<?php
/**
 * Pagine interne: fascia scura con il titolo, poi il contenuto a blocchi.
 */
get_header();
while (have_posts()) :
    the_post();
    ?>
    <header class="dnd-pagehead">
        <div class="dnd-wrap">
            <?php if (shortcode_exists('ticinoweb_breadcrumbs')) { echo do_shortcode('[ticinoweb_breadcrumbs]'); } ?>
            <h1><?php the_title(); ?></h1>
            <?php if (has_excerpt()) : ?><p class="dnd-pagehead__lead"><?php echo esc_html(get_the_excerpt()); ?></p><?php endif; ?>
        </div>
    </header>
    <div class="dnd-content dnd-content--page">
        <div class="dnd-wrap dnd-prose"><?php the_content(); ?></div>
    </div>
    <?php
endwhile;
get_footer();
