<?php
/**
 * Richieste di materiale: gestione essenziale in Bacheca.
 *
 * Ogni richiesta inviata dal modulo [dnd_richiesta_materiale] diventa una scheda («Richieste materiale») con
 * codice, stato, note interne, resoconti ricevuti e foto/documenti allegati. Il modulo pubblico dei resoconti è
 * un modulo di tW Formulari (le foto restano nelle sue Compilazioni, in cartella privata): quando arriva, il tema lo
 * collega alla richiesta dal codice (o, in mancanza, dall'e-mail) e porta lo stato a «Resoconto ricevuto».
 * Resta anche «Invii Ricevuti» del parent con il testo della richiesta: qui si tiene il filo di chi ha ricevuto cosa.
 */

if (!defined('ABSPATH')) {
    exit;
}

const DND_RICHIESTA_TYPE = 'dnd_richiesta';

function dnd_richiesta_stati() {
    return array(
        'nuova'      => __('Nuova', 'dico-no-alla-droga-child-theme'),
        'lavorazione' => __('In lavorazione', 'dico-no-alla-droga-child-theme'),
        'spedita'    => __('Spedita', 'dico-no-alla-droga-child-theme'),
        'resoconto'  => __('Resoconto ricevuto', 'dico-no-alla-droga-child-theme'),
        'chiusa'     => __('Chiusa', 'dico-no-alla-droga-child-theme'),
    );
}

function dnd_richiesta_tipi_label($tipi) {
    $map = array(
        'materiale'     => __('Opuscoli', 'dico-no-alla-droga-child-theme'),
        'kit'           => __('Kit conferenza', 'dico-no-alla-droga-child-theme'),
        'conferenziere' => __('Conferenziere', 'dico-no-alla-droga-child-theme'),
    );
    $out = array();
    foreach ((array) $tipi as $t) {
        if (isset($map[$t])) {
            $out[] = $map[$t];
        }
    }
    return implode(', ', $out);
}

add_action('init', function () {
    register_post_type(DND_RICHIESTA_TYPE, array(
        'labels' => array(
            'name'               => __('Richieste materiale', 'dico-no-alla-droga-child-theme'),
            'singular_name'      => __('Richiesta', 'dico-no-alla-droga-child-theme'),
            'menu_name'          => __('Richieste materiale', 'dico-no-alla-droga-child-theme'),
            'all_items'          => __('Tutte le richieste', 'dico-no-alla-droga-child-theme'),
            'edit_item'          => __('Richiesta', 'dico-no-alla-droga-child-theme'),
            'search_items'       => __('Cerca richieste', 'dico-no-alla-droga-child-theme'),
            'not_found'          => __('Nessuna richiesta ancora.', 'dico-no-alla-droga-child-theme'),
            'not_found_in_trash' => __('Nessuna richiesta nel cestino.', 'dico-no-alla-droga-child-theme'),
        ),
        'public'              => false,
        'show_ui'             => true,
        'show_in_menu'        => true,
        'show_in_rest'        => false,
        'menu_position'       => 25,
        'menu_icon'           => 'dashicons-clipboard',
        'capability_type'     => 'post',
        'capabilities'        => array('create_posts' => 'do_not_allow'),
        'map_meta_cap'        => true,
        'supports'            => array('title'),
        'exclude_from_search' => true,
        'rewrite'             => false,
    ));
});

/**
 * La richiesta pubblica diventa una scheda. Il codice è già nel messaggio inviato all'Associazione.
 */
add_action('ticinoweb_form_submitted', function ($submission_id, $fields, $sent) {
    $c = dnd_request_context();
    if (!$c || empty($c['codice'])) {
        return;
    }
    $id = wp_insert_post(array(
        'post_type'   => DND_RICHIESTA_TYPE,
        'post_status' => 'publish',
        'post_title'  => trim($c['ente'] . ' — ' . $c['nome']),
    ), true);
    if (is_wp_error($id) || !$id) {
        return;
    }
    foreach (array('codice', 'tipi', 'ente', 'ente_tipo', 'nome', 'email', 'telefono', 'opuscoli', 'copie', 'indirizzo', 'uso', 'occasione', 'conferenza', 'note') as $k) {
        update_post_meta($id, '_dnd_' . $k, $c[$k]);
    }
    update_post_meta($id, '_dnd_stato', 'nuova');
    update_post_meta($id, '_dnd_invio', (int) $submission_id);
}, 10, 3);

/** Trova la richiesta di un codice (o, in mancanza, l'ultima di quell'e-mail). */
function dnd_find_richiesta($code, $email) {
    $code = strtoupper(trim((string) $code));
    $base = array('post_type' => DND_RICHIESTA_TYPE, 'post_status' => 'publish', 'numberposts' => 1, 'orderby' => 'date', 'order' => 'DESC', 'fields' => 'ids');
    if ($code !== '') {
        $q = get_posts($base + array('meta_key' => '_dnd_codice', 'meta_value' => $code));
        if ($q) {
            return (int) $q[0];
        }
    }
    if (is_email($email)) {
        $q = get_posts($base + array('meta_key' => '_dnd_email', 'meta_value' => sanitize_email($email)));
        if ($q) {
            return (int) $q[0];
        }
    }
    return 0;
}

/**
 * Arriva un resoconto dal modulo di tW Formulari: lo si lega alla richiesta.
 */
add_action('twf_submission_completed', function ($form_id, $entry_id, $values) {
    if ((int) $form_id !== (int) get_option('dnd_form_resoconto') || !(int) $form_id) {
        return;
    }
    $rid = dnd_find_richiesta(isset($values['codice']) ? $values['codice'] : '', isset($values['email']) ? $values['email'] : '');
    if (!$rid) {
        return;
    }
    $list = (array) get_post_meta($rid, '_dnd_resoconti', true);
    $list[] = (int) $entry_id;
    update_post_meta($rid, '_dnd_resoconti', array_values(array_unique(array_filter($list))));
    if (in_array(get_post_meta($rid, '_dnd_stato', true), array('nuova', 'lavorazione', 'spedita'), true)) {
        update_post_meta($rid, '_dnd_stato', 'resoconto');
    }
}, 10, 3);

// ---------------------------------------------------------------------
// Schermata della richiesta
// ---------------------------------------------------------------------

add_action('add_meta_boxes_' . DND_RICHIESTA_TYPE, function () {
    remove_meta_box('submitdiv', DND_RICHIESTA_TYPE, 'side');
    add_meta_box('dnd-ric-stato', __('Stato e note', 'dico-no-alla-droga-child-theme'), 'dnd_richiesta_box_stato', DND_RICHIESTA_TYPE, 'side', 'high');
    add_meta_box('dnd-ric-dati', __('Cosa ha richiesto', 'dico-no-alla-droga-child-theme'), 'dnd_richiesta_box_dati', DND_RICHIESTA_TYPE, 'normal', 'high');
    add_meta_box('dnd-ric-resoconti', __('Resoconti, foto e documenti', 'dico-no-alla-droga-child-theme'), 'dnd_richiesta_box_resoconti', DND_RICHIESTA_TYPE, 'normal', 'default');
});

function dnd_richiesta_meta($id, $k) {
    return get_post_meta($id, '_dnd_' . $k, true);
}

function dnd_richiesta_box_stato($post) {
    $stato = dnd_richiesta_meta($post->ID, 'stato') ?: 'nuova';
    wp_nonce_field('dnd_richiesta', 'dnd_richiesta_nonce');
    ?>
    <p><strong><?php echo esc_html(dnd_richiesta_meta($post->ID, 'codice')); ?></strong> · <?php echo esc_html(get_the_date('d.m.Y', $post)); ?></p>
    <p>
        <label for="dnd_stato"><strong><?php esc_html_e('Stato', 'dico-no-alla-droga-child-theme'); ?></strong></label><br>
        <select name="dnd_stato" id="dnd_stato" style="width:100%">
            <?php foreach (dnd_richiesta_stati() as $k => $label) : ?>
                <option value="<?php echo esc_attr($k); ?>" <?php selected($stato, $k); ?>><?php echo esc_html($label); ?></option>
            <?php endforeach; ?>
        </select>
    </p>
    <p>
        <label for="dnd_note_int"><strong><?php esc_html_e('Note interne', 'dico-no-alla-droga-child-theme'); ?></strong></label><br>
        <textarea name="dnd_note_int" id="dnd_note_int" rows="5" style="width:100%"><?php echo esc_textarea((string) dnd_richiesta_meta($post->ID, 'note_int')); ?></textarea>
    </p>
    <p class="description"><?php esc_html_e('Visibili solo qui. Ricordati di portare lo stato su «Spedita» quando parte il materiale.', 'dico-no-alla-droga-child-theme'); ?></p>
    <p><button type="submit" class="button button-primary button-large" style="width:100%"><?php esc_html_e('Salva', 'dico-no-alla-droga-child-theme'); ?></button></p>
    <?php
}

function dnd_richiesta_box_dati($post) {
    $m = function ($k) use ($post) {
        return dnd_richiesta_meta($post->ID, $k);
    };
    $rows = array(
        __('Cosa', 'dico-no-alla-droga-child-theme')               => dnd_richiesta_tipi_label($m('tipi')),
        __('Scuola / associazione', 'dico-no-alla-droga-child-theme') => trim($m('ente_tipo') . ': ' . $m('ente'), ': '),
        __('Referente', 'dico-no-alla-droga-child-theme')          => $m('nome'),
        __('E-mail', 'dico-no-alla-droga-child-theme')             => $m('email'),
        __('Telefono', 'dico-no-alla-droga-child-theme')           => $m('telefono'),
        __('Opuscoli', 'dico-no-alla-droga-child-theme')           => $m('opuscoli') ? implode(', ', (array) $m('opuscoli')) . ($m('copie') ? ' — ' . (int) $m('copie') . ' ' . __('copie ciascuno', 'dico-no-alla-droga-child-theme') : '') : '',
        __('Spedire a', 'dico-no-alla-droga-child-theme')          => $m('indirizzo'),
        __('Come lo userà', 'dico-no-alla-droga-child-theme')      => $m('uso'),
        __('Occasione fissata', 'dico-no-alla-droga-child-theme')  => $m('occasione'),
        __('Conferenza richiesta', 'dico-no-alla-droga-child-theme') => $m('conferenza'),
        __('Note', 'dico-no-alla-droga-child-theme')               => $m('note'),
    );
    echo '<table class="widefat striped" style="border:0"><tbody>';
    foreach ($rows as $label => $value) {
        if ((string) $value === '') {
            continue;
        }
        echo '<tr><th style="width:190px;text-align:left">' . esc_html($label) . '</th><td>' . nl2br(esc_html((string) $value)) . '</td></tr>';
    }
    echo '</tbody></table>';

    // Chi ha già ricevuto materiale senza mandare il resoconto: da sapere prima di spedire altro.
    $email = (string) $m('email');
    if ($email !== '') {
        $others = get_posts(array('post_type' => DND_RICHIESTA_TYPE, 'post_status' => 'publish', 'numberposts' => 20, 'post__not_in' => array($post->ID),
            'meta_key' => '_dnd_email', 'meta_value' => $email));
        $missing = array();
        foreach ($others as $o) {
            if (in_array(dnd_richiesta_meta($o->ID, 'stato'), array('spedita', 'lavorazione'), true) && !dnd_richiesta_meta($o->ID, 'resoconti') && !dnd_richiesta_meta($o->ID, 'allegati')) {
                $missing[] = '<a href="' . esc_url(get_edit_post_link($o->ID)) . '">' . esc_html(dnd_richiesta_meta($o->ID, 'codice') . ' (' . get_the_date('d.m.Y', $o) . ')') . '</a>';
            }
        }
        if ($others) {
            echo '<p style="margin-top:14px"><strong>' . esc_html__('Altre richieste di questa persona:', 'dico-no-alla-droga-child-theme') . '</strong> ' . (int) count($others) . '</p>';
        }
        if ($missing) {
            echo '<p style="color:#b3261e;font-weight:600">' . esc_html__('Attenzione: ha già ricevuto materiale ma non ha ancora inviato il resoconto:', 'dico-no-alla-droga-child-theme') . ' ' . implode(', ', $missing) . '</p>'; // phpcs:ignore WordPress.Security.EscapeOutput
        }
    }
}

function dnd_richiesta_box_resoconti($post) {
    $entries = array_filter((array) dnd_richiesta_meta($post->ID, 'resoconti'));
    $allegati = array_filter(array_map('absint', (array) dnd_richiesta_meta($post->ID, 'allegati')));
    $form_id = (int) get_option('dnd_form_resoconto');
    echo '<h4 style="margin-top:0">' . esc_html__('Resoconti inviati dal modulo del sito', 'dico-no-alla-droga-child-theme') . '</h4>';
    if (!$entries) {
        echo '<p class="description">' . esc_html__('Nessun resoconto ancora. Quando arriva dal modulo pubblico, compare qui da solo (collegato dal codice richiesta o dall’e-mail).', 'dico-no-alla-droga-child-theme') . '</p>';
    } elseif (class_exists('\TicinoWeb\TWFormulari\Builder\Entries')) {
        echo '<ul style="margin:0 0 12px">';
        foreach ($entries as $eid) {
            $e = \TicinoWeb\TWFormulari\Builder\Entries::get((int) $eid);
            if (!$e) {
                continue;
            }
            $url   = \TicinoWeb\TWFormulari\Builder\EntriesAdmin::list_url(array('entry' => (int) $eid));
            $photo = is_array($e['files']) ? count($e['files']) : 0;
            echo '<li>' . esc_html(get_date_from_gmt($e['created_gmt'], 'd.m.Y H:i')) . ' — ' . esc_html(sprintf(_n('%d foto/file', '%d foto/file', $photo, 'dico-no-alla-droga-child-theme'), $photo)) . ' · <a href="' . esc_url($url) . '">' . esc_html__('Apri il resoconto con le foto', 'dico-no-alla-droga-child-theme') . '</a></li>';
        }
        echo '</ul>';
    }
    echo '<h4>' . esc_html__('Foto e documenti allegati a mano', 'dico-no-alla-droga-child-theme') . '</h4>';
    echo '<p class="description">' . esc_html__('Per ciò che arriva per e-mail o di persona: aggiungi le foto e i documenti ricevuti.', 'dico-no-alla-droga-child-theme') . '</p>';
    wp_enqueue_media();
    echo '<input type="hidden" name="dnd_allegati" id="dnd_allegati" value="' . esc_attr(implode(',', $allegati)) . '">';
    echo '<div id="dnd_allegati_grid" style="display:flex;flex-wrap:wrap;gap:10px;margin:10px 0">';
    foreach ($allegati as $aid) {
        echo dnd_richiesta_allegato_html($aid); // phpcs:ignore WordPress.Security.EscapeOutput
    }
    echo '</div>';
    echo '<p><button type="button" class="button button-primary" id="dnd_allegati_add">' . esc_html__('Aggiungi foto o documenti', 'dico-no-alla-droga-child-theme') . '</button></p>';
    ?>
    <script>
    (function () {
        var input = document.getElementById('dnd_allegati'), grid = document.getElementById('dnd_allegati_grid'), frame;
        function ids() { return input.value ? input.value.split(',') : []; }
        function card(a) {
            var d = document.createElement('div');
            d.className = 'dnd-all'; d.setAttribute('data-id', a.id);
            d.style.cssText = 'width:130px;border:1px solid #dcdcde;border-radius:8px;padding:6px;background:#fff;font-size:12px;position:relative';
            var thumb = (a.sizes && a.sizes.thumbnail) ? a.sizes.thumbnail.url : (a.type === 'image' ? a.url : '');
            d.innerHTML = (thumb ? '<img src="' + thumb + '" alt="" style="width:100%;height:90px;object-fit:cover;border-radius:4px">' : '<div style="height:90px;display:flex;align-items:center;justify-content:center;background:#f0f6f8;border-radius:4px">' + (a.subtype || 'file').toUpperCase() + '</div>')
                + '<div style="margin-top:4px;word-break:break-all">' + (a.filename || '') + '</div>'
                + '<button type="button" class="button-link" style="color:#b3261e">Togli</button>';
            return d;
        }
        document.getElementById('dnd_allegati_add').addEventListener('click', function () {
            if (!frame) {
                frame = wp.media({ title: 'Foto e documenti ricevuti', button: { text: 'Allega alla richiesta' }, multiple: true });
                frame.on('select', function () {
                    frame.state().get('selection').each(function (m) {
                        var a = m.toJSON(); var list = ids();
                        if (list.indexOf(String(a.id)) === -1) { list.push(String(a.id)); input.value = list.join(','); grid.appendChild(card(a)); }
                    });
                });
            }
            frame.open();
        });
        grid.addEventListener('click', function (e) {
            if (e.target.tagName !== 'BUTTON') { return; }
            var d = e.target.closest('.dnd-all'); var id = d.getAttribute('data-id');
            input.value = ids().filter(function (x) { return x !== id; }).join(','); d.remove();
        });
    })();
    </script>
    <?php
}

function dnd_richiesta_allegato_html($aid) {
    $url   = wp_get_attachment_url($aid);
    if (!$url) {
        return '';
    }
    $file  = wp_basename($url);
    $thumb = wp_attachment_is_image($aid) ? wp_get_attachment_image($aid, 'thumbnail', false, array('style' => 'width:100%;height:90px;object-fit:cover;border-radius:4px')) : '<div style="height:90px;display:flex;align-items:center;justify-content:center;background:#f0f6f8;border-radius:4px">' . esc_html(strtoupper(pathinfo($file, PATHINFO_EXTENSION))) . '</div>';
    return '<div class="dnd-all" data-id="' . (int) $aid . '" style="width:130px;border:1px solid #dcdcde;border-radius:8px;padding:6px;background:#fff;font-size:12px"><a href="' . esc_url($url) . '" target="_blank" rel="noopener">' . $thumb . '</a><div style="margin-top:4px;word-break:break-all">' . esc_html($file) . '</div><button type="button" class="button-link" style="color:#b3261e">' . esc_html__('Togli', 'dico-no-alla-droga-child-theme') . '</button></div>';
}

add_action('save_post_' . DND_RICHIESTA_TYPE, function ($post_id) {
    if (!isset($_POST['dnd_richiesta_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['dnd_richiesta_nonce'])), 'dnd_richiesta')) {
        return;
    }
    if ((defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) || !current_user_can('edit_post', $post_id)) {
        return;
    }
    $stato = isset($_POST['dnd_stato']) ? sanitize_key(wp_unslash($_POST['dnd_stato'])) : 'nuova';
    update_post_meta($post_id, '_dnd_stato', isset(dnd_richiesta_stati()[$stato]) ? $stato : 'nuova');
    update_post_meta($post_id, '_dnd_note_int', isset($_POST['dnd_note_int']) ? sanitize_textarea_field(wp_unslash($_POST['dnd_note_int'])) : '');
    $ids = isset($_POST['dnd_allegati']) ? array_filter(array_map('absint', explode(',', sanitize_text_field(wp_unslash($_POST['dnd_allegati']))))) : array();
    $ids = array_values(array_filter($ids, function ($id) {
        return get_post_type($id) === 'attachment';
    }));
    update_post_meta($post_id, '_dnd_allegati', $ids);
});

// ---------------------------------------------------------------------
// Elenco
// ---------------------------------------------------------------------

add_filter('manage_' . DND_RICHIESTA_TYPE . '_posts_columns', function () {
    return array(
        'cb'        => '<input type="checkbox">',
        'title'     => __('Scuola / associazione', 'dico-no-alla-droga-child-theme'),
        'dnd_cod'   => __('Codice', 'dico-no-alla-droga-child-theme'),
        'dnd_cosa'  => __('Cosa', 'dico-no-alla-droga-child-theme'),
        'dnd_stato' => __('Stato', 'dico-no-alla-droga-child-theme'),
        'dnd_res'   => __('Resoconto', 'dico-no-alla-droga-child-theme'),
        'date'      => __('Data', 'dico-no-alla-droga-child-theme'),
    );
});

add_action('manage_' . DND_RICHIESTA_TYPE . '_posts_custom_column', function ($col, $id) {
    if ($col === 'dnd_cod') {
        echo esc_html(dnd_richiesta_meta($id, 'codice'));
    } elseif ($col === 'dnd_cosa') {
        echo esc_html(dnd_richiesta_tipi_label(dnd_richiesta_meta($id, 'tipi')));
    } elseif ($col === 'dnd_stato') {
        $st = dnd_richiesta_meta($id, 'stato') ?: 'nuova';
        $colors = array('nuova' => '#b3261e', 'lavorazione' => '#8a5a00', 'spedita' => '#00788c', 'resoconto' => '#0f7a4a', 'chiusa' => '#50636b');
        echo '<strong style="color:' . esc_attr($colors[$st] ?? '#000') . '">' . esc_html(dnd_richiesta_stati()[$st] ?? $st) . '</strong>';
    } elseif ($col === 'dnd_res') {
        $n = count(array_filter((array) dnd_richiesta_meta($id, 'resoconti'))) + count(array_filter((array) dnd_richiesta_meta($id, 'allegati')));
        $needs = in_array(dnd_richiesta_meta($id, 'stato'), array('spedita', 'lavorazione'), true) && in_array('materiale', (array) dnd_richiesta_meta($id, 'tipi'), true) || in_array('kit', (array) dnd_richiesta_meta($id, 'tipi'), true);
        if ($n) {
            echo '<span style="color:#0f7a4a;font-weight:600">✓ ' . (int) $n . '</span>';
        } elseif ($needs && dnd_richiesta_meta($id, 'stato') === 'spedita') {
            echo '<span style="color:#b3261e">' . esc_html__('Da sollecitare', 'dico-no-alla-droga-child-theme') . '</span>';
        } else {
            echo '<span aria-hidden="true">—</span>';
        }
    }
}, 10, 2);

add_action('restrict_manage_posts', function ($type) {
    if ($type !== DND_RICHIESTA_TYPE) {
        return;
    }
    $cur = isset($_GET['dnd_stato']) ? sanitize_key(wp_unslash($_GET['dnd_stato'])) : '';
    echo '<select name="dnd_stato"><option value="">' . esc_html__('Tutti gli stati', 'dico-no-alla-droga-child-theme') . '</option>';
    foreach (dnd_richiesta_stati() as $k => $label) {
        echo '<option value="' . esc_attr($k) . '"' . selected($cur, $k, false) . '>' . esc_html($label) . '</option>';
    }
    echo '</select>';
});

add_action('pre_get_posts', function ($q) {
    if (!is_admin() || !$q->is_main_query() || $q->get('post_type') !== DND_RICHIESTA_TYPE) {
        return;
    }
    if (!empty($_GET['dnd_stato'])) {
        $q->set('meta_query', array(array('key' => '_dnd_stato', 'value' => sanitize_key(wp_unslash($_GET['dnd_stato'])))));
    }
    if (!$q->get('s')) {
        return;
    }
    // La ricerca guarda anche codice, e-mail e referente.
    $term = sanitize_text_field($q->get('s'));
    add_filter('posts_search', function ($search) use ($term) {
        global $wpdb;
        $like = '%' . $wpdb->esc_like($term) . '%';
        return $wpdb->prepare(" AND ({$wpdb->posts}.post_title LIKE %s OR EXISTS (SELECT 1 FROM {$wpdb->postmeta} pm WHERE pm.post_id = {$wpdb->posts}.ID AND pm.meta_key IN ('_dnd_codice','_dnd_email','_dnd_nome') AND pm.meta_value LIKE %s))", $like, $like);
    });
});

/** Segnalino con il numero di richieste nuove nel menu. */
add_action('admin_menu', function () {
    global $menu;
    $n = (int) (new WP_Query(array('post_type' => DND_RICHIESTA_TYPE, 'post_status' => 'publish', 'meta_key' => '_dnd_stato', 'meta_value' => 'nuova', 'fields' => 'ids', 'posts_per_page' => 50, 'no_found_rows' => true)))->post_count;
    if (!$n || !is_array($menu)) {
        return;
    }
    foreach ($menu as $k => $item) {
        if (isset($item[2]) && $item[2] === 'edit.php?post_type=' . DND_RICHIESTA_TYPE) {
            $menu[$k][0] .= ' <span class="awaiting-mod">' . $n . '</span>'; // phpcs:ignore WordPress.WP.GlobalVariablesOverride
        }
    }
}, 99);
