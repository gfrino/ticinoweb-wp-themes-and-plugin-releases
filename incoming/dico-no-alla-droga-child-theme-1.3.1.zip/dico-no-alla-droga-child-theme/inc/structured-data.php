<?php
/**
 * Dati strutturati: arricchisce l'Organization del parent (tW SEO) con i dati di ticinoWEB CMS.
 * Nessuno schema parallelo: usa il filtro del parent, un solo JSON-LD per pagina.
 */

if (!defined('ABSPATH')) {
    exit;
}

add_filter('ticinoweb_seo_jsonld_org_schema', function ($schema) {
    $schema['@type'] = 'NGO';

    $email = get_option('ticinoweb_contact_email');
    if ($email) {
        $schema['email'] = $email;
    }
    $phone = get_option('ticinoweb_contact_phone');
    if ($phone) {
        $schema['telephone'] = $phone;
    }
    $address = get_option('ticinoweb_contact_address');
    if ($address && empty($schema['address'])) {
        $schema['address'] = array('@type' => 'PostalAddress', 'streetAddress' => $address, 'addressCountry' => 'CH');
    }
    $same = array();
    foreach (array('facebook', 'instagram', 'linkedin', 'youtube', 'tiktok', 'x') as $k) {
        $u = get_option('ticinoweb_contact_' . $k);
        if ($u) {
            $same[] = $u;
        }
    }
    if ($same) {
        $schema['sameAs'] = array_values(array_unique(array_merge((array) ($schema['sameAs'] ?? array()), $same)));
    }
    $schema['areaServed'] = array('@type' => 'AdministrativeArea', 'name' => 'Ticino');
    return $schema;
});
