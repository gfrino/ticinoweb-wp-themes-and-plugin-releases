<?php
/**
 * Opuscoli: i contenuti «Opuscoli» (tipo di contenuto configurato nel parent, ticinoWEB CMS → Tipi di
 * contenuto, slug «opuscolo») con copertina = immagine in evidenza e PDF = campo qui sotto.
 *
 * Il child non crea il tipo di contenuto (lo fa il parent da un'opzione): aggiunge solo il campo «File PDF»
 * con un selettore della Libreria media e lo shortcode [dnd_opuscoli] per mostrarli.
 */

if (!defined('ABSPATH')) {
    exit;
}

const DND_OPUSCOLO_TYPE = 'opuscolo';
const DND_OPUSCOLO_PDF  = '_dnd_pdf_id';

/**
 * Schermata «Opuscolo» semplificata: il titolo e due scelte (copertina, PDF) con anteprima dal vivo.
 * Niente editor a blocchi, riassunto, campi personalizzati o attributi: qui non servono.
 */
add_action('init', function () {
    foreach (array('editor', 'excerpt', 'custom-fields', 'page-attributes') as $feature) {
        remove_post_type_support(DND_OPUSCOLO_TYPE, $feature);
    }
}, 20);

add_filter('enter_title_here', function ($text, $post) {
    return $post && $post->post_type === DND_OPUSCOLO_TYPE ? __('Titolo dell’opuscolo (es. «La verità sul Ritalin»)', 'dico-no-alla-droga-child-theme') : $text;
}, 10, 2);

add_action('add_meta_boxes_' . DND_OPUSCOLO_TYPE, function () {
    remove_meta_box('postimagediv', DND_OPUSCOLO_TYPE, 'side');
    remove_meta_box('slugdiv', DND_OPUSCOLO_TYPE, 'normal');
    add_meta_box('dnd-opuscolo', __('Copertina e PDF', 'dico-no-alla-droga-child-theme'), 'dnd_opuscolo_metabox', DND_OPUSCOLO_TYPE, 'normal', 'high');
});

function dnd_opuscolo_metabox($post) {
    $pdf_id   = (int) get_post_meta($post->ID, DND_OPUSCOLO_PDF, true);
    $pdf_url  = $pdf_id ? wp_get_attachment_url($pdf_id) : '';
    $cover_id = (int) get_post_thumbnail_id($post);
    $cover    = $cover_id ? wp_get_attachment_image_url($cover_id, 'medium') : '';
    wp_nonce_field('dnd_opuscolo', 'dnd_opuscolo_nonce');
    wp_enqueue_media();
    ?>
    <div class="dnd-ob">
        <div class="dnd-ob__card">
            <h3><span class="dnd-ob__n">1</span> <?php esc_html_e('Copertina', 'dico-no-alla-droga-child-theme'); ?></h3>
            <div class="dnd-ob__cover" id="dnd_cover_box">
                <img id="dnd_cover_img" src="<?php echo esc_url($cover); ?>" alt="" <?php echo $cover ? '' : 'hidden'; ?>>
                <span id="dnd_cover_empty" <?php echo $cover ? 'hidden' : ''; ?>><?php esc_html_e('Nessuna copertina', 'dico-no-alla-droga-child-theme'); ?></span>
            </div>
            <input type="hidden" name="dnd_cover_id" id="dnd_cover_id" value="<?php echo esc_attr($cover_id); ?>">
            <p class="dnd-ob__actions">
                <button type="button" class="button button-primary" id="dnd_cover_pick"><?php echo $cover ? esc_html__('Cambia copertina', 'dico-no-alla-droga-child-theme') : esc_html__('Scegli la copertina', 'dico-no-alla-droga-child-theme'); ?></button>
            </p>
            <p class="description"><?php esc_html_e('Un’immagine orizzontale: si vede intera, senza tagli.', 'dico-no-alla-droga-child-theme'); ?></p>
        </div>
        <div class="dnd-ob__card">
            <h3><span class="dnd-ob__n">2</span> <?php esc_html_e('File PDF da scaricare', 'dico-no-alla-droga-child-theme'); ?></h3>
            <input type="hidden" name="dnd_pdf_id" id="dnd_pdf_id" value="<?php echo esc_attr($pdf_id); ?>">
            <div class="dnd-ob__pdf <?php echo $pdf_url ? 'is-set' : ''; ?>" id="dnd_pdf_box">
                <span class="dashicons dashicons-media-document" aria-hidden="true"></span>
                <span id="dnd_pdf_name"><?php echo $pdf_url ? esc_html(wp_basename($pdf_url)) : esc_html__('Nessun PDF scelto', 'dico-no-alla-droga-child-theme'); ?></span>
            </div>
            <p class="dnd-ob__actions">
                <button type="button" class="button button-primary" id="dnd_pdf_pick"><?php echo $pdf_url ? esc_html__('Cambia PDF', 'dico-no-alla-droga-child-theme') : esc_html__('Scegli o carica il PDF', 'dico-no-alla-droga-child-theme'); ?></button>
                <button type="button" class="button-link dnd-ob__remove" id="dnd_pdf_clear" <?php echo $pdf_id ? '' : 'hidden'; ?>><?php esc_html_e('Togli il PDF', 'dico-no-alla-droga-child-theme'); ?></button>
            </p>
            <p class="description"><?php esc_html_e('I visitatori lo scaricano dal sito. Puoi anche lasciarlo vuoto: resta la richiesta di copie.', 'dico-no-alla-droga-child-theme'); ?></p>
        </div>
        <div class="dnd-ob__card dnd-ob__card--small">
            <h3><span class="dnd-ob__n">3</span> <?php esc_html_e('Posizione nell’elenco', 'dico-no-alla-droga-child-theme'); ?></h3>
            <input type="number" min="0" step="1" name="dnd_order" id="dnd_order" value="<?php echo esc_attr((int) $post->menu_order); ?>">
            <p class="description"><?php esc_html_e('Facoltativo. Numeri bassi compaiono per primi (1 = in cima); a parità, in ordine alfabetico.', 'dico-no-alla-droga-child-theme'); ?></p>
        </div>
    </div>
    <style>
        #dnd-opuscolo .inside { margin: 0; padding: 16px; }
        .dnd-ob { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 16px; }
        .dnd-ob__card { border: 1px solid #dcdcde; border-radius: 10px; padding: 16px 18px; background: #fff; }
        .dnd-ob__card--small { grid-column: 1 / -1; }
        .dnd-ob__card h3 { margin: 0 0 12px; font-size: 15px; display: flex; align-items: center; gap: 8px; }
        .dnd-ob__n { display: inline-flex; width: 24px; height: 24px; border-radius: 50%; background: #0a1b24; color: #fff; font-size: 13px; align-items: center; justify-content: center; }
        .dnd-ob__cover { aspect-ratio: 3 / 2; background: #f0f6f8; border: 2px dashed #c3d3d9; border-radius: 8px; display: flex; align-items: center; justify-content: center; overflow: hidden; color: #50636b; }
        .dnd-ob__cover img { width: 100%; height: 100%; object-fit: contain; }
        .dnd-ob__cover [hidden], .dnd-ob [hidden] { display: none !important; }
        .dnd-ob__pdf { display: flex; align-items: center; gap: 10px; padding: 18px; background: #f0f6f8; border: 2px dashed #c3d3d9; border-radius: 8px; min-height: 90px; word-break: break-all; color: #50636b; }
        .dnd-ob__pdf.is-set { border-style: solid; border-color: #0f7a4a; background: #eef8f2; color: #14262f; font-weight: 600; }
        .dnd-ob__pdf .dashicons { font-size: 30px; width: 30px; height: 30px; flex: 0 0 auto; }
        .dnd-ob__actions { margin: 12px 0 6px; display: flex; align-items: center; gap: 16px; }
        .dnd-ob__remove { color: #b3261e; }
        .dnd-ob input[type=number] { width: 100px; }
        @media (max-width: 782px) { .dnd-ob { grid-template-columns: 1fr; } }
        .post-type-<?php echo esc_attr(DND_OPUSCOLO_TYPE); ?> #titlediv #title { font-size: 1.5em; padding: 10px 12px; }
    </style>
    <script>
    (function () {
        var $ = function (id) { return document.getElementById(id); };
        function picker(btn, opts, onSelect) {
            var frame;
            $(btn).addEventListener('click', function () {
                if (!frame) {
                    frame = wp.media({ title: opts.title, button: { text: opts.button }, library: { type: opts.type }, multiple: false });
                    frame.on('select', function () { onSelect(frame.state().get('selection').first().toJSON()); });
                }
                frame.open();
            });
        }
        picker('dnd_cover_pick', { title: <?php echo wp_json_encode(__('Scegli la copertina', 'dico-no-alla-droga-child-theme')); ?>, button: <?php echo wp_json_encode(__('Usa come copertina', 'dico-no-alla-droga-child-theme')); ?>, type: 'image' }, function (a) {
            $('dnd_cover_id').value = a.id;
            var img = $('dnd_cover_img'); img.src = (a.sizes && a.sizes.medium) ? a.sizes.medium.url : a.url; img.hidden = false;
            $('dnd_cover_empty').hidden = true; $('dnd_cover_pick').textContent = <?php echo wp_json_encode(__('Cambia copertina', 'dico-no-alla-droga-child-theme')); ?>;
        });
        picker('dnd_pdf_pick', { title: <?php echo wp_json_encode(__('Scegli il PDF', 'dico-no-alla-droga-child-theme')); ?>, button: <?php echo wp_json_encode(__('Usa questo PDF', 'dico-no-alla-droga-child-theme')); ?>, type: 'application/pdf' }, function (a) {
            $('dnd_pdf_id').value = a.id; $('dnd_pdf_name').textContent = a.filename || a.url;
            $('dnd_pdf_box').classList.add('is-set'); $('dnd_pdf_clear').hidden = false;
            $('dnd_pdf_pick').textContent = <?php echo wp_json_encode(__('Cambia PDF', 'dico-no-alla-droga-child-theme')); ?>;
        });
        $('dnd_pdf_clear').addEventListener('click', function () {
            $('dnd_pdf_id').value = ''; $('dnd_pdf_name').textContent = <?php echo wp_json_encode(__('Nessun PDF scelto', 'dico-no-alla-droga-child-theme')); ?>;
            $('dnd_pdf_box').classList.remove('is-set'); this.hidden = true;
            $('dnd_pdf_pick').textContent = <?php echo wp_json_encode(__('Scegli o carica il PDF', 'dico-no-alla-droga-child-theme')); ?>;
        });
    })();
    </script>
    <?php
}

add_action('save_post_' . DND_OPUSCOLO_TYPE, function ($post_id) {
    if (!isset($_POST['dnd_opuscolo_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['dnd_opuscolo_nonce'])), 'dnd_opuscolo')) {
        return;
    }
    if ((defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) || !current_user_can('edit_post', $post_id)) {
        return;
    }
    $pdf = isset($_POST['dnd_pdf_id']) ? absint($_POST['dnd_pdf_id']) : 0;
    if ($pdf && get_post_mime_type($pdf) === 'application/pdf') {
        update_post_meta($post_id, DND_OPUSCOLO_PDF, $pdf);
    } else {
        delete_post_meta($post_id, DND_OPUSCOLO_PDF);
    }
    $cover = isset($_POST['dnd_cover_id']) ? absint($_POST['dnd_cover_id']) : 0;
    if ($cover && wp_attachment_is_image($cover)) {
        set_post_thumbnail($post_id, $cover);
    } else {
        delete_post_thumbnail($post_id);
    }
    if (isset($_POST['dnd_order'])) {
        $order = max(0, absint($_POST['dnd_order']));
        if ($order !== (int) get_post_field('menu_order', $post_id)) {
            global $wpdb;
            $wpdb->update($wpdb->posts, array('menu_order' => $order), array('ID' => $post_id), array('%d'), array('%d'));
            clean_post_cache($post_id);
        }
    }
    wp_cache_delete('dnd_opuscoli_-1', 'dnd');
});

/* Elenco in Bacheca: copertina, titolo, PDF presente o mancante. */
add_filter('manage_' . DND_OPUSCOLO_TYPE . '_posts_columns', function () {
    return array(
        'cb'        => '<input type="checkbox">',
        'dnd_cover' => __('Copertina', 'dico-no-alla-droga-child-theme'),
        'title'     => __('Titolo', 'dico-no-alla-droga-child-theme'),
        'dnd_pdf'   => __('PDF', 'dico-no-alla-droga-child-theme'),
        'dnd_order' => __('Posizione', 'dico-no-alla-droga-child-theme'),
    );
});
add_action('manage_' . DND_OPUSCOLO_TYPE . '_posts_custom_column', function ($col, $post_id) {
    if ($col === 'dnd_cover') {
        echo has_post_thumbnail($post_id) ? get_the_post_thumbnail($post_id, array(90, 60), array('style' => 'width:90px;height:60px;object-fit:contain;background:#f0f6f8;border-radius:4px')) : '<span aria-hidden="true">—</span>';
    } elseif ($col === 'dnd_pdf') {
        echo get_post_meta($post_id, DND_OPUSCOLO_PDF, true)
            ? '<span style="color:#0f7a4a;font-weight:600">✓ ' . esc_html__('Presente', 'dico-no-alla-droga-child-theme') . '</span>'
            : '<span style="color:#b3261e">' . esc_html__('Manca', 'dico-no-alla-droga-child-theme') . '</span>';
    } elseif ($col === 'dnd_order') {
        echo (int) get_post_field('menu_order', $post_id);
    }
}, 10, 2);
add_action('pre_get_posts', function ($q) {
    if (is_admin() && $q->is_main_query() && $q->get('post_type') === DND_OPUSCOLO_TYPE && !$q->get('orderby')) {
        $q->set('orderby', array('menu_order' => 'ASC', 'title' => 'ASC'));
    }
});
add_action('admin_head-edit.php', function () {
    if (get_current_screen() && get_current_screen()->post_type === DND_OPUSCOLO_TYPE) {
        echo '<style>.column-dnd_cover{width:110px}.column-dnd_pdf,.column-dnd_order{width:110px}</style>';
    }
});

/**
 * Elenco degli opuscoli pubblicati (usato dallo shortcode e dal modulo di richiesta).
 *
 * @return WP_Post[]
 */
function dnd_get_opuscoli($limit = -1) {
    if (!post_type_exists(DND_OPUSCOLO_TYPE)) {
        return array();
    }
    $key = 'dnd_opuscoli_' . (int) $limit;
    $cached = wp_cache_get($key, 'dnd');
    if (is_array($cached)) {
        return $cached;
    }
    $posts = get_posts(array(
        'post_type'              => DND_OPUSCOLO_TYPE,
        'post_status'            => 'publish',
        'posts_per_page'         => (int) $limit,
        'orderby'                => array('menu_order' => 'ASC', 'title' => 'ASC'),
        'no_found_rows'          => true,
        'update_post_term_cache' => false,
    ));
    wp_cache_set($key, $posts, 'dnd', 300);
    return $posts;
}

/**
 * [dnd_opuscoli limit="6" richiedi="1"] – griglia delle copertine con «Scarica PDF» e «Aggiungi alla richiesta».
 */
add_shortcode('dnd_opuscoli', function ($atts) {
    $atts  = shortcode_atts(array('limit' => '-1', 'richiedi' => '1'), $atts, 'dnd_opuscoli');
    $posts = dnd_get_opuscoli((int) $atts['limit']);
    if (!$posts) {
        return current_user_can('edit_pages')
            ? '<p class="dnd-empty">' . esc_html__('Nessun opuscolo pubblicato: aggiungili dal menu «Opuscoli» della Bacheca.', 'dico-no-alla-droga-child-theme') . '</p>'
            : '';
    }
    dnd_enqueue_reader_assets();
    ob_start();
    echo '<ul class="dnd-booklets">';
    foreach ($posts as $p) {
        $pdf_id = (int) get_post_meta($p->ID, DND_OPUSCOLO_PDF, true);
        $pdf    = $pdf_id ? wp_get_attachment_url($pdf_id) : '';
        $title  = get_the_title($p);
        echo '<li class="dnd-booklet">';
        echo '<div class="dnd-booklet__cover">';
        if (has_post_thumbnail($p)) {
            echo get_the_post_thumbnail($p, 'dnd-cover', array('loading' => 'lazy', 'alt' => sprintf(/* translators: %s: booklet title */ __('Copertina: %s', 'dico-no-alla-droga-child-theme'), $title)));
        }
        echo '</div>';
        echo '<h3 class="dnd-sr">' . esc_html($title) . '</h3>';
        echo '<div class="dnd-booklet__actions">';
        if ($pdf) {
            printf(
                '<a class="dnd-bk dnd-bk--read" href="%1$s" data-dnd-read="%1$s" data-title="%2$s">%3$s</a>',
                esc_url($pdf),
                esc_attr($title),
                esc_html__('Sfoglia online', 'dico-no-alla-droga-child-theme')
            );
        }
        if ($atts['richiedi'] === '1') {
            printf(
                '<a class="dnd-bk dnd-bk--ask" href="%s" data-dnd-add="%d">%s</a>',
                esc_url(add_query_arg('opuscolo', $p->ID, home_url('/')) . '#richiedi'),
                (int) $p->ID,
                esc_html__('Richiedi copie', 'dico-no-alla-droga-child-theme')
            );
        }
        echo '</div></li>';
    }
    echo '</ul>';
    return ob_get_clean();
});

/**
 * Lettore sfogliabile: script e librerie (in locale, nel tema) solo dove c'è l'elenco degli opuscoli.
 */
function dnd_enqueue_reader_assets() {
    static $done = false;
    if ($done) {
        return;
    }
    $done = true;
    $dir = get_stylesheet_directory();
    $uri = get_stylesheet_directory_uri();
    $ver = function ($rel) use ($dir) {
        return file_exists($dir . $rel) ? filemtime($dir . $rel) : DND_THEME_VERSION;
    };
    wp_enqueue_script('dnd-reader', $uri . '/assets/js/reader.js', array(), $ver('/assets/js/reader.js'), true);
    wp_localize_script('dnd-reader', 'dndReader', array(
        'pdfjs'    => $uri . '/assets/vendor/pdfjs/pdf.min.js?ver=3.11.174',
        'worker'   => $uri . '/assets/vendor/pdfjs/pdf.worker.min.js?ver=3.11.174',
        'pageflip' => $uri . '/assets/vendor/page-flip/page-flip.browser.js?ver=2.0.7',
        'i18n'     => array(
            'dialog'   => __('Lettore dell’opuscolo', 'dico-no-alla-droga-child-theme'),
            'close'    => __('Chiudi', 'dico-no-alla-droga-child-theme'),
            'prev'     => __('Pagina precedente', 'dico-no-alla-droga-child-theme'),
            'next'     => __('Pagina successiva', 'dico-no-alla-droga-child-theme'),
            'download' => __('Scarica il PDF', 'dico-no-alla-droga-child-theme'),
            'loading'  => __('Caricamento dell’opuscolo…', 'dico-no-alla-droga-child-theme'),
            'error'    => __('Non riesco ad aprire l’opuscolo qui: scaricalo in PDF.', 'dico-no-alla-droga-child-theme'),
            'page'     => __('Pagina', 'dico-no-alla-droga-child-theme'),
        ),
    ));
}
