<?php
/**
 * Header: logo, menu principale (posizione «primary» del parent), pulsante «Richiedi materiale».
 */
if (!defined('ABSPATH')) {
    exit;
}
$logo      = function_exists('ticinoweb_get_site_logo') ? ticinoweb_get_site_logo() : false;
$site_name = get_bloginfo('name');
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="dnd-skip" href="#contenuto"><?php esc_html_e('Vai al contenuto', 'dico-no-alla-droga-child-theme'); ?></a>

<header class="dnd-header">
    <div class="dnd-header__bar">
        <a class="dnd-brand" href="<?php echo esc_url(home_url('/')); ?>" rel="home">
            <?php if ($logo) : ?>
                <img src="<?php echo esc_url($logo); ?>" alt="<?php echo esc_attr($site_name); ?>" width="260" height="50">
            <?php else : ?>
                <span class="dnd-brand__text"><?php echo esc_html($site_name); ?></span>
            <?php endif; ?>
        </a>

        <button class="dnd-nav-toggle" type="button" aria-expanded="false" aria-controls="dnd-nav">
            <span class="screen-reader-text"><?php esc_html_e('Menu', 'dico-no-alla-droga-child-theme'); ?></span>
            <span class="dnd-nav-toggle__bars" aria-hidden="true"></span>
        </button>

        <nav class="dnd-nav" id="dnd-nav" aria-label="<?php esc_attr_e('Menu principale', 'dico-no-alla-droga-child-theme'); ?>">
            <?php
            wp_nav_menu(array(
                'theme_location' => 'primary',
                'menu_class'     => 'dnd-menu',
                'container'      => false,
                'fallback_cb'    => false,
                'depth'          => 1,
            ));
            ?>
            <a class="dnd-btn dnd-btn--sun dnd-nav__cta" href="<?php echo esc_url(dnd_cta_url()); ?>"><?php esc_html_e('Richiedi materiale', 'dico-no-alla-droga-child-theme'); ?></a>
        </nav>
    </div>
</header>
<main id="contenuto" class="dnd-main">
