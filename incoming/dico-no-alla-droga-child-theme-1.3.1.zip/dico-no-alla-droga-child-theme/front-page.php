<?php
/**
 * Home: il contenuto (sezioni a blocchi) sta nella pagina impostata come home, modificabile da Pagine.
 * Il tema fornisce solo l'aspetto e i componenti [dnd_richiesta_materiale], [dnd_opuscoli], [tw_faq].
 */
get_header();
while (have_posts()) :
    the_post();
    ?>
    <div class="dnd-content dnd-content--home"><?php the_content(); ?></div>
    <?php
endwhile;
get_footer();
