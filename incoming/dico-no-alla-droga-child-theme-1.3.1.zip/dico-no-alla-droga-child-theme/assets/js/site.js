/* Header: menu a tendina su telefono, ombra allo scroll. Nessuna dipendenza. */
(function () {
    'use strict';
    var header = document.querySelector('.dnd-header');
    var toggle = document.querySelector('.dnd-nav-toggle');
    if (!header) { return; }

    function onScroll() { header.classList.toggle('is-scrolled', window.scrollY > 8); }
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });

    if (toggle) {
        toggle.addEventListener('click', function () {
            var open = header.classList.toggle('is-open');
            toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
        });
        header.addEventListener('click', function (e) {
            if (e.target.closest && e.target.closest('.dnd-nav a')) {
                header.classList.remove('is-open');
                toggle.setAttribute('aria-expanded', 'false');
            }
        });
        document.addEventListener('keydown', function (e) {
            if (e.key === 'Escape') {
                header.classList.remove('is-open');
                toggle.setAttribute('aria-expanded', 'false');
            }
        });
    }
})();
