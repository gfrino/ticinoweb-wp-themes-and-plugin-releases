/* Lettore sfogliabile degli opuscoli: pdf.js disegna le pagine, StPageFlip le fa girare. Le librerie si caricano solo all'apertura. */
(function () {
    'use strict';
    var cfg = window.dndReader || {};
    var i18n = cfg.i18n || {};
    var scripts = {};
    var modal, stage, flip, pdf, rendered = {}, ratio = 1.4, current = 0, lastFocus, docs = {}, queue = [], busy = 0, token = 0, coverSrc = '';

    function loadScript(src) {
        if (!scripts[src]) {
            scripts[src] = new Promise(function (resolve, reject) {
                var s = document.createElement('script');
                s.src = src; s.async = true; s.onload = resolve; s.onerror = reject;
                document.head.appendChild(s);
            });
        }
        return scripts[src];
    }

    function libs() { return Promise.all([loadScript(cfg.pdfjs), loadScript(cfg.pageflip)]); }

    // Il PDF si apre a richiesta: solo l'intestazione e le pagine che servono (il server accetta richieste parziali).
    function loadDoc(url) {
        if (!docs[url]) {
            docs[url] = libs().then(function () {
                window.pdfjsLib.GlobalWorkerOptions.workerSrc = cfg.worker;
                return window.pdfjsLib.getDocument({ url: url, disableAutoFetch: true, disableStream: false, rangeChunkSize: 262144 }).promise;
            }).then(function (d) { return d.getPage(1).then(function () { return d; }); });
            docs[url].catch(function () { delete docs[url]; });
        }
        return docs[url];
    }

    function el(tag, cls, html) {
        var n = document.createElement(tag);
        if (cls) { n.className = cls; }
        if (html) { n.innerHTML = html; }
        return n;
    }

    function build() {
        if (modal) { return; }
        modal = el('div', 'dnd-reader');
        modal.setAttribute('role', 'dialog');
        modal.setAttribute('aria-modal', 'true');
        modal.setAttribute('aria-label', i18n.dialog || 'Lettore');
        modal.hidden = true;
        modal.innerHTML =
            '<div class="dnd-reader__bar">' +
                '<strong class="dnd-reader__title"></strong>' +
                '<a class="dnd-reader__dl" target="_blank" rel="noopener"></a>' +
                '<button type="button" class="dnd-reader__close" aria-label="' + (i18n.close || 'Chiudi') + '">&times;</button>' +
            '</div>' +
            '<div class="dnd-reader__body">' +
                '<button type="button" class="dnd-reader__nav dnd-reader__nav--prev" aria-label="' + (i18n.prev || 'Pagina precedente') + '">&#8249;</button>' +
                '<div class="dnd-reader__stage"><p class="dnd-reader__msg"></p></div>' +
                '<button type="button" class="dnd-reader__nav dnd-reader__nav--next" aria-label="' + (i18n.next || 'Pagina successiva') + '">&#8250;</button>' +
            '</div>' +
            '<div class="dnd-reader__foot"><span class="dnd-reader__count"></span></div>';
        document.body.appendChild(modal);
        stage = modal.querySelector('.dnd-reader__stage');
        modal.querySelector('.dnd-reader__close').addEventListener('click', close);
        modal.querySelector('.dnd-reader__nav--prev').addEventListener('click', function () { if (flip) { flip.flipPrev(); } });
        modal.querySelector('.dnd-reader__nav--next').addEventListener('click', function () { if (flip) { flip.flipNext(); } });
        modal.addEventListener('click', function (e) { if (e.target === modal) { close(); } });
        document.addEventListener('keydown', function (e) {
            if (modal.hidden) { return; }
            if (e.key === 'Escape') { close(); }
            if (e.key === 'ArrowRight' && flip) { flip.flipNext(); }
            if (e.key === 'ArrowLeft' && flip) { flip.flipPrev(); }
        });
    }

    function message(text) {
        stage.innerHTML = '';
        stage.appendChild(el('p', 'dnd-reader__msg')).textContent = text;
    }

    function open(url, title, cover) {
        build();
        lastFocus = document.activeElement;
        modal.querySelector('.dnd-reader__title').textContent = title || '';
        var dl = modal.querySelector('.dnd-reader__dl');
        dl.href = url; dl.textContent = i18n.download || 'Scarica il PDF';
        modal.querySelector('.dnd-reader__count').textContent = '';
        modal.hidden = false;
        document.documentElement.classList.add('dnd-reader-open');
        modal.querySelector('.dnd-reader__close').focus();
        // Subito qualcosa da guardare: la copertina, mentre il PDF si prepara.
        stage.innerHTML = '';
        stage.style.width = ''; stage.style.height = '';
        var wait = el('div', 'dnd-reader__loading');
        if (cover) { var img = el('img', 'dnd-reader__cover'); img.src = cover; img.alt = ''; wait.appendChild(img); }
        wait.appendChild(el('span', 'dnd-reader__spinner'));
        var msg = el('p', 'dnd-reader__msg'); msg.textContent = i18n.loading || 'Caricamento…'; wait.appendChild(msg);
        stage.appendChild(wait);
        coverSrc = cover || '';
        var my = ++token;
        loadDoc(url).then(function (d) { if (my === token && !modal.hidden) { return start(d); } })
            .catch(function () { if (my === token) { message(i18n.error || 'Non riesco ad aprire l’opuscolo: scaricalo in PDF.'); } });
    }

    function close() {
        if (!modal || modal.hidden) { return; }
        modal.hidden = true;
        document.documentElement.classList.remove('dnd-reader-open');
        if (flip) { try { flip.destroy(); } catch (e) { /* già distrutto */ } flip = null; }
        pdf = null; queue = []; token++;
        rendered = {};
        stage.innerHTML = '';
        if (lastFocus && lastFocus.focus) { lastFocus.focus(); }
    }

    function renderPage(n) {
        if (!pdf || rendered[n]) { return; }
        rendered[n] = 'queued';
        queue.push(n);
        pump();
    }

    // Le pagine si disegnano due alla volta, le più vicine a quella aperta per prime.
    function pump() {
        while (busy < 2 && queue.length) {
            queue.sort(function (a, b) { return Math.abs(a - current) - Math.abs(b - current); });
            drawPage(queue.shift());
        }
    }

    function drawPage(n) {
        var doc = pdf, my = token;
        busy++;
        doc.getPage(n + 1).then(function (page) {
            var holder = stage.querySelector('[data-page="' + n + '"]');
            if (!holder || my !== token) { rendered[n] = false; return; }
            var base = page.getViewport({ scale: 1 });
            var single = stage.clientWidth <= 700;
            var cssW = single ? stage.clientWidth : stage.clientWidth / 2;
            var vp = page.getViewport({ scale: (Math.min(cssW, 800) * Math.min(window.devicePixelRatio || 1, 1.5)) / base.width });
            var canvas = document.createElement('canvas');
            canvas.width = Math.floor(vp.width); canvas.height = Math.floor(vp.height);
            return page.render({ canvasContext: canvas.getContext('2d'), viewport: vp }).promise.then(function () {
                if (my !== token) { return; }
                holder.innerHTML = '';
                holder.appendChild(canvas);
                rendered[n] = true;
            });
        }).catch(function () { rendered[n] = false; }).then(function () { busy--; pump(); });
    }

    function around(index) {
        for (var i = Math.max(0, index - 1); i <= Math.min(pdf.numPages - 1, index + 4); i++) { renderPage(i); }
        // Libera la memoria delle pagine lontane.
        Object.keys(rendered).forEach(function (k) {
            if (rendered[k] === true && Math.abs(k - index) > 6) {
                var h = stage.querySelector('[data-page="' + k + '"]');
                if (h) { h.innerHTML = ''; }
                delete rendered[k];
            }
        });
    }

    function start(doc) {
        pdf = doc;
        return doc.getPage(1).then(function (p1) {
            var v = p1.getViewport({ scale: 1 });
            ratio = v.height / v.width;
            stage.innerHTML = '';
            var body = modal.querySelector('.dnd-reader__body');
            var availH = Math.max(280, body.clientHeight - 24), availW = Math.max(260, body.clientWidth - 24);
            var single = availW < 700;
            var w = Math.min(availW, single ? availH / ratio : (availH / ratio) * 2);
            stage.style.width = Math.floor(w) + 'px';
            stage.style.height = Math.floor(single ? w * ratio : (w / 2) * ratio) + 'px';
            var pages = [];
            for (var i = 0; i < doc.numPages; i++) {
                var d = el('div', 'dnd-reader__page');
                d.setAttribute('data-page', i);
                if (i === 0 && coverSrc) { var ci = el('img', 'dnd-reader__page-cover'); ci.src = coverSrc; ci.alt = ''; d.appendChild(ci); }
                stage.appendChild(d);
                pages.push(d);
            }
            flip = new window.St.PageFlip(stage, {
                width: 400, height: Math.round(400 * ratio), size: 'stretch',
                minWidth: 220, maxWidth: 1000, minHeight: 280, maxHeight: 1500,
                showCover: true, usePortrait: true, mobileScrollSupport: false, maxShadowOpacity: .35, flippingTime: 700
            });
            flip.loadFromHTML(pages);
            var count = modal.querySelector('.dnd-reader__count');
            function label(idx) {
                var total = doc.numPages;
                var shown = (flip.getOrientation && flip.getOrientation() === 'landscape' && idx > 0 && idx < total - 1) ? (idx + 1) + '–' + Math.min(idx + 2, total) : String(idx + 1);
                count.textContent = (i18n.page || 'Pagina') + ' ' + shown + ' / ' + total;
            }
            flip.on('flip', function (e) { current = e.data; around(current); label(current); });
            around(0); label(0);
        });
    }

    function coverOf(btn) {
        var card = btn.closest('.dnd-booklet');
        var img = card ? card.querySelector('.dnd-booklet__cover img') : null;
        return img ? (img.currentSrc || img.src) : '';
    }

    document.addEventListener('click', function (e) {
        var b = e.target.closest ? e.target.closest('[data-dnd-read]') : null;
        if (!b) { return; }
        e.preventDefault();
        open(b.getAttribute('data-dnd-read'), b.getAttribute('data-title'), coverOf(b));
    });

    // Chi sta per toccare «Sfoglia online» trova già pronte le librerie e l'inizio del PDF.
    function warm(e) {
        var b = e.target.closest ? e.target.closest('[data-dnd-read]') : null;
        if (b) { loadDoc(b.getAttribute('data-dnd-read')).catch(function () {}); }
    }
    document.addEventListener('pointerover', warm, { passive: true });
    document.addEventListener('touchstart', warm, { passive: true });
    document.addEventListener('focusin', warm);
    // Le librerie (circa 400 KB compressi) si scaricano a pagina ferma, così sono già in cache al primo clic.
    (window.requestIdleCallback || function (f) { setTimeout(f, 3000); })(function () { libs().catch(function () {}); }, { timeout: 6000 });
})();
