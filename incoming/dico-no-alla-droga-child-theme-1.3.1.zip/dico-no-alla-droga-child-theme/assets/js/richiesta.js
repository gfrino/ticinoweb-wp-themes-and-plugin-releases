/* Modulo «Richiedi materiale / conferenziere»: a fasi, con invio AJAX al gestore del parent. */
(function () {
    'use strict';
    var cfg = window.dndRichiesta || {};
    var form = document.querySelector('[data-dnd-form]');
    if (!form || !cfg.ajax_url) { return; }

    var i18n = cfg.i18n || {};
    var msg = cfg.msg || {};
    var notice = form.querySelector('.dnd-notice');
    var panels = form.querySelectorAll('[data-dnd-when]');
    var submitBox = form.querySelector('.dnd-form__submit');
    var idx = 0;
    var ui = {};

    function checkedTypes() {
        var out = [];
        Array.prototype.forEach.call(form.querySelectorAll('input[name="tipo[]"]:checked'), function (i) { out.push(i.value); });
        return out;
    }

    function allSteps() { return Array.prototype.slice.call(form.querySelectorAll('.dnd-fieldset')); }
    function activeSteps() { return allSteps().filter(function (fs) { return !fs.hidden; }); }

    function syncPanels() {
        var types = checkedTypes();
        Array.prototype.forEach.call(panels, function (p) {
            p.hidden = !p.getAttribute('data-dnd-when').split(' ').some(function (w) { return types.indexOf(w) !== -1; });
        });
    }

    function legendText(fs) {
        var l = fs.querySelector('legend');
        if (!l) { return ''; }
        var c = l.cloneNode(true);
        var n = c.querySelector('.dnd-step');
        if (n) { n.remove(); }
        return c.textContent.trim();
    }

    // ---------- Barra di avanzamento e pulsanti ----------
    function buildUi() {
        var bar = document.createElement('div');
        bar.className = 'dnd-progress';
        bar.innerHTML = '<div class="dnd-progress__meta"><span class="dnd-progress__label"></span><span class="dnd-progress__title"></span></div>' +
            '<div class="dnd-progress__track"><span class="dnd-progress__fill"></span></div><ol class="dnd-progress__steps"></ol>';
        form.insertBefore(bar, form.firstChild);
        var nav = document.createElement('div');
        nav.className = 'dnd-wizard__nav';
        nav.innerHTML = '<button type="button" class="dnd-btn dnd-btn--ghost dnd-wizard__back"></button><button type="button" class="dnd-btn dnd-btn--sun dnd-wizard__next"></button>';
        form.insertBefore(nav, submitBox);
        ui.bar = bar; ui.nav = nav;
        ui.label = bar.querySelector('.dnd-progress__label');
        ui.title = bar.querySelector('.dnd-progress__title');
        ui.fill = bar.querySelector('.dnd-progress__fill');
        ui.list = bar.querySelector('.dnd-progress__steps');
        ui.back = nav.querySelector('.dnd-wizard__back');
        ui.next = nav.querySelector('.dnd-wizard__next');
        ui.back.textContent = '‹ ' + (i18n.back || 'Indietro');
        ui.next.textContent = (i18n.next || 'Avanti') + ' ›';
        ui.back.addEventListener('click', function () { go(idx - 1); });
        ui.next.addEventListener('click', function () { advance(); });
        form.classList.add('is-wizard');
    }

    function render(focus) {
        var steps = activeSteps();
        if (idx >= steps.length) { idx = steps.length - 1; }
        if (idx < 0) { idx = 0; }
        allSteps().forEach(function (fs) { fs.classList.remove('is-current'); });
        steps.forEach(function (fs, i) {
            var n = fs.querySelector('.dnd-step:not(.dnd-step--icon)');
            if (n) { n.textContent = String(i + 1); }
        });
        var cur = steps[idx];
        cur.classList.add('is-current');
        var last = idx === steps.length - 1;
        ui.label.textContent = (i18n.step || 'Passo') + ' ' + (idx + 1) + ' ' + (i18n.of || 'di') + ' ' + steps.length;
        ui.title.textContent = legendText(cur);
        ui.fill.style.width = Math.round(((idx + 1) / steps.length) * 100) + '%';
        ui.list.innerHTML = '';
        steps.forEach(function (fs, i) {
            var li = document.createElement('li');
            li.className = i < idx ? 'is-done' : (i === idx ? 'is-current' : '');
            var icon = fs.querySelector('.dnd-step--icon');
            li.innerHTML = '<span class="dnd-progress__dot">' + (i < idx ? '✓' : (icon ? icon.innerHTML : (i + 1))) + '</span><span class="dnd-progress__name"></span>';
            li.querySelector('.dnd-progress__name').textContent = legendText(fs);
            if (i < idx) { li.tabIndex = 0; li.setAttribute('role', 'button'); li.addEventListener('click', function () { go(i); }); li.addEventListener('keydown', function (e) { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); go(i); } }); }
            ui.list.appendChild(li);
        });
        ui.back.hidden = idx === 0;
        ui.next.hidden = last;
        submitBox.hidden = !last;
        if (last) { buildRecap(); }
        if (focus) {
            var f = cur.querySelector('input:not([type=hidden]):not([type=checkbox]):not([type=radio]), select, textarea');
            if (f && !cur.querySelector('.dnd-choice-cards, .dnd-booklet-picker')) { try { f.focus({ preventScroll: true }); } catch (e) { f.focus(); } }
        }
    }

    function topOfForm() {
        var y = form.getBoundingClientRect().top + window.pageYOffset - 100;
        window.scrollTo({ top: Math.max(0, y), behavior: 'smooth' });
    }

    function go(i, keepScroll) {
        idx = i;
        clearErrors();
        render(true);
        if (!keepScroll) { topOfForm(); }
    }

    // ---------- Controllo dei campi di una fase ----------
    function field(fs, name) { return fs.querySelector('[name="' + name + '"]'); }
    function text(fs, name) { var f = field(fs, name); return f ? String(f.value || '').trim() : null; }
    function checked(fs, name) { var f = field(fs, name); return f ? f.checked : null; }

    function validateStep(fs) {
        var err = {};
        var t;
        if (fs.querySelector('input[name="tipo[]"]') && !checkedTypes().length) { err.tipo = msg.tipo; }
        ['ente_nome', 'nome', 'indirizzo', 'cap', 'localita', 'luogo'].forEach(function (n) { t = text(fs, n); if (t !== null && t === '') { err[n] = msg[n]; } });
        t = text(fs, 'email');
        if (t !== null && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(t)) { err.email = msg.email; }
        if (fs.querySelector('input[name="opuscoli[]"]') && !fs.querySelector('input[name="opuscoli[]"]:checked')) { err.opuscoli = msg.opuscoli; }
        ['copie', 'partecipanti'].forEach(function (n) { t = text(fs, n); if (t !== null && !(parseInt(t, 10) >= 1)) { err[n] = msg[n]; } });
        t = text(fs, 'uso');
        if (t !== null && t.length < 20) { err.uso = msg.uso; }
        ['impegno_uso', 'impegno_resoconto', 'privacy'].forEach(function (n) { if (checked(fs, n) === false) { err[n] = msg[n]; } });
        return err;
    }

    function advance() {
        var steps = activeSteps();
        var err = validateStep(steps[idx]);
        if (Object.keys(err).length) {
            clearErrors();
            showErrors(err, true);
            return;
        }
        go(idx + 1);
    }

    // ---------- Riepilogo nell'ultima fase ----------
    function buildRecap() {
        var box = form.querySelector('[data-dnd-recap]');
        if (!box) { return; }
        var steps = activeSteps();
        var rows = [];
        function stepOf(name) {
            for (var i = 0; i < steps.length; i++) { if (field(steps[i], name)) { return i; } }
            return 0;
        }
        var cards = [];
        Array.prototype.forEach.call(form.querySelectorAll('input[name="tipo[]"]:checked'), function (c) {
            var s = c.parentNode.querySelector('strong'); if (s) { cards.push(s.textContent); }
        });
        rows.push(['Cosa', cards.join(', '), stepOf('tipo[]')]);
        var ente = text(form, 'ente_nome');
        rows.push(['Chi', [ente, text(form, 'nome'), text(form, 'email')].filter(Boolean).join(' · '), stepOf('ente_nome')]);
        var bk = [];
        Array.prototype.forEach.call(form.querySelectorAll('input[name="opuscoli[]"]:checked'), function (c) {
            var em = c.parentNode.querySelector('em'); if (em) { bk.push(em.textContent); }
        });
        var copies = text(form, 'copie');
        if (!form.querySelector('[data-dnd-when~="materiale"]').hidden && bk.length) { rows.push(['Opuscoli', bk.join(', ') + (copies ? ' — ' + copies + ' copie ciascuno' : ''), stepOf('opuscoli[]')]); }
        if (!form.querySelector('[data-dnd-when~="kit"]').hidden && text(form, 'indirizzo')) { rows.push(['Spedizione', [text(form, 'indirizzo'), text(form, 'cap') + ' ' + text(form, 'localita')].join(', '), stepOf('indirizzo')]); }
        var luogo = text(form, 'luogo');
        var conf = form.querySelector('[data-dnd-when="conferenziere"]');
        if (conf && !conf.hidden && luogo) { rows.push(['Conferenza', [luogo, text(form, 'data_conf'), text(form, 'partecipanti') + ' persone'].filter(function (x) { return x && x.trim() !== 'persone'; }).join(' · '), stepOf('luogo')]); }
        var html = '<h3>' + (i18n.recap || 'Riepilogo') + '</h3><dl>';
        rows.forEach(function (r) {
            html += '<div><dt></dt><dd></dd><button type="button" class="dnd-recap__edit"></button></div>';
        });
        html += '</dl>';
        box.innerHTML = html;
        var divs = box.querySelectorAll('dl > div');
        rows.forEach(function (r, i) {
            divs[i].querySelector('dt').textContent = r[0];
            divs[i].querySelector('dd').textContent = r[1];
            var b = divs[i].querySelector('button');
            b.textContent = i18n.edit || 'Modifica';
            b.addEventListener('click', function () { go(r[2]); });
        });
    }

    // ---------- Errori ----------
    function clearErrors() {
        Array.prototype.forEach.call(form.querySelectorAll('.dnd-error'), function (e) { e.textContent = ''; });
        Array.prototype.forEach.call(form.querySelectorAll('[aria-invalid]'), function (e) { e.removeAttribute('aria-invalid'); });
    }

    function showErrors(map, stay) {
        var first = null, firstName = null;
        Object.keys(map || {}).forEach(function (name) {
            var slot = form.querySelector('[data-error-for="' + name + '"]');
            if (slot) { slot.textContent = map[name]; }
            var f = form.querySelector('[name="' + name + '"]');
            if (f) { f.setAttribute('aria-invalid', 'true'); }
            if (!first) { first = slot || f; firstName = name; }
        });
        if (first && !stay) {
            // Un errore del server può riguardare una fase già superata: ci torniamo.
            var steps = activeSteps();
            for (var i = 0; i < steps.length; i++) { if (steps[i].contains(first)) { idx = i; break; } }
            render(false);
        }
        if (first && first.scrollIntoView) { first.scrollIntoView({ behavior: 'smooth', block: 'center' }); }
        ui.nav && ui.nav.classList.add('is-shake');
        setTimeout(function () { ui.nav && ui.nav.classList.remove('is-shake'); }, 500);
    }

    function say(text, ok) {
        notice.hidden = false;
        notice.className = 'dnd-notice ' + (ok ? 'is-ok' : 'is-error');
        notice.textContent = text;
        if (notice.scrollIntoView) { notice.scrollIntoView({ behavior: 'smooth', block: 'center' }); }
    }

    // ---------- Fine: schermata di ringraziamento ----------
    function done(message) {
        var m = /DND-[A-Z0-9]{5}/.exec(message || '');
        var code = m ? m[0] : '';
        form.classList.add('is-done');
        var box = document.createElement('div');
        box.className = 'dnd-done';
        box.setAttribute('role', 'status');
        box.innerHTML = '<span class="dnd-done__check" aria-hidden="true"></span><h3></h3><p class="dnd-done__msg"></p>' +
            (code ? '<div class="dnd-done__code"><small></small><strong></strong></div>' : '') +
            '<ol class="dnd-done__next"><li></li><li></li><li></li></ol><div class="dnd-done__actions"></div>';
        box.querySelector('h3').textContent = i18n.doneTitle || 'Richiesta inviata!';
        box.querySelector('.dnd-done__msg').textContent = (message || '').replace(/\s*Il tuo codice richiesta è DND-[A-Z0-9]{5}:[^.]*\./, '').trim();
        if (code) { box.querySelector('.dnd-done__code small').textContent = i18n.code || 'Il tuo codice richiesta'; box.querySelector('.dnd-done__code strong').textContent = code; }
        var li = box.querySelectorAll('.dnd-done__next li');
        li[0].textContent = i18n.next1; li[1].textContent = i18n.next2; li[2].textContent = i18n.next3;
        var actions = box.querySelector('.dnd-done__actions');
        if (cfg.resoconto_url) {
            var a = document.createElement('a'); a.className = 'dnd-btn dnd-btn--sun'; a.href = cfg.resoconto_url; a.textContent = i18n.sendReport; actions.appendChild(a);
        }
        var h = document.createElement('a'); h.className = 'dnd-btn dnd-btn--ghost'; h.href = cfg.home_url || '/'; h.textContent = i18n.toHome; actions.appendChild(h);
        form.appendChild(box);
        topOfForm();
    }

    function getToken() {
        return fetch(cfg.ajax_url + '?action=' + encodeURIComponent(cfg.token_action), { credentials: 'same-origin', cache: 'no-store' })
            .then(function (r) { return r.json(); })
            .then(function (j) { return j && j.success && j.data ? j.data.token : ''; });
    }

    function recaptcha() {
        if (!cfg.recaptcha_site_key || !window.grecaptcha) { return Promise.resolve(''); }
        return new Promise(function (resolve) {
            window.grecaptcha.ready(function () {
                window.grecaptcha.execute(cfg.recaptcha_site_key, { action: 'richiesta' }).then(resolve, function () { resolve(''); });
            });
        });
    }

    form.addEventListener('change', function (e) {
        if (e.target && e.target.name === 'tipo[]') {
            var cur = activeSteps()[idx];
            syncPanels();
            var steps = activeSteps();
            var at = steps.indexOf(cur);
            idx = at >= 0 ? at : 0;
            render(false);
        }
    });

    // Invio sulla tastiera = avanti, non invio del modulo (tranne all'ultima fase).
    form.addEventListener('keydown', function (e) {
        if (e.key !== 'Enter' || !e.target || e.target.tagName === 'TEXTAREA' || e.target.tagName === 'BUTTON' || e.target.type === 'checkbox') { return; }
        if (idx < activeSteps().length - 1) { e.preventDefault(); advance(); }
    });

    syncPanels();
    buildUi();
    render(false);

    // «Richiedi copie» dagli opuscoli: ?opuscolo=ID preseleziona il materiale e quell'opuscolo.
    (function preselect() {
        var m = /[?&]opuscolo=(\d+)/.exec(window.location.search);
        if (m) { selectBooklet(m[1], true); }
    })();

    function selectBooklet(id, quiet) {
        var box = form.querySelector('input[name="opuscoli[]"][value="' + id + '"]');
        var type = form.querySelector('input[name="tipo[]"][value="materiale"]');
        if (type) { type.checked = true; }
        if (box) { box.checked = true; }
        syncPanels();
        if (box) {
            // Si parte dalla scelta degli opuscoli, già fatta: si prosegue dai dati di chi richiede.
            idx = 0;
        }
        render(false);
        if (quiet) { return; }
    }

    document.addEventListener('click', function (e) {
        var a = e.target.closest ? e.target.closest('[data-dnd-add]') : null;
        if (!a) { return; }
        var target = document.getElementById('dnd-richiesta-form');
        if (!target) { return; }
        e.preventDefault();
        selectBooklet(a.getAttribute('data-dnd-add'));
        target.scrollIntoView({ behavior: 'smooth', block: 'start' });
    });

    form.addEventListener('submit', function (e) {
        e.preventDefault();
        var steps = activeSteps();
        if (idx < steps.length - 1) { advance(); return; }
        // Prima di inviare si ricontrollano tutte le fasi.
        for (var i = 0; i < steps.length; i++) {
            var err = validateStep(steps[i]);
            if (Object.keys(err).length) { idx = i; render(false); clearErrors(); showErrors(err, true); return; }
        }
        clearErrors();
        notice.hidden = true;

        var btn = form.querySelector('[type="submit"]');
        var label = btn.textContent;
        btn.disabled = true;
        btn.textContent = i18n.sending;

        Promise.all([getToken(), recaptcha()]).then(function (res) {
            var fd = new FormData(form);
            fd.append('action', cfg.submit_action);
            fd.append('token', res[0]);
            if (res[1]) { fd.append('recaptcha_token', res[1]); }
            // I campi dei pannelli nascosti non vengono inviati.
            Array.prototype.forEach.call(panels, function (p) {
                if (p.hidden) {
                    Array.prototype.forEach.call(p.querySelectorAll('input,select,textarea'), function (i) { fd.delete(i.name); });
                }
            });
            return fetch(cfg.ajax_url, { method: 'POST', body: fd, credentials: 'same-origin' });
        }).then(function (r) { return r.json(); }).then(function (j) {
            if (j && j.success) {
                form.reset();
                syncPanels();
                done(j.data.message);
            } else {
                var d = (j && j.data) || {};
                if (d.fields) { showErrors(d.fields); }
                say(d.message || i18n.error, false);
            }
        }).catch(function () {
            say(i18n.error, false);
        }).then(function () {
            btn.disabled = false;
            btn.textContent = label;
        });
    });
})();
