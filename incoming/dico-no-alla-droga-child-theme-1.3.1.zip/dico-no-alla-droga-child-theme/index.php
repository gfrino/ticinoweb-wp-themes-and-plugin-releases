<?php
/**
 * Riserva: qualsiasi altra richiesta (ricerca, archivi) usa il modello pagina.
 */
get_header();
?>
<header class="dnd-pagehead"><div class="dnd-wrap"><h1><?php echo esc_html(is_search() ? sprintf(__('Risultati per «%s»', 'dico-no-alla-droga-child-theme'), get_search_query()) : get_the_archive_title()); ?></h1></div></header>
<div class="dnd-content dnd-content--page"><div class="dnd-wrap dnd-prose">
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
    <article><h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2><?php the_excerpt(); ?></article>
<?php endwhile; else : ?>
    <p><?php esc_html_e('Nessun contenuto trovato.', 'dico-no-alla-droga-child-theme'); ?></p>
<?php endif; ?>
</div></div>
<?php get_footer();
