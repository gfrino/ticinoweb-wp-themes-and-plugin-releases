<?php
/**
 * Pagina iniziale 0.3 «Insegna rosa antico» (regole in Kyle AI Dev/tools/fashionshoes/ANTI-SLOP.md):
 * la parola-insegna (il nome del negozio) alta quanto la pagina, il titolo con le informazioni e i due post più recenti
 * · collezioni come righe di testo (Servizi del CMS) · il negozio (Chi siamo e due foto) · Instagram su fondo marrone
 * · orari e contatti con lo stato «aperto ora» e il modulo · domande (scheda FAQ della pagina). Ogni testo e foto viene
 * dal database: senza contenuto la sezione non compare.
 *
 * @package fashionshoes-child-theme
 */

defined('ABSPATH') || exit;

get_header();

$fs_contacts   = fashionshoes_contacts();
$fs_title      = fashionshoes_text('hero_title');
$fs_title      = $fs_title !== '' ? $fs_title : get_bloginfo('name');
$fs_hero_img   = fashionshoes_image_id(fashionshoes_setting('hero_image', 0));
$fs_map        = fashionshoes_map_url();
$fs_services   = fashionshoes_services();
$fs_instagram  = fashionshoes_gallery_images((string) fashionshoes_setting('instagram_gallery', ''), 6);
$fs_shop       = fashionshoes_gallery_images((string) fashionshoes_setting('shop_gallery', ''), 3);
$fs_galleria   = fashionshoes_gallery_images((string) fashionshoes_setting('gallery_gallery', ''), 48);
$fs_about_t    = trim((string) get_option('ticinoweb_chi_siamo_title', ''));
$fs_about_text = trim((string) get_option('ticinoweb_chi_siamo_text', ''));
$fs_hours      = fashionshoes_hours();
$fs_note       = fashionshoes_hours_note();
$fs_door       = fashionshoes_image_id(fashionshoes_setting('contact_image', 0));
$fs_word       = trim((string) preg_replace('/\s+Locarno$/iu', '', get_bloginfo('name'))); // la parola-insegna: il nome senza la città
$fs_hero_img2  = fashionshoes_image_id(fashionshoes_setting('hero_image_2', 0));
// Le due foto accanto al titolo: quelle scelte in Personalizza, altrimenti i due post Instagram più recenti.
$fs_coppia     = ($fs_hero_img && $fs_hero_img2) ? array($fs_hero_img, $fs_hero_img2) : array();
// Senza foto scelte per la testata: la vetrina del negozio, con la tinta del sito (niente più post Instagram, troppo piccoli per stare qui).
$fs_vetrina    = (!$fs_coppia && !$fs_hero_img && $fs_door) ? $fs_door : 0;
$fs_orari_json = wp_json_encode(get_option('ticinoweb_contact_opening_hours', array()));

// Domande: la scheda FAQ scelta nel box «FAQ della pagina» della pagina iniziale (Bacheca → FAQ).
$fs_faq     = null;
$fs_faq_ref = get_post_meta((int) get_option('page_on_front'), '_tw_faq_page_set', true);
if ($fs_faq_ref && function_exists('ticinoweb_faq_get_set')) {
    $fs_faq = ticinoweb_faq_get_set($fs_faq_ref);
    if ($fs_faq && !empty($fs_faq['items']) && function_exists('ticinoweb_faq_schema_add')) {
        ticinoweb_faq_schema_add($fs_faq['items']);
    }
}

/** Un paragrafo per ogni blocco separato da una riga vuota. */
$fs_paragraphs = function ($text) {
    $out = '';
    foreach (preg_split('/\R\s*\R/', trim((string) $text)) as $p) {
        if (trim($p) !== '') {
            $out .= '<p>' . nl2br(esc_html(trim($p))) . '</p>';
        }
    }
    return $out;
};

/** Stato del negozio: lo scrive lo script dagli orari (data-fs-orari); i testi qui, traducibili. */
$fs_stato = function () use ($fs_orari_json) {
    printf(
        '<span class="fs-stato" data-fs-orari="%s" data-aperto="%s" data-chiuso="%s" data-riapre="%s" data-oggi="%s" data-domani="%s" data-giorni="%s" role="status"></span>',
        esc_attr((string) $fs_orari_json),
        esc_attr(fashionshoes_t(__('Aperto ora · fino alle %s', 'fashionshoes-child-theme'), 'stato:aperto')),
        esc_attr(fashionshoes_t(__('Chiuso', 'fashionshoes-child-theme'), 'stato:chiuso')),
        esc_attr(fashionshoes_t(__('Chiuso · riapre %1$s alle %2$s', 'fashionshoes-child-theme'), 'stato:riapre')),
        esc_attr(fashionshoes_t(__('oggi', 'fashionshoes-child-theme'), 'stato:oggi')),
        esc_attr(fashionshoes_t(__('domani', 'fashionshoes-child-theme'), 'stato:domani')),
        esc_attr(fashionshoes_t(__('domenica,lunedì,martedì,mercoledì,giovedì,venerdì,sabato', 'fashionshoes-child-theme'), 'stato:giorni'))
    );
};
?>
<main id="fs-main">

    <section class="fs-hero" aria-labelledby="fs-h-hero">
        <div class="fs-contenitore">
            <?php // Il logo grande: scrollando vola in alto a sinistra e diventa quello della testata (assets/js/movimento.js). Senza JS resta qui. ?>
            <?php // Filtro della sfocatura di movimento del logo: una scia di copie spostate nella direzione del moto (le misure le imposta movimento.js, secondo velocità e direzione; la scia è centrata sul logo). ?>
            <svg width="0" height="0" style="position:absolute" aria-hidden="true" focusable="false"><filter id="fs-sfoca" x="-40%" y="-100%" width="180%" height="300%" color-interpolation-filters="sRGB"><feOffset in="SourceGraphic" dx="0" dy="0" result="o1"/><feComponentTransfer in="o1" result="a1"><feFuncA type="linear" slope="0.12"/></feComponentTransfer><feOffset in="SourceGraphic" dx="0" dy="0" result="o2"/><feComponentTransfer in="o2" result="a2"><feFuncA type="linear" slope="0.12"/></feComponentTransfer><feOffset in="SourceGraphic" dx="0" dy="0" result="o3"/><feComponentTransfer in="o3" result="a3"><feFuncA type="linear" slope="0.12"/></feComponentTransfer><feOffset in="SourceGraphic" dx="0" dy="0" result="o4"/><feComponentTransfer in="o4" result="a4"><feFuncA type="linear" slope="0.12"/></feComponentTransfer><feOffset in="SourceGraphic" dx="0" dy="0" result="o5"/><feComponentTransfer in="o5" result="a5"><feFuncA type="linear" slope="0.12"/></feComponentTransfer><feOffset in="SourceGraphic" dx="0" dy="0" result="o6"/><feComponentTransfer in="o6" result="a6"><feFuncA type="linear" slope="0.12"/></feComponentTransfer><feOffset in="SourceGraphic" dx="0" dy="0" result="o7"/><feComponentTransfer in="o7" result="a7"><feFuncA type="linear" slope="0.12"/></feComponentTransfer><feOffset in="SourceGraphic" dx="0" dy="0" result="o8"/><feComponentTransfer in="o8" result="a8"><feFuncA type="linear" slope="0.12"/></feComponentTransfer><feOffset in="SourceGraphic" dx="0" dy="0" result="o9"/><feComponentTransfer in="o9" result="a9"><feFuncA type="linear" slope="0.12"/></feComponentTransfer><feOffset in="SourceGraphic" dx="0" dy="0" result="o10"/><feComponentTransfer in="o10" result="a10"><feFuncA type="linear" slope="0.12"/></feComponentTransfer><feMerge result="coda"><feMergeNode in="a10"/><feMergeNode in="a9"/><feMergeNode in="a8"/><feMergeNode in="a7"/><feMergeNode in="a6"/><feMergeNode in="a5"/><feMergeNode in="a4"/><feMergeNode in="a3"/><feMergeNode in="a2"/><feMergeNode in="a1"/></feMerge><feGaussianBlur in="coda" stdDeviation="1.2" result="cs"/><feComponentTransfer in="SourceGraphic" result="fonte"><feFuncA type="linear" slope="0.45"/></feComponentTransfer><feMerge result="mosso"><feMergeNode in="cs"/><feMergeNode in="fonte"/></feMerge><feComposite id="fs-mix" in="SourceGraphic" in2="mosso" operator="arithmetic" k1="0" k2="1" k3="0" k4="0"/></filter></svg>
            <div class="fs-logo-posto" data-fs-logo-posto>
                <a class="fs-logo-grande" href="<?php echo esc_url(fashionshoes_url(home_url('/'), 'url:home')); ?>" rel="home" data-fs-logo><img src="<?php echo esc_url(FASHIONSHOES_URI . '/assets/img/logo-marrone.svg'); ?>" alt="<?php echo esc_attr(get_bloginfo('name')); ?>" width="2768" height="385" fetchpriority="high" decoding="async"></a>
            </div>
            <div class="fs-hero__corpo">
                <h1 class="fs-hero__titolo fs-titolo" id="fs-h-hero" data-fs-su><?php echo esc_html($fs_title); ?></h1>
                <div class="fs-hero__lato" data-fs-su>
                    <?php $fs_stato(); ?>
                    <?php if (fashionshoes_text('hero_text') !== '') : ?><p class="fs-hero__sotto"><?php echo esc_html(fashionshoes_text('hero_text')); ?></p><?php endif; ?>
                    <?php if (fashionshoes_text('hero_text') === '' && fashionshoes_address_line() !== '') : ?><p class="fs-hero__info"><?php echo fashionshoes_icona('posizione'); // phpcs:ignore WordPress.Security.EscapeOutput -- SVG del tema ?><?php echo esc_html(fashionshoes_address_line()); ?></p><?php endif; ?>
                    <div class="fs-azioni">
                        <?php if ($fs_map !== '') : ?><a class="fs-bottone fs-bottone--pieno" href="<?php echo esc_url($fs_map); ?>" target="_blank" rel="noopener"><?php esc_html_e('Come arrivare', 'fashionshoes-child-theme'); ?><?php echo fashionshoes_icona('freccia'); // phpcs:ignore WordPress.Security.EscapeOutput ?></a><?php endif; ?>
                        <?php if ($fs_contacts['phone'] !== '') : ?><a class="fs-bottone fs-bottone--linea" href="<?php echo esc_attr(fashionshoes_tel($fs_contacts['phone'])); ?>"><?php echo esc_html($fs_contacts['phone_display']); ?></a><?php endif; ?>
                    </div>
                </div>
            </div>
            <?php if ($fs_coppia) : ?>
                <div class="fs-coppia">
                    <?php foreach ($fs_coppia as $fs_id) : ?>
                        <figure class="fs-foto"><?php echo fashionshoes_image($fs_id, 'large', array('loading' => 'eager', 'fetchpriority' => 'high', 'sizes' => '(min-width: 900px) 40vw, 60vw')); // phpcs:ignore WordPress.Security.EscapeOutput ?></figure>
                    <?php endforeach; ?>
                </div>
            <?php elseif ($fs_vetrina) : ?>
                <div class="fs-coppia fs-coppia--sola">
                    <figure class="fs-foto fs-foto--tinta" style="--fs-fuoco:70% 50%"><?php echo fashionshoes_image($fs_vetrina, 'full', array('loading' => 'eager', 'fetchpriority' => 'high', 'sizes' => '100vw')); // phpcs:ignore WordPress.Security.EscapeOutput ?></figure>
                </div>
            <?php elseif ($fs_hero_img) : ?>
                <div class="fs-coppia fs-coppia--sola">
                    <figure class="fs-foto fs-foto--tinta" style="--fs-fuoco:50% 78%"><?php echo fashionshoes_image($fs_hero_img, 'full', array('loading' => 'eager', 'fetchpriority' => 'high', 'sizes' => '100vw')); // phpcs:ignore WordPress.Security.EscapeOutput ?></figure>
                </div>
            <?php endif; ?>
        </div>
    </section>

    <?php if ($fs_services) : ?>
        <section class="fs-collezioni" id="collezioni" aria-labelledby="fs-h-collezioni">
            <div class="fs-contenitore">
                <h2 class="fs-etichetta" id="fs-h-collezioni"><?php echo esc_html(fashionshoes_text('collections_title') !== '' ? fashionshoes_text('collections_title') : __('Collezioni', 'fashionshoes-child-theme')); ?></h2>
                <?php if (fashionshoes_text('collections_text') !== '') : ?><p class="fs-collezioni__testo"><?php echo esc_html(fashionshoes_text('collections_text')); ?></p><?php endif; ?>
                <div class="fs-righe">
                    <?php foreach ($fs_services as $fs_s) :
                        $fs_sid  = (string) ($fs_s['id'] ?? '');
                        $fs_img  = fashionshoes_image_id((string) ($fs_s['image'] ?? ''));
                        $fs_desc = trim((string) ($fs_s['description'] ?? ''));
                        $fs_name = fashionshoes_t($fs_s['title'], 'service:' . $fs_sid . ':title');
                        ?>
                        <?php
                        $fs_slug = sanitize_title((string) ($fs_s['title'] ?? ''));
                        // Senza foto: i saldi hanno il cartellino con il %, le altre voci la loro icona se esiste.
                        $fs_icona = !$fs_img ? ($fs_slug === 'saldi' ? '<span class="fs-cartellino__segno">%</span>' : fashionshoes_icona($fs_slug)) : '';
                        ?>
                        <article class="fs-riga<?php echo (!$fs_img && $fs_icona === '') ? ' fs-riga--solo' : ''; ?>">
                            <h3><?php echo esc_html($fs_name); ?></h3>
                            <?php if ($fs_desc !== '') : ?><p><?php echo esc_html(fashionshoes_t(wp_strip_all_tags($fs_desc), 'service:' . $fs_sid . ':description')); ?></p><?php endif; ?>
                            <?php if ($fs_img) : ?><div class="fs-foto"><?php echo fashionshoes_image($fs_img, 'medium', array('sizes' => '(min-width: 900px) 120px, 88px')); // phpcs:ignore WordPress.Security.EscapeOutput ?></div>
                            <?php elseif ($fs_icona !== '') : ?><div class="fs-foto fs-foto--icona<?php echo $fs_slug === 'saldi' ? ' fs-foto--cartellino' : ''; ?>" aria-hidden="true"><?php echo $fs_icona; // phpcs:ignore WordPress.Security.EscapeOutput ?></div><?php endif; ?>
                        </article>
                    <?php endforeach; ?>
                </div>
            </div>
        </section>
    <?php endif; ?>

    <?php if ($fs_about_text !== '' || $fs_shop) : ?>
        <section class="fs-negozio" id="negozio" aria-labelledby="fs-h-negozio">
            <div class="fs-contenitore fs-negozio__in">
                <?php $fs_about_h = $fs_about_t !== '' ? fashionshoes_t($fs_about_t, 'about:title') : __('Il negozio', 'fashionshoes-child-theme'); ?>
                <div class="fs-negozio__testo">
                    <h2 class="fs-titolo" id="fs-h-negozio" data-fs-rev><?php echo esc_html(fashionshoes_text('hero_motto') !== '' ? fashionshoes_text('hero_motto') : $fs_about_h); ?></h2>
                    <?php if (fashionshoes_text('hero_motto') !== '') : ?><h3 class="fs-etichetta" data-fs-rev><?php echo esc_html($fs_about_h); ?></h3><?php endif; ?>
                    <div data-fs-rev><?php echo $fs_paragraphs(fashionshoes_t($fs_about_text, 'about:text')); // phpcs:ignore WordPress.Security.EscapeOutput -- escape nella funzione ?></div>
                </div>
                <?php if ($fs_shop) : ?>
                    <div class="fs-negozio__foto">
                        <?php foreach (array_slice($fs_shop, 0, 2) as $fs_id) : ?>
                            <button class="fs-foto" type="button" data-fs-apri data-fs-rev data-fs-full="<?php echo esc_url((string) wp_get_attachment_image_url($fs_id, 'large')); ?>"><?php echo fashionshoes_image($fs_id, 'large', array('sizes' => '(min-width: 900px) 34vw, 50vw')); // phpcs:ignore WordPress.Security.EscapeOutput ?></button>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </section>
    <?php endif; ?>

    <?php if ($fs_galleria) : ?>
        <section class="fs-galleria" id="galleria" aria-labelledby="fs-h-galleria">
            <div class="fs-contenitore">
                <div class="fs-testa">
                    <h2 class="fs-titolo" id="fs-h-galleria" data-fs-rev><?php echo esc_html(fashionshoes_text('gallery_title') !== '' ? fashionshoes_text('gallery_title') : __('Galleria', 'fashionshoes-child-theme')); ?></h2>
                    <?php if (fashionshoes_text('gallery_text') !== '') : ?><p data-fs-rev><?php echo esc_html(fashionshoes_text('gallery_text')); ?></p><?php endif; ?>
                </div>
                <div class="fs-muratura">
                    <?php foreach ($fs_galleria as $fs_n => $fs_id) : ?>
                        <button class="fs-foto" type="button" data-fs-apri data-fs-rev data-fs-full="<?php echo esc_url((string) wp_get_attachment_image_url($fs_id, 'large')); ?>" aria-label="<?php echo esc_attr(sprintf(fashionshoes_t(__('Apri la foto %d', 'fashionshoes-child-theme'), 'gallery:open'), $fs_n + 1)); ?>"><?php echo fashionshoes_image($fs_id, 'large', array('sizes' => '(min-width: 1100px) 22vw, (min-width: 700px) 30vw, 46vw')); // phpcs:ignore WordPress.Security.EscapeOutput ?></button>
                    <?php endforeach; ?>
                </div>
            </div>
        </section>
    <?php endif; ?>

    <?php if ($fs_instagram) : ?>
        <section class="fs-sezione fs-instagram" id="instagram" aria-labelledby="fs-h-instagram">
            <div class="fs-contenitore">
                <div class="fs-testa">
                    <h2 class="fs-titolo" id="fs-h-instagram"><?php echo esc_html(fashionshoes_text('instagram_title') !== '' ? fashionshoes_text('instagram_title') : __('Dal nostro Instagram', 'fashionshoes-child-theme')); ?></h2>
                        <?php if (fashionshoes_text('instagram_text') !== '') : ?><p><?php echo esc_html(fashionshoes_text('instagram_text')); ?></p><?php endif; ?>
                </div>
                <div class="fs-striscia">
                    <?php foreach ($fs_instagram as $fs_id) :
                        // Le foto arrivate dalla sincronizzazione aprono il loro post su Instagram; quelle caricate a mano il visore.
                        $fs_post = (string) get_post_meta($fs_id, '_fs_instagram_link', true);
                        $fs_img  = fashionshoes_image($fs_id, 'medium_large', array('sizes' => '(min-width: 1024px) 210px, 33vw'));
                        ?>
                        <?php if ($fs_post !== '') : ?>
                            <a class="fs-foto fs-foto--post" style="--fs-ar:4/5" href="<?php echo esc_url($fs_post); ?>" target="_blank" rel="noopener" aria-label="<?php echo esc_attr(fashionshoes_t(__('Apri il post su Instagram', 'fashionshoes-child-theme'), 'ui:ig_post')); ?>"><?php echo $fs_img; // phpcs:ignore WordPress.Security.EscapeOutput ?><?php echo fashionshoes_icona('instagram'); // phpcs:ignore WordPress.Security.EscapeOutput ?></a>
                        <?php else : ?>
                            <button class="fs-foto" type="button" style="--fs-ar:4/5" data-fs-apri data-fs-full="<?php echo esc_url((string) wp_get_attachment_image_url($fs_id, 'large')); ?>"><?php echo $fs_img; // phpcs:ignore WordPress.Security.EscapeOutput ?></button>
                        <?php endif; ?>
                    <?php endforeach; ?>
                </div>
                    <?php if ($fs_contacts['instagram'] !== '') :
                        $fs_handle = trim((string) wp_parse_url($fs_contacts['instagram'], PHP_URL_PATH), '/');
                        ?>
                        <div class="fs-azioni fs-instagram__segui"><a class="fs-bottone fs-bottone--linea" href="<?php echo esc_url($fs_contacts['instagram']); ?>" target="_blank" rel="noopener"><?php echo fashionshoes_icona('instagram'); // phpcs:ignore WordPress.Security.EscapeOutput ?><?php
                            /* translators: %s: nome del profilo Instagram */
                            echo esc_html($fs_handle !== '' ? sprintf(__('Segui @%s', 'fashionshoes-child-theme'), $fs_handle) : __('Seguici su Instagram', 'fashionshoes-child-theme'));
                        ?></a></div>
                    <?php endif; ?>
            </div>
        </section>
    <?php endif; ?>

    <section class="fs-contatti" id="contatti" aria-labelledby="fs-h-contatti">
        <div class="fs-contenitore">
            <div class="fs-testa">
                <h2 class="fs-titolo" id="fs-h-contatti" data-fs-rev><?php echo esc_html(fashionshoes_text('contact_title') !== '' ? fashionshoes_text('contact_title') : __('Orari e contatti', 'fashionshoes-child-theme')); ?></h2>
            </div>
            <?php $fs_embed = fashionshoes_map_embed_url(); ?>
            <?php if ($fs_embed !== '') : ?>
                <div class="fs-mappa carica" data-fs-rev>
                    <iframe src="<?php echo esc_url($fs_embed); ?>" title="<?php esc_attr_e('Mappa: dove siamo', 'fashionshoes-child-theme'); ?>" loading="lazy" referrerpolicy="no-referrer-when-downgrade" allowfullscreen></iframe>
                </div>
            <?php endif; ?>
            <div class="fs-griglia">
                <div class="fs-contatti__lato" data-fs-rev style="--fs-t:8; --fs-d:6">
                    <h3><?php esc_html_e('Dove siamo', 'fashionshoes-child-theme'); ?></h3>
                    <address class="fs-indirizzo">
                        <?php if (fashionshoes_address_line() !== '') : ?><?php echo $fs_map !== '' ? '<a href="' . esc_url($fs_map) . '" target="_blank" rel="noopener">' : '<span>'; ?><?php echo fashionshoes_icona('posizione'); // phpcs:ignore WordPress.Security.EscapeOutput ?><?php echo esc_html(fashionshoes_address_line()); ?><?php echo $fs_map !== '' ? '</a>' : '</span>'; ?><?php endif; ?>
                        <?php if ($fs_contacts['phone'] !== '') : ?><a href="<?php echo esc_attr(fashionshoes_tel($fs_contacts['phone'])); ?>"><?php echo fashionshoes_icona('telefono'); // phpcs:ignore WordPress.Security.EscapeOutput ?><?php echo esc_html($fs_contacts['phone_display']); ?></a><?php endif; ?>
                        <?php if ($fs_contacts['email'] !== '') : ?><a href="<?php echo esc_attr('mailto:' . $fs_contacts['email']); ?>"><?php echo fashionshoes_icona('email'); // phpcs:ignore WordPress.Security.EscapeOutput ?><?php echo esc_html($fs_contacts['email']); ?></a><?php endif; ?>
                    </address>
                    <?php if ($fs_map !== '' || $fs_contacts['phone'] !== '') : ?>
                        <div class="fs-azioni">
                            <?php if ($fs_map !== '') : ?><a class="fs-bottone fs-bottone--pieno" href="<?php echo esc_url($fs_map); ?>" target="_blank" rel="noopener"><?php esc_html_e('Come arrivare', 'fashionshoes-child-theme'); ?><?php echo fashionshoes_icona('freccia'); // phpcs:ignore WordPress.Security.EscapeOutput ?></a><?php endif; ?>
                            <?php if ($fs_contacts['phone'] !== '') : ?><a class="fs-bottone fs-bottone--linea" href="<?php echo esc_attr(fashionshoes_tel($fs_contacts['phone'])); ?>"><?php esc_html_e('Chiama', 'fashionshoes-child-theme'); ?></a><?php endif; ?>
                        </div>
                    <?php endif; ?>
                    <div class="fs-contatti__orari">
                    <?php if ($fs_hours) : ?>
                        <div>
                            <?php if (fashionshoes_text('hours_title') !== '') : ?><h3><?php echo esc_html(fashionshoes_text('hours_title')); ?></h3><?php endif; ?>
                            <table class="fs-tabella">
                                <?php foreach ($fs_hours as $fs_h) : ?>
                                    <tr<?php echo $fs_h['oggi'] ? ' class="oggi"' : ''; ?>><th scope="row"><?php echo esc_html($fs_h['giorni']); ?></th><td><?php echo esc_html($fs_h['ore']); ?></td></tr>
                                <?php endforeach; ?>
                            </table>
                        </div>
                    <?php endif; ?>
                    <?php if ($fs_note) : ?>
                        <div>
                            <?php if (fashionshoes_text('hours_note_title') !== '') : ?><h3><?php echo esc_html(fashionshoes_text('hours_note_title')); ?></h3><?php endif; ?>
                            <table class="fs-tabella">
                                <?php foreach ($fs_note as $fs_n) : ?>
                                    <tr><th scope="row"><?php echo esc_html($fs_n['giorni']); ?></th><td><?php echo esc_html($fs_n['ore']); ?></td></tr>
                                <?php endforeach; ?>
                            </table>
                        </div>
                    <?php endif; ?>
                    </div>
                </div>
                <div class="fs-contatti__destra" data-fs-rev style="--fs-t:8; --fs-d:5; --fs-d-start:8">
                    <?php get_template_part('template-parts/form'); ?>
                </div>
            </div>
        </div>
    </section>

    <?php if ($fs_faq && !empty($fs_faq['items'])) : ?>
        <section class="fs-sezione fs-sezione--stretta fs-domande-sezione" id="domande" aria-labelledby="fs-h-domande">
            <div class="fs-contenitore fs-griglia">
                <h2 class="fs-titolo" id="fs-h-domande" data-fs-rev style="--fs-t:8; --fs-d:5"><?php echo esc_html($fs_faq['title'] !== '' ? $fs_faq['title'] : __('Domande frequenti', 'fashionshoes-child-theme')); ?></h2>
                <div class="fs-domande" data-fs-rev style="--fs-t:8; --fs-d:6; --fs-d-start:7">
                    <?php foreach ($fs_faq['items'] as $fs_q) : ?>
                        <details><summary><?php echo esc_html($fs_q['question']); ?><?php echo fashionshoes_icona('piu'); // phpcs:ignore WordPress.Security.EscapeOutput ?></summary><div class="fs-domande__risposta"><?php echo wp_kses_post($fs_q['answer']); ?></div></details>
                    <?php endforeach; ?>
                </div>
            </div>
        </section>
    <?php endif; ?>

</main>
<?php
get_footer();
