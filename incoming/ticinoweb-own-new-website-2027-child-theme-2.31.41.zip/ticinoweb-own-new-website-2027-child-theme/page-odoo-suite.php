<?php
/** Template Name: TICINOWEB — ODOO SUITE
 * THESIS: un ecosistema esplorabile, cinque approfondimenti distinti, nessun elenco infinito.
 * OWN-WORLD: palette e tipografia ticinoWEB, PNG ufficiali Odoo, linee e spazio editoriale.
 * STORY: capire l'area → esplorare funzioni reali → richiedere una consulenza.
 * FIRST VIEWPORT: hero a due colonne, visual reale e CTA; sotto, navigazione interna comune.
 * FORM: architettura specificata dal brief; accordion a divisione singola e griglie senza card SaaS.
 */
if(!defined('ABSPATH'))exit;
get_header();
while(have_posts()):the_post();
$d=tw_odoo_suite_data();$service=(array)get_post_meta(get_the_ID(),'_tw_service_content',true);
?>
<main class="tw-odoo-suite">
<?php get_template_part('template-parts/odoo/hero',null,['service'=>$service]); ?>
<?php get_template_part('template-parts/odoo/suite-nav'); ?>
<?php get_template_part('template-parts/odoo/intro',null,['service'=>$service]); ?>
<?php if($rows=tw_odoo_suite_active_rows($d['divisions']??[])): ?><section class="tw-odoo-section tw-odoo-explorer"><div class="tw-shell"><h2><?php echo esc_html($d['explorer_title']??''); ?></h2><?php get_template_part('template-parts/odoo/accordion',null,['groups'=>$rows,'prefix'=>'modules']); ?></div></section><?php endif; ?>
<?php if($rows=tw_odoo_suite_active_rows($d['groups']??[])): ?><section class="tw-odoo-section"><div class="tw-shell"><h2><?php echo esc_html($d['groups_title']??''); ?></h2><?php if(($d['role']??'')==='overview' || count($rows)>4):get_template_part('template-parts/odoo/accordion',null,['groups'=>$rows,'prefix'=>'features']);else:foreach($rows as $group): ?>
<section class="tw-odoo-feature"><header><h3><?php echo esc_html($group['title']); ?></h3><?php echo tw_odoo_suite_text($group['text']??''); ?></header>
<div class="tw-odoo-feature-body<?php echo !empty($group['media_id'])?' has-editorial-media':''; ?>">
<div class="tw-odoo-modules"><?php foreach(tw_odoo_suite_active_rows($group['rows']??[]) as $row)get_template_part('template-parts/odoo/module-card',null,['row'=>$row,'level'=>4]); get_template_part('template-parts/odoo/specialist',null,['id'=>$group['team_member_id']??0]); ?></div>
<?php if(!empty($group['media_id'])): ?><figure class="tw-odoo-editorial-visual"><?php tw_odoo_suite_media($group['media_id']); ?></figure><?php endif; ?>
</div>
<?php if(!empty($group['video_url'])): ?><a class="tw-text-link" href="<?php echo esc_url($group['video_url']); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e('Guarda il video su YouTube','ticinoweb-child-theme'); ?> <span class="tw-arrow" aria-hidden="true"></span></a><?php endif; ?>
</section><?php endforeach;endif; ?></div></section><?php endif; ?>
<?php foreach(['concepts','sectors'] as $key):if(!$rows=tw_odoo_suite_active_rows($d[$key]??[]))continue; ?><section class="tw-odoo-section<?php echo $key==='concepts'?' tw-odoo-ink':''; ?>"><div class="tw-shell"><h2><?php echo esc_html($d[$key.'_title']??''); ?></h2><div class="tw-odoo-modules"><?php foreach($rows as $row)get_template_part('template-parts/odoo/module-card',null,['row'=>$row,'level'=>3]); ?></div></div></section><?php endforeach; ?>
<?php get_template_part('template-parts/odoo/media',null,['data'=>$d]); ?>
<?php get_template_part('template-parts/odoo/cta',null,['data'=>$d,'service'=>$service]); ?>
</main>
<?php endwhile;get_footer();
