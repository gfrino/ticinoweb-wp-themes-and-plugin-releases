<?php
/**
 * Header navigation explorers, built from the WordPress menu and CMS content.
 *
 * @package ticinoWEB_Child_Theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Return the latest blog articles explicitly selected as projects.
 */
/**
 * Riga di progetto per il pannello «Progetto in evidenza».
 */
function tw_nav_project_row( $post ) {
	$categories     = wp_get_post_terms( $post->ID, 'category', array( 'fields' => 'names' ) );
	$categories     = is_wp_error( $categories ) ? array() : array_values( $categories );
	$category_slugs = wp_get_post_terms( $post->ID, 'category', array( 'fields' => 'slugs' ) );
	$category_slugs = is_wp_error( $category_slugs ) ? array() : array_map( 'sanitize_title', array_values( $category_slugs ) );
	return array(
		'id'             => (int) $post->ID,
		'title'          => get_the_title( $post ),
		'url'            => get_permalink( $post ),
		'image_id'       => absint( get_post_thumbnail_id( $post ) ),
		'types'          => $categories,
		'category_slugs' => $category_slugs,
	);
}

/**
 * Referenze di food delivery: gli articoli eCommerce più recenti su pizzerie, ristoranti e take away.
 */
function tw_nav_get_food_projects( $limit = 1 ) {
	static $food = null;
	if ( null === $food ) {
		$food  = array();
		$query = new WP_Query(
			array(
				'post_type'           => 'post',
				'post_status'         => 'publish',
				'category_name'       => 'ecommerce',
				'posts_per_page'      => 40,
				'orderby'             => 'date',
				'order'               => 'DESC',
				'no_found_rows'       => true,
				'ignore_sticky_posts' => true,
			)
		);
		foreach ( $query->posts as $post ) {
			if ( preg_match( '/pizz|food|delivery|inka|take ?away|ristorant|bistrot|sushi|poke/i', $post->post_title ) && has_post_thumbnail( $post ) ) {
				$food[] = tw_nav_project_row( $post );
			}
		}
	}
	return array_slice( $food, 0, min( 3, max( 1, absint( $limit ) ) ) );
}

function tw_nav_get_featured_projects( $limit = 3, $category_slug = '' ) {
	$limit         = min( 3, max( 1, absint( $limit ) ) );
	$category_slug = sanitize_title( $category_slug );
	if ( 'food-delivery' === $category_slug ) {
		return tw_nav_get_food_projects( $limit );
	}
	static $pool = null;

	if ( null === $pool ) {
		$query = new WP_Query(
			array(
				'post_type'           => 'post',
				'post_status'         => 'publish',
				'posts_per_page'      => 12,
				'orderby'             => 'date',
				'order'               => 'DESC',
				'no_found_rows'       => true,
				'ignore_sticky_posts' => true,
				'meta_query'          => array(
					array(
						'key'     => 'tw_home_project_featured',
						'value'   => '1',
						'compare' => '=',
					),
				),
			)
		);
		$pool = array_map(
			static function ( $post ) {
				$categories = wp_get_post_terms( $post->ID, 'category', array( 'fields' => 'names' ) );
				$categories = is_wp_error( $categories ) ? array() : array_values( $categories );
				$category_slugs = wp_get_post_terms( $post->ID, 'category', array( 'fields' => 'slugs' ) );
				$category_slugs = is_wp_error( $category_slugs ) ? array() : array_map( 'sanitize_title', array_values( $category_slugs ) );
				return array(
					'id'             => (int) $post->ID,
					'title'          => get_the_title( $post ),
					'url'            => get_permalink( $post ),
					'image_id'       => absint( get_post_thumbnail_id( $post ) ),
					'types'          => $categories,
					'category_slugs' => $category_slugs,
				);
			},
			$query->posts
		);
	}

	$projects = $pool;
	if ( $category_slug ) {
		$projects = array_values(
			array_filter(
				$projects,
				static function ( $project ) use ( $category_slug ) {
					return in_array( $category_slug, $project['category_slugs'], true );
				}
			)
		);
	}

	return array_slice( $projects, 0, $limit );
}

/**
 * Curated categories are resolved from WordPress rather than hardcoded URLs.
 */
function tw_nav_get_project_categories() {
	$categories = array();
	// Hosting è un servizio, non un progetto: resta solo nel menu Servizi.
	foreach ( array( 'web-design', 'ecommerce', 'gestionali', 'applicazioni-ios-android', 'grafica-pubblicitaria-cat' ) as $slug ) {
		$term = get_term_by( 'slug', $slug, 'category' );
		if ( ! $term || is_wp_error( $term ) ) {
			continue;
		}
		$url = function_exists( 'tw_projects_term_url' ) ? tw_projects_term_url( 'category', $term ) : get_term_link( $term );
		if ( is_wp_error( $url ) ) continue;
		$categories[] = array(
			'name' => $term->name,
			'slug' => $term->slug,
			'url'  => $url,
		);
	}
	return $categories;
}

/**
 * Keep footer service links aligned with the canonical commercial pages.
 *
 * The portfolio routes intentionally remain separate because they expose
 * filtered project archives rather than service content.
 */
function tw_child_normalize_footer_service_links( $items, $args ) {
	$location = isset( $args->theme_location ) ? (string) $args->theme_location : '';
	if ( 'footer-services' !== $location ) {
		return $items;
	}

	$canonical = array(
		'siti web'  => 'siti-web',
		'ecommerce' => 'ecommerce-websites',
		'e-commerce' => 'ecommerce-websites',
	);

	foreach ( $items as $item ) {
		$label = strtolower( trim( wp_strip_all_tags( (string) $item->title ) ) );
		if ( 'web' === $label && 0 === (int) $item->menu_item_parent ) {
			$item->url = home_url( '/siti-web/' );
			continue;
		}
		if ( isset( $canonical[ $label ] ) ) {
			$item->url = home_url( '/' . $canonical[ $label ] . '/' );
		}
	}

	return $items;
}
add_filter( 'wp_nav_menu_objects', 'tw_child_normalize_footer_service_links', 20, 2 );

/**
 * Deferred media prevents hidden mega panels from downloading every image.
 */
function tw_nav_get_deferred_image_markup( $image_id, $size = 'medium_large' ) {
	$image = absint( $image_id ) ? wp_get_attachment_image_src( absint( $image_id ), $size ) : false;
	if ( ! $image ) {
		return '<span class="tw-mega-media-placeholder" aria-hidden="true"></span>';
	}
	$srcset = wp_get_attachment_image_srcset( absint( $image_id ), $size );
	return sprintf(
		'<img data-deferred-image data-src="%1$s"%2$s alt="" width="%3$d" height="%4$d" decoding="async" sizes="(max-width: 1280px) 0px, 360px">',
		esc_url( $image[0] ),
		$srcset ? ' data-srcset="' . esc_attr( $srcset ) . '"' : '',
		(int) $image[1],
		(int) $image[2]
	);
}

/**
 * Render one or more featured projects.
 */
function tw_nav_render_featured_projects( $projects, $key = 'default', $hidden = false, $compact = false ) {
	if ( empty( $projects ) ) {
		return;
	}
	?>
	<div class="tw-mega-feature__projects<?php echo $compact ? ' is-compact' : ''; ?>" data-featured-project="<?php echo esc_attr( $key ); ?>"<?php echo $hidden ? ' hidden' : ''; ?>>
		<?php foreach ( $projects as $project ) : ?>
			<article class="tw-mega-feature__project">
				<a href="<?php echo esc_url( $project['url'] ); ?>">
					<figure class="tw-mega-feature__media"><?php echo tw_nav_get_deferred_image_markup( $project['image_id'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></figure>
					<div>
						<?php if ( ! empty( $project['types'] ) ) : ?><p class="tw-mega-eyebrow"><?php echo esc_html( implode( ' · ', array_slice( $project['types'], 0, 2 ) ) ); ?></p><?php endif; ?>
						<p class="tw-mega-feature__title"><?php echo esc_html( $project['title'] ); ?></p>
						<span><?php esc_html_e( 'Scopri la referenza', 'ticinoweb-child-theme' ); ?> <span class="tw-arrow" aria-hidden="true"></span></span>
					</div>
				</a>
			</article>
		<?php endforeach; ?>
	</div>
	<?php
}

/**
 * The website child theme deliberately converts the existing CMS menu into
 * six focused editorial explorers. Links still come from WordPress.
 */
class TW_Premium_Nav_Walker extends Walker_Nav_Menu {
	private $items = array();
	private $children = array();

	/**
	 * Render the complete primary navigation in the approved order.
	 */
	public function walk( $elements, $max_depth, ...$args ) {
		$this->items    = array();
		$this->children = array();
		foreach ( (array) $elements as $item ) {
			$this->items[ (int) $item->ID ] = $item;
			$this->children[ (int) $item->menu_item_parent ][] = (int) $item->ID;
		}

		$services   = $this->find_item( array( 'servizi', 'services' ) );
		$references = $this->find_item( array( 'referenze', 'references', 'progetti', 'projects' ) );
		$blog       = $this->find_item( array( 'tblog', 'blog' ) );
		$support    = $this->find_item( array( 'supporto', 'support' ) );
		$jobs       = $this->find_item( array( 'lavora con noi', 'jobs', 'careers' ) );
		$about      = $this->find_item( array( 'chi siamo & contatti', 'chi siamo', 'about' ) );
		$service_items = $services ? $this->descendants( (int) $services->ID ) : array();
		$web_item   = $this->find_in_items( $service_items, array( 'siti web', 'website', 'web design' ) );

		ob_start();
		// «Siti Web» non è più una voce a sé: resta nel menu Servizi.
		$this->render_services_item( $services, $service_items );
		$this->render_projects_item( $references );
		$this->render_agency_item( $about, $jobs );
		$this->render_simple_item( $blog, 'tBlog' );
		$this->render_simple_item( $support, __( 'Supporto', 'ticinoweb-child-theme' ) );
		return ob_get_clean();
	}

	private function normalize( $value ) {
		$value = strtolower( wp_strip_all_tags( (string) $value ) );
		return preg_replace( '/\s+/', ' ', trim( $value ) );
	}

	private function find_item( $labels ) {
		$top = array_map( static function ( $id ) { return (int) $id; }, $this->children[0] ?? array() );
		$items = array();
		foreach ( $top as $id ) {
			if ( isset( $this->items[ $id ] ) ) {
				$items[] = $this->items[ $id ];
			}
		}
		return $this->find_in_items( $items, $labels );
	}

	private function find_in_items( $items, $labels ) {
		foreach ( (array) $items as $item ) {
			$title = $this->normalize( $item->title ?? '' );
			foreach ( $labels as $label ) {
				if ( false !== strpos( $title, $this->normalize( $label ) ) ) {
					return $item;
				}
			}
		}
		return null;
	}

	private function descendants( $parent_id ) {
		$output = array();
		foreach ( $this->children[ $parent_id ] ?? array() as $child_id ) {
			if ( ! isset( $this->items[ $child_id ] ) ) {
				continue;
			}
			$output[] = $this->items[ $child_id ];
			$output = array_merge( $output, $this->descendants( $child_id ) );
		}
		return $output;
	}

	private function valid_url( $item, $fallback = '' ) {
		$url = trim( (string) ( $item->url ?? '' ) );
		if ( '' === $url || '#' === $url ) {
			$url = $fallback;
		}
		return $url;
	}

	private function panel_button( $label, $kind ) {
		$id = 'tw-nav-panel-' . sanitize_html_class( $kind );
		?>
		<span class="tw-nav-item__line">
			<button id="<?php echo esc_attr( $id ); ?>-trigger" type="button" aria-expanded="false" aria-controls="<?php echo esc_attr( $id ); ?>" data-submenu-toggle data-menu-trigger>
				<span><?php echo esc_html( $label ); ?></span>
				<svg class="tw-submenu-chevron" aria-hidden="true" viewBox="0 0 12 8"><path d="m1 1 5 5 5-5" fill="none" stroke="currentColor" stroke-width="1.5"/></svg>
			</button>
		</span>
		<?php
	}

	private function render_simple_item( $item, $fallback_label ) {
		if ( ! $item ) {
			return;
		}
		?>
		<li class="menu-item tw-nav-simple"><span class="tw-nav-item__line"><a href="<?php echo esc_url( $this->valid_url( $item, home_url( '/' ) ) ); ?>"><?php echo esc_html( $fallback_label ); ?></a></span></li>
		<?php
	}

	private function description_for( $item ) {
		$description = trim( wp_strip_all_tags( (string) ( $item->description ?? '' ) ) );
		if ( $description ) {
			return wp_trim_words( $description, 14 );
		}
		if ( function_exists( 'tw_home_get_services' ) ) {
			foreach ( (array) tw_home_get_services() as $service ) {
				if ( $this->normalize( $service['title'] ?? '' ) === $this->normalize( $item->title ?? '' ) ) {
					$summary = trim( wp_strip_all_tags( (string) ( $service['short_description'] ?? '' ) ) );
					if ( $summary ) return wp_trim_words( $summary, 14 );
				}
			}
		}
		$object_id = absint( $item->object_id ?? 0 );
		if ( $object_id && 'publish' === get_post_status( $object_id ) ) {
			$excerpt = trim( wp_strip_all_tags( get_post_field( 'post_excerpt', $object_id ) ) );
			if ( $excerpt ) return wp_trim_words( $excerpt, 14 );
			$content = trim( wp_strip_all_tags( get_post_field( 'post_content', $object_id ) ) );
			if ( $content && ! preg_match( '/elementor|\{[^}]*\}|src\$=|\/\*!/i', $content ) ) {
				return wp_trim_words( $content, 14 );
			}
		}
		$fallbacks = array(
			'web'            => __( 'Progettazione, contenuti e sviluppo coordinati.', 'ticinoweb-child-theme' ),
			'marketing'      => __( 'Strategia e presenza digitale su misura.', 'ticinoweb-child-theme' ),
			'software'       => __( 'Gestionali collegati ai processi dell’azienda.', 'ticinoweb-child-theme' ),
			'apps'           => __( 'App per smartphone progettate intorno alla tua attività.', 'ticinoweb-child-theme' ),
			'infrastructure' => __( 'Servizi tecnici per continuità e protezione.', 'ticinoweb-child-theme' ),
		);
		return $fallbacks[ $this->service_family( $item ) ];
	}

	private function service_family( $item ) {
		$value = $this->normalize( ( $item->title ?? '' ) . ' ' . ( $item->url ?? '' ) );
		if ( preg_match( '/hosting|backup|hostiweb|cloud/', $value ) ) {
			return 'infrastructure';
		}
		if ( preg_match( '/applicazioni|android|ios|su-misura/', $value ) ) {
			return 'apps';
		}
		if ( preg_match( '/odoo|gestional|gestione-contabile|software|fatturazione|sistemi-di-cassa|retail|contabil|immobiliar/', $value ) ) {
			return 'software';
		}
		if ( preg_match( '/marketing|google|social|video|grafica|contenut/', $value ) ) {
			return 'marketing';
		}
		return 'web';
	}

	private function project_key_for_service( $item ) {
		$value = $this->normalize( $item->title ?? '' );
		if ( preg_match( '/food|delivery/', $value ) ) return 'food-delivery';
		if ( false !== strpos( $value, 'ecommerce' ) ) return 'ecommerce';
		if ( preg_match( '/odoo|gestional|panoramica|fatturazione|retail|contabil|immobiliar/', $value ) ) return 'gestionali';
		if ( preg_match( '/applicazioni|android|ios/', $value ) ) return 'applicazioni-ios-android';
		if ( preg_match( '/grafica|video|social|marketing|google/', $value ) ) return 'grafica-pubblicitaria-cat';
		if ( preg_match( '/hosting|backup/', $value ) ) return 'hosting';
		return 'web-design';
	}

	private function render_web_item( $item, $references, $service_items ) {
		$links = function_exists( 'tw_web_services_navigation_items' ) ? tw_web_services_navigation_items() : array_values( array_filter( $service_items, function ( $service ) { return 'web' === $this->service_family( $service ); } ) );
		?>
		<li class="menu-item menu-item-has-children menu-item--explorer" data-menu-kind="web">
			<?php $this->panel_button( __( 'Siti Web', 'ticinoweb-child-theme' ), 'web' ); ?>
			<div id="tw-nav-panel-web" class="tw-menu-panel tw-mega-menu tw-mega-menu--web" data-menu-panel data-mega-menu hidden aria-labelledby="tw-nav-panel-web-trigger">
				<div class="tw-shell tw-mega-web__grid">
					<div><p class="tw-mega-eyebrow"><?php esc_html_e( 'Il nostro core', 'ticinoweb-child-theme' ); ?></p><h2><?php esc_html_e( 'Siti pensati per funzionare, crescere e farsi ricordare.', 'ticinoweb-child-theme' ); ?></h2><p><?php esc_html_e( 'Strategia, identità, contenuti e tecnologia in un unico percorso.', 'ticinoweb-child-theme' ); ?></p></div>
					<div class="tw-mega-index">
						<?php foreach ( array_slice( $links, 0, 3 ) as $link ) : ?>
							<a href="<?php echo esc_url( $this->valid_url( $link, home_url( '/' ) ) ); ?>"><strong><?php echo esc_html( $link->title ); ?></strong><span><?php echo esc_html( $this->description_for( $link ) ); ?></span><i class="tw-arrow" aria-hidden="true"></i></a>
						<?php endforeach; ?>
					</div>
				</div>
			</div>
		</li>
		<?php
	}

	private function render_services_item( $item, $service_items ) {
		$families = array(
			'web'            => __( 'Web & Commerce', 'ticinoweb-child-theme' ),
			'marketing'      => __( 'Marketing & Content', 'ticinoweb-child-theme' ),
			'software'       => __( 'Software Aziendale', 'ticinoweb-child-theme' ),
			'apps'           => __( 'Applicazioni', 'ticinoweb-child-theme' ),
			'infrastructure' => __( 'Hosting', 'ticinoweb-child-theme' ),
		);
		$grouped = array_fill_keys( array_keys( $families ), array() );
		foreach ( $service_items as $service ) {
			$grouped[ $this->service_family( $service ) ][] = $service;
		}
		$default_projects = tw_nav_get_featured_projects( 1, 'web-design' );
		?>
		<li class="menu-item menu-item-has-children menu-item--explorer" data-menu-kind="services">
			<?php $this->panel_button( __( 'Servizi', 'ticinoweb-child-theme' ), 'services' ); ?>
			<div id="tw-nav-panel-services" class="tw-menu-panel tw-mega-menu tw-mega-menu--services" data-menu-panel data-mega-menu hidden aria-labelledby="tw-nav-panel-services-trigger">
				<div class="tw-shell tw-service-explorer">
					<div class="tw-service-explorer__categories" role="tablist" aria-label="<?php esc_attr_e( 'Categorie di servizi', 'ticinoweb-child-theme' ); ?>">
						<p class="tw-mega-eyebrow"><?php esc_html_e( 'Esplora i servizi', 'ticinoweb-child-theme' ); ?></p>
						<?php $index = 0; foreach ( $families as $key => $label ) : ?>
							<button type="button" role="tab" id="tw-service-tab-<?php echo esc_attr( $key ); ?>" aria-selected="<?php echo 0 === $index ? 'true' : 'false'; ?>" aria-expanded="<?php echo 0 === $index ? 'true' : 'false'; ?>" aria-controls="tw-service-pane-<?php echo esc_attr( $key ); ?>" data-service-category="<?php echo esc_attr( $key ); ?>"><span><?php echo esc_html( $label ); ?></span><svg class="tw-submenu-chevron" aria-hidden="true" viewBox="0 0 12 8"><path d="m1 1 5 5 5-5" fill="none" stroke="currentColor" stroke-width="1.5"/></svg></button>
						<?php ++$index; endforeach; ?>
					</div>
					<div class="tw-service-explorer__panes">
						<?php $index = 0; foreach ( $families as $key => $label ) : ?>
							<div id="tw-service-pane-<?php echo esc_attr( $key ); ?>" role="tabpanel" aria-labelledby="tw-service-tab-<?php echo esc_attr( $key ); ?>" data-service-pane="<?php echo esc_attr( $key ); ?>"<?php echo 0 === $index ? '' : ' hidden'; ?>>
								<?php foreach ( array_slice( $grouped[ $key ], 0, 6 ) as $service ) : $project_key = $this->project_key_for_service( $service ); ?>
									<a href="<?php echo esc_url( $this->valid_url( $service, home_url( '/' ) ) ); ?>" data-feature-project="<?php echo esc_attr( $project_key ); ?>"><span><strong><?php echo esc_html( $service->title ); ?></strong><small><?php echo esc_html( $this->description_for( $service ) ); ?></small></span><i class="tw-arrow" aria-hidden="true"></i></a>
								<?php endforeach; ?>
							</div>
						<?php ++$index; endforeach; ?>
					</div>
					<aside class="tw-service-explorer__feature"><p class="tw-mega-eyebrow"><?php esc_html_e( 'Progetto in evidenza', 'ticinoweb-child-theme' ); ?></p>
						<?php tw_nav_render_featured_projects( $default_projects, 'default' ); ?>
						<?php foreach ( array( 'web-design', 'ecommerce', 'food-delivery', 'gestionali', 'applicazioni-ios-android', 'grafica-pubblicitaria-cat', 'hosting' ) as $slug ) : tw_nav_render_featured_projects( tw_nav_get_featured_projects( 1, $slug ), $slug, true ); endforeach; ?>
					</aside>
				</div>
			</div>
		</li>
		<?php
	}

	private function render_projects_item( $item ) {
		$categories = tw_nav_get_project_categories();
		$projects   = tw_nav_get_featured_projects( 3 );
		$url        = $this->valid_url( $item, tw_home_mapped_url( 'page_referenze', 'referenze' ) );
		?>
		<li class="menu-item menu-item-has-children menu-item--explorer" data-menu-kind="projects">
			<?php $this->panel_button( __( 'Referenze', 'ticinoweb-child-theme' ), 'projects' ); ?>
			<div id="tw-nav-panel-projects" class="tw-menu-panel tw-mega-menu tw-mega-menu--projects" data-menu-panel data-mega-menu hidden aria-labelledby="tw-nav-panel-projects-trigger">
				<div class="tw-shell tw-project-explorer">
					<div><p class="tw-mega-eyebrow"><?php esc_html_e( 'Esplora per tipologia', 'ticinoweb-child-theme' ); ?></p><h2><?php esc_html_e( 'Una selezione del nostro lavoro.', 'ticinoweb-child-theme' ); ?></h2><div class="tw-project-explorer__categories"><?php foreach ( $categories as $category ) : ?><a href="<?php echo esc_url( $category['url'] ); ?>"><?php echo esc_html( $category['name'] ); ?><span class="tw-arrow" aria-hidden="true"></span></a><?php endforeach; ?></div><a class="tw-mega-text-link" href="<?php echo esc_url( $url ); ?>"><?php esc_html_e( 'Tutte le referenze', 'ticinoweb-child-theme' ); ?> <span class="tw-arrow" aria-hidden="true"></span></a></div>
					<div><p class="tw-mega-eyebrow"><?php esc_html_e( 'Referenze recenti', 'ticinoweb-child-theme' ); ?></p><?php tw_nav_render_featured_projects( $projects, 'projects', false, true ); ?></div>
				</div>
			</div>
		</li>
		<?php
	}

	private function render_agency_item( $about, $jobs ) {
		$d = tw_agency_menu_data(); $facts=tw_agency_menu_facts(); $contact=$facts['contact'];
		$about_url = $this->valid_url( $about, tw_home_mapped_url( 'page_chi_siamo', 'chi-siamo' ) );
		$team=$this->find_item(array('team'));$contact_item=$this->find_item(array('contatti','contacts'));$sustain_item=$this->find_item(array('sostenibilità','sostenibilita','sustainability'));$sustain_page=get_page_by_path('sostenibilita');$faq_item=$this->find_item(array('faq','domande frequenti'));$faq_page=get_page_by_path('faq');
		$jobs_url=apply_filters('tw_jobs_url','https://ticinoweb.online/jobs');
		$links=array(
			array('label'=>__('Chi siamo','ticinoweb-child-theme'),'url'=>$about_url,'description'=>trim(wp_strip_all_tags($about->description??''))?:($d['about_description']??'')),
			array('label'=>__('Team','ticinoweb-child-theme'),'url'=>$this->valid_url($team,home_url('/').'#team'),'description'=>trim(wp_strip_all_tags($team->description??''))?:($d['team_description']??'')),
			array('label'=>__('Lavora con noi','ticinoweb-child-theme'),'url'=>$this->valid_url($jobs,$jobs_url),'description'=>trim(wp_strip_all_tags($jobs->description??''))?:($d['jobs_description']??'')),
			array('label'=>__('Sostenibilità','ticinoweb-child-theme'),'url'=>$this->valid_url($sustain_item,$sustain_page?get_permalink($sustain_page):''),'description'=>trim(wp_strip_all_tags($sustain_item->description??''))?:($d['sustainability_description']??__('Energia rinnovabile, mobilità elettrica e meno plastica.','ticinoweb-child-theme'))),
		array('label'=>__('FAQ','ticinoweb-child-theme'),'url'=>$this->valid_url($faq_item,$faq_page?get_permalink($faq_page):''),'description'=>trim(wp_strip_all_tags($faq_item->description??''))?:($d['faq_description']??__('Le risposte alle domande più frequenti dei clienti.','ticinoweb-child-theme'))),
		array('label'=>__('Contatti','ticinoweb-child-theme'),'url'=>$this->valid_url($contact_item,tw_home_mapped_url('page_contatti','contatti')),'description'=>trim(wp_strip_all_tags($contact_item->description??''))?:($d['contact_description']??''))
		);
		?>
		<li class="menu-item menu-item-has-children menu-item--explorer" data-menu-kind="agency">
			<?php $this->panel_button( __( 'Agenzia', 'ticinoweb-child-theme' ), 'agency' ); ?>
			<div id="tw-nav-panel-agency" class="tw-menu-panel tw-mega-menu tw-mega-menu--agency" data-menu-panel data-mega-menu hidden aria-labelledby="tw-nav-panel-agency-trigger">
				<div class="tw-shell tw-agency-explorer">
					<div class="tw-agency-explorer__intro"><p class="tw-mega-eyebrow"><?php echo esc_html($d['eyebrow']??''); ?></p><h2><?php echo nl2br(esc_html($d['title']??'')); ?></h2><p><?php echo esc_html($d['text']??''); ?></p><p class="tw-agency-explorer__microcopy"><?php echo esc_html($d['microcopy']??''); ?></p></div>
					<div class="tw-agency-explorer__links"><?php foreach($links as $link): if(!$link['url'])continue; ?><a href="<?php echo esc_url($link['url']); ?>"<?php echo tw_external_link_attrs($link['url']); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>><span><strong><?php echo esc_html($link['label']); ?></strong><small><?php echo esc_html($link['description']); ?></small></span><i class="tw-arrow" aria-hidden="true"></i></a><?php endforeach; ?></div>
					<aside class="tw-agency-explorer__institution">
					<?php if(!empty($d['media_id'])): ?><figure><?php echo tw_nav_get_deferred_image_markup($d['media_id'],'medium_large'); ?></figure><p class="tw-mega-eyebrow"><?php echo esc_html(sprintf(__('Dal %1$s a %2$s','ticinoweb-child-theme'),$facts['year'],$facts['city'])); ?></p><?php else: ?><dl class="tw-agency-explorer__facts">
					<?php if($facts['year']): ?><div><dt><?php echo esc_html($facts['year']); ?></dt><dd><?php echo esc_html($d['birth_label']??''); ?></dd></div><?php endif; ?>
					<?php if($facts['city']): ?><div><dt><?php echo esc_html($facts['city']); ?></dt><dd><?php echo esc_html($d['studio_label']??''); ?></dd></div><?php endif; ?>
					<?php if(!empty($d['team_text'])): ?><div><dt><?php echo esc_html($d['team_label']??''); ?></dt><dd><?php echo esc_html($d['team_text']); ?></dd></div><?php endif; ?></dl><?php endif; ?>
					<p class="tw-agency-explorer__name"><?php echo esc_html($facts['name']); ?></p><?php if(!empty($contact['address'])): ?><p class="tw-agency-explorer__address"><?php echo esc_html($contact['address']); ?></p><?php endif; ?><?php if(!empty($contact['phone'])): ?><p class="tw-agency-explorer__phone"><?php echo esc_html($contact['phone']); ?></p><?php endif; ?>
					</aside>
				</div>
			</div>
		</li>
		<?php
	}
}


/**
 * Le offerte di lavoro vivono su Odoo (ticinoweb.online/jobs): il vecchio indirizzo
 * /lavora-con-noi/ (anche con prefisso di lingua) porta lì con un redirect permanente.
 */
add_action( 'template_redirect', function () {
	$path = trim( (string) wp_parse_url( (string) ( $_SERVER['REQUEST_URI'] ?? '' ), PHP_URL_PATH ), '/' ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
	if ( preg_match( '#^(?:(?:en|fr|de)/)?ticinoweb-e-lecologia$#', $path ) ) {
		$sustain = get_page_by_path( 'sostenibilita' );
		if ( $sustain ) {
			wp_safe_redirect( get_permalink( $sustain ), 301 );
			exit;
		}
	}
	if ( preg_match( '#^(?:(?:en|fr|de)/)?lavora-con-noi$#', $path ) ) {
		wp_redirect( esc_url_raw( apply_filters( 'tw_jobs_url', 'https://ticinoweb.online/jobs' ) ), 301 ); // phpcs:ignore WordPress.Security.SafeRedirect
		exit;
	}
}, 1 );


/**
 * Link verso altri siti: si aprono in una nuova scheda (con rel di sicurezza); tel:, mailto: e
 * i link interni restano nella stessa pagina.
 */
function tw_is_external_url( $url ) {
	$url = (string) $url;
	if ( ! preg_match( '#^https?://#i', $url ) ) {
		return false;
	}
	$host = strtolower( (string) wp_parse_url( $url, PHP_URL_HOST ) );
	$home = strtolower( (string) wp_parse_url( home_url(), PHP_URL_HOST ) );
	return '' !== $host && preg_replace( '/^www\./', '', $host ) !== preg_replace( '/^www\./', '', $home );
}

function tw_external_link_attrs( $url ) {
	return tw_is_external_url( $url ) ? ' target="_blank" rel="noopener noreferrer"' : '';
}

add_filter( 'nav_menu_link_attributes', function ( $atts, $item ) {
	if ( tw_is_external_url( $atts['href'] ?? '' ) ) {
		$atts['target'] = '_blank';
		$atts['rel']    = 'noopener noreferrer';
		$atts['aria-label'] = sprintf( __( '%s (si apre in una nuova scheda)', 'ticinoweb-child-theme' ), wp_strip_all_tags( $item->title ?? '' ) );
	}
	return $atts;
}, 20, 2 );

/**
 * Le voci del menu principale con la classe `tw-header-only` (Sostenibilità, FAQ) servono al
 * pannello Agenzia in alto: non si ripetono nel blocco «Navigazione» del footer.
 */
add_filter( 'wp_nav_menu_objects', function ( $items, $args ) {
	if ( ! empty( $args->menu_class ) && false !== strpos( (string) $args->menu_class, 'tw-footer-menu--navigation' ) ) {
		$items = array_values( array_filter( $items, static function ( $item ) {
			return ! in_array( 'tw-header-only', (array) $item->classes, true );
		} ) );
	}
	return $items;
}, 10, 2 );
