<?php
/**
 * Template Name: ticinoWEB — Panoramica Siti Web
 *
 * @package ticinoWEB_Child_Theme
 */

if ( ! defined( 'ABSPATH' ) ) exit;

$tw_data       = tw_web_services_get_data();
$tw_contact    = tw_home_mapped_url( 'page_contatti', 'contatti' );
$tw_projects   = tw_home_mapped_url( 'page_referenze', 'referenze' );
$tw_primary    = $tw_data['hero_cta_url'] ?: $tw_contact;
$tw_final_url  = $tw_data['final_cta_url'] ?: $tw_contact;

get_header();
?>
<main class="tw-web-service tw-web-service--overview">
	<section class="tw-web-hero">
		<div class="tw-shell">
			<div class="tw-web-hero__grid">
				<div>
					<p class="tw-kicker"><?php echo esc_html( $tw_data['hero_eyebrow'] ); ?></p>
					<h1><?php echo esc_html( $tw_data['hero_title'] ); ?></h1>
					<p><?php echo wp_kses_post( $tw_data['hero_text'] ); ?></p>
					<?php if ( $tw_data['hero_cta_text'] ) : ?><a class="tw-text-link" href="<?php echo esc_url( $tw_primary ); ?>"><?php echo esc_html( $tw_data['hero_cta_text'] ); ?> <span class="tw-arrow" aria-hidden="true"></span></a><?php endif; ?>
				</div>
				<?php if ( ! empty( $tw_data['hero_media_id'] ) ) : ?><figure><?php echo wp_get_attachment_image( $tw_data['hero_media_id'], 'large', false, array( 'alt' => '', 'fetchpriority' => 'high', 'decoding' => 'async', 'sizes' => '(max-width: 900px) 100vw, 45vw' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></figure><?php endif; ?>
			</div>
		</div>
	</section>

	<?php tw_parallax_band( 'web/web-codice.webp', __( 'Sviluppo', 'ticinoweb-child-theme' ), __( 'Un unico studio, dal primo schizzo alla messa online', 'ticinoweb-child-theme' ), __( 'Design, sviluppo e gestione nello stesso team, a Locarno: un solo referente per il tuo sito.', 'ticinoweb-child-theme' ), __( 'Codice di un sito web su uno schermo', 'ticinoweb-child-theme' ), '50% 50%' ); ?>

	<?php if ( '1' === ( $tw_data['show_intro'] ?? '1' ) ) : ?>
	<section class="tw-web-intro">
		<div class="tw-shell tw-web-split">
			<p class="tw-kicker"><?php esc_html_e( 'Siti Web', 'ticinoweb-child-theme' ); ?></p>
			<div><h2><?php echo esc_html( $tw_data['intro_title'] ); ?></h2><?php echo wp_kses_post( wpautop( $tw_data['intro_text'] ) ); ?></div>
		</div>
	</section>
	<?php endif; ?>

	<?php
	$tw_type_count = count( $tw_data['overview_types'] ?? array() );
	$tw_count_word = array( 2 => 'Due', 3 => 'Tre', 4 => 'Quattro', 5 => 'Cinque', 6 => 'Sei', 7 => 'Sette', 8 => 'Otto' );
	?>
	<section class="tw-web-overview-types" aria-labelledby="tw-web-types-title">
		<?php tw_parallax_backdrop( 'web/web-laptop.webp' ); ?>
		<div class="tw-shell">
			<p class="tw-kicker"><?php esc_html_e( 'Tipologie', 'ticinoweb-child-theme' ); ?></p>
			<h2 id="tw-web-types-title"><?php echo esc_html( isset( $tw_count_word[ $tw_type_count ] ) ? sprintf( /* translators: %s: number of structures, in words */ __( '%s strutture, una sola attenzione al risultato.', 'ticinoweb-child-theme' ), $tw_count_word[ $tw_type_count ] ) : __( 'Una sola attenzione al risultato.', 'ticinoweb-child-theme' ) ); ?></h2>
			<div class="tw-web-overview-types__list">
				<?php foreach ( $tw_data['overview_types'] ?? array() as $tw_type ) : ?>
					<?php $tw_type_url = home_url( '/' . trim( $tw_type['url'], '/' ) . '/' ); ?>
					<a href="<?php echo esc_url( $tw_type_url ); ?>">
						<span><?php echo esc_html( $tw_type['number'] ); ?></span>
						<h3><?php echo esc_html( $tw_type['title'] ); ?></h3>
						<p><?php echo esc_html( $tw_type['text'] ); ?></p>
						<i class="tw-arrow" aria-hidden="true"></i>
					</a>
				<?php endforeach; ?>
			</div>
		</div>
	</section>

	<?php if ( '1' === ( $tw_data['show_final_cta'] ?? '1' ) ) : ?>
	<section class="tw-web-final-cta">
		<div class="tw-shell tw-web-final-cta__grid">
			<div><p class="tw-kicker"><?php esc_html_e( 'Il prossimo passo', 'ticinoweb-child-theme' ); ?></p><h2><?php echo esc_html( $tw_data['final_cta_title'] ); ?></h2></div>
			<div><?php echo wp_kses_post( wpautop( $tw_data['final_cta_text'] ) ); ?><a class="tw-button" href="<?php echo esc_url( $tw_final_url ); ?>"><?php echo esc_html( $tw_data['final_cta_button'] ); ?> <span class="tw-arrow" aria-hidden="true"></span></a><?php if ( $tw_data['portfolio_link_text'] ) : ?><a class="tw-web-portfolio-link" href="<?php echo esc_url( $tw_projects ); ?>"><?php echo esc_html( $tw_data['portfolio_link_text'] ); ?> <span class="tw-arrow" aria-hidden="true"></span></a><?php endif; ?></div>
		</div>
	</section>
	<?php endif; ?>
</main>
<?php get_footer(); ?>
