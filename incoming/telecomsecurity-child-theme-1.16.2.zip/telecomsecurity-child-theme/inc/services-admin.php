<?php
/** Extend the parent services editor without introducing another content store. */
defined('ABSPATH') || exit;

/** Return the default-language ID used to keep CMS metadata stable with WPML. */
function telecomsecurity_get_canonical_service_page_id( int $page_id ): int {
    if ( ! $page_id ) {
        return 0;
    }

    $default_language = apply_filters( 'wpml_default_language', null );
    if ( ! is_string( $default_language ) || '' === $default_language ) {
        return $page_id;
    }

    $canonical_id = apply_filters( 'wpml_object_id', $page_id, 'page', true, $default_language );
    return absint( $canonical_id ) ?: $page_id;
}

/** Return the current-language page ID when WPML provides a translation. */
function telecomsecurity_get_localized_service_page_id( int $page_id ): int {
    if ( ! $page_id ) {
        return 0;
    }

    $localized_id = apply_filters( 'wpml_object_id', $page_id, 'page', true );
    return absint( $localized_id ) ?: $page_id;
}

/**
 * Resolve the page that owns the service pages without hardcoding its ID.
 *
 * @param array<int,array<string,mixed>> $stored_services Existing CMS rows.
 */
function telecomsecurity_get_services_parent_page_id( array $stored_services ): int {
    $mapping   = (array) get_option( 'ticinoweb_page_mapping', array() );
    $mapped_id = absint( $mapping['page_servizi'] ?? 0 );
    if ( $mapped_id && 'page' === get_post_type( $mapped_id ) ) {
        return telecomsecurity_get_localized_service_page_id( $mapped_id );
    }

    $services_page = get_page_by_path( 'servizi' );
    if ( $services_page && 'page' === get_post_type( $services_page->ID ) ) {
        return telecomsecurity_get_localized_service_page_id( absint( $services_page->ID ) );
    }

    $parents = array();
    foreach ( $stored_services as $service ) {
        $page_id = telecomsecurity_get_localized_service_page_id( absint( $service['page_id'] ?? 0 ) );
        $page    = $page_id ? get_post( $page_id ) : null;
        if ( $page && 'page' === get_post_type( $page_id ) && absint( $page->post_parent ?? 0 ) ) {
            $parents[ absint( $page->post_parent ) ] = true;
        }
    }
    if ( 1 === count( $parents ) ) {
        return absint( array_key_first( $parents ) );
    }
    return 0;
}

/** Read the persisted option without the runtime page projection. */
function telecomsecurity_get_raw_services_option() {
    remove_filter( 'option_ticinoweb_services', 'telecomsecurity_project_services_from_pages', 30 );
    $value = get_option( 'ticinoweb_services', null );
    add_filter( 'option_ticinoweb_services', 'telecomsecurity_project_services_from_pages', 30 );
    return $value;
}

/**
 * Project the published service pages into the parent CMS collection.
 *
 * Page title, excerpt, featured image and publication state are canonical.
 * The CMS option retains only presentation metadata that does not belong to a page.
 *
 * @param mixed $stored_value Value currently stored in ticinoweb_services.
 * @return array<int,array<string,mixed>>
 */
function telecomsecurity_project_services_from_pages( $stored_value ): array {
    static $request_cache = array();

    $stored_services = is_array( $stored_value ) ? $stored_value : array();
    $blog_id         = function_exists( 'get_current_blog_id' ) ? get_current_blog_id() : 0;
    $language        = apply_filters( 'wpml_current_language', '' );
    $posts_changed   = function_exists( 'wp_cache_get_last_changed' ) ? wp_cache_get_last_changed( 'posts' ) : '';
    $cache_key       = md5( serialize( array( $blog_id, $language, $posts_changed, $stored_services ) ) );
    if ( isset( $request_cache[ $cache_key ] ) ) {
        return $request_cache[ $cache_key ];
    }

    $parent_id       = telecomsecurity_get_services_parent_page_id( $stored_services );
    if ( ! $parent_id ) {
        $request_cache[ $cache_key ] = $stored_services;
        return $request_cache[ $cache_key ];
    }

    $saved_by_page = array();
    foreach ( $stored_services as $stored ) {
        if ( ! is_array( $stored ) ) {
            continue;
        }
        $page_id = absint( $stored['page_id'] ?? 0 );
        if ( ! $page_id && is_string( $stored['id'] ?? null ) && preg_match( '/^page_(\d+)$/', $stored['id'], $matches ) ) {
            $page_id = absint( $matches[1] );
        }
        if ( $page_id ) {
            $saved_by_page[ telecomsecurity_get_canonical_service_page_id( $page_id ) ] = $stored;
        }
    }

    $pages = get_pages(
        array(
            'parent'      => $parent_id,
            'post_type'   => 'page',
            'post_status' => 'publish',
            'sort_column' => 'menu_order,post_title',
            'sort_order'  => 'ASC',
        )
    );

    $services = array();
    foreach ( $pages as $page ) {
        $page_id = absint( $page->ID ?? 0 );
        if ( ! $page_id ) {
            continue;
        }
        $canonical_page_id = telecomsecurity_get_canonical_service_page_id( $page_id );
        $saved             = $saved_by_page[ $canonical_page_id ] ?? array();
        $area  = $saved['area'] ?? 'security';
        $area  = in_array( $area, array( 'security', 'infrastructure' ), true ) ? $area : 'security';

        $services[] = array(
            'id'          => sanitize_key( (string) ( $saved['id'] ?? '' ) ) ?: 'page_' . $canonical_page_id,
            'image'       => esc_url_raw( (string) ( get_the_post_thumbnail_url( $page_id, 'full' ) ?: '' ) ),
            'title'       => sanitize_text_field( (string) get_the_title( $page_id ) ),
            'description' => wp_kses_post( (string) get_post_field( 'post_excerpt', $page_id ) ),
            'icon'        => sanitize_text_field( (string) ( $saved['icon'] ?? 'dashicons-admin-tools' ) ),
            'icon_type'   => sanitize_key( (string) ( $saved['icon_type'] ?? 'dashicon' ) ),
            'icon_svg'    => esc_url_raw( (string) ( $saved['icon_svg'] ?? '' ) ),
            'page_id'     => $page_id,
            'area'        => $area,
            'geometry'    => sanitize_key( (string) ( $saved['geometry'] ?? 'shield' ) ),
            'edit_url'    => (string) get_edit_post_link( $page_id, 'raw' ),
        );
    }

    $request_cache[ $cache_key ] = $services;
    return $request_cache[ $cache_key ];
}
add_filter( 'option_ticinoweb_services', 'telecomsecurity_project_services_from_pages', 30 );

/** Ensure the collection exists so first-time page discovery also works. */
function telecomsecurity_ensure_services_option_exists(): void {
    $raw_value = telecomsecurity_get_raw_services_option();
    if ( null === $raw_value ) {
        add_option( 'ticinoweb_services', array(), '', false );
    }
}
add_action( 'init', 'telecomsecurity_ensure_services_option_exists', 2 );

/**
 * Keep the page hierarchy order aligned when services are reordered in the CMS.
 *
 * @param mixed $old_value Previous option value.
 * @param mixed $new_value Saved option value.
 */
function telecomsecurity_sync_service_page_order( $old_value, $new_value ): void {
    if ( ! is_array( $new_value ) ) {
        return;
    }

    $parent_id = telecomsecurity_get_services_parent_page_id( $new_value );
    if ( ! $parent_id ) {
        return;
    }

    $menu_order = 1;
    foreach ( array_values( $new_value ) as $service ) {
        $page_id = is_array( $service ) ? absint( $service['page_id'] ?? 0 ) : 0;
        $page    = $page_id ? get_post( $page_id ) : null;
        if ( ! $page || 'page' !== get_post_type( $page_id ) || 'publish' !== ( $page->post_status ?? '' ) || $parent_id !== absint( $page->post_parent ?? 0 ) || ! current_user_can( 'edit_post', $page_id ) ) {
            continue;
        }
        if ( (int) ( $page->menu_order ?? 0 ) === $menu_order ) {
            ++$menu_order;
            continue;
        }
        $updated = wp_update_post(
            array(
                'ID'         => $page_id,
                'menu_order' => $menu_order,
            ),
            true
        );
        if ( ! is_wp_error( $updated ) ) {
            ++$menu_order;
        }
    }
}
add_action( 'update_option_ticinoweb_services', 'telecomsecurity_sync_service_page_order', 20, 2 );

add_filter('sanitize_option_ticinoweb_services', 'telecomsecurity_sanitize_service_metadata', 20, 3);

function telecomsecurity_sanitize_service_metadata($value, $option, $original_value) {
    if ($original_value === null) {
        $raw_value = telecomsecurity_get_raw_services_option();
        return is_array( $raw_value ) ? $raw_value : array();
    }
    if (!is_array($original_value) || !function_exists('ticinoweb_sanitize_services')) {
        return $value;
    }

    $saved_by_id = array();
    $raw_saved = telecomsecurity_get_raw_services_option();
    foreach ( is_array( $raw_saved ) ? $raw_saved : array() as $saved) {
        if (is_array($saved) && !empty($saved['id'])) {
            $saved_by_id[$saved['id']] = $saved;
        }
    }
    $result = array();
    $seen = array();
    foreach ($original_value as $raw) {
        if (!is_array($raw) || !isset($raw['title']) || !is_string($raw['title'])) {
            continue;
        }
        // Sanitize each original row separately: blank rows may be removed by the parent.
        $clean = ticinoweb_sanitize_services(array($raw));
        if (empty($clean)) {
            continue;
        }
        $row = reset($clean);
        $id = isset($raw['id']) && is_string($raw['id']) ? sanitize_key($raw['id']) : '';
        $duplicate = $id !== '' && isset($seen[$id]);
        if ($id === '' || $duplicate) {
            $id = wp_generate_uuid4();
        }
        $saved = isset($saved_by_id[$id]) ? $saved_by_id[$id] : array();
        $row['id'] = $id;
        $row['page_id'] = $duplicate ? 0 : absint($raw['page_id'] ?? $saved['page_id'] ?? 0);
        if (!$duplicate && !$row['page_id']) {
            // Resolve once by an exact page title, then retain the page ID on later edits.
            $pages = get_posts(array(
                'post_type' => 'page',
                'post_status' => 'publish',
                'title' => $row['title'],
                'numberposts' => 2,
                'fields' => 'ids',
                'no_found_rows' => true,
            ));
            if (count($pages) === 1) {
                $row['page_id'] = absint($pages[0]);
            }
        }
        $area = $raw['area'] ?? $saved['area'] ?? 'security';
        $row['area'] = in_array($area, array('security', 'infrastructure'), true) ? $area : 'security';
        $geometry = $raw['geometry'] ?? $saved['geometry'] ?? '';
        if (is_string($geometry) && isset(telecomsecurity_geometry_paths()[$geometry])) $row['geometry'] = $geometry;
        $seen[$id] = true;
        $result[] = $row;
    }

    // Keep presentation metadata for draft, trashed or temporarily moved pages.
    // Runtime projection still hides those rows until the pages are republished
    // as direct children of Servizi.
    foreach ( $saved_by_id as $id => $saved ) {
        if ( isset( $seen[ $id ] ) ) {
            continue;
        }
        $page_id = absint( $saved['page_id'] ?? 0 );
        if ( ! $page_id || ! get_post( $page_id ) ) {
            continue;
        }
        $result[] = $saved;
    }
    return $result;
}

add_action('admin_init', function () {
    register_setting('ticinoweb_settings_group', 'ts_services_editorial', array(
        'type' => 'array',
        'sanitize_callback' => 'telecomsecurity_sanitize_services_editorial',
    ));
});

function telecomsecurity_sanitize_services_editorial($input) {
    $saved = get_option('ts_services_editorial', array());
    if (!is_array($input)) {
        return $saved;
    }
    $result = is_array($saved) ? $saved : array();
    foreach (array('chapter_1_title', 'chapter_1_text', 'chapter_2_title', 'chapter_2_text', 'transition_title', 'transition_text') as $key) {
        if (array_key_exists($key, $input) && is_string($input[$key])) {
            $result[$key] = substr($key, -5) === '_text' ? sanitize_textarea_field($input[$key]) : sanitize_text_field($input[$key]);
        }
    }
    return $result;
}

add_action('admin_enqueue_scripts', function ($hook) {
    if ($hook !== 'toplevel_page_ticinoweb-cms' || !current_user_can('edit_pages')) {
        return;
    }
    $relative = '/assets/js/services-admin.js';
    wp_enqueue_script('telecomsecurity-services-admin', get_stylesheet_directory_uri() . $relative, array('jquery'), filemtime(get_stylesheet_directory() . $relative), true);
    $config = array(
        'services' => array_values((array) get_option('ticinoweb_services', array())),
        'editorial' => telecomsecurity_get_services_editorial_data(),
        'symbols' => array_keys(telecomsecurity_geometry_paths()),
        'newPageUrl' => admin_url('post-new.php?post_type=page'),
        'managePagesUrl' => admin_url('edit.php?post_type=page'),
        'symbolDefaults' => array_column(array_map(static function ($row) { return array('id'=>$row['id'] ?? '', 'symbol'=>telecomsecurity_service_symbol($row)); }, (array) get_option('ticinoweb_services', array())), 'symbol', 'id'),
        'labels' => array(
            'area' => __('Area', 'telecomsecurity-child-theme'),
            'security' => __('Sicurezza', 'telecomsecurity-child-theme'),
            'infrastructure' => __('Infrastrutture', 'telecomsecurity-child-theme'),
            'up' => __('Sposta su', 'telecomsecurity-child-theme'),
            'down' => __('Sposta giù', 'telecomsecurity-child-theme'),
            'heading' => __('Testi della sezione Servizi', 'telecomsecurity-child-theme'),
            'chapter_1_title' => __('Titolo capitolo Sicurezza', 'telecomsecurity-child-theme'),
            'chapter_1_text' => __('Introduzione capitolo Sicurezza', 'telecomsecurity-child-theme'),
            'chapter_2_title' => __('Titolo capitolo Infrastrutture', 'telecomsecurity-child-theme'),
            'chapter_2_text' => __('Introduzione capitolo Infrastrutture', 'telecomsecurity-child-theme'),
            'transition_title' => __('Titolo di transizione', 'telecomsecurity-child-theme'),
            'transition_text' => __('Testo di transizione', 'telecomsecurity-child-theme'),
            'editPage' => __('Modifica pagina', 'telecomsecurity-child-theme'),
            'addPage' => __('Nuova pagina servizio', 'telecomsecurity-child-theme'),
            'managePages' => __('Gestisci le pagine', 'telecomsecurity-child-theme'),
            'syncedNotice' => __('Titolo, descrizione breve e immagine provengono automaticamente dalle pagine figlie pubblicate di Servizi. Modifica la pagina sorgente per aggiornarli; pubblica, sposta in bozza o cestina una pagina figlia per aggiungere o rimuovere il servizio.', 'telecomsecurity-child-theme'),
        ),
    );
    wp_add_inline_script('telecomsecurity-services-admin', 'window.telecomsecurityServicesAdmin = ' . wp_json_encode($config, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) . ';', 'before');
});
