(function () {
	'use strict';

	var tabNavigation = document.querySelector('.gl-app-admin .nav-tab-wrapper');
	var activeTab = tabNavigation ? tabNavigation.querySelector('.nav-tab-active') : null;
	function keepActiveTabVisible() {
		if (!activeTab || !window.matchMedia('(max-width: 782px)').matches || tabNavigation.scrollWidth <= tabNavigation.clientWidth) return;
		window.requestAnimationFrame(function () {
			var navigationBox = tabNavigation.getBoundingClientRect();
			var activeBox = activeTab.getBoundingClientRect();
			var target = tabNavigation.scrollLeft + (activeBox.left - navigationBox.left) - ((tabNavigation.clientWidth - activeBox.width) / 2);
			tabNavigation.scrollLeft = Math.max(0, target);
		});
	}
	function scheduleActiveTabVisibility() {
		keepActiveTabVisible();
		window.setTimeout(keepActiveTabVisible, 200);
	}
	if (document.readyState === 'complete') scheduleActiveTabVisibility();
	else window.addEventListener('load', scheduleActiveTabVisibility, { once: true });
	window.addEventListener('resize', keepActiveTabVisible);

	document.querySelectorAll('[data-gl-stripe-settings]').forEach(function (root) {
		var controls = Array.prototype.slice.call(root.querySelectorAll('[data-gl-stripe-mode]'));
		var panels = Array.prototype.slice.call(root.querySelectorAll('[data-gl-stripe-panel]'));
		var current = root.querySelector('[data-gl-stripe-current]');
		if (!controls.length || !panels.length) return;

		root.classList.add('is-enhanced');

		function syncMode() {
			var selected = controls.find(function (control) { return control.checked; });
			var mode = selected ? selected.value : 'test';
			panels.forEach(function (panel) {
				var active = panel.getAttribute('data-gl-stripe-panel') === mode;
				panel.hidden = !active;
				panel.classList.toggle('is-active', active);
			});
			if (current) {
				var template = current.getAttribute('data-gl-stripe-current-template') || '%s';
				var label = selected ? selected.getAttribute('data-gl-stripe-label') : 'Test';
				current.textContent = template.replace('%s', label);
			}
		}

		controls.forEach(function (control) { control.addEventListener('change', syncMode); });
		syncMode();
	});

	document.querySelectorAll('[data-gl-schedule-week]').forEach(function (week) {
		var pattern = week.getAttribute('data-gl-schedule-week');

		week.querySelectorAll('[data-gl-schedule-day]').forEach(function (dayRow) {
			var day = dayRow.getAttribute('data-gl-schedule-day');
			var openControl = dayRow.querySelector('[data-gl-day-open]');
			var rangeList = dayRow.querySelector('[data-gl-time-ranges]');
			var addButton = dayRow.querySelector('[data-gl-add-range]');
			if (!openControl || !rangeList || !addButton) return;

			function nextIndex() {
				var indexes = Array.prototype.map.call(rangeList.querySelectorAll('[data-gl-range-index]'), function (range) {
					return parseInt(range.getAttribute('data-gl-range-index'), 10) || 0;
				});
				return indexes.length ? Math.max.apply(Math, indexes) + 1 : 0;
			}

			function makeTimeField(index, key, label) {
				var wrapper = document.createElement('label');
				var text = document.createElement('span');
				var input = document.createElement('input');
				text.textContent = label;
				input.type = 'time';
				input.name = 'settings[weekly_patterns][' + pattern + '][' + day + '][ranges][' + index + '][' + key + ']';
				input.setAttribute('aria-label', dayRow.querySelector('.gl-app-schedule__day-name').textContent + ': ' + (key === 'open' ? 'dalle' : 'alle'));
				wrapper.appendChild(text);
				wrapper.appendChild(input);
				return wrapper;
			}

			function addRange() {
				var index = nextIndex();
				var range = document.createElement('div');
				var remove = document.createElement('button');
				range.className = 'gl-app-time-range';
				range.setAttribute('data-gl-time-range', '');
				range.setAttribute('data-gl-range-index', String(index));
				range.appendChild(makeTimeField(index, 'open', 'Da'));
				range.appendChild(makeTimeField(index, 'close', 'A'));
				remove.type = 'button';
				remove.className = 'button-link-delete gl-app-time-range__remove';
				remove.setAttribute('data-gl-remove-range', '');
				remove.setAttribute('aria-label', 'Rimuovi questo orario');
				remove.textContent = '\u00d7';
				range.appendChild(remove);
				rangeList.appendChild(range);
				openControl.checked = true;
				syncDay();
				range.querySelector('input').focus();
			}

			function syncDay() {
				var isOpen = openControl.checked;
				dayRow.classList.toggle('is-open', isOpen);
				dayRow.classList.toggle('is-closed', !isOpen);
				var state = dayRow.querySelector('[data-gl-open-label]');
				if (state) state.textContent = isOpen ? 'Aperto' : 'Chiuso';
				rangeList.querySelectorAll('input').forEach(function (input) { input.disabled = !isOpen; });
			}

			openControl.addEventListener('change', function () {
				if (openControl.checked && !rangeList.querySelector('[data-gl-time-range]')) addRange();
				else syncDay();
			});
			addButton.addEventListener('click', addRange);
			rangeList.addEventListener('click', function (event) {
				var remove = event.target.closest('[data-gl-remove-range]');
				if (!remove) return;
				remove.closest('[data-gl-time-range]').remove();
				if (!rangeList.querySelector('[data-gl-time-range]')) openControl.checked = false;
				syncDay();
			});
			syncDay();
		});
	});
}());
