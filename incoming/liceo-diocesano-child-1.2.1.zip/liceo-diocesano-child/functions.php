<?php
/**
 * Liceo Diocesano Child: funzioni del tema.
 *
 * @package liceo-diocesano-child
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

function liceo_diocesano_enqueue_styles() {
    // Il parent accoda get_stylesheet_uri() (= questo style.css) come 'ticinoweb-ai-style' e Poppins da Google Fonts:
    // il child lo riaccoda con la propria versione e usa Source Sans 3 self-hosted, quindi si tolgono entrambi.
    wp_dequeue_style( 'ticinoweb-ai-style' );
    wp_dequeue_style( 'poppins-font' );

    $parent_version = wp_get_theme( get_template() )->get( 'Version' );
    wp_enqueue_style( 'parent-style', get_template_directory_uri() . '/style.css', array(), $parent_version );
    $version = filemtime( get_stylesheet_directory() . '/style.css' );
    wp_enqueue_style( 'child-style', get_stylesheet_uri(), array( 'parent-style' ), $version );
}
add_action( 'wp_enqueue_scripts', 'liceo_diocesano_enqueue_styles', 20 );

function liceo_diocesano_enqueue_menu_script() {
    $file = get_stylesheet_directory() . '/assets/js/menu.js';
    wp_enqueue_script( 'liceo-diocesano-menu', get_stylesheet_directory_uri() . '/assets/js/menu.js', array(), filemtime( $file ), true );
}
add_action( 'wp_enqueue_scripts', 'liceo_diocesano_enqueue_menu_script', 25 );

// Pulsante del menu su mobile (il parent non lo prevede); si vede solo sotto i 900px.
function liceo_diocesano_menu_toggle() {
    echo '<button type="button" class="ld-menu-toggle" aria-expanded="false" aria-label="' . esc_attr__( 'Apri il menu', 'liceo-diocesano-child' ) . '"><span></span><span></span><span></span></button>';
}
add_action( 'ticinoweb_after_primary_navigation', 'liceo_diocesano_menu_toggle' );

// Il font del corpo è caricato dal CSS: precarica la parte latina, usata da tutto il testo italiano.
function liceo_diocesano_preload_font() {
    printf(
        '<link rel="preload" href="%s" as="font" type="font/woff2" crossorigin>' . "\n",
        esc_url( get_stylesheet_directory_uri() . '/assets/fonts/source-sans-3-latin.woff2' )
    );
}
add_action( 'wp_head', 'liceo_diocesano_preload_font', 1 );

function liceo_diocesano_register_menus() {
    register_nav_menus( array(
        'primary' => __( 'Menu Principale', 'liceo-diocesano-child' ),
    ) );
}
add_action( 'after_setup_theme', 'liceo_diocesano_register_menus', 20 );

/**
 * Home: il parent stampa lo slider (ticinoWEB CMS → Slider) e poi questi tre punti di aggancio.
 * Il testo di presentazione si modifica nella pagina impostata come Home (Impostazioni → Lettura).
 */
function liceo_diocesano_upload_url( $path ) {
    $up = wp_upload_dir();
    return trailingslashit( $up['baseurl'] ) . ltrim( $path, '/' );
}

function liceo_diocesano_page_url( $slug ) {
    $page = get_page_by_path( $slug );
    return $page ? get_permalink( $page ) : '';
}

function liceo_diocesano_home_intro() {
    $home_id = (int) get_option( 'page_on_front' );
    $home    = $home_id ? get_post( $home_id ) : null;
    if ( $home && '' !== trim( $home->post_content ) ) {
        echo '<div class="ld-intro entry-content">' . apply_filters( 'the_content', $home->post_content ) . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput
    }

    $cards = array(
        array( 'Iscrizione alla scuola', 'Info e iscrizioni >', 'iscrizione', '2025/10/Schermata-2025-09-23-alle-17.22.24.png', '' ),
        array( 'Corsi tecnologici', 'Info e iscrizioni >', 'corsi-tecnologici', '2025/10/liceo-alberi.jpg', 'ld-card--alt' ),
        array( 'Indirizzi formativi', 'Scopri di più >', 'piano-degli-studi', '2025/10/Schermata-2025-09-23-alle-17.22.24.png', '' ),
        array( 'Indirizzo e contatti', 'Scopri di più >', 'indirizzo_contatti', '2025/10/contact-us-concept-2025-02-20-23-32-51-utc-scaled.jpg', 'ld-card--alt' ),
        array( 'Borse di studio', 'Scopri di più >', 'borse-di-studio', '2025/10/Schermata-2025-09-23-alle-17.29.58.png', '' ),
        array( 'Informativa sul trattamento dei dati personali della fondazione Liceo Diocesano', 'Scopri di più >', '', '2025/10/Schermata-2025-09-23-alle-17.30.43.png', 'ld-card--alt' ),
    );
    echo '<div class="ld-cards">';
    foreach ( $cards as $c ) {
        $url = $c[2] ? liceo_diocesano_page_url( $c[2] ) : liceo_diocesano_upload_url( '2023/12/Informativa-LDP-Lucino-WEB.pdf' );
        printf(
            '<a class="ld-card %1$s" href="%2$s" style="background-image:url(%3$s)"><span class="ld-card__body"><strong>%4$s</strong><span class="ld-card__more">%5$s</span></span></a>',
            esc_attr( $c[4] ),
            esc_url( $url ),
            esc_url( liceo_diocesano_upload_url( $c[3] ) ),
            esc_html( $c[0] ),
            esc_html( $c[1] )
        );
    }
    echo '</div>';
}
add_action( 'ticinoweb_services_section', 'liceo_diocesano_home_intro' );

function liceo_diocesano_home_quicklinks() {
    $links = array(
        array( 'Calendario Scolastico', 'calendario-scolastico', '2025/10/calendar-editable_0.3s.svg' ),
        array( 'Orario Scolastico', 'la-griglia-oraria', '2025/10/clock-1-editable_0.3s.svg' ),
        array( 'Menu Settimanale mensa', 'menu-settimanale-mensa', '2025/10/Restaurant_Silverware_0.3s.svg' ),
    );
    echo '<section class="ld-quicklinks"><div class="container">';
    foreach ( $links as $l ) {
        printf(
            '<a href="%1$s"><img src="%2$s" alt="" width="64" height="64" loading="lazy"><span>%3$s</span></a>',
            esc_url( liceo_diocesano_page_url( $l[1] ) ),
            esc_url( liceo_diocesano_upload_url( $l[2] ) ),
            esc_html( $l[0] )
        );
    }
    echo '</div></section>';
}
add_action( 'ticinoweb_cta_section', 'liceo_diocesano_home_quicklinks' );

function liceo_diocesano_home_news() {
    $posts = get_posts( array( 'numberposts' => 6, 'post_status' => 'publish' ) );
    if ( ! $posts ) {
        return;
    }
    echo '<section class="ld-news"><div class="container"><h2>' . esc_html__( 'Ultimi Articoli', 'liceo-diocesano-child' ) . '</h2><div class="ld-news__grid">';
    foreach ( $posts as $p ) {
        $thumb = get_the_post_thumbnail( $p, 'medium_large', array( 'loading' => 'lazy', 'alt' => '' ) );
        printf(
            '<article class="ld-news__item"><a class="ld-news__img" href="%1$s" tabindex="-1" aria-hidden="true">%2$s</a><time datetime="%3$s">%4$s</time><h3><a href="%1$s">%5$s</a></h3></article>',
            esc_url( get_permalink( $p ) ),
            $thumb, // phpcs:ignore WordPress.Security.EscapeOutput
            esc_attr( get_the_date( 'c', $p ) ),
            esc_html( get_the_date( '', $p ) ),
            esc_html( get_the_title( $p ) )
        );
    }
    echo '</div>';
    $archive = liceo_diocesano_page_url( 'articoli' );
    if ( $archive ) {
        echo '<p class="ld-news__all"><a class="button" href="' . esc_url( $archive ) . '">' . esc_html__( 'Vedi tutti gli articoli', 'liceo-diocesano-child' ) . '</a></p>';
    }
    echo '</div></section>';
}
add_action( 'ticinoweb_about_section', 'liceo_diocesano_home_news' );

// Footer: tutti gli indirizzi email del sito (il parent ne stampa uno solo) e link principali.
function liceo_diocesano_footer_emails() {
    $c      = ticinoweb_get_contact_info();
    $labels = array( 'email' => 'segreteria', 'email_2' => 'direzione', 'email_3' => 'amministrazione' );
    echo '<ul class="ld-footer-emails">';
    foreach ( $labels as $key => $label ) {
        if ( ! empty( $c[ $key ] ) ) {
            printf( '<li>%s: <a href="mailto:%s">%s</a></li>', esc_html( $label ), esc_attr( $c[ $key ] ), esc_html( $c[ $key ] ) );
        }
    }
    echo '</ul>';
}
add_action( 'ticinoweb_footer_brand_description', 'liceo_diocesano_footer_emails' );

function liceo_diocesano_footer_links() {
    $items = array( 'informazioni' => 'Informazioni', 'organizzazione' => 'Studi', 'il-liceo' => '2025-26', 'articoli' => 'Notizie', 'la-storia' => 'La Storia', 'area-riservata-2' => 'Area Riservata' );
    foreach ( $items as $slug => $label ) {
        $url = liceo_diocesano_page_url( $slug );
        if ( $url ) {
            printf( '<li><a href="%s">%s</a></li>', esc_url( $url ), esc_html( $label ) );
        }
    }
}
add_action( 'ticinoweb_footer_links', 'liceo_diocesano_footer_links' );

// Titolo della colonna link del footer del parent.
add_filter( 'gettext', function ( $text, $original, $domain ) {
    return ( 'Servizi' === $original && 'ticinoweb-ai-theme' === $domain ) ? 'Link utili' : $text;
}, 10, 3 );
