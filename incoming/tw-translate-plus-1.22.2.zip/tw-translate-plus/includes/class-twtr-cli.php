<?php
/**
 * WP-CLI commands: wp twtr queue|status|retry|index|check|glossary-sync|legacy-keys
 *
 * @package tw-translate-plus
 */

if (!defined('ABSPATH')) {
    exit;
}

class Twtr_CLI {

    /**
     * Process the translation queue of the current site.
     *
     * ## OPTIONS
     *
     * [--batches=<n>]
     * : Number of batches to process (default 1, 0 = until empty).
     *
     * ## EXAMPLES
     *
     *     wp twtr queue --url=https://example.com/site1 --batches=0
     *
     * @subcommand queue
     */
    public function queue($args, $assoc_args) {
        twtr_queue();
        $batches = isset($assoc_args['batches']) ? (int) $assoc_args['batches'] : 1;
        $run     = 0;
        do {
            $result = Twtr_Queue::process();
            $run++;
            WP_CLI::log(sprintf(
                'Batch %d: %d tradotte, %d errori, %d in coda. %s',
                $run, $result['processed'], $result['errors'], $result['remaining'], $result['message']
            ));
            if ($result['remaining'] === 0 || ($result['processed'] === 0 && $result['errors'] === 0)) {
                break;
            }
        } while ($batches === 0 || $run < $batches);
        WP_CLI::success('Coda processata.');
    }

    /**
     * Show translation status per language.
     *
     * @subcommand status
     */
    public function status($args, $assoc_args) {
        $counts = Twtr_Storage::status_counts();
        if (!$counts) {
            WP_CLI::log('Nessuna traduzione registrata per questo sito.');
            return;
        }
        $rows = array();
        foreach ($counts as $locale => $statuses) {
            $rows[] = array(
                'lingua'  => $locale,
                'ready'   => isset($statuses['ready']) ? $statuses['ready'] : 0,
                'pending' => isset($statuses['pending']) ? $statuses['pending'] : 0,
                'stale'   => isset($statuses['stale']) ? $statuses['stale'] : 0,
                'error'   => isset($statuses['error']) ? $statuses['error'] : 0,
            );
        }
        \WP_CLI\Utils\format_items('table', $rows, array('lingua', 'ready', 'pending', 'stale', 'error'));
        WP_CLI::log('Motore di traduzione del sito: ' . Twtr_Settings::provider_label());
        $missing = Twtr_Settings::engine_missing_reason();
        if ($missing !== '') {
            WP_CLI::warning($missing);
        } elseif (Twtr_Settings::provider() === 'openai') {
            WP_CLI::log('Chiave OpenAI del sito: …' . Twtr_Settings::openai_key_hint());
        } elseif (Twtr_Settings::provider() === 'compat') {
            $compat = Twtr_Settings::compat_config();
            WP_CLI::log('Server compatibile: ' . $compat['base_url'] . ' — modello ' . $compat['model']);
        }
        $limit = Twtr_Settings::daily_char_limit();
        WP_CLI::log('Caratteri usati oggi (sito): ' . number_format_i18n(Twtr_Settings::usage_today())
            . ' / ' . ($limit > 0 ? number_format_i18n($limit) : 'nessun limite'));
    }

    /**
     * Reset failed entries back to pending and process them.
     *
     * @subcommand retry
     */
    public function retry($args, $assoc_args) {
        $reset = Twtr_Storage::retry_errors();
        WP_CLI::log($reset . ' entry in errore rimesse in coda.');
        if ($reset > 0) {
            $this->queue(array(), array('batches' => 0));
        }
    }

    /**
     * Index every published content and public term of the current site,
     * queueing the strings not translated yet (same as the admin button).
     *
     * ## OPTIONS
     *
     * [--process]
     * : Process the queue until empty right after indexing.
     *
     * ## EXAMPLES
     *
     *     wp twtr index --url=https://example.com/site1 --process
     *
     * @subcommand index
     */
    public function index($args, $assoc_args) {
        if (!Twtr_Settings::extra_languages()) {
            WP_CLI::error('Nessuna lingua aggiuntiva attiva su questo sito.');
        }
        twtr_queue();
        $before  = Twtr_Queue::remaining();
        $phase   = 'posts';
        $offset  = 0;
        $scanned = 0;
        do {
            $result   = Twtr_Extractor::index_batch($phase, $offset, 50);
            $scanned += $result['scanned'];
            $phase    = $result['phase'];
            $offset   = $result['offset'];
            WP_CLI::log(sprintf('%d/%d elementi esaminati…', $scanned, $result['total']));
        } while (!$result['done']);
        WP_CLI::success(sprintf(
            'Indicizzazione completata: %d elementi esaminati, %d nuove stringhe in coda.',
            $scanned, max(0, Twtr_Queue::remaining() - $before)
        ));
        if (!empty($assoc_args['process'])) {
            $this->queue(array(), array('batches' => 0));
        }
    }

    /**
     * Force a Google glossary re-sync for all needed language pairs.
     *
     * Only meaningful with the Google engine: OpenAI receives the glossary
     * inline in the prompt, so there is nothing to push.
     *
     * @subcommand glossary-sync
     */
    public function glossary_sync($args, $assoc_args) {
        twtr_glossary();
        if (!Twtr_Glossary::remote_sync_supported()) {
            WP_CLI::success(sprintf(
                'Motore attivo: %s. Il glossario viene applicato al momento della traduzione, nessuna sincronizzazione necessaria.',
                Twtr_Settings::provider_label()
            ));
            return;
        }
        foreach (Twtr_Glossary::needed_pairs() as $pair) {
            list($src, $tgt) = explode('-', $pair, 2);
            $result = Twtr_Glossary::sync_pair($src, $tgt);
            if (is_wp_error($result)) {
                WP_CLI::warning($pair . ': ' . $result->get_error_message());
            } else {
                WP_CLI::log($pair . ': sincronizzazione avviata.');
            }
        }
        Twtr_Glossary::refresh_sync();
        WP_CLI::success('Sync glossario completata (verifica lo stato nella pagina Glossario del sito).');
    }

    /**
     * Network-level credentials left by versions before 1.7.0.
     *
     * Since 1.7.0 every site translates only with its own key and the
     * network values are never read. They are not moved automatically
     * because the plugin cannot know which site a key belongs to: assign
     * them explicitly, then purge them from the network option.
     *
     * ## OPTIONS
     *
     * [--assign=<engine>]
     * : Copy the network credentials of this engine (openai|google) into the
     * site given with --url and select that engine for the site.
     *
     * [--purge]
     * : Delete every credential and the old network usage counter from the
     * network option.
     *
     * ## EXAMPLES
     *
     *     wp twtr legacy-keys
     *     wp twtr legacy-keys --assign=openai --url=https://example.com/
     *     wp twtr legacy-keys --purge
     *
     * @subcommand legacy-keys
     */
    public function legacy_keys($args, $assoc_args) {
        $legacy = get_site_option(Twtr_Settings::NETWORK_OPTION, array());
        $legacy = is_array($legacy) ? $legacy : array();
        $openai = isset($legacy['openai_api_key']) ? (string) $legacy['openai_api_key'] : '';
        $gjson  = isset($legacy['credentials_json']) ? (string) $legacy['credentials_json'] : '';
        $gpath  = isset($legacy['credentials_path']) ? (string) $legacy['credentials_path'] : '';
        $gdata  = $gjson !== '' ? json_decode($gjson, true) : null;

        if (!empty($assoc_args['assign'])) {
            $engine = sanitize_key($assoc_args['assign']);
            if ($engine === 'openai') {
                if ($openai === '') {
                    WP_CLI::error('Nessuna chiave OpenAI di rete da assegnare.');
                }
                Twtr_Settings::update_engine(array(
                    'provider'       => 'openai',
                    'openai_api_key' => $openai,
                    'openai_model'   => !empty($legacy['openai_model']) ? (string) $legacy['openai_model'] : 'gpt-4o-mini',
                ));
            } elseif ($engine === 'google') {
                if ($gjson === '' && $gpath === '') {
                    WP_CLI::error('Nessuna credenziale Google di rete da assegnare.');
                }
                Twtr_Settings::update_engine(array(
                    'provider'         => 'google',
                    'project_id'       => isset($legacy['project_id']) ? (string) $legacy['project_id'] : '',
                    'location'         => !empty($legacy['location']) ? (string) $legacy['location'] : 'us-central1',
                    'credentials_json' => $gjson,
                    'credentials_path' => $gpath,
                    'gcs_bucket'       => isset($legacy['gcs_bucket']) ? (string) $legacy['gcs_bucket'] : '',
                    // Glossaries are per site since 1.9.0: rebuild this site's
                    // resources from its own terms at the next queue run.
                    'glossary_state'          => isset($legacy['glossary_state']) ? (array) $legacy['glossary_state'] : array(),
                    'glossary_synced_version' => 0,
                ));
            } else {
                WP_CLI::error('--assign accetta openai oppure google.');
            }
            delete_transient('twtr_google_token');
            WP_CLI::success(sprintf('Credenziali %s assegnate a %s.', $engine, home_url('/')));
            return;
        }

        if (!empty($assoc_args['purge'])) {
            foreach (array('provider', 'openai_api_key', 'openai_model', 'openai_models', 'openai_models_at', 'project_id', 'location',
                'credentials_path', 'credentials_json', 'gcs_bucket', 'daily_char_limit', 'glossary_state') as $key) {
                unset($legacy[$key]);
            }
            update_site_option(Twtr_Settings::NETWORK_OPTION, $legacy);
            delete_site_option('twtr_usage');
            delete_site_transient('twtr_google_token');
            WP_CLI::success('Credenziali di rete eliminate: ogni sito usa solo le proprie.');
            return;
        }

        WP_CLI::log('OpenAI di rete: ' . ($openai !== '' ? 'chiave …' . substr($openai, -4) : 'nessuna'));
        WP_CLI::log('Google di rete: ' . (is_array($gdata) && !empty($gdata['client_email'])
            ? $gdata['client_email'] . (!empty($legacy['project_id']) ? ' (progetto ' . $legacy['project_id'] . ')' : '')
            : ($gpath !== '' ? 'file ' . $gpath : 'nessuna')));
        WP_CLI::log('Queste credenziali non vengono piu\' usate: assegnale al sito a cui appartengono con --assign, poi eliminale con --purge.');
    }

    /**
     * Import the translations of a WPML site (run while WPML is active).
     *
     * ## OPTIONS
     *
     * [--dry-run]
     * : Count and report only, write nothing.
     *
     * [--step=<step>]
     * : Only one step: posts, terms, media, strings, redirects.
     *
     * [--configure-languages]
     * : Set tW default and extra languages from WPML first.
     *
     * [--include-trashed]
     * : Also read WPML translations already in the trash (re-import after the cleanup).
     *
     * [--undo]
     * : Delete everything imported from WPML (entries, slug map, redirects).
     *
     * @subcommand wpml-import
     */
    public function wpml_import($args, $assoc_args) {
        require_once TWTR_DIR . 'includes/class-twtr-wpml.php';
        if (!empty($assoc_args['undo'])) {
            WP_CLI::success(sprintf('Rimosse %d voci importate da WPML, mappa slug e redirect.', Twtr_Wpml::undo()));
            return;
        }
        if (!Twtr_Wpml::available()) {
            WP_CLI::error('Nessun dato WPML su questo sito.');
        }
        if (!empty($assoc_args['configure-languages'])) {
            $c = Twtr_Wpml::configure_languages();
            WP_CLI::log('Lingue tW: predefinita ' . $c['default'] . ', altre ' . implode(', ', $c['extra']));
        }
        if (!Twtr_Settings::extra_languages()) {
            WP_CLI::error('Nessuna lingua aggiuntiva configurata in tW: usa --configure-languages.');
        }
        $dry   = !empty($assoc_args['dry-run']);
        Twtr_Wpml::$include_trashed = !empty($assoc_args['include-trashed']);
        $steps = !empty($assoc_args['step']) ? array((string) $assoc_args['step']) : Twtr_Wpml::steps();
        foreach ($steps as $step) {
            $offset = 0;
            $sum    = array();
            do {
                $res = Twtr_Wpml::run_step($step, $offset, $dry);
                foreach ($res['stats'] as $k => $v) {
                    $sum[$k] = is_int($v) ? (int) ($sum[$k] ?? 0) + $v : array_merge((array) ($sum[$k] ?? array()), (array) $v);
                }
                $offset = $res['next'];
            } while (!$res['done']);
            $line = array();
            foreach ($sum as $k => $v) {
                $line[] = $k . '=' . (is_array($v) ? count($v) : $v);
            }
            WP_CLI::log(sprintf('[%s] %s%s', $step, implode(' ', $line), $dry ? ' (dry-run)' : ''));
            foreach (array('no_default_list', 'mismatch_list', 'list') as $k) {
                if (!empty($sum[$k])) {
                    foreach (array_slice($sum[$k], 0, 15) as $row) {
                        WP_CLI::log('    ' . $row);
                    }
                    if (count($sum[$k]) > 15) {
                        WP_CLI::log('    … +' . (count($sum[$k]) - 15));
                    }
                }
            }
        }
        WP_CLI::success($dry ? 'Simulazione completata.' : 'Import completato.');
    }

    /**
     * WPML «translations» identical to the original sentence (never
     * translated in WPML), imported as locked by versions before 1.22.2:
     * they keep the default language on the translated pages.
     *
     * ## OPTIONS
     *
     * [--delete]
     * : Delete them: the pages queue the texts and the engine translates them.
     *
     * @subcommand wpml-identical
     */
    public function wpml_identical($args, $assoc_args) {
        require_once TWTR_DIR . 'includes/class-twtr-wpml.php';
        $delete = !empty($assoc_args['delete']);
        $n      = Twtr_Wpml::identical_entries($delete);
        if ($delete) {
            WP_CLI::success(sprintf('%d voci identiche all\'originale eliminate: verranno tradotte dal motore.', $n));
        } else {
            WP_CLI::log(sprintf('%d voci importate da WPML sono identiche all\'originale (frasi mai tradotte in WPML). Rilancia con --delete per farle tradurre.', $n));
        }
    }

    /**
     * Find translated URL segments that lead to the wrong page.
     *
     * In each language a translated segment must lead back to exactly one
     * original and must not be an original slug itself. Two originals with
     * the same translation (DE «hose» for a product and a category), or a
     * translation equal to another page's slug, send visitors to the wrong
     * page or to a 404. Without --fix nothing is changed.
     *
     * ## OPTIONS
     *
     * [--fix]
     * : Give the later claimant «<translation>-<lang>» and save the map.
     *   Old URLs of renamed segments that now answer 404 are not redirected
     *   automatically: re-run `wp twtr wpml-import --step=redirects` while the
     *   WPML tables are still there.
     *
     * ## EXAMPLES
     *
     *     wp twtr slugs-check --url=https://example.com/
     *
     * @subcommand slugs-check
     */
    public function slugs_check($args, $assoc_args) {
        if (class_exists('Twtr_Wpml') === false && file_exists(TWTR_DIR . 'includes/class-twtr-wpml.php')) {
            require_once TWTR_DIR . 'includes/class-twtr-wpml.php';
        }
        $fix     = !empty($assoc_args['fix']);
        $changes = Twtr_Slugs::check_map($fix);
        if (!$changes) {
            WP_CLI::success('Nessun segmento tradotto ambiguo.');
            return;
        }
        foreach ($changes as $c) {
            WP_CLI::log(sprintf('%s  %s → %s  (ora %s: %s)', $c['lang'], $c['orig'], $c['to'], $c['from'], $c['reason']));
        }
        if ($fix) {
            WP_CLI::success(sprintf('%d segmenti resi univoci.', count($changes)));
        } else {
            WP_CLI::warning(sprintf('%d segmenti ambigui: rilancia con --fix per correggerli.', count($changes)));
        }
    }

    /**
     * Find stored translations that break a page or show nonsense.
     *
     * Two kinds. A translation whose placeholders (%s, %d…) are not those
     * of the original: the theme hands it to sprintf() and the page stops
     * with an error (the plugin now shows the original instead, but the
     * entry is still wrong). And an entry whose original was already in the
     * target language: a translation that was translated a second time.
     *
     * Without options nothing is changed.
     *
     * ## OPTIONS
     *
     * [--fix]
     * : Restore the placeholders where it can be done safely; send the other
     * entries back to the queue. Manual translations are only listed.
     *
     * [--delete-retranslated]
     * : Delete the entries whose original was already in the target language.
     *
     * [--limit=<n>]
     * : Rows printed per kind.
     * ---
     * default: 30
     * ---
     *
     * ## EXAMPLES
     *
     *     wp twtr check --url=https://example.com/
     *     wp twtr check --fix --url=https://example.com/
     *
     * @subcommand check
     */
    public function check($args, $assoc_args) {
        global $wpdb;
        $table   = Twtr_Storage::entries_table();
        $blog_id = get_current_blog_id();
        $fix     = !empty($assoc_args['fix']);
        $delete  = !empty($assoc_args['delete-retranslated']);
        $limit   = max(1, (int) ($assoc_args['limit'] ?? 30));
        $short   = function ($text) {
            $text = trim(preg_replace('/\s+/u', ' ', wp_strip_all_tags((string) $text)));
            return mb_strlen($text) > 70 ? mb_substr($text, 0, 70) . '…' : $text;
        };
        $touched = array();

        // 1. Placeholders.
        $rows = $wpdb->get_results($wpdb->prepare(
            "SELECT id, context_key, target_locale, source_text, translated_text, locked FROM {$table}
             WHERE blog_id = %d AND source_text LIKE %s AND translated_text IS NOT NULL AND translated_text <> ''",
            $blog_id, '%' . $wpdb->esc_like('%') . '%'
        ));
        $bad = array();
        foreach ($rows as $row) {
            if (Twtr_Placeholders::has($row->source_text) && !Twtr_Placeholders::same($row->source_text, $row->translated_text)) {
                $bad[] = $row;
            }
        }
        WP_CLI::log(sprintf('Traduzioni con segnaposto diversi dall’originale: %d', count($bad)));
        $repaired = 0;
        $requeued = 0;
        foreach ($bad as $i => $row) {
            $fixed = Twtr_Placeholders::repair($row->source_text, $row->translated_text);
            $what  = $row->locked ? 'manuale: da correggere a mano' : ($fixed !== null ? 'riparabile' : 'da ritradurre');
            if ($i < $limit) {
                WP_CLI::log(sprintf('  #%d [%s] %s | «%s» → «%s» (%s)', $row->id, $row->target_locale, $row->context_key, $short($row->source_text), $short($row->translated_text), $what));
            }
            if (!$fix || $row->locked) {
                continue;
            }
            if ($fixed !== null) {
                $wpdb->update($table, array('translated_text' => $fixed, 'updated_at' => current_time('mysql', true)), array('id' => (int) $row->id));
                $repaired++;
            } else {
                $wpdb->update($table, array('status' => 'pending', 'attempts' => 0, 'claim_token' => null, 'error_message' => null, 'updated_at' => current_time('mysql', true)), array('id' => (int) $row->id));
                $requeued++;
            }
            $touched[$row->target_locale . "\n" . $row->context_key] = array($row->target_locale, $row->context_key);
        }
        if (count($bad) > $limit) {
            WP_CLI::log('  … +' . (count($bad) - $limit));
        }

        // 2. Originals already in the target language (only where the two
        // languages use different alphabets: there it can be told for sure).
        $default = Twtr_Settings::default_lang();
        $locales = array_values(array_filter(Twtr_Settings::extra_languages(), array('Twtr_Placeholders', 'has_own_script')));
        $again = array();
        if ($locales) {
            $in   = implode(',', array_fill(0, count($locales), '%s'));
            $last = 0;
            do {
                $batch = $wpdb->get_results($wpdb->prepare(
                    "SELECT id, context_key, target_locale, LEFT(source_text, 400) AS source_text, LEFT(translated_text, 200) AS translated_text
                     FROM {$table} WHERE blog_id = %d AND id > %d AND target_locale IN ({$in}) ORDER BY id ASC LIMIT 2000",
                    array_merge(array($blog_id, $last), $locales)
                ));
                foreach ($batch as $row) {
                    $last = (int) $row->id;
                    if (Twtr_Placeholders::in_target_script(wp_strip_all_tags($row->source_text), $row->target_locale, $default)) {
                        $again[] = $row;
                    }
                }
            } while (count($batch) === 2000);
        }
        WP_CLI::log(sprintf('Voci il cui originale era già nella lingua di arrivo (tradotte due volte): %d', count($again)));
        foreach (array_slice($again, 0, $limit) as $row) {
            WP_CLI::log(sprintf('  #%d [%s] %s | «%s» → «%s»', $row->id, $row->target_locale, $row->context_key, $short($row->source_text), $short($row->translated_text)));
        }
        if (count($again) > $limit) {
            WP_CLI::log('  … +' . (count($again) - $limit));
        }
        $deleted = 0;
        if ($delete && $again) {
            foreach (array_chunk($again, 500) as $chunk) {
                $ids = array_map(function ($row) { return (int) $row->id; }, $chunk);
                $deleted += (int) $wpdb->query($wpdb->prepare(
                    "DELETE FROM {$table} WHERE blog_id = %d AND id IN (" . implode(',', array_fill(0, count($ids), '%d')) . ')',
                    array_merge(array($blog_id), $ids)
                ));
                foreach ($chunk as $row) {
                    $touched[$row->target_locale . "\n" . $row->context_key] = array($row->target_locale, $row->context_key);
                }
            }
        }

        foreach ($touched as $t) {
            Twtr_Resolver::flush_group($t[0], $t[1]);
            Twtr_Cache::purge_for_context($t[1], $t[0]);
        }
        if ($requeued > 0) {
            twtr_queue();
            Twtr_Queue::schedule();
        }
        if ($fix || $delete) {
            WP_CLI::success(sprintf('Riparate %d, rimesse in coda %d, eliminate %d.', $repaired, $requeued, $deleted));
        } elseif ($bad || $again) {
            WP_CLI::log('Niente è stato modificato. Con --fix si riparano i segnaposto; con --delete-retranslated si eliminano le voci tradotte due volte.');
        } else {
            WP_CLI::success('Nessuna traduzione da correggere.');
        }
    }
}
