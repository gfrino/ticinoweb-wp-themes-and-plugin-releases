<?php
/**
 * WooCommerce adapter (frontend, non-default language only).
 *
 * Product name, description and terms already flow through the generic
 * content filters; this adapter covers the Woo-specific display filters.
 * Everything technical — IDs, SKU, prices, stock, variations, attribute
 * keys, form values, cart, orders, sessions, endpoints, webhooks, payment
 * payloads — is intentionally left untouched: the same product object
 * serves every language.
 *
 * WooCommerce UI strings (buttons, notices, checkout labels) are covered by
 * the request-level locale switch, using the official Woo language packs.
 *
 * @package tw-translate-plus
 */

if (!defined('ABSPATH')) {
    exit;
}

class Twtr_Woo {

    /**
     * Register WooCommerce display filters.
     */
    public static function init() {
        add_filter('woocommerce_short_description', array(__CLASS__, 'short_description'), 20);
        add_filter('woocommerce_attribute_label', array(__CLASS__, 'attribute_label'), 20, 2);
        // Fee names (shipping surcharges, payment fees, rules of fee plugins
        // such as Pricepep Checkout Fees): renamed when the cart is computed,
        // so cart, checkout, AJAX fragments and the order all show the
        // customer's language. Name it in the default language in the fee
        // plugin; the other languages are translated here.
        add_action('woocommerce_cart_calculate_fees', array(__CLASS__, 'fees'), 999);
        // The mini cart is kept in the browser (sessionStorage) under a name
        // built from the site URL only, the same in every language: after a
        // visit in Italian, English pages showed «Subtotale», «Visualizza
        // carrello» and Italian product names until the cart changed. One
        // name per language, as WooCommerce Multilingual did.
        add_filter('woocommerce_cart_fragment_name', array(__CLASS__, 'per_language_key'), 20);
        add_filter('woocommerce_cart_hash_key', array(__CLASS__, 'per_language_key'), 20);
        // Never translate machine-facing requests: REST (incl. Store API,
        // which has no language prefix) and admin AJAX are excluded upstream
        // because the router only activates on prefixed frontend URLs.
    }

    /**
     * Browser storage key of the mini cart, per language.
     *
     * @param string $key
     * @return string
     */
    public static function per_language_key($key) {
        $lang = Twtr_Router::current_language();
        return ($lang !== '' && is_string($key) && $key !== '') ? $key . '_' . $lang : $key;
    }

    /**
     * Product short description.
     *
     * @param string $text Rendered short description HTML.
     * @return string
     */
    public static function short_description($text) {
        $post_id = get_the_ID();
        if (!$post_id || trim($text) === '') {
            return $text;
        }
        $context = 'product:' . (int) $post_id . ':short-description';
        // wpautop leaves a trailing newline that the stored text may not have.
        $trim = trim($text);
        if ($trim !== $text) {
            $found = Twtr_Resolver::find($trim, $context);
            if ($found !== null) {
                Twtr_Resolver::mark_emitted(Twtr_Router::current_language(), wptexturize($found));
                return $found;
            }
        }
        return Twtr_Resolver::translate($text, $context);
    }

    /**
     * Translate the names of the fees added to the cart.
     *
     * @param WC_Cart $cart
     */
    public static function fees($cart) {
        if (!is_object($cart) || !method_exists($cart, 'fees_api')) {
            return;
        }
        foreach ((array) $cart->fees_api()->get_fees() as $fee) {
            if (is_object($fee) && isset($fee->name) && is_string($fee->name) && trim($fee->name) !== '') {
                // Objects are shared with the cart: renaming here updates it.
                $fee->name = Twtr_Resolver::translate(trim(preg_replace('/\s+/u', ' ', $fee->name)), 'woo:fee');
            }
        }
    }

    /**
     * Attribute label as displayed (the attribute slug/key is untouched).
     *
     * @param string $label
     * @param string $name  Attribute slug.
     * @return string
     */
    public static function attribute_label($label, $name = '') {
        if (!is_string($label) || $label === '') {
            return $label;
        }
        return Twtr_Resolver::translate($label, 'woo:attribute:' . sanitize_key($name) . ':label');
    }
}
