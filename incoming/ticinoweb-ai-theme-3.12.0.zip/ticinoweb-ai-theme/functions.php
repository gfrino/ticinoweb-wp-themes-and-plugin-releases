<?php
define('TICINOWEB_THEME_VERSION', wp_get_theme( get_template() )->get('Version'));

/**
 * Handle database initialization and updates
 */
function ticinoweb_init_database() {
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();
    $table_name = $wpdb->prefix . 'ticinoweb_form_submissions';

    $sql = "CREATE TABLE $table_name (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        data_invio datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
        nome varchar(255) NOT NULL,
        email varchar(255) NOT NULL,
        telefono varchar(50) DEFAULT '' NOT NULL,
        oggetto varchar(255) DEFAULT '' NOT NULL,
        messaggio text NOT NULL,
        letto tinyint(1) DEFAULT 0 NOT NULL,
        PRIMARY KEY  (id),
        KEY data_invio (data_invio)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}
// Gate dbDelta: only run when DB schema version is outdated (not on every request)
add_action('after_setup_theme', function() {
    $installed = get_option('ticinoweb_db_version', '0');
    if (version_compare($installed, TICINOWEB_THEME_VERSION, '<')) {
        ticinoweb_init_database();
        update_option('ticinoweb_db_version', TICINOWEB_THEME_VERSION);
    }
});

// Theme setup: minimal, multisite-safe, ready for child themes
function ticinoweb_ai_setup()
{
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('html5', array('search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script'));
    register_nav_menus(array(
        'primary' => __('Menu Principale', 'ticinoweb-ai-theme'),
    ));
}
add_action('after_setup_theme', 'ticinoweb_ai_setup');

// Include translation compatibility layer first
require_once get_template_directory() . '/inc/translation-compat.php';

// Include admin settings and email handler
require_once get_template_directory() . '/inc/admin-settings.php';
require_once get_template_directory() . '/inc/email-handler.php';
require_once get_template_directory() . '/inc/form-handler.php';   // gestore AJAX form contatti per i child (3.10.0)
require_once get_template_directory() . '/inc/github-updater.php'; // aggiornamenti dal repo release GitHub (3.10.0)
require_once get_template_directory() . '/inc/shortcodes.php';
require_once get_template_directory() . '/inc/custom-post-labels.php';
require_once get_template_directory() . '/inc/custom-post-types.php';
require_once get_template_directory() . '/inc/media-galleries.php';
require_once get_template_directory() . '/inc/dashboard-stats.php';
require_once get_template_directory() . '/inc/image-upload-validation.php';
require_once get_template_directory() . '/inc/maintenance-mode.php';
require_once get_template_directory() . '/inc/duplicate-post.php';
require_once get_template_directory() . '/inc/google-reviews.php';
require_once get_template_directory() . '/inc/seo.php';
require_once get_template_directory() . '/inc/woocommerce.php'; // WC support, HPOS, Blocks — inherited by all child themes
// SVG Icons Library integration disabled - use ticinoWEB CMS > Icone SVG tab instead
// require_once get_template_directory() . '/inc/svg-icons-library.php';

// Preconnect to Google Fonts for improved LCP/TTFB performance (#7)
add_action('wp_head', function() {
    echo '<link rel="preconnect" href="https://fonts.googleapis.com">' . "\n";
    echo '<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>' . "\n";
}, 0);

// Enqueue assets (kept lean for performance)
function ticinoweb_ai_assets()
{
    // Google Font Poppins (elegant, modern, slim)
    wp_enqueue_style('poppins-font', 'https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap', array(), null);

    // Use TICINOWEB_THEME_VERSION for proper cache busting on updates (#6)
    wp_enqueue_style('ticinoweb-ai-style', get_stylesheet_uri(), array('poppins-font'), TICINOWEB_THEME_VERSION);
    wp_enqueue_script('ticinoweb-ai-main', get_template_directory_uri() . '/assets/js/main.js', array(), TICINOWEB_THEME_VERSION, true);
}
add_action('wp_enqueue_scripts', 'ticinoweb_ai_assets');

// ========================================
// LIGHTWEIGHT CMS - WordPress Customizer Integration
// ========================================

// Register Customizer sections for Site Identity, Slider and Contacts
function ticinoweb_ai_customizer($wp_customize)
{

    // ===== SITE IDENTITY (LOGO) =====
    $wp_customize->add_setting('site_logo', array(
        'default' => '',
        'transport' => 'refresh',
        'sanitize_callback' => 'esc_url_raw',
    ));
    $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, 'site_logo', array(
        'label' => __('Logo del Sito', 'ticinoweb-ai-theme'),
        'section' => 'title_tagline',
        'settings' => 'site_logo',
        'description' => 'Carica il logo del tuo sito. Formati supportati: PNG, SVG, JPG. Si consiglia PNG o SVG con sfondo trasparente, dimensione consigliata: altezza 60-80px.',
    )));

    // Slider Settings e Contatti sono stati spostati in ticinoWEB CMS
    // Vai in WordPress Admin → ticinoWEB CMS per gestire Slider e Contatti
}
add_action('customize_register', 'ticinoweb_ai_customizer');

// Helper functions to get customizer values (use anywhere in theme)
function ticinoweb_get_slider_data()
{
    $slides = array();

    // Try to get from ticinoWEB CMS first, then fallback to Customizer
    $count = (int) get_option('ticinoweb_slider_count');
    if (empty($count)) {
        $count = (int) get_theme_mod('slider_count', 3);
    }
    $count = max(1, min(5, $count));

    // Generic default contents — replace client-specific text with neutral placeholders (#11)
    $defaults = array(
        1 => array(
            'title'    => __('Slide 1', 'ticinoweb-ai-theme'),
            'desc'     => __('Descrizione della slide 1.', 'ticinoweb-ai-theme'),
            'btn_text' => __('Scopri di più', 'ticinoweb-ai-theme'),
            'btn_link' => '#servizi',
        ),
        2 => array(
            'title'    => __('Slide 2', 'ticinoweb-ai-theme'),
            'desc'     => __('Descrizione della slide 2.', 'ticinoweb-ai-theme'),
            'btn_text' => __('Contattaci', 'ticinoweb-ai-theme'),
            'btn_link' => '#contatti',
        ),
        3 => array(
            'title'    => __('Slide 3', 'ticinoweb-ai-theme'),
            'desc'     => __('Descrizione della slide 3.', 'ticinoweb-ai-theme'),
            'btn_text' => __('Chi Siamo', 'ticinoweb-ai-theme'),
            'btn_link' => '#chi-siamo',
        ),
        4 => array(
            'title'    => __('Slide 4', 'ticinoweb-ai-theme'),
            'desc'     => __('Descrizione della slide 4.', 'ticinoweb-ai-theme'),
            'btn_text' => __('Scopri di più', 'ticinoweb-ai-theme'),
            'btn_link' => '#servizi',
        ),
        5 => array(
            'title'    => __('Slide 5', 'ticinoweb-ai-theme'),
            'desc'     => __('Descrizione della slide 5.', 'ticinoweb-ai-theme'),
            'btn_text' => __('Informazioni', 'ticinoweb-ai-theme'),
            'btn_link' => '#info',
        ),
    );

    for ($i = 1; $i <= $count; $i++) {
        // Try get_option first, then get_theme_mod
        $image = get_option("ticinoweb_slider_image_$i") ?: get_theme_mod("slider_image_$i");
        if (empty($image))
            continue;

        $default = isset($defaults[$i]) ? $defaults[$i] : array('title' => '', 'desc' => '', 'btn_text' => '', 'btn_link' => '');

        $raw_title    = get_option("ticinoweb_slider_title_$i") ?: get_theme_mod("slider_title_$i", $default['title']);
        $raw_desc     = get_option("ticinoweb_slider_desc_$i") ?: get_theme_mod("slider_desc_$i", $default['desc']);
        $raw_btn_text = get_option("ticinoweb_slider_btn_text_$i") ?: get_theme_mod("slider_btn1_text_$i", $default['btn_text']);
        $raw_btn_link = get_option("ticinoweb_slider_btn_link_$i") ?: get_theme_mod("slider_btn1_link_$i", $default['btn_link']);

        $slides[] = array(
            'image'     => $image,
            'title'     => ticinoweb_frontend_text($raw_title, "theme:slider:{$i}:title"),
            'desc'      => ticinoweb_frontend_text($raw_desc, "theme:slider:{$i}:description"),
            'btn1_text' => ticinoweb_frontend_text($raw_btn_text, "theme:slider:{$i}:btn_text"),
            'btn1_link' => ticinoweb_frontend_url($raw_btn_link, "theme:slider:{$i}:btn_link"),
        );
    }
    return $slides;
}

function ticinoweb_get_contact_info()
{
    // Static cache to avoid repeated get_option() calls per request (#8)
    static $cache = null;
    if ($cache !== null) {
        return $cache;
    }

    $phone = get_option('ticinoweb_contact_phone');
    $phone_display = get_option('ticinoweb_contact_phone_display');
    if (empty($phone) && !empty($phone_display)) {
        $phone = $phone_display;
    }

    // Fix: removed hardcoded client emails/addresses as fallbacks (#12)
    $cache = array(
        'phone'              => $phone ?: get_theme_mod('contact_phone', ''),
        'phone_landline'     => get_option('ticinoweb_contact_phone_landline', ''),
        'phone_mobile'       => get_option('ticinoweb_contact_phone_mobile', ''),
        'email'              => get_option('ticinoweb_contact_email') ?: get_theme_mod('contact_email', ''),
        'email_2'            => get_option('ticinoweb_contact_email_2', ''),
        'email_3'            => get_option('ticinoweb_contact_email_3', ''),
        'address'            => ticinoweb_frontend_text(get_option('ticinoweb_contact_address') ?: get_theme_mod('contact_address', ''), 'theme:contact:address'),
        'facebook'           => get_option('ticinoweb_contact_facebook') ?: get_theme_mod('contact_facebook', ''),
        'instagram'          => get_option('ticinoweb_contact_instagram') ?: get_theme_mod('contact_instagram', ''),
        'linkedin'           => get_option('ticinoweb_contact_linkedin') ?: get_theme_mod('contact_linkedin', ''),
        'opening_hours'      => get_option('ticinoweb_contact_opening_hours', array()),
        'opening_hours_note' => ticinoweb_frontend_text(get_option('ticinoweb_contact_opening_hours_note', ''), 'theme:contact:hours_note'),
    );
    return $cache;
}

/**
 * Render one day's opening hours as a display string.
 *
 * Consumers used to read `slots` directly, which silently produced an empty string
 * for a day flagged as open around the clock (a 24-hour day deliberately carries no
 * slots). Child themes should call this rather than formatting slots themselves.
 *
 * @param array  $day_data One day out of `ticinoweb_contact_opening_hours`.
 * @param string $separator Placed between multiple slots.
 * @return string e.g. "24 ore", "Chiuso", "08:30 – 12:00, 14:00 – 18:00".
 */
function ticinoweb_format_day_hours($day_data, $separator = ', ') {
    if (!is_array($day_data)) {
        return '';
    }

    if (!empty($day_data['closed'])) {
        return __('Chiuso', 'ticinoweb-ai-theme');
    }

    if (!empty($day_data['open_24h'])) {
        return __('24 ore', 'ticinoweb-ai-theme');
    }

    $slots = isset($day_data['slots']) && is_array($day_data['slots']) ? $day_data['slots'] : array();
    $parts = array();

    foreach ($slots as $slot) {
        $open  = isset($slot['open']) ? trim((string) $slot['open']) : '';
        $close = isset($slot['close']) ? trim((string) $slot['close']) : '';

        if ($open === '' && $close === '') {
            continue;
        }

        $parts[] = ($open !== '' && $close !== '') ? $open . ' – ' . $close : $open . $close;
    }

    return $parts ? implode($separator, $parts) : '';
}

/**
 * Is the business open 24/7 — every day flagged as round-the-clock?
 *
 * @return bool
 */
function ticinoweb_is_open_24_7() {
    $hours = get_option('ticinoweb_contact_opening_hours', array());

    if (!is_array($hours) || count($hours) < 7) {
        return false;
    }

    foreach ($hours as $day_data) {
        if (empty($day_data['open_24h'])) {
            return false;
        }
    }

    return true;
}

// Helper function to get site logo
function ticinoweb_get_site_logo()
{
    // Prefer option set via ticinoWEB CMS Look & Feel tab, fallback to Customizer theme_mod
    $logo = get_option('ticinoweb_site_logo');
    if (empty($logo)) {
        $logo = get_theme_mod('site_logo', '');
    }
    return !empty($logo) ? $logo : false;
}

/**
 * Customize the standard WordPress login page logo and link properties
 * using the branding logo set inside ticinoWEB CMS.
 */
function ticinoweb_custom_login_logo() {
    $logo_url = function_exists('ticinoweb_get_site_logo') ? ticinoweb_get_site_logo() : false;
    if ( $logo_url ) {
        ?>
        <style type="text/css">
            #login h1 a, .login h1 a {
                background-image: url("<?php echo esc_url($logo_url); ?>") !important;
                background-size: contain !important;
                width: 100% !important;
                height: 80px !important;
                background-position: center !important;
                margin-bottom: 20px !important;
            }
        </style>
        <?php
    }
}
add_action( 'login_enqueue_scripts', 'ticinoweb_custom_login_logo' );

function ticinoweb_custom_login_logo_url() {
    return home_url();
}
add_filter( 'login_headerurl', 'ticinoweb_custom_login_logo_url' );

function ticinoweb_custom_login_logo_url_title() {
    return get_bloginfo( 'name' );
}
add_filter( 'login_headertext', 'ticinoweb_custom_login_logo_url_title' );
add_filter( 'login_headertitle', 'ticinoweb_custom_login_logo_url_title' );

// Helper function to get site icon/favicon
function ticinoweb_get_site_icon()
{
    // Prefer option set via ticinoWEB CMS Look & Feel tab ("Icona (favicon)")
    $icon = get_option('ticinoweb_site_icon');
    return !empty($icon) ? $icon : false;
}

// Add favicon to wp_head with dynamic MIME type support for any image format
// Remove WordPress default favicon and site icon to avoid conflicts
remove_action('wp_head', 'wp_site_icon');

add_action('wp_head', 'ticinoweb_add_favicon', 1);
function ticinoweb_add_favicon()
{
    $favicon = ticinoweb_get_site_icon();
    if ($favicon) {
        // Detect file extension and set appropriate MIME type
        $ext = strtolower(pathinfo($favicon, PATHINFO_EXTENSION));
        $mime_types = array(
            'ico' => 'image/x-icon',
            'png' => 'image/png',
            'jpg' => 'image/jpeg',
            'jpeg' => 'image/jpeg',
            'gif' => 'image/gif',
            'svg' => 'image/svg+xml',
            'webp' => 'image/webp',
        );
        $type = $mime_types[$ext] ?? 'image/x-icon';
        echo '<link rel="icon" type="' . esc_attr($type) . '" href="' . esc_url($favicon) . '">' . PHP_EOL;
    }
}

/**
 * Get page ID from page mapping
 * @param string $key The mapping key (e.g., 'page_contatti', 'page_slider', 'archive_referenze')
 * @return int|false Page ID or false if not set
 */
function ticinoweb_get_mapped_page_id($key)
{
    $mapping = get_option('ticinoweb_page_mapping', []);
    $page_id = $mapping[$key] ?? 0;

    return !empty($page_id) ? (int) $page_id : false;
}

/**
 * Get page URL from page mapping
 * @param string $key The mapping key
 * @return string|false Page URL or false if not set
 */
function ticinoweb_get_mapped_page_url($key)
{
    $page_id = ticinoweb_get_mapped_page_id($key);
    $url = $page_id ? get_permalink($page_id) : false;
    return $url ? ticinoweb_frontend_url($url, "theme:url:page_mapping_{$key}") : false;
}
/**
 * Auto-add shortcodes when pages are mapped in ticinoWEB CMS
 * Intercepts page mapping updates and adds the appropriate shortcode
 */
function ticinoweb_auto_add_page_shortcodes($old_value, $new_value)
{
    if (!is_array($new_value)) {
        return;
    }

    $old_value = is_array($old_value) ? $old_value : [];

    // Mapping of page keys to shortcode suffixes (without double prefix)
    $shortcode_map = array(
        'page_contatti' => 'contatti',
        'page_chi_siamo' => 'chi_siamo',
        'page_slider' => 'slider',
        'page_servizi' => 'servizi',
    );

    $remove_shortcode_from_page = function ($page_id, $shortcode_tag) {
        if (empty($page_id)) {
            return;
        }

        $page_content = get_post_field('post_content', $page_id);
        if (empty($page_content)) {
            return;
        }

        $pattern = '/\[\s*' . preg_quote($shortcode_tag, '/') . '(\s+[^\]]*)?\s*\]/i';
        $updated_content = preg_replace($pattern, '', $page_content);
        if ($updated_content !== $page_content) {
            $updated_content = trim($updated_content);
            wp_update_post(array(
                'ID' => $page_id,
                'post_content' => $updated_content,
            ));
        }
    };

    $ensure_shortcode_on_page = function ($page_id, $shortcode_tag) {
        if (empty($page_id)) {
            return;
        }

        $shortcode = '[' . $shortcode_tag . ']';
        $page_content = get_post_field('post_content', $page_id);
        $fixed_content = str_replace('ticinoweb_ticinoweb_', 'ticinoweb_', $page_content);
        if ($fixed_content !== $page_content) {
            wp_update_post(array(
                'ID' => $page_id,
                'post_content' => $fixed_content,
            ));
            $page_content = $fixed_content;
        }

        if (strpos($page_content, $shortcode) === false) {
            $new_content = trim($page_content);
            if ($new_content === '') {
                $new_content = $shortcode;
            } else {
                $new_content .= "\n\n" . $shortcode;
            }

            wp_update_post(array(
                'ID' => $page_id,
                'post_content' => $new_content,
            ));
        }
    };

    // Check each page key
    foreach ($shortcode_map as $page_key => $shortcode_suffix) {
        $old_page_id = $old_value[$page_key] ?? 0;
        $new_page_id = $new_value[$page_key] ?? 0;
        $shortcode_tag = 'ticinoweb_' . $shortcode_suffix;

        // If a new page was selected (or changed)
        if (!empty($new_page_id) && $new_page_id != $old_page_id) {
            $ensure_shortcode_on_page($new_page_id, $shortcode_tag);
        }

        // If mapping removed or changed away, remove shortcode from old page
        if (!empty($old_page_id) && (empty($new_page_id) || $new_page_id != $old_page_id)) {
            $remove_shortcode_from_page($old_page_id, $shortcode_tag);
        }
    }

    // Also check for Custom Post Type archives
    $cpts = get_option('ticinoweb_custom_post_types', []);
    if (!empty($cpts)) {
        foreach ($cpts as $cpt) {
            $cpt_slug = $cpt['slug'];
            $mapping_key = "archive_" . $cpt_slug;

            $old_page_id = $old_value[$mapping_key] ?? 0;
            $new_page_id = $new_value[$mapping_key] ?? 0;
            $shortcode_tag = 'ticinoweb_' . $cpt_slug . '_archive';

            if (!empty($new_page_id) && $new_page_id != $old_page_id) {
                $ensure_shortcode_on_page($new_page_id, $shortcode_tag);
            }

            if (!empty($old_page_id) && (empty($new_page_id) || $new_page_id != $old_page_id)) {
                $remove_shortcode_from_page($old_page_id, $shortcode_tag);
            }
        }
    }
}
add_action('update_option_ticinoweb_page_mapping', 'ticinoweb_auto_add_page_shortcodes', 10, 2);

// Apply optional page background image (global or specific page)
add_action('wp_head', 'ticinoweb_apply_page_background_image');
function ticinoweb_apply_page_background_image()
{
    if (is_admin()) {
        return;
    }

    $bg_image = get_option('ticinoweb_page_bg_image', '');
    if (empty($bg_image)) {
        return;
    }

    $scope = get_option('ticinoweb_page_bg_scope', 'all');
    $target_page_id = (int) get_option('ticinoweb_page_bg_page_id', 0);
    $current_id = get_queried_object_id();

    if ($scope === 'specific' && $target_page_id > 0 && $current_id !== $target_page_id) {
        return;
    }

    if ($scope === 'specific' && $target_page_id === 0) {
        return;
    }

    // Use double-quoted CSS url() to prevent CSS injection from URLs containing ')  (#2)
    $bg_url = esc_url($bg_image);
    // Show a subtle overlay in the top-right only, without covering the entire page
    echo '<style>
    body { position: relative; }
    body::before {
        content: \'\'; position: fixed; top: 0; right: 0;
        width: clamp(220px, 36vw, 520px); height: clamp(220px, 36vw, 520px);
        background-image: url("' . $bg_url . '");
        background-repeat: no-repeat; background-position: top right; background-size: contain;
        opacity: 0.08; pointer-events: none; z-index: 0;
    }
    </style>';
}

// ========================================
// ACTION HOOKS FOR CHILD THEMES
// ========================================
// I hook sono eseguiti nei template (front-page.php/footer.php), non qui.

/**
 * Disable WordPress Speculation Rules API in admin and wp-admin pages
 * to prevent 404 errors from prefetch requests with query parameters.
 * Removed noindex injection for logged-in users — caused SEO damage on public pages (#3).
 */
add_filter('wp_enqueue_scripts', 'ticinoweb_disable_speculation_rules_admin', 999);
function ticinoweb_disable_speculation_rules_admin()
{
    if (is_admin() || strpos($_SERVER['REQUEST_URI'], '/wp-admin/') !== false) {
        wp_dequeue_script('wp-speculation-rules');
    }
}

// ========================================
// COMMENT DISABLING FEATURE
// ========================================
// Blocks ALL comments site-wide when ticinoweb_disable_comments option is enabled (default: on)

add_filter('comments_open', 'ticinoweb_filter_comments_open', 10, 2);
function ticinoweb_filter_comments_open($open, $post_id)
{
    if (get_option('ticinoweb_disable_comments', 1)) {
        return false;
    }
    return $open;
}

add_filter('pings_open', 'ticinoweb_filter_pings_open', 10, 2);
function ticinoweb_filter_pings_open($open, $post_id)
{
    if (get_option('ticinoweb_disable_comments', 1)) {
        return false;
    }
    return $open;
}

add_filter('pre_comment_approved', 'ticinoweb_filter_comment_approved', 10, 1);
function ticinoweb_filter_comment_approved($approved)
{
    if (get_option('ticinoweb_disable_comments', 1)) {
        return 'spam';
    }
    return $approved;
}

// Hide Comments menu from WordPress admin when disabled
add_action('admin_menu', 'ticinoweb_hide_comments_menu', 999);
function ticinoweb_hide_comments_menu()
{
    if (get_option('ticinoweb_disable_comments', 1) && current_user_can('manage_options')) {
        remove_menu_page('edit-comments.php');
    }
}

// Hide Comments column from posts list
add_filter('manage_posts_columns', 'ticinoweb_remove_comments_column');
function ticinoweb_remove_comments_column($columns)
{
    if (get_option('ticinoweb_disable_comments', 1)) {
        unset($columns['comments']);
    }
    return $columns;
}

/**
 * Intelligent Brand Primary Color Extractor
 * Honors the manual color set in Look & Feel settings, otherwise extracts the dominant color from your site logo.
 * Caches in a transient for 24 hours for maximum performance.
 *
 * @return string Hex color code (e.g. '#4f46e5').
 */
function ticinoweb_get_brand_primary_color() {
    // 1. Honor manual primary color from Look & Feel settings first
    $primary = get_option('ticinoweb_palette_primary');
    if (!empty($primary)) {
        return $primary;
    }

    // 2. Return cached logo color if available
    $cached = get_transient('tw_logo_dominant_color');
    if ($cached !== false) {
        return $cached;
    }

    // 3. Fallback default primary color (indigo)
    $default_color = '#4f46e5';

    // 4. Try to fetch and extract color from site logo
    $logo_url = function_exists('ticinoweb_get_site_logo') ? ticinoweb_get_site_logo() : false;
    if (empty($logo_url)) {
        return $default_color;
    }

    // Fetch the logo file (remote or local)
    $response = wp_safe_remote_get($logo_url, array('timeout' => 3));
    if (!is_wp_error($response) && wp_remote_retrieve_response_code($response) === 200) {
        $body = wp_remote_retrieve_body($response);
        $ext = strtolower(pathinfo(parse_url($logo_url, PHP_URL_PATH), PATHINFO_EXTENSION));

        if ($ext === 'svg' || strpos($body, '<svg') !== false) {
            // Intelligent SVG Hex color regex extractor
            if (preg_match_all('/(?:fill|stroke)="\s*(#[a-fA-F0-9]{6}|#[a-fA-F0-9]{3})"/i', $body, $matches)) {
                foreach ($matches[1] as $color) {
                    $color = strtolower($color);
                    // Filter out common neutral colors
                    if (!in_array($color, array('#fff', '#ffffff', '#000', '#000000', '#eee', '#ccc', '#666', '#333', '#999', '#f8f9fa', '#eaeaea'), true)) {
                        set_transient('tw_logo_dominant_color', $color, DAY_IN_SECONDS);
                        return $color;
                    }
                }
            }
        } elseif (function_exists('imagecreatefromstring')) {
            // Intelligent PNG/JPEG downsample sampler
            $img = @imagecreatefromstring($body);
            if ($img) {
                $tmp = imagecreatetruecolor(1, 1);
                imagecopyresampled($tmp, $img, 0, 0, 0, 0, 1, 1, imagesx($img), imagesy($img));
                $rgb = imagecolorat($tmp, 0, 0);
                $r = ($rgb >> 16) & 0xFF;
                $g = ($rgb >> 8) & 0xFF;
                $b = $rgb & 0xFF;
                imagedestroy($img);
                imagedestroy($tmp);

                $hex = sprintf("#%02x%02x%02x", $r, $g, $b);
                
                // Keep if not excessively close to black
                if ($r > 20 || $g > 20 || $b > 20) {
                    set_transient('tw_logo_dominant_color', $hex, DAY_IN_SECONDS);
                    return $hex;
                }
            }
        }
    }

    // Cache fallback to prevent repetitive hits
    set_transient('tw_logo_dominant_color', $default_color, DAY_IN_SECONDS);
    return $default_color;
}

/**
 * Redirect 404 pages to the home page.
 *
 * INTENTIONAL DESIGN CHOICE — do NOT "fix" to a plain 404 without an explicit
 * client request. For ticinoWEB client sites this is the desired UX: a visitor
 * never lands on an error page, they are always sent back to the homepage.
 * This deliberately favours user experience over textbook 404 SEO handling.
 * See README "SEO & Routing Behaviour".
 */
function ticinoweb_redirect_404_to_home() {
    if ( is_404() ) {
        wp_safe_redirect( home_url( '/' ), 301 );
        exit;
    }
}
add_action( 'template_redirect', 'ticinoweb_redirect_404_to_home' );

// Include security enhancements
require_once get_template_directory() . '/inc/security.php';
require_once get_template_directory() . '/inc/passkeys.php';


