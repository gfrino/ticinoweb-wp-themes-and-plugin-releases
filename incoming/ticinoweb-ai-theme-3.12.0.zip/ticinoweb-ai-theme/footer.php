<?php
// Get contact info from Customizer
$contact = ticinoweb_get_contact_info();
?>
<footer class="site-footer" id="contatti">
    <div class="footer-container">
        <div class="footer-main">
            <div class="footer-brand">
                <h2 class="footer-brand-name"><?php echo esc_html(ticinoweb_frontend_text(get_bloginfo('name'), 'theme:branding:site_name')); ?></h2>
                <p class="footer-tagline"><?php echo esc_html(ticinoweb_frontend_text(get_bloginfo('description'), 'theme:branding:site_description')); ?></p>
                <?php do_action('ticinoweb_footer_brand_description'); ?>
            </div>
            
            <div class="footer-links">
                <h3><?php echo esc_html(ticinoweb_frontend_text(__('Servizi', 'ticinoweb-ai-theme'), 'theme:footer:services_title')); ?></h3>
                <ul>
                    <?php do_action('ticinoweb_footer_links'); ?>
                </ul>
                <?php if (function_exists('get_privacy_policy_url') && get_privacy_policy_url()): ?>
                <div class="footer-privacy-link" style="margin-top: 12px;">
                    <a href="<?php echo esc_url(ticinoweb_frontend_url(get_privacy_policy_url(), 'theme:url:privacy_policy')); ?>"><?php esc_html_e('Privacy Policy', 'ticinoweb-ai-theme'); ?></a>
                </div>
                <?php endif; ?>
            </div>
            
            <div class="footer-contact">
                <h3><?php echo esc_html(ticinoweb_frontend_text(__('Contatti', 'ticinoweb-ai-theme'), 'theme:footer:contact_title')); ?></h3>
                <ul class="footer-contact-list">
                    <?php if (!empty($contact['phone'])): ?>
                    <li>
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path></svg>
                        <a href="tel:<?php echo esc_attr(str_replace(' ', '', $contact['phone'])); ?>"><?php echo esc_html($contact['phone']); ?></a>
                    </li>
                    <?php endif; ?>
                    <?php if (!empty($contact['email'])): ?>
                    <li>
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path><polyline points="22,6 12,13 2,6"></polyline></svg>
                        <a href="mailto:<?php echo esc_attr($contact['email']); ?>"><?php echo esc_html($contact['email']); ?></a>
                    </li>
                    <?php endif; ?>
                    <?php if (!empty($contact['address'])): ?>
                    <li>
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path><circle cx="12" cy="10" r="3"></circle></svg>
                        <span><?php echo esc_html(ticinoweb_frontend_text($contact['address'], 'theme:contact:address')); ?></span>
                    </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
        
        <div class="footer-bottom">
            <div class="footer-bottom-content">
                <div class="footer-meta" style="display: flex; flex-wrap: wrap; gap: 12px; align-items: center;">
                    <span class="footer-copyright"><?php echo esc_html(ticinoweb_frontend_text(sprintf(__('© %s %s. Tutti i diritti riservati.', 'ticinoweb-ai-theme'), date('Y'), get_bloginfo('name')), 'theme:footer:copyright')); ?></span>
                    <span class="footer-backend"><a href="<?php echo esc_url(admin_url()); ?>"><?php esc_html_e('Backend', 'ticinoweb-ai-theme'); ?></a></span>
                    <span class="footer-design">Design by <a href="https://ticinoweb.com" target="_blank" rel="noopener">ticinoWEB</a></span>
                </div>
                <div class="footer-social">
                    <?php if (!empty($contact['instagram'])): ?>
                    <a href="<?php echo esc_url($contact['instagram']); ?>" target="_blank" rel="noopener" aria-label="Instagram">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/></svg>
                    </a>
                    <?php endif; ?>
                    <?php if (!empty($contact['facebook'])): ?>
                    <a href="<?php echo esc_url($contact['facebook']); ?>" target="_blank" rel="noopener" aria-label="Facebook">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>
                    </a>
                    <?php endif; ?>
                    <?php if (!empty($contact['linkedin'])): ?>
                    <a href="<?php echo esc_url($contact['linkedin']); ?>" target="_blank" rel="noopener" aria-label="LinkedIn">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor"><path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/></svg>
                    </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</footer>
<?php wp_footer(); ?>
</body>
</html>
