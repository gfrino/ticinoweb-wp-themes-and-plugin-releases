<?php
/**
 * Template Name: tW Full Width
 * Description: Page template full width con barra superiore titolo e overlay immagine
 */

get_header();

// Get theme settings
$overlay_image = get_option('ticinoweb_page_header_overlay_image', '');
$header_bg_color = get_option('ticinoweb_page_header_bg_color', '#6b9b6b');
$header_bg_image = get_option('ticinoweb_page_header_bg_image', '');
$gradient_enabled = get_option('ticinoweb_page_header_bg_gradient_enabled', '') === '1';
$gradient_color_1 = get_option('ticinoweb_page_header_bg_gradient_color_1', $header_bg_color);
$gradient_color_2 = get_option('ticinoweb_page_header_bg_gradient_color_2', '#4e7a4e');

$header_styles = [];
if ($gradient_enabled) {
    if (!empty($header_bg_image)) {
        $header_styles[] = "background-image: linear-gradient(135deg, {$gradient_color_1}, {$gradient_color_2}), url('" . esc_url($header_bg_image) . "')";
    } else {
        $header_styles[] = "background-image: linear-gradient(135deg, {$gradient_color_1}, {$gradient_color_2})";
    }
} elseif (!empty($header_bg_image)) {
    $header_styles[] = "background-image: url('" . esc_url($header_bg_image) . "')";
    $header_styles[] = "background-color: {$header_bg_color}";
} else {
    $header_styles[] = "background-color: {$header_bg_color}";
}

if (!empty($header_bg_image) || $gradient_enabled) {
    $header_styles[] = 'background-size: cover';
    $header_styles[] = 'background-position: center';
    $header_styles[] = 'background-repeat: no-repeat';
}

$header_style_attr = implode('; ', array_map('esc_attr', $header_styles));
?>

<main id="primary" class="site-main full-width-template">
    <?php
    while ( have_posts() ) :
        the_post();
        ?>
        
        <!-- Page Header Bar with Overlay -->
        <div class="page-header-bar" style="<?php echo $header_style_attr; ?>;">
            <?php if (!empty($overlay_image)): ?>
                <div class="page-header-overlay" style="background-image: url('<?php echo esc_url($overlay_image); ?>');"></div>
            <?php endif; ?>
            <div class="page-header-content">
                <h1 class="page-title"><?php the_title(); ?></h1>
            </div>
        </div>
        
        <article id="post-<?php the_ID(); ?>" <?php post_class('full-width-page'); ?>>
            
            <div class="entry-content full-width-content">
                <?php
                the_content();
                
                wp_link_pages(
                    array(
                        'before' => '<div class="page-links">' . esc_html__( 'Pagine:', 'ticinoweb-ai-theme' ),
                        'after'  => '</div>',
                    )
                );
                ?>
            </div>
            
        </article>
        
        <?php
        // Se i commenti sono aperti o ci sono commenti, carica il template
        if ( comments_open() || get_comments_number() ) :
            echo '<div class="container">';
            comments_template();
            echo '</div>';
        endif;
        
    endwhile;
    ?>
</main>

<?php
get_footer();
