<?php
/**
 * Fallback template
 */
get_header();
?>
<main class="container" style="padding:4rem 0;">
    <?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
        <article <?php post_class('default-article'); ?>>
            <h1><?php the_title(); ?></h1>
            <div class="entry-content">
                <?php the_content(); ?>
            </div>
        </article>
    <?php endwhile; else : ?>
        <p><?php echo esc_html(ticinoweb_frontend_text(__('Nessun contenuto disponibile.', 'ticinoweb-ai-theme'), 'theme:index:empty_message')); ?></p>
    <?php endif; ?>
</main>
<?php get_footer(); ?>
