<?php
/**
 * Template Name: Servizi per Categoria
 * Description: Template dinamico che mostra i servizi in base alla categoria
 */

get_header();
?>

<main class="site-main">
    <?php while (have_posts()) : the_post(); ?>
        <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
            <div class="full-width-content">
                <?php
                // Ottieni il titolo della pagina per mapparlo alla categoria
                $page_title = get_the_title();
                $category_slug = '';
                
                // Mappa titolo pagina -> slug categoria
                $category_map = [
                    'Cura degli alberi' => 'cura-alberi',
                    'Abbattimenti Speciali' => 'abbattimenti-speciali',
                    'Lavori forestali' => 'lavori-forestali'
                ];
                
                if (isset($category_map[$page_title])) {
                    $category_slug = $category_map[$page_title];
                }
                
                // Query servizi della categoria
                $args = [
                    'post_type' => 'post',
                    'posts_per_page' => -1,
                    'orderby' => 'menu_order title',
                    'order' => 'ASC'
                ];
                
                if ($category_slug) {
                    $args['category_name'] = $category_slug;
                }
                
                $servizi_query = new WP_Query($args);
                
                if ($servizi_query->have_posts()) :
                    echo '<div class="servizi-categoria-grid">';
                    
                    while ($servizi_query->have_posts()) : $servizi_query->the_post();
                        ?>
                        <div class="servizio-card-categoria">
                            <?php if (has_post_thumbnail()) : ?>
                                <div class="servizio-card-image">
                                    <?php the_post_thumbnail('medium_large'); ?>
                                    <div class="servizio-card-overlay"></div>
                                </div>
                            <?php endif; ?>
                            
                            <div class="servizio-card-content">
                                <h3 class="servizio-card-title"><?php the_title(); ?></h3>
                                
                                <div class="servizio-card-excerpt">
                                    <?php 
                                    if (has_excerpt()) {
                                        the_excerpt();
                                    } else {
                                        echo wp_trim_words(get_the_content(), 30, '...');
                                    }
                                    ?>
                                </div>
                                
                                <?php if (get_the_content()) : ?>
                                    <div class="servizio-card-full-content">
                                        <?php the_content(); ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                        <?php
                    endwhile;
                    
                    echo '</div>';
                    
                    wp_reset_postdata();
                else :
                    ?>
                    <div class="no-servizi">
                        <p><?php echo esc_html(ticinoweb_frontend_text(sprintf(__('Nessun servizio trovato per questa categoria. Aggiungi articoli dal backend con la categoria "%s".', 'ticinoweb-ai-theme'), $page_title), 'theme:services_category:empty_message', array('title' => $page_title))); ?></p>
                    </div>
                    <?php
                endif;
                ?>
            </div>
        </article>
    <?php endwhile; ?>
</main>

<?php get_footer(); ?>
