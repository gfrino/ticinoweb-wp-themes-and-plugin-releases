<?php
/**
 * Generic front page template for ticinoweb AI CMS
 * Fully customizable via Customizer; specific content is in child themes
 */

get_header();

// Get slider data from Customizer
$slides = ticinoweb_get_slider_data();
?>

<section class="hero-slider-wrapper">
    <div class="hero-slider">
        <div class="slider-track">
            <?php foreach ($slides as $index => $slide): 
                if (empty($slide['image'])) continue; // Skip slides without image
            ?>
            <div class="slide">
                <img src="<?php echo esc_url($slide['image']); ?>" alt="<?php echo esc_attr($slide['title']); ?>" class="slide-image">
                <div class="slide-overlay"></div>
                <div class="slide-content">
                    <h1><?php echo esc_html($slide['title']); ?></h1>
                    <p><?php echo esc_html($slide['desc']); ?></p>
                    <?php if (!empty($slide['btn1_text']) || !empty($slide['btn1_link'])): ?>
                    <div class="slider-buttons">
                        <?php if (!empty($slide['btn1_text'])): ?>
                        <a href="<?php echo esc_url($slide['btn1_link']); ?>" class="btn btn-primary"><?php echo esc_html($slide['btn1_text']); ?></a>
                        <?php endif; ?>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <button class="slider-arrow prev" aria-label="<?php echo esc_attr(ticinoweb_frontend_text(__('Slide precedente', 'ticinoweb-ai-theme'), 'theme:slider:prev_aria')); ?>">‹</button>
        <button class="slider-arrow next" aria-label="<?php echo esc_attr(ticinoweb_frontend_text(__('Slide successiva', 'ticinoweb-ai-theme'), 'theme:slider:next_aria')); ?>">›</button>
        <div class="slider-dots"></div>
    </div>
</section>

<section class="section-padding" id="servizi">
    <div class="container">
        <div class="section-header">
            <!-- Services section header and shortcode customized in child theme via ticinoweb_services_section hook -->
            <?php do_action('ticinoweb_services_section'); ?>
        </div>
    </div>
</section>

<!-- CTA Section: customized in child theme via ticinoweb_cta_section hook -->
<?php do_action('ticinoweb_cta_section'); ?>

<!-- About Section: customized in child theme via ticinoweb_about_section hook -->
<?php do_action('ticinoweb_about_section'); ?>

<?php
get_footer();
