<?php
/**
 * Duplicate Post/Page/CPT Feature for ticinoWEB AI Theme
 *
 * Adds a "Duplica" (or "Duplicate" in English) action link
 * in the row actions for all public post types (posts, pages, products, CPTs).
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Add "Duplicate" link to row actions for all post types
 */
add_filter('post_row_actions', 'ticinoweb_duplicate_post_link', 10, 2);
add_filter('page_row_actions', 'ticinoweb_duplicate_post_link', 10, 2);

function ticinoweb_duplicate_post_link($actions, $post) {
    if (!current_user_can('edit_posts')) {
        return $actions;
    }

    $locale = get_locale();
    $label = (strpos($locale, 'en') === 0) ? 'Duplicate' : 'Duplica';

    $url = wp_nonce_url(
        admin_url('admin.php?action=ticinoweb_duplicate_post&post=' . $post->ID),
        'ticinoweb_duplicate_' . $post->ID
    );

    $actions['duplicate'] = '<a href="' . esc_url($url) . '" title="' . esc_attr($label) . '">' . esc_html($label) . '</a>';

    return $actions;
}

/**
 * Handle the duplicate action
 */
add_action('admin_action_ticinoweb_duplicate_post', 'ticinoweb_duplicate_post_handler');

function ticinoweb_duplicate_post_handler() {
    if (!current_user_can('edit_posts')) {
        wp_die(__('Permessi insufficienti.', 'ticinoweb-ai-theme'));
    }

    $post_id = isset($_GET['post']) ? absint($_GET['post']) : 0;

    if (!$post_id) {
        wp_die(__('Post non trovato.', 'ticinoweb-ai-theme'));
    }

    // Verify nonce
    if (!isset($_GET['_wpnonce']) || !wp_verify_nonce($_GET['_wpnonce'], 'ticinoweb_duplicate_' . $post_id)) {
        wp_die(__('Errore di sicurezza.', 'ticinoweb-ai-theme'));
    }

    $post = get_post($post_id);

    if (!$post) {
        wp_die(__('Post non trovato.', 'ticinoweb-ai-theme'));
    }

    // Prepare new post data
    $locale = get_locale();
    $copy_label = (strpos($locale, 'en') === 0) ? '(Copy)' : '(Copia)';

    $new_post_data = array(
        'post_title'     => $post->post_title . ' ' . $copy_label,
        'post_content'   => $post->post_content,
        'post_excerpt'   => $post->post_excerpt,
        'post_status'    => 'draft',
        'post_type'      => $post->post_type,
        'post_author'    => get_current_user_id(),
        'post_parent'    => $post->post_parent,
        'post_password'  => $post->post_password,
        'comment_status' => $post->comment_status,
        'ping_status'    => $post->ping_status,
        'menu_order'     => $post->menu_order,
    );

    // Insert the new post
    $new_post_id = wp_insert_post($new_post_data);

    if (is_wp_error($new_post_id)) {
        wp_die($new_post_id->get_error_message());
    }

    // Duplicate all post meta
    $post_meta = get_post_meta($post_id);
    if ($post_meta) {
        foreach ($post_meta as $meta_key => $meta_values) {
            // Skip internal WordPress meta
            if ($meta_key === '_edit_lock' || $meta_key === '_edit_last') {
                continue;
            }
            foreach ($meta_values as $meta_value) {
                add_post_meta($new_post_id, $meta_key, maybe_unserialize($meta_value));
            }
        }
    }

    // Duplicate taxonomies (categories, tags, custom taxonomies)
    $taxonomies = get_object_taxonomies($post->post_type);
    if ($taxonomies) {
        foreach ($taxonomies as $taxonomy) {
            $terms = wp_get_object_terms($post_id, $taxonomy, array('fields' => 'ids'));
            if (!is_wp_error($terms) && !empty($terms)) {
                wp_set_object_terms($new_post_id, $terms, $taxonomy);
            }
        }
    }

    // Duplicate featured image
    $thumbnail_id = get_post_thumbnail_id($post_id);
    if ($thumbnail_id) {
        set_post_thumbnail($new_post_id, $thumbnail_id);
    }

    // Redirect to edit the new post
    wp_safe_redirect(admin_url('post.php?action=edit&post=' . $new_post_id));
    exit;
}
