<?php
/**
 * Google Reviews Integration logic
 * Handles fetching from Google Places API and storage in wp_options.
 */

if (!defined('ABSPATH')) exit;

/**
 * Language code sent to the Google Places API.
 *
 * Google translates the review text and the opening-hours strings into this
 * language, so it has to follow the site the content is displayed on — not the
 * language of this CMS. It was hardcoded to `it`, which asked Google for Italian
 * even on the English-language sites.
 *
 * With no explicit setting the site locale decides, so an untouched site starts
 * asking for the right language on its own. Google addresses most languages by
 * their primary subtag only — `it`, not `it-IT`, which it ignores — and documents
 * a short list of region-qualified exceptions, kept below.
 *
 * @return string A Google Places `language` value, e.g. `en`, `it`, `pt-BR`.
 */
function ticinoweb_google_places_language() {
    $override = get_option( 'ticinoweb_google_reviews_language', '' );

    if ( is_string( $override ) && $override !== '' ) {
        $lang = $override;
    } else {
        $regional = array( 'pt-BR', 'pt-PT', 'zh-CN', 'zh-TW', 'en-AU', 'en-GB', 'fr-CA' );
        $tag      = str_replace( '_', '-', get_locale() );

        $lang = in_array( $tag, $regional, true )
            ? $tag
            : strtolower( substr( get_locale(), 0, 2 ) );
    }

    /**
     * Filter the language requested from the Google Places API.
     *
     * @param string $lang Resolved language code.
     */
    $lang = apply_filters( 'ticinoweb_google_places_language', $lang );

    // A malformed value would make Google reject the whole request, so fall back
    // rather than pass it through.
    return preg_match( '/^[a-z]{2}(-[A-Za-z]{2})?$/', (string) $lang ) ? $lang : 'en';
}

/**
 * Fetch reviews from Google Places API and save to local options.
 * @return array|WP_Error Array of results or WP_Error on failure.
 */
function ticinoweb_pull_google_reviews() {
    $api_key = get_option('ticinoweb_google_api_key');
    $place_id = get_option('ticinoweb_google_place_id');

    if (empty($api_key) || empty($place_id)) {
        return new WP_Error('missing_config', __('API Key o Place ID mancante nelle impostazioni.', 'ticinoweb-ai-theme'));
    }

    $url = "https://maps.googleapis.com/maps/api/place/details/json?place_id=" . urlencode($place_id) . "&fields=reviews,rating,user_ratings_total&key=" . urlencode($api_key) . "&language=" . urlencode(ticinoweb_google_places_language());

    $response = wp_remote_get($url);

    if (is_wp_error($response)) {
        return $response;
    }

    $body = wp_remote_retrieve_body($response);
    $data = json_decode($body, true);

    if (empty($data) || $data['status'] !== 'OK') {
        $error_msg = isset($data['error_message']) ? $data['error_message'] : __('Errore API sconosciuto.', 'ticinoweb-ai-theme');
        return new WP_Error('api_error', $error_msg);
    }

    $result = $data['result'];
    $reviews = isset($result['reviews']) ? $result['reviews'] : [];
    
    // Store data locally
    update_option('ticinoweb_google_reviews_data', $reviews);
    update_option('ticinoweb_google_reviews_rating', $result['rating'] ?? 0);
    update_option('ticinoweb_google_reviews_count', $result['user_ratings_total'] ?? 0);
    update_option('ticinoweb_google_reviews_last_sync', current_time('mysql'));

    return [
        'count' => count($reviews),
        'rating' => $result['rating'] ?? 0,
        'total_reviews' => $result['user_ratings_total'] ?? 0
    ];
}

/**
 * AJAX handler for the manual sync button.
 */
add_action('wp_ajax_ticinoweb_sync_google_reviews', 'ticinoweb_ajax_sync_google_reviews');
function ticinoweb_ajax_sync_google_reviews() {
    check_ajax_referer('ticinoweb_reviews_nonce', 'nonce');

    if (!current_user_can('manage_options')) {
        wp_send_json_error(['message' => __('Permessi insufficienti.', 'ticinoweb-ai-theme')]);
    }

    $result = ticinoweb_pull_google_reviews();

    if (is_wp_error($result)) {
        wp_send_json_error(['message' => $result->get_error_message()]);
    } else {
        wp_send_json_success([
            'message' => sprintf(__('Sincronizzazione completata! %d recensioni importate.', 'ticinoweb-ai-theme'), $result['count']),
            'last_sync' => current_time('mysql')
        ]);
    }
}

/**
 * Get filtered google reviews for use in templates/shortcodes.
 * @param int $limit Number of reviews to return.
 * @param int $min_rating Minimum star rating filter.
 * @return array
 */
if (!function_exists('ticinoweb_get_google_reviews')) {
    function ticinoweb_get_google_reviews($limit = 5, $min_rating = 0) {
        $reviews = get_option('ticinoweb_google_reviews_data', []);
        
        if (empty($reviews)) {
            return [];
        }

        // Filter by rating
        if ($min_rating > 0) {
            $reviews = array_filter($reviews, function($review) use ($min_rating) {
                return isset($review['rating']) && $review['rating'] >= $min_rating;
            });
        }

        // Limit results
        if ($limit > 0) {
            $reviews = array_slice($reviews, 0, $limit);
        }

        return $reviews;
    }
}

/**
 * Shortcode [ticinoweb_google_reviews]
 */
function ticinoweb_google_reviews_shortcode($atts) {
    $default_min = get_option('ticinoweb_google_reviews_min_rating', 4);
    
    $a = shortcode_atts([
        'limit' => 5,
        'min_rating' => $default_min,
        'layout' => 'grid' // grid, list
    ], $atts);

    $reviews = ticinoweb_get_google_reviews($a['limit'], $a['min_rating']);
    $business_link = get_option('ticinoweb_google_business_link');
    $rating = get_option('ticinoweb_google_reviews_rating');
    $count = get_option('ticinoweb_google_reviews_count');

    if (empty($reviews)) {
        return '';
    }

    ob_start();
    ?>
    <div class="ticinoweb-reviews-container ticinoweb-reviews-layout-<?php echo esc_attr($a['layout']); ?>">
        <?php if ($rating > 0): ?>
        <div class="ticinoweb-reviews-header">
            <div class="ticinoweb-reviews-summary">
                <span class="rating-number"><?php echo number_format($rating, 1); ?></span>
                <div class="stars-display"><?php echo ticinoweb_render_stars($rating); ?></div>
                <span class="reviews-count">(<?php echo esc_html(ticinoweb_frontend_text(sprintf(__('%s recensioni', 'ticinoweb-ai-theme'), $count), 'theme:reviews:count_label', array('count' => $count))); ?>)</span>
            </div>
            <?php if ($business_link): ?>
            <a href="<?php echo esc_url($business_link); ?>" class="ticinoweb-reviews-cta" target="_blank" rel="nofollow">
                <?php echo esc_html(ticinoweb_frontend_text(__('Lascia una recensione', 'ticinoweb-ai-theme'), 'theme:reviews:cta_text')); ?>
            </a>
            <?php endif; ?>
        </div>
        <?php endif; ?>

        <div class="ticinoweb-reviews-grid">
            <?php foreach ($reviews as $review): ?>
            <div class="ticinoweb-review-card">
                <div class="review-author">
                    <?php if (!empty($review['profile_photo_url'])): ?>
                        <img src="<?php echo esc_url($review['profile_photo_url']); ?>" alt="<?php echo esc_attr($review['author_name']); ?>" class="author-photo">
                    <?php endif; ?>
                    <div class="author-info">
                        <span class="author-name"><?php echo esc_html($review['author_name']); ?></span>
                        <span class="review-date"><?php echo esc_html($review['relative_time_description']); ?></span>
                    </div>
                </div>
                <div class="review-rating">
                    <?php echo ticinoweb_render_stars($review['rating']); ?>
                </div>
                <div class="review-text">
                    <p><?php echo nl2br(esc_html($review['text'])); ?></p>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('ticinoweb_google_reviews', 'ticinoweb_google_reviews_shortcode');

/**
 * Helper to render star icons
 */
function ticinoweb_render_stars($rating) {
    $full = floor($rating);
    $half = ($rating - $full) >= 0.5 ? 1 : 0;
    $empty = 5 - ($full + $half);
    
    $output = '<div class="star-rating">';
    for ($i = 0; $i < $full; $i++) $output .= '<span class="dashicons dashicons-star-filled"></span>';
    if ($half) $output .= '<span class="dashicons dashicons-star-half"></span>';
    for ($i = 0; $i < $empty; $i++) $output .= '<span class="dashicons dashicons-star-empty"></span>';
    $output .= '</div>';
    
    return $output;
}

/**
 * AJAX handler to sync opening hours from Google Places API
 */
add_action('wp_ajax_ticinoweb_sync_google_hours', 'ticinoweb_sync_google_hours_handler');
function ticinoweb_sync_google_hours_handler() {
    check_ajax_referer('ticinoweb_admin_ajax_nonce', 'nonce');
    if (!current_user_can('edit_pages')) {
        wp_send_json_error(array('message' => __('Permessi insufficienti.', 'ticinoweb-ai-theme')));
    }

    $api_key = get_option('ticinoweb_google_api_key');
    $place_id = get_option('ticinoweb_google_place_id');

    if (empty($api_key) || empty($place_id)) {
        wp_send_json_error(array('message' => __('Configura prima la chiave API di Google e il Place ID nella scheda "Recensioni" per sincronizzare.', 'ticinoweb-ai-theme')));
    }

    $url = sprintf(
        'https://maps.googleapis.com/maps/api/place/details/json?place_id=%s&fields=opening_hours&key=%s&language=%s',
        urlencode($place_id),
        urlencode($api_key),
        urlencode(ticinoweb_google_places_language())
    );

    $response = wp_safe_remote_get($url, array('timeout' => 10));
    if (is_wp_error($response)) {
        wp_send_json_error(array('message' => $response->get_error_message()));
    }

    $body = wp_remote_retrieve_body($response);
    $data = json_decode($body, true);

    if (empty($data['result']['opening_hours'])) {
        $status = isset($data['status']) ? $data['status'] : 'Sconosciuto';
        $error_msg = isset($data['error_message']) ? $data['error_message'] : '';
        wp_send_json_error(array('message' => sprintf(__('Impossibile recuperare gli orari da Google. Stato: %s. %s', 'ticinoweb-ai-theme'), $status, $error_msg)));
    }

    $opening_hours = $data['result']['opening_hours'];
    
    // Mappa i giorni da 0-6 delle API di Google a chiavi testuali
    // 0 = Domenica, 1 = Lunedì, 2 = Martedì, 3 = Mercoledì, 4 = Giovedì, 5 = Venerdì, 6 = Sabato
    $day_mapping = array(
        1 => 'monday',
        2 => 'tuesday',
        3 => 'wednesday',
        4 => 'thursday',
        5 => 'friday',
        6 => 'saturday',
        0 => 'sunday'
    );

    $formatted_hours = array();
    foreach ($day_mapping as $g_day => $day_key) {
        $formatted_hours[$day_key] = array(
            'closed'   => 1,
            'open_24h' => 0,
            'slots'    => array()
        );
    }

    // Google expresses "always open" as a SINGLE period with open.day = 0,
    // open.time = "0000" and no `close` key at all. The per-period loop below
    // cannot represent that: it wrote 00:00 into Sunday's opening field, left the
    // closing field empty and left the other six days marked closed — which is
    // exactly what a 24/7 business got out of this button before.
    $periods = isset($opening_hours['periods']) && is_array($opening_hours['periods'])
        ? $opening_hours['periods']
        : array();

    $always_open = count($periods) === 1
        && isset($periods[0]['open']['time'])
        && $periods[0]['open']['time'] === '0000'
        && !isset($periods[0]['close']);

    if ($always_open) {
        foreach (array_keys($formatted_hours) as $day_key) {
            $formatted_hours[$day_key] = array(
                'closed'   => 0,
                'open_24h' => 1,
                'slots'    => array()
            );
        }

        wp_send_json_success($formatted_hours);
    }

    if (!empty($opening_hours['periods'])) {
        foreach ($opening_hours['periods'] as $period) {
            $open_day = isset($period['open']['day']) ? intval($period['open']['day']) : null;
            if ($open_day === null || !isset($day_mapping[$open_day])) {
                continue;
            }
            $day_key = $day_mapping[$open_day];
            
            $open_time = isset($period['open']['time']) ? $period['open']['time'] : ''; // formato "hhmm" (es. "0830")
            $close_time = isset($period['close']['time']) ? $period['close']['time'] : ''; // formato "hhmm"

            $open_formatted = '';
            if (strlen($open_time) === 4) {
                $open_formatted = substr($open_time, 0, 2) . ':' . substr($open_time, 2, 2);
            }
            
            $close_formatted = '';
            if (strlen($close_time) === 4) {
                $close_formatted = substr($close_time, 0, 2) . ':' . substr($close_time, 2, 2);
            }

            $formatted_hours[$day_key]['closed'] = 0;

            // A single day running midnight to midnight: Google sends open 0000 and
            // close 0000. Recording that as a slot would render as "00:00 – 00:00".
            if ($open_time === '0000' && $close_time === '0000') {
                $formatted_hours[$day_key]['open_24h'] = 1;
                $formatted_hours[$day_key]['slots']    = array();
                continue;
            }

            $formatted_hours[$day_key]['slots'][] = array(
                'open' => $open_formatted,
                'close' => $close_formatted
            );
        }
    }

    wp_send_json_success($formatted_hours);
}
