<?php
// Shortcode implementation for TicinoWEB Services
// Relies on ticinoweb_get_services() defined in inc/admin-settings.php

function ticinoweb_services_shortcode($atts) {
    if (!function_exists('ticinoweb_get_services')) {
        return '';
    }

    $services = ticinoweb_get_services();

    // Fallback: use child pages of the mapped Servizi page
    if (empty($services)) {
        $parent_id = function_exists('ticinoweb_get_mapped_page_id')
            ? ticinoweb_get_mapped_page_id('page_servizi')
            : 0;

        if (!$parent_id) {
            $servizi_page = get_page_by_path('servizi');
            $parent_id = $servizi_page ? $servizi_page->ID : 0;
        }

        if ($parent_id) {
            $child_pages = get_pages([
                'parent' => $parent_id,
                'sort_column' => 'menu_order,post_title',
                'sort_order' => 'ASC',
                'post_status' => 'publish',
            ]);

            if (!empty($child_pages)) {
                ob_start();
                ?>
                <div class="services-grid">
                    <?php foreach ($child_pages as $page): ?>
                        <?php
                        $thumb = get_the_post_thumbnail_url($page->ID, 'large');
                        $raw_excerpt = $page->post_excerpt;
                        $raw_content = $page->post_content;
                        $content_html = apply_filters('the_content', $raw_content);
                        $content_text = wp_strip_all_tags($content_html);
                        $excerpt_source = $raw_excerpt ? do_shortcode($raw_excerpt) : $content_text;
                        $excerpt = $excerpt_source ? wp_trim_words($excerpt_source, 30, '...') : '';
                        $page_title = get_the_title($page);
                        $page_link = ticinoweb_frontend_url(get_permalink($page->ID), "post:{$page->ID}:url");
                        ?>
                        <article class="service-card">
                            <?php if ($thumb): ?>
                                <div class="service-image">
                                    <img src="<?php echo esc_url($thumb); ?>" alt="<?php echo esc_attr($page_title); ?>" loading="lazy">
                                </div>
                            <?php endif; ?>
                            <div class="service-body">
                                <h3><?php echo esc_html($page_title); ?></h3>
                                <?php if ($excerpt): ?>
                                    <p><?php echo wp_kses_post($excerpt); ?></p>
                                <?php endif; ?>
                                <a class="service-link" href="<?php echo esc_url($page_link); ?>">
                                    <?php echo esc_html(ticinoweb_frontend_text(__('Scopri di più', 'ticinoweb-ai-theme'), 'theme:services:read_more')); ?>
                                </a>
                            </div>
                        </article>
                    <?php endforeach; ?>
                </div>
                <?php
                return ob_get_clean();
            }
        }

        return '';
    }

    ob_start();
    ?>
    <div class="services-grid">
        <?php foreach ($services as $service_idx => $service): 
            $service_id = !empty($service['id']) ? $service['id'] : ('srv_' . $service_idx);
            $service_title = ticinoweb_frontend_text($service['title'], "theme:service:{$service_id}:title");
            $service_desc = ticinoweb_frontend_text($service['description'], "theme:service:{$service_id}:description");
            $contact_url = function_exists('ticinoweb_get_mapped_page_url')
                ? (ticinoweb_get_mapped_page_url('page_contatti') ?: site_url('/contatti'))
                : site_url('/contatti');
            $contact_url = ticinoweb_frontend_url($contact_url, "theme:service:{$service_id}:link_url");
        ?>
        <article class="service-card">
            <?php if (!empty($service['image'])): ?>
            <div class="service-image">
                <img src="<?php echo esc_url($service['image']); ?>" alt="<?php echo esc_attr($service_title); ?>" loading="lazy">
            </div>
            <?php endif; ?>
            <div class="service-body">
                <h3><?php echo esc_html($service_title); ?></h3>
                <p><?php echo wp_kses_post($service_desc); ?></p>
                <a class="service-link" href="<?php echo esc_url($contact_url); ?>">
                    <?php echo esc_html(ticinoweb_frontend_text(__('Scopri di più', 'ticinoweb-ai-theme'), 'theme:services:read_more')); ?>
                </a>
            </div>
        </article>
        <?php endforeach; ?>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('ticinoweb_services', 'ticinoweb_services_shortcode');
add_shortcode('ticinoweb_servizi', 'ticinoweb_services_shortcode');

/**
 * Dynamic CPT archive shortcodes: [ticinoweb_{slug}_archive]
 */
function ticinoweb_register_cpt_archive_shortcodes() {
    $cpts = get_option('ticinoweb_custom_post_types', []);
    if (empty($cpts) || !is_array($cpts)) {
        return;
    }

    foreach ($cpts as $cpt) {
        if (empty($cpt['slug'])) {
            continue;
        }

        $slug = sanitize_title($cpt['slug']);
        $tag = 'ticinoweb_' . $slug . '_archive';
        add_shortcode($tag, 'ticinoweb_cpt_archive_shortcode');
    }
}
add_action('init', 'ticinoweb_register_cpt_archive_shortcodes', 20);

function ticinoweb_cpt_archive_shortcode($atts = [], $content = null, $tag = '') {
    if (empty($tag)) {
        return '';
    }

    $slug = str_replace(['ticinoweb_', '_archive'], '', $tag);
    if (empty($slug)) {
        return '';
    }

    // Limit query to avoid memory issues on large archives (#4)
    $atts = shortcode_atts(['limit' => 200], $atts, $tag);

    $query = new WP_Query([
        'post_type'      => $slug,
        'posts_per_page' => absint($atts['limit']),
        'orderby'        => 'menu_order title',
        'order'          => 'ASC',
    ]);

    // Layout speciale per Referenze (CPT o fallback categoria)
    if ($slug === 'referenza' || $slug === 'referenze') {
        $referenze_title = ticinoweb_frontend_text(__('Referenze', 'ticinoweb-ai-theme'), 'theme:referenze:title');
        $referenze_subtitle = ticinoweb_frontend_text(__('Una selezione di lavori e progetti recenti.', 'ticinoweb-ai-theme'), 'theme:referenze:subtitle');
        if ($query->have_posts()) {
            ob_start();
            ?>
            <div class="slachta-referenze-page">
                <section class="referenze-wall">
                    <div class="referenze-wall-header">
                        <h2><?php echo esc_html($referenze_title); ?></h2>
                        <p><?php echo esc_html($referenze_subtitle); ?></p>
                    </div>

                    <div class="referenze-wall-grid">
                        <?php while ($query->have_posts()) : $query->the_post(); ?>
                            <?php
                            $thumb_url = get_the_post_thumbnail_url(get_the_ID(), 'large');
                            if (!$thumb_url) {
                                $thumb_url = get_stylesheet_directory_uri() . '/assets/images/placeholder.jpg';
                            }
                            ?>
                            <article <?php post_class('referenza-card'); ?>>
                                <a class="referenza-link" href="<?php echo esc_url(ticinoweb_frontend_url(get_permalink(), "post:" . get_the_ID() . ":url")); ?>">
                                    <img src="<?php echo esc_url($thumb_url); ?>" alt="<?php the_title_attribute(); ?>" loading="lazy">
                                    <span class="referenza-overlay">
                                        <span class="referenza-title"><?php the_title(); ?></span>
                                    </span>
                                </a>
                            </article>
                        <?php endwhile; ?>
                    </div>
                </section>
            </div>
            <?php
            wp_reset_postdata();
            return ob_get_clean();
        }

        wp_reset_postdata();

        $referenze_cat = get_category_by_slug('referenze');
        $cat_query_args = [
            'post_type'      => 'post',
            'posts_per_page' => -1,
            'orderby'        => 'date',
            'order'          => 'DESC',
        ];

        if ($referenze_cat) {
            $cat_query_args['category_name'] = 'referenze';
        }

        $referenze_query = new WP_Query($cat_query_args);
        if (!$referenze_query->have_posts()) {
            wp_reset_postdata();
            return '';
        }

        ob_start();
        ?>
        <div class="slachta-referenze-page">
            <section class="referenze-wall">
                <div class="referenze-wall-header">
                    <h2><?php echo esc_html($referenze_title); ?></h2>
                    <p><?php echo esc_html($referenze_subtitle); ?></p>
                </div>

                <div class="referenze-wall-grid">
                    <?php while ($referenze_query->have_posts()) : $referenze_query->the_post(); ?>
                        <?php
                        $thumb_url = get_the_post_thumbnail_url(get_the_ID(), 'large');
                        if (!$thumb_url) {
                            $thumb_url = get_stylesheet_directory_uri() . '/assets/images/placeholder.jpg';
                        }
                        ?>
                        <article <?php post_class('referenza-card'); ?>>
                            <a class="referenza-link" href="<?php echo esc_url(ticinoweb_frontend_url(get_permalink(), "post:" . get_the_ID() . ":url")); ?>">
                                <img src="<?php echo esc_url($thumb_url); ?>" alt="<?php the_title_attribute(); ?>">
                                <span class="referenza-overlay">
                                    <span class="referenza-title"><?php the_title(); ?></span>
                                </span>
                            </a>
                        </article>
                    <?php endwhile; ?>
                </div>
            </section>
        </div>
        <?php
        wp_reset_postdata();
        return ob_get_clean();
    }

    if (!$query->have_posts()) {
        wp_reset_postdata();
        return '';
    }

    ob_start();
    ?>
    <div class="ticinoweb-archive-grid ticinoweb-archive-grid--<?php echo esc_attr($slug); ?>">
        <?php while ($query->have_posts()) : $query->the_post(); ?>
            <article <?php post_class('ticinoweb-archive-card'); ?>>
                <?php if (has_post_thumbnail()) : ?>
                    <div class="ticinoweb-archive-card__image">
                        <?php the_post_thumbnail('large'); ?>
                    </div>
                <?php endif; ?>
                <div class="ticinoweb-archive-card__body">
                    <h3><?php the_title(); ?></h3>
                    <div class="ticinoweb-archive-card__content">
                        <?php the_content(); ?>
                    </div>
                </div>
            </article>
        <?php endwhile; ?>
    </div>
    <?php
    wp_reset_postdata();
    return ob_get_clean();
}

