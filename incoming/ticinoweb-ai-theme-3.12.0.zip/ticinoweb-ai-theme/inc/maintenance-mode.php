<?php
/**
 * Maintenance Mode for ticinoWEB AI Theme
 * 
 * When enabled, shows a fullscreen liquid glass maintenance page
 * with logo, contacts, and a login form.
 * Admins bypass the maintenance page entirely.
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Get maintenance mode strings based on site locale.
 * Supports Italian (default) and English.
 */
function ticinoweb_maintenance_strings() {
    $locale = get_locale();
    $is_english = (strpos($locale, 'en') === 0);

    if ($is_english) {
        $default_heading  = 'Website Under Construction';
        $default_subtitle = "We are working to bring you a better experience. Please come back soon!";
        $strings = array(
            'page_title'     => 'Under Maintenance',
            'heading'        => $default_heading,
            'subtitle'       => $default_subtitle,
            'login_title'    => 'Restricted Access',
            'username'       => 'Username',
            'password'       => 'Password',
            'login_btn'      => 'Log In',
            'logging_in'     => 'Logging in...',
            'error_security' => 'Security error. Please reload the page.',
            'error_empty'    => 'Please enter username and password.',
            'error_invalid'  => 'Invalid credentials.',
            'error_login'    => 'Login error.',
            'error_network'  => 'Network error. Please try again.',
            'error_bot'      => 'Bot activity detected. Please reload and try again.',
            'error_captcha'  => 'Incorrect answer. Please try again.',
            'error_too_many' => 'Too many failed attempts. Please wait 15 minutes.',
            'captcha_label'  => 'Anti-bot check',
            'captcha_hint'   => 'Answer the question above',
        );
    } else {
        $default_heading  = 'Sito in Costruzione';
        $default_subtitle = "Stiamo lavorando per offrirti un'esperienza migliore. Torna a trovarci presto!";
        $strings = array(
            'page_title'     => 'Sito in Manutenzione',
            'heading'        => $default_heading,
            'subtitle'       => $default_subtitle,
            'login_title'    => 'Accesso Riservato',
            'username'       => 'Nome utente',
            'password'       => 'Password',
            'login_btn'      => 'Accedi',
            'logging_in'     => 'Accesso in corso...',
            'error_security' => 'Errore di sicurezza. Ricarica la pagina.',
            'error_empty'    => 'Inserisci utente e password.',
            'error_invalid'  => 'Credenziali non valide.',
            'error_login'    => 'Errore durante il login.',
            'error_network'  => 'Errore di rete. Riprova.',
            'error_bot'      => 'Attività bot rilevata. Ricarica la pagina e riprova.',
            'error_captcha'  => 'Risposta errata. Riprova.',
            'error_too_many' => 'Troppi tentativi falliti. Riprova tra 15 minuti.',
            'captcha_label'  => 'Verifica anti-bot',
            'captcha_hint'   => 'Rispondi alla domanda qui sopra',
        );
    }

    // Override heading and subtitle with custom values from admin settings (if set)
    $custom_heading  = get_option('ticinoweb_maintenance_heading', '');
    $custom_subtitle = get_option('ticinoweb_maintenance_subtitle', '');

    if (!empty($custom_heading)) {
        $strings['heading'] = $custom_heading;
    }
    if (!empty($custom_subtitle)) {
        $strings['subtitle'] = $custom_subtitle;
    }

    return $strings;
}

/**
 * Generate a self-contained HMAC-signed math CAPTCHA token.
 * The answer is signed with AUTH_KEY — no database/transient lookup needed.
 * Cache-safe: the token validates itself server-side on any request.
 * Returns array: ['token' => string, 'question' => string]
 */
function ticinoweb_maintenance_generate_captcha() {
    $a      = wp_rand(1, 12);
    $b      = wp_rand(1, 12);
    $answer = $a + $b;
    $ts     = time();

    // Sign answer + timestamp with AUTH_KEY so it cannot be tampered with
    $salt      = defined('AUTH_KEY') ? AUTH_KEY : wp_salt('auth');
    $signature = hash_hmac('sha256', $answer . ':' . $ts, $salt);

    // Pack as base64(answer:timestamp:signature) — fully self-contained
    $token = base64_encode($answer . ':' . $ts . ':' . $signature);

    return array(
        'token'    => $token,
        'question' => $a . ' + ' . $b . ' = ?',
    );
}

/**
 * Get the client IP address for rate limiting.
 * Uses REMOTE_ADDR only — no X-Forwarded-For trust to avoid spoofing.
 */
function ticinoweb_maintenance_client_ip() {
    return isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : 'unknown';
}

/**
 * Check if the current IP is rate-limited.
 * Returns true if blocked (>= 5 failed attempts within 15 minutes).
 */
function ticinoweb_maintenance_is_rate_limited() {
    $ip      = ticinoweb_maintenance_client_ip();
    $key     = 'twmaint_rl_' . md5($ip);
    $attempts = (int) get_transient($key);
    return $attempts >= 5;
}

/**
 * Increment the failed-attempt counter for the current IP.
 * Lockout period: 15 minutes.
 */
function ticinoweb_maintenance_increment_failures() {
    $ip      = ticinoweb_maintenance_client_ip();
    $key     = 'twmaint_rl_' . md5($ip);
    $attempts = (int) get_transient($key);
    set_transient($key, $attempts + 1, 15 * MINUTE_IN_SECONDS);
}

/**
 * Clear the rate-limit counter on successful login.
 */
function ticinoweb_maintenance_clear_rate_limit() {
    $ip  = ticinoweb_maintenance_client_ip();
    $key = 'twmaint_rl_' . md5($ip);
    delete_transient($key);
}

/**
 * Handle maintenance mode login form submission via AJAX
 */
add_action('wp_ajax_nopriv_ticinoweb_maintenance_login', 'ticinoweb_maintenance_login_handler');
add_action('wp_ajax_ticinoweb_maintenance_login', 'ticinoweb_maintenance_login_handler');

function ticinoweb_maintenance_login_handler() {
    $strings = ticinoweb_maintenance_strings();

    // --- Rate Limiting: check before any other processing ---
    if (ticinoweb_maintenance_is_rate_limited()) {
        wp_send_json_error(array('message' => $strings['error_too_many']));
    }

    // --- Nonce verification ---
    if (!isset($_POST['maintenance_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['maintenance_nonce'])), 'ticinoweb_maintenance_login')) {
        ticinoweb_maintenance_increment_failures();
        wp_send_json_error(array('message' => $strings['error_security']));
    }

    // --- Honeypot check: field must be empty (bots fill it, humans don't) ---
    $honeypot = isset($_POST['website_url']) ? $_POST['website_url'] : null;
    if ($honeypot !== '' && $honeypot !== null) {
        // Silently fail — don't reveal honeypot exists
        ticinoweb_maintenance_increment_failures();
        wp_send_json_error(array('message' => $strings['error_invalid']));
    }

    // --- Timing check: page must have been loaded at least 2 seconds before submit ---
    $page_ts = isset($_POST['page_ts']) ? (int) $_POST['page_ts'] : 0;
    $now_ts  = time();
    if ($page_ts <= 0 || ($now_ts - $page_ts) < 2) {
        ticinoweb_maintenance_increment_failures();
        wp_send_json_error(array('message' => $strings['error_bot']));
    }
    // Reject implausibly old tokens (> 15 minutes) to prevent replay
    if (($now_ts - $page_ts) > 15 * MINUTE_IN_SECONDS) {
        wp_send_json_error(array('message' => $strings['error_security']));
    }

    // --- Math CAPTCHA verification (HMAC-signed, no DB lookup, cache-safe) ---
    $captcha_token  = isset($_POST['captcha_token']) ? sanitize_text_field(wp_unslash($_POST['captcha_token'])) : '';
    $captcha_answer = isset($_POST['captcha_answer']) ? (int) $_POST['captcha_answer'] : -9999;

    // Decode and split the self-contained signed token
    $decoded = base64_decode($captcha_token, true);
    if ($decoded === false) {
        ticinoweb_maintenance_increment_failures();
        wp_send_json_error(array('message' => $strings['error_security']));
    }

    $parts = explode(':', $decoded, 3);
    if (count($parts) !== 3) {
        ticinoweb_maintenance_increment_failures();
        wp_send_json_error(array('message' => $strings['error_security']));
    }

    list($encoded_answer, $encoded_ts, $encoded_sig) = $parts;

    // Verify HMAC signature — proves the token was generated by this server
    $salt         = defined('AUTH_KEY') ? AUTH_KEY : wp_salt('auth');
    $expected_sig = hash_hmac('sha256', $encoded_answer . ':' . $encoded_ts, $salt);

    if (!hash_equals($expected_sig, $encoded_sig)) {
        ticinoweb_maintenance_increment_failures();
        wp_send_json_error(array('message' => $strings['error_security']));
    }

    // Verify the answer
    if ((int) $encoded_answer !== $captcha_answer) {
        ticinoweb_maintenance_increment_failures();
        wp_send_json_error(array('message' => $strings['error_captcha']));
    }

    // --- Credentials ---
    $username = sanitize_user(wp_unslash($_POST['log'] ?? ''));
    $password = wp_unslash($_POST['pwd'] ?? '');

    if (empty($username) || empty($password)) {
        wp_send_json_error(array('message' => $strings['error_empty']));
    }

    $creds = array(
        'user_login'    => $username,
        'user_password' => $password,
        'remember'      => true,
    );

    $user = wp_signon($creds, is_ssl());

    if (is_wp_error($user)) {
        ticinoweb_maintenance_increment_failures();
        wp_send_json_error(array('message' => $strings['error_invalid']));
    }

    // Successful login — clear rate limit counter
    ticinoweb_maintenance_clear_rate_limit();

    wp_set_current_user($user->ID);

    // Admin users → go to wp-admin
    if (user_can($user, 'manage_options')) {
        wp_send_json_success(array('redirect' => admin_url()));
    }

    // Non-admin users → go to homepage
    wp_send_json_success(array('redirect' => home_url('/')));
}

/**
 * Hide admin bar for non-admin users when maintenance mode is active
 */
add_action('init', 'ticinoweb_maintenance_hide_admin_bar');

function ticinoweb_maintenance_hide_admin_bar() {
    if (!get_option('ticinoweb_maintenance_mode', 0)) {
        return;
    }

    if (is_user_logged_in() && !current_user_can('manage_options')) {
        show_admin_bar(false);
    }
}

/**
 * Tell LiteSpeed Cache (and W3TC, WP Super Cache, etc.) NOT to cache
 * the maintenance page. This fires on 'init' — the earliest safe point
 * where get_option() works — well before any HTML is output.
 */
add_action('init', 'ticinoweb_maintenance_nocache_hooks', 1);

function ticinoweb_maintenance_nocache_hooks() {
    if (!get_option('ticinoweb_maintenance_mode', 0)) {
        return;
    }
    if (current_user_can('manage_options') || is_user_logged_in()) {
        return;
    }
    $uri = $_SERVER['REQUEST_URI'] ?? '';
    if (strpos($uri, 'wp-admin') !== false || strpos($uri, 'admin-ajax.php') !== false) {
        return;
    }

    // LiteSpeed Cache plugin WordPress API (v3.x+)
    do_action('litespeed_control_set_nocache', 'ticinoweb_maintenance_mode');

    // LiteSpeed Cache plugin older API (v2.x)
    if (class_exists('LiteSpeed_Cache_API')) {
        LiteSpeed_Cache_API::set_nocache('ticinoweb_maintenance_mode');
    }

    // W3 Total Cache
    if (function_exists('w3tc_pgcache_flush')) {
        define('DONOTCACHEPAGE', true);
    }

    // WP Super Cache
    if (!defined('DONOTCACHEPAGE')) {
        define('DONOTCACHEPAGE', true);
    }
}

/**
 * Intercept frontend requests when maintenance mode is active
 */
add_action('template_redirect', 'ticinoweb_maintenance_redirect');

function ticinoweb_maintenance_redirect() {
    // Not enabled? bail
    if (!get_option('ticinoweb_maintenance_mode', 0)) {
        return;
    }

    // Allow admins through
    if (current_user_can('manage_options')) {
        return;
    }

    // Allow logged-in non-admin users to browse the site
    if (is_user_logged_in()) {
        return;
    }

    // Don't block wp-login, wp-admin, admin-ajax, wp-cron
    $request_uri = $_SERVER['REQUEST_URI'] ?? '';
    if (
        strpos($request_uri, 'wp-login.php') !== false ||
        strpos($request_uri, 'wp-admin') !== false ||
        strpos($request_uri, 'admin-ajax.php') !== false ||
        strpos($request_uri, 'wp-cron.php') !== false
    ) {
        return;
    }

    // Show maintenance page
    ticinoweb_render_maintenance_page();
    exit;
}

/**
 * Hide wp-admin and wp-login.php for unauthenticated users when maintenance mode is active.
 * Excludes AJAX requests, CRON tasks, and logged-in admins to maintain standard operations
 * and multisite compatibility. Intercepts early at 'init' hook.
 */
add_action('init', 'ticinoweb_maintenance_block_admin_access', 5);

function ticinoweb_maintenance_block_admin_access() {
    // Only if maintenance mode is enabled for this subsite
    if (!get_option('ticinoweb_maintenance_mode', 0)) {
        return;
    }

    // Allow logged-in administrators/managers of this subsite
    if (current_user_can('manage_options')) {
        return;
    }

    // Bypass for AJAX, Cron, and WP-CLI commands
    if (
        (defined('DOING_AJAX') && DOING_AJAX) ||
        (defined('DOING_CRON') && DOING_CRON) ||
        (defined('WP_CLI') && WP_CLI)
    ) {
        return;
    }

    // Check if the current request is trying to load login page or admin dashboard area
    global $pagenow;
    $is_login_page = ( $pagenow === 'wp-login.php' || ( isset( $_SERVER['SCRIPT_NAME'] ) && basename( $_SERVER['SCRIPT_NAME'] ) === 'wp-login.php' ) );
    $is_admin_area = is_admin();

    if ($is_login_page || $is_admin_area) {
        // Securely redirect to the subsite home page (which will serve the maintenance page)
        wp_safe_redirect(home_url('/'));
        exit;
    }
}

/**
 * Render the fullscreen liquid glass maintenance page
 */
function ticinoweb_render_maintenance_page() {
    $strings   = ticinoweb_maintenance_strings();
    $logo_url  = function_exists('ticinoweb_get_site_logo') ? ticinoweb_get_site_logo() : false;
    $contacts  = function_exists('ticinoweb_get_contact_info') ? ticinoweb_get_contact_info() : array();
    $site_name = get_bloginfo('name');
    $primary_color = get_option('ticinoweb_palette_primary', '#6366f1');
    $ajax_url  = admin_url('admin-ajax.php');
    $nonce     = wp_create_nonce('ticinoweb_maintenance_login');

    // Generate server-side math CAPTCHA
    $captcha   = ticinoweb_maintenance_generate_captcha();
    // Server timestamp — used server-side for timing check
    $server_ts = time();

    // Derive accent colors from primary
    $hex = ltrim($primary_color, '#');
    if (strlen($hex) === 3) {
        $hex = $hex[0].$hex[0].$hex[1].$hex[1].$hex[2].$hex[2];
    }
    $r = hexdec(substr($hex, 0, 2));
    $g = hexdec(substr($hex, 2, 2));
    $b = hexdec(substr($hex, 4, 2));

    // Lighter, pastel-ish blob colors for the clear background
    $color1 = "rgba(" . min(255, $r + 60) . ", " . min(255, $g + 60) . ", " . min(255, $b + 60) . ", 0.5)";
    $color2 = "rgba(" . (($r + 80) % 256) . ", " . min(255, $g + 100) . ", " . (($b + 120) % 256) . ", 0.45)";
    $color3 = "rgba(" . (($r + 160) % 256) . ", " . min(255, $g + 140) . ", " . (($b + 60) % 256) . ", 0.4)";
    $color4 = "rgba(" . min(255, $r + 120) . ", " . (($g + 180) % 256) . ", " . min(255, $b + 90) . ", 0.45)";
    $btn_gradient_end = "rgba(" . (($r + 80) % 256) . ", " . min(255, $g + 100) . ", " . (($b + 120) % 256) . ", 1)";

    // HTTP 503 Service Unavailable + Retry-After: segnale SEO corretto per una
    // manutenzione TEMPORANEA. Dice ai crawler "il sito tornerà, riprova più tardi",
    // così Google non indicizza la pagina di manutenzione né declassa le pagine reali.
    // Il body 503 viene comunque renderizzato normalmente dal browser (nessuno "spinning tab").
    // Restiamo con noindex/nofollow nel <meta> come ulteriore sicurezza.
    status_header(503);
    header('Retry-After: 3600');
    header('Content-Type: text/html; charset=utf-8');

    // Prevent ANY cache from storing this page — it contains a unique CAPTCHA token
    // that must match a server-side transient. Caching would break the CAPTCHA.
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    header('Pragma: no-cache');
    header('Expires: Thu, 01 Jan 1970 00:00:00 GMT');
    // LiteSpeed Cache specific — force bypass even for anonymous users
    header('X-LiteSpeed-Cache-Control: no-cache');
    ?>
<!DOCTYPE html>
<html lang="<?php echo esc_attr(get_locale()); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="noindex, nofollow">
    <title><?php echo esc_html($site_name); ?> — <?php echo esc_html($strings['page_title']); ?></title>
    <?php
    // Favicon
    $icon = function_exists('ticinoweb_get_site_icon') ? ticinoweb_get_site_icon() : '';
    if ($icon): ?>
    <link rel="icon" href="<?php echo esc_url($icon); ?>">
    <?php endif; ?>
    <style>
        /* Google Fonts: @import DEVE essere prima di qualsiasi regola CSS */
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');

        *, *::before, *::after { margin: 0; padding: 0; box-sizing: border-box; }

        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            overflow: hidden;
            background: #f5f3ff; /* base neutro chiaro, i blob sono i colori */
            color: #2d3748;
        }

        /* Animated gradient background */
        .bg-canvas {
            position: fixed;
            inset: 0;
            z-index: 0;
            overflow: hidden;
           /* Blob di sfondo — dimensioni viewport per farsi fondere tra loro */
        }

        .blob {
            position: absolute;
            border-radius: 50%;
            will-change: transform, filter;
        }

        /* Blob 1 — viola, top-left, grande */
        .blob-1 {
            width: 110vw; height: 110vw;
            background: rgba(139, 92, 246, 0.72);
            top: -55%; left: -35%;
            animation: blob-anim-1 20s ease-in-out infinite;
        }

        /* Blob 2 — teal, bottom-right */
        .blob-2 {
            width: 95vw; height: 95vw;
            background: rgba(6, 182, 212, 0.68);
            bottom: -48%; right: -28%;
            animation: blob-anim-2 26s ease-in-out infinite;
            animation-delay: -9s;
        }

        /* Blob 3 — arancione, centro-basso */
        .blob-3 {
            width: 80vw; height: 80vw;
            background: rgba(249, 115, 22, 0.62);
            top: 35%; left: 8%;
            animation: blob-anim-3 22s ease-in-out infinite;
            animation-delay: -15s;
        }

        /* Blob 4 — fuchsia, top-right */
        .blob-4 {
            width: 75vw; height: 75vw;
            background: rgba(232, 72, 152, 0.58);
            top: -25%; right: -5%;
            animation: blob-anim-4 30s ease-in-out infinite;
            animation-delay: -4s;
        }

        /* Ogni blob anima: posizione + scala + hue-rotate (cambio colore nel tempo) */
        @keyframes blob-anim-1 {
            0%   { transform: translate(0vw, 0vh)       scale(1);    filter: blur(80px) hue-rotate(0deg);   opacity: 0.8; }
            25%  { transform: translate(12vw, 8vh)      scale(1.15); filter: blur(90px) hue-rotate(90deg);  opacity: 1.0; }
            50%  { transform: translate(-6vw, 18vh)     scale(0.9);  filter: blur(75px) hue-rotate(180deg); opacity: 0.7; }
            75%  { transform: translate(8vw,  4vh)      scale(1.1);  filter: blur(85px) hue-rotate(270deg); opacity: 0.9; }
            100% { transform: translate(0vw, 0vh)       scale(1);    filter: blur(80px) hue-rotate(360deg); opacity: 0.8; }
        }

        @keyframes blob-anim-2 {
            0%   { transform: translate(0vw, 0vh)       scale(1);    filter: blur(85px) hue-rotate(0deg);   opacity: 0.75; }
            30%  { transform: translate(-10vw, -8vh)    scale(1.2);  filter: blur(95px) hue-rotate(120deg); opacity: 1.0;  }
            60%  { transform: translate(8vw, -15vh)     scale(0.85); filter: blur(78px) hue-rotate(240deg); opacity: 0.65; }
            100% { transform: translate(0vw, 0vh)       scale(1);    filter: blur(85px) hue-rotate(360deg); opacity: 0.75; }
        }

        @keyframes blob-anim-3 {
            0%   { transform: translate(0vw, 0vh)       scale(1);    filter: blur(80px) hue-rotate(60deg);  opacity: 0.7;  }
            33%  { transform: translate(10vw, -10vh)    scale(1.25); filter: blur(88px) hue-rotate(180deg); opacity: 0.95; }
            66%  { transform: translate(-8vw, -5vh)     scale(0.82); filter: blur(72px) hue-rotate(300deg); opacity: 0.6;  }
            100% { transform: translate(0vw, 0vh)       scale(1);    filter: blur(80px) hue-rotate(420deg); opacity: 0.7;  }
        }

        @keyframes blob-anim-4 {
            0%   { transform: translate(0vw, 0vh)       scale(1);    filter: blur(82px) hue-rotate(30deg);  opacity: 0.72; }
            20%  { transform: translate(-8vw, 12vh)     scale(0.85); filter: blur(92px) hue-rotate(150deg); opacity: 0.55; }
            50%  { transform: translate(10vw, 8vh)      scale(1.3);  filter: blur(78px) hue-rotate(270deg); opacity: 0.95; }
            80%  { transform: translate(-4vw, -8vh)     scale(0.9);  filter: blur(86px) hue-rotate(330deg); opacity: 0.65; }
            100% { transform: translate(0vw, 0vh)       scale(1);    filter: blur(82px) hue-rotate(390deg); opacity: 0.72; }
        }

        /* Glass card */
        .maintenance-card {
            position: relative;
            z-index: 10;
            width: 90%;
            max-width: 460px;
            background: rgba(255, 255, 255, 0.45);
            backdrop-filter: blur(20px) saturate(1.4);
            -webkit-backdrop-filter: blur(20px) saturate(1.4);
            border: 1px solid rgba(255, 255, 255, 0.6);
            border-radius: 24px;
            padding: 48px 36px 40px;
            text-align: center;
            box-shadow:
                0 8px 40px rgba(0, 0, 0, 0.08),
                0 2px 12px rgba(0, 0, 0, 0.04),
                inset 0 1px 0 rgba(255, 255, 255, 0.8);
            animation: cardIn 0.8s ease-out;
        }

        @keyframes cardIn {
            0% { opacity: 0; transform: translateY(30px) scale(0.96); }
            100% { opacity: 1; transform: translateY(0) scale(1); }
        }

        .maintenance-logo {
            margin-bottom: 28px;
        }

        .maintenance-logo img {
            max-width: 180px;
            max-height: 80px;
            object-fit: contain;
            filter: drop-shadow(0 2px 8px rgba(0,0,0,0.1));
        }

        .maintenance-title {
            font-size: 1.75rem;
            font-weight: 700;
            letter-spacing: -0.02em;
            margin-bottom: 8px;
            color: #1a202c;
        }

        .maintenance-subtitle {
            font-size: 0.95rem;
            color: #718096;
            font-weight: 300;
            margin-bottom: 32px;
            line-height: 1.5;
        }

        /* Contacts */
        .maintenance-contacts {
            display: flex;
            flex-direction: column;
            gap: 10px;
            margin-bottom: 32px;
        }

        .maintenance-contacts a,
        .maintenance-contacts span {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            font-size: 0.88rem;
            color: #4a5568;
            text-decoration: none;
            transition: color 0.2s;
        }

        .maintenance-contacts a:hover {
            color: <?php echo esc_attr($primary_color); ?>;
        }

        .maintenance-contacts svg {
            flex-shrink: 0;
            opacity: 0.6;
        }

        /* Divider */
        .maintenance-divider {
            height: 1px;
            background: linear-gradient(90deg, transparent, rgba(0,0,0,0.1), transparent);
            margin: 8px 0 24px;
        }

        /* Login form */
        .login-section-title {
            font-size: 0.78rem;
            text-transform: uppercase;
            letter-spacing: 0.1em;
            color: #a0aec0;
            margin-bottom: 16px;
            font-weight: 500;
        }

        .maintenance-form .form-group {
            margin-bottom: 14px;
        }

        .maintenance-form input[type="text"],
        .maintenance-form input[type="password"] {
            width: 100%;
            padding: 12px 16px;
            border: 1px solid rgba(0, 0, 0, 0.1);
            border-radius: 12px;
            background: rgba(255, 255, 255, 0.6);
            color: #2d3748;
            font-size: 0.9rem;
            font-family: inherit;
            outline: none;
            transition: border-color 0.2s, background 0.2s, box-shadow 0.2s;
        }

        .maintenance-form input[type="text"]::placeholder,
        .maintenance-form input[type="password"]::placeholder {
            color: #a0aec0;
        }

        .maintenance-form input[type="text"]:focus,
        .maintenance-form input[type="password"]:focus {
            border-color: <?php echo esc_attr($primary_color); ?>;
            background: rgba(255, 255, 255, 0.85);
            box-shadow: 0 0 0 3px rgba(<?php echo "$r, $g, $b"; ?>, 0.15);
        }

        /* Password field with eye toggle */
        .pwd-wrapper {
            position: relative;
            display: block;
        }

        .pwd-wrapper input[type="password"],
        .pwd-wrapper input[type="text"] {
            padding-right: 44px;
        }

        .pwd-toggle {
            position: absolute;
            right: 12px;
            top: 50%;
            transform: translateY(-50%);
            background: none;
            border: none;
            cursor: pointer;
            padding: 4px;
            color: #a0aec0;
            transition: color 0.2s;
            line-height: 0;
        }

        .pwd-toggle:hover {
            color: <?php echo esc_attr($primary_color); ?>;
        }

        .pwd-toggle svg {
            width: 18px;
            height: 18px;
            display: block;
            pointer-events: none;
        }

        /* Honeypot — visually hidden but in DOM so bots see it */
        .hp-field {
            opacity: 0;
            position: absolute;
            top: 0;
            left: 0;
            height: 0;
            width: 0;
            z-index: -1;
            pointer-events: none;
        }

        /* CAPTCHA question */
        .captcha-group {
            margin-bottom: 14px;
        }

        .captcha-question {
            font-size: 0.82rem;
            color: #718096;
            margin-bottom: 6px;
            font-weight: 500;
            text-align: left;
        }

        .captcha-row {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .captcha-label {
            font-size: 0.95rem;
            font-weight: 600;
            color: #2d3748;
            background: rgba(255,255,255,0.55);
            border: 1px solid rgba(0,0,0,0.08);
            border-radius: 10px;
            padding: 10px 14px;
            white-space: nowrap;
            letter-spacing: 0.04em;
        }

        .captcha-input {
            flex: 1;
            padding: 10px 14px;
            border: 1px solid rgba(0, 0, 0, 0.1);
            border-radius: 10px;
            background: rgba(255, 255, 255, 0.6);
            color: #2d3748;
            font-size: 0.9rem;
            font-family: inherit;
            outline: none;
            transition: border-color 0.2s, background 0.2s, box-shadow 0.2s;
            -moz-appearance: textfield;
        }

        .captcha-input::-webkit-outer-spin-button,
        .captcha-input::-webkit-inner-spin-button { -webkit-appearance: none; margin: 0; }

        .captcha-input:focus {
            border-color: <?php echo esc_attr($primary_color); ?>;
            background: rgba(255, 255, 255, 0.85);
            box-shadow: 0 0 0 3px rgba(<?php echo "$r, $g, $b"; ?>, 0.15);
        }

        .maintenance-form .submit-btn {
            width: 100%;
            padding: 14px;
            border: none;
            border-radius: 12px;
            background: linear-gradient(135deg, #1a1a2e 0%, <?php echo esc_attr($primary_color); ?> 60%, <?php echo $btn_gradient_end; ?> 100%);
            background-size: 200% auto;
            color: #fff;
            font-size: 1rem;
            font-weight: 700;
            font-family: inherit;
            cursor: pointer;
            letter-spacing: 0.03em;
            position: relative;
            overflow: hidden;
            transition: background-position 0.4s ease, transform 0.15s, box-shadow 0.2s;
            margin-top: 8px;
            box-shadow: 0 4px 16px rgba(<?php echo "$r, $g, $b"; ?>, 0.45),
                        0 1px 4px rgba(0,0,0,0.2);
        }

        /* Shimmer sweep on hover */
        .maintenance-form .submit-btn::before {
            content: '';
            position: absolute;
            top: 0; left: -100%;
            width: 60%; height: 100%;
            background: linear-gradient(120deg, transparent, rgba(255,255,255,0.25), transparent);
            transition: left 0.45s ease;
        }

        .maintenance-form .submit-btn:hover {
            background-position: right center;
            transform: translateY(-2px);
            box-shadow: 0 8px 28px rgba(<?php echo "$r, $g, $b"; ?>, 0.55),
                        0 2px 8px rgba(0,0,0,0.2);
        }

        .maintenance-form .submit-btn:hover::before {
            left: 150%;
        }

        .maintenance-form .submit-btn:active {
            transform: translateY(0);
            box-shadow: 0 2px 8px rgba(<?php echo "$r, $g, $b"; ?>, 0.3);
        }

        .maintenance-form .submit-btn:disabled {
            opacity: 0.55;
            cursor: not-allowed;
            transform: none;
            box-shadow: none;
        }

        .login-error {
            color: #e53e3e;
            font-size: 0.85rem;
            margin-top: 10px;
            min-height: 1.2em;
            transition: opacity 0.2s;
        }

        /* Responsive */
        @media (max-width: 520px) {
            .maintenance-card {
                padding: 36px 24px 32px;
                border-radius: 20px;
            }
            .maintenance-title {
                font-size: 1.4rem;
            }
            .blob { filter: blur(70px); }
            .blob-1 { width: 350px; height: 350px; }
            .blob-2 { width: 280px; height: 280px; }
            .blob-3 { width: 250px; height: 250px; }
            .blob-4 { width: 200px; height: 200px; }
        }
    </style>
</head>
<body>
    <div class="bg-canvas">
        <div class="blob blob-1"></div>
        <div class="blob blob-2"></div>
        <div class="blob blob-3"></div>
        <div class="blob blob-4"></div>
    </div>

    <div class="maintenance-card">
        <?php if ($logo_url): ?>
        <div class="maintenance-logo">
            <img id="maintenance-logo-img" src="<?php echo esc_url($logo_url); ?>" alt="<?php echo esc_attr($site_name); ?>" crossorigin="anonymous">
        </div>
        <?php endif; ?>

        <h1 class="maintenance-title"><?php echo esc_html($strings['heading']); ?></h1>
        <p class="maintenance-subtitle"><?php echo esc_html($strings['subtitle']); ?></p>

        <?php
        $has_contacts = false;
        if (!empty($contacts['email']) && $contacts['email'] !== 'info@slachta.ch') $has_contacts = true;
        if (!empty($contacts['phone']) && $contacts['phone'] !== '+41 79 123 45 67') $has_contacts = true;
        if (!empty($contacts['address']) && $contacts['address'] !== 'Via Example 123, 6900 Lugano') $has_contacts = true;
        ?>

        <?php if ($has_contacts): ?>
        <div class="maintenance-contacts">
            <?php if (!empty($contacts['email']) && $contacts['email'] !== 'info@slachta.ch'): ?>
            <a href="mailto:<?php echo esc_attr($contacts['email']); ?>">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>
                <?php echo esc_html($contacts['email']); ?>
            </a>
            <?php endif; ?>
            <?php if (!empty($contacts['phone']) && $contacts['phone'] !== '+41 79 123 45 67'): ?>
            <a href="tel:<?php echo esc_attr(preg_replace('/[^+0-9]/', '', $contacts['phone'])); ?>">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.127.96.361 1.903.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0 1 22 16.92z"/></svg>
                <?php echo esc_html($contacts['phone']); ?>
            </a>
            <?php endif; ?>
            <?php if (!empty($contacts['address']) && $contacts['address'] !== 'Via Example 123, 6900 Lugano'): ?>
            <span>
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>
                <?php echo esc_html($contacts['address']); ?>
            </span>
            <?php endif; ?>
        </div>
        <?php endif; ?>

        <div class="maintenance-divider"></div>

        <p class="login-section-title"><?php echo esc_html($strings['login_title']); ?></p>

        <form class="maintenance-form" id="maintenance-login-form" autocomplete="off">

            <!-- Honeypot: hidden from real users, visible to bots -->
            <div class="hp-field" aria-hidden="true">
                <label for="website_url">Leave this field empty</label>
                <input type="text" name="website_url" id="website_url" tabindex="-1" autocomplete="off" value="">
            </div>

            <!-- Hidden anti-bot fields (server timestamp + CAPTCHA token) -->
            <input type="hidden" name="page_ts" id="maintenance-page-ts" value="<?php echo esc_attr($server_ts); ?>">
            <input type="hidden" name="captcha_token" value="<?php echo esc_attr($captcha['token']); ?>">

            <div class="form-group">
                <input type="text" name="log" id="maintenance-user" placeholder="<?php echo esc_attr($strings['username']); ?>" autocomplete="username" required>
            </div>
            <div class="form-group">
                <div class="pwd-wrapper">
                    <input type="password" name="pwd" id="maintenance-pwd" placeholder="<?php echo esc_attr($strings['password']); ?>" autocomplete="current-password" required>
                    <button type="button" class="pwd-toggle" id="pwd-eye" aria-label="Mostra/nascondi password" tabindex="-1">
                        <!-- Eye open -->
                        <svg id="eye-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
                        <!-- Eye off (hidden by default) -->
                        <svg id="eye-off-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="display:none"><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/></svg>
                    </button>
                </div>
            </div>

            <!-- Math CAPTCHA -->
            <div class="captcha-group">
                <p class="captcha-question"><?php echo esc_html($strings['captcha_label']); ?></p>
                <div class="captcha-row">
                    <span class="captcha-label"><?php echo esc_html($captcha['question']); ?></span>
                    <input type="number" name="captcha_answer" id="maintenance-captcha"
                           class="captcha-input"
                           placeholder="<?php echo esc_attr($strings['captcha_hint']); ?>"
                           required min="2" max="24" autocomplete="off">
                </div>
            </div>

            <button type="submit" class="submit-btn" id="maintenance-submit"><?php echo esc_html($strings['login_btn']); ?></button>
            <div class="login-error" id="login-error"></div>
        </form>
    </div>

    <script>
    (function() {
        var form    = document.getElementById('maintenance-login-form');
        var btn     = document.getElementById('maintenance-submit');
        var errorEl = document.getElementById('login-error');
        var btnText      = <?php echo json_encode($strings['login_btn']); ?>;
        var loggingText  = <?php echo json_encode($strings['logging_in']); ?>;
        var genericError = <?php echo json_encode($strings['error_login']); ?>;
        var networkError = <?php echo json_encode($strings['error_network']); ?>;

        // --- Password eye toggle ---
        var eyeBtn    = document.getElementById('pwd-eye');
        var pwdInput  = document.getElementById('maintenance-pwd');
        var eyeIcon   = document.getElementById('eye-icon');
        var eyeOffIcon= document.getElementById('eye-off-icon');

        if (eyeBtn && pwdInput) {
            eyeBtn.addEventListener('click', function() {
                var isPassword = pwdInput.type === 'password';
                pwdInput.type = isPassword ? 'text' : 'password';
                eyeIcon.style.display    = isPassword ? 'none'  : 'block';
                eyeOffIcon.style.display = isPassword ? 'block' : 'none';
            });
        }

        // --- Form submit ---
        function resetBtn(msg) {
            errorEl.textContent = msg || '';
            btn.disabled = false;
            btn.textContent = btnText;
        }

        form.addEventListener('submit', function(e) {
            e.preventDefault();
            errorEl.textContent = '';
            btn.disabled = true;
            btn.textContent = loggingText;

            // Build FormData defensively — null-safe for any missing elements
            var formData;
            try {
                formData = new FormData();
                formData.append('action',            'ticinoweb_maintenance_login');
                formData.append('maintenance_nonce', <?php echo json_encode($nonce); ?>);
                formData.append('log',  (document.getElementById('maintenance-user')  || {value:''}).value);
                formData.append('pwd',  (document.getElementById('maintenance-pwd')   || {value:''}).value);
                var tokenEl = document.querySelector('[name="captcha_token"]');
                formData.append('captcha_token',  tokenEl ? tokenEl.value : '');
                formData.append('captcha_answer', (document.getElementById('maintenance-captcha')  || {value:''}).value);
                formData.append('page_ts',        (document.getElementById('maintenance-page-ts') || {value:'0'}).value);
                formData.append('website_url',    (document.getElementById('website_url')          || {value:''}).value);
            } catch (buildErr) {
                resetBtn(genericError);
                return;
            }

            // 12-second timeout via AbortController
            var controller = new AbortController();
            var timeout    = setTimeout(function() { controller.abort(); }, 12000);

            fetch(<?php echo json_encode($ajax_url); ?>, {
                method: 'POST',
                credentials: 'same-origin',
                signal: controller.signal,
                body: formData
            })
            .then(function(r) {
                clearTimeout(timeout);
                return r.json();
            })
            .then(function(data) {
                if (data.success && data.data && data.data.redirect) {
                    window.location.href = data.data.redirect;
                } else {
                    var msg = (data.data && data.data.message) ? data.data.message : genericError;
                    resetBtn(msg);
                }
            })
            .catch(function() {
                clearTimeout(timeout);
                resetBtn(networkError);
            });
        });
    })();
    </script>

    <script>
    // Remove white/gray background from PNG logos using Canvas
    // This is more reliable than CSS mix-blend-mode on glass cards with backdrop-filter
    (function() {
        var img = document.getElementById('maintenance-logo-img');
        if (!img) return;

        function removeBg(imgEl) {
            var canvas = document.createElement('canvas');
            canvas.width  = imgEl.naturalWidth  || imgEl.width;
            canvas.height = imgEl.naturalHeight || imgEl.height;

            var ctx = canvas.getContext('2d');
            ctx.drawImage(imgEl, 0, 0);

            var imageData;
            try {
                imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
            } catch(e) {
                // CORS error — can't read pixels (image from different origin without crossorigin)
                return;
            }

            var data = imageData.data;

            // Sample the corner pixel as the background color reference
            var bgR = data[0], bgG = data[1], bgB = data[2];

            for (var i = 0; i < data.length; i += 4) {
                var r = data[i], g = data[i+1], b = data[i+2];

                // If pixel is close to the background color → make transparent
                var dist = Math.sqrt(
                    Math.pow(r - bgR, 2) +
                    Math.pow(g - bgG, 2) +
                    Math.pow(b - bgB, 2)
                );

                if (dist < 40) {
                    // Smooth the edges with partial transparency based on distance
                    data[i+3] = Math.round((dist / 40) * data[i+3]);
                }
            }

            ctx.putImageData(imageData, 0, 0);
            imgEl.src = canvas.toDataURL('image/png');
        }

        if (img.complete && img.naturalWidth) {
            removeBg(img);
        } else {
            img.addEventListener('load', function() { removeBg(img); });
        }
    })();
    </script>
</body>
</html>
    <?php
}
