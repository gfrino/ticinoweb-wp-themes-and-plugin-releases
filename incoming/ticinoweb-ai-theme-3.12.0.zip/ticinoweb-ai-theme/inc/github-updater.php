<?php
/**
 * Aggiornamenti del tema dal repository pubblico delle release ticinoWEB.
 *
 * Repo: https://github.com/gfrino/ticinoweb-wp-themes-and-plugin-releases
 * Convenzione: una release per versione, tag `<slug>-v<versione>` (es.
 * `ticinoweb-ai-theme-v3.10.0`), asset `<slug>-<versione>.zip` con dentro la
 * cartella `<slug>/`. Il corpo della release e' il changelog mostrato nella
 * finestra "Dettagli versione" di WordPress.
 *
 * Il tema si aggancia a `pre_set_site_transient_update_themes`: la nuova
 * versione compare in Bacheca → Aggiornamenti e in Aspetto → Temi (in
 * multisite: nella bacheca di rete, una sola volta per tutti i siti) e viene
 * installata dall'aggiornatore standard di WordPress. L'elenco release del repo e' letto
 * al massimo una volta ogni 12 ore (site transient condiviso da tutti i temi e
 * plugin registrati); "Controlla di nuovo" in
 * Aggiornamenti forza il ricontrollo.
 *
 * La classe e' generica: `new TW_GitHub_Updater('ticinoweb-ai-theme')` per un
 * tema, `new TW_GitHub_Updater('mio-plugin', 'plugin', 'mio-plugin/mio-plugin.php')`
 * per un plugin che voglia usare lo stesso repo di release.
 *
 * @package ticinoweb-ai-theme
 * @since 3.10.0
 */

if (!defined('ABSPATH')) {
    exit;
}

if (!defined('TICINOWEB_RELEASES_REPO')) {
    define('TICINOWEB_RELEASES_REPO', 'gfrino/ticinoweb-wp-themes-and-plugin-releases');
}

if (!class_exists('TW_GitHub_Updater')) :

class TW_GitHub_Updater {

    const CACHE_TTL = 12 * HOUR_IN_SECONDS;

    protected $slug;
    protected $type;      // 'theme' | 'plugin'
    protected $basename;  // plugin: 'dir/file.php'
    protected $repo;
    protected $version;

    public function __construct($slug, $type = 'theme', $basename = '', $repo = TICINOWEB_RELEASES_REPO) {
        $this->slug     = $slug;
        $this->type     = $type === 'plugin' ? 'plugin' : 'theme';
        $this->basename = $basename ?: $slug;
        $this->repo     = $repo;

        if ($this->type === 'theme') {
            $this->version = (string) wp_get_theme($slug)->get('Version');
            add_filter('pre_set_site_transient_update_themes', array($this, 'inject_theme_update'));
            add_filter('site_transient_update_themes', array($this, 'inject_theme_update'));
            add_filter('themes_api', array($this, 'theme_details'), 10, 3);
        } else {
            if (!function_exists('get_plugin_data')) {
                require_once ABSPATH . 'wp-admin/includes/plugin.php';
            }
            $file = WP_PLUGIN_DIR . '/' . $this->basename;
            $this->version = file_exists($file) ? (string) get_plugin_data($file, false, false)['Version'] : '0';
            add_filter('pre_set_site_transient_update_plugins', array($this, 'inject_plugin_update'));
            add_filter('site_transient_update_plugins', array($this, 'inject_plugin_update'));
            add_filter('plugins_api', array($this, 'plugin_details'), 10, 3);
        }

        add_filter('upgrader_source_selection', array($this, 'fix_source_folder'), 10, 4);
        add_action('upgrader_process_complete', array($this, 'flush_cache'), 10, 0);
        add_action('load-update-core.php', array($this, 'maybe_force_check'));
        add_action('load-themes.php', array($this, 'maybe_force_check'));
        add_action('load-plugins.php', array($this, 'maybe_force_check'));
    }

    /* ---------- lettura release ---------- */

    /**
     * Cache condivisa per repo: l'elenco release e' scaricato una volta sola
     * (al massimo ogni 12 ore) e riusato da tutti i temi/plugin registrati,
     * cosi' un multisite con decine di child fa 1-3 richieste, non una per tema.
     */
    protected function cache_key() {
        return 'tw_ghu_repo_' . md5($this->repo);
    }

    public function flush_cache() {
        delete_site_transient($this->cache_key());
    }

    public function maybe_force_check() {
        if (isset($_GET['force-check'])) { // phpcs:ignore WordPress.Security.NonceVerification
            $this->flush_cache();
        }
    }

    /**
     * Elenco (ridotto) di tutte le release stabili del repo, dalla cache o da GitHub.
     * Ogni voce: tag, url, body, published, assets => array(name => download_url).
     * Null se GitHub non risponde (ritenta dopo un'ora).
     */
    protected function get_releases() {
        static $memo = array();
        if (array_key_exists($this->repo, $memo)) {
            return $memo[$this->repo];
        }

        $cached = get_site_transient($this->cache_key());
        if (is_array($cached)) {
            return $memo[$this->repo] = (isset($cached['error']) ? null : $cached);
        }

        $releases = array();
        for ($page = 1; $page <= 3; $page++) {
            $response = wp_remote_get(
                sprintf('https://api.github.com/repos/%s/releases?per_page=100&page=%d', $this->repo, $page),
                array(
                    'timeout' => 8,
                    'headers' => array(
                        'Accept'     => 'application/vnd.github+json',
                        'User-Agent' => 'ticinoWEB-updater (' . home_url('/') . ')',
                    ),
                )
            );
            if (is_wp_error($response) || (int) wp_remote_retrieve_response_code($response) !== 200) {
                // Errore di rete o rate limit: si riprova tra un'ora, senza rumore in admin.
                set_site_transient($this->cache_key(), array('error' => true), HOUR_IN_SECONDS);
                return $memo[$this->repo] = null;
            }
            $batch = json_decode(wp_remote_retrieve_body($response), true);
            if (!is_array($batch)) {
                break;
            }
            foreach ($batch as $rel) {
                if (!is_array($rel) || !empty($rel['draft']) || !empty($rel['prerelease']) || empty($rel['tag_name'])) {
                    continue;
                }
                $assets = array();
                foreach ((array) ($rel['assets'] ?? array()) as $asset) {
                    if (!empty($asset['name']) && !empty($asset['browser_download_url'])) {
                        $assets[(string) $asset['name']] = (string) $asset['browser_download_url'];
                    }
                }
                $releases[] = array(
                    'tag'       => (string) $rel['tag_name'],
                    'url'       => (string) ($rel['html_url'] ?? ''),
                    'body'      => (string) ($rel['body'] ?? ''),
                    'published' => (string) ($rel['published_at'] ?? ''),
                    'assets'    => $assets,
                );
            }
            if (count($batch) < 100) {
                break;
            }
        }

        set_site_transient($this->cache_key(), $releases, self::CACHE_TTL);
        return $memo[$this->repo] = $releases;
    }

    /**
     * Ultima release stabile per questo slug: array(version, package, url, body, published, requires, requires_php) o null.
     */
    public function get_latest_release() {
        $releases = $this->get_releases();
        if ($releases === null) {
            return null;
        }
        $prefix = $this->slug . '-v';
        $latest = null;

        foreach ($releases as $rel) {
            if (strpos($rel['tag'], $prefix) !== 0) {
                continue;
            }
            $version = substr($rel['tag'], strlen($prefix));
            if (!preg_match('/^\d+(\.\d+){1,3}$/', $version)) {
                continue;
            }
            $package = '';
            foreach ($rel['assets'] as $name => $url) {
                if (substr($name, -4) === '.zip' && strpos($name, $this->slug) === 0) {
                    $package = $url;
                    break;
                }
            }
            if ($package === '') {
                continue;
            }
            if ($latest === null || version_compare($version, $latest['version'], '>')) {
                $latest = array(
                    'version'      => $version,
                    'package'      => $package,
                    'url'          => $rel['url'],
                    'body'         => $rel['body'],
                    'published'    => $rel['published'],
                    'requires'     => '6.0',
                    'requires_php' => '8.0',
                );
            }
        }
        return $latest;
    }

    protected function has_update() {
        $latest = $this->get_latest_release();
        if (!$latest || !$this->version) {
            return null;
        }
        return version_compare($latest['version'], $this->version, '>') ? $latest : null;
    }

    /* ---------- temi ---------- */

    public function inject_theme_update($transient) {
        if (!is_object($transient)) {
            $transient = new stdClass();
        }
        $latest = $this->has_update();
        if ($latest) {
            if (!isset($transient->response) || !is_array($transient->response)) {
                $transient->response = array();
            }
            $transient->response[$this->slug] = array(
                'theme'        => $this->slug,
                'new_version'  => $latest['version'],
                'url'          => $latest['url'],
                'package'      => $latest['package'],
                'requires'     => $latest['requires'],
                'requires_php' => $latest['requires_php'],
            );
        } elseif (isset($transient->response[$this->slug])) {
            unset($transient->response[$this->slug]);
        }
        return $transient;
    }

    public function theme_details($result, $action, $args) {
        if ($action !== 'theme_information' || empty($args->slug) || $args->slug !== $this->slug) {
            return $result;
        }
        $latest = $this->get_latest_release();
        if (!$latest) {
            return $result;
        }
        $theme = wp_get_theme($this->slug);
        return (object) array(
            'name'          => $theme->get('Name'),
            'slug'          => $this->slug,
            'version'       => $latest['version'],
            'author'        => $theme->get('Author'),
            'homepage'      => 'https://github.com/' . $this->repo,
            'requires'      => $latest['requires'],
            'requires_php'  => $latest['requires_php'],
            'last_updated'  => $latest['published'],
            'download_link' => $latest['package'],
            'sections'      => array(
                'description' => $theme->get('Description'),
                'changelog'   => $this->format_body($latest['body']),
            ),
        );
    }

    /* ---------- plugin ---------- */

    public function inject_plugin_update($transient) {
        if (!is_object($transient)) {
            $transient = new stdClass();
        }
        $latest = $this->has_update();
        if ($latest) {
            if (!isset($transient->response) || !is_array($transient->response)) {
                $transient->response = array();
            }
            $transient->response[$this->basename] = (object) array(
                'slug'         => $this->slug,
                'plugin'       => $this->basename,
                'new_version'  => $latest['version'],
                'url'          => $latest['url'],
                'package'      => $latest['package'],
                'requires'     => $latest['requires'],
                'requires_php' => $latest['requires_php'],
            );
        } elseif (isset($transient->response[$this->basename])) {
            unset($transient->response[$this->basename]);
        }
        return $transient;
    }

    public function plugin_details($result, $action, $args) {
        if ($action !== 'plugin_information' || empty($args->slug) || $args->slug !== $this->slug) {
            return $result;
        }
        $latest = $this->get_latest_release();
        if (!$latest) {
            return $result;
        }
        return (object) array(
            'name'          => $this->slug,
            'slug'          => $this->slug,
            'version'       => $latest['version'],
            'homepage'      => 'https://github.com/' . $this->repo,
            'requires'      => $latest['requires'],
            'requires_php'  => $latest['requires_php'],
            'last_updated'  => $latest['published'],
            'download_link' => $latest['package'],
            'sections'      => array('changelog' => $this->format_body($latest['body'])),
        );
    }

    /* ---------- comuni ---------- */

    /**
     * Lo zip deve estrarre una cartella con il nome dello slug: se l'asset e'
     * stato creato con un altro nome di cartella, la rinomina.
     */
    public function fix_source_folder($source, $remote_source, $upgrader, $hook_extra) {
        $is_ours = ($this->type === 'theme' && !empty($hook_extra['theme']) && $hook_extra['theme'] === $this->slug)
            || ($this->type === 'plugin' && !empty($hook_extra['plugin']) && $hook_extra['plugin'] === $this->basename);
        if (!$is_ours || is_wp_error($source)) {
            return $source;
        }
        global $wp_filesystem;
        $current = basename(untrailingslashit($source));
        if ($current === $this->slug) {
            return $source;
        }
        $target = trailingslashit(dirname(untrailingslashit($source))) . $this->slug;
        if ($wp_filesystem && $wp_filesystem->move($source, $target)) {
            return trailingslashit($target);
        }
        return $source;
    }

    /**
     * Markdown minimale del corpo release → HTML sicuro per la finestra dettagli.
     */
    protected function format_body($md) {
        $md = trim((string) $md);
        if ($md === '') {
            return '';
        }
        $html = '';
        $in_list = false;
        foreach (preg_split('/\r?\n/', $md) as $line) {
            $line = trim($line);
            if (preg_match('/^[-*]\s+(.*)$/', $line, $m)) {
                if (!$in_list) { $html .= '<ul>'; $in_list = true; }
                $html .= '<li>' . $this->inline_md($m[1]) . '</li>';
                continue;
            }
            if ($in_list) { $html .= '</ul>'; $in_list = false; }
            if ($line === '') {
                continue;
            }
            if (preg_match('/^(#{1,6})\s+(.*)$/', $line, $m)) {
                $level = min(4, max(3, strlen($m[1])));
                $html .= "<h{$level}>" . $this->inline_md($m[2]) . "</h{$level}>";
                continue;
            }
            $html .= '<p>' . $this->inline_md($line) . '</p>';
        }
        if ($in_list) { $html .= '</ul>'; }
        return $html;
    }

    protected function inline_md($text) {
        $text = esc_html($text);
        $text = preg_replace('/`([^`]+)`/', '<code>$1</code>', $text);
        $text = preg_replace('/\*\*([^*]+)\*\*/', '<strong>$1</strong>', $text);
        return $text;
    }
}

endif;

// Il parent si registra da solo e registra anche i child theme: in un sito
// singolo il child attivo, in multisite tutti i child installati che derivano
// da ticinoweb-ai-theme (gli aggiornamenti dei temi si gestiscono dalla bacheca
// di rete, dove get_stylesheet() e' solo quello del sito principale). Se sul
// repo delle release esiste un tag `<child>-v<versione>` piu' recente della
// versione in style.css, il child compare tra gli aggiornamenti.
// I child non devono fare nulla.
add_action('init', function () {
    if (!is_admin() && !wp_doing_cron() && !(defined('WP_CLI') && WP_CLI)) {
        return;
    }
    new TW_GitHub_Updater('ticinoweb-ai-theme');

    $children = array();
    if (is_multisite()) {
        foreach (wp_get_themes(array('errors' => false)) as $slug => $theme) {
            if ($theme->get('Template') === 'ticinoweb-ai-theme') {
                $children[] = $slug;
            }
        }
    }
    $active = get_stylesheet();
    if ($active && $active !== 'ticinoweb-ai-theme' && !in_array($active, $children, true)) {
        $children[] = $active;
    }
    foreach ($children as $slug) {
        new TW_GitHub_Updater($slug);
    }
}, 5);
