<?php
/**
 * WooCommerce Compatibility & Theme Support
 *
 * Central file for ALL WooCommerce-related declarations, hooks and helpers.
 * Included by the parent theme — child themes inherit everything automatically
 * without needing to redeclare any support.
 *
 * @package ticinoweb-ai-theme
 * @since   2.7.0
 */

if (!defined('ABSPATH')) {
    exit;
}

// ============================================================================
// 1. THEME SUPPORT
// Declares all WooCommerce features supported by this theme.
// Child themes inherit these automatically via the parent's after_setup_theme.
// ============================================================================
add_action('after_setup_theme', 'ticinoweb_woocommerce_setup', 20);
function ticinoweb_woocommerce_setup()
{
    // Core WooCommerce support with configurable product grid
    add_theme_support('woocommerce', array(
        'thumbnail_image_width' => 450,      // Product thumbnail width (px)
        'single_image_width'    => 800,      // Single product image width (px)
        'product_grid'          => array(
            'default_rows'    => 4,
            'min_rows'        => 1,
            'max_rows'        => 8,
            'default_columns' => 3,
            'min_columns'     => 1,
            'max_columns'     => 6,
        ),
    ));

    // Product gallery enhancements
    add_theme_support('wc-product-gallery-zoom');       // Zoom on hover
    add_theme_support('wc-product-gallery-lightbox');   // Lightbox on click
    add_theme_support('wc-product-gallery-slider');     // Thumbnail slider
}

// ============================================================================
// 2. FEATURE FLAGS COMPATIBILITY
// Declares compatibility with WooCommerce feature flags (HPOS, Blocks, etc.).
// Using parent functions.php as the registration anchor — child themes do NOT
// need to redeclare these.
// ============================================================================
add_action('before_woocommerce_init', 'ticinoweb_declare_woocommerce_compatibility');
function ticinoweb_declare_woocommerce_compatibility()
{
    if (!class_exists('\Automattic\WooCommerce\Utilities\FeaturesUtil')) {
        return;
    }

    // Use parent theme's functions.php as the declaration anchor
    $anchor = get_template_directory() . '/functions.php';

    // HPOS — High-Performance Order Storage
    // Theme does not query orders via legacy post meta → fully compatible
    \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility(
        'custom_order_tables',
        $anchor,
        true
    );

    // Block-based Cart & Checkout (WC Blocks)
    // Templates use standard WC hooks → compatible with block cart/checkout
    \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility(
        'cart_checkout_blocks',
        $anchor,
        true
    );
}

// ============================================================================
// 3. BODY CLASSES
// Adds 'ticinoweb-woocommerce' class on all WC pages for targeted CSS.
// Child themes can target .ticinoweb-woocommerce without extra checks.
// ============================================================================
add_filter('body_class', 'ticinoweb_woocommerce_body_class');
function ticinoweb_woocommerce_body_class($classes)
{
    if (!function_exists('is_woocommerce')) {
        return $classes;
    }

    if (is_woocommerce() || ( function_exists('is_cart') && is_cart() ) || ( function_exists('is_checkout') && is_checkout() ) || ( function_exists('is_account_page') && is_account_page() )) {
        $classes[] = 'ticinoweb-woocommerce';
    }

    return $classes;
}

// ============================================================================
// 4. WOOCOMMERCE HELPERS
// Utility functions available to all child themes.
// ============================================================================

/**
 * Check if WooCommerce is active (plugin loaded).
 * Safe to call before WC is fully initialized.
 *
 * @return bool
 */
if (!function_exists('ticinoweb_is_woocommerce_active')) {
    function ticinoweb_is_woocommerce_active()
    {
        return class_exists('WooCommerce');
    }
}

/**
 * Get the WooCommerce shop URL from mapped page (CMS) or WC default.
 *
 * @return string
 */
if (!function_exists('ticinoweb_get_shop_url')) {
    function ticinoweb_get_shop_url()
    {
        $mapped = function_exists('ticinoweb_get_mapped_page_url')
            ? ticinoweb_get_mapped_page_url('page_shop')
            : false;

        $url = $mapped ? $mapped : (function_exists('wc_get_page_permalink') ? wc_get_page_permalink('shop') : home_url('/shop/'));
        return function_exists('ticinoweb_frontend_url') ? ticinoweb_frontend_url($url, 'theme:url:shop') : $url;
    }
}

/**
 * Get the WooCommerce cart URL.
 *
 * @return string
 */
if (!function_exists('ticinoweb_get_cart_url')) {
    function ticinoweb_get_cart_url()
    {
        $url = function_exists('wc_get_cart_url') ? wc_get_cart_url() : home_url('/carrello/');
        return function_exists('ticinoweb_frontend_url') ? ticinoweb_frontend_url($url, 'theme:url:cart') : $url;
    }
}

/**
 * Get cart item count (safe, returns 0 if WC not active).
 *
 * @return int
 */
if (!function_exists('ticinoweb_get_cart_count')) {
    function ticinoweb_get_cart_count()
    {
        if (!ticinoweb_is_woocommerce_active() || !WC()->cart) {
            return 0;
        }
        return (int) WC()->cart->get_cart_contents_count();
    }
}

/**
 * Get cart total (safe, returns empty string if WC not active).
 *
 * @return string HTML-formatted cart total
 */
if (!function_exists('ticinoweb_get_cart_total')) {
    function ticinoweb_get_cart_total()
    {
        if (!ticinoweb_is_woocommerce_active() || !WC()->cart) {
            return '';
        }
        return WC()->cart->get_cart_total();
    }
}

// ============================================================================
// 5. OPTIONAL OVERRIDES (commented — child themes can uncomment as needed)
// ============================================================================

// Remove WooCommerce default styles (enable if child theme fully replaces them):
// add_filter('woocommerce_enqueue_styles', '__return_empty_array');

// Remove WooCommerce breadcrumbs globally:
// remove_action('woocommerce_before_main_content', 'woocommerce_breadcrumb', 20);

// Remove WooCommerce sidebar globally:
// remove_action('woocommerce_sidebar', 'woocommerce_get_sidebar', 10);
