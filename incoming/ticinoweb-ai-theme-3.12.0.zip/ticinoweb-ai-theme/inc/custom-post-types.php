<?php
/**
 * Register Custom Post Types dynamically from Theme Settings
 */

if (!defined('ABSPATH')) {
    exit;
}

add_action('init', 'ticinoweb_register_custom_post_types');
function ticinoweb_register_custom_post_types() {
    $cpts = get_option('ticinoweb_custom_post_types', []);
    
    if (empty($cpts) || !is_array($cpts)) {
        return;
    }
    
    foreach ($cpts as $cpt) {
        if (empty($cpt['slug'])) continue;

        $icon_slug = sanitize_title($cpt['slug']); // Ensure slug is safe
        
        $singular = !empty($cpt['singular']) ? $cpt['singular'] : ucfirst($icon_slug);
        $plural = !empty($cpt['plural']) ? $cpt['plural'] : $singular . 's';
        
        // Determine icon (Dashicon or SVG)
        $icon = !empty($cpt['icon']) ? $cpt['icon'] : 'dashicons-admin-post'; // Default fallback
        if (isset($cpt['icon_type']) && $cpt['icon_type'] === 'svg' && !empty($cpt['icon_svg'])) {
            $icon = $cpt['icon_svg'];
        }
        
        $public = isset($cpt['public']) ? (bool) $cpt['public'] : false;
        $has_archive = isset($cpt['has_archive']) ? (bool) $cpt['has_archive'] : false;
        
        $labels = array(
            'name'                  => $plural,
            'singular_name'         => $singular,
            'menu_name'             => $plural,
            'name_admin_bar'        => $singular,
            'add_new'               => 'Aggiungi Nuovo',
            'add_new_item'          => 'Aggiungi Nuovo ' . $singular,
            'new_item'              => 'Nuovo ' . $singular,
            'edit_item'             => 'Modifica ' . $singular,
            'view_item'             => 'Vedi ' . $singular,
            'all_items'             => 'Tutti i ' . $plural,
            'search_items'          => 'Cerca ' . $plural,
            'parent_item_colon'     => 'Genitore ' . $plural . ':',
            'not_found'             => 'Nessun ' . strtolower($singular) . ' trovato.',
            'not_found_in_trash'    => 'Nessun ' . strtolower($singular) . ' trovato nel cestino.'
        );
        
        $args = array(
            'labels'             => $labels,
            'public'             => $public,
            'publicly_queryable' => $public,
            'show_ui'            => true,
            'show_in_menu'       => true,
            'query_var'          => true,
            'rewrite'            => array('slug' => $icon_slug),
            'capability_type'    => 'post',
            'has_archive'        => $has_archive,
            'hierarchical'       => false,
            'menu_position'      => null,
            'menu_icon'          => $icon,
            'supports'           => array('title', 'editor', 'thumbnail', 'excerpt', 'custom-fields', 'page-attributes'),
            'show_in_rest'       => true, // Enable Gutenberg editor
        );
        
        register_post_type($icon_slug, $args);
    }
}

/**
 * Add CSS to style SVG icons in Admin Menu (Force White Color)
 */
add_action('admin_head', 'ticinoweb_cpt_icons_css', 100);
function ticinoweb_cpt_icons_css() {
    $cpts = get_option('ticinoweb_custom_post_types', []);
    
    if (empty($cpts) || !is_array($cpts)) {
        return;
    }
    
    $css = '';

    // Ensure default Posts menu label stays readable when renamed (e.g., "Referenze")
    $css .= "
    #menu-posts a.menu-top,
    #menu-posts .wp-menu-name {
        color: #f0f0f1 !important;
    }
    #menu-posts:hover a.menu-top,
    #menu-posts.wp-has-current-submenu a.menu-top {
        color: #ffffff !important;
    }";
    
    foreach ($cpts as $cpt) {
        if (empty($cpt['slug'])) continue;
        
        // Apply only if SVG is selected
        if (isset($cpt['icon_type']) && $cpt['icon_type'] === 'svg' && !empty($cpt['icon_svg'])) {
            $slug = sanitize_title($cpt['slug']); // Ensure matching logic with registration
             
            // Force white color using filter
            $css .= "
            #menu-posts-{$slug} .wp-menu-image img {
                width: 20px !important;
                height: 20px !important;
                filter: brightness(0) invert(1) !important;
                opacity: 0.9 !important;
                padding-top: 7px !important; 
            }
            #menu-posts-{$slug}:hover .wp-menu-image img, 
            #menu-posts-{$slug}.wp-has-current-submenu .wp-menu-image img {
                opacity: 1 !important;
            }";
        }
    }
    
    if (!empty($css)) {
        echo '<style type="text/css" id="ticinoweb-cpt-icons">' . $css . '</style>';
    }
}
