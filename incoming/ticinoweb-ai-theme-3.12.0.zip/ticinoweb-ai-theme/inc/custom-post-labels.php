<?php
/**
 * Custom Post Type Labels Override
 * Rinomina il post type "post" con etichette personalizzate
 */

if (!defined('ABSPATH')) {
    exit;
}

// Override post type labels
add_action('init', 'ticinoweb_customize_post_labels', 999);
function ticinoweb_customize_post_labels() {
    global $wp_post_types;
    
    $singular = get_option('ticinoweb_post_name_singular', 'Articolo');
    $plural = get_option('ticinoweb_post_name_plural', 'Articoli');
    $gender = get_option('ticinoweb_post_gender', 'maschile');
    $icon = get_option('ticinoweb_post_icon', 'dashicons-admin-post');
    
    // Handle empty strings (fallback to defaults if empty)
    $singular = !empty($singular) ? $singular : 'Articolo';
    $plural = !empty($plural) ? $plural : 'Articoli';
    $gender = !empty($gender) ? $gender : 'maschile';
    $icon = !empty($icon) ? $icon : 'dashicons-admin-post';
    
    // Determina articoli/pronomi in base al genere
    if ($gender === 'femminile') {
        $article_sing = 'una';
        $article_plur = 'le';
        $all = 'tutte le';
    } else {
        $article_sing = 'un';
        $article_plur = 'i';
        $all = 'tutti gli';
    }
    
    if (isset($wp_post_types['post'])) {
        $labels = &$wp_post_types['post']->labels;
        
        $labels->name = $plural;
        $labels->singular_name = $singular;
        $labels->add_new = 'Aggiungi ' . $singular;
        $labels->add_new_item = 'Aggiungi Nuov' . ($gender === 'maschile' ? 'o' : 'a') . ' ' . $singular;
        $labels->edit_item = 'Modifica ' . $singular;
        $labels->new_item = 'Nuov' . ($gender === 'maschile' ? 'o' : 'a') . ' ' . $singular;
        $labels->view_item = 'Visualizza ' . $singular;
        $labels->view_items = 'Visualizza ' . $plural;
        $labels->search_items = 'Cerca ' . $plural;
        $labels->not_found = 'Nessun' . ($gender === 'maschile' ? 'o' : 'a') . ' ' . $singular . ' trovato';
        $labels->not_found_in_trash = 'Nessun' . ($gender === 'maschile' ? 'o' : 'a') . ' ' . $singular . ' nel cestino';
        $labels->parent_item_colon = $singular . ' Genitore:';
        $labels->all_items = ucfirst($all) . ' ' . $plural;
        $labels->archives = 'Archivio ' . $plural;
        $labels->attributes = 'Attributi ' . $singular;
        $labels->insert_into_item = 'Inserisci in ' . $singular;
        $labels->uploaded_to_this_item = 'Caricato in quest' . ($gender === 'maschile' ? 'o' : 'a') . ' ' . $singular;
        $labels->featured_image = 'Immagine in evidenza';
        $labels->set_featured_image = 'Imposta immagine in evidenza';
        $labels->remove_featured_image = 'Rimuovi immagine in evidenza';
        $labels->use_featured_image = 'Usa come immagine in evidenza';
        $labels->menu_name = $plural;
        $labels->filter_items_list = 'Filtra lista ' . $plural;
        $labels->items_list_navigation = 'Navigazione lista ' . $plural;
        $labels->items_list = 'Lista ' . $plural;
        $labels->item_published = $singular . ' pubblicat' . ($gender === 'maschile' ? 'o' : 'a');
        $labels->item_published_privately = $singular . ' pubblicat' . ($gender === 'maschile' ? 'o' : 'a') . ' privatamente';
        $labels->item_reverted_to_draft = $singular . ' riportat' . ($gender === 'maschile' ? 'o' : 'a') . ' in bozza';
        $labels->item_scheduled = $singular . ' pianificat' . ($gender === 'maschile' ? 'o' : 'a');
        $labels->item_updated = $singular . ' aggiornat' . ($gender === 'maschile' ? 'o' : 'a');
        
        // Update menu icon
        $wp_post_types['post']->menu_icon = $icon;
    }
}

// Update admin menu icon via filter (fallback)
add_filter('register_post_type_args', 'ticinoweb_update_post_icon', 10, 2);
function ticinoweb_update_post_icon($args, $post_type) {
    if ($post_type === 'post') {
        $icon = get_option('ticinoweb_post_icon', 'dashicons-admin-post');
        $args['menu_icon'] = $icon;
    }
    return $args;
}
