<?php
/**
 * Dashboard Widget: statistiche visitatori (giorno, settimana, mese, anno).
 *
 * Due grafici con lo stesso selettore di periodo:
 * - Visitatori unici: ogni browser e' contato una volta per giorno, una per
 *   settimana, una per mese e una per anno (non la somma dei giorni).
 * - Tempo medio per visita: tempo di lettura attiva (pagina visibile, utente
 *   non inattivo da piu' di 3 minuti) diviso per il numero di visite.
 *   Una visita finisce dopo 30 minuti senza attivita'.
 *
 * Come funziona (dalla 3.12.0)
 * La pagina stampa uno script statico (cacheabile da LiteSpeed). Il browser
 * ricorda in localStorage in quale giorno/settimana/mese/anno e' gia' stato
 * contato e l'ora dell'ultima attivita': nessun identificativo del visitatore,
 * nessun dato personale. Lo script invia a admin-ajax.php solo dei flag
 * ("nuovo per questo mese", "nuova visita") e i secondi di lettura; il server
 * somma i valori in `{prefix}tw_visit_stats` con un'unica INSERT ... ON
 * DUPLICATE KEY UPDATE, atomica anche con visite simultanee.
 *
 * Bot esclusi: lo script parte solo con JavaScript, solo quando la pagina e'
 * visibile (non in prerender o in schede aperte in background) e non sui
 * browser automatizzati (navigator.webdriver); il server scarta in piu' gli
 * user agent di crawler, strumenti SEO/performance, monitor e client HTTP.
 * Gli utenti collegati sono contati come tutti gli altri.
 *
 * Storico: i conteggi giornalieri registrati fino alla 3.11.x (opzione
 * `ticinoweb_daily_visits`) sono importati una volta nella tabella. Per i
 * periodi iniziati prima dell'importazione la parte precedente e' la somma
 * di quei conteggi giornalieri.
 */

if (!defined('ABSPATH')) {
    exit;
}

define('TICINOWEB_STATS_DB_VERSION', '1');

/** Nome della tabella del sito corrente (in multisite una per sito). */
function ticinoweb_stats_table() {
    global $wpdb;
    return $wpdb->prefix . 'tw_visit_stats';
}

/**
 * Crea la tabella e importa lo storico, una sola volta per sito.
 * Chiamata dal beacon e dal widget: il primo che arriva installa.
 */
function ticinoweb_stats_maybe_install() {
    if (get_option('ticinoweb_stats_db_version') === TICINOWEB_STATS_DB_VERSION) {
        return;
    }

    global $wpdb;
    $table = ticinoweb_stats_table();
    $charset_collate = $wpdb->get_charset_collate();

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta("CREATE TABLE $table (
        pkey varchar(12) NOT NULL,
        metric varchar(8) NOT NULL,
        value bigint(20) unsigned NOT NULL DEFAULT 0,
        PRIMARY KEY  (pkey,metric)
    ) $charset_collate;");

    // Importa i conteggi giornalieri della versione precedente (INSERT IGNORE:
    // ripetere l'importazione non duplica nulla).
    $legacy = get_option('ticinoweb_daily_visits', array());
    if (is_array($legacy) && $legacy) {
        foreach (array_chunk($legacy, 100, true) as $chunk) {
            $values = array();
            foreach ($chunk as $day => $count) {
                if (preg_match('/^\d{8}$/', (string) $day) && (int) $count > 0) {
                    $values[] = $wpdb->prepare('(%s,%s,%d)', 'd' . $day, 'u', (int) $count);
                }
            }
            if ($values) {
                $wpdb->query("INSERT IGNORE INTO $table (pkey,metric,value) VALUES " . implode(',', $values)); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- valori preparati sopra
            }
        }
    }

    // Da questo giorno i conteggi di settimana/mese/anno sono unici "veri".
    add_option('ticinoweb_stats_since', wp_date('Y-m-d'), '', false);
    update_option('ticinoweb_stats_db_version', TICINOWEB_STATS_DB_VERSION, true);
}
add_action('admin_init', 'ticinoweb_stats_maybe_install');

/** Chiavi dei periodi che contengono il timestamp, nel fuso del sito. */
function ticinoweb_stats_period_keys($timestamp) {
    $date = (new DateTimeImmutable('@' . (int) $timestamp))->setTimezone(wp_timezone());
    return array(
        'd' => 'd' . $date->format('Ymd'),
        'w' => 'w' . $date->format('o\WW'),
        'm' => 'm' . $date->format('Ym'),
        'y' => 'y' . $date->format('Y'),
    );
}

/** User agent di bot, crawler, strumenti di analisi e client HTTP. */
function ticinoweb_stats_is_bot() {
    $ua = isset($_SERVER['HTTP_USER_AGENT']) ? (string) wp_unslash($_SERVER['HTTP_USER_AGENT']) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- usato solo in preg_match
    if ($ua === '') {
        return true;
    }
    $pattern = '/(?<!cu)bot\b|bot\/|crawl|spider|slurp|archiver|facebookexternalhit|embedly|preview|headless|lighthouse|pagespeed|gtmetrix|pingdom|uptime|statuscake|site24x7|monitor|phantom|puppeteer|playwright|selenium|webdriver|python|curl|wget|java\/|go-http|okhttp|axios|node-fetch|httpclient|libwww|scrapy|ahrefs|semrush|mj12|dotbot|bytespider|petalbot|yandex|baidu|seznam|gptbot|chatgpt|claude|anthropic|ccbot|perplexity|amazonbot|applebot|googleother|google-inspectiontool|ptst|prerender/i';
    return (bool) apply_filters('ticinoweb_stats_is_bot', (bool) preg_match($pattern, $ua), $ua);
}

/**
 * Script del beacon. Stato in localStorage `tw_stats`:
 * d/w/m/y = ultimo giorno/settimana/mese/anno gia' contato, l = ultima attivita' (ms).
 */
add_action('wp_footer', 'ticinoweb_print_visit_beacon', 99);
function ticinoweb_print_visit_beacon() {
    if (is_admin() || is_feed() || is_embed() || is_robots()) {
        return;
    }
    if (function_exists('is_customize_preview') && is_customize_preview()) {
        return;
    }

    $js = <<<'JS'
(function(){try{
var n=navigator,ls=window.localStorage;
if(!ls||n.webdriver||/(^|[^u])bot\b|bot\/|crawl|spider|slurp|headless|lighthouse|pagespeed|gtmetrix|pingdom|phantom|puppeteer|playwright|selenium|prerender/i.test(n.userAgent))return;
var U=__URL__,K='tw_stats',IDLE=180000,GAP=1800000,st={},acc=0,since=0,last=Date.now(),seen=false;
try{st=JSON.parse(ls.getItem(K))||{};}catch(e){}
function save(){try{ls.setItem(K,JSON.stringify(st));}catch(e){}}
function send(o){var b=new FormData(),k;b.append('action','ticinoweb_track_visit');for(k in o)b.append(k,o[k]);
if(n.sendBeacon&&n.sendBeacon(U,b))return;if(window.fetch)fetch(U,{method:'POST',body:b,credentials:'same-origin',keepalive:true});}
function p2(x){return(x<10?'0':'')+x;}
function keys(d){var y=d.getFullYear(),m=p2(d.getMonth()+1),t=new Date(Date.UTC(y,d.getMonth(),d.getDate())),wd=t.getUTCDay()||7,wy,w;
t.setUTCDate(t.getUTCDate()+4-wd);wy=t.getUTCFullYear();w=Math.ceil(((t-Date.UTC(wy,0,1))/864e5+1)/7);
return{d:''+y+m+p2(d.getDate()),w:wy+'W'+p2(w),m:''+y+m,y:''+y};}
function hit(){var now=Date.now(),k=keys(new Date()),o={},any=false,p;
for(p in k){if(st[p]!==k[p]){o['u'+p]=1;st[p]=k[p];any=true;}}
if(!st.l||now-st.l>GAP){o.s=1;any=true;}
st.l=now;save();if(any)send(o);}
function start(){if(document.visibilityState!=='visible')return;seen=true;hit();if(!since){since=last=Date.now();}}
function stop(){if(since){var e=Math.min(Date.now(),last+IDLE);if(e>since)acc+=e-since;since=0;}}
function flush(){stop();var s=Math.floor(acc/1000);if(s>0){acc-=s*1000;send({t:s});}if(seen){st.l=Math.max(st.l||0,last);save();}}
function act(){var now=Date.now();if(document.visibilityState!=='visible')return;
if(!since||now-last>IDLE){stop();start();}last=now;if(now-(st.l||0)>60000){st.l=now;save();}}
['mousemove','mousedown','keydown','scroll','touchstart','wheel'].forEach(function(e){window.addEventListener(e,act,{passive:true,capture:true});});
document.addEventListener('visibilitychange',function(){if(document.visibilityState==='hidden')flush();else start();});
window.addEventListener('pagehide',flush);
start();
}catch(e){}})();
JS;
    $js = str_replace('__URL__', wp_json_encode(admin_url('admin-ajax.php')), $js);

    if (function_exists('wp_print_inline_script_tag')) {
        wp_print_inline_script_tag($js, array('id' => 'ticinoweb-visit-beacon'));
    } else {
        echo '<script id="ticinoweb-visit-beacon">' . $js . '</script>' . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput
    }
}

add_action('wp_ajax_nopriv_ticinoweb_track_visit', 'ticinoweb_track_visit');
add_action('wp_ajax_ticinoweb_track_visit', 'ticinoweb_track_visit');
function ticinoweb_track_visit() {
    if ((defined('WP_CLI') && WP_CLI) || (defined('DOING_CRON') && DOING_CRON) || !wp_doing_ajax()) {
        return;
    }
    if (!isset($_SERVER['REQUEST_METHOD']) || strtoupper($_SERVER['REQUEST_METHOD']) !== 'POST') {
        wp_send_json_error('method', 405);
    }
    if (ticinoweb_stats_is_bot()) {
        wp_send_json_success(array('counted' => false));
    }

    // phpcs:disable WordPress.Security.NonceVerification.Missing -- beacon pubblico su pagine in cache: solo flag e un intero, nessuna azione privilegiata.
    $keys    = ticinoweb_stats_period_keys(time());
    $metrics = array();

    // Seconda barriera oltre al localStorage: un cookie HttpOnly per il giorno.
    // Se il browser e' gia' stato contato oggi, non e' nuovo neppure per
    // settimana, mese o anno.
    $cookie_name = 'ticinoweb_visit_' . substr($keys['d'], 1);
    $new_today   = empty($_COOKIE[$cookie_name]);
    $unique      = array();
    if ($new_today) {
        foreach (array('d', 'w', 'm', 'y') as $p) {
            if (!empty($_POST['u' . $p])) {
                $unique[] = $p;
            }
        }
    }
    foreach ($unique as $p) {
        $metrics[] = array($keys[$p], 'u', 1);
    }

    if (!empty($_POST['s'])) {
        foreach ($keys as $key) {
            $metrics[] = array($key, 's', 1);
        }
    }

    // Secondi di lettura attiva dall'ultimo invio (massimo 30 minuti per invio).
    $seconds = isset($_POST['t']) ? min(1800, absint($_POST['t'])) : 0;
    if ($seconds > 0) {
        foreach ($keys as $key) {
            $metrics[] = array($key, 't', $seconds);
        }
    }
    // phpcs:enable

    if (!$metrics) {
        wp_send_json_success(array('counted' => false));
    }

    ticinoweb_stats_maybe_install();

    global $wpdb;
    $table  = ticinoweb_stats_table();
    $values = array();
    foreach ($metrics as $m) {
        $values[] = $wpdb->prepare('(%s,%s,%d)', $m[0], $m[1], $m[2]);
    }
    $wpdb->query("INSERT INTO $table (pkey,metric,value) VALUES " . implode(',', $values) . ' ON DUPLICATE KEY UPDATE value = value + VALUES(value)'); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- valori preparati sopra

    if ($unique) {
        setcookie($cookie_name, '1', array(
            'expires'  => time() + DAY_IN_SECONDS,
            'path'     => COOKIEPATH,
            'domain'   => COOKIE_DOMAIN,
            'secure'   => is_ssl(),
            'httponly' => true,
            'samesite' => 'Lax',
        ));
    }

    wp_send_json_success(array('counted' => true));
}

add_action('wp_dashboard_setup', 'ticinoweb_register_dashboard_widget');
function ticinoweb_register_dashboard_widget() {
    wp_add_dashboard_widget(
        'ticinoweb_visits_widget',
        __('Statistiche Visitatori', 'ticinoweb-ai-theme'),
        'ticinoweb_render_dashboard_widget'
    );
}

/** Tutti i contatori del sito: [pkey][metric] => valore. Una query per richiesta. */
function ticinoweb_stats_all() {
    static $data = null;
    if ($data !== null) {
        return $data;
    }
    ticinoweb_stats_maybe_install();

    global $wpdb;
    $data = array();
    $rows = $wpdb->get_results('SELECT pkey, metric, value FROM ' . ticinoweb_stats_table(), ARRAY_N); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- nessun input
    foreach ((array) $rows as $row) {
        $data[$row[0]][$row[1]] = (int) $row[2];
    }
    return $data;
}

/**
 * Ultimi $count periodi del tipo indicato (d, w, m, y), dal piu' vecchio.
 * Ogni periodo: key, label, start/end (DateTimeImmutable, end escluso).
 */
function ticinoweb_stats_periods($type, $count) {
    $today = new DateTimeImmutable('today', wp_timezone());
    switch ($type) {
        case 'w':
            $base = $today->modify('monday this week');
            $step = 'week';
            break;
        case 'm':
            $base = $today->modify('first day of this month');
            $step = 'month';
            break;
        case 'y':
            $base = $today->setDate((int) $today->format('Y'), 1, 1);
            $step = 'year';
            break;
        default:
            $type = 'd';
            $base = $today;
            $step = 'day';
    }

    $periods = array();
    for ($i = $count - 1; $i >= 0; $i--) {
        $start = $base->modify("-$i $step");
        $end   = $start->modify("+1 $step");
        $ts    = $start->getTimestamp();
        switch ($type) {
            case 'd':
                $key   = 'd' . $start->format('Ymd');
                $label = wp_date('D j', $ts);
                break;
            case 'w':
                $key   = 'w' . $start->format('o\WW');
                $label = wp_date('j M', $ts);
                break;
            case 'm':
                $key   = 'm' . $start->format('Ym');
                $label = wp_date('M', $ts);
                break;
            default:
                $key   = 'y' . $start->format('Y');
                $label = $start->format('Y');
        }
        $periods[] = compact('key', 'label', 'start', 'end');
    }
    return $periods;
}

/** Visitatori unici del periodo (con la parte storica per i giorni prima dell'importazione). */
function ticinoweb_stats_unique($period, $data) {
    $total = isset($data[$period['key']]['u']) ? $data[$period['key']]['u'] : 0;
    if ($period['key'][0] === 'd') {
        return $total;
    }

    $since = DateTimeImmutable::createFromFormat('!Y-m-d', (string) get_option('ticinoweb_stats_since', ''), wp_timezone());
    if (!$since || $period['start'] >= $since) {
        return $total;
    }
    $until = $period['end'] < $since ? $period['end'] : $since;
    for ($day = $period['start']; $day < $until; $day = $day->modify('+1 day')) {
        $key = 'd' . $day->format('Ymd');
        if (isset($data[$key]['u'])) {
            $total += $data[$key]['u'];
        }
    }
    return $total;
}

/** Secondi medi per visita nel periodo (0 se non ci sono visite misurate). */
function ticinoweb_stats_avg_seconds($period, $data) {
    $row = isset($data[$period['key']]) ? $data[$period['key']] : array();
    $sessions = isset($row['s']) ? $row['s'] : 0;
    $seconds  = isset($row['t']) ? $row['t'] : 0;
    return $sessions > 0 ? (int) round($seconds / $sessions) : 0;
}

/** Minuti:secondi ("0:45", "16:15", "1:02:05"): sta anche in 8 barre strette. */
function ticinoweb_stats_format_duration($seconds) {
    $seconds = (int) $seconds;
    if ($seconds <= 0) {
        return '–';
    }
    if ($seconds >= HOUR_IN_SECONDS) {
        return sprintf('%d:%02d:%02d', intdiv($seconds, HOUR_IN_SECONDS), intdiv($seconds % HOUR_IN_SECONDS, 60), $seconds % 60);
    }
    return sprintf('%d:%02d', intdiv($seconds, 60), $seconds % 60);
}

/**
 * Visitatori unici degli ultimi $days giorni (somma dei giorni).
 * Mantenuta per compatibilita' con eventuali child che la usano.
 */
function ticinoweb_get_visit_sum($days) {
    $data = ticinoweb_stats_all();
    $total = 0;
    foreach (ticinoweb_stats_periods('d', max(1, (int) $days)) as $period) {
        $total += ticinoweb_stats_unique($period, $data);
    }
    return $total;
}

/** Barre di un grafico: $bars = [ ['label', 'value', 'display'] ]. */
function ticinoweb_stats_render_bars($period, $bars) {
    $max_value = max(1, max(array_column($bars, 'value')));
    ?>
    <div class="ticinoweb-widget-chart-container" data-period="<?php echo esc_attr($period); ?>">
        <?php foreach ($bars as $bar) :
            $height = (int) round(($bar['value'] / $max_value) * 100);
            $height = max(10, min(100, $height));
            ?>
            <div class="ticinoweb-bar">
                <div class="ticinoweb-bar-graph" aria-hidden="true">
                    <div class="ticinoweb-bar-fill" style="height: <?php echo esc_attr($height); ?>px; background: #2563eb;"></div>
                </div>
                <div class="ticinoweb-bar-value"><?php echo esc_html($bar['display']); ?></div>
                <span class="ticinoweb-bar-label"><?php echo esc_html($bar['label']); ?></span>
            </div>
        <?php endforeach; ?>
    </div>
    <?php
}

function ticinoweb_render_dashboard_widget() {
    $data = ticinoweb_stats_all();
    $ranges = array(
        'daily'   => array('d', 7),
        'weekly'  => array('w', 8),
        'monthly' => array('m', 6),
        'yearly'  => array('y', 5),
    );

    $visitors = array();
    $durations = array();
    foreach ($ranges as $period => $range) {
        foreach (ticinoweb_stats_periods($range[0], $range[1]) as $p) {
            $unique = ticinoweb_stats_unique($p, $data);
            $avg    = ticinoweb_stats_avg_seconds($p, $data);
            $visitors[$period][]  = array('label' => $p['label'], 'value' => $unique, 'display' => number_format_i18n($unique));
            $durations[$period][] = array('label' => $p['label'], 'value' => $avg, 'display' => ticinoweb_stats_format_duration($avg));
        }
    }

    $logo_url = get_template_directory_uri() . '/assets/images/logo-ticinoweb-2025.png';
    ?>
    <style>
        .ticinoweb-widget-wrap {
            padding: 10px 8px 8px;
        }
        .ticinoweb-widget-glass {
            background: rgba(255, 255, 255, 0.72);
            border-radius: 0;
            border: 1px solid rgba(255, 255, 255, 0.45);
            box-shadow: none;
            backdrop-filter: blur(12px) saturate(140%);
            -webkit-backdrop-filter: blur(12px) saturate(140%);
            padding: 14px 14px 12px;
        }
        .ticinoweb-widget-head {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 12px;
            margin-bottom: 10px;
        }
        .ticinoweb-widget-logo {
            max-width: 100px;
            height: auto;
            display: block;
            filter: drop-shadow(0 6px 12px rgba(15, 23, 42, 0.1));
        }
        .ticinoweb-widget-select {
            display: flex;
            flex-direction: column;
            gap: 4px;
            align-items: flex-end;
        }
        .ticinoweb-widget-select select {
            border-radius: 999px;
            padding: 4px 12px 5px;
            border: 1px solid rgba(148, 163, 184, 0.6);
            background: rgba(255, 255, 255, 0.9);
            font-size: 12px;
            color: #1f2937;
            box-shadow: inset 0 0 0 1px rgba(255, 255, 255, 0.4);
        }
        .ticinoweb-widget-title {
            margin: 4px 0 8px;
            font-size: 13px;
            font-weight: 600;
            color: #111827;
        }
        .ticinoweb-widget-section + .ticinoweb-widget-section {
            margin-top: 16px;
        }
        .ticinoweb-bar {
            background: #f3f4f6;
            border-radius: 0;
            padding: 6px 4px 8px;
            text-align: center;
            box-shadow: inset 0 0 0 1px rgba(15, 23, 42, 0.06);
            flex: 1;
            min-width: 0;
        }
        .ticinoweb-bar-graph {
            height: 100px;
            display: flex;
            align-items: flex-end;
            justify-content: center;
            margin-bottom: 6px;
        }
        .ticinoweb-bar-fill {
            width: 100%;
            border-radius: 0;
            transition: height 0.3s ease;
            position: relative;
            overflow: hidden;
        }
        .ticinoweb-bar-fill::after {
            content: '';
            position: absolute;
            inset: 0;
            background: linear-gradient(120deg, rgba(255, 255, 255, 0.45) 0%, rgba(255, 255, 255, 0.12) 35%, rgba(255, 255, 255, 0.5) 70%, rgba(255, 255, 255, 0.18) 100%);
            opacity: 0.6;
            mix-blend-mode: screen;
        }
        .ticinoweb-bar-value {
            font-size: 13px;
            font-weight: 700;
            color: #111827;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        .ticinoweb-bar-label {
            display: block;
            font-size: 10px;
            color: #6b7280;
            margin-top: 2px;
        }
        .ticinoweb-widget-chart-container {
            display: none;
        }
        .ticinoweb-widget-chart-container.active {
            display: flex;
            gap: 4px;
            margin-bottom: 12px;
        }
        .ticinoweb-widget-footnote {
            font-size: 11px;
            color: #6b7280;
        }
    </style>
    <div class="ticinoweb-widget-wrap" id="ticinoweb-visits-widget">
        <div class="ticinoweb-widget-glass">
            <div class="ticinoweb-widget-head">
                <img class="ticinoweb-widget-logo" src="<?php echo esc_url($logo_url); ?>" alt="ticinoWEB">
                <div class="ticinoweb-widget-select">
                    <select id="ticinoweb-period-select" class="ticinoweb-period-select" aria-label="<?php esc_attr_e('Seleziona periodo', 'ticinoweb-ai-theme'); ?>">
                        <option value="daily"><?php esc_html_e('Giornaliero', 'ticinoweb-ai-theme'); ?></option>
                        <option value="weekly" selected><?php esc_html_e('Settimanale', 'ticinoweb-ai-theme'); ?></option>
                        <option value="monthly"><?php esc_html_e('Mensile', 'ticinoweb-ai-theme'); ?></option>
                        <option value="yearly"><?php esc_html_e('Annuale', 'ticinoweb-ai-theme'); ?></option>
                    </select>
                </div>
            </div>

            <div class="ticinoweb-widget-section">
                <h3 class="ticinoweb-widget-title"><?php esc_html_e('Visitatori unici', 'ticinoweb-ai-theme'); ?></h3>
                <?php foreach ($visitors as $period => $bars) {
                    ticinoweb_stats_render_bars($period, $bars);
                } ?>
            </div>

            <div class="ticinoweb-widget-section">
                <h3 class="ticinoweb-widget-title"><?php esc_html_e('Tempo medio per visita (minuti:secondi)', 'ticinoweb-ai-theme'); ?></h3>
                <?php foreach ($durations as $period => $bars) {
                    ticinoweb_stats_render_bars($period, $bars);
                } ?>
            </div>

            <div class="ticinoweb-widget-footnote">
                <?php esc_html_e('Ogni visitatore è contato una volta per periodo; bot e crawler sono esclusi. Il tempo medio misura la lettura attiva di ogni visita.', 'ticinoweb-ai-theme'); ?>
            </div>
        </div>
    </div>
    <script>
        (function() {
            var widget = document.getElementById('ticinoweb-visits-widget');
            if (!widget) {
                return;
            }
            var select = widget.querySelector('.ticinoweb-period-select');
            var containers = widget.querySelectorAll('.ticinoweb-widget-chart-container');

            var updateCharts = function() {
                var value = select.value;
                containers.forEach(function(container) {
                    container.classList.toggle('active', container.getAttribute('data-period') === value);
                });
            };

            select.addEventListener('change', updateCharts);
            updateCharts();
        })();
    </script>
    <?php
}
