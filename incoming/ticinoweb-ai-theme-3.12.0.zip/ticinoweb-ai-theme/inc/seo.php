<?php
/**
 * tW SEO Module - Modern Liquid Glass SEO for ticinoWEB AI Theme
 * Handles Meta Tags, JSON-LD Schema, Social Sharing, and Sitemap settings.
 */

if (!defined('ABSPATH')) {
    exit;
}

// Add admin menu
add_action('admin_menu', 'tw_seo_add_menu');
function tw_seo_add_menu() {
    add_menu_page(
        __('tW SEO', 'ticinoweb-ai-theme'),
        __('tW SEO', 'ticinoweb-ai-theme'),
        'edit_pages',
        'tw-seo',
        'tw_seo_render_page',
        'dashicons-chart-area', // Wireframe chart icon
        31
    );
}

// Enqueue media library for SEO page
add_action('admin_enqueue_scripts', 'tw_seo_admin_assets');
function tw_seo_admin_assets($hook) {
    if ($hook !== 'toplevel_page_tw-seo') {
        return;
    }
    wp_enqueue_media();
}

// Register settings
add_action('admin_init', 'tw_seo_register_settings');
function tw_seo_register_settings() {
    register_setting('tw_seo_group', 'tw_seo_home_title');
    register_setting('tw_seo_group', 'tw_seo_description');
    register_setting('tw_seo_group', 'tw_seo_social_image');
    register_setting('tw_seo_group', 'tw_seo_separator', array('default' => '|'));
    register_setting('tw_seo_group', 'tw_seo_google_console');
    register_setting('tw_seo_group', 'tw_seo_bing_webmaster');
    register_setting('tw_seo_group', 'tw_seo_org_name');
    register_setting('tw_seo_group', 'tw_seo_org_logo');
    register_setting('tw_seo_group', 'tw_seo_org_social');
    register_setting('tw_seo_group', 'tw_seo_schema_type', array('default' => 'Organization'));
    register_setting('tw_seo_group', 'tw_seo_business_phone');
    register_setting('tw_seo_group', 'tw_seo_business_address');
    register_setting('tw_seo_group', 'tw_seo_fb_app_id');
    register_setting('tw_seo_group', 'tw_seo_twitter_user');
    register_setting('tw_seo_group', 'tw_seo_exclude_sitemap', array('type' => 'array', 'default' => array()));
    register_setting('tw_seo_group', 'tw_seo_enable_metabox', array('type' => 'array', 'default' => array()));
    
    // Privacy & Analytics Settings
    register_setting('tw_seo_group', 'tw_cookie_banner_enable');
    register_setting('tw_seo_group', 'tw_privacy_policy_url');
    register_setting('tw_seo_group', 'tw_google_analytics_id');

    // Google Tag / GTM Settings
    register_setting('tw_seo_group', 'tw_gtag_code',      array('sanitize_callback' => 'tw_seo_sanitize_tag_code'));
    register_setting('tw_seo_group', 'tw_gtm_head_code',  array('sanitize_callback' => 'tw_seo_sanitize_tag_code'));
    register_setting('tw_seo_group', 'tw_gtm_body_code',  array('sanitize_callback' => 'tw_seo_sanitize_tag_code'));

    // SEO Feature Toggles (Impostazioni tab)
    register_setting('tw_seo_group', 'tw_seo_enable_schema',   array('default' => '1'));
    register_setting('tw_seo_group', 'tw_seo_enable_og',       array('default' => '1'));
    register_setting('tw_seo_group', 'tw_seo_enable_twitter',  array('default' => '1'));
    register_setting('tw_seo_group', 'tw_seo_enable_gtag_out', array('default' => '1'));
}

/**
 * Sanitize callback for Google Tag / GTM code fields.
 *
 * wp_kses_post() is NOT used here because it strips <script>, <noscript> and
 * <iframe> — all of which appear in standard Google Tag Manager snippets.
 * Since these fields are only accessible to users with 'manage_options' or
 * 'edit_pages' capability (admin level), preserving the raw HTML is safe.
 * We only unslash (remove WordPress magic quotes) and leave the rest intact.
 *
 * @param  string $value Raw value submitted from the form.
 * @return string        Sanitized (unslashed) value.
 */
function tw_seo_sanitize_tag_code($value) {
    if (!current_user_can('edit_pages')) {
        return '';
    }
    return wp_unslash((string) $value);
}

/**
 * SEO Health Checklist — shown on every tab.
 * Returns HTML string with 14 real checks.
 */
function tw_seo_checklist_html() {
    $has_title        = strlen(trim((string) get_option('tw_seo_home_title'))) > 2;
    $has_desc         = strlen(trim((string) get_option('tw_seo_description'))) > 10;
    $org_logo         = tw_seo_get_org_logo();
    $has_logo         = (bool) filter_var($org_logo, FILTER_VALIDATE_URL);
    $has_org_name     = strlen(trim((string) get_option('tw_seo_org_name'))) > 0;
    $has_schema       = $has_org_name && $has_logo;
    $has_og_img       = (bool) filter_var(tw_seo_get_social_image(), FILTER_VALIDATE_URL);
    // Google Search Console: valore valido = SOLO il codice, senza prefisso "google-site-verification="
    $gsc_raw          = trim((string) get_option('tw_seo_google_console'));
    $has_gsc          = strlen($gsc_raw) > 10
                     && strpos($gsc_raw, 'google-site-verification=') === false
                     && strpos($gsc_raw, '<') === false
                     && strpos($gsc_raw, ' ') === false;

    $has_bing         = strlen(trim((string) get_option('tw_seo_bing_webmaster'))) > 5;
    $has_ssl          = strpos(home_url('/'), 'https://') === 0;
    $has_analytics    = strlen(trim((string) get_option('tw_google_analytics_id'))) > 3
                     || strlen(trim((string) get_option('tw_gtag_code'))) > 20
                     || strlen(trim((string) get_option('tw_gtm_head_code'))) > 20;
    $has_privacy      = (bool) filter_var(trim((string) get_option('tw_privacy_policy_url')), FILTER_VALIDATE_URL);
    $has_cookie_raw   = get_option('tw_cookie_banner_enable') === '1';
    $cookie_ok        = !$has_analytics || $has_cookie_raw;
    $has_social_links = strlen(trim((string) get_option('tw_seo_org_social'))) > 5;
    $has_separator    = strlen(trim((string) get_option('tw_seo_separator', '|'))) > 0;

    // Google Tag module enabled/disabled in Impostazioni
    $gtag_module_on   = get_option('tw_seo_enable_gtag_out', '1') === '1';

    $items = array(
        array('label' => __('Titolo Home Page',           'ticinoweb-ai-theme'), 'ok' => $has_title,       'warn' => false, 'tab' => 'general',      'tip' => __('Essenziale: il titolo che vedi su Google', 'ticinoweb-ai-theme')),
        array('label' => __('Meta Description',           'ticinoweb-ai-theme'), 'ok' => $has_desc,        'warn' => false, 'tab' => 'general',      'tip' => __('Testo sotto il link nei risultati di ricerca', 'ticinoweb-ai-theme')),
        array('label' => __('Separatore Titolo',          'ticinoweb-ai-theme'), 'ok' => $has_separator,   'warn' => true,  'tab' => 'general',      'tip' => __('Es: Pagina | NomeSito', 'ticinoweb-ai-theme')),
        array('label' => __('Immagine Social (OG Image)', 'ticinoweb-ai-theme'), 'ok' => $has_og_img,      'warn' => false, 'tab' => 'social',       'tip' => __('Preview su Facebook / LinkedIn / WhatsApp', 'ticinoweb-ai-theme')),
        array('label' => __('Logo Organizzazione',        'ticinoweb-ai-theme'), 'ok' => $has_logo,        'warn' => false, 'tab' => 'schema',       'tip' => __('Logo per Schema.org e Google Knowledge Panel', 'ticinoweb-ai-theme')),
        array('label' => __('Schema.org completo',        'ticinoweb-ai-theme'), 'ok' => $has_schema,      'warn' => false, 'tab' => 'schema',       'tip' => __('Nome + logo: abilita rich result su Google', 'ticinoweb-ai-theme')),
        array('label' => __('Profili Social (sameAs)',    'ticinoweb-ai-theme'), 'ok' => $has_social_links, 'warn' => true, 'tab' => 'schema',       'tip' => __('Collega Facebook, Instagram ecc. a Google', 'ticinoweb-ai-theme')),
        array('label' => __('Google Search Console',      'ticinoweb-ai-theme'), 'ok' => $has_gsc,         'warn' => true,  'tab' => 'verification', 'tip' => __('Verifica proprietà e monitora indicizzazione', 'ticinoweb-ai-theme')),
        array('label' => __('Bing Webmaster Tools',       'ticinoweb-ai-theme'), 'ok' => $has_bing,        'warn' => true,  'tab' => 'verification', 'tip' => __('Visibilità su Bing (8% del mercato ricerche)', 'ticinoweb-ai-theme')),
        array('label' => __('HTTPS / SSL attivo',         'ticinoweb-ai-theme'), 'ok' => $has_ssl,         'warn' => false, 'tab' => null,           'tip' => __('Fattore di ranking ufficiale Google', 'ticinoweb-ai-theme')),
        array('label' => __('Cookie Banner GDPR',         'ticinoweb-ai-theme'), 'ok' => $cookie_ok,       'warn' => false, 'tab' => 'privacy',      'tip' => __('Obbligatorio se usi Analytics o Ads', 'ticinoweb-ai-theme')),
        array('label' => __('Privacy Policy',             'ticinoweb-ai-theme'), 'ok' => $has_privacy,     'warn' => false, 'tab' => 'privacy',      'tip' => __('Link alla privacy policy nel cookie banner', 'ticinoweb-ai-theme')),
        array('label' => __('Sitemap XML',                'ticinoweb-ai-theme'), 'ok' => true,              'warn' => false, 'tab' => 'sitemap',      'tip' => __('Generata automaticamente da WordPress 5.5+', 'ticinoweb-ai-theme')),
    );

    // Analytics / Google Tag: solo se il modulo è attivo
    if ($gtag_module_on) {
        $items[] = array(
            'label' => __('Analytics / Google Tag', 'ticinoweb-ai-theme'),
            'ok'    => $has_analytics,
            'warn'  => true,
            'tab'   => 'gtag',
            'tip'   => __('Misura le visite per migliorare il sito', 'ticinoweb-ai-theme'),
        );
    }

    $ok_count = 0;
    foreach ($items as $item) {
        if ($item['ok']) $ok_count++;
    }
    $total = count($items);
    $pct   = $total > 0 ? round($ok_count / $total * 100) : 0;

    if ($pct >= 86)      { $sc = '#16a34a'; $sb = 'rgba(22,163,74,0.1)';  $sl = '🟢 Ottimo'; }
    elseif ($pct >= 60)  { $sc = '#d97706'; $sb = 'rgba(217,119,6,0.1)';  $sl = '🟡 Buono';  }
    else                 { $sc = '#dc2626'; $sb = 'rgba(220,38,38,0.08)'; $sl = '🔴 Da completare'; }

    ob_start(); ?>
    <div class="tw-seo-checklist-wrap">
        <div class="tw-seo-cl-header">
            <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;">
                <strong style="font-size:14px;color:#1e293b;">📊 <?php _e('Stato SEO', 'ticinoweb-ai-theme'); ?></strong>
                <span style="background:<?php echo $sb;?>;color:<?php echo $sc;?>;padding:3px 10px;border-radius:20px;font-size:12px;font-weight:700;"><?php echo $sl; ?> &nbsp;·&nbsp; <?php echo $ok_count; ?>/<?php echo $total; ?></span>
            </div>
            <div style="margin-top:8px;background:rgba(0,0,0,0.06);border-radius:20px;height:6px;">
                <div style="height:6px;border-radius:20px;background:<?php echo $sc;?>;width:<?php echo $pct;?>%;transition:width 0.5s;"></div>
            </div>
        </div>
        <div class="tw-seo-cl-grid">
        <?php foreach ($items as $item):
            $icon  = $item['ok'] ? '✅' : ($item['warn'] ? '⚠️' : '❌');
            $color = $item['ok'] ? '#374151' : ($item['warn'] ? '#b45309' : '#b91c1c');
            $bg    = $item['ok'] ? 'rgba(22,163,74,0.04)' : ($item['warn'] ? 'rgba(217,119,6,0.06)' : 'rgba(220,38,38,0.06)');
        ?>
            <div class="tw-seo-cl-item" style="background:<?php echo $bg;?>;" title="<?php echo esc_attr($item['tip']); ?>">
                <span style="font-size:14px;line-height:1;flex-shrink:0;"><?php echo $icon; ?></span>
                <span style="font-size:12px;font-weight:600;color:<?php echo $color;?>;flex:1;min-width:0;"><?php echo esc_html($item['label']); ?></span>
                <?php if (!$item['ok'] && $item['tab']) : ?>
                    <button type="button" class="tw-cl-goto" data-tab="<?php echo esc_attr($item['tab']); ?>" title="<?php echo esc_attr($item['tip']); ?>">
                        <?php _e('→', 'ticinoweb-ai-theme'); ?>
                    </button>
                <?php endif; ?>
            </div>
        <?php endforeach; ?>
        </div>
    </div>
    <?php
    return ob_get_clean();
}

/**
 * Render the SEO settings page with Liquid Glass design
 */
function tw_seo_render_page() {
    ?>
    <style>
        .tw-seo-wrap {
            margin: 20px 20px 0 0;
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            position: relative;
            min-height: 80vh;
        }
        
        /* Glass Morphism Background Blobs */
        .tw-seo-bg {
            position: fixed;
            top: 0; left: 0; right: 0; bottom: 0;
            z-index: -1;
            overflow: hidden;
            background: #f0f4f8;
            border-radius: 12px;
        }
        
        .tw-seo-blob {
            position: absolute;
            width: 300px; height: 300px;
            background: rgba(99, 102, 241, 0.15);
            filter: blur(80px);
            border-radius: 50%;
            animation: move 20s infinite alternate;
        }
        
        .tw-seo-blob-2 {
            background: rgba(139, 92, 246, 0.15);
            right: 10%; bottom: 10%;
            animation-duration: 25s;
        }
        
        @keyframes move {
            from { transform: translate(0,0); }
            to { transform: translate(100px, 100px); }
        }

        .tw-seo-card {
            background: rgba(255, 255, 255, 0.6);
            backdrop-filter: blur(15px);
            -webkit-backdrop-filter: blur(15px);
            border: 1px solid rgba(255, 255, 255, 0.5);
            border-radius: 16px;
            padding: 30px;
            box-shadow: 0 8px 32px rgba(31, 38, 135, 0.07);
        }

        .tw-seo-header {
            display: flex;
            align-items: center;
            gap: 15px;
            margin-bottom: 30px;
        }
        
        .tw-seo-header h1 {
            margin: 0;
            font-weight: 700;
            color: #1e293b;
            font-size: 24px;
        }

        .tw-seo-tabs-nav {
            display: flex;
            gap: 10px;
            margin-bottom: 25px;
            border-bottom: 1px solid rgba(0,0,0,0.05);
            padding-bottom: 15px;
        }
        
        .tw-seo-tab-btn {
            background: rgba(255,255,255,0.4);
            border: 1px solid rgba(255,255,255,0.6);
            padding: 10px 20px;
            border-radius: 10px;
            cursor: pointer;
            font-weight: 500;
            color: #64748b;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .tw-seo-tab-btn.active {
            background: #fff;
            color: #4f46e5;
            box-shadow: 0 4px 12px rgba(79, 70, 229, 0.1);
            border-color: #4f46e5;
        }

        .tw-seo-tab-content {
            display: none;
            animation: fadeIn 0.4s ease;
        }
        
        .tw-seo-tab-content.active {
            display: block;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .tw-seo-field-group {
            margin-bottom: 25px;
        }
        
        .tw-seo-label {
            display: block;
            font-weight: 600;
            color: #334155;
            margin-bottom: 8px;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .tw-seo-help {
            background: rgba(79, 70, 229, 0.05);
            border-left: 3px solid #4f46e5;
            padding: 12px 15px;
            border-radius: 0 8px 8px 0;
            font-size: 13px;
            color: #475569;
            margin-bottom: 12px;
            line-height: 1.5;
        }
        
        .tw-seo-help strong {
            color: #4f46e5;
            display: block;
            margin-bottom: 4px;
        }
        /* Inline bold inside help text uses <b> to avoid display:block */
        .tw-seo-help b {
            color: #4f46e5;
            font-weight: 700;
        }

        .tw-seo-input {
            width: 100%;
            padding: 12px 16px;
            border-radius: 10px;
            border: 1px solid rgba(0,0,0,0.1);
            background: rgba(255,255,255,0.7);
            font-size: 14px;
            transition: all 0.3s;
        }
        
        .tw-seo-input:focus {
            border-color: #4f46e5;
            box-shadow: 0 0 0 4px rgba(79, 70, 229, 0.1);
            outline: none;
            background: #fff;
        }

        /* Image Preview */
        .tw-img-preview-wrap {
            margin-top: 10px;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        .tw-img-preview {
            max-height: 80px;
            max-width: 200px;
            border-radius: 8px;
            border: 1px solid rgba(0,0,0,0.1);
            object-fit: contain;
            background: #f8f9ff;
            padding: 4px;
        }
        .tw-img-remove-btn {
            background: none;
            border: 1px solid rgba(220,38,38,0.3);
            color: #b91c1c;
            border-radius: 6px;
            padding: 4px 10px;
            font-size: 12px;
            cursor: pointer;
            transition: all 0.2s;
        }
        .tw-img-remove-btn:hover {
            background: rgba(220,38,38,0.08);
        }

        .tw-seo-submit {
            background: #4f46e5;
            color: #fff;
            padding: 12px 30px;
            border-radius: 10px;
            border: none;
            font-weight: 600;
            cursor: pointer;
            box-shadow: 0 10px 15px -3px rgba(79, 70, 229, 0.3);
            transition: all 0.3s;
        }
        
        .tw-seo-submit:hover {
            background: #4338ca;
            transform: translateY(-2px);
            box-shadow: 0 20px 25px -5px rgba(79, 70, 229, 0.4);
        }

        .tw-seo-icon-wire {
            width: 20px; height: 20px;
            stroke: currentColor;
            stroke-width: 1.5;
            fill: none;
        }
        /* Checklist */
        .tw-seo-checklist-wrap {
            background: rgba(255,255,255,0.5);
            border: 1px solid rgba(0,0,0,0.06);
            border-radius: 14px;
            padding: 16px 20px;
            margin-bottom: 20px;
        }
        .tw-seo-cl-header { margin-bottom: 12px; }
        .tw-seo-cl-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            gap: 7px;
        }
        .tw-seo-cl-item {
            display: flex;
            align-items: center;
            gap: 7px;
            padding: 7px 10px;
            border-radius: 8px;
            overflow: hidden;
        }
        .tw-cl-goto {
            background: rgba(79,70,229,0.1);
            border: none;
            color: #4f46e5;
            border-radius: 6px;
            padding: 2px 7px;
            font-size: 13px;
            cursor: pointer;
            flex-shrink: 0;
            transition: background 0.2s;
        }
        .tw-cl-goto:hover { background: rgba(79,70,229,0.2); }
        /* Toggle switch */
        .tw-toggle-row {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 14px 0;
            border-bottom: 1px solid rgba(0,0,0,0.04);
        }
        .tw-toggle-label { font-weight: 600; color: #334155; font-size: 14px; }
        .tw-toggle-desc  { font-size: 12px; color: #64748b; margin-top: 2px; }
        .tw-toggle {
            position: relative;
            display: inline-block;
            width: 44px; height: 24px;
            flex-shrink: 0;
        }
        .tw-toggle input { opacity: 0; width: 0; height: 0; }
        .tw-toggle-slider {
            position: absolute;
            inset: 0;
            background: #cbd5e1;
            border-radius: 24px;
            transition: 0.3s;
            cursor: pointer;
        }
        .tw-toggle-slider:before {
            content: '';
            position: absolute;
            width: 18px; height: 18px;
            left: 3px; bottom: 3px;
            background: white;
            border-radius: 50%;
            transition: 0.3s;
        }
        .tw-toggle input:checked + .tw-toggle-slider { background: #4f46e5; }
        .tw-toggle input:checked + .tw-toggle-slider:before { transform: translateX(20px); }
        /* Import buttons */
        .tw-import-btn {
            background: rgba(79,70,229,0.1);
            border: 1px solid rgba(79,70,229,0.3);
            color: #4f46e5;
            border-radius: 8px;
            padding: 8px 14px;
            font-size: 13px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s;
            white-space: nowrap;
        }
        .tw-import-btn:hover { background: rgba(79,70,229,0.18); transform: translateY(-1px); }
        .tw-import-pill {
            background: rgba(79,70,229,0.08);
            border: 1px solid rgba(79,70,229,0.2);
            color: #4f46e5;
            border-radius: 6px;
            padding: 5px 10px;
            font-size: 12px;
            font-weight: 600;
            cursor: pointer;
            white-space: nowrap;
            flex-shrink: 0;
            transition: background 0.2s;
        }
        .tw-import-pill:hover { background: rgba(79,70,229,0.18); }
    </style>

    <div class="tw-seo-wrap">
        <div class="tw-seo-bg">
            <div class="tw-seo-blob"></div>
            <div class="tw-seo-blob tw-seo-blob-2"></div>
        </div>

        <div class="tw-seo-card">
            <div class="tw-seo-header">
                <svg class="tw-seo-icon-wire" viewBox="0 0 24 24"><path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"/></svg>
                <h1><?php _e('tW SEO - Ottimizzazione Motori di Ricerca', 'ticinoweb-ai-theme'); ?></h1>
            </div>

            <form method="post" action="options.php">
                <?php settings_fields('tw_seo_group'); ?>

                <?php echo tw_seo_checklist_html(); ?>

                <div class="tw-seo-tabs-nav">
                    <button type="button" class="tw-seo-tab-btn active" data-tab="general">
                        <svg class="tw-seo-icon-wire" viewBox="0 0 24 24"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>
                        <?php _e('Generali', 'ticinoweb-ai-theme'); ?>
                    </button>
                    <button type="button" class="tw-seo-tab-btn" data-tab="schema">
                        <svg class="tw-seo-icon-wire" viewBox="0 0 24 24"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"/><line x1="3" y1="9" x2="21" y2="9"/><line x1="9" y1="21" x2="9" y2="9"/></svg>
                        <?php _e('Schema.org', 'ticinoweb-ai-theme'); ?>
                    </button>
                    <button type="button" class="tw-seo-tab-btn" data-tab="social">
                        <svg class="tw-seo-icon-wire" viewBox="0 0 24 24"><path d="M4 12v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8"/><polyline points="16 6 12 2 8 6"/><line x1="12" y1="2" x2="12" y2="15"/></svg>
                        <?php _e('Social', 'ticinoweb-ai-theme'); ?>
                    </button>
                    <button type="button" class="tw-seo-tab-btn" data-tab="verification">
                        <svg class="tw-seo-icon-wire" viewBox="0 0 24 24"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
                        <?php _e('Verifica', 'ticinoweb-ai-theme'); ?>
                    </button>
                    <button type="button" class="tw-seo-tab-btn" data-tab="privacy">
                        <svg class="tw-seo-icon-wire" viewBox="0 0 24 24"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
                        <?php _e('Privacy & Statistiche', 'ticinoweb-ai-theme'); ?>
                    </button>
                    <button type="button" class="tw-seo-tab-btn" data-tab="gtag">
                        <svg class="tw-seo-icon-wire" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg>
                        <?php _e('Google Tag', 'ticinoweb-ai-theme'); ?>
                    </button>
                    <button type="button" class="tw-seo-tab-btn" data-tab="sitemap">
                        <svg class="tw-seo-icon-wire" viewBox="0 0 24 24"><line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><line x1="3" y1="6" x2="3.01" y2="6"/><line x1="3" y1="12" x2="3.01" y2="12"/><line x1="3" y1="18" x2="3.01" y2="18"/></svg>
                        <?php _e('Sitemap', 'ticinoweb-ai-theme'); ?>
                    </button>
                    <button type="button" class="tw-seo-tab-btn" data-tab="settings">
                        <svg class="tw-seo-icon-wire" viewBox="0 0 24 24"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>
                        <?php _e('Impostazioni', 'ticinoweb-ai-theme'); ?>
                    </button>
                </div>

                <!-- Tab Generali -->
                <div class="tw-seo-tab-content active" id="general">
                    <!-- Importa da WordPress -->
                    <?php
                    $wp_name = get_bloginfo('name');
                    $wp_desc = get_bloginfo('description');
                    $wp_url  = home_url('/');
                    ?>
                    <div style="background:rgba(79,70,229,0.05);border:1px solid rgba(79,70,229,0.15);border-radius:12px;padding:14px 18px;margin-bottom:18px;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:10px;">
                        <div>
                            <strong style="color:#4f46e5;font-size:13px;">🔄 <?php _e('Importa da WordPress', 'ticinoweb-ai-theme'); ?></strong>
                            <div style="font-size:12px;color:#64748b;margin-top:2px;"><?php echo esc_html($wp_name); ?> &nbsp;·&nbsp; <?php echo esc_html($wp_desc ?: __('(nessuna tagline)', 'ticinoweb-ai-theme')); ?></div>
                        </div>
                        <button type="button" class="tw-import-btn" data-action="import_generali"
                            data-home-title="<?php echo esc_attr($wp_name . ($wp_desc ? ' — ' . $wp_desc : '')); ?>"
                            data-description="<?php echo esc_attr($wp_desc); ?>">
                            ✨ <?php _e('Suggerisci campi da WP', 'ticinoweb-ai-theme'); ?>
                        </button>
                    </div>

                    <div class="tw-seo-field-group">
                        <label class="tw-seo-label"><?php _e('Titolo Home Page (Meta Title)', 'ticinoweb-ai-theme'); ?></label>
                        <div class="tw-seo-help">
                            <strong>🤔 <?php _e('Cos\'è questo?', 'ticinoweb-ai-theme'); ?></strong>
                            <?php _e('È il titolo principale che appare su Google per la tua Home Page. Se lo lasci vuoto, Google userà il nome del sito e il motto impostati in Impostazioni > Generali.', 'ticinoweb-ai-theme'); ?>
                        </div>
                        <input type="text" name="tw_seo_home_title" value="<?php echo esc_attr(get_option('tw_seo_home_title')); ?>" class="tw-seo-input" placeholder="<?php _e('Es: Nome Azienda - I Migliori Servizi di...', 'ticinoweb-ai-theme'); ?>">
                    </div>
                
                    <div class="tw-seo-field-group">
                        <label class="tw-seo-label"><?php _e('Descrizione Principale (Meta Description)', 'ticinoweb-ai-theme'); ?></label>
                        <div class="tw-seo-help">
                            <strong>🤔 <?php _e('Cos\'è questo?', 'ticinoweb-ai-theme'); ?></strong>
                            <?php _e('È il testo che appare sotto il nome del tuo sito nei risultati di ricerca. Spiega brevemente di cosa tratta il tuo sito per attirare persone.', 'ticinoweb-ai-theme'); ?>
                        </div>
                        <textarea name="tw_seo_description" rows="3" class="tw-seo-input" placeholder="<?php _e('Es: Un sito professionale che offre servizi di...', 'ticinoweb-ai-theme'); ?>"><?php echo esc_textarea(get_option('tw_seo_description')); ?></textarea>
                    </div>

                    <div class="tw-seo-field-group">
                        <label class="tw-seo-label"><?php _e('Separatore Titolo', 'ticinoweb-ai-theme'); ?></label>
                        <div class="tw-seo-help">
                            <strong>🤔 <?php _e('Cos\'è questo?', 'ticinoweb-ai-theme'); ?></strong>
                            <?php _e('Il simbolo che divide il titolo della pagina dal nome del sito. Esempio: Pagina Contatti | MioSito', 'ticinoweb-ai-theme'); ?>
                        </div>
                        <input type="text" name="tw_seo_separator" value="<?php echo esc_attr(get_option('tw_seo_separator', '|')); ?>" class="tw-seo-input" style="width: 100px;">
                    </div>
                </div>

                <!-- Tab Schema -->
                <div class="tw-seo-tab-content" id="schema">
                    <div class="tw-seo-field-group">
                        <label class="tw-seo-label"><?php _e('Tipo di Schema (SEO Avanzato)', 'ticinoweb-ai-theme'); ?></label>
                        <div class="tw-seo-help">
                            <strong>🤔 <?php _e('Cos\'è questo?', 'ticinoweb-ai-theme'); ?></strong>
                            <?php _e('Organizzazione è per siti web standard. LocalBusiness (Attività Locale) è consigliato se il sito rappresenta un\'azienda fisica che riceve clienti (aiuta enormemente nella SEO Locale su Google Maps).', 'ticinoweb-ai-theme'); ?>
                        </div>
                        <select name="tw_seo_schema_type" class="tw-seo-input">
                            <option value="Organization" <?php selected(get_option('tw_seo_schema_type', 'Organization'), 'Organization'); ?>><?php _e('Organizzazione Standard', 'ticinoweb-ai-theme'); ?></option>
                            <option value="LocalBusiness" <?php selected(get_option('tw_seo_schema_type'), 'LocalBusiness'); ?>><?php _e('Attività Locale (Local Business)', 'ticinoweb-ai-theme'); ?></option>
                        </select>
                    </div>

                    <div class="tw-seo-field-group">
                        <label class="tw-seo-label"><?php _e('Nome Organizzazione / Business', 'ticinoweb-ai-theme'); ?></label>
                        <div class="tw-seo-help">
                            <strong>🤔 <?php _e('Cos\'è questo?', 'ticinoweb-ai-theme'); ?></strong>
                            <?php _e('Il nome ufficiale della tua azienda. Aiuta Google a capire chi sei e a mostrare il box informativo sulla destra.', 'ticinoweb-ai-theme'); ?>
                        </div>
                        <div style="display:flex;gap:8px;align-items:center;">
                            <input type="text" name="tw_seo_org_name" id="tw_seo_org_name_field" value="<?php echo esc_attr(get_option('tw_seo_org_name')); ?>" class="tw-seo-input">
                            <button type="button" class="tw-import-pill" data-fill-target="tw_seo_org_name_field" data-fill-value="<?php echo esc_attr(get_bloginfo('name')); ?>">
                                🔄 <?php _e('Da WP', 'ticinoweb-ai-theme'); ?>
                            </button>
                        </div>
                    </div>
                    
                    <div class="tw-seo-field-group">
                        <label class="tw-seo-label"><?php _e('Logo Organizzazione (URL)', 'ticinoweb-ai-theme'); ?></label>
                        <div style="display: flex; gap: 10px; align-items: center;">
                            <input type="text" name="tw_seo_org_logo" id="tw_seo_org_logo" value="<?php echo esc_attr(get_option('tw_seo_org_logo')); ?>" class="tw-seo-input" placeholder="<?php esc_attr_e('Vuoto: usa il logo del sito', 'ticinoweb-ai-theme'); ?>">
                            <button type="button" class="button button-secondary tw-seo-upload-btn" data-target="tw_seo_org_logo" data-preview="tw_seo_org_logo_preview"><?php _e('Scegli Immagine', 'ticinoweb-ai-theme'); ?></button>
                        </div>
                        <div class="tw-img-preview-wrap" id="tw_seo_org_logo_preview_wrap" style="<?php echo get_option('tw_seo_org_logo') ? '' : 'display:none;'; ?>">
                            <img id="tw_seo_org_logo_preview" src="<?php echo esc_url(get_option('tw_seo_org_logo')); ?>" alt="Logo preview" class="tw-img-preview">
                            <button type="button" class="tw-img-remove-btn" data-target="tw_seo_org_logo">&times; <?php _e('Rimuovi', 'ticinoweb-ai-theme'); ?></button>
                        </div>
                    </div>

                    <div class="tw-seo-field-group">
                        <label class="tw-seo-label"><?php _e('Profili Social (uno per riga)', 'ticinoweb-ai-theme'); ?></label>
                        <div class="tw-seo-help">
                            <strong>🤔 <?php _e('Cos\'è questo?', 'ticinoweb-ai-theme'); ?></strong>
                            <?php _e('Inserisci i link alle tue pagine Facebook, Instagram, LinkedIn, ecc. Collega ufficialmente la tua presenza social al tuo sito.', 'ticinoweb-ai-theme'); ?>
                        </div>
                        <textarea name="tw_seo_org_social" rows="4" class="tw-seo-input" placeholder="https://facebook.com/miobusiness..."><?php echo esc_textarea(get_option('tw_seo_org_social')); ?></textarea>
                    </div>

                    <div class="tw-seo-field-group" style="padding-top: 20px; border-top: 1px solid rgba(0,0,0,0.05); margin-top: 20px;">
                        <label class="tw-seo-label"><?php _e('Telefono Pubblico (Per Schema)', 'ticinoweb-ai-theme'); ?></label>
                        <div class="tw-seo-help">
                            <?php _e('Opzionale, ma essenziale se hai scelto "Attività Locale" per mostrare il bottone "Chiama" vicino al tuo sito su Google.', 'ticinoweb-ai-theme'); ?>
                        </div>
                        <?php
                        // Priorità: CMS ticinoweb > WooCommerce
                        $cms_phone   = trim((string) get_option('ticinoweb_contact_phone', ''));
                        $cms_phone_l = trim((string) get_option('ticinoweb_contact_phone_landline', ''));
                        $cms_phone_m = trim((string) get_option('ticinoweb_contact_phone_mobile', ''));
                        $wc_phone    = '';
                        if (!$cms_phone && !$cms_phone_l && !$cms_phone_m && (function_exists('WC') || class_exists('WooCommerce'))) {
                            $wc_phone = trim((string) get_option('woocommerce_store_phone', ''));
                        }
                        ?>
                        <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;">
                            <input type="tel" name="tw_seo_business_phone" id="tw_seo_business_phone_field" value="<?php echo esc_attr(get_option('tw_seo_business_phone')); ?>" class="tw-seo-input" placeholder="+41 91 ...">
                            <?php if ($cms_phone) : ?>
                                <button type="button" class="tw-import-pill" data-fill-target="tw_seo_business_phone_field" data-fill-value="<?php echo esc_attr($cms_phone); ?>">
                                    🔄 <?php _e('Da CMS', 'ticinoweb-ai-theme'); ?>
                                </button>
                            <?php endif; ?>
                            <?php if ($cms_phone_l) : ?>
                                <button type="button" class="tw-import-pill" data-fill-target="tw_seo_business_phone_field" data-fill-value="<?php echo esc_attr($cms_phone_l); ?>">
                                    📞 <?php _e('Fisso', 'ticinoweb-ai-theme'); ?>
                                </button>
                            <?php endif; ?>
                            <?php if ($cms_phone_m) : ?>
                                <button type="button" class="tw-import-pill" data-fill-target="tw_seo_business_phone_field" data-fill-value="<?php echo esc_attr($cms_phone_m); ?>">
                                    📱 <?php _e('Mobile', 'ticinoweb-ai-theme'); ?>
                                </button>
                            <?php endif; ?>
                            <?php if ($wc_phone) : ?>
                                <button type="button" class="tw-import-pill" data-fill-target="tw_seo_business_phone_field" data-fill-value="<?php echo esc_attr($wc_phone); ?>">
                                    🔄 <?php _e('Da WooCommerce', 'ticinoweb-ai-theme'); ?>
                                </button>
                            <?php endif; ?>
                        </div>
                        <?php if ($cms_phone || $cms_phone_l || $cms_phone_m || $wc_phone) : ?>
                            <div style="font-size:12px;color:#64748b;margin-top:5px;">
                                <?php
                                $hints = array_filter(array(
                                    $cms_phone   ? '📞 CMS: <code>' . esc_html($cms_phone)   . '</code>' : '',
                                    $cms_phone_l ? '📞 Fisso: <code>' . esc_html($cms_phone_l) . '</code>' : '',
                                    $cms_phone_m ? '📱 Mobile: <code>' . esc_html($cms_phone_m) . '</code>' : '',
                                    $wc_phone    ? '📞 WooCommerce: <code>' . esc_html($wc_phone) . '</code>' : '',
                                ));
                                echo implode(' &nbsp;&middot;&nbsp; ', $hints);
                                ?>
                            </div>
                        <?php else : ?>
                            <div style="font-size:12px;color:#94a3b8;margin-top:5px;">
                                <?php _e('Nessun telefono trovato. Aggiungilo in ', 'ticinoweb-ai-theme'); ?>
                                <a href="<?php echo esc_url(admin_url('admin.php?page=ticinoweb-cms#contatti')); ?>" style="color:#4f46e5;"><?php _e('CMS › Contatti', 'ticinoweb-ai-theme'); ?></a>
                            </div>
                        <?php endif; ?>
                    </div>

                    <div class="tw-seo-field-group">
                        <label class="tw-seo-label"><?php _e('Indirizzo Completo (Per Schema)', 'ticinoweb-ai-theme'); ?></label>
                        <div class="tw-seo-help">
                            <?php _e('Opzionale, utilissimo per "Attività Locale". Formato consigliato: Via Esempio 1, 6600 Locarno, Switzerland.', 'ticinoweb-ai-theme'); ?>
                        </div>
                        <?php
                        // Priorità: CMS ticinoweb > WooCommerce
                        $cms_address = trim((string) get_option('ticinoweb_contact_address', ''));
                        $wc_address  = '';
                        if (!$cms_address && (function_exists('WC') || class_exists('WooCommerce'))) {
                            $parts = array_filter(array(
                                get_option('woocommerce_store_address', ''),
                                get_option('woocommerce_store_address_2', ''),
                                get_option('woocommerce_store_city', ''),
                                get_option('woocommerce_store_postcode', ''),
                            ));
                            $country_code = get_option('woocommerce_default_country', '');
                            if (strpos($country_code, ':') !== false) {
                                list($country_code) = explode(':', $country_code);
                            }
                            if ($country_code && function_exists('WC') && WC()->countries) {
                                $countries    = WC()->countries->get_countries();
                                $country_name = isset($countries[$country_code]) ? $countries[$country_code] : $country_code;
                                $parts[]      = $country_name;
                            }
                            $wc_address = trim(implode(', ', array_filter(array_map('trim', $parts))));
                        }
                        ?>
                        <div style="display:flex;gap:8px;align-items:flex-start;">
                            <textarea name="tw_seo_business_address" id="tw_seo_business_address_field" rows="2" class="tw-seo-input" placeholder="Via Esempio 1, 6600 Locarno, Switzerland"><?php echo esc_textarea(get_option('tw_seo_business_address')); ?></textarea>
                            <?php if ($cms_address) : ?>
                                <button type="button" class="tw-import-pill" style="margin-top:4px;" data-fill-target="tw_seo_business_address_field" data-fill-value="<?php echo esc_attr($cms_address); ?>">
                                    🔄 <?php _e('Da CMS', 'ticinoweb-ai-theme'); ?>
                                </button>
                            <?php elseif ($wc_address) : ?>
                                <button type="button" class="tw-import-pill" style="margin-top:4px;" data-fill-target="tw_seo_business_address_field" data-fill-value="<?php echo esc_attr($wc_address); ?>">
                                    🔄 <?php _e('Da WooCommerce', 'ticinoweb-ai-theme'); ?>
                                </button>
                            <?php endif; ?>
                        </div>
                        <?php if ($cms_address) : ?>
                            <div style="font-size:12px;color:#64748b;margin-top:5px;">📍 CMS: <code><?php echo esc_html($cms_address); ?></code></div>
                        <?php elseif ($wc_address) : ?>
                            <div style="font-size:12px;color:#64748b;margin-top:5px;">📍 WooCommerce: <code><?php echo esc_html($wc_address); ?></code></div>
                        <?php else : ?>
                            <div style="font-size:12px;color:#94a3b8;margin-top:5px;">
                                <?php _e('Nessun indirizzo trovato. Aggiungilo in ', 'ticinoweb-ai-theme'); ?>
                                <a href="<?php echo esc_url(admin_url('admin.php?page=ticinoweb-cms#contatti')); ?>" style="color:#4f46e5;"><?php _e('CMS › Contatti', 'ticinoweb-ai-theme'); ?></a>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Tab Social -->
                <div class="tw-seo-tab-content" id="social">
                    <div class="tw-seo-field-group">
                        <label class="tw-seo-label"><?php _e('Immagine Social di Default', 'ticinoweb-ai-theme'); ?></label>
                        <div class="tw-seo-help">
                            <strong>🤔 <?php _e('Cos\'è questo?', 'ticinoweb-ai-theme'); ?></strong>
                            <?php _e('L\'immagine che appare quando qualcuno condivide il tuo sito su Facebook o LinkedIn, se non ci sono altre foto nella pagina.', 'ticinoweb-ai-theme'); ?>
                        </div>
                        <div style="display: flex; gap: 10px; align-items: center;">
                            <input type="text" name="tw_seo_social_image" id="tw_seo_social_image" value="<?php echo esc_attr(get_option('tw_seo_social_image')); ?>" class="tw-seo-input" placeholder="<?php esc_attr_e('Vuoto: usa il logo del sito', 'ticinoweb-ai-theme'); ?>">
                            <button type="button" class="button button-secondary tw-seo-upload-btn" data-target="tw_seo_social_image" data-preview="tw_seo_social_image_preview"><?php _e('Scegli Immagine', 'ticinoweb-ai-theme'); ?></button>
                        </div>
                        <div class="tw-img-preview-wrap" id="tw_seo_social_image_preview_wrap" style="<?php echo get_option('tw_seo_social_image') ? '' : 'display:none;'; ?>">
                            <img id="tw_seo_social_image_preview" src="<?php echo esc_url(get_option('tw_seo_social_image')); ?>" alt="Social image preview" class="tw-img-preview">
                            <button type="button" class="tw-img-remove-btn" data-target="tw_seo_social_image">&times; <?php _e('Rimuovi', 'ticinoweb-ai-theme'); ?></button>
                        </div>
                    </div>

                    <div class="tw-seo-field-group">
                        <label class="tw-seo-label"><?php _e('Twitter Username', 'ticinoweb-ai-theme'); ?></label>
                        <input type="text" name="tw_seo_twitter_user" value="<?php echo esc_attr(get_option('tw_seo_twitter_user')); ?>" class="tw-seo-input" placeholder="@miobusiness">
                    </div>
                </div>

                <!-- Tab Verification -->
                <div class="tw-seo-tab-content" id="verification">
                    <div class="tw-seo-field-group">
                        <label class="tw-seo-label"><?php _e('Google Search Console (codice verifica meta tag)', 'ticinoweb-ai-theme'); ?></label>
                        <div class="tw-seo-help">
                            <strong>🤔 <?php _e('Cos\'è questo?', 'ticinoweb-ai-theme'); ?></strong>
                            <?php _e('Verifica la proprietà del sito tramite il metodo <strong>Tag HTML</strong> di Google Search Console.', 'ticinoweb-ai-theme'); ?>
                            <br><br>
                            <strong style="color:#0f766e;">✅ <?php _e('Come fare:', 'ticinoweb-ai-theme'); ?></strong><br>
                            <?php _e('1. Vai su Google Search Console → Aggiungi proprietà → <strong>Prefisso URL</strong> (es. https://picantillo.ch)<br>2. Scegli metodo verifica → <strong>Tag HTML</strong><br>3. Copia <u>solo il codice</u> dall\'attributo <code>content</code> del meta tag<br>&nbsp;&nbsp;&nbsp;<code style="font-size:11px;background:#f1f5f9;padding:2px 5px;border-radius:3px;">&lt;meta name="google-site-verification" content="<strong>COPIA SOLO QUESTO</strong>" /&gt;</code>', 'ticinoweb-ai-theme'); ?>
                            <br><br>
                            <strong style="color:#dc2626;">❌ <?php _e('Attenzione — NON incollare:', 'ticinoweb-ai-theme'); ?></strong><br>
                            <?php _e('• Il record DNS TXT (<code>google-site-verification=...</code>) → va nel pannello DNS di Infomaniak, non qui<br>• Il tag HTML completo (<code>&lt;meta ...&gt;</code>)', 'ticinoweb-ai-theme'); ?>
                            <br><br>
                            <a href="https://search.google.com/search-console/welcome" target="_blank" style="color: #4f46e5; text-decoration: underline; font-weight: 600;">
                                🚀 <?php _e('Apri Google Search Console', 'ticinoweb-ai-theme'); ?>
                            </a>
                        </div>
                        <?php
                        $gsc_current = get_option('tw_seo_google_console', '');
                        $gsc_bad_format = !empty($gsc_current) && (
                            strpos($gsc_current, 'google-site-verification=') !== false
                            || strpos($gsc_current, '<') !== false
                            || strpos($gsc_current, ' ') !== false
                        );
                        ?>
                        <?php if ($gsc_bad_format) : ?>
                            <div style="background:#fef2f2;border:1px solid #fca5a5;border-radius:6px;padding:10px 14px;margin-bottom:8px;font-size:12px;color:#991b1b;">
                                ⚠️ <strong><?php _e('Formato non corretto', 'ticinoweb-ai-theme'); ?></strong><br>
                                <?php _e('Il valore attuale sembra un record DNS TXT o contiene caratteri non validi. Incolla solo il codice alfanumerico senza il prefisso <code>google-site-verification=</code>.', 'ticinoweb-ai-theme'); ?>
                            </div>
                        <?php endif; ?>
                        <input type="text" name="tw_seo_google_console" value="<?php echo esc_attr($gsc_current); ?>" class="tw-seo-input" placeholder="abc123XYZ..." style="<?php echo $gsc_bad_format ? 'border-color:#ef4444;' : ''; ?>">
                    </div>

                    <div class="tw-seo-field-group" style="padding-top:20px;border-top:1px solid rgba(0,0,0,0.05);margin-top:10px;">
                        <label class="tw-seo-label"><?php _e('Bing Webmaster Tools (codice verifica)', 'ticinoweb-ai-theme'); ?></label>
                        <div class="tw-seo-help">
                            <strong>🤔 <?php _e('Cos\'è questo?', 'ticinoweb-ai-theme'); ?></strong>
                            <?php _e('Inserisci il codice meta fornito da Bing per verificare la proprietà del sito su Bing Webmaster Tools. Bing rappresenta circa l\'8% delle ricerche — vale la pena configurarlo.', 'ticinoweb-ai-theme'); ?>
                            <br><br>
                            <a href="https://www.bing.com/webmasters/" target="_blank" style="color:#4f46e5;text-decoration:underline;font-weight:600;">
                                🚀 <?php _e('Apri Bing Webmaster Tools', 'ticinoweb-ai-theme'); ?>
                            </a>
                        </div>
                        <input type="text" name="tw_seo_bing_webmaster" value="<?php echo esc_attr(get_option('tw_seo_bing_webmaster')); ?>" class="tw-seo-input" placeholder="<?php _e('Incolla qui il contenuto del meta tag content="..."', 'ticinoweb-ai-theme'); ?>">
                    </div>
                </div>

                <!-- Tab Privacy & Statistiche (GDPR & Google Analytics) -->
                <div class="tw-seo-tab-content" id="privacy">
                    <div class="tw-seo-field-group">
                        <label class="tw-seo-label"><?php _e('Attiva Banner Cookie', 'ticinoweb-ai-theme'); ?></label>
                        <div class="tw-seo-help">
                            <strong>🤔 <?php _e('Perché usarlo?', 'ticinoweb-ai-theme'); ?></strong>
                            <?php _e('La legge (GDPR / LPD) richiede di informare gli utenti sui cookie e bloccare le statistiche finché non cliccano "Accetta". Seleziona per mostrare automaticamente il banner sul sito.', 'ticinoweb-ai-theme'); ?>
                        </div>
                        <label>
                            <input type="checkbox" name="tw_cookie_banner_enable" value="1" <?php checked(get_option('tw_cookie_banner_enable'), '1'); ?>>
                            <strong><?php _e('Mostra il Banner Cookie in basso allo schermo', 'ticinoweb-ai-theme'); ?></strong>
                        </label>
                    </div>

                    <div class="tw-seo-field-group">
                        <label class="tw-seo-label"><?php _e('Link alla tua Privacy Policy', 'ticinoweb-ai-theme'); ?></label>
                        <div class="tw-seo-help">
                            <strong>🤔 <?php _e('A cosa serve?', 'ticinoweb-ai-theme'); ?></strong>
                            <?php _e('Nel banner cookie ci deve essere un collegamento per far leggere all\'utente come tratti i suoi dati limitando così le responsabilità legali. Incolla il link della tua pagina privacy.', 'ticinoweb-ai-theme'); ?>
                        </div>
                        <input type="url" name="tw_privacy_policy_url" value="<?php echo esc_url(get_option('tw_privacy_policy_url')); ?>" class="tw-seo-input" placeholder="https://tuosito.ch/privacy-policy/">
                    </div>

                    <div class="tw-seo-field-group" style="padding-top: 20px; border-top: 1px solid rgba(0,0,0,0.05); margin-top: 20px;">
                        <label class="tw-seo-label" style="display:flex; align-items:center; gap:8px;">
                            <img src="<?php echo esc_url(admin_url('images/spinner.gif')); ?>" style="visibility:hidden;width:0;height:0;"> 
                            <?php _e('Google Analytics (Monitoraggio Visite)', 'ticinoweb-ai-theme'); ?>
                        </label>
                        <div class="tw-seo-help">
                            <strong>🤔 <?php _e('Cos\'è e come inserirlo in regola?', 'ticinoweb-ai-theme'); ?></strong>
                            <?php _e('Google Analytics (GA4) traccia chi visita il tuo sito. Inserisci il codice "Misurazione" (es. G-XXXXXXXXXX) e il sistema farà il resto, bloccandolo in automatico finché l\'utente non accetta i Cookie! Niente stress.', 'ticinoweb-ai-theme'); ?>
                        </div>
                        <input type="text" name="tw_google_analytics_id" value="<?php echo esc_attr(get_option('tw_google_analytics_id')); ?>" class="tw-seo-input" placeholder="G-XXXXXXXXXX">
                    </div>
                </div>

                <!-- Tab Google Tag -->
                <div class="tw-seo-tab-content" id="gtag">

                    <!-- SEZIONE: Google tag (gtag.js) -->
                    <div class="tw-seo-field-group">
                        <label class="tw-seo-label">
                            <svg class="tw-seo-icon-wire" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg>
                            <?php _e('Google tag (gtag.js)', 'ticinoweb-ai-theme'); ?>
                        </label>
                        <div class="tw-seo-help">
                            <strong>🤔 <?php _e('Cos\'è questo?', 'ticinoweb-ai-theme'); ?></strong>
                            <?php _e('Questo è il codice "Google tag" moderno, fornito da Google Analytics 4, Google Ads o altri prodotti Google. Va incollato <b>esattamente</b> come copiato da Google, inclusi i tag <code>&lt;script&gt;</code>.', 'ticinoweb-ai-theme'); ?>
                            <br><br>
                            <strong>📋 <?php _e('Come si ottiene?', 'ticinoweb-ai-theme'); ?></strong><br>
                            <?php _e('1. Vai su <a href="https://analytics.google.com/" target="_blank" style="color:#4f46e5;font-weight:600;">Google Analytics</a> oppure <a href="https://ads.google.com/" target="_blank" style="color:#4f46e5;font-weight:600;">Google Ads</a><br>2. Scegli il tuo account/proprietà → <em>Amministrazione → Codice di monitoraggio</em> (Analytics) o <em>Strumenti → Tag Google</em> (Ads)<br>3. Copia il blocco che inizia con <code>&lt;!-- Google tag (gtag.js) --&gt;</code><br>4. Incollalo qui sotto', 'ticinoweb-ai-theme'); ?>
                            <br><br>
                            <strong>📍 <?php _e('Dove viene inserito?', 'ticinoweb-ai-theme'); ?></strong><br>
                            <?php _e('Viene aggiunto in cima a <code>&lt;head&gt;</code>, come richiesto da Google.', 'ticinoweb-ai-theme'); ?>
                        </div>
                        <textarea
                            name="tw_gtag_code"
                            rows="8"
                            class="tw-seo-input"
                            style="font-family: monospace; font-size: 12px;"
                            placeholder="<!-- Google tag (gtag.js) -->
<script async src=&quot;https://www.googletagmanager.com/gtag/js?id=G-XXXXXXXXXX&quot;></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'G-XXXXXXXXXX');
</script>"
                        ><?php echo esc_textarea(get_option('tw_gtag_code')); ?></textarea>
                        <!-- Verifica gtag -->
                        <div style="display:flex; align-items:center; gap:12px; margin-top:10px; flex-wrap:wrap;">
                            <button type="button" class="tw-gtag-verify-btn button button-secondary" data-type="gtag" data-result="tw-gtag-result">
                                🔍 <?php _e('Verifica sul sito', 'ticinoweb-ai-theme'); ?>
                            </button>
                            <span id="tw-gtag-result" class="tw-verify-result"></span>
                            <a href="https://tagassistant.google.com/#/?source=TAG_MANAGER&id=<?php echo urlencode(home_url('/')); ?>" target="_blank" class="button button-secondary" style="text-decoration:none;">
                                🔗 <?php _e('Apri Tag Assistant', 'ticinoweb-ai-theme'); ?>
                            </a>
                        </div>

                        </div>

                    <!-- SEZIONE: Google Tag Manager (HEAD) -->
                    <div class="tw-seo-field-group" style="padding-top: 20px; border-top: 1px solid rgba(0,0,0,0.05); margin-top: 10px;">
                        <label class="tw-seo-label">
                            <svg class="tw-seo-icon-wire" viewBox="0 0 24 24"><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M9 9h1v6H9z"/><path d="M14 9l3 3-3 3"/></svg>
                            <?php _e('Google Tag Manager — Snippet &lt;head&gt;', 'ticinoweb-ai-theme'); ?>
                        </label>
                        <div class="tw-seo-help">
                            <strong>🤔 <?php _e('Cos\'è Google Tag Manager?', 'ticinoweb-ai-theme'); ?></strong>
                            <?php _e('GTM è uno strumento che permette di gestire tutti i tag (Analytics, Ads, Hotjar, Facebook Pixel, ecc.) da un unico posto <b>senza toccare il codice del sito</b>. È la scelta professionale per chi ha molti strumenti di tracciamento. <em>Nota: se usi GTM non devi inserire il Google tag (gtag.js) separato — GTM li gestisce già.</em>', 'ticinoweb-ai-theme'); ?>
                            <br><br>
                            <strong>📋 <?php _e('Come si ottiene?', 'ticinoweb-ai-theme'); ?></strong><br>
                            <?php _e('1. Vai su <a href="https://tagmanager.google.com/" target="_blank" style="color:#4f46e5;font-weight:600;">tagmanager.google.com</a><br>2. Seleziona il tuo Container → <em>Amministrazione → Installa Google Tag Manager</em><br>3. Copia il <b>primo blocco</b> (quello per <code>&lt;head&gt;</code>)<br>4. Incollalo qui sotto', 'ticinoweb-ai-theme'); ?>
                            <br><br>
                            <strong>📍 <?php _e('Dove viene inserito?', 'ticinoweb-ai-theme'); ?></strong><br>
                            <?php _e('Viene inserito il più in alto possibile nel <code>&lt;head&gt;</code>, come richiesto da Google.', 'ticinoweb-ai-theme'); ?>
                        </div>
                        <textarea
                            name="tw_gtm_head_code"
                            rows="6"
                            class="tw-seo-input"
                            style="font-family: monospace; font-size: 12px;"
                            placeholder="<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-XXXXXXX');</script>
<!-- End Google Tag Manager -->"
                        ><?php echo esc_textarea(get_option('tw_gtm_head_code')); ?></textarea>
                        <!-- Verifica GTM head -->
                        <div style="display:flex; align-items:center; gap:12px; margin-top:10px; flex-wrap:wrap;">
                            <button type="button" class="tw-gtag-verify-btn button button-secondary" data-type="gtm_head" data-result="tw-gtmhead-result">
                                🔍 <?php _e('Verifica sul sito', 'ticinoweb-ai-theme'); ?>
                            </button>
                            <span id="tw-gtmhead-result" class="tw-verify-result"></span>
                            <a href="https://tagmanager.google.com/" target="_blank" class="button button-secondary" style="text-decoration:none;">
                                🔗 <?php _e('Apri GTM Dashboard', 'ticinoweb-ai-theme'); ?>
                            </a>
                        </div>

                        </div>

                    <!-- SEZIONE: Google Tag Manager (BODY noscript) -->
                    <div class="tw-seo-field-group" style="padding-top: 20px; border-top: 1px solid rgba(0,0,0,0.05); margin-top: 10px;">
                        <label class="tw-seo-label">
                            <svg class="tw-seo-icon-wire" viewBox="0 0 24 24"><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M9 15l3-3-3-3"/><line x1="15" y1="9" x2="15" y2="15"/></svg>
                            <?php _e('Google Tag Manager — Snippet &lt;body&gt; (noscript)', 'ticinoweb-ai-theme'); ?>
                        </label>
                        <div class="tw-seo-help">
                            <strong>🤔 <?php _e('Perché serve anche questo?', 'ticinoweb-ai-theme'); ?></strong>
                            <?php _e('Google richiede un secondo frammento di codice <code>&lt;noscript&gt;</code> da inserire subito dopo l\'apertura del <code>&lt;body&gt;</code>. Serve per tracciare anche i browser che hanno JavaScript disabilitato. Va incollato <b>insieme</b> allo snippet head sopra.', 'ticinoweb-ai-theme'); ?>
                            <br><br>
                            <strong>📋 <?php _e('Come si ottiene?', 'ticinoweb-ai-theme'); ?></strong><br>
                            <?php _e('Dalla stessa schermata di GTM (<em>Installa Google Tag Manager</em>), copia il <b>secondo blocco</b> (quello per <code>&lt;body&gt;</code>).', 'ticinoweb-ai-theme'); ?>
                            <br><br>
                            <strong>📍 <?php _e('Dove viene inserito?', 'ticinoweb-ai-theme'); ?></strong><br>
                            <?php _e('Viene inserito immediatamente dopo il tag di apertura <code>&lt;body&gt;</code> tramite l\'hook WordPress <code>wp_body_open</code>. Assicurati che il tuo tema (o il tema padre) contenga <code>wp_body_open();</code> subito dopo <code>&lt;body&gt;</code>.', 'ticinoweb-ai-theme'); ?>
                            <br><br>
                            <strong style="color:#e67e22;">⚠️ <?php _e('Nota importante:', 'ticinoweb-ai-theme'); ?></strong>
                            <?php _e('Se usi <b>GTM</b>, non inserire anche il Google tag (gtag.js) nel campo precedente: evita la duplicazione del tracciamento.', 'ticinoweb-ai-theme'); ?>
                        </div>
                        <textarea
                            name="tw_gtm_body_code"
                            rows="5"
                            class="tw-seo-input"
                            style="font-family: monospace; font-size: 12px;"
                            placeholder="<!-- Google Tag Manager (noscript) -->
<noscript><iframe src=&quot;https://www.googletagmanager.com/ns.html?id=GTM-XXXXXXX&quot;
height=&quot;0&quot; width=&quot;0&quot; style=&quot;display:none;visibility:hidden&quot;></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->"
                        ><?php echo esc_textarea(get_option('tw_gtm_body_code')); ?></textarea>
                        <!-- Verifica GTM body -->
                        <div style="display:flex; align-items:center; gap:12px; margin-top:10px; flex-wrap:wrap;">
                            <button type="button" class="tw-gtag-verify-btn button button-secondary" data-type="gtm_body" data-result="tw-gtmbody-result">
                                🔍 <?php _e('Verifica sul sito', 'ticinoweb-ai-theme'); ?>
                            </button>
                            <span id="tw-gtmbody-result" class="tw-verify-result"></span>
                            <a href="https://tagassistant.google.com/#/?source=TAG_MANAGER&id=<?php echo urlencode(home_url('/')); ?>" target="_blank" class="button button-secondary" style="text-decoration:none;">
                                🔗 <?php _e('Apri Tag Assistant', 'ticinoweb-ai-theme'); ?>
                            </a>
                        </div>

                        </div>

                    <!-- INFO BOX: gtag vs GTM -->
                    <div style="background: rgba(79,70,229,0.06); border: 1px solid rgba(79,70,229,0.2); border-radius: 12px; padding: 18px; margin-top: 10px;">
                        <strong style="color:#4f46e5; display:block; margin-bottom: 8px;">💡 <?php _e('gtag.js o Google Tag Manager: quale usare?', 'ticinoweb-ai-theme'); ?></strong>
                        <table style="width:100%; border-collapse:collapse; font-size: 13px;">
                            <tr style="border-bottom: 1px solid rgba(0,0,0,0.07);">
                                <th style="text-align:left; padding: 8px 10px; color:#334155;"></th>
                                <th style="text-align:center; padding: 8px 10px; color:#4f46e5;">Google tag (gtag.js)</th>
                                <th style="text-align:center; padding: 8px 10px; color:#7c3aed;">Google Tag Manager (GTM)</th>
                            </tr>
                            <tr style="border-bottom: 1px solid rgba(0,0,0,0.04);">
                                <td style="padding: 7px 10px; color:#475569;"><?php _e('Semplicità', 'ticinoweb-ai-theme'); ?></td>
                                <td style="text-align:center;">⭐⭐⭐</td>
                                <td style="text-align:center;">⭐⭐</td>
                            </tr>
                            <tr style="border-bottom: 1px solid rgba(0,0,0,0.04);">
                                <td style="padding: 7px 10px; color:#475569;"><?php _e('Flessibilità (molti tag)', 'ticinoweb-ai-theme'); ?></td>
                                <td style="text-align:center;">⭐⭐</td>
                                <td style="text-align:center;">⭐⭐⭐</td>
                            </tr>
                            <tr style="border-bottom: 1px solid rgba(0,0,0,0.04);">
                                <td style="padding: 7px 10px; color:#475569;"><?php _e('Ideale per', 'ticinoweb-ai-theme'); ?></td>
                                <td style="text-align:center; padding: 7px 10px; color:#475569;"><?php _e('Solo Analytics o Ads', 'ticinoweb-ai-theme'); ?></td>
                                <td style="text-align:center; padding: 7px 10px; color:#475569;"><?php _e('Più strumenti di tracciamento', 'ticinoweb-ai-theme'); ?></td>
                            </tr>
                        </table>
                    </div>

                </div>

                <!-- Tab Sitemap -->
                <div class="tw-seo-tab-content" id="sitemap">
                    <div class="tw-seo-field-group">
                        <label class="tw-seo-label"><?php _e('Link Sitemap XML', 'ticinoweb-ai-theme'); ?></label>
                        <div class="tw-seo-help">
                            <?php _e('Il tuo sito genera automaticamente una mappa per Google qui:', 'ticinoweb-ai-theme'); ?>
                            <a href="<?php echo home_url('/wp-sitemap.xml'); ?>" target="_blank" style="color: #4f46e5; text-decoration: underline;"><?php echo home_url('/wp-sitemap.xml'); ?></a>
                        </div>
                    </div>

                    <div class="tw-seo-field-group">
                        <label class="tw-seo-label"><?php _e('Escludi Tipi di Post dalla Sitemap', 'ticinoweb-ai-theme'); ?></label>
                        <?php
                        $post_types = get_post_types(array('public' => true), 'objects');
                        $excludes = get_option('tw_seo_exclude_sitemap', array());
                        foreach ($post_types as $type) : ?>
                            <label style="display: block; margin-bottom: 5px;">
                                <input type="checkbox" name="tw_seo_exclude_sitemap[]" value="<?php echo esc_attr($type->name); ?>" <?php checked(in_array($type->name, (array)$excludes)); ?>>
                                <?php echo esc_html($type->label); ?>
                            </label>
                        <?php endforeach; ?>
                    </div>

                    <div class="tw-seo-field-group" style="padding-top: 20px; border-top: 1px solid rgba(0,0,0,0.05); margin-top: 20px;">
                        <label class="tw-seo-label"><?php _e('Attiva Metabox SEO per Tipi di Post', 'ticinoweb-ai-theme'); ?></label>
                        <div class="tw-seo-help">
                            <?php _e('Seleziona su quali contenuti vuoi vedere il box SEO per inserire titoli e descrizioni personalizzate. Se disattivo, il plugin le genererà in modo intelligente.', 'ticinoweb-ai-theme'); ?>
                        </div>
                        <?php
                        $metabox_enabled = get_option('tw_seo_enable_metabox', array());
                        foreach ($post_types as $type) : ?>
                            <label style="display: block; margin-bottom: 5px;">
                                <input type="checkbox" name="tw_seo_enable_metabox[]" value="<?php echo esc_attr($type->name); ?>" <?php checked(in_array($type->name, (array)$metabox_enabled)); ?>>
                                <?php echo esc_html($type->label); ?>
                            </label>
                        <?php endforeach; ?>
                    </div>
                </div>

                <!-- Tab Impostazioni SEO -->
                <div class="tw-seo-tab-content" id="settings">
                    <div class="tw-seo-field-group">
                        <label class="tw-seo-label"><?php _e('Funzionalità SEO Attive', 'ticinoweb-ai-theme'); ?></label>
                        <div class="tw-seo-help">
                            <strong>⚙️ <?php _e('Controllo moduli SEO', 'ticinoweb-ai-theme'); ?></strong>
                            <?php _e('Attiva o disattiva singoli moduli SEO. Utile se il sito usa già un plugin esterno per una funzionalità specifica, o se non hai bisogno di Google Tag.', 'ticinoweb-ai-theme'); ?>
                        </div>

                        <div class="tw-toggle-row">
                            <div>
                                <div class="tw-toggle-label">📊 <?php _e('Schema.org JSON-LD', 'ticinoweb-ai-theme'); ?></div>
                                <div class="tw-toggle-desc"><?php _e('Dati strutturati per Google Rich Results (Knowledge Panel, breadcrumb, articoli)', 'ticinoweb-ai-theme'); ?></div>
                            </div>
                            <label class="tw-toggle">
                                <input type="checkbox" name="tw_seo_enable_schema" value="1" <?php checked(get_option('tw_seo_enable_schema', '1'), '1'); ?>>
                                <span class="tw-toggle-slider"></span>
                            </label>
                        </div>

                        <div class="tw-toggle-row">
                            <div>
                                <div class="tw-toggle-label">🔗 <?php _e('Open Graph (og:title, og:image...)', 'ticinoweb-ai-theme'); ?></div>
                                <div class="tw-toggle-desc"><?php _e('Meta tag per condivisioni su Facebook, LinkedIn, WhatsApp', 'ticinoweb-ai-theme'); ?></div>
                            </div>
                            <label class="tw-toggle">
                                <input type="checkbox" name="tw_seo_enable_og" value="1" <?php checked(get_option('tw_seo_enable_og', '1'), '1'); ?>>
                                <span class="tw-toggle-slider"></span>
                            </label>
                        </div>

                        <div class="tw-toggle-row">
                            <div>
                                <div class="tw-toggle-label">🐦 <?php _e('Twitter / X Card', 'ticinoweb-ai-theme'); ?></div>
                                <div class="tw-toggle-desc"><?php _e('Meta tag per anteprima su Twitter/X con immagine grande', 'ticinoweb-ai-theme'); ?></div>
                            </div>
                            <label class="tw-toggle">
                                <input type="checkbox" name="tw_seo_enable_twitter" value="1" <?php checked(get_option('tw_seo_enable_twitter', '1'), '1'); ?>>
                                <span class="tw-toggle-slider"></span>
                            </label>
                        </div>

                        <div class="tw-toggle-row">
                            <div>
                                <div class="tw-toggle-label">📡 <?php _e('Google Tag / GTM Output', 'ticinoweb-ai-theme'); ?></div>
                                <div class="tw-toggle-desc"><?php _e('Abilita l\'iniezione dei codici Google Tag (gtag.js) e GTM nell\'HTML del sito. Disattiva se gestisci i tag da un plugin separato.', 'ticinoweb-ai-theme'); ?></div>
                            </div>
                            <label class="tw-toggle">
                                <input type="checkbox" name="tw_seo_enable_gtag_out" value="1" <?php checked(get_option('tw_seo_enable_gtag_out', '1'), '1'); ?>>
                                <span class="tw-toggle-slider"></span>
                            </label>
                        </div>
                    </div>

                    <div class="tw-seo-field-group" style="padding-top:20px;border-top:1px solid rgba(0,0,0,0.05);margin-top:10px;">
                        <div style="background:rgba(79,70,229,0.06);border:1px solid rgba(79,70,229,0.15);border-radius:12px;padding:16px;">
                            <strong style="color:#4f46e5;display:block;margin-bottom:8px;">📋 <?php _e('Tag meta iniettati automaticamente:', 'ticinoweb-ai-theme'); ?></strong>
                            <ul style="margin:0;padding-left:18px;color:#475569;font-size:13px;line-height:1.8;">
                                <li><code>meta description</code> — <?php _e('descrizione pagina per Google', 'ticinoweb-ai-theme'); ?></li>
                                <li><code>og:title / og:description / og:image / og:url / og:site_name</code></li>
                                <li><code>twitter:card / twitter:title / twitter:image</code></li>
                                <li><code>link rel="canonical"</code> — <?php _e('evita contenuto duplicato', 'ticinoweb-ai-theme'); ?></li>
                                <li><code>meta robots</code> — <?php _e('controllabile per singola pagina via metabox', 'ticinoweb-ai-theme'); ?></li>
                                <li><code>google-site-verification</code> + <code>msvalidate.01</code> (Bing)</li>
                            </ul>
                        </div>
                    </div>
                </div>

                <div style="margin-top: 30px;">
                    <button type="submit" class="tw-seo-submit"><?php _e('Salva Impostazioni SEO', 'ticinoweb-ai-theme'); ?></button>
                </div>
            </form>
        </div>
    </div>

    <style>
        .tw-verify-result {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 6px 14px;
            border-radius: 20px;
            font-size: 13px;
            font-weight: 600;
            opacity: 0;
            transition: opacity 0.3s ease, transform 0.3s ease;
            transform: translateY(4px);
        }
        .tw-verify-result.visible {
            opacity: 1;
            transform: translateY(0);
        }
        .tw-verify-result.success {
            background: rgba(22,163,74,0.1);
            color: #15803d;
            border: 1px solid rgba(22,163,74,0.3);
        }
        .tw-verify-result.error {
            background: rgba(220,38,38,0.08);
            color: #b91c1c;
            border: 1px solid rgba(220,38,38,0.2);
        }
        .tw-verify-result.loading {
            background: rgba(79,70,229,0.07);
            color: #4f46e5;
            border: 1px solid rgba(79,70,229,0.2);
        }
        .tw-verify-result.warning {
            background: rgba(234,179,8,0.08);
            color: #b45309;
            border: 1px solid rgba(234,179,8,0.25);
        }
    </style>

    <script type="text/javascript">
    jQuery(document).ready(function($) {
        $('.tw-seo-tab-btn').on('click', function() {
            var tabId = $(this).data('tab');
            $('.tw-seo-tab-btn').removeClass('active');
            $(this).addClass('active');
            $('.tw-seo-tab-content').removeClass('active');
            $('#' + tabId).addClass('active');
        });

        // Google Tag tab: show/hide based on tw_seo_enable_gtag_out toggle
        function twSeoUpdateGtagTabVisibility() {
            var gtagOn = $('input[name="tw_seo_enable_gtag_out"]').is(':checked');
            var $gtagBtn = $('.tw-seo-tab-btn[data-tab="gtag"]');
            if (gtagOn) {
                $gtagBtn.css({'display':'', 'opacity':'1'});
            } else {
                if ($gtagBtn.hasClass('active')) {
                    $gtagBtn.removeClass('active');
                    $('.tw-seo-tab-btn[data-tab="settings"]').addClass('active');
                    $('.tw-seo-tab-content').removeClass('active');
                    $('#settings').addClass('active');
                }
                $gtagBtn.hide();
            }
        }
        twSeoUpdateGtagTabVisibility();
        $('input[name="tw_seo_enable_gtag_out"]').on('change', twSeoUpdateGtagTabVisibility);

        // Checklist → tab navigation
        $(document).on('click', '.tw-cl-goto', function() {
            var tabId = $(this).data('tab');
            $('.tw-seo-tab-btn').removeClass('active');
            $('.tw-seo-tab-btn[data-tab="' + tabId + '"]').addClass('active');
            $('.tw-seo-tab-content').removeClass('active');
            $('#' + tabId).addClass('active');
            $('html, body').animate({ scrollTop: $('.tw-seo-tabs-nav').offset().top - 20 }, 300);
        });

        // Import da WordPress: blocco Generali
        $(document).on('click', '.tw-import-btn[data-action="import_generali"]', function() {
            var btn = $(this);
            var title = btn.data('home-title');
            var desc  = btn.data('description');
            if (title && !$('input[name="tw_seo_home_title"]').val()) {
                $('input[name="tw_seo_home_title"]').val(title).addClass('tw-just-filled');
            }
            if (desc && !$('textarea[name="tw_seo_description"]').val()) {
                $('textarea[name="tw_seo_description"]').val(desc).addClass('tw-just-filled');
            }
            btn.text('\u2705 <?php echo esc_js(__('Importato!', 'ticinoweb-ai-theme')); ?>').prop('disabled', true);
            setTimeout(function() { btn.text('\u2728 <?php echo esc_js(__('Suggerisci campi da WP', 'ticinoweb-ai-theme')); ?>').prop('disabled', false); }, 2500);
        });

        // Import pill: riempe singolo campo
        $(document).on('click', '.tw-import-pill', function() {
            var targetId = $(this).data('fill-target');
            var val      = $(this).data('fill-value');
            if (targetId && val) {
                $('#' + targetId).val(val).focus();
            }
        });

        // Highlight fields just filled
        $('<style>.tw-just-filled { animation: twFilledFlash 1.2s ease; } @keyframes twFilledFlash { 0%,100%{box-shadow:none} 40%{box-shadow:0 0 0 4px rgba(79,70,229,0.25);} }<\/style>').appendTo('head');

        // Remove class after animation
        $(document).on('animationend webkitAnimationEnd', '.tw-just-filled', function() {
            $(this).removeClass('tw-just-filled');
        });

        // Media Library Integration
        var mediaUploader;

        function updateImgPreview(targetId, url) {
            var previewId  = targetId + '_preview';
            var wrapId     = targetId + '_preview_wrap';
            if (url) {
                $('#' + previewId).attr('src', url);
                $('#' + wrapId).show();
            } else {
                $('#' + wrapId).hide();
                $('#' + previewId).attr('src', '');
            }
        }

        // Init previews for any pre-filled fields on page load
        $('.tw-seo-upload-btn[data-preview]').each(function() {
            var targetId = $(this).data('target');
            var url = $('#' + targetId).val();
            updateImgPreview(targetId, url);
        });

        // Update preview when URL is typed/pasted manually
        $('#tw_seo_org_logo, #tw_seo_social_image').on('input change', function() {
            updateImgPreview(this.id, this.value);
        });

        // Remove button
        $(document).on('click', '.tw-img-remove-btn', function() {
            var targetId = $(this).data('target');
            $('#' + targetId).val('');
            updateImgPreview(targetId, '');
        });

        $('.tw-seo-upload-btn').on('click', function(e) {
            e.preventDefault();
            var button = $(this);
            var targetId = button.data('target');

            mediaUploader = wp.media({
                title: '<?php _e('Scegli Immagine', 'ticinoweb-ai-theme'); ?>',
                button: { text: '<?php _e('Usa questa immagine', 'ticinoweb-ai-theme'); ?>' },
                multiple: false
            });

            mediaUploader.on('select', function() {
                var attachment = mediaUploader.state().get('selection').first().toJSON();
                var url = attachment.url;
                $('#' + targetId).val(url).trigger('change');
                updateImgPreview(targetId, url);
            });

            mediaUploader.open();
        });

        // ── Google Tag Verification ────────────────────────────────────────────
        var fieldMap = {
            'gtag':     'textarea[name="tw_gtag_code"]',
            'gtm_head': 'textarea[name="tw_gtm_head_code"]',
            'gtm_body': 'textarea[name="tw_gtm_body_code"]'
        };

        /**
         * Extract the measurement/container ID from the pasted code.
         * Supports: G-XXXXXXXX, AW-XXXXXXXX, GTM-XXXXXXX, UA-XXXXX-X
         */
        function extractTagId(code) {
            var patterns = [
                /['"]?(G-[A-Z0-9]+)['"]?/,        // GA4
                /['"]?(AW-[0-9]+)['"]?/,           // Google Ads
                /['"]?(GTM-[A-Z0-9]+)['"]?/,       // GTM
                /['"]?(UA-[0-9]+-[0-9]+)['"]?/     // Universal Analytics (legacy)
            ];
            for (var i = 0; i < patterns.length; i++) {
                var m = code.match(patterns[i]);
                if (m) return m[1];
            }
            return null;
        }

        function showResult($el, type, message) {
            $el.removeClass('success error loading warning visible')
               .addClass(type + ' visible')
               .html(message);
        }

        $('.tw-gtag-verify-btn').on('click', function() {
            var btn      = $(this);
            var fieldSel = fieldMap[btn.data('type')];
            var $result  = $('#' + btn.data('result'));
            var code     = $(fieldSel).val().trim();

            if (!code) {
                showResult($result, 'warning', '⚠️ <?php _e('Campo vuoto — incolla prima il codice.', 'ticinoweb-ai-theme'); ?>');
                return;
            }

            var tagId = extractTagId(code);
            if (!tagId) {
                showResult($result, 'warning', '⚠️ <?php _e('ID non trovato nel codice. Controlla il testo incollato.', 'ticinoweb-ai-theme'); ?>');
                return;
            }

            showResult($result, 'loading', '⏳ <?php echo esc_js(__('Verifica in corso...', 'ticinoweb-ai-theme')); ?>');
            btn.prop('disabled', true);

            $.ajax({
                url: ajaxurl,
                type: 'POST',
                data: {
                    action:  'tw_seo_verify_tag',
                    nonce:   '<?php echo wp_create_nonce('tw_seo_verify_tag'); ?>',
                    tag_id:  tagId,
                    tag_type: btn.data('type')
                },
                success: function(response) {
                    btn.prop('disabled', false);
                    if (response.success) {
                        var d = response.data;
                        if (d.found) {
                            showResult($result, 'success',
                                '✅ ' + tagId + ' <?php echo esc_js(__('trovato nell\'HTML del sito!', 'ticinoweb-ai-theme')); ?>' +
                                (d.container_ok ? ' · Container GTM attivo ✓' : '')
                            );
                        } else {
                            var hint = '';
                            if (!d.saved) hint = ' · <?php echo esc_js(__('Salva prima le impostazioni!', 'ticinoweb-ai-theme')); ?>';
                            showResult($result, 'error',
                                '❌ ' + tagId + ' <?php echo esc_js(__('non trovato nell\'HTML.', 'ticinoweb-ai-theme')); ?>' + hint
                            );
                        }
                    } else {
                        showResult($result, 'error', '❌ ' + (response.data || '<?php echo esc_js(__('Errore di rete.', 'ticinoweb-ai-theme')); ?>'));
                    }
                },
                error: function() {
                    btn.prop('disabled', false);
                    showResult($result, 'error', '❌ <?php echo esc_js(__('Errore di connessione al server.', 'ticinoweb-ai-theme')); ?>');
                }
            });
        });
    });
    </script>
    <?php
}

/**
 * SEO Logic: Metadata and Frontend Hooks
 */

// ── Google Tag AJAX Verification Handler ─────────────────────────────────────
add_action('wp_ajax_tw_seo_verify_tag', 'tw_seo_ajax_verify_tag');
function tw_seo_ajax_verify_tag() {
    check_ajax_referer('tw_seo_verify_tag', 'nonce');

    if (!current_user_can('edit_pages')) {
        wp_send_json_error(__('Permesso negato.', 'ticinoweb-ai-theme'));
    }

    $tag_id   = sanitize_text_field($_POST['tag_id'] ?? '');
    $tag_type = sanitize_text_field($_POST['tag_type'] ?? '');

    if (empty($tag_id)) {
        wp_send_json_error(__('ID tag mancante.', 'ticinoweb-ai-theme'));
    }

    // Fetch the site homepage HTML (bypass cache with nocache param)
    $url      = add_query_arg('nocache', time(), home_url('/'));
    $response = wp_remote_get($url, array(
        'timeout'    => 15,
        'user-agent' => 'Mozilla/5.0 (compatible; tW-SEO-Verifier/1.0)',
        'sslverify'  => false,
    ));

    if (is_wp_error($response)) {
        wp_send_json_error(sprintf(
            __('Impossibile raggiungere il sito: %s', 'ticinoweb-ai-theme'),
            $response->get_error_message()
        ));
    }

    $html = wp_remote_retrieve_body($response);

    // Check if the tag ID appears in the HTML source
    $found = (strpos($html, $tag_id) !== false);

    // For GTM IDs: also verify the container exists on Google's servers
    $container_ok = false;
    if (strpos($tag_id, 'GTM-') === 0) {
        $gtm_url   = 'https://www.googletagmanager.com/gtm.js?id=' . urlencode($tag_id);
        $gtm_resp  = wp_remote_head($gtm_url, array('timeout' => 8, 'sslverify' => true));
        $gtm_code  = is_wp_error($gtm_resp) ? 0 : wp_remote_retrieve_response_code($gtm_resp);
        $container_ok = ($gtm_code === 200);
    }

    // Check whether the saved option already contains the ID (helps diagnose
    // "not found" cases where the user forgot to save)
    $option_map = array(
        'gtag'     => 'tw_gtag_code',
        'gtm_head' => 'tw_gtm_head_code',
        'gtm_body' => 'tw_gtm_body_code',
    );
    $saved_code = get_option($option_map[$tag_type] ?? '', '');
    $saved      = (strpos($saved_code, $tag_id) !== false);

    wp_send_json_success(array(
        'found'        => $found,
        'saved'        => $saved,
        'container_ok' => $container_ok,
        'tag_id'       => $tag_id,
    ));
}

/**
 * SEO Logic: Metadata and Frontend Hooks
 */
/**
 * Inject Google tag (gtag.js) and Google Tag Manager <head> snippet
 * Priority 1 → as early as possible in <head>
 */
add_action('wp_head', 'tw_seo_inject_google_tags', 1);
function tw_seo_inject_google_tags() {
    if (is_admin()) return;

    // Gate: check the Impostazioni toggle
    if (get_option('tw_seo_enable_gtag_out', '1') !== '1') return;

    // Google tag (gtag.js) — standalone snippet
    $gtag_code = get_option('tw_gtag_code');
    if (!empty(trim($gtag_code)) && (strpos($gtag_code, '<') !== false)) {
        echo "\n" . $gtag_code . "\n";
    }

    // Google Tag Manager — <head> snippet
    $gtm_head = get_option('tw_gtm_head_code');
    if (!empty(trim($gtm_head)) && (strpos($gtm_head, '<') !== false)) {
        echo "\n" . $gtm_head . "\n";
    }
}

/**
 * Inject Google Tag Manager <body> noscript snippet
 * Uses wp_body_open hook (fires immediately after <body> opening tag)
 */
add_action('wp_body_open', 'tw_seo_inject_gtm_body', 1);
function tw_seo_inject_gtm_body() {
    if (is_admin()) return;

    $gtm_body = get_option('tw_gtm_body_code');
    if (!empty(trim($gtm_body))) {
        echo "\n" . $gtm_body . "\n";
    }
}

/**
 * Context-aware canonical URL.
 *
 * Returns '' when a canonical can't be reliably determined (search results, 404),
 * so we never emit an empty or wrong <link rel="canonical">. The previous version
 * used get_permalink() everywhere, which on archives/home returned the URL of the
 * first post in the loop (wrong) or false (empty).
 *
 * @return string Absolute canonical URL, or '' when none applies.
 */
function tw_seo_get_canonical_url() {
    $canonical = '';
    if (is_front_page()) {
        $canonical = home_url('/');
    } elseif (is_home()) { // Blog posts page (when a static front page is set)
        $posts_page = (int) get_option('page_for_posts');
        $canonical = $posts_page ? get_permalink($posts_page) : home_url('/');
    } elseif (is_singular()) {
        $url = get_permalink();
        $canonical = $url ?: '';
    } elseif (is_category() || is_tag() || is_tax()) {
        $term = get_queried_object();
        if ($term && !is_wp_error($term)) {
            $link = get_term_link($term);
            $canonical = is_wp_error($link) ? '' : $link;
        }
    } elseif (is_post_type_archive()) {
        $link = get_post_type_archive_link(get_query_var('post_type'));
        $canonical = $link ?: '';
    } elseif (is_author()) {
        $canonical = get_author_posts_url(get_queried_object_id()) ?: '';
    }

    if ($canonical && function_exists('ticinoweb_frontend_url')) {
        $canonical = ticinoweb_frontend_url($canonical, 'theme:seo:canonical');
    }

    /**
     * Filter the canonical URL generated by tW SEO.
     *
     * @param string $canonical Canonical URL or empty string.
     */
    return apply_filters('ticinoweb_seo_canonical_url', $canonical);
}

// Remove WordPress core's own canonical tag so we don't emit two <link rel="canonical">
// tags on singular pages (core adds one at priority 10; we output our own below).
remove_action('wp_head', 'rel_canonical');

/**
 * Logo dell'organizzazione, con ricaduta sul logo del sito.
 *
 * Il logo va inserito in un posto solo: quello del tema (ticinoweb_site_logo,
 * o il custom_logo di WordPress). Il campo SEO resta disponibile per chi
 * vuole un'immagine diversa nei dati strutturati, ma se e' vuoto non si
 * inventa nulla: eredita. Prima di questa modifica un sito che aggiornava il
 * logo del tema si ritrovava og:image e logo Schema.org fermi al file
 * precedente, e se quel file veniva cancellato puntavano a un 404.
 *
 * @return string URL, stringa vuota se nessuna fonte e' valorizzata.
 */
function tw_seo_get_org_logo() {
    $logo = trim((string) get_option('tw_seo_org_logo'));

    if ($logo === '') {
        $logo = trim((string) get_option('ticinoweb_site_logo'));
    }

    if ($logo === '' && function_exists('get_custom_logo')) {
        $custom_logo_id = (int) get_theme_mod('custom_logo');
        if ($custom_logo_id) {
            $src = wp_get_attachment_image_url($custom_logo_id, 'full');
            if ($src) {
                $logo = $src;
            }
        }
    }

    return $logo;
}

/**
 * Immagine per le condivisioni social, con ricaduta sul logo.
 *
 * @return string
 */
function tw_seo_get_social_image() {
    $img = trim((string) get_option('tw_seo_social_image'));
    return $img !== '' ? $img : tw_seo_get_org_logo();
}

add_action('wp_head', 'tw_seo_inject_metadata', 1);
function tw_seo_inject_metadata() {
    if (is_admin()) return;

    $description  = get_option('tw_seo_description');
    $social_img   = tw_seo_get_social_image();
    $twitter_user = get_option('tw_seo_twitter_user');
    $google_ver   = get_option('tw_seo_google_console');
    $bing_ver     = get_option('tw_seo_bing_webmaster');
    $site_name    = get_bloginfo('name');
    $og_enabled   = get_option('tw_seo_enable_og', '1') === '1';
    $tw_enabled   = get_option('tw_seo_enable_twitter', '1') === '1';

    // Google Verification
    if ($google_ver) {
        echo '<meta name="google-site-verification" content="' . esc_attr($google_ver) . '" />' . "\n";
    }

    // Bing Webmaster Verification
    if ($bing_ver) {
        echo '<meta name="msvalidate.01" content="' . esc_attr($bing_ver) . '" />' . "\n";
    }

    // Robots Meta Override
    $robots = '';
    if (is_singular()) {
        $robots = get_post_meta(get_the_ID(), '_tw_seo_robots', true);
    } else {
        // Gli archivi di post type non sono "singular": il loro robots va letto
        // dalla pagina che li rappresenta (es. la shop page di WooCommerce),
        // altrimenti un noindex impostato su quella pagina verrebbe ignorato.
        $archive_page_id = tw_seo_get_archive_page_id();
        if ($archive_page_id) {
            $robots = get_post_meta($archive_page_id, '_tw_seo_robots', true);
        }
    }
    if ($robots && $robots !== 'index, follow') {
        echo '<meta name="robots" content="' . esc_attr($robots) . '" />' . "\n";
    }

    // Canonical URL (context-aware; core rel_canonical removed above to avoid duplicates)
    $canonical = tw_seo_get_canonical_url();
    if ($canonical) {
        echo '<link rel="canonical" href="' . esc_url($canonical) . '" />' . "\n";
    }

    // Meta Description (max 160 chars)
    $final_desc = '';
    if (is_singular()) {
        $custom_desc = get_post_meta(get_the_ID(), '_tw_seo_description', true);
        if ($custom_desc) {
            $final_desc = $custom_desc;
        } else {
            $auto = tw_seo_get_auto_metadata(get_post());
            $final_desc = $auto['description'];
        }
    } elseif (is_category() || is_tag() || is_tax()) {
        $term = get_queried_object();
        $custom_desc = get_term_meta($term->term_id, '_tw_seo_description', true);
        if ($custom_desc) {
            $final_desc = $custom_desc;
        } else {
            $final_desc = term_description($term->term_id);
            if (!$final_desc) $final_desc = $description;
        }
    } else {
        $final_desc = $description;
    }
    $final_desc = wp_strip_all_tags(strip_shortcodes((string) $final_desc));
    if (strlen($final_desc) > 160) $final_desc = mb_substr($final_desc, 0, 157) . '...';

    if (function_exists('ticinoweb_frontend_text') && $final_desc) {
        $final_desc = ticinoweb_frontend_text($final_desc, 'theme:seo:meta_description');
    }

    /**
     * Filter the meta description tag.
     *
     * @param string $final_desc Final meta description.
     */
    $final_desc = apply_filters('ticinoweb_seo_meta_description', $final_desc);

    if ($final_desc) {
        echo '<meta name="description" content="' . esc_attr($final_desc) . '" />' . "\n";
    }

    // Open Graph
    $og_title = '';
    if (is_front_page()) {
        $home_title = get_option('tw_seo_home_title');
        $og_title = $home_title ? $home_title : $site_name;
    } elseif (is_singular()) {
        $custom_title = get_post_meta(get_the_ID(), '_tw_seo_title', true);
        if ($custom_title) {
            $og_title = $custom_title;
        } else {
            $auto = tw_seo_get_auto_metadata(get_post());
            $og_title = $auto['title'];
        }
    } elseif (is_category() || is_tag() || is_tax()) {
        $term = get_queried_object();
        $custom_title = get_term_meta($term->term_id, '_tw_seo_title', true);
        $og_title = $custom_title ? $custom_title : single_term_title('', false);
    } else {
        $og_title = $site_name;
    }

    if (function_exists('ticinoweb_frontend_text') && $og_title) {
        $og_title = ticinoweb_frontend_text($og_title, 'theme:seo:og_title');
    }

    $og_title  = apply_filters('ticinoweb_seo_og_title', $og_title);
    $og_desc   = apply_filters('ticinoweb_seo_og_description', $final_desc);
    $og_url    = apply_filters('ticinoweb_seo_og_url', $canonical);
    $og_locale = apply_filters('ticinoweb_seo_og_locale', str_replace('-', '_', get_locale()));

    $og_img = $social_img;
    if (is_singular() && has_post_thumbnail()) {
        $og_img = get_the_post_thumbnail_url(get_the_ID(), 'full');
    }
    $og_type = (is_singular() && !is_front_page()) ? 'article' : 'website';

    if ($og_enabled) {
        echo '<meta property="og:title" content="' . esc_attr($og_title) . '" />' . "\n";
        echo '<meta property="og:description" content="' . esc_attr($og_desc) . '" />' . "\n";
        if ($og_url) {
            echo '<meta property="og:url" content="' . esc_url($og_url) . '" />' . "\n";
        }
        echo '<meta property="og:type" content="' . esc_attr($og_type) . '" />' . "\n";
        echo '<meta property="og:site_name" content="' . esc_attr($site_name) . '" />' . "\n";
        echo '<meta property="og:locale" content="' . esc_attr($og_locale) . '" />' . "\n";
        if ($og_img) {
            echo '<meta property="og:image" content="' . esc_url($og_img) . '" />' . "\n";
            echo '<meta property="og:image:width" content="1200" />' . "\n";
            echo '<meta property="og:image:height" content="630" />' . "\n";
        }
    }

    // Twitter / X Card
    if ($tw_enabled) {
        $tw_title = apply_filters('ticinoweb_seo_twitter_title', $og_title);
        $tw_desc  = apply_filters('ticinoweb_seo_twitter_description', $final_desc);

        echo '<meta name="twitter:card" content="summary_large_image" />' . "\n";
        if ($twitter_user) {
            $twitter_user = ltrim($twitter_user, '@');
            echo '<meta name="twitter:site" content="@' . esc_attr($twitter_user) . '" />' . "\n";
        }
        echo '<meta name="twitter:title" content="' . esc_attr($tw_title) . '" />' . "\n";
        echo '<meta name="twitter:description" content="' . esc_attr($tw_desc) . '" />' . "\n";
        if ($og_img) {
            echo '<meta name="twitter:image" content="' . esc_url($og_img) . '" />' . "\n";
        }
    }
}

/**
 * Filter document title with separator
 */
add_filter('document_title_separator', 'tw_seo_title_separator');
function tw_seo_title_separator($sep) {
    $custom_sep = get_option('tw_seo_separator');
    return $custom_sep ? $custom_sep : $sep;
}

/**
 * Filter document title parts to inject Custom Home Title
 * Fix: hook was defined but never registered — added add_filter() call.
 */
add_filter('document_title_parts', 'tw_seo_filter_title_parts');
function tw_seo_filter_title_parts($title) {
    if (is_front_page()) {
        $home_title = get_option('tw_seo_home_title');
        if ($home_title) {
            $title['title'] = function_exists('ticinoweb_frontend_text') ? ticinoweb_frontend_text($home_title, 'theme:seo:home_title') : $home_title;
            // Clear tagline if home title is set to avoid duplication
            unset($title['tagline']);
            unset($title['site']);
        }
    } elseif (is_singular()) {
        $custom_title = get_post_meta(get_the_ID(), '_tw_seo_title', true);
        if ($custom_title) {
             $title['title'] = function_exists('ticinoweb_frontend_text') ? ticinoweb_frontend_text($custom_title, 'theme:seo:post_title') : $custom_title;
             unset($title['tagline']);
             unset($title['site']);
        } else {
            // Intelligent fallback for runtime title if no meta title is set
            $auto = tw_seo_get_auto_metadata(get_post());
            if ($auto['title']) {
                $title['title'] = str_replace(' ' . get_option('tw_seo_separator', '|') . ' ' . get_bloginfo('name'), '', $auto['title']);
            }
        }
    } elseif (is_category() || is_tag() || is_tax()) {
        $term = get_queried_object();
        $custom_title = get_term_meta($term->term_id, '_tw_seo_title', true);
        if ($custom_title) {
             $title['title'] = function_exists('ticinoweb_frontend_text') ? ticinoweb_frontend_text($custom_title, 'theme:seo:term_title') : $custom_title;
             unset($title['tagline']);
             unset($title['site']);
        }
    }

    /**
     * Filter document title parts.
     *
     * @param array $title Title parts array.
     */
    return apply_filters('ticinoweb_seo_document_title_parts', $title);
}

/**
 * Intelligent Metadata Generator
 */
function tw_seo_get_auto_metadata($post) {
    if (!$post) return array('title' => '', 'description' => '');

    $sep = get_option('tw_seo_separator', '|');
    $site_name = get_bloginfo('name');

    // Generate Title
    $title = $post->post_title . ' ' . $sep . ' ' . $site_name;

    // Generate Description
    $description = '';
    if (has_excerpt($post->ID)) {
        $description = wp_strip_all_tags(get_the_excerpt($post->ID));
    } else {
        // Strip shortcodes and HTML from content
        $content = strip_shortcodes($post->post_content);
        $content = wp_strip_all_tags($content);
        $description = wp_trim_words($content, 25, ''); // ~160 chars
    }

    return array(
        'title'       => $title,
        'description' => $description
    );
}

/**
 * Schema.org JSON-LD in Footer
 */
add_action('wp_footer', 'tw_seo_inject_schema');
function tw_seo_inject_schema() {
    if (!is_front_page() && !is_single()) return;
    if (get_option('tw_seo_enable_schema', '1') !== '1') return;

    if (is_front_page()) {
        $org_name = get_option('tw_seo_org_name', get_bloginfo('name'));
        if (function_exists('ticinoweb_frontend_text')) {
            $org_name = ticinoweb_frontend_text($org_name, 'theme:seo:schema_org_name');
        }
        $org_logo = tw_seo_get_org_logo();
        $schema_type = get_option('tw_seo_schema_type', 'Organization');
        $socials_raw = get_option('tw_seo_org_social');
        $socials = array_filter(array_map('trim', explode("\n", $socials_raw)));
        $home_url = function_exists('ticinoweb_frontend_url') ? ticinoweb_frontend_url(home_url('/'), 'theme:url:home') : home_url('/');

        $schema = array(
            '@context' => 'https://schema.org',
            '@type' => $schema_type,
            'name' => $org_name,
            'url' => $home_url,
        );

        if ($org_logo) {
            $schema['logo'] = $org_logo;
            $schema['image'] = $org_logo;
        }

        if ($schema_type === 'LocalBusiness') {
            $phone = get_option('tw_seo_business_phone');
            $address = get_option('tw_seo_business_address');
            if (function_exists('ticinoweb_frontend_text') && $address) {
                $address = ticinoweb_frontend_text($address, 'theme:contact:address');
            }
            if ($phone) $schema['telephone'] = $phone;
            if ($address) $schema['address'] = array(
                '@type' => 'PostalAddress',
                'streetAddress' => $address
            );
        }

        if (!empty($socials)) {
            $schema['sameAs'] = $socials;
        }

        /**
         * Filter Organization / LocalBusiness JSON-LD Schema.
         *
         * @param array $schema Schema data array.
         */
        $schema = apply_filters('ticinoweb_seo_jsonld_org_schema', $schema);

        echo '<script type="application/ld+json">' . json_encode($schema, JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT) . '</script>' . "\n";

        // Website Search Schema
        $search_schema = array(
            '@context' => 'https://schema.org',
            '@type' => 'WebSite',
            'url' => $home_url,
            'potentialAction' => array(
                '@type' => 'SearchAction',
                'target' => home_url('/?s={search_term_string}'),
                'query-input' => 'required name=search_term_string'
            )
        );

        /**
         * Filter WebSite SearchAction JSON-LD Schema.
         *
         * @param array $search_schema Search schema array.
         */
        $search_schema = apply_filters('ticinoweb_seo_jsonld_search_schema', $search_schema);

        echo '<script type="application/ld+json">' . json_encode($search_schema, JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT) . '</script>' . "\n";
    }

    if (is_single()) {
        $post = get_post();
        $auto = tw_seo_get_auto_metadata($post);
        $headline = get_post_meta($post->ID, '_tw_seo_title', true) ?: $auto['title'];
        if (function_exists('ticinoweb_frontend_text')) {
            $headline = ticinoweb_frontend_text($headline, "post:{$post->ID}:title");
        }
        $article_schema = array(
            '@context' => 'https://schema.org',
            '@type' => 'Article',
            'headline' => $headline,
            'image' => has_post_thumbnail($post) ? array(get_the_post_thumbnail_url($post, 'full')) : array(),
            'datePublished' => get_the_time('c', $post),
            'dateModified' => get_the_modified_date('c', $post),
            'author' => array(
                '@type' => 'Person',
                'name' => get_the_author_meta('display_name', $post->post_author)
            )
        );

        /**
         * Filter Article JSON-LD Schema.
         *
         * @param array   $article_schema Article schema array.
         * @param WP_Post $post           Current post object.
         */
        $article_schema = apply_filters('ticinoweb_seo_jsonld_article_schema', $article_schema, $post);

        echo '<script type="application/ld+json">' . json_encode($article_schema, JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT) . '</script>' . "\n";
    }
}

/**
 * Breadcrumbs Function for Child Themes
 */
function ticinoweb_get_breadcrumbs() {
    if (is_front_page()) return '';

    $home_url = function_exists('ticinoweb_frontend_url') ? ticinoweb_frontend_url(home_url('/'), 'theme:url:home') : home_url('/');
    $home_name = function_exists('ticinoweb_frontend_text') ? ticinoweb_frontend_text(__('Home', 'ticinoweb-ai-theme'), 'theme:breadcrumb:home') : __('Home', 'ticinoweb-ai-theme');

    $items = array();
    $items[] = array('name' => $home_name, 'url' => $home_url);

    if (is_singular()) {
        $post = get_post();
        $title = get_the_title();
        $url = get_permalink();
        if (function_exists('ticinoweb_frontend_url')) {
            $url = ticinoweb_frontend_url($url, "post:{$post->ID}:url");
        }
        if (function_exists('ticinoweb_frontend_text')) {
            $title = ticinoweb_frontend_text($title, "post:{$post->ID}:title");
        }
        $items[] = array('name' => $title, 'url' => $url);
    } elseif (is_category() || is_tag() || is_tax()) {
        $term_name = single_term_title('', false);
        if (function_exists('ticinoweb_frontend_text')) {
            $term_name = ticinoweb_frontend_text($term_name, 'theme:breadcrumb:term');
        }
        $items[] = array('name' => $term_name, 'url' => '');
    } elseif (is_search()) {
        $search_name = function_exists('ticinoweb_frontend_text') ? ticinoweb_frontend_text(__('Ricerca', 'ticinoweb-ai-theme'), 'theme:breadcrumb:search') : __('Ricerca', 'ticinoweb-ai-theme');
        $items[] = array('name' => $search_name, 'url' => '');
    }

    /**
     * Filter breadcrumb items before rendering.
     *
     * @param array $items Array of breadcrumb item arrays (['name' => ..., 'url' => ...]).
     */
    $items = apply_filters('ticinoweb_seo_breadcrumb_items', $items);

    if (empty($items)) {
        return '';
    }

    $html = '<nav class="tw-breadcrumbs" aria-label="breadcrumb">';
    $html .= '<ol class="tw-breadcrumbs-list" itemscope itemtype="https://schema.org/BreadcrumbList">';
    
    foreach ($items as $index => $item) {
        $pos = $index + 1;
        $html .= '<li class="tw-breadcrumb-item" itemprop="itemListElement" itemscope itemtype="https://schema.org/ListItem">';
        if (!empty($item['url']) && $pos < count($items)) {
            $html .= '<a itemprop="item" href="' . esc_url($item['url']) . '"><span itemprop="name">' . esc_html($item['name']) . '</span></a>';
        } else {
            $html .= '<span itemprop="name">' . esc_html($item['name']) . '</span>';
        }
        $html .= '<meta itemprop="position" content="' . $pos . '" />';
        $html .= '</li>';
    }

    $html .= '</ol></nav>';
    
    // Add default styles for breadcrumbs
    $html .= '<style>
        .tw-breadcrumbs { margin-bottom: 20px; font-size: 14px; color: #64748b; }
        .tw-breadcrumbs-list { list-style: none; padding: 0; display: flex; gap: 10px; flex-wrap: wrap; }
        .tw-breadcrumb-item:not(:last-child)::after { content: "/"; margin-left: 10px; opacity: 0.5; }
        .tw-breadcrumb-item a { color: #4f46e5; text-decoration: none; transition: color 0.2s; }
        .tw-breadcrumb-item a:hover { color: #4338ca; text-decoration: underline; }
        .tw-breadcrumb-item span { font-weight: 500; }
    </style>';
    
    return $html;
}
add_shortcode('ticinoweb_breadcrumbs', 'ticinoweb_get_breadcrumbs');

/**
 * Sitemap Exclusions
 */
add_filter('wp_sitemaps_post_types', 'tw_seo_filter_sitemap_types');
function tw_seo_filter_sitemap_types($post_types) {
    $excludes = get_option('tw_seo_exclude_sitemap', array());
    foreach ($excludes as $type) {
        unset($post_types[$type]);
    }
    return $post_types;
}

/**
 * Keep noindex content out of the core sitemap.
 *
 * Whatever carries a `_tw_seo_robots` meta containing "noindex" must not be
 * advertised in the sitemap: listing a page we then ask Google not to index
 * sends contradictory signals. Posts without the meta are untouched, so sites
 * that never used the SEO metabox keep exactly the sitemap they had.
 *
 * @param array  $args      Query args used to build the sitemap page.
 * @param string $post_type Post type being listed.
 * @return array
 */
add_filter('wp_sitemaps_posts_query_args', 'tw_seo_exclude_noindex_from_sitemap', 10, 2);
function tw_seo_exclude_noindex_from_sitemap($args, $post_type) {
    $meta_query = isset($args['meta_query']) && is_array($args['meta_query']) ? $args['meta_query'] : array();

    $meta_query[] = array(
        'relation' => 'OR',
        array(
            'key'     => '_tw_seo_robots',
            'compare' => 'NOT EXISTS',
        ),
        array(
            'key'     => '_tw_seo_robots',
            'value'   => 'noindex',
            'compare' => 'NOT LIKE',
        ),
    );

    $args['meta_query'] = $meta_query;
    return $args;
}

/**
 * ID of the page representing the current post type archive, if any.
 *
 * Covers the WooCommerce shop page and any post type whose archive is backed
 * by a real page, so archive requests can reuse that page's SEO metadata.
 *
 * @return int 0 when the current request is not a supported archive.
 */
function tw_seo_get_archive_page_id() {
    if (function_exists('is_shop') && is_shop()) {
        $shop_id = (int) get_option('woocommerce_shop_page_id');
        return $shop_id > 0 ? $shop_id : 0;
    }

    if (is_home() && ! is_front_page()) {
        return (int) get_option('page_for_posts');
    }

    return 0;
}

/**
 * Per-Page SEO Metabox
 */
add_action('add_meta_boxes', 'tw_seo_add_metabox');
function tw_seo_add_metabox() {
    $enabled_types = get_option('tw_seo_enable_metabox', array());
    if (empty($enabled_types)) return;

    foreach ($enabled_types as $screen) {
        add_meta_box(
            'tw_seo_editor_box',
            __('Impostazioni SEO', 'ticinoweb-ai-theme'),
            'tw_seo_render_metabox',
            $screen,
            'normal',
            'high'
        );
    }
}

function tw_seo_render_metabox($post) {
    $seo_title = get_post_meta($post->ID, '_tw_seo_title', true);
    $seo_desc = get_post_meta($post->ID, '_tw_seo_description', true);
    $seo_robots = get_post_meta($post->ID, '_tw_seo_robots', true);
    wp_nonce_field('tw_seo_metabox_nonce', 'tw_seo_nonce');
    ?>
    <style>
        .tw-seo-metabox { font-family: 'Inter', sans-serif; padding: 10px; }
        .tw-seo-preview { 
            background: #fff; border: 1px solid #e2e8f0; border-radius: 12px; padding: 20px; margin-bottom: 25px;
            max-width: 600px; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05);
        }
        .tw-preview-title { color: #1a0dab; font-size: 20px; font-weight: 400; margin-bottom: 3px; display: block; overflow: hidden; white-space: nowrap; text-overflow: ellipsis; }
        .tw-preview-url { color: #006621; font-size: 14px; margin-bottom: 5px; display: block; }
        .tw-preview-desc { color: #545454; font-size: 14px; line-height: 1.5; }
        
        .tw-metabox-field { margin-bottom: 20px; }
        .tw-metabox-label { display: block; font-weight: 600; margin-bottom: 8px; color: #1e293b; }
        .tw-metabox-input { width: 100%; padding: 10px; border-radius: 8px; border: 1px solid #cbd5e1; }
        .tw-metabox-help { font-size: 12px; color: #64748b; margin-top: 5px; }
    </style>
    
    <div class="tw-seo-metabox">
        <div class="tw-seo-preview">
            <span class="tw-preview-title" id="tw-preview-title-el"><?php echo $seo_title ? esc_html($seo_title) : esc_html($post->post_title); ?></span>
            <span class="tw-preview-url"><?php echo esc_url(get_permalink($post->ID)); ?></span>
            <p class="tw-preview-desc" id="tw-preview-desc-el"><?php echo $seo_desc ? esc_html($seo_desc) : __('Aggiungi una descrizione per vedere l\'anteprima qui...', 'ticinoweb-ai-theme'); ?></p>
        </div>

        <div class="tw-metabox-field">
            <label class="tw-metabox-label"><?php _e('Titolo SEO Personalizzato', 'ticinoweb-ai-theme'); ?></label>
            <input type="text" name="tw_seo_title" id="tw_seo_title_field" value="<?php echo esc_attr($seo_title); ?>" class="tw-metabox-input" maxlength="70">
            <p class="tw-metabox-help">
                <span id="tw-title-count">0</span>/70 <?php _e('caratteri.', 'ticinoweb-ai-theme'); ?> 
                <?php _e('Se vuoto, verrà usato il titolo della pagina.', 'ticinoweb-ai-theme'); ?>
            </p>
        </div>

        <div class="tw-metabox-field">
            <label class="tw-metabox-label"><?php _e('Descrizione SEO Personalizzata', 'ticinoweb-ai-theme'); ?></label>
            <textarea name="tw_seo_description_metabox" id="tw_seo_desc_field" rows="3" class="tw-metabox-input" maxlength="160"><?php echo esc_textarea($seo_desc); ?></textarea>
            <p class="tw-metabox-help">
                <span id="tw-desc-count">0</span>/160 <?php _e('caratteri.', 'ticinoweb-ai-theme'); ?> 
                <?php _e('Idealmente tra 150-160.', 'ticinoweb-ai-theme'); ?>
            </p>
        </div>

        <div class="tw-metabox-field">
            <label class="tw-metabox-label"><?php _e('Robots Meta', 'ticinoweb-ai-theme'); ?></label>
            <select name="tw_seo_robots" class="tw-metabox-input">
                <option value="index, follow" <?php selected($seo_robots, 'index, follow'); ?>><?php _e('Standard (Index, Follow)', 'ticinoweb-ai-theme'); ?></option>
                <option value="noindex, follow" <?php selected($seo_robots, 'noindex, follow'); ?>><?php _e('Nascondi (Noindex, Follow)', 'ticinoweb-ai-theme'); ?></option>
                <option value="noindex, nofollow" <?php selected($seo_robots, 'noindex, nofollow'); ?>><?php _e('Nascosto Totale (Noindex, Nofollow)', 'ticinoweb-ai-theme'); ?></option>
            </select>
        </div>
    </div>

    <script>
    jQuery(document).ready(function($) {
        function updateCounts() {
            var titleLen = $('#tw_seo_title_field').val().length;
            var descLen = $('#tw_seo_desc_field').val().length;
            $('#tw-title-count').text(titleLen).css('color', titleLen > 60 ? '#e53e3e' : '#64748b');
            $('#tw-desc-count').text(descLen).css('color', (descLen > 140 && descLen <= 160) ? '#10b981' : (descLen > 160 ? '#e53e3e' : '#64748b'));
        }

        $('#tw_seo_title_field').on('keyup', function() {
            var val = $(this).val() || <?php echo json_encode($post->post_title); ?>;
            $('#tw-preview-title-el').text(val);
            updateCounts();
        });
        $('#tw_seo_desc_field').on('keyup', function() {
            var val = $(this).val() || '...';
            $('#tw-preview-desc-el').text(val);
            updateCounts();
        });
        
        updateCounts();
    });
    </script>
    <?php
}

add_action('save_post', 'tw_seo_save_metabox_data');
function tw_seo_save_metabox_data($post_id) {
    if (!isset($_POST['tw_seo_nonce']) || !wp_verify_nonce($_POST['tw_seo_nonce'], 'tw_seo_metabox_nonce')) return;
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
    if (!current_user_can('edit_post', $post_id)) return;

    $title = isset($_POST['tw_seo_title']) ? sanitize_text_field($_POST['tw_seo_title']) : '';
    $desc = isset($_POST['tw_seo_description_metabox']) ? sanitize_text_field($_POST['tw_seo_description_metabox']) : '';
    $robots = isset($_POST['tw_seo_robots']) ? sanitize_text_field($_POST['tw_seo_robots']) : 'index, follow';

    // Automated Filling if empty
    if (empty($title) || empty($desc)) {
        $post = get_post($post_id);
        $auto = tw_seo_get_auto_metadata($post);
        if (empty($title)) $title = $auto['title'];
        if (empty($desc)) $desc = $auto['description'];
    }

    update_post_meta($post_id, '_tw_seo_title', $title);
    update_post_meta($post_id, '_tw_seo_description', $desc);
    update_post_meta($post_id, '_tw_seo_robots', $robots);
}

/**
 * Google Analytics Conditional Loader
 */
add_action('wp_head', 'tw_seo_google_analytics_render', 5);
function tw_seo_google_analytics_render() {
    if (is_admin()) return;
    
    $ga_id = get_option('tw_google_analytics_id');
    if (empty($ga_id)) return;
    
    // Consent is deliberately NOT read from $_COOKIE here. This output must be identical
    // for every visitor so a full-page cache (LiteSpeed) can store one copy per URL. If the
    // decision were made in PHP, a page cached for a consenting visitor would auto-fire GA
    // for everyone served that copy — including users who declined. Decided in JS instead.
    ?>
    <script>
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    window.twLoadGA = function() {
        if(window.twGaLoaded) return;
        var script = document.createElement('script');
        script.async = true;
        script.src = "https://www.googletagmanager.com/gtag/js?id=<?php echo esc_js($ga_id); ?>";
        document.head.appendChild(script);
        gtag('js', new Date());
        gtag('config', '<?php echo esc_js($ga_id); ?>', { 'anonymize_ip': true });
        window.twGaLoaded = true;
    };
    (function() {
        function twReadCookie(name) {
            var m = document.cookie.match('(?:^|; )' + name.replace(/([.*+?^${}()|[\]\\])/g, '\\$1') + '=([^;]*)');
            return m ? decodeURIComponent(m[1]) : null;
        }
        // Auto-load only if this visitor previously consented to analytics.
        var consent = twReadCookie('tw_cookie_consent');
        var allowed = (consent === 'accepted');
        if (consent === 'custom') {
            try {
                allowed = !!JSON.parse(twReadCookie('tw_cookie_preferences') || '{}').analytics;
            } catch (e) {
                allowed = false;
            }
        }
        if (allowed) twLoadGA();
    })();
    </script>
    <?php
}

/**
 * Frontend Cookie Banner Render (Liquid Glass)
 */
add_action('wp_footer', 'tw_seo_cookie_banner_render', 100);
function tw_seo_cookie_banner_render() {
    if (is_admin()) return;
    if (!get_option('tw_cookie_banner_enable')) return;
    // Consent is NOT checked here on purpose. The markup is rendered for every visitor so the
    // page HTML stays identical and a full-page cache (LiteSpeed) can serve one copy safely.
    // Gating this in PHP meant whichever variant was cached first was served to everyone:
    // primed by a consenting visitor, the banner vanished for new visitors entirely.
    // Whether the banner is actually shown is decided in JS below, from the cookie.

    $privacy_url = get_option('tw_privacy_policy_url');
    $primary_color = function_exists('ticinoweb_get_brand_primary_color') ? ticinoweb_get_brand_primary_color() : '#4f46e5';
    
    $lang = substr(get_locale(), 0, 2);
    
    $active = array(
        'text' => __('Utilizziamo i cookie per offrirti la migliore esperienza sul nostro sito web e per analizzare il traffico.', 'ticinoweb-ai-theme'),
        'policy' => __('Leggi la Privacy Policy per saperne di più.', 'ticinoweb-ai-theme'),
        'decline' => __('Rifiuta', 'ticinoweb-ai-theme'),
        'accept' => __('Accetta tutto', 'ticinoweb-ai-theme'),
        'customize' => __('Personalizza', 'ticinoweb-ai-theme'),
        'modal_title' => __('Centro Preferenze Cookie', 'ticinoweb-ai-theme'),
        'modal_desc' => __('Scegli quali categorie di cookie desideri autorizzare. I cookie necessari sono indispensabili per il corretto funzionamento del sito.', 'ticinoweb-ai-theme'),
        'opt_necessary_title' => __('Cookie Necessari', 'ticinoweb-ai-theme'),
        'opt_necessary_desc' => __('Indispensabili per consentire la navigazione e fornire le funzionalità di base. Non possono essere disattivati.', 'ticinoweb-ai-theme'),
        'opt_analytics_title' => __('Cookie Statistici e Analitici', 'ticinoweb-ai-theme'),
        'opt_analytics_desc' => __('Ci consentono di misurare il traffico del sito in modo anonimo per migliorare le performance e l\'esperienza d\'uso.', 'ticinoweb-ai-theme'),
        'opt_marketing_title' => __('Cookie di Marketing e Profilazione', 'ticinoweb-ai-theme'),
        'opt_marketing_desc' => __('Utilizzati per mostrare annunci pertinenti o tracciare le conversioni pubblicitarie sui social media e motori di ricerca.', 'ticinoweb-ai-theme'),
        'save_necessary_btn' => __('Solo Necessari', 'ticinoweb-ai-theme'),
        'save_preferences_btn' => __('Salva Selezione', 'ticinoweb-ai-theme')
    );

    if ($lang === 'en') {
        $active = array(
            'text' => __('We use cookies to offer you the best experience on our website and to analyze traffic.', 'ticinoweb-ai-theme'),
            'policy' => __('Read the Privacy Policy to learn more.', 'ticinoweb-ai-theme'),
            'decline' => __('Decline', 'ticinoweb-ai-theme'),
            'accept' => __('Accept All', 'ticinoweb-ai-theme'),
            'customize' => __('Customize', 'ticinoweb-ai-theme'),
            'modal_title' => __('Cookie Preference Center', 'ticinoweb-ai-theme'),
            'modal_desc' => __('Choose which categories of cookies you wish to authorize. Necessary cookies are essential for the proper functioning of the website.', 'ticinoweb-ai-theme'),
            'opt_necessary_title' => __('Necessary Cookies', 'ticinoweb-ai-theme'),
            'opt_necessary_desc' => __('Essential to enable navigation and provide basic core functionalities. Cannot be disabled.', 'ticinoweb-ai-theme'),
            'opt_analytics_title' => __('Statistical & Analytical Cookies', 'ticinoweb-ai-theme'),
            'opt_analytics_desc' => __('Allow us to measure website traffic anonymously to improve overall performance and user experience.', 'ticinoweb-ai-theme'),
            'opt_marketing_title' => __('Marketing & Targeting Cookies', 'ticinoweb-ai-theme'),
            'opt_marketing_desc' => __('Used to display relevant advertisements or track advertising conversions across social media and search engines.', 'ticinoweb-ai-theme'),
            'save_necessary_btn' => __('Only Necessary', 'ticinoweb-ai-theme'),
            'save_preferences_btn' => __('Save Selection', 'ticinoweb-ai-theme')
        );
    } elseif ($lang === 'fr') {
        $active = array(
            'text' => __('Nous utilisons des cookies pour vous offrir la meilleure expérience sur notre site web et pour analyser le trafic.', 'ticinoweb-ai-theme'),
            'policy' => __('Lisez la politique de confidentialité pour en savoir plus.', 'ticinoweb-ai-theme'),
            'decline' => __('Refuser', 'ticinoweb-ai-theme'),
            'accept' => __('Tout Accepter', 'ticinoweb-ai-theme'),
            'customize' => __('Personnaliser', 'ticinoweb-ai-theme'),
            'modal_title' => __('Centre de Préférences de Cookies', 'ticinoweb-ai-theme'),
            'modal_desc' => __('Choisissez les catégories de cookies que vous souhaitez autoriser. Les cookies nécessaires sont essentiels au bon fonctionnement du site.', 'ticinoweb-ai-theme'),
            'opt_necessary_title' => __('Cookies Nécessaires', 'ticinoweb-ai-theme'),
            'opt_necessary_desc' => __('Essentiels pour permettre la navigation et fournir les fonctionnalités de base. Ne peuvent pas être désactivés.', 'ticinoweb-ai-theme'),
            'opt_analytics_title' => __('Cookies Statistiques et Analytiques', 'ticinoweb-ai-theme'),
            'opt_analytics_desc' => __('Nous permettent de mesurer le trafic du site de manière anonyme pour améliorer les performances.', 'ticinoweb-ai-theme'),
            'opt_marketing_title' => __('Cookies de Marketing et Ciblage', 'ticinoweb-ai-theme'),
            'opt_marketing_desc' => __('Utilisés pour afficher des publicités pertinentes ou suivre le succès des campagnes.', 'ticinoweb-ai-theme'),
            'save_necessary_btn' => __('Uniquement Nécessaires', 'ticinoweb-ai-theme'),
            'save_preferences_btn' => __('Enregistrer la Sélection', 'ticinoweb-ai-theme')
        );
    } elseif ($lang === 'de') {
        $active = array(
            'text' => __('Wir verwenden Cookies, um Ihnen die beste Erfahrung auf unserer Website zu bieten und den Datenverkehr zu analysieren.', 'ticinoweb-ai-theme'),
            'policy' => __('Lesen Sie die Datenschutzerklärung, um mehr zu erfahren.', 'ticinoweb-ai-theme'),
            'decline' => __('Ablehnen', 'ticinoweb-ai-theme'),
            'accept' => __('Alle Akzeptieren', 'ticinoweb-ai-theme'),
            'customize' => __('Anpassen', 'ticinoweb-ai-theme'),
            'modal_title' => __('Cookie-Einstellungszentrum', 'ticinoweb-ai-theme'),
            'modal_desc' => __('Wählen Sie aus, welche Kategorien von Cookies Sie zulassen möchten. Notwendige Cookies sind für die Funktion der Website unerlässlich.', 'ticinoweb-ai-theme'),
            'opt_necessary_title' => __('Notwendige Cookies', 'ticinoweb-ai-theme'),
            'opt_necessary_desc' => __('Unerlässlich für die Navigation und grundlegende Kernfunktionen der Website. Können nicht deaktiviert werden.', 'ticinoweb-ai-theme'),
            'opt_analytics_title' => __('Statistik- und Analyse-Cookies', 'ticinoweb-ai-theme'),
            'opt_analytics_desc' => __('Ermöglichen es uns, den Website-Verkehr anonym zu messen, um die Leistung zu verbessern.', 'ticinoweb-ai-theme'),
            'opt_marketing_title' => __('Marketing- und Werbe-Cookies', 'ticinoweb-ai-theme'),
            'opt_marketing_desc' => __('Wird verwendet, um relevante Werbung anzuzeigen oder den Erfolg von Kampagnen zu verfolgen.', 'ticinoweb-ai-theme'),
            'save_necessary_btn' => __('Nur Notwendige', 'ticinoweb-ai-theme'),
            'save_preferences_btn' => __('Auswahl Speichern', 'ticinoweb-ai-theme')
        );
    }
    ?>
    <style>
        :root {
            --tw-cookie-primary: <?php echo esc_html($primary_color); ?>;
        }
        .tw-cookie-banner {
            position: fixed;
            bottom: 20px;
            left: 50%;
            transform: translateX(-50%) translateY(150px);
            width: 90%;
            max-width: 650px;
            background: rgba(255, 255, 255, 0.88);
            backdrop-filter: blur(16px);
            -webkit-backdrop-filter: blur(16px);
            border: 1px solid rgba(255, 255, 255, 0.5);
            border-radius: 20px;
            box-shadow: 0 12px 40px rgba(0, 0, 0, 0.08), 0 4px 12px rgba(0,0,0,0.03);
            padding: 24px 28px;
            z-index: 999999;
            font-family: inherit;
            display: flex;
            flex-direction: column;
            gap: 16px;
            opacity: 0;
            /* Markup is now always present in the HTML (cache-safe), so the hidden state must
               not swallow clicks. visibility flips only after the fade-out finishes. */
            visibility: hidden;
            pointer-events: none;
            transition: opacity 0.6s cubic-bezier(0.16, 1, 0.3, 1),
                        transform 0.6s cubic-bezier(0.16, 1, 0.3, 1),
                        visibility 0s linear 0.6s;
        }
        .tw-cookie-banner.show {
            transform: translateX(-50%) translateY(0);
            opacity: 1;
            visibility: visible;
            pointer-events: auto;
            transition: opacity 0.6s cubic-bezier(0.16, 1, 0.3, 1),
                        transform 0.6s cubic-bezier(0.16, 1, 0.3, 1),
                        visibility 0s linear 0s;
        }
        .tw-cookie-text {
            font-size: 14.5px;
            line-height: 1.6;
            color: #334155;
            margin: 0;
            font-weight: 400;
            text-align: left;
        }
        .tw-cookie-text a {
            color: var(--tw-cookie-primary);
            text-decoration: underline;
            font-weight: 600;
        }
        .tw-cookie-actions {
            display: flex;
            gap: 10px;
            justify-content: flex-end;
            align-items: center;
        }
        .tw-cookie-btn {
            border: none;
            padding: 10px 20px;
            border-radius: 10px;
            font-weight: 600;
            font-size: 14px;
            cursor: pointer;
            transition: all 0.25s ease;
            outline: none;
            display: inline-flex;
            align-items: center;
            justify-content: center;
        }
        .tw-cookie-btn-decline {
            background: rgba(0, 0, 0, 0.05);
            color: #64748b;
        }
        .tw-cookie-btn-decline:hover {
            background: rgba(0, 0, 0, 0.08);
            color: #1e293b;
        }
        .tw-cookie-btn-customize {
            background: rgba(255, 255, 255, 0.8);
            border: 1px solid rgba(0, 0, 0, 0.1);
            color: #475569;
        }
        .tw-cookie-btn-customize:hover {
            background: #fff;
            border-color: rgba(0, 0, 0, 0.15);
            color: #0f172a;
            box-shadow: 0 2px 6px rgba(0,0,0,0.03);
        }
        .tw-cookie-btn-accept {
            background: var(--tw-cookie-primary);
            color: #fff;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
        }
        .tw-cookie-btn-accept:hover {
            filter: brightness(0.9);
            transform: translateY(-1.5px);
        }
        
        /* Preferences Modal (Glassmorphism Overlay) */
        .tw-cookie-modal {
            position: fixed;
            inset: 0;
            z-index: 9999999;
            display: flex;
            align-items: center;
            justify-content: center;
            opacity: 0;
            pointer-events: none;
            transition: opacity 0.4s ease;
            font-family: inherit;
        }
        .tw-cookie-modal.show {
            opacity: 1;
            pointer-events: auto;
        }
        .tw-cookie-modal-overlay {
            position: absolute;
            inset: 0;
            background: rgba(15, 23, 42, 0.35);
            backdrop-filter: blur(8px);
            -webkit-backdrop-filter: blur(8px);
        }
        .tw-cookie-modal-content {
            position: relative;
            z-index: 10;
            width: 90%;
            max-width: 550px;
            background: rgba(255, 255, 255, 0.95);
            border: 1px solid rgba(255, 255, 255, 0.6);
            border-radius: 24px;
            box-shadow: 0 20px 50px rgba(0, 0, 0, 0.15);
            padding: 30px;
            transform: scale(0.9);
            transition: transform 0.4s cubic-bezier(0.16, 1, 0.3, 1);
            display: flex;
            flex-direction: column;
            gap: 20px;
        }
        .tw-cookie-modal.show .tw-cookie-modal-content {
            transform: scale(1);
        }
        .tw-cookie-modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid #f1f5f9;
            padding-bottom: 15px;
        }
        .tw-cookie-modal-header h3 {
            margin: 0;
            font-size: 18px;
            font-weight: 700;
            color: #0f172a;
        }
        .tw-cookie-modal-close {
            background: none;
            border: none;
            font-size: 26px;
            color: #94a3b8;
            cursor: pointer;
            padding: 0 5px;
            line-height: 0.8;
            transition: color 0.2s;
        }
        .tw-cookie-modal-close:hover {
            color: #475569;
        }
        .tw-cookie-modal-body {
            max-height: 380px;
            overflow-y: auto;
            padding-right: 5px;
            display: flex;
            flex-direction: column;
            gap: 18px;
        }
        .tw-cookie-modal-body p {
            margin: 0;
            font-size: 14px;
            line-height: 1.6;
            color: #475569;
            margin-bottom: 5px;
            text-align: left;
        }
        .tw-cookie-option-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: #f8fafc;
            border: 1px solid #e2e8f0;
            border-radius: 14px;
            padding: 16px 18px;
            gap: 20px;
        }
        .tw-cookie-option-info {
            display: flex;
            flex-direction: column;
            gap: 4px;
            text-align: left;
        }
        .tw-cookie-option-info strong {
            font-size: 14px;
            color: #0f172a;
        }
        .tw-cookie-option-info span {
            font-size: 12px;
            line-height: 1.5;
            color: #64748b;
        }
        
        /* Modern Switch Slider */
        .tw-cookie-switch-label {
            position: relative;
            display: inline-block;
            width: 44px;
            height: 24px;
            flex-shrink: 0;
        }
        .tw-cookie-switch-label input {
            opacity: 0;
            width: 0;
            height: 0;
        }
        .tw-cookie-slider {
            position: absolute;
            cursor: pointer;
            inset: 0;
            background-color: #cbd5e1;
            transition: .3s;
            border-radius: 24px;
        }
        .tw-cookie-slider:before {
            position: absolute;
            content: "";
            height: 18px;
            width: 18px;
            left: 3px;
            bottom: 3px;
            background-color: white;
            transition: .3s;
            border-radius: 50%;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
        }
        .tw-cookie-switch-label input:checked + .tw-cookie-slider {
            background-color: var(--tw-cookie-primary);
        }
        .tw-cookie-switch-label input:focus + .tw-cookie-slider {
            box-shadow: 0 0 1px var(--tw-cookie-primary);
        }
        .tw-cookie-switch-label input:checked + .tw-cookie-slider:before {
            transform: translateX(20px);
        }
        .tw-cookie-switch-label input:disabled + .tw-cookie-slider {
            opacity: 0.5;
            cursor: not-allowed;
        }
        .tw-cookie-modal-footer {
            display: flex;
            justify-content: flex-end;
            gap: 10px;
            border-top: 1px solid #f1f5f9;
            padding-top: 15px;
        }
        
        /* Custom Scrollbar for Modal Body */
        .tw-cookie-modal-body::-webkit-scrollbar {
            width: 6px;
        }
        .tw-cookie-modal-body::-webkit-scrollbar-track {
            background: #f1f5f9;
            border-radius: 10px;
        }
        .tw-cookie-modal-body::-webkit-scrollbar-thumb {
            background: #cbd5e1;
            border-radius: 10px;
        }
        .tw-cookie-modal-body::-webkit-scrollbar-thumb:hover {
            background: #94a3b8;
        }
        
        @media(max-width: 580px) {
            .tw-cookie-banner { bottom: 10px; width: 95%; padding: 18px 20px; }
            .tw-cookie-actions { flex-direction: column; width: 100%; gap: 8px; }
            .tw-cookie-btn { width: 100%; text-align: center; }
            
            .tw-cookie-modal-content { padding: 20px; border-radius: 20px; }
            .tw-cookie-option-row { flex-direction: column; align-items: flex-start; gap: 12px; }
            .tw-cookie-switch-wrapper { align-self: flex-end; }
        }
    </style>
    
    <!-- Cookie Banner -->
    <div id="tw-cookie-banner" class="tw-cookie-banner">
        <p class="tw-cookie-text">
            <?php echo esc_html($active['text']); ?>
            <?php if ($privacy_url) : ?>
                <br><a href="<?php echo esc_url($privacy_url); ?>" target="_blank"><?php echo esc_html($active['policy']); ?></a>
            <?php endif; ?>
        </p>
        <div class="tw-cookie-actions">
            <button class="tw-cookie-btn tw-cookie-btn-decline" id="tw-cookie-decline"><?php echo esc_html($active['decline']); ?></button>
            <button class="tw-cookie-btn tw-cookie-btn-customize" id="tw-cookie-customize"><?php echo esc_html($active['customize']); ?></button>
            <button class="tw-cookie-btn tw-cookie-btn-accept" id="tw-cookie-accept"><?php echo esc_html($active['accept']); ?></button>
        </div>
    </div>

    <!-- GDPR Preferences Modal -->
    <div id="tw-cookie-modal" class="tw-cookie-modal">
        <div class="tw-cookie-modal-overlay" id="tw-cookie-modal-overlay"></div>
        <div class="tw-cookie-modal-content">
            <div class="tw-cookie-modal-header">
                <h3><?php echo esc_html($active['modal_title']); ?></h3>
                <button type="button" class="tw-cookie-modal-close" id="tw-cookie-modal-close">&times;</button>
            </div>
            <div class="tw-cookie-modal-body">
                <p><?php echo esc_html($active['modal_desc']); ?></p>
                
                <!-- Category 1: Necessary -->
                <div class="tw-cookie-option-row">
                    <div class="tw-cookie-option-info">
                        <strong id="tw-cookie-opt-necessary-label"><?php echo esc_html($active['opt_necessary_title']); ?></strong>
                        <span><?php echo esc_html($active['opt_necessary_desc']); ?></span>
                    </div>
                    <div class="tw-cookie-switch-wrapper">
                        <label class="tw-cookie-switch-label">
                            <input type="checkbox" checked disabled class="tw-cookie-switch" aria-labelledby="tw-cookie-opt-necessary-label">
                            <span class="tw-cookie-slider"></span>
                        </label>
                    </div>
                </div>
                
                <!-- Category 2: Analytics -->
                <div class="tw-cookie-option-row">
                    <div class="tw-cookie-option-info">
                        <strong id="tw-cookie-opt-analytics-label"><?php echo esc_html($active['opt_analytics_title']); ?></strong>
                        <span><?php echo esc_html($active['opt_analytics_desc']); ?></span>
                    </div>
                    <div class="tw-cookie-switch-wrapper">
                        <label class="tw-cookie-switch-label">
                            <input type="checkbox" id="tw-cookie-opt-analytics" checked class="tw-cookie-switch" aria-labelledby="tw-cookie-opt-analytics-label">
                            <span class="tw-cookie-slider"></span>
                        </label>
                    </div>
                </div>
                
                <!-- Category 3: Marketing -->
                <div class="tw-cookie-option-row">
                    <div class="tw-cookie-option-info">
                        <strong id="tw-cookie-opt-marketing-label"><?php echo esc_html($active['opt_marketing_title']); ?></strong>
                        <span><?php echo esc_html($active['opt_marketing_desc']); ?></span>
                    </div>
                    <div class="tw-cookie-switch-wrapper">
                        <label class="tw-cookie-switch-label">
                            <input type="checkbox" id="tw-cookie-opt-marketing" checked class="tw-cookie-switch" aria-labelledby="tw-cookie-opt-marketing-label">
                            <span class="tw-cookie-slider"></span>
                        </label>
                    </div>
                </div>
            </div>
            <div class="tw-cookie-modal-footer">
                <button class="tw-cookie-btn tw-cookie-btn-decline" id="tw-cookie-save-necessary"><?php echo esc_html($active['save_necessary_btn']); ?></button>
                <button class="tw-cookie-btn tw-cookie-btn-accept" id="tw-cookie-save-preferences"><?php echo esc_html($active['save_preferences_btn']); ?></button>
            </div>
        </div>
    </div>

    <script>
    document.addEventListener("DOMContentLoaded", function() {
        var banner = document.getElementById('tw-cookie-banner');
        var modal = document.getElementById('tw-cookie-modal');
        var overlay = document.getElementById('tw-cookie-modal-overlay');
        var closeBtn = document.getElementById('tw-cookie-modal-close');
        var customizeBtn = document.getElementById('tw-cookie-customize');
        
        if(!banner) return;

        function twReadCookie(name) {
            var m = document.cookie.match('(?:^|; )' + name.replace(/([.*+?^${}()|[\]\\])/g, '\\$1') + '=([^;]*)');
            return m ? decodeURIComponent(m[1]) : null;
        }

        // Consent is evaluated here rather than in PHP so the cached HTML is identical for
        // every visitor. If a choice was already made, drop the markup and stop.
        if (twReadCookie('tw_cookie_consent')) {
            banner.remove();
            if (modal) modal.remove();
            return;
        }

        // Show banner with slight delay
        setTimeout(function() { banner.classList.add('show'); }, 500);

        function setConsentCookie(consentValue, preferencesObj) {
            var date = new Date();
            date.setTime(date.getTime() + (365*24*60*60*1000));
            var expires = "; expires=" + date.toUTCString();
            
            document.cookie = "tw_cookie_consent=" + consentValue + expires + "; path=/; SameSite=Lax";
            if (preferencesObj) {
                document.cookie = "tw_cookie_preferences=" + encodeURIComponent(JSON.stringify(preferencesObj)) + expires + "; path=/; SameSite=Lax";
            } else {
                document.cookie = "tw_cookie_preferences=" + encodeURIComponent(JSON.stringify({ analytics: false, marketing: false })) + expires + "; path=/; SameSite=Lax";
            }
            
            // Hide banner and modal
            banner.classList.remove('show');
            if (modal) {
                modal.classList.remove('show');
            }
            setTimeout(function() {
                banner.remove();
                if (modal) modal.remove();
            }, 600);
        }

        // Accept All
        document.getElementById('tw-cookie-accept').addEventListener('click', function() {
            var allPref = { analytics: true, marketing: true };
            setConsentCookie('accepted', allPref);
            if(typeof window.twLoadGA === 'function') {
                window.twLoadGA();
            }
        });

        // Decline All
        document.getElementById('tw-cookie-decline').addEventListener('click', function() {
            setConsentCookie('declined', { analytics: false, marketing: false });
        });

        // Customize Preferences (Open Modal)
        if (customizeBtn && modal) {
            customizeBtn.addEventListener('click', function() {
                modal.classList.add('show');
            });
        }

        // Close Modal (x)
        if (closeBtn && modal) {
            closeBtn.addEventListener('click', function() {
                modal.classList.remove('show');
            });
        }

        // Close Modal (Overlay Click)
        if (overlay && modal) {
            overlay.addEventListener('click', function() {
                modal.classList.remove('show');
            });
        }

        // Save Only Necessary Cookies
        var saveNecessaryBtn = document.getElementById('tw-cookie-save-necessary');
        if (saveNecessaryBtn) {
            saveNecessaryBtn.addEventListener('click', function() {
                var necessaryPref = { analytics: false, marketing: false };
                setConsentCookie('custom', necessaryPref);
            });
        }

        // Save Selection
        var savePreferencesBtn = document.getElementById('tw-cookie-save-preferences');
        if (savePreferencesBtn) {
            savePreferencesBtn.addEventListener('click', function() {
                var analyticsOpt = document.getElementById('tw-cookie-opt-analytics');
                var marketingOpt = document.getElementById('tw-cookie-opt-marketing');
                
                var isAnalyticsAccepted = analyticsOpt ? analyticsOpt.checked : false;
                var isMarketingAccepted = marketingOpt ? marketingOpt.checked : false;
                
                var customPref = {
                    analytics: isAnalyticsAccepted,
                    marketing: isMarketingAccepted
                };
                
                setConsentCookie('custom', customPref);
                
                if (isAnalyticsAccepted && typeof window.twLoadGA === 'function') {
                    window.twLoadGA();
                }
            });
        }
    });
    </script>
    <?php
}

/**
 * Media SEO: Auto Alt Tags for missing images
 */
add_filter('wp_get_attachment_image_attributes', 'tw_seo_auto_alt_tags', 10, 3);
function tw_seo_auto_alt_tags($attr, $attachment, $size) {
    if (empty($attr['alt'])) {
        $attr['alt'] = trim(strip_tags(get_the_title($attachment->ID)));
    }
    return $attr;
}

/**
 * Taxonomy SEO: Add fields to Categories and Tags
 */
add_action('category_add_form_fields', 'tw_seo_add_taxonomy_fields');
add_action('post_tag_add_form_fields', 'tw_seo_add_taxonomy_fields');
function tw_seo_add_taxonomy_fields($taxonomy) {
    ?>
    <div class="form-field term-group">
        <label for="_tw_seo_title"><?php _e('Titolo SEO Personalizzato', 'ticinoweb-ai-theme'); ?></label>
        <input type="text" name="_tw_seo_title" id="_tw_seo_title" value="">
        <p><?php _e('Lascia vuoto per usare il nome standard della categoria/tag.', 'ticinoweb-ai-theme'); ?></p>
    </div>
    <div class="form-field term-group">
        <label for="_tw_seo_description"><?php _e('Descrizione SEO Personalizzata', 'ticinoweb-ai-theme'); ?></label>
        <textarea name="_tw_seo_description" id="_tw_seo_description" rows="3"></textarea>
        <p><?php _e('Ideale intorno ai 150-160 caratteri. Se vuota, usa la descrizione standard.', 'ticinoweb-ai-theme'); ?></p>
    </div>
    <?php
}

add_action('category_edit_form_fields', 'tw_seo_edit_taxonomy_fields', 10, 2);
add_action('post_tag_edit_form_fields', 'tw_seo_edit_taxonomy_fields', 10, 2);
function tw_seo_edit_taxonomy_fields($term, $taxonomy) {
    $seo_title = get_term_meta($term->term_id, '_tw_seo_title', true);
    $seo_desc = get_term_meta($term->term_id, '_tw_seo_description', true);
    ?>
    <tr class="form-field term-group-wrap">
        <th scope="row"><label for="_tw_seo_title"><?php _e('Titolo SEO', 'ticinoweb-ai-theme'); ?></label></th>
        <td><input type="text" name="_tw_seo_title" id="_tw_seo_title" value="<?php echo esc_attr($seo_title); ?>"><p class="description"><?php _e('Sovrascrive il titolo standard per Google.', 'ticinoweb-ai-theme'); ?></p></td>
    </tr>
    <tr class="form-field term-group-wrap">
        <th scope="row"><label for="_tw_seo_description"><?php _e('Descrizione SEO', 'ticinoweb-ai-theme'); ?></label></th>
        <td><textarea name="_tw_seo_description" id="_tw_seo_description" rows="3"><?php echo esc_textarea($seo_desc); ?></textarea><p class="description"><?php _e('Sovrascrive la descrizione automatica per Google.', 'ticinoweb-ai-theme'); ?></p></td>
    </tr>
    <?php
}

add_action('created_category', 'tw_seo_save_taxonomy_fields', 10, 2);
add_action('created_post_tag', 'tw_seo_save_taxonomy_fields', 10, 2);
add_action('edited_category', 'tw_seo_save_taxonomy_fields', 10, 2);
add_action('edited_post_tag', 'tw_seo_save_taxonomy_fields', 10, 2);
function tw_seo_save_taxonomy_fields($term_id, $tt_id) {
    if (isset($_POST['_tw_seo_title'])) {
        update_term_meta($term_id, '_tw_seo_title', sanitize_text_field($_POST['_tw_seo_title']));
    }
    if (isset($_POST['_tw_seo_description'])) {
        update_term_meta($term_id, '_tw_seo_description', sanitize_textarea_field($_POST['_tw_seo_description']));
    }
}
