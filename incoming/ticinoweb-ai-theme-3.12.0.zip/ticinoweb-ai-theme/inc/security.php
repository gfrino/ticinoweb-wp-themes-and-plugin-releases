<?php
/**
 * Security Features for ticinoweb-ai-theme
 * - Disables XML-RPC
 * - Masks login URL to /tw-login
 */

// 1. Disable XML-RPC completely
add_filter('xmlrpc_enabled', '__return_false');
remove_action('wp_head', 'rsd_link');

add_action('init', 'tw_block_xmlrpc_requests', 1);
function tw_block_xmlrpc_requests() {
    $req_uri = $_SERVER['REQUEST_URI'] ?? '';
    if ( strpos($req_uri, 'xmlrpc.php') !== false ) {
        wp_die('XML-RPC disabilitato per motivi di sicurezza.', '403', array('response' => 403));
    }
}

// 2. Custom Login URL (/tw-login)
add_action('init', 'tw_custom_login_setup', 1);
function tw_custom_login_setup() {
    // Skip if running in CLI or WP-CLI
    if ( php_sapi_name() === 'cli' || defined('WP_CLI') ) {
        return;
    }

    $login_slug = 'tw-login';
    
    // Calculate relative path for subdirectory multisite support
    $site_url = site_url();
    $site_path = parse_url($site_url, PHP_URL_PATH);
    $site_path = rtrim($site_path ?? '', '/');
    
    $req_uri = $_SERVER['REQUEST_URI'] ?? '';
    $req_path = parse_url($req_uri, PHP_URL_PATH);
    $req_path = rtrim($req_path, '/');

    if ( $site_path && strpos($req_path, $site_path) === 0 ) {
        $rel_path = substr($req_path, strlen($site_path));
    } else {
        $rel_path = $req_path;
    }
    
    $rel_path = trim($rel_path, '/');

    // Block standard wp-login.php access
    if ( $rel_path === 'wp-login.php' ) {
        $action = isset($_GET['action']) ? $_GET['action'] : '';
        // Allow logout and password reset submissions just in case, but block the form itself
        if ( ! in_array($action, ['logout', 'postpass', 'rp', 'resetpass']) ) {
            wp_die('Pagina non trovata', '404', array('response' => 404));
        }
    }

    // Block unauthenticated access to wp-admin to prevent redirection to tw-login
    $is_wp_admin = (strpos($rel_path, 'wp-admin') === 0);
    $is_ajax = (strpos($rel_path, 'admin-ajax.php') !== false || strpos($rel_path, 'admin-post.php') !== false);
    
    if ( $is_wp_admin && ! $is_ajax && ! is_user_logged_in() ) {
        wp_die('Pagina non trovata', '404', array('response' => 404));
    }

    // Serve custom login page
    if ( $rel_path === $login_slug || (strpos($rel_path, $login_slug) === 0) ) {
        define('TW_CUSTOM_LOGIN', true);
        
        global $error, $interim_login, $action, $user_login;
        require_once ABSPATH . 'wp-login.php';
        exit;
    }
}

// Filter URLs to replace wp-login.php with tw-login
add_filter('site_url', 'tw_filter_login_url', 10, 4);
add_filter('network_site_url', 'tw_filter_login_url', 10, 3);
add_filter('wp_redirect', 'tw_filter_login_redirect', 10, 2);

function tw_filter_login_url($url, $path, $scheme, $blog_id = null) {
    if ( strpos($url, 'wp-login.php') !== false ) {
        $url = str_replace('wp-login.php', 'tw-login', $url);
    }
    return $url;
}

function tw_filter_login_redirect($location, $status) {
    if ( strpos($location, 'wp-login.php') !== false ) {
        $location = str_replace('wp-login.php', 'tw-login', $location);
    }
    return $location;
}

// Prevent WordPress from automatically redirecting /login, /admin, and /dashboard to the custom login URL
remove_action('template_redirect', 'wp_redirect_admin_locations', 1000);
