<?php
/**
 * Gestore generico dei form di contatto (AJAX) per tutti i child theme.
 *
 * Endpoint: admin-ajax.php?action=ticinoweb_submit_form (POST)
 * Token:    admin-ajax.php?action=ticinoweb_form_token  (GET, restituisce un nonce fresco:
 *           le pagine sono in cache LiteSpeed anche per giorni, quindi un nonce
 *           stampato nell'HTML sarebbe scaduto)
 *
 * Campi accettati: nome*, email*, telefono, oggetto, messaggio*, tw_hp (honeypot,
 * deve restare vuoto), recaptcha_token (facoltativo, verificato solo se il sito
 * ha configurato le chiavi reCAPTCHA v3 nel pannello ticinoWEB CMS).
 *
 * Il messaggio viene salvato nella tabella {prefix}ticinoweb_form_submissions
 * (tab "Invii Ricevuti" del pannello) e inviato via wp_mail (quindi SMTP o
 * SendGrid se configurati) all'email di contatto del sito.
 *
 * Il JS del child riceve in `ticinoweb_ai_main`: ajax_url, token_action,
 * submit_action, recaptcha_site_key.
 *
 * Filtri: ticinoweb_form_fields, ticinoweb_form_recipients,
 *         ticinoweb_form_email_subject, ticinoweb_form_email_body,
 *         ticinoweb_form_rate_limit (default 5 invii / 10 minuti per IP).
 * Azione: ticinoweb_form_submitted($submission_id, $fields).
 *
 * @package ticinoweb-ai-theme
 * @since 3.10.0
 */

if (!defined('ABSPATH')) {
    exit;
}

add_action('wp_enqueue_scripts', 'ticinoweb_form_localize_main', 20);
function ticinoweb_form_localize_main() {
    if (!wp_script_is('ticinoweb-ai-main', 'enqueued') && !wp_script_is('ticinoweb-ai-main', 'registered')) {
        return;
    }
    wp_localize_script('ticinoweb-ai-main', 'ticinoweb_ai_main', array(
        'ajax_url'           => admin_url('admin-ajax.php'),
        'token_action'       => 'ticinoweb_form_token',
        'submit_action'      => 'ticinoweb_submit_form',
        'recaptcha_site_key' => (string) get_option('ticinoweb_recaptcha_site_key', ''),
    ));
}

add_action('wp_ajax_nopriv_ticinoweb_form_token', 'ticinoweb_form_token');
add_action('wp_ajax_ticinoweb_form_token', 'ticinoweb_form_token');
function ticinoweb_form_token() {
    nocache_headers();
    wp_send_json_success(array('token' => wp_create_nonce('ticinoweb_submit_form')));
}

add_action('wp_ajax_nopriv_ticinoweb_submit_form', 'ticinoweb_submit_form');
add_action('wp_ajax_ticinoweb_submit_form', 'ticinoweb_submit_form');
function ticinoweb_submit_form() {
    nocache_headers();

    if (!isset($_SERVER['REQUEST_METHOD']) || strtoupper($_SERVER['REQUEST_METHOD']) !== 'POST') {
        wp_send_json_error(array('message' => __('Metodo non consentito.', 'ticinoweb-ai-theme')), 405);
    }

    $token = isset($_POST['token']) ? sanitize_text_field(wp_unslash($_POST['token'])) : '';
    if (!wp_verify_nonce($token, 'ticinoweb_submit_form')) {
        wp_send_json_error(array('message' => __('Sessione scaduta, riprova.', 'ticinoweb-ai-theme'), 'code' => 'token'), 403);
    }

    // Honeypot: i bot compilano tutto, gli umani non vedono il campo.
    if (!empty($_POST['tw_hp'])) {
        wp_send_json_success(array('message' => __('Grazie, messaggio ricevuto.', 'ticinoweb-ai-theme')));
    }

    // Rate limit per IP.
    $ip = isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR'])) : '0.0.0.0';
    $limit = (array) apply_filters('ticinoweb_form_rate_limit', array('max' => 5, 'window' => 10 * MINUTE_IN_SECONDS));
    $rl_key = 'tw_form_rl_' . md5($ip);
    $count  = (int) get_transient($rl_key);
    if ($count >= (int) $limit['max']) {
        wp_send_json_error(array('message' => __('Troppi invii in poco tempo, riprova più tardi.', 'ticinoweb-ai-theme'), 'code' => 'rate'), 429);
    }
    set_transient($rl_key, $count + 1, (int) $limit['window']);

    $fields = array(
        'nome'      => isset($_POST['nome']) ? sanitize_text_field(wp_unslash($_POST['nome'])) : '',
        'email'     => isset($_POST['email']) ? sanitize_email(wp_unslash($_POST['email'])) : '',
        'telefono'  => isset($_POST['telefono']) ? sanitize_text_field(wp_unslash($_POST['telefono'])) : '',
        'oggetto'   => isset($_POST['oggetto']) ? sanitize_text_field(wp_unslash($_POST['oggetto'])) : '',
        'messaggio' => isset($_POST['messaggio']) ? sanitize_textarea_field(wp_unslash($_POST['messaggio'])) : '',
    );
    $fields = (array) apply_filters('ticinoweb_form_fields', $fields, $_POST);

    $errors = array();
    if (mb_strlen($fields['nome']) < 2) {
        $errors['nome'] = __('Inserisci il tuo nome.', 'ticinoweb-ai-theme');
    }
    if (!is_email($fields['email'])) {
        $errors['email'] = __("Inserisci un'email valida.", 'ticinoweb-ai-theme');
    }
    if (mb_strlen($fields['messaggio']) < 5) {
        $errors['messaggio'] = __('Inserisci un messaggio.', 'ticinoweb-ai-theme');
    }
    if (mb_strlen($fields['messaggio']) > 5000) {
        $errors['messaggio'] = __('Il messaggio è troppo lungo (max 5000 caratteri).', 'ticinoweb-ai-theme');
    }
    if ($errors) {
        wp_send_json_error(array('message' => __('Controlla i campi evidenziati.', 'ticinoweb-ai-theme'), 'fields' => $errors), 422);
    }

    // reCAPTCHA v3: solo se il sito lo ha configurato.
    if (get_option('ticinoweb_recaptcha_secret_key') && function_exists('ticinoweb_verify_recaptcha')) {
        $rc_token = isset($_POST['recaptcha_token']) ? sanitize_text_field(wp_unslash($_POST['recaptcha_token'])) : '';
        $rc = $rc_token ? ticinoweb_verify_recaptcha($rc_token) : array('success' => false, 'error' => 'token mancante');
        if (empty($rc['success'])) {
            wp_send_json_error(array('message' => __('Verifica anti-spam non superata, riprova.', 'ticinoweb-ai-theme'), 'code' => 'recaptcha'), 403);
        }
    }

    // Salvataggio nella tabella degli invii (creata da ticinoweb_init_database).
    global $wpdb;
    $table = $wpdb->prefix . 'ticinoweb_form_submissions';
    $inserted = $wpdb->insert($table, array(
        'data_invio' => current_time('mysql'),
        'nome'       => $fields['nome'],
        'email'      => $fields['email'],
        'telefono'   => $fields['telefono'],
        'oggetto'    => $fields['oggetto'],
        'messaggio'  => $fields['messaggio'],
        'letto'      => 0,
    ), array('%s', '%s', '%s', '%s', '%s', '%s', '%d'));
    $submission_id = $inserted ? (int) $wpdb->insert_id : 0;

    // Email al titolare.
    $site_name  = wp_specialchars_decode(get_bloginfo('name'), ENT_QUOTES);
    $recipients = array_filter(array_map('sanitize_email', (array) apply_filters(
        'ticinoweb_form_recipients',
        array(get_option('ticinoweb_contact_email') ?: get_option('admin_email')),
        $fields
    )));
    $subject = apply_filters(
        'ticinoweb_form_email_subject',
        sprintf('[%s] %s', $site_name, $fields['oggetto'] !== '' ? $fields['oggetto'] : sprintf(__('Nuovo messaggio da %s', 'ticinoweb-ai-theme'), $fields['nome'])),
        $fields
    );
    $source = wp_get_referer();
    $lines  = array(
        __('Nome', 'ticinoweb-ai-theme') . ': ' . $fields['nome'],
        __('Email', 'ticinoweb-ai-theme') . ': ' . $fields['email'],
    );
    if ($fields['telefono'] !== '') {
        $lines[] = __('Telefono', 'ticinoweb-ai-theme') . ': ' . $fields['telefono'];
    }
    if ($fields['oggetto'] !== '') {
        $lines[] = __('Oggetto', 'ticinoweb-ai-theme') . ': ' . $fields['oggetto'];
    }
    $lines[] = '';
    $lines[] = $fields['messaggio'];
    $lines[] = '';
    $lines[] = '--';
    $lines[] = sprintf(__('Inviato dal sito %s', 'ticinoweb-ai-theme'), home_url('/')) . ($source ? ' (' . $source . ')' : '');
    $lines[] = __('Data', 'ticinoweb-ai-theme') . ': ' . wp_date(get_option('date_format') . ' ' . get_option('time_format'));
    $body = apply_filters('ticinoweb_form_email_body', implode("\n", $lines), $fields);

    // Reply-To con la sola email validata da is_email(): niente header injection.
    $headers = array('Reply-To: ' . $fields['email']);
    $sent = !empty($recipients) ? wp_mail($recipients, $subject, $body, $headers) : false;

    do_action('ticinoweb_form_submitted', $submission_id, $fields, $sent);

    if (!$submission_id && !$sent) {
        wp_send_json_error(array('message' => __('Invio non riuscito, riprova o scrivici direttamente via email.', 'ticinoweb-ai-theme'), 'code' => 'send'), 500);
    }

    wp_send_json_success(array(
        'message' => __('Grazie! Il tuo messaggio è stato inviato. Ti risponderemo al più presto.', 'ticinoweb-ai-theme'),
        'id'      => $submission_id,
        'mailed'  => (bool) $sent,
    ));
}
