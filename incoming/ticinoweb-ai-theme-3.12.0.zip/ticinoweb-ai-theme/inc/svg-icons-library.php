<?php
/**
 * SVG Icons Library - WordPress Media Library Integration
 * Adds a custom "Icone SVG" tab to the WordPress media library with caching and validation
 */

if (!defined('ABSPATH')) {
    exit;
}

if (get_option('ticinoweb_disable_svg_icons')) {
    return;
}

// Enqueue media library extension
add_action('admin_enqueue_scripts', 'ticinoweb_svg_icons_library_assets');
function ticinoweb_svg_icons_library_assets() {
    // Only load on pages with media library
    if (!did_action('wp_enqueue_media')) {
        return;
    }
    
    wp_enqueue_script(
        'ticinoweb-svg-icons-library',
        get_template_directory_uri() . '/assets/js/svg-icons-library.js',
        array('media-views'),
        '1.0.0',
        true
    );
    
    // Get cached icons or generate fresh list
    $icons_data = ticinoweb_get_svg_icons_cached();
    
    wp_localize_script('ticinoweb-svg-icons-library', 'ticinowebSVGIcons', array(
        'icons' => $icons_data,
        'baseUrl' => get_template_directory_uri() . '/assets/icons/',
        'labels' => array(
            'title' => __('Icone SVG', 'ticinoweb-ai-theme'),
            'search' => __('Cerca icone...', 'ticinoweb-ai-theme'),
            'select' => __('Seleziona icona', 'ticinoweb-ai-theme'),
            'copied' => __('URL copiato negli appunti!', 'ticinoweb-ai-theme'),
        )
    ));
    
    wp_enqueue_style(
        'ticinoweb-svg-icons-library',
        get_template_directory_uri() . '/assets/css/svg-icons-library.css',
        array(),
        '1.0.0'
    );
}

/**
 * Get cached SVG icons list with invalidation on filesystem changes
 * Uses WordPress transients for performance (caches for 12 hours)
 */
function ticinoweb_get_svg_icons_cached() {
    $cache_key = 'ticinoweb_svg_icons_list';
    $cache_time = 12 * HOUR_IN_SECONDS; // Cache for 12 hours
    
    // Try to get from cache
    $cached_icons = get_transient($cache_key);
    
    if ($cached_icons !== false && is_array($cached_icons)) {
        return $cached_icons;
    }
    
    // Generate fresh list
    $icons_data = ticinoweb_scan_svg_icons();
    
    // Store in cache
    set_transient($cache_key, $icons_data, $cache_time);
    
    return $icons_data;
}

/**
 * Scan and validate SVG icons from filesystem
 * Filters out broken, corrupted, or invalid SVG files
 * Supports recursive subdirectories (e.g., assets/icons/Varie/)
 */
function ticinoweb_scan_svg_icons() {
    $icons_dir = get_template_directory() . '/assets/icons/';
    $icons_url = get_template_directory_uri() . '/assets/icons/';
    $icons_data = array();
    $skip_count = 0;
    
    if (!is_dir($icons_dir)) {
        return $icons_data;
    }
    
    // Recursively scan for SVG files in subdirectories
    try {
        $iterator = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($icons_dir, RecursiveDirectoryIterator::SKIP_DOTS),
            RecursiveIteratorIterator::SELF_FIRST
        );
        
        foreach ($iterator as $file_path) {
            // Only process .svg files
            if (!$file_path->isFile() || strtolower($file_path->getExtension()) !== 'svg') {
                continue;
            }
            
            $full_path = $file_path->getRealPath();
            
            // Validate SVG file
            $validation = ticinoweb_validate_svg_file($full_path);
            
            if (!$validation['valid']) {
                $skip_count++;
                continue;
            }
            
            // Build relative path for URL and encode spaces
            $rel_path = str_replace($icons_dir, '', $full_path);
            $url = $icons_url . str_replace('\\', '/', $rel_path);
            
            // URL encode spaces and special characters
            $url = str_replace(' ', '%20', $url);
            
            $icons_data[] = array(
                'filename' => $file_path->getBasename(),
                'url' => $url,
                'name' => $file_path->getBasename('.svg'),
                'category' => basename(dirname($full_path))
            );
        }
    } catch (Exception $e) {
        // Silently handle directory iteration errors
        if (WP_DEBUG) {
            error_log('ticinoWEB SVG Icons: Error scanning directory - ' . $e->getMessage());
        }
    }
    
    // Log validation errors only in debug mode
    if (WP_DEBUG && $skip_count > 0) {
        error_log('ticinoWEB SVG Icons: ' . $skip_count . ' invalid files skipped');
    }
    
    // Sort by category and name for better organization
    usort($icons_data, function($a, $b) {
        $cat_cmp = strcmp($a['category'], $b['category']);
        return $cat_cmp !== 0 ? $cat_cmp : strcmp($a['name'], $b['name']);
    });
    
    return $icons_data;
}

/**
 * Validate an SVG file for integrity and correctness
 * Returns array with 'valid' bool and 'error' message if invalid
 */
function ticinoweb_validate_svg_file($file_path) {
    // Check file exists and is readable
    if (!is_readable($file_path)) {
        return array('valid' => false, 'error' => "Unreadable file: $file_path");
    }
    
    $file_size = filesize($file_path);
    
    // Check file size (min 100 bytes, max 500KB)
    if ($file_size < 100 || $file_size > 500000) {
        return array('valid' => false, 'error' => "File size invalid: $file_path");
    }
    
    // Read file content
    $content = @file_get_contents($file_path);
    if ($content === false) {
        return array('valid' => false, 'error' => "Cannot read file: $file_path");
    }
    
    // Basic check: does it contain SVG tag?
    if (stripos($content, '<svg') === false) {
        return array('valid' => false, 'error' => "Not an SVG file: $file_path");
    }
    
    // Validate XML/SVG structure using DOMDocument
    $previous_errors = libxml_use_internal_errors(true);
    
    try {
        $dom = new DOMDocument();
        $loaded = @$dom->loadXML($content);
        
        if (!$loaded) {
            libxml_clear_errors();
            libxml_use_internal_errors($previous_errors);
            return array('valid' => false, 'error' => "Invalid XML structure: $file_path");
        }
        
        // Check if root element is svg
        if ($dom->documentElement->tagName !== 'svg') {
            libxml_use_internal_errors($previous_errors);
            return array('valid' => false, 'error' => "Root element is not SVG: $file_path");
        }
        
    } catch (Exception $e) {
        libxml_clear_errors();
        libxml_use_internal_errors($previous_errors);
        return array('valid' => false, 'error' => "XML parsing error: $file_path");
    }
    
    libxml_use_internal_errors($previous_errors);
    
    return array('valid' => true, 'error' => '');
}

/**
 * Clear SVG icons cache (call when icons directory changes)
 * Can be used as admin action or hook
 */
function ticinoweb_clear_svg_icons_cache() {
    delete_transient('ticinoweb_svg_icons_list');
}

// Add template to footer with category grouping and pagination
add_action('admin_footer', 'ticinoweb_svg_icons_template');
add_action('wp_footer', 'ticinoweb_svg_icons_template');
function ticinoweb_svg_icons_template() {
    ?>
    <script type="text/html" id="tmpl-ticinoweb-svg-icons">
        <div class="svg-icons-info">
            <h4>{{ data.labels.title }}</h4>
            <p>Clicca su un'icona per copiare il suo URL. Puoi usarlo nei servizi selezionando "SVG Custom".</p>
            <p style="font-size: 12px; color: #666;">
                <strong>💡 Tip:</strong> Usa la barra di ricerca per trovare rapidamente le icone. Le icone vengono caricate per categoria (20 alla volta per prestazioni).
            </p>
        </div>
        
        <input type="text" class="svg-search-input" placeholder="{{ data.labels.search }}" style="margin-bottom: 15px;">
        
        <div class="svg-icons-categories">
            <# 
            var categories = {};
            var itemsPerCategory = 20;
            
            // Group icons by category
            _.each(data.icons, function(icon) {
                var cat = icon.category || 'Varie';
                if (!categories[cat]) {
                    categories[cat] = [];
                }
                categories[cat].push(icon);
            });
            
            // Display categories with pagination
            _.each(categories, function(icons, category) { #>
                <div class="svg-category-section" data-category="{{ category }}">
                    <h5 style="margin: 20px 0 10px 0; padding: 10px; background: #f5f5f5; border-left: 4px solid #0073aa;">
                        {{ category }} <span style="color: #666; font-weight: normal;">({{ icons.length }})</span>
                    </h5>
                    
                    <div class="svg-icons-grid category-grid" data-category="{{ category }}">
                        <# _.each(icons.slice(0, itemsPerCategory), function(icon) { #>
                            <div class="svg-icon-item" data-url="{{ icon.url }}" data-filename="{{ icon.filename }}" title="{{ icon.name }}">
                                <img src="{{ icon.url }}" alt="{{ icon.name }}" loading="lazy" onerror="this.parentElement.style.opacity='0.4'">
                                <div class="svg-icon-name">{{ icon.name }}</div>
                            </div>
                        <# }); #>
                    </div>
                    
                    <# if (icons.length > itemsPerCategory) { #>
                        <button type="button" class="button button-secondary load-more-icons" data-category="{{ category }}" data-remaining="{{ icons.length - itemsPerCategory }}" style="width: 100%; margin-top: 10px;">
                            Carica altri ({{ icons.length - itemsPerCategory }} rimanenti)
                        </button>
                    <# } #>
                </div>
            <# }); #>
        </div>
        
        <div class="svg-copied-notice">{{ data.labels.copied }}</div>
    </script>
    
    <script>
    // Handle category pagination and search
    (function($) {
        $(document).ready(function() {
            // Store full icon data in window for pagination
            window.ticinowebSVGIconsData = ticinowebSVGIcons.icons;
            
            // Load more icons when button clicked
            $(document).on('click', '.load-more-icons', function(e) {
                e.preventDefault();
                var btn = $(this);
                var category = btn.data('category');
                var grid = $('.category-grid[data-category="' + category + '"]');
                
                // Find all icons in this category that aren't displayed
                var displayedCount = grid.find('.svg-icon-item').length;
                var categoryIcons = window.ticinowebSVGIconsData.filter(function(icon) {
                    return (icon.category || 'Varie') === category;
                });
                
                // Add next batch
                var itemsPerBatch = 20;
                var newIcons = categoryIcons.slice(displayedCount, displayedCount + itemsPerBatch);
                
                newIcons.forEach(function(icon) {
                    var html = '<div class="svg-icon-item" data-url="' + icon.url + '" data-filename="' + icon.filename + '" title="' + icon.name + '">' +
                        '<img src="' + icon.url + '" alt="' + icon.name + '" loading="lazy" onerror="this.parentElement.style.opacity=\'0.4\'">' +
                        '<div class="svg-icon-name">' + icon.name + '</div>' +
                    '</div>';
                    grid.append(html);
                });
                
                // Update button or hide if all loaded
                var remaining = categoryIcons.length - (displayedCount + itemsPerBatch);
                if (remaining > 0) {
                    btn.text('Carica altri (' + remaining + ' rimanenti)').data('remaining', remaining);
                } else {
                    btn.remove();
                }
            });
            
            // Filter icons based on search
            var searchTimeout;
            $(document).on('input', '.svg-search-input', function() {
                clearTimeout(searchTimeout);
                var query = $(this).val().toLowerCase();
                var categories = $('.svg-category-section');
                
                searchTimeout = setTimeout(function() {
                    categories.each(function() {
                        var category = $(this);
                        var hasVisible = false;
                        
                        category.find('.svg-icon-item').each(function() {
                            var name = $(this).find('.svg-icon-name').text().toLowerCase();
                            var match = name.indexOf(query) !== -1;
                            $(this).toggle(match);
                            if (match) hasVisible = true;
                        });
                        
                        category.find('.load-more-icons').hide();
                        category.toggle(hasVisible || query.length === 0);
                    });
                }, 300);
            });
        });
    })(jQuery);
    </script>
    <?php
}
