<?php
/**
 * Email Configuration Handler
 * Override wp_mail with SMTP or SendGrid based on settings
 */

if (!defined('ABSPATH')) {
    exit;
}

// Configure PHPMailer for SMTP
add_action('phpmailer_init', 'ticinoweb_configure_smtp');
function ticinoweb_configure_smtp($phpmailer) {
    $method = get_option('ticinoweb_email_method', 'default');
    
    if ($method === 'smtp') {
        $host = trim((string) get_option('ticinoweb_smtp_host'));
        if (empty($host)) {
            // SMTP host not configured — bail silently to avoid PHPMailer errors
            error_log('ticinoweb SMTP: host non configurato, invio con metodo default WP.');
            return;
        }

        $port = (int) get_option('ticinoweb_smtp_port', 587);
        if ($port <= 0) {
            $port = 587; // safe fallback
        }

        $encryption = trim((string) get_option('ticinoweb_smtp_encryption', ''));
        $username   = trim((string) get_option('ticinoweb_smtp_username'));
        $password   = trim((string) get_option('ticinoweb_smtp_password'));

        $phpmailer->isSMTP();
        $phpmailer->Host       = $host;
        $phpmailer->Port       = $port;
        $phpmailer->SMTPAuth   = (!empty($username) && !empty($password));
        $phpmailer->Username   = $username;
        $phpmailer->Password   = $password;
        $phpmailer->SMTPSecure = in_array($encryption, array('tls', 'ssl'), true) ? $encryption : '';

        $from_email = trim((string) get_option('ticinoweb_smtp_from_email'));
        $from_name  = trim((string) get_option('ticinoweb_smtp_from_name', get_bloginfo('name')));
        if (!empty($from_email)) {
            $phpmailer->From     = $from_email;
            $phpmailer->FromName = $from_name;
        }
        
        // Enable debug logging when WP_DEBUG is on
        if (defined('WP_DEBUG') && WP_DEBUG) {
            $phpmailer->SMTPDebug  = 2;
            $phpmailer->Debugoutput = function($str, $level) {
                error_log('ticinoweb SMTP Debug [' . $level . ']: ' . $str);
            };
        }
    }
}

// SendGrid API integration via pre_wp_mail (prevents duplicate local send & preserves headers)
add_filter('pre_wp_mail', 'ticinoweb_sendgrid_pre_send', 10, 2);
function ticinoweb_sendgrid_pre_send($return, $args) {
    $method = get_option('ticinoweb_email_method', 'default');
    if ($method !== 'sendgrid') {
        return $return; // Let standard wp_mail proceed
    }
    
    $api_key = get_option('ticinoweb_sendgrid_api_key');
    if (empty($api_key)) {
        return $return;
    }
    
    $to = is_array($args['to']) ? $args['to'] : array($args['to']);
    $subject = $args['subject'];
    $message = $args['message'];
    
    // Check if headers specify text/html BEFORE WordPress strips it!
    $is_html = false;
    if (!empty($args['headers'])) {
        $headers = is_array($args['headers']) ? $args['headers'] : explode("\n", str_replace("\r\n", "\n", $args['headers']));
        foreach ($headers as $header) {
            if (stripos($header, 'Content-Type: text/html') !== false) {
                $is_html = true;
                break;
            }
        }
    }
    
    // Also check wp_mail_content_type filter
    if (apply_filters('wp_mail_content_type', 'text/plain') === 'text/html') {
        $is_html = true;
    }
    
    // Fallback heuristic
    if (!$is_html && preg_match('/<[a-z][\s\S]*>/i', $message)) {
        $is_html = true;
    }

    $from_email = get_option('ticinoweb_sendgrid_from_email');
    $from_name = get_option('ticinoweb_sendgrid_from_name', get_bloginfo('name'));

    // Build SendGrid payload
    $payload = array(
        'personalizations' => array(
            array(
                'to' => array_map(function($email) {
                    return array('email' => $email);
                }, $to)
            )
        ),
        'from' => array(
            'email' => $from_email,
            'name' => $from_name
        ),
        'subject' => $subject,
        'content' => array(
            array(
                'type' => $is_html ? 'text/html' : 'text/plain',
                'value' => $message
            )
        )
    );
    
    // Send via SendGrid API
    $response = wp_remote_post('https://api.sendgrid.com/v3/mail/send', array(
        'headers' => array(
            'Authorization' => 'Bearer ' . $api_key,
            'Content-Type' => 'application/json'
        ),
        'body' => json_encode($payload),
        'timeout' => 30
    ));
    
    if (is_wp_error($response)) {
        error_log('SendGrid Error: ' . $response->get_error_message());
        return false;
    }
    
    $code = wp_remote_retrieve_response_code($response);
    if ($code !== 202) {
        error_log('SendGrid API returned status: ' . $code);
        return false;
    }
    
    return true;
}

// Helper function to verify reCAPTCHA
function ticinoweb_verify_recaptcha($token) {
    $secret = get_option('ticinoweb_recaptcha_secret_key');
    
    if (empty($secret)) {
        return array('success' => false, 'error' => 'reCAPTCHA non configurato');
    }
    
    $response = wp_remote_post('https://www.google.com/recaptcha/api/siteverify', array(
        'body' => array(
            'secret' => $secret,
            'response' => $token
        )
    ));
    
    if (is_wp_error($response)) {
        return array('success' => false, 'error' => $response->get_error_message());
    }
    
    $body = json_decode(wp_remote_retrieve_body($response), true);
    
    if (!$body['success']) {
        return array('success' => false, 'error' => 'Verifica reCAPTCHA fallita');
    }
    
    $threshold = floatval(get_option('ticinoweb_recaptcha_threshold', 0.5));
    $score = floatval($body['score']);
    
    if ($score < $threshold) {
        return array(
            'success' => false, 
            'error' => 'Score troppo basso: ' . $score . ' (minimo: ' . $threshold . ')'
        );
    }
    
    return array('success' => true, 'score' => $score);
}

// Helper to get reCAPTCHA site key for frontend
function ticinoweb_get_recaptcha_site_key() {
    return get_option('ticinoweb_recaptcha_site_key', '');
}
