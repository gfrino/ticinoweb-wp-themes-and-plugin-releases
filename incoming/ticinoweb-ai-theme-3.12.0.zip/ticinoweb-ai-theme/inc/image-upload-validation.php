<?php
/**
 * Image Upload Validation
 * Blocca il caricamento di formati immagine non supportati dai browser web
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Valida il formato dell'immagine durante l'upload
 * Blocca formati non web-standard come HEIC/HEIF
 */
add_filter('wp_handle_upload_prefilter', 'ticinoweb_validate_image_upload');
function ticinoweb_validate_image_upload($file)
{
    // Controlla solo se è un'immagine
    if (strpos($file['type'], 'image/') !== 0) {
        return $file; // Non è un'immagine, lascia passare
    }

    // Formati immagine supportati dai browser web moderni
    $allowed_formats = array(
        'image/jpeg',
        'image/jpg',
        'image/png',
        'image/gif',
        'image/webp',
        'image/svg+xml',
        'image/bmp',
        'image/x-icon',
        'image/vnd.microsoft.icon'
    );

    // Estensioni file non supportate (case insensitive)
    $blocked_extensions = array('heic', 'heif', 'avif');
    $file_extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));

    // Blocca se estensione è in lista nera
    if (in_array($file_extension, $blocked_extensions)) {
        $file['error'] = sprintf(
            __('Formato immagine non supportato: .%s - Per favore converti l\'immagine in JPG, PNG o WebP prima di caricarla.', 'ticinoweb-ai-theme'),
            strtoupper($file_extension)
        );
        return $file;
    }

    // Blocca se MIME type non è nella lista consentiti
    if (!in_array($file['type'], $allowed_formats)) {
        $file['error'] = sprintf(
            __('Formato immagine non supportato: %s - Formati consentiti: JPG, PNG, GIF, WebP, SVG.', 'ticinoweb-ai-theme'),
            $file['type']
        );
        return $file;
    }

    return $file;
}

/**
 * Gestisce i tipi MIME consentiti per l'upload
 * - Rimuove formati non web-standard (HEIC/HEIF)
 * - Aggiunge esplicitamente supporto SVG per loghi
 */
add_filter('upload_mimes', 'ticinoweb_manage_upload_mimes');
function ticinoweb_manage_upload_mimes($mimes)
{
    // Rimuovi formati non web-standard se presenti
    unset($mimes['heic']);
    unset($mimes['heif']);

    // Aggiungi esplicitamente supporto SVG (per loghi e icone)
    // WordPress blocca SVG di default per sicurezza, ma lo abilitiamo per il tema
    $mimes['svg'] = 'image/svg+xml';
    $mimes['svgz'] = 'image/svg+xml';

    return $mimes;
}

/**
 * Messaggio personalizzato per errori di upload nella Media Library
 */
add_filter('wp_handle_upload', 'ticinoweb_custom_upload_error_message');
function ticinoweb_custom_upload_error_message($upload)
{
    if (isset($upload['error']) && strpos($upload['error'], 'non supportato') !== false) {
        // Aggiungi suggerimento per conversione
        $upload['error'] .= ' ' . __('Suggerimento: Su Mac usa Anteprima > Esporta > JPG. Su Windows usa un convertitore online.', 'ticinoweb-ai-theme');
    }
    return $upload;
}
