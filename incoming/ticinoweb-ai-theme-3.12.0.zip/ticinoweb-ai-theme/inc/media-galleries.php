<?php
/**
 * Media Galleries taxonomy and admin UI (parent theme)
 * Allows grouping attachments into named galleries with filters in Media Library and modal.
 */

// Register custom taxonomy for attachments
function ticinoweb_register_media_galleries_taxonomy()
{
    $labels = array(
        'name' => __('Gallerie media', 'ticinoweb-ai-theme'),
        'singular_name' => __('Galleria media', 'ticinoweb-ai-theme'),
        'menu_name' => __('Gallerie media', 'ticinoweb-ai-theme'),
        'all_items' => __('Tutte le gallerie', 'ticinoweb-ai-theme'),
        'edit_item' => __('Modifica galleria', 'ticinoweb-ai-theme'),
        'view_item' => __('Visualizza galleria', 'ticinoweb-ai-theme'),
        'update_item' => __('Aggiorna galleria', 'ticinoweb-ai-theme'),
        'add_new_item' => __('Aggiungi nuova galleria', 'ticinoweb-ai-theme'),
        'new_item_name' => __('Nome nuova galleria', 'ticinoweb-ai-theme'),
        'search_items' => __('Cerca gallerie', 'ticinoweb-ai-theme'),
        'parent_item' => __('Galleria padre', 'ticinoweb-ai-theme'),
        'parent_item_colon' => __('Galleria padre:', 'ticinoweb-ai-theme'),
    );

    register_taxonomy(
        'ticinoweb_media_gallery',
        'attachment',
        array(
            'hierarchical' => true,
            'labels' => $labels,
            'show_ui' => true,
            'show_admin_column' => true,
            'update_count_callback' => '_update_generic_term_count',
            'query_var' => true,
            'rewrite' => false,
            'show_in_rest' => true,
        )
    );
}
add_action('init', 'ticinoweb_register_media_galleries_taxonomy');

// Filter dropdown in Media Library (list view)
function ticinoweb_media_gallery_filter_dropdown()
{
    global $pagenow;
    if ($pagenow !== 'upload.php') {
        return;
    }

    $taxonomy = 'ticinoweb_media_gallery';
    $terms = get_terms(array(
        'taxonomy' => $taxonomy,
        'hide_empty' => false,
    ));

    if (empty($terms) || is_wp_error($terms)) {
        return;
    }

    $current = isset($_GET[$taxonomy]) ? (int) $_GET[$taxonomy] : 0;
    echo '<select name="' . esc_attr($taxonomy) . '" class="postform">';
    echo '<option value="0">' . esc_html__('Tutte le gallerie', 'ticinoweb-ai-theme') . '</option>';
    foreach ($terms as $term) {
        printf(
            '<option value="%1$s" %2$s>%3$s</option>',
            esc_attr($term->term_id),
            selected($current, $term->term_id, false),
            esc_html($term->name)
        );
    }
    echo '</select>';
}
add_action('restrict_manage_posts', 'ticinoweb_media_gallery_filter_dropdown');

// Apply taxonomy filter to media queries (list + modal)
function ticinoweb_media_gallery_query_filter($args)
{
    $taxonomy = 'ticinoweb_media_gallery';
    $term_id = 0;

    if (!empty($_REQUEST[$taxonomy])) {
        $term_id = (int) $_REQUEST[$taxonomy];
    }

    if (isset($_REQUEST['query'][$taxonomy])) {
        $term_id = (int) $_REQUEST['query'][$taxonomy];
    }

    if (!empty($term_id)) {
        $args['tax_query'] = isset($args['tax_query']) ? (array) $args['tax_query'] : array();
        $args['tax_query'][] = array(
            'taxonomy' => $taxonomy,
            'field' => 'term_id',
            'terms' => $term_id,
        );
    }

    return $args;
}
add_filter('ajax_query_attachments_args', 'ticinoweb_media_gallery_query_filter');
add_filter('pre_get_posts', 'ticinoweb_media_gallery_query_filter');

// Attachment edit fields: checkbox list + new gallery input
function ticinoweb_media_gallery_fields_to_edit($form_fields, $post)
{
    $taxonomy = 'ticinoweb_media_gallery';

    $terms = get_terms(array(
        'taxonomy' => $taxonomy,
        'hide_empty' => false,
    ));

    $selected = wp_get_object_terms($post->ID, $taxonomy, array('fields' => 'ids'));
    $selected = is_array($selected) ? $selected : array();

    ob_start();
    echo '<div style="max-height: 180px; overflow-y: auto; padding: 8px 0;">';
    if (!empty($terms) && !is_wp_error($terms)) {
        foreach ($terms as $term) {
            $checked = in_array($term->term_id, $selected, true) ? 'checked' : '';
            echo '<label style="display:block; margin-bottom:6px;">';
            echo '<input type="checkbox" name="attachments[' . esc_attr($post->ID) . '][' . esc_attr($taxonomy) . '][]" value="' . esc_attr($term->term_id) . '" ' . $checked . ' /> ';
            echo esc_html($term->name);
            echo '</label>';
        }
    } else {
        echo '<em>' . esc_html__('Nessuna galleria ancora creata.', 'ticinoweb-ai-theme') . '</em>';
    }
    echo '</div>';

    echo '<label style="display:block; margin-top:8px;">' . esc_html__('Nuova galleria', 'ticinoweb-ai-theme') . '</label>';
    echo '<input type="text" name="attachments[' . esc_attr($post->ID) . '][' . esc_attr($taxonomy) . '_new]" value="" class="widefat" placeholder="' . esc_attr__('Es: Catalogo 2024', 'ticinoweb-ai-theme') . '" />';

    $form_fields[$taxonomy] = array(
        'label' => __('Gallerie', 'ticinoweb-ai-theme'),
        'input' => 'html',
        'html' => ob_get_clean(),
        'helps' => __('Raggruppa gli allegati in gallerie personalizzate.', 'ticinoweb-ai-theme'),
    );

    return $form_fields;
}
add_filter('attachment_fields_to_edit', 'ticinoweb_media_gallery_fields_to_edit', 10, 2);

function ticinoweb_media_gallery_fields_to_save($post, $attachment)
{
    $taxonomy = 'ticinoweb_media_gallery';
    $selected = isset($attachment[$taxonomy]) ? (array) $attachment[$taxonomy] : array();
    $selected = array_filter(array_map('intval', $selected));

    $new_term = isset($attachment[$taxonomy . '_new']) ? sanitize_text_field($attachment[$taxonomy . '_new']) : '';
    if (!empty($new_term)) {
        $created = wp_insert_term($new_term, $taxonomy);
        if (!is_wp_error($created) && !empty($created['term_id'])) {
            $selected[] = (int) $created['term_id'];
        }
    }

    $selected = array_unique($selected);
    wp_set_object_terms($post['ID'], $selected, $taxonomy, false);

    return $post;
}
add_filter('attachment_fields_to_save', 'ticinoweb_media_gallery_fields_to_save', 10, 2);

// Helper to sort gallery terms according to saved custom sequence
function ticinoweb_sort_media_galleries($terms)
{
    if (empty($terms) || is_wp_error($terms) || !is_array($terms)) {
        return $terms;
    }
    $saved_order = get_option('ticinoweb_media_galleries_order', array());
    if (is_array($saved_order) && !empty($saved_order)) {
        usort($terms, function ($a, $b) use ($saved_order) {
            $idA = is_object($a) ? $a->term_id : (int) $a;
            $idB = is_object($b) ? $b->term_id : (int) $b;
            $posA = array_search($idA, $saved_order);
            $posB = array_search($idB, $saved_order);
            if ($posA === false) $posA = 999999;
            if ($posB === false) $posB = 999999;
            if ($posA === $posB) {
                if (is_object($a) && is_object($b) && isset($a->name, $b->name)) {
                    return strcasecmp($a->name, $b->name);
                }
                return 0;
            }
            return $posA - $posB;
        });
    }
    return $terms;
}

add_filter('get_terms', function ($terms, $taxonomies, $args) {
    if (!is_array($terms) || empty($terms)) {
        return $terms;
    }
    $is_gallery = false;
    if (is_string($taxonomies) && $taxonomies === 'ticinoweb_media_gallery') {
        $is_gallery = true;
    } elseif (is_array($taxonomies) && in_array('ticinoweb_media_gallery', $taxonomies, true)) {
        $is_gallery = true;
    }
    if (!$is_gallery) {
        return $terms;
    }
    return ticinoweb_sort_media_galleries($terms);
}, 10, 3);

// Media modal filter (grid view)
function ticinoweb_media_gallery_media_modal_filter()
{
    $taxonomy = 'ticinoweb_media_gallery';
    $terms = get_terms(array(
        'taxonomy' => $taxonomy,
        'hide_empty' => false,
    ));

    if (empty($terms) || is_wp_error($terms)) {
        return;
    }

    $data = array();
    foreach ($terms as $term) {
        $data[] = array(
            'id' => (int) $term->term_id,
            'name' => $term->name,
        );
    }

    $inline_js = <<<JS
(function(wp){
    if (!wp || !wp.media || !wp.media.view) { return; }
    var terms = %s;
    if (!terms || !terms.length) { return; }

    var GalleryFilter = wp.media.view.AttachmentFilters.extend({
        id: "ticinowebMediaGallery",
        createFilters: function() {
            var filters = {};
            filters.all = {
                text: "%s",
                props: { ticinoweb_media_gallery: "" },
                priority: 1
            };
            terms.forEach(function(term){
                filters["gallery-" + term.id] = {
                    text: term.name,
                    props: { ticinoweb_media_gallery: term.id },
                    priority: 2
                };
            });
            this.filters = filters;
        }
    });

    if (!wp.media.view.AttachmentFilters.ticinowebMediaGallery) {
        wp.media.view.AttachmentFilters.ticinowebMediaGallery = GalleryFilter;
    }

    var original = wp.media.view.AttachmentsBrowser;
    if (original && !original.__ticinowebPatched) {
        wp.media.view.AttachmentsBrowser = original.extend({
            createToolbar: function() {
                original.prototype.createToolbar.apply(this, arguments);
                if (!terms.length || !this.toolbar) { return; }
                var control = new wp.media.view.AttachmentFilters.ticinowebMediaGallery({
                    controller: this.controller,
                    model: this.collection.props
                });
                this.toolbar.set('ticinowebMediaGallery', control.render());
                control.model.on('change:ticinoweb_media_gallery', function(model){
                    this.collection.props.set('ticinoweb_media_gallery', model.get('ticinoweb_media_gallery'));
                    this.collection.more();
                }, this);
            }
        });
        wp.media.view.AttachmentsBrowser.__ticinowebPatched = true;
    }
})(window.wp);
JS;

    $inline_js = sprintf(
        $inline_js,
        wp_json_encode($data),
        esc_js(__('Tutte le gallerie', 'ticinoweb-ai-theme'))
    );

    wp_add_inline_script('media-views', $inline_js);
}
add_action('admin_enqueue_scripts', function ($hook) {
    // Load on media library and post editor (for modal)
    if (!in_array($hook, array('upload.php', 'media-upload.php', 'post.php', 'post-new.php'), true)) {
        return;
    }
    ticinoweb_media_gallery_media_modal_filter();
});

// Admin menu for Media Galleries manager
function ticinoweb_add_media_galleries_menu()
{
    add_submenu_page(
        'upload.php',
        __('Gestisci Gallerie', 'ticinoweb-ai-theme'),
        __('Gestisci Gallerie', 'ticinoweb-ai-theme'),
        'manage_options',
        'ticinoweb-media-galleries-manager',
        'ticinoweb_media_galleries_manager_page'
    );
}
add_action('admin_menu', 'ticinoweb_add_media_galleries_menu');

function ticinoweb_enqueue_galleries_manager_script()
{
    $page = isset($_GET['page']) ? sanitize_text_field($_GET['page']) : '';
    if ($page !== 'ticinoweb-media-galleries-manager') {
        return;
    }

    wp_enqueue_media();
    wp_enqueue_script('jquery-ui-sortable');
    wp_enqueue_script('ticinoweb-galleries-manager', get_template_directory_uri() . '/assets/js/media-galleries-manager.js', array('jquery', 'media-views', 'jquery-ui-sortable'), defined('TICINOWEB_THEME_VERSION') ? TICINOWEB_THEME_VERSION : '1.1.0', true);

    // Sync gallery_id with the auto-selection logic in the page renderer
    $current_gallery_id = isset($_GET['gallery']) ? (int) $_GET['gallery'] : 0;
    if (!$current_gallery_id) {
        $galleries = get_terms(array(
            'taxonomy' => 'ticinoweb_media_gallery',
            'hide_empty' => false,
            'number' => 1,
        ));
        if (!empty($galleries) && !is_wp_error($galleries)) {
            $current_gallery_id = $galleries[0]->term_id;
        }
    }

    wp_localize_script('ticinoweb-galleries-manager', 'ticinoweb_galleries', array(
        'gallery_id' => $current_gallery_id,
        'nonce' => wp_create_nonce('ticinoweb_gallery_nonce'),
        'i18n' => array(
            'select' => esc_html__('Seleziona foto per la galleria', 'ticinoweb-ai-theme'),
            'add' => esc_html__('Aggiungi foto', 'ticinoweb-ai-theme'),
            'confirm_remove' => esc_html__('Rimuovere questa foto dalla galleria?', 'ticinoweb-ai-theme'),
        )
    ));
}
add_action('admin_enqueue_scripts', 'ticinoweb_enqueue_galleries_manager_script');

function ticinoweb_media_galleries_manager_page()
{
    $taxonomy = 'ticinoweb_media_gallery';
    $galleries = get_terms(array(
        'taxonomy' => $taxonomy,
        'hide_empty' => false,
    ));

    $current_gallery_id = isset($_GET['gallery']) ? (int) $_GET['gallery'] : (is_array($galleries) && !empty($galleries) ? $galleries[0]->term_id : 0);
    $current_gallery = $current_gallery_id ? get_term($current_gallery_id, $taxonomy) : null;
    ?>
    <style>
        .twgm-wrap {
            max-width: 1400px;
            margin: 20px auto 0;
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif
        }

        .twgm-header {
            background: linear-gradient(135deg, #1e3a5f 0%, #2271b1 100%);
            color: #fff;
            padding: 28px 32px;
            border-radius: 16px;
            margin-bottom: 24px
        }

        .twgm-header h1 {
            margin: 0;
            font-size: 24px;
            font-weight: 600;
            color: #fff
        }

        .twgm-header p {
            margin: 6px 0 0;
            opacity: .8;
            font-size: 14px
        }

        .twgm-layout {
            display: grid;
            grid-template-columns: 260px 1fr;
            gap: 24px;
            align-items: start
        }

        .twgm-sidebar {
            background: #fff;
            border-radius: 12px;
            box-shadow: 0 1px 3px rgba(0, 0, 0, .08), 0 1px 2px rgba(0, 0, 0, .06);
            overflow: hidden
        }

        .twgm-sidebar-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 18px 16px 10px;
        }

        .twgm-sidebar-title {
            font-size: 11px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: .5px;
            color: #94a3b8;
            margin: 0
        }

        .twgm-gallery-list {
            list-style: none;
            padding: 0 8px 8px;
            margin: 0
        }

        .twgm-gallery-item {
            display: flex;
            align-items: center;
            border-radius: 8px;
            margin-bottom: 3px;
            transition: all .2s ease;
            position: relative;
        }

        .twgm-gallery-item:hover {
            background: #f8fafc;
        }

        .twgm-gallery-item.active {
            background: #eff6ff;
        }

        .twgm-gallery-drag-handle {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 22px;
            height: 38px;
            cursor: grab;
            color: #94a3b8;
            opacity: 0.35;
            transition: opacity .2s ease, color .2s ease;
            flex-shrink: 0;
            padding-left: 6px;
        }

        .twgm-gallery-item:hover .twgm-gallery-drag-handle {
            opacity: 1;
            color: #475569;
        }

        .twgm-gallery-item.active .twgm-gallery-drag-handle {
            color: #3b82f6;
            opacity: 0.7;
        }

        .twgm-gallery-item a {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 8px 10px 8px 2px;
            border-radius: 8px;
            text-decoration: none;
            color: #334155;
            transition: all .2s ease;
            flex: 1;
            min-width: 0;
        }

        .twgm-gallery-item.active a {
            color: #1e40af
        }

        .twgm-gallery-icon {
            width: 34px;
            height: 34px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-shrink: 0
        }

        .twgm-gallery-item.active .twgm-gallery-icon {
            background: #2271b1;
            color: #fff
        }

        .twgm-gallery-item:not(.active) .twgm-gallery-icon {
            background: #f1f5f9;
            color: #64748b
        }

        .twgm-gallery-info {
            min-width: 0
        }

        .twgm-gallery-name {
            font-size: 13.5px;
            font-weight: 500;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            display: block
        }

        .twgm-gallery-count {
            font-size: 11.5px;
            color: #94a3b8
        }

        .twgm-gallery-placeholder {
            height: 48px;
            background: #f8fafc;
            border: 2px dashed #cbd5e1;
            border-radius: 8px;
            margin-bottom: 3px;
            visibility: visible !important;
        }

        .twgm-gallery-item.ui-sortable-helper {
            background: #fff;
            box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.15), 0 8px 10px -6px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            cursor: grabbing;
        }

        .twgm-content {
            background: #fff;
            border-radius: 12px;
            box-shadow: 0 1px 3px rgba(0, 0, 0, .08), 0 1px 2px rgba(0, 0, 0, .06);
            padding: 24px
        }

        .twgm-content-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 24px
        }

        .twgm-content-header h2 {
            margin: 0;
            font-size: 20px;
            font-weight: 600;
            color: #1e293b
        }

        .twgm-badge {
            background: #f1f5f9;
            color: #64748b;
            font-size: 12px;
            font-weight: 500;
            padding: 4px 10px;
            border-radius: 20px;
            margin-left: 10px
        }

        .twgm-add-btn {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 10px 20px;
            background: linear-gradient(135deg, #2271b1, #1e5a8e);
            color: #fff;
            border: none;
            border-radius: 10px;
            font-size: 14px;
            font-weight: 500;
            cursor: pointer;
            transition: all .2s ease;
            box-shadow: 0 2px 4px rgba(34, 113, 177, .3)
        }

        .twgm-add-btn:hover {
            transform: translateY(-1px);
            box-shadow: 0 4px 8px rgba(34, 113, 177, .4);
            color: #fff
        }

        .twgm-add-btn:active {
            transform: translateY(0)
        }

        .twgm-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, 120px);
            gap: 12px
        }

        .twgm-image-card {
            position: relative;
            border-radius: 10px;
            overflow: hidden;
            background: #f8fafc;
            width: 120px;
            height: 120px;
            cursor: pointer;
            transition: all .25s ease
        }

        .twgm-image-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 16px rgba(0, 0, 0, .12)
        }

        .twgm-image-card img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            display: block
        }

        .twgm-image-overlay {
            position: absolute;
            inset: 0;
            background: linear-gradient(to top, rgba(0, 0, 0, .6) 0%, transparent 50%);
            opacity: 0;
            transition: opacity .25s ease;
            display: flex;
            align-items: flex-end;
            justify-content: center;
            padding: 12px;
            pointer-events: none
        }

        .twgm-image-card:hover .twgm-image-overlay {
            opacity: 1
        }

        .twgm-remove-btn {
            padding: 4px 10px;
            background: rgba(255, 255, 255, .95);
            color: #dc2626;
            border: none;
            border-radius: 6px;
            font-size: 11px;
            font-weight: 600;
            cursor: pointer;
            transition: all .2s ease;
            pointer-events: auto
        }

        .twgm-drag-handle {
            position: absolute;
            top: 5px;
            right: 5px;
            background: rgba(255, 255, 255, 0.8);
            border-radius: 4px;
            padding: 2px;
            color: #1e293b;
            cursor: move;
            z-index: 10;
            opacity: 0;
            transition: opacity 0.2s ease
        }

        .twgm-image-card:hover .twgm-drag-handle {
            opacity: 1
        }

        .twgm-remove-btn:hover {
            background: #dc2626;
            color: #fff
        }

        .twgm-spinner {
            width: 28px;
            height: 28px;
            border: 3px solid #e2e8f0;
            border-top-color: #2271b1;
            border-radius: 50%;
            animation: twgm-spin .8s linear infinite
        }

        @keyframes twgm-spin {
            to {
                transform: rotate(360deg)
            }
        }

        .twgm-empty {
            grid-column: 1/-1;
            text-align: center;
            padding: 60px 20px;
            color: #94a3b8
        }

        .twgm-empty p {
            margin: 0;
            font-size: 15px
        }

        /* Sortable Enhancements */
        .twgm-placeholder {
            background: #f8fafc;
            border: 2px dashed #cbd5e1;
            border-radius: 10px;
            visibility: visible !important;
            height: 120px !important;
            width: 120px !important;
        }

        .ui-sortable-helper {
            box-shadow: 0 10px 15px -3px rgb(0 0 0 / 0.1), 0 4px 6px -4px rgb(0 0 0 / 0.1) !important;
            transform: scale(1.02);
            z-index: 100;
            transition: transform 0.1s ease;
        }

        .twgm-grid.sorting-active,
        .twgm-gallery-list.sorting-active {
            cursor: grabbing !important;
        }
    </style>

    <div class="twgm-wrap">
        <div class="twgm-header">
            <h1><?php esc_html_e('Gallerie Media', 'ticinoweb-ai-theme'); ?></h1>
            <p><?php esc_html_e('Organizza le tue immagini in gallerie personalizzate', 'ticinoweb-ai-theme'); ?></p>
        </div>

        <div class="twgm-layout">
            <!-- Sidebar -->
            <div class="twgm-sidebar">
                <div class="twgm-sidebar-header">
                    <h3 class="twgm-sidebar-title"><?php esc_html_e('Gallerie', 'ticinoweb-ai-theme'); ?></h3>
                    <span class="twgm-sidebar-hint" title="<?php esc_attr_e('Trascina le gallerie per riordinare', 'ticinoweb-ai-theme'); ?>">
                        <svg xmlns="http://www.w3.org/2000/svg" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="9" cy="12" r="1"></circle><circle cx="9" cy="5" r="1"></circle><circle cx="9" cy="19" r="1"></circle><circle cx="15" cy="12" r="1"></circle><circle cx="15" cy="5" r="1"></circle><circle cx="15" cy="19" r="1"></circle></svg>
                    </span>
                </div>
                <?php if (!empty($galleries) && !is_wp_error($galleries)): ?>
                    <ul class="twgm-gallery-list">
                        <?php foreach ($galleries as $term):
                            $is_active = ($current_gallery_id === $term->term_id);
                            ?>
                            <li class="twgm-gallery-item <?php echo $is_active ? 'active' : ''; ?>" data-term-id="<?php echo esc_attr($term->term_id); ?>">
                                <span class="twgm-gallery-drag-handle" title="<?php esc_attr_e('Trascina per riordinare', 'ticinoweb-ai-theme'); ?>">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                        <circle cx="9" cy="5" r="1.5"></circle>
                                        <circle cx="9" cy="12" r="1.5"></circle>
                                        <circle cx="9" cy="19" r="1.5"></circle>
                                        <circle cx="15" cy="5" r="1.5"></circle>
                                        <circle cx="15" cy="12" r="1.5"></circle>
                                        <circle cx="15" cy="19" r="1.5"></circle>
                                    </svg>
                                </span>
                                <a href="?page=ticinoweb-media-galleries-manager&gallery=<?php echo esc_attr($term->term_id); ?>">
                                    <span class="twgm-gallery-icon">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24"
                                            fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                                            stroke-linejoin="round">
                                            <rect x="3" y="3" width="18" height="18" rx="2" />
                                            <circle cx="8.5" cy="8.5" r="1.5" />
                                            <polyline points="21 15 16 10 5 21" />
                                        </svg>
                                    </span>
                                    <span class="twgm-gallery-info">
                                        <span class="twgm-gallery-name"><?php echo esc_html($term->name); ?></span>
                                        <span class="twgm-gallery-count"><?php echo esc_html($term->count); ?> foto</span>
                                    </span>
                                </a>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                <?php else: ?>
                    <p style="padding:12px 20px;color:#94a3b8;font-size:13px">
                        <?php esc_html_e('Nessuna galleria ancora.', 'ticinoweb-ai-theme'); ?>
                    </p>
                <?php endif; ?>
            </div>

            <!-- Content -->
            <div class="twgm-content">
                <?php if ($current_gallery): ?>
                    <div class="twgm-content-header">
                        <div>
                            <h2><?php echo esc_html($current_gallery->name); ?><span
                                    class="twgm-badge"><?php echo esc_html($current_gallery->count); ?> foto</span></h2>
                            <?php if ($current_gallery->description): ?>
                                <p style="margin:4px 0 0;color:#64748b;font-size:13px">
                                    <?php echo esc_html($current_gallery->description); ?>
                                </p>
                            <?php endif; ?>
                        </div>
                        <button type="button" class="twgm-add-btn" id="ticinoweb-add-photos">
                            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none"
                                stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <line x1="12" y1="5" x2="12" y2="19" />
                                <line x1="5" y1="12" x2="19" y2="12" />
                            </svg>
                            <?php esc_html_e('Aggiungi foto', 'ticinoweb-ai-theme'); ?>
                        </button>
                    </div>

                    <div class="twgm-grid" id="gallery-images">
                        <?php
                        $images = new WP_Query(array(
                            'post_type'      => 'attachment',
                            'post_status'    => 'inherit',
                            'posts_per_page' => 500, // limit to avoid memory exhaustion on large galleries (#10)
                            'tax_query' => array(
                                array(
                                    'taxonomy' => $taxonomy,
                                    'field' => 'term_id',
                                    'terms' => $current_gallery_id,
                                )
                            )
                        ));

                        $saved_order = get_term_meta($current_gallery_id, '_ticinoweb_gallery_order', true);
                        if (!is_array($saved_order)) {
                            $saved_order = array();
                        }

                        if (!empty($saved_order) && $images->have_posts()) {
                            usort($images->posts, function ($a, $b) use ($saved_order) {
                                $posA = array_search($a->ID, $saved_order);
                                $posB = array_search($b->ID, $saved_order);
                                if ($posA === false)
                                    $posA = 999999;
                                if ($posB === false)
                                    $posB = 999999;
                                return $posA - $posB;
                            });
                        }

                        if ($images->have_posts()):
                            while ($images->have_posts()):
                                $images->the_post();
                                $img_url = wp_get_attachment_image_src(get_the_ID(), 'medium');
                                ?>
                                <div class="twgm-image-card" data-attachment-id="<?php echo esc_attr(get_the_ID()); ?>">
                                    <div class="twgm-drag-handle">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none"
                                            stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                            <polyline points="5 9 2 12 5 15"></polyline>
                                            <polyline points="9 5 12 2 15 5"></polyline>
                                            <polyline points="15 19 12 22 9 19"></polyline>
                                            <polyline points="19 9 22 12 19 15"></polyline>
                                            <line x1="2" y1="12" x2="22" y2="12"></line>
                                            <line x1="12" y1="2" x2="12" y2="22"></line>
                                        </svg>
                                    </div>
                                    <img src="<?php echo esc_url($img_url[0]); ?>" alt="<?php the_title_attribute(); ?>">
                                    <div class="twgm-image-overlay">
                                        <button type="button" class="twgm-remove-btn remove-from-gallery"
                                            data-attachment-id="<?php echo esc_attr(get_the_ID()); ?>">
                                            <?php esc_html_e('Rimuovi', 'ticinoweb-ai-theme'); ?>
                                        </button>
                                    </div>
                                </div>
                                <?php
                            endwhile;
                            wp_reset_postdata();
                        else:
                            ?>
                            <div class="twgm-empty">
                                <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none"
                                    stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"
                                    style="opacity:.4;margin-bottom:12px">
                                    <rect x="3" y="3" width="18" height="18" rx="2" />
                                    <circle cx="8.5" cy="8.5" r="1.5" />
                                    <polyline points="21 15 16 10 5 21" />
                                </svg>
                                <p><?php esc_html_e('Nessuna foto in questa galleria.', 'ticinoweb-ai-theme'); ?></p>
                                <p style="font-size:13px;margin-top:4px">
                                    <?php esc_html_e('Clicca "Aggiungi foto" per iniziare.', 'ticinoweb-ai-theme'); ?>
                                </p>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php else: ?>
                    <div class="twgm-empty">
                        <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none"
                            stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"
                            style="opacity:.4;margin-bottom:12px">
                            <rect x="3" y="3" width="18" height="18" rx="2" />
                            <circle cx="8.5" cy="8.5" r="1.5" />
                            <polyline points="21 15 16 10 5 21" />
                        </svg>
                        <p><?php esc_html_e('Seleziona una galleria per gestire le foto.', 'ticinoweb-ai-theme'); ?></p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <?php
}


// AJAX: Add attachment to gallery
add_action('wp_ajax_ticinoweb_add_to_gallery', function () {
    check_ajax_referer('ticinoweb_gallery_nonce', 'nonce');
    if (!current_user_can('manage_options')) {
        wp_send_json_error('Unauthorized');
    }

    $attachment_id = (int) $_POST['attachment_id'];
    $term_id = (int) $_POST['term_id'];
    $taxonomy = 'ticinoweb_media_gallery';

    $current_terms = wp_get_object_terms($attachment_id, $taxonomy, array('fields' => 'ids'));
    $current_terms = is_array($current_terms) ? $current_terms : array();

    if (!in_array($term_id, $current_terms)) {
        $current_terms[] = $term_id;
    }

    wp_set_object_terms($attachment_id, $current_terms, $taxonomy, false);
    wp_send_json_success();
});

// AJAX: Remove attachment from gallery
add_action('wp_ajax_ticinoweb_remove_from_gallery', function () {
    check_ajax_referer('ticinoweb_gallery_nonce', 'nonce');
    if (!current_user_can('manage_options')) {
        wp_send_json_error('Unauthorized');
    }

    $attachment_id = (int) $_POST['attachment_id'];
    $term_id = (int) $_POST['term_id'];
    $taxonomy = 'ticinoweb_media_gallery';

    $current_terms = wp_get_object_terms($attachment_id, $taxonomy, array('fields' => 'ids'));
    $current_terms = is_array($current_terms) ? $current_terms : array();
    $current_terms = array_diff($current_terms, array($term_id));

    wp_set_object_terms($attachment_id, $current_terms, $taxonomy, false);
    wp_send_json_success();
});

// AJAX: Save photo order inside a gallery
add_action('wp_ajax_ticinoweb_save_gallery_order', function () {
    check_ajax_referer('ticinoweb_gallery_nonce', 'nonce');
    if (!current_user_can('manage_options')) {
        wp_send_json_error('Unauthorized');
    }

    $term_id = (int) $_POST['term_id'];
    $order = isset($_POST['order']) ? (array) $_POST['order'] : array();
    $order = array_map('intval', $order);

    update_term_meta($term_id, '_ticinoweb_gallery_order', $order);
    wp_send_json_success();
});

// AJAX: Save list of galleries order (sidebar sequence)
add_action('wp_ajax_ticinoweb_save_galleries_order', function () {
    check_ajax_referer('ticinoweb_gallery_nonce', 'nonce');
    if (!current_user_can('manage_options')) {
        wp_send_json_error('Unauthorized');
    }

    $order = isset($_POST['order']) ? (array) $_POST['order'] : array();
    $order = array_values(array_filter(array_map('intval', $order)));

    update_option('ticinoweb_media_galleries_order', $order);
    wp_send_json_success(array('order' => $order));
});

// Clean up or append to gallery order when terms change
add_action('delete_ticinoweb_media_gallery', function ($term_id) {
    $saved_order = get_option('ticinoweb_media_galleries_order', array());
    if (is_array($saved_order) && in_array($term_id, $saved_order)) {
        $saved_order = array_values(array_diff($saved_order, array($term_id)));
        update_option('ticinoweb_media_galleries_order', $saved_order);
    }
});

add_action('created_ticinoweb_media_gallery', function ($term_id) {
    $saved_order = get_option('ticinoweb_media_galleries_order', array());
    if (is_array($saved_order) && !in_array($term_id, $saved_order)) {
        $saved_order[] = (int) $term_id;
        update_option('ticinoweb_media_galleries_order', $saved_order);
    }
});


