/**
 * Passkey (WebAuthn) - ticinoweb-ai-theme 3.7.0
 *
 * Due modalita': "login" sulla pagina di accesso, "manage" nel profilo utente.
 * Nessuna dipendenza, nemmeno jQuery: la pagina di login carica poco ed e'
 * meglio non appesantirla.
 */
(function () {
	'use strict';

	if (typeof window.twPasskeys === 'undefined') {
		return;
	}
	var CFG = window.twPasskeys;

	var supported = !!(window.PublicKeyCredential &&
		navigator.credentials &&
		typeof navigator.credentials.create === 'function');

	/* ---------- base64url <-> ArrayBuffer ---------- */

	function b64urlToBuf(s) {
		s = String(s).replace(/-/g, '+').replace(/_/g, '/');
		while (s.length % 4) { s += '='; }
		var bin = window.atob(s);
		var buf = new Uint8Array(bin.length);
		for (var i = 0; i < bin.length; i++) { buf[i] = bin.charCodeAt(i); }
		return buf.buffer;
	}

	function bufToB64url(buf) {
		var bytes = new Uint8Array(buf), bin = '';
		for (var i = 0; i < bytes.length; i++) { bin += String.fromCharCode(bytes[i]); }
		return window.btoa(bin).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
	}

	/* ---------- utilita' ---------- */

	function post(action, data) {
		var body = new URLSearchParams();
		body.append('action', action);
		Object.keys(data).forEach(function (k) { body.append(k, data[k]); });

		return fetch(CFG.ajaxUrl, {
			method: 'POST',
			credentials: 'same-origin',
			headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
			body: body.toString()
		}).then(function (r) { return r.json(); });
	}

	function msg(text, kind) {
		var el = document.getElementById('tw-pk-msg');
		if (!el) { return; }
		el.textContent = text || '';
		el.className = 'tw-pk-msg' + (kind ? ' ' + kind : '');
	}

	/**
	 * Gli errori dell'API WebAuthn sono poco leggibili: NotAllowedError copre
	 * sia l'annullamento volontario sia il timeout, e presentarlo come guasto
	 * confonderebbe chi ha semplicemente chiuso il dialogo.
	 */
	function humanError(err) {
		if (!err) { return 'Operazione non riuscita.'; }
		switch (err.name) {
			case 'NotAllowedError':
				return 'Operazione annullata o scaduta.';
			case 'InvalidStateError':
				return 'Questo dispositivo ha gia’ una passkey registrata per il sito.';
			case 'NotSupportedError':
				return 'Questo dispositivo non supporta le passkey.';
			case 'SecurityError':
				return 'Contesto non sicuro: le passkey richiedono HTTPS.';
			case 'AbortError':
				return 'Operazione interrotta.';
			default:
				return err.message || 'Operazione non riuscita.';
		}
	}

	/* ---------- modalita' LOGIN ---------- */

	function initLogin() {
		var box = document.getElementById('tw-pk-login');
		var btn = document.getElementById('tw-pk-login-btn');
		if (!box || !btn) { return; }

		// Il blocco resta nascosto se il browser non supporta WebAuthn: meglio
		// non offrire un pulsante che non potrebbe funzionare.
		if (!supported) { return; }
		box.hidden = false;

		btn.addEventListener('click', function () {
			btn.disabled = true;
			msg('Attendere…');

			var loginEl = document.getElementById('user_login');
			var username = loginEl ? loginEl.value.trim() : '';

			post('tw_passkey_auth_options', { username: username }).then(function (res) {
				if (!res || !res.success) {
					throw new Error(res && res.data ? res.data.message : 'Richiesta non riuscita.');
				}
				var o = res.data;
				var allowCreds = [];
				if (Array.isArray(o.allowCredentials) && o.allowCredentials.length > 0) {
					allowCreds = o.allowCredentials.map(function (c) {
						return { type: c.type || 'public-key', id: b64urlToBuf(c.id) };
					});
				}
				return navigator.credentials.get({
					publicKey: {
						challenge: b64urlToBuf(o.challenge),
						rpId: o.rpId,
						timeout: o.timeout,
						userVerification: 'preferred',
						allowCredentials: allowCreds
					}
				}).then(function (cred) {
					if (!cred) { throw new Error('Nessuna passkey selezionata.'); }
					var rememberEl = document.getElementById('rememberme');
					return post('tw_passkey_auth_verify', {
						token: o.token,
						id: bufToB64url(cred.rawId),
						clientDataJSON: bufToB64url(cred.response.clientDataJSON),
						authenticatorData: bufToB64url(cred.response.authenticatorData),
						signature: bufToB64url(cred.response.signature),
						remember: (rememberEl && rememberEl.checked) ? '1' : '0',
						redirect_to: CFG.redirectTo || ''
					});
				});
			}).then(function (res) {
				if (!res || !res.success) {
					throw new Error(res && res.data ? res.data.message : 'Accesso non riuscito.');
				}
				msg('Accesso riuscito, un momento…', 'ok');
				window.location.assign(res.data.redirect);
			}).catch(function (err) {
				msg(humanError(err), 'error');
				btn.disabled = false;
			});
		});
	}

	/* ---------- modalita' PROFILO ---------- */

	function bindDelete() {
		var rows = document.getElementById('tw-pk-rows');
		if (!rows) { return; }

		rows.addEventListener('click', function (ev) {
			var btn = ev.target.closest('.tw-pk-del');
			if (!btn) { return; }
			if (!window.confirm('Revocare questa passkey? Il dispositivo non potra’ piu’ accedere con essa.')) {
				return;
			}
			btn.disabled = true;
			post('tw_passkey_delete', {
				nonce: CFG.nonce,
				user_id: CFG.userId,
				id: btn.getAttribute('data-id')
			}).then(function (res) {
				if (!res || !res.success) {
					throw new Error(res && res.data ? res.data.message : 'Revoca non riuscita.');
				}
				rows.innerHTML = res.data.rows;
				msg(res.data.message, 'ok');
			}).catch(function (err) {
				msg(humanError(err), 'error');
				btn.disabled = false;
			});
		});
	}

	function initManage() {
		bindDelete();

		var add = document.getElementById('tw-pk-add');
		if (!add) { return; }

		if (!supported) {
			add.disabled = true;
			msg('Questo browser non supporta le passkey.', 'error');
			return;
		}

		add.addEventListener('click', function () {
			add.disabled = true;
			msg('Segui le istruzioni del dispositivo…');

			var labelEl = document.getElementById('tw-pk-label');
			var label = labelEl ? labelEl.value : '';

			post('tw_passkey_register_options', { nonce: CFG.nonce }).then(function (res) {
				if (!res || !res.success) {
					throw new Error(res && res.data ? res.data.message : 'Richiesta non riuscita.');
				}
				var o = res.data;
				return navigator.credentials.create({
					publicKey: {
						challenge: b64urlToBuf(o.challenge),
						rp: o.rp,
						user: {
							id: b64urlToBuf(o.user.id),
							name: o.user.name,
							displayName: o.user.displayName
						},
						pubKeyCredParams: [
							{ type: 'public-key', alg: -7 },   // ES256
							{ type: 'public-key', alg: -257 }  // RS256
						],
						timeout: o.timeout,
						attestation: 'none',
						authenticatorSelection: {
							residentKey: 'preferred',
							userVerification: 'preferred'
						},
						excludeCredentials: (o.excludeCredentials || []).map(function (c) {
							return { type: 'public-key', id: b64urlToBuf(c.id) };
						})
					}
				}).then(function (cred) {
					if (!cred) { throw new Error('Registrazione annullata.'); }
					return post('tw_passkey_register_verify', {
						nonce: CFG.nonce,
						token: o.token,
						label: label,
						clientDataJSON: bufToB64url(cred.response.clientDataJSON),
						attestationObject: bufToB64url(cred.response.attestationObject)
					});
				});
			}).then(function (res) {
				if (!res || !res.success) {
					throw new Error(res && res.data ? res.data.message : 'Registrazione non riuscita.');
				}
				var rows = document.getElementById('tw-pk-rows');
				if (rows) { rows.innerHTML = res.data.rows; }
				if (labelEl) { labelEl.value = ''; }
				msg(res.data.message, 'ok');
				add.disabled = false;
			}).catch(function (err) {
				msg(humanError(err), 'error');
				add.disabled = false;
			});
		});
	}

	function boot() {
		if (CFG.mode === 'login') { initLogin(); } else { initManage(); }
	}

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', boot);
	} else {
		boot();
	}
})();
