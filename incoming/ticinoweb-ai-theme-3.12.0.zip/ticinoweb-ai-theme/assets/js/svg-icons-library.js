/**
 * SVG Icons Library - Media Library Extension
 * Adds custom "Icone SVG" tab to WordPress media library
 */

(function($) {
    'use strict';
    
    if (typeof wp === 'undefined' || !wp.media) {
        return;
    }
    
    // Create custom SVG Icons view
    var SVGIconsView = wp.media.View.extend({
        className: 'ticinoweb-svg-icons-browser',
        template: wp.template('ticinoweb-svg-icons'),
        
        events: {
            'input .svg-search-input': 'searchIcons',
            'click .svg-icon-item': 'selectIcon'
        },
        
        initialize: function() {
            this.icons = ticinowebSVGIcons.icons || [];
            this.filteredIcons = this.icons;
        },
        
        render: function() {
            this.$el.html(this.template({
                icons: this.filteredIcons,
                labels: ticinowebSVGIcons.labels
            }));
            return this;
        },
        
        searchIcons: function(e) {
            var search = $(e.currentTarget).val().toLowerCase();
            this.filteredIcons = this.icons.filter(function(icon) {
                return icon.name.toLowerCase().indexOf(search) > -1;
            });
            this.render();
        },
        
        selectIcon: function(e) {
            e.preventDefault();
            var $item = $(e.currentTarget);
            var url = $item.data('url');
            var filename = $item.data('filename');
            
            // Copy to clipboard
            this.copyToClipboard(url);
            
            // Show copied notice
            this.$('.svg-copied-notice').fadeIn().delay(2000).fadeOut();
            
            // Highlight selected
            this.$('.svg-icon-item').removeClass('selected');
            $item.addClass('selected');
            
            // Trigger selection event for parent frame
            this.controller.state().get('selection').reset([{
                id: 'svg-' + filename,
                url: url,
                type: 'image',
                subtype: 'svg+xml',
                filename: filename
            }]);
        },
        
        copyToClipboard: function(text) {
            var $temp = $('<input>');
            $('body').append($temp);
            $temp.val(text).select();
            document.execCommand('copy');
            $temp.remove();
        }
    });
    
    // Add custom tab to media library
    wp.media.view.MediaFrame.Post = wp.media.view.MediaFrame.Post.extend({
        createStates: function() {
            // Call original method
            wp.media.view.MediaFrame.prototype.createStates.apply(this, arguments);
            
            // Add SVG Icons state
            this.states.add([
                new wp.media.controller.Library({
                    id: 'ticinoweb-svg-icons',
                    title: ticinowebSVGIcons.labels.title,
                    priority: 60,
                    toolbar: 'select',
                    filterable: false,
                    searchable: false,
                    sortable: false,
                    display: false,
                    content: 'ticinoweb-svg-icons',
                    contentUserSetting: false,
                    syncSelection: false
                })
            ]);
        },
        
        bindHandlers: function() {
            wp.media.view.MediaFrame.prototype.bindHandlers.apply(this, arguments);
            
            this.on('content:create:ticinoweb-svg-icons', this.createSVGIconsContent, this);
        },
        
        createSVGIconsContent: function(contentRegion) {
            contentRegion.view = new SVGIconsView({
                controller: this,
                model: this.state().props
            });
        }
    });
    
    // Also extend MediaFrame.Select for other contexts
    wp.media.view.MediaFrame.Select = wp.media.view.MediaFrame.Select.extend({
        createStates: function() {
            wp.media.view.MediaFrame.prototype.createStates.apply(this, arguments);
            
            this.states.add([
                new wp.media.controller.Library({
                    id: 'ticinoweb-svg-icons',
                    title: ticinowebSVGIcons.labels.title,
                    priority: 60,
                    toolbar: 'select',
                    filterable: false,
                    searchable: false,
                    sortable: false,
                    display: false,
                    content: 'ticinoweb-svg-icons',
                    contentUserSetting: false,
                    syncSelection: false
                })
            ]);
        },
        
        bindHandlers: function() {
            wp.media.view.MediaFrame.prototype.bindHandlers.apply(this, arguments);
            
            this.on('content:create:ticinoweb-svg-icons', this.createSVGIconsContent, this);
        },
        
        createSVGIconsContent: function(contentRegion) {
            contentRegion.view = new SVGIconsView({
                controller: this,
                model: this.state().props
            });
        }
    });
    
})(jQuery);
