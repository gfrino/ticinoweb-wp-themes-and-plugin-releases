document.addEventListener('DOMContentLoaded', function() {
  const slider = document.querySelector('.hero-slider');
  if (!slider) return;
  
  const track = slider.querySelector('.slider-track');
  const slides = track.querySelectorAll('.slide');
  const nextBtn = slider.querySelector('.slider-arrow.next');
  const prevBtn = slider.querySelector('.slider-arrow.prev');
  const dotsContainer = slider.querySelector('.slider-dots');
  
  let currentSlide = 0;
  const totalSlides = slides.length;
  
  // Create dots
  function createDots() {
    dotsContainer.innerHTML = '';
    for (let i = 0; i < totalSlides; i++) {
      const dot = document.createElement('button');
      dot.className = 'slider-dot';
      dot.setAttribute('aria-label', 'Vai alla slide ' + (i + 1));
      dot.addEventListener('click', function() {
        goToSlide(i);
      });
      dotsContainer.appendChild(dot);
    }
  }
  
  // Update slider position
  function updateSlider() {
    // Move track
    track.style.transform = 'translateX(-' + (currentSlide * 100) + '%)';
    
    // Update dots
    const dots = dotsContainer.querySelectorAll('.slider-dot');
    dots.forEach(function(dot, index) {
      if (index === currentSlide) {
        dot.classList.add('active');
      } else {
        dot.classList.remove('active');
      }
    });
    
    // Update slides visibility
    slides.forEach(function(slide, index) {
      if (index === currentSlide) {
        slide.style.opacity = '1';
        slide.style.visibility = 'visible';
      } else {
        slide.style.opacity = '0';
        slide.style.visibility = 'hidden';
      }
    });
  }
  
  // Go to specific slide
  function goToSlide(n) {
    currentSlide = n;
    if (currentSlide >= totalSlides) currentSlide = 0;
    if (currentSlide < 0) currentSlide = totalSlides - 1;
    updateSlider();
  }
  
  // Next slide
  function nextSlide() {
    currentSlide++;
    if (currentSlide >= totalSlides) currentSlide = 0;
    updateSlider();
  }
  
  // Previous slide
  function prevSlide() {
    currentSlide--;
    if (currentSlide < 0) currentSlide = totalSlides - 1;
    updateSlider();
  }
  
  // Event listeners
  if (nextBtn) nextBtn.addEventListener('click', nextSlide);
  if (prevBtn) prevBtn.addEventListener('click', prevSlide);
  
  // Initialize
  createDots();
  updateSlider();
  
  // Auto-advance
  setInterval(nextSlide, 5000);
});
