/**
 * Media Galleries Manager - Admin JS
 */

(function ($) {
    'use strict';

    $(document).ready(function () {
        var galleryId = parseInt(ticinoweb_galleries.gallery_id) || 0;
        var nonce = ticinoweb_galleries.nonce || '';

        console.log('Gallery Manager JS loaded', { galleryId: galleryId, nonce: nonce });

        // Add photos button
        $('#ticinoweb-add-photos').on('click', function (e) {
            e.preventDefault();

            if (!galleryId) {
                alert('Seleziona una galleria');
                return;
            }

            console.log('Opening media frame for gallery:', galleryId);

            var mediaFrame = wp.media({
                title: ticinoweb_galleries.i18n.select,
                button: { text: ticinoweb_galleries.i18n.add },
                multiple: true,
                library: { type: 'image' }
            });

            mediaFrame.on('select', function () {
                var attachments = mediaFrame.state().get('selection').toJSON();
                var processed = 0;

                console.log('Selected attachments:', attachments.length);

                if (attachments.length === 0) {
                    alert('Nessuna foto selezionata');
                    return;
                }

                // Insert spinner placeholders into grid
                var $grid = $('#gallery-images');
                attachments.forEach(function () {
                    $grid.append(
                        '<div class="twgm-image-card twgm-placeholder" style="display:flex;align-items:center;justify-content:center;background:#f1f5f9">' +
                        '<div class="twgm-spinner"></div>' +
                        '</div>'
                    );
                });

                // Disable add button during upload
                $('#ticinoweb-add-photos').prop('disabled', true).css('opacity', '0.6');

                attachments.forEach(function (attachment) {
                    console.log('Adding attachment to gallery:', attachment.id);
                    $.ajax({
                        url: ajaxurl,
                        type: 'POST',
                        data: {
                            action: 'ticinoweb_add_to_gallery',
                            attachment_id: attachment.id,
                            term_id: galleryId,
                            nonce: nonce
                        },
                        success: function (resp) {
                            console.log('AJAX success:', resp);
                            processed++;
                            if (processed === attachments.length) {
                                location.reload();
                            }
                        },
                        error: function (xhr, status, error) {
                            console.error('AJAX error:', { xhr: xhr, status: status, error: error });
                            processed++;
                            if (processed === attachments.length) {
                                location.reload();
                            }
                        }
                    });
                });
            });

            mediaFrame.open();
        });

        // Remove from gallery (double-click confirmation)
        $(document).on('click', '.remove-from-gallery', function (e) {
            e.preventDefault();
            e.stopPropagation();
            var $btn = $(this);
            var attachmentId = $btn.data('attachment-id');

            // Double-click confirmation pattern
            if ($btn.data('confirming')) {
                // Second click: proceed with removal
                $btn.data('confirming', false);
                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'ticinoweb_remove_from_gallery',
                        attachment_id: attachmentId,
                        term_id: galleryId,
                        nonce: nonce
                    },
                    success: function (resp) {
                        if (resp.success) {
                            location.reload();
                        } else {
                            alert('Errore nella rimozione');
                        }
                    },
                    error: function () {
                        alert('Errore di connessione');
                    }
                });
            } else {
                // First click: show confirmation state
                $btn.data('confirming', true);
                var origText = $btn.text();
                $btn.text('Conferma?');
                $btn.css({ 'opacity': '1', 'background': '#b00', 'border-color': '#b00' });
                setTimeout(function () {
                    $btn.data('confirming', false);
                    $btn.text(origText);
                    $btn.css({ 'background': '#dc3545', 'border-color': '#dc3545' });
                }, 3000);
            }
        });

        // Initialize Sortable for drag-and-drop ordering
        if ($('#gallery-images').length && $.fn.sortable) {
            $('#gallery-images').sortable({
                items: '> .twgm-image-card',
                handle: '.twgm-drag-handle',
                placeholder: 'twgm-placeholder',
                forcePlaceholderSize: true,
                revert: 150,
                tolerance: 'pointer',
                opacity: 0.8,
                zIndex: 9999,
                cursor: 'grabbing',
                start: function (event, ui) {
                    $('#gallery-images').addClass('sorting-active');
                    // Ensure helper has original dimensions
                    ui.helper.css({
                        width: ui.item.width(),
                        height: ui.item.height()
                    });
                },
                stop: function (event, ui) {
                    $('#gallery-images').removeClass('sorting-active');
                },
                update: function (event, ui) {
                    if (!galleryId) return;

                    var order = [];
                    $('#gallery-images .twgm-image-card').each(function () {
                        var id = $(this).data('attachment-id');
                        if (id) {
                            order.push(id);
                        }
                    });

                    // Subtle indication instead of blocking
                    var $grid = $('#gallery-images');
                    $grid.css('opacity', '0.7');

                    $.ajax({
                        url: ajaxurl,
                        type: 'POST',
                        data: {
                            action: 'ticinoweb_save_gallery_order',
                            term_id: galleryId,
                            order: order,
                            nonce: nonce
                        },
                        success: function (resp) {
                            $grid.css('opacity', '1');
                            if (!resp.success) {
                                console.error('Errore nel salvataggio dell\'ordine:', resp.data);
                            }
                        },
                        error: function () {
                            $grid.css('opacity', '1');
                            console.error('Errore di connessione durante il salvataggio');
                        }
                    });
                }
            });
        }

        // Initialize Sortable for gallery list (reordering galleries)
        if ($('.twgm-gallery-list').length && $.fn.sortable) {
            $('.twgm-gallery-list').sortable({
                items: '> .twgm-gallery-item',
                handle: '.twgm-gallery-drag-handle',
                placeholder: 'twgm-gallery-placeholder',
                forcePlaceholderSize: true,
                revert: 150,
                tolerance: 'pointer',
                opacity: 0.85,
                zIndex: 9999,
                cursor: 'grabbing',
                start: function (event, ui) {
                    $('.twgm-gallery-list').addClass('sorting-active');
                },
                stop: function (event, ui) {
                    $('.twgm-gallery-list').removeClass('sorting-active');
                },
                update: function (event, ui) {
                    var order = [];
                    $('.twgm-gallery-list .twgm-gallery-item').each(function () {
                        var id = $(this).data('term-id');
                        if (id) {
                            order.push(id);
                        }
                    });

                    var $list = $('.twgm-gallery-list');
                    $list.css('opacity', '0.7');

                    $.ajax({
                        url: ajaxurl,
                        type: 'POST',
                        data: {
                            action: 'ticinoweb_save_galleries_order',
                            order: order,
                            nonce: nonce
                        },
                        success: function (resp) {
                            $list.css('opacity', '1');
                            if (!resp.success) {
                                console.error('Errore nel salvataggio dell\'ordine delle gallerie:', resp);
                            }
                        },
                        error: function () {
                            $list.css('opacity', '1');
                            console.error('Errore di connessione durante il salvataggio');
                        }
                    });
                }
            });
        }
    });

})(jQuery);

