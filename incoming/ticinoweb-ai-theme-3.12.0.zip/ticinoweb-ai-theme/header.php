<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?> id="home">
<?php wp_body_open(); ?>

<header class="site-header">
    <div class="site-branding">
        <a href="<?php echo esc_url(ticinoweb_frontend_url(home_url('/'), 'theme:url:home')); ?>" rel="home">
            <?php 
            $logo = ticinoweb_get_site_logo();
            $site_name = ticinoweb_frontend_text(get_bloginfo('name'), 'theme:branding:site_name');
            if ($logo): 
            ?>
                <img src="<?php echo esc_url($logo); ?>" alt="<?php echo esc_attr($site_name); ?>" class="site-logo">
            <?php else: ?>
                <span class="site-title"><?php echo esc_html($site_name); ?></span>
            <?php endif; ?>
        </a>
    </div>
    <nav class="main-navigation">
        <?php
        wp_nav_menu(array(
            'theme_location' => 'primary',
            'menu_class'     => 'primary-menu',
            'container'      => false,
            'fallback_cb'    => false,
        ));
        ?>
    </nav>
    <?php do_action('ticinoweb_after_primary_navigation'); ?>
</header>
