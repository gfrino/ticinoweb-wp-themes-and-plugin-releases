/**
 * Mobile Admin — Driver: dashboard sul sito (mobile-first, nessuna dipendenza).
 *
 * Tre schede: Disponibili, Le mie consegne, Storico. La lista si aggiorna da sola ogni 15 s
 * (solo con la pagina visibile e online). Tutte le decisioni le prende il server: qui si mostra
 * il risultato, compreso il 409 quando un altro Driver ha preso l'ordine un attimo prima.
 */
(function () {
	'use strict';

	var cfg = window.madrDriver || {};
	var t = cfg.i18n || {};
	var root = document.getElementById('madr-dash');
	if (!root) {
		return;
	}
	var panel = root.querySelector('.madr-panel');
	var tabsEl = root.querySelector('.madr-tabs');
	var availEl = root.querySelector('.madr-avail');
	var toastEl = root.querySelector('.madr-toast');

	var state = { tab: 'available', me: null, available: [], mine: [], history: [], detail: null, busy: false, lastUpdate: null };
	var timer = null;

	function esc(s) {
		return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
			return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
		});
	}

	function api(path, method) {
		return fetch(cfg.rest + path, {
			method: method || 'GET',
			credentials: 'same-origin',
			headers: { 'X-WP-Nonce': cfg.nonce, 'Accept': 'application/json' }
		}).then(function (res) {
			return res.json().catch(function () { return {}; }).then(function (body) {
				if (!res.ok) {
					var err = new Error(body && body.message ? body.message : (t.error || 'Errore'));
					err.status = res.status;
					throw err;
				}
				return body;
			});
		});
	}

	function toast(msg, kind) {
		toastEl.textContent = msg;
		toastEl.className = 'madr-toast' + (kind ? ' madr-toast--' + kind : '');
		toastEl.hidden = false;
		clearTimeout(toast._t);
		toast._t = setTimeout(function () { toastEl.hidden = true; }, 4000);
	}

	function time(iso) {
		if (!iso) { return ''; }
		var d = new Date(iso);
		return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
	}

	function date(iso) {
		if (!iso) { return ''; }
		var d = new Date(iso);
		return d.toLocaleDateString([], { day: '2-digit', month: '2-digit' }) + ' ' + time(iso);
	}

	/* ---------------------------------------------------------------- render */

	function renderAvailability() {
		if (!state.me) { return; }
		var html = '<span class="madr-avail__label">' + esc(t.availability) + '</span><div class="madr-seg">';
		Object.keys(cfg.avail || {}).forEach(function (key) {
			var on = state.me.availability === key;
			html += '<button type="button" role="radio" aria-checked="' + on + '" class="madr-seg__btn madr-seg__btn--' + key + (on ? ' is-on' : '') + '" data-avail="' + key + '">' + esc(cfg.avail[key]) + '</button>';
		});
		availEl.innerHTML = html + '</div>';
	}

	function renderTabs() {
		var tabs = [['available', t.available, state.available.length], ['mine', t.mine, state.mine.length], ['history', t.history, null]];
		tabsEl.innerHTML = tabs.map(function (tab) {
			var on = state.tab === tab[0];
			return '<button type="button" role="tab" aria-selected="' + on + '" class="madr-tab' + (on ? ' is-on' : '') + '" data-tab="' + tab[0] + '">' + esc(tab[1]) + (tab[2] ? ' <span class="madr-badge">' + tab[2] + '</span>' : '') + '</button>';
		}).join('');
	}

	function statusChip(o) {
		return '<span class="madr-chip madr-chip--' + esc(o.status) + '">' + esc(o.status_label) + '</span>';
	}

	function card(o, kind) {
		var addr = [o.address && o.address.street, o.address && o.address.city].filter(Boolean).join(', ');
		var meta = [];
		if (o.slot) { meta.push(esc(t.slot) + ' ' + esc(o.slot)); }
		if (kind === 'history') { meta.push(esc(date(o.delivered_at))); } else if (o.created_at) { meta.push(esc(time(o.created_at))); }
		var html = '<article class="madr-card" data-id="' + o.order_id + '">' +
			'<header class="madr-card__head"><strong class="madr-card__num">#' + esc(o.number) + '</strong>' + statusChip(o) + '</header>' +
			'<p class="madr-card__addr">' + esc(addr) + '</p>' +
			'<p class="madr-card__meta">' + meta.join(' · ') + '</p>';
		if (o.note && kind !== 'history') { html += '<p class="madr-card__note">' + esc(o.note) + '</p>'; }
		if (kind === 'available') {
			html += '<button type="button" class="madr-btn madr-btn--primary madr-btn--block" data-accept="' + o.order_id + '">' + esc(t.accept) + '</button>';
		} else if (kind === 'mine') {
			html += '<button type="button" class="madr-btn madr-btn--block" data-open="' + o.order_id + '">' + esc(t.details) + '</button>';
		}
		return html + '</article>';
	}

	function renderList() {
		var list = state[state.tab] || [];
		var empty = { available: t.noAvailable, mine: t.noMine, history: t.noHistory }[state.tab];
		var html = list.length ? list.map(function (o) { return card(o, state.tab); }).join('') : '<p class="madr-empty">' + esc(empty) + '</p>';
		if (state.lastUpdate && state.tab !== 'history') {
			html += '<p class="madr-muted madr-updated">' + esc(t.updated) + ' ' + esc(time(state.lastUpdate)) + (navigator.onLine === false ? ' — ' + esc(t.offline) : '') + '</p>';
		}
		panel.innerHTML = html;
	}

	function renderDetail(o) {
		var addr = o.address || {};
		var html = '<div class="madr-detail">' +
			'<button type="button" class="madr-link" data-back="1">← ' + esc(t.back) + '</button>' +
			'<header class="madr-card__head"><h3 class="madr-detail__title">' + esc(t.order) + ' #' + esc(o.number) + '</h3>' + statusChip(o) + '</header>' +
			'<p class="madr-detail__addr">' + esc(addr.full || '') + '</p>' +
			(o.slot ? '<p class="madr-card__meta">' + esc(t.slot) + ' ' + esc(o.slot) + '</p>' : '');
		if (o.navigation) {
			html += '<div class="madr-nav">' +
				'<a class="madr-btn madr-btn--nav" href="' + esc(o.navigation.google) + '" target="_blank" rel="noopener">' + esc(t.google) + '</a>' +
				'<a class="madr-btn madr-btn--nav" href="' + esc(o.navigation.apple) + '" target="_blank" rel="noopener">' + esc(t.apple) + '</a></div>';
		}
		if (o.customer) {
			html += '<dl class="madr-dl"><dt>' + esc(t.customer) + '</dt><dd>' + esc(o.customer.name) +
				(o.customer.phone ? ' · <a href="tel:' + esc(o.customer.phone.replace(/[^+\d]/g, '')) + '">' + esc(t.call) + '</a>' : '') + '</dd>';
			html += o.to_collect ? '<dt>' + esc(t.collect) + '</dt><dd class="madr-collect">' + esc(o.to_collect.label) + '</dd>' : '<dt>' + esc(t.collect) + '</dt><dd>' + esc(t.paid) + '</dd>';
			if (o.note) { html += '<dt>' + esc(t.note) + '</dt><dd>' + esc(o.note) + '</dd>'; }
			if (o.items && o.items.length) {
				html += '<dt>' + esc(t.products) + '</dt><dd><ul class="madr-items">' + o.items.map(function (i) { return '<li>' + i.qty + '× ' + esc(i.name) + '</li>'; }).join('') + '</ul></dd>';
			}
			html += '</dl>';
		}
		if (o.status === 'assigned') {
			html += '<p class="madr-hint">' + esc(t.gpsInApp) + '</p>';
		}
		if (o.status === 'assigned' || o.status === 'en_route') {
			html += '<button type="button" class="madr-btn madr-btn--success madr-btn--block madr-btn--big" data-deliver="' + o.order_id + '">' + esc(t.delivered) + '</button>';
		}
		panel.innerHTML = html + '</div>';
		var h = panel.querySelector('.madr-detail__title');
		if (h) { h.setAttribute('tabindex', '-1'); h.focus(); }
	}

	function render() {
		root.removeAttribute('data-loading');
		renderAvailability();
		renderTabs();
		if (state.detail) {
			renderDetail(state.detail);
		} else {
			renderList();
		}
	}

	/* ------------------------------------------------------------------ data */

	function refresh() {
		if (navigator.onLine === false) {
			render();
			return Promise.resolve();
		}
		var jobs = [api('/me'), api('/available'), api('/deliveries?scope=active')];
		if (state.tab === 'history') { jobs.push(api('/deliveries?scope=history')); }
		return Promise.all(jobs).then(function (r) {
			state.me = r[0];
			state.available = r[1].orders || [];
			state.mine = r[2].deliveries || [];
			if (r[3]) { state.history = r[3].deliveries || []; }
			state.lastUpdate = new Date().toISOString();
			if (state.detail) {
				var fresh = state.mine.filter(function (o) { return o.order_id === state.detail.order_id; })[0];
				if (fresh) { state.detail = fresh; } else if (state.detail.status !== 'delivered') { state.detail = null; }
			}
			render();
		}).catch(function (e) {
			if (e.status === 401 || e.status === 403) {
				panel.innerHTML = '<p class="madr-empty">' + esc(e.message) + '</p>';
				stop();
				return;
			}
			toast(e.message, 'error');
		});
	}

	function start() {
		stop();
		timer = setInterval(function () {
			if (document.visibilityState === 'visible' && !state.busy) { refresh(); }
		}, cfg.poll || 15000);
	}

	function stop() {
		if (timer) { clearInterval(timer); timer = null; }
	}

	/* ---------------------------------------------------------------- events */

	root.addEventListener('click', function (ev) {
		var el = ev.target.closest('button, a');
		if (!el || state.busy) { return; }

		if (el.dataset.tab) {
			state.tab = el.dataset.tab;
			state.detail = null;
			render();
			if (state.tab === 'history') { refresh(); }
			return;
		}
		if (el.dataset.avail) {
			state.busy = true;
			fetch(cfg.rest + '/me/availability', {
				method: 'POST', credentials: 'same-origin',
				headers: { 'X-WP-Nonce': cfg.nonce, 'Content-Type': 'application/json' },
				body: JSON.stringify({ availability: el.dataset.avail })
			}).then(function (r) { return r.json(); }).then(function (me) { state.me = me; render(); })
				.catch(function () { toast(t.error, 'error'); })
				.then(function () { state.busy = false; });
			return;
		}
		if (el.dataset.accept) {
			state.busy = true;
			el.disabled = true;
			api('/deliveries/' + el.dataset.accept + '/accept', 'POST').then(function (o) {
				toast(t.accepted, 'ok');
				state.tab = 'mine';
				state.detail = o;
				return refresh();
			}).catch(function (e) {
				toast(e.message, 'error');
				return refresh();
			}).then(function () { state.busy = false; });
			return;
		}
		if (el.dataset.open) {
			var id = parseInt(el.dataset.open, 10);
			state.detail = state.mine.filter(function (o) { return o.order_id === id; })[0] || null;
			render();
			return;
		}
		if (el.dataset.back) {
			state.detail = null;
			render();
			return;
		}
		if (el.dataset.deliver) {
			if (!window.confirm(t.confirmDeliver)) { return; }
			state.busy = true;
			el.disabled = true;
			api('/deliveries/' + el.dataset.deliver + '/delivered', 'POST').then(function () {
				toast(t.deliveredOk, 'ok');
				state.detail = null;
				state.tab = 'mine';
				return refresh();
			}).catch(function (e) {
				toast(e.message, 'error');
				el.disabled = false;
			}).then(function () { state.busy = false; });
		}
	});

	document.addEventListener('visibilitychange', function () {
		if (document.visibilityState === 'visible') { refresh(); }
	});
	window.addEventListener('online', refresh);
	window.addEventListener('offline', render);

	refresh().then(start);
})();
