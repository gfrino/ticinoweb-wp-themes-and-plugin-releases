<?php
/**
 * Sito: dashboard Driver (shortcode [li_driver_dashboard] nella pagina «Driver») e
 * tracking del cliente nella pagina dell'ordine (Il mio account → Ordini → Visualizza).
 *
 * @package mobile-admin
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Crea (una volta) la pagina «Driver» della sede. */
function madr_ensure_page() {
	$page_id = (int) get_option( 'madr_page_id' );
	if ( $page_id && 'trash' !== get_post_status( $page_id ) && get_post( $page_id ) ) {
		return $page_id;
	}
	$page_id = wp_insert_post( array(
		'post_type'    => 'page',
		'post_status'  => 'publish',
		'post_title'   => __( 'Driver', 'wp-app-dashboard' ),
		'post_name'    => 'driver',
		'post_content' => '<!-- wp:shortcode -->[li_driver_dashboard]<!-- /wp:shortcode -->',
	) );
	if ( $page_id && ! is_wp_error( $page_id ) ) {
		update_option( 'madr_page_id', (int) $page_id, false );
		return (int) $page_id;
	}
	return 0;
}

/** Indirizzo della dashboard Driver ('' se la pagina non c'è). Usato dal tema per l'icona nell'header. */
function madr_dashboard_url() {
	$page_id = (int) get_option( 'madr_page_id' );
	return $page_id && get_post( $page_id ) ? (string) get_permalink( $page_id ) : '';
}

/** L'utente collegato vede l'icona Driver nell'header? */
function madr_show_driver_link() {
	return is_user_logged_in() && madr_is_driver() && '' !== madr_dashboard_url();
}

/** La pagina Driver non va nei motori di ricerca né in cache. */
add_filter( 'wp_robots', function ( $robots ) {
	$page_id = (int) get_option( 'madr_page_id' );
	if ( $page_id && is_page( $page_id ) ) {
		$robots['noindex']  = true;
		$robots['nofollow'] = true;
	}
	return $robots;
} );
add_action( 'template_redirect', function () {
	$page_id = (int) get_option( 'madr_page_id' );
	if ( $page_id && is_page( $page_id ) ) {
		do_action( 'litespeed_control_set_nocache', 'mobile-admin driver dashboard' );
		nocache_headers();
	}
} );

function madr_car_svg( $class = '' ) {
	return '<svg class="' . esc_attr( $class ) . '" viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M5.1 17.2H2.7v-4l2.3-1.7 2.7-4.1a2 2 0 0 1 1.7-.9h5.9a2 2 0 0 1 1.6.8l3.2 4.2 2.2.7v5h-1.7M9.6 17.2h5.8"/><path d="M5.9 11.6h14"/><circle cx="7.3" cy="17.3" r="2.1"/><circle cx="17.7" cy="17.3" r="2.1"/></svg>';
}

add_shortcode( 'li_driver_dashboard', 'madr_render_dashboard' );

function madr_render_dashboard() {
	if ( ! is_user_logged_in() ) {
		$login = function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'myaccount' ) : wp_login_url( get_permalink() );
		return '<div class="madr-dash madr-dash--empty"><p>' . esc_html__( 'Accedi con il tuo account per usare l\'area Driver.', 'wp-app-dashboard' ) . '</p><p><a class="madr-btn madr-btn--primary" href="' . esc_url( add_query_arg( 'redirect_to', rawurlencode( get_permalink() ), $login ) ) . '">' . esc_html__( 'Accedi', 'wp-app-dashboard' ) . '</a></p></div>';
	}
	if ( ! madr_is_driver() ) {
		return '<div class="madr-dash madr-dash--empty"><p>' . esc_html__( 'Il tuo account non è abilitato come Driver per questa sede. Se pensi che sia un errore, chiedi al responsabile della sede.', 'wp-app-dashboard' ) . '</p></div>';
	}
	wp_enqueue_style( 'madr-driver', MADR_URL . 'css/driver.css', array(), MADR_VERSION );
	wp_enqueue_script( 'madr-driver', MADR_URL . 'js/driver-dashboard.js', array(), MADR_VERSION, true );
	wp_localize_script( 'madr-driver', 'madrDriver', array(
		'rest'     => esc_url_raw( rest_url( MADR_REST_NS ) ),
		'nonce'    => wp_create_nonce( 'wp_rest' ),
		'poll'     => 15000,
		'statuses' => madr_status_labels(),
		'avail'    => madr_availability_labels(),
		'i18n'     => array(
			'available'      => __( 'Disponibili', 'wp-app-dashboard' ),
			'mine'           => __( 'Le mie consegne', 'wp-app-dashboard' ),
			'history'        => __( 'Storico', 'wp-app-dashboard' ),
			'accept'         => __( 'Accetto consegna', 'wp-app-dashboard' ),
			'accepted'       => __( 'Consegna presa in carico.', 'wp-app-dashboard' ),
			'details'        => __( 'Dettagli', 'wp-app-dashboard' ),
			'back'           => __( 'Indietro', 'wp-app-dashboard' ),
			'delivered'      => __( 'Consegnato', 'wp-app-dashboard' ),
			'confirmDeliver' => __( 'Confermi che l\'ordine è stato consegnato al cliente?', 'wp-app-dashboard' ),
			'deliveredOk'    => __( 'Consegna completata. Grazie!', 'wp-app-dashboard' ),
			'google'         => __( 'Apri in Google Maps', 'wp-app-dashboard' ),
			'apple'          => __( 'Apri in Apple Maps', 'wp-app-dashboard' ),
			'noAvailable'    => __( 'Nessun ordine da consegnare in questo momento. La lista si aggiorna da sola.', 'wp-app-dashboard' ),
			'noMine'         => __( 'Nessuna consegna in corso. Accetta un ordine da «Disponibili».', 'wp-app-dashboard' ),
			'noHistory'      => __( 'Ancora nessuna consegna completata.', 'wp-app-dashboard' ),
			'slot'           => __( 'Fascia', 'wp-app-dashboard' ),
			'note'           => __( 'Note del cliente', 'wp-app-dashboard' ),
			'customer'       => __( 'Cliente', 'wp-app-dashboard' ),
			'call'           => __( 'Chiama', 'wp-app-dashboard' ),
			'collect'        => __( 'Da incassare', 'wp-app-dashboard' ),
			'paid'           => __( 'Già pagato', 'wp-app-dashboard' ),
			'products'       => __( 'Prodotti', 'wp-app-dashboard' ),
			'order'          => __( 'Ordine', 'wp-app-dashboard' ),
			'gpsInApp'       => __( 'Per far seguire l\'auto al cliente avvia la consegna dall\'app: lì il GPS resta attivo anche con Google Maps aperto.', 'wp-app-dashboard' ),
			'error'          => __( 'Qualcosa non ha funzionato. Riprova.', 'wp-app-dashboard' ),
			'offline'        => __( 'Sei offline: la lista non si aggiorna.', 'wp-app-dashboard' ),
			'updated'        => __( 'Aggiornato', 'wp-app-dashboard' ),
			'availability'   => __( 'La tua disponibilità', 'wp-app-dashboard' ),
		),
	) );
	ob_start();
	?>
	<div class="madr-dash" id="madr-dash" data-loading="1">
		<div class="madr-dash__head">
			<span class="madr-dash__icon"><?php echo madr_car_svg(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- SVG statico. ?></span>
			<div class="madr-dash__heading">
				<h2 class="madr-dash__title"><?php esc_html_e( 'Area Driver', 'wp-app-dashboard' ); ?></h2>
				<p class="madr-dash__eyebrow"><?php echo esc_html( get_bloginfo( 'name' ) ); ?></p>
			</div>
		</div>
		<div class="madr-avail" role="radiogroup" aria-label="<?php esc_attr_e( 'La tua disponibilità', 'wp-app-dashboard' ); ?>"></div>
		<div class="madr-tabs" role="tablist"></div>
		<div class="madr-panel" aria-live="polite"><p class="madr-muted"><?php esc_html_e( 'Caricamento…', 'wp-app-dashboard' ); ?></p></div>
		<div class="madr-toast" role="status" hidden></div>
		<noscript><?php esc_html_e( 'Per usare l\'area Driver serve JavaScript.', 'wp-app-dashboard' ); ?></noscript>
	</div>
	<?php
	return (string) ob_get_clean();
}

/* ------------------------------------------------------- Tracking del cliente */

add_action( 'woocommerce_order_details_before_order_table', 'madr_render_customer_tracking', 5 );

function madr_render_customer_tracking( $order ) {
	if ( ! $order instanceof WC_Order || ! madr_user_can_track( $order ) || ! madr_is_home_delivery( $order ) ) {
		return;
	}
	$row = madr_get_delivery( $order->get_id() );
	if ( ! $row || in_array( $row->status, array( MADR_STATUS_WAITING, MADR_STATUS_CANCELLED ), true ) ) {
		return;
	}
	$config = madr_firebase_web_config();
	wp_enqueue_style( 'madr-driver', MADR_URL . 'css/driver.css', array(), MADR_VERSION );
	$live = $config && in_array( $row->status, madr_active_statuses(), true );
	if ( $live ) {
		// Leaflet incluso nel plugin (licenza BSD-2 in assets/vendor/leaflet): nessuna richiesta a CDN esterni.
		wp_enqueue_style( 'madr-leaflet', MADR_URL . 'vendor/leaflet/leaflet.css', array(), '1.9.4' );
		wp_enqueue_script( 'madr-leaflet', MADR_URL . 'vendor/leaflet/leaflet.js', array(), '1.9.4', true );
		wp_enqueue_script_module( 'madr-tracking', MADR_URL . 'js/tracking.js', array(), MADR_VERSION );
		do_action( 'litespeed_control_set_nocache', 'mobile-admin driver tracking' );
	}
	$data = array(
		'rest'      => esc_url_raw( rest_url( MADR_REST_NS ) ),
		'nonce'     => wp_create_nonce( 'wp_rest' ),
		'orderId'   => (int) $order->get_id(),
		'docId'     => madr_tracking_doc_id( $order->get_id() ),
		'status'    => $row->status,
		'firebase'  => $config,
		'emulator'  => defined( 'MADR_FIREBASE_EMULATOR' ) ? (string) MADR_FIREBASE_EMULATOR : '',
		// Carta nazionale grigia di swisstopo, dove l'auto risalta (servizio federale svizzero, dati aperti con attribuzione): le richieste
		// delle tessere restano in Svizzera. Sostituibile con il filtro madr_map_tiles.
		'tiles'     => apply_filters( 'madr_map_tiles', 'https://wmts.geo.admin.ch/1.0.0/ch.swisstopo.pixelkarte-grau/default/current/3857/{z}/{x}/{y}.jpeg' ),
		'tilesAttribution' => apply_filters( 'madr_map_tiles_attribution', '&copy; swisstopo' ),
		'statuses'  => madr_status_labels(),
		'i18n'      => array(
			'stale'     => __( 'Posizione non aggiornata da %s min', 'wp-app-dashboard' ),
			'waitGps'   => __( 'In attesa della posizione del Driver…', 'wp-app-dashboard' ),
			'delivered' => __( 'Il tuo ordine è stato consegnato. Buon appetito!', 'wp-app-dashboard' ),
			'cancelled' => __( 'La consegna è stata annullata.', 'wp-app-dashboard' ),
			'driver'    => __( 'Il tuo Driver', 'wp-app-dashboard' ),
			'home'      => __( 'Consegna qui', 'wp-app-dashboard' ),
			'offline'   => __( 'Connessione assente: la mappa riprende da sola.', 'wp-app-dashboard' ),
			'error'     => __( 'Mappa non disponibile in questo momento.', 'wp-app-dashboard' ),
		),
	);
	$steps = array( MADR_STATUS_ASSIGNED, MADR_STATUS_EN_ROUTE, MADR_STATUS_DELIVERED );
	$index = array_search( $row->status, $steps, true );
	?>
	<section class="madr-track" id="madr-track" data-config="<?php echo esc_attr( wp_json_encode( $data ) ); ?>">
		<h2 class="madr-track__title"><?php esc_html_e( 'La tua consegna', 'wp-app-dashboard' ); ?></h2>
		<ol class="madr-steps">
			<?php foreach ( $steps as $i => $step ) : ?>
				<li class="madr-steps__item<?php echo false !== $index && $i <= $index ? ' is-done' : ''; ?><?php echo $i === $index ? ' is-current' : ''; ?>" data-step="<?php echo esc_attr( $step ); ?>"><?php echo esc_html( madr_status_label( $step ) ); ?></li>
			<?php endforeach; ?>
		</ol>
		<?php if ( MADR_STATUS_DELIVERED === $row->status ) : ?>
			<p class="madr-track__done"><?php esc_html_e( 'Il tuo ordine è stato consegnato. Buon appetito!', 'wp-app-dashboard' ); ?></p>
		<?php elseif ( $live ) : ?>
			<div class="madr-track__map" id="madr-track-map" role="img" aria-label="<?php esc_attr_e( 'Mappa con la posizione del Driver', 'wp-app-dashboard' ); ?>"></div>
			<p class="madr-track__info" id="madr-track-info"><?php esc_html_e( 'In attesa della posizione del Driver…', 'wp-app-dashboard' ); ?></p>
		<?php endif; ?>
	</section>
	<?php
}
