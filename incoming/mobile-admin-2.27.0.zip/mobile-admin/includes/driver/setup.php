<?php
/**
 * Driver — ruolo, tabelle e impostazioni. Caricato solo dove il Driver è acceso (driver.php).
 *
 * Ogni sede (sottosito del multisite) ha i suoi ordini WooCommerce: le tabelle delle consegne
 * sono per sede ($wpdb->prefix) e anche il ruolo `driver` è per sede, come i ruoli di WordPress.
 *
 * @package mobile-admin
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Capacità che apre l'area Driver (sito, app, API). */
const MADR_CAP = 'madr_deliver';

/** Stati della consegna, separati dagli stati commerciali dell'ordine WooCommerce. */
const MADR_STATUS_WAITING   = 'waiting';   // In attesa di assegnazione.
const MADR_STATUS_ASSIGNED  = 'assigned';  // Preso in carico.
const MADR_STATUS_EN_ROUTE  = 'en_route';  // In consegna (tracking attivo).
const MADR_STATUS_DELIVERED = 'delivered'; // Consegnato.
const MADR_STATUS_CANCELLED = 'cancelled'; // Ordine annullato.

/** Etichette leggibili degli stati della consegna. */
function madr_status_labels() {
	return array(
		MADR_STATUS_WAITING   => __( 'In attesa di assegnazione', 'wp-app-dashboard' ),
		MADR_STATUS_ASSIGNED  => __( 'Preso in carico', 'wp-app-dashboard' ),
		MADR_STATUS_EN_ROUTE  => __( 'In consegna', 'wp-app-dashboard' ),
		MADR_STATUS_DELIVERED => __( 'Consegnato', 'wp-app-dashboard' ),
		MADR_STATUS_CANCELLED => __( 'Annullato', 'wp-app-dashboard' ),
	);
}

function madr_status_label( $status ) {
	$labels = madr_status_labels();
	return isset( $labels[ $status ] ) ? $labels[ $status ] : (string) $status;
}

/** Stati attivi: il Driver ha la consegna in mano. */
function madr_active_statuses() {
	return array( MADR_STATUS_ASSIGNED, MADR_STATUS_EN_ROUTE );
}

/** Disponibilità del Driver. */
function madr_availability_labels() {
	return array(
		'available' => __( 'Disponibile', 'wp-app-dashboard' ),
		'busy'      => __( 'Occupato', 'wp-app-dashboard' ),
		'off'       => __( 'Non disponibile', 'wp-app-dashboard' ),
	);
}

function madr_table( $name ) {
	global $wpdb;
	return $wpdb->prefix . 'madr_' . $name;
}

/** Tabelle e ruolo della sede corrente (idempotente). */
function madr_install_site() {
	global $wpdb;
	require_once ABSPATH . 'wp-admin/includes/upgrade.php';
	$charset    = $wpdb->get_charset_collate();
	$deliveries = madr_table( 'deliveries' );
	$events     = madr_table( 'events' );

	dbDelta( "CREATE TABLE {$deliveries} (
		order_id bigint(20) unsigned NOT NULL,
		driver_id bigint(20) unsigned DEFAULT NULL,
		status varchar(20) NOT NULL DEFAULT 'waiting',
		accepted_at datetime DEFAULT NULL,
		started_at datetime DEFAULT NULL,
		delivered_at datetime DEFAULT NULL,
		cancelled_at datetime DEFAULT NULL,
		dest_lat decimal(9,6) DEFAULT NULL,
		dest_lng decimal(9,6) DEFAULT NULL,
		sync_error varchar(190) DEFAULT NULL,
		updated_at datetime NOT NULL,
		PRIMARY KEY  (order_id),
		KEY driver_status (driver_id,status),
		KEY status (status)
	) {$charset};" );

	dbDelta( "CREATE TABLE {$events} (
		id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
		order_id bigint(20) unsigned NOT NULL,
		driver_id bigint(20) unsigned DEFAULT NULL,
		actor_id bigint(20) unsigned DEFAULT NULL,
		event varchar(30) NOT NULL,
		note varchar(255) DEFAULT NULL,
		created_at datetime NOT NULL,
		PRIMARY KEY  (id),
		KEY order_id (order_id),
		KEY driver_id (driver_id)
	) {$charset};" );

	madr_register_role();
	update_option( 'madr_db_version', MADR_DB_VERSION, false );
}

/** Ruolo `driver`: legge e consegna, nient'altro. Si aggiunge al ruolo che l'utente ha già (cliente). */
function madr_register_role() {
	if ( ! get_role( 'driver' ) ) {
		add_role( 'driver', __( 'Driver', 'wp-app-dashboard' ), array( 'read' => true, MADR_CAP => true ) );
	} elseif ( ! get_role( 'driver' )->has_cap( MADR_CAP ) ) {
		get_role( 'driver' )->add_cap( MADR_CAP );
	}
	// Gli amministratori possono aprire la dashboard per supervisione.
	$admin = get_role( 'administrator' );
	if ( $admin && ! $admin->has_cap( MADR_CAP ) ) {
		$admin->add_cap( MADR_CAP );
	}
}

/** Prepara la sede la prima volta che il Driver vi è acceso, e dopo ogni cambio delle tabelle. */
add_action( 'init', function () {
	if ( get_option( 'madr_db_version' ) !== MADR_DB_VERSION ) {
		madr_install_site();
	}
}, 5 );

/** Il Driver ha il ruolo nella sede corrente (lo controlla sempre il server). */
function madr_is_driver( $user_id = 0 ) {
	$user_id = $user_id ? (int) $user_id : get_current_user_id();
	return $user_id > 0 && user_can( $user_id, MADR_CAP );
}

/**
 * Impostazioni della sede, con i valori predefiniti.
 *
 * - statuses: stati WooCommerce in cui un ordine «a domicilio» è pronto per un Driver.
 *   «completed» è incluso perché tw-woocommerce-order-status chiude da solo gli ordini dopo 30 minuti.
 * - max_age_hours: ordini più vecchi non compaiono tra i disponibili.
 * - max_active: consegne contemporanee per Driver (0 = senza limite).
 */
function madr_settings() {
	$defaults = array(
		'statuses'      => array( 'processing', 'completed' ),
		'max_age_hours' => 8,
		'max_active'    => 3,
		'firebase'      => array( 'apiKey' => '', 'authDomain' => '', 'projectId' => '', 'appId' => '' ),
	);
	$saved = get_option( 'madr_settings', array() );
	$s     = wp_parse_args( is_array( $saved ) ? $saved : array(), $defaults );
	$s['statuses']      = array_values( array_filter( array_map( 'sanitize_key', (array) $s['statuses'] ) ) );
	$s['max_age_hours'] = max( 1, (int) $s['max_age_hours'] );
	$s['max_active']    = max( 0, (int) $s['max_active'] );
	$s['firebase']      = wp_parse_args( is_array( $s['firebase'] ) ? $s['firebase'] : array(), $defaults['firebase'] );
	return $s;
}

/**
 * Identificativo della sede, lo stesso che usano app e Cloud Functions (`siteId`):
 * l'host del sito senza protocollo e senza barra finale, es. «bellinzona.littleinka.ch».
 */
function madr_site_id() {
	$url = untrailingslashit( preg_replace( '#^https?://#i', '', home_url() ) );
	return (string) apply_filters( 'madr_site_id', $url );
}

/** Documento Firestore della consegna (niente «/» nell'ID). */
function madr_tracking_doc_id( $order_id ) {
	return str_replace( array( '/', ':' ), '_', madr_site_id() ) . '__' . (int) $order_id;
}

/** Data/ora MySQL in UTC. */
function madr_now() {
	return gmdate( 'Y-m-d H:i:s' );
}

/** Data MySQL UTC → ISO 8601, per API e JavaScript. */
function madr_iso( $mysql ) {
	return $mysql ? gmdate( 'c', strtotime( $mysql . ' UTC' ) ) : null;
}
