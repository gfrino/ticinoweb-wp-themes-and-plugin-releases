/**
 * ticinoWEB CMS - backend moderno (3.14.0).
 *
 * Raccoglie gli avvisi informativi e promozionali dei plugin in un pannello
 * richiudibile sopra il contenuto. Restano sempre in vista: errori, conferme
 * di salvataggio, avvisi dentro i moduli e quelli nascosti di proposito.
 * Lo stato aperto/chiuso e' ricordato nel browser.
 */
(function () {
  'use strict';

  var cfg = window.ticinowebAdminUI || {};
  var s = cfg.strings || {};
  var KEY = 'twaNoticesOpen';

  function remember(open) {
    try { window.localStorage.setItem(KEY, open ? '1' : '0'); } catch (e) {}
  }
  function remembered() {
    try { return window.localStorage.getItem(KEY) === '1'; } catch (e) { return false; }
  }

  function keepVisible(n) {
    var c = n.classList;
    if (c.contains('notice-error') || c.contains('notice-success')) return true;
    if (c.contains('error') && !c.contains('notice-info') && !c.contains('notice-warning')) return true;
    if (c.contains('updated') && !c.contains('notice')) return true; // conferme classiche di WordPress
    if (c.contains('inline') || c.contains('hidden')) return true;
    if (n.id === 'message' || n.id === 'setting-error-settings_updated') return true;
    if (n.closest('form, .twa-notices-panel, #screen-meta')) return true;
    return n.offsetParent === null; // gia' nascosto
  }

  function run() {
    var content = document.getElementById('wpbody-content');
    if (!content) return;

    var nodes = Array.prototype.filter.call(
      content.querySelectorAll('.notice, .update-nag, div.updated, div.error'),
      function (n) { return !keepVisible(n); }
    );
    if (!nodes.length) return;

    var panel = document.createElement('div');
    panel.className = 'twa-notices-panel';

    var toggle = document.createElement('button');
    toggle.type = 'button';
    toggle.className = 'twa-notices-toggle';

    var label = document.createElement('span');
    label.textContent = (s.panel || 'Avvisi dei plugin (%d)').replace('%d', nodes.length);
    var action = document.createElement('span');
    action.className = 'twa-notices-action';

    toggle.appendChild(label);
    toggle.appendChild(action);

    var list = document.createElement('div');
    list.className = 'twa-notices-list';
    list.id = 'twa-notices-list';
    toggle.setAttribute('aria-controls', list.id);

    nodes.forEach(function (n) { list.appendChild(n); });

    function setOpen(open) {
      list.hidden = !open;
      toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
      action.textContent = open ? (s.hide || 'Nascondi') : (s.show || 'Mostra');
      panel.classList.toggle('is-open', open);
    }
    toggle.addEventListener('click', function () {
      var open = list.hidden;
      setOpen(open);
      remember(open);
    });
    setOpen(remembered());

    panel.appendChild(toggle);
    panel.appendChild(list);

    var wrap = content.querySelector('.wrap') || content;
    var anchor = wrap.querySelector('.wp-header-end');
    if (anchor && anchor.parentNode) {
      anchor.parentNode.insertBefore(panel, anchor.nextSibling);
    } else {
      wrap.insertBefore(panel, wrap.firstChild);
    }
  }

  // Dopo che WordPress ha spostato gli avvisi sotto il titolo (common.js, al DOM ready).
  if (document.readyState === 'complete') {
    run();
  } else {
    window.addEventListener('load', run);
  }
})();
