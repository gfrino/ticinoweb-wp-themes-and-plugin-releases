<?php
/**
 * Backend WordPress moderno (3.14.0).
 *
 * Tre parti, sempre attive sui siti che usano il tema:
 * 1. Stile: menu, barra, bacheca, tabelle, pulsanti, campi e avvisi in uno
 *    stile moderno e coerente (assets/css/admin-ui.css). Il colore d'accento
 *    e' il colore principale del sito (ticinoWEB CMS > palette), reso
 *    leggibile se troppo chiaro.
 * 2. Bacheca: via i widget di poco valore, nuovo widget "Ultimi messaggi
 *    ricevuti", ordine iniziale con in alto le informazioni utili (finche'
 *    l'utente non riordina la bacheca a modo suo).
 * 3. Performance: Heartbeat a 60 s fuori dall'editor, niente script emoji,
 *    avvisi informativi dei plugin raccolti in un pannello richiudibile
 *    (assets/js/admin-ui.js); errori e conferme restano visibili.
 *
 * Multisite: il file e' caricato solo dai siti che usano il tema (functions.php
 * del tema attivo). In piu' non si applica alla bacheca di rete ne' a quella
 * utente, che servono anche i siti con altri temi.
 *
 * Filtri: ticinoweb_admin_ui_enabled, ticinoweb_admin_ui_accent,
 *         ticinoweb_admin_hidden_dashboard_widgets, ticinoweb_admin_notices_panel.
 *
 * @package ticinoweb-ai-theme
 * @since 3.14.0
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Il backend moderno vale per la bacheca del sito corrente.
 *
 * @return bool
 */
function ticinoweb_admin_ui_enabled() {
    $enabled = is_admin() && !is_network_admin() && !is_user_admin();
    return (bool) apply_filters('ticinoweb_admin_ui_enabled', $enabled);
}

/**
 * Colore d'accento: il colore principale del sito, scurito se il testo
 * bianco non sarebbe leggibile (contrasto WCAG AA 4.5:1).
 *
 * @return string Esadecimale #rrggbb.
 */
function ticinoweb_admin_ui_accent() {
    $color = sanitize_hex_color((string) get_option('ticinoweb_palette_primary', ''));
    if (!$color) {
        $color = '#2563eb';
    }
    $color = (string) apply_filters('ticinoweb_admin_ui_accent', $color);

    $hex = ltrim($color, '#');
    if (strlen($hex) === 3) {
        $hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
    }
    if (!preg_match('/^[0-9a-fA-F]{6}$/', $hex)) {
        return '#2563eb';
    }
    $rgb = array(hexdec(substr($hex, 0, 2)), hexdec(substr($hex, 2, 2)), hexdec(substr($hex, 4, 2)));

    for ($i = 0; $i < 20 && ticinoweb_admin_ui_contrast_with_white($rgb) < 4.5; $i++) {
        $rgb = array_map(function ($c) {
            return (int) floor($c * 0.9);
        }, $rgb);
    }

    return sprintf('#%02x%02x%02x', $rgb[0], $rgb[1], $rgb[2]);
}

/**
 * Rapporto di contrasto fra un colore e il bianco.
 *
 * @param int[] $rgb Componenti 0-255.
 * @return float
 */
function ticinoweb_admin_ui_contrast_with_white($rgb) {
    $lin = array_map(function ($c) {
        $c = $c / 255;
        return $c <= 0.03928 ? $c / 12.92 : pow(($c + 0.055) / 1.055, 2.4);
    }, $rgb);
    $lum = 0.2126 * $lin[0] + 0.7152 * $lin[1] + 0.0722 * $lin[2];
    return 1.05 / ($lum + 0.05);
}

/* ------------------------------------------------------------------ */
/* 1. Stile e script                                                   */
/* ------------------------------------------------------------------ */

add_action('admin_enqueue_scripts', 'ticinoweb_admin_ui_assets', 20);
function ticinoweb_admin_ui_assets() {
    if (!ticinoweb_admin_ui_enabled()) {
        return;
    }
    // L'editor a blocchi ha la sua interfaccia: non la tocchiamo.
    $screen = function_exists('get_current_screen') ? get_current_screen() : null;
    if ($screen && method_exists($screen, 'is_block_editor') && $screen->is_block_editor()) {
        return;
    }

    $dir = get_template_directory();
    $uri = get_template_directory_uri();

    wp_enqueue_style('ticinoweb-admin-ui', $uri . '/assets/css/admin-ui.css', array(), (string) filemtime($dir . '/assets/css/admin-ui.css'));

    $accent = ticinoweb_admin_ui_accent();
    $hex    = ltrim($accent, '#');
    $soft   = sprintf('rgba(%d, %d, %d, 0.12)', hexdec(substr($hex, 0, 2)), hexdec(substr($hex, 2, 2)), hexdec(substr($hex, 4, 2)));
    wp_add_inline_style('ticinoweb-admin-ui', ':root{--twa-accent:' . $accent . ';--twa-accent-soft:' . $soft . ';}');

    if (apply_filters('ticinoweb_admin_notices_panel', true)) {
        wp_enqueue_script('ticinoweb-admin-ui', $uri . '/assets/js/admin-ui.js', array(), (string) filemtime($dir . '/assets/js/admin-ui.js'), true);
        wp_localize_script('ticinoweb-admin-ui', 'ticinowebAdminUI', array(
            'strings' => array(
                /* translators: %d: numero di avvisi */
                'panel'  => __('Avvisi dei plugin (%d)', 'ticinoweb-ai-theme'),
                'show'   => __('Mostra', 'ticinoweb-ai-theme'),
                'hide'   => __('Nascondi', 'ticinoweb-ai-theme'),
            ),
        ));
    }
}

// Font Manrope: precarica il file dei caratteri latini, cosi' il testo non cambia font dopo il caricamento.
add_action('admin_head', 'ticinoweb_admin_ui_preload_font', 1);
function ticinoweb_admin_ui_preload_font() {
    if (!ticinoweb_admin_ui_enabled()) {
        return;
    }
    $screen = function_exists('get_current_screen') ? get_current_screen() : null;
    if ($screen && method_exists($screen, 'is_block_editor') && $screen->is_block_editor()) {
        return;
    }
    printf(
        '<link rel="preload" href="%s" as="font" type="font/woff2" crossorigin>' . "\n",
        esc_url(get_template_directory_uri() . '/assets/fonts/manrope/manrope-latin-wght-normal.woff2')
    );
}

/* ------------------------------------------------------------------ */
/* 2. Bacheca                                                          */
/* ------------------------------------------------------------------ */

/**
 * Widget nascosti di default: notizie WordPress, bozza rapida, salute del
 * sito (resta in Strumenti > Salute del sito), widget Jetpack di
 * promozione e statistiche doppie, recensioni WooCommerce.
 *
 * @return string[]
 */
function ticinoweb_admin_hidden_dashboard_widgets() {
    return (array) apply_filters('ticinoweb_admin_hidden_dashboard_widgets', array(
        'dashboard_primary',
        'dashboard_quick_press',
        'dashboard_site_health',
        'wpcom_daily_writing_prompt',
        'jetpack_newsletter_dashboard_widget',
        'jetpack_summary_widget',
        'woocommerce_dashboard_recent_reviews',
    ));
}

add_action('wp_dashboard_setup', 'ticinoweb_admin_ui_dashboard', 999);
function ticinoweb_admin_ui_dashboard() {
    if (!ticinoweb_admin_ui_enabled()) {
        return;
    }
    remove_action('welcome_panel', 'wp_welcome_panel');

    if (current_user_can('edit_pages')) {
        wp_add_dashboard_widget(
            'ticinoweb_latest_submissions',
            __('Ultimi messaggi ricevuti', 'ticinoweb-ai-theme'),
            'ticinoweb_admin_ui_submissions_widget'
        );
    }
}

// Alcuni plugin registrano i widget piu' tardi: si tolgono appena prima della stampa.
add_action('do_meta_boxes', 'ticinoweb_admin_ui_remove_widgets', 999, 2);
function ticinoweb_admin_ui_remove_widgets($screen, $context) {
    if ('dashboard' !== $screen || !ticinoweb_admin_ui_enabled()) {
        return;
    }
    foreach (ticinoweb_admin_hidden_dashboard_widgets() as $id) {
        remove_meta_box($id, 'dashboard', $context);
    }
}

/**
 * Ordine iniziale della bacheca, finche' l'utente non la riordina.
 */
add_filter('get_user_option_meta-box-order_dashboard', 'ticinoweb_admin_ui_dashboard_order');
function ticinoweb_admin_ui_dashboard_order($order) {
    if (!empty($order) || !ticinoweb_admin_ui_enabled()) {
        return $order;
    }
    return array(
        'normal'  => 'woocommerce_dashboard_status,ticinoweb_visits_widget',
        'side'    => 'ticinoweb_latest_submissions,dashboard_right_now,dashboard_activity',
        'column3' => '',
        'column4' => '',
    );
}

/**
 * Widget "Ultimi messaggi ricevuti": gli ultimi 5 invii dei moduli del sito.
 */
function ticinoweb_admin_ui_submissions_widget() {
    global $wpdb;
    $table = $wpdb->prefix . 'ticinoweb_form_submissions';
    $page  = admin_url('admin.php?page=ticinoweb-submissions');

    $exists = $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $wpdb->esc_like($table)));
    $rows   = $exists ? $wpdb->get_results("SELECT id, data_invio, nome, oggetto, letto FROM {$table} ORDER BY data_invio DESC LIMIT 5") : array(); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- nome tabella dal prefisso, nessun input

    if (empty($rows)) {
        echo '<p class="twa-empty">' . esc_html__('Nessun messaggio ricevuto finora. Ogni invio dei moduli del sito compare qui e in Invii Ricevuti.', 'ticinoweb-ai-theme') . '</p>';
        return;
    }

    echo '<ul class="twa-submissions">';
    foreach ($rows as $row) {
        $when    = mysql2date(get_option('date_format') . ' ' . get_option('time_format'), $row->data_invio);
        $subject = $row->oggetto !== '' ? $row->oggetto : __('(senza oggetto)', 'ticinoweb-ai-theme');
        printf(
            '<li class="%1$s"><a href="%2$s"><strong>%3$s</strong><span>%4$s</span><time>%5$s</time></a></li>',
            $row->letto ? 'is-read' : 'is-unread',
            esc_url($page),
            esc_html($row->nome),
            esc_html($subject),
            esc_html($when)
        );
    }
    echo '</ul>';
    echo '<p class="twa-widget-footer"><a class="button" href="' . esc_url($page) . '">' . esc_html__('Vai a Invii Ricevuti', 'ticinoweb-ai-theme') . '</a></p>';
}

/* ------------------------------------------------------------------ */
/* 3. Performance                                                      */
/* ------------------------------------------------------------------ */

// Heartbeat: 60 s fuori dall'editor (nell'editor servono salvataggi automatici e blocchi).
add_filter('heartbeat_settings', 'ticinoweb_admin_ui_heartbeat');
function ticinoweb_admin_ui_heartbeat($settings) {
    if (!ticinoweb_admin_ui_enabled()) {
        return $settings;
    }
    global $pagenow;
    if (!in_array($pagenow, array('post.php', 'post-new.php'), true)) {
        $settings['interval'] = 60;
    }
    return $settings;
}

// Niente rilevamento emoji nel backend: i browser moderni le mostrano da soli.
add_action('admin_init', 'ticinoweb_admin_ui_disable_emoji');
function ticinoweb_admin_ui_disable_emoji() {
    if (!ticinoweb_admin_ui_enabled()) {
        return;
    }
    remove_action('admin_print_scripts', 'print_emoji_detection_script');
    remove_action('admin_print_styles', 'print_emoji_styles');
    remove_action('admin_enqueue_scripts', 'wp_enqueue_emoji_styles');
}

/**
 * ticinoWEB CMS sempre secondo nel menu laterale, subito sotto Bacheca.
 */
add_filter('custom_menu_order', '__return_true', 999);
add_filter('menu_order', 'ticinoweb_admin_ui_menu_order', 999);
function ticinoweb_admin_ui_menu_order($menu_order) {
    if (!is_array($menu_order)) {
        return $menu_order;
    }
    $cms = 'ticinoweb-cms';
    $pos = array_search($cms, $menu_order, true);
    if ($pos === false) {
        return $menu_order;
    }
    unset($menu_order[$pos]);
    $menu_order = array_values($menu_order);
    $dash = array_search('index.php', $menu_order, true);
    $at   = $dash === false ? 0 : $dash + 1;
    array_splice($menu_order, $at, 0, array($cms));
    return $menu_order;
}

/*
 * Admin Menu Editor (Pro), quando il sito ha un menu personalizzato, ricostruisce
 * il menu dopo il filtro menu_order (filtro submenu_file, priorita' 1001):
 * si riapplica lo spostamento subito dopo, cosi' vale anche con AME attivo.
 */
add_filter('submenu_file', 'ticinoweb_admin_ui_menu_cms_second', PHP_INT_MAX);
function ticinoweb_admin_ui_menu_cms_second($submenu_file) {
    global $menu;
    if (empty($menu) || !is_array($menu)) {
        return $submenu_file;
    }
    $cms_key = null;
    foreach ($menu as $key => $item) {
        if (isset($item[2]) && $item[2] === 'ticinoweb-cms') {
            $cms_key = $key;
            break;
        }
    }
    if ($cms_key === null) {
        return $submenu_file;
    }
    $cms = $menu[$cms_key];
    unset($menu[$cms_key]);
    $ordered = array();
    $placed  = false;
    foreach ($menu as $item) {
        $ordered[] = $item;
        if (!$placed && isset($item[2]) && $item[2] === 'index.php') {
            $ordered[] = $cms;
            $placed    = true;
        }
    }
    if (!$placed) {
        array_unshift($ordered, $cms);
    }
    $menu = $ordered;
    return $submenu_file;
}
