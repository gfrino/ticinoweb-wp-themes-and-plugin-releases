<?php
/**
 * «Invii Ricevuti»: i messaggi dei moduli del sito, come voce del menu di sinistra
 * (prima era un tab dentro ticinoWEB CMS). Stessa tabella, stesse azioni.
 *
 * @package ticinoweb-ai-theme
 */

if (!defined('ABSPATH')) {
    exit;
}

add_action('admin_menu', 'ticinoweb_add_submissions_menu');
function ticinoweb_add_submissions_menu() {
    add_menu_page(
        __('Invii Ricevuti', 'ticinoweb-ai-theme'),
        __('Invii Ricevuti', 'ticinoweb-ai-theme'),
        'edit_pages',
        'ticinoweb-submissions',
        'ticinoweb_render_submissions_page',
        'dashicons-email-alt',
        31
    );
}

add_action('admin_enqueue_scripts', function ($hook) {
    if ($hook === 'toplevel_page_ticinoweb-submissions') {
        wp_enqueue_style('ticinoweb-admin-modern', get_template_directory_uri() . '/assets/css/admin-modern.css', array(), defined('TICINOWEB_THEME_VERSION') ? TICINOWEB_THEME_VERSION : '3.1.5');
    }
});

function ticinoweb_render_submissions_page() {
    if (!current_user_can('edit_pages')) {
        wp_die(__('Permessi insufficienti.', 'ticinoweb-ai-theme'));
    }
    ?>
    <div class="wrap">
        <h1><?php esc_html_e('Invii Ricevuti', 'ticinoweb-ai-theme'); ?></h1>
        <div id="form-submissions" class="ticinoweb-tab-content" style="display:block;">
                                <p class="description"><?php _e('Cronologia dei messaggi ricevuti dal form contatti.', 'ticinoweb-ai-theme'); ?></p>
                
                <?php
                global $wpdb;
                $table_name = $wpdb->prefix . 'ticinoweb_form_submissions';
                
                // Get page size from query parameter or default to 10
                $per_page_options = array(10, 20, 50, 100);
                $per_page = isset($_GET['per_page']) ? intval($_GET['per_page']) : 10;
                if (!in_array($per_page, $per_page_options)) {
                    $per_page = 10;
                }
                
                // Get total submissions
                $total_items = intval($wpdb->get_var("SELECT COUNT(*) FROM $table_name"));
                $total_pages = ceil($total_items / $per_page);
                
                // Get current page
                $current_page = isset($_GET['sub_paged']) ? intval($_GET['sub_paged']) : 1;
                $current_page = max(1, min($total_pages ? $total_pages : 1, $current_page));
                
                // Calculate offset
                $offset = ($current_page - 1) * $per_page;
                
                // Get paginated submissions
                $submissions = $wpdb->get_results($wpdb->prepare(
                    "SELECT * FROM $table_name ORDER BY data_invio DESC LIMIT %d OFFSET %d",
                    $per_page,
                    $offset
                ));
                
                if ($submissions && count($submissions) > 0):
                ?>
                    <div class="submission-actions" style="margin: 10px 0 15px; display: flex; align-items: center; gap: 10px;">
                        <button type="button" id="delete-selected-submissions" class="button button-secondary" disabled><?php _e('Elimina selezionati', 'ticinoweb-ai-theme'); ?></button>
                        <span id="submission-delete-feedback" style="color: #2271b1;"></span>
                    </div>

                    <div style="margin-top: 20px; overflow-x: auto;">
                        <table class="widefat striped">
                            <thead>
                                <tr>
                                    <th style="width: 32px; text-align: center;"><input type="checkbox" id="select-all-submissions"></th>
                                    <th><?php _e('Data', 'ticinoweb-ai-theme'); ?></th>
                                    <th><?php _e('Nome', 'ticinoweb-ai-theme'); ?></th>
                                    <th><?php _e('Email', 'ticinoweb-ai-theme'); ?></th>
                                    <th><?php _e('Telefono', 'ticinoweb-ai-theme'); ?></th>
                                    <th><?php _e('Oggetto', 'ticinoweb-ai-theme'); ?></th>
                                    <th><?php _e('Messaggio', 'ticinoweb-ai-theme'); ?></th>
                                    <th><?php _e('Stato', 'ticinoweb-ai-theme'); ?></th>
                                    <th><?php _e('Azioni', 'ticinoweb-ai-theme'); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($submissions as $submission): ?>
                                    <tr class="submission-row"
                                        data-id="<?php echo esc_attr($submission->id); ?>"
                                        data-nome="<?php echo esc_attr($submission->nome); ?>"
                                        data-email="<?php echo esc_attr($submission->email); ?>"
                                        data-telefono="<?php echo esc_attr($submission->telefono); ?>"
                                        data-oggetto="<?php echo esc_attr($submission->oggetto); ?>"
                                        data-messaggio="<?php echo esc_attr($submission->messaggio); ?>"
                                        data-data="<?php echo esc_attr(date('d.m.Y H:i', strtotime($submission->data_invio))); ?>"
                                        data-letto="<?php echo $submission->letto ? '1' : '0'; ?>">
                                        <td style="text-align: center;"><input type="checkbox" class="submission-checkbox" value="<?php echo esc_attr($submission->id); ?>" /></td>
                                        <td><?php echo esc_html(date('d.m.Y H:i', strtotime($submission->data_invio))); ?></td>
                                        <td><?php echo esc_html($submission->nome); ?></td>
                                        <td><a href="mailto:<?php echo esc_attr($submission->email); ?>"><?php echo esc_html($submission->email); ?></a></td>
                                        <td><?php echo esc_html($submission->telefono ?: '-'); ?></td>
                                        <td><?php echo esc_html($submission->oggetto); ?></td>
                                        <td><?php echo esc_html(substr($submission->messaggio, 0, 50)) . (strlen($submission->messaggio) > 50 ? '...' : ''); ?></td>
                                        <td>
                                            <span class="submission-status" style="padding: 4px 8px; border-radius: 3px; background: <?php echo $submission->letto ? '#f0f0f0' : '#fff8e5'; ?>; font-size: 12px;">
                                                <?php echo $submission->letto ? __('Letto', 'ticinoweb-ai-theme') : __('Non Letto', 'ticinoweb-ai-theme'); ?>
                                            </span>
                                        </td>
                                        <td>
                                            <a href="#" class="view-submission" data-id="<?php echo $submission->id; ?>" title="<?php _e('Visualizza completo', 'ticinoweb-ai-theme'); ?>"><?php _e('Visualizza', 'ticinoweb-ai-theme'); ?></a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>

                    <!-- Pagination Bar -->
                    <div class="ticinoweb-submissions-nav">
                        <div class="nav-left">
                            <?php 
                            $from_item = $offset + 1;
                            $to_item = min($offset + $per_page, $total_items);
                            if ($total_items > 0) {
                                printf(
                                    __('Mostrando da %1$d a %2$d di %3$d elementi', 'ticinoweb-ai-theme'),
                                    $from_item,
                                    $to_item,
                                    $total_items
                                );
                            } else {
                                _e('Nessun elemento da mostrare', 'ticinoweb-ai-theme');
                            }
                            ?>
                        </div>
                        <div class="nav-right">
                            <!-- Page Size Selector -->
                            <div class="page-size-selector">
                                <label for="ticinoweb-page-size"><?php _e('Elementi per pagina:', 'ticinoweb-ai-theme'); ?></label>
                                <select id="ticinoweb-page-size" onchange="ticinowebChangePageSize(this);">
                                    <?php foreach ($per_page_options as $option): ?>
                                        <option value="<?php echo $option; ?>" <?php selected($per_page, $option); ?>><?php echo $option; ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            
                            <!-- Pagination links -->
                            <?php
                            $page_links = paginate_links(array(
                                'base' => add_query_arg('sub_paged', '%#%'),
                                'format' => '',
                                'prev_text' => '&laquo;',
                                'next_text' => '&raquo;',
                                'total' => $total_pages,
                                'current' => $current_page,
                                'type' => 'array'
                            ));
                            
                            if ($page_links) {
                                echo '<ul class="ticinoweb-pagination">';
                                foreach ($page_links as $link) {
                                    if (strpos($link, 'href=') !== false) {
                                        $link = str_replace("'", '"', $link);
                                        // il collegamento resta sulla stessa pagina «Invii Ricevuti»
                                    }
                                    echo '<li>' . $link . '</li>';
                                }
                                echo '</ul>';
                            }
                            ?>
                        </div>
                    </div>
                    
                    <script>
                    function ticinowebChangePageSize(select) {
                        var url = new URL(window.location.href);
                        url.searchParams.set('per_page', select.value);
                        url.searchParams.set('sub_paged', '1');
                        window.location.href = url.toString();
                    }
                    </script>
                    
                    <!-- Modal for full submission view -->
                    <div id="submission-modal" style="display: none; position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(0,0,0,0.5); z-index: 9999; align-items: center; justify-content: center;">
                        <div style="background: white; padding: 30px; border-radius: 8px; max-width: 600px; width: 90%; max-height: 80vh; overflow-y: auto; position: relative;">
                            <button type="button" class="close-modal" style="position: absolute; top: 10px; right: 15px; background: none; border: none; font-size: 28px; cursor: pointer; color: #999;">×</button>
                            
                            <div id="modal-content">
                                <!-- Content will be filled by JS -->
                            </div>
                        </div>
                    </div>
                    
                <?php else: ?>
                    <div class="notice notice-info inline" style="margin: 20px 0;">
                        <p><?php _e('Nessun messaggio ricevuto ancora.', 'ticinoweb-ai-theme'); ?></p>
                    </div>
                <?php endif; ?>
            </div>
            
    </div>

    <script>
    jQuery(document).ready(function($) {
        var deleteNonce = '<?php echo wp_create_nonce('ticinoweb_delete_submissions'); ?>';

        // Form submissions: open modal with full details
        $(document).on('click', '.view-submission', function(e) {
            e.preventDefault();

            var $row = $(this).closest('.submission-row');
            if (!$row.length) {
                return;
            }

            var data = $row.data();
            var telefono = data.telefono ? data.telefono : '-';
            var message = (data.messaggio || '').toString().replace(/\r\n/g, '\n').replace(/\r/g, '\n');
            var messageHtml = message
                ? message.replace(/\n/g, '<br>')
                : '<em><?php echo esc_js(__('Nessun messaggio', 'ticinoweb-ai-theme')); ?></em>';

            var modalHtml = ''
                + '<p><strong><?php echo esc_js(__('Data', 'ticinoweb-ai-theme')); ?>:</strong> ' + (data.data || '') + '</p>'
                + '<p><strong><?php echo esc_js(__('Nome', 'ticinoweb-ai-theme')); ?>:</strong> ' + (data.nome || '') + '</p>'
                + '<p><strong><?php echo esc_js(__('Email', 'ticinoweb-ai-theme')); ?>:</strong> <a href="mailto:' + (data.email || '') + '">' + (data.email || '') + '</a></p>'
                + '<p><strong><?php echo esc_js(__('Telefono', 'ticinoweb-ai-theme')); ?>:</strong> ' + telefono + '</p>'
                + '<p><strong><?php echo esc_js(__('Oggetto', 'ticinoweb-ai-theme')); ?>:</strong> ' + (data.oggetto || '') + '</p>'
                + '<div><strong><?php echo esc_js(__('Messaggio', 'ticinoweb-ai-theme')); ?>:</strong><br>' + messageHtml + '</div>';

            $('#modal-content').html(modalHtml);
            $('#submission-modal').css('display', 'flex');

            // Mark as read visually
            $row.data('letto', '1');
            $row.find('.submission-status')
                .text('<?php echo esc_js(__('Letto', 'ticinoweb-ai-theme')); ?>')
                .css('background', '#f0f0f0');
        });

        $(document).on('click', '.close-modal', function() {
            $('#submission-modal').hide();
        });

        $('#submission-modal').on('click', function(event) {
            if ($(event.target).is('#submission-modal')) {
                $('#submission-modal').hide();
            }
        });

        // Bulk delete submissions
        var $deleteBtn = $('#delete-selected-submissions');
        var $feedback = $('#submission-delete-feedback');
        var $selectAll = $('#select-all-submissions');

        function updateDeleteState() {
            var checkedCount = $('.submission-checkbox:checked').length;
            $deleteBtn.prop('disabled', checkedCount === 0);
        }

        $(document).on('change', '.submission-checkbox', function() {
            updateDeleteState();
        });

        $selectAll.on('change', function() {
            var isChecked = $(this).is(':checked');
            $('.submission-checkbox').prop('checked', isChecked);
            updateDeleteState();
        });

        $deleteBtn.on('click', function() {
            var ids = $('.submission-checkbox:checked').map(function() { return $(this).val(); }).get();
            if (ids.length === 0) {
                return;
            }

            if (!confirm('<?php echo esc_js(__('Sei sicuro di voler eliminare i messaggi selezionati?', 'ticinoweb-ai-theme')); ?>')) {
                return;
            }

            $deleteBtn.prop('disabled', true).text('<?php echo esc_js(__('Eliminazione...', 'ticinoweb-ai-theme')); ?>');
            $feedback.text('');

            $.post(ajaxurl, {
                action: 'ticinoweb_delete_submissions',
                nonce: deleteNonce,
                ids: ids
            }).done(function(response) {
                $deleteBtn.text('<?php echo esc_js(__('Elimina selezionati', 'ticinoweb-ai-theme')); ?>');

                if (response && response.success) {
                    ids.forEach(function(id) {
                        $('.submission-checkbox[value="' + id + '"]').closest('tr').remove();
                    });
                    $selectAll.prop('checked', false);
                    updateDeleteState();
                    $feedback.css('color', '#2271b1').text('<?php echo esc_js(__('Messaggi eliminati', 'ticinoweb-ai-theme')); ?>');

                    // If no more rows, reload to show the empty state
                    if ($('.submission-row').length === 0) {
                        location.reload();
                    }
                } else {
                    var msg = (response && response.data) ? response.data : '<?php echo esc_js(__('Errore durante l\'eliminazione.', 'ticinoweb-ai-theme')); ?>';
                    $feedback.css('color', '#d63638').text(msg);
                    updateDeleteState();
                }
            }).fail(function() {
                $deleteBtn.text('<?php echo esc_js(__('Elimina selezionati', 'ticinoweb-ai-theme')); ?>');
                $feedback.css('color', '#d63638').text('<?php echo esc_js(__('Errore di rete durante l\'eliminazione.', 'ticinoweb-ai-theme')); ?>');
                updateDeleteState();
            });
        });

    });
    </script>
    <?php
}
