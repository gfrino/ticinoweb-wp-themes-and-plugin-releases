<?php
/**
 * Lists admin page (overview + single list management).
 *
 * @package WPNews
 */

if (!defined('ABSPATH')) {
	exit;
}

$view            = isset($_GET['view']) ? sanitize_key(wp_unslash($_GET['view'])) : 'list';
$current_list_id = isset($_GET['id']) ? absint($_GET['id']) : 0;
$admin_base      = admin_url('admin.php');

// Result of a list action (admin-post.php redirects back with wpnews_msg).
$wpnews_msgs = array(
	'list_deleted'        => array('success', __('List deleted.', 'wp-news')),
	'list_renamed'        => array('success', __('List renamed successfully.', 'wp-news')),
	'sub_removed'         => array('success', __('Subscriber removed from list.', 'wp-news')),
	'sub_blacklisted'     => array('success', __('Subscriber blacklisted.', 'wp-news')),
	'already_blacklisted' => array('warning', __('Subscriber already blacklisted or invalid.', 'wp-news')),
	'error'               => array('error', __('The action could not be completed. Please try again.', 'wp-news')),
);
$wpnews_msg = isset($_GET['wpnews_msg']) ? sanitize_key(wp_unslash($_GET['wpnews_msg'])) : '';
if (isset($wpnews_msgs[$wpnews_msg])) {
	printf('<div class="notice notice-%1$s is-dismissible"><p>%2$s</p></div>', esc_attr($wpnews_msgs[$wpnews_msg][0]), esc_html($wpnews_msgs[$wpnews_msg][1]));
}

// Color palette for list cards
$list_colors = array('#6366f1', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899', '#06b6d4', '#84cc16');

// ==========================================
// VIEW: EDIT LIST
// ==========================================
if ('edit' === $view && $current_list_id) {
	$list = WPNews_List_Manager::get_list($current_list_id);
	if (!$list || !is_array($list)) {
		echo '<div class="notice notice-error"><p>' . esc_html__('List not found.', 'wp-news') . '</p></div>';
		return;
	}

	// Handle Actions: Add Subscriber
	if (isset($_POST['wpnews_add_subscriber']) && check_admin_referer('wpnews_add_sub', 'wpnews_nonce')) {
		$email = isset($_POST['email']) ? sanitize_email(wp_unslash($_POST['email'])) : '';
		$fname = isset($_POST['first_name']) ? sanitize_text_field(wp_unslash($_POST['first_name'])) : '';
		$lname = isset($_POST['last_name']) ? sanitize_text_field(wp_unslash($_POST['last_name'])) : '';

		if ('' !== $email && is_email($email)) {
			$sub_id = WPNews_List_Manager::create_or_get_subscriber($email, $fname, $lname);
			if ($sub_id) {
				if (WPNews_List_Manager::add_subscriber_to_list($sub_id, $current_list_id)) {
					echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__('Subscriber added.', 'wp-news') . '</p></div>';
				} else {
					echo '<div class="notice notice-warning is-dismissible"><p>' . esc_html__('Subscriber already in list.', 'wp-news') . '</p></div>';
				}
			} else {
				echo '<div class="notice notice-error is-dismissible"><p>' . esc_html__('Error creating subscriber.', 'wp-news') . '</p></div>';
			}
		} else {
			echo '<div class="notice notice-error is-dismissible"><p>' . esc_html__('Invalid email.', 'wp-news') . '</p></div>';
		}
	}

	// Subscribers of this list: search + pagination handled by the model (no PHP filtering).
	$search   = isset($_GET['s']) ? sanitize_text_field(wp_unslash($_GET['s'])) : '';
	$per_page = 25;
	$paged    = isset($_GET['paged']) ? max(1, absint($_GET['paged'])) : 1;
	$offset   = ($paged - 1) * $per_page;

	$total       = (int) WPNews_List_Manager::count_all_subscribers($search, 'active', $current_list_id);
	$subscribers = WPNews_List_Manager::get_all_subscribers($per_page, $offset, $search, 'active', $current_list_id);
	if (!is_array($subscribers)) {
		$subscribers = array();
	}
	$total_pages = (int) ceil($total / $per_page);
	$list_color  = $list_colors[$current_list_id % count($list_colors)];

	$base_edit_url = add_query_arg(array('page' => 'wp-news-lists', 'view' => 'edit', 'id' => $current_list_id), $admin_base);
	$paged_base    = '' !== $search ? add_query_arg('s', rawurlencode($search), $base_edit_url) : $base_edit_url;
	$page_links    = paginate_links(array(
		'base'      => add_query_arg('paged', '%#%', $paged_base),
		'format'    => '',
		'current'   => $paged,
		'total'     => $total_pages,
		'prev_text' => '&laquo;',
		'next_text' => '&raquo;',
	));
	?>
	<div class="wpnews-admin-wrap">
		<!-- Header -->
		<div class="wpnews-list-head">
			<div class="wpnews-list-head__title">
				<div class="wpnews-list-icon" style="--list-color:<?php echo esc_attr($list_color); ?>;">
					<span class="dashicons dashicons-list-view"></span>
				</div>
				<div>
					<h1><?php echo esc_html((string) $list['name']); ?></h1>
					<span class="wpnews-muted-text"><?php
						/* translators: %d: number of active subscribers */
						printf(esc_html__('%d active subscribers', 'wp-news'), (int) $total);
					?></span>
				</div>
			</div>
			<a href="<?php echo esc_url(add_query_arg(array('page' => 'wp-news-lists'), $admin_base)); ?>" class="wpnews-btn wpnews-btn-outline">
				<span class="dashicons dashicons-arrow-left-alt"></span>
				<?php esc_html_e('Back to Lists', 'wp-news'); ?>
			</a>
		</div>

		<!-- Signup form builder, preselected on this list -->
		<?php
		$wpnews_builder_lists    = WPNews_List_Manager::get_lists();
		$wpnews_builder_selected = $current_list_id;
		include WPNEWS_PLUGIN_DIR . 'admin/partials/signup-form-builder.php';
		?>

		<!-- Add Subscriber Form -->
		<div class="wpnews-card wpnews-mb-16">
			<div class="wpnews-card-title">
				<span class="dashicons dashicons-plus-alt2" style="color:<?php echo esc_attr($list_color); ?>;"></span>
				<h3><?php esc_html_e('Add Subscriber', 'wp-news'); ?></h3>
			</div>
			<form method="post">
				<?php wp_nonce_field('wpnews_add_sub', 'wpnews_nonce'); ?>
				<div class="wpnews-form-row">
					<div class="wpnews-form-col wpnews-form-col--2">
						<label class="wpnews-field-label" for="wpnews-add-email"><?php esc_html_e('Email', 'wp-news'); ?></label>
						<input type="email" id="wpnews-add-email" name="email" placeholder="subscriber@example.com" required class="wpnews-input">
					</div>
					<div class="wpnews-form-col">
						<label class="wpnews-field-label" for="wpnews-add-fname"><?php esc_html_e('First Name', 'wp-news'); ?></label>
						<input type="text" id="wpnews-add-fname" name="first_name" placeholder="<?php esc_attr_e('First Name', 'wp-news'); ?>" class="wpnews-input">
					</div>
					<div class="wpnews-form-col">
						<label class="wpnews-field-label" for="wpnews-add-lname"><?php esc_html_e('Last Name', 'wp-news'); ?></label>
						<input type="text" id="wpnews-add-lname" name="last_name" placeholder="<?php esc_attr_e('Last Name', 'wp-news'); ?>" class="wpnews-input">
					</div>
					<div>
						<button type="submit" name="wpnews_add_subscriber" value="1" class="wpnews-btn wpnews-btn-primary">
							<span class="dashicons dashicons-plus"></span>
							<?php esc_html_e('Add', 'wp-news'); ?>
						</button>
					</div>
				</div>
			</form>
		</div>

		<!-- Search + Subscriber Table -->
		<div class="wpnews-card">
			<div class="wpnews-toolbar-row">
				<div class="wpnews-card-title wpnews-m-0">
					<span class="dashicons dashicons-groups" style="color:<?php echo esc_attr($list_color); ?>;"></span>
					<h3>
						<?php
						/* translators: %d: number of subscribers */
						printf(esc_html__('Subscribers (%d)', 'wp-news'), (int) $total);
						?>
						<?php if ('' !== $search) : ?>
							<span class="wpnews-small-muted">(<?php esc_html_e('filtered', 'wp-news'); ?>)</span>
						<?php endif; ?>
					</h3>
				</div>
				<form method="get" action="<?php echo esc_url($admin_base); ?>" class="wpnews-inline-field">
					<input type="hidden" name="page" value="wp-news-lists">
					<input type="hidden" name="view" value="edit">
					<input type="hidden" name="id" value="<?php echo esc_attr($current_list_id); ?>">
					<div class="wpnews-search-wrap wpnews-search-wrap--sm">
						<span class="dashicons dashicons-search wpnews-search-icon"></span>
						<input type="search" name="s" value="<?php echo esc_attr($search); ?>" placeholder="<?php esc_attr_e('Search subscribers...', 'wp-news'); ?>" class="wpnews-search-input">
					</div>
					<button type="submit" class="wpnews-btn wpnews-btn-primary wpnews-btn-icon" title="<?php esc_attr_e('Search', 'wp-news'); ?>">
						<span class="dashicons dashicons-search"></span>
					</button>
					<?php if ('' !== $search) : ?>
						<a href="<?php echo esc_url($base_edit_url); ?>" class="wpnews-btn wpnews-btn-ghost"><?php esc_html_e('Clear', 'wp-news'); ?></a>
					<?php endif; ?>
				</form>
			</div>

			<?php if ($total_pages > 1) : ?>
				<div class="wpnews-tablenav wpnews-tablenav--top">
					<span class="wpnews-muted-text"><?php
						/* translators: 1: current page, 2: total pages */
						printf(esc_html__('Page %1$d of %2$d', 'wp-news'), (int) $paged, (int) $total_pages);
					?></span>
					<div class="tablenav-pages">
						<?php if ($page_links) : ?><span class="pagination-links"><?php echo wp_kses_post($page_links); ?></span><?php endif; ?>
					</div>
				</div>
			<?php endif; ?>

			<?php if (!empty($subscribers)) : ?>
				<table class="wpnews-table wpnews-subscriber-table">
					<thead>
						<tr>
							<th><?php esc_html_e('Email', 'wp-news'); ?></th>
							<th style="width:180px;"><?php esc_html_e('Name', 'wp-news'); ?></th>
							<th style="width:110px;"><?php esc_html_e('Joined', 'wp-news'); ?></th>
							<th style="width:120px;"><?php esc_html_e('Actions', 'wp-news'); ?></th>
						</tr>
					</thead>
					<tbody>
						<?php foreach ($subscribers as $sub) :
							$sub_id    = (int) ($sub['id'] ?? 0);
							$sub_email = (string) ($sub['email'] ?? '');
							$full_name = trim((string) ($sub['first_name'] ?? '') . ' ' . (string) ($sub['last_name'] ?? ''));
							$joined_ts = !empty($sub['subscribed_at']) ? strtotime((string) $sub['subscribed_at']) : false;

							$back_args     = array('back' => 'edit') + ('' !== $search ? array('s' => $search) : array());
							$remove_url    = WPNews_Admin::list_action_url('remove_sub', $current_list_id, $back_args + array('sub_id' => $sub_id));
							$blacklist_url = WPNews_Admin::list_action_url('blacklist_sub', $current_list_id, $back_args + array('email' => $sub_email));
							?>
							<tr>
								<td><span class="wpnews-email"><?php echo esc_html($sub_email); ?></span></td>
								<td>
									<?php if ('' !== $full_name) : ?>
										<span><?php echo esc_html($full_name); ?></span>
									<?php else : ?>
										<span class="wpnews-dash">—</span>
									<?php endif; ?>
								</td>
								<td class="wpnews-cell-date"><?php echo $joined_ts ? esc_html(date_i18n('Y-m-d', $joined_ts)) : '—'; ?></td>
								<td>
									<div class="wpnews-action-btns">
										<button type="button" class="wpnews-btn wpnews-btn-sm wpnews-btn-remove" data-email="<?php echo esc_attr($sub_email); ?>" data-url="<?php echo esc_url($remove_url); ?>" title="<?php esc_attr_e('Remove from list', 'wp-news'); ?>">
											<span class="dashicons dashicons-minus"></span>
										</button>
										<button type="button" class="wpnews-btn wpnews-btn-sm wpnews-btn-warning wpnews-bl-btn" data-email="<?php echo esc_attr($sub_email); ?>" data-url="<?php echo esc_url($blacklist_url); ?>" title="<?php esc_attr_e('Blacklist globally', 'wp-news'); ?>">
											<span class="dashicons dashicons-shield"></span>
										</button>
									</div>
								</td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>

				<?php if ($total_pages > 1) : ?>
					<div class="wpnews-tablenav">
						<span></span>
						<div class="tablenav-pages">
							<?php if ($page_links) : ?><span class="pagination-links"><?php echo wp_kses_post($page_links); ?></span><?php endif; ?>
						</div>
					</div>
				<?php endif; ?>
			<?php else : ?>
				<div class="wpnews-empty">
					<span class="dashicons dashicons-groups wpnews-empty__icon"></span>
					<?php if ('' !== $search) : ?>
						<p><?php esc_html_e('No subscribers match your search.', 'wp-news'); ?>
							<a href="<?php echo esc_url($base_edit_url); ?>"><?php esc_html_e('Clear search', 'wp-news'); ?></a>
						</p>
					<?php else : ?>
						<p><?php esc_html_e('No subscribers in this list yet. Add one above!', 'wp-news'); ?></p>
					<?php endif; ?>
				</div>
			<?php endif; ?>
		</div>
	</div>
	<?php
	return;
}

// ==========================================
// VIEW: LIST OVERVIEW (Default)
// ==========================================

// Handle Add List
if (isset($_POST['wpnews_add_list']) && check_admin_referer('wpnews_add_list', 'wpnews_nonce')) {
	$name = isset($_POST['list_name']) ? sanitize_text_field(wp_unslash($_POST['list_name'])) : '';
	if ('' !== $name) {
		if (WPNews_List_Manager::create_list($name)) {
			echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__('List created successfully!', 'wp-news') . '</p></div>';
		} else {
			echo '<div class="notice notice-error is-dismissible"><p>' . esc_html__('Error creating list.', 'wp-news') . '</p></div>';
		}
	} else {
		echo '<div class="notice notice-error is-dismissible"><p>' . esc_html__('List name cannot be empty.', 'wp-news') . '</p></div>';
	}
}

$lists = WPNews_List_Manager::get_lists();
if (!is_array($lists)) {
	$lists = array();
}
$total_subscribers = 0;
foreach ($lists as $l) {
	$total_subscribers += (int) ($l['subscriber_count'] ?? 0);
}
?>
<div class="wpnews-admin-wrap">
	<div class="wpnews-list-head">
		<div>
			<h1><?php esc_html_e('Mailing Lists', 'wp-news'); ?></h1>
			<span class="wpnews-muted-text">
				<?php
				/* translators: 1: number of lists, 2: total subscribers */
				printf(esc_html__('%1$d lists · %2$s total subscribers', 'wp-news'), count($lists), esc_html(number_format_i18n($total_subscribers)));
				?>
			</span>
		</div>
	</div>

	<?php
	$wpnews_builder_lists    = $lists;
	$wpnews_builder_selected = 0;
	include WPNEWS_PLUGIN_DIR . 'admin/partials/signup-form-builder.php';
	?>

	<!-- Create New List -->
	<div class="wpnews-card wpnews-mb-20">
		<div class="wpnews-card-title">
			<span class="dashicons dashicons-plus-alt2 wpnews-text-indigo"></span>
			<h3><?php esc_html_e('Create New List', 'wp-news'); ?></h3>
		</div>
		<form method="post" action="">
			<?php wp_nonce_field('wpnews_add_list', 'wpnews_nonce'); ?>
			<div class="wpnews-form-row">
				<div class="wpnews-form-col wpnews-form-col--max">
					<label class="wpnews-field-label" for="wpnews-list-name"><?php esc_html_e('List Name', 'wp-news'); ?></label>
					<input type="text" id="wpnews-list-name" name="list_name" placeholder="<?php esc_attr_e('e.g. Newsletter Subscribers', 'wp-news'); ?>" required class="wpnews-input">
				</div>
				<button type="submit" name="wpnews_add_list" value="1" class="wpnews-btn wpnews-btn-primary">
					<span class="dashicons dashicons-plus"></span>
					<?php esc_html_e('Create List', 'wp-news'); ?>
				</button>
			</div>
		</form>
	</div>

	<!-- Lists Grid -->
	<?php if (!empty($lists)) : ?>
		<div class="wpnews-lists-grid">
			<?php foreach ($lists as $list) :
				$lid        = (int) ($list['id'] ?? 0);
				$count      = (int) ($list['subscriber_count'] ?? 0);
				$color      = $list_colors[$lid % count($list_colors)];
				$edit_url   = add_query_arg(array('page' => 'wp-news-lists', 'view' => 'edit', 'id' => $lid), $admin_base);
				$delete_url = WPNews_Admin::list_action_url('delete', $lid);
				$rename_url = WPNews_Admin::list_action_url('rename', $lid);
				$created_ts = !empty($list['created_at']) ? strtotime((string) $list['created_at']) : false;
				?>
				<div class="wpnews-list-card" style="--list-color:<?php echo esc_attr($color); ?>;">
					<div class="wpnews-list-card-header">
						<div class="wpnews-list-card-meta">
							<div class="wpnews-list-icon wpnews-list-icon--sm">
								<span class="dashicons dashicons-email-alt"></span>
							</div>
							<div class="wpnews-list-card-name">
								<h4><?php echo esc_html((string) ($list['name'] ?? '')); ?></h4>
								<span><?php echo $created_ts ? esc_html(date_i18n('M d, Y', $created_ts)) : ''; ?></span>
							</div>
						</div>
						<div class="wpnews-list-card-count">
							<div class="wpnews-list-card-number"><?php echo esc_html(number_format_i18n($count)); ?></div>
							<span><?php esc_html_e('subscribers', 'wp-news'); ?></span>
						</div>
					</div>
					<div class="wpnews-list-card-footer">
						<div class="wpnews-action-btns">
							<a href="<?php echo esc_url($edit_url); ?>" class="wpnews-btn wpnews-btn-sm wpnews-btn-tinted">
								<span class="dashicons dashicons-groups"></span>
								<?php esc_html_e('Manage', 'wp-news'); ?>
							</a>
							<a href="#wpnews-signup-builder" class="wpnews-btn wpnews-btn-sm wpnews-btn-neutral" data-wpnews-builder-list="<?php echo esc_attr($lid); ?>">
								<span class="dashicons dashicons-feedback"></span>
								<?php esc_html_e('Signup form', 'wp-news'); ?>
							</a>
						</div>
						<div class="wpnews-action-btns">
							<button type="button" class="wpnews-btn wpnews-btn-sm wpnews-btn-neutral wpnews-edit-list-btn" data-name="<?php echo esc_attr((string) ($list['name'] ?? '')); ?>" data-url="<?php echo esc_url($rename_url); ?>" title="<?php esc_attr_e('Rename List', 'wp-news'); ?>">
								<span class="dashicons dashicons-edit"></span>
							</button>
							<button type="button" class="wpnews-btn wpnews-btn-sm wpnews-btn-danger-outline wpnews-delete-list-btn" data-name="<?php echo esc_attr((string) ($list['name'] ?? '')); ?>" data-url="<?php echo esc_url($delete_url); ?>" title="<?php esc_attr_e('Delete List', 'wp-news'); ?>">
								<span class="dashicons dashicons-trash"></span>
							</button>
						</div>
					</div>
				</div>
			<?php endforeach; ?>
		</div>
	<?php else : ?>
		<div class="wpnews-card wpnews-empty">
			<span class="dashicons dashicons-list-view wpnews-empty__icon"></span>
			<p><?php esc_html_e('No lists yet. Create one above to get started!', 'wp-news'); ?></p>
		</div>
	<?php endif; ?>
</div>
