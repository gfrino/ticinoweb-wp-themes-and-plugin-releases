<?php
/**
 * The admin-specific functionality of the plugin.
 *
 * @package WPNews
 */

/**
 * The admin-specific functionality of the plugin.
 */
class WPNews_Admin
{

	/**
	 * The ID of this plugin.
	 *
	 * @var string
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @var string
	 */
	private $version;

	/**
	 * Option keys that hold credentials. They are rendered as password fields,
	 * never echoed back, and preserved when submitted empty.
	 *
	 * @var string[]
	 */
	const CREDENTIAL_KEYS = array(
		'sendgrid_api_key',
		'sendgrid_webhook_key',
		'ses_access_key',
		'ses_secret_key',
	);

	/**
	 * Allowed values for the mailer_type option.
	 *
	 * @var string[]
	 */
	const MAILER_TYPES = array('sendgrid', 'ses');

	/**
	 * Initialize the class and set its properties.
	 *
	 * @param string $plugin_name The name of this plugin.
	 * @param string $version     The version of this plugin.
	 */
	public function __construct($plugin_name, $version)
	{
		$this->plugin_name = $plugin_name;
		$this->version = $version;
	}

	/**
	 * Whether the current admin screen belongs to this plugin.
	 *
	 * @param string $hook Current admin page hook.
	 * @return bool
	 */
	private function is_plugin_screen($hook)
	{
		return is_string($hook) && strpos($hook, 'wp-news') !== false;
	}

	/**
	 * Register the stylesheets for the admin area.
	 *
	 * @param string $hook Current admin page hook.
	 */
	public function enqueue_styles($hook)
	{
		if (!$this->is_plugin_screen($hook)) {
			return;
		}

		wp_enqueue_style(
			$this->plugin_name,
			WPNEWS_PLUGIN_URL . 'admin/css/admin.css',
			array('dashicons'),
			$this->version,
			'all'
		);

		// Live preview of the signup form builder uses the real front-end styles.
		if (isset($_GET['page']) && 'wp-news-lists' === sanitize_key(wp_unslash($_GET['page']))) {
			wp_enqueue_style(
				$this->plugin_name . '-public-preview',
				WPNEWS_PLUGIN_URL . 'public/css/public.css',
				array(),
				$this->version
			);
		}
	}

	/**
	 * Register the JavaScript for the admin area.
	 *
	 * @param string $hook Current admin page hook.
	 */
	public function enqueue_scripts($hook)
	{
		if (!$this->is_plugin_screen($hook)) {
			return;
		}

		$page = isset($_GET['page']) ? sanitize_key(wp_unslash($_GET['page'])) : '';

		// Vanilla JS shared by all admin partials (no jQuery / jQuery UI needed).
		wp_enqueue_script(
			'wp-news-admin',
			WPNEWS_PLUGIN_URL . 'admin/js/admin.js',
			array(),
			$this->version,
			true
		);

		wp_localize_script(
			'wp-news-admin',
			'wpNewsAdmin',
			array(
				'ajaxUrl'   => admin_url('admin-ajax.php'),
				'restRoot'  => esc_url_raw(rest_url('wp-news/v1/')),
				'restNonce' => wp_create_nonce('wp_rest'),
				'strings'   => array(
					'noFileChosen'         => __('No file chosen', 'wp-news'),
					'importing'            => __('Importing...', 'wp-news'),
					'importFromMailpoet'   => __('Import from MailPoet', 'wp-news'),
					'confirmMailpoet'      => __('This will import all subscribers, lists, and blacklists from MailPoet. Continue?', 'wp-news'),
					'saving'               => __('Saving...', 'wp-news'),
					'saved'                => __('Saved', 'wp-news'),
					'error'                => __('Error', 'wp-news'),
					'errorPrefix'          => __('Error: %s', 'wp-news'),
					'unknownError'         => __('Unknown error', 'wp-news'),
					'networkError'         => __('Network error', 'wp-news'),
					'networkErrorDetail'   => __('Network error: %s', 'wp-news'),
					'confirmBlacklist'     => __('Blacklist %s?', 'wp-news'),
					'confirmBlacklistGlobal' => __('Blacklist %s globally?', 'wp-news'),
					'confirmDelete'        => __('Delete %s?', 'wp-news'),
					'confirmRemoveFromList' => __('Remove %s from this list?', 'wp-news'),
					'confirmDeleteList'    => __('Delete list "%s"? This cannot be undone.', 'wp-news'),
					'promptListName'       => __('Enter new list name:', 'wp-news'),
					'copied'               => __('Copied!', 'wp-news'),
					'copyManually'         => __('Copy the shortcode:', 'wp-news'),
					'selected'             => __('%d selected', 'wp-news'),
					'confirmBulkDelete'    => __('Are you sure you want to delete %d campaigns? This cannot be undone.', 'wp-news'),
					'confirmStop'          => __('Are you sure you want to stop this campaign?', 'wp-news'),
					'confirmResume'        => __('Do you want to resume sending this campaign?', 'wp-news'),
					'stopping'             => __('Stopping...', 'wp-news'),
					'resuming'             => __('Resuming...', 'wp-news'),
					'checking'             => __('Checking...', 'wp-news'),
					'notConfigured'        => __('Not configured', 'wp-news'),
					'identity'             => __('Identity', 'wp-news'),
					'verified'             => __('Verified', 'wp-news'),
					'yes'                  => __('Yes', 'wp-news'),
					'no'                   => __('No', 'wp-news'),
					'type'                 => __('Type', 'wp-news'),
					'status'               => __('Status', 'wp-news'),
					'snsTopic'             => __('SNS Topic', 'wp-news'),
					'delivery'             => __('Delivery', 'wp-news'),
					'bounce'               => __('Bounce', 'wp-news'),
					'complaint'            => __('Complaint', 'wp-news'),
					'active'               => __('Active', 'wp-news'),
					'inactive'             => __('Not active', 'wp-news'),
					'secretGenerated'      => __('A new secret has been generated. Save the settings to apply it and update the webhook URLs in SendGrid / AWS SNS.', 'wp-news'),
				),
			)
		);

		// React App (News Builder)
		if ('wp-news-create-campaign' === $page) {
			wp_enqueue_media();
			wp_enqueue_style('wp-block-editor');
			$asset_file = WPNEWS_PLUGIN_DIR . 'build/index.asset.php';

			if (file_exists($asset_file)) {
				$assets = require $asset_file;

				wp_enqueue_script(
					'wp-news-builder',
					WPNEWS_PLUGIN_URL . 'build/index.js',
					isset($assets['dependencies']) ? $assets['dependencies'] : array(),
					isset($assets['version']) ? $assets['version'] : $this->version,
					true
				);
				wp_set_script_translations('wp-news-builder', 'wp-news', WPNEWS_PLUGIN_DIR . 'languages');

				$options = get_option('wpnews_options', array());
				if (!is_array($options)) {
					$options = array();
				}
				$physical_address = isset($options['physical_address']) ? trim((string) $options['physical_address']) : '';

				$wpml_languages = apply_filters('wpml_active_languages', null, 'orderby=id&order=desc');
				$languages = array();
				if (!empty($wpml_languages) && is_array($wpml_languages)) {
					foreach ($wpml_languages as $l) {
						$languages[] = array(
							'code' => isset($l['language_code']) ? $l['language_code'] : '',
							'name' => isset($l['native_name']) ? $l['native_name'] : '',
						);
					}
				}

				wp_localize_script(
					'wp-news-builder',
					'wpNewsSettings',
					array(
						'root'            => esc_url_raw(rest_url('wp-news/v1/builder/')),
						'nonce'           => wp_create_nonce('wp_rest'),
						'adminUrl'        => admin_url(),
						'pluginUrl'       => WPNEWS_PLUGIN_URL,
						'locale'          => get_user_locale(),
						// The builder is opened in edit mode via admin.php?page=wp-news-create-campaign&id={id}.
						'editUrlTemplate' => admin_url('admin.php?page=wp-news-create-campaign&id=%d'),
						'campaignsUrl'    => admin_url('admin.php?page=wp-news-campaigns'),
						'siteName'        => get_bloginfo('name'),
						'siteUrl'         => home_url(),
						'adminEmail'      => get_option('admin_email'),
						'physicalAddress' => $physical_address,
						'mailerType'      => isset($options['mailer_type']) && in_array($options['mailer_type'], self::MAILER_TYPES, true) ? $options['mailer_type'] : 'sendgrid',
						'wpmlLanguages'   => $languages,
					)
				);

				wp_enqueue_style('wp-components');
				// RichText formats (bold, italic, link) are registered by the format library.
				wp_enqueue_script('wp-format-library');
				wp_enqueue_style('wp-format-library');
				wp_enqueue_style('wp-block-editor');
			}
		}
	}

	/**
	 * Add plugin admin menu.
	 */
	public function add_plugin_admin_menu()
	{
		add_menu_page(
			__('WP-News Newsletter', 'wp-news'),
			__('Newsletter', 'wp-news'),
			'manage_options',
			$this->plugin_name,
			array($this, 'display_dashboard'),
			'dashicons-email-alt',
			100
		);

		add_submenu_page(
			$this->plugin_name,
			__('Dashboard', 'wp-news'),
			__('Dashboard', 'wp-news'),
			'manage_options',
			$this->plugin_name,
			array($this, 'display_dashboard')
		);

		add_submenu_page(
			$this->plugin_name,
			__('Campaigns', 'wp-news'),
			__('Campaigns', 'wp-news'),
			'manage_options',
			$this->plugin_name . '-campaigns',
			array($this, 'display_campaigns')
		);

		add_submenu_page(
			$this->plugin_name,
			__('Create Campaign', 'wp-news'),
			__('Create Campaign', 'wp-news'),
			'manage_options',
			$this->plugin_name . '-create-campaign',
			array($this, 'display_create_campaign')
		);

		add_submenu_page(
			$this->plugin_name,
			__('Subscribers', 'wp-news'),
			__('Subscribers', 'wp-news'),
			'manage_options',
			$this->plugin_name . '-subscribers',
			array($this, 'display_subscribers')
		);

		add_submenu_page(
			$this->plugin_name,
			__('Lists', 'wp-news'),
			__('Lists', 'wp-news'),
			'manage_options',
			$this->plugin_name . '-lists',
			array($this, 'display_lists')
		);

		add_submenu_page(
			$this->plugin_name,
			__('Blacklist', 'wp-news'),
			__('Blacklist', 'wp-news'),
			'manage_options',
			$this->plugin_name . '-blacklist',
			array($this, 'display_blacklist')
		);

		add_submenu_page(
			$this->plugin_name,
			__('Settings', 'wp-news'),
			__('Settings', 'wp-news'),
			'manage_options',
			$this->plugin_name . '-settings',
			array($this, 'display_settings')
		);
	}

	/**
	 * Register plugin settings (Settings API).
	 */
	public function register_settings()
	{
		register_setting(
			'wpnews_options_group',
			'wpnews_options',
			array(
				'type'              => 'array',
				'sanitize_callback' => array($this, 'sanitize_options'),
				'default'           => array(),
			)
		);
	}

	/**
	 * Generate a random hexadecimal webhook secret (32 chars).
	 *
	 * @return string
	 */
	public static function generate_webhook_secret()
	{
		try {
			return bin2hex(random_bytes(16));
		} catch (Exception $e) {
			return wp_generate_password(32, false, false);
		}
	}

	/**
	 * Sanitize options.
	 *
	 * Strict whitelist of every key used by the settings screen. Unknown keys are
	 * dropped. Values already stored are used as a baseline so that partial
	 * updates (e.g. from includes/ code) do not wipe unrelated keys.
	 *
	 * @param mixed $input Raw input.
	 * @return array Sanitized options.
	 */
	public function sanitize_options($input)
	{
		$existing = get_option('wpnews_options', array());
		if (!is_array($existing)) {
			$existing = array();
		}
		if (!is_array($input)) {
			$input = array();
		}

		// Marker set by the settings form: when present, missing checkboxes mean "false".
		$from_settings_form = !empty($input['settings_form']);
		unset($input['settings_form']);

		$sanitized = $existing;

		// --- Text fields ---
		$text_keys = array('from_name', 'ses_region', 'sns_topic_arn');
		foreach ($text_keys as $key) {
			if (array_key_exists($key, $input)) {
				$sanitized[$key] = sanitize_text_field(wp_unslash((string) $input[$key]));
			}
		}

		// --- Email ---
		if (array_key_exists('from_email', $input)) {
			$email = sanitize_email(wp_unslash((string) $input['from_email']));
			$sanitized['from_email'] = is_email($email) ? $email : (isset($existing['from_email']) ? $existing['from_email'] : '');
		}

		// --- Enumerations ---
		if (array_key_exists('mailer_type', $input)) {
			$type = sanitize_key((string) $input['mailer_type']);
			$sanitized['mailer_type'] = in_array($type, self::MAILER_TYPES, true) ? $type : 'sendgrid';
		}

		// --- Numbers ---
		// Emails per minute, Amazon SES only. 0 = no throttling.
		if (array_key_exists('sending_frequency', $input)) {
			$sanitized['sending_frequency'] = absint($input['sending_frequency']);
		}
		if (array_key_exists('signup_list_id', $input)) {
			$sanitized['signup_list_id'] = absint($input['signup_list_id']);
		}
		if (array_key_exists('auto_email_list_id', $input)) {
			$sanitized['auto_email_list_id'] = absint($input['auto_email_list_id']);
		}

		// --- Booleans ---
		$bool_keys = array('double_optin', 'enable_auto_emails');
		foreach ($bool_keys as $key) {
			if (array_key_exists($key, $input)) {
				$sanitized[$key] = (bool) $input[$key];
			} elseif ($from_settings_form) {
				$sanitized[$key] = false;
			}
		}

		// --- Textareas ---
		if (array_key_exists('physical_address', $input)) {
			$sanitized['physical_address'] = sanitize_textarea_field(wp_unslash((string) $input['physical_address']));
		}
		// admin_note comes from wp_editor (rich text): allow post-safe HTML.
		if (array_key_exists('admin_note', $input)) {
			$sanitized['admin_note'] = wp_kses_post(wp_unslash((string) $input['admin_note']));
		}

		// --- Credentials: never wiped by an empty submission ---
		foreach (self::CREDENTIAL_KEYS as $key) {
			if (array_key_exists($key, $input)) {
				$value = sanitize_text_field(wp_unslash((string) $input[$key]));
				$value = str_replace(' ', '', $value);
				if ('' !== $value) {
					$sanitized[$key] = $value;
				} elseif (!isset($sanitized[$key])) {
					$sanitized[$key] = '';
				}
			}
		}

		// --- Webhook secret: required by SNS/SendGrid webhooks (?key=...) ---
		if (array_key_exists('webhook_secret', $input)) {
			$secret = preg_replace('/[^A-Za-z0-9]/', '', (string) wp_unslash($input['webhook_secret']));
			$sanitized['webhook_secret'] = $secret;
		}
		if (empty($sanitized['webhook_secret'])) {
			$sanitized['webhook_secret'] = self::generate_webhook_secret();
		}

		return $sanitized;
	}

	/**
	 * Display activation notice.
	 */
	public function activation_notice()
	{
		if (get_transient('wpnews_activation_notice')) {
			?>
			<div class="notice notice-success is-dismissible">
				<p><?php esc_html_e('WP-News Newsletter plugin has been activated successfully!', 'wp-news'); ?></p>
			</div>
			<?php
			delete_transient('wpnews_activation_notice');
		}
	}

	/**
	 * Warn when the site clock is a fixed UTC offset instead of a timezone.
	 *
	 * Scheduled campaigns are compared with the WordPress local time: with a fixed
	 * offset (e.g. "UTC+1") the site is one hour behind during daylight saving time
	 * and a campaign set for 09:00 leaves at 10:00 (seen 2026-09-14).
	 */
	public function timezone_notice()
	{
		$screen = function_exists('get_current_screen') ? get_current_screen() : null;
		if (!$screen || false === strpos((string) $screen->id, 'wp-news')) {
			return;
		}
		if (!current_user_can('manage_options') || '' !== (string) get_option('timezone_string', '')) {
			return;
		}

		$offset = (float) get_option('gmt_offset', 0);
		$offset_label = sprintf('UTC%+g', $offset);
		?>
		<div class="notice notice-warning">
			<p>
				<?php
				printf(
					/* translators: 1: current fixed offset such as UTC+1, 2: opening link tag to Settings > General, 3: closing link tag */
					esc_html__('The site timezone is a fixed offset (%1$s), so scheduled campaigns can leave one hour late during daylight saving time. Choose a city such as Europe/Zurich in %2$sSettings > General%3$s.', 'wp-news'),
					esc_html($offset_label),
					'<a href="' . esc_url(admin_url('options-general.php#timezone_string')) . '">',
					'</a>'
				);
				?>
			</p>
		</div>
		<?php
	}

	/**
	 * Abort an admin-post request when the user lacks the required capability.
	 */
	private function require_manage_options()
	{
		if (!current_user_can('manage_options')) {
			wp_die(esc_html__('You do not have permission to perform this action.', 'wp-news'), '', array('response' => 403));
		}
	}

	/**
	 * Handle campaign duplicate action via admin-post.php.
	 * The builder uses the REST route POST wp-news/v1/builder/duplicate/{id};
	 * this handler stays for the links in the campaigns list.
	 */
	public function handle_duplicate_campaign()
	{
		$this->require_manage_options();

		$campaign_id = isset($_GET['id']) ? absint($_GET['id']) : 0;
		$redirect    = admin_url('admin.php?page=wp-news-campaigns');

		if ($campaign_id) {
			check_admin_referer('wpnews_duplicate_campaign_' . $campaign_id);
			$new_id = WPNews_Campaign_Manager::duplicate_campaign($campaign_id);
			if ($new_id) {
				$redirect = admin_url('admin.php?page=wp-news-create-campaign&id=' . (int) $new_id);
			}
		}

		wp_safe_redirect($redirect);
		exit;
	}

	/**
	 * Handle campaign delete action via admin-post.php.
	 */
	public function handle_delete_campaign()
	{
		$this->require_manage_options();

		$campaign_id = isset($_GET['id']) ? absint($_GET['id']) : 0;
		$type_arg    = isset($_GET['type']) && 'auto' === $_GET['type'] ? '&type=auto' : '';
		$redirect    = admin_url('admin.php?page=wp-news-campaigns' . $type_arg);

		if ($campaign_id) {
			check_admin_referer('wpnews_delete_campaign_' . $campaign_id);
			WPNews_Campaign_Manager::delete_campaign($campaign_id);
		}

		wp_safe_redirect($redirect);
		exit;
	}

	/**
	 * List actions (delete / rename list, remove / blacklist a member) via
	 * admin-post.php, then back to the Lists screen with a notice.
	 *
	 * They used to be GET requests on the Lists page itself with a generic
	 * `action=delete` parameter, which other plugins on the site may intercept
	 * (on alpagrumi.ch deleting a list silently did nothing).
	 */
	public function handle_list_action()
	{
		$this->require_manage_options();

		$op      = isset($_GET['op']) ? sanitize_key(wp_unslash($_GET['op'])) : '';
		$list_id = isset($_GET['id']) ? absint($_GET['id']) : 0;
		$back    = isset($_GET['back']) && 'edit' === $_GET['back'] ? 'edit' : 'list';
		$args    = array('page' => 'wp-news-lists');
		if ('edit' === $back && $list_id) {
			$args['view'] = 'edit';
			$args['id']   = $list_id;
		}

		check_admin_referer('wpnews_list_' . $op . '_' . $list_id);

		$msg = 'error';
		switch ($op) {
			case 'delete':
				if ($list_id && WPNews_List_Manager::get_list($list_id)) {
					WPNews_List_Manager::delete_list($list_id);
					$msg = 'list_deleted';
				}
				break;

			case 'rename':
				$new_name = isset($_GET['new_name']) ? sanitize_text_field(wp_unslash($_GET['new_name'])) : '';
				if ($list_id && '' !== $new_name && WPNews_List_Manager::update_list($list_id, array('name' => $new_name))) {
					$msg = 'list_renamed';
				}
				break;

			case 'remove_sub':
				$sub_id = isset($_GET['sub_id']) ? absint($_GET['sub_id']) : 0;
				if ($list_id && $sub_id) {
					WPNews_List_Manager::remove_subscriber_from_list($sub_id, $list_id);
					$msg = 'sub_removed';
				}
				break;

			case 'blacklist_sub':
				$email = isset($_GET['email']) ? sanitize_email(wp_unslash($_GET['email'])) : '';
				$msg   = ('' !== $email && WPNews_Blacklist_Manager::add_to_blacklist($email, 'Manual from List')) ? 'sub_blacklisted' : 'already_blacklisted';
				break;
		}

		if (isset($_GET['s']) && '' !== $_GET['s']) {
			$args['s'] = sanitize_text_field(wp_unslash($_GET['s']));
		}
		$args['wpnews_msg'] = $msg;
		wp_safe_redirect(add_query_arg($args, admin_url('admin.php')));
		exit;
	}

	/**
	 * Signed admin-post URL for a list action.
	 *
	 * @param string $op      delete|rename|remove_sub|blacklist_sub.
	 * @param int    $list_id List ID.
	 * @param array  $extra   Extra query args.
	 * @return string
	 */
	public static function list_action_url($op, $list_id, $extra = array())
	{
		$url = add_query_arg(
			array_merge(array('action' => 'wpnews_list_action', 'op' => $op, 'id' => (int) $list_id), $extra),
			admin_url('admin-post.php')
		);
		return wp_nonce_url($url, 'wpnews_list_' . $op . '_' . (int) $list_id);
	}

	/**
	 * Handle bulk delete campaigns via admin-post.php.
	 */
	public function handle_bulk_delete_campaigns()
	{
		$this->require_manage_options();
		check_admin_referer('wpnews_bulk_delete_campaigns');

		$campaign_ids = isset($_POST['campaign_ids']) ? array_map('absint', (array) wp_unslash($_POST['campaign_ids'])) : array();

		foreach ($campaign_ids as $campaign_id) {
			if ($campaign_id > 0) {
				WPNews_Campaign_Manager::delete_campaign($campaign_id);
			}
		}

		$type_arg = isset($_POST['type']) && 'auto' === $_POST['type'] ? '&type=auto' : '';
		wp_safe_redirect(admin_url('admin.php?page=wp-news-campaigns' . $type_arg));
		exit;
	}

	/**
	 * Display dashboard page.
	 */
	public function display_dashboard()
	{
		require_once WPNEWS_PLUGIN_DIR . 'admin/partials/dashboard.php';
	}

	/**
	 * Display campaigns page.
	 */
	public function display_campaigns()
	{
		require_once WPNEWS_PLUGIN_DIR . 'admin/partials/campaigns.php';
	}

	/**
	 * Display create campaign page.
	 */
	public function display_create_campaign()
	{
		require_once WPNEWS_PLUGIN_DIR . 'admin/partials/create-campaign.php';
	}

	/**
	 * Display subscribers page.
	 */
	public function display_subscribers()
	{
		require_once WPNEWS_PLUGIN_DIR . 'admin/partials/subscribers.php';
	}

	/**
	 * Display lists page.
	 */
	public function display_lists()
	{
		require_once WPNEWS_PLUGIN_DIR . 'admin/partials/lists.php';
	}

	/**
	 * Display blacklist page.
	 */
	public function display_blacklist()
	{
		require_once WPNEWS_PLUGIN_DIR . 'admin/partials/blacklist.php';
	}

	/**
	 * Display settings page.
	 */
	public function display_settings()
	{
		require_once WPNEWS_PLUGIN_DIR . 'admin/partials/settings.php';
	}
}
