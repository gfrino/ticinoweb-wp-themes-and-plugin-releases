( function () {
    var url = ( window.liceoHero || {} ).video;
    var slider = document.querySelector( '.hero-slider' );
    var img = slider && slider.querySelector( '.slide .slide-image' );
    if ( ! url || ! img ) {
        return;
    }

    // Resta la foto con movimento ridotto, risparmio dati attivo o rete lenta.
    var conn = navigator.connection || {};
    var slow = conn.saveData || /(^|-)2g$|3g/.test( conn.effectiveType || '' );
    var still = window.matchMedia && window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches;
    if ( slow || still ) {
        return;
    }

    function start() {
        var v = document.createElement( 'video' );
        v.className = 'slide-image slide-video';
        v.muted = true;
        v.loop = true;
        v.playsInline = true;
        v.setAttribute( 'playsinline', '' );
        v.setAttribute( 'muted', '' );
        v.setAttribute( 'aria-hidden', 'true' );
        v.disablePictureInPicture = true;
        v.preload = 'auto';
        v.poster = img.currentSrc || img.src;
        v.src = url;
        v.style.opacity = '0';
        v.style.transition = 'opacity .6s ease';
        img.parentNode.insertBefore( v, img.nextSibling );

        // Appare in dissolvenza sopra la foto solo quando il video sta davvero partendo.
        v.addEventListener( 'playing', function () {
            v.style.opacity = '1';
            setTimeout( function () { img.style.visibility = 'hidden'; }, 650 );
        } );

        // Fuori schermo o con la scheda in background si ferma: meno CPU e batteria.
        var visible = true;
        function sync() {
            if ( visible && ! document.hidden ) {
                var p = v.play();
                if ( p && p.catch ) {
                    p.catch( function () {} ); // se il browser blocca l'avvio resta la foto
                }
            } else {
                v.pause();
            }
        }
        if ( 'IntersectionObserver' in window ) {
            new IntersectionObserver( function ( entries ) {
                visible = entries[ 0 ].isIntersecting;
                sync();
            }, { threshold: 0.1 } ).observe( slider );
        }
        document.addEventListener( 'visibilitychange', sync );
        sync();
    }

    // Parte dopo il caricamento della pagina, così non ruba banda a foto, font e testi.
    if ( document.readyState === 'complete' ) {
        start();
    } else {
        window.addEventListener( 'load', function () { setTimeout( start, 100 ); } );
    }
} )();
