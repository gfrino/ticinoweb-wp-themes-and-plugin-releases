<?php
/**
 * WooCommerce adapter (frontend, non-default language only).
 *
 * Product name, description and terms already flow through the generic
 * content filters; this adapter covers the Woo-specific display filters.
 * Everything technical — IDs, SKU, prices, stock, variations, attribute
 * keys, form values, cart, orders, sessions, endpoints, webhooks, payment
 * payloads — is intentionally left untouched: the same product object
 * serves every language.
 *
 * WooCommerce UI strings (buttons, notices, checkout labels) are covered by
 * the request-level locale switch, using the official Woo language packs.
 *
 * @package tw-translate-plus
 */

if (!defined('ABSPATH')) {
    exit;
}

class Twtr_Woo {

    /**
     * Register WooCommerce display filters.
     */
    public static function init() {
        add_filter('woocommerce_short_description', array(__CLASS__, 'short_description'), 20);
        add_filter('woocommerce_attribute_label', array(__CLASS__, 'attribute_label'), 20, 2);
        // Fee names (shipping surcharges, payment fees, rules of fee plugins
        // such as Pricepep Checkout Fees): renamed when the cart is computed,
        // so cart, checkout, AJAX fragments and the order all show the
        // customer's language. Name it in the default language in the fee
        // plugin; the other languages are translated here.
        add_action('woocommerce_cart_calculate_fees', array(__CLASS__, 'fees'), 999);
        // Never translate machine-facing requests: REST (incl. Store API,
        // which has no language prefix) and admin AJAX are excluded upstream
        // because the router only activates on prefixed frontend URLs.
    }

    /**
     * Product short description.
     *
     * @param string $text Rendered short description HTML.
     * @return string
     */
    public static function short_description($text) {
        $post_id = get_the_ID();
        if (!$post_id || trim($text) === '') {
            return $text;
        }
        return Twtr_Resolver::translate($text, 'product:' . (int) $post_id . ':short-description');
    }

    /**
     * Translate the names of the fees added to the cart.
     *
     * @param WC_Cart $cart
     */
    public static function fees($cart) {
        if (!is_object($cart) || !method_exists($cart, 'fees_api')) {
            return;
        }
        foreach ((array) $cart->fees_api()->get_fees() as $fee) {
            if (is_object($fee) && isset($fee->name) && is_string($fee->name) && trim($fee->name) !== '') {
                // Objects are shared with the cart: renaming here updates it.
                $fee->name = Twtr_Resolver::translate(trim(preg_replace('/\s+/u', ' ', $fee->name)), 'woo:fee');
            }
        }
    }

    /**
     * Attribute label as displayed (the attribute slug/key is untouched).
     *
     * @param string $label
     * @param string $name  Attribute slug.
     * @return string
     */
    public static function attribute_label($label, $name = '') {
        if (!is_string($label) || $label === '') {
            return $label;
        }
        return Twtr_Resolver::translate($label, 'woo:attribute:' . sanitize_key($name) . ':label');
    }
}
