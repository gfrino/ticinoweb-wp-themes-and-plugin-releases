<?php
/**
 * Translated URL segments and 301 redirects.
 *
 * tW Translate keeps ONE object per page/product/term. Its URL in another
 * language is /{lang}/ + the original path, unless a translated segment is
 * known: then /de/bewasserung/ is served for /arrosage/ and every internal
 * link built in German uses it. The map is per site and per language:
 *
 *     twtr_slug_map = [ 'de' => [ 'arrosage' => 'bewasserung', 'produit' => 'produkt', … ], … ]
 *
 * It is filled by the WPML importer (so the URLs indexed by Google under
 * WPML stay exactly the same) and can be extended later. Matching is done
 * per path segment, which covers pages (also nested), posts, products,
 * the product base and categories with one rule and no rewrite rules.
 *
 * Redirects: URLs that cannot be reproduced (content that only existed in
 * one language, a different hierarchy…) are stored as old path → new path
 * (twtr_redirects) and answered with a 301 when WordPress would return 404.
 *
 * @package tw-translate-plus
 */

if (!defined('ABSPATH')) {
    exit;
}

class Twtr_Slugs {

    const MAP_OPTION      = 'twtr_slug_map';
    const REDIRECT_OPTION = 'twtr_redirects';

    /** @var array<int,array> Per site: [forward[lang][orig] => tr, reverse[lang][tr] => orig]. */
    private static $maps = array();

    /**
     * Register runtime hooks (front end).
     */
    public static function init() {
        add_action('template_redirect', array(__CLASS__, 'maybe_redirect'), 1);
    }

    /**
     * @return array{forward:array,reverse:array}
     */
    private static function maps() {
        $blog = get_current_blog_id();
        if (!isset(self::$maps[$blog])) {
            $raw     = array_replace_recursive((array) get_option(self::MAP_OPTION, array()), self::$preview);
            $forward = array();
            $reverse = array();
            foreach ((array) $raw as $lang => $pairs) {
                foreach ((array) $pairs as $orig => $tr) {
                    $orig = (string) $orig;
                    $tr   = (string) $tr;
                    if ($orig === '' || $tr === '' || $orig === $tr) {
                        continue;
                    }
                    $forward[$lang][$orig] = $tr;
                    if (!isset($reverse[$lang][$tr])) {
                        $reverse[$lang][$tr] = $orig;
                    }
                }
            }
            self::$maps[$blog] = array('forward' => $forward, 'reverse' => $reverse);
        }
        return self::$maps[$blog];
    }

    /** @var array In-memory additions (dry-run of an import). */
    private static $preview = array();

    /**
     * Add pairs to the map for this request only (simulation, nothing saved).
     *
     * @param array $pairs [lang => [orig => translated]]
     */
    public static function preview_map($pairs) {
        foreach ((array) $pairs as $lang => $list) {
            foreach ((array) $list as $o => $t) {
                self::$preview[$lang][$o] = $t;
            }
        }
        self::flush();
    }

    /**
     * Drop the in-request cache after the map changed.
     */
    public static function flush() {
        unset(self::$maps[get_current_blog_id()]);
    }

    /**
     * Store translated segments (merged with the existing map).
     *
     * @param array $pairs [lang => [orig => translated]]
     */
    public static function save_map($pairs) {
        $map = (array) get_option(self::MAP_OPTION, array());
        foreach ((array) $pairs as $lang => $list) {
            foreach ((array) $list as $orig => $tr) {
                $orig = sanitize_title(rawurldecode((string) $orig));
                $tr   = sanitize_title(rawurldecode((string) $tr));
                if ($orig !== '' && $tr !== '' && $orig !== $tr) {
                    $map[$lang][$orig] = $tr;
                }
            }
        }
        update_option(self::MAP_OPTION, $map, false);
        self::flush();
    }

    /**
     * Incoming request: translated segments back to the original ones.
     *
     * @param string $path_and_query Prefix already removed (/home/bewasserung/?x=1).
     * @param string $lang           Language of the request.
     * @param string $home_path      Home path without trailing slash.
     * @return string
     */
    public static function to_original_path($path_and_query, $lang, $home_path) {
        $rev = self::maps()['reverse'][$lang] ?? array();
        if (!$rev) {
            return $path_and_query;
        }
        return self::map_path($path_and_query, $home_path, function ($seg) use ($rev) {
            return $rev[$seg] ?? null;
        });
    }

    /**
     * Outgoing internal URL in $lang (already prefixed): original segments to
     * translated ones. Segments that belong to another language are first
     * brought back to the original, so switching language works from any page.
     *
     * @param string $url
     * @param string $lang
     * @param string $home_path
     * @return string
     */
    public static function to_translated_url($url, $lang, $home_path) {
        $maps = self::maps();
        if (empty($maps['forward'][$lang]) && empty($maps['reverse'])) {
            return $url;
        }
        $fwd = $maps['forward'][$lang] ?? array();
        $rev = $maps['reverse'];
        return self::map_url($url, $home_path . '/' . $lang, function ($seg) use ($fwd, $rev, $lang) {
            $orig = $seg;
            if (!isset($fwd[$seg])) {
                foreach ($rev as $l => $list) {
                    if (isset($list[$seg])) {
                        $orig = $list[$seg];
                        break;
                    }
                }
            }
            return $fwd[$orig] ?? ($orig !== $seg ? $orig : null);
        });
    }

    /**
     * Default-language URL: any translated segment back to the original.
     *
     * @param string $url
     * @param string $home_path
     * @return string
     */
    public static function to_original_url($url, $home_path) {
        $rev = self::maps()['reverse'];
        if (!$rev) {
            return $url;
        }
        return self::map_url($url, $home_path, function ($seg) use ($rev) {
            foreach ($rev as $list) {
                if (isset($list[$seg])) {
                    return $list[$seg];
                }
            }
            return null;
        });
    }

    /**
     * Apply $fn to every path segment after $base of an absolute URL.
     */
    private static function map_url($url, $base, $fn) {
        if (!is_string($url) || $url === '' || preg_match('#(wp-admin|wp-json|wp-content|wp-includes|\.php)#', $url)) {
            return $url;
        }
        $parts = wp_parse_url($url);
        if (empty($parts['path'])) {
            return $url;
        }
        $new = self::map_path($parts['path'], $base, $fn);
        if ($new === $parts['path']) {
            return $url;
        }
        $pos = strpos($url, $parts['path'], isset($parts['host']) ? strpos($url, $parts['host']) + strlen($parts['host']) : 0);
        return $pos === false ? $url : substr($url, 0, $pos) . $new . substr($url, $pos + strlen($parts['path']));
    }

    /**
     * @param string   $path_and_query
     * @param string   $base Path before the mappable part (home path, + /lang).
     * @param callable $fn   Segment → replacement or null.
     * @return string
     */
    private static function map_path($path_and_query, $base, $fn) {
        $query = '';
        $qpos  = strpos($path_and_query, '?');
        if ($qpos !== false) {
            $query          = substr($path_and_query, $qpos);
            $path_and_query = substr($path_and_query, 0, $qpos);
        }
        if ($base !== '' && strpos($path_and_query, $base) !== 0) {
            return $path_and_query . $query;
        }
        $rest     = substr($path_and_query, strlen($base));
        $segments = explode('/', (string) $rest);
        $changed  = false;
        foreach ($segments as $i => $seg) {
            if ($seg === '') {
                continue;
            }
            $key = rawurldecode($seg);
            $rep = $fn($key);
            if ($rep !== null && $rep !== $key) {
                $segments[$i] = rawurlencode($rep);
                $changed      = true;
            }
        }
        return ($changed ? $base . implode('/', $segments) : $path_and_query) . $query;
    }

    /* ------------------------------------------------------------------
     * Redirects
     * ------------------------------------------------------------------ */

    /**
     * Store old path → new path pairs (merged). Paths are relative to the
     * site root, with leading slash, without host.
     *
     * @param array<string,string> $pairs
     */
    public static function save_redirects($pairs) {
        $all = (array) get_option(self::REDIRECT_OPTION, array());
        foreach ((array) $pairs as $from => $to) {
            $from = self::normalize_path((string) $from);
            $to   = (string) $to;
            if ($from !== '' && $to !== '' && $from !== self::normalize_path($to)) {
                $all[$from] = $to;
            }
        }
        update_option(self::REDIRECT_OPTION, $all, false);
    }

    /**
     * @return array<string,string>
     */
    public static function redirects() {
        return (array) get_option(self::REDIRECT_OPTION, array());
    }

    /**
     * 301 for a known old URL, only when WordPress found nothing (404), so a
     * redirect can never hide a real page.
     */
    public static function maybe_redirect() {
        self::maybe_canonical();
        if (!is_404()) {
            return;
        }
        $req = isset($_SERVER['REQUEST_URI']) ? (string) wp_unslash($_SERVER['REQUEST_URI']) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
        $uri = class_exists('Twtr_Router') ? Twtr_Router::original_uri() : $req;
        $key = self::normalize_path((string) strtok($uri, '?'));
        $all = self::redirects();
        if ($key === '' || !isset($all[$key])) {
            return;
        }
        $to = $all[$key];
        if (strpos($to, 'http') !== 0) {
            $to = home_url($to);
        }
        $qs = (string) parse_url($uri, PHP_URL_QUERY);
        if ($qs !== '') {
            $to .= (strpos($to, '?') === false ? '?' : '&') . $qs;
        }
        wp_safe_redirect($to, 301, 'tW Translate Plus');
        exit;
    }

    /**
     * One URL per page and language: a translated page reached with the
     * original slug (/de/arrosage/ when /de/bewasserung/ exists) is sent to
     * its translated URL with a 301, so search engines never see duplicates.
     */
    private static function maybe_canonical() {
        $lang = class_exists('Twtr_Router') ? Twtr_Router::current_language() : '';
        if ($lang === '' || is_404() || is_preview() || is_paged() || !empty($_GET) || empty(self::maps()['forward'][$lang])) { // phpcs:ignore WordPress.Security.NonceVerification
            return;
        }
        $obj = get_queried_object();
        if (is_singular() && $obj instanceof WP_Post) {
            $target = get_permalink($obj);
        } elseif ((is_category() || is_tag() || is_tax()) && $obj instanceof WP_Term) {
            $target = get_term_link($obj);
        } else {
            return;
        }
        if (!is_string($target) || $target === '') {
            return;
        }
        $target = Twtr_Router::language_url($lang, $target);
        $want   = self::normalize_path($target);
        $have   = self::normalize_path((string) strtok(Twtr_Router::original_uri(), '?'));
        if ($want !== '' && $have !== '' && $want !== $have) {
            wp_safe_redirect($target, 301, 'tW Translate Plus');
            exit;
        }
    }

    /**
     * Path relative to the site root, decoded, with leading and trailing slash.
     *
     * @param string $path
     * @return string
     */
    public static function normalize_path($path) {
        $path = (string) wp_parse_url($path, PHP_URL_PATH);
        if ($path === '') {
            return '';
        }
        $home = rtrim((string) wp_parse_url(get_option('home'), PHP_URL_PATH), '/');
        if ($home !== '' && strpos($path, $home) === 0) {
            $path = substr($path, strlen($home));
        }
        $path = '/' . trim(rawurldecode($path), '/');
        return $path === '/' ? '/' : $path . '/';
    }
}
