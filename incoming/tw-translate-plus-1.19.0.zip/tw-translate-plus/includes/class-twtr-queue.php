<?php
/**
 * Background translation queue.
 *
 * The entries table itself is the queue: rows with status=pending and
 * locked=0 are claimed atomically with a token, translated in small batches
 * and marked ready. Safe under concurrency (claim via single UPDATE),
 * recoverable (stuck claims are released after 10 minutes) and quota-aware.
 *
 * Processing runs via WP-Cron single events (works with a real server cron
 * hitting wp-cron.php), via WP-CLI, or inline from the admin "Processa ora"
 * action. It never runs during a normal frontend visit.
 *
 * @package tw-translate-plus
 */

if (!defined('ABSPATH')) {
    exit;
}

class Twtr_Queue {

    const HOOK = 'twtr_process_queue';
    const MAX_ATTEMPTS = 3;
    const CLAIM_TIMEOUT_MIN = 10;
    const MAX_BATCH_CHARS = 24000;
    const MAX_BATCH_CHARS_LLM = 8000;
    /** Open models (gpt-oss) also spend time reasoning: smaller requests. */
    const MAX_BATCH_CHARS_OPEN = 3000;
    /** Never start an engine request with less time than this left. */
    const MIN_REQUEST_SECONDS = 12;

    /** Parallel requests per wave for language-model engines. */
    const CONCURRENCY = 6;

    /**
     * Indexes of segments the engine returned unchanged although they are
     * real sentences (4+ words): a translation, not a brand name or a code.
     *
     * @param string[] $sources
     * @param string[] $outputs
     * @return int[]
     */
    public static function echoed($sources, $outputs) {
        $out = array();
        foreach ($sources as $i => $src) {
            if (!isset($outputs[$i])) {
                continue;
            }
            $a = self::plain($src);
            if ($a === '' || count(preg_split('/\s+/u', $a)) < 4) {
                continue;
            }
            if ($a === self::plain($outputs[$i])) {
                $out[] = $i;
            }
        }
        return $out;
    }

    /** @return string Lower-cased text without tags, entities and extra spaces. */
    private static function plain($html) {
        $t = html_entity_decode(wp_strip_all_tags((string) $html), ENT_QUOTES | ENT_HTML5, 'UTF-8');
        $t = str_replace(array("\u{2019}", "\u{2018}", "\u{201C}", "\u{201D}", "\u{2013}", "\u{2014}", "\u{00A0}"), array("'", "'", '"', '"', '-', '-', ' '), $t);
        return mb_strtolower(trim(preg_replace('/\s+/u', ' ', $t)));
    }

    /**
     * Sanitize engine output before it is stored and printed: post-level
     * HTML only, plus the tags/attributes the source itself contains (an
     * embed written by a trusted author survives; anything the model, a
     * compromised endpoint or a prompt injection adds does not).
     *
     * @param string $source
     * @param string $translation
     * @return string
     */
    public static function clean($source, $translation) {
        $allowed = wp_kses_allowed_html('post');
        if (preg_match_all('/<([a-z][a-z0-9-]*)\b([^>]*)>/i', (string) $source, $tags, PREG_SET_ORDER)) {
            foreach ($tags as $tag) {
                $name = strtolower($tag[1]);
                if (!isset($allowed[$name])) {
                    $allowed[$name] = array();
                }
                if (preg_match_all('/([a-z_:][a-z0-9_:.-]*)\s*=/i', $tag[2], $attrs)) {
                    foreach ($attrs[1] as $attr) {
                        $allowed[$name][strtolower($attr)] = true;
                    }
                }
            }
        }
        return wp_kses((string) $translation, $allowed);
    }

    /**
     * Whether a failed parallel answer may succeed when retried alone:
     * yes for glitches (misaligned, network, 400 to adapt, rate limit,
     * server errors), no for key, credit or model problems.
     *
     * @param WP_Error $error
     * @return bool
     */
    private static function worth_retrying($error) {
        $code = $error->get_error_code();
        if (in_array($code, array('twtr_misaligned', 'twtr_network', 'twtr_response', 'twtr_http_400', 'twtr_http_429'), true)) {
            return true;
        }
        return (bool) preg_match('/^twtr_http_5\d\d$/', $code);
    }

    /** @return int */
    public static function concurrency() {
        return max(1, min(16, (int) apply_filters('twtr_concurrency', self::CONCURRENCY, Twtr_Settings::provider())));
    }

    /** @var string[] When set, claim only entries whose context starts with one of these. */
    private static $only_prefixes = array();

    /**
     * Translate one post right now («Traduci adesso»): its pending entries
     * jump the queue, within $seconds. Whatever is left continues in the
     * background.
     *
     * @param int $post_id
     * @param int $seconds
     * @return array{processed:int,reused:int,errors:int,remaining:int,message:string}
     */
    public static function process_post($post_id, $seconds = 40, $html_hashes = array()) {
        self::$only_prefixes = Twtr_Storage::post_context_prefixes($post_id);
        self::$only_hashes   = array_values(array_unique(array_filter((array) $html_hashes)));
        try {
            return self::process_for($seconds);
        } finally {
            self::$only_prefixes = array();
            self::$only_hashes   = array();
        }
    }

    /** @var string[] With $only_prefixes: also claim these page-level ("html") texts. */
    private static $only_hashes = array();

    /** @var float Hard end of the current run (microtime), 0 = none. */
    private static $deadline = 0.0;

    /**
     * Seconds left in the current run (PHP_INT_MAX when unbounded). Web
     * servers kill long requests (LiteSpeed: ~120 s), so every engine call
     * is sized to finish before the run's deadline.
     *
     * @return float
     */
    public static function time_left() {
        return self::$deadline > 0 ? self::$deadline - microtime(true) : (float) PHP_INT_MAX;
    }
    /** Time budget of one cron run: well under the usual 60 s PHP limit. */
    const RUN_SECONDS = 45;

    /**
     * Character budget of a single request to the engine.
     *
     * Google answers one translation per input string and has no output
     * ceiling worth worrying about. An LLM re-emits the whole batch as
     * generated tokens instead, so a batch that is fine on input can still
     * hit the model's maximum output length and come back truncated — which
     * would fail the entire chunk. Hence the smaller budget for OpenAI.
     *
     * @return int
     */
    public static function max_batch_chars() {
        $chars = Twtr_Settings::provider() === 'compat' ? self::MAX_BATCH_CHARS_OPEN
            : (Twtr_Settings::is_llm() ? self::MAX_BATCH_CHARS_LLM : self::MAX_BATCH_CHARS);
        return max(500, (int) apply_filters('twtr_max_batch_chars', $chars, Twtr_Settings::provider()));
    }

    /**
     * Schedule a near-future processing run for this site (idempotent).
     */
    public static function schedule() {
        /*
         * IL FRENO CENTRALE. Ogni innesco automatico — l'estrattore quando un
         * post o un termine viene salvato, il resolver alla prima visita
         * frontend di una pagina in una lingua attiva, il ripristino di una
         * traduzione automatica o il rimettere in coda gli errori dal tab
         * Traduzioni — passa da qui prima di arrivare al cron. Un solo
         * controllo, in un solo posto, invece di quattro sparsi nel codice
         * che potrebbero disallinearsi nel tempo.
         *
         * "Processa ora" (Twtr_Queue::process(), chiamato direttamente da
         * ajax_process_now() e dal comando WP-CLI) non passa da qui: resta
         * sempre disponibile per tradurre su decisione esplicita, anche con
         * l'interruttore spento. Attivare una lingua non deve mai, da solo,
         * avviare una traduzione automatica non richiesta.
         */
        if (!Twtr_Settings::auto_translate()) {
            return;
        }
        // Senza la chiave del sito non c'e' nulla da elaborare: niente cron.
        if (!Twtr_Settings::engine_ready()) {
            return;
        }
        if (!wp_next_scheduled(self::HOOK)) {
            wp_schedule_single_event(time() + 30, self::HOOK);
        }
        // The cron event is a bonus; the self-driven worker does the job.
        Twtr_Worker::nudge();
    }

    /**
     * Process batches back to back for up to $seconds.
     *
     * One batch per cron run made the queue crawl: on a multisite whose
     * server cron reaches each site every few minutes, 25 strings per visit
     * meant days for a catalogue. Stops early when a batch makes no
     * progress (quota reached, engine error, nothing left), so a failing
     * engine is not hammered for the whole budget. The next run is still
     * scheduled by process() itself.
     *
     * @param int $seconds
     * @return array{processed:int,errors:int,remaining:int,message:string}
     */
    public static function process_for($seconds) {
        $deadline = microtime(true) + max(1, (int) $seconds);
        self::$deadline = $deadline;
        $total    = array('processed' => 0, 'reused' => 0, 'errors' => 0, 'remaining' => 0, 'message' => '');
        do {
            $started = microtime(true);
            $result  = self::process();
            $total['processed'] += $result['processed'];
            $total['reused']    += $result['reused'];
            $total['errors']    += $result['errors'];
            $total['remaining']  = $result['remaining'];
            $total['message']    = $result['message'];
            $took = microtime(true) - $started;
            // Leave room for one more batch of similar length.
        } while (($result['processed'] + $result['reused']) > 0 && $result['errors'] === 0 && $result['remaining'] > 0
            && microtime(true) + $took < $deadline && self::time_left() > self::MIN_REQUEST_SECONDS);
        self::$deadline = 0.0;
        return $total;
    }

    /**
     * Process one batch for the current site.
     *
     * @param int|null $batch_size Override the configured batch size.
     * @return array{processed:int,errors:int,remaining:int,message:string}
     */
    public static function process($batch_size = null) {
        global $wpdb;
        $table   = Twtr_Storage::entries_table();
        $blog_id = get_current_blog_id();
        $n       = Twtr_Settings::network();
        $size    = $batch_size ? (int) $batch_size : max(1, (int) $n['batch_size']);
        if (!$batch_size && Twtr_Settings::is_llm()) {
            // Enough rows to fill every parallel request of one wave.
            $size = max($size, self::concurrency() * 25);
        }
        $default = Twtr_Settings::default_lang();
        $result  = array('processed' => 0, 'reused' => 0, 'errors' => 0, 'remaining' => 0, 'message' => '');

        // Release claims stuck by fatals/timeouts.
        $wpdb->query($wpdb->prepare(
            "UPDATE {$table} SET claim_token = NULL WHERE blog_id = %d AND claim_token IS NOT NULL AND updated_at < (UTC_TIMESTAMP() - INTERVAL %d MINUTE)",
            $blog_id, self::CLAIM_TIMEOUT_MIN
        ));

        // Translation memory first: free, needs no engine, ignores the quota.
        // At most every 30 s: within a run, batches dedupe themselves.
        static $memory_at = 0;
        if (microtime(true) - $memory_at > 30) {
            $memory_at        = microtime(true);
            $result['reused'] = Twtr_Storage::fill_from_memory();
        }

        // No key of its own, no translation: there is no network fallback.
        // Entries stay pending and are processed once the site gets a key.
        if (!Twtr_Settings::engine_ready()) {
            $result['message']   = Twtr_Settings::engine_missing_reason();
            $result['remaining'] = self::remaining();
            return $result;
        }

        // Quota guard: the site's own limit against the site's own usage.
        $limit = Twtr_Settings::daily_char_limit();
        if ($limit > 0 && Twtr_Settings::usage_today() >= $limit) {
            $result['message']   = __('Limite giornaliero di caratteri raggiunto: la coda riprende domani.', 'tw-translate-plus');
            $result['remaining'] = self::remaining();
            self::reschedule_if_needed($result['remaining'], 6 * HOUR_IN_SECONDS);
            return $result;
        }

        // Keep Google glossaries aligned before translating (no-op when clean,
        // and skipped entirely on engines that take the glossary inline).
        twtr_glossary();
        if (Twtr_Glossary::remote_sync_supported() && self::glossary_needs_attention()) {
            Twtr_Glossary::refresh_sync();
        }

        // Atomic claim (optionally limited to one post's contexts).
        $token  = uniqid('twtr', true);
        $token  = substr($token, 0, 23);
        $only   = '';
        $params = array($token, $blog_id);
        if (self::$only_prefixes) {
            $likes = array();
            foreach (self::$only_prefixes as $prefix) {
                $likes[]  = 'context_key LIKE %s';
                $params[] = $wpdb->esc_like($prefix) . '%';
            }
            if (self::$only_hashes) {
                $likes[] = "(context_key = 'html' AND source_hash IN (" . implode(',', array_fill(0, count(self::$only_hashes), '%s')) . '))';
                $params  = array_merge($params, self::$only_hashes);
            }
            $only = ' AND (' . implode(' OR ', $likes) . ')';
        }
        $params[] = $size;
        $wpdb->query($wpdb->prepare(
            "UPDATE {$table} SET claim_token = %s, updated_at = UTC_TIMESTAMP()
             WHERE blog_id = %d AND status = 'pending' AND locked = 0 AND claim_token IS NULL{$only}
             ORDER BY id ASC LIMIT %d",
            $params
        ));
        $rows = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$table} WHERE blog_id = %d AND claim_token = %s",
            $blog_id, $token
        ));

        if (!$rows) {
            $result['remaining'] = self::remaining();
            return $result;
        }

        $engine  = twtr_translator();
        $origin  = Twtr_Settings::provider();
        twtr_glossary();
        $version = Twtr_Glossary::version();

        // Jobs: per locale, char-bounded sub-batches with identical texts
        // sent once.
        $by_locale = array();
        foreach ($rows as $row) {
            $by_locale[$row->target_locale][] = $row;
        }
        $jobs = array();
        foreach ($by_locale as $locale => $locale_rows) {
            foreach (self::chunk_by_chars($locale_rows) as $chunk) {
                $texts = array();
                $slot  = array();
                foreach ($chunk as $row) {
                    if (!isset($slot[$row->source_hash])) {
                        $slot[$row->source_hash] = count($texts);
                        $texts[] = $row->source_text;
                    }
                }
                $jobs[] = array('locale' => $locale, 'rows' => $chunk, 'texts' => $texts, 'slot' => $slot);
            }
        }

        // Language models: send CONCURRENCY batches at once (one round trip
        // for all of them). Google and single batches: one at a time.
        $parallel = Twtr_Settings::is_llm() && method_exists($engine, 'translate_many');
        $wave     = $parallel ? self::concurrency() : 1;
        $stop     = false;
        foreach (array_chunk($jobs, $wave) as $group) {
            if (self::time_left() < self::MIN_REQUEST_SECONDS) {
                break; // out of time: the rest is released below, untouched
            }
            $answers = array();
            if (count($group) > 1) {
                $many = array();
                foreach ($group as $k => $job) {
                    $many[$k] = array($job['texts'], $default, $job['locale']);
                }
                $answers = $engine->translate_many($many);
            }
            foreach ($group as $k => $job) {
                $unique = isset($answers[$k]) ? $answers[$k] : null;
                // Single job, or a parallel answer to retry alone (adapts to
                // 400s, splits misaligned batches, retries network errors).
                if ($unique === null || (is_wp_error($unique) && self::worth_retrying($unique))) {
                    $unique = self::translate_texts($engine, $job['texts'], $default, $job['locale']);
                }
                if (is_wp_error($unique) && $unique->get_error_code() === 'twtr_deadline') {
                    $stop = true; // not a failure: the rows go back to the queue as they are
                    break;
                }
                if (is_wp_error($unique)) {
                    $message = mb_substr($unique->get_error_message(), 0, 490);
                    foreach ($job['rows'] as $row) {
                        self::mark_failed($row, $message);
                        $result['errors']++;
                    }
                    $result['message'] = $message;
                    continue;
                }

                // A model sometimes hands a segment back untranslated inside a
                // batch: ask again for those segments alone. If the answer is
                // still the same text, the model confirms it stays as it is
                // (names, addresses, brands: «Choco Duo», «Alla Monda 12,
                // 6515 Gudo») and it is accepted. Only when the retry could
                // not run is the segment left for later.
                $echo = self::echoed($job['texts'], $unique);
                if ($echo && self::time_left() > self::MIN_REQUEST_SECONDS) {
                    // Each one truly alone (one segment per request), in
                    // parallel when the engine supports it.
                    $alone = array();
                    foreach ($echo as $i) {
                        $alone[$i] = array(array($job['texts'][$i]), $default, $job['locale']);
                    }
                    $again = ($parallel && count($alone) > 1) ? $engine->translate_many($alone) : array();
                    $left  = array();
                    foreach ($echo as $i) {
                        $one = isset($again[$i]) ? $again[$i] : self::translate_texts($engine, array($job['texts'][$i]), $default, $job['locale']);
                        if (is_array($one) && isset($one[0])) {
                            $unique[$i] = $one[0]; // confirmed alone: accepted, even if unchanged
                        } else {
                            $left[] = $i;
                        }
                    }
                    $echo = $left;
                }
                $echo_hash = array();
                foreach ($echo as $i) {
                    $echo_hash[md5($job['texts'][$i])] = true;
                }

                Twtr_Settings::add_usage(array_sum(array_map('mb_strlen', $job['texts'])));
                $now      = current_time('mysql', true);
                $contexts = array();
                $wpdb->query('START TRANSACTION');
                foreach ($job['rows'] as $row) {
                    if (isset($echo_hash[$row->source_hash])) {
                        self::mark_failed($row, __('Il motore ha restituito il testo senza tradurlo: verrà riprovato.', 'tw-translate-plus'));
                        $result['errors']++;
                        continue;
                    }
                    $wpdb->update($table, array(
                        'translated_text'  => self::clean($row->source_text, $unique[$job['slot'][$row->source_hash]]),
                        'origin'           => $origin,
                        'status'           => 'ready',
                        'attempts'         => 0,
                        'glossary_version' => $version,
                        'claim_token'      => null,
                        'error_message'    => null,
                        'updated_at'       => $now,
                    ), array('id' => (int) $row->id));
                    $contexts[$row->target_locale . "\n" . $row->context_key] = array($row->target_locale, $row->context_key);
                    $result['processed']++;
                }
                $wpdb->query('COMMIT');
                foreach ($contexts as $c) {
                    Twtr_Resolver::flush_group($c[0], $c[1]);
                    Twtr_Cache::purge_for_context($c[1], $c[0]);
                }
            }
            if ($stop) {
                break;
            }
        }

        // Rows of this claim not handled (deadline): back to the queue now
        // instead of waiting for the 10-minute stale-claim release.
        $wpdb->query($wpdb->prepare(
            "UPDATE {$table} SET claim_token = NULL WHERE blog_id = %d AND claim_token = %s AND status = 'pending'",
            $blog_id, $token
        ));

        $result['remaining'] = self::remaining();
        self::reschedule_if_needed($result['remaining'], 60);
        return $result;
    }

    /**
     * Translate a batch; when an LLM drops or merges segments, split the
     * batch in halves and retry each half instead of failing every row.
     * A few segments trip the model, not the whole batch: halving isolates
     * them, and a single segment can never come back misaligned in count.
     *
     * @param Twtr_Google|Twtr_Openai $engine
     * @param string[]                $texts
     * @param string                  $source
     * @param string                  $target
     * @return string[]|WP_Error
     */
    private static function translate_texts($engine, $texts, $source, $target) {
        if (self::time_left() < self::MIN_REQUEST_SECONDS) {
            return new WP_Error('twtr_deadline', 'run deadline');
        }
        $result = $engine->translate_batch($texts, $source, $target);
        if (!is_wp_error($result) || $result->get_error_code() !== 'twtr_misaligned' || count($texts) < 2) {
            return $result;
        }
        $half  = (int) ceil(count($texts) / 2);
        $first = self::translate_texts($engine, array_slice($texts, 0, $half), $source, $target);
        if (is_wp_error($first)) {
            return $first;
        }
        $second = self::translate_texts($engine, array_slice($texts, $half), $source, $target);
        if (is_wp_error($second)) {
            return $second;
        }
        return array_merge($first, $second);
    }

    /**
     * Pending entries left for the current site.
     *
     * @return int
     */
    public static function remaining() {
        global $wpdb;
        return (int) $wpdb->get_var($wpdb->prepare(
            'SELECT COUNT(*) FROM ' . Twtr_Storage::entries_table() .
            " WHERE blog_id = %d AND status = 'pending' AND locked = 0",
            get_current_blog_id()
        ));
    }

    /**
     * Failure handling: retry with attempt counter, then park as error.
     *
     * @param object $row
     * @param string $message
     */
    private static function mark_failed($row, $message) {
        global $wpdb;
        $attempts = (int) $row->attempts + 1;
        $wpdb->update(Twtr_Storage::entries_table(), array(
            'status'        => $attempts >= self::MAX_ATTEMPTS ? 'error' : 'pending',
            'attempts'      => $attempts,
            'claim_token'   => null,
            'error_message' => $message,
            'updated_at'    => current_time('mysql', true),
        ), array('id' => (int) $row->id));
    }

    /**
     * Split rows into sub-batches bounded by total character count.
     *
     * @param object[] $rows
     * @return object[][]
     */
    private static function chunk_by_chars($rows) {
        $chunks  = array();
        $current = array();
        $chars   = 0;
        $budget  = self::max_batch_chars();
        foreach ($rows as $row) {
            $len = mb_strlen($row->source_text);
            if ($current && ($chars + $len) > $budget) {
                $chunks[] = $current;
                $current  = array();
                $chars    = 0;
            }
            $current[] = $row;
            $chars    += $len;
        }
        if ($current) {
            $chunks[] = $current;
        }
        return $chunks;
    }

    /**
     * @param int $remaining
     * @param int $delay Seconds.
     */
    private static function reschedule_if_needed($remaining, $delay) {
        if ($remaining > 0 && !wp_next_scheduled(self::HOOK)) {
            wp_schedule_single_event(time() + $delay, self::HOOK);
        }
    }

    /**
     * @return bool Whether the site's Google glossaries are behind the
     *              site's glossary, or a pair is dirty or syncing.
     */
    private static function glossary_needs_attention() {
        $e = Twtr_Settings::engine();
        if ((int) $e['glossary_synced_version'] !== Twtr_Glossary::version()) {
            return true;
        }
        foreach ((array) $e['glossary_state'] as $info) {
            if (isset($info['status']) && in_array($info['status'], array('dirty', 'syncing'), true)) {
                return true;
            }
        }
        return false;
    }
}
