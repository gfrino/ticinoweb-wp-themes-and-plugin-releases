/* global twtrPost, jQuery */
/**
 * tW Translate Plus — «Traduci adesso» in the editor's Traduzioni box.
 */
(function ($) {
    'use strict';

    $(document).on('click', '.twtr-translate-now', function () {
        var $btn = $(this),
            $box = $btn.closest('.twtr-post-box'),
            $fb = $box.find('.twtr-post-feedback');

        $btn.prop('disabled', true);
        $fb.removeClass('twtr-feedback-ok twtr-feedback-error').text(twtrPost.working);
        $.post(twtrPost.ajaxUrl, {
            action: 'twtr_translate_post',
            _ajax_nonce: twtrPost.nonce,
            post_id: $box.data('post')
        }).done(function (res) {
            if (res && res.success) {
                $box.find('.twtr-post-box-status').html(res.data.html);
                $fb.text(res.data.message).addClass('twtr-feedback-ok');
            } else {
                $fb.text(res && res.data && res.data.message ? res.data.message : twtrPost.error).addClass('twtr-feedback-error');
            }
        }).fail(function () {
            $fb.text(twtrPost.error).addClass('twtr-feedback-error');
        }).always(function () {
            $btn.prop('disabled', false);
        });
    });
})(jQuery);
