<?php
/** Native footer navigation and legal-page identity. @package AutonecChildTheme */
if ( ! defined( 'ABSPATH' ) ) { exit; }

function autonec_footer_menus() {
 register_nav_menus( array(
  'footer_brands' => __( 'Footer — Marchi', 'autonec-child-theme' ),
  'footer_legal' => __( 'Footer — Informazioni legali', 'autonec-child-theme' ),
 ) );
}
add_action( 'after_setup_theme', 'autonec_footer_menus' );

/** Render only assigned native menus: never a generated page-list fallback. */
function autonec_footer_navigation( $location, $label, $level = 3 ) {
 if ( ! has_nav_menu( $location ) ) { return; }
 $tag = 2 === $level ? 'h2' : 'h3';
 printf( '<nav class="an-footer__navigation an-footer__navigation--%s" aria-label="%s"><%s>%s</%s>', esc_attr( sanitize_html_class( $location ) ), esc_attr( $label ), $tag, esc_html( $label ), $tag );
 wp_nav_menu( array( 'theme_location'=>$location, 'container'=>false, 'menu_class'=>'an-footer-menu', 'fallback_cb'=>false, 'depth'=>1 ) );
 echo '</nav>';
}

/** Use each native brand page's existing logo, without a second CMS input. */
function autonec_footer_brand_title( $title, $item, $args ) {
 if ( ( $args->theme_location ?? '' ) !== 'footer_brands' ) { return $title; }
 $page_id = 'page' === ( $item->object ?? '' ) ? (int) $item->object_id : autonec_home_media_owner( $item->url ?? '' );
 if ( ! $page_id || 'template-marque.php' !== get_page_template_slug( $page_id ) ) { return $title; }
 $logo_id = get_post_thumbnail_id( $page_id );
 if ( ! $logo_id ) { return $title; }
 $image = wp_get_attachment_image( $logo_id, 'medium', false, array(
  'class'=>'an-footer-brand__logo', 'alt'=>'', 'aria-hidden'=>'true',
  'loading'=>'lazy', 'decoding'=>'async', 'sizes'=>'88px',
 ) );
 if ( ! $image ) { return $title; }
 return '<span class="an-footer-brand__image" aria-hidden="true">' . $image . '</span><span class="an-footer-brand__name">' . $title . '</span>';
}
add_filter( 'nav_menu_item_title', 'autonec_footer_brand_title', 30, 3 );

/** Same contact data as the footer, inside a named native editable group. */
function autonec_legal_identity( $html, $block ) {
 if ( ! is_page_template( 'template-legal.php' ) || ! in_array( 'an-legal-identity', preg_split( '/\s+/', $block['attrs']['className'] ?? '' ), true ) ) { return $html; }
 $contact = ticinoweb_get_contact_info();
 $details = '<address><strong>' . esc_html( autonec_site_name() ) . '</strong>';
 if ( $contact['address'] ) { $details .= '<span>' . nl2br( esc_html( $contact['address'] ) ) . '</span>'; }
 if ( $contact['email'] ) { $details .= '<a href="' . esc_url( 'mailto:' . sanitize_email( $contact['email'] ) ) . '">' . esc_html( $contact['email'] ) . '</a>'; }
 if ( $contact['phone'] ) { $details .= '<a href="tel:' . esc_attr( preg_replace( '/[^+0-9]/', '', $contact['phone'] ) ) . '">' . esc_html( $contact['phone_display'] ?: $contact['phone'] ) . '</a>'; }
 if ( $contact['vat'] ) { $details .= '<span>' . esc_html( $contact['vat'] ) . '</span>'; }
 $details .= '</address>';
 $end = strrpos( $html, '</div>' );
 return false === $end ? $html : substr_replace( $html, $details, $end, 0 );
}
add_filter( 'render_block_core/group', 'autonec_legal_identity', 20, 2 );
