<?php
/** Team: the parent's configurable CPT owns each person; shared company contacts stay native. */
defined('ABSPATH') || exit;

function autonec_team_sanitize($input) {
 if(!is_array($input))return new WP_Error('team_data',__('Controlla i dati del collaboratore.','autonec-child-theme'));
 foreach(['role','email','phone','phone_source'] as $key)if(isset($input[$key])&&!is_string($input[$key]))return new WP_Error('team_data',__('Controlla i dati del collaboratore.','autonec-child-theme'));
 $email=trim($input['email']??'');$source=$input['phone_source']??'direct';
 if($email!==''&&!is_email($email))return new WP_Error('team_email',__('Inserisci un indirizzo email valido. I contatti precedenti sono stati conservati.','autonec-child-theme'));
 if(!in_array($source,['direct','sales','workshop'],true))return new WP_Error('team_phone',__('Scegli un recapito telefonico valido.','autonec-child-theme'));
 return ['role'=>sanitize_text_field($input['role']??''),'email'=>sanitize_email($email),'phone'=>sanitize_text_field($input['phone']??''),'phone_source'=>$source];
}
function autonec_team_phone($data) {
 switch($data['phone_source']??'direct'){
  case 'sales':return (string)get_option('ticinoweb_contact_phone','');
  case 'workshop':return (string)get_option('ticinoweb_contact_phone_landline','');
  default:return (string)($data['phone']??'');
 }
}
function autonec_team_phone_href($phone) {
 $number=preg_replace('/[^+0-9]/','',(string)$phone);
 return preg_match('/^\+?[0-9]{6,18}$/D',$number)?'tel:'.$number:'';
}
function autonec_team_data($id) {
 $data=get_post_meta($id,'_an_team',true);
 $data=is_array($data)?$data:[];
 return array_merge(['role'=>'','email'=>'','phone'=>'','phone_source'=>'direct'],$data);
}
/** Only published records; a request cache avoids repeating the query in the footer. */
function autonec_team_members() {
 static $members=[];$key=get_current_blog_id().':'.get_locale();
 if(!isset($members[$key]))$members[$key]=get_posts(['post_type'=>'collaboratori','post_status'=>'publish','posts_per_page'=>-1,'orderby'=>['menu_order'=>'ASC','title'=>'ASC'],'no_found_rows'=>true,'suppress_filters'=>false]);
 return $members[$key];
}
function autonec_team_contact_links($data,$name) {
 $phone=autonec_team_phone($data);$href=autonec_team_phone_href($phone);
 if($href){$label='workshop'===($data['phone_source']??'')?sprintf(__('Chiama l’officina per %s','autonec-child-theme'),$name):sprintf(__('Chiama %s','autonec-child-theme'),$name);
  printf('<a href="%s" aria-label="%s">%s%s</a>',esc_url($href),esc_attr($label),esc_html($phone),'workshop'===($data['phone_source']??'')?'<span class="an-team-contact-note">'.esc_html__('Officina','autonec-child-theme').'</span>':'');
 }
 if(is_email($data['email']??''))printf('<a href="%s" aria-label="%s">%s</a>',esc_url('mailto:'.$data['email']),esc_attr(sprintf(__('Scrivi a %s','autonec-child-theme'),$name)),esc_html($data['email']));
}
function autonec_team_shortcode() {
 $members=autonec_team_members();if(!$members)return '';
 ob_start();?><div class="an-company-people an-team-list">
 <?php foreach($members as $person):$data=autonec_team_data($person->ID);$name=get_the_title($person);$role=ticinoweb_frontend_text($data['role'],'autonec:team:'.$person->ID.':role');?>
 <article class="an-company-person an-team-person">
 <?php if(has_post_thumbnail($person)):?><figure class="an-company-portrait"><?php echo get_the_post_thumbnail($person,'medium',['alt'=>$name,'loading'=>'lazy','sizes'=>'(max-width: 599px) 100px, 160px']);?></figure><?php endif;?>
 <div class="an-team-person__details"><h3><?php echo esc_html($name);?></h3><?php if($role):?><p class="an-team-role"><?php echo esc_html($role);?></p><?php endif;?>
 <div class="an-team-links"><?php autonec_team_contact_links($data,$name);?></div></div>
 </article><?php endforeach;?></div><?php return ob_get_clean();
}
add_shortcode('autonec_team','autonec_team_shortcode');

/** These fields already exist in the parent Contact CMS: no new company phone or email options. */
function autonec_footer_company_contacts() {
 $seen=[];
 foreach(['ticinoweb_contact_phone'=>__('Ufficio vendite','autonec-child-theme'),'ticinoweb_contact_phone_landline'=>__('Officina','autonec-child-theme'),'ticinoweb_contact_phone_mobile'=>__('Cellulare','autonec-child-theme')] as $key=>$label){
  $phone=(string)get_option($key,'');$href=autonec_team_phone_href($phone);if(!$href||isset($seen[$href]))continue;$seen[$href]=true;
  printf('<div class="an-footer__contact-item"><span>%s</span><a class="an-footer__phone" href="%s">%s</a></div>',esc_html($label),esc_url($href),esc_html($phone));
 }
 foreach(['ticinoweb_contact_email','ticinoweb_contact_email_2','ticinoweb_contact_email_3'] as $key){$email=sanitize_email((string)get_option($key,''));if(!$email||isset($seen[strtolower($email)]))continue;$seen[strtolower($email)]=true;printf('<a href="%s">%s</a>',esc_url('mailto:'.$email),esc_html($email));}
}
function autonec_footer_team() {
 $members=autonec_team_members();if(!$members)return;
 ?><section class="an-footer__team" aria-label="<?php esc_attr_e('Contatti del team','autonec-child-theme');?>"><?php foreach($members as $person):$data=autonec_team_data($person->ID);if(!autonec_team_phone_href(autonec_team_phone($data))&&!is_email($data['email']))continue;$name=get_the_title($person);?>
 <div class="an-footer__person"><h3><?php echo esc_html($name);?></h3><?php if($data['role']):?><p><?php echo esc_html(ticinoweb_frontend_text($data['role'],'autonec:team:'.$person->ID.':role'));?></p><?php endif;?><div class="an-team-links"><?php autonec_team_contact_links($data,$name);?></div></div>
 <?php endforeach;?></section><?php
}
