(() => {
 'use strict';
 const section=document.getElementById('recensioni');
 if(!section)return;
 const viewport=section.querySelector('.an-reviews__viewport'),track=section.querySelector('.an-reviews__track'),list=section.querySelector('.an-reviews__list'),controls=section.querySelector('.an-reviews__controls'),toggle=section.querySelector('[data-reviews-toggle]');
 if(!viewport||!track||!list||!toggle||list.children.length<2||!('IntersectionObserver' in window)||!('ResizeObserver' in window))return;
 const reduced=matchMedia('(prefers-reduced-motion: reduce)'),connection=navigator.connection;
 let clone=null,distance=0,position=0,last=0,frame=null,visible=false,hovered=false,focused=false,dragging=false,userPaused=false,suspended=false;
 const quiet=()=>reduced.matches||!!connection?.saveData;
 const canRun=()=>visible&&!document.hidden&&!suspended&&!quiet()&&!userPaused&&!hovered&&!focused&&!dragging&&distance>viewport.clientWidth;
 function stop(){if(frame!==null)cancelAnimationFrame(frame);frame=null;last=0;}
 function tick(time){
  frame=null;
  if(!canRun()){last=0;return;}
  if(last){position=(position+Math.min(48,time-last)*.026)%distance;viewport.scrollLeft=position;}
  last=time;frame=requestAnimationFrame(tick);
 }
 function reconcile(){
  stop();
  toggle.textContent=userPaused?toggle.dataset.resume:toggle.dataset.pause;
  controls.hidden=quiet()||distance<=viewport.clientWidth;
  if(canRun()){position=viewport.scrollLeft%distance;frame=requestAnimationFrame(tick);}
 }
 function measure(){
  const width=viewport.clientWidth;if(!width)return;
  const gap=innerWidth<700?24:32,columns=innerWidth>=1000?3:innerWidth>=700?2:1.12;
  viewport.style.setProperty('--an-review-width',`${Math.max(230,(width-gap*(Math.ceil(columns)-1))/columns)}px`);
  distance=list.getBoundingClientRect().width;
  // Only a visual continuation: readers and keyboard users encounter each review once.
  if(!quiet()&&distance>width){
   if(!clone){clone=list.cloneNode(true);clone.setAttribute('aria-hidden','true');clone.inert=true;clone.querySelectorAll('[id]').forEach(el=>el.removeAttribute('id'));clone.querySelectorAll('a,button,[tabindex]').forEach(el=>el.setAttribute('tabindex','-1'));track.append(clone);}
  }else if(clone){clone.remove();clone=null;}
  if(viewport.scrollLeft>=distance)viewport.scrollLeft%=distance;
  reconcile();
 }
 section.classList.add('is-loop');viewport.tabIndex=0;viewport.setAttribute('aria-label',section.querySelector('h2').textContent);
 toggle.addEventListener('click',()=>{userPaused=!userPaused;reconcile();});
 viewport.addEventListener('pointerenter',event=>{if(event.pointerType==='mouse'){hovered=true;reconcile();}});
 viewport.addEventListener('pointerleave',event=>{if(event.pointerType==='mouse'){hovered=false;reconcile();}});
 viewport.addEventListener('focusin',()=>{focused=true;reconcile();});
 viewport.addEventListener('focusout',event=>{focused=viewport.contains(event.relatedTarget);reconcile();});
 viewport.addEventListener('pointerdown',()=>{dragging=true;userPaused=true;reconcile();},{passive:true});
 window.addEventListener('pointerup',()=>{if(dragging){dragging=false;reconcile();}},{passive:true});
 window.addEventListener('pointercancel',()=>{dragging=false;reconcile();},{passive:true});
 viewport.addEventListener('wheel',event=>{if(Math.abs(event.deltaX)>Math.abs(event.deltaY)||event.shiftKey){userPaused=true;reconcile();}},{passive:true});
 new IntersectionObserver(entries=>{visible=entries[0].isIntersecting;reconcile();},{threshold:0}).observe(viewport);
 new ResizeObserver(measure).observe(viewport);
 reduced.addEventListener('change',measure);connection?.addEventListener?.('change',measure);
 document.addEventListener('visibilitychange',reconcile);
 window.addEventListener('pagehide',()=>{suspended=true;reconcile();});
 window.addEventListener('pageshow',()=>{suspended=false;reconcile();});
 measure();
})();
