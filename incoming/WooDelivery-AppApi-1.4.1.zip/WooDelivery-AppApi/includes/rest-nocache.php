<?php
/**
 * The plugin's REST answers are never served from a page cache (v1.4.1)
 *
 * The app reads these routes to know what a customer can choose right now: delivery and pickup
 * settings, shipping methods, delivery restrictions, time slots, pickup points with photo and time.
 * LiteSpeed Cache caches REST GETs by URL when its «Cache REST API» setting is on (the plugin's
 * default) and keeps them for the site's REST TTL (7 days by default): on a site with the page
 * cache active, /wdapi/v1/settings, /get-shipping-methods and /delivery-restriction came back with
 * `x-litespeed-cache: hit`, so a change in the delivery settings could reach the app days later.
 *
 * Done in one place for every route of the plugin (same approach as mobile-admin 2.23.2):
 * - before the route runs, LiteSpeed Cache is told through its own control hook that the request
 *   is not cacheable (the only signal it listens to); without LiteSpeed Cache the hook does nothing;
 * - the standard no-cache headers are sent for any other cache in front of the site. They are sent
 *   here, before the callback, because settings and delivery-restriction end the request with
 *   wp_send_json() and never reach rest_post_dispatch; for the other routes they are also set on
 *   the response.
 */

defined('ABSPATH') || exit;

/**
 * True when the REST route belongs to this plugin: the wdapi/v1 namespace, plus the pickup points
 * route of WooCustomCheckoutFieldsAPI that this plugin completes with photo and time.
 *
 * @param string $route Route as WP_REST_Request::get_route() gives it, e.g. "/wdapi/v1/settings".
 */
function wdaapi_rest_is_own_route($route)
{
    // WordPress matches REST routes case-insensitively (/wp-json/WDAPI/v1/settings runs the same
    // callback), so the comparison is done in lower case.
    $route = strtolower('/' . ltrim((string) $route, '/'));
    if ('/wdapi/v1' === $route || 0 === strpos($route, '/wdapi/v1/')) {
        return true;
    }
    return 1 === preg_match('#^/getpickuplocations/alllocations/?$#', $route);
}

/**
 * Whether this request's answer must stay out of every page cache.
 *
 * Filter `wdaapi_rest_nocache` (bool $nocache, string $route, WP_REST_Request $request): return
 * false to let a cache keep one of the plugin's routes on a site that really needs it.
 */
function wdaapi_rest_must_not_cache($request)
{
    // Only when the browser/app asked for the REST route itself. A page that runs one of these
    // routes internally (rest_do_request) must keep its own cache rules.
    if (!(defined('REST_REQUEST') && REST_REQUEST) || !$request instanceof WP_REST_Request) {
        return false;
    }
    $route = $request->get_route();
    if (!wdaapi_rest_is_own_route($route)) {
        return false;
    }
    return (bool) apply_filters('wdaapi_rest_nocache', true, $route, $request);
}

/**
 * Tell the page-cache plugins that this request must not be cached.
 *
 * - litespeed_control_set_nocache: LiteSpeed Cache's own control hook (a no-op without that plugin).
 * - set_nocache_hard (LiteSpeed Cache 7.9.2+): the plain flag loses against a «Force Cache URIs» /
 *   «Force Public Cache URIs» rule that happens to match /wp-json/; the hard flag does not.
 * - DONOTCACHEPAGE: the same message for older LiteSpeed Cache versions and other cache plugins.
 *   It is only ever defined on a direct REST request to one of the plugin's own routes.
 */
function wdaapi_rest_tell_caches_nocache()
{
    $reason = 'WooDelivery App API REST: the app needs fresh data';
    do_action('litespeed_control_set_nocache', $reason);
    if (is_callable(['\\LiteSpeed\\Control', 'set_nocache_hard'])) {
        \LiteSpeed\Control::set_nocache_hard($reason);
    }
    if (!defined('DONOTCACHEPAGE')) {
        define('DONOTCACHEPAGE', true);
    }
}

/** Before the route runs: tell the cache plugins and send the no-cache headers. */
add_filter('rest_pre_dispatch', function ($result, $server, $request) {
    if (wdaapi_rest_must_not_cache($request)) {
        wdaapi_rest_tell_caches_nocache();
        if (!headers_sent()) {
            header('Cache-Control: no-cache, no-store, must-revalidate, max-age=0');
            header('X-LiteSpeed-Cache-Control: no-cache');
        }
    }
    return $result;
}, 1, 3);

/** On the way out (routes that return a response instead of ending the request). */
add_filter('rest_post_dispatch', function ($response, $server, $request) {
    if ($response instanceof WP_HTTP_Response && wdaapi_rest_must_not_cache($request)) {
        // Again here: when REST authentication fails (e.g. a wrong X-WP-Nonce) WordPress answers 403
        // without dispatching, so rest_pre_dispatch never ran and that 403 could be cached.
        wdaapi_rest_tell_caches_nocache();
        $response->header('Cache-Control', 'no-cache, no-store, must-revalidate, max-age=0');
        $response->header('X-LiteSpeed-Cache-Control', 'no-cache');
    }
    return $response;
}, 99, 3);
