<?php
/** A small native editor for the parent's configurable Team records. */
defined('ABSPATH') || exit;
add_filter('register_post_type_args',static function($args,$type){
 if('collaboratori'!==$type)return $args;
 $args['public']=false;$args['publicly_queryable']=false;$args['exclude_from_search']=true;$args['show_in_rest']=false;$args['rewrite']=false;$args['query_var']=false;$args['has_archive']=false;
 $args['show_in_menu']='ticinoweb-cms';$args['supports']=['title','thumbnail','page-attributes'];
 $args['labels']=array_merge($args['labels'],['name'=>__('Team','autonec-child-theme'),'singular_name'=>__('Collaboratore','autonec-child-theme'),'add_new_item'=>__('Aggiungi collaboratore','autonec-child-theme'),'edit_item'=>__('Modifica collaboratore','autonec-child-theme'),'all_items'=>__('Team','autonec-child-theme')]);
 return $args;
},20,2);
add_filter('use_block_editor_for_post_type',static fn($enabled,$type)=>'collaboratori'===$type?false:$enabled,20,2);
add_action('add_meta_boxes',static function($type){if('collaboratori'!==$type)return;remove_meta_box('postcustom',$type,'normal');add_meta_box('an-team-data',__('Ruolo e recapiti','autonec-child-theme'),'autonec_team_editor_box',$type,'normal','high');},100);
function autonec_team_editor_box($post){$data=autonec_team_data($post->ID);wp_nonce_field('an_team_save','an_team_nonce');?>
 <p><?php esc_html_e('Foto dal riquadro Immagine in evidenza. Pubblica per mostrare il collaboratore nel Chi siamo e nel footer; usa Bozza per nasconderlo. Il campo Ordine stabilisce la posizione.','autonec-child-theme');?></p>
 <table class="form-table"><tbody>
 <tr><th><label for="an-team-role"><?php esc_html_e('Ruolo','autonec-child-theme');?></label></th><td><input class="large-text" id="an-team-role" name="an_team[role]" value="<?php echo esc_attr($data['role']);?>"></td></tr>
 <tr><th><label for="an-team-email"><?php esc_html_e('Email professionale','autonec-child-theme');?></label></th><td><input type="email" class="large-text" id="an-team-email" name="an_team[email]" value="<?php echo esc_attr($data['email']);?>"></td></tr>
 <tr><th><label for="an-team-source"><?php esc_html_e('Recapito telefonico','autonec-child-theme');?></label></th><td><select id="an-team-source" name="an_team[phone_source]">
 <?php foreach(['direct'=>__('Numero personale qui sotto','autonec-child-theme'),'sales'=>__('Ufficio vendite — dal CMS Contatti','autonec-child-theme'),'workshop'=>__('Officina — dal CMS Contatti','autonec-child-theme')] as $key=>$label):?><option value="<?php echo esc_attr($key);?>" <?php selected($data['phone_source'],$key);?>><?php echo esc_html($label);?></option><?php endforeach;?></select>
 <p class="description"><?php esc_html_e('Ufficio vendite usa Telefono; Officina usa Telefono fisso del CMS Contatti. Modificali una volta sola: cambiano anche nel footer.','autonec-child-theme');?></p></td></tr>
 <tr><th><label for="an-team-phone"><?php esc_html_e('Numero personale','autonec-child-theme');?></label></th><td><input type="tel" class="regular-text" id="an-team-phone" name="an_team[phone]" value="<?php echo esc_attr($data['phone']);?>"><p class="description"><?php esc_html_e('Usato solo se scegli Numero personale. I campi facoltativi vuoti non compaiono nel sito.','autonec-child-theme');?></p></td></tr>
 </tbody></table><?php
}
function autonec_team_save($id){
 if(wp_is_post_revision($id)||wp_is_post_autosave($id)||!current_user_can('edit_post',$id)||!isset($_POST['an_team_nonce'])||!is_string($_POST['an_team_nonce'])||!wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['an_team_nonce'])),'an_team_save')||!isset($_POST['an_team']))return;
 $data=autonec_team_sanitize(wp_unslash($_POST['an_team']));
 if(is_wp_error($data)){set_transient('an_team_error_'.get_current_user_id(),$data->get_error_message(),60);return;}
 update_post_meta($id,'_an_team',$data);
}
add_action('save_post_collaboratori','autonec_team_save');
add_action('admin_notices',static function(){$screen=get_current_screen();if(!$screen||$screen->post_type!=='collaboratori')return;$key='an_team_error_'.get_current_user_id();$error=get_transient($key);if($error){delete_transient($key);printf('<div class="notice notice-error"><p>%s</p></div>',esc_html($error));}});
add_filter('manage_collaboratori_posts_columns',static fn($columns)=>['cb'=>$columns['cb'],'title'=>__('Collaboratore','autonec-child-theme'),'an_team_role'=>__('Ruolo','autonec-child-theme'),'an_team_contact'=>__('Recapiti','autonec-child-theme'),'an_team_order'=>__('Ordine','autonec-child-theme'),'date'=>$columns['date']]);
add_action('manage_collaboratori_posts_custom_column',static function($column,$id){$data=autonec_team_data($id);if('an_team_role'===$column)echo esc_html($data['role']);if('an_team_order'===$column)echo (int)get_post_field('menu_order',$id);if('an_team_contact'===$column){echo esc_html(autonec_team_phone($data));if($data['email'])echo '<br>'.esc_html($data['email']);}},10,2);
add_action('pre_get_posts',static function($query){if(is_admin()&&$query->is_main_query()&&$query->get('post_type')==='collaboratori'&&!$query->get('orderby'))$query->set('orderby',['menu_order'=>'ASC','title'=>'ASC']);});
add_filter('ticinoweb_chi_siamo_managed_notice',static function($notice){if(!current_user_can('edit_posts'))return $notice;return $notice.' '.sprintf(__('Foto, ruoli e recapiti delle persone si aggiornano in %s.','autonec-child-theme'),'<a href="'.esc_url(admin_url('edit.php?post_type=collaboratori')).'">'.esc_html__('Team','autonec-child-theme').'</a>');},30);
add_action('admin_notices',static function(){
 $screen=get_current_screen();if(!$screen||$screen->post_type!=='collaboratori')return;
 printf('<div class="notice notice-info"><p>%s</p></div>',sprintf(esc_html__('I recapiti del team alimentano anche il footer. I numeri di ufficio e officina e le email aziendali si modificano in %s.','autonec-child-theme'),'<a href="'.esc_url(admin_url('admin.php?page=ticinoweb-cms#contatti')).'">'.esc_html__('CMS → Contatti','autonec-child-theme').'</a>'));
});
