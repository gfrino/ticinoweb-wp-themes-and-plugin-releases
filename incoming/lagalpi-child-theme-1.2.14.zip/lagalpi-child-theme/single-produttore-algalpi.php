<?php
/**
 * Single template for Produttore Algalpi CPT
 *
 * @package lagalpi-child
 */

get_header();
?>

<div class="lagalpi-container lagalpi-single-producer">
    <div class="producer-layout">
        <!-- Left Sidebar: Share Buttons -->
        <aside class="producer-sidebar">
            <h4 class="share-title"><?php esc_html_e( 'Condividi :', 'lagalpi-child' ); ?></h4>
            <div class="share-buttons">
                <?php
                $current_url = urlencode( get_permalink() );
                $current_title = urlencode( get_the_title() );
                ?>
                <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo $current_url; ?>" target="_blank" class="share-btn facebook"><i class="fab fa-facebook-f"></i></a>
                <a href="https://twitter.com/intent/tweet?url=<?php echo $current_url; ?>&text=<?php echo $current_title; ?>" target="_blank" class="share-btn twitter"><i class="fab fa-twitter"></i></a>
                <a href="https://www.linkedin.com/shareArticle?mini=true&url=<?php echo $current_url; ?>&title=<?php echo $current_title; ?>" target="_blank" class="share-btn linkedin"><i class="fab fa-linkedin-in"></i></a>
                <a href="https://t.me/share/url?url=<?php echo $current_url; ?>&text=<?php echo $current_title; ?>" target="_blank" class="share-btn telegram"><i class="fab fa-telegram-plane"></i></a>
            </div>
        </aside>

        <!-- Right Content Area -->
        <main class="producer-main-content">
            <?php while ( have_posts() ) : the_post(); ?>
                
                <?php if ( has_post_thumbnail() ) : ?>
                    <div class="producer-featured-image">
                        <?php the_post_thumbnail( 'full' ); ?>
                    </div>
                <?php endif; ?>

                <h1 class="producer-title"><?php the_title(); ?></h1>

                <div class="producer-description">
                    <?php the_content(); ?>
                </div>

                <?php
                // Link to WooCommerce products for this producer
                // Assuming the pa_produttore term slug matches the CPT post slug
                $term = get_term_by( 'slug', $post->post_name, 'pa_produttore' );
                if ( $term && ! is_wp_error( $term ) ) {
                    $shop_link = get_term_link( $term );
                } else {
                    // Fallback to shop if term not found
                    $shop_link = wc_get_page_permalink( 'shop' );
                }
                ?>
                
                <div class="producer-cta">
                    <p class="cta-text font-semibold"><?php esc_html_e( 'Ordina ora :', 'lagalpi-child' ); ?></p>
                    <a href="<?php echo esc_url( $shop_link ); ?>" class="btn-producer-cta"><?php esc_html_e( 'SCOPRI I PRODOTTI', 'lagalpi-child' ); ?></a>
                </div>

            <?php endwhile; ?>
        </main>
    </div>
</div>

<?php get_footer(); ?>
