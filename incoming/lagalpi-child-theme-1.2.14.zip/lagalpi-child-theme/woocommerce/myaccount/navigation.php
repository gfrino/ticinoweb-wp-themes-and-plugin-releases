<?php
/**
 * My Account navigation (theme override of woocommerce/templates/myaccount/navigation.php).
 *
 * Only change from the WooCommerce default: the "Log out" item gets a real
 * <i> icon after its label. WooCommerce's own template runs the label
 * through esc_html(), so a CSS ::before-only approach can't be relied on to
 * inject it consistently — an actual icon element (same fa-solid convention
 * used everywhere else in this theme) is added here for just that one item.
 *
 * @package lagalpi-child
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

do_action( 'woocommerce_before_account_navigation' );
?>

<nav class="woocommerce-MyAccount-navigation" aria-label="<?php esc_html_e( 'Account pages', 'woocommerce' ); ?>">
    <ul>
        <?php foreach ( wc_get_account_menu_items() as $endpoint => $label ) : ?>
            <li class="<?php echo wc_get_account_menu_item_classes( $endpoint ); ?>">
                <a href="<?php echo esc_url( wc_get_account_endpoint_url( $endpoint ) ); ?>" <?php echo wc_is_current_account_menu_item( $endpoint ) ? 'aria-current="page"' : ''; ?>>
                    <?php echo esc_html( $label ); ?>
                    <?php if ( 'customer-logout' === $endpoint ) : ?>
                        <i class="fa-solid fa-arrow-right-from-bracket lagalpi-logout-icon" aria-hidden="true"></i>
                    <?php endif; ?>
                </a>
            </li>
        <?php endforeach; ?>
    </ul>
</nav>

<?php do_action( 'woocommerce_after_account_navigation' ); ?>
