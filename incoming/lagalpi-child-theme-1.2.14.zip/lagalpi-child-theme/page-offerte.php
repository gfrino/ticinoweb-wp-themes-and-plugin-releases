<?php
/**
 * Template Name: Offerte
 *
 * @package lagalpi-child
 */

get_header();

// Get the featured image for the banner, fallback to a placeholder if not set
$hero_img = get_the_post_thumbnail_url( get_the_ID(), 'full' );
if ( ! $hero_img ) {
    $hero_img = esc_url( lagalpi_uploads_url( '2023/06/Produttore-scaled.jpg' ) );
}
?>



<section class="offerte-hero" style="background-image: url('<?php echo $hero_img; ?>');">
    <div class="offerte-hero-overlay"></div>
    <h1><?php esc_html_e( 'Offerte', 'lagalpi-child' ); ?></h1>
</section>

<section class="offerte-grid-section">
    <div class="lagalpi-container">
        <?php
        $sale_ids = wc_get_product_ids_on_sale();
        
        if ( ! empty( $sale_ids ) ) {
            $args = array(
                'post_type'      => 'product',
                'posts_per_page' => -1,
                'post__in'       => $sale_ids,
                'post_status'    => 'publish',
            );
            $sale_query = new WP_Query( $args );

            if ( $sale_query->have_posts() ) {
                echo '<div class="offerte-grid">';
                while ( $sale_query->have_posts() ) {
                    $sale_query->the_post();
                    global $product;
                    if ( empty( $product ) ) {
                        $product = wc_get_product( get_the_ID() );
                    }
                    ?>
                    <div class="offerte-card">
                        <div class="offerte-card-image">
                            <a href="<?php the_permalink(); ?>">
                                <?php echo $product->get_image( 'woocommerce_thumbnail' ); ?>
                            </a>
                            <span class="offerte-badge"><?php esc_html_e( 'In offerta!', 'lagalpi-child' ); ?></span>
                        </div>
                        <div class="offerte-card-info">
                            <h3 class="offerte-product-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                            <div class="offerte-product-price">
                                <?php echo $product->get_price_html(); ?>
                            </div>
                            <?php
                            $add_to_cart_url = $product->add_to_cart_url();
                            $button_text     = $product->add_to_cart_text();
                            
                            // For simple products we usually say ACQUISTA, but we use what WC provides or hardcode
                            $text = ( $product->is_type( 'simple' ) ) ? __( 'ACQUISTA', 'lagalpi-child' ) : $button_text;
                            ?>
                            <a href="<?php echo esc_url( $add_to_cart_url ); ?>" data-product_id="<?php echo esc_attr( $product->get_id() ); ?>" class="btn-acquista ajax_add_to_cart">
                                <?php echo esc_html( $text ); ?>
                            </a>
                        </div>
                    </div>
                    <?php
                }
                echo '</div>';
                wp_reset_postdata();
            }
        } else {
            echo '<p>' . esc_html__( 'Al momento non ci sono prodotti in offerta.', 'lagalpi-child' ) . '</p>';
        }
        ?>
    </div>
</section>

<?php get_footer(); ?>
