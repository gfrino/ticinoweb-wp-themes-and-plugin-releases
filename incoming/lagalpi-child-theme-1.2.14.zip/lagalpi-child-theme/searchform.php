<?php
/**
 * Custom search form template for lagAlpi child theme.
 * Displays a modern search form with a search icon button.
 *
 * @package lagalpi-child
 */
?>
<form role="search" method="get" class="lagalpi-search-form" action="<?php echo esc_url( home_url( '/' ) ); ?>">
    <input type="search" class="lagalpi-search-field" placeholder="<?php echo esc_attr_x( 'Cerca...', 'placeholder', 'lagalpi-child' ); ?>" value="<?php echo get_search_query(); ?>" name="s" required />
    <button type="submit" class="lagalpi-search-submit" aria-label="<?php echo esc_attr_x( 'Cerca', 'submit button', 'lagalpi-child' ); ?>">
        <i class="fas fa-search"></i>
    </button>
</form>
