<?php
/**
 * Weekly automatic refresh of the Google reviews.
 *
 * The homepage shows a cached copy of the reviews (pulled from the Google
 * Places API by the parent theme's ticinoweb_pull_google_reviews()). This
 * schedules a WP-Cron event that re-pulls them once a week so new reviews and
 * updated ratings appear without anyone pressing the manual "Sync" button.
 *
 * The schedule travels with the theme: it self-registers on load and is cleared
 * when the theme is switched away.
 *
 * @package lagalpi-child
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

const LAGALPI_REVIEWS_CRON_HOOK = 'lagalpi_weekly_reviews_sync';

/**
 * Ensure a "weekly" cron interval exists (older WordPress cores lack it).
 */
function lagalpi_reviews_cron_schedules( $schedules ) {
    if ( ! isset( $schedules['weekly'] ) ) {
        $schedules['weekly'] = array(
            'interval' => defined( 'WEEK_IN_SECONDS' ) ? WEEK_IN_SECONDS : 604800,
            'display'  => __( 'Once Weekly', 'lagalpi-child' ),
        );
    }
    return $schedules;
}
add_filter( 'cron_schedules', 'lagalpi_reviews_cron_schedules' );

/**
 * Schedule the weekly event once, if it is not already queued.
 */
function lagalpi_reviews_cron_activate() {
    if ( ! wp_next_scheduled( LAGALPI_REVIEWS_CRON_HOOK ) ) {
        wp_schedule_event( time() + HOUR_IN_SECONDS, 'weekly', LAGALPI_REVIEWS_CRON_HOOK );
    }
}
add_action( 'after_setup_theme', 'lagalpi_reviews_cron_activate' );

/**
 * Clear the scheduled event when this theme is deactivated.
 */
function lagalpi_reviews_cron_deactivate() {
    $timestamp = wp_next_scheduled( LAGALPI_REVIEWS_CRON_HOOK );
    if ( $timestamp ) {
        wp_unschedule_event( $timestamp, LAGALPI_REVIEWS_CRON_HOOK );
    }
}
add_action( 'switch_theme', 'lagalpi_reviews_cron_deactivate' );

/**
 * The actual weekly job: re-pull reviews via the parent theme's function.
 */
function lagalpi_reviews_cron_run() {
    if ( function_exists( 'ticinoweb_pull_google_reviews' ) ) {
        ticinoweb_pull_google_reviews();
    }
}
add_action( LAGALPI_REVIEWS_CRON_HOOK, 'lagalpi_reviews_cron_run' );
