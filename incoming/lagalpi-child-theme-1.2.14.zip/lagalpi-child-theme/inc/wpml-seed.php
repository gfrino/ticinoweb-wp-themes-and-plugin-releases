<?php
/**
 * Seeds the theme's WPML String Translation entries.
 *
 * The translations for the 'lagalpi-child' text domain live in WPML's database
 * tables, NOT in the theme files — so copying the theme folder to another site
 * does not carry them across. This seeder reads the bundled seed data
 * (inc/wpml-translations.php) and registers each source string together with
 * its DE/FR/EN translations into WPML on whichever site the theme runs on, so
 * the translations effectively ship with the theme.
 *
 * It is idempotent and cheap: real work happens only when the seed file's
 * contents change (tracked via a content hash stored in an option). After the
 * first run, a normal request only does one md5_file() + one option read.
 *
 * WPML stays the runtime source of truth: every string remains editable in
 * WPML > String Translation. Editing the source site's translations and
 * regenerating inc/wpml-translations.php changes the hash, which makes the
 * seeder re-run once on the next deploy and push the updated values.
 *
 * @package lagalpi-child
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Register the bundled lagalpi-child strings + translations into WPML if the
 * seed data has changed since the last run.
 */
function lagalpi_seed_wpml_translations() {
    // Requires WPML String Translation's registration API. If WPML ST is not
    // active the theme's runtime translation still works via its own gettext
    // fallback filter, so simply do nothing here.
    if ( ! function_exists( 'icl_register_string' )
        || ! function_exists( 'icl_get_string_id' )
        || ! function_exists( 'icl_add_string_translation' ) ) {
        return;
    }

    $seed_file = get_stylesheet_directory() . '/inc/wpml-translations.php';
    if ( ! file_exists( $seed_file ) ) {
        return;
    }

    // Only (re)seed when the bundled data actually changes.
    $version = md5_file( $seed_file );
    if ( get_option( 'lagalpi_wpml_seed_version' ) === $version ) {
        return;
    }

    $rows = include $seed_file;
    if ( ! is_array( $rows ) ) {
        return;
    }

    $context  = 'lagalpi-child';
    $complete = defined( 'ICL_TM_COMPLETE' ) ? ICL_TM_COMPLETE : 10;

    foreach ( $rows as $row ) {
        if ( empty( $row['src'] ) ) {
            continue;
        }

        $src = $row['src'];
        // The string name MUST be md5( source ) so it matches how WordPress
        // core's __()/_e() calls are looked up by WPML's gettext hook.
        $name = md5( $src );

        icl_register_string( $context, $name, $src );

        $string_id = icl_get_string_id( $src, $context, $name );
        if ( ! $string_id ) {
            continue;
        }

        foreach ( array( 'de', 'fr', 'en' ) as $lang ) {
            if ( ! empty( $row[ $lang ] ) ) {
                icl_add_string_translation( $string_id, $lang, $row[ $lang ], $complete );
            }
        }
    }

    update_option( 'lagalpi_wpml_seed_version', $version );
}
add_action( 'init', 'lagalpi_seed_wpml_translations', 20 );

/**
 * Seed WooCommerce (WCML) admin-text translations — shipping method titles and
 * payment gateway titles shown at checkout.
 *
 * These strings are registered by WooCommerce Multilingual under "admin_texts_*"
 * contexts, and their WPML string NAME embeds a per-site instance id
 * (free_shipping23, local_pickup6, …). So, unlike the theme's own strings, they
 * are matched here by their Italian source VALUE within the context — which is
 * stable across sites — rather than by name. All strings in a context matching
 * that value get the translation (harmless when several instances share a
 * title).
 *
 * Idempotent and self-healing: it re-runs only while the seed data's content
 * hash changes or until every entry has matched at least once (WCML may not
 * have registered the strings yet on a very fresh install), with a bounded
 * retry budget so it never queries indefinitely.
 */
function lagalpi_seed_wpml_wc_translations() {
    global $wpdb;

    if ( ! function_exists( 'icl_add_string_translation' ) ) {
        return;
    }

    $seed_file = get_stylesheet_directory() . '/inc/wpml-wc-translations.php';
    if ( ! file_exists( $seed_file ) ) {
        return;
    }

    $version = md5_file( $seed_file );
    $state   = get_option( 'lagalpi_wpml_wc_seed_state' );

    if ( is_array( $state ) && isset( $state['hash'] ) && $state['hash'] === $version ) {
        // Done, or retry budget exhausted for this data set.
        if ( ! empty( $state['done'] ) || (int) $state['attempts'] >= 20 ) {
            return;
        }
    } else {
        $state = array(
            'hash'     => $version,
            'done'     => false,
            'attempts' => 0,
        );
    }

    $rows = include $seed_file;
    if ( ! is_array( $rows ) ) {
        return;
    }

    $complete    = defined( 'ICL_TM_COMPLETE' ) ? ICL_TM_COMPLETE : 10;
    $strings_tbl = $wpdb->prefix . 'icl_strings';
    $all_found   = true;

    foreach ( $rows as $row ) {
        if ( empty( $row['context'] ) || empty( $row['src'] ) || empty( $row['tr'] ) ) {
            continue;
        }

        $ids = $wpdb->get_col(
            $wpdb->prepare(
                "SELECT id FROM {$strings_tbl} WHERE context = %s AND value = %s",
                $row['context'],
                $row['src']
            )
        );

        if ( empty( $ids ) ) {
            $all_found = false;
            continue;
        }

        foreach ( $ids as $sid ) {
            foreach ( $row['tr'] as $lang => $val ) {
                if ( '' !== $val ) {
                    icl_add_string_translation( (int) $sid, $lang, $val, $complete );
                }
            }
        }
    }

    $state['attempts'] = (int) $state['attempts'] + 1;
    $state['done']     = $all_found;
    update_option( 'lagalpi_wpml_wc_seed_state', $state );
}
add_action( 'init', 'lagalpi_seed_wpml_wc_translations', 21 );
