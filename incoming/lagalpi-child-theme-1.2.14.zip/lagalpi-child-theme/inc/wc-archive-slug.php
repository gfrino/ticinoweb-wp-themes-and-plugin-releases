<?php
/**
 * lagAlpi Child Theme product archive base lock.
 *
 * WooCommerce derives the product post type's has_archive from the URI of the
 * Shop page (class-wc-post-types.php:352). WPML/WCML swap that page for its
 * translation whenever the active language isn't the default one - including
 * get_option( 'woocommerce_shop_page_id' ) itself - so a permalink flush run
 * with the admin in English baked "shop-2" (the EN slug) into the rewrite
 * rules. /shop/ then had no archive rule left, fell through to the verbose
 * page rules and was served as plain page 268: the product loop came back
 * empty and the body lost its "archive" class, which is what every shop
 * layout rule in assets/css/main.css is scoped to.
 *
 * Resolve the Shop page back to its original-language counterpart so the
 * archive base stays identical whichever language triggers the flush. WPML
 * still registers its own per-language variants on top of this.
 *
 * @package lagalpi-child
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Pin the product archive base to the default-language Shop page slug.
 *
 * @param array $args Arguments passed to register_post_type( 'product' ).
 * @return array
 */
function lagalpi_lock_product_archive_base( $args ) {
    // WooCommerce sets has_archive to false when the active theme declares no
    // WooCommerce support; don't resurrect an archive it deliberately dropped.
    if ( empty( $args['has_archive'] ) ) {
        return $args;
    }

    $shop_page_id = (int) wc_get_page_id( 'shop' );
    if ( $shop_page_id <= 0 ) {
        return $args;
    }

    $default_language = apply_filters( 'wpml_default_language', null );
    if ( $default_language ) {
        $original_id = apply_filters( 'wpml_object_id', $shop_page_id, 'page', true, $default_language );
        if ( $original_id ) {
            $shop_page_id = (int) $original_id;
        }
    }

    if ( get_post( $shop_page_id ) ) {
        $args['has_archive'] = urldecode( get_page_uri( $shop_page_id ) );
    }

    return $args;
}
add_filter( 'woocommerce_register_post_type_product', 'lagalpi_lock_product_archive_base' );

/**
 * Self-heal the stored rewrite rules if the product archive base drifts.
 *
 * lagalpi_lock_product_archive_base() guarantees has_archive is always the
 * default-language slug, but the rules already persisted in the database can
 * still be stale - that is exactly the state the site was found in, with the
 * archive registered at "shop-2" while has_archive resolved to "shop", so
 * /shop/ had no archive rule at all and was served as an ordinary page.
 *
 * The rewrite_rules option is autoloaded, so this is an in-memory array key
 * lookup on admin requests only. When it does fire, flush with $hard = false:
 * the rules live in the option, and .htaccess must not be rewritten here.
 */
function lagalpi_heal_product_archive_rules() {
    $product = get_post_type_object( 'product' );
    if ( ! $product || empty( $product->has_archive ) || ! is_string( $product->has_archive ) ) {
        return;
    }

    $rules = get_option( 'rewrite_rules' );
    if ( ! is_array( $rules ) || ! $rules ) {
        return;
    }

    if ( ! isset( $rules[ $product->has_archive . '/?$' ] ) ) {
        flush_rewrite_rules( false );
    }
}
add_action( 'admin_init', 'lagalpi_heal_product_archive_rules', 99 );
