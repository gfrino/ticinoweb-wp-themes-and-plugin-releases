<?php
/**
 * lagAlpi Child Theme helpers
 *
 * @package lagalpi-child
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Get active language code
 */
function lagalpi_get_current_language() {
    if ( ! defined( 'ICL_SITEPRESS_VERSION' ) && function_exists( 'twtr_get_current_language' ) ) {
        return twtr_get_current_language();
    }
    return defined( 'ICL_LANGUAGE_CODE' ) ? ICL_LANGUAGE_CODE : 'it';
}

/**
 * Build a URL into the current site's uploads directory.
 *
 * These images live directly in the uploads folder rather than as
 * registered media library attachments, so they can't be resolved via
 * wp_get_attachment_image_url(). Hardcoding '/wp-content/uploads/sites/13/'
 * (as this theme used to) breaks the moment the site is migrated to a
 * install where it isn't multisite blog ID 13 (a different blog ID, or a
 * single-site install with no /sites/N/ segment at all). wp_upload_dir()
 * always returns the correct base for whatever install/blog is currently
 * running, so building the URL from it keeps this working after a move —
 * as long as the same relative file path exists under the new uploads dir.
 *
 * @param string $relative_path Path relative to the uploads base, e.g. '2023/05/logo.png'.
 * @return string
 */
function lagalpi_uploads_url( $relative_path ) {
    $upload_dir = wp_get_upload_dir();
    return trailingslashit( $upload_dir['baseurl'] ) . ltrim( $relative_path, '/' );
}

/**
 * Force this theme's slug-based custom page templates (page-contatti.php,
 * page-offerte.php, ...) to keep applying on every WPML-translated version
 * of the same page — not just the Italian original.
 *
 * WordPress's normal template hierarchy only auto-selects "page-{slug}.php"
 * when the CURRENT post's slug matches the filename. WPML gives every
 * translation its own localized slug (contatti -> kontakt -> contact), so on
 * German/French/English these templates silently stop matching and the page
 * falls back to the generic page.php template with whatever static content
 * happens to be saved in that translated post — completely bypassing all
 * the dynamic markup/hero images/forms these templates build. Confirmed via
 * direct testing: /kontakt/ (the German Contatti page) was rendering stale,
 * unrelated hardcoded HTML instead of page-contatti.php's actual form.
 *
 * This resolves each translation back to its Italian original via WPML's
 * translation groups (bypassing WPML's language query filter with
 * suppress_filters) and forces the matching template regardless of which
 * language/slug is currently being viewed.
 */
function lagalpi_force_translated_page_templates( $template ) {
    if ( ! is_page() || ! function_exists( 'icl_object_id' ) ) {
        return $template;
    }

    static $slug_to_original_id = array();

    // Italian slug => template file. These must stay in sync with the
    // "Template Name:" files in the theme root.
    $template_map = array(
        'contatti'   => 'page-contatti.php',
        'chi-siamo'  => 'page-chi-siamo.php',
        'offerte'    => 'page-offerte.php',
        'produttori' => 'page-produttori.php',
        'articoli'   => 'page-articoli.php',
    );

    foreach ( $template_map as $it_slug => $file ) {
        if ( ! array_key_exists( $it_slug, $slug_to_original_id ) ) {
            // suppress_filters bypasses WPML's "only this language" query
            // filter, so this still finds the Italian post while browsing
            // any other language.
            $matches = get_posts( array(
                'name'             => $it_slug,
                'post_type'        => 'page',
                'post_status'      => 'publish',
                'numberposts'      => 1,
                'suppress_filters' => true,
            ) );
            $slug_to_original_id[ $it_slug ] = ! empty( $matches ) ? $matches[0]->ID : 0;
        }

        $original_id = $slug_to_original_id[ $it_slug ];
        if ( ! $original_id ) {
            continue;
        }

        $translated_id = icl_object_id( $original_id, 'page', false );
        if ( $translated_id && is_page( $translated_id ) ) {
            $located = locate_template( $file );
            if ( $located ) {
                return $located;
            }
        }
    }

    return $template;
}
add_filter( 'template_include', 'lagalpi_force_translated_page_templates', 99 );

/**
 * Render WPML language switcher
 */
function lagalpi_render_language_switcher() {
    if ( ! defined( 'ICL_SITEPRESS_VERSION' ) && function_exists( 'twtr_language_switcher' ) ) {
        twtr_language_switcher( array( 'style' => 'flags', 'size' => 18, 'order' => 'it,en,de,fr', 'class' => 'lagalpi-lang-switcher' ) );
        return;
    }
    $languages = apply_filters( 'wpml_active_languages', NULL, 'skip_missing=0' );
    if ( ! empty( $languages ) ) {
        echo '<div class="lagalpi-lang-switcher">';
        foreach ( $languages as $l ) {
            $active_class = $l['active'] ? 'active' : '';
            echo '<a href="' . esc_url( $l['url'] ) . '" class="lang-item ' . $active_class . '" title="' . esc_attr( $l['native_name'] ) . '">';
            if ( ! empty( $l['country_flag_url'] ) ) {
                echo '<img src="' . esc_url( $l['country_flag_url'] ) . '" alt="' . esc_attr( $l['language_code'] ) . '" class="lang-flag-img">';
            } else {
                echo esc_html( strtoupper( $l['language_code'] ) );
            }
            echo '</a>';
        }
        echo '</div>';
    }
}

/**
 * Retrieve Mega Menu Data
 */
function lagalpi_get_mega_menu_data() {
    $lang = lagalpi_get_current_language();
    
    // Base URL mapping
    $base_url = home_url( '/' );

    $data = array(
        'it' => array(
            'columns' => array(
                array(
                    'title' => 'Elisir leggendari & Spiriti alpini',
                    'link'  => $base_url . 'elisir-leggendari-spiriti-alpini/',
                    'image' => lagalpi_uploads_url( '2022/11/Discovery-Alpi-SPIRITO-DELLE-ALPI-370x370.jpg' ), // Placeholder fallback or actual URL
                    'items' => array(
                        array( 'text' => 'Birre', 'slug' => 'birra' ),
                        array( 'text' => 'Sidri', 'slug' => 'sidro' ),
                        array( 'text' => 'Distillati', 'slug' => 'distillati' ),
                        array( 'text' => 'Liquori', 'slug' => 'liquori' ),
                        array( 'text' => 'Sciroppi', 'slug' => 'sciroppi' ),
                        array( 'text' => 'Tè', 'slug' => 'the' ),
                    )
                ),
                array(
                    'title' => 'Dalle Alpi in tavola',
                    'link'  => $base_url . 'dalle-alpi-in-tavola/',
                    'image' => lagalpi_uploads_url( '2022/10/in-tavola-370x370.jpg' ),
                    'items' => array(
                        array( 'text' => 'Aceti', 'slug' => 'aceto' ),
                        array( 'text' => 'Antipasti e Sottoli', 'slug' => 'antipasti-e-sottoli' ),
                        array( 'text' => 'Farine', 'slug' => 'farina' ),
                        array( 'text' => 'Mostarde e Salse salate', 'slug' => 'mostarde-e-salse-salate' ),
                        array( 'text' => 'Olii', 'slug' => 'olio-2' ),
                        array( 'text' => 'Senapi', 'slug' => 'senapi' ),
                        array( 'text' => 'Spezie e Condimenti', 'slug' => 'spezie-e-condimenti' ),
                        array( 'text' => 'Sughi e Conserve', 'slug' => 'sughi-e-conserve' ),
                        array( 'text' => 'Legumi', 'slug' => 'legumi' ),
                        array( 'text' => 'Snacks e Chips', 'slug' => 'snacks-e-chips' ),
                        array( 'text' => 'Riso', 'slug' => 'riso' ),
                    )
                ),
                array(
                    'title' => 'Dolci e leccornie di vetta',
                    'link'  => $base_url . 'dolci-e-leccornie-di-vetta/',
                    'image' => lagalpi_uploads_url( '2022/10/dolci-370x370.jpg' ),
                    'items' => array(
                        array( 'text' => 'Cioccolati', 'slug' => 'cioccolato' ),
                        array( 'text' => 'Marmellate e composte', 'slug' => 'marmellate-e-composte' ),
                        array( 'text' => 'Frutte sciroppate', 'slug' => 'frutta-sciroppata' ),
                        array( 'text' => 'Marrons Glacés', 'slug' => 'marron-glaces' ),
                        array( 'text' => 'Miele', 'slug' => 'miele' ),
                    )
                ),

                array(
                    'title' => 'Idee regalo',
                    'link'  => $base_url . 'idee-regalo/cesti-regalo/',
                    'image' => lagalpi_uploads_url( '2022/11/Confezione-regalo-Terzo-piacere3-370x370.jpg' ),
                    'items' => array(
                        array( 'text' => 'Box degustazione', 'slug' => 'box-degustazione' ),
                        array( 'text' => 'Cesti regalo', 'slug' => 'cesti-regalo' ),
                        array( 'text' => 'Libri', 'slug' => 'libri' ),
                    )
                ),
            )
        ),
        'fr' => array(
            'columns' => array(
                array(
                    'title' => 'Elixirs légendaires et spiritueux alpins',
                    'link'  => $base_url . 'elisir-leggendari-spiriti-alpini/',
                    'image' => lagalpi_uploads_url( '2022/11/Discovery-Alpi-SPIRITO-DELLE-ALPI-370x370.jpg' ),
                    'items' => array(
                        array( 'text' => 'Bières', 'slug' => 'birra' ),
                        array( 'text' => 'Cidre', 'slug' => 'sidro' ),
                        array( 'text' => 'Distillats', 'slug' => 'distillati' ),
                        array( 'text' => 'Liqueurs', 'slug' => 'liquori' ),
                        array( 'text' => 'Sirops', 'slug' => 'sciroppi' ),
                        array( 'text' => 'Thé', 'slug' => 'the' ),
                    )
                ),
                array(
                    'title' => 'Des Alpes à la table',
                    'link'  => $base_url . 'dalle-alpi-in-tavola/',
                    'image' => lagalpi_uploads_url( '2022/10/in-tavola-370x370.jpg' ),
                    'items' => array(
                        array( 'text' => 'Vinaigre', 'slug' => 'aceto' ),
                        array( 'text' => 'Entrées et Produits à l’huile', 'slug' => 'antipasti-e-sottoli' ),
                        array( 'text' => 'Farines', 'slug' => 'farina' ),
                        array( 'text' => 'Moutardes et sauces salées', 'slug' => 'mostarde-e-salse-salate' ),
                        array( 'text' => 'Huiles', 'slug' => 'olio-2' ),
                        array( 'text' => 'Moutarde', 'slug' => 'senapi' ),
                        array( 'text' => 'Épices et assaisonnements', 'slug' => 'spezie-e-condimenti' ),
                        array( 'text' => 'Sauces et conserves', 'slug' => 'sughi-e-conserve' ),
                        array( 'text' => 'Légumineuses', 'slug' => 'legumi' ),
                        array( 'text' => 'En-cas et chips', 'slug' => 'snacks-e-chips' ),
                        array( 'text' => 'Riz', 'slug' => 'riso' ),
                    )
                ),
                array(
                    'title' => 'Bonbons et friandises du sommet',
                    'link'  => $base_url . 'dolci-e-leccornie-di-vetta/',
                    'image' => lagalpi_uploads_url( '2022/10/dolci-370x370.jpg' ),
                    'items' => array(
                        array( 'text' => 'Chocolat', 'slug' => 'cioccolato' ),
                        array( 'text' => 'Confitures et compotes', 'slug' => 'marmellate-e-composte' ),
                        array( 'text' => 'Fruits au sirop', 'slug' => 'frutta-sciroppata' ),
                        array( 'text' => 'Marrons Glacés', 'slug' => 'marron-glaces' ),
                        array( 'text' => 'Miel', 'slug' => 'miele' ),
                    )
                ),

                array(
                    'title' => 'Idées de cadeaux',
                    'link'  => $base_url . 'idee-regalo/cesti-regalo/',
                    'image' => lagalpi_uploads_url( '2022/11/Confezione-regalo-Terzo-piacere3-370x370.jpg' ),
                    'items' => array(
                        array( 'text' => 'Boîte de dégustation', 'slug' => 'box-degustazione' ),
                        array( 'text' => 'Paniers cadeaux', 'slug' => 'cesti-regalo' ),
                        array( 'text' => 'Livres', 'slug' => 'libri' ),
                    )
                ),
            )
        ),
        'en' => array(
            'columns' => array(
                array(
                    'title' => 'Legendary Elixirs & Alpine Spirits',
                    'link'  => $base_url . 'elisir-leggendari-spiriti-alpini/',
                    'image' => lagalpi_uploads_url( '2022/11/Discovery-Alpi-SPIRITO-DELLE-ALPI-370x370.jpg' ),
                    'items' => array(
                        array( 'text' => 'Beers', 'slug' => 'birra' ),
                        array( 'text' => 'Cider', 'slug' => 'sidro' ),
                        array( 'text' => 'Distillates', 'slug' => 'distillati' ),
                        array( 'text' => 'Liqueurs', 'slug' => 'liquori' ),
                        array( 'text' => 'Syrups', 'slug' => 'sciroppi' ),
                        array( 'text' => 'Tea', 'slug' => 'the' ),
                    )
                ),
                array(
                    'title' => 'From the Alps to the table',
                    'link'  => $base_url . 'dalle-alpi-in-tavola/',
                    'image' => lagalpi_uploads_url( '2022/10/in-tavola-370x370.jpg' ),
                    'items' => array(
                        array( 'text' => 'Vinegars', 'slug' => 'aceto' ),
                        array( 'text' => 'Appetizers and Oil-preserved products', 'slug' => 'antipasti-e-sottoli' ),
                        array( 'text' => 'Flours', 'slug' => 'farina' ),
                        array( 'text' => 'Chutney and Savory Sauces', 'slug' => 'mostarde-e-salse-salate' ),
                        array( 'text' => 'Oils', 'slug' => 'olio-2' ),
                        array( 'text' => 'Mustards', 'slug' => 'senapi' ),
                        array( 'text' => 'Spices and Seasonings', 'slug' => 'spezie-e-condimenti' ),
                        array( 'text' => 'Sauces and Purees', 'slug' => 'sughi-e-conserve' ),
                        array( 'text' => 'Legumes', 'slug' => 'legumi' ),
                        array( 'text' => 'Snacks and Chips', 'slug' => 'snacks-e-chips' ),
                        array( 'text' => 'Rice', 'slug' => 'riso' ),
                    )
                ),
                array(
                    'title' => 'Summit sweets and delicacies',
                    'link'  => $base_url . 'dolci-e-leccornie-di-vetta/',
                    'image' => lagalpi_uploads_url( '2022/10/dolci-370x370.jpg' ),
                    'items' => array(
                        array( 'text' => 'Chocolate', 'slug' => 'cioccolato' ),
                        array( 'text' => 'Jams and compotes', 'slug' => 'marmellate-e-composte' ),
                        array( 'text' => 'Fruit preserved in syrup', 'slug' => 'frutta-sciroppata' ),
                        array( 'text' => 'Marrons Glacés', 'slug' => 'marron-glaces' ),
                        array( 'text' => 'Honey', 'slug' => 'miele' ),
                    )
                ),

                array(
                    'title' => 'Gift ideas',
                    'link'  => $base_url . 'idee-regalo/cesti-regalo/',
                    'image' => lagalpi_uploads_url( '2022/11/Confezione-regalo-Terzo-piacere3-370x370.jpg' ),
                    'items' => array(
                        array( 'text' => 'Tasting box', 'slug' => 'box-degustazione' ),
                        array( 'text' => 'Gift baskets', 'slug' => 'cesti-regalo' ),
                        array( 'text' => 'Books', 'slug' => 'libri' ),
                    )
                ),
            )
        ),
        'de' => array(
            'columns' => array(
                array(
                    'title' => 'Sagenhafte elixiere & Alpenspirituosen',
                    'link'  => $base_url . 'elisir-leggendari-spiriti-alpini/',
                    'image' => lagalpi_uploads_url( '2022/11/Discovery-Alpi-SPIRITO-DELLE-ALPI-370x370.jpg' ),
                    'items' => array(
                        array( 'text' => 'Biere', 'slug' => 'birra' ),
                        array( 'text' => 'Apfelwein', 'slug' => 'sidro' ),
                        array( 'text' => 'Destillate', 'slug' => 'distillati' ),
                        array( 'text' => 'Liköre', 'slug' => 'liquori' ),
                        array( 'text' => 'Sirupe', 'slug' => 'sciroppi' ),
                        array( 'text' => 'Tee', 'slug' => 'the' ),
                    )
                ),
                array(
                    'title' => 'Von den Alpen auf den Tisch',
                    'link'  => $base_url . 'dalle-alpi-in-tavola/',
                    'image' => lagalpi_uploads_url( '2022/10/in-tavola-370x370.jpg' ),
                    'items' => array(
                        array( 'text' => 'Essig', 'slug' => 'aceto' ),
                        array( 'text' => 'Vorspeisen und Eingelegte Produkte in Öl', 'slug' => 'antipasti-e-sottoli' ),
                        array( 'text' => 'Mehle', 'slug' => 'farina' ),
                        array( 'text' => 'Chutney und pikante Saucen', 'slug' => 'mostarde-e-salse-salate' ),
                        array( 'text' => 'Öle', 'slug' => 'olio-2' ),
                        array( 'text' => 'Senf', 'slug' => 'senapi' ),
                        array( 'text' => 'Gewürze und Würzmittel', 'slug' => 'spezie-e-condimenti' ),
                        array( 'text' => 'Saucen und Konserven', 'slug' => 'sughi-e-conserve' ),
                        array( 'text' => 'Hülsenfrüchte', 'slug' => 'legumi' ),
                        array( 'text' => 'Snacks und Chips', 'slug' => 'snacks-e-chips' ),
                        array( 'text' => 'Reis', 'slug' => 'riso' ),
                    )
                ),
                array(
                    'title' => 'Süssigkeiten und leckereien vom berggipfel',
                    'link'  => $base_url . 'dolci-e-leccornie-di-vetta/',
                    'image' => lagalpi_uploads_url( '2022/10/dolci-370x370.jpg' ),
                    'items' => array(
                        array( 'text' => 'Schokolade', 'slug' => 'cioccolato' ),
                        array( 'text' => 'Marmeladen und Kompott', 'slug' => 'marmellate-e-composte' ),
                        array( 'text' => 'Dosenfrüchte', 'slug' => 'frutta-sciroppata' ),
                        array( 'text' => 'Marrons Glacés', 'slug' => 'marron-glaces' ),
                        array( 'text' => 'Honig', 'slug' => 'miele' ),
                    )
                ),

                array(
                    'title' => 'Geschenkideen',
                    'link'  => $base_url . 'idee-regalo/cesti-regalo/',
                    'image' => lagalpi_uploads_url( '2022/11/Confezione-regalo-Terzo-piacere3-370x370.jpg' ),
                    'items' => array(
                        array( 'text' => 'Verkostungsbox', 'slug' => 'box-degustazione' ),
                        array( 'text' => 'Geschenk-Körbe', 'slug' => 'cesti-regalo' ),
                        array( 'text' => 'Bücher', 'slug' => 'libri' ),
                    )
                ),
            )
        ),
    );

    return isset( $data[$lang] ) ? $data[$lang] : $data['it'];
}

/**
 * Render custom mega menu HTML
 */
function lagalpi_render_mega_menu() {
    $menu_data = lagalpi_get_mega_menu_data();
    $base_url  = home_url( '/' );

    echo '<div class="lagalpi-mega-menu-wrapper">';
    echo '<div class="lagalpi-mega-menu-container">';
    foreach ( $menu_data['columns'] as $col ) {
        echo '<div class="mega-menu-column">';

        // The hardcoded 'link' values above are built as home_url() + 'slug/',
        // but real product_cat archive URLs need the '/product-category/'
        // prefix (and any parent-category segments). Resolve the actual term
        // link by slug so the column heading/image point to a working page,
        // falling back to the raw string only if the term can't be found.
        $col_link      = $col['link'];
        $col_slug_path = trim( str_replace( $base_url, '', $col['link'] ), '/' );
        $col_segments  = explode( '/', $col_slug_path );
        $col_term      = get_term_by( 'slug', end( $col_segments ), 'product_cat' );
        if ( $col_term && ! is_wp_error( $col_term ) ) {
            $resolved_link = get_term_link( $col_term );
            if ( ! is_wp_error( $resolved_link ) ) {
                $col_link = $resolved_link;
            }
        }

        if ( ! empty( $col['image'] ) ) {
            echo '<a href="' . esc_url( $col_link ) . '" class="mega-column-image-link">';
            echo '<img src="' . esc_url( $col['image'] ) . '" alt="' . esc_attr( $col['title'] ) . '" class="mega-column-image">';
            echo '</a>';
        }
        echo '<h4 class="mega-column-title">';
        echo '<a href="' . esc_url( $col_link ) . '">' . esc_html( $col['title'] ) . '</a>';
        echo '</h4>';
        if ( ! empty( $col['items'] ) ) {
            echo '<ul class="mega-column-list">';
            foreach ( $col['items'] as $item ) {
                $item_link = $col_link;

                if ( ! empty( $item['slug'] ) ) {
                    $item_link = $col_link . $item['slug'] . '/'; // fallback
                    $item_term = get_term_by( 'slug', $item['slug'], 'product_cat' );
                    if ( $item_term && ! is_wp_error( $item_term ) ) {
                        $resolved_item_link = get_term_link( $item_term );
                        if ( ! is_wp_error( $resolved_item_link ) ) {
                            $item_link = $resolved_item_link;
                        }
                    }
                }

                echo '<li><a href="' . esc_url( $item_link ) . '">' . esc_html( $item['text'] ) . '</a></li>';
            }
            echo '</ul>';
        }
        echo '</div>';
    }
    echo '</div>';
    echo '</div>';
}

/**
 * Custom Nav Menu Walker to inject Mega Menu on Prodotti item
 */
class Lagalpi_Walker_Nav_Menu extends Walker_Nav_Menu {
    public function start_el( &$output, $item, $depth = 0, $args = null, $id = 0 ) {
        // Detect if this item points to WooCommerce Shop or has the class 'mega-menu-trigger'
        $is_shop = false;
        if ( function_exists( 'wc_get_page_id' ) ) {
            $shop_page_id = wc_get_page_id( 'shop' );
            if ( $shop_page_id > 0 ) {
                $shop_url = get_permalink( $shop_page_id );
                $item_path = wp_make_link_relative( $item->url );
                $shop_path = wp_make_link_relative( $shop_url );
                if ( trim( $item_path, '/' ) === trim( $shop_path, '/' ) ) {
                    $is_shop = true;
                }
            }
        }

        // Add dropdown caret to the shop item
        if ( $is_shop ) {
            $item->title .= ' <i class="fa fa-caret-down"></i>';
            $item->classes[] = 'has-mega-menu';
        }

        // Build standard element
        parent::start_el( $output, $item, $depth, $args, $id );

        if ( ( is_array( $item->classes ) && in_array( 'mega-menu-trigger', $item->classes ) ) || $is_shop ) {
            ob_start();
            lagalpi_render_mega_menu();
            $mega_menu_html = ob_get_clean();
            $output .= $mega_menu_html;
        }
    }
}

