<?php
/**
 * lagAlpi Child Theme AJAX Product Filters handler
 *
 * Handles filtering products asynchronously via WP Query tax and meta options.
 *
 * @package lagalpi-child
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

add_action( 'wp_ajax_lagalpi_filter_products', 'lagalpi_ajax_filter_products' );
add_action( 'wp_ajax_nopriv_lagalpi_filter_products', 'lagalpi_ajax_filter_products' );

function lagalpi_ajax_filter_products() {
    // 1. Security Check
    check_ajax_referer( 'lagalpi_filters_nonce', 'nonce' );

    // 2. Retrieve and Sanitize Parameters
    $paged = isset( $_POST['paged'] ) ? intval( $_POST['paged'] ) : 1;
    $cat = isset( $_POST['filter_cat'] ) ? sanitize_text_field( $_POST['filter_cat'] ) : '';
    
    $colors = isset( $_POST['filter_color'] ) ? array_map( 'sanitize_text_field', (array)$_POST['filter_color'] ) : array();
    $formats = isset( $_POST['filter_format'] ) ? array_map( 'sanitize_text_field', (array)$_POST['filter_format'] ) : array();
    $producers = isset( $_POST['filter_producer'] ) ? array_map( 'sanitize_text_field', (array)$_POST['filter_producer'] ) : array();
    
    $min_price = isset( $_POST['min_price'] ) ? intval( $_POST['min_price'] ) : 0;
    $max_price = isset( $_POST['max_price'] ) ? intval( $_POST['max_price'] ) : 99999;
    
    $orderby = isset( $_POST['orderby'] ) ? sanitize_text_field( $_POST['orderby'] ) : 'menu_order';

    // 3. Build WP_Query Arguments
    $args = array(
        'post_type'      => 'product',
        'post_status'    => 'publish',
        'paged'          => $paged,
        'posts_per_page' => apply_filters( 'loop_shop_per_page', wc_get_default_products_per_row() * wc_get_default_product_rows_per_page() ),
    );

    // Apply Sorting
    switch ( $orderby ) {
        case 'price':
            $args['meta_key'] = '_price';
            $args['orderby']  = 'meta_value_num';
            $args['order']    = 'ASC';
            break;
        case 'price-desc':
            $args['meta_key'] = '_price';
            $args['orderby']  = 'meta_value_num';
            $args['order']    = 'DESC';
            break;
        case 'date':
            $args['orderby']  = 'date';
            $args['order']    = 'DESC';
            break;
        case 'popularity':
            $args['meta_key'] = 'total_sales';
            $args['orderby']  = 'meta_value_num';
            $args['order']    = 'DESC';
            break;
        case 'rating':
            $args['meta_key'] = '_wc_average_rating';
            $args['orderby']  = 'meta_value_num';
            $args['order']    = 'DESC';
            break;
        default:
            $args['orderby']  = 'menu_order';
            $args['order']    = 'ASC';
            break;
    }

    // Tax Query
    $tax_query = array( 'relation' => 'AND' );

    // Category
    if ( ! empty( $cat ) ) {
        $tax_query[] = array(
            'taxonomy' => 'product_cat',
            'field'    => 'slug',
            'terms'    => $cat,
        );
    }

    // Colors
    if ( ! empty( $colors ) ) {
        $tax_query[] = array(
            'taxonomy' => 'pa_colore',
            'field'    => 'slug',
            'terms'    => $colors,
            'operator' => 'IN',
        );
    }

    // Formats
    if ( ! empty( $formats ) ) {
        $tax_query[] = array(
            'taxonomy' => 'pa_formato',
            'field'    => 'slug',
            'terms'    => $formats,
            'operator' => 'IN',
        );
    }

    // Producers
    if ( ! empty( $producers ) ) {
        $tax_query[] = array(
            'taxonomy' => 'pa_produttore',
            'field'    => 'slug',
            'terms'    => $producers,
            'operator' => 'IN',
        );
    }

    if ( count( $tax_query ) > 1 ) {
        $args['tax_query'] = $tax_query;
    }

    // Meta Query (Price Range)
    $args['meta_query'] = array(
        'relation' => 'AND',
        array(
            'key'     => '_price',
            'value'   => array( $min_price, $max_price ),
            'compare' => 'BETWEEN',
            'type'    => 'NUMERIC',
        )
    );

    // 4. Run Query and Capture Output
    $query = new WP_Query( $args );

    ob_start();
    
    if ( $query->have_posts() ) {
        woocommerce_product_loop_start();
        while ( $query->have_posts() ) {
            $query->the_post();
            wc_get_template_part( 'content', 'product' );
        }
        woocommerce_product_loop_end();
    } else {
        echo '<p class="woocommerce-info no-products-found">';
        esc_html_e( 'Nessun prodotto trovato corrispondente alla selezione.', 'lagalpi-child' );
        echo '</p>';
    }

    $products_html = ob_get_clean();

    // Capture pagination markup
    ob_start();
    if ( $query->max_num_pages > 1 ) {
        $shop_url = wc_get_page_permalink( 'shop' );
        if ( get_option( 'permalink_structure' ) ) {
            $base = trailingslashit( $shop_url ) . user_trailingslashit( 'page/%#%', 'paged' );
        } else {
            $base = add_query_arg( 'paged', '%#%', $shop_url );
        }

        echo '<nav class="woocommerce-pagination">';
        echo paginate_links( array(
            'base'      => $base,
            'format'    => '',
            'add_args'  => false,
            'current'   => max( 1, $paged ),
            'total'     => $query->max_num_pages,
            'prev_text' => is_rtl() ? '&rarr;' : '&larr;',
            'next_text' => is_rtl() ? '&larr;' : '&rarr;',
            'type'      => 'list',
            'end_size'  => 3,
            'mid_size'  => 3,
        ) );
        echo '</nav>';
    }
    $pagination_html = ob_get_clean();

    // Prepare response data
    $response = array(
        'html'       => $products_html,
        'pagination' => $pagination_html,
        'count'      => sprintf( _n( 'Mostrato 1 risultato', 'Mostrati %s risultati', $query->found_posts, 'lagalpi-child' ), $query->found_posts ),
        'max_pages'  => $query->max_num_pages,
    );

    wp_reset_postdata();

    wp_send_json_success( $response );
}
