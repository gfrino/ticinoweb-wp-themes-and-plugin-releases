<?php
/**
 * WooCommerce (WCML) admin-text translation seed data.
 *
 * Unlike the theme's own gettext strings (see inc/wpml-translations.php), these
 * are WooCommerce configuration strings — shipping method titles and payment
 * gateway titles — registered by WooCommerce Multilingual under "admin_texts_*"
 * contexts. Their internal WPML string NAME embeds the shipping/gateway
 * instance id (e.g. free_shipping23), which differs from site to site, so they
 * cannot be matched by name across installs.
 *
 * The WooCommerce seeder (lagalpi_seed_wpml_wc_translations() in
 * inc/wpml-seed.php) therefore matches each string by its Italian source VALUE
 * within the given context, so it works regardless of the instance ids on the
 * target site. Matching by value means: if a title is renamed in WooCommerce,
 * regenerate/update this file with the new source text.
 *
 * @package lagalpi-child
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

return array(
    array(
        'context' => 'admin_texts_woocommerce_shipping',
        'src'     => 'Spedizione gratuita',
        'tr'      => array(
            'fr' => 'Livraison gratuite',
            'de' => 'Kostenloser Versand',
            'en' => 'Free shipping',
        ),
    ),
    array(
        'context' => 'admin_texts_woocommerce_shipping',
        'src'     => 'Ritiro a Magazino Manno - Via Cantonale 4, Centro Galleria 3, CH - 6928 Manno',
        'tr'      => array(
            'fr' => 'Retrait chez Magazino Manno - Via Cantonale 4, Centro Galleria 3, CH - 6928 Manno',
            'de' => 'Abholung bei Magazino Manno - Via Cantonale 4, Centro Galleria 3, CH - 6928 Manno',
            'en' => 'Pickup at Magazino Manno - Via Cantonale 4, Centro Galleria 3, CH - 6928 Manno',
        ),
    ),
    array(
        'context' => 'admin_texts_woocommerce_gateways',
        'src'     => 'Carta di credito',
        'tr'      => array(
            'fr' => 'Carte de crédit',
            'de' => 'Kreditkarte',
            'en' => 'Credit card',
        ),
    ),
    array(
        'context' => 'admin_texts_woocommerce_stripe_cc_settings',
        'src'     => 'Carta di credito',
        'tr'      => array(
            'fr' => 'Carte de crédit',
            'de' => 'Kreditkarte',
            'en' => 'Credit card',
        ),
    ),
);
