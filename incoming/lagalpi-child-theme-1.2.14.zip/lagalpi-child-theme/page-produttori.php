<?php
/**
 * Template Name: Produttori
 *
 * @package lagalpi-child
 */

get_header();

$hero_img = esc_url( lagalpi_uploads_url( '2023/06/Produttore-scaled.jpg' ) );
?>



<section class="produttori-hero" style="background-image: url('<?php echo $hero_img; ?>');">
    <div class="hero-overlay"></div>
    <div class="hero-content">
        <h1 class="hero-title"><?php esc_html_e( 'I produttori', 'lagalpi-child' ); ?></h1>
        <p class="hero-subtitle"><?php esc_html_e( 'Direttamente dalle Alpi', 'lagalpi-child' ); ?></p>
    </div>
</section>

<section class="produttori-intro">
    <div class="lagalpi-container">
        <h2 class="intro-title"><?php esc_html_e( 'Esploratori del gusto', 'lagalpi-child' ); ?></h2>
        <p class="intro-text">
            <?php esc_html_e( 'Svizzera, Italia, Francia, Germania, Austria, Slovenia e Liechtenstein non sono più i Paesi che si contendono le Alpi, ma un unico territorio dai sapori unici e genuini, naturali e inconfondibili, arricchito da specificità locali che, messe insieme, creano armonia e piacere.', 'lagalpi-child' ); ?>
        </p>
    </div>
</section>

<section class="produttori-list">
    <div class="lagalpi-container">
        <?php
        // Query the produttore-algalpi Custom Post Type
        $args = array(
            'post_type'      => 'produttore-algalpi',
            'posts_per_page' => -1,
            'post_status'    => 'publish',
            'orderby'        => 'title',
            'order'          => 'ASC'
        );
        $producers_query = new WP_Query( $args );

        if ( $producers_query->have_posts() ) :
            echo '<div class="producers-grid">';
            while ( $producers_query->have_posts() ) : $producers_query->the_post();
                $image_url = get_the_post_thumbnail_url( get_the_ID(), 'large' );
                if ( ! $image_url ) {
                    $image_url = wc_placeholder_img_src();
                }
                ?>
                <a href="<?php the_permalink(); ?>" class="producer-card-simple">
                    <img src="<?php echo esc_url( $image_url ); ?>" alt="<?php the_title_attribute(); ?>">
                    <div class="producer-overlay">
                        <h3><?php the_title(); ?></h3>
                    </div>
                </a>
                <?php
            endwhile;
            wp_reset_postdata();
            echo '</div>';
        endif;
        ?>
    </div>
</section>

<?php get_footer(); ?>
