/**
 * lagAlpi Child Theme AJAX filters script
 *
 * Dispatches async queries for WooCommerce store filters, updates
 * catalog loops, handles sorting, debounces price changes, and syncs history.
 */
(function($) {
    'use strict';

    $(document).ready(function() {
        
        // Selector elements
        var $catalog = $('#content'); // Usually main section wrapper
        var $sidebar = $('.lagalpi-filters-container');
        
        if ($sidebar.length === 0) return; // Exit if no sidebar

        var debounceTimer;

        // Double Price Range Slider Logic
        var $priceMin = $('#price-min');
        var $priceMax = $('#price-max');
        var $priceMinDisplay = $('#price-min-display');
        var $priceMaxDisplay = $('#price-max-display');

        function handlePriceSlider() {
            var minVal = parseInt($priceMin.val());
            var maxVal = parseInt($priceMax.val());

            if (minVal > maxVal) {
                // Prevent crossing
                if (this.id === 'price-min') {
                    $priceMin.val(maxVal);
                    minVal = maxVal;
                } else {
                    $priceMax.val(minVal);
                    maxVal = minVal;
                }
            }

            $priceMinDisplay.text(minVal);
            $priceMaxDisplay.text(maxVal);
        }

        $priceMin.on('input', handlePriceSlider);
        $priceMax.on('input', handlePriceSlider);

        // --- Event Listeners for Filters ---

        // Category link trigger
        $sidebar.on('click', '.filter-cat-trigger', function(e) {
            e.preventDefault();
            $(this).toggleClass('active');
            // Allow only one active category
            $sidebar.find('.filter-cat-trigger').not(this).removeClass('active');
            triggerFilter();
        });

        // Color Swatches buttons
        $sidebar.on('click', '.color-swatch-btn', function(e) {
            e.preventDefault();
            $(this).toggleClass('active');
            triggerFilter();
        });

        // Formato buttons
        $sidebar.on('click', '.format-btn', function(e) {
            e.preventDefault();
            $(this).toggleClass('active');
            triggerFilter();
        });

        // Producer checkboxes
        $sidebar.on('change', '.producer-checkbox', function() {
            triggerFilter();
        });

        // Price range changes (Debounced)
        $sidebar.on('input change', '.price-range-input', function() {
            clearTimeout(debounceTimer);
            debounceTimer = setTimeout(function() {
                triggerFilter();
            }, 350); // 350ms debounce
        });

        // Reset button
        $sidebar.on('click', '.lagalpi-reset-filters-btn', function(e) {
            e.preventDefault();
            
            // Clear inputs
            $sidebar.find('.filter-cat-trigger').removeClass('active');
            $sidebar.find('.color-swatch-btn').removeClass('active');
            $sidebar.find('.format-btn').removeClass('active');
            $sidebar.find('.producer-checkbox').prop('checked', false);
            
            // Reset price range bounds
            var minLimit = $priceMin.attr('min');
            var maxLimit = $priceMax.attr('max');
            $priceMin.val(minLimit);
            $priceMax.val(maxLimit);
            $priceMinDisplay.text(minLimit);
            $priceMaxDisplay.text(maxLimit);

            triggerFilter();
        });

        // Catch woocommerce catalog sorting actions
        $(document).on('change', '.woocommerce-ordering select.orderby', function() {
            triggerFilter();
        });

        // Catch pagination link clicks
        $(document).on('click', '.woocommerce-pagination a', function(e) {
            e.preventDefault();
            
            // Find clicked page number
            var href = $(this).attr('href');
            var paged = 1;
            
            // Parse page number from URL path or query params
            var pageMatch = href.match(/\/page\/([0-9]+)/);
            if (pageMatch) {
                paged = parseInt(pageMatch[1]);
            } else {
                var queryMatch = href.match(/paged=([0-9]+)/);
                if (queryMatch) {
                    paged = parseInt(queryMatch[1]);
                }
            }

            triggerFilter(paged);
        });

        // Mobile Filter Drawer controls
        $('.mobile-menu-trigger').on('click', function() {
            // If filters are collapsible, code toggle logic
        });

        // --- Core AJAX dispatcher ---
        function triggerFilter(pagedNum) {
            var paged = pagedNum || 1;
            
            // 1. Gather all active filter selections
            var activeCat = $sidebar.find('.filter-cat-trigger.active').data('slug') || '';
            
            var activeColors = [];
            $sidebar.find('.color-swatch-btn.active').each(function() {
                activeColors.push($(this).data('slug'));
            });

            var activeFormats = [];
            $sidebar.find('.format-btn.active').each(function() {
                activeFormats.push($(this).data('slug'));
            });

            var activeProducers = [];
            $sidebar.find('.producer-checkbox:checked').each(function() {
                activeProducers.push($(this).val());
            });

            var minPriceVal = $priceMin.val();
            var maxPriceVal = $priceMax.val();

            // Read orderby from WooCommerce order widget if it exists
            var orderby = $('.woocommerce-ordering select.orderby').val() || 'menu_order';

            // 2. Setup loading state overlay
            var $productsList = $('.products');
            if ($productsList.length === 0) {
                $productsList = $('.no-products-found');
            }
            
            $productsList.css('opacity', '0.55');

            // 3. Assemble parameters map
            var data = {
                action: 'lagalpi_filter_products',
                nonce: lagalpi_filters.nonce,
                paged: paged,
                filter_cat: activeCat,
                filter_color: activeColors,
                filter_format: activeFormats,
                filter_producer: activeProducers,
                min_price: minPriceVal,
                max_price: maxPriceVal,
                orderby: orderby
            };

            // 4. Dispatch fetch post query
            $.post(lagalpi_filters.ajax_url, data, function(response) {
                if (response.success) {
                    // Update layout nodes
                    var $resultsWrap = $('.products');
                    
                    if ($resultsWrap.length === 0) {
                        $resultsWrap = $('.no-products-found');
                    }
                    
                    if (response.data.html) {
                        // Replace loop elements
                        $resultsWrap.replaceWith(response.data.html);
                    }

                    // Replace pagination links
                    var $pagination = $('.woocommerce-pagination');
                    if ($pagination.length > 0) {
                        $pagination.replaceWith(response.data.pagination);
                    } else if (response.data.pagination) {
                        // Append if it was absent
                        $('.products').after(response.data.pagination);
                    }

                    // Update count labels
                    var $countLabel = $('.woocommerce-result-count');
                    if ($countLabel.length > 0) {
                        $countLabel.text(response.data.count);
                    }

                    // Reset opacity opacity
                    $('.products').css('opacity', '1');

                    // 5. Update browser history path arguments
                    updateBrowserURL(data);
                }
            }).fail(function() {
                $('.products').css('opacity', '1');
            });
        }

        // Generate query parameters and update URL bar state
        function updateBrowserURL(filtersData) {
            var params = [];
            
            if (filtersData.filter_cat) {
                params.push('filter_cat=' + encodeURIComponent(filtersData.filter_cat));
            }
            if (filtersData.filter_color && filtersData.filter_color.length > 0) {
                params.push('filter_color=' + encodeURIComponent(filtersData.filter_color.join(',')));
            }
            if (filtersData.filter_format && filtersData.filter_format.length > 0) {
                params.push('filter_format=' + encodeURIComponent(filtersData.filter_format.join(',')));
            }
            if (filtersData.filter_producer && filtersData.filter_producer.length > 0) {
                params.push('filter_producer=' + encodeURIComponent(filtersData.filter_producer.join(',')));
            }
            
            // Only add prices if they are different from global defaults
            if (parseInt(filtersData.min_price) > parseInt($priceMin.attr('min'))) {
                params.push('min_price=' + filtersData.min_price);
            }
            if (parseInt(filtersData.max_price) < parseInt($priceMax.attr('max'))) {
                params.push('max_price=' + filtersData.max_price);
            }

            if (filtersData.orderby && filtersData.orderby !== 'menu_order') {
                params.push('orderby=' + encodeURIComponent(filtersData.orderby));
            }
            
            if (filtersData.paged > 1) {
                params.push('paged=' + filtersData.paged);
            }

            var newURL = window.location.pathname;
            if (params.length > 0) {
                newURL += '?' + params.join('&');
            }

            history.pushState(null, '', newURL);
        }

    });

})(jQuery);
