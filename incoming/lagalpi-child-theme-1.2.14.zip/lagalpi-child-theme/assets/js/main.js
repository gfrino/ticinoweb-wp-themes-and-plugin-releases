/**
 * lagAlpi Child Theme JavaScript
 *
 * Manages header search trigger, mobile drawer toggle, and simple animations.
 */
(function($) {
    'use strict';

    $(document).ready(function() {
        
        // 1. Search Modal Toggle
        $('.search-trigger').on('click', function(e) {
            e.preventDefault();
            $('.lagalpi-search-modal').addClass('active');
            $('.lagalpi-search-modal input[type="search"]').focus();
            $('body').css('overflow', 'hidden'); // Lock scroll
        });

        $('.search-modal-close, .lagalpi-search-modal').on('click', function(e) {
            // Close if clicked close button OR overlay background itself
            if (e.target === this || $(e.target).closest('.search-modal-close').length > 0) {
                $('.lagalpi-search-modal').removeClass('active');
                $('body').css('overflow', ''); // Unlock scroll
                clearSearchResults();
            }
        });

        // 1b. Live Product Search (type-ahead preview with image + title + price)
        var $searchField = $('.lagalpi-search-field');
        var $searchResults = $('.lagalpi-search-results');
        var searchTimer = null;
        var searchRequest = null;
        var activeResultIndex = -1;

        function clearSearchResults() {
            $searchResults.removeClass('active has-results').empty();
            activeResultIndex = -1;
        }

        function renderSearchResults(products, term) {
            activeResultIndex = -1;

            if (!products || products.length === 0) {
                $searchResults.html(
                    '<p class="lagalpi-search-no-results">' +
                    'Nessun prodotto trovato per &laquo;' + $('<div>').text(term).html() + '&raquo;' +
                    '</p>'
                ).addClass('active').removeClass('has-results');
                return;
            }

            var $list = $('<div class="lagalpi-search-results-list"></div>');

            products.forEach(function(product) {
                var $item = $(
                    '<a class="lagalpi-search-result-item" href="' + product.permalink + '">' +
                        '<span class="lagalpi-search-result-thumb">' +
                            '<img src="' + product.image + '" alt="" loading="lazy" />' +
                        '</span>' +
                        '<span class="lagalpi-search-result-info">' +
                            '<span class="lagalpi-search-result-title"></span>' +
                            '<span class="lagalpi-search-result-price"></span>' +
                        '</span>' +
                    '</a>'
                );
                $item.find('.lagalpi-search-result-title').text(product.title);
                $item.find('.lagalpi-search-result-price').html(product.price);
                $list.append($item);
            });

            $searchResults.empty().append($list).addClass('active has-results');
        }

        function runLiveSearch(term) {
            if (searchRequest) {
                searchRequest.abort();
            }

            $searchResults.addClass('active').removeClass('has-results')
                .html('<p class="lagalpi-search-loading">Ricerca in corso...</p>');

            searchRequest = $.post(lagalpi_ajax.ajax_url, {
                action: 'lagalpi_live_search',
                nonce: lagalpi_ajax.search_nonce,
                term: term
            }, function(response) {
                if (response.success) {
                    renderSearchResults(response.data, term);
                } else {
                    clearSearchResults();
                }
            });
        }

        if ($searchField.length) {
            $searchField.on('input', function() {
                var term = $(this).val().trim();

                clearTimeout(searchTimer);

                if (term.length < 2) {
                    clearSearchResults();
                    return;
                }

                searchTimer = setTimeout(function() {
                    runLiveSearch(term);
                }, 300);
            });

            // Keyboard navigation through the result list
            $searchField.on('keydown', function(e) {
                var $items = $searchResults.find('.lagalpi-search-result-item');
                if (!$items.length) {
                    return;
                }

                if (e.key === 'ArrowDown') {
                    e.preventDefault();
                    activeResultIndex = Math.min(activeResultIndex + 1, $items.length - 1);
                } else if (e.key === 'ArrowUp') {
                    e.preventDefault();
                    activeResultIndex = Math.max(activeResultIndex - 1, 0);
                } else if (e.key === 'Enter' && activeResultIndex > -1) {
                    e.preventDefault();
                    window.location.href = $items.eq(activeResultIndex).attr('href');
                    return;
                } else {
                    return;
                }

                $items.removeClass('is-active');
                $items.eq(activeResultIndex).addClass('is-active');
            });
        }

        // 2. Mobile Navigation Drawer Toggle
        $('.mobile-menu-trigger').on('click', function(e) {
            e.preventDefault();
            $('.lagalpi-mobile-drawer').addClass('active');
            $('.lagalpi-mobile-drawer-overlay').addClass('active');
            $('body').css('overflow', 'hidden');
        });

        $('.drawer-close, .lagalpi-mobile-drawer-overlay').on('click', function(e) {
            $('.lagalpi-mobile-drawer').removeClass('active');
            $('.lagalpi-mobile-drawer-overlay').removeClass('active');
            $('body').css('overflow', '');
        });

        // Close overlays on Esc key press
        $(document).on('keydown', function(e) {
            if (e.key === 'Escape') {
                $('.lagalpi-search-modal').removeClass('active');
                $('.lagalpi-mobile-drawer').removeClass('active');
                $('.lagalpi-mobile-drawer-overlay').removeClass('active');
                $('body').css('overflow', '');
            }
        });

        // 3. Simple Header Animation on Scroll
        var $header = $('.lagalpi-header');
        var $headerSpacer = $('<div class="lagalpi-header-spacer" aria-hidden="true"></div>');
        var headerOffset = $header.length ? $header.offset().top : 0;

        if ($header.length) {
            $header.after($headerSpacer);
        }

        function updateFixedHeader() {
            var scrollTop = $(window).scrollTop();

            if ($header.length && scrollTop >= headerOffset) {
                $headerSpacer.height($header.outerHeight()).show();
                $header.addClass('header-fixed');
            } else {
                $header.removeClass('header-fixed');
                $headerSpacer.hide().height(0);
            }

            if (scrollTop > 50) {
                $header.addClass('header-scrolled');
            } else {
                $header.removeClass('header-scrolled');
            }
        }

        $(window).on('scroll', updateFixedHeader);
        $(window).on('resize', function() {
            if (!$header.hasClass('header-fixed')) {
                headerOffset = $header.offset().top;
            }
            updateFixedHeader();
        });
        updateFixedHeader();

        // 4. Newsletter Form AJAX Submission
        $('.lagalpi-newsletter-form').on('submit', function(e) {
            e.preventDefault();
            var $form = $(this);
            var $button = $form.find('.newsletter-submit-btn');
            var originalText = $button.text();
            
            $button.prop('disabled', true).text('...');
            
            $.post(lagalpi_ajax.ajax_url, {
                action: 'lagalpi_newsletter_subscribe',
                nonce: lagalpi_ajax.nonce,
                nome: $form.find('input[name="nome"]').val(),
                email: $form.find('input[name="email"]').val()
            }, function(response) {
                if (response.success) {
                    var successMsg = $('<div>').text(lagalpi_ajax.strings.newsletter_success).html();
                    $form.html('<p class="newsletter-success" style="color: #6bb059; font-weight: 500; margin: 10px 0 0 0;">' + successMsg + '</p>');
                } else {
                    alert(response.data || lagalpi_ajax.strings.generic_error);
                    $button.prop('disabled', false).text(originalText);
                }
            });
        });

        // 4b. Shipping Rules Page: International Shipping Request Form
        $('.lagalpi-shipping-contact-form').on('submit', function(e) {
            e.preventDefault();
            var $form = $(this);
            var $button = $form.find('.shipping-contact-submit-btn');
            var $feedback = $form.find('.shipping-contact-feedback');
            var originalText = $button.text();

            $button.prop('disabled', true).text('...');
            $feedback.removeClass('is-error is-success').text('');

            $.post(lagalpi_ajax.ajax_url, {
                action: 'lagalpi_shipping_contact',
                nonce: lagalpi_ajax.shipping_nonce,
                name: $form.find('[name="shipping_contact_name"]').val(),
                email: $form.find('[name="shipping_contact_email"]').val(),
                country: $form.find('[name="shipping_contact_country"]').val(),
                message: $form.find('[name="shipping_contact_message"]').val()
            }, function(response) {
                if (response.success) {
                    $feedback.addClass('is-success').text(lagalpi_ajax.strings.shipping_success);
                    $form[0].reset();
                    $button.prop('disabled', false).text(originalText);
                } else {
                    $feedback.addClass('is-error').text(response.data || lagalpi_ajax.strings.generic_error);
                    $button.prop('disabled', false).text(originalText);
                }
            }).fail(function() {
                $feedback.addClass('is-error').text(lagalpi_ajax.strings.generic_error);
                $button.prop('disabled', false).text(originalText);
            });
        });

        // 5. Mini Cart Drawer Toggle
        $(document).on('click', '#lagalpi-cart-trigger', function(e) {
            e.preventDefault();
            $('#lagalpi-mini-cart-drawer').addClass('active');
            $('body').css('overflow', 'hidden'); // Lock scroll
        });

        $(document).on('click', '.mini-cart-drawer-close, .lagalpi-mini-cart-drawer-overlay', function(e) {
            $('#lagalpi-mini-cart-drawer').removeClass('active');
            $('body').css('overflow', ''); // Unlock scroll
        });

        // Close drawer on ESC key
        $(document).on('keydown', function(e) {
            if (e.key === 'Escape') {
                $('#lagalpi-mini-cart-drawer').removeClass('active');
                $('.lagalpi-filters-container').removeClass('active');
                $('body').css('overflow', '');
            }
        });

        // Automatically open the drawer when a product is added via AJAX
        $(document.body).on('added_to_cart', function() {
            $('#lagalpi-mini-cart-drawer').addClass('active');
            $('body').css('overflow', 'hidden');
        });

        // 5b. Mobile Shop Filters Drawer Toggle
        $(document).on('click', '.lagalpi-mobile-filter-trigger', function(e) {
            e.preventDefault();
            $('.lagalpi-filters-container').addClass('active');
            $('body').css('overflow', 'hidden');
        });

        $(document).on('click', '.close-filters-drawer', function(e) {
            e.preventDefault();
            $('.lagalpi-filters-container').removeClass('active');
            $('body').css('overflow', '');
        });

        // 6. Premium Lightbox Modal for Image Links
        $('.default-article .entry-content a[href$=".jpg"], .default-article .entry-content a[href$=".jpeg"], .default-article .entry-content a[href$=".png"], .default-article .entry-content a[href$=".gif"], .default-article .entry-content a[href$=".webp"]').on('click', function(e) {
            e.preventDefault();
            var imageUrl = $(this).attr('href');
            var imageAlt = $(this).find('img').attr('alt') || lagalpi_ajax.strings.image_alt_fallback;

            var $lightbox = $('#lagalpi-lightbox');
            if ($lightbox.length === 0) {
                $lightbox = $('<div id="lagalpi-lightbox" class="lagalpi-lightbox">' +
                    '<button class="lagalpi-lightbox-close" aria-label="' + lagalpi_ajax.strings.close + '">&times;</button>' +
                    '<div class="lagalpi-lightbox-content">' +
                        '<img src="" alt="" />' +
                    '</div>' +
                '</div>');
                $('body').append($lightbox);
                
                $lightbox.on('click', function(e) {
                    if (e.target === this || $(e.target).hasClass('lagalpi-lightbox-close')) {
                        $lightbox.removeClass('active');
                        $('body').css('overflow', '');
                    }
                });
            }
            
            $lightbox.find('img').attr('src', imageUrl).attr('alt', imageAlt);
            $lightbox.addClass('active');
            $('body').css('overflow', 'hidden');
        });
        
        $(document).on('keydown', function(e) {
            if (e.key === 'Escape') {
                $('#lagalpi-lightbox').removeClass('active');
                $('body').css('overflow', '');
            }
        });
        // 7. Mobile Menu Dropdown Accordion
        $('.lagalpi-mobile-menu .menu-item-has-children').each(function() {
            var $li = $(this);
            // Append a toggle button
            $li.append('<span class="submenu-toggle-btn"><i class="fas fa-chevron-down"></i></span>');
            
            // Toggle submenu on clicking the toggle button
            $li.find('.submenu-toggle-btn').on('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                var $submenu = $li.children('.sub-menu');
                var $icon = $(this).find('i');
                
                $submenu.slideToggle(300);
                $li.toggleClass('submenu-open');
                
                if ($li.hasClass('submenu-open')) {
                    $icon.removeClass('fa-chevron-down').addClass('fa-chevron-up');
                } else {
                    $icon.removeClass('fa-chevron-up').addClass('fa-chevron-down');
                }
            });
        });

        // Google reviews carousel: true infinite loop (always advances in the
        // clicked direction by rotating cards) + a fallback avatar for browsers
        // that block Google's hotlinked profile photos.
        function lagalpiOnce(fn) {
            var called = false;
            return function() {
                if (called) { return; }
                called = true;
                fn();
            };
        }

        $('.lagalpi-reviews-carousel').each(function() {
            var $carousel = $(this);
            var $viewport = $carousel.find('.lagalpi-reviews-viewport');
            var $track = $carousel.find('.lagalpi-reviews-track');
            var $prev = $carousel.find('.lagalpi-reviews-nav.prev');
            var $next = $carousel.find('.lagalpi-reviews-nav.next');
            var GAP = 24;
            var animating = false;

            if (!$track.length) {
                return;
            }

            // Replace a failed Google avatar with a coloured initial badge.
            $track.find('.lagalpi-review-avatar').each(function() {
                var img = this;
                function toFallback() {
                    var initial = (img.getAttribute('data-initial') || (img.getAttribute('alt') || '?').charAt(0)).toUpperCase();
                    $(img).replaceWith('<span class="lagalpi-review-avatar lagalpi-review-avatar--fallback" aria-hidden="true">' + initial + '</span>');
                }
                if (img.complete && img.naturalWidth === 0) {
                    toFallback();
                } else {
                    $(img).on('error', toFallback);
                }
            });

            function visibleCount() {
                return $viewport.width() < 760 ? 1 : 2;
            }
            function cardWidth() {
                var vc = visibleCount();
                return ($viewport.width() - GAP * (vc - 1)) / vc;
            }
            function layout() {
                $track.find('.lagalpi-review-card').css('width', cardWidth() + 'px');
                $track.css({ transition: 'none', transform: 'translateX(0)' });
            }

            layout();
            $(window).on('resize', layout);

            // Nothing to loop if the cards already fit the viewport.
            if ($track.children('.lagalpi-review-card').length <= visibleCount()) {
                $prev.add($next).hide();
                return;
            }

            function slide(dir) {
                if (animating) {
                    return;
                }
                animating = true;
                var dist = cardWidth() + GAP;

                if (dir > 0) {
                    // Forward: slide one card left, then move the first card to the end.
                    var finishNext = lagalpiOnce(function() {
                        $track.css({ transition: 'none', transform: 'translateX(0)' });
                        $track.append($track.children('.lagalpi-review-card').first());
                        void $track[0].offsetHeight; // reflow
                        animating = false;
                    });
                    $track.css({ transition: 'transform .45s ease', transform: 'translateX(' + (-dist) + 'px)' });
                    $track.one('transitionend', finishNext);
                    setTimeout(finishNext, 550);
                } else {
                    // Backward: move the last card to the front, offset, then animate back to 0.
                    $track.prepend($track.children('.lagalpi-review-card').last());
                    $track.css({ transition: 'none', transform: 'translateX(' + (-dist) + 'px)' });
                    void $track[0].offsetHeight; // reflow
                    var finishPrev = lagalpiOnce(function() {
                        $track.css('transition', 'none');
                        animating = false;
                    });
                    $track.css({ transition: 'transform .45s ease', transform: 'translateX(0)' });
                    $track.one('transitionend', finishPrev);
                    setTimeout(finishPrev, 550);
                }
            }

            $next.on('click', function() { slide(1); });
            $prev.on('click', function() { slide(-1); });
        });

    });

})(jQuery);
