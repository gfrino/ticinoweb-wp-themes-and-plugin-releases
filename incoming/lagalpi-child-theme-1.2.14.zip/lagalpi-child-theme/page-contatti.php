<?php
/**
 * Template Name: Contatti
 *
 * @package lagalpi-child
 */

get_header();

// Get the featured image for the banner, fallback to a placeholder
$hero_img = get_the_post_thumbnail_url( get_the_ID(), 'full' );
if ( ! $hero_img ) {
    $hero_img = esc_url( lagalpi_uploads_url( '2023/06/Chi-siamo-scaled.jpg' ) );
}
?>

<section class="contatti-hero" style="background-image: url('<?php echo $hero_img; ?>');">
    <div class="contatti-hero-overlay"></div>
    <div class="contatti-hero-text">
        <h1><?php the_title(); ?></h1>
    </div>
</section>

<div class="lagalpi-container contatti-content">
    
    <div class="contatti-header">
        <h2><?php esc_html_e( 'Ufficio Manno', 'lagalpi-child' ); ?></h2>
    </div>

    <div class="contatti-icons-row">
        <div class="contact-box">
            <div class="contact-icon">
                <!-- SVG Icon for Store/Address -->
                <svg viewBox="0 0 24 24" fill="none" stroke="#6bb059" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path><polyline points="9 22 9 12 15 12 15 22"></polyline></svg>
            </div>
            <h3><?php esc_html_e( 'Indirizzo', 'lagalpi-child' ); ?></h3>
            <p><?php esc_html_e( 'Via Cantonale 4, Centro Galleria 3', 'lagalpi-child' ); ?><br><?php esc_html_e( 'CH - 6928 Manno', 'lagalpi-child' ); ?></p>
        </div>
        
        <div class="contact-box">
            <div class="contact-icon">
                <!-- SVG Icon for Phone -->
                <svg viewBox="0 0 24 24" fill="none" stroke="#d9534f" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path></svg>
            </div>
            <h3><?php esc_html_e( 'Telefono', 'lagalpi-child' ); ?></h3>
            <?php
            $lagalpi_phone      = get_option( 'ticinoweb_contact_phone' ) ?: '+41764173621';
            $lagalpi_phone_disp = get_option( 'ticinoweb_contact_phone_display' ) ?: '+41 76 417 36 21';
            ?>
            <p><a href="tel:<?php echo esc_attr( preg_replace( '/[^0-9+]/', '', $lagalpi_phone ) ); ?>"><?php echo esc_html( $lagalpi_phone_disp ); ?></a></p>
        </div>

        <div class="contact-box">
            <div class="contact-icon">
                <!-- SVG Icon for Email -->
                <svg viewBox="0 0 24 24" fill="none" stroke="#8e44ad" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path><polyline points="22,6 12,13 2,6"></polyline></svg>
            </div>
            <h3><?php esc_html_e( 'Email', 'lagalpi-child' ); ?></h3>
            <p><a href="mailto:info@lagalpi.com">info@lagalpi.com</a></p>
        </div>

        <div class="contact-box">
            <div class="contact-icon">
                <!-- SVG Icon for Clock -->
                <svg viewBox="0 0 24 24" fill="none" stroke="#6bb059" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 16 14"></polyline></svg>
            </div>
            <h3><?php esc_html_e( "Orari d'apertura", 'lagalpi-child' ); ?></h3>
            <p><?php esc_html_e( 'Lun-Ven: 09:00 - 18:00', 'lagalpi-child' ); ?></p>
        </div>
    </div>

    <div class="contatti-map-form-row">
        <div class="contatti-map">
            <!-- Map Embed -->
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2777.6712398517227!2d8.917409215573428!3d46.02705597911181!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4784323c21a1170d%3A0xc3bba5f07a04a377!2sVia%20Cantonale%204%2C%206928%20Manno%2C%20Switzerland!5e0!3m2!1sen!2s!4v1688000000000!5m2!1sen!2s" width="100%" height="450" style="border:0; border-radius: 8px;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
        </div>
        <div class="contatti-form">
            <h2><?php esc_html_e( 'Lasciaci un messaggio', 'lagalpi-child' ); ?></h2>
            <form class="lagalpi-contact-form" action="#" method="post">
                <label for="contact_name"><?php esc_html_e( 'Nome', 'lagalpi-child' ); ?></label>
                <input type="text" id="contact_name" name="contact_name" placeholder="<?php esc_attr_e( 'Nome', 'lagalpi-child' ); ?>" required>

                <label for="contact_email"><?php esc_html_e( 'Email', 'lagalpi-child' ); ?></label>
                <input type="email" id="contact_email" name="contact_email" placeholder="<?php esc_attr_e( 'Email', 'lagalpi-child' ); ?>" required>

                <label for="contact_message"><?php esc_html_e( 'Messaggio', 'lagalpi-child' ); ?></label>
                <textarea id="contact_message" name="contact_message" placeholder="<?php esc_attr_e( 'Messaggio', 'lagalpi-child' ); ?>" rows="5" required></textarea>

                <input type="submit" value="<?php esc_attr_e( 'Invia', 'lagalpi-child' ); ?>">
            </form>
        </div>
    </div>

</div>

<?php get_footer(); ?>
