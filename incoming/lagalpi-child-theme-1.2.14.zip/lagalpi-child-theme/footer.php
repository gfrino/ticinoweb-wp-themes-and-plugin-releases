    </div><!-- #content -->

    <!-- Footer Promo Columns -->
    <section class="footer-promo-bar">
        <div class="lagalpi-container promo-container">
            <div class="promo-item text-center">
                <div class="promo-icon" style="color: #63a967; font-size: 42px; width: 42px; height: 42px;">
                    <span class="dashicons dashicons-star-filled" style="font-size: 42px; width: 42px; height: 42px;"></span>
                </div>
                <div class="promo-text">
                    <h3 class="promo-title font-semibold"><?php esc_html_e( 'Esclusività', 'lagalpi-child' ); ?></h3>
                    <p class="promo-desc font-light" style="max-width: 280px; margin: 0 auto;"><?php esc_html_e( 'Garantiamo originalità e qualità dei nostri prodotti, spesso unici ed esclusivi ma sempre eccezionali.', 'lagalpi-child' ); ?></p>
                </div>
            </div>
            <div class="promo-item text-center">
                <div class="promo-icon" style="color: #996699; font-size: 42px; width: 42px; height: 42px;">
                    <span class="dashicons dashicons-admin-generic" style="font-size: 42px; width: 42px; height: 42px;"></span>
                </div>
                <div class="promo-text">
                    <h3 class="promo-title font-semibold"><?php esc_html_e( 'Tecnologia', 'lagalpi-child' ); ?></h3>
                    <p class="promo-desc font-light" style="max-width: 280px; margin: 0 auto;"><?php esc_html_e( 'Usando il meglio delle tecnologie portiamo a tutti l\'unicità di sapori e prodotti spesso di difficile reperimento, diamo voce e visibilità a piccoli produttori ed a prodotti speciali e poco conosciuti.', 'lagalpi-child' ); ?></p>
                </div>
            </div>
            <div class="promo-item text-center">
                <div class="promo-icon" style="color: #d96c6c; font-size: 42px; width: 42px; height: 42px;">
                    <span class="dashicons dashicons-shield" style="font-size: 42px; width: 42px; height: 42px;"></span>
                </div>
                <div class="promo-text">
                    <h3 class="promo-title font-semibold"><?php esc_html_e( 'Tutela', 'lagalpi-child' ); ?></h3>
                    <p class="promo-desc font-light" style="max-width: 280px; margin: 0 auto;"><?php esc_html_e( 'Supportiamo i produttori creando un circolo virtuoso per tutelare la natura, i processi produttivi e l\'equa commercializzazione di piccole realtà imprenditoriali Alpine.', 'lagalpi-child' ); ?></p>
                </div>
            </div>
        </div>
    </section>

    <!-- Main Footer -->
    <footer class="lagalpi-footer" id="contatti" style="background-image: linear-gradient(rgba(38, 48, 56, 0.9), rgba(38, 48, 56, 0.9)), url('<?php echo esc_url( lagalpi_uploads_url( '2023/05/beautiful-snowcapped-mountains-and-forest-landscape-with-blue-sky-at-the-ski-resort-of-morzine-in-th.jpg' ) ); ?>'); background-size: cover; background-position: center 20%; color: #fff;">
        <div class="lagalpi-container footer-container">
            <!-- Brand Column -->
            <div class="footer-column brand-column">
                <div class="footer-logo-box" style="background-color: rgba(255, 255, 255, 0.45);">
                    <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="footer-logo-link">
                        <img src="<?php echo esc_url( lagalpi_uploads_url( '2023/05/lagalpi-logo.png' ) ); ?>" alt="<?php bloginfo( 'name' ); ?>" class="footer-logo">
                    </a>
                    <p class="brand-desc italic">
                        <?php esc_html_e( 'Il meglio delle alpi alla portata di un clic', 'lagalpi-child' ); ?>
                    </p>
                </div>
            </div>

            <!-- Quick Links Column -->
            <div class="footer-column">
                <h4 class="footer-heading font-semibold"><?php esc_html_e( 'Link veloci', 'lagalpi-child' ); ?></h4>
                <?php
                wp_nav_menu( array(
                    'theme_location' => 'primary',
                    'menu_class'     => 'footer-menu-list font-light',
                    'container'      => false,
                    'fallback_cb'    => false,
                ) );
                ?>
            </div>            <!-- Contact Info Column -->
            <div class="footer-column contact-column">
                <h4 class="footer-heading font-semibold"><?php esc_html_e( 'Contatti', 'lagalpi-child' ); ?></h4>
                <div class="footer-contact-items">
                    <?php
                    // The options may exist as empty strings, so fall back on empty too.
                    $address = get_option( 'ticinoweb_contact_address' ) ?: 'Via Cantonale 4, Centro Galleria 3, 6928 Manno';
                    $phone   = get_option( 'ticinoweb_contact_phone' ) ?: '+41764173621';
                    $phone_disp = get_option( 'ticinoweb_contact_phone_display' ) ?: '+41 76 417 36 21';
                    $email   = get_option( 'ticinoweb_contact_email' ) ?: 'info@lagalpi.com';
                    ?>
                    <div class="contact-item">
                        <div class="contact-icon bg-green">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512" fill="currentColor" width="24" height="24"><path d="M215.7 499.2C267 435 384 279.4 384 192C384 86 298 0 192 0S0 86 0 192c0 87.4 117 243 168.3 307.2c12.3 15.3 35.1 15.3 47.4 0zM192 128a64 64 0 1 1 0 128 64 64 0 1 1 0-128z"/></svg>
                        </div>
                        <div class="contact-text">
                            <strong><?php esc_html_e( 'Ufficio', 'lagalpi-child' ); ?></strong>
                            <span><?php echo esc_html( $address ); ?></span>
                        </div>
                    </div>
                    <div class="contact-item">
                        <div class="contact-icon bg-red">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" fill="currentColor" width="22" height="22"><path d="M164.9 24.6c-7.7-18.6-28-28.5-47.4-23.2l-88 24C12.1 30.2 0 46 0 64C0 311.4 200.6 512 448 512c18 0 33.8-12.1 38.6-29.5l24-88c5.3-19.4-4.6-39.7-23.2-47.4l-96-40c-16.3-6.8-35.2-2.1-46.3 11.6L304.7 368C234.3 334.7 177.3 277.7 144 207.3L193.3 167c13.7-11.2 18.4-30 11.6-46.3l-40-96z"/></svg>
                        </div>
                        <div class="contact-text">
                            <strong><?php esc_html_e( 'Telefono', 'lagalpi-child' ); ?></strong>
                            <a href="tel:<?php echo esc_attr( $phone ); ?>"><?php echo esc_html( $phone_disp ); ?></a>
                        </div>
                    </div>
                    <div class="contact-item">
                        <div class="contact-icon bg-yellow">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" fill="currentColor" width="22" height="22"><path d="M48 64C21.5 64 0 85.5 0 112c0 15.1 7.1 29.3 19.2 38.4L236.8 313.6c11.4 8.5 27 8.5 38.4 0L492.8 150.4c12.1-9.1 19.2-23.3 19.2-38.4c0-26.5-21.5-48-48-48H48zM0 176V384c0 35.3 28.7 64 64 64H448c35.3 0 64-28.7 64-64V176L294.4 339.2c-22.8 17.1-54 17.1-76.8 0L0 176z"/></svg>
                        </div>
                        <div class="contact-text">
                            <strong><?php esc_html_e( 'Email', 'lagalpi-child' ); ?></strong>
                            <a href="mailto:<?php echo esc_attr( $email ); ?>"><?php echo esc_html( $email ); ?></a>
                        </div>
                    </div>
                </div>
                <div class="footer-social-icons">
                    <?php
                    // Dynamic Social Links from CMS Settings
                    $socials = array(
                        'facebook'  => array( 'url' => get_option('ticinoweb_contact_facebook'), 'icon' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 512" fill="currentColor" width="20" height="20"><path d="M80 299.3V512H196V299.3h86.5l18-97.8H196V166.9c0-51.7 20.3-71.5 72.7-71.5c16.3 0 29.4 .4 37 1.2V7.9C291.4 4 256.4 0 236.2 0C129.3 0 80 50.5 80 159.4v42.1H14v97.8H80z"/></svg>', 'label' => 'Facebook' ),
                        'instagram' => array( 'url' => get_option('ticinoweb_contact_instagram'), 'icon' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512" fill="currentColor" width="20" height="20"><path d="M224.1 141c-63.6 0-114.9 51.3-114.9 114.9s51.3 114.9 114.9 114.9S339 319.5 339 255.9 287.7 141 224.1 141zm0 189.6c-41.1 0-74.7-33.5-74.7-74.7s33.5-74.7 74.7-74.7 74.7 33.5 74.7 74.7-33.6 74.7-74.7 74.7zm146.4-194.3c0 14.9-12 26.8-26.8 26.8-14.9 0-26.8-12-26.8-26.8s12-26.8 26.8-26.8 26.8 12.2 26.8 26.8zm76.1 27.2c-1.7-35.9-9.9-67.7-36.2-93.9-26.2-26.2-58-34.4-93.9-36.2-37-2.1-147.9-2.1-184.9 0-35.8 1.7-67.6 9.9-93.9 36.1s-34.4 58-36.2 93.9c-2.1 37-2.1 147.9 0 184.9 1.7 35.9 9.9 67.7 36.2 93.9s58 34.4 93.9 36.2c37 2.1 147.9 2.1 184.9 0 35.9-1.7 67.7-9.9 93.9-36.2 26.2-26.2 34.4-58 36.2-93.9 2.1-37 2.1-147.8 0-184.8zM398.8 388c-7.8 19.6-22.9 34.7-42.6 42.6-29.5 11.7-99.5 9-132.1 9s-102.7 2.6-132.1-9c-19.6-7.8-34.7-22.9-42.6-42.6-11.7-29.5-9-99.5-9-132.1s-2.6-102.7 9-132.1c7.8-19.6 22.9-34.7 42.6-42.6 29.5-11.7 99.5-9 132.1-9s102.7-2.6 132.1 9c19.6 7.8 34.7 22.9 42.6 42.6 11.7 29.5 9 99.5 9 132.1s2.7 102.7-9 132.1z"/></svg>', 'label' => 'Instagram' ),
                        'linkedin'  => array( 'url' => get_option('ticinoweb_contact_linkedin'), 'icon' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512" fill="currentColor" width="20" height="20"><path d="M416 32H31.9C14.3 32 0 46.5 0 64.3v383.4C0 465.5 14.3 480 31.9 480H416c17.6 0 32-14.5 32-32.3V64.3c0-17.8-14.4-32.3-32-32.3zM135.4 416H69V202.2h66.5V416zm-33.2-243c-21.3 0-38.5-17.3-38.5-38.5S80.9 96 102.2 96c21.2 0 38.5 17.3 38.5 38.5 0 21.3-17.2 38.5-38.5 38.5zm282.1 243h-66.4V312c0-24.8-.5-56.7-34.5-56.7-34.5 0-39.9 27-39.9 54.9V416h-66.4V202.2h63.7v29.2h.9c8.9-16.8 30.6-34.5 62.9-34.5 67.2 0 79.7 44.3 79.7 101.9V416z"/></svg>', 'label' => 'LinkedIn' ),
                        'youtube'   => array( 'url' => get_option('ticinoweb_contact_youtube'), 'icon' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 576 512" fill="currentColor" width="20" height="20"><path d="M549.7 124.1c-6.3-23.7-24.8-42.3-48.3-48.6C458.8 64 288 64 288 64S117.2 64 74.6 75.5c-23.5 6.3-42 24.9-48.3 48.6-11.4 42.9-11.4 132.3-11.4 132.3s0 89.4 11.4 132.3c6.3 23.7 24.8 41.5 48.3 47.8C117.2 448 288 448 288 448s170.8 0 213.4-11.5c23.5-6.3 42-24.2 48.3-47.8 11.4-42.9 11.4-132.3 11.4-132.3s0-89.4-11.4-132.3zm-317.5 213.5V175.2l142.7 81.2-142.7 81.2z"/></svg>', 'label' => 'YouTube' ),
                        'x'         => array( 'url' => get_option('ticinoweb_contact_x'), 'icon' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" fill="currentColor" width="20" height="20"><path d="M389.2 48h70.6L305.6 224.2 487 464H345L233.7 318.6 106.5 464H35.8L200.7 275.5 26.8 48H172.4L272.9 180.9 389.2 48zM364.4 421.8h39.1L151.1 88h-42L364.4 421.8z"/></svg>', 'label' => 'X (Twitter)' ),
                        'tiktok'    => array( 'url' => get_option('ticinoweb_contact_tiktok'), 'icon' => '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512" fill="currentColor" width="20" height="20"><path d="M448 209.9a210.1 210.1 0 0 1 -122.8-39.3V349.4A162.6 162.6 0 1 1 185 188.3V278.2a74.6 74.6 0 1 0 52.2 71.2V0l88 0a121.2 121.2 0 0 0 1.9 22.2h0A122.2 122.2 0 0 0 381 102.4a121.4 121.4 0 0 0 67 20.1z"/></svg>', 'label' => 'TikTok' ),
                    );
 
                    foreach ( $socials as $platform => $data ) {
                        if ( ! empty( $data['url'] ) ) {
                            printf(
                                '<a href="%s" target="_blank" rel="noopener" aria-label="%s">%s</a>',
                                esc_url( $data['url'] ),
                                esc_attr( $data['label'] ),
                                $data['icon']
                            );
                        }
                    }
                    ?>
                </div>
            </div>
 
            <!-- Newsletter Column -->
            <div class="footer-column newsletter-column">
                <h4 class="footer-heading font-semibold"><?php esc_html_e( 'Iscriviti alla newsletter', 'lagalpi-child' ); ?></h4>
                <form class="lagalpi-newsletter-form" action="#" method="post">
                    <div class="newsletter-input-group-vertical">
                        <input type="text" class="newsletter-input font-light" name="nome" placeholder="<?php esc_attr_e( 'Nome', 'lagalpi-child' ); ?>" required>
                        <input type="email" class="newsletter-input font-light" name="email" placeholder="<?php esc_attr_e( 'Email', 'lagalpi-child' ); ?>" required>
                        <button type="submit" class="newsletter-submit-btn" aria-label="<?php esc_attr_e( 'Invia', 'lagalpi-child' ); ?>">
                            <?php esc_html_e( 'Invia', 'lagalpi-child' ); ?>
                        </button>
                    </div>
                </form>
            </div>
        </div>
 
        <hr class="footer-divider">
 
        <!-- Footer Bottom Bar -->
        <div class="lagalpi-container footer-bottom" style="display: flex; flex-direction: column; align-items: center; gap: 15px; text-align: center; width: 100%;">
            <div class="footer-policy-links" style="font-size: 13px; font-weight: 300; display: flex; flex-wrap: wrap; justify-content: center; gap: 10px 15px; margin-bottom: 5px;">
                <a href="<?php echo esc_url( lagalpi_get_policy_page_url('info') ); ?>" style="color: #e0e0e0; text-decoration: none; transition: color 0.2s;" onmouseover="this.style.color='#76c3d1'" onmouseout="this.style.color='#e0e0e0'"><?php echo esc_html( lagalpi_get_policy_page_label('info') ); ?></a>
                <span style="color: rgba(255,255,255,0.2);">|</span>
                <a href="<?php echo esc_url( lagalpi_get_policy_page_url('condizioni') ); ?>" style="color: #e0e0e0; text-decoration: none; transition: color 0.2s;" onmouseover="this.style.color='#76c3d1'" onmouseout="this.style.color='#e0e0e0'"><?php echo esc_html( lagalpi_get_policy_page_label('condizioni') ); ?></a>
                <span style="color: rgba(255,255,255,0.2);">|</span>
                <a href="<?php echo esc_url( lagalpi_get_policy_page_url('privacy') ); ?>" style="color: #e0e0e0; text-decoration: none; transition: color 0.2s;" onmouseover="this.style.color='#76c3d1'" onmouseout="this.style.color='#e0e0e0'"><?php echo esc_html( lagalpi_get_policy_page_label('privacy') ); ?></a>
                <span style="color: rgba(255,255,255,0.2);">|</span>
                <a href="<?php echo esc_url( lagalpi_get_policy_page_url('cookie') ); ?>" style="color: #e0e0e0; text-decoration: none; transition: color 0.2s;" onmouseover="this.style.color='#76c3d1'" onmouseout="this.style.color='#e0e0e0'"><?php echo esc_html( lagalpi_get_policy_page_label('cookie') ); ?></a>
            </div>
            <div style="display: flex; justify-content: space-between; align-items: center; width: 100%; flex-wrap: wrap; gap: 15px; border-top: 1px solid rgba(255,255,255,0.08); padding-top: 15px;">
                <div class="footer-copyright font-light" style="margin: 0; font-size: 13px; text-align: left; color: rgba(255,255,255,0.5);">
                    <span>&copy; <?php echo date( 'Y' ); ?> Copyright Lagalpi</span>
                    <span class="copyright-separator">|</span>
                    <a href="<?php echo esc_url( admin_url() ); ?>" style="color: rgba(255,255,255,0.5); text-decoration: none; transition: color 0.2s;" onmouseover="this.style.color='#fff'" onmouseout="this.style.color='rgba(255,255,255,0.5)'"><?php esc_html_e( 'Area Riservata', 'lagalpi-child' ); ?></a>
                    <span class="copyright-separator">|</span>
                    <span>design by <a href="https://ticinoweb.net" target="_blank" rel="noopener" style="color: rgba(255,255,255,0.5); text-decoration: none; transition: color 0.2s;" onmouseover="this.style.color='#fff'" onmouseout="this.style.color='rgba(255,255,255,0.5)'">ticinoWEB</a></span>
                </div>
                <div class="footer-payment-methods" style="margin: 0;">
                    <img src="<?php echo esc_url( lagalpi_uploads_url( '2023/05/pagamenti-300x26-1.png' ) ); ?>" alt="Metodi di pagamento sicuri">
                </div>
            </div>
        </div></div>
    </footer>
</div><!-- #page -->

<?php wp_footer(); ?>
</body>
</html>
