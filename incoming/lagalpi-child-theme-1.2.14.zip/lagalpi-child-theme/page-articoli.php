<?php
/**
 * Template Name: Articoli / Storie
 *
 * @package lagalpi-child
 */

get_header();

// Banner image
$hero_img = get_the_post_thumbnail_url( get_the_ID(), 'full' );
if ( ! $hero_img ) {
    $hero_img = esc_url( lagalpi_uploads_url( '2023/06/storie-scaled.jpg' ) );
}
?>

<section class="storie-hero" style="background-image: url('<?php echo $hero_img; ?>');">
    <div class="storie-hero-overlay"></div>
    <h1><?php esc_html_e( 'Storie', 'lagalpi-child' ); ?></h1>
</section>

<section class="storie-grid-section">
    <div class="lagalpi-container">
        <h2 class="storie-section-title"><?php esc_html_e( 'Storie di cima e di valle', 'lagalpi-child' ); ?></h2>
        
        <?php
        $paged = ( get_query_var( 'paged' ) ) ? get_query_var( 'paged' ) : 1;
        $args = array(
            'post_type'      => 'post',
            'posts_per_page' => 9,
            'post_status'    => 'publish',
            'paged'          => $paged
        );
        $storie_query = new WP_Query( $args );

        if ( $storie_query->have_posts() ) {
            echo '<div class="storie-grid">';
            while ( $storie_query->have_posts() ) {
                $storie_query->the_post();
                
                // Get first category
                $categories = get_the_category();
                $cat_name = ! empty( $categories ) ? $categories[0]->name : '';
                ?>
                <article class="storie-card">
                    <div class="storie-card-image">
                        <a href="<?php the_permalink(); ?>">
                            <?php 
                            if ( has_post_thumbnail() ) {
                                the_post_thumbnail( 'large' );
                            } else {
                                echo '<img src="' . wc_placeholder_img_src() . '" alt="Placeholder">';
                            }
                            ?>
                        </a>
                        <?php if ( $cat_name ) : ?>
                            <span class="storie-category-badge"><?php echo esc_html( $cat_name ); ?></span>
                        <?php endif; ?>
                    </div>
                    
                    <div class="storie-card-content">
                        <h3 class="storie-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                        <div class="storie-excerpt">
                            <?php echo wp_trim_words( get_the_excerpt(), 20, '...' ); ?>
                        </div>
                        <a href="<?php the_permalink(); ?>" class="storie-read-more"><?php esc_html_e( 'LEGGI TUTTO »', 'lagalpi-child' ); ?></a>
                    </div>
                    
                    <div class="storie-card-footer">
                        <span class="storie-date"><?php echo get_the_date(); ?></span>
                    </div>
                </article>
                <?php
            }
            echo '</div>';
            
            // Pagination
            $total_pages = $storie_query->max_num_pages;
            if ($total_pages > 1) {
                $current_page = max(1, get_query_var('paged'));
                echo '<div class="storie-pagination">';
                echo paginate_links(array(
                    'base' => get_pagenum_link(1) . '%_%',
                    'format' => 'page/%#%/',
                    'current' => $current_page,
                    'total' => $total_pages,
                    'prev_text'    => __('« Precedente', 'lagalpi-child'),
                    'next_text'    => __('Successivo »', 'lagalpi-child'),
                ));
                echo '</div>';
            }
            
            wp_reset_postdata();
        } else {
            echo '<p>' . esc_html__( 'Nessuna storia trovata.', 'lagalpi-child' ) . '</p>';
        }
        ?>
    </div>
</section>

<?php get_footer(); ?>
