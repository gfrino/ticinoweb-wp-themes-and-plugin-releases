<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<div id="page" class="site">
    <a class="skip-link screen-reader-text" href="#primary"><?php esc_html_e( 'Skip to content', 'lagalpi-child' ); ?></a>

    <!-- Topbar Header -->
    <div class="lagalpi-topbar">
        <div class="lagalpi-container topbar-container">
            <div class="topbar-contact">
                <?php
                // The options may exist as empty strings, so fall back on empty too.
                $phone = get_option( 'ticinoweb_contact_phone' ) ?: '+41764173621';
                $phone_display = get_option( 'ticinoweb_contact_phone_display' ) ?: '+41 76 417 36 21';
                $email = get_option( 'ticinoweb_contact_email' ) ?: 'info@lagalpi.com';
                $address = get_option( 'ticinoweb_contact_address' ) ?: 'Via Cantonale 4, Manno';
                ?>
                <span class="contact-item font-light">
                    <i class="fas fa-phone-alt"></i>
                    <a href="tel:<?php echo esc_attr( $phone ); ?>"><?php echo esc_html( $phone_display ); ?></a>
                </span>
                <span class="contact-item font-light">
                    <i class="fas fa-envelope-open"></i>
                    <a href="mailto:<?php echo esc_attr( $email ); ?>"><?php echo esc_html( $email ); ?></a>
                </span>
                <span class="contact-item font-light">
                    <i class="fas fa-map-marker-alt"></i>
                    <span><?php echo esc_html( $address ); ?></span>
                </span>
            </div>
            <div class="topbar-right">
                <?php lagalpi_render_language_switcher(); ?>
            </div>
        </div>
    </div>

    <!-- Main Navigation Header -->
    <header class="lagalpi-header">
        <div class="lagalpi-container header-container">
            <!-- Brand Logo -->
            <div class="header-logo">
                <a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
                    <?php 
                    $logo = function_exists( 'ticinoweb_get_site_logo' ) ? ticinoweb_get_site_logo() : '';
                    if ( empty( $logo ) && function_exists( 'get_theme_mod' ) ) {
                        $custom_logo_id = get_theme_mod( 'custom_logo' );
                        if ( $custom_logo_id ) {
                            $logo_image = wp_get_attachment_image_src( $custom_logo_id, 'full' );
                            if ( $logo_image ) {
                                $logo = $logo_image[0];
                            }
                        }
                    }
                    if ( ! empty( $logo ) ) : 
                    ?>
                        <img src="<?php echo esc_url( $logo ); ?>" alt="<?php bloginfo( 'name' ); ?>" class="site-logo">
                    <?php else : ?>
                        <span class="site-title font-semibold"><?php bloginfo( 'name' ); ?></span>
                    <?php endif; ?>
                </a>
            </div>

            <!-- Desktop Menu -->
            <nav class="header-navigation desktop-only">
                <?php
                wp_nav_menu( array(
                    'theme_location' => 'primary',
                    'menu_class'     => 'lagalpi-primary-menu',
                    'container'      => false,
                    'fallback_cb'    => false,
                    'walker'         => new Lagalpi_Walker_Nav_Menu(),
                ) );
                ?>
            </nav>

            <!-- Header Action Icons -->
            <div class="header-actions">
                <!-- Mini-Cart Link -->
                <?php if ( function_exists( 'is_woocommerce' ) ) : ?>
                    <div class="header-cart-wrapper">
                        <a href="<?php echo esc_url( wc_get_cart_url() ); ?>" class="action-btn cart-contents" id="lagalpi-cart-trigger">
                            <span class="cart-total"><?php echo WC()->cart->get_cart_subtotal(); ?></span>
                            <span class="cart-icon-wrapper">
                                <i class="fas fa-shopping-cart"></i>
                                <span class="cart-count"><?php echo esc_html( WC()->cart->get_cart_contents_count() ); ?></span>
                            </span>
                        </a>
                    </div>
                <?php endif; ?>

                <!-- My Account Link -->
                <a href="<?php echo esc_url( get_permalink( get_option( 'woocommerce_myaccount_page_id' ) ) ); ?>" class="action-btn account-link" aria-label="<?php esc_attr_e( 'My Account', 'lagalpi-child' ); ?>">
                    <i class="far fa-user-circle"></i>
                </a>

                <!-- Search Button -->
                <button class="action-btn search-trigger" aria-label="<?php esc_attr_e( 'Search', 'lagalpi-child' ); ?>">
                    <i class="fas fa-search"></i>
                </button>

                <!-- Mobile Navigation Trigger -->
                <button class="action-btn mobile-menu-trigger mobile-only" aria-label="<?php esc_attr_e( 'Toggle menu', 'lagalpi-child' ); ?>">
                    <i class="fas fa-bars"></i>
                </button>
            </div>
        </div>
    </header>

    <!-- Mobile Navigation Drawer -->
    <div class="lagalpi-mobile-drawer-overlay"></div>
    <div class="lagalpi-mobile-drawer">
        <div class="drawer-header">
            <span class="drawer-title"><?php bloginfo( 'name' ); ?></span>
            <button class="drawer-close" aria-label="<?php esc_attr_e( 'Close menu', 'lagalpi-child' ); ?>">
                <i class="fas fa-times"></i>
            </button>
        </div>
        <div class="drawer-content">
            <nav class="mobile-navigation">
                <?php
                wp_nav_menu( array(
                    'theme_location' => 'primary',
                    'menu_class'     => 'lagalpi-mobile-menu',
                    'container'      => false,
                    'fallback_cb'    => false,
                ) );
                ?>
            </nav>
            <div class="drawer-contact-info">
                <p><i class="fas fa-phone-alt"></i> <a href="tel:<?php echo esc_attr( $phone ); ?>"><?php echo esc_html( $phone_display ); ?></a></p>
                <p><i class="fas fa-envelope"></i> <a href="mailto:<?php echo esc_attr( $email ); ?>"><?php echo esc_html( $email ); ?></a></p>
                <p><i class="fas fa-map-marker-alt"></i> <?php echo esc_html( $address ); ?></p>
            </div>
        </div>
    </div>

    <!-- Search Modal Overlay -->
    <div class="lagalpi-search-modal">
        <button class="search-modal-close" aria-label="<?php esc_attr_e( 'Close search', 'lagalpi-child' ); ?>">
            <i class="fas fa-times"></i>
        </button>
        <div class="search-modal-content">
            <?php get_search_form(); ?>
            <div class="lagalpi-search-results" aria-live="polite"></div>
        </div>
    </div>

    <div id="content" class="site-content">
