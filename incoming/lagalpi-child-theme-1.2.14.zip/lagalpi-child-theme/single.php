<?php
/**
 * The template for displaying all single posts
 *
 * @package lagalpi-child
 */

get_header();
?>

<div class="lagalpi-container lagalpi-single-post-new">
    <?php while ( have_posts() ) : the_post(); ?>
        
        <div class="post-layout">
            <!-- Sidebar -->
            <aside class="post-sidebar">
                <div class="sidebar-widget">
                    <h4 class="sidebar-title"><?php esc_html_e( 'Condividi :', 'lagalpi-child' ); ?></h4>
                    <div class="share-buttons">
                        <?php
                        $current_url = urlencode( get_permalink() );
                        $current_title = urlencode( get_the_title() );
                        ?>
                        <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo $current_url; ?>" target="_blank" class="share-btn facebook"><i class="fab fa-facebook-f"></i></a>
                        <a href="https://twitter.com/intent/tweet?url=<?php echo $current_url; ?>&text=<?php echo $current_title; ?>" target="_blank" class="share-btn twitter"><i class="fab fa-twitter"></i></a>
                        <a href="https://www.linkedin.com/shareArticle?mini=true&url=<?php echo $current_url; ?>&title=<?php echo $current_title; ?>" target="_blank" class="share-btn linkedin"><i class="fab fa-linkedin-in"></i></a>
                        <a href="https://t.me/share/url?url=<?php echo $current_url; ?>&text=<?php echo $current_title; ?>" target="_blank" class="share-btn telegram"><i class="fab fa-telegram-plane"></i></a>
                    </div>
                </div>

                <hr class="sidebar-separator">

                <div class="sidebar-widget">
                    <h4 class="sidebar-title"><?php esc_html_e( 'Ordina ora :', 'lagalpi-child' ); ?></h4>
                    <a href="<?php echo esc_url( wc_get_page_permalink( 'shop' ) ); ?>" class="btn-sidebar-shop"><?php esc_html_e( 'VAI ALLO SHOP', 'lagalpi-child' ); ?></a>
                </div>
            </aside>
            
            <!-- Main Content -->
            <main class="post-main-content">
                <h1 class="post-title"><?php the_title(); ?></h1>
                
                <div class="post-content">
                    <?php the_content(); ?>
                </div>
                
                <?php
                if ( comments_open() || get_comments_number() ) :
                    comments_template();
                endif;
                ?>
            </main>
        </div>

    <?php endwhile; ?>
</div>

<?php get_footer(); ?>
