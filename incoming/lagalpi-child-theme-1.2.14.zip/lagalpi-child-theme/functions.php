<?php
/**
 * lagAlpi Child Theme functions
 *
 * All core functionalities are handled by the parent theme ticinoweb-ai-theme.
 * This file enqueues parent and child assets and registers client-specific functions.
 *
 * @package lagalpi-child
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Enqueue parent and child theme stylesheets and scripts.
 */
/**
 * Return a cache-busting version string for a child-theme asset based on its
 * last-modified time. The URL only changes when the file itself changes, so
 * browsers can cache the asset between page loads (unlike time(), which forced
 * a fresh download of every CSS/JS file on every single request).
 *
 * @param string $relative_path Path relative to the child theme root, e.g. 'assets/css/main.css'.
 * @return string|int Version string (filemtime, or theme version as fallback).
 */
function lagalpi_asset_version( $relative_path ) {
    $file = trailingslashit( get_stylesheet_directory() ) . ltrim( $relative_path, '/' );
    if ( file_exists( $file ) ) {
        return filemtime( $file );
    }
    $theme = wp_get_theme();
    return $theme->get( 'Version' ) ? $theme->get( 'Version' ) : '1.0.0';
}

function lagalpi_child_enqueue_assets() {
    // Cache-busting versions are derived per-file from each asset's modification
    // time (see lagalpi_asset_version): assets stay cacheable and only
    // re-download when actually edited.

    // 1. Parent theme stylesheet
    wp_enqueue_style( 'ticinoweb-ai-style', get_template_directory_uri() . '/style.css', array(), '1.0.0' );

    // 2. Google Fonts (Commissioner & DM Sans)
    wp_enqueue_style( 'lagalpi-google-fonts', 'https://fonts.googleapis.com/css2?family=Commissioner:wght@300;400;500;600;700&family=DM+Sans:wght@600&display=swap', array(), null );

    // Enqueue FontAwesome for icons
    wp_enqueue_style( 'font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css', array(), '6.4.2' );
    
    // Enqueue Dashicons for native WordPress icons
    wp_enqueue_style( 'dashicons' );

    // 3. Child theme CSS files
    wp_enqueue_style( 'lagalpi-main-style', get_stylesheet_directory_uri() . '/assets/css/main.css', array( 'ticinoweb-ai-style' ), lagalpi_asset_version( 'assets/css/main.css' ) );

    if ( function_exists( 'is_woocommerce' ) ) {
        wp_enqueue_style( 'lagalpi-woocommerce-style', get_stylesheet_directory_uri() . '/assets/css/woocommerce.css', array( 'lagalpi-main-style' ), lagalpi_asset_version( 'assets/css/woocommerce.css' ) );
        wp_enqueue_style( 'lagalpi-filters-style', get_stylesheet_directory_uri() . '/assets/css/ajax-filters.css', array( 'lagalpi-woocommerce-style' ), lagalpi_asset_version( 'assets/css/ajax-filters.css' ) );

        // The account page hero background-image is computed here (rather than
        // hardcoded in woocommerce.css) so it stays correct via wp_upload_dir()
        // regardless of the install/blog ID this theme ends up running on.
        if ( function_exists( 'is_account_page' ) && is_account_page() ) {
            $account_hero_url = lagalpi_uploads_url( '2023/05/beautiful-snowcapped-mountains-and-forest-landscape-with-blue-sky-at-the-ski-resort-of-morzine-in-th.jpg' );
            wp_add_inline_style(
                'lagalpi-woocommerce-style',
                '.woocommerce-account main.container > article > h1 { background-image: linear-gradient(rgba(20, 28, 22, 0.6), rgba(20, 28, 22, 0.6)), url(' . esc_url( $account_hero_url ) . '); }'
            );
        }
    }

    // 4. Child theme javascript files
    wp_enqueue_script( 'lagalpi-main-js', get_stylesheet_directory_uri() . '/assets/js/main.js', array( 'jquery' ), lagalpi_asset_version( 'assets/js/main.js' ), true );

    // Pass AJAX URL and nonce to Javascript
    wp_localize_script( 'lagalpi-main-js', 'lagalpi_ajax', array(
        'ajax_url'        => admin_url( 'admin-ajax.php' ),
        'nonce'           => wp_create_nonce( 'lagalpi_newsletter_nonce' ),
        'shipping_nonce'  => wp_create_nonce( 'lagalpi_shipping_contact_nonce' ),
        'search_nonce'    => wp_create_nonce( 'lagalpi_live_search_nonce' ),
        // UI copy used by main.js. These are translated here (rather than
        // hardcoded in the JS file) because static .js files can't be
        // intercepted by the gettext filter — WPML/our translation switch
        // has no way to see or translate a string that's never passed
        // through a PHP translation function.
        'strings'         => array(
            'generic_error'      => esc_html__( 'Si è verificato un errore. Riprova più tardi.', 'lagalpi-child' ),
            'shipping_success'   => esc_html__( 'Grazie! Ti risponderemo il prima possibile.', 'lagalpi-child' ),
            'newsletter_success' => esc_html__( 'Grazie per esserti iscritto!', 'lagalpi-child' ),
            'image_alt_fallback' => esc_html__( 'Immagine', 'lagalpi-child' ),
            'close'              => esc_html__( 'Chiudi', 'lagalpi-child' ),
        ),
    ) );

    if ( function_exists( 'is_woocommerce' ) && ( is_shop() || is_product_category() || is_product_taxonomy() ) ) {
        wp_enqueue_script( 'lagalpi-filters-js', get_stylesheet_directory_uri() . '/assets/js/ajax-filters.js', array( 'jquery' ), lagalpi_asset_version( 'assets/js/ajax-filters.js' ), true );
        
        // Pass AJAX URL and translations to Javascript
        wp_localize_script( 'lagalpi-filters-js', 'lagalpi_filters', array(
            'ajax_url' => admin_url( 'admin-ajax.php' ),
            'nonce'    => wp_create_nonce( 'lagalpi_filters_nonce' ),
        ) );
    }
}
add_action( 'wp_enqueue_scripts', 'lagalpi_child_enqueue_assets', 20 );

/**
 * Speed up the external font/icon CDNs by opening their connections early.
 * Purely a network optimisation — does not change which resources load or how
 * the site looks.
 */
function lagalpi_resource_hints( $hints, $relation ) {
    if ( 'preconnect' === $relation ) {
        $hints[] = array(
            'href'        => 'https://fonts.gstatic.com',
            'crossorigin' => 'anonymous',
        );
        $hints[] = 'https://fonts.googleapis.com';
        $hints[] = 'https://cdnjs.cloudflare.com';
    }
    return $hints;
}
add_filter( 'wp_resource_hints', 'lagalpi_resource_hints', 10, 2 );

/**
 * Setup child theme.
 */
function lagalpi_child_setup() {
    add_theme_support( 'title-tag' );
    add_theme_support( 'post-thumbnails' );
}
add_action( 'after_setup_theme', 'lagalpi_child_setup' );

/**
 * Add custom body class.
 */
function lagalpi_child_body_classes( $classes ) {
    $classes[] = 'lagalpi-child-theme';
    return $classes;
}
add_filter( 'body_class', 'lagalpi_child_body_classes' );

// Include helper scripts
require_once get_stylesheet_directory() . '/inc/helpers.php';
require_once get_stylesheet_directory() . '/inc/ajax-filters.php';
require_once get_stylesheet_directory() . '/inc/wpml-seed.php';
require_once get_stylesheet_directory() . '/inc/wc-archive-slug.php';
require_once get_stylesheet_directory() . '/inc/reviews-cron.php';

/**
 * Remove WooCommerce's default breadcrumb (shop/category/single product
 * pages) site-wide, on top of the theme's own breadcrumb markup already
 * removed from header.php, the cart template, and the checkout page.
 */
remove_action( 'woocommerce_before_main_content', 'woocommerce_breadcrumb', 20, 0 );

/**
 * Custom WooCommerce sidebar hook to render filters sidebar
 */
function lagalpi_render_shop_sidebar() {
    if ( is_shop() || is_product_category() || is_product_taxonomy() ) {
        get_template_part( 'template-parts/woocommerce/filters-sidebar' );
    }
}
remove_action( 'woocommerce_sidebar', 'woocommerce_get_sidebar', 10 );
add_action( 'woocommerce_sidebar', 'lagalpi_render_shop_sidebar', 10 );

/**
 * Mobile trigger button that opens the filters sidebar as an off-canvas
 * drawer. The sidebar/drawer markup itself (including the close button)
 * already existed in filters-sidebar.php; below ~992px it just had no way
 * to be opened, so the filters were effectively unreachable without
 * scrolling past the entire product grid first.
 */
function lagalpi_render_mobile_filter_trigger() {
    if ( is_shop() || is_product_category() || is_product_taxonomy() ) {
        ?>
        <button type="button" class="lagalpi-mobile-filter-trigger">
            <i class="fa-solid fa-sliders"></i>
            <?php esc_html_e( 'Filtri', 'lagalpi-child' ); ?>
        </button>
        <?php
    }
}
add_action( 'woocommerce_before_shop_loop', 'lagalpi_render_mobile_filter_trigger', 5 );

/**
 * WooCommerce Single Product Layout Adjustments
 */
// 1. Move price below short description
remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_price', 10 );
add_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_price', 25 );

// 2. Remove default tabs and move additional info (attributes) to the summary
remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_output_product_data_tabs', 10 );

function lagalpi_add_attributes_to_summary() {
    global $product;
    if ( ! $product ) {
        return;
    }
    // Output the attributes table directly
    wc_display_product_attributes( $product );
}
add_action( 'woocommerce_single_product_summary', 'lagalpi_add_attributes_to_summary', 45 );

// 3. Add "Richiedi info sul prodotto" button
function lagalpi_add_richiedi_info_button() {
    // home_url('/contatti/') is the Italian slug only — WPML gives the
    // Contatti page a different slug per language (kontakt/contact/...), so
    // this hardcoded link 404'd (or landed on the wrong page) on every
    // non-Italian product page. Resolve it through the translation group
    // instead, same approach as lagalpi_force_translated_page_templates().
    $contatti_url = home_url( '/contatti/' ); // fallback if lookup fails
    $matches = get_posts( array(
        'name'             => 'contatti',
        'post_type'        => 'page',
        'post_status'      => 'publish',
        'numberposts'      => 1,
        'suppress_filters' => true,
    ) );
    if ( ! empty( $matches ) ) {
        $translated_id = function_exists( 'icl_object_id' ) ? icl_object_id( $matches[0]->ID, 'page', false ) : $matches[0]->ID;
        if ( $translated_id ) {
            $permalink = get_permalink( $translated_id );
            if ( $permalink ) {
                $contatti_url = $permalink;
            }
        }
    }

    echo '<a href="' . esc_url( $contatti_url ) . '" class="lagalpi-richiedi-info-btn">' . esc_html__( 'Richiedi info sul prodotto', 'lagalpi-child' ) . '</a>';
}
add_action( 'woocommerce_single_product_summary', 'lagalpi_add_richiedi_info_button', 50 );


/**
 * 4. Custom Backend Email Settings Page
 */
function lagalpi_add_email_settings_page() {
    add_menu_page(
        esc_html__( 'Impostazioni Email', 'lagalpi-child' ),
        esc_html__( 'lagAlpi Mail', 'lagalpi-child' ),
        'manage_options',
        'lagalpi-email-settings',
        'lagalpi_render_email_settings_page',
        'dashicons-email-alt',
        80
    );
}
add_action( 'admin_menu', 'lagalpi_add_email_settings_page' );

function lagalpi_register_email_settings() {
    register_setting(
        'lagalpi_email_settings_group',
        'lagalpi_email_logo',
        array( 'sanitize_callback' => 'esc_url_raw' )
    );
    register_setting(
        'lagalpi_email_settings_group',
        'lagalpi_email_signature',
        array( 'sanitize_callback' => 'wp_kses_post' )
    );
    register_setting(
        'lagalpi_email_settings_group',
        'lagalpi_email_primary_color',
        array( 'sanitize_callback' => 'sanitize_hex_color' )
    );
}
add_action( 'admin_init', 'lagalpi_register_email_settings' );

function lagalpi_enqueue_admin_media_scripts( $hook ) {
    if ( $hook !== 'toplevel_page_lagalpi-email-settings' ) {
        return;
    }
    wp_enqueue_media();
}
add_action( 'admin_enqueue_scripts', 'lagalpi_enqueue_admin_media_scripts' );

function lagalpi_render_email_settings_page() {
    ?>
    <div class="wrap">
        <h1><?php esc_html_e( 'Impostazioni Email lagAlpi', 'lagalpi-child' ); ?></h1>
        <form method="post" action="options.php" style="max-width: 800px; background: #fff; padding: 25px; border-radius: 8px; box-shadow: 0 4px 15px rgba(0,0,0,0.05); margin-top: 20px;">
            <?php settings_fields( 'lagalpi_email_settings_group' ); ?>
            <?php do_settings_sections( 'lagalpi_email_settings_group' ); ?>
            
            <table class="form-table" style="width: 100%;">
                <tr valign="top">
                    <th scope="row" style="width: 200px; font-weight: 600;"><?php esc_html_e( 'Logo Intestazione Email', 'lagalpi-child' ); ?></th>
                    <td>
                        <?php
                        $logo_url = get_option( 'lagalpi_email_logo', '' );
                        ?>
                        <input type="text" name="lagalpi_email_logo" class="lagalpi-logo-url-input regular-text" value="<?php echo esc_attr( $logo_url ); ?>" style="width: 350px; margin-right: 10px;" />
                        <input type="button" class="lagalpi-upload-logo-btn button" value="<?php esc_attr_e( 'Seleziona Immagine', 'lagalpi-child' ); ?>" />
                        <br />
                        <img class="lagalpi-logo-preview" src="<?php echo esc_url( $logo_url ); ?>" style="max-width: 150px; margin-top: 15px; border: 1px solid #ddd; padding: 5px; background: #f9f9f9; display: <?php echo $logo_url ? 'block' : 'none'; ?>;" />
                    </td>
                </tr>
                
                <tr valign="top">
                    <th scope="row" style="font-weight: 600;"><?php esc_html_e( 'Colore Principale', 'lagalpi-child' ); ?></th>
                    <td>
                        <?php
                        $color = get_option( 'lagalpi_email_primary_color', '#6bb059' );
                        ?>
                        <input type="color" name="lagalpi_email_primary_color" value="<?php echo esc_attr( $color ); ?>" style="width: 60px; height: 35px; border: 1px solid #ccc; border-radius: 4px; padding: 2px; cursor: pointer;" />
                        <span style="margin-left: 10px; color: #666; font-size: 13px;"><?php esc_html_e( 'Colore per intestazioni, link e bottoni.', 'lagalpi-child' ); ?></span>
                    </td>
                </tr>

                <tr valign="top">
                    <th scope="row" style="font-weight: 600;"><?php esc_html_e( 'Firma Email / Piè di pagina', 'lagalpi-child' ); ?></th>
                    <td>
                        <?php
                        $signature = get_option( 'lagalpi_email_signature', '&copy; ' . date('Y') . ' lagAlpi. Tutti i diritti riservati.' );
                        wp_editor( $signature, 'lagalpi_email_signature', array(
                            'textarea_rows' => 5,
                            'media_buttons' => false,
                            'tinymce'       => true,
                            'quicktags'     => true
                        ) );
                        ?>
                    </td>
                </tr>
            </table>
            
            <?php submit_button( esc_html__( 'Salva Impostazioni', 'lagalpi-child' ) ); ?>
        </form>
    </div>

    <script>
    jQuery(document).ready(function($){
        $('.lagalpi-upload-logo-btn').click(function(e) {
            e.preventDefault();
            var custom_uploader = wp.media({
                title: '<?php esc_html_e( "Seleziona Logo Email", "lagalpi-child" ); ?>',
                button: {
                    text: '<?php esc_html_e( "Usa questo logo", "lagalpi-child" ); ?>'
                },
                multiple: false
            }).on('select', function() {
                var attachment = custom_uploader.state().get('selection').first().toJSON();
                $('.lagalpi-logo-url-input').val(attachment.url);
                $('.lagalpi-logo-preview').attr('src', attachment.url).show();
            }).open();
        });
    });
    </script>
    <?php
}

/**
 * upgraded AJAX handler for Newsletter Subscription with HTML support
 */
add_action( 'wp_ajax_lagalpi_newsletter_subscribe', 'lagalpi_handle_newsletter_subscribe' );
add_action( 'wp_ajax_nopriv_lagalpi_newsletter_subscribe', 'lagalpi_handle_newsletter_subscribe' );

/**
 * Ensure the WooCommerce cart and checkout pages always have their shortcodes
 */
function lagalpi_force_woocommerce_page_shortcodes( $content ) {
    if ( is_page() ) {
        if ( function_exists( 'is_cart' ) && is_cart() ) {
            if ( empty( trim( $content ) ) || strpos( $content, '[woocommerce_cart]' ) === false ) {
                $content = '[woocommerce_cart]';
            }
        } elseif ( function_exists( 'is_checkout' ) && is_checkout() && ! is_wc_endpoint_url( 'order-pay' ) && ! is_wc_endpoint_url( 'order-received' ) ) {
            if ( empty( trim( $content ) ) || strpos( $content, '[woocommerce_checkout]' ) === false ) {
                $content = '[woocommerce_checkout]';
            }
        } elseif ( function_exists( 'is_account_page' ) && is_account_page() ) {
            if ( empty( trim( $content ) ) || strpos( $content, '[woocommerce_my_account]' ) === false ) {
                $content = '[woocommerce_my_account]';
            }
        }
    }
    return $content;
}
add_filter( 'the_content', 'lagalpi_force_woocommerce_page_shortcodes', 1 );

/**
 * Cart/checkout/account pages reuse the generic page.php template, which
 * tags the <article> with "default-article" for the plain-text prose card
 * styling (narrow width, boxed cells, link-as-card shadow). That styling
 * breaks the WooCommerce layouts, so strip the class on those pages.
 */
function lagalpi_strip_default_article_class( $classes ) {
    if ( ( function_exists( 'is_cart' ) && is_cart() )
        || ( function_exists( 'is_checkout' ) && is_checkout() )
        || ( function_exists( 'is_account_page' ) && is_account_page() ) ) {
        $classes = array_diff( $classes, array( 'default-article' ) );
    }
    return $classes;
}
add_filter( 'post_class', 'lagalpi_strip_default_article_class' );

/**
 * Shipping Rules Page: append a contact form for international shipping requests
 */
function lagalpi_append_shipping_contact_form( $content ) {
    if ( is_page( 'regole-di-spedizione' ) && in_the_loop() && is_main_query() ) {
        ob_start();
        ?>
        <div class="lagalpi-shipping-contact-box">
            <form class="lagalpi-shipping-contact-form" method="post">
                <div class="form-row-group">
                    <div>
                        <label for="shipping_contact_name"><?php esc_html_e( 'Nome', 'lagalpi-child' ); ?></label>
                        <input type="text" id="shipping_contact_name" name="shipping_contact_name" placeholder="<?php esc_attr_e( 'Nome', 'lagalpi-child' ); ?>" required>
                    </div>
                    <div>
                        <label for="shipping_contact_email"><?php esc_html_e( 'Email', 'lagalpi-child' ); ?></label>
                        <input type="email" id="shipping_contact_email" name="shipping_contact_email" placeholder="<?php esc_attr_e( 'Email', 'lagalpi-child' ); ?>" required>
                    </div>
                </div>
                <label for="shipping_contact_country"><?php esc_html_e( 'Paese di destinazione', 'lagalpi-child' ); ?></label>
                <input type="text" id="shipping_contact_country" name="shipping_contact_country" placeholder="<?php esc_attr_e( 'Paese di destinazione', 'lagalpi-child' ); ?>" required>
                <label for="shipping_contact_message"><?php esc_html_e( 'Messaggio', 'lagalpi-child' ); ?></label>
                <textarea id="shipping_contact_message" name="shipping_contact_message" placeholder="<?php esc_attr_e( 'Descrivi cosa desideri spedire e a quale indirizzo', 'lagalpi-child' ); ?>" rows="5" required></textarea>
                <button type="submit" class="shipping-contact-submit-btn"><?php esc_html_e( 'Invia richiesta', 'lagalpi-child' ); ?></button>
                <p class="shipping-contact-feedback" role="status"></p>
            </form>
        </div>
        <?php
        $content .= ob_get_clean();
    }
    return $content;
}
add_filter( 'the_content', 'lagalpi_append_shipping_contact_form', 20 );

/**
 * My Account page: wrap everything after the account nav (greeting text,
 * order tables, address cards, forms, ...) in a single container so it can
 * be styled as one content card next to the nav sidebar. Without this, the
 * nav and each loose sibling (e.g. two separate <p> tags on the dashboard)
 * are independent CSS Grid items, and a tall sidebar inflates the row they
 * share, blowing an empty gap into the shorter siblings.
 */
function lagalpi_wrap_account_content( $content ) {
    if ( function_exists( 'is_account_page' ) && is_account_page() && in_the_loop() && is_main_query() ) {
        $parts = explode( '</nav>', $content, 2 );
        if ( count( $parts ) === 2 ) {
            $content = $parts[0] . '</nav><div class="lagalpi-account-content-card">' . $parts[1] . '</div>';
        }
    }
    return $content;
}
add_filter( 'the_content', 'lagalpi_wrap_account_content', 25 );

/**
 * Handle the international shipping request form (AJAX)
 */
function lagalpi_handle_shipping_contact_form() {
    check_ajax_referer( 'lagalpi_shipping_contact_nonce', 'nonce' );

    $name    = isset( $_POST['name'] ) ? sanitize_text_field( wp_unslash( $_POST['name'] ) ) : '';
    $email   = isset( $_POST['email'] ) ? sanitize_email( wp_unslash( $_POST['email'] ) ) : '';
    $country = isset( $_POST['country'] ) ? sanitize_text_field( wp_unslash( $_POST['country'] ) ) : '';
    $message = isset( $_POST['message'] ) ? sanitize_textarea_field( wp_unslash( $_POST['message'] ) ) : '';

    if ( empty( $name ) || empty( $country ) || empty( $message ) || ! is_email( $email ) ) {
        wp_send_json_error( esc_html__( 'Compila tutti i campi con un indirizzo email valido.', 'lagalpi-child' ) );
    }

    $logo_url  = get_option( 'lagalpi_email_logo', '' );
    $signature = get_option( 'lagalpi_email_signature', '&copy; ' . date( 'Y' ) . ' lagAlpi. Tutti i diritti riservati.' );
    $color     = get_option( 'lagalpi_email_primary_color', '#6bb059' );

    $email_content = '
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="utf-8">
        <style>
            body { font-family: "Helvetica Neue", Helvetica, Arial, sans-serif; background-color: #f6f6f6; margin: 0; padding: 20px; }
            .email-container { max-width: 600px; margin: 0 auto; background: #ffffff; border-radius: 8px; border: 1px solid #eaeaea; overflow: hidden; }
            .email-header { background: ' . esc_attr( $color ) . '; padding: 30px; text-align: center; }
            .email-header img { max-width: 150px; height: auto; }
            .email-body { padding: 40px 30px; line-height: 1.6; color: #333333; font-size: 16px; }
            .email-body h2 { color: ' . esc_attr( $color ) . '; margin-top: 0; font-size: 22px; border-bottom: 2px solid #eaeaea; padding-bottom: 10px; }
            .email-table { width: 100%; border-collapse: collapse; margin-top: 20px; }
            .email-table td { padding: 12px; border-bottom: 1px solid #eaeaea; font-size: 15px; vertical-align: top; }
            .email-table td.label { font-weight: bold; width: 120px; color: #555555; }
            .email-footer { background: #fafafa; padding: 25px 20px; text-align: center; font-size: 12px; color: #777777; border-top: 1px solid #eaeaea; line-height: 1.5; }
            .email-footer a { color: ' . esc_attr( $color ) . '; text-decoration: none; }
        </style>
    </head>
    <body>
        <div class="email-container">
            <div class="email-header">
                ' . ( ! empty( $logo_url ) ? '<img src="' . esc_url( $logo_url ) . '" alt="lagAlpi">' : '<h1 style="color:#ffffff; margin:0; font-size:24px; font-weight:600; letter-spacing:1px;">lagAlpi</h1>' ) . '
            </div>
            <div class="email-body">
                <h2>Richiesta Spedizione Internazionale</h2>
                <p>Un utente ha richiesto informazioni per una spedizione verso un paese non coperto dalle tariffe standard.</p>
                <table class="email-table">
                    <tr>
                        <td class="label">Nome:</td>
                        <td>' . esc_html( $name ) . '</td>
                    </tr>
                    <tr>
                        <td class="label">Email:</td>
                        <td><a href="mailto:' . esc_attr( $email ) . '" style="color:' . esc_attr( $color ) . '; font-weight:600; text-decoration:none;">' . esc_html( $email ) . '</a></td>
                    </tr>
                    <tr>
                        <td class="label">Paese:</td>
                        <td>' . esc_html( $country ) . '</td>
                    </tr>
                    <tr>
                        <td class="label">Messaggio:</td>
                        <td>' . nl2br( esc_html( $message ) ) . '</td>
                    </tr>
                    <tr>
                        <td class="label">Data/Ora:</td>
                        <td>' . current_time( 'mysql' ) . '</td>
                    </tr>
                </table>
            </div>
            <div class="email-footer">
                ' . wp_kses_post( $signature ) . '
            </div>
        </div>
    </body>
    </html>
    ';

    $admin_email = get_option( 'admin_email' );
    $subject     = esc_html__( 'Richiesta spedizione internazionale - lagAlpi', 'lagalpi-child' );
    $headers     = array(
        'Content-Type: text/html; charset=UTF-8',
        'Reply-To: ' . $name . ' <' . $email . '>',
    );

    $sent = wp_mail( $admin_email, $subject, $email_content, $headers );

    if ( $sent ) {
        wp_send_json_success();
    } else {
        wp_send_json_error( esc_html__( 'Errore nell\'invio dell\'email. Riprova più tardi.', 'lagalpi-child' ) );
    }
}
add_action( 'wp_ajax_lagalpi_shipping_contact', 'lagalpi_handle_shipping_contact_form' );
add_action( 'wp_ajax_nopriv_lagalpi_shipping_contact', 'lagalpi_handle_shipping_contact_form' );

/**
 * Live product search: returns matching products (image, title, price, link)
 * for the header search modal's type-ahead preview.
 */
function lagalpi_handle_live_search() {
    check_ajax_referer( 'lagalpi_live_search_nonce', 'nonce' );

    $term = isset( $_POST['term'] ) ? sanitize_text_field( wp_unslash( $_POST['term'] ) ) : '';

    if ( mb_strlen( trim( $term ) ) < 2 ) {
        wp_send_json_success( array() );
    }

    $query = new WP_Query( array(
        'post_type'           => 'product',
        's'                   => $term,
        'posts_per_page'      => 6,
        'post_status'         => 'publish',
        'ignore_sticky_posts' => true,
    ) );

    $results = array();

    if ( $query->have_posts() ) {
        while ( $query->have_posts() ) {
            $query->the_post();
            $product = wc_get_product( get_the_ID() );

            if ( ! $product ) {
                continue;
            }

            $image_id  = $product->get_image_id();
            $image_url = $image_id ? wp_get_attachment_image_url( $image_id, 'thumbnail' ) : wc_placeholder_img_src( 'thumbnail' );

            $results[] = array(
                'title'     => get_the_title(),
                'permalink' => get_permalink(),
                'image'     => $image_url,
                'price'     => wp_strip_all_tags( $product->get_price_html() ),
                'in_stock'  => $product->is_in_stock(),
            );
        }
        wp_reset_postdata();
    }

    wp_send_json_success( $results );
}
add_action( 'wp_ajax_lagalpi_live_search', 'lagalpi_handle_live_search' );
add_action( 'wp_ajax_nopriv_lagalpi_live_search', 'lagalpi_handle_live_search' );

function lagalpi_handle_newsletter_subscribe() {
    check_ajax_referer( 'lagalpi_newsletter_nonce', 'nonce' );
    
    $nome = isset( $_POST['nome'] ) ? sanitize_text_field( wp_unslash( $_POST['nome'] ) ) : '';
    $email = isset( $_POST['email'] ) ? sanitize_email( wp_unslash( $_POST['email'] ) ) : '';
    
    if ( ! is_email( $email ) ) {
        wp_send_json_error( esc_html__( 'Indirizzo email non valido.', 'lagalpi-child' ) );
    }
    
    // Fetch CMS settings
    $logo_url = get_option( 'lagalpi_email_logo', '' );
    $signature = get_option( 'lagalpi_email_signature', '&copy; ' . date('Y') . ' lagAlpi. Tutti i diritti riservati.' );
    $color = get_option( 'lagalpi_email_primary_color', '#6bb059' );

    // Build beautiful HTML email body
    $email_content = '
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="utf-8">
        <style>
            body { font-family: "Helvetica Neue", Helvetica, Arial, sans-serif; background-color: #f6f6f6; margin: 0; padding: 20px; }
            .email-container { max-width: 600px; margin: 0 auto; background: #ffffff; border-radius: 8px; border: 1px solid #eaeaea; overflow: hidden; }
            .email-header { background: ' . esc_attr( $color ) . '; padding: 30px; text-align: center; }
            .email-header img { max-width: 150px; height: auto; }
            .email-body { padding: 40px 30px; line-height: 1.6; color: #333333; font-size: 16px; }
            .email-body h2 { color: ' . esc_attr( $color ) . '; margin-top: 0; font-size: 22px; border-bottom: 2px solid #eaeaea; padding-bottom: 10px; }
            .email-table { width: 100%; border-collapse: collapse; margin-top: 20px; }
            .email-table td { padding: 12px; border-bottom: 1px solid #eaeaea; font-size: 15px; }
            .email-table td.label { font-weight: bold; width: 120px; color: #555555; }
            .email-footer { background: #fafafa; padding: 25px 20px; text-align: center; font-size: 12px; color: #777777; border-top: 1px solid #eaeaea; line-height: 1.5; }
            .email-footer a { color: ' . esc_attr( $color ) . '; text-decoration: none; }
        </style>
    </head>
    <body>
        <div class="email-container">
            <div class="email-header">
                ' . ( ! empty( $logo_url ) ? '<img src="' . esc_url( $logo_url ) . '" alt="lagAlpi">' : '<h1 style="color:#ffffff; margin:0; font-size:24px; font-weight:600; letter-spacing:1px;">lagAlpi</h1>' ) . '
            </div>
            <div class="email-body">
                <h2>Nuova Iscrizione alla Newsletter</h2>
                <p>Un utente ha completato con successo l\'iscrizione alla newsletter tramite il form presente nel sito lagAlpi.</p>
                <table class="email-table">
                    <tr>
                        <td class="label">Nome:</td>
                        <td>' . esc_html( $nome ) . '</td>
                    </tr>
                    <tr>
                        <td class="label">Email:</td>
                        <td><a href="mailto:' . esc_attr( $email ) . '" style="color:' . esc_attr( $color ) . '; font-weight:600; text-decoration:none;">' . esc_html( $email ) . '</a></td>
                    </tr>
                    <tr>
                        <td class="label">Data/Ora:</td>
                        <td>' . current_time( 'mysql' ) . '</td>
                    </tr>
                </table>
            </div>
            <div class="email-footer">
                ' . wp_kses_post( $signature ) . '
            </div>
        </div>
    </body>
    </html>
    ';

    $admin_email = get_option( 'admin_email' );
    $subject = esc_html__( 'Nuova iscrizione alla newsletter - lagAlpi', 'lagalpi-child' );
    $headers = array( 'Content-Type: text/html; charset=UTF-8' );
    
    $sent = wp_mail( $admin_email, $subject, $email_content, $headers );
    
    if ( $sent ) {
        wp_send_json_success();
    } else {
        wp_send_json_error( esc_html__( 'Errore nell\'invio dell\'email.', 'lagalpi-child' ) );
    }
}

/**
 * Force Italian translations for specific WooCommerce and theme strings
 */
function lagalpi_custom_translations( $translated_text, $text, $domain ) {
    $lang = function_exists( 'lagalpi_get_current_language' ) ? lagalpi_get_current_language() : 'it';
    $trimmed = trim( $text );
    $lowercased = strtolower( $trimmed );
    
    if ( $lang === 'it' ) {
        switch ( $lowercased ) {
            case 'billing details':
                return 'Dettagli di fatturazione';
            case 'billing & shipping':
                return 'Fatturazione e Spedizione';
            case 'no order has been made yet.':
                return 'Non hai ancora effettuato ordini.';
            case 'browse products':
                return 'Sfoglia i prodotti';
            case 'no downloads available yet.':
                return 'Nessun download disponibile al momento.';
            case 'the following addresses will be used on the checkout page by default.':
                return 'I seguenti indirizzi verranno utilizzati per impostazione predefinita nella pagina di pagamento.';
            case 'no saved methods found.':
                return 'Nessun metodo salvato trovato.';
            case 'add payment method':
                return 'Aggiungi metodo di pagamento';
            case 'password change':
                return 'Cambio password';
            case 'current password (leave blank to leave unchanged)':
                return 'Password attuale (lascia vuoto per non modificarla)';
            case 'new password (leave blank to leave unchanged)':
                return 'Nuova password (lascia vuoto per non modificarla)';
            case 'confirm new password':
                return 'Conferma nuova password';
            case 'billing address':
                return 'Indirizzo di fatturazione';
            case 'shipping address':
                return 'Indirizzo di spedizione';
            case 'edit %s':
                return 'Modifica %s';
            case 'add %s':
                return 'Aggiungi %s';
            case 'you have not set up this type of address yet.':
                return 'Non hai ancora impostato questo tipo di indirizzo.';
            case 'privacy policy':
                return 'informativa sulla privacy';
            case 'terms and conditions':
                return 'termini e condizioni';
            case 'display name':
                return 'Nome visualizzato';
            case 'this will be how your name will be displayed in the account section and in reviews':
                return 'Sarà il modo in cui il tuo nome verrà mostrato nella sezione account e nelle recensioni';
            case 'save changes':
                return 'Salva modifiche';
            case 'dashboard':
                return 'Bacheca';
            case 'orders':
                return 'Ordini';
            case 'downloads':
                return 'Download';
            case 'address':
                return 'Indirizzo';
            case 'addresses':
                return 'Indirizzi';
            case 'payment methods':
                return 'Metodi di pagamento';
            case 'account details':
                return 'Dettagli account';
            case 'log out':
                return 'Esci';
            case 'hello %1$s (not %1$s? <a href="%2$s">log out</a>)':
                return 'Ciao %1$s (non sei %1$s? <a href="%2$s">Esci</a>)';
            case 'from your account dashboard you can view your <a href="%1$s">recent orders</a>, manage your <a href="%2$s">shipping and billing addresses</a>, and <a href="%3$s">edit your password and account details</a>.':
                return 'Dalla tua bacheca puoi visualizzare i tuoi <a href="%1$s">ordini recenti</a>, gestire i tuoi <a href="%2$s">indirizzi di spedizione e fatturazione</a> e <a href="%3$s">modificare la password e i dettagli dell\'account</a>.';
            case 'from your account dashboard you can view your <a href="%1$s">recent orders</a>, manage your <a href="%2$s">billing address</a>, and <a href="%3$s">edit your password and account details</a>.':
                return 'Dalla tua bacheca puoi visualizzare i tuoi <a href="%1$s">ordini recenti</a>, gestire il tuo <a href="%2$s">indirizzo di fatturazione</a> e <a href="%3$s">modificare la password e i dettagli dell\'account</a>.';
            case 'first name':
                return 'Nome';
            case 'last name':
                return 'Cognome';
            case 'company name':
                return 'Nome della società';
            case 'company name (optional)':
                return 'Nome della società (opzionale)';
            case '(optional)':
                return '(opzionale)';
            case 'optional':
                return 'opzionale';
            case 'country / region':
                return 'Paese / Regione';
            case 'street address':
                return 'Via e numero';
            case 'apartment, suite, unit, etc. (optional)':
                return 'Appartamento, suite, unità, ecc. (opzionale)';
            case 'town / city':
                return 'Città';
            case 'state / county':
                return 'Provincia / Cantone';
            case 'canton':
            case 'canton:':
                return 'Cantone';
            case 'postcode / zip':
            case 'postcode':
            case 'zip':
                return 'C.A.P.';
            case 'phone':
                return 'Telefono';
            case 'email address':
                return 'Indirizzo email';
            case 'order notes':
                return 'Note sull\'ordine';
            case 'order notes (optional)':
                return 'Note sull\'ordine (opzionale)';
            case 'notes about your order, e.g. special notes for delivery.':
                return 'Note sull\'ordine, es. note speciali per la consegna.';
            case 'additional information':
                return 'Informazioni aggiuntive';
            case 'your order':
                return 'Il tuo ordine';
            case 'ship to a different address?':
            case 'ship to a different address':
                return 'Spedire ad un indirizzo diverso?';
            case 'save to account':
            case 'save to account?':
                return 'Salva nel tuo account';
            case 'available on backorder':
                return 'Disponibile su ordinazione';
            case 'format':
                return ( $text === 'FORMAT' ) ? 'FORMATO' : 'Formato';
            case 'clear':
                return ( $text === 'CLEAR' ) ? 'CANCELLA' : 'Cancella';
            case 'related products':
                return ( $text === 'RELATED PRODUCTS' ) ? 'PRODOTTI CORRELATI' : 'Prodotti correlati';
            case 'weight':
                return ( $text === 'WEIGHT' ) ? 'PESO' : 'Peso';
            case 'categories':
            case 'categories:':
                return ( strpos( $text, ':' ) !== false ) ? 'Categorie:' : 'Categorie';
            case 'category':
            case 'category:':
                return ( strpos( $text, ':' ) !== false ) ? 'Categoria:' : 'Categoria';
            case 'add to cart':
                return ( $text === 'ADD TO CART' ) ? 'ACQUISTA' : 'Acquista';
            case 'select options':
                return ( $text === 'SELECT OPTIONS' ) ? 'SCEGLI' : 'Scegli';
            case 'producer':
                return ( $text === 'PRODUCER' ) ? 'PRODUTTORE' : 'Produttore';
            case 'currency':
                return ( $text === 'CURRENCY' ) ? 'VALUTA' : 'Valuta';
            case 'currencies':
                return ( $text === 'CURRENCIES' ) ? 'VALUTE' : 'Valute';
            case 'product':
                return ( $text === 'PRODUCT' ) ? 'PRODOTTO' : 'Prodotto';
            case 'price':
                return ( $text === 'PRICE' ) ? 'PREZZO' : 'Prezzo';
            case 'quantity':
                return ( $text === 'QUANTITY' ) ? 'QUANTITÀ' : 'Quantità';
            case 'subtotal':
            case 'subtotal:':
                return ( strpos( $text, ':' ) !== false ) ? 'Subtotale:' : 'Subtotale';
            case 'cart totals':
                return ( $text === 'CART TOTALS' ) ? 'TOTALE CARRELLO' : 'Totale Carrello';
            case 'shipment':
            case 'shipment:':
                return ( strpos( $text, ':' ) !== false ) ? 'Spedizione:' : 'Spedizione';
            case 'shipping':
            case 'shipping:':
                return ( strpos( $text, ':' ) !== false ) ? 'Spedizione:' : 'Spedizione';
            case 'total':
            case 'total:':
                return ( strpos( $text, ':' ) !== false ) ? 'Totale:' : 'Totale';
            case 'proceed to checkout':
                return ( $text === 'PROCEED TO CHECKOUT' ) ? 'PROCEDI AL PAGAMENTO' : 'Procedi al pagamento';
            case 'update cart':
                return ( $text === 'UPDATE CART' ) ? 'AGGIORNA CARRELLO' : 'Aggiorna carrello';
            case 'apply coupon':
                return ( $text === 'APPLY COUPON' ) ? 'APPLICA COUPON' : 'Applica coupon';
            case 'coupon code':
                return ( $text === 'COUPON CODE' ) ? 'CODICE COUPON' : 'Codice Coupon';
            case 'shipping to':
                return 'Spedizione a';
            case 'change address':
                return 'Modifica indirizzo';
            case 'your personal data will be used to process your order, support your experience throughout this website, and for other purposes described in our privacy policy.':
                return 'I tuoi dati personali verranno utilizzati per elaborare il tuo ordine, supportare la tua esperienza su questo sito web e per altri scopi descritti nella nostra privacy policy.';
            case 'place order':
                return ( $text === 'PLACE ORDER' ) ? 'EFFETTUA ORDINE' : 'Effettua ordine';
            case 'view cart':
                return ( $text === 'VIEW CART' ) ? 'VEDI CARRELLO' : 'Vedi carrello';
            case 'checkout':
                return ( $text === 'CHECKOUT' ) ? 'PAGAMENTO' : 'Pagamento';
            case '“%s” has been added to your cart.':
            case '"%s" has been added to your cart.':
            case '&ldquo;%s&rdquo; has been added to your cart.':
                return '“%s” è stato aggiunto al tuo carrello.';
            case 'returning customer?':
                return 'Cliente registrato?';
            case 'click here to login':
                return 'Clicca qui per accedere';
            case 'have a coupon?':
                return 'Hai un coupon?';
            case 'click here to enter your code':
                return 'Clicca qui per inserire il tuo codice';
            case 'enter your coupon code':
                return 'Inserisci il tuo codice coupon';
            case 'house number and street name':
                return 'Numero civico e nome della via';
            case '(includes %1$s estimated for %2$s)':
                return '(include %1$s stimato per %2$s)';
            case '(includes %s)':
                return '(include %s)';
            case 'my account':
                return 'Il mio account';
            case 'toggle menu':
                return 'Apri/chiudi menu';
            case 'close menu':
                return 'Chiudi menu';
            case 'close search':
                return 'Chiudi ricerca';
        }
    } elseif ( $lang === 'de' ) {
        switch ( $lowercased ) {
            case 'billing details':
                return 'Rechnungsdetails';
            case 'billing & shipping':
                return 'Rechnungsstellung & Versand';
            case 'no order has been made yet.':
                return 'Es wurde noch keine Bestellung aufgegeben.';
            case 'browse products':
                return 'Produkte durchstöbern';
            case 'no downloads available yet.':
                return 'Noch keine Downloads verfügbar.';
            case 'the following addresses will be used on the checkout page by default.':
                return 'Die folgenden Adressen werden standardmässig auf der Kassenseite verwendet.';
            case 'no saved methods found.':
                return 'Keine gespeicherten Zahlungsmethoden gefunden.';
            case 'add payment method':
                return 'Zahlungsmethode hinzufügen';
            case 'password change':
                return 'Passwort ändern';
            case 'current password (leave blank to leave unchanged)':
                return 'Aktuelles Passwort (leer lassen, um es unverändert zu lassen)';
            case 'new password (leave blank to leave unchanged)':
                return 'Neues Passwort (leer lassen, um es unverändert zu lassen)';
            case 'confirm new password':
                return 'Neues Passwort bestätigen';
            case 'billing address':
                return 'Rechnungsadresse';
            case 'shipping address':
                return 'Lieferadresse';
            case 'edit %s':
                return 'Bearbeiten: %s';
            case 'add %s':
                return 'Hinzufügen: %s';
            case 'you have not set up this type of address yet.':
                return 'Du hast diesen Adresstyp noch nicht eingerichtet.';
            case 'privacy policy':
                return 'Datenschutzerklärung';
            case 'terms and conditions':
                return 'Allgemeine Geschäftsbedingungen';
            case 'display name':
                return 'Anzeigename';
            case 'this will be how your name will be displayed in the account section and in reviews':
                return 'So wird dein Name im Kontobereich und in Bewertungen angezeigt';
            case 'save changes':
                return 'Änderungen speichern';
            case 'dashboard':
                return 'Übersicht';
            case 'orders':
                return 'Bestellungen';
            case 'downloads':
                return 'Downloads';
            case 'address':
                return 'Adresse';
            case 'addresses':
                return 'Adressen';
            case 'payment methods':
                return 'Zahlungsarten';
            case 'account details':
                return 'Kontodetails';
            case 'log out':
                return 'Abmelden';
            case 'hello %1$s (not %1$s? <a href="%2$s">log out</a>)':
                return 'Hallo %1$s (nicht %1$s? <a href="%2$s">Abmelden</a>)';
            case 'from your account dashboard you can view your <a href="%1$s">recent orders</a>, manage your <a href="%2$s">shipping and billing addresses</a>, and <a href="%3$s">edit your password and account details</a>.':
                return 'In deiner Kontoübersicht kannst du deine <a href="%1$s">letzten Bestellungen</a> einsehen, deine <a href="%2$s">Liefer- und Rechnungsadressen</a> verwalten und <a href="%3$s">dein Passwort und deine Kontodetails</a> bearbeiten.';
            case 'from your account dashboard you can view your <a href="%1$s">recent orders</a>, manage your <a href="%2$s">billing address</a>, and <a href="%3$s">edit your password and account details</a>.':
                return 'In deiner Kontoübersicht kannst du deine <a href="%1$s">letzten Bestellungen</a> einsehen, deine <a href="%2$s">Rechnungsadresse</a> verwalten und <a href="%3$s">dein Passwort und deine Kontodetails</a> bearbeiten.';
            case 'first name':
                return 'Vorname';
            case 'last name':
                return 'Nachname';
            case 'company name':
                return 'Firmenname (optional)';
            case 'company name (optional)':
                return 'Firmenname (optional)';
            case 'country / region':
                return 'Land / Region';
            case 'street address':
                return 'Straße und Hausnummer';
            case 'apartment, suite, unit, etc. (optional)':
                return 'Wohnung, Suite, U.S.W. (optional)';
            case 'town / city':
                return 'Ort / Stadt';
            case 'state / county':
                return 'Staat / Kanton';
            case 'postcode / zip':
            case 'postcode':
            case 'zip':
                return 'PLZ';
            case 'phone':
                return 'Telefon';
            case 'email address':
                return 'E-Mail-Adresse';
            case 'order notes':
                return 'Anmerkungen zur Bestellung';
            case 'order notes (optional)':
                return 'Anmerkungen zur Bestellung (optional)';
            case 'notes about your order, e.g. special notes for delivery.':
                return 'Anmerkungen zu Ihrer Bestellung, z.B. besondere Hinweise für die Lieferung.';
            case 'additional information':
                return 'Zusätzliche Informationen';
            case 'your order':
                return 'Ihre Bestellung';
            case 'ship to a different address?':
            case 'ship to a different address':
                return 'Lieferung an eine andere Adresse?';
            case 'canton':
            case 'canton:':
                return 'Kanton';
            case 'save to account':
            case 'save to account?':
                return 'Im Konto speichern';
            case 'available on backorder':
                return 'Auf Nachbestellung verfügbar';
            case 'format':
                return ( $text === 'FORMAT' ) ? 'FORMAT' : 'Format';
            case 'clear':
                return 'Leeren';
            case 'related products':
                return 'Ähnliche Produkte';
            case 'weight':
                return 'Gewicht';
            case 'categories':
            case 'categories:':
                return ( strpos( $text, ':' ) !== false ) ? 'Kategorien:' : 'Kategorien';
            case 'category':
            case 'category:':
                return ( strpos( $text, ':' ) !== false ) ? 'Kategorie:' : 'Kategorie';
            case 'add to cart':
                return 'In den Warenkorb';
            case 'select options':
                return 'Ausführung wählen';
            case 'producer':
                return 'Hersteller';
            case 'product':
                return 'Produkt';
            case 'price':
                return 'Preis';
            case 'quantity':
                return 'Menge';
            case 'subtotal':
            case 'subtotal:':
                return ( strpos( $text, ':' ) !== false ) ? 'Zwischensumme:' : 'Zwischensumme';
            case 'cart totals':
                return 'Warenkorb-Gesamtsumme';
            case 'shipment':
            case 'shipment:':
                return ( strpos( $text, ':' ) !== false ) ? 'Versand:' : 'Versand';
            case 'shipping':
            case 'shipping:':
                return ( strpos( $text, ':' ) !== false ) ? 'Versand:' : 'Versand';
            case 'total':
            case 'total:':
                return ( strpos( $text, ':' ) !== false ) ? 'Gesamtsumme:' : 'Gesamtsumme';
            case 'proceed to checkout':
                return 'Weiter zur Kasse';
            case 'update cart':
                return 'Warenkorb aktualisieren';
            case 'apply coupon':
                return 'Gutschein anwenden';
            case 'coupon code':
                return 'Gutscheincode';
            case 'your personal data will be used to process your order, support your experience throughout this website, and for other purposes described in our privacy policy.':
                return 'Ihre personenbezogenen Daten werden zur Abwicklung Ihrer Bestellung, zur Unterstützung Ihrer Erfahrung auf dieser Website und für andere in unserer Datenschutzerklärung beschriebene Zwecke verwendet.';
            case 'place order':
                return ( $text === 'PLACE ORDER' ) ? 'BESTELLUNG ABSCHICKEN' : 'Bestellung abschicken';
            case 'view cart':
                return ( $text === 'VIEW CART' ) ? 'WARENKORB ANZEIGEN' : 'Warenkorb anzeigen';
            case 'checkout':
                return ( $text === 'CHECKOUT' ) ? 'KASSE' : 'Kasse';
            case '“%s” has been added to your cart.':
            case '"%s" has been added to your cart.':
            case '&ldquo;%s&rdquo; has been added to your cart.':
                return '„%s“ wurde Ihrem Warenkorb hinzugefügt.';
            case 'returning customer?':
                return 'Bereits Kunde?';
            case 'click here to login':
                return 'Hier klicken, um sich anzumelden';
            case 'have a coupon?':
                return 'Sie haben einen Gutschein?';
            case 'click here to enter your code':
                return 'Hier klicken, um Ihren Code einzugeben';
            case 'enter your coupon code':
                return 'Geben Sie Ihren Gutscheincode ein';
            case 'house number and street name':
                return 'Hausnummer und Straßenname';
            case '(includes %1$s estimated for %2$s)':
                return '(inkl. %1$s geschätzt für %2$s)';
            case '(includes %s)':
                return '(inkl. %s)';
            case 'my account':
                return 'Mein Konto';
            case 'toggle menu':
                return 'Menü ein-/ausblenden';
            case 'close menu':
                return 'Menü schliessen';
            case 'close search':
                return 'Suche schliessen';
        }
    } elseif ( $lang === 'fr' ) {
        switch ( $lowercased ) {
            case 'billing details':
                return 'Détails de facturation';
            case 'billing & shipping':
                return 'Facturation & Livraison';
            case 'no order has been made yet.':
                return 'Aucune commande n\'a encore été passée.';
            case 'browse products':
                return 'Parcourir les produits';
            case 'no downloads available yet.':
                return 'Aucun téléchargement disponible pour le moment.';
            case 'the following addresses will be used on the checkout page by default.':
                return 'Les adresses suivantes seront utilisées par défaut sur la page de commande.';
            case 'no saved methods found.':
                return 'Aucune méthode enregistrée trouvée.';
            case 'add payment method':
                return 'Ajouter un moyen de paiement';
            case 'password change':
                return 'Changement de mot de passe';
            case 'current password (leave blank to leave unchanged)':
                return 'Mot de passe actuel (laisser vide pour ne pas le modifier)';
            case 'new password (leave blank to leave unchanged)':
                return 'Nouveau mot de passe (laisser vide pour ne pas le modifier)';
            case 'confirm new password':
                return 'Confirmer le nouveau mot de passe';
            case 'billing address':
                return 'Adresse de facturation';
            case 'shipping address':
                return 'Adresse de livraison';
            case 'edit %s':
                return 'Modifier %s';
            case 'add %s':
                return 'Ajouter %s';
            case 'you have not set up this type of address yet.':
                return 'Vous n\'avez pas encore configuré ce type d\'adresse.';
            case 'privacy policy':
                return 'politique de confidentialité';
            case 'terms and conditions':
                return 'termes et conditions';
            case 'display name':
                return 'Nom affiché';
            case 'this will be how your name will be displayed in the account section and in reviews':
                return 'C\'est ainsi que votre nom sera affiché dans la section compte et dans les avis';
            case 'save changes':
                return 'Enregistrer les modifications';
            case 'dashboard':
                return 'Tableau de bord';
            case 'orders':
                return 'Commandes';
            case 'downloads':
                return 'Téléchargements';
            case 'address':
                return 'Adresse';
            case 'addresses':
                return 'Adresses';
            case 'payment methods':
                return 'Moyens de paiement';
            case 'account details':
                return 'Détails du compte';
            case 'log out':
                return 'Déconnexion';
            case 'hello %1$s (not %1$s? <a href="%2$s">log out</a>)':
                return 'Bonjour %1$s (pas %1$s ? <a href="%2$s">Déconnexion</a>)';
            case 'from your account dashboard you can view your <a href="%1$s">recent orders</a>, manage your <a href="%2$s">shipping and billing addresses</a>, and <a href="%3$s">edit your password and account details</a>.':
                return 'Depuis votre tableau de bord, vous pouvez consulter vos <a href="%1$s">commandes récentes</a>, gérer vos <a href="%2$s">adresses de livraison et de facturation</a>, et <a href="%3$s">modifier votre mot de passe et les détails de votre compte</a>.';
            case 'from your account dashboard you can view your <a href="%1$s">recent orders</a>, manage your <a href="%2$s">billing address</a>, and <a href="%3$s">edit your password and account details</a>.':
                return 'Depuis votre tableau de bord, vous pouvez consulter vos <a href="%1$s">commandes récentes</a>, gérer votre <a href="%2$s">adresse de facturation</a>, et <a href="%3$s">modifier votre mot de passe et les détails de votre compte</a>.';
            case 'first name':
                return 'Prénom';
            case 'last name':
                return 'Nom';
            case 'company name':
                return 'Nom de l’entreprise';
            case 'company name (optional)':
                return 'Nom de l’entreprise (facultatif)';
            case 'country / region':
                return 'Pays / Région';
            case 'street address':
                return 'Adresse';
            case 'apartment, suite, unit, etc. (optional)':
                return 'Appartement, bureau, etc. (facultatif)';
            case 'town / city':
                return 'Ville';
            case 'state / county':
                return 'Région / Département';
            case 'canton':
            case 'canton:':
                return 'Canton';
            case 'postcode / zip':
            case 'postcode':
            case 'zip':
                return 'Code postal';
            case 'phone':
                return 'Téléphone';
            case 'email address':
                return 'Adresse e-mail';
            case 'order notes':
                return 'Notes de commande';
            case 'order notes (optional)':
                return 'Notes de commande (facultatif)';
            case 'notes about your order, e.g. special notes for delivery.':
                return 'Notes de commande, par exemple pour la livraison.';
            case 'additional information':
                return 'Informations complémentaires';
            case 'your order':
                return 'Votre commande';
            case 'ship to a different address?':
            case 'ship to a different address':
                return 'Expédier à une adresse différente ?';
            case 'save to account':
            case 'save to account?':
                return 'Enregistrer dans mon compte';
            case '(optional)':
                return '(facultatif)';
            case 'optional':
                return 'facultatif';
            case 'available on backorder':
                return 'Disponible sur commande';
            case 'format':
                return ( $text === 'FORMAT' ) ? 'FORMAT' : 'Format';
            case 'clear':
                return 'Effacer';
            case 'related products':
                return 'Produits apparentés';
            case 'weight':
                return 'Poids';
            case 'categories':
            case 'categories:':
                return ( strpos( $text, ':' ) !== false ) ? 'Catégories :' : 'Catégories';
            case 'category':
            case 'category:':
                return ( strpos( $text, ':' ) !== false ) ? 'Catégorie :' : 'Catégorie';
            case 'add to cart':
                return ( $text === 'ADD TO CART' ) ? 'ACHETER' : 'Acheter';
            case 'select options':
                return ( $text === 'SELECT OPTIONS' ) ? 'CHOISIR' : 'Choisir';
            case 'producer':
                return 'Producteur';
            case 'currency':
                return 'Devise';
            case 'currencies':
                return 'Devises';
            case 'product':
                return 'Produit';
            case 'price':
                return 'Prix';
            case 'quantity':
                return 'Quantité';
            case 'subtotal':
            case 'subtotal:':
                return ( strpos( $text, ':' ) !== false ) ? 'Sous-total :' : 'Sous-total';
            case 'cart totals':
                return 'Total du panier';
            case 'shipment':
            case 'shipment:':
                return ( strpos( $text, ':' ) !== false ) ? 'Livraison :' : 'Livraison';
            case 'shipping':
            case 'shipping:':
                return ( strpos( $text, ':' ) !== false ) ? 'Livraison :' : 'Livraison';
            case 'total':
            case 'total:':
                return ( strpos( $text, ':' ) !== false ) ? 'Total :' : 'Total';
            case 'proceed to checkout':
                return 'PROCÉDER À LA COMMANDE';
            case 'update cart':
                return 'METTRE À JOUR LE PANIER';
            case 'apply coupon':
                return 'APPLIQUER LE CODE PROMO';
            case 'coupon code':
                return 'Code promo';
            case 'shipping to':
                return 'Livraison à';
            case 'change address':
                return 'Modifier l’adresse';
            case 'your personal data will be used to process your order, support your experience throughout this website, and for other purposes described in our privacy policy.':
                return 'Vos données personnelles seront utilisées pour traiter votre commande, faciliter votre expérience sur ce site web et à d’autres fins décrites dans notre politique de confidentialité.';
            case 'place order':
                return ( $text === 'PLACE ORDER' ) ? 'PASSER LA COMMANDE' : 'Passer la commande';
            case 'view cart':
                return ( $text === 'VIEW CART' ) ? 'VOIR LE PANIER' : 'Voir le panier';
            case 'checkout':
                return ( $text === 'CHECKOUT' ) ? 'COMMANDER' : 'Commander';
            case '“%s” has been added to your cart.':
            case '"%s" has been added to your cart.':
            case '&ldquo;%s&rdquo; has been added to your cart.':
                return '« %s » a été ajouté à votre panier.';
            case 'returning customer?':
                return 'Client existant ?';
            case 'click here to login':
                return 'Cliquez ici pour vous connecter';
            case 'have a coupon?':
                return 'Vous avez un code promo ?';
            case 'click here to enter your code':
                return 'Cliquez ici pour entrer votre code';
            case 'enter your coupon code':
                return 'Entrez votre code promo';
            case 'house number and street name':
                return 'Numéro et nom de rue';
            case '(includes %1$s estimated for %2$s)':
                return '(inclut %1$s estimé pour %2$s)';
            case '(includes %s)':
                return '(inclut %s)';
            case 'my account':
                return 'Mon compte';
            case 'toggle menu':
                return 'Afficher/masquer le menu';
            case 'close menu':
                return 'Fermer le menu';
            case 'close search':
                return 'Fermer la recherche';
        }
    }
    // English needs no branch here: every remaining case above is keyed on
    // strings whose SOURCE text is already English (WooCommerce/WP core
    // __() calls), so the untouched $translated_text is already correct.
    // The theme's own Italian-sourced custom strings (homepage, contact
    // form, JS messages, ...) are translated via WPML String Translation
    // instead (see icl_register_string()/icl_add_string_translation() in
    // the one-off migration that moved them there), not through this
    // hand-written switch.
    return $translated_text;
}
add_filter( 'gettext', 'lagalpi_custom_translations', 20, 3 );

/**
 * WooCommerce's account menu builds "Address"/"Addresses" via _n(), which
 * fires 'ngettext' rather than plain 'gettext' — so the switch above never
 * saw it. Delegate to the same function with whichever of the two literal
 * strings actually applies.
 */
add_filter( 'ngettext', function ( $translated_text, $single, $plural, $number, $domain ) {
    $text = ( (int) $number === 1 ) ? $single : $plural;
    return lagalpi_custom_translations( $translated_text, $text, $domain );
}, 20, 5 );

/**
 * Safety net for WPML's own String Translation.
 *
 * All of this theme's custom strings (contact form, homepage, footer, JS
 * messages) are registered as WPML strings via icl_register_string() /
 * icl_add_string_translation() (context 'lagalpi-child'), so WPML's native
 * gettext hook (WPML\ST\Gettext\Hooks, priority 9) should serve them
 * automatically — and it reliably does for most of the site. But on the
 * handful of pages whose template is forced by name via
 * lagalpi_force_translated_page_templates() (Offerte/Produttori/Articoli/
 * Chi-siamo — see inc/helpers.php), the very first strings rendered right
 * after get_header() (e.g. the page's own <h1>) come back untranslated:
 * WPML's internal "current language" cache for that hook apparently hasn't
 * settled yet at that exact point, even though icl_translate() called
 * directly with the explicit language resolves correctly. Strings further
 * down the same page (e.g. the Contatti form fields) are unaffected.
 *
 * Rather than hardcode a workaround per page, this re-invokes that same
 * already-correct WPML API directly (with the language read from
 * ICL_LANGUAGE_CODE, which - unlike SitePress's cached value - is reliably
 * correct at this point) whenever the native hook left a 'lagalpi-child'
 * string untranslated. The actual translation still comes entirely from
 * WPML's String Translation tables (editable from wp-admin), never from
 * hardcoded PHP text.
 */
function lagalpi_wpml_string_translation_fallback( $translated_text, $text, $domain ) {
    if ( $domain !== 'lagalpi-child' || $translated_text !== $text ) {
        return $translated_text;
    }

    if ( ! function_exists( 'icl_translate' ) ) {
        return $translated_text;
    }

    $lang = function_exists( 'lagalpi_get_current_language' ) ? lagalpi_get_current_language() : 'it';
    if ( $lang === 'it' ) {
        return $translated_text; // 'it' is the source language; nothing to look up.
    }

    $has_translation = null;
    $result = icl_translate( $domain, md5( $text ), $text, false, $has_translation, $lang );

    return $has_translation ? $result : $translated_text;
}
add_filter( 'gettext', 'lagalpi_wpml_string_translation_fallback', 21, 3 );

/**
 * Some strings (e.g. the "Shipment" cart/checkout row label) are translated
 * with _x() rather than __(), which fires "gettext_with_context" instead of
 * "gettext" — route it through the same switch so those aren't missed.
 */
add_filter(
    'gettext_with_context',
    function ( $translated_text, $text, $context, $domain ) {
        return lagalpi_custom_translations( $translated_text, $text, $domain );
    },
    20,
    4
);


/**
 * Update header cart fragments on AJAX add to cart
 */
function lagalpi_cart_fragments( $fragments ) {
    ob_start();
    ?>
    <a href="<?php echo esc_url( wc_get_cart_url() ); ?>" class="action-btn cart-contents" id="lagalpi-cart-trigger">
        <span class="cart-total"><?php echo WC()->cart->get_cart_subtotal(); ?></span>
        <span class="cart-icon-wrapper">
            <i class="fas fa-shopping-cart"></i>
            <span class="cart-count"><?php echo esc_html( WC()->cart->get_cart_contents_count() ); ?></span>
        </span>
    </a>
    <?php
    $fragments['#lagalpi-cart-trigger'] = ob_get_clean();
    return $fragments;
}
add_filter( 'woocommerce_add_to_cart_fragments', 'lagalpi_cart_fragments' );

/**
 * Render mini-cart sidebar template in footer
 */
function lagalpi_mini_cart_sidebar() {
    // Avoid rendering on Cart or Checkout pages to prevent confusion
    if ( is_cart() || is_checkout() ) {
        return;
    }
    ?>
    <div id="lagalpi-mini-cart-drawer" class="lagalpi-mini-cart-drawer">
        <div class="lagalpi-mini-cart-drawer-overlay"></div>
        <div class="mini-cart-drawer-content">
            <div class="mini-cart-drawer-header">
                <h3><?php esc_html_e( 'Carrello', 'lagalpi-child' ); ?></h3>
                <button type="button" class="mini-cart-drawer-close" aria-label="<?php esc_attr_e( 'Chiudi', 'lagalpi-child' ); ?>">&times;</button>
            </div>
            <div class="mini-cart-drawer-body">
                <div class="widget_shopping_cart_content">
                    <?php woocommerce_mini_cart(); ?>
                </div>
            </div>
        </div>
    </div>
    <?php
}
add_action( 'wp_footer', 'lagalpi_mini_cart_sidebar' );


/**
 * Translate checkout and registration privacy policy texts dynamically.
 *
 * These strings do NOT come through as plain gettext() calls: WooCommerce
 * stores them as DB options (woocommerce_checkout_privacy_policy_text /
 * woocommerce_registration_privacy_policy_text, saved with their English
 * defaults) and applies a single filter — 'woocommerce_get_privacy_policy_text'
 * with a $type param ('checkout'/'registration') — to the option's value,
 * BEFORE replacing the literal '[privacy_policy]'/'[terms]' placeholders
 * with the actual links. The previous version of this function hooked two
 * filter names ('woocommerce_checkout_privacy_policy_text' and
 * '...registration...') that WooCommerce never actually fires, so it never
 * ran at all — the saved English option text was always shown verbatim,
 * regardless of language. The replacement below hooks the real filter and
 * keeps the '[privacy_policy]' token intact so WooCommerce's own link
 * replacement still works.
 */
function lagalpi_translate_privacy_policy_text( $text, $type ) {
    $lang = function_exists( 'lagalpi_get_current_language' ) ? lagalpi_get_current_language() : 'it';

    if ( $type === 'checkout' ) {
        switch ( $lang ) {
            case 'it':
                return 'I tuoi dati personali verranno utilizzati per elaborare il tuo ordine, supportare la tua esperienza su questo sito web e per altri scopi descritti nella nostra [privacy_policy].';
            case 'de':
                return 'Ihre personenbezogenen Daten werden zur Abwicklung Ihrer Bestellung, zur Unterstützung Ihrer Erfahrung auf dieser Website und für andere in unserer [privacy_policy] beschriebene Zwecke verwendet.';
            case 'fr':
                return 'Vos données personnelles seront utilisées pour traiter votre commande, faciliter votre expérience sur ce site web et à d’autres fins décrites dans notre [privacy_policy].';
            case 'en':
                return 'Your personal data will be used to process your order, support your experience throughout this website, and for other purposes described in our [privacy_policy].';
        }
    } elseif ( $type === 'registration' ) {
        switch ( $lang ) {
            case 'it':
                return 'I tuoi dati personali verranno utilizzati per supportare la tua esperienza su questo sito web, per gestire l\'accesso al tuo account e per altri scopi descritti nella nostra [privacy_policy].';
            case 'de':
                return 'Ihre personenbezogenen Daten werden verwendet, um Ihre Erfahrung auf dieser Website zu unterstützen, den Zugang zu Ihrem Konto zu verwalten und für andere in unserer [privacy_policy] beschriebene Zwecke.';
            case 'fr':
                return 'Vos données personnelles seront utilisées pour faciliter votre expérience sur ce site web, gérer l’accès à votre compte et à d’autres fins décrites dans notre [privacy_policy].';
            case 'en':
                return 'Your personal data will be used to support your experience throughout this website, to manage access to your account, and for other purposes described in our [privacy_policy].';
        }
    }

    return $text;
}
add_filter( 'woocommerce_get_privacy_policy_text', 'lagalpi_translate_privacy_policy_text', 20, 2 );

/**
 * Get localized policy page URLs dynamically
 */
function lagalpi_get_policy_page_url( $type ) {
    $lang = function_exists( 'lagalpi_get_current_language' ) ? lagalpi_get_current_language() : 'it';
    $paths = array(
        'it' => array(
            'info' => 'regole-di-spedizione',
            'condizioni' => 'condizioni-generali-di-vendita',
            'privacy' => 'privacy-policy',
            'cookie' => 'cookie-policy',
        ),
        'de' => array(
            'info' => 'versandvorschriften',
            'condizioni' => 'allgemeine-verkaufsbedingungen',
            'privacy' => 'privacy-policy',
            'cookie' => 'cookie-richtlinie',
        ),
        'fr' => array(
            'info' => 'informations-sur-la-livraison-et-lexpedition',
            'condizioni' => 'conditions-generales-de-vente',
            'privacy' => 'politique-de-confidentialite',
            'cookie' => 'politique-en-matiere-de-cookies',
        ),
        'en' => array(
            'info' => 'shipping-rules',
            'condizioni' => 'general-terms-and-conditions-of-sale',
            'privacy' => 'privacy-policy',
            'cookie' => 'cookie-policy',
        )
    );
    
    $path = isset( $paths[$lang][$type] ) ? $paths[$lang][$type] : $paths['it'][$type];
    $page = get_page_by_path( $path );
    
    if ( $page ) {
        return get_permalink( $page->ID );
    }
    
    $lang_prefix = ( $lang === 'it' ) ? '' : '/' . $lang;
    return home_url( $lang_prefix . '/' . $path . '/' );
}

/**
 * Get localized labels for policy links
 */
function lagalpi_get_policy_page_label( $type ) {
    $lang = function_exists( 'lagalpi_get_current_language' ) ? lagalpi_get_current_language() : 'it';
    $labels = array(
        'it' => array(
            'info' => 'Info consegne e spedizioni',
            'condizioni' => 'Condizioni generali di vendita',
            'privacy' => 'Privacy Policy',
            'cookie' => 'Cookie Policy',
        ),
        'de' => array(
            'info' => 'Lieferung und Versand',
            'condizioni' => 'Allgemeine Verkaufsbedingungen',
            'privacy' => 'Datenschutzerklärung',
            'cookie' => 'Cookie-Richtlinie',
        ),
        'fr' => array(
            'info' => 'Informations sur la livraison',
            'condizioni' => 'Conditions générales de vente',
            'privacy' => 'Politique de confidentialité',
            'cookie' => 'Politique en matière de cookies',
        ),
        'en' => array(
            'info' => 'Delivery and shipping info',
            'condizioni' => 'General terms and conditions of sale',
            'privacy' => 'Privacy Policy',
            'cookie' => 'Cookie Policy',
        )
    );
    
    return isset( $labels[$lang][$type] ) ? $labels[$lang][$type] : $labels['it'][$type];
}

/**
 * Strip srcset and CDN prefixes from images on local environment to prevent broken images
 */
function lagalpi_fix_local_images( $content ) {
    if ( isset( $_SERVER['HTTP_HOST'] ) && strpos( $_SERVER['HTTP_HOST'], 'localhost' ) !== false ) {
        // Strip srcset attributes entirely, or replace CDN urls
        $content = preg_replace( '/\s+srcset="[^"]*"/', '', $content );
        $content = preg_replace( '/\s+sizes="[^"]*"/', '', $content );
        // Also replace any Jetpack CDN urls in src
        $content = preg_replace( '/https:\/\/i[0-3]\.wp\.com\/lagalpi\.com/', 'http://localhost:8000/lagalpi', $content );
    }
    return $content;
}
add_filter( 'the_content', 'lagalpi_fix_local_images', 999 );





require_once get_stylesheet_directory() . '/inc/translation-compat.php';
