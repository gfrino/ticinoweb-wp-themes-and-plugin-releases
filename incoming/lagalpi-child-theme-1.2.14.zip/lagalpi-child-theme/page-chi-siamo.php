<?php
/**
 * Template Name: Chi Siamo
 *
 * @package lagalpi-child
 */

get_header();

// Get the featured image for the banner, fallback to provided image if not set
$hero_img = get_the_post_thumbnail_url( get_the_ID(), 'full' );
if ( ! $hero_img ) {
    $hero_img = esc_url( lagalpi_uploads_url( '2023/06/Chi-siamo-scaled.jpg' ) );
}
?>

<section class="chisiamo-hero" style="background-image: url('<?php echo $hero_img; ?>');">
    <div class="chisiamo-hero-overlay"></div>
    <div class="chisiamo-hero-text">
        <h1><?php the_title(); ?></h1>
        <?php
        // We can use the page excerpt for the subtitle "Gusto sconfinato"
        if ( has_excerpt() ) {
            echo '<p>' . get_the_excerpt() . '</p>';
        } else {
            echo '<p>' . esc_html__( 'Gusto sconfinato', 'lagalpi-child' ) . '</p>';
        }
        ?>
    </div>
</section>

<div class="lagalpi-container chisiamo-content">
    
    <div class="chisiamo-layout">
        <div class="chisiamo-image">
            <img src="<?php echo esc_url( lagalpi_uploads_url( '2023/05/sunlit-forest_1080x.webp' ) ); ?>" alt="Dalle radici al cielo">
        </div>
        
        <div class="chisiamo-text">
            <h2><?php esc_html_e( 'Dalle radici al cielo', 'lagalpi-child' ); ?></h2>
            <p><?php esc_html_e( "La struttura di lagAlpi è quella di un albero. Un bell'albero con radici solide nella tradizione e nel rispetto del territorio alpino, in quella terra che è nativa di lagAlpi e delle sue personalità. Poi c'è il tronco, audace e orgoglioso che protegge e sorregge, che nel suo svettare verso il cielo porta linfa vitale alla chioma, e rende possibile lo sguardo ottimistico al futuro. Infine lei, la chioma, rigogliosa e in continua trasformazione, pronta a protendersi laddove il futuro lo richiede per vincere le sfide con il tempo.", 'lagalpi-child' ); ?></p>
            <p><?php esc_html_e( "Nasciamo e troviamo spunto dalla passione per l'arco alpino e prealpino e per la sua gente, animati ed entusiasmati da un lungo cammino, tante esperienze e molti sogni, sbocciati in intense emozioni nel corso di generazioni e tanti anni a stretto contatto con il territorio.", 'lagalpi-child' ); ?></p>
            <p><?php esc_html_e( "La folta chioma del nostro albero si protende verso il futuro e l'innovazione, ma mantenendo un legame profondo con le radici di quella tradizione che ha saputo maturare l'eccellenza.", 'lagalpi-child' ); ?></p>
        </div>
    </div>
</div>
<div class="chisiamo-parallax-section" style="background-image: url('<?php echo esc_url( lagalpi_uploads_url( '2023/05/shallow-stream-midst-alpine-trees-rolling-hills-mountain-scaled.jpg' ) ); ?>');">
    <div class="parallax-overlay"></div>
    <div class="parallax-content lagalpi-container">
        <span class="parallax-subtitle"><?php esc_html_e( 'Filosofia', 'lagalpi-child' ); ?></span>
        <h2 class="parallax-title"><?php esc_html_e( 'Un territorio unico', 'lagalpi-child' ); ?></h2>
        <p><?php esc_html_e( 'Vorremmo respirare il profumo di un territorio unico, sogniamo lagAlpi come un veicolo per proporre una sostenibilità e uno sviluppo diversi e innovativi, dove la gente che opera e la terra da cui nascono i frutti siano i protagonisti e abbiano un futuro certo e di qualità.', 'lagalpi-child' ); ?></p>
    </div>
</div>

<div class="lagalpi-container chisiamo-content" style="padding: 60px 0;">
    <div class="chisiamo-layout">
        <div class="chisiamo-text">
            <h2><?php esc_html_e( 'Tradizione sì, ma nel futuro', 'lagalpi-child' ); ?></h2>
            <p><?php esc_html_e( 'Proprio il produttore ha un ruolo centrale in questo processo: è grazie a lui che la tradizione si è potuta mantenere intatta, arricchendosi delle nuove tecnologie a maggiore tutela di tutta la filiera produttiva. lagAlpi è consapevole di quanto sia importante il suo ruolo nella produzione e lo supporta attivamente e concretamente affinché possa continuare a svolgere il proprio lavoro – una grande passione – a beneficio di tutti gli alchimisti del gusto.', 'lagalpi-child' ); ?></p>
            <a href="<?php echo esc_url( home_url( '/produttori/' ) ); ?>" class="btn-chisiamo"><?php esc_html_e( 'SCOPRI I PRODUTTORI', 'lagalpi-child' ); ?></a>
        </div>
        <div class="chisiamo-image">
            <img src="<?php echo esc_url( lagalpi_uploads_url( '2023/05/woman-with-horse-in-corral_1080x.webp' ) ); ?>" alt="Tradizione sì, ma nel futuro">
        </div>
    </div>
</div>

<?php get_footer(); ?>
