<?php
/**
 * lagAlpi Child Theme custom WooCommerce filters sidebar template part.
 *
 * @package lagalpi-child
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// Get min/max prices from products
global $wpdb;
$min_price = floor( $wpdb->get_var( "SELECT MIN(meta_value+0) FROM {$wpdb->postmeta} WHERE meta_key='_price'" ) );
$max_price = ceil( $wpdb->get_var( "SELECT MAX(meta_value+0) FROM {$wpdb->postmeta} WHERE meta_key='_price'" ) );

// Set fallbacks if no prices found
if ( ! $min_price ) $min_price = 0;
if ( ! $max_price ) $max_price = 100;

// Fetch current active filters from URL query params (if page was reloaded)
$active_cat = isset( $_GET['filter_cat'] ) ? sanitize_text_field( $_GET['filter_cat'] ) : '';
$active_color = isset( $_GET['filter_color'] ) ? explode( ',', sanitize_text_field( $_GET['filter_color'] ) ) : array();
$active_format = isset( $_GET['filter_format'] ) ? explode( ',', sanitize_text_field( $_GET['filter_format'] ) ) : array();
$active_producer = isset( $_GET['filter_producer'] ) ? explode( ',', sanitize_text_field( $_GET['filter_producer'] ) ) : array();
$curr_min_price = isset( $_GET['min_price'] ) ? intval( $_GET['min_price'] ) : $min_price;
$curr_max_price = isset( $_GET['max_price'] ) ? intval( $_GET['max_price'] ) : $max_price;

// If we are currently on a category page, override default active category filter
if ( is_product_category() ) {
    $current_term = get_queried_object();
    $active_cat = $current_term->slug;
}
?>

<div class="lagalpi-filters-container">
    <button class="close-filters-drawer mobile-only" aria-label="<?php esc_attr_e( 'Close filters', 'lagalpi-child' ); ?>">
        <i class="fa-solid fa-xmark"></i>
    </button>
    
    <h3 class="filters-sidebar-title"><?php esc_html_e( 'Filtra prodotti', 'lagalpi-child' ); ?></h3>

    <!-- Search Bar -->
    <div class="filter-section filter-search">
        <h4 class="filter-title font-semibold" style="color:var(--color-primary); margin-bottom:15px; font-size:16px;"><?php esc_html_e( 'Cerca il prodotto', 'lagalpi-child' ); ?></h4>
        <form role="search" method="get" class="lagalpi-product-search" action="<?php echo esc_url( home_url( '/' ) ); ?>" style="position:relative; margin-bottom:40px;">
            <input type="search" class="search-field" placeholder="<?php esc_attr_e( 'Cerca...', 'lagalpi-child' ); ?>" value="<?php echo get_search_query(); ?>" name="s" style="width:100%; border:1px solid #ddd; padding:10px 40px 10px 15px; border-radius:4px; font-size:14px; outline:none;" />
            <input type="hidden" name="post_type" value="product" />
            <button type="submit" aria-label="<?php esc_attr_e( 'Search', 'lagalpi-child' ); ?>" style="position:absolute; right:10px; top:50%; transform:translateY(-50%); background:none; border:none; color:var(--color-primary); cursor:pointer;"><i class="fa-solid fa-magnifying-glass"></i></button>
        </form>
    </div>

    <!-- Product Categories Filter -->
    <div class="filter-section filter-categories">
        <h4 class="filter-title font-semibold" style="text-transform:uppercase; margin-bottom:15px; font-size:16px;"><?php esc_html_e( 'Categorie', 'lagalpi-child' ); ?></h4>
        <ul class="filter-links-list font-light">
            <?php
            $desired_order = array(
                'Dalle Alpi in tavola' => array('Aceto', 'Antipasti e Sottoli', 'Farina', 'Legumi', 'Mostarde e Salse salate', 'Olio', 'Riso', 'Senapi', 'Snacks e Chips', 'Spezie e Condimenti', 'Sughi e Conserve'),
                'Dolci e leccornie di vetta' => array('Composte e marmellate', 'Frutta sciroppata', 'Marron Glacès', 'Miele'),
                'Elisir leggendari & Spiriti alpini' => array('Birra', 'Distillati', 'Liquori', 'Sciroppi', 'Sidri', 'Tè'),
                'Idee regalo' => array('Box degustazione', 'Cesti regalo', 'Libri'),
            );
            
            // Get ALL product categories that are not empty
            $all_categories = get_terms( array(
                'taxonomy'   => 'product_cat',
                'hide_empty' => true,
            ) );
            
            // Create a lookup by normalized name and slug
            $cat_by_name = array();
            if ( ! is_wp_error( $all_categories ) && ! empty( $all_categories ) ) {
                foreach ( $all_categories as $c ) {
                    $normalized_name = mb_strtolower( trim( html_entity_decode( $c->name ) ), 'UTF-8' );
                    $cat_by_name[ $normalized_name ] = $c;
                    $cat_by_name[ strtolower( $c->slug ) ] = $c; // Fallback
                }
            }

            foreach ( $desired_order as $parent_name => $children_names ) {
                $parent_key = mb_strtolower( trim( $parent_name ), 'UTF-8' );
                $parent_cat = null;
                
                if ( isset( $cat_by_name[ $parent_key ] ) ) {
                    $parent_cat = $cat_by_name[ $parent_key ];
                } else {
                    $slug_fallback = sanitize_title( $parent_name );
                    if ( isset( $cat_by_name[ $slug_fallback ] ) ) {
                        $parent_cat = $cat_by_name[ $slug_fallback ];
                    }
                }
                
                if ( $parent_cat ) {
                    $active_class = ( $active_cat === $parent_cat->slug ) ? 'active' : '';
                    echo '<li class="parent-category" style="margin-bottom:8px;">';
                    echo '<a href="#" class="filter-cat-trigger ' . $active_class . '" data-slug="' . esc_attr( $parent_cat->slug ) . '" style="color:var(--color-text-secondary); text-decoration:none;">';
                    echo esc_html( $parent_cat->name );
                    echo '</a>';
                    
                    echo '<ul class="child-categories" style="list-style:none; padding-left:15px; margin-top:5px; margin-bottom:10px;">';
                    foreach ( $children_names as $child_name ) {
                        $child_key = mb_strtolower( trim( $child_name ), 'UTF-8' );
                        $child_cat = null;
                        
                        if ( isset( $cat_by_name[ $child_key ] ) ) {
                            $child_cat = $cat_by_name[ $child_key ];
                        } else {
                            $slug_fallback = sanitize_title( $child_name );
                            if ( isset( $cat_by_name[ $slug_fallback ] ) ) {
                                $child_cat = $cat_by_name[ $slug_fallback ];
                            }
                        }
                        
                        if ( $child_cat ) {
                            $child_active = ( $active_cat === $child_cat->slug ) ? 'active' : '';
                            echo '<li class="child-category" style="margin-bottom:5px;">';
                            echo '<a href="#" class="filter-cat-trigger ' . $child_active . '" data-slug="' . esc_attr( $child_cat->slug ) . '" style="color:var(--color-text-secondary); text-decoration:none; font-size:14px;">';
                            echo esc_html( $child_cat->name );
                            echo '</a>';
                            echo '</li>';
                        }
                    }
                    echo '</ul>';
                    echo '</li>';
                }
            }
            ?>
        </ul>
    </div>

    <!-- Color Attribute Swatches -->
    <div class="filter-section filter-colors">
        <h4 class="filter-title font-semibold"><?php esc_html_e( 'Colore', 'lagalpi-child' ); ?></h4>
        <div class="color-swatches-grid">
            <?php
            $colors = get_terms( array(
                'taxonomy'   => 'pa_colore',
                'hide_empty' => true,
            ) );
            
            if ( ! is_wp_error( $colors ) && ! empty( $colors ) ) :
                foreach ( $colors as $color ) :
                    // Try to get hex code from term meta (color, value, or secondary_color)
                    $hex = get_term_meta( $color->term_id, 'color', true );
                    if ( empty( $hex ) ) {
                        $hex = get_term_meta( $color->term_id, 'value', true );
                    }
                    if ( empty( $hex ) ) {
                        $hex = '#cccccc'; // Fallback
                    }
                    
                    $active_class = in_array( $color->slug, $active_color ) ? 'active' : '';
                    echo '<button class="color-swatch-btn ' . $active_class . '" ';
                    echo 'data-slug="' . esc_attr( $color->slug ) . '" ';
                    echo 'title="' . esc_attr( $color->name ) . '" ';
                    echo 'style="background-color: ' . esc_attr( $hex ) . ';"';
                    echo ' aria-label="' . esc_attr( $color->name ) . '">';
                    echo '</button>';
                endforeach;
            endif;
            ?>
        </div>
    </div>

    <!-- Formato Attribute buttons -->
    <div class="filter-section filter-formats">
        <h4 class="filter-title font-semibold"><?php esc_html_e( 'Formato', 'lagalpi-child' ); ?></h4>
        <div class="format-buttons-grid">
            <?php
            $formats = get_terms( array(
                'taxonomy'   => 'pa_formato',
                'hide_empty' => true,
            ) );
            
            if ( ! is_wp_error( $formats ) && ! empty( $formats ) ) :
                foreach ( $formats as $format ) :
                    $active_class = in_array( $format->slug, $active_format ) ? 'active' : '';
                    echo '<button class="format-btn ' . $active_class . '" data-slug="' . esc_attr( $format->slug ) . '">';
                    echo esc_html( $format->name );
                    echo '</button>';
                endforeach;
            endif;
            ?>
        </div>
    </div>

    <!-- Produttore Attribute check list -->
    <div class="filter-section filter-producers">
        <h4 class="filter-title font-semibold"><?php esc_html_e( 'Produttore', 'lagalpi-child' ); ?></h4>
        <ul class="filter-checkbox-list font-light">
            <?php
            $producers = get_terms( array(
                'taxonomy'   => 'pa_produttore',
                'hide_empty' => true,
            ) );
            
            if ( ! is_wp_error( $producers ) && ! empty( $producers ) ) :
                foreach ( $producers as $prod ) :
                    $checked = in_array( $prod->slug, $active_producer ) ? 'checked' : '';
                    echo '<li>';
                    echo '<label class="checkbox-label">';
                    echo '<input type="checkbox" class="producer-checkbox" value="' . esc_attr( $prod->slug ) . '" ' . $checked . '>';
                    echo '<span>' . esc_html( $prod->name ) . '</span>';
                    echo '</label>';
                    echo '</li>';
                endforeach;
            endif;
            ?>
        </ul>
    </div>

    <!-- Price Range Slider -->
    <div class="filter-section filter-price">
        <h4 class="filter-title font-semibold"><?php esc_html_e( 'Prezzo', 'lagalpi-child' ); ?></h4>
        <div class="price-slider-container">
            <div class="price-inputs">
                <span class="price-label"><?php esc_html_e( 'Prezzo: ', 'lagalpi-child' ); ?></span>
                <span class="price-display">
                    <span id="price-min-display"><?php echo $curr_min_price; ?></span> CHF - 
                    <span id="price-max-display"><?php echo $curr_max_price; ?></span> CHF
                </span>
            </div>
            <div class="slider-inputs-wrapper">
                <input type="range" id="price-min" min="<?php echo $min_price; ?>" max="<?php echo $max_price; ?>" value="<?php echo $curr_min_price; ?>" class="price-range-input">
                <input type="range" id="price-max" min="<?php echo $min_price; ?>" max="<?php echo $max_price; ?>" value="<?php echo $curr_max_price; ?>" class="price-range-input">
            </div>
        </div>
    </div>

    <!-- Reset and Active Filters Bar -->
    <div class="filter-section reset-section">
        <button class="lagalpi-reset-filters-btn font-semibold">
            <i class="fa-solid fa-rotate-left"></i> <?php esc_html_e( 'Reset filtri', 'lagalpi-child' ); ?>
        </button>
    </div>
</div>
