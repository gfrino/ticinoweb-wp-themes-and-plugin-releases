<?php
/**
 * Custom front page template for lagAlpi child theme.
 * Renders the homepage layout using clean PHP/HTML/CSS without Elementor.
 *
 * @package lagalpi-child
 */

get_header();
?>

<!-- 1. Hero Slider Section -->
<section class="lagalpi-hero-section">
    <div class="hero-slider-container">
        <div class="hero-slides-wrapper">
            <!-- Slide 1 -->
            <div class="hero-slide active" style="background-image: url('<?php echo esc_url( lagalpi_uploads_url( '2023/05/2Z4A2802_1944x.webp' ) ); ?>');">
                <div class="slide-overlay"></div>
                <div class="slide-content">
                    <h1 class="slide-title"><?php esc_html_e( 'Regala lo spirito delle Alpi', 'lagalpi-child' ); ?></h1>
                    <p class="slide-subtitle"><?php esc_html_e( 'Perfetti per un\'idea regalo all\'insegna del gusto delle Alpi.', 'lagalpi-child' ); ?></p>
                    <a href="<?php echo esc_url( home_url( '/idee-regalo/cesti-regalo/' ) ); ?>" class="btn-hero-cta">
                        <?php esc_html_e( 'SCOPRI LE NOSTRE BOX DEGUSTAZIONE', 'lagalpi-child' ); ?>
                    </a>
                </div>
            </div>
            <!-- Slide 2 -->
            <div class="hero-slide" style="background-image: url('<?php echo esc_url( lagalpi_uploads_url( '2023/06/Produttore-slideshow-scaled.jpg' ) ); ?>');">
                <div class="slide-overlay"></div>
                <div class="slide-content">
                    <h1 class="slide-title"><?php esc_html_e( 'I produttori', 'lagalpi-child' ); ?></h1>
                    <p class="slide-subtitle"><?php esc_html_e( 'I veri artefici del gusto delle Alpi', 'lagalpi-child' ); ?></p>
                    <a href="<?php echo esc_url( home_url( '/produttori/' ) ); ?>" class="btn-hero-cta">
                        <?php esc_html_e( 'Scopri i nostri produttori', 'lagalpi-child' ); ?>
                    </a>
                </div>
            </div>
            <!-- Slide 3 -->
            <div class="hero-slide" style="background-image: url('<?php echo esc_url( lagalpi_uploads_url( '2023/05/aerial-view-doi-luang-chiang-dao-mountains-sunset-chiang-mai-thailand-scaled.jpg' ) ); ?>');">
                <div class="slide-overlay"></div>
                <div class="slide-content">
                    <h1 class="slide-title"><?php esc_html_e( 'Il vero gusto delle Alpi', 'lagalpi-child' ); ?></h1>
                    <p class="slide-subtitle"><?php esc_html_e( 'Eccellenza e passione', 'lagalpi-child' ); ?></p>
                    <a href="<?php echo esc_url( home_url( '/shop/' ) ); ?>" class="btn-hero-cta">
                        <?php esc_html_e( 'Scopri i nostri prodotti', 'lagalpi-child' ); ?>
                    </a>
                </div>
            </div>
        </div>
        <!-- Controls -->
        <button class="hero-slider-arrow prev-slide" aria-label="<?php esc_attr_e( 'Precedente', 'lagalpi-child' ); ?>">‹</button>
        <button class="hero-slider-arrow next-slide" aria-label="<?php esc_attr_e( 'Successiva', 'lagalpi-child' ); ?>">›</button>
        <!-- Dots -->
        <div class="hero-slider-dots">
            <span class="slider-dot active" data-slide="0"></span>
            <span class="slider-dot" data-slide="1"></span>
            <span class="slider-dot" data-slide="2"></span>
        </div>
    </div>
</section>

<!-- 2. Highlight Cards Section (Promo + Top Sellers) -->
<section class="lagalpi-highlight-cards-section top-overlap-section">
    <div class="lagalpi-container">
        <div class="highlight-cards-grid">
            <!-- Promo Banner (Left) -->
            <div class="promo-banner-card-new">
                <div class="promo-banner-image-new">
                    <img src="<?php echo esc_url( lagalpi_uploads_url( '2024/01/photo-7-copia.jpg' ) ); ?>" alt="<?php esc_attr_e( 'Offerte Lagalpi', 'lagalpi-child' ); ?>">
                </div>
                <div class="promo-banner-content-new">
                    <h3 class="banner-subtitle-new"><?php esc_html_e( 'Offerte Lagalpi', 'lagalpi-child' ); ?></h3>
                    <h2 class="banner-title-new"><?php esc_html_e( 'Non perdetevi il meglio delle Alpi!', 'lagalpi-child' ); ?></h2>
                    <a href="<?php echo esc_url( home_url( '/offerte/' ) ); ?>" class="btn-banner-new">
                        <?php esc_html_e( 'Scopri ora', 'lagalpi-child' ); ?>
                    </a>
                </div>
            </div>

            <!-- Top Sellers (Right) -->
            <div class="top-sellers-card woocommerce">
                <h2 class="top-sellers-title"><?php esc_html_e( 'I più venduti della settimana', 'lagalpi-child' ); ?></h2>
                
                <?php
                $best_sellers_query = new WP_Query( array(
                    'post_type'      => 'product',
                    'posts_per_page' => 3,
                    'tax_query'      => array(
                        array(
                            'taxonomy' => 'product_visibility',
                            'field'    => 'name',
                            'terms'    => 'featured',
                            'operator' => 'IN',
                        ),
                    ),
                ) );

                if ( $best_sellers_query->have_posts() ) :
                    woocommerce_product_loop_start();
                    while ( $best_sellers_query->have_posts() ) :
                        $best_sellers_query->the_post();
                        wc_get_template_part( 'content', 'product' );
                    endwhile;
                    woocommerce_product_loop_end();
                    wp_reset_postdata();
                else :
                    echo '<p class="text-center">' . esc_html__( 'Nessun prodotto in evidenza trovato.', 'lagalpi-child' ) . '</p>';
                endif;
                ?>
            </div>
        </div>
    </div>
</section>

<!-- 4. Text CTA Section -->
<section class="lagalpi-text-cta-section section-padding">
    <div class="lagalpi-container text-center narrow-container">
        <h2 class="text-cta-title"><?php esc_html_e( 'Le Alpi a portata di click', 'lagalpi-child' ); ?></h2>
        <div class="text-cta-desc">
            <p>
                <?php esc_html_e( 'lagAlpi è un e-commerce, ma non solo. Ci proponiamo di digitalizzare l’eccellenza e la passione enogastronomiche alpine suggerendo sapori e abbinamenti inesplorati, allargando i confini del gusto, ma avendo sempre ben presente la ricchezza di una tradizione secolare che, radicata nel territorio alpino, intendiamo proiettare nel futuro.', 'lagalpi-child' ); ?>
            </p>
        </div>
    </div>
</section>

<!-- 5. Categories Showcase Section -->
<section class="lagalpi-categories-showcase section-padding bg-light">
    <div class="lagalpi-container">
        <h2 class="section-title text-center"><?php esc_html_e( 'Sfoglia le nostre categorie', 'lagalpi-child' ); ?></h2>
        
        <div class="categories-grid-cards">
            <?php
            $target_cats = array( 'idee-regalo', 'elisir-leggendari-spiriti-alpini', 'dolci-e-leccornie-di-vetta', 'dalle-alpi-in-tavola' );
            foreach ( $target_cats as $slug ) :
                $cat_term = get_term_by( 'slug', $slug, 'product_cat' );
                if ( $cat_term && ! is_wp_error( $cat_term ) ) :
                    $thumbnail_id = get_term_meta( $cat_term->term_id, 'thumbnail_id', true );
                    $image_url = $thumbnail_id ? wp_get_attachment_url( $thumbnail_id ) : '';
                    if ( empty( $image_url ) ) {
                        $image_url = wc_placeholder_img_src();
                    }
                    ?>
                    <a href="<?php echo esc_url( get_term_link( $cat_term ) ); ?>" class="cat-card" style="background-image: url('<?php echo esc_url( $image_url ); ?>');">
                        <div class="cat-card-overlay"></div>
                        <div class="cat-card-content">
                            <h3 class="cat-card-title"><?php echo esc_html( $cat_term->name ); ?> (<?php echo $cat_term->count; ?>)</h3>
                            <span class="btn-cat-card">
                                <?php esc_html_e( 'Scopri la categoria', 'lagalpi-child' ); ?> >
                            </span>
                        </div>
                    </a>
                    <?php
                endif;
            endforeach;
            ?>
        </div>
    </div>
</section>

<!-- 6. New Products Section -->
<section class="lagalpi-featured-products section-padding woocommerce">
    <div class="lagalpi-container">
        <h2 class="new-products-title text-center"><?php esc_html_e( 'Nuove proposte e prodotti nuovi', 'lagalpi-child' ); ?></h2>
        
        <?php
        $latest_query = new WP_Query( array(
            'post_type'      => 'product',
            'posts_per_page' => 6,
            'orderby'        => 'date',
            'order'          => 'DESC',
        ) );

        if ( $latest_query->have_posts() ) :
            woocommerce_product_loop_start();
            while ( $latest_query->have_posts() ) :
                $latest_query->the_post();
                wc_get_template_part( 'content', 'product' );
            endwhile;
            woocommerce_product_loop_end();
            wp_reset_postdata();
        else :
            echo '<p class="text-center">' . esc_html__( 'Nessun nuovo prodotto trovato.', 'lagalpi-child' ) . '</p>';
        endif;
        ?>
    </div>
</section>

<!-- 7. Split Highlight Section (Producer Highlight) -->
<section class="lagalpi-split-highlight-section section-padding bg-light">
    <div class="lagalpi-container split-grid">
        <div class="split-text-column">
            <span class="split-subtitle"><?php esc_html_e( 'Eccellenza e passione', 'lagalpi-child' ); ?></span>
            <h2 class="split-title"><?php esc_html_e( 'Tradizione sì, ma nel futuro', 'lagalpi-child' ); ?></h2>
            <div class="split-description font-light">
                <p>
                    <?php esc_html_e( 'Proprio il produttore ha un ruolo centrale in questo processo: è grazie a lui che la tradizione si è potuta mantenere intatta, arricchendosi delle nuove tecnologie a maggiore tutela di tutta la filiera produttiva. lagAlpi è consapevole di quanto sia importante il suo ruolo nella produzione e lo supporta attivamente e concretamente affinché possa continuare a svolgere il proprio lavoro - una grande passione - a beneficio di tutti gli alchimisti del gusto.', 'lagalpi-child' ); ?>
                </p>
            </div>
            <a href="<?php echo esc_url( home_url( '/produttori/' ) ); ?>" class="btn-split-cta">
                <?php esc_html_e( 'Scopri i nostri produttori', 'lagalpi-child' ); ?>
            </a>
        </div>
        <div class="split-image-column">
            <img src="<?php echo esc_url( lagalpi_uploads_url( '2023/05/woman-with-horse-in-corral_1080x.webp' ) ); ?>" alt="<?php esc_attr_e( 'Tradizione e futuro', 'lagalpi-child' ); ?>" class="split-image">
        </div>
    </div>
</section>

<!-- 8. Box Degustazione Products -->
<section class="lagalpi-featured-products section-padding">
    <div class="lagalpi-container">
        <div class="box-degustazione-banner" style="background-image: url('<?php echo esc_url( lagalpi_uploads_url( '2023/05/aerial-view-doi-luang-chiang-dao-mountains-sunset-chiang-mai-thailand-scaled.jpg' ) ); ?>');">
            <div class="box-degustazione-banner-overlay"></div>
            <div class="box-degustazione-banner-content">
                <div class="box-degustazione-banner-text">
                    <h2 class="box-degustazione-banner-title"><?php esc_html_e( 'BOX DEGUSTAZIONE', 'lagalpi-child' ); ?></h2>
                    <p class="box-degustazione-banner-subtitle">
                        <?php esc_html_e( 'Lasciatevi accompagnare alla scoperta di tradizioni e sapori genuini Alpini.', 'lagalpi-child' ); ?>
                    </p>
                </div>
                <?php $box_term = get_term_by('slug', 'box-degustazione', 'product_cat'); ?>
                <?php if ( $box_term && ! is_wp_error( $box_term ) ) : ?>
                <a href="<?php echo esc_url( get_term_link( $box_term ) ); ?>" class="btn-box-degustazione">
                    <?php esc_html_e( 'Scopri ora', 'lagalpi-child' ); ?>
                </a>
                <?php endif; ?>
            </div>
        </div>
        

    </div>
</section>

<!-- 8.5. Google Reviews Placeholder -->
<?php
// Real Google reviews rendered as a card carousel. Data comes from the parent
// theme's Google Places integration (ticinoweb_get_google_reviews), cached
// under the theme settings and refreshed weekly via WP-Cron (inc/reviews-cron.php).
// Markup + styles are namespaced .lagalpi-reviews-* so the look is fully owned
// by the child theme. The whole section only renders when real reviews exist —
// otherwise a sync reminder is shown to logged-in admins only.
$lagalpi_min_rating   = (int) get_option( 'ticinoweb_google_reviews_min_rating', 4 );
$lagalpi_reviews      = function_exists( 'ticinoweb_get_google_reviews' ) ? ticinoweb_get_google_reviews( 12, $lagalpi_min_rating ) : array();
$lagalpi_avg_rating   = (float) get_option( 'ticinoweb_google_reviews_rating', 0 );
$lagalpi_total_count  = (int) get_option( 'ticinoweb_google_reviews_count', 0 );
$lagalpi_business_url = get_option( 'ticinoweb_google_business_link' );
$lagalpi_has_reviews  = ! empty( $lagalpi_reviews );
?>
<?php if ( $lagalpi_has_reviews || current_user_can( 'manage_options' ) ) : ?>
<section class="lagalpi-google-reviews section-padding">
    <div class="lagalpi-container">
        <?php if ( $lagalpi_has_reviews ) : ?>
            <div class="lagalpi-reviews">
                <div class="lagalpi-reviews-header">
                    <div class="lagalpi-reviews-brand">
                        <i class="fab fa-google" aria-hidden="true"></i>
                        <span><?php esc_html_e( 'Recensioni Google', 'lagalpi-child' ); ?></span>
                    </div>
                    <?php if ( $lagalpi_avg_rating > 0 ) : ?>
                    <div class="lagalpi-reviews-summary">
                        <span class="lagalpi-reviews-score"><?php echo esc_html( number_format( $lagalpi_avg_rating, 1 ) ); ?></span>
                        <span class="lagalpi-reviews-stars" aria-hidden="true">
                            <?php for ( $i = 1; $i <= 5; $i++ ) : ?>
                                <i class="<?php echo ( $i <= round( $lagalpi_avg_rating ) ) ? 'fas' : 'far'; ?> fa-star"></i>
                            <?php endfor; ?>
                        </span>
                        <?php if ( $lagalpi_total_count > 0 ) : ?>
                        <span class="lagalpi-reviews-count"><?php printf( esc_html__( 'su %d recensioni', 'lagalpi-child' ), $lagalpi_total_count ); ?></span>
                        <?php endif; ?>
                    </div>
                    <?php endif; ?>
                </div>

                <div class="lagalpi-reviews-carousel">
                    <button type="button" class="lagalpi-reviews-nav prev" aria-label="<?php esc_attr_e( 'Recensioni precedenti', 'lagalpi-child' ); ?>">
                        <i class="fas fa-chevron-left" aria-hidden="true"></i>
                    </button>
                    <div class="lagalpi-reviews-viewport">
                    <div class="lagalpi-reviews-track">
                        <?php
                        foreach ( $lagalpi_reviews as $r ) :
                            $r_rating = isset( $r['rating'] ) ? (int) $r['rating'] : 5;
                            $r_name   = isset( $r['author_name'] ) ? $r['author_name'] : '';
                            $r_photo  = isset( $r['profile_photo_url'] ) ? $r['profile_photo_url'] : '';
                            $r_when   = isset( $r['relative_time_description'] ) ? $r['relative_time_description'] : '';
                            $r_text   = isset( $r['text'] ) ? $r['text'] : '';
                            ?>
                        <article class="lagalpi-review-card">
                            <div class="lagalpi-review-top">
                                <span class="lagalpi-review-stars" aria-label="<?php echo esc_attr( sprintf( __( 'Valutazione: %d su 5', 'lagalpi-child' ), $r_rating ) ); ?>">
                                    <?php for ( $i = 1; $i <= 5; $i++ ) : ?>
                                        <i class="<?php echo ( $i <= $r_rating ) ? 'fas' : 'far'; ?> fa-star" aria-hidden="true"></i>
                                    <?php endfor; ?>
                                </span>
                                <?php if ( $r_when ) : ?>
                                <span class="lagalpi-review-date"><?php echo esc_html( $r_when ); ?></span>
                                <?php endif; ?>
                            </div>
                            <?php if ( $r_text ) : ?>
                            <div class="lagalpi-review-text"><p><?php echo nl2br( esc_html( $r_text ) ); ?></p></div>
                            <?php endif; ?>
                            <div class="lagalpi-review-author">
                                <?php if ( $r_photo ) : ?>
                                    <img class="lagalpi-review-avatar" src="<?php echo esc_url( $r_photo ); ?>" alt="<?php echo esc_attr( $r_name ); ?>" referrerpolicy="no-referrer" width="48" height="48" data-initial="<?php echo esc_attr( mb_strtoupper( mb_substr( $r_name, 0, 1 ) ) ); ?>">
                                <?php else : ?>
                                    <span class="lagalpi-review-avatar lagalpi-review-avatar--fallback" aria-hidden="true"><?php echo esc_html( mb_strtoupper( mb_substr( $r_name, 0, 1 ) ) ); ?></span>
                                <?php endif; ?>
                                <span class="lagalpi-review-meta">
                                    <span class="lagalpi-review-name"><?php echo esc_html( $r_name ); ?></span>
                                    <span class="lagalpi-review-source"><i class="fab fa-google" aria-hidden="true"></i> Google</span>
                                </span>
                            </div>
                        </article>
                        <?php endforeach; ?>
                    </div>
                    </div>
                    <button type="button" class="lagalpi-reviews-nav next" aria-label="<?php esc_attr_e( 'Recensioni successive', 'lagalpi-child' ); ?>">
                        <i class="fas fa-chevron-right" aria-hidden="true"></i>
                    </button>
                </div>

                <?php if ( $lagalpi_business_url ) : ?>
                <div class="lagalpi-reviews-footer">
                    <a href="<?php echo esc_url( $lagalpi_business_url ); ?>" class="lagalpi-reviews-cta" target="_blank" rel="nofollow noopener"><?php esc_html_e( 'Lascia una recensione', 'lagalpi-child' ); ?></a>
                </div>
                <?php endif; ?>
            </div>
        <?php else : ?>
            <div class="reviews-placeholder text-center" style="padding: 40px; border: 2px dashed #ccc; border-radius: 8px; margin: 20px 0;">
                <p style="color: #888; margin-bottom: 0; font-size: 16px;"><em>Recensioni Google non ancora sincronizzate (avviso visibile solo agli amministratori). <br>Vai in <strong>Impostazioni tema &rarr; Recensioni Google</strong> e avvia la sincronizzazione: appariranno automaticamente a tutti i visitatori.</em></p>
            </div>
        <?php endif; ?>
    </div>
</section>
<?php endif; ?>

<!-- 8.6. Challenge Parallax Section -->
<section class="chisiamo-parallax-section front-page-parallax" style="background-image: url('<?php echo esc_url( lagalpi_uploads_url( '2023/05/apuane-alpi-snowy-mountains-in-winter-garfagnana-tuscany-italy-.jpg' ) ); ?>'); margin: 40px 0;">
    <div class="parallax-overlay"></div>
    <div class="parallax-content lagalpi-container" style="text-align: left; padding-bottom: 60px;">
        <span class="parallax-subtitle"><?php esc_html_e( 'La sfida', 'lagalpi-child' ); ?></span>
        <h2 class="parallax-title"><?php esc_html_e( 'Gusto sconfinato', 'lagalpi-child' ); ?></h2>
        <p><?php esc_html_e( 'lagAlpi sa che oggi è in gioco una sfida: abbattere le barriere geografiche che separano il sapore delle tradizioni dal mondo là fuori, escludendo alcuni dal piacere che in esse è racchiuso.', 'lagalpi-child' ); ?></p>
    </div>
</section>

<!-- 9. Stories / Blog Section -->
<section class="lagalpi-stories-section section-padding bg-light">
    <div class="lagalpi-container">
        <h2 class="new-products-title text-center"><?php esc_html_e( 'Storie di cima e di valle', 'lagalpi-child' ); ?></h2>
        
        <div class="stories-grid-cards">
            <?php
            $stories_query = new WP_Query( array(
                'post_type'      => 'post',
                'posts_per_page' => 3,
                'post_status'    => 'publish',
            ) );

            if ( $stories_query->have_posts() ) :
                while ( $stories_query->have_posts() ) :
                    $stories_query->the_post();
                    ?>
                    <article class="story-card-new">
                        <?php if ( has_post_thumbnail() ) : ?>
                            <div class="story-thumbnail-new">
                                <a href="<?php the_permalink(); ?>">
                                    <?php the_post_thumbnail( 'medium_large' ); ?>
                                </a>
                                <?php
                                $categories = get_the_category();
                                if ( ! empty( $categories ) ) {
                                    echo '<span class="story-cat-badge">' . esc_html( mb_strtoupper( $categories[0]->name, 'UTF-8' ) ) . '</span>';
                                }
                                ?>
                            </div>
                        <?php endif; ?>
                        <div class="story-content-new">
                            <h3 class="story-card-title-new"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                            <div class="story-excerpt-new font-light">
                                <?php echo wp_trim_words( get_the_excerpt(), 25 ); ?>
                            </div>
                            <a href="<?php the_permalink(); ?>" class="story-read-more-new">
                                <?php esc_html_e( 'LEGGI TUTTO »', 'lagalpi-child' ); ?>
                            </a>
                        </div>
                    </article>
                    <?php
                endwhile;
                wp_reset_postdata();
            else :
                echo '<p class="text-center">' . esc_html__( 'Nessun articolo trovato.', 'lagalpi-child' ) . '</p>';
            endif;
            ?>
        </div>
        <div class="text-center" style="margin-top: 50px; margin-bottom: 50px;">
            <a href="<?php echo esc_url( get_permalink( get_option( 'page_for_posts' ) ) ); ?>" class="btn-visualizza-tutto">
                <?php esc_html_e( 'VISUALIZZA TUTTO', 'lagalpi-child' ); ?>
            </a>
        </div>
    </div>
</section>

<!-- Include simple Javascript inline for the Hero Slider -->
<script type="text/javascript">
(function() {
    document.addEventListener('DOMContentLoaded', function() {
        var slides = document.querySelectorAll('.hero-slide');
        var dots = document.querySelectorAll('.slider-dot');
        var prevBtn = document.querySelector('.prev-slide');
        var nextBtn = document.querySelector('.next-slide');
        var currentSlide = 0;
        var slideInterval = setInterval(nextSlide, 6000); // 6s auto rotate

        function goToSlide(n) {
            slides[currentSlide].classList.remove('active');
            dots[currentSlide].classList.remove('active');
            currentSlide = (n + slides.length) % slides.length;
            slides[currentSlide].classList.add('active');
            dots[currentSlide].classList.add('active');
        }

        function nextSlide() {
            goToSlide(currentSlide + 1);
        }

        function prevSlide() {
            goToSlide(currentSlide - 1);
        }

        if (prevBtn && nextBtn) {
            prevBtn.addEventListener('click', function() {
                prevSlide();
                resetTimer();
            });
            nextBtn.addEventListener('click', function() {
                nextSlide();
                resetTimer();
            });
        }

        dots.forEach(function(dot) {
            dot.addEventListener('click', function() {
                var index = parseInt(dot.getAttribute('data-slide'));
                goToSlide(index);
                resetTimer();
            });
        });

        function resetTimer() {
            clearInterval(slideInterval);
            slideInterval = setInterval(nextSlide, 6000);
        }
    });
})();
</script>
<?php
get_footer();
