/**
 * Little Inka: menu da telefono (foglio a tutto schermo) e barra fissa «Ordina online» della home.
 * Niente jQuery; i testi arrivano da window.littleInka (functions.php).
 */
(function () {
  'use strict';
  var i18n = window.littleInka || {};

  /* Menu da telefono: il pulsante apre il foglio, Escape lo chiude, lo scroll del body resta fermo. */
  var header = document.querySelector('.li-header');
  var toggle = header ? header.querySelector('.li-header__toggle') : null;
  var sheet = document.getElementById('li-sheet');
  var desktop = window.matchMedia('(min-width: 1024px)');

  function setOpen(open) {
    if (!toggle || !header) return;
    header.classList.toggle('is-open', open);
    document.body.classList.toggle('li-nav-open', open);
    toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
    toggle.setAttribute('aria-label', open ? (i18n.menuClose || 'Chiudi il menu') : (i18n.menuOpen || 'Apri il menu'));
  }

  if (toggle && sheet) {
    toggle.addEventListener('click', function () {
      setOpen(toggle.getAttribute('aria-expanded') !== 'true');
    });
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && header.classList.contains('is-open')) {
        setOpen(false);
        toggle.focus();
      }
    });
    // Un tocco su una voce dello stesso foglio (ancore della home) chiude il foglio.
    sheet.addEventListener('click', function (e) {
      if (e.target.closest('a') && header.classList.contains('is-open')) setOpen(false);
    });
    // Se la finestra si allarga con il foglio aperto, il foglio si chiude: la barra torna normale.
    var onDesktop = function (mq) { if (mq.matches) setOpen(false); };
    if (typeof desktop.addEventListener === 'function') desktop.addEventListener('change', onDesktop);
    else if (typeof desktop.addListener === 'function') desktop.addListener(onDesktop);
  }

  /* Hero: pulsante per fermare e far ripartire le foto che scorrono. */
  var reel = document.querySelector('[data-li-reel]');
  var pause = reel ? reel.querySelector('.li-hero__pause') : null;
  if (reel && pause) {
    pause.addEventListener('click', function () {
      var paused = reel.classList.toggle('is-paused');
      pause.setAttribute('aria-pressed', paused ? 'true' : 'false');
      pause.setAttribute('aria-label', pause.getAttribute(paused ? 'data-label-play' : 'data-label-pause'));
    });
  }

  /* Barra fissa del telefono: sparisce finché il bottone dell'hero è in vista (nessuna animazione). */
  var bar = document.querySelector('.li-actionbar');
  var cta = document.querySelector('[data-li-hero-cta]');
  if (bar && cta && 'IntersectionObserver' in window) {
    new IntersectionObserver(function (entries) {
      bar.classList.toggle('is-hidden', entries[0].isIntersecting);
    }, { threshold: 0.5 }).observe(cta);
  }
})();

/* Pagine ripresentate dal browser con «Indietro» / «Avanti» (bfcache): sono copie vecchie.
   Carrello e cassa si ricaricano; nelle altre pagine si aggiornano numero del carrello e pulsante «Vai al carrello»,
   altrimenti mostrerebbero un carrello diverso da quello vero. */
(function () {
  window.addEventListener('pageshow', function (event) {
    var nav = window.performance && performance.getEntriesByType ? performance.getEntriesByType('navigation')[0] : null;
    if (!event.persisted && !(nav && nav.type === 'back_forward')) {
      return;
    }
    var body = document.body;
    if (body.classList.contains('woocommerce-cart') || body.classList.contains('woocommerce-checkout')) {
      window.location.reload();
      return;
    }
    var url = window.littleInka && window.littleInka.fragments;
    if (!url || !window.fetch) {
      return;
    }
    fetch(url, { method: 'POST', credentials: 'same-origin' })
      .then(function (response) { return response.json(); })
      .then(function (data) {
        if (!data || !data.fragments) {
          return;
        }
        Object.keys(data.fragments).forEach(function (selector) {
          document.querySelectorAll(selector).forEach(function (el) {
            var wrap = document.createElement('div');
            wrap.innerHTML = data.fragments[selector];
            if (wrap.firstElementChild) {
              el.replaceWith(wrap.firstElementChild);
            }
          });
        });
      })
      .catch(function () {});
  });
})();
