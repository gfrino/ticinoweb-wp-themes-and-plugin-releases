<?php
/**
 * Language switcher for any theme or page builder: shortcode
 * [tw_language_switcher] (Elementor: «Shortcode» widget), PHP function
 * twtr_language_switcher() and the same markup everywhere.
 *
 * Flags are bundled SVG files (assets/flags/<code>.svg) shown through <img>:
 * they look the same on every system (emoji flags do not exist on Windows,
 * which shows "DE" / "FR" instead) and never clash with theme CSS or ids.
 *
 * @package tw-translate-plus
 */

if (!defined('ABSPATH')) {
    exit;
}

class Twtr_Switcher {

    const SHORTCODE = 'tw_language_switcher';

    /** Flag shown for each language (filter twtr_flag_code to change one, e.g. en → us). */
    private static $flag_of = array(
        'it' => 'it', 'en' => 'en', 'de' => 'de', 'fr' => 'fr', 'es' => 'es', 'pt' => 'pt',
        'nl' => 'nl', 'pl' => 'pl', 'ru' => 'ru', 'uk' => 'uk', 'cs' => 'cs', 'ro' => 'ro',
        'hu' => 'hu', 'el' => 'el', 'hr' => 'hr', 'sq' => 'sq', 'sv' => 'sv', 'da' => 'da',
        'tr' => 'tr', 'zh' => 'zh', 'ja' => 'ja', 'ar' => 'ar',
    );

    public static function init() {
        add_shortcode(self::SHORTCODE, array(__CLASS__, 'shortcode'));
    }

    /** @return string[] Flag files available (for the settings page). */
    public static function flag_codes() {
        $codes = array();
        foreach ((array) glob(TWTR_DIR . 'assets/flags/*.svg') as $file) {
            $codes[] = basename($file, '.svg');
        }
        return $codes;
    }

    /**
     * @param string $lang      Language slug.
     * @param array  $overrides lang => flag code from the shortcode's flags="".
     * @return string Flag image URL, '' when none.
     */
    public static function flag_url($lang, $overrides = array()) {
        $code = isset($overrides[$lang]) ? $overrides[$lang] : (isset(self::$flag_of[$lang]) ? self::$flag_of[$lang] : $lang);
        $code = sanitize_key((string) apply_filters('twtr_flag_code', $code, $lang));
        if ($code === '' || !file_exists(TWTR_DIR . 'assets/flags/' . $code . '.svg')) {
            return '';
        }
        return TWTR_URL . 'assets/flags/' . $code . '.svg';
    }

    /**
     * Shortcode handler.
     *
     * Attributes:
     * - style:   flags (default) | flags-names | names | codes | dropdown
     * - current: show (default) | hide — hide the language being viewed
     * - size:    flag height in px (default 18)
     * - flags:   per-language flag overrides, e.g. "en:us,it:ch"
     * - class:   extra CSS class
     *
     * @param array|string $atts
     * @return string
     */
    public static function shortcode($atts) {
        $atts = shortcode_atts(array(
            'style'   => 'flags',
            'current' => 'show',
            'size'    => 18,
            'flags'   => '',
            'class'   => '',
        ), (array) $atts, self::SHORTCODE);
        return self::render($atts);
    }

    /**
     * @param array $atts See shortcode().
     * @return string HTML ('' when only one language is published).
     */
    public static function render($atts) {
        $languages = twtr_get_languages(true);
        if (count($languages) < 2) {
            return '';
        }
        $style = in_array($atts['style'], array('flags', 'flags-names', 'names', 'codes', 'dropdown'), true) ? $atts['style'] : 'flags';
        $size  = max(10, min(64, (int) $atts['size']));
        $over  = array();
        foreach (array_filter(array_map('trim', explode(',', (string) $atts['flags']))) as $pair) {
            $parts = array_map('sanitize_key', explode(':', $pair, 2));
            if (count($parts) === 2 && $parts[0] !== '' && $parts[1] !== '') {
                $over[$parts[0]] = $parts[1];
            }
        }
        $hide_current = $atts['current'] === 'hide';
        $classes      = trim('twtr-ls twtr-ls-' . $style . ' ' . implode(' ', array_map('sanitize_html_class', preg_split('/\s+/', (string) $atts['class']))));

        $items   = array();
        $current = null;
        foreach ($languages as $lang) {
            if (!empty($lang['is_current'])) {
                $current = $lang;
                if ($hide_current && $style !== 'dropdown') {
                    continue;
                }
            }
            $items[] = $lang;
        }

        $html = self::style_once();
        if ($style === 'dropdown') {
            // <details>: a real dropdown with no JavaScript, keyboard friendly.
            $html .= '<details class="' . esc_attr($classes) . ' notranslate" translate="no"><summary>'
                . ($current ? self::item_content($current, 'flags-names', $size, $over) : '')
                . '</summary><ul>';
            foreach ($items as $lang) {
                if (!empty($lang['is_current'])) {
                    continue;
                }
                $html .= '<li>' . self::link($lang, 'flags-names', $size, $over) . '</li>';
            }
            return $html . '</ul></details>';
        }

        // Translated like any site string (the plugin's own .mo files do not
        // follow the visitor's language).
        $label = Twtr_Resolver::translate('Lingua', 'twtr:switcher:label');
        $html .= '<nav class="' . esc_attr($classes) . ' notranslate" translate="no" aria-label="' . esc_attr($label) . '"><ul>';
        foreach ($items as $lang) {
            $html .= '<li>' . self::link($lang, $style, $size, $over) . '</li>';
        }
        return $html . '</ul></nav>';
    }

    private static function link($lang, $style, $size, $over) {
        $code = str_replace('_', '-', $lang['locale']);
        return sprintf(
            '<a href="%1$s" hreflang="%2$s" lang="%2$s" title="%3$s" class="twtr-ls-link%4$s"%5$s>%6$s</a>',
            esc_url($lang['url']),
            esc_attr($code),
            esc_attr($lang['label']),
            !empty($lang['is_current']) ? ' is-current' : '',
            !empty($lang['is_current']) ? ' aria-current="page"' : '',
            self::item_content($lang, $style, $size, $over)
        );
    }

    private static function item_content($lang, $style, $size, $over) {
        $out  = '';
        $flag = self::flag_url($lang['slug'], $over);
        if (in_array($style, array('flags', 'flags-names'), true) && $flag !== '') {
            $out .= sprintf(
                '<img class="twtr-ls-flag" src="%s" alt="" width="%d" height="%d" loading="lazy" decoding="async" />',
                esc_url($flag),
                (int) round($size * 1.5),
                (int) $size
            );
        }
        if ($style === 'flags' || ($style === 'flags-names' && $flag === '')) {
            // Name for screen readers (and as text when no flag file exists).
            $out .= $flag !== '' ? '<span class="twtr-ls-sr">' . esc_html($lang['label']) . '</span>' : '<span class="twtr-ls-name">' . esc_html(strtoupper($lang['slug'])) . '</span>';
        } elseif ($style === 'flags-names' || $style === 'names') {
            $out .= '<span class="twtr-ls-name">' . esc_html($lang['label']) . '</span>';
        } elseif ($style === 'codes') {
            $out .= '<span class="twtr-ls-name">' . esc_html(strtoupper($lang['slug'])) . '</span>';
        }
        return $out;
    }

    /** Minimal CSS, printed once, easy to override from the theme. */
    private static function style_once() {
        static $done = false;
        if ($done) {
            return '';
        }
        $done = true;
        return '<style id="twtr-ls-css">'
            . '.twtr-ls ul{list-style:none;margin:0;padding:0;display:flex;flex-wrap:wrap;gap:.6em;align-items:center}'
            . '.twtr-ls li{margin:0;padding:0}'
            . '.twtr-ls-link{display:inline-flex;align-items:center;gap:.4em;text-decoration:none;line-height:1}'
            . '.twtr-ls-flag{display:block;border-radius:2px;box-shadow:0 0 0 1px rgba(0,0,0,.12);object-fit:cover;max-width:none}'
            . '.twtr-ls-link.is-current .twtr-ls-flag{outline:2px solid currentColor;outline-offset:2px}'
            . '.twtr-ls-link.is-current{font-weight:600}'
            . '.twtr-ls-sr{position:absolute!important;width:1px;height:1px;overflow:hidden;clip:rect(1px,1px,1px,1px);white-space:nowrap}'
            . 'details.twtr-ls{position:relative;display:inline-block}'
            . 'details.twtr-ls>summary{list-style:none;cursor:pointer;display:inline-flex;align-items:center;gap:.4em}'
            . 'details.twtr-ls>summary::-webkit-details-marker{display:none}'
            . 'details.twtr-ls>summary .twtr-ls-flag{outline:0}'
            . 'details.twtr-ls>summary::after{content:"";border:solid currentColor;border-width:0 2px 2px 0;padding:2px;transform:rotate(45deg);margin-left:.2em}'
            . 'details.twtr-ls ul{position:absolute;z-index:9999;left:0;top:calc(100% + 6px);flex-direction:column;align-items:stretch;gap:0;background:#fff;color:#1d2327;border-radius:6px;box-shadow:0 6px 24px rgba(0,0,0,.15);padding:.4em 0;min-width:10em}'
            . 'details.twtr-ls ul a{display:flex;padding:.45em .9em;color:inherit}details.twtr-ls ul a:hover{background:#f0f0f1}'
            . '</style>';
    }
}

/**
 * Print or return the language switcher from PHP (same options as the
 * shortcode).
 *
 * @param array $args style, current, size, flags, class.
 * @param bool  $echo
 * @return string
 */
function twtr_language_switcher($args = array(), $echo = true) {
    $html = Twtr_Switcher::render(wp_parse_args($args, array('style' => 'flags', 'current' => 'show', 'size' => 18, 'flags' => '', 'class' => '')));
    if ($echo) {
        echo $html; // phpcs:ignore WordPress.Security.EscapeOutput -- escaped in render().
    }
    return $html;
}
