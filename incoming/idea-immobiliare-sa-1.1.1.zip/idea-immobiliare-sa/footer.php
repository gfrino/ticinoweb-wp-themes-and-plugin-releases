<?php
/**
 * Footer: categorie, recapiti, link utili.
 *
 * @package Idea_Immobiliare_SA
 */
$contact = idea_immo_contact();
$cats = get_terms(array('taxonomy' => 'categoria_immobile', 'hide_empty' => true, 'number' => 8));
$cookie_url = (string) get_option('tw_privacy_policy_url', '');
if ($cookie_url === '' && function_exists('get_privacy_policy_url')) {
	$cookie_url = get_privacy_policy_url();
}
?>
<footer class="idea-footer">
	<div class="idea-container idea-footer__grid">
		<div class="idea-footer__col">
			<img class="idea-footer__logo" src="<?php echo esc_url(idea_immo_logo_url()); ?>" alt="<?php echo esc_attr(get_bloginfo('name')); ?>" width="123" height="56" loading="lazy">
			<?php if (get_bloginfo('description') !== '') : ?><p><?php bloginfo('description'); ?></p><?php endif; ?>
		</div>
		<?php if ($cats && !is_wp_error($cats)) : ?>
		<div class="idea-footer__col">
			<h2><?php esc_html_e('Immobili', 'idea-immobiliare-sa'); ?></h2>
			<ul>
				<?php foreach ($cats as $cat) : ?>
					<li><a href="<?php echo esc_url(get_term_link($cat)); ?>"><?php echo esc_html($cat->name); ?></a></li>
				<?php endforeach; ?>
			</ul>
		</div>
		<?php endif; ?>
		<div class="idea-footer__col">
			<h2><?php esc_html_e('Contatti', 'idea-immobiliare-sa'); ?></h2>
			<address>
				<?php if ($contact['address'] !== '') : ?><?php echo nl2br(esc_html($contact['address'])); ?><br><?php endif; ?>
				<?php if ($contact['phone'] !== '') : ?><a href="<?php echo esc_attr(idea_immo_tel_href($contact['phone'])); ?>"><?php echo esc_html($contact['phone']); ?></a><br><?php endif; ?>
				<?php if ($contact['email'] !== '') : ?><a href="mailto:<?php echo esc_attr($contact['email']); ?>"><?php echo esc_html($contact['email']); ?></a><?php endif; ?>
			</address>
		</div>
	</div>
	<div class="idea-footer__bottom">
		<div class="idea-container">
			<span>&copy; <?php echo esc_html(wp_date('Y')); ?> <?php bloginfo('name'); ?></span>
			<span class="idea-footer__links">
				<?php if ($cookie_url !== '') : ?><a href="<?php echo esc_url($cookie_url); ?>"><?php esc_html_e('Privacy e cookie', 'idea-immobiliare-sa'); ?></a><?php endif; ?>
				<?php // Il link porta sempre al login mascherato del parent (/tw-login), mai a wp-admin. ?>
				<a href="<?php echo esc_url(wp_login_url()); ?>" rel="nofollow"><?php esc_html_e('Area riservata', 'idea-immobiliare-sa'); ?></a>
			</span>
		</div>
	</div>
</footer>
<?php wp_footer(); ?>
</body>
</html>
