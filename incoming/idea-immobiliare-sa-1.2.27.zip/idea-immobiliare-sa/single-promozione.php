<?php
/**
 * Scheda di una promozione immobiliare: testata a tutta larghezza con la foto di copertina,
 * testo a sinistra e, a destra, richiesta di informazioni sempre a portata di mano.
 *
 * @package Idea_Immobiliare_SA
 */
get_header();
while (have_posts()) : the_post();
	$has_thumb = has_post_thumbnail();
	$contact   = idea_immo_contact();
?>
<main id="main" class="az az-promo">
	<header class="az-cover<?php echo $has_thumb ? ' has-photo' : ''; ?>">
		<?php if ($has_thumb) : the_post_thumbnail('full', array('alt' => '', 'loading' => 'eager', 'decoding' => 'async', 'class' => 'az-cover__img')); endif; ?>
		<div class="az-cover__shade"></div>
		<div class="idea-container az-cover__inner">
			<?php echo ticinoweb_get_breadcrumbs(); // phpcs:ignore WordPress.Security.EscapeOutput ?>
			<span class="az-hero__lead"><?php esc_html_e('Promozione immobiliare', 'idea-immobiliare-sa'); ?></span>
			<h1><?php the_title(); ?></h1>
		</div>
	</header>

	<section class="idea-section az-body">
		<div class="idea-container az-promo__grid">
			<article class="az-card az-promo__text az-prose"><?php the_content(); ?></article>
			<aside class="az-card az-promo__side">
				<h2><?php esc_html_e('Vuoi saperne di più?', 'idea-immobiliare-sa'); ?></h2>
				<?php if ($contact['phone'] !== '') : ?><p><?php esc_html_e('Chiamaci:', 'idea-immobiliare-sa'); ?> <a class="az-promo__phone" href="<?php echo esc_url(idea_immo_tel_href($contact['phone'])); ?>"><?php echo esc_html($contact['phone']); ?></a></p><?php endif; ?>
				<?php echo idea_immo_contact_form(get_the_title()); // phpcs:ignore WordPress.Security.EscapeOutput ?>
			</aside>
		</div>
		<div class="idea-container az-promo__back"><a href="<?php echo esc_url(get_post_type_archive_link('promozione')); ?>">← <?php esc_html_e('Tutte le promozioni', 'idea-immobiliare-sa'); ?></a></div>
	</section>
</main>
<?php endwhile;
get_footer();
