<?php
/**
 * Pagine interne: fascia con il titolo e contenuto su scheda bianca.
 *
 * @package liceo-diocesano-child
 */
get_header();
while ( have_posts() ) :
    the_post();
    $parent_id = wp_get_post_parent_id( get_the_ID() );
    liceo_diocesano_page_hero( get_the_title(), $parent_id ? get_the_title( $parent_id ) : get_bloginfo( 'name' ) );
    ?>
    <main class="container ld-page">
        <article <?php post_class( 'default-article' ); ?>>
            <div class="entry-content"><?php the_content(); ?></div>
        </article>
        <?php
        if ( 'articoli' === get_post_field( 'post_name' ) ) {
            $paged = max( 1, (int) get_query_var( 'paged' ), (int) get_query_var( 'page' ) );
            $q     = new WP_Query( array( 'post_type' => 'post', 'post_status' => 'publish', 'posts_per_page' => 12, 'paged' => $paged ) );
            echo '<div class="ld-news ld-news--page">';
            liceo_diocesano_posts_grid( $q );
            echo '<nav class="ld-pagination">' . paginate_links( array( 'total' => $q->max_num_pages, 'current' => $paged, 'format' => '?paged=%#%' ) ) . '</nav></div>'; // phpcs:ignore WordPress.Security.EscapeOutput
        }
        ?>
    </main>
    <?php
endwhile;
get_footer();
