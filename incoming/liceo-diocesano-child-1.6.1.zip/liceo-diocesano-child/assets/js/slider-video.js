( function () {
    var url = ( window.liceoHero || {} ).video;
    var slider = document.querySelector( '.hero-slider' );
    var img = slider && slider.querySelector( '.slide .slide-image' );
    if ( ! url || ! img ) {
        return;
    }

    // Resta la foto con movimento ridotto, risparmio dati attivo o rete lenta.
    var conn = navigator.connection || {};
    var slow = conn.saveData || /(^|-)2g$|3g/.test( conn.effectiveType || '' );
    var still = window.matchMedia && window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches;
    if ( slow || still ) {
        return;
    }

    var FADE = 1.0; // secondi di dissolvenza incrociata tra la fine e l'inizio del video

    function make() {
        var v = document.createElement( 'video' );
        v.className = 'slide-image slide-video';
        v.muted = true;
        v.playsInline = true;
        v.setAttribute( 'playsinline', '' );
        v.setAttribute( 'muted', '' );
        v.setAttribute( 'aria-hidden', 'true' );
        v.disablePictureInPicture = true;
        v.preload = 'auto';
        v.src = url;
        v.style.opacity = '0';
        return v;
    }

    function start() {
        var a = make();
        var b = make();
        a.poster = img.currentSrc || img.src;
        img.parentNode.insertBefore( a, img.nextSibling );
        img.parentNode.insertBefore( b, a.nextSibling );

        var cur = a;
        var nxt = b;
        var crossing = false;
        var visible = true;

        function play( v ) {
            var p = v.play();
            if ( p && p.catch ) {
                p.catch( function () {} ); // se il browser blocca l'avvio resta la foto
            }
        }

        // Il loop è una dissolvenza: poco prima della fine parte la seconda copia e la prima sfuma.
        function watch( v ) {
            v.addEventListener( 'timeupdate', function () {
                if ( v !== cur || crossing || ! v.duration || v.duration - v.currentTime > FADE ) {
                    return;
                }
                crossing = true;
                nxt.currentTime = 0;
                play( nxt );
                nxt.style.opacity = '1';
                cur.style.opacity = '0';
                var old = cur;
                setTimeout( function () {
                    old.pause();
                    old.currentTime = 0;
                    cur = nxt;
                    nxt = old;
                    crossing = false;
                }, FADE * 1000 + 50 );
            } );
        }
        watch( a );
        watch( b );

        // Appare in dissolvenza sopra la foto solo quando il video sta davvero partendo.
        a.addEventListener( 'playing', function first() {
            a.removeEventListener( 'playing', first );
            a.style.opacity = '1';
            setTimeout( function () { img.style.visibility = 'hidden'; }, 700 );
        } );

        // Fuori schermo o con la scheda in background si ferma: meno CPU e batteria.
        function sync() {
            if ( visible && ! document.hidden ) {
                play( cur );
                if ( crossing ) {
                    play( nxt );
                }
            } else {
                a.pause();
                b.pause();
            }
        }
        if ( 'IntersectionObserver' in window ) {
            new IntersectionObserver( function ( entries ) {
                visible = entries[ 0 ].isIntersecting;
                sync();
            }, { threshold: 0.1 } ).observe( slider );
        }
        document.addEventListener( 'visibilitychange', sync );
        sync();
    }

    // Parte dopo il caricamento della pagina, così non ruba banda a foto, font e testi.
    if ( document.readyState === 'complete' ) {
        start();
    } else {
        window.addEventListener( 'load', function () { setTimeout( start, 100 ); } );
    }
} )();
