<?php
/**
 * Modalità della testata della home: slider di foto oppure un video.
 *
 * Il parent (ticinoWEB CMS → Slider & Partner) gestisce solo lo slider di foto. Qui si aggiunge un interruttore
 * «Slider di foto / Video» e, per il video, il file MP4 o WebM scelto dalla Libreria media. In modalità video la
 * testata mostra il video con titolo, descrizione e pulsante della Slide 1; la foto della Slide 1 resta come
 * immagine di attesa. I campi si salvano con il solito pulsante «Salva» del CMS.
 *
 * @package liceo-diocesano-child
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

function liceo_diocesano_hero_video_url() {
    return 'video' === get_option( 'ld_hero_mode', 'slider' ) ? (string) get_option( 'ld_hero_video', '' ) : '';
}

function liceo_diocesano_register_hero_settings() {
    register_setting( 'ticinoweb_settings_group', 'ld_hero_mode', array(
        'type'              => 'string',
        'sanitize_callback' => function ( $v ) {
            return 'video' === $v ? 'video' : 'slider';
        },
        'default'           => 'slider',
    ) );
    register_setting( 'ticinoweb_settings_group', 'ld_hero_overlay_color', array(
        'type'              => 'string',
        'sanitize_callback' => function ( $v ) {
            $c = sanitize_hex_color( (string) $v );
            return $c ? $c : '#281c14';
        },
        'default'           => '#281c14',
    ) );
    register_setting( 'ticinoweb_settings_group', 'ld_hero_overlay_opacity', array(
        'type'              => 'integer',
        'sanitize_callback' => function ( $v ) {
            return max( 0, min( 90, (int) $v ) );
        },
        'default'           => 45,
    ) );
    register_setting( 'ticinoweb_settings_group', 'ld_hero_overlay_style', array(
        'type'              => 'string',
        'sanitize_callback' => function ( $v ) {
            return 'flat' === $v ? 'flat' : 'gradient';
        },
        'default'           => 'gradient',
    ) );
    register_setting( 'ticinoweb_settings_group', 'ld_hero_video', array(
        'type'              => 'string',
        'sanitize_callback' => 'liceo_diocesano_sanitize_video_url',
        'default'           => '',
    ) );
}
add_action( 'admin_init', 'liceo_diocesano_register_hero_settings' );

function liceo_diocesano_sanitize_video_url( $value ) {
    $url = esc_url_raw( (string) $value );
    if ( '' === $url ) {
        return '';
    }
    $type = wp_check_filetype( wp_parse_url( $url, PHP_URL_PATH ) );
    return in_array( $type['ext'], array( 'mp4', 'webm' ), true ) ? $url : '';
}

function liceo_diocesano_admin_hero_mode( $hook ) {
    if ( false === strpos( (string) $hook, 'ticinoweb-cms' ) ) {
        return;
    }
    wp_enqueue_media();
    $file = get_stylesheet_directory() . '/assets/js/admin-slider-video.js';
    wp_enqueue_script( 'liceo-slider-video-admin', get_stylesheet_directory_uri() . '/assets/js/admin-slider-video.js', array( 'jquery' ), filemtime( $file ), true );
    wp_localize_script( 'liceo-slider-video-admin', 'liceoHero', array(
        'mode'  => get_option( 'ld_hero_mode', 'slider' ),
        'video' => (string) get_option( 'ld_hero_video', '' ),
        'overlay' => array(
            'color'   => (string) get_option( 'ld_hero_overlay_color', '#281c14' ),
            'opacity' => (int) get_option( 'ld_hero_overlay_opacity', 45 ),
            'style'   => (string) get_option( 'ld_hero_overlay_style', 'gradient' ),
        ),
        'i18n'  => array(
            'overlayTitle' => __( 'Overlay sul video (per rendere leggibili i testi)', 'liceo-diocesano-child' ),
            'ovColor'      => __( 'Colore', 'liceo-diocesano-child' ),
            'ovOpacity'    => __( 'Intensità', 'liceo-diocesano-child' ),
            'ovStyle'      => __( 'Stile', 'liceo-diocesano-child' ),
            'ovGradient'   => __( 'Sfumatura dal basso (consigliato)', 'liceo-diocesano-child' ),
            'ovFlat'       => __( 'Uniforme su tutto il video', 'liceo-diocesano-child' ),
            'ovPreview'    => __( 'Anteprima del testo', 'liceo-diocesano-child' ),
            'textsTitle'   => __( 'Testi della testata', 'liceo-diocesano-child' ),
            'modeLabel' => __( 'Testata della home', 'liceo-diocesano-child' ),
            'slider'    => __( 'Slider di foto', 'liceo-diocesano-child' ),
            'video'     => __( 'Video', 'liceo-diocesano-child' ),
            'file'      => __( 'File video', 'liceo-diocesano-child' ),
            'choose'    => __( 'Scegli video', 'liceo-diocesano-child' ),
            'remove'    => __( 'Rimuovi video', 'liceo-diocesano-child' ),
            'title'     => __( 'Scegli un video MP4 o WebM', 'liceo-diocesano-child' ),
            'none'      => __( 'Nessun video scelto: finché manca, si vede la foto della Slide 1.', 'liceo-diocesano-child' ),
            'hint'      => __( 'Parte da solo, senza audio e in loop. Meglio MP4 (H.264) sotto i 10 MB. Titolo, descrizione e pulsante sono quelli della Slide 1, la cui foto resta come immagine di attesa.', 'liceo-diocesano-child' ),
        ),
    ) );
}
add_action( 'admin_enqueue_scripts', 'liceo_diocesano_admin_hero_mode' );

// Sul sito, in modalità video il parent deve stampare una sola slide (la prima).
function liceo_diocesano_single_slide( $pre ) {
    if ( is_admin() || ! liceo_diocesano_hero_video_url() ) {
        return $pre;
    }
    return 1;
}
add_filter( 'pre_option_ticinoweb_slider_count', 'liceo_diocesano_single_slide' );

function liceo_diocesano_hero_body_class( $classes ) {
    if ( is_front_page() && liceo_diocesano_hero_video_url() ) {
        $classes[] = 'ld-hero-video';
    }
    return $classes;
}
add_filter( 'body_class', 'liceo_diocesano_hero_body_class' );

function liceo_diocesano_front_hero_video() {
    $video = liceo_diocesano_hero_video_url();
    if ( ! is_front_page() || ! $video ) {
        return;
    }
    $file = get_stylesheet_directory() . '/assets/js/slider-video.js';
    wp_enqueue_script( 'liceo-slider-video', get_stylesheet_directory_uri() . '/assets/js/slider-video.js', array(), filemtime( $file ), true );
    wp_localize_script( 'liceo-slider-video', 'liceoHero', array( 'video' => esc_url_raw( $video ) ) );
}
add_action( 'wp_enqueue_scripts', 'liceo_diocesano_front_hero_video', 30 );

// Overlay sul video: colore, intensità e stile scelti nel CMS (solo in modalità video).
function liceo_diocesano_overlay_css() {
    if ( ! is_front_page() || ! liceo_diocesano_hero_video_url() ) {
        return;
    }
    $hex = ltrim( (string) get_option( 'ld_hero_overlay_color', '#281c14' ), '#' );
    if ( 3 === strlen( $hex ) ) {
        $hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
    }
    $r = hexdec( substr( $hex, 0, 2 ) );
    $g = hexdec( substr( $hex, 2, 2 ) );
    $b = hexdec( substr( $hex, 4, 2 ) );
    $a = max( 0, min( 90, (int) get_option( 'ld_hero_overlay_opacity', 45 ) ) ) / 100;
    if ( 'flat' === get_option( 'ld_hero_overlay_style', 'gradient' ) ) {
        $bg = sprintf( 'rgba(%d,%d,%d,%s)', $r, $g, $b, $a );
    } else {
        $bg = sprintf( 'linear-gradient(180deg, rgba(%1$d,%2$d,%3$d,%4$s) 0%%, rgba(%1$d,%2$d,%3$d,%5$s) 100%%)', $r, $g, $b, round( $a * 0.2, 2 ), $a );
    }
    wp_add_inline_style( 'child-style', '.ld-hero-video .slide-overlay{background:' . $bg . ';}' );
}
add_action( 'wp_enqueue_scripts', 'liceo_diocesano_overlay_css', 40 );

// Prestazioni: la foto di attesa della Slide 1 è l'elemento più grande della pagina, si scarica per prima.
function liceo_diocesano_preload_poster() {
    if ( ! is_front_page() || ! liceo_diocesano_hero_video_url() ) {
        return;
    }
    $img = (string) get_option( 'ticinoweb_slider_image_1', '' );
    if ( $img ) {
        printf( '<link rel="preload" as="image" href="%s" fetchpriority="high">' . "\n", esc_url( $img ) );
    }
}
add_action( 'wp_head', 'liceo_diocesano_preload_poster', 2 );
