<?php
/**
 * WPML importer: turns a WPML site (one post per language) into tW Translate
 * entries for the single original object, without calling any translation
 * engine — the translations already written and corrected in WPML are kept.
 *
 * Run it while WPML is still active (tW Translate stays in front-end standby
 * meanwhile, see Twtr_Router::wpml_active()), then deactivate WPML.
 *
 * What is imported, per WPML translation group (trid) whose original is in
 * the tW default language:
 *   - posts, pages, products, variations, menu items, Elementor templates,
 *     blocks: title, excerpt / short description, content chunks (same
 *     pipeline as Twtr_Extractor, aligned chunk by chunk);
 *   - Elementor documents: every text setting of every widget, matched by
 *     element id (WPML keeps the ids), stored as page-level text pairs
 *     (context "html") that Twtr_Html uses on any page;
 *   - terms (categories, product categories, attributes…): name, description;
 *   - media: alt text, title, caption;
 *   - String Translation strings whose source is the default language;
 *   - URL segments (post/term slugs, translated product base) → Twtr_Slugs map,
 *     so the WPML URLs stay identical; URLs that cannot be reproduced get a
 *     301 (Twtr_Slugs redirects).
 *
 * Entries are stored with origin "wpml", ready and locked (never overwritten
 * by the engine). An existing manual override made in tW Translate wins.
 * The import is repeatable (upsert) and can be undone (delete origin "wpml").
 *
 * @package tw-translate-plus
 */

if (!defined('ABSPATH')) {
    exit;
}

class Twtr_Wpml {

    const ORIGIN       = 'wpml';
    const STATE_OPTION = 'twtr_wpml_import';
    const BATCH        = 25;

    /** @var bool Also read translations already moved to the trash (re-import after the WPML cleanup). */
    public static $include_trashed = false;

    /** @var array Dry-run: a few generated entries per context type, to check them. */
    public static $samples = array();

    /** Settings keys never treated as visible text in Elementor data. */
    private static $skip_keys = '/(tooltip|font|^_|^id$|^link|^url|^html_tag|title_size|shortcode|custom_css|css_classes|email_|form_id|form_name|selected_icon|icon|image|background|video|_(color|typography|size|width|height|padding|margin|border|align|position|animation|transition|radius|shadow|gap|spacing|columns|order|style|type|skin|layout|hover_animation|id)$)/';

    /* ------------------------------------------------------------------
     * Detection and configuration
     * ------------------------------------------------------------------ */

    /** @return bool WPML tables with translations exist on this site. */
    public static function available() {
        global $wpdb;
        $t = $wpdb->prefix . 'icl_translations';
        return $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $t)) === $t
            && (int) $wpdb->get_var("SELECT COUNT(*) FROM {$t} WHERE source_language_code IS NOT NULL") > 0;
    }

    /**
     * WPML languages: default + active codes.
     *
     * @return array{default:string,languages:string[]}
     */
    public static function wpml_languages() {
        global $wpdb;
        $s       = get_option('icl_sitepress_settings', array());
        $default = is_array($s) && !empty($s['default_language']) ? (string) $s['default_language'] : '';
        $langs   = $wpdb->get_col("SELECT code FROM {$wpdb->prefix}icl_languages WHERE active = 1");
        if (!$langs) {
            $langs = $wpdb->get_col("SELECT DISTINCT language_code FROM {$wpdb->prefix}icl_translations");
        }
        return array('default' => $default, 'languages' => array_values(array_unique(array_map('sanitize_key', (array) $langs))));
    }

    /**
     * Overview shown before importing.
     *
     * @return array
     */
    public static function summary() {
        global $wpdb;
        $p     = $wpdb->prefix;
        $langs = self::wpml_languages();
        $types = $wpdb->get_results("SELECT element_type, SUM(source_language_code IS NULL) originals, SUM(source_language_code IS NOT NULL) translations FROM {$p}icl_translations GROUP BY element_type ORDER BY translations DESC", ARRAY_A);
        $catalog = Twtr_Settings::catalog();
        $missing = array_values(array_diff($langs['languages'], array_keys($catalog)));
        return array(
            'default'          => $langs['default'],
            'languages'        => $langs['languages'],
            'unsupported'      => $missing,
            'types'            => $types,
            'strings'          => (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$p}icl_string_translations t JOIN {$p}icl_strings s ON s.id = t.string_id WHERE t.status = 10 AND s.language = %s", $langs['default'])),
            'imported_entries' => Twtr_Storage::origin_entries(self::ORIGIN),
            'state'            => get_option(self::STATE_OPTION, array()),
        );
    }

    /**
     * Configure tW languages like WPML (default + published extra languages).
     *
     * @return array Configured languages.
     */
    public static function configure_languages() {
        $langs   = self::wpml_languages();
        $catalog = Twtr_Settings::catalog();
        $site    = Twtr_Settings::site();
        $default = isset($catalog[$langs['default']]) ? $langs['default'] : $site['default_lang'];
        $extra   = array();
        foreach ($langs['languages'] as $code) {
            if ($code !== $default && isset($catalog[$code])) {
                $extra[$code] = array('published' => true);
            }
        }
        Twtr_Settings::update_site(array(
            'default_lang'   => $default,
            'languages'      => $extra,
            'auto_translate' => !empty($site['auto_translate']),
        ));
        return array('default' => $default, 'extra' => array_keys($extra));
    }

    /* ------------------------------------------------------------------
     * Steps (batched, resumable)
     * ------------------------------------------------------------------ */

    /** @return string[] */
    public static function steps() {
        return array('posts', 'terms', 'media', 'strings', 'redirects');
    }

    /**
     * Run one batch of a step.
     *
     * @param string $step
     * @param int    $offset Groups already processed.
     * @param bool   $dry    Count only, write nothing.
     * @return array{done:bool,next:int,total:int,stats:array}
     */
    public static function run_step($step, $offset = 0, $dry = false) {
        $state = get_option(self::STATE_OPTION, array());
        if (!is_array($state)) {
            $state = array();
        }
        switch ($step) {
            case 'posts':
                $res = self::step_posts($offset, $dry);
                break;
            case 'terms':
                $res = self::step_terms($offset, $dry);
                break;
            case 'media':
                $res = self::step_media($offset, $dry);
                break;
            case 'strings':
                $res = self::step_strings($offset, $dry);
                break;
            case 'redirects':
                $res = self::step_redirects($offset, $dry);
                break;
            default:
                return array('done' => true, 'next' => 0, 'total' => 0, 'stats' => array());
        }
        if (!$dry) {
            $prev = isset($state['stats'][$step]) ? (array) $state['stats'][$step] : array();
            foreach ($res['stats'] as $k => $v) {
                if (is_int($v)) {
                    $prev[$k] = ($offset === 0 ? 0 : (int) ($prev[$k] ?? 0)) + $v;
                } elseif (is_array($v)) {
                    $prev[$k] = array_slice(array_merge($offset === 0 ? array() : (array) ($prev[$k] ?? array()), $v), 0, 200);
                }
            }
            $state['stats'][$step] = $prev;
            $state['updated']      = current_time('mysql');
            if ($res['done']) {
                $state['done'][$step] = current_time('mysql');
            }
            update_option(self::STATE_OPTION, $state, false);
            Twtr_Slugs::flush();
        }
        return $res;
    }

    /** Keep up to 6 examples per context type (dry-run). */
    private static function sample($items) {
        foreach ($items as $it) {
            $type = preg_replace('/:\d+:/', ':N:', $it['context']);
            if (count(self::$samples[$type] ?? array()) < 6) {
                self::$samples[$type][] = $it['locale'] . ' | ' . mb_substr(wp_strip_all_tags($it['source']), 0, 70) . '  =>  ' . mb_substr(wp_strip_all_tags($it['translation']), 0, 70);
            }
        }
    }

    /* ------------------------------------------------------------------
     * Groups
     * ------------------------------------------------------------------ */

    /**
     * trids of an element_type family, ordered, paged.
     *
     * @param string $like  e.g. 'post\_%' or 'tax\_%'
     * @param int    $offset
     * @param int    $limit
     * @return array{trids:int[],total:int}
     */
    private static function trids($like, $offset, $limit, $exclude = array()) {
        global $wpdb;
        $t   = $wpdb->prefix . 'icl_translations';
        $ex  = $exclude ? " AND element_type NOT IN ('" . implode("','", array_map('esc_sql', $exclude)) . "')" : '';
        $sql = "FROM {$t} WHERE element_type LIKE %s{$ex} AND trid IN (SELECT trid FROM {$t} WHERE source_language_code IS NOT NULL)";
        $total = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(DISTINCT trid) {$sql}", $like));
        $trids = array_map('intval', (array) $wpdb->get_col($wpdb->prepare("SELECT DISTINCT trid {$sql} ORDER BY trid LIMIT %d OFFSET %d", $like, $limit, $offset)));
        return array('trids' => $trids, 'total' => $total);
    }

    /**
     * Members of a group: lang => element_id, plus the element type.
     *
     * @param int $trid
     * @return array{type:string,members:array<string,int>}
     */
    private static function group($trid) {
        global $wpdb;
        $rows = $wpdb->get_results($wpdb->prepare("SELECT element_id, element_type, language_code FROM {$wpdb->prefix}icl_translations WHERE trid = %d AND element_id IS NOT NULL", $trid));
        $out  = array('type' => '', 'members' => array());
        foreach ((array) $rows as $r) {
            $out['type']                           = (string) $r->element_type;
            $out['members'][(string) $r->language_code] = (int) $r->element_id;
        }
        return $out;
    }

    /* ------------------------------------------------------------------
     * Step: posts (incl. products, variations, menu items, templates)
     * ------------------------------------------------------------------ */

    private static function step_posts($offset, $dry) {
        $default = Twtr_Settings::default_lang();
        $extra   = Twtr_Settings::extra_languages();
        $page    = self::trids('post\_%', $offset, self::BATCH, array('post_attachment'));
        $items   = array();
        $slugs   = array();
        $copies  = array();
        $stats   = array('groups' => 0, 'pairs' => 0, 'entries' => 0, 'elementor_pairs' => 0, 'content_mismatch' => 0, 'no_default' => 0, 'no_default_list' => array(), 'mismatch_list' => array());

        require_once TWTR_DIR . 'includes/class-twtr-content.php';
        foreach ($page['trids'] as $trid) {
            $g = self::group($trid);
            $stats['groups']++;
            if (!$g['members']) {
                continue; // WPML rows of deleted elements
            }
            if (empty($g['members'][$default])) {
                $stats['no_default']++;
                $first = reset($g['members']);
                $stats['no_default_list'][] = $g['type'] . ' #' . $first . ' ' . html_entity_decode(get_the_title($first)) . ' [' . implode(',', array_keys($g['members'])) . ']';
                continue;
            }
            $orig = get_post($g['members'][$default]);
            if (!$orig) {
                continue;
            }
            foreach ($g['members'] as $lang => $tr_id) {
                if ($lang === $default || !in_array($lang, $extra, true)) {
                    continue;
                }
                $tr = get_post($tr_id);
                if (!$tr || ($tr->post_status === 'trash' && !self::$include_trashed)) {
                    continue;
                }
                $copies[] = (int) $tr_id;
                $stats['pairs']++;
                $before = count($items);
                self::post_pair($orig, $tr, $lang, $items, $stats);
                $stats['entries'] += count($items) - $before;
                // A trashed copy has its slug renamed (shop__trashed-2): use
                // the slug it had, which is the URL indexed under WPML.
                $tr_slug = $tr->post_name;
                if ($tr->post_status === 'trash') {
                    $desired = (string) get_post_meta($tr->ID, '_wp_desired_post_slug', true);
                    $tr_slug = $desired !== '' ? $desired : preg_replace('/__trashed(-\d+)?$/', '', $tr_slug);
                }
                if ($tr_slug !== '' && $orig->post_name !== '' && $tr_slug !== $orig->post_name && !in_array($orig->post_type, array('nav_menu_item', 'elementor_library', 'product_variation', 'wp_block', 'wp_navigation'), true)) {
                    $slugs[$lang][$orig->post_name] = $tr_slug;
                }
            }
        }
        if ($dry) {
            self::sample($items);
        }
        if (!$dry) {
            Twtr_Storage::upsert_imported(self::with_rendered_forms($items), self::ORIGIN);
            Twtr_Slugs::save_map($slugs);
            self::drop_obsolete_queue($items, $copies);
        } else {
            Twtr_Slugs::preview_map($slugs);
        }
        $next = $offset + count($page['trids']);
        $stats['slugs'] = array_sum(array_map('count', $slugs));
        return array('done' => $next >= $page['total'] || !$page['trids'], 'next' => $next, 'total' => $page['total'], 'stats' => $stats);
    }

    /**
     * Post meta keys of SEO plugins that hold translatable text.
     *
     * @return string[]
     */
    private static function seo_meta_keys() {
        $keys = array(
            // SEOPress.
            '_seopress_titles_title', '_seopress_titles_desc',
            '_seopress_social_fb_title', '_seopress_social_fb_desc',
            '_seopress_social_twitter_title', '_seopress_social_twitter_desc',
            // Yoast SEO.
            '_yoast_wpseo_title', '_yoast_wpseo_metadesc',
            '_yoast_wpseo_opengraph-title', '_yoast_wpseo_opengraph-description',
            '_yoast_wpseo_twitter-title', '_yoast_wpseo_twitter-description',
            // Rank Math.
            'rank_math_title', 'rank_math_description',
            'rank_math_facebook_title', 'rank_math_facebook_description',
            'rank_math_twitter_title', 'rank_math_twitter_description',
        );
        return array_values(array_filter((array) apply_filters('twtr_wpml_seo_meta_keys', $keys), 'is_string'));
    }

    /**
     * Entries for one original/translation pair.
     */
    private static function post_pair($orig, $tr, $lang, &$items, &$stats) {
        $add = function ($context, $src, $dst) use (&$items, $lang) {
            $src = (string) $src;
            $dst = (string) $dst;
            if (trim($src) === '' || trim($dst) === '' || !preg_match('/\p{L}/u', $src)) {
                return;
            }
            // A page-builder control that stores an id (a category picked from
            // a list) is "COSMETICA" on the original and "1" on the copy: not
            // a translation. It would replace the word by a number on the page.
            if (preg_match('/^\d{1,6}$/', trim(strip_tags($dst))) && !preg_match('/^[\d\s.,%\-]+$/', trim(strip_tags($src)))) {
                return;
            }
            $items[] = array('context' => $context, 'source' => $src, 'locale' => $lang, 'translation' => $dst);
        };
        $oid = (int) $orig->ID;

        // Title (also as page-level text: menus, breadcrumbs, widgets; the
        // rendered wptexturize form is added by with_rendered_forms()).
        $add('post:' . $oid . ':title', $orig->post_title, $tr->post_title);
        $add(Twtr_Html::CONTEXT, trim($orig->post_title), trim($tr->post_title));

        // Excerpt / WooCommerce short description (same pipeline as the extractor).
        if ($orig->post_excerpt !== '' && $tr->post_excerpt !== '') {
            if ($orig->post_type === 'product') {
                $add('product:' . $oid . ':short-description', trim(wpautop($orig->post_excerpt)), trim(wpautop($tr->post_excerpt)));
            }
            $add('post:' . $oid . ':excerpt', $orig->post_excerpt, $tr->post_excerpt);
            self::text_pairs($orig->post_excerpt, $tr->post_excerpt, $add);
        }

        // Variation description: WooCommerce shows it through the short
        // description filter of the parent product (variation selector).
        if ($orig->post_type === 'product_variation' && $orig->post_parent) {
            $od = trim((string) get_post_meta($oid, '_variation_description', true));
            $td = trim((string) get_post_meta((int) $tr->ID, '_variation_description', true));
            if ($od !== '' && $td !== '' && $od !== $td) {
                $add('product:' . (int) $orig->post_parent . ':short-description', trim(wpautop($od)), trim(wpautop($td)));
                $add(Twtr_Html::CONTEXT, $od, $td);
            }
        }

        // Visible custom fields (page builders print them as text through
        // dynamic tags): each WPML copy kept its own translated value.
        $tm = get_post_meta((int) $tr->ID);
        foreach (get_post_meta($oid) as $key => $vals) {
            $key = (string) $key;
            if ($key === '' || $key[0] === '_' || !isset($tm[$key]) || count($vals) !== 1 || count($tm[$key]) !== 1) {
                continue;
            }
            $o = trim((string) $vals[0]);
            $t = trim((string) $tm[$key][0]);
            if ($o === $t || strlen($o) > 500 || is_serialized($o) || preg_match('#^https?://#i', $o) || !preg_match('/\p{L}{2}/u', $o)) {
                continue;
            }
            $add(Twtr_Html::CONTEXT, $o, $t);
        }

        // SEO plugins: custom title / description / social texts typed on the
        // original and on each copy. They start with "_" so the loop above
        // skips them, yet they print in <title>, <meta description> and
        // og:/twitter: tags. Values with a template variable (%%title%%,
        // %title%) are patterns built at render time from texts that are
        // already translated: nothing to import.
        $tm_id = (int) $tr->ID;
        foreach (self::seo_meta_keys() as $key) {
            $o = trim((string) get_post_meta($oid, $key, true));
            $t = trim((string) get_post_meta($tm_id, $key, true));
            if ($o === '' || $t === '' || $o === $t || strpos($o, '%') !== false || strpos($t, '%') !== false || !preg_match('/\p{L}{2}/u', $o)) {
                continue;
            }
            $add(Twtr_Html::CONTEXT, $o, $t);
        }

        // Elementor document: widget settings matched by element id.
        $o_el = self::elementor_data($oid);
        $t_el = self::elementor_data((int) $tr->ID);
        if ($o_el && $t_el) {
            $before = count($items);
            self::elementor_pairs($o_el, $t_el, $add);
            $stats['elementor_pairs'] += count($items) - $before;
            return;
        }

        // Classic content: the whole WPML text is the translation, used as
        // long as the original content is unchanged (Twtr_Content::content(),
        // context post:{id}:content-full). Rendered chunks often differ from
        // a save-time approximation (lazy images, srcset, block supports), so
        // chunk pairs alone would leave whole articles untranslated. Aligned
        // chunks are stored as well: they keep the translation alive for the
        // paragraphs that stay identical after a later edit of the original.
        if (trim($orig->post_content) !== '' && trim($tr->post_content) !== '') {
            $add('post:' . $oid . ':content-full', $orig->post_content, $tr->post_content);
            $oc = self::content_chunks($orig->post_content);
            $tc = self::content_chunks($tr->post_content);
            if ($oc && count($oc) === count($tc)) {
                foreach ($oc as $i => $chunk) {
                    $add('post:' . $oid . ':content', $chunk, $tc[$i]);
                }
            } else {
                $stats['content_mismatch']++;
                $stats['mismatch_list'][] = $orig->post_type . ' #' . $oid . ' ' . $orig->post_title . " ({$lang}: " . count($oc) . ' vs ' . count($tc) . ' blocks, whole text kept)';
            }
            self::text_pairs($orig->post_content, $tr->post_content, $add);
        }
    }

    /**
     * Page-level texts are looked up as they appear in the rendered HTML,
     * where WordPress and Elementor apply wptexturize (C'est → C&#8217;est,
     * -- → &#8211;): store that form too, so typographic quotes and dashes do
     * not leave whole paragraphs in the original language.
     *
     * @param array $items
     * @return array
     */
    private static function with_rendered_forms($items) {
        $out = $items;
        foreach ($items as $it) {
            if ($it['context'] !== Twtr_Html::CONTEXT) {
                continue;
            }
            // Decoded: the entity spelling of wptexturize depends on the
            // locale (&#8217; or &rsquo;); Twtr_Html also looks up decoded text.
            $src = Twtr_Html::decoded(wptexturize($it['source']));
            if ($src !== $it['source']) {
                $it['source']      = $src;
                $it['translation'] = Twtr_Html::decoded(wptexturize($it['translation']));
                $out[]             = $it;
            }
        }
        return $out;
    }

    /**
     * Queue rows the import made useless (never sent to the engine, only
     * pending/failed rows of origin google are removed):
     *   - content chunks of posts whose whole text now comes from WPML;
     *   - every string of the WPML copies (DE/EN/IT posts), which tW indexes
     *     as originals once WPML is off and which the cleanup deletes.
     *
     * @param array $items Imported entries.
     * @param int[] $copies Post ids of the WPML translations.
     */
    private static function drop_obsolete_queue($items, $copies, $term_copies = array()) {
        global $wpdb;
        $table = Twtr_Storage::entries_table();
        $blog  = get_current_blog_id();
        $where = array();
        foreach ($items as $it) {
            if (substr($it['context'], -13) === ':content-full') {
                $where[] = $wpdb->prepare('(context_key = %s AND target_locale = %s)', substr($it['context'], 0, -5), $it['locale']);
            }
        }
        foreach (array_unique(array_map('intval', (array) $copies)) as $id) {
            $where[] = $wpdb->prepare('(context_key LIKE %s OR context_key LIKE %s)', 'post:' . $id . ':%', 'product:' . $id . ':%');
        }
        foreach (array_unique(array_map('intval', (array) $term_copies)) as $id) {
            $where[] = $wpdb->prepare('(context_key LIKE %s)', 'term:' . $id . ':%');
        }
        foreach (array_chunk($where, 200) as $part) {
            $wpdb->query($wpdb->prepare("DELETE FROM {$table} WHERE blog_id = %d AND origin = 'google' AND status IN ('pending','error') AND (" . implode(' OR ', $part) . ')', $blog)); // phpcs:ignore WordPress.DB.PreparedSQL
        }
        // Rows queued towards the default language (it has nothing to translate).
        $wpdb->query($wpdb->prepare("DELETE FROM {$table} WHERE blog_id = %d AND target_locale = %s AND origin = 'google' AND status IN ('pending','error')", $blog, Twtr_Settings::default_lang()));
    }

    /**
     * Post ids of WPML translations (copies of an original), cached per
     * request. Empty when WPML tables are gone.
     *
     * @return array<int,true>
     */
    public static function copy_ids() {
        static $ids = null;
        if ($ids === null) {
            $ids = array();
            if (self::available()) {
                global $wpdb;
                foreach ((array) $wpdb->get_col("SELECT element_id FROM {$wpdb->prefix}icl_translations WHERE source_language_code IS NOT NULL AND element_type LIKE 'post\\_%' AND element_id IS NOT NULL") as $id) {
                    $ids[(int) $id] = true;
                }
            }
        }
        return $ids;
    }

    /** Same render approximation as Twtr_Extractor::on_save_post(). */
    private static function content_chunks($content) {
        $html = shortcode_unautop(wpautop(wptexturize(do_blocks($content))));
        $out  = array();
        foreach (Twtr_Content::split_html($html) as $chunk) {
            if (Twtr_Content::is_translatable_chunk($chunk)) {
                $out[] = $chunk;
            }
        }
        return $out;
    }

    /**
     * Page-level pairs: the text nodes of two HTML fragments, paired by
     * position when both have the same number of nodes.
     */
    private static function text_pairs($src_html, $dst_html, $add) {
        $a = self::text_nodes($src_html);
        $b = self::text_nodes($dst_html);
        if ($a && count($a) === count($b)) {
            foreach ($a as $i => $node) {
                $add(Twtr_Html::CONTEXT, $node, $b[$i]);
            }
            return;
        }
        // Different number of nodes (a translator added a line break, split or
        // joined a sentence): pair the paragraphs / list items one by one and,
        // inside a paragraph that is ONE text on the original, join the pieces
        // of the translation. Anything that cannot be aligned safely is left
        // out: the engine translates it instead of risking a wrong match.
        $ba = self::text_blocks($src_html);
        $bb = self::text_blocks($dst_html);
        if (!$ba || count($ba) !== count($bb)) {
            return;
        }
        foreach ($ba as $i => $nodes_a) {
            $nodes_b = $bb[$i];
            if (count($nodes_a) === count($nodes_b)) {
                foreach ($nodes_a as $j => $node) {
                    $add(Twtr_Html::CONTEXT, $node, $nodes_b[$j]);
                }
            } elseif (count($nodes_a) === 1 && $nodes_b) {
                $add(Twtr_Html::CONTEXT, $nodes_a[0], trim(preg_replace('/\s+/u', ' ', implode(' ', $nodes_b))));
            }
        }
    }

    /**
     * Text nodes grouped by block (paragraph, list item, heading, cell…).
     *
     * @param string $html
     * @return array<int,string[]> Blocks that contain text, each a list of nodes.
     */
    private static function text_blocks($html) {
        $html   = preg_replace('#<(script|style)\b.*?</\1>#is', '', (string) $html);
        $blocks = array();
        foreach (preg_split('#</?(?:p|div|li|ul|ol|h[1-6]|table|thead|tbody|tr|td|th|section|article|blockquote|figure|figcaption|dl|dt|dd|header|footer)\b[^>]*>#i', $html) as $segment) {
            $nodes = self::text_nodes($segment);
            if ($nodes) {
                $blocks[] = $nodes;
            }
        }
        return $blocks;
    }

    /**
     * Visible text nodes as Twtr_Html sees them (trimmed, with letters).
     *
     * @param string $html
     * @return string[]
     */
    private static function text_nodes($html) {
        $html = preg_replace('#<(script|style)\b.*?</\1>#is', '', (string) $html);
        $out  = array();
        foreach (preg_split('/<[^>]*>/', (string) $html) as $node) {
            $node = trim($node);
            if ($node !== '' && preg_match('/\p{L}{2}/u', html_entity_decode($node, ENT_QUOTES | ENT_HTML5, 'UTF-8'))) {
                $out[] = $node;
            }
        }
        return $out;
    }

    /** @return array|null Decoded Elementor elements of a post. */
    private static function elementor_data($post_id) {
        if (get_post_meta($post_id, '_elementor_edit_mode', true) !== 'builder') {
            return null;
        }
        $raw  = get_post_meta($post_id, '_elementor_data', true);
        $data = is_string($raw) ? json_decode($raw, true) : (is_array($raw) ? $raw : null);
        return is_array($data) ? $data : null;
    }

    /**
     * Walk both Elementor trees; same element id → compare text settings.
     */
    private static function elementor_pairs($orig_tree, $tr_tree, $add) {
        $index = array();
        $collect = function ($els) use (&$collect, &$index) {
            foreach ((array) $els as $e) {
                if (!empty($e['id'])) {
                    $index[(string) $e['id']] = $e;
                }
                if (!empty($e['elements'])) {
                    $collect($e['elements']);
                }
            }
        };
        $collect($tr_tree);
        $walk = function ($els) use (&$walk, $index, $add) {
            foreach ((array) $els as $e) {
                $id = isset($e['id']) ? (string) $e['id'] : '';
                if ($id !== '' && isset($index[$id]) && !empty($e['settings']) && is_array($e['settings'])) {
                    self::settings_pairs((array) $e['settings'], (array) ($index[$id]['settings'] ?? array()), $add);
                }
                if (!empty($e['elements'])) {
                    $walk($e['elements']);
                }
            }
        };
        $walk($orig_tree);
    }

    /**
     * Recursive comparison of two settings arrays. Repeater items are
     * matched by their _id, then by position.
     */
    private static function settings_pairs($a, $b, $add, $depth = 0) {
        if ($depth > 5) {
            return;
        }
        foreach ($a as $key => $va) {
            if (!array_key_exists($key, $b)) {
                continue;
            }
            $vb = $b[$key];
            if (is_string($key) && preg_match(self::$skip_keys, $key)) {
                continue;
            }
            if (is_array($va) && is_array($vb)) {
                if (isset($va[0]) && is_array($va[0])) {
                    // Repeater.
                    $by_id = array();
                    foreach ($vb as $item) {
                        if (is_array($item) && isset($item['_id'])) {
                            $by_id[(string) $item['_id']] = $item;
                        }
                    }
                    foreach ($va as $i => $item) {
                        if (!is_array($item)) {
                            continue;
                        }
                        $match = (isset($item['_id']) && isset($by_id[(string) $item['_id']])) ? $by_id[(string) $item['_id']] : ($vb[$i] ?? null);
                        if (is_array($match)) {
                            self::settings_pairs($item, $match, $add, $depth + 1);
                        }
                    }
                } else {
                    self::settings_pairs($va, $vb, $add, $depth + 1);
                }
                continue;
            }
            if (!is_string($va) || !is_string($vb) || !self::looks_like_text($va)) {
                continue;
            }
            if (strpos($va, '<') !== false || strpos($vb, '<') !== false) {
                self::text_pairs($va, $vb, $add);
            } else {
                $add(Twtr_Html::CONTEXT, trim($va), trim($vb));
            }
        }
    }

    /** Heuristic: a settings value that is visible text, not a technical value. */
    private static function looks_like_text($v) {
        $v = trim($v);
        if ($v === '' || mb_strlen($v) > 20000 || !preg_match('/\p{L}{2}/u', $v)) {
            return false;
        }
        if (preg_match('#^(https?:)?//|^\#[0-9a-f]{3,8}$|^[a-z0-9_-]+$|^\{|^\[|^[\w.+-]+@[\w-]+\.[\w.]+$#i', $v) && strpos($v, ' ') === false) {
            // URLs, colours, slugs/keywords (no space), JSON, shortcodes, e-mails…
            return preg_match('/^\p{Lu}\p{Ll}+$/u', $v) === 1; // …except single capitalised words ("Envoyer")
        }
        return true;
    }

    /* ------------------------------------------------------------------
     * Step: terms
     * ------------------------------------------------------------------ */

    private static function step_terms($offset, $dry) {
        global $wpdb;
        $default = Twtr_Settings::default_lang();
        $extra   = Twtr_Settings::extra_languages();
        $page    = self::trids('tax\_%', $offset, self::BATCH * 4);
        $items   = array();
        $slugs   = array();
        $copies  = array();
        $stats   = array('groups' => 0, 'pairs' => 0, 'entries' => 0, 'no_default' => 0);
        $term_of = function ($tt_id) use ($wpdb) {
            return $wpdb->get_row($wpdb->prepare("SELECT t.term_id, t.name, t.slug, tt.description, tt.taxonomy FROM {$wpdb->terms} t JOIN {$wpdb->term_taxonomy} tt ON tt.term_id = t.term_id WHERE tt.term_taxonomy_id = %d", $tt_id));
        };
        foreach ($page['trids'] as $trid) {
            $g = self::group($trid);
            $stats['groups']++;
            if (empty($g['members'][$default])) {
                $stats['no_default']++;
                continue;
            }
            $o = $term_of($g['members'][$default]);
            if (!$o || in_array($o->taxonomy, array('nav_menu', 'translation_priority', 'elementor_library_type', 'elementor_library_category', 'product_visibility', 'product_type', 'product_shipping_class'), true)) {
                continue; // not shown to visitors
            }
            foreach ($g['members'] as $lang => $tt) {
                if ($lang === $default || !in_array($lang, $extra, true)) {
                    continue;
                }
                $t = $term_of($tt);
                if (!$t) {
                    continue;
                }
                $copies[] = (int) $t->term_id;
                $stats['pairs']++;
                $before = count($items);
                foreach (array(array('term:' . $o->term_id . ':name', $o->name, $t->name), array('term:' . $o->term_id . ':description', $o->description, $t->description), array(Twtr_Html::CONTEXT, trim($o->name), trim($t->name))) as $row) {
                    if (trim((string) $row[1]) !== '' && trim((string) $row[2]) !== '' && preg_match('/\p{L}/u', (string) $row[1])) {
                        $items[] = array('context' => $row[0], 'source' => (string) $row[1], 'locale' => $lang, 'translation' => (string) $row[2]);
                    }
                }
                $stats['entries'] += count($items) - $before;
                if ($t->slug !== $o->slug && strpos($o->taxonomy, 'pa_') !== 0) {
                    $slugs[$lang][$o->slug] = $t->slug;
                }
            }
        }
        if ($dry) {
            self::sample($items);
        }
        if (!$dry) {
            Twtr_Storage::upsert_imported(self::with_rendered_forms($items), self::ORIGIN);
            Twtr_Slugs::save_map($slugs);
            self::drop_obsolete_queue($items, array(), $copies);
        } else {
            Twtr_Slugs::preview_map($slugs);
        }
        $next = $offset + count($page['trids']);
        $stats['slugs'] = array_sum(array_map('count', $slugs));
        return array('done' => $next >= $page['total'] || !$page['trids'], 'next' => $next, 'total' => $page['total'], 'stats' => $stats);
    }

    /* ------------------------------------------------------------------
     * Step: media (alt, title, caption)
     * ------------------------------------------------------------------ */

    private static function step_media($offset, $dry) {
        $default = Twtr_Settings::default_lang();
        $extra   = Twtr_Settings::extra_languages();
        global $wpdb;
        $t     = $wpdb->prefix . 'icl_translations';
        $total = (int) $wpdb->get_var("SELECT COUNT(DISTINCT trid) FROM {$t} WHERE element_type = 'post_attachment' AND source_language_code IS NOT NULL");
        $trids = array_map('intval', (array) $wpdb->get_col($wpdb->prepare("SELECT DISTINCT trid FROM {$t} WHERE element_type = 'post_attachment' AND source_language_code IS NOT NULL ORDER BY trid LIMIT %d OFFSET %d", self::BATCH * 8, $offset)));
        $items = array();
        $stats = array('groups' => 0, 'entries' => 0);
        foreach ($trids as $trid) {
            $g = self::group($trid);
            $stats['groups']++;
            if (empty($g['members'][$default])) {
                continue;
            }
            $o   = get_post($g['members'][$default]);
            $oal = (string) get_post_meta($g['members'][$default], '_wp_attachment_image_alt', true);
            foreach ($g['members'] as $lang => $id) {
                if ($lang === $default || !in_array($lang, $extra, true) || !$o) {
                    continue;
                }
                $tp  = get_post($id);
                $tal = (string) get_post_meta($id, '_wp_attachment_image_alt', true);
                foreach (array(array($oal, $tal), array($o->post_title, $tp ? $tp->post_title : ''), array($o->post_excerpt, $tp ? $tp->post_excerpt : '')) as $pair) {
                    $s = trim((string) $pair[0]);
                    $d = trim((string) $pair[1]);
                    if ($s !== '' && $d !== '' && preg_match('/\p{L}{2}/u', $s)) {
                        $items[] = array('context' => Twtr_Html::CONTEXT, 'source' => $s, 'locale' => $lang, 'translation' => $d);
                    }
                }
            }
        }
        $stats['entries'] = count($items);
        if ($dry) {
            self::sample($items);
        }
        if (!$dry) {
            Twtr_Storage::upsert_imported(self::with_rendered_forms($items), self::ORIGIN);
        }
        $next = $offset + count($trids);
        return array('done' => $next >= $total || !$trids, 'next' => $next, 'total' => $total, 'stats' => $stats);
    }

    /* ------------------------------------------------------------------
     * Step: String Translation
     * ------------------------------------------------------------------ */

    private static function step_strings($offset, $dry) {
        global $wpdb;
        $p       = $wpdb->prefix;
        $default = Twtr_Settings::default_lang();
        $extra   = Twtr_Settings::extra_languages();
        $limit   = 1000;
        $total   = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$p}icl_string_translations t JOIN {$p}icl_strings s ON s.id = t.string_id WHERE t.status = 10 AND s.language = %s", $default));
        $rows    = $wpdb->get_results($wpdb->prepare(
            "SELECT s.name, s.context, s.value src, t.language lang, t.value dst FROM {$p}icl_string_translations t JOIN {$p}icl_strings s ON s.id = t.string_id
             WHERE t.status = 10 AND s.language = %s ORDER BY t.id LIMIT %d OFFSET %d",
            $default, $limit, $offset
        ));
        $items = array();
        $slugs = array();
        $stats = array('rows' => count((array) $rows), 'entries' => 0, 'slugs' => 0);
        foreach ((array) $rows as $r) {
            if (!in_array($r->lang, $extra, true)) {
                continue;
            }
            // Translated URL bases (WPML "URL slug: product", category bases…).
            if (stripos((string) $r->name, 'URL ') === 0 && stripos((string) $r->name, 'slug') !== false) {
                foreach (array_map('trim', explode('/', trim((string) $r->src, '/'))) as $i => $seg) {
                    $tseg = explode('/', trim((string) $r->dst, '/'));
                    if ($seg !== '' && isset($tseg[$i]) && $tseg[$i] !== '') {
                        $slugs[$r->lang][$seg] = $tseg[$i];
                    }
                }
                continue;
            }
            $src = trim((string) $r->src);
            $dst = trim((string) $r->dst);
            if ($src === '' || $dst === '' || mb_strlen($src) > 5000 || !preg_match('/\p{L}{2}/u', $src) || preg_match('/%(\d+\$)?[sd]/', $src)) {
                continue; // placeholders never appear as such on a page
            }
            // Newer WPML names the options «blogname» / «blogdescription»;
            // older installs keep «Blog Title» / «Tagline» (context «WP»).
            if ($r->name === 'blogname' || ($r->name === 'Blog Title' && $r->context === 'WP')) {
                $items[] = array('context' => 'site:name', 'source' => $src, 'locale' => $r->lang, 'translation' => $dst);
            } elseif ($r->name === 'blogdescription' || ($r->name === 'Tagline' && $r->context === 'WP')) {
                $items[] = array('context' => 'site:description', 'source' => $src, 'locale' => $r->lang, 'translation' => $dst);
            }
            if (strpos($src, '<') !== false) {
                $add = function ($c, $s, $d) use (&$items, $r) {
                    $items[] = array('context' => $c, 'source' => $s, 'locale' => $r->lang, 'translation' => $d);
                };
                self::text_pairs($src, $dst, $add);
            } else {
                $items[] = array('context' => Twtr_Html::CONTEXT, 'source' => $src, 'locale' => $r->lang, 'translation' => $dst);
            }
        }
        $stats['entries'] = count($items);
        $stats['slugs']   = array_sum(array_map('count', $slugs));
        if ($dry) {
            self::sample($items);
        }
        if (!$dry) {
            Twtr_Storage::upsert_imported(self::with_rendered_forms($items), self::ORIGIN);
            Twtr_Slugs::save_map($slugs);
            self::drop_obsolete_queue($items, array());
        } else {
            Twtr_Slugs::preview_map($slugs);
        }
        $next = $offset + $limit;
        return array('done' => $next >= $total || !$rows, 'next' => $next, 'total' => $total, 'stats' => $stats);
    }

    /* ------------------------------------------------------------------
     * Step: redirects (WPML URL → tW URL, only when they differ)
     * ------------------------------------------------------------------ */

    private static function step_redirects($offset, $dry) {
        global $wpdb;
        $default = Twtr_Settings::default_lang();
        $extra   = Twtr_Settings::extra_languages();
        $t       = $wpdb->prefix . 'icl_translations';
        $types   = "'post_page','post_post','post_product'";
        $total   = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$t} WHERE element_type IN ({$types}) AND source_language_code IS NOT NULL");
        $rows    = $wpdb->get_results($wpdb->prepare("SELECT trid, element_id, language_code FROM {$t} WHERE element_type IN ({$types}) AND source_language_code IS NOT NULL ORDER BY translation_id LIMIT %d OFFSET %d", self::BATCH * 4, $offset));
        $pairs   = array();
        $stats   = array('checked' => 0, 'same' => 0, 'redirects' => 0, 'list' => array());
        foreach ((array) $rows as $r) {
            if (!in_array($r->language_code, $extra, true) || get_post_status((int) $r->element_id) !== 'publish') {
                continue;
            }
            $g = self::group((int) $r->trid);
            if (empty($g['members'][$default])) {
                continue;
            }
            $stats['checked']++;
            // WPML builds a copy's permalink (prefix, translated base and
            // slug) only in that copy's language: switch to it first.
            do_action('wpml_switch_language', $r->language_code);
            $old = (string) get_permalink((int) $r->element_id);
            do_action('wpml_switch_language', $default);
            $new = self::tw_url((int) $g['members'][$default], $r->language_code);
            $o   = Twtr_Slugs::normalize_path($old);
            $n   = Twtr_Slugs::normalize_path($new);
            if ($o === '' || $n === '' || $o === $n) {
                $stats['same']++;
                continue;
            }
            $pairs[$o] = $n;
            $stats['redirects']++;
            $stats['list'][] = $o . ' → ' . $n;
        }
        if (!$dry) {
            Twtr_Slugs::save_redirects($pairs);
        }
        $next = $offset + count((array) $rows);
        return array('done' => $next >= $total || !$rows, 'next' => $next, 'total' => $total, 'stats' => $stats);
    }

    /**
     * URL tW Translate will serve for an original post in $lang: the
     * default-language permalink, prefixed and with translated segments.
     *
     * @param int    $post_id
     * @param string $lang
     * @return string
     */
    public static function tw_url($post_id, $lang) {
        $default_url = (string) apply_filters('wpml_permalink', get_permalink($post_id), Twtr_Settings::default_lang(), true);
        $home        = rtrim((string) get_option('home'), '/');
        $home_path   = rtrim((string) parse_url($home, PHP_URL_PATH), '/');
        $path        = (string) parse_url($default_url, PHP_URL_PATH);
        $rel         = $home_path !== '' && strpos($path, $home_path) === 0 ? substr($path, strlen($home_path)) : $path;
        $url         = $home . '/' . $lang . ($rel === '' ? '/' : $rel);
        return Twtr_Slugs::to_translated_url($url, $lang, $home_path);
    }

    /**
     * Undo: delete every entry imported from WPML, the slug map and the
     * redirects created by the import.
     *
     * @return int Entries deleted.
     */
    public static function undo() {
        $n = Twtr_Storage::origin_entries(self::ORIGIN, true);
        delete_option(Twtr_Slugs::MAP_OPTION);
        delete_option(Twtr_Slugs::REDIRECT_OPTION);
        delete_option(self::STATE_OPTION);
        Twtr_Slugs::flush();
        return $n;
    }
}
