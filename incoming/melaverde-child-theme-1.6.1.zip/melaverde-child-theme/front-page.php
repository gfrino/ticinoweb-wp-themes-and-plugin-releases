<?php
/**
 * Mela Verde Child Theme - Front Page (ONE PAGE Layout)
 */

get_header();

// ==========================================
// ESTRAZIONE DATI DAL CMS
// ==========================================

// 1. HERO SLIDER
$hero_slides = function_exists('ticinoweb_get_slider_data') ? ticinoweb_get_slider_data() : array();
$first_hero = !empty($hero_slides) ? $hero_slides[0] : null;

$upload_dir = wp_get_upload_dir();
$uploads_base = $upload_dir['baseurl'];

$hero_image = $first_hero && !empty($first_hero['image']) ? $first_hero['image'] : $uploads_base . '/2026/04/melaverde-demo-hero.png';
// Titolo e sottotitolo: editabili da Aspetto > Personalizza (non più dallo Slider CMS)
$hero_title = get_theme_mod( 'melaverde_hero_title', 'Ispirazioni genuine per la tua tavola' );
$hero_desc = get_theme_mod( 'melaverde_hero_desc', 'Prodotti di stagione, locali e selezionati ogni giorno.' );
$hero_btn1 = 'Servizi'; // Fisso: non modificabile dal pannello testi
$hero_btn1_link = '#prodotti'; // Forziamo l'ancora al nuovo ID della sezione servizi/prodotti
$hero_btn2 = 'Vieni a trovarci'; // Fisso: non modificabile dal pannello testi

// 2. CHI SIAMO (titolo e testo editabili da Aspetto > Personalizza)
$chi_siamo_title = get_theme_mod( 'melaverde_chisiamo_title', 'La nostra storia' );
$chi_siamo_image = get_option('ticinoweb_chi_siamo_image', '');

$chi_siamo_text_default = "Da oltre 20 anni lavoriamo nel mondo della gastronomia con passione, esperienza e attenzione alla qualità. Oggi, con il nostro punto vendita di Bellinzona, portiamo questa esperienza direttamente al cliente, offrendo ogni giorno prodotti freschi e selezionati.\n\nSiamo specializzati nella vendita di frutta e verdura di stagione, accuratamente scelta per garantire gusto, freschezza e genuinità. Accanto a questo, proponiamo un'ampia selezione di prodotti alimentari, tra cui latticini, salumi e formaggi, privilegiando fornitori locali e filiere corte a km 0.\nIl nostro obiettivo è semplice: offrire prodotti di qualità superiore, senza conservanti e nel rispetto della stagionalità, per portare sulla tavola sapori autentici e genuini.\n\nCrediamo nella cura dei dettagli, nella scelta delle materie prime e in un servizio attento alle esigenze di ogni cliente. Grazie a infrastrutture adeguate per lo stoccaggio e la logistica, siamo in grado di garantire freschezza costante e standard elevati in ogni prodotto.\nMela Verde non è solo un negozio, ma un punto di riferimento per chi cerca qualità, autenticità e prodotti selezionati con competenza.";
$chi_siamo_text_raw = get_theme_mod( 'melaverde_chisiamo_text', $chi_siamo_text_default );
$chi_siamo_text = '<div class="font-body text-lg text-on-surface-variant leading-relaxed">' . wpautop( esc_html( $chi_siamo_text_raw ) ) . '</div>';

if(empty($chi_siamo_image)) {
    // Fallback Image from HTML mock
    $chi_siamo_image = $uploads_base . '/2026/04/melaverde-demo-chisiamo.png';
}

// 3. CONTATTI — tutti i dati vengono dal ticinoWEB CMS (Contatti). Nessun valore
// di riserva nel codice: se un campo è vuoto, il riquadro corrispondente non compare.
$contact_info    = ticinoweb_get_contact_info();
$contact_address = trim( (string) $contact_info['address'] );
$contact_email   = trim( (string) $contact_info['email'] );

// Telefoni: fisso (o principale) e cellulare, senza doppioni.
$contact_phones = array();
foreach ( array( $contact_info['phone'], $contact_info['phone_landline'], $contact_info['phone_mobile'] ) as $melaverde_phone ) {
    $melaverde_phone = trim( (string) $melaverde_phone );
    $melaverde_digits = preg_replace( '/[^0-9+]/', '', $melaverde_phone );
    if ( $melaverde_phone !== '' && $melaverde_digits !== '' && ! isset( $contact_phones[ $melaverde_digits ] ) ) {
        $contact_phones[ $melaverde_digits ] = $melaverde_phone;
    }
}

// Orari: giorni nell'ordine del CMS, etichette italiane del sito.
$melaverde_days = array(
    'monday'    => 'Lunedì',
    'tuesday'   => 'Martedì',
    'wednesday' => 'Mercoledì',
    'thursday'  => 'Giovedì',
    'friday'    => 'Venerdì',
    'saturday'  => 'Sabato',
    'sunday'    => 'Domenica',
);
$contact_hours = array();
$melaverde_hours_raw = is_array( $contact_info['opening_hours'] ) ? $contact_info['opening_hours'] : array();
foreach ( $melaverde_days as $melaverde_day_key => $melaverde_day_label ) {
    if ( ! isset( $melaverde_hours_raw[ $melaverde_day_key ] ) ) {
        continue;
    }
    $melaverde_day_text = ticinoweb_format_day_hours( $melaverde_hours_raw[ $melaverde_day_key ], ', ' );
    if ( $melaverde_day_text === '' ) {
        continue;
    }
    $contact_hours[] = array(
        'label'  => $melaverde_day_label,
        'text'   => $melaverde_day_text,
        'closed' => ! empty( $melaverde_hours_raw[ $melaverde_day_key ]['closed'] ),
    );
}
$contact_hours_note = trim( (string) $contact_info['opening_hours_note'] );

// 3.5 GALLERIA (Dynamic Extraction from Ticinoweb Media Galleries)
$gallery_images = [];
$target_gallery_id = 3;

$gallery_args = array(
    'post_type' => 'attachment',
    'post_status' => 'inherit',
    'posts_per_page' => -1,
    'tax_query' => array(
        array(
            'taxonomy' => 'ticinoweb_media_gallery',
            'field' => 'term_id',
            'terms' => $target_gallery_id,
        )
    )
);
$gallery_query = new WP_Query($gallery_args);
if ( $gallery_query->have_posts() ) {
    $saved_order = get_term_meta($target_gallery_id, '_ticinoweb_gallery_order', true);
    if (!is_array($saved_order)) $saved_order = array();
    
    $raw_posts = $gallery_query->posts;
    if (!empty($saved_order)) {
        usort($raw_posts, function ($a, $b) use ($saved_order) {
            $posA = array_search($a->ID, $saved_order);
            $posB = array_search($b->ID, $saved_order);
            if ($posA === false) $posA = 999999;
            if ($posB === false) $posB = 999999;
            return $posA - $posB;
        });
    }
    
    foreach( $raw_posts as $gpost ) {
        $gallery_images[] = [
            'url' => wp_get_attachment_image_url($gpost->ID, 'large') ?: wp_get_attachment_image_url($gpost->ID, 'full'),
            'alt' => get_post_meta($gpost->ID, '_wp_attachment_image_alt', true) ?: $gpost->post_title
        ];
    }
}
if (empty($gallery_images)) {
    // Fallback default
    $gallery_images = [
        ['url' => 'https://lh3.googleusercontent.com/aida-public/AB6AXuCTK_udZifFIn5PBh0E3U7U0k7LwPvszrGQqRQJqhvjUGBwsjn2Yj8v0kmPDSXGeVGS1oGheMCeSydsqILLk2YHOp2iqmWZKkv2B22sUJuKY5Q3bkbhsf4B7IEjHEVphkk2wtwzp0iSFVOWSwuCZwIYbrvEq2xHEgfZERnIi6JysEjflBefsOtJm3gY-ubfNSgOh8nFw-3pGJnoM2hsr7Pqp5njWHGH4w41g_8Oo4T3S_aHC6DC9Uz0T20HSmr11IRJycoYCPzUy9Kk', 'alt' => 'Fresh organic vegetables'],
        ['url' => 'https://lh3.googleusercontent.com/aida-public/AB6AXuDMY_T0Q4eqA9Hx_8UfQc3mtbROd1olGH7P1f2mzik8HRBEoaUPK6a6SZCyKZhPQI7FM1FysXHZVm4_toeIv9-3tweLRGKeEtgiGAKy3Wq1KVFP0LBcOlXkHmzDZAsseWn6f9WGy0ss3aqU3b0k24arlpdefJiHR_xARr1q2-OXukXaplSwZlW4QbHVK6uGBd8SYKRiBPht_qGduxxe0qaa_Soc6ekYj4B6WcxC224B6Wdy-mGAi3HhFqr4_wJbYAAIlsrW3ChhhoPF', 'alt' => 'Citrus fruits'],
        ['url' => 'https://lh3.googleusercontent.com/aida-public/AB6AXuAETNjSDGtZVicQ3pYgV9TCkWjdKe2aAJrn-6yFuTMUY7I6XzfNvOfqFoHGxtCEZozL7aRf6BidN1Se1QkvWIoq0iCjy8z-jry9ZWDkdau94UcS5nv5lqzDB4wkLfZcLCXgeQVDQUVtB2xlRDOOPO97SFX0i5N7i0DSQBY9x78OW1ivVHlizno-VTIOQCkjSYf_oC81md5cx5DjUBUX3YcsCw2Qtvj7Wifl1HxXKUxfUhRyM3jYsG8XiWw5T6ny7d1yDWMuVGdwLCAp', 'alt' => 'Local market interior'],
        ['url' => 'https://lh3.googleusercontent.com/aida-public/AB6AXuCdw2FnFRLb8Lm-vVgc6nq0XrYd0n2mYJABoQIjFB2IkAHf1s1cPQ7NB1pz2memyfMkaEuFUd_jMGjPEf2N16TBTjkAf8DhO5dDuyzo5Q2o9StNpJ3eQFBwKBeLx6MnbAclujNq3dhtLn13E_IravJ8IRL06LHI2nwzm6SLVg8Px_KC7OvhR7GQUPGvaJy9IbMvHts3rCUWM0nRyDsUcl3qdeSfMbB5B0PuUdiua3JqnchhS_cPvf5KdjOWb3x_ii0JwuXTUwTdARxd', 'alt' => 'Fresh tomatoes'],
        ['url' => 'https://lh3.googleusercontent.com/aida-public/AB6AXuBjTtNn0wK97mT4E6jH8XtCkPYw17vfcCbeoN-ji9WCljV0exwifgBC_T-t4VO1HT5DBbO7C4vY4b0G9kGTfh84fqK1W8MgUhqWa9OysNBVSWji00coa3jcHfhEKbvIXyOmAUCRlhd9ieAdx23QcAAwjA7wsloOTipEHdXtkHWN6rdaqbYikugej7K-lb9BOZcUIAdECURiErqcEJm4dLmCPXWPgDkz5FlqGHhpd6iwoUAx9kxTZMVzNfuE2kiVinvRRQ30i7xQspQ6', 'alt' => 'Fresh produce'],
        ['url' => 'https://lh3.googleusercontent.com/aida-public/AB6AXuDk1NUoSTWy0rw2nuaR254ItfrnKA2HmSVvHJWPMxFi0BC2rPuWzLzndsSKu91AyRd3JvFYCADc6iKZqqo5ceDHmF8jqXZAujhoOhYpJ72MM7mSDavNfduJC8kgsA1IcG5jNkuJ4f5Qk_OrL4CZia0jGsl7Jh6CcN15q39q9NOYOq775A4ggHQlz9Y2iazNu3E0_XRfm41fIjP9YS4CiUgCHb4BGetBk34-yuHrGCgZJS-oZluzmd5Ug6KlEMm2tSCgeEUyLnJrqTYO', 'alt' => 'Vegetables array'],
        ['url' => 'https://lh3.googleusercontent.com/aida-public/AB6AXuDYrEAOnJ-5g_KvxznR8L073TPa9izfHCIKqObSJ41GwPZbaIbJ70NsJfxIWfYbW4d_IzkVfuJcbCrLdPKH153hSgES7B52QZYZzrQFqfo7JZCqG9ctZG8-OFcGGLcDfOnxWBYkbxANBYPCNCjEEwzk1gPkr0_l15oLCcV39jvQgL-akeZJ7pchIL2Y3miZV0IkIOugKY5JFXRChcfnije5rYF_CiEYCTGpr2cJ1tqf0-9zA9d8DUPY3LJTnlHY_ACyN_ULFAU3K2hw', 'alt' => 'Fresh greens']
    ];
}

// 4. LOGO
$logo_url = get_option('ticinoweb_site_logo', '');
if ( empty($logo_url) ) {
    $custom_logo_id = get_theme_mod( 'custom_logo' );
    $logo_url = wp_get_attachment_image_url( $custom_logo_id , 'full' );
}

// 5. TESTI DEL MENU E DEL FOOTER (fissi: non modificabili dal pannello testi)
$nav_home     = 'Home';
$nav_chisiamo = 'Chi Siamo';
$nav_prodotti = 'Prodotti';
$nav_galleria = 'Galleria';
$nav_contatti = 'Contatti';
$nav_cta      = 'Contattaci';

// 6. TESTI DELLE SCHEDE PRODOTTO (editabili da Aspetto > Personalizza)
$prodotti_cards = [
    1 => [ 'image' => get_theme_mod( 'melaverde_prodotti_card1_image', $uploads_base . '/2026/04/PHOTO-2026-04-16-11-18-25-5.jpg' ), 'title' => get_theme_mod( 'melaverde_prodotti_card1_title', 'Frutta e verdura di stagione' ), 'desc' => get_theme_mod( 'melaverde_prodotti_card1_desc', 'Raccolte al momento giusto per il massimo del sapore e dei nutrienti.' ) ],
    2 => [ 'image' => get_theme_mod( 'melaverde_prodotti_card2_image', $uploads_base . '/2026/04/PHOTO-2026-04-26-18-52-03.jpg' ), 'title' => get_theme_mod( 'melaverde_prodotti_card2_title', 'Latticini Freschi' ), 'desc' => get_theme_mod( 'melaverde_prodotti_card2_desc', 'Latte, yogurt e mozzarelle dal sapore genuino garantito.' ) ],
    3 => [ 'image' => get_theme_mod( 'melaverde_prodotti_card3_image', $uploads_base . '/2026/04/PHOTO-2026-04-26-18-52-03-2.jpg' ), 'title' => get_theme_mod( 'melaverde_prodotti_card3_title', 'Salumi Selezionati' ), 'desc' => get_theme_mod( 'melaverde_prodotti_card3_desc', 'I migliori insaccati artigianali perfetti per i tuoi taglieri.' ) ],
    4 => [ 'image' => get_theme_mod( 'melaverde_prodotti_card4_image', $uploads_base . '/2026/04/PHOTO-2026-04-16-11-18-25.jpg' ), 'title' => get_theme_mod( 'melaverde_prodotti_card4_title', 'Formaggi Locali' ), 'desc' => get_theme_mod( 'melaverde_prodotti_card4_desc', 'Profumi e sapori intensi, dai pascoli ticinesi alla tua tavola.' ) ],
    5 => [ 'title' => get_theme_mod( 'melaverde_prodotti_card5_title', 'Prodotti a Km 0' ), 'desc' => get_theme_mod( 'melaverde_prodotti_card5_desc', "Sosteniamo l'agricoltura ticinese per offrirti il vero sapore del nostro territorio." ) ],
];
?>

<!-- TopNavBar Shared Component -->
<nav class="fixed top-0 w-full z-50 bg-[#faf6f0]/90 backdrop-blur-md dark:bg-stone-900/90 border-b border-stone-200/50 dark:border-stone-800 shadow-sm transition-all duration-300 ease-in-out">
<div class="flex justify-between items-center px-4 md:px-8 h-24 max-w-7xl mx-auto">
<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="font-['Literata'] text-2xl font-bold text-[#4a7c59] dark:text-emerald-500 flex items-center hover:opacity-80 transition-opacity">
    <?php if ( $logo_url ) : ?>
        <img src="<?php echo esc_url( $logo_url ); ?>" alt="Mela Verde Logo" class="h-20 w-auto object-contain drop-shadow-sm scale-110 origin-left">
    <?php else : ?>
        Mela Verde
    <?php endif; ?>
</a>
<div class="relative hidden md:flex items-center gap-2" id="header-nav-container">
<a class="header-nav-link active font-['Nunito_Sans'] font-semibold text-sm uppercase tracking-wide px-3 py-2 text-[#4a7c59] transition-colors duration-300 ease-in-out" href="#home" data-target="home"><?php echo esc_html( $nav_home ); ?></a>
<a class="header-nav-link font-['Nunito_Sans'] font-semibold text-sm uppercase tracking-wide px-3 py-2 text-stone-600 dark:text-stone-400 hover:text-[#4a7c59] transition-colors duration-300 ease-in-out" href="#chisiamo" data-target="chisiamo"><?php echo esc_html( $nav_chisiamo ); ?></a>
<a class="header-nav-link font-['Nunito_Sans'] font-semibold text-sm uppercase tracking-wide px-3 py-2 text-stone-600 dark:text-stone-400 hover:text-[#4a7c59] transition-colors duration-300 ease-in-out" href="#prodotti" data-target="prodotti"><?php echo esc_html( $nav_prodotti ); ?></a>
<a class="header-nav-link font-['Nunito_Sans'] font-semibold text-sm uppercase tracking-wide px-3 py-2 text-stone-600 dark:text-stone-400 hover:text-[#4a7c59] transition-colors duration-300 ease-in-out" href="#galleria" data-target="galleria"><?php echo esc_html( $nav_galleria ); ?></a>
<a class="header-nav-link font-['Nunito_Sans'] font-semibold text-sm uppercase tracking-wide px-3 py-2 text-stone-600 dark:text-stone-400 hover:text-[#4a7c59] transition-colors duration-300 ease-in-out" href="#contatti" data-target="contatti"><?php echo esc_html( $nav_contatti ); ?></a>
<div id="nav-indicator" class="absolute left-0 bottom-0 h-[2px] bg-[#4a7c59] transition-all duration-300 ease-out pointer-events-none" style="width: 0; transform: translateX(0);"></div>
</div>
<a href="#contatti" class="bg-primary text-on-primary font-body font-semibold py-2 px-6 rounded-lg hover:bg-primary-container hover:text-on-primary-container transition-colors hidden md:block">
                <?php echo esc_html( $nav_cta ); ?>
            </a>
<button id="mobile-menu-btn" class="md:hidden text-[#4a7c59] z-[60] relative p-1">
<span id="mobile-menu-icon" class="material-symbols-outlined text-[36px]" style="font-variation-settings: 'FILL' 0;">menu</span>
</button>
</div>
</nav>

<!-- MOBILE MENU OVERLAY -->
<div id="mobile-menu-overlay" class="fixed inset-0 bg-[#faf6f0]/70 dark:bg-stone-900/80 backdrop-blur-2xl z-[150] transform translate-x-full transition-transform duration-500 ease-in-out md:hidden flex flex-col items-center justify-center gap-10 shadow-2xl">
    <button id="mobile-menu-close" class="absolute top-8 right-6 p-2 text-[#4a7c59] dark:text-emerald-500 hover:scale-110 transition-transform">
        <span class="material-symbols-outlined text-[48px]" style="font-variation-settings: 'FILL' 0;">close</span>
    </button>
    <a href="#home" class="mobile-nav-link text-[#4a7c59] text-3xl font-headline font-bold" data-target="home"><?php echo esc_html( $nav_home ); ?></a>
    <a href="#chisiamo" class="mobile-nav-link text-stone-600 dark:text-stone-300 text-3xl font-headline font-bold hover:text-[#4a7c59] transition-colors" data-target="chisiamo"><?php echo esc_html( $nav_chisiamo ); ?></a>
    <a href="#prodotti" class="mobile-nav-link text-stone-600 dark:text-stone-300 text-3xl font-headline font-bold hover:text-[#4a7c59] transition-colors" data-target="prodotti"><?php echo esc_html( $nav_prodotti ); ?></a>
    <a href="#galleria" class="mobile-nav-link text-stone-600 dark:text-stone-300 text-3xl font-headline font-bold hover:text-[#4a7c59] transition-colors" data-target="galleria"><?php echo esc_html( $nav_galleria ); ?></a>
    <a href="#contatti" class="mobile-nav-link text-stone-600 dark:text-stone-300 text-3xl font-headline font-bold hover:text-[#4a7c59] transition-colors" data-target="contatti"><?php echo esc_html( $nav_contatti ); ?></a>
</div>

<!-- SIDE NAVIGATION SPY -->
<nav id="side-nav" class="fixed right-6 top-1/2 transform -translate-y-1/2 z-[100] hidden xl:flex flex-col gap-6 items-center">
    <?php
    $nav_sections = [
        ['id' => 'home', 'label' => $nav_home],
        ['id' => 'chisiamo', 'label' => $nav_chisiamo],
        ['id' => 'prodotti', 'label' => $nav_prodotti],
        ['id' => 'galleria', 'label' => $nav_galleria],
        ['id' => 'contatti', 'label' => $nav_contatti]
    ];
    foreach ($nav_sections as $sec) :
    ?>
    <a href="#<?php echo $sec['id']; ?>" class="nav-dot group relative flex items-center justify-center w-8 h-8" data-target="<?php echo $sec['id']; ?>">
        <!-- Base Dot -->
        <div class="dot w-3 h-3 rounded-full bg-stone-300 dark:bg-stone-600 group-hover:bg-primary transition-all duration-300"></div>
        <!-- Active Apple Marker -->
        <div class="apple-marker absolute inset-0 opacity-0 scale-50 transition-all duration-300 flex items-center justify-center text-xl drop-shadow-md">🍏</div>
        <!-- Tooltip Label -->
        <span class="absolute right-full mr-4 bg-tertiary-container text-on-tertiary-container px-3 py-1 rounded-lg text-sm font-bold opacity-0 translate-x-4 transition-all duration-300 group-hover:opacity-100 group-hover:translate-x-0 pointer-events-none whitespace-nowrap shadow-md"><?php echo esc_html( $sec['label'] ); ?></span>
    </a>
    <?php endforeach; ?>
</nav>

<style>
/* Smooth Scrolling & Offset for Fixed Header */
html {
    scroll-behavior: smooth;
    scroll-padding-top: 96px;
}

/* CSS Reset for Parent Theme Spacing and Headers */
#content, .site-content, .site {
    padding-top: 0 !important;
    padding-bottom: 0 !important;
    margin-top: 0 !important;
    margin-bottom: 0 !important;
}
#masthead, .site-header {
    display: none !important;
}

/* CSS Logic for ScrollSpy toggle */
.nav-dot.active .dot {
    opacity: 0;
    transform: scale(0);
}
.nav-dot.active .apple-marker {
    opacity: 1;
    transform: scale(1.1);
}

/* Animated hand-drawn underline */
.group:hover .hand-drawn-line {
    stroke-dashoffset: 0 !important;
}
</style>

<!-- HERO -->
<header class="relative w-full h-[819px] min-h-[600px] flex items-center justify-center overflow-hidden gsap-hero" id="home">
<img alt="<?php echo esc_attr($hero_title); ?>" class="absolute inset-0 w-full h-full object-cover hero-image" src="<?php echo esc_url($hero_image); ?>" style="will-change: transform, opacity;"/>
<div class="relative w-full px-4 md:px-0 flex justify-center">
<div class="relative z-10 text-center px-6 md:px-14 py-10 md:py-12 w-full max-w-4xl backdrop-blur-md bg-stone-900/30 border border-white/20 rounded-[2.5rem] md:rounded-[3rem] shadow-2xl">
<h1 class="font-headline text-4xl md:text-7xl font-bold text-white mb-6 leading-tight drop-shadow-lg hero-title" style="will-change: transform, opacity;">
    <?php echo esc_html($hero_title); ?>
</h1>
<p class="font-body text-xl md:text-2xl text-surface-container-low mb-10 drop-shadow-md hero-text" style="will-change: transform, opacity;">
    <?php echo esc_html($hero_desc); ?>
</p>
<div class="flex flex-col sm:flex-row gap-4 justify-center hero-cta" style="will-change: transform, opacity;">
<a class="bg-primary text-on-primary font-body font-bold text-lg py-4 px-8 rounded-xl hover:bg-primary/90 transition-colors soft-shadow" href="<?php echo esc_url($hero_btn1_link); ?>">
    <?php echo esc_html($hero_btn1); ?>
</a>
<a class="bg-surface text-primary border-2 border-surface font-body font-bold text-lg py-4 px-8 rounded-xl hover:bg-surface-container-low transition-colors soft-shadow" href="#contatti">
    <?php echo esc_html($hero_btn2); ?>
</a>
</div>
</div>
</div>
</header>

<!-- CHI SIAMO -->
<section class="py-24 px-6 bg-surface gsap-story overflow-hidden" id="chisiamo">
<div class="max-w-6xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-16 items-center story-container">
<div class="relative story-image-block" style="will-change: transform, opacity;">
<div class="absolute -inset-4 bg-tertiary-fixed rounded-xl transform -rotate-2 opacity-50"></div>
<img alt="<?php echo esc_attr($chi_siamo_title); ?>" class="relative z-10 rounded-xl w-full h-auto object-cover soft-shadow story-image" src="<?php echo esc_url($chi_siamo_image); ?>" style="will-change: transform;"/>
</div>
<div class="story-text-block" style="will-change: transform, opacity;">
<h2 class="font-headline text-3xl md:text-4xl text-primary mb-6"><?php echo esc_html($chi_siamo_title); ?></h2>
<?php echo $chi_siamo_text; ?>
</div>
</div>
</section>

<!-- I NOSTRI PRODOTTI (Bento Grid) -->
<section class="py-24 px-6 bg-surface-container-low gsap-features" id="prodotti">
<div class="max-w-7xl mx-auto">
<div class="text-center mb-16">
<h2 class="font-headline text-3xl md:text-4xl text-primary mb-4"><?php echo esc_html( get_theme_mod( 'melaverde_prodotti_title', 'I Nostri Prodotti' ) ); ?></h2>
<p class="font-body text-lg text-on-surface-variant max-w-2xl mx-auto"><?php echo esc_html( get_theme_mod( 'melaverde_prodotti_subtitle', "Selezionati con cura per offrire solo l'eccellenza alla tua tavola, dai campi freschi alle cantine stagionate." ) ); ?></p>
</div>
<div class="grid grid-cols-1 md:grid-cols-3 gap-6 auto-rows-[250px] features-grid">
<!-- Frutta e verdura -->
<div class="feature-card md:col-span-2 md:row-span-2 relative rounded-xl overflow-hidden group cursor-pointer soft-shadow" style="will-change: transform, opacity;">
<img alt="<?php echo esc_attr( $prodotti_cards[1]['title'] ); ?>" class="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" src="<?php echo esc_url( $prodotti_cards[1]['image'] ); ?>"/>
<div class="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent"></div>
<div class="absolute bottom-0 left-0 p-8 w-full">
<h3 class="font-headline text-2xl md:text-3xl text-white mb-2"><?php echo esc_html( $prodotti_cards[1]['title'] ); ?></h3>
<p class="font-body text-surface-container-high opacity-0 group-hover:opacity-100 transition-all duration-300 transform translate-y-4 group-hover:translate-y-0"><?php echo esc_html( $prodotti_cards[1]['desc'] ); ?></p>
</div>
</div>
<!-- Latticini -->
<div class="feature-card relative rounded-xl overflow-hidden group cursor-pointer soft-shadow bg-surface" style="will-change: transform, opacity;">
<img alt="<?php echo esc_attr( $prodotti_cards[2]['title'] ); ?>" class="absolute inset-0 w-full h-full object-cover object-[50%_80%] transition-transform duration-700 group-hover:scale-105" src="<?php echo esc_url( $prodotti_cards[2]['image'] ); ?>"/>
<div class="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent"></div>
<div class="absolute bottom-0 left-0 p-6 w-full">
<h3 class="font-headline text-2xl text-white mb-2"><?php echo esc_html( $prodotti_cards[2]['title'] ); ?></h3>
<p class="font-body text-surface-container-high text-sm opacity-0 group-hover:opacity-100 transition-all duration-300 transform translate-y-4 group-hover:translate-y-0"><?php echo esc_html( $prodotti_cards[2]['desc'] ); ?></p>
</div>
</div>
<!-- Salumi -->
<div class="feature-card relative rounded-xl overflow-hidden group cursor-pointer soft-shadow" style="will-change: transform, opacity;">
<img alt="<?php echo esc_attr( $prodotti_cards[3]['title'] ); ?>" class="absolute inset-0 w-full h-full object-cover object-[50%_80%] transition-transform duration-700 group-hover:scale-105" src="<?php echo esc_url( $prodotti_cards[3]['image'] ); ?>"/>
<div class="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent"></div>
<div class="absolute bottom-0 left-0 p-6 w-full">
<h3 class="font-headline text-2xl text-white mb-2"><?php echo esc_html( $prodotti_cards[3]['title'] ); ?></h3>
<p class="font-body text-surface-container-high text-sm opacity-0 group-hover:opacity-100 transition-all duration-300 transform translate-y-4 group-hover:translate-y-0"><?php echo esc_html( $prodotti_cards[3]['desc'] ); ?></p>
</div>
</div>
<!-- Formaggi -->
<div class="feature-card relative rounded-xl overflow-hidden group cursor-pointer soft-shadow" style="will-change: transform, opacity;">
<img alt="<?php echo esc_attr( $prodotti_cards[4]['title'] ); ?>" class="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" src="<?php echo esc_url( $prodotti_cards[4]['image'] ); ?>"/>
<div class="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent"></div>
<div class="absolute bottom-0 left-0 p-6 w-full">
<h3 class="font-headline text-2xl text-white mb-2"><?php echo esc_html( $prodotti_cards[4]['title'] ); ?></h3>
<p class="font-body text-surface-container-high text-sm opacity-0 group-hover:opacity-100 transition-all duration-300 transform translate-y-4 group-hover:translate-y-0"><?php echo esc_html( $prodotti_cards[4]['desc'] ); ?></p>
</div>
</div>
<!-- Km 0 -->
<div class="feature-card md:col-span-2 relative rounded-xl overflow-hidden group cursor-pointer soft-shadow bg-tertiary-container flex items-center justify-center p-8" style="will-change: transform, opacity;">
<div class="text-center z-10">
<span class="material-symbols-outlined block mx-auto text-5xl text-on-tertiary-container mb-4" style="font-variation-settings: 'FILL' 1;">local_shipping</span>
<h3 class="font-headline text-2xl md:text-3xl text-on-tertiary-container mb-2 relative inline-block">
<?php echo esc_html( $prodotti_cards[5]['title'] ); ?>
<svg class="absolute w-[105%] h-[12px] -bottom-1 -left-[2.5%] text-[#4a7c59] opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none" viewBox="0 0 100 15" preserveAspectRatio="none">
<path d="M2,12 Q30,2 60,10 T98,12" pathLength="1" stroke="currentColor" stroke-width="3" stroke-linecap="round" fill="none" class="transition-all duration-700 ease-out hand-drawn-line delay-100" style="stroke-dasharray: 1; stroke-dashoffset: 1;" />
</svg>
</h3>
<p class="font-body text-on-tertiary-container/80 text-lg"><?php echo esc_html( $prodotti_cards[5]['desc'] ); ?></p>
</div>
<div class="absolute inset-0 bg-white/10 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
</div>
</div>
</div>
</section>

<!-- GALLERIA -->
<section class="py-24 px-6 bg-background gsap-galleria" id="galleria">
<div class="max-w-7xl mx-auto">
<div class="text-center mb-16">
<h2 class="font-headline text-3xl md:text-4xl text-primary mb-4"><?php echo esc_html( get_theme_mod( 'melaverde_galleria_title', 'Scatti di Freschezza' ) ); ?></h2>
<p class="font-body text-lg text-on-surface-variant max-w-2xl mx-auto">
    <?php echo esc_html( get_theme_mod( 'melaverde_galleria_subtitle', "Un'occhiata all'interno del nostro negozio e ai prodotti che selezioniamo ogni giorno per voi." ) ); ?>
</p>
</div>
<div class="grid grid-cols-2 md:grid-cols-4 gap-4 auto-rows-[200px]">
    <?php 
    $gallery_classes = [
        'col-span-2 row-span-2',
        '', // 1x1
        '', // 1x1
        '', // 1x1
        '', // 1x1
        'col-span-2', // width 2
        'col-span-2'  // width 2
    ];
    foreach($gallery_images as $i => $img): 
        $cls = isset($gallery_classes[$i % 7]) ? $gallery_classes[$i % 7] : '';
        $url = is_array($img) && isset($img['url']) ? $img['url'] : (is_string($img) ? $img : '');
        $alt = is_array($img) && isset($img['alt']) ? $img['alt'] : 'Galleria Mela Verde';
    ?>
    <div class="<?php echo $cls; ?> rounded-xl overflow-hidden soft-shadow group">
        <img alt="<?php echo esc_attr($alt); ?>" class="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" src="<?php echo esc_url($url); ?>"/>
    </div>
    <?php endforeach; ?>
</div>
</div>
</section>

<!-- DOVE TROVARCI -->
<section class="py-24 px-6 bg-surface gsap-contatti overflow-hidden" id="contatti">
<div class="max-w-7xl mx-auto">
<?php
$contatti_subtitle_tpl = get_theme_mod( 'melaverde_contatti_subtitle', 'Siamo in {indirizzo}. Passa a scoprire i nostri prodotti freschi.' );
// Senza indirizzo nel CMS il segnaposto resterebbe un buco ("Siamo in ."): meglio non mostrare la frase.
$contatti_subtitle = ( $contact_address === '' && strpos( $contatti_subtitle_tpl, '{indirizzo}' ) !== false )
    ? ''
    : str_replace( '{indirizzo}', $contact_address, $contatti_subtitle_tpl );

// Le colonne seguono i riquadri davvero presenti, così non restano buchi nella griglia.
$contatti_cards_count = ( $contact_email !== '' ? 1 : 0 ) + ( $contact_phones ? 1 : 0 ) + ( $contact_address !== '' ? 1 : 0 ) + ( $contact_hours ? 1 : 0 );
$contatti_grid_cols   = array( 1 => 'lg:grid-cols-1 max-w-sm mx-auto', 2 => 'lg:grid-cols-2', 3 => 'lg:grid-cols-3', 4 => 'lg:grid-cols-4' );
?>
<div class="text-center mb-12 contatti-header" style="will-change: transform, opacity;">
<h2 class="font-headline text-3xl md:text-4xl text-primary mb-4"><?php echo esc_html( get_theme_mod( 'melaverde_contatti_title', 'Vieni a trovarci a Bellinzona' ) ); ?></h2>
<?php if ( $contatti_subtitle !== '' ) : ?>
<p class="font-body text-lg text-on-surface-variant max-w-2xl mx-auto">
    <?php echo esc_html( $contatti_subtitle ); ?>
</p>
<?php endif; ?>
</div>

<?php if ( $contatti_cards_count > 0 ) : ?>
<div class="grid grid-cols-1 md:grid-cols-2 <?php echo esc_attr( $contatti_grid_cols[ $contatti_cards_count ] ); ?> gap-6 mb-12">
<?php if ( $contact_email !== '' ) : ?>
<div class="bg-surface-container-low p-6 rounded-xl flex flex-col items-center text-center soft-shadow contatti-card" style="will-change: transform, opacity;">
<span class="material-symbols-outlined text-4xl text-primary mb-4" style="font-variation-settings: 'FILL' 1;">mail</span>
<h3 class="font-headline text-xl text-on-surface mb-2">Email</h3>
<a class="font-body text-on-surface-variant hover:text-primary transition-colors text-sm break-all" href="mailto:<?php echo esc_attr( antispambot( $contact_email ) ); ?>"><?php echo esc_html( antispambot( $contact_email ) ); ?></a>
</div>
<?php endif; ?>
<?php if ( $contact_phones ) : ?>
<div class="bg-surface-container-low p-6 rounded-xl flex flex-col items-center text-center soft-shadow contatti-card" style="will-change: transform, opacity;">
<span class="material-symbols-outlined text-4xl text-primary mb-4" style="font-variation-settings: 'FILL' 1;">phone</span>
<h3 class="font-headline text-xl text-on-surface mb-2">Telefono</h3>
<?php foreach ( $contact_phones as $melaverde_phone_digits => $melaverde_phone_label ) : ?>
<a class="font-body text-on-surface-variant hover:text-primary transition-colors text-sm" href="tel:<?php echo esc_attr( $melaverde_phone_digits ); ?>"><?php echo esc_html( $melaverde_phone_label ); ?></a>
<?php endforeach; ?>
</div>
<?php endif; ?>
<?php if ( $contact_address !== '' ) : ?>
<div class="bg-surface-container-low p-6 rounded-xl flex flex-col items-center text-center soft-shadow contatti-card" style="will-change: transform, opacity;">
<span class="material-symbols-outlined text-4xl text-primary mb-4" style="font-variation-settings: 'FILL' 1;">location_on</span>
<h3 class="font-headline text-xl text-on-surface mb-2">Indirizzo</h3>
<p class="font-body text-on-surface-variant text-sm"><?php echo esc_html( $contact_address ); ?></p>
</div>
<?php endif; ?>
<?php if ( $contact_hours ) : ?>
<div class="bg-surface-container-low p-6 rounded-xl flex flex-col items-center text-center soft-shadow contatti-card" style="will-change: transform, opacity;">
<span class="material-symbols-outlined text-4xl text-primary mb-4" style="font-variation-settings: 'FILL' 1;">schedule</span>
<h3 class="font-headline text-xl text-on-surface mb-4">Orari</h3>
<div class="w-full font-body text-sm text-on-surface-variant flex flex-col gap-1 text-left">
<?php
$melaverde_hours_last = count( $contact_hours ) - 1;
foreach ( $contact_hours as $melaverde_i => $melaverde_day ) :
    $melaverde_row_class  = $melaverde_i === 0 ? 'pb-1' : ( $melaverde_i === $melaverde_hours_last ? 'pt-1' : 'py-1' );
    $melaverde_row_class .= $melaverde_i === $melaverde_hours_last ? '' : ' border-b border-stone-200/50';
    $melaverde_text_class = $melaverde_day['closed'] ? 'text-red-700/80' : 'text-stone-600';
?>
    <div class="flex justify-between gap-3 <?php echo esc_attr( $melaverde_row_class ); ?>"><span><?php echo esc_html( $melaverde_day['label'] ); ?></span><span class="font-semibold text-right <?php echo esc_attr( $melaverde_text_class ); ?>"><?php echo esc_html( $melaverde_day['text'] ); ?></span></div>
<?php endforeach; ?>
</div>
<?php if ( $contact_hours_note !== '' ) : ?>
<p class="font-body text-xs text-on-surface-variant mt-3"><?php echo esc_html( $contact_hours_note ); ?></p>
<?php endif; ?>
</div>
<?php endif; ?>
</div>
<?php endif; ?>

<div class="grid grid-cols-1 <?php echo $contact_address !== '' ? 'lg:grid-cols-2' : 'max-w-3xl mx-auto'; ?> gap-8 contatti-map" style="will-change: transform, opacity;">
<?php if ( $contact_address !== '' ) : ?>
<!-- Mappa: segue l'indirizzo del ticinoWEB CMS -->
<div class="w-full h-[400px] lg:h-auto min-h-[400px] rounded-3xl overflow-hidden soft-shadow relative">
<iframe frameborder="0" height="100%" marginheight="0" marginwidth="0" scrolling="no" src="https://maps.google.com/maps?q=<?php echo rawurlencode( $contact_address ); ?>&amp;t=&amp;z=15&amp;ie=UTF8&amp;iwloc=&amp;output=embed" style="filter: contrast(0.9) sepia(0.3) hue-rotate(50deg) saturate(0.8) brightness(0.95);" width="100%" class="absolute inset-0" title="<?php echo esc_attr( $contact_address ); ?>"></iframe>
</div>
<?php endif; ?>

<!-- Form -->
<div class="bg-white p-8 md:p-10 rounded-3xl soft-shadow flex flex-col justify-center">
    <h3 class="font-headline text-3xl md:text-4xl text-on-surface mb-8 italic font-light tracking-wide"><?php echo esc_html( get_theme_mod( 'melaverde_form_title', 'Contattaci per informazioni' ) ); ?></h3>
    <?php
    // Invio con il gestore del parent (ticinoweb_submit_form): il messaggio finisce in
    // ticinoWEB CMS → Invii Ricevuti e parte per email all'indirizzo di contatto del CMS.
    $melaverde_privacy_url = get_privacy_policy_url() ?: home_url( '/privacy-policy/' );
    $melaverde_input_class = 'w-full bg-transparent border border-stone-300 rounded-lg py-3 px-4 focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary transition-colors aria-[invalid=true]:border-red-700';
    ?>
    <form class="flex flex-col gap-6" data-melaverde-contact-form novalidate data-ajax-url="<?php echo esc_url( admin_url( 'admin-ajax.php' ) ); ?>" data-fallback-mail="<?php echo esc_attr( antispambot( $contact_email ) ); ?>">
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div class="flex flex-col gap-2">
                <label for="mv-nome" class="font-body text-[15px] font-medium text-stone-700">Nome*</label>
                <input id="mv-nome" name="nome" type="text" autocomplete="name" maxlength="120" class="<?php echo esc_attr( $melaverde_input_class ); ?>" required aria-describedby="mv-err-nome">
                <span id="mv-err-nome" class="font-body text-sm text-red-700" data-error-for="nome"></span>
            </div>
            <div class="flex flex-col gap-2">
                <label for="mv-email" class="font-body text-[15px] font-medium text-stone-700">Email*</label>
                <input id="mv-email" name="email" type="email" autocomplete="email" maxlength="190" class="<?php echo esc_attr( $melaverde_input_class ); ?>" required aria-describedby="mv-err-email">
                <span id="mv-err-email" class="font-body text-sm text-red-700" data-error-for="email"></span>
            </div>
        </div>

        <div class="flex flex-col gap-2">
            <label for="mv-messaggio" class="font-body text-[15px] font-medium text-stone-700">Messaggio*</label>
            <textarea id="mv-messaggio" name="messaggio" rows="4" maxlength="5000" class="<?php echo esc_attr( $melaverde_input_class ); ?> resize-none" required aria-describedby="mv-err-messaggio"></textarea>
            <span id="mv-err-messaggio" class="font-body text-sm text-red-700" data-error-for="messaggio"></span>
        </div>

        <!-- Campo trappola per i bot: le persone non lo vedono e resta vuoto. -->
        <div aria-hidden="true" style="position:absolute;left:-9999px;width:1px;height:1px;overflow:hidden;">
            <label for="mv-hp">Lascia vuoto</label>
            <input id="mv-hp" type="text" name="tw_hp" tabindex="-1" autocomplete="off">
        </div>

        <div class="flex flex-col gap-1">
            <label class="flex items-start gap-3 font-body text-sm text-stone-700 cursor-pointer">
                <input type="checkbox" name="privacy" value="1" class="mt-1 h-4 w-4 accent-[#4a7c59] shrink-0" required aria-describedby="mv-err-privacy">
                <span>Ho letto la <a href="<?php echo esc_url( $melaverde_privacy_url ); ?>" class="underline underline-offset-4 hover:text-primary" target="_blank" rel="noopener">Privacy Policy</a> e acconsento al trattamento dei miei dati per ricevere una risposta.*</span>
            </label>
            <span id="mv-err-privacy" class="font-body text-sm text-red-700" data-error-for="privacy"></span>
        </div>

        <div class="flex flex-wrap items-center gap-4 mt-2">
            <button type="submit" class="bg-primary hover:bg-primary-container hover:text-on-primary-container text-white font-body font-semibold text-lg py-3 px-12 rounded-full w-fit transition-colors disabled:opacity-60 disabled:cursor-wait">
                Invia
            </button>
            <p class="font-body text-sm text-stone-600" role="status" aria-live="polite" data-form-status></p>
        </div>
    </form>
    <div class="hidden flex-col items-start gap-3" data-form-success tabindex="-1">
        <span class="material-symbols-outlined text-5xl text-primary" style="font-variation-settings: 'FILL' 1;" aria-hidden="true">check_circle</span>
        <p class="font-body text-lg text-on-surface" data-form-success-text></p>
    </div>
</div>
</div>
</div>
</section>

<!-- Footer Shared Component -->
<footer class="w-full py-12 px-8 bg-stone-100 dark:bg-stone-950 border-t border-stone-200 dark:border-stone-800 transition-all duration-200">
<div class="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-7xl mx-auto">
<div class="flex flex-col gap-4">
<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="font-['Literata'] text-xl font-bold text-[#4a7c59] mb-3 block w-fit hover:opacity-80 transition-opacity">
                    <?php if ( !empty($logo_url) ) : ?>
                        <img src="<?php echo esc_url( $logo_url ); ?>" alt="Mela Verde Logo" class="h-24 w-auto object-contain drop-shadow-sm -ml-2">
                    <?php else : ?>
                        Mela Verde
                    <?php endif; ?>
                </a>
<p class="font-['Nunito_Sans'] text-stone-600 dark:text-stone-400 text-sm flex flex-col md:flex-row gap-2 md:gap-4 items-start md:items-center">
                    <span>© <?php echo date('Y'); ?> <?php echo esc_html( get_theme_mod( 'melaverde_footer_copyright', 'Mela Verde Bellinzona. Tutti i diritti riservati.' ) ); ?></span>
                    <span class="hidden md:inline text-stone-300">|</span>
                    <?php if ( function_exists('get_privacy_policy_url') && get_privacy_policy_url() ) : ?>
                        <a href="<?php echo esc_url(get_privacy_policy_url()); ?>" class="hover:text-[#4a7c59] transition-colors underline decoration-transparent hover:decoration-[#4a7c59] underline-offset-4"><?php echo esc_html( get_theme_mod( 'melaverde_footer_privacy_label', 'Privacy Policy' ) ); ?></a>
                    <?php else: ?>
                        <a href="<?php echo esc_url(home_url('/privacy-policy/')); ?>" class="hover:text-[#4a7c59] transition-colors underline decoration-transparent hover:decoration-[#4a7c59] underline-offset-4"><?php echo esc_html( get_theme_mod( 'melaverde_footer_privacy_label', 'Privacy Policy' ) ); ?></a>
                    <?php endif; ?>
                    <span class="hidden md:inline text-stone-300">|</span>
                    <a href="<?php echo esc_url( wp_login_url() ); /* /tw-login/ del parent: wp-admin dà 404 ai visitatori */ ?>" rel="nofollow" class="hover:text-[#4a7c59] transition-colors underline decoration-transparent hover:decoration-[#4a7c59] underline-offset-4"><?php echo esc_html( get_theme_mod( 'melaverde_footer_area_riservata', 'Area Riservata' ) ); ?></a>
                </p>
<p class="font-['Nunito_Sans'] text-stone-400 dark:text-stone-500 text-xs mt-1">
                    Design by <a href="https://ticinoweb.com/" target="_blank" rel="noopener noreferrer" class="font-bold text-stone-500 hover:text-[#4a7c59] transition-colors">ticinoWEB</a>
                </p>
</div>
<div class="flex flex-col gap-3">
<a class="font-['Nunito_Sans'] text-stone-500 hover:text-[#4a7c59] hover:underline decoration-[#4a7c59] underline-offset-4 transition-all duration-200" href="#home"><?php echo esc_html( $nav_home ); ?></a>
<a class="font-['Nunito_Sans'] text-stone-500 hover:text-[#4a7c59] hover:underline decoration-[#4a7c59] underline-offset-4 transition-all duration-200" href="#chisiamo"><?php echo esc_html( $nav_chisiamo ); ?></a>
<a class="font-['Nunito_Sans'] text-stone-500 hover:text-[#4a7c59] hover:underline decoration-[#4a7c59] underline-offset-4 transition-all duration-200" href="#prodotti"><?php echo esc_html( $nav_prodotti ); ?></a>
<a class="font-['Nunito_Sans'] text-stone-500 hover:text-[#4a7c59] hover:underline decoration-[#4a7c59] underline-offset-4 transition-all duration-200" href="#contatti"><?php echo esc_html( $nav_contatti ); ?></a>
</div>
<div class="flex flex-col gap-4">
</div>
</div>
</footer>

<!-- LIGHTBOX GALLERY -->
<div id="gallery-lightbox" class="fixed inset-0 z-[9999] bg-stone-950/95 backdrop-blur-md opacity-0 pointer-events-none transition-opacity duration-500 flex items-center justify-center">
    <button id="lightbox-close" class="absolute top-6 right-6 text-stone-400 hover:text-white transition-colors z-[10000]">
        <span class="material-symbols-outlined text-4xl">close</span>
    </button>
    <button id="lightbox-prev" class="absolute left-4 md:left-12 top-1/2 transform -translate-y-1/2 text-stone-400 hover:text-white transition-colors z-[10000]">
        <span class="material-symbols-outlined text-6xl">chevron_left</span>
    </button>
    <button id="lightbox-next" class="absolute right-4 md:right-12 top-1/2 transform -translate-y-1/2 text-stone-400 hover:text-white transition-colors z-[10000]">
        <span class="material-symbols-outlined text-6xl">chevron_right</span>
    </button>
    <div class="relative w-full max-w-6xl px-4 md:px-24 h-[85vh] flex items-center justify-center">
        <img id="lightbox-img" src="" alt="" class="max-w-full max-h-full object-contain rounded-xl shadow-2xl scale-90 transition-all duration-300 ease-out" />
    </div>
</div>

<script>
document.addEventListener("DOMContentLoaded", () => {
    // 0. MOBILE MENU LOGIC
    const mobileBtn = document.getElementById('mobile-menu-btn');
    const mobileCloseBtn = document.getElementById('mobile-menu-close');
    const mobileOverlay = document.getElementById('mobile-menu-overlay');
    const mobileLinks = document.querySelectorAll('.mobile-nav-link');

    if (mobileBtn && mobileOverlay) {
        function toggleMobileMenu() {
            const isOpen = !mobileOverlay.classList.contains('translate-x-full');
            if (isOpen) {
                mobileOverlay.classList.add('translate-x-full');
                document.body.style.overflow = '';
            } else {
                mobileOverlay.classList.remove('translate-x-full');
                document.body.style.overflow = 'hidden';
            }
        }
        mobileBtn.addEventListener('click', toggleMobileMenu);
        if (mobileCloseBtn) mobileCloseBtn.addEventListener('click', toggleMobileMenu);
        mobileLinks.forEach(link => link.addEventListener('click', toggleMobileMenu));
    }

    const initGSAP = () => {
        if (typeof window.gsap === 'undefined' || typeof window.ScrollTrigger === 'undefined') {
            setTimeout(initGSAP, 50);
            return;
        }
        
        const gsap = window.gsap;
        const ScrollTrigger = window.ScrollTrigger;
        gsap.registerPlugin(ScrollTrigger);
        const appleEase = "power3.out";
        let mm = gsap.matchMedia();

        // 0A. SCROLL SPY (Indicatore Mela Verde) - Bulletproof Native JS Absolute
        const sectionsIds = ["home", "chisiamo", "prodotti", "galleria", "contatti"];
        
        function updateAppleMarker(id) {
            document.querySelectorAll('.nav-dot').forEach(el => el.classList.remove('active'));
            const activeDot = document.querySelector(`.nav-dot[data-target="${id}"]`);
            if(activeDot) activeDot.classList.add('active');

            // Header Nav Link Highlighting (Magic Line)
            const indicator = document.getElementById("nav-indicator");
            const navContainer = document.getElementById("header-nav-container");

            document.querySelectorAll('.header-nav-link').forEach(el => {
                el.classList.remove('text-[#4a7c59]', 'active');
                el.classList.add('text-stone-600', 'dark:text-stone-400');
            });
            const activeHeader = document.querySelector(`.header-nav-link[data-target="${id}"]`);
            if (activeHeader) {
                activeHeader.classList.remove('text-stone-600', 'dark:text-stone-400');
                activeHeader.classList.add('text-[#4a7c59]', 'active');
                
                if(indicator && navContainer) {
                    const rect = activeHeader.getBoundingClientRect();
                    const containerRect = navContainer.getBoundingClientRect();
                    indicator.style.width = `${rect.width}px`;
                    indicator.style.transform = `translateX(${rect.left - containerRect.left}px)`;
                }
            }

            // Mobile Nav Link Highlighting
            document.querySelectorAll('.mobile-nav-link').forEach(el => {
                el.classList.remove('text-[#4a7c59]', 'active');
                el.classList.add('text-stone-600', 'dark:text-stone-300');
            });
            const activeMobile = document.querySelector(`.mobile-nav-link[data-target="${id}"]`);
            if (activeMobile) {
                activeMobile.classList.remove('text-stone-600', 'dark:text-stone-300');
                activeMobile.classList.add('text-[#4a7c59]', 'active');
            }
        }

        window.addEventListener('scroll', () => {
            let current = 'home';
            sectionsIds.forEach(id => {
                const el = document.getElementById(id);
                if (el) {
                    const rect = el.getBoundingClientRect();
                    // Se la sezione lambisce o oltrepassa il terzo superiore dello schermo, diventa attiva
                    if (rect.top <= window.innerHeight * 0.35) {
                        current = id;
                    }
                }
            });
            updateAppleMarker(current);
        });
        // Inizializza stato al caricamento
        window.dispatchEvent(new Event('scroll'));

        // 0. ANCHOR JUMP LISTENER ADVANCED (Risoluzione bug "pin spacer" e Completamento Immediato)
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function(e) {
                const targetId = this.getAttribute("href");
                if(targetId === "#") return;
                const targetEl = document.querySelector(targetId);
                if (targetEl) {
                    e.preventDefault(); // Blocca lo scatto nativo sballato
                    // GSAP capisce esattamente dove si trova di fatto la sezione sommando tutti i pin precedenti
                    let st = ScrollTrigger.create({ trigger: targetEl, start: "top top" });
                    let yPos = st.start;
                    st.kill(); 

                    // Saltiamo precisamente alla coordinata depurata
                    window.scrollTo({ top: yPos, behavior: 'auto' });
                    
                    // Mostriamo subito tutto l'esito già svelato
                    ScrollTrigger.getAll().forEach(trig => {
                        if (trig.animation) {
                            trig.animation.progress(1);
                        }
                    });
                    gsap.set(".feature-card, .story-text-block, .story-image-block, .contatti-header, .contatti-card, .contatti-map", { opacity: 1, y: 0, x: 0, scale: 1 });
                }
            });
        });

        // 1. HERO ANIMATION
        gsap.set(".hero-title, .hero-text, .hero-cta", { y: 40, opacity: 0 });
        gsap.set(".hero-image", { scale: 1.05, opacity: 0 });

    const heroTl = gsap.timeline({ defaults: { ease: appleEase, duration: 1.2 }});
    heroTl.to(".hero-title", { y: 0, opacity: 1, duration: 1 })
          .to(".hero-text", { y: 0, opacity: 1 }, "-=0.8")
          .to(".hero-cta", { y: 0, opacity: 1 }, "-=0.8")
          .to(".hero-image", { scale: 1, opacity: 1, duration: 1.8 }, "-=1");

    // Lo zoom scrub della hero è stato rimosso in base alle tue indicazioni!

    // 2. FEATURES (Clean Stagger Fade Up)
    // Apparizione morbida una dopo l'altra senza effetti esagerati 3D
    gsap.set(".feature-card", { opacity: 0, y: 30 }); 
    ScrollTrigger.create({
        trigger: ".gsap-features",
        start: "top 85%",
        once: true,
        onEnter: () => {
            gsap.to(".feature-card", {
                opacity: 1,
                y: 0,
                duration: 0.8,
                ease: "power2.out",
                stagger: 0.15
            });
        }
    });

    // 3. STORY (Ripristino Scroll Pin e Scrub)
    // Come richiesto: l'animazione di scorrimento reale con freeze dello schermo torna operativa!
    mm.add("(min-width: 769px)", () => {
        const storyTl = gsap.timeline({
            scrollTrigger: {
                trigger: ".gsap-story",
                start: "center center", 
                end: "+=50%",
                pin: true,
                scrub: 0.5 
            }
        });

        // Rivelazione spaziale al passaggio del mouse
        storyTl.fromTo(".story-text-block", 
            { x: 50, opacity: 0 }, 
            { x: 0, opacity: 1, duration: 1 }
        );
        storyTl.fromTo(".story-image-block", 
            { scale: 1 }, 
            { scale: 1.05, duration: 1 }, 
            "<"
        );
    });

    mm.add("(max-width: 768px)", () => {
        gsap.from(".story-image-block, .story-text-block", {
            scrollTrigger: { trigger: ".gsap-story", start: "top 90%" },
            y: 30,
            opacity: 0,
            duration: 0.8,
            stagger: 0.2,
            ease: appleEase
        });
    });

    // 4. NUOVA: CONTATTI (Pure Fade / Opacity)
    gsap.set(".contatti-header", { opacity: 0 });
    gsap.set(".contatti-card", { opacity: 0 });
    gsap.set(".contatti-map", { opacity: 0 });

    ScrollTrigger.create({
        trigger: ".gsap-contatti",
        start: "top 90%", 
        once: true,
        onEnter: () => {
            const contattiTl = gsap.timeline();
            contattiTl.to(".contatti-header", { opacity: 1, duration: 1, ease: "power2.inOut" })
                      .to(".contatti-card", { opacity: 1, duration: 1, ease: "power2.inOut", stagger: 0.15 }, "-=0.5")
                      .to(".contatti-map", { opacity: 1, duration: 1, ease: "power2.inOut" }, "-=0.5");
        }
    });

    }; // End of initGSAP
    initGSAP(); // Launch initializer loop

    // 5. LIGHTBOX LOGIC
    const lightbox = document.getElementById("gallery-lightbox");
    const lightboxImg = document.getElementById("lightbox-img");
    const lightboxClose = document.getElementById("lightbox-close");
    const lightboxPrev = document.getElementById("lightbox-prev");
    const lightboxNext = document.getElementById("lightbox-next");
    const galleryItems = document.querySelectorAll("#galleria .group"); 
    
    const imagesList = Array.from(galleryItems).map(item => item.querySelector("img"));
    let currentIdx = 0;

    function openLightbox(index) {
        currentIdx = index;
        updateLightbox();
        lightbox.classList.remove("opacity-0", "pointer-events-none");
        lightbox.classList.add("opacity-100");
        document.body.style.overflow = "hidden";
        setTimeout(() => {
            lightboxImg.classList.remove("scale-90");
            lightboxImg.classList.add("scale-100");
        }, 50);
    }

    function closeLightbox() {
        lightbox.classList.remove("opacity-100");
        lightbox.classList.add("opacity-0", "pointer-events-none");
        lightboxImg.classList.remove("scale-100");
        lightboxImg.classList.add("scale-90");
        document.body.style.overflow = "";
    }

    function updateLightbox() {
        lightboxImg.style.opacity = 0;
        setTimeout(() => {
            if (imagesList[currentIdx]) {
                lightboxImg.src = imagesList[currentIdx].src;
                lightboxImg.alt = imagesList[currentIdx].alt;
            }
            lightboxImg.style.opacity = 1;
        }, 150);
    }

    function goNext() {
        currentIdx = (currentIdx + 1) % imagesList.length;
        updateLightbox();
    }

    function goPrev() {
        currentIdx = (currentIdx - 1 + imagesList.length) % imagesList.length;
        updateLightbox();
    }

    imagesList.forEach((img, index) => {
        if(img) {
            const container = img.closest(".group");
            if(container) {
                container.style.cursor = "pointer";
                container.addEventListener("click", () => openLightbox(index));
            }
        }
    });

    if (lightboxClose) lightboxClose.addEventListener("click", closeLightbox);
    if (lightboxNext) lightboxNext.addEventListener("click", goNext);
    if (lightboxPrev) lightboxPrev.addEventListener("click", goPrev);

    if (lightbox) {
        lightbox.addEventListener("click", (e) => {
            if (e.target === lightbox || e.target.closest('div.relative.w-full')) {
                if(e.target !== lightboxImg && !e.target.closest('button')) {
                    closeLightbox();
                }
            }
        });
    }

    document.addEventListener("keydown", (e) => {
        if (lightbox && lightbox.classList.contains("opacity-100")) {
            if (e.key === "Escape") closeLightbox();
            if (e.key === "ArrowRight") goNext();
            if (e.key === "ArrowLeft") goPrev();
        }
    });

});
</script>

<?php get_footer(); ?>
