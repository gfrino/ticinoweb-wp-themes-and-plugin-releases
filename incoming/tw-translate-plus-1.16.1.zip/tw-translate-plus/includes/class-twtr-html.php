<?php
/**
 * Page-level translation: the finished HTML of every translated page is
 * scanned and each visible text (plus alt, title, placeholder, aria-label,
 * button values and SEO meta) is translated, like a browser translator
 * does — but stored, indexable and cached.
 *
 * Why: the WordPress filters (titles, content, terms, widgets…) only see
 * what goes through WordPress. Themes and page builders also print text of
 * their own — template labels, sections built by parsing the content,
 * Elementor widgets, plugin markup — that no filter ever sees. This layer
 * catches all of it, on any theme.
 *
 * Cost: runs only on translated pages and only when the page is generated
 * (LiteSpeed then caches the result). One indexed query by hash per page;
 * new texts are queued (context "html", shared by every page, so a label
 * repeated on 900 products is one row per language) and translated in
 * background.
 *
 * Not translated: script, style, code, pre, textarea, svg, template,
 * noscript, the admin bar, anything inside class="notranslate" or
 * translate="no", texts without letters, and translations already output
 * by the filters in this request.
 *
 * @package tw-translate-plus
 */

if (!defined('ABSPATH')) {
    exit;
}

class Twtr_Html {

    const CONTEXT = 'html';
    const MAX_NEW_PER_PAGE = 300;

    /** Elements whose content is never translated. */
    private static $skip_tags = array('script', 'style', 'code', 'pre', 'textarea', 'svg', 'template', 'noscript', 'math', 'kbd', 'samp', 'var');

    /** @var string Current language slug. */
    private static $locale = '';

    /** @var array<string,string[]> Hashes discovered per post id (for «Traduci adesso»). */
    private static $post_hashes = array();

    public static function init() {
        if (is_admin() || wp_doing_ajax() || wp_doing_cron() || (defined('REST_REQUEST') && REST_REQUEST) || (defined('WP_CLI') && WP_CLI)) {
            return;
        }
        self::$locale = Twtr_Router::current_language();
        if (self::$locale === '' || !apply_filters('twtr_translate_html', true)) {
            return;
        }
        // Early: themes and plugins that print a page and exit inside
        // template_redirect (maintenance pages, landing pages) are covered
        // too. Page caches (LiteSpeed) buffer outside this one, so they store
        // the translated result.
        add_action('template_redirect', array(__CLASS__, 'start'), -10000);
    }

    public static function start() {
        if (is_feed() || is_robots() || is_trackback() || is_embed()) {
            return;
        }
        ob_start(array(__CLASS__, 'filter'));
    }

    /**
     * Output-buffer callback.
     *
     * @param string $html
     * @return string
     */
    public static function filter($html) {
        if (!is_string($html) || $html === '' || stripos($html, '<body') === false) {
            return $html; // not an HTML page (JSON, XML, partial output)
        }
        foreach (headers_list() as $header) {
            if (stripos($header, 'content-type:') === 0 && stripos($header, 'text/html') === false) {
                return $html;
            }
        }
        // Memory guard: tokenizing costs roughly 10x the page size. On a
        // process already close to its limit, serve the page untranslated
        // rather than risk an out-of-memory error.
        $limit = wp_convert_hr_to_bytes((string) ini_get('memory_limit'));
        if (strlen($html) > 4 * MB_IN_BYTES || ($limit > 0 && memory_get_usage(true) + strlen($html) * 12 > $limit * 0.85)) {
            return $html;
        }
        try {
            return self::translate_document($html);
        } catch (Throwable $e) {
            return $html; // never break a page
        }
    }

    /**
     * @param string $html Full document.
     * @return string
     */
    public static function translate_document($html) {
        $locale = self::$locale !== '' ? self::$locale : Twtr_Router::current_language();
        if ($locale === '') {
            return $html;
        }
        $tokens = preg_split('/(<!--.*?-->|<[^>]*>)/s', $html, -1, PREG_SPLIT_DELIM_CAPTURE | PREG_SPLIT_NO_EMPTY);
        if (!$tokens) {
            return $html;
        }

        $segments = array(); // token index => array(kind, data)
        $wanted   = array(); // hash => source text
        $skip_tag = '';
        $depth    = 0;
        $in_body  = false;
        $in_title = false;

        foreach ($tokens as $i => $tok) {
            if ($tok[0] === '<') {
                if (strpos($tok, '<!--') === 0 || strpos($tok, '<!') === 0 || strpos($tok, '<?') === 0) {
                    continue;
                }
                if (!preg_match('/^<\s*(\/?)\s*([a-zA-Z][a-zA-Z0-9:-]*)/', $tok, $m)) {
                    continue;
                }
                $closing = $m[1] === '/';
                $name    = strtolower($m[2]);
                $self    = substr($tok, -2) === '/>';

                if ($skip_tag !== '') {
                    if ($name === $skip_tag && !$self) {
                        $depth += $closing ? -1 : 1;
                        if ($depth <= 0) {
                            $skip_tag = '';
                            $depth    = 0;
                        }
                    }
                    continue;
                }
                if ($name === 'body' && !$closing) {
                    $in_body = true;
                }
                if ($name === 'title') {
                    $in_title = !$closing && !$in_body; // the document title, not an SVG <title>
                }
                if (!$closing) {
                    // Translatable attributes of this tag.
                    $attrs = self::attribute_segments($name, $tok);
                    if ($attrs) {
                        $segments[$i] = array('attr', $attrs);
                        foreach ($attrs as $a) {
                            $wanted[md5($a['text'])] = $a['text'];
                        }
                    }
                    $opaque = in_array($name, self::$skip_tags, true)
                        || preg_match('/\sclass\s*=\s*["\'][^"\']*\bnotranslate\b/i', $tok)
                        || preg_match('/\stranslate\s*=\s*["\']?no\b/i', $tok)
                        || preg_match('/\sid\s*=\s*["\']wpadminbar["\']/i', $tok);
                    if ($opaque && !$self && !in_array($name, array('br', 'img', 'input', 'meta', 'link', 'hr', 'source', 'wbr'), true)) {
                        $skip_tag = $name;
                        $depth    = 1;
                    }
                }
                continue;
            }
            if ($skip_tag !== '' || (!$in_body && !$in_title)) {
                continue;
            }
            $text = trim($tok);
            if (!self::worth($text, $locale)) {
                continue;
            }
            $segments[$i] = array('text', $text);
            $wanted[md5($text)] = $text;
        }

        if (!$segments) {
            return $html;
        }

        $found = self::lookup($locale, array_keys($wanted));

        // Replace.
        $missing = array();
        foreach ($segments as $i => $seg) {
            if ($seg[0] === 'text') {
                $hash = md5($seg[1]);
                if (isset($found[$hash])) {
                    $tok         = $tokens[$i];
                    $lead        = substr($tok, 0, strlen($tok) - strlen(ltrim($tok)));
                    $trail       = substr($tok, strlen(rtrim($tok)));
                    $tokens[$i]  = $lead . self::as_text($found[$hash]) . $trail;
                } else {
                    $missing[$hash] = $seg[1];
                }
                continue;
            }
            $tag = $tokens[$i];
            foreach ($seg[1] as $a) {
                $hash = md5($a['text']);
                if (isset($found[$hash])) {
                    $tag = str_replace($a['full'], $a['prefix'] . esc_attr(self::plain($found[$hash])) . $a['suffix'], $tag);
                } else {
                    $missing[$hash] = $a['text'];
                }
            }
            $tokens[$i] = $tag;
        }

        if ($missing) {
            self::queue($locale, $missing);
        }
        return implode('', $tokens);
    }

    /**
     * Translatable attributes of one opening tag.
     *
     * @return array<int,array{full:string,prefix:string,suffix:string,text:string}>
     */
    private static function attribute_segments($name, $tag) {
        $names = array('title', 'alt', 'placeholder', 'aria-label', 'aria-description', 'data-title', 'data-tooltip');
        if ($name === 'input' && preg_match('/\stype\s*=\s*["\']?(submit|button|reset)\b/i', $tag)) {
            $names[] = 'value';
        }
        if ($name === 'meta' && preg_match('/\s(?:name|property)\s*=\s*["\'](description|og:title|og:description|twitter:title|twitter:description|og:image:alt)["\']/i', $tag)) {
            $names = array('content');
        }
        $out = array();
        if (!preg_match_all('/(\s(' . implode('|', array_map('preg_quote', $names)) . ')\s*=\s*(["\']))(.*?)(\3)/is', $tag, $m, PREG_SET_ORDER)) {
            return $out;
        }
        foreach ($m as $hit) {
            $text = trim(html_entity_decode($hit[4], ENT_QUOTES | ENT_HTML5, 'UTF-8'));
            if (self::worth($text, self::$locale)) {
                $out[] = array('full' => $hit[0], 'prefix' => $hit[1], 'suffix' => $hit[5], 'text' => $text);
            }
        }
        return $out;
    }

    /** Whether a piece of text should be translated. */
    private static function worth($text, $locale) {
        if ($text === '' || mb_strlen($text) > 5000) {
            return false;
        }
        $plain = html_entity_decode($text, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        // Fragment of an attribute whose value contained ">" (the tokenizer
        // split the tag there): never touch it.
        if (preg_match('/^["\'}\]]|=\s*["\']|["\']\s*\/?>?$/', $text)) {
            return false;
        }
        if (!preg_match('/\p{L}{2}/u', $plain)) {
            return false; // numbers, prices, symbols, single letters
        }
        if (preg_match('#^(https?:)?//\S+$#i', $plain) || preg_match('/^[\w.+-]+@[\w-]+\.[\w.]+$/', $plain)) {
            return false; // URLs, e-mail addresses
        }
        // Already a translation produced by the filters in this request.
        return !Twtr_Resolver::is_emitted($locale, $text) && !Twtr_Resolver::is_emitted($locale, $plain);
    }

    /**
     * Ready translations for these hashes, from ANY context of the site: a
     * text translated as part of a title or a menu is reused here for free.
     *
     * @param string   $locale
     * @param string[] $hashes
     * @return array<string,string> hash => translation
     */
    private static function lookup($locale, $hashes) {
        global $wpdb;
        $out = array();
        foreach (array_chunk($hashes, 400) as $chunk) {
            $ph   = implode(',', array_fill(0, count($chunk), '%s'));
            $rows = $wpdb->get_results($wpdb->prepare(
                'SELECT source_hash, translated_text, locked FROM ' . Twtr_Storage::entries_table() .
                " WHERE blog_id = %d AND target_locale = %s AND status = 'ready' AND source_hash IN ({$ph})" .
                ' AND translated_text IS NOT NULL ORDER BY locked ASC',
                array_merge(array(get_current_blog_id(), $locale), $chunk)
            ));
            foreach ((array) $rows as $row) {
                // Manual overrides (locked) come last and win.
                $out[$row->source_hash] = (string) $row->translated_text;
            }
        }
        return $out;
    }

    /**
     * Queue the texts of this page that have no translation yet.
     *
     * @param string               $locale
     * @param array<string,string> $missing hash => text
     */
    private static function queue($locale, $missing) {
        $items = array();
        foreach (array_slice($missing, 0, self::MAX_NEW_PER_PAGE, true) as $hash => $text) {
            $items[] = array('context' => self::CONTEXT, 'hash' => $hash, 'source' => $text, 'locale' => $locale);
        }
        if (!$items) {
            return;
        }
        if (is_singular()) {
            self::remember_for_post((int) get_queried_object_id(), $locale, array_keys($missing));
        }
        $new = Twtr_Storage::insert_pending($items);
        if ($new > 0) {
            twtr_queue();
            Twtr_Queue::schedule();
        }
    }

    /**
     * Hashes of a post's page-level texts, so «Traduci adesso» can translate
     * them first.
     */
    private static function remember_for_post($post_id, $locale, $hashes) {
        if ($post_id > 0) {
            set_transient('twtr_html_' . $post_id . '_' . $locale, array_slice($hashes, 0, 1000), DAY_IN_SECONDS);
        }
    }

    /**
     * @param int    $post_id
     * @param string $locale
     * @return string[] Page-level hashes discovered on the post's page.
     */
    public static function hashes_for_post($post_id, $locale) {
        $h = get_transient('twtr_html_' . (int) $post_id . '_' . $locale);
        return is_array($h) ? $h : array();
    }

    /** A stored translation as safe text for a text node. */
    private static function as_text($translation) {
        return esc_html(self::plain($translation));
    }

    private static function plain($translation) {
        return html_entity_decode(wp_strip_all_tags((string) $translation), ENT_QUOTES | ENT_HTML5, 'UTF-8');
    }
}
