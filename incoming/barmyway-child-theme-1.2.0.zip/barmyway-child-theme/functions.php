<?php
/**
 * Bar my Way — child theme di ticinoweb-ai-theme.
 *
 * Solo presentazione: contatti, orari, servizi, chi siamo, FAQ, recensioni e SEO
 * restano nel CMS del parent (Input First) e qui si leggono soltanto.
 *
 * @package BarMyWayChildTheme
 */

defined( 'ABSPATH' ) || exit;

define( 'BARMYWAY_VERSION', wp_get_theme()->get( 'Version' ) );

add_action(
	'after_setup_theme',
	function () {
		load_child_theme_textdomain( 'barmyway-child-theme', get_stylesheet_directory() . '/languages' );
		add_theme_support( 'responsive-embeds' );
		add_theme_support( 'align-wide' );
		// Il parent carica Poppins da Google Fonts e il proprio style.css: il child è autonomo,
		// con font di sistema (nessun font da terzi).
		remove_action( 'wp_enqueue_scripts', 'ticinoweb_ai_assets' );
	}
);

add_action(
	'wp_enqueue_scripts',
	function () {
		wp_enqueue_style( 'barmyway-style', get_stylesheet_uri(), array(), BARMYWAY_VERSION );
		wp_enqueue_script(
			'barmyway-site',
			get_stylesheet_directory_uri() . '/assets/site.js',
			array(),
			BARMYWAY_VERSION,
			array(
				'in_footer' => true,
				'strategy'  => 'defer',
			)
		);
		$accent = sanitize_hex_color( get_option( 'ticinoweb_palette_primary', '' ) );
		if ( $accent ) {
			wp_add_inline_style( 'barmyway-style', ':root{--bw-accent:' . $accent . ';--bw-accent-deep:color-mix(in srgb,' . $accent . ' 78%,#000);}' );
		}
	},
	20
);

/**
 * Voci di menu di ripiego, finché al sito non è assegnato un menu in Aspetto → Menu.
 * Puntano alle sezioni della home e compaiono solo se la sezione esiste.
 */
function barmyway_fallback_menu() {
	$home  = trailingslashit( home_url( '/' ) );
	$items = array(
		'servizi'    => __( 'Cosa serviamo', 'barmyway-child-theme' ),
		'chi-siamo'  => __( 'Chi siamo', 'barmyway-child-theme' ),
		'orari'      => __( 'Orari', 'barmyway-child-theme' ),
		'faq'        => __( 'Domande', 'barmyway-child-theme' ),
		'contatti'   => __( 'Dove siamo', 'barmyway-child-theme' ),
	);
	echo '<ul class="primary-menu">';
	foreach ( $items as $anchor => $label ) {
		printf( '<li><a href="%s">%s</a></li>', esc_url( $home . '#' . $anchor ), esc_html( $label ) );
	}
	echo '</ul>';
}

/** Giorni della settimana come nel CMS del parent (chiave => etichetta). */
function barmyway_days() {
	return array(
		'monday'    => __( 'Lunedì', 'barmyway-child-theme' ),
		'tuesday'   => __( 'Martedì', 'barmyway-child-theme' ),
		'wednesday' => __( 'Mercoledì', 'barmyway-child-theme' ),
		'thursday'  => __( 'Giovedì', 'barmyway-child-theme' ),
		'friday'    => __( 'Venerdì', 'barmyway-child-theme' ),
		'saturday'  => __( 'Sabato', 'barmyway-child-theme' ),
		'sunday'    => __( 'Domenica', 'barmyway-child-theme' ),
	);
}

/** Numero di telefono ripulito per il link tel:. */
function barmyway_tel( $phone ) {
	return preg_replace( '/[^0-9+]/', '', (string) $phone );
}

/** Icona di una voce del menù: immagine del servizio, altrimenti un simbolo a rotazione. */
function barmyway_service_icon( $index ) {
	$icons = array(
		'<path d="M4 9h12v5a5 5 0 0 1-5 5H9a5 5 0 0 1-5-5V9Zm12 1h2a2.5 2.5 0 0 1 0 5h-2M8 3v3m4-3v3"/>',
		'<path d="M3 11h18a9 9 0 0 1-18 0Zm3-4 2-3 2 3 2-3 2 3 2-3 2 3"/>',
		'<path d="M6 3h12l-5 8v8h3M11 19H8m-3-8h14"/>',
		'<path d="M4 5h16v11H4zM2 19h20M9 9h6"/>',
	);
	return '<svg viewBox="0 0 24 24" width="28" height="28" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">' . $icons[ $index % count( $icons ) ] . '</svg>';
}

require_once get_stylesheet_directory() . '/inc/seed.php';
