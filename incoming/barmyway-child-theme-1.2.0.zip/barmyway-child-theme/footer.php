<?php
/**
 * Piè di pagina: contatti, orari e social dal CMS del parent.
 *
 * @package BarMyWayChildTheme
 */

defined( 'ABSPATH' ) || exit;

$bmw_contact = ticinoweb_get_contact_info();
$bmw_hours   = is_array( $bmw_contact['opening_hours'] ) ? $bmw_contact['opening_hours'] : array();
$bmw_social  = array(
	'instagram' => 'Instagram',
	'facebook'  => 'Facebook',
	'tiktok'    => 'TikTok',
);
$bmw_privacy = function_exists( 'get_privacy_policy_url' ) ? get_privacy_policy_url() : '';
?>
</main>

<footer class="bmw-footer" id="contatti">
	<div class="bmw-wrap bmw-footer__grid">
		<div class="bmw-footer__brand">
			<p class="bmw-footer__name"><?php bloginfo( 'name' ); ?></p>
			<?php if ( get_bloginfo( 'description' ) ) : ?>
				<p><?php bloginfo( 'description' ); ?></p>
			<?php endif; ?>
		</div>

		<div>
			<h2 class="bmw-footer__title"><?php esc_html_e( 'Dove siamo', 'barmyway-child-theme' ); ?></h2>
			<ul class="bmw-footer__list">
				<?php if ( ! empty( $bmw_contact['address'] ) ) : ?>
					<li>
						<?php echo nl2br( esc_html( $bmw_contact['address'] ) ); ?><br>
						<a href="<?php echo esc_url( 'https://www.google.com/maps/search/?api=1&query=' . rawurlencode( preg_replace( '/\s+/', ' ', $bmw_contact['address'] ) ) ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'Apri su Google Maps', 'barmyway-child-theme' ); ?></a>
					</li>
				<?php endif; ?>
				<?php if ( ! empty( $bmw_contact['phone'] ) ) : ?>
					<li><a href="tel:<?php echo esc_attr( barmyway_tel( $bmw_contact['phone'] ) ); ?>"><?php echo esc_html( $bmw_contact['phone'] ); ?></a></li>
				<?php endif; ?>
				<?php if ( ! empty( $bmw_contact['email'] ) ) : ?>
					<li><a href="mailto:<?php echo esc_attr( $bmw_contact['email'] ); ?>"><?php echo esc_html( $bmw_contact['email'] ); ?></a></li>
				<?php endif; ?>
			</ul>
		</div>

		<?php if ( $bmw_hours ) : ?>
			<div>
				<h2 class="bmw-footer__title"><?php esc_html_e( 'Orari', 'barmyway-child-theme' ); ?></h2>
				<ul class="bmw-footer__list bmw-footer__hours">
					<?php foreach ( barmyway_days() as $key => $label ) : ?>
						<?php
						if ( empty( $bmw_hours[ $key ] ) ) {
							continue;
						}
						$text = ticinoweb_format_day_hours( $bmw_hours[ $key ] );
						?>
						<li data-day="<?php echo esc_attr( $key ); ?>"><span><?php echo esc_html( $label ); ?></span> <span><?php echo esc_html( $text ); ?></span></li>
					<?php endforeach; ?>
				</ul>
				<?php if ( ! empty( $bmw_contact['opening_hours_note'] ) ) : ?>
					<p class="bmw-footer__note"><?php echo esc_html( $bmw_contact['opening_hours_note'] ); ?></p>
				<?php endif; ?>
			</div>
		<?php endif; ?>
	</div>

	<div class="bmw-wrap bmw-footer__bottom">
		<p>
			<?php
			/* translators: 1: year, 2: site name */
			printf( esc_html__( '© %1$s %2$s. Tutti i diritti riservati.', 'barmyway-child-theme' ), esc_html( wp_date( 'Y' ) ), esc_html( get_bloginfo( 'name' ) ) );
			?>
			<?php if ( $bmw_privacy ) : ?>
				· <a href="<?php echo esc_url( $bmw_privacy ); ?>"><?php esc_html_e( 'Privacy', 'barmyway-child-theme' ); ?></a>
			<?php endif; ?>
		</p>
		<p class="bmw-footer__social">
			<?php foreach ( $bmw_social as $key => $label ) : ?>
				<?php if ( ! empty( $bmw_contact[ $key ] ) ) : ?>
					<a href="<?php echo esc_url( $bmw_contact[ $key ] ); ?>" target="_blank" rel="noopener"><?php echo esc_html( $label ); ?></a>
				<?php endif; ?>
			<?php endforeach; ?>
			<span class="bmw-footer__credit">Design by <a href="https://ticinoweb.com" target="_blank" rel="noopener">ticinoWEB</a></span>
		</p>
	</div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
