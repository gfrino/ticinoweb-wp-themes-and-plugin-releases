<?php
/**
 * Contenuti di partenza del sito, scritti nel CMS del parent alla prima attivazione.
 *
 * Riempie solo ciò che è vuoto: non sovrascrive mai un dato già inserito. Tutto si
 * modifica poi da ticinoWEB CMS (orari, servizi, chi siamo) e da Bacheca → FAQ.
 *
 * @package BarMyWayChildTheme
 */

defined( 'ABSPATH' ) || exit;

const BARMYWAY_SEED_VERSION = 3;

/**
 * Porta una foto del tema nella Libreria media e ne restituisce l'URL.
 * Ogni foto viene caricata una sola volta (id in un'opzione), anche se il seed gira di nuovo.
 *
 * @param string $file Nome del file in assets/img.
 * @param string $alt  Testo alternativo.
 * @return string URL del file nella Libreria media, vuoto se il caricamento fallisce.
 */
function barmyway_import_photo( $file, $alt ) {
	$done = get_option( 'barmyway_seed_photos', array() );
	if ( ! is_array( $done ) ) {
		$done = array();
	}
	if ( ! empty( $done[ $file ] ) && get_post( (int) $done[ $file ] ) ) {
		return (string) wp_get_attachment_url( (int) $done[ $file ] );
	}

	$source = get_stylesheet_directory() . '/assets/img/' . basename( $file );
	if ( ! is_readable( $source ) ) {
		return '';
	}

	require_once ABSPATH . 'wp-admin/includes/file.php';
	require_once ABSPATH . 'wp-admin/includes/media.php';
	require_once ABSPATH . 'wp-admin/includes/image.php';

	$tmp = wp_tempnam( $file );
	if ( ! $tmp || ! copy( $source, $tmp ) ) {
		return '';
	}
	$id = media_handle_sideload( array( 'name' => basename( $file ), 'tmp_name' => $tmp ), 0, null, array( 'post_title' => $alt ) );
	if ( is_wp_error( $id ) ) {
		wp_delete_file( $tmp );
		return '';
	}
	update_post_meta( $id, '_wp_attachment_image_alt', $alt );
	$done[ $file ] = $id;
	update_option( 'barmyway_seed_photos', $done, false );
	return (string) wp_get_attachment_url( $id );
}

/** Foto di esempio (Unsplash, licenza libera) nei campi immagine ancora vuoti. */
function barmyway_seed_photos() {
	if ( '' === trim( (string) get_option( 'ticinoweb_slider_image_1', '' ) ) ) {
		$url = barmyway_import_photo( 'hero.jpg', 'Il bancone di un bar luminoso con sgabelli in legno' );
		if ( $url ) {
			update_option( 'ticinoweb_slider_image_1', $url );
		}
	}

	if ( '' === trim( (string) get_option( 'ticinoweb_chi_siamo_image', '' ) ) ) {
		$url = barmyway_import_photo( 'chi-siamo.jpg', 'Un espresso che scende dalla macchina del caffè' );
		if ( $url ) {
			update_option( 'ticinoweb_chi_siamo_image', $url );
		}
	}

	if ( '' === trim( (string) get_option( 'ticinoweb_site_icon', '' ) ) ) {
		$url = barmyway_import_photo( 'favicon.png', 'Icona di Bar my Way' );
		if ( $url ) {
			update_option( 'ticinoweb_site_icon', $url );
		}
	}

	// Dalla 1.2.0 il servizio «Pause per le riunioni» usa la foto della sala dell'ArbedSmart Center:
	// si sostituisce la foto di esempio della 1.1.0 solo se è ancora quella, mai una scelta del cliente.
	$done = get_option( 'barmyway_seed_photos', array() );
	if ( ! empty( $done['pause-riunioni.jpg'] ) ) {
		$old_url  = (string) wp_get_attachment_url( (int) $done['pause-riunioni.jpg'] );
		$services = get_option( 'ticinoweb_services', array() );
		if ( $old_url && is_array( $services ) ) {
			foreach ( $services as &$service ) {
				if ( isset( $service['id'], $service['image'] ) && 'srv_bmw_meeting' === $service['id'] && $service['image'] === $old_url ) {
					$service['image'] = '';
				}
			}
			unset( $service );
			update_option( 'ticinoweb_services', $services );
		}
	}

	$photos = array(
		'srv_bmw_caffe'     => array( 'caffe-colazioni.jpg', 'Cappuccino con cornetti in un cestino' ),
		'srv_bmw_pranzo'    => array( 'pranzo.jpg', 'Panino farcito con insalata e pomodoro' ),
		'srv_bmw_aperitivo' => array( 'aperitivo.jpg', 'Spritz con olive e stuzzichini' ),
		'srv_bmw_meeting'   => array( 'pause-riunioni-arbed.jpg', 'Una sala riunioni dell’ArbedSmart Center con tavolo e schermo' ),
	);
	$services = get_option( 'ticinoweb_services', array() );
	if ( is_array( $services ) ) {
		$changed = false;
		foreach ( $services as &$service ) {
			$id = isset( $service['id'] ) ? $service['id'] : '';
			if ( isset( $photos[ $id ] ) && empty( $service['image'] ) ) {
				$url = barmyway_import_photo( $photos[ $id ][0], $photos[ $id ][1] );
				if ( $url ) {
					$service['image'] = $url;
					$changed          = true;
				}
			}
		}
		unset( $service );
		if ( $changed ) {
			update_option( 'ticinoweb_services', $services );
		}
	}
}

function barmyway_seed() {
	if ( (int) get_option( 'barmyway_seed_version', 0 ) >= BARMYWAY_SEED_VERSION ) {
		return;
	}

	$tagline = (string) get_option( 'blogdescription', '' );
	if ( '' === $tagline || 'Just another WordPress site' === $tagline ) {
		update_option( 'blogdescription', 'Il tuo caffè lungo la strada, all’ArbedSmart Center di Arbedo' );
	}

	if ( '' === trim( (string) get_option( 'ticinoweb_contact_address', '' ) ) ) {
		update_option( 'ticinoweb_contact_address', "ArbedSmart Center\n6517 Arbedo" );
	}

	$hours = get_option( 'ticinoweb_contact_opening_hours', array() );
	if ( empty( $hours ) ) {
		$weekday = array(
			'closed'   => 0,
			'open_24h' => 0,
			'slots'    => array( array( 'open' => '06:30', 'close' => '18:30' ) ),
		);
		update_option(
			'ticinoweb_contact_opening_hours',
			array(
				'monday'    => $weekday,
				'tuesday'   => $weekday,
				'wednesday' => $weekday,
				'thursday'  => $weekday,
				'friday'    => $weekday,
				'saturday'  => array(
					'closed'   => 0,
					'open_24h' => 0,
					'slots'    => array( array( 'open' => '07:30', 'close' => '13:00' ) ),
				),
				'sunday'    => array(
					'closed'   => 1,
					'open_24h' => 0,
					'slots'    => array(),
				),
			)
		);
	}

	$services = get_option( 'ticinoweb_services', array() );
	if ( empty( $services ) ) {
		update_option(
			'ticinoweb_services',
			array(
				array(
					'id'          => 'srv_bmw_caffe',
					'title'       => 'Caffè e colazioni',
					'description' => 'Espresso, cappuccino e cornetti caldi fin dal mattino presto, anche da portare via.',
				),
				array(
					'id'          => 'srv_bmw_pranzo',
					'title'       => 'Pranzo veloce',
					'description' => 'Panini, insalate e piatto del giorno per la pausa pranzo, pronti in pochi minuti.',
				),
				array(
					'id'          => 'srv_bmw_aperitivo',
					'title'       => 'Aperitivo',
					'description' => 'Calici, stuzzichini e un tagliere da dividere a fine giornata o dopo una riunione.',
				),
				array(
					'id'          => 'srv_bmw_meeting',
					'title'       => 'Pause per le riunioni',
					'description' => 'Caffè, acqua e qualcosa da sgranocchiare per chi ha una sala prenotata nel centro: ordini e ti raggiungiamo.',
				),
			)
		);
	}

	if ( '' === trim( (string) get_option( 'ticinoweb_chi_siamo_title', '' ) ) ) {
		update_option( 'ticinoweb_chi_siamo_title', 'Una sosta che sa di casa' );
	}
	if ( '' === trim( (string) get_option( 'ticinoweb_chi_siamo_text', '' ) ) ) {
		update_option(
			'ticinoweb_chi_siamo_text',
			"Bar my Way è il bar dell’ArbedSmart Center di Arbedo: un posto dove fermarsi cinque minuti, senza fretta, che tu lavori qui, sia in viaggio o ti fermi per la notte.\n\nCaffè scelto con cura, prodotti freschi ogni giorno e un saluto vero al banco. Ognuno ha il suo modo di fare strada: il nostro è farti stare bene lungo la tua."
		);
	}

	if ( function_exists( 'ticinoweb_faq_upsert_set' ) && function_exists( 'ticinoweb_faq_find' ) && ! ticinoweb_faq_find( 'bar-my-way' ) ) {
		ticinoweb_faq_upsert_set(
			'bar-my-way',
			'Domande su Bar my Way',
			array(
				array(
					'q'       => 'Dove si trova Bar my Way?',
					'a'       => 'Bar my Way si trova all’interno dell’ArbedSmart Center di Arbedo, sulla strada tra Bellinzona e il Gottardo, ed è aperto anche a chi non alloggia o lavora nel centro.',
					'visible' => 1,
				),
				array(
					'q'       => 'Qual è l’orario di apertura?',
					'a'       => 'Siamo aperti dal lunedì al venerdì dalle 6.30 alle 18.30 e il sabato dalle 7.30 alle 13.00. La domenica siamo chiusi.',
					'visible' => 1,
				),
				array(
					'q'       => 'Posso ordinare caffè e snack per una riunione?',
					'a'       => 'Sì. Se hai una sala riunioni all’ArbedSmart Center scrivici o chiamaci prima: prepariamo caffè, acqua e qualcosa da mangiare e te li portiamo all’orario che indichi.',
					'visible' => 1,
				),
				array(
					'q'       => 'Servite la colazione?',
					'a'       => 'Sì, dalle 6.30 con caffè, cappuccino, cornetti e brioche appena sfornati. Puoi consumare al banco, al tavolo o portare via.',
					'visible' => 1,
				),
				array(
					'q'       => 'Bisogna prenotare un tavolo?',
					'a'       => 'Per un caffè o un pranzo veloce no, basta entrare. Per gruppi di più di otto persone ti consigliamo di avvisarci in anticipo, così ti riserviamo i posti.',
					'visible' => 1,
				),
			),
			array( 'intro' => 'Le risposte alle domande che ci fanno più spesso al banco.' )
		);
	}

	barmyway_seed_photos();

	update_option( 'barmyway_seed_version', BARMYWAY_SEED_VERSION, false );
}
// Alla prima attivazione; admin_init copre il caso di un sito dove il tema è già attivo quando il codice arriva.
add_action( 'after_switch_theme', 'barmyway_seed' );
add_action( 'admin_init', 'barmyway_seed' );
