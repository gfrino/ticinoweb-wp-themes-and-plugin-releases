<?php
/**
 * Pagine e articoli singoli.
 *
 * @package BarMyWayChildTheme
 */

defined( 'ABSPATH' ) || exit;

get_header();
?>
<article class="bmw-page">
	<?php while ( have_posts() ) : the_post(); ?>
		<header class="bmw-page__head">
			<div class="bmw-wrap bmw-wrap--narrow">
				<h1><?php the_title(); ?></h1>
			</div>
		</header>
		<div class="bmw-wrap bmw-wrap--narrow bmw-prose">
			<?php the_content(); ?>
		</div>
	<?php endwhile; ?>
</article>
<?php
get_footer();
