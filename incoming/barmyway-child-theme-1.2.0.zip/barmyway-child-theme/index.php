<?php
/**
 * Elenco articoli e archivi.
 *
 * @package BarMyWayChildTheme
 */

defined( 'ABSPATH' ) || exit;

get_header();
?>
<section class="bmw-page">
	<header class="bmw-page__head">
		<div class="bmw-wrap bmw-wrap--narrow">
			<h1><?php echo is_search() ? esc_html( sprintf( /* translators: %s: search query */ __( 'Risultati per «%s»', 'barmyway-child-theme' ), get_search_query() ) ) : esc_html( wp_strip_all_tags( get_the_archive_title() ?: get_bloginfo( 'name' ) ) ); ?></h1>
		</div>
	</header>
	<div class="bmw-wrap bmw-wrap--narrow bmw-prose">
		<?php if ( have_posts() ) : ?>
			<?php while ( have_posts() ) : the_post(); ?>
				<article class="bmw-entry">
					<h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
					<?php the_excerpt(); ?>
				</article>
			<?php endwhile; ?>
			<?php the_posts_pagination(); ?>
		<?php else : ?>
			<p><?php esc_html_e( 'Non abbiamo trovato nulla.', 'barmyway-child-theme' ); ?></p>
		<?php endif; ?>
	</div>
</section>
<?php
get_footer();
