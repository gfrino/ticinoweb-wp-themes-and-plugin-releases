(function () {
	'use strict';

	var burger = document.querySelector('.bmw-burger');
	var nav = document.getElementById('bmw-nav');
	if (burger && nav) {
		burger.addEventListener('click', function () {
			var open = burger.getAttribute('aria-expanded') === 'true';
			burger.setAttribute('aria-expanded', open ? 'false' : 'true');
			nav.classList.toggle('is-open', !open);
		});
		nav.addEventListener('click', function (e) {
			if (e.target.closest('a')) {
				burger.setAttribute('aria-expanded', 'false');
				nav.classList.remove('is-open');
			}
		});
	}

	// Evidenzia il giorno di oggi negli orari (lato browser: la pagina resta cacheabile).
	var days = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
	var today = days[new Date().getDay()];
	document.querySelectorAll('[data-day="' + today + '"]').forEach(function (el) {
		el.classList.add('is-today');
	});
})();
