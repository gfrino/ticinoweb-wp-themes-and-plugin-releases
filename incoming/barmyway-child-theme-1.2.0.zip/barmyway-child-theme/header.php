<?php
/**
 * Testata: logo, menu principale e pulsante di chiamata.
 *
 * @package BarMyWayChildTheme
 */

defined( 'ABSPATH' ) || exit;

$bmw_contact = ticinoweb_get_contact_info();
$bmw_logo    = ticinoweb_get_site_logo();
$bmw_name    = get_bloginfo( 'name' );
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="bmw-skip" href="#contenuto"><?php esc_html_e( 'Vai al contenuto', 'barmyway-child-theme' ); ?></a>

<header class="bmw-header" id="home">
	<div class="bmw-wrap bmw-header__bar">
		<a class="bmw-brand" href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
			<?php if ( $bmw_logo ) : ?>
				<img class="bmw-brand__logo" src="<?php echo esc_url( $bmw_logo ); ?>" alt="<?php echo esc_attr( $bmw_name ); ?>" width="180" height="48">
			<?php else : ?>
				<span class="bmw-brand__text"><?php echo esc_html( $bmw_name ); ?></span>
			<?php endif; ?>
		</a>

		<button class="bmw-burger" type="button" aria-expanded="false" aria-controls="bmw-nav">
			<span class="bmw-burger__lines" aria-hidden="true"></span>
			<span class="screen-reader-text"><?php esc_html_e( 'Menu', 'barmyway-child-theme' ); ?></span>
		</button>

		<nav class="bmw-nav" id="bmw-nav" aria-label="<?php esc_attr_e( 'Navigazione principale', 'barmyway-child-theme' ); ?>">
			<?php
			wp_nav_menu(
				array(
					'theme_location' => 'primary',
					'menu_class'     => 'primary-menu',
					'container'      => false,
					'fallback_cb'    => 'barmyway_fallback_menu',
				)
			);
			?>
			<?php if ( ! empty( $bmw_contact['phone'] ) ) : ?>
				<a class="bmw-btn bmw-btn--small" href="tel:<?php echo esc_attr( barmyway_tel( $bmw_contact['phone'] ) ); ?>"><?php esc_html_e( 'Chiamaci', 'barmyway-child-theme' ); ?></a>
			<?php endif; ?>
		</nav>
	</div>
</header>

<main id="contenuto">
