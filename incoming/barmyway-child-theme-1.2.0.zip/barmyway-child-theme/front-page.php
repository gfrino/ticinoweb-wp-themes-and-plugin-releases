<?php
/**
 * Home: copertina, cosa serviamo, chi siamo, orari, recensioni, domande, dove siamo.
 * Ogni blocco legge il CMS del parent e sparisce se il dato manca.
 *
 * @package BarMyWayChildTheme
 */

defined( 'ABSPATH' ) || exit;

get_header();

$bmw_contact  = ticinoweb_get_contact_info();
$bmw_hours    = is_array( $bmw_contact['opening_hours'] ) ? $bmw_contact['opening_hours'] : array();
$bmw_services = function_exists( 'ticinoweb_get_services' ) ? ticinoweb_get_services() : array();
$bmw_slides   = function_exists( 'ticinoweb_get_slider_data' ) ? ticinoweb_get_slider_data() : array();
$bmw_cover    = ( ! empty( $bmw_slides[0]['image'] ) ) ? $bmw_slides[0]['image'] : '';
$bmw_about_t  = trim( (string) get_option( 'ticinoweb_chi_siamo_title', '' ) );
$bmw_about_x  = trim( (string) get_option( 'ticinoweb_chi_siamo_text', '' ) );
$bmw_about_i  = trim( (string) get_option( 'ticinoweb_chi_siamo_image', '' ) );
$bmw_reviews  = get_option( 'ticinoweb_google_place_id', '' ) && shortcode_exists( 'ticinoweb_google_reviews' );
$bmw_faq      = function_exists( 'ticinoweb_faq_render' ) ? ticinoweb_faq_render( 'bar-my-way', array( 'show_title' => false, 'heading_level' => 3 ) ) : '';
?>

<section class="bmw-hero<?php echo $bmw_cover ? ' bmw-hero--photo' : ''; ?>"<?php echo $bmw_cover ? ' style="--bmw-cover:url(\'' . esc_url( $bmw_cover ) . '\')"' : ''; ?>>
	<div class="bmw-wrap bmw-hero__inner">
		<p class="bmw-eyebrow"><?php esc_html_e( 'ArbedSmart Center · Arbedo', 'barmyway-child-theme' ); ?></p>
		<h1 class="bmw-hero__title"><?php bloginfo( 'name' ); ?></h1>
		<?php if ( get_bloginfo( 'description' ) ) : ?>
			<p class="bmw-hero__lead"><?php bloginfo( 'description' ); ?></p>
		<?php endif; ?>
		<p class="bmw-hero__actions">
			<?php if ( $bmw_services ) : ?>
				<a class="bmw-btn" href="#servizi"><?php esc_html_e( 'Scopri cosa serviamo', 'barmyway-child-theme' ); ?></a>
			<?php endif; ?>
			<a class="bmw-btn bmw-btn--ghost" href="#contatti"><?php esc_html_e( 'Come raggiungerci', 'barmyway-child-theme' ); ?></a>
		</p>
	</div>
</section>

<?php if ( $bmw_services ) : ?>
<section class="bmw-section" id="servizi">
	<div class="bmw-wrap">
		<h2 class="bmw-title"><?php esc_html_e( 'Cosa serviamo', 'barmyway-child-theme' ); ?></h2>
		<div class="bmw-cards">
			<?php foreach ( array_values( $bmw_services ) as $i => $service ) : ?>
				<?php
				if ( empty( $service['title'] ) ) {
					continue;
				}
				?>
				<article class="bmw-card">
					<?php if ( ! empty( $service['image'] ) ) : ?>
						<img class="bmw-card__img" src="<?php echo esc_url( $service['image'] ); ?>" alt="" loading="lazy" decoding="async">
					<?php else : ?>
						<span class="bmw-card__icon"><?php echo barmyway_service_icon( $i ); // phpcs:ignore WordPress.Security.EscapeOutput -- SVG fisso del tema. ?></span>
					<?php endif; ?>
					<h3><?php echo esc_html( $service['title'] ); ?></h3>
					<?php if ( ! empty( $service['description'] ) ) : ?>
						<p><?php echo esc_html( $service['description'] ); ?></p>
					<?php endif; ?>
				</article>
			<?php endforeach; ?>
		</div>
	</div>
</section>
<?php endif; ?>

<?php if ( $bmw_about_x ) : ?>
<section class="bmw-section bmw-section--cream" id="chi-siamo">
	<div class="bmw-wrap bmw-about<?php echo $bmw_about_i ? ' bmw-about--image' : ''; ?>">
		<div class="bmw-about__text">
			<?php if ( $bmw_about_t ) : ?>
				<h2 class="bmw-title"><?php echo esc_html( $bmw_about_t ); ?></h2>
			<?php endif; ?>
			<?php echo wp_kses_post( wpautop( esc_html( $bmw_about_x ) ) ); ?>
		</div>
		<?php if ( $bmw_about_i ) : ?>
			<img class="bmw-about__img" src="<?php echo esc_url( $bmw_about_i ); ?>" alt="" loading="lazy" decoding="async">
		<?php endif; ?>
	</div>
</section>
<?php endif; ?>

<?php if ( $bmw_hours ) : ?>
<section class="bmw-section" id="orari">
	<div class="bmw-wrap bmw-hours">
		<h2 class="bmw-title"><?php esc_html_e( 'Quando trovarci', 'barmyway-child-theme' ); ?></h2>
		<ul class="bmw-hours__list">
			<?php foreach ( barmyway_days() as $key => $label ) : ?>
				<?php
				if ( empty( $bmw_hours[ $key ] ) ) {
					continue;
				}
				$text = ticinoweb_format_day_hours( $bmw_hours[ $key ] );
				?>
				<li data-day="<?php echo esc_attr( $key ); ?>"><span><?php echo esc_html( $label ); ?></span><strong><?php echo esc_html( $text ); ?></strong></li>
			<?php endforeach; ?>
		</ul>
		<?php if ( ! empty( $bmw_contact['opening_hours_note'] ) ) : ?>
			<p class="bmw-note"><?php echo esc_html( $bmw_contact['opening_hours_note'] ); ?></p>
		<?php endif; ?>
	</div>
</section>
<?php endif; ?>

<?php if ( $bmw_reviews ) : ?>
	<?php wp_enqueue_style( 'dashicons' ); ?>
<section class="bmw-section bmw-section--cream" id="recensioni">
	<div class="bmw-wrap">
		<h2 class="bmw-title"><?php esc_html_e( 'Dicono di noi', 'barmyway-child-theme' ); ?></h2>
		<?php echo do_shortcode( '[ticinoweb_google_reviews]' ); ?>
	</div>
</section>
<?php endif; ?>

<?php if ( $bmw_faq ) : ?>
<section class="bmw-section" id="faq">
	<div class="bmw-wrap bmw-wrap--narrow">
		<h2 class="bmw-title"><?php esc_html_e( 'Domande frequenti', 'barmyway-child-theme' ); ?></h2>
		<?php echo $bmw_faq; // phpcs:ignore WordPress.Security.EscapeOutput -- HTML già escapato dal parent. ?>
	</div>
</section>
<?php endif; ?>

<?php
get_footer();
