<?php
/**
 * Pagina non trovata.
 *
 * @package BarMyWayChildTheme
 */

defined( 'ABSPATH' ) || exit;

get_header();
?>
<section class="bmw-page">
	<header class="bmw-page__head">
		<div class="bmw-wrap bmw-wrap--narrow">
			<h1><?php esc_html_e( 'Qui non c’è niente… ma il caffè sì', 'barmyway-child-theme' ); ?></h1>
		</div>
	</header>
	<div class="bmw-wrap bmw-wrap--narrow bmw-prose">
		<p><?php esc_html_e( 'La pagina che cercavi non esiste più o non è mai esistita.', 'barmyway-child-theme' ); ?></p>
		<p><a class="bmw-btn" href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Torna alla home', 'barmyway-child-theme' ); ?></a></p>
	</div>
</section>
<?php
get_footer();
