/**
 * Accessible service tabs/accordion and lightweight one-shot motion.
 */
(function () {
	'use strict';

	const root = document.querySelector('.ts-service-single');
	if (!root) return;

	const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
	const mobileTabs = window.matchMedia('(max-width: 767px)');

	function setInert(element, inert) {
		if (!element) return;
		element.inert = inert;
	}

	function initTabs(tabs) {
		const tabList = tabs.querySelector('.ts-service-tabs__list');
		const buttons = Array.from(tabs.querySelectorAll('[data-service-tab]'));
		const panels = Array.from(tabs.querySelectorAll('[data-service-panel]'));
		const accordionButtons = Array.from(tabs.querySelectorAll('[data-service-accordion]'));
		if (!tabList || !buttons.length || buttons.length !== panels.length) return;

		let activeIndex = Math.max(0, buttons.findIndex(button => button.getAttribute('aria-selected') === 'true'));
		tabs.classList.add('is-enhanced');

		function activate(index, moveFocus, allowCollapse = false) {
			activeIndex = allowCollapse && mobileTabs.matches && index === activeIndex
				? -1
				: Math.max(0, Math.min(index, buttons.length - 1));
			buttons.forEach((button, buttonIndex) => {
				const active = buttonIndex === activeIndex;
				button.classList.toggle('is-active', active);
				button.setAttribute('aria-selected', String(active));
				button.tabIndex = active ? 0 : -1;
			});
			panels.forEach((panel, panelIndex) => {
				const active = panelIndex === activeIndex;
				const content = panel.querySelector('.ts-service-tabs__panel-content');
				const accordion = accordionButtons[panelIndex];
				panel.classList.toggle('is-active', active);
				accordion?.setAttribute('aria-expanded', String(active));
				if (mobileTabs.matches) panel.removeAttribute('aria-hidden');
				else panel.setAttribute('aria-hidden', String(!active));
				if (mobileTabs.matches) {
					setInert(panel, false);
					setInert(content, !active);
				} else {
					setInert(content, false);
					setInert(panel, !active);
				}
			});
			if (moveFocus) (mobileTabs.matches ? accordionButtons[activeIndex] : buttons[activeIndex])?.focus();
		}

		function setMode() {
			if (mobileTabs.matches) {
				tabList.setAttribute('aria-hidden', 'true');
				setInert(tabList, true);
				buttons.forEach(button => button.tabIndex = -1);
				panels.forEach((panel, index) => {
					panel.setAttribute('role', 'region');
					panel.setAttribute('aria-labelledby', accordionButtons[index].id);
					panel.removeAttribute('aria-hidden');
					accordionButtons[index].removeAttribute('aria-hidden');
					accordionButtons[index].tabIndex = 0;
				});
			} else {
				if (activeIndex < 0) activeIndex = 0;
				tabList.removeAttribute('aria-hidden');
				setInert(tabList, false);
				tabList.setAttribute('role', 'tablist');
				panels.forEach((panel, index) => {
					panel.setAttribute('role', 'tabpanel');
					panel.setAttribute('aria-labelledby', buttons[index].id);
					panel.setAttribute('aria-hidden', String(index !== activeIndex));
					accordionButtons[index].setAttribute('aria-hidden', 'true');
					accordionButtons[index].tabIndex = -1;
				});
			}
			activate(activeIndex, false);
			if (!mobileTabs.matches) {
				panels.forEach((panel, index) => panel.setAttribute('aria-hidden', String(index !== activeIndex)));
			}
		}

		buttons.forEach((button, index) => {
			button.addEventListener('click', () => activate(index, false));
			button.addEventListener('keydown', event => {
				let targetIndex = null;
				if (event.key === 'ArrowRight') targetIndex = (index + 1) % buttons.length;
				if (event.key === 'ArrowLeft') targetIndex = (index - 1 + buttons.length) % buttons.length;
				if (event.key === 'Home') targetIndex = 0;
				if (event.key === 'End') targetIndex = buttons.length - 1;
				if (targetIndex === null) return;
				event.preventDefault();
				activate(targetIndex, true);
			});
		});

		accordionButtons.forEach((button, index) => button.addEventListener('click', () => activate(index, false, true)));
		mobileTabs.addEventListener('change', setMode);
		setMode();
	}

	function initPerimeter(svg) {
		const motion = svg.querySelector('[data-service-perimeter-motion]');
		if (!motion || reducedMotion.matches) {
			svg.pauseAnimations?.();
			return;
		}
		let started = false;
		const observer = new IntersectionObserver(entries => {
			const visible = entries[0]?.isIntersecting;
			if (visible) {
				if (!started) {
					motion.beginElement?.();
					started = true;
				}
				svg.unpauseAnimations?.();
			} else {
				svg.pauseAnimations?.();
			}
		}, { rootMargin: '120px 0px', threshold: 0 });
		observer.observe(svg);
	}

	function initReveals() {
		const elements = Array.from(root.querySelectorAll('[data-service-reveal]'));
		root.classList.add('is-enhanced');
		if (reducedMotion.matches || !('IntersectionObserver' in window)) {
			elements.forEach(element => element.classList.add('is-visible'));
			return;
		}
		const observer = new IntersectionObserver(entries => {
			entries.forEach(entry => {
				if (!entry.isIntersecting) return;
				entry.target.classList.add('is-visible');
				observer.unobserve(entry.target);
			});
		}, { rootMargin: '0px 0px -8% 0px', threshold: 0.08 });
		elements.forEach(element => observer.observe(element));
	}

	root.querySelectorAll('[data-service-tabs]').forEach(initTabs);
	root.querySelectorAll('[data-service-perimeter]').forEach(initPerimeter);
	initReveals();

	// Hero carousel: native scroll-snap, buttons/dots, gentle autoplay (off with reduced motion).
	root.querySelectorAll('[data-service-carousel]').forEach(carousel => {
		const track = carousel.querySelector('[data-service-carousel-track]');
		const slides = Array.from(carousel.querySelectorAll('[data-service-carousel-slide]'));
		const dots = Array.from(carousel.querySelectorAll('[data-service-carousel-dot]'));
		const prev = carousel.querySelector('[data-service-carousel-prev]');
		const next = carousel.querySelector('[data-service-carousel-next]');
		if (!track || slides.length < 2) return;

		let current = 0;
		let timer = 0;
		let paused = false;

		function setActive(index) {
			current = index;
			dots.forEach((dot, i) => {
				dot.classList.toggle('is-active', i === index);
				if (i === index) dot.setAttribute('aria-current', 'true');
				else dot.removeAttribute('aria-current');
			});
			slides.forEach((slide, i) => slide.setAttribute('aria-hidden', i === index ? 'false' : 'true'));
		}

		function goTo(index) {
			const target = (index + slides.length) % slides.length;
			track.scrollTo({ left: slides[target].offsetLeft, behavior: reducedMotion.matches ? 'auto' : 'smooth' });
			setActive(target);
		}

		function stop() { window.clearInterval(timer); timer = 0; }
		function start() {
			stop();
			if (reducedMotion.matches || paused || document.hidden) return;
			timer = window.setInterval(() => goTo(current + 1), 5000);
		}

		let scrollFrame = 0;
		track.addEventListener('scroll', () => {
			window.cancelAnimationFrame(scrollFrame);
			scrollFrame = window.requestAnimationFrame(() => {
				const index = Math.round(track.scrollLeft / Math.max(1, track.clientWidth));
				if (index !== current && slides[index]) setActive(index);
			});
		}, { passive: true });

		prev && prev.addEventListener('click', () => { goTo(current - 1); start(); });
		next && next.addEventListener('click', () => { goTo(current + 1); start(); });
		dots.forEach((dot, i) => dot.addEventListener('click', () => { goTo(i); start(); }));
		track.addEventListener('keydown', event => {
			if (event.key === 'ArrowRight') { event.preventDefault(); goTo(current + 1); start(); }
			if (event.key === 'ArrowLeft') { event.preventDefault(); goTo(current - 1); start(); }
		});

		['pointerenter', 'focusin'].forEach(type => carousel.addEventListener(type, () => { paused = true; stop(); }));
		['pointerleave', 'focusout'].forEach(type => carousel.addEventListener(type, () => { paused = false; start(); }));
		track.addEventListener('touchstart', () => { paused = true; stop(); }, { passive: true });
		document.addEventListener('visibilitychange', start);
		if (reducedMotion.addEventListener) reducedMotion.addEventListener('change', start);

		setActive(0);
		start();
	});
})();
