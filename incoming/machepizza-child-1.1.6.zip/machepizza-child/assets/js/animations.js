/**
 * Mache Pizza - Premium Animations & Interactions
 */
document.addEventListener('DOMContentLoaded', function() {
    
    // 1. Reveal Animations on Scroll
    if (window.matchMedia('(prefers-reduced-motion: no-preference)').matches) {
        const observerOptions = {
            root: null,
            rootMargin: '0px',
            threshold: 0.15
        };
        const observer = new IntersectionObserver((entries, observer) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    // Aggiungiamo un leggero ritardo per renderlo più "premium" ed elegante
                    setTimeout(() => {
                        entry.target.classList.add('active');
                    }, 50);
                    observer.unobserve(entry.target); 
                }
            });
        }, observerOptions);
        
        document.querySelectorAll('.mp-reveal').forEach(el => observer.observe(el));
    } else {
        // Fallback per accessibilità: se riducono il movimento, rendiamo tutto subito visibile
        document.querySelectorAll('.mp-reveal').forEach(el => el.classList.add('active'));
    }

    // 2. Micro-interactions: Mouse Move subtle parallax (opzionale, solo per la Hero Visual Wrapper se presente)
    const heroVisual = document.querySelector('.mp-hero-visual-wrapper');
    if (heroVisual && window.matchMedia('(prefers-reduced-motion: no-preference)').matches && window.innerWidth > 991) {
        heroVisual.addEventListener('mousemove', (e) => {
            const xAxis = (window.innerWidth / 2 - e.pageX) / 40;
            const yAxis = (window.innerHeight / 2 - e.pageY) / 40;
            
            // Applichiamo il movimento delicatissimo alle cards
            const card1 = document.querySelector('.mp-preview-card.card-1');
            const card2 = document.querySelector('.mp-preview-card.card-2');
            
            if (card1) card1.style.transform = `translateY(0) scale(1) translate(${xAxis}px, ${yAxis}px)`;
            if (card2) card2.style.transform = `translateY(0) scale(1) translate(${xAxis * -1}px, ${yAxis * -1}px)`;
        });

        heroVisual.addEventListener('mouseleave', () => {
            const card1 = document.querySelector('.mp-preview-card.card-1');
            const card2 = document.querySelector('.mp-preview-card.card-2');
            if (card1) card1.style.transform = `translateY(0) scale(1)`;
            if (card2) card2.style.transform = `translateY(0) scale(1)`;
        });
    }
    // 3. Header Sticky Logic
    const header = document.getElementById('mp-header');
    if (header) {
        window.addEventListener('scroll', () => {
            if (window.scrollY > 50) {
                header.classList.add('is-scrolled');
            } else {
                header.classList.remove('is-scrolled');
            }
        });
        // Run once on load to set initial state
        if (window.scrollY > 50) {
            header.classList.add('is-scrolled');
        }
    }

    // 4. Mobile Menu Hamburger Toggle
    const hamburger = document.getElementById('mp-hamburger');
    const nav = document.getElementById('mp-nav');
    
    if (hamburger && nav) {
        hamburger.addEventListener('click', () => {
            hamburger.classList.toggle('is-active');
            nav.classList.toggle('is-active');
            if (nav.classList.contains('is-active')) {
                document.body.style.overflow = 'hidden';
            } else {
                document.body.style.overflow = '';
            }
        });

        // Close menu on link click
        nav.querySelectorAll('a').forEach(link => {
            link.addEventListener('click', () => {
                hamburger.classList.remove('is-active');
                nav.classList.remove('is-active');
                document.body.style.overflow = '';
            });
        });
    }

});
