/**
 * Mache Pizza – Shop Interactions
 *
 * - Category pill filtering (show/hide sections)
 * - Category section collapse/expand
 * - Addon popup modal (AJAX load product form)
 * - AJAX add-to-cart for simple products
 */
(function () {
  'use strict';

  document.addEventListener('DOMContentLoaded', init);

  function init() {
    initCategoryPills();
    initCategoryToggles();
    initAddonPopup();
    initSimpleAddToCart();
    initStickyNav();
  }

  /* ─── Category Pill Navigation ─── */
  function initCategoryPills() {
    const pills = document.querySelectorAll('.mp-pill');
    const sections = document.querySelectorAll('.mp-cat-section');
    if (!pills.length) return;

    pills.forEach(function (pill) {
      pill.addEventListener('click', function () {
        pills.forEach(function (p) { p.classList.remove('mp-pill-active'); });
        pill.classList.add('mp-pill-active');

        var target = pill.getAttribute('data-target');
        if (target === 'all') {
          sections.forEach(function (s) { s.style.display = ''; });
        } else {
          sections.forEach(function (s) {
            s.style.display = s.id === target ? '' : 'none';
          });
        }

        // Smooth scroll to shop content
        var shopContent = document.querySelector('.mp-shop-content');
        if (shopContent) {
          shopContent.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
      });
    });
  }

  /* ─── Category Section Collapse/Expand ─── */
  function initCategoryToggles() {
    var toggles = document.querySelectorAll('.mp-cat-toggle');
    toggles.forEach(function (btn) {
      btn.addEventListener('click', function () {
        var section = btn.closest('.mp-cat-section');
        var list = section.querySelector('.mp-cat-products');
        var expanded = btn.getAttribute('aria-expanded') === 'true';

        btn.setAttribute('aria-expanded', !expanded);
        list.classList.toggle('mp-cat-collapsed');
        btn.classList.toggle('mp-cat-toggle-collapsed');
      });
    });
  }

  /* ─── Addon Popup Modal ─── */
  function initAddonPopup() {
    var overlay = document.getElementById('mp-addon-overlay');
    var modal = document.getElementById('mp-addon-modal');
    var closeBtn = document.getElementById('mp-addon-close');
    var loading = document.getElementById('mp-addon-loading');
    var content = document.getElementById('mp-addon-content');

    if (!overlay) return;

    // Open popup on "Scegli" button click
    document.addEventListener('click', function (e) {
      var btn = e.target.closest('.mp-btn-addon-popup');
      if (!btn) return;
      e.preventDefault();

      var productUrl = btn.getAttribute('data-product-url');
      if (!productUrl) return;

      openPopup();
      loadProductForm(productUrl);
    });

    // Close popup
    if (closeBtn) {
      closeBtn.addEventListener('click', closePopup);
    }
    overlay.addEventListener('click', function (e) {
      if (e.target === overlay) closePopup();
    });
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') closePopup();
    });

    function openPopup() {
      overlay.classList.add('mp-addon-visible');
      document.body.style.overflow = 'hidden';
      loading.style.display = '';
      content.style.display = 'none';
      content.innerHTML = '';
    }

    function closePopup() {
      overlay.classList.remove('mp-addon-visible');
      document.body.style.overflow = '';
    }

    function loadProductForm(url) {
      fetch(url)
        .then(function (r) { return r.text(); })
        .then(function (html) {
          var parser = new DOMParser();
          var doc = parser.parseFromString(html, 'text/html');

          // Extract product image, title, price, and form
          var imgEl = doc.querySelector('.woocommerce-product-gallery img, .wp-post-image');
          var titleEl = doc.querySelector('.product_title, .entry-title');
          var priceEl = doc.querySelector('.price, .woocommerce-Price-amount');
          var descEl = doc.querySelector('.woocommerce-product-details__short-description');
          var formEl = doc.querySelector('form.cart, form.variations_form');

          var popupHtml = '<div class="mp-addon-product">';

          // Product header
          popupHtml += '<div class="mp-addon-header">';
          if (imgEl) {
            popupHtml += '<img src="' + (imgEl.getAttribute('data-large_image') || imgEl.src) + '" class="mp-addon-img" alt="" />';
          }
          popupHtml += '<div class="mp-addon-title-wrap">';
          if (titleEl) {
            popupHtml += '<h2 class="mp-addon-title">' + titleEl.textContent + '</h2>';
          }
          if (descEl) {
            popupHtml += '<p class="mp-addon-desc">' + descEl.textContent.trim().substring(0, 120) + '</p>';
          }
          if (priceEl) {
            popupHtml += '<div class="mp-addon-price">' + priceEl.innerHTML + '</div>';
          }
          popupHtml += '</div></div>';

          // Product form (addons / variations)
          if (formEl) {
            popupHtml += '<div class="mp-addon-form-wrap">' + formEl.outerHTML + '</div>';
          }

          popupHtml += '</div>';

          loading.style.display = 'none';
          content.innerHTML = popupHtml;
          content.style.display = '';

          // Re-init WooCommerce variation form scripts
          if (typeof jQuery !== 'undefined' && jQuery.fn.wc_variation_form) {
            jQuery('.variations_form').each(function () {
              jQuery(this).wc_variation_form();
            });
          }

          // Style the addon form inside popup
          styleAddonForm();
        })
        .catch(function () {
          loading.style.display = 'none';
          content.innerHTML = '<p class="mp-addon-error">Errore nel caricamento. Riprova.</p>';
          content.style.display = '';
        });
    }

    function styleAddonForm() {
      // Add visual labels to variation selects
      var selects = content.querySelectorAll('.variations select, select[id^="addon-"]');
      selects.forEach(function (sel) {
        sel.classList.add('mp-addon-select');
      });

      // Style the add to cart button inside popup
      var addBtn = content.querySelector('.single_add_to_cart_button');
      if (addBtn) {
        addBtn.classList.add('mp-btn-order', 'mp-btn-popup-submit');
        addBtn.textContent = '🛒 Aggiungi al Carrello';
      }
    }
  }

  /* ─── Simple Add to Cart (AJAX) ─── */
  function initSimpleAddToCart() {
    document.addEventListener('click', function (e) {
      var btn = e.target.closest('.mp-btn-add-to-cart');
      if (!btn) return;
      e.preventDefault();

      var productId = btn.getAttribute('data-product-id');
      if (!productId) return;

      btn.classList.add('mp-btn-loading');
      btn.disabled = true;

      // WooCommerce AJAX add to cart
      var data = new FormData();
      data.append('product_id', productId);
      data.append('quantity', '1');

      var ajaxUrl = (typeof wc_add_to_cart_params !== 'undefined')
        ? wc_add_to_cart_params.wc_ajax_url.replace('%%endpoint%%', 'add_to_cart')
        : '/?wc-ajax=add_to_cart';

      fetch(ajaxUrl, {
        method: 'POST',
        body: new URLSearchParams({ product_id: productId, quantity: 1 }),
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      })
        .then(function (r) { return r.json(); })
        .then(function (res) {
          btn.classList.remove('mp-btn-loading');
          btn.disabled = false;

          if (res.error) {
            btn.textContent = '⚠ Errore';
            setTimeout(function () {
              btn.innerHTML = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"/></svg> Aggiungi';
            }, 2000);
            return;
          }

          // Success animation
          btn.classList.add('mp-btn-added');
          btn.innerHTML = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg> Aggiunto!';

          // Update cart count in header if exists
          var cartCount = document.querySelector('.mp-cart-count');
          if (cartCount && res.cart_hash) {
            var current = parseInt(cartCount.textContent) || 0;
            cartCount.textContent = current + 1;
          }

          setTimeout(function () {
            btn.classList.remove('mp-btn-added');
            btn.innerHTML = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"/></svg> Aggiungi';
          }, 2500);
        })
        .catch(function () {
          btn.classList.remove('mp-btn-loading');
          btn.disabled = false;
        });
    });
  }

  /* ─── Sticky Category Nav ─── */
  function initStickyNav() {
    var nav = document.getElementById('mp-category-nav');
    if (!nav) return;

    var hero = document.querySelector('.mp-shop-hero');
    if (!hero) return;

    var observer = new IntersectionObserver(
      function (entries) {
        entries.forEach(function (entry) {
          if (!entry.isIntersecting) {
            nav.classList.add('mp-category-nav-sticky');
          } else {
            nav.classList.remove('mp-category-nav-sticky');
          }
        });
      },
      { threshold: 0 }
    );

    observer.observe(hero);
  }
})();
