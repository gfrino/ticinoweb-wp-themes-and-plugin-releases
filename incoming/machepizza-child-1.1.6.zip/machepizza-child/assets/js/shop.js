jQuery(document).ready(function($) {

    /* --- 0. AUTO-OPEN QUICK ORDER POPUP --- */
    const urlParams = new URLSearchParams(window.location.search);
    const quickOrderId = urlParams.get('mp_quick_order');
    if (quickOrderId) {
        setTimeout(function() {
            let $btn = $('.mp-quick-order-btn[data-product_id="' + quickOrderId + '"]');
            if ($btn.length) {
                $btn.trigger('click');
            }
            // Puliamo l'URL senza ricaricare la pagina per evitare riaperture in caso di refresh
            let newUrl = window.location.protocol + "//" + window.location.host + window.location.pathname;
            window.history.replaceState({path: newUrl}, '', newUrl);
        }, 300); // Piccolo ritardo per assicurarsi che il DOM sia pronto
    }
    /* --- 1. SEARCH ON ENTER --- */
    $('#mp-instant-search').on('keypress', function(e) {
        if (e.which === 13) {
            e.preventDefault();
            let term = $(this).val().toLowerCase().trim();
            let hasResults = false;

            if (term.length === 0) {
                $('.mp-menu-category-block').show();
                $('.mp-menu-row').show();
                $('#mp-no-results').hide();
                return;
            }

            $('.mp-menu-category-block').each(function() {
                let catHasResults = false;
                let $catBlock = $(this);

                $catBlock.find('.mp-menu-row').each(function() {
                    let text = $(this).attr('data-search-term');
                    if (text && text.indexOf(term) > -1) {
                        $(this).show();
                        catHasResults = true;
                        hasResults = true;
                    } else {
                        $(this).hide();
                    }
                });

                if (catHasResults) {
                    $catBlock.show();
                } else {
                    $catBlock.hide();
                }
            });

            if (hasResults) {
                $('#mp-no-results').hide();
                // Scrolla gentilmente al primo risultato visibile, meno l'altezza dell'header
                $('html, body').animate({
                    scrollTop: $('.mp-menu-category-block:visible').first().offset().top - 180
                }, 400);
            } else {
                $('#mp-no-results').show();
            }
        }
    });

    // Se l'utente cancella tutto il testo nel campo, ripristina la visualizzazione completa
    $('#mp-instant-search').on('input', function() {
        if ($(this).val().trim() === '') {
            $('.mp-menu-category-block').show();
            $('.mp-menu-row').show();
            $('#mp-no-results').hide();
        }
    });


    /* --- 2. SMOOTH SCROLL CATEGORIES --- */
    $('.mp-shop-cat-pill').on('click', function(e) {
        let target = $(this).attr('href');
        if (target.startsWith('#cat-')) {
            e.preventDefault();
            let $target = $(target);
            if ($target.length) {
                $('html, body').animate({
                    scrollTop: $target.offset().top - 170
                }, 400);
            }
            // Active state
            $('.mp-shop-cat-pill').removeClass('active');
            $(this).addClass('active');
        }
    });

    // Update active pill on scroll
    $(window).on('scroll', function() {
        let scrollPos = $(document).scrollTop();
        $('.mp-menu-category-block').each(function() {
            let top = $(this).offset().top - 200;
            let bottom = top + $(this).outerHeight();
            if (scrollPos >= top && scrollPos <= bottom) {
                let id = $(this).attr('id');
                $('.mp-shop-cat-pill').removeClass('active');
                $('.mp-shop-cat-pill[href="#' + id + '"]').addClass('active');
            }
        });
    });


    /* --- 3. CUSTOM QUANTITY PICKER --- */
    $(document).on('click', '.mp-qty-plus, .mp-qty-minus', function() {
        let $picker = $(this).closest('.mp-qty-picker');
        let $input = $picker.find('.mp-qty-input');
        let $addToCartBtn = $picker.next('.ajax_add_to_cart');
        
        let currentVal = parseInt($input.val()) || 1;
        let max = parseInt($input.attr('max')) || 99;
        let min = parseInt($input.attr('min')) || 1;

        if ($(this).hasClass('mp-qty-plus')) {
            if (currentVal < max) currentVal++;
        } else {
            if (currentVal > min) currentVal--;
        }

        $input.val(currentVal);
        
        // Sync with WooCommerce add to cart button
        if ($addToCartBtn.length) {
            $addToCartBtn.attr('data-quantity', currentVal);
        }
    });


    /* --- 4. DRAWER CARRELLO (UI) --- */
    function openCartDrawer() {
        $('#mp-shop-cart-sidebar').addClass('is-open');
        $('#mp-cart-overlay').addClass('is-active');
        $('body').css('overflow', 'hidden').addClass('mp-cart-open');
    }

    function closeCartDrawer() {
        $('#mp-shop-cart-sidebar').removeClass('is-open');
        $('#mp-cart-overlay').removeClass('is-active');
        $('body').css('overflow', '').removeClass('mp-cart-open');
    }

    $('#mp-mobile-cart-fab, .mp-cart-overlay').on('click', function() {
        if ($('#mp-shop-cart-sidebar').hasClass('is-open')) {
            closeCartDrawer();
        } else {
            openCartDrawer();
        }
    });

    $('#mp-cart-close').on('click', closeCartDrawer);


    /* --- 5. WOOCOMMERCE AJAX CART FRAGMENTS SYNC --- */
    // WooCommerce usa un body event quando aggiunge al carrello
    $('body').on('added_to_cart', function(e, fragments, cart_hash, $button) {
        // Apri il carrello per feedback
        openCartDrawer();
        
        // Aggiorna conteggio FAB
        updateFabCount();
        
        // Reset quantità input e bottone dopo aggiunta
        if ($button && $button.length) {
            let $picker = $button.prev('.mp-qty-picker');
            if ($picker.length) {
                $picker.find('.mp-qty-input').val(1);
                $button.attr('data-quantity', 1);
            }
            
            // Effetto visivo bottone
            let originalText = $button.text();
            $button.text('Aggiunto!');
            setTimeout(function() {
                $button.text(originalText);
            }, 2000);
        }
    });

    // Inizializza il carrello al caricamento pagina se siamo su shop
    if ($('#mp-shop-cart-sidebar').length) {
        // Trigger manuale fragment refresh per caricare il contenuto iniziale
        $('body').trigger('wc_fragment_refresh');
    }
    
    // Aggiorna conteggio FAB e chiusura quando frammenti ricaricano (es. eliminazione prodotto)
    $('body').on('wc_fragments_refreshed wc_fragments_loaded', function() {
        updateFabCount();
        
        // Se il carrello è vuoto (lo controlliamo verificando se ci sono item)
        let $items = $('#mp-cart-body').find('.woocommerce-mini-cart-item');
        if ($items.length === 0) {
            // Aggiungiamo un messaggio amichevole se WooCommerce non lo mette già
            if ($('#mp-cart-body').find('.woocommerce-mini-cart__empty-message').length === 0) {
                $('#mp-cart-body').find('.widget_shopping_cart_content').html('<div class="mp-cart-loading" style="padding: 30px; text-align: center; color: #777;">Il tuo carrello è vuoto.</div>');
            }
        }
    });

    function updateFabCount() {
        // Conta elementi cercando nel DOM del fragment
        let count = 0;
        let $items = $('#mp-cart-body').find('.woocommerce-mini-cart-item');
        if ($items.length) {
            // Selezioniamo le quantità, a volte in format testuale "1 x"
            $items.each(function() {
                let qtyText = $(this).find('.quantity').text();
                // Estrae il numero prima della 'x' o dalla stringa
                let qtyMatch = qtyText.match(/(\d+)/);
                if (qtyMatch && qtyMatch[1]) {
                    count += parseInt(qtyMatch[1]);
                } else {
                    count++; // Fallback
                }
            });
        }
        $('#mp-fab-count').text(count);
    }

    /* --- 6. QUICK ORDER PANEL --- */
    const $qopPanel = $('#mp-quick-order-panel');
    const $qopOverlay = $('#mp-quick-order-overlay');
    const $qopContent = $('#mp-qop-content');
    
    function openQOP() {
        $qopOverlay.addClass('is-active');
        $qopPanel.addClass('is-active');
        $('body').css('overflow', 'hidden');
    }
    
    function closeQOP() {
        $qopOverlay.removeClass('is-active');
        $qopPanel.removeClass('is-active');
        $('body').css('overflow', '');
    }

    $('#mp-qop-close, #mp-quick-order-overlay').on('click', closeQOP);

    $(document).on('click', '.mp-quick-order-btn', function(e) {
        e.preventDefault();
        e.stopPropagation();

        let $btn = $(this);
        let productId = $btn.data('product_id');
        let productType = $btn.data('product_type');
        let quantity = 1;
        
        let $picker = $btn.closest('.mp-menu-row-actions').find('.mp-qty-input');
        if($picker.length) {
            quantity = parseInt($picker.val()) || 1;
        }

        // SE E' PRODOTTO SEMPLICE -> AJAX DIRETTO
        if (productType === 'simple' || productType === '') {
            let originalText = $btn.text();
            $btn.text('Aggiungo...').prop('disabled', true);
            
            let ajaxUrl = (typeof wc_add_to_cart_params !== 'undefined') ? wc_add_to_cart_params.wc_ajax_url.toString().replace( '%%endpoint%%', 'add_to_cart' ) : '/?wc-ajax=add_to_cart';
            
            $.ajax({
                type: 'POST',
                url: ajaxUrl,
                data: {
                    product_id: productId,
                    quantity: quantity
                },
                success: function(response) {
                    if (response.error && response.product_url) {
                        alert('Impossibile aggiungere il prodotto. Verifica la disponibilità.');
                        $btn.text(originalText).prop('disabled', false);
                        return;
                    }
                    // Trigger evento nativo woo
                    $(document.body).trigger('added_to_cart', [response.fragments, response.cart_hash, $btn]);
                    
                    $btn.text('Aggiunto!').addClass('success');
                    setTimeout(function() {
                        $btn.text(originalText).removeClass('success').prop('disabled', false);
                    }, 2000);
                },
                error: function() {
                    alert('Errore di connessione. Riprova.');
                    $btn.text(originalText).prop('disabled', false);
                }
            });
            return;
        }
        
        // SE E' VARIABILE/CON OPZIONI -> APRI DRAWER
        $qopContent.html('<div class="mp-qop-loader"><div class="mp-spinner"></div><p>Caricamento opzioni...</p></div>');
        openQOP();
        
        $.ajax({
            url: machepizza_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'mp_quick_order_form',
                product_id: productId
            },
            success: function(response) {
                if(response.success) {
                    $qopContent.html(response.data);
                    
                    let $form = $qopContent.find('form.cart, form.variations_form');
                    
                    // Aggiungi Stepper Custom per Quantità
                    $form.find('input.qty').each(function() {
                        let $input = $(this);
                        if(!$input.parent().hasClass('mp-stepper')) {
                            let $wrapper = $('<div class="mp-stepper"></div>');
                            let $minus = $('<button type="button" class="mp-stepper-btn minus">-</button>');
                            let $plus = $('<button type="button" class="mp-stepper-btn plus">+</button>');
                            
                            $input.wrap($wrapper);
                            $input.before($minus);
                            $input.after($plus);
                        }
                    });

                    // Ristruttura per avere un footer sticky
                    let $button = $form.find('button[type="submit"]');
                    let $qty = $form.find('.mp-stepper').parent('.quantity');
                    if($qty.length === 0) $qty = $form.find('.quantity');
                    let $addonsTotal = $form.find('#product-addons-total');
                    let $varPrice = $form.find('.woocommerce-variation-price'); // Variabili
                    
                    if($button.length) {
                        let $footer = $('<div class="mp-qop-sticky-footer"></div>');
                        let $footerActions = $('<div class="mp-qop-footer-actions"></div>');
                        
                        if($addonsTotal.length) $footer.append($addonsTotal);
                        if($varPrice.length) $footer.append($varPrice);
                        
                        if($qty.length) $footerActions.append($qty);
                        
                        $button.html('<span class="mp-btn-text">Aggiungi</span>')
                               .removeClass('alt single_add_to_cart_button')
                               .addClass('mp-btn mp-btn-primary mp-btn-large mp-btn-popup-submit');
                        
                        $footerActions.append($button);
                        $footer.append($footerActions);
                        
                        $form.append($footer);
                        
                        // Assicuriamoci che il totale degli addon si aggiorni
                        $(document.body).trigger('init_addon_totals');
                    }
                    
                    // Inizializza eventi per lo stepper
                    $qopContent.find('.mp-stepper-btn').off('click').on('click', function(e) {
                        e.preventDefault();
                        let $btn = $(this);
                        let $input = $btn.siblings('input.qty');
                        let val = parseInt($input.val()) || 1;
                        let min = parseInt($input.attr('min')) || 1;
                        let max = parseInt($input.attr('max')) || 999;
                        
                        if($btn.hasClass('minus')) {
                            if(val > min) $input.val(val - 1).trigger('change');
                        } else {
                            if(val < max) $input.val(val + 1).trigger('change');
                        }
                    });
                    
                    // Initialize WC variation form
                    if (typeof $.fn.wc_variation_form !== 'undefined') {
                        $qopContent.find('.variations_form').wc_variation_form();
                        $qopContent.find('.variations_form').trigger('check_variations');
                    }
                } else {
                    $qopContent.html('<p class="mp-qop-error">Errore: ' + response.data + '</p>');
                }
            },
            error: function() {
                $qopContent.html('<p class="mp-qop-error">Errore di rete. Riprova.</p>');
            }
        });
    });

    let isAddingToCart = false;

    // AJAX form submission per varianti dentro al modal (no redirect)
    $(document).on('submit', '#mp-qop-content form.cart', function(e) {
        e.preventDefault();
        e.stopImmediatePropagation();
        
        if (isAddingToCart) return;
        isAddingToCart = true;
        
        let $form = $(this);
        let $button = $form.find('button[type="submit"]');
        let formData = new FormData($form[0]);
        
        // Rimuoviamo TASSATIVAMENTE 'add-to-cart' per evitare che WooCommerce 
        // nativo intercetti la richiesta su wp_loaded e aggiunga il prodotto due volte!
        formData.delete('add-to-cart');
        
        // Assicuriamoci che ci sia un product_id
        let productIdVal = $form.find('[name="product_id"]').val() || $button.val() || $button.data('product_id');
        if(productIdVal) {
            formData.append('product_id', productIdVal);
        }

        $button.html('<span class="mp-btn-text">Aggiungo...</span>').addClass('mp-btn-loading').prop('disabled', true);

        $.ajax({
            url: (typeof wc_add_to_cart_params !== 'undefined') ? wc_add_to_cart_params.wc_ajax_url.toString().replace( '%%endpoint%%', 'machepizza_add_to_cart' ) : '/?wc-ajax=machepizza_add_to_cart',
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            success: function(response) {
                if (response.error && response.product_url) {
                    alert('Errore: verifica di aver selezionato tutte le opzioni obbligatorie.');
                    $button.html('<span class="mp-btn-text">Aggiungi</span>').removeClass('mp-btn-loading').prop('disabled', false);
                    isAddingToCart = false;
                    return;
                }
                
                $button.html('<span class="mp-btn-text">Aggiunto!</span>').removeClass('mp-btn-loading').addClass('success');
                
                // Trigger evento nativo woo per aggiornare il carrello
                $(document.body).trigger('added_to_cart', [response.fragments, response.cart_hash, $button]);
                
                // Chiudi il drawer dopo 1 secondo
                setTimeout(function() {
                    closeQOP();
                    isAddingToCart = false;
                }, 800);
            },
            error: function() {
                $button.removeClass('mp-btn-loading').html('<span class="mp-btn-text">Riprova</span>').prop('disabled', false);
                isAddingToCart = false;
            }
        });
    });

});
