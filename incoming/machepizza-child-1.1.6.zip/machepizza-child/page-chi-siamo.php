<?php
/**
 * Template Name: Chi Siamo
 * 
 * Mache Pizza - Pagina "Chi siamo" dinamica e immersiva
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

get_header(); 

// ---------------------------------------------------------
// 1. FETCH DYNAMIC DATA FROM CMS (con Fallback Mache Pizza)
// ---------------------------------------------------------

// Sezione 1: Hero
$hero_title    = get_option('ticinoweb_chi_siamo_title', 'Mache Pizza, il gusto italiano in Ticino');
$hero_subtitle = get_option('ticinoweb_chi_siamo_subtitle', 'Pizza calda, ingredienti scelti e tutto il piacere di una tavola condivisa. Da Mache Pizza ogni ordine nasce per portare a casa tua qualcosa di semplice, buono e familiare.');
$hero_image    = get_option('ticinoweb_chi_siamo_image', 'https://images.unsplash.com/photo-1590947132387-155cc02f3212?ixlib=rb-1.2.1&auto=format&fit=crop&w=1200&q=80');

// Sezione 2: Storia
$storia_title = get_option('ticinoweb_chi_siamo_storia_title', 'Una pizza semplice, buona, di casa');
$storia_text  = get_option('ticinoweb_chi_siamo_text', 'Mache Pizza nasce con un’idea chiara: portare il gusto della pizza italiana nella quotidianità, con un servizio semplice, diretto e pensato per chi vuole ordinare qualcosa di buono senza complicazioni.<br><br>Una pizza generosa, calda e piena di carattere, perfetta per una cena in famiglia, una pausa veloce o una serata da condividere. Non ci sono segreti complicati: solo un impasto curato, farciture ricche e il sapore di qualcosa fatto con passione.');

// CTA Links
$shop_link = function_exists('wc_get_page_permalink') ? wc_get_page_permalink('shop') : '/shop';
$cta_link  = get_option('ticinoweb_chi_siamo_link', $shop_link);

// PDF menu logic (come in home)
$pdf_url = get_option('machepizza_downloadable_menu_link', '');
$menu_link = !empty($pdf_url) ? $pdf_url : $shop_link;
$menu_target = !empty($pdf_url) ? 'target="_blank" rel="noopener"' : '';
?>

<div class="mp-chi-siamo-page">

    <!-- 1. HERO CHI SIAMO -->
    <section class="mp-cs-hero mp-section" style="position: relative;">
        <div class="mp-cs-hero-bg"></div>
        
        <!-- Decorazioni Fluttuanti Chi Siamo -->
        <div class="mp-floating-decorations">
            <div class="mp-deco-item mp-deco-1" style="font-size: 3rem;">🍅</div>
            <div class="mp-deco-item mp-deco-3">🌿</div>
            <div class="mp-deco-item mp-deco-5">🧄</div>
            <div class="mp-deco-item mp-deco-8" style="font-size: 2.5rem;">🧀</div>
        </div>

        <div class="mp-container mp-cs-hero-container">
            <div class="mp-cs-hero-content mp-reveal">
                <span class="mp-cs-tag">La Nostra Storia</span>
                <h1 class="mp-cs-hero-title"><?php echo wp_kses_post($hero_title); ?></h1>
                <p class="mp-cs-hero-subtitle"><?php echo wp_kses_post($hero_subtitle); ?></p>
                <div class="mp-cs-hero-actions">
                    <a href="<?php echo esc_url($menu_link); ?>" <?php echo $menu_target; ?> class="mp-btn mp-btn-primary">Scarica il menu</a>
                </div>
            </div>
            <div class="mp-cs-hero-visual mp-reveal" style="transition-delay: 0.2s;">
                <div class="mp-cs-hero-image-wrap">
                    <img src="<?php echo esc_url($hero_image); ?>" alt="Mache Pizza Chi Siamo" class="mp-cs-img">
                </div>
            </div>
        </div>
        
        <!-- Bottom Wave -->
        <div class="mp-hero-wave">
            <svg viewBox="0 0 1440 120" preserveAspectRatio="none">
                <path d="M0,32 C360,140 1080,-30 1440,60 L1440,120 L0,120 Z" class="shape-fill" style="fill: var(--mp-cream);"></path>
            </svg>
        </div>
    </section>

    <!-- 2. SEZIONE STORIA -->
    <section class="mp-cs-storia mp-section" style="background: var(--mp-cream);">
        <div class="mp-container">
            <div class="mp-cs-storia-inner mp-reveal">
                <div class="mp-cs-storia-text-box">
                    <h2 class="mp-section-title"><?php echo esc_html($storia_title); ?></h2>
                    <div class="mp-cs-storia-content">
                        <?php echo wpautop(wp_kses_post($storia_text)); ?>
                    </div>
                </div>
                <div class="mp-cs-storia-visual">
                    <div class="mp-cs-polaroid">
                        <img src="https://images.unsplash.com/photo-1513104890138-7c749659a591?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80" alt="Pizza al forno" class="mp-cs-polaroid-img">
                        <div class="mp-cs-polaroid-caption">Passione e farina</div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- 2.5 SEZIONE VIDEO -->
    <section class="mp-cs-video-section mp-section">
        <div class="mp-container">
            <div class="mp-section-header mp-text-center mp-reveal">
                <h2 class="mp-section-title">Guarda il gusto prendere forma</h2>
                <p class="mp-section-subtitle">Un assaggio dell’atmosfera Mache Pizza: calore, ingredienti semplici e quella voglia di pizza che arriva ancora prima del primo morso.</p>
            </div>
            
            <div class="mp-cs-video-wrapper mp-reveal" style="transition-delay: 0.2s;">
                <div class="mp-cs-video-glow"></div>
                <div class="mp-cs-video-frame">
                    <?php 
                    // Recupera il video dinamicamente dal metabox/opzioni o fallback a quello esistente
                    $dynamic_video = get_option('ticinoweb_chi_siamo_video');
                    $video_id = 5381;
                    
                    if (!empty($dynamic_video)) {
                        $video_url = $dynamic_video;
                    } else {
                        $video_url = wp_get_attachment_url($video_id);
                    }
                    
                    // Immagine di fallback / poster (placeholder elegante)
                    $poster_url = 'https://images.unsplash.com/photo-1590947132387-155cc02f3212?ixlib=rb-1.2.1&auto=format&fit=crop&w=1200&q=80'; 
                    
                    if ($video_url) : 
                    ?>
                        <video 
                            id="mp-atmosfera-video"
                            class="mp-cs-video-el" 
                            src="<?php echo esc_url($video_url); ?>" 
                            muted playsinline loop controls preload="metadata"
                            poster="<?php echo esc_url($poster_url); ?>"
                        ></video>
                        <div class="mp-cs-video-overlay"></div>
                        <div class="mp-cs-video-badge">Dal forno a casa tua</div>
                        
                        <!-- Piccoli elementi decorativi -->
                        <div class="mp-cs-video-deco mp-deco-basil">🌿</div>
                        <div class="mp-cs-video-deco mp-deco-flour"></div>
                    <?php else : ?>
                        <!-- Fallback Elegante -->
                        <div class="mp-cs-video-fallback">
                            <img src="<?php echo esc_url($poster_url); ?>" alt="Mache Pizza Atmosfera" class="mp-cs-video-fallback-img">
                            <div class="mp-cs-video-fallback-msg">Passione e farina</div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            
            <div class="mp-cs-video-actions mp-text-center mp-reveal" style="transition-delay: 0.4s;">
                <a href="<?php echo esc_url($shop_link); ?>" class="mp-btn mp-btn-primary">Ordina la tua pizza</a>
            </div>
        </div>
        
        <!-- IntersectionObserver Script per performance -->
        <script>
        document.addEventListener('DOMContentLoaded', function() {
            var video = document.getElementById('mp-atmosfera-video');
            if (video && 'IntersectionObserver' in window) {
                var observer = new IntersectionObserver(function(entries) {
                    entries.forEach(function(entry) {
                        if (entry.isIntersecting) {
                            var playPromise = video.play();
                            if (playPromise !== undefined) {
                                playPromise.catch(function(error) {
                                    console.log("Autoplay prevented:", error);
                                });
                            }
                        } else {
                            video.pause();
                        }
                    });
                }, { threshold: 0.2 });
                observer.observe(video);
            } else if (video) {
                video.autoplay = true;
                var playPromise = video.play();
                if (playPromise !== undefined) {
                    playPromise.catch(function(e){});
                }
            }
        });
        </script>
    </section>

    <!-- 3. SEZIONE VALORI -->
    <section class="mp-cs-valori mp-section">
        <div class="mp-container">
            <div class="mp-section-header mp-text-center mp-reveal">
                <h2 class="mp-section-title">Cosa ci rende speciali</h2>
                <p class="mp-section-subtitle">Pochi principi, ma buoni. Proprio come la nostra pizza.</p>
            </div>
            
            <div class="mp-cs-valori-grid">
                <!-- Valore 1 -->
                <div class="mp-cs-valore-card mp-reveal">
                    <div class="mp-cs-valore-icon">🌾</div>
                    <h3>Impasto fragrante</h3>
                    <p>Una base semplice, profumata e pensata per esaltare ogni ingrediente.</p>
                </div>
                
                <!-- Valore 2 -->
                <div class="mp-cs-valore-card mp-reveal" style="transition-delay: 0.1s;">
                    <div class="mp-cs-valore-icon">🧀</div>
                    <h3>Ingredienti scelti</h3>
                    <p>Scegliamo combinazioni generose, dirette e ricche di gusto italiano.</p>
                </div>
                
                <!-- Valore 3 -->
                <div class="mp-cs-valore-card mp-reveal" style="transition-delay: 0.2s;">
                    <div class="mp-cs-valore-icon">📱</div>
                    <h3>Ordine semplice</h3>
                    <p>Dal nostro menu direttamente al tuo carrello in pochi clic, senza complicazioni.</p>
                </div>
                
                <!-- Valore 4 -->
                <div class="mp-cs-valore-card mp-reveal" style="transition-delay: 0.3s;">
                    <div class="mp-cs-valore-icon">🏠</div>
                    <h3>Calore di famiglia</h3>
                    <p>Colori, profumi e sapori che ricordano sempre una grande tavola condivisa.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- 4. SEZIONE ATMOSFERA / TAVOLA -->
    <section class="mp-cs-atmosfera mp-section">
        <div class="mp-cs-atmosfera-bg"></div>
        <div class="mp-container mp-cs-atmosfera-container mp-reveal">
            <div class="mp-cs-atmosfera-content">
                <h2 class="mp-section-title" style="color: #fff;">Il bello della pizza è condividerla</h2>
                <p>Una pizza arriva al centro della tavola e cambia subito l’atmosfera. Si apre il cartone, arriva il profumo, ognuno sceglie la sua fetta e la serata diventa più semplice. È questo il modo in cui immaginiamo Mache Pizza: un momento caldo, diretto e da vivere insieme.</p>
            </div>
        </div>
    </section>

    <!-- 5. DAL FORNO A CASA TUA (Servizio) -->
    <section class="mp-cs-step mp-section" style="background: var(--mp-cream);">
        <div class="mp-container">
            <div class="mp-section-header mp-text-center mp-reveal">
                <h2 class="mp-section-title">Dal forno a casa tua</h2>
                <p class="mp-section-subtitle">Con Mache Pizza puoi scegliere le tue pizze preferite in modo semplice. Pensiamo a una pizza calda, generosa e pronta da gustare.</p>
            </div>
            
            <div class="mp-cs-step-grid">
                <div class="mp-cs-step-item mp-reveal">
                    <div class="mp-cs-step-number">1</div>
                    <h4>Scegli</h4>
                    <p>Scopri il nostro menu e trova la tua pizza preferita.</p>
                </div>
                <div class="mp-cs-step-item mp-reveal" style="transition-delay: 0.1s;">
                    <div class="mp-cs-step-number">2</div>
                    <h4>Ordina</h4>
                    <p>Personalizza e aggiungi al carrello in un attimo.</p>
                </div>
                <div class="mp-cs-step-item mp-reveal" style="transition-delay: 0.2s;">
                    <div class="mp-cs-step-number">3</div>
                    <h4>Gusta</h4>
                    <p>Ritira o aspetta la consegna, e goditi il vero sapore italiano.</p>
                </div>
            </div>
            
            <div class="mp-text-center mp-reveal" style="margin-top: 40px;">
                <a href="<?php echo esc_url($shop_link); ?>" class="mp-btn mp-btn-primary">Vai al Menu</a>
            </div>
        </div>
    </section>

    <section class="mp-cs-cta-section mp-section">
        <div class="mp-container mp-text-center mp-reveal">
            <h2 class="mp-section-title" style="color: var(--mp-yellow);">Hai già voglia di pizza?</h2>
            <p style="color: #fff; font-size: 1.2rem; margin-bottom: 30px; max-width: 600px; margin-left: auto; margin-right: auto;">
                Scopri il menu Mache Pizza e scegli cosa portare in tavola oggi.
            </p>
            <div class="mp-cs-cta-actions" style="display: flex; gap: 15px; justify-content: center;">
                <a href="<?php echo esc_url($shop_link); ?>" class="mp-btn mp-cs-cta-btn">Ordina Ora</a>
                <a href="<?php echo esc_url($menu_link); ?>" <?php echo $menu_target; ?> class="mp-btn mp-btn-outline" style="color:#fff; border-color:#fff;">Scarica il menu</a>
            </div>
        </div>
    </section>

</div>

<?php get_footer(); ?>
