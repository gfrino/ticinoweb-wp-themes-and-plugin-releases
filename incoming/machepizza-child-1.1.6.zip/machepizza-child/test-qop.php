<?php
require_once('/Users/marketing/kDrive/Common documents/Div.4 Delivery/Manuel-AI-Dev/wordpress/wp-load.php');
$product_id = 56; // Assuming 56 is a valid product ID. If not, any product with addons. Let's find one.
$args = array('post_type' => 'product', 'posts_per_page' => 1);
$products = get_posts($args);
$product_id = $products[0]->ID;

$_POST['action'] = 'mp_quick_order_form';
$_POST['product_id'] = $product_id;
do_action('wp_ajax_mp_quick_order_form');
