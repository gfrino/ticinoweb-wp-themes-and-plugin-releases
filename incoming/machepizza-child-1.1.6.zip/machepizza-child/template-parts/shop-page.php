<?php
/**
 * Mache Pizza – WooCommerce Shop Page (archive-product.php)
 *
 * Table-view layout grouped by product categories.
 * Products are displayed as horizontal cards within collapsible category sections.
 * "Ordina" button triggers an AJAX popup to select addons before adding to cart.
 *
 * @package machepizza-child
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

// Get all product categories with products
$categories = get_terms( array(
	'taxonomy'   => 'product_cat',
	'hide_empty' => true,
	'orderby'    => 'menu_order',
	'order'      => 'ASC',
	'parent'     => 0,
) );

// If no top-level categories, try all categories
if ( empty( $categories ) || is_wp_error( $categories ) ) {
	$categories = get_terms( array(
		'taxonomy'   => 'product_cat',
		'hide_empty' => true,
		'orderby'    => 'name',
		'order'      => 'ASC',
	) );
}

// Emoji map for category icons
$cat_icons = array(
	'pizze'      => '🍕',
	'pizza'      => '🍕',
	'calzon'     => '🥟',
	'hamburger'  => '🍔',
	'bibite'     => '🥤',
	'bevand'     => '🥤',
	'dolci'      => '🍰',
	'dessert'    => '🍰',
	'fritti'     => '🍟',
	'kebab'      => '🥙',
	'menu'       => '📋',
	'insalat'    => '🥗',
	'past'       => '🍝',
	'panin'      => '🥪',
);

/**
 * Get an emoji icon for a category based on its slug/name
 */
function mp_get_cat_icon( $cat, $cat_icons ) {
	$slug = strtolower( $cat->slug );
	$name = strtolower( $cat->name );
	foreach ( $cat_icons as $key => $icon ) {
		if ( strpos( $slug, $key ) !== false || strpos( $name, $key ) !== false ) {
			return $icon;
		}
	}
	return '🍽️';
}
?>

<main class="mp-shop-page">
	<!-- Shop Hero Banner -->
	<section class="mp-shop-hero">
		<div class="mp-container">
			<h1 class="mp-shop-hero-title">Il Nostro Menu</h1>
			<p class="mp-shop-hero-subtitle">Scegli tra le nostre specialità, preparate con ingredienti freschi e tanta passione</p>
		</div>
	</section>

	<!-- Category Navigation Pills -->
	<nav class="mp-category-nav" id="mp-category-nav">
		<div class="mp-container">
			<div class="mp-category-pills">
				<button class="mp-pill mp-pill-active" data-target="all">
					<span class="mp-pill-icon">🍽️</span>
					<span>Tutto</span>
				</button>
				<?php if ( ! empty( $categories ) && ! is_wp_error( $categories ) ) : ?>
					<?php foreach ( $categories as $cat ) : ?>
						<button class="mp-pill" data-target="cat-<?php echo esc_attr( $cat->slug ); ?>">
							<span class="mp-pill-icon"><?php echo mp_get_cat_icon( $cat, $cat_icons ); ?></span>
							<span><?php echo esc_html( $cat->name ); ?></span>
							<span class="mp-pill-count"><?php echo intval( $cat->count ); ?></span>
						</button>
					<?php endforeach; ?>
				<?php endif; ?>
			</div>
		</div>
	</nav>

	<!-- Products by Category -->
	<div class="mp-shop-content">
		<div class="mp-container">
			<?php if ( ! empty( $categories ) && ! is_wp_error( $categories ) ) : ?>
				<?php foreach ( $categories as $cat ) :
					// Get products in this category
					$products = new WP_Query( array(
						'post_type'      => 'product',
						'posts_per_page' => -1,
						'post_status'    => 'publish',
						'orderby'        => 'title',
						'order'          => 'ASC',
						'tax_query'      => array(
							array(
								'taxonomy' => 'product_cat',
								'field'    => 'term_id',
								'terms'    => $cat->term_id,
							),
						),
					) );

					if ( ! $products->have_posts() ) {
						wp_reset_postdata();
						continue;
					}
					$icon = mp_get_cat_icon( $cat, $cat_icons );
				?>
				<section class="mp-cat-section" id="cat-<?php echo esc_attr( $cat->slug ); ?>" data-category="<?php echo esc_attr( $cat->slug ); ?>">
					<div class="mp-cat-header">
						<div class="mp-cat-header-left">
							<span class="mp-cat-icon"><?php echo $icon; ?></span>
							<h2 class="mp-cat-title"><?php echo esc_html( $cat->name ); ?></h2>
							<span class="mp-cat-count"><?php echo intval( $cat->count ); ?> prodotti</span>
						</div>
						<button class="mp-cat-toggle" aria-expanded="true" aria-controls="cat-list-<?php echo esc_attr( $cat->slug ); ?>">
							<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>
						</button>
					</div>

					<div class="mp-cat-products" id="cat-list-<?php echo esc_attr( $cat->slug ); ?>">
						<?php while ( $products->have_posts() ) : $products->the_post();
							global $product;
							if ( ! $product || ! $product->is_visible() ) continue;

							$image     = wp_get_attachment_image_url( $product->get_image_id(), 'woocommerce_thumbnail' );
							$price     = $product->get_price_html();
							$has_addons = $product->is_type( 'variable' ) || ( is_array( get_post_meta( $product->get_id(), '_product_addons', true ) ) && ! empty( get_post_meta( $product->get_id(), '_product_addons', true ) ) );
							$permalink = get_permalink();
							$short_desc = $product->get_short_description();
						?>
						<div class="mp-product-row" data-product-id="<?php echo esc_attr( $product->get_id() ); ?>">
							<div class="mp-product-img-wrap">
								<?php if ( $image ) : ?>
									<img src="<?php echo esc_url( $image ); ?>" alt="<?php echo esc_attr( $product->get_name() ); ?>" class="mp-product-img" loading="lazy" />
								<?php else : ?>
									<div class="mp-product-img-placeholder">
										<span>🍕</span>
									</div>
								<?php endif; ?>
							</div>
							<div class="mp-product-info">
								<h3 class="mp-product-name"><?php echo esc_html( $product->get_name() ); ?></h3>
								<?php if ( $short_desc ) : ?>
									<p class="mp-product-desc"><?php echo wp_kses_post( wp_trim_words( wp_strip_all_tags( $short_desc ), 15 ) ); ?></p>
								<?php endif; ?>
							</div>
							<div class="mp-product-action">
								<span class="mp-product-price"><?php echo wp_kses_post( $price ); ?></span>
								<?php if ( $has_addons ) : ?>
									<button class="mp-btn-order mp-btn-addon-popup"
										data-product-id="<?php echo esc_attr( $product->get_id() ); ?>"
										data-product-url="<?php echo esc_url( $permalink ); ?>">
										<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="16"/><line x1="8" y1="12" x2="16" y2="12"/></svg>
										Scegli
									</button>
								<?php else : ?>
									<button class="mp-btn-order mp-btn-add-to-cart"
										data-product-id="<?php echo esc_attr( $product->get_id() ); ?>">
										<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"/></svg>
										Aggiungi
									</button>
								<?php endif; ?>
							</div>
						</div>
						<?php endwhile; wp_reset_postdata(); ?>
					</div>
				</section>
				<?php endforeach; ?>
			<?php else : ?>
				<p class="mp-no-products">Nessun prodotto trovato.</p>
			<?php endif; ?>
		</div>
	</div>

	<!-- Addon Popup Modal -->
	<div class="mp-addon-overlay" id="mp-addon-overlay">
		<div class="mp-addon-modal" id="mp-addon-modal">
			<button class="mp-addon-close" id="mp-addon-close" aria-label="Chiudi">
				<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
			</button>
			<div class="mp-addon-loading" id="mp-addon-loading">
				<div class="mp-spinner"></div>
				<p>Caricamento opzioni...</p>
			</div>
			<div class="mp-addon-content" id="mp-addon-content" style="display:none;">
				<!-- Dynamically loaded product form -->
			</div>
		</div>
	</div>
</main>

<?php get_footer(); ?>
