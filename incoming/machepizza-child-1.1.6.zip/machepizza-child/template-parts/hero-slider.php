<?php
/**
 * Mache Pizza – Hero Slider
 * Reads slide data from ticinoWEB CMS (ticinoweb_get_slider_data)
 */
$slides = ticinoweb_get_slider_data();
if ( empty( $slides ) ) return;
?>

<section class="mp-hero" id="mp-hero">
    <div class="mp-slider">
        <div class="mp-slider-track">
            <?php foreach ( $slides as $index => $slide ) :
                if ( empty( $slide['image'] ) ) continue;
            ?>
            <div class="mp-slide <?php echo $index === 0 ? 'mp-slide-active' : ''; ?>">
                <div class="mp-slide-bg" style="background-image: url('<?php echo esc_url( $slide['image'] ); ?>')"></div>
                <div class="mp-slide-overlay"></div>
                <div class="mp-slide-content">
                    <?php if ( ! empty( $slide['title'] ) ) : ?>
                    <h1 class="mp-slide-title"><?php echo esc_html( $slide['title'] ); ?></h1>
                    <?php endif; ?>
                    <?php if ( ! empty( $slide['desc'] ) ) : ?>
                    <p class="mp-slide-desc"><?php echo esc_html( $slide['desc'] ); ?></p>
                    <?php endif; ?>
                    <?php if ( ! empty( $slide['btn1_text'] ) ) : ?>
                    <div class="mp-slide-buttons">
                        <a href="<?php echo esc_url( $slide['btn1_link'] ); ?>" class="mp-btn mp-btn-primary mp-btn-lg">
                            <?php echo esc_html( $slide['btn1_text'] ); ?>
                        </a>
                        <a href="tel:<?php
                            $contact = ticinoweb_get_contact_info();
                            echo esc_attr( str_replace( ' ', '', $contact['phone'] ) );
                        ?>" class="mp-btn mp-btn-outline mp-btn-lg">
                            📞 Chiama Ora
                        </a>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            <?php endforeach; ?>
        </div>

        <?php if ( count( $slides ) > 1 ) : ?>
        <button class="mp-slider-arrow mp-slider-prev" aria-label="Slide precedente">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="15 18 9 12 15 6"/></svg>
        </button>
        <button class="mp-slider-arrow mp-slider-next" aria-label="Slide successiva">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="9 6 15 12 9 18"/></svg>
        </button>
        <div class="mp-slider-dots">
            <?php foreach ( $slides as $i => $s ) : ?>
            <button class="mp-dot <?php echo $i === 0 ? 'mp-dot-active' : ''; ?>" data-slide="<?php echo $i; ?>" aria-label="Slide <?php echo $i + 1; ?>"></button>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
    </div>

    <!-- Scroll indicator -->
    <div class="mp-scroll-indicator">
        <span>Scorri</span>
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="6 9 12 15 18 9"/></svg>
    </div>
</section>

<!-- Slider JS -->
<script>
(function() {
    const slides = document.querySelectorAll('.mp-slide');
    const dots = document.querySelectorAll('.mp-dot');
    const prevBtn = document.querySelector('.mp-slider-prev');
    const nextBtn = document.querySelector('.mp-slider-next');
    if (slides.length <= 1) return;

    let current = 0;
    let interval;

    function goTo(n) {
        slides[current].classList.remove('mp-slide-active');
        if (dots[current]) dots[current].classList.remove('mp-dot-active');
        current = (n + slides.length) % slides.length;
        slides[current].classList.add('mp-slide-active');
        if (dots[current]) dots[current].classList.add('mp-dot-active');
    }

    function startAutoplay() {
        interval = setInterval(function() { goTo(current + 1); }, 6000);
    }

    function resetAutoplay() {
        clearInterval(interval);
        startAutoplay();
    }

    if (prevBtn) prevBtn.addEventListener('click', function() { goTo(current - 1); resetAutoplay(); });
    if (nextBtn) nextBtn.addEventListener('click', function() { goTo(current + 1); resetAutoplay(); });
    dots.forEach(function(dot) {
        dot.addEventListener('click', function() {
            goTo(parseInt(this.dataset.slide));
            resetAutoplay();
        });
    });

    startAutoplay();
})();
</script>
