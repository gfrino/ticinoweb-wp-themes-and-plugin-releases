<?php
/**
 * Mache Pizza – Features Section
 * "Why choose us" grid with pizza-themed icons
 */
?>

<section class="mp-features" id="chi-siamo">
    <div class="mp-container">
        <div class="mp-section-header">
            <span class="mp-section-tag">Perché Sceglierci</span>
            <h2 class="mp-section-title">La Pizza Come Si Deve</h2>
            <p class="mp-section-subtitle">Ingredienti freschi, impasto artigianale e consegna veloce. Questo è Mache Pizza.</p>
        </div>

        <div class="mp-features-grid">
            <div class="mp-feature-card">
                <div class="mp-feature-icon">🍕</div>
                <h3>Pizza Artigianale</h3>
                <p>Impasto a lunga lievitazione con ingredienti selezionati di prima qualità.</p>
            </div>
            <div class="mp-feature-card">
                <div class="mp-feature-icon">🚗</div>
                <h3>Consegna Veloce</h3>
                <p>Consegna rapida a domicilio nella zona di Montagnola e dintorni.</p>
            </div>
            <div class="mp-feature-card">
                <div class="mp-feature-icon">⭐</div>
                <h3>Qualità Garantita</h3>
                <p>Ogni pizza è preparata al momento con passione e cura nei dettagli.</p>
            </div>
            <div class="mp-feature-card">
                <div class="mp-feature-icon">📱</div>
                <h3>Ordina dall'App</h3>
                <p>Scarica la nostra app per ordinare comodamente e guadagnare punti fedeltà.</p>
            </div>
        </div>
    </div>
</section>
