<?php
/**
 * Mache Pizza – CTA Section
 * Call to action banner with WhatsApp and phone ordering
 */
$contact = ticinoweb_get_contact_info();
?>

<section class="mp-cta">
    <div class="mp-cta-overlay"></div>
    <div class="mp-container mp-cta-content">
        <h2 class="mp-cta-title">Hai Fame? Ordina Adesso!</h2>
        <p class="mp-cta-desc">Ordina online, via WhatsApp o chiamaci direttamente. La tua pizza arriva calda in pochi minuti.</p>
        <div class="mp-cta-buttons">
            <a href="<?php echo esc_url( home_url( '/shop/' ) ); ?>" class="mp-btn mp-btn-primary mp-btn-lg">
                🍕 Ordina Online
            </a>
            <?php if ( ! empty( $contact['phone'] ) ) : ?>
            <a href="https://api.whatsapp.com/send/?phone=<?php echo esc_attr( preg_replace( '/[^0-9]/', '', $contact['phone'] ) ); ?>&text=Ciao!%20Vorrei%20ordinare%20una%20pizza" target="_blank" rel="noopener" class="mp-btn mp-btn-whatsapp mp-btn-lg">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347z"/><path d="M12 0C5.373 0 0 5.373 0 12c0 2.127.556 4.122 1.527 5.855L.064 23.483a.5.5 0 00.615.61l5.723-1.436A11.95 11.95 0 0012 24c6.627 0 12-5.373 12-12S18.627 0 12 0zm0 21.818c-1.937 0-3.74-.562-5.267-1.527l-.377-.224-3.388.85.875-3.333-.248-.393A9.774 9.774 0 012.182 12c0-5.415 4.403-9.818 9.818-9.818S21.818 6.585 21.818 12 17.415 21.818 12 21.818z"/></svg>
                WhatsApp
            </a>
            <a href="tel:<?php echo esc_attr( str_replace( ' ', '', $contact['phone'] ) ); ?>" class="mp-btn mp-btn-outline mp-btn-lg">
                📞 Chiama
            </a>
            <?php endif; ?>
        </div>
    </div>
</section>
