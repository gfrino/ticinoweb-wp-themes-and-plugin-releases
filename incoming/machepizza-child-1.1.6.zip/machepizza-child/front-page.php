<?php
/**
 * Mache Pizza – Front Page
 * Concept: "La pizzeria di casa, pronta da ordinare" (Premium Edition)
 */
get_header();

$has_woo = class_exists('WooCommerce');

// Helper per Hero (Pizze Classiche Normali)
function mp_get_hero_products($limit = 2) {
    if (!class_exists('WooCommerce')) return [];
    
    $args = [
        'post_type' => 'product',
        'posts_per_page' => $limit,
        'tax_query' => [
            [
                'taxonomy' => 'product_cat',
                'field'    => 'slug',
                'terms'    => ['pizze-classiche-normali', 'pizze-classiche', 'pizza'],
                'operator' => 'IN'
            ]
        ]
    ];
    $loop = new WP_Query($args);
    return $loop;
}

// Helper per i Più Scelti (Mix Pizza e Hamburger)
function mp_get_popular_mixed_products($limit = 4) {
    if (!class_exists('WooCommerce')) return [];
    
    $args = [
        'post_type' => 'product',
        'posts_per_page' => $limit,
        'tax_query' => [
            [
                'taxonomy' => 'product_cat',
                'field'    => 'slug',
                'terms'    => ['pizza', 'pizze', 'pizze-classiche-normali', 'hamburger', 'burger', 'burgers'],
                'operator' => 'IN'
            ]
        ]
    ];
    $loop = new WP_Query($args);
    
    // Fallback se vuoto
    if (!$loop->have_posts()) {
        $args = [
            'post_type' => 'product',
            'posts_per_page' => $limit
        ];
        $loop = new WP_Query($args);
    }
    
    return $loop;
}

// Helper icone categorie
function mp_get_category_icon($cat_name) {
    $name = strtolower($cat_name);
    if (strpos($name, 'dolc') !== false || strpos($name, 'dessert') !== false || strpos($name, 'torta') !== false) return '🍰';
    if (strpos($name, 'bevande') !== false || strpos($name, 'bibit') !== false || strpos($name, 'drink') !== false) return '🥤';
    if (strpos($name, 'calzon') !== false) return '🥟';
    if (strpos($name, 'burger') !== false || strpos($name, 'hamburger') !== false) return '🍔';
    if (strpos($name, 'kebab') !== false || strpos($name, 'wrap') !== false || strpos($name, 'piadin') !== false) return '🌯';
    if (strpos($name, 'fritt') !== false || strpos($name, 'sfizi') !== false) return '🍟';
    if (strpos($name, 'menu') !== false || strpos($name, 'combo') !== false || strpos($name, 'offert') !== false) return '🛍️';
    if (strpos($name, 'bianch') !== false) return '🧀';
    if (strpos($name, 'special') !== false) return '🌟';
    return '🍕'; // Fallback per pizza
}

$shop_url = class_exists('WooCommerce') ? wc_get_page_permalink('shop') : '/shop';
?>

<div class="mp-home-wrapper">

    <?php 
    // Prepare slider data for Ken Burns background
    $slider_html = do_shortcode('[ticinoweb_slider]');
    $slides = [];
    
    if (strpos($slider_html, '[ticinoweb_slider]') !== false || empty(trim($slider_html))) {
        if (function_exists('ticinoweb_get_slider_data')) {
            $slides = ticinoweb_get_slider_data();
        }
    }

    if (empty($slides)) {
        $slides = [[
            'title' => 'La pizza che sa di casa, pronta da ordinare',
            'desc' => 'Impasto fragrante, ingredienti scelti e tutto il calore della tradizione italiana. Scegli la tua pizza e gustala calda, semplice e generosa.',
            'btn1_text' => 'Ordina ora',
            'btn1_link' => $shop_url
        ]];
    }
    
    // Extract BG images
    $hero_bg_images = [];
    foreach($slides as $s) {
        if(!empty($s['image'])) {
            $hero_bg_images[] = $s['image'];
        }
    }
    ?>

    <!-- 1. HERO COMPACT -->
    <section class="mp-hero-compact">
        <?php if (!empty($hero_bg_images)): ?>
            <div class="mp-hero-bg-slider">
                <?php foreach($hero_bg_images as $i => $img_url): ?>
                    <div class="mp-hero-bg-slide slide-<?php echo $i; ?>" style="background-image: url('<?php echo esc_url($img_url); ?>');"></div>
                <?php endforeach; ?>
            </div>
            <div class="mp-hero-bg-overlay"></div>
        <?php endif; ?>

        <!-- Nuove Decorazioni Fluttuanti -->
        <div class="mp-floating-decorations">
            <div class="mp-deco-item mp-deco-1">🍕</div>
            <div class="mp-deco-item mp-deco-2">🌿</div>
            <div class="mp-deco-item mp-deco-3">🍅</div>
            <div class="mp-deco-item mp-deco-4">🧀</div>
            <div class="mp-deco-item mp-deco-5">🧄</div>
            <div class="mp-deco-item mp-deco-6">🔥</div>
            <div class="mp-deco-item mp-deco-7">🍄</div>
            <div class="mp-deco-item mp-deco-8">🫒</div>
        </div>

        <div class="mp-container mp-reveal">
            <?php
            $slide = $slides[0];
            $title = !empty($slide['title']) ? $slide['title'] : 'La pizza che sa di casa, pronta da ordinare';
            $desc = !empty($slide['desc']) ? $slide['desc'] : 'Impasto fragrante, ingredienti scelti e tutto il calore della tradizione italiana.';
            $btn_text = !empty($slide['btn1_text']) ? $slide['btn1_text'] : 'Ordina ora';
            $btn_link = $shop_url; // Forza verso lo shop
            ?>
            <div class="mp-hero-content">
                <!-- SINISTRA: Testi -->
                <div class="mp-hero-left">
                    <span class="mp-hero-eyebrow">Mache Pizza &bull; Ticino</span>
                    <h1><?php echo esc_html($title); ?></h1>
                    <p><?php echo esc_html($desc); ?></p>
                    
                    <div class="mp-hero-actions">
                        <a href="<?php echo esc_url($btn_link); ?>" class="mp-btn mp-btn-primary"><?php echo esc_html($btn_text); ?></a>
                        <?php 
                        $pdf_url = get_option('machepizza_downloadable_menu_link', '');
                        $menu_link = !empty($pdf_url) ? $pdf_url : $shop_url;
                        $menu_target = !empty($pdf_url) ? 'target="_blank" rel="noopener"' : '';
                        ?>
                        <a href="<?php echo esc_url($menu_link); ?>" <?php echo $menu_target; ?> class="mp-btn mp-btn-outline">Scarica il menu</a>
                    </div>
                    
                    <div class="mp-hero-micro-badges">
                        <span class="mp-micro-badge">🛵 Ordina online</span>
                        <span class="mp-micro-badge">🔥 Pizza calda</span>
                        <span class="mp-micro-badge">🇮🇹 Gusto italiano</span>
                    </div>
                </div>

                <!-- DESTRA: Visual Shoppable -->
                <div class="mp-hero-right">
                    <div class="mp-hero-visual-wrapper">
                        <?php 
                        $hero_products = mp_get_hero_products(2); 
                        $has_hero_products = false;
                        if ($hero_products && $hero_products->have_posts()) {
                            $has_hero_products = true;
                            $count = 1;
                            while ($hero_products->have_posts()) {
                                $hero_products->the_post();
                                global $product;
                                
                                $img_url = has_post_thumbnail() ? get_the_post_thumbnail_url(get_the_ID(), 'medium') : 'https://images.unsplash.com/photo-1513104890138-7c749659a591?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80';
                                ?>
                                <?php $shop_url_qop = add_query_arg('mp_quick_order', $product->get_id(), wc_get_page_permalink('shop')); ?>
                                <div class="mp-preview-card card-<?php echo $count; ?>">
                                    <img src="<?php echo esc_url($img_url); ?>" class="mp-preview-img" alt="<?php echo esc_attr(get_the_title()); ?>">
                                    <h4><?php the_title(); ?></h4>
                                    <div class="mp-preview-price"><?php echo $product->get_price_html(); ?></div>
                                    <a href="<?php echo esc_url($shop_url_qop); ?>" class="mp-preview-btn">Ordina</a>
                                </div>
                                <?php
                                $count++;
                            }
                            wp_reset_postdata();
                        }
                        
                        if (!$has_hero_products) {
                            ?>
                            <div class="mp-preview-card card-1">
                                <img src="https://images.unsplash.com/photo-1513104890138-7c749659a591?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80" class="mp-preview-img" alt="Margherita">
                                <h4>Margherita Classica</h4>
                                <div class="mp-preview-price">CHF 15.00</div>
                                <a href="<?php echo esc_url($shop_url); ?>" class="mp-preview-btn">Ordina</a>
                            </div>
                            <div class="mp-preview-card card-2">
                                <img src="https://images.unsplash.com/photo-1590947132387-155cc02f3212?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80" class="mp-preview-img" alt="Diavola">
                                <h4>Diavola Piccante</h4>
                                <div class="mp-preview-price">CHF 18.00</div>
                                <a href="<?php echo esc_url($shop_url); ?>" class="mp-preview-btn">Ordina</a>
                            </div>
                            <?php
                        }
                        ?>
                    </div>
                </div>
            </div>
        </div>
        <div class="mp-hero-wave">
            <svg viewBox="0 0 1440 120" preserveAspectRatio="none">
                <path d="M0,32 C360,140 1080,-30 1440,60 L1440,120 L0,120 Z" class="shape-fill"></path>
            </svg>
        </div>
    </section>

    <!-- 2. I PIÙ SCELTI DEL MENU (Mix Pizze & Hamburger) -->
    <section class="mp-section mp-popular-pizzas">
        <div class="mp-container mp-reveal">
            <div class="mp-section-header mp-text-center">
                <h2 class="mp-section-title">I più scelti del menu</h2>
                <p class="mp-section-subtitle">Le preferite di chi ha già fame. Scegli, aggiungi al carrello e preparati al primo morso.</p>
            </div>
            
            <div class="mp-products-grid">
                <?php
                $popular_products = mp_get_popular_mixed_products(6);
                if ($popular_products && $popular_products->have_posts()) {
                    $count = 0;
                    while ($popular_products->have_posts()) {
                        $popular_products->the_post();
                        global $product;
                        $count++;
                        
                        $badge = '';
                        if ($count === 1) $badge = 'Più amato';
                        if ($count === 2) $badge = 'Consigliato';
                        
                        $btn_text = ($product->is_type('variable') || !$product->is_purchasable()) ? 'Scegli' : 'Ordina';
                        $add_to_cart_url = $product->is_type('variable') ? get_permalink() : '?add-to-cart=' . $product->get_id();
                        
                        // Determinare l'icona di fallback in base alla categoria del prodotto
                        $cats = wp_get_post_terms(get_the_ID(), 'product_cat', ['fields' => 'names']);
                        $cat_string = !empty($cats) ? implode(' ', $cats) : 'pizza';
                        $fallback_icon = mp_get_category_icon($cat_string);
                        ?>
                        <?php $shop_url_qop = add_query_arg('mp_quick_order', $product->get_id(), wc_get_page_permalink('shop')); ?>
                        <div class="mp-product-card">
                            <?php if($badge): ?>
                                <span class="mp-product-badge"><?php echo $badge; ?></span>
                            <?php endif; ?>
                            
                            <div class="mp-product-img-wrap">
                                <?php 
                                if (has_post_thumbnail()) {
                                    the_post_thumbnail('medium');
                                } else {
                                    echo '<div class="mp-product-fallback-icon">' . $fallback_icon . '</div>';
                                }
                                ?>
                            </div>
                            <div class="mp-product-info">
                                <h3><?php the_title(); ?></h3>
                                <div class="mp-product-desc"><?php echo wp_trim_words(get_the_excerpt(), 12); ?></div>
                                <div class="mp-product-bottom">
                                    <div class="mp-product-price"><?php echo $product->get_price_html(); ?></div>
                                    <a href="<?php echo esc_url($shop_url_qop); ?>" class="mp-btn mp-product-add"><?php echo $btn_text; ?></a>
                                </div>
                            </div>
                        </div>
                        <?php
                    }
                    wp_reset_postdata();
                } else {
                    echo "<p style='text-align:center;'>Nessun prodotto trovato. Aggiungi pizze o hamburger nello store.</p>";
                }
                ?>
            </div>
            
            <div class="mp-text-center" style="margin-top: 50px;">
                <a href="<?php echo esc_url($shop_url); ?>" class="mp-btn mp-btn-primary">Vedi tutto il menu</a>
            </div>
        </div>
    </section>

    <!-- 3. CATEGORIE (Menu Tiles intelligenti) -->
    <section class="mp-section mp-categories">
        <div class="mp-container mp-reveal">
            <div class="mp-section-header mp-text-center">
                <h2 class="mp-section-title">Cosa ti va oggi?</h2>
                <p class="mp-section-subtitle">Classica, speciale, dolce o una combo da condividere: scegli la categoria e vai dritto al gusto.</p>
            </div>
            
            <div class="mp-cat-grid">
                <?php 
                if ($has_woo && taxonomy_exists('product_cat')) {
                    $terms = get_terms([
                        'taxonomy' => 'product_cat',
                        'hide_empty' => true,
                    ]);
                    
                    if (!empty($terms) && !is_wp_error($terms)) {
                        $priority_slugs = ['pizze', 'pizze-classiche-normali', 'hamburger', 'burger', 'calzoni', 'bevande', 'dolci'];
                        $ordered_terms = [];
                        $other_terms = [];
                        
                        foreach ($terms as $term) {
                            if (in_array($term->slug, $priority_slugs)) {
                                $ordered_terms[] = $term;
                            } else {
                                $other_terms[] = $term;
                            }
                        }
                        
                        $final_terms = array_merge($ordered_terms, $other_terms);
                        $final_terms = array_slice($final_terms, 0, 6);
                        
                        foreach($final_terms as $cat) {
                            $shop_url = wc_get_page_permalink( 'shop' );
                            $link = trailingslashit($shop_url) . '#cat-' . $cat->slug;
                            $thumbnail_id = get_term_meta( $cat->term_id, 'thumbnail_id', true );
                            $image_url = $thumbnail_id ? wp_get_attachment_url( $thumbnail_id ) : false;
                            
                            $icon = mp_get_category_icon($cat->name);
                            ?>
                            <a href="<?php echo esc_url($link); ?>" class="mp-cat-card">
                                <?php if ($image_url): ?>
                                    <img src="<?php echo esc_url($image_url); ?>" alt="<?php echo esc_attr($cat->name); ?>" class="mp-cat-img">
                                <?php else: ?>
                                    <div class="mp-cat-icon"><?php echo $icon; ?></div>
                                <?php endif; ?>
                                
                                <div class="mp-cat-info">
                                    <h3 class="mp-cat-name"><?php echo esc_html($cat->name); ?></h3>
                                    <div class="mp-cat-desc"><?php echo $cat->count; ?> prodotti</div>
                                </div>
                                <div class="mp-cat-arrow">&rarr;</div>
                            </a>
                            <?php
                        }
                    }
                }
                ?>
            </div>
        </div>
    </section>

    <!-- 4. ORDINE VELOCE / MOOD SHOPPING -->
    <section class="mp-section mp-quick-combos">
        <div class="mp-container mp-reveal">
            <div class="mp-section-header">
                <h2 class="mp-section-title">Scegli il tuo mood</h2>
                <p class="mp-section-subtitle">Vai sul sicuro con le scelte più popolari per ogni occasione.</p>
            </div>
            
            <div class="mp-combo-grid">
                <a href="<?php echo esc_url($menu_link); ?>" <?php echo $menu_target; ?> class="mp-combo-card">
                    <img src="https://images.unsplash.com/photo-1544982503-9f984c14501a?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80" alt="Serata in famiglia" class="mp-combo-bg">
                    <div class="mp-combo-content">
                        <h3 class="mp-combo-title">Serata in famiglia</h3>
                        <p class="mp-combo-desc">Per condividere con chi ami la vera pizza artigianale.</p>
                        <div class="mp-combo-link-wrap">
                            <span class="mp-combo-link">Scarica il menu &rarr;</span>
                        </div>
                    </div>
                </a>
                
                <a href="<?php echo esc_url($shop_url); ?>" class="mp-combo-card">
                    <img src="https://images.unsplash.com/photo-1565299585323-38d6b0865b47?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80" alt="Solo per me" class="mp-combo-bg">
                    <div class="mp-combo-content">
                        <h3 class="mp-combo-title">Solo per me</h3>
                        <p class="mp-combo-desc">La tua preferita, pronta e caldissima.</p>
                        <div class="mp-combo-link-wrap">
                            <span class="mp-combo-link">Ordina ora &rarr;</span>
                        </div>
                    </div>
                </a>
                
                <a href="<?php echo esc_url(trailingslashit($shop_url)) . '#cat-menu'; ?>" class="mp-combo-card">
                    <img src="https://images.unsplash.com/photo-1528137871618-79d2761e3fd5?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80" alt="Da condividere" class="mp-combo-bg">
                    <div class="mp-combo-content">
                        <h3 class="mp-combo-title">Da condividere</h3>
                        <p class="mp-combo-desc">Combo e formati grandi per fare festa.</p>
                        <div class="mp-combo-link-wrap">
                            <span class="mp-combo-link">Guarda le combo &rarr;</span>
                        </div>
                    </div>
                </a>
            </div>
        </div>
    </section>

    <!-- 5. BRAND / ACCOGLIENZA -->
    <section class="mp-section mp-brand-story">
        <div class="mp-container mp-reveal">
            <div class="mp-brand-grid">
                <div class="mp-brand-text">
                    <h2>Non è solo pizza.<br>È quella voglia lì.</h2>
                    <p>Quella voglia di aprire il cartone, sentire il profumo, scegliere la fetta più filante e condividere il primo morso. Mache Pizza nasce per portare a casa tua una pizza semplice, buona, calda e piena di carattere.</p>
                    
                    <div class="mp-brand-benefits">
                        <div class="mp-benefit-item"><span class="mp-benefit-icon">🌾</span> Impasto fragrante</div>
                        <div class="mp-benefit-item"><span class="mp-benefit-icon">🍅</span> Ingredienti scelti</div>
                        <div class="mp-benefit-item"><span class="mp-benefit-icon">📱</span> Ordine online facile</div>
                        <div class="mp-benefit-item"><span class="mp-benefit-icon">🇮🇹</span> Gusto vero italiano</div>
                    </div>
                </div>
                
                <div class="mp-brand-visual">
                    <img src="https://images.unsplash.com/photo-1590947132387-155cc02f3212?ixlib=rb-1.2.1&auto=format&fit=crop&w=1000&q=80" alt="Mache Pizza Forno">
                    <div class="mp-brand-badge">Dal forno a casa tua</div>
                </div>
            </div>
        </div>
    </section>

    <!-- 6. COME FUNZIONA -->
    <section class="mp-section mp-how-it-works">
        <div class="mp-container mp-reveal">
            <div class="mp-section-header mp-text-center">
                <h2 class="mp-section-title">Ordini in pochi clic</h2>
                <p class="mp-section-subtitle">Scegli. Ordina. Gusta.</p>
            </div>
            
            <div class="mp-steps-grid">
                <div class="mp-step">
                    <div class="mp-step-number">1</div>
                    <div class="mp-step-text">
                        <h3>Scegli</h3>
                        <p>Guarda le pizze e trova quella che ti chiama dal menu.</p>
                    </div>
                </div>
                <div class="mp-step">
                    <div class="mp-step-number">2</div>
                    <div class="mp-step-text">
                        <h3>Ordina</h3>
                        <p>Aggiungi al carrello e completa l'ordine online comodamente.</p>
                    </div>
                </div>
                <div class="mp-step">
                    <div class="mp-step-number">3</div>
                    <div class="mp-step-text">
                        <h3>Gusta</h3>
                        <p>La tua pizza calda arriva pronta da condividere.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- 7. CTA FINALE -->
    <section class="mp-section mp-final-cta">
        <div class="mp-container mp-reveal">
            <h2>Stasera pizza?</h2>
            <p>La risposta giusta è sempre sì. Scegli la tua preferita e porta a casa il gusto caldo di Mache Pizza.</p>
            
            <div class="mp-final-buttons">
                <a href="<?php echo esc_url($shop_url); ?>" class="mp-btn mp-btn-primary">Ordina ora</a>
                <a href="<?php echo esc_url($shop_url); ?>" class="mp-btn mp-btn-outline">Guarda il menu</a>
            </div>
        </div>
    </section>

</div>

<?php get_footer(); ?>
