<?php
/**
 * Template Name: Contatti
 * 
 * Mache Pizza - Pagina "Contatti" Dinamica
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

get_header(); 

// ---------------------------------------------------------
// 1. FETCH DYNAMIC DATA FROM CMS
// ---------------------------------------------------------
$contact_info = function_exists('ticinoweb_get_contact_info') ? ticinoweb_get_contact_info() : array();

// Basic Info
$phone   = !empty($contact_info['phone']) ? $contact_info['phone'] : '';
$mobile  = !empty($contact_info['phone_mobile']) ? $contact_info['phone_mobile'] : '';
$email   = !empty($contact_info['email']) ? $contact_info['email'] : '';
$address = !empty($contact_info['address']) ? $contact_info['address'] : '';

// Hero text
$hero_title    = get_option('ticinoweb_contact_title', 'Siamo qui, quando hai voglia di pizza');
$hero_subtitle = get_option('ticinoweb_contact_text', 'Hai domande, vuoi ordinare o passare a trovarci? Qui trovi tutti i contatti di Mache Pizza, sempre aggiornati.');

// Links
$shop_link = function_exists('wc_get_page_permalink') ? wc_get_page_permalink('shop') : '/shop';

// PDF menu logic (come in home)
$pdf_url = get_option('machepizza_downloadable_menu_link', '');
$menu_link = !empty($pdf_url) ? $pdf_url : $shop_link;
$menu_target = !empty($pdf_url) ? 'target="_blank" rel="noopener"' : '';
$wa_link   = '';
if ($mobile) {
    // Format mobile for WhatsApp link (remove spaces, pluses)
    $clean_wa = preg_replace('/[^0-9]/', '', $mobile);
    $wa_link  = 'https://wa.me/' . $clean_wa;
}
$maps_link = get_option('ticinoweb_contact_map_link');
$maps_embed = get_option('ticinoweb_contact_map_embed'); // Sometimes stored here, if not, we use link

// Socials
$socials = array(
    'instagram' => !empty($contact_info['instagram']) ? $contact_info['instagram'] : '',
    'facebook'  => !empty($contact_info['facebook']) ? $contact_info['facebook'] : '',
    'tiktok'    => !empty($contact_info['tiktok']) ? $contact_info['tiktok'] : '',
);
$has_socials = array_filter($socials);

// Opening Hours
$hours = function_exists('machepizza_get_opening_hours') ? machepizza_get_opening_hours() : array();
$hours_note = !empty($contact_info['opening_hours_note']) ? $contact_info['opening_hours_note'] : '';

?>

<div class="mp-contatti-page">

    <!-- 1. HERO CONTATTI COMPATTA -->
    <section class="mp-contact-hero mp-section" style="position: relative;">
        <div class="mp-contact-hero-bg"></div>
        
        <!-- Decorazioni Fluttuanti Contatti -->
        <div class="mp-floating-decorations">
            <div class="mp-deco-item mp-deco-2" style="font-size: 2.5rem;">📞</div>
            <div class="mp-deco-item mp-deco-4" style="font-size: 3rem;">🛵</div>
            <div class="mp-deco-item mp-deco-6">🍕</div>
            <div class="mp-deco-item mp-deco-7">📍</div>
        </div>

        <div class="mp-container mp-contact-hero-container">
            <div class="mp-contact-hero-content mp-reveal">
                <span class="mp-cs-tag" style="background: var(--mp-yellow); color: var(--mp-charcoal);">Contattaci</span>
                <h1 class="mp-contact-hero-title"><?php echo wp_kses_post($hero_title); ?></h1>
                <p class="mp-contact-hero-subtitle"><?php echo wp_kses_post($hero_subtitle); ?></p>
                <div class="mp-contact-hero-actions">
                    <?php if ($phone) : ?>
                        <a href="tel:<?php echo esc_attr(str_replace(' ', '', $phone)); ?>" class="mp-btn mp-cs-cta-btn">Chiama ora</a>
                    <?php elseif ($mobile) : ?>
                        <a href="tel:<?php echo esc_attr(str_replace(' ', '', $mobile)); ?>" class="mp-btn mp-cs-cta-btn">Chiama ora</a>
                    <?php endif; ?>
                    <a href="<?php echo esc_url($menu_link); ?>" <?php echo $menu_target; ?> class="mp-btn mp-cs-outline-white">Scarica il menu</a>
                </div>
            </div>
            
        </div>
        
        <!-- Bottom Wave -->
        <div class="mp-hero-wave">
            <svg viewBox="0 0 1440 120" preserveAspectRatio="none">
                <path d="M0,32 C360,140 1080,-30 1440,60 L1440,120 L0,120 Z" class="shape-fill" style="fill: var(--mp-cream);"></path>
            </svg>
        </div>
    </section>

    <!-- 2. CARD CONTATTI RAPIDI -->
    <section class="mp-contact-cards-section mp-section" style="padding-top: 0;">
        <div class="mp-container">
            <div class="mp-contact-cards-grid">
                
                <?php if ($phone) : ?>
                <div class="mp-contact-card mp-reveal">
                    <div class="mp-contact-card-icon">📞</div>
                    <h3>Telefono</h3>
                    <p class="mp-contact-card-value"><?php echo esc_html($phone); ?></p>
                    <a href="tel:<?php echo esc_attr(str_replace(' ', '', $phone)); ?>" class="mp-contact-link-btn">Chiama ora</a>
                </div>
                <?php endif; ?>

                <?php if ($mobile) : ?>
                <div class="mp-contact-card mp-reveal" style="transition-delay: 0.1s;">
                    <div class="mp-contact-card-icon" style="color: #25D366;">💬</div>
                    <h3>WhatsApp</h3>
                    <p class="mp-contact-card-value"><?php echo esc_html($mobile); ?></p>
                    <a href="<?php echo esc_url($wa_link); ?>" target="_blank" rel="noopener" class="mp-contact-link-btn">Scrivici su WhatsApp</a>
                </div>
                <?php endif; ?>

                <?php if ($email) : ?>
                <div class="mp-contact-card mp-reveal" style="transition-delay: 0.2s;">
                    <div class="mp-contact-card-icon">✉️</div>
                    <h3>Email</h3>
                    <p class="mp-contact-card-value"><?php echo esc_html($email); ?></p>
                    <a href="mailto:<?php echo esc_attr($email); ?>" class="mp-contact-link-btn">Scrivi email</a>
                </div>
                <?php endif; ?>

                <?php if ($address) : ?>
                <div class="mp-contact-card mp-reveal" style="transition-delay: 0.3s;">
                    <div class="mp-contact-card-icon">📍</div>
                    <h3>Indirizzo</h3>
                    <p class="mp-contact-card-value"><?php echo esc_html($address); ?></p>
                    <?php if ($maps_link) : ?>
                        <a href="<?php echo esc_url($maps_link); ?>" target="_blank" rel="noopener" class="mp-contact-link-btn">Apri indicazioni</a>
                    <?php endif; ?>
                </div>
                <?php endif; ?>

            </div>
        </div>
    </section>

    <!-- 3. SEZIONE MAPPA E 4. SEZIONE ORARI -->
    <section class="mp-contact-map-hours mp-section">
        <div class="mp-container">
            <div class="mp-contact-split">
                
                <!-- Colonna Sinistra: Orari -->
                <div class="mp-contact-hours-wrap mp-reveal">
                    <div class="mp-contact-hours-card">
                        <div class="mp-contact-hours-header">
                            <span class="mp-contact-hours-icon">🕒</span>
                            <h2 class="mp-contact-hours-title">Orari di apertura</h2>
                        </div>
                        <p class="mp-contact-hours-subtitle">Controlla quando siamo aperti e scegli il momento giusto per ordinare.</p>
                        
                        <?php if ( !empty($hours) ) : 
                            $current_day = strtolower(wp_date('l'));
                            $day_map = array(
                                'monday'    => 'lunedì',
                                'tuesday'   => 'martedì',
                                'wednesday' => 'mercoledì',
                                'thursday'  => 'giovedì',
                                'friday'    => 'venerdì',
                                'saturday'  => 'sabato',
                                'sunday'    => 'domenica',
                            );
                            $ita_current = isset($day_map[$current_day]) ? $day_map[$current_day] : '';
                        ?>
                            <ul class="mp-contact-hours-list">
                                <?php foreach ($hours as $hour) : 
                                    if (empty($hour['day'])) continue;
                                    $day_lower = strtolower(trim($hour['day']));
                                    $is_today = (strpos($day_lower, $ita_current) !== false);
                                    $is_closed = (strpos(strtolower($hour['hours']), 'chius') !== false);
                                ?>
                                    <li class="mp-contact-hours-item <?php echo $is_today ? 'mp-today' : ''; ?>">
                                        <span class="mp-day"><?php echo esc_html($hour['day']); ?></span>
                                        <span class="mp-time <?php echo $is_closed ? 'mp-closed-text' : ''; ?>">
                                            <?php echo esc_html($hour['hours']); ?>
                                        </span>
                                    </li>
                                <?php endforeach; ?>
                            </ul>
                            <?php if ($hours_note) : ?>
                                <p class="mp-contact-hours-note"><?php echo esc_html($hours_note); ?></p>
                            <?php endif; ?>
                        <?php else : ?>
                            <p class="mp-contact-hours-empty">Contattaci per conoscere gli orari aggiornati.</p>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Colonna Destra: Mappa -->
                <?php if ($address || $maps_embed) : ?>
                <div class="mp-contact-map-wrap mp-reveal" style="transition-delay: 0.2s;">
                    <div class="mp-contact-map-card">
                        <div class="mp-contact-map-header">
                            <span class="mp-contact-map-icon">📍</span>
                            <h2 class="mp-contact-map-title">Dove trovarci</h2>
                        </div>
                        <p class="mp-contact-map-subtitle">Passa da Mache Pizza o raggiungici facilmente con le indicazioni stradali.</p>
                        
                        <div class="mp-contact-map-canvas">
                            <?php if ($maps_embed) : ?>
                                <?php echo $maps_embed; // Pre-sanitized from CMS or needs to be iframe ?>
                            <?php elseif ($address) : ?>
                                <!-- Mappa generata dinamicamente dall'indirizzo -->
                                <iframe width="100%" height="100%" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.com/maps?q=<?php echo urlencode($address); ?>&t=m&z=15&output=embed&iwloc=near" style="min-height: 400px; border: 0; border-radius: var(--mp-radius); width: 100%;"></iframe>
                            <?php else : ?>
                                <!-- Fallback map visual if no embed and no address -->
                                <div class="mp-contact-map-placeholder">
                                    <div class="mp-contact-map-placeholder-inner">
                                        <div class="mp-contact-map-pin">🍕</div>
                                        <p>Indirizzo non inserito.</p>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <?php endif; ?>

            </div>
        </div>
    </section>

    <!-- 5. SEZIONE ORDINA / ASPORTO / CONSEGNA -->
    <section class="mp-contact-order-info mp-section" style="background: var(--mp-cream);">
        <div class="mp-container">
            <div class="mp-contact-order-banner mp-reveal">
                <div class="mp-contact-order-content">
                    <h2>Vuoi ordinare?</h2>
                    <p>Scegli le tue pizze preferite dal menu online e completa l'ordine in pochi clic. Per asporto o consegna, il sapore di casa arriva caldo.</p>
                    <div class="mp-contact-order-actions">
                        <a href="<?php echo esc_url($shop_link); ?>" class="mp-btn mp-cs-dark-btn">Ordina ora</a>
                        <?php if ($phone) : ?>
                            <a href="tel:<?php echo esc_attr(str_replace(' ', '', $phone)); ?>" class="mp-btn mp-cs-outline-dark">Chiama per informazioni</a>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="mp-contact-order-visual">
                    <div class="mp-orbit-item" style="font-size: 4rem; position: static; animation: none; transform: rotate(15deg);">🛵</div>
                </div>
            </div>
        </div>
    </section>

    <!-- 6. SEZIONE SOCIAL -->
    <?php if ($has_socials) : ?>
    <section class="mp-contact-social-section mp-section">
        <div class="mp-container mp-text-center mp-reveal">
            <h2 class="mp-section-title">Seguici anche qui</h2>
            <p class="mp-section-subtitle">Resta aggiornato sulle novità, le pizze del momento e le serate Mache Pizza.</p>
            
            <div class="mp-contact-social-pills">
                <?php if ($socials['instagram']) : ?>
                    <a href="<?php echo esc_url($socials['instagram']); ?>" target="_blank" rel="noopener" class="mp-social-pill instagram">
                        <span class="mp-social-icon">📸</span>
                        <span>Instagram</span>
                    </a>
                <?php endif; ?>
                
                <?php if ($socials['facebook']) : ?>
                    <a href="<?php echo esc_url($socials['facebook']); ?>" target="_blank" rel="noopener" class="mp-social-pill facebook">
                        <span class="mp-social-icon">👍</span>
                        <span>Facebook</span>
                    </a>
                <?php endif; ?>

                <?php if ($socials['tiktok']) : ?>
                    <a href="<?php echo esc_url($socials['tiktok']); ?>" target="_blank" rel="noopener" class="mp-social-pill tiktok">
                        <span class="mp-social-icon">🎵</span>
                        <span>TikTok</span>
                    </a>
                <?php endif; ?>
            </div>
        </div>
    </section>
    <?php endif; ?>

    <!-- 7. CTA FINALE -->
    <section class="mp-cs-cta-section mp-section">
        <div class="mp-container mp-text-center mp-reveal">
            <h2 class="mp-section-title" style="color: var(--mp-yellow);">Stasera pizza?</h2>
            <p style="color: #fff; font-size: 1.2rem; margin-bottom: 30px; max-width: 600px; margin-left: auto; margin-right: auto;">
                Scopri il menu Mache Pizza e scegli cosa portare in tavola oggi.
            </p>
            <div class="mp-contact-final-cta">
                <a href="<?php echo esc_url($menu_link); ?>" <?php echo $menu_target; ?> class="mp-btn mp-cs-cta-btn">Scarica il menu</a>
                <?php if ($phone) : ?>
                    <a href="tel:<?php echo esc_attr(str_replace(' ', '', $phone)); ?>" class="mp-btn mp-cs-outline-white">Chiama ora</a>
                <?php endif; ?>
            </div>
        </div>
    </section>

</div>

<?php get_footer(); ?>
