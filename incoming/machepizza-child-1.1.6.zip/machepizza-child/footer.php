<?php
/**
 * Mache Pizza – Footer
 * Contact info and opening hours from CMS
 */
$contact = ticinoweb_get_contact_info();
$hours   = machepizza_get_opening_hours();
$logo    = ticinoweb_get_site_logo();
?>

<footer class="mp-footer" id="contatti">
    <div class="mp-footer-inner">

        <!-- Column 1: Brand -->
        <div class="mp-footer-col mp-footer-brand">
            <?php if ( $logo ) : ?>
                <img src="<?php echo esc_url( $logo ); ?>" alt="<?php bloginfo( 'name' ); ?>" class="mp-footer-logo">
            <?php endif; ?>
            <p class="mp-footer-desc">La tua pizza artigianale, consegnata calda a domicilio a Montagnola e dintorni.</p>
            <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="mp-btn mp-btn-primary mp-footer-cta">
                🍕 Ordina Ora
            </a>
            <?php if ( file_exists( get_stylesheet_directory() . '/assets/img/alcolici-minori.jpg' ) ) : ?>
                <img src="<?php echo esc_url( get_stylesheet_directory_uri() . '/assets/img/alcolici-minori.jpg' ); ?>" alt="Divieto alcolici minori" loading="lazy" style="max-width: 180px; display: block; margin: -5px 0 20px 0; border-radius: 6px;">
            <?php endif; ?>
            <div class="mp-footer-social">
                <?php if ( ! empty( $contact['instagram'] ) ) : ?>
                <a href="<?php echo esc_url( $contact['instagram'] ); ?>" target="_blank" rel="noopener" aria-label="Instagram">
                    <svg width="22" height="22" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zM12 0C8.741 0 8.333.014 7.053.072 2.695.272.273 2.69.073 7.052.014 8.333 0 8.741 0 12c0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98C8.333 23.986 8.741 24 12 24c3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98C15.668.014 15.259 0 12 0zm0 5.838a6.162 6.162 0 100 12.324 6.162 6.162 0 000-12.324zM12 16a4 4 0 110-8 4 4 0 010 8zm6.406-11.845a1.44 1.44 0 100 2.881 1.44 1.44 0 000-2.881z"/></svg>
                </a>
                <?php endif; ?>
                <?php if ( ! empty( $contact['facebook'] ) ) : ?>
                <a href="<?php echo esc_url( $contact['facebook'] ); ?>" target="_blank" rel="noopener" aria-label="Facebook">
                    <svg width="22" height="22" viewBox="0 0 24 24" fill="currentColor"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>
                </a>
                <?php endif; ?>
            </div>
        </div>

        <!-- Column 2: Orari -->
        <div class="mp-footer-col mp-footer-hours">
            <h3 class="mp-footer-title">🕐 Orari di Apertura</h3>
            <ul class="mp-hours-list">
                <?php foreach ( $hours as $entry ) : ?>
                <li class="<?php echo $entry['hours'] === 'Chiuso' ? 'mp-closed' : ''; ?>">
                    <span class="mp-day"><?php echo esc_html( $entry['day'] ); ?></span>
                    <span class="mp-time"><?php echo esc_html( $entry['hours'] ); ?></span>
                </li>
                <?php endforeach; ?>
            </ul>
        </div>

        <!-- Column 3: Contatti -->
        <div class="mp-footer-col mp-footer-contact">
            <h3 class="mp-footer-title">📍 Contatti</h3>
            <ul class="mp-contact-list">
                <?php if ( ! empty( $contact['address'] ) ) : ?>
                <li>
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>
                    <span><?php echo esc_html( $contact['address'] ); ?></span>
                </li>
                <?php endif; ?>
                <?php if ( ! empty( $contact['phone'] ) ) : ?>
                <li>
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.127.96.361 1.903.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0 1 22 16.92z"/></svg>
                    <a href="tel:<?php echo esc_attr( str_replace( ' ', '', $contact['phone'] ) ); ?>"><?php echo esc_html( $contact['phone'] ); ?></a>
                </li>
                <?php endif; ?>
                <?php if ( ! empty( $contact['email'] ) ) : ?>
                <li>
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>
                    <a href="mailto:<?php echo esc_attr( $contact['email'] ); ?>"><?php echo esc_html( $contact['email'] ); ?></a>
                </li>
                <?php endif; ?>
                <?php if ( ! empty( $contact['phone'] ) ) : ?>
                <li>
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347z"/><path d="M12 0C5.373 0 0 5.373 0 12c0 2.127.556 4.122 1.527 5.855L.064 23.483a.5.5 0 00.615.61l5.723-1.436A11.95 11.95 0 0012 24c6.627 0 12-5.373 12-12S18.627 0 12 0zm0 21.818c-1.937 0-3.74-.562-5.267-1.527l-.377-.224-3.388.85.875-3.333-.248-.393A9.774 9.774 0 012.182 12c0-5.415 4.403-9.818 9.818-9.818S21.818 6.585 21.818 12 17.415 21.818 12 21.818z"/></svg>
                    <a href="https://api.whatsapp.com/send/?phone=<?php echo esc_attr( preg_replace( '/[^0-9]/', '', $contact['phone'] ) ); ?>" target="_blank" rel="noopener">WhatsApp</a>
                </li>
                <?php endif; ?>
            </ul>
        </div>

        <!-- Column 4: Link Rapidi -->
        <div class="mp-footer-col mp-footer-links">
            <h3 class="mp-footer-title">🔗 Link Rapidi</h3>
            <ul class="mp-quick-links">
                <li><a href="<?php echo esc_url( home_url( '/' ) ); ?>">Home</a></li>
                <li><a href="<?php echo esc_url( home_url( '/chi-siamo/' ) ); ?>">Chi Siamo</a></li>
                <li><a href="<?php echo esc_url( home_url( '/' ) ); ?>">Menu</a></li>
                <li><a href="<?php echo esc_url( home_url( '/allergeni/' ) ); ?>">Allergeni</a></li>
                <li><a href="#contatti">Contatti</a></li>
            </ul>
        </div>

    </div>

    <!-- Bottom Bar -->
    <div class="mp-footer-bottom">
        <div class="mp-footer-legal">
            <a href="<?php echo esc_url( home_url( '/condizioni-generali-di-vendita/' ) ); ?>">Condizioni Generali di Vendita</a>
            <span class="mp-separator">|</span>
            <a href="<?php echo esc_url( home_url( '/privacy-policy/' ) ); ?>">Privacy Policy</a>
            <span class="mp-separator">|</span>
            <a href="<?php echo esc_url( home_url( '/impressum/' ) ); ?>">Impressum</a>
        </div>
        <div class="mp-footer-copy">
            <span>© <?php echo date( 'Y' ); ?> <?php bloginfo( 'name' ); ?>. Tutti i diritti riservati.</span>
            <span class="mp-footer-credit">Design by <a href="https://ticinoweb.com" target="_blank" rel="noopener">ticinoWEB</a></span>
        </div>
    </div>
</footer>

<?php
// ─── App Download Feature ───
$app_enabled = get_option('machepizza_app_enabled', 1);
if ( $app_enabled ) :
    $app_ios_link = get_option('machepizza_app_ios_link', '');
    $app_android_link = get_option('machepizza_app_android_link', '');
    $badge_txt = get_option('machepizza_app_badge_text', 'Scarica l\'App');
    $pnl_title = get_option('machepizza_app_popup_title', 'Scarica l\'app Mache Pizza');
    $pnl_desc  = get_option('machepizza_app_popup_desc', "Ordina più velocemente e tieni d'occhio il tuo ordine. La tua pizza preferita sempre a portata di mano.");
?>
<!-- Floating App Badge -->
<div class="mp-app-badge" id="mp-app-badge" role="button" aria-label="<?php echo esc_attr($badge_txt); ?>" tabindex="0">
    <div class="mp-app-badge-inner">
        <div class="mp-app-badge-icon">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="5" y="2" width="14" height="20" rx="2" ry="2"></rect><line x1="12" y1="18" x2="12.01" y2="18"></line></svg>
        </div>
        <span class="mp-app-badge-text"><?php echo esc_html($badge_txt); ?></span>
    </div>
</div>

<!-- App Side Panel -->
<div class="mp-app-panel-overlay" id="mp-app-panel-overlay"></div>
<aside class="mp-app-panel" id="mp-app-panel">
    <div class="mp-app-panel-header">
        <h3 class="mp-app-panel-title">Mache Pizza App</h3>
        <button class="mp-app-panel-close" id="mp-app-panel-close" aria-label="Chiudi">&times;</button>
    </div>
    <div class="mp-app-panel-body">
        <div class="mp-app-panel-illustration">
            <div class="mp-app-mockup">
                <div class="mp-app-mockup-screen">
                    <img src="<?php echo get_stylesheet_directory_uri(); ?>/assets/img/schermata%20app.png" alt="Mache Pizza App" class="mp-app-screen-img">
                </div>
            </div>
        </div>
        
        <h2 class="mp-app-panel-heading"><?php echo esc_html($pnl_title); ?></h2>
        <p class="mp-app-panel-desc"><?php echo nl2br(esc_html($pnl_desc)); ?></p>
        
        <ul class="mp-app-panel-benefits">
            <li>
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"></polyline></svg>
                Ordina in pochi tap
            </li>
            <li>
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"></polyline></svg>
                Salva i tuoi preferiti
            </li>
            <li>
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"></polyline></svg>
                Esperienza super veloce
            </li>
        </ul>
        
        <div class="mp-app-panel-action">
            <?php if ( ! empty( $app_ios_link ) ) : ?>
                <a href="<?php echo esc_url($app_ios_link); ?>" target="_blank" rel="noopener" class="mp-app-store-btn mp-app-store-apple">
                    <svg viewBox="0 0 384 512" width="24" height="24" fill="currentColor"><path d="M318.7 268.7c-.2-36.7 16.4-64.4 50-84.8-18.8-26.9-47.2-41.7-84.7-44.6-35.5-2.8-74.3 20.7-88.5 20.7-15 0-49.4-19.7-76.4-19.7C63.3 141.2 4 184.8 4 273.5q0 39.3 14.4 81.2c12.8 36.7 59 126.7 107.2 125.2 25.2-.6 43-17.9 75.8-17.9 31.8 0 48.3 17.9 76.4 17.9 48.6-.7 90.4-82.5 102.6-119.3-65.2-30.7-61.7-90-61.7-91.9zm-56.6-164.2c27.3-32.4 24.8-61.9 24-72.5-24.1 1.4-52 16.4-67.9 34.9-17.5 19.8-27.8 44.3-25.6 71.9 26.1 2 49.9-11.4 69.5-34.3z"/></svg>
                    <div class="mp-app-store-text">
                        <span class="mp-app-store-small">Download on the</span>
                        <span class="mp-app-store-big">App Store</span>
                    </div>
                </a>
            <?php else : ?>
                <div class="mp-app-store-btn mp-app-btn-disabled">
                    <div class="mp-app-store-text">
                        <span class="mp-app-store-small">App Store</span>
                        <span class="mp-app-store-big">Disponibile a breve</span>
                    </div>
                </div>
            <?php endif; ?>

            <?php if ( ! empty( $app_android_link ) ) : ?>
                <a href="<?php echo esc_url($app_android_link); ?>" target="_blank" rel="noopener" class="mp-app-store-btn mp-app-store-google">
                    <svg viewBox="0 0 512 512" width="24" height="24" fill="currentColor"><path d="M325.3 234.3L104.6 13l280.8 161.2-60.1 60.1zM47 0C34 6.8 25.3 19.2 25.3 35.3v441.3c0 16.1 8.7 28.5 21.7 35.3l256.6-256L47 0zm425.2 225.6l-58.9-34.1-65.7 64.5 65.7 64.5 60.1-34.1c18-14.3 18-46.5-1.2-60.8zM104.6 499l280.8-161.2-60.1-60.1L104.6 499z"/></svg>
                    <div class="mp-app-store-text">
                        <span class="mp-app-store-small">GET IT ON</span>
                        <span class="mp-app-store-big">Google Play</span>
                    </div>
                </a>
            <?php else : ?>
                <div class="mp-app-store-btn mp-app-btn-disabled">
                    <div class="mp-app-store-text">
                        <span class="mp-app-store-small">Google Play</span>
                        <span class="mp-app-store-big">Disponibile a breve</span>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</aside>
<?php endif; ?>

<!-- Sticky header + hamburger JS -->
<script>
(function() {
    const header = document.getElementById('mp-header');
    const hamburger = document.getElementById('mp-hamburger');
    const nav = document.getElementById('mp-nav');

    // Sticky header on scroll
    let lastScroll = 0;
    window.addEventListener('scroll', function() {
        const scrollY = window.scrollY;
        if (scrollY > 80) {
            header.classList.add('mp-header-scrolled');
        } else {
            header.classList.remove('mp-header-scrolled');
        }
        lastScroll = scrollY;
    });

    // Hamburger toggle
    if (hamburger && nav) {
        hamburger.addEventListener('click', function() {
            hamburger.classList.toggle('active');
            nav.classList.toggle('mp-nav-open');
            document.body.classList.toggle('mp-nav-active');
        });

        // Close on link click
        nav.querySelectorAll('a').forEach(function(link) {
            link.addEventListener('click', function() {
                hamburger.classList.remove('active');
                nav.classList.remove('mp-nav-open');
                document.body.classList.remove('mp-nav-active');
            });
        });
    }

    // App Panel Logic
    const appBadge = document.getElementById('mp-app-badge');
    const appPanel = document.getElementById('mp-app-panel');
    const appOverlay = document.getElementById('mp-app-panel-overlay');
    const appClose = document.getElementById('mp-app-panel-close');

    if (appBadge && appPanel && appOverlay) {
        let previousFocus = null;

        function openAppPanel() {
            previousFocus = document.activeElement;
            appPanel.classList.add('is-open');
            appOverlay.classList.add('is-active');
            document.body.style.overflow = 'hidden'; // Prevent background scrolling
            
            // Set focus to the panel close button after opening for accessibility
            setTimeout(() => {
                appClose.focus();
            }, 100);
        }

        function closeAppPanel() {
            appPanel.classList.remove('is-open');
            appOverlay.classList.remove('is-active');
            document.body.style.overflow = '';
            
            if (previousFocus) {
                previousFocus.focus();
            }
        }

        appBadge.addEventListener('click', openAppPanel);
        
        // Accessibility: allow pressing Enter/Space on the badge to open
        appBadge.addEventListener('keydown', function(e) {
            if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                openAppPanel();
            }
        });

        appClose.addEventListener('click', closeAppPanel);
        appOverlay.addEventListener('click', closeAppPanel);

        // Accessibility: close on ESC key
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape' && appPanel.classList.contains('is-open')) {
                closeAppPanel();
            }
        });

        // Auto-open if query parameter show-app or hash is present
        const urlParams = new URLSearchParams(window.location.search);
        if (urlParams.has('show-app') || window.location.hash === '#show-app') {
            openAppPanel();
        }
    }
})();
</script>

<?php wp_footer(); ?>
</body>
</html>
