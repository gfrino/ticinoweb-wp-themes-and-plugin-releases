<?php
/**
 * Mache Pizza - Custom Shop Page (Digital Menu / Product Table)
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

get_header();

// Get all non-empty product categories
$args = array(
    'taxonomy'   => 'product_cat',
    'hide_empty' => true,
    'orderby'    => 'menu_order',
    'order'      => 'ASC',
);
$product_categories = get_terms( $args );

// Fallback icon helper if not defined elsewhere
if(!function_exists('mp_get_category_icon')) {
    function mp_get_category_icon($slug) {
        if(strpos($slug, 'pizza') !== false && strpos($slug, 'bianch') === false) return '🍕';
        if(strpos($slug, 'bianch') !== false) return '🧀';
        if(strpos($slug, 'calzon') !== false) return '🥟';
        if(strpos($slug, 'burger') !== false || strpos($slug, 'hamburger') !== false) return '🍔';
        if(strpos($slug, 'kebab') !== false) return '🌯';
        if(strpos($slug, 'dolc') !== false) return '🍰';
        if(strpos($slug, 'bevand') !== false || strpos($slug, 'bibit') !== false) return '🥤';
        if(strpos($slug, 'menu') !== false || strpos($slug, 'combo') !== false) return '🛍️';
        return '🍕';
    }
}
?>

<div class="mp-shop-wrapper">
    
    <!-- 1. Hero Intro Compatta -->
    <section class="mp-shop-hero" style="position: relative;">
        
        <!-- Decorazioni Fluttuanti Shop -->
        <div class="mp-floating-decorations">
            <div class="mp-deco-item mp-deco-1" style="font-size: 2.2rem; filter: blur(1px);">🌿</div>
            <div class="mp-deco-item mp-deco-3" style="font-size: 2.8rem; opacity: 0.4;">🍕</div>
            <div class="mp-deco-item mp-deco-5" style="font-size: 2rem;">🧀</div>
            <div class="mp-deco-item mp-deco-8" style="font-size: 3rem; opacity: 0.3;">🍅</div>
        </div>

        <div class="mp-container">
            <div class="mp-shop-hero-inner">
                <div class="mp-shop-hero-text">
                    <span class="mp-shop-hero-badge">🛵 Ordina Online</span>
                    <h1 class="mp-shop-title">Menu Mache Pizza</h1>
                    <p class="mp-shop-subtitle">Scegli le tue pizze preferite, aggiungile al carrello e preparati a gustarle calde.</p>
                </div>
                <div class="mp-shop-hero-search">
                    <div class="mp-search-wrapper">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>
                        <input type="text" id="mp-instant-search" placeholder="Cerca una pizza, una bibita o un dolce..." aria-label="Cerca">
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- 2. Barra Categorie Sticky -->
    <div class="mp-shop-categories-sticky" id="mp-shop-categories">
        <div class="mp-container">
            <div class="mp-cat-nav-wrapper">
                <nav class="mp-cat-nav" id="mp-cat-nav-scroll">
                    <?php foreach ($product_categories as $cat) : ?>
                        <a href="#cat-<?php echo esc_attr($cat->slug); ?>" class="mp-shop-cat-pill">
                            <span class="mp-shop-cat-pill-icon">
                                <?php 
                                $thumbnail_id = get_term_meta( $cat->term_id, 'thumbnail_id', true );
                                $image_url = $thumbnail_id ? wp_get_attachment_url( $thumbnail_id ) : false;
                                if ($image_url): ?>
                                    <img src="<?php echo esc_url($image_url); ?>" alt="<?php echo esc_attr($cat->name); ?>" class="mp-shop-cat-img">
                                <?php else: ?>
                                    <span class="mp-shop-cat-emoji"><?php echo mp_get_category_icon($cat->slug); ?></span>
                                <?php endif; ?>
                            </span>
                            <span class="mp-shop-cat-pill-text"><?php echo esc_html($cat->name); ?></span>
                        </a>
                    <?php endforeach; ?>
                </nav>
            </div>
        </div>
    </div>

    <!-- 3. Lista Prodotti (Menu) -->
    <section class="mp-shop-menu-section">
        <div class="mp-container mp-shop-layout">
            
            <div class="mp-shop-main">
                
                <?php foreach ($product_categories as $cat) : ?>
                    <div id="cat-<?php echo esc_attr($cat->slug); ?>" class="mp-menu-category-block">
                        
                        <div class="mp-menu-category-header">
                            <h2 class="mp-menu-cat-title"><?php echo esc_html($cat->name); ?></h2>
                            <?php if(!empty($cat->description)): ?>
                                <p class="mp-menu-cat-desc"><?php echo esc_html($cat->description); ?></p>
                            <?php endif; ?>
                        </div>

                        <div class="mp-menu-products-list">
                            <?php
                            $args = array(
                                'post_type'      => 'product',
                                'posts_per_page' => -1,
                                'product_cat'    => $cat->slug,
                                'post_status'    => 'publish',
                            );
                            $products = new WP_Query( $args );

                            if ( $products->have_posts() ) {
                                while ( $products->have_posts() ) {
                                    $products->the_post();
                                    global $product;
                                    
                                    $img_url = has_post_thumbnail() ? get_the_post_thumbnail_url(get_the_ID(), 'thumbnail') : wc_placeholder_img_src('thumbnail');
                                    $needs_options = $product->is_type('variable');
                                    
                                    // Controllo se il prodotto ha WooCommerce Product Add-ons
                                    if ( ! $needs_options && class_exists( 'WC_Product_Addons_Helper' ) ) {
                                        $addons = WC_Product_Addons_Helper::get_product_addons( $product->get_id() );
                                        if ( ! empty( $addons ) ) {
                                            $needs_options = true;
                                        }
                                    }
                                    
                                    // Impostiamo un tipo fittizio 'addons' per forzare l'apertura del modale nel JS
                                    $js_product_type = $needs_options ? 'addons' : $product->get_type();
                                    ?>
                                    <div class="mp-menu-row" data-search-term="<?php echo esc_attr(strtolower(get_the_title() . ' ' . get_the_excerpt() . ' ' . $cat->name)); ?>">
                                        <div class="mp-menu-row-img">
                                            <img src="<?php echo esc_url($img_url); ?>" alt="<?php echo esc_attr(get_the_title()); ?>" loading="lazy">
                                        </div>
                                        <div class="mp-menu-row-info">
                                            <h3 class="mp-menu-row-title"><?php the_title(); ?></h3>
                                            <div class="mp-menu-row-desc"><?php echo wp_trim_words(get_the_excerpt(), 15); ?></div>
                                            <div class="mp-menu-row-price"><?php echo $product->get_price_html(); ?></div>
                                        </div>
                                        
                                        <div class="mp-menu-row-actions">
                                            <?php if($needs_options): ?>
                                                <button type="button" class="mp-btn mp-btn-primary mp-btn-small mp-quick-order-btn" data-product_id="<?php echo esc_attr($product->get_id()); ?>" data-product_type="<?php echo esc_attr($js_product_type); ?>">
                                                    Ordina
                                                </button>
                                            <?php else: ?>
                                                <div class="mp-qty-picker">
                                                    <button type="button" class="mp-qty-btn mp-qty-minus">-</button>
                                                    <input type="number" class="mp-qty-input" value="1" min="1" max="99" step="1" title="Qtà">
                                                    <button type="button" class="mp-qty-btn mp-qty-plus">+</button>
                                                </div>
                                                <button type="button" class="mp-btn mp-btn-primary mp-btn-small mp-quick-order-btn" data-product_id="<?php echo esc_attr($product->get_id()); ?>" data-product_type="<?php echo esc_attr($js_product_type); ?>">
                                                    Ordina
                                                </button>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <?php
                                }
                                wp_reset_postdata();
                            } else {
                                echo '<p>Nessun prodotto disponibile in questa categoria.</p>';
                            }
                            ?>
                        </div>
                    </div>
                <?php endforeach; ?>
                
                <div id="mp-no-results" style="display: none; padding: 40px; text-align: center;">
                    <h3 style="margin-bottom: 10px;">Nessun prodotto trovato.</h3>
                    <p>Prova a cercare con altre parole.</p>
                </div>
            </div>

            <!-- 4. Drawer Carrello (Desktop Sidebar / Mobile Drawer) -->
            <aside class="mp-shop-cart-sidebar" id="mp-shop-cart-sidebar">
                <div class="mp-cart-sidebar-inner">
                    <div class="mp-cart-header">
                        <h3>Il tuo Ordine</h3>
                        <button id="mp-cart-close" class="mp-cart-close-btn" aria-label="Chiudi Carrello">&times;</button>
                    </div>
                    
                    <div class="mp-cart-body" id="mp-cart-body">
                        <div class="widget_shopping_cart_content">
                            <?php woocommerce_mini_cart(); ?>
                        </div>
                    </div>
                </div>
            </aside>
            <div class="mp-cart-overlay" id="mp-cart-overlay"></div>
        </div>
    </section>

    <!-- Floating Action Button per Mobile (Mostra Carrello) -->
    <div class="mp-mobile-cart-fab" id="mp-mobile-cart-fab">
        <div class="mp-fab-inner">
            <span class="mp-fab-icon">🛒</span>
            <span class="mp-fab-count" id="mp-fab-count">0</span>
            <span class="mp-fab-text">Vai al Carrello</span>
        </div>
    </div>

</div>

<!-- Quick Order Panel (Modal/Bottom Sheet) -->
<div class="mp-quick-order-overlay" id="mp-quick-order-overlay"></div>
<div class="mp-quick-order-panel" id="mp-quick-order-panel">
    <div class="mp-qop-header">
        <div class="mp-qop-header-text">
            <h3 class="mp-qop-title">Personalizza la tua pizza</h3>
            <p class="mp-qop-subtitle">Scegli impasto, aggiunte e quantità prima di aggiungerla al tuo ordine.</p>
        </div>
        <button type="button" class="mp-qop-close" id="mp-qop-close">&times;</button>
    </div>
    <div class="mp-qop-content" id="mp-qop-content">
        <!-- Loader -->
        <div class="mp-qop-loader">
            <div class="mp-spinner"></div>
            <p>Caricamento opzioni...</p>
        </div>
        <!-- Verrà popolato via AJAX con il form delle varianti WooCommerce -->
    </div>
</div>

<?php
get_footer( 'shop' );
