<?php
/**
 * Functions and helpers for the Oasi delle Spezie Home Page redesign.
 *
 * @package OasiDelleSpezieChild
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Return the site header classes for the current page context.
 *
 * The transparent overlay is intentionally limited to the front page, where
 * the hero provides the contrasting media background.
 *
 * @return string[] Header class names.
 */
function oasi_get_header_class_names(): array {
	$classes = array( 'oasi-header' );

	if ( is_front_page() ) {
		$classes[] = 'oasi-header--overlay';
	}

	return $classes;
}

/**
 * Render one day's opening hours as a clean display string.
 *
 * @param array $day_data Array with 'closed', 'open_24h', and 'slots'.
 * @return string Formatted hours string or 'Chiuso'.
 */
function oasi_format_day_hours( array $day_data ): string {
	if ( ! empty( $day_data['closed'] ) ) {
		return __( 'Chiuso', 'oasidellespezie-child-theme' );
	}

	if ( ! empty( $day_data['open_24h'] ) ) {
		return __( '24 ore', 'oasidellespezie-child-theme' );
	}

	$slots = isset( $day_data['slots'] ) && is_array( $day_data['slots'] ) ? $day_data['slots'] : array();
	$parts = array();

	foreach ( $slots as $slot ) {
		$open  = isset( $slot['open'] ) ? trim( (string) $slot['open'] ) : '';
		$close = isset( $slot['close'] ) ? trim( (string) $slot['close'] ) : '';

		if ( '' === $open && '' === $close ) {
			continue;
		}

		$parts[] = ( '' !== $open && '' !== $close ) ? $open . ' – ' . $close : $open . $close;
	}

	return ! empty( $parts ) ? implode( ', ', $parts ) : __( 'Chiuso', 'oasidellespezie-child-theme' );
}

/**
 * Build a concise, human-readable summary of weekly opening hours.
 *
 * @param array $hours Array of days from ticinoweb_contact_opening_hours.
 * @return array Tuple with ['summary' => string, 'short' => string, 'days' => array].
 */
function oasi_format_opening_hours_data( array $hours ): array {
	$days_labels = array(
		'monday'    => __( 'Lunedì', 'oasidellespezie-child-theme' ),
		'tuesday'   => __( 'Martedì', 'oasidellespezie-child-theme' ),
		'wednesday' => __( 'Mercoledì', 'oasidellespezie-child-theme' ),
		'thursday'  => __( 'Giovedì', 'oasidellespezie-child-theme' ),
		'friday'    => __( 'Venerdì', 'oasidellespezie-child-theme' ),
		'saturday'  => __( 'Sabato', 'oasidellespezie-child-theme' ),
		'sunday'    => __( 'Domenica', 'oasidellespezie-child-theme' ),
	);

	$days_formatted = array();
	foreach ( $days_labels as $day_key => $day_name ) {
		$day_data = $hours[ $day_key ] ?? array();
		$days_formatted[ $day_key ] = array(
			'label' => $day_name,
			'hours' => oasi_format_day_hours( $day_data ),
		);
	}

	$mon_fri_same = true;
	$mf_hours     = $days_formatted['monday']['hours'] ?? '';
	foreach ( array( 'tuesday', 'wednesday', 'thursday', 'friday' ) as $k ) {
		if ( ( $days_formatted[ $k ]['hours'] ?? '' ) !== $mf_hours ) {
			$mon_fri_same = false;
			break;
		}
	}

	$sat_hours = $days_formatted['saturday']['hours'] ?? __( 'Chiuso', 'oasidellespezie-child-theme' );

	if ( $mon_fri_same && ! empty( $mf_hours ) && $mf_hours !== __( 'Chiuso', 'oasidellespezie-child-theme' ) ) {
		if ( ! empty( $sat_hours ) && $sat_hours !== __( 'Chiuso', 'oasidellespezie-child-theme' ) ) {
			$summary = sprintf( __( 'Lun–Ven: %1$s • Sab: %2$s', 'oasidellespezie-child-theme' ), $mf_hours, $sat_hours );
			$short   = sprintf( __( 'Lu-Ve %1$s / Sa %2$s', 'oasidellespezie-child-theme' ), $mf_hours, $sat_hours );
		} else {
			$summary = sprintf( __( 'Lun–Ven: %s (Sab e Dom chiuso)', 'oasidellespezie-child-theme' ), $mf_hours );
			$short   = sprintf( __( 'Lu-Ve %s', 'oasidellespezie-child-theme' ), $mf_hours );
		}
	} else {
		$summary = __( 'Aperto Lun–Sab (vedi orari dettagliati)', 'oasidellespezie-child-theme' );
		$short   = __( 'Lu-Ve / Sa', 'oasidellespezie-child-theme' );
	}

	return array(
		'summary' => $summary,
		'short'   => $short,
		'days'    => $days_formatted,
	);
}

/**
 * Retrieve dynamic contact information from ticinoWEB CMS (#contatti tab).
 *
 * @return array Structured dynamic contact data.
 */
function oasi_get_contact_data(): array {
	static $contact_cache = null;
	if ( null !== $contact_cache ) {
		return $contact_cache;
	}

	if ( function_exists( 'ticinoweb_get_contact_info' ) ) {
		$cms = ticinoweb_get_contact_info();
	} else {
		$phone = (string) get_option( 'ticinoweb_contact_phone', '' );
		$phone_display = (string) get_option( 'ticinoweb_contact_phone_display', '' );
		if ( empty( $phone ) && ! empty( $phone_display ) ) {
			$phone = $phone_display;
		}

		$cms = array(
			'phone'              => $phone ?: '+41 91 859 05 32',
			'phone_landline'     => (string) get_option( 'ticinoweb_contact_phone_landline', '' ),
			'phone_mobile'       => (string) get_option( 'ticinoweb_contact_phone_mobile', '' ),
			'email'              => (string) get_option( 'ticinoweb_contact_email', 'info@oasidellespezie.ch' ),
			'address'            => (string) get_option( 'ticinoweb_contact_address', 'Alla Monda 12, 6515 Gudo' ),
			'facebook'           => (string) get_option( 'ticinoweb_contact_facebook', '' ),
			'instagram'          => (string) get_option( 'ticinoweb_contact_instagram', '' ),
			'linkedin'           => (string) get_option( 'ticinoweb_contact_linkedin', '' ),
			'youtube'            => (string) get_option( 'ticinoweb_contact_youtube', '' ),
			'opening_hours'      => get_option( 'ticinoweb_contact_opening_hours', array() ),
			'opening_hours_note' => (string) get_option( 'ticinoweb_contact_opening_hours_note', '' ),
		);
	}

	$phone_display = ! empty( $cms['phone'] ) ? $cms['phone'] : '+41 91 859 05 32';
	$phone_clean   = preg_replace( '/[^\+0-9]/', '', $phone_display ) ?: '+41918590532';
	$email         = ! empty( $cms['email'] ) ? sanitize_email( $cms['email'] ) : 'info@oasidellespezie.ch';
	$address       = ! empty( $cms['address'] ) ? $cms['address'] : 'Alla Monda 12, 6515 Gudo';

	// Extract city from address string if available
	$city = 'Gudo';
	if ( preg_match( '/\b\d{4}\s+([A-Za-zÀ-ÿ\s\-]+)$/u', $address, $matches ) ) {
		$city = trim( $matches[1] );
	}

	$hours_raw  = is_array( $cms['opening_hours'] ?? null ) ? $cms['opening_hours'] : array();
	$hours_data = oasi_format_opening_hours_data( $hours_raw );

	$contact_cache = array(
		'phone'         => $phone_display,
		'phone_tel'     => $phone_clean,
		'email'         => $email,
		'address'       => $address,
		'city'          => $city,
		'maps_url'      => 'https://maps.google.com/?q=' . rawurlencode( $address ),
		'hours_summary' => $hours_data['summary'],
		'hours_short'   => $hours_data['short'],
		'hours_days'    => $hours_data['days'],
		'hours_note'    => $cms['opening_hours_note'] ?? '',
		'facebook'      => $cms['facebook'] ?? '',
		'instagram'     => $cms['instagram'] ?? '',
		'linkedin'      => $cms['linkedin'] ?? '',
		'youtube'       => $cms['youtube'] ?? '',
	);

	return $contact_cache;
}

/**
 * Retrieve dynamic Hero data from ticinoWEB CMS or safe defaults.
 *
 * @return array Hero configuration with media type, URL, poster, title, description, and CTA.
 */
function oasi_get_hero_data(): array {
	$slider_count = (int) get_option( 'ticinoweb_slider_count', 1 );
	$image_url    = (string) get_option( 'ticinoweb_slider_image_1', '' );
	$title        = (string) get_option( 'ticinoweb_slider_title_1', '' );
	$desc         = (string) get_option( 'ticinoweb_slider_desc_1', '' );
	$btn_text     = (string) get_option( 'ticinoweb_slider_btn_text_1', '' );
	$btn_link     = (string) get_option( 'ticinoweb_slider_btn_link_1', '' );

	// Fallback poster image (Attachment ID 33338 - spices-2.jpg)
	$poster_url = wp_get_attachment_image_url( 33338, '1536x1536' );
	if ( ! $poster_url ) {
		$poster_url = oasi_upload_url( '2022/02/spices-2.jpg' );
	}

	if ( empty( $image_url ) ) {
		// Use video background as primary asset (Attachment ID 33902 / 34964)
		$image_url = oasi_upload_url( '2022/02/spices-2021-08-30-14-03-12-utc.mp4' );
	}

	$is_video = false;
	$path_ext = strtolower( pathinfo( wp_parse_url( $image_url, PHP_URL_PATH ) ?: '', PATHINFO_EXTENSION ) );
	if ( in_array( $path_ext, array( 'mp4', 'webm', 'ogg', 'mov' ), true ) ) {
		$is_video = true;
	}

	if ( empty( $title ) ) {
		$title = "Linea d'eccellenza";
	}

	if ( empty( $desc ) ) {
		$desc = "L'Oasi delle Spezie è un laboratorio artigianale nel Canton Ticino: selezioniamo le migliori spezie dal mondo e le maciniamo su ordinazione per offrire la massima freschezza e conservare gli oli essenziali naturali.";
	}

	if ( empty( $btn_text ) ) {
		$btn_text = 'Scopri le spezie';
	}

	if ( empty( $btn_link ) ) {
		$shop_page_id = function_exists( 'wc_get_page_id' ) ? wc_get_page_id( 'shop' ) : 0;
		$btn_link     = $shop_page_id > 0 ? get_permalink( $shop_page_id ) : home_url( '/shop-online-oasi-delle-spezie/' );
	}

	return array(
		'is_video'    => $is_video,
		'media_url'   => $image_url,
		'poster_url'  => $poster_url,
		'tagline'     => 'Laboratorio Artigianale Svizzero • Dal 2018',
		'title'       => $title,
		'description' => $desc,
		'btn_text'    => $btn_text,
		'btn_link'    => $btn_link,
	);
}

/**
 * Retrieve verified Bestseller products from real historical HPOS order data.
 *
 * @param int $limit Max number of products to return.
 * @return WC_Product[]
 */
function oasi_get_bestseller_products( int $limit = 8 ): array {
	if ( ! function_exists( 'wc_get_product' ) ) {
		return array();
	}

	// Top historical bestsellers identified in products-media-audit.md
	$top_ids = array(
		17104, 9077, 28859, 7665, 16862, 489, 29427, 20157,
		28938, 21735, 16699, 75903, 1893, 30802, 30349, 186089,
		9088, 179385, 11200, 20071,
	);
	$products = array();

	foreach ( $top_ids as $id ) {
		$product = wc_get_product( $id );
		if ( $product && $product->is_visible() ) {
			$products[] = $product;
			if ( count( $products ) >= $limit ) {
				break;
			}
		}
	}

	return $products;
}

/**
 * Retrieve verified products for the 2-row Bestseller Marquee Showcase.
 *
 * @return array Tuple with ['row1' => WC_Product[], 'row2' => WC_Product[]].
 */
function oasi_get_bestseller_showcase_products(): array {
	if ( ! function_exists( 'wc_get_product' ) ) {
		return array( 'row1' => array(), 'row2' => array() );
	}

	// Row 1: 4 real bestsellers
	$row1_ids = array( 17104, 9077, 28859, 7665 );
	// Row 2: 4 real bestsellers
	$row2_ids = array( 28938, 21735, 16699, 75903 );

	$row1 = array();
	foreach ( $row1_ids as $id ) {
		$product = wc_get_product( $id );
		if ( $product && $product->is_visible() ) {
			$row1[] = $product;
		}
	}

	$row2 = array();
	foreach ( $row2_ids as $id ) {
		$product = wc_get_product( $id );
		if ( $product && $product->is_visible() ) {
			$row2[] = $product;
		}
	}

	// Fallback if needed
	if ( count( $row1 ) < 4 || count( $row2 ) < 4 ) {
		$all = oasi_get_bestseller_products( 8 );
		$row1 = array_slice( $all, 0, 4 );
		$row2 = array_slice( $all, 4, 4 );
	}

	return array(
		'row1' => $row1,
		'row2' => $row2,
	);
}

/**
 * Retrieve verified MIXTIS Organic Creations products.
 *
 * @return WC_Product[]
 */
function oasi_get_mixtis_products(): array {
	if ( ! function_exists( 'wc_get_product' ) ) {
		return array();
	}

	// Exact featured products shown in the historical MIXTIS section
	$ids = array( 186089, 179385, 30349, 11200, 9622 );
	$products = array();

	foreach ( $ids as $id ) {
		$product = wc_get_product( $id );
		if ( $product && $product->is_visible() ) {
			$products[] = $product;
		}
	}

	return $products;
}

/**
 * Retrieve verified Gift Boxes and Sets products.
 *
 * @return WC_Product[]
 */
function oasi_get_gift_boxes(): array {
	if ( ! function_exists( 'wc_get_product' ) ) {
		return array();
	}

	// Exact products from the historical gift ideas section
	$ids = array( 69356, 18275, 68322, 33476, 184930 );
	$products = array();

	foreach ( $ids as $id ) {
		$product = wc_get_product( $id );
		if ( $product && $product->is_visible() ) {
			$products[] = $product;
		}
	}

	return $products;
}

/**
 * Whether a product card must show "Esaurito".
 *
 * Variable products count as sold out only when no variation is in stock.
 *
 * @param WC_Product $product Product.
 */
function oasi_product_is_sold_out( WC_Product $product ): bool {
	return ! $product->is_in_stock();
}

/**
 * Print the "Esaurito" badge for a sold-out product (nothing otherwise).
 *
 * @param WC_Product $product Product.
 */
function oasi_render_sold_out_badge( WC_Product $product ): void {
	if ( ! oasi_product_is_sold_out( $product ) ) {
		return;
	}

	printf( '<span class="oasi-sold-out-badge">%s</span>', esc_html__( 'Esaurito', 'oasidellespezie-child-theme' ) );
}

/**
 * Render an elegant, accessible, semantic product card.
 *
 * @param WC_Product $product
 * @param string     $badge Badge text to display (e.g. 'Bio', 'Bestseller', 'Svizzero').
 * @param string     $button_label Optional custom button label.
 */
function oasi_render_product_card( WC_Product $product, string $badge = '', string $button_label = '' ): void {
	$product_id   = $product->get_id();
	$permalink    = get_permalink( $product_id );
	$title        = $product->get_name();
	$price_html   = $product->get_price_html();
	$is_variable  = $product->is_type( 'variable' );
	$image_id     = $product->get_image_id();
	$image_url    = $image_id ? wp_get_attachment_image_url( $image_id, 'medium' ) : wc_placeholder_img_src();
	$image_alt    = get_post_meta( $image_id, '_wp_attachment_image_alt', true ) ?: $title;

	if ( empty( $button_label ) ) {
		$button_label = $is_variable ? __( 'Scegli', 'oasidellespezie-child-theme' ) : __( 'Aggiungi al carrello', 'oasidellespezie-child-theme' );
	}

	// Determine automatic badge if not passed
	if ( empty( $badge ) ) {
		if ( stripos( $title, 'bio' ) !== false ) {
			$badge = 'Bio';
		} elseif ( stripos( $title, 'ticino' ) !== false || stripos( $title, 'svizzero' ) !== false || stripos( $title, 'maggia' ) !== false ) {
			$badge = 'Svizzero';
		}
	}
	$sold_out = oasi_product_is_sold_out( $product );
	?>
	<article class="oasi-product-card<?php echo $sold_out ? ' is-sold-out' : ''; ?>" data-product-id="<?php echo esc_attr( $product_id ); ?>">
		<div class="oasi-product-card__thumb">
			<?php oasi_render_sold_out_badge( $product ); ?>
			<?php if ( ! empty( $badge ) && ! $sold_out ) :
				$badge_slug = sanitize_html_class( strtolower( str_replace( array( ' ', "'" ), '-', $badge ) ) );
			?>
				<span class="oasi-product-badge <?php echo esc_attr( 'oasi-product-badge--' . $badge_slug ); ?>">
					<?php echo esc_html( $badge ); ?>
				</span>
			<?php endif; ?>

			<a href="<?php echo esc_url( $permalink ); ?>" class="oasi-product-card__img-link" tabindex="-1" aria-hidden="true">
				<img src="<?php echo esc_url( $image_url ); ?>" alt="<?php echo esc_attr( $image_alt ); ?>" loading="lazy" width="300" height="300" class="oasi-product-card__img">
			</a>
		</div>

		<div class="oasi-product-card__content">
			<h3 class="oasi-product-card__title">
				<a href="<?php echo esc_url( $permalink ); ?>"><?php echo esc_html( $title ); ?></a>
			</h3>

			<div class="oasi-product-card__price">
				<?php echo wp_kses_post( $price_html ); ?>
			</div>

			<div class="oasi-product-card__action">
				<?php if ( $is_variable ) : ?>
					<a href="<?php echo esc_url( $permalink ); ?>" class="oasi-btn oasi-btn--secondary oasi-btn--sm">
						<?php echo esc_html( $button_label ); ?>
					</a>
				<?php else : ?>
					<a href="<?php echo esc_url( $product->add_to_cart_url() ); ?>"
					   data-quantity="1"
					   class="oasi-btn oasi-btn--primary oasi-btn--sm <?php echo esc_attr( $product->is_purchasable() && $product->is_in_stock() ? 'add_to_cart_button ajax_add_to_cart' : '' ); ?>"
					   data-product_id="<?php echo esc_attr( $product_id ); ?>"
					   data-product_sku="<?php echo esc_attr( $product->get_sku() ); ?>"
					   aria-label="<?php echo esc_attr( sprintf( __( 'Aggiungi "%s" al carrello', 'oasidellespezie-child-theme' ), $title ) ); ?>"
					   rel="nofollow">
						<?php echo esc_html( $button_label ); ?>
					</a>
				<?php endif; ?>
			</div>
		</div>
	</article>
	<?php
}

/**
 * Render the compact WooCommerce card used only by the Home Product Ribbon.
 *
 * @param WC_Product $product Product to render.
 */
function oasi_render_product_ribbon_card( WC_Product $product ): void {
	$product_id  = $product->get_id();
	$permalink   = get_permalink( $product_id );
	$title       = $product->get_name();
	$price_html  = $product->get_price_html();
	$is_variable = $product->is_type( 'variable' );
	$image_id    = $product->get_image_id();
	$image_url   = $image_id ? wp_get_attachment_image_url( $image_id, 'medium' ) : wc_placeholder_img_src();
	$image_alt   = $image_id ? get_post_meta( $image_id, '_wp_attachment_image_alt', true ) : '';
	$image_alt   = $image_alt ?: $title;
	$is_addable  = ! $is_variable && $product->is_purchasable() && $product->is_in_stock();
	$action_url  = $is_addable ? $product->add_to_cart_url() : $permalink;
	$action_aria = $is_addable
		? sprintf( __( 'Aggiungi "%s" al carrello', 'oasidellespezie-child-theme' ), $title )
		: sprintf( __( 'Scopri "%s"', 'oasidellespezie-child-theme' ), $title );
	?>
	<article class="oasi-ribbon-card<?php echo oasi_product_is_sold_out( $product ) ? ' is-sold-out' : ''; ?>" data-product-id="<?php echo esc_attr( $product_id ); ?>">
		<a href="<?php echo esc_url( $permalink ); ?>" class="oasi-ribbon-card__media" tabindex="-1" aria-hidden="true">
			<?php oasi_render_sold_out_badge( $product ); ?>
			<img src="<?php echo esc_url( $image_url ); ?>" alt="<?php echo esc_attr( $image_alt ); ?>" loading="lazy" width="120" height="120" class="oasi-ribbon-card__image">
		</a>
		<div class="oasi-ribbon-card__content">
			<h3 class="oasi-ribbon-card__title">
				<a href="<?php echo esc_url( $permalink ); ?>"><?php echo esc_html( $title ); ?></a>
			</h3>
			<div class="oasi-ribbon-card__price"><?php echo wp_kses_post( $price_html ); ?></div>
		</div>
		<a href="<?php echo esc_url( $action_url ); ?>"
			class="oasi-ribbon-card__action<?php echo $is_addable ? ' add_to_cart_button ajax_add_to_cart' : ''; ?>"
			<?php if ( $is_addable ) : ?>data-quantity="1" data-product_id="<?php echo esc_attr( $product_id ); ?>" data-product_sku="<?php echo esc_attr( $product->get_sku() ); ?>" rel="nofollow"<?php endif; ?>
			aria-label="<?php echo esc_attr( $action_aria ); ?>">
			<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M7 17l9.2-9.2M17 17V8H8"/></svg>
		</a>
	</article>
	<?php
}

/**
 * Render an individual artisanal masonry card for the Home Bestsellers grid.
 *
 * @param WC_Product $product Product to render.
 * @param int        $index   0-based index within the row (0 to 3).
 * @param int        $row     Row number (1 or 2).
 */
function oasi_render_bestseller_masonry_card( WC_Product $product, int $index = 0, int $row = 1 ): void {
	$product_id  = $product->get_id();
	$permalink   = get_permalink( $product_id );
	$title       = $product->get_name();
	$price_html  = $product->get_price_html();
	$is_variable = $product->is_type( 'variable' );
	$image_id    = $product->get_image_id();
	$image_url   = $image_id ? wp_get_attachment_image_url( $image_id, 'medium_large' ) : wc_placeholder_img_src();
	$image_alt   = $image_id ? get_post_meta( $image_id, '_wp_attachment_image_alt', true ) : '';
	$image_alt   = $image_alt ?: $title;
	$is_addable  = ! $is_variable && $product->is_purchasable() && $product->is_in_stock();
	$action_url  = $is_addable ? $product->add_to_cart_url() : $permalink;
	$action_aria = $is_addable
		? sprintf( __( 'Aggiungi "%s" al carrello', 'oasidellespezie-child-theme' ), $title )
		: sprintf( __( 'Scopri "%s"', 'oasidellespezie-child-theme' ), $title );
	$action_text = $is_variable ? __( 'Scegli', 'oasidellespezie-child-theme' ) : __( 'Aggiungi', 'oasidellespezie-child-theme' );

	// Determine artisanal badge
	$badge = 'Bestseller';
	$badge_type = 'bestseller';
	if ( stripos( $title, 'bio' ) !== false ) {
		$badge = '100% Bio';
		$badge_type = 'bio';
	} elseif ( stripos( $title, 'ticino' ) !== false || stripos( $title, 'svizzero' ) !== false || stripos( $title, 'ceresio' ) !== false || stripos( $title, 'maggia' ) !== false ) {
		$badge = 'Selezione Ticino';
		$badge_type = 'ticino';
	} elseif ( stripos( $title, 'igp' ) !== false || stripos( $title, 'guérande' ) !== false || stripos( $title, 'guerande' ) !== false ) {
		$badge = 'Origine IGP';
		$badge_type = 'igp';
	}

	if ( oasi_product_is_sold_out( $product ) ) {
		$badge      = __( 'Esaurito', 'oasidellespezie-child-theme' );
		$badge_type = 'esaurito';
	}

	// Category eyebrow
	$terms = get_the_terms( $product_id, 'product_cat' );
	$category_name = '';
	if ( ! empty( $terms ) && ! is_wp_error( $terms ) ) {
		foreach ( $terms as $term ) {
			if ( 'uncategorized' !== $term->slug && 'senza-categoria' !== $term->slug ) {
				$category_name = $term->name;
				break;
			}
		}
	}
	if ( empty( $category_name ) ) {
		$category_name = __( 'Specialità Artigianale', 'oasidellespezie-child-theme' );
	}
	?>
	<article class="oasi-bestseller-card oasi-masonry-card<?php echo oasi_product_is_sold_out( $product ) ? ' is-sold-out' : ''; ?>" data-product-id="<?php echo esc_attr( $product_id ); ?>">
		<div class="oasi-bestseller-card__media-wrap">
			<a href="<?php echo esc_url( $permalink ); ?>" class="oasi-bestseller-card__media-link" aria-label="<?php echo esc_attr( $title ); ?>" tabindex="-1">
				<img src="<?php echo esc_url( $image_url ); ?>" alt="<?php echo esc_attr( $image_alt ); ?>" loading="lazy" width="300" height="180" class="oasi-bestseller-card__img">
			</a>
			<span class="oasi-bestseller-card__badge oasi-bestseller-card__badge--<?php echo esc_attr( $badge_type ); ?>">
				<span class="oasi-bestseller-card__badge-dot" aria-hidden="true"></span>
				<?php echo esc_html( $badge ); ?>
			</span>
		</div>
		<div class="oasi-bestseller-card__body">
			<span class="oasi-bestseller-card__cat"><?php echo esc_html( $category_name ); ?></span>
			<h3 class="oasi-bestseller-card__title">
				<a href="<?php echo esc_url( $permalink ); ?>"><?php echo esc_html( $title ); ?></a>
			</h3>
			<div class="oasi-bestseller-card__footer">
				<div class="oasi-bestseller-card__price"><?php echo wp_kses_post( $price_html ); ?></div>
				<a href="<?php echo esc_url( $action_url ); ?>"
					class="oasi-bestseller-card__btn<?php echo $is_addable ? ' add_to_cart_button ajax_add_to_cart' : ''; ?>"
					<?php if ( $is_addable ) : ?>data-quantity="1" data-product_id="<?php echo esc_attr( $product_id ); ?>" data-product_sku="<?php echo esc_attr( $product->get_sku() ); ?>" rel="nofollow"<?php endif; ?>
					aria-label="<?php echo esc_attr( $action_aria ); ?>">
					<span><?php echo esc_html( $action_text ); ?></span>
					<svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M7 17l9.2-9.2M17 17V8H8"/></svg>
				</a>
			</div>
		</div>
	</article>
	<?php
}

/**
 * Return master logo URL with transparent background.
 *
 * @return string Master logo URL or empty string.
 */
function oasi_get_master_logo_url(): string {
	$cms_logo = function_exists( 'ticinoweb_get_site_logo' ) ? ticinoweb_get_site_logo() : '';
	$url      = is_string( $cms_logo ) ? trim( $cms_logo ) : '';

	if ( '' === $url ) {
		$url = wp_get_attachment_image_url( 186270, 'full' );
	}
	if ( ! $url ) {
		$url = oasi_upload_url( '2026/02/oasi-delle-spezie-logo-2.1-sfondo-trasparente-e1779111706924.png' );
	}

	return esc_url_raw( $url );
}

/**
 * Memoise an expensive catalog structure per request and in the object cache.
 *
 * Keyed by locale because tW Translate prefixes URLs per language, and by a salt
 * that changes whenever menus or product categories (names, images, counts) change.
 * Without a persistent object cache it still avoids rebuilding within one request.
 *
 * @param string   $name  Structure name.
 * @param callable $build Builder returning the structure.
 * @return mixed
 */
function oasi_catalog_cached( string $name, callable $build ): mixed {
	static $memo = array();

	if ( ! function_exists( 'wp_cache_get' ) ) {
		return $build();
	}

	$salt = wp_cache_get( 'salt', 'oasi_catalog' );
	if ( false === $salt ) {
		$salt = (string) microtime( true );
		wp_cache_set( 'salt', $salt, 'oasi_catalog' );
	}

	$key = $name . '_' . get_locale() . '_' . $salt;
	if ( array_key_exists( $key, $memo ) ) {
		return $memo[ $key ];
	}

	$value = wp_cache_get( $key, 'oasi_catalog' );
	if ( false === $value ) {
		$value = $build();
		wp_cache_set( $key, $value, 'oasi_catalog', 12 * HOUR_IN_SECONDS );
	}

	return $memo[ $key ] = $value;
}

/**
 * Invalidate every cached catalog structure.
 */
function oasi_catalog_cache_flush(): void {
	if ( function_exists( 'wp_cache_set' ) ) {
		wp_cache_set( 'salt', (string) microtime( true ), 'oasi_catalog' );
	}
}
if ( function_exists( 'add_action' ) ) {
	foreach ( array( 'wp_update_nav_menu', 'wp_delete_nav_menu', 'created_product_cat', 'edited_product_cat', 'delete_product_cat', 'edited_term_taxonomy', 'set_object_terms', 'switch_theme' ) as $oasi_catalog_hook ) {
		add_action( $oasi_catalog_hook, 'oasi_catalog_cache_flush' );
	}
	unset( $oasi_catalog_hook );
}

/**
 * Retrieve all product categories organized into coherent macro-groups (cached).
 *
 * @return array[]
 */
function oasi_get_category_macro_groups(): array {
	return oasi_catalog_cached( 'macro_groups', 'oasi_build_category_macro_groups' );
}

/**
 * Retrieve all 45 product categories organized into 6 coherent macro-groups.
 *
 * @return array[] Array of macro-groups with id, name, icon, description, and terms.
 */
function oasi_build_category_macro_groups(): array {
	$macro_definitions = array(
		'spezie-erbe' => array(
			'id'          => 'spezie-erbe',
			'name'        => 'Spezie, Erbe & Botaniche',
			'short_name'  => 'Spezie & Erbe',
			'icon'        => '🌿',
			'badge'       => 'Pura Natura',
			'description' => 'Singole spezie nobili macinate su ordinazione, erbe aromatiche pure biologiche, vaniglie pregiate e fiori eduli.',
			'slugs'       => array(
				'spezie-bio',
				'erbe-aromatiche-bio',
				'mix-erbe-aromatiche-bio',
				'semi-aromatici-bio',
				'chili-paprika-bio',
				'fiori-bio',
				'vaniglie',
				'aglio-nero',
				'erbe-officinali',
				'vaniglia-blu',
			),
		),
		'miscele-rub' => array(
			'id'          => 'miscele-rub',
			'name'        => 'Miscele, Rub & Creazioni',
			'short_name'  => 'Miscele & Rub',
			'icon'        => '✨',
			'badge'       => 'Artigianali',
			'description' => "L'alta espressione del nostro atelier: bouquet di spezie bilanciati a mano, BBQ Rub d'autore, superpolveri e ricette ayurvediche.",
			'slugs'       => array(
				'miscele-di-spezie-bio',
				'rub-bio',
				'superpolvere-bio',
				'ayurveda',
			),
		),
		'sali-pepi' => array(
			'id'          => 'sali-pepi',
			'name'        => 'Sali dal Mondo, Pepi & Macine',
			'short_name'  => 'Sali & Pepi',
			'icon'        => '🧂',
			'badge'       => 'Origini Rare',
			'description' => 'Fior di sale atlantici, sali rosa incontaminati, pepi rari in grani, bacche profumate e innovative sfere da grattugiare.',
			'slugs'       => array(
				'sali-del-mondo',
				'fior-di-sali',
				'sali-aromatizzati-bio',
				'pepi-e-bacche-bio',
				'pepi-aromatizzati-bio',
				'sfere-da-grattugiare',
			),
		),
		'te-benessere' => array(
			'id'          => 'te-benessere',
			'name'        => 'Tè, Tisane, Superfood & Vitalità',
			'short_name'  => 'Tè & Benessere',
			'icon'        => '🍵',
			'badge'       => 'Benessere Quotidiano',
			'description' => 'Pregiate foglie di tè biologico, tisane rilassanti, alghe ricche di minerali e superfood naturali per l’armonia del corpo.',
			'slugs'       => array(
				'te-bio',
				'superfood-bio',
				'alghe',
			),
		),
		'dispensa-gourmet' => array(
			'id'          => 'dispensa-gourmet',
			'name'        => 'Dispensa Gourmet & Delizie',
			'short_name'  => 'Dispensa Gourmet',
			'icon'        => '🍯',
			'badge'       => 'Golosità Bio',
			'description' => 'Condimenti artigianali, Aceto Balsamico Tradizionale DOP, perle balsamiche, mieli ticinesi, frutta secca e cioccolato d’eccellenza.',
			'slugs'       => array(
				'condimenti-bio',
				'aceto-balsamico-dop',
				'perle-balsamiche',
				'aceti-e-oli-bio',
				'oli-bio',
				'mieli-e-marmellate-bio',
				'frutta-secca-bio',
				'crunchy-fruits-bio-2',
				'zuccheri-dorigine-bio',
				'zuccheri-aromatizzati-bio',
				'sciroppi-bio',
				'verdure-disidratate-bio',
				'cereali-bio',
				'cioccolato-bio',
			),
		),
		'svizzera-regali' => array(
			'id'          => 'svizzera-regali',
			'name'        => 'Tipicità Svizzere & Idee Regalo',
			'short_name'  => 'Svizzera & Regali',
			'icon'        => '🇨🇭',
			'badge'       => 'Territorio & Doni',
			'description' => 'Specialità ticinesi certificate, creazioni dal Canada, liquori artigianali e cofanetti regalo esclusivi per intenditori.',
			'slugs'       => array(
				'prodotti-svizzeri-bio',
				'idee-regalo',
				'box',
				'prodotti-del-canada',
				'bevande-alcoliche',
				'bevande-analcoliche',
				'accessori',
				'date-corte',
			),
		),
	);

	$groups     = array();
	$mapped_ids = array();

	foreach ( $macro_definitions as $key => $def ) {
		$categories     = array();
		$total_products = 0;

		foreach ( $def['slugs'] as $slug ) {
			$term = get_term_by( 'slug', $slug, 'product_cat' );
			if ( ! $term || is_wp_error( $term ) ) {
				continue;
			}

			$thumb_id  = get_term_meta( $term->term_id, 'thumbnail_id', true );
			$image_url = $thumb_id ? wp_get_attachment_image_url( (int) $thumb_id, 'medium' ) : '';
			$term_link = get_term_link( $term );

			$categories[] = array(
				'id'        => $term->term_id,
				'name'      => html_entity_decode( $term->name, ENT_QUOTES, 'UTF-8' ),
				'slug'      => $term->slug,
				'count'     => (int) $term->count,
				'image_url' => $image_url,
				'url'       => ! is_wp_error( $term_link ) ? $term_link : '#',
			);

			$mapped_ids[]    = $term->term_id;
			$total_products += (int) $term->count;
		}

		$def['categories']     = $categories;
		$def['total_products'] = $total_products;
		$def['cat_count']      = count( $categories );
		$groups[ $key ]        = $def;
	}

	// Dynamic fallback for any newly added product categories
	$all_terms = get_terms( array(
		'taxonomy'   => 'product_cat',
		'hide_empty' => false,
	) );

	if ( ! is_wp_error( $all_terms ) && is_array( $all_terms ) ) {
		foreach ( $all_terms as $unmapped ) {
			if ( ! in_array( $unmapped->term_id, $mapped_ids, true ) && $unmapped->slug !== 'uncategorized' ) {
				$thumb_id  = get_term_meta( $unmapped->term_id, 'thumbnail_id', true );
				$image_url = $thumb_id ? wp_get_attachment_image_url( (int) $thumb_id, 'medium' ) : '';
				$term_link = get_term_link( $unmapped );

				$groups['svizzera-regali']['categories'][] = array(
					'id'        => $unmapped->term_id,
					'name'      => html_entity_decode( $unmapped->name, ENT_QUOTES, 'UTF-8' ),
					'slug'      => $unmapped->slug,
					'count'     => (int) $unmapped->count,
					'image_url' => $image_url,
					'url'       => ! is_wp_error( $term_link ) ? $term_link : '#',
				);
				$groups['svizzera-regali']['cat_count']++;
				$groups['svizzera-regali']['total_products'] += (int) $unmapped->count;
			}
		}
	}

	return $groups;
}
