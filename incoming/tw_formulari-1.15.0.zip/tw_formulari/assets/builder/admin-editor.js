/**
 * TW Formulari — visual form editor.
 *
 * Left: add fields / outline. Centre: live preview rendered by the server with the same code the site uses (inside an
 * iframe, so styles never clash with the WordPress admin). Right: settings of the selected field.
 * Tabs for notifications, what happens after sending, settings and the raw JSON.
 *
 * Everything is saved through the REST endpoint of the plugin, which normalises the definition on the server.
 */
(function () {
	'use strict';

	var D = window.TWF_EDITOR;
	var root = document.getElementById('twf-editor');
	if (!D || !root) { return; }

	function t(s) { return (D.i18n && D.i18n[s]) || s; }
	function clone(o) { return JSON.parse(JSON.stringify(o)); }

	function el(tag, attrs, kids) {
		var n = document.createElement(tag);
		Object.keys(attrs || {}).forEach(function (k) {
			var v = attrs[k];
			if (v === null || v === undefined || v === false) { return; }
			if (k === 'class') { n.className = v; }
			else if (k === 'text') { n.textContent = v; }
			else if (k.indexOf('on') === 0) { n.addEventListener(k.slice(2), v); }
			else if (v === true) { n.setAttribute(k, ''); }
			else { n.setAttribute(k, v); }
		});
		(kids || []).forEach(function (c) {
			if (c === null || c === undefined || c === false) { return; }
			n.appendChild(typeof c === 'string' ? document.createTextNode(c) : c);
		});
		return n;
	}
	function clear(n) { while (n.firstChild) { n.removeChild(n.firstChild); } }

	/* ---------------------------------------------------------------- state */

	var state = {
		def: clone(D.definition),
		title: D.title,
		selected: null,
		tab: 'fields',
		side: (D.definition.fields || []).length ? 'outline' : 'add',
		dirty: false,
		saving: false,
		device: 'desktop'
	};

	var GROUPS = [
		{ title: 'Dati personali', types: ['name', 'email', 'phone', 'address'] },
		{ title: 'Testo, numeri e date', types: ['text', 'textarea', 'number', 'currency', 'date'] },
		{ title: 'Scelte', types: ['select', 'radio', 'checkbox'] },
		{ title: 'Altro', types: ['upload', 'gdpr', 'calculation', 'hidden'] },
		{ title: 'Impaginazione', types: ['section', 'html', 'page_break'] }
	];
	var LAYOUT = ['html', 'section', 'page_break'];
	var TEXT_LIKE = ['text', 'textarea', 'email', 'phone', 'number', 'currency'];

	function isInput(type) { return LAYOUT.indexOf(type) === -1; }
	function typeLabel(type) { return (D.types && D.types[type]) || type; }
	function fieldById(id) { return (state.def.fields || []).filter(function (f) { return f.id === id; })[0] || null; }
	function indexOfField(id) { var i = -1; (state.def.fields || []).forEach(function (f, k) { if (f.id === id) { i = k; } }); return i; }
	function fieldName(f) { return (f.label && f.label.trim()) || typeLabel(f.type); }
	function inputFields(exceptId) { return (state.def.fields || []).filter(function (f) { return isInput(f.type) && f.id !== exceptId; }); }

	function slug(text) {
		var s = String(text || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^a-z0-9]+/g, '_').replace(/^_+|_+$/g, '');
		return (s || 'campo').slice(0, 30);
	}
	function uniqueId(base) {
		var used = {};
		(state.def.fields || []).forEach(function (f) { used[f.id] = true; });
		(state.def.notifications || []).forEach(function (n) { used[n.id] = true; });
		var id = base, n = 2;
		while (used[id]) { id = base.slice(0, 36) + '_' + n; n++; }
		return id;
	}

	/* ---------------------------------------------------------------- preview */

	var frame, frameReady = false, previewTimer = null, previewSeq = 0, lastHtml = '';

	function previewDoc() {
		var css = D.preview.css, js = D.preview.js;
		return '<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">' +
			'<link rel="stylesheet" href="' + css + '"><style>body{margin:0;padding:22px;background:#fff;font:16px/1.5 system-ui,-apple-system,Segoe UI,Roboto,sans-serif;color:#111827}</style></head>' +
			'<body><div id="mount"></div><script src="' + js + '"><\/script><script>' +
			'(function(){var mount=document.getElementById("mount");' +
			'function mark(id){document.querySelectorAll(".twf-selected").forEach(function(n){n.classList.remove("twf-selected")});if(!id)return;var n=document.querySelector("[data-field-id=\\""+id+"\\"]");if(n){n.classList.add("twf-selected");n.scrollIntoView({block:"nearest",behavior:"smooth"})}}' +
			'window.addEventListener("message",function(e){var d=e.data||{};if(d.type==="render"){var y=window.scrollY;mount.innerHTML=d.html;document.querySelectorAll(".twf-form").forEach(function(f){window.twfInit&&window.twfInit(f)});mark(d.selected);window.scrollTo(0,y)}else if(d.type==="select"){mark(d.id)}});' +
			'document.addEventListener("click",function(e){var f=e.target.closest("[data-field-id]");e.preventDefault();if(f){parent.postMessage({type:"select",id:f.getAttribute("data-field-id")},"*")}},true);' +
			'parent.postMessage({type:"ready"},"*")})();<\/script></body></html>';
	}

	function schedulePreview(immediate) {
		clearTimeout(previewTimer);
		previewTimer = setTimeout(refreshPreview, immediate ? 0 : 300);
	}

	function refreshPreview() {
		if (!frame) { return; }
		var seq = ++previewSeq;
		api('preview', 'POST', { id: D.id, definition: state.def }).then(function (res) {
			if (seq !== previewSeq || !res || !res.html) { return; }
			lastHtml = res.html;
			postToFrame({ type: 'render', html: res.html, selected: state.selected });
		}).catch(function () { /* the preview keeps its last state */ });
	}

	function postToFrame(msg) {
		if (frame && frame.contentWindow && frameReady) { frame.contentWindow.postMessage(msg, '*'); }
	}

	window.addEventListener('message', function (e) {
		if (!frame || e.source !== frame.contentWindow) { return; }
		var d = e.data || {};
		if (d.type === 'ready') { frameReady = true; if (lastHtml) { postToFrame({ type: 'render', html: lastHtml, selected: state.selected }); } else { refreshPreview(); } }
		if (d.type === 'select' && fieldById(d.id)) { select(d.id, true); }
	});

	/* ---------------------------------------------------------------- api */

	function api(path, method, body) {
		return fetch(D.rest.base + path, {
			method: method,
			credentials: 'same-origin',
			headers: { 'X-WP-Nonce': D.rest.nonce, 'Content-Type': 'application/json', 'Accept': 'application/json' },
			body: body ? JSON.stringify(body) : undefined
		}).then(function (res) {
			return res.json().catch(function () { return {}; }).then(function (data) {
				if (!res.ok) { var err = new Error(data && data.message ? data.message : t('Qualcosa non ha funzionato.')); err.data = data; throw err; }
				return data;
			});
		});
	}

	/* ---------------------------------------------------------------- shell */

	var els = {};

	function build() {
		clear(root);

		els.title = el('input', { type: 'text', class: 'twf-title', value: state.title, 'aria-label': t('Titolo del modulo'), oninput: function (e) { state.title = e.target.value; touch(true); } });
		els.status = el('span', { class: 'twf-savestate', role: 'status' });
		els.save = el('button', { type: 'button', class: 'button button-primary twf-save', onclick: save }, [t('Salva')]);
		els.shortcode = el('code', { class: 'twf-code', title: t('Incolla questo codice nella pagina dove vuoi il modulo') }, [D.shortcode]);
		els.copy = el('button', { type: 'button', class: 'button', onclick: copyShortcode }, [t('Copia')]);

		var bar = el('div', { class: 'twf-bar' }, [
			el('a', { class: 'twf-back', href: D.listUrl }, ['← ' + t('Moduli')]),
			els.title,
			el('div', { class: 'twf-bar__right' }, [
				el('span', { class: 'twf-sc' }, [t('Da incollare nella pagina:'), ' ', els.shortcode, ' ', els.copy]),
				el('a', { class: 'button', href: D.entriesUrl }, [t('Compilazioni')]),
				els.status, els.save
			])
		]);

		els.tabs = el('nav', { class: 'twf-tabs', role: 'tablist' });
		els.body = el('div', { class: 'twf-body' });
		els.toast = el('div', { class: 'twf-toast', role: 'alert' });

		root.appendChild(bar);
		root.appendChild(els.tabs);
		root.appendChild(els.body);
		root.appendChild(els.toast);

		renderTabs();
		renderBody();
		updateSaveState();
	}

	var TABS = [['fields', 'Campi'], ['notifications', 'Notifiche e-mail'], ['confirmation', 'Dopo l’invio'], ['payment', 'Pagamento'], ['settings', 'Impostazioni'], ['json', 'Avanzate']];

	function renderTabs() {
		clear(els.tabs);
		TABS.forEach(function (tab) {
			els.tabs.appendChild(el('button', {
				type: 'button', role: 'tab', 'aria-selected': state.tab === tab[0] ? 'true' : 'false',
				class: 'twf-tab' + (state.tab === tab[0] ? ' is-active' : ''),
				onclick: function () { state.tab = tab[0]; renderTabs(); renderBody(); }
			}, [t(tab[1])]));
		});
	}

	function renderBody() {
		clear(els.body);
		frame = null; frameReady = false;
		if (state.tab === 'fields') { renderFieldsTab(); }
		else if (state.tab === 'notifications') { renderNotificationsTab(); }
		else if (state.tab === 'confirmation') { renderConfirmationTab(); }
		else if (state.tab === 'payment') { renderPaymentTab(); }
		else if (state.tab === 'settings') { renderSettingsTab(); }
		else { renderJsonTab(); }
	}

	function touch(titleOnly) {
		state.dirty = true;
		updateSaveState();
		if (!titleOnly && state.tab === 'fields') { schedulePreview(false); }
	}

	function updateSaveState() {
		if (!els.status) { return; }
		els.status.textContent = state.saving ? t('Salvataggio…') : (state.dirty ? t('Modifiche non salvate') : t('Tutto salvato'));
		els.status.className = 'twf-savestate' + (state.dirty ? ' is-dirty' : '');
		els.save.disabled = state.saving;
	}

	function toast(message, ok) {
		els.toast.textContent = message;
		els.toast.className = 'twf-toast is-visible ' + (ok ? 'is-ok' : 'is-error');
		clearTimeout(toast.timer);
		toast.timer = setTimeout(function () { els.toast.className = 'twf-toast'; }, ok ? 2500 : 7000);
	}

	function copyShortcode() {
		var done = function () { toast(t('Copiato: incollalo nella pagina.'), true); };
		if (navigator.clipboard && navigator.clipboard.writeText) { navigator.clipboard.writeText(D.shortcode).then(done); }
		else { var r = document.createRange(); r.selectNode(els.shortcode); window.getSelection().removeAllRanges(); window.getSelection().addRange(r); document.execCommand('copy'); done(); }
	}

	function save() {
		if (state.saving) { return; }
		state.saving = true; updateSaveState();
		api('forms', 'POST', { id: D.id, title: state.title, definition: state.def }).then(function (res) {
			state.def = res.definition;
			state.title = res.title;
			state.dirty = false;
			if (state.selected && !fieldById(state.selected)) { state.selected = null; }
			els.title.value = state.title;
			toast(t('Modulo salvato.'), true);
			renderBody();
		}).catch(function (err) {
			toast(err.message || t('Non sono riuscito a salvare.'), false);
		}).then(function () { state.saving = false; updateSaveState(); });
	}

	document.addEventListener('keydown', function (e) {
		if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 's') { e.preventDefault(); save(); }
	});
	window.addEventListener('beforeunload', function (e) { if (state.dirty) { e.preventDefault(); e.returnValue = ''; } });

	/* ---------------------------------------------------------------- form controls */

	function row(label, control, hint) {
		return el('div', { class: 'twf-row' }, [el('label', { class: 'twf-label' }, [label, control]), hint ? el('p', { class: 'twf-hint' }, [hint]) : null]);
	}
	function textInput(label, obj, key, opts) {
		opts = opts || {};
		var input = el('input', { type: opts.type || 'text', value: obj[key] === undefined ? '' : obj[key], placeholder: opts.placeholder || null, min: opts.min, max: opts.max, step: opts.step,
			oninput: function (e) { obj[key] = e.target.value; touch(); if (opts.onchange) { opts.onchange(); } } });
		return row(label, input, opts.hint);
	}
	function areaInput(label, obj, key, opts) {
		opts = opts || {};
		var area = el('textarea', { rows: opts.rows || 4, placeholder: opts.placeholder || null, oninput: function (e) { obj[key] = e.target.value; touch(); } });
		area.value = obj[key] === undefined ? '' : obj[key];
		return row(label, area, opts.hint);
	}
	function checkInput(label, obj, key, opts) {
		opts = opts || {};
		var cb = el('input', { type: 'checkbox', onchange: function (e) { obj[key] = e.target.checked; touch(); if (opts.onchange) { opts.onchange(); } } });
		cb.checked = !!obj[key];
		return el('div', { class: 'twf-row twf-row--check' }, [el('label', null, [cb, ' ', label]), opts.hint ? el('p', { class: 'twf-hint' }, [opts.hint]) : null]);
	}
	function selectInput(label, obj, key, choices, opts) {
		opts = opts || {};
		var sel = el('select', { onchange: function (e) { obj[key] = e.target.value; touch(); if (opts.onchange) { opts.onchange(); } } },
			choices.map(function (c) { return el('option', { value: c[0], selected: String(obj[key]) === String(c[0]) }, [c[1]]); }));
		return row(label, sel, opts.hint);
	}
	function section(title, kids, open) {
		var d = el('details', { class: 'twf-section', open: open !== false }, [el('summary', null, [title])].concat(kids));
		return d;
	}

	/* ---------------------------------------------------------------- Fields tab */

	function renderFieldsTab() {
		var left = el('aside', { class: 'twf-col twf-left' });
		var mid = el('section', { class: 'twf-col twf-mid' });
		var right = el('aside', { class: 'twf-col twf-right' });
		els.left = left; els.right = right;

		els.devices = el('div', { class: 'twf-devices' }, [
			el('button', { type: 'button', class: 'button' + (state.device === 'desktop' ? ' is-active' : ''), onclick: function () { setDevice('desktop'); } }, [t('Computer')]),
			el('button', { type: 'button', class: 'button' + (state.device === 'phone' ? ' is-active' : ''), onclick: function () { setDevice('phone'); } }, [t('Telefono')])
		]);
		frame = el('iframe', { class: 'twf-frame', title: t('Anteprima del modulo'), srcdoc: previewDoc() });
		els.frameWrap = el('div', { class: 'twf-framewrap is-' + state.device }, [frame]);
		mid.appendChild(el('div', { class: 'twf-midbar' }, [el('span', null, [t('Anteprima — clicca un campo per modificarlo')]), els.devices]));
		mid.appendChild(els.frameWrap);

		els.body.appendChild(left);
		els.body.appendChild(mid);
		els.body.appendChild(right);
		renderLeft();
		renderRight();
	}

	function setDevice(d) {
		state.device = d;
		els.frameWrap.className = 'twf-framewrap is-' + d;
		Array.prototype.forEach.call(els.devices.children, function (b, i) { b.classList.toggle('is-active', (i === 0) === (d === 'desktop')); });
	}

	function renderLeft() {
		var left = els.left;
		clear(left);
		left.appendChild(el('div', { class: 'twf-subtabs' }, [
			el('button', { type: 'button', class: 'twf-subtab' + (state.side === 'outline' ? ' is-active' : ''), onclick: function () { state.side = 'outline'; renderLeft(); } }, [t('Struttura')]),
			el('button', { type: 'button', class: 'twf-subtab' + (state.side === 'add' ? ' is-active' : ''), onclick: function () { state.side = 'add'; renderLeft(); } }, [t('Aggiungi campo')])
		]));
		if (state.side === 'add') { left.appendChild(renderPalette()); } else { left.appendChild(renderOutline()); }
	}

	function renderPalette() {
		var box = el('div', { class: 'twf-palette' });
		GROUPS.forEach(function (g) {
			box.appendChild(el('h4', null, [t(g.title)]));
			var wrap = el('div', { class: 'twf-chips' });
			g.types.forEach(function (type) {
				wrap.appendChild(el('button', { type: 'button', class: 'twf-chip', onclick: function () { addField(type); } }, ['+ ' + typeLabel(type)]));
			});
			box.appendChild(wrap);
		});
		return box;
	}

	var dragId = null;

	function renderOutline() {
		var fields = state.def.fields || [];
		if (!fields.length) {
			return el('div', { class: 'twf-emptybox' }, [el('p', null, [t('Il modulo è vuoto.')]), el('button', { type: 'button', class: 'button button-primary', onclick: function () { state.side = 'add'; renderLeft(); } }, [t('Aggiungi il primo campo')])]);
		}
		var ul = el('ul', { class: 'twf-outline' });
		fields.forEach(function (f) {
			var li = el('li', {
				class: 'twf-outline__item' + (f.id === state.selected ? ' is-selected' : '') + (f.type === 'page_break' ? ' is-break' : ''),
				draggable: 'true', 'data-id': f.id,
				onclick: function () { select(f.id); },
				ondragstart: function (e) { dragId = f.id; e.dataTransfer.effectAllowed = 'move'; try { e.dataTransfer.setData('text/plain', f.id); } catch (x) { /* old browsers */ } },
				ondragover: function (e) { e.preventDefault(); li.classList.add('is-over'); },
				ondragleave: function () { li.classList.remove('is-over'); },
				ondrop: function (e) { e.preventDefault(); li.classList.remove('is-over'); moveTo(dragId, f.id); dragId = null; }
			}, [
				el('span', { class: 'twf-grip', 'aria-hidden': 'true' }, ['⋮⋮']),
				el('span', { class: 'twf-outline__label' }, [f.type === 'page_break' ? '— ' + fieldName(f) + ' —' : fieldName(f)]),
				el('span', { class: 'twf-outline__tags' }, [
					f.required ? el('span', { class: 'twf-tag', title: t('Obbligatorio') }, ['*']) : null,
					f.conditions ? el('span', { class: 'twf-tag twf-tag--cond', title: t('Ha una condizione') }, ['se']) : null,
					f.required_conditions ? el('span', { class: 'twf-tag twf-tag--cond', title: t('Obbligatorio solo in certi casi') }, ['*se']) : null,
					el('span', { class: 'twf-tag twf-tag--type' }, [typeLabel(f.type)])
				])
			]);
			ul.appendChild(li);
		});
		return ul;
	}

	function moveTo(fromId, toId) {
		if (!fromId || fromId === toId) { return; }
		var fields = state.def.fields, from = indexOfField(fromId), to = indexOfField(toId);
		if (from < 0 || to < 0) { return; }
		var item = fields.splice(from, 1)[0];
		fields.splice(to, 0, item);
		touch(); renderLeft();
	}

	function select(id, fromPreview) {
		state.selected = id;
		if (state.side !== 'outline') { state.side = 'outline'; }
		renderLeft();
		renderRight();
		if (!fromPreview) { postToFrame({ type: 'select', id: id }); }
	}

	function defaultsFor(type) {
		var f = { id: uniqueId(slug(typeLabel(type))), type: type, label: typeLabel(type), required: false };
		if (['select', 'radio', 'checkbox'].indexOf(type) !== -1) {
			f.options = [1, 2, 3].map(function (n) { return { label: t('Opzione') + ' ' + n, value: 'opzione_' + n, calc: '' }; });
		}
		if (type === 'upload') { f.extensions = ['pdf', 'jpg', 'png']; f.max_size_mb = 5; f.max_files = 1; }
		if (type === 'gdpr') { f.label = t('Ho letto l’informativa sulla privacy'); f.required = true; }
		if (type === 'calculation') { f.formula = ''; f.decimals = 2; }
		if (type === 'page_break') { f.label = t('Nuova pagina'); }
		if (type === 'name') { f.last = true; }
		if (type === 'html') { f.label = t('Testo informativo'); f.content = '<p>' + t('Scrivi qui il testo.') + '</p>'; }
		if (type === 'hidden') { f.default = ''; f.param = ''; }
		return f;
	}

	function addField(type) {
		var f = defaultsFor(type);
		var at = state.selected ? indexOfField(state.selected) + 1 : state.def.fields.length;
		state.def.fields.splice(at, 0, f);
		touch();
		state.side = 'outline';
		select(f.id, false);
		schedulePreview(true);
	}

	function removeField(id) {
		var f = fieldById(id);
		if (!f || !window.confirm(t('Eliminare il campo') + ' «' + fieldName(f) + '»?')) { return; }
		var i = indexOfField(id);
		state.def.fields.splice(i, 1);
		// Conditions and notifications that pointed to it are cleaned by the server on save; here we drop them too.
		state.def.fields.forEach(function (x) { cleanConditions(x, id); });
		(state.def.notifications || []).forEach(function (n) { cleanConditions(n, id); n.to_fields = (n.to_fields || []).filter(function (x) { return x !== id; }); if (n.reply_to_field === id) { n.reply_to_field = ''; } });
		var next = state.def.fields[i] || state.def.fields[i - 1];
		state.selected = next ? next.id : null;
		touch(); renderLeft(); renderRight(); schedulePreview(true);
	}

	function cleanConditions(owner, removedId) {
		['conditions', 'required_conditions'].forEach(function (prop) {
			if (!owner[prop]) { return; }
			owner[prop].rules = (owner[prop].rules || []).filter(function (r) { return r.field !== removedId; });
			if (!owner[prop].rules.length) { owner[prop] = null; }
		});
	}

	function duplicateField(id) {
		var f = fieldById(id);
		if (!f) { return; }
		var copy = clone(f);
		copy.id = uniqueId(f.id.replace(/_\d+$/, ''));
		copy.label = fieldName(f) + ' ' + t('(copia)');
		state.def.fields.splice(indexOfField(id) + 1, 0, copy);
		touch(); select(copy.id, false); schedulePreview(true);
	}

	function moveField(id, delta) {
		var i = indexOfField(id), j = i + delta;
		if (i < 0 || j < 0 || j >= state.def.fields.length) { return; }
		var tmp = state.def.fields[i]; state.def.fields[i] = state.def.fields[j]; state.def.fields[j] = tmp;
		touch(); renderLeft(); schedulePreview(true);
	}

	/* ---------------------------------------------------------------- field settings (right column) */

	function renderRight() {
		var right = els.right;
		clear(right);
		var f = state.selected ? fieldById(state.selected) : null;
		if (!f) {
			right.appendChild(el('div', { class: 'twf-emptybox' }, [el('h3', null, [t('Modifica un campo')]), el('p', null, [t('Clicca un campo nell’anteprima o nella lista “Struttura” per cambiarne testi e regole.')])]));
			return;
		}
		right.appendChild(el('div', { class: 'twf-fieldhead' }, [
			el('strong', null, [typeLabel(f.type)]),
			el('span', { class: 'twf-fieldhead__tools' }, [
				el('button', { type: 'button', class: 'button button-small', title: t('Sposta su'), onclick: function () { moveField(f.id, -1); } }, ['↑']),
				el('button', { type: 'button', class: 'button button-small', title: t('Sposta giù'), onclick: function () { moveField(f.id, 1); } }, ['↓']),
				el('button', { type: 'button', class: 'button button-small', onclick: function () { duplicateField(f.id); } }, [t('Duplica')]),
				el('button', { type: 'button', class: 'button button-small twf-danger', onclick: function () { removeField(f.id); } }, [t('Elimina')])
			])
		]));

		var labelHint = f.type === 'page_break' ? t('Titolo della pagina successiva') : null;
		var base = [textInput(f.type === 'html' ? t('Nome interno') : t('Testo del campo'), f, 'label', { hint: labelHint, onchange: refreshOutlineSoon })];
		if (f.type !== 'page_break' && f.type !== 'html' && f.type !== 'hidden') { base.push(areaInput(t('Spiegazione sotto il testo (facoltativa)'), f, 'description', { rows: 2 })); }
		if (TEXT_LIKE.indexOf(f.type) !== -1) { base.push(textInput(t('Testo di esempio nel campo'), f, 'placeholder')); }
		if (isInput(f.type) && ['gdpr', 'calculation', 'hidden'].indexOf(f.type) === -1) { base.push(checkInput(t('Obbligatorio'), f, 'required', { onchange: function () { refreshOutlineSoon(); renderRight(); } })); }
		if (isInput(f.type) && ['gdpr', 'hidden', 'calculation'].indexOf(f.type) === -1) { base.push(selectInput(t('Larghezza'), f, 'width', [['full', t('Tutta la riga')], ['half', t('Mezza riga (affiancato)')]])); }
		right.appendChild(section(t('Generale'), base));

		// Dynamic field: shown right after the basics and always open, so it is easy to find.
		if (f.type !== 'page_break') {
			right.appendChild(section(t('Campo dinamico (mostra solo se…)'), [conditionsEditor(f, f.id, function () { refreshOutlineSoon(); })], true));
		}
		// Required only in some cases (e.g. the phone is optional for the 3K and compulsory for the 10K).
		if (isInput(f.type) && ['gdpr', 'hidden', 'calculation'].indexOf(f.type) === -1) {
			right.appendChild(section(t('Obbligatorio solo se…'), [conditionsEditor(f, f.id, function () { refreshOutlineSoon(); }, {
				prop: 'required_conditions',
				kinds: ['require', 'optional'],
				toggle: t('Rendi questo campo obbligatorio o facoltativo in base a un’altra risposta'),
				actions: [t('Rendi obbligatorio'), t('Rendi facoltativo')],
				after: t('questo campo se'),
				hint: t('Esempio: il «Telefono» è facoltativo per la 3K e obbligatorio per la 10K. Lascia «Obbligatorio» spento e scegli «Rendi obbligatorio se Percorso è 10K», oppure accendilo e scegli «Rendi facoltativo se Percorso è 3K».'),
				note: function (c) {
					if (c.action === 'optional' && !f.required) { return t('Per «Rendi facoltativo» il campo deve essere «Obbligatorio» nelle impostazioni generali: ora non è obbligatorio, quindi questa regola non cambia nulla.'); }
					if (c.action !== 'optional' && f.required) { return t('Il campo è già sempre obbligatorio: questa regola non cambia nulla. Spegni «Obbligatorio» nelle impostazioni generali.'); }
					return '';
				}
			})], true));
		}
		var special = typeSettings(f);
		if (special.length) { right.appendChild(section(t('Opzioni di questo campo'), special)); }
		right.appendChild(section(t('Avanzate'), [textInput(t('Classe CSS (per i tecnici)'), f, 'css_class')], false));
	}

	var outlineTimer = null;
	function refreshOutlineSoon() { clearTimeout(outlineTimer); outlineTimer = setTimeout(renderLeft, 150); }

	function typeSettings(f) {
		var out = [];
		switch (f.type) {
			case 'text':
			case 'textarea':
				out.push(textInput(t('Lunghezza minima'), f, 'min_length', { type: 'number', min: 0 }));
				out.push(textInput(t('Lunghezza massima (0 = senza limite)'), f, 'max_length', { type: 'number', min: 0 }));
				break;
			case 'name':
				out.push(checkInput(t('Chiedi anche il cognome'), f, 'last', { onchange: function () { schedulePreview(true); } }));
				break;
			case 'address':
				out.push(checkInput(t('Chiedi anche il paese'), f, 'country', { onchange: function () { schedulePreview(true); } }));
				break;
			case 'number':
			case 'currency':
				out.push(textInput(t('Valore minimo'), f, 'min', { type: 'text' }));
				out.push(textInput(t('Valore massimo'), f, 'max', { type: 'text' }));
				out.push(textInput(t('Valore iniziale'), f, 'default', { type: 'text' }));
				break;
			case 'date':
				out.push(textInput(t('Data più vicina ammessa'), f, 'min_date', { type: 'date' }));
				out.push(textInput(t('Data più lontana ammessa'), f, 'max_date', { type: 'date' }));
				break;
			case 'select':
			case 'radio':
			case 'checkbox':
				out.push(optionsEditor(f));
				break;
			case 'upload':
				out.push(extensionsEditor(f));
				out.push(textInput(t('Dimensione massima per file (MB, da 1 a 25)'), f, 'max_size_mb', { type: 'number', min: 1, max: 25 }));
				out.push(textInput(t('Numero massimo di file (da 1 a 10)'), f, 'max_files', { type: 'number', min: 1, max: 10 }));
				break;
			case 'hidden':
				out.push(textInput(t('Valore'), f, 'default'));
				out.push(textInput(t('Prendi il valore dall’indirizzo della pagina'), f, 'param', { hint: t('Esempio: scrivi “fonte” e la pagina /contatti/?fonte=newsletter riempie il campo con “newsletter”.') }));
				break;
			case 'gdpr':
				out.push(areaInput(t('Testo del consenso (puoi mettere un link)'), f, 'content', { rows: 3, hint: t('Se lo lasci vuoto si usa il testo del campo.'), }));
				break;
			case 'html':
				out.push(areaInput(t('Testo da mostrare'), f, 'content', { rows: 6, hint: t('Puoi usare <strong>, <em>, <a href>, <br>, <ul>, <li>.') }));
				break;
			case 'calculation':
				out.push(formulaEditor(f));
				break;
		}
		return out;
	}

	function optionsEditor(f) {
		var box = el('div', { class: 'twf-options' });
		var focusIndex = -1;

		function grow(area) { area.style.height = 'auto'; area.style.height = Math.max(area.scrollHeight, 38) + 'px'; }
		function move(i, delta) {
			var j = i + delta;
			if (j < 0 || j >= f.options.length) { return; }
			var tmp = f.options[i]; f.options[i] = f.options[j]; f.options[j] = tmp;
			touch(); draw();
		}

		function card(opt, i, total) {
			var label = el('textarea', { rows: 1, class: 'twf-optcard__label', id: 'twf-opt-' + i, placeholder: t('Testo che vede chi compila'), 'aria-label': t('Testo dell’opzione') + ' ' + (i + 1),
				oninput: function (e) { opt.label = e.target.value.replace(/\s*\n\s*/g, ' '); touch(); grow(e.target); },
				onkeydown: function (e) { if (e.key === 'Enter') { e.preventDefault(); } } });
			label.value = opt.label || '';
			var calc = el('input', { type: 'text', inputmode: 'decimal', class: 'twf-optcard__calc', id: 'twf-optcalc-' + i, value: opt.calc || '', placeholder: t('es. 25'),
				oninput: function (e) { opt.calc = e.target.value; touch(); } });
			var head = el('div', { class: 'twf-optcard__head' }, [
				el('span', { class: 'twf-optcard__n', 'aria-hidden': 'true' }, [String(i + 1)]),
				el('span', { class: 'twf-optcard__tools' }, [
					el('button', { type: 'button', class: 'button button-small', title: t('Sposta su'), 'aria-label': t('Sposta su l’opzione') + ' ' + (i + 1), disabled: i === 0, onclick: function () { move(i, -1); } }, ['↑']),
					el('button', { type: 'button', class: 'button button-small', title: t('Sposta giù'), 'aria-label': t('Sposta giù l’opzione') + ' ' + (i + 1), disabled: i === total - 1, onclick: function () { move(i, 1); } }, ['↓']),
					el('button', { type: 'button', class: 'button button-small twf-danger', title: t('Elimina l’opzione'), 'aria-label': t('Elimina l’opzione') + ' ' + (i + 1), onclick: function () {
						if (f.options.length <= 1 && !window.confirm(t('È l’ultima opzione: il campo resterà senza scelte. Eliminarla?'))) { return; }
						f.options.splice(i, 1); touch(); draw();
					} }, ['×'])
				])
			]);
			var c = el('div', { class: 'twf-optcard' }, [
				head,
				el('div', { class: 'twf-optcard__body' }, [
					el('label', { class: 'twf-optcard__field', 'for': 'twf-opt-' + i }, [t('Testo'), label]),
					el('label', { class: 'twf-optcard__field twf-optcard__field--calc', 'for': 'twf-optcalc-' + i }, [t('Valore per i calcoli'), el('span', { class: 'twf-optcard__opt' }, [t('facoltativo')]), calc])
				])
			]);
			setTimeout(function () { grow(label); }, 0);
			return c;
		}

		function draw() {
			clear(box);
			var list = f.options || [];
			box.appendChild(el('p', { class: 'twf-hint twf-options__hint' }, [t('Una scheda per ogni scelta, nell’ordine in cui compaiono. Il «valore per i calcoli» serve ai totali e ai pagamenti (per esempio il prezzo: 25 per la 3 Km, 45 per la 10 Km): se non fai calcoli lascialo vuoto.')]));
			if (!list.length) { box.appendChild(el('p', { class: 'twf-optempty' }, [t('Nessuna scelta ancora: aggiungine una.')])); }
			list.forEach(function (opt, i) { box.appendChild(card(opt, i, list.length)); });
			box.appendChild(el('button', { type: 'button', class: 'button twf-optadd', onclick: function () {
				var n = (f.options || []).length + 1;
				var used = {}; (f.options || []).forEach(function (o) { used[o.value] = true; });
				var v = 'opzione_' + n; while (used[v]) { n++; v = 'opzione_' + n; }
				f.options = f.options || []; f.options.push({ label: t('Opzione') + ' ' + n, value: v, calc: '' });
				focusIndex = f.options.length - 1;
				touch(); draw();
			} }, ['+ ' + t('Aggiungi una scelta')]));
			if (focusIndex >= 0) {
				var target = box.querySelector('#twf-opt-' + focusIndex);
				focusIndex = -1;
				if (target) { target.focus(); target.select(); }
			}
		}
		draw();
		return box;
	}

	function extensionsEditor(f) {
		var box = el('div', { class: 'twf-ext' }, [el('p', { class: 'twf-label' }, [t('Tipi di file ammessi')])]);
		var current = f.extensions || [];
		D.extensions.forEach(function (ext) {
			var cb = el('input', { type: 'checkbox', onchange: function (e) {
				var set = (f.extensions || []).filter(function (x) { return x !== ext; });
				if (e.target.checked) { set.push(ext); }
				f.extensions = set; touch();
			} });
			cb.checked = current.indexOf(ext) !== -1;
			box.appendChild(el('label', { class: 'twf-extchk' }, [cb, ' .' + ext]));
		});
		box.appendChild(el('p', { class: 'twf-hint' }, [t('Per sicurezza i file eseguibili (php, exe, svg, html…) non sono mai ammessi.')]));
		return box;
	}

	function formulaEditor(f) {
		var wrap = el('div', { class: 'twf-formula' });
		var input = el('input', { type: 'text', value: f.formula || '', placeholder: t('Esempio: {quota} * {persone}'), oninput: function (e) { f.formula = e.target.value; touch(); } });
		wrap.appendChild(el('label', { class: 'twf-label' }, [t('Formula'), input]));
		var picker = el('select', { 'aria-label': t('Inserisci un campo'), onchange: function (e) {
			if (!e.target.value) { return; }
			var pos = input.selectionStart === null ? input.value.length : input.selectionStart;
			input.value = input.value.slice(0, pos) + '{' + e.target.value + '}' + input.value.slice(pos);
			f.formula = input.value; touch(); e.target.value = ''; input.focus();
		} }, [el('option', { value: '' }, [t('Inserisci un campo…')])].concat(
			inputFields(f.id).filter(function (x) { return ['number', 'currency', 'select', 'radio', 'checkbox', 'calculation'].indexOf(x.type) !== -1; }).map(function (x) { return el('option', { value: x.id }, [fieldName(x)]); })
		));
		wrap.appendChild(picker);
		wrap.appendChild(el('p', { class: 'twf-hint' }, [t('Puoi usare + − * / %, le parentesi e round(), floor(), ceil(), abs(), min(), max(). Le scelte con “valore per i calcoli” contano per quel valore.')]));
		wrap.appendChild(textInput(t('Cifre decimali'), f, 'decimals', { type: 'number', min: 0, max: 4 }));
		return wrap;
	}

	/* ---------------------------------------------------------------- conditions editor (fields and notifications) */

	function conditionsEditor(owner, selfId, onChange, opts) {
		opts = opts || {};
		var prop = opts.prop || 'conditions';
		var kinds = opts.kinds || ['show', 'hide'];
		var box = el('div', { class: 'twf-cond' });
		var candidates = function () { return inputFields(selfId); };

		function change() { touch(); if (onChange) { onChange(); } }

		function draw() {
			clear(box);
			var c = owner[prop];
			var can = candidates().length > 0;
			var cb = el('input', { type: 'checkbox', onchange: function (e) {
				if (e.target.checked) {
					var first = candidates()[0];
					owner[prop] = { action: kinds[0], match: 'all', rules: [{ field: first.id, op: 'is', value: '' }] };
				} else { owner[prop] = null; }
				change(); draw();
			} });
			cb.checked = !!c; cb.disabled = !can;
			box.appendChild(el('label', { class: 'twf-condtoggle' }, [cb, ' ', opts.toggle || (selfId ? t('Mostra o nascondi questo campo in base a un’altra risposta') : t('Invia questa e-mail solo se…'))]));
			if (!can) { box.appendChild(el('p', { class: 'twf-hint' }, [t('Servono altri campi nel modulo per impostare una condizione.')])); return; }
			if (!c) {
				if (opts.hint) { box.appendChild(el('p', { class: 'twf-hint' }, [opts.hint])); }
				else if (selfId) { box.appendChild(el('p', { class: 'twf-hint' }, [t('Esempio: il campo «Ragione sociale» compare solo se «Tipo» è «Azienda». Un campo nascosto non si compila, non è obbligatorio e non finisce nelle risposte.')])); }
				return;
			}

			var head = el('div', { class: 'twf-condhead' }, []);
			if (selfId || opts.actions) {
				var labels = opts.actions || [t('Mostra'), t('Nascondi')];
				head.appendChild(el('select', { onchange: function (e) { c.action = e.target.value; change(); draw(); } }, [
					el('option', { value: kinds[0], selected: c.action !== kinds[1] }, [labels[0]]), el('option', { value: kinds[1], selected: c.action === kinds[1] }, [labels[1]])
				]));
				head.appendChild(document.createTextNode(' ' + (opts.actions ? (opts.after || t('se')) : t('questo campo se')) + ' '));
			}
			if (c.rules.length > 1) {
				head.appendChild(el('select', { onchange: function (e) { c.match = e.target.value; change(); } }, [
					el('option', { value: 'all', selected: c.match !== 'any' }, [t('tutte le')]), el('option', { value: 'any', selected: c.match === 'any' }, [t('almeno una delle')])
				]));
				head.appendChild(document.createTextNode(' ' + t('condizioni sono vere:')));
			} else if (!selfId && !opts.actions) {
				head.appendChild(document.createTextNode(t('la condizione è vera:')));
			}
			box.appendChild(head);

			c.rules.forEach(function (rule, i) {
				var refField = fieldById(rule.field);
				var fieldSel = el('select', { 'aria-label': t('Campo'), onchange: function (e) { rule.field = e.target.value; rule.value = ''; change(); draw(); } },
					candidates().map(function (x) { return el('option', { value: x.id, selected: x.id === rule.field }, [fieldName(x)]); }));
				var opSel = el('select', { 'aria-label': t('Confronto'), onchange: function (e) { rule.op = e.target.value; change(); draw(); } },
					Object.keys(D.operators).map(function (op) { return el('option', { value: op, selected: op === rule.op }, [D.operators[op]]); }));
				var valueCtl = null;
				if (rule.op !== 'empty' && rule.op !== 'not_empty') {
					if (refField && refField.options && refField.options.length && ['is', 'is_not'].indexOf(rule.op) !== -1) {
						valueCtl = el('select', { 'aria-label': t('Valore'), onchange: function (e) { rule.value = e.target.value; change(); } },
							[el('option', { value: '' }, ['—'])].concat(refField.options.map(function (o) { return el('option', { value: o.value, selected: o.value === rule.value }, [o.label]); })));
					} else {
						valueCtl = el('input', { type: 'text', value: rule.value || '', 'aria-label': t('Valore'), placeholder: t('Valore'), oninput: function (e) { rule.value = e.target.value; change(); } });
					}
				}
				box.appendChild(el('div', { class: 'twf-rule' }, [fieldSel, opSel, valueCtl,
					el('button', { type: 'button', class: 'button button-small', 'aria-label': t('Togli la condizione'), onclick: function () { c.rules.splice(i, 1); if (!c.rules.length) { owner[prop] = null; } change(); draw(); } }, ['×'])]));
			});
			if (opts.note) {
				var note = opts.note(c);
				if (note) { box.appendChild(el('p', { class: 'twf-hint twf-hint--warn' }, [note])); }
			}
			if (c.rules.length < 20) {
				box.appendChild(el('button', { type: 'button', class: 'button button-small', onclick: function () {
					c.rules.push({ field: candidates()[0].id, op: 'is', value: '' }); change(); draw();
				} }, ['+ ' + t('Aggiungi una condizione')]));
			}
		}
		draw();
		return box;
	}

	/* ---------------------------------------------------------------- Notifications tab */

	function emailFields() { return (state.def.fields || []).filter(function (f) { return f.type === 'email'; }); }

	function renderNotificationsTab() {
		var wrap = el('div', { class: 'twf-page' });
		wrap.appendChild(el('h2', null, [t('Notifiche e-mail')]));
		wrap.appendChild(el('p', { class: 'twf-lead' }, [t('Le e-mail che partono quando qualcuno invia il modulo. Ogni destinatario riceve la sua e-mail separata: gli indirizzi non si vedono tra loro.')]));
		var list = el('div', { class: 'twf-notifs' });
		wrap.appendChild(list);

		function draw() {
			clear(list);
			var items = state.def.notifications || [];
			if (!items.length) { list.appendChild(el('div', { class: 'twf-emptybox' }, [el('p', null, [t('Non parte nessuna e-mail. Aggiungi un avviso per te, e una conferma per chi compila.')])])); }
			items.forEach(function (n, i) { list.appendChild(notificationCard(n, i, draw)); });
		}
		draw();
		wrap.appendChild(el('p', null, [
			el('button', { type: 'button', class: 'button button-primary', onclick: function () {
				var admin = '';
				state.def.notifications = state.def.notifications || [];
				state.def.notifications.push({ id: uniqueId('notifica'), name: t('Nuova e-mail'), enabled: true, to: admin ? [admin] : [], to_fields: [], subject: '', body: '{all_fields}', reply_to_field: '', attach_files: false, attach_pdf: false, conditions: null });
				touch(); draw();
			} }, ['+ ' + t('Aggiungi un’e-mail')])
		]));
		els.body.appendChild(wrap);
	}

	function notificationCard(n, index, redraw) {
		var card = el('div', { class: 'twf-card' });
		card.appendChild(el('div', { class: 'twf-card__head' }, [
			el('input', { type: 'text', class: 'twf-card__name', value: n.name, 'aria-label': t('Nome dell’e-mail'), oninput: function (e) { n.name = e.target.value; touch(); } }),
			el('label', { class: 'twf-inline' }, [(function () { var c = el('input', { type: 'checkbox', onchange: function (e) { n.enabled = e.target.checked; touch(); } }); c.checked = n.enabled !== false; return c; })(), ' ' + t('Attiva')]),
			el('button', { type: 'button', class: 'button button-small twf-danger', onclick: function () { if (window.confirm(t('Eliminare questa e-mail?'))) { state.def.notifications.splice(index, 1); touch(); redraw(); } } }, [t('Elimina')])
		]));

		var toArea = el('textarea', { rows: 2, placeholder: t('un indirizzo per riga'), oninput: function (e) {
			n.to = e.target.value.split(/[\n,;]+/).map(function (s) { return s.trim(); }).filter(Boolean); touch();
		} });
		toArea.value = (n.to || []).join('\n');
		card.appendChild(row(t('A chi la mandi (indirizzi fissi)'), toArea));

		var ef = emailFields();
		if (ef.length) {
			var chk = el('div', { class: 'twf-row' }, [el('p', { class: 'twf-label' }, [t('E anche all’indirizzo scritto da chi compila in:')])]);
			ef.forEach(function (f) {
				var cb = el('input', { type: 'checkbox', onchange: function (e) {
					var set = (n.to_fields || []).filter(function (x) { return x !== f.id; });
					if (e.target.checked) { set.push(f.id); }
					n.to_fields = set; touch();
				} });
				cb.checked = (n.to_fields || []).indexOf(f.id) !== -1;
				chk.appendChild(el('label', { class: 'twf-extchk' }, [cb, ' ' + fieldName(f)]));
			});
			card.appendChild(chk);
			var reply = el('select', { onchange: function (e) { n.reply_to_field = e.target.value; touch(); } },
				[el('option', { value: '' }, [t('— nessuno —')])].concat(ef.map(function (f) { return el('option', { value: f.id, selected: n.reply_to_field === f.id }, [fieldName(f)]); })));
			card.appendChild(row(t('Quando rispondi, scrivi a'), reply));
		} else {
			card.appendChild(el('p', { class: 'twf-hint' }, [t('Aggiungi un campo “E-mail” al modulo per poter mandare una conferma a chi compila.')]));
		}

		var subject = el('input', { type: 'text', value: n.subject || '', placeholder: t('Oggetto dell’e-mail'), oninput: function (e) { n.subject = e.target.value; touch(); } });
		var body = el('textarea', { rows: 7, oninput: function (e) { n.body = e.target.value; touch(); } });
		body.value = n.body || '';
		card.appendChild(row(t('Oggetto'), subject));
		card.appendChild(row(t('Messaggio'), body));
		card.appendChild(tagPicker(function (tag) {
			var pos = body.selectionStart === null ? body.value.length : body.selectionStart;
			body.value = body.value.slice(0, pos) + tag + body.value.slice(pos);
			n.body = body.value; touch(); body.focus();
		}));

		card.appendChild(el('div', { class: 'twf-row' }, [el('p', { class: 'twf-label' }, [t('Allegati')])]));
		card.appendChild(checkInput(t('I file caricati da chi compila'), n, 'attach_files'));
		if (!D.features.pdf) {
			card.appendChild(el('p', { class: 'twf-hint' }, [t('Il PDF con le risposte è spento per tutto il sito: attivalo in '),
				el('a', { href: D.features.url, target: '_blank', rel: 'noopener' }, [t('TW Formulari → Impostazioni')]), '.']));
		} else if (state.def.settings.pdf) {
			card.appendChild(checkInput(state.def.settings.pdf_template === 'voucher' ? t('Il buono regalo in PDF') : t('Un PDF con tutte le risposte'), n, 'attach_pdf'));
		} else {
			card.appendChild(el('p', { class: 'twf-hint' }, [t('Vuoi allegare anche un PDF con le risposte? È una funzione facoltativa: accendila in '),
				el('a', { href: '#', onclick: function (e) { e.preventDefault(); state.tab = 'settings'; renderTabs(); renderBody(); } }, [t('Impostazioni → Funzioni facoltative')]), '.']));
		}
		card.appendChild(section(t('Condizione'), [conditionsEditor(n, null, null)], !!n.conditions));
		return card;
	}

	function tagPicker(insert) {
		var opts = [el('option', { value: '' }, [t('Inserisci un dato nel messaggio…')]),
			el('option', { value: '{all_fields}' }, [t('Tutte le risposte (tabella)')]),
			el('option', { value: '{form_title}' }, [t('Titolo del modulo')]),
			el('option', { value: '{date}' }, [t('Data e ora dell’invio')]),
			el('option', { value: '{entry_id}' }, [t('Numero della compilazione')])];
		inputFields().forEach(function (f) { opts.push(el('option', { value: '{' + f.id + '}' }, [t('Risposta:') + ' ' + fieldName(f)])); });
		return el('div', { class: 'twf-row' }, [el('select', { 'aria-label': t('Inserisci un dato'), onchange: function (e) { if (e.target.value) { insert(e.target.value); e.target.value = ''; } } }, opts)]);
	}

	/* ---------------------------------------------------------------- Confirmation tab */

	function renderConfirmationTab() {
		var c = state.def.confirmation;
		var wrap = el('div', { class: 'twf-page' }, [el('h2', null, [t('Dopo l’invio')]), el('p', { class: 'twf-lead' }, [t('Cosa vede chi ha compilato il modulo.')])]);
		var box = el('div', { class: 'twf-card' });
		function draw() {
			clear(box);
			[['message', t('Mostra un messaggio al posto del modulo')], ['message_keep', t('Mostra un messaggio e lascia il modulo (per inviarne un altro)')], ['redirect', t('Porta a un’altra pagina')]].forEach(function (o) {
				var r = el('input', { type: 'radio', name: 'twf-conf', value: o[0], onchange: function () { c.type = o[0]; touch(); draw(); } });
				r.checked = c.type === o[0];
				box.appendChild(el('label', { class: 'twf-radio' }, [r, ' ' + o[1]]));
			});
			if (c.type === 'redirect') {
				box.appendChild(textInput(t('Indirizzo della pagina'), c, 'url', { type: 'url', placeholder: 'https://', hint: t('Se resta vuoto si mostra il messaggio.') }));
			} else {
				box.appendChild(areaInput(t('Messaggio'), c, 'message', { rows: 5, hint: t('Puoi usare <strong>, <em>, <a href>, <br>.') }));
				box.appendChild(textInput(t('Nascondi il messaggio dopo quanti secondi (0 = mai)'), c, 'autoclose', { type: 'number', min: 0, max: 600 }));
			}
		}
		draw();
		wrap.appendChild(box);
		els.body.appendChild(wrap);
	}

	/* ---------------------------------------------------------------- Settings tab */

	function renderSettingsTab() {
		var s = state.def.settings;
		var wrap = el('div', { class: 'twf-page' }, [el('h2', null, [t('Impostazioni')])]);

		wrap.appendChild(el('div', { class: 'twf-card' }, [
			el('h3', null, [t('Aspetto')]),
			selectInput(t('Stile'), s, 'style', [['default', t('Predefinito')], ['flat', t('Piatto')], ['material', t('Linee (material)')]]),
			(function () {
				var color = el('input', { type: 'color', value: s.accent || '#2563eb', oninput: function (e) { s.accent = e.target.value; touch(); } });
				return row(t('Colore dei pulsanti e dei campi selezionati'), color);
			})(),
			textInput(t('Testo del pulsante di invio'), s, 'submit_label'),
			section(t('CSS personalizzato (per i tecnici)'), [areaInput(t('CSS'), s, 'custom_css', { rows: 6 })], false)
		]));

		wrap.appendChild(el('div', { class: 'twf-card' }, [
			el('h3', null, [t('Compilazioni')]),
			checkInput(t('Salva le compilazioni nel sito'), s, 'store_entries', { hint: t('Se lo spegni, le risposte arrivano solo per e-mail e non restano nel database.') }),
			textInput(t('Conserva le compilazioni per quanti giorni (0 = per sempre)'), s, 'retention_days', { type: 'number', min: 0, max: 3650, hint: t('Passato questo tempo vengono eliminate da sole, con i loro file.') }),
			textInput(t('Numero massimo di risposte (0 = senza limite)'), s, 'max_entries', { type: 'number', min: 0 }),
			(function () {
				var input = el('input', { type: 'datetime-local', value: (s.expire_at || '').replace(' ', 'T'), oninput: function (e) { s.expire_at = e.target.value ? e.target.value.replace('T', ' ') : ''; touch(); } });
				return row(t('Chiudi il modulo dopo questa data (facoltativo)'), input);
			})()
		]));

		wrap.appendChild(el('div', { class: 'twf-card' }, [
			el('h3', null, [t('Protezione dallo spam')]),
			checkInput(t('Campo trappola nascosto (consigliato)'), s, 'honeypot'),
			textInput(t('Tempo minimo di compilazione, in secondi'), s, 'min_seconds', { type: 'number', min: 0, max: 60, hint: t('Chi invia prima è un programma automatico.') }),
			textInput(t('Invii massimi per persona in un’ora (0 = nessun limite)'), s, 'rate_limit', { type: 'number', min: 0, max: 1000 }),
			(function () {
				var ok = !!(D.captcha && D.captcha.available);
				var cb = el('input', { type: 'checkbox', onchange: function (e) { s.captcha = e.target.checked ? 'recaptcha' : 'none'; touch(); renderBody(); } });
				cb.checked = s.captcha === 'recaptcha';
				var out = el('div', { class: 'twf-row twf-row--check' }, [el('label', null, [cb, ' ', t('Verifica anti-spam reCAPTCHA (quella di ticinoWEB CMS)')])]);
				var note = ok
					? el('p', { class: 'twf-hint' }, [t('Usa le chiavi e la soglia già impostate in ticinoWEB CMS → reCAPTCHA: nessun dato da inserire qui.')])
					: el('p', { class: 'twf-warn' }, [t('Mancano le chiavi del reCAPTCHA: inseriscile in '), el('a', { href: D.captcha ? D.captcha.url : '#', target: '_blank', rel: 'noopener' }, [t('ticinoWEB CMS → reCAPTCHA')]), t(', poi la protezione parte da sola.')]);
				return el('div', null, [out, note]);
			})()
		]));

		wrap.appendChild(el('div', { class: 'twf-card' }, [
			el('h3', null, [t('Funzioni facoltative')]),
			D.features.pdf
				? checkInput(t('PDF con le risposte'), s, 'pdf', { hint: t('Quando è acceso, nella scheda “Notifiche e-mail” compare la scelta di allegare alle e-mail un PDF con tutte le risposte (con il logo e i dati della scheda PDF di “TW Formulari”). Se resta spento, il PDF non viene mai creato.'), onchange: renderBody })
				: el('p', { class: 'twf-hint' }, [t('Il PDF con le risposte è spento per tutto il sito. Per usarlo, attivalo in '), el('a', { href: D.features.url, target: '_blank', rel: 'noopener' }, [t('TW Formulari → Impostazioni')]), '.']),
			D.features.pdf && s.pdf
				? selectInput(t('Che PDF creare'), s, 'pdf_template', [['summary', t('Riepilogo di tutte le risposte')], ['voucher', t('Buono regalo da stampare')]], {
					hint: t('Il buono regalo mostra il logo del sito, il titolo, l’importo pagato, la dedica (il primo campo di testo lungo), chi lo regala (il primo campo Nome), il numero della compilazione e la data.'),
					onchange: renderBody
				})
				: null,
			D.features.pdf && s.pdf && s.pdf_template === 'voucher'
				? textInput(t('Titolo sul buono'), s, 'pdf_title', { placeholder: t('Buono regalo'), hint: t('Per esempio «Buono regalo» o lo stesso titolo in più lingue.') })
				: null,
			D.features.pdf && s.pdf && s.pdf_template === 'voucher'
				? areaInput(t('Condizioni in fondo al buono (facoltativo)'), s, 'pdf_note', { rows: 3, placeholder: t('Per esempio: valido per pranzi e cene, da presentare al momento del pagamento.') })
				: null,
			D.features.pdf && s.pdf && s.pdf_template === 'voucher'
				? (function () {
					var color = el('input', { type: 'color', value: s.pdf_color || s.accent || '#b68745', oninput: function (e) { s.pdf_color = e.target.value; touch(); } });
					return row(t('Colore del buono'), color, t('Colore dell’importo, del titolo e della fascia accanto alla foto.'));
				})()
				: null,
			D.features.pdf && s.pdf && s.pdf_template === 'voucher'
				? selectInput(t('Grafica accanto al testo (se non c’è una foto)'), s, 'pdf_graphic', [['gift', t('Pacco regalo')], ['flower', t('Fiore con doppio cerchio')]], { onchange: renderBody })
				: null,
			D.features.pdf && s.pdf && s.pdf_template === 'voucher' && s.pdf_graphic === 'flower'
				? (function () {
					var box = el('div');
					var names = [t('Cerchi e stelline'), t('Petali'), t('Petali alterni')];
					// Sfumatura verso il bianco (come i colori automatici del PDF), da cui partire.
					function tint(hex, amount) {
						var n = parseInt(hex.slice(1), 16), out = '#';
						[(n >> 16) & 255, (n >> 8) & 255, n & 255].forEach(function (v) { out += ('0' + Math.round(v + (255 - v) * amount).toString(16)).slice(-2); });
						return out;
					}
					function paint() {
						box.innerHTML = '';
						var list = Array.isArray(s.pdf_colors) ? s.pdf_colors : [];
						if (!list.length) {
							box.appendChild(el('p', { class: 'twf-hint' }, [t('Colori automatici: sfumature del colore del buono.')]));
							box.appendChild(el('button', { type: 'button', class: 'button', onclick: function () { var base = s.pdf_color || s.accent || '#b68745'; s.pdf_colors = [tint(base, 0.55), tint(base, 0.35), tint(base, 0.7)]; touch(); paint(); } }, [t('Scegli i colori')]));
							return;
						}
						names.forEach(function (name, i) {
							var input = el('input', { type: 'color', value: list[i] || '#ffffff', oninput: function (e) { s.pdf_colors[i] = e.target.value; touch(); } });
							box.appendChild(el('label', { style: 'display:inline-flex;align-items:center;gap:6px;margin-right:14px' }, [input, name]));
						});
						box.appendChild(el('button', { type: 'button', class: 'button-link', style: 'margin-left:6px', onclick: function () { s.pdf_colors = []; touch(); paint(); } }, [t('Torna ai colori automatici')]));
					}
					paint();
					return row(t('Colori della decorazione (facoltativi)'), box, t('Senza foto, il buono ha a sinistra un fiore con un doppio cerchio sul colore del buono: qui scegli i colori, per esempio quelli del tuo logo.'));
				})()
				: null,
			D.features.pdf && s.pdf && s.pdf_template === 'voucher'
				? (function () {
					var preview = el('div', { class: 'twf-pdf-photo' });
					function paint() {
						preview.innerHTML = '';
						if (s.pdf_image && D.pdfImage) {
							preview.appendChild(el('img', { src: D.pdfImage, alt: '', style: 'max-width:220px;height:auto;display:block;border-radius:6px;margin-bottom:8px' }));
						} else {
							preview.appendChild(el('p', { class: 'twf-hint' }, [t('Nessuna foto: al suo posto c’è la grafica scelta qui sopra.')]));
						}
					}
					var choose = el('button', { type: 'button', class: 'button', onclick: function () {
						if (!window.wp || !wp.media) { return; }
						var frame = wp.media({ title: t('Foto del buono regalo'), button: { text: t('Usa questa foto') }, library: { type: 'image' }, multiple: false });
						frame.on('select', function () {
							var a = frame.state().get('selection').first().toJSON();
							s.pdf_image = a.id;
							D.pdfImage = (a.sizes && (a.sizes.medium || a.sizes.full) || a).url;
							touch(); paint();
						});
						frame.open();
					} }, [t('Scegli una foto')]);
					var remove = el('button', { type: 'button', class: 'button-link', style: 'margin-left:10px', onclick: function () { s.pdf_image = 0; D.pdfImage = ''; touch(); paint(); } }, [t('Togli la foto')]);
					paint();
					return row(t('Foto del buono (facoltativa)'), el('div', null, [preview, choose, remove]), t('Una foto del locale o di un piatto: occupa la parte sinistra del buono.'));
				})()
				: null
		]));

		els.body.appendChild(wrap);
	}

	/* ---------------------------------------------------------------- Payment tab */

	function renderPaymentTab() {
		var p = state.def.payment, s = state.def.settings;
		var st = D.stripe || {};
		var wrap = el('div', { class: 'twf-page' }, [
			el('h2', null, [t('Pagamento')]),
			el('p', { class: 'twf-lead' }, [t('Chiedi un pagamento insieme alla compilazione: online con carta, Apple Pay, Google Pay e TWINT (Stripe) e, se vuoi, con bonifico bancario o altri metodi. L’importo lo calcola sempre il sito, partendo dalle risposte.')])
		]);

		var status;
		if (!D.features.payments) {
			status = el('p', { class: 'twf-warn' }, [t('I pagamenti con Stripe sono spenti per tutto il sito. '), el('a', { href: D.features.url, target: '_blank', rel: 'noopener' }, [t('Attivali in TW Formulari → Impostazioni')]), '.']);
		} else if (!st.configured) {
			status = el('p', { class: 'twf-warn' }, [t('Stripe non è ancora configurato su questo sito. '), el('a', { href: st.url || '#', target: '_blank', rel: 'noopener' }, [t('Inserisci le chiavi in TW Formulari → Pagamenti')]), '.']);
		} else {
			status = el('p', { class: 'twf-hint' }, [st.mode === 'live' ? t('Stripe è collegato con chiavi REALI: i pagamenti addebitano davvero.') : t('Stripe è collegato con chiavi di PROVA: nessun addebito reale.')]);
		}

		var card = el('div', { class: 'twf-card' }, [
			el('h3', null, [t('Stripe')]), status,
			checkInput(t('Chiedi un pagamento con questo modulo'), p, 'enabled', { onchange: function () {
				if (p.enabled && (!s.submit_label || s.submit_label === t('Invia') || s.submit_label === 'Invia')) { s.submit_label = t('Paga e invia'); }
				renderBody();
			} })
		]);
		wrap.appendChild(card);

		if (p.enabled) {
			var amountFields = (state.def.fields || []).filter(function (f) {
				return p.mode === 'calculation' ? f.type === 'calculation' : ['number', 'currency', 'calculation', 'select', 'radio', 'checkbox'].indexOf(f.type) !== -1;
			});
			var fieldChoices = [['', t('— scegli un campo —')]].concat(amountFields.map(function (f) { return [f.id, (f.label || f.id) + ' (' + (D.types[f.type] || f.type) + ')']; }));
			var emailChoices = [['', t('— nessuno —')]].concat(emailFields().map(function (f) { return [f.id, f.label || f.id]; }));

			var amountCard = el('div', { class: 'twf-card' }, [
				el('h3', null, [t('Quanto si paga')]),
				selectInput(t('Valuta'), p, 'currency', [['CHF', 'CHF — franco svizzero'], ['EUR', 'EUR — euro'], ['USD', 'USD — dollaro'], ['GBP', 'GBP — sterlina']], { hint: t('TWINT funziona solo in franchi svizzeri (CHF).') }),
				selectInput(t('L’importo è'), p, 'mode', [['fixed', t('Fisso, sempre lo stesso')], ['calculation', t('Il risultato di un campo “Calcolo”')], ['field', t('Il valore di un campo (numero, importo, scelta con prezzo)')]], { onchange: function () { p.amount_field = ''; renderBody(); } })
			]);
			if (p.mode === 'fixed') {
				amountCard.appendChild(textInput(t('Importo da pagare'), p, 'amount', { type: 'number', min: 0.5, step: '0.01', placeholder: '50.00' }));
			} else {
				amountCard.appendChild(selectInput(t('Campo che contiene l’importo'), p, 'amount_field', fieldChoices, {
					hint: p.mode === 'calculation' ? t('Crea prima un campo “Calcolo” nella scheda Campi (ad esempio quantità × prezzo).') : t('Per le scelte (menu, pulsanti) conta il “valore per i calcoli” di ogni opzione.')
				}));
				if (!amountFields.length) { amountCard.appendChild(el('p', { class: 'twf-warn' }, [t('Non c’è ancora nessun campo adatto: aggiungilo nella scheda Campi.')])); }
			}
			amountCard.appendChild(textInput(t('Importo minimo (facoltativo)'), p, 'min_amount', { type: 'number', min: 0, step: '0.01' }));
			amountCard.appendChild(textInput(t('Importo massimo (facoltativo)'), p, 'max_amount', { type: 'number', min: 0, step: '0.01' }));
			wrap.appendChild(amountCard);

			// Which ways to pay this form offers: Stripe and/or the manual methods of the site (bank transfer…).
			var allMethods = (D.methods && D.methods.list) || [];
			if (!p.methods || !p.methods.length) { p.methods = ['stripe']; }
			var allOn = p.methods.indexOf('*') !== -1;
			var methodsCard = el('div', { class: 'twf-card' }, [
				el('h3', null, [t('Come si può pagare')]),
				(function () {
					var cbAll = el('input', { type: 'checkbox', onchange: function (e) {
						p.methods = e.target.checked ? ['*'] : allMethods.filter(function (x) { return x.ready; }).map(function (x) { return x.id; });
						if (!p.methods.length) { p.methods = ['stripe']; }
						touch(); schedulePreview(true); renderBody();
					} });
					cbAll.checked = allOn;
					return el('div', { class: 'twf-row twf-row--check' }, [el('label', null, [cbAll, ' ', el('strong', null, [t('Tutti i metodi attivi in TW Formulari → Pagamenti (consigliato)')])])]);
				})(),
				el('p', { class: 'twf-hint' }, [allOn ? t('Chi compila vede ogni metodo attivo: se ne accendi o aggiungi uno nella pagina Pagamenti, compare da solo anche qui.') : t('Scegli a mano quali offrire.')]),
				el('p', { class: 'twf-hint' }, [t('Spunta i modi che questo modulo offre. Se ne offri più d’uno, chi compila sceglie come pagare. Con il bonifico (o un altro metodo manuale) il modulo si invia subito e la compilazione resta «in attesa» finché non la segni come pagata.')])
			]);
			allMethods.forEach(function (m) {
				var cb = el('input', { type: 'checkbox', onchange: function (e) {
					var list = (p.methods || []).filter(function (id) { return id !== m.id; });
					if (e.target.checked) { list.push(m.id); }
					p.methods = allMethods.map(function (x) { return x.id; }).filter(function (id) { return list.indexOf(id) !== -1; });
					touch(); schedulePreview(true); renderBody();
				} });
				cb.checked = allOn ? !!m.ready : p.methods.indexOf(m.id) !== -1;
				if (allOn) { cb.disabled = true; }
				methodsCard.appendChild(el('div', { class: 'twf-row twf-row--check' }, [el('label', null, [cb, ' ', m.label + (m.note ? ' (' + m.note + ')' : '')])]));
			});
			if (!allOn && !p.methods.length) { methodsCard.appendChild(el('p', { class: 'twf-warn' }, [t('Scegli almeno un metodo: senza, si usa Stripe.')])); }
			if (allMethods.length < 2) {
				methodsCard.appendChild(el('p', { class: 'twf-hint' }, [t('Per aggiungere il bonifico bancario o altri metodi vai in '), el('a', { href: D.methods.url, target: '_blank', rel: 'noopener' }, [t('TW Formulari → Pagamenti')]), '.']));
			} else {
				methodsCard.appendChild(el('p', { class: 'twf-hint' }, [t('Aggiungi o modifica i metodi in '), el('a', { href: D.methods.url, target: '_blank', rel: 'noopener' }, [t('TW Formulari → Pagamenti')]), '.']));
			}
			wrap.appendChild(methodsCard);

			wrap.appendChild(el('div', { class: 'twf-card' }, [
				el('h3', null, [t('Quando si paga online')]),
				el('p', { class: 'twf-hint' }, [t('Di norma il pagamento è sempre richiesto. Se il modulo offre anche altri modi di pagare (contanti, bonifico, TWINT a mano), puoi chiedere il pagamento online solo in certi casi: negli altri il modulo si invia senza pagamento.')]),
				conditionsEditor(p, null, null, {
					toggle: t('Chiedi il pagamento online solo in certi casi'),
					actions: [t('Chiedi il pagamento'), t('Non chiedere il pagamento')],
					hint: t('Esempio: non chiedere il pagamento se «Metodo di pagamento» è «Contanti». Attenzione: chi compila sceglie la risposta, quindi usa questa regola solo per modi di pagare che controlli tu.')
				})
			]));

			wrap.appendChild(el('div', { class: 'twf-card' }, [
				el('h3', null, [t('Dettagli')]),
				textInput(t('Descrizione sul pagamento'), p, 'description', { placeholder: t('Ad esempio: Iscrizione all’evento'), hint: t('Compare nella ricevuta e nell’elenco pagamenti di Stripe. Se la lasci vuota si usa il titolo del modulo. Puoi usare {form_title}, {entry_id}, {site_name}.') }),
				selectInput(t('Invia la ricevuta di Stripe a questo indirizzo'), p, 'email_field', emailChoices, { hint: t('Stripe invia le ricevute solo con chiavi reali e se le ricevute sono attive nel suo pannello.') })
			]));

			wrap.appendChild(el('div', { class: 'twf-card' }, [
				el('h3', null, [t('Cosa succede')]),
				el('ul', { class: 'twf-list' }, [
					el('li', null, [t('La compilazione viene salvata “in attesa di pagamento” e le e-mail partono solo a pagamento riuscito, verificato da Stripe.')]),
					el('li', null, [t('Le compilazioni di moduli con pagamento vengono sempre salvate nel sito (serve a confermarle).')]),
					el('li', null, [t('Chi non completa il pagamento non lascia traccia: dopo 3 giorni la compilazione e i suoi file vengono eliminati. Un pagamento rifiutato resta visibile come “non riuscito”.')]),
					el('li', null, [t('Nelle e-mail puoi usare {payment_amount} per l’importo pagato.')])
				])
			]));
		}
		els.body.appendChild(wrap);
	}

	/* ---------------------------------------------------------------- JSON tab */

	function renderJsonTab() {
		var area = el('textarea', { class: 'twf-json', rows: 28, spellcheck: 'false' });
		area.value = JSON.stringify(state.def, null, 2);
		var msg = el('p', { class: 'twf-hint' });
		var wrap = el('div', { class: 'twf-page' }, [
			el('h2', null, [t('Avanzate: struttura in JSON')]),
			el('p', { class: 'twf-lead' }, [t('La descrizione completa del modulo. Serve per copiarlo su un altro sito o per modifiche da tecnici. Dopo “Applica” ricordati di salvare.')]),
			area, msg,
			el('button', { type: 'button', class: 'button', onclick: function () {
				try {
					var parsed = JSON.parse(area.value);
					if (!parsed || typeof parsed !== 'object' || !Array.isArray(parsed.fields)) { throw new Error(t('Manca l’elenco dei campi.')); }
					state.def = parsed; state.selected = null; touch(true);
					msg.textContent = t('Applicato. Controlla nella scheda Campi e poi salva.');
				} catch (e) { msg.textContent = t('JSON non valido:') + ' ' + e.message; }
			} }, [t('Applica')])
		]);
		els.body.appendChild(wrap);
	}

	build();
})();
