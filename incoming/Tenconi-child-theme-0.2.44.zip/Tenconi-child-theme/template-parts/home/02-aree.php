<?php
/**
 * 2 — LE CINQUE AREE, come sequenza orizzontale ancorata allo scroll.
 *
 * SOSTITUISCE LA GRIGLIA 3+2 della fase Legacy Parity, su richiesta del
 * committente: la sezione doveva diventare completamente diversa. Il contenuto
 * NON cambia — stesse cinque aree, stesse etichette, stesse immagini legacy
 * verificate, stesso ordine, stessi collegamenti. Cambia solo come si guardano.
 *
 * COME FUNZIONA. La sezione si ancora allo schermo e i cinque pannelli scorrono
 * di lato mentre si scorre in verticale: un movimento che nella griglia non
 * esisteva e che da' a ogni area lo spazio di una schermata intera invece di un
 * dodicesimo di pagina. Il numero progressivo dice sempre dove si e'.
 *
 * L'IMMAGINE VIENE PRIMA DEL TESTO, e la ragione e' un difetto vero che era da
 * correggere. Con il testo a sinistra dell'immagine l'ordine sulla pista era
 * [testo1][immagine1][testo2][immagine2]: scorrendo, l'occhio si trovava
 * immagine1 accanto a testo2 e accostava i due, cioe' leggeva l'etichetta di
 * un'area sotto la fotografia di quella precedente.
 *
 * Adesso ogni pannello e' immagine e SOTTO la sua didascalia, e lo stacco fra i
 * pannelli e' molto piu' grande dello stacco interno: e' la legge della
 * prossimita', cioe' cio' che sta vicino si legge come un gruppo. Una didascalia
 * sotto una fotografia non si sbaglia.
 *
 * L'inversione e' fatta nel DOM e non con l'ordine del CSS, cosi' vale anche per
 * chi legge con uno screen reader e per la tabulazione.
 *
 * L'IMPIANTO REGGE SENZA JAVASCRIPT, e non e' un dettaglio: senza GSAP i cinque
 * pannelli restano una colonna verticale leggibile e cliccabile. L'ancoraggio e
 * lo scorrimento laterale sono un miglioramento progressivo, non la condizione
 * per vedere il contenuto. Lo stesso vale con prefers-reduced-motion e sotto i
 * 900 px, dove la sequenza orizzontale sarebbe piu' scomoda della colonna.
 *
 * @package tenconi-child-theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/*
 * DAL 04.11.2026 i pannelli sono le quattro schede del menu "Prodotti e
 * servizi" (stesse foto, titoli e collegamenti del mega menu), non piu' le
 * cinque aree legacy: Energia e' passata a Tenconi Idromeccanica SA.
 */
$tl_aree = tenconi_home_prodotti();
if ( ! $tl_aree ) {
	return;
}
$tl_tot = count( $tl_aree );
?>
<section class="tl-oriz" id="tl-aree" data-tl-oriz aria-labelledby="tl-aree-t">

	<div class="tl-oriz__testa">
		<div class="tl-wrap">
			<h2 class="tl-oriz__t" id="tl-aree-t">Le nostre aree di attività</h2>
		</div>
	</div>

	<div class="tl-oriz__pista" data-tl-oriz-pista>
		<?php foreach ( $tl_aree as $tl_i => $tl_a ) : ?>
			<?php
			$tl_n   = str_pad( (string) ( $tl_i + 1 ), 2, '0', STR_PAD_LEFT );
			$tl_tag = '' !== $tl_a['url'] ? 'a' : 'div';
			?>
			<<?php echo esc_attr( $tl_tag ); ?>
				class="tl-pan<?php echo '' !== $tl_a['url'] ? ' tl-tile' : ''; ?>"
				<?php echo '' !== $tl_a['url'] ? ' href="' . esc_url( $tl_a['url'] ) . '"' : ''; ?>>

				<figure class="tl-pan__f">
					<?php
					if ( 'ok' === $tl_a['stato'] ) {
						echo wp_get_attachment_image(
							$tl_a['img'],
							'large',
							false,
							array(
								'alt'      => $tl_a['alt'],
								'loading'  => $tl_i < 2 ? 'eager' : 'lazy',
								'decoding' => 'async',
								'sizes'    => '(max-width: 900px) 100vw, 52vw',
							)
						);
						?>
						<?php
						/*
						 * L'ICONA WIREFRAME, in basso a destra della fotografia — non del
						 * riquadro di testo sotto. Stesso sprite gia' stampato una volta in
						 * header.php per il mega menu: qui e' solo un richiamo <use>, zero
						 * tracciato in piu' scaricato.
						 *
						 * L'icona e' la stessa della voce nel mega menu: arriva gia' con la
						 * scheda, da tenconi_mega_icone().
						 */
						$tl_nome_icona = $tl_a['icona'];
						if ( '' !== $tl_nome_icona ) :
							?>
							<span class="tl-pan__ico" data-tl-pan-ico aria-hidden="true">
								<svg viewBox="0 0 24 24" focusable="false"><use href="#tl-i-<?php echo esc_attr( $tl_nome_icona ); ?>"/></svg>
							</span>
						<?php endif; ?>
						<?php
					} else {
						?>
						<div class="tl-vuoto" role="img" aria-label="<?php echo esc_attr( function_exists( 'ticinoweb_frontend_text' ) ? ticinoweb_frontend_text( 'Immagine non disponibile', 'tenconi:ui:immagine-non-disponibile' ) : 'Immagine non disponibile' ); ?>">
							<span class="tl-vuoto__t">Immagine non disponibile</span>
						</div>
						<?php
					}
					?>
				</figure>

				<div class="tl-pan__testo">
					<p class="tl-pan__n" aria-hidden="true">
						<?php echo esc_html( $tl_n ); ?><span class="tl-pan__tot">/<?php echo esc_html( str_pad( (string) $tl_tot, 2, '0', STR_PAD_LEFT ) ); ?></span>
					</p>
					<h3 class="tl-pan__l"><?php echo esc_html( $tl_a['label'] ); ?></h3>
					<?php if ( '' !== $tl_a['url'] ) : ?>
						<p class="tl-pan__v" aria-hidden="true"><?php echo esc_html( function_exists( 'ticinoweb_frontend_text' ) ? ticinoweb_frontend_text( 'Vedi l’area', 'tenconi:home:aree-vedi' ) : 'Vedi l’area' ); ?></p>
					<?php endif; ?>
				</div>

			</<?php echo esc_attr( $tl_tag ); ?>>
		<?php endforeach; ?>
	</div>
</section>
