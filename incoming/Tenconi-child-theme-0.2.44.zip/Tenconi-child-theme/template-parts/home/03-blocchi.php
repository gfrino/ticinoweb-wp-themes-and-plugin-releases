<?php
/**
 * 3 — I DUE BLOCCHI FINALI, riscritti come fasce alternate a tutta larghezza.
 *
 * PERCHE' CAMBIA. La versione precedente era la ricostruzione fedele del vecchio
 * sito: due colonne uguali dentro la colonna da 1400, etichetta centrata sopra,
 * immagine 3:2, paragrafo, link dentro la frase. Fedele e riconoscibile — troppo:
 * il committente ha chiesto che la home non somigli al sito di prima, e questa
 * era la sezione che lo somigliava di piu'.
 *
 * IL CONTENUTO NON CAMBIA. Stesse due voci, stesse immagini legacy verificate,
 * stessi paragrafi letti dal contenuto pubblicato, stessi collegamenti. Cambia
 * solo la geometria, e cambia in modo sostanziale:
 *
 *   prima                            adesso
 *   due colonne uguali               fasce alternate, una per schermata
 *   dentro la colonna da 1400        immagine A TUTTA LARGHEZZA, fuori colonna
 *   etichetta centrata sopra         testo in colonna stretta, a lato
 *   simmetrico                       si alterna: immagine a destra, poi a sinistra
 *
 * L'IMMAGINE ESCE DALLA COLONNA e arriva al bordo dello schermo: e' la rottura
 * che si nota subito, perche' in tutto il vecchio sito nulla usciva mai dai 1400.
 *
 * REGGE SENZA JAVASCRIPT: le fasce sono griglie CSS, il parallasse e' un
 * miglioramento che anima.js aggiunge se puo'.
 *
 * @package tenconi-child-theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/*
 * DAL 04.11.2026 le fasce sono le tre voci del menu "Tecnologia e progetti"
 * (Parco macchine, Referenze, Tecnica e progettazione), con le foto e i
 * collegamenti del mega menu. E rientrano nel box del sito: fotografia piu'
 * piccola, titolo piu' grande, niente piu' immagine a filo dello schermo.
 */
$tl_b = tenconi_home_tecnologia();
if ( ! $tl_b ) {
	return;
}
?>
<section class="tl-fasce" aria-label="<?php echo esc_attr( function_exists( 'ticinoweb_frontend_text' ) ? ticinoweb_frontend_text( 'Tecnologia e progetti', 'tenconi:home:fasce-aria' ) : 'Tecnologia e progetti' ); ?>">
	<?php foreach ( $tl_b as $tl_x ) : ?>
		<article class="tl-fascia" data-tl-fascia>

			<div class="tl-fascia__testo">
				<?php
				/*
				 * NESSUN NUMERO PROGRESSIVO. C'era un "01" e "02" in filigrana sopra
				 * l'etichetta: rimosso su richiesta. Non portava informazione — sono
				 * due sole fasce e l'ordine si vede — e in filigrana su bianco era un
				 * segno che chiedeva attenzione senza darne in cambio.
				 *
				 * I numeri della sequenza orizzontale delle AREE restano: la' sono
				 * cinque pannelli che scorrono di lato, e il progressivo dice a che
				 * punto si e'. Qui non c'era niente da dire.
				 */
				?>
				<?php
				/*
				 * LO SPAN INTERNO SERVE ALLA COMPARSA. Il titolo si rivela salendo da
				 * dietro un bordo: il taglio va sull'h2 e il movimento sullo span,
				 * perche' un elemento non puo' essere insieme la maschera e la cosa
				 * mascherata — traslandolo si trascinerebbe dietro anche il taglio.
				 */
				?>
				<h2 class="tl-fascia__l"><span class="tl-fascia__l-i"><?php echo esc_html( $tl_x['label'] ); ?></span></h2>

				<?php if ( '' !== $tl_x['testo'] ) : ?>
					<p class="tl-fascia__p">
						<?php
						/*
						 * LA CIFRA SI CONTA DA SOLA. Il testo del parco macchine dice
						 * "dispone di 34 macchinari all'avanguardia": quel 34 e' il dato piu'
						 * concreto della sezione e passava inosservato in mezzo alla frase.
						 * Isolato in uno span, anima.js lo fa salire da zero quando entra in
						 * vista. L'idea e' il Number Ticker di MagicUI, riscritta in GSAP:
						 * quella e' un componente React e qui React non c'e'.
						 *
						 * SI TAGLIA SUL TESTO GREZZO, PRIMA DI ESCAPARLO, e non con una
						 * regex sull'HTML gia' escapato: esc_html() produce entita' come
						 * &#039; in "all'avanguardia", e una regex sulle cifre avrebbe
						 * pescato il 039 dentro l'entita' invece del 34 nella frase.
						 *
						 * Se il testo non ha numeri non succede nulla: la seconda fascia
						 * infatti non ne ha.
						 */
						if ( preg_match( '/\d+/u', $tl_x['testo'], $tl_m, PREG_OFFSET_CAPTURE ) ) {
							$tl_cif = $tl_m[0][0];
							$tl_pos = (int) $tl_m[0][1];
							echo esc_html( substr( $tl_x['testo'], 0, $tl_pos ) );
							echo '<span class="tl-cifra" data-tl-cifra="' . esc_attr( $tl_cif ) . '">' . esc_html( $tl_cif ) . '</span>';
							echo esc_html( substr( $tl_x['testo'], $tl_pos + strlen( $tl_cif ) ) );
						} else {
							echo esc_html( $tl_x['testo'] );
						}
						?>
					</p>
				<?php endif; ?>

				<?php if ( '' !== $tl_x['url'] ) : ?>
					<p class="tl-fascia__a">
						<a class="tl-freccia" href="<?php echo esc_url( $tl_x['url'] ); ?>">
							<span><?php echo esc_html( $tl_x['label'] ); ?></span>
							<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M4 12h15m0 0-6-6m6 6-6 6" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg>
						</a>
					</p>
				<?php endif; ?>
			</div>

			<?php
			/*
			 * La cornice ha overflow hidden e l'immagine dentro e' piu' alta del
			 * riquadro: cosi' anima.js puo' muoverla in verticale per il parallasse
			 * senza che si veda un bordo vuoto e senza spostare una riga di layout.
			 */
			?>
			<figure class="tl-fascia__f">
				<?php
				if ( 'ok' === $tl_x['stato'] ) {
					echo wp_get_attachment_image(
						$tl_x['img'],
						'large',
						false,
						array(
							'class'    => 'tl-fascia__i',
							'alt'      => $tl_x['alt'],
							'loading'  => 'lazy',
							'decoding' => 'async',
							'sizes'    => '(max-width: 900px) 100vw, 640px',
						)
					);
				} else {
					?>
					<div class="tl-vuoto" role="img" aria-label="<?php echo esc_attr( function_exists( 'ticinoweb_frontend_text' ) ? ticinoweb_frontend_text( 'Immagine non disponibile', 'tenconi:ui:immagine-non-disponibile' ) : 'Immagine non disponibile' ); ?>">
						<span class="tl-vuoto__t">Immagine non disponibile</span>
					</div>
					<?php
				}
				?>

				<?php
				/*
				 * LE MIRE AGLI ANGOLI. Sono i crocini di registro di un disegno tecnico:
				 * inquadrano la fotografia come una tavola quotata invece che come una
				 * illustrazione. Vengono dall'idea del Pointer Highlight di Aceternity.
				 *
				 * STANNO NEL MARKUP E NON IN JAVASCRIPT perche' fanno parte del disegno:
				 * senza JS si vedono ferme, con JS si stringono in posizione. Il filetto
				 * bianco ha sotto un'ombra scura di mezzo pixel, perche' una fotografia
				 * industriale ha zone chiare dove il bianco su bianco spariva.
				 */
				?>
				<span class="tl-fascia__mire" data-tl-mire aria-hidden="true">
					<span></span><span></span><span></span><span></span>
				</span>
			</figure>
		</article>
	<?php endforeach; ?>
</section>
