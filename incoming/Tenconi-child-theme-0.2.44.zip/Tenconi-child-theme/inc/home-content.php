<?php
/**
 * Contenuti della homepage Legacy-Modernized.
 *
 * PRINCIPIO: la homepage non scrive testo. Legge quello pubblicato in WordPress
 * e SCARTA alla fonte i paragrafi che contengono segnaposto o dati che il
 * committente non ha confermato. Cosi un dato non confermato non puo' arrivare
 * al frontend nemmeno per distrazione: non passa il filtro.
 *
 * Le sole righe scritte per il progetto sono il titolo dell'eroe e la frase di
 * invito al contatto. Sono redazionali, non contengono numeri, date, nomi propri
 * ne' riferimenti normativi, e sono marcate qui sotto come tali.
 *
 * FOTOGRAFIE: selezione editoriale dichiarata, fatta guardando i provini. Ogni
 * immagine passa comunque tre controlli a runtime - diritti, qualita', esistenza
 * del file - e se ne fallisce uno esce dalla pagina da sola.
 *
 * @package tenconi-child-theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Dati che PRODUCT.md tiene aperti e che non vanno pubblicati.
 *
 * Non e' una lista di stringhe da cercare, e' la forma del dato: una cifra
 * seguita da uno di questi sostantivi. Cosi regge anche se la cifra cambia.
 * "34 macchinari" non ricade nel pattern, ed e' confermato su tre fonti.
 */
const TENCONI_DATI_APERTI_RE = '/\d[\d\x{2019}\x{0027}.\x{00A0} ]*\s*(prodotti|clienti|client|paesi|dipendent\w*|collaborator\w*)/iu';

/**
 * Un frammento di testo e' pubblicabile?
 *
 * @param string $testo Testo da valutare.
 * @return bool
 */
function tenconi_home_frase_ok( $testo ) {
	$t = trim( wp_strip_all_tags( (string) $testo ) );
	if ( '' === $t ) {
		return false;
	}
	if ( preg_match( TENCONI_PH_RE, $t ) ) {
		return false;
	}
	if ( preg_match( TENCONI_DATI_APERTI_RE, $t ) ) {
		return false;
	}
	return true;
}

/**
 * Ripulisce un paragrafo che ha perso il suo antecedente.
 *
 * Il filtro scarta i paragrafi con segnaposto e dati aperti, e questo puo' far
 * diventare primo un paragrafo che comincia con un connettivo: "Inoltre, la mirata
 * diversificazione..." rimanda a una frase che non c'e' piu'. Si rimuove il solo
 * connettivo e si rialza l'iniziale. Non e' riscrittura: e' togliere un rinvio a
 * vuoto.
 *
 * @param string $t Paragrafo.
 * @return string
 */
function tenconi_home_senza_connettivo( $t ) {
	$t = preg_replace( '/^(inoltre|infatti|tuttavia|peraltro|in\s+aggiunta)\s*,?\s*/iu', '', $t, 1 );
	return ( '' === $t ) ? '' : mb_strtoupper( mb_substr( $t, 0, 1 ) ) . mb_substr( $t, 1 );
}

/**
 * Paragrafi pubblicabili di una pagina, nell'ordine in cui sono pubblicati.
 *
 * @param string $slug  Slug della pagina.
 * @param int    $quanti Numero massimo di paragrafi da restituire.
 * @return string[]
 */
function tenconi_home_paragrafi( $slug, $quanti = 3 ) {

	$p = get_page_by_path( $slug );
	if ( ! $p || 'publish' !== $p->post_status ) {
		return array();
	}

	$grezzi = preg_split( '/\R{2,}|<\/p>/i', (string) $p->post_content );
	$out    = array();

	foreach ( (array) $grezzi as $g ) {
		$t = trim( wp_strip_all_tags( $g ) );
		$t = html_entity_decode( $t, ENT_QUOTES, 'UTF-8' );
		$t = trim( preg_replace( '/\s+/u', ' ', $t ) );

		// Righe troppo corte sono intestazioni o firme, non paragrafi.
		if ( mb_strlen( $t ) < 60 ) {
			continue;
		}
		if ( ! tenconi_home_frase_ok( $t ) ) {
			continue;
		}
		$out[] = $t;
		if ( count( $out ) >= $quanti ) {
			break;
		}
	}

	return $out;
}

/**
 * Un'immagine e' utilizzabile nel frontend pubblico?
 *
 * Tre condizioni: i diritti non sono in revisione, il file esiste, e non e' una
 * grafica piatta travestita da fotografia. La soglia di 0,02 byte per pixel
 * separa una fotografia da un rettangolo di colore.
 *
 * @param int $id ID dell'allegato.
 * @return bool
 */
function tenconi_home_img_ok( $id ) {

	$id = (int) $id;
	if ( ! $id ) {
		return false;
	}
	if ( 'review_required' === get_post_meta( $id, '_tcm_rights_state', true ) ) {
		return false;
	}
	if ( 0 !== strpos( (string) get_post_mime_type( $id ), 'image/' ) ) {
		return false;
	}

	$meta = wp_get_attachment_metadata( $id );
	$px   = (int) ( $meta['width'] ?? 0 ) * (int) ( $meta['height'] ?? 0 );
	$file = get_attached_file( $id );

	if ( ! $px || ! $file || ! file_exists( $file ) ) {
		return false;
	}
	return ( filesize( $file ) / $px ) >= 0.02;
}

/**
 * L'eroe.
 *
 * Titolo e sottotitolo sono le due righe REDAZIONALI del progetto. La riga di
 * supporto invece e' letta dal testo pubblicato, e se non passa il filtro non
 * viene sostituita da niente: la pagina regge senza.
 *
 * @return array<string,mixed>
 */
function tenconi_home_hero() {

	$par = tenconi_home_paragrafi( 'storia', 6 );

	/*
	 * Cerca il paragrafo che descrive i settori: e' quello utile in apertura.
	 * Se nessuno passa il filtro, l'eroe resta senza riga di supporto.
	 */
	$supporto = '';
	foreach ( $par as $t ) {
		if ( preg_match( '/ferroviario|metalmeccanica|settori/i', $t ) ) {
			$supporto = tenconi_home_senza_connettivo( $t );
			break;
		}
	}

	// REDAZIONALE. Nessun numero, nessuna data, nessun riferimento normativo.
	return array(
		'kicker'   => 'Tenconi SA — dal 1871, Canton Ticino',
		'titolo'   => 'Componenti ferroviari e lavorazioni meccaniche su disegno.',
		'supporto' => $supporto,
		'grezzo'   => $supporto,
		'immagine' => tenconi_home_img_ok( 267 ) ? 267 : 0,
		'alt'      => 'Reparto di lavorazioni meccaniche: centri di lavoro a controllo numerico.',
		'didascalia' => 'Reparto lavorazioni meccaniche',
	);
}

/**
 * I paragrafi per la sezione Chi siamo, senza quello gia' usato dall'eroe.
 *
 * Senza questo controllo lo stesso paragrafo comparirebbe due volte nella stessa
 * pagina, a 700 pixel di distanza.
 *
 * @param int $quanti Numero massimo.
 * @return string[]
 */
function tenconi_home_par_azienda( $quanti = 3 ) {

	$hero = tenconi_home_hero();
	$usato = $hero['grezzo'];
	$out   = array();

	foreach ( tenconi_home_paragrafi( 'storia', 6 ) as $t ) {
		$pulito = tenconi_home_senza_connettivo( $t );
		if ( '' !== $usato && $pulito === $usato ) {
			continue;
		}
		$out[] = $pulito;
		if ( count( $out ) >= $quanti ) {
			break;
		}
	}
	return $out;
}

/**
 * La scheda dati dell'azienda. Solo fatti confermati.
 *
 * L'anno di fondazione e le due sedi sono nel testo pubblicato e in PRODUCT.md
 * come confermati. Le due norme ISO sono dichiarate nel testo pubblicato: non
 * esistono record di certificazione, quindi la fonte e' e resta testuale.
 *
 * @return array<int,array{label:string,valore:string}>
 */
function tenconi_home_fatti() {

	$out = array();
	$cs  = get_page_by_path( 'storia' );
	$txt = $cs ? wp_strip_all_tags( (string) $cs->post_content ) : '';

	if ( preg_match( '/\b(18\d{2})\b/', $txt, $m ) ) {
		$out[] = array(
			'label'  => 'Fondazione',
			'valore' => $m[1],
		);
	}
	if ( false !== stripos( $txt, 'Airolo' ) && false !== stripos( $txt, 'Cadenazzo' ) ) {
		$out[] = array(
			'label'  => 'Sedi',
			'valore' => 'Airolo · Cadenazzo',
		);
	}
	$norme = array();
	foreach ( array( '9001', '14001' ) as $n ) {
		if ( preg_match( '/ISO\s*' . $n . '|\b' . $n . '\b/', $txt ) ) {
			$norme[] = 'ISO ' . $n;
		}
	}
	if ( $norme ) {
		$out[] = array(
			'label'  => 'Certificazioni',
			'valore' => implode( ' · ', $norme ),
		);
	}

	return $out;
}

/**
 * La riga di apertura della home: tre media 16:9.
 *
 * Nel legacy sono tre video YouTube. Qui sono tre fotografie reali, per la ragione
 * spiegata in template-parts/home/01-media.php: un iframe di terzi tocca il
 * consenso, non il layout. La geometria e' quella misurata; le didascalie dei
 * video NON vengono riusate, perche' etichetterebbero una fotografia col nome di
 * un filmato.
 *
 * @return array<int,array<string,mixed>>
 */
function tenconi_home_media() {

	/*
	 * La prima riga NON e' piu' una scelta di questo file: e' la mappa legacy.
	 * Le tre fotografie che stavano qui (attachment 267, 262, 615) non erano gli
	 * asset del legacy, ed e' la divergenza piu' visibile che il confronto ha
	 * mostrato. Nel legacy questa riga e' due video YouTube e una figura.
	 */
	return tenconi_legacy_home_media();
}

/**
 * I due blocchi che chiudono la home legacy.
 *
 * I paragrafi sono quelli PUBBLICATI nella pagina home, letti verbatim: e' il
 * testo che il sito legacy mostra in quel punto. Il link compare solo se la
 * destinazione e' pubblicabile; dove non lo e', restano etichetta, immagine e
 * testo, senza collegamento.
 *
 * @return array<int,array<string,mixed>>
 */
function tenconi_home_blocchi() {

	$home = get_page_by_path( 'home' );
	$txt  = $home ? wp_strip_all_tags( (string) $home->post_content ) : '';
	$txt  = html_entity_decode( $txt, ENT_QUOTES, 'UTF-8' );

	// I due paragrafi, presi per intero dalla frase iniziale al punto finale.
	$par = function ( $inizio ) use ( $txt ) {
		if ( ! preg_match( '/' . preg_quote( $inizio, '/' ) . '[^.]*\./u', $txt, $m ) ) {
			return '';
		}
		return trim( preg_replace( '/\s+/u', ' ', $m[0] ) );
	};

	/*
	 * Le immagini vengono dalla mappa legacy, non da questo file. Prima c'erano
	 * l'attachment 258 per il parco macchine e il 491 per la gestione progetti:
	 * nessuno dei due e' l'asset del legacy.
	 */
	$out = array();
	foreach ( tenconi_legacy_home_blocchi() as $d ) {
		$out[] = array(
			'label'  => $d['label'],
			'img'    => (int) $d['img'],
			'stato'  => tenconi_legacy_stato_img( $d['img'] ),
			'legacy' => isset( $d['legacy'] ) ? $d['legacy'] : '',
			'alt'    => $d['alt'],
			'testo'    => $par( $d['inizio'] ),
			'prefisso' => $d['prefisso'],
			'link'     => $d['link'],
			'url'      => tenconi_dest_url( $d['dest'][0], $d['dest'][1] ),
		);
	}
	return $out;
}

/**
 * Le cinque aree di attivita' del sito legacy.
 *
 * Le etichette sono quelle approvate, cioe' quelle legacy. L'URL c'e' soltanto
 * se la destinazione passa il cancello: dove manca, la tavola resta una tavola e
 * non diventa un link finto.
 *
 * @return array<int,array<string,mixed>>
 */
function tenconi_home_aree() {

	/*
	 * Immagini E ORDINE vengono dalla mappa legacy. Qui prima c'erano cinque
	 * attachment diversi da quelli del legacy, e Carpenteria metallica stava in
	 * quarta posizione invece che in terza.
	 *
	 * UNA TAVOLA NON VIENE PIU' OMESSA se la sua immagine non e' pubblicabile:
	 * sparirebbe un'area di attivita' dell'azienda per un problema di file. La
	 * tavola resta, con l'etichetta e il suo stato.
	 */
	$out = array();
	foreach ( tenconi_legacy_home_aree() as $d ) {
		$out[] = array(
			'label' => $d['label'],
			'url'   => tenconi_dest_url( $d['dest'][0], $d['dest'][1] ),
			'img'   => (int) $d['img'],
			'stato' => tenconi_legacy_stato_img( $d['img'] ),
			'alt'   => $d['alt'],
		);
	}
	return $out;
}

/**
 * Il parco macchine: conteggio reale piu' la frase pubblicata che lo dichiara.
 *
 * Il 34 concorda su tre fonti indipendenti: il conteggio dei record, la frase
 * della home legacy e il testo pubblicato. Viene mostrato solo se il conteggio
 * e la frase concordano ancora: se divergono, il numero non esce.
 *
 * @return array<string,mixed>
 */
function tenconi_home_macchine() {

	$n     = (int) wp_count_posts( 'machine' )->publish;
	$frase = '';

	$home = get_page_by_path( 'home' );
	$txt  = $home ? wp_strip_all_tags( (string) $home->post_content ) : '';
	if ( preg_match( '/[^.]*\b' . $n . '\s+macchinari[^.]*\./u', $txt, $m ) ) {
		$frase = trim( preg_replace( '/\s+/u', ' ', $m[0] ) );
	}

	return array(
		'n'     => $frase ? $n : 0,
		'frase' => $frase,
		'url'   => tenconi_dest_url( 'cpt_archive', 'machine' ),
		'img'   => tenconi_home_img_ok( 258 ) ? 258 : 0,
		'alt'   => 'Centro di lavoro di grandi dimensioni.',
	);
}

/**
 * Referenze e progetti.
 *
 * Nessuna prosa: la pagina legacy referenze e' marcata da redigere e tutti i
 * progetti sono da riautorizzare. Restano le tre sezioni che quella pagina
 * dichiara nei propri H2, che sono pubblicate e non nominano nessun progetto.
 *
 * @return array<string,mixed>
 */
function tenconi_home_referenze() {
	$img_id = tenconi_home_img_ok( 615 ) ? 615 : ( function_exists( 'tenconi_media_da_nome' ) ? tenconi_media_da_nome( 'referenze-progetti', 'image' ) : 0 );
	return array(
		'sezioni' => 'Ferroviario · Carpenteria metallica · Energia',
		'url'     => tenconi_dest_url( 'cpt_archive', 'project' ),
		'img'     => $img_id,
		'alt'     => 'Ponte ferroviario in acciaio e infrastruttura con catenaria alpina.',
	);
}

/**
 * Le norme dichiarate nel testo pubblicato, con la loro denominazione.
 *
 * @return array<int,array{codice:string,nome:string}>
 */
function tenconi_home_norme() {

	$cs  = get_page_by_path( 'storia' );
	$txt = $cs ? wp_strip_all_tags( (string) $cs->post_content ) : '';
	$out = array();

	if ( preg_match( '/ISO\s*9001|\b9001\b/', $txt ) ) {
		$out[] = array(
			'codice' => 'ISO 9001',
			'nome'   => 'Sistema di gestione della qualità',
		);
	}
	if ( preg_match( '/ISO\s*14001|\b14001\b/', $txt ) ) {
		$out[] = array(
			'codice' => 'ISO 14001',
			'nome'   => 'Sistema di gestione ambientale',
		);
	}
	return $out;
}

/**
 * La frase pubblicata che elenca le competenze certificate, se pubblicabile.
 *
 * @return string
 */
function tenconi_home_competenze() {
	foreach ( tenconi_home_paragrafi( 'storia', 6 ) as $t ) {
		if ( preg_match( '/certificazion/i', $t ) ) {
			return $t;
		}
	}
	return '';
}

/**
 * Le schede di un gruppo del menu, come le vede il mega menu.
 *
 * DAL 04.11.2026 LA HOME LEGGE IL MENU. Il carosello e le fasce finali mostrano
 * le stesse voci dei pannelli "Prodotti e servizi" e "Tecnologia e progetti":
 * stesse fotografie (comprese quelle scelte nel backend), stessi titoli, stessi
 * collegamenti. Cambiare una voce del menu cambia anche la home, senza toccare
 * il tema due volte.
 *
 * @param string $gruppo Chiave del gruppo in tenconi_nav_blueprint().
 * @return array<int,array<string,mixed>>
 */
function tenconi_home_schede_menu( $gruppo ) {

	if ( ! function_exists( 'tenconi_nav_mega' ) ) {
		return array();
	}

	$icone = function_exists( 'tenconi_mega_icone' ) ? tenconi_mega_icone() : array();
	$out   = array();

	foreach ( tenconi_nav_mega() as $voce ) {
		if ( $gruppo !== $voce['key'] || empty( $voce['schede'] ) ) {
			continue;
		}
		foreach ( $voce['schede'] as $s ) {
			$img   = (int) $s['img'];
			$out[] = array(
				'key'   => $s['key'],
				'label' => $s['label'],
				'url'   => (string) $s['url'],
				'img'   => $img,
				'stato' => tenconi_legacy_stato_img( $img ),
				'alt'   => '' !== (string) $s['alt'] ? (string) $s['alt'] : (string) $s['label'],
				'icona' => isset( $icone[ $s['key'] ] ) ? $icone[ $s['key'] ] : '',
			);
		}
	}
	return $out;
}

/**
 * Le quattro schede di "Prodotti e servizi", per il carosello della home.
 *
 * @return array<int,array<string,mixed>>
 */
function tenconi_home_prodotti() {
	return tenconi_home_schede_menu( 'aree-di-attivita' );
}

/**
 * Le tre voci di "Tecnologia e progetti", per le fasce finali della home.
 *
 * I testi di Parco macchine e di Tecnica e progettazione sono i paragrafi
 * pubblicati nella pagina Home (gli stessi delle due fasce di prima). Referenze
 * non ha un paragrafo pubblicato: la frase qui sotto e' redazionale e nomina
 * solo tipi di lavoro che hanno una scheda progetto pubblicata.
 *
 * @return array<int,array<string,mixed>>
 */
function tenconi_home_tecnologia() {

	$home = get_page_by_path( 'home' );
	$txt  = $home ? wp_strip_all_tags( (string) $home->post_content ) : '';
	$txt  = html_entity_decode( $txt, ENT_QUOTES, 'UTF-8' );

	$par = function ( $inizio ) use ( $txt ) {
		if ( ! preg_match( '/' . preg_quote( $inizio, '/' ) . '[^.]*\./u', $txt, $m ) ) {
			return '';
		}
		return trim( preg_replace( '/\s+/u', ' ', $m[0] ) );
	};

	$referenze = 'Ponti, elettrodotti, valvole e telai ferroviari: una selezione dei lavori realizzati da Tenconi.';
	if ( function_exists( 'ticinoweb_frontend_text' ) ) {
		$referenze = ticinoweb_frontend_text( $referenze, 'tenconi:home:referenze-testo' );
	}

	$testi = array(
		'parco-macchine'    => $par( 'Nelle due sedi' ),
		'referenze'         => $referenze,
		'gestione-progetti' => $par( 'La ditta Tenconi SA' ),
	);

	$out = array();
	foreach ( tenconi_home_schede_menu( 'tecnologia-e-progetti' ) as $s ) {
		$s['testo'] = isset( $testi[ $s['key'] ] ) ? $testi[ $s['key'] ] : '';
		$out[]      = $s;
	}
	return $out;
}
