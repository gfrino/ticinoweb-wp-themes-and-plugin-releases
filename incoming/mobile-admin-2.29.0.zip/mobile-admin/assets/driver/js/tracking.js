/**
 * Mobile Admin — Driver: tracking del cliente sul sito.
 *
 * 1. WordPress dà un token breve (5 min) all'utente collegato.
 * 2. Le Cloud Functions lo scambiano con un token Firebase (uid «wp_<id>»).
 * 3. Firestore manda in tempo reale il documento della consegna: le regole lo fanno leggere
 *    solo al cliente dell'ordine, al Driver assegnato e agli amministratori.
 * La posizione mostrata è sempre l'ultima ricevuta: niente punti inventati; se è vecchia lo dice.
 */
import { initializeApp } from 'https://www.gstatic.com/firebasejs/10.14.1/firebase-app.js';
import { initializeAuth, inMemoryPersistence, signInWithCustomToken, signOut, connectAuthEmulator } from 'https://www.gstatic.com/firebasejs/10.14.1/firebase-auth.js';
import { getFirestore, doc, onSnapshot, connectFirestoreEmulator } from 'https://www.gstatic.com/firebasejs/10.14.1/firebase-firestore.js';

const box = document.getElementById('madr-track');
const mapEl = document.getElementById('madr-track-map');
const info = document.getElementById('madr-track-info');

if (box && mapEl && window.L) {
	const cfg = JSON.parse(box.dataset.config || '{}');
	const t = cfg.i18n || {};
	const STALE_MS = 60 * 1000;

	const L = window.L;
	const map = L.map(mapEl, { zoomControl: true, attributionControl: true }).setView([46.19, 9.02], 13);
	L.tileLayer(cfg.tiles, { maxZoom: 19, attribution: cfg.tilesAttribution || '' }).addTo(map);

	const carIcon = L.divIcon({
		className: 'madr-car',
		html: '<span class="madr-car__dot"><svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5.1 17.2H2.7v-4l2.3-1.7 2.7-4.1a2 2 0 0 1 1.7-.9h5.9a2 2 0 0 1 1.6.8l3.2 4.2 2.2.7v5h-1.7M9.6 17.2h5.8"/><path d="M5.9 11.6h14"/><circle cx="7.3" cy="17.3" r="2.1"/><circle cx="17.7" cy="17.3" r="2.1"/></svg></span>',
		iconSize: [40, 40],
		iconAnchor: [20, 20]
	});
	const homeIcon = L.divIcon({ className: 'madr-home', html: '<span class="madr-home__pin"></span>', iconSize: [22, 22], iconAnchor: [11, 22] });

	let car = null;
	let home = null;
	let lastTs = 0;
	let fitted = false;
	let unsubscribe = null;
	let auth = null;
	let done = false;
	let staleTimer = null;

	const setInfo = (msg, kind) => {
		if (done && kind !== 'done') { return; }
		info.textContent = msg;
		info.className = 'madr-track__info' + (kind ? ' is-' + kind : '');
	};

	const setStep = (status) => {
		const order = ['assigned', 'en_route', 'delivered'];
		const idx = order.indexOf(status);
		box.querySelectorAll('.madr-steps__item').forEach((li, i) => {
			li.classList.toggle('is-done', idx >= 0 && i <= idx);
			li.classList.toggle('is-current', i === idx);
		});
	};

	const finish = (msg) => {
		if (done) { return; }
		done = true;
		if (unsubscribe) { unsubscribe(); unsubscribe = null; }
		if (staleTimer) { clearInterval(staleTimer); staleTimer = null; }
		lastTs = 0;
		map.remove();
		mapEl.remove();
		setInfo(msg, 'done');
		if (auth) { signOut(auth).catch(() => {}); }
	};

	const refreshStale = () => {
		if (!lastTs) { return; }
		const age = Date.now() - lastTs;
		if (age > STALE_MS) {
			setInfo((t.stale || '').replace('%s', String(Math.max(1, Math.round(age / 60000)))), 'stale');
			if (car) { car.getElement() && car.getElement().classList.add('is-stale'); }
		}
	};
	staleTimer = setInterval(refreshStale, 15000);

	// L'auto scorre in ~0.9 s dalla posizione ricevuta prima a quella nuova (entrambe vere): niente salti,
	// niente posizioni previste. Con «riduci movimento» del sistema si sposta subito.
	const reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
	let slideRaf = 0;
	const slideTo = (to) => {
		cancelAnimationFrame(slideRaf);
		const from = car.getLatLng();
		if (reduce) { car.setLatLng(to); return; }
		const start = performance.now();
		const step = (now) => {
			const k = Math.min(1, (now - start) / 900);
			const e = k < 0.5 ? 2 * k * k : 1 - Math.pow(-2 * k + 2, 2) / 2;
			car.setLatLng([from.lat + (to[0] - from.lat) * e, from.lng + (to[1] - from.lng) * e]);
			if (k < 1) { slideRaf = requestAnimationFrame(step); }
		};
		slideRaf = requestAnimationFrame(step);
	};

	const render = (data) => {
		setStep(data.status);
		if (data.status === 'delivered') { finish(t.delivered); return; }
		if (data.status === 'cancelled') { finish(t.cancelled); return; }
		if (data.destination && !home) {
			home = L.marker([data.destination.lat, data.destination.lng], { icon: homeIcon, title: t.home }).addTo(map);
		}
		const p = data.driverPosition;
		if (!p || typeof p.lat !== 'number') {
			setInfo(t.waitGps);
			if (home && !fitted) { map.setView(home.getLatLng(), 15); }
			return;
		}
		const ts = p.ts && typeof p.ts.toMillis === 'function' ? p.ts.toMillis() : Date.now();
		lastTs = ts;
		const ll = [p.lat, p.lng];
		if (!car) {
			car = L.marker(ll, { icon: carIcon, title: t.driver, keyboard: false }).addTo(map);
		} else {
			slideTo(ll);
		}
		car.getElement() && car.getElement().classList.toggle('is-stale', Date.now() - ts > STALE_MS);
		if (!fitted) {
			map.fitBounds(home ? L.latLngBounds([ll, home.getLatLng()]).pad(0.3) : L.latLngBounds([ll, ll]).pad(0.01), { maxZoom: 16 });
			fitted = true;
		} else if (!map.getBounds().pad(-0.15).contains(ll)) {
			map.panTo(ll, { animate: true });
		}
		setInfo(data.driverName ? data.driverName + ' — ' + (cfg.statuses[data.status] || '') : (cfg.statuses[data.status] || ''));
		refreshStale();
	};

	const start = async () => {
		const wp = await fetch(cfg.rest + '/firebase-token', {
			method: 'POST', credentials: 'same-origin', headers: { 'X-WP-Nonce': cfg.nonce }
		}).then((r) => (r.ok ? r.json() : Promise.reject(new Error('wp ' + r.status))));
		const ex = await fetch(wp.functions + '/driverTracking/token', {
			method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + wp.token }
		}).then((r) => (r.ok ? r.json() : Promise.reject(new Error('cf ' + r.status))));

		const app = initializeApp(cfg.firebase, 'madr-tracking');
		// Sessione solo in memoria: chiusa la pagina non resta nessun accesso salvato nel browser.
		auth = initializeAuth(app, { persistence: inMemoryPersistence });
		const db = getFirestore(app);
		if (cfg.emulator) {
			connectAuthEmulator(auth, 'http://' + cfg.emulator + ':9099', { disableWarnings: true });
			connectFirestoreEmulator(db, cfg.emulator, 8085);
		}
		await signInWithCustomToken(auth, ex.customToken);
		unsubscribe = onSnapshot(doc(db, 'deliveries', cfg.docId), (snap) => {
			if (snap.exists()) { render(snap.data()); }
		}, () => setInfo(t.error, 'stale'));
	};

	window.addEventListener('offline', () => setInfo(t.offline, 'stale'));
	window.addEventListener('pagehide', () => {
		if (unsubscribe) { unsubscribe(); unsubscribe = null; }
		if (auth) { signOut(auth).catch(() => {}); }
	});
	start().catch(() => setInfo(t.error, 'stale'));
}
