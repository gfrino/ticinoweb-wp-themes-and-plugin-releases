<?php
/**
 * Accesso app (JWT) — v2.24.0
 *
 * Mobile Admin answers, in place of the «Simple JWT Login» plugin (3.6.8), the REST routes that the
 * client apps and their Cloud Functions call. Same addresses, same parameters, same answers and the
 * same error codes, because the apps already installed on the phones cannot be changed:
 *
 *   POST      simple-jwt-login/v1/auth                 login            { success, data: { jwt } }
 *   GET|POST  simple-jwt-login/v1/auth/validate        token check      { success, data: { user, roles, jwt: [ {…} ] } }
 *   POST      simple-jwt-login/v1/auth/revoke          logout           { success, message, data: { jwt: [ token ] } }
 *   POST      simple-jwt-login/v1/users                registration     { success, id, message, user, roles, jwt }
 *   POST      simple-jwt-login/v1/user/reset_password  send the reset   { success, message }
 *   PUT       simple-jwt-login/v1/user/reset_password  new password     { success, message }
 *   DELETE    simple-jwt-login/v1/users                delete account   { message, id }   (2.26.0, only where the site allows it)
 *
 * Errors: { success: false, data: { message, errorCode } } with HTTP 400 (401 for a revoked,
 * expired or not-yet-valid token), exactly as 3.6.8 does.
 *
 * Tokens already issued stay valid: same signing key, same algorithm, same claims, same list of
 * revoked tokens (user meta `simple_jwt_login_revoked_token`).
 *
 * When it answers
 * - only on a site where the switch «Accesso app» is on (off by default: nothing changes on a site
 *   until someone turns it on), and
 * - only while Simple JWT Login is NOT active on that site: there is never a second set of the same
 *   routes. Reactivating Simple JWT Login hands the routes back to it at once.
 *
 * Settings
 * Turning the switch on copies the settings the routes need from Simple JWT Login's option
 * (`simple_jwt_login_settings`, flat 3.x format) into Mobile Admin's own option
 * (`wpadr_jwt_settings`, not autoloaded), because deleting Simple JWT Login deletes its option.
 * The key names are kept as they are, so nothing has to be typed again.
 *
 * Deliberately NOT carried over (no app or Cloud Function calls them, and each one is a way in):
 * autologin by link, auth/refresh, Google OAuth, login with `password_hash`, extra
 * claims sent by the client (`payload`), user meta at registration, the JWT «middleware» on the
 * other REST routes, the plugin's hooks, JWT from cookie or PHP session.
 *
 * Added on top of 3.6.8: a limit on failed attempts (HTTP 429), constant-time comparison of the
 * app key, no privileged role for a new account, answers never kept by a page cache, and (2.25.0)
 * the forgotten-password e-mail of the shop: WooCommerce's own e-mail, with the link to the site's
 * «My account» page, chosen per site in Gestione App → Accesso app (settings key `ma_reset_flow`).
 * Nothing is written to a log: neither keys, nor passwords, nor tokens.
 */

defined( 'ABSPATH' ) || exit;

/** Mobile Admin's own copy of the settings (per site, not autoloaded). */
define( 'WPADR_JWT_OPTION', 'wpadr_jwt_settings' );
/** The switch (per site): '1' = Mobile Admin may answer the app login routes. */
define( 'WPADR_JWT_SWITCH', 'wpadr_jwt_enabled' );
/** Simple JWT Login's option, read only. */
define( 'WPADR_JWT_SJL_OPTION', 'simple_jwt_login_settings' );
/** Revoked tokens: the same user meta Simple JWT Login 3.x writes, so a token revoked before stays revoked. */
define( 'WPADR_JWT_REVOKED_META', 'simple_jwt_login_revoked_token' );
/** Clock tolerance in seconds when a token is checked (same as Simple JWT Login). */
define( 'WPADR_JWT_LEEWAY', 60 );

/**
 * An error of the app login routes. The code is the Simple JWT Login error code the apps read in
 * `data.errorCode`; $http_status overrides the HTTP status (429 when the attempt limit is reached).
 */
class WPADR_Jwt_Exception extends Exception {
	/** @var int */
	public $http_status = 0;
	/** @var int */
	public $retry_after = 0;
}

// ---------------------------------------------------------------------------------------------
// Settings
// ---------------------------------------------------------------------------------------------

/** The Simple JWT Login keys the routes use. Anything else is not copied. */
function WPADR_jwt_setting_keys() {
	return array(
		// Login.
		'allow_authentication', 'auth_requires_auth_code', 'auth_password_base64', 'auth_ip',
		'jwt_payload', 'jwt_auth_ttl', 'jwt_auth_iss',
		// Token.
		'jwt_algorithm', 'decryption_source', 'decryption_key', 'decryption_key_base64',
		'request_jwt_url', 'request_jwt_header', 'request_jwt_cookie', 'request_jwt_session', 'request_keys',
		'jwt_login_by', 'jwt_login_by_parameter', 'jwt_email_parameter',
		// Registration.
		'allow_register', 'require_register_auth', 'new_user_profile', 'register_ip', 'register_domain',
		'random_password', 'random_password_length', 'register_jwt', 'allowed_user_meta',
		// Password reset.
		'allow_reset_password', 'reset_password_requires_auth_code', 'reset_password_jwt',
		'jwt_reset_password_flow', 'jwt_email_subject', 'jwt_reset_password_email_body', 'jwt_email_type',
		// Account deletion (2.26.0).
		'allow_delete', 'require_delete_auth', 'delete_ip', 'delete_user_by', 'jwt_delete_by_parameter',
		// App keys and address.
		'auth_codes', 'auth_code_key', 'route_namespace',
		// Read only to warn that they are not carried over.
		'api_middleware', 'enabled_hooks',
	);
}

/** Simple JWT Login's settings of this site as an array, or null when there are none. */
function WPADR_jwt_read_sjl_settings() {
	$raw = get_option( WPADR_JWT_SJL_OPTION, null );
	if ( is_string( $raw ) && '' !== $raw ) {
		$raw = json_decode( $raw, true );
	}
	return ( is_array( $raw ) && $raw ) ? $raw : null;
}

/** Keeps only the keys the routes use. */
function WPADR_jwt_filter_settings( $settings ) {
	return array_intersect_key( (array) $settings, array_flip( WPADR_jwt_setting_keys() ) );
}

/** Mobile Admin's own settings of this site (empty array when the site was never set up). */
function WPADR_jwt_settings() {
	$own = get_option( WPADR_JWT_OPTION, null );
	return ( is_array( $own ) && $own ) ? $own : array();
}

/**
 * The settings in force: Mobile Admin's own copy when it exists, otherwise Simple JWT Login's
 * (read only). Used by the status page and by mobile-admin/v1/register-or-add, which must keep
 * working on the sites where the switch is still off.
 */
function WPADR_jwt_effective_settings() {
	$own = WPADR_jwt_settings();
	if ( $own ) {
		return $own;
	}
	$sjl = WPADR_jwt_read_sjl_settings();
	return $sjl ? WPADR_jwt_filter_settings( $sjl ) : array();
}

/**
 * Mobile Admin's own choices inside its settings: the keys that start with `ma_`. Simple JWT Login
 * does not know them, so a new copy of its settings must keep them and a comparison must skip them.
 */
function WPADR_jwt_own_choices( $settings ) {
	$choices = array();
	foreach ( (array) $settings as $key => $value ) {
		if ( 0 === strpos( (string) $key, 'ma_' ) ) {
			$choices[ $key ] = $value;
		}
	}
	return $choices;
}

/** Copies Simple JWT Login's settings into Mobile Admin's option. False when there is nothing to copy. */
function WPADR_jwt_import_from_sjl() {
	$sjl = WPADR_jwt_read_sjl_settings();
	if ( ! $sjl ) {
		return false;
	}
	update_option( WPADR_JWT_OPTION, array_merge( WPADR_jwt_filter_settings( $sjl ), WPADR_jwt_own_choices( WPADR_jwt_settings() ) ), false );
	return true;
}

/** True when Simple JWT Login's settings exist and differ from Mobile Admin's copy. */
function WPADR_jwt_copy_is_stale() {
	$own = WPADR_jwt_settings();
	$sjl = WPADR_jwt_read_sjl_settings();
	if ( ! $own || ! $sjl ) {
		return false;
	}
	return wp_json_encode( array_diff_key( $own, WPADR_jwt_own_choices( $own ) ) ) !== wp_json_encode( WPADR_jwt_filter_settings( $sjl ) );
}

/** A setting as Simple JWT Login reads it: the stored value when the key exists, else the default. */
function WPADR_jwt_get( $settings, $key, $default = null ) {
	return isset( $settings[ $key ] ) ? $settings[ $key ] : $default;
}

/** REST namespace of the routes (Simple JWT Login's own setting, `simple-jwt-login/v1` by default). */
function WPADR_jwt_namespace( $settings ) {
	$namespace = (string) WPADR_jwt_get( $settings, 'route_namespace', 'simple-jwt-login/v1/' );
	// A value saved with escaped slashes (simple-jwt-login\/v1\/) worked in Simple JWT Login only
	// because a REST route is matched as a regular expression: here it becomes a plain path.
	$namespace = trim( str_replace( '\\', '', $namespace ), '/' );
	return '' !== $namespace ? $namespace : 'simple-jwt-login/v1';
}

/** Signing key of this site ('' when missing). */
function WPADR_jwt_signing_key( $settings ) {
	$key = (string) WPADR_jwt_get( $settings, 'decryption_key', '' );
	if ( '' !== $key && ! empty( $settings['decryption_key_base64'] ) ) {
		$key = (string) base64_decode( $key ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode -- the key is stored base64-encoded when this option is on
	}
	return $key;
}

/** HMAC algorithms Mobile Admin signs and verifies with. */
function WPADR_jwt_algorithms() {
	return array(
		'HS256' => 'sha256',
		'HS384' => 'sha384',
		'HS512' => 'sha512',
	);
}

/**
 * Reasons why Mobile Admin cannot take over on this site with these settings (plain Italian, shown
 * in the dashboard). Empty array = it can.
 */
function WPADR_jwt_blockers( $settings ) {
	$blockers = array();
	if ( ! $settings ) {
		return $blockers;
	}
	$algorithm = (string) WPADR_jwt_get( $settings, 'jwt_algorithm', 'HS256' );
	if ( ! isset( WPADR_jwt_algorithms()[ $algorithm ] ) ) {
		$blockers[] = 'I token sono firmati con ' . $algorithm . ' (un certificato): Mobile Admin firma solo con una chiave segreta (HS256, HS384, HS512).';
	}
	if ( '1' === (string) WPADR_jwt_get( $settings, 'decryption_source', '0' ) ) {
		$blockers[] = 'La chiave di firma è scritta in wp-config.php e non nelle impostazioni.';
	} elseif ( '' === WPADR_jwt_signing_key( $settings ) ) {
		$blockers[] = 'Manca la chiave di firma dei token.';
	}
	$ip_lists = array( 'auth_ip', 'register_ip' );
	if ( ! empty( $settings['allow_delete'] ) ) {
		$ip_lists[] = 'delete_ip';
	}
	foreach ( $ip_lists as $key ) {
		if ( '' !== trim( (string) WPADR_jwt_get( $settings, $key, '' ) ) ) {
			$blockers[] = 'È impostato un elenco di indirizzi IP ammessi (' . $key . '), che Mobile Admin non applica.';
			break;
		}
	}
	return $blockers;
}

/** Settings that Simple JWT Login applied and Mobile Admin does not (shown as a note, not a stop). */
function WPADR_jwt_notes( $settings ) {
	$notes = array();
	if ( ! empty( $settings['api_middleware']['enabled'] ) ) {
		$notes[] = 'Su questo sito Simple JWT Login accettava il token dell\'app anche sulle altre rotte REST di WordPress («middleware»). Mobile Admin non lo fa: il token vale solo per le rotte di accesso.';
	}
	if ( ! empty( $settings['enabled_hooks'] ) ) {
		$notes[] = 'Erano attivi degli hook di Simple JWT Login (per sviluppatori): con Mobile Admin non vengono eseguiti.';
	}
	if ( ! empty( $settings['request_jwt_cookie'] ) || ! empty( $settings['request_jwt_session'] ) ) {
		$notes[] = 'Il token veniva letto anche da cookie o sessione: Mobile Admin lo legge solo dall\'intestazione Authorization e dall\'indirizzo.';
	}
	if ( '' !== trim( (string) WPADR_jwt_get( $settings, 'allowed_user_meta', '' ) ) ) {
		$notes[] = 'Alla registrazione venivano salvati dei campi utente aggiuntivi (user_meta): Mobile Admin non li salva.';
	}
	return $notes;
}

// ---------------------------------------------------------------------------------------------
// Who answers
// ---------------------------------------------------------------------------------------------

/**
 * The switch of this site. Read from the options WordPress has already loaded (the switch is
 * always saved autoloaded): on a site that never turned it on this costs no database query,
 * and it runs on every REST request.
 */
function WPADR_jwt_switch_on() {
	$options = wp_load_alloptions();
	return isset( $options[ WPADR_JWT_SWITCH ] ) && '1' === (string) $options[ WPADR_JWT_SWITCH ];
}

/** Turns the switch on or off (autoloaded, see WPADR_jwt_switch_on). */
function WPADR_jwt_set_switch( $on ) {
	update_option( WPADR_JWT_SWITCH, $on ? '1' : '0', true );
}

/**
 * When Simple JWT Login is deactivated on a site whose switch is on, Mobile Admin takes over on
 * the next request: take a fresh copy of its settings now, in case they were changed after the
 * switch was turned on.
 */
add_action( 'deactivated_plugin', 'WPADR_jwt_on_plugin_deactivated' );
function WPADR_jwt_on_plugin_deactivated( $plugin ) {
	if ( 'simple-jwt-login.php' === basename( (string) $plugin ) && WPADR_jwt_switch_on() ) {
		WPADR_jwt_import_from_sjl();
	}
}

/** True when the Simple JWT Login plugin is active on this site (or on the whole network). */
function WPADR_jwt_sjl_active() {
	if ( function_exists( 'simple_jwt_login_plugin_create_menu_entry' ) || defined( 'SIMPLE_JWT_LOGIN_V3_EOL_NOTICE_ACTION' ) ) {
		return true;
	}
	$active = (array) get_option( 'active_plugins', array() );
	if ( is_multisite() ) {
		$active = array_merge( $active, array_keys( (array) get_site_option( 'active_sitewide_plugins', array() ) ) );
	}
	foreach ( $active as $plugin ) {
		// Listed as active and really on disk: a deleted plugin can stay in the list until the
		// Plugins screen is opened, and must not keep the app login switched off.
		if ( 'simple-jwt-login.php' === basename( (string) $plugin ) && file_exists( WP_PLUGIN_DIR . '/' . $plugin ) ) {
			return true;
		}
	}
	return false;
}

/**
 * Where this site stands.
 *
 * code: 'on'       Mobile Admin answers the app login routes
 *       'waiting'  switch on, Simple JWT Login still active (it answers; Mobile Admin takes over when it is deactivated)
 *       'off'      switch off, Simple JWT Login answers
 *       'nobody'   switch off and Simple JWT Login not active, but settings exist: nobody answers the app
 *       'blocked'  switch on but these settings cannot be served (see blockers)
 *       'empty'    no settings on this site: it is not an app site (yet)
 */
function WPADR_jwt_state() {
	$switch     = WPADR_jwt_switch_on();
	$sjl_active = WPADR_jwt_sjl_active();
	$own        = WPADR_jwt_settings();
	$effective  = $own ? $own : WPADR_jwt_effective_settings();
	$blockers   = WPADR_jwt_blockers( $effective );
	$serving    = $switch && ! $sjl_active && $own && ! $blockers;

	if ( ! $effective ) {
		$code = 'empty';
	} elseif ( $serving ) {
		$code = 'on';
	} elseif ( $switch && $blockers ) {
		$code = 'blocked';
	} elseif ( $switch && $sjl_active ) {
		$code = 'waiting';
	} elseif ( $sjl_active ) {
		$code = 'off';
	} else {
		$code = 'nobody';
	}
	return array(
		'code'       => $code,
		'switch'     => $switch,
		'sjl_active' => $sjl_active,
		'has_own'    => (bool) $own,
		'settings'   => $effective,
		'blockers'   => $blockers,
		'serving'    => (bool) $serving,
	);
}

// ---------------------------------------------------------------------------------------------
// Routes
// ---------------------------------------------------------------------------------------------

/**
 * REST namespace Mobile Admin answers on this site, '' when it does not. Cheap on purpose (it runs
 * on every REST request): a site with the switch off stops at the options already in memory.
 */
function WPADR_jwt_serving_namespace() {
	static $namespace = array();
	$blog = get_current_blog_id();
	if ( ! isset( $namespace[ $blog ] ) ) {
		$namespace[ $blog ] = '';
		if ( WPADR_jwt_switch_on() ) {
			$state = WPADR_jwt_state();
			if ( $state['serving'] ) {
				$namespace[ $blog ] = WPADR_jwt_namespace( $state['settings'] );
			}
		}
	}
	return $namespace[ $blog ];
}

add_action( 'rest_api_init', 'WPADR_jwt_register_routes', 99 );
function WPADR_jwt_register_routes() {
	$namespace = WPADR_jwt_serving_namespace();
	if ( '' === $namespace ) {
		return;
	}
	// Second guard against a double set of routes: whoever registered this namespace before us keeps it.
	if ( in_array( strtolower( $namespace ), array_map( 'strtolower', rest_get_server()->get_namespaces() ), true ) ) {
		return;
	}
	$routes = array(
		array( '/auth', 'POST', 'WPADR_jwt_route_auth' ),
		array( '/auth/validate', 'GET, POST', 'WPADR_jwt_route_validate' ),
		array( '/auth/revoke', 'POST', 'WPADR_jwt_route_revoke' ),
		array( '/users', 'POST', 'WPADR_jwt_route_register' ),
		array( '/users', 'DELETE', 'WPADR_jwt_route_delete_user' ),
		array( '/user/reset_password', 'POST, PUT', 'WPADR_jwt_route_reset_password' ),
	);
	foreach ( $routes as $definition ) {
		list( $route, $methods, $handler ) = $definition;
		register_rest_route( $namespace, $route, array(
			'methods'             => $methods,
			'callback'            => function ( $request ) use ( $handler ) {
				return WPADR_jwt_dispatch( $handler, $request );
			},
			// Public on purpose: these are the login, registration and password reset of the app.
			// Each route checks by itself what the request must carry (app key, password, token).
			'permission_callback' => '__return_true',
		) );
	}
}

/** Runs a route and turns its result, or its error, into the answer Simple JWT Login gives. */
function WPADR_jwt_dispatch( $handler, $request ) {
	$settings = WPADR_jwt_settings();
	try {
		$response = new WP_REST_Response( call_user_func( $handler, WPADR_jwt_request_vars( $request ), $settings, $request ), 200 );
	} catch ( Exception $exception ) {
		$status = 400;
		if ( $exception instanceof WPADR_Jwt_Exception && $exception->http_status ) {
			$status = (int) $exception->http_status;
		} elseif ( in_array( (int) $exception->getCode(), array( 55, 14, 13, 12 ), true ) ) {
			// Revoked, expired or not-yet-valid token.
			$status = 401;
		}
		$response = new WP_REST_Response( array(
			'success' => false,
			'data'    => array(
				'message'   => $exception->getMessage(),
				'errorCode' => (int) $exception->getCode(),
			),
		), $status );
		if ( $exception instanceof WPADR_Jwt_Exception && $exception->retry_after ) {
			$response->header( 'Retry-After', (string) max( 1, (int) $exception->retry_after ) );
		}
	}
	return $response;
}

/**
 * Marks every answer of the app login namespace with a header that says Mobile Admin gave it.
 * The page «Accesso app» reads it on the namespace index to show who is answering right now.
 */
add_filter( 'rest_post_dispatch', 'WPADR_jwt_mark_response', 10, 3 );
function WPADR_jwt_mark_response( $response, $server, $request ) {
	$namespace = WPADR_jwt_serving_namespace();
	if ( '' !== $namespace && $response instanceof WP_HTTP_Response && $request instanceof WP_REST_Request ) {
		$route = strtolower( (string) $request->get_route() );
		$base  = '/' . strtolower( $namespace );
		if ( $route === $base || 0 === strpos( $route, $base . '/' ) ) {
			$response->header( 'X-Mobile-Admin-Auth', '1' );
		}
	}
	return $response;
}

/** Shortcut: an error with a Simple JWT Login code. */
function WPADR_jwt_error( $message, $code = 0 ) {
	return new WPADR_Jwt_Exception( $message, (int) $code );
}

/**
 * The request as Simple JWT Login reads it: $_REQUEST (address and form fields, with WordPress's
 * slashes) and, on top, the fields of the body read raw (JSON, or a form). Reading them the same
 * way is what keeps a password with a quote or a backslash working for the accounts created so far.
 */
function WPADR_jwt_request_vars( $request ) {
	$vars = $_REQUEST; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- public API route of the app, no browser session involved
	$type = isset( $_SERVER['CONTENT_TYPE'] ) ? strtolower( trim( explode( ';', (string) $_SERVER['CONTENT_TYPE'] )[0] ) ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- only compared with a constant
	if ( 'multipart/form-data' !== $type ) {
		$body = (string) $request->get_body();
		if ( '' !== $body ) {
			$parsed = json_decode( $body, true );
			if ( empty( $parsed ) ) {
				$parsed = array();
				parse_str( $body, $parsed );
			}
			if ( is_array( $parsed ) ) {
				$vars = array_merge( $vars, $parsed );
			}
		}
	}
	return $vars;
}

/** A request field as clean text ('' for an array). Null when the field is not there. */
function WPADR_jwt_field( $vars, $key ) {
	return isset( $vars[ $key ] ) ? sanitize_text_field( $vars[ $key ] ) : null;
}

/** Password as sent by the app (base64 only on a site that asks for it). */
function WPADR_jwt_password_field( $vars, $key, $settings ) {
	$password = (string) WPADR_jwt_field( $vars, $key );
	if ( ! empty( $settings['auth_password_base64'] ) ) {
		$password = (string) base64_decode( $password ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode -- the app sends the password base64-encoded when this option is on
	}
	return $password;
}

/** Name of the request field that carries the app key (AUTH_KEY unless the site changed it). */
function WPADR_jwt_auth_key_name( $settings ) {
	$name = WPADR_jwt_get( $settings, 'auth_code_key', '' );
	return ( is_string( $name ) && '' !== $name ) ? $name : 'AUTH_KEY';
}

/**
 * The app keys of the site as [ code, role, expiration ] rows (old installs stored plain strings).
 */
function WPADR_jwt_auth_codes( $settings ) {
	$codes = array();
	foreach ( (array) WPADR_jwt_get( $settings, 'auth_codes', array() ) as $entry ) {
		if ( is_array( $entry ) && isset( $entry['code'], $entry['role'], $entry['expiration_date'] ) ) {
			$codes[] = array( (string) $entry['code'], (string) $entry['role'], (string) $entry['expiration_date'] );
		} elseif ( is_scalar( $entry ) ) {
			$codes[] = array( (string) $entry, '', '' );
		}
	}
	return $codes;
}

/**
 * The app key row matching the request, or null. Compared in constant time; an expired key is skipped.
 */
function WPADR_jwt_matching_auth_code( $vars, $settings ) {
	$name = WPADR_jwt_auth_key_name( $settings );
	if ( ! isset( $vars[ $name ] ) || ! is_scalar( $vars[ $name ] ) || '' === (string) $vars[ $name ] ) {
		return null;
	}
	$given = (string) $vars[ $name ];
	$found = null;
	foreach ( WPADR_jwt_auth_codes( $settings ) as $row ) {
		list( $code, , $expires ) = $row;
		if ( '' === $code ) {
			continue;
		}
		$match = hash_equals( $code, $given );
		if ( $match && null === $found && ( '' === $expires || strtotime( $expires ) >= time() ) ) {
			$found = $row;
		}
	}
	return $found;
}

/** The token of the request: Authorization header first, then the address/body field (JWT). */
function WPADR_jwt_token_from_request( $vars, $settings, $request ) {
	$keys = (array) WPADR_jwt_get( $settings, 'request_keys', array() );
	if ( WPADR_jwt_get( $settings, 'request_jwt_header', true ) ) {
		$name  = isset( $keys['header'] ) && '' !== (string) $keys['header'] ? (string) $keys['header'] : 'Authorization';
		$value = $request->get_header( $name );
		if ( null === $value && function_exists( 'getallheaders' ) ) {
			$headers = array_change_key_case( (array) getallheaders(), CASE_LOWER );
			$value   = isset( $headers[ strtolower( $name ) ] ) ? $headers[ strtolower( $name ) ] : null;
		}
		if ( is_string( $value ) && preg_match( '/^(?:(\w+)\s+)?([\w\-.]+)$/mi', $value, $matches )
			&& ( empty( $matches[1] ) || 'bearer' === strtolower( $matches[1] ) ) ) {
			return $matches[2];
		}
	}
	if ( WPADR_jwt_get( $settings, 'request_jwt_url', true ) ) {
		$name  = isset( $keys['url'] ) && '' !== (string) $keys['url'] ? strtolower( (string) $keys['url'] ) : 'jwt';
		$lower = array_change_key_case( $vars, CASE_LOWER );
		if ( isset( $lower[ $name ] ) && is_string( $lower[ $name ] ) ) {
			return $lower[ $name ];
		}
	}
	return '';
}

// ---------------------------------------------------------------------------------------------
// Tokens
// ---------------------------------------------------------------------------------------------

function WPADR_jwt_b64url_encode( $data ) {
	return rtrim( strtr( base64_encode( $data ), '+/', '-_' ), '=' ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode -- JWT encoding
}

function WPADR_jwt_b64url_decode( $data ) {
	$data      = strtr( (string) $data, '-_', '+/' );
	$remainder = strlen( $data ) % 4;
	if ( $remainder ) {
		$data .= str_repeat( '=', 4 - $remainder );
	}
	return (string) base64_decode( $data ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode -- JWT decoding
}

/** Decodes one JSON part of a token; a JSON error is Simple JWT Login's error 22. */
function WPADR_jwt_json_decode( $json ) {
	$value = json_decode( $json, true, 512, JSON_BIGINT_AS_STRING );
	$error = json_last_error();
	if ( $error ) {
		$messages = array(
			JSON_ERROR_DEPTH          => 'Maximum stack depth exceeded',
			JSON_ERROR_STATE_MISMATCH => 'Invalid or malformed JSON',
			JSON_ERROR_CTRL_CHAR      => 'Unexpected control character found',
			JSON_ERROR_SYNTAX         => 'Syntax error, malformed JSON',
			JSON_ERROR_UTF8           => 'Malformed UTF-8 characters',
		);
		throw WPADR_jwt_error( isset( $messages[ $error ] ) ? $messages[ $error ] : sprintf( 'Unknown JSON error: %s', $error ), 22 );
	}
	return $value;
}

/** Signs a token with the site's key and algorithm. */
function WPADR_jwt_sign( $payload, $settings ) {
	$algorithm  = (string) WPADR_jwt_get( $settings, 'jwt_algorithm', 'HS256' );
	$algorithms = WPADR_jwt_algorithms();
	if ( ! isset( $algorithms[ $algorithm ] ) ) {
		throw WPADR_jwt_error( 'Algorithm not supported', 15 );
	}
	$segments = array(
		WPADR_jwt_b64url_encode( (string) wp_json_encode( array( 'typ' => 'JWT', 'alg' => $algorithm ) ) ),
		WPADR_jwt_b64url_encode( (string) wp_json_encode( $payload ) ),
	);
	$segments[] = WPADR_jwt_b64url_encode( hash_hmac( $algorithms[ $algorithm ], implode( '.', $segments ), WPADR_jwt_signing_key( $settings ), true ) );
	return implode( '.', $segments );
}

/**
 * Checks a token (format, algorithm, signature, dates) and returns its claims.
 * Same checks, in the same order and with the same error codes, as Simple JWT Login 3.6.8.
 */
function WPADR_jwt_verify( $jwt, $settings ) {
	$parts = explode( '.', (string) $jwt );
	if ( 3 !== count( $parts ) ) {
		throw WPADR_jwt_error( 'Wrong number of segments', 2 );
	}
	list( $head64, $body64, $sign64 ) = $parts;
	$header = WPADR_jwt_json_decode( WPADR_jwt_b64url_decode( $head64 ) );
	if ( ! is_array( $header ) ) {
		throw WPADR_jwt_error( 'Invalid header encoding', 3 );
	}
	$payload = WPADR_jwt_json_decode( WPADR_jwt_b64url_decode( $body64 ) );
	if ( ! is_array( $payload ) ) {
		throw WPADR_jwt_error( 'Invalid claims encoding', 4 );
	}
	$key = WPADR_jwt_signing_key( $settings );
	if ( '' === $key ) {
		throw WPADR_jwt_error( 'Key may not be empty', 1 );
	}
	if ( empty( $header['alg'] ) || ! is_string( $header['alg'] ) ) {
		throw WPADR_jwt_error( 'Empty algorithm', 6 );
	}
	$algorithms = WPADR_jwt_algorithms();
	if ( ! isset( $algorithms[ $header['alg'] ] ) && ! in_array( $header['alg'], array( 'RS256', 'RS384', 'RS512' ), true ) ) {
		throw WPADR_jwt_error( 'Algorithm not supported', 7 );
	}
	// Only the algorithm the site is set to: a token signed with anything else is refused.
	if ( $header['alg'] !== (string) WPADR_jwt_get( $settings, 'jwt_algorithm', 'HS256' ) || ! isset( $algorithms[ $header['alg'] ] ) ) {
		throw WPADR_jwt_error( 'Algorithm not allowed', 8 );
	}
	$expected = hash_hmac( $algorithms[ $header['alg'] ], $head64 . '.' . $body64, $key, true );
	if ( ! hash_equals( $expected, WPADR_jwt_b64url_decode( $sign64 ) ) ) {
		throw WPADR_jwt_error( 'Signature verification failed', 11 );
	}
	$now = time();
	if ( isset( $payload['nbf'] ) && $payload['nbf'] > $now + WPADR_JWT_LEEWAY ) {
		throw WPADR_jwt_error( 'Cannot handle token prior to ' . gmdate( 'Y-m-d\TH:i:sO', (int) $payload['nbf'] ), 12 );
	}
	if ( isset( $payload['iat'] ) && $payload['iat'] > $now + WPADR_JWT_LEEWAY ) {
		throw WPADR_jwt_error( 'Cannot handle token prior to ' . gmdate( 'Y-m-d\TH:i:sO', (int) $payload['iat'] ), 13 );
	}
	if ( isset( $payload['exp'] ) && ( $now - WPADR_JWT_LEEWAY ) >= $payload['exp'] ) {
		throw WPADR_jwt_error( 'Expired token', 14 );
	}
	return $payload;
}

/** The claim that says whose token it is (setting «JWT parameter», dots walk into nested claims). */
function WPADR_jwt_user_claim( $payload, $settings ) {
	$parameter = (string) WPADR_jwt_get( $settings, 'jwt_login_by_parameter', WPADR_jwt_get( $settings, 'jwt_email_parameter', '' ) );
	if ( false !== strpos( $parameter, '.' ) ) {
		foreach ( explode( '.', $parameter ) as $part ) {
			if ( ! is_array( $payload ) || ! isset( $payload[ $part ] ) ) {
				throw WPADR_jwt_error( sprintf( 'Unable to find user %s property in JWT.( Settings: %s )', $part, $parameter ), 29 );
			}
			$payload = $payload[ $part ];
		}
		return is_scalar( $payload ) ? (string) $payload : '';
	}
	if ( ! isset( $payload[ $parameter ] ) ) {
		throw WPADR_jwt_error( sprintf( 'Unable to find user %s property in JWT.', $parameter ), 30 );
	}
	return is_scalar( $payload[ $parameter ] ) ? (string) $payload[ $parameter ] : '';
}

/** The WordPress user a claim points to (by email, ID or username, as the site is set), or null. */
function WPADR_jwt_user_by_claim( $value, $settings ) {
	switch ( (int) WPADR_jwt_get( $settings, 'jwt_login_by', 0 ) ) {
		case 0:
			$user = get_user_by( 'email', $value );
			break;
		case 2:
			$user = get_user_by( 'login', $value );
			break;
		default:
			$user = get_userdata( (int) $value );
	}
	return ( $user instanceof WP_User ) ? $user : null;
}

/** Stops with error 55 when the user revoked this token (logout). */
function WPADR_jwt_assert_not_revoked( $user_id, $jwt ) {
	foreach ( (array) get_user_meta( $user_id, WPADR_JWT_REVOKED_META, false ) as $revoked ) {
		if ( is_string( $revoked ) && hash_equals( $revoked, (string) $jwt ) ) {
			throw WPADR_jwt_error( 'This JWT is invalid.', 55 );
		}
	}
}

/** Token → user, with every check. $not_found is the error for a token whose user no longer exists. */
function WPADR_jwt_user_from_token( $jwt, $settings ) {
	$payload = WPADR_jwt_verify( $jwt, $settings );
	$user    = WPADR_jwt_user_by_claim( WPADR_jwt_user_claim( $payload, $settings ), $settings );
	if ( null === $user ) {
		throw WPADR_jwt_error( 'User not found.', 24 );
	}
	return $user;
}

/** The claims of a new token, in the order and with the values Simple JWT Login writes. */
function WPADR_jwt_build_payload( $user, $settings ) {
	$enabled = (array) WPADR_jwt_get( $settings, 'jwt_payload', array() );
	$payload = array( 'iat' => time() );
	foreach ( array( 'exp', 'email', 'id', 'site', 'username', 'iss' ) as $claim ) {
		if ( ! in_array( $claim, $enabled, true ) ) {
			continue;
		}
		switch ( $claim ) {
			case 'exp':
				$payload['exp'] = time() + (int) WPADR_jwt_get( $settings, 'jwt_auth_ttl', 60 ) * 60;
				break;
			case 'email':
				$payload['email'] = $user->get( 'user_email' );
				break;
			case 'id':
				$payload['id'] = $user->get( 'ID' );
				break;
			case 'site':
				$payload['site'] = site_url();
				break;
			case 'username':
				$payload['username'] = $user->get( 'user_login' );
				break;
			case 'iss':
				$payload['iss'] = WPADR_jwt_issuer( $settings );
				break;
		}
	}
	return $payload;
}

function WPADR_jwt_issuer( $settings ) {
	return isset( $settings['jwt_auth_iss'] ) ? (string) $settings['jwt_auth_iss'] : site_url();
}

/** The user as the apps receive it: WordPress's user row without the password. */
function WPADR_jwt_user_array( $user ) {
	$data = $user->to_array();
	unset( $data['user_pass'] );
	// The password-reset key (hashed) is of no use to an app: the field stays, empty.
	if ( isset( $data['user_activation_key'] ) ) {
		$data['user_activation_key'] = '';
	}
	return $data;
}

/** Role for a new account. Never one that can work in the dashboard, whatever the settings say. */
function WPADR_jwt_safe_role( $role ) {
	$role   = sanitize_key( (string) $role );
	$object = '' !== $role ? get_role( $role ) : null;
	if ( '' === $role ) {
		return 'subscriber';
	}
	if ( $object ) {
		foreach ( array( 'edit_posts', 'manage_options', 'list_users', 'edit_users', 'manage_woocommerce', 'upload_files' ) as $capability ) {
			if ( $object->has_cap( $capability ) ) {
				return 'subscriber';
			}
		}
	}
	return $role;
}

// ---------------------------------------------------------------------------------------------
// Limit on attempts
// ---------------------------------------------------------------------------------------------

/**
 * [ attempts, seconds ] per kind of attempt. Only failures count for the login and the reset
 * code; registrations and reset emails count every request. Filter `wpadr_jwt_limits`.
 *
 * The per-address limits are wide on purpose: an app that goes through its Cloud Functions, or a
 * site that calls itself, reaches the site from one address for all its customers.
 */
function WPADR_jwt_limits() {
	return (array) apply_filters( 'wpadr_jwt_limits', array(
		'login_account' => array( 10, 15 * MINUTE_IN_SECONDS ),  // wrong passwords for one account from one address
		'login_ip'      => array( 300, 15 * MINUTE_IN_SECONDS ), // wrong passwords from one address
		'register_ip'   => array( 60, HOUR_IN_SECONDS ),         // registrations from one address
		'reset_account' => array( 5, HOUR_IN_SECONDS ),          // reset emails for one account
		'reset_ip'      => array( 20, HOUR_IN_SECONDS ),         // reset emails asked from one address
		'code_account'  => array( 10, 15 * MINUTE_IN_SECONDS ),  // wrong reset codes for one account from one address
	) );
}

/** Address of the caller. REMOTE_ADDR only: a forwarded-for header can be written by the caller. */
function WPADR_jwt_client_ip() {
	$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? (string) $_SERVER['REMOTE_ADDR'] : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- validated on the next line
	return filter_var( $ip, FILTER_VALIDATE_IP ) ? $ip : '';
}

function WPADR_jwt_throttle_name( $bucket, $id ) {
	return 'wpadr_jt_' . md5( $bucket . '|' . $id );
}

/** Seconds still to wait for this bucket, 0 when free. */
function WPADR_jwt_throttle_left( $bucket, $id ) {
	$limits = WPADR_jwt_limits();
	if ( '' === (string) $id || empty( $limits[ $bucket ][0] ) ) {
		return 0;
	}
	$record = get_site_transient( WPADR_jwt_throttle_name( $bucket, $id ) );
	if ( ! is_array( $record ) || empty( $record['until'] ) || $record['until'] <= time() ) {
		return 0;
	}
	return ( (int) $record['n'] >= (int) $limits[ $bucket ][0] ) ? (int) $record['until'] - time() : 0;
}

/** Counts one attempt. The window starts at the first attempt and does not stretch. */
function WPADR_jwt_throttle_hit( $bucket, $id ) {
	$limits = WPADR_jwt_limits();
	if ( '' === (string) $id || empty( $limits[ $bucket ][0] ) ) {
		return;
	}
	$name   = WPADR_jwt_throttle_name( $bucket, $id );
	$record = get_site_transient( $name );
	if ( ! is_array( $record ) || empty( $record['until'] ) || $record['until'] <= time() ) {
		$record = array( 'n' => 0, 'until' => time() + (int) $limits[ $bucket ][1] );
	}
	++$record['n'];
	set_site_transient( $name, $record, max( 1, (int) $record['until'] - time() ) );
}

/** Forgets the attempts of a bucket (after a good login). No write when there is nothing to forget. */
function WPADR_jwt_throttle_clear( $bucket, $id ) {
	$name = WPADR_jwt_throttle_name( $bucket, $id );
	if ( false !== get_site_transient( $name ) ) {
		delete_site_transient( $name );
	}
}

/** Stops with HTTP 429 when one of the [ bucket, id ] pairs is over its limit. */
function WPADR_jwt_throttle_guard( $pairs ) {
	foreach ( $pairs as $pair ) {
		$left = WPADR_jwt_throttle_left( $pair[0], $pair[1] );
		if ( $left > 0 ) {
			$exception              = new WPADR_Jwt_Exception( 'Too many attempts. Please try again later.', 429 );
			$exception->http_status = 429;
			$exception->retry_after = $left;
			throw $exception;
		}
	}
}

/** Bucket id «this account from this address». */
function WPADR_jwt_account_id( $account ) {
	return WPADR_jwt_client_ip() . '|' . strtolower( trim( (string) $account ) );
}

// ---------------------------------------------------------------------------------------------
// POST auth — login
// ---------------------------------------------------------------------------------------------

function WPADR_jwt_route_auth( $vars, $settings, $request ) {
	WPADR_jwt_assert_authentication_enabled( $settings );
	WPADR_jwt_assert_auth_key_for_login( $vars, $settings );

	if ( ! isset( $vars['email'] ) && ! isset( $vars['username'] ) && ! isset( $vars['login'] ) ) {
		throw WPADR_jwt_error( 'The email, username, or login parameter is missing from the request.', 46 );
	}
	if ( ! isset( $vars['password'] ) && ! isset( $vars['password_hash'] ) ) {
		throw WPADR_jwt_error( 'The password or password_hash parameter is missing from request.', 47 );
	}

	if ( isset( $vars['username'] ) ) {
		$account = (string) WPADR_jwt_field( $vars, 'username' );
	} elseif ( isset( $vars['email'] ) ) {
		$account = (string) WPADR_jwt_field( $vars, 'email' );
	} else {
		$account = is_scalar( $vars['login'] ) ? (string) $vars['login'] : '';
	}
	$ip = WPADR_jwt_client_ip();
	WPADR_jwt_throttle_guard( array(
		array( 'login_account', WPADR_jwt_account_id( $account ) ),
		array( 'login_ip', $ip ),
	) );

	$user = false;
	if ( isset( $vars['username'] ) ) {
		$user = get_user_by( 'login', $account );
	} elseif ( isset( $vars['email'] ) ) {
		$user = get_user_by( 'email', $account );
	} else {
		$user = get_user_by( 'login', $account );
		if ( ! $user && false !== strpos( $account, '@' ) ) {
			$user = get_user_by( 'email', $account );
		}
	}

	// Login with the password hash instead of the password is not offered: without `password` the
	// answer is the same as for a wrong password.
	$valid = false;
	if ( $user instanceof WP_User && isset( $vars['password'] ) ) {
		$valid = wp_check_password( WPADR_jwt_password_field( $vars, 'password', $settings ), $user->user_pass );
	}
	if ( ! $valid ) {
		// Per-account count only for an account that exists: a made-up name has no password to
		// guess, and counting each one would let a flood of names fill the database.
		if ( $user instanceof WP_User ) {
			WPADR_jwt_throttle_hit( 'login_account', WPADR_jwt_account_id( $account ) );
		}
		WPADR_jwt_throttle_hit( 'login_ip', $ip );
		throw WPADR_jwt_error( 'Wrong user credentials.', 48 );
	}
	WPADR_jwt_throttle_clear( 'login_account', WPADR_jwt_account_id( $account ) );

	return array(
		'success' => true,
		'data'    => array(
			'jwt' => WPADR_jwt_sign( WPADR_jwt_build_payload( $user, $settings ), $settings ),
		),
	);
}

function WPADR_jwt_assert_authentication_enabled( $settings ) {
	if ( empty( $settings['allow_authentication'] ) ) {
		throw WPADR_jwt_error( 'Authentication is not enabled.', 45 );
	}
}

function WPADR_jwt_assert_auth_key_for_login( $vars, $settings ) {
	if ( WPADR_jwt_get( $settings, 'auth_requires_auth_code', false ) && null === WPADR_jwt_matching_auth_code( $vars, $settings ) ) {
		throw WPADR_jwt_error( sprintf( 'Invalid Auth Code ( %s ) provided.', WPADR_jwt_auth_key_name( $settings ) ), 27 );
	}
}

// ---------------------------------------------------------------------------------------------
// GET|POST auth/validate — token check
// ---------------------------------------------------------------------------------------------

function WPADR_jwt_route_validate( $vars, $settings, $request ) {
	WPADR_jwt_assert_authentication_enabled( $settings );

	$jwt = WPADR_jwt_token_from_request( $vars, $settings, $request );
	if ( '' === $jwt ) {
		throw WPADR_jwt_error( 'The `jwt` parameter is missing.', 53 );
	}
	$user = WPADR_jwt_user_from_token( $jwt, $settings );
	WPADR_jwt_assert_not_revoked( $user->ID, $jwt );

	list( $head64, $body64 ) = explode( '.', $jwt );
	$token = array(
		'token'   => $jwt,
		'header'  => json_decode( WPADR_jwt_b64url_decode( $head64 ), true ),
		'payload' => json_decode( WPADR_jwt_b64url_decode( $body64 ), true ),
	);
	if ( isset( $token['payload']['exp'] ) ) {
		$token['expire_in'] = $token['payload']['exp'] - time();
	}

	return array(
		'success' => true,
		'data'    => array(
			'user'  => WPADR_jwt_user_array( $user ),
			'roles' => isset( $user->roles ) ? $user->roles : array(),
			// A list with one element: every app reads data.jwt[0].
			'jwt'   => array( $token ),
		),
	);
}

// ---------------------------------------------------------------------------------------------
// POST auth/revoke — logout
// ---------------------------------------------------------------------------------------------

function WPADR_jwt_route_revoke( $vars, $settings, $request ) {
	WPADR_jwt_assert_authentication_enabled( $settings );
	WPADR_jwt_assert_auth_key_for_login( $vars, $settings );

	$jwt = WPADR_jwt_token_from_request( $vars, $settings, $request );
	if ( '' === $jwt ) {
		throw WPADR_jwt_error( 'The `jwt` parameter is missing.', 53 );
	}
	$user    = WPADR_jwt_user_from_token( $jwt, $settings );
	$revoked = (array) get_user_meta( $user->ID, WPADR_JWT_REVOKED_META, false );

	// Housekeeping: revoked tokens that have expired by now are of no use.
	foreach ( $revoked as $old ) {
		$parts  = is_string( $old ) ? explode( '.', $old ) : array();
		$claims = isset( $parts[1] ) ? json_decode( WPADR_jwt_b64url_decode( $parts[1] ), true ) : null;
		if ( isset( $claims['exp'] ) && $claims['exp'] < time() ) {
			delete_user_meta( $user->ID, WPADR_JWT_REVOKED_META, $old );
		}
	}
	foreach ( $revoked as $old ) {
		if ( is_string( $old ) && hash_equals( $old, $jwt ) ) {
			throw WPADR_jwt_error( 'Token was already revoked.', 0 );
		}
	}
	add_user_meta( $user->ID, WPADR_JWT_REVOKED_META, $jwt, false );

	return array(
		'success' => true,
		'message' => 'Token was revoked.',
		'data'    => array(
			'jwt' => array( $jwt ),
		),
	);
}

// ---------------------------------------------------------------------------------------------
// POST users — registration
// ---------------------------------------------------------------------------------------------

function WPADR_jwt_route_register( $vars, $settings, $request ) {
	if ( empty( $settings['allow_register'] ) ) {
		throw WPADR_jwt_error( 'Register is not allowed.', 31 );
	}
	$key_name = WPADR_jwt_auth_key_name( $settings );
	$key_row  = WPADR_jwt_matching_auth_code( $vars, $settings );
	if ( ( WPADR_jwt_get( $settings, 'require_register_auth', true ) || isset( $vars[ $key_name ] ) ) && null === $key_row ) {
		throw WPADR_jwt_error( sprintf( 'Invalid Auth Code ( %s ) provided.', $key_name ), 32 );
	}
	$random = (bool) WPADR_jwt_get( $settings, 'random_password', false );
	if ( ! isset( $vars['email'] ) || ( ! isset( $vars['password'] ) && ! $random ) ) {
		throw WPADR_jwt_error( 'Missing email or password.', 35 );
	}
	if ( ! is_string( $vars['email'] ) || ! is_email( $vars['email'] ) ) {
		throw WPADR_jwt_error( 'Invalid email address.', 36 );
	}
	$email   = (string) WPADR_jwt_field( $vars, 'email' );
	$domains = trim( (string) WPADR_jwt_get( $settings, 'register_domain', '' ) );
	if ( '' !== $domains ) {
		$parts = explode( '@', $email );
		if ( ! isset( $parts[1] ) || ! in_array( $parts[1], array_map( 'trim', explode( ',', $domains ) ), true ) ) {
			throw WPADR_jwt_error( 'This website does not allows users from this domain.', 37 );
		}
	}

	$ip = WPADR_jwt_client_ip();
	WPADR_jwt_throttle_guard( array( array( 'register_ip', $ip ) ) );
	WPADR_jwt_throttle_hit( 'register_ip', $ip );

	$username = isset( $vars['user_login'] ) && '' !== (string) WPADR_jwt_field( $vars, 'user_login' ) ? (string) WPADR_jwt_field( $vars, 'user_login' ) : $email;
	if ( username_exists( $username ) || email_exists( $email ) ) {
		throw WPADR_jwt_error( 'User already exists.', 38 );
	}

	$password = $random
		? wp_generate_password( max( 8, (int) WPADR_jwt_get( $settings, 'random_password_length', 10 ) ) )
		: (string) WPADR_jwt_field( $vars, 'password' );

	// The role of the site, or the one tied to the app key that was used.
	$role = (string) WPADR_jwt_get( $settings, 'new_user_profile', 'subscriber' );
	if ( $key_row && '' !== $key_row[1] ) {
		$role = $key_row[1];
	}

	$userdata = array(
		'user_pass'  => $password,
		'user_login' => $username,
		'user_email' => $email,
	);
	// Profile fields an app may send along. Nothing that decides access (role, status, keys).
	foreach ( array( 'user_nicename', 'user_url', 'display_name', 'nickname', 'first_name', 'last_name', 'description', 'locale' ) as $field ) {
		if ( isset( $vars[ $field ] ) && is_scalar( $vars[ $field ] ) ) {
			$userdata[ $field ] = (string) $vars[ $field ];
		}
	}
	$user_id = wp_insert_user( $userdata );
	if ( ! is_int( $user_id ) ) {
		throw WPADR_jwt_error( is_wp_error( $user_id ) ? $user_id->get_error_message( $user_id->get_error_code() ) : 'User could not be created.', 52 );
	}
	$user = new WP_User( $user_id );
	$user->set_role( WPADR_jwt_safe_role( $role ) );

	$response = array(
		'success' => true,
		'id'      => $user->get( 'ID' ),
		'message' => 'User was successfully created.',
		'user'    => WPADR_jwt_user_array( $user ),
		'roles'   => isset( $user->roles ) ? $user->roles : array(),
	);
	if ( WPADR_jwt_get( $settings, 'register_jwt', false ) ) {
		$payload = ! empty( $settings['allow_authentication'] )
			? WPADR_jwt_build_payload( $user, $settings )
			: array(
				'email'    => $user->get( 'user_email' ),
				'id'       => $user->get( 'ID' ),
				'username' => $user->get( 'user_login' ),
				'iat'      => time(),
				'iss'      => WPADR_jwt_issuer( $settings ),
			);
		$response['jwt'] = WPADR_jwt_sign( $payload, $settings );
	}
	return $response;
}

// ---------------------------------------------------------------------------------------------
// DELETE users — the customer deletes their own account from the app
// ---------------------------------------------------------------------------------------------

/**
 * Removes the account the token belongs to, as Simple JWT Login 3.6.8 does: on a network the
 * customer is removed from this site (WordPress keeps the network account, which other sites of
 * the network may use), on a single site the account is deleted. Only where the site allows it.
 *
 * Never an account that can work in the dashboard: deleting an administrator through a route an
 * app can reach is not something a token should be able to do.
 */
function WPADR_jwt_route_delete_user( $vars, $settings, $request ) {
	if ( ! WPADR_jwt_get( $settings, 'allow_delete', false ) ) {
		throw WPADR_jwt_error( 'Delete is not enabled.', 39 );
	}
	$jwt = WPADR_jwt_token_from_request( $vars, $settings, $request );
	if ( '' === $jwt ) {
		throw WPADR_jwt_error( 'The `jwt` parameter is missing.', 42 );
	}
	if ( WPADR_jwt_get( $settings, 'require_delete_auth', true ) && null === WPADR_jwt_matching_auth_code( $vars, $settings ) ) {
		throw WPADR_jwt_error( sprintf( 'Missing AUTH KEY ( %s ).', WPADR_jwt_auth_key_name( $settings ) ), 40 );
	}

	// Which account: the claim and the lookup chosen for deletion (same numbering as for the login).
	$payload = WPADR_jwt_verify( $jwt, $settings );
	$lookup  = array(
		'jwt_login_by_parameter' => (string) WPADR_jwt_get( $settings, 'jwt_delete_by_parameter', '' ),
		'jwt_login_by'           => (int) WPADR_jwt_get( $settings, 'delete_user_by', 0 ),
	);
	$user = WPADR_jwt_user_by_claim( WPADR_jwt_user_claim( $payload, $lookup ), $lookup );
	if ( null === $user ) {
		throw WPADR_jwt_error( 'User not found.', 24 );
	}
	WPADR_jwt_assert_not_revoked( $user->ID, $jwt );

	foreach ( array( 'edit_posts', 'manage_options', 'list_users', 'edit_users', 'manage_woocommerce', 'upload_files' ) as $capability ) {
		if ( is_super_admin( $user->ID ) || user_can( $user, $capability ) ) {
			$exception              = new WPADR_Jwt_Exception( 'This account cannot be deleted from the app.', 0 );
			$exception->http_status = 403;
			throw $exception;
		}
	}

	require_once ABSPATH . 'wp-admin/includes/user.php';
	$user_id = $user->get( 'ID' );
	if ( false === wp_delete_user( (int) $user_id ) ) {
		throw WPADR_jwt_error( 'User not found.', 24 );
	}
	return array(
		'message' => 'User was successfully deleted.',
		'id'      => $user_id,
	);
}

// ---------------------------------------------------------------------------------------------
// POST|PUT user/reset_password — forgotten password
// ---------------------------------------------------------------------------------------------

/**
 * True when the site can send the shop's own forgotten-password e-mail: WooCommerce is active,
 * its «My account» page exists (the link in the e-mail leads there) and that e-mail is enabled.
 */
function WPADR_jwt_shop_reset_available() {
	if ( ! function_exists( 'WC' ) || ! function_exists( 'wc_get_page_id' ) || wc_get_page_id( 'myaccount' ) <= 0 ) {
		return false;
	}
	$emails = WC()->mailer()->get_emails();
	return isset( $emails['WC_Email_Customer_Reset_Password'] ) && $emails['WC_Email_Customer_Reset_Password']->is_enabled();
}

/**
 * What happens when a customer asks for a new password from the app:
 *   'shop'  WooCommerce's e-mail, link to the site's «My account» page (Mobile Admin's choice, 2.25.0)
 *   'wp'    WordPress's own e-mail with its link
 *   'code'  an e-mail with a code to type in the app (text set in Simple JWT Login)
 *   'none'  the code is only saved, nothing is sent
 * Mobile Admin's choice (`ma_reset_flow`: shop | wp) wins over the flow copied from Simple JWT Login.
 */
function WPADR_jwt_reset_flow( $settings ) {
	$choice = (string) WPADR_jwt_get( $settings, 'ma_reset_flow', '' );
	if ( 'shop' === $choice ) {
		// Without WooCommerce the customer still gets an e-mail: WordPress's.
		return WPADR_jwt_shop_reset_available() ? 'shop' : 'wp';
	}
	if ( 'wp' === $choice ) {
		return 'wp';
	}
	$flow = WPADR_jwt_get( $settings, 'jwt_reset_password_flow', 0 );
	if ( is_numeric( $flow ) ) {
		$names = array( 0 => 'none', 1 => 'wp', 2 => 'code' );
		if ( isset( $names[ (int) $flow ] ) ) {
			return $names[ (int) $flow ];
		}
	}
	return 'invalid';
}

function WPADR_jwt_route_reset_password( $vars, $settings, $request ) {
	if ( empty( $settings['allow_reset_password'] ) ) {
		throw WPADR_jwt_error( 'Reset Password is not allowed.', 56 );
	}
	if ( ! empty( $settings['reset_password_requires_auth_code'] ) && null === WPADR_jwt_matching_auth_code( $vars, $settings ) ) {
		throw WPADR_jwt_error( sprintf( 'Invalid Auth Code ( %s ) provided.', WPADR_jwt_auth_key_name( $settings ) ), 58 );
	}
	$method = isset( $_SERVER['REQUEST_METHOD'] ) ? strtoupper( (string) $_SERVER['REQUEST_METHOD'] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- only compared with constants
	if ( 'PUT' === $method ) {
		return WPADR_jwt_reset_change_password( $vars, $settings, $request );
	}
	if ( 'POST' === $method ) {
		return WPADR_jwt_reset_send( $vars, $settings );
	}
	throw WPADR_jwt_error( 'Route called with invalid request method.', 57 );
}

/** POST: starts the reset (WordPress's own email, an email with a code, or only the code in the database). */
function WPADR_jwt_reset_send( $vars, $settings ) {
	if ( empty( $vars['email'] ) ) {
		throw WPADR_jwt_error( 'Missing email parameter.', 63 );
	}
	$email = (string) WPADR_jwt_field( $vars, 'email' );
	$ip    = WPADR_jwt_client_ip();
	WPADR_jwt_throttle_guard( array(
		array( 'reset_ip', $ip ),
		array( 'reset_account', strtolower( $email ) ),
	) );
	WPADR_jwt_throttle_hit( 'reset_ip', $ip );

	$user = get_user_by( 'email', $email );
	if ( ! $user instanceof WP_User ) {
		throw WPADR_jwt_error( 'Wrong user.', 64 );
	}
	WPADR_jwt_throttle_hit( 'reset_account', strtolower( $email ) );

	switch ( WPADR_jwt_reset_flow( $settings ) ) {
		case 'none':
			get_password_reset_key( $user );
			$message = 'The Code has been saved into the database.';
			break;
		case 'wp':
			retrieve_password( $user->user_login );
			$message = 'Reset password email has been sent.';
			break;
		case 'shop':
			// WooCommerce's «reset password» e-mail: the shop's layout and sender, and a link to
			// the «My account» page of this site, where the customer types the new password.
			$key = get_password_reset_key( $user );
			if ( ! is_wp_error( $key ) ) {
				WC()->mailer(); // loads WooCommerce's e-mails, which listen to this action
				do_action( 'woocommerce_reset_password_notification', $user->user_login, $key );
			}
			$message = 'Reset password email has been sent.';
			break;
		case 'code':
			$code = get_password_reset_key( $user );
			$body = (string) base64_decode( (string) WPADR_jwt_get( $settings, 'jwt_reset_password_email_body', '' ) ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode -- Simple JWT Login stores the email text base64-encoded
			$body = strtr( $body, array(
				'{{CODE}}'       => is_wp_error( $code ) ? '' : (string) $code,
				'{{NAME}}'       => $user->get( 'first_name' ) . $user->get( 'last_name' ),
				'{{USERNAME}}'   => (string) $user->get( 'user_login' ),
				'{{EMAIL}}'      => (string) $user->get( 'user_email' ),
				'{{NICKNAME}}'   => (string) $user->get( 'nickname' ),
				'{{FIRST_NAME}}' => (string) $user->get( 'first_name' ),
				'{{LAST_NAME}}'  => (string) $user->get( 'last_name' ),
				'{{SITE}}'       => site_url(),
				'{{IP}}'         => $ip,
			) );
			$html = 1 === (int) WPADR_jwt_get( $settings, 'jwt_email_type', 0 );
			wp_mail(
				$user->get( 'user_email' ),
				(string) WPADR_jwt_get( $settings, 'jwt_email_subject', '' ),
				$body,
				$html ? 'Content-type: text/html' : array()
			);
			$message = 'Reset password email has been sent.';
			break;
		default:
			throw WPADR_jwt_error( 'Invalid flow type.', 65 );
	}
	return array(
		'success' => true,
		'message' => $message,
	);
}

/** PUT: sets the new password, proven by the emailed code or (where the site allows it) by the user's token. */
function WPADR_jwt_reset_change_password( $vars, $settings, $request ) {
	if ( empty( $vars['email'] ) ) {
		throw WPADR_jwt_error( 'Missing email parameter.', 59 );
	}
	if ( empty( $vars['new_password'] ) ) {
		throw WPADR_jwt_error( 'Missing new_password parameter.', 61 );
	}
	$email        = (string) WPADR_jwt_field( $vars, 'email' );
	$new_password = WPADR_jwt_password_field( $vars, 'new_password', $settings );
	$jwt_allowed  = ! empty( $settings['reset_password_jwt'] );
	if ( ! $jwt_allowed && empty( $vars['code'] ) ) {
		throw WPADR_jwt_error( 'Missing code parameter.', 60 );
	}

	if ( $jwt_allowed && empty( $vars['code'] ) ) {
		// A signed-in user changes their own password: the token must be theirs.
		$jwt = WPADR_jwt_token_from_request( $vars, $settings, $request );
		if ( '' === $jwt ) {
			throw WPADR_jwt_error( 'The `jwt` parameter is missing.', 53 );
		}
		$payload = WPADR_jwt_verify( $jwt, $settings );
		$user    = WPADR_jwt_user_by_claim( WPADR_jwt_user_claim( $payload, $settings ), $settings );
		if ( null === $user || ! is_string( $vars['email'] ) || $user->get( 'user_email' ) !== $vars['email'] ) {
			throw WPADR_jwt_error( 'This JWT can not change your password.', 0 );
		}
		WPADR_jwt_assert_not_revoked( $user->ID, $jwt );
	} else {
		$account = WPADR_jwt_account_id( $email );
		WPADR_jwt_throttle_guard( array( array( 'code_account', $account ) ) );
		$found = get_user_by( 'email', $email );
		$user  = ( $found instanceof WP_User ) ? check_password_reset_key( (string) WPADR_jwt_field( $vars, 'code' ), $found->user_login ) : null;
		if ( ! $user instanceof WP_User ) {
			if ( $found instanceof WP_User ) {
				WPADR_jwt_throttle_hit( 'code_account', $account );
			}
			throw WPADR_jwt_error( 'Invalid code provided.', 62 );
		}
	}
	reset_password( $user, $new_password );

	return array(
		'success' => true,
		'message' => 'User Password has been changed.',
	);
}
