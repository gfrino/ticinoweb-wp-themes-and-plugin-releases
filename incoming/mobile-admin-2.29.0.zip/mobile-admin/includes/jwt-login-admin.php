<?php
/**
 * Gestione App → Accesso app (v2.24.0)
 *
 * One switch per site: who answers the login, registration and «forgotten password» of the app,
 * the «Simple JWT Login» plugin or Mobile Admin (includes/jwt-login.php). The page shows where the
 * site stands in plain words, asks the site itself who is answering right now, and lists what is
 * set, without ever printing a key.
 */

defined( 'ABSPATH' ) || exit;

add_action( 'admin_menu', 'ARD_app_login_menu', 23 );
function ARD_app_login_menu() {
	add_submenu_page(
		'ard_stato_app',
		'Accesso app',
		'Accesso app',
		'manage_options',
		'ard_app_login',
		'ARD_showContent_app_login'
	);
}

/**
 * Red notice in the dashboard when nobody answers the app login on a site that is set up for it:
 * Simple JWT Login was deactivated and the switch is still off. Customers cannot sign in.
 */
add_action( 'admin_notices', 'ARD_app_login_notice' );
function ARD_app_login_notice() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	if ( isset( $_GET['page'] ) && 'ard_app_login' === $_GET['page'] ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read only, picks the screen
		return;
	}
	// Cheap exits: Simple JWT Login is answering, or the site never had an app login.
	if ( WPADR_jwt_sjl_active() ) {
		return;
	}
	if ( ! WPADR_jwt_switch_on() && null === get_option( WPADR_JWT_SJL_OPTION, null ) && null === get_option( WPADR_JWT_OPTION, null ) ) {
		return;
	}
	$state = WPADR_jwt_state();
	if ( ! in_array( $state['code'], array( 'nobody', 'blocked' ), true ) || empty( $state['settings']['allow_authentication'] ) ) {
		return;
	}
	echo '<div class="notice notice-error"><p><strong>App mobile:</strong> su questo sito nessuno risponde all\'accesso dell\'app, quindi i clienti non riescono ad accedere né a registrarsi. <a href="' . esc_url( admin_url( 'admin.php?page=ard_app_login' ) ) . '">Apri «Accesso app»</a>.</p></div>';
}

/**
 * Who may set up the app login on a site that never had one: on a network only the network
 * administrator (ticinoWEB), because it opens a public login on the site and creates its keys.
 */
function ARD_app_login_can_setup() {
	return is_multisite() ? is_super_admin() : current_user_can( 'manage_options' );
}

/** Settings for a site that never had an app login: new keys, the usual choices. */
function ARD_app_login_new_settings() {
	return array(
		'allow_authentication'              => '1',
		'auth_requires_auth_code'           => true,
		'jwt_payload'                       => array( 'email', 'exp', 'id', 'iss', 'site', 'username' ),
		'jwt_auth_ttl'                      => '172800', // minutes: 120 days
		'jwt_auth_iss'                      => home_url(),
		'jwt_algorithm'                     => 'HS256',
		'decryption_source'                 => '0',
		'decryption_key'                    => wp_generate_password( 64, false ),
		'decryption_key_base64'             => false,
		'request_jwt_url'                   => 1,
		'request_jwt_header'                => 1,
		'request_keys'                      => array(
			'url'    => 'JWT',
			'header' => 'Authorization',
		),
		'jwt_login_by'                      => 0,
		'jwt_login_by_parameter'            => 'email',
		'allow_register'                    => true,
		'require_register_auth'             => true,
		'new_user_profile'                  => get_role( 'customer' ) ? 'customer' : 'subscriber',
		'random_password'                   => false,
		'register_jwt'                      => true,
		'allow_reset_password'              => true,
		'reset_password_requires_auth_code' => false,
		'reset_password_jwt'                => false,
		'jwt_reset_password_flow'           => 1,
		'auth_codes'                        => array(
			array(
				'code'            => wp_generate_password( 48, false ),
				'role'            => '',
				'expiration_date' => '',
			),
		),
		'auth_code_key'                     => 'AUTH_KEY',
		'route_namespace'                   => 'simple-jwt-login/v1/',
	);
}

/** Handles the buttons of the page. Returns the notices to show: [ type, html ]. */
function ARD_app_login_handle_post() {
	$notices = array();
	if ( ! isset( $_POST['ard_app_login_nonce'] )
		|| ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['ard_app_login_nonce'] ) ), 'ard_app_login_action' )
		|| ! current_user_can( 'manage_options' ) ) {
		return $notices;
	}
	$action = isset( $_POST['ard_app_login_do'] ) ? sanitize_key( wp_unslash( $_POST['ard_app_login_do'] ) ) : '';

	if ( 'switch' === $action ) {
		$on = ! empty( $_POST['ard_app_login_on'] );
		if ( ! $on ) {
			WPADR_jwt_set_switch( false );
			$notices[] = array( 'success', 'Interruttore spento. Le impostazioni copiate restano salvate.' );
		} elseif ( ! WPADR_jwt_settings() && ! WPADR_jwt_import_from_sjl() ) {
			$notices[] = array( 'error', 'Su questo sito non ci sono impostazioni di accesso da usare. Usa «Prepara questo sito per l\'app».' );
		} else {
			WPADR_jwt_set_switch( true );
			$notices[] = array( 'success', 'Interruttore acceso.' );
		}
	} elseif ( 'reset_flow' === $action ) {
		$own    = WPADR_jwt_settings();
		$choice = isset( $_POST['ard_app_login_reset'] ) ? sanitize_key( wp_unslash( $_POST['ard_app_login_reset'] ) ) : '';
		if ( ! $own ) {
			$notices[] = array( 'error', 'Accendi prima l\'interruttore: le impostazioni non sono ancora in Mobile Admin.' );
		} elseif ( ! in_array( $choice, array( 'shop', 'wp', 'base' ), true ) || ( 'shop' === $choice && ! WPADR_jwt_shop_reset_available() ) ) {
			$notices[] = array( 'error', 'Scelta non valida per questo sito.' );
		} else {
			if ( 'base' === $choice ) {
				unset( $own['ma_reset_flow'] );
			} else {
				$own['ma_reset_flow'] = $choice;
			}
			update_option( WPADR_JWT_OPTION, $own, false );
			$notices[] = array( 'success', '«Password dimenticata» salvata: vale dalla prossima richiesta fatta dall\'app.' );
		}
	} elseif ( 'recopy' === $action ) {
		$notices[] = WPADR_jwt_import_from_sjl()
			? array( 'success', 'Impostazioni copiate di nuovo da Simple JWT Login.' )
			: array( 'error', 'Simple JWT Login non ha impostazioni su questo sito: non c\'è nulla da copiare.' );
	} elseif ( 'setup' === $action ) {
		if ( ! ARD_app_login_can_setup() ) {
			$notices[] = array( 'error', 'Solo ticinoWEB può preparare un sito per l\'app.' );
		} elseif ( WPADR_jwt_effective_settings() ) {
			$notices[] = array( 'error', 'Questo sito ha già le impostazioni di accesso: non ne creo di nuove.' );
		} else {
			$settings = ARD_app_login_new_settings();
			update_option( WPADR_JWT_OPTION, $settings, false );
			WPADR_jwt_set_switch( true );
			$notices[] = array(
				'success',
				'Sito pronto per l\'app. <strong>Copia adesso queste due chiavi e consegnale a chi sviluppa l\'app: non verranno più mostrate.</strong>'
				. '<br><br>Chiave dell\'app (AUTH_KEY):<br><code style="user-select:all;word-break:break-all;">' . esc_html( $settings['auth_codes'][0]['code'] ) . '</code>'
				. '<br><br>Chiave di firma dei token (JWT_SECRET delle Cloud Functions):<br><code style="user-select:all;word-break:break-all;">' . esc_html( $settings['decryption_key'] ) . '</code>',
			);
		}
	}
	return $notices;
}

/**
 * The choices of «Password dimenticata» for this site: [ value, title, description, enabled ].
 * 'base' is what was set in Simple JWT Login; 'shop' and 'wp' are Mobile Admin's own choices.
 */
function ARD_app_login_reset_choices( $settings ) {
	$base = WPADR_jwt_reset_flow( array_diff_key( (array) $settings, array( 'ma_reset_flow' => 1 ) ) );
	$shop = WPADR_jwt_shop_reset_available();
	$rows = array(
		array(
			'shop',
			'E-mail del negozio (consigliata)',
			$shop
				? 'Il cliente riceve l\'e-mail di WooCommerce, con il link per scegliere la nuova password nella pagina «Il mio account» di questo sito.'
				: 'Serve WooCommerce con la pagina «Il mio account» e la sua e-mail «Reimposta password» attiva: su questo sito non ci sono.',
			$shop,
		),
	);
	if ( 'wp' !== $base ) {
		$rows[] = array( 'wp', 'E-mail standard di WordPress', 'Il cliente riceve l\'e-mail di WordPress con il link per scegliere la nuova password.', true );
	}
	$bases = array(
		'wp'      => array( 'E-mail standard di WordPress', 'Il cliente riceve l\'e-mail di WordPress con il link per scegliere la nuova password.' ),
		'code'    => array( 'E-mail con un codice', 'Il cliente riceve un codice da scrivere nell\'app. Funziona solo se l\'app ha la schermata per inserirlo.' ),
		'none'    => array( 'Nessuna e-mail', 'Il codice viene solo salvato: il cliente non riceve nulla e non può cambiare la password dall\'app.' ),
		'invalid' => array( 'Impostazione non valida', 'Il cliente riceve un errore.' ),
	);
	$rows[] = array( 'base', $bases[ $base ][0], $bases[ $base ][1], true );
	return $rows;
}

/** The rows of «Cosa è impostato»: [ label, value, warning? ]. No key is ever printed. */
function ARD_app_login_summary( $settings ) {
	$rows = array();
	$yes  = '<span class="ard-jl-yes">Attivo</span>';
	$no   = '<span class="ard-jl-no">Spento</span>';

	$codes  = count( WPADR_jwt_auth_codes( $settings ) );
	$rows[] = array( 'Login dall\'app', ! empty( $settings['allow_authentication'] ) ? $yes : $no, false );
	$rows[] = array(
		'Chiave dell\'app',
		( WPADR_jwt_get( $settings, 'auth_requires_auth_code', false ) ? 'Richiesta a ogni login' : 'Non richiesta per il login' )
			. ' · ' . ( 1 === $codes ? '1 chiave impostata' : $codes . ' chiavi impostate' ),
		0 === $codes,
	);

	if ( ! empty( $settings['allow_register'] ) ) {
		$role  = WPADR_jwt_safe_role( WPADR_jwt_get( $settings, 'new_user_profile', 'subscriber' ) );
		$names = wp_roles()->get_names();
		$label = isset( $names[ $role ] ) ? translate_user_role( $names[ $role ] ) : $role;
		$rows[] = array( 'Registrazione dall\'app', $yes . ' · i nuovi account sono «' . esc_html( $label ) . '»', false );
	} else {
		$rows[] = array( 'Registrazione dall\'app', $no, false );
	}

	if ( ! empty( $settings['allow_reset_password'] ) ) {
		$flow  = WPADR_jwt_reset_flow( $settings );
		$texts = array(
			'shop' => 'Il cliente riceve l\'e-mail del negozio con il link per scegliere la nuova password',
			'wp'   => 'Il cliente riceve l\'e-mail standard di WordPress con il link',
			'code' => 'Il cliente riceve un\'e-mail con un codice da scrivere nell\'app',
			'none' => 'Nessuna e-mail: il codice viene solo salvato e il cliente non riceve nulla',
		);
		$text  = isset( $texts[ $flow ] ) ? $texts[ $flow ] : 'Impostazione non valida: il cliente riceve un errore';
		$warn  = ! in_array( $flow, array( 'shop', 'wp', 'code' ), true );
		if ( ! empty( $settings['reset_password_requires_auth_code'] ) ) {
			$text .= ' · serve la chiave dell\'app';
		}
		if ( ! empty( $settings['reset_password_jwt'] ) ) {
			$text .= ' · chi ha già fatto l\'accesso può cambiare la password dall\'app';
		}
		$rows[] = array( 'Password dimenticata', $text, $warn );
	} else {
		$rows[] = array( 'Password dimenticata', $no, false );
	}

	if ( in_array( 'exp', (array) WPADR_jwt_get( $settings, 'jwt_payload', array() ), true ) ) {
		$minutes = (int) WPADR_jwt_get( $settings, 'jwt_auth_ttl', 60 );
		$days    = $minutes / 1440;
		$text    = $days >= 1 ? sprintf( '%s giorni', number_format_i18n( $days, (float) floor( $days ) === (float) $days ? 0 : 1 ) ) : sprintf( '%d minuti', $minutes );
		$rows[]  = array( 'Durata dell\'accesso', $text . ', poi il cliente rifà il login', false );
	} else {
		$rows[] = array( 'Durata dell\'accesso', 'Senza scadenza: chi ha fatto l\'accesso resta dentro finché non esce', true );
	}

	$rows[] = array( 'Elimina account dall\'app', WPADR_jwt_get( $settings, 'allow_delete', false ) ? $yes . ' · il cliente viene tolto da questo sito' : $no, false );
	$rows[] = array( 'Chiave di firma', '' !== WPADR_jwt_signing_key( $settings ) ? 'Impostata' : 'Manca', '' === WPADR_jwt_signing_key( $settings ) );
	return $rows;
}

function ARD_showContent_app_login() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( 'Non hai i permessi per questa pagina.' );
	}
	$notices  = ARD_app_login_handle_post();
	$state    = WPADR_jwt_state();
	$settings = $state['settings'];

	$states = array(
		'on'      => array( 'green', 'Attivo', 'L\'accesso dell\'app passa da Mobile Admin. Su questo sito il plugin Simple JWT Login non serve più.' ),
		'waiting' => array( 'amber', 'Pronto, in attesa', 'Le impostazioni sono copiate. Finché il plugin Simple JWT Login è attivo su questo sito risponde ancora lui: per i clienti non cambia nulla. Appena viene disattivato, Mobile Admin prende il suo posto da solo. Per tornare indietro basta riattivarlo.' ),
		'off'     => array( 'grey', 'Spento', 'L\'accesso dell\'app è gestito dal plugin Simple JWT Login. Accendi l\'interruttore per preparare il passaggio: per i clienti non cambia nulla finché Simple JWT Login resta attivo.' ),
		'nobody'  => array( 'red', 'Nessuno risponde all\'app', 'Simple JWT Login non è attivo e l\'interruttore è spento: i clienti non riescono ad accedere né a registrarsi dall\'app. Accendi l\'interruttore.' ),
		'blocked' => array( 'red', 'Non può partire', 'Con le impostazioni di questo sito Mobile Admin non può gestire l\'accesso. Lascia attivo Simple JWT Login e contatta ticinoWEB.' ),
		'empty'   => array( 'grey', 'Questo sito non è collegato a un\'app', ARD_app_login_can_setup() ? 'Non ci sono impostazioni di accesso. Se questo sito deve servire un\'app, preparalo con il pulsante qui sotto.' : 'Non ci sono impostazioni di accesso: i clienti non entrano nell\'app da questo sito. Se deve servire un\'app, lo prepara ticinoWEB.' ),
	);
	list( $lamp, $title, $text ) = $states[ $state['code'] ];

	$namespace = WPADR_jwt_namespace( $settings );
	// The index of the namespace: 200 from whoever serves the routes, 404 when nobody does.
	$probe_url = add_query_arg( 'rest_route', '/' . $namespace, home_url( '/' ) );
	?>
	<div class="wrap ard-jl">
		<h1>Accesso app</h1>
		<p class="description ard-jl-intro">
			Login, registrazione e «password dimenticata» dei clienti nell'app passano da questo sito.
			Qui vedi chi li gestisce e puoi affidarli a Mobile Admin al posto del plugin Simple JWT Login.
		</p>

		<?php foreach ( $notices as $notice ) : ?>
			<div class="notice notice-<?php echo esc_attr( $notice[0] ); ?> inline"><p><?php echo wp_kses_post( $notice[1] ); ?></p></div>
		<?php endforeach; ?>

		<div class="ard-jl-card">
			<div class="ard-jl-state">
				<span class="ard-jl-lamp ard-jl-<?php echo esc_attr( $lamp ); ?>" aria-hidden="true"></span>
				<div>
					<p class="ard-jl-title"><?php echo esc_html( $title ); ?></p>
					<p class="ard-jl-text"><?php echo esc_html( $text ); ?></p>
					<?php if ( $state['blockers'] ) : ?>
						<ul class="ard-jl-list">
							<?php foreach ( $state['blockers'] as $blocker ) : ?>
								<li><?php echo esc_html( $blocker ); ?></li>
							<?php endforeach; ?>
						</ul>
					<?php endif; ?>
				</div>
			</div>

			<?php if ( 'empty' === $state['code'] && ! ARD_app_login_can_setup() ) : ?>
			<?php elseif ( 'empty' === $state['code'] ) : ?>
				<form method="post" onsubmit="return confirm('Creo le chiavi e le impostazioni di accesso per questo sito?');">
					<?php wp_nonce_field( 'ard_app_login_action', 'ard_app_login_nonce' ); ?>
					<input type="hidden" name="ard_app_login_do" value="setup">
					<button type="submit" class="button button-primary">Prepara questo sito per l'app</button>
				</form>
			<?php else : ?>
				<form method="post" class="ard-jl-switch-form" id="ard-jl-switch-form">
					<?php wp_nonce_field( 'ard_app_login_action', 'ard_app_login_nonce' ); ?>
					<input type="hidden" name="ard_app_login_do" value="switch">
					<label class="ard-jl-switch">
						<input type="checkbox" name="ard_app_login_on" value="1" id="ard-jl-switch" <?php checked( $state['switch'] ); ?>
							data-live="<?php echo 'on' === $state['code'] ? '1' : '0'; ?>">
						<span class="ard-jl-slider" aria-hidden="true"></span>
						<span class="ard-jl-switch-label">Mobile Admin gestisce l'accesso dell'app</span>
					</label>
					<noscript><button type="submit" class="button">Salva</button></noscript>
				</form>
			<?php endif; ?>
		</div>

		<?php if ( 'empty' !== $state['code'] ) : ?>
			<div class="ard-jl-card">
				<p class="ard-jl-h">Chi risponde adesso</p>
				<p class="ard-jl-text" id="ard-jl-probe" aria-live="polite">Controllo in corso…</p>
				<button type="button" class="button" id="ard-jl-probe-btn">Prova di nuovo</button>
			</div>

			<div class="ard-jl-card">
				<p class="ard-jl-h">Cosa è impostato</p>
				<table class="ard-jl-table">
					<tbody>
					<?php foreach ( ARD_app_login_summary( $settings ) as $row ) : ?>
						<tr<?php echo $row[2] ? ' class="ard-jl-warn"' : ''; ?>>
							<th scope="row"><?php echo esc_html( $row[0] ); ?></th>
							<td><?php echo wp_kses( $row[1], array( 'span' => array( 'class' => array() ) ) ); ?></td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
				<p class="description">
					<?php echo $state['has_own'] ? 'Sono le impostazioni salvate in Mobile Admin.' : 'Sono le impostazioni di Simple JWT Login: accendendo l\'interruttore vengono copiate in Mobile Admin, senza riscrivere nulla.'; ?>
				</p>
				<?php if ( WPADR_jwt_copy_is_stale() ) : ?>
					<form method="post" class="ard-jl-inline">
						<?php wp_nonce_field( 'ard_app_login_action', 'ard_app_login_nonce' ); ?>
						<input type="hidden" name="ard_app_login_do" value="recopy">
						<p class="ard-jl-text"><strong>Le impostazioni di Simple JWT Login sono diverse dalla copia di Mobile Admin.</strong> Se le hai cambiate lì dopo la copia, ricopiale.</p>
						<button type="submit" class="button">Ricopia da Simple JWT Login</button>
					</form>
				<?php endif; ?>
				<?php foreach ( WPADR_jwt_notes( $settings ) as $note ) : ?>
					<p class="ard-jl-note"><?php echo esc_html( $note ); ?></p>
				<?php endforeach; ?>
			</div>

			<?php if ( $state['has_own'] && ! empty( $settings['allow_reset_password'] ) ) : ?>
				<?php
				$reset_choice = (string) WPADR_jwt_get( $settings, 'ma_reset_flow', '' );
				$reset_choice = in_array( $reset_choice, array( 'shop', 'wp' ), true ) ? $reset_choice : 'base';
				?>
				<form method="post" class="ard-jl-card">
					<?php wp_nonce_field( 'ard_app_login_action', 'ard_app_login_nonce' ); ?>
					<input type="hidden" name="ard_app_login_do" value="reset_flow">
					<p class="ard-jl-h">Password dimenticata</p>
					<p class="ard-jl-text">Cosa riceve il cliente quando tocca «Password dimenticata» nell'app.</p>
					<?php foreach ( ARD_app_login_reset_choices( $settings ) as $choice ) : ?>
						<label class="ard-jl-radio<?php echo $choice[3] ? '' : ' ard-jl-disabled'; ?>">
							<input type="radio" name="ard_app_login_reset" value="<?php echo esc_attr( $choice[0] ); ?>" <?php checked( $reset_choice, $choice[0] ); ?> <?php disabled( ! $choice[3] ); ?>>
							<span>
								<strong><?php echo esc_html( $choice[1] ); ?></strong><br>
								<span class="ard-jl-radio-text"><?php echo esc_html( $choice[2] ); ?></span>
							</span>
						</label>
					<?php endforeach; ?>
					<?php if ( 'shop' === $reset_choice && 'shop' !== WPADR_jwt_reset_flow( $settings ) ) : ?>
						<p class="ard-jl-note">Su questo sito l'e-mail del negozio non è disponibile in questo momento: finché manca, il cliente riceve l'e-mail standard di WordPress.</p>
					<?php endif; ?>
					<button type="submit" class="button button-primary">Salva</button>
				</form>
			<?php endif; ?>

			<details class="ard-jl-card ard-jl-tech">
				<summary>Per il tecnico</summary>
				<p>Indirizzi serviti (gli stessi di Simple JWT Login 3.6.8, con le stesse risposte e gli stessi codici di errore):</p>
				<ul class="ard-jl-list">
					<li><code>POST /<?php echo esc_html( $namespace ); ?>/auth</code> login</li>
					<li><code>GET|POST /<?php echo esc_html( $namespace ); ?>/auth/validate</code> controllo del token</li>
					<li><code>POST /<?php echo esc_html( $namespace ); ?>/auth/revoke</code> uscita</li>
					<li><code>POST /<?php echo esc_html( $namespace ); ?>/users</code> registrazione</li>
					<li><code>POST|PUT /<?php echo esc_html( $namespace ); ?>/user/reset_password</code> password dimenticata</li>
					<li><code>DELETE /<?php echo esc_html( $namespace ); ?>/users</code> eliminazione dell'account (solo se attiva qui sopra)</li>
				</ul>
				<p>Non riprodotti, perché nessuna app li usa: accesso automatico da link (autologin), rinnovo del token, login con Google.</p>
				<?php if ( '' !== WPADR_jwt_signing_key( $settings ) && ARD_app_login_can_setup() ) : ?>
					<p>Impronta della chiave di firma: <code><?php echo esc_html( substr( hash( 'sha256', WPADR_jwt_signing_key( $settings ) ), 0, 10 ) ); ?></code>
					(serve a confrontarla con quella delle Cloud Functions senza mostrarla: <code>sha256</code>, primi 10 caratteri).</p>
				<?php endif; ?>
				<p>Tentativi falliti: dopo 10 password sbagliate in 15 minuti per lo stesso account l'accesso si ferma fino allo scadere dei 15 minuti (risposta 429).</p>
			</details>
		<?php endif; ?>
	</div>

	<style>
		.ard-jl-intro { max-width: 760px; }
		.ard-jl-card { max-width: 760px; background: #fff; border: 1px solid #dcdcde; border-radius: 12px; padding: 16px 18px; margin: 14px 0; box-sizing: border-box; }
		.ard-jl-state { display: flex; gap: 14px; align-items: flex-start; margin-bottom: 14px; }
		.ard-jl-lamp { flex: 0 0 14px; width: 14px; height: 14px; border-radius: 50%; margin-top: 5px; }
		.ard-jl-green { background: #00a32a; }
		.ard-jl-amber { background: #dba617; }
		.ard-jl-red { background: #d63638; }
		.ard-jl-grey { background: #a7aaad; }
		.ard-jl-title { margin: 0 0 4px; font-size: 16px; font-weight: 600; }
		.ard-jl-h { margin: 0 0 8px; font-size: 14px; font-weight: 600; }
		.ard-jl-text { margin: 0 0 10px; }
		.ard-jl-list { margin: 6px 0 10px 18px; list-style: disc; }
		.ard-jl-switch { display: inline-flex; align-items: center; gap: 12px; cursor: pointer; }
		.ard-jl-switch input { position: absolute; opacity: 0; width: 1px; height: 1px; }
		.ard-jl-slider { position: relative; flex: 0 0 46px; width: 46px; height: 26px; border-radius: 13px; background: #a7aaad; transition: background .15s; }
		.ard-jl-slider::after { content: ""; position: absolute; top: 3px; left: 3px; width: 20px; height: 20px; border-radius: 50%; background: #fff; transition: transform .15s; }
		.ard-jl-switch input:checked + .ard-jl-slider { background: #2271b1; }
		.ard-jl-switch input:checked + .ard-jl-slider::after { transform: translateX(20px); }
		.ard-jl-switch input:focus-visible + .ard-jl-slider { outline: 2px solid #2271b1; outline-offset: 2px; }
		.ard-jl-switch-label { font-weight: 600; }
		.ard-jl-table { border-collapse: collapse; width: 100%; margin-bottom: 8px; }
		.ard-jl-table th, .ard-jl-table td { text-align: left; padding: 8px 10px 8px 0; border-bottom: 1px solid #f0f0f1; vertical-align: top; }
		.ard-jl-table th { width: 210px; font-weight: 600; }
		.ard-jl-warn td { color: #b32d2e; }
		.ard-jl-yes { color: #007017; font-weight: 600; }
		.ard-jl-no { color: #646970; font-weight: 600; }
		.ard-jl-note { margin: 10px 0 0; padding: 8px 12px; background: #fcf9e8; border-radius: 8px; }
		.ard-jl-inline { margin-top: 12px; }
		.ard-jl-radio { display: flex; gap: 10px; align-items: flex-start; padding: 10px 12px; margin: 0 0 8px; border: 1px solid #dcdcde; border-radius: 8px; cursor: pointer; }
		.ard-jl-radio input { margin-top: 3px; flex: 0 0 auto; }
		.ard-jl-radio:has(input:checked) { border-color: #2271b1; background: #f0f6fc; }
		.ard-jl-radio-text { color: #50575e; }
		.ard-jl-disabled { opacity: .6; cursor: default; }
		.ard-jl-tech summary { cursor: pointer; font-weight: 600; }
		.ard-jl-tech code { word-break: break-all; }
		.ard-jl-ok { color: #007017; font-weight: 600; }
		.ard-jl-bad { color: #b32d2e; font-weight: 600; }
		@media (max-width: 600px) {
			.ard-jl-table th, .ard-jl-table td { display: block; width: auto; border-bottom: 0; padding: 2px 0; }
			.ard-jl-table tr { display: block; padding: 8px 0; border-bottom: 1px solid #f0f0f1; }
		}
	</style>
	<script>
	(function () {
		var sw = document.getElementById('ard-jl-switch');
		if (sw) {
			sw.addEventListener('change', function () {
				if (!sw.checked && sw.getAttribute('data-live') === '1'
					&& !window.confirm('Se spegni, su questo sito nessuno risponde più all\'accesso dell\'app finché non riattivi Simple JWT Login. Spengo?')) {
					sw.checked = true;
					return;
				}
				document.getElementById('ard-jl-switch-form').submit();
			});
		}
		var out = document.getElementById('ard-jl-probe');
		var btn = document.getElementById('ard-jl-probe-btn');
		if (!out) { return; }
		var url = <?php echo wp_json_encode( $probe_url ); ?>;
		function show(cls, text) {
			out.className = 'ard-jl-text ' + cls;
			out.textContent = text;
		}
		function probe() {
			show('', 'Controllo in corso…');
			fetch(url + '&_=' + Date.now(), { credentials: 'omit', cache: 'no-store' })
				.then(function (res) {
					if (res.headers.get('X-Mobile-Admin-Auth') === '1') {
						show('ard-jl-ok', 'Risponde Mobile Admin.');
					} else if (res.ok) {
						show('', 'Risponde il plugin Simple JWT Login.');
					} else if (res.status === 404) {
						show('ard-jl-bad', 'Non risponde nessuno: dall\'app non si può accedere.');
					} else {
						show('ard-jl-bad', 'Il sito ha risposto con un errore (' + res.status + '). Riprova tra poco.');
					}
				})
				.catch(function () {
					show('ard-jl-bad', 'Il sito non ha risposto alla prova. Riprova tra poco.');
				});
		}
		if (btn) { btn.addEventListener('click', probe); }
		probe();
	})();
	</script>
	<?php
}
