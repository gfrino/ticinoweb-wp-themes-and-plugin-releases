<?php
/**
 * Amministrazione: Driver, Consegne, Impostazioni (sotto «Gestione App» se c'è Mobile Admin),
 * pulsante «Promuovi a Driver» nel profilo utente, riquadro nell'ordine e colonna nell'elenco ordini.
 *
 * @package mobile-admin
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// MADR_ADMIN_SLUG: in ../driver.php (serve anche con il Driver spento).

add_action( 'admin_menu', function () {
	$title  = __( 'Driver e consegne', 'wp-app-dashboard' );
	$parent = ! empty( $GLOBALS['admin_page_hooks']['ard_stato_app'] ) ? 'ard_stato_app' : '';
	if ( $parent ) {
		add_submenu_page( $parent, $title, __( 'Driver', 'wp-app-dashboard' ), 'manage_woocommerce', MADR_ADMIN_SLUG, 'madr_admin_page' );
	} else {
		add_menu_page( $title, __( 'Driver', 'wp-app-dashboard' ), 'manage_woocommerce', MADR_ADMIN_SLUG, 'madr_admin_page', 'dashicons-location-alt', 56 );
	}
}, 30 );

add_action( 'admin_enqueue_scripts', function ( $hook ) {
	$screen = get_current_screen();
	$on_order = function_exists( 'wc_get_page_screen_id' ) && $screen && in_array( $screen->id, array( wc_get_page_screen_id( 'shop-order' ), 'shop_order' ), true );
	if ( false !== strpos( (string) $hook, MADR_ADMIN_SLUG ) || $on_order || in_array( $hook, array( 'user-edit.php', 'profile.php' ), true ) ) {
		wp_enqueue_style( 'madr-admin', MADR_URL . 'css/admin.css', array(), MADR_VERSION );
	}
} );

function madr_admin_url( $tab = 'drivers', $args = array() ) {
	return add_query_arg( array_merge( array( 'page' => MADR_ADMIN_SLUG, 'tab' => $tab ), $args ), admin_url( 'admin.php' ) );
}

/** Utenti con il ruolo Driver in questa sede. */
function madr_get_drivers() {
	return get_users( array( 'role' => 'driver', 'orderby' => 'display_name', 'number' => 200 ) );
}

function madr_admin_notice_from_query() {
	$msg = isset( $_GET['madr_msg'] ) ? sanitize_text_field( wp_unslash( $_GET['madr_msg'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	$err = isset( $_GET['madr_err'] ) ? sanitize_text_field( wp_unslash( $_GET['madr_err'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	if ( $msg ) {
		echo '<div class="notice notice-success is-dismissible"><p>' . esc_html( $msg ) . '</p></div>';
	}
	if ( $err ) {
		echo '<div class="notice notice-error is-dismissible"><p>' . esc_html( $err ) . '</p></div>';
	}
}

function madr_admin_page() {
	$tab  = isset( $_GET['tab'] ) ? sanitize_key( $_GET['tab'] ) : 'drivers'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	$tabs = array(
		'drivers'    => __( 'Driver', 'wp-app-dashboard' ),
		'deliveries' => __( 'Consegne', 'wp-app-dashboard' ),
		'settings'   => __( 'Impostazioni', 'wp-app-dashboard' ),
	);
	echo '<div class="wrap madr-admin"><h1>' . esc_html__( 'Driver e consegne', 'wp-app-dashboard' ) . '</h1>';
	madr_admin_notice_from_query();
	echo '<nav class="nav-tab-wrapper">';
	foreach ( $tabs as $key => $label ) {
		printf( '<a href="%s" class="nav-tab%s">%s</a>', esc_url( madr_admin_url( $key ) ), $tab === $key ? ' nav-tab-active' : '', esc_html( $label ) );
	}
	echo '</nav>';
	if ( 'deliveries' === $tab ) {
		madr_admin_tab_deliveries();
	} elseif ( 'settings' === $tab ) {
		madr_admin_tab_settings();
	} else {
		madr_admin_tab_drivers();
	}
	echo '</div>';
}

/* ------------------------------------------------------------------ Driver */

function madr_admin_tab_drivers() {
	global $wpdb;
	$drivers = madr_get_drivers();
	$table   = madr_table( 'deliveries' );
	$avail   = madr_availability_labels();
	?>
	<div class="madr-card">
		<h2><?php esc_html_e( 'Promuovi un utente a Driver', 'wp-app-dashboard' ); ?></h2>
		<p class="description"><?php esc_html_e( 'L\'utente tiene il suo account e tutto quello che aveva: ottiene in più l\'area Driver sul sito e nell\'app, solo per questa sede.', 'wp-app-dashboard' ); ?></p>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="madr-inline">
			<?php wp_nonce_field( 'madr_promote' ); ?>
			<input type="hidden" name="action" value="madr_promote">
			<label for="madr-user" class="screen-reader-text"><?php esc_html_e( 'Email o nome utente', 'wp-app-dashboard' ); ?></label>
			<input type="text" id="madr-user" name="user" class="regular-text" placeholder="<?php esc_attr_e( 'Email o nome utente', 'wp-app-dashboard' ); ?>" required>
			<?php submit_button( __( 'Promuovi a Driver', 'wp-app-dashboard' ), 'primary', 'submit', false ); ?>
		</form>
	</div>

	<div class="madr-card">
		<h2><?php esc_html_e( 'Driver di questa sede', 'wp-app-dashboard' ); ?></h2>
		<?php if ( ! $drivers ) : ?>
			<p class="madr-empty"><?php esc_html_e( 'Nessun Driver ancora. Promuovi un utente qui sopra o dal suo profilo (Utenti → Modifica → «Promuovi a Driver»).', 'wp-app-dashboard' ); ?></p>
		<?php else : ?>
			<table class="widefat striped">
				<thead><tr>
					<th><?php esc_html_e( 'Driver', 'wp-app-dashboard' ); ?></th>
					<th><?php esc_html_e( 'Disponibilità', 'wp-app-dashboard' ); ?></th>
					<th><?php esc_html_e( 'Consegne in corso', 'wp-app-dashboard' ); ?></th>
					<th><?php esc_html_e( 'Consegnate (30 giorni)', 'wp-app-dashboard' ); ?></th>
					<th></th>
				</tr></thead>
				<tbody>
				<?php foreach ( $drivers as $user ) :
					$active = madr_driver_active_count( $user->ID );
					$done   = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE driver_id = %d AND status = 'delivered' AND delivered_at > %s", $user->ID, gmdate( 'Y-m-d H:i:s', time() - 30 * DAY_IN_SECONDS ) ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
					$av     = madr_get_availability( $user->ID );
					?>
					<tr>
						<td><strong><?php echo esc_html( $user->display_name ); ?></strong><br><span class="description"><?php echo esc_html( $user->user_email ); ?></span></td>
						<td><span class="madr-chip madr-chip--<?php echo esc_attr( $av ); ?>"><?php echo esc_html( $avail[ $av ] ); ?></span></td>
						<td><?php echo $active ? '<a href="' . esc_url( madr_admin_url( 'deliveries', array( 'driver' => $user->ID ) ) ) . '">' . (int) $active . '</a>' : '0'; ?></td>
						<td><a href="<?php echo esc_url( madr_admin_url( 'deliveries', array( 'driver' => $user->ID, 'view' => 'history' ) ) ); ?>"><?php echo (int) $done; ?></a></td>
						<td class="madr-actions">
							<?php if ( current_user_can( 'promote_users' ) ) : ?>
							<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" onsubmit="return confirm('<?php echo esc_js( $active ? __( 'Il Driver ha consegne in corso: torneranno disponibili per gli altri Driver. Revocare?', 'wp-app-dashboard' ) : __( 'Revocare il ruolo Driver?', 'wp-app-dashboard' ) ); ?>');">
								<?php wp_nonce_field( 'madr_revoke_' . $user->ID ); ?>
								<input type="hidden" name="action" value="madr_revoke">
								<input type="hidden" name="user_id" value="<?php echo (int) $user->ID; ?>">
								<button type="submit" class="button button-link-delete"><?php esc_html_e( 'Revoca', 'wp-app-dashboard' ); ?></button>
							</form>
							<?php endif; ?>
						</td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
		<?php endif; ?>
	</div>
	<?php
}

/** Promuove: lo aggiunge alla sede come cliente se non c'era, poi aggiunge il ruolo Driver. */
function madr_promote_user( $user_id ) {
	if ( is_multisite() && ! is_user_member_of_blog( $user_id, get_current_blog_id() ) ) {
		add_user_to_blog( get_current_blog_id(), $user_id, 'customer' );
	}
	$user = get_userdata( $user_id );
	if ( ! $user ) {
		return false;
	}
	if ( ! in_array( 'driver', (array) $user->roles, true ) ) {
		$user->add_role( 'driver' );
		madr_set_availability( $user_id, 'off' );
	}
	return true;
}

add_action( 'admin_post_madr_promote', function () {
	check_admin_referer( 'madr_promote' );
	if ( ! current_user_can( 'promote_users' ) ) {
		wp_die( esc_html__( 'Non hai i permessi per cambiare i ruoli.', 'wp-app-dashboard' ), 403 );
	}
	$ref  = isset( $_POST['user'] ) ? sanitize_text_field( wp_unslash( $_POST['user'] ) ) : '';
	$id   = isset( $_POST['user_id'] ) ? absint( $_POST['user_id'] ) : 0;
	$user = $id ? get_userdata( $id ) : ( is_email( $ref ) ? get_user_by( 'email', $ref ) : get_user_by( 'login', $ref ) );
	$back = isset( $_POST['back'] ) ? esc_url_raw( wp_unslash( $_POST['back'] ) ) : madr_admin_url( 'drivers' );
	if ( ! $user ) {
		wp_safe_redirect( add_query_arg( 'madr_err', rawurlencode( __( 'Nessun utente con questa email o nome utente.', 'wp-app-dashboard' ) ), $back ) );
		exit;
	}
	madr_promote_user( $user->ID );
	/* translators: %s: nome utente */
	wp_safe_redirect( add_query_arg( 'madr_msg', rawurlencode( sprintf( __( '%s ora è un Driver di questa sede.', 'wp-app-dashboard' ), $user->display_name ) ), $back ) );
	exit;
} );

add_action( 'admin_post_madr_revoke', function () {
	$user_id = isset( $_POST['user_id'] ) ? absint( $_POST['user_id'] ) : 0;
	check_admin_referer( 'madr_revoke_' . $user_id );
	if ( ! current_user_can( 'promote_users' ) ) {
		wp_die( esc_html__( 'Non hai i permessi per cambiare i ruoli.', 'wp-app-dashboard' ), 403 );
	}
	$user = get_userdata( $user_id );
	$back = isset( $_POST['back'] ) ? esc_url_raw( wp_unslash( $_POST['back'] ) ) : madr_admin_url( 'drivers' );
	if ( $user ) {
		do_action( 'madr_revoking', $user_id );
		$user->remove_role( 'driver' ); // → madr_release_driver() tramite l'hook remove_user_role.
	}
	wp_safe_redirect( add_query_arg( 'madr_msg', rawurlencode( __( 'Ruolo Driver revocato. Le sue consegne in corso sono tornate disponibili.', 'wp-app-dashboard' ) ), $back ) );
	exit;
} );

/** Profilo utente: stato e pulsante Promuovi/Revoca. */
function madr_profile_section( $user ) {
	if ( ! current_user_can( 'promote_users' ) ) {
		return;
	}
	$is   = in_array( 'driver', (array) $user->roles, true );
	$back = get_edit_user_link( $user->ID );
	?>
	<h2><?php esc_html_e( 'Driver', 'wp-app-dashboard' ); ?></h2>
	<table class="form-table" role="presentation"><tr>
		<th><?php esc_html_e( 'Consegne', 'wp-app-dashboard' ); ?></th>
		<td>
			<p><?php echo $is ? esc_html__( 'È un Driver di questa sede.', 'wp-app-dashboard' ) : esc_html__( 'Non è un Driver.', 'wp-app-dashboard' ); ?></p>
			<p>
				<button type="submit" form="madr-role-form" class="button <?php echo $is ? 'button-link-delete' : 'button-primary'; ?>"><?php echo $is ? esc_html__( 'Revoca ruolo Driver', 'wp-app-dashboard' ) : esc_html__( 'Promuovi a Driver', 'wp-app-dashboard' ); ?></button>
			</p>
		</td>
	</tr></table>
	<?php
	// Il form vero sta fuori dal form del profilo (vedi madr_profile_form): qui solo il pulsante con form="...".
	add_action( 'admin_footer', function () use ( $user, $is, $back ) {
		$action = $is ? 'madr_revoke' : 'madr_promote';
		$nonce  = $is ? 'madr_revoke_' . $user->ID : 'madr_promote';
		echo '<form id="madr-role-form" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" style="display:none">';
		wp_nonce_field( $nonce );
		echo '<input type="hidden" name="action" value="' . esc_attr( $action ) . '"><input type="hidden" name="user_id" value="' . (int) $user->ID . '"><input type="hidden" name="back" value="' . esc_url( $back ) . '"></form>';
	} );
}
add_action( 'edit_user_profile', 'madr_profile_section' );
add_action( 'show_user_profile', 'madr_profile_section' );
add_action( 'admin_notices', function () {
	$screen = get_current_screen();
	if ( $screen && in_array( $screen->id, array( 'user-edit', 'profile' ), true ) ) {
		madr_admin_notice_from_query();
	}
} );

/* --------------------------------------------------------------- Consegne */

function madr_admin_tab_deliveries() {
	global $wpdb;
	$table   = madr_table( 'deliveries' );
	$driver  = isset( $_GET['driver'] ) ? absint( $_GET['driver'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	$history = isset( $_GET['view'] ) && 'history' === $_GET['view']; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	$drivers = madr_get_drivers();

	$where = $history ? "status IN ('delivered','cancelled')" : "status IN ('assigned','en_route')";
	if ( $driver ) {
		$where .= $wpdb->prepare( ' AND driver_id = %d', $driver );
	}
	$rows      = $wpdb->get_results( "SELECT * FROM {$table} WHERE {$where} ORDER BY updated_at DESC LIMIT 100" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	$available = $history || $driver ? array() : madr_available_orders();
	$labels    = madr_status_labels();
	?>
	<p class="madr-filters">
		<a href="<?php echo esc_url( madr_admin_url( 'deliveries' ) ); ?>" class="<?php echo ! $history ? 'current' : ''; ?>"><?php esc_html_e( 'In corso', 'wp-app-dashboard' ); ?></a> |
		<a href="<?php echo esc_url( madr_admin_url( 'deliveries', array( 'view' => 'history' ) ) ); ?>" class="<?php echo $history ? 'current' : ''; ?>"><?php esc_html_e( 'Storico', 'wp-app-dashboard' ); ?></a>
		<?php if ( $driver && ( $u = get_userdata( $driver ) ) ) : ?>
			— <?php /* translators: %s: nome del Driver */ printf( esc_html__( 'solo %s', 'wp-app-dashboard' ), esc_html( $u->display_name ) ); ?> <a href="<?php echo esc_url( madr_admin_url( 'deliveries', $history ? array( 'view' => 'history' ) : array() ) ); ?>">×</a>
		<?php endif; ?>
	</p>

	<?php if ( ! $history && ! $driver ) : ?>
	<div class="madr-card">
		<h2><?php esc_html_e( 'Ordini da assegnare', 'wp-app-dashboard' ); ?> <span class="count">(<?php echo count( $available ); ?>)</span></h2>
		<?php if ( ! $available ) : ?>
			<p class="madr-empty"><?php esc_html_e( 'Nessun ordine a domicilio in attesa di un Driver.', 'wp-app-dashboard' ); ?></p>
		<?php else : ?>
			<table class="widefat striped"><thead><tr>
				<th><?php esc_html_e( 'Ordine', 'wp-app-dashboard' ); ?></th><th><?php esc_html_e( 'Fascia', 'wp-app-dashboard' ); ?></th><th><?php esc_html_e( 'Indirizzo', 'wp-app-dashboard' ); ?></th><th><?php esc_html_e( 'In attesa da', 'wp-app-dashboard' ); ?></th><th><?php esc_html_e( 'Assegna a', 'wp-app-dashboard' ); ?></th>
			</tr></thead><tbody>
			<?php foreach ( $available as $order ) :
				$addr    = madr_order_address( $order );
				$created = $order->get_date_created();
				?>
				<tr>
					<td><a href="<?php echo esc_url( $order->get_edit_order_url() ); ?>">#<?php echo esc_html( $order->get_order_number() ); ?></a></td>
					<td><?php echo esc_html( madr_order_slot( $order ) ?: '—' ); ?></td>
					<td><?php echo esc_html( $addr['full'] ); ?></td>
					<td><?php echo $created ? esc_html( human_time_diff( $created->getTimestamp() ) ) : '—'; ?></td>
					<td><?php madr_reassign_form( $order->get_id(), 0, $drivers ); ?></td>
				</tr>
			<?php endforeach; ?>
			</tbody></table>
		<?php endif; ?>
	</div>
	<?php endif; ?>

	<?php
	$failed = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table} WHERE sync_error IS NOT NULL" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	if ( $failed ) :
		?>
		<div class="notice notice-warning inline"><p>
			<?php /* translators: %d: consegne non sincronizzate */ printf( esc_html( _n( '%d consegna non è aggiornata sulla mappa del cliente. Si riprova da solo ogni minuto.', '%d consegne non sono aggiornate sulla mappa del cliente. Si riprova da solo ogni minuto.', $failed, 'wp-app-dashboard' ) ), (int) $failed ); ?>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="madr-inline" style="display:inline-flex;margin-left:8px"><?php wp_nonce_field( 'madr_resync' ); ?><input type="hidden" name="action" value="madr_resync"><button class="button"><?php esc_html_e( 'Riprova adesso', 'wp-app-dashboard' ); ?></button></form>
		</p></div>
	<?php endif; ?>
	<div class="madr-card">
		<h2><?php echo $history ? esc_html__( 'Consegne chiuse', 'wp-app-dashboard' ) : esc_html__( 'Consegne in corso', 'wp-app-dashboard' ); ?></h2>
		<?php if ( ! $rows ) : ?>
			<p class="madr-empty"><?php echo $history ? esc_html__( 'Ancora nessuna consegna chiusa.', 'wp-app-dashboard' ) : esc_html__( 'Nessuna consegna in corso.', 'wp-app-dashboard' ); ?></p>
		<?php else : ?>
			<table class="widefat striped"><thead><tr>
				<th><?php esc_html_e( 'Ordine', 'wp-app-dashboard' ); ?></th><th><?php esc_html_e( 'Stato', 'wp-app-dashboard' ); ?></th><th><?php esc_html_e( 'Driver', 'wp-app-dashboard' ); ?></th><th><?php esc_html_e( 'Accettato', 'wp-app-dashboard' ); ?></th><th><?php echo $history ? esc_html__( 'Chiuso', 'wp-app-dashboard' ) : esc_html__( 'Problemi', 'wp-app-dashboard' ); ?></th><?php if ( ! $history ) : ?><th><?php esc_html_e( 'Riassegna', 'wp-app-dashboard' ); ?></th><?php endif; ?>
			</tr></thead><tbody>
			<?php foreach ( $rows as $row ) :
				$order = wc_get_order( $row->order_id );
				$u     = $row->driver_id ? get_userdata( $row->driver_id ) : null;
				?>
				<tr>
					<td><?php echo $order ? '<a href="' . esc_url( $order->get_edit_order_url() ) . '">#' . esc_html( $order->get_order_number() ) . '</a>' : '#' . (int) $row->order_id; ?></td>
					<td><span class="madr-chip madr-chip--<?php echo esc_attr( $row->status ); ?>"><?php echo esc_html( $labels[ $row->status ] ?? $row->status ); ?></span></td>
					<td><?php echo $u ? esc_html( $u->display_name ) : '—'; ?></td>
					<td><?php echo $row->accepted_at ? esc_html( madr_admin_time( $row->accepted_at ) ) : '—'; ?></td>
					<td>
						<?php if ( $history ) : ?>
							<?php echo esc_html( madr_admin_time( $row->delivered_at ?: $row->cancelled_at ) ); ?>
						<?php else : ?>
							<?php echo esc_html( implode( ' · ', madr_delivery_problems( $row ) ) ?: '—' ); ?>
						<?php endif; ?>
					</td>
					<?php if ( ! $history ) : ?><td><?php madr_reassign_form( $row->order_id, (int) $row->driver_id, $drivers ); ?></td><?php endif; ?>
				</tr>
			<?php endforeach; ?>
			</tbody></table>
		<?php endif; ?>
	</div>
	<?php
}

function madr_admin_time( $mysql ) {
	return $mysql ? wp_date( get_option( 'date_format' ) . ' H:i', strtotime( $mysql . ' UTC' ) ) : '—';
}

/** Problemi visibili all'amministratore: sincronizzazione fallita, consegna lunga, partenza mai avvenuta. */
function madr_delivery_problems( $row ) {
	$p = array();
	if ( $row->sync_error ) {
		$p[] = __( 'Tracking non aggiornato', 'wp-app-dashboard' );
	}
	if ( MADR_STATUS_ASSIGNED === $row->status && $row->accepted_at && strtotime( $row->accepted_at . ' UTC' ) < time() - 45 * MINUTE_IN_SECONDS ) {
		$p[] = __( 'Presa in carico da più di 45 min, non ancora partita', 'wp-app-dashboard' );
	}
	if ( MADR_STATUS_EN_ROUTE === $row->status && $row->started_at && strtotime( $row->started_at . ' UTC' ) < time() - 60 * MINUTE_IN_SECONDS ) {
		$p[] = __( 'In consegna da più di un\'ora', 'wp-app-dashboard' );
	}
	return $p;
}

function madr_reassign_form( $order_id, $current, $drivers ) {
	?>
	<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="madr-inline">
		<?php wp_nonce_field( 'madr_reassign_' . $order_id ); ?>
		<input type="hidden" name="action" value="madr_reassign">
		<input type="hidden" name="order_id" value="<?php echo (int) $order_id; ?>">
		<input type="hidden" name="back" value="<?php echo esc_url( isset( $_SERVER['REQUEST_URI'] ) ? esc_url_raw( wp_unslash( $_SERVER['REQUEST_URI'] ) ) : '' ); ?>">
		<label class="screen-reader-text" for="madr-re-<?php echo (int) $order_id; ?>"><?php esc_html_e( 'Driver', 'wp-app-dashboard' ); ?></label>
		<select name="driver_id" id="madr-re-<?php echo (int) $order_id; ?>">
			<option value="0"><?php echo $current ? esc_html__( 'Nessuno (rimetti disponibile)', 'wp-app-dashboard' ) : esc_html__( 'Scegli un Driver…', 'wp-app-dashboard' ); ?></option>
			<?php foreach ( $drivers as $d ) : ?>
				<option value="<?php echo (int) $d->ID; ?>" <?php selected( $current, $d->ID ); ?>><?php echo esc_html( $d->display_name ); ?></option>
			<?php endforeach; ?>
		</select>
		<button type="submit" class="button"><?php echo $current ? esc_html__( 'Riassegna', 'wp-app-dashboard' ) : esc_html__( 'Assegna', 'wp-app-dashboard' ); ?></button>
	</form>
	<?php
}

add_action( 'admin_post_madr_resync', function () {
	check_admin_referer( 'madr_resync' );
	if ( ! current_user_can( 'manage_woocommerce' ) ) {
		wp_die( esc_html__( 'Non hai i permessi.', 'wp-app-dashboard' ), 403 );
	}
	$r = madr_retry_failed_syncs();
	/* translators: 1: consegne aggiornate, 2: consegne provate */
	wp_safe_redirect( add_query_arg( 'madr_msg', rawurlencode( sprintf( __( 'Tracking aggiornato: %1$d su %2$d.', 'wp-app-dashboard' ), $r['ok'], $r['tried'] ) ), madr_admin_url( 'deliveries' ) ) );
	exit;
} );

add_action( 'admin_post_madr_reassign', function () {
	$order_id = isset( $_POST['order_id'] ) ? absint( $_POST['order_id'] ) : 0;
	check_admin_referer( 'madr_reassign_' . $order_id );
	if ( ! current_user_can( 'manage_woocommerce' ) ) {
		wp_die( esc_html__( 'Non hai i permessi.', 'wp-app-dashboard' ), 403 );
	}
	$driver = isset( $_POST['driver_id'] ) ? absint( $_POST['driver_id'] ) : 0;
	$back   = isset( $_POST['back'] ) && $_POST['back'] ? esc_url_raw( wp_unslash( $_POST['back'] ) ) : madr_admin_url( 'deliveries' );
	$back   = remove_query_arg( array( 'madr_msg', 'madr_err' ), $back );
	$result = madr_reassign( $order_id, $driver, get_current_user_id() );
	if ( is_wp_error( $result ) ) {
		wp_safe_redirect( add_query_arg( 'madr_err', rawurlencode( $result->get_error_message() ), $back ) );
	} else {
		wp_safe_redirect( add_query_arg( 'madr_msg', rawurlencode( __( 'Consegna aggiornata.', 'wp-app-dashboard' ) ), $back ) );
	}
	exit;
} );

/* ------------------------------------------------------------ Impostazioni */

function madr_admin_tab_settings() {
	$s        = madr_settings();
	$statuses = function_exists( 'wc_get_order_statuses' ) ? wc_get_order_statuses() : array();
	$fn_ok    = (bool) madr_functions_url();
	$sec_ok   = (bool) madr_server_secret();
	$jwt_ok   = '' !== madr_jwt_key();
	?>
	<div class="madr-card">
		<h2><?php esc_html_e( 'Collegamenti', 'wp-app-dashboard' ); ?></h2>
		<ul class="madr-checks">
			<li class="<?php echo $fn_ok && $sec_ok ? 'ok' : 'ko'; ?>"><?php esc_html_e( 'Collegamento con l\'app (Cloud Functions): notifiche e tracking', 'wp-app-dashboard' ); ?> — <?php echo $fn_ok && $sec_ok ? esc_html__( 'configurato da Gestione App', 'wp-app-dashboard' ) : esc_html__( 'manca: imposta l\'indirizzo delle Cloud Functions in Gestione App', 'wp-app-dashboard' ); ?></li>
			<li class="<?php echo $jwt_ok ? 'ok' : 'ko'; ?>"><?php esc_html_e( 'Login dell\'app (simple-jwt-login)', 'wp-app-dashboard' ); ?> — <?php echo $jwt_ok ? esc_html__( 'chiave presente', 'wp-app-dashboard' ) : esc_html__( 'chiave di firma mancante', 'wp-app-dashboard' ); ?></li>
		</ul>
	</div>
	<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
		<?php wp_nonce_field( 'madr_settings' ); ?>
		<input type="hidden" name="action" value="madr_settings">
		<div class="madr-card">
			<h2><?php esc_html_e( 'Quando un ordine è pronto per un Driver', 'wp-app-dashboard' ); ?></h2>
			<p class="description"><?php esc_html_e( 'Compaiono solo gli ordini con consegna a domicilio in questi stati, creati nelle ultime ore indicate.', 'wp-app-dashboard' ); ?></p>
			<fieldset class="madr-statuses">
				<?php foreach ( $statuses as $key => $label ) : $key = str_replace( 'wc-', '', $key ); ?>
					<label><input type="checkbox" name="statuses[]" value="<?php echo esc_attr( $key ); ?>" <?php checked( in_array( $key, $s['statuses'], true ) ); ?>> <?php echo esc_html( $label ); ?></label>
				<?php endforeach; ?>
			</fieldset>
			<p><label><?php esc_html_e( 'Ordini delle ultime', 'wp-app-dashboard' ); ?> <input type="number" min="1" max="48" name="max_age_hours" value="<?php echo (int) $s['max_age_hours']; ?>" class="small-text"> <?php esc_html_e( 'ore', 'wp-app-dashboard' ); ?></label></p>
			<p><label><?php esc_html_e( 'Consegne contemporanee per Driver', 'wp-app-dashboard' ); ?> <input type="number" min="0" max="20" name="max_active" value="<?php echo (int) $s['max_active']; ?>" class="small-text"></label> <span class="description"><?php esc_html_e( '0 = senza limite', 'wp-app-dashboard' ); ?></span></p>
		</div>
		<div class="madr-card">
			<h2><?php esc_html_e( 'Mappa per il cliente sul sito (Firebase, client web)', 'wp-app-dashboard' ); ?></h2>
			<p class="description"><?php esc_html_e( 'Valori pubblici della «Web app» del progetto Firebase (Impostazioni progetto → Le tue app). Non sono segreti.', 'wp-app-dashboard' ); ?></p>
			<?php foreach ( array( 'apiKey' => 'API key', 'authDomain' => 'Auth domain', 'projectId' => 'Project ID', 'appId' => 'App ID' ) as $k => $label ) : ?>
				<p><label><span class="madr-label"><?php echo esc_html( $label ); ?></span> <input type="text" name="firebase[<?php echo esc_attr( $k ); ?>]" value="<?php echo esc_attr( $s['firebase'][ $k ] ); ?>" class="regular-text code"></label></p>
			<?php endforeach; ?>
		</div>
		<?php submit_button( __( 'Salva', 'wp-app-dashboard' ) ); ?>
	</form>
	<hr>
	<h2><?php esc_html_e( 'Spegnere il Driver', 'wp-app-dashboard' ); ?></h2>
	<p><?php esc_html_e( 'Spento, il sito non mostra più l\'area Driver né la mappa ai clienti e l\'app non riceve consegne da questa sede. Driver e storico restano e si ritrovano riaccendendo.', 'wp-app-dashboard' ); ?></p>
	<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
		<input type="hidden" name="action" value="madr_toggle">
		<input type="hidden" name="enable" value="0">
		<?php wp_nonce_field( 'madr_toggle' ); ?>
		<?php submit_button( __( 'Spegni il Driver su questo sito', 'wp-app-dashboard' ), 'secondary', 'submit', false ); ?>
	</form>
	<?php
}

add_action( 'admin_post_madr_settings', function () {
	check_admin_referer( 'madr_settings' );
	if ( ! current_user_can( 'manage_woocommerce' ) ) {
		wp_die( esc_html__( 'Non hai i permessi.', 'wp-app-dashboard' ), 403 );
	}
	$fb = isset( $_POST['firebase'] ) && is_array( $_POST['firebase'] ) ? wp_unslash( $_POST['firebase'] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- sanificati sotto.
	update_option( 'madr_settings', array(
		'statuses'      => isset( $_POST['statuses'] ) ? array_map( 'sanitize_key', (array) wp_unslash( $_POST['statuses'] ) ) : array(),
		'max_age_hours' => isset( $_POST['max_age_hours'] ) ? absint( $_POST['max_age_hours'] ) : 8,
		'max_active'    => isset( $_POST['max_active'] ) ? absint( $_POST['max_active'] ) : 3,
		'firebase'      => array_map( 'sanitize_text_field', array_intersect_key( (array) $fb, array_flip( array( 'apiKey', 'authDomain', 'projectId', 'appId' ) ) ) ),
	), false );
	wp_safe_redirect( add_query_arg( 'madr_msg', rawurlencode( __( 'Impostazioni salvate.', 'wp-app-dashboard' ) ), madr_admin_url( 'settings' ) ) );
	exit;
} );


/* ------------------------------------------------------ Ordine e elenco ordini */

add_action( 'add_meta_boxes', function () {
	$screen = function_exists( 'wc_get_page_screen_id' ) ? wc_get_page_screen_id( 'shop-order' ) : 'shop_order';
	add_meta_box( 'madr-delivery', __( 'Consegna Driver', 'wp-app-dashboard' ), 'madr_order_metabox', $screen, 'side', 'high' );
} );

function madr_order_metabox( $post_or_order ) {
	global $wpdb;
	$order = $post_or_order instanceof WC_Order ? $post_or_order : wc_get_order( $post_or_order->ID );
	if ( ! $order || ! madr_is_home_delivery( $order ) ) {
		echo '<p class="description">' . esc_html__( 'Non è una consegna a domicilio.', 'wp-app-dashboard' ) . '</p>';
		return;
	}
	$row    = madr_get_delivery( $order->get_id() );
	$status = $row ? $row->status : MADR_STATUS_WAITING;
	$u      = $row && $row->driver_id ? get_userdata( $row->driver_id ) : null;
	echo '<p><span class="madr-chip madr-chip--' . esc_attr( $status ) . '">' . esc_html( madr_status_label( $status ) ) . '</span></p>';
	echo '<p><strong>' . esc_html__( 'Driver', 'wp-app-dashboard' ) . ':</strong> ' . ( $u ? esc_html( $u->display_name ) : '—' ) . '</p>';
	if ( $row ) {
		echo '<p class="madr-times">';
		foreach ( array( 'accepted_at' => __( 'Accettato', 'wp-app-dashboard' ), 'started_at' => __( 'Partito', 'wp-app-dashboard' ), 'delivered_at' => __( 'Consegnato', 'wp-app-dashboard' ) ) as $k => $label ) {
			if ( $row->$k ) {
				echo esc_html( $label ) . ': ' . esc_html( madr_admin_time( $row->$k ) ) . '<br>';
			}
		}
		echo '</p>';
		foreach ( madr_delivery_problems( $row ) as $problem ) {
			echo '<p class="madr-problem">' . esc_html( $problem ) . '</p>';
		}
		$events = $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . madr_table( 'events' ) . ' WHERE order_id = %d ORDER BY id DESC LIMIT 8', $order->get_id() ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		if ( $events ) {
			echo '<details><summary>' . esc_html__( 'Registro', 'wp-app-dashboard' ) . '</summary><ul class="madr-log">';
			foreach ( $events as $e ) {
				echo '<li>' . esc_html( madr_admin_time( $e->created_at ) . ' — ' . $e->event . ( $e->note ? ' (' . $e->note . ')' : '' ) ) . '</li>';
			}
			echo '</ul></details>';
		}
	}
	if ( ! in_array( $status, array( MADR_STATUS_DELIVERED, MADR_STATUS_CANCELLED ), true ) ) {
		// Il riquadro sta dentro il form dell'ordine: il form di riassegnazione va fuori (in fondo alla pagina).
		$drivers = madr_get_drivers();
		add_action( 'admin_footer', function () use ( $order, $row, $drivers ) {
			echo '<div id="madr-reassign-tpl" hidden>';
			madr_reassign_form( $order->get_id(), $row ? (int) $row->driver_id : 0, $drivers );
			echo '</div><script>(function(){var t=document.getElementById("madr-reassign-tpl"),b=document.getElementById("madr-delivery");if(t&&b){b.querySelector(".inside").appendChild(t.firstElementChild);}})();</script>';
		} );
	}
}

$madr_col = function ( $columns ) {
	$new = array();
	foreach ( $columns as $k => $v ) {
		$new[ $k ] = $v;
		if ( 'order_status' === $k ) {
			$new['madr_delivery'] = __( 'Consegna', 'wp-app-dashboard' );
		}
	}
	return $new;
};
add_filter( 'manage_woocommerce_page_wc-orders_columns', $madr_col );
add_filter( 'manage_edit-shop_order_columns', $madr_col );

$madr_col_value = function ( $column, $order ) {
	if ( 'madr_delivery' !== $column ) {
		return;
	}
	$order = $order instanceof WC_Order ? $order : wc_get_order( $order );
	if ( ! $order || ! madr_is_home_delivery( $order ) ) {
		return;
	}
	$status = (string) $order->get_meta( '_madr_delivery_status' ) ?: MADR_STATUS_WAITING;
	$driver = (int) $order->get_meta( '_madr_driver_id' );
	$u      = $driver ? get_userdata( $driver ) : null;
	echo '<span class="madr-chip madr-chip--' . esc_attr( $status ) . '">' . esc_html( madr_status_label( $status ) ) . '</span>';
	if ( $u ) {
		echo '<br><small>' . esc_html( $u->display_name ) . '</small>';
	}
};
add_action( 'manage_woocommerce_page_wc-orders_custom_column', $madr_col_value, 10, 2 );
add_action( 'manage_shop_order_posts_custom_column', $madr_col_value, 10, 2 );
