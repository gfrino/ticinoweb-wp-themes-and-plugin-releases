<?php
/**
 * API REST `app-driver/v1`, le stesse per il sito (cookie + nonce) e per l'app (token dell'app nell'intestazione
 * Authorization: lo verifica Mobile Admin, vedi madr_rest_authenticate()). Ogni permesso si controlla qui,
 * lato server: nascondere un pulsante non basta. Le risposte non vanno mai in cache (LiteSpeed).
 *
 * @package mobile-admin
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

const MADR_REST_NS = 'app-driver/v1';

add_action( 'rest_api_init', 'madr_register_routes' );

function madr_register_routes() {
	$driver = 'madr_rest_permission_driver';
	$id     = array( 'id' => array( 'validate_callback' => function ( $v ) { return is_numeric( $v ) && (int) $v > 0; } ) );

	register_rest_route( MADR_REST_NS, '/me', array(
		'methods'             => 'GET',
		'callback'            => 'madr_rest_me',
		'permission_callback' => 'madr_rest_permission_user',
	) );
	register_rest_route( MADR_REST_NS, '/me/availability', array(
		'methods'             => 'POST',
		'callback'            => 'madr_rest_set_availability',
		'permission_callback' => $driver,
		'args'                => array( 'availability' => array( 'required' => true, 'enum' => array( 'available', 'busy', 'off' ) ) ),
	) );
	register_rest_route( MADR_REST_NS, '/available', array(
		'methods'             => 'GET',
		'callback'            => 'madr_rest_available',
		'permission_callback' => $driver,
	) );
	register_rest_route( MADR_REST_NS, '/deliveries', array(
		'methods'             => 'GET',
		'callback'            => 'madr_rest_deliveries',
		'permission_callback' => $driver,
		'args'                => array( 'scope' => array( 'default' => 'active', 'enum' => array( 'active', 'history' ) ) ),
	) );
	register_rest_route( MADR_REST_NS, '/deliveries/(?P<id>\d+)', array(
		'methods'             => 'GET',
		'callback'            => 'madr_rest_delivery',
		'permission_callback' => $driver,
		'args'                => $id,
	) );
	register_rest_route( MADR_REST_NS, '/deliveries/(?P<id>\d+)/accept', array(
		'methods'             => 'POST',
		'callback'            => 'madr_rest_accept',
		'permission_callback' => $driver,
		'args'                => $id,
	) );
	register_rest_route( MADR_REST_NS, '/deliveries/(?P<id>\d+)/start', array(
		'methods'             => 'POST',
		'callback'            => 'madr_rest_start',
		'permission_callback' => $driver,
		'args'                => $id,
	) );
	register_rest_route( MADR_REST_NS, '/deliveries/(?P<id>\d+)/delivered', array(
		'methods'             => 'POST',
		'callback'            => 'madr_rest_delivered',
		'permission_callback' => $driver,
		'args'                => $id,
	) );
	register_rest_route( MADR_REST_NS, '/orders/(?P<id>\d+)/tracking', array(
		'methods'             => 'GET',
		'callback'            => 'madr_rest_tracking',
		'permission_callback' => 'madr_rest_permission_user',
		'args'                => $id,
	) );
	register_rest_route( MADR_REST_NS, '/my-deliveries', array(
		'methods'             => 'GET',
		'callback'            => 'madr_rest_customer_deliveries',
		'permission_callback' => 'madr_rest_permission_user',
	) );
	register_rest_route( MADR_REST_NS, '/firebase-token', array(
		'methods'             => 'POST',
		'callback'            => 'madr_rest_firebase_token',
		'permission_callback' => 'madr_rest_permission_user',
	) );
}

/**
 * Utente dal token dell'app («Authorization: Bearer …»), solo per queste API. Mobile Admin di proposito non
 * autentica le altre API REST con il token (jwt-login.php): qui si usano le sue stesse verifiche
 * (firma, scadenza, utente, token revocato al logout).
 */
function madr_rest_authenticate() {
	if ( is_user_logged_in() || ! function_exists( 'WPADR_jwt_user_from_token' ) ) {
		return;
	}
	$header = isset( $_SERVER['HTTP_AUTHORIZATION'] ) ? (string) wp_unslash( $_SERVER['HTTP_AUTHORIZATION'] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- è un token, si verifica sotto
	if ( '' === $header && isset( $_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ) ) {
		$header = (string) wp_unslash( $_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
	}
	if ( ! preg_match( '/^Bearer\s+([A-Za-z0-9_\-]+\.[A-Za-z0-9_\-]+\.[A-Za-z0-9_\-]+)$/', trim( $header ), $m ) ) {
		return;
	}
	try {
		$settings = WPADR_jwt_effective_settings();
		$user     = WPADR_jwt_user_from_token( $m[1], $settings );
		WPADR_jwt_assert_not_revoked( $user->ID, $m[1] );
		wp_set_current_user( $user->ID );
	} catch ( Exception $e ) {
		// Token non valido: si resta anonimi e il permesso risponde 401.
	}
}

/** Utente collegato (sito o app). */
function madr_rest_permission_user() {
	madr_rest_authenticate();
	return is_user_logged_in() ? true : new WP_Error( 'madr_login', __( 'Accedi per continuare.', 'wp-app-dashboard' ), array( 'status' => 401 ) );
}

/** Solo Driver della sede (o amministratori), controllato a ogni richiesta: la revoca vale subito. */
function madr_rest_permission_driver() {
	madr_rest_authenticate();
	if ( ! is_user_logged_in() ) {
		return new WP_Error( 'madr_login', __( 'Accedi per continuare.', 'wp-app-dashboard' ), array( 'status' => 401 ) );
	}
	if ( ! madr_is_driver() ) {
		return new WP_Error( 'madr_not_driver', __( 'Il tuo account non è abilitato come Driver per questa sede.', 'wp-app-dashboard' ), array( 'status' => 403 ) );
	}
	return true;
}

/** Niente cache per le nostre risposte (LiteSpeed, proxy). */
add_filter( 'rest_post_dispatch', function ( $response, $server, $request ) {
	if ( 0 === strpos( $request->get_route(), '/' . MADR_REST_NS ) && $response instanceof WP_REST_Response ) {
		$response->header( 'Cache-Control', 'no-store, private' );
		do_action( 'litespeed_control_set_nocache', 'wp-app-dashboard' );
	}
	return $response;
}, 10, 3 );

function madr_rest_me() {
	$uid       = get_current_user_id();
	$is_driver = madr_is_driver( $uid );
	$data      = array(
		'is_driver'    => $is_driver,
		'site_id'      => madr_site_id(),
		'site_name'    => get_bloginfo( 'name' ),
		'statuses'     => madr_status_labels(),
		'availability' => $is_driver ? madr_get_availability( $uid ) : null,
		'active_count' => $is_driver ? madr_driver_active_count( $uid ) : 0,
		'max_active'   => madr_settings()['max_active'],
	);
	return rest_ensure_response( $data );
}

function madr_rest_set_availability( WP_REST_Request $request ) {
	madr_set_availability( get_current_user_id(), $request['availability'] );
	return madr_rest_me();
}

function madr_rest_available() {
	$items = array();
	foreach ( madr_available_orders() as $order ) {
		$items[] = madr_order_payload( $order, null, 'available' );
	}
	return rest_ensure_response( array( 'orders' => $items, 'server_time' => gmdate( 'c' ) ) );
}

function madr_rest_deliveries( WP_REST_Request $request ) {
	$history  = 'history' === $request['scope'];
	$statuses = $history ? array( MADR_STATUS_DELIVERED ) : madr_active_statuses();
	$items    = array();
	foreach ( madr_driver_deliveries( get_current_user_id(), $statuses, $history ? 50 : 20 ) as $row ) {
		$order = wc_get_order( $row->order_id );
		if ( $order ) {
			$items[] = madr_order_payload( $order, $row, 'driver' );
		}
	}
	return rest_ensure_response( array( 'deliveries' => $items ) );
}

/** Dettaglio: solo il Driver a cui è assegnata (anche un amministratore riceve 403 se non è il suo). */
function madr_rest_delivery( WP_REST_Request $request ) {
	$row   = madr_get_delivery( (int) $request['id'] );
	$order = wc_get_order( (int) $request['id'] );
	if ( ! $row || ! $order || (int) $row->driver_id !== get_current_user_id() ) {
		return new WP_Error( 'madr_forbidden', __( 'Questa consegna non è assegnata a te.', 'wp-app-dashboard' ), array( 'status' => 403 ) );
	}
	return rest_ensure_response( madr_order_payload( $order, $row, 'driver' ) );
}

function madr_rest_respond_row( $result ) {
	if ( is_wp_error( $result ) ) {
		return $result;
	}
	$order = wc_get_order( $result->order_id );
	return rest_ensure_response( madr_order_payload( $order, $result, 'driver' ) );
}

function madr_rest_accept( WP_REST_Request $request ) {
	return madr_rest_respond_row( madr_accept( (int) $request['id'], get_current_user_id() ) );
}

function madr_rest_start( WP_REST_Request $request ) {
	$dest = null;
	$lat  = $request->get_param( 'dest_lat' );
	$lng  = $request->get_param( 'dest_lng' );
	if ( null !== $lat && null !== $lng ) {
		$dest = array( 'lat' => $lat, 'lng' => $lng );
	}
	return madr_rest_respond_row( madr_start( (int) $request['id'], get_current_user_id(), $dest ) );
}

function madr_rest_delivered( WP_REST_Request $request ) {
	return madr_rest_respond_row( madr_complete( (int) $request['id'], get_current_user_id() ) );
}

/** Il cliente può seguire solo i suoi ordini; l'amministratore tutti. */
function madr_user_can_track( $order ) {
	return $order && ( (int) $order->get_customer_id() === get_current_user_id() || current_user_can( 'manage_woocommerce' ) );
}

function madr_rest_tracking( WP_REST_Request $request ) {
	$order = wc_get_order( (int) $request['id'] );
	if ( ! madr_user_can_track( $order ) ) {
		return new WP_Error( 'madr_forbidden', __( 'Non puoi vedere questo ordine.', 'wp-app-dashboard' ), array( 'status' => 403 ) );
	}
	$row = madr_get_delivery( $order->get_id() );
	if ( ! $row || ! madr_is_home_delivery( $order ) ) {
		return rest_ensure_response( array( 'tracking' => false ) );
	}
	return rest_ensure_response( array( 'tracking' => true ) + madr_order_payload( $order, $row, 'customer' ) );
}

/** Ordini del cliente con una consegna ancora da chiudere o chiusa da poco (l'app li mostra con «Segui»). */
function madr_rest_customer_deliveries() {
	$orders = wc_get_orders( array(
		'customer_id'  => get_current_user_id(),
		'type'         => 'shop_order',
		'date_created' => '>' . ( time() - DAY_IN_SECONDS ),
		'limit'        => 10,
	) );
	$items = array();
	foreach ( $orders as $order ) {
		$row = madr_get_delivery( $order->get_id() );
		if ( $row && MADR_STATUS_WAITING !== $row->status ) {
			$items[] = madr_order_payload( $order, $row, 'customer' );
		}
	}
	return rest_ensure_response( array( 'deliveries' => $items ) );
}

/** Token breve per il browser: si scambia con un token Firebase per leggere la mappa in tempo reale. */
function madr_rest_firebase_token() {
	$jwt = madr_short_jwt_for_current_user();
	if ( '' === $jwt ) {
		return new WP_Error( 'madr_no_key', __( 'Tracciamento non configurato su questa sede.', 'wp-app-dashboard' ), array( 'status' => 503 ) );
	}
	return rest_ensure_response( array( 'token' => $jwt, 'functions' => madr_functions_public_url() ) );
}
