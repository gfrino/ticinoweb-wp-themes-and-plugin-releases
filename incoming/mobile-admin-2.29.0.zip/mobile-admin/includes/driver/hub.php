<?php
/**
 * Driver — gestione centrale sul sito del marchio (es. littleinka.ch), dalla 2.29.0.
 *
 * Dal sito principale si promuovono gli utenti a Driver e si sceglie per quali sedi consegnano.
 * Le sedi sono quelle collegate al marchio (le stesse di «Chiavi API app»: ARD_payment_methods_sites()).
 *
 * Fonte di verità: il ruolo `driver` di ogni sede (ogni sede ha i suoi ruoli, come in WordPress).
 * Spuntare una sede: l'utente entra nella sede (se non ne fa già parte), riceve il ruolo Driver lì e il
 * Driver si accende su quella sede. Togliere la spunta: perde il ruolo Driver solo in quella sede.
 * Così un Driver di Biasca non vede gli ordini di Rivera, e un Driver può consegnare per più sedi.
 *
 * Caricato solo sul sito del marchio, senza negozio (driver.php).
 *
 * @package mobile-admin
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

const MADR_HUB_CAP = 'manage_options';

/** Sedi collegate: [ host => [ 'name' => …, 'blog_id' => … ] ], solo quelle con un sito nella rete. */
function madr_hub_sites() {
	$out = array();
	if ( ! function_exists( 'ARD_payment_methods_sites' ) || ! function_exists( 'ARD_app_keys_blog_id' ) ) {
		return $out;
	}
	foreach ( (array) ARD_payment_methods_sites() as $host => $name ) {
		$blog_id = (int) ARD_app_keys_blog_id( $host );
		if ( $blog_id > 0 && $blog_id !== get_current_blog_id() ) {
			$out[ $host ] = array( 'name' => (string) $name, 'blog_id' => $blog_id );
		}
	}
	return $out;
}

/** È Driver in quella sede (ruolo della sede). */
function madr_hub_is_driver_in( $user_id, $blog_id ) {
	$user = new WP_User( (int) $user_id, '', (int) $blog_id );
	return $user->exists() && in_array( 'driver', (array) $user->roles, true );
}

/** Tutti i Driver delle sedi collegate: [ user_id => [ host, … ] ]. */
function madr_hub_drivers( $sites ) {
	$drivers = array();
	foreach ( $sites as $host => $site ) {
		$ids = get_users( array( 'blog_id' => $site['blog_id'], 'role' => 'driver', 'fields' => 'ID', 'number' => 500 ) );
		foreach ( $ids as $id ) {
			$drivers[ (int) $id ][] = $host;
		}
	}
	return $drivers;
}

/**
 * Applica le sedi scelte a un utente: ruolo Driver dove è spuntato, tolto altrove.
 * Accende il Driver sulle sedi che ricevono il primo Driver (le tabelle si creano alla prima visita della sede).
 */
function madr_hub_apply( $user_id, array $hosts, $sites ) {
	$user_id = (int) $user_id;
	foreach ( $sites as $host => $site ) {
		$blog_id = (int) $site['blog_id'];
		$want    = in_array( $host, $hosts, true );
		switch_to_blog( $blog_id );
		$user = new WP_User( $user_id );
		if ( $want ) {
			if ( ! is_user_member_of_blog( $user_id, $blog_id ) ) {
				add_user_to_blog( $blog_id, $user_id, get_role( 'customer' ) ? 'customer' : get_option( 'default_role', 'subscriber' ) );
				$user = new WP_User( $user_id );
			}
			if ( ! get_role( 'driver' ) ) {
				add_role( 'driver', __( 'Driver', 'wp-app-dashboard' ), array( 'read' => true, 'madr_deliver' => true ) );
			}
			if ( ! in_array( 'driver', (array) $user->roles, true ) ) {
				$user->add_role( 'driver' );
			}
			if ( '1' !== (string) get_option( MADR_ENABLED_OPTION, '0' ) ) {
				update_option( MADR_ENABLED_OPTION, '1', true );
			}
		} elseif ( in_array( 'driver', (array) $user->roles, true ) ) {
			$user->remove_role( 'driver' );
			// Nessun altro ruolo: resta cliente della sede (come prima di diventare Driver).
			if ( empty( $user->roles ) ) {
				$user->add_role( get_role( 'customer' ) ? 'customer' : 'subscriber' );
			}
		}
		restore_current_blog();
	}
	clean_user_cache( $user_id );
}

/** Utente da email, nome utente o ID. */
function madr_hub_find_user( $ref ) {
	$ref = trim( (string) $ref );
	if ( '' === $ref ) {
		return null;
	}
	$user = is_email( $ref ) ? get_user_by( 'email', $ref ) : get_user_by( 'login', $ref );
	if ( ! $user && ctype_digit( $ref ) ) {
		$user = get_user_by( 'id', (int) $ref );
	}
	return $user ?: null;
}

function madr_hub_url( $args = array() ) {
	return add_query_arg( array_merge( array( 'page' => MADR_ADMIN_SLUG ), $args ), admin_url( 'admin.php' ) );
}

function madr_hub_page() {
	if ( ! current_user_can( MADR_HUB_CAP ) ) {
		return;
	}
	$sites   = madr_hub_sites();
	$drivers = madr_hub_drivers( $sites );
	$msg     = isset( $_GET['madr_msg'] ) ? sanitize_text_field( wp_unslash( $_GET['madr_msg'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	$err     = isset( $_GET['madr_err'] ) ? sanitize_text_field( wp_unslash( $_GET['madr_err'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	?>
	<div class="wrap madr-hub">
		<h1><?php esc_html_e( 'Driver e consegne', 'wp-app-dashboard' ); ?></h1>
		<?php if ( $msg ) : ?><div class="notice notice-success is-dismissible"><p><?php echo esc_html( $msg ); ?></p></div><?php endif; ?>
		<?php if ( $err ) : ?><div class="notice notice-error is-dismissible"><p><?php echo esc_html( $err ); ?></p></div><?php endif; ?>
		<p class="madr-hub__intro"><?php esc_html_e( 'Qui scegli chi fa le consegne e per quali sedi. Un Driver vede nell\'app solo gli ordini delle sedi spuntate; può averne più di una.', 'wp-app-dashboard' ); ?></p>

		<?php if ( ! $sites ) : ?>
			<p><?php esc_html_e( 'Nessuna sede collegata trovata: le sedi sono i siti del marchio con il negozio WooCommerce.', 'wp-app-dashboard' ); ?></p>
		</div>
			<?php
			return;
		endif;
		?>

		<h2><?php esc_html_e( 'Aggiungi un Driver', 'wp-app-dashboard' ); ?></h2>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="madr-hub__add">
			<input type="hidden" name="action" value="madr_hub_add">
			<?php wp_nonce_field( 'madr_hub_add' ); ?>
			<p>
				<label for="madr-hub-user"><strong><?php esc_html_e( 'Utente', 'wp-app-dashboard' ); ?></strong></label><br>
				<input type="text" id="madr-hub-user" name="user" class="regular-text" placeholder="<?php esc_attr_e( 'Email o nome utente', 'wp-app-dashboard' ); ?>" required autocomplete="off">
				<br><span class="description"><?php esc_html_e( 'La persona deve avere già un account (lo stesso con cui accede all\'app).', 'wp-app-dashboard' ); ?></span>
			</p>
			<fieldset>
				<legend><strong><?php esc_html_e( 'Consegna per', 'wp-app-dashboard' ); ?></strong></legend>
				<?php foreach ( $sites as $host => $site ) : ?>
					<label class="madr-hub__site"><input type="checkbox" name="sedi[]" value="<?php echo esc_attr( $host ); ?>"> <?php echo esc_html( $site['name'] ); ?></label>
				<?php endforeach; ?>
			</fieldset>
			<?php submit_button( __( 'Rendi Driver', 'wp-app-dashboard' ), 'primary', 'submit', false ); ?>
		</form>

		<h2><?php echo esc_html( sprintf( /* translators: %d: number of drivers */ __( 'Driver (%d)', 'wp-app-dashboard' ), count( $drivers ) ) ); ?></h2>
		<?php if ( ! $drivers ) : ?>
			<p><?php esc_html_e( 'Ancora nessun Driver. Aggiungine uno qui sopra.', 'wp-app-dashboard' ); ?></p>
		<?php else : ?>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="madr_hub_save">
				<?php wp_nonce_field( 'madr_hub_save' ); ?>
				<table class="widefat striped madr-hub__table">
					<thead>
						<tr>
							<th scope="col"><?php esc_html_e( 'Driver', 'wp-app-dashboard' ); ?></th>
							<?php foreach ( $sites as $site ) : ?>
								<th scope="col" class="madr-hub__col"><?php echo esc_html( $site['name'] ); ?></th>
							<?php endforeach; ?>
						</tr>
					</thead>
					<tbody>
						<?php
						foreach ( $drivers as $user_id => $hosts ) :
							$u = get_userdata( $user_id );
							if ( ! $u ) {
								continue;
							}
							?>
							<tr>
								<td>
									<strong><?php echo esc_html( $u->display_name ); ?></strong><br>
									<span class="description"><?php echo esc_html( $u->user_email ); ?></span>
									<input type="hidden" name="drivers[]" value="<?php echo esc_attr( $user_id ); ?>">
								</td>
								<?php foreach ( $sites as $host => $site ) : ?>
									<td class="madr-hub__col">
										<label>
											<input type="checkbox" name="sedi[<?php echo esc_attr( $user_id ); ?>][]" value="<?php echo esc_attr( $host ); ?>" <?php checked( in_array( $host, $hosts, true ) ); ?>>
											<span class="screen-reader-text"><?php echo esc_html( $u->display_name . ' — ' . $site['name'] ); ?></span>
										</label>
									</td>
								<?php endforeach; ?>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
				<p class="description"><?php esc_html_e( 'Togli tutte le spunte di una riga per togliere il ruolo Driver a quella persona. Resta cliente come prima.', 'wp-app-dashboard' ); ?></p>
				<?php submit_button( __( 'Salva le sedi', 'wp-app-dashboard' ) ); ?>
			</form>
		<?php endif; ?>
	</div>
	<style>
		.madr-hub__intro { max-width: 760px; font-size: 14px; }
		.madr-hub__add { background: #fff; border: 1px solid #dcdcde; border-radius: 8px; padding: 12px 16px; max-width: 760px; }
		.madr-hub__add fieldset { margin: 8px 0 12px; }
		.madr-hub__site { display: inline-flex; align-items: center; gap: 6px; margin: 4px 16px 4px 0; white-space: nowrap; }
		.madr-hub__table { max-width: 1100px; }
		.madr-hub__col { text-align: center; }
		.madr-hub__table input[type=checkbox] { transform: scale(1.2); }
	</style>
	<?php
}

/** «Rendi Driver»: aggiunge le sedi spuntate a quelle che l'utente ha già. */
add_action( 'admin_post_madr_hub_add', function () {
	check_admin_referer( 'madr_hub_add' );
	if ( ! current_user_can( MADR_HUB_CAP ) ) {
		wp_die( esc_html__( 'Non hai i permessi per questa operazione.', 'wp-app-dashboard' ), 403 );
	}
	$sites = madr_hub_sites();
	$user  = madr_hub_find_user( isset( $_POST['user'] ) ? sanitize_text_field( wp_unslash( $_POST['user'] ) ) : '' );
	$hosts = array_values( array_intersect( array_map( 'sanitize_text_field', (array) wp_unslash( $_POST['sedi'] ?? array() ) ), array_keys( $sites ) ) );
	if ( ! $user ) {
		wp_safe_redirect( madr_hub_url( array( 'madr_err' => rawurlencode( __( 'Nessun utente con questa email o questo nome utente.', 'wp-app-dashboard' ) ) ) ) );
		exit;
	}
	if ( ! $hosts ) {
		wp_safe_redirect( madr_hub_url( array( 'madr_err' => rawurlencode( __( 'Spunta almeno una sede.', 'wp-app-dashboard' ) ) ) ) );
		exit;
	}
	$current = madr_hub_drivers( $sites );
	$keep    = isset( $current[ $user->ID ] ) ? $current[ $user->ID ] : array();
	madr_hub_apply( $user->ID, array_values( array_unique( array_merge( $keep, $hosts ) ) ), $sites );
	/* translators: %s: user display name */
	wp_safe_redirect( madr_hub_url( array( 'madr_msg' => rawurlencode( sprintf( __( '%s ora è Driver.', 'wp-app-dashboard' ), $user->display_name ) ) ) ) );
	exit;
} );

/** «Salva le sedi»: la tabella intera (spunte per Driver e sede). */
add_action( 'admin_post_madr_hub_save', function () {
	check_admin_referer( 'madr_hub_save' );
	if ( ! current_user_can( MADR_HUB_CAP ) ) {
		wp_die( esc_html__( 'Non hai i permessi per questa operazione.', 'wp-app-dashboard' ), 403 );
	}
	$sites   = madr_hub_sites();
	$drivers = array_map( 'absint', (array) wp_unslash( $_POST['drivers'] ?? array() ) );
	$sedi    = (array) wp_unslash( $_POST['sedi'] ?? array() );
	foreach ( $drivers as $user_id ) {
		if ( ! $user_id || ! get_userdata( $user_id ) ) {
			continue;
		}
		$hosts = isset( $sedi[ $user_id ] ) ? array_map( 'sanitize_text_field', (array) $sedi[ $user_id ] ) : array();
		madr_hub_apply( $user_id, array_values( array_intersect( $hosts, array_keys( $sites ) ) ), $sites );
	}
	wp_safe_redirect( madr_hub_url( array( 'madr_msg' => rawurlencode( __( 'Sedi dei Driver salvate.', 'wp-app-dashboard' ) ) ) ) );
	exit;
} );
