<?php
/**
 * Sito: tracking del cliente nella pagina dell'ordine (Il mio account → Ordini → Visualizza).
 * Le funzioni del Driver stanno solo nell'app (2.28.0): il sito non ha una pagina «Driver».
 *
 * @package mobile-admin
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* ------------------------------------------------------- Tracking del cliente */

add_action( 'woocommerce_order_details_before_order_table', 'madr_render_customer_tracking', 5 );

function madr_render_customer_tracking( $order ) {
	if ( ! $order instanceof WC_Order || ! madr_user_can_track( $order ) || ! madr_is_home_delivery( $order ) ) {
		return;
	}
	$row = madr_get_delivery( $order->get_id() );
	if ( ! $row || in_array( $row->status, array( MADR_STATUS_WAITING, MADR_STATUS_CANCELLED ), true ) ) {
		return;
	}
	$config = madr_firebase_web_config();
	wp_enqueue_style( 'madr-driver', MADR_URL . 'css/driver.css', array(), MADR_VERSION );
	$live = $config && in_array( $row->status, madr_active_statuses(), true );
	if ( $live ) {
		// Leaflet incluso nel plugin (licenza BSD-2 in assets/vendor/leaflet): nessuna richiesta a CDN esterni.
		wp_enqueue_style( 'madr-leaflet', MADR_URL . 'vendor/leaflet/leaflet.css', array(), '1.9.4' );
		wp_enqueue_script( 'madr-leaflet', MADR_URL . 'vendor/leaflet/leaflet.js', array(), '1.9.4', true );
		wp_enqueue_script_module( 'madr-tracking', MADR_URL . 'js/tracking.js', array(), MADR_VERSION );
		do_action( 'litespeed_control_set_nocache', 'mobile-admin driver tracking' );
	}
	$data = array(
		'rest'      => esc_url_raw( rest_url( MADR_REST_NS ) ),
		'nonce'     => wp_create_nonce( 'wp_rest' ),
		'orderId'   => (int) $order->get_id(),
		'docId'     => madr_tracking_doc_id( $order->get_id() ),
		'status'    => $row->status,
		'firebase'  => $config,
		'emulator'  => defined( 'MADR_FIREBASE_EMULATOR' ) ? (string) MADR_FIREBASE_EMULATOR : '',
		// Carta nazionale grigia di swisstopo, dove l'auto risalta (servizio federale svizzero, dati aperti con attribuzione): le richieste
		// delle tessere restano in Svizzera. Sostituibile con il filtro madr_map_tiles.
		'tiles'     => apply_filters( 'madr_map_tiles', 'https://wmts.geo.admin.ch/1.0.0/ch.swisstopo.pixelkarte-grau/default/current/3857/{z}/{x}/{y}.jpeg' ),
		'tilesAttribution' => apply_filters( 'madr_map_tiles_attribution', '&copy; swisstopo' ),
		'statuses'  => madr_status_labels(),
		'i18n'      => array(
			'stale'     => __( 'Posizione non aggiornata da %s min', 'wp-app-dashboard' ),
			'waitGps'   => __( 'In attesa della posizione del Driver…', 'wp-app-dashboard' ),
			'delivered' => __( 'Il tuo ordine è stato consegnato. Buon appetito!', 'wp-app-dashboard' ),
			'cancelled' => __( 'La consegna è stata annullata.', 'wp-app-dashboard' ),
			'driver'    => __( 'Il tuo Driver', 'wp-app-dashboard' ),
			'home'      => __( 'Consegna qui', 'wp-app-dashboard' ),
			'offline'   => __( 'Connessione assente: la mappa riprende da sola.', 'wp-app-dashboard' ),
			'error'     => __( 'Mappa non disponibile in questo momento.', 'wp-app-dashboard' ),
		),
	);
	$steps = array( MADR_STATUS_ASSIGNED, MADR_STATUS_EN_ROUTE, MADR_STATUS_DELIVERED );
	$index = array_search( $row->status, $steps, true );
	?>
	<section class="madr-track" id="madr-track" data-config="<?php echo esc_attr( wp_json_encode( $data ) ); ?>">
		<h2 class="madr-track__title"><?php esc_html_e( 'La tua consegna', 'wp-app-dashboard' ); ?></h2>
		<ol class="madr-steps">
			<?php foreach ( $steps as $i => $step ) : ?>
				<li class="madr-steps__item<?php echo false !== $index && $i <= $index ? ' is-done' : ''; ?><?php echo $i === $index ? ' is-current' : ''; ?>" data-step="<?php echo esc_attr( $step ); ?>"><?php echo esc_html( madr_status_label( $step ) ); ?></li>
			<?php endforeach; ?>
		</ol>
		<?php if ( MADR_STATUS_DELIVERED === $row->status ) : ?>
			<p class="madr-track__done"><?php esc_html_e( 'Il tuo ordine è stato consegnato. Buon appetito!', 'wp-app-dashboard' ); ?></p>
		<?php elseif ( $live ) : ?>
			<div class="madr-track__map" id="madr-track-map" role="img" aria-label="<?php esc_attr_e( 'Mappa con la posizione del Driver', 'wp-app-dashboard' ); ?>"></div>
			<p class="madr-track__info" id="madr-track-info"><?php esc_html_e( 'In attesa della posizione del Driver…', 'wp-app-dashboard' ); ?></p>
		<?php endif; ?>
	</section>
	<?php
}
