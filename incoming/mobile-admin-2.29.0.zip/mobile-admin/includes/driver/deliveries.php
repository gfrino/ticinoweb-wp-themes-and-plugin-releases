<?php
/**
 * Consegne: dati e transizioni di stato.
 *
 * Fonte di verità: la tabella {prefix}madr_deliveries della sede (una riga per ordine).
 * L'assegnazione è un solo UPDATE condizionato («solo se ancora libero»): con due Driver
 * che accettano insieme, MySQL fa vincere uno solo e l'altro riceve 409.
 * Ogni transizione aggiorna i meta dell'ordine (colonna in admin), scrive nel registro
 * e sincronizza il documento di tracking su Firestore (includes/firebase.php).
 *
 * @package mobile-admin
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Riga della consegna, o null. */
function madr_get_delivery( $order_id ) {
	global $wpdb;
	$table = madr_table( 'deliveries' );
	return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE order_id = %d", (int) $order_id ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
}

/** Crea la riga «in attesa» se non c'è (idempotente). */
function madr_ensure_row( $order_id ) {
	global $wpdb;
	$table = madr_table( 'deliveries' );
	$wpdb->query( $wpdb->prepare( "INSERT IGNORE INTO {$table} (order_id, status, updated_at) VALUES (%d, %s, %s)", (int) $order_id, MADR_STATUS_WAITING, madr_now() ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
}

/** Registro delle operazioni (chi, cosa, quando): serve all'amministratore e ai problemi di assegnazione. */
function madr_log( $order_id, $event, $note = '', $driver_id = null, $actor_id = null ) {
	global $wpdb;
	$wpdb->insert(
		madr_table( 'events' ),
		array(
			'order_id'   => (int) $order_id,
			'driver_id'  => $driver_id ? (int) $driver_id : null,
			'actor_id'   => null === $actor_id ? ( get_current_user_id() ?: null ) : (int) $actor_id,
			'event'      => substr( sanitize_key( $event ), 0, 30 ),
			'note'       => $note ? substr( wp_strip_all_tags( $note ), 0, 255 ) : null,
			'created_at' => madr_now(),
		)
	);
}

/** È un ordine «a domicilio»? Meta `delivery_type` scritto dall'app (Cloud Functions) e dal checkout del sito. */
function madr_is_home_delivery( $order ) {
	$type = strtolower( (string) $order->get_meta( 'delivery_type' ) );
	return (bool) apply_filters( 'madr_is_home_delivery', 'delivery' === $type, $order );
}

/** L'ordine può essere assegnato a un Driver adesso? */
function madr_order_is_eligible( $order ) {
	if ( ! $order instanceof WC_Order || ! madr_is_home_delivery( $order ) ) {
		return false;
	}
	$s = madr_settings();
	if ( ! in_array( $order->get_status(), $s['statuses'], true ) ) {
		return false;
	}
	$created = $order->get_date_created();
	if ( $created && $created->getTimestamp() < time() - $s['max_age_hours'] * HOUR_IN_SECONDS ) {
		return false;
	}
	return (bool) apply_filters( 'madr_order_is_eligible', true, $order );
}

/**
 * Ordini pronti e non ancora presi in carico.
 *
 * @return WC_Order[]
 */
function madr_available_orders() {
	$s      = madr_settings();
	$orders = wc_get_orders(
		array(
			'type'         => 'shop_order',
			'status'       => array_map( function ( $st ) { return 'wc-' . $st; }, $s['statuses'] ),
			'date_created' => '>' . ( time() - $s['max_age_hours'] * HOUR_IN_SECONDS ),
			// I già presi si escludono nella query (meta scritto da madr_after_change): un limite applicato prima
			// del filtro farebbe sparire gli ordini nuovi nelle ore di punta.
			'meta_query'   => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
				'relation' => 'AND',
				array( 'key' => 'delivery_type', 'value' => 'delivery' ),
				array(
					'relation' => 'OR',
					array( 'key' => '_madr_delivery_status', 'compare' => 'NOT EXISTS' ),
					array( 'key' => '_madr_delivery_status', 'value' => MADR_STATUS_WAITING ),
				),
			),
			'limit'        => 200,
			'orderby'      => 'date',
			'order'        => 'ASC',
		)
	);
	if ( ! $orders ) {
		return array();
	}
	global $wpdb;
	$table = madr_table( 'deliveries' );
	$ids   = array_map( function ( $o ) { return (int) $o->get_id(); }, $orders );
	$taken = $wpdb->get_col( "SELECT order_id FROM {$table} WHERE order_id IN (" . implode( ',', $ids ) . ") AND status <> 'waiting'" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- interi.
	$taken = array_map( 'intval', $taken );
	return array_values( array_filter( $orders, function ( $o ) use ( $taken ) {
		return ! in_array( (int) $o->get_id(), $taken, true ) && madr_order_is_eligible( $o );
	} ) );
}

/** Consegne del Driver, per stato. */
function madr_driver_deliveries( $driver_id, $statuses, $limit = 50 ) {
	global $wpdb;
	$table    = madr_table( 'deliveries' );
	$statuses = array_map( 'sanitize_key', (array) $statuses );
	$in       = "'" . implode( "','", $statuses ) . "'";
	$order_by = in_array( MADR_STATUS_DELIVERED, $statuses, true ) ? 'delivered_at DESC' : 'accepted_at ASC';
	return $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$table} WHERE driver_id = %d AND status IN ({$in}) ORDER BY {$order_by} LIMIT %d", (int) $driver_id, (int) $limit ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- stati sanificati.
}

function madr_driver_active_count( $driver_id ) {
	return count( madr_driver_deliveries( $driver_id, madr_active_statuses(), 100 ) );
}

/* ---------------------------------------------------------------------------
 * Disponibilità (per sede: user option col prefisso della sede)
 * ------------------------------------------------------------------------ */

function madr_get_availability( $user_id ) {
	$v = get_user_option( 'madr_availability', (int) $user_id );
	return in_array( $v, array( 'available', 'busy', 'off' ), true ) ? $v : 'off';
}

function madr_set_availability( $user_id, $value ) {
	if ( ! in_array( $value, array( 'available', 'busy', 'off' ), true ) ) {
		return false;
	}
	update_user_option( (int) $user_id, 'madr_availability', $value );
	return true;
}

/* ---------------------------------------------------------------------------
 * Transizioni
 * ------------------------------------------------------------------------ */

/** Dopo ogni cambio: meta dell'ordine (per l'admin) e documento Firestore. */
function madr_after_change( $order_id, $notify = '' ) {
	$row   = madr_get_delivery( $order_id );
	$order = wc_get_order( $order_id );
	if ( $row && $order ) {
		$order->update_meta_data( '_madr_delivery_status', $row->status );
		$order->update_meta_data( '_madr_driver_id', (int) $row->driver_id );
		$order->save_meta_data();
	}
	if ( $row ) {
		madr_firebase_sync( $row, $notify );
	}
	do_action( 'madr_delivery_changed', $order_id, $row );
}

/**
 * «Accetto consegna».
 *
 * @return object|WP_Error Riga aggiornata.
 */
function madr_accept( $order_id, $driver_id ) {
	global $wpdb;
	$order = wc_get_order( $order_id );
	if ( ! $order || ! madr_order_is_eligible( $order ) ) {
		return new WP_Error( 'madr_not_available', __( 'Questo ordine non è più disponibile.', 'wp-app-dashboard' ), array( 'status' => 409 ) );
	}
	$row = madr_get_delivery( $order_id );
	// Richiesta ripetuta dallo stesso Driver (doppio tocco, rete lenta): stessa risposta, nessun doppione.
	if ( $row && (int) $row->driver_id === (int) $driver_id && in_array( $row->status, madr_active_statuses(), true ) ) {
		return $row;
	}
	if ( 'off' === madr_get_availability( $driver_id ) ) {
		return new WP_Error( 'madr_unavailable', __( 'Sei segnato come «Non disponibile». Cambia la disponibilità per accettare consegne.', 'wp-app-dashboard' ), array( 'status' => 409 ) );
	}
	$max = madr_settings()['max_active'];
	if ( $max > 0 && madr_driver_active_count( $driver_id ) >= $max ) {
		/* translators: %d: numero massimo di consegne contemporanee */
		return new WP_Error( 'madr_too_many', sprintf( __( 'Hai già %d consegne in corso: completale prima di accettarne altre.', 'wp-app-dashboard' ), $max ), array( 'status' => 409 ) );
	}

	madr_ensure_row( $order_id );
	$table   = madr_table( 'deliveries' );
	$now     = madr_now();
	$updated = $wpdb->query( $wpdb->prepare( "UPDATE {$table} SET driver_id = %d, status = %s, accepted_at = %s, updated_at = %s WHERE order_id = %d AND driver_id IS NULL AND status = %s", (int) $driver_id, MADR_STATUS_ASSIGNED, $now, $now, (int) $order_id, MADR_STATUS_WAITING ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	if ( 1 !== (int) $updated ) {
		$row = madr_get_delivery( $order_id );
		if ( $row && (int) $row->driver_id === (int) $driver_id && in_array( $row->status, madr_active_statuses(), true ) ) {
			return $row;
		}
		madr_log( $order_id, 'accept_lost', '', $driver_id );
		return new WP_Error( 'madr_taken', __( 'Un altro Driver ha appena preso questo ordine.', 'wp-app-dashboard' ), array( 'status' => 409 ) );
	}

	$user = get_userdata( $driver_id );
	/* translators: %s: nome del Driver */
	$order->add_order_note( sprintf( __( 'Consegna presa in carico dal Driver %s.', 'wp-app-dashboard' ), $user ? $user->display_name : '#' . $driver_id ) );
	madr_log( $order_id, 'accepted', '', $driver_id );
	if ( 'available' === madr_get_availability( $driver_id ) && $max > 0 && madr_driver_active_count( $driver_id ) >= $max ) {
		madr_set_availability( $driver_id, 'busy' );
	}
	madr_after_change( $order_id, 'assigned' );
	return madr_get_delivery( $order_id );
}

/**
 * Il Driver parte: tracking attivo. $dest = destinazione geocodificata dal telefono (facoltativa).
 *
 * @return object|WP_Error
 */
function madr_start( $order_id, $driver_id, $dest = null ) {
	global $wpdb;
	$row = madr_get_delivery( $order_id );
	if ( ! $row || (int) $row->driver_id !== (int) $driver_id ) {
		return new WP_Error( 'madr_forbidden', __( 'Questa consegna non è assegnata a te.', 'wp-app-dashboard' ), array( 'status' => 403 ) );
	}
	if ( MADR_STATUS_EN_ROUTE === $row->status ) {
		return $row; // già partito: idempotente.
	}
	if ( MADR_STATUS_ASSIGNED !== $row->status ) {
		return new WP_Error( 'madr_bad_state', __( 'La consegna non può essere avviata in questo stato.', 'wp-app-dashboard' ), array( 'status' => 409 ) );
	}
	$data = array( 'status' => MADR_STATUS_EN_ROUTE, 'started_at' => madr_now(), 'updated_at' => madr_now() );
	if ( is_array( $dest ) && isset( $dest['lat'], $dest['lng'] ) && madr_valid_coords( $dest['lat'], $dest['lng'] ) ) {
		$data['dest_lat'] = round( (float) $dest['lat'], 6 );
		$data['dest_lng'] = round( (float) $dest['lng'], 6 );
	}
	$wpdb->update( madr_table( 'deliveries' ), $data, array( 'order_id' => (int) $order_id, 'status' => MADR_STATUS_ASSIGNED ) );
	madr_log( $order_id, 'started', '', $driver_id );
	madr_after_change( $order_id, 'en_route' );
	return madr_get_delivery( $order_id );
}

/**
 * «Consegnato». Idempotente: una seconda richiesta (rete instabile) risponde come la prima.
 *
 * @return object|WP_Error
 */
function madr_complete( $order_id, $driver_id ) {
	global $wpdb;
	$row = madr_get_delivery( $order_id );
	if ( ! $row || (int) $row->driver_id !== (int) $driver_id ) {
		return new WP_Error( 'madr_forbidden', __( 'Questa consegna non è assegnata a te.', 'wp-app-dashboard' ), array( 'status' => 403 ) );
	}
	if ( MADR_STATUS_DELIVERED === $row->status ) {
		return $row;
	}
	if ( ! in_array( $row->status, madr_active_statuses(), true ) ) {
		return new WP_Error( 'madr_bad_state', __( 'La consegna non è più attiva (forse l\'ordine è stato annullato).', 'wp-app-dashboard' ), array( 'status' => 409 ) );
	}
	$table = madr_table( 'deliveries' );
	$now   = madr_now();
	$wpdb->query( $wpdb->prepare( "UPDATE {$table} SET status = %s, delivered_at = %s, updated_at = %s WHERE order_id = %d AND driver_id = %d AND status IN ('assigned','en_route')", MADR_STATUS_DELIVERED, $now, $now, (int) $order_id, (int) $driver_id ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared

	$order = wc_get_order( $order_id );
	if ( $order ) {
		$order->add_order_note( __( 'Ordine consegnato dal Driver.', 'wp-app-dashboard' ) );
		$order->update_meta_data( '_madr_delivered_at', $now );
		$order->save_meta_data();
	}
	madr_log( $order_id, 'delivered', '', $driver_id );
	if ( 'busy' === madr_get_availability( $driver_id ) ) {
		madr_set_availability( $driver_id, 'available' );
	}
	madr_after_change( $order_id, 'delivered' );
	return madr_get_delivery( $order_id );
}

/**
 * Riassegnazione dall'amministratore. $new_driver_id = 0 rimette l'ordine «in attesa».
 * Il Driver precedente perde subito l'accesso (driver_id cambia) e il suo tracking si chiude.
 *
 * @return object|WP_Error
 */
function madr_reassign( $order_id, $new_driver_id, $actor_id ) {
	global $wpdb;
	$order = wc_get_order( $order_id );
	if ( ! $order ) {
		return new WP_Error( 'madr_no_order', __( 'Ordine non trovato.', 'wp-app-dashboard' ), array( 'status' => 404 ) );
	}
	if ( $new_driver_id && ! madr_is_driver( $new_driver_id ) ) {
		return new WP_Error( 'madr_not_driver', __( 'L\'utente scelto non è un Driver di questa sede.', 'wp-app-dashboard' ), array( 'status' => 400 ) );
	}
	madr_ensure_row( $order_id );
	$row = madr_get_delivery( $order_id );
	if ( in_array( $row->status, array( MADR_STATUS_DELIVERED, MADR_STATUS_CANCELLED ), true ) ) {
		return new WP_Error( 'madr_closed', __( 'La consegna è già chiusa.', 'wp-app-dashboard' ), array( 'status' => 409 ) );
	}
	$now = madr_now();
	$wpdb->update(
		madr_table( 'deliveries' ),
		array(
			'driver_id'   => $new_driver_id ? (int) $new_driver_id : null,
			'status'      => $new_driver_id ? MADR_STATUS_ASSIGNED : MADR_STATUS_WAITING,
			'accepted_at' => $new_driver_id ? $now : null,
			'started_at'  => null,
			'updated_at'  => $now,
		),
		array( 'order_id' => (int) $order_id )
	);
	$old  = (int) $row->driver_id;
	$user = $new_driver_id ? get_userdata( $new_driver_id ) : null;
	/* translators: %s: nome del nuovo Driver, o «nessuno» */
	$order->add_order_note( sprintf( __( 'Consegna riassegnata dall\'amministratore a: %s.', 'wp-app-dashboard' ), $user ? $user->display_name : __( 'nessuno (di nuovo disponibile)', 'wp-app-dashboard' ) ) );
	madr_log( $order_id, 'reassigned', $old ? 'da #' . $old : '', $new_driver_id ?: null, $actor_id );
	madr_after_change( $order_id, $new_driver_id ? 'assigned' : '' );
	return madr_get_delivery( $order_id );
}

/** Ordine annullato/rimborsato/fallito: la consegna si chiude e il tracking si ferma. */
function madr_cancel( $order_id, $reason = '' ) {
	global $wpdb;
	$row = madr_get_delivery( $order_id );
	if ( ! $row || in_array( $row->status, array( MADR_STATUS_DELIVERED, MADR_STATUS_CANCELLED ), true ) ) {
		return;
	}
	$wpdb->update(
		madr_table( 'deliveries' ),
		array( 'status' => MADR_STATUS_CANCELLED, 'cancelled_at' => madr_now(), 'updated_at' => madr_now() ),
		array( 'order_id' => (int) $order_id )
	);
	madr_log( $order_id, 'cancelled', $reason, $row->driver_id ?: null );
	madr_after_change( $order_id, $row->driver_id ? 'cancelled' : '' );
}

add_action( 'woocommerce_order_status_changed', function ( $order_id, $from, $to ) {
	if ( in_array( $to, array( 'cancelled', 'refunded', 'failed', 'trash' ), true ) ) {
		/* translators: %s: stato WooCommerce */
		madr_cancel( $order_id, sprintf( 'ordine %s', $to ) );
		return;
	}
	// Annullato per errore e poi ripristinato: la consegna torna «in attesa» per un Driver.
	if ( in_array( $from, array( 'cancelled', 'refunded', 'failed' ), true ) && in_array( $to, madr_settings()['statuses'], true ) ) {
		madr_reopen( $order_id );
	}
}, 20, 3 );

/** Riapre una consegna annullata (ordine ripristinato): torna «in attesa», senza Driver. */
function madr_reopen( $order_id ) {
	global $wpdb;
	$row = madr_get_delivery( $order_id );
	if ( ! $row || MADR_STATUS_CANCELLED !== $row->status ) {
		return;
	}
	$wpdb->update(
		madr_table( 'deliveries' ),
		array( 'status' => MADR_STATUS_WAITING, 'driver_id' => null, 'accepted_at' => null, 'started_at' => null, 'cancelled_at' => null, 'updated_at' => madr_now() ),
		array( 'order_id' => (int) $order_id )
	);
	madr_log( $order_id, 'reopened', 'ordine ripristinato' );
	madr_after_change( $order_id );
}

/**
 * Revoca del ruolo: effetto immediato perché ogni richiesta controlla la capacità lato server.
 * Le consegne attive di quel Driver tornano «in attesa» per un altro Driver.
 */
function madr_release_driver( $user_id, $reason = 'role_revoked' ) {
	$released = 0;
	foreach ( madr_driver_deliveries( $user_id, madr_active_statuses(), 100 ) as $row ) {
		$result = madr_reassign( $row->order_id, 0, get_current_user_id() ?: null );
		if ( ! is_wp_error( $result ) ) {
			madr_log( $row->order_id, $reason, '', $user_id );
			$released++;
		}
	}
	update_user_option( (int) $user_id, 'madr_availability', 'off' );
	return $released;
}

add_action( 'remove_user_role', function ( $user_id, $role ) {
	if ( 'driver' === $role ) {
		madr_release_driver( $user_id );
	}
}, 10, 2 );
/**
 * WordPress: salvare un profilo (Utenti → Modifica, campo «Ruolo») chiama set_role(), che toglie TUTTI i ruoli,
 * compreso «driver» aggiunto come secondo ruolo. Qui lo si rimette: il ruolo Driver si toglie solo con «Revoca»
 * (remove_role → madr_release_driver), mai per effetto collaterale di un salvataggio.
 */
add_action( 'set_user_role', function ( $user_id, $role, $old_roles ) {
	if ( 'driver' === $role || ! in_array( 'driver', (array) $old_roles, true ) || did_action( 'madr_revoking' ) ) {
		return;
	}
	$user = get_userdata( $user_id );
	if ( $user && ! in_array( 'driver', (array) $user->roles, true ) ) {
		$user->add_role( 'driver' );
	}
}, 10, 3 );
add_action( 'remove_user_from_blog', function ( $user_id ) {
	if ( madr_is_driver( $user_id ) ) {
		madr_release_driver( $user_id, 'removed_from_site' );
	}
}, 10, 1 );

/* ---------------------------------------------------------------------------
 * Dati per le API: solo ciò che serve, e i dati personali solo al Driver assegnato
 * ------------------------------------------------------------------------ */

function madr_valid_coords( $lat, $lng ) {
	return is_numeric( $lat ) && is_numeric( $lng ) && abs( (float) $lat ) <= 90 && abs( (float) $lng ) <= 180 && ! ( 0.0 === (float) $lat && 0.0 === (float) $lng );
}

/** Indirizzo di consegna: spedizione se compilata, altrimenti fatturazione. */
function madr_order_address( $order ) {
	$use = $order->get_shipping_address_1() ? 'shipping' : 'billing';
	$get = function ( $field ) use ( $order, $use ) {
		$m = "get_{$use}_{$field}";
		return method_exists( $order, $m ) ? trim( (string) $order->$m() ) : '';
	};
	$street = trim( $get( 'address_1' ) . ' ' . $get( 'address_2' ) );
	$city   = trim( $get( 'postcode' ) . ' ' . $get( 'city' ) );
	return array(
		'street' => $street,
		'city'   => $city,
		'full'   => trim( $street . ', ' . $city, ', ' ),
	);
}

/**
 * Il Driver deve incassare? WooCommerce considera «pagato» ogni ordine in lavorazione, quindi si guarda il metodo:
 * contrassegno del sito (cod) o «Pagamento Alla Consegna» dell'app (Cloud Functions). La data di pagamento non serve:
 * WooCommerce la imposta da solo quando l'ordine passa «in lavorazione».
 */
function madr_order_pay_on_delivery( $order ) {
	$method = strtolower( $order->get_payment_method() . ' ' . $order->get_payment_method_title() );
	$cod    = 'cod' === $order->get_payment_method() || false !== strpos( $method, 'alla consegna' ) || false !== strpos( $method, 'on delivery' );
	return (bool) apply_filters( 'madr_order_pay_on_delivery', $cod, $order );
}

/** Fascia oraria: l'app scrive «nome‖HH:MM - HH:MM», il sito solo l'orario. */
function madr_order_slot( $order ) {
	$slot = (string) $order->get_meta( 'delivery_time' );
	if ( false !== strpos( $slot, '‖' ) ) {
		$parts = explode( '‖', $slot );
		$slot  = end( $parts );
	}
	return trim( $slot );
}

/**
 * Ordine per le API.
 *
 * @param string $view 'available' (niente dati personali), 'driver' (dettaglio al Driver assegnato), 'customer'.
 */
function madr_order_payload( $order, $row = null, $view = 'available' ) {
	$address = madr_order_address( $order );
	$created = $order->get_date_created();
	$data    = array(
		'order_id'     => (int) $order->get_id(),
		'number'       => (string) $order->get_order_number(),
		'created_at'   => $created ? $created->date( 'c' ) : null,
		'slot'         => madr_order_slot( $order ),
		'order_status' => $order->get_status(),
		'status'       => $row ? $row->status : MADR_STATUS_WAITING,
		'status_label' => madr_status_label( $row ? $row->status : MADR_STATUS_WAITING ),
		'address'      => array(
			'street' => $address['street'],
			'city'   => $address['city'],
		),
		'note'         => wp_strip_all_tags( (string) $order->get_customer_note() ),
		'items_count'  => (int) $order->get_item_count(),
	);
	if ( 'available' === $view ) {
		return $data;
	}
	$data['accepted_at']  = $row ? madr_iso( $row->accepted_at ) : null;
	$data['started_at']   = $row ? madr_iso( $row->started_at ) : null;
	$data['delivered_at'] = $row ? madr_iso( $row->delivered_at ) : null;
	$data['tracking_doc'] = madr_tracking_doc_id( $order->get_id() );
	if ( $row && null !== $row->dest_lat ) {
		$data['destination'] = array( 'lat' => (float) $row->dest_lat, 'lng' => (float) $row->dest_lng );
	}
	if ( 'customer' === $view ) {
		unset( $data['note'] );
		return $data;
	}
	// Dettaglio al Driver assegnato e solo finché la consegna è attiva: dopo restano i dati minimi.
	$active = $row && in_array( $row->status, madr_active_statuses(), true );
	$data['address']['full'] = $address['full'];
	if ( $active ) {
		$data['customer'] = array(
			'name'  => trim( ( $order->get_shipping_first_name() ?: $order->get_billing_first_name() ) . ' ' . mb_substr( (string) ( $order->get_shipping_last_name() ?: $order->get_billing_last_name() ), 0, 1 ) . '.' ),
			'phone' => (string) $order->get_billing_phone(),
		);
		$data['items'] = array();
		foreach ( $order->get_items() as $item ) {
			$data['items'][] = array( 'name' => $item->get_name(), 'qty' => (int) $item->get_quantity() );
		}
		$data['to_collect'] = ! madr_order_pay_on_delivery( $order ) ? null : array(
			'amount'   => (float) $order->get_total(),
			'currency' => $order->get_currency(),
			'label'    => html_entity_decode( wp_strip_all_tags( wc_price( $order->get_total(), array( 'currency' => $order->get_currency() ) ) ), ENT_QUOTES, 'UTF-8' ),
		);
		$q                    = rawurlencode( $address['full'] );
		$data['navigation']   = array(
			'google'      => 'https://www.google.com/maps/dir/?api=1&destination=' . $q . '&travelmode=driving',
			'apple'       => 'https://maps.apple.com/?daddr=' . $q . '&dirflg=d',
			'google_app'  => 'comgooglemaps://?daddr=' . $q . '&directionsmode=driving',
			'android_nav' => 'google.navigation:q=' . $q,
		);
	} else {
		$data['address'] = array( 'street' => '', 'city' => $address['city'], 'full' => $address['city'] );
		$data['note']    = '';
	}
	return $data;
}
