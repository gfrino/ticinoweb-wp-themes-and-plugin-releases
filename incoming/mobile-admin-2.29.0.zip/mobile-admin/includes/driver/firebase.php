<?php
/**
 * Collegamento con le Cloud Functions dell'app (Firebase).
 *
 * - WordPress decide (assegnazioni, stati): dopo ogni cambio chiama `driverTracking/sync`,
 *   che aggiorna il documento Firestore `deliveries/{docId}` e manda la notifica push al cliente.
 * - La posizione la scrive il telefono del Driver passando dalle Cloud Functions (`driverTracking/position`),
 *   che controllano che sia proprio il Driver assegnato e che la consegna sia in corso.
 * - Cliente e amministratore leggono il documento in tempo reale con Firebase Auth: il sito chiede
 *   qui un token breve firmato come quelli dell'app (simple-jwt-login) e lo scambia con le Cloud Functions.
 *
 * Indirizzo e segreto sono quelli già configurati da Mobile Admin (Gestione App), senza duplicarli:
 * ARD_app_functions_url() e ARD_app_keys_secret(); in alternativa le costanti MADR_FUNCTIONS_URL / MADR_SERVER_SECRET.
 *
 * @package mobile-admin
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function madr_functions_url() {
	if ( defined( 'MADR_FUNCTIONS_URL' ) && MADR_FUNCTIONS_URL ) {
		return untrailingslashit( (string) MADR_FUNCTIONS_URL );
	}
	if ( function_exists( 'ARD_app_functions_url' ) ) {
		return untrailingslashit( (string) ARD_app_functions_url() );
	}
	return '';
}

/**
 * Indirizzo delle Cloud Functions per il browser (mappa del cliente). Di solito è lo stesso del server;
 * si separa quando il server le raggiunge con un nome che il browser non conosce (es. Docker: host.docker.internal).
 */
function madr_functions_public_url() {
	if ( defined( 'MADR_FUNCTIONS_PUBLIC_URL' ) && MADR_FUNCTIONS_PUBLIC_URL ) {
		return untrailingslashit( (string) MADR_FUNCTIONS_PUBLIC_URL );
	}
	return madr_functions_url();
}

function madr_server_secret() {
	if ( defined( 'MADR_SERVER_SECRET' ) && MADR_SERVER_SECRET ) {
		return (string) MADR_SERVER_SECRET;
	}
	return function_exists( 'ARD_app_keys_secret' ) ? (string) ARD_app_keys_secret() : '';
}

/**
 * Aggiorna il documento di tracking. $notify: tipo di notifica al cliente ('assigned', 'en_route', 'delivered', 'cancelled' o '').
 */
function madr_firebase_sync( $row, $notify = '' ) {
	$url    = madr_functions_url();
	$secret = madr_server_secret();
	if ( ! $url || ! $secret ) {
		return false;
	}
	$order = wc_get_order( $row->order_id );
	if ( ! $order ) {
		return false;
	}
	$driver = $row->driver_id ? get_userdata( $row->driver_id ) : null;
	$body   = array(
		'docId'       => madr_tracking_doc_id( $row->order_id ),
		'siteId'      => madr_site_id(),
		'siteName'    => get_bloginfo( 'name' ),
		'orderId'     => (int) $row->order_id,
		'orderNumber' => (string) $order->get_order_number(),
		'status'      => $row->status,
		'driverUid'   => $row->driver_id ? 'wp_' . (int) $row->driver_id : null,
		'driverName'  => $driver ? $driver->first_name ?: $driver->display_name : null,
		'customerUid' => $order->get_customer_id() ? 'wp_' . (int) $order->get_customer_id() : null,
		'destination' => null !== $row->dest_lat ? array( 'lat' => (float) $row->dest_lat, 'lng' => (float) $row->dest_lng ) : null,
		'notify'      => $notify,
		'language'    => (string) $order->get_meta( 'wpml_language' ) ?: substr( get_locale(), 0, 2 ),
	);
	$response = wp_remote_post(
		$url . '/driverTracking/sync',
		array(
			'timeout' => 6,
			'headers' => array( 'Content-Type' => 'application/json', 'X-App-Keys-Secret' => $secret ),
			'body'    => wp_json_encode( $body ),
		)
	);
	global $wpdb;
	$code = is_wp_error( $response ) ? 0 : (int) wp_remote_retrieve_response_code( $response );
	if ( $code < 200 || $code >= 300 ) {
		$error = is_wp_error( $response ) ? $response->get_error_message() : 'HTTP ' . $code;
		$wpdb->update( madr_table( 'deliveries' ), array( 'sync_error' => substr( $error, 0, 190 ) ), array( 'order_id' => (int) $row->order_id ) );
		madr_log( $row->order_id, 'sync_error', $error, $row->driver_id ?: null, 0 );
		return false;
	}
	if ( $row->sync_error ) {
		$wpdb->update( madr_table( 'deliveries' ), array( 'sync_error' => null ), array( 'order_id' => (int) $row->order_id ) );
	}
	return true;
}

/**
 * Chiave di firma dei token dell'app (la stessa che le Cloud Functions usano come jwt.secret): quella di
 * «Accesso app» di Mobile Admin, oppure di Simple JWT Login dove è ancora attivo (jwt-login.php).
 */
function madr_jwt_key() {
	return function_exists( 'WPADR_jwt_signing_key' ) ? WPADR_jwt_signing_key( WPADR_jwt_effective_settings() ) : '';
}

function madr_b64url( $data ) {
	return rtrim( strtr( base64_encode( $data ), '+/', '-_' ), '=' ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode
}

/**
 * Token breve (5 minuti) per l'utente collegato al sito, da scambiare con un token Firebase.
 * Contiene solo id ed email, più `lidrAdminSite` (la sede) per chi può supervisionare le consegne di quella sede.
 */
function madr_short_jwt_for_current_user() {
	$user = wp_get_current_user();
	$key  = madr_jwt_key();
	if ( ! $user->ID || '' === $key ) {
		return '';
	}
	$now     = time();
	$payload = array(
		'id'        => (int) $user->ID,
		'email'     => $user->user_email,
		'iat'       => $now,
		'exp'       => $now + 300,
		'iss'       => home_url(),
	);
	// Supervisione solo della PROPRIA sede: il claim porta la sede, e le regole Firestore la confrontano
	// con il siteId della consegna (un gestore di Bellinzona non legge le consegne di Biasca).
	if ( current_user_can( 'manage_woocommerce' ) ) {
		$payload['lidrAdminSite'] = madr_site_id();
	}
	$header = madr_b64url( wp_json_encode( array( 'typ' => 'JWT', 'alg' => 'HS256' ) ) );
	$body   = madr_b64url( wp_json_encode( $payload ) );
	$sig    = madr_b64url( hash_hmac( 'sha256', $header . '.' . $body, $key, true ) );
	return $header . '.' . $body . '.' . $sig;
}

/** Configurazione pubblica di Firebase per il browser (nessun segreto: sono i valori del client web). */
function madr_firebase_web_config() {
	$c = madr_settings()['firebase'];
	$c = array_map( 'sanitize_text_field', $c );
	return array_filter( $c ) ? $c : array();
}

/* ---------------------------------------------------------------------------
 * Nuovi tentativi: se le Cloud Functions non rispondono, la consegna resta con sync_error
 * e si riprova ogni minuto (wp-cron), così «Consegnato» o «Annullato» arrivano comunque
 * al cliente e la posizione del Driver smette di essere visibile.
 * ------------------------------------------------------------------------ */

add_filter( 'cron_schedules', function ( $schedules ) {
	$schedules['madr_minute'] = array( 'interval' => 60, 'display' => 'Driver: ogni minuto' );
	return $schedules;
} );

add_action( 'init', function () {
	if ( ! wp_next_scheduled( 'madr_retry_sync' ) ) {
		wp_schedule_event( time() + 60, 'madr_minute', 'madr_retry_sync' );
	}
} );

/** Riprova le consegne con la sincronizzazione fallita (più vecchie prima, massimo 20 per giro). */
function madr_retry_failed_syncs() {
	global $wpdb;
	$table = madr_table( 'deliveries' );
	$rows  = $wpdb->get_results( "SELECT * FROM {$table} WHERE sync_error IS NOT NULL ORDER BY updated_at ASC LIMIT 20" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	$ok    = 0;
	foreach ( $rows as $row ) {
		// La notifica di quello stato potrebbe non essere partita: le Cloud Functions la mandano una sola volta per stato.
		$notify = in_array( $row->status, array( MADR_STATUS_ASSIGNED, MADR_STATUS_EN_ROUTE, MADR_STATUS_DELIVERED, MADR_STATUS_CANCELLED ), true ) ? $row->status : '';
		if ( madr_firebase_sync( $row, $notify ) ) {
			$ok++;
		}
	}
	return array( 'tried' => count( $rows ), 'ok' => $ok );
}
add_action( 'madr_retry_sync', 'madr_retry_failed_syncs' );
