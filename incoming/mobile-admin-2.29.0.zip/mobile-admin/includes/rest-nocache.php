<?php
/**
 * The plugin's REST answers are never served from a page cache (v2.23.2, hardened in 2.23.3)
 *
 * The app and its Cloud Functions read these routes to know what to show right now: app status,
 * payment methods, POS info, slides, category icons, combo menus, add-ons, delivery caps.
 * LiteSpeed Cache caches REST GETs by URL when its «Cache REST API» setting is on (the plugin's
 * default) and keeps them for the site's REST TTL (7 days by default). It ignores a Cache-Control
 * or X-LiteSpeed-Cache-Control header set on the WP_REST_Response by a callback, so the headers
 * that payment-methods and combo-menu already sent did not keep them out of the cache: on a site
 * with the page cache active the second request came back with `x-litespeed-cache: hit`.
 *
 * So this is done in one place for every route of the plugin, instead of route by route:
 * - before the route runs, and again on the way out, LiteSpeed Cache is told through its own
 *   control hook that the request is not cacheable (the only way it listens to); without
 *   LiteSpeed Cache the hook does nothing;
 * - on the way out, the response gets the standard no-cache headers for any other cache in front
 *   of the site (CDN, proxy, the LiteSpeed server without its WordPress plugin).
 *
 * It covers errors too (400, 403, 404 of these routes), which a cache would otherwise keep.
 */

defined( 'ABSPATH' ) || exit;

/**
 * True when the REST route belongs to this plugin.
 *
 * Namespaces mobile-admin/v1, mobile/v1 and wpadr/v1 are the plugin's own. In cs/v1 only
 * /addons/<category_id> is ours: /cs/v1/addons/all belongs to the mu-plugin cs-addons-rest-api.
 *
 * @param string $route Route as WP_REST_Request::get_route() gives it, e.g. "/mobile-admin/v1/config".
 */
function ARD_rest_is_own_route( $route ) {
	// WordPress matches REST routes case-insensitively (/wp-json/Mobile-Admin/v1/config runs the same
	// callback), so the comparison is done in lower case.
	$route = strtolower( '/' . ltrim( (string) $route, '/' ) );
	foreach ( array( '/mobile-admin/v1', '/mobile/v1', '/wpadr/v1' ) as $namespace ) {
		if ( $route === $namespace || 0 === strpos( $route, $namespace . '/' ) ) {
			return true;
		}
	}
	// The app login routes (Simple JWT Login's namespace), only where Mobile Admin answers them (v2.24.0):
	// a cached «token valid» would outlive a logout.
	if ( function_exists( 'WPADR_jwt_serving_namespace' ) ) {
		$login = strtolower( '/' . WPADR_jwt_serving_namespace() );
		if ( '/' !== $login && ( $route === $login || 0 === strpos( $route, $login . '/' ) ) ) {
			return true;
		}
	}
	return 1 === preg_match( '#^/cs/v1/addons/\d+/?$#', $route );
}

/**
 * Whether this request's answer must stay out of every page cache.
 *
 * Filter `ard_rest_nocache` (bool $nocache, string $route, WP_REST_Request $request): return false
 * to let a cache keep one of the plugin's routes on a site that really needs it.
 */
function ARD_rest_must_not_cache( $request ) {
	// Only when the browser/app asked for the REST route itself. A page that runs one of these
	// routes internally (rest_do_request) must keep its own cache rules.
	if ( ! ( defined( 'REST_REQUEST' ) && REST_REQUEST ) || ! $request instanceof WP_REST_Request ) {
		return false;
	}
	$route = $request->get_route();
	if ( ! ARD_rest_is_own_route( $route ) ) {
		return false;
	}
	return (bool) apply_filters( 'ard_rest_nocache', true, $route, $request );
}

/**
 * Tell the page-cache plugins that this request must not be cached.
 *
 * - litespeed_control_set_nocache: LiteSpeed Cache's own control hook (a no-op without that plugin).
 * - set_nocache_hard (LiteSpeed Cache 7.9.2+): the plain flag loses against a «Force Cache URIs» /
 *   «Force Public Cache URIs» rule that happens to match /wp-json/; the hard flag does not.
 * - DONOTCACHEPAGE: the same message for older LiteSpeed Cache versions and other cache plugins.
 *   It is only ever defined on a direct REST request to one of the plugin's own routes.
 */
function ARD_rest_tell_caches_nocache() {
	$reason = 'mobile-admin REST: the app needs fresh data';
	do_action( 'litespeed_control_set_nocache', $reason );
	if ( is_callable( array( '\\LiteSpeed\\Control', 'set_nocache_hard' ) ) ) {
		\LiteSpeed\Control::set_nocache_hard( $reason );
	}
	if ( ! defined( 'DONOTCACHEPAGE' ) ) {
		define( 'DONOTCACHEPAGE', true );
	}
}

/** Before the route runs: tell the cache plugins not to cache this request. */
add_filter( 'rest_pre_dispatch', function ( $result, $server, $request ) {
	if ( ARD_rest_must_not_cache( $request ) ) {
		ARD_rest_tell_caches_nocache();
	}
	return $result;
}, 1, 3 );

/** On the way out: standard no-cache headers for any other cache in front of the site. */
add_filter( 'rest_post_dispatch', function ( $response, $server, $request ) {
	if ( $response instanceof WP_HTTP_Response && ARD_rest_must_not_cache( $request ) ) {
		// Again here: when REST authentication fails (e.g. a wrong X-WP-Nonce) WordPress answers 403
		// without dispatching, so rest_pre_dispatch never ran and that 403 could be cached.
		ARD_rest_tell_caches_nocache();
		// A route that already set its own, stricter Cache-Control (app-keys adds "private") keeps it.
		$headers = array_change_key_case( (array) $response->get_headers(), CASE_LOWER );
		if ( empty( $headers['cache-control'] ) ) {
			$response->header( 'Cache-Control', 'no-cache, no-store, must-revalidate, max-age=0' );
		}
		$response->header( 'X-LiteSpeed-Cache-Control', 'no-cache' );
	}
	return $response;
}, 99, 3 );
