<?php
/** Native listing fallback; more specific existing templates remain authoritative. */
require get_stylesheet_directory() . '/archive.php';
