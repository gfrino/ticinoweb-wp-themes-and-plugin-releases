<?php
/** Media pages use the editorial shell when WordPress does not redirect to the file. */
get_header();
while(have_posts()){the_post();get_template_part('template-parts/editorial-page');}
get_footer();
