<?php
/** Default designed page: future editor pages inherit this without special setup. */
get_header();
while(have_posts()){the_post();get_template_part('template-parts/editorial-page');}
get_footer();
