<?php
/** Recovery presentation only: WordPress keeps its native 404 status. */
get_header();
$tw_recovery_links = tw_public_archives_recovery_links();
$tw_secondary_link = $tw_recovery_links['projects'] ?? $tw_recovery_links['contact'] ?? $tw_recovery_links['web'] ?? null;
?>
<main class="tw-public-archive tw-public-not-found">
	<div class="tw-shell tw-public-hero">
		<p class="tw-blog-kicker"><?php esc_html_e( 'Errore 404', 'ticinoweb-child-theme' ); ?></p>
		<h1><?php esc_html_e( 'Questa pagina non è più qui.', 'ticinoweb-child-theme' ); ?></h1>
		<p class="tw-public-intro"><?php esc_html_e( 'Il collegamento potrebbe essere cambiato. Riparti dalla Home o esplora il sito.', 'ticinoweb-child-theme' ); ?></p>
		<div class="tw-public-actions">
			<a class="tw-public-action-primary" href="<?php echo esc_url( $tw_recovery_links['home']['url'] ); ?>"><?php esc_html_e( 'Torna alla Home', 'ticinoweb-child-theme' ); ?></a>
			<?php if ( $tw_secondary_link ) : ?>
				<a href="<?php echo esc_url( $tw_secondary_link['url'] ); ?>"><?php echo esc_html( isset( $tw_recovery_links['projects'] ) ? __( 'Scopri i progetti', 'ticinoweb-child-theme' ) : $tw_secondary_link['label'] ); ?></a>
			<?php endif; ?>
		</div>
	</div>
</main>
<?php get_footer(); ?>
