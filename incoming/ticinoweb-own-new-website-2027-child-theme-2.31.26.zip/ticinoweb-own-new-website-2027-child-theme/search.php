<?php
/** Search keeps WordPress main query and its actual total. */
get_header();
global $wp_query;
$tw_search_total = (int) $wp_query->found_posts;
?>
<main class="tw-public-archive tw-public-search">
	<header class="tw-public-hero">
		<div class="tw-shell">
			<p class="tw-blog-kicker"><?php esc_html_e( 'Ricerca nel sito', 'ticinoweb-child-theme' ); ?></p>
			<h1><?php echo esc_html( sprintf( __( 'Risultati per “%s”', 'ticinoweb-child-theme' ), get_search_query( false ) ) ); ?></h1>
			<p class="tw-public-intro"><?php echo esc_html( sprintf( _n( '%s risultato', '%s risultati', $tw_search_total, 'ticinoweb-child-theme' ), number_format_i18n( $tw_search_total ) ) ); ?></p>
			<?php get_search_form(); ?>
		</div>
	</header>
	<div class="tw-shell tw-public-results"><?php tw_public_archives_render_results(); ?></div>
</main>
<?php get_footer(); ?>
