<?php
/**
 * Contratto dati dinamico della Home.
 *
 * Riutilizza le opzioni del parent, gli articoli e il Team senza creare
 * sistemi editoriali duplicati.
 *
 * @package ticinoWEB_Child_Theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Registra il solo CPT Team usato dal sito.
 */
function tw_home_register_existing_content_types() {
	if ( ! post_type_exists( 'tw_team_member' ) ) {
		register_post_type(
			'tw_team_member',
			array(
				'labels' => array(
					'name'               => __( 'Il Team', 'ticinoweb-child-theme' ),
					'singular_name'      => __( 'Collaboratore', 'ticinoweb-child-theme' ),
					'menu_name'          => __( 'Il Team', 'ticinoweb-child-theme' ),
					'add_new'            => __( 'Aggiungi collaboratore', 'ticinoweb-child-theme' ),
					'add_new_item'       => __( 'Aggiungi collaboratore', 'ticinoweb-child-theme' ),
					'edit_item'          => __( 'Modifica collaboratore', 'ticinoweb-child-theme' ),
					'featured_image'     => __( 'Foto collaboratore', 'ticinoweb-child-theme' ),
					'set_featured_image' => __( 'Imposta foto collaboratore', 'ticinoweb-child-theme' ),
				),
				'public'             => true,
				'publicly_queryable' => false,
				'show_ui'            => true,
				'show_in_rest'       => true,
				'menu_icon'          => 'dashicons-groups',
				'supports'           => array( 'title', 'editor', 'thumbnail', 'revisions' ),
			)
		);
	}
}
add_action( 'init', 'tw_home_register_existing_content_types', 20 );

/**
 * Produce testo breve e pulito da contenuti storici.
 */
function tw_home_excerpt( $value, $words = 28 ) {
	$value = html_entity_decode( (string) $value, ENT_QUOTES, get_bloginfo( 'charset' ) );
	$value = preg_replace( '/\s+/u', ' ', wp_strip_all_tags( $value ) );
	return wp_trim_words( trim( $value ), $words, '…' );
}

/**
 * Risolve un allegato anche quando il multisite espone URL con una base diversa.
 */
function tw_home_attachment_id_from_url( $url ) {
	$url = (string) $url;
	if ( ! $url ) {
		return 0;
	}
	$attachment_id = attachment_url_to_postid( $url );
	if ( $attachment_id ) {
		return (int) $attachment_id;
	}
	$path = rawurldecode( (string) wp_parse_url( $url, PHP_URL_PATH ) );
	if ( ! preg_match( '#/uploads/sites/\d+/(.+)$#', $path, $matches ) ) {
		return 0;
	}
	global $wpdb;
	$relative_path = $matches[1];
	$attachment_id = (int) $wpdb->get_var(
		$wpdb->prepare(
			"SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = '_wp_attached_file' AND meta_value = %s LIMIT 1",
			$relative_path
		)
	);
	if ( $attachment_id ) {
		return $attachment_id;
	}
	$original_path = preg_replace( '/-\d+x\d+(?=\.[a-z0-9]+$)/i', '', $relative_path );
	if ( $original_path === $relative_path ) {
		return 0;
	}
	return (int) $wpdb->get_var(
		$wpdb->prepare(
			"SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = '_wp_attached_file' AND meta_value = %s LIMIT 1",
			$original_path
		)
	);
}

/**
 * Trova una pagina mappata nel parent e fornisce un fallback sicuro.
 */
function tw_home_mapped_url( $key, $fallback_slug = '' ) {
	$mapping = get_option( 'ticinoweb_page_mapping', array() );
	$page_id = isset( $mapping[ $key ] ) ? absint( $mapping[ $key ] ) : 0;
	if ( $page_id && 'publish' === get_post_status( $page_id ) ) {
		return get_permalink( $page_id );
	}
	if ( $fallback_slug ) {
		$page = get_page_by_path( $fallback_slug );
		if ( $page instanceof WP_Post ) {
			return get_permalink( $page );
		}
	}
	return home_url( '/' );
}

/**
 * Riconosce il tipo di media salvato nel campo Slider del CMS.
 *
 * Il parent espone un unico URL per immagini e video. Il child mantiene
 * quella singola fonte e usa prima il MIME dell'allegato, poi l'estensione.
 */
function tw_home_resolve_slide_media( $url ) {
	$attachment_id = attachment_url_to_postid( $url );
	$mime_type     = $attachment_id ? (string) get_post_mime_type( $attachment_id ) : '';

	if ( ! $mime_type ) {
		$path      = (string) parse_url( $url, PHP_URL_PATH );
		$file_type = wp_check_filetype( $path );
		$mime_type = (string) ( $file_type['type'] ?? '' );
	}

	return array(
		'attachment_id' => (int) $attachment_id,
		'media_type'    => 0 === strpos( $mime_type, 'video/' ) ? 'video' : 'image',
		'mime_type'     => $mime_type,
	);
}

/**
 * Normalizza le slide del parent.
 */
function tw_home_get_slides() {
	$slides = function_exists( 'ticinoweb_get_slider_data' ) ? ticinoweb_get_slider_data() : array();
	$count  = (int) get_option( 'ticinoweb_slider_count', get_theme_mod( 'slider_count', 3 ) );
	$count  = max( 1, min( 5, $count ) );
	$slots  = array();
	for ( $slot = 1; $slot <= $count; $slot++ ) {
		$image = get_option( "ticinoweb_slider_image_{$slot}" ) ?: get_theme_mod( "slider_image_{$slot}" );
		if ( $image ) {
			$slots[] = $slot;
		}
	}
	$position = 0;
	return array_values(
		array_filter(
			array_map(
			static function ( $slide ) use ( &$position, $slots ) {
					$image = esc_url_raw( $slide['image'] ?? '' );
					if ( ! $image || empty( $slide['title'] ) ) {
						return null;
					}
					$media = tw_home_resolve_slide_media( $image );
					$slot = $slots[ $position ] ?? ( $position + 1 );
					$position++;
					$dynamic = function_exists( 'tw_hero_dynamic_get_config' ) ? tw_hero_dynamic_get_config( $slot ) : array();
					$dynamic['enabled'] = ! empty( $dynamic['enabled'] ) && ! empty( $dynamic['before'] ) && ! empty( $dynamic['terms'] ) && ! empty( $dynamic['after'] );
					return array(
						'image'         => $image,
						'image_id'      => 'image' === $media['media_type'] ? $media['attachment_id'] : 0,
						'attachment_id' => $media['attachment_id'],
						'media_type'    => $media['media_type'],
						'mime_type'     => $media['mime_type'],
						'title'         => (string) $slide['title'],
						'description' => (string) ( $slide['desc'] ?? '' ),
						'button'      => (string) ( $slide['btn1_text'] ?? '' ),
						'url'         => (string) ( $slide['btn1_link'] ?? '' ),
						'slot'        => $slot,
						'dynamic_title' => $dynamic,
					);
				},
				$slides
			)
		)
	);
}

/**
 * Recupera il ritratto editoriale dell'Hero dalla Libreria Media.
 */
function tw_home_get_hero_portrait_id() {
	$attachment_id = absint( get_option( 'tw_home_hero_portrait_id', 0 ) );
	return $attachment_id && wp_attachment_is_image( $attachment_id ) ? $attachment_id : 0;
}

/**
 * Indicizza i servizi del CMS per chiave.
 */
function tw_home_get_services() {
	$services = function_exists( 'ticinoweb_get_services' ) ? ticinoweb_get_services() : array();
	$services = is_array( $services ) ? $services : array();
	usort(
		$services,
		static fn( $a, $b ) => (int) ( $a['order'] ?? 999 ) <=> (int) ( $b['order'] ?? 999 )
	);
	return array_values( array_filter( $services, static fn( $service ) => ! empty( $service['title'] ) ) );
}

/**
 * Risolve la pagina di riferimento di un servizio.
 *
 * Il collegamento configurato nel CMS ha sempre la precedenza. Gli slug sono
 * usati soltanto come fallback per i servizi storici che non hanno ancora un
 * URL salvato nel relativo campo.
 */
function tw_home_service_url( $service ) {
	$cms_url = trim( (string) ( $service['url'] ?? '' ) );
	if ( $cms_url ) {
		return $cms_url;
	}

	$service_key = sanitize_title( wp_strip_all_tags( (string) ( $service['short_name'] ?? $service['title'] ?? '' ) ) );
	$page_slugs  = array(
		'siti-web'                 => 'siti-web',
		'ecommerce'                => 'ecommerce-websites',
		'applicazioni-android-ios' => 'applicazioni-android-ios',
		'odoo-e-gestionali'        => 'odoo',
		'produzioni-video'         => 'produzioni-video',
		'campagne-google'          => 'campagne-di-posizionamento-su-google',
		'gestione-dei-social'      => 'gestione-dei-social',
		'grafica-pubblicitaria'    => 'grafica-pubblicitaria-pagina',
		'hosting'                  => 'hosting-2',
		'assistenza'               => 'assistenza',
	);
	$page_slug   = $page_slugs[ $service_key ] ?? '';
	$page        = $page_slug ? get_page_by_path( $page_slug ) : null;

	return $page instanceof WP_Post && 'publish' === get_post_status( $page ) ? get_permalink( $page ) : '';
}

/**
 * Elenco chiuso delle tassonomie native del blog usate dal Project Explorer.
 */
function tw_home_project_taxonomies() {
	return array( 'category', 'tw_project_sector', 'tw_odoo_sector' );
}

/**
 * Recupera gli ID degli articoli pubblicati marcati come progetti.
 */
function tw_home_get_project_post_ids() {
	static $project_ids = null;
	if ( null !== $project_ids ) {
		return $project_ids;
	}

	$project_ids = get_posts(
		array(
			'post_type'           => 'post',
			'post_status'         => 'publish',
			'posts_per_page'      => -1,
			'fields'              => 'ids',
			'meta_key'            => 'tw_home_project_featured',
			'meta_value'          => '1',
			'ignore_sticky_posts' => true,
			'no_found_rows'       => true,
		)
	);

	return array_values( array_map( 'absint', $project_ids ) );
}

/**
 * Recupera i termini realmente usati dagli articoli marcati come progetti.
 */
function tw_home_get_project_terms( $taxonomy ) {
	if ( ! in_array( $taxonomy, tw_home_project_taxonomies(), true ) || ! taxonomy_exists( $taxonomy ) ) {
		return array();
	}

	$project_ids = tw_home_get_project_post_ids();
	if ( empty( $project_ids ) ) {
		return array();
	}

	$terms = wp_get_object_terms(
		$project_ids,
		$taxonomy,
		array(
			'fields' => 'all_with_object_id',
		)
	);
	if ( is_wp_error( $terms ) ) {
		return array();
	}

	$grouped = array();
	foreach ( $terms as $term ) {
		$term_id = absint( $term->term_id );
		if ( ! isset( $grouped[ $term_id ] ) ) {
			$grouped[ $term_id ] = array(
				'id'    => $term_id,
				'name'  => (string) $term->name,
				'slug'  => (string) $term->slug,
				'count' => 0,
			);
		}
		$grouped[ $term_id ]['count']++;
	}

	usort(
		$grouped,
		static function ( $first, $second ) {
			$count_order = $second['count'] <=> $first['count'];
			return $count_order ?: strcasecmp( $first['name'], $second['name'] );
		}
	);

	return array_values( $grouped );
}

/**
 * Restituisce le sole categorie editoriali utili al Project Explorer della Home.
 *
 * I termini restano disponibili nel blog e nel backend: questa cura riguarda
 * esclusivamente l'indice Progetti / Realizzazioni della Home.
 */
function tw_home_get_project_explorer_categories() {
	$hidden_slugs = array( 'sito-cliente', 'aziendale-premium', 'one-page', 'consigliati' );
	$general      = array();
	$categories   = array();

	foreach ( tw_home_get_project_terms( 'category' ) as $term ) {
		if ( in_array( $term['slug'], $hidden_slugs, true ) ) {
			continue;
		}

		if ( 'web-design' === $term['slug'] ) {
			$general[] = $term;
			continue;
		}

		$categories[] = $term;
	}

	return array_merge( $general, $categories );
}

/**
 * Espone un filtro REST esplicito per i soli articoli progetto.
 */
function tw_home_add_project_rest_collection_param( $params ) {
	$params['tw_home_project_featured'] = array(
		'description'       => __( 'Limita la risposta agli articoli mostrati in Referenze / Realizzazioni.', 'ticinoweb-child-theme' ),
		'type'              => 'boolean',
		'sanitize_callback' => 'rest_sanitize_boolean',
	);
	return $params;
}
add_filter( 'rest_post_collection_params', 'tw_home_add_project_rest_collection_param' );

/**
 * Applica il flag editoriale alla query REST degli articoli.
 */
function tw_home_filter_project_rest_query( $args, $request ) {
	if ( ! rest_sanitize_boolean( $request->get_param( 'tw_home_project_featured' ) ) ) {
		return $args;
	}

	$args['meta_query'][] = array(
		'key'     => 'tw_home_project_featured',
		'value'   => '1',
		'compare' => '=',
	);
	return $args;
}
add_filter( 'rest_post_query', 'tw_home_filter_project_rest_query', 10, 2 );

/**
 * Converte un progetto nel contratto minimo usato dalle card.
 */
function tw_home_project_card_data( $project ) {
	$type_names = wp_get_post_terms( $project->ID, 'category', array( 'fields' => 'names' ) );

	$data = array(
		'id'       => (int) $project->ID,
		'title'    => get_the_title( $project ),
		'url'      => get_permalink( $project ),
		'image_id' => absint( get_post_thumbnail_id( $project ) ),
		'types'    => is_wp_error( $type_names ) ? array() : array_values( $type_names ),
		'sectors'  => array(),
	);
	$id=$data['image_id'];
	$src=$id && wp_attachment_is_image($id) && is_file(get_attached_file($id)) ? wp_get_attachment_image_src($id,'large') : false;
	if(!$src)$data['image_id']=0;
	$data['image']=$src?array('src'=>$src[0],'width'=>$src[1],'height'=>$src[2],'srcset'=>wp_get_attachment_image_srcset($id,'large')):null;
	return $data;
}

/**
 * Recupera un singolo batch di progetti associati a un termine reale.
 */
function tw_home_get_projects_for_term( $taxonomy, $term_id, $page = 1, $per_page = 6 ) {
	if ( ! in_array( $taxonomy, tw_home_project_taxonomies(), true ) || ! term_exists( absint( $term_id ), $taxonomy ) ) {
		return array( 'items' => array(), 'total' => 0, 'pages' => 0 );
	}
	$query = new WP_Query(tw_home_project_query_args($taxonomy,$term_id,$page,$per_page));

	$items = array_map( 'tw_home_project_card_data', $query->posts );
	if($taxonomy==='tw_odoo_sector') {
		$term=get_term($term_id,$taxonomy);
		foreach($items as &$item){$kind=get_post_type($item['id'])==='tw_project'?__('Progetto','ticinoweb-child-theme'):__('Articolo','ticinoweb-child-theme');$item['meta_label']=$kind.' · Odoo · '.$term->name;}
		unset($item);
	}
	$result = array(
		'items' => $items,
		'total' => (int) $query->found_posts,
		'pages' => (int) $query->max_num_pages,
	);
	wp_reset_postdata();
	return $result;
}

/**
 * Costruisce il modello del Project Explorer senza duplicare dati WordPress.
 */
function tw_home_get_project_explorer() {
	$groups = array(
		'category' => array(
			'label'      => __( 'Tipologie', 'ticinoweb-child-theme' ),
			'rest_param' => 'categories',
			'terms'      => tw_home_get_project_explorer_categories(),
		),
		'tw_odoo_sector'=>array('label'=>__('Settori di attività','ticinoweb-child-theme'),'terms'=>tw_home_sector_terms('tw_odoo_sector')),
	);

	$default_term = $groups['category']['terms'][0] ?? null;

	return array(
		'groups'           => $groups,
		'default_taxonomy' => 'category',
		'default_term'     => $default_term,
		'initial'          => $default_term ? tw_home_get_projects_for_term( 'category', $default_term['id'], 1, 6 ) : array( 'items' => array(), 'total' => 0, 'pages' => 0 ),
		'rest_url'         => rest_url( 'ticinoweb/v1/projects' ),
		'per_page'         => 6,
	);
}

/**
 * Recupera Founder e Team reali.
 */
function tw_home_get_people() {
	$query = new WP_Query(
		array(
			'post_type'      => 'tw_team_member',
			'post_status'    => 'publish',
			'posts_per_page' => 20,
			'meta_key'       => 'tw_order',
			'orderby'        => 'meta_value_num',
			'order'          => 'ASC',
			'meta_query'     => array(
				array( 'key' => 'tw_active', 'value' => '1' ),
			),
			'no_found_rows'  => true,
		)
	);
	$founder = null;
	$team = array();
	foreach ( $query->posts as $person ) {
		$data = array(
			'id'             => $person->ID,
			'name'           => get_the_title( $person ),
			'role'           => (string) get_post_meta( $person->ID, 'tw_role', true ),
			'bio'            => tw_home_excerpt( get_post_meta( $person->ID, 'tw_full_bio', true ), 42 ),
			'image_id'       => get_post_thumbnail_id( $person ),
			'specialization' => (string) get_post_meta( $person->ID, 'tw_specializations', true ),
			'languages'      => (string) get_post_meta( $person->ID, 'tw_languages', true ),
			'experience'     => (string) get_post_meta( $person->ID, 'tw_experience_since', true ),
		);
		if ( '1' === (string) get_post_meta( $person->ID, 'tw_founder', true ) ) {
			$founder = $data;
		} else {
			$team[] = $data;
		}
	}
	wp_reset_postdata();
	return array( 'founder' => $founder, 'team' => $team );
}

/**
 * Recupera recensioni verificate dal parent.
 */
function tw_home_get_reviews() {
	$reviews = function_exists( 'ticinoweb_get_google_reviews' ) ? ticinoweb_get_google_reviews( 8, 4 ) : array();
	$reviews = array_values( array_filter( (array) $reviews, static fn( $review ) => ! empty( $review['text'] ) && ! empty( $review['author_name'] ) ) );
	return array(
		'rating'       => (string) get_option( 'ticinoweb_google_reviews_rating', '' ),
		'count'        => absint( get_option( 'ticinoweb_google_reviews_count', 0 ) ),
		'items'        => array_slice( $reviews, 0, 6 ),
		'business_url' => esc_url_raw( get_option( 'ticinoweb_google_business_link', '' ) ),
		'last_sync'    => sanitize_text_field( get_option( 'ticinoweb_google_reviews_last_sync', '' ) ),
	);
}

/**
 * Recupera i partner configurati nel parent.
 */
function tw_home_get_partners() {
	$count = min( 24, max( 0, absint( get_option( 'ticinoweb_partner_count', 0 ) ) ) );
	$rows = array();
	for ( $index = 1; $index <= $count; $index++ ) {
		$rows[] = array(
			'logo' => esc_url_raw( get_option( "ticinoweb_partner_logo_{$index}", '' ) ),
			'url'  => esc_url_raw( get_option( "ticinoweb_partner_link_{$index}", '' ) ),
		);
	}
	$cache_key = 'tw_home_partners_' . md5( wp_json_encode( $rows ) );
	$cached = get_transient( $cache_key );
	if ( is_array( $cached ) ) {
		return $cached;
	}
	$partners = array();
	$seen_logos = array();
	foreach ( $rows as $row ) {
		$logo = $row['logo'];
		if ( ! $logo ) {
			continue;
		}
		$image_id = tw_home_attachment_id_from_url( $logo );
		$logo_key = $image_id ? 'attachment:' . $image_id : 'url:' . strtolower( strtok( $logo, '?' ) );
		if ( isset( $seen_logos[ $logo_key ] ) ) {
			continue;
		}
		$seen_logos[ $logo_key ] = true;
		$label    = $image_id ? get_post_meta( $image_id, '_wp_attachment_image_alt', true ) : '';
		if ( ! $label && $image_id ) {
			$label = get_the_title( $image_id );
		}
		$partners[] = array(
			'logo'     => $logo,
			'image_id' => $image_id,
			'label'    => tw_home_excerpt( $label, 8 ),
			'url'      => $row['url'],
		);
	}
	set_transient( $cache_key, $partners, 12 * HOUR_IN_SECONDS );
	return $partners;
}

/**
 * Recupera i clienti dalla galleria Media "Credono in noi".
 *
 * Ordine, immagini e appartenenza alla fascia restano gestibili dal manager
 * Gallerie Media del parent; l'URL facoltativo vive sul singolo allegato.
 */
function tw_home_get_clients() {
	$taxonomy = 'ticinoweb_media_gallery';
	if ( ! taxonomy_exists( $taxonomy ) ) {
		return array();
	}

	$gallery = get_term_by( 'slug', 'credono-in-noi', $taxonomy );
	if ( ! $gallery instanceof WP_Term ) {
		return array();
	}

	$attachment_ids = get_posts(
		array(
			'post_type'        => 'attachment',
			'post_status'      => 'inherit',
			'post_mime_type'   => 'image',
			'posts_per_page'   => -1,
			'fields'           => 'ids',
			'orderby'          => 'ID',
			'order'            => 'ASC',
			'suppress_filters' => true,
			'tax_query'        => array(
				array(
					'taxonomy' => $taxonomy,
					'field'    => 'term_id',
					'terms'    => array( $gallery->term_id ),
				),
			),
		)
	);

	$saved_order = get_term_meta( $gallery->term_id, '_ticinoweb_gallery_order', true );
	$saved_order = array_values( array_intersect( array_map( 'absint', (array) $saved_order ), $attachment_ids ) );
	$attachment_ids = array_merge( $saved_order, array_values( array_diff( $attachment_ids, $saved_order ) ) );

	$clients = array();
	foreach ( $attachment_ids as $attachment_id ) {
		$label = get_post_meta( $attachment_id, '_wp_attachment_image_alt', true );
		$label = $label ?: get_the_title( $attachment_id );
		$clients[] = array(
			'image_id' => $attachment_id,
			'label'    => tw_home_excerpt( $label, 8 ),
			'url'      => esc_url_raw( get_post_meta( $attachment_id, '_tw_client_url', true ) ),
		);
	}

	return $clients;
}

/**
 * Recupera gli ultimi articoli pubblicati.
 */
function tw_home_get_articles() {
	$query = new WP_Query(
		array(
			'post_type'      => 'post',
			'post_status'    => 'publish',
			'posts_per_page' => 3,
			'meta_query'     => array(
				array( 'key' => '_thumbnail_id', 'compare' => 'EXISTS' ),
			),
			'ignore_sticky_posts' => true,
			'no_found_rows'  => true,
		)
	);
	$articles = array();
	foreach ( $query->posts as $post ) {
		$categories = get_the_category( $post->ID );
		$articles[] = array(
			'id'       => $post->ID,
			'title'    => get_the_title( $post ),
			'url'      => get_permalink( $post ),
			'date'     => get_the_date( '', $post ),
			'category' => $categories ? $categories[0]->name : __( 'tBlog', 'ticinoweb-child-theme' ),
			'image_id' => get_post_thumbnail_id( $post ),
		);
	}
	wp_reset_postdata();
	return $articles;
}

/**
 * Compone il view-model della Home senza scrivere dati.
 */
function tw_home_get_view_model() {
	$people = tw_home_get_people();
	$contact = function_exists( 'ticinoweb_get_contact_info' ) ? ticinoweb_get_contact_info() : array();
	$published_project_count = count( tw_home_get_project_post_ids() );
	$completed_project_count = absint( get_option( 'tw_home_completed_projects', 0 ) );
	return array(
		'slides'      => tw_home_get_slides(),
		'hero_portrait_id' => tw_home_get_hero_portrait_id(),
		'project_explorer' => tw_home_get_project_explorer(),
		'published_project_count' => $completed_project_count ?: $published_project_count,
		'services'    => tw_home_get_services(),
		'founder'     => $people['founder'],
		'team'        => $people['team'],
		'reviews'     => tw_home_get_reviews(),
		'partners'    => tw_home_get_partners(),
		'clients'     => tw_home_get_clients(),
		'articles'    => tw_home_get_articles(),
		'contact'     => $contact,
		'urls'        => array(
			'projects' => tw_home_mapped_url( 'page_referenze', 'referenze' ),
			'contact'  => tw_home_mapped_url( 'page_contatti', 'contatti' ),
			'blog'     => tw_home_mapped_url( 'page_blog', 'tblog' ),
		),
	);
}
