<?php
/** Editorial contact page. People, company details and delivery remain native CMS data. */
if ( ! defined( 'ABSPATH' ) ) exit;

function tw_about_fields() {
	return array(
		'hero_eyebrow'=>'Hero — Sopratitolo', 'hero_title'=>'Hero — Titolo', 'hero_text'=>'Hero — Descrizione', 'hero_cta_text'=>'Hero — CTA', 'hero_cta_url'=>'Hero — Link CTA',
		'story_eyebrow'=>'Storia — Sopratitolo', 'story_title'=>'Storia — Titolo condiviso con CMS Chi siamo', 'story_text'=>'Storia — Testo condiviso con CMS Chi siamo',
		'founder_eyebrow'=>'Founder — Sopratitolo', 'founder_text'=>'Founder — Testo editoriale',
		'team_eyebrow'=>'Team — Sopratitolo', 'team_title'=>'Team — Titolo',
		'approach_title'=>'Approccio — Titolo', 'location_eyebrow'=>'Sede — Sopratitolo', 'location_title'=>'Sede — Titolo', 'location_text'=>'Sede — Indicazioni di ingresso',
		'contact_eyebrow'=>'Contatti — Sopratitolo', 'contact_title'=>'Contatti — Titolo', 'contact_text'=>'Contatti — Descrizione', 'submit_text'=>'Form — Testo pulsante',
	);
}
function tw_about_is_page( $id = 0 ) {
	$id = $id ?: get_queried_object_id();
	return $id && '1' === get_post_meta( $id, '_tw_about_enabled', true );
}
function tw_about_data( $id = 0 ) {
	$d = (array) get_post_meta( $id ?: get_queried_object_id(), '_tw_about_content', true );
	$d['story_title'] = (string) get_option( 'ticinoweb_chi_siamo_title', '' );
	$d['story_text'] = (string) get_option( 'ticinoweb_chi_siamo_text', '' );
	return $d;
}
/** All published profiles, including records without ordering/active metadata. */
function tw_about_people() {
	$people = get_posts( array( 'post_type'=>'tw_team_member', 'post_status'=>'publish', 'numberposts'=>-1, 'orderby'=>'menu_order title', 'order'=>'ASC' ) );
	usort( $people, static function( $a, $b ) { return (int) get_post_meta($a->ID,'tw_order',true) <=> (int) get_post_meta($b->ID,'tw_order',true); } );
	return $people;
}
add_filter( 'template_include', function( $template ) {
	return is_page() && tw_about_is_page() ? get_stylesheet_directory().'/page-about-contact.php' : $template;
}, 120 );
add_action( 'wp_enqueue_scripts', function() {
	if ( ! is_page() || ! tw_about_is_page() ) return;
	$v = wp_get_theme()->get('Version');
	wp_enqueue_style('tw-about',get_stylesheet_directory_uri().'/assets/css/about-contact.css',array('ticinoweb-child-site'),$v);
	wp_enqueue_script('tw-about',get_stylesheet_directory_uri().'/assets/js/about-contact.js',array(),$v,true);
	wp_localize_script('tw-about','twAboutForm',array(
		'ajax_url'=>admin_url('admin-ajax.php'), 'token_action'=>'ticinoweb_form_token', 'submit_action'=>'ticinoweb_submit_form',
		'recaptcha_site_key'=>(string)get_option('ticinoweb_recaptcha_site_key',''),
		'busy'=>__('Invio in corso…','ticinoweb-child-theme'), 'failure'=>__('Invio non riuscito. Riprova oppure contattaci via email.','ticinoweb-child-theme'),
		'privacy'=>__('Accetta l’informativa privacy per inviare la richiesta.','ticinoweb-child-theme'),
		'saved'=>__('Richiesta registrata. Se non ricevi una risposta, contattaci direttamente.','ticinoweb-child-theme'),
	));
}, 30 );
add_action( 'add_meta_boxes', function( $type, $post ) {
	if ( $type !== 'page' || ! $post ) return;
	$mapping=(array)get_option('ticinoweb_page_mapping',array());
	if ( !tw_about_is_page($post->ID) && !in_array($post->ID,array_map('absint',array($mapping['page_chi_siamo']??0,$mapping['page_contatti']??0)),true) ) return;
	remove_meta_box('tw-service-system','page','normal');
	add_meta_box('tw-about-content',__('Contenuti Chi siamo & Contatti','ticinoweb-child-theme'),'tw_about_metabox','page','normal','high');
}, 30, 2 );
function tw_about_metabox( $post ) {
	$d=tw_about_data($post->ID);wp_nonce_field('tw_about_save','tw_about_nonce');wp_enqueue_media();
	?><p><?php esc_html_e('Nomi, ruoli, ritratti e competenze si modificano in Team. Telefono, email e indirizzo in ticinoWEB CMS → Contatti. Qui gestisci solo il racconto della pagina.','ticinoweb-child-theme'); ?></p>
	<p><label><input type="checkbox" name="tw_about_enabled" value="1" <?php checked(tw_about_is_page($post->ID)); ?>> <?php esc_html_e('Usa il layout editoriale Chi siamo & Contatti','ticinoweb-child-theme'); ?></label></p>
	<?php foreach(tw_about_fields() as $key=>$label): ?><p><label><strong><?php echo esc_html($label); ?></strong><textarea style="display:block;width:100%" rows="<?php echo str_ends_with($key,'_text')?4:1; ?>" name="tw_about[<?php echo esc_attr($key); ?>]"><?php echo esc_textarea($d[$key]??''); ?></textarea></label></p><?php endforeach; ?>
	<p><label><?php esc_html_e('Profilo Founder','ticinoweb-child-theme'); ?> <select name="tw_about[founder_id]"><option value="0"><?php esc_html_e('Automatico dal Team','ticinoweb-child-theme'); ?></option><?php foreach(tw_about_people() as $person): ?><option value="<?php echo esc_attr($person->ID); ?>" <?php selected($d['founder_id']??0,$person->ID); ?>><?php echo esc_html($person->post_title); ?></option><?php endforeach; ?></select></label></p>
	<?php foreach(array('hero'=>'Foto hero (vuoto: ritratti reali del Team)','location'=>'Foto reale sede (vuoto: contatti a larghezza piena)') as $key=>$label): ?><p class="tw-about-media"><label><?php echo esc_html($label); ?><input type="hidden" name="tw_about[<?php echo esc_attr($key); ?>_media_id]" value="<?php echo esc_attr($d[$key.'_media_id']??0); ?>"></label> <button type="button" class="button tw-about-pick"><?php esc_html_e('Seleziona media','ticinoweb-child-theme'); ?></button> <button type="button" class="button tw-about-clear"><?php esc_html_e('Rimuovi','ticinoweb-child-theme'); ?></button><span><?php echo !empty($d[$key.'_media_id'])?esc_html(get_the_title($d[$key.'_media_id'])):''; ?></span></p><?php endforeach; ?>
	<?php foreach(array('facts'=>'Dati verificati — Valore / Etichetta','approach'=>'Approccio — Titolo / Descrizione') as $key=>$label): ?><details class="tw-about-repeater" data-field="<?php echo esc_attr($key); ?>"><summary><?php echo esc_html($label); ?></summary><div class="tw-about-items"><?php foreach((array)($d[$key]??array()) as $i=>$r): ?><fieldset style="padding:14px;border:1px solid #ddd;margin-block:12px"><?php foreach(array('title'=>'Valore / Titolo','text'=>'Etichetta / Descrizione') as $f=>$l): ?><p><label><?php echo esc_html($l); ?><textarea style="display:block;width:100%" rows="2" name="tw_about[<?php echo esc_attr($key); ?>][<?php echo esc_attr($i); ?>][<?php echo esc_attr($f); ?>]"><?php echo esc_textarea($r[$f]??''); ?></textarea></label></p><?php endforeach; ?><button type="button" class="button tw-about-remove">Rimuovi voce</button></fieldset><?php endforeach; ?></div><button type="button" class="button tw-about-add">Aggiungi voce</button></details><?php endforeach; ?>
	<script>document.querySelectorAll('.tw-about-media').forEach(function(p){p.querySelector('.tw-about-pick').onclick=function(){const f=wp.media({multiple:false,library:{type:'image'}});f.on('select',function(){const m=f.state().get('selection').first().toJSON();p.querySelector('input').value=m.id;p.querySelector('span').textContent=m.title;});f.open();};p.querySelector('.tw-about-clear').onclick=function(){p.querySelector('input').value=0;p.querySelector('span').textContent='';};});document.querySelectorAll('.tw-about-repeater').forEach(function(s){s.onclick=function(e){if(e.target.classList.contains('tw-about-remove'))e.target.closest('fieldset').remove();if(e.target.classList.contains('tw-about-add')){const f=document.createElement('fieldset'),i=Date.now();f.style.cssText='padding:14px;border:1px solid #ddd;margin-block:12px';['title','text'].forEach(function(k){const l=document.createElement('label');l.textContent=k==='title'?'Valore / Titolo':'Etichetta / Descrizione';const t=document.createElement('textarea');t.name='tw_about['+s.dataset.field+']['+i+']['+k+']';t.style.cssText='display:block;width:100%;margin-bottom:14px';l.append(t);f.append(l);});const b=document.createElement('button');b.type='button';b.className='button tw-about-remove';b.textContent='Rimuovi voce';f.append(b);s.querySelector('.tw-about-items').append(f);}};});</script>
	<?php
}
add_action('save_post_page',function($id){
	if(empty($_POST['tw_about_nonce'])||!wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['tw_about_nonce'])),'tw_about_save')||!current_user_can('edit_post',$id)||wp_is_post_revision($id)||(defined('DOING_AUTOSAVE')&&DOING_AUTOSAVE))return;
	$raw=wp_unslash($_POST['tw_about']??array());$d=array();
	foreach(tw_about_fields() as $key=>$label){$value=str_ends_with($key,'_url')?esc_url_raw($raw[$key]??''):sanitize_textarea_field($raw[$key]??'');if(in_array($key,array('story_title','story_text'),true))update_option($key==='story_title'?'ticinoweb_chi_siamo_title':'ticinoweb_chi_siamo_text',$value);else $d[$key]=$value;}
	foreach(array('hero_media_id','location_media_id','founder_id') as $key)$d[$key]=absint($raw[$key]??0);
	foreach(array('facts','approach') as $key){$d[$key]=array();foreach((array)($raw[$key]??array()) as $row){if(!is_array($row)||empty($row['title']))continue;$d[$key][]=array('title'=>sanitize_text_field($row['title']),'text'=>sanitize_textarea_field($row['text']??''));}}
	update_post_meta($id,'_tw_about_content',$d);update_post_meta($id,'_tw_about_enabled',empty($_POST['tw_about_enabled'])?'0':'1');
});
/** Extend the existing parent handler for this form only, not with another submission endpoint. */
function tw_about_guard_form() {
	if(($_POST['tw_form_context']??'')!=='about')return;
	if(!wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['token']??'')),'ticinoweb_submit_form'))return;
	if(($_POST['privacy']??'')!=='1')wp_send_json_error(array('message'=>__('Accetta l’informativa privacy per inviare la richiesta.','ticinoweb-child-theme'),'fields'=>array('privacy'=>__('Campo obbligatorio.','ticinoweb-child-theme'))),422);
	$message=sanitize_textarea_field(wp_unslash($_POST['messaggio']??''));
	$length=function_exists('mb_strlen')?mb_strlen($message):strlen($message);
	if($length<5)wp_send_json_error(array('message'=>__('Scrivi un messaggio di almeno 5 caratteri.','ticinoweb-child-theme'),'fields'=>array('messaggio'=>__('Scrivi un messaggio di almeno 5 caratteri.','ticinoweb-child-theme'))),422);
}
add_action('wp_ajax_ticinoweb_submit_form','tw_about_guard_form',1);
add_action('wp_ajax_nopriv_ticinoweb_submit_form','tw_about_guard_form',1);
add_filter('ticinoweb_form_fields',function($fields,$raw){
	if(($raw['tw_form_context']??'')!=='about')return $fields;
	$company=sanitize_text_field(wp_unslash($raw['azienda']??''));
	if($company)$fields['messaggio'].="\n\n".__('Azienda','ticinoweb-child-theme').': '.$company;
	$fields['messaggio'].="\n".__('Informativa privacy accettata','ticinoweb-child-theme');
	return $fields;
},10,2);
function tw_about_contact_links( $contact ) {
	if(!empty($contact['phone']))echo '<a href="'.esc_url('tel:'.preg_replace('/[^+0-9]/','',$contact['phone'])).'">'.esc_html($contact['phone']).'</a>';
	if(!empty($contact['email']))echo '<a href="'.esc_url('mailto:'.$contact['email']).'">'.esc_html($contact['email']).'</a>';
}
