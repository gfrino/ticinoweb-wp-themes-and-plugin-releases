<?php
/** Official, bundled Odoo application PNGs. Filenames remain the asset identity. */
if (!defined('ABSPATH')) {
    exit;
}

/** Normalize a display name for lookup only; never use this value as a path. */
function tw_odoo_icon_slug($value) {
    $value = remove_accents($value);
    $value = preg_replace('/\p{Mn}/u', '', $value);
    return sanitize_title($value);
}

/**
 * Discover application assets once per release/day, then serve a cached allowlist.
 * The community membership badge is branding, not a selectable application.
 * URLs are rebuilt from the current site URI, never stored across site contexts.
 *
 * @return array<string,array{label:string,url:string}>
 */
function tw_odoo_icons() {
    static $registries = array();
    $directory = get_stylesheet_directory() . '/assets/images/odoo';
    $cache_key = 'tw_odoo_icons_' . md5($directory . '|' . wp_get_theme()->get('Version'));
    $uri = rtrim(get_stylesheet_directory_uri(), '/') . '/assets/images/odoo/';
    $request_key = $cache_key . '|' . $uri;
    if (isset($registries[$request_key])) {
        return $registries[$request_key];
    }

    $filenames = get_transient($cache_key);
    if (!is_array($filenames)) {
        $filenames = array();
        $entries = is_dir($directory) && is_readable($directory) ? scandir($directory) : false;
        foreach ($entries ?: array() as $filename) {
            if (!preg_match('/^[^\/\\\\\x00-\x1f]+\.png$/u', $filename)
                || $filename === 'odoo_community_member_rgb.png'
                || is_link($directory . '/' . $filename)
                || !is_file($directory . '/' . $filename)) {
                continue;
            }
            $filenames[] = $filename;
        }
        set_transient($cache_key, $filenames, DAY_IN_SECONDS);
    }

    $icons = array();
    foreach ($filenames as $filename) {
        // Also validate cached data before constructing a URL.
        if (!is_string($filename) || !preg_match('/^[^\/\\\\\x00-\x1f]+\.png$/u', $filename)
            || $filename === 'odoo_community_member_rgb.png') {
            continue;
        }
        $label = preg_replace('/\s+/u', ' ', trim(substr($filename, 0, -4)));
        if (class_exists('Normalizer')) {
            $label = Normalizer::normalize($label, Normalizer::FORM_C);
        }
        $icons[$filename] = array('label' => $label, 'url' => $uri . rawurlencode($filename));
    }
    uasort($icons, function ($first, $second) {
        return strnatcasecmp($first['label'], $second['label']);
    });
    $registries[$request_key] = $icons;
    return $icons;
}

/** Resolve an actual filename or normalized label slug against the asset allowlist. */
function tw_odoo_icon_key($value) {
    if (!is_string($value) || $value === '' || preg_match('/[\/\\\\\x00-\x1f]/', $value)) {
        return '';
    }
    $icons = tw_odoo_icons();
    if (isset($icons[$value])) {
        return $value;
    }
    // A slug is an exact alias, not a sanitized approximation of unsafe input.
    if (!preg_match('/^[a-z0-9]+(?:-[a-z0-9]+)*$/D', $value)) {
        return '';
    }
    $matched = '';
    foreach ($icons as $filename => $icon) {
        if (tw_odoo_icon_slug($icon['label']) === $value) {
            if ($matched !== '') {
                return ''; // Ambiguous aliases must never silently select another asset.
            }
            $matched = $filename;
        }
    }
    return $matched;
}

/** Return a current-theme URL only for an allowlisted application asset. */
function tw_odoo_icon_url($filename) {
    $key = tw_odoo_icon_key($filename);
    if ($key === '') {
        return '';
    }
    $icons = tw_odoo_icons();
    return $icons[$key]['url'];
}
