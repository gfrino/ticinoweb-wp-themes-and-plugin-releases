<?php
/** Native archive, search and recovery presentation. No query or SEO mutations. */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Preserve the specialized Projects and WooCommerce presentation. */
function tw_public_archives_is_context() {
	if ( ( function_exists( 'tw_projects_is_archive' ) && tw_projects_is_archive() )
		|| ( function_exists( 'is_woocommerce' ) && is_woocommerce() ) ) {
		return false;
	}
	return is_archive() || is_search() || is_404() || is_home();
}

function tw_public_archives_enqueue() {
	if ( ! tw_public_archives_is_context() ) {
		return;
	}
	$version = wp_get_theme()->get( 'Version' );
	wp_enqueue_style( 'ticinoweb-child-blog', get_stylesheet_directory_uri() . '/assets/css/blog.css', array( 'ticinoweb-child-site' ), $version );
	wp_enqueue_style( 'ticinoweb-child-public-archives', get_stylesheet_directory_uri() . '/assets/css/public-archives.css', array( 'ticinoweb-child-blog' ), $version );
}
add_action( 'wp_enqueue_scripts', 'tw_public_archives_enqueue', 25 );

/** Resolve existing CMS destinations; never manufacture a URL for a missing page. */
function tw_public_archives_recovery_links() {
	$links = array( 'home' => array( 'url' => home_url( '/' ), 'label' => __( 'Home', 'ticinoweb-child-theme' ) ) );
	$mapping = (array) get_option( 'ticinoweb_page_mapping', array() );
	$destinations = array(
		'web'      => array( 'mapping' => 'page_siti_web', 'slugs' => array( 'siti-web' ), 'label' => __( 'Siti Web', 'ticinoweb-child-theme' ) ),
		'projects' => array( 'mapping' => 'page_referenze', 'slugs' => array( 'referenze', 'showcase' ), 'label' => __( 'Progetti', 'ticinoweb-child-theme' ) ),
		'contact'  => array( 'mapping' => 'page_contatti', 'slugs' => array( 'contatti' ), 'label' => __( 'Contatti', 'ticinoweb-child-theme' ) ),
	);
	foreach ( $destinations as $key => $destination ) {
		$id = absint( $mapping[ $destination['mapping'] ] ?? 0 );
		if ( ! $id || 'publish' !== get_post_status( $id ) ) {
			$id = 0;
			foreach ( $destination['slugs'] as $slug ) {
				$page = get_page_by_path( $slug );
				if ( $page && 'publish' === $page->post_status ) {
					$id = $page->ID;
					break;
				}
			}
		}
		$url = $id ? get_permalink( $id ) : '';
		if ( $url ) {
			$links[ $key ] = array( 'url' => $url, 'label' => $destination['label'] );
		}
	}
	return $links;
}

/** The native main query owns filters, order, counts and pagination. */
function tw_public_archives_render_results() {
	if ( have_posts() ) {
		echo '<div class="tw-blog-grid tw-public-grid">';
		while ( have_posts() ) {
			the_post();
			get_template_part( 'template-parts/public-result' );
		}
		echo '</div>';
		the_posts_pagination(
			array(
				'class'              => 'tw-blog-pagination',
				'mid_size'           => 1,
				'prev_text'          => __( 'Precedenti', 'ticinoweb-child-theme' ),
				'next_text'          => __( 'Successivi', 'ticinoweb-child-theme' ),
				'screen_reader_text' => __( 'Paginazione dei risultati', 'ticinoweb-child-theme' ),
			)
		);
		return;
	}
	?>
	<div class="tw-public-empty">
		<h2><?php esc_html_e( 'Nessun risultato trovato.', 'ticinoweb-child-theme' ); ?></h2>
		<p><?php esc_html_e( 'Prova un’altra ricerca oppure esplora queste pagine.', 'ticinoweb-child-theme' ); ?></p>
		<nav class="tw-public-actions" aria-label="<?php esc_attr_e( 'Pagine utili', 'ticinoweb-child-theme' ); ?>">
			<?php foreach ( tw_public_archives_recovery_links() as $link ) : ?>
				<a href="<?php echo esc_url( $link['url'] ); ?>"><?php echo esc_html( $link['label'] ); ?></a>
			<?php endforeach; ?>
		</nav>
	</div>
	<?php
}
