<?php
/** Agency-panel presentation only. Existing primary navigation and CMS contacts stay authoritative. */
if(!defined('ABSPATH'))exit;
function tw_agency_menu_page_id(){ $m=(array)get_option('ticinoweb_page_mapping',[]);return absint($m['page_chi_siamo']??$m['page_contatti']??0); }
function tw_agency_menu_data(){ $d=get_post_meta(tw_agency_menu_page_id(),'_tw_agency_menu',true);return is_array($d)?$d:[]; }
function tw_agency_menu_fields(){return [
 'eyebrow'=>__('Introduzione — Sopratitolo','ticinoweb-child-theme'),'title'=>__('Introduzione — Titolo','ticinoweb-child-theme'),'text'=>__('Introduzione — Descrizione','ticinoweb-child-theme'),'microcopy'=>__('Introduzione — Microcopy','ticinoweb-child-theme'),
 'about_description'=>__('Chi siamo — Descrizione breve','ticinoweb-child-theme'),'team_description'=>__('Team — Descrizione breve','ticinoweb-child-theme'),'jobs_description'=>__('Lavora con noi — Descrizione breve','ticinoweb-child-theme'),'sustainability_description'=>__('Sostenibilità — Descrizione breve','ticinoweb-child-theme'),'faq_description'=>__('FAQ — Descrizione breve','ticinoweb-child-theme'),'contact_description'=>__('Contatti — Descrizione breve','ticinoweb-child-theme'),
 'birth_label'=>__('Fondazione — Etichetta','ticinoweb-child-theme'),'studio_label'=>__('Sede — Etichetta','ticinoweb-child-theme'),'team_label'=>__('Competenze — Etichetta','ticinoweb-child-theme'),'team_text'=>__('Competenze — Testo','ticinoweb-child-theme') ];}
function tw_agency_menu_facts(){
 $contact=function_exists('ticinoweb_get_contact_info')?ticinoweb_get_contact_info():[];$facts=function_exists('tw_about_data')?(tw_about_data(tw_agency_menu_page_id())['facts']??[]):[];$year='';$city='';
 foreach($facts as $f){if(preg_match('/^\d{4}$/',$f['title']??''))$year=$f['title'];if(str_contains(strtolower($f['text']??''),'sede'))$city=$f['title']??'';}
 return ['year'=>$year,'city'=>$city,'name'=>get_option('tw_seo_org_name',''),'contact'=>$contact];
}
add_action('add_meta_boxes_page',static function($post){if($post->ID===tw_agency_menu_page_id())add_meta_box('tw-agency-menu',__('Mega menu Agenzia','ticinoweb-child-theme'),'tw_agency_menu_metabox','page','normal','default');});
function tw_agency_menu_metabox($post){
 $d=tw_agency_menu_data();wp_nonce_field('tw_agency_menu_save','tw_agency_menu_nonce');wp_enqueue_media();
 echo '<p>'.esc_html__('Solo il pannello Agenzia. I link restano quelli reali del menu; le sue descrizioni hanno priorità. Nome, recapiti, anno e sede provengono dai dati CMS esistenti. Se non scegli una foto aziendale valida viene mostrato il riepilogo tipografico.','ticinoweb-child-theme').'</p>';
 foreach(tw_agency_menu_fields() as $key=>$label){echo '<p><label><strong>'.esc_html($label).'</strong><textarea style="display:block;width:100%" rows="2" name="tw_agency_menu['.esc_attr($key).']">'.esc_textarea($d[$key]??'').'</textarea></label></p>';}
 ?><p class="tw-agency-media-picker"><strong><?php esc_html_e('Featured Media — solo team, studio o ambiente reale','ticinoweb-child-theme'); ?></strong><input type="hidden" name="tw_agency_menu[media_id]" value="<?php echo esc_attr($d['media_id']??0); ?>"><span><?php echo !empty($d['media_id'])?esc_html(get_the_title($d['media_id'])):''; ?></span><button type="button" class="button tw-agency-pick"><?php esc_html_e('Seleziona media','ticinoweb-child-theme'); ?></button><button type="button" class="button tw-agency-clear"><?php esc_html_e('Rimuovi','ticinoweb-child-theme'); ?></button></p>
 <script>document.querySelectorAll('.tw-agency-media-picker').forEach(function(p){p.querySelector('.tw-agency-pick').onclick=function(){const f=wp.media({multiple:false,library:{type:'image'}});f.on('select',function(){const m=f.state().get('selection').first().toJSON();p.querySelector('input').value=m.id;p.querySelector('span').textContent=m.title;});f.open();};p.querySelector('.tw-agency-clear').onclick=function(){p.querySelector('input').value=0;p.querySelector('span').textContent='';};});</script>
 <?php
}
function tw_agency_menu_save($id){
 if($id!==tw_agency_menu_page_id()||empty($_POST['tw_agency_menu_nonce'])||!wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['tw_agency_menu_nonce'])),'tw_agency_menu_save')||!current_user_can('edit_post',$id)||wp_is_post_revision($id)||(defined('DOING_AUTOSAVE')&&DOING_AUTOSAVE))return;
 $raw=wp_unslash($_POST['tw_agency_menu']??[]);if(!is_array($raw))return;$d=[];
 foreach(tw_agency_menu_fields() as $key=>$label)$d[$key]=sanitize_textarea_field(is_scalar($raw[$key]??'')?($raw[$key]??''):'');
 $media=absint($raw['media_id']??0);$d['media_id']=wp_attachment_is_image($media)?$media:0;update_post_meta($id,'_tw_agency_menu',$d);
}
add_action('save_post_page','tw_agency_menu_save');
