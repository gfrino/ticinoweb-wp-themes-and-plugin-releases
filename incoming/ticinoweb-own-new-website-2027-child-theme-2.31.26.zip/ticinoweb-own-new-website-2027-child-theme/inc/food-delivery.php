<?php
/**
 * Pagina Food Delivery: fasce fotografiche con parallasse e galleria dei siti realizzati.
 *
 * @package ticinoWEB_Child_Theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function tw_food_is_page() {
	$post = get_queried_object();
	return $post instanceof WP_Post && 'page' === $post->post_type && 'food-delivery' === $post->post_name;
}

add_action( 'wp_enqueue_scripts', function () {
	if ( ! tw_food_is_page() ) {
		return;
	}
	$ver = wp_get_theme()->get( 'Version' );
	wp_enqueue_style( 'ticinoweb-child-food', get_stylesheet_directory_uri() . '/assets/css/food-delivery.css', array( 'ticinoweb-child-web-services' ), $ver );
	wp_enqueue_script( 'ticinoweb-child-food', get_stylesheet_directory_uri() . '/assets/js/food-delivery.js', array(), $ver, true );
	wp_script_add_data( 'ticinoweb-child-food', 'strategy', 'defer' );
}, 30 );

function tw_food_img( $file ) {
	return get_stylesheet_directory_uri() . '/assets/images/food/' . $file;
}

/**
 * Fascia fotografica a tutta larghezza: l'immagine scorre più lentamente della pagina.
 */
function tw_food_band( $image, $kicker, $title, $text, $alt, $position = 'center' ) {
	?>
	<section class="tw-food-band" aria-label="<?php echo esc_attr( $title ); ?>">
		<div class="tw-food-band__media" data-tw-parallax="0.28">
			<img src="<?php echo esc_url( tw_food_img( $image ) ); ?>" alt="<?php echo esc_attr( $alt ); ?>" loading="lazy" decoding="async" style="object-position:<?php echo esc_attr( $position ); ?>">
		</div>
		<div class="tw-shell tw-food-band__copy" data-tw-reveal>
			<p class="tw-kicker"><?php echo esc_html( $kicker ); ?></p>
			<h2><?php echo esc_html( $title ); ?></h2>
			<p><?php echo esc_html( $text ); ?></p>
		</div>
	</section>
	<?php
}

function tw_food_sites() {
	return array(
		array( 'mrjoecity.ch', 'https://www.mrjoecity.ch', 'shot-mrjoecity.webp' ),
		array( 'pizzastyle.ch', 'https://www.pizzastyle.ch', 'shot-pizzastyle.webp' ),
		array( 'littleinka.ch', 'https://www.littleinka.ch', 'shot-littleinka.webp' ),
		array( 'pizza-flash.ch', 'https://www.pizza-flash.ch', 'shot-pizza-flash.webp' ),
		array( 'machepizza.ch', 'https://www.machepizza.ch', 'shot-machepizza.webp' ),
	);
}

/**
 * Galleria di screenshot in cornice di browser, su sfondo fotografico in parallasse.
 */
function tw_food_gallery() {
	?>
	<section class="tw-food-gallery" aria-labelledby="tw-food-gallery-title">
		<div class="tw-food-gallery__bg" data-tw-parallax="0.18" aria-hidden="true">
			<img src="<?php echo esc_url( tw_food_img( 'fd-steak.webp' ) ); ?>" alt="" loading="lazy" decoding="async">
		</div>
		<div class="tw-shell">
			<header data-tw-reveal>
				<p class="tw-kicker"><?php esc_html_e( 'Siti online', 'ticinoweb-child-theme' ); ?></p>
				<h2 id="tw-food-gallery-title"><?php esc_html_e( 'Food delivery che funzionano davvero', 'ticinoweb-child-theme' ); ?></h2>
				<p><?php esc_html_e( 'Pizzerie e ristoranti con ordini online, pagamento e stampa dell’ordine in cucina. Questi sono alcuni dei siti realizzati da noi.', 'ticinoweb-child-theme' ); ?></p>
			</header>
			<ul class="tw-food-gallery__grid">
				<?php foreach ( tw_food_sites() as $site ) : ?>
				<li data-tw-reveal>
					<a class="tw-food-shot" href="<?php echo esc_url( $site[1] ); ?>" target="_blank" rel="noopener">
						<span class="tw-food-shot__bar" aria-hidden="true"><i></i><i></i><i></i><b><?php echo esc_html( $site[0] ); ?></b></span>
						<img src="<?php echo esc_url( tw_food_img( $site[2] ) ); ?>" alt="<?php echo esc_attr( sprintf( /* translators: %s: site domain */ __( 'Sito food delivery %s', 'ticinoweb-child-theme' ), $site[0] ) ); ?>" width="1200" height="750" loading="lazy" decoding="async">
					</a>
				</li>
				<?php endforeach; ?>
			</ul>
		</div>
	</section>
	<?php
}
