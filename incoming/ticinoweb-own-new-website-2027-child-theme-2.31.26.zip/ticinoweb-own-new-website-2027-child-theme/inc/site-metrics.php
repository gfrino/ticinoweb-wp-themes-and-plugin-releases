<?php
/**
 * Local site metrics and Google Reviews refresh policy.
 *
 * @package ticinoWEB_Child_Theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Preserve the saved project total when another CMS form posts the shared group. */
function tw_child_sanitize_completed_projects( $value ) {
	if ( null === $value || ! isset( $_POST['tw_home_completed_projects'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Settings API validates the request.
		return absint( get_option( 'tw_home_completed_projects', 0 ) );
	}
	return min( 999999, absint( $value ) );
}

/** Add the client-specific historic project total to the existing CMS settings group. */
function tw_child_register_site_metrics() {
	register_setting(
		'ticinoweb_settings_group',
		'tw_home_completed_projects',
		array(
			'type'              => 'integer',
			'sanitize_callback' => 'tw_child_sanitize_completed_projects',
			'default'           => 0,
		)
	);

	add_settings_field(
		'tw_home_completed_projects',
		__( 'Referenze completate', 'ticinoweb-child-theme' ),
		static function () {
			$value = absint( get_option( 'tw_home_completed_projects', 0 ) );
			?>
			<input class="small-text" type="number" min="0" max="999999" step="1" id="tw_home_completed_projects" name="tw_home_completed_projects" value="<?php echo esc_attr( (string) $value ); ?>">
			<p class="description"><?php esc_html_e( 'Totale storico reale. Lascia 0 per usare automaticamente il numero delle referenze pubblicate nel CMS.', 'ticinoweb-child-theme' ); ?></p>
			<?php
		},
		'ticinoweb_settings_group',
		'ticinoweb_main_section'
	);
}
add_action( 'admin_init', 'tw_child_register_site_metrics', 30 );

/** Schedule a periodic refresh through the Google integration already owned by the parent. */
function tw_child_schedule_google_reviews_sync() {
	if ( ! wp_next_scheduled( 'tw_child_google_reviews_sync' ) ) {
		wp_schedule_event( time() + HOUR_IN_SECONDS, 'twicedaily', 'tw_child_google_reviews_sync' );
	}
}
add_action( 'init', 'tw_child_schedule_google_reviews_sync', 40 );

/** Refresh the cached Google data; the parent only replaces valid data after a successful response. */
function tw_child_run_google_reviews_sync() {
	if ( ! function_exists( 'ticinoweb_pull_google_reviews' ) ) {
		return;
	}
	if ( ! get_option( 'ticinoweb_google_api_key' ) || ! get_option( 'ticinoweb_google_place_id' ) ) {
		return;
	}

	$result = ticinoweb_pull_google_reviews();
	if ( is_wp_error( $result ) ) {
		set_transient( 'tw_child_google_reviews_sync_error', sanitize_text_field( $result->get_error_message() ), 12 * HOUR_IN_SECONDS );
		return;
	}
	delete_transient( 'tw_child_google_reviews_sync_error' );
}
add_action( 'tw_child_google_reviews_sync', 'tw_child_run_google_reviews_sync' );

/** Remove only this child theme's event when the theme is switched. */
function tw_child_clear_google_reviews_sync() {
	wp_clear_scheduled_hook( 'tw_child_google_reviews_sync' );
}
add_action( 'switch_theme', 'tw_child_clear_google_reviews_sync' );
