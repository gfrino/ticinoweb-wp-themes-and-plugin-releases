<?php
/** Restore original CMS questionnaire through the existing protected parent form. */
if (!defined('ABSPATH')) exit;

/** Omit the redundant introductory heading at render time, never alter CMS data. */
function tw_sitewide_survey_intro($html,$title) {
	$normalize=static function($text) {
		$text=strtolower(html_entity_decode(strip_tags($text),ENT_QUOTES,'UTF-8'));
		return trim(preg_replace('/\s+/u',' ',preg_replace('/\bdi\b/u','',$text)));
	};
	return preg_replace_callback('/<h2\b[^>]*>(.*?)<\/h2>/is',static function($match) use($normalize,$title) {
		return $normalize($match[1])===$normalize($title)?'':$match[0];
	},$html,1);
}

function tw_sitewide_survey_normalize($snapshot) {
	$fields=[];
	foreach ((array)$snapshot as $form) {
		if (!is_array($form) || !is_array($form['fields']??null)) continue;
		foreach ($form['fields'] as $field) {
			if (!is_array($field) || !is_string($field['id']??null) || !preg_match('/^[a-zA-Z0-9_-]+$/D',$field['id']) || !is_string($field['label']??null) || !in_array($field['type']??null,['text','email','textarea','tel'],true)) continue;
			$id=$field['id'];
			if (isset($fields[$id])) continue;
			$label=sanitize_text_field($field['label']);
			if ($label==='') continue;
			$fields[$id]=['id'=>$id,'type'=>$field['type'],'label'=>$label];
		}
	}
	return array_values($fields);
}

function tw_sitewide_survey_fields($post_id) {
	$post=get_post($post_id);
	if (!$post || $post->post_type!=='page' || $post->post_status!=='publish') return [];
	$raw=get_post_meta($post->ID,'__elementor_forms_snapshot',true);
	$snapshot=is_string($raw)?json_decode($raw,true):$raw;
	$fields=tw_sitewide_survey_normalize(is_array($snapshot)?$snapshot:[]);
	return ($post->post_name==='sondaggio-marketing' || count($fields)===19) ? $fields : [];
}

function tw_sitewide_survey_role($field) {
	if ($field['type']==='email') return 'email';
	if ($field['id']==='name' || preg_match('/^nome(?: completo| e cognome)?$/iu',$field['label'])) return 'nome';
	if ($field['type']==='tel' || preg_match('/^telefono$/iu',$field['label'])) return 'telefono';
	return '';
}

/** Pure composition: known scalar inputs only; parent enforces aggregate 5000 characters. */
function tw_sitewide_survey_compose($fields,$answers,$title) {
	$result=['nome'=>'','email'=>'','telefono'=>'','oggetto'=>sanitize_text_field($title),'messaggio'=>''];
	$lines=[];
	foreach ($fields as $field) {
		$value=$answers[$field['id']]??'';
		$value=is_string($value)?wp_unslash($value):'';
		$value=str_replace(["\r\n","\r"],"\n",$value);
		$value=$field['type']==='email'?sanitize_email($value):($field['type']==='textarea'?sanitize_textarea_field($value):sanitize_text_field($value));
		$role=tw_sitewide_survey_role($field);
		if ($role) $result[$role]=$value;
		elseif ($value!=='') $lines[]=$field['label'].': '.$value;
	}
	$result['messaggio']=implode("\n\n",$lines);
	return $result;
}

function tw_sitewide_survey_guard() {
	if (($_POST['tw_form_context']??null)!=='legacy_survey') return;
	$token=$_POST['token']??'';
	if (!is_string($token)) wp_send_json_error(['message'=>__('Sessione scaduta, riprova.','ticinoweb-child-theme')],403);
	if (!wp_verify_nonce(sanitize_text_field(wp_unslash($token)),'ticinoweb_submit_form')) return;
	$id=$_POST['tw_survey_page']??'';
	$fields=is_string($id)&&ctype_digit($id)?tw_sitewide_survey_fields((int)$id):[];
	$invalid=!$fields || ($_POST['privacy']??null)!=='1' || !is_array($_POST['tw_survey']??[]);
	foreach (['nome','email','telefono','oggetto','messaggio','tw_hp','recaptcha_token'] as $key) if (isset($_POST[$key])&&!is_string($_POST[$key])) $invalid=true;
	foreach ((array)($_POST['tw_survey']??[]) as $value) if (!is_string($value)) $invalid=true;
	if ($invalid) wp_send_json_error(['message'=>__('Controlla il modulo e accetta l’informativa privacy.','ticinoweb-child-theme'),'fields'=>['privacy'=>__('Campo obbligatorio.','ticinoweb-child-theme')]],422);
}
add_action('wp_ajax_ticinoweb_submit_form','tw_sitewide_survey_guard',1);
add_action('wp_ajax_nopriv_ticinoweb_submit_form','tw_sitewide_survey_guard',1);
add_filter('ticinoweb_form_fields',function($fields,$raw) {
	if (($raw['tw_form_context']??null)!=='legacy_survey') return $fields;
	$id=$raw['tw_survey_page']??'';
	$definitions=is_string($id)&&ctype_digit($id)?tw_sitewide_survey_fields((int)$id):[];
	if (!$definitions) return $fields;
	$answers=is_array($raw['tw_survey']??null)?$raw['tw_survey']:[];
	foreach ($definitions as $field) if ($role=tw_sitewide_survey_role($field)) $answers[$field['id']]=$raw[$role]??'';
	return tw_sitewide_survey_compose($definitions,$answers,get_the_title((int)$id));
},20,2);

add_action('wp_enqueue_scripts',function() {
	if (!is_page() || !tw_sitewide_survey_fields(get_queried_object_id())) return;
	wp_enqueue_script('tw-about',get_stylesheet_directory_uri().'/assets/js/about-contact.js',[],wp_get_theme()->get('Version'),true);
	wp_localize_script('tw-about','twAboutForm',[
		'ajax_url'=>admin_url('admin-ajax.php'),'token_action'=>'ticinoweb_form_token','submit_action'=>'ticinoweb_submit_form',
		'recaptcha_site_key'=>(string)get_option('ticinoweb_recaptcha_site_key',''),
		'busy'=>__('Invio in corso…','ticinoweb-child-theme'),'failure'=>__('Invio non riuscito. Riprova oppure contattaci via email.','ticinoweb-child-theme'),
		'privacy'=>__('Accetta l’informativa privacy per inviare la richiesta.','ticinoweb-child-theme'),
		'saved'=>__('Richiesta registrata. Se non ricevi una risposta, contattaci direttamente.','ticinoweb-child-theme'),
	]);
	wp_enqueue_script('tw-legacy-survey',get_stylesheet_directory_uri().'/assets/js/legacy-survey.js',['tw-about'],wp_get_theme()->get('Version'),true);
	wp_localize_script('tw-legacy-survey','twSurveyBudget',[
		'remaining'=>__('%d caratteri disponibili, domande incluse.','ticinoweb-child-theme'),
		'excess'=>__('Riduci le risposte di almeno %d caratteri.','ticinoweb-child-theme'),
		'overflow'=>__('Le risposte e le domande superano il limite complessivo di 5000 caratteri. Riduci le risposte prima di inviare.','ticinoweb-child-theme'),
	]);
},31);
