<?php
/**
 * Read-only helpers for the Support page.
 *
 * @package ticinoWEB_Child_Theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Checks whether the current request is the mapped Support page.
 *
 * @return bool
 */
function tw_support_is_page() {
	if ( ! function_exists( 'is_page' ) ) {
		return false;
	}

	$mapping = get_option( 'ticinoweb_page_mapping', array() );
	$page_id = isset( $mapping['page_supporto'] ) ? absint( $mapping['page_supporto'] ) : 0;

	return ( $page_id && is_page( $page_id ) ) || is_page( 'supporto' );
}

/**
 * Keeps the existing specialist recipients stored in the Support page editor.
 *
 * @param string $content        Raw Support page content.
 * @param string $service_key    Service key.
 * @param string $fallback_email CMS contact email.
 * @return string
 */
function tw_support_resolve_service_email( $content, $service_key, $fallback_email ) {
	$aliases = array(
		'odoo'      => array( 'odoo' ),
		'app'       => array( 'app', 'ios', 'android' ),
		'web'       => array( 'web' ),
		'marketing' => array( 'marketing' ),
	);
	$matches = array();
	preg_match_all( '/mailto:([^\s"\'<>?]+)/iu', (string) $content, $matches );

	foreach ( $matches[1] ?? array() as $candidate ) {
		$email = sanitize_email( rawurldecode( html_entity_decode( $candidate, ENT_QUOTES, 'UTF-8' ) ) );
		if ( ! is_email( $email ) ) {
			continue;
		}
		$local_part = strtolower( strstr( $email, '@', true ) ?: $email );
		foreach ( $aliases[ $service_key ] ?? array() as $alias ) {
			if ( str_contains( $local_part, $alias ) ) {
				return $email;
			}
		}
	}

	$fallback_email = sanitize_email( $fallback_email );
	return is_email( $fallback_email ) ? $fallback_email : '';
}

/**
 * Builds an encoded assistance email without inserting personal data.
 *
 * @param string $email   Recipient.
 * @param string $subject Subject line.
 * @param string $service Human-readable service.
 * @return string
 */
function tw_support_build_mailto( $email, $subject, $service ) {
	$email = sanitize_email( $email );
	if ( ! is_email( $email ) ) {
		return '';
	}

	$body = sprintf(
		"Buongiorno ticinoWEB,\n\navrei bisogno di assistenza per: %s.\n\nDescrizione del problema:\n\n\nNome / Azienda:\n\nTelefono:\n",
		wp_strip_all_tags( $service )
	);
	$query = http_build_query(
		array(
			'subject' => wp_strip_all_tags( $subject ),
			'body'    => $body,
		),
		'',
		'&',
		PHP_QUERY_RFC3986
	);

	return 'mailto:' . $email . '?' . $query;
}

/**
 * Extracts the useful explanatory paragraphs already stored in WordPress.
 *
 * @param string $content Raw Support page content.
 * @return string[]
 */
function tw_support_extract_description_paragraphs( $content ) {
	if ( ! class_exists( 'DOMDocument' ) || ! trim( (string) $content ) ) {
		return array();
	}

	$document = new DOMDocument();
	libxml_use_internal_errors( true );
	$document->loadHTML( '<?xml encoding="utf-8" ?><div id="tw-support-source">' . $content . '</div>', LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD );
	libxml_clear_errors();
	$xpath = new DOMXPath( $document );
	$nodes = $xpath->query( '//*[@id="tw-support-source"]//*[self::h2 or self::p]' );
	$found = false;
	$paragraphs = array();

	foreach ( $nodes as $node ) {
		$text = trim( preg_replace( '/\s+/u', ' ', $node->textContent ) );
		if ( 'h2' === strtolower( $node->nodeName ) ) {
			if ( $found ) {
				break;
			}
			$found = 0 === strcasecmp( $text, 'Supporto' );
			continue;
		}
		if ( ! $found || 'p' !== strtolower( $node->nodeName ) || ! $text ) {
			continue;
		}
		if ( str_contains( strtolower( $text ), 'puoi contare su di noi' ) || $node->getElementsByTagName( 'a' )->length ) {
			continue;
		}
		$paragraphs[] = $text;
		if ( 3 === count( $paragraphs ) ) {
			break;
		}
	}

	return $paragraphs;
}


/**
 * Icone a tratto (wireframe) della pagina Supporto, SVG inline: ereditano il colore del testo.
 *
 * @param string $name Nome dell'icona.
 * @return string SVG già pronto (contenuto statico, sicuro da stampare).
 */
function tw_support_icon( $name ) {
	$paths = array(
		'odoo'      => '<rect x="3" y="3" width="7.5" height="7.5" rx="1.6"/><rect x="13.5" y="3" width="7.5" height="7.5" rx="1.6"/><rect x="3" y="13.5" width="7.5" height="7.5" rx="1.6"/><path d="M17.25 13.5v7.5M13.5 17.25H21"/>',
		'app'       => '<rect x="6.5" y="2.5" width="11" height="19" rx="2.6"/><path d="M10.5 18.5h3"/><path d="M10 5.5h4"/>',
		'web'       => '<rect x="2.5" y="4" width="19" height="16" rx="2.2"/><path d="M2.5 9h19"/><circle cx="5.6" cy="6.5" r=".6"/><circle cx="8" cy="6.5" r=".6"/><path d="M7 14.5h4M7 17h8"/>',
		'marketing' => '<path d="M3.5 10.5v3a1 1 0 0 0 1 1h2l5 4V5.5l-5 4h-2a1 1 0 0 0-1 1z"/><path d="M15 9.2a4 4 0 0 1 0 5.6M17.8 6.6a8 8 0 0 1 0 10.8"/>',
		'headset'   => '<path d="M4 14v-2a8 8 0 0 1 16 0v2"/><path d="M4 14h3v4.5H5.2a1.2 1.2 0 0 1-1.2-1.2z"/><path d="M20 14h-3v4.5h1.8a1.2 1.2 0 0 0 1.2-1.2z"/><path d="M18.5 18.5c0 1.8-1.8 2.8-4.5 2.8"/>',
		'ticket'    => '<path d="M3.5 7.5h17v3a1.8 1.8 0 0 0 0 3.6v3.4h-17v-3.4a1.8 1.8 0 0 0 0-3.6z"/><path d="M14.5 7.5v9" stroke-dasharray="1.6 1.8"/>',
		'user'      => '<circle cx="12" cy="8" r="3.6"/><path d="M4.8 20c.9-3.9 3.7-6 7.2-6s6.3 2.1 7.2 6"/>',
		'shield'    => '<path d="M12 3l7.5 3v5.5c0 4.6-3.1 7.6-7.5 9.5-4.4-1.9-7.5-4.9-7.5-9.5V6z"/><path d="M8.8 12.2l2.2 2.2 4.2-4.4"/>',
	);
	if ( ! isset( $paths[ $name ] ) ) {
		return '';
	}
	return '<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" focusable="false">' . $paths[ $name ] . '</svg>';
}
