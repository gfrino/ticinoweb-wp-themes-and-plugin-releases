<?php
/**
 * Structured CMS and rendering contract for the commercial Website Services.
 *
 * @package ticinoWEB_Child_Theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'TW_WEB_SERVICE_META', '_tw_web_service' );
define( 'TW_WEB_SERVICE_TYPE_META', '_tw_web_service_type' );

/**
 * One controlled family: overview plus three real website types.
 */
function tw_web_services_page_definitions() {
	return array(
		'siti-web' => array(
			'slug'     => 'siti-web',
			'title'    => __( 'Siti Web', 'ticinoweb-child-theme' ),
			'template' => 'page-siti-web.php',
			'kind'     => 'overview',
		),
		'one-page' => array(
			'slug'     => 'one-page',
			'title'    => __( 'One-Page', 'ticinoweb-child-theme' ),
			'template' => 'page-web-service.php',
			'kind'     => 'type',
		),
		'aziendale-premium' => array(
			'slug'     => 'aziendale-premium',
			'title'    => __( 'Aziendale Premium', 'ticinoweb-child-theme' ),
			'template' => 'page-web-service.php',
			'kind'     => 'type',
		),
		'ecommerce' => array(
			'slug'     => 'ecommerce-websites',
			'title'    => __( 'eCommerce', 'ticinoweb-child-theme' ),
			'template' => 'page-web-service.php',
			'kind'     => 'type',
		),
		'food-delivery' => array(
			'slug'     => 'food-delivery',
			'title'    => __( 'Food Delivery', 'ticinoweb-child-theme' ),
			'template' => 'page-web-service.php',
			'kind'     => 'type',
		),
	);
}

/**
 * Initial editorial content, copied to page meta by the explicit initializer.
 */
function tw_web_services_initial_content() {
	$common_process = array(
		array( 'number' => '01', 'title' => __( 'Ascolto', 'ticinoweb-child-theme' ), 'text' => __( 'Comprendiamo obiettivi, pubblico e contesto prima di proporre una soluzione.', 'ticinoweb-child-theme' ) ),
		array( 'number' => '02', 'title' => __( 'Strategia', 'ticinoweb-child-theme' ), 'text' => __( 'Definiamo priorità, contenuti e percorso affinché ogni scelta abbia una ragione.', 'ticinoweb-child-theme' ) ),
		array( 'number' => '03', 'title' => __( 'Design', 'ticinoweb-child-theme' ), 'text' => __( 'Trasformiamo la strategia in un’esperienza riconoscibile, chiara e facile da usare.', 'ticinoweb-child-theme' ) ),
		array( 'number' => '04', 'title' => __( 'Sviluppo', 'ticinoweb-child-theme' ), 'text' => __( 'Costruiamo con attenzione a qualità, prestazioni, sicurezza e gestione futura.', 'ticinoweb-child-theme' ) ),
		array( 'number' => '05', 'title' => __( 'Crescita', 'ticinoweb-child-theme' ), 'text' => __( 'Restiamo presenti dopo il lancio con supporto e miglioramenti continui.', 'ticinoweb-child-theme' ) ),
	);
	$common_includes = array(
		array( 'number' => '01', 'title' => __( 'Design su misura', 'ticinoweb-child-theme' ), 'text' => __( 'Un’interfaccia coerente con identità, contenuti e obiettivi del progetto.', 'ticinoweb-child-theme' ) ),
		array( 'number' => '02', 'title' => __( 'CMS gestibile', 'ticinoweb-child-theme' ), 'text' => __( 'Contenuti aggiornabili dal backend con una struttura chiara e controllata.', 'ticinoweb-child-theme' ) ),
		array( 'number' => '03', 'title' => __( 'Responsive', 'ticinoweb-child-theme' ), 'text' => __( 'Un’esperienza curata su computer, tablet e smartphone.', 'ticinoweb-child-theme' ) ),
		array( 'number' => '04', 'title' => __( 'Struttura SEO', 'ticinoweb-child-theme' ), 'text' => __( 'Codice, gerarchie e contenuti preparati per essere compresi dai motori di ricerca.', 'ticinoweb-child-theme' ) ),
		array( 'number' => '05', 'title' => __( 'Contatti e misurazione', 'ticinoweb-child-theme' ), 'text' => __( 'Form e strumenti di analisi configurati in base alle necessità reali.', 'ticinoweb-child-theme' ) ),
	);
	$visibility = array(
		'show_intro'     => '1',
		'show_audience'  => '1',
		'show_includes'  => '1',
		'show_features'  => '1',
		'show_process'   => '1',
		'show_extras'    => '1',
		'show_growth'    => '1',
		'show_faq'       => '0',
		'show_final_cta' => '1',
		'hero_media_id'     => 0,
		'intro_media_id'    => 0,
		'includes_media_id' => 0,
		'growth_media_id'   => 0,
		'method_media_id'   => 0,
	);

	return array(
		'siti-web' => array_merge(
			$visibility,
			array(
				'hero_eyebrow'        => __( 'Il nostro core', 'ticinoweb-child-theme' ),
				'hero_title'          => __( 'Siti pensati per funzionare, crescere e farsi ricordare.', 'ticinoweb-child-theme' ),
				'hero_text'           => __( 'Strategia, identità, contenuti e tecnologia in un unico percorso.', 'ticinoweb-child-theme' ),
				'hero_cta_text'       => __( 'Parliamo del tuo progetto', 'ticinoweb-child-theme' ),
				'intro_title'         => __( 'Il sito giusto parte da ciò che deve ottenere.', 'ticinoweb-child-theme' ),
				'intro_text'          => __( 'Progettiamo esperienze digitali chiare, veloci e gestibili. La struttura cambia in base alla complessità dell’azienda e al percorso che deve compiere chi visita il sito.', 'ticinoweb-child-theme' ),
				'overview_types'      => array(
					array( 'number' => '01', 'title' => __( 'One-Page', 'ticinoweb-child-theme' ), 'text' => __( 'Una presenza digitale essenziale, completa e immediata.', 'ticinoweb-child-theme' ), 'url' => 'one-page' ),
					array( 'number' => '02', 'title' => __( 'Aziendale Premium', 'ticinoweb-child-theme' ), 'text' => __( 'Una piattaforma completa per raccontare azienda, servizi e identità.', 'ticinoweb-child-theme' ), 'url' => 'aziendale-premium' ),
					array( 'number' => '03', 'title' => __( 'eCommerce', 'ticinoweb-child-theme' ), 'text' => __( 'Esperienze di vendita online costruite intorno al tuo business.', 'ticinoweb-child-theme' ), 'url' => 'ecommerce-websites' ),
				),
				'final_cta_title'     => __( 'Costruiamo una presenza digitale che lavora davvero.', 'ticinoweb-child-theme' ),
				'final_cta_text'      => __( 'Raccontaci obiettivi, priorità e punto di partenza.', 'ticinoweb-child-theme' ),
				'final_cta_button'    => __( 'Parliamone', 'ticinoweb-child-theme' ),
				'portfolio_link_text' => __( 'Scopri i nostri progetti', 'ticinoweb-child-theme' ),
			)
		),
		'one-page' => array_merge(
			$visibility,
			array(
				'hero_eyebrow'     => __( 'Siti Web / One-Page', 'ticinoweb-child-theme' ),
				'hero_title'       => __( 'Tutto ciò che conta, in una sola esperienza.', 'ticinoweb-child-theme' ),
				'hero_text'        => __( 'Una pagina unica, veloce e ordinata per presentare con chiarezza attività, servizi e contatti.', 'ticinoweb-child-theme' ),
				'hero_cta_text'    => __( 'Parliamo del tuo sito', 'ticinoweb-child-theme' ),
				'intro_title'      => __( 'Una presenza essenziale, non un sito ridotto.', 'ticinoweb-child-theme' ),
				'intro_text'       => __( 'Il One-Page concentra il racconto in un percorso lineare. È adatto quando l’offerta è focalizzata e il visitatore deve capire subito chi sei, cosa proponi e come contattarti.', 'ticinoweb-child-theme' ),
				'audience_title'   => __( 'Per chi è pensato', 'ticinoweb-child-theme' ),
				'audience'         => array(
					array( 'title' => __( 'Nuove attività', 'ticinoweb-child-theme' ), 'text' => __( 'Per partire con una presenza professionale e pronta a evolvere.', 'ticinoweb-child-theme' ) ),
					array( 'title' => __( 'Professionisti', 'ticinoweb-child-theme' ), 'text' => __( 'Per raccontare competenze, approccio e modalità di contatto.', 'ticinoweb-child-theme' ) ),
					array( 'title' => __( 'Servizi focalizzati', 'ticinoweb-child-theme' ), 'text' => __( 'Per offerte chiare che non richiedono una struttura articolata.', 'ticinoweb-child-theme' ) ),
				),
				'includes_title'   => __( 'Cosa include', 'ticinoweb-child-theme' ),
				'includes'         => $common_includes,
				'features_title'   => __( 'Può crescere con te', 'ticinoweb-child-theme' ),
				'features'         => array(
					array( 'title' => __( 'Sezioni aggiuntive', 'ticinoweb-child-theme' ), 'text' => __( 'Il racconto può espandersi quando servizi e contenuti aumentano.', 'ticinoweb-child-theme' ) ),
					array( 'title' => __( 'Multilingua', 'ticinoweb-child-theme' ), 'text' => __( 'Contenuti in più lingue quando pubblico e mercato lo richiedono.', 'ticinoweb-child-theme' ) ),
					array( 'title' => __( 'Integrazioni', 'ticinoweb-child-theme' ), 'text' => __( 'Collegamenti a strumenti e servizi realmente usati dall’attività.', 'ticinoweb-child-theme' ) ),
				),
				'process_title'    => __( 'Come lavoriamo', 'ticinoweb-child-theme' ),
				'process'          => $common_process,
				'extras_title'     => __( 'Un punto di partenza che può evolvere', 'ticinoweb-child-theme' ),
				'extras_text'      => __( 'SEO, campagne, contenuti, hosting e automazioni possono essere aggiunti quando servono davvero.', 'ticinoweb-child-theme' ),
				'final_cta_title'  => __( 'Serve un sito essenziale e ben costruito?', 'ticinoweb-child-theme' ),
				'final_cta_text'   => __( 'Partiamo dalle informazioni che contano e costruiamo il percorso più diretto.', 'ticinoweb-child-theme' ),
				'final_cta_button' => __( 'Parliamone', 'ticinoweb-child-theme' ),
			)
		),
		'aziendale-premium' => array_merge(
			$visibility,
			array(
				'hero_eyebrow'     => __( 'Siti Web / Aziendale Premium', 'ticinoweb-child-theme' ),
				'hero_title'       => __( 'Una piattaforma completa per raccontare la tua azienda.', 'ticinoweb-child-theme' ),
				'hero_text'        => __( 'Struttura, contenuti e funzionalità costruiti intorno a servizi, identità e obiettivi commerciali.', 'ticinoweb-child-theme' ),
				'hero_cta_text'    => __( 'Parliamo del tuo sito', 'ticinoweb-child-theme' ),
				'intro_title'      => __( 'Più spazio al valore dell’azienda.', 'ticinoweb-child-theme' ),
				'intro_text'       => __( 'Un sito aziendale articolato organizza offerte, competenze e contenuti in percorsi chiari. È pensato per crescere nel tempo senza perdere coerenza.', 'ticinoweb-child-theme' ),
				'audience_title'   => __( 'Per chi è pensato', 'ticinoweb-child-theme' ),
				'audience'         => array(
					array( 'title' => __( 'PMI', 'ticinoweb-child-theme' ), 'text' => __( 'Per presentare più servizi e interlocutori con una struttura solida.', 'ticinoweb-child-theme' ) ),
					array( 'title' => __( 'Aziende strutturate', 'ticinoweb-child-theme' ), 'text' => __( 'Per coordinare contenuti, aree e obiettivi diversi.', 'ticinoweb-child-theme' ) ),
					array( 'title' => __( 'Organizzazioni', 'ticinoweb-child-theme' ), 'text' => __( 'Per informare pubblici diversi mantenendo una navigazione leggibile.', 'ticinoweb-child-theme' ) ),
				),
				'includes_title'   => __( 'Cosa include', 'ticinoweb-child-theme' ),
				'includes'         => array_merge( $common_includes, array( array( 'number' => '06', 'title' => __( 'Architettura dei contenuti', 'ticinoweb-child-theme' ), 'text' => __( 'Pagine e percorsi organizzati per rendere l’offerta facile da esplorare.', 'ticinoweb-child-theme' ) ) ) ),
				'features_title'   => __( 'Può crescere con te', 'ticinoweb-child-theme' ),
				'features'         => array(
					array( 'title' => __( 'Blog e risorse', 'ticinoweb-child-theme' ), 'text' => __( 'Contenuti editoriali gestibili per informare e costruire autorevolezza.', 'ticinoweb-child-theme' ) ),
					array( 'title' => __( 'Portfolio e cataloghi', 'ticinoweb-child-theme' ), 'text' => __( 'Strutture dedicate per presentare lavori, servizi o prodotti.', 'ticinoweb-child-theme' ) ),
					array( 'title' => __( 'Multilingua', 'ticinoweb-child-theme' ), 'text' => __( 'Una gestione coerente dei contenuti per mercati e pubblici diversi.', 'ticinoweb-child-theme' ) ),
				),
				'process_title'    => __( 'Come lavoriamo', 'ticinoweb-child-theme' ),
				'process'          => $common_process,
				'extras_title'     => __( 'Una base pronta a espandersi', 'ticinoweb-child-theme' ),
				'extras_text'      => __( 'Il sito può collegarsi a marketing, social, Odoo, automazioni e servizi digitali quando il progetto lo richiede.', 'ticinoweb-child-theme' ),
				'final_cta_title'  => __( 'La tua azienda merita una struttura all’altezza.', 'ticinoweb-child-theme' ),
				'final_cta_text'   => __( 'Mettiamo ordine a contenuti, priorità e funzionalità prima di disegnare.', 'ticinoweb-child-theme' ),
				'final_cta_button' => __( 'Parliamone', 'ticinoweb-child-theme' ),
			)
		),
		'ecommerce' => array_merge(
			$visibility,
			array(
				'hero_eyebrow'     => __( 'Siti Web / eCommerce', 'ticinoweb-child-theme' ),
				'hero_title'       => __( 'Vendere online con un sistema costruito intorno al tuo business.', 'ticinoweb-child-theme' ),
				'hero_text'        => __( 'Un eCommerce professionale, affidabile e pratico da gestire, dalla scoperta del prodotto fino all’ordine.', 'ticinoweb-child-theme' ),
				'hero_cta_text'    => __( 'Parliamo del tuo shop', 'ticinoweb-child-theme' ),
				'intro_title'      => __( 'Non solo un catalogo: un’esperienza di vendita.', 'ticinoweb-child-theme' ),
				'intro_text'       => __( 'Progettiamo struttura, navigazione e gestione operativa affinché prodotti, pagamenti e ordini formino un percorso semplice per il cliente e sostenibile per l’azienda.', 'ticinoweb-child-theme' ),
				'audience_title'   => __( 'Per chi è pensato', 'ticinoweb-child-theme' ),
				'audience'         => array(
					array( 'title' => __( 'Negozi e produttori', 'ticinoweb-child-theme' ), 'text' => __( 'Per portare online un assortimento e gestirlo con continuità.', 'ticinoweb-child-theme' ) ),
					array( 'title' => __( 'Brand in crescita', 'ticinoweb-child-theme' ), 'text' => __( 'Per costruire una vendita digitale coerente con l’identità del marchio.', 'ticinoweb-child-theme' ) ),
					array( 'title' => __( 'Attività con processi specifici', 'ticinoweb-child-theme' ), 'text' => __( 'Per integrare flussi, pagamenti e funzionalità su misura.', 'ticinoweb-child-theme' ) ),
				),
				'includes_title'   => __( 'Cosa include', 'ticinoweb-child-theme' ),
				'includes'         => array_merge( $common_includes, array( array( 'number' => '06', 'title' => __( 'Gestione del catalogo', 'ticinoweb-child-theme' ), 'text' => __( 'Prodotti e disponibilità gestibili dal backend.', 'ticinoweb-child-theme' ) ) ) ),
				'features_title'   => __( 'Può crescere con te', 'ticinoweb-child-theme' ),
				'features'         => array(
					array( 'title' => __( 'Catalogo e stock', 'ticinoweb-child-theme' ), 'text' => __( 'Prodotti, varianti e disponibilità organizzati per una gestione pratica.', 'ticinoweb-child-theme' ) ),
					array( 'title' => __( 'Pagamenti online', 'ticinoweb-child-theme' ), 'text' => __( 'Metodi di pagamento configurati in base al progetto.', 'ticinoweb-child-theme' ) ),
					array( 'title' => __( 'Ordini e spedizioni', 'ticinoweb-child-theme' ), 'text' => __( 'Flussi chiari per cliente e amministrazione.', 'ticinoweb-child-theme' ) ),
					array( 'title' => __( 'Promozioni e account', 'ticinoweb-child-theme' ), 'text' => __( 'Strumenti per fidelizzazione e relazione con il cliente quando necessari.', 'ticinoweb-child-theme' ) ),
					array( 'title' => __( 'Integrazioni', 'ticinoweb-child-theme' ), 'text' => __( 'Collegamenti con sistemi gestionali e servizi esterni valutati sul caso reale.', 'ticinoweb-child-theme' ) ),
				),
				'process_title'    => __( 'Come lavoriamo', 'ticinoweb-child-theme' ),
				'process'          => $common_process,
				'extras_title'     => __( 'Una piattaforma che può evolvere', 'ticinoweb-child-theme' ),
				'extras_text'      => __( 'Marketing, SEO, automazioni e integrazioni possono accompagnare la crescita dello shop.', 'ticinoweb-child-theme' ),
				'final_cta_title'  => __( 'Portiamo online il tuo modo di vendere.', 'ticinoweb-child-theme' ),
				'final_cta_text'   => __( 'Analizziamo catalogo, gestione e obiettivi prima di scegliere la soluzione.', 'ticinoweb-child-theme' ),
				'final_cta_button' => __( 'Parliamone', 'ticinoweb-child-theme' ),
			)
		),
		'food-delivery' => array_merge(
			$visibility,
			array(
				'hero_eyebrow'     => __( 'Siti Web / Food Delivery', 'ticinoweb-child-theme' ),
				'hero_title'       => __( 'Il tuo menu online. Gli ordini direttamente in pizzeria.', 'ticinoweb-child-theme' ),
				'hero_text'        => __( 'Siti web e app per pizzerie e ristoranti con consegna a domicilio e ritiro: il cliente ordina online e l’ordine arriva direttamente sulla stampante in cucina, senza commissioni di terzi.', 'ticinoweb-child-theme' ),
				'hero_cta_text'    => __( 'Parliamo della tua pizzeria', 'ticinoweb-child-theme' ),
				'intro_title'      => __( 'Pensato per chi vive di ordini online.', 'ticinoweb-child-theme' ),
				'intro_text'       => sprintf(
					/* translators: 1-4: links to client case studies. */
					__( 'ticinoWEB realizza siti e app di ordinazione per pizzerie e ristoranti: menu chiaro, supplementi e varianti, scelta tra consegna a domicilio e ritiro, pagamento online e un ordine che si stampa da solo nel locale.

L’abbiamo fatto, tra gli altri, per %1$s, pioniere della pizza online in Ticino e punto di riferimento per la consegna a domicilio nel Locarnese; per %2$s a Lugano, con sito e app; per %3$s, con l’ordine che arriva direttamente sulla stampante del locale; e per %4$s, con l’app di poké e sushi.', 'ticinoweb-child-theme' ),
					tw_web_services_case_link( 'web-designer-ecommerce-pizza-flash', 'Pizza Flash' ),
					tw_web_services_case_link( 'una-nuova-app-per-ordinare-con-un-tap', 'Mache Pizza' ),
					tw_web_services_case_link( 'mamma-mi-ordini-da-pizza-style-stasera-siiiii', 'Pizza Style' ),
					tw_web_services_case_link( 'little-inka-lancia-la-nuova-app', 'Little Inka' )
				),
				'audience_title'   => __( 'Per chi è pensato', 'ticinoweb-child-theme' ),
				'audience'         => array(
					array( 'title' => __( 'Pizzerie e ristoranti', 'ticinoweb-child-theme' ), 'text' => __( 'Per ricevere ordini a domicilio e da asporto senza passare da piattaforme esterne.', 'ticinoweb-child-theme' ) ),
					array( 'title' => __( 'Locali con più sedi', 'ticinoweb-child-theme' ), 'text' => __( 'Per far scegliere la sede e il CAP di consegna in un unico sito o in un’unica app.', 'ticinoweb-child-theme' ) ),
					array( 'title' => __( 'Chi vuole clienti che tornano', 'ticinoweb-child-theme' ), 'text' => __( 'Per costruire un rapporto diretto con account, preferiti e storico degli ordini.', 'ticinoweb-child-theme' ) ),
				),
				'includes_title'   => __( 'Cosa include', 'ticinoweb-child-theme' ),
				'includes'         => array(
					array( 'number' => '01', 'title' => __( 'Menu e supplementi', 'ticinoweb-child-theme' ), 'text' => __( 'Pizze, varianti, supplementi e opzioni (anche senza glutine) organizzati in modo chiaro e gestibili dal backend.', 'ticinoweb-child-theme' ) ),
					array( 'number' => '02', 'title' => __( 'Consegna e ritiro', 'ticinoweb-child-theme' ), 'text' => __( 'Il cliente sceglie consegna a domicilio o ritiro in sede; le zone di consegna si impostano per CAP.', 'ticinoweb-child-theme' ) ),
					array( 'number' => '03', 'title' => __( 'Pagamento online', 'ticinoweb-child-theme' ), 'text' => __( 'Metodi di pagamento configurati in base al locale, ad esempio TWINT, PostFinance e carte.', 'ticinoweb-child-theme' ) ),
					array( 'number' => '04', 'title' => __( 'Ordini stampati in pizzeria', 'ticinoweb-child-theme' ), 'text' => __( 'Appena l’ordine è confermato arriva direttamente sulla stampante del locale, pronto da preparare.', 'ticinoweb-child-theme' ) ),
					array( 'number' => '05', 'title' => __( 'Veloce da smartphone', 'ticinoweb-child-theme' ), 'text' => __( 'La maggior parte degli ordini parte dal telefono: l’esperienza è pensata prima di tutto per quello schermo.', 'ticinoweb-child-theme' ) ),
					array( 'number' => '06', 'title' => __( 'Pronto per Google e per le ricerche AI', 'ticinoweb-child-theme' ), 'text' => __( 'Struttura SEO, dati strutturati e domande frequenti per farsi trovare da chi cerca una pizza.', 'ticinoweb-child-theme' ) ),
				),
				'features_title'   => __( 'Può crescere con te', 'ticinoweb-child-theme' ),
				'features'         => array(
					array( 'title' => __( 'App per iPhone e Android', 'ticinoweb-child-theme' ), 'text' => __( 'Un’app dedicata con account, indirizzi salvati, storico e ordine ripetibile in pochi tocchi, come per Mache Pizza e Mr Joe & Da Mè.', 'ticinoweb-child-theme' ) ),
					array( 'title' => __( 'Punti e preferiti', 'ticinoweb-child-theme' ), 'text' => __( 'Programmi fedeltà, piatti preferiti e storico ordini per far tornare i clienti.', 'ticinoweb-child-theme' ) ),
					array( 'title' => __( 'Più sedi, un solo sistema', 'ticinoweb-child-theme' ), 'text' => __( 'Più locali in un unico sito o app, con scelta della sede.', 'ticinoweb-child-theme' ) ),
					array( 'title' => __( 'Notifiche', 'ticinoweb-child-theme' ), 'text' => __( 'Novità e promozioni direttamente sul telefono dei clienti che usano l’app.', 'ticinoweb-child-theme' ) ),
					array( 'title' => __( 'Gestionale e cassa', 'ticinoweb-child-theme' ), 'text' => __( 'Collegamento con gestionale e sistemi di cassa valutato sul caso reale.', 'ticinoweb-child-theme' ) ),
				),
				'process_title'    => __( 'Come lavoriamo', 'ticinoweb-child-theme' ),
				'process'          => $common_process,
				'extras_title'     => __( 'Una piattaforma che può evolvere', 'ticinoweb-child-theme' ),
				'extras_text'      => __( 'Campagne su Google, social e video del tuo menu possono accompagnare la crescita del servizio di consegna.', 'ticinoweb-child-theme' ),
				'show_faq'         => '1',
				'final_cta_title'  => __( 'Portiamo online la tua cucina.', 'ticinoweb-child-theme' ),
				'final_cta_text'   => __( 'Ci racconti menu, zone di consegna e come lavori: ti proponiamo la soluzione giusta.', 'ticinoweb-child-theme' ),
				'final_cta_button' => __( 'Parliamone', 'ticinoweb-child-theme' ),
			)
		),
	);
}

/** Link a un caso cliente (articolo) per slug; nel testo di una pagina servizio. */
function tw_web_services_case_link( $slug, $label ) {
	$post = get_page_by_path( $slug, OBJECT, 'post' );
	$url  = $post ? get_permalink( $post ) : home_url( '/' . $slug . '/' );
	return '<a href="' . esc_url( $url ) . '">' . esc_html( $label ) . '</a>';
}

/**
 * Sanitize a generic structured repeater.
 */
function tw_web_services_sanitize_rows( $rows ) {
	$clean = array();
	foreach ( (array) $rows as $row ) {
		$row = (array) $row;
		$title = sanitize_text_field( $row['title'] ?? '' );
		$text  = wp_kses_post( $row['text'] ?? '' );
		if ( '' === $title && '' === trim( wp_strip_all_tags( $text ) ) ) {
			continue;
		}
		$clean[] = array(
			'number' => sanitize_text_field( $row['number'] ?? '' ),
			'title'  => $title,
			'text'   => $text,
			'icon'   => sanitize_text_field( $row['icon'] ?? '' ),
			'url'    => sanitize_title( $row['url'] ?? '' ),
		);
	}
	return $clean;
}

/**
 * Find the service key from a page ID or slug.
 */
function tw_web_services_page_key( $post = null ) {
	if ( is_numeric( $post ) ) {
		$post = get_post( absint( $post ) );
	}
	if ( ! $post && function_exists( 'get_queried_object' ) ) {
		$post = get_queried_object();
	}
	$slug = is_object( $post ) ? (string) ( $post->post_name ?? '' ) : '';
	foreach ( tw_web_services_page_definitions() as $key => $definition ) {
		if ( $slug === $definition['slug'] ) {
			return $key;
		}
	}
	if ( is_object( $post ) && ! empty( $post->ID ) && function_exists( 'get_post_meta' ) ) {
		$stored_key = sanitize_key( (string) get_post_meta( $post->ID, TW_WEB_SERVICE_TYPE_META, true ) );
		if ( isset( tw_web_services_page_definitions()[ $stored_key ] ) ) {
			return $stored_key;
		}
	}
	return '';
}

/**
 * Return saved content. Initial content is only a safety net before migration.
 */
function tw_web_services_get_data( $post_id = 0 ) {
	$post_id = $post_id ?: get_queried_object_id();
	$key     = tw_web_services_page_key( $post_id );
	$initial = tw_web_services_initial_content();
	$saved   = $post_id ? get_post_meta( $post_id, TW_WEB_SERVICE_META, true ) : array();
	return tw_web_services_normalize_data( is_array( $saved ) ? $saved : array(), $initial[ $key ] ?? array() );
}

/**
 * Merge saved content with safe defaults and fold the legacy Extras group into
 * the single Growth group without altering the stored record automatically.
 */
function tw_web_services_normalize_data( $saved, $fallback = array() ) {
	$saved    = is_array( $saved ) ? $saved : array();
	$fallback = is_array( $fallback ) ? $fallback : array();
	$data     = array_merge( $fallback, $saved );

	if ( ! array_key_exists( 'show_growth', $saved ) ) {
		$data['show_growth'] = ( '1' === ( $data['show_features'] ?? '0' ) || '1' === ( $data['show_extras'] ?? '0' ) ) ? '1' : '0';
	}

	$growth_rows  = array();
	$seen         = array();
	$legacy_extra = '1' === ( $data['legacy_extras_consumed'] ?? '0' ) ? array() : (array) ( $data['extras'] ?? array() );
	foreach ( array_merge( (array) ( $data['features'] ?? array() ), $legacy_extra ) as $row ) {
		if ( ! is_array( $row ) ) {
			continue;
		}
		$fingerprint = strtolower( trim( (string) ( $row['title'] ?? '' ) ) . '|' . trim( wp_strip_all_tags( (string) ( $row['text'] ?? '' ) ) ) );
		if ( '|' === $fingerprint || isset( $seen[ $fingerprint ] ) ) {
			continue;
		}
		$seen[ $fingerprint ] = true;
		$growth_rows[]        = $row;
	}
	$data['features'] = $growth_rows;

	return $data;
}

/**
 * Resolve links to page family members without hardcoded hosts.
 */
function tw_web_services_url( $key ) {
	$definitions = tw_web_services_page_definitions();
	$definition  = $definitions[ $key ] ?? null;
	if ( ! $definition ) {
		return home_url( '/' );
	}
	$page = get_page_by_path( $definition['slug'] );
	return $page ? get_permalink( $page ) : home_url( '/' . $definition['slug'] . '/' );
}

/**
 * Curated navigation model: exactly three website types.
 */
function tw_web_services_navigation_items() {
	$items = array();
	$initial = tw_web_services_initial_content();
	foreach ( array( 'one-page', 'aziendale-premium', 'ecommerce', 'food-delivery' ) as $key ) {
		$definition = tw_web_services_page_definitions()[ $key ];
		$page       = get_page_by_path( $definition['slug'] );
		$data       = $page ? tw_web_services_get_data( $page->ID ) : ( $initial[ $key ] ?? array() );
		$items[]    = (object) array(
			'ID'          => $page ? $page->ID : 0,
			'title'       => $definition['title'],
			'url'         => $page ? get_permalink( $page ) : home_url( '/' . $definition['slug'] . '/' ),
			'description' => $data['hero_text'] ?? '',
		);
	}
	return $items;
}

/**
 * Detect pages served by the new commercial family.
 */
function tw_web_services_is_page() {
	if ( ! function_exists( 'is_page' ) || ! is_page() ) {
		return false;
	}
	if ( tw_web_services_page_key() ) {
		return true;
	}
	return function_exists( 'is_page_template' ) && ( is_page_template( 'page-web-service.php' ) || is_page_template( 'page-siti-web.php' ) );
}

/**
 * Route the verified slugs to child-theme templates.
 */
function tw_web_services_template_include( $template ) {
	if ( ! tw_web_services_is_page() ) {
		return $template;
	}
	$key         = tw_web_services_page_key();
	$definitions = tw_web_services_page_definitions();
	$template_slug = function_exists( 'get_page_template_slug' ) ? get_page_template_slug( get_queried_object_id() ) : '';
	$template_file = $key && isset( $definitions[ $key ] ) ? $definitions[ $key ]['template'] : $template_slug;
	if ( ! in_array( $template_file, array( 'page-siti-web.php', 'page-web-service.php' ), true ) ) {
		return $template;
	}
	$candidate = get_stylesheet_directory() . '/' . $template_file;
	return file_exists( $candidate ) ? $candidate : $template;
}
add_filter( 'template_include', 'tw_web_services_template_include', 97 );

/**
 * Register one structured meta value for translations and the block editor.
 */
function tw_web_services_register_meta() {
	register_post_meta(
		'page',
		TW_WEB_SERVICE_META,
		array(
			'type'              => 'object',
			'single'            => true,
			'show_in_rest'      => false,
			'sanitize_callback' => 'tw_web_services_sanitize_data',
			'auth_callback'     => static fn() => current_user_can( 'edit_pages' ),
		)
	);
}
add_action( 'init', 'tw_web_services_register_meta', 30 );

/**
 * Sanitize the complete controlled page payload.
 */
function tw_web_services_sanitize_data( $raw ) {
	$raw = (array) $raw;
	$clean = array();
	$text_fields = array(
		'hero_eyebrow', 'hero_title', 'hero_cta_text', 'intro_title', 'audience_title', 'includes_title',
		'features_title', 'process_title', 'extras_title', 'final_cta_title', 'final_cta_button', 'portfolio_link_text',
	);
	$textarea_fields = array( 'hero_text', 'intro_text', 'extras_text', 'final_cta_text' );
	$url_fields = array( 'hero_cta_url', 'final_cta_url' );
	$toggle_fields = array( 'show_intro', 'show_audience', 'show_includes', 'show_features', 'show_process', 'show_extras', 'show_growth', 'show_faq', 'show_final_cta' );
	$row_fields = array( 'overview_types', 'audience', 'includes', 'features', 'process', 'extras' );
	foreach ( $text_fields as $field ) $clean[ $field ] = sanitize_text_field( $raw[ $field ] ?? '' );
	foreach ( $textarea_fields as $field ) $clean[ $field ] = wp_kses_post( $raw[ $field ] ?? '' );
	foreach ( $url_fields as $field ) $clean[ $field ] = esc_url_raw( $raw[ $field ] ?? '' );
	foreach ( $toggle_fields as $field ) $clean[ $field ] = empty( $raw[ $field ] ) ? '0' : '1';
	foreach ( $row_fields as $field ) $clean[ $field ] = tw_web_services_sanitize_rows( $raw[ $field ] ?? array() );
	foreach ( array( 'hero_media_id', 'intro_media_id', 'includes_media_id', 'growth_media_id', 'method_media_id' ) as $media_field ) {
		$clean[ $media_field ] = absint( $raw[ $media_field ] ?? 0 );
	}
	$clean['faq_set_id'] = absint( $raw['faq_set_id'] ?? 0 );
	return $clean;
}

/**
 * Keep hidden legacy values until an explicit migration removes them.
 * The frontend folds these rows into Growth, but the original record remains
 * recoverable and translations do not lose fields on their first save.
 */
function tw_web_services_preserve_legacy_data( $clean, $existing ) {
	$clean    = is_array( $clean ) ? $clean : array();
	$existing = is_array( $existing ) ? $existing : array();
	if ( array_key_exists( 'extras_title', $existing ) ) {
		$clean['extras_title'] = sanitize_text_field( $existing['extras_title'] );
	}
	if ( array_key_exists( 'extras', $existing ) ) {
		$clean['extras'] = tw_web_services_sanitize_rows( $existing['extras'] );
		$clean['legacy_extras_consumed'] = '1';
	}
	foreach ( array( 'show_features', 'show_extras' ) as $legacy_toggle ) {
		if ( array_key_exists( $legacy_toggle, $existing ) ) {
			$clean[ $legacy_toggle ] = empty( $existing[ $legacy_toggle ] ) ? '0' : '1';
		}
	}
	return $clean;
}

/**
 * Limit the meta box to the controlled family.
 */
function tw_web_services_add_meta_box( $post ) {
	if ( ! tw_web_services_page_key( $post ) && ! in_array( get_page_template_slug( $post ), array( 'page-siti-web.php', 'page-web-service.php' ), true ) ) {
		return;
	}
	add_meta_box( 'tw_web_service_content', __( 'Contenuti pagina Siti Web', 'ticinoweb-child-theme' ), 'tw_web_services_render_meta_box', 'page', 'normal', 'high' );
}
add_action( 'add_meta_boxes_page', 'tw_web_services_add_meta_box' );

/**
 * Render one repeater inside the controlled meta box.
 */
function tw_web_services_admin_repeater( $key, $label, $rows ) {
	?>
	<div class="tw-ws-repeater" data-tw-ws-repeater="<?php echo esc_attr( $key ); ?>">
		<h4><?php echo esc_html( $label ); ?></h4>
		<div data-tw-ws-rows>
			<?php foreach ( (array) $rows as $index => $row ) : ?>
				<div class="tw-ws-row" data-tw-ws-row>
					<input type="text" name="tw_web_service[<?php echo esc_attr( $key ); ?>][<?php echo esc_attr( (string) $index ); ?>][number]" value="<?php echo esc_attr( $row['number'] ?? '' ); ?>" placeholder="<?php esc_attr_e( 'Numero', 'ticinoweb-child-theme' ); ?>">
					<input type="text" name="tw_web_service[<?php echo esc_attr( $key ); ?>][<?php echo esc_attr( (string) $index ); ?>][title]" value="<?php echo esc_attr( $row['title'] ?? '' ); ?>" placeholder="<?php esc_attr_e( 'Titolo', 'ticinoweb-child-theme' ); ?>">
					<textarea name="tw_web_service[<?php echo esc_attr( $key ); ?>][<?php echo esc_attr( (string) $index ); ?>][text]" rows="2" placeholder="<?php esc_attr_e( 'Descrizione', 'ticinoweb-child-theme' ); ?>"><?php echo esc_textarea( $row['text'] ?? '' ); ?></textarea>
					<input type="text" name="tw_web_service[<?php echo esc_attr( $key ); ?>][<?php echo esc_attr( (string) $index ); ?>][icon]" value="<?php echo esc_attr( $row['icon'] ?? '' ); ?>" placeholder="<?php esc_attr_e( 'Icona (opzionale)', 'ticinoweb-child-theme' ); ?>">
					<input type="text" name="tw_web_service[<?php echo esc_attr( $key ); ?>][<?php echo esc_attr( (string) $index ); ?>][url]" value="<?php echo esc_attr( $row['url'] ?? '' ); ?>" placeholder="<?php esc_attr_e( 'Slug collegato (opzionale)', 'ticinoweb-child-theme' ); ?>">
					<button type="button" class="button-link-delete" data-tw-ws-remove><?php esc_html_e( 'Rimuovi', 'ticinoweb-child-theme' ); ?></button>
				</div>
			<?php endforeach; ?>
		</div>
		<button type="button" class="button" data-tw-ws-add><?php esc_html_e( 'Aggiungi voce', 'ticinoweb-child-theme' ); ?></button>
	</div>
	<?php
}

/**
 * Render the structured page editor.
 */
function tw_web_services_render_meta_box( $post ) {
	$data = tw_web_services_get_data( $post->ID );
	$key  = tw_web_services_page_key( $post );
	wp_nonce_field( 'tw_web_service_save', 'tw_web_service_nonce' );
	$toggle = static function ( $name, $label ) use ( $data ) {
		printf( '<label class="tw-ws-toggle"><input type="checkbox" name="tw_web_service[%1$s]" value="1"%2$s> %3$s</label>', esc_attr( $name ), checked( '1', $data[ $name ] ?? '0', false ), esc_html( $label ) );
	};
	$field = static function ( $name, $label, $textarea = false ) use ( $data ) {
		echo '<label class="tw-ws-field"><strong>' . esc_html( $label ) . '</strong>';
		if ( $textarea ) {
			printf( '<textarea name="tw_web_service[%1$s]" rows="3">%2$s</textarea>', esc_attr( $name ), esc_textarea( $data[ $name ] ?? '' ) );
		} else {
			printf( '<input type="text" name="tw_web_service[%1$s]" value="%2$s">', esc_attr( $name ), esc_attr( $data[ $name ] ?? '' ) );
		}
		echo '</label>';
	};
	$media = static function ( $name, $label ) use ( $data ) {
		$attachment_id = absint( $data[ $name ] ?? 0 );
		$mime_type     = $attachment_id ? (string) get_post_mime_type( $attachment_id ) : '';
		$filename      = $attachment_id ? basename( (string) get_attached_file( $attachment_id ) ) : '';
		?>
		<label class="tw-ws-field tw-ws-field--media">
			<strong><?php echo esc_html( $label ); ?></strong>
			<span class="tw-ws-media" data-tw-ws-media-field>
				<input type="hidden" name="tw_web_service[<?php echo esc_attr( $name ); ?>]" value="<?php echo esc_attr( (string) $attachment_id ); ?>" data-tw-ws-media-id>
				<span class="tw-ws-media__preview" data-tw-ws-media-preview>
					<?php if ( $attachment_id && 0 === strpos( $mime_type, 'image/' ) ) : ?>
						<?php echo wp_get_attachment_image( $attachment_id, 'thumbnail', false, array( 'alt' => '' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
					<?php elseif ( $attachment_id ) : ?>
						<span><?php echo esc_html( $filename ); ?></span>
					<?php else : ?>
						<span><?php esc_html_e( 'Nessun media selezionato', 'ticinoweb-child-theme' ); ?></span>
					<?php endif; ?>
				</span>
				<span class="tw-ws-media__actions"><button type="button" class="button" data-tw-ws-media><?php esc_html_e( 'Scegli dalla Libreria Media', 'ticinoweb-child-theme' ); ?></button><button type="button" class="button-link-delete" data-tw-ws-media-clear><?php esc_html_e( 'Rimuovi', 'ticinoweb-child-theme' ); ?></button></span>
			</span>
		</label>
		<?php
	};
	?>
	<div class="tw-ws-admin" data-tw-ws-admin>
		<p><?php esc_html_e( 'Struttura controllata: modifica testi e voci senza cambiare il layout della pagina.', 'ticinoweb-child-theme' ); ?></p>
		<details open><summary><?php esc_html_e( 'Hero', 'ticinoweb-child-theme' ); ?></summary><div class="tw-ws-fields">
			<?php $field( 'hero_eyebrow', __( 'Eyebrow', 'ticinoweb-child-theme' ) ); $field( 'hero_title', __( 'Titolo H1', 'ticinoweb-child-theme' ) ); $field( 'hero_text', __( 'Descrizione', 'ticinoweb-child-theme' ), true ); $field( 'hero_cta_text', __( 'Testo CTA', 'ticinoweb-child-theme' ) ); $field( 'hero_cta_url', __( 'URL CTA (vuoto = Contatti)', 'ticinoweb-child-theme' ) ); ?>
			<?php $media( 'hero_media_id', __( 'Hero Media', 'ticinoweb-child-theme' ) ); ?>
		</div></details>
		<?php if ( 'siti-web' === $key ) : ?>
			<details><summary><?php esc_html_e( 'Introduzione', 'ticinoweb-child-theme' ); ?></summary><?php $toggle( 'show_intro', __( 'Mostra sezione', 'ticinoweb-child-theme' ) ); ?><div class="tw-ws-fields"><?php $field( 'intro_title', __( 'Titolo', 'ticinoweb-child-theme' ) ); $field( 'intro_text', __( 'Testo', 'ticinoweb-child-theme' ), true ); ?></div></details>
			<details><summary><?php esc_html_e( 'Tipologie mostrate', 'ticinoweb-child-theme' ); ?></summary><?php tw_web_services_admin_repeater( 'overview_types', __( 'One-Page, Aziendale Premium, eCommerce', 'ticinoweb-child-theme' ), $data['overview_types'] ?? array() ); ?></details>
		<?php else : ?>
			<details><summary><?php esc_html_e( 'Introduzione e destinatari', 'ticinoweb-child-theme' ); ?></summary><?php $toggle( 'show_intro', __( 'Mostra introduzione', 'ticinoweb-child-theme' ) ); $toggle( 'show_audience', __( 'Mostra destinatari', 'ticinoweb-child-theme' ) ); ?><div class="tw-ws-fields"><?php $field( 'intro_title', __( 'Titolo introduzione', 'ticinoweb-child-theme' ) ); $field( 'intro_text', __( 'Testo introduzione', 'ticinoweb-child-theme' ), true ); $field( 'audience_title', __( 'Titolo destinatari', 'ticinoweb-child-theme' ) ); $media( 'intro_media_id', __( 'Media Introduzione (opzionale)', 'ticinoweb-child-theme' ) ); ?></div><?php tw_web_services_admin_repeater( 'audience', __( 'Destinatari', 'ticinoweb-child-theme' ), $data['audience'] ?? array() ); ?></details>
			<details><summary><?php esc_html_e( 'Cosa include', 'ticinoweb-child-theme' ); ?></summary><?php $toggle( 'show_includes', __( 'Mostra sezione', 'ticinoweb-child-theme' ) ); ?><div class="tw-ws-fields"><?php $field( 'includes_title', __( 'Titolo sezione', 'ticinoweb-child-theme' ) ); $media( 'includes_media_id', __( 'Media Cosa Include (opzionale)', 'ticinoweb-child-theme' ) ); ?></div><?php tw_web_services_admin_repeater( 'includes', __( 'Elementi inclusi', 'ticinoweb-child-theme' ), $data['includes'] ?? array() ); ?></details>
			<details><summary><?php esc_html_e( 'Crescita e possibilità', 'ticinoweb-child-theme' ); ?></summary><?php $toggle( 'show_growth', __( 'Mostra sezione', 'ticinoweb-child-theme' ) ); ?><div class="tw-ws-fields"><?php $field( 'features_title', __( 'Titolo sezione', 'ticinoweb-child-theme' ) ); $field( 'extras_text', __( 'Testo introduttivo', 'ticinoweb-child-theme' ), true ); $media( 'growth_media_id', __( 'Media Crescita / Possibilità (opzionale)', 'ticinoweb-child-theme' ) ); ?></div><?php tw_web_services_admin_repeater( 'features', __( 'Estensioni / possibilità', 'ticinoweb-child-theme' ), $data['features'] ?? array() ); ?></details>
			<details><summary><?php esc_html_e( 'Metodo', 'ticinoweb-child-theme' ); ?></summary><?php $toggle( 'show_process', __( 'Mostra sezione', 'ticinoweb-child-theme' ) ); ?><div class="tw-ws-fields"><?php $field( 'process_title', __( 'Titolo sezione', 'ticinoweb-child-theme' ) ); $media( 'method_media_id', __( 'Media Metodo (opzionale)', 'ticinoweb-child-theme' ) ); ?></div><?php tw_web_services_admin_repeater( 'process', __( 'Fasi', 'ticinoweb-child-theme' ), $data['process'] ?? array() ); ?></details>
			<details><summary><?php esc_html_e( 'FAQ', 'ticinoweb-child-theme' ); ?></summary><?php $toggle( 'show_faq', __( 'Mostra sezione', 'ticinoweb-child-theme' ) ); ?><label class="tw-ws-field"><strong><?php esc_html_e( 'Scheda FAQ esistente', 'ticinoweb-child-theme' ); ?></strong><select name="tw_web_service[faq_set_id]"><option value="0"><?php esc_html_e( 'Nessuna', 'ticinoweb-child-theme' ); ?></option><?php foreach ( function_exists( 'ticinoweb_faq_choices' ) ? ticinoweb_faq_choices() : array() as $id => $label ) : ?><option value="<?php echo esc_attr( (string) $id ); ?>"<?php selected( (int) ( $data['faq_set_id'] ?? 0 ), (int) $id ); ?>><?php echo esc_html( $label ); ?></option><?php endforeach; ?></select></label></details>
		<?php endif; ?>
		<details><summary><?php esc_html_e( 'CTA finale', 'ticinoweb-child-theme' ); ?></summary><?php $toggle( 'show_final_cta', __( 'Mostra sezione', 'ticinoweb-child-theme' ) ); ?><div class="tw-ws-fields"><?php $field( 'final_cta_title', __( 'Titolo', 'ticinoweb-child-theme' ) ); $field( 'final_cta_text', __( 'Testo', 'ticinoweb-child-theme' ), true ); $field( 'final_cta_button', __( 'Testo bottone', 'ticinoweb-child-theme' ) ); $field( 'final_cta_url', __( 'URL (vuoto = Contatti)', 'ticinoweb-child-theme' ) ); $field( 'portfolio_link_text', __( 'Link testuale al portfolio (opzionale)', 'ticinoweb-child-theme' ) ); ?></div></details>
	</div>
	<?php
}

/**
 * Save page data with standard WordPress protections.
 */
function tw_web_services_save_meta( $post_id, $post ) {
	if ( ! isset( $_POST['tw_web_service_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['tw_web_service_nonce'] ) ), 'tw_web_service_save' ) ) {
		return;
	}
	if ( ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) || wp_is_post_revision( $post_id ) || ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}
	$raw      = isset( $_POST['tw_web_service'] ) && is_array( $_POST['tw_web_service'] ) ? wp_unslash( $_POST['tw_web_service'] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
	$existing = get_post_meta( $post_id, TW_WEB_SERVICE_META, true );
	$clean    = tw_web_services_preserve_legacy_data( tw_web_services_sanitize_data( $raw ), $existing );
	update_post_meta( $post_id, TW_WEB_SERVICE_META, $clean );
	$service_key = tw_web_services_page_key( $post );
	if ( $service_key ) {
		update_post_meta( $post_id, TW_WEB_SERVICE_TYPE_META, $service_key );
	}
}
add_action( 'save_post_page', 'tw_web_services_save_meta', 10, 2 );

/**
 * Admin assets only for this page family.
 */
function tw_web_services_admin_assets( $hook ) {
	if ( ! in_array( $hook, array( 'post.php', 'post-new.php' ), true ) ) return;
	$screen = get_current_screen();
	if ( ! $screen || 'page' !== $screen->post_type ) return;
	$post_id = isset( $_GET['post'] ) ? absint( wp_unslash( $_GET['post'] ) ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	$post    = $post_id ? get_post( $post_id ) : null;
	if ( ! $post || ( ! tw_web_services_page_key( $post ) && ! in_array( get_page_template_slug( $post ), array( 'page-siti-web.php', 'page-web-service.php' ), true ) ) ) {
		return;
	}
	wp_enqueue_media();
	wp_enqueue_style( 'tw-web-services-admin', get_stylesheet_directory_uri() . '/assets/css/web-services-admin.css', array(), wp_get_theme()->get( 'Version' ) );
	wp_enqueue_script( 'tw-web-services-admin', get_stylesheet_directory_uri() . '/assets/js/web-services-admin.js', array(), wp_get_theme()->get( 'Version' ), true );
	wp_localize_script(
		'tw-web-services-admin',
		'twWebServicesAdmin',
		array(
			'number'        => __( 'Numero', 'ticinoweb-child-theme' ),
			'title'         => __( 'Titolo', 'ticinoweb-child-theme' ),
			'description'   => __( 'Descrizione', 'ticinoweb-child-theme' ),
			'icon'          => __( 'Icona (opzionale)', 'ticinoweb-child-theme' ),
			'url'           => __( 'Slug collegato (opzionale)', 'ticinoweb-child-theme' ),
			'remove'        => __( 'Rimuovi', 'ticinoweb-child-theme' ),
			'mediaTitle'    => __( 'Scegli immagine o video', 'ticinoweb-child-theme' ),
			'mediaSelected' => __( 'Media selezionato', 'ticinoweb-child-theme' ),
			'mediaEmpty'    => __( 'Nessun media selezionato', 'ticinoweb-child-theme' ),
		)
	);
}
add_action( 'admin_enqueue_scripts', 'tw_web_services_admin_assets' );

/**
 * Render an administrator-selected image or video with responsive defaults.
 */
function tw_web_services_render_media( $attachment_id, $context = 'section', $priority = false ) {
	$attachment_id = absint( $attachment_id );
	if ( ! $attachment_id ) {
		return;
	}
	$mime_type = (string) get_post_mime_type( $attachment_id );
	$class     = 'tw-web-media tw-web-media--' . sanitize_html_class( $context );
	if ( 0 === strpos( $mime_type, 'video/' ) ) {
		$url = wp_get_attachment_url( $attachment_id );
		if ( ! $url ) {
			return;
		}
		$video_preload = $priority ? 'metadata' : 'none';
		$video_mode    = $priority ? 'hero' : 'viewport';
		?>
		<figure class="<?php echo esc_attr( $class ); ?>">
			<video muted loop playsinline preload="<?php echo esc_attr( $video_preload ); ?>" data-tw-web-video="<?php echo esc_attr( $video_mode ); ?>">
				<source src="<?php echo esc_url( $url ); ?>" type="<?php echo esc_attr( $mime_type ); ?>">
			</video>
		</figure>
		<?php
		return;
	}
	if ( 0 !== strpos( $mime_type, 'image/' ) ) {
		return;
	}
	$attributes = array(
		'class'    => 'tw-web-media__image',
		'decoding' => 'async',
		'loading'  => $priority ? 'eager' : 'lazy',
		'sizes'    => '(max-width: 900px) 100vw, 44vw',
	);
	if ( $priority ) {
		$attributes['fetchpriority'] = 'high';
	}
	?>
	<figure class="<?php echo esc_attr( $class ); ?>">
		<?php echo wp_get_attachment_image( $attachment_id, 'large', false, $attributes ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
	</figure>
	<?php
}

/**
 * Render a numbered editorial list shared by all sections.
 */
function tw_web_services_render_rows( $rows, $class = '' ) {
	if ( ! $rows ) return;
	?>
	<div class="tw-web-rows <?php echo esc_attr( $class ); ?>">
		<?php foreach ( $rows as $index => $row ) : ?>
			<div class="tw-web-row">
				<span><?php echo esc_html( $row['number'] ?: str_pad( (string) ( $index + 1 ), 2, '0', STR_PAD_LEFT ) ); ?></span>
				<h3><?php echo esc_html( $row['title'] ); ?></h3>
				<div><?php echo wp_kses_post( wpautop( $row['text'] ) ); ?></div>
			</div>
		<?php endforeach; ?>
	</div>
	<?php
}

/**
 * Local-only initializer. It never runs automatically and is not exposed on
 * production hosts. Existing page content and SEO metadata are preserved.
 */
function tw_web_services_is_local_environment() {
	if ( ! function_exists( 'home_url' ) || ! function_exists( 'wp_parse_url' ) ) return false;
	$host = strtolower( (string) wp_parse_url( home_url( '/' ), PHP_URL_HOST ) );
	return in_array( $host, array( 'localhost', '127.0.0.1', '::1' ), true );
}

/**
 * Back up and initialize the four local commercial pages.
 */
function tw_web_services_initialize_pages() {
	if ( ! tw_web_services_is_local_environment() ) {
		return new WP_Error( 'not_local', __( 'Inizializzazione disponibile solamente nell’ambiente locale.', 'ticinoweb-child-theme' ) );
	}
	$definitions = tw_web_services_page_definitions();
	$initial     = tw_web_services_initial_content();
	$backup      = array();
	$pages       = array();

	foreach ( $definitions as $key => $definition ) {
		$page = get_page_by_path( $definition['slug'], OBJECT, 'page' );
		if ( $page ) {
			$backup[] = array(
				'ID'           => $page->ID,
				'post_name'    => $page->post_name,
				'post_title'   => $page->post_title,
				'post_content' => $page->post_content,
				'template'     => get_post_meta( $page->ID, '_wp_page_template', true ),
				'service_meta' => get_post_meta( $page->ID, TW_WEB_SERVICE_META, true ),
			);
		}
	}

	$upload_dir = wp_upload_dir();
	$backup_dir = trailingslashit( $upload_dir['basedir'] ) . 'tw-web-services-backups';
	if ( ! wp_mkdir_p( $backup_dir ) ) {
		return new WP_Error( 'backup_directory_failed', __( 'Impossibile creare la cartella locale dei backup.', 'ticinoweb-child-theme' ) );
	}
	$backup_file = trailingslashit( $backup_dir ) . 'tw-web-services-backup-' . current_time( 'Ymd-His' ) . '.json';
	$backup_json = wp_json_encode( $backup, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );
	if ( false === $backup_json || false === file_put_contents( $backup_file, $backup_json, LOCK_EX ) ) { // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
		return new WP_Error( 'backup_failed', __( 'Impossibile salvare il backup locale delle pagine.', 'ticinoweb-child-theme' ) );
	}

	foreach ( $definitions as $key => $definition ) {
		$page = get_page_by_path( $definition['slug'], OBJECT, 'page' );
		if ( $page ) {
			$page_id = $page->ID;
		} else {
			$page_id = wp_insert_post(
				array(
					'post_type'    => 'page',
					'post_status'  => 'publish',
					'post_title'   => $definition['title'],
					'post_name'    => $definition['slug'],
					'post_content' => '',
				),
				true
			);
			if ( is_wp_error( $page_id ) ) return $page_id;
		}
		update_post_meta( $page_id, '_wp_page_template', $definition['template'] );
		update_post_meta( $page_id, TW_WEB_SERVICE_TYPE_META, $key );
		update_post_meta( $page_id, TW_WEB_SERVICE_META, tw_web_services_sanitize_data( $initial[ $key ] ) );
		$pages[ $key ] = array( 'id' => (int) $page_id, 'url' => get_permalink( $page_id ) );
	}

	return array( 'pages' => $pages, 'backup' => $backup_file );
}

/**
 * Register the explicit local maintenance action.
 */
function tw_web_services_register_local_tool() {
	if ( ! tw_web_services_is_local_environment() ) return;
	add_management_page(
		__( 'Inizializza area Siti Web', 'ticinoweb-child-theme' ),
		__( 'Area Siti Web', 'ticinoweb-child-theme' ),
		'manage_options',
		'tw-web-services-init',
		'tw_web_services_render_local_tool'
	);
}
add_action( 'admin_menu', 'tw_web_services_register_local_tool' );

/**
 * Render the local initializer screen.
 */
function tw_web_services_render_local_tool() {
	if ( ! current_user_can( 'manage_options' ) ) return;
	?>
	<div class="wrap"><h1><?php esc_html_e( 'Area Siti Web', 'ticinoweb-child-theme' ); ?></h1>
		<?php if ( isset( $_GET['tw_initialized'] ) ) : // phpcs:ignore WordPress.Security.NonceVerification.Recommended ?><div class="notice notice-success"><p><?php esc_html_e( 'Le quattro pagine sono state collegate ai nuovi template e compilate. Il backup è stato salvato negli upload locali.', 'ticinoweb-child-theme' ); ?></p></div><?php endif; ?>
		<p><?php esc_html_e( 'Questa azione locale crea le pagine mancanti, conserva i contenuti esistenti nel backup e compila i campi strutturati.', 'ticinoweb-child-theme' ); ?></p>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"><?php wp_nonce_field( 'tw_web_services_initialize', 'tw_web_services_initialize_nonce' ); ?><input type="hidden" name="action" value="tw_web_services_initialize"><button class="button button-primary" type="submit"><?php esc_html_e( 'Inizializza e collega le pagine', 'ticinoweb-child-theme' ); ?></button></form>
	</div>
	<?php
}

/**
 * Handle the administrator-confirmed local write.
 */
function tw_web_services_handle_initialize() {
	if ( ! current_user_can( 'manage_options' ) ) wp_die( esc_html__( 'Permessi insufficienti.', 'ticinoweb-child-theme' ) );
	check_admin_referer( 'tw_web_services_initialize', 'tw_web_services_initialize_nonce' );
	$result = tw_web_services_initialize_pages();
	if ( is_wp_error( $result ) ) wp_die( esc_html( $result->get_error_message() ) );
	wp_safe_redirect( add_query_arg( 'tw_initialized', '1', admin_url( 'tools.php?page=tw-web-services-init' ) ) );
	exit;
}
add_action( 'admin_post_tw_web_services_initialize', 'tw_web_services_handle_initialize' );
