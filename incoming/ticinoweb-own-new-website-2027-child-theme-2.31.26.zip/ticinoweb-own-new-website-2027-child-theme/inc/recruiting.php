<?php
/** Page-owned recruiting content. Applications remain on the official external portal. */
if (!defined('ABSPATH')) exit;

function tw_recruiting_fields() {
 return [
 'hero_eyebrow'=>__('Hero — Sopratitolo','ticinoweb-child-theme'), 'hero_title'=>__('Hero — Titolo','ticinoweb-child-theme'), 'hero_text'=>__('Hero — Descrizione','ticinoweb-child-theme'), 'hero_cta'=>__('Hero — Pulsante posizioni','ticinoweb-child-theme'),
 'values_eyebrow'=>__('Metodo — Sopratitolo','ticinoweb-child-theme'), 'values_title'=>__('Metodo — Titolo','ticinoweb-child-theme'), 'areas_title'=>__('Aree — Titolo','ticinoweb-child-theme'), 'areas_text'=>__('Aree — Introduzione','ticinoweb-child-theme'),
 'positions_title'=>__('Posizioni — Titolo','ticinoweb-child-theme'), 'positions_text'=>__('Posizioni — Introduzione','ticinoweb-child-theme'), 'portal_url'=>__('URL portale recruiting','ticinoweb-child-theme'), 'portal_notice'=>__('Portale — Modalità candidatura','ticinoweb-child-theme'), 'portal_cta'=>__('Portale — Pulsante','ticinoweb-child-theme'),
 'empty_title'=>__('Nessuna posizione — Titolo','ticinoweb-child-theme'), 'empty_text'=>__('Nessuna posizione — Descrizione','ticinoweb-child-theme'),
 'process_title'=>__('Candidatura — Titolo','ticinoweb-child-theme'), 'note_title'=>__('Informazioni esistenti — Titolo','ticinoweb-child-theme'), 'note_text'=>__('Informazioni esistenti — Testo','ticinoweb-child-theme'),
 'final_title'=>__('CTA finale — Titolo','ticinoweb-child-theme'), 'final_text'=>__('CTA finale — Descrizione','ticinoweb-child-theme'), 'final_cta'=>__('CTA finale — Pulsante portale','ticinoweb-child-theme') ];
}
function tw_recruiting_schema() {
 $common=['title'=>__('Titolo','ticinoweb-child-theme'),'text'=>__('Descrizione (opzionale)','ticinoweb-child-theme')];
 return ['values'=>['label'=>__('Valori del lavoro','ticinoweb-child-theme'),'fields'=>['number'=>__('Numero','ticinoweb-child-theme')]+$common],
 'areas'=>['label'=>__('Aree professionali — non annunci','ticinoweb-child-theme'),'fields'=>['icon'=>__('Icona','ticinoweb-child-theme')]+$common],
 'positions'=>['label'=>__('Posizioni aperte','ticinoweb-child-theme'),'fields'=>['title'=>__('Titolo posizione','ticinoweb-child-theme'),'area'=>__('Area','ticinoweb-child-theme'),'location'=>__('Sede','ticinoweb-child-theme'),'employment'=>__('Percentuale / tipo impiego','ticinoweb-child-theme'),'text'=>__('Descrizione (opzionale)','ticinoweb-child-theme'),'url'=>__('URL candidatura (vuoto: portale generale)','ticinoweb-child-theme'),'status'=>__('Stato','ticinoweb-child-theme')]],
 'process'=>['label'=>__('Processo candidatura','ticinoweb-child-theme'),'fields'=>['number'=>__('Numero','ticinoweb-child-theme')]+$common]];
}
function tw_recruiting_url($url) {
 $url=esc_url_raw(is_scalar($url)?(string)$url:'',['https']);
 return wp_parse_url($url,PHP_URL_SCHEME)==='https' && !wp_parse_url($url,PHP_URL_USER) && !wp_parse_url($url,PHP_URL_PASS) ? $url : '';
}
function tw_recruiting_sanitize($raw) {
 $raw=is_array($raw)?$raw:[];$d=[];
 foreach(tw_recruiting_fields() as $key=>$label)$d[$key]=$key==='portal_url'?tw_recruiting_url($raw[$key]??''):sanitize_textarea_field(is_scalar($raw[$key]??'')?$raw[$key]??'':'');
 foreach(['hero_media_id','editorial_media_id'] as $key){$id=absint($raw[$key]??0);$d[$key]=wp_attachment_is_image($id)?$id:0;}
 foreach(tw_recruiting_schema() as $key=>$schema){$d[$key]=[];foreach((array)($raw[$key]??[]) as $row){if(!is_array($row)||!is_scalar($row['title']??null)||!trim($row['title']))continue;$clean=[];foreach($schema['fields'] as $field=>$label){$v=is_scalar($row[$field]??'')?(string)($row[$field]??''):'';$clean[$field]=$field==='url'?tw_recruiting_url($v):($field==='status'?($v==='open'?'open':'closed'):sanitize_textarea_field($v));}$d[$key][]=$clean;}}
 foreach($d['areas'] as &$area){if(!isset(tw_recruiting_icons()[$area['icon']??'']))$area['icon']='';}unset($area);
 return $d;
}
/** Read-only use of the parent's existing vector family. No arbitrary paths or SVG markup. */
function tw_recruiting_icons(){return [
 'design'=>['label'=>__('Design','ticinoweb-child-theme'),'file'=>'brush.svg'],
 'development'=>['label'=>__('Sviluppo','ticinoweb-child-theme'),'file'=>'code.svg'],
 'marketing'=>['label'=>__('Marketing','ticinoweb-child-theme'),'file'=>'performance.svg'],
 'content'=>['label'=>__('Contenuti','ticinoweb-child-theme'),'file'=>'send.svg'],
 'software'=>['label'=>__('Software','ticinoweb-child-theme'),'file'=>'gears.svg'],
 'video'=>['label'=>__('Video','ticinoweb-child-theme'),'file'=>'play.svg'],
 'sales'=>['label'=>__('Relazione clienti','ticinoweb-child-theme'),'file'=>'meeting.svg'],
 'administration'=>['label'=>__('Amministrazione','ticinoweb-child-theme'),'file'=>'document.svg'] ];}
function tw_recruiting_area_icon($key){
 $choice=tw_recruiting_icons()[$key]??null;if(!$choice)return;
 $url=get_template_directory_uri().'/assets/icons/Varie/'.$choice['file'];
 echo '<span class="tw-recruiting-area-icon" aria-hidden="true" style="--tw-recruiting-icon:url(\''.esc_url($url).'\')"></span>';
}
function tw_recruiting_data($id=0){$d=get_post_meta($id?:get_queried_object_id(),'_tw_recruiting_content',true);return is_array($d)?$d:[];}
function tw_recruiting_enabled($id=0){return get_post_meta($id?:get_queried_object_id(),'_tw_recruiting_enabled',true)==='1';}
function tw_recruiting_job_url($row,$d){
 $portal=tw_recruiting_url($d['portal_url']??'');$url=tw_recruiting_url($row['url']??'');
 return $url && $portal && strtolower((string)wp_parse_url($url,PHP_URL_HOST))===strtolower((string)wp_parse_url($portal,PHP_URL_HOST)) ? $url : $portal;
}
function tw_recruiting_open_positions($d){return array_values(array_filter((array)($d['positions']??[]),static fn($r)=>is_array($r)&&($r['status']??'')==='open'&&!empty($r['title'])));}
function tw_recruiting_save($id){
 if(empty($_POST['tw_recruiting_nonce'])||!is_scalar($_POST['tw_recruiting_nonce'])||!wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['tw_recruiting_nonce'])),'tw_recruiting_save')||!current_user_can('edit_post',$id)||wp_is_post_revision($id)||(defined('DOING_AUTOSAVE')&&DOING_AUTOSAVE))return;
 update_post_meta($id,'_tw_recruiting_content',tw_recruiting_sanitize(wp_unslash($_POST['tw_recruiting']??[])));
 update_post_meta($id,'_tw_recruiting_enabled',empty($_POST['tw_recruiting_enabled'])?'0':'1');
}
add_action('save_post_page','tw_recruiting_save');
add_filter('template_include',static fn($template)=>is_page()&&tw_recruiting_enabled()?get_stylesheet_directory().'/page-recruiting.php':$template,125);
add_action('wp_enqueue_scripts',static function(){if(is_page()&&tw_recruiting_enabled())wp_enqueue_style('tw-recruiting',get_stylesheet_directory_uri().'/assets/css/recruiting.css',['ticinoweb-child-site'],wp_get_theme()->get('Version'));},30);
add_action('add_meta_boxes',static function($type,$post){
 if($type!=='page'||!$post)return;
 $page=get_page_by_path('lavora-con-noi');
 if(!tw_recruiting_enabled($post->ID)&&(!$page||$page->ID!==$post->ID))return;
 remove_meta_box('tw-service-system','page','normal');
 add_meta_box('tw-recruiting',__('Contenuti Lavora con noi','ticinoweb-child-theme'),'tw_recruiting_metabox','page','normal','high');
},30,2);
function tw_recruiting_control($name,$label,$value,$type='text'){
 echo '<label style="display:block;margin-block:12px"><strong>'.esc_html($label).'</strong>';
 if($type==='icon'){echo '<select style="display:block" name="'.esc_attr($name).'"><option value="">'.esc_html__('Nessuna icona','ticinoweb-child-theme').'</option>';foreach(tw_recruiting_icons() as $key=>$choice)echo '<option value="'.esc_attr($key).'" '.selected($value,$key,false).'>'.esc_html($choice['label']).'</option>';echo '</select>';}
 elseif($type==='status'){echo '<select style="display:block" name="'.esc_attr($name).'"><option value="closed" '.selected($value,'closed',false).'>'.esc_html__('Chiusa / nascosta','ticinoweb-child-theme').'</option><option value="open" '.selected($value,'open',false).'>'.esc_html__('Aperta','ticinoweb-child-theme').'</option></select>';}
 elseif($type==='textarea')echo '<textarea style="display:block;width:100%" rows="3" name="'.esc_attr($name).'">'.esc_textarea($value).'</textarea>';
 else echo '<input style="display:block;width:100%" type="'.esc_attr($type).'" name="'.esc_attr($name).'" value="'.esc_attr($value).'">';
 echo '</label>';
}
function tw_recruiting_metabox($post){
 $d=tw_recruiting_data($post->ID);wp_nonce_field('tw_recruiting_save','tw_recruiting_nonce');wp_enqueue_media();
 wp_enqueue_script('tw-recruiting-admin',get_stylesheet_directory_uri().'/assets/js/recruiting-admin.js',['jquery'],wp_get_theme()->get('Version'),true);
 echo '<p>'.esc_html__('Le aree descrivono competenze, non offerte. Pubblica solo annunci verificati sul portale ufficiale; imposta Chiusa quando non sono più disponibili. Nessuna candidatura viene raccolta qui.','ticinoweb-child-theme').'</p>';
 echo '<label><input type="checkbox" name="tw_recruiting_enabled" value="1" '.checked(tw_recruiting_enabled($post->ID),true,false).'> '.esc_html__('Usa il layout recruiting','ticinoweb-child-theme').'</label>';
 foreach(tw_recruiting_fields() as $key=>$label)tw_recruiting_control('tw_recruiting['.$key.']',$label,$d[$key]??'',str_ends_with($key,'_text')?'textarea':($key==='portal_url'?'url':'text'));
 foreach(['hero_media_id'=>__('Hero Media — foto reale','ticinoweb-child-theme'),'editorial_media_id'=>__('Recruiting / Team Media — facoltativo','ticinoweb-child-theme')] as $key=>$label){echo '<p class="tw-recruiting-media"><strong>'.esc_html($label).'</strong><input type="hidden" name="tw_recruiting['.esc_attr($key).']" value="'.esc_attr($d[$key]??0).'"><span>'.esc_html(!empty($d[$key])?get_the_title($d[$key]):'').'</span> <button class="button tw-recruiting-pick" type="button">'.esc_html__('Seleziona media','ticinoweb-child-theme').'</button> <button class="button tw-recruiting-clear" type="button">'.esc_html__('Rimuovi','ticinoweb-child-theme').'</button></p>';}
 foreach(tw_recruiting_schema() as $key=>$schema){
  echo '<details class="tw-recruiting-repeater" data-field="'.esc_attr($key).'" style="margin-block:20px"><summary><strong>'.esc_html($schema['label']).'</strong></summary><div class="tw-recruiting-rows">';
  foreach((array)($d[$key]??[]) as $i=>$row)tw_recruiting_admin_row($key,$schema,$row,$i);
  echo '</div><template>';tw_recruiting_admin_row($key,$schema,[],0);echo '</template><button type="button" class="button tw-recruiting-add">'.esc_html__('Aggiungi voce','ticinoweb-child-theme').'</button></details>';
 }
}
function tw_recruiting_admin_row($key,$schema,$row,$i){
 echo '<fieldset style="padding:16px;margin-block:14px;border:1px solid #ddd">';
 foreach($schema['fields'] as $f=>$label)tw_recruiting_control('tw_recruiting['.$key.']['.$i.']['.$f.']',$label,$row[$f]??($f==='status'?'closed':''),$f==='icon'?'icon':($f==='status'?'status':($f==='text'?'textarea':($f==='url'?'url':'text'))));
 foreach(['up'=>__('Sposta su','ticinoweb-child-theme'),'down'=>__('Sposta giù','ticinoweb-child-theme'),'remove'=>__('Rimuovi voce','ticinoweb-child-theme')] as $action=>$label)echo '<button type="button" class="button tw-recruiting-'.esc_attr($action).'">'.esc_html($label).'</button> ';
 echo '</fieldset>';
}
