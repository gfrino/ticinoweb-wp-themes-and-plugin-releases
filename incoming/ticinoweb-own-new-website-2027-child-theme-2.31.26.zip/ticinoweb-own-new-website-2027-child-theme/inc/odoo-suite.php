<?php
/** Odoo Suite: structured page data and presentation only; global CMS and forms stay native. */
if(!defined('ABSPATH'))exit;
function tw_odoo_suite_data($id=0){$d=get_post_meta($id?:get_queried_object_id(),'_tw_odoo_suite',true);return is_array($d)?$d:[];}
function tw_odoo_suite_enabled($id=0){return (tw_odoo_suite_data($id)['enabled']??'0')==='1';}
function tw_odoo_suite_navigation(){ $rows=get_option('tw_odoo_suite_navigation',[]);return is_array($rows)?$rows:[]; }
function tw_odoo_suite_scalar($value){return is_scalar($value)?(string)$value:'';}
function tw_odoo_suite_image_id($value){$id=absint(tw_odoo_suite_scalar($value));return $id && get_post_type($id)==='attachment' && wp_attachment_is_image($id)?$id:0;}
function tw_odoo_suite_team_id($value){$id=absint(tw_odoo_suite_scalar($value));return $id && get_post_type($id)==='tw_team_member' && get_post_status($id)==='publish'?$id:0;}
function tw_odoo_suite_row($raw){
 $r=[];foreach(['title','eyebrow','cta'] as $key)$r[$key]=sanitize_text_field(tw_odoo_suite_scalar($raw[$key]??''));
 $r['text']=wp_kses_post(tw_odoo_suite_scalar($raw['text']??''));$r['url']=esc_url_raw(tw_odoo_suite_scalar($raw['url']??''));
 $r['icon']=tw_odoo_icon_key($raw['icon']??'');$r['order']=min(9999,absint(tw_odoo_suite_scalar($raw['order']??0)));$r['active']=($raw['active']??'0')==='1'?'1':'0';return $r;
}
function tw_odoo_suite_sanitize($raw){
 $raw=is_array($raw)?$raw:[];$d=['enabled'=>($raw['enabled']??'0')==='1'?'1':'0','role'=>($raw['role']??'')==='overview'?'overview':'detail'];
 foreach(['explorer_title','groups_title','concepts_title','sectors_title','media_title','video_title','appstore_label','form_title'] as $k)$d[$k]=sanitize_text_field(tw_odoo_suite_scalar($raw[$k]??''));
 $d['form_text']=sanitize_textarea_field(tw_odoo_suite_scalar($raw['form_text']??''));
 foreach(['appstore_url','video_url'] as $k)$d[$k]=esc_url_raw(tw_odoo_suite_scalar($raw[$k]??''));
 $d['media_id']=tw_odoo_suite_image_id($raw['media_id']??0);
 foreach(['divisions','groups'] as $key){$d[$key]=[];foreach(array_slice(is_array($raw[$key]??null)?$raw[$key]:[],0,30) as $group){
  if(!is_array($group)||empty($group['title']))continue;$g=tw_odoo_suite_row($group);$g['media_id']=tw_odoo_suite_image_id($group['media_id']??0);$g['team_member_id']=tw_odoo_suite_team_id($group['team_member_id']??0);$g['video_url']=esc_url_raw(tw_odoo_suite_scalar($group['video_url']??''));$g['rows']=[];
  foreach(array_slice(is_array($group['rows']??null)?$group['rows']:[],0,60) as $row)if(is_array($row)&&!empty($row['title']))$g['rows'][]=tw_odoo_suite_row($row);
  $d[$key][]=$g;
 }}
 foreach(['concepts','sectors'] as $key){$d[$key]=[];foreach(array_slice(is_array($raw[$key]??null)?$raw[$key]:[],0,30) as $row)if(is_array($row)&&!empty($row['title']))$d[$key][]=tw_odoo_suite_row($row);}
 return $d;
}
function tw_odoo_suite_active_rows($rows){$rows=array_values(array_filter((array)$rows,static fn($r)=>is_array($r)&&($r['active']??'0')==='1'));usort($rows,static fn($a,$b)=>(int)($a['order']??0)<=>(int)($b['order']??0));return $rows;}
function tw_odoo_suite_public_nav(){
 $rows=[];foreach(tw_odoo_suite_active_rows(tw_odoo_suite_navigation()) as $r){$id=absint($r['page_id']??0);if(get_post_type($id)!=='page'||get_post_status($id)!=='publish'||!tw_odoo_suite_enabled($id))continue;
  $translated=apply_filters('wpml_object_id',$id,'page',true);$r['page_id']=$translated;$r['url']=get_permalink($translated);$r['label']=($r['label']??'')?:get_the_title($translated);$rows[]=$r;
 }return $rows;
}
function tw_odoo_suite_text($text){return wp_kses_post(wpautop($text));}
function tw_odoo_suite_media($id,$eager=false){if(!$id)return;echo wp_get_attachment_image($id,'large',false,['loading'=>$eager?'eager':'lazy','decoding'=>'async','sizes'=>'(max-width: 900px) 92vw, 60vw']);}
add_filter('template_include',static function($template){
 if(!is_page())return $template;
 if(tw_odoo_suite_enabled())return get_stylesheet_directory().'/page-odoo-suite.php';
 if(basename($template)==='page-odoo-suite.php')return get_stylesheet_directory().(tw_service_enabled()?'/page-service.php':'/page.php');
 return $template;
},130);
add_action('wp_enqueue_scripts',static function(){
 if(!is_page()||!tw_odoo_suite_enabled())return;$v=wp_get_theme()->get('Version');$uri=get_stylesheet_directory_uri();
 wp_enqueue_style('tw-odoo-suite',$uri.'/assets/css/odoo-suite.css',['ticinoweb-child-site'],$v);
 wp_enqueue_script('tw-odoo-suite',$uri.'/assets/js/odoo-suite.js',[],$v,true);
 wp_enqueue_script('tw-about',$uri.'/assets/js/about-contact.js',[],$v,true);
 wp_localize_script('tw-about','twAboutForm',['ajax_url'=>admin_url('admin-ajax.php'),'token_action'=>'ticinoweb_form_token','submit_action'=>'ticinoweb_submit_form','recaptcha_site_key'=>(string)get_option('ticinoweb_recaptcha_site_key',''),'busy'=>__('Invio in corso…','ticinoweb-child-theme'),'failure'=>__('Invio non riuscito. Riprova oppure contattaci via email.','ticinoweb-child-theme'),'privacy'=>__('Accetta l’informativa privacy per inviare la richiesta.','ticinoweb-child-theme'),'saved'=>__('Richiesta registrata. Se non ricevi una risposta, contattaci direttamente.','ticinoweb-child-theme')]);
},40);
add_filter('ticinoweb_form_fields',static function($fields,$raw){
 if(($raw['tw_form_context']??'')!=='about'||!is_scalar($raw['tw_odoo_page']??null))return $fields;
 $id=absint($raw['tw_odoo_page']);if(get_post_status($id)!=='publish'||!tw_odoo_suite_enabled($id))return $fields;
 $size=sanitize_text_field(tw_odoo_suite_scalar($raw['tw_odoo_company_size']??''));
 if($size!=='')$fields['messaggio'].="\n".__('Dimensione dell’azienda','ticinoweb-child-theme').': '.mb_substr($size,0,100);
 return $fields;
},20,2);
/** Preserve previous local aliases recorded by WordPress, without guessing another route. */
add_action('template_redirect',static function(){
 if(!is_404())return;
 $path=untrailingslashit((string)wp_parse_url(wp_unslash($_SERVER['REQUEST_URI']??''),PHP_URL_PATH));
 foreach(tw_odoo_suite_navigation() as $row){
  $id=absint($row['page_id']??0);if(get_post_status($id)!=='publish'||!tw_odoo_suite_enabled($id))continue;
  foreach(get_post_meta($id,'_wp_old_slug',false) as $old){
   if(!is_string($old)||!$old||get_page_by_path($old))continue;
   if($path===untrailingslashit((string)wp_parse_url(home_url('/'.$old.'/'),PHP_URL_PATH))){wp_safe_redirect(get_permalink($id),301,'ticinoWEB Odoo Suite');exit;}
  }
 }
},-1);
/** Existing explicit SEO remains authoritative; replace only the broken legacy auto-excerpt. */
add_filter('ticinoweb_seo_meta_description',static function($description){
 if(!is_page()||!tw_odoo_suite_enabled()||get_post_meta(get_queried_object_id(),'_tw_seo_description',true))return $description;
 $s=(array)get_post_meta(get_queried_object_id(),'_tw_service_content',true);
 return !empty($s['hero_text'])?wp_html_excerpt(wp_strip_all_tags($s['hero_text']),160,'…'):$description;
});
