<?php
/**
 * Editing contract for blog-native Projects and the Team content model.
 *
 * Gli articoli sono l'unica fonte per Progetti / Realizzazioni. Il modello
 * legacy viene migrato e cancellato una sola volta.
 *
 * @package ticinoWEB_Child_Theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Sanitize a stored checkbox or REST boolean. */
function tw_home_sanitize_boolean( $value ) {
	return (bool) rest_sanitize_boolean( $value );
}

/** Sanitize a comma-separated or REST array of service keys. */
function tw_home_sanitize_key_list( $value ) {
	if ( is_string( $value ) ) {
		$value = preg_split( '/[\s,]+/', $value, -1, PREG_SPLIT_NO_EMPTY );
	}
	$keys = array_filter( array_map( 'sanitize_key', is_array( $value ) ? $value : array( $value ) ) );
	return array_values( array_unique( $keys ) );
}

/** Field used to include a post in the Home Project Explorer. */
function tw_home_project_article_fields() {
	return array(
		'tw_home_project_featured' => array(
			'label'       => __( 'Mostra nella sezione Referenze / Realizzazioni della Home', 'ticinoweb-child-theme' ),
			'type'        => 'checkbox',
			'sanitize'    => 'tw_home_sanitize_boolean',
			'rest_type'   => 'boolean',
			'description' => __( 'L’articolo sarà mostrato con la sua immagine in evidenza e potrà essere filtrato per categoria e argomento.', 'ticinoweb-child-theme' ),
		),
	);
}

/** Fields used by Founder and Team on the Home. */
function tw_home_team_fields() {
	return array(
		'tw_role'             => array( 'label' => __( 'Ruolo', 'ticinoweb-child-theme' ), 'type' => 'text', 'sanitize' => 'sanitize_text_field', 'rest_type' => 'string' ),
		'tw_full_bio'         => array( 'label' => __( 'Bio completa', 'ticinoweb-child-theme' ), 'type' => 'textarea', 'sanitize' => 'wp_kses_post', 'rest_type' => 'string' ),
		'tw_specializations'  => array( 'label' => __( 'Specializzazioni', 'ticinoweb-child-theme' ), 'type' => 'textarea', 'sanitize' => 'sanitize_textarea_field', 'rest_type' => 'string' ),
		'tw_languages'        => array( 'label' => __( 'Lingue parlate', 'ticinoweb-child-theme' ), 'type' => 'textarea', 'sanitize' => 'sanitize_textarea_field', 'rest_type' => 'string', 'description' => __( 'Indica le lingue parlate, separate da virgole.', 'ticinoweb-child-theme' ) ),
		'tw_experience_since' => array( 'label' => __( 'Attivo nel settore dal', 'ticinoweb-child-theme' ), 'type' => 'number', 'sanitize' => 'absint', 'rest_type' => 'integer' ),
		'tw_order'            => array( 'label' => __( 'Ordinamento', 'ticinoweb-child-theme' ), 'type' => 'number', 'sanitize' => 'absint', 'rest_type' => 'integer' ),
		'tw_active'           => array( 'label' => __( 'Attivo', 'ticinoweb-child-theme' ), 'type' => 'checkbox', 'sanitize' => 'tw_home_sanitize_boolean', 'rest_type' => 'boolean' ),
		'tw_founder'          => array( 'label' => __( 'Fondatore', 'ticinoweb-child-theme' ), 'type' => 'checkbox', 'sanitize' => 'tw_home_sanitize_boolean', 'rest_type' => 'boolean' ),
	);
}

/** Register Home-consumed meta keys without changing stored data. */
function tw_home_register_editorial_meta() {
	foreach ( array( 'post' => tw_home_project_article_fields(), 'tw_team_member' => tw_home_team_fields() ) as $post_type => $fields ) {
		foreach ( $fields as $key => $field ) {
			$rest_type = $field['rest_type'];
			$show_in_rest = 'array' === $rest_type ? array( 'schema' => array( 'type' => 'array', 'items' => array( 'type' => 'string' ) ) ) : true;
			register_post_meta(
				$post_type,
				$key,
				array(
					'type'              => $rest_type,
					'single'            => true,
					'show_in_rest'      => $show_in_rest,
					'sanitize_callback' => $field['sanitize'],
					'auth_callback'     => static function () {
						return current_user_can( 'edit_posts' );
					},
				)
			);
		}
	}
}
add_action( 'init', 'tw_home_register_editorial_meta', 25 );

/** Add the optional destination used by logos in the "Credono in noi" gallery. */
function tw_home_client_url_field( $fields, $post ) {
	if ( ! wp_attachment_is_image( $post->ID ) ) {
		return $fields;
	}
	$value = esc_url( get_post_meta( $post->ID, '_tw_client_url', true ) );
	$fields['tw_client_url'] = array(
		'label' => __( 'Credono in noi — URL', 'ticinoweb-child-theme' ),
		'input' => 'html',
		'html'  => '<input class="widefat" type="url" name="attachments[' . esc_attr( $post->ID ) . '][tw_client_url]" value="' . esc_attr( $value ) . '" placeholder="https://">',
		'helps' => __( 'Collegamento facoltativo usato quando questo logo appartiene alla galleria “Credono in noi”.', 'ticinoweb-child-theme' ),
	);
	return $fields;
}
add_filter( 'attachment_fields_to_edit', 'tw_home_client_url_field', 20, 2 );

/** Save the client destination through WordPress' protected attachment editor. */
function tw_home_save_client_url_field( $post, $attachment ) {
	if ( ! isset( $attachment['tw_client_url'] ) ) {
		return $post;
	}
	$url = esc_url_raw( $attachment['tw_client_url'] );
	$url ? update_post_meta( $post['ID'], '_tw_client_url', $url ) : delete_post_meta( $post['ID'], '_tw_client_url' );
	return $post;
}
add_filter( 'attachment_fields_to_save', 'tw_home_save_client_url_field', 20, 2 );

/** Render one secure group of existing meta fields. */
function tw_home_render_meta_box( $post, $fields, $nonce_action ) {
	wp_nonce_field( $nonce_action, '_tw_home_meta_nonce' );
	echo '<table class="form-table" role="presentation"><tbody>';
	foreach ( $fields as $key => $field ) {
		$value = get_post_meta( $post->ID, $key, true );
		echo '<tr><th scope="row"><label for="' . esc_attr( $key ) . '">' . esc_html( $field['label'] ) . '</label></th><td>';
		if ( 'textarea' === $field['type'] ) {
			echo '<textarea class="large-text" rows="5" id="' . esc_attr( $key ) . '" name="' . esc_attr( $key ) . '">' . esc_textarea( (string) $value ) . '</textarea>';
		} elseif ( 'checkbox' === $field['type'] ) {
			echo '<input type="checkbox" id="' . esc_attr( $key ) . '" name="' . esc_attr( $key ) . '" value="1" ' . checked( (bool) $value, true, false ) . '>';
		} else {
			$display = is_array( $value ) ? implode( ', ', $value ) : (string) $value;
			echo '<input class="regular-text" type="' . esc_attr( $field['type'] ) . '" id="' . esc_attr( $key ) . '" name="' . esc_attr( $key ) . '" value="' . esc_attr( $display ) . '">';
		}
		if ( ! empty( $field['description'] ) ) {
			echo '<p class="description">' . esc_html( $field['description'] ) . '</p>';
		}
		echo '</td></tr>';
	}
	echo '</tbody></table>';
}

/** Persist only whitelisted fields after nonce and capability checks. */
function tw_home_save_meta_box( $post_id, $fields, $nonce_action ) {
	$nonce = isset( $_POST['_tw_home_meta_nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['_tw_home_meta_nonce'] ) ) : '';
	if ( ! wp_verify_nonce( $nonce, $nonce_action ) || ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) || wp_is_post_revision( $post_id ) || ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}
	foreach ( $fields as $key => $field ) {
		if ( 'checkbox' === $field['type'] ) {
			update_post_meta( $post_id, $key, isset( $_POST[ $key ] ) ? '1' : '0' );
			continue;
		}
		if ( ! isset( $_POST[ $key ] ) ) {
			continue;
		}
		$value = call_user_func( $field['sanitize'], wp_unslash( $_POST[ $key ] ) );
		'' === $value ? delete_post_meta( $post_id, $key ) : update_post_meta( $post_id, $key, $value );
	}
}

/** Add and save the blog-native Project flag. */
function tw_home_add_article_project_meta_box() {
	add_meta_box( 'tw-home-project-article', __( 'Referenze / Realizzazioni', 'ticinoweb-child-theme' ), static function ( $post ) {
		wp_nonce_field( 'tw_home_save_project_article', '_tw_home_meta_nonce' );
		$field = tw_home_project_article_fields()['tw_home_project_featured'];
		$value = get_post_meta( $post->ID, 'tw_home_project_featured', true );
		?>
		<p>
			<label for="tw_home_project_featured">
				<input type="checkbox" id="tw_home_project_featured" name="tw_home_project_featured" value="1" <?php checked( '1', (string) $value ); ?>>
				<strong><?php echo esc_html( $field['label'] ); ?></strong>
			</label>
		</p>
		<p class="description"><?php echo esc_html( $field['description'] ); ?></p>
		<?php
	}, 'post', 'side', 'high' );
}
add_action( 'add_meta_boxes_post', 'tw_home_add_article_project_meta_box' );
add_action( 'save_post_post', static function ( $post_id ) {
	tw_home_save_meta_box( $post_id, tw_home_project_article_fields(), 'tw_home_save_project_article' );
} );

/**
 * Registra solo internamente le tassonomie legacy finché la cancellazione non è conclusa.
 */
function tw_home_register_legacy_project_taxonomies_for_migration() {
	// Native shared sectors supersede the retired destructive migration.
	if ( function_exists( 'tw_home_register_project_sectors' ) ) return;
	if ( '1' === (string) get_option( 'tw_home_project_article_migration_version', '' ) ) {
		return;
	}

	foreach ( array( 'tw_project_type', 'tw_project_sector' ) as $taxonomy ) {
		if ( taxonomy_exists( $taxonomy ) ) {
			continue;
		}
		register_taxonomy(
			$taxonomy,
			array( 'tw_project' ),
			array(
				'public'            => false,
				'publicly_queryable' => false,
				'show_ui'           => false,
				'show_in_rest'      => false,
				'rewrite'           => false,
				'query_var'         => false,
			)
		);
	}
}
add_action( 'init', 'tw_home_register_legacy_project_taxonomies_for_migration', 19 );

/**
 * Trasferisce il flag ai relativi articoli ed elimina definitivamente il modello legacy.
 *
 * @return array Riepilogo numerico della migrazione.
 */
function tw_home_maybe_migrate_legacy_projects() {
	if ( function_exists( 'tw_home_register_project_sectors' ) ) return array( 'deleted'=>0, 'remaining'=>0 );
	$result_option = 'tw_home_project_article_migration_result';
	if ( '1' === (string) get_option( 'tw_home_project_article_migration_version', '' ) ) {
		$result = get_option( $result_option, array() );
		return is_array( $result ) ? $result : array();
	}
	if ( ! current_user_can( 'manage_options' ) ) {
		return array();
	}

	$projects = get_posts(
		array(
			'post_type'        => 'tw_project',
			'post_status'      => array_values( get_post_stati( array(), 'names' ) ),
			'posts_per_page'   => -1,
			'orderby'          => 'ID',
			'order'            => 'ASC',
			'suppress_filters' => true,
		)
	);
	$result = array(
		'total'     => count( $projects ),
		'migrated'  => 0,
		'unmatched' => 0,
		'deleted'   => 0,
		'remaining' => 0,
		'completed' => gmdate( 'c' ),
	);

	foreach ( $projects as $project ) {
		$article_id = absint( get_post_meta( $project->ID, '_tw_source_post_id', true ) );
		$article    = $article_id ? get_post( $article_id ) : null;
		if ( ! $article || 'post' !== $article->post_type ) {
			$article = get_page_by_path( $project->post_name, OBJECT, 'post' );
		}

		if ( $article && 'post' === $article->post_type ) {
			update_post_meta( $article->ID, 'tw_home_project_featured', '1' );
			$result['migrated']++;
		} else {
			$result['unmatched']++;
		}

		if ( wp_delete_post( $project->ID, true ) ) {
			$result['deleted']++;
		}
	}

	foreach ( array( 'tw_project_type', 'tw_project_sector' ) as $taxonomy ) {
		$terms = get_terms(
			array(
				'taxonomy'   => $taxonomy,
				'hide_empty' => false,
			)
		);
		if ( is_wp_error( $terms ) ) {
			continue;
		}
		foreach ( $terms as $term ) {
			wp_delete_term( $term->term_id, $taxonomy );
		}
	}

	$remaining = get_posts(
		array(
			'post_type'        => 'tw_project',
			'post_status'      => array_values( get_post_stati( array(), 'names' ) ),
			'posts_per_page'   => -1,
			'fields'           => 'ids',
			'suppress_filters' => true,
		)
	);
	$result['remaining'] = count( $remaining );

	update_option( $result_option, $result, false );
	update_option( 'tw_home_project_article_migration_version', '1', false );
	update_option( 'tw_home_project_article_migration_notice', '1', false );
	return $result;
}
add_action( 'admin_init', 'tw_home_maybe_migrate_legacy_projects', 5 );

/** Show the local administrator the one-time migration result. */
function tw_home_project_migration_notice() {
	if ( ! current_user_can( 'manage_options' ) || '1' !== (string) get_option( 'tw_home_project_article_migration_notice', '' ) ) {
		return;
	}
	$result = get_option( 'tw_home_project_article_migration_result', array() );
	printf(
		'<div class="notice notice-success is-dismissible"><p>%s</p></div>',
		esc_html(
			sprintf(
				/* translators: 1: migrated articles, 2: deleted projects, 3: unmatched projects. */
				__( 'Migrazione Referenze completata: %1$d articoli marcati, %2$d vecchie referenze eliminate, %3$d senza articolo associato.', 'ticinoweb-child-theme' ),
				absint( $result['migrated'] ?? 0 ),
				absint( $result['deleted'] ?? 0 ),
				absint( $result['unmatched'] ?? 0 )
			)
		)
	);
	delete_option( 'tw_home_project_article_migration_notice' );
}
add_action( 'admin_notices', 'tw_home_project_migration_notice' );

/** Add and save the Team editing panel. */
function tw_home_add_team_meta_box() {
	add_meta_box( 'tw-home-team-details', __( 'Dati collaboratore ticinoWEB', 'ticinoweb-child-theme' ), static function ( $post ) {
		tw_home_render_meta_box( $post, tw_home_team_fields(), 'tw_home_save_team' );
	}, 'tw_team_member', 'normal', 'high' );
}
add_action( 'add_meta_boxes_tw_team_member', 'tw_home_add_team_meta_box' );
add_action( 'save_post_tw_team_member', static function ( $post_id ) {
	tw_home_save_meta_box( $post_id, tw_home_team_fields(), 'tw_home_save_team' );
	if ( '1' !== (string) get_post_meta( $post_id, 'tw_founder', true ) ) {
		return;
	}
	$other_founders = get_posts(
		array(
			'post_type'      => 'tw_team_member',
			'post_status'    => 'any',
			'posts_per_page' => -1,
			'fields'         => 'ids',
			'post__not_in'   => array( $post_id ),
			'meta_key'       => 'tw_founder',
			'meta_value'     => '1',
		)
	);
	foreach ( $other_founders as $other_id ) {
		update_post_meta( $other_id, 'tw_founder', '0' );
	}
} );

/** Flush rewrites once per child version, after CPT/taxonomy registration. */
function tw_home_maybe_flush_rewrites() {
	$version = wp_get_theme()->get( 'Version' );
	if ( get_option( 'tw_home_rewrite_version' ) === $version ) {
		return;
	}
	flush_rewrite_rules( false );
	update_option( 'tw_home_rewrite_version', $version, false );
}
add_action( 'admin_init', 'tw_home_maybe_flush_rewrites' );
