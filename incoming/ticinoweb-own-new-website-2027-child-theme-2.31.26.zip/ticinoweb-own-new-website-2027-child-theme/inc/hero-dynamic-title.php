<?php
/**
 * Estensione child del sistema Slider CMS per il titolo dinamico Hero.
 *
 * @package ticinoWEB_Child_Theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Pulisce e conserva l'ordine dei termini dinamici.
 */
function tw_hero_dynamic_sanitize_terms( $value ) {
	if ( ! is_array( $value ) ) {
		return array();
	}

	$terms = array_map( 'sanitize_text_field', $value );
	$terms = array_values( array_filter( $terms, static fn( $term ) => '' !== trim( $term ) ) );
	return array_slice( $terms, 0, 12 );
}

/**
 * Limita l'intervallo a un tempo leggibile e sicuro.
 */
function tw_hero_dynamic_sanitize_interval( $value ) {
	if ( '' === $value || null === $value ) {
		return 3200;
	}
	return min( 10000, max( 1800, absint( $value ) ) );
}

/**
 * Registra i campi nello stesso gruppo Settings API dello Slider parent.
 */
function tw_hero_dynamic_register_settings() {
	for ( $slot = 1; $slot <= 5; $slot++ ) {
		$enabled_key  = "ticinoweb_slider_dynamic_enabled_{$slot}";
		$before_key   = "ticinoweb_slider_dynamic_before_{$slot}";
		$terms_key    = "ticinoweb_slider_dynamic_terms_{$slot}";
		$after_key    = "ticinoweb_slider_dynamic_after_{$slot}";
		$interval_key = "ticinoweb_slider_dynamic_interval_{$slot}";

		register_setting( 'ticinoweb_settings_group', $enabled_key, array( 'sanitize_callback' => 'absint' ) );
		register_setting( 'ticinoweb_settings_group', $before_key, array( 'sanitize_callback' => 'sanitize_text_field' ) );
		register_setting( 'ticinoweb_settings_group', $terms_key, array( 'sanitize_callback' => 'tw_hero_dynamic_sanitize_terms' ) );
		register_setting( 'ticinoweb_settings_group', $after_key, array( 'sanitize_callback' => 'sanitize_text_field' ) );
		register_setting( 'ticinoweb_settings_group', $interval_key, array( 'sanitize_callback' => 'tw_hero_dynamic_sanitize_interval' ) );
	}
}
add_action( 'admin_init', 'tw_hero_dynamic_register_settings', 30 );

/**
 * Restituisce il contratto normalizzato di una slide.
 */
function tw_hero_dynamic_get_config( $slot ) {
	$slot = min( 5, max( 1, absint( $slot ) ) );
	$before = sanitize_text_field( get_option( "ticinoweb_slider_dynamic_before_{$slot}", '' ) );
	$terms  = tw_hero_dynamic_sanitize_terms( get_option( "ticinoweb_slider_dynamic_terms_{$slot}", array() ) );
	$after  = sanitize_text_field( get_option( "ticinoweb_slider_dynamic_after_{$slot}", '' ) );

	if ( function_exists( 'ticinoweb_frontend_text' ) ) {
		$before = ticinoweb_frontend_text( $before, "theme:slider:{$slot}:dynamic_before" );
		$after  = ticinoweb_frontend_text( $after, "theme:slider:{$slot}:dynamic_after" );
		$terms  = array_map(
			static fn( $term, $index ) => ticinoweb_frontend_text( $term, "theme:slider:{$slot}:dynamic_term:{$index}" ),
			$terms,
			array_keys( $terms )
		);
	}

	return array(
		'enabled'  => 1 === absint( get_option( "ticinoweb_slider_dynamic_enabled_{$slot}", 0 ) ),
		'before'   => $before,
		'terms'    => $terms,
		'after'    => $after,
		'interval' => tw_hero_dynamic_sanitize_interval( get_option( "ticinoweb_slider_dynamic_interval_{$slot}", 3200 ) ),
	);
}

/**
 * Compila una sola volta la configurazione approvata della Slide 1.
 */
function tw_hero_dynamic_seed_slide_one() {
	if ( '1.0.0' === get_option( 'tw_child_hero_dynamic_schema', '' ) ) {
		return;
	}

	update_option( 'ticinoweb_slider_dynamic_enabled_1', 1 );
	update_option( 'ticinoweb_slider_dynamic_before_1', 'Progettiamo' );
	update_option(
		'ticinoweb_slider_dynamic_terms_1',
		array(
			'esperienze digitali',
			'siti web su misura',
			'eCommerce performanti',
			'identità digitali',
			'ecosistemi digitali',
		)
	);
	update_option( 'ticinoweb_slider_dynamic_after_1', 'che fanno crescere le aziende.' );
	update_option( 'ticinoweb_slider_dynamic_interval_1', 3200 );
	update_option( 'tw_child_hero_dynamic_schema', '1.0.0', false );
}
add_action( 'after_setup_theme', 'tw_hero_dynamic_seed_slide_one', 30 );

/**
 * Carica l'estensione soltanto nella pagina ticinoWEB CMS.
 */
function tw_hero_dynamic_admin_assets( $hook_suffix ) {
	if ( 'toplevel_page_ticinoweb-cms' !== $hook_suffix || ! current_user_can( 'edit_pages' ) ) {
		return;
	}

	$theme = wp_get_theme();
	wp_enqueue_style(
		'tw-hero-dynamic-admin',
		get_stylesheet_directory_uri() . '/assets/css/hero-dynamic-admin.css',
		array(),
		$theme->get( 'Version' )
	);
	wp_enqueue_script(
		'tw-hero-dynamic-admin',
		get_stylesheet_directory_uri() . '/assets/js/hero-dynamic-admin.js',
		array( 'jquery', 'jquery-ui-sortable' ),
		$theme->get( 'Version' ),
		true
	);

	$slides = array();
	for ( $slot = 1; $slot <= 5; $slot++ ) {
		$slides[ $slot ] = tw_hero_dynamic_get_config( $slot );
	}
	wp_localize_script(
		'tw-hero-dynamic-admin',
		'twHeroDynamicAdmin',
		array(
			'slides' => $slides,
			'labels' => array(
				'mediaLabel'  => __( 'Immagine o video Hero', 'ticinoweb-child-theme' ),
				'mediaButton' => __( 'Carica immagine o video', 'ticinoweb-child-theme' ),
				'group'       => __( 'Titolo dinamico', 'ticinoweb-child-theme' ),
				'enabled'     => __( 'Attiva testo dinamico', 'ticinoweb-child-theme' ),
				'before'      => __( 'Testo prima', 'ticinoweb-child-theme' ),
				'terms'       => __( 'Termini dinamici', 'ticinoweb-child-theme' ),
				'termLabel'   => __( 'Termine dinamico', 'ticinoweb-child-theme' ),
				'after'       => __( 'Testo dopo', 'ticinoweb-child-theme' ),
				'interval'    => __( 'Intervallo rotazione (ms)', 'ticinoweb-child-theme' ),
				'addTerm'     => __( 'Aggiungi termine', 'ticinoweb-child-theme' ),
				'removeTerm'  => __( 'Rimuovi termine', 'ticinoweb-child-theme' ),
				'moveTerm'    => __( 'Trascina per riordinare', 'ticinoweb-child-theme' ),
				'moveUp'      => __( 'Sposta il termine verso l’alto', 'ticinoweb-child-theme' ),
				'moveDown'    => __( 'Sposta il termine verso il basso', 'ticinoweb-child-theme' ),
				'description' => __( 'Il titolo originale resta il fallback quando questa opzione è disattivata.', 'ticinoweb-child-theme' ),
			),
		)
	);
}
add_action( 'admin_enqueue_scripts', 'tw_hero_dynamic_admin_assets' );
