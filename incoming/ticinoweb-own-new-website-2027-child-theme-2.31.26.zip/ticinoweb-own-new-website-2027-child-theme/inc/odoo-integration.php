<?php
/**
 * Integrazione dei form del sito con Odoo (ticinoweb.online).
 *
 * - Richieste di consulenza (form Contatti, Chi siamo, CTA Odoo)  -> opportunità CRM (crm.lead)
 * - Richieste di assistenza (form della pagina Supporto)          -> ticket Helpdesk (helpdesk.ticket)
 *
 * L'invio parte dall'azione `ticinoweb_form_submitted` del tema parent, dopo il salvataggio
 * e la mail: se Odoo non risponde la richiesta non va persa, resta nella coda e viene
 * ritentata dal cron. Impostazioni: ticinoWEB CMS → Integrazione Odoo.
 *
 * @package ticinoWEB_Child_Theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

const TW_ODOO_OPTION = 'tw_odoo_settings';
const TW_ODOO_QUEUE  = 'tw_odoo_queue';
const TW_ODOO_LOG    = 'tw_odoo_last';

function tw_odoo_defaults() {
	return array(
		'enabled'    => 0,
		'url'        => 'https://ticinoweb.online',
		'db'         => 'Production',
		'login'      => '',
		'api_key'    => '',
		'crm_user'   => 'gio@ticinoweb.net',
		'crm_team'   => 'Website',
		'help_user'  => 'kyle@ticinoweb.net',
		'help_routing' => array(
			'odoo'      => 'odoo@ticinoweb.net',
			'app'       => 'gio@ticinoweb.net',
			'web'       => 'kyle@ticinoweb.net',
			'marketing' => 'gio@ticinoweb.net',
		),
		'help_team'  => 'Assistenza Clienti',
	);
}

function tw_odoo_settings() {
	return wp_parse_args( (array) get_option( TW_ODOO_OPTION, array() ), tw_odoo_defaults() );
}

/* ------------------------------------------------------------------ chiave API cifrata */

function tw_odoo_crypto_key() {
	$salt = ( defined( 'AUTH_KEY' ) ? AUTH_KEY : '' ) . ( defined( 'SECURE_AUTH_KEY' ) ? SECURE_AUTH_KEY : '' );
	return hash( 'sha256', 'tw-odoo|' . $salt, true );
}

function tw_odoo_encrypt( $plain ) {
	if ( '' === $plain ) {
		return '';
	}
	$iv     = random_bytes( 16 );
	$cipher = openssl_encrypt( $plain, 'aes-256-cbc', tw_odoo_crypto_key(), OPENSSL_RAW_DATA, $iv );
	return false === $cipher ? '' : base64_encode( $iv . $cipher );
}

function tw_odoo_decrypt( $stored ) {
	$raw = base64_decode( (string) $stored, true );
	if ( false === $raw || strlen( $raw ) < 17 ) {
		return '';
	}
	$plain = openssl_decrypt( substr( $raw, 16 ), 'aes-256-cbc', tw_odoo_crypto_key(), OPENSSL_RAW_DATA, substr( $raw, 0, 16 ) );
	return false === $plain ? '' : $plain;
}

/** La costante TW_ODOO_API_KEY in wp-config.php ha la precedenza sul campo. */
function tw_odoo_api_key() {
	if ( defined( 'TW_ODOO_API_KEY' ) && TW_ODOO_API_KEY ) {
		return (string) TW_ODOO_API_KEY;
	}
	return tw_odoo_decrypt( tw_odoo_settings()['api_key'] );
}

/* ------------------------------------------------------------------ client JSON-RPC */

function tw_odoo_rpc( $service, $method, array $args ) {
	$s = tw_odoo_settings();
	$response = wp_remote_post(
		trailingslashit( esc_url_raw( $s['url'] ) ) . 'jsonrpc',
		array(
			'timeout' => 8,
			'headers' => array( 'Content-Type' => 'application/json' ),
			'body'    => wp_json_encode( array(
				'jsonrpc' => '2.0',
				'method'  => 'call',
				'id'      => wp_rand( 1, 999999 ),
				'params'  => array( 'service' => $service, 'method' => $method, 'args' => $args ),
			) ),
		)
	);
	if ( is_wp_error( $response ) ) {
		return $response;
	}
	$code = (int) wp_remote_retrieve_response_code( $response );
	$data = json_decode( wp_remote_retrieve_body( $response ), true );
	if ( ! is_array( $data ) ) {
		return new WP_Error( 'tw_odoo_bad_response', sprintf( 'Risposta non valida da Odoo (HTTP %d).', $code ) );
	}
	if ( ! empty( $data['error'] ) ) {
		$msg = $data['error']['data']['message'] ?? $data['error']['message'] ?? 'Errore Odoo';
		return new WP_Error( 'tw_odoo_error', (string) $msg );
	}
	return $data['result'] ?? null;
}

function tw_odoo_uid() {
	static $uid = null;
	if ( null !== $uid ) {
		return $uid;
	}
	$s   = tw_odoo_settings();
	$key = tw_odoo_api_key();
	if ( '' === $key || '' === $s['login'] ) {
		return new WP_Error( 'tw_odoo_config', 'Utente Odoo o chiave API mancanti.' );
	}
	$result = tw_odoo_rpc( 'common', 'authenticate', array( $s['db'], $s['login'], $key, new stdClass() ) );
	if ( is_wp_error( $result ) ) {
		return $result;
	}
	if ( ! $result ) {
		return new WP_Error( 'tw_odoo_auth', 'Odoo ha rifiutato utente o chiave API.' );
	}
	$uid = (int) $result;
	return $uid;
}

function tw_odoo_call( $model, $method, array $args = array(), array $kwargs = array() ) {
	$uid = tw_odoo_uid();
	if ( is_wp_error( $uid ) ) {
		return $uid;
	}
	$s = tw_odoo_settings();
	return tw_odoo_rpc( 'object', 'execute_kw', array( $s['db'], $uid, tw_odoo_api_key(), $model, $method, $args, (object) $kwargs ) );
}

/** Id di un record cercato per campo (con cache di 12 ore); false se non esiste. */
function tw_odoo_lookup( $model, $field, $value ) {
	if ( '' === (string) $value ) {
		return false;
	}
	$cache_key = 'tw_odoo_id_' . md5( $model . '|' . $field . '|' . $value );
	$cached    = get_transient( $cache_key );
	if ( false !== $cached ) {
		return (int) $cached;
	}
	// =ilike: confronto esatto senza distinzione di maiuscole, valido anche sui campi tradotti (es. utm.source).
	$ids = tw_odoo_call( $model, 'search', array( array( array( $field, '=ilike', addcslashes( (string) $value, '%_\\' ) ) ) ), array( 'limit' => 1 ) );
	if ( is_wp_error( $ids ) ) {
		return $ids;
	}
	if ( empty( $ids ) ) {
		return false;
	}
	set_transient( $cache_key, (int) $ids[0], 12 * HOUR_IN_SECONDS );
	return (int) $ids[0];
}

/** Id del record con quel nome; se manca lo crea (per sorgenti e tag, che nascono al primo uso). */
function tw_odoo_find_or_create( $model, $name ) {
	$id = tw_odoo_lookup( $model, 'name', $name );
	if ( $id && ! is_wp_error( $id ) ) {
		return (int) $id;
	}
	$created = tw_odoo_call( $model, 'create', array( array( 'name' => $name ) ) );
	return is_wp_error( $created ) ? false : (int) $created;
}

function tw_odoo_html( $text, $extra = '' ) {
	return '<p>' . nl2br( esc_html( (string) $text ) ) . '</p>' . $extra;
}

/** Azienda (res.partner con is_company) cercata per nome esatto, senza distinzione di maiuscole; la crea se manca. */
function tw_odoo_company_id( $name ) {
	$ids = tw_odoo_call( 'res.partner', 'search', array( array( array( 'is_company', '=', true ), array( 'name', '=ilike', addcslashes( $name, '%_\\' ) ) ) ), array( 'limit' => 1 ) );
	if ( ! is_wp_error( $ids ) && ! empty( $ids ) ) {
		return (int) $ids[0];
	}
	$created = tw_odoo_call( 'res.partner', 'create', array( array( 'name' => $name, 'is_company' => true ) ) );
	return is_wp_error( $created ) ? false : (int) $created;
}

function tw_odoo_partner_id( $email ) {
	$ids = tw_odoo_call( 'res.partner', 'search', array( array( array( 'email', '=ilike', $email ) ) ), array( 'limit' => 1 ) );
	return ( ! is_wp_error( $ids ) && ! empty( $ids ) ) ? (int) $ids[0] : false;
}

/* ------------------------------------------------------------------ creazione record */

function tw_odoo_create_lead( array $job ) {
	$s = tw_odoo_settings();
	$f = $job['fields'];

	$vals = array(
		'type'         => 'opportunity',
		'name'         => $f['oggetto'] ?: 'Nuova richiesta dal sito',
		'contact_name' => $f['nome'],
		'email_from'   => $f['email'],
		'phone'        => $f['telefono'],
		'description'  => tw_odoo_html( $f['messaggio'], '<p><small>' . esc_html( 'Inviata dal sito: ' . ( $job['source'] ?: home_url( '/' ) ) ) . '</small></p>' ),
	);
	$user = tw_odoo_lookup( 'res.users', 'login', $s['crm_user'] );
	if ( $user ) {
		$vals['user_id'] = $user;
	}
	$team = tw_odoo_lookup( 'crm.team', 'name', $s['crm_team'] );
	if ( $team ) {
		$vals['team_id'] = $team;
	}
	$source = tw_odoo_find_or_create( 'utm.source', 'Sito ticinoweb.com' );
	if ( $source ) {
		$vals['source_id'] = $source;
	}
	$medium = tw_odoo_lookup( 'utm.medium', 'name', 'Website' );
	if ( $medium ) {
		$vals['medium_id'] = $medium;
	}
	// Azienda: se esiste già in Odoo la collega, altrimenti la crea. Il contatto (persona) resta
	// collegato per email se già presente; altrimenti il cliente dell'opportunità è l'azienda.
	$company_id = false;
	$company    = trim( (string) ( $job['company'] ?? '' ) );
	if ( '' !== $company ) {
		$vals['partner_name'] = $company;
		$company_id           = tw_odoo_company_id( $company );
	}
	$partner = tw_odoo_partner_id( $f['email'] );
	if ( $partner ) {
		$vals['partner_id'] = $partner;
	} elseif ( $company_id ) {
		$vals['partner_id'] = $company_id;
	}
	$tag_ids = array();
	foreach ( array_merge( array( 'Sito ticinoweb.com' ), (array) $job['tags'] ) as $tag ) {
		$id = tw_odoo_find_or_create( 'crm.tag', $tag );
		if ( $id && ! is_wp_error( $id ) ) {
			$tag_ids[] = (int) $id;
		}
	}
	if ( $tag_ids ) {
		$vals['tag_ids'] = array( array( 6, 0, array_values( array_unique( $tag_ids ) ) ) );
	}
	return tw_odoo_call( 'crm.lead', 'create', array( $vals ) );
}

function tw_odoo_create_ticket( array $job ) {
	$s = tw_odoo_settings();
	$f = $job['fields'];

	$vals = array(
		'name'          => $f['oggetto'] ?: 'Richiesta di assistenza dal sito',
		'description'   => tw_odoo_html( $f['messaggio'], '<p><small>' . esc_html( 'Telefono: ' . ( $f['telefono'] ?: '—' ) . ' · Inviata dal sito: ' . ( $job['source'] ?: home_url( '/' ) ) ) . '</small></p>' ),
		'partner_name'  => $f['nome'],
		'partner_email' => $f['email'],
	);
	$user = tw_odoo_lookup( 'res.users', 'login', tw_odoo_support_assignee( (string) ( $job['service'] ?? '' ) ) );
	if ( $user ) {
		$vals['user_id'] = $user;
	}
	$team = tw_odoo_lookup( 'helpdesk.ticket.team', 'name', $s['help_team'] );
	if ( $team ) {
		$vals['team_id'] = $team;
	}
	$channel = tw_odoo_lookup( 'helpdesk.ticket.channel', 'name', 'Web' );
	if ( $channel ) {
		$vals['channel_id'] = $channel;
	}
	$partner = tw_odoo_partner_id( $f['email'] );
	if ( $partner ) {
		$vals['partner_id'] = $partner;
	}
	return tw_odoo_call( 'helpdesk.ticket', 'create', array( $vals ) );
}

function tw_odoo_dispatch( array $job ) {
	return 'ticket' === $job['kind'] ? tw_odoo_create_ticket( $job ) : tw_odoo_create_lead( $job );
}

function tw_odoo_log( $ok, $message ) {
	update_option( TW_ODOO_LOG, array( 'time' => time(), 'ok' => (bool) $ok, 'message' => (string) $message ), false );
}

/* ------------------------------------------------------------------ aggancio ai form */

add_filter( 'ticinoweb_form_fields', function ( $fields, $raw ) {
	if ( 'support' !== ( $raw['tw_form_context'] ?? '' ) ) {
		return $fields;
	}
	$services = tw_odoo_support_services();
	$key      = sanitize_key( wp_unslash( $raw['servizio'] ?? '' ) );
	$label    = $services[ $key ] ?? __( 'Assistenza generale', 'ticinoweb-child-theme' );
	$fields['oggetto']   = sprintf( __( 'Assistenza %s', 'ticinoweb-child-theme' ), $label );
	$fields['messaggio'] = __( 'Servizio', 'ticinoweb-child-theme' ) . ': ' . $label . "\n\n" . $fields['messaggio'];
	return $fields;
}, 11, 2 );

function tw_odoo_support_services() {
	return array(
		'odoo'      => 'Odoo',
		'app'       => 'App iOS / Android',
		'web'       => 'Siti Web',
		'marketing' => 'Marketing',
	);
}

/** Email dell'utente Odoo a cui assegnare il ticket per quel servizio (con ripiego sul responsabile generale). */
function tw_odoo_support_assignee( $service ) {
	$s      = tw_odoo_settings();
	$routes = (array) $s['help_routing'];
	$email  = $routes[ $service ] ?? '';
	return is_email( $email ) ? $email : $s['help_user'];
}

add_action( 'ticinoweb_form_submitted', function ( $submission_id, $fields ) {
	$s = tw_odoo_settings();
	if ( empty( $s['enabled'] ) ) {
		return;
	}
	$context = sanitize_key( wp_unslash( $_POST['tw_form_context'] ?? '' ) ); // phpcs:ignore WordPress.Security.NonceVerification
	if ( ! in_array( $context, array( 'about', 'support' ), true ) ) {
		return; // il sondaggio e gli altri form non passano da Odoo.
	}
	$tags = array();
	if ( 'about' === $context && function_exists( 'tw_contact_project_types' ) ) {
		$types = tw_contact_project_types();
		foreach ( (array) wp_unslash( $_POST['progetto'] ?? array() ) as $key ) { // phpcs:ignore WordPress.Security.NonceVerification
			$key = sanitize_key( $key );
			if ( isset( $types[ $key ] ) ) {
				$tags[] = $types[ $key ];
			}
		}
	}
	$job = array(
		'kind'   => 'support' === $context ? 'ticket' : 'lead',
		'fields' => array_merge( array( 'nome' => '', 'email' => '', 'telefono' => '', 'oggetto' => '', 'messaggio' => '' ), $fields ),
		'tags'   => $tags,
		'service' => sanitize_key( wp_unslash( $_POST['servizio'] ?? '' ) ), // phpcs:ignore WordPress.Security.NonceVerification
		'company' => sanitize_text_field( wp_unslash( $_POST['azienda'] ?? '' ) ), // phpcs:ignore WordPress.Security.NonceVerification
		'source' => wp_get_referer() ?: '',
		'tries'  => 0,
	);
	try {
		$result = tw_odoo_dispatch( $job );
	} catch ( Throwable $e ) {
		$result = new WP_Error( 'tw_odoo_exception', $e->getMessage() );
	}
	if ( is_wp_error( $result ) ) {
		tw_odoo_log( false, $result->get_error_message() );
		$queue   = (array) get_option( TW_ODOO_QUEUE, array() );
		$queue[] = $job;
		update_option( TW_ODOO_QUEUE, array_slice( $queue, -50 ), false );
		if ( ! wp_next_scheduled( 'tw_odoo_retry' ) ) {
			wp_schedule_single_event( time() + 5 * MINUTE_IN_SECONDS, 'tw_odoo_retry' );
		}
		return;
	}
	tw_odoo_log( true, sprintf( '%s creato in Odoo (id %d).', 'ticket' === $job['kind'] ? 'Ticket' : 'Opportunità', (int) $result ) );
}, 20, 2 );

add_action( 'tw_odoo_retry', function () {
	$queue = (array) get_option( TW_ODOO_QUEUE, array() );
	$left  = array();
	foreach ( $queue as $job ) {
		$result = tw_odoo_dispatch( $job );
		if ( is_wp_error( $result ) ) {
			tw_odoo_log( false, $result->get_error_message() );
			if ( ++$job['tries'] < 12 ) {
				$left[] = $job;
			}
		} else {
			tw_odoo_log( true, 'Richiesta in coda inviata a Odoo (id ' . (int) $result . ').' );
		}
	}
	update_option( TW_ODOO_QUEUE, $left, false );
	if ( $left ) {
		wp_schedule_single_event( time() + 10 * MINUTE_IN_SECONDS, 'tw_odoo_retry' );
	}
} );

/* ------------------------------------------------------------------ pagina impostazioni */

// Voce nel menu «ticinoWEB CMS» (priorità 20: dopo la registrazione del menu principale nel parent).
add_action( 'admin_menu', function () {
	add_submenu_page( 'ticinoweb-cms', 'Integrazione Odoo', 'Integrazione Odoo', 'manage_options', 'tw-odoo', 'tw_odoo_render_settings' );
}, 20 );

add_action( 'admin_post_tw_odoo_save', function () {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( 'Non autorizzato.' );
	}
	check_admin_referer( 'tw_odoo_save' );
	$old = tw_odoo_settings();
	$new = array(
		'enabled'   => empty( $_POST['enabled'] ) ? 0 : 1,
		'url'       => esc_url_raw( untrailingslashit( wp_unslash( $_POST['url'] ?? $old['url'] ) ) ),
		'db'        => sanitize_text_field( wp_unslash( $_POST['db'] ?? $old['db'] ) ),
		'login'     => sanitize_email( wp_unslash( $_POST['login'] ?? '' ) ),
		'crm_user'  => sanitize_email( wp_unslash( $_POST['crm_user'] ?? '' ) ),
		'crm_team'  => sanitize_text_field( wp_unslash( $_POST['crm_team'] ?? '' ) ),
		'help_user' => sanitize_email( wp_unslash( $_POST['help_user'] ?? '' ) ),
		'help_routing' => array(),
		'help_team' => sanitize_text_field( wp_unslash( $_POST['help_team'] ?? '' ) ),
		'api_key'   => $old['api_key'],
	);
	foreach ( array_keys( tw_odoo_support_services() ) as $key ) {
		$new['help_routing'][ $key ] = sanitize_email( wp_unslash( $_POST['route'][ $key ] ?? '' ) );
	}
	$typed = trim( (string) wp_unslash( $_POST['api_key'] ?? '' ) );
	if ( '' !== $typed ) {
		$new['api_key'] = tw_odoo_encrypt( $typed );
	}
	update_option( TW_ODOO_OPTION, $new, false );
	wp_safe_redirect( add_query_arg( array( 'page' => 'tw-odoo', 'saved' => 1 ), admin_url( 'admin.php' ) ) );
	exit;
} );

add_action( 'admin_post_tw_odoo_test', function () {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( 'Non autorizzato.' );
	}
	check_admin_referer( 'tw_odoo_test' );
	$s     = tw_odoo_settings();
	$lines = array();
	$uid   = tw_odoo_uid();
	if ( is_wp_error( $uid ) ) {
		$lines[] = array( false, 'Connessione: ' . $uid->get_error_message() );
	} else {
		$lines[] = array( true, 'Connessione e chiave API: OK (utente Odoo n. ' . $uid . ').' );
		$checks  = array(
			array( 'Commerciale CRM ' . $s['crm_user'], 'res.users', 'login', $s['crm_user'] ),
			array( 'Team CRM «' . $s['crm_team'] . '»', 'crm.team', 'name', $s['crm_team'] ),
			array( 'Responsabile ticket generico ' . $s['help_user'], 'res.users', 'login', $s['help_user'] ),
			array( 'Team Helpdesk «' . $s['help_team'] . '»', 'helpdesk.ticket.team', 'name', $s['help_team'] ),
		);
		foreach ( tw_odoo_support_services() as $key => $label ) {
			$mail     = tw_odoo_support_assignee( $key );
			$checks[] = array( 'Ticket «' . $label . '» a ' . $mail, 'res.users', 'login', $mail );
		}
		foreach ( $checks as $c ) {
			$id      = tw_odoo_lookup( $c[1], $c[2], $c[3] );
			$ok      = $id && ! is_wp_error( $id );
			$lines[] = array( $ok, $c[0] . ': ' . ( $ok ? 'trovato' : 'NON trovato in Odoo' ) );
		}
	}
	set_transient( 'tw_odoo_test_result', $lines, 120 );
	wp_safe_redirect( add_query_arg( array( 'page' => 'tw-odoo', 'tested' => 1 ), admin_url( 'admin.php' ) ) );
	exit;
} );

function tw_odoo_render_settings() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$s       = tw_odoo_settings();
	$has_key = '' !== tw_odoo_api_key();
	$log     = get_option( TW_ODOO_LOG, array() );
	$queue   = (array) get_option( TW_ODOO_QUEUE, array() );
	?>
	<div class="wrap">
		<h1>Integrazione Odoo</h1>
		<p>Le richieste di <strong>consulenza</strong> (Contatti, Chi siamo, CTA Odoo) diventano opportunità nel CRM; le richieste di <strong>assistenza</strong> (pagina Supporto) diventano ticket nell’Helpdesk. La mail di notifica parte comunque.</p>
		<?php if ( ! empty( $_GET['saved'] ) ) : // phpcs:ignore WordPress.Security.NonceVerification ?>
			<div class="notice notice-success"><p>Impostazioni salvate.</p></div>
		<?php endif; ?>
		<?php
		if ( ! empty( $_GET['tested'] ) ) : // phpcs:ignore WordPress.Security.NonceVerification
			foreach ( (array) get_transient( 'tw_odoo_test_result' ) as $line ) :
				?>
				<div class="notice notice-<?php echo $line[0] ? 'success' : 'error'; ?>"><p><?php echo esc_html( $line[1] ); ?></p></div>
				<?php
			endforeach;
		endif;
		?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="tw_odoo_save">
			<?php wp_nonce_field( 'tw_odoo_save' ); ?>
			<table class="form-table" role="presentation">
				<tr><th scope="row">Invio attivo</th><td><label><input type="checkbox" name="enabled" value="1" <?php checked( $s['enabled'] ); ?>> Invia le richieste a Odoo</label></td></tr>
				<tr><th scope="row"><label for="tw-odoo-url">Indirizzo di Odoo</label></th><td><input id="tw-odoo-url" class="regular-text" type="url" name="url" value="<?php echo esc_attr( $s['url'] ); ?>"></td></tr>
				<tr><th scope="row"><label for="tw-odoo-db">Database</label></th><td><input id="tw-odoo-db" class="regular-text" name="db" value="<?php echo esc_attr( $s['db'] ); ?>"></td></tr>
				<tr><th scope="row"><label for="tw-odoo-login">Email del tuo utente Odoo</label></th><td><input id="tw-odoo-login" class="regular-text" type="email" name="login" value="<?php echo esc_attr( $s['login'] ); ?>" autocomplete="off"></td></tr>
				<tr><th scope="row"><label for="tw-odoo-key">Chiave API</label></th><td>
					<input id="tw-odoo-key" class="regular-text" type="password" name="api_key" value="" autocomplete="new-password" placeholder="<?php echo $has_key ? '•••••••• (già salvata: lascia vuoto per non cambiarla)' : 'Incolla qui la chiave'; ?>">
					<p class="description">In Odoo: il tuo profilo → Sicurezza account → <em>Nuova chiave API</em>. Viene salvata cifrata. In alternativa definisci <code>TW_ODOO_API_KEY</code> in wp-config.php.</p>
				</td></tr>
				<tr><th scope="row"><label for="tw-odoo-crm-user">Commerciale (CRM)</label></th><td><input id="tw-odoo-crm-user" class="regular-text" type="email" name="crm_user" value="<?php echo esc_attr( $s['crm_user'] ); ?>"><p class="description">Email dell’utente Odoo a cui assegnare le opportunità.</p></td></tr>
				<tr><th scope="row"><label for="tw-odoo-crm-team">Team vendite</label></th><td><input id="tw-odoo-crm-team" class="regular-text" name="crm_team" value="<?php echo esc_attr( $s['crm_team'] ); ?>"></td></tr>
				<?php foreach ( tw_odoo_support_services() as $key => $label ) : ?>
					<tr><th scope="row"><label for="tw-odoo-route-<?php echo esc_attr( $key ); ?>">Ticket «<?php echo esc_html( $label ); ?>» a</label></th><td><input id="tw-odoo-route-<?php echo esc_attr( $key ); ?>" class="regular-text" type="email" name="route[<?php echo esc_attr( $key ); ?>]" value="<?php echo esc_attr( $s['help_routing'][ $key ] ?? '' ); ?>"><?php if ( 'odoo' === $key ) : ?><p class="description">Email dell’utente Odoo a cui assegnare i ticket di quel servizio.</p><?php endif; ?></td></tr>
				<?php endforeach; ?>
				<tr><th scope="row"><label for="tw-odoo-help-user">Altri ticket a</label></th><td><input id="tw-odoo-help-user" class="regular-text" type="email" name="help_user" value="<?php echo esc_attr( $s['help_user'] ); ?>"><p class="description">Se un servizio non ha un responsabile.</p></td></tr>
				<tr><th scope="row"><label for="tw-odoo-help-team">Team Helpdesk</label></th><td><input id="tw-odoo-help-team" class="regular-text" name="help_team" value="<?php echo esc_attr( $s['help_team'] ); ?>"></td></tr>
			</table>
			<?php submit_button( 'Salva impostazioni' ); ?>
		</form>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin-top:8px">
			<input type="hidden" name="action" value="tw_odoo_test">
			<?php wp_nonce_field( 'tw_odoo_test' ); ?>
			<?php submit_button( 'Prova la connessione', 'secondary', 'submit', false ); ?>
			<span class="description">Controlla chiave, utenti e team senza creare nulla.</span>
		</form>
		<h2>Stato</h2>
		<?php if ( $log ) : ?>
			<p><strong><?php echo ! empty( $log['ok'] ) ? 'Ultimo invio riuscito' : 'Ultimo invio non riuscito'; ?></strong> (<?php echo esc_html( wp_date( 'd.m.Y H:i', (int) $log['time'] ) ); ?>): <?php echo esc_html( $log['message'] ); ?></p>
		<?php else : ?>
			<p>Nessun invio ancora.</p>
		<?php endif; ?>
		<p>Richieste in coda per un nuovo tentativo: <strong><?php echo count( $queue ); ?></strong></p>
	</div>
	<?php
}
