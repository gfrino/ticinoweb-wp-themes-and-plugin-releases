<?php
/**
 * Pagina Contatti / Parliamo del tuo progetto.
 * Pagina di conversione separata da Chi siamo: riusa il gestore form del parent
 * (ticinoweb_submit_form), la stessa protezione (token, honeypot, rate limit,
 * reCAPTCHA) e la stessa validazione del form Chi siamo (contesto "about").
 */
if ( ! defined( 'ABSPATH' ) ) exit;

function tw_contact_is_page() {
	return is_page() && is_page_template( 'page-contact.php' );
}

/** Tipologie di progetto proposte nel form (etichette tradotte da tW Translate). */
function tw_contact_project_types() {
	return array(
		'sito'       => __( 'Sito web', 'ticinoweb-child-theme' ),
		'ecommerce'  => __( 'E-commerce', 'ticinoweb-child-theme' ),
		'app'        => __( 'App iOS / Android', 'ticinoweb-child-theme' ),
		'odoo'       => __( 'Gestionale Odoo', 'ticinoweb-child-theme' ),
		'marketing'  => __( 'Social e marketing', 'ticinoweb-child-theme' ),
		'hosting'    => __( 'Hosting ed email', 'ticinoweb-child-theme' ),
		'altro'      => __( 'Altro', 'ticinoweb-child-theme' ),
	);
}
function tw_contact_budgets() {
	return array(
		''        => __( 'Preferisco parlarne', 'ticinoweb-child-theme' ),
		'lt5'     => __( 'Fino a CHF 5’000', 'ticinoweb-child-theme' ),
		'5-15'    => __( 'CHF 5’000 – 15’000', 'ticinoweb-child-theme' ),
		'15-30'   => __( 'CHF 15’000 – 30’000', 'ticinoweb-child-theme' ),
		'gt30'    => __( 'Oltre CHF 30’000', 'ticinoweb-child-theme' ),
	);
}
function tw_contact_timings() {
	return array(
		''        => __( 'Non ancora definito', 'ticinoweb-child-theme' ),
		'subito'  => __( 'Il prima possibile', 'ticinoweb-child-theme' ),
		'1-3'     => __( 'Entro 1–3 mesi', 'ticinoweb-child-theme' ),
		'3plus'   => __( 'Tra più di 3 mesi', 'ticinoweb-child-theme' ),
	);
}
function tw_contact_page_url() {
	return tw_home_mapped_url( 'page_contatti', 'contatti' );
}

add_action( 'wp_enqueue_scripts', function () {
	if ( ! tw_contact_is_page() ) return;
	$v = wp_get_theme()->get( 'Version' );
	wp_enqueue_style( 'tw-about', get_stylesheet_directory_uri() . '/assets/css/about-contact.css', array( 'ticinoweb-child-site' ), $v );
	wp_enqueue_style( 'tw-contact', get_stylesheet_directory_uri() . '/assets/css/contact.css', array( 'tw-about' ), $v );
	wp_enqueue_script( 'tw-about', get_stylesheet_directory_uri() . '/assets/js/about-contact.js', array(), $v, true );
	wp_localize_script( 'tw-about', 'twAboutForm', array(
		'ajax_url' => admin_url( 'admin-ajax.php' ), 'token_action' => 'ticinoweb_form_token', 'submit_action' => 'ticinoweb_submit_form',
		'recaptcha_site_key' => (string) get_option( 'ticinoweb_recaptcha_site_key', '' ),
		'busy'    => __( 'Invio in corso…', 'ticinoweb-child-theme' ),
		'failure' => __( 'Invio non riuscito. Riprova oppure contattaci via email.', 'ticinoweb-child-theme' ),
		'privacy' => __( 'Accetta l’informativa privacy per inviare la richiesta.', 'ticinoweb-child-theme' ),
		'saved'   => __( 'Richiesta registrata. Se non ricevi una risposta, contattaci direttamente.', 'ticinoweb-child-theme' ),
	) );
}, 30 );

/** Aggiunge al messaggio i dati di qualificazione del progetto (solo questo form). */
add_filter( 'ticinoweb_form_fields', function ( $fields, $raw ) {
	if ( empty( $raw['tw_contact_page'] ) ) return $fields;
	$types   = tw_contact_project_types();
	$picked  = array();
	foreach ( (array) wp_unslash( $raw['progetto'] ?? array() ) as $key ) {
		$key = sanitize_key( $key );
		if ( isset( $types[ $key ] ) ) $picked[] = $types[ $key ];
	}
	$budgets = tw_contact_budgets();
	$timings = tw_contact_timings();
	$budget  = sanitize_key( wp_unslash( $raw['budget'] ?? '' ) );
	$timing  = sanitize_key( wp_unslash( $raw['tempistiche'] ?? '' ) );
	$site    = esc_url_raw( wp_unslash( $raw['sito_attuale'] ?? '' ) );
	$prefer  = sanitize_text_field( wp_unslash( $raw['ricontatto'] ?? '' ) );
	$company = sanitize_text_field( wp_unslash( $raw['azienda'] ?? '' ) );
	$lines   = array();
	if ( '' !== $company ) $lines[] = __( 'Azienda', 'ticinoweb-child-theme' ) . ': ' . $company;
	if ( $picked ) $lines[] = __( 'Tipo di progetto', 'ticinoweb-child-theme' ) . ': ' . implode( ', ', $picked );
	if ( '' !== $budget && isset( $budgets[ $budget ] ) ) $lines[] = __( 'Budget indicativo', 'ticinoweb-child-theme' ) . ': ' . $budgets[ $budget ];
	if ( '' !== $timing && isset( $timings[ $timing ] ) ) $lines[] = __( 'Tempistiche', 'ticinoweb-child-theme' ) . ': ' . $timings[ $timing ];
	if ( $site ) $lines[] = __( 'Sito attuale', 'ticinoweb-child-theme' ) . ': ' . $site;
	if ( in_array( $prefer, array( 'email', 'telefono', 'whatsapp' ), true ) ) $lines[] = __( 'Preferisce essere ricontattato via', 'ticinoweb-child-theme' ) . ': ' . $prefer;
	if ( $lines ) $fields['messaggio'] = implode( "\n", $lines ) . "\n\n" . $fields['messaggio'];
	$fields['oggetto'] = $picked
		? sprintf( __( 'Nuova richiesta progetto: %s', 'ticinoweb-child-theme' ), implode( ', ', $picked ) )
		: __( 'Nuova richiesta dal sito', 'ticinoweb-child-theme' );
	return $fields;
}, 11, 2 );
