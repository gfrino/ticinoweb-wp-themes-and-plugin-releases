<?php
/** Controlled, native page editor for Odoo Suite content. */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function tw_odoo_suite_admin_eligible( $post_id ) {
	$data = get_post_meta( $post_id, '_tw_odoo_suite', true );
	return 'page' === get_post_type( $post_id ) && ( ( is_array( $data ) && '1' === ( $data['enabled'] ?? '' ) ) || 'page-odoo-suite.php' === get_page_template_slug( $post_id ) );
}

add_action( 'add_meta_boxes_page', function ( $post ) {
	if ( tw_odoo_suite_admin_eligible( $post->ID ) ) {
		add_meta_box( 'tw-odoo-suite', __( 'Odoo Suite — contenuti', 'ticinoweb-child-theme' ), 'tw_odoo_suite_admin_box', 'page', 'normal', 'high' );
	}
} );

add_action( 'admin_enqueue_scripts', function ( $hook ) {
	global $post;
	if ( ! in_array( $hook, array( 'post.php', 'post-new.php' ), true ) || ! $post || ! tw_odoo_suite_admin_eligible( $post->ID ) ) {
		return;
	}
	wp_enqueue_media();
	$version = wp_get_theme()->get( 'Version' );
	wp_enqueue_style( 'tw-odoo-suite-admin', get_stylesheet_directory_uri() . '/assets/css/odoo-suite-admin.css', array(), $version );
	wp_enqueue_script( 'tw-odoo-suite-admin', get_stylesheet_directory_uri() . '/assets/js/odoo-suite-admin.js', array( 'media-views' ), $version, true );
	wp_localize_script( 'tw-odoo-suite-admin', 'twOdooSuiteAdmin', array(
		'mediaTitle' => __( 'Scegli un media Odoo', 'ticinoweb-child-theme' ),
		'mediaButton' => __( 'Usa questo media', 'ticinoweb-child-theme' ),
		'emptyMedia' => __( 'Nessun media selezionato', 'ticinoweb-child-theme' ),
		'newGroup' => __( 'Nuovo gruppo', 'ticinoweb-child-theme' ),
		'removeConfirm' => __( 'Rimuovere questa voce e i suoi contenuti? La modifica sarà definitiva dopo il salvataggio della pagina.', 'ticinoweb-child-theme' ),
	) );
} );

/** Each label wraps its control, including dynamically created repeater controls. */
function tw_odoo_suite_admin_field( $name, $label, $value = '', $type = 'text' ) {
	echo '<label class="tw-odoo-field"><span>' . esc_html( $label ) . '</span>';
	if ( 'textarea' === $type ) {
		echo '<textarea rows="3" name="' . esc_attr( $name ) . '">' . esc_textarea( $value ) . '</textarea>';
	} else {
		echo '<input type="' . esc_attr( $type ) . '" name="' . esc_attr( $name ) . '" value="' . esc_attr( $value ) . '"' . ( 'number' === $type ? ' step="1" min="0"' : '' ) . '>';
	}
	echo '</label>';
}

function tw_odoo_suite_admin_state( $name, $data ) {
	echo '<div class="tw-odoo-state">';
	tw_odoo_suite_admin_field( $name . '[order]', __( 'Ordine', 'ticinoweb-child-theme' ), $data['order'] ?? 0, 'number' );
	echo '<label><input type="hidden" name="' . esc_attr( $name . '[active]' ) . '" value="0"><input type="checkbox" name="' . esc_attr( $name . '[active]' ) . '" value="1" ' . checked( $data['active'] ?? '1', '1', false ) . '> ' . esc_html__( 'Attiva', 'ticinoweb-child-theme' ) . '</label></div>';
}

function tw_odoo_suite_admin_media( $name, $id ) {
	$id = absint( $id );
	echo '<div class="tw-odoo-media"><input type="hidden" class="tw-odoo-media-id" name="' . esc_attr( $name ) . '" value="' . esc_attr( $id ) . '"><p class="tw-odoo-media-name">' . esc_html( $id ? get_the_title( $id ) : __( 'Nessun media selezionato', 'ticinoweb-child-theme' ) ) . '</p><button type="button" class="button" data-odoo-media="pick">' . esc_html__( 'Scegli dalla Libreria Media', 'ticinoweb-child-theme' ) . '</button> <button type="button" class="button" data-odoo-media="clear">' . esc_html__( 'Rimuovi media', 'ticinoweb-child-theme' ) . '</button></div>';
}

function tw_odoo_suite_admin_row( $name, $row = array() ) {
	echo '<fieldset class="tw-odoo-item"><legend>' . esc_html__( 'Modulo / funzionalità', 'ticinoweb-child-theme' ) . '</legend>';
	tw_odoo_suite_admin_field( $name . '[title]', __( 'Titolo', 'ticinoweb-child-theme' ), $row['title'] ?? '' );
	tw_odoo_suite_admin_field( $name . '[text]', __( 'Descrizione', 'ticinoweb-child-theme' ), $row['text'] ?? '', 'textarea' );
	echo '<div class="tw-odoo-icon"><label class="tw-odoo-field"><span>' . esc_html__( 'Icona ufficiale Odoo', 'ticinoweb-child-theme' ) . '</span><select class="tw-odoo-icon-select" name="' . esc_attr( $name . '[icon]' ) . '"><option value="">' . esc_html__( 'Nessuna icona', 'ticinoweb-child-theme' ) . '</option>';
	$icons = tw_odoo_icons();
	foreach ( $icons as $key => $icon ) {
		echo '<option value="' . esc_attr( $key ) . '" data-url="' . esc_url( $icon['url'] ) . '" ' . selected( $row['icon'] ?? '', $key, false ) . '>' . esc_html( $icon['label'] ) . '</option>';
	}
	$icon_url = isset( $icons[ $row['icon'] ?? '' ] ) ? $icons[ $row['icon'] ]['url'] : '';
	echo '</select></label><img class="tw-odoo-icon-preview" alt="" width="48" height="48"' . ( $icon_url ? ' src="' . esc_url( $icon_url ) . '"' : ' hidden' ) . '></div>';
	tw_odoo_suite_admin_field( $name . '[url]', __( 'URL opzionale', 'ticinoweb-child-theme' ), $row['url'] ?? '', 'url' );
	tw_odoo_suite_admin_field( $name . '[cta]', __( 'Testo del collegamento', 'ticinoweb-child-theme' ), $row['cta'] ?? '' );
	tw_odoo_suite_admin_state( $name, $row );
	echo '<button type="button" class="button-link-delete" data-odoo-remove>' . esc_html__( 'Rimuovi voce', 'ticinoweb-child-theme' ) . '</button></fieldset>';
}

function tw_odoo_suite_admin_group( $name, $group = array(), $media = false ) {
	echo '<details class="tw-odoo-item tw-odoo-group"><summary>' . esc_html( $group['title'] ?? __( 'Nuovo gruppo', 'ticinoweb-child-theme' ) ) . '</summary><div class="tw-odoo-group-fields">';
	tw_odoo_suite_admin_field( $name . '[title]', __( 'Titolo gruppo', 'ticinoweb-child-theme' ), $group['title'] ?? '' );
	tw_odoo_suite_admin_field( $name . '[eyebrow]', __( 'Sopratitolo / numero', 'ticinoweb-child-theme' ), $group['eyebrow'] ?? '' );
	tw_odoo_suite_admin_field( $name . '[text]', __( 'Descrizione opzionale', 'ticinoweb-child-theme' ), $group['text'] ?? '', 'textarea' );
	tw_odoo_suite_admin_state( $name, $group );
	if ( $media ) {
		echo '<label class="tw-odoo-field"><span>' . esc_html__( 'Collaboratore del team (opzionale)', 'ticinoweb-child-theme' ) . '</span><select name="' . esc_attr( $name . '[team_member_id]' ) . '"><option value="0">' . esc_html__( 'Nessun collaboratore', 'ticinoweb-child-theme' ) . '</option>';
		foreach ( get_posts( array( 'post_type' => 'tw_team_member', 'post_status' => 'publish', 'numberposts' => 100, 'orderby' => 'title', 'order' => 'ASC' ) ) as $person ) {
			echo '<option value="' . esc_attr( $person->ID ) . '" ' . selected( $group['team_member_id'] ?? 0, $person->ID, false ) . '>' . esc_html( $person->post_title ) . '</option>';
		}
		echo '</select></label>';
		tw_odoo_suite_admin_media( $name . '[media_id]', $group['media_id'] ?? 0 );
		tw_odoo_suite_admin_field( $name . '[video_url]', __( 'URL video opzionale', 'ticinoweb-child-theme' ), $group['video_url'] ?? '', 'url' );
	}
	tw_odoo_suite_admin_repeater( $name . '[rows]', $group['rows'] ?? array(), 'row', __( 'Moduli / funzionalità', 'ticinoweb-child-theme' ) );
	echo '<button type="button" class="button-link-delete" data-odoo-remove>' . esc_html__( 'Rimuovi gruppo', 'ticinoweb-child-theme' ) . '</button></div></details>';
}

function tw_odoo_suite_admin_nav_row( $name, $row = array() ) {
	echo '<fieldset class="tw-odoo-item"><legend>' . esc_html__( 'Voce della navigazione', 'ticinoweb-child-theme' ) . '</legend><label class="tw-odoo-field"><span>' . esc_html__( 'Pagina WordPress pubblicata', 'ticinoweb-child-theme' ) . '</span>';
	wp_dropdown_pages( array( 'name' => $name . '[page_id]', 'id' => '', 'selected' => absint( $row['page_id'] ?? 0 ), 'show_option_none' => __( 'Scegli una pagina', 'ticinoweb-child-theme' ), 'option_none_value' => '0', 'post_status' => 'publish' ) );
	echo '</label>';
	tw_odoo_suite_admin_field( $name . '[label]', __( 'Etichetta', 'ticinoweb-child-theme' ), $row['label'] ?? '' );
	tw_odoo_suite_admin_state( $name, $row );
	echo '<button type="button" class="button-link-delete" data-odoo-remove>' . esc_html__( 'Rimuovi voce', 'ticinoweb-child-theme' ) . '</button></fieldset>';
}

function tw_odoo_suite_admin_repeater( $name, $items, $kind, $label ) {
	echo '<div class="tw-odoo-repeater" data-name="' . esc_attr( $name ) . '" data-kind="' . esc_attr( $kind ) . '"><h4>' . esc_html( $label ) . '</h4><div class="tw-odoo-items">';
	foreach ( is_array( $items ) ? array_values( $items ) : array() as $index => $item ) {
		if ( ! is_array( $item ) ) {
			continue;
		}
		$prefix = $name . '[' . $index . ']';
		if ( 'row' === $kind ) {
			tw_odoo_suite_admin_row( $prefix, $item );
		} elseif ( 'nav' === $kind ) {
			tw_odoo_suite_admin_nav_row( $prefix, $item );
		} else {
			tw_odoo_suite_admin_group( $prefix, $item, 'group' === $kind );
		}
	}
	echo '</div><button type="button" class="button" data-odoo-add>' . esc_html__( 'Aggiungi voce', 'ticinoweb-child-theme' ) . '</button></div>';
}

function tw_odoo_suite_admin_box( $post ) {
	$data = tw_odoo_suite_data( $post->ID );
	wp_nonce_field( 'tw_odoo_suite_save', 'tw_odoo_suite_nonce' );
	echo '<div class="tw-odoo-admin"><p>' . esc_html__( 'Hero, introduzione e CTA finale si modificano nel box “Contenuti pagina Servizio”. I contatti provengono dal ticinoWEB CMS. Qui si gestiscono solo i contenuti specifici Odoo.', 'ticinoweb-child-theme' ) . '</p>';
	echo '<input type="hidden" name="tw_odoo_suite[enabled]" value="0"><p><label><input type="checkbox" name="tw_odoo_suite[enabled]" value="1" ' . checked( $data['enabled'] ?? '1', '1', false ) . '> ' . esc_html__( 'Abilita Odoo Suite per questa pagina', 'ticinoweb-child-theme' ) . '</label></p>';
	echo '<label class="tw-odoo-field"><span>' . esc_html__( 'Ruolo della pagina', 'ticinoweb-child-theme' ) . '</span><select name="tw_odoo_suite[role]" class="tw-odoo-role">';
	foreach ( array( 'overview' => __( 'Panoramica', 'ticinoweb-child-theme' ), 'detail' => __( 'Approfondimento', 'ticinoweb-child-theme' ) ) as $key => $label ) {
		echo '<option value="' . esc_attr( $key ) . '" ' . selected( $data['role'] ?? 'detail', $key, false ) . '>' . esc_html( $label ) . '</option>';
	}
	echo '</select></label>';
	$sections = array(
		'divisions' => array( 'explorer_title', __( 'Divisioni e moduli', 'ticinoweb-child-theme' ), 'division' ),
		'groups' => array( 'groups_title', __( 'Gruppi di funzionalità', 'ticinoweb-child-theme' ), 'group' ),
		'concepts' => array( 'concepts_title', __( 'Concetti ERP / CRM / CMS', 'ticinoweb-child-theme' ), 'row' ),
		'sectors' => array( 'sectors_title', __( 'Settori', 'ticinoweb-child-theme' ), 'row' ),
	);
	foreach ( $sections as $key => $section ) {
		echo '<details class="tw-odoo-section"><summary>' . esc_html( $section[1] ) . '</summary>';
		tw_odoo_suite_admin_field( 'tw_odoo_suite[' . $section[0] . ']', __( 'Titolo della sezione', 'ticinoweb-child-theme' ), $data[ $section[0] ] ?? '' );
		tw_odoo_suite_admin_repeater( 'tw_odoo_suite[' . $key . ']', $data[ $key ] ?? array(), $section[2], $section[1] );
		echo '</details>';
	}
	echo '<details class="tw-odoo-section"><summary>' . esc_html__( 'Visual, video e collegamenti', 'ticinoweb-child-theme' ) . '</summary>';
	foreach ( array( 'media_title' => __( 'Titolo visual', 'ticinoweb-child-theme' ), 'video_title' => __( 'Titolo video', 'ticinoweb-child-theme' ), 'appstore_label' => __( 'Etichetta Odoo App Store', 'ticinoweb-child-theme' ), 'form_title' => __( 'Titolo consulenza', 'ticinoweb-child-theme' ) ) as $key => $label ) {
		tw_odoo_suite_admin_field( 'tw_odoo_suite[' . $key . ']', $label, $data[ $key ] ?? '' );
	}
	tw_odoo_suite_admin_media( 'tw_odoo_suite[media_id]', $data['media_id'] ?? 0 );
	tw_odoo_suite_admin_field( 'tw_odoo_suite[video_url]', __( 'URL video', 'ticinoweb-child-theme' ), $data['video_url'] ?? '', 'url' );
	tw_odoo_suite_admin_field( 'tw_odoo_suite[appstore_url]', __( 'URL Odoo App Store', 'ticinoweb-child-theme' ), $data['appstore_url'] ?? '', 'url' );
	tw_odoo_suite_admin_field( 'tw_odoo_suite[form_text]', __( 'Testo consulenza', 'ticinoweb-child-theme' ), $data['form_text'] ?? '', 'textarea' );
	echo '</details>';
	if ( current_user_can( 'manage_options' ) ) {
		echo '<details class="tw-odoo-section tw-odoo-navigation"><summary>' . esc_html__( 'Navigazione comune Odoo Suite', 'ticinoweb-child-theme' ) . '</summary><p>' . esc_html__( 'Modificabile dalla pagina Panoramica; le voci sono condivise da tutte le pagine Odoo.', 'ticinoweb-child-theme' ) . '</p><input type="hidden" name="tw_odoo_navigation_present" value="1">';
		tw_odoo_suite_admin_repeater( 'tw_odoo_navigation', tw_odoo_suite_navigation(), 'nav', __( 'Pagine della Suite', 'ticinoweb-child-theme' ) );
		echo '</details>';
	}
	foreach ( array( 'row', 'division', 'group', 'nav' ) as $kind ) {
		echo '<template id="tw-odoo-template-' . esc_attr( $kind ) . '">';
		if ( 'row' === $kind ) {
			tw_odoo_suite_admin_row( '__NAME__' );
		} elseif ( 'nav' === $kind ) {
			tw_odoo_suite_admin_nav_row( '__NAME__' );
		} else {
			tw_odoo_suite_admin_group( '__NAME__', array(), 'group' === $kind );
		}
		echo '</template>';
	}
	echo '<input type="hidden" name="tw_odoo_suite_complete" value="1"></div>';
}

/** Only published pages from this site can become Suite navigation destinations. */
function tw_odoo_suite_admin_sanitize_navigation( $raw ) {
	$rows = array();
	$seen = array();
	foreach ( is_array( $raw ) ? array_slice( $raw, 0, 100 ) : array() as $row ) {
		if ( ! is_array( $row ) || ! is_scalar( $row['page_id'] ?? null ) ) {
			continue;
		}
		$id = absint( $row['page_id'] );
		if ( ! $id || isset( $seen[ $id ] ) || 'page' !== get_post_type( $id ) || 'publish' !== get_post_status( $id ) ) {
			continue;
		}
		$seen[ $id ] = true;
		$rows[] = array(
			'page_id' => $id,
			'label' => is_scalar( $row['label'] ?? null ) ? sanitize_text_field( $row['label'] ) : '',
			'order' => is_scalar( $row['order'] ?? null ) ? absint( $row['order'] ) : 0,
			'active' => '1' === ( $row['active'] ?? '' ) ? '1' : '0',
		);
	}
	usort( $rows, function ( $a, $b ) { return $a['order'] <=> $b['order']; } );
	return $rows;
}

add_action( 'save_post_page', 'tw_odoo_suite_admin_save' );
function tw_odoo_suite_admin_save( $post_id ) {
	if ( ! isset( $_POST['tw_odoo_suite_nonce'] ) || ! is_string( $_POST['tw_odoo_suite_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['tw_odoo_suite_nonce'] ) ), 'tw_odoo_suite_save' ) || ! current_user_can( 'edit_post', $post_id ) || wp_is_post_revision( $post_id ) || wp_is_post_autosave( $post_id ) || ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) || ! tw_odoo_suite_admin_eligible( $post_id ) || ! isset( $_POST['tw_odoo_suite'] ) || ! is_array( $_POST['tw_odoo_suite'] ) ) {
		return;
	}
	if ( ( $_POST['tw_odoo_suite_complete'] ?? '' ) !== '1' ) {
		add_filter( 'redirect_post_location', static function( $location ) { return add_query_arg( 'tw_odoo_truncated', '1', $location ); } );
		return;
	}
	$data = tw_odoo_suite_sanitize( wp_unslash( $_POST['tw_odoo_suite'] ) );
	update_post_meta( $post_id, '_tw_odoo_suite', $data );
	if ( 'overview' === ( $data['role'] ?? '' ) && current_user_can( 'manage_options' ) && isset( $_POST['tw_odoo_navigation_present'] ) && '1' === $_POST['tw_odoo_navigation_present'] ) {
		update_option( 'tw_odoo_suite_navigation', tw_odoo_suite_admin_sanitize_navigation( wp_unslash( is_array( $_POST['tw_odoo_navigation'] ?? null ) ? $_POST['tw_odoo_navigation'] : array() ) ), false );
	}
}
add_action('admin_notices',static function(){
	if(($_GET['tw_odoo_truncated']??'')==='1')echo '<div class="notice notice-error"><p>'.esc_html__('I contenuti Odoo non sono stati salvati perché il modulo ha superato il limite del server. I dati precedenti sono intatti: riduci le voci oppure chiedi di aumentare max_input_vars.','ticinoweb-child-theme').'</p></div>';
});
