<?php
/** Shared editorial completion layer. CMS content and approved specialty templates stay authoritative. */
if (!defined('ABSPATH')) exit;

function tw_sitewide_family($post_id=0) {
    $p=get_post($post_id ?: get_queried_object_id());
    if (!$p) return 'editorial';
    if ($p->post_type==='tw_team_member') return 'profile';
    if ($p->ID===(int)get_option('wp_page_for_privacy_policy') || (function_exists('wc_get_page_id') && $p->ID===wc_get_page_id('terms')) || preg_match('/privacy|cookie|termini|condizioni|disclaimer|informativa|^legal$/i',$p->post_name)) return 'legal';
    static $tool_ids;
    if ($tool_ids===null) {
        $tool_ids=[];$locations=get_nav_menu_locations();
        foreach(wp_get_nav_menu_items($locations['footer-actions']??0) ?: [] as $item) $tool_ids[]=absint($item->object_id);
    }
    if (in_array($p->ID,$tool_ids,true) || preg_match('/pagamento|analisi-gratuita|sondaggio|whois|^zoho$|newsletter|unsubscribe|pagina-di-conferma/',$p->post_name)) return 'tools';
    return 'editorial';
}

/** Add semantic anchors and correct duplicate H1 levels without editing any original text. */
function tw_sitewide_prepare_content($html,$family='editorial') {
    $toc=[];$used=[];$counter=0;
    $html=preg_replace_callback('/<h([1-3])\b([^>]*)>(.*?)<\/h\1>/is',static function($m) use (&$toc,&$used,&$counter) {
        $level=max(2,(int)$m[1]);$attrs=$m[2];$text=trim(wp_strip_all_tags($m[3]));
        if (!$text) return '<h'.$level.$attrs.'>'.$m[3].'</h'.$level.'>';
        if(preg_match('/\bid\s*=\s*["\']([^"\']+)["\']/i',$attrs,$id_match)) $id=$id_match[1];
        else { $id='tw-document-'.(++$counter).'-'.sanitize_title($text); $attrs.=' id="'.esc_attr($id).'"'; }
        if(!isset($used[$id])){$toc[]=['id'=>$id,'text'=>$text,'level'=>$level];$used[$id]=true;}
        return '<h'.$level.$attrs.'>'.$m[3].'</h'.$level.'>';
    },$html);
    if ($family!=='legal' || count($toc)<4 || strlen(wp_strip_all_tags($html))<3500) $toc=[];
    return ['html'=>$html,'toc'=>$toc];
}

/** Override only parent-owned page templates; all approved child templates keep priority. */
add_filter('template_include',static function($template){
    if(is_page() && str_starts_with(wp_normalize_path($template),wp_normalize_path(get_template_directory()).'/'))return get_stylesheet_directory().'/page.php';
    return $template;
},125);

function tw_sitewide_is_editorial_request() {
    if(is_singular(['tw_team_member','attachment']))return true;
    if(!is_page() || is_front_page())return false;
    if((function_exists('tw_support_is_page')&&tw_support_is_page()) || (function_exists('tw_projects_is_archive')&&tw_projects_is_archive()) || (function_exists('tw_about_is_page')&&tw_about_is_page()) || (function_exists('tw_recruiting_is_page')&&tw_recruiting_is_page()) || (function_exists('tw_service_enabled')&&tw_service_enabled()))return false;
    if(function_exists('is_cart')&&(is_cart()||is_checkout()||is_account_page()||is_shop()))return false;
    return !in_array(get_page_template_slug(),['page-siti-web.php','page-web-service.php','page-tblog.php'],true) && !is_page(['tblog','siti-web']);
}
add_action('wp_enqueue_scripts',static function(){
    if(!tw_sitewide_is_editorial_request())return;
    $version=wp_get_theme()->get('Version');
    wp_enqueue_style('tw-editorial-page',get_stylesheet_directory_uri().'/assets/css/editorial-page.css',['ticinoweb-child-site'],$version);
},45);

function tw_sitewide_unavailable_content($atts=[],$content=null,$tag='') {
    $legal=str_starts_with($tag,'cmplz-');
    $message=$legal ? __('Questo documento o servizio privacy non è disponibile al momento. Contattaci per richiederlo.','ticinoweb-child-theme') : __('Questo strumento non è disponibile al momento. Contattaci per ricevere assistenza.','ticinoweb-child-theme');
    return '<div class="tw-content-unavailable" role="status"><p>'.esc_html($message).'</p><a class="tw-text-link" href="'.esc_url(tw_home_mapped_url('page_contatti','contatti')).'">'.esc_html__('Contattaci','ticinoweb-child-theme').' <span aria-hidden="true">↗</span></a></div>';
}

/** Honour the same CMS exclusions and robots filter as the native XML sitemap. */
function tw_sitewide_sitemap_html() {
    if(in_array('page',(array)get_option('tw_seo_exclude_sitemap',[]),true))return '';
    $args=apply_filters('wp_sitemaps_posts_query_args',['post_type'=>'page','post_status'=>'publish','posts_per_page'=>-1,'orderby'=>'title','order'=>'ASC'],'page');
    $query=new WP_Query($args);$html='<nav class="tw-html-sitemap" aria-label="'.esc_attr__('Mappa delle pagine','ticinoweb-child-theme').'"><ul>';
    foreach($query->posts as $page)$html.='<li><a href="'.esc_url(get_permalink($page)).'">'.esc_html(get_the_title($page)).'</a></li>';
    return $html.'</ul></nav>';
}

/** Recover obsolete generated thumbnails from their unique original Media Library file. */
function tw_sitewide_restore_media($html) {
    $uploads=wp_upload_dir();$prefix=trailingslashit($uploads['baseurl']).'elementor/thumbs/';
    $marker='/uploads/sites/'.get_current_blog_id().'/';
    if(!str_contains($html,$marker) || !class_exists('WP_HTML_Tag_Processor'))return $html;
    $processor=new WP_HTML_Tag_Processor($html);
    while($processor->next_tag('IMG')){
        $url=$processor->get_attribute('src');
        if(!is_string($url))continue;
        $path=parse_url($url,PHP_URL_PATH)??'';$position=strpos($path,$marker);
        if($position!==false){
            $relative=substr($path,$position+strlen($marker));$file_path=realpath(trailingslashit($uploads['basedir']).$relative);
            if($file_path && str_starts_with(wp_normalize_path($file_path),trailingslashit(wp_normalize_path($uploads['basedir']))) && is_file($file_path) && preg_match('/\.(jpe?g|png|webp|gif|avif)$/i',$relative)){
                $local=trailingslashit($uploads['baseurl']).$relative;
                if($local!==$url){$processor->set_attribute('src',$local);$processor->remove_attribute('srcset');}
                continue;
            }
        }
        if(!str_starts_with($url,$prefix)||!preg_match('/^(.+)-[a-z0-9]{20,}\.(jpe?g|png|webp)$/i',basename($path),$match))continue;
        global $wpdb;
        $file=$match[1].'.'.$match[2];
        $ids=$wpdb->get_col($wpdb->prepare("SELECT MIN(pm.post_id) FROM {$wpdb->postmeta} pm JOIN {$wpdb->posts} p ON p.ID=pm.post_id WHERE pm.meta_key='_wp_attached_file' AND pm.meta_value LIKE %s AND p.post_type='attachment' AND p.post_status='inherit' GROUP BY pm.meta_value LIMIT 2",'%/'.$wpdb->esc_like($file)));
        if(count($ids)===1 && $original=wp_get_attachment_url((int)$ids[0]))$processor->set_attribute('src',$original);
    }
    return $processor->get_updated_html();
}
add_filter('the_content','tw_sitewide_restore_media',12);

/** Never impersonate a missing provider; show a truthful state, leave original editor data intact. */
add_action('init',static function(){
    foreach(['wpdomainwhois','forminator_form','CP_CALCULATED_FIELDS','mailpoet_manage','mailpoet_manage_subscription','mailpoet_page','cmplz-document','cmplz-manage-consent','ticinoweb_contatti'] as $tag)if(!shortcode_exists($tag))add_shortcode($tag,'tw_sitewide_unavailable_content');
    if(!shortcode_exists('trustindex'))add_shortcode('trustindex',static function(){return shortcode_exists('ticinoweb_google_reviews')?do_shortcode('[ticinoweb_google_reviews]'):tw_sitewide_unavailable_content();});
    if(!shortcode_exists('seopress_html_sitemap'))add_shortcode('seopress_html_sitemap','tw_sitewide_sitemap_html');
},100);
