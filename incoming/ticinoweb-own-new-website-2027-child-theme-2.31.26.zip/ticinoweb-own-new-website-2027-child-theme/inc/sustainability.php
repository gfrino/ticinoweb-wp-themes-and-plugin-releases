<?php
/**
 * Pagina Sostenibilità: profilo ESG autodichiarato.
 *
 * I valori si inseriscono nel riquadro «Profilo ESG» della pagina con il template
 * «ticinoWEB — Sostenibilità». Se il punteggio totale è vuoto la sezione non viene mostrata.
 *
 * @package ticinoWEB_Child_Theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

const TW_SUSTAIN_ESG_META = '_tw_sustain_esg';

function tw_sustain_esg_fields() {
	return array(
		'total'  => __( 'Punteggio ESG totale (es. 7,5/10 oppure 78/100)', 'ticinoweb-child-theme' ),
		'year'   => __( 'Anno di riferimento (es. 2026)', 'ticinoweb-child-theme' ),
		'e'      => __( 'Punteggio E — Ambiente (facoltativo)', 'ticinoweb-child-theme' ),
		's'      => __( 'Punteggio S — Persone (facoltativo)', 'ticinoweb-child-theme' ),
		'g'      => __( 'Punteggio G — Governance (facoltativo)', 'ticinoweb-child-theme' ),
	);
}

function tw_sustain_esg( $post_id ) {
	$data = get_post_meta( $post_id, TW_SUSTAIN_ESG_META, true );
	return is_array( $data ) ? $data : array();
}

add_action( 'add_meta_boxes_page', function ( $post ) {
	if ( 'page-sostenibilita.php' !== get_post_meta( $post->ID, '_wp_page_template', true ) ) {
		return;
	}
	add_meta_box( 'tw-sustain-esg', __( 'Profilo ESG (autodichiarato)', 'ticinoweb-child-theme' ), function ( $post ) {
		$d = tw_sustain_esg( $post->ID );
		wp_nonce_field( 'tw_sustain_esg_save', 'tw_sustain_esg_nonce' );
		echo '<p>' . esc_html__( 'Compare nella pagina solo se il punteggio totale è compilato. È un’autovalutazione di ticinoWEB, non una certificazione.', 'ticinoweb-child-theme' ) . '</p>';
		foreach ( tw_sustain_esg_fields() as $key => $label ) {
			printf( '<p><label><strong>%1$s</strong><input type="text" class="widefat" name="tw_sustain_esg[%2$s]" value="%3$s"></label></p>', esc_html( $label ), esc_attr( $key ), esc_attr( $d[ $key ] ?? '' ) );
		}
		printf( '<p><label><strong>%1$s</strong><textarea class="widefat" rows="4" name="tw_sustain_esg[method]">%2$s</textarea></label></p>', esc_html__( 'Come è calcolato (facoltativo)', 'ticinoweb-child-theme' ), esc_textarea( $d['method'] ?? '' ) );
	}, 'page', 'normal', 'default' );
} );

add_action( 'save_post_page', function ( $post_id ) {
	if ( empty( $_POST['tw_sustain_esg_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['tw_sustain_esg_nonce'] ) ), 'tw_sustain_esg_save' ) || ! current_user_can( 'edit_post', $post_id ) || wp_is_post_revision( $post_id ) || ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) ) {
		return;
	}
	$raw   = isset( $_POST['tw_sustain_esg'] ) && is_array( $_POST['tw_sustain_esg'] ) ? wp_unslash( $_POST['tw_sustain_esg'] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
	$clean = array();
	foreach ( array_keys( tw_sustain_esg_fields() ) as $key ) {
		$clean[ $key ] = sanitize_text_field( $raw[ $key ] ?? '' );
	}
	$clean['method'] = sanitize_textarea_field( $raw['method'] ?? '' );
	update_post_meta( $post_id, TW_SUSTAIN_ESG_META, $clean );
} );
