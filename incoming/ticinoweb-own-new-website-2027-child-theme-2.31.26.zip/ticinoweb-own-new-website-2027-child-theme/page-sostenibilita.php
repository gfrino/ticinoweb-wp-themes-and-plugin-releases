<?php
/**
 * Template Name: ticinoWEB — Sostenibilità
 *
 * Pagina editoriale con accenti naturali tenui (salvia, carta calda), nello stile del resto del sito.
 * Contenuto dall'editor: il titolo è l'H1, l'estratto è il testo introduttivo, l'immagine in evidenza
 * è l'illustrazione in alto. Ogni impegno è un blocco «Gruppo» con classe `tw-pillar` che contiene
 * un'immagine, un titolo H2 e un paragrafo. Il profilo ESG si compila nel riquadro «Profilo ESG»
 * (vedi inc/sustainability.php).
 */
if ( ! defined( 'ABSPATH' ) ) exit;
get_header();
while ( have_posts() ) :
	the_post();
	$tw_kicker = (string) get_post_meta( get_the_ID(), '_tw_sustain_kicker', true );
	$tw_kicker = '' !== $tw_kicker ? $tw_kicker : __( 'Il nostro impegno ambientale', 'ticinoweb-child-theme' );
	$tw_esg    = function_exists( 'tw_sustain_esg' ) ? tw_sustain_esg( get_the_ID() ) : array();
	?>
<main id="main-content" class="tw-sustain">
	<section class="tw-sustain-hero">
		<div class="tw-shell tw-sustain-hero__grid<?php echo has_post_thumbnail() ? '' : ' is-single'; ?>">
			<div class="tw-sustain-hero__copy">
				<p class="tw-sustain-kicker">
					<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M5 20C5 11 10 5 20 4c0 9-5 15-13 15"/><path d="M5 20 13 12"/></svg>
					<?php echo esc_html( $tw_kicker ); ?>
				</p>
				<h1><?php the_title(); ?></h1>
				<?php if ( has_excerpt() ) : ?><p class="tw-sustain-lead"><?php echo esc_html( get_the_excerpt() ); ?></p><?php endif; ?>
				<?php if ( ! empty( $tw_esg['total'] ) ) : ?>
					<a class="tw-text-link" href="#esg"><?php esc_html_e( 'Il nostro profilo ESG', 'ticinoweb-child-theme' ); ?> <span aria-hidden="true">↓</span></a>
				<?php endif; ?>
			</div>
			<?php if ( has_post_thumbnail() ) : ?>
				<figure class="tw-sustain-hero__art"><?php the_post_thumbnail( 'large', array( 'loading' => 'eager', 'decoding' => 'async', 'alt' => '' ) ); ?></figure>
			<?php endif; ?>
		</div>
	</section>

	<section class="tw-sustain-body">
		<div class="tw-shell tw-sustain-content">
			<?php the_content(); ?>
		</div>
	</section>

	<?php if ( ! empty( $tw_esg['total'] ) ) : ?>
	<section class="tw-esg" id="esg" aria-labelledby="tw-esg-title">
		<div class="tw-shell tw-esg__grid">
			<div class="tw-esg__brand">
				<svg class="tw-esg__logo" viewBox="0 0 132 132" role="img" aria-label="ESG">
					<circle cx="66" cy="66" r="62" fill="#f5f3ed" stroke="#071f2a" stroke-width="3"/>
					<circle cx="66" cy="66" r="50" fill="none" stroke="#8fa896" stroke-width="2" stroke-dasharray="2 6" stroke-linecap="round"/>
					<text x="66" y="78" text-anchor="middle" font-family="inherit" font-size="38" font-weight="800" letter-spacing="1" fill="#071f2a">ESG</text>
					<path d="M92 30c-10 1-17 7-18 16 9 0 16-6 18-16z" fill="#8fa896"/>
				</svg>
				<p class="tw-sustain-kicker"><?php esc_html_e( 'Profilo ESG', 'ticinoweb-child-theme' ); ?></p>
				<h2 id="tw-esg-title"><?php esc_html_e( 'Ambiente, persone, governance', 'ticinoweb-child-theme' ); ?></h2>
				<p class="tw-esg__note"><?php esc_html_e( 'Punteggio autodichiarato da ticinoWEB: non è una certificazione di un ente terzo.', 'ticinoweb-child-theme' ); ?></p>
			</div>
			<div class="tw-esg__score">
				<p class="tw-esg__total"><span><?php echo esc_html( $tw_esg['total'] ); ?></span><small><?php esc_html_e( 'punteggio ESG autodichiarato', 'ticinoweb-child-theme' ); ?><?php echo ! empty( $tw_esg['year'] ) ? ' · ' . esc_html( $tw_esg['year'] ) : ''; ?></small></p>
				<?php foreach ( array( 'e' => __( 'Environment — Ambiente', 'ticinoweb-child-theme' ), 's' => __( 'Social — Persone', 'ticinoweb-child-theme' ), 'g' => __( 'Governance', 'ticinoweb-child-theme' ) ) as $tw_k => $tw_l ) : ?>
					<?php if ( '' !== (string) ( $tw_esg[ $tw_k ] ?? '' ) ) : ?>
						<div class="tw-esg__row"><strong><?php echo esc_html( strtoupper( $tw_k ) ); ?></strong><span><?php echo esc_html( $tw_l ); ?></span><em><?php echo esc_html( $tw_esg[ $tw_k ] ); ?></em></div>
					<?php endif; ?>
				<?php endforeach; ?>
				<?php if ( ! empty( $tw_esg['method'] ) ) : ?><div class="tw-esg__method"><?php echo wp_kses_post( wpautop( $tw_esg['method'] ) ); ?></div><?php endif; ?>
			</div>
		</div>
	</section>
	<?php endif; ?>
</main>
	<?php
endwhile;
get_footer();
