<?php
if (!defined('ABSPATH')) exit;
$d=tw_recruiting_data();$jobs=tw_recruiting_open_positions($d);$portal=tw_recruiting_url($d['portal_url']??'');
get_header();
?>
<!-- THESIS: Real people and verified opportunities, not generic HR illustration.
OWN-WORLD: Inherited Digital Proof Studio: warm paper, navy, local sans, editorial lines.
STORY: Understand disciplines, read real openings, apply only on the official external portal.
FIRST VIEWPORT: Half copy, half authentic photograph, compact heading and positions anchor.
FORM: User-specified recruiting composition; no concept seed required for a pinned brief.
FINISH: unreviewed and undocumented is unfinished; this build ends with the finish review, the verdict, and DESIGN.md -->
<main id="main-content" class="tw-recruiting-page">
 <section class="tw-recruiting-hero"><div class="tw-shell tw-recruiting-split<?php echo empty($d['hero_media_id'])?' tw-recruiting-split--text':''; ?>"><div>
  <?php if(!empty($d['hero_eyebrow'])): ?><p class="tw-kicker"><?php echo esc_html($d['hero_eyebrow']); ?></p><?php endif; ?>
  <h1><?php echo nl2br(esc_html($d['hero_title']??get_the_title())); ?></h1>
  <div class="tw-recruiting-copy"><?php echo wp_kses_post(wpautop($d['hero_text']??'')); ?></div>
  <?php if(!empty($d['hero_cta'])): ?><a class="tw-text-link" href="#posizioni"><?php echo esc_html($d['hero_cta']); ?><span aria-hidden="true">↗</span></a><?php endif; ?>
 </div><?php if(!empty($d['hero_media_id'])): ?><figure><?php echo wp_get_attachment_image($d['hero_media_id'],'large',false,['loading'=>'eager','fetchpriority'=>'high','sizes'=>'(max-width:900px) 100vw, 50vw']); ?><?php if($caption=wp_get_attachment_caption($d['hero_media_id'])): ?><figcaption><?php echo esc_html($caption); ?></figcaption><?php endif; ?></figure><?php endif; ?></div></section>
 <?php if(!empty($d['values'])): ?><section class="tw-recruiting-values"><div class="tw-shell">
 <?php if(!empty($d['values_eyebrow'])): ?><p class="tw-kicker"><?php echo esc_html($d['values_eyebrow']); ?></p><?php endif; ?>
 <h2><?php echo nl2br(esc_html($d['values_title']??'')); ?></h2><div class="tw-recruiting-values-grid">
 <?php foreach($d['values'] as $row): ?><article><?php if(!empty($row['number'])): ?><span class="tw-recruiting-number" aria-hidden="true"><?php echo esc_html($row['number']); ?></span><?php endif; ?><h3><?php echo esc_html($row['title']); ?></h3><p><?php echo esc_html($row['text']??''); ?></p></article><?php endforeach; ?>
 </div></div></section><?php endif; ?>
 <?php if(!empty($d['areas'])): ?><section class="tw-recruiting-areas"><div class="tw-shell"><h2><?php echo esc_html($d['areas_title']??''); ?></h2><p class="tw-recruiting-copy"><?php echo esc_html($d['areas_text']??''); ?></p><ul class="tw-recruiting-area-list">
 <?php foreach($d['areas'] as $row): ?><li><?php tw_recruiting_area_icon($row['icon']??''); ?><h3><?php echo esc_html($row['title']); ?></h3><?php if(!empty($row['text'])): ?><p><?php echo esc_html($row['text']); ?></p><?php endif; ?></li><?php endforeach; ?>
 </ul></div></section><?php endif; ?>
 <section id="posizioni" class="tw-recruiting-positions"><div class="tw-shell"><h2><?php echo esc_html($d['positions_title']??''); ?></h2><p class="tw-recruiting-copy"><?php echo esc_html($d['positions_text']??''); ?></p>
 <?php if($jobs): ?><ul class="tw-recruiting-job-list">
 <?php foreach($jobs as $job): $url=tw_recruiting_job_url($job,$d); ?><li><div><h3><?php if($url): ?><a href="<?php echo esc_url($url); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html($job['title']); ?><span class="tw-sr-only"> — <?php esc_html_e('apri sul portale recruiting in una nuova scheda','ticinoweb-child-theme'); ?></span></a><?php else: echo esc_html($job['title']); endif; ?></h3><?php if(!empty($job['text'])): ?><p><?php echo esc_html($job['text']); ?></p><?php endif; ?></div><dl><?php foreach(['area'=>__('Area','ticinoweb-child-theme'),'location'=>__('Sede','ticinoweb-child-theme'),'employment'=>__('Tipo impiego','ticinoweb-child-theme')] as $key=>$label): if(empty($job[$key]))continue; ?><div><dt><?php echo esc_html($label); ?></dt><dd><?php echo esc_html($job[$key]); ?></dd></div><?php endforeach; ?></dl><?php if($url): ?><span class="tw-recruiting-job-arrow" aria-hidden="true">↗</span><?php endif; ?></li><?php endforeach; ?>
 </ul><?php else: ?><div class="tw-recruiting-empty"><h3><?php echo esc_html($d['empty_title']??''); ?></h3><p><?php echo esc_html($d['empty_text']??''); ?></p></div><?php endif; ?>
 <div class="tw-recruiting-portal"><p><?php echo esc_html($d['portal_notice']??''); ?></p><?php if($portal&&!empty($d['portal_cta'])): ?><a class="tw-button" href="<?php echo esc_url($portal); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html($d['portal_cta']); ?><span aria-hidden="true">↗</span></a><?php endif; ?></div>
 </div></section>
 <?php if(!empty($d['process'])||!empty($d['note_text'])): ?><section class="tw-recruiting-process"><div class="tw-shell">
 <?php if(!empty($d['process'])): ?><h2><?php echo esc_html($d['process_title']??''); ?></h2><ol><?php foreach($d['process'] as $row): ?><li><?php if(!empty($row['number'])): ?><span aria-hidden="true"><?php echo esc_html($row['number']); ?></span><?php endif; ?><div><h3><?php echo esc_html($row['title']); ?></h3><p><?php echo esc_html($row['text']??''); ?></p></div></li><?php endforeach; ?></ol><?php endif; ?>
 <?php if(!empty($d['note_text'])): ?><details class="tw-recruiting-note"><summary><?php echo esc_html($d['note_title']??''); ?></summary><div class="tw-recruiting-copy"><?php echo wp_kses_post(wpautop($d['note_text'])); ?></div></details><?php endif; ?>
 </div></section><?php endif; ?>
 <?php if(!empty($d['editorial_media_id'])): ?><section class="tw-recruiting-editorial"><figure class="tw-shell"><?php echo wp_get_attachment_image($d['editorial_media_id'],'large',false,['loading'=>'lazy','sizes'=>'100vw']); ?></figure></section><?php endif; ?>
 <?php if(!empty($d['final_title'])): ?><section class="tw-recruiting-final tw-web-final-cta"><div class="tw-shell"><h2><?php echo esc_html($d['final_title']); ?></h2><p><?php echo esc_html($d['final_text']??''); ?></p><?php if($portal&&!empty($d['final_cta'])): ?><a class="tw-button" href="<?php echo esc_url($portal); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html($d['final_cta']); ?><span aria-hidden="true">↗</span></a><?php endif; ?></div></section><?php endif; ?>
</main>
<?php get_footer(); ?>
