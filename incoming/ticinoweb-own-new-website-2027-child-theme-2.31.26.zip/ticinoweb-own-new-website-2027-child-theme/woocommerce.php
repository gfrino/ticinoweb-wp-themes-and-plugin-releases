<?php
/** Native WooCommerce catalogue and endpoint shell. */
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header();
?>
<main class="tw-commerce woocommerce">
	<div class="tw-shell tw-commerce__inner">
		<?php if ( is_woocommerce() ) : ?>
			<?php woocommerce_content(); ?>
		<?php else : ?>
			<?php while ( have_posts() ) : the_post(); ?>
				<header class="tw-commerce__heading"><h1><?php echo esc_html( get_the_title() ); ?></h1></header>
				<div class="tw-commerce__content"><?php the_content(); ?></div>
			<?php endwhile; ?>
		<?php endif; ?>
	</div>
</main>
<?php get_footer();
