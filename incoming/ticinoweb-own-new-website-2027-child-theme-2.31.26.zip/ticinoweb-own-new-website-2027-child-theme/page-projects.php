<?php
/**
 * Unified template for portfolio archives and legacy reference pages.
 *
 * @package ticinoWEB_Child_Theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$tw_context = tw_projects_get_context();
$tw_batch   = tw_projects_query_batch( $tw_context, 1, 12 );
$tw_contact = tw_home_mapped_url( 'page_contatti', 'contatti' );

get_header();
?>
<main class="tw-project-archive" data-project-archive data-rest-url="<?php echo esc_url( rest_url( 'ticinoweb/v1/projects' ) ); ?>" data-taxonomy="<?php echo esc_attr( $tw_context['taxonomy'] ); ?>" data-term="<?php echo esc_attr( $tw_context['term_slug'] ); ?>" data-pages="<?php echo esc_attr( (string) $tw_batch['pages'] ); ?>" data-page="1">
	<section class="tw-project-archive__hero">
		<div class="tw-shell">
			<p class="tw-kicker"><?php echo esc_html( $tw_context['eyebrow'] ); ?></p>
			<div class="tw-project-archive__hero-grid">
				<h1><?php echo esc_html( $tw_context['title'] ); ?></h1>
				<p><?php echo esc_html( $tw_context['intro'] ); ?></p>
			</div>
		</div>
	</section>

	<section class="tw-project-archive__work" aria-label="<?php esc_attr_e( 'Esplora le realizzazioni', 'ticinoweb-child-theme' ); ?>">
		<div class="tw-shell">
			<nav class="tw-project-filters" aria-label="<?php esc_attr_e( 'Filtri delle realizzazioni', 'ticinoweb-child-theme' ); ?>">
				<div class="tw-project-filters__tabs">
					<a href="<?php echo esc_url( tw_home_mapped_url( 'page_referenze', 'referenze' ) ); ?>"<?php echo ! $tw_context['taxonomy'] ? ' aria-current="page"' : ''; ?>><?php esc_html_e( 'Tutti', 'ticinoweb-child-theme' ); ?></a>
					<?php if ( $tw_context['sector_terms'] ) : ?><span<?php echo $tw_context['taxonomy'] === $tw_context['schema']['sector_taxonomy'] ? ' class="is-active"' : ''; ?>><?php esc_html_e( 'Settori', 'ticinoweb-child-theme' ); ?></span><?php endif; ?>
				</div>
				<div class="tw-project-filters__links">
					<?php foreach ( $tw_context['type_terms'] as $tw_term ) : ?>
						<a href="<?php echo esc_url( tw_projects_term_url( $tw_context['schema']['type_taxonomy'], $tw_term ) ); ?>"<?php echo (int) $tw_context['term_id'] === (int) $tw_term->term_id ? ' aria-current="page"' : ''; ?>><?php echo esc_html( $tw_term->name ); ?></a>
					<?php endforeach; ?>
					<?php foreach ( $tw_context['sector_terms'] as $tw_term ) : ?>
						<a class="is-sector" href="<?php echo esc_url( tw_projects_term_url( $tw_context['schema']['sector_taxonomy'], $tw_term ) ); ?>"<?php echo (int) $tw_context['term_id'] === (int) $tw_term->term_id ? ' aria-current="page"' : ''; ?>><?php echo esc_html( $tw_term->name ); ?></a>
					<?php endforeach; ?>
				</div>
			</nav>

			<div class="tw-project-archive__meta">
				<p><?php echo esc_html( sprintf( _n( '%s progetto', '%s progetti', $tw_batch['total'], 'ticinoweb-child-theme' ), number_format_i18n( $tw_batch['total'] ) ) ); ?></p>
			</div>

			<div class="tw-project-archive__grid" data-project-archive-grid>
				<?php foreach ( $tw_batch['items'] as $tw_project ) : ?><?php echo tw_projects_render_card( $tw_project ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?><?php endforeach; ?>
			</div>

			<?php if ( ! $tw_batch['items'] ) : ?><p class="tw-project-archive__empty"><?php esc_html_e( 'Nessuna realizzazione disponibile per questo filtro.', 'ticinoweb-child-theme' ); ?></p><?php endif; ?>
			<p class="tw-project-archive__status" role="status" aria-live="polite" data-project-archive-status></p>
			<button class="tw-project-archive__more" type="button" data-project-archive-more<?php echo $tw_batch['pages'] > 1 ? '' : ' hidden'; ?>><?php esc_html_e( 'Carica altri progetti', 'ticinoweb-child-theme' ); ?> <span aria-hidden="true">+</span></button>
		</div>
	</section>

	<section class="tw-project-archive__cta">
		<div class="tw-shell">
			<p class="tw-kicker"><?php esc_html_e( 'Il prossimo progetto', 'ticinoweb-child-theme' ); ?></p>
			<div><h2><?php esc_html_e( 'Hai un’idea da trasformare in qualcosa di concreto?', 'ticinoweb-child-theme' ); ?></h2><a class="tw-button" href="<?php echo esc_url( $tw_contact ); ?>"><?php esc_html_e( 'Parliamone', 'ticinoweb-child-theme' ); ?> <span aria-hidden="true">↗</span></a></div>
		</div>
	</section>
</main>
<?php get_footer(); ?>
