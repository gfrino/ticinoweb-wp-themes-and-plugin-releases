<?php
/** Native public profile, not a promotional article. */
get_header();
while(have_posts()){the_post();get_template_part('template-parts/editorial-page');}
get_footer();
