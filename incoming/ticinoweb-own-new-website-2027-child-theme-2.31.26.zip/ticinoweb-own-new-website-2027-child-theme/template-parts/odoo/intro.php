<?php
/** Optional editorial image uses the existing Service intro media field. */
if (!defined('ABSPATH')) exit;
$service=$args['service']??[];
if(empty($service['intro_text'])) return;
$image=tw_odoo_suite_image_id($service['intro_media_id']??0);
?>
<section class="tw-odoo-section"><div class="tw-shell tw-odoo-intro<?php echo $image?' has-editorial-media':''; ?>">
<?php if($image): ?><div class="tw-odoo-intro-copy"><?php endif; ?>
<h2><?php echo esc_html($service['intro_title']??''); ?></h2>
<div><?php echo tw_odoo_suite_text($service['intro_text']); ?></div>
<?php if($image): ?></div><figure class="tw-odoo-editorial-visual"><?php tw_odoo_suite_media($image); ?></figure><?php endif; ?>
</div></section>
