<?php $d=$args['data'];if(empty($d['media_id'])&&empty($d['video_url'])&&empty($d['appstore_url']))return; ?>
<section class="tw-odoo-section"><div class="tw-shell"><h2><?php echo esc_html($d['media_title']??''); ?></h2>
<?php if(!empty($d['media_id'])): ?><figure class="tw-odoo-visual"><?php tw_odoo_suite_media($d['media_id']); ?></figure><?php endif; ?>
<div class="tw-odoo-actions"><?php if(!empty($d['video_url'])): ?><a class="tw-text-link" href="<?php echo esc_url($d['video_url']); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html(($d['video_title']??'')?:__('Guarda il video su YouTube','ticinoweb-child-theme')); ?> ↗</a><?php endif; ?><?php if(!empty($d['appstore_url'])): ?><a class="tw-text-link" href="<?php echo esc_url($d['appstore_url']); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html($d['appstore_label']??''); ?> ↗</a><?php endif; ?></div>
</div></section>
