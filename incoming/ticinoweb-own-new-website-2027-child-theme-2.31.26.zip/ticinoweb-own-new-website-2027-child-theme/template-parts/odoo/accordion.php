<div class="tw-odoo-accordion" data-odoo-accordion>
<?php foreach($args['groups'] as $i=>$g):$id='odoo-'.get_the_ID().'-'.$args['prefix'].'-'.$i; ?>
<section class="tw-odoo-group"><h3><button type="button" id="<?php echo esc_attr($id.'-button'); ?>" aria-expanded="true" aria-controls="<?php echo esc_attr($id); ?>"><span class="tw-odoo-number" aria-hidden="true"><?php echo esc_html(($g['eyebrow']??'')?:sprintf('%02d',$i+1)); ?></span><span><?php echo esc_html($g['title']); ?></span><span class="tw-odoo-toggle" aria-hidden="true">−</span></button></h3>
<div id="<?php echo esc_attr($id); ?>" class="tw-odoo-panel" role="region" aria-labelledby="<?php echo esc_attr($id.'-button'); ?>">
<?php if(!empty($g['text'])): ?><div class="tw-odoo-group-intro"><?php echo tw_odoo_suite_text($g['text']); ?></div><?php endif; ?>
<div class="tw-odoo-modules"><?php $modules=tw_odoo_suite_active_rows($g['rows']??[]);foreach($modules as $row)get_template_part('template-parts/odoo/module-card',null,['row'=>$row,'hide_title'=>count($modules)===1&&$row['title']===$g['title']]); get_template_part('template-parts/odoo/specialist',null,['id'=>$g['team_member_id']??0]); ?></div>
<?php if(!empty($g['media_id'])): ?><figure class="tw-odoo-visual"><?php tw_odoo_suite_media($g['media_id']); ?></figure><?php endif; ?>
<?php if(!empty($g['video_url'])): ?><a class="tw-text-link" href="<?php echo esc_url($g['video_url']); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e('Guarda il video su YouTube','ticinoweb-child-theme'); ?> ↗</a><?php endif; ?>
</div></section>
<?php endforeach; ?></div>
