<?php
/** Native team record: one source for the portrait, name and role. */
if ( ! defined( 'ABSPATH' ) ) exit;
$person_id = tw_odoo_suite_team_id( $args['id'] ?? 0 );
if ( ! $person_id || get_post_meta( $person_id, 'tw_active', true ) !== '1' ) return;
$photo_id = get_post_thumbnail_id( $person_id );
if ( ! $photo_id ) return;
$name = get_the_title( $person_id );
$role = get_post_meta( $person_id, 'tw_role', true );
?>
<figure class="tw-odoo-specialist">
	<?php echo wp_get_attachment_image( $photo_id, 'medium_large', false, array( 'alt' => $name, 'loading' => 'lazy', 'decoding' => 'async', 'sizes' => '(max-width: 600px) 280px, 240px' ) ); ?>
	<figcaption><h4><?php echo esc_html( $name ); ?></h4><?php if ( $role ) : ?><p><?php echo esc_html( $role ); ?></p><?php endif; ?></figcaption>
</figure>
