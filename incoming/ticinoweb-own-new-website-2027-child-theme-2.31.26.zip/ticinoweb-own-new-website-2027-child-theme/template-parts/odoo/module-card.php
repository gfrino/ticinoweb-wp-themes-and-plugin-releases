<?php $row=$args['row'];$level=($args['level']??4)===3?3:4; ?>
<article class="tw-odoo-module">
<?php if($icon=tw_odoo_icon_url($row['icon']??'')): ?><img class="tw-odoo-icon" src="<?php echo esc_url($icon); ?>" alt="" width="64" height="64" loading="lazy" decoding="async"><?php endif; ?>
<?php if(empty($args['hide_title']))echo '<h'.$level.'>'.esc_html($row['title']).'</h'.$level.'>'; ?>
<?php echo tw_odoo_suite_text($row['text']??''); ?>
<?php if(!empty($row['url'])): ?><a class="tw-text-link" href="<?php echo esc_url($row['url']); ?>"><?php echo esc_html(($row['cta']??'')?:__('Scopri di più','ticinoweb-child-theme')); ?> <span aria-hidden="true">↗</span></a><?php endif; ?>
</article>
