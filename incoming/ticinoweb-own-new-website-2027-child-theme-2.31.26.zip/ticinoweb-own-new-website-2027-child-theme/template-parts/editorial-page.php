<?php
/** Compact reading/operating surface inside the approved ticinoWEB world. */
$family=tw_sitewide_family(get_the_ID());
$copy=apply_filters('the_content',get_the_content());
$is_survey=function_exists('tw_sitewide_survey_fields') && (bool)tw_sitewide_survey_fields(get_the_ID());
if($is_survey)$copy=tw_sitewide_survey_intro($copy,get_the_title());
if($family==='profile' && !trim(wp_strip_all_tags($copy)))$copy=wpautop(esc_html((string)get_post_meta(get_the_ID(),'tw_full_bio',true)));
$document=tw_sitewide_prepare_content($copy,$family);
$manual_excerpt=trim((string)get_post_field('post_excerpt',get_the_ID()));
$label=$family==='legal'?__('Informazioni legali','ticinoweb-child-theme'):($family==='tools'?__('Strumenti ticinoWEB','ticinoweb-child-theme'):($family==='profile'?__('Team','ticinoweb-child-theme'):''));
?>
<main class="tw-editorial-page tw-editorial-page--<?php echo esc_attr($family); ?><?php echo $is_survey?' tw-editorial-page--survey':''; ?>">
    <article <?php post_class(); ?>>
        <header class="tw-editorial-hero tw-shell">
            <?php if($label): ?><p class="tw-kicker"><?php echo esc_html($label); ?></p><?php endif; ?>
            <h1><?php the_title(); ?></h1>
            <?php if($family==='profile' && $role=get_post_meta(get_the_ID(),'tw_role',true)): ?><p class="tw-editorial-deck"><?php echo esc_html($role); ?></p><?php elseif($manual_excerpt): ?><div class="tw-editorial-deck"><?php echo wp_kses_post(wpautop($manual_excerpt)); ?></div><?php endif; ?>
        </header>
        <?php if($family!=='legal' && has_post_thumbnail()): ?><figure class="tw-editorial-featured tw-shell"><?php the_post_thumbnail('large',['loading'=>'eager','decoding'=>'async','sizes'=>'(max-width: 700px) 92vw, 880px']); ?></figure><?php endif; ?>
        <div class="tw-editorial-layout tw-shell<?php echo $document['toc']?' has-toc':''; ?>">
            <?php if($document['toc']): ?><nav class="tw-document-toc" aria-label="<?php esc_attr_e('Indice del documento','ticinoweb-child-theme'); ?>"><p><?php esc_html_e('In questa pagina','ticinoweb-child-theme'); ?></p><ol><?php foreach($document['toc'] as $item): ?><li><a href="#<?php echo esc_attr($item['id']); ?>"><?php echo esc_html($item['text']); ?></a></li><?php endforeach; ?></ol></nav><?php endif; ?>
            <div class="tw-editorial-content entry-content">
                <?php echo $document['html']; // Native the_content output: preserve trusted editor blocks, shortcodes and embeds. ?>
                <?php if($family==='profile'): foreach(['tw_specializations'=>__('Competenze','ticinoweb-child-theme'),'tw_languages'=>__('Lingue','ticinoweb-child-theme')] as $key=>$title): if($value=get_post_meta(get_the_ID(),$key,true)): ?><h2><?php echo esc_html($title); ?></h2><p><?php echo esc_html($value); ?></p><?php endif; endforeach; endif; ?>
                <?php if($is_survey)get_template_part('template-parts/legacy-survey'); ?>
                <?php wp_link_pages(); ?>
            </div>
        </div>
    </article>
</main>
