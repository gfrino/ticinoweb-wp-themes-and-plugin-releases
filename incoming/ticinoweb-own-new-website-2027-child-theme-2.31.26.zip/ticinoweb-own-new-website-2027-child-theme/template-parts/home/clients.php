<?php
$tw_clients = $args['clients'] ?? array();

$tw_render_client = static function ( $tw_client, $interactive = true ) {
	$tw_label = $tw_client['label'] ?? '';
	$tw_url   = $tw_client['url'] ?? '';
	$tw_tag   = $interactive && $tw_url ? 'a' : 'span';
	?>
	<<?php echo esc_html( $tw_tag ); ?> class="tw-partner-logo tw-client-logo" role="listitem"<?php if ( 'a' === $tw_tag ) : ?> href="<?php echo esc_url( $tw_url ); ?>" target="_blank" rel="noopener noreferrer" aria-label="<?php echo esc_attr( $tw_label ); ?>"<?php elseif ( $tw_url ) : ?> tabindex="-1"<?php endif; ?>>
		<?php echo wp_get_attachment_image( $tw_client['image_id'], 'medium', false, array( 'alt' => $tw_label, 'loading' => 'lazy', 'decoding' => 'async', 'sizes' => '(max-width: 767px) 136px, 172px' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
	</<?php echo esc_html( $tw_tag ); ?>>
	<?php
};
?>
<?php if ( $tw_clients ) : ?>
<section class="tw-partners tw-clients" aria-labelledby="tw-clients-title" data-partner-marquee>
	<div class="tw-shell">
		<header class="tw-partners__head tw-clients__head" data-home-reveal>
			<h2 id="tw-clients-title"><?php esc_html_e( 'Credono in noi.', 'ticinoweb-child-theme' ); ?></h2>
		</header>
	</div>

	<div class="tw-partners__viewport">
		<div class="tw-partners__rail">
			<div class="tw-partners__track" data-partner-track role="list">
				<div class="tw-partners__sequence">
					<?php foreach ( $tw_clients as $tw_client ) : ?>
						<?php $tw_render_client( $tw_client, true ); ?>
					<?php endforeach; ?>
				</div>
				<div class="tw-partners__sequence" aria-hidden="true">
					<?php foreach ( $tw_clients as $tw_client ) : ?>
						<?php $tw_render_client( $tw_client, false ); ?>
					<?php endforeach; ?>
				</div>
			</div>
		</div>
	</div>
</section>
<?php endif; ?>
