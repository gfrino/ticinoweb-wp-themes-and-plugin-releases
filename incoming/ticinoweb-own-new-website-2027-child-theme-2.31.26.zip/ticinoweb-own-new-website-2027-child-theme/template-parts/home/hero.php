<?php
$tw_slides = $args['slides'] ?? array();
$tw_slide_count = count( $tw_slides );
$tw_reviews = is_array( $args['reviews'] ?? null ) ? $args['reviews'] : array();
$tw_partners = array_slice( is_array( $args['partners'] ?? null ) ? $args['partners'] : array(), 0, 3 );
$tw_published_projects = absint( $args['published_project_count'] ?? 0 );
$tw_hero_portrait_id = absint( $args['hero_portrait_id'] ?? 0 );
$tw_has_proof = ! empty( $tw_reviews['rating'] ) || $tw_published_projects || $tw_partners;
?>
<section class="tw-hero" aria-label="<?php esc_attr_e( 'Presentazione ticinoWEB', 'ticinoweb-child-theme' ); ?>" data-hero-slider data-slide-count="<?php echo esc_attr( (string) $tw_slide_count ); ?>">
	<div class="tw-hero__track" data-hero-track>
		<?php foreach ( $tw_slides as $tw_index => $tw_slide ) : ?>
			<?php
			$tw_dynamic = $tw_slide['dynamic_title'] ?? array();
			$tw_has_dynamic_title = ! empty( $tw_dynamic['enabled'] ) && ! empty( $tw_dynamic['terms'] );
			$tw_initial_term = $tw_has_dynamic_title ? (string) $tw_dynamic['terms'][0] : '';
			$tw_accessible_title = $tw_has_dynamic_title
				? trim( implode( ' ', array( $tw_dynamic['before'], $tw_initial_term, $tw_dynamic['after'] ) ) )
				: (string) $tw_slide['title'];
			$tw_heading_tag = 0 === $tw_index ? 'h1' : 'h2';
			?>
			<article class="tw-hero__slide<?php echo 0 === $tw_index ? ' is-active' : ''; ?>" data-hero-slide aria-hidden="<?php echo 0 === $tw_index ? 'false' : 'true'; ?>">
				<div class="tw-hero__backdrop" data-hero-media aria-hidden="true">
					<?php
					if ( 'video' === ( $tw_slide['media_type'] ?? 'image' ) ) {
						?>
						<video class="tw-hero__video" data-hero-video autoplay muted playsinline preload="<?php echo 0 === $tw_index ? 'auto' : 'metadata'; ?>" tabindex="-1">
							<source src="<?php echo esc_url( $tw_slide['image'] ); ?>"<?php echo ! empty( $tw_slide['mime_type'] ) ? ' type="' . esc_attr( $tw_slide['mime_type'] ) . '"' : ''; ?>>
						</video>
						<?php
					} elseif ( $tw_slide['image_id'] ) {
						echo wp_get_attachment_image(
							$tw_slide['image_id'],
							'full',
							false,
							array(
								'alt'           => '',
								'loading'       => 0 === $tw_index ? 'eager' : 'lazy',
								'fetchpriority' => 0 === $tw_index ? 'high' : 'auto',
								'decoding'      => 'async',
								'sizes'         => '100vw',
							)
						); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
					} elseif ( $tw_slide['image'] ) {
						printf( '<img src="%1$s" alt="" loading="%2$s" fetchpriority="%3$s" decoding="async">', esc_url( $tw_slide['image'] ), 0 === $tw_index ? 'eager' : 'lazy', 0 === $tw_index ? 'high' : 'auto' );
					}
					?>
				</div>
				<?php if ( 0 === $tw_index && $tw_hero_portrait_id ) : ?>
					<figure class="tw-hero__portrait" aria-hidden="true">
						<?php
						echo wp_get_attachment_image(
							$tw_hero_portrait_id,
							'full',
							false,
							array(
								'alt'           => '',
								'loading'       => 'eager',
								'fetchpriority' => 'auto',
								'decoding'      => 'async',
								'sizes'         => '(max-width: 767px) 74vw, (max-width: 1180px) 52vw, 39vw',
							)
						); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
						?>
					</figure>
				<?php endif; ?>
				<div class="tw-shell tw-hero__inner">
					<div class="tw-hero__copy">
						<p class="tw-kicker"><?php esc_html_e( 'Web Design · Locarno · Ticino', 'ticinoweb-child-theme' ); ?></p>
						<?php if ( $tw_has_dynamic_title ) : ?>
							<<?php echo $tw_heading_tag; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?> class="tw-hero-dynamic-title" data-hero-rotator data-interval="<?php echo esc_attr( (string) $tw_dynamic['interval'] ); ?>">
								<span class="screen-reader-text"><?php echo esc_html( $tw_accessible_title ); ?></span>
								<span class="tw-hero-dynamic-title__visual" aria-hidden="true">
									<span class="tw-hero-dynamic-title__before"><?php echo esc_html( $tw_dynamic['before'] ); ?></span>
									<span class="tw-hero-dynamic-title__slot">
										<?php foreach ( $tw_dynamic['terms'] as $tw_term_index => $tw_term ) : ?>
											<span class="tw-hero-dynamic-title__term<?php echo 0 === $tw_term_index ? ' is-current' : ''; ?>" data-hero-term><?php echo esc_html( $tw_term ); ?></span>
										<?php endforeach; ?>
									</span>
									<span class="tw-hero-dynamic-title__after"><?php echo esc_html( $tw_dynamic['after'] ); ?></span>
								</span>
							</<?php echo $tw_heading_tag; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>>
						<?php elseif ( 0 === $tw_index ) : ?>
							<h1><?php echo esc_html( $tw_slide['title'] ); ?></h1>
						<?php else : ?>
							<h2><?php echo esc_html( $tw_slide['title'] ); ?></h2>
						<?php endif; ?>
						<?php if ( $tw_slide['description'] ) : ?><p class="tw-hero__lead"><?php echo esc_html( $tw_slide['description'] ); ?></p><?php endif; ?>
						<?php if ( $tw_slide['button'] && $tw_slide['url'] ) : ?>
							<a class="tw-button tw-button--primary" href="<?php echo esc_url( $tw_slide['url'] ); ?>"><?php echo esc_html( $tw_slide['button'] ); ?><span aria-hidden="true">↗</span></a>
						<?php endif; ?>
					</div>
					<?php if ( $tw_has_proof ) : ?>
						<div class="tw-hero-proof" role="group" aria-label="<?php esc_attr_e( 'Risultati e partner', 'ticinoweb-child-theme' ); ?>">
							<?php if ( ! empty( $tw_reviews['rating'] ) ) : ?>
								<div class="tw-hero-proof__item tw-hero-proof__reviews">
									<span class="tw-hero-proof__label"><?php esc_html_e( 'Recensioni Google', 'ticinoweb-child-theme' ); ?></span>
									<p><strong><?php echo esc_html( $tw_reviews['rating'] ); ?>/5</strong><span class="tw-hero-proof__stars" aria-hidden="true">★★★★★</span></p>
									<small><?php echo esc_html( sprintf( __( '%d recensioni', 'ticinoweb-child-theme' ), absint( $tw_reviews['count'] ?? 0 ) ) ); ?></small>
								</div>
							<?php endif; ?>
							<?php if ( $tw_published_projects ) : ?>
								<div class="tw-hero-proof__item">
									<span class="tw-hero-proof__label"><?php esc_html_e( 'Progetti completati', 'ticinoweb-child-theme' ); ?></span>
									<p><strong><?php echo esc_html( number_format_i18n( $tw_published_projects ) ); ?>+</strong></p>
									<small><?php esc_html_e( 'Esperienze digitali reali', 'ticinoweb-child-theme' ); ?></small>
								</div>
							<?php endif; ?>
							<?php if ( $tw_partners ) : ?>
								<div class="tw-hero-proof__item tw-hero-proof__partners">
									<span class="tw-hero-proof__label"><?php esc_html_e( 'Partner tecnologici', 'ticinoweb-child-theme' ); ?></span>
									<div class="tw-hero-proof__logos">
										<?php foreach ( $tw_partners as $tw_partner ) : ?>
											<?php if ( $tw_partner['url'] ) : ?><a href="<?php echo esc_url( $tw_partner['url'] ); ?>" target="_blank" rel="noopener noreferrer"><?php else : ?><span><?php endif; ?>
											<?php if ( $tw_partner['image_id'] ) : ?>
												<?php echo wp_get_attachment_image( $tw_partner['image_id'], 'medium', false, array( 'alt' => $tw_partner['label'] ?? '', 'loading' => 'eager', 'decoding' => 'async', 'sizes' => '(max-width: 767px) 30vw, 116px' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
											<?php else : ?>
												<img src="<?php echo esc_url( $tw_partner['logo'] ); ?>" alt="<?php echo esc_attr( $tw_partner['label'] ?? '' ); ?>" width="116" height="38" loading="eager" decoding="async">
											<?php endif; ?>
											<?php if ( $tw_partner['url'] ) : ?></a><?php else : ?></span><?php endif; ?>
										<?php endforeach; ?>
									</div>
								</div>
							<?php endif; ?>
						</div>
					<?php endif; ?>
					<div class="tw-hero__micro">
						<p class="tw-hero__place"><?php esc_html_e( 'Locarno · Ticino · Switzerland', 'ticinoweb-child-theme' ); ?></p>
						<a href="#progetti"><?php esc_html_e( 'Scroll', 'ticinoweb-child-theme' ); ?> <span aria-hidden="true">↓</span></a>
					</div>
				</div>
			</article>
		<?php endforeach; ?>
	</div>
	<?php if ( $tw_slide_count > 1 ) : ?>
		<div class="tw-shell tw-hero__controls" aria-label="<?php esc_attr_e( 'Controlli presentazione', 'ticinoweb-child-theme' ); ?>">
			<button type="button" data-hero-prev aria-label="<?php esc_attr_e( 'Slide precedente', 'ticinoweb-child-theme' ); ?>">←</button>
			<p aria-live="polite"><span data-hero-current>01</span> / <?php echo esc_html( str_pad( (string) $tw_slide_count, 2, '0', STR_PAD_LEFT ) ); ?></p>
			<button type="button" data-hero-next aria-label="<?php esc_attr_e( 'Slide successiva', 'ticinoweb-child-theme' ); ?>">→</button>
			<button type="button" data-hero-toggle aria-pressed="false" aria-label="<?php esc_attr_e( 'Metti in pausa la presentazione', 'ticinoweb-child-theme' ); ?>" data-pause-label="<?php esc_attr_e( 'Metti in pausa la presentazione', 'ticinoweb-child-theme' ); ?>" data-play-label="<?php esc_attr_e( 'Riprendi la presentazione', 'ticinoweb-child-theme' ); ?>">Ⅱ</button>
		</div>
	<?php endif; ?>
</section>
