<?php
$tw_articles = $args['articles'] ?? array();
$tw_blog_url = $args['urls']['blog'] ?? home_url( '/' );
?>
<section class="tw-section tw-insights" aria-labelledby="tw-insights-title">
	<div class="tw-shell">
		<header class="tw-section-head"><div><p class="tw-kicker">tBLOG</p><h2 id="tw-insights-title"><?php esc_html_e( 'Idee, progetti e digitale dal nostro team.', 'ticinoweb-child-theme' ); ?></h2></div><div><a class="tw-text-link" href="<?php echo esc_url( $tw_blog_url ); ?>"><?php esc_html_e( 'Vai al tBlog', 'ticinoweb-child-theme' ); ?><span aria-hidden="true">↗</span></a></div></header>
		<div class="tw-insights__grid">
			<?php foreach ( $tw_articles as $tw_index => $tw_article ) : ?>
				<article class="tw-article<?php echo 0 === $tw_index ? ' tw-article--lead' : ''; ?>" data-home-reveal>
					<a class="tw-article__media" href="<?php echo esc_url( $tw_article['url'] ); ?>"><?php if ( $tw_article['image_id'] ) : ?><?php echo wp_get_attachment_image( $tw_article['image_id'], 0 === $tw_index ? 'large' : 'medium_large', false, array( 'alt' => $tw_article['title'], 'loading' => 'lazy', 'decoding' => 'async' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?><?php endif; ?></a>
					<div><p class="tw-meta"><?php echo esc_html( $tw_article['category'] . ' · ' . $tw_article['date'] ); ?></p><h3><a href="<?php echo esc_url( $tw_article['url'] ); ?>"><?php echo esc_html( $tw_article['title'] ); ?></a></h3></div>
				</article>
			<?php endforeach; ?>
		</div>
	</div>
</section>
