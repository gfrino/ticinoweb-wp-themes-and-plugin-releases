<?php
$tw_contact = $args['contact'] ?? array();
$tw_contact_url = $args['urls']['contact'] ?? home_url( '/' );
?>
<section class="tw-final-cta" aria-labelledby="tw-final-title">
	<div class="tw-shell tw-final-cta__grid">
		<div><p class="tw-kicker"><?php esc_html_e( 'Il prossimo progetto', 'ticinoweb-child-theme' ); ?></p><h2 id="tw-final-title"><?php esc_html_e( 'Hai un progetto? Parliamone.', 'ticinoweb-child-theme' ); ?></h2></div>
		<div class="tw-final-cta__aside">
			<p><?php esc_html_e( 'Raccontaci cosa vuoi costruire. Dal nostro studio di Locarno possiamo aiutarti a trasformare un’idea in un progetto digitale concreto.', 'ticinoweb-child-theme' ); ?></p>
			<div class="tw-final-cta__actions"><a class="tw-button tw-button--light" href="<?php echo esc_url( $tw_contact_url ); ?>"><?php esc_html_e( 'Parliamo del tuo progetto', 'ticinoweb-child-theme' ); ?><span aria-hidden="true">↗</span></a><?php if ( ! empty( $tw_contact['email'] ) ) : ?><a class="tw-text-link tw-text-link--light" href="mailto:<?php echo esc_attr( antispambot( $tw_contact['email'] ) ); ?>"><?php esc_html_e( 'Contattaci', 'ticinoweb-child-theme' ); ?><span aria-hidden="true">→</span></a><?php endif; ?></div>
			<address><?php if ( ! empty( $tw_contact['phone'] ) ) : ?><a href="tel:<?php echo esc_attr( preg_replace( '/[^+0-9]/', '', $tw_contact['phone'] ) ); ?>"><?php echo esc_html( $tw_contact['phone'] ); ?></a><?php endif; ?><?php if ( ! empty( $tw_contact['email'] ) ) : ?><a href="mailto:<?php echo esc_attr( antispambot( $tw_contact['email'] ) ); ?>"><?php echo esc_html( antispambot( $tw_contact['email'] ) ); ?></a><?php endif; ?><?php if ( ! empty( $tw_contact['address'] ) ) : ?><span><?php echo esc_html( $tw_contact['address'] ); ?></span><?php endif; ?></address>
		</div>
	</div>
</section>
