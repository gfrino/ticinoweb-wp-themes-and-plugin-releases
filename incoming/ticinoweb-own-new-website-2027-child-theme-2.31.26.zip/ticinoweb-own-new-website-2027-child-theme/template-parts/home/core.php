<?php
$tw_services = $args['services'] ?? array();
$tw_core = array_values(
	array_filter(
		$tw_services,
		static fn( $service ) => in_array( $service['category'] ?? '', array( 'Web Design', 'eCommerce' ), true )
	)
);
?>
<section class="tw-section tw-core-services" aria-labelledby="tw-core-title">
	<div class="tw-shell">
		<header class="tw-core-services__head">
			<p class="tw-kicker"><?php esc_html_e( 'Il nostro core', 'ticinoweb-child-theme' ); ?></p>
			<h2 id="tw-core-title"><?php esc_html_e( 'Il web non deve solo esserci. Deve funzionare.', 'ticinoweb-child-theme' ); ?></h2>
			<p><?php esc_html_e( 'Progettiamo siti web capaci di unire identità, esperienza utente, performance e obiettivi commerciali. Ogni progetto viene costruito intorno all’azienda, non intorno a un template.', 'ticinoweb-child-theme' ); ?></p>
		</header>
		<?php if ( $tw_core ) : ?>
			<div class="tw-core-services__list">
				<?php foreach ( $tw_core as $tw_index => $tw_service ) : $tw_service_url = tw_home_service_url( $tw_service ); ?>
				<article class="tw-core-service" data-home-reveal>
					<div class="tw-core-service__media">
						<?php $tw_image_id = tw_home_attachment_id_from_url( $tw_service['image'] ?? '' ); ?>
						<?php if ( $tw_image_id ) : ?><?php echo wp_get_attachment_image( $tw_image_id, 'large', false, array( 'alt' => $tw_service['title'], 'loading' => 'lazy', 'decoding' => 'async', 'sizes' => '(max-width: 767px) 92vw, 46vw' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?><?php endif; ?>
					</div>
					<div class="tw-core-service__copy">
						<span><?php echo esc_html( str_pad( (string) ( $tw_index + 1 ), 2, '0', STR_PAD_LEFT ) ); ?></span>
						<h3><?php echo esc_html( $tw_service['title'] ); ?></h3>
						<p><?php echo esc_html( tw_home_excerpt( $tw_service['short_description'] ?? $tw_service['description'], 26 ) ); ?></p>
						<?php if ( $tw_service_url ) : ?><a class="tw-text-link" href="<?php echo esc_url( $tw_service_url ); ?>"><?php echo esc_html( $tw_service['cta_label'] ?? __( 'Scopri il servizio', 'ticinoweb-child-theme' ) ); ?><span aria-hidden="true">↗</span></a><?php endif; ?>
					</div>
				</article>
				<?php endforeach; ?>
			</div>
		<?php endif; ?>
	</div>
</section>
