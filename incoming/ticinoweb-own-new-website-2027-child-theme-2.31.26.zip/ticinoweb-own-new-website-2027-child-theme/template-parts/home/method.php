<?php
$tw_steps = array(
	array( __( 'Ascolto', 'ticinoweb-child-theme' ), __( 'Comprendiamo obiettivi, persone e contesto prima di proporre una soluzione.', 'ticinoweb-child-theme' ) ),
	array( __( 'Strategia', 'ticinoweb-child-theme' ), __( 'Definiamo priorità, contenuti e percorso affinché ogni scelta abbia una ragione.', 'ticinoweb-child-theme' ) ),
	array( __( 'Design', 'ticinoweb-child-theme' ), __( 'Trasformiamo la strategia in un’esperienza riconoscibile, chiara e facile da usare.', 'ticinoweb-child-theme' ) ),
	array( __( 'Sviluppo', 'ticinoweb-child-theme' ), __( 'Costruiamo con attenzione a qualità, performance, sicurezza e gestione futura.', 'ticinoweb-child-theme' ) ),
	array( __( 'Crescita', 'ticinoweb-child-theme' ), __( 'Restiamo presenti dopo il lancio con dati, supporto e miglioramenti continui.', 'ticinoweb-child-theme' ) ),
);
?>
<section class="tw-section tw-method" aria-labelledby="tw-method-title">
	<div class="tw-shell tw-method__grid">
		<header><p class="tw-kicker"><?php esc_html_e( 'Come lavoriamo', 'ticinoweb-child-theme' ); ?></p><h2 id="tw-method-title"><?php esc_html_e( 'Dall’idea al risultato.', 'ticinoweb-child-theme' ); ?></h2></header>
		<ol class="tw-method__steps">
			<?php foreach ( $tw_steps as $tw_index => $tw_step ) : ?>
				<li data-home-reveal><span><?php echo esc_html( str_pad( (string) ( $tw_index + 1 ), 2, '0', STR_PAD_LEFT ) ); ?></span><h3><?php echo esc_html( $tw_step[0] ); ?></h3><p><?php echo esc_html( $tw_step[1] ); ?></p></li>
			<?php endforeach; ?>
		</ol>
	</div>
</section>
