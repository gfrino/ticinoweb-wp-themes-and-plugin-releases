<?php
$tw_partners = $args['partners'] ?? array();

$tw_render_partner = static function ( $tw_partner, $interactive = true ) {
	$tw_label = $tw_partner['label'] ?? '';
	$tw_url   = $tw_partner['url'] ?? '';
	$tw_tag   = $interactive && $tw_url ? 'a' : 'span';
	?>
	<<?php echo esc_html( $tw_tag ); ?> class="tw-partner-logo" role="listitem"<?php if ( 'a' === $tw_tag ) : ?> href="<?php echo esc_url( $tw_url ); ?>" target="_blank" rel="noopener noreferrer" aria-label="<?php echo esc_attr( $tw_label ); ?>"<?php elseif ( $tw_url ) : ?> tabindex="-1"<?php endif; ?>>
		<?php if ( $tw_partner['image_id'] ) : ?>
			<?php echo wp_get_attachment_image( $tw_partner['image_id'], 'medium', false, array( 'alt' => $tw_label, 'loading' => 'lazy', 'decoding' => 'async', 'sizes' => '(max-width: 767px) 150px, 190px' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
		<?php else : ?>
			<img src="<?php echo esc_url( $tw_partner['logo'] ); ?>" alt="<?php echo esc_attr( $tw_label ); ?>" width="190" height="72" loading="lazy" decoding="async">
		<?php endif; ?>
	</<?php echo esc_html( $tw_tag ); ?>>
	<?php
};
?>
<?php if ( $tw_partners ) : ?>
<section class="tw-partners" aria-labelledby="tw-partners-title" data-partner-marquee>
	<div class="tw-shell">
		<header class="tw-partners__head" data-home-reveal>
			<h2 id="tw-partners-title"><?php esc_html_e( 'Partner, tecnologie e certificazioni.', 'ticinoweb-child-theme' ); ?></h2>
		</header>
	</div>

	<div class="tw-partners__viewport">
		<div class="tw-partners__rail">
			<div class="tw-partners__track" data-partner-track role="list">
				<div class="tw-partners__sequence">
					<?php foreach ( $tw_partners as $tw_partner ) : ?>
						<?php $tw_render_partner( $tw_partner, true ); ?>
					<?php endforeach; ?>
				</div>
				<div class="tw-partners__sequence" aria-hidden="true">
					<?php foreach ( $tw_partners as $tw_partner ) : ?>
						<?php $tw_render_partner( $tw_partner, false ); ?>
					<?php endforeach; ?>
				</div>
			</div>
		</div>
	</div>
</section>
<?php endif; ?>
