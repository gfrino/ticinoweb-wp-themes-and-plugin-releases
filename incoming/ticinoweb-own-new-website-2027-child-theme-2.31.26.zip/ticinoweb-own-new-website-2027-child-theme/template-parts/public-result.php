<?php
/** One native search/archive result. All content and links come from WordPress. */
$tw_result_type = get_post_type_object( get_post_type() );
$tw_result_title = get_the_title();
if ( '' === trim( $tw_result_title ) ) {
	$tw_result_title = __( 'Senza titolo', 'ticinoweb-child-theme' );
}
?>
<article <?php post_class( 'tw-blog-card tw-public-card' ); ?>>
	<?php if ( has_post_thumbnail() ) : ?>
		<a class="tw-blog-card__media" href="<?php echo esc_url( get_permalink() ); ?>" tabindex="-1" aria-hidden="true">
			<?php the_post_thumbnail( 'medium_large', array( 'alt' => '', 'loading' => 'lazy', 'decoding' => 'async', 'sizes' => '(max-width: 620px) 100vw, (max-width: 1100px) 50vw, 33vw' ) ); ?>
		</a>
	<?php endif; ?>
	<div class="tw-blog-card__body">
		<?php if ( $tw_result_type ) : ?>
			<p class="tw-blog-card__meta"><?php echo esc_html( $tw_result_type->labels->singular_name ); ?><?php if ( 'post' === get_post_type() ) : ?> · <time datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>"><?php echo esc_html( get_the_date() ); ?></time><?php endif; ?></p>
		<?php endif; ?>
		<h2><a href="<?php echo esc_url( get_permalink() ); ?>"><?php echo esc_html( $tw_result_title ); ?></a></h2>
		<?php $tw_result_excerpt = wp_trim_words( wp_strip_all_tags( strip_shortcodes( get_the_excerpt() ) ), 30 ); ?>
		<?php if ( $tw_result_excerpt ) : ?><p><?php echo esc_html( $tw_result_excerpt ); ?></p><?php endif; ?>
		<a class="tw-blog-card__link" href="<?php echo esc_url( get_permalink() ); ?>"><?php esc_html_e( 'Scopri di più', 'ticinoweb-child-theme' ); ?><span aria-hidden="true">↗</span></a>
	</div>
</article>
