<?php
/** Compact native category/tag/taxonomy/author/date/CPT archive. */
get_header();
$tw_archive_title = wp_strip_all_tags( get_the_archive_title() );
$tw_archive_description = get_the_archive_description();
if ( is_home() ) {
	$tw_posts_page = absint( get_option( 'page_for_posts' ) );
	$tw_archive_title = $tw_posts_page ? get_the_title( $tw_posts_page ) : __( 'Articoli e approfondimenti', 'ticinoweb-child-theme' );
	$tw_archive_description = '';
}
?>
<main class="tw-public-archive">
	<header class="tw-public-hero">
		<div class="tw-shell">
			<p class="tw-blog-kicker"><?php esc_html_e( 'Esplora i contenuti', 'ticinoweb-child-theme' ); ?></p>
			<h1><?php echo esc_html( $tw_archive_title ); ?></h1>
			<?php if ( $tw_archive_description ) : ?>
				<div class="tw-public-intro"><?php echo wp_kses_post( $tw_archive_description ); ?></div>
			<?php endif; ?>
		</div>
	</header>
	<div class="tw-shell tw-public-results"><?php tw_public_archives_render_results(); ?></div>
</main>
<?php get_footer(); ?>
