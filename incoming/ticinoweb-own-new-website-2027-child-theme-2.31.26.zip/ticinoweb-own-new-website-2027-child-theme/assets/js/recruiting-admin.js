document.querySelectorAll('.tw-recruiting-media').forEach(p=>{
 p.querySelector('.tw-recruiting-pick').addEventListener('click',()=>{const frame=wp.media({multiple:false,library:{type:'image'}});frame.on('select',()=>{const m=frame.state().get('selection').first().toJSON();p.querySelector('input').value=m.id;p.querySelector('span').textContent=m.title;});frame.open();});
 p.querySelector('.tw-recruiting-clear').addEventListener('click',()=>{p.querySelector('input').value=0;p.querySelector('span').textContent='';});
});
document.querySelectorAll('.tw-recruiting-repeater').forEach(s=>{
 const rows=s.querySelector('.tw-recruiting-rows');
 const reindex=()=>[...rows.children].forEach((row,i)=>row.querySelectorAll('[name]').forEach(input=>{input.name=input.name.replace(/\[\d+\]/,`[${i}]`);}));
 s.addEventListener('click',e=>{
  const row=e.target.closest('fieldset');
  if(e.target.classList.contains('tw-recruiting-add'))rows.append(s.querySelector('template').content.cloneNode(true));
  if(row&&e.target.classList.contains('tw-recruiting-remove'))row.remove();
  if(row&&e.target.classList.contains('tw-recruiting-up')&&row.previousElementSibling)rows.insertBefore(row,row.previousElementSibling);
  if(row&&e.target.classList.contains('tw-recruiting-down')&&row.nextElementSibling)rows.insertBefore(row.nextElementSibling,row);
  reindex();
 });
});
