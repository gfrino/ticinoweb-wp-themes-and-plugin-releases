/* Original CMS questionnaire budget. Server validation remains authoritative. */
(function () {
	'use strict';
	const trim = value => value.replace(/^[ \t\n\r\0\x0b]+|[ \t\n\r\0\x0b]+$/g, '');
	const sanitize = (value, type) => {
		let text = String(value).replace(/\r\n?/g, '\n');
		if (text.includes('<')) {
			text = text.replace(/<[^>]*?(?=<|>|$)>?/g, part => part.includes('>') ? part : part.replace(/&(?!(?:[a-z]+|#\d+|#x[\da-f]+);)/gi, '&amp;').replace(/</g, '&lt;').replace(/"/g, '&quot;').replace(/'/g, '&#039;'));
			text = text.replace(/<(script|style)[^>]*>[^]*?<\/\1>/gi, '').replace(/<[^>]*>/g, '');
		}
		if (type !== 'textarea') text = text.replace(/[\r\n\t ]+/g, ' ');
		text = trim(text);
		if (/%[a-f\d]{2}/i.test(text)) text = trim(text.replace(/%[a-f\d]{2}/gi, '').replace(/ +/g, ' '));
		return text;
	};
	const compose = fields => fields.map(field => {
		const value = sanitize(field.value, field.type);
		return value ? field.label + ': ' + value : '';
	}).filter(Boolean).join('\n\n');
	const count = value => Array.from(value).length;
	if (typeof module !== 'undefined' && module.exports) module.exports = {compose, count};
	if (typeof document === 'undefined') return;
	const form = document.querySelector('.tw-legacy-survey[data-tw-about-form]');
	if (!form) return;
	const cfg = window.twSurveyBudget || {};
	const counter = form.querySelector('[data-tw-survey-budget]');
	const status = form.querySelector('.tw-about-form-status');
	const questions = Array.from(form.querySelectorAll('[data-tw-survey-question]'));
	const used = () => count(compose(questions.map(input => ({label:input.dataset.twSurveyLabel,type:input.dataset.twSurveyType,value:input.value}))));
	const refresh = () => {
		const total = used();
		if (counter) counter.textContent = total <= 5000 ? (cfg.remaining || '%d caratteri disponibili, domande incluse.').replace('%d', String(5000 - total)) : (cfg.excess || 'Riduci le risposte di almeno %d caratteri.').replace('%d', String(total - 5000));
		return total;
	};
	form.addEventListener('input', refresh);
	form.addEventListener('reset', () => setTimeout(refresh, 0));
	form.addEventListener('submit', event => {
		if (refresh() <= 5000) return;
		event.preventDefault();
		event.stopImmediatePropagation();
		status.textContent = cfg.overflow || 'Le risposte e le domande superano il limite complessivo di 5000 caratteri. Riduci le risposte prima di inviare.';
		const first = questions.find(input => sanitize(input.value, input.dataset.twSurveyType));
		if (first) { first.setAttribute('aria-describedby', status.id); first.focus(); }
		else status.focus();
	}, true);
	refresh();
})();
