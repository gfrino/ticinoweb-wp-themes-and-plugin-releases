(function () {
	'use strict';
	const box = document.getElementById('tw-odoo-suite');
	if (!box) return;
	const labels = window.twOdooSuiteAdmin;
	let sequence = Date.now();
	function updateRole() {
		const navigation = box.querySelector('.tw-odoo-navigation');
		if (!navigation) return;
		const enabled = box.querySelector('.tw-odoo-role').value === 'overview';
		navigation.hidden = !enabled;
		navigation.querySelectorAll('input, select, textarea, button').forEach(control => { control.disabled = !enabled; });
	}
	box.addEventListener('change', function (event) {
		if (event.target.matches('.tw-odoo-role')) updateRole();
		if (event.target.matches('.tw-odoo-icon-select')) {
			const preview = event.target.closest('.tw-odoo-icon').querySelector('img');
			const url = event.target.selectedOptions[0].dataset.url;
			preview.hidden = !url;
			if (url) preview.src = url;
			else preview.removeAttribute('src');
		}
		if (event.target.name && /\[title\]$/.test(event.target.name)) {
			const group = event.target.closest('.tw-odoo-group');
			if (group && event.target === group.querySelector('input[name$="[title]"]')) {
				group.querySelector('summary').textContent = event.target.value || labels.newGroup;
			}
		}
	});
	box.addEventListener('click', function (event) {
		const button = event.target.closest('button');
		if (!button) return;
		if (button.hasAttribute('data-odoo-add')) {
			const repeater = button.closest('.tw-odoo-repeater');
			const template = document.getElementById('tw-odoo-template-' + repeater.dataset.kind);
			const name = repeater.dataset.name + '[' + (++sequence) + ']';
			const fragment = template.content.cloneNode(true);
			fragment.querySelectorAll('[name], [data-name], [id]').forEach(control => {
				['name', 'data-name', 'id'].forEach(attribute => {
					if (control.hasAttribute(attribute)) control.setAttribute(attribute, control.getAttribute(attribute).replaceAll('__NAME__', name));
				});
			});
			const item = fragment.firstElementChild;
			if (item.tagName === 'DETAILS') item.open = true;
			repeater.querySelector(':scope > .tw-odoo-items').append(fragment);
			const firstControl = item.querySelector('input:not([type="hidden"]),select,textarea');
			if (firstControl) firstControl.focus();
		}
		if (button.hasAttribute('data-odoo-remove') && window.confirm(labels.removeConfirm)) {
			const item = button.closest('.tw-odoo-item');
			const repeater = item.parentElement.closest('.tw-odoo-repeater');
			item.remove();
			if (repeater) repeater.querySelector(':scope > [data-odoo-add]').focus();
		}
		if (button.hasAttribute('data-odoo-media')) {
			const media = button.closest('.tw-odoo-media');
			const input = media.querySelector('input');
			const caption = media.querySelector('.tw-odoo-media-name');
			if (button.dataset.odooMedia === 'clear') {
				input.value = '0';
				caption.textContent = labels.emptyMedia;
				return;
			}
			const frame = wp.media({ title: labels.mediaTitle, button: { text: labels.mediaButton }, library: { type: 'image' }, multiple: false });
			frame.on('select', function () {
				const attachment = frame.state().get('selection').first().toJSON();
				input.value = attachment.id;
				caption.textContent = attachment.title || attachment.filename;
			});
			frame.open();
		}
	});
	updateRole();
})();
