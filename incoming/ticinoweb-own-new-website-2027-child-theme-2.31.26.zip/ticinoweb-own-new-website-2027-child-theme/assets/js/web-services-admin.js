(() => {
	'use strict';
	const root = document.querySelector('[data-tw-ws-admin]');
	if (!root) return;
	const labels = window.twWebServicesAdmin || {};
	const text = (key, fallback) => labels[key] || fallback;
	const safe = (value) => String(value).replace(/[&<>'"]/g, (character) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#039;', '"': '&quot;' }[character]));
	const renderMediaPreview = (preview, attachment = null) => {
		preview.replaceChildren();
		if (attachment?.type === 'image') {
			const previewUrl = attachment.sizes?.thumbnail?.url || attachment.icon || '';
			if (previewUrl) {
				const image = document.createElement('img');
				image.src = previewUrl;
				image.alt = '';
				preview.append(image);
				return;
			}
		}
		const label = document.createElement('span');
		label.textContent = attachment
			? (attachment.filename || attachment.title || text('mediaSelected', 'Media selezionato'))
			: text('mediaEmpty', 'Nessun media selezionato');
		preview.append(label);
	};
	root.addEventListener('click', (event) => {
		const remove = event.target.closest('[data-tw-ws-remove]');
		if (remove) { remove.closest('[data-tw-ws-row]')?.remove(); return; }
		const add = event.target.closest('[data-tw-ws-add]');
		if (add) {
			const repeater = add.closest('[data-tw-ws-repeater]');
			const key = repeater.dataset.twWsRepeater;
			const rows = repeater.querySelector('[data-tw-ws-rows]');
			const index = `${Date.now()}${Math.floor(Math.random() * 1000)}`;
			const row = document.createElement('div');
			row.className = 'tw-ws-row'; row.dataset.twWsRow = '';
			row.innerHTML = `<input type="text" name="tw_web_service[${safe(key)}][${index}][number]" placeholder="${safe(text('number', 'Numero'))}"><input type="text" name="tw_web_service[${safe(key)}][${index}][title]" placeholder="${safe(text('title', 'Titolo'))}"><textarea name="tw_web_service[${safe(key)}][${index}][text]" rows="2" placeholder="${safe(text('description', 'Descrizione'))}"></textarea><input type="text" name="tw_web_service[${safe(key)}][${index}][icon]" placeholder="${safe(text('icon', 'Icona (opzionale)'))}"><input type="text" name="tw_web_service[${safe(key)}][${index}][url]" placeholder="${safe(text('url', 'Slug collegato (opzionale)'))}"><button type="button" class="button-link-delete" data-tw-ws-remove>${safe(text('remove', 'Rimuovi'))}</button>`;
			rows.append(row); row.querySelector('input')?.focus(); return;
		}
		const mediaButton = event.target.closest('[data-tw-ws-media]');
		if (mediaButton && window.wp?.media) {
			const field = mediaButton.closest('[data-tw-ws-media-field]');
			const frame = window.wp.media({ title: text('mediaTitle', 'Scegli immagine o video'), multiple: false, library: { type: ['image', 'video'] } });
			frame.on('select', () => {
				const attachment = frame.state().get('selection').first().toJSON();
				field.querySelector('[data-tw-ws-media-id]').value = attachment.id;
				const preview = field.querySelector('[data-tw-ws-media-preview]');
				renderMediaPreview(preview, attachment);
			});
			frame.open(); return;
		}
		const clear = event.target.closest('[data-tw-ws-media-clear]');
		if (clear) {
			const field = clear.closest('[data-tw-ws-media-field]');
			field.querySelector('[data-tw-ws-media-id]').value = '';
			renderMediaPreview(field.querySelector('[data-tw-ws-media-preview]'));
		}
	});
})();
