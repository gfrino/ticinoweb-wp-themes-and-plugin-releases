(() => {
	'use strict';
	const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
	const heroVideo = document.querySelector("[data-tw-web-video='hero']");
	const viewportVideos = document.querySelectorAll("[data-tw-web-video='viewport']");
	if (reduceMotion) {
		document.querySelectorAll('[data-tw-web-video]').forEach((video) => video.pause());
	} else {
		heroVideo?.play().catch(() => {});
		if ('IntersectionObserver' in window) {
			const videoObserver = new IntersectionObserver((entries) => {
				entries.forEach((entry) => {
					if (entry.isIntersecting) entry.target.play().catch(() => {});
					else entry.target.pause();
				});
			}, { rootMargin: '160px 0px', threshold: 0.08 });
			viewportVideos.forEach((video) => videoObserver.observe(video));
		}
	}

	const method = document.querySelector('[data-tw-web-method]');
	if (!method || reduceMotion || !('IntersectionObserver' in window)) {
		method?.classList.add('is-visible');
		return;
	}
	const observer = new IntersectionObserver((entries) => {
		if (!entries[0]?.isIntersecting) return;
		method.classList.add('is-visible');
		observer.disconnect();
	}, { threshold: 0.25 });
	observer.observe(method);
})();
