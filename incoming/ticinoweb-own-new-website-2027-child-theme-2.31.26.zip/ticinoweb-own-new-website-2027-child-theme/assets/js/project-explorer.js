(() => {
	'use strict';

	const explorer = document.querySelector('[data-project-explorer]');
	if (!explorer) return;

	const restUrl = explorer.dataset.restUrl;
	const perPage = Number.parseInt(explorer.dataset.perPage || '6', 10);
	const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
	const groups = [...explorer.querySelectorAll('[data-project-group]')];
	const requestCache = new Map();

	const textFromHtml = (value = '') => {
		const parsedDocument = new DOMParser().parseFromString(value, 'text/html');
		return parsedDocument.body.textContent || '';
	};

	const safeUrl = (value = '') => {
		try {
			const url = new URL(value, window.location.origin);
			return ['http:', 'https:'].includes(url.protocol) ? url.href : '#';
		} catch (error) {
			return '#';
		}
	};

	const getProjectTerms = (project) => {
		if (project.meta_label) return project.meta_label;
		if (project.types) return project.types.join(' · ');
		const embeddedTerms = project._embedded?.['wp:term'] || [];
		const terms = embeddedTerms.flat();
		const types = terms.filter((term) => term.taxonomy === 'category').map((term) => textFromHtml(term.name));
		return types.join(' · ');
	};

	const getProjectMedia = (project) => {
		if ('image' in project) return project.image ? {...project.image, src:safeUrl(project.image.src)} : null;
		const media = project._embedded?.['wp:featuredmedia']?.[0];
		if (!media) return null;
		const sizes = media.media_details?.sizes || {};
		const preferred = sizes.large || sizes.medium_large || sizes.full;
		const sources = Object.values(sizes)
			.filter((size) => size?.source_url && size?.width)
			.sort((first, second) => first.width - second.width)
			.map((size) => `${safeUrl(size.source_url)} ${size.width}w`);
		return {
			src: safeUrl(preferred?.source_url || media.source_url),
			srcset: [...new Set(sources)].join(', '),
			width: preferred?.width || media.media_details?.width || 1200,
			height: preferred?.height || media.media_details?.height || 900,
		};
	};

	const createCopy = (className, title, meta) => {
		const copy = document.createElement('span');
		copy.className = className;
		const heading = document.createElement('strong');
		heading.textContent = title;
		copy.append(heading);
		if (meta) {
			const details = document.createElement('small');
			details.textContent = meta;
			copy.append(details);
		}
		const arrow = document.createElement('i');
		arrow.setAttribute('aria-hidden', 'true');
		arrow.textContent = '↗';
		copy.append(arrow);
		return copy;
	};

	const createProjectCard = (project) => {
		const title = textFromHtml(typeof project.title === 'string' ? project.title : project.title?.rendered || '');
		const meta = getProjectTerms(project);
		const card = document.createElement('a');
		card.className = 'tw-project-card is-entering';
		card.href = safeUrl(project.url || project.link);
		card.dataset.projectId = String(project.id);

		const mediaFrame = document.createElement('span');
		mediaFrame.className = 'tw-project-card__media';
		const media = getProjectMedia(project);
		if (media) {
			const image = document.createElement('img');
			image.src = media.src;
			if (media.srcset) image.srcset = media.srcset;
			image.sizes = '(max-width: 767px) calc(100vw - 32px), (max-width: 1100px) 46vw, 31vw';
			image.width = media.width;
			image.height = media.height;
			image.alt = '';
			image.loading = 'lazy';
			image.decoding = 'async';
			mediaFrame.append(image);
		} else {
			const fallback=document.createElement('span'); fallback.className='tw-project-card__fallback';fallback.setAttribute('aria-hidden','true');fallback.textContent=Array.from(title).slice(0,2).join('');mediaFrame.append(fallback);
		}
		mediaFrame.append(createCopy('tw-project-card__overlay', title, meta));
		card.append(mediaFrame, createCopy('tw-project-card__mobile-copy', title, meta));
		card.addEventListener('animationend', () => card.classList.remove('is-entering'), { once: true });
		return card;
	};

	const requestProjects = async (item, page) => {
		const cacheKey = `${item.dataset.taxonomy}:${item.dataset.termId}:${page}`;
		if (requestCache.has(cacheKey)) return requestCache.get(cacheKey);

		const url = new URL(restUrl);
		url.searchParams.set('context', 'home');
		url.searchParams.set('page', String(page));
		url.searchParams.set('taxonomy', item.dataset.taxonomy);
		url.searchParams.set('term_id', item.dataset.termId);

		const response = await fetch(url, { headers: { Accept: 'application/json' } });
		if (!response.ok) throw new Error(`Project request failed: ${response.status}`);
		const result = await response.json();
		requestCache.set(cacheKey, result);
		return result;
	};

	const loadProjects = async (item, page, append = false) => {
		const grid = item.querySelector('[data-project-grid]');
		const status = item.querySelector('[data-project-status]');
		const loadMore = item.querySelector('[data-project-load-more]');
		loadMore.setAttribute('aria-busy', 'true');
		loadMore.disabled = true;
		status.textContent = explorer.dataset.loadingLabel;

		try {
			const result = await requestProjects(item, page);
			if (!append) grid.replaceChildren();
			result.items.forEach((project) => {if(!grid.querySelector(`[data-project-id="${Number(project.id)}"]`))grid.append(createProjectCard(project));});
			item.dataset.loaded = 'true';
			item.dataset.page = String(page);
			item.dataset.pages = String(result.pages);
			loadMore.hidden = page >= result.pages;
			status.textContent = result.items.length
				? explorer.dataset.loadedLabel.replace('%d', String(result.items.length))
				: explorer.dataset.emptyLabel;
		} catch (error) {
			status.textContent = explorer.dataset.errorLabel;
			loadMore.hidden = false;
		} finally {
			loadMore.removeAttribute('aria-busy');
			loadMore.disabled = false;
		}
	};

	const closeItem = (item, instant = false) => {
		const trigger = item.querySelector('[data-project-trigger]');
		const panel = item.querySelector('[data-project-panel]');
		trigger.setAttribute('aria-expanded', 'false');
		item.classList.remove('is-open');
		if (instant) {
			panel.hidden = true;
			return;
		}
		window.setTimeout(() => {
			if (!item.classList.contains('is-open')) panel.hidden = true;
		}, reduceMotion ? 0 : 450);
	};

	const updateDeepLink = (item = null) => {
		const url = new URL(window.location.href);
		groups.forEach((group) => url.searchParams.delete(group.dataset.queryParam));
		if (item) {
			const group = item.closest('[data-project-group]');
			url.searchParams.set(group.dataset.queryParam, item.dataset.termSlug);
		}
		window.history.replaceState({}, '', `${url.pathname}${url.search}${url.hash}`);
	};

	const openItem = async (item, updateUrl = true) => {
		const group = item.closest('[data-project-group]');
		const trigger = item.querySelector('[data-project-trigger]');
		const panel = item.querySelector('[data-project-panel]');
		// Le sezioni aperte si chiudono subito e la pagina resta ferma sulla riga cliccata,
		// altrimenti il contenuto sopra collassa e la pagina "salta" più in basso.
		const anchorTop = trigger.getBoundingClientRect().top;
		group.querySelectorAll('[data-project-item].is-open').forEach((open) => {
			if (open !== item) closeItem(open, true);
		});
		const shift = trigger.getBoundingClientRect().top - anchorTop;
		if (shift) window.scrollBy({ top: shift, behavior: 'instant' });
		panel.hidden = false;
		trigger.setAttribute('aria-expanded', 'true');
		window.requestAnimationFrame(() => item.classList.add('is-open'));
		if (updateUrl) updateDeepLink(item);
		if (item.dataset.loaded !== 'true') await loadProjects(item, 1, false);
	};

	explorer.querySelectorAll('[data-project-item]').forEach((item) => {
		item.querySelector('[data-project-trigger]').addEventListener('click', () => {
			if (item.classList.contains('is-open')) {
				closeItem(item);
				updateDeepLink();
			} else {
				openItem(item);
			}
		});
		item.querySelector('[data-project-load-more]').addEventListener('click', () => {
			const nextPage = item.dataset.loaded==='true' ? Number.parseInt(item.dataset.page || '1', 10) + 1 : 1;
			loadProjects(item, nextPage, true);
		});
	});

	const modeButtons=[...explorer.querySelectorAll('[data-project-mode]')];
	const selectGroup=(taxonomy,load=true)=>{
		groups.forEach(group=>{const selected=group.dataset.projectGroup===taxonomy;group.hidden=!selected;group.classList.toggle('is-active',selected);});
		modeButtons.forEach(button=>{const selected=button.dataset.projectMode===taxonomy;button.setAttribute('aria-selected',String(selected));button.tabIndex=selected?0:-1;});
		const group=groups.find(g=>g.dataset.projectGroup===taxonomy);
		if(load&&group){const item=group.querySelector('[data-project-item].is-open')||group.querySelector('[data-project-item]');if(item)openItem(item);else updateDeepLink();}
	};
	modeButtons.forEach((button,index)=>{
		button.addEventListener('click',()=>selectGroup(button.dataset.projectMode));
		button.addEventListener('keydown',event=>{let next;if(event.key==='ArrowRight')next=(index+1)%modeButtons.length;else if(event.key==='ArrowLeft')next=(index+modeButtons.length-1)%modeButtons.length;else if(event.key==='Home')next=0;else if(event.key==='End')next=modeButtons.length-1;else return;event.preventDefault();modeButtons[next].focus();modeButtons[next].scrollIntoView({block:'nearest',inline:'nearest'});selectGroup(modeButtons[next].dataset.projectMode);});
	});
	const params = new URLSearchParams(window.location.search);
	let deepLinkedItem = null;
	groups.forEach((group) => {
		const slug = params.get(group.dataset.queryParam);
		if (!slug || deepLinkedItem) return;
		deepLinkedItem = [...group.querySelectorAll('[data-project-item]')].find((item) => item.dataset.termSlug === slug) || null;
	});
	if (deepLinkedItem) {selectGroup(deepLinkedItem.dataset.taxonomy,false);openItem(deepLinkedItem, false);}
})();
