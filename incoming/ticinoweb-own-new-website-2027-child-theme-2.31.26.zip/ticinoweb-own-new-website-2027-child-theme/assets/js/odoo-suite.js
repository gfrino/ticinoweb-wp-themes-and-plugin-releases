(() => {
 'use strict';
 const nav=document.querySelector('.tw-odoo-nav ul');
 if(nav){
  const revealCurrent=()=>{
   const active=nav.querySelector('[aria-current=page]');
   if(!active||nav.scrollWidth<=nav.clientWidth)return;
   const rect=active.getBoundingClientRect();
   nav.scrollTo({left:nav.scrollLeft+rect.left-nav.getBoundingClientRect().left-(nav.clientWidth-rect.width)/2,behavior:'instant'});
  };
  revealCurrent();
  if('ResizeObserver' in window)new ResizeObserver(revealCurrent).observe(nav);
  else window.addEventListener('resize',revealCurrent,{passive:true});
 }
 document.querySelectorAll('[data-odoo-accordion]').forEach(accordion => {
  const buttons=[...accordion.querySelectorAll(':scope > section > h3 > button')];
  const set=(button,open)=>{
   button.setAttribute('aria-expanded',String(open));
   const panel=document.getElementById(button.getAttribute('aria-controls'));
   if(panel)panel.hidden=!open;
   button.querySelector('.tw-odoo-toggle').textContent=open?'−':'+';
  };
  buttons.forEach((button,index)=>{
   set(button,index===0);
   button.addEventListener('click',()=>{
    const open=button.getAttribute('aria-expanded')!=='true';
    buttons.forEach(other=>set(other,other===button&&open));
    // Collapsing a long preceding panel must not strand the selected heading behind the sticky navigation.
    const ceiling=(document.querySelector('.tw-odoo-nav')?.getBoundingClientRect().bottom||0)+16;
    const top=button.getBoundingClientRect().top;
    if(top<ceiling)window.scrollBy({top:top-ceiling,behavior:'instant'});
   });
   button.addEventListener('keydown',event=>{
    const keys={ArrowDown:(index+1)%buttons.length,ArrowUp:(index+buttons.length-1)%buttons.length,Home:0,End:buttons.length-1};
    if(Object.hasOwn(keys,event.key)){event.preventDefault();buttons[keys[event.key]].focus();}
   });
  });
 });
})();
