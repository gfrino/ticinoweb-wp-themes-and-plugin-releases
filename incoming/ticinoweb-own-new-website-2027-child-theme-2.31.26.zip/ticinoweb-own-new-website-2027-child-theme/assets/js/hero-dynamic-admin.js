((windowObject, $) => {
	'use strict';

	const config = windowObject.twHeroDynamicAdmin;
	if (!config || !$) return;

	const escapeHtml = (value = '') => $('<div>').text(value).html();
	const isVideoUrl = (value = '') => /\.(?:mp4|webm|ogv)(?:[?#].*)?$/i.test(value.trim());
	const synchronizeSliderMedia = (item) => {
		const input = item.find('.slider-image-url');
		const preview = item.find('.slider-image-preview');
		const url = String(input.val() || '').trim();
		input.closest('tr').find('th label').text(config.labels.mediaLabel);
		item.find('.upload-slider-image').text(config.labels.mediaButton);
		if (!preview.length || !isVideoUrl(url) || preview.find('video').attr('src') === url) return;
		const video = $('<video controls muted playsinline preload="metadata">').attr('src', url);
		preview.empty().append(video);
	};
	const termLabel = (index) => `${config.labels.termLabel} ${index + 1}`;
	const termRow = (slot, value = '', index = 0) => `
		<li class="tw-dynamic-title-term">
			<span class="tw-dynamic-title-term__controls">
				<button type="button" class="tw-dynamic-title-term__handle" aria-label="${escapeHtml(config.labels.moveTerm)}">⋮⋮</button>
				<button type="button" class="tw-dynamic-title-term__move" data-move-dynamic-term-up aria-label="${escapeHtml(config.labels.moveUp)}">↑</button>
				<button type="button" class="tw-dynamic-title-term__move" data-move-dynamic-term-down aria-label="${escapeHtml(config.labels.moveDown)}">↓</button>
			</span>
			<input type="text" name="ticinoweb_slider_dynamic_terms_${slot}[]" value="${escapeHtml(value)}" class="regular-text" aria-label="${escapeHtml(termLabel(index))}">
			<button type="button" class="button-link-delete" data-remove-dynamic-term aria-label="${escapeHtml(config.labels.removeTerm)}">×</button>
		</li>`;
	const refreshTermList = (list) => {
		const rows = list.children('.tw-dynamic-title-term');
		rows.each((index, row) => {
			$(row).find('input[type="text"]').attr('aria-label', termLabel(index));
			$(row).find('[data-move-dynamic-term-up]').prop('disabled', index === 0);
			$(row).find('[data-move-dynamic-term-down]').prop('disabled', index === rows.length - 1);
		});
	};

	const buildGroup = (slot) => {
		const slide = config.slides[slot] || { enabled: false, before: '', terms: [], after: '', interval: 3200 };
		const terms = slide.terms.length ? slide.terms : [''];
		return `
			<tr class="tw-dynamic-title-row">
				<th scope="row"><span>${escapeHtml(config.labels.group)}</span></th>
				<td>
					<fieldset class="tw-dynamic-title-fields" data-dynamic-title-fields>
						<label class="tw-dynamic-title-toggle">
							<input type="hidden" name="ticinoweb_slider_dynamic_enabled_${slot}" value="0">
							<input type="checkbox" name="ticinoweb_slider_dynamic_enabled_${slot}" value="1" ${slide.enabled ? 'checked' : ''}>
							<span>${escapeHtml(config.labels.enabled)}</span>
						</label>
						<label><span>${escapeHtml(config.labels.before)}</span><input type="text" name="ticinoweb_slider_dynamic_before_${slot}" value="${escapeHtml(slide.before)}" class="regular-text"></label>
						<div><span class="tw-dynamic-title-label">${escapeHtml(config.labels.terms)}</span><ul class="tw-dynamic-title-terms" data-dynamic-terms>${terms.map((term, index) => termRow(slot, term, index)).join('')}</ul><button type="button" class="button" data-add-dynamic-term>${escapeHtml(config.labels.addTerm)}</button></div>
						<label><span>${escapeHtml(config.labels.after)}</span><input type="text" name="ticinoweb_slider_dynamic_after_${slot}" value="${escapeHtml(slide.after)}" class="regular-text"></label>
						<label><span>${escapeHtml(config.labels.interval)}</span><input type="number" name="ticinoweb_slider_dynamic_interval_${slot}" value="${Number.parseInt(slide.interval, 10) || 3200}" min="1800" max="10000" step="100" class="small-text"></label>
						<p class="description">${escapeHtml(config.labels.description)}</p>
					</fieldset>
				</td>
			</tr>`;
	};

	const reindexDynamicFields = () => {
		$('#slider-items-container .slider-item').each((index, element) => {
			const slot = index + 1;
			$(element).find('[name^="ticinoweb_slider_dynamic_"]').each((fieldIndex, field) => {
				field.name = field.name.replace(/_(\d+)(\[\])?$/, `_${slot}$2`);
			});
			$(element).find('[data-dynamic-terms]').each((listIndex, list) => refreshTermList($(list)));
		});
	};

	$('#slider-items-container .slider-item').each((index, element) => {
		const item = $(element);
		item.find('.slider-item-body > .form-table > tbody').append(buildGroup(index + 1));
		const list = item.find('[data-dynamic-terms]');
		list.sortable({ handle: '.tw-dynamic-title-term__handle', axis: 'y', stop: () => refreshTermList(list) });
		refreshTermList(list);
		synchronizeSliderMedia(item);
		const preview = item.find('.slider-image-preview').get(0);
		if (preview) new MutationObserver(() => synchronizeSliderMedia(item)).observe(preview, { childList: true });
	});
	$(document).on('input change', '.slider-image-url', function () {
		synchronizeSliderMedia($(this).closest('.slider-item'));
	});

	$(document).on('click', '[data-add-dynamic-term]', function () {
		const item = $(this).closest('.slider-item');
		const slot = item.index() + 1;
		const list = item.find('[data-dynamic-terms]');
		list.append(termRow(slot, '', list.children().length));
		refreshTermList(list);
	});
	$(document).on('click', '[data-remove-dynamic-term]', function () {
		const list = $(this).closest('[data-dynamic-terms]');
		if (list.children().length > 1) $(this).closest('li').remove();
		else $(this).siblings('input').val('');
		refreshTermList(list);
	});
	$(document).on('click', '[data-move-dynamic-term-up]', function () {
		const row = $(this).closest('li');
		const previous = row.prev();
		if (previous.length) previous.before(row);
		refreshTermList(row.closest('[data-dynamic-terms]'));
	});
	$(document).on('click', '[data-move-dynamic-term-down]', function () {
		const row = $(this).closest('li');
		const next = row.next();
		if (next.length) next.after(row);
		refreshTermList(row.closest('[data-dynamic-terms]'));
	});
	$('#slider-items-container').on('sortstop', () => windowObject.setTimeout(reindexDynamicFields, 0));
	$(document).on('click', '.slider-move-up, .slider-move-down', () => windowObject.setTimeout(reindexDynamicFields, 0));
})(window, window.jQuery);
