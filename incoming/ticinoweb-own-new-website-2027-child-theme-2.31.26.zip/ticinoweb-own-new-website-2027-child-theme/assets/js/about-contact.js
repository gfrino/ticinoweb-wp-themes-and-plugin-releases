(() => {
	'use strict';
	const form = document.querySelector('[data-tw-about-form]');
	if (!form) return;
	const cfg = window.twAboutForm || {};
	const button = form.querySelector('button[type=submit]');
	const status = form.querySelector('.tw-about-form-status');
	const label = button.textContent;
	let busy = false;
	let recaptcha;
	const announce = (text) => { status.textContent = text; status.focus(); };
	const request = async (url, options) => {
		const response = await fetch(url, {credentials:'same-origin',cache:'no-store',...options});
		return response.json();
	};
	const captchaToken = async () => {
		if (!cfg.recaptcha_site_key) return '';
		if (!recaptcha) recaptcha = new Promise((resolve,reject) => {
			const script=document.createElement('script');
			script.src='https://www.google.com/recaptcha/api.js?render='+encodeURIComponent(cfg.recaptcha_site_key);
			script.onload=resolve;script.onerror=reject;document.head.append(script);
		});
		await recaptcha;
		return new Promise((resolve,reject)=>window.grecaptcha.ready(()=>window.grecaptcha.execute(cfg.recaptcha_site_key,{action:'contact'}).then(resolve,reject)));
	};
	form.addEventListener('input', e => {e.target.removeAttribute('aria-invalid');e.target.removeAttribute('aria-describedby');});
	form.addEventListener('submit', async (event) => {
		event.preventDefault();
		if (busy || !form.reportValidity()) return;
		if (!form.elements.privacy.checked) { announce(cfg.privacy);return; }
		busy=true;button.disabled=true;button.textContent=cfg.busy;form.setAttribute('aria-busy','true');status.textContent='';
		try {
			const [token,captcha]=await Promise.all([
				request(cfg.ajax_url+'?action='+encodeURIComponent(cfg.token_action)),captchaToken()
			]);
			if (!token.success || !token.data?.token) throw new Error();
			const data=new FormData(form);data.set('action',cfg.submit_action);data.set('token',token.data.token);
			if(captcha)data.set('recaptcha_token',captcha);
			const result=await request(cfg.ajax_url,{method:'POST',body:data});
			if(result.success){form.reset();announce(result.data.mailed?result.data.message:cfg.saved);}
			else {
				Object.keys(result.data?.fields||{}).forEach(name=>{form.elements[name]?.setAttribute('aria-invalid','true');form.elements[name]?.setAttribute('aria-describedby',status.id);});
				announce([result.data?.message||cfg.failure,...Object.values(result.data?.fields||{})].join(' '));
			}
		} catch { announce(cfg.failure); }
		finally {busy=false;button.disabled=false;button.textContent=label;form.removeAttribute('aria-busy');}
	});
})();
