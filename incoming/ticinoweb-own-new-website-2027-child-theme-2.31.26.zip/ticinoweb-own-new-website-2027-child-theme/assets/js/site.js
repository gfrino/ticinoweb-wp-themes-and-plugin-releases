(() => {
	'use strict';

	const OPEN_DELAY = 90;
	const CLOSE_DELAY = 180;
	const PANEL_TRANSITION = 230;
	const FEATURE_TRANSITION = 160;
	const header = document.querySelector('[data-site-header]');
	const toggle = document.querySelector('[data-menu-toggle]');
	const nav = document.querySelector('[data-primary-nav]');
	const cta = document.querySelector('[data-header-cta]');
	const backdrop = document.querySelector('[data-nav-backdrop]');
	const desktopMedia = window.matchMedia('(min-width: 1281px)');
	const focusableSelector = 'a[href], button:not([disabled]), [tabindex]:not([tabindex="-1"])';
	const panelHideTimers = new WeakMap();
	const featureSwitchTimers = new WeakMap();
	let activeDesktopItem = null;
	let openTimer = null;
	let closeTimer = null;
	let lastFocused = null;
	let suppressFocusOpen = false;
	let headerFrame = null;
	let headerIsScrolled = false;

	if (!header || !toggle || !nav) return;

	const directPanel = (item) => item?.querySelector(':scope > [data-menu-panel]');
	const directTrigger = (item) => item?.querySelector(':scope > .tw-nav-item__line > [data-submenu-toggle]');
	const clearDesktopTimers = () => {
		window.clearTimeout(openTimer);
		window.clearTimeout(closeTimer);
		openTimer = null;
		closeTimer = null;
	};
	const clearPanelHideTimer = (panel) => {
		const timer = panel ? panelHideTimers.get(panel) : null;
		if (timer) window.clearTimeout(timer);
		if (panel) panelHideTimers.delete(panel);
	};

	const hydratePanelMedia = (scope) => {
		scope?.querySelectorAll('[data-src]').forEach((image) => {
			if (image.closest('[hidden]')) return;
			image.src = image.dataset.src;
			if (image.dataset.srcset) image.srcset = image.dataset.srcset;
			image.removeAttribute('data-src');
			image.removeAttribute('data-srcset');
		});
	};

	const setBackdrop = (visible) => {
		if (!backdrop) return;
		if (visible) {
			backdrop.hidden = false;
			window.requestAnimationFrame(() => backdrop.classList.add('is-visible'));
		} else {
			backdrop.classList.remove('is-visible');
			window.setTimeout(() => {
				if (!activeDesktopItem) backdrop.hidden = true;
			}, PANEL_TRANSITION);
		}
	};

	const closeDesktopPanel = (item, returnFocus = false) => {
		if (!item) return;
		const trigger = directTrigger(item);
		const panel = directPanel(item);
		item.classList.remove('is-open');
		trigger?.setAttribute('aria-expanded', 'false');
		if (activeDesktopItem === item) activeDesktopItem = null;
		if (panel) {
			clearPanelHideTimer(panel);
			const timer = window.setTimeout(() => {
				if (!item.classList.contains('is-open')) panel.hidden = true;
				panelHideTimers.delete(panel);
			}, PANEL_TRANSITION);
			panelHideTimers.set(panel, timer);
		}
		if (!activeDesktopItem) {
			header.classList.remove('has-open-panel');
			document.body.classList.remove('tw-mega-open');
			setBackdrop(false);
		}
		if (returnFocus && trigger) {
			clearDesktopTimers();
			suppressFocusOpen = true;
			trigger.focus();
			window.requestAnimationFrame(() => { suppressFocusOpen = false; });
		}
	};

	const openDesktopPanel = (item) => {
		const trigger = directTrigger(item);
		const panel = directPanel(item);
		if (!trigger || !panel || !desktopMedia.matches) return;
		clearDesktopTimers();
		if (activeDesktopItem && activeDesktopItem !== item) {
			const previousItem = activeDesktopItem;
			const previousPanel = directPanel(previousItem);
			clearPanelHideTimer(previousPanel);
			previousItem.classList.remove('is-open');
			directTrigger(previousItem)?.setAttribute('aria-expanded', 'false');
			if (previousPanel) previousPanel.hidden = true;
		}
		activeDesktopItem = item;
		clearPanelHideTimer(panel);
		panel.hidden = false;
		trigger.setAttribute('aria-expanded', 'true');
		header.classList.add('has-open-panel');
		document.body.classList.add('tw-mega-open');
		setBackdrop(true);
		window.requestAnimationFrame(() => item.classList.add('is-open'));
		hydratePanelMedia(panel);
	};

	const scheduleDesktopOpen = (item) => {
		clearDesktopTimers();
		openTimer = window.setTimeout(() => openDesktopPanel(item), OPEN_DELAY);
	};
	const scheduleDesktopClose = (item) => {
		clearDesktopTimers();
		closeTimer = window.setTimeout(() => closeDesktopPanel(item), CLOSE_DELAY);
	};

	const closeMobileSubmenu = (item, returnFocus = false) => {
		const trigger = directTrigger(item);
		const panel = directPanel(item);
		item?.classList.remove('is-mobile-open');
		trigger?.setAttribute('aria-expanded', 'false');
		if (panel) panel.hidden = true;
		if (returnFocus) trigger?.focus();
	};
	const openMobileSubmenu = (item) => {
		const trigger = directTrigger(item);
		const panel = directPanel(item);
		if (!trigger || !panel) return;
		nav.querySelectorAll(':scope > ul > .is-mobile-open').forEach((sibling) => {
			if (sibling !== item) closeMobileSubmenu(sibling);
		});
		panel.hidden = false;
		item.classList.add('is-mobile-open');
		trigger.setAttribute('aria-expanded', 'true');
		hydratePanelMedia(panel);
	};

	const setMobileMenu = (open, returnFocus = true) => {
		if (open && activeDesktopItem) closeDesktopPanel(activeDesktopItem);
		toggle.setAttribute('aria-expanded', String(open));
		toggle.setAttribute('aria-label', open ? toggle.dataset.closeLabel : toggle.dataset.openLabel);
		header.classList.toggle('is-menu-open', open);
		nav.classList.toggle('is-open', open);
		document.body.classList.toggle('tw-menu-open', open);
		if (open) {
			lastFocused = document.activeElement;
			window.requestAnimationFrame(() => nav.querySelector(focusableSelector)?.focus());
		} else {
			nav.querySelectorAll('.is-mobile-open').forEach((item) => closeMobileSubmenu(item));
			if (returnFocus) (lastFocused instanceof HTMLElement ? lastFocused : toggle).focus();
		}
	};

	const showFeaturedProject = (source) => {
		const mega = source.closest('[data-mega-menu]');
		if (!mega) return;
		const groups = [...mega.querySelectorAll('[data-featured-project]')];
		const key = source.dataset.featureProject || 'default';
		const requested = groups.find((group) => group.dataset.featuredProject === key)
			|| groups.find((group) => group.dataset.featuredProject === 'default');
		if (!requested) return;
		const previousTimer = featureSwitchTimers.get(mega);
		if (previousTimer) window.clearTimeout(previousTimer);
		const current = groups.find((group) => !group.hidden);
		if (!current || current === requested) {
			groups.forEach((group) => { group.hidden = group !== requested; });
			hydratePanelMedia(requested);
			return;
		}
		current.classList.add('is-featured-leaving');
		const timer = window.setTimeout(() => {
			groups.forEach((group) => {
				group.hidden = group !== requested;
				group.classList.remove('is-featured-leaving', 'is-featured-entering');
			});
			requested.classList.add('is-featured-entering');
			hydratePanelMedia(requested);
			window.requestAnimationFrame(() => requested.classList.remove('is-featured-entering'));
			featureSwitchTimers.delete(mega);
		}, FEATURE_TRANSITION);
		featureSwitchTimers.set(mega, timer);
	};

	const selectServiceCategory = (button, allowCollapse = false) => {
		const explorer = button.closest('.tw-service-explorer');
		if (!explorer) return;
		const key = button.dataset.serviceCategory;
		const buttons = [...explorer.querySelectorAll('[data-service-category]')];
		const panes = [...explorer.querySelectorAll('[data-service-pane]')];
		const pane = panes.find((candidate) => candidate.dataset.servicePane === key);
		const wasSelected = button.getAttribute('aria-selected') === 'true';
		const collapse = allowCollapse && wasSelected;
		buttons.forEach((candidate) => {
			const selected = candidate === button && !collapse;
			candidate.setAttribute('aria-selected', String(selected));
			candidate.setAttribute('aria-expanded', String(selected));
		});
		panes.forEach((candidate) => { candidate.hidden = collapse || candidate !== pane; });
		if (!collapse && pane) {
			pane.classList.remove('is-pane-entering');
			window.requestAnimationFrame(() => pane.classList.add('is-pane-entering'));
			window.setTimeout(() => pane.classList.remove('is-pane-entering'), PANEL_TRANSITION);
			hydratePanelMedia(pane);
			const firstService = pane.querySelector('[data-feature-project]');
			if (firstService) showFeaturedProject(firstService);
		}
	};

	const initializePanels = () => {
		clearDesktopTimers();
		if (activeDesktopItem) closeDesktopPanel(activeDesktopItem);
		setMobileMenu(false, false);
		nav.querySelectorAll(':scope > ul > .menu-item-has-children').forEach((item) => {
			item.classList.remove('is-open', 'is-mobile-open');
			directTrigger(item)?.setAttribute('aria-expanded', 'false');
			const panel = directPanel(item);
			if (panel) panel.hidden = true;
		});
		nav.querySelectorAll('.tw-service-explorer').forEach((explorer) => {
			const buttons = [...explorer.querySelectorAll('[data-service-category]')];
			if (desktopMedia.matches && buttons[0]) selectServiceCategory(buttons[0]);
			if (!desktopMedia.matches) {
				buttons.forEach((button) => {
					button.setAttribute('aria-selected', 'false');
					button.setAttribute('aria-expanded', 'false');
				});
				explorer.querySelectorAll('[data-service-pane]').forEach((pane) => { pane.hidden = true; });
			}
		});
	};

	const topLevelItems = [...nav.querySelectorAll(':scope > ul > .menu-item-has-children')];
	topLevelItems.forEach((item) => {
		item.addEventListener('pointerenter', () => { if (desktopMedia.matches) scheduleDesktopOpen(item); });
		item.addEventListener('pointerleave', () => { if (desktopMedia.matches) scheduleDesktopClose(item); });
		item.addEventListener('focusin', () => { if (desktopMedia.matches && !suppressFocusOpen) scheduleDesktopOpen(item); });
		item.addEventListener('focusout', (event) => {
			if (desktopMedia.matches && !item.contains(event.relatedTarget)) scheduleDesktopClose(item);
		});
	});

	nav.addEventListener('click', (event) => {
		const category = event.target.closest('[data-service-category]');
		if (category) {
			selectServiceCategory(category, !desktopMedia.matches);
			return;
		}
		const submenuToggle = event.target.closest('[data-submenu-toggle]');
		if (submenuToggle) {
			const item = submenuToggle.closest('.menu-item');
			if (desktopMedia.matches) {
				activeDesktopItem === item ? closeDesktopPanel(item, true) : openDesktopPanel(item);
			} else {
				item.classList.contains('is-mobile-open') ? closeMobileSubmenu(item, true) : openMobileSubmenu(item);
			}
			return;
		}
		const link = event.target.closest('a');
		if (link && !desktopMedia.matches) setMobileMenu(false, false);
	});

	nav.addEventListener('pointerover', (event) => {
		if (!desktopMedia.matches) return;
		const category = event.target.closest('[data-service-category]');
		if (category) selectServiceCategory(category);
		const service = event.target.closest('[data-feature-project]');
		if (service) showFeaturedProject(service);
	});
	nav.addEventListener('focusin', (event) => {
		if (!desktopMedia.matches) return;
		const category = event.target.closest('[data-service-category]');
		if (category) selectServiceCategory(category);
		const service = event.target.closest('[data-feature-project]');
		if (service) showFeaturedProject(service);
	});
	nav.addEventListener('keydown', (event) => {
		const category = event.target.closest('[data-service-category]');
		if (!category || !desktopMedia.matches || !['ArrowDown', 'ArrowRight', 'ArrowUp', 'ArrowLeft', 'Home', 'End'].includes(event.key)) return;
		const buttons = [...category.closest('.tw-service-explorer').querySelectorAll('[data-service-category]')];
		let index = buttons.indexOf(category);
		if (event.key === 'Home') index = 0;
		else if (event.key === 'End') index = buttons.length - 1;
		else if (event.key === 'ArrowDown' || event.key === 'ArrowRight') index = (index + 1) % buttons.length;
		else index = (index - 1 + buttons.length) % buttons.length;
		event.preventDefault();
		buttons[index].focus();
		selectServiceCategory(buttons[index]);
	});

	toggle.addEventListener('click', () => setMobileMenu(toggle.getAttribute('aria-expanded') !== 'true'));
	backdrop?.addEventListener('click', () => closeDesktopPanel(activeDesktopItem));
	document.addEventListener('click', (event) => {
		if (desktopMedia.matches && activeDesktopItem && !event.target.closest('[data-site-header]')) closeDesktopPanel(activeDesktopItem);
	});
	document.addEventListener('keydown', (event) => {
		if (event.key === 'Escape') {
			if (activeDesktopItem) {
				closeDesktopPanel(activeDesktopItem, true);
				return;
			}
			const openMobile = nav.querySelector(':scope > ul > .is-mobile-open');
			if (openMobile) {
				closeMobileSubmenu(openMobile, true);
				return;
			}
			if (toggle.getAttribute('aria-expanded') === 'true') setMobileMenu(false);
		}
		if (event.key !== 'Tab' || desktopMedia.matches || toggle.getAttribute('aria-expanded') !== 'true') return;
		const focusable = [...nav.querySelectorAll(focusableSelector), cta, toggle]
			.filter((item) => item instanceof HTMLElement && item.offsetParent !== null);
		if (!focusable.length) return;
		const first = focusable[0];
		const last = focusable[focusable.length - 1];
		if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
		if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
	});

	const updateHeader = () => {
		const y = window.scrollY;
		if (!headerIsScrolled && y > 42) headerIsScrolled = true;
		if (headerIsScrolled && y < 12) headerIsScrolled = false;
		header.classList.toggle('is-scrolled', headerIsScrolled);
		const adminToolbar = document.getElementById('wpadminbar');
		const toolbarBottom = adminToolbar ? adminToolbar.getBoundingClientRect().bottom : 0;
		header.style.top = `${Math.max(0, toolbarBottom)}px`;
		document.documentElement.style.setProperty('--tw-header-overlay-top', `${header.getBoundingClientRect().bottom}px`);
		headerFrame = null;
	};
	const scheduleHeaderUpdate = () => {
		if (headerFrame !== null) return;
		headerFrame = window.requestAnimationFrame(updateHeader);
	};
	window.addEventListener('scroll', scheduleHeaderUpdate, { passive: true });
	window.addEventListener('resize', scheduleHeaderUpdate, { passive: true });
	if ('ResizeObserver' in window) new ResizeObserver(scheduleHeaderUpdate).observe(header);
	desktopMedia.addEventListener('change', initializePanels);
	updateHeader();
	initializePanels();
})();
