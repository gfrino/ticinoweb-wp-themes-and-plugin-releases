(() => {
	'use strict';
	document.querySelectorAll('[data-share-copy]').forEach((button) => {
		button.addEventListener('click', async () => {
			const url = button.dataset.shareCopy;
			try {
				if (navigator.share && window.matchMedia('(pointer: coarse)').matches) {
					await navigator.share({ title: document.title, url });
					return;
				}
				await navigator.clipboard.writeText(url);
				const label = button.getAttribute('aria-label');
				button.classList.add('is-copied');
				button.setAttribute('aria-label', button.dataset.copiedLabel || label);
				button.title = button.dataset.copiedLabel || label;
				window.setTimeout(() => { button.classList.remove('is-copied'); button.setAttribute('aria-label', label); button.title = label; }, 1800);
			} catch (e) { /* share dismissed or clipboard unavailable */ }
		});
	});
})();
