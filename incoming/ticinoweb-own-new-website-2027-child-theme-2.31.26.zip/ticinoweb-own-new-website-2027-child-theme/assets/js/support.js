(() => {
	'use strict';
	const form = document.querySelector('[data-support-session]');
	const input = form?.querySelector('[name="key"]');
	if (!form || !input) return;
	const normalize = () => {
		input.value = input.value.replace(/[\s-]/g, '');
		input.setCustomValidity(input.value && !/^\d{9}$/.test(input.value) ? input.dataset.invalidMessage : '');
	};
	input.addEventListener('input', () => input.setCustomValidity(''));
	input.addEventListener('change', normalize);
	input.addEventListener('invalid', () => {
		if (!input.value || !/^\d{9}$/.test(input.value.replace(/[\s-]/g, ''))) input.setCustomValidity(input.dataset.invalidMessage);
	});
	form.addEventListener('submit', (event) => {
		normalize();
		if (!form.checkValidity()) {
			event.preventDefault();
			input.reportValidity();
		}
	});
})();

(() => {
	'use strict';
	const wanted = new URLSearchParams(window.location.search).get('servizio');
	if (!wanted) return;
	const radio = document.querySelector(`.tw-service-tile input[value="${CSS.escape(wanted)}"]`);
	if (radio) radio.checked = true;
})();
