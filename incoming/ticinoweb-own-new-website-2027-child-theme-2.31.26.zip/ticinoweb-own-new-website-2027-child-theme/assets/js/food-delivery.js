/* Parallasse delle foto di sfondo e comparsa degli elementi allo scorrimento (pagina Food Delivery). */
( function () {
	'use strict';
	var reduce = window.matchMedia && window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches;
	var layers = Array.prototype.slice.call( document.querySelectorAll( '[data-tw-parallax]' ) );
	var reveals = Array.prototype.slice.call( document.querySelectorAll( '[data-tw-reveal]' ) );

	if ( ! reduce && 'IntersectionObserver' in window ) {
		document.documentElement.classList.add( 'tw-food-js' );
		var io = new IntersectionObserver( function ( entries ) {
			entries.forEach( function ( e ) {
				if ( e.isIntersecting ) { e.target.classList.add( 'is-in' ); io.unobserve( e.target ); }
			} );
		}, { threshold: 0.12 } );
		reveals.forEach( function ( el ) { io.observe( el ); } );
	}

	if ( reduce || ! layers.length ) { return; }
	var ticking = false;
	function update() {
		ticking = false;
		var vh = window.innerHeight;
		layers.forEach( function ( el ) {
			var box = el.parentNode.getBoundingClientRect();
			if ( box.bottom < -100 || box.top > vh + 100 ) { return; }
			var offset = ( box.top + box.height / 2 ) - vh / 2;
			el.style.transform = 'translate3d(0,' + ( offset * -parseFloat( el.getAttribute( 'data-tw-parallax' ) ) ).toFixed( 1 ) + 'px,0)';
		} );
	}
	function request() { if ( ! ticking ) { ticking = true; window.requestAnimationFrame( update ); } }
	window.addEventListener( 'scroll', request, { passive: true } );
	window.addEventListener( 'resize', request );
	update();
}() );
