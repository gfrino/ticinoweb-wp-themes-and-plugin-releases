(() => {
	'use strict';
	const archive = document.querySelector('[data-project-archive]');
	if (!archive) return;

	const button = archive.querySelector('[data-project-archive-more]');
	const grid = archive.querySelector('[data-project-archive-grid]');
	const status = archive.querySelector('[data-project-archive-status]');
	if (!button || !grid || !status) return;

	button.addEventListener('click', async () => {
		const nextPage = Number.parseInt(archive.dataset.page || '1', 10) + 1;
		const url = new URL(archive.dataset.restUrl, window.location.origin);
		url.searchParams.set('page', String(nextPage));
		if (archive.dataset.taxonomy && archive.dataset.term) {
			url.searchParams.set('taxonomy', archive.dataset.taxonomy);
			url.searchParams.set('term', archive.dataset.term);
		}
		button.disabled = true;
		button.setAttribute('aria-busy', 'true');
		status.textContent = 'Caricamento…';
		try {
			const response = await fetch(url, { headers: { Accept: 'application/json' } });
			if (!response.ok) throw new Error(String(response.status));
			const result = await response.json();
			const fragment = document.createRange().createContextualFragment(result.html || '');
			fragment.querySelectorAll('.tw-project-archive-card').forEach((card) => card.classList.add('is-entering'));
			grid.append(fragment);
			archive.dataset.page = String(nextPage);
			archive.dataset.pages = String(result.pages || nextPage);
			button.hidden = nextPage >= Number.parseInt(archive.dataset.pages, 10);
			status.textContent = result.html ? 'Altri progetti caricati.' : 'Non ci sono altri progetti.';
		} catch (error) {
			status.textContent = 'Non è stato possibile caricare altri progetti. Riprova.';
		} finally {
			button.disabled = false;
			button.removeAttribute('aria-busy');
		}
	});
})();
