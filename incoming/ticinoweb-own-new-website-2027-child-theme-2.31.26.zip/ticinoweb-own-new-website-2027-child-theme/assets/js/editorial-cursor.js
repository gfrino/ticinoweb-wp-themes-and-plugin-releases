/* Adapted from Codrops Sketch 018, Copyright (c) 2022 Codrops, MIT License.
 * See licenses/CODROPS-MIT.txt. Original Cursor/CursorElement, lerp and filter
 * timeline are retained; demo UI, per-link listeners and endless RAF are removed.
 */
export const lerp=(a,b,n)=>(1-n)*a+n*b;
export const eligible=({fine,hover})=>fine&&hover;
export const INTERACTIVE='a,button,[role="button"],input[type="submit"],input[type="button"],summary,[aria-expanded],[data-project-trigger],.tw-project-card,.woocommerce .button';
export function trackPoint(previous,target,amount,elapsed,reduced=false,maxLag=Infinity){
 if(reduced)return {...target};
 const weight=1-Math.pow(1-amount,Math.max(0,elapsed)/(1000/60));
 let x=lerp(previous.x,target.x,weight),y=lerp(previous.y,target.y,weight);
 const dx=x-target.x,dy=y-target.y,distance=Math.hypot(dx,dy);
 if(distance>maxLag){x=target.x+dx/distance*maxLag;y=target.y+dy/distance*maxLag;}
 return {x,y};
}

export class CursorElement{
 constructor(el,gsap,filterSupported){
  this.DOM={el,inner:el.querySelector('circle'),feTurbulence:el.querySelector('feTurbulence'),displacement:el.querySelector('feDisplacementMap')};
  this.amount=Number(el.dataset.amt);this.maxLag=Number(el.dataset.maxLag);
  this.position={x:0,y:0};this.gsap=gsap;this.filterSupported=filterSupported;
  this.filterId='#'+el.querySelector('filter').id;
  this.primitiveValues={turbulence:.01,strength:0,scale:1,opacity:1,joltX:0,joltY:0};this.filterTimeline=null;this.joltTimeline=null;this.exitTween=null;this.pulse=null;
  this.createFilterTimeline();
 }
 applyFilter(){
  try{
   this.DOM.feTurbulence.setAttribute('baseFrequency',String(this.primitiveValues.turbulence));
   this.DOM.displacement.setAttribute('scale',String(this.primitiveValues.strength));
   this.DOM.inner.style.transform=`translate(${this.primitiveValues.joltX}px,${this.primitiveValues.joltY}px) scale(${this.primitiveValues.scale})`;
   this.DOM.inner.style.opacity=String(this.primitiveValues.opacity);
  }catch{this.filterSupported=false;this.resetFilter();}
 }
 resetFilter(){
  Object.assign(this.primitiveValues,{turbulence:.01,strength:0,scale:1,opacity:1,joltX:0,joltY:0});
  this.DOM.inner.style.filter='none';this.DOM.inner.style.transform='scale(1)';this.DOM.inner.style.opacity='1';
  this.DOM.feTurbulence.setAttribute('baseFrequency','.01');this.DOM.displacement.setAttribute('scale','0');
 }
 createFilterTimeline(){
  if(!this.gsap||!this.filterSupported)return;
  this.filterTimeline=this.gsap.timeline({paused:true,onStart:()=>{
   this.DOM.inner.style.filter=`url(${this.filterId})`;
  },onUpdate:()=>this.applyFilter()})
  .to(this.primitiveValues,{turbulence:.025,strength:9,scale:1.8,opacity:.25,duration:1.15,ease:'power2.out'});
  // Short damped impulse; only the circle moves, never the actual pointer.
  const direction=this.amount>.2?1:-1;
  this.joltTimeline=this.gsap.timeline({paused:true,onUpdate:()=>this.applyFilter()})
  .to(this.primitiveValues,{joltX:2.4*direction,joltY:-1*direction,duration:.05,ease:'sine.out'})
  .to(this.primitiveValues,{joltX:-2*direction,joltY:.9*direction,duration:.065,ease:'sine.inOut'})
  .to(this.primitiveValues,{joltX:1.3*direction,joltY:-.6*direction,duration:.065,ease:'sine.inOut'})
  .to(this.primitiveValues,{joltX:-.6*direction,joltY:.3*direction,duration:.08,ease:'sine.inOut'})
  .to(this.primitiveValues,{joltX:0,joltY:0,duration:.1,ease:'sine.out'});
 }
 enter(){
  if(!this.filterTimeline||!this.filterSupported)return;
  this.exitTween?.kill();this.pulse?.cancel();this.filterTimeline.invalidate().restart();this.joltTimeline?.invalidate().restart();
 }
 leave(){
  this.filterTimeline?.pause();this.joltTimeline?.pause();this.exitTween?.kill();
  if(!this.gsap||!this.filterSupported){this.resetFilter();return;}
  this.exitTween=this.gsap.to(this.primitiveValues,{turbulence:.01,strength:0,scale:1,opacity:1,joltX:0,joltY:0,duration:.4,ease:'power2.out',onUpdate:()=>this.applyFilter(),onComplete:()=>this.resetFilter()});
 }
 snap(point){this.position={...point};this.paint();}
 paint(){this.DOM.el.style.transform=`translate3d(${this.position.x-32}px,${this.position.y-32}px,0)`;}
 render(point,elapsed,reduced){this.position=trackPoint(this.position,point,this.amount,elapsed,reduced,this.maxLag);this.paint();return Math.hypot(point.x-this.position.x,point.y-this.position.y)>.08;}
 click(){
  this.pulse?.cancel();this.pulse=this.DOM.inner.animate([{transform:'scale(.9)'},{transform:'scale(1)'}],{duration:100,easing:'ease-out'});
 }
 stop(){this.filterTimeline?.pause();this.joltTimeline?.pause();this.exitTween?.kill();this.pulse?.cancel();this.resetFilter();}
}

export class Cursor{
 constructor(root,gsap){
  this.root=root;this.pointer=matchMedia('(hover: hover) and (pointer: fine)');this.reduced=matchMedia('(prefers-reduced-motion: reduce)');
  this.point={x:0,y:0};this.frame=0;this.lastTime=0;this.visible=false;this.lastTarget=null;this.activeTrigger=null;
  const supported=typeof window.SVGFETurbulenceElement==='function'&&typeof window.SVGFEDisplacementMapElement==='function';
  this.elements=[...root.querySelectorAll('svg[data-cursor-element]')].map(el=>new CursorElement(el,gsap,supported));
  if(this.elements.length!==2)throw new Error('Cursor markup unavailable');
  root.dataset.filter=supported&&gsap?'ready':'fallback';
  document.addEventListener('pointermove',event=>this.move(event),{passive:true});
  document.addEventListener('pointerover',event=>this.move(event),{passive:true});
  document.addEventListener('pointerout',event=>{if(!event.relatedTarget)this.hide();},{passive:true});
  document.addEventListener('pointerdown',event=>{
   this.move(event);if(this.visible&&!this.reduced.matches&&!this.activeTrigger)this.elements.forEach(el=>el.click());
  },{passive:true});
  document.addEventListener('pointercancel',()=>this.hide(),{passive:true});
  document.addEventListener('visibilitychange',()=>{if(document.hidden)this.hide();});
  window.addEventListener('blur',()=>this.hide());
  window.addEventListener('error',event=>{if(event.filename?.includes('editorial-cursor'))this.hide();});
  this.pointer.addEventListener('change',()=>this.hide());
  this.reduced.addEventListener('change',()=>{
   this.stop();this.activeTrigger=null;if(this.visible)this.elements.forEach(el=>el.snap(this.point));
  });
  window.addEventListener('scroll',()=>{if(this.visible){this.lastTarget=null;this.updateTarget(document.elementFromPoint(this.point.x,this.point.y));}},{passive:true});
 }
 stop(){cancelAnimationFrame(this.frame);this.frame=0;this.lastTime=0;this.elements.forEach(el=>el.stop());}
 hide(){this.stop();this.visible=false;this.activeTrigger=null;this.root.dataset.visible='false';document.documentElement.classList.remove('tw-cursor-on');}
 themeFor(target){
  const explicit=target.closest('[data-cursor-theme]')?.dataset.cursorTheme;
  if(explicit==='dark'||explicit==='light')return explicit;
  for(let node=target;node&&node!==document.documentElement;node=node.parentElement){
   if(node.matches('img,picture,.tw-hero,.tw-project-card__media,.tw-mega-feature__media'))return 'dark';
   const color=getComputedStyle(node).backgroundColor.match(/[\d.]+/g);
   if(color&&color.length>=3&&(color.length===3||Number(color[3])>.9)){
    const [r,g,b]=color.map(Number);return .2126*r+.7152*g+.0722*b<130?'dark':'light';
   }
  }
  return 'light';
 }
 updateTarget(target){
  if(!(target instanceof Element))return;
  if(target!==this.lastTarget){this.root.dataset.theme=this.themeFor(target);this.lastTarget=target;}
  const trigger=target.closest(INTERACTIVE);
  if(trigger!==this.activeTrigger){
   if(this.activeTrigger)this.elements.forEach(el=>el.leave());
   this.activeTrigger=trigger;
   if(trigger&&!this.reduced.matches)this.elements.forEach(el=>el.enter());
  }
 }
 move(event){
  if(event.pointerType!=='mouse'||!this.pointer.matches||document.hidden){this.hide();return;}
  try{
   if(event.target instanceof Element&&event.target.closest('iframe')){this.hide();return;}
   this.point={x:event.clientX,y:event.clientY};
   if(!this.visible){
    this.elements.forEach(el=>el.snap(this.point));this.visible=true;this.root.hidden=false;
    this.root.dataset.visible='true';document.documentElement.classList.add('tw-cursor-on');
   }
   this.updateTarget(event.target);
   if(this.reduced.matches)this.elements.forEach(el=>el.snap(this.point));
   else if(!this.frame)this.frame=requestAnimationFrame(time=>this.render(time));
  }catch{this.hide();}
 }
 render(time){
  this.frame=0;if(!this.visible||document.hidden)return;
  try{
   const elapsed=this.lastTime?Math.min(64,time-this.lastTime):1000/60;this.lastTime=time;let moving=false;
   for(const el of this.elements){if(el.render(this.point,elapsed,this.reduced.matches))moving=true;}
   if(moving)this.frame=requestAnimationFrame(next=>this.render(next));else this.lastTime=0;
  }catch{this.hide();}
 }
}
if(typeof document!=='undefined'){
 const root=document.getElementById('tw-cursor');
 if(root&&matchMedia('(hover: hover) and (pointer: fine)').matches){
  try{new Cursor(root,window.gsap);}catch{root.remove();document.documentElement.classList.remove('tw-cursor-on');}
 }
}
