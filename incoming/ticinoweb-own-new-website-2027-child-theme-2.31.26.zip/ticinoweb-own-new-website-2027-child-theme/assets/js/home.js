(() => {
	'use strict';

	const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
	const HERO_VIDEO_FADE_MS = 520;
	const HERO_VIDEO_LOOP_LEAD = 0.75;
	// Hold the end of Team while Partner and Projects rise together as one sheet.
	document.querySelectorAll('.tw-project-sheet-stage').forEach((stage) => {
		const predecessor = stage.querySelector(':scope > .tw-team');
		if (!predecessor || reduceMotion) return;
		const measure = () => stage.style.setProperty('--tw-sheet-predecessor-height', `${Math.ceil(predecessor.getBoundingClientRect().height)}px`);
		measure();
		if ('ResizeObserver' in window) new ResizeObserver(measure).observe(predecessor);
		else window.addEventListener('resize', measure, { passive: true });
	});
	if (!reduceMotion) {
		document.documentElement.classList.add('tw-home-enhanced');
		const revealItems = document.querySelectorAll('[data-home-reveal]');
		if ('IntersectionObserver' in window) {
			const revealObserver = new IntersectionObserver((entries, observer) => {
				entries.forEach((entry) => {
					if (!entry.isIntersecting) return;
					entry.target.classList.add('is-visible');
					observer.unobserve(entry.target);
				});
			}, { rootMargin: '0px 0px -8% 0px', threshold: 0.08 });
			revealItems.forEach((item) => revealObserver.observe(item));
		} else {
			revealItems.forEach((item) => item.classList.add('is-visible'));
		}
	}

	document.querySelectorAll('[data-service-index]').forEach((index) => {
		const triggers = [...index.querySelectorAll('[data-service-trigger]')];
		const panels = [...index.querySelectorAll('[data-service-panel]')];
		const activate = (value) => {
			triggers.forEach((trigger) => {
				const active = trigger.dataset.serviceTrigger === value;
				trigger.setAttribute('aria-expanded', String(active));
				trigger.closest('.tw-service-index__item')?.classList.toggle('is-active', active);
			});
			panels.forEach((panel) => {
				const active = panel.dataset.servicePanel === value;
				panel.hidden = !active;
				panel.classList.toggle('is-active', active);
			});
		};
		triggers.forEach((trigger) => {
			trigger.addEventListener('click', () => activate(trigger.dataset.serviceTrigger));
			trigger.addEventListener('mouseenter', () => {
				if (window.matchMedia('(min-width: 961px)').matches) activate(trigger.dataset.serviceTrigger);
			});
		});
	});

	document.querySelectorAll('[data-partner-marquee]').forEach((marquee) => {
		if (reduceMotion) return;
		// Scorrimento a velocità costante in pixel: la distanza è la larghezza reale di una sequenza
		// (non il 50% teorico della pista) e, se i loghi sono pochi, le sequenze si ripetono finché
		// la pista copre lo schermo: niente salti e niente spazio vuoto.
		const track = marquee.querySelector('[data-partner-track]');
		const firstSequence = track?.querySelector('.tw-partners__sequence');
		const layoutMarquee = () => {
			if (!track || !firstSequence) return;
			track.querySelectorAll('[data-marquee-clone]').forEach((node) => node.remove());
			const width = firstSequence.getBoundingClientRect().width;
			if (!width) return;
			const existing = track.querySelectorAll('.tw-partners__sequence').length;
			const needed = 1 + Math.ceil(marquee.clientWidth / width);
			for (let index = existing; index < needed; index += 1) {
				const clone = track.lastElementChild.cloneNode(true);
				clone.setAttribute('aria-hidden', 'true');
				clone.setAttribute('data-marquee-clone', '');
				clone.querySelectorAll('a').forEach((link) => link.setAttribute('tabindex', '-1'));
				track.append(clone);
			}
			const pixelsPerSecond = window.matchMedia('(max-width: 767px)').matches ? 24 : 36;
			track.style.setProperty('--tw-marquee-distance', `-${width}px`);
			track.style.animationDuration = `${Math.max(20, width / pixelsPerSecond)}s`;
		};
		layoutMarquee();
		if ('ResizeObserver' in window) {
			let lastWidth = marquee.clientWidth;
			new ResizeObserver(() => {
				if (marquee.clientWidth !== lastWidth) { lastWidth = marquee.clientWidth; layoutMarquee(); }
			}).observe(marquee);
		}
		window.addEventListener('load', layoutMarquee, { once: true });
		const updateVisibility = () => {
			marquee.classList.toggle('is-partner-paused', document.hidden);
		};
		if ('IntersectionObserver' in window) {
			const partnerObserver = new IntersectionObserver((entries) => {
				entries.forEach((entry) => marquee.classList.toggle('is-partner-active', entry.isIntersecting));
			}, { rootMargin: '120px 0px', threshold: 0.01 });
			partnerObserver.observe(marquee);
		} else {
			marquee.classList.add('is-partner-active');
		}
		document.addEventListener('visibilitychange', updateVisibility);
		updateVisibility();
	});

	const hero = document.querySelector('[data-hero-slider]');
	if (!hero) return;
	const slides = [...hero.querySelectorAll('[data-hero-slide]')];
	const heroVideos = [...hero.querySelectorAll('[data-hero-video]')];
	const videoLoopTimers = new WeakMap();

	const playHeroVideo = (video) => {
		const playRequest = video.play();
		if (playRequest?.catch) playRequest.catch(() => {});
	};
	const cancelHeroVideoLoop = (video) => {
		const timer = videoLoopTimers.get(video);
		if (timer) window.clearTimeout(timer);
		videoLoopTimers.delete(video);
		video.classList.remove('is-loop-fading');
		video.dataset.looping = 'false';
	};
	const startHeroVideoLoop = (video) => {
		if (reduceMotion || video.dataset.looping === 'true' || !video.closest('[data-hero-slide]')?.classList.contains('is-active')) return;
		video.dataset.looping = 'true';
		video.classList.add('is-loop-fading');
		const timer = window.setTimeout(() => {
			video.currentTime = 0;
			if (!document.hidden && video.closest('[data-hero-slide]')?.classList.contains('is-active')) playHeroVideo(video);
			window.requestAnimationFrame(() => window.requestAnimationFrame(() => {
				video.classList.remove('is-loop-fading');
				video.dataset.looping = 'false';
				videoLoopTimers.delete(video);
			}));
		}, HERO_VIDEO_FADE_MS);
		videoLoopTimers.set(video, timer);
	};
	const synchronizeHeroVideos = () => {
		heroVideos.forEach((video) => {
			video.muted = true;
			const active = video.closest('[data-hero-slide]')?.classList.contains('is-active');
			if (reduceMotion || document.hidden || !active) {
				cancelHeroVideoLoop(video);
				video.pause();
				if (reduceMotion && video.readyState >= 1) video.currentTime = 0;
				return;
			}
			playHeroVideo(video);
		});
	};
	heroVideos.forEach((video) => {
		video.addEventListener('timeupdate', () => {
			if (Number.isFinite(video.duration) && video.duration - video.currentTime <= HERO_VIDEO_LOOP_LEAD) startHeroVideoLoop(video);
		});
		video.addEventListener('ended', () => startHeroVideoLoop(video));
		if (reduceMotion) video.addEventListener('loadedmetadata', () => { video.pause(); video.currentTime = 0; }, { once: true });
	});
	window.requestAnimationFrame(() => {
		window.requestAnimationFrame(() => document.documentElement.classList.add('tw-hero-loaded'));
	});
	synchronizeHeroVideos();
	document.addEventListener('visibilitychange', synchronizeHeroVideos);

	// Hero title fit: translated titles (EN/DE/FR) are longer than the Italian
	// ones. Shrink the font only as much as needed so the whole copy fits the
	// hero height and no word overflows its column; the CSS clamp stays the max.
	const HERO_TITLE_MIN_PX = 34;
	const fitHeroTitle = (slide) => {
		if (!slide || !slide.classList.contains('is-active')) return;
		const inner = slide.querySelector('.tw-hero__inner');
		const copy = slide.querySelector('.tw-hero__copy');
		const title = copy?.querySelector('h1, h2');
		if (!inner || !copy || !title) return;
		title.style.removeProperty('font-size');
		const slot = title.querySelector('.tw-hero-dynamic-title__slot');
		const terms = [...title.querySelectorAll('[data-hero-term]')];
		const slotHeight = slot ? slot.style.height : '';
		const innerStyle = window.getComputedStyle(inner);
		const boundHeight = innerStyle.display !== 'contents';
		const available = inner.clientHeight - parseFloat(innerStyle.paddingTop) - parseFloat(innerStyle.paddingBottom);
		const parts = [...title.querySelectorAll('.tw-hero-dynamic-title__before, .tw-hero-dynamic-title__after, [data-hero-term]')];
		const fits = () => {
			// Measure with the tallest rotating term, so no term overflows later.
			if (slot && terms.length) {
				slot.style.height = 'auto';
				slot.style.height = `${Math.max(...terms.map((term) => term.offsetHeight))}px`;
			}
			const wide = (parts.length ? parts : [title]).some((part) => part.scrollWidth > part.clientWidth + 1) || title.scrollWidth > copy.clientWidth + 1;
			return !wide && (!boundHeight || copy.offsetHeight <= available);
		};
		let size = parseFloat(window.getComputedStyle(title).fontSize);
		const min = Math.min(HERO_TITLE_MIN_PX, size);
		while (size > min && !fits()) {
			size = Math.max(min, size - 2);
			title.style.fontSize = `${size}px`;
		}
		if (slot) {
			slot.style.height = slotHeight;
			const current = title.querySelector('[data-hero-term].is-current');
			if (slotHeight && current) slot.style.height = `${current.offsetHeight}px`;
		}
	};
	const fitActiveHeroTitle = () => slides.forEach((slide) => fitHeroTitle(slide));
	let heroFitFrame = null;
	const scheduleHeroFit = () => {
		if (heroFitFrame) window.cancelAnimationFrame(heroFitFrame);
		heroFitFrame = window.requestAnimationFrame(() => { heroFitFrame = null; fitActiveHeroTitle(); });
	};
	fitActiveHeroTitle();
	document.fonts?.ready.then(scheduleHeroFit);
	window.addEventListener('resize', scheduleHeroFit, { passive: true });
	if ('MutationObserver' in window) {
		const slideObserver = new MutationObserver(scheduleHeroFit);
		slides.forEach((slide) => slideObserver.observe(slide, { attributes: true, attributeFilter: ['class'] }));
	}

	document.querySelectorAll('[data-hero-rotator]').forEach((rotator) => {
		const terms = [...rotator.querySelectorAll('[data-hero-term]')];
		if (reduceMotion || terms.length < 2) return;
		const interval = Math.min(10000, Math.max(1800, Number.parseInt(rotator.dataset.interval || '3200', 10)));
		let current = 0;
		let changeTimer = null;
		let transitionTimer = null;
		let pending = null;
		const slot = rotator.querySelector('.tw-hero-dynamic-title__slot');
		const compactTitle = window.matchMedia('(max-width: 1180px)');
		const syncTitleHeight = (term = pending?.incoming || terms[current]) => {
			if (!slot) return;
			if (compactTitle.matches) slot.style.height = `${term.offsetHeight}px`;
			else slot.style.removeProperty('height');
		};
		syncTitleHeight();
		window.addEventListener('resize', () => syncTitleHeight(), { passive: true });
		document.fonts?.ready.then(() => syncTitleHeight());

		const clearTimers = () => {
			if (changeTimer) window.clearTimeout(changeTimer);
			if (transitionTimer) window.clearTimeout(transitionTimer);
			changeTimer = null;
			transitionTimer = null;
		};
		const schedule = (delay = interval) => {
			if (document.hidden) return;
			if (changeTimer) window.clearTimeout(changeTimer);
			changeTimer = window.setTimeout(swap, delay);
		};
		const finishSwap = () => {
			if (!pending) return;
			const { outgoing, incoming, next } = pending;
			outgoing.classList.remove('is-current', 'is-leaving');
			incoming.classList.remove('is-entering');
			incoming.classList.add('is-current');
			current = next;
			pending = null;
			transitionTimer = null;
			schedule();
		};
		function swap() {
			changeTimer = null;
			const next = (current + 1) % terms.length;
			const outgoing = terms[current];
			const incoming = terms[next];
			pending = { outgoing, incoming, next };
			syncTitleHeight(incoming);
			outgoing.classList.add('is-leaving');
			incoming.classList.add('is-entering');
			transitionTimer = window.setTimeout(finishSwap, 660);
		}

		document.addEventListener('visibilitychange', () => {
			if (document.hidden) {
				clearTimers();
				finishSwap();
			} else {
				schedule();
			}
		});
		// L'ingresso Hero dura circa 900 ms: il primo cambio arriva ~1,9 s dopo la sua conclusione.
		schedule(2800);
	});

	if (!reduceMotion && window.matchMedia('(min-width: 768px)').matches) {
		let parallaxFrame = null;
		const updateHeroShift = () => {
			parallaxFrame = null;
			const bounds = hero.getBoundingClientRect();
			if (bounds.bottom <= 0 || bounds.top >= window.innerHeight) return;
			const shift = Math.min(18, Math.max(0, window.scrollY * 0.045));
			hero.style.setProperty('--tw-hero-shift', `${shift}px`);
		};
		const requestHeroShift = () => {
			if (parallaxFrame === null) parallaxFrame = window.requestAnimationFrame(updateHeroShift);
		};
		window.addEventListener('scroll', requestHeroShift, { passive: true });
		updateHeroShift();
	}

	if (slides.length < 2) return;
	const previous = hero.querySelector('[data-hero-prev]');
	const next = hero.querySelector('[data-hero-next]');
	const autoplayToggle = hero.querySelector('[data-hero-toggle]');
	const currentLabel = hero.querySelector('[data-hero-current]');
	let current = 0;
	let timer = null;
	let pointerStart = null;
	let userPaused = reduceMotion;

	const show = (target) => {
		current = (target + slides.length) % slides.length;
		slides.forEach((slide, index) => {
			const active = index === current;
			slide.classList.toggle('is-active', active);
			slide.setAttribute('aria-hidden', String(!active));
		});
		if (currentLabel) currentLabel.textContent = String(current + 1).padStart(2, '0');
		synchronizeHeroVideos();
	};
	const stop = () => { if (timer) window.clearInterval(timer); timer = null; };
	const updateAutoplayControl = () => {
		if (!autoplayToggle) return;
		autoplayToggle.setAttribute('aria-pressed', String(userPaused));
		autoplayToggle.setAttribute('aria-label', userPaused ? autoplayToggle.dataset.playLabel : autoplayToggle.dataset.pauseLabel);
		autoplayToggle.textContent = userPaused ? '▶' : 'Ⅱ';
	};
	const start = () => {
		stop();
		if (!userPaused && !document.hidden) timer = window.setInterval(() => show(current + 1), 8000);
	};
	const pauseFromInteraction = () => { userPaused = true; stop(); updateAutoplayControl(); };
	previous?.addEventListener('click', () => { show(current - 1); pauseFromInteraction(); });
	next?.addEventListener('click', () => { show(current + 1); pauseFromInteraction(); });
	autoplayToggle?.addEventListener('click', () => {
		userPaused = !userPaused;
		updateAutoplayControl();
		userPaused ? stop() : start();
	});
	hero.addEventListener('mouseenter', stop);
	hero.addEventListener('mouseleave', start);
	hero.addEventListener('focusin', stop);
	hero.addEventListener('focusout', start);
	hero.addEventListener('pointerdown', (event) => { pointerStart = event.clientX; });
	hero.addEventListener('pointerup', (event) => {
		if (pointerStart === null) return;
		const distance = event.clientX - pointerStart;
		pointerStart = null;
		if (Math.abs(distance) > 55) { show(current + (distance < 0 ? 1 : -1)); pauseFromInteraction(); }
	});
	document.addEventListener('visibilitychange', () => {
		document.hidden ? stop() : start();
	});
	updateAutoplayControl();
	start();
})();
