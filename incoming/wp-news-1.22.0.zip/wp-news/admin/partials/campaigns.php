<?php
/**
 * Campaigns list and stats admin page.
 *
 * @package WPNews
 */

if (!defined('ABSPATH')) {
	exit;
}

$view        = isset($_GET['view']) ? sanitize_key(wp_unslash($_GET['view'])) : 'list';
$campaign_id = isset($_GET['id']) ? absint($_GET['id']) : 0;
$admin_base  = admin_url('admin.php');

// ==========================================
// VIEW: STATS
// ==========================================
if ('stats' === $view && $campaign_id) {
	global $wpdb;

	$campaign = WPNews_Campaign_Manager::get_campaign($campaign_id);
	if (!$campaign || !is_array($campaign)) {
		wp_die(esc_html__('Campaign not found', 'wp-news'), '', array('response' => 404));
	}

	$stats_table       = $wpdb->prefix . 'wpnews_campaign_stats';
	$subscribers_table = $wpdb->prefix . 'wpnews_subscribers';
	$blacklist_table   = $wpdb->prefix . 'wpnews_blacklist';
	$campaigns_table   = $wpdb->prefix . 'wpnews_campaigns';

	$is_parent = !empty($campaign['is_recurring']);

	// Recurring parents aggregate their child snapshots.
	$all_ids            = array($campaign_id);
	$children_campaigns = array();
	if ($is_parent) {
		$children_campaigns = $wpdb->get_results(
			$wpdb->prepare("SELECT id, name, sent_at, created_at FROM $campaigns_table WHERE parent_id = %d ORDER BY created_at DESC", $campaign_id),
			ARRAY_A
		);
		if (!is_array($children_campaigns)) {
			$children_campaigns = array();
		}
		foreach ($children_campaigns as $child) {
			$all_ids[] = (int) $child['id'];
		}
	}
	$ids_sql = implode(',', array_map('intval', $all_ids));

	// Blacklist is de-duplicated in a derived table so the joins never multiply rows.
	$from_sql = "FROM $stats_table st
		LEFT JOIN $subscribers_table s ON s.id = st.subscriber_id
		LEFT JOIN (SELECT DISTINCT email FROM $blacklist_table) bl ON bl.email = s.email";

	// One aggregate query for all counters.
	$totals = $wpdb->get_row(
		"SELECT
			COUNT(*) AS total_rows,
			SUM(CASE WHEN st.sent_at IS NOT NULL THEN 1 ELSE 0 END) AS sent,
			SUM(CASE WHEN st.delivered_at IS NOT NULL THEN 1 ELSE 0 END) AS delivered,
			COUNT(DISTINCT CASE WHEN st.opened_at IS NOT NULL THEN st.subscriber_id END) AS opened,
			COUNT(DISTINCT CASE WHEN st.clicked_at IS NOT NULL THEN st.subscriber_id END) AS clicked,
			SUM(CASE WHEN st.bounced = 1 THEN 1 ELSE 0 END) AS bounced,
			COUNT(DISTINCT CASE WHEN bl.email IS NOT NULL THEN s.email END) AS blacklisted
		$from_sql
		WHERE st.campaign_id IN ($ids_sql)",
		ARRAY_A
	);
	if (!is_array($totals)) {
		$totals = array();
	}

	$total_rows        = (int) ($totals['total_rows'] ?? 0);
	$total_sent        = (int) ($totals['sent'] ?? 0);
	$total_delivered   = (int) ($totals['delivered'] ?? 0);
	$total_opened      = (int) ($totals['opened'] ?? 0);
	$total_clicked     = (int) ($totals['clicked'] ?? 0);
	$total_bounced     = (int) ($totals['bounced'] ?? 0);
	$total_blacklisted = (int) ($totals['blacklisted'] ?? 0);

	$open_rate       = $total_sent > 0 ? round(($total_opened / $total_sent) * 100, 1) : 0;
	$click_rate_sent = $total_sent > 0 ? round(($total_clicked / $total_sent) * 100, 1) : 0;
	$delivery_rate   = $total_sent > 0 ? round(($total_delivered / $total_sent) * 100, 1) : 0;
	$bounce_rate     = $total_sent > 0 ? round(($total_bounced / $total_sent) * 100, 1) : 0;

	// Recipient log: server-side filter, search and pagination (50 per page).
	$allowed_filters = array('all', 'delivered', 'opened', 'clicked', 'bounced', 'blacklisted');
	$log_filter      = isset($_GET['filter']) ? sanitize_key(wp_unslash($_GET['filter'])) : 'all';
	if (!in_array($log_filter, $allowed_filters, true)) {
		$log_filter = 'all';
	}
	$log_search   = isset($_GET['q']) ? sanitize_text_field(wp_unslash($_GET['q'])) : '';
	$log_per_page = 50;
	$log_page     = isset($_GET['paged']) ? max(1, absint($_GET['paged'])) : 1;
	$log_offset   = ($log_page - 1) * $log_per_page;

	$where  = array("st.campaign_id IN ($ids_sql)");
	$params = array();
	switch ($log_filter) {
		case 'delivered':
			$where[] = 'st.delivered_at IS NOT NULL';
			break;
		case 'opened':
			$where[] = 'st.opened_at IS NOT NULL';
			break;
		case 'clicked':
			$where[] = 'st.clicked_at IS NOT NULL';
			break;
		case 'bounced':
			$where[] = 'st.bounced = 1';
			break;
		case 'blacklisted':
			$where[] = 'bl.email IS NOT NULL';
			break;
	}
	if ('' !== $log_search) {
		$where[]  = 's.email LIKE %s';
		$params[] = '%' . $wpdb->esc_like($log_search) . '%';
	}
	$where_sql = implode(' AND ', $where);

	$count_sql = "SELECT COUNT(*) $from_sql WHERE $where_sql";
	$log_total = (int) (!empty($params) ? $wpdb->get_var($wpdb->prepare($count_sql, $params)) : $wpdb->get_var($count_sql));
	$log_pages = (int) ceil($log_total / $log_per_page);

	$logs_sql = "SELECT s.email, s.first_name, s.last_name, st.sent_at, st.delivered_at, st.opened_at, st.clicked_at, st.bounced,
			(bl.email IS NOT NULL) AS is_blacklisted
		$from_sql
		WHERE $where_sql
		ORDER BY st.bounced DESC, st.opened_at DESC, st.sent_at ASC
		LIMIT %d OFFSET %d";
	$logs = $wpdb->get_results($wpdb->prepare($logs_sql, array_merge($params, array($log_per_page, $log_offset))), ARRAY_A);
	if (!is_array($logs)) {
		$logs = array();
	}

	// URLs preserving the current filter/search.
	$stats_base = add_query_arg(array('page' => 'wp-news-campaigns', 'view' => 'stats', 'id' => $campaign_id), $admin_base);
	$filter_base = $stats_base;
	if ('' !== $log_search) {
		$filter_base = add_query_arg('q', rawurlencode($log_search), $filter_base);
	}
	$current_url = 'all' !== $log_filter ? add_query_arg('filter', $log_filter, $filter_base) : $filter_base;
	$log_page_links = paginate_links(array(
		'base'      => add_query_arg('paged', '%#%', $current_url),
		'format'    => '',
		'prev_text' => '&laquo;',
		'next_text' => '&raquo;',
		'total'     => $log_pages,
		'current'   => $log_page,
	));

	$filter_pills = array(
		'all'         => array(__('All', 'wp-news'), $total_rows),
		'delivered'   => array(__('Delivered', 'wp-news'), $total_delivered),
		'opened'      => array(__('Opened', 'wp-news'), $total_opened),
		'clicked'     => array(__('Clicked', 'wp-news'), $total_clicked),
		'bounced'     => array(__('Bounced', 'wp-news'), $total_bounced),
		'blacklisted' => array(__('Blacklisted', 'wp-news'), $total_blacklisted),
	);

	$clicked_links = WPNews_Campaign_Manager::get_clicked_links_stats($campaign_id);
	if (!is_array($clicked_links)) {
		$clicked_links = array();
	}

	$format_dt = static function ($value, $format = 'M d H:i') {
		if (empty($value)) {
			return '';
		}
		$ts = strtotime((string) $value);
		return $ts ? date_i18n($format, $ts) : '';
	};
	?>
	<div class="wpnews-admin-wrap">
		<div class="wpnews-header wpnews-header--flex">
			<h1><?php
				/* translators: %s: campaign name */
				printf(esc_html__('Campaign Stats: %s', 'wp-news'), esc_html((string) $campaign['name']));
			?></h1>
			<a href="<?php echo esc_url(add_query_arg(array('page' => 'wp-news-campaigns', 'type' => $is_parent ? 'auto' : 'regular'), $admin_base)); ?>"
				class="button wpnews-pill">&larr; <?php esc_html_e('Back to Campaigns', 'wp-news'); ?></a>
		</div>

		<!-- Metric Cards -->
		<div class="wpnews-stats-grid">
			<div class="wpnews-stats-card card-sent">
				<div class="stat-value"><?php echo esc_html(number_format_i18n($total_sent)); ?></div>
				<div class="stat-label"><?php esc_html_e('Total Sent', 'wp-news'); ?></div>
			</div>
			<div class="wpnews-stats-card card-delivered">
				<div class="stat-value"><?php echo esc_html(number_format_i18n($total_delivered)); ?></div>
				<div class="stat-label"><?php esc_html_e('Delivered', 'wp-news'); ?></div>
				<div class="stat-rate"><?php echo esc_html($delivery_rate); ?>%</div>
			</div>
			<div class="wpnews-stats-card card-opened">
				<div class="stat-value"><?php echo esc_html(number_format_i18n($total_opened)); ?></div>
				<div class="stat-label"><?php esc_html_e('Opened', 'wp-news'); ?></div>
				<div class="stat-rate"><?php echo esc_html($open_rate); ?>%</div>
			</div>
			<div class="wpnews-stats-card card-clicked">
				<div class="stat-value"><?php echo esc_html(number_format_i18n($total_clicked)); ?></div>
				<div class="stat-label"><?php esc_html_e('Clicked', 'wp-news'); ?></div>
				<div class="stat-rate"><?php echo esc_html($click_rate_sent); ?>%</div>
			</div>
			<div class="wpnews-stats-card card-bounced">
				<div class="stat-value"><?php echo esc_html(number_format_i18n($total_bounced)); ?></div>
				<div class="stat-label"><?php esc_html_e('Bounced', 'wp-news'); ?></div>
				<div class="stat-rate"><?php echo esc_html($bounce_rate); ?>%</div>
			</div>
			<div class="wpnews-stats-card card-blacklisted">
				<div class="stat-value"><?php echo esc_html(number_format_i18n($total_blacklisted)); ?></div>
				<div class="stat-label"><?php esc_html_e('Blacklisted', 'wp-news'); ?></div>
			</div>
		</div>

		<div class="wpnews-card wpnews-card--rounded">
			<?php if ($is_parent) : ?>
				<h3><?php esc_html_e('Auto-Sending History', 'wp-news'); ?></h3>
				<p class="wpnews-muted-text">
					<?php esc_html_e('This is a recurring template. Below are the individual sends (snapshots) and their specific performance.', 'wp-news'); ?>
				</p>
				<table class="wpnews-table wpnews-mb-30">
					<thead>
						<tr>
							<th><?php esc_html_e('Dispatch Date', 'wp-news'); ?></th>
							<th><?php esc_html_e('Campaign Name', 'wp-news'); ?></th>
							<th><?php esc_html_e('Actions', 'wp-news'); ?></th>
						</tr>
					</thead>
					<tbody>
						<?php if (!empty($children_campaigns)) : ?>
							<?php foreach ($children_campaigns as $child) : ?>
								<tr>
									<td><strong><?php echo esc_html($format_dt(!empty($child['sent_at']) ? $child['sent_at'] : $child['created_at'], 'M d, Y - H:i')); ?></strong></td>
									<td><?php echo esc_html((string) $child['name']); ?></td>
									<td>
										<a href="<?php echo esc_url(add_query_arg(array('page' => 'wp-news-campaigns', 'view' => 'stats', 'id' => (int) $child['id']), $admin_base)); ?>"
											class="button button-small button-secondary wpnews-pill"><?php esc_html_e('View Details', 'wp-news'); ?></a>
									</td>
								</tr>
							<?php endforeach; ?>
						<?php else : ?>
							<tr><td colspan="3"><?php esc_html_e('No sends have occurred yet.', 'wp-news'); ?></td></tr>
						<?php endif; ?>
					</tbody>
				</table>
			<?php endif; ?>

			<?php if (!empty($clicked_links)) : ?>
				<div class="wpnews-mb-30">
					<h3 class="wpnews-mb-12"><?php esc_html_e('Clicked Links Breakdown', 'wp-news'); ?></h3>
					<table class="wpnews-table">
						<thead>
							<tr>
								<th><?php esc_html_e('URL', 'wp-news'); ?></th>
								<th class="wpnews-col-center" style="width:150px;"><?php esc_html_e('Unique Clicks', 'wp-news'); ?></th>
							</tr>
						</thead>
						<tbody>
							<?php foreach ($clicked_links as $link) : ?>
								<tr>
									<td>
										<a href="<?php echo esc_url((string) ($link['url'] ?? '')); ?>" target="_blank" rel="noopener" class="wpnews-break-all">
											<?php echo esc_html((string) ($link['url'] ?? '')); ?>
										</a>
									</td>
									<td class="wpnews-col-center"><strong><?php echo (int) ($link['click_count'] ?? 0); ?></strong></td>
								</tr>
							<?php endforeach; ?>
						</tbody>
					</table>
				</div>
			<?php endif; ?>

			<?php if (!$is_parent || $total_rows > 0) : ?>
				<div class="wpnews-toolbar-row">
					<h3 class="wpnews-m-0"><?php esc_html_e('Subscriber Activity', 'wp-news'); ?></h3>
					<form method="get" action="<?php echo esc_url($admin_base); ?>" class="wpnews-search-emoji">
						<input type="hidden" name="page" value="wp-news-campaigns">
						<input type="hidden" name="view" value="stats">
						<input type="hidden" name="id" value="<?php echo esc_attr($campaign_id); ?>">
						<?php if ('all' !== $log_filter) : ?>
							<input type="hidden" name="filter" value="<?php echo esc_attr($log_filter); ?>">
						<?php endif; ?>
						<input type="search" name="q" value="<?php echo esc_attr($log_search); ?>" placeholder="<?php esc_attr_e('Search email address...', 'wp-news'); ?>">
					</form>
				</div>

				<?php if ($is_parent) : ?>
					<p class="wpnews-muted-text">
						<?php esc_html_e('Activity recorded on the template and all of its snapshots.', 'wp-news'); ?>
					</p>
				<?php endif; ?>

				<!-- Filter pills (server-side links) -->
				<div class="wpnews-pill-row">
					<?php foreach ($filter_pills as $key => $pill) : ?>
						<a href="<?php echo esc_url('all' === $key ? $filter_base : add_query_arg('filter', $key, $filter_base)); ?>"
							class="wpnews-bl-pill <?php echo $log_filter === $key ? 'active' : ''; ?>" data-f="<?php echo esc_attr($key); ?>">
							<?php echo esc_html($pill[0]); ?> (<?php echo esc_html(number_format_i18n($pill[1])); ?>)
						</a>
					<?php endforeach; ?>
				</div>

				<table class="wpnews-table" id="wpnews-subscriber-table">
					<thead>
						<tr>
							<th><?php esc_html_e('Subscriber', 'wp-news'); ?></th>
							<th><?php esc_html_e('Sent', 'wp-news'); ?></th>
							<th><?php esc_html_e('Delivered', 'wp-news'); ?></th>
							<th><?php esc_html_e('Opened', 'wp-news'); ?></th>
							<th><?php esc_html_e('Clicked', 'wp-news'); ?></th>
							<th><?php esc_html_e('Bounced', 'wp-news'); ?></th>
							<th><?php esc_html_e('Status', 'wp-news'); ?></th>
							<th><?php esc_html_e('Actions', 'wp-news'); ?></th>
						</tr>
					</thead>
					<tbody>
						<?php if (!empty($logs)) : ?>
							<?php foreach ($logs as $log) :
								$is_bounced = !empty($log['bounced']);
								$is_bl      = !empty($log['is_blacklisted']);
								$email      = (string) ($log['email'] ?? '');
								$status       = __('Sent', 'wp-news');
								$status_class = 'sent';
								if ($is_bl) {
									$status       = __('Blacklisted', 'wp-news');
									$status_class = 'blacklisted';
								} elseif ($is_bounced) {
									$status       = __('Bounced', 'wp-news');
									$status_class = 'bounced';
								} elseif (!empty($log['clicked_at'])) {
									$status       = __('Clicked', 'wp-news');
									$status_class = 'clicked';
								} elseif (!empty($log['opened_at'])) {
									$status       = __('Opened', 'wp-news');
									$status_class = 'opened';
								} elseif (!empty($log['delivered_at'])) {
									$status       = __('Delivered', 'wp-news');
									$status_class = 'delivered';
								}
								?>
								<tr data-status="<?php echo esc_attr($status_class); ?>">
									<td>
										<strong><?php echo esc_html($email); ?></strong><br>
										<span class="wpnews-small-muted"><?php echo esc_html(trim((string) ($log['first_name'] ?? '') . ' ' . (string) ($log['last_name'] ?? ''))); ?></span>
									</td>
									<td><?php echo $format_dt($log['sent_at'] ?? null) !== '' ? esc_html($format_dt($log['sent_at'])) : '-'; ?></td>
									<td><?php echo $format_dt($log['delivered_at'] ?? null) !== '' ? esc_html($format_dt($log['delivered_at'])) : '-'; ?></td>
									<td><?php echo $format_dt($log['opened_at'] ?? null) !== '' ? esc_html($format_dt($log['opened_at'])) : '-'; ?></td>
									<td><?php echo $format_dt($log['clicked_at'] ?? null) !== '' ? esc_html($format_dt($log['clicked_at'])) : '-'; ?></td>
									<td>
										<?php if ($is_bounced) : ?>
											<span class="wpnews-text-bounced"><?php esc_html_e('Yes', 'wp-news'); ?></span>
										<?php else : ?>
											<span class="wpnews-dash">—</span>
										<?php endif; ?>
									</td>
									<td><span class="wpnews-badge <?php echo esc_attr($status_class); ?>"><?php echo esc_html($status); ?></span></td>
									<td>
										<?php if (!$is_bl && '' !== $email) : ?>
											<button type="button" class="button button-small wpnews-pill wpnews-btn-red-outline wpnews-stats-blacklist-btn" data-email="<?php echo esc_attr($email); ?>">
												<?php esc_html_e('Blacklist', 'wp-news'); ?>
											</button>
										<?php endif; ?>
									</td>
								</tr>
							<?php endforeach; ?>
						<?php else : ?>
							<tr>
								<td colspan="8" class="wpnews-empty">
									<?php esc_html_e('No activity matches the current filter.', 'wp-news'); ?>
								</td>
							</tr>
						<?php endif; ?>
					</tbody>
				</table>

				<?php if ($log_pages > 1) : ?>
					<div class="wpnews-tablenav">
						<span class="wpnews-muted-text"><?php
							/* translators: 1: current page, 2: total pages */
							printf(esc_html__('Page %1$d of %2$d', 'wp-news'), (int) $log_page, (int) $log_pages);
						?></span>
						<div class="tablenav-pages">
							<?php if ($log_page_links) : ?>
								<span class="pagination-links"><?php echo wp_kses_post($log_page_links); ?></span>
							<?php endif; ?>
						</div>
					</div>
				<?php endif; ?>
			<?php endif; ?>
		</div>
	</div>
	<?php
	return;
}

// ==========================================
// VIEW: LIST (Default)
// ==========================================

global $wpdb;

$campaigns_type = isset($_GET['type']) && 'auto' === $_GET['type'] ? 'auto' : 'regular';
$per_page       = 20;
$paged          = isset($_GET['paged']) ? max(1, absint($_GET['paged'])) : 1;
$offset         = ($paged - 1) * $per_page;

if (method_exists('WPNews_Campaign_Manager', 'count_campaigns')) {
	$total_campaigns = (int) WPNews_Campaign_Manager::count_campaigns(null, $campaigns_type);
} else {
	$campaigns_table = $wpdb->prefix . 'wpnews_campaigns';
	$type_clause     = 'auto' === $campaigns_type ? 'is_recurring = 1' : 'is_recurring = 0';
	$total_campaigns = (int) $wpdb->get_var("SELECT COUNT(*) FROM $campaigns_table WHERE $type_clause AND (parent_id IS NULL OR parent_id = 0)");
}
$total_pages = (int) ceil($total_campaigns / $per_page);

$campaigns = WPNews_Campaign_Manager::get_campaigns(null, $campaigns_type, array(
	'limit'  => $per_page,
	'offset' => $offset,
	'light'  => true,
));
if (!is_array($campaigns)) {
	$campaigns = array();
}
// Safety net if the model ignores the $args pagination.
if (count($campaigns) > $per_page) {
	$campaigns = array_slice($campaigns, $offset, $per_page);
}

$campaign_ids   = wp_list_pluck($campaigns, 'id');
$stats_summary  = WPNews_Campaign_Manager::get_campaign_stats_summary($campaign_ids);
$detailed_stats = WPNews_Campaign_Manager::get_campaign_detailed_stats($campaign_ids);
if (!is_array($stats_summary)) {
	$stats_summary = array();
}
if (!is_array($detailed_stats)) {
	$detailed_stats = array();
}

$list_base  = add_query_arg(array('page' => 'wp-news-campaigns', 'type' => $campaigns_type), $admin_base);
$page_links = paginate_links(array(
	'base'      => add_query_arg('paged', '%#%', $list_base),
	'format'    => '',
	'prev_text' => '&laquo;',
	'next_text' => '&raquo;',
	'total'     => $total_pages,
	'current'   => $paged,
));

$format_date = static function ($value) {
	if (empty($value)) {
		return '';
	}
	$ts = strtotime((string) $value);
	return $ts ? date_i18n('M d, Y', $ts) : '';
};
$format_datetime = static function ($value) {
	if (empty($value)) {
		return '';
	}
	$ts = strtotime((string) $value);
	return $ts ? date_i18n(get_option('date_format') . ' ' . get_option('time_format'), $ts) : '';
};
?>
<div class="wpnews-admin-wrap">
	<div class="wpnews-header wpnews-header--flex">
		<h1><?php esc_html_e('Campaigns', 'wp-news'); ?></h1>
		<?php if ('auto' === $campaigns_type) : ?>
			<a href="<?php echo esc_url(admin_url('admin.php?page=wp-news-create-campaign&is_recurring=1')); ?>"
				class="button button-primary wpnews-pill wpnews-pill--lg"><?php esc_html_e('Create Auto-Sending Campaign', 'wp-news'); ?></a>
		<?php else : ?>
			<span>
				<button type="button" id="wpnews-import-mailpoet-campaigns" class="button wpnews-pill wpnews-pill--lg"><?php esc_html_e('Import from MailPoet', 'wp-news'); ?></button>
				<a href="<?php echo esc_url(admin_url('admin.php?page=wp-news-create-campaign')); ?>"
					class="button button-primary wpnews-pill wpnews-pill--lg"><?php esc_html_e('Create New Campaign', 'wp-news'); ?></a>
			</span>
		<?php endif; ?>
	</div>

	<h2 class="nav-tab-wrapper wpnews-mb-20">
		<a href="<?php echo esc_url(add_query_arg(array('page' => 'wp-news-campaigns', 'type' => 'regular'), $admin_base)); ?>"
			class="nav-tab <?php echo 'regular' === $campaigns_type ? 'nav-tab-active' : ''; ?>">
			<?php esc_html_e('Regular Campaigns', 'wp-news'); ?>
		</a>
		<a href="<?php echo esc_url(add_query_arg(array('page' => 'wp-news-campaigns', 'type' => 'auto'), $admin_base)); ?>"
			class="nav-tab <?php echo 'auto' === $campaigns_type ? 'nav-tab-active' : ''; ?>">
			<?php esc_html_e('Auto-Sending Campaigns', 'wp-news'); ?>
		</a>
	</h2>

	<div class="wpnews-card wpnews-card--rounded">
		<div class="wpnews-toolbar-row">
			<p class="wpnews-muted-text wpnews-m-0">
				<?php
				/* translators: %s: number of campaigns */
				printf(esc_html__('%s campaigns', 'wp-news'), '<strong>' . esc_html(number_format_i18n($total_campaigns)) . '</strong>');
				?>
			</p>
			<div class="wpnews-search-emoji wpnews-search-emoji--sm">
				<input type="search" id="wpnews-campaign-search" placeholder="<?php esc_attr_e('Search campaigns on this page...', 'wp-news'); ?>">
			</div>
		</div>

		<!-- Bulk Delete Form -->
		<form id="wpnews-bulk-delete-form" method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
			<?php wp_nonce_field('wpnews_bulk_delete_campaigns'); ?>
			<input type="hidden" name="action" value="wpnews_bulk_delete_campaigns">
			<input type="hidden" name="type" value="<?php echo esc_attr($campaigns_type); ?>">

			<?php if (!empty($campaigns)) : ?>
				<table class="wpnews-table" id="wpnews-campaigns-table">
					<thead>
						<tr>
							<th class="wpnews-col-center" style="width:30px;"><input type="checkbox" id="wpnews-select-all" title="<?php esc_attr_e('Select All', 'wp-news'); ?>"></th>
							<th><?php esc_html_e('Name', 'wp-news'); ?></th>
							<th style="width:100px;"><?php esc_html_e('Status', 'wp-news'); ?></th>
							<th class="wpnews-col-center" style="width:80px;"><?php esc_html_e('Delivered', 'wp-news'); ?></th>
							<th class="wpnews-col-center" style="width:80px;"><?php esc_html_e('Opened', 'wp-news'); ?></th>
							<th class="wpnews-col-center" style="width:80px;"><?php esc_html_e('Clicked', 'wp-news'); ?></th>
							<th class="wpnews-col-center" style="width:80px;"><?php esc_html_e('Bounced', 'wp-news'); ?></th>
							<th style="width:100px;"><?php esc_html_e('Created', 'wp-news'); ?></th>
							<th style="width:100px;"><?php esc_html_e('Sent', 'wp-news'); ?></th>
							<th style="width:220px;"><?php esc_html_e('Actions', 'wp-news'); ?></th>
						</tr>
					</thead>
					<tbody>
						<?php foreach ($campaigns as $campaign) :
							$cid    = (int) ($campaign['id'] ?? 0);
							$status = (string) ($campaign['status'] ?? 'draft');
							$total  = (int) ($campaign['total_recipients'] ?? 0);
							$sent   = (int) ($campaign['sent_count'] ?? 0);
							if (0 === $sent && isset($stats_summary[$cid])) {
								$sent = (int) $stats_summary[$cid];
							}
							$percent = $total > 0 ? min(100, (int) round(($sent / $total) * 100)) : 0;
							if ('sent' === $status && 0 === $total && $sent > 0) {
								$percent = 100;
								$total   = $sent;
							}

							$ds = isset($detailed_stats[$cid]) && is_array($detailed_stats[$cid]) ? $detailed_stats[$cid] : array();
							$delivered = (int) ($ds['delivered'] ?? 0);
							$opened    = (int) ($ds['opened'] ?? 0);
							$clicked   = (int) ($ds['clicked'] ?? 0);
							$bounced   = (int) ($ds['bounced'] ?? 0);

							$is_editable  = in_array($status, array('draft', 'saved', 'stopped'), true);
							$is_recurring = !empty($campaign['is_recurring']);
							$has_progress = in_array($status, array('sending', 'sent', 'stopped'), true);
							?>
							<tr data-name="<?php echo esc_attr(mb_strtolower((string) ($campaign['name'] ?? ''))); ?>"<?php echo 'sending' === $status ? ' data-sending-id="' . esc_attr($cid) . '"' : ''; ?>>
								<td class="wpnews-col-center">
									<?php if ($is_editable) : ?>
										<input type="checkbox" class="wpnews-campaign-cb" name="campaign_ids[]" value="<?php echo esc_attr($cid); ?>">
									<?php endif; ?>
								</td>
								<td>
									<strong><?php echo esc_html((string) ($campaign['name'] ?? '')); ?></strong>
									<br><span class="wpnews-small-muted"><?php echo esc_html(mb_strimwidth((string) ($campaign['subject'] ?? ''), 0, 60, '...')); ?></span>
								</td>
								<td>
									<span class="wpnews-badge <?php echo esc_attr($status); ?>"><?php echo esc_html(ucfirst($status)); ?></span>
									<?php if ('scheduled' === $status && !empty($campaign['schedule_at'])) : ?>
										<div class="wpnews-small-muted" title="<?php esc_attr_e('Site local time', 'wp-news'); ?>">
											<?php
											/* translators: %s: scheduled date and time in the site timezone */
											printf(esc_html__('Scheduled for %s', 'wp-news'), esc_html($format_datetime($campaign['schedule_at'])));
											?>
										</div>
									<?php endif; ?>
									<?php if ($has_progress) : ?>
										<div class="wpnews-progress">
											<div class="wpnews-progress-bar">
												<div class="wpnews-progress-fill" style="width:<?php echo (int) $percent; ?>%;"></div>
											</div>
											<div class="wpnews-progress-text">
												<span><?php echo esc_html(number_format_i18n($sent)); ?> / <?php echo esc_html(number_format_i18n($total)); ?></span><span><?php echo (int) $percent; ?>%</span>
											</div>
										</div>
									<?php endif; ?>
								</td>
								<td class="wpnews-col-center">
									<?php if ($delivered > 0) : ?><span class="wpnews-num wpnews-num--delivered"><?php echo esc_html(number_format_i18n($delivered)); ?></span><?php else : ?><span class="wpnews-dash">—</span><?php endif; ?>
								</td>
								<td class="wpnews-col-center">
									<?php if ($opened > 0) : ?><span class="wpnews-num wpnews-num--opened"><?php echo esc_html(number_format_i18n($opened)); ?></span><?php else : ?><span class="wpnews-dash">—</span><?php endif; ?>
								</td>
								<td class="wpnews-col-center">
									<?php if ($clicked > 0) : ?><span class="wpnews-num wpnews-num--clicked"><?php echo esc_html(number_format_i18n($clicked)); ?></span><?php else : ?><span class="wpnews-dash">—</span><?php endif; ?>
								</td>
								<td class="wpnews-col-center">
									<?php if ($bounced > 0) : ?><span class="wpnews-num wpnews-num--bounced"><?php echo esc_html(number_format_i18n($bounced)); ?></span><?php else : ?><span class="wpnews-dash">—</span><?php endif; ?>
								</td>
								<td class="wpnews-cell-date"><?php echo esc_html($format_date($campaign['created_at'] ?? null)); ?></td>
								<td class="wpnews-cell-date">
									<?php if (!empty($campaign['sent_at'])) : ?>
										<?php echo esc_html($format_date($campaign['sent_at'])); ?>
									<?php else : ?>
										<span class="wpnews-dash">—</span>
									<?php endif; ?>
								</td>
								<td>
									<div class="wpnews-actions-row">
										<?php if ($is_editable) : ?>
											<a href="<?php echo esc_url(add_query_arg(array('page' => 'wp-news-create-campaign', 'id' => $cid), $admin_base)); ?>"
												class="button button-small wpnews-pill wpnews-pill--sm"><?php esc_html_e('Edit', 'wp-news'); ?></a>
										<?php endif; ?>
										<?php if ('sending' === $status || 'sent' === $status) : ?>
											<a href="<?php echo esc_url(add_query_arg(array('page' => 'wp-news-create-campaign', 'id' => $cid, 'preview' => '1'), $admin_base)); ?>"
												class="button button-small wpnews-pill wpnews-pill--sm"><?php esc_html_e('Preview', 'wp-news'); ?></a>
										<?php endif; ?>
										<a href="<?php echo esc_url(wp_nonce_url(add_query_arg(array('action' => 'wpnews_duplicate_campaign', 'id' => $cid), admin_url('admin-post.php')), 'wpnews_duplicate_campaign_' . $cid)); ?>"
											class="button button-small button-secondary wpnews-pill wpnews-pill--sm"><?php esc_html_e('Duplicate', 'wp-news'); ?></a>
										<?php if ($is_editable) : ?>
											<a href="<?php echo esc_url(wp_nonce_url(add_query_arg(array('action' => 'wpnews_delete_campaign', 'id' => $cid, 'type' => $campaigns_type), admin_url('admin-post.php')), 'wpnews_delete_campaign_' . $cid)); ?>"
												class="button button-small wpnews-pill wpnews-pill--sm wpnews-btn-red-outline"
												data-wpnews-confirm="<?php esc_attr_e('Are you sure you want to delete this campaign?', 'wp-news'); ?>"><?php esc_html_e('Delete', 'wp-news'); ?></a>
										<?php endif; ?>
										<?php if ('sending' === $status || 'sent' === $status || $is_recurring) : ?>
											<a href="<?php echo esc_url(add_query_arg(array('page' => 'wp-news-campaigns', 'view' => 'stats', 'id' => $cid), $admin_base)); ?>"
												class="button button-small wpnews-pill wpnews-pill--sm wpnews-btn-dark"><?php esc_html_e('Stats', 'wp-news'); ?></a>
										<?php endif; ?>
										<?php if ('sending' === $status) : ?>
											<button type="button" class="button button-small wpnews-pill wpnews-pill--sm wpnews-btn-red-outline wpnews-stop-btn" data-campaign-id="<?php echo esc_attr($cid); ?>">
												<?php esc_html_e('Stop', 'wp-news'); ?>
											</button>
										<?php endif; ?>
										<?php if ('stopped' === $status) : ?>
											<button type="button" class="button button-small wpnews-pill wpnews-pill--sm wpnews-btn-green-outline wpnews-resume-btn" data-campaign-id="<?php echo esc_attr($cid); ?>">
												<?php esc_html_e('Resume', 'wp-news'); ?>
											</button>
										<?php endif; ?>
									</div>
								</td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>

				<?php if ($total_pages > 1) : ?>
					<div class="wpnews-tablenav">
						<span class="wpnews-muted-text"><?php
							/* translators: 1: current page, 2: total pages */
							printf(esc_html__('Page %1$d of %2$d', 'wp-news'), (int) $paged, (int) $total_pages);
						?></span>
						<div class="tablenav-pages">
							<?php if ($page_links) : ?>
								<span class="pagination-links"><?php echo wp_kses_post($page_links); ?></span>
							<?php endif; ?>
						</div>
					</div>
				<?php endif; ?>
			<?php else : ?>
				<p class="wpnews-empty"><?php esc_html_e('No campaigns yet.', 'wp-news'); ?></p>
			<?php endif; ?>

			<!-- Bulk Action Bar (inside form so checkboxes are included) -->
			<div id="wpnews-bulk-bar" class="wpnews-bulk-float" style="display:none;">
				<span id="wpnews-bulk-count"></span>
				<button type="button" id="wpnews-bulk-delete-btn" class="wpnews-bulk-float__delete">
					<?php esc_html_e('Delete Selected', 'wp-news'); ?>
				</button>
				<button type="button" id="wpnews-bulk-cancel-btn" class="wpnews-bulk-float__cancel">
					<?php esc_html_e('Cancel', 'wp-news'); ?>
				</button>
			</div>
		</form>

		<!-- Confirm Modal -->
		<div id="wpnews-confirm-modal" class="wpnews-modal" style="display:none;">
			<div class="wpnews-modal__box">
				<h3><?php esc_html_e('Delete Campaigns', 'wp-news'); ?></h3>
				<p id="wpnews-confirm-msg"></p>
				<div class="wpnews-modal__actions">
					<button type="button" id="wpnews-confirm-no" class="wpnews-modal__cancel"><?php esc_html_e('Cancel', 'wp-news'); ?></button>
					<button type="button" id="wpnews-confirm-yes" class="wpnews-modal__confirm"><?php esc_html_e('Yes, Delete', 'wp-news'); ?></button>
				</div>
			</div>
		</div>
	</div>
</div>
