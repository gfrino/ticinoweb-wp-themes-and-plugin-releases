<?php
/**
 * Campaign management functionality.
 *
 * @package WPNews
 */

/**
 * Campaign Manager class.
 */
class WPNews_Campaign_Manager
{

	/**
	 * Lock TTL in seconds: a lock older than this is considered stale.
	 */
	const LOCK_TTL = 300;

	/**
	 * Hard upper bound (seconds) for a single sending batch.
	 */
	const MAX_BATCH_SECONDS = 90;

	/**
	 * Seconds to wait before retrying a batch interrupted by a transport error
	 * (DNS/connection failures, HTTP 429/5xx from the provider).
	 */
	const TRANSPORT_RETRY_DELAY = 60;

	/**
	 * Number of pending recipients fetched per query inside a batch.
	 */
	const FETCH_CHUNK = 100;

	/**
	 * Number of consecutive batches with zero successful sends after which a
	 * campaign is stopped (protects against infinite retries).
	 */
	const MAX_FAILED_BATCHES = 3;

	/**
	 * Allowed campaign statuses.
	 *
	 * @var string[]
	 */
	private static $statuses = array('draft', 'scheduled', 'sending', 'stopped', 'sent');

	/* ---------------------------------------------------------------------
	 * Sanitization
	 * ------------------------------------------------------------------ */

	/**
	 * Sanitize email HTML content.
	 *
	 * Like wp_kses_post() but additionally allows the structural tags an HTML
	 * email needs (<!DOCTYPE html>, html, head, meta, title, body, center, style)
	 * and the presentational table attributes email clients rely on.
	 * The `data:` protocol is allowed only for this call (inline images).
	 *
	 * @param string $content Raw email HTML.
	 * @return string Sanitized HTML.
	 */
	public static function sanitize_email_html($content)
	{
		$content = (string) $content;
		$has_doctype = (bool) preg_match('/^\s*<!DOCTYPE\s+html[^>]*>/i', $content);

		$allowed = wp_kses_allowed_html('post');

		$allowed['style'] = array('type' => true, 'media' => true);
		$allowed['html'] = array('lang' => true, 'dir' => true, 'xmlns' => true, 'xmlns:v' => true, 'xmlns:o' => true);
		$allowed['head'] = array();
		$allowed['meta'] = array('charset' => true, 'name' => true, 'content' => true, 'http-equiv' => true);
		$allowed['title'] = array();
		$allowed['body'] = array(
			'style' => true, 'class' => true, 'bgcolor' => true, 'width' => true,
			'leftmargin' => true, 'topmargin' => true, 'marginwidth' => true, 'marginheight' => true,
		);
		$allowed['center'] = array('style' => true, 'class' => true);

		$table_attrs = array(
			'width' => true, 'height' => true, 'align' => true, 'valign' => true, 'bgcolor' => true,
			'cellpadding' => true, 'cellspacing' => true, 'border' => true, 'role' => true,
			'style' => true, 'class' => true, 'id' => true, 'colspan' => true, 'rowspan' => true,
			'dir' => true, 'lang' => true, 'background' => true,
		);
		foreach (array('table', 'thead', 'tbody', 'tfoot', 'tr', 'td', 'th') as $tag) {
			$allowed[$tag] = array_merge(isset($allowed[$tag]) ? $allowed[$tag] : array(), $table_attrs);
		}

		$allowed['img'] = array_merge(isset($allowed['img']) ? $allowed['img'] : array(), array(
			'width' => true, 'height' => true, 'border' => true, 'align' => true, 'hspace' => true, 'vspace' => true, 'style' => true,
		));
		$allowed['a'] = array_merge(isset($allowed['a']) ? $allowed['a'] : array(), array(
			'style' => true, 'target' => true, 'title' => true, 'class' => true,
		));

		$protocols = array_merge(wp_allowed_protocols(), array('data'));
		$clean = wp_kses($content, $allowed, $protocols);

		if ($has_doctype) {
			$clean = "<!DOCTYPE html>\n" . ltrim($clean);
		}

		return $clean;
	}

	/**
	 * Sanitize the builder blocks JSON server-side.
	 *
	 * Recursively, for every string value:
	 *  - keys matching /color/i     -> sanitize_hex_color() ('transparent' allowed, '' if invalid)
	 *  - keys matching /url|href|src|link/i -> esc_url_raw() ({{placeholders}} and data:image/* allowed)
	 *  - any other string           -> wp_kses_post()
	 * Numbers, booleans and null pass through untouched.
	 *
	 * @param string|array $json Raw JSON string (or already-decoded array).
	 * @return string Sanitized JSON string, '' when empty or invalid.
	 */
	public static function sanitize_blocks_json($json)
	{
		if (is_array($json)) {
			$decoded = $json;
		} else {
			if (!is_string($json) || '' === trim($json)) {
				return '';
			}
			$decoded = json_decode($json, true);
			if (JSON_ERROR_NONE !== json_last_error() || !is_array($decoded)) {
				return '';
			}
		}

		$clean = self::sanitize_blocks_value($decoded, '');
		$encoded = wp_json_encode($clean, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

		return is_string($encoded) ? $encoded : '';
	}

	/**
	 * Recursive worker for sanitize_blocks_json().
	 *
	 * @param mixed  $value Value to sanitize.
	 * @param string $key   Closest string key (numeric keys inherit the parent key).
	 * @return mixed
	 */
	private static function sanitize_blocks_value($value, $key)
	{
		if (is_array($value)) {
			$out = array();
			foreach ($value as $k => $v) {
				$out[$k] = self::sanitize_blocks_value($v, is_string($k) ? $k : $key);
			}
			return $out;
		}

		if (!is_string($value)) {
			return $value; // int, float, bool, null
		}

		if ('' !== $key && preg_match('/color/i', $key)) {
			$v = trim($value);
			if ('' === $v) {
				return '';
			}
			if ('transparent' === strtolower($v)) {
				return 'transparent';
			}
			$hex = sanitize_hex_color($v);
			return $hex ? $hex : '';
		}

		if ('' !== $key && preg_match('/url|href|src|link/i', $key)) {
			$v = trim($value);
			if ('' === $v) {
				return '';
			}
			if (preg_match('/^\{\{[a-z0-9_]+\}\}$/i', $v)) {
				return $v;
			}
			if (preg_match('#^data:image/(png|jpe?g|gif|webp);base64,[A-Za-z0-9+/=]+$#', $v)) {
				return $v;
			}
			return esc_url_raw($v);
		}

		return wp_kses_post($value);
	}

	/**
	 * Normalise a status value against the allowed list.
	 *
	 * @param mixed $status
	 * @return string|null
	 */
	private static function sanitize_status($status)
	{
		$status = sanitize_key((string) $status);
		return in_array($status, self::$statuses, true) ? $status : null;
	}

	/* ---------------------------------------------------------------------
	 * CRUD
	 * ------------------------------------------------------------------ */

	/**
	 * Create a new campaign.
	 *
	 * @param array $data Campaign data.
	 * @return int|false Campaign ID on success, false on failure.
	 */
	public static function create_campaign($data)
	{
		global $wpdb;

		$table = $wpdb->prefix . 'wpnews_campaigns';

		$campaign_data = array(
			'name' => WPNews_Security::sanitize_text(isset($data['name']) ? $data['name'] : ''),
			'subject' => WPNews_Security::sanitize_text(isset($data['subject']) ? $data['subject'] : ''),
			'content' => isset($data['content']) ? self::sanitize_email_html($data['content']) : '',
			'status' => 'draft',
		);

		if (isset($data['blocks_json'])) {
			$campaign_data['blocks_json'] = self::sanitize_blocks_json($data['blocks_json']);
		}

		if (!empty($data['schedule_at'])) {
			$campaign_data['schedule_at'] = WPNews_Security::sanitize_text($data['schedule_at']);
			$campaign_data['status'] = 'scheduled';
		}

		if (isset($data['is_recurring'])) {
			$campaign_data['is_recurring'] = intval($data['is_recurring']);
		}

		if (!empty($data['recurring_interval'])) {
			$campaign_data['recurring_interval'] = sanitize_text_field($data['recurring_interval']);
		}

		if (!empty($data['recurring_day'])) {
			$campaign_data['recurring_day'] = sanitize_text_field($data['recurring_day']);
		}

		if (isset($data['send_if_new'])) {
			$campaign_data['send_if_new'] = intval($data['send_if_new']);
		}

		$result = $wpdb->insert($table, $campaign_data);

		if (false === $result) {
			return false;
		}

		$campaign_id = (int) $wpdb->insert_id;

		if (isset($data['lists']) && is_array($data['lists'])) {
			self::set_campaign_lists($campaign_id, $data['lists']);
		}

		return $campaign_id;
	}

	/**
	 * Update an existing campaign.
	 *
	 * @param int   $campaign_id Campaign ID.
	 * @param array $data        Campaign data.
	 * @return bool True on success, false on failure (including "already sent").
	 */
	public static function update_campaign($campaign_id, $data)
	{
		global $wpdb;

		$table = $wpdb->prefix . 'wpnews_campaigns';
		$campaign_id = (int) $campaign_id;

		// Prevent editing if the campaign is already sent
		$current_campaign = self::get_campaign($campaign_id);
		if (!$current_campaign || 'sent' === $current_campaign['status']) {
			return false;
		}

		$campaign_data = array();

		if (isset($data['name'])) {
			$campaign_data['name'] = WPNews_Security::sanitize_text($data['name']);
		}
		if (isset($data['subject'])) {
			$campaign_data['subject'] = WPNews_Security::sanitize_text($data['subject']);
		}
		if (isset($data['content'])) {
			$campaign_data['content'] = self::sanitize_email_html($data['content']);
		}
		if (isset($data['blocks_json'])) {
			$campaign_data['blocks_json'] = self::sanitize_blocks_json($data['blocks_json']);
		}
		if (isset($data['status'])) {
			$status = self::sanitize_status($data['status']);
			if (null !== $status) {
				$campaign_data['status'] = $status;
			}
		}
		if (isset($data['is_recurring'])) {
			$campaign_data['is_recurring'] = intval($data['is_recurring']);
		}
		if (isset($data['recurring_interval'])) {
			$campaign_data['recurring_interval'] = sanitize_text_field($data['recurring_interval']);
		}
		if (isset($data['recurring_day'])) {
			$campaign_data['recurring_day'] = sanitize_text_field($data['recurring_day']);
		}
		if (isset($data['send_if_new'])) {
			$campaign_data['send_if_new'] = intval($data['send_if_new']);
		}
		if (isset($data['schedule_at'])) {
			$campaign_data['schedule_at'] = empty($data['schedule_at']) ? null : WPNews_Security::sanitize_text($data['schedule_at']);
		}

		if (empty($campaign_data) && !isset($data['lists'])) {
			return false;
		}

		$result = true;
		if (!empty($campaign_data)) {
			$result = $wpdb->update($table, $campaign_data, array('id' => $campaign_id));
		}

		// Update lists if provided
		if (isset($data['lists']) && is_array($data['lists'])) {
			self::set_campaign_lists($campaign_id, $data['lists']);
		}

		return false !== $result;
	}

	/**
	 * Get a campaign by ID.
	 *
	 * @param int $campaign_id Campaign ID.
	 * @return array|false Campaign data or false if not found.
	 */
	public static function get_campaign($campaign_id)
	{
		global $wpdb;

		$table = $wpdb->prefix . 'wpnews_campaigns';

		$campaign = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE id = %d", (int) $campaign_id), ARRAY_A);

		if ($campaign) {
			$campaign['lists'] = self::get_campaign_lists($campaign_id);
			return $campaign;
		}

		return false;
	}

	/**
	 * Get lists assigned to a campaign.
	 *
	 * @param int $campaign_id
	 * @return array List IDs
	 */
	public static function get_campaign_lists($campaign_id)
	{
		global $wpdb;
		$table = $wpdb->prefix . 'wpnews_campaign_lists';
		$results = $wpdb->get_results($wpdb->prepare("SELECT list_id FROM $table WHERE campaign_id = %d", (int) $campaign_id), ARRAY_A);
		return array_map('intval', wp_list_pluck((array) $results, 'list_id'));
	}

	/**
	 * Set lists for a campaign.
	 *
	 * @param int   $campaign_id Campaign ID.
	 * @param array $list_ids    Array of List IDs.
	 */
	public static function set_campaign_lists($campaign_id, $list_ids)
	{
		global $wpdb;
		$table = $wpdb->prefix . 'wpnews_campaign_lists';
		$campaign_id = (int) $campaign_id;

		$wpdb->delete($table, array('campaign_id' => $campaign_id), array('%d'));

		$list_ids = array_unique(array_filter(array_map('intval', (array) $list_ids)));
		if (empty($list_ids)) {
			return;
		}

		$values = array();
		foreach ($list_ids as $list_id) {
			$values[] = $wpdb->prepare('(%d, %d)', $campaign_id, $list_id);
		}
		$wpdb->query("INSERT INTO $table (campaign_id, list_id) VALUES " . implode(',', $values));
	}

	/**
	 * Get campaigns.
	 *
	 * @param string|null $status Campaign status filter.
	 * @param string      $type   'regular' (default) or 'auto' (recurring templates).
	 * @param array       $args   {
	 *     @type int  $limit  Max rows (0 = no limit).
	 *     @type int  $offset Offset (used with limit).
	 *     @type bool $light  When true, `content` and `blocks_json` are excluded from the SELECT.
	 * }
	 * @return array Array of campaigns.
	 */
	public static function get_campaigns($status = null, $type = 'regular', $args = array())
	{
		global $wpdb;

		$table = $wpdb->prefix . 'wpnews_campaigns';
		$args = wp_parse_args((array) $args, array(
			'limit' => 0,
			'offset' => 0,
			'light' => false,
		));

		$columns = '*';
		if (!empty($args['light'])) {
			$columns = 'id, parent_id, name, subject, status, schedule_at, is_recurring, recurring_interval, recurring_day, send_if_new, total_recipients, sent_count, sent_at, created_at, updated_at';
		}

		$where = array();
		$params = array();

		$where[] = ($type === 'auto') ? 'is_recurring = 1' : 'is_recurring = 0';
		$where[] = '(parent_id IS NULL OR parent_id = 0)';

		if ($status) {
			$where[] = 'status = %s';
			$params[] = $status;
		}

		$sql = "SELECT $columns FROM $table WHERE " . implode(' AND ', $where) . ' ORDER BY created_at DESC';

		$limit = (int) $args['limit'];
		if ($limit > 0) {
			$sql .= ' LIMIT %d OFFSET %d';
			$params[] = $limit;
			$params[] = max(0, (int) $args['offset']);
		}

		if (!empty($params)) {
			$sql = $wpdb->prepare($sql, $params);
		}

		$campaigns = $wpdb->get_results($sql, ARRAY_A);

		return is_array($campaigns) ? $campaigns : array();
	}

	/**
	 * Count top-level campaigns matching the same filters as get_campaigns().
	 *
	 * @param string|null $status
	 * @param string      $type 'regular' or 'auto'
	 * @return int
	 */
	public static function count_campaigns($status = null, $type = 'regular')
	{
		global $wpdb;

		$table = $wpdb->prefix . 'wpnews_campaigns';
		$where = array(($type === 'auto') ? 'is_recurring = 1' : 'is_recurring = 0', '(parent_id IS NULL OR parent_id = 0)');
		$params = array();
		if ($status) {
			$where[] = 'status = %s';
			$params[] = $status;
		}
		$sql = "SELECT COUNT(*) FROM $table WHERE " . implode(' AND ', $where);
		if (!empty($params)) {
			$sql = $wpdb->prepare($sql, $params);
		}

		return (int) $wpdb->get_var($sql);
	}

	/**
	 * Get stats summary (sent count) for a list of campaigns.
	 *
	 * @param array $campaign_ids
	 * @return array campaign_id => sent_count
	 */
	public static function get_campaign_stats_summary($campaign_ids)
	{
		$campaign_ids = array_filter(array_map('intval', (array) $campaign_ids));
		if (empty($campaign_ids)) {
			return array();
		}

		global $wpdb;
		$stats_table = $wpdb->prefix . 'wpnews_campaign_stats';
		$ids_list = implode(',', $campaign_ids);

		$results = $wpdb->get_results(
			"SELECT campaign_id, COUNT(*) as sent_count
			 FROM $stats_table
			 WHERE campaign_id IN ($ids_list)
			 GROUP BY campaign_id",
			ARRAY_A
		);

		$summary = array();
		foreach ((array) $results as $row) {
			$summary[(int) $row['campaign_id']] = (int) $row['sent_count'];
		}

		return $summary;
	}

	/**
	 * Get detailed stats (delivered, opened, clicked, bounced) for a list of campaigns.
	 * Child campaign stats are aggregated into their recurring parent.
	 *
	 * @param array $campaign_ids
	 * @return array Keyed by campaign_id: ['delivered' => n, 'opened' => n, 'clicked' => n, 'bounced' => n]
	 */
	public static function get_campaign_detailed_stats($campaign_ids)
	{
		$campaign_ids = array_values(array_unique(array_filter(array_map('intval', (array) $campaign_ids))));
		if (empty($campaign_ids)) {
			return array();
		}

		global $wpdb;
		$stats_table = $wpdb->prefix . 'wpnews_campaign_stats';
		$campaign_table = $wpdb->prefix . 'wpnews_campaigns';
		$ids_list = implode(',', $campaign_ids);

		// Map child_id => parent_id for recurring parents in the list
		$child_to_parent = array();
		$child_rows = $wpdb->get_results(
			"SELECT id, parent_id FROM $campaign_table WHERE parent_id IN ($ids_list)",
			ARRAY_A
		);
		foreach ((array) $child_rows as $row) {
			$child_to_parent[(int) $row['id']] = (int) $row['parent_id'];
		}

		$all_ids = array_unique(array_merge($campaign_ids, array_keys($child_to_parent)));
		$all_ids_list = implode(',', $all_ids);

		$results = $wpdb->get_results(
			"SELECT campaign_id,
				SUM(CASE WHEN delivered_at IS NOT NULL THEN 1 ELSE 0 END) as delivered,
				SUM(CASE WHEN opened_at IS NOT NULL THEN 1 ELSE 0 END) as opened,
				SUM(CASE WHEN clicked_at IS NOT NULL THEN 1 ELSE 0 END) as clicked,
				SUM(CASE WHEN bounced = 1 THEN 1 ELSE 0 END) as bounced
			FROM $stats_table
			WHERE campaign_id IN ($all_ids_list)
			GROUP BY campaign_id",
			ARRAY_A
		);

		$detailed = array();
		foreach ($campaign_ids as $id) {
			$detailed[$id] = array('delivered' => 0, 'opened' => 0, 'clicked' => 0, 'bounced' => 0);
		}

		foreach ((array) $results as $row) {
			$cid = (int) $row['campaign_id'];
			$target_id = isset($child_to_parent[$cid]) ? $child_to_parent[$cid] : $cid;
			if (isset($detailed[$target_id])) {
				$detailed[$target_id]['delivered'] += (int) $row['delivered'];
				$detailed[$target_id]['opened'] += (int) $row['opened'];
				$detailed[$target_id]['clicked'] += (int) $row['clicked'];
				$detailed[$target_id]['bounced'] += (int) $row['bounced'];
			}
		}

		return $detailed;
	}

	/**
	 * Duplicate a campaign.
	 *
	 * @param int      $campaign_id Campaign ID.
	 * @param string   $status      Status of the copy ('draft' or 'sending' for recurring snapshots).
	 * @param int|null $parent_id   Parent ID for recurring snapshots.
	 * @return int|false New campaign ID on success.
	 */
	public static function duplicate_campaign($campaign_id, $status = 'draft', $parent_id = null)
	{
		global $wpdb;

		$table = $wpdb->prefix . 'wpnews_campaigns';
		$campaign_id = (int) $campaign_id;
		$campaign = $wpdb->get_row(
			$wpdb->prepare("SELECT * FROM $table WHERE id = %d", $campaign_id),
			ARRAY_A
		);

		if (!$campaign) {
			return false;
		}

		$status = self::sanitize_status($status);
		if (null === $status) {
			$status = 'draft';
		}

		/* translators: %s: original campaign name */
		$new_name = ($status === 'draft') ? sprintf(__('Copy of %s', 'wp-news'), $campaign['name']) : $campaign['name'];

		$new_campaign = array(
			'name' => WPNews_Security::sanitize_text($new_name),
			'subject' => WPNews_Security::sanitize_text($campaign['subject']),
			'content' => $campaign['content'],
			'blocks_json' => $campaign['blocks_json'],
			'status' => $status,
			'parent_id' => $parent_id ? (int) $parent_id : null,
			'is_recurring' => 0, // Duplicates are snapshots or new drafts, never recurring templates
		);

		if ($status === 'sent') {
			$new_campaign['sent_at'] = current_time('mysql');
			$new_campaign['total_recipients'] = (int) $campaign['total_recipients'];
		}

		$result = $wpdb->insert($table, $new_campaign);
		if (false === $result) {
			return false;
		}

		$new_id = (int) $wpdb->insert_id;
		$lists = self::get_campaign_lists($campaign_id);
		if (!empty($lists)) {
			self::set_campaign_lists($new_id, $lists);
		}

		return $new_id;
	}

	/**
	 * Delete a campaign and related data.
	 *
	 * @param int $campaign_id Campaign ID.
	 * @return bool True on success, false on failure.
	 */
	public static function delete_campaign($campaign_id)
	{
		global $wpdb;

		$campaign_id = (int) $campaign_id;
		$campaign_table = $wpdb->prefix . 'wpnews_campaigns';
		$lists_table = $wpdb->prefix . 'wpnews_campaign_lists';
		$stats_table = $wpdb->prefix . 'wpnews_campaign_stats';
		$clicks_table = $wpdb->prefix . 'wpnews_campaign_clicks';

		$wpdb->delete($lists_table, array('campaign_id' => $campaign_id), array('%d'));
		$wpdb->delete($stats_table, array('campaign_id' => $campaign_id), array('%d'));
		$wpdb->delete($clicks_table, array('campaign_id' => $campaign_id), array('%d'));

		$result = $wpdb->delete($campaign_table, array('id' => $campaign_id), array('%d'));

		delete_option('wpnews_campaign_errors_' . $campaign_id);
		wp_clear_scheduled_hook('wpnews_send_campaign_async', array($campaign_id));

		return false !== $result;
	}

	/**
	 * Get clicked links grouped by URL and count for a campaign (or its children if recurring).
	 *
	 * @param int $campaign_id
	 * @return array
	 */
	public static function get_clicked_links_stats($campaign_id)
	{
		global $wpdb;
		$clicks_table = $wpdb->prefix . 'wpnews_campaign_clicks';
		$campaigns_table = $wpdb->prefix . 'wpnews_campaigns';
		$campaign_id = (int) $campaign_id;

		$campaign = self::get_campaign($campaign_id);
		$all_cids = array($campaign_id);

		if ($campaign && !empty($campaign['is_recurring'])) {
			$children_ids = $wpdb->get_col($wpdb->prepare("SELECT id FROM $campaigns_table WHERE parent_id = %d", $campaign_id));
			$all_cids = array_merge($all_cids, array_map('intval', (array) $children_ids));
		}

		$all_cids_str = implode(',', array_map('intval', $all_cids));
		$results = $wpdb->get_results(
			"SELECT url, COUNT(DISTINCT subscriber_id) as click_count
			 FROM $clicks_table
			 WHERE campaign_id IN ($all_cids_str)
			 GROUP BY url
			 ORDER BY click_count DESC",
			ARRAY_A
		);

		return is_array($results) ? $results : array();
	}

	/* ---------------------------------------------------------------------
	 * Sending engine
	 * ------------------------------------------------------------------ */

	/**
	 * Send a campaign (one time-boxed batch).
	 *
	 * Engine overview:
	 *  - A per-campaign lock (`wpnews_lock_{id}` row in wp_options, atomic INSERT IGNORE,
	 *    stale after LOCK_TTL) guarantees a single worker per campaign.
	 *  - Pending recipients come from ONE query (lists JOIN, status active, blacklist
	 *    excluded, NOT EXISTS on campaign_stats), fetched in chunks of FETCH_CHUNK.
	 *  - The HTML is prepared once (shortcodes, WPML switch, footer fallback); per
	 *    recipient only placeholders are replaced and tracking links wrapped.
	 *  - Claim-then-send: a campaign_stats row is inserted (INSERT IGNORE) BEFORE the
	 *    send; if the insert affects 0 rows the recipient was already handled by
	 *    another process. On provider failure the claim is deleted so the recipient
	 *    is retried in a later batch, and the error is logged (`WPNEWS: ...`).
	 *  - The loop runs until the time budget min(MAX_BATCH_SECONDS, max_execution_time - 30)
	 *    is exhausted or no recipients remain. No fixed sleep between emails.
	 *    MAX_BATCH_SECONDS is 90 s: LiteSpeed kills lsphp workers after
	 *    LSAPI_MAX_PROCESS_TIME (120 s on ticinoweb01) and a PHP process that has
	 *    issued ~900 HTTP requests starts failing with "getaddrinfo() thread failed
	 *    to start" (seen 2026-09-14 on sigmaconsulting.ch).
	 *  - Transport errors (provider result flagged `transient`: WP_Error from
	 *    wp_remote_post, HTTP 429/5xx) end the batch immediately: the failing
	 *    recipient is released and the next batch is scheduled TRANSPORT_RETRY_DELAY
	 *    seconds later, instead of burning through every remaining recipient.
	 *  - Rate limiting: the `sending_frequency` option (emails per minute) is applied
	 *    ONLY when > 0 AND the provider is Amazon SES (usleep(60/freq s) between sends).
	 *    SendGrid and the default (0/empty) run without pauses.
	 *  - When recipients remain, a `wpnews_send_campaign_async` single event is
	 *    scheduled and, once the campaign lock is released, wp-cron.php is pinged
	 *    with a non-blocking loopback request (see spawn_cron_now()) so the next
	 *    batch starts right away in a fresh PHP process even when DISABLE_WP_CRON
	 *    is set. Otherwise the campaign is finalised (status `sent`, `sent_at`;
	 *    recurring parents are rescheduled).
	 *  - Batches with zero successes and >0 failures are counted; after
	 *    MAX_FAILED_BATCHES consecutive ones the campaign is set to `stopped`.
	 *
	 * @param int      $campaign_id Campaign ID (recurring parent for recurring campaigns).
	 * @param int|null $child_id    Optional recurring snapshot ID (auto-detected when null).
	 * @return array Result array: success, message, success_count, error_count, errors[, remaining].
	 */
	public static function send_campaign($campaign_id, $child_id = null)
	{
		$campaign_id = (int) $campaign_id;

		$campaign = self::get_campaign($campaign_id);
		if (!$campaign) {
			return self::result(false, __('Campaign not found.', 'wp-news'));
		}

		// Prevent sending non-recurring campaigns that are already sent
		if ('sent' === $campaign['status'] && empty($campaign['is_recurring'])) {
			return self::result(false, __('Campaign already sent.', 'wp-news'));
		}

		// An imported draft has no HTML until it is opened and saved in the builder.
		if ('' === trim(wp_strip_all_tags((string) $campaign['content'])) && false === stripos((string) $campaign['content'], '<img')) {
			return self::result(false, __('This campaign has no content yet. Open it in the builder and save it before sending.', 'wp-news'));
		}

		if (!self::acquire_lock($campaign_id)) {
			return self::result(true, __('Campaign is already being processed by another worker.', 'wp-news'));
		}

		try {
			$result = self::run_batch($campaign, $child_id ? (int) $child_id : null);
		} finally {
			self::release_lock($campaign_id);
		}

		// Chain the next batch only after the lock is gone, otherwise the new
		// worker would find the campaign locked and give up.
		if (!empty($result['spawn_worker'])) {
			unset($result['spawn_worker']);
			self::spawn_cron_now();
		}

		return $result;
	}

	/**
	 * Build a standard result array.
	 *
	 * @param bool   $success
	 * @param string $message
	 * @param array  $extra
	 * @return array
	 */
	private static function result($success, $message, $extra = array())
	{
		return array_merge(array(
			'success' => $success,
			'message' => $message,
			'success_count' => 0,
			'error_count' => 0,
			'errors' => array(),
		), $extra);
	}

	/**
	 * Execute one batch for a locked campaign.
	 *
	 * @param array    $campaign Campaign row (with 'lists').
	 * @param int|null $child_id Recurring snapshot ID or null.
	 * @return array
	 */
	private static function run_batch(array $campaign, $child_id)
	{
		global $wpdb;

		$start = time();
		$budget = self::batch_time_budget();
		$campaign_id = (int) $campaign['id'];
		$campaign_table = $wpdb->prefix . 'wpnews_campaigns';
		$stats_table = $wpdb->prefix . 'wpnews_campaign_stats';
		$is_recurring = !empty($campaign['is_recurring']);
		$options = get_option('wpnews_options', array());
		if (!is_array($options)) {
			$options = array();
		}

		// Resolve the recurring snapshot (child) and whether this is the first batch
		if ($is_recurring) {
			if (!$child_id) {
				$child_id = (int) $wpdb->get_var($wpdb->prepare(
					"SELECT id FROM $campaign_table WHERE parent_id = %d AND status = 'sending' ORDER BY id DESC LIMIT 1",
					$campaign_id
				));
			}
			$is_first_batch = empty($child_id);
		} else {
			$child_id = null;
			$is_first_batch = ('sending' !== $campaign['status'] || (int) $campaign['total_recipients'] === 0);
		}

		// Recurring "send only if there are new posts" check (first batch only)
		if ($is_first_batch && $is_recurring && !empty($campaign['send_if_new']) && !self::has_new_posts_since_last_send($campaign)) {
			self::reschedule_recurring($campaign, null);
			return self::result(true, __('Skipped sending because there are no new published articles.', 'wp-news'));
		}

		$list_ids = array_filter(array_map('intval', (array) $campaign['lists']));

		if ($is_first_batch) {
			$total = empty($list_ids) ? 0 : self::count_recipients($list_ids, 0);

			if ($total === 0) {
				// Nothing to do: do not leave the campaign stuck in 'sending'
				if ($is_recurring) {
					self::reschedule_recurring($campaign, null);
				} else {
					$wpdb->update($campaign_table, array('status' => 'draft'), array('id' => $campaign_id), array('%s'), array('%d'));
				}
				return self::result(false, __('No recipients found.', 'wp-news'));
			}

			$wpdb->update(
				$campaign_table,
				array('status' => 'sending', 'total_recipients' => $total, 'sent_count' => 0),
				array('id' => $campaign_id),
				array('%s', '%d', '%d'),
				array('%d')
			);

			if ($is_recurring) {
				$child_id = self::duplicate_campaign($campaign_id, 'sending', $campaign_id);
				if (!$child_id) {
					$wpdb->update($campaign_table, array('status' => 'scheduled'), array('id' => $campaign_id), array('%s'), array('%d'));
					return self::result(false, __('Could not create the campaign snapshot.', 'wp-news'));
				}
			}

			delete_option('wpnews_campaign_errors_' . $campaign_id);
		}

		$target_id = $child_id ? (int) $child_id : $campaign_id;

		if (empty($list_ids)) {
			return self::finalize_campaign($campaign, $child_id, 0, self::result(true, ''));
		}

		// Prepare content ONCE
		$html_template = self::prepare_campaign_html($campaign, $options);
		$attachments = self::get_attachments($campaign);
		$mailer = new WPNews_Mailer();
		$delay_us = self::rate_limit_delay($options, $mailer->get_type());
		$subject = (string) $campaign['subject'];

		$results = self::result(true, '');
		$failed_ids = array();
		$transport_failure = '';

		while ((time() - $start) < $budget) {
			$recipients = self::get_pending_recipients($list_ids, $target_id, self::FETCH_CHUNK, $failed_ids);
			if (empty($recipients)) {
				break;
			}

			foreach ($recipients as $recipient) {
				if ((time() - $start) >= $budget) {
					break 2;
				}

				// Stop flag (set by the REST "stop" endpoint)
				if (get_transient('wpnews_stop_campaign_' . $campaign_id)) {
					delete_transient('wpnews_stop_campaign_' . $campaign_id);
					self::mark_stopped($campaign_id, $child_id);
					self::update_sent_count($campaign_id, $child_id, $target_id);
					$results['message'] = sprintf(
						/* translators: %d: number of emails sent before the stop */
						__('Campaign stopped. %d emails sent before stopping.', 'wp-news'),
						$results['success_count']
					);
					return $results;
				}

				$sid = (int) $recipient['id'];
				$email = isset($recipient['email']) ? (string) $recipient['email'] : '';
				if ('' === $email || !is_email($email)) {
					$failed_ids[] = $sid; // exclude from the next fetch in this run
					error_log(sprintf('WPNEWS: campaign #%d skipped subscriber #%d (invalid email).', $target_id, $sid));
					continue;
				}

				// Claim (atomic thanks to UNIQUE KEY campaign_subscriber)
				$wpdb->query($wpdb->prepare(
					"INSERT IGNORE INTO $stats_table (campaign_id, subscriber_id, sent_at) VALUES (%d, %d, %s)",
					$target_id,
					$sid,
					current_time('mysql')
				));
				if ((int) $wpdb->rows_affected < 1) {
					continue; // already handled by another worker
				}

				$rendered = self::render_for_recipient($html_template, $recipient, $target_id, $sid);
				$headers = array(
					'List-Unsubscribe' => '<' . $rendered['unsubscribe_url'] . '>',
					'List-Unsubscribe-Post' => 'List-Unsubscribe=One-Click',
				);

				$sent = $mailer->send_email($email, $subject, $rendered['html'], $headers, $attachments);

				if (!empty($sent['success'])) {
					$results['success_count']++;
				} else {
					// Release the claim so the recipient can be retried later
					$wpdb->delete($stats_table, array('campaign_id' => $target_id, 'subscriber_id' => $sid), array('%d', '%d'));
					$failed_ids[] = $sid;
					$message = isset($sent['message']) ? (string) $sent['message'] : __('Unknown error.', 'wp-news');
					error_log(sprintf('WPNEWS: campaign #%d send to %s failed: %s', $target_id, $email, $message));
					$results['error_count']++;
					$results['errors'][] = array('email' => $email, 'message' => $message);
					self::record_failure($campaign_id, $email, $message);

					if (!empty($sent['transient'])) {
						// The transport (DNS, connection, provider 429/5xx) is failing, not
						// this recipient: stop here and let a fresh process retry later.
						$transport_failure = $message;
						error_log(sprintf('WPNEWS: campaign #%d batch interrupted by a transport error after %d sends (%s); retry in %d s.', $target_id, $results['success_count'], $message, self::TRANSPORT_RETRY_DELAY));
						break 2;
					}
				}

				if ($delay_us > 0) {
					usleep($delay_us);
				}
			}
		}

		$sent_total = self::update_sent_count($campaign_id, $child_id, $target_id);
		$remaining = self::count_recipients($list_ids, $target_id);

		if ($remaining > 0) {
			if ($results['success_count'] === 0 && $results['error_count'] > 0) {
				$failed_batches = self::bump_failed_batches($campaign_id);
				if ($failed_batches >= self::MAX_FAILED_BATCHES) {
					self::mark_stopped($campaign_id, $child_id);
					error_log(sprintf('WPNEWS: campaign #%d stopped after %d consecutive batches without a successful send.', $campaign_id, $failed_batches));
					$results['success'] = false;
					$results['message'] = __('Campaign stopped after repeated delivery failures. Check the error log and resume when the problem is fixed.', 'wp-news');
					return $results;
				}
			} else {
				self::reset_failed_batches($campaign_id);
			}

			if ('' !== $transport_failure) {
				self::schedule_next_batch($campaign_id, self::TRANSPORT_RETRY_DELAY, false);
				$results['remaining'] = $remaining;
				$results['message'] = sprintf(
					/* translators: 1: emails sent in this batch, 2: remaining recipients, 3: seconds before the retry */
					__('Batch interrupted by a network error after %1$d emails. %2$d remaining - retry scheduled in %3$d seconds.', 'wp-news'),
					$results['success_count'],
					$remaining,
					self::TRANSPORT_RETRY_DELAY
				);
				return $results;
			}

			self::schedule_next_batch($campaign_id, 0, false);
			$results['spawn_worker'] = true; // send_campaign() pings wp-cron.php after releasing the lock
			$results['remaining'] = $remaining;
			$results['message'] = sprintf(
				/* translators: 1: emails sent in this batch, 2: remaining recipients */
				__('Batch sent: %1$d emails. %2$d remaining - next batch scheduled.', 'wp-news'),
				$results['success_count'],
				$remaining
			);
			return $results;
		}

		return self::finalize_campaign($campaign, $child_id, $sent_total, $results);
	}

	/**
	 * Seconds available for the current batch.
	 *
	 * @return int
	 */
	private static function batch_time_budget()
	{
		$budget = self::MAX_BATCH_SECONDS;
		$max_exec = (int) ini_get('max_execution_time');
		if ($max_exec > 0) {
			$budget = min($budget, max(30, $max_exec - 30));
		}
		return $budget;
	}

	/**
	 * Microseconds to sleep between two sends (0 = no pause).
	 *
	 * `sending_frequency` is interpreted as emails per minute and applied only
	 * when > 0 and the provider is Amazon SES.
	 *
	 * @param array  $options     Plugin options.
	 * @param string $mailer_type 'ses' or 'sendgrid'.
	 * @return int
	 */
	private static function rate_limit_delay(array $options, $mailer_type)
	{
		$freq = isset($options['sending_frequency']) ? (int) $options['sending_frequency'] : 0;
		if ($freq <= 0 || 'ses' !== $mailer_type) {
			return 0;
		}
		return (int) floor((60 / $freq) * 1000000);
	}

	/* ---- Lock ---------------------------------------------------------- */

	/**
	 * Acquire the per-campaign lock atomically (INSERT IGNORE into wp_options).
	 *
	 * @param int $campaign_id
	 * @return bool
	 */
	private static function acquire_lock($campaign_id)
	{
		global $wpdb;
		$name = 'wpnews_lock_' . (int) $campaign_id;
		$now = time();

		for ($attempt = 0; $attempt < 2; $attempt++) {
			$inserted = $wpdb->query($wpdb->prepare(
				"INSERT IGNORE INTO {$wpdb->options} (option_name, option_value, autoload) VALUES (%s, %s, 'no')",
				$name,
				(string) $now
			));
			if (1 === (int) $inserted) {
				wp_cache_delete($name, 'options');
				return true;
			}

			$existing = $wpdb->get_var($wpdb->prepare("SELECT option_value FROM {$wpdb->options} WHERE option_name = %s", $name));
			if (null === $existing) {
				continue; // vanished between the two queries: retry
			}
			if (($now - (int) $existing) > self::LOCK_TTL) {
				// Stale lock: compare-and-delete, then retry
				$wpdb->query($wpdb->prepare(
					"DELETE FROM {$wpdb->options} WHERE option_name = %s AND option_value = %s",
					$name,
					$existing
				));
				continue;
			}
			return false;
		}

		return false;
	}

	/**
	 * Release the per-campaign lock.
	 *
	 * @param int $campaign_id
	 */
	private static function release_lock($campaign_id)
	{
		global $wpdb;
		$name = 'wpnews_lock_' . (int) $campaign_id;
		$wpdb->delete($wpdb->options, array('option_name' => $name), array('%s'));
		wp_cache_delete($name, 'options');
	}

	/**
	 * Whether a non-stale lock exists for the campaign.
	 *
	 * @param int $campaign_id
	 * @return bool
	 */
	public static function is_locked($campaign_id)
	{
		global $wpdb;
		$name = 'wpnews_lock_' . (int) $campaign_id;
		$value = $wpdb->get_var($wpdb->prepare("SELECT option_value FROM {$wpdb->options} WHERE option_name = %s", $name));
		if (null === $value) {
			return false;
		}
		return (time() - (int) $value) <= self::LOCK_TTL;
	}

	/* ---- Recipients ---------------------------------------------------- */

	/**
	 * Shared FROM/WHERE fragment for recipient queries (integers only, safe to inline).
	 *
	 * @param array $list_ids           List IDs.
	 * @param int   $target_campaign_id Campaign whose stats exclude recipients (0 = none).
	 * @param array $exclude_ids        Subscriber IDs to skip.
	 * @return string
	 */
	private static function recipients_sql_body(array $list_ids, $target_campaign_id, array $exclude_ids = array())
	{
		global $wpdb;
		$subscribers_table = $wpdb->prefix . 'wpnews_subscribers';
		$subscriber_lists_table = $wpdb->prefix . 'wpnews_subscriber_lists';
		$blacklist_table = $wpdb->prefix . 'wpnews_blacklist';
		$stats_table = $wpdb->prefix . 'wpnews_campaign_stats';

		$lists_in = implode(',', array_map('intval', $list_ids));
		$target_campaign_id = (int) $target_campaign_id;

		$sql = "FROM $subscribers_table s
			INNER JOIN $subscriber_lists_table sl ON sl.subscriber_id = s.id AND sl.list_id IN ($lists_in)
			LEFT JOIN $blacklist_table bl ON bl.email = s.email
			WHERE s.status = 'active'
			  AND bl.email IS NULL";

		if ($target_campaign_id > 0) {
			$sql .= " AND NOT EXISTS (SELECT 1 FROM $stats_table st WHERE st.campaign_id = $target_campaign_id AND st.subscriber_id = s.id)";
		}

		$exclude_ids = array_filter(array_map('intval', $exclude_ids));
		if (!empty($exclude_ids)) {
			$sql .= ' AND s.id NOT IN (' . implode(',', $exclude_ids) . ')';
		}

		return $sql;
	}

	/**
	 * Count (distinct) pending recipients.
	 *
	 * @param array $list_ids
	 * @param int   $target_campaign_id 0 to count all eligible recipients.
	 * @return int
	 */
	private static function count_recipients(array $list_ids, $target_campaign_id)
	{
		global $wpdb;
		if (empty($list_ids)) {
			return 0;
		}
		return (int) $wpdb->get_var('SELECT COUNT(DISTINCT s.id) ' . self::recipients_sql_body($list_ids, $target_campaign_id));
	}

	/**
	 * Fetch a chunk of pending recipients (id, email, first_name, last_name).
	 *
	 * @param array $list_ids
	 * @param int   $target_campaign_id
	 * @param int   $limit
	 * @param array $exclude_ids
	 * @return array
	 */
	private static function get_pending_recipients(array $list_ids, $target_campaign_id, $limit, array $exclude_ids = array())
	{
		global $wpdb;
		if (empty($list_ids)) {
			return array();
		}
		$sql = 'SELECT DISTINCT s.id, s.email, s.first_name, s.last_name '
			. self::recipients_sql_body($list_ids, $target_campaign_id, $exclude_ids)
			. ' ORDER BY s.id ASC LIMIT ' . max(1, (int) $limit);

		$rows = $wpdb->get_results($sql, ARRAY_A);
		return is_array($rows) ? $rows : array();
	}

	/* ---- Content ------------------------------------------------------- */

	/**
	 * Prepare the campaign HTML once per batch: builder clean-up, WPML switch,
	 * shortcodes, footer fallback, physical address.
	 *
	 * @param array $campaign
	 * @param array $options
	 * @return string HTML template still containing per-recipient placeholders.
	 */
	private static function prepare_campaign_html(array $campaign, array $options)
	{
		$raw = isset($campaign['content']) ? (string) $campaign['content'] : '';

		// The JS builder erroneously serialises padding as paddingValues="[object Object]";
		// the brackets break WP's shortcode parser, leaking "]" into the email.
		$raw = preg_replace('/\s+paddingValues=&quot;[^&]*(?:&quot;)?/', '', $raw);
		$raw = preg_replace('/\s+paddingValues="[^"]*"/', '', $raw);
		$decoded = str_replace(array('&quot;', '&#034;', '&#34;'), '"', $raw);

		// WPML: render shortcodes in the campaign language
		$settings = json_decode(isset($campaign['blocks_json']) ? (string) $campaign['blocks_json'] : '', true);
		$wpml_language = (is_array($settings) && isset($settings['settings']['wpmlLanguage'])) ? (string) $settings['settings']['wpmlLanguage'] : '';
		$previous_lang = null;
		$switch_wpml = ('' !== $wpml_language && has_action('wpml_switch_language'));

		if ($switch_wpml) {
			$previous_lang = apply_filters('wpml_current_language', null);
			do_action('wpml_switch_language', $wpml_language);
		}

		$html = do_shortcode($decoded);

		if ($switch_wpml && $previous_lang) {
			do_action('wpml_switch_language', $previous_lang);
		}

		// Final safety: strip any leftover "] from broken shortcode parsing
		$html = preg_replace('/"\]\s*(?=<|$)/', '', $html);

		// Footer fallback: every email must carry an unsubscribe link
		if (false === stripos($html, '{{unsubscribe_url}}')) {
			$footer = self::build_fallback_footer($options);
			if (false !== stripos($html, '</body>')) {
				$html = str_ireplace('</body>', $footer . '</body>', $html);
			} else {
				$html .= $footer;
			}
		}

		$physical_address = isset($options['physical_address']) ? trim((string) $options['physical_address']) : '';
		$html = str_replace('{{physical_address}}', nl2br(esc_html($physical_address)), $html);

		return $html;
	}

	/**
	 * Minimal footer with unsubscribe link and physical address.
	 *
	 * @param array $options
	 * @return string
	 */
	private static function build_fallback_footer(array $options)
	{
		$physical_address = isset($options['physical_address']) ? trim((string) $options['physical_address']) : '';

		$html = '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0"><tr>'
			. '<td align="center" style="padding:16px;font-family:Arial,Helvetica,sans-serif;font-size:12px;line-height:18px;color:#6b7280;">';
		if ('' !== $physical_address) {
			$html .= nl2br(esc_html($physical_address)) . '<br />';
		}
		$html .= '<a href="{{unsubscribe_url}}" style="color:#6b7280;text-decoration:underline;">' . esc_html__('Unsubscribe', 'wp-news') . '</a>';
		$html .= '</td></tr></table>';

		return $html;
	}

	/**
	 * Per-recipient rendering: placeholders, open pixel, tracked links.
	 *
	 * @param string $html_template Output of prepare_campaign_html().
	 * @param array  $recipient     id, email, first_name, last_name.
	 * @param int    $campaign_id   Campaign used for stats (child snapshot for recurring).
	 * @param int    $subscriber_id
	 * @return array ['html' => string, 'unsubscribe_url' => string]
	 */
	private static function render_for_recipient($html_template, array $recipient, $campaign_id, $subscriber_id)
	{
		$campaign_id = (int) $campaign_id;
		$subscriber_id = (int) $subscriber_id;

		$unsub_url = self::get_unsubscribe_url($subscriber_id, $campaign_id);
		$fname = isset($recipient['first_name']) ? trim((string) $recipient['first_name']) : '';
		$lname = isset($recipient['last_name']) ? trim((string) $recipient['last_name']) : '';
		$email = isset($recipient['email']) ? (string) $recipient['email'] : '';

		$html = str_replace(
			array('{{unsubscribe_url}}', '{{email}}', '{{first_name}}', '{{last_name}}', '{{name}}'),
			array(WPNews_Security::email_url($unsub_url), esc_html($email), esc_html($fname), esc_html($lname), esc_html(trim($fname . ' ' . $lname))),
			$html_template
		);

		// Open pixel (before </body> so email clients see it)
		$pixel_tag = '<img src="' . WPNews_Security::email_url(self::build_open_url($campaign_id, $subscriber_id)) . '" width="1" height="1" alt="" style="display:none !important;" />';
		if (false !== stripos($html, '</body>')) {
			$html = str_ireplace('</body>', $pixel_tag . '</body>', $html);
		} else {
			$html .= $pixel_tag;
		}

		$html = self::wrap_tracking_links($html, $campaign_id, $subscriber_id);

		return array('html' => $html, 'unsubscribe_url' => $unsub_url);
	}

	/**
	 * HMAC-signed unsubscribe URL (same token format verified in public/class-public.php).
	 *
	 * @param int $subscriber_id
	 * @param int $campaign_id
	 * @return string
	 */
	public static function get_unsubscribe_url($subscriber_id, $campaign_id)
	{
		$subscriber_id = (int) $subscriber_id;
		$campaign_id = (int) $campaign_id;
		$token = WPNews_Security::sign($subscriber_id . ':' . $campaign_id);
		return home_url('/?wpnews_unsubscribe=1&s=' . $subscriber_id . '&c=' . $campaign_id . '&token=' . $token);
	}

	/**
	 * Signed open-tracking pixel URL.
	 *
	 * Params: c (campaign), s (subscriber), sig = HMAC("open|{c}|{s}").
	 *
	 * @param int $campaign_id
	 * @param int $subscriber_id
	 * @return string
	 */
	public static function build_open_url($campaign_id, $subscriber_id)
	{
		$campaign_id = (int) $campaign_id;
		$subscriber_id = (int) $subscriber_id;
		return add_query_arg(
			array(
				'c' => $campaign_id,
				's' => $subscriber_id,
				'sig' => WPNews_Security::sign('open|' . $campaign_id . '|' . $subscriber_id),
			),
			rest_url('wp-news/v1/track/open')
		);
	}

	/**
	 * Signed click-tracking URL.
	 *
	 * Params: c, s, u = base64url(url) (rawurlencoded), sig = HMAC("click|{c}|{s}|{url}").
	 *
	 * @param int    $campaign_id
	 * @param int    $subscriber_id
	 * @param string $url Absolute http(s) destination.
	 * @return string
	 */
	public static function build_click_url($campaign_id, $subscriber_id, $url)
	{
		$campaign_id = (int) $campaign_id;
		$subscriber_id = (int) $subscriber_id;
		$encoded = rtrim(strtr(base64_encode($url), '+/', '-_'), '=');
		return add_query_arg(
			array(
				'c' => $campaign_id,
				's' => $subscriber_id,
				'u' => rawurlencode($encoded),
				'sig' => WPNews_Security::sign('click|' . $campaign_id . '|' . $subscriber_id . '|' . $url),
			),
			rest_url('wp-news/v1/track/click')
		);
	}

	/**
	 * Wrap http(s) links in signed click-tracking redirects.
	 *
	 * Skipped: mailto/tel/sms/anchors/javascript, leftover placeholders, links already
	 * tracked, unsubscribe/confirm links. Root-relative paths are made absolute.
	 *
	 * @param string $html
	 * @param int    $campaign_id
	 * @param int    $subscriber_id
	 * @return string
	 */
	private static function wrap_tracking_links($html, $campaign_id, $subscriber_id)
	{
		return preg_replace_callback('/href=(["\'])(.*?)\1/i', function ($m) use ($campaign_id, $subscriber_id) {
			$quote = $m[1];
			$url = html_entity_decode(trim($m[2]), ENT_QUOTES, 'UTF-8');

			if ('' === $url || preg_match('/^(mailto:|tel:|sms:|#|javascript:|\{\{)/i', $url)) {
				return $m[0];
			}
			if (false !== strpos($url, '/track/click') || false !== strpos($url, 'wpnews_unsubscribe=') || false !== strpos($url, 'wpnews_confirm=')) {
				return $m[0];
			}
			if (!preg_match('#^https?://#i', $url)) {
				if (0 === strpos($url, '/') && 0 !== strpos($url, '//')) {
					$url = home_url($url);
				} else {
					return $m[0];
				}
			}

			return 'href=' . $quote . WPNews_Security::email_url(self::build_click_url($campaign_id, $subscriber_id, $url)) . $quote;
		}, $html);
	}

	/**
	 * Collect PDF attachments declared in the builder blocks.
	 * Only attachments whose mime type is application/pdf are accepted.
	 *
	 * @param array $campaign
	 * @return array Array of ['path', 'filename', 'type'].
	 */
	private static function get_attachments(array $campaign)
	{
		$attachments = array();
		if (empty($campaign['blocks_json'])) {
			return $attachments;
		}

		$blocks = json_decode((string) $campaign['blocks_json'], true);
		if (!is_array($blocks) || !isset($blocks['blocks']) || !is_array($blocks['blocks'])) {
			return $attachments;
		}

		foreach ($blocks['blocks'] as $block) {
			if (!is_array($block) || !isset($block['type']) || 'pdf-attachment' !== $block['type']) {
				continue;
			}
			$pdf_id = isset($block['props']['pdfId']) ? absint($block['props']['pdfId']) : 0;
			if ($pdf_id <= 0 || 'application/pdf' !== get_post_mime_type($pdf_id)) {
				continue;
			}
			$file_path = get_attached_file($pdf_id);
			if (!$file_path || !file_exists($file_path) || !is_readable($file_path)) {
				continue;
			}
			$filename = !empty($block['props']['pdfName']) ? sanitize_file_name((string) $block['props']['pdfName']) : basename($file_path);
			$attachments[] = array(
				'path' => $file_path,
				'filename' => $filename,
				'type' => 'application/pdf',
			);
		}

		return $attachments;
	}

	/* ---- Progress / errors -------------------------------------------- */

	/**
	 * Refresh sent_count on the parent (and child) from campaign_stats.
	 *
	 * @param int      $campaign_id
	 * @param int|null $child_id
	 * @param int      $target_id
	 * @return int Total rows in campaign_stats for the target.
	 */
	private static function update_sent_count($campaign_id, $child_id, $target_id)
	{
		global $wpdb;
		$campaign_table = $wpdb->prefix . 'wpnews_campaigns';
		$stats_table = $wpdb->prefix . 'wpnews_campaign_stats';

		$sent_total = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $stats_table WHERE campaign_id = %d", (int) $target_id));

		$wpdb->update($campaign_table, array('sent_count' => $sent_total), array('id' => (int) $campaign_id), array('%d'), array('%d'));
		if ($child_id) {
			$wpdb->update($campaign_table, array('sent_count' => $sent_total), array('id' => (int) $child_id), array('%d'), array('%d'));
		}

		return $sent_total;
	}

	/**
	 * Whether the campaigns table has a `failed_count` column (cached per request).
	 *
	 * @return bool
	 */
	private static function has_failed_count_column()
	{
		static $has = null;
		if (null === $has) {
			global $wpdb;
			$table = $wpdb->prefix . 'wpnews_campaigns';
			$has = (bool) $wpdb->get_var("SHOW COLUMNS FROM $table LIKE 'failed_count'");
		}
		return $has;
	}

	/**
	 * Record a failed send attempt: increments `failed_count` (column when available)
	 * and stores the last 20 errors in the `wpnews_campaign_errors_{id}` option.
	 *
	 * @param int    $campaign_id
	 * @param string $email
	 * @param string $message
	 */
	private static function record_failure($campaign_id, $email, $message)
	{
		global $wpdb;
		$campaign_id = (int) $campaign_id;

		if (self::has_failed_count_column()) {
			$table = $wpdb->prefix . 'wpnews_campaigns';
			$wpdb->query($wpdb->prepare("UPDATE $table SET failed_count = failed_count + 1 WHERE id = %d", $campaign_id));
		}

		$log = self::get_error_log($campaign_id);
		$log['failed_count'] = (int) $log['failed_count'] + 1;
		$log['errors'][] = array(
			'time' => current_time('mysql'),
			'email' => $email,
			'message' => mb_substr((string) $message, 0, 500),
		);
		$log['errors'] = array_slice($log['errors'], -20);
		update_option('wpnews_campaign_errors_' . $campaign_id, $log, false);
	}

	/**
	 * Read the error log option for a campaign.
	 *
	 * @param int $campaign_id
	 * @return array ['errors' => array, 'failed_count' => int, 'failed_batches' => int]
	 */
	public static function get_error_log($campaign_id)
	{
		$log = get_option('wpnews_campaign_errors_' . (int) $campaign_id, array());
		if (!is_array($log)) {
			$log = array();
		}
		return wp_parse_args($log, array('errors' => array(), 'failed_count' => 0, 'failed_batches' => 0));
	}

	/**
	 * Increment and return the consecutive failed-only batch counter.
	 *
	 * @param int $campaign_id
	 * @return int
	 */
	private static function bump_failed_batches($campaign_id)
	{
		$log = self::get_error_log($campaign_id);
		$log['failed_batches'] = (int) $log['failed_batches'] + 1;
		update_option('wpnews_campaign_errors_' . (int) $campaign_id, $log, false);
		return $log['failed_batches'];
	}

	/**
	 * Reset the consecutive failed-only batch counter.
	 *
	 * @param int $campaign_id
	 */
	private static function reset_failed_batches($campaign_id)
	{
		$log = self::get_error_log($campaign_id);
		if ((int) $log['failed_batches'] > 0) {
			$log['failed_batches'] = 0;
			update_option('wpnews_campaign_errors_' . (int) $campaign_id, $log, false);
		}
	}

	/**
	 * Set parent (and child) to 'stopped'.
	 *
	 * @param int      $campaign_id
	 * @param int|null $child_id
	 */
	private static function mark_stopped($campaign_id, $child_id)
	{
		global $wpdb;
		$campaign_table = $wpdb->prefix . 'wpnews_campaigns';
		$wpdb->update($campaign_table, array('status' => 'stopped'), array('id' => (int) $campaign_id), array('%s'), array('%d'));
		if ($child_id) {
			$wpdb->update($campaign_table, array('status' => 'stopped'), array('id' => (int) $child_id), array('%s'), array('%d'));
		}
	}

	/**
	 * Schedule the next batch for a campaign and, by default, ping wp-cron.php.
	 *
	 * @param int  $campaign_id Campaign ID.
	 * @param int  $delay       Seconds from now (0 = immediately).
	 * @param bool $spawn       Ping wp-cron.php right away (only when $delay is 0).
	 *                          Pass false while holding the campaign lock.
	 */
	public static function schedule_next_batch($campaign_id, $delay = 0, $spawn = true)
	{
		$campaign_id = (int) $campaign_id;
		$delay = max(0, (int) $delay);
		wp_clear_scheduled_hook('wpnews_send_campaign_async', array($campaign_id));
		wp_schedule_single_event(time() + $delay, 'wpnews_send_campaign_async', array($campaign_id));
		if ($spawn && 0 === $delay) {
			self::spawn_cron_now();
		}
	}

	/**
	 * Ping wp-cron.php right now with a non-blocking loopback request.
	 *
	 * Core's spawn_cron() is a no-op when DISABLE_WP_CRON is set, which on hosts
	 * driven by a system cron means every batch waits for the next external tick
	 * (15 minutes on ticinoweb01). This bypasses only that check and otherwise
	 * mirrors core: it claims the `doing_cron` lock and passes it as
	 * `doing_wp_cron`, so wp-cron.php accepts the request and any concurrent
	 * cron run stops at its next lock check (same behaviour as a successful
	 * spawn_cron()). Must be called when no campaign lock is held by this process.
	 */
	public static function spawn_cron_now()
	{
		if (defined('WP_INSTALLING') && WP_INSTALLING) {
			return;
		}
		if (false === apply_filters('wpnews_spawn_cron_now', true)) {
			return;
		}

		$doing_wp_cron = sprintf('%.22F', microtime(true));
		set_transient('doing_cron', $doing_wp_cron);

		$url = add_query_arg('doing_wp_cron', $doing_wp_cron, site_url('wp-cron.php'));

		wp_remote_post(
			$url,
			array(
				'timeout'   => 0.01,
				'blocking'  => false,
				/** This filter is documented in wp-includes/class-wp-http-streams.php */
				'sslverify' => apply_filters('https_local_ssl_verify', false),
			)
		);
	}

	/* ---- Recurring ----------------------------------------------------- */

	/**
	 * Whether at least one post was published since the last recurring send
	 * (default window: 7 days when never sent).
	 *
	 * @param array $campaign Recurring parent.
	 * @return bool
	 */
	private static function has_new_posts_since_last_send(array $campaign)
	{
		global $wpdb;
		$campaign_table = $wpdb->prefix . 'wpnews_campaigns';

		$last_sent = $wpdb->get_var($wpdb->prepare(
			"SELECT sent_at FROM $campaign_table WHERE parent_id = %d AND sent_at IS NOT NULL ORDER BY sent_at DESC LIMIT 1",
			(int) $campaign['id']
		));
		if (!$last_sent) {
			$last_sent = gmdate('Y-m-d H:i:s', strtotime(current_time('mysql')) - 7 * DAY_IN_SECONDS);
		}

		$settings = json_decode(isset($campaign['blocks_json']) ? (string) $campaign['blocks_json'] : '', true);
		$wpml_language = (is_array($settings) && isset($settings['settings']['wpmlLanguage'])) ? (string) $settings['settings']['wpmlLanguage'] : '';
		$previous_lang = null;
		$switch_wpml = ('' !== $wpml_language && has_action('wpml_switch_language'));

		if ($switch_wpml) {
			$previous_lang = apply_filters('wpml_current_language', null);
			do_action('wpml_switch_language', $wpml_language);
		}

		$new_posts = get_posts(array(
			'date_query' => array(array('after' => $last_sent)),
			'post_status' => 'publish',
			'posts_per_page' => 1,
			'fields' => 'ids',
			'suppress_filters' => false,
		));

		if ($switch_wpml && $previous_lang) {
			do_action('wpml_switch_language', $previous_lang);
		}

		return !empty($new_posts);
	}

	/**
	 * Compute the next run (site-local MySQL datetime) for a recurring campaign.
	 *
	 * @param array    $campaign Recurring parent (recurring_interval, recurring_day).
	 * @param int|null $from_ts  Reference "local" timestamp (default: now).
	 * @return string
	 */
	private static function next_recurring_timestamp(array $campaign, $from_ts = null)
	{
		$now_local = null === $from_ts ? strtotime(current_time('mysql')) : (int) $from_ts;
		$interval = isset($campaign['recurring_interval']) ? trim((string) $campaign['recurring_interval']) : '';
		$day = isset($campaign['recurring_day']) ? strtolower(trim((string) $campaign['recurring_day'])) : '';

		$weekdays = array('monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday');
		$next_ts = false;

		if ('' !== $day && in_array($day, $weekdays, true) && false !== strpos($interval, 'week')) {
			$next_ts = strtotime('next ' . $day, $now_local);
		} elseif ('' !== $interval && preg_match('/^\d+\s+(day|week|month|year)s?$/i', $interval)) {
			$next_ts = strtotime('+' . $interval, $now_local);
		}

		if (false === $next_ts || $next_ts <= $now_local) {
			$next_ts = strtotime('+1 week', $now_local);
		}

		return gmdate('Y-m-d H:i:s', $next_ts);
	}

	/**
	 * Put a recurring parent back to 'scheduled' at its next run.
	 *
	 * @param array    $campaign
	 * @param int|null $sent_count When not null, sent_count is updated too.
	 */
	private static function reschedule_recurring(array $campaign, $sent_count)
	{
		global $wpdb;
		$campaign_table = $wpdb->prefix . 'wpnews_campaigns';

		$data = array(
			'status' => 'scheduled',
			'schedule_at' => self::next_recurring_timestamp($campaign),
		);
		$formats = array('%s', '%s');
		if (null !== $sent_count) {
			$data['sent_count'] = (int) $sent_count;
			$formats[] = '%d';
		}

		$wpdb->update($campaign_table, $data, array('id' => (int) $campaign['id']), $formats, array('%d'));
	}

	/**
	 * Finalize a campaign after all recipients were processed.
	 *
	 * @param array    $campaign   Campaign row.
	 * @param int|null $child_id   Recurring snapshot ID.
	 * @param int      $total_sent Total emails sent.
	 * @param array    $results    Accumulated batch results.
	 * @return array
	 */
	private static function finalize_campaign(array $campaign, $child_id, $total_sent, array $results)
	{
		global $wpdb;
		$campaign_table = $wpdb->prefix . 'wpnews_campaigns';
		$campaign_id = (int) $campaign['id'];
		$now = current_time('mysql');

		if (!empty($campaign['is_recurring'])) {
			if ($child_id) {
				$wpdb->update(
					$campaign_table,
					array('status' => 'sent', 'sent_at' => $now, 'sent_count' => (int) $total_sent),
					array('id' => (int) $child_id),
					array('%s', '%s', '%d'),
					array('%d')
				);
			}
			self::reschedule_recurring($campaign, (int) $total_sent);
		} else {
			$wpdb->update(
				$campaign_table,
				array('status' => 'sent', 'sent_at' => $now, 'sent_count' => (int) $total_sent),
				array('id' => $campaign_id),
				array('%s', '%s', '%d'),
				array('%d')
			);
		}

		self::reset_failed_batches($campaign_id);
		wp_clear_scheduled_hook('wpnews_send_campaign_async', array($campaign_id));

		$results['success'] = true;
		$results['success_count'] = (int) $total_sent;
		$results['message'] = sprintf(
			/* translators: %d: number of recipients */
			__('Campaign sent successfully to %d recipients.', 'wp-news'),
			(int) $total_sent
		);

		return $results;
	}

	/* ---------------------------------------------------------------------
	 * Shortcodes
	 * ------------------------------------------------------------------ */

	/**
	 * Shortcode callback to render the Latest Posts block dynamically inside the email.
	 */
	public static function render_latest_posts_shortcode($atts)
	{
		// WP forces all shortcode attributes to lowercase!
		$atts = shortcode_atts(array(
			'postcount' => 3,
			'layout' => 'list',
			'showimage' => 'true',
			'imageposition' => 'top',
			'imagewidth' => 100,
			'imageborderradius' => 8,
			'showexcerpt' => 'true',
			'showdate' => 'true',
			'showauthor' => 'false',
			'buttontext' => __('Read the article', 'wp-news'),
			'articlebackgroundcolor' => '#ffffff',
			'titlecolor' => '#111111',
			'textcolor' => '#4b5563',
			'buttonbackgroundcolor' => '#2563eb',
			'buttontextcolor' => '#ffffff',
			'padding' => 24,
		), $atts, 'wpnews_latest_posts');

		// Adjust booleans and integers
		$show_image = filter_var($atts['showimage'], FILTER_VALIDATE_BOOLEAN);
		$show_excerpt = filter_var($atts['showexcerpt'], FILTER_VALIDATE_BOOLEAN);
		$show_date = filter_var($atts['showdate'], FILTER_VALIDATE_BOOLEAN);
		$show_author = filter_var($atts['showauthor'], FILTER_VALIDATE_BOOLEAN);

		$image_width = absint($atts['imagewidth']);
		$image_radius = absint($atts['imageborderradius']);
		$image_pos = $atts['imageposition'];

		$posts = get_posts(array(
			'posts_per_page' => absint($atts['postcount']),
			'post_status' => 'publish',
			'ignore_sticky_posts' => 1,
			'suppress_filters' => false,
		));

		if (empty($posts)) {
			return '';
		}

		$html = '<table width="100%" cellpadding="0" cellspacing="0" border="0" style="padding: ' . esc_attr($atts['padding']) . 'px 0;">';

		if ($atts['layout'] === 'grid') {
			$html .= '<tr><td align="center"><table width="100%" cellpadding="0" cellspacing="0" border="0"><tr>';
		}

		$count = 0;
		foreach ($posts as $post) {
			$image_url = get_the_post_thumbnail_url($post->ID, 'large');
			if (!$image_url) {
				$image_url = apply_filters('wpnews_fallback_thumbnail_url', WPNEWS_PLUGIN_URL . 'assets/placeholder.png');
			}

			$text_html = '<table width="100%" cellpadding="0" cellspacing="0" border="0"><tr><td style="padding: 20px; text-align: left;">';
			$text_html .= '<h2 style="margin: 0 0 10px 0; font-size: 20px; font-weight: bold; color: ' . esc_attr($atts['titlecolor']) . '; line-height: 1.3;">' . esc_html(get_the_title($post->ID)) . '</h2>';

			if ($show_date || $show_author) {
				$date = get_the_date('', $post->ID);
				$author = get_the_author_meta('display_name', $post->post_author);
				if ($show_date && $show_author) {
					/* translators: 1: publication date, 2: author name */
					$meta_text = sprintf(__('Published on %1$s by %2$s', 'wp-news'), $date, $author);
				} elseif ($show_date) {
					/* translators: %s: publication date */
					$meta_text = sprintf(__('Published on %s', 'wp-news'), $date);
				} else {
					/* translators: %s: author name */
					$meta_text = sprintf(__('By %s', 'wp-news'), $author);
				}
				$text_html .= '<p style="margin: 0 0 12px 0; font-size: 13px; color: #6b7280;">' . esc_html($meta_text) . '</p>';
			}

			if ($show_excerpt) {
				$text_html .= '<div style="margin: 0 0 20px 0; font-size: 15px; color: ' . esc_attr($atts['textcolor']) . '; line-height: 1.5;">' . wp_kses_post(wp_trim_words(get_the_excerpt($post->ID), 25)) . '</div>';
			}

			$text_html .= '<table cellpadding="0" cellspacing="0" border="0"><tr><td align="center" bgcolor="' . esc_attr($atts['buttonbackgroundcolor']) . '" style="border-radius: 6px;">';
			$text_html .= '<a href="' . esc_url(get_permalink($post->ID)) . '" style="display: inline-block; padding: 12px 20px; color: ' . esc_attr($atts['buttontextcolor']) . '; font-weight: bold; font-size: 14px; text-decoration: none; border-radius: 6px; background-color: ' . esc_attr($atts['buttonbackgroundcolor']) . ';">' . esc_html($atts['buttontext']) . '</a>';
			$text_html .= '</td></tr></table>';
			$text_html .= '</td></tr></table>';

			$img_html = '';
			if ($show_image && $image_url) {
				$img_style = 'display: block; max-width: 100%; height: auto; border-radius: ' . $image_radius . 'px;';
				if ($image_pos === 'top' && $image_width === 100 && $image_radius > 0) {
					$img_style = 'display: block; max-width: 100%; height: auto; border-top-left-radius: ' . $image_radius . 'px; border-top-right-radius: ' . $image_radius . 'px; border-bottom-left-radius: 0; border-bottom-right-radius: 0;';
				}

				if ($image_pos === 'top') {
					$align_wrap = $image_width < 100 ? 'align="center"' : 'align="left"';
					$img_html = '<table width="' . $image_width . '%" cellpadding="0" cellspacing="0" border="0" ' . $align_wrap . ' style="margin: 0 auto; width: ' . $image_width . '%;"><tr><td><img src="' . esc_url($image_url) . '" width="100%" alt="" style="' . $img_style . '" /></td></tr></table>';
				} else {
					$img_html = '<img src="' . esc_url($image_url) . '" width="100%" alt="" style="' . $img_style . '" />';
				}
			}

			$article_style = 'background-color: ' . esc_attr($atts['articlebackgroundcolor']) . '; margin-bottom: 20px; border-radius: 8px; border: 1px solid #e5e7eb; overflow: hidden;';

			if ($atts['layout'] === 'grid') {
				if ($count > 0 && $count % 2 === 0) {
					$html .= '</tr><tr>';
				}
				$pad_left = ($count % 2 !== 0) ? '10px' : '0';
				$pad_right = ($count % 2 === 0) ? '10px' : '0';

				$html .= '<td width="50%" valign="top" style="padding-left: ' . $pad_left . '; padding-right: ' . $pad_right . ';">';
			} else {
				$html .= '<tr><td align="center">';
			}

			// Render Article Container
			$html .= '<table width="100%" cellpadding="0" cellspacing="0" border="0" style="' . $article_style . '"><tr><td align="left" valign="top">';

			if (!$show_image || !$image_url || $image_pos === 'top') {
				$html .= $img_html . $text_html;
			} elseif ($image_pos === 'left') {
				$img_w = $image_width;
				$txt_w = 100 - $image_width;
				$html .= '<table width="100%" cellpadding="0" cellspacing="0" border="0"><tr>';
				$html .= '<td width="' . $img_w . '%" valign="top" style="width: ' . $img_w . '%; padding: 20px 0 20px 20px;">' . $img_html . '</td>';
				$html .= '<td width="' . $txt_w . '%" valign="top" style="width: ' . $txt_w . '%;">' . $text_html . '</td>';
				$html .= '</tr></table>';
			} elseif ($image_pos === 'right') {
				$img_w = $image_width;
				$txt_w = 100 - $image_width;
				$html .= '<table width="100%" cellpadding="0" cellspacing="0" border="0"><tr>';
				$html .= '<td width="' . $txt_w . '%" valign="top" style="width: ' . $txt_w . '%;">' . $text_html . '</td>';
				$html .= '<td width="' . $img_w . '%" valign="top" style="width: ' . $img_w . '%; padding: 20px 20px 20px 0;">' . $img_html . '</td>';
				$html .= '</tr></table>';
			}

			$html .= '</td></tr></table>';

			if ($atts['layout'] !== 'grid') {
				$html .= '</td></tr>';
			}

			$count++;
		}

		if ($atts['layout'] === 'grid') {
			// Fill empty cell if odd
			if ($count % 2 !== 0) {
				$html .= '<td width="50%"></td>';
			}
			$html .= '</tr></table></td></tr>';
		}

		$html .= '</table>';

		return $html;
	}
}
