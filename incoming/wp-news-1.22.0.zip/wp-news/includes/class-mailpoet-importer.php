<?php
/**
 * Import of MailPoet campaigns (newsletters) as WP-News campaigns.
 *
 * Sent newsletters become read-only "sent" campaigns (history, duplicable);
 * everything else becomes a draft, never scheduled, so nothing is sent by
 * surprise. The MailPoet editor JSON is converted to WP-News builder blocks
 * so that a copy can be edited and reused.
 *
 * @package WPNews
 */

defined('ABSPATH') || exit;

class WPNews_MailPoet_Importer
{
	/** Option mapping MailPoet newsletter id => WP-News campaign id (re-running skips imported ones). */
	const MAP_OPTION = 'wpnews_mailpoet_campaign_map';

	/** @var int Block id counter. */
	private static $counter = 0;

	/** @var array Unsupported MailPoet block types met during the current import (type => count). */
	private static $skipped_types = array();

	/** @var string Subject of the newsletter being converted (for [newsletter:subject]). */
	private static $subject = '';

	/**
	 * Resolve a MailPoet table name (with or without the WordPress prefix).
	 *
	 * @param string $name Table name without prefix.
	 * @return string Empty when the table does not exist.
	 */
	private static function table($name)
	{
		global $wpdb;
		foreach (array($wpdb->prefix . $name, $name) as $candidate) {
			if ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $candidate)) === $candidate) {
				return $candidate;
			}
		}
		return '';
	}

	/**
	 * Import the MailPoet campaigns.
	 *
	 * @return array Result: imported, skipped, sent, drafts, unsupported, errors.
	 */
	public static function import_campaigns()
	{
		global $wpdb;

		$result = array(
			'imported'    => 0,
			'already'     => 0,
			'sent'        => 0,
			'drafts'      => 0,
			'unsupported' => array(),
			'errors'      => array(),
		);

		$newsletters_table = self::table('mailpoet_newsletters');
		if ('' === $newsletters_table) {
			$result['errors'][] = __('MailPoet tables not found in database.', 'wp-news');
			return $result;
		}
		$queues_table   = self::table('mailpoet_sending_queues');
		$segments_table = self::table('mailpoet_newsletter_segment');
		$mp_lists_table = self::table('mailpoet_segments');

		if (function_exists('set_time_limit')) {
			@set_time_limit(120); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
		}

		$ids = $wpdb->get_col("SELECT id FROM $newsletters_table WHERE deleted_at IS NULL AND type IN ('standard','notification_history') ORDER BY COALESCE(sent_at, created_at) ASC, id ASC");
		$map = get_option(self::MAP_OPTION, array());
		if (!is_array($map)) {
			$map = array();
		}
		$campaigns_table = $wpdb->prefix . 'wpnews_campaigns';
		$lists_table     = $wpdb->prefix . 'wpnews_lists';
		self::$skipped_types = array();

		foreach (array_chunk(array_map('intval', (array) $ids), 20) as $chunk) {
			$in   = implode(',', $chunk);
			$rows = $wpdb->get_results("SELECT * FROM $newsletters_table WHERE id IN ($in)", ARRAY_A);

			foreach ((array) $rows as $row) {
				$mp_id = (int) $row['id'];

				if (!empty($map[$mp_id]) && $wpdb->get_var($wpdb->prepare("SELECT id FROM $campaigns_table WHERE id = %d", (int) $map[$mp_id]))) {
					$result['already']++;
					continue;
				}

				$subject = trim((string) $row['subject']);
				self::$subject = $subject;
				$body    = json_decode((string) $row['body'], true);
				$built   = is_array($body) ? self::convert_body($body, (string) $row['preheader']) : array('blocks' => array(), 'settings' => array());

				$is_sent  = ('sent' === $row['status'] || 'notification_history' === $row['type']) && !empty($row['sent_at']);
				$queue    = null;
				$html     = '';
				if ('' !== $queues_table) {
					$queue = $wpdb->get_row($wpdb->prepare("SELECT newsletter_rendered_body, count_total, count_processed FROM $queues_table WHERE newsletter_id = %d ORDER BY id DESC LIMIT 1", $mp_id), ARRAY_A);
					if ($queue && !empty($queue['newsletter_rendered_body'])) {
						$rendered = json_decode((string) $queue['newsletter_rendered_body'], true);
						$html     = is_array($rendered) && !empty($rendered['html']) ? (string) $rendered['html'] : (string) $queue['newsletter_rendered_body'];
						$html     = self::convert_shortcodes($html);
					}
				}

				$blocks_json = '';
				if (!empty($built['blocks'])) {
					$blocks_json = wp_json_encode(
						array('type' => 'react-email-builder', 'blocks' => $built['blocks'], 'settings' => $built['settings']),
						JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
					);
				}

				// Lists: only the ones already present in WP-News (same name), none is created here.
				$list_ids = array();
				if ('' !== $segments_table && '' !== $mp_lists_table) {
					$names = $wpdb->get_col($wpdb->prepare("SELECT s.name FROM $segments_table ns INNER JOIN $mp_lists_table s ON s.id = ns.segment_id WHERE ns.newsletter_id = %d", $mp_id));
					foreach ((array) $names as $name) {
						$lid = (int) $wpdb->get_var($wpdb->prepare("SELECT id FROM $lists_table WHERE name = %s ORDER BY id ASC LIMIT 1", WPNews_Security::sanitize_text($name)));
						if ($lid) {
							$list_ids[] = $lid;
						}
					}
				}

				$campaign_id = WPNews_Campaign_Manager::create_campaign(array(
					'name'        => $subject,
					'subject'     => $subject,
					'content'     => $html,
					'blocks_json' => $blocks_json,
					'lists'       => $list_ids,
				));
				if (!$campaign_id) {
					/* translators: %s: newsletter subject */
					$result['errors'][] = sprintf(__('Could not import "%s".', 'wp-news'), $subject);
					continue;
				}

				$update = array();
				if (!empty($row['created_at'])) {
					$update['created_at'] = $row['created_at'];
				}
				if ($is_sent) {
					$update['status']           = 'sent';
					$update['sent_at']          = $row['sent_at'];
					$update['total_recipients'] = $queue ? (int) $queue['count_total'] : 0;
					$update['sent_count']       = $queue ? (int) $queue['count_processed'] : 0;
					$result['sent']++;
				} else {
					$result['drafts']++;
				}
				if ($update) {
					$wpdb->update($campaigns_table, $update, array('id' => (int) $campaign_id));
				}

				$map[$mp_id] = (int) $campaign_id;
				$result['imported']++;
			}
		}

		update_option(self::MAP_OPTION, $map, false);
		$result['unsupported'] = self::$skipped_types;

		return $result;
	}

	/* ---------------------------------------------------------------------
	 * Conversion
	 * ------------------------------------------------------------------ */

	/**
	 * Convert a MailPoet editor body to WP-News blocks and email settings.
	 *
	 * @param array  $body      Decoded MailPoet body (content, globalStyles).
	 * @param string $preheader Newsletter preheader.
	 * @return array { blocks: array, settings: array }
	 */
	public static function convert_body(array $body, $preheader = '')
	{
		$styles = isset($body['globalStyles']) && is_array($body['globalStyles']) ? $body['globalStyles'] : array();
		$blocks = array();
		if (isset($body['content']) && is_array($body['content'])) {
			self::walk($body['content'], $styles, $blocks);
		}

		$text_color = self::color(isset($styles['text']['fontColor']) ? $styles['text']['fontColor'] : '', '#111111');
		$settings   = array(
			'preheader'              => (string) $preheader,
			'bodyBackgroundColor'    => self::color(isset($styles['body']['backgroundColor']) ? $styles['body']['backgroundColor'] : '', '#f5f5f5'),
			'bodyBackgroundImage'    => '',
			'bodyPaddingTop'         => 24,
			'bodyPaddingBottom'      => 24,
			'contentBackgroundColor' => self::color(isset($styles['wrapper']['backgroundColor']) ? $styles['wrapper']['backgroundColor'] : '', '#ffffff'),
			'contentPadding'         => 20,
			'contentBorderRadius'    => 14,
			'contentBorderWidth'     => 1,
			'contentBorderColor'     => '#e2e6ed',
			'rowPadding'             => 12,
			'columnPadding'          => 8,
			'textColor'              => $text_color,
			'fontFamily'             => self::font(isset($styles['text']['fontFamily']) ? $styles['text']['fontFamily'] : ''),
			'contentWidth'           => 600,
			'internalNote'           => '',
			'wpmlLanguage'           => '',
		);

		return array('blocks' => $blocks, 'settings' => $settings);
	}

	/**
	 * Walk the MailPoet container tree depth-first, appending converted blocks.
	 * Columns are flattened in reading order (WP-News has no free column layout).
	 */
	private static function walk(array $node, array $styles, array &$out)
	{
		$type = isset($node['type']) ? (string) $node['type'] : '';

		if ('container' === $type) {
			foreach ((array) (isset($node['blocks']) ? $node['blocks'] : array()) as $child) {
				if (is_array($child)) {
					self::walk($child, $styles, $out);
				}
			}
			return;
		}

		switch ($type) {
			case 'text':
				foreach (self::convert_text(isset($node['text']) ? (string) $node['text'] : '', $styles) as $block) {
					$out[] = $block;
				}
				break;

			case 'image':
				$src = isset($node['src']) ? trim((string) $node['src']) : '';
				if ('' === $src) {
					break;
				}
				$width = isset($node['width']) ? (int) $node['width'] : 600;
				$pct   = !empty($node['fullWidth']) ? 100 : max(10, min(100, (int) round($width / 600 * 100)));
				$out[] = self::block('image', array(
					'src'          => $src,
					'alt'          => isset($node['alt']) ? (string) $node['alt'] : '',
					'width'        => 560,
					'widthValue'   => $pct,
					'widthUnit'    => '%',
					'align'        => self::align(isset($node['styles']['block']['textAlign']) ? $node['styles']['block']['textAlign'] : 'center'),
					'borderRadius' => 0,
					'overlayColor' => 'transparent',
					'overlayOpacity' => 0,
					'shadow'       => 'none',
					'framePadding' => 0,
					'linkUrl'      => self::url(isset($node['link']) ? $node['link'] : ''),
				));
				break;

			case 'button':
				$b     = isset($node['styles']['block']) && is_array($node['styles']['block']) ? $node['styles']['block'] : array();
				$out[] = self::block('button', array(
					'text'            => isset($node['text']) ? wp_strip_all_tags(self::convert_shortcodes((string) $node['text'])) : '',
					'url'             => self::url(isset($node['url']) ? $node['url'] : ''),
					'align'           => self::align(isset($b['textAlign']) ? $b['textAlign'] : 'center'),
					'backgroundColor' => self::color(isset($b['backgroundColor']) ? $b['backgroundColor'] : '', '#1b5cff'),
					'textColor'       => self::color(isset($b['fontColor']) ? $b['fontColor'] : '', '#ffffff'),
				));
				break;

			case 'divider':
				$b     = isset($node['styles']['block']) && is_array($node['styles']['block']) ? $node['styles']['block'] : array();
				$out[] = self::block('divider', array(
					'color'     => self::color(isset($b['borderColor']) ? $b['borderColor'] : '', '#e6e6e6'),
					'thickness' => max(1, min(10, isset($b['borderWidth']) ? (int) $b['borderWidth'] : 1)),
				));
				break;

			case 'spacer':
				$h     = isset($node['styles']['block']['height']) ? (int) $node['styles']['block']['height'] : 24;
				$out[] = self::block('spacer', array('height' => max(4, min(200, $h))));
				break;

			case 'social':
				$map   = array('website' => 'websiteUrl', 'instagram' => 'instagramUrl', 'facebook' => 'facebookUrl', 'linkedin' => 'linkedinUrl', 'twitter' => 'xUrl', 'youtube' => 'youtubeUrl', 'tiktok' => 'tiktokUrl');
				$props = array('websiteUrl' => '', 'instagramUrl' => '', 'facebookUrl' => '', 'linkedinUrl' => '', 'xUrl' => '', 'youtubeUrl' => '', 'tiktokUrl' => '');
				foreach ((array) (isset($node['icons']) ? $node['icons'] : array()) as $icon) {
					$kind = isset($icon['iconType']) ? (string) $icon['iconType'] : '';
					if (isset($map[$kind]) && !empty($icon['link'])) {
						$props[$map[$kind]] = self::url($icon['link']);
					}
				}
				if (array_filter($props)) {
					$out[] = self::block('social', $props);
				}
				break;

			case 'footer':
				// The WP-News footer adds the unsubscribe link and the address itself: drop the MailPoet ones.
				$text = isset($node['text']) ? self::convert_shortcodes((string) $node['text']) : '';
				$text = preg_replace('#<a\b[^>]*href=(["\'])\{\{unsubscribe_url\}\}\1[^>]*>.*?</a>#is', '', $text);
				$text = str_replace('{{physical_address}}', '', $text);
				$text = preg_replace('#(<p[^>]*>|<br\s*/?>)\s*[|\-–·]\s*#i', '$1', $text);
				$text = preg_replace('#\s*[|\-–·]\s*(<br\s*/?>|</p>)#i', '$1', $text);
				$text = preg_replace('#^\s*[|\-–·]\s*#', '', $text);
				$items = self::convert_text($text, $styles);
				$html  = array();
				foreach ($items as $item) {
					if (isset($item['props']['text']) && '' !== trim(wp_strip_all_tags($item['props']['text']))) {
						$html[] = $item['props']['text'];
					}
				}
				$out[] = self::block('footer', array(
					'text'             => implode('<br>', $html),
					'align'            => 'center',
					'color'            => '#6b6b6b',
					'backgroundColor'  => 'transparent',
					'backgroundImage'  => '',
					'padding'          => 24,
					'logoUrl'          => '',
					'logoAlt'          => '',
					'logoWidth'        => 120,
					'socialIconSize'   => 16,
					'socialLinks'      => array('websiteUrl' => '', 'instagramUrl' => '', 'facebookUrl' => '', 'linkedinUrl' => '', 'xUrl' => '', 'youtubeUrl' => '', 'tiktokUrl' => ''),
				));
				break;

			case 'automatedLatestContent':
			case 'automatedLatestContentLayout':
				$out[] = self::block('latest-posts', array(
					'postCount'             => max(1, min(10, isset($node['amount']) ? (int) $node['amount'] : 3)),
					'layout'                => 'list',
					'showImage'             => true,
					'imagePosition'         => 'top',
					'imageWidth'            => 100,
					'imageBorderRadius'     => 8,
					'showExcerpt'           => true,
					'showDate'              => true,
					'showAuthor'            => false,
					'buttonText'            => __('Read more', 'wp-news'),
					'articleBackgroundColor' => '#ffffff',
					'titleColor'            => '#111111',
					'textColor'             => '#4b5563',
					'buttonBackgroundColor' => '#2563eb',
					'buttonTextColor'       => '#ffffff',
					'padding'               => 24,
				));
				break;

			case 'header': // "View it in your browser": WP-News has no equivalent.
				break;

			default:
				if ('' !== $type) {
					self::$skipped_types[$type] = (isset(self::$skipped_types[$type]) ? self::$skipped_types[$type] : 0) + 1;
				}
		}
	}

	/**
	 * Split a MailPoet text block into heading and text blocks.
	 *
	 * @return array[] WP-News blocks.
	 */
	private static function convert_text($html, array $styles)
	{
		$html = self::convert_shortcodes($html);
		if ('' === trim($html)) {
			return array();
		}

		$dom = new DOMDocument();
		$prev = libxml_use_internal_errors(true);
		$dom->loadHTML('<?xml encoding="utf-8" ?><div id="wpn-root">' . $html . '</div>', LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD);
		libxml_clear_errors();
		libxml_use_internal_errors($prev);
		$root = $dom->getElementById('wpn-root');
		if (!$root) {
			return array(self::text_block(wp_kses_post($html), 'left', $styles));
		}

		$blocks = array();
		$buffer = array();
		$align  = '';

		$flush = static function () use (&$buffer, &$align, &$blocks, $styles) {
			$text = trim(implode('<br>', $buffer));
			$text = preg_replace('/^(?:<br\s*\/?>\s*)+|(?:<br\s*\/?>\s*)+$/i', '', $text);
			if ('' !== trim(wp_strip_all_tags($text)) || false !== stripos($text, '<img')) {
				$blocks[] = WPNews_MailPoet_Importer::text_block($text, '' !== $align ? $align : 'left', $styles);
			}
			$buffer = array();
			$align  = '';
		};

		foreach ($root->childNodes as $node) {
			if (XML_ELEMENT_NODE !== $node->nodeType) {
				$t = trim($node->textContent);
				if ('' !== $t) {
					$buffer[] = esc_html($t);
				}
				continue;
			}
			$tag   = strtolower($node->nodeName);
			$inner = self::inner_html($node);
			$a     = self::node_align($node);

			if (in_array($tag, array('h1', 'h2', 'h3', 'h4'), true)) {
				$flush();
				$level = 'h4' === $tag ? 'h3' : $tag;
				$hs    = isset($styles[$level]) && is_array($styles[$level]) ? $styles[$level] : array();
				$blocks[] = self::block('heading', array(
					'text'            => wp_kses_post($inner),
					'level'           => $level,
					'align'           => '' !== $a ? $a : 'left',
					'color'           => self::color(isset($hs['fontColor']) ? $hs['fontColor'] : '', '#111111'),
					'backgroundColor' => 'transparent',
					'paddingValues'   => null,
					'padding'         => 0,
					'borderWidth'     => 0,
					'borderColor'     => '#e2e8f0',
					'borderRadius'    => 0,
				));
				continue;
			}

			if ('' === $align && '' !== $a) {
				$align = $a;
			}
			if (in_array($tag, array('ul', 'ol'), true)) {
				$n = 0;
				foreach ($node->getElementsByTagName('li') as $li) {
					$n++;
					$buffer[] = ('ol' === $tag ? $n . '. ' : '• ') . self::inner_html($li);
				}
				continue;
			}
			$buffer[] = $inner;
		}
		$flush();

		return $blocks;
	}

	/** Public only so the closure above can call it. */
	public static function text_block($html, $align, array $styles)
	{
		$px   = isset($styles['text']['fontSize']) ? (int) $styles['text']['fontSize'] : 0;
		$size = '';
		if ($px >= 34) {
			$size = '36';
		} elseif ($px >= 26) {
			$size = '28';
		} elseif ($px >= 20) {
			$size = '22';
		} elseif ($px >= 17) {
			$size = '18';
		}

		return self::block('text', array(
			'text'            => wp_kses_post($html),
			'align'           => $align,
			'fontSize'        => $size,
			'color'           => self::color(isset($styles['text']['fontColor']) ? $styles['text']['fontColor'] : '', '#333333'),
			'backgroundColor' => 'transparent',
			'paddingValues'   => null,
			'padding'         => 0,
			'borderWidth'     => 0,
			'borderColor'     => '#e2e8f0',
			'borderRadius'    => 0,
		));
	}

	/**
	 * Replace MailPoet shortcodes with WP-News placeholders and drop the rest.
	 */
	public static function convert_shortcodes($html)
	{
		$html = (string) $html;

		// Links to the unsubscribe / manage pages become the WP-News unsubscribe link; "view in browser" is dropped.
		$html = preg_replace('/\[link:(?:subscription_unsubscribe_url|subscription_instant_unsubscribe_url|subscription_manage_url)\]/i', '{{unsubscribe_url}}', $html);
		$html = preg_replace('#<a\b[^>]*href=(["\'])\[link:newsletter_view_in_browser_url\]\1[^>]*>.*?</a>#is', '', $html);
		$html = preg_replace('/\[link:[^\]]*\]/i', '#', $html);

		$html = preg_replace('/\[subscriber:(?:firstname|first_name)[^\]]*\]/i', '{{first_name}}', $html);
		$html = preg_replace('/\[subscriber:(?:lastname|last_name)[^\]]*\]/i', '{{last_name}}', $html);
		$html = preg_replace('/\[subscriber:email[^\]]*\]/i', '{{email}}', $html);
		$html = preg_replace('/\[subscriber:(?:displayname|fullname|name)[^\]]*\]/i', '{{name}}', $html);
		$html = str_ireplace('[site:title]', esc_html(get_bloginfo('name')), $html);
		$html = str_ireplace('[site:homepage_url]', esc_url(home_url('/')), $html);
		$html = str_ireplace('[site:address]', '{{physical_address}}', $html);
		$html = str_ireplace('[newsletter:subject]', esc_html(self::$subject), $html);

		// Anything else (dates, custom fields, WooCommerce...) has no equivalent: remove it.
		$html = preg_replace('/\[(?:subscriber|site|newsletter|date|custom|global|wc|mailpoet|link)[^\]]*\]/i', '', $html);

		return $html;
	}

	/* ---------------------------------------------------------------------
	 * Helpers
	 * ------------------------------------------------------------------ */

	private static function block($type, array $props)
	{
		self::$counter++;
		return array(
			'id'    => sprintf('block-%s-mp%s-%s', $type, base_convert((string) time(), 10, 36), base_convert((string) self::$counter, 10, 36)),
			'type'  => $type,
			'props' => $props,
		);
	}

	private static function inner_html(DOMNode $node)
	{
		$html = '';
		foreach ($node->childNodes as $child) {
			$html .= $node->ownerDocument->saveHTML($child);
		}
		return trim($html);
	}

	/** text-align from the element's inline style. */
	private static function node_align(DOMNode $node)
	{
		if ($node instanceof DOMElement && preg_match('/text-align:\s*(left|center|right)/i', (string) $node->getAttribute('style'), $m)) {
			return strtolower($m[1]);
		}
		return '';
	}

	private static function align($value)
	{
		$value = strtolower((string) $value);
		return in_array($value, array('left', 'center', 'right'), true) ? $value : 'center';
	}

	private static function color($value, $fallback)
	{
		$value = trim((string) $value);
		if ('transparent' === strtolower($value)) {
			return 'transparent';
		}
		$hex = sanitize_hex_color($value);
		return $hex ? $hex : $fallback;
	}

	private static function url($value)
	{
		$value = trim((string) $value);
		if ('' === $value || '#' === $value) {
			return '';
		}
		$value = self::convert_shortcodes($value);
		return preg_match('/^\{\{[a-z0-9_]+\}\}$/i', $value) ? $value : esc_url_raw($value);
	}

	/** Map a MailPoet font name to a WP-News font stack. */
	private static function font($name)
	{
		$stacks = array(
			'arial'           => 'Arial, sans-serif',
			'verdana'         => 'Verdana, Geneva, sans-serif',
			'tahoma'          => 'Tahoma, Verdana, sans-serif',
			'trebuchet ms'    => 'Trebuchet MS, Arial, sans-serif',
			'georgia'         => 'Georgia, serif',
			'times new roman' => 'Times New Roman, Times, serif',
			'courier new'     => 'Courier New, Courier, monospace',
			'garamond'        => 'Garamond, Times, serif',
		);
		$key = strtolower(trim((string) $name));
		return isset($stacks[$key]) ? $stacks[$key] : 'Arial, sans-serif';
	}
}
