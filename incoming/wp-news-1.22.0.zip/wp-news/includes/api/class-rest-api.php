<?php
/**
 * REST API Handler
 *
 * @package WPNews
 */

class WPNews_REST_API extends WP_REST_Controller
{

    protected $namespace = 'wp-news/v1';
    protected $rest_base = 'builder';

    public function register_routes()
    {
        // Save Campaign
        register_rest_route($this->namespace, '/' . $this->rest_base . '/save', array(
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => array($this, 'save_campaign'),
            'permission_callback' => array($this, 'permissions_check'),
        ));

        // Get Campaign
        register_rest_route($this->namespace, '/' . $this->rest_base . '/(?P<id>\d+)', array(
            'methods' => WP_REST_Server::READABLE,
            'callback' => array($this, 'get_campaign'),
            'permission_callback' => array($this, 'permissions_check'),
        ));

        // Duplicate Campaign (as draft)
        register_rest_route($this->namespace, '/' . $this->rest_base . '/duplicate/(?P<id>\d+)', array(
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => array($this, 'duplicate_campaign'),
            'permission_callback' => array($this, 'permissions_check'),
        ));

        // Preview: returns the sanitized HTML exactly as it will be stored/sent
        register_rest_route($this->namespace, '/' . $this->rest_base . '/preview', array(
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => array($this, 'preview_campaign'),
            'permission_callback' => array($this, 'permissions_check'),
        ));

        // Lists
        register_rest_route($this->namespace, '/lists', array(
            array(
                'methods' => WP_REST_Server::READABLE,
                'callback' => array($this, 'get_lists'),
                'permission_callback' => array($this, 'permissions_check'),
            ),
            array(
                'methods' => WP_REST_Server::CREATABLE,
                'callback' => array($this, 'create_list'),
                'permission_callback' => array($this, 'permissions_check'),
            ),
        ));

        // Get Theme Data (ticinoWEB CMS)
        register_rest_route($this->namespace, '/' . $this->rest_base . '/theme-data', array(
            'methods' => WP_REST_Server::READABLE,
            'callback' => array($this, 'get_theme_data'),
            'permission_callback' => array($this, 'permissions_check'),
        ));

        // Send Test Email
        register_rest_route($this->namespace, '/' . $this->rest_base . '/test-send', array(
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => array($this, 'send_test_email'),
            'permission_callback' => array($this, 'permissions_check'),
        ));

        // Send Campaign Now
        register_rest_route($this->namespace, '/' . $this->rest_base . '/send', array(
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => array($this, 'send_campaign_now'),
            'permission_callback' => array($this, 'permissions_check'),
        ));

        // Stop Campaign
        register_rest_route($this->namespace, '/' . $this->rest_base . '/stop', array(
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => array($this, 'stop_campaign'),
            'permission_callback' => array($this, 'permissions_check'),
        ));

        // Resume a stopped campaign
        register_rest_route($this->namespace, '/' . $this->rest_base . '/resume', array(
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => array($this, 'resume_campaign'),
            'permission_callback' => array($this, 'permissions_check'),
        ));

        // Campaign Progress
        register_rest_route($this->namespace, '/' . $this->rest_base . '/progress', array(
            'methods' => WP_REST_Server::READABLE,
            'callback' => array($this, 'get_campaign_progress'),
            'permission_callback' => array($this, 'permissions_check'),
        ));

        // SNS notification status check
        register_rest_route($this->namespace, '/' . $this->rest_base . '/sns-status', array(
            'methods' => WP_REST_Server::READABLE,
            'callback' => array($this, 'get_sns_status'),
            'permission_callback' => array($this, 'permissions_check'),
        ));

        // Tracking Routes (Public, HMAC-signed)
        register_rest_route($this->namespace, '/track/open', array(
            'methods' => WP_REST_Server::READABLE,
            'callback' => array($this, 'track_open'),
            'permission_callback' => '__return_true',
        ));

        register_rest_route($this->namespace, '/track/click', array(
            'methods' => WP_REST_Server::READABLE,
            'callback' => array($this, 'track_click'),
            'permission_callback' => '__return_true',
        ));

        // Import from MailPoet
        register_rest_route($this->namespace, '/subscribers/import-mailpoet', array(
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => array($this, 'import_from_mailpoet'),
            'permission_callback' => array($this, 'permissions_check'),
        ));

        // Import campaigns from MailPoet
        register_rest_route($this->namespace, '/campaigns/import-mailpoet', array(
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => array($this, 'import_campaigns_from_mailpoet'),
            'permission_callback' => array($this, 'permissions_check'),
        ));

        // Update Subscriber
        register_rest_route($this->namespace, '/subscribers/update', array(
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => array($this, 'update_subscriber'),
            'permission_callback' => array($this, 'permissions_check'),
        ));

        // Blacklist Subscriber
        register_rest_route($this->namespace, '/subscribers/blacklist', array(
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => array($this, 'blacklist_subscriber'),
            'permission_callback' => array($this, 'permissions_check'),
        ));
    }

    public function permissions_check()
    {
        return current_user_can('manage_options');
    }

    /* ------------------------------------------------------------------
     * Tracking (public, signed)
     * --------------------------------------------------------------- */

    /**
     * Headers shared by tracking responses: no cache anywhere, no indexing.
     */
    private function send_tracking_headers()
    {
        // Prevent LiteSpeed Cache from caching this response (official LSCache API)
        do_action('litespeed_control_set_nocache', 'tracking endpoints must not be cached');

        if (!headers_sent()) {
            header('X-LiteSpeed-Cache-Control: no-cache');
            header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
            header('Pragma: no-cache');
            header('Expires: Thu, 01 Jan 1970 00:00:00 GMT');
            header('X-Robots-Tag: noindex, nofollow');
        }
    }

    /**
     * Decode a base64url string (RFC 4648 section 5, unpadded).
     *
     * @param string $data
     * @return string Empty string on failure.
     */
    private static function base64url_decode($data)
    {
        $data = strtr((string) $data, '-_', '+/');
        $pad = strlen($data) % 4;
        if ($pad) {
            $data .= str_repeat('=', 4 - $pad);
        }
        $decoded = base64_decode($data, true);
        return (false === $decoded) ? '' : $decoded;
    }

    /**
     * Open pixel: GET /track/open?c=&s=&sig=HMAC("open|c|s")
     */
    public function track_open($request)
    {
        $campaign_id = (int) $request->get_param('c');
        $subscriber_id = (int) $request->get_param('s');
        $sig = (string) $request->get_param('sig');

        if ($campaign_id && $subscriber_id && WPNews_Security::verify('open|' . $campaign_id . '|' . $subscriber_id, $sig)) {
            WPNews_Tracker::track_open($campaign_id, $subscriber_id);
        }

        $this->send_tracking_headers();

        // Return 1x1 transparent GIF
        $img = base64_decode('R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7');
        if (!headers_sent()) {
            header('Content-Type: image/gif');
            header('Content-Length: ' . strlen($img));
        }
        echo $img;
        exit;
    }

    /**
     * Click redirect: GET /track/click?c=&s=&u=base64url(url)&sig=HMAC("click|c|s|url")
     *
     * Any http(s) destination is accepted when the signature is valid; otherwise
     * the visitor is sent to the home page.
     */
    public function track_click($request)
    {
        $campaign_id = (int) $request->get_param('c');
        $subscriber_id = (int) $request->get_param('s');
        $sig = (string) $request->get_param('sig');
        $url = self::base64url_decode((string) $request->get_param('u'));

        $valid = $campaign_id && $subscriber_id && '' !== $url
            && preg_match('#^https?://#i', $url)
            && WPNews_Security::verify('click|' . $campaign_id . '|' . $subscriber_id . '|' . $url, $sig);

        $this->send_tracking_headers();

        if ($valid) {
            WPNews_Tracker::track_click($campaign_id, $subscriber_id, $url);
            wp_redirect($url, 302); // phpcs:ignore WordPress.Security.SafeRedirect -- destination is HMAC-signed by us
            exit;
        }

        wp_safe_redirect(home_url('/'), 302);
        exit;
    }

    /* ------------------------------------------------------------------
     * Campaigns
     * --------------------------------------------------------------- */

    public function get_campaign($request)
    {
        $id = (int) $request->get_param('id');
        $campaign = WPNews_Campaign_Manager::get_campaign($id);

        if (!$campaign) {
            return new WP_Error('not_found', __('Campaign not found.', 'wp-news'), array('status' => 404));
        }

        // Cast integer fields so JavaScript doesn't treat string '0' as truthy
        $campaign['is_recurring'] = (int) ($campaign['is_recurring'] ?? 0);
        $campaign['send_if_new'] = (int) ($campaign['send_if_new'] ?? 0);

        return rest_ensure_response($campaign);
    }

    /**
     * POST /builder/duplicate/{id} -> {success:true, id:<new id>}
     */
    public function duplicate_campaign($request)
    {
        $id = (int) $request->get_param('id');
        if (!$id || !WPNews_Campaign_Manager::get_campaign($id)) {
            return new WP_Error('not_found', __('Campaign not found.', 'wp-news'), array('status' => 404));
        }

        $new_id = WPNews_Campaign_Manager::duplicate_campaign($id, 'draft');
        if (!$new_id) {
            return new WP_Error('db_error', __('Could not duplicate the campaign.', 'wp-news'), array('status' => 500));
        }

        return rest_ensure_response(array('success' => true, 'id' => (int) $new_id));
    }

    /**
     * POST /builder/preview {html} -> {html: sanitized}
     */
    public function preview_campaign($request)
    {
        $params = $request->get_json_params();
        $html = (is_array($params) && isset($params['html']) && is_string($params['html'])) ? $params['html'] : '';

        return rest_ensure_response(array(
            'html' => WPNews_Campaign_Manager::sanitize_email_html($html),
        ));
    }

    public function save_campaign($request)
    {
        try {
            $params = $request->get_json_params();
            if (!is_array($params)) {
                $params = array();
            }

            // Validation
            if (empty($params['name']) || empty($params['subject'])) {
                return new WP_Error('missing_params', __('Name and subject are required.', 'wp-news'), array('status' => 400));
            }

            // Strip paddingValues="[object Object]" JS serialization bug
            $content_raw = isset($params['content']) && is_string($params['content']) ? $params['content'] : '';
            $content_raw = preg_replace('/\s+paddingValues=&quot;[^&]*(?:&quot;)?/', '', $content_raw);
            $content_raw = preg_replace('/\s+paddingValues="[^"]*"/', '', $content_raw);

            $data = array(
                'name' => $params['name'],
                'subject' => $params['subject'],
                'content' => $content_raw,
                'blocks_json' => isset($params['blocks_json']) ? $params['blocks_json'] : '',
                'lists' => isset($params['lists']) && is_array($params['lists']) ? array_map('absint', $params['lists']) : array(),
                'status' => isset($params['status']) ? sanitize_key($params['status']) : 'draft',
                'is_recurring' => isset($params['is_recurring']) ? (int) $params['is_recurring'] : 0,
                'recurring_interval' => isset($params['recurring_interval']) ? sanitize_text_field($params['recurring_interval']) : '',
                'recurring_day' => isset($params['recurring_day']) ? sanitize_text_field($params['recurring_day']) : '',
                'send_if_new' => isset($params['send_if_new']) ? (int) $params['send_if_new'] : 0,
                'schedule_at' => isset($params['schedule_at']) ? sanitize_text_field($params['schedule_at']) : '',
            );

            if (!empty($params['id'])) {
                // Update
                $id = (int) $params['id'];
                $existing = WPNews_Campaign_Manager::get_campaign($id);
                if (!$existing) {
                    return new WP_Error('not_found', __('Campaign not found.', 'wp-news'), array('status' => 404));
                }
                if ('sent' === $existing['status']) {
                    return new WP_Error('campaign_sent', __('Sent campaigns cannot be modified.', 'wp-news'), array('status' => 409));
                }

                $ok = WPNews_Campaign_Manager::update_campaign($id, $data);
                if (!$ok) {
                    return new WP_Error('update_failed', __('The campaign could not be updated.', 'wp-news'), array('status' => 409));
                }
                return rest_ensure_response(array('success' => true, 'id' => $id));
            }

            // Create
            $id = WPNews_Campaign_Manager::create_campaign($data);
            if (!$id) {
                return new WP_Error('db_error', __('Could not create the campaign.', 'wp-news'), array('status' => 500));
            }
            return rest_ensure_response(array('success' => true, 'id' => $id));
        } catch (Throwable $e) {
            error_log('WPNEWS: save_campaign exception - ' . $e->getMessage());
            return new WP_Error('exception', __('An unexpected error occurred while saving the campaign.', 'wp-news'), array('status' => 500));
        }
    }

    /**
     * Put a campaign (and its recurring snapshot, if any) into 'sending' and
     * queue the async worker. Shared by send-now and resume.
     *
     * @param array $campaign Campaign row.
     * @param bool  $reset_counters Reset total_recipients/sent_count (fresh start).
     */
    private function queue_campaign(array $campaign, $reset_counters)
    {
        global $wpdb;
        $table = $wpdb->prefix . 'wpnews_campaigns';
        $id = (int) $campaign['id'];

        $data = array('status' => 'sending');
        $formats = array('%s');
        if ($reset_counters) {
            $data['total_recipients'] = 0;
            $data['sent_count'] = 0;
            $formats[] = '%d';
            $formats[] = '%d';
        }
        $wpdb->update($table, $data, array('id' => $id), $formats, array('%d'));

        // Recurring: wake up a stopped snapshot so the engine resumes it instead of creating a new one
        if (!empty($campaign['is_recurring'])) {
            $wpdb->query($wpdb->prepare(
                "UPDATE $table SET status = 'sending' WHERE parent_id = %d AND status = 'stopped'",
                $id
            ));
        }

        delete_transient('wpnews_stop_campaign_' . $id);
        WPNews_Campaign_Manager::schedule_next_batch($id);
    }

    /**
     * Send now: never sends inside the HTTP request. Marks the campaign as
     * 'sending', schedules `wpnews_send_campaign_async` and returns immediately.
     */
    public function send_campaign_now($request)
    {
        $params = $request->get_json_params();
        $id = (is_array($params) && isset($params['id'])) ? (int) $params['id'] : 0;

        if (!$id) {
            return new WP_Error('missing_params', __('Campaign ID is required.', 'wp-news'), array('status' => 400));
        }

        $campaign = WPNews_Campaign_Manager::get_campaign($id);
        if (!$campaign) {
            return new WP_Error('not_found', __('Campaign not found.', 'wp-news'), array('status' => 404));
        }
        if ('sent' === $campaign['status'] && empty($campaign['is_recurring'])) {
            return new WP_Error('campaign_sent', __('This campaign has already been sent.', 'wp-news'), array('status' => 409));
        }

        // Resuming a stopped/sending campaign keeps its progress; anything else starts fresh
        $reset = !in_array($campaign['status'], array('sending', 'stopped'), true);
        $this->queue_campaign($campaign, $reset);

        return rest_ensure_response(array(
            'success' => true,
            'message' => __('Sending started. The campaign is being sent in the background.', 'wp-news'),
        ));
    }

    /**
     * Stop a campaign that is currently sending.
     */
    public function stop_campaign($request)
    {
        $params = $request->get_json_params();
        $id = (is_array($params) && isset($params['id'])) ? (int) $params['id'] : 0;

        if (!$id) {
            return new WP_Error('missing_params', __('Campaign ID is required.', 'wp-news'), array('status' => 400));
        }

        // Set transient flag — the send loop checks this before each email
        set_transient('wpnews_stop_campaign_' . $id, true, 300); // 5 min TTL

        return rest_ensure_response(array(
            'success' => true,
            'message' => __('Stop signal sent. The campaign will stop after the current email.', 'wp-news'),
        ));
    }

    /**
     * Resume a stopped campaign — re-send to remaining recipients.
     */
    public function resume_campaign($request)
    {
        $params = $request->get_json_params();
        $id = (is_array($params) && isset($params['id'])) ? (int) $params['id'] : 0;

        if (!$id) {
            return new WP_Error('missing_params', __('Campaign ID is required.', 'wp-news'), array('status' => 400));
        }

        $campaign = WPNews_Campaign_Manager::get_campaign($id);
        if (!$campaign) {
            return new WP_Error('not_found', __('Campaign not found.', 'wp-news'), array('status' => 404));
        }
        if ('sent' === $campaign['status'] && empty($campaign['is_recurring'])) {
            return new WP_Error('campaign_sent', __('This campaign has already been sent.', 'wp-news'), array('status' => 409));
        }

        $this->queue_campaign($campaign, false);

        return rest_ensure_response(array(
            'success' => true,
            'message' => __('Campaign resumed. Sending to the remaining recipients.', 'wp-news'),
        ));
    }

    /**
     * Get campaign progress (for AJAX polling).
     */
    public function get_campaign_progress($request)
    {
        $id = (int) $request->get_param('id');

        if (!$id) {
            return new WP_Error('missing_params', __('Campaign ID is required.', 'wp-news'), array('status' => 400));
        }

        global $wpdb;
        $campaign_table = $wpdb->prefix . 'wpnews_campaigns';
        $campaign = $wpdb->get_row($wpdb->prepare(
            "SELECT status, total_recipients, sent_count FROM $campaign_table WHERE id = %d",
            $id
        ), ARRAY_A);

        if (!$campaign) {
            return new WP_Error('not_found', __('Campaign not found.', 'wp-news'), array('status' => 404));
        }

        $errors = WPNews_Campaign_Manager::get_error_log($id);

        return rest_ensure_response(array(
            'status' => $campaign['status'],
            'total_recipients' => (int) $campaign['total_recipients'],
            'sent_count' => (int) $campaign['sent_count'],
            'failed_count' => (int) $errors['failed_count'],
        ));
    }

    /* ------------------------------------------------------------------
     * Misc builder endpoints
     * --------------------------------------------------------------- */

    public function get_lists()
    {
        return rest_ensure_response(WPNews_List_Manager::get_lists());
    }

    public function get_theme_data()
    {
        $site_name = get_bloginfo('name');
        $site_url = home_url();

        $data = array(
            'available' => false,
            'siteName' => $site_name,
            'siteUrl' => $site_url,
            'logoUrl' => '',
            'social' => array(
                'websiteUrl' => $site_url,
                'instagramUrl' => '',
                'facebookUrl' => '',
                'linkedinUrl' => '',
            ),
        );

        if (function_exists('ticinoweb_get_contact_info')) {
            $info = ticinoweb_get_contact_info();
            if (!is_array($info)) {
                $info = array();
            }
            $data['available'] = true;
            if (function_exists('ticinoweb_get_site_logo')) {
                $data['logoUrl'] = ticinoweb_get_site_logo() ?: '';
            }

            $data['social'] = array(
                'websiteUrl' => $site_url,
                'instagramUrl' => isset($info['instagram']) ? esc_url_raw($info['instagram']) : '',
                'facebookUrl' => isset($info['facebook']) ? esc_url_raw($info['facebook']) : '',
                'linkedinUrl' => isset($info['linkedin']) ? esc_url_raw($info['linkedin']) : '',
            );
        }

        return rest_ensure_response($data);
    }

    public function create_list($request)
    {
        $params = $request->get_json_params();

        if (!is_array($params) || empty($params['name'])) {
            return new WP_Error('missing_params', __('List name is required.', 'wp-news'), array('status' => 400));
        }

        $id = WPNews_List_Manager::create_list($params['name']);

        if (!$id) {
            return new WP_Error('db_error', __('Could not create the list.', 'wp-news'), array('status' => 500));
        }

        return rest_ensure_response(array('success' => true, 'id' => $id, 'name' => sanitize_text_field($params['name'])));
    }

    public function send_test_email($request)
    {
        $params = $request->get_json_params();

        if (!is_array($params) || empty($params['email']) || empty($params['content'])) {
            return new WP_Error('missing_params', __('Email and content are required.', 'wp-news'), array('status' => 400));
        }

        $to = sanitize_email($params['email']);
        if (!is_email($to)) {
            return new WP_Error('invalid_email', __('Invalid email address.', 'wp-news'), array('status' => 400));
        }

        $subject = '[TEST] ' . sanitize_text_field(!empty($params['subject']) ? $params['subject'] : __('Newsletter preview', 'wp-news'));

        // Process shortcodes and dynamic tags for the TEST email
        $content = is_string($params['content']) ? $params['content'] : '';
        // Strip paddingValues="[object Object]" which breaks WP shortcode parser
        $content = preg_replace('/\s+paddingValues=&quot;[^&]*(?:&quot;)?/', '', $content);
        $content = preg_replace('/\s+paddingValues="[^"]*"/', '', $content);
        $decoded_content = str_replace(array('&quot;', '&#034;', '&#34;'), '"', $content);
        $parsed_content = do_shortcode($decoded_content);
        // Safety: strip any leftover "] from broken shortcode parsing
        $parsed_content = preg_replace('/"\]\s*(?=<|$)/', '', $parsed_content);

        $options = get_option('wpnews_options', array());
        $physical_address = (is_array($options) && isset($options['physical_address'])) ? trim((string) $options['physical_address']) : '';

        // For test emails, use a dummy unsubscribe URL since we don't have a real subscriber context
        $parsed_content = str_replace(
            array('{{unsubscribe_url}}', '{{physical_address}}', '{{email}}', '{{first_name}}', '{{last_name}}', '{{name}}'),
            array(
                esc_url(home_url('/?wpnews_unsubscribe=1&test=1')),
                nl2br(esc_html($physical_address)),
                esc_html($to),
                esc_html__('Test', 'wp-news'),
                esc_html__('Subscriber', 'wp-news'),
                esc_html__('Test Subscriber', 'wp-news'),
            ),
            $parsed_content
        );

        $mailer = new WPNews_Mailer();
        $result = $mailer->send_email($to, $subject, $parsed_content);

        if (empty($result['success'])) {
            $message = isset($result['message']) ? $result['message'] : __('Unknown error.', 'wp-news');
            return new WP_Error('send_error', $message, array('status' => 500));
        }

        return rest_ensure_response(array('success' => true));
    }

    /**
     * Get SNS notification configuration status for the SES identity.
     */
    public function get_sns_status($request)
    {
        $options = get_option('wpnews_options', array());
        if (!is_array($options)) {
            $options = array();
        }
        $mailer_type = isset($options['mailer_type']) ? $options['mailer_type'] : 'sendgrid';

        if ($mailer_type !== 'ses') {
            return rest_ensure_response(array(
                'success' => false,
                'message' => __('Mailer type is not set to Amazon SES.', 'wp-news'),
            ));
        }

        $ses = new WPNews_SES(
            isset($options['ses_region']) ? $options['ses_region'] : 'eu-central-1',
            isset($options['ses_access_key']) ? $options['ses_access_key'] : '',
            isset($options['ses_secret_key']) ? $options['ses_secret_key'] : ''
        );

        return rest_ensure_response($ses->get_notification_status());
    }

    /* ------------------------------------------------------------------
     * Subscribers
     * --------------------------------------------------------------- */

    /**
     * Blacklist a subscriber via email.
     */
    public function blacklist_subscriber($request)
    {
        $params = $request->get_json_params();
        $email = (is_array($params) && isset($params['email'])) ? sanitize_email($params['email']) : '';

        if (!$email || !is_email($email)) {
            return new WP_Error('invalid_email', __('Invalid email address.', 'wp-news'), array('status' => 400));
        }

        global $wpdb;
        $sub_table = $wpdb->prefix . 'wpnews_subscribers';
        $subscriber_id = $wpdb->get_var($wpdb->prepare("SELECT id FROM $sub_table WHERE email = %s", $email));

        if (!$subscriber_id) {
            return new WP_Error('not_found', __('Subscriber not found.', 'wp-news'), array('status' => 404));
        }

        $result = WPNews_List_Manager::blacklist_subscriber((int) $subscriber_id);

        if ($result) {
            return rest_ensure_response(array('success' => true));
        }

        return new WP_Error('blacklist_failed', __('Failed to blacklist the subscriber.', 'wp-news'), array('status' => 500));
    }

    /**
     * Import campaigns (history and drafts) from MailPoet.
     *
     * @param WP_REST_Request $request
     * @return WP_REST_Response|WP_Error
     */
    public function import_campaigns_from_mailpoet($request)
    {
        $result = WPNews_MailPoet_Importer::import_campaigns();

        if (!empty($result['errors']) && empty($result['imported'])) {
            return new WP_Error('import_error', implode(', ', $result['errors']), array('status' => 400));
        }

        $message = sprintf(
            /* translators: 1: campaigns imported, 2: sent campaigns (history), 3: drafts, 4: already imported before */
            __('Import completed: %1$d campaigns imported (%2$d sent, %3$d drafts), %4$d already imported before.', 'wp-news'),
            (int) $result['imported'],
            (int) $result['sent'],
            (int) $result['drafts'],
            (int) $result['already']
        );
        if (!empty($result['unsupported'])) {
            $message .= ' ' . sprintf(
                /* translators: %d: number of MailPoet blocks without an equivalent */
                __('%d MailPoet blocks (such as products or manual posts) have no equivalent and were left out.', 'wp-news'),
                array_sum($result['unsupported'])
            );
        }
        if (!empty($result['errors'])) {
            $message .= ' ' . implode(' ', $result['errors']);
        }

        return rest_ensure_response(array('success' => true, 'message' => $message, 'data' => $result));
    }

    /**
     * Import subscribers from MailPoet.
     *
     * @param WP_REST_Request $request
     * @return WP_REST_Response|WP_Error
     */
    public function import_from_mailpoet($request)
    {
        $result = WPNews_List_Manager::import_mailpoet_subscribers();

        if (!empty($result['errors'])) {
            return new WP_Error('import_error', implode(', ', $result['errors']), array('status' => 400));
        }

        return rest_ensure_response(array(
            'success' => true,
            'message' => sprintf(
                /* translators: 1: lists created, 2: subscribers imported, 3: blacklisted addresses */
                __('Import completed: %1$d lists created, %2$d subscribers imported, %3$d blacklisted.', 'wp-news'),
                (int) $result['lists_created'],
                (int) $result['subscribers_imported'],
                (int) $result['blacklisted']
            ),
            'data' => $result,
        ));
    }

    /**
     * Update a subscriber's details and list memberships.
     */
    public function update_subscriber($request)
    {
        $params = $request->get_json_params();
        $id = (is_array($params) && isset($params['id'])) ? (int) $params['id'] : 0;

        if (!$id) {
            return new WP_Error('missing_params', __('Subscriber ID is required.', 'wp-news'), array('status' => 400));
        }

        global $wpdb;
        $sub_table = $wpdb->prefix . 'wpnews_subscribers';
        $sl_table = $wpdb->prefix . 'wpnews_subscriber_lists';

        // Check subscriber exists
        $existing = $wpdb->get_row($wpdb->prepare("SELECT id FROM $sub_table WHERE id = %d", $id), ARRAY_A);
        if (!$existing) {
            return new WP_Error('not_found', __('Subscriber not found.', 'wp-news'), array('status' => 404));
        }

        // Update basic fields
        $update = array();
        $formats = array();

        if (isset($params['email'])) {
            $email = sanitize_email($params['email']);
            if (!is_email($email)) {
                return new WP_Error('invalid_email', __('Invalid email address.', 'wp-news'), array('status' => 400));
            }
            // Check uniqueness (excluding current)
            $dup = $wpdb->get_var($wpdb->prepare("SELECT id FROM $sub_table WHERE email = %s AND id != %d", $email, $id));
            if ($dup) {
                return new WP_Error('duplicate_email', __('This email address already exists.', 'wp-news'), array('status' => 400));
            }
            $update['email'] = $email;
            $formats[] = '%s';
        }

        if (isset($params['first_name'])) {
            $update['first_name'] = sanitize_text_field($params['first_name']);
            $formats[] = '%s';
        }

        if (isset($params['last_name'])) {
            $update['last_name'] = sanitize_text_field($params['last_name']);
            $formats[] = '%s';
        }

        if (isset($params['status']) && in_array($params['status'], array('active', 'unsubscribed'), true)) {
            $update['status'] = $params['status'];
            $formats[] = '%s';
        }

        if (!empty($update)) {
            $wpdb->update($sub_table, $update, array('id' => $id), $formats, array('%d'));
        }

        // Sync list memberships
        if (isset($params['list_ids']) && is_array($params['list_ids'])) {
            $new_list_ids = array_map('intval', $params['list_ids']);

            $current = $wpdb->get_col($wpdb->prepare("SELECT list_id FROM $sl_table WHERE subscriber_id = %d", $id));
            $current = array_map('intval', (array) $current);

            foreach ($new_list_ids as $lid) {
                if (!in_array($lid, $current, true)) {
                    WPNews_List_Manager::add_subscriber_to_list($id, $lid);
                }
            }
            foreach ($current as $lid) {
                if (!in_array($lid, $new_list_ids, true)) {
                    WPNews_List_Manager::remove_subscriber_from_list($id, $lid);
                }
            }
        }

        return rest_ensure_response(array('success' => true, 'id' => $id));
    }
}
