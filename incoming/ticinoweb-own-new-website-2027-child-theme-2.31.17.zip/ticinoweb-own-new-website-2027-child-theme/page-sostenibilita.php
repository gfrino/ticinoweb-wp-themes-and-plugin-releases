<?php
/**
 * Template Name: ticinoWEB — Sostenibilità
 * Pagina a tema naturale: sfondo verde con foglie e colline, contenuto modificabile dall'editor.
 *
 * Il titolo della pagina è l'H1, l'estratto è il testo introduttivo. Ogni impegno è un blocco
 * «Gruppo» con classe `tw-pillar` (e una classe icona: `tw-pillar--hosting`, `--energy`,
 * `--mobility`, `--plastic`) che contiene un titolo H2 e un paragrafo.
 */
if ( ! defined( 'ABSPATH' ) ) exit;
get_header();
while ( have_posts() ) :
	the_post();
	$tw_kicker = (string) get_post_meta( get_the_ID(), '_tw_sustain_kicker', true );
	$tw_kicker = '' !== $tw_kicker ? $tw_kicker : __( 'Il nostro impegno ambientale', 'ticinoweb-child-theme' );
	?>
<main id="main-content" class="tw-sustain">
	<section class="tw-sustain-hero">
		<svg class="tw-sustain-hero__hills" viewBox="0 0 1440 320" preserveAspectRatio="none" aria-hidden="true" focusable="false">
			<path d="M0 220 C 160 150 260 130 400 180 C 540 230 640 120 800 110 C 960 100 1080 190 1220 150 C 1320 122 1390 150 1440 170 L1440 320 L0 320 Z" fill="#17513a" opacity=".55"/>
			<path d="M0 260 C 200 200 330 215 470 245 C 640 282 760 190 930 200 C 1080 208 1210 270 1440 226 L1440 320 L0 320 Z" fill="#e9f3ec"/>
		</svg>
		<?php foreach ( array( 'a' => '6% 18%', 'b' => '88% 12%', 'c' => '78% 62%', 'd' => '12% 70%' ) as $tw_leaf => $tw_pos ) : ?>
			<svg class="tw-sustain-leaf tw-sustain-leaf--<?php echo esc_attr( $tw_leaf ); ?>" style="left:<?php echo esc_attr( explode( ' ', $tw_pos )[0] ); ?>;top:<?php echo esc_attr( explode( ' ', $tw_pos )[1] ); ?>" viewBox="0 0 64 64" aria-hidden="true" focusable="false"><path d="M8 56C8 28 26 8 56 8c0 28-16 48-44 48" fill="currentColor"/><path d="M8 56 38 26" stroke="#0f3d2e" stroke-width="2" stroke-linecap="round" fill="none" opacity=".55"/></svg>
		<?php endforeach; ?>
		<div class="tw-shell tw-sustain-hero__inner">
			<p class="tw-sustain-kicker"><?php echo esc_html( $tw_kicker ); ?></p>
			<h1><?php the_title(); ?></h1>
			<?php if ( has_excerpt() ) : ?><p class="tw-sustain-lead"><?php echo esc_html( get_the_excerpt() ); ?></p><?php endif; ?>
		</div>
	</section>

	<section class="tw-sustain-body">
		<div class="tw-shell tw-sustain-content">
			<?php the_content(); ?>
		</div>
	</section>
</main>
	<?php
endwhile;
get_footer();
