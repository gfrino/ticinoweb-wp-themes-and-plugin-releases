<?php
/**
 * Mache Pizza Child Theme – functions.php
 *
 * Enqueues parent + child assets and registers action hooks
 * that populate the parent theme's sections with pizza-themed content.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'MACHEPIZZA_VERSION', time() );

// ─── Enqueue Parent + Child Styles ───
add_action( 'wp_enqueue_scripts', 'machepizza_enqueue_assets' );
function machepizza_enqueue_assets() {
	// Parent theme CSS
	wp_enqueue_style(
		'ticinoweb-ai-parent-style',
		get_template_directory_uri() . '/style.css',
		array(),
		MACHEPIZZA_VERSION
	);

	// Google Fonts: Poppins (inherited) + Playfair Display for headings
	wp_enqueue_style(
		'machepizza-fonts',
		'https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700;900&family=Poppins:wght@300;400;500;600;700&display=swap',
		array(),
		null
	);

	// Child theme CSS
	wp_enqueue_style(
		'machepizza-style',
		get_stylesheet_directory_uri() . '/assets/css/machepizza.css',
		array( 'ticinoweb-ai-parent-style', 'machepizza-fonts' ),
		MACHEPIZZA_VERSION
	);
    
    // Child theme animations JS
	wp_enqueue_script(
		'machepizza-animations',
		get_stylesheet_directory_uri() . '/assets/js/animations.js',
		array(),
		MACHEPIZZA_VERSION,
		true
	);

	// Shop page CSS + JS (on WooCommerce shop/archive, cart, checkout)
	$is_shop_page = function_exists( 'is_woocommerce' ) && ( is_shop() || is_product_category() || is_product_tag() || is_product() );
	if ( $is_shop_page || is_cart() || is_checkout() ) {
		wp_enqueue_style(
			'machepizza-shop-style',
			get_stylesheet_directory_uri() . '/assets/css/shop.css',
			array( 'machepizza-style' ),
			time()
		);

		wp_enqueue_script(
			'machepizza-shop-js',
			get_stylesheet_directory_uri() . '/assets/js/shop-addons.js',
			array(),
			MACHEPIZZA_VERSION,
			true
		);
	}
}

// ─── Custom Shop Scripts ───
add_action( 'wp_enqueue_scripts', 'machepizza_shop_assets' );
function machepizza_shop_assets() {
    if ( is_shop() || is_product_category() || is_product_taxonomy() || is_post_type_archive('product') ) {
        wp_enqueue_script( 'wc-add-to-cart-variation' );
        wp_enqueue_script( 'machepizza-shop-core-js', get_stylesheet_directory_uri() . '/assets/js/shop.js', array('jquery'), time(), true );
        wp_localize_script( 'machepizza-shop-core-js', 'machepizza_ajax', array(
            'ajax_url' => admin_url( 'admin-ajax.php' )
        ));
    }
}

// ─── Quick Order Panel AJAX ───
add_action( 'wp_ajax_mp_quick_order_form', 'mp_ajax_quick_order_form' );
add_action( 'wp_ajax_nopriv_mp_quick_order_form', 'mp_ajax_quick_order_form' );
function mp_ajax_quick_order_form() {
    if ( ! isset( $_POST['product_id'] ) ) {
        wp_send_json_error( 'Nessun ID prodotto fornito.' );
    }

    $product_id = intval( $_POST['product_id'] );
    $product = wc_get_product( $product_id );

    if ( ! $product ) {
        wp_send_json_error( 'Prodotto non trovato.' );
    }

    global $post;
    $post = get_post( $product_id );
    setup_postdata( $post );

    ob_start();
    ?>
    <div class="mp-qop-product-info">
        <?php if ( $product->get_image_id() ) : ?>
            <div class="mp-qop-img">
                <?php echo $product->get_image('medium'); ?>
            </div>
        <?php endif; ?>
        <div class="mp-qop-details">
            <h2 class="mp-qop-product-title"><?php echo esc_html( $product->get_name() ); ?></h2>
            <div class="mp-qop-price"><?php echo $product->get_price_html(); ?></div>
            <div class="mp-qop-excerpt"><?php echo apply_filters( 'woocommerce_short_description', $product->get_short_description() ); ?></div>
        </div>
    </div>
    <div class="mp-qop-form-wrapper">
        <?php
        if ( $product->is_type( 'variable' ) ) {
            woocommerce_variable_add_to_cart();
        } else {
            woocommerce_simple_add_to_cart();
        }
        ?>
    </div>
    <?php
    wp_reset_postdata();
    $html = ob_get_clean();
    wp_send_json_success( $html );
}

// ─── Opening Hours Helper ───
function machepizza_get_opening_hours() {
	$cms_hours = get_option('ticinoweb_contact_opening_hours', array());
	
	// Fallback se il CMS è vuoto
	if ( empty( $cms_hours ) || ! is_array( $cms_hours ) ) {
		return array(
			array( 'day' => 'Lunedì',    'hours' => 'Chiuso' ),
			array( 'day' => 'Martedì',   'hours' => '11:30–14:00, 17:30–21:30' ),
			array( 'day' => 'Mercoledì', 'hours' => '11:30–14:00, 17:30–21:30' ),
			array( 'day' => 'Giovedì',   'hours' => '11:30–14:00, 17:30–21:30' ),
			array( 'day' => 'Venerdì',   'hours' => '11:30–14:00, 17:30–21:30' ),
			array( 'day' => 'Sabato',    'hours' => '11:30–14:00, 17:30–21:30' ),
			array( 'day' => 'Domenica',  'hours' => '11:30–14:00, 17:30–21:30' ),
		);
	}

	$days_map = array(
		'monday'    => 'Lunedì',
		'tuesday'   => 'Martedì',
		'wednesday' => 'Mercoledì',
		'thursday'  => 'Giovedì',
		'friday'    => 'Venerdì',
		'saturday'  => 'Sabato',
		'sunday'    => 'Domenica',
	);

	$formatted_hours = array();

	foreach ( $days_map as $key => $label ) {
		$day_data = isset( $cms_hours[$key] ) ? $cms_hours[$key] : array();
		
		if ( isset( $day_data['closed'] ) && $day_data['closed'] ) {
			$formatted_hours[] = array( 'day' => $label, 'hours' => 'Chiuso' );
		} else {
			$slots = isset( $day_data['slots'] ) && is_array( $day_data['slots'] ) ? $day_data['slots'] : array();
			$slots_strings = array();
			foreach ( $slots as $slot ) {
				if ( ! empty( $slot['open'] ) && ! empty( $slot['close'] ) ) {
					// Rimuovi i secondi se presenti (es. 11:30:00 -> 11:30)
					$open = substr($slot['open'], 0, 5);
					$close = substr($slot['close'], 0, 5);
					$slots_strings[] = $open . '–' . $close;
				}
			}
			$hours_str = ! empty( $slots_strings ) ? implode( ', ', $slots_strings ) : 'Chiuso';
			$formatted_hours[] = array( 'day' => $label, 'hours' => $hours_str );
		}
	}

	return $formatted_hours;
}

// ─── Footer Links Hook (parent theme: ticinoweb_footer_links) ───
add_action( 'ticinoweb_footer_links', 'machepizza_footer_links' );
function machepizza_footer_links() {
	$menu_link = home_url( '/menu/' );
	$shop_link = home_url( '/shop/' );
	?>
	<li><a href="<?php echo esc_url( $shop_link ); ?>">Menu & Ordini</a></li>
	<li><a href="<?php echo esc_url( home_url( '/#chi-siamo' ) ); ?>">Chi Siamo</a></li>
	<li><a href="<?php echo esc_url( home_url( '/#contatti' ) ); ?>">Contatti</a></li>
	<?php
}

// ─── Footer Brand Description Hook ───
add_action( 'ticinoweb_footer_brand_description', 'machepizza_footer_brand_desc' );
function machepizza_footer_brand_desc() {
	echo '<p class="footer-brand-desc">La tua pizza artigianale, consegnata calda a domicilio.</p>';
}

// ─── CTA Section Hook (parent: ticinoweb_cta_section) ───
add_action( 'ticinoweb_cta_section', 'machepizza_cta_section' );
function machepizza_cta_section() {
	get_template_part( 'template-parts/cta-section' );
}

// ─── About Section Hook (parent: ticinoweb_about_section) ───
add_action( 'ticinoweb_about_section', 'machepizza_about_section' );
function machepizza_about_section() {
	get_template_part( 'template-parts/features-section' );
}

// ─── Custom AJAX Add to Cart for Products with Addons ───
add_action( 'wc_ajax_machepizza_add_to_cart', 'machepizza_custom_ajax_add_to_cart' );

function machepizza_custom_ajax_add_to_cart() {
	if ( isset(WC()->session) && ! WC()->session->has_session() ) {
		WC()->session->set_customer_session_cookie( true );
	}
	ob_start();

	if ( ! isset( $_POST['product_id'] ) ) {
		wp_send_json_error( 'No product id' );
	}

	$product_id        = apply_filters( 'woocommerce_add_to_cart_product_id', absint( $_POST['product_id'] ) );
	$product           = wc_get_product( $product_id );
	$quantity          = empty( $_POST['quantity'] ) ? 1 : wc_stock_amount( wp_unslash( $_POST['quantity'] ) );
	
	// DEBUG LOG
	error_log("MACHEPIZZA ADD_TO_CART AJAX: product_id=$product_id, POST quantity=" . print_r($_POST['quantity'], true) . ", final quantity=$quantity");

	$passed_validation = apply_filters( 'woocommerce_add_to_cart_validation', true, $product_id, $quantity );
	$product_status    = get_post_status( $product_id );

	$variation_id = isset( $_POST['variation_id'] ) ? absint( $_POST['variation_id'] ) : 0;
	$variation    = array();

	if ( $product && $product->is_type( 'variation' ) ) {
		$variation_id = $product_id;
		$product_id   = $product->get_parent_id();
		$variation    = $product->get_variation_attributes();
	} elseif ( $variation_id > 0 ) {
		foreach ( $_POST as $key => $val ) {
			if ( strpos( $key, 'attribute_' ) === 0 ) {
				$variation[ $key ] = wp_unslash( $val );
			}
		}
	}

	if ( $passed_validation && false !== WC()->cart->add_to_cart( $product_id, $quantity, $variation_id, $variation ) && 'publish' === $product_status ) {
		do_action( 'woocommerce_ajax_added_to_cart', $product_id );

		// Svuotiamo le notifiche di WooCommerce per evitare che si accumulino 
		// "Prodotto aggiunto" visibili poi nella pagina cassa, dato che usiamo l'interfaccia personalizzata.
		wc_clear_notices();

		// FORZA IL SALVATAGGIO DELLA SESSIONE NEL DB PRIMA DI USCIRE!
		if ( isset( WC()->session ) ) {
			WC()->session->save_data();
		}

		WC_AJAX::get_refreshed_fragments();
	} else {
		// Validazione fallita o add to cart fallito
		$data = array(
			'error'       => true,
			'product_url' => apply_filters( 'woocommerce_cart_redirect_after_error', get_permalink( $product_id ), $product_id ),
		);
		wp_send_json( $data );
	}
	die();
}

// ─── Rimuovi definitivamente i messaggi nativi "Aggiunto al carrello" ───
// Poiché usiamo il carrello laterale e animazioni sui bottoni come feedback visivo,
// evitiamo che si accumulino decine di banner verdi nella pagina Cassa.
add_filter( 'wc_add_to_cart_message_html', '__return_false' );
add_action( 'woocommerce_add_to_cart', 'machepizza_clear_cart_notices', 99 );
function machepizza_clear_cart_notices() {
    $notices = WC()->session->get( 'wc_notices', array() );
    if ( isset( $notices['success'] ) ) {
        unset( $notices['success'] );
        WC()->session->set( 'wc_notices', $notices );
    }
}

// ─── Integrazione Sottomenu App in ticinoWEB CMS ───
add_action('admin_menu', 'machepizza_add_app_submenu', 40);
function machepizza_add_app_submenu() {
    add_submenu_page(
        'ticinoweb-cms',
        'App Mache Pizza',
        'App Mache Pizza',
        'edit_pages',
        'ticinoweb-app',
        'machepizza_app_settings_page'
    );
    
    // Nuovo sottomenu per impostazioni Shop/Menu
    add_submenu_page(
        'ticinoweb-cms',
        'Menu PDF / Shop',
        'Menu PDF / Shop',
        'edit_pages',
        'ticinoweb-shop-settings',
        'machepizza_shop_settings_page'
    );
}

// ----------------------------------------------------
// IMPOSTAZIONI SHOP / MENU PDF
// ----------------------------------------------------
add_action('admin_init', 'machepizza_register_shop_settings');
function machepizza_register_shop_settings() {
    register_setting('machepizza_shop_settings_group', 'machepizza_downloadable_menu_link', 'esc_url_raw');
}

function machepizza_shop_settings_page() {
    if (!current_user_can('edit_pages')) {
        wp_die(__('Permessi insufficienti.', 'machepizza'));
    }
    ?>
    <div class="wrap">
        <h1>Impostazioni Shop & Menu</h1>
        <p>Configura elementi aggiuntivi per la pagina del menu/shop.</p>
        <form method="post" action="options.php">
            <?php
            settings_fields('machepizza_shop_settings_group');
            do_settings_sections('machepizza_shop_settings_group');
            
            $menu_link = get_option('machepizza_downloadable_menu_link', '');
            ?>
            <table class="form-table">
                <tr>
                    <th scope="row">File menu scaricabile (PDF o Immagine)</th>
                    <td>
                        <input type="text" name="machepizza_downloadable_menu_link" value="<?php echo esc_attr($menu_link); ?>" class="regular-text" style="width: 100%;">
                        <p class="description">Inserisci l'URL del file menu completo (PDF o immagine). Verrà mostrato come pulsante "Scarica/Apri il menu" all'inizio dello shop. Lascia vuoto per nasconderlo.</p>
                    </td>
                </tr>
            </table>
            <?php submit_button(); ?>
        </form>
    </div>
    <?php
}

// ----------------------------------------------------
// METABOX: PDF MENU NELLA HOMEPAGE
// ----------------------------------------------------
add_action('admin_enqueue_scripts', 'machepizza_enqueue_media_for_home');
function machepizza_enqueue_media_for_home($hook) {
    if ($hook == 'post.php' || $hook == 'post-new.php') {
        wp_enqueue_media();
    }
}

add_action('add_meta_boxes', 'machepizza_add_home_menu_meta_box');
function machepizza_add_home_menu_meta_box() {
    $post_id = isset($_GET['post']) ? $_GET['post'] : (isset($_POST['post_ID']) ? $_POST['post_ID'] : 0);
    if (empty($post_id)) return;
    
    if (get_option('page_on_front') == $post_id) {
        add_meta_box(
            'machepizza_home_menu_meta_box',
            '🍕 Menu Download (PDF o Immagine)',
            'machepizza_home_menu_meta_box_html',
            'page',
            'normal',
            'high'
        );
    }
}

function machepizza_home_menu_meta_box_html($post) {
    // Recupera l'URL dal post meta (o dall'opzione globale come fallback)
    $value = get_post_meta($post->ID, '_machepizza_home_menu_pdf', true);
    if (empty($value)) {
        $value = get_option('machepizza_downloadable_menu_link', '');
    }
    
    wp_nonce_field('machepizza_home_menu_nonce_action', 'machepizza_home_menu_nonce');
    ?>
    <p>
        <label for="machepizza_home_menu_pdf"><strong>Carica il file del Menu</strong> che gli utenti potranno scaricare dal bottone nella Homepage (e nello Shop).</label>
    </p>
    <div style="display: flex; gap: 10px; align-items: center; margin-top: 15px;">
        <input type="text" id="machepizza_home_menu_pdf" name="machepizza_home_menu_pdf" value="<?php echo esc_attr($value); ?>" style="width: 100%; max-width: 500px;" placeholder="https://...">
        <button type="button" class="button button-primary" id="machepizza_home_menu_upload_btn">Seleziona / Carica PDF</button>
    </div>
    <p class="description" style="margin-top:10px;">Clicca su "Seleziona / Carica PDF" per caricare un nuovo menu dal tuo computer o sceglierlo dalla libreria media.</p>
    
    <script>
    jQuery(document).ready(function($){
        var mediaUploader;
        $('#machepizza_home_menu_upload_btn').click(function(e) {
            e.preventDefault();
            if (mediaUploader) {
                mediaUploader.open();
                return;
            }
            mediaUploader = wp.media.frames.file_frame = wp.media({
                title: 'Seleziona il Menu (PDF o Immagine)',
                button: { text: 'Usa questo file come Menu' },
                multiple: false
            });
            mediaUploader.on('select', function() {
                var attachment = mediaUploader.state().get('selection').first().toJSON();
                $('#machepizza_home_menu_pdf').val(attachment.url);
            });
            mediaUploader.open();
        });
    });
    </script>
    <?php
}

add_action('save_post', 'machepizza_save_home_menu_meta_box');
function machepizza_save_home_menu_meta_box($post_id) {
    if (!isset($_POST['machepizza_home_menu_nonce']) || !wp_verify_nonce($_POST['machepizza_home_menu_nonce'], 'machepizza_home_menu_nonce_action')) {
        return;
    }
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
    if (!current_user_can('edit_page', $post_id)) return;
    
    if (isset($_POST['machepizza_home_menu_pdf'])) {
        $menu_url = esc_url_raw($_POST['machepizza_home_menu_pdf']);
        update_post_meta($post_id, '_machepizza_home_menu_pdf', $menu_url);
        
        // Sincronizza con l'opzione globale così si aggiorna anche nello Shop!
        update_option('machepizza_downloadable_menu_link', $menu_url);
    }
}
add_action('admin_init', 'machepizza_register_app_settings');
function machepizza_register_app_settings() {
    register_setting('machepizza_app_settings_group', 'machepizza_app_enabled', 'absint');
    register_setting('machepizza_app_settings_group', 'machepizza_app_ios_link', 'esc_url_raw');
    register_setting('machepizza_app_settings_group', 'machepizza_app_android_link', 'esc_url_raw');
    register_setting('machepizza_app_settings_group', 'machepizza_app_badge_text', 'sanitize_text_field');
    register_setting('machepizza_app_settings_group', 'machepizza_app_popup_title', 'sanitize_text_field');
    register_setting('machepizza_app_settings_group', 'machepizza_app_popup_desc', 'sanitize_textarea_field');
    register_setting('machepizza_app_settings_group', 'machepizza_app_popup_btn', 'sanitize_text_field');
}

function machepizza_app_settings_page() {
    if (!current_user_can('edit_pages')) {
        wp_die(__('Permessi insufficienti.', 'machepizza'));
    }
    ?>
    <div class="wrap">
        <h1>Impostazioni App Mache Pizza</h1>
        <p>Configura il badge e il pannello per promuovere l'applicazione mobile del sito.</p>
        <form method="post" action="options.php">
            <?php
            settings_fields('machepizza_app_settings_group');
            do_settings_sections('machepizza_app_settings_group');
            
            $enabled = get_option('machepizza_app_enabled', 1);
            ?>
            <table class="form-table">
                <tr>
                    <th scope="row">Mostra Badge App</th>
                    <td>
                        <label>
                            <input type="checkbox" name="machepizza_app_enabled" value="1" <?php checked(1, $enabled); ?>>
                            Attiva il badge in basso a sinistra e il pannello interattivo.
                        </label>
                    </td>
                </tr>
                <tr>
                    <th scope="row">Link App Store (iOS)</th>
                    <td>
                        <input type="url" name="machepizza_app_ios_link" value="<?php echo esc_attr(get_option('machepizza_app_ios_link')); ?>" class="regular-text" placeholder="https://apps.apple.com/...">
                    </td>
                </tr>
                <tr>
                    <th scope="row">Link Google Play (Android)</th>
                    <td>
                        <input type="url" name="machepizza_app_android_link" value="<?php echo esc_attr(get_option('machepizza_app_android_link')); ?>" class="regular-text" placeholder="https://play.google.com/...">
                        <p class="description">Lascia i campi vuoti se l'app non è ancora pronta (i pulsanti mostreranno "Disponibile a breve").</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">Testo nel Badge</th>
                    <td>
                        <input type="text" name="machepizza_app_badge_text" value="<?php echo esc_attr(get_option('machepizza_app_badge_text', 'Scarica l\'App')); ?>" class="regular-text">
                    </td>
                </tr>
                <tr>
                    <th scope="row">Titolo Pannello</th>
                    <td>
                        <input type="text" name="machepizza_app_popup_title" value="<?php echo esc_attr(get_option('machepizza_app_popup_title', 'Scarica l\'app Mache Pizza')); ?>" class="regular-text">
                    </td>
                </tr>
                <tr>
                    <th scope="row">Descrizione Pannello</th>
                    <td>
                        <textarea name="machepizza_app_popup_desc" rows="4" class="large-text"><?php echo esc_textarea(get_option('machepizza_app_popup_desc', "Ordina più velocemente e tieni d'occhio il tuo ordine. La tua pizza preferita sempre a portata di mano.")); ?></textarea>
                    </td>
                </tr>
                <tr>
                    <th scope="row">Testo Bottone Download</th>
                    <td>
                        <input type="text" name="machepizza_app_popup_btn" value="<?php echo esc_attr(get_option('machepizza_app_popup_btn', 'Scarica ora')); ?>" class="regular-text">
                    </td>
                </tr>
            </table>
            <?php submit_button(); ?>
        </form>
    </div>
    <?php
}

// ----------------------------------------------------
// METABOX: VIDEO NELLA PAGINA STORIA (CHI SIAMO)
// ----------------------------------------------------
add_action('add_meta_boxes', 'machepizza_add_chisiamo_video_meta_box');
function machepizza_add_chisiamo_video_meta_box() {
    $post_id = isset($_GET['post']) ? $_GET['post'] : (isset($_POST['post_ID']) ? $_POST['post_ID'] : 0);
    if (empty($post_id)) return;
    
    // Controlla se il template è page-chi-siamo.php
    $template = get_page_template_slug($post_id);
    if ($template == 'page-chi-siamo.php') {
        add_meta_box(
            'machepizza_chisiamo_video_meta_box',
            '🎥 Video Atmosfera (Sfondo)',
            'machepizza_chisiamo_video_meta_box_html',
            'page',
            'normal',
            'high'
        );
    }
}

function machepizza_chisiamo_video_meta_box_html($post) {
    $value = get_post_meta($post->ID, '_machepizza_chisiamo_video_url', true);
    if (empty($value)) {
        // Fallback al video predefinito
        $value = get_option('ticinoweb_chi_siamo_video', 'https://player.vimeo.com/external/530263654.hd.mp4?s=d001614ba635bb36d7f8d689255be5530ef0fc81&profile_id=175&oauth2_token_id=57447761');
    }
    
    wp_nonce_field('machepizza_chisiamo_video_nonce_action', 'machepizza_chisiamo_video_nonce');
    ?>
    <p>
        <label for="machepizza_chisiamo_video_url"><strong>Carica o inserisci l'URL del video</strong> che farà da sfondo nella pagina Storia (Chi Siamo).</label>
    </p>
    <div style="display: flex; gap: 10px; align-items: center; margin-top: 15px;">
        <input type="text" id="machepizza_chisiamo_video_url" name="machepizza_chisiamo_video_url" value="<?php echo esc_attr($value); ?>" style="width: 100%; max-width: 500px;" placeholder="https://...">
        <button type="button" class="button button-primary" id="machepizza_chisiamo_video_upload_btn">Seleziona / Carica Video</button>
    </div>
    <p class="description" style="margin-top:10px;">Clicca su "Seleziona / Carica Video" per usare un video dalla libreria media. Si consiglia un video in formato MP4 (sotto i 5MB).</p>
    
    <script>
    jQuery(document).ready(function($){
        var mediaUploaderVideo;
        $('#machepizza_chisiamo_video_upload_btn').click(function(e) {
            e.preventDefault();
            if (mediaUploaderVideo) {
                mediaUploaderVideo.open();
                return;
            }
            mediaUploaderVideo = wp.media.frames.file_frame = wp.media({
                title: 'Seleziona il Video (MP4)',
                button: { text: 'Usa questo video' },
                multiple: false,
                library: { type: 'video' }
            });
            mediaUploaderVideo.on('select', function() {
                var attachment = mediaUploaderVideo.state().get('selection').first().toJSON();
                $('#machepizza_chisiamo_video_url').val(attachment.url);
            });
            mediaUploaderVideo.open();
        });
    });
    </script>
    <?php
}

add_action('save_post', 'machepizza_save_chisiamo_video_meta_box');
function machepizza_save_chisiamo_video_meta_box($post_id) {
    if (!isset($_POST['machepizza_chisiamo_video_nonce']) || !wp_verify_nonce($_POST['machepizza_chisiamo_video_nonce'], 'machepizza_chisiamo_video_nonce_action')) {
        return;
    }
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
    if (!current_user_can('edit_page', $post_id)) return;
    
    if (isset($_POST['machepizza_chisiamo_video_url'])) {
        $video_url = esc_url_raw($_POST['machepizza_chisiamo_video_url']);
        update_post_meta($post_id, '_machepizza_chisiamo_video_url', $video_url);
        
        // Sincronizza anche con l'opzione globale se necessario
        update_option('ticinoweb_chi_siamo_video', $video_url);
    }
}

// ─── Dynamic Interception for /app Link ───
add_action( 'template_redirect', 'machepizza_app_redirect', 5 );
function machepizza_app_redirect() {
    if ( isset( $_SERVER['REQUEST_URI'] ) ) {
        $home_path = trim( parse_url( home_url(), PHP_URL_PATH ), '/' );
        $request_path = trim( parse_url( $_SERVER['REQUEST_URI'], PHP_URL_PATH ), '/' );

        // Remove home subdirectory prefix on local/staging environments
        if ( ! empty( $home_path ) && strpos( $request_path, $home_path ) === 0 ) {
            $request_path = trim( substr( $request_path, strlen( $home_path ) ), '/' );
        }

        if ( strtolower( $request_path ) === 'app' ) {
            $ios_link = get_option('machepizza_app_ios_link', '');
            $android_link = get_option('machepizza_app_android_link', '');

            // Sanitize settings text/trailing metadata if any
            if ( ! empty( $ios_link ) ) {
                $ios_link = trim( explode( ' ', $ios_link )[0] );
            }
            if ( ! empty( $android_link ) ) {
                $android_link = trim( explode( ' ', $android_link )[0] );
            }

            $user_agent = isset( $_SERVER['HTTP_USER_AGENT'] ) ? $_SERVER['HTTP_USER_AGENT'] : '';

            if ( preg_match( '/iphone|ipad|ipod/i', $user_agent ) && ! empty( $ios_link ) ) {
                wp_redirect( $ios_link, 302 );
                exit;
            } elseif ( preg_match( '/android/i', $user_agent ) && ! empty( $android_link ) ) {
                wp_redirect( $android_link, 302 );
                exit;
            } else {
                // Desktop: redirect to home and open the app download panel
                wp_redirect( home_url( '/?show-app=1' ), 302 );
                exit;
            }
        }
    }
}

