<?php
/** Scheduled homepage announcement without CTA. */

if ( ! defined( 'ABSPATH' ) || ! function_exists( 'oasi_home_announcement_is_active' ) || ! oasi_home_announcement_is_active() ) {
	return;
}

$announcement = oasi_get_home_announcement();
?>
<section class="oasi-home-announcement" aria-labelledby="oasi-home-announcement-title">
	<div class="oasi-container">
		<div class="oasi-home-announcement__layout">
			<div class="oasi-home-announcement__media">
				<?php
				echo wp_get_attachment_image(
					$announcement['image_id'],
					'large',
					false,
					array(
						'class'    => 'oasi-home-announcement__image',
						'loading'  => 'lazy',
						'decoding' => 'async',
						'alt'      => '',
					)
				);
				?>
			</div>
			<div class="oasi-home-announcement__content">
				<h2 id="oasi-home-announcement-title"><?php echo esc_html( $announcement['title'] ); ?></h2>
				<p><?php echo nl2br( esc_html( $announcement['description'] ) ); ?></p>
			</div>
		</div>
	</div>
</section>
