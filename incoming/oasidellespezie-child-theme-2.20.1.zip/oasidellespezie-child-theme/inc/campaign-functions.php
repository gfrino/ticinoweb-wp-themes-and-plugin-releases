<?php
/** Scheduled popup and homepage announcement controls. */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function oasi_popup_campaign_defaults(): array {
	return array(
		'enabled'      => 0,
		'start_at'     => '',
		'end_at'       => '',
		'button_label' => 'Scopri di più',
		'delay_ms'     => 900,
	);
}

function oasi_home_announcement_defaults(): array {
	return array(
		'enabled'     => 0,
		'start_at'    => '',
		'end_at'      => '',
		'title'       => '',
		'description' => '',
		'image_id'    => 0,
	);
}

/** Keep a valid datetime-local value in the WordPress timezone. */
function oasi_campaign_sanitize_datetime( $value ): string {
	$value = sanitize_text_field( (string) $value );
	if ( '' === $value ) {
		return '';
	}

	$date   = DateTimeImmutable::createFromFormat( '!Y-m-d\TH:i', $value, wp_timezone() );
	$errors = DateTimeImmutable::getLastErrors();
	if ( false === $date || ( is_array( $errors ) && ( $errors['warning_count'] || $errors['error_count'] ) ) ) {
		return '';
	}

	return $date->format( 'Y-m-d\TH:i' );
}

function oasi_campaign_sanitize_window( array $value ): array {
	$value['start_at'] = oasi_campaign_sanitize_datetime( $value['start_at'] ?? '' );
	$value['end_at']   = oasi_campaign_sanitize_datetime( $value['end_at'] ?? '' );

	if ( '' !== $value['start_at'] && '' !== $value['end_at'] && $value['end_at'] < $value['start_at'] ) {
		$value['end_at'] = '';
		add_settings_error(
			'oasi_campaign_settings',
			'oasi_campaign_end_before_start',
			__( 'La data di fine era precedente alla data di inizio ed è stata rimossa. Inseriscila di nuovo se necessaria.', 'oasidellespezie-child-theme' ),
			'warning'
		);
	}

	return $value;
}

function oasi_popup_campaign_sanitize( $value ): array {
	$value = is_array( $value ) ? $value : array();
	$value = oasi_campaign_sanitize_window( $value );

	return array(
		'enabled'      => empty( $value['enabled'] ) ? 0 : 1,
		'start_at'     => $value['start_at'],
		'end_at'       => $value['end_at'],
		'button_label' => sanitize_text_field( $value['button_label'] ?? '' ),
		'delay_ms'     => min( 5000, max( 0, absint( $value['delay_ms'] ?? 900 ) ) ),
	);
}

function oasi_home_announcement_sanitize( $value ): array {
	$value = is_array( $value ) ? $value : array();
	$value = oasi_campaign_sanitize_window( $value );

	return array(
		'enabled'     => empty( $value['enabled'] ) ? 0 : 1,
		'start_at'    => $value['start_at'],
		'end_at'      => $value['end_at'],
		'title'       => sanitize_text_field( $value['title'] ?? '' ),
		'description' => sanitize_textarea_field( $value['description'] ?? '' ),
		'image_id'    => absint( $value['image_id'] ?? 0 ),
	);
}

function oasi_get_popup_campaign(): array {
	$saved = get_option( 'oasi_popup_campaign', array() );
	return oasi_popup_campaign_sanitize( array_replace( oasi_popup_campaign_defaults(), is_array( $saved ) ? $saved : array() ) );
}

function oasi_get_home_announcement(): array {
	$saved = get_option( 'oasi_home_announcement', array() );
	return oasi_home_announcement_sanitize( array_replace( oasi_home_announcement_defaults(), is_array( $saved ) ? $saved : array() ) );
}

/** Determine whether an enabled campaign is inside its configured window. */
function oasi_campaign_is_in_window( array $campaign, ?DateTimeImmutable $now = null ): bool {
	if ( empty( $campaign['enabled'] ) ) {
		return false;
	}

	$timezone = wp_timezone();
	$now      = $now ? $now->setTimezone( $timezone ) : new DateTimeImmutable( 'now', $timezone );
	$start    = oasi_campaign_sanitize_datetime( $campaign['start_at'] ?? '' );
	$end      = oasi_campaign_sanitize_datetime( $campaign['end_at'] ?? '' );

	if ( '' !== $start ) {
		$start_date = DateTimeImmutable::createFromFormat( '!Y-m-d\TH:i', $start, $timezone );
		if ( $start_date && $now < $start_date ) {
			return false;
		}
	}

	if ( '' !== $end ) {
		$end_date = DateTimeImmutable::createFromFormat( '!Y-m-d\TH:i', $end, $timezone );
		if ( $end_date && $now > $end_date ) {
			return false;
		}
	}

	return true;
}

function oasi_campaign_popup_content(): array {
	return array(
		'title' => trim( (string) get_option( 'ticinoweb_promozioni_title', '' ) ),
		'text'  => trim( (string) get_option( 'ticinoweb_promozioni_text', '' ) ),
		'image' => trim( (string) get_option( 'ticinoweb_promozioni_image', '' ) ),
		'link'  => trim( (string) get_option( 'ticinoweb_promozioni_link', '' ) ),
	);
}

function oasi_home_announcement_is_active(): bool {
	$campaign = oasi_get_home_announcement();
	return oasi_campaign_is_in_window( $campaign )
		&& '' !== $campaign['title']
		&& '' !== $campaign['description']
		&& $campaign['image_id'] > 0
		&& (bool) wp_get_attachment_image_url( $campaign['image_id'], 'large' );
}

function oasi_campaign_should_show_popup(): bool {
	if ( is_admin() || is_feed() || is_robots() || is_404() ) {
		return false;
	}

	if ( function_exists( 'oasi_maintenance_should_render' ) && oasi_maintenance_should_render() ) {
		return false;
	}

	if ( ( function_exists( 'is_cart' ) && is_cart() ) || ( function_exists( 'is_checkout' ) && is_checkout() ) || ( function_exists( 'is_account_page' ) && is_account_page() ) ) {
		return false;
	}

	global $pagenow;
	if ( 'wp-login.php' === $pagenow ) {
		return false;
	}

	$content = oasi_campaign_popup_content();
	return oasi_campaign_is_in_window( oasi_get_popup_campaign() ) && '' !== $content['title'] && '' !== $content['text'];
}

function oasi_campaign_popup_config(): array {
	$campaign = oasi_get_popup_campaign();
	$content  = oasi_campaign_popup_content();
	$version  = hash( 'sha256', wp_json_encode( array( $campaign, $content ) ) );

	return array(
		'delay'      => (int) $campaign['delay_ms'],
		'sessionKey' => 'oasi_popup_' . substr( $version, 0, 16 ),
	);
}

function oasi_campaign_render_popup(): void {
	if ( ! oasi_campaign_should_show_popup() ) {
		return;
	}

	$campaign = oasi_get_popup_campaign();
	$content  = oasi_campaign_popup_content();
	?>
	<div class="oasi-site-popup" id="oasi-site-popup" hidden data-oasi-site-popup>
		<div class="oasi-site-popup__backdrop" data-oasi-popup-close></div>
		<section class="oasi-site-popup__dialog<?php echo '' !== $content['image'] ? ' has-image' : ' has-no-image'; ?>" role="dialog" aria-modal="true" aria-labelledby="oasi-site-popup-title" aria-describedby="oasi-site-popup-description" tabindex="-1">
			<button type="button" class="oasi-site-popup__close" data-oasi-popup-close aria-label="<?php esc_attr_e( 'Chiudi annuncio', 'oasidellespezie-child-theme' ); ?>">
				<svg viewBox="0 0 24 24" width="22" height="22" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>
			</button>
			<?php if ( '' !== $content['image'] ) : ?>
				<div class="oasi-site-popup__media"><img src="<?php echo esc_url( $content['image'] ); ?>" alt="" loading="lazy" decoding="async"></div>
			<?php endif; ?>
			<div class="oasi-site-popup__content">
				<h2 id="oasi-site-popup-title"><?php echo esc_html( $content['title'] ); ?></h2>
				<p id="oasi-site-popup-description"><?php echo nl2br( esc_html( $content['text'] ) ); ?></p>
				<?php if ( '' !== $content['link'] && '' !== $campaign['button_label'] ) : ?>
					<a class="oasi-site-popup__action" href="<?php echo esc_url( $content['link'] ); ?>"><?php echo esc_html( $campaign['button_label'] ); ?></a>
				<?php endif; ?>
			</div>
		</section>
	</div>
	<?php
}
// WordPress prints footer scripts at priority 20; the dialog must exist first.
add_action( 'wp_footer', 'oasi_campaign_render_popup', 10 );

function oasi_campaign_flush_cache( $old_value, $new_value ): void {
	if ( $old_value === $new_value ) {
		return;
	}
	if ( class_exists( 'Twtr_Cache' ) ) {
		Twtr_Cache::purge_all();
	} else {
		do_action( 'litespeed_purge_all' );
	}
}
add_action( 'update_option_oasi_home_announcement', 'oasi_campaign_flush_cache', 10, 2 );
add_action( 'update_option_oasi_popup_campaign', 'oasi_campaign_flush_cache', 10, 2 );
add_action( 'update_option_ticinoweb_promozioni_title', 'oasi_campaign_flush_cache', 10, 2 );
add_action( 'update_option_ticinoweb_promozioni_text', 'oasi_campaign_flush_cache', 10, 2 );
add_action( 'update_option_ticinoweb_promozioni_image', 'oasi_campaign_flush_cache', 10, 2 );
add_action( 'update_option_ticinoweb_promozioni_link', 'oasi_campaign_flush_cache', 10, 2 );

function oasi_campaign_register_settings(): void {
	register_setting( 'oasi_campaign_settings', 'oasi_popup_campaign', array( 'type' => 'array', 'default' => oasi_popup_campaign_defaults(), 'sanitize_callback' => 'oasi_popup_campaign_sanitize' ) );
	register_setting( 'oasi_campaign_settings', 'oasi_home_announcement', array( 'type' => 'array', 'default' => oasi_home_announcement_defaults(), 'sanitize_callback' => 'oasi_home_announcement_sanitize' ) );
	register_setting( 'oasi_campaign_settings', 'ticinoweb_promozioni_title', array( 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field' ) );
	register_setting( 'oasi_campaign_settings', 'ticinoweb_promozioni_text', array( 'type' => 'string', 'sanitize_callback' => 'sanitize_textarea_field' ) );
	register_setting( 'oasi_campaign_settings', 'ticinoweb_promozioni_image', array( 'type' => 'string', 'sanitize_callback' => 'esc_url_raw' ) );
	register_setting( 'oasi_campaign_settings', 'ticinoweb_promozioni_link', array( 'type' => 'string', 'sanitize_callback' => 'esc_url_raw' ) );
}
add_action( 'admin_init', 'oasi_campaign_register_settings', 30 );

function oasi_campaign_option_capability(): string {
	return 'edit_pages';
}
add_filter( 'option_page_capability_oasi_campaign_settings', 'oasi_campaign_option_capability' );

function oasi_campaign_menu(): void {
	add_submenu_page(
		'ticinoweb-cms',
		__( 'Campagne e annunci', 'oasidellespezie-child-theme' ),
		__( 'Campagne e annunci', 'oasidellespezie-child-theme' ),
		'edit_pages',
		'oasi-campaign-settings',
		'oasi_campaign_render_admin_page'
	);
}
add_action( 'admin_menu', 'oasi_campaign_menu', 39 );

function oasi_campaign_admin_assets( string $hook ): void {
	if ( 'ticinoweb-cms_page_oasi-campaign-settings' !== $hook ) {
		return;
	}
	wp_enqueue_media();
	wp_enqueue_style( 'oasi-cms-editor', get_stylesheet_directory_uri() . '/assets/css/cms-editor.css', array(), wp_get_theme()->get( 'Version' ) );
	wp_enqueue_script( 'oasi-campaign-admin', get_stylesheet_directory_uri() . '/assets/js/campaign-admin.js', array(), wp_get_theme()->get( 'Version' ), true );
}
add_action( 'admin_enqueue_scripts', 'oasi_campaign_admin_assets' );

function oasi_campaign_admin_media_field( string $name, string $value, string $label, string $storage ): void {
	$image_url = 'id' === $storage ? wp_get_attachment_image_url( absint( $value ), 'medium' ) : $value;
	?>
	<div class="oasi-cms-editor__field" data-oasi-campaign-media data-storage="<?php echo esc_attr( $storage ); ?>">
		<span><?php echo esc_html( $label ); ?></span>
		<div class="oasi-cms-editor__media">
			<div class="oasi-cms-editor__preview" data-oasi-campaign-preview data-empty-label="<?php esc_attr_e( 'Nessuna immagine selezionata', 'oasidellespezie-child-theme' ); ?>">
				<?php if ( $image_url ) : ?><img src="<?php echo esc_url( $image_url ); ?>" alt=""><?php else : ?><span><?php esc_html_e( 'Nessuna immagine selezionata', 'oasidellespezie-child-theme' ); ?></span><?php endif; ?>
			</div>
			<div class="oasi-cms-editor__media-actions">
				<input type="hidden" name="<?php echo esc_attr( $name ); ?>" value="<?php echo esc_attr( $value ); ?>" data-oasi-campaign-media-input>
				<button type="button" class="button" data-oasi-campaign-media-pick><?php esc_html_e( 'Scegli dalla Libreria Media', 'oasidellespezie-child-theme' ); ?></button>
				<button type="button" class="button-link-delete" data-oasi-campaign-media-clear><?php esc_html_e( 'Rimuovi', 'oasidellespezie-child-theme' ); ?></button>
			</div>
		</div>
	</div>
	<?php
}

function oasi_campaign_admin_window_fields( string $prefix, array $data ): void {
	?>
	<div class="oasi-cms-editor__grid">
		<label class="oasi-cms-editor__field"><span><?php esc_html_e( 'Data e ora di inizio', 'oasidellespezie-child-theme' ); ?></span><input type="datetime-local" name="<?php echo esc_attr( $prefix ); ?>[start_at]" value="<?php echo esc_attr( $data['start_at'] ); ?>"><small><?php esc_html_e( 'Lascia vuoto per pubblicare subito.', 'oasidellespezie-child-theme' ); ?></small></label>
		<label class="oasi-cms-editor__field"><span><?php esc_html_e( 'Data e ora di fine', 'oasidellespezie-child-theme' ); ?></span><input type="datetime-local" name="<?php echo esc_attr( $prefix ); ?>[end_at]" value="<?php echo esc_attr( $data['end_at'] ); ?>"><small><?php esc_html_e( 'Lascia vuoto per non impostare una scadenza.', 'oasidellespezie-child-theme' ); ?></small></label>
	</div>
	<?php
}

function oasi_campaign_render_admin_page(): void {
	if ( ! current_user_can( 'edit_pages' ) ) {
		wp_die( esc_html__( 'Non hai i permessi per gestire campagne e annunci.', 'oasidellespezie-child-theme' ) );
	}

	$popup       = oasi_get_popup_campaign();
	$popup_data  = oasi_campaign_popup_content();
	$announcement = oasi_get_home_announcement();
	?>
	<div class="wrap oasi-cms-editor oasi-campaign-editor">
		<h1><?php esc_html_e( 'Campagne e annunci', 'oasidellespezie-child-theme' ); ?></h1>
		<p class="oasi-cms-editor__lead"><?php esc_html_e( 'Prepara comunicazioni temporanee e decidi esattamente quando mostrarle. Tutto si pubblica e si interrompe automaticamente secondo le date impostate.', 'oasidellespezie-child-theme' ); ?></p>
		<?php settings_errors(); ?>
		<form method="post" action="options.php">
			<?php settings_fields( 'oasi_campaign_settings' ); ?>
			<section class="oasi-cms-editor__section" aria-labelledby="oasi-popup-editor-title">
				<div class="oasi-cms-editor__section-heading"><div><h2 id="oasi-popup-editor-title"><?php esc_html_e( 'Popup del sito', 'oasidellespezie-child-theme' ); ?></h2></div><p><?php esc_html_e( 'Compare una volta per sessione e non interrompe carrello, cassa, conferma ordine o area cliente.', 'oasidellespezie-child-theme' ); ?></p></div>
				<input type="hidden" name="oasi_popup_campaign[enabled]" value="0">
				<label class="oasi-cms-editor__toggle"><input type="checkbox" name="oasi_popup_campaign[enabled]" value="1" <?php checked( 1, $popup['enabled'] ); ?>><span><strong><?php esc_html_e( 'Pubblica il popup', 'oasidellespezie-child-theme' ); ?></strong><small><?php esc_html_e( 'Il popup sarà visibile soltanto durante il periodo indicato.', 'oasidellespezie-child-theme' ); ?></small></span></label>
				<div class="oasi-cms-editor__grid">
					<label class="oasi-cms-editor__field"><span><?php esc_html_e( 'Titolo', 'oasidellespezie-child-theme' ); ?></span><input type="text" class="large-text" name="ticinoweb_promozioni_title" value="<?php echo esc_attr( $popup_data['title'] ); ?>"></label>
					<label class="oasi-cms-editor__field"><span><?php esc_html_e( 'Testo del pulsante', 'oasidellespezie-child-theme' ); ?></span><input type="text" class="large-text" name="oasi_popup_campaign[button_label]" value="<?php echo esc_attr( $popup['button_label'] ); ?>"><small><?php esc_html_e( 'Lascia vuoto per mostrare il popup senza pulsante.', 'oasidellespezie-child-theme' ); ?></small></label>
					<label class="oasi-cms-editor__field"><span><?php esc_html_e( 'Descrizione', 'oasidellespezie-child-theme' ); ?></span><textarea class="large-text" rows="4" name="ticinoweb_promozioni_text"><?php echo esc_textarea( $popup_data['text'] ); ?></textarea></label>
					<label class="oasi-cms-editor__field"><span><?php esc_html_e( 'Destinazione del pulsante', 'oasidellespezie-child-theme' ); ?></span><input type="url" class="large-text" name="ticinoweb_promozioni_link" value="<?php echo esc_attr( $popup_data['link'] ); ?>" placeholder="https://"><small><?php esc_html_e( 'Usa una pagina del sito. Se vuoto, il pulsante non compare.', 'oasidellespezie-child-theme' ); ?></small></label>
				</div>
				<?php oasi_campaign_admin_media_field( 'ticinoweb_promozioni_image', $popup_data['image'], __( 'Immagine del popup (opzionale)', 'oasidellespezie-child-theme' ), 'url' ); ?>
				<?php oasi_campaign_admin_window_fields( 'oasi_popup_campaign', $popup ); ?>
				<input type="hidden" name="oasi_popup_campaign[delay_ms]" value="<?php echo esc_attr( (string) $popup['delay_ms'] ); ?>">
			</section>

			<section class="oasi-cms-editor__section" aria-labelledby="oasi-home-announcement-editor-title">
				<div class="oasi-cms-editor__section-heading"><div><h2 id="oasi-home-announcement-editor-title"><?php esc_html_e( 'Annuncio nella Homepage', 'oasidellespezie-child-theme' ); ?></h2></div><p><?php esc_html_e( 'Appare fra la barra dei servizi e i prodotti Novità. Non contiene pulsanti o collegamenti.', 'oasidellespezie-child-theme' ); ?></p></div>
				<input type="hidden" name="oasi_home_announcement[enabled]" value="0">
				<label class="oasi-cms-editor__toggle"><input type="checkbox" name="oasi_home_announcement[enabled]" value="1" <?php checked( 1, $announcement['enabled'] ); ?>><span><strong><?php esc_html_e( 'Pubblica l’annuncio in Home', 'oasidellespezie-child-theme' ); ?></strong><small><?php esc_html_e( 'Sono necessari titolo, descrizione e immagine.', 'oasidellespezie-child-theme' ); ?></small></span></label>
				<div class="oasi-cms-editor__grid">
					<label class="oasi-cms-editor__field"><span><?php esc_html_e( 'Titolo', 'oasidellespezie-child-theme' ); ?></span><input type="text" class="large-text" name="oasi_home_announcement[title]" value="<?php echo esc_attr( $announcement['title'] ); ?>"></label>
					<label class="oasi-cms-editor__field"><span><?php esc_html_e( 'Descrizione', 'oasidellespezie-child-theme' ); ?></span><textarea class="large-text" rows="4" name="oasi_home_announcement[description]"><?php echo esc_textarea( $announcement['description'] ); ?></textarea></label>
				</div>
				<?php oasi_campaign_admin_media_field( 'oasi_home_announcement[image_id]', (string) $announcement['image_id'], __( 'Immagine dell’annuncio', 'oasidellespezie-child-theme' ), 'id' ); ?>
				<?php oasi_campaign_admin_window_fields( 'oasi_home_announcement', $announcement ); ?>
			</section>
			<?php submit_button( __( 'Salva campagne e annunci', 'oasidellespezie-child-theme' ) ); ?>
		</form>
	</div>
	<?php
}
