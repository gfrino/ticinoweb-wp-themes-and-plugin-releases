<?php
/** A separate card and independent gallery for each product color. */
defined( 'ABSPATH' ) || exit;
if ( ! function_exists( 'wc_get_products' ) ) {
    return;
}
$models = array();
foreach ( wc_get_products( array( 'status' => 'publish', 'type' => 'variable', 'limit' => 2, 'orderby' => 'ID', 'order' => 'ASC' ) ) as $model ) {
    if ( ! $model->is_visible() ) {
        continue;
    }
    $cards = monvel_get_home_color_cards( $model );
    if ( $cards ) {
        $models[] = array( 'product' => $model, 'cards' => $cards );
    }
}
if ( ! $models ) {
    return;
}
?>
<section id="colori" class="mv-colors-section" aria-labelledby="mv-colors-title">
    <div class="monvel-container">
        <div class="mv-colors-intro">
            <div>
                <?php if ( ! empty( $args['has_biography_heading'] ) ) : ?>
                    <h2 id="mv-colors-title"><?php esc_html_e( 'Gli ultimi drop', 'monvel-child-theme' ); ?></h2>
                <?php else : ?>
                    <h1 id="mv-colors-title"><?php esc_html_e( 'Gli ultimi drop', 'monvel-child-theme' ); ?></h1>
                <?php endif; ?>
                <p><?php esc_html_e( 'Scegli il tuo colore. Scopri ogni dettaglio.', 'monvel-child-theme' ); ?></p>
            </div>
            <nav class="mv-colors-jump" aria-label="<?php esc_attr_e( 'Scegli il modello', 'monvel-child-theme' ); ?>">
                <?php foreach ( $models as $group ) : ?>
                    <a href="#mv-model-<?php echo esc_attr( $group['product']->get_id() ); ?>"><?php echo esc_html( $group['product']->get_name() ); ?><span aria-hidden="true">↓</span></a>
                <?php endforeach; ?>
            </nav>
        </div>
        <div class="mv-model-columns">
            <?php foreach ( $models as $group ) :
                $model = $group['product'];
                ?>
                <section id="mv-model-<?php echo esc_attr( $model->get_id() ); ?>" class="mv-model-column" aria-labelledby="mv-model-title-<?php echo esc_attr( $model->get_id() ); ?>">
                    <header class="mv-model-heading">
                        <h3 id="mv-model-title-<?php echo esc_attr( $model->get_id() ); ?>"><?php echo esc_html( $model->get_name() ); ?></h3>
                        <span><?php echo esc_html( sprintf( _n( '%s colore', '%s colori', count( $group['cards'] ), 'monvel-child-theme' ), number_format_i18n( count( $group['cards'] ) ) ) ); ?></span>
                    </header>
                    <div class="mv-color-grid">
                        <?php foreach ( $group['cards'] as $card_index => $card ) :
                            $card_id = 'mv-color-' . $card['variation_id'];
                            $photo_count = count( $card['images'] );
                            ?>
                            <article class="mv-color-card" aria-labelledby="<?php echo esc_attr( $card_id ); ?>-name <?php echo esc_attr( $card_id ); ?>-color">
                                <div class="mv-card-gallery" role="group" aria-label="<?php echo esc_attr( $model->get_name() . ' — ' . $card['color'] ); ?>">
                                    <div id="<?php echo esc_attr( $card_id ); ?>-photo" class="mv-card-photo">
                                        <?php echo wp_get_attachment_image( $card['images'][0], 'large', false, array( 'loading' => 0 === $card_index ? 'eager' : 'lazy', 'decoding' => 'async', 'sizes' => '(min-width: 1900px) 440px, (min-width: 1200px) 24vw, (min-width: 700px) 48vw, calc((100vw - 44px) / 2)', 'alt' => $model->get_name() . ' — ' . $card['color'] ) ); ?>
                                    </div>
                                    <?php if ( $photo_count > 1 ) : ?>
                                        <?php foreach ( $card['images'] as $index => $image_id ) : ?>
                                            <template data-photo="<?php echo esc_attr( $index ); ?>"><?php echo wp_get_attachment_image( $image_id, 'large', false, array( 'loading' => 'eager', 'decoding' => 'async', 'sizes' => '(min-width: 1900px) 440px, (min-width: 1200px) 24vw, (min-width: 700px) 48vw, calc((100vw - 44px) / 2)', 'alt' => $model->get_name() . ' — ' . $card['color'] . ' — ' . sprintf( __( 'Foto %s', 'monvel-child-theme' ), $index + 1 ) ) ); ?></template>
                                        <?php endforeach; ?>
                                        <div class="mv-card-gallery-controls" hidden>
                                            <button type="button" data-gallery-step="-1" class="mv-gallery-arrow" aria-label="<?php esc_attr_e( 'Foto precedente', 'monvel-child-theme' ); ?>" aria-controls="<?php echo esc_attr( $card_id ); ?>-photo"><span aria-hidden="true">←</span></button>
                                            <div class="mv-gallery-dots">
                                                <?php foreach ( $card['images'] as $index => $image_id ) : ?>
                                                    <button type="button" data-gallery-photo="<?php echo esc_attr( $index ); ?>" aria-label="<?php echo esc_attr( sprintf( __( 'Foto %1$s di %2$s', 'monvel-child-theme' ), $index + 1, $photo_count ) ); ?>" aria-pressed="<?php echo 0 === $index ? 'true' : 'false'; ?>" aria-controls="<?php echo esc_attr( $card_id ); ?>-photo"><span></span></button>
                                                <?php endforeach; ?>
                                            </div>
                                            <span class="mv-gallery-counter" aria-hidden="true">1 / <?php echo esc_html( $photo_count ); ?></span>
                                            <button type="button" data-gallery-step="1" class="mv-gallery-arrow" aria-label="<?php esc_attr_e( 'Foto successiva', 'monvel-child-theme' ); ?>" aria-controls="<?php echo esc_attr( $card_id ); ?>-photo"><span aria-hidden="true">→</span></button>
                                        </div>
                                        <span class="mv-gallery-status screen-reader-text" aria-live="polite"></span>
                                    <?php endif; ?>
                                </div>
                                <div class="mv-card-details">
                                    <h4 id="<?php echo esc_attr( $card_id ); ?>-name"><?php echo esc_html( $model->get_name() ); ?></h4>
                                    <div class="mv-card-color-price">
                                        <p id="<?php echo esc_attr( $card_id ); ?>-color"><?php echo esc_html( $card['color'] ); ?></p>
                                        <span class="mv-card-price"><?php echo wp_kses_post( $card['price'] ); ?></span>
                                    </div>
                                    <?php if ( ! $card['in_stock'] ) : ?><p class="mv-card-stock"><?php esc_html_e( 'Esaurito', 'monvel-child-theme' ); ?></p><?php endif; ?>
                                    <a class="mv-card-link" href="<?php echo esc_url( $card['url'] ); ?>"><?php esc_html_e( 'Scopri il cappello', 'monvel-child-theme' ); ?><span aria-hidden="true">↗</span></a>
                                </div>
                            </article>
                        <?php endforeach; ?>
                    </div>
                </section>
            <?php endforeach; ?>
        </div>
    </div>
</section>
