<?php
/** Text-only introduction from the existing parent CMS fields. */
defined( 'ABSPATH' ) || exit;
?>
<section class="mv-home-biography"<?php if ( '' !== $args['title'] ) : ?> aria-labelledby="mv-biography-title"<?php endif; ?>>
    <div class="monvel-container">
        <div class="mv-biography-inner">
            <?php if ( '' !== $args['title'] ) : ?>
                <h1 id="mv-biography-title"><?php echo esc_html( $args['title'] ); ?></h1>
            <?php endif; ?>
            <div class="mv-biography-copy"><?php echo wpautop( esc_html( $args['text'] ) ); ?></div>
        </div>
    </div>
</section>
