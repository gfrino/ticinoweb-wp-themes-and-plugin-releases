<?php
/** Brand introduction and color catalogue for Monvél Cappelli. */
get_header();
?>
<main id="primary" class="site-main mv-home-catalog-first">
    <?php
    $biography_title = trim( wp_strip_all_tags( (string) get_option( 'ticinoweb_chi_siamo_title', '' ) ) );
    $biography_text = trim( (string) get_option( 'ticinoweb_chi_siamo_text', '' ) );
    $has_biography = '' !== trim( wp_strip_all_tags( $biography_text ) );
    if ( $has_biography ) {
        get_template_part( 'template-parts/home-biography', null, array( 'title' => $biography_title, 'text' => $biography_text ) );
    }
    get_template_part( 'template-parts/home-color-cards', null, array( 'has_biography_heading' => $has_biography && '' !== $biography_title ) );
    ?>

    <!-- CAMPAIGN GRID (Editorial layout) -->
    <section class="mv-campaign-grid-section">
        <?php
        // Fetch images for Campaign Grid from ticinoWEB Media Gallery ID 27
        $campaign_gallery_id = 27;
        $campaign_images = array();
        
        $campaign_query = new WP_Query(array(
            'post_type'      => 'attachment',
            'post_status'    => 'inherit',
            'posts_per_page' => 4,
            'tax_query' => array(
                array(
                    'taxonomy' => 'ticinoweb_media_gallery',
                    'field' => 'term_id',
                    'terms' => $campaign_gallery_id,
                )
            )
        ));

        // Apply saved order if any
        $saved_order = get_term_meta($campaign_gallery_id, '_ticinoweb_gallery_order', true);
        if (!empty($saved_order) && is_array($saved_order) && $campaign_query->have_posts()) {
            usort($campaign_query->posts, function ($a, $b) use ($saved_order) {
                $posA = array_search($a->ID, $saved_order);
                $posB = array_search($b->ID, $saved_order);
                if ($posA === false) $posA = 999999;
                if ($posB === false) $posB = 999999;
                return $posA - $posB;
            });
        }

        if ($campaign_query->have_posts()) {
            foreach ($campaign_query->posts as $attachment) {
                $img_src = wp_get_attachment_image_src($attachment->ID, 'large');
                if ($img_src) {
                    $campaign_images[] = $img_src[0];
                }
            }
        }
        wp_reset_postdata();

        // Fallbacks if fewer than 4 images
        while (count($campaign_images) < 4) {
            $campaign_images[] = 'https://images.unsplash.com/photo-1556821840-3a63f95609a7?q=80&w=1200&auto=format&fit=crop';
        }

        $shop_url = function_exists('wc_get_page_permalink') ? wc_get_page_permalink('shop') : home_url('/shop/');
        
        $campaign_blocks = array(
            array('title' => 'ESSENZIALI MONVÉL', 'cta' => 'ACQUISTA ORA', 'link' => $shop_url),
            array('title' => 'STILE URBANO', 'cta' => 'SCOPRI ORA', 'link' => $shop_url),
            array('title' => 'NUOVE ICONE STREET', 'cta' => 'ESPLORA', 'link' => $shop_url),
            array('title' => 'DETTAGLI CHE CONTANO', 'cta' => 'VEDI I CAPPELLI', 'link' => $shop_url),
        );
        ?>
        <div class="monvel-container">
            <div class="mv-campaign-grid">
                <?php for ($i = 0; $i < 4; $i++): ?>
                    <a href="<?php echo esc_url($campaign_blocks[$i]['link']); ?>" class="mv-campaign-block">
                        <div class="mv-campaign-bg"><img src="<?php echo esc_url( $campaign_images[$i] ); ?>" alt="" loading="lazy" decoding="async"></div>
                        <div class="mv-campaign-overlay"></div>
                        <div class="mv-campaign-content">
                            <h3 class="mv-campaign-title"><?php echo esc_html($campaign_blocks[$i]['title']); ?></h3>
                            <span class="mv-campaign-cta"><?php echo esc_html($campaign_blocks[$i]['cta']); ?></span>
                        </div>
                    </a>
                <?php endfor; ?>
            </div>
        </div>
    </section>

    <!-- PROMOTIONAL VIDEO SECTION -->
    <section class="mv-front-video-section">
        <div class="monvel-container">
            <div class="mv-video-wrapper">
                <video id="mv-front-video" class="mv-front-video" autoplay loop muted playsinline preload="none" data-src="https://monvelwear.com/wp-content/uploads/sites/108/2026/07/Crea_un_video_pubblicitario_ci-1.mp4"></video>
                <noscript><style>#mv-front-video{display:none}</style><video class="mv-front-video" controls muted playsinline preload="none" src="https://monvelwear.com/wp-content/uploads/sites/108/2026/07/Crea_un_video_pubblicitario_ci-1.mp4"></video></noscript>
                <div class="mv-video-overlay"></div>
                <button id="mv-audio-toggle" class="mv-audio-toggle" aria-label="Toggle Audio">
                    <svg class="mv-icon-muted" viewBox="0 0 24 24" width="24" height="24" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"></polygon><line x1="23" y1="9" x2="17" y2="15"></line><line x1="17" y1="9" x2="23" y2="15"></line></svg>
                    <svg class="mv-icon-unmuted" viewBox="0 0 24 24" width="24" height="24" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round" style="display:none;"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"></polygon><path d="M19.07 4.93a10 10 0 0 1 0 14.14M15.54 8.46a5 5 0 0 1 0 7.07"></path></svg>
                </button>
            </div>
        </div>
    </section>

    <!-- FINAL CTA SECTION -->
    <section class="mv-final-cta-section">
        <!-- Soft glowing background effect -->
        <div class="mv-final-glow"></div>
        
        <div class="monvel-container">
            <div class="mv-final-content">
                <span class="mv-final-eyebrow">IL PROSSIMO PASSO</span>
                <h2 class="mv-final-title">UNISCITI AL DROP</h2>
                <p class="mv-final-subtitle">Nuovi colori, nuovi modelli, stessa identità Monvél.</p>
                <div class="mv-final-actions">
                    <a href="<?php echo class_exists('WooCommerce') ? wc_get_page_permalink( 'shop' ) : '#colori'; ?>" class="mv-btn mv-btn-dark mv-final-btn">
                        <span>Scopri la collezione</span>
                    </a>
                </div>
            </div>
        </div>
    </section>

</main>

<?php
get_footer();
