/** Brand entrance on each real home load. No session state and no dependency on GSAP. */
(() => {
    'use strict';
    const media = window.matchMedia('(prefers-reduced-motion: reduce)');
    const navigation = performance.getEntriesByType('navigation')[0];
    if (media.matches || !Element.prototype.animate || navigation?.type === 'back_forward') return;

    const html = document.documentElement;
    const timers = [], animations = [];
    let loader = null, closed = false;
    const interactions = ['pointerdown', 'keydown', 'wheel'];
    const finish = () => {
        if (closed) return;
        closed = true;
        timers.forEach(clearTimeout);
        animations.forEach(animation => animation.cancel());
        html.classList.remove('mv-intro-pending');
        (loader || document.querySelector('#mv-home-preloader'))?.remove();
        interactions.forEach(type => window.removeEventListener(type, finish, true));
        media.removeEventListener?.('change', changedMotion);
    };
    const changedMotion = event => { if (event.matches) finish(); };
    const delay = ms => new Promise(resolve => timers.push(setTimeout(resolve, ms)));
    timers.push(setTimeout(finish, 3200));
    html.classList.add('mv-intro-pending');
    interactions.forEach(type => window.addEventListener(type, finish, { capture: true, passive: true, once: true }));
    window.addEventListener('pagehide', finish, { once: true });
    window.addEventListener('pageshow', event => { if (event.persisted) finish(); });
    media.addEventListener?.('change', changedMotion);

    const start = () => {
        if (closed) return;
        loader = document.querySelector('#mv-home-preloader');
        if (!loader || getComputedStyle(loader).position !== 'fixed') { finish(); return; }
        const logo = loader.querySelector('.mv-preloader__logo');
        if (!logo || (logo.complete && !logo.naturalWidth)) { finish(); return; }
        const leave = () => {
            if (closed || !loader.isConnected) return;
            try {
                const target = document.querySelector('.monvel-header .monvel-logo-img');
                const from = logo.getBoundingClientRect(), to = target?.getBoundingClientRect();
                if (to?.width && to.height && from.width && from.height) {
                    const dx = to.left + to.width / 2 - from.left - from.width / 2;
                    const dy = to.top + to.height / 2 - from.top - from.height / 2;
                    animations.push(logo.animate([
                        { transform: 'none' },
                        { transform: `translate3d(${dx}px,${dy}px,0) scale(${to.width / from.width},${to.height / from.height})` },
                    ], { duration: 900, easing: 'cubic-bezier(.42,0,.2,1)', fill: 'forwards' }));
                }
                loader.querySelectorAll('.mv-preloader__panel').forEach((panel, index) => {
                    animations.push(panel.animate([
                        { transform: 'translateX(0)' },
                        { transform: `translateX(${index === 0 ? -100 : 100}%)` },
                    ], { duration: 750, delay: 430, easing: 'cubic-bezier(.65,0,.25,1)', fill: 'forwards' }));
                });
                const seam = loader.querySelector('.mv-preloader__seam');
                if (seam) animations.push(seam.animate([{ opacity: .2 }, { opacity: 0 }], { duration: 320, fill: 'forwards' }));
                Promise.all(animations.map(animation => animation.finished)).then(finish, finish);
            } catch { finish(); }
        };
        const firstPhoto = document.querySelector('.mv-card-photo img');
        const ready = [logo, firstPhoto].filter(Boolean).map(img => img.decode ? img.decode() : Promise.resolve());
        Promise.all([delay(900), Promise.race([Promise.allSettled(ready), delay(1100)])]).then(leave, finish);
    };
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start, { once: true });
    else start();
})();
