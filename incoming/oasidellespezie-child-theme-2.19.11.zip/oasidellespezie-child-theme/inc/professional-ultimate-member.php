<?php
/**
 * Ultimate Member bridge for professional access requests.
 *
 * Existing customers stay approved in Ultimate Member while their separate
 * professional request is reviewed. This avoids invalidating active sessions.
 *
 * @package OasiDelleSpezieChild
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Return whether the Ultimate Member runtime API is available. */
function oasi_professional_um_is_available(): bool {
	if ( ! function_exists( 'UM' ) || ! is_object( UM() ) || ! is_object( UM()->common() ) ) {
		return false;
	}
	return is_object( UM()->common()->users() );
}

/** Resolve the Ultimate Member professional form without relying on local IDs. */
function oasi_professional_um_get_form_id(): int {
	$form_ids = get_posts(
		array(
			'post_type'      => 'um_form',
			'post_status'    => array( 'publish', 'draft' ),
			'posts_per_page' => 1,
			'fields'         => 'ids',
			'meta_key'       => '_um_register_role', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- One administrative lookup, cached by WordPress.
			'meta_value'     => 'wholesale_customer', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value -- One administrative lookup, cached by WordPress.
		)
	);
	return $form_ids ? absint( $form_ids[0] ) : 0;
}

/** Return labels used by the Ultimate Member administration screen. */
function oasi_professional_um_request_fields(): array {
	return array(
		'company_uid'     => __( 'UID / CHE', 'oasidellespezie-child-theme' ),
		'legal_form'      => __( 'Forma giuridica', 'oasidellespezie-child-theme' ),
		'website'         => __( 'Sito web', 'oasidellespezie-child-theme' ),
		'sector'          => __( 'Settore', 'oasidellespezie-child-theme' ),
		'activity'        => __( 'Descrizione attività', 'oasidellespezie-child-theme' ),
		'customer_type'   => __( 'Utilizzo dei prodotti', 'oasidellespezie-child-theme' ),
		'interests'       => __( 'Categorie di interesse', 'oasidellespezie-child-theme' ),
		'message'         => __( 'Altre informazioni', 'oasidellespezie-child-theme' ),
	);
}

/** Return human-readable values for request choices. */
function oasi_professional_um_choice_labels(): array {
	$labels = array(
		'ditta-individuale' => __( 'Ditta individuale', 'oasidellespezie-child-theme' ),
		'sagl'               => 'Sagl',
		'sa'                 => 'SA',
		'associazione'       => __( 'Associazione', 'oasidellespezie-child-theme' ),
		'ente-pubblico'      => __( 'Ente pubblico', 'oasidellespezie-child-theme' ),
		'altra'              => __( 'Altra', 'oasidellespezie-child-theme' ),
		'ristorazione'       => __( 'Ristorazione', 'oasidellespezie-child-theme' ),
		'hotellerie'         => __( 'Hotellerie', 'oasidellespezie-child-theme' ),
		'produzione'         => __( 'Produzione alimentare', 'oasidellespezie-child-theme' ),
		'vendita'            => __( 'Commercio / vendita', 'oasidellespezie-child-theme' ),
		'benessere'          => __( 'Benessere', 'oasidellespezie-child-theme' ),
		'formazione'         => __( 'Formazione', 'oasidellespezie-child-theme' ),
		'altro'              => __( 'Altro', 'oasidellespezie-child-theme' ),
		'utilizzatore'       => __( 'Uso nella mia attività', 'oasidellespezie-child-theme' ),
		'rivenditore'        => __( 'Rivendita', 'oasidellespezie-child-theme' ),
		'produttore'         => __( 'Produzione / trasformazione', 'oasidellespezie-child-theme' ),
		'distributore'       => __( 'Distribuzione', 'oasidellespezie-child-theme' ),
	);

	return array_merge( $labels, oasi_professional_application_get_interest_choices() );
}

/** Format one stored request value for administrators. */
function oasi_professional_um_format_value( $value ): string {
	$labels = oasi_professional_um_choice_labels();
	$values = is_array( $value ) ? $value : array( $value );
	$values = array_filter(
		array_map(
			static function ( $item ) use ( $labels ): string {
				$item = sanitize_text_field( (string) $item );
				return $labels[ $item ] ?? $item;
			},
			$values
		)
	);
	return $values ? implode( ', ', $values ) : '—';
}

/**
 * Save a validated request in Ultimate Member's user-meta model.
 *
 * The core `account_status` is checked but deliberately never changed: setting
 * an approved customer to UM pending review would destroy sessions and block login.
 */
function oasi_professional_um_sync_request( array $data, WP_User $user, array $account ) {
	if ( ! oasi_professional_um_is_available() ) {
		return new WP_Error( 'ultimate_member_unavailable', __( 'Il servizio di verifica professionale non è disponibile. Riprova più tardi.', 'oasidellespezie-child-theme' ) );
	}

	$account_status = sanitize_key( (string) get_user_meta( $user->ID, 'account_status', true ) );
	if ( $account_status && 'approved' !== $account_status ) {
		return new WP_Error( 'ultimate_member_account', __( 'Il tuo account Ultimate Member deve essere attivo prima di inviare la richiesta.', 'oasidellespezie-child-theme' ) );
	}

	$request = array();
	foreach ( array_keys( oasi_professional_um_request_fields() ) as $key ) {
		$request[ $key ] = $data[ $key ] ?? '';
		update_user_meta( $user->ID, 'oasi_professional_' . $key, $request[ $key ] );
	}

	$um_fields = array(
		'user_azienda'       => sanitize_text_field( (string) ( $account['company'] ?? '' ) ),
		'user_attivita'      => sanitize_key( (string) ( $data['sector'] ?? '' ) ),
		'user_altraattivita' => sanitize_textarea_field( (string) ( $data['activity'] ?? '' ) ),
		'user_iva'           => sanitize_text_field( (string) ( $data['company_uid'] ?? '' ) ),
		'mobile_number'      => sanitize_text_field( (string) ( $account['phone'] ?? '' ) ),
		'user_messaggio'     => sanitize_textarea_field( (string) ( $data['message'] ?? '' ) ),
		'user_indirizzo'     => sanitize_text_field( (string) ( $account['address'] ?? '' ) ),
	);
	foreach ( $um_fields as $meta_key => $value ) {
		update_user_meta( $user->ID, $meta_key, $value );
	}

	$requested_at = current_time( 'mysql' );
	update_user_meta( $user->ID, 'oasi_professional_request_status', 'pending' );
	update_user_meta( $user->ID, 'oasi_professional_requested_at', $requested_at );
	update_user_meta( $user->ID, 'oasi_professional_request_id', sanitize_text_field( (string) ( $data['request_id'] ?? '' ) ) );
	update_user_meta( $user->ID, 'oasi_professional_um_form_id', oasi_professional_um_get_form_id() );
	update_user_meta( $user->ID, 'oasi_professional_um_synced_at', $requested_at );

	$users_api = UM()->common()->users();
	if ( is_object( $users_api ) && method_exists( $users_api, 'remove_cache' ) ) {
		$users_api->remove_cache( $user->ID );
	}

	do_action( 'oasi_professional_request_synced_to_um', $user->ID, $request, $um_fields );
	return true;
}

/** Return professional applicants sorted from newest to oldest. */
function oasi_professional_um_get_requests( string $status = 'pending' ): array {
	$users = get_users(
		array(
			'meta_key'   => 'oasi_professional_request_status', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- Small administrative dataset.
			'meta_value' => sanitize_key( $status ), // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value -- Small administrative dataset.
			'orderby'    => 'ID',
			'order'      => 'DESC',
		)
	);
	usort(
		$users,
		static function ( WP_User $first, WP_User $second ): int {
			return strcmp( (string) get_user_meta( $second->ID, 'oasi_professional_requested_at', true ), (string) get_user_meta( $first->ID, 'oasi_professional_requested_at', true ) );
		}
	);
	return $users;
}

/** Add the request manager under the Ultimate Member menu. */
function oasi_professional_um_register_admin_menu(): void {
	add_submenu_page(
		'ultimatemember',
		__( 'Richieste professionali', 'oasidellespezie-child-theme' ),
		__( 'Richieste professionali', 'oasidellespezie-child-theme' ),
		'edit_users',
		'oasi-professional-requests',
		'oasi_professional_um_render_requests_page'
	);
}
add_action( 'um_extend_admin_menu', 'oasi_professional_um_register_admin_menu' );

/** Register a summary box on the native Ultimate Member dashboard. */
function oasi_professional_um_register_dashboard_widget(): void {
	add_meta_box(
		'oasi-um-professional-requests',
		__( 'Richieste professionali', 'oasidellespezie-child-theme' ),
		'oasi_professional_um_render_dashboard_widget',
		'toplevel_page_ultimatemember',
		'normal',
		'high'
	);
}
add_action( 'load-toplevel_page_ultimatemember', 'oasi_professional_um_register_dashboard_widget' );

/** Load scoped styling only on the Ultimate Member request screens. */
function oasi_professional_um_admin_assets( string $hook_suffix ): void {
	if ( ! in_array( $hook_suffix, array( 'toplevel_page_ultimatemember', 'ultimate-member_page_oasi-professional-requests', 'user-edit.php', 'profile.php' ), true ) ) {
		return;
	}
	wp_enqueue_style(
		'oasi-professional-admin',
		get_stylesheet_directory_uri() . '/assets/css/professional-admin.css',
		array(),
		wp_get_theme()->get( 'Version' )
	);
}
add_action( 'admin_enqueue_scripts', 'oasi_professional_um_admin_assets' );

/** Return a protected approval/rejection URL. */
function oasi_professional_um_decision_url( int $user_id, string $decision, string $return_url = '' ): string {
	$url = add_query_arg(
		array(
			'action'     => 'oasi_professional_um_decision',
			'user_id'    => $user_id,
			'decision'   => sanitize_key( $decision ),
			'return_url' => $return_url ?: admin_url( 'admin.php?page=oasi-professional-requests' ),
		),
		admin_url( 'admin-post.php' )
	);
	return wp_nonce_url( $url, 'oasi_professional_um_decision_' . $user_id );
}

/** Render one compact applicant row. */
function oasi_professional_um_render_request_row( WP_User $user, bool $compact = false ): void {
	$company = sanitize_text_field( (string) get_user_meta( $user->ID, 'user_azienda', true ) );
	$uid     = sanitize_text_field( (string) get_user_meta( $user->ID, 'oasi_professional_company_uid', true ) );
	$date    = sanitize_text_field( (string) get_user_meta( $user->ID, 'oasi_professional_requested_at', true ) );
	$return  = $compact ? admin_url( 'admin.php?page=ultimatemember' ) : admin_url( 'admin.php?page=oasi-professional-requests' );
	?>
	<article class="oasi-um-request<?php echo $compact ? ' oasi-um-request--compact' : ''; ?>">
		<div class="oasi-um-request__identity">
			<strong><?php echo esc_html( $company ?: $user->display_name ); ?></strong>
			<span><?php echo esc_html( $user->user_email ); ?></span>
		</div>
		<div class="oasi-um-request__meta">
			<span><b><?php esc_html_e( 'UID', 'oasidellespezie-child-theme' ); ?></b> <?php echo esc_html( $uid ?: '—' ); ?></span>
			<span><b><?php esc_html_e( 'Ricevuta', 'oasidellespezie-child-theme' ); ?></b> <?php echo esc_html( $date ?: '—' ); ?></span>
		</div>
		<div class="oasi-um-request__actions">
			<a class="button" href="<?php echo esc_url( get_edit_user_link( $user->ID ) ); ?>"><?php esc_html_e( 'Dettagli', 'oasidellespezie-child-theme' ); ?></a>
			<a class="button button-primary" href="<?php echo esc_url( oasi_professional_um_decision_url( $user->ID, 'approved', $return ) ); ?>"><?php esc_html_e( 'Approva', 'oasidellespezie-child-theme' ); ?></a>
			<a class="button oasi-um-request__reject" href="<?php echo esc_url( oasi_professional_um_decision_url( $user->ID, 'rejected', $return ) ); ?>"><?php esc_html_e( 'Rifiuta', 'oasidellespezie-child-theme' ); ?></a>
		</div>
	</article>
	<?php
}

/** Render the Ultimate Member dashboard summary. */
function oasi_professional_um_render_dashboard_widget(): void {
	$requests = oasi_professional_um_get_requests();
	?>
	<div class="oasi-um-requests oasi-um-requests--dashboard">
		<div class="oasi-um-requests__intro">
			<div><strong><?php echo esc_html( (string) count( $requests ) ); ?></strong><span><?php esc_html_e( 'richieste in attesa', 'oasidellespezie-child-theme' ); ?></span></div>
			<a href="<?php echo esc_url( admin_url( 'admin.php?page=oasi-professional-requests' ) ); ?>"><?php esc_html_e( 'Gestisci tutte', 'oasidellespezie-child-theme' ); ?> →</a>
		</div>
		<?php if ( ! $requests ) : ?>
			<p class="oasi-um-requests__empty"><?php esc_html_e( 'Nessuna richiesta professionale da esaminare.', 'oasidellespezie-child-theme' ); ?></p>
		<?php else : ?>
			<?php foreach ( array_slice( $requests, 0, 5 ) as $request_user ) : ?>
				<?php oasi_professional_um_render_request_row( $request_user, true ); ?>
			<?php endforeach; ?>
		<?php endif; ?>
	</div>
	<?php
}

/** Render status notices after administrative actions. */
function oasi_professional_um_render_notice(): void {
	$notice = isset( $_GET['oasi_um_notice'] ) ? sanitize_key( wp_unslash( (string) $_GET['oasi_um_notice'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only redirect feedback.
	if ( ! $notice ) {
		return;
	}
	$messages = array(
		'approved' => __( 'Richiesta approvata: il ruolo professionale è ora attivo.', 'oasidellespezie-child-theme' ),
		'rejected' => __( 'Richiesta rifiutata. L’account cliente è rimasto invariato.', 'oasidellespezie-child-theme' ),
		'error'    => __( 'Non è stato possibile completare l’operazione.', 'oasidellespezie-child-theme' ),
	);
	if ( isset( $messages[ $notice ] ) ) {
		printf( '<div class="notice notice-%1$s is-dismissible"><p>%2$s</p></div>', 'error' === $notice ? 'error' : 'success', esc_html( $messages[ $notice ] ) );
	}
}

/** Render the full professional-request manager within Ultimate Member. */
function oasi_professional_um_render_requests_page(): void {
	if ( ! current_user_can( 'edit_users' ) ) {
		wp_die( esc_html__( 'Non hai i permessi per gestire queste richieste.', 'oasidellespezie-child-theme' ) );
	}
	$status   = isset( $_GET['request_status'] ) ? sanitize_key( wp_unslash( (string) $_GET['request_status'] ) ) : 'pending'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only filter.
	$statuses = array( 'pending', 'approved', 'rejected' );
	if ( ! in_array( $status, $statuses, true ) ) {
		$status = 'pending';
	}
	$requests = oasi_professional_um_get_requests( $status );
	$labels   = array( 'pending' => __( 'In attesa', 'oasidellespezie-child-theme' ), 'approved' => __( 'Approvate', 'oasidellespezie-child-theme' ), 'rejected' => __( 'Rifiutate', 'oasidellespezie-child-theme' ) );
	?>
	<div class="wrap oasi-um-requests">
		<h1><?php esc_html_e( 'Richieste professionali', 'oasidellespezie-child-theme' ); ?></h1>
		<p class="oasi-um-requests__lead"><?php esc_html_e( 'Le richieste arrivano dal formulario riservato agli account esistenti. L’account resta attivo durante la verifica.', 'oasidellespezie-child-theme' ); ?></p>
		<?php oasi_professional_um_render_notice(); ?>
		<nav class="nav-tab-wrapper" aria-label="<?php esc_attr_e( 'Stato richieste', 'oasidellespezie-child-theme' ); ?>">
			<?php foreach ( $labels as $key => $label ) : ?>
				<a class="nav-tab<?php echo $status === $key ? ' nav-tab-active' : ''; ?>" href="<?php echo esc_url( add_query_arg( array( 'page' => 'oasi-professional-requests', 'request_status' => $key ), admin_url( 'admin.php' ) ) ); ?>"><?php echo esc_html( $label ); ?></a>
			<?php endforeach; ?>
		</nav>
		<div class="oasi-um-requests__list">
			<?php if ( ! $requests ) : ?>
				<p class="oasi-um-requests__empty"><?php esc_html_e( 'Nessuna richiesta in questo stato.', 'oasidellespezie-child-theme' ); ?></p>
			<?php else : ?>
				<?php foreach ( $requests as $request_user ) : ?>
					<?php if ( 'pending' === $status ) : ?>
						<?php oasi_professional_um_render_request_row( $request_user ); ?>
					<?php else : ?>
						<article class="oasi-um-request oasi-um-request--archive"><div class="oasi-um-request__identity"><strong><?php echo esc_html( (string) get_user_meta( $request_user->ID, 'user_azienda', true ) ?: $request_user->display_name ); ?></strong><span><?php echo esc_html( $request_user->user_email ); ?></span></div><a class="button" href="<?php echo esc_url( get_edit_user_link( $request_user->ID ) ); ?>"><?php esc_html_e( 'Apri dettagli', 'oasidellespezie-child-theme' ); ?></a></article>
					<?php endif; ?>
				<?php endforeach; ?>
			<?php endif; ?>
		</div>
	</div>
	<?php
}

/** Show all submitted request data on the WordPress/Ultimate Member user record. */
function oasi_professional_um_render_user_profile( WP_User $user ): void {
	$status = sanitize_key( (string) get_user_meta( $user->ID, 'oasi_professional_request_status', true ) );
	if ( ! $status || ! current_user_can( 'edit_users' ) ) {
		return;
	}
	?>
	<section class="oasi-um-profile-request">
		<h2><?php esc_html_e( 'Richiesta professionale — Ultimate Member', 'oasidellespezie-child-theme' ); ?></h2>
		<p><span class="oasi-um-profile-request__status oasi-um-profile-request__status--<?php echo esc_attr( $status ); ?>"><?php echo esc_html( ucfirst( $status ) ); ?></span></p>
		<dl>
			<?php foreach ( oasi_professional_um_request_fields() as $key => $label ) : ?>
				<?php $value = get_user_meta( $user->ID, 'oasi_professional_' . $key, true ); ?>
				<div><dt><?php echo esc_html( $label ); ?></dt><dd><?php echo esc_html( oasi_professional_um_format_value( $value ) ); ?></dd></div>
			<?php endforeach; ?>
		</dl>
		<?php if ( 'pending' === $status ) : ?>
			<p class="oasi-um-profile-request__actions"><a class="button button-primary" href="<?php echo esc_url( oasi_professional_um_decision_url( $user->ID, 'approved', get_edit_user_link( $user->ID ) ) ); ?>"><?php esc_html_e( 'Approva come professionista', 'oasidellespezie-child-theme' ); ?></a><a class="button" href="<?php echo esc_url( oasi_professional_um_decision_url( $user->ID, 'rejected', get_edit_user_link( $user->ID ) ) ); ?>"><?php esc_html_e( 'Rifiuta richiesta', 'oasidellespezie-child-theme' ); ?></a></p>
		<?php endif; ?>
	</section>
	<?php
}
add_action( 'show_user_profile', 'oasi_professional_um_render_user_profile', 30 );
add_action( 'edit_user_profile', 'oasi_professional_um_render_user_profile', 30 );

/** Send the applicant a concise decision notification. */
function oasi_professional_um_send_decision_email( WP_User $user, string $decision ): void {
	$approved = 'approved' === $decision;
	$subject  = $approved ? __( 'Accesso professionale approvato', 'oasidellespezie-child-theme' ) : __( 'Aggiornamento richiesta professionale', 'oasidellespezie-child-theme' );
	$message  = $approved
		? __( "La tua richiesta professionale è stata approvata. Puoi accedere allo Shop con il tuo account esistente per visualizzare le condizioni dedicate.\n\nOasi delle Spezie", 'oasidellespezie-child-theme' )
		: __( "La tua richiesta professionale non è stata approvata. Il tuo account cliente resta attivo e invariato. Per chiarimenti puoi contattare il laboratorio.\n\nOasi delle Spezie", 'oasidellespezie-child-theme' );
	wp_mail( $user->user_email, $subject, $message, array( 'Content-Type: text/plain; charset=UTF-8' ) );
}

/** Apply one reviewed decision without coupling it to the admin redirect. */
function oasi_professional_um_review_request( int $user_id, string $decision, int $reviewer_id = 0, bool $notify = true ) {
	$user = get_userdata( $user_id );
	if ( ! $user instanceof WP_User || ! in_array( $decision, array( 'approved', 'rejected' ), true ) ) {
		return new WP_Error( 'invalid_decision', __( 'La decisione richiesta non è valida.', 'oasidellespezie-child-theme' ) );
	}
	if ( 'pending' !== get_user_meta( $user_id, 'oasi_professional_request_status', true ) ) {
		return new WP_Error( 'request_not_pending', __( 'La richiesta non risulta in attesa di revisione.', 'oasidellespezie-child-theme' ) );
	}

	$um_status = sanitize_key( (string) get_user_meta( $user_id, 'account_status', true ) );
	if ( $um_status && 'approved' !== $um_status ) {
		return new WP_Error( 'ultimate_member_account', __( 'L’account Ultimate Member non è attivo.', 'oasidellespezie-child-theme' ) );
	}

	if ( 'approved' === $decision ) {
		// Additive on purpose: set_role() would wipe every other role, so approving a
		// request from a staff account would silently remove shop_manager/administrator.
		$user->remove_role( 'customer' );
		$user->add_role( 'wholesale_customer' );
	}
	update_user_meta( $user_id, 'oasi_professional_request_status', $decision );
	update_user_meta( $user_id, 'oasi_professional_reviewed_at', current_time( 'mysql' ) );
	update_user_meta( $user_id, 'oasi_professional_reviewed_by', $reviewer_id ?: get_current_user_id() );
	if ( oasi_professional_um_is_available() ) {
		UM()->common()->users()->remove_cache( $user_id );
	}
	if ( $notify ) {
		oasi_professional_um_send_decision_email( $user, $decision );
	}
	do_action( 'oasi_professional_request_reviewed_in_um', $user_id, $decision, $reviewer_id ?: get_current_user_id() );
	return true;
}

/** Process an approval or rejection from the Ultimate Member administration. */
function oasi_professional_um_handle_decision(): void {
	if ( ! current_user_can( 'edit_users' ) ) {
		wp_die( esc_html__( 'Non hai i permessi per gestire queste richieste.', 'oasidellespezie-child-theme' ), '', array( 'response' => 403 ) );
	}
	$user_id  = isset( $_GET['user_id'] ) ? absint( $_GET['user_id'] ) : 0;
	$decision = isset( $_GET['decision'] ) ? sanitize_key( wp_unslash( (string) $_GET['decision'] ) ) : '';
	check_admin_referer( 'oasi_professional_um_decision_' . $user_id );
	$return_url = isset( $_GET['return_url'] ) ? wp_validate_redirect( esc_url_raw( wp_unslash( (string) $_GET['return_url'] ) ), admin_url( 'admin.php?page=oasi-professional-requests' ) ) : admin_url( 'admin.php?page=oasi-professional-requests' );
	$result = oasi_professional_um_review_request( $user_id, $decision, get_current_user_id() );
	$notice = is_wp_error( $result ) ? 'error' : $decision;

	wp_safe_redirect( add_query_arg( 'oasi_um_notice', $notice, $return_url ) );
	exit;
}
add_action( 'admin_post_oasi_professional_um_decision', 'oasi_professional_um_handle_decision' );
