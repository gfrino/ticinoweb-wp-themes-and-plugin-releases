<?php
/**
 * Secure professional access application workflow.
 *
 * @package OasiDelleSpezieChild
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Ensure the private-entry application page exists only on Oasi. */
function oasi_professional_application_ensure_page(): void {
	if ( get_stylesheet() !== 'oasidellespezie-child-theme' || '1' === get_option( 'oasi_professional_application_page_version' ) ) {
		return;
	}
	$page = get_page_by_path( 'richiesta-professionale', OBJECT, 'page' );
	if ( ! $page instanceof WP_Post ) {
		$page_id = wp_insert_post(
			array(
				'post_type'    => 'page',
				'post_status'  => 'publish',
				'post_name'    => 'richiesta-professionale',
				'post_title'   => 'Richiesta verifica professionale',
				'post_content' => 'Modulo riservato agli account esistenti che richiedono la verifica professionale.',
			)
		);
		if ( is_wp_error( $page_id ) ) {
			return;
		}
	}
	update_option( 'oasi_professional_application_page_version', '1', false );
}
add_action( 'init', 'oasi_professional_application_ensure_page', 9 );

/** Return the canonical application URL. */
function oasi_professional_application_get_url(): string {
	$page = get_page_by_path( 'richiesta-professionale', OBJECT, 'page' );
	if ( $page instanceof WP_Post && 'publish' === $page->post_status ) {
		$url = get_permalink( $page );
		if ( $url ) {
			return (string) $url;
		}
	}
	return home_url( '/richiesta-professionale/' );
}

/** Return existing account data; these values are never duplicated as form inputs. */
function oasi_professional_application_get_account_data( int $user_id ): array {
	$user = get_userdata( $user_id );
	if ( ! $user instanceof WP_User ) {
		return array();
	}
	$meta = static fn( string $key ): string => sanitize_text_field( trim( (string) get_user_meta( $user_id, $key, true ) ) );
	$address_parts = array_filter( array( $meta( 'billing_address_1' ), $meta( 'billing_address_2' ), trim( $meta( 'billing_postcode' ) . ' ' . $meta( 'billing_city' ) ), $meta( 'billing_state' ), $meta( 'billing_country' ) ) );

	return array(
		'name'    => trim( $meta( 'first_name' ) . ' ' . $meta( 'last_name' ) ) ?: sanitize_text_field( $user->display_name ),
		'email'   => sanitize_email( $user->user_email ),
		'company' => $meta( 'billing_company' ),
		'phone'   => $meta( 'billing_phone' ),
		'address' => implode( ', ', $address_parts ),
	);
}

/**
 * Return the current top-level WooCommerce categories shown in the Shop.
 *
 * The professional form deliberately reuses the same category hierarchy and
 * ordering as the dynamic mega menu, so the dashboard remains the only source
 * of truth for additions, renames, reordering and removals.
 *
 * @return array<string,string> Category slug => human-readable name.
 */
function oasi_professional_application_get_interest_choices(): array {
	if ( ! function_exists( 'oasi_get_megamenu_tree' ) ) {
		return array();
	}

	$choices = array();
	foreach ( oasi_get_megamenu_tree() as $family ) {
		$term_id = absint( $family['term_id'] ?? 0 );
		if ( $term_id < 1 ) {
			continue;
		}

		$term = get_term( $term_id, 'product_cat' );
		if ( ! $term instanceof WP_Term || 'uncategorized' === $term->slug ) {
			continue;
		}

		$slug = sanitize_key( (string) $term->slug );
		$name = html_entity_decode( (string) ( $family['title'] ?? $term->name ), ENT_QUOTES, 'UTF-8' );
		if ( '' !== $slug && '' !== $name ) {
			$choices[ $slug ] = $name;
		}
	}

	return $choices;
}

/** Generate signed anti-bot and idempotency fields. */
function oasi_professional_application_security_fields(): array {
	$started = (string) time();
	$request = wp_generate_uuid4();
	return array(
		'started_at'  => $started,
		'started_sig' => wp_hash( $started . '|oasi_professional_application' ),
		'request_id'  => $request,
		'request_sig' => wp_hash( $request . '|oasi_professional_request' ),
	);
}

/** Validate and sanitize request-specific data without side effects. */
function oasi_professional_application_validate( array $source, WP_User $user ) {
	$clean = static fn( string $key ): string => sanitize_text_field( wp_unslash( (string) ( $source[ $key ] ?? '' ) ) );
	if ( '' !== $clean( 'oasi_professional_company_fax' ) ) {
		return new WP_Error( 'spam', __( 'Invio non valido. Ricarica la pagina e riprova.', 'oasidellespezie-child-theme' ) );
	}

	$started     = $clean( 'oasi_professional_started_at' );
	$started_sig = $clean( 'oasi_professional_started_sig' );
	$request_id  = $clean( 'oasi_professional_request_id' );
	$request_sig = $clean( 'oasi_professional_request_sig' );
	if ( ! ctype_digit( $started ) || ! hash_equals( wp_hash( $started . '|oasi_professional_application' ), $started_sig ) || time() - (int) $started < 2 || time() - (int) $started > DAY_IN_SECONDS ) {
		return new WP_Error( 'security', __( 'La sessione del modulo è scaduta. Ricarica la pagina.', 'oasidellespezie-child-theme' ) );
	}
	if ( ! preg_match( '/^[A-Za-z0-9-]{8,128}$/', $request_id ) || ! hash_equals( wp_hash( $request_id . '|oasi_professional_request' ), $request_sig ) ) {
		return new WP_Error( 'security', __( 'La richiesta non è valida. Ricarica la pagina.', 'oasidellespezie-child-theme' ) );
	}

	$interest_choices = oasi_professional_application_get_interest_choices();
	$allowed = array(
		'legal_form'    => array( 'ditta-individuale', 'sagl', 'sa', 'associazione', 'ente-pubblico', 'altra' ),
		'sector'        => array( 'ristorazione', 'hotellerie', 'produzione', 'vendita', 'benessere', 'formazione', 'altro' ),
		'customer_type' => array( 'utilizzatore', 'rivenditore', 'produttore', 'distributore', 'altro' ),
		'interests'     => array_keys( $interest_choices ),
	);

	$data = array(
		'request_id'      => $request_id,
		'company_uid'     => strtoupper( $clean( 'company_uid' ) ),
		'legal_form'      => $clean( 'legal_form' ),
		'website'         => esc_url_raw( wp_unslash( (string) ( $source['website'] ?? '' ) ) ),
		'sector'          => $clean( 'sector' ),
		'activity'        => sanitize_textarea_field( wp_unslash( (string) ( $source['activity'] ?? '' ) ) ),
		'customer_type' => $clean( 'customer_type' ),
		'message'       => sanitize_textarea_field( wp_unslash( (string) ( $source['message'] ?? '' ) ) ),
		'privacy'       => $clean( 'privacy' ),
		'truth'         => $clean( 'truth' ),
	);
	$raw_interests = isset( $source['interests'] ) && is_array( $source['interests'] ) ? $source['interests'] : array();
	$data['interests'] = array_values( array_intersect( $allowed['interests'], array_map( 'sanitize_key', wp_unslash( $raw_interests ) ) ) );

	if ( '' === $data['company_uid'] || '' === $data['activity'] || '1' !== $data['privacy'] || '1' !== $data['truth'] || empty( $data['interests'] ) ) {
		return new WP_Error( 'invalid', __( 'Completa tutti i campi obbligatori e accetta le dichiarazioni.', 'oasidellespezie-child-theme' ) );
	}
	if ( ! preg_match( '/^CHE[- .]?\d{3}[. ]?\d{3}[. ]?\d{3}$/i', $data['company_uid'] ) ) {
		return new WP_Error( 'invalid_uid', __( 'Inserisci un numero UID nel formato CHE-123.456.789.', 'oasidellespezie-child-theme' ) );
	}
	foreach ( array( 'legal_form', 'sector', 'customer_type' ) as $key ) {
		if ( ! in_array( $data[ $key ], $allowed[ $key ], true ) ) {
			return new WP_Error( 'invalid', __( 'Una selezione non è valida.', 'oasidellespezie-child-theme' ) );
		}
	}
	if ( oasi_contact_text_length( $data['activity'] ) > 2000 || oasi_contact_text_length( $data['message'] ) > 2000 || oasi_contact_text_length( $data['website'] ) > 250 ) {
		return new WP_Error( 'invalid', __( 'Uno o più campi superano la lunghezza consentita.', 'oasidellespezie-child-theme' ) );
	}
	$data['user_id'] = $user->ID;
	return $data;
}

/** Send, register and mark one professional request pending. */
function oasi_professional_application_process( array $source, WP_User $user ) {
	$data = oasi_professional_application_validate( $source, $user );
	if ( is_wp_error( $data ) ) {
		return $data;
	}
	$account = oasi_professional_application_get_account_data( $user->ID );
	if ( empty( $account['email'] ) ) {
		return new WP_Error( 'account', __( 'Completa l’email del tuo account prima di inviare la richiesta.', 'oasidellespezie-child-theme' ) );
	}

	$request_key = 'oasi_contact_once_professional_' . substr( wp_hash( $data['request_id'] . '|oasi_professional_once' ), 0, 32 );
	$rate_key    = 'oasi_contact_rate_professional_' . substr( wp_hash( (string) $user->ID . '|oasi_professional_rate' ), 0, 32 );
	$held = array();
	foreach ( array( $request_key => DAY_IN_SECONDS, $rate_key => 300 ) as $key => $ttl ) {
		$owner = oasi_contact_reserve( $key, $ttl );
		if ( false === $owner ) {
			oasi_contact_release_reservations( $held );
			return new WP_Error( $key === $request_key ? 'duplicate' : 'rate_limited', __( 'La richiesta risulta già inviata o troppo recente.', 'oasidellespezie-child-theme' ) );
		}
		$held[ $key ] = $owner;
	}

	$um_result = function_exists( 'oasi_professional_um_sync_request' )
		? oasi_professional_um_sync_request( $data, $user, $account )
		: new WP_Error( 'ultimate_member_unavailable', __( 'Il servizio di verifica professionale non è disponibile. Riprova più tardi.', 'oasidellespezie-child-theme' ) );
	if ( is_wp_error( $um_result ) ) {
		oasi_contact_release_reservations( $held );
		return $um_result;
	}

	$labels = array(
		'company_uid' => 'UID/CHE', 'legal_form' => 'Forma giuridica', 'website' => 'Sito web', 'sector' => 'Settore', 'activity' => 'Attività',
		'customer_type' => 'Tipologia cliente', 'interests' => 'Interessi', 'message' => 'Note',
	);
	$lines = array( 'RICHIESTA VERIFICA PROFESSIONALE', '', 'DATI ACCOUNT ESISTENTE', 'Utente: #' . $user->ID, 'Nome: ' . ( $account['name'] ?: '—' ), 'Azienda: ' . ( $account['company'] ?: '—' ), 'Email: ' . $account['email'], 'Telefono: ' . ( $account['phone'] ?: '—' ), 'Indirizzo: ' . ( $account['address'] ?: '—' ), '', 'DATI RICHIESTA' );
	foreach ( $labels as $key => $label ) {
		if ( 'interests' === $key ) {
			$value = implode( ', ', array_map( static fn( string $slug ): string => $interest_choices[ $slug ] ?? $slug, $data[ $key ] ) );
		} else {
			$value = is_array( $data[ $key ] ) ? implode( ', ', $data[ $key ] ) : ( $data[ $key ] ?: '—' );
		}
		$lines[] = $label . ': ' . $value;
	}
	$message = implode( "\n", $lines );
	$to = sanitize_email( (string) get_option( 'ticinoweb_contact_email', '' ) );
	if ( ! is_email( $to ) ) {
		$to = sanitize_email( (string) get_option( 'admin_email', '' ) );
	}
	$mail_sent = is_email( $to ) && wp_mail( $to, 'Richiesta verifica professionale — ' . ( $account['company'] ?: $account['name'] ), $message, array( 'Content-Type: text/plain; charset=UTF-8', 'Reply-To: ' . $account['email'] ) );
	update_user_meta( $user->ID, 'oasi_professional_notification_status', $mail_sent ? 'sent' : 'failed' );
	if ( ! $mail_sent ) {
		error_log( 'Oasi Professional: richiesta salvata in Ultimate Member, ma notifica email non inviata.' );
	}

	global $wpdb;
	$inserted = $wpdb->insert(
		$wpdb->prefix . 'ticinoweb_form_submissions',
		array( 'data_invio' => current_time( 'mysql' ), 'nome' => $account['company'] ?: $account['name'], 'email' => $account['email'], 'telefono' => $account['phone'], 'oggetto' => 'Richiesta verifica professionale', 'messaggio' => $message, 'letto' => 0 ),
		array( '%s', '%s', '%s', '%s', '%s', '%s', '%d' )
	);
	if ( false === $inserted ) {
		error_log( 'Oasi Professional: richiesta inviata ma non registrata nella tabella ticinoWEB.' );
	}
	return array( 'status' => 'sent', 'mail_sent' => $mail_sent );
}

/** Handle authenticated applications and redirect safely. */
function oasi_professional_application_handle(): void {
	check_admin_referer( 'oasi_professional_application_submit', 'oasi_professional_nonce' );
	if ( ! is_user_logged_in() || 'customer' !== oasi_professional_get_access_state() ) {
		wp_safe_redirect( add_query_arg( 'application_status', 'access', oasi_professional_application_get_url() ) );
		exit;
	}
	$user   = wp_get_current_user();
	$source = is_array( $_POST ) ? $_POST : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Dedicated validator sanitizes all fields.
	$result = oasi_professional_application_process( $source, $user );
	$status = is_wp_error( $result ) ? $result->get_error_code() : 'sent';
	wp_safe_redirect( add_query_arg( 'application_status', sanitize_key( $status ), oasi_professional_application_get_url() ) . '#richiesta-professionale' );
	exit;
}
add_action( 'admin_post_oasi_professional_application_submit', 'oasi_professional_application_handle' );

/** Route only the canonical hidden-entry page. */
function oasi_professional_application_template_include( string $template ): string {
	if ( ! is_page( 'richiesta-professionale' ) ) {
		return $template;
	}
	$application_template = get_stylesheet_directory() . '/page-richiesta-professionale.php';
	return is_file( $application_template ) ? $application_template : $template;
}
add_filter( 'template_include', 'oasi_professional_application_template_include', 100 );
