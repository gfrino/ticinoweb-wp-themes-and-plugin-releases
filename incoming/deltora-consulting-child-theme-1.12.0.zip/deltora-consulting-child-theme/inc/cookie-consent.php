<?php
/**
 * Deltora-specific consent surface for the external Google Maps embed.
 *
 * @package DeltoraConsultingChildTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Determine whether the consent interface is enabled in tW SEO.
 *
 * @return bool
 */
function deltora_consulting_cookie_consent_is_enabled() {
	return '1' === (string) get_option( 'tw_cookie_banner_enable', '' );
}

/**
 * Replace the parent banner and disable unused visit analytics on Deltora.
 *
 * The child interface retains the parent CMS switch while presenting only the
 * processing that actually exists on this site: necessary storage and the
 * optional Google Maps embed.
 *
 * @return void
 */
function deltora_consulting_replace_parent_cookie_consent() {
	remove_action( 'wp_footer', 'tw_seo_cookie_banner_render', 100 );
	remove_action( 'wp_head', 'tw_seo_google_analytics_render', 5 );
	remove_action( 'wp_footer', 'ticinoweb_print_visit_beacon', 99 );
}
add_action( 'after_setup_theme', 'deltora_consulting_replace_parent_cookie_consent', 100 );

/**
 * Render the Deltora cookie banner and preference dialog.
 *
 * @return void
 */
function deltora_consulting_render_cookie_consent() {
	if ( is_admin() || ! deltora_consulting_cookie_consent_is_enabled() ) {
		return;
	}

	$privacy_url = get_privacy_policy_url();
	if ( ! $privacy_url ) {
		$privacy_url = (string) get_option( 'tw_privacy_policy_url', '' );
	}
	?>
	<section
		id="deltora-cookie-banner"
		class="deltora-cookie-banner"
		aria-labelledby="deltora-cookie-banner-title"
		aria-describedby="deltora-cookie-banner-description"
		hidden
	>
		<div class="deltora-cookie-banner__copy">
			<h2 id="deltora-cookie-banner-title"><?php esc_html_e( 'La tua privacy, in modo chiaro', 'deltora-consulting-child-theme' ); ?></h2>
			<p id="deltora-cookie-banner-description">
				<?php esc_html_e( 'Utilizziamo soltanto memorie tecniche necessarie e, con il tuo consenso, Google Maps per mostrarti la nostra sede.', 'deltora-consulting-child-theme' ); ?>
				<?php if ( $privacy_url ) : ?>
					<a href="<?php echo esc_url( $privacy_url ); ?>"><?php esc_html_e( 'Leggi l’informativa privacy', 'deltora-consulting-child-theme' ); ?></a>.
				<?php endif; ?>
			</p>
		</div>
		<div class="deltora-cookie-banner__actions">
			<button type="button" class="deltora-cookie-button deltora-cookie-button--secondary" data-cookie-reject>
				<?php esc_html_e( 'Solo necessari', 'deltora-consulting-child-theme' ); ?>
			</button>
			<button type="button" class="deltora-cookie-button deltora-cookie-button--outline" data-cookie-customize>
				<?php esc_html_e( 'Personalizza', 'deltora-consulting-child-theme' ); ?>
			</button>
			<button type="button" class="deltora-cookie-button deltora-cookie-button--primary" data-cookie-accept>
				<?php esc_html_e( 'Accetta Google Maps', 'deltora-consulting-child-theme' ); ?>
			</button>
		</div>
	</section>

	<div id="deltora-cookie-modal" class="deltora-cookie-modal" hidden>
		<div class="deltora-cookie-modal__overlay" data-cookie-close aria-hidden="true"></div>
		<div
			class="deltora-cookie-modal__dialog"
			role="dialog"
			aria-modal="true"
			aria-labelledby="deltora-cookie-modal-title"
			aria-describedby="deltora-cookie-modal-description"
			tabindex="-1"
		>
			<header class="deltora-cookie-modal__header">
				<h2 id="deltora-cookie-modal-title"><?php esc_html_e( 'Preferenze cookie', 'deltora-consulting-child-theme' ); ?></h2>
				<button type="button" class="deltora-cookie-modal__close" data-cookie-close aria-label="<?php esc_attr_e( 'Chiudi le preferenze cookie', 'deltora-consulting-child-theme' ); ?>">
					<span aria-hidden="true">&times;</span>
				</button>
			</header>

			<div class="deltora-cookie-modal__body">
				<p id="deltora-cookie-modal-description">
					<?php esc_html_e( 'Puoi scegliere se autorizzare Google Maps. La scelta può essere modificata in qualsiasi momento dal collegamento nel footer.', 'deltora-consulting-child-theme' ); ?>
				</p>

				<div class="deltora-cookie-option">
					<div class="deltora-cookie-option__copy">
						<h3 id="deltora-cookie-necessary-label"><?php esc_html_e( 'Memorie necessarie', 'deltora-consulting-child-theme' ); ?></h3>
						<p><?php esc_html_e( 'Conservano la scelta privacy e assicurano le funzioni essenziali del sito. Non possono essere disattivate.', 'deltora-consulting-child-theme' ); ?></p>
					</div>
					<input class="deltora-cookie-switch" type="checkbox" role="switch" checked disabled aria-labelledby="deltora-cookie-necessary-label">
				</div>

				<div class="deltora-cookie-option">
					<div class="deltora-cookie-option__copy">
						<h3 id="deltora-cookie-maps-label"><?php esc_html_e( 'Contenuti esterni — Google Maps', 'deltora-consulting-child-theme' ); ?></h3>
						<p><?php esc_html_e( 'Carica la mappa interattiva della sede. Solo dopo l’attivazione il browser stabilisce una connessione con Google.', 'deltora-consulting-child-theme' ); ?></p>
					</div>
					<input id="deltora-cookie-maps" class="deltora-cookie-switch" type="checkbox" role="switch" aria-labelledby="deltora-cookie-maps-label">
				</div>
			</div>

			<footer class="deltora-cookie-modal__footer">
				<button type="button" class="deltora-cookie-button deltora-cookie-button--secondary" data-cookie-necessary>
					<?php esc_html_e( 'Solo necessari', 'deltora-consulting-child-theme' ); ?>
				</button>
				<button type="button" class="deltora-cookie-button deltora-cookie-button--primary" data-cookie-save>
					<?php esc_html_e( 'Salva selezione', 'deltora-consulting-child-theme' ); ?>
				</button>
			</footer>
		</div>
	</div>
	<?php
}
add_action( 'wp_footer', 'deltora_consulting_render_cookie_consent', 100 );
