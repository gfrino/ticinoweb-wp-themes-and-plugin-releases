<?php
/**
 * Versioned Glute Lab catalogue and public API.
 *
 * No order, credit, booking or payment state is stored here.
 *
 * @package GluteLabChildTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'GLUTELAB_CATALOG_SCHEMA_VERSION', 2 );
define( 'GLUTELAB_CATALOG_MIGRATION_VERSION', '1.0.0' );

/** Return the client-approved initial catalogue. */
function glutelab_catalog_defaults() {
	$contact = home_url( '/contatti/' );
	$groups  = array(
		'personal' => array( 'id' => 'personal', 'title' => 'Glute Lab Personal', 'order_label' => '01', 'description' => 'Lezioni individuali One to One: un percorso personalizzato, con attenzione dedicata.', 'status' => 'active', 'sort_order' => 1, 'image_id' => 0, 'cta_label' => 'Scopri Personal', 'cta_url' => '', 'max_participants' => 1, 'mode' => 'individual' ),
		'team' => array( 'id' => 'team', 'title' => 'Glute Lab Team', 'order_label' => '02', 'description' => 'Lezioni in piccoli gruppi, massimo 4 persone: motivazione e attenzione in un ambiente raccolto.', 'status' => 'active', 'sort_order' => 2, 'image_id' => 0, 'cta_label' => 'Scopri Team', 'cta_url' => '', 'max_participants' => 4, 'mode' => 'group' ),
		'full-experience' => array( 'id' => 'full-experience', 'title' => 'Glute Lab Full Experience', 'order_label' => '03', 'description' => 'Un percorso integrato di 3 mesi per combinare allenamento, alimentazione e palestra.', 'status' => 'active', 'sort_order' => 3, 'image_id' => 0, 'cta_label' => 'Scopri Full Experience', 'cta_url' => '', 'max_participants' => null, 'mode' => 'integrated' ),
		'nutrition' => array( 'id' => 'nutrition', 'title' => 'Glute Lab Nutrition', 'order_label' => '04', 'description' => 'Supporto digitale per seguire l’alimentazione e monitorare i progressi.', 'status' => 'active', 'sort_order' => 4, 'image_id' => 0, 'cta_label' => 'Scopri Nutrition', 'cta_url' => '', 'max_participants' => null, 'mode' => 'digital' ),
	);
	$base = array(
		'subtitle' => '', 'status' => 'active', 'badge' => '', 'featured' => 0, 'currency' => 'CHF', 'price_suffix' => '', 'price_model' => 'one_time', 'price_period' => '',
		'frequency' => '', 'total_duration' => '', 'session_minutes' => null, 'validity' => '', 'gym_months' => 0, 'includes_nutrition_app' => 0,
		'includes_bmi_monitoring' => 0, 'includes_progress_monitoring' => 0, 'benefits' => array(), 'commercial_notes' => '', 'cta_label' => 'Richiedi informazioni',
		'cta_url' => $contact, 'online_purchase_available' => 0, 'payment_in_person_available' => 0,
	);
	$packages = array(
		'personal-single' => array( 'id' => 'personal-single', 'group_id' => 'personal', 'title' => 'Lezione singola', 'description' => '1 lezione individuale', 'sort_order' => 1, 'price' => 59.0, 'mode' => 'individual', 'lessons_purchased' => 1, 'bonus_lessons' => 0, 'max_participants' => 1 ),
		'personal-start-5-plus-1' => array( 'id' => 'personal-start-5-plus-1', 'group_id' => 'personal', 'title' => 'Personal Start 5+1', 'description' => '6 lezioni + 1 mese di palestra ASCO Fit', 'sort_order' => 2, 'price' => 295.0, 'mode' => 'individual', 'lessons_purchased' => 5, 'bonus_lessons' => 1, 'max_participants' => 1, 'gym_months' => 1 ),
		'personal-evolution-10-plus-1' => array( 'id' => 'personal-evolution-10-plus-1', 'group_id' => 'personal', 'title' => 'Personal Evolution 10+1', 'description' => '11 lezioni + 2 mesi di palestra ASCO Fit', 'sort_order' => 3, 'price' => 490.0, 'mode' => 'individual', 'lessons_purchased' => 10, 'bonus_lessons' => 1, 'max_participants' => 1, 'gym_months' => 2 ),
		'team-single' => array( 'id' => 'team-single', 'group_id' => 'team', 'title' => 'Team Single', 'description' => '1 lezione di gruppo', 'sort_order' => 1, 'price' => 49.0, 'mode' => 'group', 'lessons_purchased' => 1, 'bonus_lessons' => 0, 'max_participants' => 4 ),
		'team-start-5-plus-1' => array( 'id' => 'team-start-5-plus-1', 'group_id' => 'team', 'title' => 'Team Start 5+1', 'description' => '6 lezioni di gruppo', 'sort_order' => 2, 'price' => 195.0, 'mode' => 'group', 'lessons_purchased' => 5, 'bonus_lessons' => 1, 'max_participants' => 4 ),
		'team-evolution-10-plus-1' => array( 'id' => 'team-evolution-10-plus-1', 'group_id' => 'team', 'title' => 'Team Evolution 10+1', 'description' => '11 lezioni di gruppo', 'sort_order' => 3, 'price' => 290.0, 'mode' => 'group', 'lessons_purchased' => 10, 'bonus_lessons' => 1, 'max_participants' => 4 ),
		'full-experience-3-months' => array( 'id' => 'full-experience-3-months', 'group_id' => 'full-experience', 'title' => 'Full Experience', 'description' => '', 'sort_order' => 1, 'price' => 790.0, 'mode' => 'integrated', 'lessons_purchased' => null, 'bonus_lessons' => null, 'max_participants' => null, 'frequency' => '2 lezioni a settimana', 'total_duration' => '3 mesi', 'gym_months' => 3, 'includes_nutrition_app' => 1, 'includes_bmi_monitoring' => 1, 'includes_progress_monitoring' => 1 ),
		'nutrition-bmi-monthly' => array( 'id' => 'nutrition-bmi-monthly', 'group_id' => 'nutrition', 'title' => 'Nutrition + BMI', 'description' => 'App Nutrition e monitoraggio BMI', 'sort_order' => 1, 'price' => 39.0, 'price_suffix' => '/mese', 'price_model' => 'display_monthly', 'price_period' => 'mese', 'mode' => 'digital', 'lessons_purchased' => null, 'bonus_lessons' => null, 'max_participants' => null, 'includes_nutrition_app' => 1, 'includes_bmi_monitoring' => 1 ),
	);
	foreach ( $packages as $id => $package ) {
		$packages[ $id ] = array_merge( $base, $package );
		$packages[ $id ]['cta_url'] = add_query_arg( array( 'package' => $id ), home_url( '/acquista-o-prenota/' ) );
	}
	return array(
		'schema_version' => GLUTELAB_CATALOG_SCHEMA_VERSION,
		'migration_version' => GLUTELAB_CATALOG_MIGRATION_VERSION,
		'general' => array( 'title' => 'Scegli il tuo percorso', 'subtitle' => 'Costruisci i tuoi risultati.', 'closing_text' => 'Per informazioni e prenotazioni, contatta ASCO Fit.', 'cta_label' => 'Richiedi informazioni', 'cta_url' => $contact ),
		'groups' => $groups,
		'packages' => $packages,
		'migration' => array( 'source' => 'official-price-list', 'notices' => array() ),
	);
}

/** Backward-compatible alias for integrations that used the old defaults helper. */
function glutelab_package_defaults() { return array_values( glutelab_catalog_defaults()['packages'] ); }

function glutelab_sanitize_price( $value, $fallback = 0.0 ) {
	if ( ! is_scalar( $value ) ) return (float) $fallback;
	$value = str_replace( array( 'CHF', ' ', '’', "'", '.–', '.-' ), '', trim( (string) $value ) );
	$value = str_replace( ',', '.', $value );
	return preg_match( '/^\d{1,8}(?:\.\d{1,2})?$/', $value ) ? round( (float) $value, 2 ) : (float) $fallback;
}

function glutelab_optional_int( $value, $fallback = null ) {
	if ( null === $value || '' === trim( (string) $value ) ) return null;
	return is_numeric( $value ) && (int) $value >= 0 ? (int) $value : $fallback;
}

function glutelab_sanitize_session_minutes( $value ) {
	$minutes = glutelab_optional_int( $value );
	return null !== $minutes && $minutes >= 5 && $minutes <= 240 ? $minutes : null;
}

function glutelab_sanitize_lines( $value ) {
	if ( is_string( $value ) ) $value = preg_split( '/\r\n|\r|\n/', $value );
	return array_values( array_filter( array_map( 'sanitize_text_field', is_array( $value ) ? $value : array() ), static fn( $v ) => '' !== $v ) );
}

function glutelab_normalize_group( $raw, $fallback = array() ) {
	$raw = is_array( $raw ) ? wp_unslash( $raw ) : array();
	$fallback = is_array( $fallback ) ? $fallback : array();
	$id = sanitize_key( $raw['id'] ?? ( $fallback['id'] ?? '' ) );
	if ( '' === $id ) $id = 'group-' . str_replace( '-', '', wp_generate_uuid4() );
	$mode = sanitize_key( $raw['mode'] ?? ( $fallback['mode'] ?? 'individual' ) );
	if ( ! in_array( $mode, array( 'individual', 'group', 'integrated', 'digital' ), true ) ) $mode = 'individual';
	$status = sanitize_key( $raw['status'] ?? ( $fallback['status'] ?? 'active' ) );
	if ( ! in_array( $status, array( 'active', 'inactive' ), true ) ) $status = 'active';
	return array(
		'id' => $id, 'title' => sanitize_text_field( $raw['title'] ?? ( $fallback['title'] ?? '' ) ), 'order_label' => sanitize_text_field( $raw['order_label'] ?? ( $fallback['order_label'] ?? '' ) ),
		'description' => sanitize_textarea_field( $raw['description'] ?? ( $fallback['description'] ?? '' ) ), 'status' => $status,
		'sort_order' => absint( $raw['sort_order'] ?? ( $fallback['sort_order'] ?? 0 ) ), 'image_id' => absint( $raw['image_id'] ?? ( $fallback['image_id'] ?? 0 ) ),
		'cta_label' => sanitize_text_field( $raw['cta_label'] ?? ( $fallback['cta_label'] ?? '' ) ), 'cta_url' => esc_url_raw( $raw['cta_url'] ?? ( $fallback['cta_url'] ?? '' ) ),
		'max_participants' => glutelab_optional_int( $raw['max_participants'] ?? ( $fallback['max_participants'] ?? null ) ), 'mode' => $mode,
	);
}

function glutelab_normalize_package( $raw, $fallback = array() ) {
	$raw = is_array( $raw ) ? wp_unslash( $raw ) : array();
	$fallback = is_array( $fallback ) ? $fallback : array();
	$id = sanitize_key( $raw['id'] ?? ( $fallback['id'] ?? '' ) );
	if ( '' === $id ) $id = 'pkg-' . str_replace( '-', '', wp_generate_uuid4() );
	$mode = sanitize_key( $raw['mode'] ?? ( $fallback['mode'] ?? 'individual' ) );
	if ( ! in_array( $mode, array( 'individual', 'group', 'integrated', 'digital' ), true ) ) $mode = $fallback['mode'] ?? 'individual';
	$model = sanitize_key( $raw['price_model'] ?? ( $fallback['price_model'] ?? 'one_time' ) );
	if ( ! in_array( $model, array( 'one_time', 'display_monthly' ), true ) ) $model = 'one_time';
	$status = sanitize_key( $raw['status'] ?? ( $fallback['status'] ?? 'active' ) );
	if ( ! in_array( $status, array( 'active', 'inactive' ), true ) ) $status = 'active';
	return array(
		'id' => $id, 'group_id' => sanitize_key( $raw['group_id'] ?? ( $fallback['group_id'] ?? 'personal' ) ), 'title' => sanitize_text_field( $raw['title'] ?? ( $fallback['title'] ?? '' ) ),
		'subtitle' => sanitize_text_field( $raw['subtitle'] ?? ( $fallback['subtitle'] ?? '' ) ), 'description' => sanitize_textarea_field( $raw['description'] ?? ( $fallback['description'] ?? '' ) ),
		'status' => $status, 'sort_order' => absint( $raw['sort_order'] ?? ( $fallback['sort_order'] ?? 0 ) ), 'badge' => sanitize_text_field( $raw['badge'] ?? ( $fallback['badge'] ?? '' ) ),
		'featured' => empty( $raw['featured'] ) ? 0 : 1, 'price' => glutelab_sanitize_price( $raw['price'] ?? ( $fallback['price'] ?? 0 ), $fallback['price'] ?? 0 ),
		'currency' => 'CHF', 'price_suffix' => sanitize_text_field( $raw['price_suffix'] ?? ( $fallback['price_suffix'] ?? '' ) ), 'price_model' => $model,
		'price_period' => sanitize_text_field( $raw['price_period'] ?? ( $fallback['price_period'] ?? '' ) ), 'mode' => $mode,
		'lessons_purchased' => glutelab_optional_int( $raw['lessons_purchased'] ?? ( $fallback['lessons_purchased'] ?? null ) ), 'bonus_lessons' => glutelab_optional_int( $raw['bonus_lessons'] ?? ( $fallback['bonus_lessons'] ?? null ) ),
		'frequency' => sanitize_text_field( $raw['frequency'] ?? ( $fallback['frequency'] ?? '' ) ), 'total_duration' => sanitize_text_field( $raw['total_duration'] ?? ( $fallback['total_duration'] ?? '' ) ),
		'session_minutes' => glutelab_sanitize_session_minutes( $raw['session_minutes'] ?? ( $fallback['session_minutes'] ?? null ) ), 'max_participants' => glutelab_optional_int( $raw['max_participants'] ?? ( $fallback['max_participants'] ?? null ) ),
		'validity' => sanitize_text_field( $raw['validity'] ?? ( $fallback['validity'] ?? '' ) ), 'gym_months' => glutelab_optional_int( $raw['gym_months'] ?? ( $fallback['gym_months'] ?? 0 ), 0 ),
		'includes_nutrition_app' => empty( $raw['includes_nutrition_app'] ) ? 0 : 1, 'includes_bmi_monitoring' => empty( $raw['includes_bmi_monitoring'] ) ? 0 : 1,
		'includes_progress_monitoring' => empty( $raw['includes_progress_monitoring'] ) ? 0 : 1, 'benefits' => glutelab_sanitize_lines( $raw['benefits'] ?? ( $fallback['benefits'] ?? array() ) ),
		'commercial_notes' => sanitize_textarea_field( $raw['commercial_notes'] ?? ( $fallback['commercial_notes'] ?? '' ) ), 'cta_label' => sanitize_text_field( $raw['cta_label'] ?? ( $fallback['cta_label'] ?? 'Richiedi informazioni' ) ),
		'cta_url' => esc_url_raw( $raw['cta_url'] ?? ( $fallback['cta_url'] ?? home_url( '/contatti/' ) ) ), 'online_purchase_available' => empty( $raw['online_purchase_available'] ) ? 0 : 1,
		'payment_in_person_available' => empty( $raw['payment_in_person_available'] ) ? 0 : 1,
	);
}

function glutelab_sort_catalog_items( $items ) {
	usort( $items, static function ( $a, $b ) { $order = (int) $a['sort_order'] <=> (int) $b['sort_order']; return 0 !== $order ? $order : strcasecmp( $a['title'], $b['title'] ); } );
	return array_values( $items );
}

function glutelab_normalize_catalog( $raw ) {
	$defaults = glutelab_catalog_defaults();
	$raw = is_array( $raw ) ? $raw : array();
	$general_raw = is_array( $raw['general'] ?? null ) ? $raw['general'] : array();
	$general = array(
		'title' => sanitize_text_field( $general_raw['title'] ?? $defaults['general']['title'] ), 'subtitle' => sanitize_text_field( $general_raw['subtitle'] ?? $defaults['general']['subtitle'] ),
		'closing_text' => sanitize_textarea_field( $general_raw['closing_text'] ?? $defaults['general']['closing_text'] ), 'cta_label' => sanitize_text_field( $general_raw['cta_label'] ?? $defaults['general']['cta_label'] ),
		'cta_url' => esc_url_raw( $general_raw['cta_url'] ?? $defaults['general']['cta_url'] ),
	);
	$groups = array();
	foreach ( is_array( $raw['groups'] ?? null ) ? $raw['groups'] : $defaults['groups'] as $key => $group ) {
		$fallback = $defaults['groups'][ $key ] ?? array(); $normalized = glutelab_normalize_group( $group, $fallback ); $groups[ $normalized['id'] ] = $normalized;
	}
	$packages = array();
	foreach ( is_array( $raw['packages'] ?? null ) ? $raw['packages'] : $defaults['packages'] as $key => $package ) {
		$fallback = $defaults['packages'][ $key ] ?? array(); $normalized = glutelab_normalize_package( $package, $fallback ); $packages[ $normalized['id'] ] = $normalized;
	}
	return array( 'schema_version' => GLUTELAB_CATALOG_SCHEMA_VERSION, 'migration_version' => sanitize_text_field( $raw['migration_version'] ?? GLUTELAB_CATALOG_MIGRATION_VERSION ), 'general' => $general, 'groups' => $groups, 'packages' => $packages, 'migration' => is_array( $raw['migration'] ?? null ) ? $raw['migration'] : $defaults['migration'] );
}

/**
 * Apply the focused duration editor to the canonical catalogue.
 *
 * Empty values deliberately clear a duration. Invalid non-empty values are
 * ignored so a malformed request cannot erase a working configuration.
 *
 * @param array $catalog   Current catalogue.
 * @param array $durations Package IDs mapped to duration values.
 * @return array
 */
function glutelab_apply_package_durations( $catalog, $durations ) {
	$catalog   = glutelab_normalize_catalog( $catalog );
	$durations = is_array( $durations ) ? wp_unslash( $durations ) : array();

	foreach ( $durations as $package_id => $raw_duration ) {
		$package_id = sanitize_key( $package_id );
		if ( ! isset( $catalog['packages'][ $package_id ] ) || ! is_scalar( $raw_duration ) ) continue;

		$raw_duration = trim( (string) $raw_duration );
		if ( '' === $raw_duration ) {
			$catalog['packages'][ $package_id ]['session_minutes'] = null;
			continue;
		}

		$minutes = glutelab_sanitize_session_minutes( $raw_duration );
		if ( null !== $minutes ) $catalog['packages'][ $package_id ]['session_minutes'] = $minutes;
	}

	return glutelab_normalize_catalog( $catalog );
}

function glutelab_get_catalog() {
	$stored = get_option( 'glutelab_catalog', null );
	$catalog = glutelab_normalize_catalog( is_array( $stored ) ? $stored : glutelab_catalog_defaults() );
	$filtered = apply_filters( 'glutelab_catalog_data', $catalog );
	return glutelab_normalize_catalog( is_array( $filtered ) ? $filtered : $catalog );
}

/** Make CMS changes visible immediately on cached public pages. */
function glutelab_app_purge_public_cache() {
	if ( has_action( 'litespeed_purge_all' ) ) do_action( 'litespeed_purge_all' );
	if ( function_exists( 'wp_cache_flush_runtime' ) ) wp_cache_flush_runtime();
}

/** Purge only after WordPress has actually changed the canonical catalogue. */
function glutelab_catalog_option_changed() { glutelab_app_purge_public_cache(); }
if ( function_exists( 'add_action' ) ) {
	add_action( 'update_option_glutelab_catalog', 'glutelab_catalog_option_changed', 10, 3 );
	add_action( 'add_option_glutelab_catalog', 'glutelab_catalog_option_changed', 10, 2 );
}

function glutelab_get_package_groups( $include_inactive = false ) {
	$groups = glutelab_sort_catalog_items( array_values( glutelab_get_catalog()['groups'] ) );
	$groups = apply_filters( 'glutelab_package_groups', $groups, (bool) $include_inactive );
	$groups = array_map( 'glutelab_normalize_group', is_array( $groups ) ? $groups : array() );
	if ( ! $include_inactive ) $groups = array_values( array_filter( $groups, static fn( $g ) => 'active' === $g['status'] ) );
	return glutelab_sort_catalog_items( $groups );
}

function glutelab_get_packages( $args = array() ) {
	if ( is_bool( $args ) ) $args = array( 'include_inactive' => $args );
	$args = array_merge( array( 'include_inactive' => false, 'group_id' => '', 'featured' => null, 'limit' => 0 ), is_array( $args ) ? $args : array() );
	$packages = array_values( glutelab_get_catalog()['packages'] );
	$packages = apply_filters( 'glutelab_packages', $packages, $args );
	$packages = array_map( 'glutelab_normalize_package', is_array( $packages ) ? $packages : array() );
	$packages = array_values( array_filter( $packages, static function ( $p ) use ( $args ) {
		if ( ! $args['include_inactive'] && 'active' !== $p['status'] ) return false;
		if ( $args['group_id'] && sanitize_key( $args['group_id'] ) !== $p['group_id'] ) return false;
		if ( null !== $args['featured'] && (bool) $args['featured'] !== (bool) $p['featured'] ) return false;
		return true;
	} ) );
	$packages = glutelab_sort_catalog_items( $packages );
	return $args['limit'] ? array_slice( $packages, 0, absint( $args['limit'] ) ) : $packages;
}

function glutelab_get_package( $package_id ) {
	$id = sanitize_key( $package_id );
	foreach ( glutelab_get_packages( array( 'include_inactive' => true ) ) as $package ) if ( $id === $package['id'] ) return $package;
	return null;
}
function glutelab_get_packages_by_group( $group_id, $include_inactive = false ) { return glutelab_get_packages( array( 'group_id' => $group_id, 'include_inactive' => $include_inactive ) ); }

function glutelab_calculate_total_lessons( $base, $bonus ) {
	if ( null === $base || '' === $base || null === $bonus || '' === $bonus || ! is_numeric( $base ) || ! is_numeric( $bonus ) ) return null;
	return max( 0, (int) $base ) + max( 0, (int) $bonus );
}
function glutelab_format_chf( $amount ) { $amount = (float) $amount; return floor( $amount ) === $amount ? 'CHF ' . number_format( $amount, 0, '.', '’' ) . '.–' : 'CHF ' . number_format( $amount, 2, '.', '’' ); }
function glutelab_package_price_text( $package ) { return glutelab_format_chf( $package['price'] ) . ( $package['price_suffix'] ? ' ' . $package['price_suffix'] : '' ); }
function glutelab_mode_label( $mode ) { return array( 'individual' => 'Individuale · One to One', 'group' => 'Gruppo', 'integrated' => 'Integrato', 'digital' => 'Digitale' )[ $mode ] ?? ucfirst( $mode ); }

function glutelab_new_catalog_id( $prefix ) { return sanitize_key( $prefix ) . '-' . str_replace( '-', '', wp_generate_uuid4() ); }

/** Update only the public catalogue copy while preserving courses and offers. */
function glutelab_update_catalog_general( $catalog, $input ) {
	$catalog = glutelab_normalize_catalog( is_array( $catalog ) ? $catalog : array() );
	return glutelab_normalize_catalog(
		array(
			'general'  => array_merge( $catalog['general'], is_array( $input ) ? $input : array() ),
			'groups'   => $catalog['groups'],
			'packages' => $catalog['packages'],
		)
	);
}

/** Settings API sanitizer. Each submission mutates one explicit catalogue scope. */
function glutelab_sanitize_catalog_option( $input ) {
	$input = is_array( $input ) ? wp_unslash( $input ) : array();
	$stored = get_option( 'glutelab_catalog', null );
	$catalog = glutelab_normalize_catalog( is_array( $stored ) ? $stored : glutelab_catalog_defaults() );
	$action = sanitize_key( $input['action'] ?? 'save' );
	if ( 'save_general' === $action ) {
		$catalog = glutelab_update_catalog_general( $catalog, $input['general'] ?? array() );
	} elseif ( 'save_group' === $action ) {
		$raw = is_array( $input['group'] ?? null ) ? $input['group'] : array(); $id = sanitize_key( $raw['id'] ?? '' ); if ( ! $id ) $id = glutelab_new_catalog_id( 'group' ); $raw['id'] = $id;
		$catalog['groups'][ $id ] = glutelab_normalize_group( $raw, $catalog['groups'][ $id ] ?? array() );
	} elseif ( 'save_package' === $action ) {
		$raw = is_array( $input['package'] ?? null ) ? $input['package'] : array(); $id = sanitize_key( $raw['id'] ?? '' ); if ( ! $id ) $id = glutelab_new_catalog_id( 'pkg' ); $raw['id'] = $id;
		$group_id = sanitize_key( $raw['group_id'] ?? '' );
		if ( isset( $catalog['groups'][ $group_id ] ) ) {
			$raw['mode']             = $catalog['groups'][ $group_id ]['mode'];
			$raw['max_participants'] = $catalog['groups'][ $group_id ]['max_participants'];
		}
		if ( array_key_exists( 'total_lessons', $raw ) ) {
			$total_lessons            = glutelab_optional_int( $raw['total_lessons'] );
			$raw['lessons_purchased'] = $total_lessons;
			$raw['bonus_lessons']     = null === $total_lessons ? null : 0;
		}
		if ( array_key_exists( 'price_model', $raw ) ) {
			$is_monthly          = 'display_monthly' === sanitize_key( $raw['price_model'] );
			$raw['price_suffix'] = $is_monthly ? '/mese' : '';
			$raw['price_period'] = $is_monthly ? 'mese' : '';
		}
		$raw['payment_in_person_available'] = 0;
		$catalog['packages'][ $id ] = glutelab_normalize_package( $raw, $catalog['packages'][ $id ] ?? array() );
	} elseif ( 'delete_package' === $action && ! empty( $input['confirm_delete'] ) ) {
		unset( $catalog['packages'][ sanitize_key( $input['package_id'] ?? '' ) ] );
	} elseif ( in_array( $action, array( 'move_package_up', 'move_package_down' ), true ) ) {
		$id = sanitize_key( $input['package_id'] ?? '' );
		if ( isset( $catalog['packages'][ $id ] ) ) {
			$group_id = $catalog['packages'][ $id ]['group_id']; $siblings = glutelab_sort_catalog_items( array_values( array_filter( $catalog['packages'], static fn( $p ) => $group_id === $p['group_id'] ) ) );
			$index = array_search( $id, array_column( $siblings, 'id' ), true ); $target = 'move_package_up' === $action ? $index - 1 : $index + 1;
			if ( false !== $index && isset( $siblings[ $target ] ) ) { $other = $siblings[ $target ]['id']; $tmp = $catalog['packages'][ $id ]['sort_order']; $catalog['packages'][ $id ]['sort_order'] = $catalog['packages'][ $other ]['sort_order']; $catalog['packages'][ $other ]['sort_order'] = $tmp; }
		}
	} elseif ( 'reorder_packages' === $action ) {
		$ids = array_filter( array_map( 'sanitize_key', explode( ',', (string) ( $input['ordered_ids'] ?? '' ) ) ) );
		foreach ( array_values( $ids ) as $index => $id ) if ( isset( $catalog['packages'][ $id ] ) ) $catalog['packages'][ $id ]['sort_order'] = $index + 1;
	} elseif ( 'delete_group' === $action && ! empty( $input['confirm_delete'] ) ) {
		$id = sanitize_key( $input['group_id'] ?? '' ); $destination = sanitize_key( $input['destination_group'] ?? '' );
		$linked = array_filter( $catalog['packages'], static fn( $p ) => $id === $p['group_id'] );
		if ( ! $linked || ( $destination && $destination !== $id && isset( $catalog['groups'][ $destination ] ) ) ) {
			foreach ( $catalog['packages'] as &$package ) if ( $id === $package['group_id'] ) $package['group_id'] = $destination; unset( $package ); unset( $catalog['groups'][ $id ] );
		} elseif ( function_exists( 'add_settings_error' ) ) add_settings_error( 'glutelab_catalog', 'group_not_deleted', __( 'Il percorso contiene offerte: scegli una destinazione alternativa.', 'glutelab-child-theme' ), 'error' );
	}
	$catalog['schema_version'] = GLUTELAB_CATALOG_SCHEMA_VERSION; $catalog['migration_version'] = GLUTELAB_CATALOG_MIGRATION_VERSION;
	return glutelab_normalize_catalog( $catalog );
}

/** Explicit, one-time legacy migration. Safe to call from the versioned site setup. */
function glutelab_migrate_legacy_catalog() {
	$current = get_option( 'glutelab_catalog', null );
	if ( is_array( $current ) && version_compare( (string) ( $current['migration_version'] ?? '0' ), GLUTELAB_CATALOG_MIGRATION_VERSION, '>=' ) ) return glutelab_normalize_catalog( $current );
	$legacy = get_option( 'glutelab_packages', null ); $catalog = glutelab_catalog_defaults(); $notices = array();
	if ( is_array( $legacy ) ) {
		add_option( 'glutelab_packages_backup_v1', $legacy, '', 'no' );
		$known = array( 'single_lesson', 'five_plus_one', 'ten_plus_one' );
		foreach ( $legacy as $row ) {
			$key = sanitize_key( $row['technical_key'] ?? '' );
			if ( in_array( $key, $known, true ) ) { $notices[] = sprintf( 'Il record legacy %s è nel backup; prezzi e dati ufficiali provengono dal nuovo listino.', sanitize_text_field( $row['title'] ?? $key ) ); continue; }
			$id = sanitize_key( $row['id'] ?? '' ); if ( ! $id ) $id = glutelab_new_catalog_id( 'legacy' );
			$row = array_merge( array( 'id' => $id, 'group_id' => 'personal', 'mode' => 'individual', 'lessons_purchased' => $row['included_lessons'] ?? null, 'commercial_notes' => $row['note'] ?? '', 'max_participants' => 1 ), $row );
			$catalog['packages'][ $id ] = glutelab_normalize_package( $row ); $notices[] = sprintf( 'Offerta manuale legacy preservata con ID %s.', $id );
		}
	}
	$catalog['migration']['source'] = 'glutelab_packages'; $catalog['migration']['notices'] = $notices; $catalog['migration_version'] = GLUTELAB_CATALOG_MIGRATION_VERSION;
	update_option( 'glutelab_catalog', $catalog ); return $catalog;
}

function glutelab_package_inclusions( $package ) {
	$items = $package['benefits'];
	if ( $package['gym_months'] ) $items[] = sprintf( _n( '%d mese di palestra ASCO Fit', '%d mesi di palestra ASCO Fit', $package['gym_months'], 'glutelab-child-theme' ), $package['gym_months'] );
	if ( $package['includes_nutrition_app'] ) $items[] = __( 'App ASCO Fit Nutrition', 'glutelab-child-theme' );
	if ( $package['includes_bmi_monitoring'] ) $items[] = __( 'Monitoraggio BMI', 'glutelab-child-theme' );
	if ( $package['includes_progress_monitoring'] ) $items[] = __( 'Monitoraggio progressi', 'glutelab-child-theme' );
	return array_values( array_unique( $items ) );
}

function glutelab_package_card_html( $package, $group = null ) {
	$package = glutelab_normalize_package( $package ); $group = $group ?: ( glutelab_get_catalog()['groups'][ $package['group_id'] ] ?? null );
	$total = glutelab_calculate_total_lessons( $package['lessons_purchased'], $package['bonus_lessons'] ); $inclusions = glutelab_package_inclusions( $package );
	$cta_url = apply_filters( 'glutelab_package_cta_url', $package['cta_url'], $package, $group );
	ob_start(); ?>
	<article class="gl-package<?php echo $package['featured'] ? ' gl-package--featured' : ''; ?>" data-package-id="<?php echo esc_attr( $package['id'] ); ?>">
		<?php if ( $package['badge'] ) : ?><p class="gl-package__badge"><?php echo esc_html( $package['badge'] ); ?></p><?php endif; ?>
		<header class="gl-package__header"><div><?php if ( $package['subtitle'] ) : ?><p class="gl-package__subtitle"><?php echo esc_html( $package['subtitle'] ); ?></p><?php endif; ?><h3><?php echo esc_html( $package['title'] ); ?></h3></div><p class="gl-package__price"><?php echo esc_html( glutelab_package_price_text( $package ) ); ?></p></header>
		<?php if ( $package['description'] ) : ?><p class="gl-package__description"><?php echo esc_html( $package['description'] ); ?></p><?php endif; ?>
		<dl class="gl-package__facts">
			<?php if ( null !== $total ) : ?><div><dt><?php esc_html_e( 'Lezioni totali', 'glutelab-child-theme' ); ?></dt><dd><?php echo esc_html( $total ); ?></dd></div><?php endif; ?>
			<?php if ( $package['frequency'] ) : ?><div><dt><?php esc_html_e( 'Frequenza', 'glutelab-child-theme' ); ?></dt><dd><?php echo esc_html( $package['frequency'] ); ?></dd></div><?php endif; ?>
			<?php if ( $package['total_duration'] ) : ?><div><dt><?php esc_html_e( 'Durata percorso', 'glutelab-child-theme' ); ?></dt><dd><?php echo esc_html( $package['total_duration'] ); ?></dd></div><?php endif; ?>
			<?php if ( null !== $package['max_participants'] ) : ?><div><dt><?php esc_html_e( 'Partecipanti', 'glutelab-child-theme' ); ?></dt><dd><?php echo esc_html( 1 === $package['max_participants'] ? 'One to One' : 'Massimo ' . $package['max_participants'] ); ?></dd></div><?php endif; ?>
		</dl>
		<?php if ( $inclusions ) : ?><ul class="gl-package__benefits"><?php foreach ( $inclusions as $item ) : ?><li><?php echo esc_html( $item ); ?></li><?php endforeach; ?></ul><?php endif; ?>
		<?php if ( $package['commercial_notes'] ) : ?><p class="gl-package__note"><?php echo esc_html( $package['commercial_notes'] ); ?></p><?php endif; ?>
		<?php if ( $package['cta_label'] && $cta_url ) : ?><div class="gl-package__cta-row"><a class="gl-button gl-button--primary gl-package__cta" href="<?php echo esc_url( $cta_url ); ?>"><?php echo esc_html( $package['cta_label'] ); ?></a></div><?php endif; ?>
	</article><?php return ob_get_clean();
}

function glutelab_render_packages( $args = array() ) {
	$packages = glutelab_get_packages( $args ); if ( ! $packages ) return; $catalog = glutelab_get_catalog(); echo '<div class="gl-packages">';
	foreach ( $packages as $package ) echo glutelab_package_card_html( $package, $catalog['groups'][ $package['group_id'] ] ?? null ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	echo '</div>';
}

/** Render the selection area of the future purchase/booking bridge. */
function glutelab_purchase_summary_html( $package_id ) {
	$package = glutelab_get_package( $package_id ); $catalog = glutelab_get_catalog(); $group = $package ? ( $catalog['groups'][ $package['group_id'] ] ?? null ) : null;
	ob_start();
	if ( $package && $group && 'active' === $package['status'] ) { ?>
		<p class="gl-kicker"><?php echo esc_html( $group['title'] ); ?></p><?php echo glutelab_package_card_html( $package, $group ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	} else { ?>
		<div class="gl-placeholder" role="status"><h2><?php esc_html_e( 'Pacchetto non trovato', 'glutelab-child-theme' ); ?></h2><p><?php esc_html_e( 'Il collegamento non identifica un’offerta attiva. Torna al catalogo e scegli il percorso che preferisci.', 'glutelab-child-theme' ); ?></p><a class="gl-button gl-button--secondary" href="<?php echo esc_url( glutelab_page_url( 'pacchetti-e-lezioni' ) ); ?>"><?php esc_html_e( 'Torna ai pacchetti', 'glutelab-child-theme' ); ?></a></div><?php
	}
	return ob_get_clean();
}

function glutelab_group_starting_price( $group_id ) {
	$packages = glutelab_get_packages_by_group( $group_id ); if ( ! $packages ) return null; return min( array_column( $packages, 'price' ) );
}

function glutelab_group_primary_characteristic( $group ) {
	$packages = glutelab_get_packages_by_group( $group['id'] ); $first = $packages[0] ?? array();
	if ( 'individual' === $group['mode'] ) return 1 === $group['max_participants'] ? 'One to One' : 'Percorso individuale';
	if ( 'group' === $group['mode'] ) return $group['max_participants'] ? sprintf( 'Massimo %d persone', $group['max_participants'] ) : 'Piccolo gruppo';
	if ( 'integrated' === $group['mode'] ) return ! empty( $first['total_duration'] ) ? $first['total_duration'] . ' · percorso integrato' : 'Percorso integrato';
	if ( 'digital' === $group['mode'] && ! empty( $first['includes_nutrition_app'] ) && ! empty( $first['includes_bmi_monitoring'] ) ) return 'App Nutrition + BMI';
	return glutelab_mode_label( $group['mode'] );
}
