<?php
/** A focused presentation for the existing WordPress event records and handlers. */
defined('ABSPATH') || exit;

function qz_event_admin_screen() {
    $screen = get_current_screen();
    return $screen && 'mec-events' === $screen->post_type && in_array($screen->base, ['edit', 'post'], true);
}
function qz_event_admin_state($id) {
    if ('trash' === get_post_status($id)) return ['muted', __('Nel cestino', 'qualazampa')];
    if ('publish' !== get_post_status($id)) return ['muted', __('Bozza · nascosto', 'qualazampa')];
    $bounds = qz_event_bounds($id);
    if (!$bounds) return ['attention', __('Date da completare', 'qualazampa')];
    if ($bounds[1] < current_datetime()) return ['muted', __('Terminato · nascosto', 'qualazampa')];
    if (qz_event_visible($id)) return ['visible', __('Visibile in home', 'qualazampa')];
    return ['muted', __('Nascosto', 'qualazampa')];
}
function qz_event_admin_badge($id) {
    [$tone, $label] = qz_event_admin_state($id);
    echo '<span class="qze-state qze-state--'.esc_attr($tone).'">'.esc_html($label).'</span>';
}
add_filter('admin_body_class', static function ($classes) {
    if (!qz_event_admin_screen()) return $classes;
    return $classes.' qz-events-admin qz-events-admin--'.get_current_screen()->base;
});
add_action('admin_enqueue_scripts', static function () {
    if (!qz_event_admin_screen()) return;
    wp_enqueue_style('qz-events-admin', get_stylesheet_directory_uri().'/assets/css/events-admin.css', ['ticinoweb-admin-ui'], qz_asset_version('assets/css/events-admin.css'));
    if ('post' !== get_current_screen()->base) return;
    wp_enqueue_script('qz-events-admin', get_stylesheet_directory_uri().'/assets/js/events-admin.js', [], qz_asset_version('assets/js/events-admin.js'), true);
    wp_localize_script('qz-events-admin', 'qzEventsAdmin', [
        'empty' => __('Scegli la data di inizio.', 'qualazampa'),
        'invalid' => __('La fine deve seguire l’inizio.', 'qualazampa'),
    ]);
}, 120);
add_action('all_admin_notices', static function () {
    if (!qz_event_admin_screen()) return;
    global $post;
    $editing = 'post' === get_current_screen()->base;
    $new = $editing && (!$post || 'auto-draft' === $post->post_status);
    echo '<div class="qze-heading"><div>';
    if ($editing) echo '<a class="qze-back" href="'.esc_url(admin_url('edit.php?post_type=mec-events')).'">'.esc_html__('Tutti gli eventi', 'qualazampa').'</a>';
    echo '<h1>'.esc_html($editing ? ($new ? __('Nuovo evento', 'qualazampa') : __('Modifica evento', 'qualazampa')) : __('Eventi', 'qualazampa')).'</h1>';
    echo '<p>'.esc_html($editing ? __('Racconta l’appuntamento, scegli quando si svolge e salva.', 'qualazampa') : __('Gli appuntamenti del negozio, con date e visibilità sempre chiare.', 'qualazampa')).'</p>';
    if ($editing && $post && get_post_meta($post->ID, '_qz_event_demo', true)) echo '<p class="qze-demo">'.esc_html__('Evento dimostrativo: non è un appuntamento reale.', 'qualazampa').'</p>';
    echo '</div><div class="qze-heading__actions">';
    if (!$editing) {
        if (current_user_can(get_post_type_object('mec-events')->cap->create_posts)) echo '<a class="button button-primary" href="'.esc_url(admin_url('post-new.php?post_type=mec-events')).'">'.esc_html__('Crea evento', 'qualazampa').'</a>';
    } elseif (!$new && $post) {
        qz_event_admin_badge($post->ID);
    }
    echo '</div></div>';
}, 110);
add_action('edit_form_after_title', static function ($post) {
    if ('mec-events' !== $post->post_type) return;
    echo '<div class="qze-description-label"><label for="content">'.esc_html__('Descrizione dell’evento', 'qualazampa').'</label><p>'.esc_html__('Le informazioni utili per chi vuole partecipare.', 'qualazampa').'</p></div>';
});
add_filter('wp_editor_settings', static function ($settings, $editor) {
    if ('content' !== $editor || !qz_event_admin_screen()) return $settings;
    $settings['media_buttons'] = false;
    $settings['teeny'] = true;
    $settings['quicktags'] = false;
    $settings['editor_height'] = 220;
    $settings['tinymce'] = array_merge(is_array($settings['tinymce'] ?? null) ? $settings['tinymce'] : [], [
        'toolbar1' => 'bold italic bullist numlist link unlink undo redo',
        'toolbar2' => '',
        'content_style' => 'body{font:15px/1.65 system-ui,sans-serif;color:#1f2733;margin:18px;}',
    ]);
    return $settings;
}, 20, 2);
// Keep the native publish/nonce/capability flow, photo picker, and existing event meta.
add_action('add_meta_boxes_mec-events', static function () {
    global $wp_meta_boxes;
    $keep = ['submitdiv', 'postimagediv', 'qz-event-details'];
    foreach (($wp_meta_boxes['mec-events'] ?? []) as $context => $priorities) {
        foreach ($priorities as $boxes) foreach ($boxes as $id => $box) {
            if (!in_array($id, $keep, true)) remove_meta_box($id, 'mec-events', $context);
        }
    }
    add_meta_box('postimagediv', __('Foto dell’evento', 'qualazampa'), 'post_thumbnail_meta_box', 'mec-events', 'side', 'low');
}, 1000);
add_filter('get_user_option_closedpostboxes_mec-events', static fn() => []);
add_action('post_submitbox_misc_actions', static function ($post) {
    if ('mec-events' !== $post->post_type) return;
    echo '<p class="qze-publish-help">'.esc_html__('Pubblica per mostrarlo in home. Le bozze e gli eventi terminati restano nascosti.', 'qualazampa').'</p>';
});
add_filter('post_row_actions', static function ($actions, $post) {
    if ('mec-events' === $post->post_type) unset($actions['inline hide-if-no-js']);
    return $actions;
}, 20, 2);
add_filter('months_dropdown_results', static function ($months, $type) {
    return 'mec-events' === $type ? [] : $months;
}, 10, 2);
