<?php
/** Store-specific extensions of tW SEO and WooCommerce. All content stays in the CMS. */
defined('ABSPATH') || exit;

function qz_seo_post_meta($key) {
    $id = is_singular() ? get_queried_object_id() : (function_exists('tw_seo_get_archive_page_id') ? tw_seo_get_archive_page_id() : 0);
    return $id ? (string) get_post_meta($id, $key, true) : '';
}

// The shop is a product archive, but its editorial SEO belongs to its native WP page.
add_filter('ticinoweb_seo_document_title_parts', static function ($parts) {
    if (function_exists('is_shop') && is_shop() && ($title = qz_seo_post_meta('_tw_seo_title'))) {
        $parts['title'] = function_exists('ticinoweb_frontend_text') ? ticinoweb_frontend_text($title, 'theme:seo:post_title') : $title;
        unset($parts['site'], $parts['tagline']);
    }
    return $parts;
});
add_filter('ticinoweb_seo_meta_description', static function ($description) {
    if (function_exists('is_shop') && is_shop() && ($custom = qz_seo_post_meta('_tw_seo_description'))) {
        return function_exists('ticinoweb_frontend_text') ? ticinoweb_frontend_text($custom, 'theme:seo:meta_description') : $custom;
    }
    return $description;
});
add_filter('ticinoweb_seo_og_title', static function ($title) {
    if (function_exists('is_shop') && is_shop() && ($custom = qz_seo_post_meta('_tw_seo_title'))) {
        return function_exists('ticinoweb_frontend_text') ? ticinoweb_frontend_text($custom, 'theme:seo:post_title') : $custom;
    }
    if (is_tax()) {
        $term = get_queried_object();
        $custom = get_term_meta($term->term_id, '_tw_seo_title', true);
        if ($custom) return function_exists('ticinoweb_frontend_text') ? ticinoweb_frontend_text($custom, 'theme:seo:term_title') : $custom;
    }
    return $title;
});

function qz_seo_utility_archive() {
    if (is_author() || is_date() || is_search() || is_attachment()) return true;
    if (!is_tax() && !is_tag() && !is_category()) return false;
    $term = get_queried_object();
    // Category and the complete native brand attribute are the curated catalogue landing pages.
    return $term instanceof WP_Term && !in_array($term->taxonomy, ['product_cat', 'pa_marche'], true);
}
function qz_seo_filtered_catalogue() {
    if (!function_exists('is_shop') || !(is_shop() || is_product_taxonomy())) return false;
    foreach (array_keys($_GET) as $key) {
        if (in_array($key, ['qz_brand', 'qz_kind', 'qz_animal', 'qz_stock', 'orderby', 'min_price', 'max_price', 'rating_filter'], true) || str_starts_with((string) $key, 'filter_')) return true;
    }
    return false;
}
add_filter('wp_robots', static function ($robots) {
    $noindex = qz_seo_utility_archive() || qz_seo_filtered_catalogue();
    if (function_exists('is_cart') && (is_cart() || is_checkout() || is_account_page())) $noindex = true;
    if (str_contains(qz_seo_post_meta('_tw_seo_robots'), 'noindex')) $noindex = true;
    if ($noindex) {
        unset($robots['index']);
        $robots['noindex'] = true;
    }
    if (str_contains(qz_seo_post_meta('_tw_seo_robots'), 'nofollow')) {
        unset($robots['follow']);
        $robots['nofollow'] = true;
    }
    // WordPress' blog_public=0 and the event demo's restrictions remain authoritative.
    return $robots;
}, 30);
add_filter('ticinoweb_seo_canonical_url', static function ($canonical) {
    if ($canonical && (is_archive() || is_home()) && !qz_seo_filtered_catalogue() && ($page = max(1, (int) get_query_var('paged'))) > 1) {
        global $wp_rewrite;
        return get_option('permalink_structure') ? user_trailingslashit(trailingslashit($canonical).$wp_rewrite->pagination_base.'/'.$page, 'paged') : add_query_arg('paged', $page, $canonical);
    }
    return $canonical;
});
add_filter('wp_sitemaps_taxonomies', static function ($taxonomies) {
    foreach ($taxonomies as $name => $taxonomy) {
        if (!in_array($name, ['product_cat', 'pa_marche'], true)) unset($taxonomies[$name]);
    }
    return $taxonomies;
});
add_filter('wp_sitemaps_add_provider', static function ($provider, $name) {
    return 'users' === $name ? false : $provider;
}, 10, 2);

function qz_seo_postal_address() {
    $raw = trim((string) get_option('ticinoweb_contact_address', ''));
    if (!$raw) return [];
    $address = ['@type' => 'PostalAddress', 'streetAddress' => $raw];
    if (preg_match('/^(.+?),\s*(\d{4})\s+(.+)$/u', $raw, $parts)) {
        $address['streetAddress'] = trim($parts[1]);
        $address['postalCode'] = $parts[2];
        $address['addressLocality'] = trim($parts[3]);
    }
    $country = explode(':', (string) get_option('woocommerce_default_country', ''))[0];
    if (preg_match('/^[A-Z]{2}$/D', $country)) $address['addressCountry'] = $country;
    return $address;
}
add_filter('ticinoweb_seo_jsonld_org_schema', static function ($schema) {
    $schema['@id'] = home_url('/#organization');
    $schema['@type'] = 'PetStore';
    $schema['name'] = get_option('tw_seo_org_name') ?: get_bloginfo('name');
    foreach (['telephone' => 'phone', 'email' => 'email'] as $property => $key) {
        $value = get_option('ticinoweb_contact_'.$key);
        if ($value) $schema[$property] = $value;
    }
    $address = qz_seo_postal_address();
    if ($address) $schema['address'] = $address;
    $image = tw_seo_get_social_image();
    if ($image) $schema['image'] = $image;
    $schema['description'] = (string) get_option('tw_seo_description', '');
    $socials = [];
    foreach (['facebook', 'instagram', 'linkedin', 'youtube', 'tiktok', 'x'] as $key) {
        $url = esc_url_raw((string) get_option('ticinoweb_contact_'.$key), ['https', 'http']);
        if ($url) $socials[] = $url;
    }
    $schema['sameAs'] = array_values(array_unique(array_merge($schema['sameAs'] ?? [], $socials)));
    if (!$schema['sameAs']) unset($schema['sameAs']);
    $days = ['monday'=>'Monday', 'tuesday'=>'Tuesday', 'wednesday'=>'Wednesday', 'thursday'=>'Thursday', 'friday'=>'Friday', 'saturday'=>'Saturday', 'sunday'=>'Sunday'];
    $hours = (array) get_option('ticinoweb_contact_opening_hours', []);
    $specifications = [];
    foreach ($days as $key => $day) {
        if (empty($hours[$key]) || !empty($hours[$key]['closed'])) continue;
        foreach ((array) ($hours[$key]['slots'] ?? []) as $slot) {
            if (!qz_event_time($slot['open'] ?? '') || !qz_event_time($slot['close'] ?? '')) continue;
            $specifications[] = ['@type'=>'OpeningHoursSpecification', 'dayOfWeek'=>'https://schema.org/'.$day, 'opens'=>$slot['open'], 'closes'=>$slot['close']];
        }
    }
    if ($specifications) $schema['openingHoursSpecification'] = $specifications;
    return $schema;
});
add_filter('ticinoweb_seo_jsonld_search_schema', static function ($schema) {
    $schema['@id'] = home_url('/#website');
    $schema['name'] = get_bloginfo('name');
    $schema['inLanguage'] = get_bloginfo('language');
    $schema['publisher'] = ['@id'=>home_url('/#organization')];
    return $schema;
});
add_filter('ticinoweb_seo_jsonld_article_schema', static function ($schema, $post) {
    if ('post' === $post->post_type) return $schema;
    // Product details are owned exclusively by WooCommerce, rather than described as an Article.
    $page = ['@context'=>'https://schema.org', '@type'=>'WebPage', '@id'=>get_permalink($post).'#webpage', 'url'=>get_permalink($post), 'name'=>$post->post_title, 'inLanguage'=>get_bloginfo('language')];
    if ('product' === $post->post_type) $page['mainEntity'] = ['@id'=>get_permalink($post).'#product'];
    if ('mec-events' === $post->post_type && !get_post_meta($post->ID, '_qz_event_demo', true)) {
        $data = qz_event_validate(qz_event_fields($post->ID));
        if (!is_wp_error($data)) {
            $page['@type'] = 'Event';
            $page['@id'] = get_permalink($post).'#event';
            foreach (['start', 'end'] as $edge) {
                $date = qz_event_date($data[$edge.'_date']);
                if ($data[$edge.'_time']) {
                    [$hour, $minute] = array_map('intval', explode(':', $data[$edge.'_time']));
                    $date = $date->setTime($hour, $minute);
                    $page[$edge.'Date'] = $date->format(DATE_ATOM);
                } else $page[$edge.'Date'] = $date->format('Y-m-d');
            }
            $page['description'] = wp_strip_all_tags(strip_shortcodes($post->post_content));
            $page['location'] = ['@type'=>'Place', 'name'=>$data['place'] ?: get_bloginfo('name')];
            if (!$data['place'] && ($address = qz_seo_postal_address())) $page['location']['address'] = $address;
            if (has_post_thumbnail($post)) $page['image'] = get_the_post_thumbnail_url($post, 'full');
            if ($data['organizer']) $page['organizer'] = ['@type'=>'Organization', 'name'=>$data['organizer']];
        }
    }
    return $page;
}, 10, 2);

/** Delegate all metadata to the parent, then correct its fixed image dimensions and robots duplication. */
add_action('after_setup_theme', static function () {
    if (!function_exists('tw_seo_inject_metadata')) return;
    remove_action('wp_head', 'tw_seo_inject_metadata', 1);
    add_action('wp_head', 'qz_seo_parent_metadata', 1);
}, 110);
function qz_seo_parent_metadata() {
    ob_start();
    tw_seo_inject_metadata();
    $html = ob_get_clean();
    // wp_robots is the single output owner, also enforcing the native per-page field above.
    $html = preg_replace('/<meta name="robots"[^>]*>\s*/', '', $html);
    $html = preg_replace('/<meta property="og:image:(?:width|height)"[^>]*>\s*/', '', $html);
    if (get_option('tw_seo_enable_og', '1') === '1') {
        $id = is_singular() && has_post_thumbnail() ? get_post_thumbnail_id() : attachment_url_to_postid(tw_seo_get_social_image());
        $image = $id ? wp_get_attachment_image_src($id, 'full') : false;
        if ($image && $image[1] && $image[2]) {
            $html .= '<meta property="og:image:width" content="'.absint($image[1]).'" />'."\n";
            $html .= '<meta property="og:image:height" content="'.absint($image[2]).'" />'."\n";
            if ($image[1] < 300 || $image[2] < 157) $html = str_replace('name="twitter:card" content="summary_large_image"', 'name="twitter:card" content="summary"', $html);
        }
        if (function_exists('is_product') && is_product()) $html = str_replace('property="og:type" content="article"', 'property="og:type" content="product"', $html);
    }
    echo $html; // All values are escaped by the parent or absint() above.
}

// Reuse the parent's fields and save handler for the curated WooCommerce taxonomies.
foreach (['product_cat', 'pa_marche'] as $taxonomy) {
    add_action($taxonomy.'_add_form_fields', 'tw_seo_add_taxonomy_fields');
    add_action($taxonomy.'_edit_form_fields', 'tw_seo_edit_taxonomy_fields', 10, 2);
    add_action('created_'.$taxonomy, 'tw_seo_save_taxonomy_fields', 10, 2);
    add_action('edited_'.$taxonomy, 'tw_seo_save_taxonomy_fields', 10, 2);
}

add_filter('woocommerce_structured_data_product', static function ($schema, $product) {
    if (empty($schema['brand'])) {
        $brands = wp_get_post_terms($product->get_id(), 'pa_marche', ['fields'=>'names']);
        if (!is_wp_error($brands) && $brands) $schema['brand'] = ['@type'=>'Brand', 'name'=>implode(', ', $brands)];
    }
    return $schema;
}, 20, 2);
