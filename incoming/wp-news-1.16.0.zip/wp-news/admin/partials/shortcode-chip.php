<?php
/**
 * Shortcode with a copy button. Expects $wpnews_sc (the shortcode string).
 *
 * @package WPNews
 */

if (!defined('ABSPATH')) {
	exit;
}
?>
<div class="wpnews-shortcode-chip">
	<code><?php echo esc_html($wpnews_sc); ?></code>
	<button type="button" class="wpnews-copy-btn" data-copy="<?php echo esc_attr($wpnews_sc); ?>" title="<?php esc_attr_e('Copy shortcode', 'wp-news'); ?>">
		<span class="dashicons dashicons-admin-page" aria-hidden="true"></span>
		<span class="wpnews-copy-label"><?php esc_html_e('Copy', 'wp-news'); ?></span>
	</button>
</div>
