<?php
/**
 * Storage: shared network tables for translation entries and glossary
 * terms. Uses $wpdb->base_prefix so a single table serves the whole
 * network; on single-site installs base_prefix equals the normal prefix.
 * Both tables are partitioned by blog_id: every site sees only its rows.
 *
 * @package tw-translate-plus
 */

if (!defined('ABSPATH')) {
    exit;
}

class Twtr_Storage {

    /**
     * @return string Entries table name.
     */
    public static function entries_table() {
        global $wpdb;
        return $wpdb->base_prefix . 'twtr_entries';
    }

    /**
     * @return string Glossary table name.
     */
    public static function glossary_table() {
        global $wpdb;
        return $wpdb->base_prefix . 'twtr_glossary';
    }

    /**
     * Create or upgrade the schema. Called only on activation and when the
     * stored DB version differs from TWTR_DB_VERSION — never per request.
     */
    public static function install() {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        $charset = $wpdb->get_charset_collate();
        $entries = self::entries_table();
        $gloss   = self::glossary_table();

        dbDelta("CREATE TABLE {$entries} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            blog_id BIGINT UNSIGNED NOT NULL DEFAULT 1,
            context_key VARCHAR(191) NOT NULL,
            source_hash CHAR(32) NOT NULL,
            source_text LONGTEXT NOT NULL,
            target_locale VARCHAR(10) NOT NULL,
            translated_text LONGTEXT NULL,
            origin VARCHAR(10) NOT NULL DEFAULT 'google',
            status VARCHAR(10) NOT NULL DEFAULT 'pending',
            locked TINYINT(1) NOT NULL DEFAULT 0,
            attempts TINYINT UNSIGNED NOT NULL DEFAULT 0,
            glossary_version INT UNSIGNED NOT NULL DEFAULT 0,
            claim_token CHAR(23) NULL DEFAULT NULL,
            error_message VARCHAR(500) NULL DEFAULT NULL,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY entry_identity (blog_id,target_locale,context_key,source_hash),
            KEY queue_scan (blog_id,status,locked),
            KEY context_scan (blog_id,target_locale,context_key),
            KEY memory_lookup (blog_id,target_locale,source_hash,status),
            KEY claim (blog_id,claim_token)
        ) {$charset};");

        dbDelta("CREATE TABLE {$gloss} (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            blog_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
            source_text VARCHAR(191) NOT NULL,
            translations LONGTEXT NOT NULL,
            active TINYINT(1) NOT NULL DEFAULT 1,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY site_term (blog_id,source_text)
        ) {$charset};");

        self::migrate_glossary_to_sites();
        self::requeue_echoes();
        self::requeue_normalized_echoes();

        update_site_option('twtr_db_version', TWTR_DB_VERSION);
    }

    /**
     * DB version 4: before 1.14.0 an engine that handed a sentence back
     * unchanged was stored as "translated" (seen with gpt-oss-20b: about 7%
     * of rows on oasidellespezie.ch kept the Italian text under /de/). Put
     * those machine rows back in the queue, on every site. Manual overrides
     * are never touched.
     */
    private static function requeue_echoes() {
        global $wpdb;
        $origins = Twtr_Settings::machine_origins();
        $ph      = implode(',', array_fill(0, count($origins), '%s'));
        $wpdb->query($wpdb->prepare(
            'UPDATE ' . self::entries_table() .
            " SET status = 'pending', attempts = 0, claim_token = NULL, updated_at = UTC_TIMESTAMP()" .
            " WHERE status = 'ready' AND locked = 0 AND origin IN ({$ph})" .
            " AND translated_text = source_text AND CHAR_LENGTH(source_text) - CHAR_LENGTH(REPLACE(source_text, ' ', '')) >= 3",
            $origins
        ));
    }

    /**
     * DB version 5: echoes that the SQL comparison of version 4 missed
     * because source and "translation" differ only in entities or
     * typography (`all&#8217;aglio` vs `all’aglio`). Compared in PHP, short
     * machine rows only (titles, labels, sentences), on every site.
     */
    private static function requeue_normalized_echoes() {
        global $wpdb;
        $table   = self::entries_table();
        $origins = Twtr_Settings::machine_origins();
        $ph      = implode(',', array_fill(0, count($origins), '%s'));
        $norm    = function ($t) {
            $t = html_entity_decode(wp_strip_all_tags((string) $t), ENT_QUOTES | ENT_HTML5, 'UTF-8');
            $t = str_replace(array("\u{2019}", "\u{2018}", "\u{201C}", "\u{201D}", "\u{2013}", "\u{2014}", "\u{00A0}"), array("'", "'", '"', '"', '-', '-', ' '), $t);
            return mb_strtolower(trim(preg_replace('/\s+/u', ' ', $t)));
        };
        $last = 0;
        do {
            $rows = $wpdb->get_results($wpdb->prepare(
                "SELECT id, source_text, translated_text FROM {$table}
                 WHERE id > %d AND status = 'ready' AND locked = 0 AND origin IN ({$ph}) AND CHAR_LENGTH(source_text) <= 600
                 ORDER BY id ASC LIMIT 2000",
                array_merge(array($last), $origins)
            ));
            $ids = array();
            foreach ((array) $rows as $row) {
                $last = (int) $row->id;
                $a    = $norm($row->source_text);
                if ($a !== '' && count(preg_split('/\s+/u', $a)) >= 4 && $a === $norm($row->translated_text)) {
                    $ids[] = (int) $row->id;
                }
            }
            if ($ids) {
                $wpdb->query("UPDATE {$table} SET status = 'pending', attempts = 0, claim_token = NULL, updated_at = UTC_TIMESTAMP() WHERE id IN (" . implode(',', $ids) . ')');
            }
        } while ($rows && count($rows) === 2000);
    }

    /**
     * DB version 2: the glossary became per site. Before, one list of terms
     * served every site of the network, so a term added on one site showed
     * up (and was applied) on all the others.
     *
     * Rows written before the change have blog_id 0 and no record of the
     * site they were added on. Each one is handed to the sites whose
     * content actually contains the term (the only sites where it ever had
     * an effect); a term found nowhere goes to every site that translates,
     * so no term is lost. Idempotent: it only touches blog_id 0 rows.
     */
    private static function migrate_glossary_to_sites() {
        global $wpdb;
        $gloss   = self::glossary_table();
        $entries = self::entries_table();

        // dbDelta adds indexes but never drops them: the old unique key on
        // source_text alone would forbid the same term on two sites.
        if ($wpdb->get_var("SHOW INDEX FROM {$gloss} WHERE Key_name = 'source_term'")) {
            $wpdb->query("ALTER TABLE {$gloss} DROP INDEX source_term");
        }

        $legacy = (array) $wpdb->get_results("SELECT * FROM {$gloss} WHERE blog_id = 0");
        if (!$legacy) {
            return;
        }

        if (is_multisite()) {
            $sites = array_map('intval', (array) $wpdb->get_col("SELECT DISTINCT blog_id FROM {$entries}"));
            if (!$sites) {
                $sites = array((int) get_main_site_id());
            }
        } else {
            $sites = array(1);
        }

        foreach ($legacy as $row) {
            $targets = $sites;
            if (count($sites) > 1) {
                $found = array_map('intval', (array) $wpdb->get_col($wpdb->prepare(
                    "SELECT DISTINCT blog_id FROM {$entries} WHERE source_text LIKE %s",
                    '%' . $wpdb->esc_like($row->source_text) . '%'
                )));
                if ($found) {
                    $targets = $found;
                }
            }
            foreach ($targets as $blog_id) {
                $wpdb->query($wpdb->prepare(
                    "INSERT IGNORE INTO {$gloss} (blog_id, source_text, translations, active, created_at, updated_at)" .
                    ' VALUES (%d, %s, %s, %d, %s, %s)',
                    $blog_id, $row->source_text, $row->translations, (int) $row->active, $row->created_at, $row->updated_at
                ));
            }
            $wpdb->delete($gloss, array('id' => (int) $row->id));
        }
    }

    /**
     * Fetch every entry for a (locale, context) group of the current site,
     * keyed by source hash. One query typically covers all content chunks of
     * a post at once.
     *
     * @param string $locale  Target language slug.
     * @param string $context Context key.
     * @return array<string,object>
     */
    public static function get_context_group($locale, $context) {
        global $wpdb;
        $rows = $wpdb->get_results($wpdb->prepare(
            'SELECT source_hash, translated_text, origin, status, locked FROM ' . self::entries_table() .
            ' WHERE blog_id = %d AND target_locale = %s AND context_key = %s',
            get_current_blog_id(), $locale, $context
        ));
        $out = array();
        foreach ((array) $rows as $row) {
            $out[$row->source_hash] = $row;
        }
        return $out;
    }

    /**
     * Insert missing entries as pending, ignoring duplicates.
     *
     * @param array $items Each item: [context, hash, source, locale].
     * @return int Number of new rows.
     */
    public static function insert_pending($items) {
        global $wpdb;
        if (!$items) {
            return 0;
        }
        $blog_id = get_current_blog_id();
        $now     = current_time('mysql', true);
        $values  = array();
        foreach ($items as $it) {
            $values[] = $wpdb->prepare('(%d,%s,%s,%s,%s,%s,%s)',
                $blog_id, $it['context'], $it['hash'], $it['source'], $it['locale'], $now, $now);
        }
        // INSERT IGNORE: the unique key on (blog_id,target_locale,context_key,source_hash)
        // makes concurrent discovery safe.
        $sql = 'INSERT IGNORE INTO ' . self::entries_table() .
            ' (blog_id, context_key, source_hash, source_text, target_locale, created_at, updated_at) VALUES ' .
            implode(',', $values);
        $result = $wpdb->query($sql); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- values prepared above.
        return (int) $result;
    }

    /**
     * Ensure entries exist for a source string across the given locales and
     * mark superseded manual overrides of the same context as stale.
     *
     * @param string   $context Context key.
     * @param string   $source  Original text.
     * @param string[] $locales Target language slugs.
     * @return int Number of new entries queued.
     */
    public static function sync_source($context, $source, $locales) {
        global $wpdb;
        if ($source === '' || !$locales) {
            return 0;
        }
        $blog_id = get_current_blog_id();
        $hash    = md5($source);
        $items   = array();
        foreach ($locales as $locale) {
            $items[] = array('context' => $context, 'hash' => $hash, 'source' => $source, 'locale' => $locale);
        }
        $created = self::insert_pending($items);

        if ($created > 0) {
            // The source changed: previous entries of this context (any hash but
            // the current one) become stale. Manual ones are kept for review;
            // old google ones are kept only as history and never requeued
            // because the lookup is hash-based.
            $placeholders = implode(',', array_fill(0, count($locales), '%s'));
            $params = array_merge(array($blog_id, $context, $hash), $locales);
            $wpdb->query($wpdb->prepare(
                'UPDATE ' . self::entries_table() .
                " SET status = 'stale', updated_at = UTC_TIMESTAMP() " .
                " WHERE blog_id = %d AND context_key = %s AND source_hash <> %s AND target_locale IN ({$placeholders}) AND status = 'ready'",
                $params
            ));
        }
        return $created;
    }

    /**
     * Multi-string variant of sync_source() for chunked contexts (post
     * content): entries are inserted for every current chunk and only rows
     * whose hash no longer belongs to the current set are marked stale.
     *
     * @param string   $context Context key shared by all chunks.
     * @param string[] $sources Current chunk texts.
     * @param string[] $locales Target language slugs.
     * @return int Number of new entries queued.
     */
    public static function sync_source_multi($context, $sources, $locales) {
        global $wpdb;
        $sources = array_values(array_filter($sources, 'strlen'));
        if (!$sources || !$locales) {
            return 0;
        }
        $blog_id = get_current_blog_id();
        $hashes  = array();
        $items   = array();
        foreach ($sources as $source) {
            $hash = md5($source);
            $hashes[$hash] = true;
            foreach ($locales as $locale) {
                $items[] = array('context' => $context, 'hash' => $hash, 'source' => $source, 'locale' => $locale);
            }
        }
        $created = self::insert_pending($items);

        $hash_list   = array_keys($hashes);
        $hash_ph     = implode(',', array_fill(0, count($hash_list), '%s'));
        $locale_ph   = implode(',', array_fill(0, count($locales), '%s'));
        $params      = array_merge(array($blog_id, $context), $hash_list, $locales);
        $wpdb->query($wpdb->prepare(
            'UPDATE ' . self::entries_table() .
            " SET status = 'stale', updated_at = UTC_TIMESTAMP()" .
            " WHERE blog_id = %d AND context_key = %s AND source_hash NOT IN ({$hash_ph})" .
            " AND target_locale IN ({$locale_ph}) AND status = 'ready'",
            $params
        ));
        return $created;
    }

    /**
     * Translation memory: fill pending (or failed) entries whose exact
     * source text is already translated elsewhere on the same site, in the
     * same language, instead of paying the engine for it again. A product
     * description shared by 20 variants, a footer repeated on every page, a
     * heading used on many posts: translated once, reused everywhere.
     *
     * Rules, chosen so a reuse is never worse than a fresh translation:
     * - same site and same target language only (sites never share text);
     * - only machine translations are copied, never manual overrides (a
     *   manual edit is a decision for that context, not a general rule);
     * - only "ready" rows: rows requeued by a glossary change are pending,
     *   so a copy always reflects the current glossary;
     * - the engine translates each segment without page context anyway, so
     *   the same input would produce the same output: reuse changes cost,
     *   not quality.
     *
     * Cost: one index-backed join (memory_lookup) and one UPDATE per hit.
     *
     * @param int $limit Max entries filled per call.
     * @return int Entries filled from memory.
     */
    public static function fill_from_memory($limit = 500) {
        global $wpdb;
        $table   = self::entries_table();
        $origins = Twtr_Settings::machine_origins();
        $ph      = implode(',', array_fill(0, count($origins), '%s'));
        // One twin per pending row (MIN id), so a text with many twins does
        // not use up the LIMIT. Twins whose "translation" is the unchanged
        // source sentence are not copied (an engine echo, not a translation).
        $rows    = $wpdb->get_results($wpdb->prepare(
            "SELECT p.id, p.context_key, p.target_locale, CHAR_LENGTH(p.source_text) AS chars, r.translated_text, r.origin
             FROM (
                SELECT p.id, MIN(r.id) AS twin
                FROM {$table} p
                JOIN {$table} r
                  ON r.blog_id = p.blog_id AND r.target_locale = p.target_locale AND r.source_hash = p.source_hash
                 AND r.status = 'ready' AND r.locked = 0 AND r.origin IN ({$ph}) AND r.id <> p.id
                 AND r.translated_text IS NOT NULL AND r.translated_text <> ''
                 AND NOT (r.translated_text = r.source_text AND CHAR_LENGTH(r.source_text) > 25)
                WHERE p.blog_id = %d AND p.status IN ('pending','error') AND p.locked = 0 AND p.claim_token IS NULL
                GROUP BY p.id
                LIMIT %d
             ) m
             JOIN {$table} p ON p.id = m.id
             JOIN {$table} r ON r.id = m.twin",
            array_merge($origins, array(get_current_blog_id(), (int) $limit))
        ));
        if (!$rows) {
            return 0;
        }
        $filled = 0;
        $chars  = 0;
        $seen   = array();
        $now    = current_time('mysql', true);
        $groups = array();
        foreach ($rows as $row) {
            if (isset($seen[$row->id])) {
                continue; // several twins: the first one is enough
            }
            $seen[$row->id] = true;
            $done = $wpdb->query($wpdb->prepare(
                "UPDATE {$table} SET translated_text = %s, origin = %s, status = 'ready', attempts = 0,
                    error_message = NULL, updated_at = %s
                 WHERE id = %d AND status IN ('pending','error') AND locked = 0 AND claim_token IS NULL",
                $row->translated_text, $row->origin, $now, (int) $row->id
            ));
            if ($done) {
                $filled++;
                $chars += (int) $row->chars;
                $groups[$row->target_locale . "\n" . $row->context_key] = array($row->target_locale, $row->context_key);
            }
        }
        foreach ($groups as $g) {
            Twtr_Resolver::flush_group($g[0], $g[1]);
            Twtr_Cache::purge_for_context($g[1], $g[0]);
        }
        if ($filled) {
            $stats = get_option('twtr_memory_stats', array());
            $stats = is_array($stats) ? $stats : array();
            update_option('twtr_memory_stats', array(
                'reused' => (isset($stats['reused']) ? (int) $stats['reused'] : 0) + $filled,
                'chars'  => (isset($stats['chars']) ? (int) $stats['chars'] : 0) + $chars,
            ), false);
        }
        return $filled;
    }

    /**
     * Context prefixes of everything the extractor stores for a post.
     *
     * @param int $post_id
     * @return string[]
     */
    public static function post_context_prefixes($post_id) {
        $id = (int) $post_id;
        return array('post:' . $id . ':', 'product:' . $id . ':', 'seo:post:' . $id . ':');
    }

    /**
     * Translation status of several posts at once (one query, prefix ranges
     * on the context_scan index): for the list-table column and the editor
     * box.
     *
     * @param int[] $post_ids
     * @return array<int,array<string,array{ready:int,pending:int,error:int}>> post id => locale => counts
     */
    public static function posts_status($post_ids) {
        global $wpdb;
        $post_ids = array_values(array_unique(array_filter(array_map('intval', (array) $post_ids))));
        if (!$post_ids) {
            return array();
        }
        $locales = Twtr_Settings::extra_languages();
        if (!$locales) {
            return array();
        }
        $likes  = array();
        $params = array(get_current_blog_id());
        foreach ($post_ids as $id) {
            foreach (self::post_context_prefixes($id) as $prefix) {
                $likes[]  = 'context_key LIKE %s';
                $params[] = $wpdb->esc_like($prefix) . '%';
            }
        }
        $rows = $wpdb->get_results($wpdb->prepare(
            'SELECT context_key, target_locale, status, locked FROM ' . self::entries_table() .
            " WHERE blog_id = %d AND target_locale IN (" . implode(',', array_fill(0, count($locales), '%s')) . ")" .
            " AND status <> 'stale' AND (" . implode(' OR ', $likes) . ')',
            array_merge(array($params[0]), $locales, array_slice($params, 1))
        ));
        $out = array();
        foreach ((array) $rows as $row) {
            if (!preg_match('/^(?:post|product|seo:post):(\d+):/', $row->context_key, $m)) {
                continue;
            }
            $pid = (int) $m[1];
            if (!isset($out[$pid][$row->target_locale])) {
                $out[$pid][$row->target_locale] = array('ready' => 0, 'pending' => 0, 'error' => 0);
            }
            $key = $row->status === 'ready' ? 'ready' : ($row->status === 'error' ? 'error' : 'pending');
            $out[$pid][$row->target_locale][$key]++;
        }
        return $out;
    }

    /**
     * Put a post's failed entries back in the queue (for «Traduci adesso»).
     *
     * @param int $post_id
     * @return int
     */
    public static function retry_post($post_id) {
        global $wpdb;
        $likes  = array();
        $params = array(get_current_blog_id());
        foreach (self::post_context_prefixes($post_id) as $prefix) {
            $likes[]  = 'context_key LIKE %s';
            $params[] = $wpdb->esc_like($prefix) . '%';
        }
        return (int) $wpdb->query($wpdb->prepare(
            'UPDATE ' . self::entries_table() .
            " SET status = 'pending', attempts = 0, error_message = NULL, claim_token = NULL, updated_at = UTC_TIMESTAMP()" .
            " WHERE blog_id = %d AND status = 'error' AND locked = 0 AND (" . implode(' OR ', $likes) . ')',
            $params
        ));
    }

    /**
     * Save a manual override.
     *
     * @param int    $id   Entry id (must belong to the current site).
     * @param string $text Translated text.
     * @return bool
     */
    public static function save_manual($id, $text) {
        global $wpdb;
        $updated = $wpdb->update(
            self::entries_table(),
            array(
                'translated_text' => $text,
                'origin'          => 'manual',
                'status'          => 'ready',
                'locked'          => 1,
                'error_message'   => null,
                'updated_at'      => current_time('mysql', true),
            ),
            array('id' => (int) $id, 'blog_id' => get_current_blog_id())
        );
        return (bool) $updated;
    }

    /**
     * Drop a manual override: unlock the entry and requeue it for the active
     * translation engine, keeping the current text visible until the new
     * translation arrives.
     *
     * @param int $id Entry id.
     * @return bool
     */
    public static function restore_machine($id) {
        global $wpdb;
        $updated = $wpdb->update(
            self::entries_table(),
            array(
                'origin'     => Twtr_Settings::provider(),
                'status'     => 'pending',
                'locked'     => 0,
                'attempts'   => 0,
                'updated_at' => current_time('mysql', true),
            ),
            array('id' => (int) $id, 'blog_id' => get_current_blog_id())
        );
        return (bool) $updated;
    }

    /**
     * @deprecated 1.6.0 Use restore_machine(); kept for older integrations.
     *
     * @param int $id Entry id.
     * @return bool
     */
    public static function restore_google($id) {
        return self::restore_machine($id);
    }

    /**
     * Get one entry of the current site by id.
     *
     * @param int $id
     * @return object|null
     */
    public static function get_entry($id) {
        global $wpdb;
        return $wpdb->get_row($wpdb->prepare(
            'SELECT * FROM ' . self::entries_table() . ' WHERE id = %d AND blog_id = %d',
            (int) $id, get_current_blog_id()
        ));
    }

    /**
     * Previous manual override for the same context (different hash), used by
     * the admin UI to offer "recupera traduzione precedente".
     *
     * @param object $entry Current entry row.
     * @return object|null
     */
    public static function previous_manual($entry) {
        global $wpdb;
        return $wpdb->get_row($wpdb->prepare(
            'SELECT * FROM ' . self::entries_table() .
            ' WHERE blog_id = %d AND target_locale = %s AND context_key = %s AND source_hash <> %s' .
            " AND origin = 'manual' ORDER BY updated_at DESC LIMIT 1",
            get_current_blog_id(), $entry->target_locale, $entry->context_key, $entry->source_hash
        ));
    }

    /**
     * Status counters for the current site, grouped by locale and status.
     *
     * @return array<string,array<string,int>> locale => status => count
     */
    public static function status_counts() {
        global $wpdb;
        $rows = $wpdb->get_results($wpdb->prepare(
            'SELECT target_locale, status, COUNT(*) AS n FROM ' . self::entries_table() .
            ' WHERE blog_id = %d GROUP BY target_locale, status',
            get_current_blog_id()
        ));
        $out = array();
        foreach ((array) $rows as $row) {
            $out[$row->target_locale][$row->status] = (int) $row->n;
        }
        return $out;
    }

    /**
     * Translation progress for one language: the share of the site's texts
     * already translated. 100% only when nothing is waiting or failed.
     *
     * @param string $locale Language slug.
     * @return array{percent:int,ready:int,total:int}
     */
    public static function language_progress($locale) {
        global $wpdb;
        $row = $wpdb->get_row($wpdb->prepare(
            "SELECT
                SUM(CASE WHEN status = 'ready' THEN 1 ELSE 0 END) AS ready_entries,
                SUM(CASE WHEN status IN ('pending','error') AND locked = 0 THEN 1 ELSE 0 END) AS unresolved_entries,
                SUM(CASE WHEN status <> 'stale' THEN 1 ELSE 0 END) AS total_entries
             FROM " . self::entries_table() . "
             WHERE blog_id = %d AND target_locale = %s",
            get_current_blog_id(), $locale
        ));
        $ready      = $row ? (int) $row->ready_entries : 0;
        $unresolved = $row ? (int) $row->unresolved_entries : 0;
        $total      = $row ? (int) $row->total_entries : 0;

        $percent = $total > 0 ? (int) floor($ready / $total * 100) : 0;
        if ($percent >= 100 && $unresolved > 0) {
            $percent = 99; // never "100%" while something is still waiting
        }
        return array(
            'percent' => max(0, min(100, $percent)),
            'ready'   => $ready,
            'total'   => $total,
        );
    }

    /**
     * Reset error entries of the current site back to pending.
     *
     * @return int Rows affected.
     */
    public static function retry_errors() {
        global $wpdb;
        return (int) $wpdb->query($wpdb->prepare(
            'UPDATE ' . self::entries_table() .
            " SET status = 'pending', attempts = 0, error_message = NULL, claim_token = NULL, updated_at = UTC_TIMESTAMP()" .
            " WHERE blog_id = %d AND status = 'error' AND locked = 0",
            get_current_blog_id()
        ));
    }

    /**
     * Paginated entry search for the admin UI.
     *
     * @param array $args {search, locale, status, page, per_page}
     * @return array{rows:array,total:int}
     */
    public static function search($args) {
        global $wpdb;
        $where  = array('blog_id = %d');
        $params = array(get_current_blog_id());

        if (!empty($args['locale'])) {
            $where[]  = 'target_locale = %s';
            $params[] = $args['locale'];
        }
        if (!empty($args['status'])) {
            if ($args['status'] === 'manual') {
                $where[] = "origin = 'manual'";
            } else {
                $where[]  = 'status = %s';
                $params[] = $args['status'];
            }
        }
        if (!empty($args['search'])) {
            $like     = '%' . $wpdb->esc_like($args['search']) . '%';
            $where[]  = '(source_text LIKE %s OR translated_text LIKE %s OR context_key LIKE %s)';
            $params[] = $like;
            $params[] = $like;
            $params[] = $like;
        }

        $per_page = max(1, (int) ($args['per_page'] ?? 50));
        $offset   = (max(1, (int) ($args['page'] ?? 1)) - 1) * $per_page;
        $where_sql = implode(' AND ', $where);
        $table     = self::entries_table();

        $total = (int) $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$table} WHERE {$where_sql}", $params
        ));
        $rows = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$table} WHERE {$where_sql} ORDER BY updated_at DESC LIMIT %d OFFSET %d",
            array_merge($params, array($per_page, $offset))
        ));
        return array('rows' => (array) $rows, 'total' => $total);
    }
}
