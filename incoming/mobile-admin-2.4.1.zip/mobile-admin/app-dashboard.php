<?php

/**
 * Plugin Name: Mobile App Management
 * Plugin URI: https://ticinoweb.com/
 * Author: Giovanni Frino
 * Author URI: https://ticinoweb.com/
 * Version: 2.4.1
 * Description: Complete backoffice management system for the Mache Pizza mobile application. Provides admin UI to control app status, manage discounts/coupons, configure promotional slides, push notifications, and category icons. Exposes REST API endpoints for: mobile config, user registration, slides, category icons, and WooCommerce global product addons (required by Firebase Cloud Functions). Integrates with WooCommerce, Simple JWT Login, and Firebase.
 * Text-Domain: wp-app-dashboard
 * Company: ticinoWEB
 * Update URI: https://github.com/gfrino/ticinoweb-wp-themes-and-plugin-releases
 */


if (!defined('ABSPATH')) : exit();
endif; // No direct access allowed.

/**
 * Define Plugins Contants
 */
define('WPADR_PATH', trailingslashit(plugin_dir_path(__FILE__)));
define('WPADR_URL', trailingslashit(plugins_url('/', __FILE__)));
// Version of the bundled includes/tw-release-updater.php (keep in sync with its header).
define('ARD_RELEASE_UPDATER_VERSION', '1.1.0');

/*
 * Updates from the ticinoWEB releases repo (see the Update URI header). The
 * bundled loader is generic and is also installed as a mu-plugin, so updates
 * work in Network Admin and the main site's cron too. If the mu-plugin is
 * already loaded this include is a no-op.
 */
require_once WPADR_PATH . 'includes/tw-release-updater.php';

function ARD_install_release_updater() {
  if ( ! class_exists( 'TW_Release_Updater' ) || TW_Release_Updater::mu_is_current( ARD_RELEASE_UPDATER_VERSION ) ) {
    return;
  }
  if ( get_site_transient( 'ard_release_updater_failed' ) ) {
    return;
  }
  $result = TW_Release_Updater::install_mu( WPADR_PATH . 'includes/tw-release-updater.php' );
  if ( is_wp_error( $result ) ) {
    set_site_transient( 'ard_release_updater_failed', $result->get_error_message(), 12 * HOUR_IN_SECONDS );
  }
}
register_activation_hook( __FILE__, 'ARD_install_release_updater' );
add_action( 'admin_init', function () {
  if ( current_user_can( is_multisite() ? 'manage_network_plugins' : 'activate_plugins' ) ) {
    ARD_install_release_updater();
  }
}, 20 );

/**
 * Shared secret for POST <fetch_url>/config/update (must match CONFIG_SECRET or
 * JWT_SECRET of the Cloud Functions). Never hardcoded: the plugin is published
 * in a public releases repo. Set it in wp-config.php:
 *   define( 'ARD_CONFIG_API_SECRET', '...' );
 * or as a network option: wp site option update ard_config_api_secret '...'
 */
function ARD_config_api_secret() {
  if ( defined( 'ARD_CONFIG_API_SECRET' ) && ARD_CONFIG_API_SECRET ) {
    return (string) ARD_CONFIG_API_SECRET;
  }
  return (string) get_site_option( 'ard_config_api_secret', '' );
}

add_action( 'admin_notices', 'ARD_missing_api_secret_notice' );
add_action( 'network_admin_notices', 'ARD_missing_api_secret_notice' );
function ARD_missing_api_secret_notice() {
  if ( ARD_config_api_secret() !== '' || ! get_option( 'fetch_url' ) || ! current_user_can( 'manage_options' ) ) {
    return;
  }
  echo '<div class="notice notice-error"><p><strong>Mobile App Management:</strong> manca il secret per sincronizzare slide, icone e configurazione con l\'app. Definisci <code>ARD_CONFIG_API_SECRET</code> in <code>wp-config.php</code> oppure l\'opzione di rete <code>ard_config_api_secret</code>.</p></div>';
}

/**
 * Global flag to prevent recursive propagation
 */
global $ARD_WC_PROPAGATING;
$ARD_WC_PROPAGATING = false;

/**
 * Loading Necessary Scripts
 */

add_action('admin_enqueue_scripts', 'ARD_load_scripts');

function ARD_load_scripts( $hook )
{
	 $url = esc_attr( get_option('fetch_url') );
     echo "<script>var fetch_url= '$url';</script>";
  wp_enqueue_style('wp-app-dashboard', WPADR_URL . 'build/main.css', [], '1.0.0', 'all');

  // Enqueue WP Media Library on the Slides admin page so wp.media() works
  if ( isset( $_GET['page'] ) && $_GET['page'] === 'ard_slides' ) {
    wp_enqueue_media();
  }
}

// Inject schedule manager UI (hidden, will be shown when clicking "Stato dell'app")
function ARD_inject_schedule_manager_hidden() {
  $fetch_url = get_option('fetch_url');
  if (empty($fetch_url)) {
    return; // Skip if no Firebase URL configured
  }
  
  $fetch_url_escaped = esc_attr($fetch_url);
  ?>
  <style>
    #ard-schedule-manager {
      display: block;
      position: relative;
      background: #fff;
      border: 1px solid #ddd;
      border-radius: 8px;
      padding: 20px;
      margin: 20px 0 40px 0;
      max-width: 100%;
      width: 100%;
      box-shadow: 0 2px 6px rgba(0,0,0,0.08);
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      z-index: auto;
    }
    #ard-schedule-manager.ard-visible { display: block; }
    #ard-schedule-manager > * { max-width: 100%; margin: 0; }
    #ard-schedule-manager h2 {
      margin: 0 0 20px 0;
      font-size: 24px;
      color: #333;
      border-bottom: 2px solid #2e7d32;
      padding-bottom: 10px;
    }
    .ard-status-display {
      background: #f5f5f5;
      padding: 15px;
      border-radius: 6px;
      margin-bottom: 20px;
    }
    .ard-status-badge {
      display: inline-block;
      padding: 8px 16px;
      border-radius: 20px;
      font-weight: 600;
      font-size: 14px;
      margin-bottom: 10px;
    }
    .ard-status-active { background: #4caf50; color: white; }
    .ard-status-inactive { background: #f44336; color: white; }
    .ard-form-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 20px;
      margin-bottom: 20px;
    }
    .ard-form-field {
      display: flex;
      flex-direction: column;
    }
    .ard-form-field label {
      font-weight: 600;
      margin-bottom: 8px;
      color: #555;
      font-size: 13px;
    }
    .ard-form-field input,
    .ard-form-field textarea {
      padding: 10px;
      border: 1px solid #ddd;
      border-radius: 4px;
      font-size: 14px;
      font-family: inherit;
    }
    .ard-form-field textarea {
      min-height: 80px;
      resize: vertical;
    }
    .ard-button {
      padding: 12px 24px;
      border: none;
      border-radius: 4px;
      font-size: 14px;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.2s;
    }
    .ard-button-primary {
      background: #2e7d32;
      color: white;
    }
    .ard-button-primary:hover {
      background: #1b5e20;
    }
    .ard-button-danger {
      background: #f44336;
      color: white;
    }
    .ard-button-danger:hover {
      background: #d32f2f;
    }
    .ard-message {
      padding: 12px;
      border-radius: 4px;
      margin-top: 15px;
      font-size: 14px;
    }
    .ard-message-success {
      background: #4caf50;
      color: white;
    }
    .ard-message-error {
      background: #f44336;
      color: white;
    }
    .ard-schedule-info {
      background: #fff3cd;
      border-left: 4px solid #ffc107;
      padding: 12px;
      margin-bottom: 15px;
      font-size: 14px;
    }
  </style>

  <div class="wrap"><div id="ard-schedule-manager">
    <h2>📅 Gestione Programmazione Chiusura App</h2>
    
    <div class="ard-status-display" id="ard-current-status">
      <div>Caricamento stato attuale...</div>
    </div>

    <div class="ard-schedule-info">
      <strong>ℹ️ Come funziona:</strong><br>
      Programma la chiusura temporanea dell'app mobile. Durante il periodo specificato, l'app mostrerà il messaggio personalizzato agli utenti. L'app si riattiverà automaticamente alla fine del periodo.
    </div>

    <div class="ard-form-grid">
      <div class="ard-form-field">
        <label>📅 Data/Ora Inizio Chiusura</label>
        <input type="datetime-local" id="ard-start-datetime" />
      </div>
      <div class="ard-form-field">
        <label>📅 Data/Ora Fine Chiusura</label>
        <input type="datetime-local" id="ard-end-datetime" />
      </div>
    </div>

    <div class="ard-form-grid">
      <div class="ard-form-field">
        <label>📝 Titolo Messaggio</label>
        <input type="text" id="ard-title" placeholder="Es: App Chiusa per Festività" maxlength="100" />
      </div>
      <div class="ard-form-field">
        <label>📝 Descrizione Messaggio</label>
        <textarea id="ard-description" placeholder="Es: Saremo di nuovo online il 1° gennaio. Buone feste!"></textarea>
      </div>
    </div>

    <div style="display: flex; gap: 10px; align-items: center;">
      <button class="ard-button ard-button-primary" onclick="ARD_saveSchedule()">
        💾 Salva Programmazione
      </button>
      <button class="ard-button ard-button-danger" onclick="ARD_clearSchedule()">
        🗑️ Rimuovi Programmazione
      </button>
    </div>

    <div id="ard-message"></div>
  </div></div>

  <script>
  (function() {
    const API_URL = '<?php echo $fetch_url_escaped; ?>';
    let currentStatus = null;

    // Load current status on page load
    async function loadCurrentStatus() {
      try {
        const response = await fetch(API_URL + '/appStatus');
        if (!response.ok) throw new Error('Errore caricamento stato');
        
        currentStatus = await response.json();
        displayCurrentStatus();
        populateForm();
      } catch (error) {
        document.getElementById('ard-current-status').innerHTML = 
          '<span style="color:#f44336;">❌ Errore caricamento: ' + error.message + '</span>';
      }
    }

    function displayCurrentStatus() {
      const now = Date.now();
      const inactivity = currentStatus.inactivity || {};
      const startAt = inactivity.startAt || 0;
      const endAt = inactivity.endAt || 0;
      
      let statusHtml = '';
      let isInScheduledPeriod = now >= startAt && now <= endAt;
      let hasFutureSchedule = startAt > now;
      
      if (isInScheduledPeriod) {
        const endDate = new Date(endAt);
        const endStr = formatDateTime(endDate);
        statusHtml = `
          <span class="ard-status-badge ard-status-inactive">🔴 App Attualmente Inattiva</span>
          <div style="margin-top:10px;">
            <strong>Programmazione Attiva:</strong><br>
            Riapertura prevista: <strong>${endStr}</strong>
          </div>
          <div style="margin-top:8px;">
            <strong>Messaggio:</strong> ${currentStatus.title || 'N/A'}<br>
            <strong>Descrizione:</strong> ${currentStatus.description || 'N/A'}
          </div>
        `;
      } else if (hasFutureSchedule) {
        const startDate = new Date(startAt);
        const endDate = new Date(endAt);
        const startStr = formatDateTime(startDate);
        const endStr = formatDateTime(endDate);
        statusHtml = `
          <span class="ard-status-badge ard-status-active">🟢 App Attualmente Attiva</span>
          <div style="margin-top:10px;">
            <strong>⏰ Chiusura Programmata:</strong><br>
            Dal <strong>${startStr}</strong><br>
            Al <strong>${endStr}</strong>
          </div>
          <div style="margin-top:8px;">
            <strong>Messaggio programmato:</strong> ${currentStatus.title || 'N/A'}<br>
            <strong>Descrizione:</strong> ${currentStatus.description || 'N/A'}
          </div>
        `;
      } else {
        statusHtml = `
          <span class="ard-status-badge ard-status-active">🟢 App Attualmente Attiva</span>
          <div style="margin-top:10px;">Nessuna chiusura programmata</div>
        `;
      }
      
      document.getElementById('ard-current-status').innerHTML = statusHtml;
    }

    function populateForm() {
      const inactivity = currentStatus.inactivity || {};
      
      if (inactivity.startAt) {
        document.getElementById('ard-start-datetime').value = 
          new Date(inactivity.startAt).toISOString().slice(0, 16);
      }
      if (inactivity.endAt) {
        document.getElementById('ard-end-datetime').value = 
          new Date(inactivity.endAt).toISOString().slice(0, 16);
      }
      if (currentStatus.title) {
        document.getElementById('ard-title').value = currentStatus.title;
      }
      if (currentStatus.description) {
        document.getElementById('ard-description').value = currentStatus.description;
      }
    }

    function formatDateTime(date) {
      return date.toLocaleString('it-IT', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      });
    }

    function showMessage(text, isError = false) {
      const msgDiv = document.getElementById('ard-message');
      msgDiv.className = 'ard-message ' + (isError ? 'ard-message-error' : 'ard-message-success');
      msgDiv.textContent = text;
      setTimeout(() => msgDiv.textContent = '', 5000);
    }

    window.ARD_saveSchedule = async function() {
      const startVal = document.getElementById('ard-start-datetime').value;
      const endVal = document.getElementById('ard-end-datetime').value;
      const title = document.getElementById('ard-title').value.trim();
      const description = document.getElementById('ard-description').value.trim();

      if (!startVal || !endVal) {
        showMessage('⚠️ Inserisci data/ora inizio e fine', true);
        return;
      }

      const startDate = new Date(startVal);
      const endDate = new Date(endVal);

      if (endDate <= startDate) {
        showMessage('⚠️ La data di fine deve essere successiva alla data di inizio', true);
        return;
      }

      if (!title) {
        showMessage('⚠️ Inserisci un titolo per il messaggio', true);
        return;
      }

      try {
        const payload = {
          isOnline: false,
          title: title,
          description: description || '',
          inactivity: {
            startAt: startDate.getTime(),
            endAt: endDate.getTime()
          }
        };

        const response = await fetch(API_URL + '/appStatus', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        });

        if (!response.ok) throw new Error('Errore salvataggio');

        showMessage('✅ Programmazione salvata con successo!');
        setTimeout(() => loadCurrentStatus(), 1000);
      } catch (error) {
        showMessage('❌ Errore: ' + error.message, true);
      }
    };

    window.ARD_clearSchedule = async function() {
      if (!confirm('Sei sicuro di voler rimuovere la programmazione?')) return;

      try {
        const payload = {
          isOnline: true,
          title: '',
          description: '',
          inactivity: {
            startAt: 0,
            endAt: 0
          }
        };

        const response = await fetch(API_URL + '/appStatus', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        });

        if (!response.ok) throw new Error('Errore rimozione');

        showMessage('✅ Programmazione rimossa!');
        document.getElementById('ard-start-datetime').value = '';
        document.getElementById('ard-end-datetime').value = '';
        document.getElementById('ard-title').value = '';
        document.getElementById('ard-description').value = '';
        setTimeout(() => loadCurrentStatus(), 1000);
      } catch (error) {
        showMessage('❌ Errore: ' + error.message, true);
      }
    };

    // Initialize - show panel immediately since we're on the right page
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', () => {
        const panel = document.getElementById('ard-schedule-manager');
        if (panel) {
          panel.classList.add('ard-visible');
          loadCurrentStatus();
        }
      });
    } else {
      const panel = document.getElementById('ard-schedule-manager');
      if (panel) {
        panel.classList.add('ard-visible');
        loadCurrentStatus();
      }
    }
  })();
  </script>
  <?php
}

function ADR_showContent()
{
  $mainHTML = file_get_contents(WPADR_URL . 'build/index.html');

  echo $mainHTML;
}

add_action('admin_menu', 'ADR_createMenuOption');

function ADR_createMenuOption()
{
  // Main icon for all menu items
  $icon_url = plugin_dir_url(__FILE__) . 'icon.png';
  
  // Parent: Gestione App (with icon)
  add_menu_page(
    'Gestione App', // Page Title
    'Gestione App', // Menu Title
    'manage_options', // Capability
    'ard_stato_app', // slug
    'ARD_showContent_stato_app',
    $icon_url // icon
  );
  
  // Child: Notifications
  add_submenu_page(
    'ard_stato_app', // Parent slug
    'Notifiche', // Page Title
    'Notifiche', // Menu Title
    'manage_options', // Capability
    'ard_notifications', // slug
    'ARD_showContent_notifications'
  );
  
  // Child: Impostazioni
  add_submenu_page(
    'ard_stato_app', // Parent slug
    'Impostazioni', // Page Title
    'Impostazioni', // Menu Title
    'manage_options', // Capability
    'app_administration_backoffice_settings', // slug
    'ADR_showContent_settings'
  );

  // Child: Slides
  add_submenu_page(
    'ard_stato_app', // Parent slug
    'Slides Home', // Page Title
    'Slides', // Menu Title
    'manage_options', // Capability
    'ard_slides', // slug
    'ARD_showContent_slides'
  );

  // Child: Icone Categorie
  add_submenu_page(
    'ard_stato_app', // Parent slug
    'Icone Categorie', // Page Title
    'Icone Categorie', // Menu Title
    'manage_options', // Capability
    'ard_category_icons', // slug
    'ARD_showContent_category_icons'
  );
  
  // WooCommerce Site Status page (separate)
  add_menu_page(
    'Gestione Sito WooCommerce', // Page Title
    'Gestione Woo', // Menu Title
    'manage_options', // Capability
    'wc_site_status', // slug
    'ADR_showContent_wc_status',
    $icon_url // icon
  );
  
  // Register settings
  add_action( 'admin_init', 'register_Backoffice_settings' );
  add_action('admin_init', 'register_wc_status_settings');
  add_action( 'admin_init', 'ARD_register_slides_settings' );
  add_action( 'admin_init', 'ARD_register_category_icons_settings' );
}

function ARD_showContent_stato_app()
{
  ARD_inject_schedule_manager_hidden();
}

function ARD_showContent_notifications()
{
  ARD_inject_notifications_manager_hidden();
}

function register_Backoffice_settings() {
	//register our settings
	register_setting( 'Backoffice-settings-group', 'fetch_url' );
	register_setting( 'Backoffice-settings-group', 'stripe_publishable_key' );
	register_setting( 'Backoffice-settings-group', 'app_site_url' );
	register_setting( 'Backoffice-settings-group', 'app_wc_consumer_key' );
	register_setting( 'Backoffice-settings-group', 'app_wc_consumer_secret' );
}

/**
 * Sync app configuration to Firestore via Cloud Functions when settings are saved.
 * This allows Cloud Functions to read the site URL and WooCommerce keys
 * dynamically without redeploying.
 */
function ARD_sync_config_to_firestore() {
  $fetch_url        = get_option( 'fetch_url' );
  $app_site_url     = get_option( 'app_site_url' );
  $wc_consumer_key  = get_option( 'app_wc_consumer_key' );
  $wc_consumer_secret = get_option( 'app_wc_consumer_secret' );

  if ( empty( $fetch_url ) ) {
    return; // No Cloud Functions URL configured
  }

  if ( ARD_config_api_secret() === '' ) {
    error_log( '[MobileAdmin] Config sync skipped: ARD_CONFIG_API_SECRET not configured' );
    return;
  }

  $config_endpoint = rtrim( $fetch_url, '/' ) . '/config/update';

  $payload = array(
    'apiSecret'        => ARD_config_api_secret(), // Must match CONFIG_SECRET / JWT_SECRET of the Cloud Functions
    'siteUrl'          => $app_site_url ?: site_url(),
    'wooConsumerKey'   => $wc_consumer_key,
    'wooConsumerSecret' => $wc_consumer_secret,
  );

  $response = wp_remote_post( $config_endpoint, array(
    'body'    => wp_json_encode( $payload ),
    'headers' => array( 'Content-Type' => 'application/json' ),
    'timeout' => 15,
  ) );

  if ( is_wp_error( $response ) ) {
    error_log( '[MobileAdmin] Config sync to Firestore failed: ' . $response->get_error_message() );
  } else {
    $code = wp_remote_retrieve_response_code( $response );
    if ( $code !== 200 ) {
      error_log( '[MobileAdmin] Config sync returned HTTP ' . $code . ': ' . wp_remote_retrieve_body( $response ) );
    }
  }
}
add_action( 'update_option_app_site_url', 'ARD_sync_config_to_firestore', 10, 0 );
add_action( 'update_option_app_wc_consumer_key', 'ARD_sync_config_to_firestore', 10, 0 );
add_action( 'update_option_app_wc_consumer_secret', 'ARD_sync_config_to_firestore', 10, 0 );

// WooCommerce Site Status settings
function register_wc_status_settings() {
  register_setting( 'wc-status-settings-group', 'wc_closed_message', [ 'default' => 'Ordini temporaneamente sospesi. Torna più tardi.' ] );
  // Scheduling options (date and time range)
  register_setting( 'wc-status-settings-group', 'wc_schedule_enabled', [ 'default' => 0 ] );
  register_setting( 'wc-status-settings-group', 'wc_closed_start_date', [ 'default' => '' ] ); // YYYY-MM-DD
  register_setting( 'wc-status-settings-group', 'wc_closed_end_date', [ 'default' => '' ] ); // YYYY-MM-DD
  register_setting( 'wc-status-settings-group', 'wc_closed_start_time', [ 'default' => '' ] ); // HH:MM
  register_setting( 'wc-status-settings-group', 'wc_closed_end_time', [ 'default' => '' ] ); // HH:MM
  // Multisite linked sites (array of blog IDs)
  register_setting( 'wc-status-settings-group', 'wc_schedule_linked_sites', [ 'default' => [] ] );
}

function ADR_showContent_settings() {
?>
<div class="wrap">
<h1>Mobile App Settings Page</h1>

<form method="post" action="options.php">
    <?php settings_fields( 'Backoffice-settings-group' ); ?>
    <?php do_settings_sections( 'Backoffice-settings-group' ); ?>
    <table class="form-table">
        <tr valign="top">
        <th scope="row">Firebase Cloud Functions URL</th>
        <td><input type="text" name="fetch_url" value="<?php echo esc_attr( get_option('fetch_url') ); ?>" class="regular-text" placeholder="https://europe-west1-project.cloudfunctions.net" /></td>
        </tr>
        <tr valign="top">
        <th scope="row">WordPress Site URL (per l'app)</th>
        <td>
            <input type="text" name="app_site_url" value="<?php echo esc_attr( get_option('app_site_url', site_url()) ); ?>" class="regular-text" placeholder="https://machepizza.ch" />
            <p class="description">L'URL del sito WordPress che le Cloud Functions useranno per le API WooCommerce. Viene sincronizzato automaticamente su Firestore.</p>
        </td>
        </tr>
        <tr valign="top">
        <th scope="row">WooCommerce Consumer Key</th>
        <td>
            <input type="text" name="app_wc_consumer_key" value="<?php echo esc_attr( get_option('app_wc_consumer_key') ); ?>" class="regular-text" placeholder="ck_..." />
            <p class="description">Consumer Key dalle impostazioni API di WooCommerce. Sincronizzato su Firestore.</p>
        </td>
        </tr>
        <tr valign="top">
        <th scope="row">WooCommerce Consumer Secret</th>
        <td>
            <input type="password" name="app_wc_consumer_secret" value="<?php echo esc_attr( get_option('app_wc_consumer_secret') ); ?>" class="regular-text" placeholder="cs_..." />
            <p class="description">Consumer Secret dalle impostazioni API di WooCommerce. Sincronizzato su Firestore.</p>
        </td>
        </tr>
    </table>
    
    <?php submit_button(); ?>

</form>

<hr style="margin: 40px 0 20px 0; border: 0; border-top: 1px solid #ccc;" />

<div class="card" style="max-width: 800px; margin-top: 20px; border-left: 4px solid #2e7d32; border-radius: 4px; padding: 20px; background: #fff; box-shadow: 0 1px 3px rgba(0,0,0,0.1);">
    <h2 style="margin-top: 0; color: #2e7d32; font-size: 1.3em;">ℹ️ CAP di consegna, minimi d'ordine e selettore CAP</h2>
    <p>Fonte di verità: le <strong>Zone di Spedizione WooCommerce di ciascun sottosito</strong>. Ecco come funziona il sistema:</p>
    <ol style="padding-left: 20px; line-height: 1.5; margin-bottom: 0;">
        <li><strong>CAP di consegna (per sede):</strong>
            <br />Su ogni sottosito, in <code>WooCommerce &gt; Impostazioni &gt; Spedizione &gt; Zone di spedizione</code>, i CAP delle zone con un metodo <strong>Tariffa Unica</strong> o <strong>Spedizione Gratuita</strong> attivo definiscono dove quella sede consegna.
            <br />Il plugin legge queste zone da tutti i sottositi (endpoint <code>/wp-json/wpadr/v1/delivery-caps</code>, cache 10 minuti) e le espone allo shortcode <code>[wpadr_cap_selector]</code>: inseriscilo nella pagina di smistamento del sito principale al posto della selezione CAP manuale. Un CAP va gestito in un punto solo: la zona di spedizione del sottosito.
        </li>
        <li style="margin-top: 10px;"><strong>Minimo d'ordine per la consegna (per sede, non per CAP):</strong>
            <br />È il valore configurato nel plugin WooDelivery del sottosito (restrizione carrello, es. <code>24.90</code> a Biasca) e viene applicato dalle Cloud Functions su tutti i metodi di pagamento dell'app. Un unico minimo per sede.
        </li>
        <li style="margin-top: 10px;"><strong>Minimo per Tariffa Unica (solo carrello del sito web):</strong>
            <br />I campi <em>Abilita importo minimo / Soglia importo minimo</em> aggiunti da questo plugin al metodo Tariffa Unica agiscono sul checkout <strong>del sito web</strong> (nascondono la tariffa sotto soglia). <strong>Non</strong> sono letti dall'app mobile.
        </li>
    </ol>
</div>
</div>
<?php }

// WooCommerce Site Status admin page
function ADR_showContent_wc_status() {
  $message = esc_attr( get_option('wc_closed_message', 'Ordini temporaneamente sospesi. Torna più tardi.') );
  $schedule_enabled = (int) get_option('wc_schedule_enabled', 0);
  $start_date = esc_attr( get_option('wc_closed_start_date', '') );
  $end_date   = esc_attr( get_option('wc_closed_end_date', '') );
  $orders_open = ARD_wc_orders_open();
  $linked_sites = (array) get_option('wc_schedule_linked_sites', [] );
  if ( empty($linked_sites) ) { $linked_sites = [ get_current_blog_id() ]; }
  $sites_list = ARD_wc_get_sites_list();
?>
<div class="wrap">
  <h1>Gestione Woo</h1>
  <p>Stato ordini WooCommerce determinato dalla pianificazione. Quando disattivato, i clienti non potranno aggiungere prodotti al carrello né completare il checkout e verrà mostrato un banner rosso in alto sul sito.</p>

  <style>
    .ard-switch-row { display:flex; align-items:center; gap:16px; }
    .ard-switch {
      appearance: none; border: none; cursor: pointer; padding: 10px 16px; border-radius: 24px;
      font-size: 16px; font-weight: 600; color: #fff; transition: all .2s ease-in-out;
    }
    .ard-switch[data-active="1"] { background: #2e7d32; }
    .ard-switch[data-active="0"] { background: #b00020; }
    .ard-switch:focus { outline: 2px solid #1976d2; }
  </style>

  <form method="post" action="options.php">
    <?php settings_fields( 'wc-status-settings-group' ); ?>
    <?php do_settings_sections( 'wc-status-settings-group' ); ?>
    <table class="form-table">
      <tr valign="top">
        <th scope="row">Ordini WooCommerce</th>
        <td>
          <div class="ard-switch-row">
            <span class="ard-switch" style="cursor: default;" data-active="<?php echo $orders_open ? '1' : '0'; ?>">
              <?php echo $orders_open ? 'Ordini ATTIVI' : 'Ordini CHIUSI'; ?>
            </span>
          </div>
          <p class="description">Lo stato è calcolato automaticamente in base alla pianificazione sotto. Il pulsante non è cliccabile.</p>
        </td>
      </tr>
      <tr valign="top">
        <th scope="row">Messaggio ai clienti</th>
        <td>
          <textarea name="wc_closed_message" rows="3" cols="60"><?php echo $message; ?></textarea>
          <p class="description">Questo testo viene mostrato globalmente: nel banner rosso in alto e come avviso nel carrello/checkout quando gli ordini sono disattivati.</p>
        </td>
      </tr>
      <tr valign="top">
        <th scope="row">Pianificazione</th>
        <td>
          <label for="wc_schedule_enabled">
            <input type="checkbox" id="wc_schedule_enabled" name="wc_schedule_enabled" value="1" <?php checked( 1, $schedule_enabled ); ?> />
            Abilita pianificazione (chiusura automatica per intervallo di date)
          </label>
          <p class="description">Quando attiva, gli ordini verranno chiusi automaticamente tra le date e ore indicate.</p>
          <hr />
          <strong>Intervallo di chiusura</strong><br />
          <label>Dal: <input type="date" name="wc_closed_start_date" value="<?php echo $start_date; ?>" /></label>
          &nbsp;
          <label>Ore: <input type="time" name="wc_closed_start_time" value="<?php echo esc_attr( get_option('wc_closed_start_time', '') ); ?>" placeholder="00:00" /></label>
          <br /><br />
          <label>Al: <input type="date" name="wc_closed_end_date" value="<?php echo $end_date; ?>" /></label>
          &nbsp;
          <label>Ore: <input type="time" name="wc_closed_end_time" value="<?php echo esc_attr( get_option('wc_closed_end_time', '') ); ?>" placeholder="23:59" /></label>
          <p class="description">Formato data: YYYY-MM-DD, ora: HH:MM (24h). Se non imposti l'ora, viene usato l'inizio (00:00) o fine (23:59) della giornata.</p>
          <?php if ( is_multisite() ) : ?>
          <hr />
          <strong>Siti collegati (Multisite)</strong>
          <p class="description">Seleziona i siti che devono seguire queste stesse impostazioni di chiusura.</p>
          <table id="wc-linked-sites" class="widefat" style="max-width:720px;">
            <thead><tr><th style="width:80%; padding-left: 16px;">Sito</th><th style="width:20%;">Azioni</th></tr></thead>
            <tbody>
            <?php foreach ( $linked_sites as $idx => $blog_id ) : ?>
              <tr>
                <td>
                  <select name="wc_schedule_linked_sites[]" <?php echo ($blog_id === get_current_blog_id()) ? 'disabled' : ''; ?>>
                    <?php foreach ( $sites_list as $sid => $label ) : ?>
                      <option value="<?php echo (int)$sid; ?>" <?php selected( (int)$sid, (int)$blog_id ); ?>><?php echo esc_html( $label ); ?></option>
                    <?php endforeach; ?>
                  </select>
                  <?php if ( $blog_id === get_current_blog_id() ) : ?>
                    <input type="hidden" name="wc_schedule_linked_sites[]" value="<?php echo (int) get_current_blog_id(); ?>" />
                    <small>(Sito corrente)</small>
                  <?php endif; ?>
                </td>
                <td>
                  <?php if ( $blog_id !== get_current_blog_id() ) : ?>
                  <button type="button" class="button link-delete-row">Rimuovi</button>
                  <?php else: ?>
                  <span class="button disabled">—</span>
                  <?php endif; ?>
                </td>
              </tr>
            <?php endforeach; ?>
            </tbody>
          </table>
          <?php if ( is_super_admin() ) : ?>
            <p><button type="button" class="button button-secondary" id="wc-add-linked-site">Aggiungi sito</button></p>
          <?php endif; ?>
          <p class="description">Nota: per mostrare il banner e bloccare gli ordini anche nei siti collegati, il plugin deve essere attivo su quei siti (oppure attivato a livello di network).</p>
          <script>
          (function(){
            var sites = <?php echo wp_json_encode( $sites_list ); ?>;
            var currentId = <?php echo (int) get_current_blog_id(); ?>;
            var table = document.getElementById('wc-linked-sites');
            var addBtn = document.getElementById('wc-add-linked-site');
            function makeRow(selected){
              var tr = document.createElement('tr');
              var td1 = document.createElement('td');
              var td2 = document.createElement('td');
              var sel = document.createElement('select');
              sel.name = 'wc_schedule_linked_sites[]';
              for (var sid in sites){ if(!sites.hasOwnProperty(sid)) continue; var opt = document.createElement('option'); opt.value = sid; opt.textContent = sites[sid]; sel.appendChild(opt); }
              if (selected) sel.value = String(selected);
              td1.appendChild(sel);
              var rm = document.createElement('button'); rm.type='button'; rm.className='button link-delete-row'; rm.textContent='Rimuovi';
              rm.addEventListener('click', function(){ tr.parentNode.removeChild(tr); });
              td2.appendChild(rm);
              tr.appendChild(td1); tr.appendChild(td2);
              return tr;
            }
            addBtn && addBtn.addEventListener('click', function(){
              var tbody = table.querySelector('tbody');
              tbody.appendChild( makeRow(null) );
            });
            table.addEventListener('click', function(e){
              if (e.target && e.target.classList.contains('link-delete-row')){
                var tr = e.target.closest('tr');
                if (tr){ tr.parentNode.removeChild(tr); }
              }
            });
          })();
          </script>
          <?php endif; ?>
        </td>
      </tr>
    </table>

    <?php submit_button(); ?>
  </form>
</div>
<!-- Stato ordini basato su pianificazione; nessuna interazione JS necessaria -->
<?php }

// Block WooCommerce ordering when disabled
function ARD_wc_is_purchasable( $purchasable, $product ) {
  // Don't block if it's a backend/admin request (allows printer and other backend processes)
  if ( is_admin() || wp_doing_cron() || ( defined('REST_REQUEST') && REST_REQUEST ) ) {
    return $purchasable;
  }
  
  if ( ! ARD_wc_orders_open() ) {
    return false;
  }
  return $purchasable;
}
add_filter( 'woocommerce_is_purchasable', 'ARD_wc_is_purchasable', 10, 2 );

function ARD_wc_add_to_cart_validation( $passed, $product_id, $quantity ) {
  // Don't block if it's a backend/admin request (allows printer and other backend processes)
  if ( is_admin() || wp_doing_cron() || ( defined('REST_REQUEST') && REST_REQUEST ) ) {
    return $passed;
  }
  
  if ( ! ARD_wc_orders_open() ) {
    $msg = get_option('wc_closed_message', 'Ordini temporaneamente sospesi. Torna più tardi.');
    wc_add_notice( $msg, 'error' );
    return false;
  }
  return $passed;
}
add_filter( 'woocommerce_add_to_cart_validation', 'ARD_wc_add_to_cart_validation', 10, 3 );

function ARD_wc_before_checkout_form() {
  if ( ! ARD_wc_orders_open() ) {
    $msg = get_option('wc_closed_message', 'Ordini temporaneamente sospesi. Torna più tardi.');
    wc_print_notice( $msg, 'error' );
  }
}
add_action( 'woocommerce_before_checkout_form', 'ARD_wc_before_checkout_form', 5 );

function ARD_wc_checkout_process_block() {
  // Don't block if it's a backend/admin request (allows printer and other backend processes)
  if ( is_admin() || wp_doing_cron() || ( defined('REST_REQUEST') && REST_REQUEST ) ) {
    return;
  }
  
  if ( ! ARD_wc_orders_open() ) {
    $msg = get_option('wc_closed_message', 'Ordini temporaneamente sospesi. Torna più tardi.');
    wc_add_notice( $msg, 'error' );
  }
}
add_action( 'woocommerce_checkout_process', 'ARD_wc_checkout_process_block' );

// Frontend global banner output (when orders disabled)
function ARD_wc_banner_head() {
  // Don't show banner on admin pages, AJAX, or REST API requests
  if ( is_admin() || wp_doing_ajax() || ( defined('REST_REQUEST') && REST_REQUEST ) ) { return; }
  if ( ARD_wc_orders_open() ) { return; }
  ?>
  <style id="ard-wc-site-banner-css">
    #ard-wc-site-banner { position: fixed; top: 0; left: 0; right: 0; background: #b00020; color: #fff; padding: 12px 16px; text-align: center; z-index: 99999; box-shadow: 0 2px 6px rgba(0,0,0,.15); font-size: 16px; line-height: 1.4; }
    #ard-wc-site-banner .ard-wc-site-banner__text { display: inline-block; margin: 0; }
    html { scroll-padding-top: 52px; }
    body { padding-top: 52px; }
    @media (max-width:768px){ html{ scroll-padding-top: 64px; } body{ padding-top: 64px; } }
  </style>
  <?php
}
add_action( 'wp_head', 'ARD_wc_banner_head', 20 );

function ARD_wc_render_site_banner() {
  // Don't show banner on admin pages, AJAX, or REST API requests
  if ( is_admin() || wp_doing_ajax() || ( defined('REST_REQUEST') && REST_REQUEST ) ) { return; }
  if ( ARD_wc_orders_open() ) { return; }
  $text = get_option('wc_closed_message', 'Ordini temporaneamente sospesi. Torna più tardi.' );
  ?>
  <div id="ard-wc-site-banner" role="status" aria-live="polite">
    <span class="ard-wc-site-banner__text"><?php echo esc_html( $text ); ?></span>
  </div>
  <?php
}
add_action( 'wp_footer', 'ARD_wc_render_site_banner', 5 );
// Try to render at the very top when theme supports wp_body_open
add_action( 'wp_body_open', 'ARD_wc_render_site_banner', 1 );

// Ensure banner appears even if theme omits wp_footer/wp_body_open
function ARD_wc_banner_script_inject() {
  // Don't inject script on admin pages, AJAX, or REST API requests
  if ( is_admin() || wp_doing_ajax() || ( defined('REST_REQUEST') && REST_REQUEST ) ) { return; }
  if ( ARD_wc_orders_open() ) { return; }
  $text = get_option('wc_closed_message', 'Ordini temporaneamente sospesi. Torna più tardi.' );
  ?>
  <script id="ard-wc-site-banner-js">
    (function(){
      var text = <?php echo json_encode( $text ); ?>;
      function ensureBanner(){
        if (!document.getElementById('ard-wc-site-banner')){
          var div = document.createElement('div');
          div.id = 'ard-wc-site-banner';
          div.setAttribute('role','status');
          div.setAttribute('aria-live','polite');
          var span = document.createElement('span');
          span.className = 'ard-wc-site-banner__text';
          span.textContent = text;
          div.appendChild(span);
          var body = document.body;
          if (body.firstChild){ body.insertBefore(div, body.firstChild); }
          else { body.appendChild(div); }
        }
      }
      if (document.readyState === 'loading'){
        document.addEventListener('DOMContentLoaded', ensureBanner);
      } else {
        ensureBanner();
      }
    })();
  </script>
  <?php
}
add_action( 'wp_head', 'ARD_wc_banner_script_inject', 21 );

/**
 * Auto-reset expired schedule dates.
 * If end_date has passed, reset both start and end dates to allow orders to reopen.
 * This function runs via WP-Cron hourly.
 */
function ARD_wc_auto_reset_expired_schedule() {
  // Only reset if scheduling is actually enabled
  $schedule_enabled = (int) get_option('wc_schedule_enabled', 0) === 1;
  if ( ! $schedule_enabled ) { return; }

  $now = current_time( 'timestamp' );
  $current_datetime = date( 'Y-m-d H:i', $now );
  
  $start_date = (string) get_option( 'wc_closed_start_date', '' );
  $end_date   = (string) get_option( 'wc_closed_end_date', '' );
  $start_time = (string) get_option( 'wc_closed_start_time', '' );
  $end_time   = (string) get_option( 'wc_closed_end_time', '' );
  
  // If no end date and start is in the past, this is a permanent closure - don't reset
  if ( $end_date === '' && $start_date !== '' ) {
    return; // Keep permanent closure as-is
  }
  
  // Build end datetime (default to 23:59 if no time specified)
  $end_datetime = $end_date !== '' ? $end_date . ' ' . ( $end_time !== '' ? $end_time : '23:59' ) : '';
  
  // If end_datetime is set and has passed, reset all schedule fields
  if ( $end_datetime !== '' && $current_datetime > $end_datetime ) {
    update_option( 'wc_closed_start_date', '' );
    update_option( 'wc_closed_end_date', '' );
    update_option( 'wc_closed_start_time', '' );
    update_option( 'wc_closed_end_time', '' );
    
    // This update_option call will trigger propagation to linked sites automatically
    // via the update_option hooks
  }
}

/**
 * Register WP-Cron hook for auto-reset (runs hourly)
 */
function ARD_wc_schedule_auto_reset() {
  if ( ! wp_next_scheduled( 'ard_wc_auto_reset_hook' ) ) {
    wp_schedule_event( time(), 'hourly', 'ard_wc_auto_reset_hook' );
  }
}
add_action( 'wp_loaded', 'ARD_wc_schedule_auto_reset' );
add_action( 'ard_wc_auto_reset_hook', 'ARD_wc_auto_reset_expired_schedule' );

/**
 * Cleanup: unschedule when plugin deactivates
 */
function ARD_wc_unschedule_auto_reset() {
  wp_clear_scheduled_hook( 'ard_wc_auto_reset_hook' );
}
register_deactivation_hook( __FILE__, 'ARD_wc_unschedule_auto_reset' );

// Helper: determine if orders are open considering schedule
function ARD_wc_orders_open() {
  // Scheduling-only control: if scheduling disabled, orders are open
  $schedule_enabled = (int) get_option('wc_schedule_enabled', 0) === 1;
  if ( ! $schedule_enabled ) { return true; }

  $now = current_time( 'timestamp' ); // WP local time
  $current_datetime = date( 'Y-m-d H:i', $now ); // YYYY-MM-DD HH:MM

  $start_date = (string) get_option( 'wc_closed_start_date', '' );
  $end_date   = (string) get_option( 'wc_closed_end_date', '' );
  $start_time = (string) get_option( 'wc_closed_start_time', '' );
  $end_time   = (string) get_option( 'wc_closed_end_time', '' );

  // If both dates empty, scheduling has no effect
  if ( $start_date === '' && $end_date === '' ) { return true; }

  // Build full datetime strings (default times: start=00:00, end=23:59)
  $start_datetime = $start_date !== '' ? $start_date . ' ' . ( $start_time !== '' ? $start_time : '00:00' ) : '';
  $end_datetime   = $end_date !== '' ? $end_date . ' ' . ( $end_time !== '' ? $end_time : '23:59' ) : '';

  // Compare YYYY-MM-DD HH:MM strings lexicographically (works because consistent format)
  if ( $start_datetime !== '' && $end_datetime !== '' ) {
    if ( $current_datetime >= $start_datetime && $current_datetime <= $end_datetime ) { return false; }
  } elseif ( $start_datetime !== '' ) {
    if ( $current_datetime >= $start_datetime ) { return false; }
  } elseif ( $end_datetime !== '' ) {
    if ( $current_datetime <= $end_datetime ) { return false; }
  }

  return true;
}

// Force no-caching when orders are closed
function ARD_wc_nocache_when_closed() {
  // Don't modify headers for CloudPRNT printer requests
  if ( isset($_SERVER['REQUEST_URI']) && strpos($_SERVER['REQUEST_URI'], 'cloudprnt') !== false ) {
    return;
  }
  // Don't modify headers for backend requests
  if ( is_admin() || wp_doing_cron() || ( defined('REST_REQUEST') && REST_REQUEST ) ) {
    return;
  }
  
  if ( ARD_wc_orders_open() ) { return; }
  nocache_headers();
  // Extra safety for some caches
  header( 'Cache-Control: no-store, no-cache, must-revalidate, max-age=0' );
  header( 'Pragma: no-cache' );
  header( 'Expires: 0' );
}
add_action( 'send_headers', 'ARD_wc_nocache_when_closed' );

function ARD_wc_meta_nocache() {
  // Don't output meta tags for CloudPRNT or backend requests
  if ( is_admin() || wp_doing_ajax() || ( defined('REST_REQUEST') && REST_REQUEST ) ) {
    return;
  }
  if ( isset($_SERVER['REQUEST_URI']) && strpos($_SERVER['REQUEST_URI'], 'cloudprnt') !== false ) {
    return;
  }
  
  if ( ARD_wc_orders_open() ) { return; }
  echo "\n<meta http-equiv=\"Cache-Control\" content=\"no-cache, no-store, must-revalidate\">\n";
  echo "<meta http-equiv=\"Pragma\" content=\"no-cache\">\n";
  echo "<meta http-equiv=\"Expires\" content=\"0\">\n";
}
add_action( 'wp_head', 'ARD_wc_meta_nocache', 1 );

// ===== Multisite propagation =====
global $ARD_WC_PROPAGATING; $ARD_WC_PROPAGATING = false;

function ARD_wc_get_sites_list() {
  $list = [];
  if ( ! is_multisite() ) { return $list; }
  $sites = get_sites([ 'number' => 0 ]);
  foreach ( $sites as $site ) {
    $id = (int) $site->blog_id;
    $label = $site->domain . $site->path;
    $list[$id] = $label;
  }
  return $list;
}

/**
 * Propagate all schedule settings to linked sites.
 * This creates a group where all linked sites have the same schedule settings.
 * Changes on ANY site propagate to all others (DA ME updates Mr Joe, and vice versa).
 * When auto-reset expires dates on one site, all sites sync that reset immediately.
 */
function ARD_wc_propagate_schedule_to_linked_sites() {
  global $ARD_WC_PROPAGATING;
  if ( $ARD_WC_PROPAGATING ) { return; }
  if ( ! is_multisite() ) { return; }

  $linked = (array) get_option( 'wc_schedule_linked_sites', [] );
  if ( empty( $linked ) ) { return; }

  $vals = [
    'wc_schedule_enabled'  => (int) get_option( 'wc_schedule_enabled', 0 ),
    'wc_closed_start_date' => (string) get_option( 'wc_closed_start_date', '' ),
    'wc_closed_end_date'   => (string) get_option( 'wc_closed_end_date', '' ),
    'wc_closed_start_time' => (string) get_option( 'wc_closed_start_time', '' ),
    'wc_closed_end_time'   => (string) get_option( 'wc_closed_end_time', '' ),
    'wc_closed_message'    => (string) get_option( 'wc_closed_message', '' ),
  ];

  $origin = get_current_blog_id();
  $ARD_WC_PROPAGATING = true;
  foreach ( $linked as $blog_id ) {
    $blog_id = (int) $blog_id;
    if ( $blog_id === $origin ) { continue; }
    switch_to_blog( $blog_id );
    foreach ( $vals as $k => $v ) { update_option( $k, $v ); }
    restore_current_blog();
  }
  $ARD_WC_PROPAGATING = false;
}

/**
 * Clear cache when schedule changes to ensure banner updates immediately.
 * This works with LiteSpeed Cache, WP Cache, and other caching plugins.
 */
function ARD_wc_clear_cache_on_schedule_change() {
  // LiteSpeed Cache
  if ( function_exists('do_action') ) {
    do_action('litespeed_purge_all');
  }
  
  // WP native cache
  wp_cache_flush();
  
  // Object cache
  if ( function_exists('wp_cache_flush') ) {
    wp_cache_flush();
  }
}

// Propagate on any relevant option update (including auto-resets)
add_action( 'update_option_wc_schedule_enabled', 'ARD_wc_propagate_schedule_to_linked_sites', 10, 0 );
add_action( 'update_option_wc_closed_start_date', 'ARD_wc_propagate_schedule_to_linked_sites', 10, 0 );
add_action( 'update_option_wc_closed_end_date', 'ARD_wc_propagate_schedule_to_linked_sites', 10, 0 );
add_action( 'update_option_wc_closed_start_time', 'ARD_wc_propagate_schedule_to_linked_sites', 10, 0 );
add_action( 'update_option_wc_closed_end_time', 'ARD_wc_propagate_schedule_to_linked_sites', 10, 0 );
add_action( 'update_option_wc_closed_message', 'ARD_wc_propagate_schedule_to_linked_sites', 10, 0 );
add_action( 'update_option_wc_schedule_linked_sites', 'ARD_wc_propagate_schedule_to_linked_sites', 10, 0 );

// Clear cache after schedule changes
add_action( 'update_option_wc_schedule_enabled', 'ARD_wc_clear_cache_on_schedule_change', 11, 0 );
add_action( 'update_option_wc_closed_start_date', 'ARD_wc_clear_cache_on_schedule_change', 11, 0 );
add_action( 'update_option_wc_closed_end_date', 'ARD_wc_clear_cache_on_schedule_change', 11, 0 );
add_action( 'update_option_wc_closed_start_time', 'ARD_wc_clear_cache_on_schedule_change', 11, 0 );
add_action( 'update_option_wc_closed_end_time', 'ARD_wc_clear_cache_on_schedule_change', 11, 0 );
add_action( 'update_option_wc_closed_message', 'ARD_wc_clear_cache_on_schedule_change', 11, 0 );

// Clear cache after slides or category icons changes
add_action( 'update_option_app_slides', 'ARD_wc_clear_cache_on_schedule_change', 11, 0 );
add_action( 'add_option_app_slides', 'ARD_wc_clear_cache_on_schedule_change', 11, 0 );
add_action( 'update_option_app_category_icons', 'ARD_wc_clear_cache_on_schedule_change', 11, 0 );
add_action( 'add_option_app_category_icons', 'ARD_wc_clear_cache_on_schedule_change', 11, 0 );

// ===== Admin Toolbar Items =====
function ARD_app_is_active_cached() {
  static $cached = null;
  if ( $cached !== null ) { return $cached; }

  $fetch_url = get_option( 'fetch_url' );
  if ( empty( $fetch_url ) || ! is_string( $fetch_url ) || trim( $fetch_url ) === '' ) {
    $cached = false;
    return $cached;
  }

  $active = true; // Default to active
  $endpoint = rtrim( $fetch_url, '/' ) . '/appStatus';
  $resp = wp_remote_get( $endpoint, [ 'timeout' => 3, 'redirection' => 2, 'sslverify' => false ] );
  if ( ! is_wp_error( $resp ) && isset( $resp['response']['code'] ) && (int) $resp['response']['code'] === 200 ) {
    $body = wp_remote_retrieve_body( $resp );
    $data = json_decode( $body, true );
    if ( is_array( $data ) ) {
      $isOnline = isset( $data['isOnline'] ) ? (bool) $data['isOnline'] : true;
      if ( ! $isOnline ) {
        // App is locked ONLY if current time is within the scheduled inactivity window
        if ( ! empty( $data['inactivity']['startAt'] ) && ! empty( $data['inactivity']['endAt'] ) ) {
          $now = time() * 1000; // current time in milliseconds
          $start = (float) $data['inactivity']['startAt'];
          $end = (float) $data['inactivity']['endAt'];
          if ( $now >= $start && $now <= $end ) {
            $active = false;
          }
        } else {
          // If isOnline is false and no schedule, mark as inactive
          $active = false;
        }
      }
    }
  } else {
    $active = false; // Fallback if API fails
  }
  $cached = $active;
  return $cached;
}

function ARD_admin_bar_items() {
  global $wp_admin_bar;
  if ( ! is_admin_bar_showing() || ! is_user_logged_in() ) { return; }
  
  // Stato Woo button
  $wc_open = ARD_wc_orders_open();
  $wc_color = $wc_open ? '#2e7d32' : '#b00020';
  $wc_label = $wc_open ? '🟢 Ordini Attivi' : '🔴 Ordini Chiusi';
  $wp_admin_bar->add_node( [
    'id' => 'ard-wc-status',
    'parent' => 'top-secondary',
    'title' => '<span style="background:' . $wc_color . '; color:#fff; padding:5px 15px; border-radius:4px; display:inline-block; font-weight:600; line-height:1.2;">' . $wc_label . '</span>',
    'href' => admin_url( 'admin.php?page=wc_site_status' ),
    'meta' => [ 'class' => 'ard-admin-bar-item' ],
  ] );
  
  // Stato App button (ONLY if fetch_url is set)
  $fetch_url = get_option('fetch_url');
  if ( ! empty( $fetch_url ) ) {
      $app_url = admin_url( 'admin.php?page=app_administration_backoffice' );
      $app_active = ARD_app_is_active_cached();
      $app_color = $app_active ? '#2e7d32' : '#b00020';
      $app_label = $app_active ? '🟢 App Attiva' : '🔴 App Inattiva';
      $wp_admin_bar->add_node( [
        'id' => 'ard-app-status',
        'parent' => 'top-secondary',
        'title' => '<span style="background:' . $app_color . '; color:#fff; padding:5px 15px; border-radius:4px; display:inline-block; font-weight:600; line-height:1.2;">' . $app_label . '</span>',
        'href' => $app_url,
        'meta' => [ 'class' => 'ard-admin-bar-item' ],
      ] );
  }
}
add_action( 'admin_bar_menu', 'ARD_admin_bar_items', 999 );

// Inject notifications manager UI (hidden, will be shown when clicking "Notifiche")
function ARD_inject_notifications_manager_hidden() {
  $fetch_url = get_option('fetch_url');
  if (empty($fetch_url)) {
    return; // Skip if no Firebase URL configured
  }
  
  $fetch_url_escaped = esc_attr($fetch_url);
  $fcm_admin_key = esc_attr(get_option('fcm_admin_key', ''));
  
  $sites_list = ARD_wc_get_sites_list();
  if ( is_multisite() ) {
    $linked_sites = (array) get_option( 'wc_schedule_linked_sites', array() );
    if ( empty( $linked_sites ) ) {
      $linked_sites = array( get_current_blog_id() );
    }
    $linked_sites_ints = array_map( 'intval', $linked_sites );
    $filtered_sites = array();
    foreach ( $sites_list as $sid => $label ) {
      if ( in_array( (int) $sid, $linked_sites_ints, true ) ) {
        $filtered_sites[$sid] = $label;
      }
    }
    $sites_list = $filtered_sites;
  }
  
  $current_blog_id = get_current_blog_id();
  
  $rest_urls = array();
  if ( is_multisite() ) {
    foreach ( $sites_list as $sid => $label ) {
      $rest_urls[ $sid ] = array(
        'cats' => esc_url_raw( get_rest_url( $sid, 'wc/v3/products/categories' ) ),
        'products' => esc_url_raw( get_rest_url( $sid, 'wc/v3/products' ) ),
      );
    }
  }

  $site_domains = array();
  if ( is_multisite() ) {
    foreach ( $sites_list as $sid => $label ) {
      $site_domains[ $sid ] = str_replace( array( 'http://', 'https://', '/' ), '', get_home_url( $sid ) );
    }
  }
  ?>
  <style>
    #ard-notifications-manager {
      display: block;
      position: relative;
      background: #fff;
      border: 1px solid #ddd;
      border-radius: 8px;
      padding: 20px;
      margin: 20px 0 40px 0;
      max-width: 100%;
      width: 100%;
      box-shadow: 0 2px 6px rgba(0,0,0,0.08);
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      z-index: auto;
    }
    #ard-notifications-manager.ard-visible { display: block; }
    #ard-notifications-manager > * { max-width: 100%; margin: 0; }
    #ard-notifications-manager h2 {
      margin: 0 0 20px 0;
      font-size: 24px;
      color: #333;
      border-bottom: 2px solid #2196F3;
      padding-bottom: 10px;
    }
    .ard-notif-form-grid {
      display: grid;
      grid-template-columns: 1fr;
      gap: 20px;
      margin-bottom: 20px;
    }
    .ard-notif-form-field {
      display: flex;
      flex-direction: column;
    }
    .ard-notif-form-field label {
      font-weight: 600;
      margin-bottom: 8px;
      color: #555;
      font-size: 13px;
    }
    .ard-notif-form-field input,
    .ard-notif-form-field textarea,
    .ard-notif-form-field select {
      padding: 10px;
      border: 1px solid #ddd;
      border-radius: 4px;
      font-size: 14px;
      font-family: inherit;
    }
    .ard-notif-form-field textarea {
      min-height: 100px;
      resize: vertical;
    }
    .ard-notif-button {
      padding: 12px 24px;
      border: none;
      border-radius: 4px;
      font-size: 14px;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.2s;
      margin-right: 10px;
    }
    .ard-notif-button-primary {
      background: #2196F3;
      color: white;
    }
    .ard-notif-button-primary:hover {
      background: #1976D2;
    }
    .ard-notif-message {
      padding: 12px;
      border-radius: 4px;
      margin-top: 15px;
      font-size: 14px;
    }
    .ard-notif-message-success {
      background: #4caf50;
      color: white;
    }
    .ard-notif-message-error {
      background: #f44336;
      color: white;
    }
    .ard-notif-info {
      background: #e3f2fd;
      border-left: 4px solid #2196F3;
      padding: 12px;
      margin-bottom: 15px;
      font-size: 14px;
    }
    /* Autocomplete for app deep links */
    .ard-link-autocomplete {
      position: relative;
    }
    .ard-link-autocomplete input {
      width: 100%;
    }
    .ard-link-dropdown {
      position: absolute;
      top: 100%;
      left: 0;
      right: 0;
      background: #fff;
      border: 1px solid #ddd;
      border-top: none;
      border-radius: 0 0 6px 6px;
      max-height: 220px;
      overflow-y: auto;
      z-index: 1000;
      box-shadow: 0 4px 12px rgba(0,0,0,0.15);
      display: none;
    }
    .ard-link-dropdown.active { display: block; }
    .ard-link-option {
      padding: 10px 14px;
      cursor: pointer;
      font-size: 13px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      transition: background 0.15s;
      gap: 12px;
    }
    .ard-link-option:hover, .ard-link-option.selected {
      background: #e3f2fd;
    }
    .ard-link-option .ard-link-label { font-weight: 500; white-space: nowrap; }
    .ard-link-option .ard-link-value { color: #999; font-size: 11px; text-align: right; word-break: break-all; max-width: 180px; }
    .ard-link-clear {
      position: absolute;
      right: 8px;
      top: 50%;
      transform: translateY(-50%);
      background: none;
      border: none;
      cursor: pointer;
      font-size: 16px;
      color: #999;
      padding: 2px 6px;
      border-radius: 50%;
      line-height: 1;
    }
    .ard-link-clear:hover { background: #f0f0f0; color: #333; }
  </style>

  <div class="wrap"><div id="ard-notifications-manager">
    <h2>📢 Invia Notifiche Push</h2>
    
    <div class="ard-notif-info">
      <strong>ℹ️ Come funziona:</strong><br>
      Invia una notifica push a tutti gli utenti della app mobile. La notifica aparirà sul loro dispositivo con il titolo e il messaggio specificati.
    </div>

    <div class="ard-notif-form-grid">
      <div class="ard-notif-form-field">
        <label>👤 Destinatari</label>
        <select id="ard-notif-recipients">
          <option value="all">Tutti gli utenti</option>
          <option value="android">Solo Android</option>
          <option value="ios">Solo iOS</option>
        </select>
      </div>
    </div>

    <div class="ard-notif-form-grid">
      <div class="ard-notif-form-field">
        <label>📝 Titolo Notifica</label>
        <input type="text" id="ard-notif-title" placeholder="Es: Nuova Offerta!" maxlength="60" />
      </div>
      <div class="ard-notif-form-field">
        <label>📝 Messaggio</label>
        <textarea id="ard-notif-message" placeholder="Es: Scopri le nostre nuove promozioni di fine anno!"></textarea>
      </div>
      <div class="ard-notif-form-field">
        <label>🔗 Link (opzionale)</label>
        
        <?php if ( is_multisite() ) : ?>
        <div style="margin-bottom:8px;">
          <select id="ard-notif-site-id" style="width:100%; padding:6px; border:1px solid #ddd; border-radius:6px; font-size:13px; height:32px;">
            <option value="0">🌍 Tutte le filiali (Generico)</option>
            <?php foreach ( $sites_list as $sid => $label ) : ?>
              <option value="<?php echo (int)$sid; ?>">
                📍 <?php echo esc_html( $label ); ?>
              </option>
            <?php endforeach; ?>
          </select>
        </div>
        <?php else : ?>
        <input type="hidden" id="ard-notif-site-id" value="0" />
        <?php endif; ?>

        <div class="ard-link-autocomplete" id="ard-notif-link-wrap">
          <input type="text" id="ard-notif-link" placeholder="Digita per cercare una pagina dell'app..." autocomplete="off" />
          <button type="button" class="ard-link-clear" id="ard-notif-link-clear" style="display:none;" title="Rimuovi link">&times;</button>
          <div class="ard-link-dropdown" id="ard-notif-link-dropdown"></div>
        </div>
        <small style="color:#888; margin-top:4px; display:block;">Seleziona una pagina dell'app. Lascia vuoto per aprire la Home.</small>
      </div>
    </div>

    <div style="display: flex; align-items: center; gap: 10px;">
      <button class="ard-notif-button ard-notif-button-primary" onclick="ARD_sendNotification()">
        ✈️ Invia Notifica
      </button>
      <div id="ard-notif-loading" style="display:none; color:#2196F3; font-weight:600;">
        ⏳ Invio in corso...
      </div>
    </div>

    <div id="ard-notif-message"></div>
  </div></div>

  <script>
  (function() {
    const API_URL = '<?php echo $fetch_url_escaped; ?>';
    const FCM_ADMIN_KEY = '<?php echo $fcm_admin_key; ?>';
    const WP_NONCE = '<?php echo wp_create_nonce("wp_rest"); ?>';
    const CURRENT_BLOG_ID = <?php echo (int) $current_blog_id; ?>;
    const REST_URLS = <?php echo json_encode( $rest_urls ); ?>;
    const BRANCH_PAGES_API_URL = '<?php echo esc_url( get_rest_url( null, "mobile-admin/v1/branch-pages" ) ); ?>';
    const SITE_DOMAINS = <?php echo json_encode( $site_domains ); ?>;

    // ── App Deep Link Autocomplete ──
    const STATIC_PAGES = [
      { label: '🏠 Home', value: 'app://home' },
      { label: '🛒 Carrello', value: 'app://cart' },
      { label: '📋 Ordini', value: 'app://orders' },
      { label: '❤️ Favoriti', value: 'app://favorites' },
      { label: 'ℹ️ Chi Siamo', value: 'app://about' },
      { label: '👤 Il Mio Account', value: 'app://account' },
      { label: '📍 Indirizzi', value: 'app://addresses' },
      { label: '📄 Altre Info', value: 'app://info' },
      { label: '📜 Impressum', value: 'app://impressum' },
    ];
    
    const branchPagesCache = {
      "0": [...STATIC_PAGES]
    };

    window.ARD_getBranchPages = function(siteId, callback) {
      siteId = parseInt(siteId) || 0;
      if (branchPagesCache[siteId]) {
        callback(branchPagesCache[siteId]);
        return;
      }

      if (siteId === 0) {
        callback(STATIC_PAGES);
        return;
      }

      fetch(BRANCH_PAGES_API_URL + '?blog_id=' + siteId, {
        headers: { 'X-WP-Nonce': WP_NONCE }
      })
      .then(r => r.json())
      .then(res => {
        let categoryPages = [];
        let productPages = [];
        if (res && Array.isArray(res.categories)) {
          categoryPages = res.categories.map(c => ({
            label: '📁 Categoria: ' + c.name,
            value: 'app://category/' + c.id + '/' + encodeURIComponent(c.name),
            blog_id: siteId
          }));
        }
        if (res && Array.isArray(res.products)) {
          productPages = res.products.map(p => {
            return {
              label: '🍕 Prodotto: ' + p.name,
              value: 'app://product/' + p.cat_id + '/' + encodeURIComponent(p.cat_name) + '/' + encodeURIComponent(p.name),
              blog_id: siteId
            };
          });
        }
        const combined = [...STATIC_PAGES, ...categoryPages, ...productPages];
        branchPagesCache[siteId] = combined;
        callback(combined);
      })
      .catch(err => {
        console.error("Error loading branch pages:", err);
        callback(STATIC_PAGES);
      });
    };

    let allPages = [];
    window.ARD_getBranchPages(CURRENT_BLOG_ID, (pages) => {
      allPages = pages;
      window.ARD_allPages = pages;
    });

    /**
     * Initialize autocomplete on an input + dropdown pair.
     * @param {string} inputId - The input element ID
     * @param {string} dropdownId - The dropdown element ID
     * @param {string} clearBtnId - The clear button ID
     * @param {string|null} hiddenInputName - If set, creates/updates a hidden input with this name
     * @param {string|null} siteSelectId - If set, filters suggestions dynamically by selected site select field
     */
    window.ARD_initLinkAutocomplete = function(inputId, dropdownId, clearBtnId, hiddenInputName, siteSelectId) {
      const input = document.getElementById(inputId);
      const dropdown = document.getElementById(dropdownId);
      const clearBtn = document.getElementById(clearBtnId);
      if (!input || !dropdown) return;

      let selectedValue = '';

      function render(filter) {
        const q = (filter || '').toLowerCase();
        const siteSelect = siteSelectId ? document.getElementById(siteSelectId) : null;
        const siteId = siteSelect ? parseInt(siteSelect.value) : CURRENT_BLOG_ID;

        window.ARD_getBranchPages(siteId, (pages) => {
          const matches = q ? pages.filter(p => p.label.toLowerCase().includes(q) || p.value.toLowerCase().includes(q)) : pages;
          if (matches.length === 0) {
            dropdown.innerHTML = '<div class="ard-link-option" style="color:#999; cursor:default;">Nessun risultato</div>';
          } else {
            dropdown.innerHTML = matches.map(p =>
              '<div class="ard-link-option" data-value="' + p.value + '">' +
                '<span class="ard-link-label">' + p.label + '</span>' +
                '<span class="ard-link-value">' + decodeURIComponent(p.value.replace('app://', '')) + '</span>' +
              '</div>'
            ).join('');
          }
          dropdown.classList.add('active');
        });
      }

      input.addEventListener('focus', () => render(input.value));
      input.addEventListener('input', () => render(input.value));

      if (siteSelectId) {
        const siteSelect = document.getElementById(siteSelectId);
        if (siteSelect) {
          siteSelect.addEventListener('change', () => {
            // Clear input values when site changes to avoid cross-site link leak
            selectedValue = '';
            input.value = '';
            input.dataset.linkValue = '';
            if (clearBtn) clearBtn.style.display = 'none';
            if (hiddenInputName) {
              const hidden = input.parentElement.querySelector('input[name="' + hiddenInputName + '"]');
              if (hidden) hidden.value = '';
            }
          });
        }
      }

      dropdown.addEventListener('click', (e) => {
        const option = e.target.closest('.ard-link-option');
        if (!option || !option.dataset.value) return;
        selectedValue = option.dataset.value;
        input.value = option.querySelector('.ard-link-label').textContent;
        input.dataset.linkValue = selectedValue;
        dropdown.classList.remove('active');
        if (clearBtn) clearBtn.style.display = 'block';
        // Update hidden input if exists
        if (hiddenInputName) {
          let hidden = input.parentElement.querySelector('input[name="' + hiddenInputName + '"]');
          if (!hidden) {
            hidden = document.createElement('input');
            hidden.type = 'hidden';
            hidden.name = hiddenInputName;
            input.parentElement.appendChild(hidden);
          }
          hidden.value = selectedValue;
        }
      });

      if (clearBtn) {
        clearBtn.addEventListener('click', () => {
          selectedValue = '';
          input.value = '';
          input.dataset.linkValue = '';
          clearBtn.style.display = 'none';
          if (hiddenInputName) {
            const hidden = input.parentElement.querySelector('input[name="' + hiddenInputName + '"]');
            if (hidden) hidden.value = '';
          }
        });
      }

      // Close dropdown when clicking outside
      document.addEventListener('click', (e) => {
        if (!input.contains(e.target) && !dropdown.contains(e.target)) {
          dropdown.classList.remove('active');
        }
      });

      // Return getter for the selected link value
      return () => input.dataset.linkValue || selectedValue || '';
    };

    // Initialize notification link autocomplete
    const getNotifLink = ARD_initLinkAutocomplete('ard-notif-link', 'ard-notif-link-dropdown', 'ard-notif-link-clear', null, 'ard-notif-site-id');

    window.ARD_sendNotification = async function() {
      const recipients = document.getElementById('ard-notif-recipients').value;
      const title = document.getElementById('ard-notif-title').value.trim();
      const message = document.getElementById('ard-notif-message').value.trim();
      const link = getNotifLink ? getNotifLink() : '';
      const loadingDiv = document.getElementById('ard-notif-loading');
      const msgDiv = document.getElementById('ard-notif-message');

      const siteSelect = document.getElementById('ard-notif-site-id');
      const siteId = siteSelect ? siteSelect.value : '0';
      
      let branchUrl = null;
      if (typeof SITE_DOMAINS !== 'undefined') {
        if (siteId !== '0' && SITE_DOMAINS[siteId]) {
          branchUrl = SITE_DOMAINS[siteId];
        } else if (typeof CURRENT_BLOG_ID !== 'undefined' && SITE_DOMAINS[CURRENT_BLOG_ID]) {
          branchUrl = SITE_DOMAINS[CURRENT_BLOG_ID];
        }
      }

      if (!title) {
        showNotifMessage('⚠️ Inserisci un titolo per la notifica', true);
        return;
      }

      if (!message) {
        showNotifMessage('⚠️ Inserisci un messaggio', true);
        return;
      }

      try {
        loadingDiv.style.display = 'block';
        msgDiv.textContent = '';

        const payload = {
          title: title,
          message: message,
          link: link || null,
          branchUrl: branchUrl,
          recipients: recipients,
          adminKey: FCM_ADMIN_KEY
        };

        const response = await fetch(API_URL + '/fcmNotifications/sendNotification', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'x-fcm-admin-key': FCM_ADMIN_KEY
          },
          body: JSON.stringify(payload)
        });

        if (!response.ok) {
          const error = await response.json();
          throw new Error(error.error || 'Errore invio notifica');
        }

        const result = await response.json();
        
        loadingDiv.style.display = 'none';
        showNotifMessage('✅ Notifica inviata! Broadcast: ' + (result.topicBroadcast || '✅') + ' | Legacy: ' + (result.legacySentCount || 0) + ' dispositivi');
        
        // Clear form
        document.getElementById('ard-notif-title').value = '';
        document.getElementById('ard-notif-message').value = '';
        document.getElementById('ard-notif-link').value = '';
        document.getElementById('ard-notif-link').dataset.linkValue = '';
        document.getElementById('ard-notif-link-clear').style.display = 'none';
      } catch (error) {
        loadingDiv.style.display = 'none';
        showNotifMessage('❌ Errore: ' + error.message, true);
      }
    };

    function showNotifMessage(text, isError = false) {
      const msgDiv = document.getElementById('ard-notif-message');
      msgDiv.className = 'ard-notif-message ' + (isError ? 'ard-notif-message-error' : 'ard-notif-message-success');
      msgDiv.textContent = text;
      if (!isError) {
        setTimeout(() => msgDiv.textContent = '', 5000);
      }
    }

    // Initialize
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', () => {
        const panel = document.getElementById('ard-notifications-manager');
        if (panel) {
          panel.classList.add('ard-visible');
        }
      });
    } else {
      const panel = document.getElementById('ard-notifications-manager');
      if (panel) {
        panel.classList.add('ard-visible');
      }
    }
  })();
  </script>
  <?php
}

function remove_footer_admin()
{
  echo '<span id="footer-thankyou">Developed by <a href="https://ticinoweb.com/" target="_blank">TicinoWEB</a></span>';
}

add_filter('admin_footer_text', 'remove_footer_admin');

// ==============================
// REST API for Mobile App Config (v1.4.0)
// ==============================

add_action( 'rest_api_init', 'WPADR_register_rest_routes' );
function WPADR_register_rest_routes() {
	// GET /wp-json/mobile-admin/v1/config
	register_rest_route( 'mobile-admin/v1', '/config', array(
		'methods'  => 'GET',
		'callback' => 'WPADR_rest_get_config',
		'permission_callback' => '__return_true',
	) );

	// GET /wp-json/mobile-admin/v1/pos-info
	register_rest_route( 'mobile-admin/v1', '/pos-info', array(
		'methods'  => 'GET',
		'callback' => 'WPADR_rest_get_pos_info',
		'permission_callback' => '__return_true',
	) );

	// POST /wp-json/mobile-admin/v1/register-or-add
	// Handles WP Multisite: if user exists in network, adds to this subsite + updates password
	register_rest_route( 'mobile-admin/v1', '/register-or-add', array(
		'methods'  => 'POST',
		'callback' => 'WPADR_rest_register_or_add_user',
		'permission_callback' => '__return_true',
	) );

	// GET /wp-json/mobile-admin/v1/order-status
	register_rest_route( 'mobile-admin/v1', '/order-status', array(
		'methods'  => 'GET',
		'callback' => 'WPADR_rest_get_order_status',
		'permission_callback' => '__return_true',
	) );
}

/**
 * GET /wp-json/mobile-admin/v1/order-status?id=123
 * Returns the status of a WooCommerce order.
 */
function WPADR_rest_get_order_status( $request ) {
	$order_id = $request->get_param( 'id' );
	if ( empty( $order_id ) ) {
		return new WP_Error( 'missing_id', 'Missing order ID', array( 'status' => 400 ) );
	}

	if ( ! class_exists( 'WooCommerce' ) ) {
		return new WP_Error( 'wc_missing', 'WooCommerce is not active on this site', array( 'status' => 500 ) );
	}

	$order = wc_get_order( (int) $order_id );
	if ( ! $order ) {
		return new WP_Error( 'invalid_order', 'Order not found', array( 'status' => 404 ) );
	}

	return rest_ensure_response( array(
		'status' => $order->get_status()
	) );
}

/**
 * GET /wp-json/mobile-admin/v1/config
 * Returns public mobile app configuration including Stripe publishable key.
 */
function WPADR_rest_get_config( $request ) {
	$stripe_key = get_option( 'stripe_publishable_key', '' );
	$app_name   = get_bloginfo( 'name' );

	return rest_ensure_response( array(
		'stripePublishableKey' => $stripe_key,
		'appName'             => $app_name,
	) );
}

/**
 * POST /wp-json/mobile-admin/v1/register-or-add
 *
 * For WP Multisite: if a user already exists in the network but not on this
 * subsite, add them to this site, update their password, and return a JWT.
 * If the user does not exist at all, create them normally.
 *
 * Params: username, email, password, AUTH_KEY
 */
function WPADR_rest_register_or_add_user( $request ) {
	$username = sanitize_user( $request->get_param( 'username' ) );
	$email    = sanitize_email( $request->get_param( 'email' ) );
	$password = $request->get_param( 'password' );
	$auth_key = $request->get_param( 'AUTH_KEY' );

	// Validate AUTH_KEY against Simple JWT Login auth codes
	$sjl_raw      = get_option( 'simple_jwt_login_settings', '{}' );
	$sjl_settings = is_string( $sjl_raw ) ? json_decode( $sjl_raw, true ) : $sjl_raw;
	if ( ! is_array( $sjl_settings ) ) $sjl_settings = array();

	$valid_key = false;
	if ( ! empty( $sjl_settings['auth_codes'] ) ) {
		foreach ( $sjl_settings['auth_codes'] as $code_entry ) {
			if ( isset( $code_entry['code'] ) && $code_entry['code'] === $auth_key ) {
				$valid_key = true;
				break;
			}
		}
	}
	if ( ! $valid_key ) {
		return new WP_Error( 'invalid_auth_key', 'AUTH_KEY non valida.', array( 'status' => 403 ) );
	}

	if ( empty( $username ) || empty( $email ) || empty( $password ) ) {
		return new WP_Error( 'missing_fields', 'Username, email e password sono obbligatori.', array( 'status' => 400 ) );
	}

	$current_blog_id = get_current_blog_id();

	// Check if user exists by username or email
	$user = get_user_by( 'login', $username );
	if ( ! $user ) {
		$user = get_user_by( 'email', $email );
	}

	if ( $user ) {
		// User exists in the network — add to this subsite if not already a member
		if ( ! is_user_member_of_blog( $user->ID, $current_blog_id ) ) {
			$role = ! empty( $sjl_settings['new_user_profile'] ) ? $sjl_settings['new_user_profile'] : 'customer';
			add_user_to_blog( $current_blog_id, $user->ID, $role );
		}

		// Update password to the one they provided
		wp_set_password( $password, $user->ID );

		// Clear cached user object after password change
		$user = get_user_by( 'id', $user->ID );
	} else {
		// User does not exist at all — create them
		$user_id = wp_create_user( $username, $password, $email );
		if ( is_wp_error( $user_id ) ) {
			return $user_id;
		}
		$role = ! empty( $sjl_settings['new_user_profile'] ) ? $sjl_settings['new_user_profile'] : 'customer';
		$user = get_user_by( 'id', $user_id );
		$user->set_role( $role );
	}

	// Generate JWT using Simple JWT Login's decryption key
	$decryption_key = isset( $sjl_settings['decryption_key'] ) ? $sjl_settings['decryption_key'] : '';
	if ( empty( $decryption_key ) ) {
		return new WP_Error( 'jwt_config_error', 'JWT decryption key non configurata.', array( 'status' => 500 ) );
	}

	$issued_at = time();
	$ttl       = isset( $sjl_settings['jwt_auth_ttl'] ) ? intval( $sjl_settings['jwt_auth_ttl'] ) : 60;
	$iss       = isset( $sjl_settings['jwt_auth_iss'] ) ? stripslashes( $sjl_settings['jwt_auth_iss'] ) : get_site_url();

	$payload = array(
		'iat'      => $issued_at,
		'exp'      => $issued_at + ( $ttl * 60 ),
		'email'    => $user->user_email,
		'id'       => $user->ID,
		'username' => $user->user_login,
		'iss'      => $iss,
	);

	$jwt = WPADR_jwt_encode( $payload, $decryption_key );

	return rest_ensure_response( array(
		'success' => true,
		'id'      => $user->ID,
		'message' => 'Utente registrato/aggiunto con successo.',
		'user'    => array(
			'ID'         => (string) $user->ID,
			'user_login' => $user->user_login,
			'user_email' => $user->user_email,
		),
		'jwt'     => $jwt,
	) );
}

/**
 * Simple HS256 JWT encoder (avoids external library dependency).
 */
function WPADR_jwt_encode( $payload, $secret ) {
	$header = array( 'typ' => 'JWT', 'alg' => 'HS256' );

	$segments = array(
		WPADR_base64url_encode( json_encode( $header, JSON_UNESCAPED_SLASHES ) ),
		WPADR_base64url_encode( json_encode( $payload, JSON_UNESCAPED_SLASHES ) ),
	);

	$signing_input = implode( '.', $segments );
	$signature     = hash_hmac( 'sha256', $signing_input, $secret, true );
	$segments[]    = WPADR_base64url_encode( $signature );

	return implode( '.', $segments );
}

function WPADR_base64url_encode( $data ) {
	return rtrim( strtr( base64_encode( $data ), '+/', '-_' ), '=' );
}

// ================================================================
// SLIDES MANAGEMENT
// ================================================================

function ARD_register_slides_settings() {
  register_setting( 'ard-slides-group', 'app_slides', array(
    'type' => 'array',
    'default' => array(),
    'sanitize_callback' => 'ARD_sanitize_slides',
  ) );
}

function ARD_sanitize_slides( $input ) {
  if ( ! is_array( $input ) ) return array();
  $slides = array_slice( $input, 0, 5 ); // Max 5 slides
  $result = array();
  foreach ( $slides as $slide ) {
    // Support legacy format (plain URL string) and new format (object with url+title+link)
    if ( is_string( $slide ) ) {
      $url = $slide;
      $title = '';
      $link = '';
    } elseif ( is_array( $slide ) ) {
      $url = isset( $slide['url'] ) ? $slide['url'] : '';
      $title = isset( $slide['title'] ) ? sanitize_text_field( $slide['title'] ) : '';
      $link = isset( $slide['link'] ) ? sanitize_text_field( $slide['link'] ) : '';
      $site_id = isset( $slide['site_id'] ) ? (int) $slide['site_id'] : 0;
    } else {
      continue;
    }
    if ( filter_var( $url, FILTER_VALIDATE_URL ) ) {
      $result[] = array( 'url' => $url, 'title' => $title, 'link' => $link, 'site_id' => $site_id );
    }
  }
  return array_values( $result );
}

add_action( 'save_post_product', 'ARD_clear_search_targets_transient' );
add_action( 'edited_product_cat', 'ARD_clear_search_targets_transient' );
function ARD_clear_search_targets_transient() {
  delete_site_transient( 'ard_all_search_targets_v5' );
}

// Filter WooCommerce REST API product response to serve optimized thumbnails instead of original full-size images
add_filter( 'woocommerce_rest_prepare_product_object', 'ARD_optimize_rest_product_images', 10, 3 );
function ARD_optimize_rest_product_images( $response, $object, $request ) {
  $data = $response->get_data();
  if ( ! empty( $data['images'] ) && is_array( $data['images'] ) ) {
    foreach ( $data['images'] as $key => $image ) {
      if ( ! empty( $image['id'] ) ) {
        $attachment_id = (int) $image['id'];
        // Use 'medium' (typically 300x300px) which is extremely light (often < 30KB) and resolves immediately
        $thumbnail_url = wp_get_attachment_image_url( $attachment_id, 'medium' );
        if ( $thumbnail_url ) {
          $data['images'][$key]['src'] = $thumbnail_url;
        }
      }
    }
    $response->set_data( $data );
  }
  return $response;
}

// Filter WooCommerce REST API product variation response to serve optimized thumbnails instead of original full-size images
add_filter( 'woocommerce_rest_prepare_product_variation_object', 'ARD_optimize_rest_variation_images', 10, 3 );
function ARD_optimize_rest_variation_images( $response, $object, $request ) {
  $data = $response->get_data();
  if ( ! empty( $data['image'] ) && is_array( $data['image'] ) ) {
    if ( ! empty( $data['image']['id'] ) ) {
      $attachment_id = (int) $data['image']['id'];
      $thumbnail_url = wp_get_attachment_image_url( $attachment_id, 'medium' );
      if ( $thumbnail_url ) {
        $data['image']['src'] = $thumbnail_url;
      }
    }
    $response->set_data( $data );
  }
  return $response;
}


function ARD_get_all_search_targets() {
  $cache = get_site_transient( 'ard_all_search_targets_v5' );
  if ( ! empty( $cache ) && is_array( $cache ) ) {
    return $cache;
  }

  global $wpdb;
  $targets = [];
  
  if ( is_multisite() ) {
    $linked_sites = (array) get_option( 'wc_schedule_linked_sites', [] );
    if ( empty( $linked_sites ) ) {
      $linked_sites = [ get_current_blog_id() ];
    }
    $linked_sites_ints = array_map( 'intval', $linked_sites );

    $sites = get_sites([ 'number' => 0 ]);
    foreach ( $sites as $site ) {
      $blog_id = (int) $site->blog_id;
      if ( ! in_array( $blog_id, $linked_sites_ints, true ) ) {
        continue;
      }
      switch_to_blog( $blog_id );
      
      $site_name = str_replace( [ 'bellinzona.', 'giubiasco.', 'sorengo.', 'dame-' ], '', $site->domain );
      $site_name = ucfirst( explode( '.', $site_name )[0] );
      
      // 1. Query Categories via SQL directly (with correct blog prefix)
      $categories = $wpdb->get_results( "
        SELECT t.term_id, t.name 
        FROM {$wpdb->prefix}terms t 
        INNER JOIN {$wpdb->prefix}term_taxonomy tt ON t.term_id = tt.term_id 
        WHERE tt.taxonomy = 'product_cat'
      " );
      if ( ! empty( $categories ) && ! is_wp_error( $categories ) ) {
        foreach ( $categories as $cat ) {
          $targets[] = [
            'label' => '🍕 [' . $site_name . '] ' . $cat->name,
            'value' => 'app://category/' . $cat->term_id . '/' . rawurlencode( $cat->name ),
            'blog_id' => $blog_id,
          ];
        }
      }
      
      // 2. Query Products via SQL directly (with correct blog prefix)
      $products = $wpdb->get_results( "
        SELECT p.ID, p.post_title, 
               (SELECT tr.term_taxonomy_id 
                FROM {$wpdb->prefix}term_relationships tr 
                INNER JOIN {$wpdb->prefix}term_taxonomy tt ON tr.term_taxonomy_id = tt.term_taxonomy_id 
                WHERE tr.object_id = p.ID AND tt.taxonomy = 'product_cat' 
                LIMIT 1) as cat_id
        FROM {$wpdb->prefix}posts p
        WHERE p.post_type = 'product' AND p.post_status = 'publish'
      " );
      if ( ! empty( $products ) && ! is_wp_error( $products ) ) {
        foreach ( $products as $prod ) {
          $cat_id = $prod->cat_id ? (int) $prod->cat_id : 0;
          $targets[] = [
            'label' => '🍔 [' . $site_name . '] ' . $prod->post_title,
            'value' => 'app://product/' . $cat_id . '/' . rawurlencode( $prod->post_title ),
            'blog_id' => $blog_id,
          ];
        }
      }
      
      restore_current_blog();
    }
  } else {
    $categories = $wpdb->get_results( "
      SELECT t.term_id, t.name 
      FROM {$wpdb->prefix}terms t 
      INNER JOIN {$wpdb->prefix}term_taxonomy tt ON t.term_id = tt.term_id 
      WHERE tt.taxonomy = 'product_cat'
    " );
    if ( ! empty( $categories ) && ! is_wp_error( $categories ) ) {
      foreach ( $categories as $cat ) {
        $targets[] = [
          'label' => '🍕 ' . $cat->name,
          'value' => 'app://category/' . $cat->term_id . '/' . rawurlencode( $cat->name ),
          'blog_id' => get_current_blog_id(),
        ];
      }
    }
    
    $products = $wpdb->get_results( "
      SELECT p.ID, p.post_title, 
             (SELECT tr.term_taxonomy_id 
              FROM {$wpdb->prefix}term_relationships tr 
              INNER JOIN {$wpdb->prefix}term_taxonomy tt ON tr.term_taxonomy_id = tt.term_taxonomy_id 
              WHERE tr.object_id = p.ID AND tt.taxonomy = 'product_cat' 
              LIMIT 1) as cat_id
      FROM {$wpdb->prefix}posts p
      WHERE p.post_type = 'product' AND p.post_status = 'publish'
    " );
    if ( ! empty( $products ) && ! is_wp_error( $products ) ) {
      foreach ( $products as $prod ) {
        $cat_id = $prod->cat_id ? (int) $prod->cat_id : 0;
        $targets[] = [
          'label' => '🍔 ' . $prod->post_title,
          'value' => 'app://product/' . $cat_id . '/' . rawurlencode( $prod->post_title ),
          'blog_id' => get_current_blog_id(),
        ];
      }
    }
  }

  set_site_transient( 'ard_all_search_targets_v5', $targets, 12 * HOUR_IN_SECONDS );
  return $targets;
}

function ARD_showContent_slides() {
  // Handle form submission
  if ( isset( $_POST['ard_slides_nonce'] ) && wp_verify_nonce( $_POST['ard_slides_nonce'], 'ard_save_slides' ) ) {
    $urls = isset( $_POST['app_slide_urls'] ) ? (array) $_POST['app_slide_urls'] : array();
    $titles = isset( $_POST['app_slide_titles'] ) ? stripslashes_deep( (array) $_POST['app_slide_titles'] ) : array();
    $links = isset( $_POST['app_slide_links'] ) ? stripslashes_deep( (array) $_POST['app_slide_links'] ) : array();
    $site_ids = isset( $_POST['app_slide_site_ids'] ) ? (array) $_POST['app_slide_site_ids'] : array();
    $raw = array();
    foreach ( $urls as $i => $url ) {
      $raw[] = array(
        'url'   => $url,
        'title' => isset( $titles[ $i ] ) ? $titles[ $i ] : '',
        'link'  => isset( $links[ $i ] ) ? sanitize_text_field( $links[ $i ] ) : '',
        'site_id' => isset( $site_ids[ $i ] ) ? (int) $site_ids[ $i ] : 0,
      );
    }
    $slides = ARD_sanitize_slides( $raw );
    update_option( 'app_slides', $slides );
    ARD_sync_slides_to_firestore();
    echo '<div class="notice notice-success"><p>Slides salvate e sincronizzate!</p></div>';
  }

  $slides = get_option( 'app_slides', array() );
  // Migrate legacy format (plain URL strings) to new format
  foreach ( $slides as &$slide ) {
    if ( is_string( $slide ) ) {
      $slide = array( 'url' => $slide, 'title' => '', 'link' => '', 'site_id' => 0 );
    }
    if ( ! isset( $slide['link'] ) ) {
      $slide['link'] = '';
    }
    if ( ! isset( $slide['site_id'] ) ) {
      $slide['site_id'] = 0;
    }
  }
  unset( $slide );
  $sites_list = ARD_wc_get_sites_list();
  if ( is_multisite() ) {
    $linked_sites = (array) get_option( 'wc_schedule_linked_sites', array() );
    if ( empty( $linked_sites ) ) {
      $linked_sites = array( get_current_blog_id() );
    }
    $linked_sites_ints = array_map( 'intval', $linked_sites );
    $filtered_sites = array();
    foreach ( $sites_list as $sid => $label ) {
      if ( in_array( (int) $sid, $linked_sites_ints, true ) ) {
        $filtered_sites[$sid] = $label;
      }
    }
    $sites_list = $filtered_sites;
  }
  ?>
  <div class="wrap">
    <h1>Slides Home Page App</h1>
    <p class="description">
      Gestisci le immagini dello slider nella home page dell'app mobile. Massimo <strong>5 slides</strong>.<br/>
      💡 Puoi inserire link personalizzati digitandoli direttamente nel campo (es. <code>app://category/ID</code> per una categoria, o <code>app://product/ID/NomeProdotto</code> per evidenziare un prodotto specifico).
    </p>

    <style>
      .ard-slides-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 20px; margin: 20px 0; }
      .ard-slide-card { position: relative; background: #fff; border: 2px solid #ddd; border-radius: 12px; transition: all 0.2s; }
      .ard-slide-card:hover { border-color: #2e7d32; box-shadow: 0 4px 12px rgba(0,0,0,0.1); }
      .ard-slide-card img { width: 100%; height: 180px; object-fit: cover; display: block; border-top-left-radius: 10px; border-top-right-radius: 10px; }
      .ard-slide-card .ard-slide-fields { padding: 10px; background: #fff; }
      .ard-slide-card .ard-slide-fields input[type="text"] { width: 100%; padding: 6px 10px; border: 1px solid #ddd; border-radius: 6px; font-size: 13px; }
      .ard-slide-card .ard-slide-actions { padding: 10px; display: flex; justify-content: space-between; align-items: center; background: #f9f9f9; border-bottom-left-radius: 10px; border-bottom-right-radius: 10px; }
      .ard-slide-remove { background: #f44336; color: #fff; border: none; padding: 6px 14px; border-radius: 6px; cursor: pointer; font-size: 13px; }
      .ard-slide-remove:hover { background: #d32f2f; }
      .ard-slide-order { font-weight: 600; color: #666; font-size: 14px; }
      .ard-add-slide { display: flex; align-items: center; justify-content: center; min-height: 260px; border: 2px dashed #ccc; border-radius: 12px; cursor: pointer; transition: all 0.2s; background: #fafafa; }
      .ard-add-slide:hover { border-color: #2e7d32; background: #f0f8f0; }
      .ard-add-slide span { font-size: 48px; color: #999; }
      .ard-submit-bar { margin-top: 20px; padding: 15px; background: #f5f5f5; border-radius: 8px; display: flex; gap: 10px; align-items: center; }

      .ard-link-autocomplete { position: relative; width: 100%; }
      .ard-link-dropdown {
        position: absolute;
        top: 100%;
        left: 0;
        right: 0;
        background: #fff;
        border: 1px solid #ddd;
        border-top: none;
        border-radius: 0 0 6px 6px;
        max-height: 200px;
        overflow-y: auto;
        z-index: 1000;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        display: none;
      }
      .ard-link-dropdown.active { display: block; }
      .ard-link-option {
        padding: 8px 12px;
        cursor: pointer;
        font-size: 13px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        transition: background 0.15s;
        gap: 12px;
      }
      .ard-link-option:hover { background: #e3f2fd; }
      .ard-link-option .ard-link-label { font-weight: 500; white-space: nowrap; }
      .ard-link-option .ard-link-value { color: #999; font-size: 11px; text-align: right; word-break: break-all; max-width: 140px; display: block; }
      .ard-link-clear {
        position: absolute;
        right: 8px;
        top: 50%;
        transform: translateY(-50%);
        background: none;
        border: none;
        cursor: pointer;
        font-size: 16px;
        color: #999;
        padding: 2px 6px;
        border-radius: 50%;
        line-height: 1;
      }
      .ard-link-clear:hover { background: #f0f0f0; color: #333; }
    </style>

    <form method="post" id="ard-slides-form">
      <?php wp_nonce_field( 'ard_save_slides', 'ard_slides_nonce' ); ?>

      <div class="ard-slides-grid" id="ard-slides-container">
        <?php foreach ( $slides as $i => $slide ) :
          $url = is_array( $slide ) ? $slide['url'] : $slide;
          $title = is_array( $slide ) && isset( $slide['title'] ) ? $slide['title'] : '';
          $link = is_array( $slide ) && isset( $slide['link'] ) ? $slide['link'] : '';
          $site_id = is_array( $slide ) && isset( $slide['site_id'] ) ? (int) $slide['site_id'] : 0;
          // Map link to display label
          $link_display = '';
          if ( $link ) {
            $link_labels = array(
              'app://home' => '🏠 Home',
              'app://cart' => '🛒 Carrello',
              'app://orders' => '📋 Ordini',
              'app://favorites' => '❤️ Favoriti',
              'app://about' => 'ℹ️ Chi Siamo',
              'app://account' => '👤 Il Mio Account',
              'app://addresses' => '📍 Indirizzi',
              'app://info' => '📄 Altre Info',
              'app://impressum' => '📜 Impressum',
            );
            if ( isset( $link_labels[ $link ] ) ) {
              $link_display = $link_labels[ $link ];
            } elseif ( preg_match( '#^app://category/\d+/(.+)$#', $link, $m ) ) {
              $link_display = '🍕 ' . urldecode( $m[1] );
            } elseif ( preg_match( '#^app://product/\d+/(.+)$#', $link, $m ) ) {
              $link_display = '🍔 ' . urldecode( $m[1] );
            } else {
              $link_display = $link;
            }
          }
        ?>
        <div class="ard-slide-card" data-index="<?php echo $i; ?>">
          <img src="<?php echo esc_url( $url ); ?>" alt="Slide <?php echo $i + 1; ?>" />
          <input type="hidden" name="app_slide_urls[]" value="<?php echo esc_url( $url ); ?>" />
          <div class="ard-slide-fields">
            <input type="text" name="app_slide_titles[]" value="<?php echo esc_attr( $title ); ?>" placeholder="Titolo slide (opzionale)" />
            
            <?php if ( is_multisite() ) : ?>
            <div style="margin-top:6px;">
              <select name="app_slide_site_ids[]" style="width:100%; padding:6px; border:1px solid #ddd; border-radius:6px; font-size:13px; height:32px;">
                <option value="0">🌍 Tutte le filiali (Generico)</option>
                <?php foreach ( $sites_list as $sid => $label ) : ?>
                  <option value="<?php echo (int)$sid; ?>" <?php selected( $site_id, (int)$sid ); ?>>
                    📍 <?php echo esc_html( $label ); ?>
                  </option>
                <?php endforeach; ?>
              </select>
            </div>
            <?php else : ?>
            <input type="hidden" name="app_slide_site_ids[]" value="0" />
            <?php endif; ?>

            <div class="ard-link-autocomplete" style="margin-top:6px;">
              <input type="text" class="ard-slide-link-input" value="<?php echo esc_attr( $link_display ); ?>" placeholder="🔗 Link pagina app (opzionale)" autocomplete="off" data-link-value="<?php echo esc_attr( $link ); ?>" />
              <input type="hidden" name="app_slide_links[]" value="<?php echo esc_attr( $link ); ?>" />
              <?php if ( $link ) : ?>
              <button type="button" class="ard-link-clear" onclick="ARD_clearSlideLink(this)" title="Rimuovi link">&times;</button>
              <?php else : ?>
              <button type="button" class="ard-link-clear" style="display:none;" onclick="ARD_clearSlideLink(this)" title="Rimuovi link">&times;</button>
              <?php endif; ?>
              <div class="ard-link-dropdown"></div>
            </div>
          </div>
          <div class="ard-slide-actions">
            <span class="ard-slide-order">Slide #<?php echo $i + 1; ?></span>
            <button type="button" class="ard-slide-remove" onclick="this.closest('.ard-slide-card').remove(); ARD_updateSlideNumbers();">Rimuovi</button>
          </div>
        </div>
        <?php endforeach; ?>
        
        <?php if ( count( $slides ) < 5 ) : ?>
        <div class="ard-add-slide" id="ard-add-slide-btn" onclick="ARD_addSlide()">
          <span>＋</span>
        </div>
        <?php endif; ?>
      </div>

      <div class="ard-submit-bar">
        <button type="submit" class="button button-primary button-large">💾 Salva Slides</button>
        <span class="description">Le slides verranno sincronizzate automaticamente con l'app.</span>
      </div>
    </form>
  </div>

  <script>
  // Autocomplete suggestions (including categories & products from all subsites)
  var allPages = [
    { label: '🏠 Home', value: 'app://home' },
    { label: '🍕 Lista Categorie Prodotti', value: 'app://products' },
    { label: '🛒 Carrello', value: 'app://cart' },
    { label: '📋 Ordini', value: 'app://orders' },
    { label: '❤️ Favoriti', value: 'app://favorites' },
    { label: 'ℹ️ Chi Siamo', value: 'app://about' },
    { label: '👤 Il Mio Account', value: 'app://account' },
    { label: '📍 Indirizzi', value: 'app://addresses' },
    { label: '📄 Altre Info', value: 'app://info' },
    { label: '📜 Impressum', value: 'app://impressum' },
  ];
  
  var dbTargets = <?php echo wp_json_encode( ARD_get_all_search_targets() ); ?> || [];
  allPages = allPages.concat(dbTargets);

  function ARD_addSlide() {
    var container = document.getElementById('ard-slides-container');
    var cards = container.querySelectorAll('.ard-slide-card');
    if (cards.length >= 5) { alert('Massimo 5 slides!'); return; }

    var frame = wp.media({
      title: 'Seleziona immagine per la slide',
      multiple: false,
      library: { type: 'image' },
      button: { text: 'Usa questa immagine' }
    });

    frame.on('select', function() {
      var attachment = frame.state().get('selection').first().toJSON();
      var url = attachment.url;
      var idx = cards.length + 1;
      
      var siteDropdownHtml = '';
      <?php if ( is_multisite() ) : ?>
      siteDropdownHtml = 
        '<div style="margin-top:6px;">' +
          '<select name="app_slide_site_ids[]" style="width:100%; padding:6px; border:1px solid #ddd; border-radius:6px; font-size:13px; height:32px;">' +
            '<option value="0">\ud83c\udf0d Tutte le filiali (Generico)</option>' +
            <?php foreach ( $sites_list as $sid => $label ) : ?>
            '<option value="<?php echo (int)$sid; ?>">\ud83d\udccd <?php echo esc_js( esc_html( $label ) ); ?></option>' +
            <?php endforeach; ?>
          '</select>' +
        '</div>';
      <?php else : ?>
      siteDropdownHtml = '<input type="hidden" name="app_slide_site_ids[]" value="0" />';
      <?php endif; ?>

      var card = document.createElement('div');
      card.className = 'ard-slide-card';
      card.innerHTML =
        '<img src="' + url + '" alt="Slide ' + idx + '" />' +
        '<input type="hidden" name="app_slide_urls[]" value="' + url + '" />' +
        '<div class="ard-slide-fields">' +
          '<input type="text" name="app_slide_titles[]" value="" placeholder="Titolo slide (opzionale)" />' +
          siteDropdownHtml +
          '<div class="ard-link-autocomplete" style="margin-top:6px;">' +
            '<input type="text" class="ard-slide-link-input" value="" placeholder="\ud83d\udd17 Link pagina app (opzionale)" autocomplete="off" data-link-value="" />' +
            '<input type="hidden" name="app_slide_links[]" value="" />' +
            '<button type="button" class="ard-link-clear" style="display:none;" onclick="ARD_clearSlideLink(this)" title="Rimuovi link">&times;</button>' +
            '<div class="ard-link-dropdown"></div>' +
          '</div>' +
        '</div>' +
        '<div class="ard-slide-actions">' +
          '<span class="ard-slide-order">Slide #' + idx + '</span>' +
          '<button type="button" class="ard-slide-remove" onclick="this.closest(\'.ard-slide-card\').remove(); ARD_updateSlideNumbers();">Rimuovi</button>' +
        '</div>';
      
      var addBtn = document.getElementById('ard-add-slide-btn');
      container.insertBefore(card, addBtn);
      
      // Hide add button if 5 slides
      if (container.querySelectorAll('.ard-slide-card').length >= 5) {
        addBtn.style.display = 'none';
      }
      ARD_updateSlideNumbers();
    });

    frame.open();
  }

  function ARD_updateSlideNumbers() {
    var cards = document.querySelectorAll('.ard-slide-card');
    cards.forEach(function(card, i) {
      card.querySelector('.ard-slide-order').textContent = 'Slide #' + (i + 1);
    });
    var addBtn = document.getElementById('ard-add-slide-btn');
    if (addBtn) {
      addBtn.style.display = cards.length >= 5 ? 'none' : 'flex';
    }
  }

  // ── Slide link autocomplete (uses ARD_initLinkAutocomplete from notifications page if available) ──

  function ARD_clearSlideLink(btn) {
    var wrap = btn.closest('.ard-link-autocomplete');
    var input = wrap.querySelector('.ard-slide-link-input');
    var hidden = wrap.querySelector('input[type="hidden"]');
    if (input) { input.value = ''; input.dataset.linkValue = ''; }
    if (hidden) hidden.value = '';
    btn.style.display = 'none';
  }

  // Event delegation for slide link autocomplete dropdowns
  document.addEventListener('click', function(e) {
    // Handle dropdown option click
    var option = e.target.closest('.ard-slide-card .ard-link-option');
    if (option && option.dataset.value) {
      var wrap = option.closest('.ard-link-autocomplete');
      var input = wrap.querySelector('.ard-slide-link-input');
      var hidden = wrap.querySelector('input[type="hidden"]');
      var clearBtn = wrap.querySelector('.ard-link-clear');
      var dropdown = wrap.querySelector('.ard-link-dropdown');
      if (input) {
        input.value = option.querySelector('.ard-link-label').textContent;
        input.dataset.linkValue = option.dataset.value;
      }
      if (hidden) hidden.value = option.dataset.value;
      if (clearBtn) clearBtn.style.display = 'block';
      if (dropdown) dropdown.classList.remove('active');
      return;
    }
    // Close all slide dropdowns when clicking outside
    document.querySelectorAll('.ard-slide-card .ard-link-dropdown.active').forEach(function(dd) {
      if (!dd.closest('.ard-link-autocomplete').contains(e.target)) {
        dd.classList.remove('active');
      }
    });
  });

  // Render slide dropdown options
  function ARD_renderSlideDropdown(dropdown, filter, selectedSiteId) {
    const siteId = selectedSiteId ? parseInt(selectedSiteId) : CURRENT_BLOG_ID;

    window.ARD_getBranchPages(siteId, (pages) => {
      var q = (filter || '').toLowerCase();
      var matches = q ? pages.filter(function(p) { return p.label.toLowerCase().indexOf(q) >= 0 || p.value.toLowerCase().indexOf(q) >= 0; }) : pages;
      if (matches.length === 0) {
        dropdown.innerHTML = '<div class="ard-link-option" style="color:#999; cursor:default;">Nessun risultato</div>';
      } else {
        dropdown.innerHTML = matches.map(function(p) {
          return '<div class="ard-link-option" data-value="' + p.value + '">' +
            '<span class="ard-link-label">' + p.label + '</span>' +
          '</div>';
        }).join('');
      }
      dropdown.classList.add('active');
    });
  }

  // Clear slide link on branch dropdown change to prevent wrong links
  document.addEventListener('change', function(e) {
    if (e.target && e.target.name === 'app_slide_site_ids[]') {
      var card = e.target.closest('.ard-slide-card');
      if (card) {
        var wrap = card.querySelector('.ard-link-autocomplete');
        if (wrap) {
          var input = wrap.querySelector('.ard-slide-link-input');
          var hidden = wrap.querySelector('input[type="hidden"]');
          var clearBtn = wrap.querySelector('.ard-link-clear');
          if (input) { input.value = ''; input.dataset.linkValue = ''; }
          if (hidden) hidden.value = '';
          if (clearBtn) clearBtn.style.display = 'none';
        }
      }
    }
  });

  // Event delegation for focus/input on slide link inputs
  document.addEventListener('focusin', function(e) {
    if (e.target.classList.contains('ard-slide-link-input')) {
      var wrap = e.target.closest('.ard-link-autocomplete');
      var card = e.target.closest('.ard-slide-card');
      var select = card.querySelector('select[name="app_slide_site_ids[]"]');
      var selectedSiteId = select ? parseInt(select.value) : 0;
      
      var dropdown = wrap.querySelector('.ard-link-dropdown');
      ARD_renderSlideDropdown(dropdown, e.target.value, selectedSiteId);
    }
  });
  document.addEventListener('input', function(e) {
    if (e.target.classList.contains('ard-slide-link-input')) {
      var wrap = e.target.closest('.ard-link-autocomplete');
      var card = e.target.closest('.ard-slide-card');
      var select = card.querySelector('select[name="app_slide_site_ids[]"]');
      var selectedSiteId = select ? parseInt(select.value) : 0;
      
      var dropdown = wrap.querySelector('.ard-link-dropdown');
      var hidden = wrap.querySelector('input[type="hidden"]');
      var clearBtn = wrap.querySelector('.ard-link-clear');
      
      var val = e.target.value.trim();
      if (val.startsWith('http://') || val.startsWith('https://') || val.startsWith('app://')) {
        if (hidden) hidden.value = val;
        e.target.dataset.linkValue = val;
      }
      if (clearBtn) clearBtn.style.display = val ? 'block' : 'none';
      ARD_renderSlideDropdown(dropdown, val, selectedSiteId);
    }
  });
  document.addEventListener('change', function(e) {
    if (e.target.classList.contains('ard-slide-link-input')) {
      var wrap = e.target.closest('.ard-link-autocomplete');
      var hidden = wrap.querySelector('input[type="hidden"]');
      var val = e.target.value.trim();
      if (val.startsWith('http://') || val.startsWith('https://') || val.startsWith('app://')) {
        if (hidden) hidden.value = val;
        e.target.dataset.linkValue = val;
      }
    }
  });
  </script>
  <?php
}

/**
 * Sync slides to Firestore via Cloud Functions.
 */
function ARD_sync_slides_to_firestore() {
  $fetch_url = get_option( 'fetch_url' );
  if ( empty( $fetch_url ) ) return;

  $slides = get_option( 'app_slides', array() );
  // Ensure slides are in the new {url, title, link, site_id} format for Firestore
  $formatted = array();
  foreach ( $slides as $slide ) {
    if ( is_string( $slide ) ) {
      $formatted[] = array( 'url' => $slide, 'title' => '', 'link' => '', 'site_id' => 0 );
    } elseif ( is_array( $slide ) ) {
      $formatted[] = array(
        'url'   => isset( $slide['url'] ) ? $slide['url'] : '',
        'title' => isset( $slide['title'] ) ? $slide['title'] : '',
        'link'  => isset( $slide['link'] ) ? $slide['link'] : '',
        'site_id' => isset( $slide['site_id'] ) ? (int) $slide['site_id'] : 0,
      );
    }
  }

  if ( ARD_config_api_secret() === '' ) {
    error_log( '[MobileAdmin] Slides sync skipped: ARD_CONFIG_API_SECRET not configured' );
    return;
  }

  $response = wp_remote_post( rtrim( $fetch_url, '/' ) . '/config/update', array(
    'body'    => wp_json_encode( array(
      'apiSecret' => ARD_config_api_secret(),
      'slides'    => $formatted,
    ) ),
    'headers' => array( 'Content-Type' => 'application/json' ),
    'timeout' => 15,
  ) );

  if ( is_wp_error( $response ) ) {
    error_log( '[MobileAdmin] Slides sync failed: ' . $response->get_error_message() );
  }
}


// ================================================================
// CATEGORY ICONS MANAGEMENT
// ================================================================

function ARD_register_category_icons_settings() {
  register_setting( 'ard-category-icons-group', 'app_category_icons', array(
    'type' => 'array',
    'default' => array(),
  ) );
}

/**
 * Get the URL base for bundled SVG category icons shipped with the plugin.
 */
function ARD_category_icons_url() {
  return plugin_dir_url( __FILE__ ) . 'category-icons/';
}

/**
 * Get the filesystem path for bundled SVG category icons.
 */
function ARD_category_icons_path() {
  return plugin_dir_path( __FILE__ ) . 'category-icons/';
}

/**
 * Get the path for custom uploaded category icons inside persistent WordPress uploads.
 */
function ARD_custom_category_icons_path() {
  $upload_dir = wp_upload_dir();
  return $upload_dir['basedir'] . '/category-icons/';
}

/**
 * Get the URL for custom uploaded category icons inside persistent WordPress uploads.
 */
function ARD_custom_category_icons_url() {
  $upload_dir = wp_upload_dir();
  return $upload_dir['baseurl'] . '/category-icons/';
}

/**
 * List all available SVG icon files (both bundled default ones and custom uploaded ones).
 */
function ARD_get_available_svg_icons() {
  $icons = array();

  // 1. Scan default icons bundled with the plugin: colorful/ (Fluent Emoji, MIT),
  //    then the line icons in category-icons/ and category-icons/food-icons/
  $default_dir = ARD_category_icons_path();
  $default_url = ARD_category_icons_url();
  if ( is_dir( $default_dir ) ) {
    foreach ( glob( $default_dir . 'colorful/*.svg' ) as $file ) {
      $basename = basename( $file, '.svg' );
      $icons[ $basename ] = array(
        'file'  => basename( $file ),
        'url'   => $default_url . 'colorful/' . basename( $file ),
        'group' => 'color',
      );
    }
    foreach ( glob( $default_dir . '*.svg' ) as $file ) {
      $basename = basename( $file, '.svg' );
      if ( isset( $icons[ $basename ] ) ) continue;
      $icons[ $basename ] = array(
        'file'  => basename( $file ),
        'url'   => $default_url . basename( $file ),
        'group' => 'line',
      );
    }
    if ( is_dir( $default_dir . 'food-icons/' ) ) {
      foreach ( glob( $default_dir . 'food-icons/*.svg' ) as $file ) {
        $basename = sanitize_title( basename( $file, '.svg' ) );
        if ( ! isset( $icons[ $basename ] ) ) {
          $icons[ $basename ] = array(
            'file'  => basename( $file ),
            'url'   => $default_url . 'food-icons/' . rawurlencode( basename( $file ) ),
            'group' => 'line',
          );
        }
      }
    }
  }

  // 2. Scan custom uploaded icons in wp-content/uploads/category-icons/
  $custom_dir = ARD_custom_category_icons_path();
  $custom_url = ARD_custom_category_icons_url();
  if ( is_dir( $custom_dir ) ) {
    foreach ( glob( $custom_dir . '*.svg' ) as $file ) {
      $basename = basename( $file, '.svg' );
      $icons[ $basename ] = array(
        'file'  => basename( $file ),
        'url'   => $custom_url . basename( $file ),
        'group' => 'custom',
      );
    }
  }

  // Grouped (custom, color, line), alphabetical within each group
  $rank = array( 'custom' => 0, 'color' => 1, 'line' => 2 );
  uksort( $icons, function( $a, $b ) use ( $icons, $rank ) {
    $ga = $rank[ $icons[ $a ]['group'] ];
    $gb = $rank[ $icons[ $b ]['group'] ];
    return $ga !== $gb ? $ga - $gb : strcmp( $a, $b );
  } );
  return $icons;
}

/**
 * Labels of the icon groups returned by ARD_get_available_svg_icons().
 */
function ARD_svg_icon_group_labels() {
  return array(
    'custom' => '📤 Caricate da te',
    'color'  => '🎨 A colori',
    'line'   => '✏️ A linea',
  );
}

/**
 * Detect the default/primary language code for a site (blog_id).
 */
function ARD_get_site_default_language( $blog_id ) {
  switch_to_blog( (int) $blog_id );
  $default_lang = '';

  // 1. WPML settings option
  $sitepress_settings = get_option( 'icl_sitepress_settings' );
  if ( is_array( $sitepress_settings ) && ! empty( $sitepress_settings['default_language'] ) ) {
    $default_lang = $sitepress_settings['default_language'];
  }

  // 2. WPML filter
  if ( empty( $default_lang ) && function_exists( 'apply_filters' ) ) {
    $wpml_default = apply_filters( 'wpml_default_language', null );
    if ( ! empty( $wpml_default ) && is_string( $wpml_default ) ) {
      $default_lang = $wpml_default;
    }
  }

  // 3. Polylang
  if ( empty( $default_lang ) && function_exists( 'pll_default_language' ) ) {
    $pll_lang = pll_default_language( 'slug' );
    if ( ! empty( $pll_lang ) ) {
      $default_lang = $pll_lang;
    }
  }

  // 4. WordPress locale (e.g. 'it_IT' -> 'it')
  if ( empty( $default_lang ) ) {
    $locale = get_locale();
    if ( ! empty( $locale ) ) {
      $parts = explode( '_', $locale );
      $default_lang = strtolower( $parts[0] );
    }
  }

  restore_current_blog();
  return $default_lang ? strtolower( trim( $default_lang ) ) : 'it';
}

/**
 * Get map of category translations for a site.
 * Returns array where each category name maps to an array of its translated names in other languages.
 * E.g.: [ 'Pizze Classiche Normali' => [ 'Classic Normal Pizzas', 'Klassische Normale Pizzen' ], ... ]
 */
function ARD_get_category_translations( $blog_id ) {
  global $wpdb;
  switch_to_blog( (int) $blog_id );
  
  $prefix = $wpdb->prefix;
  $wpml_table = $prefix . 'icl_translations';
  $trans_map = array();

  // 1. WPML
  if ( $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $wpml_table ) ) === $wpml_table ) {
    $rows = $wpdb->get_results(
      "SELECT icl.trid, t.name, icl.language_code
       FROM {$wpml_table} AS icl
       INNER JOIN {$prefix}term_taxonomy AS tt ON (icl.element_id = tt.term_taxonomy_id OR icl.element_id = tt.term_id)
       INNER JOIN {$prefix}terms AS t ON tt.term_id = t.term_id
       WHERE icl.element_type = 'tax_product_cat'
         AND tt.taxonomy = 'product_cat'"
    );

    if ( ! empty( $rows ) ) {
      $trid_groups = array();
      foreach ( $rows as $r ) {
        if ( ! empty( $r->trid ) && ! empty( $r->name ) ) {
          $trid_groups[ $r->trid ][] = $r->name;
        }
      }

      foreach ( $trid_groups as $trid => $names ) {
        $unique_names = array_values( array_unique( $names ) );
        if ( count( $unique_names ) > 1 ) {
          foreach ( $unique_names as $name ) {
            $others = array_values( array_diff( $unique_names, array( $name ) ) );
            $trans_map[ $name ] = $others;
          }
        }
      }
    }
  }

  // 2. Polylang (if WPML was empty and Polylang is available)
  if ( empty( $trans_map ) && function_exists( 'pll_get_term_translations' ) ) {
    $terms = get_terms( array( 'taxonomy' => 'product_cat', 'hide_empty' => false ) );
    if ( ! empty( $terms ) && ! is_wp_error( $terms ) ) {
      foreach ( $terms as $term ) {
        $translations = pll_get_term_translations( $term->term_id );
        if ( is_array( $translations ) && count( $translations ) > 1 ) {
          $trans_names = array();
          foreach ( $translations as $lang => $trans_id ) {
            if ( $trans_id !== $term->term_id ) {
              $t = get_term( $trans_id, 'product_cat' );
              if ( $t && ! is_wp_error( $t ) ) {
                $trans_names[] = $t->name;
              }
            }
          }
          if ( ! empty( $trans_names ) ) {
            $trans_map[ $term->name ] = $trans_names;
          }
        }
      }
    }
  }

  restore_current_blog();
  return $trans_map;
}

/**
 * Automatically propagate category icons to their translated names across languages.
 * If category "Pizze Classiche" has icon X, any translated counterparts
 * ("Classic Pizzas", "Klassische Pizzen") automatically receive the exact same icon
 * without requiring the user to configure each translation manually.
 */
function ARD_propagate_icons_to_translations( $icons ) {
  if ( ! is_array( $icons ) ) return $icons;

  foreach ( $icons as $blog_id => $site_icons ) {
    $blog_id = intval( $blog_id );
    if ( ! is_array( $site_icons ) || empty( $site_icons ) ) continue;

    $trans_map = ARD_get_category_translations( $blog_id );
    if ( empty( $trans_map ) ) continue;

    foreach ( $site_icons as $cat_name => $data ) {
      if ( empty( $data ) || ! is_array( $data ) ) continue;
      if ( empty( $data['value'] ) ) continue;

      if ( isset( $trans_map[ $cat_name ] ) ) {
        foreach ( $trans_map[ $cat_name ] as $translated_name ) {
          // If the translated category has no icon set yet, or has an auto-propagated icon:
          if ( ! isset( $site_icons[ $translated_name ] ) || empty( $site_icons[ $translated_name ]['value'] ) || ! empty( $site_icons[ $translated_name ]['auto_i18n'] ) ) {
            $site_icons[ $translated_name ] = array(
              'type'       => isset( $data['type'] ) ? $data['type'] : 'emoji',
              'value'      => $data['value'],
              'equivalent' => isset( $data['equivalent'] ) ? $data['equivalent'] : '',
              // Same position as the source category: the app shows one
              // language at a time, so the sequence stays identical.
              'order'      => isset( $data['order'] ) ? (int) $data['order'] : 999,
              'auto_i18n'  => true,
            );
          }
        }
      }
    }

    $icons[ $blog_id ] = $site_icons;
  }

  return $icons;
}

/**
 * Fetch WooCommerce product categories for a specific site (blog_id).
 * Automatically filters to only return categories in the site's default/primary language
 * so multilingual sites (WPML/Polylang) don't load duplicate categories for every language.
 * Uses direct DB query because switch_to_blog() doesn't re-register
 * WooCommerce taxonomies, so get_terms('product_cat') fails.
 * Returns an array of objects with properties: term_id, name, slug.
 */
function ARD_get_categories_for_site( $blog_id ) {
  global $wpdb;
  switch_to_blog( (int) $blog_id );
  
  $prefix = $wpdb->prefix; // This updates after switch_to_blog()
  $default_lang = ARD_get_site_default_language( $blog_id );
  $wpml_table = $prefix . 'icl_translations';
  $has_wpml = ( $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $wpml_table ) ) === $wpml_table );

  $results = array();

  if ( $has_wpml ) {
    // In WPML: query categories in the site's default language
    if ( $default_lang ) {
      $results = $wpdb->get_results(
        $wpdb->prepare(
          "SELECT t.term_id, t.name, t.slug, tt.count
           FROM {$prefix}terms AS t
           INNER JOIN {$prefix}term_taxonomy AS tt ON t.term_id = tt.term_id
           INNER JOIN {$wpml_table} AS icl ON (icl.element_id = tt.term_taxonomy_id OR icl.element_id = t.term_id)
           WHERE tt.taxonomy = 'product_cat'
             AND icl.element_type = 'tax_product_cat'
             AND t.slug != 'uncategorized'
             AND tt.count > 0
             AND icl.language_code = %s
           GROUP BY t.term_id
           ORDER BY t.name ASC",
          $default_lang
        )
      );
    }
    
    // Fallback if empty: original/base language terms (source_language_code is null/empty)
    if ( empty( $results ) ) {
      $results = $wpdb->get_results(
        "SELECT t.term_id, t.name, t.slug, tt.count
         FROM {$prefix}terms AS t
         INNER JOIN {$prefix}term_taxonomy AS tt ON t.term_id = tt.term_id
         INNER JOIN {$wpml_table} AS icl ON (icl.element_id = tt.term_taxonomy_id OR icl.element_id = t.term_id)
         WHERE tt.taxonomy = 'product_cat'
           AND icl.element_type = 'tax_product_cat'
           AND t.slug != 'uncategorized'
           AND tt.count > 0
           AND (icl.source_language_code IS NULL OR icl.source_language_code = '')
         GROUP BY t.term_id
         ORDER BY t.name ASC"
      );
    }
  } else {
    // Check Polylang
    $has_pll = taxonomy_exists( 'language' );
    if ( $has_pll && $default_lang ) {
      $results = $wpdb->get_results(
        $wpdb->prepare(
          "SELECT t.term_id, t.name, t.slug, tt.count
           FROM {$prefix}terms AS t
           INNER JOIN {$prefix}term_taxonomy AS tt ON t.term_id = tt.term_id
           INNER JOIN {$prefix}term_relationships AS tr ON tr.object_id = tt.term_taxonomy_id
           INNER JOIN {$prefix}term_taxonomy AS tt_lang ON tr.term_taxonomy_id = tt_lang.term_taxonomy_id
           INNER JOIN {$prefix}terms AS t_lang ON tt_lang.term_id = t_lang.term_id
           WHERE tt.taxonomy = 'product_cat'
             AND tt_lang.taxonomy = 'language'
             AND (t_lang.slug = %s OR t_lang.name = %s)
             AND t.slug != 'uncategorized'
             AND tt.count > 0
           GROUP BY t.term_id
           ORDER BY t.name ASC",
          $default_lang,
          $default_lang
        )
      );
    }
  }

  // Safety fallback: if language filtering yielded empty results, return all categories
  if ( empty( $results ) ) {
    $results = $wpdb->get_results(
      "SELECT t.term_id, t.name, t.slug, tt.count
       FROM {$prefix}terms AS t
       INNER JOIN {$prefix}term_taxonomy AS tt ON t.term_id = tt.term_id
       WHERE tt.taxonomy = 'product_cat'
         AND t.slug != 'uncategorized'
         AND tt.count > 0
       ORDER BY t.name ASC"
    );
  }
  
  restore_current_blog();
  return is_array( $results ) ? $results : array();
}

/**
 * Get linked sites from the option (same logic used elsewhere in the plugin).
 */
function ARD_get_linked_sites_for_icons() {
  // The option is stored on the current blog (the admin hub, e.g. blog 8 for mrjoecity.ch)
  $linked = (array) get_option( 'wc_schedule_linked_sites', array() );
  if ( empty( $linked ) ) {
    $linked = array( get_current_blog_id() );
  }
  $linked = array_values( array_map( 'intval', $linked ) );

  // Explicitly exclude the main management hub (blog 8) if multisite is active
  if ( is_multisite() ) {
    $linked = array_filter( $linked, function( $id ) {
      return intval( $id ) !== 8;
    } );
  }
  $linked = array_values( $linked );

  // Filter: only keep sites that have WooCommerce product categories with products
  $filtered = array();
  foreach ( $linked as $bid ) {
    $cats = ARD_get_categories_for_site( $bid );
    if ( ! empty( $cats ) ) {
      $filtered[] = $bid;
    }
  }
  return $filtered;
}

/**
 * Migrate old flat icon format to new per-site structure.
 * Old: { "Category Name": "🍕" }
 * New: { blog_id: { "Category Name": { "type": "emoji", "value": "🍕" } } }
 */
/**
 * Give an explicit 'order' index to entries saved before ordering was stored.
 * The WordPress option keeps the drag&drop order as array key order, so that
 * order is what gets frozen into the numeric index.
 */
function ARD_backfill_icons_order( $icons ) {
  foreach ( $icons as $blog_id => $site_icons ) {
    if ( ! is_array( $site_icons ) ) continue;
    $position = 0;
    foreach ( $site_icons as $name => $data ) {
      if ( is_array( $data ) && ! isset( $data['order'] ) ) {
        $site_icons[ $name ]['order'] = $position;
      }
      $position++;
    }
    $icons[ $blog_id ] = $site_icons;
  }
  return $icons;
}

function ARD_maybe_migrate_category_icons( $icons ) {
  if ( empty( $icons ) || ! is_array( $icons ) ) return $icons;
  // Check if already in new format (keys are numeric blog IDs)
  $first_key = array_key_first( $icons );
  if ( is_numeric( $first_key ) && is_array( reset( $icons ) ) ) {
    // Check deeper: is it already { type, value } or still flat?
    $first_inner = reset( $icons );
    if ( ! empty( $first_inner ) ) {
      $inner_val = reset( $first_inner );
      if ( is_array( $inner_val ) && isset( $inner_val['type'] ) ) {
        return ARD_backfill_icons_order( $icons ); // Already in new format
      }
    }
  }
  // Old flat format detected — migrate all to current blog
  $migrated = array();
  $current_blog = get_current_blog_id();
  $linked = ARD_get_linked_sites_for_icons();
  $target_blog = in_array( $current_blog, $linked ) ? $current_blog : ( ! empty( $linked ) ? $linked[0] : $current_blog );
  
  foreach ( $icons as $name => $value ) {
    if ( is_string( $value ) ) {
      $migrated[ $target_blog ][ $name ] = array( 'type' => 'emoji', 'value' => $value );
    }
  }
  return $migrated;
}

/**
 * Sort a site's icon entries by their saved 'order' index (drag&drop order).
 * Entries without an order keep their relative position at the end.
 */
function ARD_sort_icons_by_order( $site_icons ) {
  if ( ! is_array( $site_icons ) || empty( $site_icons ) ) return $site_icons;
  $i = 0;
  $indexed = array();
  foreach ( $site_icons as $name => $data ) {
    $indexed[] = array(
      'name'     => $name,
      'data'     => $data,
      'order'    => isset( $data['order'] ) ? (int) $data['order'] : PHP_INT_MAX,
      'fallback' => $i++,
    );
  }
  usort( $indexed, function( $a, $b ) {
    if ( $a['order'] !== $b['order'] ) return $a['order'] - $b['order'];
    return $a['fallback'] - $b['fallback'];
  } );
  $sorted = array();
  foreach ( $indexed as $row ) {
    $sorted[ $row['name'] ] = $row['data'];
  }
  return $sorted;
}

/**
 * Display the Category Icons admin page with per-site tabs and SVG support.
 */
function ARD_showContent_category_icons() {
  // Handle SVG deletion
  if ( isset( $_GET['action'] ) && $_GET['action'] === 'delete_svg' && isset( $_GET['svg'] ) && isset( $_GET['_wpnonce'] ) ) {
    $svg_slug = sanitize_text_field( wp_unslash( $_GET['svg'] ) );
    if ( wp_verify_nonce( sanitize_text_field( wp_unslash( $_GET['_wpnonce'] ) ), 'ard_delete_svg_' . $svg_slug ) ) {
      $svg_name = sanitize_file_name( $svg_slug ) . '.svg';
      $custom_path = ARD_custom_category_icons_path() . $svg_name;

      // Only uploaded icons can be deleted: bundled ones are plugin files and
      // would be restored by the next update.
      $deleted = false;
      if ( current_user_can( 'manage_options' ) && file_exists( $custom_path ) ) {
        unlink( $custom_path );
        $deleted = true;
      }
      
      if ( $deleted ) {
        wp_safe_redirect( remove_query_arg( array( 'action', 'svg', '_wpnonce' ) ) );
        exit;
      }
    }
  }

  // Handle form submission
  if ( isset( $_POST['ard_icons_nonce'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['ard_icons_nonce'] ) ), 'ard_save_icons' ) ) {
    $icons = array();
    if ( isset( $_POST['ard_site_icons'] ) && is_array( $_POST['ard_site_icons'] ) ) {
      foreach ( $_POST['ard_site_icons'] as $blog_id => $site_icons ) {
        $blog_id = intval( $blog_id );
        if ( ! is_array( $site_icons ) ) continue;
        // Row order in the POST array is the drag&drop order: persist it as an
        // explicit numeric index, because Firestore maps don't keep key order.
        $position = 0;
        foreach ( $site_icons as $entry ) {
          $name  = isset( $entry['name'] )  ? sanitize_text_field( $entry['name'] )  : '';
          $type  = isset( $entry['type'] )  ? sanitize_text_field( $entry['type'] )  : 'emoji';
          $value = isset( $entry['value'] ) ? sanitize_text_field( $entry['value'] ) : '';
          $equivalent = isset( $entry['equivalent'] ) ? sanitize_text_field( $entry['equivalent'] ) : '';
          if ( $name && $value ) {
            $icons[ $blog_id ][ $name ] = array(
              'type' => $type,
              'value' => $value,
              'equivalent' => $equivalent,
              'order' => $position
            );
            $position++;
          }
        }
      }
    }
    $icons = ARD_propagate_icons_to_translations( $icons );
    update_option( 'app_category_icons', $icons );
    ARD_sync_category_icons_to_firestore();
    echo '<div class="notice notice-success"><p>✅ Icone categorie salvate e sincronizzate (con propagazione automatica alle altre lingue)!</p></div>';
  }

  // Handle SVG upload via AJAX-style inline upload
  if ( isset( $_POST['ard_upload_svg_nonce'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['ard_upload_svg_nonce'] ) ), 'ard_upload_svg' ) ) {
    if ( ! empty( $_FILES['ard_svg_file']['name'] ) ) {
      $upload_dir = ARD_custom_category_icons_path();
      if ( ! is_dir( $upload_dir ) ) {
        wp_mkdir_p( $upload_dir );
      }
      $filename = sanitize_file_name( $_FILES['ard_svg_file']['name'] );
      if ( strtolower( pathinfo( $filename, PATHINFO_EXTENSION ) ) === 'svg' ) {
        $target = $upload_dir . $filename;
        if ( move_uploaded_file( $_FILES['ard_svg_file']['tmp_name'], $target ) ) {
          echo '<div class="notice notice-success"><p>✅ SVG caricato: ' . esc_html( $filename ) . '</p></div>';
        } else {
          echo '<div class="notice notice-error"><p>❌ Errore nel caricamento del file SVG.</p></div>';
        }
      } else {
        echo '<div class="notice notice-error"><p>❌ Solo file .svg sono accettati.</p></div>';
      }
    }
  }

  $icons    = get_option( 'app_category_icons', array() );
  $icons    = ARD_maybe_migrate_category_icons( $icons );
  $linked   = ARD_get_linked_sites_for_icons();
  $svg_list = ARD_get_available_svg_icons();
  ?>
  <div class="wrap">
    <h1>🎨 Icone Categorie App</h1>
    <p class="description">Configura le icone (emoji o SVG) per ogni categoria di prodotti nell'app mobile. Le categorie vengono caricate dinamicamente da WooCommerce per ogni sito collegato.</p>

    <style>
      .ard-icons-wrap { max-width: 900px; margin: 20px 0; }
      .ard-site-tabs { display: flex; gap: 0; border-bottom: 2px solid #0073aa; margin-bottom: 0; }
      .ard-site-tab { padding: 10px 20px; background: #f1f1f1; border: 1px solid #ccc; border-bottom: none; border-radius: 6px 6px 0 0; cursor: pointer; font-weight: 600; font-size: 13px; color: #555; transition: all .2s; }
      .ard-site-tab:hover { background: #e0e0e0; }
      .ard-site-tab.active { background: #fff; color: #0073aa; border-color: #0073aa; border-bottom: 2px solid #fff; margin-bottom: -2px; }
      .ard-site-panel { display: none; background: #fff; border: 1px solid #0073aa; border-top: none; padding: 20px; border-radius: 0 0 8px 8px; }
      .ard-site-panel.active { display: block; }
      .ard-icons-table { width: 100%; border-collapse: collapse; }
      .ard-icons-table th { background: #f8f9fa; font-weight: 600; font-size: 12px; color: #666; text-transform: uppercase; letter-spacing: 0.5px; padding: 10px 12px; text-align: left; border-bottom: 2px solid #eee; }
      .ard-icons-table td { padding: 10px 12px; border-bottom: 1px solid #f0f0f0; vertical-align: middle; }
      .ard-icons-table tr:hover { background: #f9fbfd; }
      .ard-icon-preview { display: inline-flex; align-items: center; justify-content: center; width: 40px; height: 40px; border-radius: 8px; background: #f5f5f5; }
      .ard-icon-preview img { width: 28px; height: 28px; }
      .ard-icon-preview .emoji-preview { font-size: 24px; line-height: 1; }
      .ard-name-input { padding: 6px 10px; border: 1px solid #ddd; border-radius: 4px; font-size: 13px; width: 200px; }
      .ard-type-select { padding: 6px 8px; border: 1px solid #ddd; border-radius: 4px; font-size: 13px; }
      .ard-value-input { padding: 6px 10px; border: 1px solid #ddd; border-radius: 4px; font-size: 13px; width: 120px; }
      .ard-svg-select { padding: 6px 8px; border: 1px solid #ddd; border-radius: 4px; font-size: 13px; max-width: 200px; }
      .ard-remove-row { background: #dc3545; color: #fff; border: none; padding: 4px 10px; border-radius: 4px; cursor: pointer; font-size: 11px; }
      .ard-remove-row:hover { background: #c82333; }
      .ard-drag-handle { cursor: grab; font-size: 18px; color: #aaa; user-select: none; text-align: center; padding: 0 4px; }
      .ard-drag-handle:hover { color: #666; }
      .ard-drag-handle:active { cursor: grabbing; }
      tr.ard-dragging { opacity: 0.4; background: #e8f0fe; }
      tr.ard-drag-over { border-top: 2px solid #0073aa; }
      .ard-btn-group { display: flex; gap: 8px; margin: 12px 0; }
      .ard-btn { padding: 8px 16px; border: none; border-radius: 6px; cursor: pointer; font-size: 13px; font-weight: 500; }
      .ard-btn-green { background: #28a745; color: #fff; }
      .ard-btn-green:hover { background: #218838; }
      .ard-btn-blue { background: #0073aa; color: #fff; }
      .ard-btn-blue:hover { background: #005a87; }
      .ard-upload-box { margin: 20px 0; padding: 16px; background: #f8f9fa; border: 1px dashed #ccc; border-radius: 8px; }
      .ard-upload-box h3 { margin-top: 0; font-size: 14px; }
      .ard-submit-bar { margin-top: 20px; padding: 15px; background: #f5f5f5; border-radius: 8px; display: flex; gap: 12px; align-items: center; }
    </style>

    <!-- SVG Upload Box -->
    <div class="ard-upload-box">
      <h3>📁 Carica nuova icona SVG</h3>
      <form method="post" enctype="multipart/form-data" style="display:flex; gap:10px; align-items:center;">
        <?php wp_nonce_field( 'ard_upload_svg', 'ard_upload_svg_nonce' ); ?>
        <input type="file" name="ard_svg_file" accept=".svg" />
        <button type="submit" class="ard-btn ard-btn-blue">⬆ Carica SVG</button>
      </form>
      <?php if ( ! empty( $svg_list ) ) : ?>
      <?php
        $group_labels = ARD_svg_icon_group_labels();
        $current_group = null;
      ?>
      <div style="margin-top:10px; font-size:12px; color:#666;">
        <strong>SVG disponibili:</strong>
        <?php foreach ( $svg_list as $slug => $info ) :
          if ( $info['group'] !== $current_group ) :
            if ( $current_group !== null ) echo '</div>';
            $current_group = $info['group'];
        ?>
          <div style="margin:10px 0 4px; font-weight:600; color:#333;"><?php echo esc_html( $group_labels[ $current_group ] ); ?></div>
          <div style="display:flex; flex-wrap:wrap; gap:6px;">
        <?php endif; ?>
          <span style="display:inline-flex; align-items:center; gap:6px; padding:4px 8px; background:#fff; border-radius:6px; border:1px solid #eee;">
            <img src="<?php echo esc_url( $info['url'] ); ?>" width="24" height="24" style="vertical-align:middle;" alt="" loading="lazy" />
            <?php echo esc_html( $slug ); ?>
            <?php if ( $info['group'] === 'custom' ) :
              $delete_url = wp_nonce_url( add_query_arg( array( 'action' => 'delete_svg', 'svg' => $slug ) ), 'ard_delete_svg_' . $slug );
            ?>
            <a href="<?php echo esc_url( $delete_url ); ?>" style="color:#dc3545; text-decoration:none; margin-left:2px; font-weight:bold; font-size:14px; line-height:1;" title="Elimina SVG" onclick="return confirm('Sei sicuro di voler eliminare questa icona SVG?');">×</a>
            <?php endif; ?>
          </span>
        <?php endforeach; ?>
        <?php if ( $current_group !== null ) echo '</div>'; ?>
      </div>
      <?php endif; ?>
    </div>

    <form method="post">
      <?php wp_nonce_field( 'ard_save_icons', 'ard_icons_nonce' ); ?>

      <div class="ard-icons-wrap">
        <!-- Site Tabs -->
        <div class="ard-site-tabs">
          <?php foreach ( $linked as $idx => $blog_id ) :
            switch_to_blog( $blog_id );
            $site_name = get_bloginfo( 'name' );
            restore_current_blog();
          ?>
            <div class="ard-site-tab <?php echo $idx === 0 ? 'active' : ''; ?>" onclick="ARD_switchTab(<?php echo (int) $blog_id; ?>)" data-site="<?php echo (int) $blog_id; ?>">
              <?php echo esc_html( $site_name ); ?>
            </div>
          <?php endforeach; ?>
        </div>

        <!-- Site Panels -->
        <?php foreach ( $linked as $idx => $blog_id ) :
          $blog_id    = intval( $blog_id );
          $site_icons = isset( $icons[ $blog_id ] ) ? $icons[ $blog_id ] : array();
          $site_icons = ARD_sort_icons_by_order( $site_icons );
          $wc_cats    = ARD_get_categories_for_site( $blog_id );
          switch_to_blog( $blog_id );
          $site_name  = get_bloginfo( 'name' );
          restore_current_blog();
        ?>
          <div class="ard-site-panel <?php echo $idx === 0 ? 'active' : ''; ?>" data-site="<?php echo $blog_id; ?>" id="ard-panel-<?php echo $blog_id; ?>">
            <table class="ard-icons-table">
              <thead>
                <tr>
                  <th style="width:30px;"></th>
                  <th style="width:60px;">Anteprima</th>
                  <th>Nome Categoria</th>
                  <th style="width:80px; text-align:center;">Prodotti</th>
                  <th style="width:140px;">Sito</th>
                  <th style="width:200px;">Equivalente</th>
                  <th style="width:100px;">Tipo</th>
                  <th>Valore / Icona</th>
                  <th style="width:50px;"></th>
                </tr>
              </thead>
              <tbody id="ard-tbody-<?php echo $blog_id; ?>">
                <?php
                // Only show saved/assigned icons — user controls what appears via 'Aggiungi categoria'
                if ( ! empty( $site_icons ) ) :
                $default_cat_names = array_map( function( $c ) { return $c->name; }, $wc_cats );
                $trans_map = ARD_get_category_translations( $blog_id );
                $cat_counts = array();
                foreach ( $wc_cats as $c ) {
                  $cat_counts[ $c->name ] = (int) $c->count;
                }

                foreach ( $site_icons as $cat_name => $saved ) :
                  // Skip auto-propagated translated rows so they don't clutter the admin UI
                  if ( ! empty( $saved['auto_i18n'] ) ) {
                    continue;
                  }
                  // Skip translated row if its default-language source already exists in site_icons
                  if ( ! empty( $trans_map[ $cat_name ] ) && ! in_array( $cat_name, $default_cat_names, true ) ) {
                    $has_default_sister = false;
                    foreach ( $trans_map[ $cat_name ] as $sister ) {
                      if ( in_array( $sister, $default_cat_names, true ) && isset( $site_icons[ $sister ] ) ) {
                        $has_default_sister = true;
                        break;
                      }
                    }
                    if ( $has_default_sister ) {
                      continue;
                    }
                  }
                  $prod_count = isset( $cat_counts[ $cat_name ] ) ? $cat_counts[ $cat_name ] : 0;
                  if ( $prod_count === 0 && ! empty( $trans_map[ $cat_name ] ) ) {
                    foreach ( $trans_map[ $cat_name ] as $sister ) {
                      if ( isset( $cat_counts[ $sister ] ) && $cat_counts[ $sister ] > 0 ) {
                        $prod_count = $cat_counts[ $sister ];
                        break;
                      }
                    }
                  }
                  $type  = isset( $saved['type'] )  ? $saved['type']  : 'emoji';
                  $value = isset( $saved['value'] ) ? $saved['value'] : '';
                  $eq    = isset( $saved['equivalent'] ) ? $saved['equivalent'] : '';
                ?>
                <tr draggable="true" ondragstart="ARD_dragStart(event)" ondragend="ARD_dragEnd(event)" ondragover="ARD_dragOver(event)" ondragleave="ARD_dragLeave(event)" ondrop="ARD_drop(event)">
                  <td class="ard-drag-handle" title="Trascina per riordinare">⠿</td>
                  <td>
                    <span class="ard-icon-preview">
                      <?php if ( ! empty( $eq ) ) : ?>
                        <span class="emoji-preview">🔗</span>
                      <?php elseif ( $type === 'svg' && $value ) : ?>
                        <img src="<?php echo esc_url( $value ); ?>" width="28" height="28" />
                      <?php elseif ( $value ) : ?>
                        <span class="emoji-preview"><?php echo esc_html( $value ); ?></span>
                      <?php else : ?>
                        <span class="emoji-preview">❓</span>
                      <?php endif; ?>
                    </span>
                  </td>
                  <td>
                    <input type="hidden" name="ard_site_icons[<?php echo $blog_id; ?>][<?php echo esc_attr( $cat_name ); ?>][name]" value="<?php echo esc_attr( $cat_name ); ?>" />
                    <strong><?php echo esc_html( $cat_name ); ?></strong>
                  </td>
                  <td style="text-align:center;">
                    <span style="display:inline-block; min-width:24px; padding:2px 8px; background:#eef2f7; color:#334e68; border:1px solid #d0dbe5; border-radius:12px; font-weight:600; font-size:12px;" title="<?php echo esc_attr( $prod_count ); ?> prodotti in questa categoria">
                      <?php echo esc_html( $prod_count ); ?>
                    </span>
                  </td>
                  <td>
                    <span style="display:inline-block; padding:3px 8px; background:#e8f0fe; border-radius:4px; font-size:11px; color:#1a73e8; font-weight:500;"><?php echo esc_html( $site_name ); ?></span>
                  </td>
                  <td>
                    <select class="ard-eq-select" name="ard_site_icons[<?php echo $blog_id; ?>][<?php echo esc_attr( $cat_name ); ?>][equivalent]" onchange="ARD_toggleEquivalent(this)" style="width:100%; max-width:180px;">
                      <option value="">— Nessuna —</option>
                      <?php
                      foreach ( $linked as $other_bid ) {
                        if ( $other_bid === $blog_id ) continue;
                        switch_to_blog( $other_bid );
                        $other_site_name = get_bloginfo( 'name' );
                        restore_current_blog();
                        $other_cats = ARD_get_categories_for_site( $other_bid );
                        foreach ( $other_cats as $other_cat ) {
                          $opt_val = $other_bid . '|' . $other_cat->name;
                          echo '<option value="' . esc_attr( $opt_val ) . '" ' . selected( $eq, $opt_val, false ) . '>';
                          echo '[' . esc_html( $other_site_name ) . '] ' . esc_html( $other_cat->name );
                          echo '</option>';
                        }
                      }
                      ?>
                    </select>
                  </td>
                  <td>
                    <select class="ard-type-select" name="ard_site_icons[<?php echo $blog_id; ?>][<?php echo esc_attr( $cat_name ); ?>][type]" onchange="ARD_toggleValueInput(this)" style="<?php echo ! empty( $eq ) ? 'display:none;' : ''; ?>">
                      <option value="emoji" <?php selected( $type, 'emoji' ); ?>>🔤 Emoji</option>
                      <option value="svg" <?php selected( $type, 'svg' ); ?>>📁 SVG</option>
                    </select>
                  </td>
                  <td>
                    <span class="ard-emoji-field" style="<?php echo ($type === 'svg' || ! empty( $eq )) ? 'display:none;' : ''; ?>">
                      <input type="text" class="ard-value-input" name="ard_site_icons[<?php echo $blog_id; ?>][<?php echo esc_attr( $cat_name ); ?>][emoji_value]" value="<?php echo $type === 'emoji' ? esc_attr( $value ) : ''; ?>" placeholder="🍕" style="width:60px; text-align:center; font-size:20px;" />
                    </span>
                    <span class="ard-svg-field" style="<?php echo ($type === 'emoji' || ! empty( $eq )) ? 'display:none;' : ''; ?>">
                      <select class="ard-svg-select" name="ard_site_icons[<?php echo $blog_id; ?>][<?php echo esc_attr( $cat_name ); ?>][svg_value]">
                        <option value="">— Seleziona SVG —</option>
                        <?php
                          $opt_group = null;
                          $opt_labels = ARD_svg_icon_group_labels();
                          foreach ( $svg_list as $slug => $info ) :
                            if ( $info['group'] !== $opt_group ) :
                              if ( $opt_group !== null ) echo '</optgroup>';
                              $opt_group = $info['group'];
                              echo '<optgroup label="' . esc_attr( $opt_labels[ $opt_group ] ) . '">';
                            endif;
                        ?>
                          <option value="<?php echo esc_attr( $info['url'] ); ?>" <?php selected( $type === 'svg' ? $value : '', $info['url'] ); ?>><?php echo esc_html( $slug ); ?></option>
                        <?php endforeach; if ( $opt_group !== null ) echo '</optgroup>'; ?>
                      </select>
                    </span>
                    <span class="ard-eq-placeholder" style="<?php echo ! empty( $eq ) ? '' : 'display:none;'; ?> color:#999; font-style:italic;">— (Usa equivalente)</span>
                    <input type="hidden" class="ard-final-value" name="ard_site_icons[<?php echo $blog_id; ?>][<?php echo esc_attr( $cat_name ); ?>][value]" value="<?php echo esc_attr( $value ); ?>" />
                  </td>
                  <td>
                    <button type="button" class="ard-remove-row" onclick="this.closest('tr').remove();">✕</button>
                  </td>
                </tr>
                <?php endforeach;
                endif;
                if ( empty( $site_icons ) ) : ?>
                <tr>
                  <td colspan="9" style="text-align:center; padding:20px; color:#999; font-style:italic;">
                    Nessuna icona assegnata. Usa "＋ Aggiungi categoria" per iniziare.
                  </td>
                </tr>
                <?php endif; ?>
              </tbody>
            </table>

            <div class="ard-btn-group">
              <button type="button" class="ard-btn ard-btn-green" onclick="ARD_addIconRow(<?php echo $blog_id; ?>)">＋ Aggiungi singola</button>
              <button type="button" class="ard-btn ard-btn-blue" onclick="ARD_populateAllCategories(<?php echo $blog_id; ?>)">⚡ Carica tutte le categorie</button>
            </div>
          </div>
        <?php endforeach; ?>
      </div>

      <div class="ard-submit-bar">
        <button type="submit" class="button button-primary button-large">💾 Salva Icone</button>
        <span class="description">Salva le icone per tutti i siti collegati.</span>
      </div>
    </form>
  </div>

  <script>
  function ARD_switchTab(siteId) {
    document.querySelectorAll('.ard-site-tab').forEach(function(tab) { tab.classList.remove('active'); });
    document.querySelectorAll('.ard-site-panel').forEach(function(panel) { panel.classList.remove('active'); });
    document.querySelector('.ard-site-tab[data-site="' + siteId + '"]').classList.add('active');
    document.getElementById('ard-panel-' + siteId).classList.add('active');
  }

  function ARD_toggleValueInput(select) {
    var tr = select.closest('tr');
    var emojiField = tr.querySelector('.ard-emoji-field');
    var svgField = tr.querySelector('.ard-svg-field');
    var finalValue = tr.querySelector('.ard-final-value');
    if (select.value === 'svg') {
      emojiField.style.display = 'none';
      svgField.style.display = '';
      // Update final value from SVG select
      var svgSelect = svgField.querySelector('select');
      finalValue.value = svgSelect.value;
    } else {
      emojiField.style.display = '';
      svgField.style.display = 'none';
      // Update final value from emoji input
      var emojiInput = emojiField.querySelector('input');
      finalValue.value = emojiInput.value;
    }
    ARD_updatePreview(tr);
  }

  function ARD_updatePreview(tr) {
    var type = tr.querySelector('.ard-type-select').value;
    var preview = tr.querySelector('.ard-icon-preview');
    var finalValue = tr.querySelector('.ard-final-value');
    if (type === 'svg') {
      var svgSelect = tr.querySelector('.ard-svg-field select');
      var url = svgSelect.value;
      finalValue.value = url;
      preview.innerHTML = url ? '<img src="' + url + '" width="28" height="28" />' : '<span class="emoji-preview">❓</span>';
    } else {
      var emojiInput = tr.querySelector('.ard-emoji-field input');
      var emoji = emojiInput.value;
      finalValue.value = emoji;
      preview.innerHTML = '<span class="emoji-preview">' + (emoji || '❓') + '</span>';
    }
  }

  function ARD_toggleEquivalent(select) {
    var tr = select.closest('tr');
    var typeSelect = tr.querySelector('.ard-type-select');
    var emojiField = tr.querySelector('.ard-emoji-field');
    var svgField = tr.querySelector('.ard-svg-field');
    var placeholder = tr.querySelector('.ard-eq-placeholder');
    var preview = tr.querySelector('.ard-icon-preview');
    
    if (select.value) {
      typeSelect.style.display = 'none';
      if (emojiField) emojiField.style.display = 'none';
      if (svgField) svgField.style.display = 'none';
      if (placeholder) placeholder.style.display = '';
      preview.innerHTML = '<span class="emoji-preview">🔗</span>';
    } else {
      typeSelect.style.display = '';
      if (placeholder) placeholder.style.display = 'none';
      ARD_toggleValueInput(typeSelect);
    }
  }

  // Attach live-update listeners
  document.addEventListener('change', function(e) {
    if (e.target.matches('.ard-svg-select')) {
      var tr = e.target.closest('tr');
      tr.querySelector('.ard-final-value').value = e.target.value;
      ARD_updatePreview(tr);
    }
  });
  document.addEventListener('input', function(e) {
    if (e.target.matches('.ard-emoji-field input')) {
      var tr = e.target.closest('tr');
      tr.querySelector('.ard-final-value').value = e.target.value;
      ARD_updatePreview(tr);
    }
  });

  // Available SVGs for dynamic rows
  var ardSvgOptions = <?php echo wp_json_encode( $svg_list ); ?>;
  var ardSvgGroupLabels = <?php echo wp_json_encode( ARD_svg_icon_group_labels() ); ?>;
  // <option>s grouped like the PHP-rendered selects (custom, color, line)
  function ardSvgOptionsHtml() {
    var html = '<option value="">— Seleziona SVG —</option>';
    var group = null;
    for (var slug in ardSvgOptions) {
      var g = ardSvgOptions[slug].group;
      if (g !== group) {
        if (group !== null) html += '</optgroup>';
        group = g;
        html += '<optgroup label="' + (ardSvgGroupLabels[g] || g) + '">';
      }
      html += '<option value="' + ardSvgOptions[slug].url + '">' + slug + '</option>';
    }
    if (group !== null) html += '</optgroup>';
    return html;
  }

  // WooCommerce categories per site (for the dropdown)
  <?php
    $cats_js = array();
    $cat_counts_js = array();
    foreach ( $linked as $bid ) {
      $cats = ARD_get_categories_for_site( $bid );
      $cats_js[ $bid ] = array();
      $cat_counts_js[ $bid ] = array();
      foreach ( $cats as $c ) {
        $cats_js[ $bid ][] = $c->name;
        $cat_counts_js[ $bid ][ $c->name ] = (int) $c->count;
      }
    }
  ?>
  var ardSiteCategories = <?php echo wp_json_encode( $cats_js ); ?>;
  var ardSiteCatCounts = <?php echo wp_json_encode( $cat_counts_js ); ?>;

  // Site names for dynamic rows
  var ardSiteNames = <?php
    $names_js = array();
    foreach ( $linked as $bid ) {
      switch_to_blog( $bid );
      $names_js[ $bid ] = get_bloginfo( 'name' );
      restore_current_blog();
    }
    echo wp_json_encode( $names_js );
  ?>;

  function ARD_updateRowCount(select, siteId) {
    var tr = select.closest('tr');
    var badge = tr.querySelector('.ard-row-count');
    if (!badge) return;
    var count = (ardSiteCatCounts[siteId] && ardSiteCatCounts[siteId][select.value] !== undefined)
      ? ardSiteCatCounts[siteId][select.value]
      : 0;
    badge.textContent = count;
    badge.setAttribute('title', count + ' prodotti in questa categoria');
  }

  function ARD_addIconRow(siteId) {
    var tbody = document.getElementById('ard-tbody-' + siteId);
    // Get categories already assigned in this panel
    var usedNames = [];
    tbody.querySelectorAll('input[type="hidden"][name$="[name]"]').forEach(function(inp) {
      if (inp.value) usedNames.push(inp.value);
    });
    // Also check any <select> name dropdowns from previously added rows
    tbody.querySelectorAll('select.ard-cat-select').forEach(function(sel) {
      if (sel.value) usedNames.push(sel.value);
    });
    // Filter available categories
    var allCats = ardSiteCategories[siteId] || [];
    var available = allCats.filter(function(name) { return usedNames.indexOf(name) === -1; });
    if (available.length === 0) {
      alert('Tutte le categorie WooCommerce di questo sito hanno già un\'icona assegnata.');
      return;
    }
    var catOpts = '<option value="">— Seleziona categoria —</option>';
    available.forEach(function(name) {
      catOpts += '<option value="' + name + '">' + name + '</option>';
    });
    var svgOpts = ardSvgOptionsHtml();
    var eqOpts = '<option value="">— Nessuna —</option>';
    for (var otherBid in ardSiteCategories) {
      if (parseInt(otherBid) === parseInt(siteId)) continue;
      var otherSiteName = ardSiteNames[otherBid] || '';
      var otherCats = ardSiteCategories[otherBid] || [];
      otherCats.forEach(function(catName) {
        var optVal = otherBid + '|' + catName;
        eqOpts += '<option value="' + optVal + '">[' + otherSiteName + '] ' + catName + '</option>';
      });
    }

    var baseName = 'ard_site_icons[' + siteId + '][new_' + Date.now() + ']';
    var tr = document.createElement('tr');
    tr.draggable = true;
    tr.ondragstart = ARD_dragStart;
    tr.ondragend = ARD_dragEnd;
    tr.ondragover = ARD_dragOver;
    tr.ondragleave = ARD_dragLeave;
    tr.ondrop = ARD_drop;
    tr.innerHTML =
      '<td class="ard-drag-handle" title="Trascina per riordinare">⠿</td>' +
      '<td><span class="ard-icon-preview"><span class="emoji-preview">❓</span></span></td>' +
      '<td><select class="ard-cat-select" style="padding:6px 10px; border:1px solid #ddd; border-radius:4px; font-size:13px; width:220px;" onchange="this.nextElementSibling.value=this.value; ARD_updateRowCount(this, ' + siteId + ');">' + catOpts + '</select>' +
        '<input type="hidden" name="' + baseName + '[name]" value="" /></td>' +
      '<td style="text-align:center;"><span class="ard-row-count" style="display:inline-block; min-width:24px; padding:2px 8px; background:#eef2f7; color:#334e68; border:1px solid #d0dbe5; border-radius:12px; font-weight:600; font-size:12px;" title="0 prodotti in questa categoria">0</span></td>' +
      '<td><span style="display:inline-block; padding:3px 8px; background:#e8f0fe; border-radius:4px; font-size:11px; color:#1a73e8; font-weight:500;">' + (ardSiteNames[siteId] || '') + '</span></td>' +
      '<td><select class="ard-eq-select" name="' + baseName + '[equivalent]" onchange="ARD_toggleEquivalent(this)" style="width:100%; max-width:180px;">' + eqOpts + '</select></td>' +
      '<td><select class="ard-type-select" name="' + baseName + '[type]" onchange="ARD_toggleValueInput(this)"><option value="emoji">🔤 Emoji</option><option value="svg">📁 SVG</option></select></td>' +
      '<td>' +
        '<span class="ard-emoji-field"><input type="text" class="ard-value-input" name="' + baseName + '[emoji_value]" value="" placeholder="🍕" style="width:60px; text-align:center; font-size:20px;" /></span>' +
        '<span class="ard-svg-field" style="display:none;"><select class="ard-svg-select" name="' + baseName + '[svg_value]">' + svgOpts + '</select></span>' +
        '<span class="ard-eq-placeholder" style="display:none; color:#999; font-style:italic;">— (Usa equivalente)</span>' +
        '<input type="hidden" class="ard-final-value" name="' + baseName + '[value]" value="" />' +
      '</td>' +
      '<td><button type="button" class="ard-remove-row" onclick="this.closest(\'tr\').remove();">✕</button></td>';
    tbody.appendChild(tr);
  }

  function ARD_populateAllCategories(siteId) {
    var tbody = document.getElementById('ard-tbody-' + siteId);
    
    // Get categories already assigned in this panel
    var usedNames = [];
    tbody.querySelectorAll('input[type="hidden"][name$="[name]"]').forEach(function(inp) {
      if (inp.value) usedNames.push(inp.value);
    });
    tbody.querySelectorAll('select.ard-cat-select').forEach(function(sel) {
      if (sel.value) usedNames.push(sel.value);
    });
    
    var allCats = ardSiteCategories[siteId] || [];
    var available = allCats.filter(function(name) { return usedNames.indexOf(name) === -1; });
    
    if (available.length === 0) {
      alert('Tutte le categorie WooCommerce di questo sito con prodotti sono già in elenco.');
      return;
    }
    
    // Remove empty state row if present
    var emptyRow = tbody.querySelector('tr td[colspan]');
    if (emptyRow) {
      emptyRow.closest('tr').remove();
    }
    
    available.forEach(function(name, index) {
      var baseName = 'ard_site_icons[' + siteId + '][new_' + (Date.now() + index) + ']';
      var svgOpts = ardSvgOptionsHtml();
      
      var eqOpts = '<option value="">— Nessuna —</option>';
      for (var otherBid in ardSiteCategories) {
        if (parseInt(otherBid) === parseInt(siteId)) continue;
        var otherSiteName = ardSiteNames[otherBid] || '';
        var otherCats = ardSiteCategories[otherBid] || [];
        otherCats.forEach(function(catName) {
          var optVal = otherBid + '|' + catName;
          eqOpts += '<option value="' + optVal + '">[' + otherSiteName + '] ' + catName + '</option>';
        });
      }

      var count = (ardSiteCatCounts[siteId] && ardSiteCatCounts[siteId][name] !== undefined) ? ardSiteCatCounts[siteId][name] : 0;

      var tr = document.createElement('tr');
      tr.draggable = true;
      tr.ondragstart = ARD_dragStart;
      tr.ondragend = ARD_dragEnd;
      tr.ondragover = ARD_dragOver;
      tr.ondragleave = ARD_dragLeave;
      tr.ondrop = ARD_drop;
      
      tr.innerHTML =
        '<td class="ard-drag-handle" title="Trascina per riordinare">⠿</td>' +
        '<td><span class="ard-icon-preview"><span class="emoji-preview">❓</span></span></td>' +
        '<td><strong style="font-size:13px;">' + name + '</strong>' +
          '<input type="hidden" name="' + baseName + '[name]" value="' + name + '" /></td>' +
        '<td style="text-align:center;"><span style="display:inline-block; min-width:24px; padding:2px 8px; background:#eef2f7; color:#334e68; border:1px solid #d0dbe5; border-radius:12px; font-weight:600; font-size:12px;" title="' + count + ' prodotti in questa categoria">' + count + '</span></td>' +
        '<td><span style="display:inline-block; padding:3px 8px; background:#e8f0fe; border-radius:4px; font-size:11px; color:#1a73e8; font-weight:500;">' + (ardSiteNames[siteId] || '') + '</span></td>' +
        '<td><select class="ard-eq-select" name="' + baseName + '[equivalent]" onchange="ARD_toggleEquivalent(this)" style="width:100%; max-width:180px;">' + eqOpts + '</select></td>' +
        '<td><select class="ard-type-select" name="' + baseName + '[type]" onchange="ARD_toggleValueInput(this)"><option value="emoji">🔤 Emoji</option><option value="svg">📁 SVG</option></select></td>' +
        '<td>' +
          '<span class="ard-emoji-field"><input type="text" class="ard-value-input" name="' + baseName + '[emoji_value]" value="" placeholder="🍕" style="width:60px; text-align:center; font-size:20px;" /></span>' +
          '<span class="ard-svg-field" style="display:none;"><select class="ard-svg-select" name="' + baseName + '[svg_value]">' + svgOpts + '</select></span>' +
          '<span class="ard-eq-placeholder" style="display:none; color:#999; font-style:italic;">— (Usa equivalente)</span>' +
          '<input type="hidden" class="ard-final-value" name="' + baseName + '[value]" value="" />' +
        '</td>' +
        '<td><button type="button" class="ard-remove-row" onclick="this.closest(\'tr\').remove();">✕</button></td>';
      tbody.appendChild(tr);
    });
  }

  // ---- Drag & Drop Reordering ----
  var ardDraggedRow = null;

  function ARD_dragStart(e) {
    ardDraggedRow = e.target.closest('tr');
    ardDraggedRow.classList.add('ard-dragging');
    e.dataTransfer.effectAllowed = 'move';
    e.dataTransfer.setData('text/plain', ''); // Required for Firefox
  }

  function ARD_dragEnd(e) {
    if (ardDraggedRow) ardDraggedRow.classList.remove('ard-dragging');
    document.querySelectorAll('.ard-drag-over').forEach(function(el) { el.classList.remove('ard-drag-over'); });
    ardDraggedRow = null;
  }

  function ARD_dragOver(e) {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
    var targetRow = e.target.closest('tr');
    if (targetRow && targetRow !== ardDraggedRow && targetRow.parentNode.tagName === 'TBODY') {
      // Remove highlight from all rows first
      targetRow.closest('tbody').querySelectorAll('.ard-drag-over').forEach(function(el) { el.classList.remove('ard-drag-over'); });
      targetRow.classList.add('ard-drag-over');
    }
  }

  function ARD_dragLeave(e) {
    var targetRow = e.target.closest('tr');
    if (targetRow) targetRow.classList.remove('ard-drag-over');
  }

  function ARD_drop(e) {
    e.preventDefault();
    var targetRow = e.target.closest('tr');
    if (!targetRow || !ardDraggedRow || targetRow === ardDraggedRow) return;
    var tbody = targetRow.closest('tbody');
    if (!tbody) return;
    // Determine position: insert before or after
    var rows = Array.from(tbody.querySelectorAll('tr'));
    var dragIdx = rows.indexOf(ardDraggedRow);
    var targetIdx = rows.indexOf(targetRow);
    if (dragIdx < targetIdx) {
      tbody.insertBefore(ardDraggedRow, targetRow.nextSibling);
    } else {
      tbody.insertBefore(ardDraggedRow, targetRow);
    }
    targetRow.classList.remove('ard-drag-over');
  }
  </script>
  <?php
}

/**
 * Sync category icons to Firestore via Cloud Functions.
 */
function ARD_sync_category_icons_to_firestore() {
  $fetch_url = get_option( 'fetch_url' );
  if ( empty( $fetch_url ) ) return;
  if ( ARD_config_api_secret() === '' ) {
    error_log( '[MobileAdmin] Category icons sync skipped: ARD_CONFIG_API_SECRET not configured' );
    return;
  }

  $icons = get_option( 'app_category_icons', array() );
  $icons = ARD_maybe_migrate_category_icons( $icons );
  $icons = ARD_propagate_icons_to_translations( $icons );

  $response = wp_remote_post( rtrim( $fetch_url, '/' ) . '/config/update', array(
    'body'    => wp_json_encode( array(
      'apiSecret'     => ARD_config_api_secret(),
      'categoryIcons' => $icons,
    ) ),
    'headers' => array( 'Content-Type' => 'application/json' ),
    'timeout' => 15,
  ) );

  if ( is_wp_error( $response ) ) {
    error_log( '[MobileAdmin] Category icons sync failed: ' . $response->get_error_message() );
  }
}

// REST API endpoint for slides + category icons
add_action( 'rest_api_init', function() {
  register_rest_route( 'mobile-admin/v1', '/slides', array(
    'methods'             => 'GET',
    'callback'            => 'ARD_rest_get_slides',
    'permission_callback' => '__return_true',
  ) );
  register_rest_route( 'mobile-admin/v1', '/category-icons', array(
    'methods'             => 'GET',
    'callback'            => 'ARD_rest_get_category_icons',
    'permission_callback' => '__return_true',
  ) );
} );

function ARD_rest_get_slides() {
  $slides = get_option( 'app_slides', array() );
  foreach ( $slides as &$slide ) {
    if ( is_array( $slide ) ) {
      $site_id = isset( $slide['site_id'] ) ? (int) $slide['site_id'] : 0;
      $slide['site_url'] = ( $site_id > 0 ) ? get_home_url( $site_id ) : '';
    }
  }
  unset( $slide );
  return rest_ensure_response( array( 'slides' => $slides ) );
}

function ARD_rest_get_category_icons() {
  $icons = get_option( 'app_category_icons', array() );
  $icons = ARD_maybe_migrate_category_icons( $icons );
  $icons = ARD_propagate_icons_to_translations( $icons );
  return rest_ensure_response( array( 'icons' => $icons ) );
}

add_action( 'rest_api_init', function() {
  register_rest_route( 'mobile-admin/v1', '/search-suggest', array(
    'methods'             => 'GET',
    'callback'            => 'ARD_rest_global_search_suggest',
    'permission_callback' => '__return_true',
  ) );
  register_rest_route( 'mobile-admin/v1', '/branch-pages', array(
    'methods'             => 'GET',
    'callback'            => 'ARD_rest_get_branch_pages',
    'permission_callback' => '__return_true',
  ) );
} );

function ARD_rest_global_search_suggest( $request ) {
  $query = sanitize_text_field( $request->get_param( 'q' ) );

  $linked = get_option( 'wc_schedule_linked_sites', array() );
  // Exclude main hub (blog 8) if present
  $linked = array_diff( $linked, array( 8 ) );

  $suggestions = array();

  foreach ( $linked as $blog_id ) {
    switch_to_blog( $blog_id );

    global $wpdb;
    
    // 1. Query WooCommerce categories with products
    $term_sql = "
      SELECT t.name 
      FROM {$wpdb->terms} t
      INNER JOIN {$wpdb->term_taxonomy} tt ON t.term_id = tt.term_id
      WHERE tt.taxonomy = 'product_cat' 
        AND tt.count > 0
    ";
    if ( ! empty( $query ) ) {
      $term_sql .= " AND t.name LIKE '%" . esc_sql( $wpdb->esc_like( $query ) ) . "%'";
      $term_sql .= " LIMIT 15";
    } else {
      $term_sql .= " LIMIT 100";
    }
    $term_rows = $wpdb->get_results( $term_sql );

    $icons = get_option( 'app_category_icons', array() );
    $icons = ARD_maybe_migrate_category_icons( $icons );

    foreach ( $term_rows as $row ) {
      $clean_name = preg_replace( '/^\d+\.\s*/', '', $row->name );

      // If there is an equivalent category mapped, group under the equivalent category's clean name
      if ( isset( $icons[ $blog_id ][ $row->name ]['equivalent'] ) && ! empty( $icons[ $blog_id ][ $row->name ]['equivalent'] ) ) {
        $parts = explode( '|', $icons[ $blog_id ][ $row->name ]['equivalent'] );
        if ( count( $parts ) === 2 ) {
          $clean_name = preg_replace( '/^\d+\.\s*/', '', $parts[1] );
        }
      }

      $key = 'cat_' . sanitize_title( $clean_name );
      if ( ! isset( $suggestions[ $key ] ) ) {
        $suggestions[ $key ] = array(
          'label' => $clean_name,
          'value' => $clean_name,
          'type'  => 'category',
          'sites' => array()
        );
      }
      if ( ! in_array( $blog_id, $suggestions[ $key ]['sites'] ) ) {
        $suggestions[ $key ]['sites'][] = (int) $blog_id;
      }
    }

    // 2. Query products (post_type = 'product', post_status = 'publish') with category details
    $product_sql = "
      SELECT p.post_title, t.term_id AS category_id, t.name AS category_name
      FROM {$wpdb->posts} p
      INNER JOIN {$wpdb->term_relationships} tr ON p.ID = tr.object_id
      INNER JOIN {$wpdb->term_taxonomy} tt ON tr.term_taxonomy_id = tt.term_taxonomy_id AND tt.taxonomy = 'product_cat'
      INNER JOIN {$wpdb->terms} t ON tt.term_id = t.term_id
      WHERE p.post_type = 'product'
        AND p.post_status = 'publish'
    ";
    if ( ! empty( $query ) ) {
      $product_sql .= " AND p.post_title LIKE '%" . esc_sql( $wpdb->esc_like( $query ) ) . "%'";
      $product_sql .= " LIMIT 40";
    } else {
      $product_sql .= " LIMIT 800";
    }
    $product_rows = $wpdb->get_results( $product_sql );

    foreach ( $product_rows as $row ) {
      // Clean leading number and dot (e.g. "4. ")
      $clean_name = preg_replace( '/^\d+\.\s*/', '', $row->post_title );
      $clean_name = preg_replace( '/\s+/', ' ', $clean_name );
      $clean_name = trim( $clean_name );
      
      // Standardize "Singola", "Famiglia" and "Bimbi" tags formatting
      if ( preg_match( '/\bSingola\b/i', $clean_name ) && ! preg_match( '/\(\s*Singola\s*\)/i', $clean_name ) ) {
        $clean_name = preg_replace( '/\s+Singola\b/i', ' (Singola)', $clean_name );
      }
      if ( preg_match( '/\bFamiglia\b/i', $clean_name ) && ! preg_match( '/\(\s*Famiglia\s*\)/i', $clean_name ) ) {
        $clean_name = preg_replace( '/\s+Famiglia\b/i', ' (Famiglia)', $clean_name );
      }
      if ( preg_match( '/\bBimbi\b/i', $clean_name ) && ! preg_match( '/\(\s*Bimbi\s*\)/i', $clean_name ) ) {
        $clean_name = preg_replace( '/\s+Bimbi\b/i', ' (Bimbi)', $clean_name );
      }

      $key = 'prod_' . sanitize_title( $clean_name );
      
      $raw_cat_name = $row->category_name;
      $clean_cat_name = preg_replace( '/^\d+\.\s*/', '', $raw_cat_name );
      
      if ( isset( $icons[ $blog_id ][ $raw_cat_name ]['equivalent'] ) && ! empty( $icons[ $blog_id ][ $raw_cat_name ]['equivalent'] ) ) {
        $parts = explode( '|', $icons[ $blog_id ][ $raw_cat_name ]['equivalent'] );
        if ( count( $parts ) === 2 ) {
          $clean_cat_name = preg_replace( '/^\d+\.\s*/', '', $parts[1] );
        }
      }

      if ( ! isset( $suggestions[ $key ] ) ) {
        $suggestions[ $key ] = array(
          'label'      => $clean_name,
          'value'      => $clean_name,
          'type'       => 'product',
          'sites'      => array(),
          'categories' => array()
        );
      }
      if ( ! in_array( $blog_id, $suggestions[ $key ]['sites'] ) ) {
        $suggestions[ $key ]['sites'][] = (int) $blog_id;
      }
      
      $suggestions[ $key ]['categories'][ (string) $blog_id ] = array(
        'id'   => (int) $row->category_id,
        'name' => $clean_cat_name
      );
    }

    restore_current_blog();
  }

  return rest_ensure_response( array( 'suggestions' => array_values( $suggestions ) ) );
}

function ARD_rest_get_branch_pages( $request ) {
  $blog_id = (int) $request->get_param( 'blog_id' );
  if ( ! $blog_id ) {
    return rest_ensure_response( array( 'categories' => array(), 'products' => array() ) );
  }

  // Verify that it is a linked site to prevent unauthorized access
  $linked_sites = (array) get_option( 'wc_schedule_linked_sites', array() );
  if ( empty( $linked_sites ) ) {
    $linked_sites = array( get_current_blog_id() );
  }
  if ( ! in_array( $blog_id, array_map( 'intval', $linked_sites ), true ) ) {
    return rest_ensure_response( array( 'categories' => array(), 'products' => array() ) );
  }

  switch_to_blog( $blog_id );
  global $wpdb;

  // 1. Fetch WooCommerce categories that have at least one product
  $cats_sql = "
    SELECT t.term_id AS id, t.name 
    FROM {$wpdb->terms} t
    INNER JOIN {$wpdb->term_taxonomy} tt ON t.term_id = tt.term_id
    WHERE tt.taxonomy = 'product_cat' 
      AND tt.count > 0
    ORDER BY t.name ASC
  ";
  $cats = $wpdb->get_results( $cats_sql );

  // 2. Fetch products with their corresponding category ID and name
  $products_sql = "
    SELECT p.ID AS id, p.post_title AS name, t.term_id AS cat_id, t.name AS cat_name
    FROM {$wpdb->posts} p
    INNER JOIN {$wpdb->term_relationships} tr ON p.ID = tr.object_id
    INNER JOIN {$wpdb->term_taxonomy} tt ON tr.term_taxonomy_id = tt.term_taxonomy_id AND tt.taxonomy = 'product_cat'
    INNER JOIN {$wpdb->terms} t ON tt.term_id = t.term_id
    WHERE p.post_type = 'product'
      AND p.post_status = 'publish'
    ORDER BY p.post_title ASC
  ";
  $products = $wpdb->get_results( $products_sql );

  restore_current_blog();

  return rest_ensure_response( array(
    'categories' => $cats ? $cats : array(),
    'products'   => $products ? $products : array(),
  ) );
}

// ================================================================
// WOOCOMMERCE GLOBAL PRODUCT ADDONS REST ENDPOINT
// Extracted to mu-plugins/cs-addons-rest-api.php for clean separation of concerns.
// Registers: GET /wp-json/cs/v1/addons/all
// Required by Firebase Cloud Function getAddonsAsync().
// ================================================================

function WPADR_rest_get_pos_info() {
	// Read linked sites dynamically from the main site (blog ID 1) option
	switch_to_blog( 1 );
	$linked_sites = (array) get_option( 'wc_schedule_linked_sites', array() );
	restore_current_blog();

	if ( empty( $linked_sites ) ) {
		$linked_sites = array( 22, 23, 63 ); // Fallback to current main sites
	}

	$info = array();

	// Fallback numbers/addresses if POS settings are empty or point to giubiasco
	$fallbacks = array(
		22 => array(
			'phone'   => '091 857 88 77',
			'address' => 'Viale Stazione 11, 6512 Giubiasco',
		),
		23 => array(
			'phone'   => '091 857 88 77',
			'address' => 'Vicolo Nord 1, 6500 Bellinzona',
		),
		24 => array(
			'phone'   => '091 994 63 63',
			'address' => 'Via Paradiso 24, 6924 Sorengo',
		),
		63 => array(
			'phone'   => '091 825 18 19',
			'address' => 'Via San Giovanni 9, 6500 Bellinzona',
		),
	);

	foreach ( $linked_sites as $blog_id ) {
		$blog_id = intval( $blog_id );
		if ( $blog_id === 1 ) {
			continue; // Skip the main network dashboard hub
		}

		switch_to_blog( $blog_id );

		$store_name    = get_option( 'woocommerce_pos_store_name', '' );
		$store_address = get_option( 'woocommerce_pos_store_address', '' );
		$store_phone   = get_option( 'woocommerce_pos_store_phone', '' );
		$store_email   = get_option( 'woocommerce_pos_store_email', '' );

		if ( empty( $store_name ) ) {
			$store_name = get_bloginfo( 'name' );
		}

		if ( empty( $store_phone ) ) {
			$store_phone = isset( $fallbacks[ $blog_id ] ) ? $fallbacks[ $blog_id ]['phone'] : '091 857 88 77';
		}

		// Clean up address if it contains Giubiasco on a non-Giubiasco site
		if ( empty( $store_address ) || ( $blog_id !== 22 && strpos( strtolower( $store_address ), 'giubiasco' ) !== false ) ) {
			$store_address = isset( $fallbacks[ $blog_id ] ) ? $fallbacks[ $blog_id ]['address'] : '';
		}

		// Get delivery hours settings
		$time_settings      = get_option( 'coderockz_woo_delivery_time_settings', array() );
		$time_slot_settings = get_option( 'coderockz_woo_delivery_time_slot_settings', array() );

		$schedules = array();

		// Default schedules mapping if delivery time slots are empty
		if ( empty( $time_slot_settings ) || empty( $time_slot_settings['time_slot'] ) ) {
			// Fallback schedules
			if ( $blog_id === 24 ) {
				$schedules = array(
					array(
						'title'     => 'Dal Lunedì al Sabato:',
						'fromAndTo' => array( array( '17:00', '22:00' ) ),
					),
					array(
						'title'     => 'Orari di consegna a domicilio:',
						'fromAndTo' => array( array( '18:00', '22:00' ) ),
					),
				);
			} else {
				$schedules = array(
					array(
						'title'     => 'Dal Lunedì al Sabato:',
						'fromAndTo' => array(
							array( '10:00', '14:00' ),
							array( '17:00', '22:00' ),
						),
					),
					array(
						'title'     => 'Orari di consegna a domicilio:',
						'fromAndTo' => array( array( '18:00', '22:00' ) ),
					),
				);
			}
		} else {
			// Parse the time slots from WooCommerce Delivery settings dynamically!
			$slots = $time_slot_settings['time_slot'];
			
			// We group timeslots by their name/type or just compile them
			foreach ( $slots as $slot ) {
				if ( isset( $slot['enable'] ) && $slot['enable'] ) {
					$slot_name = isset( $slot['name'] ) ? $slot['name'] : 'Orari';
					
					// Convert start/end minutes to HH:MM format
					$start_min = isset( $slot['start'] ) ? (int) $slot['start'] : 0;
					$end_min   = isset( $slot['end'] ) ? (int) $slot['end'] : 0;
					
					$start_h   = str_pad( floor( $start_min / 60 ), 2, '0', STR_PAD_LEFT );
					$start_m   = str_pad( $start_min % 60, 2, '0', STR_PAD_LEFT );
					$end_h     = str_pad( floor( $end_min / 60 ), 2, '0', STR_PAD_LEFT );
					$end_m     = str_pad( $end_min % 60, 2, '0', STR_PAD_LEFT );
					
					$time_range = array( "{$start_h}:{$start_m}", "{$end_h}:{$end_m}" );
					
					// Check if a slot with this name already exists in $schedules
					$found = false;
					$title_str = $slot_name . ':';
					foreach ( $schedules as &$sch ) {
						if ( $sch['title'] === $title_str ) {
							$sch['fromAndTo'][] = $time_range;
							$found = true;
							break;
						}
					}
					if ( !$found ) {
						$schedules[] = array(
							'title'     => $title_str,
							'fromAndTo' => array( $time_range ),
						);
					}
				}
			}
		}

		$details = get_blog_details( $blog_id );
		if ( $details && strpos( strtolower( $details->domain ), 'dame' ) !== false ) {
			$key = 'dame';
		} else {
			$key = $details ? str_replace( array( '.mrjoecity.ch', '.ch', '/' ), '', $details->domain . $details->path ) : "site_{$blog_id}";
		}

		$info[] = array(
			'key'       => $key,
			'siteId'    => $blog_id,
			'name'      => $store_name,
			'address'   => str_replace( array( "\r\n", "\r", "\n" ), ", ", trim( $store_address ) ),
			'phone'     => $store_phone,
			'email'     => $store_email,
			'schedules' => $schedules,
		);

		restore_current_blog();
	}

	return rest_ensure_response( array( 'outlets' => $info ) );
}

/**
 * Add custom fields to WooCommerce Flat Rate shipping settings
 */
add_filter( 'woocommerce_shipping_instance_form_fields_flat_rate', 'WPADR_add_flat_rate_minimum_order_fields', 10, 1 );
function WPADR_add_flat_rate_minimum_order_fields( $fields ) {
	$fields['enable_min_amount'] = array(
		'title'   => 'Importo minimo',
		'type'    => 'checkbox',
		'label'   => 'Abilita importo minimo del carrello',
		'default' => 'no',
	);
	$fields['min_amount'] = array(
		'title'       => 'Soglia importo minimo (CHF)',
		'type'        => 'number',
		'description' => 'L\'importo minimo del carrello necessario per rendere disponibile questo metodo.',
		'desc_tip'    => true,
		'default'     => '',
		'custom_attributes' => array(
			'step' => 'any',
			'min'  => '0',
		),
	);
	return $fields;
}

/**
 * Filter available WooCommerce rates by minimum order amount configured on the Flat Rate method
 */
add_filter( 'woocommerce_package_rates', 'WPADR_filter_flat_rate_rates_by_minimum_order', 10, 2 );
function WPADR_filter_flat_rate_rates_by_minimum_order( $rates, $package ) {
	// Skip if WooCommerce cart is not loaded
	if ( ! WC() || ! WC()->cart ) {
		return $rates;
	}

	$cart_total = WC()->cart->get_subtotal();

	foreach ( $rates as $rate_key => $rate ) {
		if ( 'flat_rate' === $rate->method_id ) {
			$option_key = 'woocommerce_flat_rate_' . $rate->instance_id . '_settings';
			$settings = get_option( $option_key );
			if ( is_array( $settings ) ) {
				$enable_min = isset( $settings['enable_min_amount'] ) ? $settings['enable_min_amount'] : 'no';
				$min_val = isset( $settings['min_amount'] ) ? floatval( $settings['min_amount'] ) : 0;
				if ( 'yes' === $enable_min && $cart_total < $min_val ) {
					unset( $rates[ $rate_key ] );
				}
			}
		}
	}
	return $rates;
}

/* =========================================================================
 * Delivery CAPs from WooCommerce shipping zones (network-wide, v2.1.0)
 *
 * Single source of truth: the postcodes configured in each subsite's
 * WooCommerce shipping zones. Exposed as:
 *  - PHP helper  WPADR_get_network_delivery_caps()
 *  - REST        GET /wp-json/wpadr/v1/delivery-caps  (?refresh=1 for admins)
 *  - Shortcode   [wpadr_cap_selector]  (CAP input -> matching sedi + links)
 * Multisite only: on single-site installs everything returns empty / renders
 * nothing, so the plugin stays safe on other (non-network) installations.
 * ========================================================================= */

/**
 * Collect, per subsite, the postcodes covered by delivery-capable shipping
 * zones (enabled flat_rate/free_shipping) and whether local pickup is offered.
 * Cached in a network transient for 10 minutes.
 *
 * @return array[] [ blog_id, name, url, delivery_caps => string[], pickup => bool ]
 */
function WPADR_get_network_delivery_caps( $force_refresh = false ) {
	if ( ! is_multisite() ) {
		return array();
	}
	$cache_key = 'wpadr_network_delivery_caps';
	if ( ! $force_refresh ) {
		$cached = get_site_transient( $cache_key );
		if ( false !== $cached ) {
			return $cached;
		}
	}

	// Only sites under the same registrable domain as the current site
	// (e.g. bellinzona.littleinka.ch under littleinka.ch): on shared networks
	// this keeps other brands' shops out of the selector.
	$current_host = (string) wp_parse_url( home_url( '/' ), PHP_URL_HOST );

	global $wpdb;
	$rows = array();
	foreach ( get_sites( array( 'number' => 0 ) ) as $site ) {
		switch_to_blog( (int) $site->blog_id );

		$site_host   = (string) wp_parse_url( home_url( '/' ), PHP_URL_HOST );
		$same_domain = ( $site_host === $current_host )
			|| ( substr( $site_host, -strlen( '.' . $current_host ) ) === '.' . $current_host );

		// switch_to_blog() does NOT load the other site's plugins, so the WC
		// classes are unavailable when WooCommerce is inactive on the current
		// site (the hub). Read the zone tables directly instead.
		$methods_table   = $wpdb->prefix . 'woocommerce_shipping_zone_methods';
		$locations_table = $wpdb->prefix . 'woocommerce_shipping_zone_locations';
		$has_wc_tables   = $same_domain
			&& $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $methods_table ) ) === $methods_table;

		if ( $has_wc_tables ) {
			$delivery_caps  = array();
			$has_pickup     = false;
			$delivery_zones = array();

			$methods = $wpdb->get_results(
				"SELECT zone_id, method_id, is_enabled FROM `{$methods_table}`"
			);
			foreach ( $methods as $method ) {
				if ( ! (int) $method->is_enabled ) {
					continue;
				}
				if ( in_array( $method->method_id, array( 'flat_rate', 'free_shipping' ), true ) ) {
					$delivery_zones[ (int) $method->zone_id ] = true;
				}
				// Zone 0 ("rest of the world") holds pickup-only setups.
				if ( 'local_pickup' === $method->method_id ) {
					$has_pickup = true;
				}
			}

			if ( ! empty( $delivery_zones ) ) {
				$locations = $wpdb->get_results(
					"SELECT zone_id, location_code, location_type FROM `{$locations_table}`"
				);
				foreach ( $locations as $location ) {
					if ( 'postcode' === $location->location_type
						&& isset( $delivery_zones[ (int) $location->zone_id ] ) ) {
						$delivery_caps[] = (string) $location->location_code;
					}
				}
			}

			if ( ! empty( $delivery_caps ) || $has_pickup ) {
				$rows[] = array(
					'blog_id'       => (int) $site->blog_id,
					'name'          => get_bloginfo( 'name' ),
					'url'           => home_url( '/' ),
					'delivery_caps' => array_values( array_unique( $delivery_caps ) ),
					'pickup'        => $has_pickup,
				);
			}
		}
		restore_current_blog();
	}

	// Prefer the sede post title (CPT on the main site) over the raw blog name.
	$sede_query = new WP_Query( array( 'post_type' => 'sede', 'posts_per_page' => -1 ) );
	if ( $sede_query->have_posts() && function_exists( 'get_field' ) ) {
		$titles_by_host = array();
		foreach ( $sede_query->posts as $sede_post ) {
			$link = (string) get_field( 'link_per_questa_sede', $sede_post->ID );
			$host = wp_parse_url( $link, PHP_URL_HOST );
			if ( $host ) {
				$titles_by_host[ $host ] = get_the_title( $sede_post );
			}
		}
		foreach ( $rows as $i => $row ) {
			$host = wp_parse_url( $row['url'], PHP_URL_HOST );
			if ( $host && isset( $titles_by_host[ $host ] ) ) {
				$rows[ $i ]['name'] = $titles_by_host[ $host ];
			}
		}
	}
	wp_reset_postdata();

	set_site_transient( $cache_key, $rows, 10 * MINUTE_IN_SECONDS );
	return $rows;
}

add_action( 'rest_api_init', function () {
	register_rest_route( 'wpadr/v1', '/delivery-caps', array(
		'methods'             => 'GET',
		'callback'            => 'WPADR_rest_delivery_caps',
		'permission_callback' => '__return_true',
	) );
} );
function WPADR_rest_delivery_caps( WP_REST_Request $request ) {
	$force = $request->get_param( 'refresh' ) && current_user_can( 'manage_options' );
	return rest_ensure_response( WPADR_get_network_delivery_caps( (bool) $force ) );
}

/**
 * [wpadr_cap_selector] — CAP input that routes visitors to the sede that
 * delivers to their postcode, reading directly from the shipping zones.
 * Supports exact codes, wildcards ("65*") and ranges ("6500...6599").
 */
add_shortcode( 'wpadr_cap_selector', 'WPADR_cap_selector_shortcode' );
function WPADR_cap_selector_shortcode( $atts ) {
	$atts = shortcode_atts( array(
		'placeholder'  => 'Inserisci il tuo CAP...',
		'no_delivery'  => 'Nessuna consegna a domicilio disponibile per questo CAP. Puoi ordinare con ritiro in sede:',
		'order_label'  => 'Ordina',
		'pickup_badge' => 'Solo Ritiro in Sede',
	), $atts, 'wpadr_cap_selector' );

	$sites = WPADR_get_network_delivery_caps();
	if ( empty( $sites ) ) {
		return '';
	}

	$payload = wp_json_encode( $sites );
	$uid     = 'wpadr-cap-' . wp_unique_id();

	ob_start();
	?>
	<div class="wpadr-cap-selector" id="<?php echo esc_attr( $uid ); ?>">
		<input type="text" inputmode="numeric" maxlength="4" class="wpadr-cap-input"
			placeholder="<?php echo esc_attr( $atts['placeholder'] ); ?>" aria-label="CAP" />
		<div class="wpadr-cap-results" role="region" aria-live="polite"></div>
	</div>
	<style>
		.wpadr-cap-selector .wpadr-cap-input{width:100%;max-width:420px;padding:12px 16px;font-size:1.1em;border:1px solid #ccc;border-radius:8px}
		.wpadr-cap-selector .wpadr-cap-card{display:flex;align-items:center;justify-content:space-between;gap:12px;border:1px solid #ddd;border-radius:8px;padding:14px 16px;margin-top:10px;max-width:420px}
		.wpadr-cap-selector .wpadr-cap-card a{white-space:nowrap}
		.wpadr-cap-selector .wpadr-cap-note{margin-top:10px;max-width:420px}
		.wpadr-cap-selector .wpadr-cap-badge{font-size:.85em;opacity:.75}
	</style>
	<script>
	(function(){
		var root = document.getElementById(<?php echo wp_json_encode( $uid ); ?>);
		if (!root) return;
		var SITES = <?php echo $payload; ?>;
		var LABELS = <?php echo wp_json_encode( array(
			'no_delivery'  => $atts['no_delivery'],
			'order_label'  => $atts['order_label'],
			'pickup_badge' => $atts['pickup_badge'],
		) ); ?>;
		var input = root.querySelector('.wpadr-cap-input');
		var results = root.querySelector('.wpadr-cap-results');

		function capMatches(code, cap){
			code = String(code).trim();
			if (code.indexOf('...') !== -1){
				var p = code.split('...');
				return cap >= p[0].trim() && cap <= p[1].trim();
			}
			if (code.slice(-1) === '*'){
				return cap.indexOf(code.slice(0, -1)) === 0;
			}
			return code === cap;
		}
		function card(site, badge){
			var div = document.createElement('div');
			div.className = 'wpadr-cap-card';
			var left = document.createElement('div');
			var strong = document.createElement('strong');
			strong.textContent = site.name;
			left.appendChild(strong);
			if (badge){
				var b = document.createElement('div');
				b.className = 'wpadr-cap-badge';
				b.textContent = badge;
				left.appendChild(b);
			}
			var a = document.createElement('a');
			a.href = site.url;
			a.className = 'wpadr-cap-order button';
			a.textContent = LABELS.order_label;
			div.appendChild(left);
			div.appendChild(a);
			return div;
		}
		function render(){
			var cap = input.value.replace(/\D/g, '');
			input.value = cap;
			results.textContent = '';
			if (cap.length !== 4) return;
			var delivering = SITES.filter(function(s){
				return (s.delivery_caps || []).some(function(c){ return capMatches(c, cap); });
			});
			if (delivering.length){
				delivering.forEach(function(s){ results.appendChild(card(s, null)); });
				return;
			}
			var note = document.createElement('p');
			note.className = 'wpadr-cap-note';
			note.textContent = LABELS.no_delivery;
			results.appendChild(note);
			SITES.filter(function(s){ return s.pickup; }).forEach(function(s){
				results.appendChild(card(s, LABELS.pickup_badge));
			});
		}
		input.addEventListener('input', render);
	})();
	</script>
	<?php
	return ob_get_clean();
}



/**
 * App payment methods per sede (v2.3.0)
 *
 * Lets the admin switch TWINT / payment on delivery on or off for each
 * sede of the app. Stored as a NETWORK option keyed by sede host (the
 * `siteId` the app already uses, e.g. "biasca.littleinka.ch"); the admin
 * page exists only on the brand hub (littleinka.ch).
 *
 *  - Admin page  Gestione App → Metodi di Pagamento
 *  - REST        GET mobile-admin/v1/payment-methods[?site=<host>]
 *
 * A sede without a saved row gets every method enabled, i.e. the app keeps
 * behaving exactly as before until something is switched off.
 */
/**
 * Payment methods the app supports. `provider` is who processes an online
 * payment (shown to the admin and returned by the REST endpoint); offline
 * methods have none. Filterable, so a new method or a provider switch only
 * needs to be declared here, never in the page markup.
 */
function ARD_payment_methods_catalog() {
	return apply_filters( 'ard_app_payment_methods_catalog', array(
		'twint' => array(
			'label'    => 'TWINT',
			'type'     => 'online',
			'provider' => 'Datatrans',
		),
		'cod'   => array(
			'label'    => 'Pagamento alla consegna',
			'type'     => 'offline',
			'provider' => '',
		),
	) );
}

/** "Online · Datatrans" / "Contanti o carta alla consegna" for the column header. */
function ARD_payment_methods_describe( array $method ) {
	if ( 'online' === $method['type'] ) {
		return $method['provider'] ? 'Online · fornitore: ' . $method['provider'] : 'Online';
	}
	return 'Alla consegna / al ritiro';
}

function ARD_payment_methods_normalize_host( $host ) {
	$host = strtolower( trim( (string) $host ) );
	$host = preg_replace( '#^https?://#', '', $host );
	return rtrim( $host, '/' );
}

/**
 * Sedi = subdomains with WooCommerce of the current site's brand domain
 * (*.littleinka.ch, from the hub or any sede), so other brands sharing the
 * network never show up. Returns [ host => label ].
 */
function ARD_payment_methods_sites() {
	if ( ! is_multisite() ) {
		$host = ARD_payment_methods_normalize_host( wp_parse_url( home_url( '/' ), PHP_URL_HOST ) );
		return array( $host => get_bloginfo( 'name' ) );
	}

	$current_host = (string) wp_parse_url( home_url( '/' ), PHP_URL_HOST );
	$labels       = explode( '.', $current_host );
	$brand_domain = implode( '.', array_slice( $labels, -2 ) );

	global $wpdb;
	$sites = array();
	foreach ( get_sites( array( 'number' => 0, 'deleted' => 0, 'archived' => 0 ) ) as $site ) {
		$host = ARD_payment_methods_normalize_host( $site->domain );
		// Sedi are subdomains: the brand hub itself (littleinka.ch) is not one.
		if ( substr( $host, -strlen( '.' . $brand_domain ) ) !== '.' . $brand_domain ) {
			continue;
		}
		$table = $wpdb->get_blog_prefix( (int) $site->blog_id ) . 'woocommerce_shipping_zone_methods';
		if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) ) !== $table ) {
			continue;
		}
		$details        = get_blog_details( (int) $site->blog_id );
		$sites[ $host ] = $details && $details->blogname ? $details->blogname : $host;
	}
	return $sites;
}

/** Enabled flags for one sede host: [ method => bool ]. */
function ARD_payment_methods_for_host( $host ) {
	$saved  = (array) get_site_option( 'ard_app_payment_methods', array() );
	$host   = ARD_payment_methods_normalize_host( $host );
	$result = array();
	foreach ( array_keys( ARD_payment_methods_catalog() ) as $method ) {
		$result[ $method ] = isset( $saved[ $host ][ $method ] ) ? (bool) $saved[ $host ][ $method ] : true;
	}
	return $result;
}

/**
 * The setting is managed centrally from the brand hub only (littleinka.ch):
 * true on a site whose host has no subdomain part, or on a single install.
 */
function ARD_payment_methods_is_hub() {
	if ( ! is_multisite() ) {
		return true;
	}
	$host = ARD_payment_methods_normalize_host( wp_parse_url( home_url( '/' ), PHP_URL_HOST ) );
	return substr_count( $host, '.' ) === 1;
}

add_action( 'admin_menu', 'ARD_payment_methods_menu', 20 );
function ARD_payment_methods_menu() {
	if ( ! ARD_payment_methods_is_hub() ) {
		return;
	}
	add_submenu_page(
		'ard_stato_app',
		'Metodi di Pagamento',
		'Metodi di Pagamento',
		'manage_options',
		'ard_payment_methods',
		'ARD_showContent_payment_methods'
	);
}

function ARD_showContent_payment_methods() {
	if ( ! ARD_payment_methods_is_hub() || ! current_user_can( 'manage_options' ) ) {
		wp_die( 'Pagina disponibile solo sul sito principale del brand.' );
	}
	$catalog = ARD_payment_methods_catalog();
	$sites   = ARD_payment_methods_sites();
	$errors  = array();

	if ( isset( $_POST['ard_payment_methods_nonce'] )
		&& wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['ard_payment_methods_nonce'] ) ), 'ard_save_payment_methods' ) ) {
		$posted = isset( $_POST['ard_pm'] ) && is_array( $_POST['ard_pm'] ) ? wp_unslash( $_POST['ard_pm'] ) : array();
		$saved  = (array) get_site_option( 'ard_app_payment_methods', array() );

		foreach ( $sites as $host => $label ) {
			$row = array();
			foreach ( array_keys( $catalog ) as $method ) {
				$row[ $method ] = ! empty( $posted[ $host ][ $method ] );
			}
			// A sede with no method at all could never complete a checkout:
			// keep its previous settings and tell the admin.
			if ( ! in_array( true, $row, true ) ) {
				$errors[] = $label;
				continue;
			}
			$saved[ $host ] = $row;
		}

		update_site_option( 'ard_app_payment_methods', $saved );
		do_action( 'litespeed_purge_all' );

		if ( $errors ) {
			echo '<div class="notice notice-error"><p>Ogni sede deve avere almeno un metodo di pagamento attivo. Non salvate: <strong>' . esc_html( implode( ', ', $errors ) ) . '</strong></p></div>';
		} else {
			echo '<div class="notice notice-success"><p>Metodi di pagamento salvati. L\'app li applica dal prossimo carrello aperto.</p></div>';
		}
	}
	?>
	<div class="wrap">
		<h1>Metodi di Pagamento App</h1>
		<p class="description">Scegli quali metodi di pagamento mostrare nel carrello dell'app per ciascuna sede. Ogni sede deve averne almeno uno attivo.</p>

		<?php if ( empty( $sites ) ) : ?>
			<p><em>Nessuna sede con WooCommerce trovata su questo dominio.</em></p>
		<?php else : ?>
		<form method="post">
			<?php wp_nonce_field( 'ard_save_payment_methods', 'ard_payment_methods_nonce' ); ?>
			<table class="widefat striped" style="max-width:760px;margin-top:16px;">
				<thead>
					<tr>
						<th>Sede</th>
						<?php foreach ( $catalog as $method ) : ?>
							<th style="text-align:center;">
								<?php echo esc_html( $method['label'] ); ?><br/>
								<span style="font-weight:normal;color:#646970;font-size:12px;"><?php echo esc_html( ARD_payment_methods_describe( $method ) ); ?></span>
							</th>
						<?php endforeach; ?>
					</tr>
				</thead>
				<tbody>
					<?php foreach ( $sites as $host => $label ) :
						$enabled = ARD_payment_methods_for_host( $host ); ?>
						<tr>
							<td><strong><?php echo esc_html( $label ); ?></strong><br/><code><?php echo esc_html( $host ); ?></code></td>
							<?php foreach ( array_keys( $catalog ) as $method ) : ?>
								<td style="text-align:center;vertical-align:middle;">
									<input type="checkbox" name="ard_pm[<?php echo esc_attr( $host ); ?>][<?php echo esc_attr( $method ); ?>]" value="1" <?php checked( $enabled[ $method ] ); ?> />
								</td>
							<?php endforeach; ?>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
			<?php submit_button( 'Salva metodi di pagamento' ); ?>
		</form>
		<?php endif; ?>
	</div>
	<?php
}

add_action( 'rest_api_init', function () {
	register_rest_route( 'mobile-admin/v1', '/payment-methods', array(
		'methods'             => 'GET',
		'callback'            => 'ARD_rest_get_payment_methods',
		'permission_callback' => '__return_true',
	) );
} );

/**
 * GET /wp-json/mobile-admin/v1/payment-methods?site=biasca.littleinka.ch
 *   → { "site": "biasca.littleinka.ch", "methods": { "twint": true, "cod": false },
 *       "catalog": { "twint": { "label", "type", "provider" }, ... } }
 * Without ?site: { "sites": { "<host>": { ... }, ... }, "catalog": ... }.
 */
function ARD_rest_get_payment_methods( WP_REST_Request $request ) {
	$site = $request->get_param( 'site' );
	if ( ! empty( $site ) ) {
		$host = ARD_payment_methods_normalize_host( $site );
		$data = array( 'site' => $host, 'methods' => ARD_payment_methods_for_host( $host ) );
	} else {
		$data = array( 'sites' => array() );
		foreach ( array_keys( ARD_payment_methods_sites() ) as $host ) {
			$data['sites'][ $host ] = ARD_payment_methods_for_host( $host );
		}
	}
	$data['catalog'] = ARD_payment_methods_catalog();

	// Must reflect a change immediately: never let LiteSpeed/CDN cache it.
	$response = rest_ensure_response( $data );
	$response->header( 'Cache-Control', 'no-cache, no-store, must-revalidate' );
	$response->header( 'X-LiteSpeed-Cache-Control', 'no-cache' );
	return $response;
}
