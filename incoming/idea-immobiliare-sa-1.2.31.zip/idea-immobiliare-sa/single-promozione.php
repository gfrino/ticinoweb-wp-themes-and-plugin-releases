<?php
/**
 * Scheda di una promozione immobiliare: testata a tutta larghezza con la foto di copertina,
 * testo a sinistra e, a destra, richiesta di informazioni sempre a portata di mano.
 *
 * @package Idea_Immobiliare_SA
 */
get_header();
while (have_posts()) : the_post();
	$has_thumb = has_post_thumbnail();
	$contact   = idea_immo_contact();
?>
<main id="main" class="az az-promo">
	<header class="az-cover<?php echo $has_thumb ? ' has-photo' : ''; ?>">
		<?php if ($has_thumb) : the_post_thumbnail('full', array('alt' => '', 'loading' => 'eager', 'decoding' => 'async', 'class' => 'az-cover__img')); endif; ?>
		<div class="az-cover__shade"></div>
		<div class="idea-container az-cover__inner">
			<?php echo ticinoweb_get_breadcrumbs(); // phpcs:ignore WordPress.Security.EscapeOutput ?>
			<span class="az-hero__lead"><?php esc_html_e('Promozione immobiliare', 'idea-immobiliare-sa'); ?></span>
			<h1><?php the_title(); ?></h1>
		</div>
	</header>

	<section class="idea-section az-body">
		<div class="idea-container az-promo__grid">
			<article class="az-card az-promo__text az-prose"><?php the_content(); ?>
				<?php $gallery = get_post_meta(get_the_ID(), '_idea_gallery', true); $gallery = is_array($gallery) ? array_values(array_filter($gallery, function ($id) { return get_post_type($id) === 'attachment'; })) : array(); ?>
				<?php if ($gallery) : ?>
				<div class="idea-gallery" data-idea-gallery>
					<figure class="idea-gallery__stage">
						<?php echo wp_get_attachment_image($gallery[0], 'large', false, array('class' => 'idea-gallery__img', 'loading' => 'lazy', 'alt' => esc_attr(get_the_title()))); ?>
						<?php if (count($gallery) > 1) : ?>
							<button type="button" class="idea-gallery__nav idea-gallery__nav--prev" aria-label="<?php esc_attr_e('Foto precedente', 'idea-immobiliare-sa'); ?>">‹</button>
							<button type="button" class="idea-gallery__nav idea-gallery__nav--next" aria-label="<?php esc_attr_e('Foto successiva', 'idea-immobiliare-sa'); ?>">›</button>
							<span class="idea-gallery__count"><span data-idea-current>1</span> / <?php echo (int) count($gallery); ?></span>
						<?php endif; ?>
					</figure>
					<?php if (count($gallery) > 1) : ?>
					<ul class="idea-gallery__thumbs">
						<?php foreach ($gallery as $i => $att) : ?>
							<li><button type="button" data-full="<?php echo esc_url(wp_get_attachment_image_url($att, 'large')); ?>"<?php echo $i === 0 ? ' aria-current="true"' : ''; ?> aria-label="<?php echo esc_attr(sprintf(__('Foto %d', 'idea-immobiliare-sa'), $i + 1)); ?>"><img src="<?php echo esc_url(wp_get_attachment_image_url($att, 'thumbnail')); ?>" alt="" loading="lazy" width="150" height="150"></button></li>
						<?php endforeach; ?>
					</ul>
					<?php endif; ?>
				</div>
				<?php endif; ?>
			</article>
			<aside class="az-card az-promo__side">
				<h2><?php esc_html_e('Vuoi saperne di più?', 'idea-immobiliare-sa'); ?></h2>
				<?php if ($contact['phone'] !== '') : ?><p><?php esc_html_e('Chiamaci:', 'idea-immobiliare-sa'); ?> <a class="az-promo__phone" href="<?php echo esc_url(idea_immo_tel_href($contact['phone'])); ?>"><?php echo esc_html($contact['phone']); ?></a></p><?php endif; ?>
				<?php echo idea_immo_contact_form(get_the_title()); // phpcs:ignore WordPress.Security.EscapeOutput ?>
			</aside>
		</div>
		<div class="idea-container az-promo__back"><a href="<?php echo esc_url(get_post_type_archive_link('promozione')); ?>">← <?php esc_html_e('Tutte le promozioni', 'idea-immobiliare-sa'); ?></a></div>
	</section>
</main>
<?php endwhile;
get_footer();
