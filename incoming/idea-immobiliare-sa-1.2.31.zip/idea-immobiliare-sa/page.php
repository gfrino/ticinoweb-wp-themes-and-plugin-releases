<?php
/**
 * Pagine standard (azienda, servizi, mandati, contatti, privacy…): testata con foto in evidenza,
 * ogni titolo H2 del testo diventa un riquadro. Testo, foto in evidenza e foto nel testo si
 * gestiscono dalla pagina. Contatti: il percorso sulla mappa usa l'indirizzo di ticinoWEB CMS.
 *
 * @package Idea_Immobiliare_SA
 */
get_header();
while (have_posts()) : the_post();
	// si divide il testo grezzo (prima dei shortcode), così i titoli H2 interni ai moduli non spezzano i riquadri
	$parts = array();
	foreach (preg_split('/(?=<h2[\s>])|(?=<!-- wp:shortcode -->\s*\[idea_contact_form)/i', get_the_content(), -1, PREG_SPLIT_NO_EMPTY) as $chunk) {
		$lead_plain = stripos(ltrim($chunk), '<h2') !== 0;
		$html = apply_filters('the_content', $chunk);
		$html = preg_replace('~</a>\s*[·•|]\s*(?=<a\b)~u', '</a> ', $html); // niente puntini tra i pulsanti
		$parts[] = $lead_plain && !$parts ? "\x01" . $html : $html;
	}
	$intro  = '';
	$plain  = '';
	if ($parts && $parts[0][0] === "\x01") {
		$first = substr(array_shift($parts), 1);
		// il primo paragrafo va in testata, il resto in un riquadro senza titolo
		if (preg_match('/^\s*(<p[^>]*>.*?<\/p>)(.*)$/is', $first, $m)) {
			$intro = $m[1];
			$plain = trim($m[2]);
		} else {
			$plain = $first;
		}
		if (trim(wp_strip_all_tags($plain)) === '' && stripos($plain, '<img') === false && stripos($plain, '[') === false) {
			$plain = '';
		}
	}
	if ($plain !== '') {
		array_unshift($parts, $plain);
	}
	$has_thumb = has_post_thumbnail();
	$two       = is_page(array('azienda', 'contatti'));
	$contact   = idea_immo_contact();
	$map_q     = trim($contact['address']);
?>
<main id="main" class="az<?php echo $two ? ' az--two' : ''; echo is_page('azienda') ? ' az--azienda' : ''; echo is_page('contatti') ? ' az--contact' : ''; ?>">
	<header class="az-hero<?php echo $has_thumb ? ' has-photo' : ''; ?>">
		<div class="idea-container az-hero__grid">
			<div class="az-hero__copy">
				<?php echo ticinoweb_get_breadcrumbs(); // phpcs:ignore WordPress.Security.EscapeOutput ?>
				<h1><?php the_title(); ?></h1>
				<?php if (has_excerpt()) : ?><p class="az-hero__lead"><?php echo esc_html(get_the_excerpt()); ?></p><?php endif; ?>
				<?php if ($intro) : ?><div class="az-hero__intro"><?php echo $intro; // phpcs:ignore WordPress.Security.EscapeOutput ?></div><?php endif; ?>
			</div>
			<?php if ($has_thumb) : ?>
				<figure class="az-hero__photo"><?php the_post_thumbnail('large', array('alt' => '', 'loading' => 'eager', 'decoding' => 'async')); ?></figure>
			<?php endif; ?>
		</div>
	</header>

	<?php if ($parts) : ?>
	<section class="idea-section az-body">
		<div class="idea-container">
			<?php foreach ($parts as $i => $part) : ?>
				<?php if ($two && $i === 2) : ?><div class="az-rest"><?php endif; ?>
				<article class="az-card az-card--<?php echo (int) $i; ?>"><?php echo $part; // phpcs:ignore WordPress.Security.EscapeOutput ?></article>
			<?php endforeach; ?>
			<?php if ($two && count($parts) > 2) : ?></div><?php endif; ?>
		</div>
	</section>
	<?php endif; ?>

	<?php if (is_page('contatti') && $map_q !== '') : ?>
	<section class="az-map" aria-label="<?php esc_attr_e('Dove siamo', 'idea-immobiliare-sa'); ?>">
		<div class="idea-container">
			<iframe title="<?php esc_attr_e('Mappa Google: dove siamo', 'idea-immobiliare-sa'); ?>" loading="lazy" referrerpolicy="no-referrer-when-downgrade" allowfullscreen
				src="<?php echo esc_url('https://www.google.com/maps?q=' . rawurlencode($map_q) . '&hl=it&z=15&output=embed'); ?>"></iframe>
			<a class="az-map__link" href="<?php echo esc_url('https://www.google.com/maps/search/?api=1&query=' . rawurlencode($map_q)); ?>" target="_blank" rel="noopener"><?php esc_html_e('Apri in Google Maps', 'idea-immobiliare-sa'); ?> <span class="idea-arrow" aria-hidden="true"><?php echo idea_immo_arrow(); // phpcs:ignore WordPress.Security.EscapeOutput ?></span></a>
		</div>
	</section>
	<?php endif; ?>
</main>
<?php endwhile;
get_footer();
