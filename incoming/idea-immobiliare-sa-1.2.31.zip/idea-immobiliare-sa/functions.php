<?php
/**
 * L'Idea Immobiliare SA child theme — functions.
 *
 * Il parent (ticinoweb-ai-theme) fornisce CMS, SEO, FAQ, sicurezza, email e
 * gestore dei form. Qui vivono solo: asset, tipi di contenuto del catalogo
 * immobiliare (immobili, promozioni), ricerca, calcolatore dei costi e i
 * dati strutturati degli annunci.
 *
 * @package Idea_Immobiliare_SA
 */

if (!defined('ABSPATH')) {
    exit;
}

define('IDEA_IMMO_VERSION', wp_get_theme()->get('Version'));

require_once get_stylesheet_directory() . '/inc/post-types.php';
require_once get_stylesheet_directory() . '/inc/property-data.php';
require_once get_stylesheet_directory() . '/inc/admin-property.php';
require_once get_stylesheet_directory() . '/inc/term-order.php';
require_once get_stylesheet_directory() . '/inc/query.php';
require_once get_stylesheet_directory() . '/inc/shortcodes.php';
require_once get_stylesheet_directory() . '/inc/seo-schema.php';
require_once get_stylesheet_directory() . '/inc/legacy-redirects.php';
require_once get_stylesheet_directory() . '/inc/home-new.php';

/* ─────────────────────────────────────────────
   1. SETUP
   ───────────────────────────────────────────── */
add_action('after_setup_theme', 'idea_immo_setup');
function idea_immo_setup()
{
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('html5', array('search-form', 'comment-form', 'gallery', 'caption', 'style', 'script'));

    add_image_size('idea-card', 720, 480, true);
    add_image_size('idea-hero', 1600, 900, true);

    register_nav_menus(array(
        'primary' => __('Menu Principale', 'idea-immobiliare-sa'),
    ));
}

/* ─────────────────────────────────────────────
   2. ASSET
   ───────────────────────────────────────────── */
add_action('wp_enqueue_scripts', 'idea_immo_enqueue_assets', 20);
function idea_immo_enqueue_assets()
{
    $dir = get_stylesheet_directory();
    $uri = get_stylesheet_directory_uri();

    wp_enqueue_style(
        'idea-immo-style',
        $uri . '/assets/css/idea-immobiliare.css',
        array('ticinoweb-ai-style'),
        (string) filemtime($dir . '/assets/css/idea-immobiliare.css')
    );

    wp_enqueue_style('idea-immo-header', $uri . '/assets/css/header.css', array('idea-immo-style'), IDEA_IMMO_VERSION);
    wp_enqueue_style('idea-immo-motion', $uri . '/assets/css/motion.css', array('idea-immo-style'), IDEA_IMMO_VERSION);
    $catalog = is_post_type_archive('immobile') || is_tax(array('zona', 'categoria_immobile'));
    if (is_page() || is_singular(array('promozione', 'immobile')) || $catalog) {
        wp_enqueue_style('idea-immo-pagine', $uri . '/assets/css/pagine.css', array('idea-immo-style'), IDEA_IMMO_VERSION);
    }
    if ($catalog) {
        // stessa ricerca della home: stile e menu a tendina
        wp_enqueue_style('idea-immo-home-new', $uri . '/assets/css/home-new.css', array('idea-immo-style'), IDEA_IMMO_VERSION);
        wp_enqueue_script('idea-immo-home-selects', $uri . '/assets/js/home-selects.js', array(), IDEA_IMMO_VERSION, true);
    }
    wp_enqueue_style('idea-immo-footer', $uri . '/assets/css/footer.css', array('idea-immo-style'), IDEA_IMMO_VERSION);

    wp_enqueue_script(
        'idea-immo-main',
        $uri . '/assets/js/main.js',
        array(),
        (string) filemtime($dir . '/assets/js/main.js'),
        true
    );

    wp_enqueue_script('idea-immo-motion', $uri . '/assets/js/motion.js', array(), IDEA_IMMO_VERSION, true);

    // Il modulo di contatto e il calcolatore si caricano solo dove servono.
    if (is_singular('immobile') || is_page() || is_singular('promozione') || is_singular('post')) {
        wp_enqueue_script(
            'idea-immo-form',
            $uri . '/assets/js/contact-form.js',
            array('ticinoweb-ai-main'),
            (string) filemtime($dir . '/assets/js/contact-form.js'),
            true
        );
    }
}

add_filter('script_loader_tag', 'idea_immo_defer_scripts', 10, 2);
function idea_immo_defer_scripts($tag, $handle)
{
    if (is_admin() || strpos($handle, 'idea-immo-') !== 0) {
        return $tag;
    }
    if (strpos($tag, ' defer') !== false || strpos($tag, ' async') !== false) {
        return $tag;
    }
    return str_replace(' src=', ' defer src=', $tag);
}

/** Il parent carica il font "Poppins" come dipendenza: il child non lo usa. */
add_filter('style_loader_src', 'idea_immo_drop_unused_parent_font', 10, 2);
function idea_immo_drop_unused_parent_font($src, $handle)
{
    return $handle === 'poppins-font' ? '' : $src;
}

add_action('wp_head', 'idea_immo_head_extras', 1);
function idea_immo_head_extras()
{
    echo '<link rel="preconnect" href="https://fonts.googleapis.com">' . "\n";
    echo '<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>' . "\n";
    echo '<meta name="theme-color" content="#2a445d">' . "\n";
}

/* ─────────────────────────────────────────────
   3. LINGUA / VARIE
   ───────────────────────────────────────────── */
add_filter('language_attributes', 'idea_immo_language_attributes');
function idea_immo_language_attributes($output)
{
    return preg_replace('/lang="it(-[A-Za-z]+)?"/', 'lang="it-CH"', $output);
}

add_filter('body_class', 'idea_immo_body_class');
function idea_immo_body_class($classes)
{
    $classes[] = 'idea-body';
    return $classes;
}

add_filter('excerpt_length', function () {
    return 28;
}, 99);
add_filter('excerpt_more', '__return_empty_string');

/**
 * Dati di contatto del sito: sempre dal ticinoWEB CMS (Input First).
 */
function idea_immo_contact()
{
    $phone = (string) get_option('ticinoweb_contact_phone_display', '');
    if ($phone === '') {
        $phone = (string) (get_option('ticinoweb_contact_phone_landline') ?: get_option('ticinoweb_contact_phone'));
    }
    return array(
        'phone'   => $phone,
        'email'   => (string) get_option('ticinoweb_contact_email', ''),
        'address' => (string) get_option('ticinoweb_contact_address', ''),
        'hours'   => (string) get_option('ticinoweb_contact_opening_hours_note', ''),
    );
}

function idea_immo_tel_href($phone)
{
    return 'tel:' . preg_replace('/[^\d+]/', '', (string) $phone);
}

/** Logo del CMS del parent, con fallback sul marchio del tema. */
function idea_immo_logo_url($variant = 'dark')
{
    $custom = function_exists('ticinoweb_get_site_logo') ? ticinoweb_get_site_logo() : (string) get_option('ticinoweb_site_logo', '');
    if ($custom !== '') {
        return $custom;
    }
    $file = 'logo.png';
    return get_stylesheet_directory_uri() . '/assets/img/' . $file;
}

/** Categorie in evidenza nella home (icone SVG inline, nessuna immagine esterna). */
function idea_immo_category_icon($slug)
{
    $icons = array(
        'appartamenti'  => '<path d="M4 21V5a1 1 0 0 1 1-1h9a1 1 0 0 1 1 1v16M15 9h4a1 1 0 0 1 1 1v11M8 8h3M8 12h3M8 16h3M2 21h20"/>',
        'case'          => '<path d="M3 11.5 12 4l9 7.5M5 10v10h14V10M10 20v-6h4v6"/>',
        'ville'         => '<path d="M2 12.5 8 8l4 3 4-3 6 4.5M4 11v9h16v-9M9 20v-5h6v5"/>',
        'locali-commerciali' => '<path d="M4 9 5.5 4h13L20 9M4 9h16M4 9v11h16V9M9 20v-6h6v6"/>',
        'attici'        => '<path d="M3 21h18M5 21V11l7-6 7 6v10M9 21v-5h6v5M3 11l9-8 9 8"/>',
        'terreni'       => '<path d="M3 20 9 8l4 7 3-4 5 9zM3 20h18"/>',
        'rustici'       => '<path d="M3 20h18M5 20V11l7-7 7 7v9M9 20v-5h6v5M12 4v3"/>',
    );
    $path = isset($icons[$slug]) ? $icons[$slug] : '<path d="M3 11.5 12 4l9 7.5M5 10v10h14V10"/>';
    return '<svg width="44" height="44" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . $path . '</svg>';
}


/** Freccia di collegamento wireframe (SVG a tratto): al posto del carattere ↗, che su iPhone diventa un'emoji. */
function idea_immo_arrow()
{
    return '<svg class="idea-arrow__svg" viewBox="0 0 24 24" width="1em" height="1em" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" focusable="false"><path d="M7 17 17 7"/><path d="M8.5 7H17v8.5"/></svg>';
}
