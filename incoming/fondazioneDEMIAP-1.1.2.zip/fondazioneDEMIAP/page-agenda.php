<?php
/**
 * Template Name: Agenda basato rigorosamente sulla struttura Tailwind fornita.
 */

get_header();
?>
<!-- Agenda / Events Section (Design Scuro dal Template) -->
<section class="bg-white text-gray-900 py-24 relative bg-[radial-gradient(#e5e7eb_1px,transparent_1px)] [background-size:20px_20px] hero-highlight group/hero" id="agenda">
    <!-- Hero Highlight Layer (Interactive) -->
    <div class="absolute inset-0 z-0 bg-[radial-gradient(#1877F2_1.5px,transparent_1.5px)] [background-size:20px_20px] pointer-events-none opacity-0 group-hover/hero:opacity-15 transition-opacity duration-500"
         style="mask-image: radial-gradient(300px circle at var(--mouse-x, 0px) var(--mouse-y, 0px), black 0%, transparent 100%); -webkit-mask-image: radial-gradient(300px circle at var(--mouse-x, 0px) var(--mouse-y, 0px), black 0%, transparent 100%);">
    </div>
    <!-- Decorazione Sfondo Vettoriale (Sottile ma visibile) -->

    <div class="container mx-auto px-6 md:px-12 relative z-10">
        <div class="mb-16 max-w-4xl mx-auto text-left">
            <h1 class="font-serif text-2xl md:text-4xl tracking-widest uppercase mb-6 text-brand-red text-left magic-title">Agenda &amp; Info Point</h1>
            <p class="text-sm md:text-base font-light leading-relaxed text-gray-600">
                In questa sezione avete la possibilità di consultare l’agenda sempre aggiornata, che raccoglie tutte le attività organizzate dalla Fondazione DEMIAP, insieme a una pagina dedicata alle ultime novità e comunicazioni. Subito dopo, vi attende una panoramica completa delle nostre iniziative: ogni attività proposta viene descritta in modo approfondito, per permettervi di coglierne sia lo spirito sia le opportunità concrete. Che sia un incontro, un evento o un progetto di sostegno, troverete tutte le informazioni necessarie per partecipare e sentirvi parte attiva della nostra Fondazione.
            </p>
        </div>

        <div class="demiap-agenda" id="notizie">
            <!-- Calendario Google della Fondazione -->
            <div class="demiap-agenda__calendar">
                <h3 class="demiap-agenda__title"><span class="material-symbols-outlined" aria-hidden="true">calendar_month</span> Calendario eventi</h3>
                <div class="demiap-agenda__frame">
                    <iframe src="https://calendar.google.com/calendar/embed?src=urtiriconciliazione%40gmail.com&amp;ctz=Europe%2FZurich&amp;hl=it" title="Calendario eventi della Fondazione DEMIAP" loading="lazy"></iframe>
                </div>
                <p class="demiap-agenda__fallback"><a href="https://calendar.google.com/calendar/embed?src=urtiriconciliazione%40gmail.com&amp;ctz=Europe%2FZurich&amp;hl=it" target="_blank" rel="noopener">Apri il calendario in una nuova finestra</a></p>
            </div>

            <!-- Bacheca Info Point: le 5 comunicazioni in evidenza -->
            <div class="demiap-agenda__board" id="bacheca">
                <h3 class="demiap-agenda__title"><span class="material-symbols-outlined" aria-hidden="true">campaign</span> Bacheca Info Point</h3>
                <?php demiap_bacheca_render_previews('agenda'); ?>
            </div>
        </div>
    </div>
</section>

<?php get_footer(); ?>
