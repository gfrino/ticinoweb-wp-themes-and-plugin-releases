<?php
/**
 * Scheda di un immobile nel catalogo.
 *
 * @package Idea_Immobiliare_SA
 */
$pid      = get_the_ID();
$location = idea_immo_location($pid);
$status   = idea_immo_status($pid);
$cat      = idea_immo_term_name('categoria_immobile', $pid);
$details  = idea_immo_details($pid, true);
$badge    = '';
if ($status === 'riservato') {
	$badge = __('Riservato', 'idea-immobiliare-sa');
} elseif ($status === 'archivio') {
	$badge = __('Non più disponibile', 'idea-immobiliare-sa');
} elseif (idea_immo_offer($pid) === 'affitto') {
	$badge = __('In affitto', 'idea-immobiliare-sa');
}
?>
<article <?php post_class('idea-card'); ?>>
	<a class="idea-card__media" href="<?php the_permalink(); ?>" tabindex="-1" aria-hidden="true">
		<?php if (has_post_thumbnail()) : ?>
			<?php the_post_thumbnail('idea-card', array('loading' => 'lazy', 'alt' => '')); ?>
		<?php else : ?>
			<span class="idea-card__placeholder"><?php echo idea_immo_category_icon('case'); ?></span>
		<?php endif; ?>
		<?php if ($badge !== '') : ?><span class="idea-card__badge"><?php echo esc_html($badge); ?></span><?php endif; ?>
	</a>
	<div class="idea-card__body">
		<p class="idea-card__meta">
			<?php if ($location !== '') : ?><span><?php echo esc_html($location); ?></span><?php endif; ?>
			<?php if ($cat !== '') : ?><span><?php echo esc_html($cat); ?></span><?php endif; ?>
		</p>
		<h3 class="idea-card__title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
		<?php if ($details) : ?>
			<ul class="idea-card__facts">
				<?php foreach ($details as $row) : ?>
					<li><span><?php echo esc_html($row[0]); ?></span> <strong><?php echo esc_html($row[1]); ?></strong></li>
				<?php endforeach; ?>
			</ul>
		<?php endif; ?>
		<p class="idea-card__price"><?php echo esc_html(idea_immo_price_label($pid)); ?></p>
	</div>
</article>
