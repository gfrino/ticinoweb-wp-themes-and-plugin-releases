<?php
/**
 * ticinoWEB CMS catalogue editor.
 *
 * @package GluteLabChildTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action( 'admin_init', 'glutelab_register_package_settings' );
add_action( 'admin_enqueue_scripts', 'glutelab_packages_admin_assets' );
add_filter( 'option_page_capability_glutelab_catalog_group', 'glutelab_packages_settings_capability' );

function glutelab_packages_settings_capability() {
	return 'edit_pages';
}

function glutelab_register_package_settings() {
	register_setting(
		'glutelab_catalog_group',
		'glutelab_catalog',
		array(
			'type'              => 'array',
			'sanitize_callback' => 'glutelab_sanitize_catalog_option',
			'default'           => array(),
			'show_in_rest'      => false,
		)
	);
}

/** Load catalogue assets only when its tab is open inside Gestione Glute Lab. */
function glutelab_packages_admin_assets( $hook ) {
	$is_packages_tab = $hook === ( $GLOBALS['glutelab_app_admin_hook'] ?? '' )
		&& 'glutelab-operations' === sanitize_key( $_GET['page'] ?? '' )
		&& 'packages' === sanitize_key( $_GET['view'] ?? '' );
	if ( ! $is_packages_tab ) {
		return;
	}

	$css_path    = get_stylesheet_directory() . '/assets/css/admin-packages.css';
	$script_path = get_stylesheet_directory() . '/assets/js/admin-packages.js';
	$css_version = file_exists( $css_path ) ? filemtime( $css_path ) : GLUTELAB_THEME_VERSION;
	$js_version  = file_exists( $script_path ) ? filemtime( $script_path ) : GLUTELAB_THEME_VERSION;

	wp_enqueue_media();
	wp_enqueue_style( 'glutelab-admin-packages', get_stylesheet_directory_uri() . '/assets/css/admin-packages.css', array(), $css_version );
	wp_enqueue_script( 'glutelab-admin-packages', get_stylesheet_directory_uri() . '/assets/js/admin-packages.js', array(), $js_version, false );
}

function glutelab_admin_url( $args = array() ) {
	if ( isset( $args['view'] ) ) {
		$args['catalog_view'] = $args['view'];
		unset( $args['view'] );
	}
	return add_query_arg( $args, admin_url( 'admin.php?page=glutelab-operations&view=packages' ) );
}

function glutelab_admin_request_key( $key, $default = '' ) {
	return isset( $_GET[ $key ] ) ? sanitize_key( wp_unslash( $_GET[ $key ] ) ) : $default;
}

function glutelab_admin_mode_label( $mode ) {
	return glutelab_mode_label( $mode );
}

function glutelab_admin_mode_short_label( $mode ) {
	$labels = array(
		'individual' => __( 'Individuale', 'glutelab-child-theme' ),
		'group'      => __( 'Gruppo', 'glutelab-child-theme' ),
		'integrated' => __( 'Integrato', 'glutelab-child-theme' ),
		'digital'    => __( 'Digitale', 'glutelab-child-theme' ),
	);
	return $labels[ $mode ] ?? ucfirst( $mode );
}

/** Render a labelled admin field with inline validation feedback. */
function glutelab_admin_field( $scope, $name, $label, $value, $type = 'text', $help = '', $attrs = '', $wrapper_attrs = '' ) {
	$id    = 'gl-' . sanitize_key( $scope . '-' . $name );
	$field = 'glutelab_catalog[' . $scope . '][' . $name . ']';
	?>
	<div class="gl-admin-field gl-admin-field--<?php echo esc_attr( $type ); ?>" <?php echo $wrapper_attrs; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?> >
		<label for="<?php echo esc_attr( $id ); ?>"><?php echo esc_html( $label ); ?></label>
		<?php if ( 'textarea' === $type ) : ?>
			<textarea id="<?php echo esc_attr( $id ); ?>" name="<?php echo esc_attr( $field ); ?>" rows="4" data-gl-field="<?php echo esc_attr( $name ); ?>" <?php echo $attrs; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>><?php echo esc_textarea( $value ); ?></textarea>
		<?php else : ?>
			<input id="<?php echo esc_attr( $id ); ?>" name="<?php echo esc_attr( $field ); ?>" type="<?php echo esc_attr( $type ); ?>" value="<?php echo esc_attr( null === $value ? '' : $value ); ?>" data-gl-field="<?php echo esc_attr( $name ); ?>" <?php echo $attrs; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>>
		<?php endif; ?>
		<?php if ( $help ) : ?><p class="description"><?php echo esc_html( $help ); ?></p><?php endif; ?>
		<p class="gl-admin-field__error" role="alert" hidden></p>
	</div>
	<?php
}

function glutelab_admin_select( $scope, $name, $label, $value, $options, $help = '', $wrapper_attrs = '' ) {
	$id = 'gl-' . sanitize_key( $scope . '-' . $name );
	?>
	<div class="gl-admin-field" <?php echo $wrapper_attrs; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?> >
		<label for="<?php echo esc_attr( $id ); ?>"><?php echo esc_html( $label ); ?></label>
		<select id="<?php echo esc_attr( $id ); ?>" name="glutelab_catalog[<?php echo esc_attr( $scope ); ?>][<?php echo esc_attr( $name ); ?>]" data-gl-field="<?php echo esc_attr( $name ); ?>">
			<?php foreach ( $options as $key => $text ) : ?>
				<option value="<?php echo esc_attr( $key ); ?>" <?php selected( $value, $key ); ?>><?php echo esc_html( $text ); ?></option>
			<?php endforeach; ?>
		</select>
		<?php if ( $help ) : ?><p class="description"><?php echo esc_html( $help ); ?></p><?php endif; ?>
		<p class="gl-admin-field__error" role="alert" hidden></p>
	</div>
	<?php
}

function glutelab_admin_checkbox( $scope, $name, $label, $checked ) {
	?>
	<label class="gl-admin__check">
		<input type="checkbox" name="glutelab_catalog[<?php echo esc_attr( $scope ); ?>][<?php echo esc_attr( $name ); ?>]" value="1" <?php checked( $checked, 1 ); ?>>
		<span><?php echo esc_html( $label ); ?></span>
	</label>
	<?php
}

function glutelab_admin_status( $status ) {
	$active = 'active' === $status;
	?>
	<span class="gl-admin__status gl-admin__status--<?php echo esc_attr( $active ? 'active' : 'inactive' ); ?>">
		<span aria-hidden="true"></span><?php echo esc_html( $active ? __( 'Attivo', 'glutelab-child-theme' ) : __( 'Disattivato', 'glutelab-child-theme' ) ); ?>
	</span>
	<?php
}

/** Return the concise lesson facts needed while scanning the offer list. */
function glutelab_admin_offer_facts( $package ) {
	$facts = array();
	$total = glutelab_calculate_total_lessons( $package['lessons_purchased'] ?? null, $package['bonus_lessons'] ?? null );
	if ( null !== $total ) {
		$facts[] = sprintf( _n( '%d lezione', '%d lezioni', $total, 'glutelab-child-theme' ), $total );
	}
	if ( ! empty( $package['session_minutes'] ) ) {
		$facts[] = sprintf( __( '%d min ciascuna', 'glutelab-child-theme' ), (int) $package['session_minutes'] );
	}
	return implode( ' · ', $facts );
}

/** Render the package-to-course selector with the inherited operational data. */
function glutelab_admin_course_select( $package, $groups ) {
	?>
	<div class="gl-admin-field">
		<label for="gl-package-group-id"><?php esc_html_e( 'Corso', 'glutelab-child-theme' ); ?></label>
		<select id="gl-package-group-id" name="glutelab_catalog[package][group_id]" data-gl-field="group_id">
			<?php foreach ( $groups as $group ) : ?>
				<option value="<?php echo esc_attr( $group['id'] ); ?>" data-gl-mode="<?php echo esc_attr( $group['mode'] ); ?>" data-gl-participants="<?php echo esc_attr( null === $group['max_participants'] ? '' : $group['max_participants'] ); ?>" <?php selected( $package['group_id'], $group['id'] ); ?>><?php echo esc_html( $group['title'] ); ?></option>
			<?php endforeach; ?>
		</select>
		<p class="description"><?php esc_html_e( 'Tipologia e partecipanti vengono ereditati dal corso.', 'glutelab-child-theme' ); ?></p>
	</div>
	<?php
}

function glutelab_admin_section_heading( $title, $description = '' ) {
	?>
	<header class="gl-admin__section-heading">
		<h3><?php echo esc_html( $title ); ?></h3>
		<?php if ( $description ) : ?><p><?php echo esc_html( $description ); ?></p><?php endif; ?>
	</header>
	<?php
}

function glutelab_admin_media_field( $image_id ) {
	$image_id = absint( $image_id );
	$image    = $image_id ? wp_get_attachment_image( $image_id, 'medium', false, array( 'class' => 'gl-admin__media-image' ) ) : '';
	?>
	<div class="gl-admin__media" data-gl-media>
		<div class="gl-admin__media-preview<?php echo $image ? '' : ' is-empty'; ?>" data-gl-media-preview>
			<?php if ( $image ) : ?>
				<?php echo $image; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			<?php else : ?>
				<span><?php esc_html_e( 'Nessuna immagine selezionata', 'glutelab-child-theme' ); ?></span>
			<?php endif; ?>
		</div>
		<div class="gl-admin__media-actions">
			<input type="hidden" name="glutelab_catalog[group][image_id]" value="<?php echo esc_attr( $image_id ); ?>" data-gl-media-id>
			<button type="button" class="button" data-gl-media-select><?php esc_html_e( 'Scegli immagine', 'glutelab-child-theme' ); ?></button>
			<button type="button" class="button-link-delete" data-gl-media-remove <?php echo $image ? '' : 'hidden'; ?>><?php esc_html_e( 'Rimuovi', 'glutelab-child-theme' ); ?></button>
		</div>
		<p class="description"><?php esc_html_e( 'Usa un’immagine dalla Libreria Media. L’ID viene conservato automaticamente.', 'glutelab-child-theme' ); ?></p>
	</div>
	<?php
}

function glutelab_admin_save_bar( $button_label, $action, $summary ) {
	$saved = isset( $_GET['settings-updated'] ) && 'true' === sanitize_key( wp_unslash( $_GET['settings-updated'] ) );
	?>
	<div class="gl-admin__save" data-gl-save-bar>
		<div class="gl-admin__save-state">
			<strong role="status" aria-live="polite" data-gl-save-state><?php echo esc_html( $saved ? __( 'Salvataggio completato', 'glutelab-child-theme' ) : __( 'Nessuna modifica da salvare', 'glutelab-child-theme' ) ); ?></strong>
			<span><?php echo esc_html( $summary ); ?></span>
		</div>
		<button class="button button-primary" name="glutelab_catalog[action]" value="<?php echo esc_attr( $action ); ?>" data-gl-save-button><?php echo esc_html( $button_label ); ?></button>
	</div>
	<?php
}

function glutelab_admin_sidebar( $groups, $view, $selected_group ) {
	$active_count = count( glutelab_get_packages() );
	?>
	<nav class="gl-admin__list" aria-label="<?php esc_attr_e( 'Sezioni del catalogo', 'glutelab-child-theme' ); ?>">
		<a class="gl-admin__item<?php echo 'overview' === $view ? ' is-current' : ''; ?>" href="<?php echo esc_url( glutelab_admin_url() ); ?>"<?php echo 'overview' === $view ? ' aria-current="page"' : ''; ?>>
			<span><strong><?php esc_html_e( 'Panoramica', 'glutelab-child-theme' ); ?></strong><small><?php echo esc_html( sprintf( '%d corsi · %d offerte', count( $groups ), $active_count ) ); ?></small></span>
		</a>
		<?php foreach ( $groups as $group ) : $is_current = in_array( $view, array( 'group', 'package' ), true ) && $selected_group === $group['id']; ?>
			<a class="gl-admin__item<?php echo $is_current ? ' is-current' : ''; ?>" href="<?php echo esc_url( glutelab_admin_url( array( 'view' => 'group', 'group' => $group['id'] ) ) ); ?>"<?php echo $is_current ? ' aria-current="page"' : ''; ?>>
				<span><strong><?php echo esc_html( $group['title'] ); ?></strong><small><?php echo esc_html( glutelab_admin_mode_short_label( $group['mode'] ) ); ?></small></span>
				<?php glutelab_admin_status( $group['status'] ); ?>
			</a>
		<?php endforeach; ?>
		<a class="gl-admin__item<?php echo 'general' === $view ? ' is-current' : ''; ?>" href="<?php echo esc_url( glutelab_admin_url( array( 'view' => 'general' ) ) ); ?>"<?php echo 'general' === $view ? ' aria-current="page"' : ''; ?>>
			<span><strong><?php esc_html_e( 'Impostazioni generali', 'glutelab-child-theme' ); ?></strong><small><?php esc_html_e( 'Titoli e CTA', 'glutelab-child-theme' ); ?></small></span>
		</a>
	</nav>
	<?php
}

function glutelab_admin_overview( $catalog, $groups ) {
	$packages = glutelab_get_packages( true );
	$active   = array_filter( $packages, static fn( $package ) => 'active' === $package['status'] );
	$inactive = array_filter( $packages, static fn( $package ) => 'inactive' === $package['status'] );
	?>
	<section class="gl-admin__editor gl-admin__overview">
		<header class="gl-admin__editor-head">
			<div><span><?php esc_html_e( 'Panoramica', 'glutelab-child-theme' ); ?></span><h2><?php esc_html_e( 'Corsi e offerte', 'glutelab-child-theme' ); ?></h2></div>
			<strong class="gl-admin__headline-status"><?php echo esc_html( sprintf( __( '%d offerte attive', 'glutelab-child-theme' ), count( $active ) ) ); ?></strong>
		</header>
		<div class="gl-admin__route-list">
			<?php foreach ( $groups as $group ) : $offers = glutelab_get_packages_by_group( $group['id'], true ); ?>
				<article class="gl-admin__route-card">
					<div class="gl-admin__route-copy">
						<div class="gl-admin__route-meta"><span class="gl-admin__mode-tag"><?php echo esc_html( glutelab_admin_mode_short_label( $group['mode'] ) ); ?></span><?php glutelab_admin_status( $group['status'] ); ?></div>
						<h3><?php echo esc_html( $group['title'] ); ?></h3>
						<p><?php echo esc_html( $group['description'] ); ?></p>
					</div>
					<ul class="gl-admin__offer-summary">
						<?php foreach ( $offers as $offer ) : ?>
							<li><span><?php echo esc_html( $offer['title'] ); ?></span><strong><?php echo esc_html( glutelab_package_price_text( $offer ) ); ?></strong></li>
						<?php endforeach; ?>
					</ul>
					<footer><a class="button" href="<?php echo esc_url( glutelab_admin_url( array( 'view' => 'group', 'group' => $group['id'] ) ) ); ?>"><?php esc_html_e( 'Gestisci corso', 'glutelab-child-theme' ); ?></a></footer>
				</article>
			<?php endforeach; ?>
		</div>
		<?php if ( $inactive ) : ?><div class="notice notice-warning inline"><p><?php echo esc_html( sprintf( __( '%d offerte sono disattivate e non compaiono sul sito.', 'glutelab-child-theme' ), count( $inactive ) ) ); ?></p></div><?php endif; ?>
	</section>
	<?php
}

function glutelab_admin_group_editor( $group, $groups ) {
	$packages = glutelab_get_packages_by_group( $group['id'], true );
	?>
	<div class="gl-admin__editor-stack">
		<form action="options.php" method="post" class="gl-admin__editor" data-gl-form data-gl-group-form>
			<?php settings_fields( 'glutelab_catalog_group' ); ?>
			<input type="hidden" name="glutelab_catalog[group][id]" value="<?php echo esc_attr( $group['id'] ); ?>">
			<header class="gl-admin__editor-head">
				<div><span><?php echo esc_html( sprintf( __( 'Corso · %s', 'glutelab-child-theme' ), glutelab_admin_mode_short_label( $group['mode'] ) ) ); ?></span><h2><?php echo esc_html( $group['title'] ); ?></h2></div>
				<?php glutelab_admin_status( $group['status'] ); ?>
			</header>
			<section class="gl-admin__section">
				<?php glutelab_admin_section_heading( __( 'Informazioni del corso', 'glutelab-child-theme' ), __( 'Nome e descrizione mostrati nel sito.', 'glutelab-child-theme' ) ); ?>
				<?php glutelab_admin_field( 'group', 'title', __( 'Nome del corso', 'glutelab-child-theme' ), $group['title'], 'text', '', 'required maxlength="120"' ); ?>
				<?php glutelab_admin_field( 'group', 'description', __( 'Descrizione breve', 'glutelab-child-theme' ), $group['description'], 'textarea' ); ?>
			</section>
			<section class="gl-admin__section">
				<?php glutelab_admin_section_heading( __( 'Tipologia e visibilità', 'glutelab-child-theme' ), __( 'I soli dati necessari per organizzare il corso.', 'glutelab-child-theme' ) ); ?>
				<div class="gl-admin__columns">
					<?php glutelab_admin_select( 'group', 'mode', __( 'Tipologia', 'glutelab-child-theme' ), $group['mode'], array( 'individual' => __( 'Individuale', 'glutelab-child-theme' ), 'group' => __( 'Gruppo', 'glutelab-child-theme' ), 'integrated' => __( 'Integrato', 'glutelab-child-theme' ), 'digital' => __( 'Digitale', 'glutelab-child-theme' ) ) ); ?>
					<?php glutelab_admin_select( 'group', 'status', __( 'Stato', 'glutelab-child-theme' ), $group['status'], array( 'active' => __( 'Attivo', 'glutelab-child-theme' ), 'inactive' => __( 'Disattivato', 'glutelab-child-theme' ) ) ); ?>
				</div>
				<?php glutelab_admin_field( 'group', 'max_participants', __( 'Partecipanti massimi', 'glutelab-child-theme' ), $group['max_participants'], 'number', __( 'Per Individuale il valore è 1; per Gruppo indica la capienza massima.', 'glutelab-child-theme' ), 'min="0"', 'data-gl-group-participants' ); ?>
			</section>
			<details class="gl-admin__details"><summary><span><?php esc_html_e( 'Immagine del corso', 'glutelab-child-theme' ); ?></span><small><?php esc_html_e( 'Facoltativa, dalla Libreria Media', 'glutelab-child-theme' ); ?></small></summary><div class="gl-admin__details-body"><?php glutelab_admin_media_field( $group['image_id'] ); ?></div></details>
			<?php glutelab_admin_save_bar( __( 'Salva corso', 'glutelab-child-theme' ), 'save_group', __( 'Nome, tipologia e visibilità del corso.', 'glutelab-child-theme' ) ); ?>
		</form>

		<section class="gl-admin__editor gl-admin__offers">
			<header class="gl-admin__editor-head">
				<div><span><?php esc_html_e( 'Pacchetti del corso', 'glutelab-child-theme' ); ?></span><h2><?php echo esc_html( sprintf( _n( '%d offerta', '%d offerte', count( $packages ), 'glutelab-child-theme' ), count( $packages ) ) ); ?></h2></div>
				<a class="button button-primary" href="<?php echo esc_url( glutelab_admin_url( array( 'view' => 'package', 'group' => $group['id'], 'package' => 'new' ) ) ); ?>"><?php esc_html_e( 'Aggiungi offerta', 'glutelab-child-theme' ); ?></a>
			</header>
			<ol class="gl-admin__sortable gl-admin__offer-list">
				<?php foreach ( $packages as $index => $package ) : ?>
					<li>
						<div class="gl-admin__offer-name"><strong><?php echo esc_html( $package['title'] ); ?></strong><small><?php echo esc_html( glutelab_admin_offer_facts( $package ) ?: __( 'Dettagli da completare', 'glutelab-child-theme' ) ); ?></small></div>
						<strong class="gl-admin__offer-price"><?php echo esc_html( glutelab_package_price_text( $package ) ); ?></strong>
						<?php glutelab_admin_status( $package['status'] ); ?>
						<a class="button" href="<?php echo esc_url( glutelab_admin_url( array( 'view' => 'package', 'group' => $group['id'], 'package' => $package['id'] ) ) ); ?>"><?php esc_html_e( 'Modifica', 'glutelab-child-theme' ); ?></a>
					</li>
				<?php endforeach; ?>
			</ol>
		</section>

		<details class="gl-admin__editor gl-admin__danger">
			<summary><?php esc_html_e( 'Zona pericolosa: elimina corso', 'glutelab-child-theme' ); ?></summary>
			<form action="options.php" method="post" class="gl-admin__details-body">
				<?php settings_fields( 'glutelab_catalog_group' ); ?><input type="hidden" name="glutelab_catalog[group_id]" value="<?php echo esc_attr( $group['id'] ); ?>">
				<p><?php esc_html_e( 'Se contiene offerte attive, conferma l’operazione e scegli un corso alternativo.', 'glutelab-child-theme' ); ?></p>
				<label class="gl-admin-field"><?php esc_html_e( 'Destinazione offerte', 'glutelab-child-theme' ); ?><select name="glutelab_catalog[destination_group]"><option value=""><?php esc_html_e( '— Nessuna —', 'glutelab-child-theme' ); ?></option><?php foreach ( $groups as $destination ) if ( $destination['id'] !== $group['id'] ) : ?><option value="<?php echo esc_attr( $destination['id'] ); ?>"><?php echo esc_html( $destination['title'] ); ?></option><?php endif; ?></select></label>
				<label class="gl-admin__check"><input type="checkbox" name="glutelab_catalog[confirm_delete]" value="1" required><span><?php esc_html_e( 'Confermo l’eliminazione del corso.', 'glutelab-child-theme' ); ?></span></label>
				<button class="button gl-admin__delete" name="glutelab_catalog[action]" value="delete_group"><?php esc_html_e( 'Elimina corso', 'glutelab-child-theme' ); ?></button>
			</form>
		</details>
	</div>
	<?php
}

function glutelab_admin_package_editor( $package, $groups, $is_new ) {
	$group_options = array_column( $groups, 'title', 'id' );
	$total_lessons = glutelab_calculate_total_lessons( $package['lessons_purchased'], $package['bonus_lessons'] );
	?>
	<div class="gl-admin__editor-stack">
	<form action="options.php" method="post" class="gl-admin__editor" data-gl-form data-gl-package-form>
		<?php settings_fields( 'glutelab_catalog_group' ); ?><input type="hidden" name="glutelab_catalog[package][id]" value="<?php echo esc_attr( $is_new ? '' : $package['id'] ); ?>">
		<input type="hidden" name="glutelab_catalog[package][sort_order]" value="<?php echo esc_attr( $package['sort_order'] ); ?>">
		<header class="gl-admin__editor-head">
			<div><span><?php echo esc_html( $is_new ? __( 'Nuova offerta', 'glutelab-child-theme' ) : $group_options[ $package['group_id'] ] ); ?></span><h2 data-gl-title-preview><?php echo esc_html( $package['title'] ?: __( 'Senza titolo', 'glutelab-child-theme' ) ); ?></h2></div>
			<div class="gl-admin__editor-meta"><strong data-gl-price-preview><?php echo esc_html( glutelab_package_price_text( $package ) ); ?></strong><?php glutelab_admin_status( $package['status'] ); ?></div>
		</header>
		<section class="gl-admin__section">
			<?php glutelab_admin_section_heading( __( 'Informazioni essenziali', 'glutelab-child-theme' ), __( 'I dati che servono per riconoscere e proporre l’offerta.', 'glutelab-child-theme' ) ); ?>
			<?php glutelab_admin_field( 'package', 'title', __( 'Nome dell’offerta', 'glutelab-child-theme' ), $package['title'], 'text', '', 'required maxlength="120"' ); ?>
			<div class="gl-admin__columns"><?php glutelab_admin_course_select( $package, $groups ); ?><?php glutelab_admin_select( 'package', 'status', __( 'Visibilità', 'glutelab-child-theme' ), $package['status'], array( 'active' => __( 'Attiva sul sito', 'glutelab-child-theme' ), 'inactive' => __( 'Nascosta', 'glutelab-child-theme' ) ) ); ?></div>
			<?php glutelab_admin_field( 'package', 'description', __( 'Descrizione breve', 'glutelab-child-theme' ), $package['description'], 'textarea' ); ?>
		</section>
		<section class="gl-admin__section">
			<?php glutelab_admin_section_heading( __( 'Lezioni e prezzo', 'glutelab-child-theme' ), __( 'Quante lezioni comprende, quanto dura ogni incontro e quanto costa.', 'glutelab-child-theme' ) ); ?>
			<div class="gl-admin__columns"><?php glutelab_admin_field( 'package', 'price', __( 'Prezzo CHF', 'glutelab-child-theme' ), $package['price'], 'text', '', 'required inputmode="decimal"' ); ?><?php glutelab_admin_select( 'package', 'price_model', __( 'Tipo di prezzo', 'glutelab-child-theme' ), $package['price_model'], array( 'one_time' => __( 'Totale una tantum', 'glutelab-child-theme' ), 'display_monthly' => __( 'Prezzo al mese', 'glutelab-child-theme' ) ), __( 'Il testo “/mese” viene aggiunto automaticamente.', 'glutelab-child-theme' ) ); ?></div>
			<div class="gl-admin__columns" data-gl-section="training"><?php glutelab_admin_field( 'package', 'total_lessons', __( 'Lezioni incluse', 'glutelab-child-theme' ), $total_lessons, 'number', __( 'Numero totale di lezioni comprese nel pacchetto.', 'glutelab-child-theme' ), 'min="0"' ); ?><?php glutelab_admin_field( 'package', 'session_minutes', __( 'Durata della singola lezione (minuti)', 'glutelab-child-theme' ), $package['session_minutes'], 'number', __( 'Questo valore genera automaticamente gli orari: 60 minuti crea intervalli di un’ora, 30 minuti intervalli di mezz’ora.', 'glutelab-child-theme' ), 'min="5" max="240" step="5"' ); ?></div>
		</section>
		<details class="gl-admin__details"><summary><span><?php esc_html_e( 'Cosa include', 'glutelab-child-theme' ); ?></span><small><?php esc_html_e( 'Solo se il pacchetto comprende servizi aggiuntivi', 'glutelab-child-theme' ); ?></small></summary><div class="gl-admin__details-body">
			<?php glutelab_admin_field( 'package', 'gym_months', __( 'Mesi palestra ASCO Fit', 'glutelab-child-theme' ), $package['gym_months'], 'number', '', 'min="0"' ); ?>
			<div class="gl-admin__check-grid"><?php glutelab_admin_checkbox( 'package', 'includes_nutrition_app', __( 'App ASCO Fit Nutrition', 'glutelab-child-theme' ), $package['includes_nutrition_app'] ); ?><?php glutelab_admin_checkbox( 'package', 'includes_bmi_monitoring', __( 'Monitoraggio BMI', 'glutelab-child-theme' ), $package['includes_bmi_monitoring'] ); ?><?php glutelab_admin_checkbox( 'package', 'includes_progress_monitoring', __( 'Monitoraggio progressi', 'glutelab-child-theme' ), $package['includes_progress_monitoring'] ); ?></div>
			<?php glutelab_admin_field( 'package', 'benefits', __( 'Altre inclusioni', 'glutelab-child-theme' ), implode( "\n", $package['benefits'] ), 'textarea', __( 'Una per riga.', 'glutelab-child-theme' ) ); ?>
		</div></details>
		<details class="gl-admin__details"><summary><span><?php esc_html_e( 'Dettagli facoltativi', 'glutelab-child-theme' ); ?></span><small><?php esc_html_e( 'Frequenza, durata complessiva e validità', 'glutelab-child-theme' ); ?></small></summary><div class="gl-admin__details-body">
			<div class="gl-admin__columns"><?php glutelab_admin_field( 'package', 'frequency', __( 'Frequenza consigliata', 'glutelab-child-theme' ), $package['frequency'] ); ?><?php glutelab_admin_field( 'package', 'total_duration', __( 'Durata complessiva del percorso', 'glutelab-child-theme' ), $package['total_duration'] ); ?></div>
			<?php glutelab_admin_field( 'package', 'validity', __( 'Validità o scadenza', 'glutelab-child-theme' ), $package['validity'], 'text', __( 'Compila soltanto se è stata definita.', 'glutelab-child-theme' ) ); ?>
			<?php glutelab_admin_field( 'package', 'commercial_notes', __( 'Nota utile al cliente', 'glutelab-child-theme' ), $package['commercial_notes'], 'textarea' ); ?>
		</div></details>
		<details class="gl-admin__details"><summary><span><?php esc_html_e( 'Prenotazione e pagamenti', 'glutelab-child-theme' ); ?></span><small><?php esc_html_e( 'Metodi consentiti per questa offerta', 'glutelab-child-theme' ); ?></small></summary><div class="gl-admin__details-body">
			<p class="description"><?php esc_html_e( 'Mostra soltanto le modalità realmente disponibili e già configurate nella Gestione Glute Lab.', 'glutelab-child-theme' ); ?></p>
			<div class="gl-admin__check-grid gl-admin__check-grid--two"><?php glutelab_admin_checkbox( 'package', 'online_purchase_available', __( 'Predisposizione acquisto online', 'glutelab-child-theme' ), $package['online_purchase_available'] ); ?><?php glutelab_admin_checkbox( 'package', 'payment_in_person_available', __( 'Pagamento in sede', 'glutelab-child-theme' ), $package['payment_in_person_available'] ); ?></div>
		</div></details>
		<?php glutelab_admin_save_bar( __( 'Salva offerta', 'glutelab-child-theme' ), 'save_package', __( 'Nome, lezioni, durata e prezzo.', 'glutelab-child-theme' ) ); ?>
	</form>
	<?php if ( ! $is_new ) : ?>
		<details class="gl-admin__editor gl-admin__danger">
			<summary><span><?php esc_html_e( 'Eliminazione', 'glutelab-child-theme' ); ?></span><small><?php esc_html_e( 'Zona pericolosa', 'glutelab-child-theme' ); ?></small></summary>
			<form action="options.php" method="post" class="gl-admin__details-body">
				<?php settings_fields( 'glutelab_catalog_group' ); ?>
				<p><?php esc_html_e( 'L’offerta verrà rimossa definitivamente dal catalogo.', 'glutelab-child-theme' ); ?></p>
				<label class="gl-admin__check"><input type="checkbox" name="glutelab_catalog[confirm_delete]" value="1" required><span><?php esc_html_e( 'Confermo l’eliminazione definitiva.', 'glutelab-child-theme' ); ?></span></label>
				<input type="hidden" name="glutelab_catalog[package_id]" value="<?php echo esc_attr( $package['id'] ); ?>">
				<button class="button gl-admin__delete" name="glutelab_catalog[action]" value="delete_package"><?php esc_html_e( 'Elimina offerta', 'glutelab-child-theme' ); ?></button>
			</form>
		</details>
	<?php endif; ?>
	</div>
	<?php
}

function glutelab_admin_general_editor( $general ) {
	?>
	<form action="options.php" method="post" class="gl-admin__editor" data-gl-form>
		<?php settings_fields( 'glutelab_catalog_group' ); ?>
		<header class="gl-admin__editor-head"><div><span><?php esc_html_e( 'Sezione pubblica', 'glutelab-child-theme' ); ?></span><h2><?php esc_html_e( 'Impostazioni generali', 'glutelab-child-theme' ); ?></h2></div></header>
		<section class="gl-admin__section"><?php glutelab_admin_section_heading( __( 'Titoli e CTA', 'glutelab-child-theme' ), __( 'Contenuti condivisi tra la Home e la pagina Pacchetti.', 'glutelab-child-theme' ) ); ?><?php glutelab_admin_field( 'general', 'title', __( 'Titolo', 'glutelab-child-theme' ), $general['title'], 'text', '', 'required' ); ?><?php glutelab_admin_field( 'general', 'subtitle', __( 'Sottotitolo', 'glutelab-child-theme' ), $general['subtitle'] ); ?><?php glutelab_admin_field( 'general', 'closing_text', __( 'Testo conclusivo', 'glutelab-child-theme' ), $general['closing_text'], 'textarea' ); ?><div class="gl-admin__columns"><?php glutelab_admin_field( 'general', 'cta_label', __( 'Testo CTA generale', 'glutelab-child-theme' ), $general['cta_label'] ); ?><?php glutelab_admin_field( 'general', 'cta_url', __( 'Destinazione CTA', 'glutelab-child-theme' ), $general['cta_url'], 'url' ); ?></div></section>
		<?php glutelab_admin_save_bar( __( 'Salva impostazioni', 'glutelab-child-theme' ), 'save_general', __( 'Valori condivisi tra Home e pagina Pacchetti.', 'glutelab-child-theme' ) ); ?>
	</form>
	<?php
}

function glutelab_packages_admin_content() {
	if ( ! current_user_can( 'edit_pages' ) ) {
		return;
	}
	$catalog    = glutelab_get_catalog();
	$groups     = glutelab_get_package_groups( true );
	$view       = glutelab_admin_request_key( 'catalog_view', 'overview' );
	$group_id   = glutelab_admin_request_key( 'group', $groups[0]['id'] ?? '' );
	$package_id = glutelab_admin_request_key( 'package' );
	?>
	<div class="gl-admin gl-admin--embedded">
		<header class="gl-admin__embedded-head"><div><h2><?php esc_html_e( 'Pacchetti e lezioni', 'glutelab-child-theme' ); ?></h2><p><?php esc_html_e( 'Modifica nome, lezioni, durata e prezzo.', 'glutelab-child-theme' ); ?></p></div><a class="button gl-admin__external" href="<?php echo esc_url( home_url( '/pacchetti-e-lezioni/' ) ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'Vedi la pagina', 'glutelab-child-theme' ); ?><span aria-hidden="true">↗</span></a></header>
		<?php settings_errors(); ?>
		<div class="gl-admin__workspace"><?php glutelab_admin_sidebar( $groups, $view, $group_id ); ?><main>
			<?php
			if ( 'group' === $view && isset( $catalog['groups'][ $group_id ] ) ) {
				glutelab_admin_group_editor( $catalog['groups'][ $group_id ], $groups );
			} elseif ( 'package' === $view ) {
				$is_new  = 'new' === $package_id || ! isset( $catalog['packages'][ $package_id ] );
				$package = $is_new ? glutelab_normalize_package( array( 'group_id' => $group_id, 'title' => '', 'status' => 'active', 'mode' => $catalog['groups'][ $group_id ]['mode'] ?? 'individual', 'sort_order' => count( glutelab_get_packages_by_group( $group_id, true ) ) + 1 ) ) : $catalog['packages'][ $package_id ];
				glutelab_admin_package_editor( $package, $groups, $is_new );
			} elseif ( 'general' === $view ) {
				glutelab_admin_general_editor( $catalog['general'] );
			} else {
				glutelab_admin_overview( $catalog, $groups );
			}
			?>
		</main></div>
		<span hidden data-gl-admin-dom-ready></span>
	</div>
	<?php
}

/** Backward-compatible renderer for integrations that called the old page callback. */
function glutelab_packages_admin_page() {
	glutelab_packages_admin_content();
}
