<?php
/** Compact operations administration. @package GluteLabChildTheme */
if ( ! defined( 'ABSPATH' ) ) exit;

$GLOBALS['glutelab_app_admin_hook'] = '';
function glutelab_app_admin_menu() {
	$GLOBALS['glutelab_app_admin_hook'] = add_submenu_page( 'ticinoweb-cms', __( 'Gestione Glute Lab', 'glutelab-child-theme' ), __( 'Gestione Glute Lab', 'glutelab-child-theme' ), 'manage_options', 'glutelab-operations', 'glutelab_app_admin_page' );
}
add_action( 'admin_menu', 'glutelab_app_admin_menu', 30 );

function glutelab_app_admin_assets( $hook ) {
	if ( $hook !== ( $GLOBALS['glutelab_app_admin_hook'] ?? '' ) ) return;
	$file = get_stylesheet_directory() . '/assets/css/admin-app.css'; wp_enqueue_style( 'glutelab-admin-app', get_stylesheet_directory_uri() . '/assets/css/admin-app.css', array(), is_file( $file ) ? filemtime( $file ) : GLUTELAB_THEME_VERSION );
	$script = get_stylesheet_directory() . '/assets/js/admin-app.js'; wp_enqueue_script( 'glutelab-admin-app', get_stylesheet_directory_uri() . '/assets/js/admin-app.js', array(), is_file( $script ) ? filemtime( $script ) : GLUTELAB_THEME_VERSION, true );
}
add_action( 'admin_enqueue_scripts', 'glutelab_app_admin_assets' );

function glutelab_app_admin_url( $view ) { return add_query_arg( array( 'page' => 'glutelab-operations', 'view' => sanitize_key( $view ) ), admin_url( 'admin.php' ) ); }
function glutelab_app_admin_page() {
	if ( ! current_user_can( 'manage_options' ) ) return;
	$view = sanitize_key( $_GET['view'] ?? 'overview' ); $allowed = array( 'overview', 'bookings', 'customers', 'settings', 'packages', 'payments', 'durations' ); if ( ! in_array( $view, $allowed, true ) ) $view = 'overview';
	$nav_view = 'durations' === $view ? 'settings' : $view;
	?><div class="wrap gl-app-admin"><header class="gl-app-admin__header"><div><p class="gl-app-admin__eyebrow">GLUTE LAB</p><h1><?php esc_html_e( 'Gestione operativa', 'glutelab-child-theme' ); ?></h1><p><?php esc_html_e( 'Richieste, prenotazioni, clienti, pagamenti e crediti in un solo posto.', 'glutelab-child-theme' ); ?></p></div><span class="gl-app-admin__state <?php echo glutelab_app_is_enabled() ? 'is-on' : ''; ?>"><?php echo glutelab_app_is_enabled() ? esc_html__( 'Sistema attivo', 'glutelab-child-theme' ) : esc_html__( 'Sistema disattivato', 'glutelab-child-theme' ); ?></span></header>
	<nav class="nav-tab-wrapper" aria-label="<?php esc_attr_e( 'Sezioni gestione', 'glutelab-child-theme' ); ?>"><?php foreach ( array( 'overview' => __( 'Panoramica', 'glutelab-child-theme' ), 'bookings' => __( 'Richieste', 'glutelab-child-theme' ), 'customers' => __( 'Clienti', 'glutelab-child-theme' ), 'settings' => __( 'Orari', 'glutelab-child-theme' ), 'packages' => __( 'Pacchetti', 'glutelab-child-theme' ), 'payments' => __( 'Pagamenti', 'glutelab-child-theme' ) ) as $key => $label ) : ?><a class="nav-tab <?php echo $nav_view === $key ? 'nav-tab-active' : ''; ?>" href="<?php echo esc_url( glutelab_app_admin_url( $key ) ); ?>"><?php echo esc_html( $label ); ?></a><?php endforeach; ?></nav>
	<?php if ( ! empty( $_GET['gl_notice'] ) ) :
		$notice = sanitize_key( $_GET['gl_notice'] );
		$error = in_array( $notice, array( 'error', 'insufficient_credits', 'booking_not_found', 'invalid_status_transition', 'stripe_credentials_invalid' ), true );
		$message = 'stripe_credentials_invalid' === $notice
			? __( 'Credenziali Stripe non salvate: verifica che le chiavi Test inizino con pk_test_ e sk_test_, e quelle Live con pk_live_ e sk_live_.', 'glutelab-child-theme' )
			: ( $error ? __( 'Operazione non completata: verifica crediti e dati della prenotazione.', 'glutelab-child-theme' ) : __( 'Operazione completata.', 'glutelab-child-theme' ) );
		?><div class="notice <?php echo $error ? 'notice-error' : 'notice-success'; ?> is-dismissible"><p><?php echo esc_html( $message ); ?></p></div><?php endif; ?>
	<main class="gl-app-admin__content"><?php call_user_func( 'glutelab_app_admin_' . $view ); ?></main></div><?php
}

function glutelab_app_admin_count( $metric ) {
	global $wpdb;
	if ( 'open_orders' === $metric ) { $name = glutelab_app_table( 'orders' ); return (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$name} WHERE status IN ('pending','awaiting_payment')" ); } // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	if ( 'future_bookings' === $metric ) { $name = glutelab_app_table( 'bookings' ); return (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$name} WHERE (start_at_utc >= UTC_TIMESTAMP() OR preferred_date >= CURDATE()) AND status IN ('requested','pending','confirmed','paid')" ); } // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	if ( 'customers' === $metric ) { $name = glutelab_app_table( 'customers' ); return (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$name}" ); } // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	return 0;
}
function glutelab_app_admin_overview() {
	?><section class="gl-app-cards"><article><span><?php esc_html_e( 'Richieste aperte', 'glutelab-child-theme' ); ?></span><strong><?php echo esc_html( glutelab_app_admin_count( 'open_orders' ) ); ?></strong></article><article><span><?php esc_html_e( 'Prenotazioni future', 'glutelab-child-theme' ); ?></span><strong><?php echo esc_html( glutelab_app_admin_count( 'future_bookings' ) ); ?></strong></article><article><span><?php esc_html_e( 'Clienti', 'glutelab-child-theme' ); ?></span><strong><?php echo esc_html( glutelab_app_admin_count( 'customers' ) ); ?></strong></article></section>
	?><section class="gl-app-panel gl-app-quick-actions"><h2><?php esc_html_e( 'Cosa vuoi fare?', 'glutelab-child-theme' ); ?></h2><div><a class="button button-primary" href="<?php echo esc_url( glutelab_app_admin_url( 'bookings' ) ); ?>"><?php esc_html_e( 'Vedi le richieste', 'glutelab-child-theme' ); ?></a><a class="button" href="<?php echo esc_url( glutelab_app_admin_url( 'settings' ) ); ?>"><?php esc_html_e( 'Imposta gli orari', 'glutelab-child-theme' ); ?></a><a class="button" href="<?php echo esc_url( glutelab_app_admin_url( 'packages' ) ); ?>"><?php esc_html_e( 'Gestisci i pacchetti', 'glutelab-child-theme' ); ?></a></div></section><?php
}

/** Keep the catalogue editor inside the main Glute Lab administration. */
function glutelab_app_admin_packages() {
	glutelab_packages_admin_content();
}

function glutelab_app_admin_empty( $text ) { echo '<div class="gl-app-empty"><p>' . esc_html( $text ) . '</p></div>'; }
function glutelab_app_admin_bookings() {
	$rows = glutelab_app_admin_rows( 'bookings' ); if ( ! $rows ) return glutelab_app_admin_empty( __( 'Nessuna prenotazione o richiesta con preferenza di giorno.', 'glutelab-child-theme' ) );
	?><div class="gl-app-table-wrap"><table class="widefat striped"><thead><tr><th><?php esc_html_e( 'Riferimento', 'glutelab-child-theme' ); ?></th><th><?php esc_html_e( 'Data, orario e durata', 'glutelab-child-theme' ); ?></th><th><?php esc_html_e( 'Offerta', 'glutelab-child-theme' ); ?></th><th><?php esc_html_e( 'Stato', 'glutelab-child-theme' ); ?></th><th><?php esc_html_e( 'Azioni', 'glutelab-child-theme' ); ?></th></tr></thead><tbody><?php foreach ( $rows as $row ) : $customer = glutelab_app_get_customer( $row['customer_id'] ); $interval = glutelab_app_booking_interval_label( $row['start_at_utc'], $row['end_at_utc'] ); $preferred = glutelab_app_preferred_date_label( $row['preferred_date'] ?? '' ); $terminal = in_array( $row['status'], array( 'completed', 'cancelled', 'no_show' ), true ); ?><tr><td><strong><?php echo esc_html( $row['reference'] ); ?></strong><br><small><?php echo esc_html( trim( ( $customer['first_name'] ?? '' ) . ' ' . ( $customer['last_name'] ?? '' ) ) ); ?></small></td><td><strong><?php echo esc_html( $interval ?: ( $preferred ? sprintf( __( 'Giorno preferito: %s', 'glutelab-child-theme' ), $preferred ) : '—' ) ); ?></strong></td><td><?php $package = glutelab_get_package( $row['package_id'] ); echo esc_html( $package ? $package['title'] : $row['package_id'] ); ?></td><td><span class="gl-app-status"><?php echo esc_html( $row['status'] ); ?></span><?php if ( $row['credits_used'] ) : ?><br><small><?php esc_html_e( '1 credito usato', 'glutelab-child-theme' ); ?></small><?php endif; ?></td><td><?php if ( $terminal ) : ?><span aria-label="<?php esc_attr_e( 'Stato finale', 'glutelab-child-theme' ); ?>">—</span><?php else : ?><form class="gl-app-inline" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" method="post"><input type="hidden" name="action" value="glutelab_app_booking_status"><input type="hidden" name="booking_id" value="<?php echo esc_attr( $row['id'] ); ?>"><?php wp_nonce_field( 'glutelab_app_booking_status' ); ?><label class="screen-reader-text" for="gl-booking-status-<?php echo esc_attr( $row['id'] ); ?>"><?php esc_html_e( 'Nuovo stato della prenotazione', 'glutelab-child-theme' ); ?></label><select id="gl-booking-status-<?php echo esc_attr( $row['id'] ); ?>" name="status"><option value="confirmed"><?php esc_html_e( 'Conferma', 'glutelab-child-theme' ); ?></option><option value="completed"><?php esc_html_e( 'Completata', 'glutelab-child-theme' ); ?></option><option value="cancelled"><?php esc_html_e( 'Annulla', 'glutelab-child-theme' ); ?></option><option value="no_show"><?php esc_html_e( 'Assente', 'glutelab-child-theme' ); ?></option></select><button class="button"><?php esc_html_e( 'Aggiorna', 'glutelab-child-theme' ); ?></button></form><?php endif; ?></td></tr><?php endforeach; ?></tbody></table></div><?php
}

function glutelab_app_admin_customers() {
	$rows = glutelab_app_admin_rows( 'customers' ); if ( ! $rows ) return glutelab_app_admin_empty( __( 'Nessun cliente registrato.', 'glutelab-child-theme' ) );
	$requests_by_customer = glutelab_app_customer_requests_by_customer( array_column( $rows, 'id' ) );
	?><div class="gl-app-table-wrap"><table class="widefat striped gl-app-customer-table"><thead><tr><th><?php esc_html_e( 'Cliente', 'glutelab-child-theme' ); ?></th><th><?php esc_html_e( 'Contatti', 'glutelab-child-theme' ); ?></th><th><?php esc_html_e( 'Ultima scelta', 'glutelab-child-theme' ); ?></th><th><?php esc_html_e( 'Crediti', 'glutelab-child-theme' ); ?></th><th><?php esc_html_e( 'Rettifica', 'glutelab-child-theme' ); ?></th></tr></thead><tbody><?php foreach ( $rows as $row ) :
		$requests = $requests_by_customer[ (int) $row['id'] ] ?? array();
		$latest   = $requests ? glutelab_app_customer_request_view( array_shift( $requests ) ) : null;
		?><tr><td><strong><?php echo esc_html( trim( $row['first_name'] . ' ' . $row['last_name'] ) ); ?></strong><br><small>#<?php echo esc_html( $row['id'] ); ?></small></td><td><a href="mailto:<?php echo esc_attr( $row['email'] ); ?>"><?php echo esc_html( $row['email'] ); ?></a><br><?php echo esc_html( $row['phone'] ); ?></td><td class="gl-app-customer-choice-cell"><?php if ( $latest ) : glutelab_app_admin_customer_choice( $latest ); ?><?php if ( $requests ) : ?><details class="gl-app-customer-history"><summary><?php echo esc_html( sprintf( _n( 'Mostra 1 richiesta precedente', 'Mostra %d richieste precedenti', count( $requests ), 'glutelab-child-theme' ), count( $requests ) ) ); ?></summary><div class="gl-app-customer-history__list"><?php foreach ( $requests as $request ) glutelab_app_admin_customer_choice( glutelab_app_customer_request_view( $request ), true ); ?></div></details><?php endif; ?><?php else : ?><span class="gl-app-muted"><?php esc_html_e( 'Nessuna richiesta inviata', 'glutelab-child-theme' ); ?></span><?php endif; ?></td><td><strong><?php echo esc_html( glutelab_app_credit_balance( $row['id'] ) ); ?></strong></td><td><form class="gl-app-inline" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" method="post"><input type="hidden" name="action" value="glutelab_app_adjust_credit"><input type="hidden" name="customer_id" value="<?php echo esc_attr( $row['id'] ); ?>"><?php wp_nonce_field( 'glutelab_app_adjust_credit' ); ?><label class="screen-reader-text" for="gl-credit-delta-<?php echo esc_attr( $row['id'] ); ?>"><?php esc_html_e( 'Rettifica crediti', 'glutelab-child-theme' ); ?></label><input id="gl-credit-delta-<?php echo esc_attr( $row['id'] ); ?>" class="small-text" type="number" min="-100" max="100" name="delta" required placeholder="+1 / -1"><label class="screen-reader-text" for="gl-credit-note-<?php echo esc_attr( $row['id'] ); ?>"><?php esc_html_e( 'Motivo della rettifica', 'glutelab-child-theme' ); ?></label><input id="gl-credit-note-<?php echo esc_attr( $row['id'] ); ?>" name="note" maxlength="255" placeholder="<?php esc_attr_e( 'Motivo', 'glutelab-child-theme' ); ?>"><button class="button"><?php esc_html_e( 'Salva', 'glutelab-child-theme' ); ?></button></form></td></tr><?php endforeach; ?></tbody></table></div><?php
}

/** Convert stored request data to the labels used in the customer table. */
function glutelab_app_customer_request_view( array $request ) {
	$package  = glutelab_get_package( $request['package_id'] ?? '' );
	$interval = glutelab_app_booking_interval_label( $request['start_at_utc'] ?? '', $request['end_at_utc'] ?? '' );
	$day      = glutelab_app_preferred_date_label( $request['preferred_date'] ?? '' );
	$methods  = array(
		'inquiry'   => __( 'Nessun pagamento ora', 'glutelab-child-theme' ),
		'in_person' => __( 'Pagamento in sede', 'glutelab-child-theme' ),
		'stripe'    => __( 'Pagamento online', 'glutelab-child-theme' ),
	);
	return array(
		'package'  => $package ? $package['title'] : __( 'Offerta non più disponibile', 'glutelab-child-theme' ),
		'schedule' => $interval ?: ( $day ? sprintf( __( '%s · Orario da concordare', 'glutelab-child-theme' ), $day ) : __( 'Giorno e orario non indicati', 'glutelab-child-theme' ) ),
		'payment'  => $methods[ $request['payment_method'] ?? '' ] ?? __( 'Metodo non disponibile', 'glutelab-child-theme' ),
	);
}

/** Render one concise request summary inside the customer table. */
function glutelab_app_admin_customer_choice( array $choice, $compact = false ) {
	?>
	<div class="gl-app-customer-choice<?php echo $compact ? ' is-compact' : ''; ?>">
		<span class="gl-app-customer-choice__label"><?php esc_html_e( 'Pacchetto scelto', 'glutelab-child-theme' ); ?></span>
		<strong><?php echo esc_html( $choice['package'] ); ?></strong>
		<dl>
			<div><dt><?php esc_html_e( 'Giorno e orario', 'glutelab-child-theme' ); ?></dt><dd><?php echo esc_html( $choice['schedule'] ); ?></dd></div>
			<div><dt><?php esc_html_e( 'Metodo di pagamento', 'glutelab-child-theme' ); ?></dt><dd><?php echo esc_html( $choice['payment'] ); ?></dd></div>
		</dl>
	</div>
	<?php
}

function glutelab_app_admin_payments() {
	$rows = glutelab_app_admin_rows( 'orders' ); if ( ! $rows ) return glutelab_app_admin_empty( __( 'Nessuna richiesta o pagamento.', 'glutelab-child-theme' ) );
	?><div class="gl-app-table-wrap"><table class="widefat striped"><thead><tr><th><?php esc_html_e( 'Riferimento', 'glutelab-child-theme' ); ?></th><th><?php esc_html_e( 'Offerta', 'glutelab-child-theme' ); ?></th><th><?php esc_html_e( 'Importo', 'glutelab-child-theme' ); ?></th><th><?php esc_html_e( 'Metodo', 'glutelab-child-theme' ); ?></th><th><?php esc_html_e( 'Stato', 'glutelab-child-theme' ); ?></th><th><?php esc_html_e( 'Azioni', 'glutelab-child-theme' ); ?></th></tr></thead><tbody><?php foreach ( $rows as $row ) : ?><tr><td><strong><?php echo esc_html( $row['reference'] ); ?></strong></td><td><?php echo esc_html( $row['package_id'] ); ?></td><td><?php echo esc_html( glutelab_format_chf( $row['amount_cents'] / 100 ) ); ?></td><td><?php echo esc_html( $row['payment_method'] ); ?></td><td><span class="gl-app-status"><?php echo esc_html( $row['status'] ); ?></span></td><td><?php if ( 'in_person' === $row['payment_method'] && 'paid' !== $row['status'] ) : ?><form action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" method="post"><input type="hidden" name="action" value="glutelab_app_order_paid"><input type="hidden" name="order_id" value="<?php echo esc_attr( $row['id'] ); ?>"><?php wp_nonce_field( 'glutelab_app_order_paid' ); ?><button class="button button-primary"><?php esc_html_e( 'Segna pagato', 'glutelab-child-theme' ); ?></button></form><?php else : ?>—<?php endif; ?></td></tr><?php endforeach; ?></tbody></table></div><?php
}

function glutelab_app_admin_time_range( $pattern, $day, $index, $interval, $day_label ) {
	$open  = $interval['open'] ?? '';
	$close = $interval['close'] ?? '';
	?>
	<div class="gl-app-time-range" data-gl-time-range data-gl-range-index="<?php echo esc_attr( $index ); ?>">
		<label><span><?php esc_html_e( 'Da', 'glutelab-child-theme' ); ?></span><input type="time" aria-label="<?php echo esc_attr( sprintf( __( '%s: dalle', 'glutelab-child-theme' ), $day_label ) ); ?>" name="settings[weekly_patterns][<?php echo esc_attr( $pattern ); ?>][<?php echo esc_attr( $day ); ?>][ranges][<?php echo esc_attr( $index ); ?>][open]" value="<?php echo esc_attr( $open ); ?>"></label>
		<label><span><?php esc_html_e( 'A', 'glutelab-child-theme' ); ?></span><input type="time" aria-label="<?php echo esc_attr( sprintf( __( '%s: alle', 'glutelab-child-theme' ), $day_label ) ); ?>" name="settings[weekly_patterns][<?php echo esc_attr( $pattern ); ?>][<?php echo esc_attr( $day ); ?>][ranges][<?php echo esc_attr( $index ); ?>][close]" value="<?php echo esc_attr( $close ); ?>"></label>
		<button type="button" class="button-link-delete gl-app-time-range__remove" data-gl-remove-range aria-label="<?php echo esc_attr( sprintf( __( 'Rimuovi questo orario di %s', 'glutelab-child-theme' ), $day_label ) ); ?>">&times;</button>
	</div>
	<?php
}

function glutelab_app_admin_week_pattern( $pattern, $label, $description, $settings, $days, $context = array() ) {
	$status       = in_array( $context['status'] ?? '', array( 'current', 'next' ), true ) ? $context['status'] : '';
	$status_label = (string) ( $context['status_label'] ?? '' );
	?>
	<fieldset class="gl-app-week-pattern<?php echo $status ? ' is-' . esc_attr( $status ) : ''; ?>" data-gl-schedule-week="<?php echo esc_attr( $pattern ); ?>"<?php echo $status ? ' data-gl-week-status="' . esc_attr( $status ) . '"' : ''; ?>>
		<legend>
			<span class="gl-app-week-pattern__title"><span><?php echo esc_html( $label ); ?></span><?php if ( $status_label ) : ?><em class="gl-app-week-pattern__status"><?php echo esc_html( $status_label ); ?></em><?php endif; ?></span>
			<small><?php echo esc_html( $description ); ?></small>
		</legend>
		<div class="gl-app-schedule">
			<div class="gl-app-schedule__heading" aria-hidden="true">
				<span><?php esc_html_e( 'Giorno', 'glutelab-child-theme' ); ?></span>
				<span><?php esc_html_e( 'Aperto', 'glutelab-child-theme' ); ?></span>
				<span><?php esc_html_e( 'Orari disponibili', 'glutelab-child-theme' ); ?></span>
			</div>
			<?php foreach ( $days as $key => $day_label ) :
				$intervals = array_values( $settings['weekly_patterns'][ $pattern ][ $key ] ?? array() );
				$is_open   = ! empty( $intervals );
				?>
				<div class="gl-app-schedule__day <?php echo $is_open ? 'is-open' : 'is-closed'; ?>" data-gl-schedule-day="<?php echo esc_attr( $key ); ?>">
					<strong class="gl-app-schedule__day-name"><?php echo esc_html( $day_label ); ?></strong>
					<label class="gl-app-schedule__open"><input type="checkbox" name="settings[weekly_patterns][<?php echo esc_attr( $pattern ); ?>][<?php echo esc_attr( $key ); ?>][enabled]" value="1" data-gl-day-open <?php checked( $is_open ); ?>><span data-gl-open-label><?php echo $is_open ? esc_html__( 'Aperto', 'glutelab-child-theme' ) : esc_html__( 'Chiuso', 'glutelab-child-theme' ); ?></span></label>
					<div class="gl-app-schedule__times">
						<div class="gl-app-time-ranges" data-gl-time-ranges><?php foreach ( $intervals as $index => $interval ) glutelab_app_admin_time_range( $pattern, $key, $index, $interval, $day_label ); ?></div>
						<button type="button" class="button gl-app-add-range" data-gl-add-range><?php esc_html_e( '+ Aggiungi orario', 'glutelab-child-theme' ); ?></button>
					</div>
				</div>
			<?php endforeach; ?>
		</div>
	</fieldset>
	<?php
}

/** Render the environment switch and the two independent Stripe credential sets. */
function glutelab_app_admin_stripe_settings( $settings ) {
	$active_mode = glutelab_app_stripe_mode( $settings );
	$modes = array(
		'test' => array(
			'label'       => __( 'Test', 'glutelab-child-theme' ),
			'description' => __( 'Pagamenti di prova, senza addebiti reali', 'glutelab-child-theme' ),
			'public_hint' => 'pk_test_…',
			'secret_hint' => 'sk_test_…',
		),
		'live' => array(
			'label'       => __( 'Live', 'glutelab-child-theme' ),
			'description' => __( 'Pagamenti reali sul conto Stripe', 'glutelab-child-theme' ),
			'public_hint' => 'pk_live_…',
			'secret_hint' => 'sk_live_…',
		),
	);
	?>
	<details class="gl-app-panel gl-app-advanced gl-app-stripe" data-gl-stripe-settings>
		<summary><span><strong><?php esc_html_e( 'Pagamento online con Stripe', 'glutelab-child-theme' ); ?></strong><small><?php esc_html_e( 'Chiavi e modalità Test o Live', 'glutelab-child-theme' ); ?></small></span><span class="gl-app-stripe__current" data-gl-stripe-current data-gl-stripe-current-template="<?php echo esc_attr( __( 'Modalità %s attiva', 'glutelab-child-theme' ) ); ?>"><?php echo esc_html( sprintf( __( 'Modalità %s attiva', 'glutelab-child-theme' ), $modes[ $active_mode ]['label'] ) ); ?></span></summary>
		<div class="gl-app-advanced__body">
			<p class="description"><?php esc_html_e( 'Conserva separatamente le chiavi di prova e quelle ufficiali. La modalità scelta stabilisce quale ambiente usa il sito.', 'glutelab-child-theme' ); ?></p>

		<fieldset class="gl-app-stripe-mode">
			<legend><?php esc_html_e( 'Modalità Stripe', 'glutelab-child-theme' ); ?></legend>
			<div class="gl-app-stripe-mode__options">
				<?php foreach ( $modes as $mode => $copy ) : ?>
					<label>
						<input type="radio" name="settings[stripe_mode]" value="<?php echo esc_attr( $mode ); ?>" data-gl-stripe-mode data-gl-stripe-label="<?php echo esc_attr( $copy['label'] ); ?>" aria-controls="gl-stripe-panel-<?php echo esc_attr( $mode ); ?>" <?php checked( $active_mode, $mode ); ?>>
						<span><strong><?php echo esc_html( $copy['label'] ); ?></strong><small><?php echo esc_html( $copy['description'] ); ?></small></span>
					</label>
				<?php endforeach; ?>
			</div>
		</fieldset>

		<div class="gl-app-stripe-panels">
			<?php foreach ( $modes as $mode => $copy ) :
				$public_key = glutelab_app_get_stripe_credential( 'publishable_key', $mode );
				$secret_saved = '' !== glutelab_app_get_stripe_credential( 'secret_key', $mode );
				$webhook_saved = '' !== glutelab_app_get_stripe_credential( 'webhook_secret', $mode );
				$complete = glutelab_app_stripe_is_configured( $mode );
				?>
				<section id="gl-stripe-panel-<?php echo esc_attr( $mode ); ?>" class="gl-app-stripe-panel<?php echo $active_mode === $mode ? ' is-active' : ''; ?>" data-gl-stripe-panel="<?php echo esc_attr( $mode ); ?>" aria-labelledby="gl-stripe-title-<?php echo esc_attr( $mode ); ?>">
					<header>
						<div><h3 id="gl-stripe-title-<?php echo esc_attr( $mode ); ?>"><?php echo esc_html( sprintf( __( 'Credenziali %s', 'glutelab-child-theme' ), $copy['label'] ) ); ?></h3><p><?php echo esc_html( $copy['description'] ); ?></p></div>
						<span class="gl-app-stripe-panel__status<?php echo $complete ? ' is-ready' : ''; ?>"><?php echo $complete ? esc_html__( 'Completo', 'glutelab-child-theme' ) : esc_html__( 'Da completare', 'glutelab-child-theme' ); ?></span>
					</header>
					<?php if ( 'live' === $mode ) : ?><p class="gl-app-stripe-panel__warning"><strong><?php esc_html_e( 'Attenzione:', 'glutelab-child-theme' ); ?></strong> <?php esc_html_e( 'usa questa modalità soltanto quando le credenziali ufficiali e il webhook Live sono stati verificati.', 'glutelab-child-theme' ); ?></p><?php endif; ?>
					<div class="gl-app-stripe-fields">
						<label><span><?php esc_html_e( 'Chiave pubblica', 'glutelab-child-theme' ); ?></span><input type="text" name="stripe_credentials[<?php echo esc_attr( $mode ); ?>][publishable_key]" value="<?php echo esc_attr( $public_key ); ?>" placeholder="<?php echo esc_attr( $copy['public_hint'] ); ?>" autocomplete="off" autocapitalize="off" spellcheck="false"><small><?php esc_html_e( 'Può essere mostrata nel browser e resta visibile qui.', 'glutelab-child-theme' ); ?></small></label>
						<label><span><?php esc_html_e( 'Chiave segreta', 'glutelab-child-theme' ); ?> <em><?php echo $secret_saved ? esc_html__( 'Salvata', 'glutelab-child-theme' ) : esc_html__( 'Mancante', 'glutelab-child-theme' ); ?></em></span><input type="password" name="stripe_credentials[<?php echo esc_attr( $mode ); ?>][secret_key]" autocomplete="new-password" autocapitalize="off" spellcheck="false" placeholder="<?php echo esc_attr( $secret_saved ? __( 'Lascia vuoto per conservarla', 'glutelab-child-theme' ) : $copy['secret_hint'] ); ?>"><small><?php esc_html_e( 'Non viene mai mostrata dopo il salvataggio.', 'glutelab-child-theme' ); ?></small></label>
						<label><span><?php esc_html_e( 'Segreto webhook', 'glutelab-child-theme' ); ?> <em><?php echo $webhook_saved ? esc_html__( 'Salvato', 'glutelab-child-theme' ) : esc_html__( 'Mancante', 'glutelab-child-theme' ); ?></em></span><input type="password" name="stripe_credentials[<?php echo esc_attr( $mode ); ?>][webhook_secret]" autocomplete="new-password" autocapitalize="off" spellcheck="false" placeholder="<?php echo esc_attr( $webhook_saved ? __( 'Lascia vuoto per conservarlo', 'glutelab-child-theme' ) : 'whsec_…' ); ?>"><small><?php esc_html_e( 'Copia il Signing secret del webhook del relativo ambiente.', 'glutelab-child-theme' ); ?></small></label>
					</div>
				</section>
			<?php endforeach; ?>
		</div>

			<label class="gl-app-field gl-app-stripe-webhook"><span><?php esc_html_e( 'URL webhook da inserire in Stripe', 'glutelab-child-theme' ); ?></span><input readonly value="<?php echo esc_attr( rest_url( 'glutelab/v1/stripe/webhook' ) ); ?>" data-gl-stripe-webhook-url><small><?php esc_html_e( 'Usa lo stesso URL negli endpoint Test e Live di Stripe; ciascuno avrà il proprio segreto.', 'glutelab-child-theme' ); ?></small></label>
		</div>
	</details>
	<?php
}

function glutelab_app_admin_settings() {
	$s = glutelab_app_get_settings();
	$days = array( 'monday' => __( 'Lunedì', 'glutelab-child-theme' ), 'tuesday' => __( 'Martedì', 'glutelab-child-theme' ), 'wednesday' => __( 'Mercoledì', 'glutelab-child-theme' ), 'thursday' => __( 'Giovedì', 'glutelab-child-theme' ), 'friday' => __( 'Venerdì', 'glutelab-child-theme' ), 'saturday' => __( 'Sabato', 'glutelab-child-theme' ), 'sunday' => __( 'Domenica', 'glutelab-child-theme' ) );
	$timezone = glutelab_app_timezone();
	$week_contexts = glutelab_app_week_contexts( new DateTimeImmutable( 'now', $timezone ) );
	?><form class="gl-app-settings" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" method="post"><input type="hidden" name="action" value="glutelab_app_save_settings"><?php wp_nonce_field( 'glutelab_app_save_settings' ); ?>
		<details class="gl-app-panel gl-app-settings-toggle"><summary><?php esc_html_e( 'Cosa è attivo sul sito', 'glutelab-child-theme' ); ?></summary><p class="description"><?php esc_html_e( 'Apri questa sezione solo per attivare o disattivare richieste, orari e pagamenti.', 'glutelab-child-theme' ); ?> <a href="<?php echo esc_url( glutelab_app_admin_url( 'packages' ) ); ?>"><?php esc_html_e( 'Apri i pacchetti', 'glutelab-child-theme' ); ?></a>.</p><div class="gl-app-toggles"><label><input type="checkbox" name="settings[enabled]" value="1" <?php checked( $s['enabled'] ); ?>> <span><strong><?php esc_html_e( 'Modulo richieste', 'glutelab-child-theme' ); ?></strong></span></label><label><input type="checkbox" name="settings[booking_enabled]" value="1" <?php checked( $s['booking_enabled'] ); ?>> <span><strong><?php esc_html_e( 'Scelta di giorno e orario', 'glutelab-child-theme' ); ?></strong></span></label><label><input type="checkbox" name="settings[payment_in_person_enabled]" value="1" <?php checked( $s['payment_in_person_enabled'] ); ?>> <span><strong><?php esc_html_e( 'Pagamento in sede', 'glutelab-child-theme' ); ?></strong></span></label><label><input type="checkbox" name="settings[stripe_enabled]" value="1" <?php checked( $s['stripe_enabled'] ); ?>> <span><strong><?php esc_html_e( 'Pagamento online', 'glutelab-child-theme' ); ?></strong></span></label></div></details>
	<section class="gl-app-panel gl-app-availability" aria-describedby="gl-app-availability-help">
			<div class="gl-app-section-heading"><div><h2><?php esc_html_e( 'Quando sei disponibile', 'glutelab-child-theme' ); ?></h2><p id="gl-app-availability-help" class="description"><?php esc_html_e( 'Imposta due settimane tipo. Il calendario le alterna automaticamente.', 'glutelab-child-theme' ); ?></p></div></div>
		<div class="gl-app-availability-note"><div><strong><?php esc_html_e( 'Le fasce indicano quando sei disponibile.', 'glutelab-child-theme' ); ?></strong><span><?php esc_html_e( 'Per trasformarle in orari selezionabili serve anche la durata della singola lezione in ogni offerta.', 'glutelab-child-theme' ); ?></span></div><a class="button" href="<?php echo esc_url( glutelab_app_admin_url( 'durations' ) ); ?>"><?php esc_html_e( 'Configura le durate', 'glutelab-child-theme' ); ?></a></div>
		<div class="gl-app-week-patterns">
			<?php foreach ( $week_contexts as $context ) :
				$range = sprintf(
					__( 'Dal %1$s al %2$s', 'glutelab-child-theme' ),
					wp_date( 'j F', $context['start']->getTimestamp(), $timezone ),
					wp_date( 'j F Y', $context['end']->getTimestamp(), $timezone )
				);
				glutelab_app_admin_week_pattern(
					$context['pattern'],
					sprintf( __( 'Settimana %s', 'glutelab-child-theme' ), strtoupper( $context['pattern'] ) ),
					$range,
					$s,
					$days,
					array(
						'status'       => $context['status'],
						'status_label' => 'current' === $context['status'] ? __( 'In corso', 'glutelab-child-theme' ) : __( 'Prossima', 'glutelab-child-theme' ),
					)
				);
			endforeach; ?>
		</div>
			<p class="description gl-app-schedule-help"><?php esc_html_e( 'Segna i giorni aperti e aggiungi gli orari. Puoi inserire più fasce nello stesso giorno per lasciare una pausa.', 'glutelab-child-theme' ); ?></p>
		<label class="gl-app-field"><span><?php esc_html_e( 'Giorni chiusi straordinari', 'glutelab-child-theme' ); ?></span><textarea name="settings[closure_dates]" rows="4" placeholder="2026-12-25&#10;2026-12-26"><?php echo esc_textarea( implode( "\n", $s['closure_dates'] ) ); ?></textarea><small><?php esc_html_e( 'Una data per riga, formato AAAA-MM-GG.', 'glutelab-child-theme' ); ?></small></label>
	</section>
		<details class="gl-app-panel gl-app-advanced"><summary><span><strong><?php esc_html_e( 'Regole di prenotazione', 'glutelab-child-theme' ); ?></strong><small><?php esc_html_e( 'Preavviso, giorni prenotabili e promemoria', 'glutelab-child-theme' ); ?></small></span></summary><div class="gl-app-advanced__body"><div class="gl-app-fields"><label><span><?php esc_html_e( 'Quante ore prima si può prenotare?', 'glutelab-child-theme' ); ?></span><input type="number" min="0" max="168" name="settings[min_notice_hours]" value="<?php echo esc_attr( $s['min_notice_hours'] ); ?>"></label><label><span><?php esc_html_e( 'Quanti giorni in avanti si può scegliere?', 'glutelab-child-theme' ); ?></span><input type="number" min="1" max="365" name="settings[booking_horizon_days]" value="<?php echo esc_attr( $s['booking_horizon_days'] ); ?>"></label><label><span><?php esc_html_e( 'Ore prima del promemoria', 'glutelab-child-theme' ); ?></span><input type="number" min="0" max="168" name="settings[reminder_hours]" value="<?php echo esc_attr( $s['reminder_hours'] ); ?>"></label></div></div></details>
	<?php glutelab_app_admin_stripe_settings( $s ); ?>
	<p class="submit"><button class="button button-primary button-hero"><?php esc_html_e( 'Salva impostazioni', 'glutelab-child-theme' ); ?></button></p></form><?php
}

/** Focused editor for the duration used by public scheduling. */
function glutelab_app_admin_durations() {
	$groups       = glutelab_get_package_groups( true );
	$packages     = glutelab_get_packages( array( 'include_inactive' => true ) );
	$visible_rows = 0;
	?>
	<form class="gl-app-durations" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" method="post">
		<input type="hidden" name="action" value="glutelab_app_save_durations">
		<?php wp_nonce_field( 'glutelab_app_save_durations' ); ?>
		<section class="gl-app-panel gl-app-duration-panel" aria-labelledby="gl-app-duration-title">
			<header class="gl-app-duration-toolbar">
				<div>
					<p class="gl-app-admin__eyebrow"><?php esc_html_e( 'Configurazione rapida', 'glutelab-child-theme' ); ?></p>
					<h2 id="gl-app-duration-title"><?php esc_html_e( 'Durata delle lezioni', 'glutelab-child-theme' ); ?></h2>
					<p class="description"><?php esc_html_e( 'La durata stabilisce ogni quanto compare un nuovo orario selezionabile. Le modifiche sono sincronizzate con la scheda completa di ogni offerta.', 'glutelab-child-theme' ); ?></p>
				</div>
				<a class="button" href="<?php echo esc_url( glutelab_app_admin_url( 'settings' ) ); ?>"><?php esc_html_e( 'Torna alle disponibilità', 'glutelab-child-theme' ); ?></a>
			</header>
			<div class="gl-app-duration-list">
				<?php foreach ( $groups as $group ) : ?>
					<?php foreach ( $packages as $package ) : ?>
						<?php if ( $group['id'] !== $package['group_id'] ) continue; ?>
						<?php if ( 'digital' === $package['mode'] ) continue; $visible_rows++; ?>
						<?php
						$total_lessons = glutelab_calculate_total_lessons( $package['lessons_purchased'], $package['bonus_lessons'] );
						$lesson_label  = null === $total_lessons ? __( 'Lezioni da definire', 'glutelab-child-theme' ) : sprintf( _n( '%d lezione', '%d lezioni', $total_lessons, 'glutelab-child-theme' ), $total_lessons );
						$input_id      = 'gl-duration-' . sanitize_html_class( $package['id'] );
						$help_id       = $input_id . '-help';
						?>
						<div class="gl-app-duration-row">
							<div class="gl-app-duration-row__main">
								<span class="gl-app-duration-row__course"><?php echo esc_html( $group['title'] ); ?></span>
								<h3><?php echo esc_html( $package['title'] ); ?></h3>
								<div class="gl-app-duration-row__facts">
									<span><?php echo esc_html( glutelab_package_price_text( $package ) ); ?></span>
									<span><?php echo esc_html( $lesson_label ); ?></span>
									<span class="gl-app-duration-status <?php echo 'active' === $package['status'] ? 'is-active' : ''; ?>"><?php echo 'active' === $package['status'] ? esc_html__( 'Attiva', 'glutelab-child-theme' ) : esc_html__( 'Non attiva', 'glutelab-child-theme' ); ?></span>
								</div>
							</div>
							<label class="gl-app-duration-field" for="<?php echo esc_attr( $input_id ); ?>">
								<span><?php esc_html_e( 'Durata della lezione', 'glutelab-child-theme' ); ?></span>
								<span class="gl-app-duration-field__control"><input id="<?php echo esc_attr( $input_id ); ?>" type="number" name="durations[<?php echo esc_attr( $package['id'] ); ?>]" min="5" max="240" step="5" inputmode="numeric" value="<?php echo esc_attr( $package['session_minutes'] ?? '' ); ?>" placeholder="<?php esc_attr_e( 'es. 60', 'glutelab-child-theme' ); ?>" aria-describedby="<?php echo esc_attr( $help_id ); ?>"><span><?php esc_html_e( 'minuti', 'glutelab-child-theme' ); ?></span></span>
								<small id="<?php echo esc_attr( $help_id ); ?>"><?php echo ! empty( $package['session_minutes'] ) ? esc_html( glutelab_app_duration_label( $package['session_minutes'] ) ) : esc_html__( 'Da configurare', 'glutelab-child-theme' ); ?></small>
							</label>
						</div>
					<?php endforeach; ?>
				<?php endforeach; ?>
				<?php if ( ! $visible_rows ) : ?><p class="gl-app-muted"><?php esc_html_e( 'Non ci sono offerte con lezioni da configurare.', 'glutelab-child-theme' ); ?></p><?php endif; ?>
			</div>
			<footer class="gl-app-duration-actions">
				<p><?php esc_html_e( 'Lascia vuoto solo se non vuoi rendere selezionabili gli orari di quell’offerta.', 'glutelab-child-theme' ); ?></p>
				<button class="button button-primary button-hero"<?php disabled( 0 === $visible_rows ); ?>><?php esc_html_e( 'Salva tutte le durate', 'glutelab-child-theme' ); ?></button>
			</footer>
		</section>
	</form>
	<?php
}

