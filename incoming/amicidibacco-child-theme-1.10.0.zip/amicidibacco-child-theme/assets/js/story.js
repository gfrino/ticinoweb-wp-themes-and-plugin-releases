(function () {
    'use strict';
    const root = document.querySelector('[data-history]');
    if (!root) return;
    const sequence = root.querySelector('[data-history-sequence]');
    const stage = root.querySelector('[data-history-stage]');
    const scenes = Array.from(root.querySelectorAll('[data-history-scene]'));
    const links = Array.from(root.querySelectorAll('[data-history-go]'));
    const reduced = matchMedia('(prefers-reduced-motion: reduce)');
    const desktop = matchMedia('(min-width: 901px)');
    const saveData = !!navigator.connection?.saveData;
    const clamp = (n, a = 0, b = 1) => Math.max(a, Math.min(b, n));
    const ease = t => { t = clamp(t); return t * t * (3 - 2 * t); };
    let enabled = false, lenis = null, raf = 0, dirty = true, start = 0, view = 1, active = -1, navigation = 0;

    function paint() {
        if (!enabled) {
            scenes.forEach(scene => {
                if (reduced.matches || saveData || desktop.matches) {
                    scene.style.removeProperty('--story-photo-pan');
                    scene.style.removeProperty('--story-photo-scale');
                    return;
                }
                const bounds = scene.getBoundingClientRect();
                if (bounds.bottom < 0 || bounds.top > innerHeight) return;
                const travel = clamp((innerHeight / 2 - bounds.top - bounds.height / 2) / innerHeight, -.5, .5);
                scene.style.setProperty('--story-photo-pan', (travel * 18).toFixed(2) + 'px');
                scene.style.setProperty('--story-photo-scale', '1.08');
            });
            return;
        }
        const progress = clamp((scrollY - start) / view, 0, scenes.length - 1);
        const base = Math.floor(progress), blend = ease((progress - base - .57) / .38);
        const next = Math.min(base + 1, scenes.length - 1);
        const current = blend > .5 ? next : base;
        scenes.forEach((scene, i) => {
            const weight = i === base ? 1 - blend : i === next ? blend : 0;
            const opacity = base === next && i === base ? 1 : weight;
            const copy = ease((opacity - .6) / .4);
            scene.style.setProperty('--story-opacity', opacity.toFixed(5));
            scene.style.setProperty('--story-copy-opacity', copy.toFixed(5));
            scene.style.setProperty('--story-copy-y', ((1 - copy) * 24).toFixed(2) + 'px');
            scene.style.setProperty('--story-photo-crop', ((1 - opacity) * 4).toFixed(3) + '%');
            const drift = clamp(progress - i, -.4, .9);
            scene.style.setProperty('--story-photo-scale', (1.035 + (drift + .4) * .025).toFixed(4));
        });
        if (current !== active) {
            active = current;
            scenes.forEach((scene, i) => scene.classList.toggle('is-current', i === active));
            links.forEach(link => {
                const selected = Number(link.dataset.historyGo) === active;
                if (selected) link.setAttribute('aria-current', 'step'); else link.removeAttribute('aria-current');
                // Only the opening CTA is inside a fading scene; chapter navigation stays available.
                if (link.closest('[data-history-scene]')) link.tabIndex = active === 0 ? 0 : -1;
            });
            stage.style.setProperty('--story-nav-color', active % 2 ? '#44232b' : '#f4f0e8');
        }
    }

    function frame(time) {
        raf = 0;
        if (document.hidden) return;
        lenis?.raf(time);
        if (dirty || lenis?.isScrolling) { dirty = false; paint(); }
        if (lenis?.isScrolling) request();
    }
    function request() { if (!raf && !document.hidden) raf = requestAnimationFrame(frame); }
    function update() { dirty = true; request(); }

    function configure() {
        const previous = enabled;
        const header = document.querySelector('.adb-header');
        const headerTop = parseFloat(getComputedStyle(header).top) || 0;
        const top = header.offsetHeight + headerTop;
        view = Math.max(420, innerHeight - top);
        root.style.setProperty('--story-top', top + 'px');
        root.style.setProperty('--story-view', view + 'px');
        root.style.setProperty('--story-runway', ((scenes.length + .6) * view) + 'px');
        const fits = scenes.every(scene => scene.querySelector('.adb-history-composition').scrollHeight <= view);
        enabled = desktop.matches && !reduced.matches && !saveData && scenes.length > 1 && view >= 560 && fits;
        root.classList.toggle('is-immersive', enabled);
        if (enabled) scenes.forEach(scene => scene.style.removeProperty('--story-photo-pan'));
        if (enabled && typeof window.Lenis === 'function' && !lenis) {
            lenis = new window.Lenis({autoRaf: false, lerp: .115, smoothWheel: true, syncTouch: false, anchors: false, prevent: node => !!node.closest?.('dialog,textarea,select,[data-lenis-prevent]')});
            lenis.on('scroll', update);
        }
        if (!enabled && lenis) { lenis.destroy(); lenis = null; }
        window.adbSmoothScroll = lenis;
        start = sequence.getBoundingClientRect().top + scrollY - top;
        if (previous && !enabled && active >= 0) {
            const target = scenes[active].getBoundingClientRect().top + scrollY - top;
            window.scrollTo({top: target, behavior: 'instant'});
        }
        links.forEach(link => { if (!enabled) link.removeAttribute('tabindex'); });
        active = -1; update();
    }

    links.forEach(link => link.addEventListener('click', event => {
        if (!enabled || event.ctrlKey || event.metaKey || event.shiftKey || event.altKey) return;
        event.preventDefault();
        const index = Number(link.dataset.historyGo), ticket = ++navigation;
        const target = start + index * view;
        const complete = () => {
            if (ticket !== navigation || Math.abs(scrollY - target) > 3) return;
            history.replaceState(history.state, '', '#adb-history-' + index);
            const heading = scenes[index].querySelector('h1,h2');
            heading.setAttribute('tabindex', '-1');
            heading.focus({preventScroll: true});
            heading.addEventListener('blur', () => heading.removeAttribute('tabindex'), {once: true});
        };
        if (lenis) lenis.scrollTo(target, {duration: 1.15, easing: t => 1 - Math.pow(1 - t, 4), onComplete: complete});
        else {
            window.scrollTo({top: target, behavior: 'smooth'});
            let checks = 0;
            const settle = () => {
                if (ticket !== navigation) return;
                if (Math.abs(scrollY - target) <= 3) complete();
                else if (++checks < 180) requestAnimationFrame(settle);
            };
            requestAnimationFrame(settle);
        }
        update();
    }));
    function followHash() {
        if (!enabled) return;
        const match = location.hash.match(/^#adb-history-(\d+)$/);
        if (!match || Number(match[1]) >= scenes.length) return;
        const target = start + Number(match[1]) * view;
        if (lenis) lenis.scrollTo(target, {immediate: true});
        else window.scrollTo({top: target, behavior: 'instant'});
        update();
    }
    addEventListener('scroll', update, {passive: true});
    addEventListener('wheel', request, {passive: true});
    addEventListener('resize', configure);
    reduced.addEventListener('change', configure);
    desktop.addEventListener('change', configure);
    document.addEventListener('visibilitychange', () => { if (document.hidden) { cancelAnimationFrame(raf); raf = 0; } else update(); });
    addEventListener('pagehide', () => { cancelAnimationFrame(raf); raf = 0; lenis?.destroy(); lenis = null; });
    addEventListener('pageshow', () => { configure(); requestAnimationFrame(() => requestAnimationFrame(followHash)); });
    addEventListener('hashchange', followHash);
    document.fonts?.ready.then(configure);
    if ('ResizeObserver' in window) {
        const sizes = new ResizeObserver(() => requestAnimationFrame(configure));
        scenes.forEach(scene => sizes.observe(scene.querySelector('.adb-history-composition')));
    }
    configure();
}());
