<?php
/** The mapped story page extends the existing Chi siamo settings, without a second editor. */
defined( 'ABSPATH' ) || exit;

function adb_is_story_page() {
    $mapping = get_option( 'ticinoweb_page_mapping', array() );
    return ! is_front_page() && ! empty( $mapping['page_chi_siamo'] ) && is_page( absint( $mapping['page_chi_siamo'] ) );
}

function adb_story_data() {
    $data = get_option( 'adb_story', array() );
    return is_array( $data ) ? $data : array();
}

function adb_sanitize_story( $input ) {
    if ( null === $input ) { return adb_story_data(); }
    if ( ! is_array( $input ) ) { return adb_story_data(); }
    $out = array();
    foreach ( array( 'closing_title', 'closing_text' ) as $key ) {
        $value = $input[ $key ] ?? '';
        $out[ $key ] = is_scalar( $value ) ? sanitize_textarea_field( $value ) : '';
    }
    $out['opening_image'] = adb_valid_image_id( $input['opening_image'] ?? 0 );
    $out['chapters'] = array();
    foreach ( array_slice( is_array( $input['chapters'] ?? null ) ? $input['chapters'] : array(), 0, 6 ) as $chapter ) {
        if ( ! is_array( $chapter ) ) { continue; }
        $item = array();
        foreach ( array( 'title', 'text' ) as $key ) { $item[ $key ] = is_scalar( $chapter[ $key ] ?? null ) ? sanitize_textarea_field( $chapter[ $key ] ) : ''; }
        $item['image'] = adb_valid_image_id( $chapter['image'] ?? 0 );
        if ( $item['title'] || $item['text'] ) { $out['chapters'][] = $item; }
    }
    return $out;
}

add_action( 'admin_init', function () {
    register_setting( 'ticinoweb_settings_group', 'adb_story', array( 'type' => 'array', 'sanitize_callback' => 'adb_sanitize_story', 'default' => array() ) );
    add_settings_section( 'adb_story_section', '', 'adb_story_settings', 'ticinoweb_settings_group' );
} );

function adb_story_settings() {
    $data = adb_story_data();
    echo '<div id="adb-story-settings"><h3>' . esc_html__( 'Il racconto nella pagina Storia', 'amicidibacco' ) . '</h3><p>' . esc_html__( 'Titolo e introduzione qui sopra sono condivisi con la home. Qui scegli le fotografie e i capitoli del racconto completo. Il simbolo | nel titolo indica un a capo.', 'amicidibacco' ) . '</p>';
    adb_admin_media_field( 'adb_story[opening_image]', absint( $data['opening_image'] ?? 0 ), __( 'Fotografia di apertura della pagina', 'amicidibacco' ) );
    $chapters = $data['chapters'] ?? array();
    for ( $i = 0; $i < max( 3, count( $chapters ) ); $i++ ) {
        $chapter = $chapters[ $i ] ?? array();
        echo '<details class="adb-story-editor"' . ( 0 === $i ? ' open' : '' ) . '><summary>' . esc_html( str_replace( '|', ' ', $chapter['title'] ?? '' ) ?: sprintf( __( 'Capitolo %d', 'amicidibacco' ), $i + 1 ) ) . '</summary>';
        foreach ( array( 'title' => __( 'Titolo del capitolo', 'amicidibacco' ), 'text' => __( 'Racconto', 'amicidibacco' ) ) as $key => $label ) {
            $id = 'adb-story-' . $i . '-' . $key;
            echo '<p><label for="' . esc_attr( $id ) . '"><strong>' . esc_html( $label ) . '</strong></label><textarea class="large-text" id="' . esc_attr( $id ) . '" name="adb_story[chapters][' . absint( $i ) . '][' . esc_attr( $key ) . ']" rows="' . ( 'title' === $key ? '2' : '5' ) . '">' . esc_textarea( $chapter[ $key ] ?? '' ) . '</textarea></p>';
        }
        adb_admin_media_field( 'adb_story[chapters][' . $i . '][image]', absint( $chapter['image'] ?? 0 ), __( 'Fotografia del capitolo', 'amicidibacco' ) );
        echo '</details>';
    }
    foreach ( array( 'closing_title' => __( 'Titolo conclusivo', 'amicidibacco' ), 'closing_text' => __( 'Invito conclusivo', 'amicidibacco' ) ) as $key => $label ) {
        echo '<p><label for="adb-story-' . esc_attr( $key ) . '"><strong>' . esc_html( $label ) . '</strong></label><textarea class="large-text" id="adb-story-' . esc_attr( $key ) . '" name="adb_story[' . esc_attr( $key ) . ']" rows="3">' . esc_textarea( $data[ $key ] ?? '' ) . '</textarea></p>';
    }
    $mapping = get_option( 'ticinoweb_page_mapping', array() );
    if ( ! empty( $mapping['page_chi_siamo'] ) ) { echo '<p><a class="button" href="' . esc_url( get_permalink( $mapping['page_chi_siamo'] ) ) . '" target="_blank" rel="noopener">' . esc_html__( 'Apri la pagina Storia', 'amicidibacco' ) . '</a></p>'; }
    echo '</div>';
}

add_action( 'admin_enqueue_scripts', function () {
    if ( ! isset( $_GET['page'] ) || 'ticinoweb-cms' !== sanitize_key( wp_unslash( $_GET['page'] ) ) ) { return; }
    wp_enqueue_media();
    wp_enqueue_script( 'adb-story-admin', get_stylesheet_directory_uri() . '/assets/js/story-admin.js', array( 'jquery', 'media-editor' ), ADB_VERSION, true );
    wp_enqueue_style( 'adb-story-admin', get_stylesheet_directory_uri() . '/assets/css/story-admin.css', array(), ADB_VERSION );
} );

add_action( 'load-post.php', function () {
    $mapping = get_option( 'ticinoweb_page_mapping', array() );
    $id = isset( $_GET['post'] ) ? absint( $_GET['post'] ) : 0;
    if ( ! $id || $id !== absint( $mapping['page_chi_siamo'] ?? 0 ) ) { return; }
    // Keep the imported text archived, but give the editor only one obvious owner.
    remove_post_type_support( 'page', 'editor' );
    add_action( 'admin_notices', function () {
        echo '<div class="notice notice-info"><p>' . esc_html__( 'Il racconto di questa pagina si modifica in ticinoWEB CMS → Chi siamo. Titolo e introduzione sono condivisi con la home.', 'amicidibacco' ) . ' <a href="' . esc_url( admin_url( 'admin.php?page=ticinoweb-cms#chi-siamo' ) ) . '">' . esc_html__( 'Modifica la nostra storia', 'amicidibacco' ) . '</a></p></div>';
    } );
} );

function adb_story_photo( $id, $eager = false ) {
    if ( ! $id ) { return; }
    adb_photo( $id, 'full', array( 'class' => 'adb-history-image', 'loading' => $eager ? 'eager' : 'lazy', 'fetchpriority' => $eager ? 'high' : 'auto', 'decoding' => 'async', 'sizes' => '(max-width:900px) 1200px, 100vw', 'alt' => '', 'aria-hidden' => 'true' ) );
}

function adb_render_story() {
    $data = adb_story_data();
    $title = adb_home( 'story_title' ) ?: get_the_title();
    $chapters = array_values( array_filter( $data['chapters'] ?? array(), static function ( $item ) { return ! empty( $item['title'] ) || ! empty( $item['text'] ); } ) );
    $scenes = array_merge( array( array( 'title' => $title, 'text' => adb_home( 'story_text' ), 'image' => $data['opening_image'] ?? 0 ) ), $chapters );
    ob_start(); ?>
    <div class="adb-history" data-history>
        <div class="adb-history-sequence" data-history-sequence style="--story-scenes:<?php echo absint( count( $scenes ) ); ?>">
            <div class="adb-history-stage" data-history-stage>
                <?php foreach ( $scenes as $i => $scene ) : $paper = $i % 2; ?>
                <section id="adb-history-<?php echo absint( $i ); ?>" class="adb-history-scene <?php echo $paper ? 'adb-history-scene--paper' : 'adb-history-scene--dark'; ?> adb-history-scene--<?php echo absint( $i ); ?>" data-history-scene aria-labelledby="adb-history-title-<?php echo absint( $i ); ?>">
                    <figure class="adb-history-photo"><?php adb_story_photo( absint( $scene['image'] ?? 0 ), 0 === $i ); ?></figure>
                    <div class="adb-wrap adb-history-composition"><div class="adb-history-copy">
                        <?php $tag = 0 === $i ? 'h1' : 'h2'; echo '<' . $tag . ' id="adb-history-title-' . absint( $i ) . '">'; $lines = explode( '|', $scene['title'] ?? '' ); foreach ( $lines as $n => $line ) { if ( $n ) { echo '<br>'; } echo $n === count( $lines ) - 1 && count( $lines ) > 1 ? '<em>' . esc_html( $line ) . '</em>' : esc_html( $line ); } echo '</' . $tag . '>'; ?>
                        <div class="adb-history-prose"><?php echo wpautop( esc_html( $scene['text'] ?? '' ) ); ?></div>
                        <?php if ( 0 === $i && count( $scenes ) > 1 ) : ?><a href="#adb-history-1" class="adb-history-begin" data-history-go="1"><?php esc_html_e( 'Dentro la nostra storia', 'amicidibacco' ); ?><?php echo adb_icon( 'down' ); ?></a><?php endif; ?>
                    </div></div>
                </section>
                <?php endforeach; ?>
                <nav class="adb-history-nav adb-wrap" aria-label="<?php esc_attr_e( 'Capitoli della nostra storia', 'amicidibacco' ); ?>">
                    <?php foreach ( $scenes as $i => $scene ) : ?><a href="#adb-history-<?php echo absint( $i ); ?>" data-history-go="<?php echo absint( $i ); ?>"<?php echo 0 === $i ? ' aria-current="step"' : ''; ?>><?php echo esc_html( 0 === $i ? get_the_title() : explode( '|', $scene['title'] ?? '' )[0] ); ?></a><?php endforeach; ?>
                </nav>
            </div>
        </div>
        <?php if ( ! empty( $data['closing_title'] ) || ! empty( $data['closing_text'] ) ) : ?>
        <section class="adb-history-close adb-wrap" aria-labelledby="adb-history-close-title">
            <h2 id="adb-history-close-title"><?php echo nl2br( esc_html( str_replace( '|', "\n", $data['closing_title'] ?? '' ) ) ); ?></h2>
            <div><div class="adb-history-prose"><?php echo wpautop( esc_html( $data['closing_text'] ?? '' ) ); ?></div><div class="adb-history-actions"><a class="adb-button" href="<?php echo esc_url( wc_get_page_permalink( 'shop' ) ); ?>"><?php esc_html_e( 'Scopri i vini', 'amicidibacco' ); ?><?php echo adb_icon(); ?></a><a class="adb-link" href="<?php echo esc_url( adb_page_link( 'contact_page_id', '/contatti/' ) ); ?>"><?php esc_html_e( 'Vieni a trovarci', 'amicidibacco' ); ?><?php echo adb_icon(); ?></a></div><a class="adb-history-cellars adb-link" href="<?php echo esc_url( adb_page_link( 'wineries_page_id', '/produttori/' ) ); ?>"><?php esc_html_e( 'Incontra le cantine', 'amicidibacco' ); ?><?php echo adb_icon(); ?></a></div>
        </section>
        <?php endif; ?>
    </div>
    <?php return ob_get_clean();
}
