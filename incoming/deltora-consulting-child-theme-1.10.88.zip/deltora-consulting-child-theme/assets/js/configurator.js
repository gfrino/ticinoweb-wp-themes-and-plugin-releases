(function initDeltoraConfigurator(root, factory) {
  const api = factory(root && root.DeltoraConfiguratorEngine);

  if (typeof module === 'object' && module.exports) {
    module.exports = api;
  }

  if (root) {
    root.DeltoraConfigurator = api;
  }

  if (root && root.document) {
    root.document.addEventListener('DOMContentLoaded', () => {
      const container = root.document.querySelector('[data-configurator-root]');
      if (container) api.mount(container, root.deltoraConfiguratorConfig || {});
    });
  }
}(typeof window !== 'undefined' ? window : globalThis, function createConfigurator(engine) {
  'use strict';

  const stepsForMode = (mode) => (
    mode === 'guided'
      ? ['mode', 'guided-year-1', 'guided-year-2', 'guided-year-3', 'exceptional', 'sector', 'review', 'result']
      : ['mode', 'direct-values', 'exceptional', 'sector', 'review', 'result']
  );

  const createEmptyYear = () => ({
    label: '',
    ebitda: null,
    netIncome: null,
    taxes: null,
    financialCosts: null,
    financialIncome: null,
    tangibleDepreciation: null,
    intangibleAmortization: null,
    impairments: null,
  });

  const createInitialState = (mode = '') => ({
    mode: mode === 'guided' || mode === 'direct' ? mode : '',
    years: [createEmptyYear(), createEmptyYear(), createEmptyYear()],
    exceptional: '',
    sectorId: '',
    currentStep: 0,
    result: null,
  });

  const deriveEbitdas = (state) => state.years.map((year) => (
    state.mode === 'guided'
      ? engine.calculateAnnualEbitda(year)
      : Number(year.ebitda)
  ));

  const validateExercises = (state) => {
    const labels = state.years.map((year) => String(year.label || '').trim());
    const incompleteIndexes = [];

    state.years.forEach((year, index) => {
      const valueIsMissing = state.mode === 'direct'
        ? !Number.isFinite(Number(year.ebitda))
        : ['netIncome', 'taxes', 'financialCosts', 'financialIncome', 'tangibleDepreciation', 'intangibleAmortization', 'impairments']
          .some((key) => !Number.isFinite(Number(year[key])));

      if (!labels[index] || valueIsMissing) incompleteIndexes.push(index);
    });

    const duplicateYears = labels.filter((label, index) => (
      label && labels.indexOf(label) !== index
    ));

    return {
      valid: incompleteIndexes.length === 0 && duplicateYears.length === 0,
      duplicateYears: [...new Set(duplicateYears)],
      incompleteIndexes,
    };
  };

  const buildResult = (state, sector) => {
    const min = sector && typeof sector.min === 'number' ? sector.min : NaN;
    const max = sector && typeof sector.max === 'number' ? sector.max : NaN;
    return engine.calculateEstimate(deriveEbitdas(state), min, max);
  };

  const buildResultPayload = (state, email, privacy, honeypot) => ({
    email,
    privacy: Boolean(privacy),
    honeypot: honeypot || '',
    mode: state.mode,
    ebitdas: deriveEbitdas(state),
    year_labels: state.years.map((year) => String(year.label)),
    exceptional: state.exceptional,
    sector_id: state.sectorId,
  });

  const getContactUrl = (config) => String(config && config.contactUrl ? config.contactUrl : '#');
  const getPrivacyUrl = (config) => String(config && config.privacyUrl ? config.privacyUrl : '');

  const buildExceptionalWarning = (exceptional) => {
    if (exceptional === 'yes') {
      return 'Hai indicato che uno o più esercizi includono ricavi o costi eccezionali. Questi elementi possono influire sull’EBITDA medio. Contatta Deltora per verificarli e ottenere una stima più precisa.';
    }
    if (exceptional === 'unknown') {
      return 'Non sei sicuro che gli EBITDA inseriti includano ricavi o costi eccezionali. Questi elementi possono influire sull’EBITDA medio. Contatta Deltora per verificarli e ottenere una stima più precisa.';
    }
    return '';
  };

  const composeResultIntroduction = (main, alerts, explanation) => {
    const visibleAlerts = alerts.filter(Boolean);
    const alertGroup = visibleAlerts.length
      ? `<div class="deltora-result-alerts">${visibleAlerts.join('')}</div>`
      : '';
    return `${main}${alertGroup}<p>${explanation}</p>`;
  };

  const buildContactDraft = (state, sector, result, formatCurrency = (value) => engine.formatCHF(value)) => {
    const exceptionalLabels = {
      no: 'no',
      yes: 'sì',
      unknown: 'non sono sicuro',
    };
    const ebitdas = deriveEbitdas(state);
    const isUnclassified = !sector || sector.id === 'other';
    const sectorLabel = isUnclassified ? 'da identificare' : sector.label;
    const calculationLines = [
      `Settore: ${sectorLabel}`,
      ...ebitdas.map((value, index) => `EBITDA ${state.years[index].label}: ${formatCurrency(value)}`),
      `EBITDA medio: ${formatCurrency(result.average)}`,
      `Componenti straordinarie: ${exceptionalLabels[state.exceptional] || 'da verificare'}`,
    ];

    if (isUnclassified) {
      return [
        'Buongiorno,',
        'ho utilizzato il configuratore, ma non ho trovato un settore che rappresenti correttamente la mia azienda.',
        '',
        'ATTIVITÀ PRINCIPALE DELL’AZIENDA',
        '[Descrivi brevemente cosa fa l’azienda]',
        '',
        'DATI INSERITI NEL CONFIGURATORE',
        ...calculationLines,
        '',
        'Vorrei essere ricontattato/a per identificare il settore corretto e completare la stima del valore della mia azienda.',
      ].join('\n');
    }

    const lines = [
      'Richiedo un approfondimento sulla stima del valore della mia azienda.',
      '',
      ...calculationLines,
      '',
      'Vorrei essere ricontattato/a da Deltora per approfondire questi dati.',
    ];

    return lines.join('\n');
  };

  const getCompanyLookupStatus = (config) => ({
    enabled: Boolean(config && config.companyLookup && config.companyLookup.enabled),
    localClassifier: Boolean(config && config.companyLookup && config.companyLookup.local_classifier),
    aiEnabled: Boolean(config && config.companyLookup && config.companyLookup.ai_enabled),
  });

  const playViewTransition = (view, gsap, reducedMotion = false) => {
    if (!view || reducedMotion || !gsap || typeof gsap.fromTo !== 'function') return;

    gsap.fromTo(view, { autoAlpha: 0.72 }, {
      autoAlpha: 1,
      duration: 0.18,
      ease: 'power1.out',
      overwrite: true,
      clearProps: 'opacity,visibility',
    });
  };

  const validationControls = (form) => Array.from(form.querySelectorAll(
    'input[required], textarea[required], select[required], input[type="radio"]',
  ));

  const controlIsInvalid = (control, controls) => {
    if (!control || control.disabled) return false;
    if (control.type === 'radio') {
      return !controls.some((candidate) => candidate.type === 'radio' && candidate.name === control.name && candidate.checked);
    }
    if (control.type === 'checkbox') return !control.checked;
    if (control.validity && !control.validity.valid) return true;
    if (control.getAttribute?.('inputmode') === 'decimal') return engine.parseMoney(control.value) === null;
    return !String(control.value || '').trim();
  };

  const findInvalidControls = (form) => {
    const controls = validationControls(form);
    return controls.filter((control) => controlIsInvalid(control, controls));
  };

  const setControlInvalid = (control, invalid) => {
    if (!control) return;
    if (invalid) control.setAttribute?.('aria-invalid', 'true');
    else control.removeAttribute?.('aria-invalid');
    const container = control.closest?.('.deltora-money-field__control, .deltora-wizard-option, .deltora-consent') || control;
    container.classList?.toggle('is-invalid', Boolean(invalid));
  };

  const enableInlineValidation = (form) => {
    if (!form) return;
    form.noValidate = true;
    const refresh = (event) => {
      const target = event.target;
      const controls = validationControls(form);
      if (!target || !controls.includes(target)) return;
      const group = target.type === 'radio'
        ? controls.filter((control) => control.type === 'radio' && control.name === target.name)
        : [target];
      group.forEach((control) => setControlInvalid(control, controlIsInvalid(control, controls)));
    };
    form.addEventListener('input', refresh);
    form.addEventListener('change', refresh);
  };

  const escapeHTML = (value) => String(value ?? '').replace(/[&<>'"]/g, (character) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;',
  }[character]));

  const option = (name, value, title, description, checked = false) => `
    <label class="deltora-wizard-option">
      <input type="radio" name="${name}" value="${value}" ${checked ? 'checked' : ''}>
      <span><strong>${title}</strong><small>${description}</small></span>
    </label>`;

  const actions = (showBack = true, nextLabel = 'Continua') => `
    <div class="deltora-wizard-actions">
      ${showBack ? '<button class="deltora-button deltora-button--secondary" type="button" data-wizard-back>Indietro</button>' : ''}
      <button class="deltora-button deltora-button--primary" type="submit">${nextLabel}</button>
    </div>`;

  const restoreConfiguratorPosition = (container, options = {}) => {
    const schedule = options.requestAnimationFrame || ((callback) => callback());
    schedule(() => {
      container.scrollIntoView?.({
        behavior: options.reducedMotion ? 'auto' : 'smooth',
        block: 'start',
      });
    });
  };

  const moneyField = (field, yearIndex, value) => `
    <div class="deltora-money-field">
      <label for="year-${yearIndex}-${field.id}">${escapeHTML(field.label)}</label>
      <div class="deltora-money-field__control"><span>CHF</span><input id="year-${yearIndex}-${field.id}" name="${field.id}" inputmode="decimal" autocomplete="off" maxlength="30" value="${escapeHTML(value ?? '')}" required></div>
      <details><summary>Dove trovo questa voce?</summary><p>${escapeHTML(field.help)}</p></details>
    </div>`;

  const mount = (container, config) => {
    const initialMode = container.dataset.initialMode || '';
    const state = createInitialState(initialMode);
    if (initialMode) state.currentStep = 1;

    const view = container.querySelector('[data-configurator-view]');
    const messages = container.querySelector('[data-configurator-messages]');
    const progress = container.querySelector('[data-configurator-progress]');
    const stepLabel = container.querySelector('[data-configurator-step]');
    const changeMode = container.querySelector('[data-change-mode]');
    const reducedMotion = typeof window !== 'undefined'
      && window.matchMedia
      && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const motionEngine = typeof window !== 'undefined' ? window.gsap : null;

    const sectorById = (id) => (config.sectors || []).find((sector) => sector.id === id);
    const showError = (message) => {
      messages.innerHTML = message ? `<p role="alert">${escapeHTML(message)}</p>` : '';
      if (message) messages.focus?.();
    };

    const currentSteps = () => (state.mode ? stepsForMode(state.mode) : ['mode']);
    const currentStepId = () => currentSteps()[Math.min(state.currentStep, currentSteps().length - 1)];

    const renderMode = () => `
      <form data-wizard-form>
        <fieldset class="deltora-wizard-fieldset">
          <legend>Come vuoi procedere?</legend>
          <p class="deltora-wizard-intro">Scegli in base ai dati che hai già a disposizione.</p>
          <div class="deltora-wizard-options">
            ${option('mode', 'guided', 'Aiutami a calcolare l’EBITDA', 'Ho i bilanci o i dati contabili, ma non conosco ancora i tre EBITDA.', state.mode === 'guided')}
            ${option('mode', 'direct', 'Inserisco gli EBITDA già calcolati', 'Conosco già i valori di tre esercizi completi e calcolati con lo stesso criterio.', state.mode === 'direct')}
          </div>
        </fieldset>
        ${actions(false)}
      </form>`;

    const renderGuidedYear = (yearIndex) => {
      const year = state.years[yearIndex];
      return `
        <form data-wizard-form data-year-index="${yearIndex}">
          <fieldset class="deltora-wizard-fieldset">
            <legend>Esercizio ${yearIndex + 1} di 3</legend>
            <p class="deltora-wizard-intro">Inserisci le voci del conto economico. Usa valori positivi, tranne l’utile o la perdita che può essere negativo.</p>
            <div class="deltora-year-label"><label for="year-${yearIndex}-label">Anno o etichetta dell’esercizio</label><input id="year-${yearIndex}-label" name="label" maxlength="40" value="${escapeHTML(year.label)}" placeholder="Esempio: 2025" required></div>
            <div class="deltora-guided-fields">${(config.guidedFields || []).map((field) => moneyField(field, yearIndex, year[field.id])).join('')}</div>
            <div class="deltora-ebitda-live" aria-live="polite"><span>EBITDA calcolato</span><strong data-live-ebitda>${engine.formatCHF(engine.calculateAnnualEbitda(year))}</strong></div>
          </fieldset>
          ${actions(true)}
        </form>`;
    };

    const renderDirect = () => `
      <form data-wizard-form>
        <fieldset class="deltora-wizard-fieldset">
          <legend>Inserisci i tre EBITDA</legend>
          <p class="deltora-wizard-intro">Usa tre esercizi completi e valori calcolati con lo stesso criterio.</p>
          <div class="deltora-direct-years">
            ${state.years.map((year, index) => `<div class="deltora-direct-year"><h3>Esercizio ${index + 1}</h3><label for="direct-label-${index}">Anno o etichetta</label><input id="direct-label-${index}" name="label-${index}" maxlength="40" value="${escapeHTML(year.label)}" placeholder="202${index + 3}" required><label for="direct-value-${index}">EBITDA</label><div class="deltora-money-field__control"><span>CHF</span><input id="direct-value-${index}" name="ebitda-${index}" inputmode="decimal" maxlength="30" value="${escapeHTML(year.ebitda ?? '')}" required></div></div>`).join('')}
          </div>
        </fieldset>
        ${actions(true)}
      </form>`;

    const renderExceptional = () => `
      <form data-wizard-form>
        <fieldset class="deltora-wizard-fieldset">
          <legend>Ci sono ricavi o costi eccezionali?</legend>
          <p class="deltora-wizard-intro">Pensa a eventi che normalmente non si ripetono: vendita straordinaria di un bene, indennizzi, costi legali irripetibili o ristrutturazioni una tantum.</p>
          <div class="deltora-wizard-options deltora-wizard-options--compact">
            ${option('exceptional', 'no', 'No', 'I tre esercizi rappresentano l’attività ordinaria.', state.exceptional === 'no')}
            ${option('exceptional', 'yes', 'Sì', 'Uno o più esercizi includono componenti non ricorrenti.', state.exceptional === 'yes')}
            ${option('exceptional', 'unknown', 'Non lo so', 'Deltora potrà verificare e normalizzare i valori.', state.exceptional === 'unknown')}
          </div>
        </fieldset>
        ${actions(true)}
      </form>`;

    const renderSector = () => `
      <form data-wizard-form>
        <fieldset class="deltora-wizard-fieldset">
          <legend>Qual è l’attività principale dell’azienda?</legend>
          <p class="deltora-wizard-intro">La scelta del settore determina l’intervallo di multipli utilizzato per elaborare la stima indicativa.</p>
          <div class="deltora-wizard-options">
            ${(config.sectors || []).map((sector) => option('sector', sector.id, escapeHTML(sector.label), escapeHTML(sector.description), state.sectorId === sector.id)).join('')}
          </div>
        </fieldset>
        ${actions(true)}
      </form>`;

    const resultRows = () => deriveEbitdas(state).map((value, index) => `<tr><th scope="row">EBITDA ${escapeHTML(state.years[index].label)}</th><td>${engine.formatCHF(value)}</td></tr>`).join('');

    const renderReview = () => {
      const sector = sectorById(state.sectorId);
      const preliminary = sector ? buildResult(state, sector) : null;
      return `
        <form data-wizard-form>
          <div class="deltora-wizard-fieldset">
            <h3>Controlla i dati prima del calcolo</h3>
            <div class="deltora-review-grid">
              <table><tbody>${resultRows()}<tr><th scope="row">EBITDA medio</th><td>${engine.formatCHF(preliminary ? preliminary.average : 0)}</td></tr></tbody></table>
              <dl><div><dt>Modalità</dt><dd>${state.mode === 'guided' ? 'Calcolo guidato' : 'Inserimento diretto'}</dd></div><div><dt>Attività</dt><dd>${escapeHTML(sector ? sector.label : '')}</dd></div><div><dt>Eventi eccezionali</dt><dd>${state.exceptional === 'no' ? 'No' : (state.exceptional === 'yes' ? 'Sì' : 'Non lo so')}</dd></div><div><dt>Intervallo di multipli</dt><dd>${sector && sector.min !== null ? `${sector.min.toFixed(1)}x–${sector.max.toFixed(1)}x` : 'Disponibile dopo l’identificazione del settore'}</dd></div></dl>
            </div>
          </div>
          ${actions(true, 'Calcola la stima')}
        </form>`;
    };

    const renderResult = () => {
      const sector = sectorById(state.sectorId);
      const result = state.result || buildResult(state, sector);
      const exceptionalWarning = buildExceptionalWarning(state.exceptional);
      const warning = exceptionalWarning ? `<p class="deltora-result-warning">${escapeHTML(exceptionalWarning)}</p>` : '';
      const isUnclassified = sector && sector.id === 'other';
	  const privacyUrl = getPrivacyUrl(config);
	  const privacyConsent = privacyUrl
	    ? `Ho letto <a href="${escapeHTML(privacyUrl)}">l’informativa privacy</a> e acconsento al trattamento dell’indirizzo email necessario per ricevere questo risultato.`
	    : 'Acconsento al trattamento dell’indirizzo email necessario per ricevere questo risultato.';
      const resultExplanation = isUnclassified
        ? 'Abbiamo comunque calcolato l’EBITDA medio dei tre esercizi. Per completare la stima è necessario identificare il settore e il relativo intervallo di multipli.'
        : 'La stima deriva dall’EBITDA medio degli ultimi tre esercizi e dall’intervallo di multipli associato all’attività selezionata.';
      const main = result.estimable
        ? `<p class="deltora-result-range"><span>Valore operativo indicativo</span><strong>${engine.formatCHF(result.minimum)} – ${engine.formatCHF(result.maximum)}</strong></p>`
        : '';
      const unavailableWarning = result.estimable
        ? ''
        : (isUnclassified
          ? '<p class="deltora-result-unavailable"><strong>Non siamo riusciti ad associare con certezza la tua attività a un settore.</strong> Contatta Deltora per identificare il settore corretto e completare la stima.</p>'
          : '<p class="deltora-result-unavailable"><strong>Il metodo dei multipli EBITDA non produce una stima significativa.</strong> Questo non significa necessariamente che l’azienda non abbia valore: possono essere necessari altri metodi e un’analisi professionale.</p>');
      const introduction = composeResultIntroduction(main, [unavailableWarning, warning], resultExplanation);

      return `<div class="deltora-result"><h3>Stima indicativa della tua azienda</h3>${introduction}<table><tbody>${resultRows()}<tr><th scope="row">EBITDA medio</th><td>${engine.formatCHF(result.average)}</td></tr><tr><th scope="row">Attività</th><td>${escapeHTML(sector ? sector.label : '')}</td></tr></tbody></table><p class="deltora-result-disclaimer">Il risultato rappresenta una prima indicazione del valore operativo dell’azienda (Enterprise Value). Non include automaticamente debiti finanziari o liquidità e non costituisce una perizia, un’offerta di acquisto o una valutazione professionale definitiva. L’intervallo applicato ha finalità orientativa.</p><div class="deltora-wizard-actions"><button class="deltora-button deltora-button--secondary" type="button" data-wizard-back>Rivedi i dati</button><a class="deltora-button deltora-button--primary" href="#deltora-result-email">Invia il risultato via email</a></div>
		<section class="deltora-result-action" id="deltora-result-email"><h4>Ricevi il riepilogo via email</h4><p>La stima resta visibile qui anche se l’invio non dovesse riuscire.</p><form data-result-email-form><label for="result-email">Indirizzo email</label><input id="result-email" type="email" name="email" autocomplete="email" maxlength="254" required><label class="deltora-consent"><input type="checkbox" name="privacy" required><span>${privacyConsent}</span></label><label class="deltora-honeypot" aria-hidden="true">Sito web<input name="website" tabindex="-1" autocomplete="off"></label><button class="deltora-button deltora-button--primary" type="submit">Invia il risultato</button><p class="deltora-form-status" data-email-status aria-live="polite"></p></form></section>
        <section class="deltora-result-action deltora-result-action--contact"><h4>Vuoi approfondire la stima?</h4><p>Il contatto con Deltora è facoltativo e separato dall’invio del risultato.</p><a class="deltora-button deltora-button--secondary" href="${escapeHTML(getContactUrl(config))}" data-configurator-contact>Contatta Deltora</a></section></div>`;
    };

    const render = (restorePosition = false) => {
      showError('');
      const steps = currentSteps();
      const step = currentStepId();
      const displayStep = state.mode ? Math.max(1, state.currentStep) : 0;
      const total = state.mode ? steps.length - 1 : 1;
      stepLabel.textContent = state.mode ? `Passaggio ${displayStep} di ${total}` : 'Scegli il percorso';
      progress.style.transform = `scaleX(${state.mode ? Math.max(0.08, displayStep / total) : 0.08})`;
      changeMode.hidden = !state.mode || step === 'mode' || step === 'result';

      if (step === 'mode') view.innerHTML = renderMode();
      else if (step.startsWith('guided-year-')) view.innerHTML = renderGuidedYear(Number(step.at(-1)) - 1);
      else if (step === 'direct-values') view.innerHTML = renderDirect();
      else if (step === 'exceptional') view.innerHTML = renderExceptional();
      else if (step === 'sector') view.innerHTML = renderSector();
      else if (step === 'review') view.innerHTML = renderReview();
      else view.innerHTML = renderResult();

      playViewTransition(view, motionEngine, reducedMotion);
      bindCurrentView(step);
      view.querySelector('legend, h3, input')?.focus?.({ preventScroll: true });
      if (restorePosition) {
        restoreConfiguratorPosition(container, {
          reducedMotion,
          requestAnimationFrame: typeof window !== 'undefined' && window.requestAnimationFrame
            ? window.requestAnimationFrame.bind(window)
            : undefined,
        });
      }
    };

    const readMoney = (input) => engine.parseMoney(input.value);
    const collectStep = (step, form) => {
      if (step === 'mode') {
        const selected = form.querySelector('input[name="mode"]:checked');
        if (!selected) return 'Scegli una modalità per continuare.';
        state.mode = selected.value;
        state.currentStep = 0;
      } else if (step.startsWith('guided-year-')) {
        const index = Number(step.at(-1)) - 1;
        const nextYear = { ...state.years[index], label: form.elements.label.value.trim() };
        let missing = !nextYear.label;
        (config.guidedFields || []).forEach((field) => {
          const value = readMoney(form.elements[field.id]);
          if (value === null) missing = true;
          nextYear[field.id] = value;
        });
        if (missing) return 'Completa tutte le voci dell’esercizio prima di continuare.';
        if (state.years.some((year, yearIndex) => yearIndex !== index && year.label && year.label === nextYear.label)) return 'Ogni esercizio deve avere un anno o un’etichetta diversa.';
        state.years[index] = nextYear;
      } else if (step === 'direct-values') {
        const years = state.years.map((year, index) => ({ label: form.elements[`label-${index}`].value.trim(), ebitda: readMoney(form.elements[`ebitda-${index}`]) }));
        state.years = years;
        const validation = validateExercises(state);
        if (!validation.valid) return validation.duplicateYears.length ? 'Ogni esercizio deve avere un anno o un’etichetta diversa.' : 'Inserisci anno ed EBITDA per tutti e tre gli esercizi.';
      } else if (step === 'exceptional') {
        const selected = form.querySelector('input[name="exceptional"]:checked');
        if (!selected) return 'Indica se sono presenti eventi eccezionali.';
        state.exceptional = selected.value;
      } else if (step === 'sector') {
        const selected = form.querySelector('input[name="sector"]:checked');
        if (!selected) return 'Seleziona l’attività principale.';
        state.sectorId = selected.value;
      } else if (step === 'review') {
        state.result = buildResult(state, sectorById(state.sectorId));
      }
      return '';
    };

    const postResultEmail = async (payload) => {
      const body = new URLSearchParams({
        action: 'deltora_send_configurator_result',
        nonce: config.nonce || '',
        payload: JSON.stringify(payload),
      });
      const response = await fetch(config.ajaxUrl, {
        method: 'POST',
        credentials: 'same-origin',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
        body: body.toString(),
      });
      const json = await response.json();
      if (!response.ok || !json.success) throw new Error(json.data?.message || 'Invio non riuscito. Riprova.');
      return json.data.message;
    };

    const bindResultEmail = () => {
      const emailForm = view.querySelector('[data-result-email-form]');
      const status = view.querySelector('[data-email-status]');
      enableInlineValidation(emailForm);
      emailForm?.addEventListener('submit', async (event) => {
        event.preventDefault();
        const invalidControls = findInvalidControls(emailForm);
        validationControls(emailForm).forEach((control) => setControlInvalid(control, invalidControls.includes(control)));
        if (invalidControls.length) {
          status.textContent = 'Completa i campi evidenziati prima di inviare il risultato.';
          status.className = 'deltora-form-status is-error';
          invalidControls[0].focus?.();
          return;
        }
        const submit = emailForm.querySelector('button[type="submit"]');
        submit.disabled = true;
        submit.textContent = 'Invio in corso…';
        status.className = 'deltora-form-status';
        try {
          const payload = buildResultPayload(
            state,
            emailForm.elements.email.value.trim(),
            emailForm.elements.privacy.checked,
            emailForm.elements.website.value,
          );
          status.textContent = await postResultEmail(payload);
          status.classList.add('is-success');
        } catch (error) {
          status.textContent = error.message;
          status.classList.add('is-error');
        } finally {
          submit.disabled = false;
          submit.textContent = 'Invia il risultato';
        }
      });
    };

    const bindCurrentView = (step) => {
      const form = view.querySelector('[data-wizard-form]');
      enableInlineValidation(form);
      form?.addEventListener('submit', (event) => {
        event.preventDefault();
        const invalidControls = findInvalidControls(form);
        validationControls(form).forEach((control) => setControlInvalid(control, invalidControls.includes(control)));
        if (invalidControls.length) {
          showError('Completa i campi evidenziati prima di continuare.');
          invalidControls[0].focus?.();
          return;
        }
        const error = collectStep(step, form);
        if (error) { showError(error); return; }
        state.currentStep += 1;
        render(true);
      });

      view.querySelector('[data-wizard-back]')?.addEventListener('click', () => {
        state.currentStep = Math.max(0, state.currentStep - 1);
        render(true);
      });

      if (step.startsWith('guided-year-') && form) {
        const yearIndex = Number(step.at(-1)) - 1;
        form.addEventListener('input', () => {
          const values = {};
          (config.guidedFields || []).forEach((field) => { values[field.id] = readMoney(form.elements[field.id]) || 0; });
          form.querySelector('[data-live-ebitda]').textContent = engine.formatCHF(engine.calculateAnnualEbitda(values));
          state.years[yearIndex] = { ...state.years[yearIndex], ...values, label: form.elements.label.value.trim() };
        });
      }

      if (step === 'result') {
        bindResultEmail();
        view.querySelector('[data-configurator-contact]')?.addEventListener('click', () => {
          const sector = sectorById(state.sectorId);
          const result = state.result || buildResult(state, sector);
          const serializedDraft = JSON.stringify({
            createdAt: Date.now(),
            message: buildContactDraft(state, sector, result),
          });
          let stored = false;
          try {
            window.sessionStorage.setItem('deltoraConfiguratorContactDraft', serializedDraft);
            stored = true;
          } catch (error) {
            // Use a navigation-scoped fallback when browser storage is unavailable.
          }
          if (!stored) {
            window.name = `deltoraConfiguratorContactDraft:${serializedDraft}`;
          }
        });
      }
    };

    changeMode.addEventListener('click', () => {
      state.currentStep = 0;
      render(true);
    });

    render();
    return state;
  };

  return {
    stepsForMode,
    createInitialState,
    deriveEbitdas,
    validateExercises,
    buildResult,
    buildResultPayload,
    getContactUrl,
    buildExceptionalWarning,
    composeResultIntroduction,
    buildContactDraft,
    getCompanyLookupStatus,
    playViewTransition,
    findInvalidControls,
    setControlInvalid,
    enableInlineValidation,
    restoreConfiguratorPosition,
    mount,
  };
}));
