<?php
/**
 * Dormant company lookup and sector-classification boundary.
 *
 * No external request is made until a server-side provider, credentials and
 * the explicit activation flag are all present.
 *
 * @package DeltoraConsultingChildTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Return public capability flags without exposing secrets. */
function deltora_consulting_get_company_lookup_capabilities() {
	$has_zefix_credentials = defined( 'DELTORA_ZEFIX_USERNAME' )
		&& defined( 'DELTORA_ZEFIX_PASSWORD' )
		&& '' !== (string) DELTORA_ZEFIX_USERNAME
		&& '' !== (string) DELTORA_ZEFIX_PASSWORD;
	$lookup_requested = defined( 'DELTORA_COMPANY_LOOKUP_ENABLED' ) && true === DELTORA_COMPANY_LOOKUP_ENABLED;
	$provider         = apply_filters( 'deltora_company_lookup_provider', null );
	$has_ai_key       = defined( 'DELTORA_OPENAI_API_KEY' ) && '' !== (string) DELTORA_OPENAI_API_KEY;
	$has_ai_provider  = false !== has_filter( 'deltora_ai_sector_classifier' );

	return array(
		'enabled'          => $lookup_requested && $has_zefix_credentials && is_callable( $provider ),
		'local_classifier' => true,
		'ai_enabled'       => $has_ai_key && $has_ai_provider,
	);
}

/** Normalize text used only for local keyword matching. */
function deltora_consulting_normalize_company_purpose( $purpose ) {
	$text = sanitize_textarea_field( (string) $purpose );
	$text = function_exists( 'remove_accents' ) ? remove_accents( $text ) : $text;
	$text = function_exists( 'mb_strtolower' ) ? mb_strtolower( $text, 'UTF-8' ) : strtolower( $text );
	return preg_replace( '/\s+/', ' ', $text );
}

/**
 * Associate a company purpose with an active configured sector.
 *
 * Local keyword matches are preferred. AI is offered only through a future
 * server-side provider and its answer is constrained to active sector IDs.
 *
 * @param string                         $purpose Company purpose.
 * @param array<int,array<string,mixed>> $sectors Optional active sectors.
 * @return array{sector_id:string,source:string,confidence:float}
 */
function deltora_consulting_classify_company_purpose( $purpose, $sectors = array() ) {
	$sectors = ! empty( $sectors ) ? $sectors : deltora_consulting_get_active_sectors();
	$purpose = deltora_consulting_normalize_company_purpose( $purpose );
	$scores  = array();

	foreach ( $sectors as $sector ) {
		if ( 'other' === $sector['id'] || empty( $sector['enabled'] ) ) {
			continue;
		}
		$score = 0;
		foreach ( (array) ( $sector['keywords'] ?? array() ) as $keyword ) {
			$keyword = deltora_consulting_normalize_company_purpose( $keyword );
			if ( '' !== $keyword && false !== strpos( $purpose, $keyword ) ) {
				++$score;
			}
		}
		$scores[ $sector['id'] ] = $score;
	}

	arsort( $scores );
	$ids          = array_keys( $scores );
	$winning_id   = $ids[0] ?? '';
	$winning      = $scores[ $winning_id ] ?? 0;
	$second_score = isset( $ids[1] ) ? $scores[ $ids[1] ] : 0;
	$total        = array_sum( $scores );

	if ( $winning > 0 && $winning > $second_score ) {
		return array(
			'sector_id' => $winning_id,
			'source'    => 'local',
			'confidence'=> $total > 0 ? round( $winning / $total, 3 ) : 0.0,
		);
	}

	$capabilities = deltora_consulting_get_company_lookup_capabilities();
	if ( $capabilities['ai_enabled'] ) {
		$ai_provider = apply_filters( 'deltora_ai_sector_classifier', null );
		$ai_result   = is_callable( $ai_provider ) ? call_user_func( $ai_provider, $purpose, $sectors, $scores ) : null;
		$active_ids  = array_column( $sectors, 'id' );
		$ai_id       = is_array( $ai_result ) ? sanitize_key( $ai_result['sector_id'] ?? '' ) : sanitize_key( (string) $ai_result );
		if ( 'other' !== $ai_id && in_array( $ai_id, $active_ids, true ) ) {
			return array( 'sector_id' => $ai_id, 'source' => 'ai', 'confidence' => 0.5 );
		}
	}

	return array( 'sector_id' => 'other', 'source' => 'manual', 'confidence' => 0.0 );
}

/**
 * Delegate a future Zefix search to the configured server-side provider.
 *
 * @param string $query Company name or identifier.
 * @return array<int,array<string,mixed>>|WP_Error
 */
function deltora_consulting_search_companies( $query ) {
	$capabilities = deltora_consulting_get_company_lookup_capabilities();
	if ( ! $capabilities['enabled'] ) {
		return new WP_Error( 'company_lookup_disabled', 'La ricerca automatica non è ancora disponibile.' );
	}
	$query = sanitize_text_field( (string) $query );
	if ( strlen( $query ) < 2 ) {
		return new WP_Error( 'company_lookup_query', 'Inserisci almeno due caratteri.' );
	}
	$provider = apply_filters( 'deltora_company_lookup_provider', null );
	$result   = call_user_func( $provider, $query );
	return is_array( $result ) ? $result : new WP_Error( 'company_lookup_response', 'La ricerca automatica non ha restituito una risposta valida.' );
}
