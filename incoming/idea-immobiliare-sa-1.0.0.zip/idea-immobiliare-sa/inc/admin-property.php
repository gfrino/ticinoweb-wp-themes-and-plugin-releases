<?php
/**
 * Scheda immobile in bacheca: campi con etichette chiare, galleria con
 * selettore immagini (nessun ID da digitare), stato dell'annuncio e
 * colonne utili nell'elenco.
 *
 * @package Idea_Immobiliare_SA
 */

if (!defined('ABSPATH')) {
    exit;
}

add_action('add_meta_boxes_immobile', 'idea_immo_add_meta_boxes');
function idea_immo_add_meta_boxes()
{
    add_meta_box('idea_immo_data', __('Dati dell’immobile', 'idea-immobiliare-sa'), 'idea_immo_render_data_box', 'immobile', 'normal', 'high');
    add_meta_box('idea_immo_gallery', __('Foto dell’immobile', 'idea-immobiliare-sa'), 'idea_immo_render_gallery_box', 'immobile', 'normal', 'default');
    add_meta_box('idea_immo_status', __('Stato dell’annuncio', 'idea-immobiliare-sa'), 'idea_immo_render_status_box', 'immobile', 'side', 'high');
}

function idea_immo_render_status_box($post)
{
    wp_nonce_field('idea_immo_save', 'idea_immo_nonce');
    $status = idea_immo_status($post->ID);
    $offer  = idea_immo_offer($post->ID);
    echo '<p><label for="idea_immo_offer"><strong>' . esc_html__('Tipo di offerta', 'idea-immobiliare-sa') . '</strong></label><br>';
    echo '<select name="idea_immo_offer" id="idea_immo_offer" style="width:100%">';
    foreach (idea_immo_offers() as $key => $label) {
        echo '<option value="' . esc_attr($key) . '"' . selected($offer, $key, false) . '>' . esc_html($label) . '</option>';
    }
    echo '</select></p>';
    echo '<p><label for="idea_immo_status_sel"><strong>' . esc_html__('Stato', 'idea-immobiliare-sa') . '</strong></label><br>';
    echo '<select name="idea_immo_status" id="idea_immo_status_sel" style="width:100%">';
    foreach (idea_immo_statuses() as $key => $label) {
        echo '<option value="' . esc_attr($key) . '"' . selected($status, $key, false) . '>' . esc_html($label) . '</option>';
    }
    echo '</select></p>';
    echo '<p class="description">' . esc_html__('Gli immobili in archivio non compaiono nel catalogo, ma restano raggiungibili dal loro indirizzo.', 'idea-immobiliare-sa') . '</p>';
}

function idea_immo_render_data_box($post)
{
    echo '<style>.idea-fields{display:grid;grid-template-columns:repeat(auto-fit,minmax(230px,1fr));gap:12px 18px}.idea-fields label{font-weight:600;display:block;margin-bottom:3px}.idea-fields input{width:100%}.idea-fields small{color:#646970}</style>';
    echo '<div class="idea-fields">';
    foreach (idea_immo_fields() as $key => $f) {
        $val = get_post_meta($post->ID, $key, true);
        echo '<div><label for="' . esc_attr($key) . '">' . esc_html($f['label']) . '</label>';
        echo '<input type="' . ($f['type'] === 'number' ? 'number' : 'text') . '" id="' . esc_attr($key) . '" name="' . esc_attr($key) . '" value="' . esc_attr($val) . '"';
        if ($f['type'] === 'number') {
            echo ' min="0" step="' . esc_attr(isset($f['step']) ? $f['step'] : 'any') . '"';
        }
        echo '>';
        if ($f['help'] !== '') {
            echo '<small>' . esc_html($f['help']) . '</small>';
        }
        echo '</div>';
    }
    echo '</div>';

    $extra = get_post_meta($post->ID, '_idea_extra', true);
    $text = '';
    if (is_array($extra)) {
        foreach ($extra as $label => $value) {
            $text .= $label . ': ' . $value . "\n";
        }
    }
    echo '<p style="margin-top:16px"><label for="idea_immo_extra"><strong>' . esc_html__('Altri dati (facoltativo)', 'idea-immobiliare-sa') . '</strong></label><br>';
    echo '<textarea id="idea_immo_extra" name="idea_immo_extra" rows="3" style="width:100%" placeholder="' . esc_attr__("Una riga per dato, es.\nNumero piani: 5\nAnno di costruzione: 1976", 'idea-immobiliare-sa') . '">' . esc_textarea($text) . '</textarea></p>';
    echo '<p class="description">' . esc_html__('La descrizione dell’immobile si scrive nel grande campo di testo qui sopra; il riassunto breve (usato nelle schede del catalogo) in «Riassunto».', 'idea-immobiliare-sa') . '</p>';
}

function idea_immo_render_gallery_box($post)
{
    $ids = get_post_meta($post->ID, '_idea_gallery', true);
    $ids = is_array($ids) ? array_map('intval', $ids) : array();
    echo '<div id="idea-gallery" data-title="' . esc_attr__('Scegli le foto dell’immobile', 'idea-immobiliare-sa') . '" data-button="' . esc_attr__('Usa queste foto', 'idea-immobiliare-sa') . '">';
    echo '<input type="hidden" name="idea_immo_gallery" id="idea-gallery-input" value="' . esc_attr(implode(',', $ids)) . '">';
    echo '<ul class="idea-gallery-list" id="idea-gallery-list">';
    foreach ($ids as $id) {
        echo idea_immo_gallery_admin_item($id);
    }
    echo '</ul>';
    echo '<p><button type="button" class="button button-primary" id="idea-gallery-add">' . esc_html__('Aggiungi o cambia foto', 'idea-immobiliare-sa') . '</button> ';
    echo '<span class="description">' . esc_html__('Trascina le foto per cambiare l’ordine: la prima è la copertina.', 'idea-immobiliare-sa') . '</span></p>';
    echo '</div>';
}

function idea_immo_gallery_admin_item($id)
{
    $thumb = wp_get_attachment_image_url($id, 'thumbnail');
    if (!$thumb) {
        return '';
    }
    return '<li data-id="' . (int) $id . '"><img src="' . esc_url($thumb) . '" alt=""><button type="button" class="idea-gallery-remove" aria-label="' . esc_attr__('Rimuovi', 'idea-immobiliare-sa') . '">×</button></li>';
}

add_action('admin_enqueue_scripts', 'idea_immo_admin_assets');
function idea_immo_admin_assets($hook)
{
    $screen = get_current_screen();
    if (!$screen || $screen->post_type !== 'immobile' || !in_array($hook, array('post.php', 'post-new.php'), true)) {
        return;
    }
    wp_enqueue_media();
    wp_enqueue_script('jquery-ui-sortable');
    $dir = get_stylesheet_directory();
    $uri = get_stylesheet_directory_uri();
    wp_enqueue_style('idea-immo-admin', $uri . '/assets/css/admin.css', array(), (string) filemtime($dir . '/assets/css/admin.css'));
    wp_enqueue_script('idea-immo-admin', $uri . '/assets/js/admin-gallery.js', array('jquery', 'jquery-ui-sortable'), (string) filemtime($dir . '/assets/js/admin-gallery.js'), true);
}

add_action('save_post_immobile', 'idea_immo_save', 10, 2);
function idea_immo_save($post_id, $post)
{
    if (!isset($_POST['idea_immo_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['idea_immo_nonce'])), 'idea_immo_save')) {
        return;
    }
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }
    if (!current_user_can('edit_post', $post_id)) {
        return;
    }

    foreach (idea_immo_fields() as $key => $f) {
        if (!isset($_POST[$key])) {
            continue;
        }
        $raw = wp_unslash($_POST[$key]);
        if ($f['type'] === 'number') {
            $raw = str_replace(array("'", '’', ' '), '', (string) $raw);
            $val = ($raw === '' || !is_numeric($raw)) ? '' : (string) (float) $raw;
        } else {
            $val = sanitize_text_field($raw);
        }
        if ($val === '') {
            delete_post_meta($post_id, $key);
        } else {
            update_post_meta($post_id, $key, $val);
        }
    }

    if (isset($_POST['idea_immo_status'])) {
        $status = sanitize_key(wp_unslash($_POST['idea_immo_status']));
        update_post_meta($post_id, '_idea_status', isset(idea_immo_statuses()[$status]) ? $status : 'disponibile');
    }
    if (isset($_POST['idea_immo_offer'])) {
        $offer = sanitize_key(wp_unslash($_POST['idea_immo_offer']));
        update_post_meta($post_id, '_idea_offer', isset(idea_immo_offers()[$offer]) ? $offer : 'vendita');
    }

    if (isset($_POST['idea_immo_extra'])) {
        $extra = array();
        foreach (preg_split('/\r\n|\r|\n/', (string) wp_unslash($_POST['idea_immo_extra'])) as $line) {
            if (strpos($line, ':') === false) {
                continue;
            }
            list($label, $value) = array_map('trim', explode(':', $line, 2));
            if ($label !== '' && $value !== '') {
                $extra[sanitize_text_field($label)] = sanitize_text_field($value);
            }
        }
        if ($extra) {
            update_post_meta($post_id, '_idea_extra', $extra);
        } else {
            delete_post_meta($post_id, '_idea_extra');
        }
    }

    if (isset($_POST['idea_immo_gallery'])) {
        $ids = array_values(array_unique(array_filter(array_map('absint', explode(',', sanitize_text_field(wp_unslash($_POST['idea_immo_gallery'])))))));
        if ($ids) {
            update_post_meta($post_id, '_idea_gallery', $ids);
            set_post_thumbnail($post_id, $ids[0]);
        } else {
            delete_post_meta($post_id, '_idea_gallery');
        }
    }
}

/* Colonne dell'elenco: copertina, località, prezzo, stato. */
add_filter('manage_immobile_posts_columns', 'idea_immo_columns');
function idea_immo_columns($cols)
{
    $new = array();
    foreach ($cols as $key => $label) {
        if ($key === 'title') {
            $new['idea_thumb'] = '';
        }
        $new[$key] = $label;
        if ($key === 'title') {
            $new['idea_location'] = __('Località', 'idea-immobiliare-sa');
            $new['idea_price']    = __('Prezzo', 'idea-immobiliare-sa');
            $new['idea_status']   = __('Stato', 'idea-immobiliare-sa');
        }
    }
    return $new;
}

add_action('manage_immobile_posts_custom_column', 'idea_immo_column_content', 10, 2);
function idea_immo_column_content($col, $post_id)
{
    switch ($col) {
        case 'idea_thumb':
            echo get_the_post_thumbnail($post_id, array(60, 40), array('style' => 'width:60px;height:40px;object-fit:cover;border-radius:3px'));
            break;
        case 'idea_location':
            echo esc_html(idea_immo_location($post_id));
            break;
        case 'idea_price':
            echo esc_html(idea_immo_price_label($post_id));
            break;
        case 'idea_status':
            $st = idea_immo_status($post_id);
            echo esc_html(idea_immo_statuses()[$st]);
            break;
    }
}

add_filter('manage_edit-immobile_sortable_columns', function ($cols) {
    $cols['idea_price'] = 'idea_price';
    return $cols;
});
add_action('pre_get_posts', function ($q) {
    if (is_admin() && $q->is_main_query() && $q->get('post_type') === 'immobile' && $q->get('orderby') === 'idea_price') {
        $q->set('meta_key', '_idea_price');
        $q->set('orderby', 'meta_value_num');
    }
});
