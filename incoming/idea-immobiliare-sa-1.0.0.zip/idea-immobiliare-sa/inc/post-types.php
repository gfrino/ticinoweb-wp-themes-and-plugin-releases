<?php
/**
 * Tipi di contenuto del catalogo: Immobili (con zona e categoria) e Promozioni.
 * Sono dati davvero specifici di questo cliente (README.md → Inventario Input First):
 * il parent non ha un catalogo con campi e tassonomie.
 *
 * @package Idea_Immobiliare_SA
 */

if (!defined('ABSPATH')) {
    exit;
}

add_action('init', 'idea_immo_register_types', 5);
function idea_immo_register_types()
{
    register_post_type('immobile', array(
        'labels' => array(
            'name'               => __('Immobili', 'idea-immobiliare-sa'),
            'singular_name'      => __('Immobile', 'idea-immobiliare-sa'),
            'menu_name'          => __('Immobili', 'idea-immobiliare-sa'),
            'add_new'            => __('Aggiungi immobile', 'idea-immobiliare-sa'),
            'add_new_item'       => __('Aggiungi un immobile', 'idea-immobiliare-sa'),
            'edit_item'          => __('Modifica immobile', 'idea-immobiliare-sa'),
            'new_item'           => __('Nuovo immobile', 'idea-immobiliare-sa'),
            'view_item'          => __('Vedi immobile', 'idea-immobiliare-sa'),
            'all_items'          => __('Tutti gli immobili', 'idea-immobiliare-sa'),
            'search_items'       => __('Cerca immobili', 'idea-immobiliare-sa'),
            'not_found'          => __('Nessun immobile trovato.', 'idea-immobiliare-sa'),
            'not_found_in_trash' => __('Nessun immobile nel cestino.', 'idea-immobiliare-sa'),
        ),
        'public'        => true,
        'has_archive'   => 'immobili',
        'rewrite'       => array('slug' => 'immobile', 'with_front' => false),
        'menu_position' => 5,
        'menu_icon'     => 'dashicons-admin-home',
        'supports'      => array('title', 'editor', 'thumbnail', 'excerpt'),
        'show_in_rest'  => true,
    ));

    register_post_type('promozione', array(
        'labels' => array(
            'name'               => __('Promozioni', 'idea-immobiliare-sa'),
            'singular_name'      => __('Promozione', 'idea-immobiliare-sa'),
            'menu_name'          => __('Promozioni', 'idea-immobiliare-sa'),
            'add_new'            => __('Aggiungi promozione', 'idea-immobiliare-sa'),
            'add_new_item'       => __('Aggiungi una promozione', 'idea-immobiliare-sa'),
            'edit_item'          => __('Modifica promozione', 'idea-immobiliare-sa'),
            'all_items'          => __('Tutte le promozioni', 'idea-immobiliare-sa'),
            'not_found'          => __('Nessuna promozione trovata.', 'idea-immobiliare-sa'),
            'not_found_in_trash' => __('Nessuna promozione nel cestino.', 'idea-immobiliare-sa'),
        ),
        'public'        => true,
        'has_archive'   => 'promozioni',
        'rewrite'       => array('slug' => 'promozione', 'with_front' => false),
        'menu_position' => 6,
        'menu_icon'     => 'dashicons-building',
        'supports'      => array('title', 'editor', 'thumbnail', 'excerpt'),
        'show_in_rest'  => true,
    ));

    register_taxonomy('zona', array('immobile'), array(
        'labels' => array(
            'name'          => __('Zone', 'idea-immobiliare-sa'),
            'singular_name' => __('Zona', 'idea-immobiliare-sa'),
            'all_items'     => __('Tutte le zone', 'idea-immobiliare-sa'),
            'add_new_item'  => __('Aggiungi zona', 'idea-immobiliare-sa'),
            'edit_item'     => __('Modifica zona', 'idea-immobiliare-sa'),
        ),
        'public'            => true,
        'hierarchical'      => true,
        'show_admin_column' => true,
        'show_in_rest'      => true,
        'rewrite'           => array('slug' => 'zona', 'with_front' => false),
    ));

    register_taxonomy('categoria_immobile', array('immobile'), array(
        'labels' => array(
            'name'          => __('Categorie', 'idea-immobiliare-sa'),
            'singular_name' => __('Categoria', 'idea-immobiliare-sa'),
            'all_items'     => __('Tutte le categorie', 'idea-immobiliare-sa'),
            'add_new_item'  => __('Aggiungi categoria', 'idea-immobiliare-sa'),
            'edit_item'     => __('Modifica categoria', 'idea-immobiliare-sa'),
        ),
        'public'            => true,
        'hierarchical'      => true,
        'show_admin_column' => true,
        'show_in_rest'      => true,
        'rewrite'           => array('slug' => 'categoria', 'with_front' => false),
    ));
}

/**
 * Zone e categorie di partenza (le stesse del vecchio sito). Una sola volta;
 * poi si gestiscono da Immobili → Zone / Categorie.
 */
add_action('init', 'idea_immo_seed_terms', 20);
function idea_immo_seed_terms()
{
    if (get_option('idea_immo_terms_seeded') === '1') {
        return;
    }
    $zones = array('Bellinzonese', 'Locarnese', 'Luganese', 'Mendrisiotto', 'Mesolcina', 'Riviera', 'Val di Blenio', 'Altro');
    foreach ($zones as $zone) {
        if (!term_exists($zone, 'zona')) {
            wp_insert_term($zone, 'zona');
        }
    }
    $cats = array('Appartamenti', 'Case', 'Ville', 'Locali commerciali', 'Attici', 'Terreni', 'Rustici', 'Stabili di reddito');
    foreach ($cats as $cat) {
        if (!term_exists($cat, 'categoria_immobile')) {
            wp_insert_term($cat, 'categoria_immobile');
        }
    }
    update_option('idea_immo_terms_seeded', '1', false);
}

/** Dopo l'attivazione del tema gli URL del catalogo devono funzionare subito. */
add_action('after_switch_theme', function () {
    idea_immo_register_types();
    flush_rewrite_rules(false);
});

/** Breadcrumb del parent: aggiunge il livello "Immobili" / "Promozioni". */
add_filter('ticinoweb_seo_breadcrumb_items', 'idea_immo_breadcrumb_items');
function idea_immo_breadcrumb_items($items)
{
    $map = array('immobile' => 'immobile', 'promozione' => 'promozione');
    $type = is_singular() ? get_post_type() : '';
    if (isset($map[$type]) && count($items) === 2) {
        $obj = get_post_type_object($type);
        $archive = array('name' => $obj->labels->name, 'url' => get_post_type_archive_link($type));
        array_splice($items, 1, 0, array($archive));
    } elseif (is_tax(array('zona', 'categoria_immobile')) && count($items) === 2) {
        $obj = get_post_type_object('immobile');
        array_splice($items, 1, 0, array(array('name' => $obj->labels->name, 'url' => get_post_type_archive_link('immobile'))));
    }
    return $items;
}
