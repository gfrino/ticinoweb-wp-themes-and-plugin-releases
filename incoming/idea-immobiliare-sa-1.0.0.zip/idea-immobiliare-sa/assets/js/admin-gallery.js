/**
 * Galleria dell'immobile in bacheca: selettore media, ordine con trascinamento.
 */
(function ($) {
  'use strict';

  var box = $('#idea-gallery');
  if (!box.length || !window.wp || !wp.media) return;

  var input = $('#idea-gallery-input');
  var list = $('#idea-gallery-list');
  var frame;

  function sync() {
    var ids = [];
    list.children('li').each(function () { ids.push($(this).data('id')); });
    input.val(ids.join(','));
  }

  function item(id, url) {
    return $('<li/>').attr('data-id', id)
      .append($('<img/>').attr({ src: url, alt: '' }))
      .append($('<button/>').attr({ type: 'button', 'aria-label': 'Rimuovi' }).addClass('idea-gallery-remove').text('×'));
  }

  list.sortable({ update: sync, tolerance: 'pointer' });

  list.on('click', '.idea-gallery-remove', function () {
    $(this).closest('li').remove();
    sync();
  });

  $('#idea-gallery-add').on('click', function (e) {
    e.preventDefault();
    if (!frame) {
      frame = wp.media({
        title: box.data('title'),
        button: { text: box.data('button') },
        library: { type: 'image' },
        multiple: 'add'
      });
      frame.on('open', function () {
        var sel = frame.state().get('selection');
        list.children('li').each(function () {
          var att = wp.media.attachment($(this).data('id'));
          att.fetch();
          sel.add(att);
        });
      });
      frame.on('select', function () {
        var sel = frame.state().get('selection');
        var existing = {};
        list.children('li').each(function () { existing[$(this).data('id')] = $(this); });
        var next = [];
        sel.each(function (att) {
          var id = att.get('id');
          if (existing[id]) { next.push(existing[id]); return; }
          var sizes = att.get('sizes') || {};
          var url = (sizes.thumbnail || {}).url || att.get('url');
          next.push(item(id, url));
        });
        list.empty().append(next);
        sync();
      });
    }
    frame.open();
  });
})(jQuery);
