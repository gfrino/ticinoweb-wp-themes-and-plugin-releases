<?php
/**
 * Luismacchine child theme bootstrap.
 *
 * @package LuismacchineChildTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'LUISMACCHINE_THEME_VERSION', wp_get_theme()->get( 'Version' ) );
define( 'LUISMACCHINE_GSAP_VERSION', '3.15.0' );
define( 'LUISMACCHINE_VEHICLE_POST_TYPE', 'vetrina-auto' );
define( 'LUISMACCHINE_PART_POST_TYPE', 'ricambio' );

require_once get_stylesheet_directory() . '/inc/catalog.php';
require_once get_stylesheet_directory() . '/inc/home-cms.php';
require_once get_stylesheet_directory() . '/inc/page-routing.php';
require_once get_stylesheet_directory() . '/inc/services.php';
require_once get_stylesheet_directory() . '/inc/site-content.php';
require_once get_stylesheet_directory() . '/inc/design-settings.php';
require_once get_stylesheet_directory() . '/inc/consent.php';
require_once get_stylesheet_directory() . '/inc/tutti-sync.php';
require_once get_stylesheet_directory() . '/inc/tutti-public-connector.php';
require_once get_stylesheet_directory() . '/inc/tutti-sync-media.php';

/**
 * Remove the parent's unconditional Google Fonts preconnect because this child
 * uses only self-hosted fonts. The parent exposes no named callback for it.
 *
 * @return void
 */
function luismacchine_remove_remote_font_hints() {
	global $wp_filter;

	if ( empty( $wp_filter['wp_head']->callbacks[0] ) ) {
		return;
	}

	foreach ( $wp_filter['wp_head']->callbacks[0] as $callback ) {
		if ( ! isset( $callback['function'] ) || ! $callback['function'] instanceof Closure ) {
			continue;
		}

		$reflection = new ReflectionFunction( $callback['function'] );
		if ( get_template_directory() . '/functions.php' === $reflection->getFileName() && 73 === $reflection->getStartLine() ) {
			remove_action( 'wp_head', $callback['function'], 0 );
		}
	}
}
add_action( 'after_setup_theme', 'luismacchine_remove_remote_font_hints', 100 );

/**
 * Load the parent and child assets in the correct order.
 *
 * @return void
 */
function luismacchine_child_enqueue_assets() {
	$parent_theme = wp_get_theme( get_template() );
	$child_theme  = wp_get_theme();
	$script_dependencies = array();

	wp_dequeue_style( 'poppins-font' );
	wp_deregister_style( 'poppins-font' );
	wp_dequeue_style( 'ticinoweb-ai-style' );
	wp_deregister_style( 'ticinoweb-ai-style' );
	wp_dequeue_script( 'ticinoweb-ai-main' );

	wp_enqueue_style(
		'ticinoweb-ai-parent-style',
		get_template_directory_uri() . '/style.css',
		array(),
		$parent_theme->get( 'Version' )
	);

	wp_enqueue_style(
		'luismacchine-child-style',
		get_stylesheet_uri(),
		array( 'ticinoweb-ai-parent-style' ),
		$child_theme->get( 'Version' )
	);

	wp_enqueue_style(
		'luismacchine-site',
		get_stylesheet_directory_uri() . '/assets/css/luismacchine.css',
		array( 'luismacchine-child-style' ),
		$child_theme->get( 'Version' )
	);

	if ( is_page( 'privacy' ) ) {
		wp_enqueue_style( 'luismacchine-privacy', get_stylesheet_directory_uri() . '/assets/css/privacy.css', array( 'luismacchine-site' ), $child_theme->get( 'Version' ) );
	}

	if ( ! is_front_page() && ( luismacchine_is_page( 'servizi' ) || luismacchine_is_page( 'chi-siamo' ) || luismacchine_is_page( 'contatti' ) || is_post_type_archive( array( LUISMACCHINE_VEHICLE_POST_TYPE, LUISMACCHINE_PART_POST_TYPE ) ) || is_singular( array( LUISMACCHINE_VEHICLE_POST_TYPE, LUISMACCHINE_PART_POST_TYPE ) ) ) ) {
		wp_enqueue_style( 'luismacchine-interior-motion', get_stylesheet_directory_uri() . '/assets/css/interior-motion.css', array( 'luismacchine-site' ), $child_theme->get( 'Version' ) );
		wp_enqueue_script( 'luismacchine-interior-motion', get_stylesheet_directory_uri() . '/assets/js/interior-motion.js', array(), $child_theme->get( 'Version' ), true );
	}

	if ( get_option( 'tw_cookie_banner_enable' ) ) {
		wp_enqueue_style(
			'luismacchine-cookie-consent',
			get_stylesheet_directory_uri() . '/assets/css/cookie-consent.css',
			array( 'luismacchine-site' ),
			$child_theme->get( 'Version' )
		);
	}

	if ( luismacchine_is_page( 'contatti' ) ) {
		wp_enqueue_style(
			'luismacchine-contact-hours',
			get_stylesheet_directory_uri() . '/assets/css/contact-hours.css',
			array( 'luismacchine-site' ),
			$child_theme->get( 'Version' )
		);
		wp_enqueue_script(
			'luismacchine-contact-hours',
			get_stylesheet_directory_uri() . '/assets/js/contact-hours.js',
			array(),
			$child_theme->get( 'Version' ),
			true
		);
	}

	if ( luismacchine_is_page( 'servizi' ) ) {
		wp_enqueue_style(
			'luismacchine-services',
			get_stylesheet_directory_uri() . '/assets/css/services.css',
			array( 'luismacchine-site' ),
			$child_theme->get( 'Version' )
		);
		wp_enqueue_script(
			'luismacchine-services',
			get_stylesheet_directory_uri() . '/assets/js/services.js',
			array(),
			$child_theme->get( 'Version' ),
			true
		);
	}

	if ( is_front_page() ) {
		wp_enqueue_style(
			'luismacchine-home',
			get_stylesheet_directory_uri() . '/assets/css/home.css',
			array( 'luismacchine-site' ),
			$child_theme->get( 'Version' )
		);
	}

	if ( is_post_type_archive( array( LUISMACCHINE_VEHICLE_POST_TYPE, LUISMACCHINE_PART_POST_TYPE ) ) ) {
		wp_enqueue_style(
			'luismacchine-catalog-archive',
			get_stylesheet_directory_uri() . '/assets/css/catalog-archive.css',
			array( 'luismacchine-site' ),
			$child_theme->get( 'Version' )
		);
		wp_enqueue_script(
			'luismacchine-catalog-filters',
			get_stylesheet_directory_uri() . '/assets/js/catalog-filters.js',
			array( 'luismacchine-site' ),
			$child_theme->get( 'Version' ),
			true
		);
	}

	if ( is_singular( array( LUISMACCHINE_VEHICLE_POST_TYPE, LUISMACCHINE_PART_POST_TYPE ) ) ) {
		wp_enqueue_style(
			'luismacchine-catalog-detail',
			get_stylesheet_directory_uri() . '/assets/css/catalog-detail.css',
			array( 'luismacchine-site' ),
			$child_theme->get( 'Version' )
		);
		wp_enqueue_script(
			'luismacchine-catalog-detail',
			get_stylesheet_directory_uri() . '/assets/js/catalog-detail.js',
			array(),
			$child_theme->get( 'Version' ),
			true
		);
	}

	wp_register_script(
		'luismacchine-gsap',
		get_stylesheet_directory_uri() . '/assets/vendor/gsap/gsap.min.js',
		array(),
		LUISMACCHINE_GSAP_VERSION,
		true
	);

	wp_register_script(
		'luismacchine-scroll-trigger',
		get_stylesheet_directory_uri() . '/assets/vendor/gsap/ScrollTrigger.min.js',
		array( 'luismacchine-gsap' ),
		LUISMACCHINE_GSAP_VERSION,
		true
	);

	if ( is_front_page() ) {
		$script_dependencies[] = 'luismacchine-scroll-trigger';
	}

	wp_enqueue_script(
		'luismacchine-site',
		get_stylesheet_directory_uri() . '/assets/js/luismacchine.js',
		$script_dependencies,
		$child_theme->get( 'Version' ),
		true
	);

	wp_localize_script(
		'luismacchine-site',
		'luismacchineTheme',
		array(
			'strings'  => array(
				'menuOpen'    => __( 'Apri il menu', 'luismacchine-child-theme' ),
				'menuClose'   => __( 'Chiudi il menu', 'luismacchine-child-theme' ),
				'filtersOpen' => __( 'Mostra i filtri', 'luismacchine-child-theme' ),
			),
		)
	);
}
add_action( 'wp_enqueue_scripts', 'luismacchine_child_enqueue_assets', 20 );

/**
 * Add project image sizes.
 *
 * @return void
 */
function luismacchine_child_setup() {
	add_image_size( 'luismacchine-card', 960, 640, true );
	add_image_size( 'luismacchine-gallery', 1600, 1067, false );
	load_child_theme_textdomain( 'luismacchine-child-theme', get_stylesheet_directory() . '/languages' );
}
add_action( 'after_setup_theme', 'luismacchine_child_setup', 20 );

/**
 * Return a URL for a child-theme asset.
 *
 * @param string $path Relative asset path.
 * @return string
 */
function luismacchine_asset_url( $path ) {
	return trailingslashit( get_stylesheet_directory_uri() ) . ltrim( $path, '/' );
}

/**
 * Return the selected homepage image attachment ID.
 *
 * @param string $field    Media setting key.
 * @return int
 */
function luismacchine_home_image_mime_allowed( $mime ) {
	return in_array( $mime, array( 'image/jpeg', 'image/png', 'image/webp', 'image/avif' ), true );
}

/**
 * Return the selected homepage image attachment ID.
 *
 * @param string $field Media setting key.
 * @return int
 */
function luismacchine_home_image_id( $field ) {
	$media = get_option( 'luismacchine_home_media', array() );
	$id    = isset( $media[ $field ] ) ? absint( $media[ $field ] ) : 0;
	$mime  = $id ? get_post_mime_type( $id ) : '';

	return luismacchine_home_image_mime_allowed( $mime ) ? $id : 0;
}

/**
 * Return a selected homepage image URL or its packaged fallback.
 *
 * @param string $field    Media setting key.
 * @param string $fallback Fallback URL.
 * @param string $size     Registered WordPress image size.
 * @return string
 */
function luismacchine_home_image_url( $field, $fallback = '', $size = 'full' ) {
	$id  = luismacchine_home_image_id( $field );
	$url = $id ? wp_get_attachment_image_url( $id, $size ) : false;

	return $url ? $url : $fallback;
}

/**
 * Connect the parent CMS primary color to the child theme's accent tokens.
 *
 * @return void
 */
function luismacchine_apply_cms_palette() {
	$primary = sanitize_hex_color( get_option( 'ticinoweb_palette_primary', '#D6B35A' ) );
	if ( ! $primary ) {
		return;
	}

	$hex = ltrim( $primary, '#' );
	if ( 3 === strlen( $hex ) ) {
		$hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
	}
	$rgb = array_map( 'hexdec', str_split( $hex, 2 ) );
	if ( 3 === count( $rgb ) ) {
		$light = array_map(
			static function ( $channel ) {
				return (int) round( $channel + ( 255 - $channel ) * 0.3 );
			},
			$rgb
		);
		$deep = array_map(
			static function ( $channel ) {
				return (int) round( $channel * 0.52 );
			},
			$rgb
		);
		$css = sprintf(
			':root{--lm-gold:%1$s;--lm-gold-rgb:%8$d,%9$d,%10$d;--lm-gold-light:#%2$02X%3$02X%4$02X;--lm-gold-light-rgb:%11$d,%12$d,%13$d;--lm-gold-deep:#%5$02X%6$02X%7$02X;--lm-gold-deep-rgb:%14$d,%15$d,%16$d;--lm-border:rgba(%8$d,%9$d,%10$d,.24)}',
			$primary,
			$light[0],
			$light[1],
			$light[2],
			$deep[0],
			$deep[1],
			$deep[2],
			$rgb[0],
			$rgb[1],
			$rgb[2],
			$light[0],
			$light[1],
			$light[2],
			$deep[0],
			$deep[1],
			$deep[2]
		);
		wp_add_inline_style( 'luismacchine-site', $css );
	}
}
add_action( 'wp_enqueue_scripts', 'luismacchine_apply_cms_palette', 30 );

/**
 * Place Luismacchine catalog screens inside the existing ticinoWEB CMS menu.
 *
 * @param array  $args      Post type arguments.
 * @param string $post_type Post type key.
 * @return array
 */
function luismacchine_catalog_admin_menu_parent( $args, $post_type ) {
	if ( in_array( $post_type, array( LUISMACCHINE_VEHICLE_POST_TYPE, LUISMACCHINE_PART_POST_TYPE ), true ) ) {
		$args['show_in_menu'] = 'ticinoweb-cms';
		if ( isset( $args['supports'] ) && is_array( $args['supports'] ) ) {
			$args['supports'] = array_values( array_diff( $args['supports'], array( 'editor', 'excerpt', 'custom-fields', 'page-attributes' ) ) );
		}
		if ( LUISMACCHINE_PART_POST_TYPE === $post_type ) {
			$args['supports'] = array_unique( array_merge( isset( $args['supports'] ) && is_array( $args['supports'] ) ? $args['supports'] : array( 'title', 'thumbnail' ), array( 'editor' ) ) );
		}
	}

	return $args;
}
add_filter( 'register_post_type_args', 'luismacchine_catalog_admin_menu_parent', 10, 2 );

/**
 * Keep the parent CMS landing page available as the first submenu item.
 * WordPress may create the first submenu from the child catalog post types,
 * replacing the automatic self-link for the top-level CMS page.
 *
 * @return void
 */
function luismacchine_restore_cms_menu_link() {
	global $submenu;

	if ( ! function_exists( 'ticinoweb_settings_page' ) || empty( $submenu['ticinoweb-cms'] ) ) {
		return;
	}

	$cms_link = array(
		__( 'ticinoWEB CMS', 'ticinoweb-ai-theme' ),
		'edit_pages',
		'ticinoweb-cms',
	);

	foreach ( $submenu['ticinoweb-cms'] as $index => $item ) {
		if ( isset( $item[2] ) && 'ticinoweb-cms' === $item[2] ) {
			$cms_link = $item;
			unset( $submenu['ticinoweb-cms'][ $index ] );
			break;
		}
	}

	array_unshift( $submenu['ticinoweb-cms'], $cms_link );
	$submenu['ticinoweb-cms'] = array_values( $submenu['ticinoweb-cms'] );
}
add_action( 'admin_menu', 'luismacchine_restore_cms_menu_link', 99 );

/**
 * Return the configured logo or the packaged official fallback.
 *
 * @return string
 */
function luismacchine_logo_url() {
	$logo             = function_exists( 'ticinoweb_get_site_logo' ) ? ticinoweb_get_site_logo() : '';
	$packaged_logo    = luismacchine_asset_url( 'assets/brand/logo-luismacchine.png' );
	$logo_path        = wp_parse_url( $logo, PHP_URL_PATH );
	$packaged_suffix  = '/wp-content/themes/' . get_stylesheet() . '/assets/brand/logo-luismacchine.png';
	$is_packaged_logo = is_string( $logo_path ) && $packaged_suffix === substr( $logo_path, -strlen( $packaged_suffix ) );

	if ( empty( $logo ) || $is_packaged_logo ) {
		$theme_version = wp_get_theme()->get( 'Version' );
		$logo          = $theme_version ? add_query_arg( 'ver', $theme_version, $packaged_logo ) : $packaged_logo;
	}

	return $logo;
}

/**
 * Resolve a Media Library attachment URL reliably on subdirectory Multisite.
 *
 * Core's attachment_url_to_postid() compares against home_url(), which may
 * include the site's path while the shared uploads URL does not.
 *
 * @param string $url Attachment URL.
 * @return int
 */
function luismacchine_attachment_id_from_url( $url ) {
	$url = esc_url_raw( $url );

	if ( empty( $url ) ) {
		return 0;
	}

	$attachment_id = attachment_url_to_postid( $url );

	if ( $attachment_id ) {
		return (int) $attachment_id;
	}

	$uploads    = wp_get_upload_dir();
	$image_path = wp_parse_url( $url, PHP_URL_PATH );

	if ( ! is_string( $image_path ) ) {
		return 0;
	}

	$uploads_directory = trim( wp_normalize_path( str_replace( WP_CONTENT_DIR, '', $uploads['basedir'] ) ), '/' );
	$uploads_marker    = '/' . basename( WP_CONTENT_DIR ) . '/' . $uploads_directory . '/';
	$marker_position   = strpos( $image_path, $uploads_marker );

	if ( false === $marker_position ) {
		return 0;
	}

	$relative_path = substr( $image_path, $marker_position + strlen( $uploads_marker ) );
	$attachments   = get_posts(
		array(
			'post_type'              => 'attachment',
			'post_status'            => 'inherit',
			'posts_per_page'         => 1,
			'fields'                 => 'ids',
			'meta_key'               => '_wp_attached_file',
			'meta_value'             => $relative_path,
			'no_found_rows'          => true,
			'update_post_meta_cache' => false,
			'update_post_term_cache' => false,
		)
	);

	return $attachments ? (int) $attachments[0] : 0;
}

/**
 * Normalize the configured phone number for a tel URL.
 *
 * @param string $phone Phone number.
 * @return string
 */
function luismacchine_phone_href( $phone ) {
	return preg_replace( '/[^0-9+]/', '', (string) $phone );
}

/**
 * Render the primary navigation when no WordPress menu is assigned yet.
 *
 * @return void
 */
function luismacchine_navigation_fallback() {
	$items = array(
		array( __( 'Home', 'luismacchine-child-theme' ), home_url( '/' ) ),
		array( __( 'Servizi', 'luismacchine-child-theme' ), luismacchine_page_url( 'servizi' ) ),
		array( __( 'Vetrina auto', 'luismacchine-child-theme' ), get_post_type_archive_link( LUISMACCHINE_VEHICLE_POST_TYPE ) ),
		array( __( 'Ricambi', 'luismacchine-child-theme' ), get_post_type_archive_link( LUISMACCHINE_PART_POST_TYPE ) ),
		array( __( 'Chi siamo', 'luismacchine-child-theme' ), luismacchine_page_url( 'chi-siamo' ) ),
		array( __( 'Contatti', 'luismacchine-child-theme' ), luismacchine_page_url( 'contatti' ) ),
	);

	echo '<ul class="lm-nav__list">';

	foreach ( $items as $item ) {
		if ( empty( $item[1] ) ) {
			continue;
		}

		printf(
			'<li><a href="%1$s">%2$s</a></li>',
			esc_url( $item[1] ),
			esc_html( $item[0] )
		);
	}

	echo '</ul>';
}

/**
 * Return the service icon name associated with its stable service ID.
 *
 * @param array $service Service data.
 * @param int   $index Service index.
 * @return string
 */
function luismacchine_service_icon_name( $service, $index ) {
	$dashicon_map = array(
		'dashicons-location-alt'   => 'tow',
		'dashicons-admin-tools'    => 'tool',
		'dashicons-hammer'         => 'tool',
		'dashicons-car'            => 'car',
		'dashicons-admin-settings' => 'gear',
		'dashicons-update'         => 'recycle',
		'dashicons-recycle'        => 'recycle',
	);
	$dashicon    = isset( $service['icon'] ) ? sanitize_html_class( $service['icon'] ) : '';
	if ( isset( $dashicon_map[ $dashicon ] ) ) {
		return $dashicon_map[ $dashicon ];
	}

	$service_id = isset( $service['id'] ) ? sanitize_key( $service['id'] ) : '';
	$map        = array(
		'recupero'     => 'tow',
		'officina'     => 'tool',
		'vendita'      => 'car',
		'ricambi'      => 'gear',
		'riciclaggio'  => 'recycle',
		'rottamazione' => 'recycle',
	);

	foreach ( $map as $needle => $icon ) {
		if ( false !== strpos( $service_id, $needle ) ) {
			return $icon;
		}
	}

	$fallbacks = array( 'tow', 'tool', 'car', 'gear', 'recycle' );

	return $fallbacks[ $index % count( $fallbacks ) ];
}

/**
 * Render a service icon configured in the parent CMS.
 * SVG uploads are restricted to this site's host; Dashicons are translated to
 * the child theme's authored line icons to preserve the approved visual style.
 *
 * @param array $service Service data from the parent CMS.
 * @param int   $index Service index.
 * @return string
 */
function luismacchine_service_icon_markup( $service, $index ) {
	if ( isset( $service['icon_type'], $service['icon_svg'] ) && 'svg' === $service['icon_type'] && '' !== $service['icon_svg'] ) {
		$icon_url = esc_url( $service['icon_svg'] );
		$icon_host = wp_parse_url( $icon_url, PHP_URL_HOST );
		$site_host = wp_parse_url( home_url(), PHP_URL_HOST );

		if ( $icon_url && $icon_host && $site_host && strtolower( $icon_host ) === strtolower( $site_host ) ) {
			return sprintf( '<img src="%1$s" width="34" height="34" alt="" aria-hidden="true" loading="lazy" decoding="async">', $icon_url );
		}
	}

	return luismacchine_icon( luismacchine_service_icon_name( $service, $index ) );
}

/**
 * Return a small authored SVG icon.
 *
 * @param string $name Icon name.
 * @param string $class Optional CSS class.
 * @return string
 */
function luismacchine_icon( $name, $class = '' ) {
	$icons = array(
		'arrow'   => '<path d="M5 12h13M13 6l6 6-6 6"/>',
		'catalog-empty' => '<path d="M5 4h14l3 9v6a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2v-6l3-9Z"/><path d="M2 13h6l1.5 3h5l1.5-3h6M9 8h6"/>',
		'calendar' => '<rect x="3.5" y="5" width="17" height="16" rx="2.5"/><path d="M7.5 2.5v5M16.5 2.5v5M3.5 10.5h17"/>',
		'road' => '<path d="m7 3-4 18M17 3l4 18M12 3v3M12 10v4M12 18v3"/>',
		'gauge' => '<path d="M5 19a9 9 0 1 1 14 0M3 12h2M5.6 5.6 7 7M12 3v2M18.4 5.6 17 7M21 12h-2M7 19h10M11 11 8 8"/><circle cx="12" cy="12" r="1.5"/>',
		'transmission' => '<path d="M5 6v12M12 6v12M19 6v6H5"/><circle cx="5" cy="4" r="2"/><circle cx="12" cy="4" r="2"/><circle cx="19" cy="4" r="2"/><circle cx="5" cy="20" r="2"/><circle cx="12" cy="20" r="2"/><path d="M18 22v-6h2a1.5 1.5 0 0 1 0 3h-2m2 0 2 3"/>',
		'phone'   => '<path d="M7.6 3H4.5A1.5 1.5 0 0 0 3 4.5C3 13.6 10.4 21 19.5 21a1.5 1.5 0 0 0 1.5-1.5v-3.1a1.5 1.5 0 0 0-1.1-1.45l-3.35-.84a1.5 1.5 0 0 0-1.55.52l-.73.97a13.1 13.1 0 0 1-5.87-5.87l.97-.73a1.5 1.5 0 0 0 .52-1.55L9.05 4.1A1.5 1.5 0 0 0 7.6 3Z"/>',
		'pin'     => '<path d="M20 10c0 5-8 11-8 11S4 15 4 10a8 8 0 1 1 16 0Z"/><circle cx="12" cy="10" r="2.5"/>',
		'tow'     => '<path d="M3 16h12l2-5h3l1 5"/><path d="M5 16V9h7l3 3v4M7 9V6h5l3 3"/><circle cx="7" cy="18" r="2"/><circle cx="18" cy="18" r="2"/>',
		'tool'    => '<path d="M14.7 6.3a4 4 0 0 0-5 5L3 18l3 3 6.7-6.7a4 4 0 0 0 5-5l-2.3 2.3-3-3 2.3-2.3Z"/>',
		'car'     => '<g stroke-width="1.4"><path d="M3.5 16H2v-3.5a1.5 1.5 0 0 1 1.2-1.47L5 10.7l2.4-3.2A2 2 0 0 1 9 6.7h4.6a2 2 0 0 1 1.5.68L18 10.7l2.8.8a1.6 1.6 0 0 1 1.2 1.54V16h-1.5M7.5 16h9M5 10.7h13M12 6.7v4M2 13.2h1.5M20.5 13.2H22"/><circle cx="5.5" cy="16" r="2"/><circle cx="18.5" cy="16" r="2"/></g>',
		'gear'    => '<circle cx="12" cy="12" r="3.25"/><path d="M9.02 4.79 10.25 4.40 10.44 2.12 13.56 2.12 13.75 4.40 14.98 4.79 16.13 5.39 17.88 3.91 20.09 6.12 18.61 7.87 19.21 9.02 19.60 10.25 21.88 10.44 21.88 13.56 19.60 13.75 19.21 14.98 18.61 16.13 20.09 17.88 17.88 20.09 16.13 18.61 14.98 19.21 13.75 19.60 13.56 21.88 10.44 21.88 10.25 19.60 9.02 19.21 7.87 18.61 6.12 20.09 3.91 17.88 5.39 16.13 4.79 14.98 4.40 13.75 2.12 13.56 2.12 10.44 4.40 10.25 4.79 9.02 5.39 7.87 3.91 6.12 6.12 3.91 7.87 5.39Z"/>',
		'recycle' => '<path d="m9 4 2-2 3 5H9M18 10l3 1-3 5-2-4M9 19l-1 3-4-5 5-.5"/><path d="M11 7H7a3 3 0 0 0-2.6 1.5L3 11M16 12l2 3a3 3 0 0 1 0 3l-1 2M9 18h5a3 3 0 0 0 2.6-1.5"/>',
		'filter'  => '<path d="M4 5h16M7 12h10M10 19h4"/>',
		'close'   => '<path d="m6 6 12 12M18 6 6 18"/>',
		'menu'    => '<path d="M4 7h16M4 12h16M4 17h16"/>',
		'volume'  => '<path d="M5 10v4h4l5 4V6l-5 4H5Z"/><path d="M17 9a4 4 0 0 1 0 6M19 6a8 8 0 0 1 0 12"/>',
	);

	if ( ! isset( $icons[ $name ] ) ) {
		return '';
	}

	return sprintf(
		'<svg class="%1$s" aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round">%2$s</svg>',
		esc_attr( $class ),
		$icons[ $name ]
	);
}

/**
 * Add site-specific body classes.
 *
 * @param array $classes Body classes.
 * @return array
 */
function luismacchine_body_classes( $classes ) {
	$classes[] = 'lm-site';

	if ( is_front_page() ) {
		$classes[] = 'lm-site--home';
	}

	return $classes;
}
add_filter( 'body_class', 'luismacchine_body_classes' );

/**
 * Dark browser chrome and preload the critical display font.
 *
 * @return void
 */
function luismacchine_document_hints() {
	printf( '<meta name="theme-color" content="%s">' . "\n", esc_attr( luismacchine_design_value( 'ticinoweb_palette_suggested_1' ) ) );
	if ( 'Barlow Condensed' === luismacchine_design_value( 'ticinoweb_font_headings' ) ) {
		printf( '<link rel="preload" href="%s" as="font" type="font/ttf" crossorigin>' . "\n", esc_url( luismacchine_asset_url( 'assets/fonts/barlow-condensed-700.ttf' ) ) );
	}
}
add_action( 'wp_head', 'luismacchine_document_hints', 2 );

/**
 * Contact information with safe project fallbacks.
 *
 * @return array
 */
function luismacchine_contact_info() {
	$info = function_exists( 'ticinoweb_get_contact_info' ) ? ticinoweb_get_contact_info() : array();
	return wp_parse_args(
		$info,
		array(
			'phone'   => '',
			'email'   => '',
			'address' => '',
		)
	);
}

/**
 * Return configured services; retain a useful fallback before CMS setup.
 *
 * @return array
 */
function luismacchine_services() {
	$services = function_exists( 'ticinoweb_get_services' ) ? ticinoweb_get_services() : array();
	if ( ! empty( $services ) ) {
		return $services;
	}
	return array(
		array( 'id' => 'recupero', 'title' => __( 'Recupero veicoli', 'luismacchine-child-theme' ), 'description' => __( 'Supporto per il recupero e il trasporto del veicolo verso la nostra sede.', 'luismacchine-child-theme' ) ),
		array( 'id' => 'officina', 'title' => __( 'Officina', 'luismacchine-child-theme' ), 'description' => __( 'Manutenzione e interventi meccanici con un referente diretto.', 'luismacchine-child-theme' ) ),
		array( 'id' => 'vendita', 'title' => __( 'Vendita auto', 'luismacchine-child-theme' ), 'description' => __( 'Veicoli selezionati, presentati con informazioni chiare e fotografie complete.', 'luismacchine-child-theme' ) ),
		array( 'id' => 'ricambi', 'title' => __( 'Ricambi', 'luismacchine-child-theme' ), 'description' => __( 'Ricambi usati e componenti verificati, consultabili nel catalogo dedicato.', 'luismacchine-child-theme' ) ),
		array( 'id' => 'riciclaggio', 'title' => __( 'Riciclaggio', 'luismacchine-child-theme' ), 'description' => __( 'Gestione responsabile dei veicoli e recupero dei componenti riutilizzabili.', 'luismacchine-child-theme' ) ),
	);
}

/**
 * Render a reusable section heading.
 *
 * @param string $eyebrow Small label.
 * @param string $title Heading.
 * @param string $text Supporting text.
 * @return void
 */
function luismacchine_section_heading( $eyebrow, $title, $text = '' ) {
	echo '<header class="lm-section-heading">';
	printf( '<p class="lm-eyebrow">%s</p>', esc_html( $eyebrow ) );
	printf( '<h2>%s</h2>', esc_html( $title ) );
	if ( $text ) {
		printf( '<p class="lm-section-heading__text">%s</p>', esc_html( $text ) );
	}
	echo '</header>';
}

/** Keep the parent consent UI without claiming that Google Analytics is active. */
function luismacchine_cookie_notice_text( $translation, $text, $domain ) {
	if ( ! is_admin() && 'Utilizziamo i cookie per offrirti la migliore esperienza sul nostro sito web e per analizzare il traffico.' === $text ) {
		return __( 'Questo sito utilizza cookie e tecnologie di memorizzazione nel browser. Puoi gestire le preferenze sui cookie facoltativi tramite i pulsanti qui sotto.', 'luismacchine-child-theme' );
	}
	return $translation;
}
add_filter( 'gettext_ticinoweb-ai-theme', 'luismacchine_cookie_notice_text', 10, 3 );

