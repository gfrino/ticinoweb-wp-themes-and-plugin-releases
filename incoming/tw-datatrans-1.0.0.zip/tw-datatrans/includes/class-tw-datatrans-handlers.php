<?php
/**
 * The two public endpoints (WooCommerce API URLs):
 *  - webhook  (Datatrans → shop, server-to-server): the source of truth.
 *  - return   (browser back from the payment page): shows the result, and
 *             re-checks the status with the API so a lost webhook never
 *             leaves a paid order "pending".
 * Neither trusts its input: the order key must match, and an order is
 * marked paid only after GET /v2/transactions/{id} says so.
 */

defined( 'ABSPATH' ) || exit;

class TW_Datatrans_Handlers {

	public static function init() {
		add_action( 'woocommerce_api_tw_datatrans_webhook', array( __CLASS__, 'webhook' ) );
		add_action( 'woocommerce_api_tw_datatrans_return', array( __CLASS__, 'back_from_datatrans' ) );
		add_action( 'woocommerce_admin_order_data_after_billing_address', array( __CLASS__, 'admin_order_box' ) );
	}

	public static function webhook_url( $order = null ) {
		$url = WC()->api_request_url( 'tw_datatrans_webhook' );
		if ( $order instanceof WC_Order ) {
			$url = add_query_arg( array( 'order' => $order->get_id(), 'key' => $order->get_order_key() ), $url );
		}
		return $url;
	}

	public static function return_url( WC_Order $order, $result ) {
		return add_query_arg(
			array( 'order' => $order->get_id(), 'key' => $order->get_order_key(), 'result' => $result ),
			WC()->api_request_url( 'tw_datatrans_return' )
		);
	}

	/** Order from ?order=&key=, or null. */
	private static function order_from_request() {
		$id  = isset( $_GET['order'] ) ? absint( $_GET['order'] ) : 0;
		$key = isset( $_GET['key'] ) ? sanitize_text_field( wp_unslash( $_GET['key'] ) ) : '';
		$order = $id ? wc_get_order( $id ) : false;
		if ( ! $order || '' === $key || ! hash_equals( $order->get_order_key(), $key ) ) {
			return null;
		}
		return $order;
	}

	/**
	 * Reads the authoritative status from Datatrans and updates the order.
	 * Returns 'paid' | 'pending' | 'failed'.
	 */
	public static function sync_order( WC_Order $order, $transaction_id, $source ) {
		$expected = (string) $order->get_meta( '_tw_datatrans_transaction_id' );
		if ( '' === $expected || $expected !== (string) $transaction_id ) {
			tw_datatrans_log( array( 'sync' => $source, 'order' => $order->get_id(), 'error' => 'transaction id mismatch', 'given' => $transaction_id, 'expected' => $expected ), 'error' );
			return 'failed';
		}
		if ( $order->is_paid() ) {
			return 'paid';
		}
		$status = TW_Datatrans_API::status( $transaction_id );
		if ( is_wp_error( $status ) ) {
			$order->add_order_note( sprintf( __( 'Datatrans: status check failed (%s).', 'tw-datatrans' ), $status->get_error_message() ) );
			return 'pending';
		}
		$state = (string) ( $status['status'] ?? '' );
		if ( TW_Datatrans_API::is_paid_status( $state ) ) {
			$method = (string) ( $status['paymentMethod'] ?? '' );
			$card   = isset( $status['card'] ) && is_array( $status['card'] ) ? $status['card'] : array();
			$wallet = (string) ( $card['walletIndicator'] ?? '' );
			$label  = self::method_label( $method, $wallet );
			$order->update_meta_data( '_tw_datatrans_payment_method', $method );
			if ( ! empty( $card['masked'] ) ) {
				$order->update_meta_data( '_tw_datatrans_card_masked', (string) $card['masked'] );
			}
			if ( ! empty( $card['info']['brand'] ) ) {
				$order->update_meta_data( '_tw_datatrans_card_brand', (string) $card['info']['brand'] );
			}
			$order->set_payment_method_title( sprintf( 'Datatrans — %s', $label ) );
			$order->payment_complete( $transaction_id );
			$order->add_order_note( sprintf( __( 'Datatrans: payment %1$s (%2$s, transaction %3$s, via %4$s).', 'tw-datatrans' ), $state, $label, $transaction_id, $source ) );
			$order->save();
			return 'paid';
		}
		if ( in_array( $state, array( 'canceled', 'failed', 'error', 'timeout' ), true ) ) {
			$order->update_status( 'failed', sprintf( __( 'Datatrans: payment %1$s (transaction %2$s).', 'tw-datatrans' ), $state, $transaction_id ) );
			return 'failed';
		}
		$order->add_order_note( sprintf( __( 'Datatrans: transaction %1$s is "%2$s", waiting.', 'tw-datatrans' ), $transaction_id, $state ) );
		return 'pending';
	}

	public static function method_label( $method, $wallet = '' ) {
		if ( 'APL' === $wallet || 'APL' === $method ) {
			return 'Apple Pay';
		}
		if ( 'PAY' === $wallet || 'PAY' === $method ) {
			return 'Google Pay';
		}
		$labels = array( 'TWI' => 'TWINT', 'VIS' => 'Visa', 'ECA' => 'Mastercard', 'AMX' => 'American Express', 'DIN' => 'Diners', 'DIS' => 'Discover', 'JCB' => 'JCB', 'PFC' => 'PostFinance Card', 'PAP' => 'PayPal', 'PEF' => 'PostFinance Pay' );
		return $labels[ $method ] ?? ( $method ?: 'Datatrans' );
	}

	/** Datatrans → shop. Synchronous: Datatrans redirects the customer only after we answer. */
	public static function webhook() {
		$raw   = (string) file_get_contents( 'php://input' );
		$order = self::order_from_request();
		if ( ! $order ) {
			status_header( 404 );
			exit;
		}
		$key = (string) TW_Datatrans_Settings::get( 'sign_key' );
		if ( '' !== $key ) {
			$header = isset( $_SERVER['HTTP_DATATRANS_SIGNATURE'] ) ? (string) $_SERVER['HTTP_DATATRANS_SIGNATURE'] : '';
			if ( ! TW_Datatrans_API::verify_signature( $header, $raw, $key ) ) {
				tw_datatrans_log( array( 'webhook' => 'invalid signature', 'order' => $order->get_id() ), 'error' );
				status_header( 403 );
				exit;
			}
		}
		$body           = json_decode( $raw, true );
		$transaction_id = is_array( $body ) ? (string) ( $body['transactionId'] ?? '' ) : '';
		tw_datatrans_log( array( 'webhook' => $order->get_id(), 'transactionId' => $transaction_id, 'status' => $body['status'] ?? null ) );
		if ( '' === $transaction_id ) {
			status_header( 400 );
			exit;
		}
		self::sync_order( $order, $transaction_id, 'webhook' );
		status_header( 200 );
		header( 'Content-Type: text/plain; charset=utf-8' );
		echo 'OK';
		exit;
	}

	/** Browser back from the Datatrans page (success / error / cancel). */
	public static function back_from_datatrans() {
		$order = self::order_from_request();
		if ( ! $order ) {
			wp_safe_redirect( wc_get_checkout_url() );
			exit;
		}
		$result         = isset( $_GET['result'] ) ? sanitize_key( wp_unslash( $_GET['result'] ) ) : 'error';
		$transaction_id = isset( $_GET['datatransTrxId'] ) ? sanitize_text_field( wp_unslash( $_GET['datatransTrxId'] ) ) : (string) $order->get_meta( '_tw_datatrans_transaction_id' );

		if ( 'cancel' === $result ) {
			if ( ! $order->is_paid() ) {
				$order->update_status( 'cancelled', __( 'Datatrans: payment cancelled by the customer.', 'tw-datatrans' ) );
			}
			wc_add_notice( __( 'Payment cancelled. Your order is still here: choose a payment method to complete it.', 'tw-datatrans' ), 'notice' );
			wp_safe_redirect( $order->get_checkout_payment_url() );
			exit;
		}

		$outcome = self::sync_order( $order, $transaction_id, 'return' );
		if ( 'paid' === $outcome ) {
			WC()->cart && WC()->cart->empty_cart();
			wp_safe_redirect( $order->get_checkout_order_received_url() );
			exit;
		}
		if ( 'pending' === $outcome ) {
			// Datatrans not reachable right now: the webhook (or a later check) settles it.
			wc_add_notice( __( 'Your payment is being confirmed. You will receive the order confirmation by email as soon as it is done.', 'tw-datatrans' ), 'notice' );
			wp_safe_redirect( $order->get_checkout_order_received_url() );
			exit;
		}
		wc_add_notice( __( 'The payment was not completed. No amount was charged: please try again or choose another payment method.', 'tw-datatrans' ), 'error' );
		wp_safe_redirect( $order->get_checkout_payment_url() );
		exit;
	}

	/** Datatrans details on the admin order page. */
	public static function admin_order_box( $order ) {
		$tx = (string) $order->get_meta( '_tw_datatrans_transaction_id' );
		if ( '' === $tx ) {
			return;
		}
		$env    = (string) $order->get_meta( '_tw_datatrans_env' );
		$method = (string) $order->get_meta( '_tw_datatrans_payment_method' );
		$masked = (string) $order->get_meta( '_tw_datatrans_card_masked' );
		$admin  = 'sandbox' === $env ? 'https://admin.sandbox.datatrans.com/' : 'https://admin.datatrans.com/';
		echo '<div class="tw-datatrans-order" style="margin-top:12px;"><h3 style="margin-bottom:4px;">Datatrans</h3>';
		echo '<p style="margin:0;">';
		echo esc_html__( 'Transaction', 'tw-datatrans' ) . ': <code>' . esc_html( $tx ) . '</code>';
		if ( '' !== $method ) {
			echo '<br/>' . esc_html__( 'Method', 'tw-datatrans' ) . ': ' . esc_html( self::method_label( $method ) );
		}
		if ( '' !== $masked ) {
			echo ' <code>' . esc_html( $masked ) . '</code>';
		}
		if ( 'sandbox' === $env ) {
			echo '<br/><strong style="color:#b00020;">' . esc_html__( 'Test payment (sandbox)', 'tw-datatrans' ) . '</strong>';
		}
		echo '<br/><a href="' . esc_url( $admin ) . '" target="_blank" rel="noopener">' . esc_html__( 'Open the Datatrans Webadmin', 'tw-datatrans' ) . '</a>';
		echo '</p></div>';
	}
}
