<?php
/**
 * Volantino del cliente nella lingua della pagina.
 *
 * Le immagini stanno in assets/img/volantini/<name>-<lingua>.jpg. SAM le
 * fornisce solo in IT, FR e DE: nelle altre lingue il blocco non compare,
 * piuttosto che mostrare un volantino in una lingua diversa da quella del
 * visitatore.
 *
 * Argomenti: name, label, title, text, alt.
 *
 * @package samswiss-child
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$flyer = wp_parse_args( $args, array(
	'name'  => '',
	'label' => '',
	'title' => '',
	'text'  => '',
	'alt'   => '',
) );

$flyer_lang = apply_filters( 'wpml_current_language', null ) ?: 'it';
$flyer_rel  = 'assets/img/volantini/' . sanitize_file_name( $flyer['name'] . '-' . $flyer_lang . '.jpg' );

if ( ! $flyer['name'] || ! file_exists( get_stylesheet_directory() . '/' . $flyer_rel ) ) {
	return;
}

$flyer_url = get_stylesheet_directory_uri() . '/' . $flyer_rel;
?>
<div class="samswiss-flyer">
	<div class="samswiss-flyer__text">
		<?php if ( $flyer['label'] ) : ?>
			<p class="sw-label samswiss-flyer__label"><?php echo esc_html( $flyer['label'] ); ?></p>
		<?php endif; ?>
		<h2 class="sw-display samswiss-flyer__title"><?php echo esc_html( $flyer['title'] ); ?></h2>
		<?php if ( $flyer['text'] ) : ?>
			<p class="samswiss-flyer__desc"><?php echo esc_html( $flyer['text'] ); ?></p>
		<?php endif; ?>
		<a class="samswiss-btn samswiss-btn--green" href="<?php echo esc_url( $flyer_url ); ?>" target="_blank" rel="noopener">
			<span><?php esc_html_e( 'Apri il volantino', 'samswiss-child' ); ?></span>
			<span aria-hidden="true">&rarr;</span>
		</a>
	</div>
	<figure class="samswiss-flyer__figure">
		<a href="<?php echo esc_url( $flyer_url ); ?>" target="_blank" rel="noopener">
			<?php echo samswiss_shipped_image( $flyer_rel, '', $flyer['alt'], 'samswiss-flyer__img' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
		</a>
	</figure>
</div>
