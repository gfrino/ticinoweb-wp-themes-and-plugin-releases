<?php
/**
 * SAM SWISS child theme — native contact form handler.
 *
 * Replaces the Elementor form widget. Verifies reCAPTCHA through the parent
 * theme when configured, and sends mail via wp_mail() (the parent theme routes
 * wp_mail through SMTP/SendGrid).
 *
 * The submission logic is separated from its transport on purpose. The form used
 * to be AJAX-only: no `action` attribute and handlers registered on `wp_ajax_*`
 * alone, so with JavaScript unavailable the browser posted the page back to
 * itself, nothing received the data, and the visitor lost a written enquiry with
 * no error. The same core now serves both an AJAX call and an ordinary POST to
 * admin-post.php, which is what the markup targets.
 *
 * @package samswiss-child
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Outcome messages, keyed by code, so the AJAX and no-JS paths cannot drift.
 *
 * @param string $code Outcome code.
 * @return string Translated, human-facing message.
 */
function samswiss_contact_message( $code ) {
	$messages = array(
		'ok'       => __( 'Grazie! Il tuo messaggio è stato inviato. Ti risponderemo al più presto.', 'samswiss-child' ),
		'nonce'    => __( 'Sessione scaduta. Ricarica la pagina e riprova.', 'samswiss-child' ),
		'invalid'  => __( 'Compila i campi obbligatori con dati validi.', 'samswiss-child' ),
		'captcha'  => __( 'Verifica anti-spam fallita. Riprova.', 'samswiss-child' ),
		'mailfail' => __( 'Non è stato possibile inviare il messaggio. Scrivici direttamente all\'indirizzo email qui accanto.', 'samswiss-child' ),
	);

	return isset( $messages[ $code ] ) ? $messages[ $code ] : $messages['invalid'];
}

/**
 * Validate the submission and send it.
 *
 * @return array{code:string,success:bool}
 */
function samswiss_contact_process() {
	$nonce = isset( $_POST['samswiss_contact_nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['samswiss_contact_nonce'] ) ) : '';
	if ( ! wp_verify_nonce( $nonce, 'samswiss_contact' ) ) {
		return array( 'code' => 'nonce', 'success' => false );
	}

	// Honeypot: real users leave it empty. Reported as success so a bot learns
	// nothing from the difference.
	if ( ! empty( $_POST['website'] ) ) {
		return array( 'code' => 'ok', 'success' => true );
	}

	$name    = isset( $_POST['name'] ) ? sanitize_text_field( wp_unslash( $_POST['name'] ) ) : '';
	$email   = isset( $_POST['email'] ) ? sanitize_email( wp_unslash( $_POST['email'] ) ) : '';
	$phone   = isset( $_POST['phone'] ) ? sanitize_text_field( wp_unslash( $_POST['phone'] ) ) : '';
	$message = isset( $_POST['message'] ) ? sanitize_textarea_field( wp_unslash( $_POST['message'] ) ) : '';

	if ( '' === $name || '' === $message || ! is_email( $email ) ) {
		return array( 'code' => 'invalid', 'success' => false );
	}

	// reCAPTCHA (only if the parent theme has it configured).
	if ( function_exists( 'ticinoweb_verify_recaptcha' ) && get_option( 'ticinoweb_recaptcha_secret_key' ) ) {
		$token = isset( $_POST['recaptcha_token'] ) ? sanitize_text_field( wp_unslash( $_POST['recaptcha_token'] ) ) : '';
		if ( ! ticinoweb_verify_recaptcha( $token ) ) {
			return array( 'code' => 'captcha', 'success' => false );
		}
	}

	$contact = function_exists( 'samswiss_get_contact' ) ? samswiss_get_contact() : array();
	$to      = get_option( 'ticinoweb_contact_email' );
	if ( ! $to || strpos( $to, 'localhost' ) !== false ) {
		$to = ! empty( $contact['email'] ) ? $contact['email'] : get_option( 'admin_email' );
	}

	/* translators: %s: sender name. */
	$subject = sprintf( __( 'Nuovo messaggio dal sito da %s', 'samswiss-child' ), $name );
	$body    = sprintf(
		"Nome: %s\nEmail: %s\nTelefono: %s\n\nMessaggio:\n%s\n",
		$name,
		$email,
		$phone,
		$message
	);
	$headers = array(
		'Content-Type: text/plain; charset=UTF-8',
		'Reply-To: ' . $name . ' <' . $email . '>',
	);

	// Record the enquiry before attempting delivery. wp_mail() returns false
	// whenever no mail transport is configured, and an enquiry is too expensive
	// to lose to a server setting the visitor cannot see.
	samswiss_store_enquiry( compact( 'name', 'email', 'phone', 'message' ) );

	if ( wp_mail( $to, $subject, $body, $headers ) ) {
		return array( 'code' => 'ok', 'success' => true );
	}

	return array( 'code' => 'mailfail', 'success' => false );
}

/**
 * Keep the last enquiries in an option so a mail failure is recoverable.
 *
 * Capped at 50 newest-first: this is a safety net for a misconfigured mailer,
 * not a CRM. Exported alongside the newsletter list from the admin.
 *
 * @param array $fields Sanitised submission fields.
 * @return void
 */
function samswiss_store_enquiry( array $fields ) {
	$log = get_option( 'samswiss_contact_enquiries', array() );
	if ( ! is_array( $log ) ) {
		$log = array();
	}

	array_unshift( $log, array(
		'date'    => current_time( 'mysql' ),
		'name'    => $fields['name'],
		'email'   => $fields['email'],
		'phone'   => $fields['phone'],
		'message' => $fields['message'],
		'lang'    => (string) apply_filters( 'wpml_current_language', null ),
	) );

	update_option( 'samswiss_contact_enquiries', array_slice( $log, 0, 50 ), false );
}

/**
 * AJAX transport.
 */
function samswiss_handle_contact_form() {
	$result = samswiss_contact_process();
	wp_send_json( array(
		'success' => $result['success'],
		'message' => samswiss_contact_message( $result['code'] ),
	) );
}
add_action( 'wp_ajax_samswiss_contact', 'samswiss_handle_contact_form' );
add_action( 'wp_ajax_nopriv_samswiss_contact', 'samswiss_handle_contact_form' );

/**
 * Ordinary form POST transport (no JavaScript).
 *
 * Redirects back to the page the form was on, carrying the outcome code, so the
 * result is rendered in place and a refresh cannot resubmit the message.
 */
function samswiss_handle_contact_post() {
	$result = samswiss_contact_process();

	$back = isset( $_POST['redirect_to'] ) ? wp_unslash( $_POST['redirect_to'] ) : '';
	$back = $back ? wp_validate_redirect( $back, home_url( '/' ) ) : wp_get_referer();
	if ( ! $back ) {
		$back = home_url( '/' );
	}

	wp_safe_redirect( add_query_arg( 'samswiss_contact', $result['code'], $back ) . '#samswiss-contact' );
	exit;
}
add_action( 'admin_post_nopriv_samswiss_contact', 'samswiss_handle_contact_post' );
add_action( 'admin_post_samswiss_contact', 'samswiss_handle_contact_post' );

/**
 * The outcome to render on the contact page after a no-JS submission, or ''.
 *
 * @return array{code:string,success:bool,message:string}|array{}
 */
function samswiss_contact_feedback() {
	if ( empty( $_GET['samswiss_contact'] ) ) {
		return array();
	}

	$code = sanitize_key( wp_unslash( $_GET['samswiss_contact'] ) );

	return array(
		'code'    => $code,
		'success' => ( 'ok' === $code ),
		'message' => samswiss_contact_message( $code ),
	);
}

/**
 * Serve the Contatti template (company details + native form) for every
 * translation of the contact page, not only the Italian one.
 *
 * WordPress picks page-contatti.php by slug, and a translated page has another
 * slug (kontakt, contact, kapcsolatok…), so it fell back to page.php and showed
 * the company details without the form. The original is recognised by ID, and
 * by slug as a fallback so it survives an export/import into another database.
 *
 * @param string $template Template resolved by WordPress.
 * @return string
 */
function samswiss_contact_page_template( $template ) {
	if ( ! is_page() ) {
		return $template;
	}

	$id      = get_queried_object_id();
	$default = (int) apply_filters( 'wpml_object_id', $id, 'page', true, apply_filters( 'wpml_default_language', null ) );
	$post    = get_post( $default ? $default : $id );

	if ( 569 !== $default && ! ( $post instanceof WP_Post && 'contatti' === $post->post_name ) ) {
		return $template;
	}

	$file = get_stylesheet_directory() . '/page-contatti.php';
	return is_readable( $file ) ? $file : $template;
}
add_filter( 'template_include', 'samswiss_contact_page_template', 99 );
