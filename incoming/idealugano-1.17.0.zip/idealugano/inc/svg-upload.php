<?php
/**
 * Caricamento di file SVG nella libreria media, per i soli amministratori.
 *
 * WordPress blocca gli SVG perche' sono documenti XML che possono contenere
 * codice eseguibile: uno <script>, un attributo onload, un riferimento a un
 * file esterno. Qui il blocco si apre, ma nessun file entra come e' arrivato:
 * ogni SVG viene riscritto tenendo solo gli elementi e gli attributi che
 * servono a disegnare. Quello che non e' nell'elenco non passa.
 *
 * Serve ai loghi dei fornitori (pagina Marchi): un logo e' un disegno
 * vettoriale, e il PNG di un marchio a schermo grande si vede sgranato.
 *
 * Chi puo': solo chi ha `manage_options`, cioe' gli amministratori del sito.
 * Gli editor usano la pagina Marchi ma non possono caricare SVG: per loro il
 * tipo di file resta bloccato come prima.
 *
 * @package Idealugano
 */

if (!defined('ABSPATH')) {
    exit;
}

/** Chi e' autorizzato a caricare SVG. */
function idealugano_svg_user_allowed()
{
    return current_user_can('manage_options');
}

/**
 * Elementi SVG ammessi: quanto basta a disegnare un logo.
 *
 * @return array<string, true>
 */
function idealugano_svg_allowed_elements()
{
    static $allowed = null;
    if ($allowed === null) {
        $allowed = array_fill_keys(array(
            'svg', 'g', 'defs', 'symbol', 'use', 'switch',
            'title', 'desc', 'metadata', 'style',
            'path', 'rect', 'circle', 'ellipse', 'line', 'polyline', 'polygon',
            'text', 'tspan', 'textpath',
            'clippath', 'mask', 'pattern', 'marker',
            'lineargradient', 'radialgradient', 'stop',
            'filter', 'fegaussianblur', 'feoffset', 'feblend', 'femerge',
            'femergenode', 'fecolormatrix', 'feflood', 'fecomposite',
            'fedropshadow', 'femorphology', 'fetile',
        ), true);
    }
    return $allowed;
}

/**
 * Riscrive un SVG tenendo solo cio' che disegna.
 *
 * Toglie il DOCTYPE (che puo' dichiarare entita' esterne), le istruzioni di
 * elaborazione, i commenti, gli elementi fuori elenco, ogni attributo che
 * comincia per "on", i riferimenti che non puntano dentro il documento stesso
 * e i valori che contengono javascript:.
 *
 * @param string $xml Contenuto del file.
 * @return string|WP_Error SVG ripulito, o errore se il file non e' XML valido.
 */
function idealugano_svg_sanitize($xml)
{
    if (!class_exists('DOMDocument')) {
        return new WP_Error('svg_no_dom', __("Il server non può controllare i file SVG.", 'idealugano'));
    }

    // Niente DOCTYPE: una dichiarazione di entita' puo' leggere file del server.
    $xml = preg_replace('/<!DOCTYPE\b[^>\[]*(?:\[[^\]]*\]\s*)?>/is', '', (string) $xml);
    $xml = preg_replace('/<\?xml-stylesheet\b[^?]*\?>/is', '', $xml);

    $doc = new DOMDocument();
    $doc->preserveWhiteSpace = false;
    $previous = libxml_use_internal_errors(true);
    // Senza LIBXML_NOENT le entita' non vengono risolte: nessun XXE.
    $ok = $doc->loadXML($xml, LIBXML_NONET | LIBXML_NOERROR | LIBXML_NOWARNING);
    libxml_clear_errors();
    libxml_use_internal_errors($previous);

    if (!$ok || !$doc->documentElement) {
        return new WP_Error('svg_not_xml', __("Questo SVG non è un file XML valido e non è stato caricato.", 'idealugano'));
    }
    if (strtolower($doc->documentElement->nodeName) !== 'svg') {
        return new WP_Error('svg_not_svg', __("Questo file non è un SVG.", 'idealugano'));
    }

    idealugano_svg_clean_node($doc->documentElement);

    $out = $doc->saveXML($doc->documentElement);
    if (!is_string($out) || $out === '') {
        return new WP_Error('svg_empty', __("Dopo il controllo questo SVG era vuoto.", 'idealugano'));
    }
    return '<?xml version="1.0" encoding="utf-8"?>' . "\n" . $out . "\n";
}

/**
 * Ripulisce un nodo e tutti i suoi figli, dal fondo verso l'alto.
 *
 * @param DOMElement $node Nodo da ripulire.
 */
function idealugano_svg_clean_node($node)
{
    $allowed = idealugano_svg_allowed_elements();

    // All'indietro: togliere un figlio non sposta quelli ancora da guardare.
    for ($i = $node->childNodes->length - 1; $i >= 0; $i--) {
        $child = $node->childNodes->item($i);
        if (!$child) {
            continue;
        }
        if ($child->nodeType === XML_COMMENT_NODE || $child->nodeType === XML_PI_NODE) {
            $node->removeChild($child);
            continue;
        }
        if ($child->nodeType !== XML_ELEMENT_NODE) {
            continue;
        }
        $name = strtolower($child->localName);
        if (!isset($allowed[$name])) {
            $node->removeChild($child);
            continue;
        }
        if ($name === 'style') {
            $child->textContent = idealugano_svg_clean_css($child->textContent);
            continue;
        }
        idealugano_svg_clean_node($child);
    }

    idealugano_svg_clean_attributes($node);
}

/**
 * Toglie dagli attributi di un elemento tutto cio' che puo' eseguire.
 *
 * @param DOMElement $el Elemento.
 */
function idealugano_svg_clean_attributes($el)
{
    if (!$el->hasAttributes()) {
        return;
    }
    for ($i = $el->attributes->length - 1; $i >= 0; $i--) {
        $attr = $el->attributes->item($i);
        if (!$attr) {
            continue;
        }
        $name  = strtolower($attr->nodeName);
        $local = strtolower($attr->localName);
        $value = (string) $attr->nodeValue;

        // Gestori di eventi: onload, onclick, onmouseover...
        if (strpos($local, 'on') === 0) {
            $el->removeAttributeNode($attr);
            continue;
        }
        // Riferimenti: solo dentro il documento stesso (#id) o a un dato inline.
        if ($local === 'href' || $name === 'xlink:href') {
            $v = trim($value);
            if ($v === '' || ($v[0] !== '#' && stripos($v, 'data:image/') !== 0)) {
                $el->removeAttributeNode($attr);
                continue;
            }
        }
        if (preg_match('/(?:javascript|vbscript|data\s*:\s*text\/html)\s*:/i', $value)) {
            $el->removeAttributeNode($attr);
            continue;
        }
        if ($local === 'style') {
            $clean = idealugano_svg_clean_css($value);
            if ($clean !== $value) {
                $attr->nodeValue = $clean;
            }
        }
    }
}

/**
 * Toglie dal CSS di un SVG le parti che possono caricare o eseguire qualcosa.
 *
 * @param string $css CSS.
 * @return string
 */
function idealugano_svg_clean_css($css)
{
    $css = preg_replace('/@import\b[^;]*;?/i', '', (string) $css);
    $css = preg_replace('/expression\s*\(/i', '(', $css);
    $css = preg_replace('/(?:javascript|vbscript)\s*:/i', '', $css);
    // url(...) e' ammesso solo verso un frammento interno o un dato inline.
    $css = preg_replace_callback(
        '/url\(\s*([\'"]?)([^\'")]*)\1\s*\)/i',
        function ($m) {
            $v = trim($m[2]);
            if ($v !== '' && ($v[0] === '#' || stripos($v, 'data:image/') === 0)) {
                return 'url(' . $m[1] . $v . $m[1] . ')';
            }
            return 'none';
        },
        $css
    );
    return $css;
}

/**
 * Aggiunge svg ai tipi ammessi, per i soli amministratori.
 *
 * Priorita' 20: in multisite `check_upload_mimes()` gira a 10 e tiene solo i
 * tipi elencati nelle impostazioni di rete. Si rimette dopo.
 */
add_filter('upload_mimes', 'idealugano_svg_allow_mime', 20);
function idealugano_svg_allow_mime($mimes)
{
    // svgz (SVG compresso con gzip) resta fuori: la ripulitura legge testo,
    // un file compresso le passerebbe davanti senza essere controllato.
    unset($mimes['svgz']);
    if (idealugano_svg_user_allowed()) {
        $mimes['svg'] = 'image/svg+xml';
    } else {
        unset($mimes['svg']);
    }
    return $mimes;
}

/**
 * WordPress confronta l'estensione con il tipo indovinato dal contenuto, e per
 * un SVG indovina spesso text/plain o text/html: senza questo il file viene
 * rifiutato anche se il tipo e' ammesso.
 */
add_filter('wp_check_filetype_and_ext', 'idealugano_svg_check_filetype', 10, 4);
function idealugano_svg_check_filetype($data, $file, $filename, $mimes)
{
    if (!empty($data['ext']) && !empty($data['type'])) {
        return $data;
    }
    if (!idealugano_svg_user_allowed()) {
        return $data;
    }
    if (strtolower(pathinfo($filename, PATHINFO_EXTENSION)) !== 'svg') {
        return $data;
    }
    return array(
        'ext'             => 'svg',
        'type'            => 'image/svg+xml',
        'proper_filename' => $data['proper_filename'],
    );
}

/**
 * Ripulisce il file prima che WordPress lo sposti negli upload. Se non e' un
 * SVG leggibile il caricamento si ferma qui, con un messaggio comprensibile.
 */
add_filter('wp_handle_upload_prefilter', 'idealugano_svg_sanitize_upload');
function idealugano_svg_sanitize_upload($file)
{
    if (empty($file['tmp_name']) || !empty($file['error'])) {
        return $file;
    }
    $ext = strtolower(pathinfo(isset($file['name']) ? $file['name'] : '', PATHINFO_EXTENSION));
    if ($ext !== 'svg') {
        return $file;
    }
    if (!idealugano_svg_user_allowed()) {
        $file['error'] = __("Solo un amministratore può caricare file SVG.", 'idealugano');
        return $file;
    }

    $raw = file_get_contents($file['tmp_name']); // phpcs:ignore WordPress.WP.AlternativeFunctions -- file locale appena caricato, non un URL.
    if ($raw === false) {
        $file['error'] = __("Non è stato possibile leggere il file SVG.", 'idealugano');
        return $file;
    }

    $clean = idealugano_svg_sanitize($raw);
    if (is_wp_error($clean)) {
        $file['error'] = $clean->get_error_message();
        return $file;
    }

    // phpcs:ignore WordPress.WP.AlternativeFunctions -- riscrittura del file temporaneo.
    if (file_put_contents($file['tmp_name'], $clean) === false) {
        $file['error'] = __("Non è stato possibile salvare il file SVG ripulito.", 'idealugano');
    }
    return $file;
}

/**
 * Misure dell'SVG per la libreria media: senza, WordPress non sa quanto e'
 * grande e nella griglia la miniatura esce schiacciata o invisibile.
 */
add_filter('wp_generate_attachment_metadata', 'idealugano_svg_attachment_metadata', 10, 2);
function idealugano_svg_attachment_metadata($metadata, $attachment_id)
{
    if (get_post_mime_type($attachment_id) !== 'image/svg+xml') {
        return $metadata;
    }
    $size = idealugano_svg_dimensions(get_attached_file($attachment_id));
    if ($size) {
        $metadata = is_array($metadata) ? $metadata : array();
        $metadata['width']  = $size[0];
        $metadata['height'] = $size[1];
        $metadata['file']   = _wp_relative_upload_path(get_attached_file($attachment_id));
        $metadata['sizes']  = isset($metadata['sizes']) ? $metadata['sizes'] : array();
    }
    return $metadata;
}

/**
 * Legge larghezza e altezza da un file SVG, dagli attributi o dal viewBox.
 *
 * @param string $path Percorso del file.
 * @return array{0:int,1:int}|null
 */
function idealugano_svg_dimensions($path)
{
    if (!$path || !file_exists($path)) {
        return null;
    }
    $head = file_get_contents($path, false, null, 0, 4096); // phpcs:ignore WordPress.WP.AlternativeFunctions -- file locale.
    if (!$head || !preg_match('/<svg\b[^>]*>/is', $head, $m)) {
        return null;
    }
    $tag = $m[0];
    $w = preg_match('/\bwidth\s*=\s*["\']\s*([\d.]+)/i', $tag, $a) ? (float) $a[1] : 0;
    $h = preg_match('/\bheight\s*=\s*["\']\s*([\d.]+)/i', $tag, $b) ? (float) $b[1] : 0;
    if ((!$w || !$h) && preg_match('/viewBox\s*=\s*["\']\s*[-\d.]+[,\s]+[-\d.]+[,\s]+([\d.]+)[,\s]+([\d.]+)/i', $tag, $c)) {
        $w = (float) $c[1];
        $h = (float) $c[2];
    }
    if ($w <= 0 || $h <= 0) {
        return null;
    }
    return array((int) round($w), (int) round($h));
}

/**
 * La miniatura di un SVG nella griglia della libreria media: senza questa
 * regola l'anteprima e' un riquadro vuoto.
 */
add_action('admin_head', 'idealugano_svg_admin_thumb_css');
function idealugano_svg_admin_thumb_css()
{
    if (!idealugano_svg_user_allowed()) {
        return;
    }
    ?>
    <style>
        .media-icon img[src$=".svg"],
        .attachment .thumbnail img[src$=".svg"],
        .attachment-preview .thumbnail img[src$=".svg"],
        td.column-icon img[src$=".svg"] {
            width: 100%;
            height: auto;
        }
    </style>
    <?php
}
