<?php
/**
 * Landing page dei servizi — dati centralizzati
 *
 * Cinque pagine dedicate, una per gruppo di annunci Google Ads, nell'ordine di
 * priorita' indicato dal cliente (set 2026): tendaggi, divani/letti e imbottiti
 * nuovi, rifacimento imbottiti, tessuti d'arredamento al metro, arredamento
 * d'interni completo. Ogni pagina e' servita da `page-landing.php` e viene
 * riconosciuta dallo slug (o dal meta `_idealugano_landing`).
 *
 * Testi, nomi e immagini dei prodotti partner provengono dai siti ufficiali dei
 * fornitori (Kadeco, MHZ, Silent Gliss, Tréca Paris, Dedar, Decortex Firenze):
 * i marchi e le foto restano di proprieta' dei rispettivi titolari e sono
 * mostrati in quanto Idea Lugano ne e' rivenditore/partner.
 *
 * @package Idealugano
 * @version 1.0.2
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Tutte le landing, in ordine di priorita' commerciale.
 *
 * @return array slug => dati
 */
function idealugano_get_landings()
{
    static $landings = null;
    if ($landings !== null) {
        return $landings;
    }

    $landings = array(

        /* ───────────── 1. TENDE SU MISURA ───────────── */
        'tende-su-misura' => array(
            'menu_label'   => 'Tende su misura',
            'short'        => 'Tende su misura',
            'eyebrow'      => 'Tendaggi',
            'title'        => 'Tende su misura a Lugano',
            'subtitle'     => 'Tendaggi confezionati nel nostro atelier di Bedano con tessuti dei marchi più conosciuti, binari e motorizzazioni Silent Gliss, MHZ, Kadeco, Casa Valentina, Scaglioni e Interstil. Sopralluogo, progetto e posa a Lugano, in tutta la Svizzera e all\'estero.',
            'hero_slot'    => 'land_tende_hero',
            'seo_title'    => 'Tende su Misura a Lugano | Tendaggi, Binari e Tessuti | Idea Lugano',
            'seo_desc'     => 'Tende su misura a Lugano, in Svizzera e all\'estero: tende arricciate, a onda, a pannello, a pacchetto, a rullo e plissettate. Tessuti Dedar e Decortex, sistemi Silent Gliss, MHZ e Kadeco. Sopralluogo e posa.',
            'intro'        => array(
                'Le tende sono il cuore del nostro lavoro. Da oltre vent\'anni realizziamo tendaggi su misura per case, appartamenti, studi e strutture ricettive a Lugano, in tutta la Svizzera e all\'estero: dal sopralluogo con rilievo delle misure alla confezione in atelier, fino alla posa dei binari e alla messa in opera.',
                'Scegliamo i tessuti fra le collezioni dei distributori più importanti del settore, li confezioniamo a mano e li abbiniamo ai sistemi di scorrimento e alle motorizzazioni più affidabili sul mercato. Il risultato è una tenda che veste la finestra con precisione, regola la luce e la privacy e dura nel tempo.',
            ),
            'pillars'      => array(
                array('title' => 'Sopralluogo e rilievo', 'text' => 'Veniamo a casa tua, misuriamo ogni finestra e ti consigliamo il tipo di tenda, il tessuto e il sistema più adatto alla stanza.'),
                array('title' => 'Confezione in atelier', 'text' => 'Ogni tenda è cucita nel nostro laboratorio di Bedano: orli, piombi, fettucce, arricciature e finiture eseguite a mano.'),
                array('title' => 'Posa e motorizzazione', 'text' => 'Installiamo binari, bastoni e sistemi motorizzati Silent Gliss, MHZ, Kadeco, Casa Valentina, Scaglioni e Interstil, integrabili con la domotica di casa.'),
            ),
            'offer'        => array(
                'title' => 'Che tipo di tende realizziamo',
                'items' => array(
                    'Tende a strappo e a scorrimento, classiche e moderne, con fettuccia, piega fiamminga o cannoncino',
                    'Tende a onda (wave) su binario, per un\'onda regolare e continua',
                    'Tende a pannello scorrevoli, anche come divisori d\'ambiente',
                    'Tende a pacchetto e tende romane in tessuto coordinato',
                    'Tende a rullo, plissettate e a nido d\'ape, tecniche o decorative',
                    'Veneziane e tende a lamelle verticali per uffici e vetrate',
                    'Tende oscuranti e dim-out per camere da letto',
                    'Mantovane, drappeggi, cordoni e passamanerie su misura',
                ),
            ),
            'suppliers'    => array(
                'title' => 'Sistemi e collezioni dei nostri partner',
                'text'  => 'Lavoriamo con i produttori europei di riferimento per binari, motorizzazioni e schermature tecniche; i tessuti arrivano dagli editori presentati nella pagina Tessuti. Tutti i sistemi sono realizzati su misura per le tue finestre.',
                'items' => array(
                    array('brand' => 'Silent Gliss', 'title' => 'Sistemi per tende arricciate e Wave', 'desc' => 'Il tessuto scorre lungo i binari Silent Gliss nella più classica soluzione di schermatura per interni: sistemi a strappo, a corda e motorizzati, compresi i sistemi Wave per l\'onda perfetta.', 'slot' => 'sup_silentgliss_tende_arricciate', 'url' => 'https://www.silentgliss.it/itit/prodotti/view/tende-arricciate/'),
                    array('brand' => 'Silent Gliss', 'title' => 'Binari motorizzati e smart home', 'desc' => 'Oltre 60 anni di esperienza nei sistemi motorizzati: tra i più silenziosi e fluidi sul mercato, comandabili da interruttore, telecomando, app o impianto domotico.', 'slot' => 'sup_silentgliss_binario_motorizzato', 'url' => 'https://www.silentgliss.it/itit/motorizzazione-smart/motorizzazione/'),
                    array('brand' => 'Silent Gliss', 'title' => 'Tende a pannelli scorrevoli', 'desc' => 'Pannelli scorrevoli di ispirazione giapponese per l\'oscuramento di finestre e la divisione degli ambienti, su binari dritti o curvi, manuali o elettrici.', 'slot' => 'sup_silentgliss_tende_a_pannelli', 'url' => 'https://www.silentgliss.it/itit/prodotti/view/tende-a-pannelli/'),
                    array('brand' => 'MHZ', 'title' => 'Binari e bastoni per tende', 'desc' => 'Binari a soffitto e a parete, bastoni e accessori di montaggio su misura per tende a strappo, a scorrimento e Wave: la parte tecnica, invisibile ma decisiva, di ogni tendaggio.', 'slot' => 'sup_mhz_binari_sistemi', 'url' => 'https://www.mhz.ch/it/interno/binari-per-tende/'),
                    array('brand' => 'MHZ', 'title' => 'Tende a pacchetto', 'desc' => 'Soluzione decorativa e funzionale che si solleva in pieghe morbide: ideale per cucine, bagni e finestre dove serve compattezza.', 'slot' => 'sup_mhz_tende_a_pacchetto', 'url' => 'https://www.mhz.ch/it/interno/tende-a-pacchetto/'),
                    array('brand' => 'MHZ', 'title' => 'Tende plissettate e a nido d\'ape', 'desc' => 'Protezione visiva e solare dal design sofisticato, con oltre 200 tessuti e la variante DUETTE a nido d\'ape per l\'isolamento termico.', 'slot' => 'sup_mhz_tende_plissettate', 'url' => 'https://www.mhz.ch/it/interno/tende-plissettate/'),
                    array('brand' => 'Kadeco', 'title' => 'Tende plissettate Kadeco', 'desc' => 'Plissé classici e a nido d\'ape, fissi o sospesi, anche per lucernari e forme speciali. Made in Germany, con precisione artigianale.', 'slot' => 'sup_kadeco_tende_plissettate', 'url' => 'https://www.kadeco.de/it/interni/tende-plissettate'),
                    array('brand' => 'Kadeco', 'title' => 'Tende a rullo e cassonetti', 'desc' => 'Tende a rullo aperte, con profilo portante o cassonetto integrato, tessuti MicroTex e collezioni coordinate per ogni ambiente.', 'slot' => 'sup_kadeco_tende_a_rullo', 'url' => 'https://www.kadeco.de/it/interni/tende-a-rullo'),
                    array('brand' => 'Kadeco', 'title' => 'Veneziane e tende a pannello', 'desc' => 'Veneziane in alluminio, feltro e legno per gestire la luce, e pannelli scorrevoli FreeLine, ClassicLine e SlimLine in tessuti moderni.', 'slot' => 'sup_kadeco_veneziane', 'url' => 'https://www.kadeco.de/it/interni/veneziane'),
                ),
            ),
            'gallery_category' => 'tende',
            'before_after' => false,
            'faq'          => array(
                array('q' => 'Quanto costano le tende su misura?', 'a' => 'Il prezzo dipende da tessuto, metratura, tipo di confezione e sistema di scorrimento. Dopo il sopralluogo gratuito prepariamo un preventivo dettagliato, senza impegno.'),
                array('q' => 'Fate anche il sopralluogo e la posa?', 'a' => 'Sì. Rileviamo le misure a domicilio, consigliamo tessuti e sistemi, confezioniamo in atelier e installiamo binari, bastoni e motorizzazioni. Interveniamo a Lugano, in tutta la Svizzera e anche all\'estero.'),
                array('q' => 'Posso motorizzare le tende e comandarle dallo smartphone?', 'a' => 'Certo. Proponiamo binari motorizzati Silent Gliss, MHZ, Kadeco, Casa Valentina, Scaglioni e Interstil con comando a interruttore, telecomando, app o integrazione con la domotica di casa.'),
                array('q' => 'Quali tessuti posso scegliere?', 'a' => 'Abbiamo campionari sempre aggiornati dei principali editori tessili, tra cui Dedar e Decortex Firenze. In atelier puoi vedere e toccare i campioni su appuntamento.'),
                array('q' => 'Rifate anche tende esistenti?', 'a' => 'Sì: accorciamo, allunghiamo, sostituiamo fodere e fettucce, cambiamo il sistema di scorrimento o adattiamo le tende a una nuova casa.'),
            ),
            'related'      => array('tessuti-arredamento', 'arredamento-interni'),
            'service_type' => 'Tende su misura',
            'keywords'     => array('Tende su misura', 'Tendaggi', 'Tende a onda', 'Tende a pannello', 'Tende a rullo', 'Tende plissettate', 'Binari motorizzati per tende'),
            'form_subject' => 'Richiesta preventivo tende su misura',
            'cta_title'    => 'Richiedi un preventivo per le tue tende',
            'cta_text'     => 'Raccontaci le finestre da vestire: ti richiamiamo per fissare il sopralluogo gratuito.',
        ),

        /* ───────────── 2. DIVANI, LETTI E IMBOTTITI ───────────── */
        'divani-letti-su-misura' => array(
            'menu_label'   => 'Divani e letti su misura',
            'short'        => 'Divani e letti',
            'eyebrow'      => 'Mobili imbottiti',
            'title'        => 'Divani, letti e mobili imbottiti su misura a Lugano',
            'subtitle'     => 'Divani, poltrone, letti, testiere e materassi realizzati su misura e rivestiti con i tessuti che scegli tu. Distributori Tréca Paris per letti e sistemi di riposo d\'alta gamma.',
            'hero_slot'    => 'land_divani_hero',
            'seo_title'    => 'Divani e Letti su Misura a Lugano | Mobili Imbottiti | Idea Lugano',
            'seo_desc'     => 'Divani su misura, poltrone, letti imbottiti, testiere e materassi Tréca Paris a Lugano. Progettazione, scelta del tessuto e realizzazione artigianale a Lugano, consegna in tutta la Svizzera e all\'estero. Richiedi un preventivo.',
            'intro'        => array(
                'Forniamo mobili imbottiti nuovi, realizzati su misura per il tuo spazio: divani lineari, angolari e modulari, poltrone, panche, pouf, letti imbottiti e testiere. Definiamo insieme dimensioni, seduta, densità delle imbottiture e finiture, poi rivestiamo il mobile con il tessuto o la pelle scelti dalle nostre collezioni.',
                'Per il riposo siamo rivenditori Tréca Paris, la maison francese che confeziona a mano materassi, sommier e testiere componendo veri sistemi di riposo. Il letto diventa così un pezzo unico, coordinato a tende, cuscini e copriletti realizzati nel nostro atelier.',
            ),
            'pillars'      => array(
                array('title' => 'Su misura, non a catalogo', 'text' => 'Misure, proporzioni e comfort sono progettati per la tua stanza. Nessun compromesso su ingombri o seduta.'),
                array('title' => 'Tessuti e pelli a scelta', 'text' => 'Velluti, bouclé, lini, jacquard e pelli dei migliori editori tessili europei, con resistenza certificata per l\'uso quotidiano.'),
                array('title' => 'Letti e materassi Tréca Paris', 'text' => 'Sistemi di riposo confezionati a mano in Francia: materassi, sommier, testiere e piedi personalizzabili.'),
            ),
            'offer'        => array(
                'title' => 'Cosa realizziamo e forniamo',
                'items' => array(
                    'Divani su misura lineari, angolari, modulari e divani letto',
                    'Poltrone, bergère, chaise longue, panche e pouf',
                    'Letti imbottiti e testiere su disegno: lisce, capitonné, a pannelli o con bordure',
                    'Materassi, sommier e sur-matelas Tréca Paris',
                    'Sedie e sgabelli imbottiti coordinati alla sala da pranzo',
                    'Copriletti, plaid, cuscini decorativi e biancheria coordinata',
                ),
            ),
            'suppliers'    => array(
                'title' => 'Tréca Paris: il riposo confezionato a mano',
                'text'  => 'Tréca Paris è l\'unica maison francese di letti interamente realizzati a mano. Ogni sistema di riposo unisce sur-matelas, materasso e sommier, con testiera nel tessuto o nella pelle che preferisci. Siamo rivenditori autorizzati, con consegna in tutta la Svizzera e all\'estero.',
                'items' => array(
                    array('brand' => 'Tréca Paris', 'title' => 'Sistemi di riposo', 'desc' => 'Auguste, Apogée, Louange, Paris Vienne Venise, Beau Rivage, Platinum e Impérial: ogni sistema abbina sur-matelas, materasso e sommier pensati come una sola creazione.', 'slot' => 'sup_treca_sistema_paris_vienne_venise', 'url' => 'https://www.treca-paris.com/ch/fr/nos-lits/'),
                    array('brand' => 'Tréca Paris', 'title' => 'Materassi', 'desc' => 'Materassi a molle insacchettate e fibre nobili (lana, cashmere, seta, crine), lavorati a mano: dalla linea Platinum ai modelli Impérial e Pullman.', 'slot' => 'sup_treca_materassi', 'url' => 'https://www.treca-paris.com/ch/fr/categorie-produit/matelas/'),
                    array('brand' => 'Tréca Paris', 'title' => 'Testiere imbottite', 'desc' => 'Modelli Montecarlo, Versailles, Lounge, Louis XV, Louis XVI, Moon, Poésie e Portofino, rivestiti nel tessuto o nella pelle scelti con noi.', 'slot' => 'sup_treca_testiera_montecarlo', 'url' => 'https://www.treca-paris.com/ch/fr/categorie-produit/tetes-de-lit/'),
                    array('brand' => 'Tréca Paris', 'title' => 'Sommier e piedi', 'desc' => 'Sommier prestige a molle o a doghe, fissi o motorizzati, con piedi in legno o metallo in molte finiture.', 'slot' => 'sup_treca_sommier', 'url' => 'https://www.treca-paris.com/ch/fr/categorie-produit/sommiers/'),
                    array('brand' => 'Dedar', 'title' => 'Tessuti per rivestimento', 'desc' => 'Velluti di cotone, mohair e seta, bouclé di lana, chenille e lini per uso intensivo: la collezione upholstery Dedar per divani e poltrone che durano.', 'slot' => 'sup_dedar_karakorum_boucle', 'url' => 'https://dedar.com/products/upholstery/'),
                    array('brand' => 'Decortex Firenze', 'title' => 'Jacquard e gobelin', 'desc' => 'Tessuti fiorentini in puro cotone e lino a uso pesante (Martindale 30.000), ideali per sedute, testiere e cuscini.', 'slot' => 'sup_decortex_birdie', 'url' => 'https://www.decortex.com/fabrics/'),
                ),
            ),
            'gallery_category' => 'divani-letti',
            'before_after' => false,
            'faq'          => array(
                array('q' => 'Realizzate divani su misura a Lugano?', 'a' => 'Sì. Progettiamo divani e poltrone su misura per dimensioni, seduta e rivestimento, li facciamo realizzare da tappezzieri artigiani e li consegniamo montati a Lugano, in tutta la Svizzera e all\'estero.'),
                array('q' => 'Vendete anche letti e materassi?', 'a' => 'Sì: siamo rivenditori Tréca Paris per letti, materassi, sommier e testiere. In atelier a Bedano ti aiutiamo a comporre il sistema di riposo più adatto, su appuntamento.'),
                array('q' => 'Posso scegliere il tessuto del divano?', 'a' => 'Certo. Scegli fra i campionari di Dedar, Decortex Firenze e degli altri editori che rappresentiamo, oppure porta un tuo tessuto: ti indichiamo la resistenza adatta all\'uso.'),
                array('q' => 'Quanto tempo serve per un divano su misura?', 'a' => 'In media da sei a dieci settimane dalla conferma dell\'ordine, in base a modello e disponibilità del tessuto. Il preventivo indica sempre i tempi di consegna.'),
                array('q' => 'Realizzate testiere imbottite per letti esistenti?', 'a' => 'Sì, anche solo la testiera: su disegno, liscia, capitonné o a pannelli, coordinata a copriletto e cuscini.'),
            ),
            'related'      => array('rifacimento-divani-poltrone', 'tessuti-arredamento'),
            'service_type' => 'Divani e letti su misura',
            'keywords'     => array('Divani su misura', 'Poltrone', 'Letti imbottiti', 'Testiere letto', 'Materassi Tréca Paris', 'Mobili imbottiti'),
            'form_subject' => 'Richiesta divani, letti e imbottiti su misura',
            'cta_title'    => 'Progettiamo insieme il tuo divano o il tuo letto',
            'cta_text'     => 'Descrivici lo spazio e lo stile che desideri: ti proponiamo modelli, tessuti e un preventivo su misura.',
        ),

        /* ───────────── 3. RIFACIMENTO E RIVESTIMENTO ───────────── */
        'rifacimento-divani-poltrone' => array(
            'menu_label'   => 'Rifacimento divani e poltrone',
            'short'        => 'Rifacimento imbottiti',
            'eyebrow'      => 'Tappezzeria',
            'title'        => 'Rifacimento e rivestimento di divani, poltrone e sedie a Lugano',
            'subtitle'     => 'Rimettiamo a nuovo i tuoi mobili imbottiti: nuove imbottiture, molleggi e rivestimenti sartoriali per divani, poltrone, sedie, panche e testiere. Laboratorio di tappezzeria a Bedano, ritiro e consegna in tutta la Svizzera e all\'estero.',
            'hero_slot'    => 'land_rifacimento_hero',
            'seo_title'    => 'Rifacimento Divani e Poltrone a Lugano | Tappezziere | Idea Lugano',
            'seo_desc'     => 'Ritappezzare divano, poltrona o sedie a Lugano: rifacimento imbottiture, molleggio e rivestimento con tessuti Dedar e Decortex. Tappezziere artigiano a Bedano, ritiro e consegna in tutta la Svizzera e all\'estero.',
            'intro'        => array(
                'Un divano con una buona struttura, una poltrona di famiglia o un set di sedie possono tornare come nuovi. Nel nostro laboratorio di tappezzeria smontiamo il mobile, sostituiamo o integriamo le imbottiture, controlliamo molleggio e cinghie e lo rivestiamo con il tessuto o la pelle che scegli tu.',
                'Rifare un imbottito conviene quando il mobile ha valore affettivo, proporzioni perfette per la stanza o una qualità costruttiva che oggi è difficile trovare. Ed è una scelta sostenibile: si conserva la struttura e si rinnova solo ciò che serve.',
            ),
            'pillars'      => array(
                array('title' => 'Diagnosi e preventivo', 'text' => 'Valutiamo struttura, molleggio e imbottiture a domicilio o su foto, e ti diciamo con chiarezza cosa conviene rifare.'),
                array('title' => 'Lavorazione artigianale', 'text' => 'Espansi a densità differenziata, ovatte, cinghie elastiche, molle: materiali conformi agli standard artigianali più rigorosi.'),
                array('title' => 'Rivestimento sartoriale', 'text' => 'Tessuti e pelli ad alta resistenza allo sfregamento, passamanerie, bottoni e cordoni per rispettare lo stile originale o crearne uno nuovo.'),
            ),
            'offer'        => array(
                'title' => 'Cosa rifacciamo',
                'items' => array(
                    'Rivestimento completo di divani e divani letto',
                    'Rifacimento imbottiture e molleggi di poltrone e bergère',
                    'Ritappezzatura di sedie, sgabelli, panche e poltroncine',
                    'Restauro di poltrone e divani d\'epoca (Luigi XV, Luigi XVI, Chesterfield)',
                    'Rifacimento testiere letto, pouf e cuscini di seduta',
                    'Fodere sfoderabili e cuscini nuovi per divani esistenti',
                    'Rifacimento paralumi e piccoli complementi imbottiti',
                ),
            ),
            'suppliers'    => array(
                'title' => 'I tessuti per il nuovo rivestimento',
                'text'  => 'Scegli il tessuto in atelier fra i campionari degli editori che rappresentiamo. Ti indichiamo sempre la resistenza (test Martindale) più adatta all\'uso che ne farai.',
                'items' => array(
                    array('brand' => 'Dedar', 'title' => 'Karakorum, bouclé di lana', 'desc' => 'Bouclé di lana e viscosa dalla trama irregolare ispirata all\'astrakan, morbido e corposo, indicato per tappezzeria a uso intensivo (larghezza 130 cm).', 'slot' => 'sup_dedar_karakorum_boucle', 'url' => 'https://dedar.com/karakorum/'),
                    array('brand' => 'Dedar', 'title' => 'Collezione upholstery', 'desc' => 'Velluti di cotone, mohair e seta, chenille, lini e jacquard: la collezione Dedar dedicata al rivestimento di sedute.', 'slot' => 'sup_dedar_tessuti_tappezzeria', 'url' => 'https://dedar.com/products/upholstery/'),
                    array('brand' => 'Decortex Firenze', 'title' => 'Birdie 1390, gobelin jacquard', 'desc' => 'Geometria jacquard in puro cotone dalla mano piena, Martindale 30.000, per sedute, cuscini, pannelli e testiere. Tre varianti colore.', 'slot' => 'sup_decortex_birdie', 'url' => 'https://www.decortex.com/fabrics/'),
                    array('brand' => 'Decortex Firenze', 'title' => 'Emino 1392, riga di lino', 'desc' => 'Fine riga verticale su lino dalla mano classica: per rivestimenti, cuscini e tende a pacchetto. Quattro varianti colore.', 'slot' => 'sup_decortex_emino', 'url' => 'https://www.decortex.com/fabrics/'),
                ),
            ),
            'gallery_category' => 'rifacimenti',
            'before_after' => true,
            'faq'          => array(
                array('q' => 'Quanto costa rifoderare un divano?', 'a' => 'Dipende dalle dimensioni, dallo stato di imbottiture e molleggio e dal tessuto scelto. Inviaci qualche foto e le misure: ti diamo una prima indicazione e poi un preventivo preciso dopo la visita.'),
                array('q' => 'Conviene rifare o comprare nuovo?', 'a' => 'Conviene rifare quando la struttura è solida, il mobile ha valore affettivo o proporzioni difficili da ritrovare. Ti diciamo onestamente quando invece è meglio sostituirlo.'),
                array('q' => 'Ritirate e riconsegnate il mobile?', 'a' => 'Sì. Organizziamo ritiro e consegna a Lugano, in tutta la Svizzera e all\'estero, con imballo protettivo.'),
                array('q' => 'Quanto tempo resta il divano in laboratorio?', 'a' => 'Di norma da due a quattro settimane, in base all\'intervento e alla disponibilità del tessuto.'),
                array('q' => 'Fate anche solo le fodere o i cuscini?', 'a' => 'Certo: fodere sfoderabili, cuscini di seduta e schienale, testiere e paralumi si possono rifare anche senza intervenire sulla struttura.'),
            ),
            'related'      => array('divani-letti-su-misura', 'tessuti-arredamento'),
            'service_type' => 'Rifacimento e rivestimento mobili imbottiti',
            'keywords'     => array('Rifacimento divani', 'Rivestimento poltrone', 'Ritappezzare sedie', 'Tappezziere Lugano', 'Restauro imbottiti', 'Rifacimento paralumi'),
            'form_subject' => 'Richiesta rifacimento divano, poltrona o sedie',
            'cta_title'    => 'Mandaci una foto del tuo divano',
            'cta_text'     => 'Descrivi il mobile e cosa vorresti cambiare: ti rispondiamo con una prima valutazione e fissiamo la visita.',
        ),

        /* ───────────── 4. TESSUTI D'ARREDAMENTO ───────────── */
        'tessuti-arredamento' => array(
            'menu_label'   => 'Tessuti per l\'arredamento',
            'short'        => 'Tessuti d\'arredo',
            'eyebrow'      => 'Collezioni tessili',
            'title'        => 'Tessuti per l\'arredamento a Lugano',
            'subtitle'     => 'Una grande scelta di tessuti d\'arredo dai maggiori distributori del settore: velluti, lini, jacquard, sheer e carte da parati. Anche al metro, per chi confeziona altrove o da sé.',
            'hero_slot'    => 'land_tessuti_hero',
            'seo_title'    => 'Tessuti per Arredamento a Lugano | Dedar, Decortex Firenze | Idea Lugano',
            'seo_desc'     => 'Tessuti d\'arredamento a Lugano: collezioni Dedar, Decortex Firenze e dei maggiori editori tessili per tende, divani, cuscini e pareti. Vendita anche al metro, campionari in atelier a Bedano su appuntamento.',
            'intro'        => array(
                'Il tessuto è la materia prima di tutto quello che facciamo, e proprio per questo ne abbiamo una scelta molto ampia. Rappresentiamo i maggiori distributori del settore tessile per l\'arredamento e teniamo i campionari sempre aggiornati con le nuove collezioni.',
                'Da noi acquista tessuto anche chi vuole farlo confezionare altrove o lavorarlo personalmente: vendiamo al metro tessuti per tende, per rivestimenti, per cuscini e biancheria, oltre a carte da parati e rivestimenti murali. In atelier, su appuntamento, puoi vedere e toccare i campioni con la luce giusta.',
            ),
            'pillars'      => array(
                array('title' => 'Collezioni sempre aggiornate', 'text' => 'Campionari completi delle ultime collezioni: nuovi colori, nuove trame e nuovi disegni ogni stagione.'),
                array('title' => 'Vendita anche al metro', 'text' => 'Puoi acquistare solo il tessuto e farlo confezionare dove preferisci. Ti consigliamo metrature e altezze.'),
                array('title' => 'Consulenza sui materiali', 'text' => 'Resistenza (Martindale), tenuta del colore, lavaggio, ignifughi: ti aiutiamo a scegliere il tessuto giusto per l\'uso.'),
            ),
            'offer'        => array(
                'title' => 'Che tessuti trovi da noi',
                'items' => array(
                    'Tessuti per tende: lini, cotoni, sete, sheer e voile, oscuranti e dim-out',
                    'Tessuti per rivestimento: velluti, bouclé, chenille, jacquard e gobelin ad alta resistenza',
                    'Tessuti per cuscini, copriletti, tovagliati e biancheria per la casa',
                    'Pelli, ecopelli e tessuti tecnici per esterni',
                    'Carte da parati e rivestimenti murali tessili',
                    'Passamanerie, cordoni, nappe, frange e bottoni rivestiti',
                ),
            ),
            'suppliers'    => array(
                'title' => 'Gli editori che rappresentiamo',
                'text'  => 'Una selezione dei marchi presenti nei nostri campionari. Chiedici anche gli altri distributori con cui lavoriamo.',
                'items' => array(
                    array('brand' => 'Dedar', 'title' => 'Tessuti per tappezzeria', 'desc' => 'La maison milanese di tessuti d\'autore: velluti Adamo & Eva e Splendido, bouclé Karakorum, mohair Vladimiro, chenille e lini per uso intensivo.', 'slot' => 'sup_dedar_tessuti_tappezzeria', 'url' => 'https://dedar.com/products/upholstery/'),
                    array('brand' => 'Dedar', 'title' => 'Tessuti per tende e sheer', 'desc' => 'Tessuti decorativi per tende e veli semitrasparenti in lino, cotone e fibre tecniche, in grandi altezze.', 'slot' => 'sup_dedar_tessuti_tende', 'url' => 'https://dedar.com/products/curtain/'),
                    array('brand' => 'Dedar', 'title' => 'Carte da parati e wallcovering', 'desc' => 'Rivestimenti murali tessili e carte da parati coordinate alle collezioni di tessuti, per progetti d\'interni completi.', 'slot' => 'sup_dedar_carte_da_parati', 'url' => 'https://dedar.com/products/wallcovering/'),
                    array('brand' => 'Decortex Firenze', 'title' => 'Birdie 1390', 'desc' => 'Gobelin jacquard in puro cotone, 140 cm, Martindale 30.000: per sedute, cuscini, pannelli murali e testiere. Varianti verde, calda e blu.', 'slot' => 'sup_decortex_birdie', 'url' => 'https://www.decortex.com/fabrics/'),
                    array('brand' => 'Decortex Firenze', 'title' => 'Emino 1392', 'desc' => 'Riga sottile su lino dalla mano naturale: per rivestimenti, cuscini e tende a pacchetto in quattro varianti colore.', 'slot' => 'sup_decortex_emino', 'url' => 'https://www.decortex.com/fabrics/'),
                    array('brand' => 'Decortex Firenze', 'title' => 'Flagstaff 1391', 'desc' => 'Tessuto per interni realizzato per essere vissuto e toccato, con fibre naturali e colori sviluppati con cura a Firenze.', 'slot' => 'sup_decortex_flagstaff', 'url' => 'https://www.decortex.com/fabrics/'),
                ),
            ),
            'gallery_category' => 'tessuti',
            'before_after' => false,
            'faq'          => array(
                array('q' => 'Vendete tessuti al metro anche senza confezione?', 'a' => 'Sì. Puoi acquistare il solo tessuto e farlo lavorare altrove o da te. Ti aiutiamo a calcolare metrature, altezze e verso del disegno.'),
                array('q' => 'Posso vedere i campionari?', 'a' => 'Certo, su appuntamento nel nostro atelier di Bedano, a pochi minuti da Lugano. Puoi anche portare a casa alcuni campioni per valutarli con la luce della stanza.'),
                array('q' => 'Quali marchi di tessuti trattate?', 'a' => 'Tra gli altri Dedar e Decortex Firenze, oltre ai maggiori distributori europei di tessuti d\'arredamento. Chiedici un marchio specifico: quasi sempre possiamo procurarlo.'),
                array('q' => 'Avete anche carte da parati?', 'a' => 'Sì, carte da parati e rivestimenti murali tessili coordinati alle collezioni di tessuti, con posa a cura di artigiani di fiducia.'),
                array('q' => 'Quanto costa un tessuto d\'arredamento?', 'a' => 'I prezzi al metro variano molto in base a fibra, lavorazione e marchio. In atelier ti mostriamo alternative in fasce di prezzo diverse per lo stesso effetto.'),
            ),
            'related'      => array('tende-su-misura', 'rifacimento-divani-poltrone'),
            'service_type' => 'Vendita tessuti per l\'arredamento',
            'keywords'     => array('Tessuti per arredamento', 'Tessuti al metro', 'Tessuti per tende', 'Tessuti per divani', 'Carte da parati', 'Dedar', 'Decortex'),
            'form_subject' => 'Richiesta tessuti per l\'arredamento',
            'cta_title'    => 'Cerchi un tessuto particolare?',
            'cta_text'     => 'Dicci per cosa ti serve e che effetto cerchi: ti prepariamo una selezione di campioni da vedere in atelier.',
        ),

        /* ───────────── 5. ARREDAMENTO D'INTERNI ───────────── */
        'arredamento-interni' => array(
            'menu_label'   => 'Arredamento d\'interni',
            'short'        => 'Arredamento completo',
            'eyebrow'      => 'Progetto completo',
            'title'        => 'Arredamento d\'interni a Lugano: tutto ciò che serve alla tua casa',
            'subtitle'     => 'Oltre a tende, imbottiti e tessuti, forniamo tutto quanto serve ad arredare una casa o un appartamento: tappeti, moquette, carte da parati, illuminazione e complementi, con un\'unica consulenza.',
            'hero_slot'    => 'land_arredamento_hero',
            'seo_title'    => 'Arredamento d\'Interni a Lugano | Tappeti, Carte da Parati, Luci | Idea Lugano',
            'seo_desc'     => 'Arredamento d\'interni completo da Lugano per tutta la Svizzera e l\'estero: consulenza, tende, divani, tappeti, moquette, carte da parati, illuminazione e complementi coordinati. Un solo interlocutore per tutta la casa.',
            'intro'        => array(
                'Chi arreda una casa o un appartamento non vuole dieci fornitori diversi. Da noi trovi un solo interlocutore che coordina tende, mobili imbottiti, tessuti, tappeti, moquette, carte da parati, illuminazione e complementi, seguendo il progetto dal primo sopralluogo alla consegna.',
                'Non siamo un negozio di mobili: siamo un atelier che progetta e realizza su misura. Ascoltiamo come vivi gli spazi, proponiamo materiali e colori coerenti fra loro e ci occupiamo delle lavorazioni artigianali e delle posa, con artigiani di fiducia per pavimenti e pareti.',
            ),
            'pillars'      => array(
                array('title' => 'Consulenza a domicilio', 'text' => 'Sopralluogo, ascolto delle esigenze e proposta di materiali, colori e soluzioni per ogni stanza.'),
                array('title' => 'Un solo interlocutore', 'text' => 'Coordiniamo fornitori, artigiani e tempi: tu parli sempre con la stessa persona.'),
                array('title' => 'Realizzazione e posa', 'text' => 'Confezione in atelier, consegna e installazione di tende, imbottiti, tappeti, carte da parati e luci.'),
            ),
            'offer'        => array(
                'title' => 'Cosa forniamo per la casa',
                'items' => array(
                    'Tende, tendaggi e schermature per ogni finestra',
                    'Divani, poltrone, letti e sedute su misura',
                    'Tappeti su misura e moquette',
                    'Carte da parati e rivestimenti murali',
                    'Illuminazione decorativa, lampade e paralumi su misura',
                    'Cuscini, copriletti, plaid e biancheria coordinata',
                    'Oggettistica e complementi d\'arredo su richiesta',
                ),
            ),
            'suppliers'    => array(
                'title' => 'Materiali e partner del progetto',
                'text'  => 'Un progetto coordinato nasce da materiali che dialogano fra loro. Alcuni dei partner con cui componiamo gli interni.',
                'items' => array(
                    array('brand' => 'Dedar', 'title' => 'Carte da parati e wallcovering', 'desc' => 'Rivestimenti murali tessili e carte da parati coordinate ai tessuti di tende e imbottiti.', 'slot' => 'sup_dedar_carte_da_parati', 'url' => 'https://dedar.com/products/wallcovering/'),
                    array('brand' => 'Tréca Paris', 'title' => 'Mobili e accessori per la camera', 'desc' => 'Comodini, panche e accessori disegnati per accompagnare i letti Tréca: oggetti decorativi che completano la camera.', 'slot' => 'sup_treca_mobilier', 'url' => 'https://www.treca-paris.com/ch/fr/categorie-produit/mobilier/'),
                    array('brand' => 'Silent Gliss', 'title' => 'Sistemi motorizzati integrati', 'desc' => 'Binari e tende motorizzate integrabili con la domotica della casa, per un progetto d\'interni anche tecnologico.', 'slot' => 'sup_silentgliss_binario_motorizzato', 'url' => 'https://www.silentgliss.it/itit/motorizzazione-smart/motorizzazione/'),
                    array('brand' => 'MHZ', 'title' => 'Tende plissettate e schermature', 'desc' => 'Schermature tecniche coordinate ai tendaggi decorativi per lucernari, bagni, cucine e vetrate.', 'slot' => 'sup_mhz_tende_plissettate', 'url' => 'https://www.mhz.ch/it/interno/tende-plissettate/'),
                ),
            ),
            'gallery_category' => 'interni',
            'before_after' => false,
            'faq'          => array(
                array('q' => 'Arredate anche appartamenti completi?', 'a' => 'Sì. Seguiamo progetti completi di case e appartamenti a Lugano, in tutta la Svizzera e all\'estero: dal sopralluogo alla consegna di tende, imbottiti, tappeti, carte da parati e illuminazione.'),
                array('q' => 'Fornite tappeti e moquette?', 'a' => 'Sì, tappeti su misura e moquette in lana e fibre tecniche, con posa a cura di artigiani specializzati.'),
                array('q' => 'Vi occupate anche dell\'illuminazione?', 'a' => 'Forniamo lampade e illuminazione decorativa e realizziamo paralumi su misura nel nostro atelier, coordinati a tessuti e colori del progetto.'),
                array('q' => 'La consulenza d\'arredo è a pagamento?', 'a' => 'Il primo incontro e il sopralluogo sono gratuiti. Per progetti completi definiamo insieme un compenso di consulenza, che viene poi scontato sulle forniture.'),
                array('q' => 'Lavorate anche con architetti e imprese?', 'a' => 'Volentieri: collaboriamo con architetti, studi di interior design, alberghi e imprese per forniture tessili e imbottiti su misura.'),
            ),
            'related'      => array('tende-su-misura', 'divani-letti-su-misura'),
            'service_type' => 'Arredamento d\'interni',
            'keywords'     => array('Arredamento interni Lugano', 'Consulenza d\'arredo', 'Tappeti su misura', 'Moquette', 'Carte da parati', 'Illuminazione'),
            'form_subject' => 'Richiesta consulenza arredamento d\'interni',
            'cta_title'    => 'Parliamo della tua casa',
            'cta_text'     => 'Raccontaci il progetto, anche solo un\'idea: fissiamo un sopralluogo gratuito e ti proponiamo un percorso.',
        ),
    );

    return $landings;
}

/**
 * Dati della landing per uno slug (o false).
 */
function idealugano_get_landing($slug)
{
    $all = idealugano_get_landings();
    return isset($all[$slug]) ? $all[$slug] + array('slug' => $slug) : false;
}

/**
 * Landing corrispondente alla pagina corrente: prima il meta esplicito,
 * poi lo slug della pagina.
 */
function idealugano_get_current_landing($post = null)
{
    $post = get_post($post);
    if (!$post) {
        return false;
    }
    $meta = get_post_meta($post->ID, '_idealugano_landing', true);
    if ($meta && idealugano_get_landing($meta)) {
        return idealugano_get_landing($meta);
    }
    return idealugano_get_landing($post->post_name);
}

/**
 * URL pubblico di una landing (pagina se esiste, altrimenti /slug/).
 */
function idealugano_landing_url($slug)
{
    static $cache = array();
    if (!isset($cache[$slug])) {
        $page = get_page_by_path($slug, OBJECT, 'page');
        $cache[$slug] = ($page && $page->post_status === 'publish') ? get_permalink($page) : home_url('/' . $slug . '/');
    }
    return $cache[$slug];
}

/**
 * Slot immagine dichiarati dalle landing (hero + prodotti partner), usati dal
 * pannello "Immagini Sito" e dal bundle del tema.
 *
 * @return array slot => array(label, description, ratio)
 */
function idealugano_get_landing_image_slots()
{
    $slots = array();
    foreach (idealugano_get_landings() as $slug => $l) {
        $slots[$l['hero_slot']] = array(
            'label'       => 'Hero: ' . $l['menu_label'],
            'description' => 'Immagine di apertura della pagina /' . $slug . '/ (consigliata 1920×1080px)',
            'ratio'       => '16/9',
        );
        foreach ($l['suppliers']['items'] as $item) {
            if (empty($item['slot']) || isset($slots[$item['slot']])) {
                continue;
            }
            $slots[$item['slot']] = array(
                'label'       => $item['brand'] . ' — ' . $item['title'],
                'description' => 'Foto prodotto partner mostrata in /' . $slug . '/ (fonte: sito ' . $item['brand'] . ')',
                'ratio'       => '4/3',
            );
        }
    }
    return $slots;
}
