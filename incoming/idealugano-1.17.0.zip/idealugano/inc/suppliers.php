<?php
/**
 * Fornitori: sistemi per tende, editori tessili, passamanerie.
 *
 * Elenchi forniti dal cliente (Monica, ottobre 2026). I loghi sono file del
 * tema in assets/images/brands/, non allegati della libreria media: chi non ha
 * un logo utilizzabile viene reso con il nome composto tipograficamente.
 *
 * Per aggiungere un marchio: una voce nell'array, e il logo con lo stesso slug
 * in assets/images/brands/. Senza file, il nome basta.
 *
 * @package Idealugano
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Tutti i gruppi di fornitori.
 *
 * @return array<string, array{label: string, items: array<int, array>}>
 */
function idealugano_get_supplier_groups()
{
    static $groups = null;
    if ($groups !== null) {
        return $groups;
    }

    $groups = array(
        'sistemi' => array(
            'label' => 'Sistemi per tende',
            'items' => array(
                array('name' => 'Silent Gliss', 'file' => 'silent-gliss.svg', 'w' => 663, 'h' => 163),
                array('name' => 'Kadeco', 'file' => 'kadeco.png', 'w' => 260, 'h' => 48),
                array('name' => 'MHZ', 'file' => 'mhz.svg', 'w' => 350, 'h' => 97),
                array('name' => 'Casa Valentina', 'file' => 'casa-valentina.png', 'w' => 190, 'h' => 160),
                array('name' => 'Scaglioni', 'file' => 'scaglioni.png', 'w' => 290, 'h' => 80),
                array('name' => 'Interstil', 'file' => 'interstil.svg', 'w' => 125, 'h' => 43),
            ),
        ),
        'tessuti' => array(
            'label' => 'Editori tessili',
            'items' => array(
                array('name' => 'Antico Setificio Fiorentino', 'file' => 'antico-setificio-fiorentino.svg', 'w' => 372, 'h' => 538),
                array('name' => 'Création Baumann', 'file' => 'baumann.svg', 'w' => 159, 'h' => 68),
                array('name' => 'Boussac'),
                array('name' => 'Braquenié'),
                array('name' => 'Brochier', 'file' => 'brochier.png', 'w' => 440, 'h' => 91),
                array('name' => 'C&C Milano', 'file' => 'c-c-milano.png', 'w' => 157, 'h' => 100),
                array('name' => 'Camengo', 'file' => 'camengo.svg', 'w' => 258, 'h' => 45),
                array('name' => 'Casal', 'file' => 'casal.svg', 'w' => 204, 'h' => 129),
                array('name' => 'Casamance', 'file' => 'casamance.svg', 'w' => 266, 'h' => 31),
                array('name' => 'Colefax & Fowler', 'file' => 'colefax-fowler.svg', 'w' => 475, 'h' => 39),
                array('name' => 'Créations Métaphores'),
                array('name' => 'de Le Cuona', 'file' => 'de-le-cuona.png', 'w' => 401, 'h' => 62),
                array('name' => 'Decortex Firenze', 'file' => 'decortex.png', 'w' => 440, 'h' => 84),
                array('name' => 'Dedar', 'file' => 'dedar.svg', 'w' => 128, 'h' => 47),
                array('name' => 'Elitis', 'file' => 'elitis.svg', 'w' => 184, 'h' => 72),
                array('name' => 'Etro Home', 'file' => 'etro.svg', 'w' => 136, 'h' => 18),
                array('name' => 'Christian Fischbacher'),
                array('name' => 'Fortuny', 'file' => 'fortuny.png', 'w' => 181, 'h' => 160),
                array('name' => 'Gaston y Daniela', 'file' => 'gaston-y-daniela.png', 'w' => 440, 'h' => 57),
                array('name' => 'G P & J Baker', 'file' => 'gp-j-baker.png', 'w' => 440, 'h' => 85),
                array('name' => 'Holland & Sherry', 'file' => 'holland-sherry.svg', 'w' => 271, 'h' => 49),
                array('name' => 'Houlès', 'file' => 'houles.png', 'w' => 179, 'h' => 154),
                array('name' => 'JAB Anstoetz'),
                array('name' => 'Jane Churchill', 'file' => 'jane-churchill.svg', 'w' => 62, 'h' => 7),
                array('name' => 'Jim Thompson', 'file' => 'jim-thompson.svg', 'w' => 185, 'h' => 27),
                array('name' => 'Kohro', 'file' => 'kohro.png', 'w' => 440, 'h' => 83),
                array('name' => 'Landenberg', 'file' => 'landenberg.png', 'w' => 440, 'h' => 81),
                array('name' => 'Larsen', 'file' => 'larsen.svg', 'w' => 233, 'h' => 49),
                array('name' => 'Le Manach'),
                array('name' => 'Lelièvre Paris', 'file' => 'lelievre.svg', 'w' => 213, 'h' => 56),
                array('name' => 'L\'Opificio'),
                array('name' => 'Luciano Marcato'),
                array('name' => 'Manuel Canovas', 'file' => 'manuel-canovas.svg', 'w' => 359, 'h' => 66),
                array('name' => 'Mastro Raphael', 'file' => 'mastro-raphael.png', 'w' => 440, 'h' => 85),
                array('name' => 'Mulberry Home'),
                array('name' => 'Nina Campbell', 'file' => 'nina-campbell.png', 'w' => 437, 'h' => 63),
                array('name' => 'Nobilis', 'file' => 'nobilis.svg', 'w' => 100, 'h' => 26),
                array('name' => 'Nya Nordiska', 'file' => 'nya-nordiska.png', 'w' => 440, 'h' => 54),
                array('name' => 'Osborne & Little'),
                array('name' => 'Pierre Frey'),
                array('name' => 'Romo', 'file' => 'romo.svg', 'w' => 208, 'h' => 46),
                array('name' => 'Rubelli', 'file' => 'rubelli.png', 'w' => 314, 'h' => 160),
                array('name' => 'Sanderson', 'file' => 'sanderson.png', 'w' => 216, 'h' => 25),
                array('name' => 'Simta'),
                array('name' => 'Tassinari & Chatel', 'file' => 'tassinari-chatel.svg', 'w' => 427, 'h' => 208),
                array('name' => 'Verel de Belval / Le Crin'),
                array('name' => 'Villa Nova', 'file' => 'villa-nova.svg', 'w' => 252, 'h' => 37),
                array('name' => 'Voghi'),
                array('name' => 'Zimmer + Rohde', 'file' => 'zimmer-rohde.svg', 'w' => 508, 'h' => 576),
            ),
        ),
        'passamanerie' => array(
            'label' => 'Passamanerie',
            'items' => array(
                array('name' => 'Houlès', 'file' => 'houles.png', 'w' => 179, 'h' => 154),
                array('name' => 'Samuel & Sons'),
                array('name' => 'Les Passementeries de l\'Île de France', 'file' => 'passementeries-ile-de-france.png', 'w' => 440, 'h' => 116),
                array('name' => 'tts inova', 'file' => 'tts-inova.png', 'w' => 288, 'h' => 43),
                array('name' => 'Herma Partner', 'file' => 'herma-partner.svg', 'w' => 313, 'h' => 105),
            ),
        ),
    );

    /**
     * Permette a un plugin di aggiungere o togliere fornitori.
     *
     * @param array $groups Gruppi di fornitori.
     */
    $groups = apply_filters('idealugano_supplier_groups', $groups);

    return $groups;
}

/**
 * Un solo gruppo di fornitori.
 *
 * @param string $key sistemi | tessuti | passamanerie
 * @return array{label: string, items: array<int, array>}|null
 */
function idealugano_get_supplier_group($key)
{
    $groups = idealugano_get_supplier_groups();
    return isset($groups[$key]) ? $groups[$key] : null;
}

/**
 * Stampa il muro dei marchi di un gruppo.
 *
 * Chi ha un logo lo mostra, gli altri il nome composto: entrambi dentro la
 * stessa casella, cosi' la griglia resta regolare.
 *
 * @param string $key      Chiave del gruppo.
 * @param string $modifier Modificatore BEM opzionale, es. 'idea-logo-wall--lg'.
 */
function idealugano_render_logo_wall($key, $modifier = '')
{
    $group = idealugano_get_supplier_group($key);
    if (empty($group['items'])) {
        return;
    }

    $base = get_stylesheet_directory_uri() . '/assets/images/brands/';
    $classes = 'idea-logo-wall' . ($modifier ? ' ' . $modifier : '');
    ?>
    <ul class="<?php echo esc_attr($classes); ?>" role="list">
        <?php foreach ($group['items'] as $item) : ?>
            <li class="idea-logo-wall__item">
                <?php if (!empty($item['file'])) : ?>
                    <img class="idea-logo-wall__img"
                         src="<?php echo esc_url($base . $item['file']); ?>"
                         width="<?php echo (int) $item['w']; ?>"
                         height="<?php echo (int) $item['h']; ?>"
                         alt="<?php echo esc_attr($item['name']); ?>"
                         loading="lazy" decoding="async">
                <?php else : ?>
                    <span class="idea-logo-wall__name"><?php echo esc_html($item['name']); ?></span>
                <?php endif; ?>
            </li>
        <?php endforeach; ?>
    </ul>
    <?php
}
