<?php
/**
 * Handles the order query and status transition logic.
 * 
 * Uses a dual approach:
 * 1. PRIMARY: Event-driven — schedules a single cron event per order when it
 *    transitions to "processing", set to fire after the configured delay.
 * 2. FALLBACK: Periodic sweep — runs every 15 minutes to catch any orders that
 *    may have been missed by the event-driven approach.
 */

if (!defined('ABSPATH')) {
    exit;
}

class TW_WC_Order_Status_Handler {

    private static $log_folder;

    /** Default delay in minutes before auto-completing an order */
    const DEFAULT_DELAY_MINUTES = 30;

    public static function init() {
        self::$log_folder = TW_WC_ORDER_STATUS_PATH . 'logs/';

        // PRIMARY: Hook into order status change → schedule a delayed completion
        add_action('woocommerce_order_status_processing', [__CLASS__, 'schedule_order_completion'], 10, 2);

        // Handle the per-order scheduled event
        add_action('tw_wc_auto_complete_order', [__CLASS__, 'complete_single_order'], 10, 1);

        // FALLBACK: Periodic sweep to catch anything missed
        add_action('tw_wc_order_status_cron_event', [__CLASS__, 'process_orders']);
    }

    /**
     * Schedule a single cron event to complete a specific order after the delay.
     * Fires when an order transitions to "processing".
     *
     * @param int      $order_id
     * @param WC_Order $order
     */
    public static function schedule_order_completion($order_id, $order = null) {
        // Check if plugin is active in settings
        if (get_option('tw_order_status_active', 'no') !== 'yes') {
            return;
        }

        $delay_minutes = (int) apply_filters('tw_wc_order_status_threshold', self::DEFAULT_DELAY_MINUTES);
        $run_at = time() + ($delay_minutes * 60);

        // Don't schedule if one already exists for this order
        $existing = wp_next_scheduled('tw_wc_auto_complete_order', [$order_id]);
        if ($existing) {
            self::log("Order #{$order_id}: auto-complete already scheduled at " . date('Y-m-d H:i:s', $existing), "INFO");
            return;
        }

        $scheduled = wp_schedule_single_event($run_at, 'tw_wc_auto_complete_order', [$order_id]);

        if ($scheduled !== false) {
            self::log("Order #{$order_id}: scheduled auto-complete in {$delay_minutes} min (at " . date('Y-m-d H:i:s', $run_at) . ").", "INFO");
        } else {
            self::log("Order #{$order_id}: FAILED to schedule auto-complete event.", "ERROR");
        }
    }

    /**
     * Complete a single order (fired by the per-order scheduled event).
     *
     * @param int $order_id
     */
    public static function complete_single_order($order_id) {
        // Check if plugin is active in settings
        if (get_option('tw_order_status_active', 'no') !== 'yes') {
            return;
        }

        $order = wc_get_order($order_id);
        if (!$order) {
            self::log("Order #{$order_id}: not found, skipping.", "WARNING");
            return;
        }

        if ($order->get_status() !== 'processing') {
            self::log("Order #{$order_id}: status is '{$order->get_status()}', not 'processing'. Skipping.", "INFO");
            return;
        }

        self::complete_order_with_correct_date($order, 'scheduled event');
    }

    /**
     * FALLBACK: Look for processing orders and complete them if old enough.
     * This runs on the periodic cron schedule as a safety net.
     */
    public static function process_orders() {
        // Check if plugin is active in settings
        if (get_option('tw_order_status_active', 'no') !== 'yes') {
            return;
        }

        self::log("Starting fallback sweep...", "INFO");

        // Set threshold
        $threshold_minutes = (int) apply_filters('tw_wc_order_status_threshold', self::DEFAULT_DELAY_MINUTES);
        $threshold_time = time() - ($threshold_minutes * 60);

        // Query processing orders older than the threshold
        $args = [
            'status' => 'processing',
            'date_created' => '<' . date('Y-m-d H:i:s', $threshold_time),
            'limit' => 50, // Batch limit to be safe
            'orderby' => 'date',
            'order' => 'ASC',
        ];

        $orders = wc_get_orders($args);

        if (empty($orders)) {
            self::log("Fallback sweep: no orders found matching criteria.", "INFO");
            return;
        }

        $count = 0;
        foreach ($orders as $order) {
            $order_id = $order->get_id();
            
            // Double check order status just in case
            if ($order->get_status() !== 'processing') {
                continue;
            }

            self::complete_order_with_correct_date($order, 'fallback sweep');
            $count++;
        }

        self::log("Fallback sweep finished. Total orders updated: {$count}", "INFO");
    }

    /**
     * Complete an order and fix date_completed to date_created + delay.
     *
     * WooCommerce's update_status('completed') sets date_completed to NOW,
     * which inflates today's revenue for old orders. This method overrides
     * date_completed to date_created + configured delay so analytics revenue
     * is attributed to the correct day.
     *
     * @param WC_Order $order  The order to complete.
     * @param string   $source Label for logging (e.g. 'scheduled event', 'fallback sweep').
     */
    private static function complete_order_with_correct_date($order, $source = '') {
        $order_id = $order->get_id();
        $delay_minutes = (int) apply_filters('tw_wc_order_status_threshold', self::DEFAULT_DELAY_MINUTES);

        // 1. Change status to completed (this sets date_completed = NOW)
        $order->update_status('completed', __('Automatically completed by TW Order Status plugin after delay.', 'tw-woocommerce-order-status'));

        // 2. Override date_completed to date_created + delay
        $date_created = $order->get_date_created();
        if ($date_created) {
            $correct_completed = clone $date_created;
            $correct_completed->modify("+{$delay_minutes} minutes");

            $order->set_date_completed($correct_completed->getTimestamp());
            $order->save();

            // 3. Also fix the operational data & analytics tables directly
            global $wpdb;
            $timestamp = $correct_completed->getTimestamp();
            $correct_gmt   = gmdate('Y-m-d H:i:s', $timestamp);   // UTC for _gmt columns
            $correct_local = wp_date('Y-m-d H:i:s', $timestamp);  // Site timezone for analytics

            $wpdb->update(
                $wpdb->prefix . 'wc_order_operational_data',
                ['date_completed_gmt' => $correct_gmt],
                ['order_id' => $order_id],
                ['%s'],
                ['%d']
            );

            $wpdb->update(
                $wpdb->prefix . 'wc_order_stats',
                ['date_completed' => $correct_local],
                ['order_id' => $order_id],
                ['%s'],
                ['%d']
            );

            self::log("Order #{$order_id} → completed with date_completed={$correct_gmt} UTC (date_created + {$delay_minutes}min) [{$source}].", "SUCCESS");
        } else {
            self::log("Order #{$order_id} → completed but could not fix date (no date_created) [{$source}].", "WARNING");
        }
    }

    /**
     * Logging helper with automatic log rotation.
     * Rotates at 1MB to prevent unbounded growth.
     */
    public static function log(string $message, string $level = 'INFO'): void {
        if (get_option('tw_order_status_enable_logs', 'no') !== 'yes') {
            return;
        }

        if (!is_dir(self::$log_folder)) {
            if (!wp_mkdir_p(self::$log_folder)) {
                return; // Cannot create log directory
            }
            // Protect logs directory from direct web access
            self::protect_log_directory();
        }

        $log_file = self::$log_folder . 'process.log';

        // Log rotation: if file exceeds 1MB, rotate it
        if (file_exists($log_file) && filesize($log_file) > 1048576) {
            $backup = self::$log_folder . 'process.log.bak';
            if (file_exists($backup)) {
                unlink($backup);
            }
            rename($log_file, $backup);
        }

        $time = wp_date('Y-m-d H:i:s');
        $entry = sprintf("[%s] [%s] %s\n", $time, strtoupper($level), $message);

        file_put_contents($log_file, $entry, FILE_APPEND | LOCK_EX);
    }

    /**
     * Create protective files in the logs directory to prevent direct web access.
     */
    private static function protect_log_directory(): void {
        // .htaccess for Apache/LiteSpeed
        $htaccess = self::$log_folder . '.htaccess';
        if (!file_exists($htaccess)) {
            file_put_contents($htaccess, "Deny from all\n");
        }

        // index.php as fallback
        $index = self::$log_folder . 'index.php';
        if (!file_exists($index)) {
            file_put_contents($index, "<?php // Silence is golden.\n");
        }
    }

    /**
     * Read logs for display on settings page
     */
    public static function get_recent_logs($limit = 50) {
        $log_file = self::$log_folder . 'process.log';
        if (!file_exists($log_file)) {
            return [];
        }

        $lines = file($log_file);
        if (!$lines) return [];

        $lines = array_reverse($lines);
        return array_slice($lines, 0, $limit);
    }
}
