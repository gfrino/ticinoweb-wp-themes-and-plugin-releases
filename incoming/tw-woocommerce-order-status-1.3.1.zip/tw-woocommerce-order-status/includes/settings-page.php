<?php
/**
 * Settings page for TW WooCommerce Order Status.
 */

if (!defined('ABSPATH')) {
    exit;
}

class TW_WC_Order_Status_Settings {

    public static function init() {
        add_action('admin_menu', [__CLASS__, 'register_menu']);
        add_action('admin_init', [__CLASS__, 'register_settings']);
        add_action('admin_enqueue_scripts', [__CLASS__, 'enqueue_assets']);
    }

    public static function register_menu() {
        add_submenu_page(
            'woocommerce',
            __('Order Auto-Switcher', 'tw-woocommerce-order-status'),
            __('Order Auto-Switcher', 'tw-woocommerce-order-status'),
            'manage_options',
            'tw-order-auto-switcher',
            [__CLASS__, 'render_page']
        );
    }

    public static function register_settings() {
        register_setting('tw_wc_order_status_group', 'tw_order_status_active');
        register_setting('tw_wc_order_status_group', 'tw_order_status_enable_logs');
    }

    public static function enqueue_assets($hook) {
        if ($hook !== 'woocommerce_page_tw-order-auto-switcher') {
            return;
        }
        wp_enqueue_style('tw-wc-order-status-admin', TW_WC_ORDER_STATUS_URL . 'assets/css/admin-style.css', [], TW_WC_ORDER_STATUS_VERSION);
    }

    public static function render_page() {
        if (!current_user_can('manage_options')) {
            return;
        }

        $active = get_option('tw_order_status_active', 'no');
        $logging = get_option('tw_order_status_enable_logs', 'no');
        $logs = TW_WC_Order_Status_Handler::get_recent_logs(20);

        ?>
        <div class="tw-os-wrap">
            <div class="tw-os-header">
                <h1>TW WooCommerce Order Status</h1>
                <p><?php _e('Lightweight automation to switch order status from processing to completed.', 'tw-woocommerce-order-status'); ?></p>
            </div>

            <div class="tw-os-body">
                <form method="post" action="options.php">
                    <?php settings_fields('tw_wc_order_status_group'); ?>
                    
                    <div class="tw-os-card">
                        <div class="tw-os-section-title">
                            <span>🚀</span> <?php _e('Automation Control', 'tw-woocommerce-order-status'); ?>
                        </div>
                        <div class="tw-os-switch-container">
                            <div>
                                <strong><?php _e('Active Status', 'tw-woocommerce-order-status'); ?></strong>
                                <p class="description"><?php _e('Enable or disable the automatic order completion process.', 'tw-woocommerce-order-status'); ?></p>
                            </div>
                            <label class="tw-os-switch">
                                <input type="checkbox" name="tw_order_status_active" value="yes" <?php checked($active, 'yes'); ?>>
                                <span class="tw-os-slider"></span>
                            </label>
                        </div>
                    </div>

                    <div class="tw-os-card">
                        <div class="tw-os-section-title">
                            <span>📄</span> <?php _e('Logging & Debugging', 'tw-woocommerce-order-status'); ?>
                        </div>
                        <div class="tw-os-switch-container">
                            <div>
                                <strong><?php _e('Enable Logs', 'tw-woocommerce-order-status'); ?></strong>
                                <p class="description"><?php _e('Keep track of every status change in a local log file.', 'tw-woocommerce-order-status'); ?></p>
                            </div>
                            <label class="tw-os-switch">
                                <input type="checkbox" name="tw_order_status_enable_logs" value="yes" <?php checked($logging, 'yes'); ?>>
                                <span class="tw-os-slider"></span>
                            </label>
                        </div>
                    </div>

                    <div class="tw-os-card">
                        <div class="tw-os-section-title">
                            <span>ℹ️</span> <?php _e('How it works', 'tw-woocommerce-order-status'); ?>
                        </div>
                        <p><?php _e('When an order enters <strong>Processing</strong> status, this plugin schedules an automatic completion after <strong>30 minutes</strong>. Each order gets its own timer — no waiting for a batch job.', 'tw-woocommerce-order-status'); ?></p>
                        <p><?php _e('A fallback sweep also runs every 15 minutes to catch any orders that may have been missed.', 'tw-woocommerce-order-status'); ?></p>
                        <p><?php _e('This is ideal for stores where orders are fulfilled immediately or digital products that don\'t require manual intervention.', 'tw-woocommerce-order-status'); ?></p>
                    </div>

                    <?php if ($logging === 'yes') : ?>
                        <div class="tw-os-card">
                            <div class="tw-os-section-title">
                                <span>📜</span> <?php _e('Recent Activity', 'tw-woocommerce-order-status'); ?>
                            </div>
                            <div class="tw-os-log-container">
                                <?php if (empty($logs)) : ?>
                                    <div class="tw-os-log-entry"><?php _e('No log entries found yet.', 'tw-woocommerce-order-status'); ?></div>
                                <?php else : ?>
                                    <?php foreach ($logs as $line) : 
                                        preg_match('/\[(.*?)\] \[(.*?)\] (.*)/', $line, $matches);
                                        if (count($matches) === 4) :
                                            $time = $matches[1];
                                            $level = strtolower($matches[2]);
                                            $msg = $matches[3];
                                    ?>
                                        <div class="tw-os-log-entry">
                                            <span class="tw-os-log-time"><?php echo esc_html($time); ?></span>
                                            <span class="tw-os-log-level <?php echo esc_attr($level); ?>">[<?php echo esc_html(strtoupper($level)); ?>]</span>
                                            <span class="tw-os-log-msg"><?php echo esc_html($msg); ?></span>
                                        </div>
                                    <?php else: ?>
                                        <div class="tw-os-log-entry"><?php echo esc_html($line); ?></div>
                                    <?php endif; endforeach; ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endif; ?>

                    <div style="text-align: right;">
                        <?php submit_button(__('Save Settings', 'tw-woocommerce-order-status'), 'primary', 'submit', false, ['class' => 'tw-os-save-btn']); ?>
                    </div>
                </form>
            </div>

            <div class="tw-os-footer">
                &copy; <?php echo wp_date('Y'); ?> ticinoWEB. <?php _e('Crafted with care.', 'tw-woocommerce-order-status'); ?>
            </div>
        </div>
        <?php
    }
}
