<?php
/**
 * Plugin Name: TW WooCommerce Order Status
 * Plugin URI: https://ticinoweb.com/
 * Description: Completa da solo gli ordini WooCommerce che restano "In lavorazione": dopo 30 minuti passano a "Completato", senza che tu debba farlo a mano. Ideale per prodotti digitali o ordini evasi subito.
 * Version: 1.3.1
 * Author: ticinoWEB
 * Author URI: https://ticinoweb.com/
 * Text Domain: tw-woocommerce-order-status
 * Requires at least: 5.8
 * Requires PHP: 8.0
 * WC requires at least: 7.0
 * Update URI: https://github.com/gfrino/ticinoweb-wp-themes-and-plugin-releases
 */

if (!defined('ABSPATH')) {
    exit;
}

// Define constants
define('TW_WC_ORDER_STATUS_VERSION', '1.3.1');
define('TW_WC_ORDER_STATUS_PATH', plugin_dir_path(__FILE__));
define('TW_WC_ORDER_STATUS_URL', plugin_dir_url(__FILE__));
// Version of the bundled includes/tw-release-updater.php (keep in sync with its header).
define('TW_WC_ORDER_STATUS_RELEASE_UPDATER_VERSION', '1.2.0');

// Standard ticinoWEB release updater (see the Update URI header).
require_once TW_WC_ORDER_STATUS_PATH . 'includes/tw-release-updater.php';

// Include necessary files
require_once TW_WC_ORDER_STATUS_PATH . 'includes/auto-complete-handler.php';
require_once TW_WC_ORDER_STATUS_PATH . 'includes/settings-page.php';

// Register Cron schedule
add_filter('cron_schedules', 'tw_wc_order_status_cron_schedules');
function tw_wc_order_status_cron_schedules($schedules) {
    if (!isset($schedules['fifteen_minutes'])) {
        $schedules['fifteen_minutes'] = array(
            'interval' => 15 * 60,
            'display'  => __('Every 15 Minutes', 'tw-woocommerce-order-status'),
        );
    }
    return $schedules;
}

// Activation Hook
register_activation_hook(__FILE__, 'tw_wc_order_status_activate');
function tw_wc_order_status_activate() {
    if (!wp_next_scheduled('tw_wc_order_status_cron_event')) {
        wp_schedule_event(time(), 'fifteen_minutes', 'tw_wc_order_status_cron_event');
    }
}

// Deactivation Hook
register_deactivation_hook(__FILE__, 'tw_wc_order_status_deactivate');
function tw_wc_order_status_deactivate() {
    $timestamp = wp_next_scheduled('tw_wc_order_status_cron_event');
    if ($timestamp) {
        wp_unschedule_event($timestamp, 'tw_wc_order_status_cron_event');
    }
}

// Initialize the plugin
add_action('plugins_loaded', 'tw_wc_order_status_init');
function tw_wc_order_status_init() {
    if (class_exists('WooCommerce')) {
        // Initialize handler
        TW_WC_Order_Status_Handler::init();
        // Initialize settings
        TW_WC_Order_Status_Settings::init();
    }
}

// Add settings link on plugins page
add_filter('plugin_action_links_' . plugin_basename(__FILE__), 'tw_wc_order_status_action_links');
function tw_wc_order_status_action_links($links) {
    $settings_link = '<a href="admin.php?page=tw-order-auto-switcher">' . __('Settings', 'tw-woocommerce-order-status') . '</a>';
    array_unshift($links, $settings_link);
    return $links;
}

/**
 * Install or upgrade the release updater mu-plugin from the bundled copy.
 * A failure (mu-plugins not writable) is retried at most every 12 hours;
 * meanwhile the bundled copy still handles updates.
 */
function tw_wc_order_status_install_release_updater() {
    if (!class_exists('TW_Release_Updater') || TW_Release_Updater::mu_is_current(TW_WC_ORDER_STATUS_RELEASE_UPDATER_VERSION)) {
        return;
    }
    if (get_site_transient('tw_wc_order_status_release_updater_failed')) {
        return;
    }
    $result = TW_Release_Updater::install_mu(TW_WC_ORDER_STATUS_PATH . 'includes/tw-release-updater.php');
    if (is_wp_error($result)) {
        set_site_transient('tw_wc_order_status_release_updater_failed', $result->get_error_message(), 12 * HOUR_IN_SECONDS);
    }
}

add_action('admin_init', function () {
    if (current_user_can(is_multisite() ? 'manage_network_plugins' : 'activate_plugins')) {
        tw_wc_order_status_install_release_updater();
    }
}, 20);
