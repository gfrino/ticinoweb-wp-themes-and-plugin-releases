<?php
/**
 * Home template for Deltora Consulting (V2).
 *
 * @package DeltoraConsultingChildTheme
 */

$deltora_services_url     = deltora_consulting_get_page_url( 'servizi' );
$deltora_configurator_url = deltora_consulting_get_page_url( 'configuratore' );
$deltora_services         = deltora_consulting_get_services();
$deltora_contact          = deltora_consulting_get_contact_details();
$deltora_map_query        = rawurlencode( $deltora_contact['address'] );
$deltora_phone_uri        = preg_replace( '/[^0-9+]/', '', $deltora_contact['phone'] );

get_header();
?>

<?php
$deltora_hero_bg = get_option( 'ticinoweb_page_header_bg_image' );
if ( empty( $deltora_hero_bg ) ) {
	$deltora_hero_bg = get_stylesheet_directory_uri() . '/assets/images/deltora-hero-terrace.jpg';
}

$deltora_hero_alt           = __( 'Architettura contemporanea affacciata sul Lago di Lugano', 'deltora-consulting-child-theme' );
$deltora_hero_attachment_id = deltora_consulting_get_attachment_id_from_url( $deltora_hero_bg );

if ( $deltora_hero_attachment_id ) {
	$deltora_media_alt = trim( (string) get_post_meta( $deltora_hero_attachment_id, '_wp_attachment_image_alt', true ) );

	if ( '' !== $deltora_media_alt ) {
		$deltora_hero_alt = $deltora_media_alt;
	}
}
?>
<main id="main-content" class="site-main deltora-home">
	<!-- 1. HERO — VALORE D'IMPRESA -->
	<section class="deltora-home-hero deltora-home-hero--immersive" aria-labelledby="deltora-home-title">
		<figure class="deltora-home-hero__media" data-motion="hero-media" data-motion-delay="80">
			<?php if ( $deltora_hero_attachment_id ) : ?>
				<?php
				echo wp_get_attachment_image(
					$deltora_hero_attachment_id,
					'full',
					false,
					array(
						'class'         => 'deltora-home-hero__image',
						'alt'           => $deltora_hero_alt,
						'decoding'      => 'async',
						'fetchpriority' => 'high',
						'loading'       => 'eager',
						'sizes'         => '100vw',
					)
				); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Core generates escaped attachment markup.
				?>
			<?php else : ?>
				<img
					class="deltora-home-hero__image"
					src="<?php echo esc_url( $deltora_hero_bg ); ?>"
					alt="<?php echo esc_attr( $deltora_hero_alt ); ?>"
					width="1672"
					height="941"
					fetchpriority="high"
					loading="eager"
					decoding="async"
				>
			<?php endif; ?>
			<figcaption class="screen-reader-text"><?php esc_html_e( 'Precisione svizzera. Visione imprenditoriale.', 'deltora-consulting-child-theme' ); ?></figcaption>
		</figure>

		<div class="deltora-container deltora-home-hero__container">
			<div class="deltora-home-hero__content" data-motion="hero-copy">
				<h1 id="deltora-home-title" class="deltora-home-hero__title">
					<span class="deltora-home-hero__title-main"><?php esc_html_e( 'Dietro ogni numero', 'deltora-consulting-child-theme' ); ?></span>
					<span class="deltora-home-hero__title-accent"><?php esc_html_e( 'ci sono scelte importanti', 'deltora-consulting-child-theme' ); ?></span>
				</h1>

				<p class="deltora-home-hero__lead">
					<span class="deltora-home-hero__lead-primary"><?php esc_html_e( 'Deltora affianca aziende e imprenditori nello sviluppo delle loro attività, offrendo una consulenza integrata in ambito strategico-gestionale, fiscale, contabile e societario.', 'deltora-consulting-child-theme' ); ?></span>
					<span class="deltora-home-hero__lead-secondary"><?php esc_html_e( 'Per una prima indicazione del valore operativo, parti dall’EBITDA degli ultimi tre esercizi.', 'deltora-consulting-child-theme' ); ?></span>
				</p>

				<div class="deltora-actions deltora-actions--hero">
					<a class="deltora-button deltora-button--hero-primary" href="<?php echo esc_url( $deltora_configurator_url ); ?>">
						<span><?php esc_html_e( 'Calcola il valore', 'deltora-consulting-child-theme' ); ?></span>
					</a>
					<a class="deltora-button deltora-button--hero-secondary" href="<?php echo esc_url( $deltora_services_url ); ?>">
						<span><?php esc_html_e( 'Scopri DELTORA', 'deltora-consulting-child-theme' ); ?></span>
					</a>
				</div>
			</div>
		</div>
	</section>

	<!-- 2. POSIZIONAMENTO (RESPIRO & VISIONE) -->
	<section class="deltora-home-position" id="introduzione" aria-labelledby="deltora-position-title">
		<div class="deltora-container">
			<div class="deltora-home-position__grid">
				<div class="deltora-home-position__header" data-motion="section-heading">
					<div class="deltora-meta-label">
						<span class="deltora-meta-label__bullet" aria-hidden="true"></span>
						<span><?php esc_html_e( 'Visione & Ruolo', 'deltora-consulting-child-theme' ); ?></span>
					</div>
					<h2 id="deltora-position-title"><?php esc_html_e( 'Dalla gestione quotidiana a una visione d’insieme', 'deltora-consulting-child-theme' ); ?></h2>
				</div>

				<div class="deltora-home-position__copy" data-motion="section-copy" data-motion-delay="70">
					<p class="deltora-lead-quote">
						<?php esc_html_e( 'Gli aspetti fiscali, contabili, societari e contrattuali vengono letti insieme, evitando che questioni collegate siano trattate come temi separati.', 'deltora-consulting-child-theme' ); ?>
					</p>
					<p>
						<?php esc_html_e( 'Il perimetro dell’incarico viene definito a partire dalle priorità operative e dalle responsabilità coinvolte.', 'deltora-consulting-child-theme' ); ?>
					</p>
				</div>
			</div>
		</div>
	</section>

	<!-- 3. SERVIZI (CONTENUTO & PRESENZA EDITORIALE) -->
	<section class="deltora-home-services" id="servizi" aria-labelledby="deltora-servizi-title">
		<div class="deltora-container">
			<div class="deltora-home-section-heading" data-motion="section-heading">
				<h2 id="deltora-servizi-title" class="deltora-section-display__title"><?php esc_html_e( 'Aree di competenza', 'deltora-consulting-child-theme' ); ?></h2>
				<p class="deltora-section-display__accent"><?php esc_html_e( 'Trova l’area da approfondire', 'deltora-consulting-child-theme' ); ?></p>
				<p class="deltora-section-display__intro"><?php esc_html_e( 'Le aree sono organizzate per aiutarti a individuare rapidamente il punto di partenza più pertinente.', 'deltora-consulting-child-theme' ); ?></p>
			</div>

			<ol class="deltora-service-route">
				<?php foreach ( $deltora_services as $deltora_service_index => $deltora_service ) : ?>
					<?php $deltora_motion_delay = min( 150, $deltora_service_index * 50 ); ?>
					<li class="deltora-service-route__item" data-motion="list-item"<?php echo $deltora_motion_delay ? ' data-motion-delay="' . esc_attr( $deltora_motion_delay ) . '"' : ''; ?>>
						<div class="deltora-service-route__indicator">
							<?php if ( 'svg' === $deltora_service['icon_type'] && $deltora_service['icon_svg'] ) : ?>
								<span class="deltora-service-route__icon" aria-hidden="true"><img src="<?php echo esc_url( $deltora_service['icon_svg'] ); ?>" alt="" width="64" height="64"></span>
							<?php elseif ( 'dashicon' === $deltora_service['icon_type'] && $deltora_service['icon'] ) : ?>
								<span class="deltora-service-route__icon dashicons <?php echo esc_attr( $deltora_service['icon'] ); ?>" aria-hidden="true"></span>
							<?php else : ?>
								<span class="deltora-service-route__icon deltora-service-icon deltora-service-icon--<?php echo esc_attr( $deltora_service['slug'] ); ?>" aria-hidden="true"></span>
							<?php endif; ?>
						</div>
						<div class="deltora-service-route__body">
							<div class="deltora-service-route__title-wrap">
								<?php if ( $deltora_service['category'] ) : ?>
									<span class="deltora-service-route__category"><?php echo esc_html( $deltora_service['category'] ); ?></span>
								<?php endif; ?>
								<h3><?php echo esc_html( $deltora_service['title'] ); ?></h3>
							</div>
							<p><?php echo esc_html( $deltora_service['summary'] ); ?></p>
							<a class="deltora-service-route__link" href="<?php echo esc_url( $deltora_services_url . '#servizio-' . $deltora_service['slug'] ); ?>">
								<span><?php esc_html_e( 'Approfondisci', 'deltora-consulting-child-theme' ); ?></span>
								<span class="deltora-arrow deltora-direction-icon deltora-direction-icon--right" aria-hidden="true"></span>
							</a>
						</div>
					</li>
				<?php endforeach; ?>
			</ol>
		</div>
	</section>

	<!-- 4. CONFIGURATORE — ACCESSO REALE ALLA STIMA EBITDA -->
	<section class="deltora-home-configurator" id="configuratore" aria-labelledby="deltora-configuratore-title">
		<div class="deltora-container">
			<div class="deltora-home-configurator__grid">
				<div class="deltora-home-configurator__content" data-motion="section-copy">
					<div class="deltora-meta-label deltora-meta-label--light">
						<span class="deltora-meta-label__bullet" aria-hidden="true"></span>
						<span><?php esc_html_e( 'Stima del valore aziendale', 'deltora-consulting-child-theme' ); ?></span>
					</div>

					<h2 id="deltora-configuratore-title"><?php esc_html_e( 'Una prima stima, costruita sui tuoi numeri', 'deltora-consulting-child-theme' ); ?></h2>

					<p class="deltora-home-configurator__desc">
						<?php esc_html_e( 'Il percorso utilizza gli EBITDA degli ultimi tre esercizi per calcolare un intervallo indicativo del valore operativo della tua azienda.', 'deltora-consulting-child-theme' ); ?>
					</p>

					<div class="deltora-configurator-features">
						<div class="deltora-config-feature">
							<span class="deltora-config-feature__num">01</span>
							<span><?php esc_html_e( 'Due modalità: calcolo guidato o inserimento diretto', 'deltora-consulting-child-theme' ); ?></span>
						</div>
						<div class="deltora-config-feature">
							<span class="deltora-config-feature__num">02</span>
							<span><?php esc_html_e( 'Intervallo basato sul settore selezionato', 'deltora-consulting-child-theme' ); ?></span>
						</div>
						<div class="deltora-config-feature">
							<span class="deltora-config-feature__num">03</span>
							<span><?php esc_html_e( 'Riepilogo consultabile e inviabile via email', 'deltora-consulting-child-theme' ); ?></span>
						</div>
					</div>

					<p class="deltora-home-configurator__notice">
						<?php esc_html_e( 'La stima è orientativa e non sostituisce una valutazione professionale dell’azienda.', 'deltora-consulting-child-theme' ); ?>
					</p>
				</div>

				<div class="deltora-home-configurator__demo-wrap" data-motion="section-media" data-motion-delay="100">
					<form class="deltora-config-entry" action="<?php echo esc_url( $deltora_configurator_url . '#deltora-configurator-start' ); ?>" method="get" data-configurator-entry>
						<div class="deltora-config-entry__header">
							<strong><?php esc_html_e( 'Inizia la stima', 'deltora-consulting-child-theme' ); ?></strong>
							<span><?php esc_html_e( 'Una scelta, poi continui nella pagina dedicata', 'deltora-consulting-child-theme' ); ?></span>
						</div>

						<fieldset class="deltora-config-entry__body">
							<legend><?php esc_html_e( 'Conosci già l’EBITDA degli ultimi tre esercizi?', 'deltora-consulting-child-theme' ); ?></legend>
							<p><?php esc_html_e( 'Scegli il punto di partenza più adatto. Potrai cambiare modalità nella pagina successiva.', 'deltora-consulting-child-theme' ); ?></p>

							<div class="deltora-config-entry__options">
								<label class="deltora-config-entry__option">
									<input type="radio" name="mode" value="guided">
									<span>
										<strong><?php esc_html_e( 'No, aiutami a calcolarlo', 'deltora-consulting-child-theme' ); ?></strong>
										<small><?php esc_html_e( 'Ho i bilanci o i dati contabili, ma non i tre EBITDA.', 'deltora-consulting-child-theme' ); ?></small>
									</span>
								</label>

								<label class="deltora-config-entry__option">
									<input type="radio" name="mode" value="direct">
									<span>
										<strong><?php esc_html_e( 'Sì, inserisco i tre valori', 'deltora-consulting-child-theme' ); ?></strong>
										<small><?php esc_html_e( 'Conosco già l’EBITDA di tre esercizi completi.', 'deltora-consulting-child-theme' ); ?></small>
									</span>
								</label>
							</div>

							<button class="deltora-button deltora-button--primary deltora-button--large" type="submit" data-configurator-entry-submit disabled>
								<?php esc_html_e( 'Continua con la stima', 'deltora-consulting-child-theme' ); ?>
							</button>
							<p class="deltora-config-entry__privacy"><?php esc_html_e( 'In questa schermata non inserisci dati finanziari o personali.', 'deltora-consulting-child-theme' ); ?></p>
						</fieldset>
					</form>
				</div>
			</div>
		</div>
	</section>

	<!-- 5. METODO / APPROCCIO (RESPIRO & CREDIBILITÀ) -->
	<section class="deltora-home-approach" id="fiducia" aria-labelledby="deltora-approach-title">
		<div class="deltora-container">
			<div class="deltora-home-section-heading" data-motion="section-heading">
				<h2 id="deltora-approach-title" class="deltora-section-display__title"><?php esc_html_e( 'Metodo operativo', 'deltora-consulting-child-theme' ); ?></h2>
				<p class="deltora-section-display__accent"><?php esc_html_e( 'Dall’ascolto alle decisioni', 'deltora-consulting-child-theme' ); ?></p>
				<p class="deltora-section-display__intro"><?php esc_html_e( 'Il lavoro procede in quattro fasi, dalla comprensione iniziale alla definizione delle azioni da intraprendere.', 'deltora-consulting-child-theme' ); ?></p>
			</div>

			<div class="deltora-approach-grid">
				<div class="deltora-approach-card" data-motion="list-item">
					<div class="deltora-approach-card__header">
						<span class="deltora-approach-card__num">01</span>
						<span class="deltora-approach-card__phase"><?php esc_html_e( 'Fase iniziale', 'deltora-consulting-child-theme' ); ?></span>
					</div>
					<h3><?php esc_html_e( 'Ascolto', 'deltora-consulting-child-theme' ); ?></h3>
					<p><?php esc_html_e( 'Comprendere a fondo la realtà aziendale, gli obiettivi da raggiungere, i vincoli operativi e le priorità strategiche.', 'deltora-consulting-child-theme' ); ?></p>
				</div>

				<div class="deltora-approach-card" data-motion="list-item" data-motion-delay="50">
					<div class="deltora-approach-card__header">
						<span class="deltora-approach-card__num">02</span>
						<span class="deltora-approach-card__phase"><?php esc_html_e( 'Analisi', 'deltora-consulting-child-theme' ); ?></span>
					</div>
					<h3><?php esc_html_e( 'Visione integrata', 'deltora-consulting-child-theme' ); ?></h3>
					<p><?php esc_html_e( 'Collegare i profili fiscali, contabili, societari e contrattuali in un quadro coerente senza compartimenti stagni.', 'deltora-consulting-child-theme' ); ?></p>
				</div>

				<div class="deltora-approach-card" data-motion="list-item" data-motion-delay="100">
					<div class="deltora-approach-card__header">
						<span class="deltora-approach-card__num">03</span>
						<span class="deltora-approach-card__phase"><?php esc_html_e( 'Metodo', 'deltora-consulting-child-theme' ); ?></span>
					</div>
					<h3><?php esc_html_e( 'Precisione', 'deltora-consulting-child-theme' ); ?></h3>
					<p><?php esc_html_e( 'Garantire rigore e ordine formale alle informazioni, ai numeri e ad ogni singolo adempimento amministrativo.', 'deltora-consulting-child-theme' ); ?></p>
				</div>

				<div class="deltora-approach-card" data-motion="list-item" data-motion-delay="150">
					<div class="deltora-approach-card__header">
						<span class="deltora-approach-card__num">04</span>
						<span class="deltora-approach-card__phase"><?php esc_html_e( 'Esecuzione', 'deltora-consulting-child-theme' ); ?></span>
					</div>
					<h3><?php esc_html_e( 'Concretezza', 'deltora-consulting-child-theme' ); ?></h3>
					<p><?php esc_html_e( 'Tradurre la consulenza in passi chiari, decisioni misurabili e soluzioni praticabili per l’imprenditore e il management.', 'deltora-consulting-child-theme' ); ?></p>
				</div>
			</div>
		</div>
	</section>

	<!-- 6. CONTATTI & SEDE -->
	<section class="deltora-home-contact" id="contatti" aria-labelledby="deltora-contatti-title">
		<div class="deltora-container">
			<div class="deltora-home-section-heading" data-motion="section-heading">
				<h2 id="deltora-contatti-title" class="deltora-section-display__title"><?php esc_html_e( 'Sede & contatto diretto', 'deltora-consulting-child-theme' ); ?></h2>
				<p class="deltora-section-display__accent"><?php esc_html_e( 'Scegli il canale più adatto', 'deltora-consulting-child-theme' ); ?></p>
				<p class="deltora-section-display__intro"><?php esc_html_e( 'Puoi contattare Deltora direttamente oppure inviare una richiesta strutturata attraverso il modulo dedicato.', 'deltora-consulting-child-theme' ); ?></p>
			</div>

			<div class="deltora-home-contact__grid">
				<div class="deltora-contact-details" data-motion="section-copy">
					<address class="deltora-contact-item">
						<span class="deltora-contact-item__label"><?php esc_html_e( 'Sede principale', 'deltora-consulting-child-theme' ); ?></span>
						<strong class="deltora-contact-item__value"><?php echo esc_html( $deltora_contact['address'] ); ?></strong>
					</address>

					<div class="deltora-contact-item">
						<span class="deltora-contact-item__label"><?php esc_html_e( 'Telefono', 'deltora-consulting-child-theme' ); ?></span>
						<a class="deltora-contact-item__link" href="tel:<?php echo esc_attr( $deltora_phone_uri ); ?>">
							<?php echo esc_html( $deltora_contact['phone'] ); ?>
						</a>
					</div>

					<div class="deltora-contact-item">
						<span class="deltora-contact-item__label"><?php esc_html_e( 'Email', 'deltora-consulting-child-theme' ); ?></span>
						<a class="deltora-contact-item__link" href="mailto:<?php echo esc_attr( antispambot( $deltora_contact['email'] ) ); ?>">
							<?php echo esc_html( antispambot( $deltora_contact['email'] ) ); ?>
						</a>
					</div>

					<div class="deltora-contact-actions">
						<a class="deltora-button" href="<?php echo esc_url( deltora_consulting_get_page_url( 'contatti' ) ); ?>">
							<span><?php esc_html_e( 'Invia una richiesta', 'deltora-consulting-child-theme' ); ?></span>
							<span class="deltora-button__mail-icon deltora-contact-icon deltora-contact-icon--email" aria-hidden="true"></span>
						</a>
					</div>
				</div>

				<div
					class="deltora-map"
					data-motion="section-media"
					data-motion-delay="90"
					data-consent-map
					data-map-src="https://www.google.com/maps?q=<?php echo esc_attr( $deltora_map_query ); ?>&amp;output=embed"
					data-map-title="<?php esc_attr_e( 'Mappa della sede Deltora Consulting a Lugano in Via Ferruccio Pelli 2', 'deltora-consulting-child-theme' ); ?>"
				>
					<div class="deltora-map__placeholder" data-map-placeholder>
						<div>
							<h3><?php esc_html_e( 'Mappa Google non ancora caricata', 'deltora-consulting-child-theme' ); ?></h3>
							<p><?php esc_html_e( 'Per visualizzare la mappa interattiva autorizza i contenuti esterni nelle preferenze cookie.', 'deltora-consulting-child-theme' ); ?></p>
						</div>
						<div class="deltora-map__actions">
							<button type="button" class="deltora-button" data-cookie-preferences-open>
								<?php esc_html_e( 'Gestisci preferenze', 'deltora-consulting-child-theme' ); ?>
							</button>
							<a class="deltora-text-link" href="https://www.google.com/maps/search/?api=1&amp;query=<?php echo esc_attr( $deltora_map_query ); ?>" target="_blank" rel="external noopener noreferrer">
								<?php esc_html_e( 'Apri in Google Maps', 'deltora-consulting-child-theme' ); ?>
							</a>
						</div>
					</div>
					<noscript>
						<p class="deltora-map__noscript">
							<a href="https://www.google.com/maps/search/?api=1&amp;query=<?php echo esc_attr( $deltora_map_query ); ?>" target="_blank" rel="external noopener noreferrer">
								<?php esc_html_e( 'Apri la sede in Google Maps', 'deltora-consulting-child-theme' ); ?>
							</a>
						</p>
					</noscript>
				</div>
			</div>
		</div>
	</section>
</main>

<?php
get_footer();
