<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<a class="skip-link screen-reader-text" href="#main-content">
	<?php esc_html_e( 'Vai al contenuto', 'deltora-consulting-child-theme' ); ?>
</a>

<header class="site-header site-header--premium<?php echo is_page( 'contatti' ) ? ' site-header--contact' : ''; ?><?php echo is_page( 'chi-siamo' ) ? ' site-header--about' : ''; ?><?php echo is_privacy_policy() ? ' site-header--privacy' : ''; ?>" data-site-header>
	<div class="deltora-container site-header__inner">
		<div class="site-branding">
			<a class="site-branding__link" href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
				<?php
				$deltora_logo = function_exists( 'ticinoweb_get_site_logo' ) ? ticinoweb_get_site_logo() : false;
				if ( empty( $deltora_logo ) ) {
					$deltora_logo = get_stylesheet_directory_uri() . '/assets/images/logo.png?v=1.3.3';
				}

				if ( $deltora_logo ) :
					$deltora_header_logo = get_stylesheet_directory_uri() . '/assets/images/logo-header.png?v=1.0.0';
					?>
					<img
						class="site-logo site-logo--header"
						src="<?php echo esc_url( $deltora_header_logo ); ?>"
						alt="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>"
						width="1600"
						height="589"
					>
				<?php else : ?>
					<span class="site-title"><?php bloginfo( 'name' ); ?></span>
				<?php endif; ?>
			</a>
		</div>

		<button
			class="menu-toggle"
			type="button"
			aria-expanded="false"
			aria-controls="deltora-primary-navigation"
		>
			<span class="menu-toggle__label"><?php esc_html_e( 'Menu', 'deltora-consulting-child-theme' ); ?></span>
			<span class="menu-toggle__icon" aria-hidden="true">
				<span></span>
				<span></span>
				<span></span>
			</span>
		</button>

		<nav
			id="deltora-primary-navigation"
			class="main-navigation"
			aria-label="<?php esc_attr_e( 'Navigazione principale', 'deltora-consulting-child-theme' ); ?>"
			data-open="false"
		>
			<?php if ( has_nav_menu( 'primary' ) ) : ?>
				<?php
				wp_nav_menu(
					array(
						'theme_location' => 'primary',
						'menu_class'     => 'primary-menu',
						'container'      => false,
						'depth'          => 1,
					)
				);
				?>
			<?php else : ?>
				<ul class="primary-menu">
					<li><a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Home', 'deltora-consulting-child-theme' ); ?></a></li>
					<li><a href="<?php echo esc_url( deltora_consulting_get_page_url( 'chi-siamo' ) ); ?>"><?php esc_html_e( 'Chi siamo', 'deltora-consulting-child-theme' ); ?></a></li>
					<li><a href="<?php echo esc_url( deltora_consulting_get_page_url( 'servizi' ) ); ?>"><?php esc_html_e( 'Servizi', 'deltora-consulting-child-theme' ); ?></a></li>
					<li><a href="<?php echo esc_url( deltora_consulting_get_page_url( 'configuratore' ) ); ?>"><?php esc_html_e( 'Valore d’impresa', 'deltora-consulting-child-theme' ); ?></a></li>
				</ul>
			<?php endif; ?>

			<?php if ( shortcode_exists( 'tw_language_switcher' ) ) : ?>
				<div class="deltora-mobile-language-switcher">
					<?php echo do_shortcode( '[tw_language_switcher]' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				</div>
			<?php endif; ?>

			<a class="deltora-mobile-menu-contact<?php echo is_page( 'contatti' ) ? ' is-current' : ''; ?>" href="<?php echo esc_url( deltora_consulting_get_page_url( 'contatti' ) ); ?>"<?php echo is_page( 'contatti' ) ? ' aria-current="page"' : ''; ?>>
				<?php esc_html_e( 'Contattaci', 'deltora-consulting-child-theme' ); ?>
			</a>
		</nav>

		<a class="deltora-button deltora-button--header<?php echo is_page( 'contatti' ) ? ' is-current' : ''; ?>" href="<?php echo esc_url( deltora_consulting_get_page_url( 'contatti' ) ); ?>"<?php echo is_page( 'contatti' ) ? ' aria-current="page"' : ''; ?>>
			<?php esc_html_e( 'Contattaci', 'deltora-consulting-child-theme' ); ?>
		</a>

		<?php if ( shortcode_exists( 'tw_language_switcher' ) ) : ?>
			<div class="deltora-desktop-language-switcher">
				<?php echo do_shortcode( '[tw_language_switcher]' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			</div>
		<?php endif; ?>
	</div>
</header>
