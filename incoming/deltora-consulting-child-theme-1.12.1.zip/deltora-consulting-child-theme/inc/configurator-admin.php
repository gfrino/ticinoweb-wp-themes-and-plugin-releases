<?php
/**
 * Configurator sector administration.
 *
 * @package DeltoraConsultingChildTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Register the sector editor below ticinoWEB CMS. */
function deltora_consulting_add_configurator_admin_page() {
	add_submenu_page(
		'ticinoweb-cms',
		__( 'Settori e coefficienti', 'deltora-consulting-child-theme' ),
		__( 'Settori e coefficienti', 'deltora-consulting-child-theme' ),
		'edit_pages',
		'ticinoweb-cms-configurator-sectors',
		'deltora_consulting_render_configurator_admin_page'
	);
}
add_action( 'admin_menu', 'deltora_consulting_add_configurator_admin_page', 30 );

/** Load editor assets only on the sector page. */
function deltora_consulting_enqueue_configurator_admin_assets( $hook_suffix ) {
	if ( 'ticinoweb-cms_page_ticinoweb-cms-configurator-sectors' !== $hook_suffix ) {
		return;
	}
	$version = wp_get_theme()->get( 'Version' );
	wp_enqueue_style( 'deltora-configurator-admin', get_stylesheet_directory_uri() . '/assets/css/configurator-admin.css', array(), $version );
	wp_enqueue_script( 'deltora-configurator-admin', get_stylesheet_directory_uri() . '/assets/js/configurator-admin.js', array(), $version, true );
}
add_action( 'admin_enqueue_scripts', 'deltora_consulting_enqueue_configurator_admin_assets' );

/** Return the sector admin URL. */
function deltora_consulting_get_configurator_admin_url( $args = array() ) {
	return add_query_arg( $args, admin_url( 'admin.php?page=ticinoweb-cms-configurator-sectors' ) );
}

/** Render one editable sector row. */
function deltora_consulting_render_sector_admin_row( $sector, $index ) {
	$is_other = 'other' === $sector['id'];
	?>
	<tr class="deltora-sector-admin__row<?php echo $is_other ? ' is-fallback' : ''; ?>" data-sector-row data-sector-id="<?php echo esc_attr( $sector['id'] ); ?>">
		<td class="deltora-sector-admin__handle"><span class="dashicons dashicons-move" aria-hidden="true"></span><span class="screen-reader-text"><?php esc_html_e( 'Posizione', 'deltora-consulting-child-theme' ); ?></span></td>
		<td>
			<input type="hidden" data-sector-field="id" name="sectors[<?php echo esc_attr( $index ); ?>][id]" value="<?php echo esc_attr( $sector['id'] ); ?>">
			<input class="regular-text" data-sector-field="label" name="sectors[<?php echo esc_attr( $index ); ?>][label]" value="<?php echo esc_attr( $sector['label'] ); ?>" <?php echo $is_other ? 'readonly' : ''; ?> required>
			<code><?php echo esc_html( $sector['id'] ); ?></code>
		</td>
		<td><textarea data-sector-field="description" name="sectors[<?php echo esc_attr( $index ); ?>][description]" rows="3" <?php echo $is_other ? 'readonly' : ''; ?>><?php echo esc_textarea( $sector['description'] ); ?></textarea></td>
		<td class="deltora-sector-admin__multiple">
			<?php if ( $is_other ) : ?>
				<span aria-label="<?php esc_attr_e( 'Nessun multiplo', 'deltora-consulting-child-theme' ); ?>">—</span>
			<?php else : ?>
				<label><span>Min</span><input type="number" data-sector-field="min" name="sectors[<?php echo esc_attr( $index ); ?>][min]" min="3" max="5" step="0.1" value="<?php echo esc_attr( number_format( (float) $sector['min'], 1, '.', '' ) ); ?>" required></label>
				<label><span>Max</span><input type="number" data-sector-field="max" name="sectors[<?php echo esc_attr( $index ); ?>][max]" min="3" max="5" step="0.1" value="<?php echo esc_attr( number_format( (float) $sector['max'], 1, '.', '' ) ); ?>" required></label>
			<?php endif; ?>
		</td>
		<td><textarea data-sector-field="keywords" name="sectors[<?php echo esc_attr( $index ); ?>][keywords]" rows="3" placeholder="parola; altra parola" <?php disabled( $is_other ); ?>><?php echo esc_textarea( implode( '; ', $sector['keywords'] ) ); ?></textarea></td>
		<td class="deltora-sector-admin__status">
			<input type="hidden" data-sector-field="enabled" name="sectors[<?php echo esc_attr( $index ); ?>][enabled]" value="0">
			<label><input type="checkbox" data-sector-field="enabled" name="sectors[<?php echo esc_attr( $index ); ?>][enabled]" value="1" <?php checked( ! empty( $sector['enabled'] ) ); ?> <?php disabled( $is_other ); ?>> <?php esc_html_e( 'Attivo', 'deltora-consulting-child-theme' ); ?></label>
			<?php if ( $is_other ) : ?><input type="hidden" data-sector-field="enabled" name="sectors[<?php echo esc_attr( $index ); ?>][enabled]" value="1"><?php endif; ?>
		</td>
		<td class="deltora-sector-admin__actions">
			<?php if ( ! $is_other ) : ?>
				<button class="button" type="button" data-sector-move-up aria-label="<?php esc_attr_e( 'Sposta su', 'deltora-consulting-child-theme' ); ?>">↑</button>
				<button class="button" type="button" data-sector-move-down aria-label="<?php esc_attr_e( 'Sposta giù', 'deltora-consulting-child-theme' ); ?>">↓</button>
				<button class="button-link-delete" type="button" data-sector-remove><?php esc_html_e( 'Rimuovi', 'deltora-consulting-child-theme' ); ?></button>
			<?php else : ?>
				<span class="description"><?php esc_html_e( 'Sempre ultimo', 'deltora-consulting-child-theme' ); ?></span>
			<?php endif; ?>
		</td>
	</tr>
	<?php
}

/** Render the sector editor. */
function deltora_consulting_render_configurator_admin_page() {
	if ( ! current_user_can( 'edit_pages' ) ) {
		wp_die( esc_html__( 'Permessi insufficienti.', 'deltora-consulting-child-theme' ) );
	}
	$sectors = deltora_consulting_get_configured_sectors();
	$status  = sanitize_key( wp_unslash( $_GET['deltora_status'] ?? '' ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	?>
	<div class="wrap deltora-sector-admin">
		<h1><?php esc_html_e( 'Settori e coefficienti', 'deltora-consulting-child-theme' ); ?></h1>
		<p class="deltora-sector-admin__intro"><?php esc_html_e( 'Gestisci le attività mostrate nel configuratore. I coefficienti sono provvisori e devono restare compresi tra 3,0x e 5,0x.', 'deltora-consulting-child-theme' ); ?></p>
		<?php if ( 'saved' === $status ) : ?><div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'Settori aggiornati.', 'deltora-consulting-child-theme' ); ?></p></div><?php endif; ?>
		<?php if ( 'reset' === $status ) : ?><div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'Valori iniziali ripristinati.', 'deltora-consulting-child-theme' ); ?></p></div><?php endif; ?>
		<?php if ( 'invalid' === $status ) : ?><div class="notice notice-error"><p><?php esc_html_e( 'Le modifiche non sono state salvate. Controlla nomi, duplicati e intervalli dei coefficienti.', 'deltora-consulting-child-theme' ); ?></p></div><?php endif; ?>

		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" data-sector-admin-form>
			<input type="hidden" name="action" value="deltora_save_configurator_sectors">
			<?php wp_nonce_field( 'deltora_save_configurator_sectors' ); ?>
			<div class="deltora-sector-admin__table-wrap">
				<table class="widefat striped deltora-sector-admin__table">
					<thead><tr><th></th><th><?php esc_html_e( 'Settore', 'deltora-consulting-child-theme' ); ?></th><th><?php esc_html_e( 'Descrizione', 'deltora-consulting-child-theme' ); ?></th><th><?php esc_html_e( 'Multipli', 'deltora-consulting-child-theme' ); ?></th><th><?php esc_html_e( 'Parole chiave', 'deltora-consulting-child-theme' ); ?></th><th><?php esc_html_e( 'Stato', 'deltora-consulting-child-theme' ); ?></th><th><?php esc_html_e( 'Azioni', 'deltora-consulting-child-theme' ); ?></th></tr></thead>
					<tbody data-sector-rows><?php foreach ( $sectors as $index => $sector ) { deltora_consulting_render_sector_admin_row( $sector, $index ); } ?></tbody>
				</table>
			</div>
			<div class="deltora-sector-admin__footer">
				<button class="button" type="button" data-sector-add><?php esc_html_e( 'Aggiungi settore', 'deltora-consulting-child-theme' ); ?></button>
				<?php submit_button( __( 'Salva settori', 'deltora-consulting-child-theme' ), 'primary', 'submit', false ); ?>
			</div>
		</form>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="deltora-sector-admin__reset">
			<input type="hidden" name="action" value="deltora_reset_configurator_sectors">
			<?php wp_nonce_field( 'deltora_reset_configurator_sectors' ); ?>
			<button class="button-link" type="submit" onclick="return window.confirm('<?php echo esc_js( __( 'Ripristinare tutti i settori e coefficienti iniziali?', 'deltora-consulting-child-theme' ) ); ?>')"><?php esc_html_e( 'Ripristina valori iniziali', 'deltora-consulting-child-theme' ); ?></button>
		</form>

		<template data-sector-template>
			<tr class="deltora-sector-admin__row" data-sector-row data-sector-id="">
				<td class="deltora-sector-admin__handle"><span class="dashicons dashicons-move" aria-hidden="true"></span></td>
				<td><input type="hidden" data-sector-field="id" value=""><input class="regular-text" data-sector-field="label" value="" required><code><?php esc_html_e( 'ID creato al salvataggio', 'deltora-consulting-child-theme' ); ?></code></td>
				<td><textarea data-sector-field="description" rows="3"></textarea></td>
				<td class="deltora-sector-admin__multiple"><label><span>Min</span><input type="number" data-sector-field="min" min="3" max="5" step="0.1" value="3.0" required></label><label><span>Max</span><input type="number" data-sector-field="max" min="3" max="5" step="0.1" value="4.0" required></label></td>
				<td><textarea data-sector-field="keywords" rows="3" placeholder="parola; altra parola"></textarea></td>
				<td class="deltora-sector-admin__status"><input type="hidden" data-sector-enabled-hidden value="0"><label><input type="checkbox" data-sector-field="enabled" value="1" checked> <?php esc_html_e( 'Attivo', 'deltora-consulting-child-theme' ); ?></label></td>
				<td class="deltora-sector-admin__actions"><button class="button" type="button" data-sector-move-up>↑</button><button class="button" type="button" data-sector-move-down>↓</button><button class="button-link-delete" type="button" data-sector-remove><?php esc_html_e( 'Rimuovi', 'deltora-consulting-child-theme' ); ?></button></td>
			</tr>
		</template>
	</div>
	<?php
}

/** Validate an admin submission before the shared sanitizer runs. */
function deltora_consulting_validate_admin_sectors( $raw_sectors ) {
	if ( ! is_array( $raw_sectors ) || empty( $raw_sectors ) ) {
		return false;
	}
	$ids = array();
	foreach ( $raw_sectors as $raw_sector ) {
		if ( ! is_array( $raw_sector ) ) {
			return false;
		}
		$label = trim( sanitize_text_field( wp_unslash( (string) ( $raw_sector['label'] ?? '' ) ) ) );
		$id    = sanitize_key( (string) ( $raw_sector['id'] ?? '' ) );
		$id    = '' !== $id ? $id : sanitize_title( $label );
		if ( '' === $label || '' === $id || isset( $ids[ $id ] ) ) {
			return false;
		}
		$ids[ $id ] = true;
		if ( 'other' === $id ) {
			continue;
		}
		$minimum = $raw_sector['min'] ?? null;
		$maximum = $raw_sector['max'] ?? null;
		if ( ! is_numeric( $minimum ) || ! is_numeric( $maximum ) || (float) $minimum < 3.0 || (float) $maximum > 5.0 || (float) $minimum > (float) $maximum ) {
			return false;
		}
	}
	return true;
}

/** Save sector edits. */
function deltora_consulting_handle_save_configurator_sectors() {
	if ( ! current_user_can( 'edit_pages' ) ) {
		wp_die( esc_html__( 'Permessi insufficienti.', 'deltora-consulting-child-theme' ) );
	}
	check_admin_referer( 'deltora_save_configurator_sectors' );
	$raw = isset( $_POST['sectors'] ) ? wp_unslash( $_POST['sectors'] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
	if ( ! deltora_consulting_validate_admin_sectors( $raw ) ) {
		wp_safe_redirect( deltora_consulting_get_configurator_admin_url( array( 'deltora_status' => 'invalid' ) ) );
		exit;
	}
	update_option( 'deltora_configurator_sectors', deltora_consulting_sanitize_sectors( $raw ), false );
	wp_safe_redirect( deltora_consulting_get_configurator_admin_url( array( 'deltora_status' => 'saved' ) ) );
	exit;
}
add_action( 'admin_post_deltora_save_configurator_sectors', 'deltora_consulting_handle_save_configurator_sectors' );

/** Restore the bundled sector catalogue. */
function deltora_consulting_handle_reset_configurator_sectors() {
	if ( ! current_user_can( 'edit_pages' ) ) {
		wp_die( esc_html__( 'Permessi insufficienti.', 'deltora-consulting-child-theme' ) );
	}
	check_admin_referer( 'deltora_reset_configurator_sectors' );
	delete_option( 'deltora_configurator_sectors' );
	wp_safe_redirect( deltora_consulting_get_configurator_admin_url( array( 'deltora_status' => 'reset' ) ) );
	exit;
}
add_action( 'admin_post_deltora_reset_configurator_sectors', 'deltora_consulting_handle_reset_configurator_sectors' );
