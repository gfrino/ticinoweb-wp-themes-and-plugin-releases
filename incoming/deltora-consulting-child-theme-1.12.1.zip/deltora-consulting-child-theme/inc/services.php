<?php
/**
 * Shared service model for Deltora templates and CMS extensions.
 *
 * @package DeltoraConsultingChildTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Resolve a Media Library attachment from a stored URL.
 *
 * Older multisite values can include the subsite path even when WordPress now
 * generates attachment URLs from the network root. Rebuilding the URL from the
 * current uploads base keeps responsive image metadata available without
 * rewriting the CMS value.
 *
 * @param string $url Media URL.
 * @return int Attachment ID, or 0 when the URL is not a local attachment.
 */
function deltora_consulting_get_attachment_id_from_url( $url ) {
	$url = esc_url_raw( $url );

	if ( '' === $url ) {
		return 0;
	}

	$attachment_id = attachment_url_to_postid( $url );

	if ( $attachment_id ) {
		return (int) $attachment_id;
	}

	$url_path = wp_parse_url( $url, PHP_URL_PATH );
	if ( ! is_string( $url_path ) || '' === $url_path ) {
		return 0;
	}

	$site_marker = '/sites/' . get_current_blog_id() . '/';
	$marker_pos   = strpos( $url_path, $site_marker );

	if ( false !== $marker_pos ) {
		$relative_path = substr( $url_path, $marker_pos + strlen( $site_marker ) );
	} else {
		$uploads_marker = '/wp-content/uploads/';
		$marker_pos     = strpos( $url_path, $uploads_marker );

		if ( false === $marker_pos ) {
			return 0;
		}

		$relative_path = substr( $url_path, $marker_pos + strlen( $uploads_marker ) );
	}

	$uploads = wp_get_upload_dir();
	if ( empty( $uploads['baseurl'] ) || '' === $relative_path ) {
		return 0;
	}

	$canonical_url = trailingslashit( $uploads['baseurl'] ) . ltrim( $relative_path, '/' );

	return (int) attachment_url_to_postid( $canonical_url );
}

/**
 * Normalize the native ticinoWEB services and Deltora-specific content.
 *
 * @param array $services Native CMS services.
 * @param array $content  Deltora content keyed by service ID.
 * @return array
 */
function deltora_consulting_normalize_services( array $services, array $content ) {
	$normalized = array();
	$used_slugs = array();

	foreach ( $services as $index => $service ) {
		if ( ! is_array( $service ) ) {
			continue;
		}

		$id    = sanitize_key( $service['id'] ?? '' );
		$title = sanitize_text_field( $service['title'] ?? '' );

		if ( '' === $id || '' === $title ) {
			continue;
		}

		$extra     = isset( $content[ $id ] ) && is_array( $content[ $id ] ) ? $content[ $id ] : array();
		$base_slug = sanitize_title( $extra['slug'] ?? $title );

		if ( '' === $base_slug ) {
			$base_slug = 'servizio-' . ( $index + 1 );
		}

		$slug   = $base_slug;
		$suffix = 2;

		while ( isset( $used_slugs[ $slug ] ) ) {
			$slug = $base_slug . '-' . $suffix;
			++$suffix;
		}

		$used_slugs[ $slug ] = true;
		$description         = wp_kses_post( $service['description'] ?? '' );
		$summary             = sanitize_text_field( $extra['summary'] ?? '' );

		if ( '' === $summary ) {
			$summary = wp_trim_words( wp_strip_all_tags( $description ), 32, '…' );
		}

		$raw_details = isset( $extra['details'] ) && is_array( $extra['details'] ) ? $extra['details'] : array();
		$details     = array_values(
			array_filter(
				array_map( 'sanitize_text_field', $raw_details ),
				static function ( $detail ) {
					return '' !== $detail;
				}
			)
		);

		$normalized[] = array(
			'id'          => $id,
			'slug'        => $slug,
			'title'       => $title,
			'category'    => sanitize_text_field( $extra['category'] ?? '' ),
			'summary'     => $summary,
			'description' => $description,
			'details'     => $details,
			'image'       => esc_url_raw( $service['image'] ?? '' ),
			'icon_type'   => 'svg' === ( $service['icon_type'] ?? '' ) ? 'svg' : 'dashicon',
			'icon'        => sanitize_html_class( preg_replace( '/\s+/', '-', (string) ( $service['icon'] ?? '' ) ) ),
			'icon_svg'    => esc_url_raw( $service['icon_svg'] ?? '' ),
		);
	}

	return $normalized;
}

/**
 * Return the services used by every public Deltora surface.
 *
 * @return array
 */
function deltora_consulting_get_services() {
	$services = function_exists( 'ticinoweb_get_services' ) ? ticinoweb_get_services() : get_option( 'ticinoweb_services', array() );
	$content  = get_option( 'deltora_service_content', array() );

	return deltora_consulting_normalize_services(
		is_array( $services ) ? $services : array(),
		is_array( $content ) ? $content : array()
	);
}

/**
 * Sanitize the Deltora-specific service fields before saving them.
 *
 * @param mixed $input Submitted option value.
 * @return array
 */
function deltora_consulting_sanitize_service_content( $input ) {
	$sanitized = array();

	if ( ! is_array( $input ) ) {
		return $sanitized;
	}

	foreach ( $input as $raw_id => $fields ) {
		$id = sanitize_key( $raw_id );

		if ( '' === $id || ! is_array( $fields ) ) {
			continue;
		}

		$details = array();
		if ( isset( $fields['details'] ) && is_array( $fields['details'] ) ) {
			$details = $fields['details'];
		} elseif ( isset( $fields['details_text'] ) && is_string( $fields['details_text'] ) ) {
			$details = preg_split( '/\r\n|\r|\n/', $fields['details_text'] );
		}

		$sanitized[ $id ] = array(
			'slug'     => sanitize_title( $fields['slug'] ?? '' ),
			'category' => sanitize_text_field( $fields['category'] ?? '' ),
			'summary'  => sanitize_text_field( $fields['summary'] ?? '' ),
			'details'  => array_values(
				array_filter(
					array_map( 'sanitize_text_field', is_array( $details ) ? $details : array() ),
					static function ( $detail ) {
						return '' !== $detail;
					}
				)
			),
		);
	}

	return $sanitized;
}

/**
 * Return the one-time seed used to preserve the approved five-service structure.
 *
 * This is migration data only. Public templates always read the CMS options.
 *
 * @return array
 */
function deltora_consulting_get_service_migration_map() {
	return array(
		'insediamenti-e-delocalizzazioni' => array(
			'slug'        => 'insediamenti',
			'category'    => 'Sviluppo & Presenza',
			'summary'     => 'Supporto nell’avvio o nel trasferimento di attività tra Svizzera e Italia, dalla costituzione societaria all’organizzazione operativa.',
			'description' => 'Un percorso coordinato per avviare, trasferire o sviluppare un’attività tra Svizzera e Italia. Deltora affianca l’impresa dalla scelta della struttura societaria all’organizzazione degli adempimenti e dell’operatività quotidiana.',
			'details'     => array( 'Costituzione e insediamento societario', 'Coordinamento fiscale, amministrativo e operativo' ),
		),
		'consulenza-fiscale'              => array(
			'slug'        => 'fiscale',
			'category'    => 'Fisco & Pianificazione',
			'summary'     => 'Pianificazione fiscale nazionale e internazionale, imposizione diretta e indiretta per società e persone fisiche.',
			'description' => 'Pianificazione fiscale nazionale e internazionale costruita intorno alla realtà dell’impresa. Affianchiamo aziende e persone fisiche nella gestione dell’imposizione diretta e indiretta.',
			'details'     => array( 'Ottimizzazione fiscale intercantonale', 'Pianificazione e Budgeting dell’imposta sugli utili societari' ),
		),
		'consulenza-contabile-e-societaria' => array(
			'slug'        => 'contabile',
			'category'    => 'Amministrazione & Bilancio',
			'summary'     => 'Adempimenti contabili e amministrativi, outsourcing, lavoro e paghe, assistenza continua fino alla chiusura di bilancio.',
			'description' => 'Ordine amministrativo e continuità operativa, dalla contabilità alla chiusura del bilancio. Un presidio affidabile per gli adempimenti quotidiani e le fasi più delicate.',
			'details'     => array( 'Contabilità e gestione del personale', 'Bilancio d’esercizio e analisi comparativa' ),
		),
		'consulenza-di-direzione'         => array(
			'slug'        => 'direzione',
			'category'    => 'Strategia & Organizzazione',
			'summary'     => 'Condivisione di competenze strategiche per sviluppare processi efficaci, governare la crescita e ottimizzare la gestione aziendale.',
			'description' => 'Competenze strategiche integrate per rendere i processi più efficaci, governare la crescita e trasformare numeri e informazioni in decisioni concrete.',
			'details'     => array( 'Organizzazione e controllo', 'Supporto alle decisioni aziendali' ),
		),
		'contrattualistica-commerciale-e-societaria' => array(
			'slug'        => 'contratti',
			'category'    => 'Diritto & Accordi Commerciali',
			'summary'     => 'Assistenza in diritto commerciale e societario, governance aziendale e supporto qualificato nelle fasi stragiudiziali, giudiziali e arbitrali.',
			'description' => 'Assistenza qualificata nei rapporti commerciali, nella governance e nelle fasi stragiudiziali, giudiziali e arbitrali, con una lettura concreta delle esigenze aziendali.',
			'details'     => array( 'Contratti e accordi commerciali', 'Governance e assistenza societaria' ),
		),
	);
}

/**
 * Prepare the native and child service options for the initial CMS migration.
 *
 * Existing IDs, media, icons and ordering are preserved. Existing editorial
 * overrides in the child option take precedence over migration defaults.
 *
 * @param array $services Native CMS services.
 * @param array $content  Existing Deltora service content.
 * @return array{services: array, content: array}
 */
function deltora_consulting_prepare_services_migration( array $services, array $content ) {
	$map           = deltora_consulting_get_service_migration_map();
	$prepared      = array();
	$prepared_data = is_array( $content ) ? $content : array();
	$known_titles  = array();
	$known_slugs   = array();

	foreach ( $services as $service ) {
		if ( ! is_array( $service ) ) {
			continue;
		}

		$title_key = sanitize_title( $service['title'] ?? '' );
		$id        = sanitize_key( $service['id'] ?? '' );

		if ( '' === $id || '' === $title_key ) {
			continue;
		}

		$known_titles[ $title_key ] = true;
		$existing_slug = sanitize_title( $prepared_data[ $id ]['slug'] ?? '' );
		if ( '' !== $existing_slug ) {
			$known_slugs[ $existing_slug ] = true;
		}

		if ( isset( $map[ $title_key ] ) ) {
			$defaults = $map[ $title_key ];
			$existing = isset( $prepared_data[ $id ] ) && is_array( $prepared_data[ $id ] ) ? $prepared_data[ $id ] : array();
			$prepared_data[ $id ] = array_merge(
				array(
					'slug'     => $defaults['slug'],
					'category' => $defaults['category'],
					'summary'  => $defaults['summary'],
					'details'  => $defaults['details'],
				),
				$existing
			);

			$current_description = trim( wp_strip_all_tags( $service['description'] ?? '' ) );
			if ( '' === $current_description || $current_description === $defaults['summary'] ) {
				$service['description'] = $defaults['description'];
			}
		}

		$prepared[] = $service;
	}

	$contracts_key = 'contrattualistica-commerciale-e-societaria';
	if ( ! isset( $known_titles[ $contracts_key ] ) && ! isset( $known_slugs['contratti'] ) ) {
		$defaults = $map[ $contracts_key ];
		$id       = 'srv_deltora_contratti';

		$prepared[] = array(
			'id'          => $id,
			'image'       => '',
			'title'       => 'Contrattualistica commerciale e societaria',
			'description' => $defaults['description'],
			'icon_type'   => 'dashicon',
			'icon'        => '',
			'icon_svg'    => '',
		);

		$existing = isset( $prepared_data[ $id ] ) && is_array( $prepared_data[ $id ] ) ? $prepared_data[ $id ] : array();
		$prepared_data[ $id ] = array_merge(
			array(
				'slug'     => $defaults['slug'],
				'category' => $defaults['category'],
				'summary'  => $defaults['summary'],
				'details'  => $defaults['details'],
			),
			$existing
		);
	}

	return array(
		'services' => $prepared,
		'content'  => deltora_consulting_sanitize_service_content( $prepared_data ),
	);
}

/**
 * Apply the service schema migration once for the current Deltora site.
 *
 * @return void
 */
function deltora_consulting_maybe_migrate_services() {
	if ( 1 <= (int) get_option( 'deltora_service_schema_version', 0 ) || ! current_user_can( 'manage_options' ) ) {
		return;
	}

	$services = get_option( 'ticinoweb_services', array() );
	$content  = get_option( 'deltora_service_content', array() );
	$prepared = deltora_consulting_prepare_services_migration(
		is_array( $services ) ? $services : array(),
		is_array( $content ) ? $content : array()
	);

	update_option( 'ticinoweb_services', $prepared['services'], false );
	update_option( 'deltora_service_content', $prepared['content'], false );
	update_option( 'deltora_service_schema_version', 1, false );
}
add_action( 'admin_init', 'deltora_consulting_maybe_migrate_services', 5 );

/**
 * Register child-owned service fields in the parent's settings form.
 *
 * @return void
 */
function deltora_consulting_register_service_settings() {
	register_setting(
		'ticinoweb_settings_group',
		'deltora_service_content',
		array(
			'type'              => 'array',
			'sanitize_callback' => 'deltora_consulting_sanitize_service_content',
			'default'           => array(),
		)
	);
}
add_action( 'admin_init', 'deltora_consulting_register_service_settings', 20 );

/**
 * Add Deltora fields to the existing ticinoWEB service editor only.
 *
 * @param string $hook Current admin screen hook.
 * @return void
 */
function deltora_consulting_enqueue_service_admin( $hook ) {
	if ( 'toplevel_page_ticinoweb-cms' !== $hook ) {
		return;
	}

	$theme = wp_get_theme();
	wp_enqueue_script(
		'deltora-consulting-admin-services',
		get_stylesheet_directory_uri() . '/assets/js/admin-services.js',
		array(),
		$theme->get( 'Version' ),
		true
	);
	wp_localize_script(
		'deltora-consulting-admin-services',
		'deltoraServiceAdmin',
		array(
			'content' => deltora_consulting_sanitize_service_content( get_option( 'deltora_service_content', array() ) ),
			'labels'  => array(
				'category'            => __( 'Categoria Home', 'deltora-consulting-child-theme' ),
				'category_placeholder' => __( 'Sviluppo & Presenza', 'deltora-consulting-child-theme' ),
				'summary'             => __( 'Sintesi Home', 'deltora-consulting-child-theme' ),
				'summary_placeholder' => __( 'Testo breve mostrato nella card della Home', 'deltora-consulting-child-theme' ),
				'details'             => __( 'Punti di dettaglio', 'deltora-consulting-child-theme' ),
				'details_placeholder' => __( 'Un punto per riga', 'deltora-consulting-child-theme' ),
				'description_hint'    => __( 'Testo esteso mostrato nella pagina Servizi.', 'deltora-consulting-child-theme' ),
			),
		)
	);
}
add_action( 'admin_enqueue_scripts', 'deltora_consulting_enqueue_service_admin', 20 );
