<?php
/**
 * Configurator fields and provisional valuation multiples.
 *
 * @package DeltoraConsultingChildTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Return the default sector catalogue.
 *
 * @return array<int,array<string,mixed>>
 */
function deltora_consulting_get_default_sectors() {
	return array(
		array(
			'id' => 'agriculture-energy-environment', 'label' => 'Agricoltura, risorse naturali, energia e ambiente',
			'description' => 'Agricoltura, selvicoltura, pesca, attività estrattive, energia, acqua, rifiuti e risanamento.',
			'keywords' => array( 'agricoltura', 'allevamento', 'coltivazione', 'pesca', 'silvicoltura', 'estrazione', 'energia', 'elettricità', 'acqua', 'rifiuti', 'riciclaggio', 'risanamento' ),
			'min' => 3.0, 'max' => 4.0, 'enabled' => true, 'provisional' => true,
		),
		array(
			'id' => 'manufacturing', 'label' => 'Industria e produzione',
			'description' => 'Produzione, lavorazione, assemblaggio, trasformazione industriale e manutenzione di macchinari.',
			'keywords' => array( 'produzione', 'fabbricazione', 'lavorazione', 'manifattura', 'assemblaggio', 'impianti', 'macchinari', 'industria' ),
			'min' => 3.5, 'max' => 4.5, 'enabled' => true, 'provisional' => true,
		),
		array(
			'id' => 'construction', 'label' => 'Costruzioni e artigianato',
			'description' => 'Edilizia, ingegneria civile, impiantistica, manutenzione e mestieri artigianali.',
			'keywords' => array( 'costruzione', 'edilizia', 'cantiere', 'impianti', 'manutenzione', 'falegnameria', 'elettricità', 'idraulica', 'artigianato' ),
			'min' => 3.0, 'max' => 4.0, 'enabled' => true, 'provisional' => true,
		),
		array(
			'id' => 'trade-ecommerce', 'label' => 'Commercio ed e-commerce',
			'description' => 'Distribuzione, vendita all’ingrosso e al dettaglio, negozi fisici e commercio elettronico.',
			'keywords' => array( 'commercio', 'vendita', 'distribuzione', 'negozio', 'e-commerce', 'importazione', 'esportazione', 'ingrosso', 'dettaglio' ),
			'min' => 3.0, 'max' => 3.5, 'enabled' => true, 'provisional' => true,
		),
		array(
			'id' => 'transport-logistics', 'label' => 'Trasporti e logistica',
			'description' => 'Trasporto di persone o merci, spedizioni, magazzinaggio, corrieri e servizi logistici.',
			'keywords' => array( 'trasporto', 'logistica', 'spedizione', 'corriere', 'magazzino', 'merci', 'mobilità', 'deposito' ),
			'min' => 3.5, 'max' => 4.5, 'enabled' => true, 'provisional' => true,
		),
		array(
			'id' => 'hospitality-tourism', 'label' => 'Turismo, alberghi e ristorazione',
			'description' => 'Alberghi, ristoranti, bar, catering, strutture ricettive, agenzie di viaggio e servizi turistici.',
			'keywords' => array( 'ristorante', 'albergo', 'hotel', 'ospitalità', 'turismo', 'catering', 'bar', 'viaggio', 'prenotazione' ),
			'min' => 3.0, 'max' => 3.5, 'enabled' => true, 'provisional' => true,
		),
		array(
			'id' => 'technology', 'label' => 'Tecnologia, software e telecomunicazioni',
			'description' => 'Software, SaaS, telecomunicazioni, infrastrutture informatiche, hosting e servizi digitali.',
			'keywords' => array( 'software', 'informatica', 'saas', 'digitale', 'piattaforma', 'tecnologia', 'sviluppo', 'telecomunicazioni', 'hosting', 'dati' ),
			'min' => 4.0, 'max' => 5.0, 'enabled' => true, 'provisional' => true,
		),
		array(
			'id' => 'media-creative', 'label' => 'Media, comunicazione e attività creative',
			'description' => 'Editoria, produzioni audiovisive, comunicazione, pubblicità, design e attività creative.',
			'keywords' => array( 'editoria', 'media', 'comunicazione', 'pubblicità', 'marketing', 'video', 'cinema', 'radio', 'design', 'creativo', 'contenuti' ),
			'min' => 3.5, 'max' => 4.5, 'enabled' => true, 'provisional' => true,
		),
		array(
			'id' => 'finance-insurance', 'label' => 'Finanza e assicurazioni',
			'description' => 'Servizi finanziari, assicurativi, fiduciari, gestione patrimoniale e attività ausiliarie.',
			'keywords' => array( 'finanza', 'finanziario', 'assicurazione', 'fiduciaria', 'investimento', 'gestione patrimoniale', 'credito', 'broker' ),
			'min' => 4.0, 'max' => 5.0, 'enabled' => true, 'provisional' => true,
		),
		array(
			'id' => 'real-estate', 'label' => 'Immobiliare',
			'description' => 'Intermediazione, amministrazione, gestione e servizi immobiliari.',
			'keywords' => array( 'immobiliare', 'proprietà', 'amministrazione stabili', 'gestione immobiliare', 'locazione', 'intermediazione', 'agenzia' ),
			'min' => 3.5, 'max' => 4.5, 'enabled' => true, 'provisional' => true,
		),
		array(
			'id' => 'professional-services', 'label' => 'Servizi professionali, consulenza e attività tecniche',
			'description' => 'Consulenza, contabilità, servizi legali, ingegneria, architettura, ricerca e altri servizi specialistici.',
			'keywords' => array( 'consulenza', 'contabilità', 'revisione', 'legale', 'ingegneria', 'architettura', 'ricerca', 'laboratorio', 'tecnico' ),
			'min' => 3.5, 'max' => 4.5, 'enabled' => true, 'provisional' => true,
		),
		array(
			'id' => 'business-support', 'label' => 'Servizi amministrativi e di supporto alle imprese',
			'description' => 'Noleggio, selezione del personale, vigilanza, facility management e servizi amministrativi.',
			'keywords' => array( 'noleggio', 'leasing operativo', 'personale', 'risorse umane', 'vigilanza', 'pulizia', 'facility', 'segreteria', 'supporto' ),
			'min' => 3.0, 'max' => 4.0, 'enabled' => true, 'provisional' => true,
		),
		array(
			'id' => 'education-training', 'label' => 'Istruzione e formazione',
			'description' => 'Scuole, formazione professionale, corsi, istruzione privata e servizi educativi.',
			'keywords' => array( 'scuola', 'istruzione', 'formazione', 'corso', 'insegnamento', 'accademia', 'educazione', 'coaching' ),
			'min' => 3.5, 'max' => 4.5, 'enabled' => true, 'provisional' => true,
		),
		array(
			'id' => 'health-social-veterinary', 'label' => 'Sanità, assistenza sociale e servizi veterinari',
			'description' => 'Studi sanitari, cliniche, terapie, assistenza sociale, cure residenziali e servizi veterinari.',
			'keywords' => array( 'medico', 'sanitario', 'clinica', 'terapia', 'assistenza', 'cura', 'sociale', 'residenziale', 'veterinario' ),
			'min' => 4.0, 'max' => 5.0, 'enabled' => true, 'provisional' => true,
		),
		array(
			'id' => 'personal-sport-entertainment', 'label' => 'Servizi alla persona, sport e intrattenimento',
			'description' => 'Benessere, sport, attività culturali e ricreative, riparazioni e altri servizi alla persona.',
			'keywords' => array( 'benessere', 'palestra', 'sport', 'intrattenimento', 'spettacolo', 'cultura', 'parrucchiere', 'estetica', 'riparazione', 'persona' ),
			'min' => 3.0, 'max' => 4.0, 'enabled' => true, 'provisional' => true,
		),
		array(
			'id' => 'other', 'label' => 'Altra attività / Non sono sicuro',
			'description' => 'Il settore richiede una classificazione da parte di Deltora.',
			'keywords' => array(), 'min' => null, 'max' => null, 'enabled' => true, 'provisional' => true,
		),
	);
}

/** Normalize a sector keyword list. */
function deltora_consulting_sanitize_sector_keywords( $raw_keywords ) {
	$keywords = is_array( $raw_keywords ) ? $raw_keywords : preg_split( '/[;,\r\n]+/', (string) $raw_keywords );
	$clean    = array();
	foreach ( (array) $keywords as $keyword ) {
		$keyword = trim( sanitize_text_field( wp_unslash( (string) $keyword ) ) );
		if ( '' !== $keyword ) {
			$clean[] = function_exists( 'mb_strtolower' ) ? mb_strtolower( $keyword, 'UTF-8' ) : strtolower( $keyword );
		}
	}
	return array_values( array_unique( $clean ) );
}

/** Sanitize stored sectors while preserving their order. */
function deltora_consulting_sanitize_sectors( $raw_sectors ) {
	if ( ! is_array( $raw_sectors ) ) {
		return array();
	}
	$clean = array();
	$other = null;
	$seen  = array();
	foreach ( $raw_sectors as $raw_sector ) {
		if ( ! is_array( $raw_sector ) ) {
			continue;
		}
		$label = sanitize_text_field( wp_unslash( (string) ( $raw_sector['label'] ?? '' ) ) );
		$id    = sanitize_key( (string) ( $raw_sector['id'] ?? '' ) );
		if ( '' === $id && '' !== $label ) {
			$id = sanitize_title( $label );
		}
		if ( '' === $id || '' === $label || isset( $seen[ $id ] ) ) {
			continue;
		}
		$sector = array(
			'id'          => $id,
			'label'       => $label,
			'description' => sanitize_textarea_field( wp_unslash( (string) ( $raw_sector['description'] ?? '' ) ) ),
			'keywords'    => deltora_consulting_sanitize_sector_keywords( $raw_sector['keywords'] ?? array() ),
			'min'         => null,
			'max'         => null,
			'enabled'     => 'other' === $id || ! empty( $raw_sector['enabled'] ),
			'provisional' => true,
		);
		if ( 'other' === $id ) {
			$other       = $sector;
			$seen[ $id ] = true;
			continue;
		}
		$minimum = is_numeric( $raw_sector['min'] ?? null ) ? (float) $raw_sector['min'] : null;
		$maximum = is_numeric( $raw_sector['max'] ?? null ) ? (float) $raw_sector['max'] : null;
		if ( null === $minimum || null === $maximum || $minimum < 3.0 || $maximum > 5.0 || $minimum > $maximum ) {
			continue;
		}
		$sector['min'] = $minimum;
		$sector['max'] = $maximum;
		$clean[]       = $sector;
		$seen[ $id ]   = true;
	}
	if ( null === $other ) {
		$defaults = deltora_consulting_get_default_sectors();
		$other    = end( $defaults );
	}
	$clean[] = $other;
	return $clean;
}

/** Return all configured sectors, including disabled entries. */
function deltora_consulting_get_configured_sectors() {
	$stored = get_option( 'deltora_configurator_sectors', null );
	if ( null === $stored ) {
		return deltora_consulting_get_default_sectors();
	}
	$clean = deltora_consulting_sanitize_sectors( $stored );
	return count( $clean ) > 1 ? $clean : deltora_consulting_get_default_sectors();
}

/** Return sectors available to the public configurator. */
function deltora_consulting_get_active_sectors() {
	return array_values(
		array_filter(
			deltora_consulting_get_configured_sectors(),
			static function ( $sector ) {
				return 'other' === $sector['id'] || ! empty( $sector['enabled'] );
			}
		)
	);
}

/** Return editable configurator configuration. */
function deltora_consulting_get_configurator_config() {
	return array(
		'currency'     => 'CHF',
		'guidedFields' => array(
			array( 'id' => 'netIncome', 'label' => 'Utile o perdita netta dopo le imposte', 'help' => 'È il risultato finale dell’esercizio, dopo imposte e componenti finanziarie.' ),
			array( 'id' => 'taxes', 'label' => 'Imposte sul reddito', 'help' => 'Inserisci le imposte sul reddito contabilizzate per l’esercizio.' ),
			array( 'id' => 'financialCosts', 'label' => 'Oneri finanziari', 'help' => 'Ad esempio interessi passivi su finanziamenti e altri costi finanziari.' ),
			array( 'id' => 'financialIncome', 'label' => 'Proventi finanziari', 'help' => 'Ad esempio interessi attivi. Questa voce viene sottratta nel calcolo.' ),
			array( 'id' => 'tangibleDepreciation', 'label' => 'Ammortamenti materiali', 'help' => 'Ammortamenti relativi a impianti, macchinari, veicoli e altri beni materiali.' ),
			array( 'id' => 'intangibleAmortization', 'label' => 'Ammortamenti immateriali', 'help' => 'Ammortamenti relativi a software, licenze e altri beni immateriali.' ),
			array( 'id' => 'impairments', 'label' => 'Svalutazioni', 'help' => 'Riduzioni di valore contabilizzate su crediti, immobilizzazioni o altre attività.' ),
		),
		'sectors'      => deltora_consulting_get_active_sectors(),
	);
}
