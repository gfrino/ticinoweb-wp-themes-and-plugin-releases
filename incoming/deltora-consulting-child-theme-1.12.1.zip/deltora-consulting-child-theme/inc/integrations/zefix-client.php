<?php
/**
 * Server-side client for the Zefix PublicREST API.
 *
 * @package DeltoraConsultingChildTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Return the fixed public Zefix API base URL. */
function deltora_consulting_get_zefix_base_url() {
	return 'https://www.zefix.admin.ch/ZefixPublicREST';
}

/**
 * Normalize a formatted Swiss UID to the compact Zefix form.
 *
 * @param string $value Raw UID.
 * @return string
 */
function deltora_consulting_normalize_zefix_uid( $value ) {
	$value = strtoupper( sanitize_text_field( (string) $value ) );
	return (string) preg_replace( '/[^A-Z0-9]/', '', $value );
}

/**
 * Determine whether a value is a complete Swiss UID.
 *
 * @param string $value Candidate UID.
 * @return bool
 */
function deltora_consulting_is_zefix_uid( $value ) {
	return 1 === preg_match( '/^CHE[0-9]{9}$/', deltora_consulting_normalize_zefix_uid( $value ) );
}

/**
 * Normalize and bound a company-name query.
 *
 * @param string $value Raw company-name query.
 * @return string
 */
function deltora_consulting_normalize_zefix_query( $value ) {
	$value = sanitize_text_field( (string) $value );
	$value = str_replace( array( '*', '?', '%' ), '', $value );
	$value = trim( (string) preg_replace( '/\s+/u', ' ', $value ) );

	if ( function_exists( 'mb_substr' ) ) {
		return mb_substr( $value, 0, 120, 'UTF-8' );
	}

	return substr( $value, 0, 120 );
}

/**
 * Return a unicode-aware string length.
 *
 * @param string $value Text to measure.
 * @return int
 */
function deltora_consulting_zefix_string_length( $value ) {
	return function_exists( 'mb_strlen' ) ? mb_strlen( $value, 'UTF-8' ) : strlen( $value );
}

/**
 * Normalize a company name for deterministic comparison only.
 *
 * @param string $value            Company name.
 * @param bool   $strip_legal_form Whether to remove a trailing legal form.
 * @return string
 */
function deltora_consulting_normalize_zefix_company_name( $value, $strip_legal_form = false ) {
	$value = deltora_consulting_normalize_zefix_query( $value );
	$value = function_exists( 'remove_accents' ) ? remove_accents( $value ) : $value;
	$value = function_exists( 'mb_strtolower' ) ? mb_strtolower( $value, 'UTF-8' ) : strtolower( $value );
	$value = trim( (string) preg_replace( '/[^a-z0-9]+/u', ' ', $value ) );

	if ( $strip_legal_form ) {
		$legal_forms = '(?:sa|sagl|sarl|ag|gmbh|srl|spa|snc|sas|societa anonima|societa a garanzia limitata)';
		$value       = trim( (string) preg_replace( '/\s+' . $legal_forms . '$/u', '', $value ) );
	}

	return trim( (string) preg_replace( '/\s+/', ' ', $value ) );
}

/**
 * Build a short list of safe Zefix name variants.
 *
 * Registered local businesses often omit spaces in their legal name or users
 * append a legal form that is not part of the stored spelling. Variants are
 * attempted only when the preceding search returned no result.
 *
 * @param string $query Normalized company-name query.
 * @return array<int,string>
 */
function deltora_consulting_get_zefix_search_variants( $query ) {
	$query    = deltora_consulting_normalize_zefix_query( $query );
	$variants = array( $query );
	$stripped = deltora_consulting_normalize_zefix_company_name( $query, true );

	if ( '' !== $stripped && $stripped !== deltora_consulting_normalize_zefix_company_name( $query ) ) {
		$variants[] = $stripped;
	}

	$compact = preg_replace( '/[^\p{L}\p{N}]+/u', '', $query );
	if ( is_string( $compact ) && '' !== $compact ) {
		$variants[] = $compact;
	}

	$generic_tokens = array( 'group', 'gruppo', 'holding', 'company', 'societa', 'services', 'service', 'swiss', 'suisse' );
	$tokens         = preg_split( '/\s+/u', deltora_consulting_normalize_zefix_company_name( $query, true ) );
	foreach ( (array) $tokens as $token ) {
		if ( deltora_consulting_zefix_string_length( $token ) >= 4 && ! in_array( $token, $generic_tokens, true ) ) {
			$variants[] = $token;
			break;
		}
	}

	$variants = array_values( array_unique( array_map( 'deltora_consulting_normalize_zefix_query', $variants ) ) );
	return array_values(
		array_filter(
			array_slice( $variants, 0, 4 ),
			static function ( $variant ) {
				return deltora_consulting_zefix_string_length( $variant ) >= 3;
			}
		)
	);
}

/**
 * Make one authenticated request to an allow-listed Zefix endpoint.
 *
 * @param string                   $method HTTP method.
 * @param string                   $path   API path.
 * @param array<string,mixed>|null $body   Optional JSON request body.
 * @return array<mixed>|WP_Error
 */
function deltora_consulting_zefix_request( $method, $path, $body = null ) {
	$settings = deltora_consulting_get_company_lookup_settings();
	if ( ! $settings['enabled'] ) {
		return new WP_Error( 'company_lookup_disabled', deltora_consulting_t( 'La ricerca automatica non è ancora disponibile.', 'configurator' ) );
	}
	if ( '' === $settings['zefix_username'] || '' === $settings['zefix_password'] ) {
		return new WP_Error( 'zefix_credentials', deltora_consulting_t( 'Il collegamento al registro non è configurato.', 'configurator' ) );
	}

	$method = strtoupper( (string) $method );
	if ( ! in_array( $method, array( 'GET', 'POST' ), true ) ) {
		return new WP_Error( 'zefix_method', deltora_consulting_t( 'Richiesta al registro non valida.', 'configurator' ) );
	}
	if ( 1 !== preg_match( '#^/api/v1/company/(?:search|uid/[A-Z0-9]+|ehraid/[0-9]+)$#', $path ) ) {
		return new WP_Error( 'zefix_path', deltora_consulting_t( 'Richiesta al registro non valida.', 'configurator' ) );
	}

	$url  = esc_url_raw( deltora_consulting_get_zefix_base_url() . $path );
	$args = array(
		'method'      => $method,
		'timeout'     => 8,
		'redirection' => 0,
		'sslverify'   => true,
		'headers'     => array(
			'Accept'        => 'application/json',
			'Authorization' => 'Basic ' . base64_encode( $settings['zefix_username'] . ':' . $settings['zefix_password'] ), // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode -- HTTP Basic authentication requires Base64.
		),
	);

	if ( null !== $body ) {
		$args['headers']['Content-Type'] = 'application/json';
		$args['body']                    = wp_json_encode( $body );
	}

	$response = wp_safe_remote_request( $url, $args );
	if ( is_wp_error( $response ) ) {
		return new WP_Error( 'zefix_unavailable', deltora_consulting_t( 'Il registro non è momentaneamente raggiungibile.', 'configurator' ) );
	}

	$status = (int) wp_remote_retrieve_response_code( $response );
	if ( in_array( $status, array( 401, 403 ), true ) ) {
		return new WP_Error( 'zefix_authentication', deltora_consulting_t( 'Il collegamento al registro non è autorizzato.', 'configurator' ) );
	}
	if ( 404 === $status ) {
		return new WP_Error( 'zefix_not_found', deltora_consulting_t( 'L’azienda non è stata trovata nel registro.', 'configurator' ) );
	}
	if ( 429 === $status || $status >= 500 ) {
		return new WP_Error( 'zefix_unavailable', deltora_consulting_t( 'Il registro non è momentaneamente disponibile.', 'configurator' ) );
	}
	if ( 200 !== $status ) {
		return new WP_Error( 'zefix_response', deltora_consulting_t( 'Il registro ha restituito una risposta non valida.', 'configurator' ) );
	}

	$decoded = json_decode( wp_remote_retrieve_body( $response ), true );
	if ( JSON_ERROR_NONE !== json_last_error() || ! is_array( $decoded ) ) {
		return new WP_Error( 'zefix_json', deltora_consulting_t( 'Il registro ha restituito dati non validi.', 'configurator' ) );
	}

	return $decoded;
}

/**
 * Extract a readable string from scalar or translated Zefix values.
 *
 * @param mixed $value Zefix scalar or translated object.
 * @return string
 */
function deltora_consulting_zefix_extract_text( $value ) {
	if ( is_scalar( $value ) ) {
		return sanitize_text_field( (string) $value );
	}
	if ( ! is_array( $value ) ) {
		return '';
	}

	foreach ( array( 'it', 'name', 'value', 'description', 'de', 'fr', 'en' ) as $key ) {
		if ( isset( $value[ $key ] ) ) {
			$text = deltora_consulting_zefix_extract_text( $value[ $key ] );
			if ( '' !== $text ) {
				return $text;
			}
		}
	}

	return '';
}

/**
 * Normalize one Zefix search result to the local public contract.
 *
 * @param mixed $company Raw company record.
 * @return array<string,mixed>
 */
function deltora_consulting_normalize_zefix_company_summary( $company ) {
	if ( ! is_array( $company ) ) {
		return array();
	}

	$name = deltora_consulting_zefix_extract_text( $company['name'] ?? $company['companyName'] ?? '' );
	if ( '' === $name ) {
		return array();
	}

	return array(
		'name'       => $name,
		'uid'        => deltora_consulting_normalize_zefix_uid( $company['uid'] ?? $company['uidFormatted'] ?? '' ),
		'ehraid'     => preg_replace( '/[^0-9]/', '', (string) ( $company['ehraid'] ?? $company['ehraId'] ?? '' ) ),
		'legal_seat' => deltora_consulting_zefix_extract_text( $company['legalSeat'] ?? $company['legal_seat'] ?? '' ),
		'canton'     => deltora_consulting_zefix_extract_text( $company['canton'] ?? '' ),
		'legal_form' => deltora_consulting_zefix_extract_text( $company['legalForm'] ?? $company['legal_form'] ?? '' ),
		'status'     => deltora_consulting_zefix_extract_text( $company['status'] ?? '' ),
	);
}

/**
 * Normalize and validate a public URL returned by Zefix.
 *
 * @param mixed $value Raw URL or translated URL object.
 * @return string
 */
function deltora_consulting_normalize_zefix_url( $value ) {
	$value = is_array( $value ) ? deltora_consulting_zefix_extract_text( $value ) : (string) $value;
	$url   = esc_url_raw( $value, array( 'http', 'https' ) );
	return $url && wp_http_validate_url( $url ) ? $url : '';
}

/**
 * Normalize one detailed Zefix company record.
 *
 * @param mixed $company Raw detailed company record.
 * @return array<string,mixed>
 */
function deltora_consulting_normalize_zefix_company_detail( $company ) {
	$summary = deltora_consulting_normalize_zefix_company_summary( $company );
	if ( empty( $summary ) ) {
		return array();
	}

	$address = $company['address'] ?? array();
	if ( empty( $address ) && ! empty( $company['addresses'][0] ) ) {
		$address = $company['addresses'][0];
	}
	$address = is_array( $address ) ? $address : array();

	$summary['purpose']      = deltora_consulting_zefix_extract_text( $company['purpose'] ?? $company['companyPurpose'] ?? '' );
	$summary['address']      = array(
		'street'       => deltora_consulting_zefix_extract_text( $address['street'] ?? $address['streetName'] ?? '' ),
		'house_number' => deltora_consulting_zefix_extract_text( $address['houseNumber'] ?? $address['house_number'] ?? '' ),
		'zip'          => deltora_consulting_zefix_extract_text( $address['swissZipCode'] ?? $address['zip'] ?? $address['postalCode'] ?? '' ),
		'city'         => deltora_consulting_zefix_extract_text( $address['city'] ?? $address['town'] ?? '' ),
	);
	$summary['zefix_url']    = deltora_consulting_normalize_zefix_url( $company['zefixDetailWeb'] ?? $company['zefixUrl'] ?? $company['zefix_url'] ?? '' );
	$summary['register_url'] = deltora_consulting_normalize_zefix_url( $company['cantonalExcerptWeb'] ?? $company['registerUrl'] ?? $company['register_url'] ?? '' );

	return $summary;
}

/**
 * Return a site-scoped transient key with a SHA-256 digest.
 *
 * @param string $prefix Cache namespace.
 * @param string $value  Normalized cache input.
 * @return string
 */
function deltora_consulting_zefix_cache_key( $prefix, $value ) {
	return 'deltora_zfx_' . sanitize_key( $prefix ) . '_' . substr( hash( 'sha256', get_current_blog_id() . '|' . $value ), 0, 48 );
}

/**
 * Score how closely a returned legal name matches the user's query.
 *
 * @param string $company_name Returned company name.
 * @param string $query        Original user query.
 * @return int
 */
function deltora_consulting_score_zefix_company_name( $company_name, $query ) {
	$name          = deltora_consulting_normalize_zefix_company_name( $company_name );
	$name_base     = deltora_consulting_normalize_zefix_company_name( $company_name, true );
	$query_name    = deltora_consulting_normalize_zefix_company_name( $query );
	$query_base    = deltora_consulting_normalize_zefix_company_name( $query, true );
	$name_compact  = str_replace( ' ', '', $name );
	$query_compact = str_replace( ' ', '', $query_name );

	if ( '' === $query_name || '' === $name ) {
		return 0;
	}
	if ( $name === $query_name ) {
		return 120;
	}
	if ( '' !== $query_base && $name_base === $query_base ) {
		return 110;
	}
	if ( $name_compact === $query_compact ) {
		return 105;
	}
	if ( 0 === strpos( $name, $query_name . ' ' ) || 0 === strpos( $name_compact, $query_compact ) ) {
		return 90;
	}
	if ( false !== strpos( $name, $query_name ) || false !== strpos( $name_compact, $query_compact ) ) {
		return 70;
	}

	return 0;
}

/**
 * Sort Zefix results by name proximity while keeping ties deterministic.
 *
 * @param array<int,array<string,mixed>> $results Normalized results.
 * @param string                         $query   Original user query.
 * @return array<int,array<string,mixed>>
 */
function deltora_consulting_rank_zefix_results( $results, $query ) {
	usort(
		$results,
		static function ( $first, $second ) use ( $query ) {
			$first_name  = (string) ( $first['name'] ?? '' );
			$second_name = (string) ( $second['name'] ?? '' );
			$score       = deltora_consulting_score_zefix_company_name( $second_name, $query ) <=> deltora_consulting_score_zefix_company_name( $first_name, $query );

			return 0 !== $score ? $score : strcasecmp( $first_name, $second_name );
		}
	);

	return $results;
}

/**
 * Execute one company-name search and normalize its response.
 *
 * @param string $query Safe company-name variant.
 * @return array<int,array<string,mixed>>|WP_Error
 */
function deltora_consulting_zefix_search_company_name( $query ) {
	$response = deltora_consulting_zefix_request(
		'POST',
		'/api/v1/company/search',
		array(
			'name'       => $query,
			'activeOnly' => true,
		)
	);
	if ( is_wp_error( $response ) ) {
		return $response;
	}

	$list = $response['results'] ?? $response['companies'] ?? $response['list'] ?? $response;
	if ( ! is_array( $list ) ) {
		return new WP_Error( 'zefix_response', deltora_consulting_t( 'Il registro ha restituito una risposta non valida.', 'configurator' ) );
	}

	$results = array();
	foreach ( array_slice( $list, 0, 25 ) as $company ) {
		$normalized = deltora_consulting_normalize_zefix_company_summary( $company );
		if ( ! empty( $normalized ) ) {
			$results[] = $normalized;
		}
	}

	return $results;
}

/**
 * Search active companies by name or exact UID.
 *
 * @param string $query Company name or UID.
 * @return array<int,array<string,mixed>>|WP_Error
 */
function deltora_consulting_zefix_search_companies( $query ) {
	if ( deltora_consulting_is_zefix_uid( $query ) ) {
		$company = deltora_consulting_zefix_get_company( $query, 'uid' );
		if ( is_wp_error( $company ) ) {
			return 'zefix_not_found' === $company->get_error_code() ? array() : $company;
		}
		return array( $company );
	}

	$query = deltora_consulting_normalize_zefix_query( $query );
	if ( deltora_consulting_zefix_string_length( $query ) < 3 ) {
		return new WP_Error( 'company_lookup_query', deltora_consulting_t( 'Inserisci almeno tre caratteri.', 'configurator' ) );
	}

	$cache_key = deltora_consulting_zefix_cache_key( 'search-v3', $query );
	$cached    = get_transient( $cache_key );
	if ( false !== $cached && is_array( $cached ) ) {
		return $cached;
	}

	$results = array();
	foreach ( deltora_consulting_get_zefix_search_variants( $query ) as $variant ) {
		$results = deltora_consulting_zefix_search_company_name( $variant );
		if ( is_wp_error( $results ) ) {
			return $results;
		}
		if ( ! empty( $results ) ) {
			break;
		}
	}
	$results = array_slice( deltora_consulting_rank_zefix_results( $results, $query ), 0, 10 );

	set_transient( $cache_key, $results, 15 * MINUTE_IN_SECONDS );
	return $results;
}

/**
 * Retrieve one company by UID or EHRA-ID.
 *
 * @param string|int $identifier UID or EHRA-ID.
 * @param string     $type       Identifier type.
 * @return array<string,mixed>|WP_Error
 */
function deltora_consulting_zefix_get_company( $identifier, $type = 'ehraid' ) {
	$type = 'uid' === $type ? 'uid' : 'ehraid';
	if ( 'uid' === $type ) {
		$identifier = deltora_consulting_normalize_zefix_uid( $identifier );
		if ( ! deltora_consulting_is_zefix_uid( $identifier ) ) {
			return new WP_Error( 'zefix_identifier', deltora_consulting_t( 'L’UID inserito non è valido.', 'configurator' ) );
		}
	} else {
		$identifier = preg_replace( '/[^0-9]/', '', (string) $identifier );
		if ( '' === $identifier || strlen( $identifier ) > 20 ) {
			return new WP_Error( 'zefix_identifier', deltora_consulting_t( 'L’identificativo inserito non è valido.', 'configurator' ) );
		}
	}

	$cache_key = deltora_consulting_zefix_cache_key( 'detail', $type . '|' . $identifier );
	$cached    = get_transient( $cache_key );
	if ( false !== $cached && is_array( $cached ) ) {
		return $cached;
	}

	$response = deltora_consulting_zefix_request( 'GET', '/api/v1/company/' . $type . '/' . rawurlencode( $identifier ) );
	if ( is_wp_error( $response ) ) {
		return $response;
	}

	$company = $response['company'] ?? $response;
	if ( isset( $company[0] ) && is_array( $company[0] ) ) {
		$company = $company[0];
	}
	$normalized = deltora_consulting_normalize_zefix_company_detail( $company );
	if ( empty( $normalized ) ) {
		return new WP_Error( 'zefix_response', deltora_consulting_t( 'Il registro ha restituito una risposta non valida.', 'configurator' ) );
	}

	set_transient( $cache_key, $normalized, HOUR_IN_SECONDS );
	return $normalized;
}
