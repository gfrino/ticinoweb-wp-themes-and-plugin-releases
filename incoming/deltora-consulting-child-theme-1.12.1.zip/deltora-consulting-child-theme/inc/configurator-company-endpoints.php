<?php
/**
 * Public AJAX boundary for the optional Zefix company lookup.
 *
 * @package DeltoraConsultingChildTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Build a privacy-preserving, site-scoped rate-limit key.
 *
 * @param string $scope Request group.
 * @return string
 */
function deltora_consulting_company_lookup_rate_limit_key( $scope ) {
	$address = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : 'unknown';
	$digest  = hash_hmac( 'sha256', $address, wp_salt( 'nonce' ) );

	return 'deltora_zfx_limit_' . get_current_blog_id() . '_' . sanitize_key( $scope ) . '_' . substr( $digest, 0, 32 );
}

/**
 * Apply a small anonymous rate limit before contacting Zefix.
 *
 * @param string $scope  Request group.
 * @param int    $limit  Maximum requests in the window.
 * @param int    $window Window duration in seconds.
 * @return bool
 */
function deltora_consulting_company_lookup_request_allowed( $scope, $limit = 20, $window = 600 ) {
	$key   = deltora_consulting_company_lookup_rate_limit_key( $scope );
	$count = (int) get_transient( $key );

	if ( $count >= $limit ) {
		return false;
	}

	set_transient( $key, $count + 1, max( MINUTE_IN_SECONDS, (int) $window ) );
	return true;
}

/**
 * Return only fields required by the browser interface.
 *
 * @param array<string,mixed> $company Normalized company data.
 * @return array<string,string>
 */
function deltora_consulting_get_public_company_summary( $company ) {
	return array(
		'name'       => sanitize_text_field( (string) ( $company['name'] ?? '' ) ),
		'uid'        => deltora_consulting_normalize_zefix_uid( (string) ( $company['uid'] ?? '' ) ),
		'ehraid'     => preg_replace( '/[^0-9]/', '', (string) ( $company['ehraid'] ?? '' ) ),
		'legal_seat' => sanitize_text_field( (string) ( $company['legal_seat'] ?? '' ) ),
		'canton'     => sanitize_text_field( (string) ( $company['canton'] ?? '' ) ),
		'legal_form' => sanitize_text_field( (string) ( $company['legal_form'] ?? '' ) ),
		'status'     => sanitize_text_field( (string) ( $company['status'] ?? '' ) ),
		'zefix_url'  => esc_url_raw( (string) ( $company['zefix_url'] ?? '' ) ),
	);
}

/**
 * Stop an invalid, disabled or excessive anonymous lookup request.
 *
 * @param string $scope Rate-limit group.
 * @return void
 */
function deltora_consulting_validate_company_lookup_request( $scope ) {
	if ( ! check_ajax_referer( 'deltora_configurator', 'nonce', false ) ) {
		wp_send_json_error( array( 'message' => deltora_consulting_t( 'La sessione è scaduta. Ricarica la pagina e riprova.', 'configurator' ) ), 403 );
	}

	$capabilities = deltora_consulting_get_company_lookup_capabilities();
	if ( empty( $capabilities['enabled'] ) ) {
		wp_send_json_error( array( 'message' => deltora_consulting_t( 'La ricerca automatica non è al momento disponibile. Puoi scegliere il settore manualmente.', 'configurator' ) ), 503 );
	}

	$limit = 'search' === $scope ? 60 : 40;
	if ( ! deltora_consulting_company_lookup_request_allowed( $scope, $limit ) ) {
		wp_send_json_error( array( 'message' => deltora_consulting_t( 'Hai effettuato troppe ricerche in poco tempo. Attendi qualche minuto oppure scegli il settore manualmente.', 'configurator' ) ), 429 );
	}
}

/**
 * Convert provider failures into safe and recoverable browser messages.
 *
 * @param WP_Error $error Provider error.
 * @return void
 */
function deltora_consulting_send_company_lookup_error( $error ) {
	$status  = 'company_lookup_query' === $error->get_error_code() ? 400 : 502;
	$message = 'company_lookup_query' === $error->get_error_code()
		? $error->get_error_message()
		: deltora_consulting_t( 'Il registro non ha risposto correttamente. Puoi riprovare oppure scegliere il settore manualmente.', 'configurator' );

	wp_send_json_error( array( 'message' => $message ), $status );
}

/** Handle an anonymous company-name or UID search. */
function deltora_consulting_ajax_search_companies() {
	deltora_consulting_validate_company_lookup_request( 'search' );

	$query   = isset( $_POST['query'] ) ? sanitize_text_field( wp_unslash( $_POST['query'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Verified centrally above.
	$results = deltora_consulting_search_companies( $query );
	if ( is_wp_error( $results ) ) {
		deltora_consulting_send_company_lookup_error( $results );
	}

	$public_results = array_values( array_filter( array_map( 'deltora_consulting_get_public_company_summary', $results ) ) );
	wp_send_json_success( array( 'results' => $public_results ) );
}
add_action( 'wp_ajax_deltora_search_companies', 'deltora_consulting_ajax_search_companies' );
add_action( 'wp_ajax_nopriv_deltora_search_companies', 'deltora_consulting_ajax_search_companies' );

/** Handle company selection and local sector classification. */
function deltora_consulting_ajax_select_company() {
	deltora_consulting_validate_company_lookup_request( 'detail' );

	$type       = isset( $_POST['type'] ) && 'uid' === sanitize_key( wp_unslash( $_POST['type'] ) ) ? 'uid' : 'ehraid'; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Verified centrally above.
	$identifier = isset( $_POST['identifier'] ) ? sanitize_text_field( wp_unslash( $_POST['identifier'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Verified centrally above.
	$company    = deltora_consulting_get_company_details( $identifier, $type );
	if ( is_wp_error( $company ) ) {
		deltora_consulting_send_company_lookup_error( $company );
	}

	$sectors        = deltora_consulting_get_active_sectors();
	$classification = deltora_consulting_classify_company_purpose( (string) ( $company['purpose'] ?? '' ), $sectors );
	$sector_id      = sanitize_key( (string) ( $classification['sector_id'] ?? 'other' ) );
	$sector_label   = '';

	foreach ( $sectors as $sector ) {
		if ( ( $sector['id'] ?? '' ) === $sector_id ) {
			$sector_label = sanitize_text_field( deltora_consulting_t( (string) ( $sector['label'] ?? '' ), 'configurator-sectors' ) );
			break;
		}
	}

	wp_send_json_success(
		array(
			'company'    => deltora_consulting_get_public_company_summary( $company ),
			'suggestion' => array(
				'sector_id'       => $sector_id,
				'sector_label'    => $sector_label,
				'source'          => 'local' === ( $classification['source'] ?? '' ) ? 'local' : 'manual',
				'requires_manual' => 'other' === $sector_id || '' === $sector_label,
			),
		)
	);
}
add_action( 'wp_ajax_deltora_select_company', 'deltora_consulting_ajax_select_company' );
add_action( 'wp_ajax_nopriv_deltora_select_company', 'deltora_consulting_ajax_select_company' );
