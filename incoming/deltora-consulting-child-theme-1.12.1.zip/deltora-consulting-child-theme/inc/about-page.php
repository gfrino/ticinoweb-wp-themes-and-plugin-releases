<?php
/**
 * Editable About page content.
 *
 * @package DeltoraConsultingChildTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Return the default introduction used when the About page excerpt is empty.
 *
 * @return string
 */
function deltora_consulting_get_default_about_excerpt() {
	return __( 'Affianchiamo le imprese nelle decisioni che contano', 'deltora-consulting-child-theme' );
}

/**
 * Return the initial About page body stored in the WordPress editor.
 *
 * The setup routine only inserts this content when the page is empty, so later
 * edits made in WordPress are never overwritten.
 *
 * @return string
 */
function deltora_consulting_get_default_about_content() {
	return sprintf(
		'<section class="deltora-about-story" aria-labelledby="deltora-about-story-title">
<div class="deltora-container deltora-about-story__grid">
<div class="deltora-about-story__heading">
<h2 id="deltora-about-story-title">%1$s</h2>
</div>
<div class="deltora-about-story__path">
<p>%2$s</p>
<p>%3$s</p>
<p>%4$s</p>
<p>%5$s %6$s %7$s %8$s %9$s</p>
</div>
</div>
</section>
<section class="deltora-about-network" aria-labelledby="deltora-about-network-title">
<div class="deltora-container deltora-about-network__grid">
<div>
<h2 id="deltora-about-network-title">%10$s</h2>
<p>%11$s</p>
</div>
<ul class="deltora-about-network__areas">
<li>%12$s</li>
<li>%13$s</li>
<li>%14$s</li>
</ul>
</div>
</section>',
		esc_html__( 'Un progetto fondato sull’esperienza', 'deltora-consulting-child-theme' ),
		esc_html__( 'Paolo Della Giovanna ha maturato oltre trent’anni di attività in Italia nella consulenza di direzione aziendale e nella professione di commercialista.', 'deltora-consulting-child-theme' ),
		esc_html__( 'Attivo in Svizzera dal 2009, dal 2016 ha consolidato la propria presenza a Lugano con una struttura fiduciaria dedicata.', 'deltora-consulting-child-theme' ),
		esc_html__( 'È iscritto all’Ordine dei Commercialisti del Canton Ticino.', 'deltora-consulting-child-theme' ),
		esc_html__( 'Ha contribuito al progetto SWIT ADVICE promosso dalla Swiss Chamber', 'deltora-consulting-child-theme' ),
		esc_html__( 'di Milano', 'deltora-consulting-child-theme' ),
		esc_html__( 'per accompagnare', 'deltora-consulting-child-theme' ),
		esc_html__( 'le', 'deltora-consulting-child-theme' ),
		esc_html__( 'imprese italiane interessate al contesto svizzero.', 'deltora-consulting-child-theme' ),
		esc_html__( 'Una rete costruita attorno all’incarico', 'deltora-consulting-child-theme' ),
		esc_html__( 'Quando un incarico richiede competenze complementari, Deltora coinvolge specialisti dedicati mantenendo continuità e chiarezza nel rapporto con l’impresa.', 'deltora-consulting-child-theme' ),
		esc_html__( 'Competenze legali', 'deltora-consulting-child-theme' ),
		esc_html__( 'Revisione contabile', 'deltora-consulting-child-theme' ),
		esc_html__( 'Gestione delle risorse umane', 'deltora-consulting-child-theme' )
	);
}
