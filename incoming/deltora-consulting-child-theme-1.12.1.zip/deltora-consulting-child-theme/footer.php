<?php
/**
 * Deltora site footer.
 *
 * @package DeltoraConsultingChildTheme
 */

$deltora_contact = deltora_consulting_get_contact_details();
?>

<footer class="site-footer">
	<div class="deltora-container site-footer__grid">
		<div class="site-footer__brand">
			<a class="site-footer__brand-link" href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
				<img
					class="site-footer__brand-logo"
					src="<?php echo esc_url( get_stylesheet_directory_uri() . '/assets/images/logo-header.png' ); ?>"
					alt="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>"
					width="1600"
					height="589"
					loading="lazy"
					decoding="async"
				>
			</a>
			<p><?php esc_html_e( 'Consulenza strategica per le imprese.', 'deltora-consulting-child-theme' ); ?></p>
		</div>

		<nav class="site-footer__navigation" aria-label="<?php esc_attr_e( 'Navigazione nel footer', 'deltora-consulting-child-theme' ); ?>">
			<h2><?php esc_html_e( 'Esplora', 'deltora-consulting-child-theme' ); ?></h2>
			<ul>
				<li><a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Home', 'deltora-consulting-child-theme' ); ?></a></li>
				<li><a href="<?php echo esc_url( deltora_consulting_get_page_url( 'chi-siamo' ) ); ?>"><?php esc_html_e( 'Chi siamo', 'deltora-consulting-child-theme' ); ?></a></li>
				<li><a href="<?php echo esc_url( deltora_consulting_get_page_url( 'servizi' ) ); ?>"><?php esc_html_e( 'Servizi', 'deltora-consulting-child-theme' ); ?></a></li>
				<li><a href="<?php echo esc_url( deltora_consulting_get_page_url( 'configuratore' ) ); ?>"><?php esc_html_e( 'Valore d’impresa', 'deltora-consulting-child-theme' ); ?></a></li>
				<li><a href="<?php echo esc_url( deltora_consulting_get_page_url( 'contatti' ) ); ?>"><?php esc_html_e( 'Contatti', 'deltora-consulting-child-theme' ); ?></a></li>
			</ul>
		</nav>

		<div class="site-footer__contact">
			<h2><?php esc_html_e( 'Contatti', 'deltora-consulting-child-theme' ); ?></h2>
			<ul>
					<?php if ( ! empty( $deltora_contact['phone'] ) ) : ?>
						<li>
							<a href="tel:<?php echo esc_attr( preg_replace( '/[^0-9+]/', '', $deltora_contact['phone'] ) ); ?>">
								<?php echo esc_html( $deltora_contact['phone'] ); ?>
							</a>
						</li>
					<?php endif; ?>

					<?php if ( ! empty( $deltora_contact['email'] ) ) : ?>
						<li>
							<a href="mailto:<?php echo esc_attr( antispambot( $deltora_contact['email'] ) ); ?>">
								<?php echo esc_html( antispambot( $deltora_contact['email'] ) ); ?>
							</a>
						</li>
					<?php endif; ?>

					<?php if ( ! empty( $deltora_contact['address'] ) ) : ?>
						<li><?php echo esc_html( $deltora_contact['address'] ); ?></li>
					<?php endif; ?>
			</ul>
		</div>
	</div>

	<div class="deltora-container site-footer__logos">
		<div class="site-footer__logo site-footer__logo--swiss-chamber">
			<img
				src="<?php echo esc_url( get_stylesheet_directory_uri() . '/assets/images/swiss-chamber-bianco.svg' ); ?>"
				alt="<?php esc_attr_e( 'Swiss Chamber', 'deltora-consulting-child-theme' ); ?>"
				width="207"
				height="75"
				loading="lazy"
				decoding="async"
			>
		</div>

		<div class="site-footer__logo site-footer__logo--occt">
			<img
				src="<?php echo esc_url( get_stylesheet_directory_uri() . '/assets/images/logo-occt-v01.png' ); ?>"
				alt="<?php esc_attr_e( 'Ordine dei Commercialisti del Canton Ticino', 'deltora-consulting-child-theme' ); ?>"
				width="1000"
				height="449"
				loading="lazy"
				decoding="async"
			>
		</div>
	</div>

	<div class="deltora-container site-footer__bottom">
		<p>
			&copy; <?php echo esc_html( wp_date( 'Y' ) ); ?> <?php echo esc_html( ! empty( $deltora_contact['company'] ) ? $deltora_contact['company'] : 'Deltora Consulting SA' ); ?>.
			<?php esc_html_e( 'Tutti i diritti riservati.', 'deltora-consulting-child-theme' ); ?>
		</p>

		<div class="site-footer__legal-links">
			<?php if ( get_privacy_policy_url() ) : ?>
				<a href="<?php echo esc_url( get_privacy_policy_url() ); ?>">
					<?php esc_html_e( 'Privacy', 'deltora-consulting-child-theme' ); ?>
				</a>
			<?php endif; ?>

			<?php if ( deltora_consulting_cookie_consent_is_enabled() ) : ?>
				<button type="button" class="site-footer__preference-button" data-cookie-preferences-open>
					<?php esc_html_e( 'Preferenze cookie', 'deltora-consulting-child-theme' ); ?>
				</button>
			<?php endif; ?>
		</div>

		<span class="site-footer__credit">
			Design by <a href="https://ticinoweb.com" target="_blank" rel="noopener">ticinoWEB</a>
		</span>
	</div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
