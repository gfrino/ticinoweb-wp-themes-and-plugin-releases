<?php
/**
 * About page template.
 *
 * The page title, introduction and body remain editable in WordPress. The
 * theme provides a verified default body only when those fields are empty.
 *
 * @package DeltoraConsultingChildTheme
 */

get_header();

while ( have_posts() ) :
	the_post();

	$deltora_about_lead = trim( get_the_excerpt() );
	if ( '' === $deltora_about_lead ) {
		$deltora_about_lead = deltora_consulting_get_default_about_excerpt();
	}

	$deltora_about_content = trim( get_the_content() );
	if ( '' === $deltora_about_content ) {
		$deltora_about_content = deltora_consulting_get_default_about_content();
	}

	$deltora_about_content = apply_filters( 'the_content', $deltora_about_content );
	?>

	<main id="main-content" class="site-main deltora-about-page">
		<header class="deltora-about-hero" aria-labelledby="deltora-about-title">
			<div class="deltora-container deltora-about-hero__content">
				<h1 id="deltora-about-title"><?php the_title(); ?></h1>
				<p class="deltora-about-hero__lead"><?php echo esc_html( $deltora_about_lead ); ?></p>
			</div>
		</header>

		<div class="deltora-about-page__content">
			<?php
			// The content has already passed through WordPress's standard content filters.
			echo $deltora_about_content; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			?>
		</div>
	</main>

	<?php
endwhile;

get_footer();
