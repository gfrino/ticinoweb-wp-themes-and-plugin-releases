<?php
/** @var array<string,mixed> $data */
$deltora_email_mode = 'guided' === $data['mode'] ? deltora_consulting_t( 'Calcolo guidato', 'configurator' ) : deltora_consulting_t( 'Inserimento diretto', 'configurator' );
$deltora_contact_url = add_query_arg( 'argomento', 'valore-impresa', deltora_consulting_localized_url( deltora_consulting_get_page_url( 'contatti' ) ) );
$deltora_email_t     = static function ( $text ) {
	return esc_html( deltora_consulting_t( $text, 'configurator-email' ) );
};
$deltora_email_lang  = function_exists( 'twtr_get_current_language' ) ? twtr_get_current_language() : 'it';
?>
<!doctype html>
<html lang="<?php echo esc_attr( $deltora_email_lang ); ?>">
<body style="margin:0;background:#f7f7f3;color:#202422;font-family:Arial,sans-serif;">
	<div style="max-width:680px;margin:0 auto;padding:32px 20px;">
		<div style="background:#1b201e;color:#fff;padding:28px;">
			<h1 style="font-size:28px;margin:0;"><?php echo $deltora_email_t( 'VALORE OPERATIVO INDICATIVO' ); ?></h1>
			<?php if ( $data['estimable'] ) : ?>
				<p style="font-size:30px;font-weight:700;margin:20px 0 0;"><?php echo esc_html( deltora_consulting_format_chf( $data['minimum'] ) . ' – ' . deltora_consulting_format_chf( $data['maximum'] ) ); ?></p>
			<?php elseif ( 'other' === $data['sector']['id'] ) : ?>
				<p style="font-size:18px;margin:20px 0 0;"><?php echo $deltora_email_t( 'Non siamo riusciti ad associare con certezza la tua attività a un settore. Contatta Deltora per identificare il settore corretto e completare la stima.' ); ?></p>
			<?php else : ?>
				<p style="font-size:18px;margin:20px 0 0;"><?php echo $deltora_email_t( 'Con i dati inseriti il metodo dei multipli EBITDA non produce una stima significativa.' ); ?></p>
			<?php endif; ?>
		</div>
		<div style="background:#fff;padding:28px;">
			<p><strong><?php echo $deltora_email_t( 'Data della stima' ); ?>:</strong> <?php echo esc_html( wp_date( 'd.m.Y' ) ); ?></p>
			<p><strong><?php echo $deltora_email_t( 'Modalità' ); ?>:</strong> <?php echo esc_html( $deltora_email_mode ); ?></p>
			<p><strong><?php echo $deltora_email_t( 'Attività' ); ?>:</strong> <?php echo esc_html( deltora_consulting_t( $data['sector']['label'], 'configurator-sectors' ) ); ?></p>
			<?php foreach ( $data['ebitdas'] as $index => $value ) : ?>
				<p><strong>EBITDA <?php echo esc_html( $data['year_labels'][ $index ] ); ?>:</strong> <?php echo esc_html( deltora_consulting_format_chf( $value ) ); ?></p>
			<?php endforeach; ?>
			<p><strong><?php echo $deltora_email_t( 'EBITDA medio' ); ?>:</strong> <?php echo esc_html( deltora_consulting_format_chf( $data['average'] ) ); ?></p>
			<?php if ( $data['estimable'] ) : ?>
				<p><strong><?php echo $deltora_email_t( 'Intervallo di multipli' ); ?>:</strong> <?php echo esc_html( number_format( $data['sector']['min'], 1 ) . 'x–' . number_format( $data['sector']['max'], 1 ) . 'x' ); ?></p>
			<?php endif; ?>
			<?php if ( 'yes' === $data['exceptional'] ) : ?>
				<p><?php echo $deltora_email_t( 'Hai indicato che uno o più esercizi includono ricavi o costi eccezionali. Questi elementi possono influire sull’EBITDA medio. Contatta Deltora per verificarli e ottenere una stima più precisa.' ); ?></p>
			<?php elseif ( 'unknown' === $data['exceptional'] ) : ?>
				<p><?php echo $deltora_email_t( 'Non sei sicuro che gli EBITDA inseriti includano ricavi o costi eccezionali. Questi elementi possono influire sull’EBITDA medio. Contatta Deltora per verificarli e ottenere una stima più precisa.' ); ?></p>
			<?php endif; ?>
			<?php if ( 'other' === $data['sector']['id'] ) : ?>
				<p><?php echo $deltora_email_t( 'Abbiamo comunque calcolato l’EBITDA medio dei tre esercizi. Per completare la stima è necessario identificare il settore e il relativo intervallo di multipli.' ); ?></p>
			<?php elseif ( $data['estimable'] ) : ?>
				<p><?php echo $deltora_email_t( 'La stima è ottenuta applicando l’intervallo di multipli all’EBITDA medio degli ultimi tre esercizi.' ); ?></p>
			<?php else : ?>
				<p><?php echo $deltora_email_t( 'L’EBITDA medio non consente di applicare in modo significativo il metodo dei multipli. Deltora potrà valutare l’azienda con un approfondimento professionale.' ); ?></p>
			<?php endif; ?>
			<p style="font-size:13px;color:#505853;"><?php echo $deltora_email_t( 'Il risultato rappresenta una prima indicazione del valore operativo dell’azienda (Enterprise Value). Non include automaticamente debiti finanziari o liquidità e non costituisce una perizia, un’offerta di acquisto o una valutazione professionale definitiva.' ); ?><?php if ( $data['estimable'] ) : ?> <?php echo $deltora_email_t( 'L’intervallo applicato ha finalità orientativa.' ); ?><?php endif; ?></p>
			<p><a href="<?php echo esc_url( $deltora_contact_url ); ?>" style="color:#356600;font-weight:700;"><?php echo $deltora_email_t( 'Richiedi una valutazione approfondita a Deltora' ); ?></a></p>
		</div>
	</div>
</body>
</html>
