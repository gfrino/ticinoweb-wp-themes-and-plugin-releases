(function initDeltoraContactForm() {
	'use strict';

	const form = document.querySelector('[data-contact-form]');
	const config = window.deltoraContactConfig || {};

	if (!form || !config.ajaxUrl || !config.nonce) {
		return;
	}

	const feedback = form.querySelector('[data-contact-feedback]');
	const submit = form.querySelector('[type="submit"]');
	const submitLabel = submit ? submit.querySelector('[data-submit-label]') : null;
	const defaultLabel = submitLabel ? submitLabel.textContent : '';
	const message = form.elements.message;

	try {
		const storageKey = 'deltoraConfiguratorContactDraft';
		const windowNamePrefix = `${storageKey}:`;
		let rawDraft = '';
		try {
			rawDraft = window.sessionStorage.getItem(storageKey) || '';
			window.sessionStorage.removeItem(storageKey);
		} catch (error) {
			// Continue with the navigation-scoped fallback below.
		}
		if (!rawDraft && window.name.startsWith(windowNamePrefix)) {
			rawDraft = window.name.slice(windowNamePrefix.length);
			window.name = '';
		}
		if (rawDraft && message && !message.value.trim()) {
			const draft = JSON.parse(rawDraft);
			const isRecent = Number.isFinite(Number(draft.createdAt))
				&& Date.now() - Number(draft.createdAt) <= 30 * 60 * 1000;
			if (isRecent && typeof draft.message === 'string') {
				message.value = draft.message.slice(0, 3000);
			}
		}
	} catch (error) {
		// The form remains fully usable when temporary browser storage is unavailable.
	}

	form.addEventListener('submit', async (event) => {
		event.preventDefault();
		if (!form.reportValidity() || !submit) {
			return;
		}

		submit.disabled = true;
		form.setAttribute('aria-busy', 'true');
		feedback.textContent = '';
		feedback.removeAttribute('data-state');
		if (submitLabel) {
			submitLabel.textContent = 'Invio in corso…';
		}

		const payload = new FormData(form);
		payload.append('action', 'deltora_send_contact_request');
		payload.append('nonce', config.nonce);

		try {
			const response = await fetch(config.ajaxUrl, {
				method: 'POST',
				body: payload,
				credentials: 'same-origin',
			});
			const result = await response.json();
			const message = result && result.data && result.data.message
				? result.data.message
				: 'Non è stato possibile inviare la richiesta.';

			feedback.textContent = message;
			feedback.dataset.state = result.success ? 'success' : 'error';
			if (result.success) {
				form.reset();
			}
		} catch (error) {
			feedback.textContent = 'La connessione si è interrotta. Riprova oppure contattaci direttamente via email.';
			feedback.dataset.state = 'error';
		} finally {
			submit.disabled = false;
			form.removeAttribute('aria-busy');
			if (submitLabel) {
				submitLabel.textContent = defaultLabel;
			}
		}
	});
})();
