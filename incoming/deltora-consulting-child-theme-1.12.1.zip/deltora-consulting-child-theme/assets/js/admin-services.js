(function () {
	'use strict';

	const config = window.deltoraServiceAdmin || { content: {} };
	const content = config.content && typeof config.content === 'object' ? config.content : {};
	const labels = config.labels && typeof config.labels === 'object' ? config.labels : {};

	function createRow(labelText, control) {
		const row = document.createElement('tr');
		row.className = 'deltora-service-field';

		const heading = document.createElement('th');
		heading.scope = 'row';
		const label = document.createElement('label');
		label.textContent = labelText;
		heading.appendChild(label);

		const cell = document.createElement('td');
		cell.appendChild(control);
		row.append(heading, cell);

		return row;
	}

	function createInput(name, value, placeholder) {
		const input = document.createElement('input');
		input.type = 'text';
		input.name = name;
		input.value = value || '';
		input.placeholder = placeholder;
		input.className = 'regular-text';
		return input;
	}

	function createTextarea(name, value, placeholder, rows) {
		const textarea = document.createElement('textarea');
		textarea.name = name;
		textarea.value = value || '';
		textarea.placeholder = placeholder;
		textarea.className = 'large-text';
		textarea.rows = rows;
		return textarea;
	}

	function slugify(value) {
		return String(value || '')
			.normalize('NFD')
			.replace(/[\u0300-\u036f]/g, '')
			.toLowerCase()
			.replace(/[^a-z0-9]+/g, '-')
			.replace(/^-+|-+$/g, '');
	}

	function persistNewSlugs(container) {
		const used = new Set();
		container.querySelectorAll('.service-item').forEach(function (item, index) {
			const slugInput = item.querySelector('input[name^="deltora_service_content"][name$="[slug]"]');
			const titleInput = item.querySelector('input[name^="ticinoweb_services"][name$="[title]"]');
			if (!slugInput) {
				return;
			}

			if (slugInput.value) {
				used.add(slugInput.value);
				return;
			}

			const base = slugify(titleInput ? titleInput.value : '') || `servizio-${index + 1}`;
			let slug = base;
			let suffix = 2;
			while (used.has(slug)) {
				slug = `${base}-${suffix}`;
				suffix += 1;
			}
			slugInput.value = slug;
			used.add(slug);
		});
	}

	function enhanceService(item) {
		if (item.dataset.deltoraFieldsReady === 'true') {
			return;
		}

		const idInput = item.querySelector('input[type="hidden"][name$="[id]"]');
		const table = item.querySelector('.service-fields table.form-table');
		if (!idInput || !table || !idInput.value) {
			return;
		}

		const serviceId = idInput.value;
		const fields = content[serviceId] || {};
		const prefix = `deltora_service_content[${serviceId}]`;
		const description = item.querySelector('textarea[name^="ticinoweb_services"][name$="[description]"]');
		if (description && !item.querySelector('.deltora-service-description-hint')) {
			const descriptionHint = document.createElement('p');
			descriptionHint.className = 'description deltora-service-description-hint';
			descriptionHint.textContent = labels.description_hint || 'Testo esteso mostrato nella pagina Servizi.';
			description.insertAdjacentElement('afterend', descriptionHint);
		}

		const slug = document.createElement('input');
		slug.type = 'hidden';
		slug.name = `${prefix}[slug]`;
		slug.value = fields.slug || '';
		const categoryRow = createRow(labels.category || 'Categoria Home', createInput(
			`${prefix}[category]`,
			fields.category || '',
			labels.category_placeholder || 'Sviluppo & Presenza'
		));
		categoryRow.querySelector('td').appendChild(slug);
		table.appendChild(categoryRow);
		table.appendChild(createRow(labels.summary || 'Sintesi Home', createTextarea(
			`${prefix}[summary]`,
			fields.summary || '',
			labels.summary_placeholder || 'Testo breve mostrato nella card della Home',
			3
		)));
		table.appendChild(createRow(labels.details || 'Punti di dettaglio', createTextarea(
			`${prefix}[details_text]`,
			Array.isArray(fields.details) ? fields.details.join('\n') : '',
			labels.details_placeholder || 'Un punto per riga',
			4
		)));
		item.dataset.deltoraFieldsReady = 'true';
	}

	function enhanceAll() {
		document.querySelectorAll('#services-container .service-item').forEach(enhanceService);
	}

	document.addEventListener('DOMContentLoaded', function () {
		const container = document.getElementById('services-container');
		if (!container) {
			return;
		}

		enhanceAll();
		new MutationObserver(enhanceAll).observe(container, { childList: true, subtree: true });
		const form = container.closest('form');
		if (form) {
			form.addEventListener('submit', function () {
				persistNewSlugs(container);
			});
		}
	});
}());
