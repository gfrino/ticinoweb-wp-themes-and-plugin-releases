'use strict';

document.addEventListener('DOMContentLoaded', () => {
  const entry = document.querySelector('[data-configurator-entry]');
  if (!entry) return;

  const modeInputs = Array.from(entry.querySelectorAll('input[name="mode"]'));
  const submit = entry.querySelector('[data-configurator-entry-submit]');
  const updateEntryState = () => {
    if (submit) submit.disabled = !modeInputs.some((input) => input.checked);
  };

  modeInputs.forEach((input) => input.addEventListener('change', updateEntryState));
  updateEntryState();
});
