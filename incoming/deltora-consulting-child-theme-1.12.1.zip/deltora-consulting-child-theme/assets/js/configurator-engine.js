(function initDeltoraConfiguratorEngine(root, factory) {
  const engine = factory();

  if (typeof module === 'object' && module.exports) {
    module.exports = engine;
  }

  if (root) {
    root.DeltoraConfiguratorEngine = engine;
  }
}(typeof window !== 'undefined' ? window : globalThis, function createEngine() {
  'use strict';

  const toFiniteNumber = (value) => {
    const parsed = typeof value === 'number' ? value : Number(value);
    return Number.isFinite(parsed) ? parsed : 0;
  };

  const parseMoney = (value) => {
    if (typeof value === 'number') return Number.isFinite(value) ? value : null;
    if (typeof value !== 'string' || value.trim() === '') return null;

    let normalized = value
      .trim()
      .replace(/CHF/gi, '')
      .replace(/[’'\s]/g, '')
      .replace(/[^0-9,.-]/g, '');

    if (!normalized || !/[0-9]/.test(normalized)) return null;

    const commaIndex = normalized.lastIndexOf(',');
    const dotIndex = normalized.lastIndexOf('.');

    if (commaIndex !== -1 && dotIndex !== -1) {
      const decimalSeparator = commaIndex > dotIndex ? ',' : '.';
      const thousandsSeparator = decimalSeparator === ',' ? /\./g : /,/g;
      normalized = normalized.replace(thousandsSeparator, '');
      normalized = normalized.replace(decimalSeparator, '.');
    } else {
      const separator = commaIndex !== -1 ? ',' : (dotIndex !== -1 ? '.' : '');
      if (separator) {
        const parts = normalized.split(separator);
        const looksLikeThousands = parts.length > 1 && parts.slice(1).every((part) => part.length === 3);
        normalized = looksLikeThousands
          ? parts.join('')
          : `${parts.slice(0, -1).join('')}.${parts.at(-1)}`;
      }
    }

    const parsed = Number(normalized);
    return Number.isFinite(parsed) ? parsed : null;
  };

  const calculateAnnualEbitda = (values) => (
    toFiniteNumber(values.netIncome)
    + toFiniteNumber(values.taxes)
    + toFiniteNumber(values.financialCosts)
    - toFiniteNumber(values.financialIncome)
    + toFiniteNumber(values.tangibleDepreciation)
    + toFiniteNumber(values.intangibleAmortization)
    + toFiniteNumber(values.impairments)
  );

  const roundEstimate = (value) => Math.round(value / 1000) * 1000;

  const calculateEstimate = (ebitdas, minMultiple, maxMultiple) => {
    const values = Array.isArray(ebitdas) ? ebitdas.map(toFiniteNumber) : [];
    const average = values.length === 3
      ? values.reduce((sum, value) => sum + value, 0) / 3
      : 0;

    if (average <= 0 || !Number.isFinite(minMultiple) || !Number.isFinite(maxMultiple)) {
      return { average, minimum: null, maximum: null, estimable: false };
    }

    return {
      average,
      minimum: roundEstimate(average * minMultiple),
      maximum: roundEstimate(average * maxMultiple),
      estimable: true,
    };
  };

  const formatCHF = (value) => {
    const rounded = Math.round(toFiniteNumber(value));
    const sign = rounded < 0 ? '-' : '';
    const digits = String(Math.abs(rounded)).replace(/\B(?=(\d{3})+(?!\d))/g, "'");
    return `CHF ${sign}${digits}`;
  };

  return {
    parseMoney,
    calculateAnnualEbitda,
    calculateEstimate,
    formatCHF,
  };
}));
