(function () {
	'use strict';

	var config = window.deltoraConsentConfig || {};
	var consentCookie = config.consentCookie || 'deltora_cookie_consent';
	var preferencesCookie = config.preferencesCookie || 'deltora_cookie_preferences';
	var cookiePath = config.cookiePath || '/';
	var cookieLifetime = Number(config.cookieLifetime || 31536000);
	var secureAttribute = config.secure ? '; Secure' : '';
	var banner;
	var modal;
	var dialog;
	var mapsSwitch;
	var returnFocus;

	function readCookie(name) {
		var escaped = name.replace(/([.*+?^${}()|[\]\\])/g, '\\$1');
		var match = document.cookie.match('(?:^|; )' + escaped + '=([^;]*)');

		return match ? decodeURIComponent(match[1]) : null;
	}

	function readPreferences() {
		try {
			return JSON.parse(readCookie(preferencesCookie) || '{}');
		} catch (error) {
			return {};
		}
	}

	function mapsAllowed() {
		var consent = readCookie(consentCookie);

		if ('accepted' === consent) {
			return true;
		}

		return 'custom' === consent && true === readPreferences().externalContent;
	}

	function writeCookie(name, value) {
		document.cookie = name + '=' + encodeURIComponent(value)
			+ '; path=' + cookiePath
			+ '; max-age=' + cookieLifetime
			+ '; SameSite=Lax'
			+ secureAttribute;
	}

	function saveConsent(value, externalContent) {
		writeCookie(consentCookie, value);
		writeCookie(preferencesCookie, JSON.stringify({ externalContent: Boolean(externalContent) }));
		applyMapPreference(Boolean(externalContent));
		hideBanner();
		closeModal();
		document.dispatchEvent(new CustomEvent('deltora:consent-change', {
			detail: { externalContent: Boolean(externalContent) },
		}));
	}

	function createMapFrame(container) {
		if (container.querySelector('iframe') || !container.dataset.mapSrc) {
			return;
		}

		var frame = document.createElement('iframe');
		frame.title = container.dataset.mapTitle || 'Mappa Google';
		frame.src = container.dataset.mapSrc;
		frame.loading = 'lazy';
		frame.referrerPolicy = 'strict-origin-when-cross-origin';
		frame.allowFullscreen = true;
		frame.setAttribute('data-consent-map-frame', '');
		container.appendChild(frame);
	}

	function applyMapPreference(allowed) {
		document.querySelectorAll('[data-consent-map]').forEach(function (container) {
			var placeholder = container.querySelector('[data-map-placeholder]');
			var frame = container.querySelector('[data-consent-map-frame]');

			if (allowed) {
				if (placeholder) {
					placeholder.hidden = true;
				}
				createMapFrame(container);
				return;
			}

			if (frame) {
				frame.remove();
			}
			if (placeholder) {
				placeholder.hidden = false;
			}
		});
	}

	function showBanner() {
		if (banner) {
			banner.hidden = false;
		}
	}

	function hideBanner() {
		if (banner) {
			banner.hidden = true;
		}
	}

	function focusableElements() {
		if (!dialog) {
			return [];
		}

		return Array.prototype.slice.call(dialog.querySelectorAll(
			'button:not([disabled]), input:not([disabled]), a[href], [tabindex]:not([tabindex="-1"])'
		));
	}

	function trapFocus(event) {
		var focusable;
		var first;
		var last;

		if (!modal || modal.hidden) {
			return;
		}

		if ('Escape' === event.key) {
			closeModal();
			return;
		}

		if ('Tab' !== event.key) {
			return;
		}

		focusable = focusableElements();
		if (!focusable.length) {
			event.preventDefault();
			dialog.focus();
			return;
		}

		first = focusable[0];
		last = focusable[focusable.length - 1];

		if (event.shiftKey && document.activeElement === first) {
			event.preventDefault();
			last.focus();
		} else if (!event.shiftKey && document.activeElement === last) {
			event.preventDefault();
			first.focus();
		}
	}

	function openModal(trigger) {
		if (!modal || !dialog) {
			return;
		}

		returnFocus = trigger || document.activeElement;
		mapsSwitch.checked = mapsAllowed();
		modal.hidden = false;
		document.body.classList.add('deltora-cookie-modal-open');
		document.addEventListener('keydown', trapFocus);
		window.requestAnimationFrame(function () {
			dialog.focus();
		});
	}

	function closeModal() {
		if (!modal || modal.hidden) {
			return;
		}

		modal.hidden = true;
		document.body.classList.remove('deltora-cookie-modal-open');
		document.removeEventListener('keydown', trapFocus);
		if (returnFocus && 'function' === typeof returnFocus.focus) {
			returnFocus.focus();
		}
	}

	function bindControls() {
		document.querySelectorAll('[data-cookie-preferences-open]').forEach(function (button) {
			button.addEventListener('click', function () {
				openModal(button);
			});
		});

		document.querySelectorAll('[data-cookie-close]').forEach(function (control) {
			control.addEventListener('click', closeModal);
		});

		banner.querySelector('[data-cookie-reject]').addEventListener('click', function () {
			saveConsent('declined', false);
		});
		banner.querySelector('[data-cookie-customize]').addEventListener('click', function (event) {
			openModal(event.currentTarget);
		});
		banner.querySelector('[data-cookie-accept]').addEventListener('click', function () {
			saveConsent('accepted', true);
		});
		modal.querySelector('[data-cookie-necessary]').addEventListener('click', function () {
			saveConsent('declined', false);
		});
		modal.querySelector('[data-cookie-save]').addEventListener('click', function () {
			saveConsent('custom', mapsSwitch.checked);
		});
	}

	function initialize() {
		banner = document.getElementById('deltora-cookie-banner');
		modal = document.getElementById('deltora-cookie-modal');
		dialog = modal ? modal.querySelector('.deltora-cookie-modal__dialog') : null;
		mapsSwitch = document.getElementById('deltora-cookie-maps');

		if (!banner || !modal || !dialog || !mapsSwitch) {
			return;
		}

		bindControls();
		applyMapPreference(mapsAllowed());

		if (!readCookie(consentCookie)) {
			showBanner();
		}
	}

	if ('loading' === document.readyState) {
		document.addEventListener('DOMContentLoaded', initialize);
	} else {
		initialize();
	}
}());
