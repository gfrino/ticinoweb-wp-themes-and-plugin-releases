'use strict';

(function motionModule(root, factory) {
  const api = factory();

  if (typeof module === 'object' && module.exports) module.exports = api;

  if (root && root.document) {
    root.document.addEventListener('DOMContentLoaded', () => {
      api.mountMotion({
        document: root.document,
        window: root,
        gsap: root.gsap,
        ScrollTrigger: root.ScrollTrigger,
      });
    });
  }
}(typeof window !== 'undefined' ? window : null, () => {
  const cappedDelay = (element) => {
    const requested = Number.parseInt(element.dataset.motionDelay || '0', 10);
    if (!Number.isFinite(requested)) return 0;
    return Math.min(180, Math.max(0, requested)) / 1000;
  };

  const scrollTriggerFor = (element, start = 'top 88%') => ({
    trigger: element,
    start,
    once: true,
  });

  const animateHomeTarget = (element, gsap) => {
    const isMedia = element.dataset.motion === 'section-media';
    const from = isMedia
      ? { autoAlpha: 0.72, scale: 0.988 }
      : { autoAlpha: 0, y: 16 };

    gsap.fromTo(element, from, {
      autoAlpha: 1,
      y: 0,
      scale: 1,
      duration: 0.52,
      delay: cappedDelay(element),
      ease: 'power3.out',
      clearProps: 'opacity,visibility,transform',
      scrollTrigger: scrollTriggerFor(element),
    });
  };

  const animateServiceChapter = (element, gsap) => {
    gsap.fromTo(element, { autoAlpha: 0.55, y: 28 }, {
      autoAlpha: 1,
      y: 0,
      duration: 0.7,
      ease: 'power3.out',
      clearProps: 'opacity,visibility,transform',
      scrollTrigger: scrollTriggerFor(element, 'top 92%'),
    });
  };

  const mountMotion = ({ document, window, gsap, ScrollTrigger }) => {
    if (!document || !window || !gsap || !ScrollTrigger) return;
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;

    gsap.registerPlugin(ScrollTrigger);

    const homeTargets = Array.from(document.querySelectorAll(
      '.deltora-home [data-motion]:not([data-motion="hero-media"]):not([data-motion="hero-copy"])',
    ));
    const serviceChapters = Array.from(document.querySelectorAll('.deltora-services-chapter__grid'));

    homeTargets.forEach((element) => animateHomeTarget(element, gsap));
    serviceChapters.forEach((element) => animateServiceChapter(element, gsap));
  };

  return { mountMotion };
}));
