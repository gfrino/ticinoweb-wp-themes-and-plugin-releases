(() => {
  'use strict';

  document.addEventListener('DOMContentLoaded', () => {
    const header = document.querySelector('[data-site-header]');

    if (header) {
      let scrollFramePending = false;

      const updateHeaderDensity = () => {
        header.classList.toggle('is-compact', window.scrollY > 24);
        scrollFramePending = false;
      };

      updateHeaderDensity();
      window.addEventListener('scroll', () => {
        if (scrollFramePending) {
          return;
        }

        scrollFramePending = true;
        window.requestAnimationFrame(updateHeaderDensity);
      }, { passive: true });
    }

    const toggle = document.querySelector('.menu-toggle');
    const navigation = document.querySelector('#deltora-primary-navigation');

    if (!toggle || !navigation) {
      return;
    }

    const closeMenu = (restoreFocus = false) => {
      toggle.setAttribute('aria-expanded', 'false');
      navigation.dataset.open = 'false';

      if (restoreFocus) {
        toggle.focus();
      }
    };

    toggle.addEventListener('click', () => {
      const isOpen = toggle.getAttribute('aria-expanded') === 'true';
      toggle.setAttribute('aria-expanded', String(!isOpen));
      navigation.dataset.open = String(!isOpen);
    });

    navigation.querySelectorAll('a').forEach((link) => {
      link.addEventListener('click', () => closeMenu());
    });

    document.addEventListener('keydown', (event) => {
      if (event.key === 'Escape' && toggle.getAttribute('aria-expanded') === 'true') {
        closeMenu(true);
      }
    });

    const desktopQuery = window.matchMedia('(min-width: 64rem)');
    const handleDesktopChange = (event) => {
      if (event.matches) {
        closeMenu();
      }
    };

    if (typeof desktopQuery.addEventListener === 'function') {
      desktopQuery.addEventListener('change', handleDesktopChange);
    } else if (typeof desktopQuery.addListener === 'function') {
      desktopQuery.addListener(handleDesktopChange);
    }
  });
})();
