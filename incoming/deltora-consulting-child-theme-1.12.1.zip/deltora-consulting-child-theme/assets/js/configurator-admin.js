(function initDeltoraConfiguratorAdmin() {
  'use strict';

  const form = document.querySelector('[data-sector-admin-form]');
  if (!form) return;

  const rows = form.querySelector('[data-sector-rows]');
  const template = document.querySelector('[data-sector-template]');

  const reindex = () => {
    const editableRows = Array.from(rows.querySelectorAll('[data-sector-row]'));
    editableRows.forEach((row, index) => {
      row.querySelectorAll('[data-sector-field]').forEach((field) => {
        field.name = `sectors[${index}][${field.dataset.sectorField}]`;
      });
      const hiddenEnabled = row.querySelector('[data-sector-enabled-hidden]');
      if (hiddenEnabled) hiddenEnabled.name = `sectors[${index}][enabled]`;
    });
  };

  const fallbackRow = () => rows.querySelector('[data-sector-id="other"]');

  form.addEventListener('click', (event) => {
    const button = event.target.closest('button');
    if (!button) return;
    const row = button.closest('[data-sector-row]');

    if (button.matches('[data-sector-add]') && template) {
      const fragment = template.content.cloneNode(true);
      rows.insertBefore(fragment, fallbackRow());
      reindex();
      rows.querySelectorAll('[data-sector-row]')[rows.querySelectorAll('[data-sector-row]').length - 2]?.querySelector('[data-sector-field="label"]')?.focus();
      return;
    }

    if (!row || row.dataset.sectorId === 'other') return;
    if (button.matches('[data-sector-remove]')) row.remove();
    if (button.matches('[data-sector-move-up]') && row.previousElementSibling) rows.insertBefore(row, row.previousElementSibling);
    if (button.matches('[data-sector-move-down]') && row.nextElementSibling && row.nextElementSibling.dataset.sectorId !== 'other') rows.insertBefore(row.nextElementSibling, row);
    reindex();
  });

  reindex();
}());
