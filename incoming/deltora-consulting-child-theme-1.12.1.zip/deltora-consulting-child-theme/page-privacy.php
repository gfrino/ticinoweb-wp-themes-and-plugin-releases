<?php
/**
 * Privacy policy page template.
 *
 * Title, hero introduction and policy body are authored in the native
 * WordPress page editor. The visual shell and generated section index remain
 * controlled by the theme.
 *
 * @package DeltoraConsultingChildTheme
 */

get_header();

while ( have_posts() ) :
	the_post();

	$deltora_privacy_lead = trim( get_the_excerpt() );
	if ( '' === $deltora_privacy_lead ) {
		$deltora_privacy_lead = deltora_consulting_get_default_privacy_excerpt();
	}

	$deltora_privacy_content = trim( get_the_content() );
	if ( '' === $deltora_privacy_content ) {
		$deltora_privacy_content = deltora_consulting_get_default_privacy_content();
	}

	$deltora_privacy_content  = apply_filters( 'the_content', $deltora_privacy_content );
	$deltora_privacy_content  = deltora_consulting_prepare_privacy_content( $deltora_privacy_content );
	$deltora_privacy_sections = deltora_consulting_get_privacy_sections( $deltora_privacy_content );
	?>

	<main id="main-content" class="site-main deltora-privacy-page">
		<header class="deltora-privacy-page__hero">
			<div class="deltora-container">
				<h1><?php the_title(); ?></h1>
				<p class="deltora-privacy-page__lead"><?php echo esc_html( $deltora_privacy_lead ); ?></p>
				<p class="deltora-privacy-page__updated">
					<?php
					printf(
						/* translators: %s: date of the latest Privacy page update. */
						esc_html__( 'Ultimo aggiornamento: %s', 'deltora-consulting-child-theme' ),
						esc_html( get_the_modified_date( 'j F Y' ) )
					);
					?>
				</p>
			</div>
		</header>

		<div class="deltora-container deltora-privacy-page__layout">
			<?php if ( ! empty( $deltora_privacy_sections ) ) : ?>
				<nav class="deltora-privacy-page__index" aria-label="<?php esc_attr_e( 'Indice dell’informativa sulla protezione dei dati', 'deltora-consulting-child-theme' ); ?>">
					<p><?php esc_html_e( 'In questa pagina', 'deltora-consulting-child-theme' ); ?></p>
					<ol>
						<?php foreach ( $deltora_privacy_sections as $deltora_privacy_section ) : ?>
							<li>
								<a href="#<?php echo esc_attr( $deltora_privacy_section['id'] ); ?>">
									<?php echo esc_html( $deltora_privacy_section['label'] ); ?>
								</a>
							</li>
						<?php endforeach; ?>
					</ol>
				</nav>
			<?php endif; ?>

			<article class="deltora-privacy-page__content">
				<?php
				// The content has already passed through WordPress's standard content filters.
				echo $deltora_privacy_content; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				?>
			</article>
		</div>
	</main>

	<?php
endwhile;

get_footer();
