<?php
/**
 * EBITDA configurator page template.
 *
 * @package DeltoraConsultingChildTheme
 */

$deltora_requested_mode = isset( $_GET['mode'] ) ? sanitize_key( wp_unslash( $_GET['mode'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
$deltora_initial_mode   = in_array( $deltora_requested_mode, array( 'guided', 'direct' ), true ) ? $deltora_requested_mode : '';

get_header();
?>

<main id="main-content" class="site-main deltora-configurator-page">
	<section class="deltora-configurator-hero" aria-labelledby="deltora-configurator-page-title">
		<div class="deltora-container deltora-configurator-hero__grid">
			<div data-motion="page-heading">
				<h1 id="deltora-configurator-page-title"><?php esc_html_e( 'Stima il valore operativo della tua azienda', 'deltora-consulting-child-theme' ); ?></h1>
				<p><?php esc_html_e( 'Il percorso elabora una stima indicativa a partire dai dati disponibili e dal settore di attività.', 'deltora-consulting-child-theme' ); ?></p>
			</div>
			<aside class="deltora-configurator-hero__requirements" data-motion="section-copy" data-motion-delay="80" aria-label="<?php esc_attr_e( 'Cosa serve', 'deltora-consulting-child-theme' ); ?>">
				<h2><?php esc_html_e( 'Prima di iniziare', 'deltora-consulting-child-theme' ); ?></h2>
				<ul>
					<li><?php esc_html_e( 'Gli ultimi tre esercizi completi', 'deltora-consulting-child-theme' ); ?></li>
					<li><?php esc_html_e( 'I tre EBITDA oppure i relativi dati contabili', 'deltora-consulting-child-theme' ); ?></li>
					<li><?php esc_html_e( 'Circa 5–10 minuti per il percorso guidato', 'deltora-consulting-child-theme' ); ?></li>
				</ul>
				<p><?php esc_html_e( 'I dati restano nel browser durante il calcolo e non vengono salvati automaticamente.', 'deltora-consulting-child-theme' ); ?></p>
			</aside>
		</div>
	</section>

	<section class="deltora-configurator-workspace" aria-labelledby="deltora-configurator-workspace-title">
		<div class="deltora-container">
			<div id="deltora-configurator-start" class="deltora-configurator-app" data-motion="workspace" data-configurator-root data-initial-mode="<?php echo esc_attr( $deltora_initial_mode ); ?>">
				<div class="deltora-configurator-app__topbar">
					<div>
						<span class="deltora-configurator-app__step" data-configurator-step><?php esc_html_e( 'Preparazione', 'deltora-consulting-child-theme' ); ?></span>
						<h2 id="deltora-configurator-workspace-title"><?php esc_html_e( 'Il valore della tua impresa', 'deltora-consulting-child-theme' ); ?></h2>
					</div>
					<button class="deltora-configurator-app__change" type="button" data-change-mode hidden><?php esc_html_e( 'Cambia modalità', 'deltora-consulting-child-theme' ); ?></button>
				</div>
				<div class="deltora-configurator-app__progress" aria-hidden="true"><span data-configurator-progress></span></div>
				<div class="deltora-configurator-app__messages" data-configurator-messages aria-live="polite"></div>
				<div class="deltora-configurator-app__body" data-configurator-view>
					<p><?php esc_html_e( 'Caricamento del percorso…', 'deltora-consulting-child-theme' ); ?></p>
				</div>
				<noscript><p class="deltora-configurator-app__noscript"><?php esc_html_e( 'Per utilizzare il percorso è necessario attivare JavaScript nel browser.', 'deltora-consulting-child-theme' ); ?></p></noscript>
			</div>
		</div>
	</section>
</main>

<?php
get_footer();
