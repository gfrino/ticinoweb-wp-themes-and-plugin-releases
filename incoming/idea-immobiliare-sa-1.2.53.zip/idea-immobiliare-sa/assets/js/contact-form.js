/**
 * Moduli "Richiedi informazioni": validazione e invio al gestore AJAX del
 * parent (ticinoweb-ai-theme/inc/form-handler.php): salvataggio in "Invii
 * Ricevuti", reCAPTCHA v3 se configurato, email al destinatario del CMS.
 */
(function () {
  'use strict';

  var forms = document.querySelectorAll('.idea-form');
  if (!forms.length) return;

  var cfg = window.ticinoweb_ai_main || {};
  var recaptchaReady = null;

  function loadRecaptcha() {
    if (recaptchaReady || !cfg.recaptcha_site_key) return;
    recaptchaReady = new Promise(function (resolve) {
      var s = document.createElement('script');
      s.src = 'https://www.google.com/recaptcha/api.js?render=' + encodeURIComponent(cfg.recaptcha_site_key);
      s.async = true;
      s.onload = resolve;
      s.onerror = resolve;
      document.head.appendChild(s);
    });
  }

  function recaptchaToken() {
    if (!cfg.recaptcha_site_key) return Promise.resolve('');
    loadRecaptcha();
    return recaptchaReady.then(function () {
      if (!window.grecaptcha || !grecaptcha.execute) return '';
      return new Promise(function (resolve) {
        grecaptcha.ready(function () {
          grecaptcha.execute(cfg.recaptcha_site_key, { action: 'contact' }).then(resolve, function () { resolve(''); });
        });
      });
    });
  }

  function formToken() {
    return fetch(cfg.ajax_url + '?action=' + encodeURIComponent(cfg.token_action || 'ticinoweb_form_token'), {
      credentials: 'same-origin',
      cache: 'no-store'
    }).then(function (r) { return r.json(); }).then(function (d) {
      return d && d.success && d.data ? d.data.token : '';
    });
  }

  // il badge reCAPTCHA deve essere visibile nelle pagine con un modulo: si carica a pagina pronta, senza aspettare il primo clic
  if (forms.length) {
    var warm = function () { loadRecaptcha(); };
    if ('requestIdleCallback' in window) { requestIdleCallback(warm, { timeout: 2500 }); } else { setTimeout(warm, 1200); }
  }

  forms.forEach(function (form) {
    var status = form.querySelector('.idea-form__status');
    var button = form.querySelector('button[type="submit"]');
    var label = button ? button.textContent : '';

    form.addEventListener('focusin', loadRecaptcha, { once: true });

    function field(name) { return form.querySelector('[name="' + name + '"]'); }
    function errorEl(name) { return form.querySelector('.idea-form__error[data-for="' + name + '"]'); }
    function setError(name, text) {
      var f = field(name), e = errorEl(name);
      if (f) f.classList.toggle('is-invalid', !!text);
      if (e) e.textContent = text || '';
    }
    function say(text, ok) {
      if (!status) return;
      status.textContent = text || '';
      status.className = 'idea-form__status' + (text ? (ok ? ' is-ok' : ' is-error') : '');
    }
    function busy(on) {
      if (!button) return;
      button.disabled = on;
      button.textContent = on ? 'Invio in corso…' : label;
    }

    form.addEventListener('submit', function (e) {
      e.preventDefault();
      say('');
      var ok = true;
      var nome = field('nome').value.trim();
      var email = field('email').value.trim();
      var msg = field('messaggio').value.trim();
      setError('nome', nome.length < 2 ? 'Inserisci il tuo nome.' : '');
      setError('email', /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) ? '' : 'Inserisci un’email valida.');
      setError('messaggio', msg.length < 5 ? 'Scrivi un messaggio.' : '');
      if (nome.length < 2 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || msg.length < 5) ok = false;
      if (!ok) return;
      if (!cfg.ajax_url) { say('Il modulo non è disponibile al momento. Scrivici via email o chiamaci.', false); return; }

      busy(true);
      Promise.all([formToken(), recaptchaToken()]).then(function (t) {
        var data = new FormData(form);
        data.append('action', cfg.submit_action || 'ticinoweb_submit_form');
        data.append('token', t[0]);
        if (t[1]) data.append('recaptcha_token', t[1]);
        return fetch(cfg.ajax_url, { method: 'POST', body: data, credentials: 'same-origin' })
          .then(function (res) { return res.json(); });
      }).then(function (res) {
        if (res && res.success) {
          form.reset();
          say((res.data && res.data.message) || 'Grazie! Ti risponderemo al più presto.', true);
          return;
        }
        var err = (res && res.data) || {};
        if (err.fields) {
          ['nome', 'email', 'messaggio'].forEach(function (n) { if (err.fields[n]) setError(n, err.fields[n]); });
        }
        say(err.message || 'Invio non riuscito. Riprova o scrivici direttamente via email.', false);
      }).catch(function () {
        say('Invio non riuscito. Riprova o scrivici direttamente via email.', false);
      }).then(function () { busy(false); });
    });
  });
})();
