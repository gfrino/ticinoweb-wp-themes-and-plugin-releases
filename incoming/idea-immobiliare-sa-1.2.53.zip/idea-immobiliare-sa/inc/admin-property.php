<?php
/**
 * Inserimento di immobili e promozioni in bacheca: un'unica schermata a sezioni,
 * campi con lo stesso stile, foto con anteprima e trascinamento, zona e categoria
 * scelte per nome (mai ID). Editor classico per la descrizione, senza blocchi.
 *
 * @package Idea_Immobiliare_SA
 */

if (!defined('ABSPATH')) {
    exit;
}

/** Tipi di contenuto che usano questa schermata. */
function idea_immo_admin_types()
{
    return array('immobile', 'promozione');
}

/* ─────────────────────────────────────────────
   1. EDITOR: classico, essenziale, senza box inutili
   ───────────────────────────────────────────── */
add_filter('use_block_editor_for_post_type', function ($use, $type) {
    return in_array($type, idea_immo_admin_types(), true) ? false : $use;
}, 10, 2);

add_filter('wp_editor_settings', function ($settings, $editor_id) {
    $screen = function_exists('get_current_screen') ? get_current_screen() : null;
    if ($editor_id === 'content' && $screen && in_array($screen->post_type, idea_immo_admin_types(), true)) {
        $settings['media_buttons'] = false;
        $settings['quicktags']     = false;
        $settings['editor_height'] = 320;
        $settings['tinymce']       = array(
            'toolbar1'          => 'bold,italic,bullist,numlist,link,unlink,undo,redo',
            'toolbar2'          => '',
            'statusbar'         => false,
            'wpautop'           => true,
            'content_style'     => 'body{font-family:system-ui,sans-serif;font-size:16px;line-height:1.6;color:#1f2a36}',
        );
    }
    return $settings;
}, 10, 2);

add_filter('enter_title_here', function ($text, $post) {
    if ($post->post_type === 'immobile') {
        return __('Titolo dell’annuncio, es. Appartamento con giardino a Bellinzona', 'idea-immobiliare-sa');
    }
    if ($post->post_type === 'promozione') {
        return __('Nome della promozione, es. Bellinzona – Residenza Cremo', 'idea-immobiliare-sa');
    }
    return $text;
}, 10, 2);

add_action('add_meta_boxes', function ($type) {
    if (!in_array($type, idea_immo_admin_types(), true)) {
        return;
    }
    foreach (array('postimagediv', 'postexcerpt', 'slugdiv', 'postcustom', 'authordiv', 'commentstatusdiv', 'commentsdiv', 'revisionsdiv') as $id) {
        remove_meta_box($id, $type, 'normal');
        remove_meta_box($id, $type, 'side');
        remove_meta_box($id, $type, 'advanced');
    }
}, 99);

/* ─────────────────────────────────────────────
   2. SCHERMATA A SEZIONI (sopra l'editor della descrizione)
   ───────────────────────────────────────────── */
add_action('edit_form_after_title', 'idea_immo_render_form');
function idea_immo_render_form($post)
{
    if (!in_array($post->post_type, idea_immo_admin_types(), true)) {
        return;
    }
    wp_nonce_field('idea_immo_save', 'idea_immo_nonce');
    echo '<div class="idea-ui">';
    if ($post->post_type === 'immobile') {
        idea_immo_ui_property($post);
    } else {
        idea_immo_ui_promo($post);
    }
    echo '</div>';
}

function idea_ui_section_open($title, $desc = '', $num = '')
{
    echo '<section class="idea-card-ui"><header><h2>' . ($num !== '' ? '<span class="idea-card-ui__num">' . esc_html($num) . '</span>' : '') . esc_html($title) . '</h2>';
    if ($desc !== '') {
        echo '<p>' . esc_html($desc) . '</p>';
    }
    echo '</header><div class="idea-card-ui__body">';
}

function idea_ui_section_close()
{
    echo '</div></section>';
}

/** Campo di testo / numero con etichetta, unità e aiuto. */
function idea_ui_input($name, $label, $value, $args = array())
{
    $a = wp_parse_args($args, array('type' => 'text', 'unit' => '', 'help' => '', 'step' => 'any', 'placeholder' => '', 'class' => ''));
    echo '<div class="idea-f ' . esc_attr($a['class']) . '"><label for="' . esc_attr($name) . '">' . esc_html($label) . '</label>';
    echo '<div class="idea-f__control' . ($a['unit'] !== '' ? ' has-unit' : '') . '">';
    echo '<input type="' . ($a['type'] === 'number' ? 'number' : 'text') . '" id="' . esc_attr($name) . '" name="' . esc_attr($name) . '" value="' . esc_attr($value) . '"';
    if ($a['type'] === 'number') {
        echo ' min="0" step="' . esc_attr($a['step']) . '" inputmode="decimal"';
    }
    if ($a['placeholder'] !== '') {
        echo ' placeholder="' . esc_attr($a['placeholder']) . '"';
    }
    echo '>';
    if ($a['unit'] !== '') {
        echo '<span class="idea-f__unit">' . esc_html($a['unit']) . '</span>';
    }
    echo '</div>';
    if ($a['help'] !== '') {
        echo '<small>' . esc_html($a['help']) . '</small>';
    }
    echo '</div>';
}

/** Scelta tra poche opzioni, a pulsanti. */
function idea_ui_segmented($name, $label, $options, $current, $help = '')
{
    echo '<div class="idea-f"><span class="idea-f__label">' . esc_html($label) . '</span><div class="idea-seg" role="radiogroup" aria-label="' . esc_attr($label) . '">';
    foreach ($options as $value => $text) {
        $id = $name . '_' . $value;
        echo '<input type="radio" id="' . esc_attr($id) . '" name="' . esc_attr($name) . '" value="' . esc_attr($value) . '"' . checked($current, $value, false) . '><label for="' . esc_attr($id) . '" class="idea-seg__opt idea-seg__opt--' . esc_attr($value) . '">' . esc_html($text) . '</label>';
    }
    echo '</div>';
    if ($help !== '') {
        echo '<small>' . esc_html($help) . '</small>';
    }
    echo '</div>';
}

/** Selettore di immagini: modalità "gallery" (più foto) o "single" (una). */
function idea_ui_media($name, $ids, $mode, $labels)
{
    $ids = array_values(array_filter(array_map('intval', (array) $ids)));
    echo '<div class="idea-media" data-mode="' . esc_attr($mode) . '" data-title="' . esc_attr($labels['title']) . '" data-button="' . esc_attr($labels['button']) . '">';
    echo '<input type="hidden" name="' . esc_attr($name) . '" value="' . esc_attr(implode(',', $ids)) . '" class="idea-media__input">';
    echo '<ul class="idea-media__list">';
    foreach ($ids as $id) {
        $thumb = wp_get_attachment_image_url($id, 'medium');
        if ($thumb) {
            echo '<li data-id="' . (int) $id . '"><img src="' . esc_url($thumb) . '" alt=""><button type="button" class="idea-media__remove" aria-label="' . esc_attr__('Rimuovi', 'idea-immobiliare-sa') . '">×</button></li>';
        }
    }
    echo '<li class="idea-media__add"><button type="button" class="idea-media__addbtn"><span>+</span>' . esc_html($labels['add']) . '</button></li>';
    echo '</ul>';
    if (!empty($labels['help'])) {
        echo '<small>' . esc_html($labels['help']) . '</small>';
    }
    echo '</div>';
}

function idea_immo_ui_property($post)
{
    $id  = $post->ID;
    $get = function ($key) use ($id) {
        return get_post_meta($id, $key, true);
    };

    // 1. Foto
    idea_ui_section_open(__('Foto', 'idea-immobiliare-sa'), __('La prima foto è la copertina nel catalogo. Trascina le foto per cambiare l’ordine.', 'idea-immobiliare-sa'), '1');
    $gallery = $get('_idea_gallery');
    idea_ui_media('idea_immo_gallery', is_array($gallery) ? $gallery : array(), 'gallery', array(
        'title'  => __('Scegli le foto dell’immobile', 'idea-immobiliare-sa'),
        'button' => __('Usa queste foto', 'idea-immobiliare-sa'),
        'add'    => __('Aggiungi foto', 'idea-immobiliare-sa'),
    ));
    idea_ui_section_close();

    // 2. Annuncio
    idea_ui_section_open(__('Annuncio', 'idea-immobiliare-sa'), __('Cosa stai proponendo e se è ancora disponibile.', 'idea-immobiliare-sa'), '2');
    echo '<div class="idea-grid idea-grid--2">';
    idea_ui_segmented('idea_immo_offer', __('Tipo di offerta', 'idea-immobiliare-sa'), idea_immo_offers(), idea_immo_offer($id));
    idea_ui_segmented('idea_immo_status', __('Stato', 'idea-immobiliare-sa'), array(
        'disponibile' => __('Disponibile', 'idea-immobiliare-sa'),
        'riservato'   => __('Riservato', 'idea-immobiliare-sa'),
        'archivio'    => __('Archivio', 'idea-immobiliare-sa'),
    ), idea_immo_status($id), __('Gli immobili in archivio non compaiono nel catalogo.', 'idea-immobiliare-sa'));
    echo '</div>';
    if (function_exists('idea_gx_opts')) {
        idea_ui_segmented('idea_immo_gx', __('Pubblica su ImmoGalaxy', 'idea-immobiliare-sa'), array('1' => __('Sì', 'idea-immobiliare-sa'), '0' => __('No', 'idea-immobiliare-sa')), (string) get_post_meta($id, '_idea_gx', true) === '0' ? '0' : '1', __('Se l’invio automatico è attivo, l’immobile parte alla notte successiva.', 'idea-immobiliare-sa'));
    }
    idea_ui_input('_idea_ref', __('ID oggetto', 'idea-immobiliare-sa'), $get('_idea_ref'), array('placeholder' => '20208', 'help' => __('Il vostro numero interno: compare nella scheda dell’immobile.', 'idea-immobiliare-sa')));
    idea_ui_section_close();

    // 3. Dove si trova
    idea_ui_section_open(__('Dove si trova', 'idea-immobiliare-sa'), '', '3');
    echo '<div class="idea-grid idea-grid--3">';
    idea_ui_input('_idea_location', __('Località', 'idea-immobiliare-sa'), $get('_idea_location'), array('placeholder' => 'Bellinzona'));
    idea_ui_input('_idea_address', __('Indirizzo', 'idea-immobiliare-sa'), $get('_idea_address'), array('placeholder' => 'Via Mirasole 22'));
    idea_ui_input('_idea_zip', __('NAP', 'idea-immobiliare-sa'), $get('_idea_zip'), array('placeholder' => '6500', 'help' => __('Il codice postale: serve per pubblicare su ImmoGalaxy.', 'idea-immobiliare-sa')));
    idea_ui_input('_idea_canton', __('Cantone', 'idea-immobiliare-sa'), $get('_idea_canton'), array('placeholder' => 'Ticino'));
    $zones = get_terms(array('taxonomy' => 'zona', 'hide_empty' => false));
    $cur_zone = wp_get_object_terms($id, 'zona', array('fields' => 'ids'));
    echo '<div class="idea-f"><label for="idea_zona">' . esc_html__('Zona', 'idea-immobiliare-sa') . '</label><div class="idea-f__control"><select id="idea_zona" name="idea_zona"><option value="">' . esc_html__('Scegli la zona', 'idea-immobiliare-sa') . '</option>';
    if (!is_wp_error($zones)) {
        foreach ($zones as $t) {
            echo '<option value="' . (int) $t->term_id . '"' . selected(in_array($t->term_id, (array) $cur_zone, true), true, false) . '>' . esc_html($t->name) . '</option>';
        }
    }
    echo '</select></div></div></div>';
    $cats = get_terms(array('taxonomy' => 'categoria_immobile', 'hide_empty' => false));
    $cur_cats = wp_get_object_terms($id, 'categoria_immobile', array('fields' => 'ids'));
    echo '<div class="idea-f"><span class="idea-f__label">' . esc_html__('Categoria', 'idea-immobiliare-sa') . '</span><div class="idea-pills">';
    if (!is_wp_error($cats)) {
        foreach ($cats as $t) {
            echo '<label class="idea-pill"><input type="checkbox" name="idea_cat[]" value="' . (int) $t->term_id . '"' . checked(in_array($t->term_id, (array) $cur_cats, true), true, false) . '><span>' . esc_html($t->name) . '</span></label>';
        }
    }
    echo '</div><small>' . esc_html__('Puoi sceglierne più di una. Per aggiungere zone o categorie: Immobili → Zone / Categorie.', 'idea-immobiliare-sa') . '</small></div>';
    idea_ui_section_close();

    // 4. Prezzo e dimensioni
    idea_ui_section_open(__('Prezzo e dimensioni', 'idea-immobiliare-sa'), __('Lascia vuoto ciò che non serve: non verrà mostrato.', 'idea-immobiliare-sa'), '4');
    echo '<div class="idea-grid idea-grid--3">';
    idea_ui_input('_idea_price', __('Prezzo', 'idea-immobiliare-sa'), $get('_idea_price'), array('type' => 'number', 'unit' => 'CHF', 'step' => '1', 'placeholder' => '890000', 'help' => __('Vuoto = «prezzo su richiesta».', 'idea-immobiliare-sa'), 'class' => 'idea-f--price'));
    idea_ui_input('_idea_rooms', __('Numero locali', 'idea-immobiliare-sa'), $get('_idea_rooms'), array('type' => 'number', 'step' => '0.5', 'placeholder' => '4.5'));
    idea_ui_input('_idea_surface', __('Superficie abitabile', 'idea-immobiliare-sa'), $get('_idea_surface'), array('type' => 'number', 'unit' => 'm²'));
    idea_ui_input('_idea_land', __('Terreno', 'idea-immobiliare-sa'), $get('_idea_land'), array('type' => 'number', 'unit' => 'm²'));
    idea_ui_input('_idea_garden', __('Giardino', 'idea-immobiliare-sa'), $get('_idea_garden'), array('type' => 'number', 'unit' => 'm²'));
    idea_ui_input('_idea_terrace', __('Terrazzo/i', 'idea-immobiliare-sa'), $get('_idea_terrace'), array('type' => 'number', 'unit' => 'm²'));
    echo '</div><p class="idea-price-preview" aria-live="polite"></p>';
    idea_ui_section_close();

    // 5. Altri dati
    idea_ui_section_open(__('Altri dati', 'idea-immobiliare-sa'), '', '5');
    echo '<div class="idea-grid idea-grid--3">';
    idea_ui_input('_idea_availability', __('Disponibilità', 'idea-immobiliare-sa'), $get('_idea_availability'), array('placeholder' => __('Subito / Da concordare', 'idea-immobiliare-sa')));
    idea_ui_input('_idea_transport', __('Trasporti pubblici', 'idea-immobiliare-sa'), $get('_idea_transport'), array('placeholder' => '300 m'));
    idea_ui_input('_idea_shops', __('Negozi', 'idea-immobiliare-sa'), $get('_idea_shops'), array('placeholder' => '300 m'));
    echo '</div>';
    $extra = $get('_idea_extra');
    $extra = is_array($extra) ? $extra : array();
    echo '<div class="idea-f"><span class="idea-f__label">' . esc_html__('Dati aggiuntivi', 'idea-immobiliare-sa') . '</span><div class="idea-extra" data-label="' . esc_attr__('Es. Anno di costruzione', 'idea-immobiliare-sa') . '" data-value="' . esc_attr__('Es. 2013', 'idea-immobiliare-sa') . '">';
    foreach ($extra as $label => $value) {
        echo '<div class="idea-extra__row"><input type="text" name="idea_extra_label[]" value="' . esc_attr($label) . '" placeholder="' . esc_attr__('Es. Anno di costruzione', 'idea-immobiliare-sa') . '"><input type="text" name="idea_extra_value[]" value="' . esc_attr($value) . '" placeholder="' . esc_attr__('Es. 2013', 'idea-immobiliare-sa') . '"><button type="button" class="idea-extra__remove" aria-label="' . esc_attr__('Rimuovi', 'idea-immobiliare-sa') . '">×</button></div>';
    }
    echo '</div><button type="button" class="idea-btn-ui idea-btn-ui--ghost idea-extra__add">+ ' . esc_html__('Aggiungi un dato', 'idea-immobiliare-sa') . '</button></div>';
    idea_ui_section_close();

    // 6. Riassunto
    idea_ui_section_open(__('Riassunto', 'idea-immobiliare-sa'), __('Una o due frasi: compaiono nelle anteprime e nei risultati di Google.', 'idea-immobiliare-sa'), '6');
    echo '<div class="idea-f"><textarea name="excerpt" id="idea_excerpt" rows="3" maxlength="300">' . esc_textarea($post->post_excerpt) . '</textarea></div>';
    idea_ui_section_close();

    echo '<h2 class="idea-ui__editor-title"><span class="idea-card-ui__num">7</span>' . esc_html__('Descrizione completa', 'idea-immobiliare-sa') . '</h2>';
}

function idea_immo_ui_promo($post)
{
    idea_ui_section_open(__('Immagine di copertina', 'idea-immobiliare-sa'), __('Compare nell’elenco delle promozioni e nella home.', 'idea-immobiliare-sa'), '1');
    idea_ui_media('idea_promo_image', has_post_thumbnail($post->ID) ? array(get_post_thumbnail_id($post->ID)) : array(), 'single', array(
        'title'  => __('Scegli l’immagine di copertina', 'idea-immobiliare-sa'),
        'button' => __('Usa questa immagine', 'idea-immobiliare-sa'),
        'add'    => __('Scegli immagine', 'idea-immobiliare-sa'),
    ));
    idea_ui_section_close();

    idea_ui_section_open(__('Riassunto', 'idea-immobiliare-sa'), __('Una o due frasi: compaiono nell’elenco delle promozioni.', 'idea-immobiliare-sa'), '2');
    echo '<div class="idea-f"><textarea name="excerpt" id="idea_excerpt" rows="3" maxlength="300">' . esc_textarea($post->post_excerpt) . '</textarea></div>';
    idea_ui_section_close();

    idea_ui_section_open(__('Link', 'idea-immobiliare-sa'), __('Facoltativo. Se lo imposti, cliccando la promozione nello slider della home si va a questo indirizzo invece che alla sua pagina.', 'idea-immobiliare-sa'), '3');
    idea_ui_input('_idea_link', __('Indirizzo del link', 'idea-immobiliare-sa'), get_post_meta($post->ID, '_idea_link', true), array('placeholder' => 'https://…', 'help' => __('Un indirizzo completo (https://…) oppure una pagina del sito (es. /immobili/). Vuoto = pagina della promozione.', 'idea-immobiliare-sa')));
    idea_ui_section_close();

    idea_ui_section_open(__('Foto della galleria', 'idea-immobiliare-sa'), __('Altre foto del progetto: compaiono nella pagina della promozione sotto il testo. Trascina le foto per cambiare l’ordine.', 'idea-immobiliare-sa'), '4');
    $pg = get_post_meta($post->ID, '_idea_gallery', true);
    idea_ui_media('idea_promo_gallery', is_array($pg) ? $pg : array(), 'gallery', array(
        'title'  => __('Scegli le foto della promozione', 'idea-immobiliare-sa'),
        'button' => __('Usa queste foto', 'idea-immobiliare-sa'),
        'add'    => __('Aggiungi foto alla galleria', 'idea-immobiliare-sa'),
    ));
    idea_ui_section_close();

    echo '<h2 class="idea-ui__editor-title"><span class="idea-card-ui__num">5</span>' . esc_html__('Testo della promozione', 'idea-immobiliare-sa') . '</h2>';
}

/** Classe sul body con lo stato dell'annuncio: serve a colorare la pillola «Stato» del box Pubblica. */
add_filter('admin_body_class', function ($classes) {
    global $post, $pagenow;
    if (in_array($pagenow, array('post.php', 'post-new.php'), true) && $post instanceof WP_Post && in_array($post->post_type, idea_immo_admin_types(), true)) {
        $classes .= ' idea-poststatus-' . ($post->post_status === 'publish' ? 'ok' : 'warn');
    }
    return $classes;
});

/* ─────────────────────────────────────────────
   3. ASSET
   ───────────────────────────────────────────── */
add_action('admin_enqueue_scripts', 'idea_immo_admin_assets');
function idea_immo_admin_assets($hook)
{
    $screen = get_current_screen();
    $dir = get_stylesheet_directory();
    $uri = get_stylesheet_directory_uri();
    // Elenchi Zone e Categorie: stesso stile della schermata dell'immobile.
    if ($screen && in_array($screen->taxonomy, array('zona', 'categoria_immobile'), true) && in_array($hook, array('edit-tags.php', 'term.php'), true)) {
        wp_enqueue_style('idea-immo-admin', $uri . '/assets/css/admin.css', array(), (string) filemtime($dir . '/assets/css/admin.css'));
        return;
    }
    if (!$screen || !in_array($screen->post_type, idea_immo_admin_types(), true) || !in_array($hook, array('post.php', 'post-new.php'), true)) {
        return;
    }
    wp_enqueue_media();
    wp_enqueue_script('jquery-ui-sortable');
    wp_enqueue_style('idea-immo-admin', $uri . '/assets/css/admin.css', array(), (string) filemtime($dir . '/assets/css/admin.css'));
    wp_enqueue_script('idea-immo-admin', $uri . '/assets/js/admin-gallery.js', array('jquery', 'jquery-ui-sortable'), (string) filemtime($dir . '/assets/js/admin-gallery.js'), true);
}

/* ─────────────────────────────────────────────
   4. SALVATAGGIO
   ───────────────────────────────────────────── */
add_action('save_post_immobile', 'idea_immo_save', 10, 2);
add_action('save_post_promozione', 'idea_immo_save', 10, 2);
function idea_immo_save($post_id, $post)
{
    if (!isset($_POST['idea_immo_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['idea_immo_nonce'])), 'idea_immo_save')) {
        return;
    }
    if ((defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) || wp_is_post_revision($post_id) || !current_user_can('edit_post', $post_id)) {
        return;
    }

    if ($post->post_type === 'promozione') {
        if (isset($_POST['idea_promo_image'])) {
            $ids = array_filter(array_map('absint', explode(',', sanitize_text_field(wp_unslash($_POST['idea_promo_image'])))));
            if ($ids) {
                set_post_thumbnail($post_id, reset($ids));
            } else {
                delete_post_thumbnail($post_id);
            }
        }
        if (isset($_POST['idea_promo_gallery'])) {
            $gids = array_values(array_unique(array_filter(array_map('absint', explode(',', sanitize_text_field(wp_unslash($_POST['idea_promo_gallery'])))))));
            if ($gids) {
                update_post_meta($post_id, '_idea_gallery', $gids);
            } else {
                delete_post_meta($post_id, '_idea_gallery');
            }
        }
        if (isset($_POST['_idea_link'])) {
            $link = esc_url_raw(trim(wp_unslash($_POST['_idea_link'])));
            if ($link === '') {
                delete_post_meta($post_id, '_idea_link');
            } else {
                update_post_meta($post_id, '_idea_link', $link);
            }
        }
        return;
    }

    foreach (idea_immo_fields() as $key => $f) {
        if (!isset($_POST[$key])) {
            continue;
        }
        $raw = wp_unslash($_POST[$key]);
        if ($f['type'] === 'number') {
            $raw = str_replace(array("'", '’', ' '), '', (string) $raw);
            $val = ($raw === '' || !is_numeric($raw)) ? '' : (string) (float) $raw;
        } else {
            $val = sanitize_text_field($raw);
        }
        if ($val === '') {
            delete_post_meta($post_id, $key);
        } else {
            update_post_meta($post_id, $key, $val);
        }
    }

    if (isset($_POST['idea_immo_status'])) {
        $status = sanitize_key(wp_unslash($_POST['idea_immo_status']));
        update_post_meta($post_id, '_idea_status', isset(idea_immo_statuses()[$status]) ? $status : 'disponibile');
    }
    if (isset($_POST['idea_immo_gx'])) {
        update_post_meta($post_id, '_idea_gx', wp_unslash($_POST['idea_immo_gx']) === '0' ? '0' : '1');
    }
    if (isset($_POST['idea_immo_offer'])) {
        $offer = sanitize_key(wp_unslash($_POST['idea_immo_offer']));
        update_post_meta($post_id, '_idea_offer', isset(idea_immo_offers()[$offer]) ? $offer : 'vendita');
    }

    // Zona e categorie: scelte per nome, salvate come termini.
    if (isset($_POST['idea_zona'])) {
        $zone = absint($_POST['idea_zona']);
        wp_set_object_terms($post_id, $zone ? array($zone) : array(), 'zona');
    }
    $cats = isset($_POST['idea_cat']) ? array_map('absint', (array) wp_unslash($_POST['idea_cat'])) : array();
    wp_set_object_terms($post_id, array_values(array_filter($cats)), 'categoria_immobile');

    // Dati aggiuntivi: righe etichetta / valore.
    if (isset($_POST['idea_extra_label'], $_POST['idea_extra_value'])) {
        $labels = (array) wp_unslash($_POST['idea_extra_label']);
        $values = (array) wp_unslash($_POST['idea_extra_value']);
        $extra  = array();
        foreach ($labels as $i => $label) {
            $label = sanitize_text_field($label);
            $value = isset($values[$i]) ? sanitize_text_field($values[$i]) : '';
            if ($label !== '' && $value !== '') {
                $extra[$label] = $value;
            }
        }
        if ($extra) {
            update_post_meta($post_id, '_idea_extra', $extra);
        } else {
            delete_post_meta($post_id, '_idea_extra');
        }
    }

    if (isset($_POST['idea_immo_gallery'])) {
        $ids = array_values(array_unique(array_filter(array_map('absint', explode(',', sanitize_text_field(wp_unslash($_POST['idea_immo_gallery'])))))));
        if ($ids) {
            update_post_meta($post_id, '_idea_gallery', $ids);
            set_post_thumbnail($post_id, $ids[0]);
        } else {
            delete_post_meta($post_id, '_idea_gallery');
            delete_post_thumbnail($post_id);
        }
    }
}

/* ─────────────────────────────────────────────
   5. ELENCHI IN BACHECA
   ───────────────────────────────────────────── */
add_filter('manage_immobile_posts_columns', 'idea_immo_columns');
function idea_immo_columns($cols)
{
    $new = array();
    foreach ($cols as $key => $label) {
        if ($key === 'title') {
            $new['idea_thumb'] = '';
        }
        $new[$key] = $label;
        if ($key === 'title') {
            $new['idea_ref']      = __('ID', 'idea-immobiliare-sa');
            $new['idea_location'] = __('Località', 'idea-immobiliare-sa');
            $new['idea_price']    = __('Prezzo', 'idea-immobiliare-sa');
            $new['idea_status']   = __('Stato', 'idea-immobiliare-sa');
        }
    }
    return $new;
}

add_action('manage_immobile_posts_custom_column', 'idea_immo_column_content', 10, 2);
function idea_immo_column_content($col, $post_id)
{
    switch ($col) {
        case 'idea_thumb':
            echo get_the_post_thumbnail($post_id, array(60, 40), array('style' => 'width:60px;height:40px;object-fit:cover;border-radius:6px'));
            break;
        case 'idea_ref':
            echo esc_html((string) get_post_meta($post_id, '_idea_ref', true));
            break;
        case 'idea_location':
            echo esc_html(idea_immo_location($post_id));
            break;
        case 'idea_price':
            echo esc_html(idea_immo_price_label($post_id));
            break;
        case 'idea_status':
            $st = idea_immo_status($post_id);
            echo '<span class="idea-badge idea-badge--' . esc_attr($st) . '">' . esc_html(idea_immo_statuses()[$st]) . '</span>';
            break;
    }
}

add_filter('manage_edit-immobile_sortable_columns', function ($cols) {
    $cols['idea_price'] = 'idea_price';
    return $cols;
});
add_action('pre_get_posts', function ($q) {
    if (is_admin() && $q->is_main_query() && $q->get('post_type') === 'immobile' && $q->get('orderby') === 'idea_price') {
        $q->set('meta_key', '_idea_price');
        $q->set('orderby', 'meta_value_num');
    }
});

// La ricerca nell'elenco trova gli immobili anche per ID oggetto (es. 20208), oltre che per titolo e testo.
add_filter('posts_search', function ($search, $q) {
    global $wpdb;
    if (!is_admin() || !$q->is_main_query() || $q->get('post_type') !== 'immobile') {
        return $search;
    }
    $term = trim((string) $q->get('s'));
    if ($term === '') {
        return $search;
    }
    $like = '%' . $wpdb->esc_like($term) . '%';
    $by_ref = $wpdb->prepare("{$wpdb->posts}.ID IN (SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = '_idea_ref' AND meta_value LIKE %s)", $like);
    if ($search === '') {
        return " AND ($by_ref) ";
    }
    return preg_replace('/^ AND \(/', ' AND (' . $by_ref . ' OR ', $search, 1);
}, 10, 2);

add_action('admin_head-edit.php', function () {
    $screen = get_current_screen();
    if ($screen && $screen->post_type === 'immobile') {
        echo '<style>.idea-badge{display:inline-block;padding:3px 10px;border-radius:20px;font-size:12px;font-weight:600;background:#e8f5ef;color:#15704a}.idea-badge--riservato{background:#fff3d6;color:#8a5a00}.idea-badge--archivio{background:#eceff2;color:#5d6b7a}.column-idea_thumb{width:70px}</style>';
    }
});
