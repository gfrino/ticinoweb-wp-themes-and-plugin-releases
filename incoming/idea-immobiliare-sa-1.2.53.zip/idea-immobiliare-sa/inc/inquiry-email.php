<?php
/**
 * Email delle richieste dalla scheda di un immobile: arriva in HTML con i colori del sito, una piccola foto e il collegamento alla scheda.
 * Usa il gestore del parent (filtri ticinoweb_form_fields / ticinoweb_form_email_body): destinatari,
 * Reply-To e salvataggio in Invii Ricevuti restano quelli del parent.
 */
if (!defined('ABSPATH')) {
    exit;
}

/** Immobile pubblicato indicato dal modulo, 0 se non c'è o non è valido. */
function idea_immo_inquiry_property($fields)
{
    $id = isset($fields['immobile_id']) ? (int) $fields['immobile_id'] : 0;
    return ($id && get_post_type($id) === 'immobile' && get_post_status($id) === 'publish') ? $id : 0;
}

add_filter('ticinoweb_form_fields', function ($fields, $post) {
    $fields['immobile_id'] = isset($post['immobile_id']) ? absint($post['immobile_id']) : 0;
    return $fields;
}, 10, 2);

add_filter('ticinoweb_form_email_body', function ($body, $fields) {
    $pid = idea_immo_inquiry_property((array) $fields);
    if (!$pid) {
        return $body;
    }
    $navy = '#2a445d';
    $mint = '#8fcdb4';
    $ink  = '#1f2a36';
    $mut  = '#5d6b7a';
    $line = '#dde4ea';
    $tint = '#f2f6f8';
    $sans = "'Source Sans 3',Arial,Helvetica,sans-serif";
    $serif = "'Playfair Display',Georgia,'Times New Roman',serif";

    $title = html_entity_decode(get_the_title($pid), ENT_QUOTES, 'UTF-8');
    $ref   = trim((string) get_post_meta($pid, '_idea_ref', true));
    $link  = get_permalink($pid);
    $logo  = get_stylesheet_directory_uri() . '/assets/img/logo-dark.jpg';
    $site  = wp_specialchars_decode(get_bloginfo('name'), ENT_QUOTES);

    $label = function ($text) use ($mut) {
        return '<div style="font-size:12px;letter-spacing:.06em;text-transform:uppercase;color:' . $mut . ';margin:0 0 2px;">' . esc_html($text) . '</div>';
    };
    $value = function ($html) use ($ink) {
        return '<div style="font-size:16px;color:' . $ink . ';margin:0 0 14px;">' . $html . '</div>';
    };

    $photo = '';
    $ids   = idea_immo_gallery_ids($pid);
    $src   = $ids ? wp_get_attachment_image_url($ids[0], 'medium') : '';
    if ($src) {
        $photo = '<td width="200" valign="top" style="padding:0 18px 0 0;"><a href="' . esc_url($link) . '"><img src="' . esc_url($src) . '" width="200" alt="' . esc_attr($title) . '" style="display:block;width:200px;max-width:100%;height:auto;border-radius:10px;border:0;"></a></td>';
    }

    $h  = '<div style="margin:0;padding:24px 12px;background:' . $tint . ';font-family:' . $sans . ';">';
    $h .= '<table role="presentation" width="600" align="center" cellpadding="0" cellspacing="0" style="width:600px;max-width:100%;background:#fff;border-radius:14px;overflow:hidden;">';
    // Intestazione
    $h .= '<tr><td style="background:' . $navy . ';padding:18px 28px;"><table role="presentation" width="100%" cellpadding="0" cellspacing="0"><tr>';
    $h .= '<td><img src="' . esc_url($logo) . '" height="40" alt="' . esc_attr($site) . '" style="display:block;height:40px;width:auto;border:0;"></td>';
    $h .= '<td align="right" style="font-size:12px;letter-spacing:.08em;text-transform:uppercase;color:' . $mint . ';">' . esc_html__('Nuova richiesta', 'idea-immobiliare-sa') . '</td>';
    $h .= '</tr></table></td></tr>';
    // Titolo
    $h .= '<tr><td style="padding:28px 28px 8px;"><h1 style="margin:0;font-family:' . $serif . ';font-size:24px;line-height:1.25;color:' . $navy . ';font-weight:700;">' . esc_html(sprintf(__('%s chiede informazioni', 'idea-immobiliare-sa'), $fields['nome'])) . '</h1></td></tr>';
    // Immobile
    $h .= '<tr><td style="padding:14px 28px 4px;"><table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:' . $tint . ';border-radius:12px;"><tr><td style="padding:14px;"><table role="presentation" width="100%" cellpadding="0" cellspacing="0"><tr>' . $photo . '<td valign="top">';
    $h .= '<div style="font-size:12px;letter-spacing:.06em;text-transform:uppercase;color:' . $mut . ';margin:0 0 4px;">' . esc_html__('Immobile richiesto', 'idea-immobiliare-sa') . '</div>';
    $h .= '<div style="font-family:' . $serif . ';font-size:18px;line-height:1.3;color:' . $navy . ';font-weight:700;margin:0 0 6px;">' . esc_html($title) . '</div>';
    $h .= '<div style="font-size:15px;color:' . $ink . ';margin:0 0 12px;">' . esc_html(idea_immo_price_label($pid)) . ($ref !== '' ? ' · ' . esc_html(sprintf(__('ID %s', 'idea-immobiliare-sa'), $ref)) : '') . '</div>';
    $h .= '<a href="' . esc_url($link) . '" style="display:inline-block;background:' . $navy . ';color:#fff;text-decoration:none;font-size:14px;font-weight:600;padding:9px 16px;border-radius:999px;">' . esc_html__('Apri la scheda', 'idea-immobiliare-sa') . '</a>';
    $h .= '</td></tr></table></td></tr></table></td></tr>';
    // Contatto
    $h .= '<tr><td style="padding:22px 28px 0;">';
    $h .= $label(__('Email', 'idea-immobiliare-sa')) . $value('<a href="mailto:' . esc_attr($fields['email']) . '" style="color:' . $navy . ';">' . esc_html($fields['email']) . '</a>');
    if (!empty($fields['telefono'])) {
        $tel = preg_replace('/[^0-9+]/', '', $fields['telefono']);
        $h .= $label(__('Telefono', 'idea-immobiliare-sa')) . $value('<a href="tel:' . esc_attr($tel) . '" style="color:' . $navy . ';">' . esc_html($fields['telefono']) . '</a>');
    }
    $h .= '</td></tr>';
    // Messaggio
    $h .= '<tr><td style="padding:0 28px 8px;">' . $label(__('Messaggio', 'idea-immobiliare-sa'));
    $h .= '<div style="background:' . $tint . ';border-radius:12px;padding:14px 16px;font-size:16px;line-height:1.55;color:' . $ink . ';white-space:pre-line;">' . esc_html($fields['messaggio']) . '</div></td></tr>';
    // Rispondi
    $h .= '<tr><td style="padding:18px 28px 26px;"><a href="mailto:' . esc_attr($fields['email']) . '?subject=' . rawurlencode('Re: ' . $title) . '" style="display:inline-block;background:' . $mint . ';color:' . $navy . ';text-decoration:none;font-size:15px;font-weight:700;padding:11px 22px;border-radius:999px;">' . esc_html__('Rispondi', 'idea-immobiliare-sa') . '</a></td></tr>';
    // Piede
    $h .= '<tr><td style="border-top:1px solid ' . $line . ';padding:14px 28px;font-size:12px;color:' . $mut . ';">' . esc_html(sprintf(__('Inviato dal sito %1$s · %2$s', 'idea-immobiliare-sa'), wp_parse_url(home_url('/'), PHP_URL_HOST), wp_date(get_option('date_format') . ' ' . get_option('time_format')))) . '</td></tr>';
    $h .= '</table></div>';

    // L'email di questa richiesta è in HTML; il filtro si toglie subito dopo l'invio.
    add_filter('wp_mail_content_type', 'idea_immo_inquiry_html_type');
    return $h;
}, 10, 2);

function idea_immo_inquiry_html_type()
{
    return 'text/html';
}
add_action('ticinoweb_form_submitted', function () {
    remove_filter('wp_mail_content_type', 'idea_immo_inquiry_html_type');
});
