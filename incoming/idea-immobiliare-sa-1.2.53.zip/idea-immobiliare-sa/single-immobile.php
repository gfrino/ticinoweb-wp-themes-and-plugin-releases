<?php
/**
 * Scheda immobile: galleria, dati, descrizione, richiesta di informazioni.
 *
 * @package Idea_Immobiliare_SA
 */
get_header();
while (have_posts()) : the_post();
	$pid      = get_the_ID();
	$gallery  = idea_immo_gallery_ids($pid);
	$location = idea_immo_location($pid);
	$details  = idea_immo_details($pid);
	$status   = idea_immo_status($pid);
	$offer    = idea_immo_offer($pid);
	$cat      = idea_immo_term_name('categoria_immobile', $pid);
	$zone     = idea_immo_term_name('zona', $pid);
	$contact  = idea_immo_contact();
	$next     = get_adjacent_post(false, '', false);
	$prev     = get_adjacent_post(false, '', true);
	?>
<main id="main" class="idea-single az az-property">
	<header class="az-hero az-hero--catalog az-hero--property">
		<div class="idea-container">
			<?php echo ticinoweb_get_breadcrumbs(); // phpcs:ignore WordPress.Security.EscapeOutput ?>
			<p class="az-chips">
				<span class="az-chip az-chip--mint"><?php echo esc_html($offer === 'affitto' ? __('Affitto', 'idea-immobiliare-sa') : __('Vendita', 'idea-immobiliare-sa')); ?></span>
				<?php if ($cat !== '') : ?><span class="az-chip"><?php echo esc_html($cat); ?></span><?php endif; ?>
				<?php if ($location !== '' || $zone !== '') : ?><span class="az-chip"><?php echo idea_immo_icon('indirizzo'); // phpcs:ignore WordPress.Security.EscapeOutput ?><?php echo esc_html($location !== '' ? $location : $zone); ?></span><?php endif; ?>
			</p>
			<h1><?php the_title(); ?></h1>
			<p class="az-price"><?php echo esc_html(idea_immo_price_label($pid)); ?></p>
		</div>
	</header>

	<section class="idea-section">
		<div class="idea-container idea-single__layout">
			<div class="idea-single__main">
				<?php if ($status !== 'disponibile') : ?>
					<p class="idea-notice"><?php echo esc_html($status === 'riservato' ? __('Questo immobile è attualmente riservato.', 'idea-immobiliare-sa') : __('Questo immobile non è più disponibile. Contattaci: abbiamo altre proposte simili.', 'idea-immobiliare-sa')); ?></p>
				<?php endif; ?>

				<?php if ($gallery) : ?>
				<div class="idea-gallery" data-idea-gallery>
					<figure class="idea-gallery__stage">
						<?php echo wp_get_attachment_image($gallery[0], idea_immo_gallery_size($gallery[0]), false, array('class' => 'idea-gallery__img', 'fetchpriority' => 'high', 'sizes' => '(max-width: 1000px) 100vw, 640px', 'alt' => esc_attr(get_the_title()))); ?>
						<?php if (count($gallery) > 1) : ?>
							<button type="button" class="idea-gallery__nav idea-gallery__nav--prev" aria-label="<?php esc_attr_e('Foto precedente', 'idea-immobiliare-sa'); ?>">‹</button>
							<button type="button" class="idea-gallery__nav idea-gallery__nav--next" aria-label="<?php esc_attr_e('Foto successiva', 'idea-immobiliare-sa'); ?>">›</button>
							<span class="idea-gallery__count"><span data-idea-current>1</span> / <?php echo (int) count($gallery); ?></span>
						<?php endif; ?>
					</figure>
					<?php if (count($gallery) > 1) : ?>
					<ul class="idea-gallery__thumbs">
						<?php foreach ($gallery as $i => $att) :
							$large = wp_get_attachment_image_url($att, idea_immo_gallery_size($att));
							$thumb = wp_get_attachment_image_url($att, 'medium'); ?>
							<li><button type="button" data-full="<?php echo esc_url($large); ?>"<?php echo $i === 0 ? ' aria-current="true"' : ''; ?> aria-label="<?php echo esc_attr(sprintf(__('Foto %d', 'idea-immobiliare-sa'), $i + 1)); ?>"><img src="<?php echo esc_url($thumb); ?>" alt="" loading="lazy" width="150" height="150"></button></li>
						<?php endforeach; ?>
					</ul>
					<?php endif; ?>
				</div>
				<?php endif; ?>

				<?php $key = idea_immo_details($pid, true); if ($key) : ?>
				<ul class="az-facts">
					<?php foreach ($key as $row) : ?>
						<li><?php echo idea_immo_icon($row[0]); // phpcs:ignore WordPress.Security.EscapeOutput ?><strong><?php echo esc_html($row[1]); ?></strong><span><?php echo esc_html($row[0]); ?></span></li>
					<?php endforeach; ?>
				</ul>
				<?php endif; ?>

				<div class="idea-prose idea-single__text">
					<?php if (trim(get_the_content()) !== '') : ?>
						<h2><?php esc_html_e('Descrizione dell’immobile', 'idea-immobiliare-sa'); ?></h2>
						<?php the_content(); ?>
					<?php endif; ?>
				</div>
			</div>

			<aside class="idea-single__side">
				<?php if ($details) : ?>
				<section class="idea-box">
					<h2><?php esc_html_e('Dettagli dell’immobile', 'idea-immobiliare-sa'); ?></h2>
					<dl class="idea-facts">
						<?php foreach ($details as $row) : ?>
							<div><dt><?php echo idea_immo_icon($row[0]); // phpcs:ignore WordPress.Security.EscapeOutput ?><?php echo esc_html($row[0]); ?></dt><dd><?php echo esc_html($row[1]); ?></dd></div>
						<?php endforeach; ?>
					</dl>
				</section>
				<?php endif; ?>

				<section class="idea-box idea-box--form" id="richiedi-informazioni">
					<?php echo idea_immo_contact_form(idea_immo_inquiry_subject($pid), __('Richiedi informazioni', 'idea-immobiliare-sa'), $pid); // phpcs:ignore WordPress.Security.EscapeOutput ?>
				</section>
			</aside>
		</div>

		<?php if ($prev || $next) : ?>
		<nav class="idea-container idea-prevnext" aria-label="<?php esc_attr_e('Altri immobili', 'idea-immobiliare-sa'); ?>">
			<span><?php if ($prev) : ?><a href="<?php echo esc_url(get_permalink($prev)); ?>" rel="prev">← <?php echo esc_html(wp_trim_words(get_the_title($prev), 8, '…')); ?></a><?php endif; ?></span>
			<span><?php if ($next) : ?><a href="<?php echo esc_url(get_permalink($next)); ?>" rel="next"><?php echo esc_html(wp_trim_words(get_the_title($next), 8, '…')); ?> →</a><?php endif; ?></span>
		</nav>
		<?php endif; ?>
	</section>
</main>
<?php endwhile;
get_footer();
