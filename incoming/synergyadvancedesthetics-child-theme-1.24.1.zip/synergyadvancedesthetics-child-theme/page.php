<?php
/**
 * The template for displaying all pages
 *
 * @package SynergyAdvancedAesthetics
 */

get_header();
?>

<?php
$is_woo_page = ( function_exists( 'is_cart' ) && is_cart() ) || ( function_exists( 'is_checkout' ) && is_checkout() ) || ( function_exists( 'is_account_page' ) && is_account_page() );
?>

<main id="primary" class="site-main generic-page-main <?php echo $is_woo_page ? 'synergy-woo-page-main' : ''; ?>">
    
    <?php if ( ! $is_woo_page ) : ?>
    <!-- PAGE HERO -->
    <section class="page-hero section">
        <div class="hero-bg">
            <div class="hero-texture"></div>
            <div class="hero-glow"></div>
        </div>
        <div class="container relative-z">
            <div class="hero-content text-center reveal">
                <span class="section-eyebrow"><?php echo esc_html( synergy_t( 'INFORMAZIONI LEGALI', 'page:hero:eyebrow' ) ); ?></span>
                <h1 class="hero-title"><?php the_title(); ?></h1>
                <div class="hero-divider"></div>
            </div>
        </div>
    </section>
    <?php endif; ?>

    <!-- PAGE CONTENT -->
    <section class="page-content-section section <?php echo $is_woo_page ? 'synergy-woo-content-section' : 'bg-ivory'; ?>">
        <div class="<?php echo $is_woo_page ? 'synergy-woo-container' : 'container'; ?>">
            <div class="<?php echo $is_woo_page ? 'synergy-woo-page-card' : 'page-content-card'; ?>">
                <?php while ( have_posts() ) : the_post(); ?>
                    <article id="post-<?php the_ID(); ?>" <?php post_class('entry-content synergy-article'); ?>>
                        <?php the_content(); ?>
                    </article>
                <?php endwhile; ?>
            </div>
        </div>
    </section>

</main>

<style>
/* STILI DEDICATI PER PAGINE GENERICHE E LEGALI */
.generic-page-main {
    padding-top: 100px;
    background-color: var(--c-ivory, #fcfbf9);
    min-height: 80vh;
}
.page-hero {
    position: relative;
    padding: 60px 0 40px;
    background: radial-gradient(circle at 50% 30%, rgba(230, 215, 189, 0.25) 0%, rgba(252, 251, 249, 0) 70%);
}
.page-hero .hero-title {
    font-family: var(--font-serif, 'Cormorant Garamond', serif);
    font-size: clamp(2.2rem, 4vw, 3.2rem);
    font-weight: 500;
    color: var(--c-charcoal, #202020);
    margin: 10px 0 15px;
}
.page-hero .section-eyebrow {
    font-family: var(--font-sans, 'Inter', sans-serif);
    font-size: 0.8rem;
    letter-spacing: 0.2em;
    text-transform: uppercase;
    color: var(--synergy-soft-gold, #cdbb96);
    font-weight: 600;
}
.page-hero .hero-divider {
    width: 50px;
    height: 1px;
    background: var(--synergy-soft-gold, #cdbb96);
    margin: 20px auto 0;
}
.page-content-section {
    padding: 20px 0 100px;
}
.page-content-card {
    background: #ffffff;
    border-radius: 16px;
    border: 1px solid rgba(206, 189, 173, 0.3);
    box-shadow: 0 10px 35px rgba(0, 0, 0, 0.03);
    padding: 60px 70px;
    max-width: 960px;
    margin: 0 auto;
}
.synergy-article h2 {
    font-family: var(--font-serif, 'Cormorant Garamond', serif);
    font-size: 1.75rem;
    color: var(--c-charcoal, #202020);
    margin-top: 40px;
    margin-bottom: 15px;
    padding-bottom: 8px;
    border-bottom: 1px solid rgba(206, 189, 173, 0.2);
}
.synergy-article h3 {
    font-family: var(--font-serif, 'Cormorant Garamond', serif);
    font-size: 1.3rem;
    color: var(--c-charcoal, #202020);
    margin-top: 25px;
    margin-bottom: 10px;
}
.synergy-article p,
.synergy-article li {
    font-family: var(--font-sans, 'Inter', sans-serif);
    font-size: 0.98rem;
    line-height: 1.75;
    color: #4a4a4a;
}
.synergy-article ul {
    padding-left: 24px;
    margin: 15px 0 25px;
}
.synergy-article li {
    margin-bottom: 8px;
}
.synergy-article a {
    color: #9f8252;
    text-decoration: underline;
    text-underline-offset: 3px;
    transition: color 0.3s ease;
}
.synergy-article a:hover {
    color: #202020;
}
.legal-identity-box {
    background: #fbf9f5;
    border-left: 3px solid var(--synergy-soft-gold, #cdbb96);
    padding: 16px 20px;
    border-radius: 6px;
    margin: 20px 0;
}
.legal-identity-box p {
    margin: 0;
}
.legal-updated {
    font-size: 0.9rem;
    color: #888;
    margin-bottom: 25px;
}

@media (max-width: 768px) {
    .generic-page-main {
        padding-top: 80px;
    }
    .page-content-card {
        padding: 35px 22px;
        border-radius: 12px;
    }
    .page-hero {
        padding: 40px 0 20px;
    }
}
</style>

<?php
get_footer();
