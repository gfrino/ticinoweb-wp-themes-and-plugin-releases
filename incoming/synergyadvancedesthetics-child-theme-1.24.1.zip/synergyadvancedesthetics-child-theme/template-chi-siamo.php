<?php
/**
 * Template Name: Chi Siamo
 * Description: Template dedicato alla pagina Chi Siamo
 */

get_header();

// Dati dal CMS
$chi_siamo_title = get_option('ticinoweb_chi_siamo_title', 'Professionalità, esperienza e attenzione alla persona.');
$chi_siamo_text = get_option('ticinoweb_chi_siamo_text', 'Da Synergy Advanced Aesthetics ogni trattamento nasce dall’ascolto. Uniamo competenza estetica, tecnologie professionali e cura del dettaglio per accompagnarti in percorsi viso e corpo personalizzati, pensati per valorizzare la tua bellezza in modo naturale e armonioso.');
$chi_siamo_img = get_option('ticinoweb_chi_siamo_image');

// Team
$team_gallery_id = 3;
$team_images = array();
if ($team_gallery_id) {
    $team_query = new WP_Query(array(
        'post_type' => 'attachment',
        'post_status' => 'inherit',
        'posts_per_page' => 2,
        'tax_query' => array(
            array(
                'taxonomy' => 'ticinoweb_media_gallery',
                'field' => 'term_id',
                'terms' => $team_gallery_id,
            )
        )
    ));

    if ( $team_query->have_posts() ) {
        $saved_order = get_term_meta($team_gallery_id, '_ticinoweb_gallery_order', true);
        if ( ! is_array( $saved_order ) ) {
            $saved_order = array();
        }
        if ( ! empty( $saved_order ) ) {
            usort( $team_query->posts, function ( $a, $b ) use ( $saved_order ) {
                $posA = array_search( $a->ID, $saved_order );
                $posB = array_search( $b->ID, $saved_order );
                if ( $posA === false ) $posA = 999999;
                if ( $posB === false ) $posB = 999999;
                return $posA - $posB;
            });
        }
        foreach ($team_query->posts as $post) {
            $team_images[] = wp_get_attachment_image_url($post->ID, 'large');
        }
    }
    wp_reset_postdata();
}

// $team_images (galleria media 'team') resta disponibile come fallback per le foto mancanti.
?>

<main id="primary" class="site-main chi-siamo-page">
    
    <!-- 1. HERO SECTION -->
    <section class="chisiamo-hero section">
        <div class="hero-bg">
            <div class="hero-texture"></div>
            <div class="hero-glow"></div>
        </div>
        <div class="container relative-z">
            <div class="hero-content reveal">
                <span class="section-eyebrow"><?php echo esc_html( synergy_t( 'LA NOSTRA STORIA', 'chi-siamo:hero:eyebrow' ) ); ?></span>
                <h1 class="hero-title"><?php echo esc_html( synergy_t( 'Oltre l\'estetica.', 'chi-siamo:hero:title' ) ); ?></h1>
                <p class="hero-lead"><?php echo esc_html( synergy_t( 'Uniamo passione, competenze e tecnologie all\'avanguardia per offrirti un\'esperienza di benessere autentico e risultati misurabili.', 'chi-siamo:hero:lead' ) ); ?></p>
            </div>
        </div>
    </section>

    <!-- 2. INTRODUZIONE / LA NOSTRA MISSIONE -->
    <section class="chisiamo-intro section">
        <div class="container">
            <div class="intro-grid">
                <div class="intro-visual reveal">
                    <div class="intro-visual-main">
                        <div class="chisiamo-placeholder-premium" <?php if (!empty($chi_siamo_img)) echo 'style="background-image: url(\'' . esc_url($chi_siamo_img) . '\'); background-size: cover; background-position: center; background-repeat: no-repeat;"'; ?>></div>
                        <div class="visual-frame"></div>
                        <div class="visual-badge parallax-element">
                            <span class="badge-icon">
                                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path></svg>
                            </span>
                            <span class="badge-text"><?php echo esc_html( synergy_t( 'Estetista AFC', 'chi-siamo:intro:badge' ) ); ?></span>
                        </div>
                    </div>
                </div>
                
                <div class="intro-content reveal delay-2">
                    <span class="section-eyebrow"><?php echo esc_html( synergy_t( 'IL CENTRO', 'chi-siamo:intro:eyebrow' ) ); ?></span>
                    <h2><?php echo esc_html( synergy_t( $chi_siamo_title, 'chi-siamo:intro:title' ) ); ?></h2>
                    <p class="content-lead"><?php echo esc_html( synergy_t( $chi_siamo_text, 'chi-siamo:intro:text' ) ); ?></p>
                    <p class="content-secondary">
                        <?php echo esc_html( synergy_t( 'Siamo un team di professioniste dedicate alla cura e al benessere della persona. Crediamo fortemente che ogni percorso debba essere personalizzato. Per questo ci prendiamo il tempo per ascoltarti, analizzare le esigenze della tua pelle e del tuo corpo, e costruire insieme a te la strategia migliore.', 'chi-siamo:intro:secondary:1' ) ); ?>
                    </p>
                    <p class="content-secondary">
                        <?php echo esc_html( synergy_t( 'La nostra filosofia non si basa solo sul trattamento estetico in sé, ma sull\'accompagnarti in un vero e proprio viaggio verso il miglioramento, in un ambiente protetto, discreto e rilassante.', 'chi-siamo:intro:secondary:2' ) ); ?>
                    </p>
                </div>
            </div>
        </div>
    </section>

    <!-- 3. I VALORI -->
    <section class="chisiamo-values section bg-pearl">
        <div class="container">
            <div class="values-header text-center reveal">
                <span class="section-eyebrow"><?php echo esc_html( synergy_t( 'LA NOSTRA FILOSOFIA', 'chi-siamo:values:eyebrow' ) ); ?></span>
                <h2><?php echo esc_html( synergy_t( 'I pilastri del nostro lavoro', 'chi-siamo:values:title' ) ); ?></h2>
            </div>
            
            <div class="values-grid">
                <div class="value-card reveal delay-1">
                    <div class="value-icon">
                        <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"></path></svg>
                    </div>
                    <h3><?php echo esc_html( synergy_t( 'Attenzione alla Persona', 'chi-siamo:values:1:title' ) ); ?></h3>
                    <p><?php echo esc_html( synergy_t( 'Non offriamo pacchetti standard, ma percorsi studiati su misura per rispettare l\'unicità di ogni individuo e garantire i migliori risultati possibili.', 'chi-siamo:values:1:text' ) ); ?></p>
                </div>
                
                <div class="value-card reveal delay-2">
                    <div class="value-icon">
                        <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="3" width="20" height="14" rx="2" ry="2"></rect><line x1="8" y1="21" x2="16" y2="21"></line><line x1="12" y1="17" x2="12" y2="21"></line></svg>
                    </div>
                    <h3><?php echo esc_html( synergy_t( 'Innovazione Tecnologica', 'chi-siamo:values:2:title' ) ); ?></h3>
                    <p><?php echo esc_html( synergy_t( 'Utilizziamo macchinari di ultima generazione e prodotti cosmetici altamente selezionati per supportare le nostre manualità con l\'efficacia della scienza.', 'chi-siamo:values:2:text' ) ); ?></p>
                </div>
                
                <div class="value-card reveal delay-3">
                    <div class="value-icon">
                        <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M22 12h-4l-3 9L9 3l-3 9H2"></path></svg>
                    </div>
                    <h3><?php echo esc_html( synergy_t( 'Trasparenza & Sicurezza', 'chi-siamo:values:3:title' ) ); ?></h3>
                    <p><?php echo esc_html( synergy_t( 'La tua sicurezza è la nostra priorità. Ti spieghiamo in modo chiaro e trasparente le fasi di ogni trattamento, accompagnandoti con competenza e discrezione.', 'chi-siamo:values:3:text' ) ); ?></p>
                </div>
            </div>
        </div>
    </section>

    <!-- 4. IL TEAM (dati dal pannello "IL TEAM", condivisi con la homepage) -->
    <?php
        $team_eyebrow     = get_option( 'synergy_team_eyebrow', 'IL TEAM' );
        $team_title       = get_option( 'synergy_team_title', 'Le professioniste dietro ogni percorso.' );
        $team_description = get_option( 'synergy_team_description', 'Ogni trattamento nasce dall’ascolto, dall’esperienza e da una cura autentica per la persona. Da Synergy Advanced Aesthetics trovi competenze professionali, discrezione e un approccio su misura per accompagnarti con fiducia in ogni fase del tuo percorso estetico.' );
        $team_members     = function_exists( 'synergy_get_team_members' ) ? synergy_get_team_members() : array();
    ?>
    <section class="team-section section">
        <div class="team-bg">
            <div class="team-glow"></div>
        </div>
        <div class="container relative-z">
            <div class="team-header text-center reveal">
                <span class="section-eyebrow"><?php echo esc_html( synergy_t( $team_eyebrow, 'chi-siamo:team:eyebrow' ) ); ?></span>
                <h2><?php echo esc_html( synergy_t( $team_title, 'chi-siamo:team:title' ) ); ?></h2>
                <p><?php echo esc_html( synergy_t( $team_description, 'chi-siamo:team:description' ) ); ?></p>
            </div>
            
            <div class="team-grid">
                <?php if ( ! empty( $team_members ) ) : ?>
                    <?php foreach ( $team_members as $index => $member ) :
                        $m_name  = isset( $member['name'] ) ? $member['name'] : '';
                        $m_role  = isset( $member['role'] ) ? $member['role'] : '';
                        $m_title = isset( $member['title'] ) ? $member['title'] : '';
                        $m_bio   = isset( $member['bio'] ) ? $member['bio'] : '';
                        $m_photo = ! empty( $member['photo'] ) ? $member['photo'] : ( isset( $team_images[ $index ] ) ? $team_images[ $index ] : '' );
                        if ( '' === $m_name ) {
                            continue;
                        }

                        // Monogramma per il placeholder se manca la foto
                        $initials = '';
                        foreach ( explode( ' ', trim( $m_name ) ) as $part ) {
                            $initials .= mb_substr( $part, 0, 1 );
                        }
                        $initials    = mb_strtoupper( mb_substr( $initials, 0, 2 ) );
                        $delay_class = 'delay-' . ( ( $index % 4 ) + 1 );
                    ?>
                    <div class="team-card reveal <?php echo esc_attr( $delay_class ); ?>">
                        <div class="team-portrait-wrapper">
                            <?php if ( ! empty( $m_photo ) ) : ?>
                                <div class="team-portrait" role="img" aria-label="<?php echo esc_attr( $m_name ); ?>" style="background-image: url('<?php echo esc_url( $m_photo ); ?>');"></div>
                            <?php else : ?>
                                <div class="team-portrait team-placeholder">
                                    <span><?php echo esc_html( $initials ); ?></span>
                                </div>
                            <?php endif; ?>
                            <div class="team-frame"></div>
                        </div>
                        <div class="team-info-box parallax-element">
                            <div class="info-content">
                                <h3><?php echo esc_html( $m_name ); ?></h3>
                                <?php if ( '' !== $m_role ) : ?>
                                    <span class="team-role"><?php echo esc_html( synergy_t( $m_role, 'chi-siamo:team:member:' . sanitize_title( $m_name ) . ':role' ) ); ?></span>
                                <?php endif; ?>
                                <?php if ( '' !== $m_title ) : ?>
                                    <span class="team-subrole"><?php echo esc_html( synergy_t( $m_title, 'chi-siamo:team:member:' . sanitize_title( $m_name ) . ':title' ) ); ?></span>
                                <?php endif; ?>
                                <?php
                                /* Qualifiche dal pannello IL TEAM: una riga per voce. */
                                $m_bio_lines = array_values( array_filter( array_map( 'trim', preg_split( '/\r\n|\r|\n/', (string) $m_bio ) ), 'strlen' ) );
                                if ( $m_bio_lines ) : ?>
                                    <ul class="team-qualifiche">
                                        <?php foreach ( $m_bio_lines as $bi => $riga ) : ?>
                                            <li><?php echo esc_html( synergy_t( $riga, 'team:member:' . sanitize_title( $m_name ) . ':bio:' . $bi ) ); ?></li>
                                        <?php endforeach; ?>
                                    </ul>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </section>



</main>

<?php get_footer(); ?>
