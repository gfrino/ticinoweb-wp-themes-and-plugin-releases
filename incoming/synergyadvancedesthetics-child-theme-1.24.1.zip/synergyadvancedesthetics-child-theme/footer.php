<?php
/**
 * The template for displaying the footer
 */

// Recupero dati da ticinoWEB CMS
$cms_name    = get_option('ticinoweb_site_name') ?: 'Synergy Advanced Aesthetics';
$cms_desc    = get_option('ticinoweb_site_description') ?: 'Bellezza, tecnologia e cura personalizzata in perfetta sinergia. Il tuo centro estetico avanzato a Paradiso, Lugano.';
$cms_address = get_option('ticinoweb_contact_address') ?: 'Via Generale Guisan 10<br>Paradiso, Lugano';
$cms_phone   = get_option('ticinoweb_contact_phone') ?: '+41 (0)79 288 61 77';


$clean_phone = preg_replace('/[^0-9+]/', '', str_replace('(0)', '', $cms_phone));
$map_link = "https://maps.google.com/?q=" . urlencode(str_replace('<br>', ', ', $cms_address));
?>

<!-- PRE-FOOTER CTA -->
<?php if ( ! is_page_template( 'template-trattamento.php' ) ) : ?>
<div class="synergy-pre-footer-cta reveal">
    <div class="pre-footer-glow"></div>
    <div class="container relative-z text-center">
        <h2><?php echo esc_html( synergy_t( 'Pronta a iniziare il tuo percorso?', 'footer:cta:title' ) ); ?></h2>
        <p><?php echo esc_html( synergy_t( 'Prenota una consulenza e lasciati guidare verso il trattamento più adatto alle tue esigenze.', 'footer:cta:text' ) ); ?></p>
        <a href="<?php echo esc_url(home_url('/contatti/')); ?>" class="btn btn-cta-glow"><?php echo esc_html( synergy_t( 'Prenota una consulenza', 'footer:cta:btn' ) ); ?></a>
    </div>
</div>
<?php endif; ?>

<!-- MAIN FOOTER -->
<footer class="synergy-footer">
    <div class="footer-noise"></div>
    <div class="container relative-z">
        
        <div class="footer-grid">
            
            <!-- Colonna 1: Brand -->
            <div class="footer-col brand-col">
                <h3><?php echo esc_html($cms_name); ?></h3>
                <p class="brand-desc"><?php echo wp_kses_post( synergy_t_html( $cms_desc, 'footer:description' ) ); ?></p>
                <div class="brand-badge">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2L2 7l10 5 10-5-10-5z"/><path d="M2 17l10 5 10-5"/><path d="M2 12l10 5 10-5"/></svg>
                    <?php echo esc_html( synergy_t( 'Estetica avanzata a Lugano', 'footer:badge' ) ); ?>
                </div>
            </div>
            
            <!-- Colonna 2: Esplora -->
            <div class="footer-col links-col">
                <h4><?php echo esc_html( synergy_t( 'Esplora', 'footer:nav:explore:title' ) ); ?></h4>
                <ul>
                    <li><a href="<?php echo esc_url(home_url('/')); ?>"><?php echo esc_html( synergy_t( 'Home', 'footer:nav:explore:home' ) ); ?></a></li>
                    <li><a href="<?php echo esc_url(home_url('/chi-siamo/')); ?>"><?php echo esc_html( synergy_t( 'Chi siamo', 'footer:nav:explore:about' ) ); ?></a></li>
                    <li><a href="<?php echo esc_url(home_url('/trattamenti/')); ?>"><?php echo esc_html( synergy_t( 'Trattamenti', 'footer:nav:explore:treatments' ) ); ?></a></li>
                    <li><a href="<?php echo esc_url(home_url('/tecnologie/')); ?>"><?php echo esc_html( synergy_t( 'Tecnologie', 'footer:nav:explore:technologies' ) ); ?></a></li>
                    <li><a href="<?php echo esc_url(home_url('/prodotti/')); ?>"><?php echo esc_html( synergy_t( 'Prodotti', 'footer:nav:explore:products' ) ); ?></a></li>
                    <li><a href="<?php echo esc_url(home_url('/contatti/')); ?>"><?php echo esc_html( synergy_t( 'Contatti', 'footer:nav:explore:contacts' ) ); ?></a></li>
                </ul>
            </div>
            
            <!-- Colonna 3: Trattamenti -->
            <div class="footer-col links-col">
                <h4><?php echo esc_html( synergy_t( 'Trattamenti', 'footer:nav:treatments:title' ) ); ?></h4>
                <ul>
                    <li><a href="<?php echo esc_url(home_url('/viso/')); ?>"><?php echo esc_html( synergy_t( 'Trattamenti viso', 'footer:nav:treatments:viso' ) ); ?></a></li>
                    <li><a href="<?php echo esc_url(home_url('/drenaggio-linfatico-detox/')); ?>"><?php echo esc_html( synergy_t( 'Trattamenti corpo', 'footer:nav:treatments:corpo' ) ); ?></a></li>
                    <li><a href="<?php echo esc_url(home_url('/epilazione-laser-depilazione/')); ?>"><?php echo esc_html( synergy_t( 'Epilazione laser', 'footer:nav:treatments:laser' ) ); ?></a></li>
                    <li><a href="<?php echo esc_url(home_url('/mani-piedi-beauty-essentials/')); ?>"><?php echo esc_html( synergy_t( 'Mani & Piedi', 'footer:nav:treatments:mani_piedi' ) ); ?></a></li>
                    <li><a href="<?php echo esc_url(home_url('/massaggi-benessere/')); ?>"><?php echo esc_html( synergy_t( 'Massaggi', 'footer:nav:treatments:massaggi' ) ); ?></a></li>
                    <li><a href="<?php echo esc_url(home_url('/beauty/')); ?>"><?php echo esc_html( synergy_t( 'Beauty Essentials', 'footer:nav:treatments:beauty' ) ); ?></a></li>
                </ul>
            </div>
            
            <!-- Colonna 4: Contatti -->
            <div class="footer-col contact-col">
                <h4><?php echo esc_html( synergy_t( 'Contatti', 'footer:contact:title' ) ); ?></h4>
                <div class="footer-contact-item">
                    <p><?php echo wp_kses_post( synergy_t_html( $cms_address, 'footer:address' ) ); ?></p>
                    <a href="<?php echo esc_url($map_link); ?>" target="_blank" class="footer-link-small"><?php echo esc_html( synergy_t( 'Indicazioni', 'footer:contact:directions' ) ); ?> &rarr;</a>
                </div>
                <div class="footer-contact-item">
                    <p><a href="tel:<?php echo esc_attr($clean_phone); ?>"><?php echo esc_html($cms_phone); ?></a></p>
                </div>
                <div class="footer-contact-item mt-15">
                    <strong><?php echo esc_html( synergy_t( 'Orari:', 'footer:contact:hours_label' ) ); ?></strong>
                    <p><?php echo synergy_get_formatted_hours(); ?></p>
                </div>
            </div>

        </div>
        
        <!-- BOTTOM BAR -->
        <div class="footer-bottom">
            <div class="fb-left">
                &copy; <?php echo date('Y'); ?> <?php echo esc_html($cms_name); ?>. <?php echo esc_html( synergy_t( 'Tutti i diritti riservati.', 'footer:copyright' ) ); ?>
            </div>

            <?php
            /*
             * Selettore lingua.
             * Reso solo se tW Translate Plus e' attivo e il sito pubblica piu'
             * di una lingua: senza il plugin il footer resta identico a prima.
             */
            if ( function_exists( 'twtr_get_languages' ) ) :
                $synergy_languages = twtr_get_languages( true );
                if ( is_array( $synergy_languages ) && count( $synergy_languages ) > 1 ) :
                    $synergy_lang_label = function_exists( 'ticinoweb_frontend_text' )
                        ? ticinoweb_frontend_text( 'Lingua del sito', 'footer.language_switcher.label' )
                        : 'Lingua del sito';
                    ?>
            <nav class="fb-lang" aria-label="<?php echo esc_attr( $synergy_lang_label ); ?>">
                <ul class="synergy-lang-switch">
                    <?php foreach ( $synergy_languages as $synergy_language ) :
                        $synergy_is_current = ! empty( $synergy_language['is_current'] );
                        ?>
                    <li>
                        <a class="lang-opt<?php echo $synergy_is_current ? ' is-current' : ''; ?>"
                           href="<?php echo esc_url( $synergy_language['url'] ); ?>"
                           hreflang="<?php echo esc_attr( $synergy_language['slug'] ); ?>"
                           lang="<?php echo esc_attr( $synergy_language['slug'] ); ?>"
                           <?php echo $synergy_is_current ? 'aria-current="true"' : ''; ?>>
                            <span class="lang-code" aria-hidden="true"><?php echo esc_html( strtoupper( $synergy_language['slug'] ) ); ?></span>
                            <span class="lang-name"><?php echo esc_html( $synergy_language['label'] ); ?></span>
                        </a>
                    </li>
                    <?php endforeach; ?>
                </ul>
            </nav>
            <?php endif; endif; ?>

            <div class="fb-right">
                <a href="<?php echo esc_url(home_url('/privacy-policy/')); ?>"><?php echo esc_html( synergy_t( 'Privacy Policy', 'footer:legal:privacy' ) ); ?></a>
                <span class="sep">|</span>
                <a href="<?php echo esc_url(home_url('/cookie-policy/')); ?>"><?php echo esc_html( synergy_t( 'Cookie Policy', 'footer:legal:cookie' ) ); ?></a>
                <span class="sep">|</span>
                <a href="<?php echo esc_url(home_url('/condizioni-generali-di-vendita/')); ?>"><?php echo esc_html( synergy_t( 'Condizioni di vendita', 'footer:legal:terms' ) ); ?></a>
                <span class="sep">|</span>
                <a href="<?php echo esc_url(home_url('/spedizioni-resi-e-rimborsi/')); ?>"><?php echo esc_html( synergy_t( 'Spedizioni e resi', 'footer:legal:shipping' ) ); ?></a>
                <span class="sep">|</span>
                <a href="<?php echo esc_url(home_url('/tw-login/')); ?>"><?php echo esc_html( synergy_t( 'Area Riservata', 'footer:legal:reserved_area' ) ); ?></a>
                <span class="sep">|</span>
                <span class="credit"><?php echo esc_html( synergy_t( 'Web Design by', 'footer:credit' ) ); ?> <a href="https://ticinoweb.com" target="_blank" rel="noopener">ticinoWEB</a></span>
            </div>
        </div>
        
    </div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
