document.addEventListener("DOMContentLoaded", function() {
  const isMobile = window.innerWidth <= 768;
  const isReduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  const container = document.getElementById("synergy-floral-video");
  
  if(!container) return;
  if(isReduced) container.classList.add("is-paused");

  // Posizioni deterministiche: x%, y%, scala, rotazione, layer
  const flowerData = [
    // Ramo Sinistro
    {x: 2, y: 95, s: 1.2, r: 15, l: 'mid'}, {x: 6, y: 85, s: 0.9, r: 75, l: 'mid'}, 
    {x: 10, y: 75, s: 1.4, r: -20, l: 'front'}, {x: 8, y: 65, s: 0.8, r: 40, l: 'back'},
    {x: 15, y: 60, s: 1.1, r: -5, l: 'mid'}, {x: 20, y: 50, s: 1.5, r: 35, l: 'mid'},
    {x: 16, y: 45, s: 0.9, r: -45, l: 'back'}, {x: 24, y: 38, s: 1.2, r: 10, l: 'mid'},
    {x: 28, y: 30, s: 0.8, r: 60, l: 'mid'}, {x: 33, y: 25, s: 1.3, r: -15, l: 'front'},
    {x: 22, y: 68, s: 0.7, r: 90, l: 'back'}, {x: 12, y: 92, s: 1.3, r: -60, l: 'front'},
    {x: 26, y: 48, s: 1, r: 25, l: 'mid'}, {x: 18, y: 55, s: 1.4, r: -30, l: 'front'},

    // Ramo Destro
    {x: 98, y: 90, s: 1.1, r: -10, l: 'mid'}, {x: 92, y: 80, s: 1.5, r: 45, l: 'front'},
    {x: 88, y: 70, s: 0.9, r: -25, l: 'mid'}, {x: 94, y: 60, s: 1.2, r: 15, l: 'mid'},
    {x: 86, y: 50, s: 1.4, r: -50, l: 'front'}, {x: 90, y: 42, s: 0.8, r: 30, l: 'back'},
    {x: 84, y: 32, s: 1.1, r: -5, l: 'mid'}, {x: 88, y: 25, s: 0.9, r: 65, l: 'mid'},
    {x: 82, y: 15, s: 1.3, r: -35, l: 'front'}, {x: 86, y: 10, s: 0.8, r: 20, l: 'back'},
    {x: 78, y: 45, s: 0.7, r: -80, l: 'back'}, {x: 82, y: 65, s: 1.1, r: 40, l: 'mid'},
    {x: 96, y: 50, s: 1, r: -15, l: 'mid'}, {x: 80, y: 28, s: 1.2, r: 55, l: 'mid'},

    // Base Floreale Centrale
    {x: 35, y: 95, s: 1.3, r: 10, l: 'mid'}, {x: 42, y: 88, s: 1.6, r: -20, l: 'front'},
    {x: 38, y: 78, s: 0.9, r: 45, l: 'back'}, {x: 48, y: 92, s: 1.2, r: -5, l: 'mid'},
    {x: 52, y: 82, s: 1.5, r: 35, l: 'mid'}, {x: 50, y: 72, s: 0.8, r: -40, l: 'back'},
    {x: 58, y: 90, s: 1.7, r: 15, l: 'front'}, {x: 62, y: 80, s: 1.1, r: -25, l: 'mid'},
    {x: 68, y: 95, s: 1.4, r: 55, l: 'mid'}, {x: 65, y: 75, s: 0.9, r: -10, l: 'back'},
    {x: 75, y: 88, s: 1.3, r: 20, l: 'front'}, {x: 72, y: 80, s: 1, r: -35, l: 'mid'},
    
    // Fiori riempitivi
    {x: 40, y: 98, s: 1.1, r: 60, l: 'mid'}, {x: 45, y: 82, s: 0.8, r: -15, l: 'back'},
    {x: 55, y: 98, s: 1.2, r: -50, l: 'mid'}, {x: 60, y: 88, s: 1, r: 30, l: 'mid'},
    {x: 70, y: 98, s: 1.1, r: -5, l: 'mid'}, {x: 30, y: 85, s: 1.2, r: -25, l: 'mid'},
    {x: 80, y: 95, s: 1.4, r: 45, l: 'front'}, {x: 85, y: 85, s: 1, r: -10, l: 'mid'},
    {x: 25, y: 90, s: 1.1, r: 15, l: 'mid'}, {x: 28, y: 78, s: 0.8, r: 65, l: 'back'}
  ];

  const svgTemplate = `<svg viewBox="-45 -45 90 90" width="100%" height="100%"><use href="#synergy-flower" /></svg>`;

  flowerData.forEach((f, i) => {
    // Drop dei livelli non necessari su mobile (risparmia CPU)
    if(isMobile && (f.l === 'back' || f.l === 'front')) return;
    
    const layer = document.getElementById(`synergy-layer-${f.l}`);
    if(!layer) return;

    const el = document.createElement("div");
    el.className = "synergy-floral-item";
    el.style.left = `${f.x}%`;
    el.style.top = `${f.y}%`;
    el.style.transform = `scale(${f.s}) rotate(${f.r}deg)`;
    
    const delay = (i * 0.3) % 4; // Desincronizza le animazioni dei fiori
    const duration = 5 + (i % 3);
    el.innerHTML = `<div class="synergy-floral-flower-inner" style="animation-duration: ${duration}s; animation-delay: -${delay}s">${svgTemplate}</div>`;
    layer.appendChild(el);
  });

  // Generatore di petali in caduta
  const petalContainer = document.getElementById("synergy-layer-falling");
  if(petalContainer && !isReduced) {
    const numPetals = isMobile ? 6 : 14;
    for(let i = 0; i < numPetals; i++) {
      const p = document.createElement("div");
      p.className = "synergy-floral-petal-drop";
      
      const left = 15 + Math.random() * 70; // Cadono tra il 15% e l'85% dello schermo
      const dur = 10 + Math.random() * 8; // Caduta lentissima (10-18 secondi)
      const delay = Math.random() * 15;
      const drift = -20 + Math.random() * 40; // Traiettoria orizzontale
      const spinDur = 3 + Math.random() * 4;
      const scale = 0.5 + Math.random() * 0.4;
      
      p.style.left = `${left}%`;
      p.style.animationDuration = `${dur}s`;
      p.style.animationDelay = `-${delay}s`;
      p.style.setProperty('--synergy-drift', `${drift}vw`);
      
      p.innerHTML = `
        <div class="synergy-floral-petal-inner" style="animation-duration: ${spinDur}s; transform: scale(${scale});">
          <svg viewBox="-45 -45 90 90" width="100%" height="100%"><use href="#synergy-petal" /></svg>
        </div>
      `;
      petalContainer.appendChild(p);
    }
  }
});