<?php
/**
 * Template Name: Front Page
 */
get_header(); ?>

<main id="main" class="site-main">

    <!-- HERO SECTION (FLORAL ANIMATED) -->
    <section class="synergy-hero synergy-hero--light">
        
        <!-- HERO FOREGROUND CONTENT -->
        <?php
            // Ottieni dinamicamente i dati dal CMS (Slider 1). Il vecchio
            // video 4K viene sostituito da sorgenti web responsive, mentre un
            // eventuale video personalizzato impostato nel CMS resta valido.
            $legacy_hero_video_name = '514336_Flower_Flowers_3840x2160 (1).mp4';
            $configured_hero_video  = trim((string) get_option('ticinoweb_slider_image_1', ''));
            $configured_video_path  = $configured_hero_video ? wp_parse_url($configured_hero_video, PHP_URL_PATH) : '';
            $uses_default_video     = empty($configured_hero_video) || basename((string) $configured_video_path) === $legacy_hero_video_name;
            $hero_video_desktop     = get_stylesheet_directory_uri() . '/video/hero-flowers-720.m4v';
            $hero_video_mobile      = get_stylesheet_directory_uri() . '/video/hero-flowers-mobile.m4v';
            $hero_title = get_option('ticinoweb_slider_title_1', 'Bellezza, tecnologia e cura personalizzata in perfetta sinergia.');
            $hero_desc = get_option('ticinoweb_slider_desc_1', 'Trattamenti viso e corpo, tecnologie estetiche avanzate e percorsi su misura per valorizzare la tua pelle, la tua forma e il tuo benessere.');
        ?>
        
        <!-- HERO VIDEO BACKGROUND -->
        <div class="synergy-video-bg">
            <video autoplay muted loop playsinline preload="metadata" class="hero-video" id="hero-video" aria-hidden="true">
                <?php if ($uses_default_video) : ?>
                    <source media="(max-width: 767px)" src="<?php echo esc_url($hero_video_mobile); ?>" type="video/mp4">
                    <source src="<?php echo esc_url($hero_video_desktop); ?>" type="video/mp4">
                <?php else : ?>
                    <source src="<?php echo esc_url($configured_hero_video); ?>" type="video/mp4">
                <?php endif; ?>
            </video>
            <!-- OVERLAY (Silver/Light per leggibilità) -->
            <div class="synergy-hero-overlay"></div>
        </div>

        <?php
            $hero_btn_text = get_option('ticinoweb_slider_btn_text_1', 'Prenota una consulenza');
            $hero_btn_link = get_option('ticinoweb_slider_btn_link_1', home_url('/contatti/'));
        ?>
        <div class="container hero-container relative-z">
            <div class="hero-content reveal">
                <span class="hero-eyebrow"><?php echo esc_html( synergy_t( 'Estetica avanzata a Lugano', 'front:hero:eyebrow' ) ); ?></span>
                <h1 class="hero-title"><?php echo esc_html( synergy_t( $hero_title, 'front:hero:title' ) ); ?></h1>
                <p class="hero-subtitle"><?php echo esc_html( synergy_t( $hero_desc, 'front:hero:desc' ) ); ?></p>
                <div class="hero-ctas">
                    <?php if (!empty($hero_btn_text)) : ?>
                        <a href="<?php echo esc_url($hero_btn_link); ?>" class="btn btn-primary"><?php echo esc_html( synergy_t( $hero_btn_text, 'front:hero:btn_text' ) ); ?></a>
                    <?php endif; ?>
                    <a href="#trattamenti" class="btn btn-outline"><?php echo esc_html( synergy_t( 'Esplora i trattamenti', 'front:hero:btn_explore' ) ); ?></a>
                </div>
                <div class="hero-badges">
                    <span class="badge"><span class="badge-dot"></span> <?php echo esc_html( synergy_t( 'Analisi personalizzata', 'front:hero:badge:1' ) ); ?></span>
                    <span class="badge"><span class="badge-dot"></span> <?php echo esc_html( synergy_t( 'Tecnologie professionali', 'front:hero:badge:2' ) ); ?></span>
                    <span class="badge"><span class="badge-dot"></span> <?php echo esc_html( synergy_t( 'Trattamenti viso & corpo', 'front:hero:badge:3' ) ); ?></span>
                </div>
            </div>
        </div>
    </section>

    <!-- INTRO / POSIZIONAMENTO -->
    <section class="intro-section section">
        <div class="container">
            <div class="intro-text-wrap reveal">
                <h2><?php echo esc_html( synergy_t( 'Un nuovo modo di vivere l’estetica.', 'front:intro:title' ) ); ?></h2>
                <p><?php echo esc_html( synergy_t( 'Synergy Advanced Aesthetics nasce per offrire trattamenti estetici professionali, tecnologie avanzate e percorsi personalizzati in un ambiente curato, luminoso e accogliente. Ogni trattamento viene scelto con attenzione, partendo dall’ascolto della persona, dall’analisi della pelle e dagli obiettivi desiderati.', 'front:intro:text' ) ); ?></p>
            </div>
            <div class="intro-cards">
                <div class="intro-card reveal delay-1">
                    <div class="card-icon-silver">
                        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
                    </div>
                    <h3><?php echo esc_html( synergy_t( 'Consulenza', 'front:intro:card:1:title' ) ); ?></h3>
                    <p><?php echo esc_html( synergy_t( 'Analisi iniziale e ascolto delle esigenze.', 'front:intro:card:1:text' ) ); ?></p>
                </div>
                <div class="intro-card reveal delay-2">
                    <div class="card-icon-silver">
                        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"><polygon points="12 2 2 7 12 12 22 7 12 2"/><polyline points="2 12 12 17 22 12"/><polyline points="2 17 12 22 22 17"/></svg>
                    </div>
                    <h3><?php echo esc_html( synergy_t( 'Metodo', 'front:intro:card:2:title' ) ); ?></h3>
                    <p><?php echo esc_html( synergy_t( 'Percorsi personalizzati viso e corpo.', 'front:intro:card:2:text' ) ); ?></p>
                </div>
                <div class="intro-card reveal delay-3">
                    <div class="card-icon-silver">
                        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 3h12l4 6-10 13L2 9Z"/><path d="M11 3 8 9l4 13"/><path d="M13 3l3 6-4 13"/></svg>
                    </div>
                    <h3><?php echo esc_html( synergy_t( 'Risultato', 'front:intro:card:3:title' ) ); ?></h3>
                    <p><?php echo esc_html( synergy_t( 'Trattamenti mirati, costanza e cura professionale.', 'front:intro:card:3:text' ) ); ?></p>
                </div>
            </div>
        </div>
    </section>

    <!-- TRATTAMENTI PRINCIPALI -->
    <section id="trattamenti" class="trattamenti-section section">
        <div class="container">
            <div class="section-header text-center reveal">
                <h2><?php echo esc_html( synergy_t( 'Trattamenti pensati per viso, corpo e benessere.', 'front:services:title' ) ); ?></h2>
                <p><?php echo esc_html( synergy_t( 'Dalla cura della pelle ai percorsi rimodellanti, ogni servizio è studiato per offrire un’esperienza professionale, personalizzata e piacevole.', 'front:services:desc' ) ); ?></p>
            </div>
            
            <div class="trattamenti-grid">
                <?php
                $services = function_exists('ticinoweb_get_services') ? ticinoweb_get_services() : get_option('ticinoweb_services', []);
                if (!empty($services) && is_array($services)) :
                    $delay = 1;
                    foreach ($services as $index => $service) :
                        $num = str_pad($index + 1, 2, '0', STR_PAD_LEFT);
                        $title = !empty($service['title']) ? $service['title'] : '';
                        $desc = !empty($service['description']) ? $service['description'] : '';
                        $image = !empty($service['image']) ? $service['image'] : '';
                        if ($delay > 3) $delay = 1;
                ?>
                <?php
                /* La scheda diventa un link quando il servizio ha una destinazione
                   (CMS > Link schede servizi). Senza, resta un div: meglio non
                   cliccabile che cliccabile a vuoto. */
                $card_link = function_exists( 'synergy_get_service_link' ) ? synergy_get_service_link( $service ) : '';
                $card_tag  = $card_link ? 'a' : 'div';
                ?>
                <<?php echo $card_tag; ?> class="trattamento-card reveal delay-<?php echo esc_attr($delay); ?><?php echo $card_link ? ' is-link' : ''; ?>"<?php echo $card_link ? ' href="' . esc_url( $card_link ) . '"' : ''; ?>>
                    <div class="card-bg" style="<?php echo !empty($image) ? 'background-image: url(' . esc_url($image) . ');' : ''; ?>"></div>
                    <div class="card-content">
                        <span class="card-number"><?php echo esc_html($num); ?></span>
                        <h3><?php echo esc_html($title); ?></h3>
                        <p><?php echo esc_html($desc); ?></p>
                    <?php if ( $card_link ) : ?>
                        <span class="card-freccia" aria-hidden="true"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg></span>
                    <?php endif; ?>
                    </div>
                </<?php echo $card_tag; ?>>
                <?php
                        $delay++;
                    endforeach;
                else :
                ?>
                <!-- 01 -->
                <div class="trattamento-card reveal delay-1">
                    <div class="card-bg"></div>
                    <div class="card-content">
                        <span class="card-number">01</span>
                        <h3><?php echo esc_html( synergy_t( 'Trattamenti Viso', 'front:services:fallback:1:title' ) ); ?></h3>
                        <p><?php echo esc_html( synergy_t( 'Pulizia, anti-age, peeling, idratazione, acne, macchie e tecnologie per migliorare luminosità e qualità della pelle.', 'front:services:fallback:1:desc' ) ); ?></p>
                    </div>
                </div>
                <!-- 02 -->
                <div class="trattamento-card reveal delay-2">
                    <div class="card-bg"></div>
                    <div class="card-content">
                        <span class="card-number">02</span>
                        <h3><?php echo esc_html( synergy_t( 'Trattamenti Corpo', 'front:services:fallback:2:title' ) ); ?></h3>
                        <p><?php echo esc_html( synergy_t( 'Percorsi per cellulite, rimodellamento, drenaggio, tonificazione e miglioramento della silhouette.', 'front:services:fallback:2:desc' ) ); ?></p>
                    </div>
                </div>
                <!-- 03 -->
                <div class="trattamento-card reveal delay-3">
                    <div class="card-bg"></div>
                    <div class="card-content">
                        <span class="card-number">03</span>
                        <h3><?php echo esc_html( synergy_t( 'Tecnologie Estetiche', 'front:services:fallback:3:title' ) ); ?></h3>
                        <p><?php echo esc_html( synergy_t( 'Radiofrequenza, HIFU/SMAS, criolipolisi, cavitazione, pressoterapia, LED e altri sistemi professionali.', 'front:services:fallback:3:desc' ) ); ?></p>
                    </div>
                </div>
                <!-- 04 -->
                <div class="trattamento-card reveal delay-1">
                    <div class="card-bg"></div>
                    <div class="card-content">
                        <span class="card-number">04</span>
                        <h3><?php echo esc_html( synergy_t( 'Epilazione Laser', 'front:services:fallback:4:title' ) ); ?></h3>
                        <p><?php echo esc_html( synergy_t( 'Epilazione con laser diodo di ultima generazione per viso e corpo, anche per uomo.', 'front:services:fallback:4:desc' ) ); ?></p>
                    </div>
                </div>
                <!-- 05 -->
                <div class="trattamento-card reveal delay-2">
                    <div class="card-bg"></div>
                    <div class="card-content">
                        <span class="card-number">05</span>
                        <h3><?php echo esc_html( synergy_t( 'Mani & Piedi', 'front:services:fallback:5:title' ) ); ?></h3>
                        <p><?php echo esc_html( synergy_t( 'Manicure, pedicure, trattamenti SPA, semipermanente, gel e cura professionale di mani e piedi.', 'front:services:fallback:5:desc' ) ); ?></p>
                    </div>
                </div>
                <!-- 06 -->
                <div class="trattamento-card reveal delay-3">
                    <div class="card-bg"></div>
                    <div class="card-content">
                        <span class="card-number">06</span>
                        <h3><?php echo esc_html( synergy_t( 'Massaggi & Beauty', 'front:services:fallback:6:title' ) ); ?></h3>
                        <p><?php echo esc_html( synergy_t( 'Massaggi corpo, linfodrenaggio, ciglia, sopracciglia, trattamenti specifici e beauty essentials.', 'front:services:fallback:6:desc' ) ); ?></p>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </section>

    <!-- TECNOLOGIE -->
    <section class="tecnologie-section section">
        <!-- Animated Background -->
        <div class="tech-bg-animation">
            <!-- Texture Grana Fine -->
            <div class="tech-texture"></div>
            <!-- Glow Lati -->
            <div class="tech-glow tech-glow-left"></div>
            <div class="tech-glow tech-glow-right"></div>
            <!-- RF Concentric Circles -->
            <div class="tech-rf-circles">
                <div class="rf-circle rf-1"></div>
                <div class="rf-circle rf-2"></div>
                <div class="rf-circle rf-3"></div>
            </div>
            <!-- Onde Energetiche Sottili -->
            <svg class="tech-wave tech-wave-1" viewBox="0 0 1440 320" preserveAspectRatio="none"><path fill="none" stroke="rgba(255,255,255,0.06)" stroke-width="0.5" d="M0,160 C320,300,420,0,740,160 C1060,320,1120,60,1440,160"></path></svg>
            <svg class="tech-wave tech-wave-2" viewBox="0 0 1440 320" preserveAspectRatio="none"><path fill="none" stroke="rgba(200,200,200,0.04)" stroke-width="1" d="M0,160 C400,0,500,300,800,160 C1100,20,1200,300,1440,160"></path></svg>
            <!-- Particelle -->
            <div class="tech-particles">
                <div class="tech-particle p1"></div>
                <div class="tech-particle p2"></div>
                <div class="tech-particle p3"></div>
            </div>
        </div>

        <div class="container tecnologie-container relative-z">
            <div class="tecnologie-text reveal">
                <span class="tech-eyebrow"><?php echo esc_html( synergy_t( 'ESTETICA AVANZATA', 'front:tech:eyebrow' ) ); ?></span>
                <h2><?php echo wp_kses_post( synergy_t_html( 'Tecnologie avanzate,<br>approccio personalizzato.', 'front:tech:title' ) ); ?></h2>
                <p><?php echo esc_html( synergy_t( 'Un trattamento efficace nasce dalla combinazione tra esperienza manuale, tecnologie professionali e una valutazione attenta delle esigenze individuali.', 'front:tech:text' ) ); ?></p>
                <p class="tecnologie-small"><em><?php echo esc_html( synergy_t( 'La tecnologia non sostituisce il metodo: lo completa.', 'front:tech:small' ) ); ?></em></p>
                
                <div class="tech-badge">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2L2 7l10 5 10-5-10-5z"/><path d="M2 17l10 5 10-5"/><path d="M2 12l10 5 10-5"/></svg>
                    <span><?php echo esc_html( synergy_t( 'Analisi, metodo e tecnologia in sinergia', 'front:tech:badge' ) ); ?></span>
                </div>
            </div>
            
            <div class="tecnologie-list">
                <!-- 01 -->
                <div class="tech-item reveal delay-1">
                    <div class="tech-item-header">
                        <h4><?php echo esc_html( synergy_t( 'Radiofrequenza', 'front:tech:item:1:title' ) ); ?></h4>
                        <span class="tech-plus">+</span>
                    </div>
                    <div class="tech-desc">
                        <p><?php echo esc_html( synergy_t( 'Migliora tono, compattezza e qualità della pelle.', 'front:tech:item:1:desc' ) ); ?></p>
                    </div>
                </div>
                <!-- 02 -->
                <div class="tech-item reveal delay-2">
                    <div class="tech-item-header">
                        <h4><?php echo esc_html( synergy_t( 'HIFU / SMAS Lifting', 'front:tech:item:2:title' ) ); ?></h4>
                        <span class="tech-plus">+</span>
                    </div>
                    <div class="tech-desc">
                        <p><?php echo esc_html( synergy_t( 'Trattamento mirato per un effetto lifting non invasivo.', 'front:tech:item:2:desc' ) ); ?></p>
                    </div>
                </div>
                <!-- 03 -->
                <div class="tech-item reveal delay-3">
                    <div class="tech-item-header">
                        <h4><?php echo esc_html( synergy_t( 'Criolipolisi', 'front:tech:item:3:title' ) ); ?></h4>
                        <span class="tech-plus">+</span>
                    </div>
                    <div class="tech-desc">
                        <p><?php echo esc_html( synergy_t( 'Tecnologia per il trattamento localizzato degli accumuli adiposi.', 'front:tech:item:3:desc' ) ); ?></p>
                    </div>
                </div>
                <!-- 04 -->
                <div class="tech-item reveal delay-1">
                    <div class="tech-item-header">
                        <h4><?php echo esc_html( synergy_t( 'Pressoterapia', 'front:tech:item:4:title' ) ); ?></h4>
                        <span class="tech-plus">+</span>
                    </div>
                    <div class="tech-desc">
                        <p><?php echo esc_html( synergy_t( 'Favorisce drenaggio, leggerezza e benessere delle gambe.', 'front:tech:item:4:desc' ) ); ?></p>
                    </div>
                </div>
                <!-- 05 -->
                <div class="tech-item reveal delay-2">
                    <div class="tech-item-header">
                        <h4><?php echo esc_html( synergy_t( 'Cavitazione', 'front:tech:item:5:title' ) ); ?></h4>
                        <span class="tech-plus">+</span>
                    </div>
                    <div class="tech-desc">
                        <p><?php echo esc_html( synergy_t( 'Supporta i percorsi rimodellanti e il trattamento degli inestetismi.', 'front:tech:item:5:desc' ) ); ?></p>
                    </div>
                </div>
                <!-- 06 -->
                <div class="tech-item reveal delay-3">
                    <div class="tech-item-header">
                        <h4><?php echo esc_html( synergy_t( 'LED Therapy', 'front:tech:item:6:title' ) ); ?></h4>
                        <span class="tech-plus">+</span>
                    </div>
                    <div class="tech-desc">
                        <p><?php echo esc_html( synergy_t( 'Luce professionale per supportare pelle, luminosità e rigenerazione.', 'front:tech:item:6:desc' ) ); ?></p>
                    </div>
                </div>
                <!-- 07 -->
                <div class="tech-item reveal delay-1">
                    <div class="tech-item-header">
                        <h4><?php echo esc_html( synergy_t( 'Cold Plasma', 'front:tech:item:7:title' ) ); ?></h4>
                        <span class="tech-plus">+</span>
                    </div>
                    <div class="tech-desc">
                        <p><?php echo esc_html( synergy_t( 'Tecnologia avanzata per trattamenti mirati della pelle.', 'front:tech:item:7:desc' ) ); ?></p>
                    </div>
                </div>
                <!-- 08 -->
                <div class="tech-item reveal delay-2">
                    <div class="tech-item-header">
                        <h4><?php echo esc_html( synergy_t( 'Epilazione laser diodo', 'front:tech:item:8:title' ) ); ?></h4>
                        <span class="tech-plus">+</span>
                    </div>
                    <div class="tech-desc">
                        <p><?php echo esc_html( synergy_t( 'Soluzione professionale per una pelle liscia più a lungo.', 'front:tech:item:8:desc' ) ); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- METODO TIMELINE -->
    <section class="metodo-section section">
        <!-- Abstract Background Layer -->
        <div class="metodo-bg">
            <div class="metodo-texture"></div>
            <div class="metodo-glow"></div>
        </div>

        <div class="container text-center reveal relative-z">
            <h2><?php echo esc_html( synergy_t( 'Ogni percorso inizia dall’ascolto.', 'front:metodo:title' ) ); ?></h2>
            <p class="metodo-subtitle"><?php echo esc_html( synergy_t( 'Un metodo pensato per accompagnarti con attenzione, chiarezza e continuità, dal primo incontro fino al mantenimento dei risultati.', 'front:metodo:subtitle' ) ); ?></p>
        </div>
        
        <div class="container timeline-container relative-z">
            <div class="timeline-steps">
                <!-- Step 1 -->
                <div class="timeline-step reveal delay-1">
                    <div class="step-card">
                        <div class="step-watermark">01</div>
                        <div class="step-card-header">
                            <span class="step-pill"><?php echo esc_html( synergy_t( 'Fase 01', 'front:metodo:step:1:pill' ) ); ?></span>
                            <div class="step-icon">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>
                            </div>
                        </div>
                        <h3><?php echo esc_html( synergy_t( 'Analisi', 'front:metodo:step:1:title' ) ); ?></h3>
                        <p><?php echo esc_html( synergy_t( 'Ascoltiamo le tue esigenze e valutiamo pelle, corpo, abitudini e obiettivi.', 'front:metodo:step:1:text' ) ); ?></p>
                    </div>
                </div>
                <!-- Step 2 -->
                <div class="timeline-step reveal delay-2">
                    <div class="step-card">
                        <div class="step-watermark">02</div>
                        <div class="step-card-header">
                            <span class="step-pill"><?php echo esc_html( synergy_t( 'Fase 02', 'front:metodo:step:2:pill' ) ); ?></span>
                            <div class="step-icon">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M12 20h9"></path><path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"></path></svg>
                            </div>
                        </div>
                        <h3><?php echo esc_html( synergy_t( 'Consulenza', 'front:metodo:step:2:title' ) ); ?></h3>
                        <p><?php echo esc_html( synergy_t( 'Definiamo un percorso realistico, personalizzato e adatto al tuo ritmo.', 'front:metodo:step:2:text' ) ); ?></p>
                    </div>
                </div>
                <!-- Step 3 -->
                <div class="timeline-step reveal delay-3">
                    <div class="step-card">
                        <div class="step-watermark">03</div>
                        <div class="step-card-header">
                            <span class="step-pill"><?php echo esc_html( synergy_t( 'Fase 03', 'front:metodo:step:3:pill' ) ); ?></span>
                            <div class="step-icon">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><path d="M12 8v4l3 3"></path></svg>
                            </div>
                        </div>
                        <h3><?php echo esc_html( synergy_t( 'Trattamento', 'front:metodo:step:3:title' ) ); ?></h3>
                        <p><?php echo esc_html( synergy_t( 'Uniamo manualità, tecnologie professionali e prodotti selezionati.', 'front:metodo:step:3:text' ) ); ?></p>
                    </div>
                </div>
                <!-- Step 4 -->
                <div class="timeline-step reveal delay-4">
                    <div class="step-card">
                        <div class="step-watermark">04</div>
                        <div class="step-card-header">
                            <span class="step-pill"><?php echo esc_html( synergy_t( 'Fase 04', 'front:metodo:step:4:pill' ) ); ?></span>
                            <div class="step-icon">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"></path></svg>
                            </div>
                        </div>
                        <h3><?php echo esc_html( synergy_t( 'Mantenimento', 'front:metodo:step:4:title' ) ); ?></h3>
                        <p><?php echo esc_html( synergy_t( 'Ti accompagniamo con consigli e routine per continuare la cura anche a casa.', 'front:metodo:step:4:text' ) ); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- CHI SIAMO PREVIEW -->
    <?php
        $chi_siamo_title = get_option('ticinoweb_chi_siamo_title', 'Professionalità, esperienza e attenzione alla persona.');
        $chi_siamo_text = get_option('ticinoweb_chi_siamo_text', 'Da Synergy Advanced Aesthetics ogni trattamento nasce dall’ascolto. Uniamo competenza estetica, tecnologie professionali e cura del dettaglio per accompagnarti in percorsi viso e corpo personalizzati, pensati per valorizzare la tua bellezza in modo naturale e armonioso.');
        $chi_siamo_img = get_option('ticinoweb_chi_siamo_image');
        $chi_siamo_link = get_option('ticinoweb_chi_siamo_link', home_url('/chi-siamo/'));
        
        // Fetch dynamic image from Gallery 4
        $gallery_image_url = '';
        $gallery_query = new WP_Query(array(
            'post_type'      => 'attachment',
            'post_status'    => 'inherit',
            'posts_per_page' => 1,
            'tax_query' => array(
                array(
                    'taxonomy' => 'ticinoweb_media_gallery',
                    'field' => 'term_id',
                    'terms' => 4,
                )
            )
        ));

        if ( $gallery_query->have_posts() ) {
            $saved_order = get_term_meta(4, '_ticinoweb_gallery_order', true);
            if ( ! is_array( $saved_order ) ) {
                $saved_order = array();
            }
            if ( ! empty( $saved_order ) ) {
                usort( $gallery_query->posts, function ( $a, $b ) use ( $saved_order ) {
                    $posA = array_search( $a->ID, $saved_order );
                    $posB = array_search( $b->ID, $saved_order );
                    if ( $posA === false ) $posA = 999999;
                    if ( $posB === false ) $posB = 999999;
                    return $posA - $posB;
                });
            }
            $gallery_image_url = wp_get_attachment_image_url($gallery_query->posts[0]->ID, 'large');
        }
        wp_reset_postdata();

        // Fallback to CMS option if gallery is empty
        if (empty($gallery_image_url)) {
            $gallery_image_url = '';
        }
    ?>
    <section class="chisiamo-preview section">
        <!-- Background elements -->
        <div class="chisiamo-bg">
            <?php if (!empty($gallery_image_url)): ?>
                <div class="chisiamo-decoration" style="background: url('<?php echo esc_url($gallery_image_url); ?>') center/contain no-repeat;"></div>
            <?php endif; ?>
            <div class="chisiamo-texture"></div>
            <div class="chisiamo-glow"></div>
        </div>

        <div class="container chisiamo-container relative-z">
            <div class="chisiamo-visual reveal">
                <!-- Visual composition -->
                <div class="visual-main">
                    <div class="chisiamo-placeholder-premium" <?php if (!empty($chi_siamo_img)) echo 'style="background-image: url(\'' . esc_url($chi_siamo_img) . '\'); background-size: cover; background-position: center; background-repeat: no-repeat;"'; ?>></div>
                    <div class="visual-frame"></div>
                    <div class="visual-badge parallax-element">
                        <span class="badge-icon">
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path></svg>
                        </span>
                        <span class="badge-text"><?php echo esc_html( synergy_t( 'Estetista AFC', 'front:chisiamo:badge' ) ); ?></span>
                    </div>
                </div>
            </div>
            
            <div class="chisiamo-content reveal delay-2">
                <span class="section-eyebrow"><?php echo esc_html( synergy_t( 'CHI SIAMO', 'front:chisiamo:eyebrow' ) ); ?></span>
                <h2><?php echo esc_html( synergy_t( $chi_siamo_title, 'front:chisiamo:title' ) ); ?></h2>
                <p class="content-lead"><?php echo esc_html( synergy_t( $chi_siamo_text, 'front:chisiamo:text' ) ); ?></p>
                
                <div class="trust-points">
                    <div class="trust-point">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="3" width="20" height="14" rx="2" ry="2"></rect><line x1="8" y1="21" x2="16" y2="21"></line><line x1="12" y1="17" x2="12" y2="21"></line></svg>
                        <span><?php echo esc_html( synergy_t( 'Tecnologie professionali', 'front:chisiamo:trust:1' ) ); ?></span>
                    </div>
                    <div class="trust-point">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"></path></svg>
                        <span><?php echo esc_html( synergy_t( 'Cura viso & corpo', 'front:chisiamo:trust:2' ) ); ?></span>
                    </div>
                </div>
                
                <div class="chisiamo-actions">
                    <a href="<?php echo esc_url($chi_siamo_link); ?>" class="btn btn-pill"><?php echo esc_html( synergy_t( 'Conosci il centro', 'front:chisiamo:btn' ) ); ?></a>
                </div>
            </div>
        </div>
    </section>

    <!-- TEAM SECTION -->
    <?php
        // Recupera dati dinamici gestiti dal backend "IL TEAM"
        $team_eyebrow     = get_option( 'synergy_team_eyebrow', 'IL TEAM' );
        $team_title       = get_option( 'synergy_team_title', 'Le professioniste dietro ogni percorso.' );
        $team_description = get_option( 'synergy_team_description', 'Ogni trattamento nasce dall’ascolto, dall’esperienza e da una cura autentica per la persona. Da Synergy Advanced Aesthetics trovi competenze professionali, discrezione e un approccio su misura per accompagnarti con fiducia in ogni fase del tuo percorso estetico.' );
        $team_members     = synergy_get_team_members();

        // Recupera eventuali immagini di fallback dalla galleria media (se photo non è specificata)
        $fallback_images = array();
        $team_gallery_id = 3;
        $team_query = new WP_Query(array(
            'post_type'      => 'attachment',
            'post_status'    => 'inherit',
            'posts_per_page' => 10,
            'tax_query' => array(
                array(
                    'taxonomy' => 'ticinoweb_media_gallery',
                    'field'    => 'term_id',
                    'terms'    => $team_gallery_id,
                )
            )
        ));
        if ( $team_query->have_posts() ) {
            $saved_order = get_term_meta($team_gallery_id, '_ticinoweb_gallery_order', true);
            if ( is_array($saved_order) && ! empty($saved_order) ) {
                usort( $team_query->posts, function ( $a, $b ) use ( $saved_order ) {
                    $posA = array_search( $a->ID, $saved_order );
                    $posB = array_search( $b->ID, $saved_order );
                    if ( $posA === false ) $posA = 999999;
                    if ( $posB === false ) $posB = 999999;
                    return $posA - $posB;
                });
            }
            foreach ($team_query->posts as $post) {
                $fallback_images[] = wp_get_attachment_image_url($post->ID, 'large');
            }
        }
        wp_reset_postdata();
    ?>
    <section class="team-section section">
        <div class="team-bg">
            <div class="team-glow"></div>
        </div>
        <div class="container relative-z">
            <!-- Header -->
            <div class="team-header reveal">
                <?php if ( ! empty( $team_eyebrow ) ) : ?>
                    <span class="section-eyebrow"><?php echo esc_html( synergy_t( $team_eyebrow, 'front:team:eyebrow' ) ); ?></span>
                <?php endif; ?>
                <?php if ( ! empty( $team_title ) ) : ?>
                    <h2><?php echo esc_html( synergy_t( $team_title, 'front:team:title' ) ); ?></h2>
                <?php endif; ?>
                <?php if ( ! empty( $team_description ) ) : ?>
                    <p><?php echo esc_html( synergy_t( $team_description, 'front:team:desc' ) ); ?></p>
                <?php endif; ?>
            </div>
            
            <!-- Cards Dinamiche -->
            <div class="team-grid">
                <?php 
                if ( ! empty( $team_members ) ) :
                    foreach ( $team_members as $index => $member ) :
                        $m_name  = isset( $member['name'] ) ? $member['name'] : '';
                        $m_role  = isset( $member['role'] ) ? $member['role'] : '';
                        $m_title = isset( $member['title'] ) ? $member['title'] : '';
                        $m_bio   = isset( $member['bio'] ) ? $member['bio'] : '';
                        $m_photo = ! empty( $member['photo'] ) ? $member['photo'] : ( isset( $fallback_images[$index] ) ? $fallback_images[$index] : '' );
                        
                        // Genera monogramma per il placeholder se manca la foto
                        $initials = '';
                        if ( ! empty( $m_name ) ) {
                            $parts = explode( ' ', trim( $m_name ) );
                            foreach ( $parts as $p ) {
                                $initials .= mb_substr( $p, 0, 1 );
                            }
                            $initials = mb_substr( $initials, 0, 2 );
                        }
                        
                        $delay_class = 'delay-' . ( ( $index % 4 ) + 1 );
                        ?>
                        <div class="team-card reveal <?php echo esc_attr( $delay_class ); ?>">
                            <div class="team-portrait-wrapper">
                                <?php if ( ! empty( $m_photo ) ) : ?>
                                    <div class="team-portrait" style="background-image: url('<?php echo esc_url( $m_photo ); ?>');"></div>
                                <?php else : ?>
                                    <div class="team-portrait team-placeholder">
                                        <span><?php echo esc_html( strtoupper( $initials ) ); ?></span>
                                    </div>
                                <?php endif; ?>
                                <div class="team-frame"></div>
                            </div>
                            <div class="team-info-box parallax-element">
                                <div class="info-content">
                                    <h3><?php echo esc_html( $m_name ); ?></h3>
                                    <?php if ( ! empty( $m_role ) ) : ?>
                                        <span class="team-role"><?php echo esc_html( synergy_t( $m_role, 'front:team:member:' . sanitize_title( $m_name ) . ':role' ) ); ?></span>
                                    <?php endif; ?>
                                    <?php if ( ! empty( $m_title ) ) : ?>
                                        <span class="team-subrole"><?php echo esc_html( synergy_t( $m_title, 'front:team:member:' . sanitize_title( $m_name ) . ':title' ) ); ?></span>
                                    <?php endif; ?>
                                    <?php
                                    /* Le qualifiche arrivano dal campo "Qualifiche e formazione"
                                       del pannello IL TEAM: una riga per voce. */
                                    $m_bio_lines = array_values( array_filter( array_map( 'trim', preg_split( '/\r\n|\r|\n/', (string) $m_bio ) ), 'strlen' ) );
                                    if ( $m_bio_lines ) : ?>
                                        <ul class="team-qualifiche">
                                            <?php foreach ( $m_bio_lines as $bi => $riga ) : ?>
                                                <li><?php echo esc_html( synergy_t( $riga, 'team:member:' . sanitize_title( $m_name ) . ':bio:' . $bi ) ); ?></li>
                                            <?php endforeach; ?>
                                        </ul>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    <?php 
                    endforeach;
                endif; 
                ?>
            </div>

        </div>
    </section>
            
            <!-- Optional CTA -->
            <div class="team-footer reveal delay-3">
                <a href="<?php echo esc_url(home_url('/chi-siamo/')); ?>" class="link-secondary"><?php echo esc_html( synergy_t( 'Scopri di più su di noi', 'front:team:btn_more' ) ); ?></a>
            </div>
        </div>
    </section>

    <!-- PRODOTTI & TECNOLOGIE -->
    <?php
    $pt_data = get_option('synergy_products_technologies_data');
    if (empty($pt_data) || empty($pt_data['items'])) {
        $pt_data = array(
            'section_title' => 'Prodotti e tecnologie professionali per la tua cura.',
            'section_description' => 'Nel centro selezioniamo prodotti cosmetici professionali e tecnologie estetiche avanzate per accompagnare ogni trattamento con qualità, precisione e attenzione alle esigenze della persona.',
            'items' => array()
        );
    }
    
    $title = !empty($pt_data['section_title']) ? $pt_data['section_title'] : 'Prodotti e tecnologie professionali per la tua cura.';
    $desc = !empty($pt_data['section_description']) ? $pt_data['section_description'] : '';
    
    // Group items by category
    $categories = array(
        'Prodotti professionali' => array(),
        'Tecnologia estetica' => array(),
        'Trattamenti Professionali' => array()
    );
    
    if (!empty($pt_data['items'])) {
        foreach ($pt_data['items'] as $item) {
            if (!isset($item['active']) || $item['active']) {
                $cat = $item['category'];
                if (isset($categories[$cat])) {
                    $categories[$cat][] = $item;
                }
            }
        }
    }
    
    // Only keep non-empty categories
    $active_categories = array_filter($categories, function($cat_items) {
        return !empty($cat_items);
    });
    ?>
    <section id="tecnologie" class="prodotti-tecnologie section bg-ivory relative" style="position: relative; overflow: hidden;">
        <div class="synergy-products-tech-bg" aria-hidden="true">
            <!-- Glows -->
            <div class="synergy-products-tech-glow glow-top"></div>
            <div class="synergy-products-tech-glow glow-bottom"></div>
            <!-- Fluid Forms -->
            <div class="synergy-products-tech-orb orb-1"></div>
            <div class="synergy-products-tech-orb orb-2"></div>
            <!-- Molecules Container -->
            <div class="synergy-products-tech-molecules" id="synergy-molecules"></div>
        </div>
        
        <div class="container relative z-10" style="position: relative; z-index: 10;">
            <div class="section-header text-center reveal">
                <span class="eyebrow"><?php echo esc_html( synergy_t( 'PRODOTTI & TECNOLOGIE', 'front:pt:eyebrow' ) ); ?></span>
                <h2 style="margin-bottom: 15px;"><?php echo esc_html( synergy_t( $title, 'front:pt:title' ) ); ?></h2>
                <?php if ($desc): ?>
                    <p class="section-desc" style="max-width: 600px; margin: 0 auto 40px;"><?php echo esc_html( synergy_t( $desc, 'front:pt:desc' ) ); ?></p>
                <?php endif; ?>
            </div>
            
            <?php if (!empty($active_categories)): ?>
                <!-- TABS -->
                <div class="pt-tabs-container reveal delay-1" style="display: flex; justify-content: center; margin-bottom: 40px;">
                    <div class="pt-tabs" style="display: inline-flex; background: #fff; padding: 5px; border-radius: 50px; border: 1px solid rgba(206,189,173,0.3); box-shadow: 0 4px 15px rgba(0,0,0,0.02);">
                        <?php 
                        $first_cat = true;
                        foreach ($active_categories as $cat_name => $cat_items): 
                            $tab_id = sanitize_title($cat_name);
                        ?>
                            <button type="button" class="pt-tab-btn <?php echo $first_cat ? 'active' : ''; ?>" data-target="<?php echo esc_attr($tab_id); ?>">
                                <?php echo esc_html( synergy_t( $cat_name, 'front:pt:category:' . sanitize_title( $cat_name ) ) ); ?>
                            </button>
                        <?php 
                        $first_cat = false;
                        endforeach; 
                        ?>
                    </div>
                </div>

                <!-- PANELS -->
                <div class="pt-panels-container reveal delay-2">
                    <?php 
                    $first_panel = true;
                    foreach ($active_categories as $cat_name => $cat_items): 
                        $tab_id = sanitize_title($cat_name);
                    ?>
                        <div class="pt-panel <?php echo $first_panel ? 'active' : ''; ?>" id="panel-<?php echo esc_attr($tab_id); ?>">
                            <div class="pt-grid">
                                <?php 
                                $count = 0;
                                foreach ($cat_items as $item): 
                                    $count++;
                                    $hidden_class = $count > 6 ? 'hidden-card' : '';
                                    $item_key = 'front:pt:item:' . sanitize_title( $item['name'] );
                                    
                                    $icon_svg = '';
                                    if ($cat_name === 'Prodotti professionali') {
                                        $icon_svg = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"/></svg>';
                                    } elseif ($cat_name === 'Tecnologia estetica') {
                                        $icon_svg = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><rect x="2" y="3" width="20" height="14" rx="2" ry="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/></svg>';
                                    } else {
                                        $icon_svg = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>';
                                    }
                                ?>
                                    <div class="pt-card <?php echo $hidden_class; ?>">
                                        <div class="pt-card-header">
                                            <div class="pt-icon"><?php echo $icon_svg; ?></div>
                                            <span class="pt-area"><?php echo esc_html( synergy_t( $item['area'], $item_key . ':area' ) ); ?></span>
                                        </div>
                                        <h3 class="pt-name"><?php echo esc_html( synergy_t( $item['name'], $item_key . ':name' ) ); ?></h3>
                                        <p class="pt-desc"><?php echo esc_html( synergy_t( $item['description'], $item_key . ':desc' ) ); ?></p>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                            
                            <?php if (count($cat_items) > 6): ?>
                                <div class="pt-actions text-center" style="margin-top: 40px;">
                                    <button class="btn btn-outline pt-mostra-tutto" data-target="panel-<?php echo esc_attr($tab_id); ?>"><?php echo esc_html( synergy_t( 'Mostra tutto', 'front:pt:show_all' ) ); ?></button>
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php 
                    $first_panel = false;
                    endforeach; 
                    ?>
                </div>
            <?php endif; ?>
        </div>
    </section>

    <!-- LISTINO PREZZI VISO -->
    <?php synergy_render_home_price_list(); ?>

    <?php
    /*
     * La sezione Promozioni e' stata rimossa dalla home su richiesta della
     * cliente (21.09.2026): la promozione resta solo come popup, reso da
     * inc/promo-popup.php. L'interruttore CMS `ticinoweb_disable_promozioni`
     * continua a governare il popup, quindi la promozione si accende e si
     * spegne dal backend come prima — cambia solo dove appare.
     */
    ?>

    <!-- BLOG / ARTICOLI SECTION -->
    <section id="blog" class="synergy-blog-section section relative">
        <div class="blog-bg-glow"></div>
        <div class="container relative-z">
            
            <!-- Header Sezione -->
            <div class="blog-section-header reveal text-center">
                <span class="section-eyebrow"><?php echo esc_html( synergy_t( 'IL NOSTRO BLOG', 'front:blog:eyebrow' ) ); ?></span>
                <h2 class="section-title"><?php echo esc_html( synergy_t( 'Consigli, approfondimenti e novità di bellezza.', 'front:blog:title' ) ); ?></h2>
                <p class="section-subtitle"><?php echo esc_html( synergy_t( 'Scopri gli articoli delle nostre professioniste dedicati alla cura della pelle, ai benefici delle tecnologie estetiche e ai rituali di benessere.', 'front:blog:subtitle' ) ); ?></p>
            </div>

            <!-- Griglia Articoli -->
            <?php
            $blog_query = new WP_Query( array(
                'post_type'      => 'post',
                'posts_per_page' => 3,
                'post_status'    => 'publish',
                'orderby'        => 'date',
                'order'          => 'DESC',
            ) );

            if ( $blog_query->have_posts() ) : ?>
                <div class="synergy-blog-grid">
                    <?php 
                    $card_idx = 0;
                    while ( $blog_query->have_posts() ) : $blog_query->the_post(); 
                        $card_idx++;
                        $categories = get_the_category();
                        $cat_name = ! empty( $categories ) ? $categories[0]->name : synergy_t( 'Bellezza & Benessere', 'front:blog:category_fallback' );
                        $has_thumb = has_post_thumbnail();
                        $thumb_url = $has_thumb ? get_the_post_thumbnail_url( get_the_ID(), 'large' ) : '';
                        $reading_time = max( 1, ceil( str_word_count( wp_strip_all_tags( get_the_content() ) ) / 200 ) );
                        ?>
                        <article class="synergy-blog-card reveal delay-<?php echo esc_attr( ( $card_idx % 3 ) + 1 ); ?>">
                            <a href="<?php the_permalink(); ?>" class="blog-card-thumb-link" aria-label="<?php the_title_attribute(); ?>">
                                <div class="blog-card-thumb-wrapper">
                                    <?php if ( $thumb_url ) : ?>
                                        <div class="blog-card-thumb" style="background-image: url('<?php echo esc_url( $thumb_url ); ?>');"></div>
                                    <?php else : ?>
                                        <div class="blog-card-thumb blog-thumb-placeholder">
                                            <div class="thumb-pattern"></div>
                                            <span class="placeholder-icon">
                                                <svg width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M12 2L2 7l10 5 10-5-10-5z"/><path d="M2 17l10 5 10-5"/><path d="M2 12l10 5 10-5"/></svg>
                                            </span>
                                        </div>
                                    <?php endif; ?>
                                    <span class="blog-card-badge"><?php echo esc_html( $cat_name ); ?></span>
                                </div>
                            </a>

                            <div class="blog-card-body">
                                <div class="blog-card-meta">
                                    <span class="blog-date">
                                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line></svg>
                                        <?php echo get_the_date( 'd M Y' ); ?>
                                    </span>
                                    <span class="blog-meta-sep">•</span>
                                    <span class="blog-read-time"><?php echo esc_html( sprintf( synergy_t( '%d min lettura', 'front:blog:read_time' ), $reading_time ) ); ?></span>
                                </div>

                                <h3 class="blog-card-title">
                                    <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                                </h3>

                                <p class="blog-card-excerpt">
                                    <?php 
                                    if ( has_excerpt() ) {
                                        echo esc_html( wp_trim_words( get_the_excerpt(), 18, '…' ) );
                                    } else {
                                        echo esc_html( wp_trim_words( get_the_content(), 18, '…' ) );
                                    }
                                    ?>
                                </p>

                                <div class="blog-card-footer">
                                    <a href="<?php the_permalink(); ?>" class="blog-read-more">
                                        <span><?php echo esc_html( synergy_t( "Leggi l'articolo", 'front:blog:read_more' ) ); ?></span>
                                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg>
                                    </a>
                                </div>
                            </div>
                        </article>
                    <?php endwhile; ?>
                </div>
            <?php 
            wp_reset_postdata();
            endif; 
            ?>

        </div>
    </section>

    <!-- CONTATTI -->
    <?php
    $cms_name    = get_option('ticinoweb_site_name') ?: 'Synergy Advanced Aesthetics';
    $cms_address = get_option('ticinoweb_contact_address') ?: "Via Generale Guisan 10<br>Paradiso, Lugano";
    $cms_phone   = get_option('ticinoweb_contact_phone') ?: '+41 (0)79 288 61 77';
    // Clean phone for link
    $clean_phone = preg_replace('/[^0-9+]/', '', str_replace('(0)', '', $cms_phone));
    
    // Map link
    $map_link = "https://maps.google.com/?q=" . urlencode(str_replace('<br>', ', ', $cms_address));
    ?>
    <section id="contatti" class="contatti-section section bg-ivory relative" style="position: relative; z-index: 1;">
        <!-- Decorazioni di sfondo leggere -->
        <div class="contatti-bg-pattern" style="position: absolute; inset: 0; pointer-events: none; opacity: 0.3; background-image: radial-gradient(rgba(206,189,173,0.4) 1px, transparent 1px); background-size: 30px 30px;"></div>
        <div class="contatti-bg-glow" style="position: absolute; right: 0; top: 20%; width: 50%; height: 60%; background: radial-gradient(circle, rgba(230,215,189,0.15) 0%, rgba(255,255,255,0) 70%); filter: blur(50px); pointer-events: none;"></div>

        <div class="container contatti-grid relative" style="z-index: 2;">
            
            <!-- Colonna Sinistra (Testi e Card) -->
            <div class="contatti-content reveal">
                <span class="eyebrow"><?php echo esc_html( synergy_t( 'DOVE SIAMO', 'front:contatti:eyebrow' ) ); ?></span>
                <h2 class="contatti-title"><?php echo esc_html( synergy_t( 'Ti aspettiamo nel cuore di Paradiso, a pochi minuti da Lugano.', 'front:contatti:title' ) ); ?></h2>
                <p class="contatti-desc"><?php echo esc_html( synergy_t( 'Un ambiente elegante, discreto e accogliente, pensato per accompagnarti in ogni trattamento con attenzione, professionalità e cura.', 'front:contatti:desc' ) ); ?></p>
                
                <div class="contact-cards-grid">
                    <!-- Card 1: Indirizzo -->
                    <div class="contact-card">
                        <div class="cc-icon">
                            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path><circle cx="12" cy="10" r="3"></circle></svg>
                        </div>
                        <div class="cc-text">
                            <h4><?php echo esc_html( synergy_t( 'Indirizzo', 'front:contatti:card:indirizzo:title' ) ); ?></h4>
                            <p><strong><?php echo esc_html($cms_name); ?></strong><br>
                               <?php echo wp_kses_post( synergy_t_html( $cms_address, 'front:contatti:address' ) ); ?>
                            </p>
                        </div>
                    </div>
                    
                    <!-- Card 2: Telefono -->
                    <div class="contact-card">
                        <div class="cc-icon">
                            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path></svg>
                        </div>
                        <div class="cc-text">
                            <h4><?php echo esc_html( synergy_t( 'Telefono', 'front:contatti:card:telefono:title' ) ); ?></h4>
                            <p><a href="tel:<?php echo esc_attr($clean_phone); ?>" class="contact-link"><?php echo esc_html($cms_phone); ?></a></p>
                        </div>
                    </div>
                    
                    <!-- Card 3: Orari -->
                    <div class="contact-card">
                        <div class="cc-icon">
                            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 16 14"></polyline></svg>
                        </div>
                        <div class="cc-text">
                            <h4><?php echo esc_html( synergy_t( 'Orari', 'front:contatti:card:orari:title' ) ); ?></h4>
                            <p><?php echo synergy_get_formatted_hours(); ?></p>
                        </div>
                    </div>
                    
                    <!-- Card 4: Prenotazione -->
                    <div class="contact-card">
                        <div class="cc-icon">
                            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line></svg>
                        </div>
                        <div class="cc-text">
                            <h4><?php echo esc_html( synergy_t( 'Prenotazione', 'front:contatti:card:prenotazione:title' ) ); ?></h4>
                            <p><?php echo esc_html( synergy_t( 'Si riceve esclusivamente su appuntamento.', 'front:contatti:card:prenotazione:text' ) ); ?></p>
                        </div>
                    </div>
                </div>
                

            </div>
            
            <!-- Colonna Destra (Mappa Premium) -->
            <div class="contatti-map-col reveal delay-2">
                <div class="premium-map-placeholder">
                    <?php 
                    $map_query = urlencode(str_replace('<br>', ', ', $cms_address));
                    // Lingua dell'interfaccia mappa: segue la lingua corrente del sito,
                    // italiano come default quando tW Translate Plus non e' attivo.
                    $map_lang = function_exists('twtr_get_current_language') ? twtr_get_current_language() : 'it';
                    ?>
                    <iframe src="https://maps.google.com/maps?q=<?php echo $map_query; ?>&t=&z=15&hl=<?php echo esc_attr($map_lang); ?>&ie=UTF8&iwloc=&output=embed" width="100%" height="100%" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                </div>
            </div>
            
        </div>
    </section>



</main>

<?php get_footer(); ?>
