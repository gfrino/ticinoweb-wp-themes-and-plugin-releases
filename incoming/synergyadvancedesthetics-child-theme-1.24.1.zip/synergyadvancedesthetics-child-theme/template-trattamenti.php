<?php
/**
 * Template Name: Trattamenti (indice)
 * Description: Indice dei trattamenti generato dal menu di navigazione.
 *
 * La fonte dei dati e' il MENU, non un elenco scritto qui: aggiungendo,
 * togliendo o riordinando una voce sotto "Trattamenti" la pagina si aggiorna
 * da sola. Titoli, immagini e descrizioni arrivano dalle pagine collegate
 * (titolo, immagine in evidenza, meta description del parent theme), quindi
 * non c'e' nessun testo da tenere allineato a mano.
 *
 * @package SynergyAdvancedAesthetics
 */

get_header();

/**
 * Ricostruisce il ramo di menu che punta a questa pagina.
 *
 * @param int $page_id ID della pagina corrente.
 * @return array Elenco di gruppi: array( 'voce' => WP_Post, 'figli' => WP_Post[] ).
 */
function synergy_trattamenti_rami_menu( $page_id ) {
	$locations = get_nav_menu_locations();
	$menu_id   = isset( $locations['primary'] ) ? (int) $locations['primary'] : 0;
	if ( ! $menu_id ) {
		return array();
	}

	$items = wp_get_nav_menu_items( $menu_id );
	if ( empty( $items ) ) {
		return array();
	}

	$per_padre = array();
	$radice    = null;
	foreach ( $items as $item ) {
		$per_padre[ (int) $item->menu_item_parent ][] = $item;
		if ( null === $radice && 'page' === $item->object && (int) $item->object_id === (int) $page_id ) {
			$radice = $item;
		}
	}
	if ( null === $radice ) {
		return array();
	}

	$gruppi = array();
	foreach ( ( isset( $per_padre[ $radice->ID ] ) ? $per_padre[ $radice->ID ] : array() ) as $lvl2 ) {
		$gruppi[] = array(
			'voce'  => $lvl2,
			'figli' => isset( $per_padre[ $lvl2->ID ] ) ? $per_padre[ $lvl2->ID ] : array(),
		);
	}

	return $gruppi;
}

/**
 * Descrizione breve di una pagina collegata dal menu.
 *
 * Ordine: meta description del parent theme (campo gia' esposto nel backend),
 * poi estratto, poi inizio del contenuto. Nessun campo nuovo.
 *
 * @param int $post_id ID della pagina.
 * @return string
 */
function synergy_trattamenti_descrizione( $post_id ) {
	if ( ! $post_id ) {
		return '';
	}
	$desc = (string) get_post_meta( $post_id, '_tw_seo_description', true );
	if ( '' === trim( $desc ) ) {
		$desc = get_the_excerpt( $post_id );
	}
	if ( '' === trim( (string) $desc ) ) {
		$post = get_post( $post_id );
		$desc = $post ? wp_trim_words( wp_strip_all_tags( $post->post_content ), 26, '…' ) : '';
	}
	return trim( (string) $desc );
}

$page_id   = get_the_ID();
$gruppi    = synergy_trattamenti_rami_menu( $page_id );
$intro     = trim( wp_strip_all_tags( get_post_field( 'post_content', $page_id ) ) );
$con_figli = array();
$senza     = array();
foreach ( $gruppi as $g ) {
	if ( ! empty( $g['figli'] ) ) {
		$con_figli[] = $g;
	} else {
		$senza[] = $g;
	}
}
?>

<main id="primary" class="site-main trattamenti-index-main">

	<!-- HERO -->
	<section class="page-hero section">
		<div class="hero-bg">
			<div class="hero-texture"></div>
			<div class="hero-glow"></div>
		</div>
		<div class="container relative-z">
			<div class="hero-content text-center">
				<span class="section-eyebrow"><?php echo esc_html( synergy_t( 'I NOSTRI TRATTAMENTI', 'trattamenti:hero:eyebrow' ) ); ?></span>
				<h1 class="hero-title"><?php the_title(); ?></h1>
				<div class="hero-divider"></div>
				<?php if ( '' !== $intro ) : ?>
					<p class="hero-subtitle"><?php echo esc_html( $intro ); ?></p>
				<?php else : ?>
					<p class="hero-subtitle"><?php echo esc_html( synergy_t( 'Percorsi viso, corpo e beauty costruiti su misura, dopo un ascolto e una valutazione della pelle.', 'trattamenti:hero:subtitle' ) ); ?></p>
				<?php endif; ?>
			</div>
		</div>
	</section>

	<?php if ( empty( $con_figli ) && empty( $senza ) ) : ?>
		<section class="section bg-ivory">
			<div class="container text-center">
				<p><?php echo esc_html( synergy_t( 'I trattamenti non sono ancora stati collegati al menu di navigazione.', 'trattamenti:vuoto' ) ); ?></p>
			</div>
		</section>
	<?php endif; ?>

	<?php
	$indice_gruppo = 0;
	foreach ( $con_figli as $gruppo ) :
		$indice_gruppo++;
		$voce      = $gruppo['voce'];
		$gruppo_id = 'page' === $voce->object ? (int) $voce->object_id : 0;
		$ancora    = sanitize_title( $voce->title );
		?>
		<section class="trattamenti-gruppo section <?php echo 0 === $indice_gruppo % 2 ? 'bg-ivory' : ''; ?>" id="<?php echo esc_attr( $ancora ); ?>">
			<div class="container">
				<header class="trattamenti-gruppo-head">
					<span class="gruppo-numero"><?php echo esc_html( str_pad( (string) $indice_gruppo, 2, '0', STR_PAD_LEFT ) ); ?></span>
					<h2 class="gruppo-titolo"><?php echo esc_html( synergy_t( wp_strip_all_tags( $voce->title ), 'trattamenti:gruppo:' . $ancora ) ); ?></h2>
					<a class="gruppo-link" href="<?php echo esc_url( $voce->url ); ?>">
						<?php echo esc_html( synergy_t( 'Vedi la sezione', 'trattamenti:gruppo:link' ) ); ?>
						<span aria-hidden="true">&rarr;</span>
					</a>
				</header>

				<div class="trattamenti-grid">
					<?php
					foreach ( $gruppo['figli'] as $figlio ) :
						$figlio_id = 'page' === $figlio->object ? (int) $figlio->object_id : 0;
						$titolo    = wp_strip_all_tags( $figlio->title );
						$descr     = synergy_trattamenti_descrizione( $figlio_id );
						$img_id    = $figlio_id ? get_post_thumbnail_id( $figlio_id ) : 0;
						?>
						<a class="trattamento-tile<?php echo $img_id ? '' : ' senza-immagine'; ?>" href="<?php echo esc_url( $figlio->url ); ?>">
							<div class="tile-media">
								<?php
								if ( $img_id ) {
									echo wp_get_attachment_image(
										$img_id,
										'medium_large',
										false,
										array(
											'class'   => 'tile-img',
											'alt'     => esc_attr( $titolo ),
											'loading' => 'lazy',
										)
									);
								} else {
									echo '<span class="tile-iniziale" aria-hidden="true">' . esc_html( mb_substr( $titolo, 0, 1 ) ) . '</span>';
								}
								?>
							</div>
							<div class="tile-corpo">
								<h3 class="tile-titolo"><?php echo esc_html( synergy_t( $titolo, 'trattamenti:voce:' . sanitize_title( $titolo ) ) ); ?></h3>
								<?php if ( '' !== $descr ) : ?>
									<p class="tile-descr"><?php echo esc_html( synergy_t( $descr, 'trattamenti:voce:' . sanitize_title( $titolo ) . ':desc' ) ); ?></p>
								<?php endif; ?>
								<span class="tile-freccia" aria-hidden="true">&rarr;</span>
							</div>
						</a>
					<?php endforeach; ?>
				</div>
			</div>
		</section>
	<?php endforeach; ?>

	<?php if ( ! empty( $senza ) ) : ?>
		<section class="trattamenti-extra section bg-ivory">
			<div class="container">
				<div class="trattamenti-extra-grid">
					<?php foreach ( $senza as $gruppo ) : ?>
						<a class="trattamenti-extra-card" href="<?php echo esc_url( $gruppo['voce']->url ); ?>">
							<h3><?php echo esc_html( synergy_t( wp_strip_all_tags( $gruppo['voce']->title ), 'trattamenti:extra:' . sanitize_title( $gruppo['voce']->title ) ) ); ?></h3>
							<span aria-hidden="true">&rarr;</span>
						</a>
					<?php endforeach; ?>
				</div>
			</div>
		</section>
	<?php endif; ?>

</main>

<?php get_footer(); ?>
