<?php
/**
 * Empty cart page
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/cart/cart-empty.php.
 *
 * @see     https://woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 7.0.1
 */

defined( 'ABSPATH' ) || exit;

?>
<div class="synergy-cart-page synergy-cart-empty-page">
	<div class="synergy-cart-intro">
		<h1 class="cart-title"><?php echo esc_html( synergy_t( 'Il tuo carrello è vuoto', 'cart-empty:title' ) ); ?></h1>
		<p class="cart-subtitle"><?php echo esc_html( synergy_t( 'Non hai ancora aggiunto prodotti al tuo carrello. Esplora la nostra selezione di prodotti professionali.', 'cart-empty:subtitle' ) ); ?></p>
	</div>

	<?php
	/**
	 * @hooked wc_empty_cart_message - 10
	 */
	do_action( 'woocommerce_cart_is_empty' );
	?>

	<div class="synergy-cart-empty-card">
		<div class="synergy-cart-empty-icon">
			<svg viewBox="0 0 24 24" width="48" height="48" stroke="currentColor" stroke-width="1.5" fill="none" stroke-linecap="round" stroke-linejoin="round">
				<path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"></path>
				<line x1="3" y1="6" x2="21" y2="6"></line>
				<path d="M16 10a4 4 0 0 1-8 0"></path>
			</svg>
		</div>

		<div class="synergy-cart-empty-actions">
			<a class="synergy-empty-shop-btn" href="<?php echo esc_url( home_url( '/prodotti/' ) ); ?>">
				<?php echo esc_html( synergy_t( 'ESPLORA I PRODOTTI', 'cart-empty:shop_btn' ) ); ?>
			</a>
		</div>
	</div>
</div>
