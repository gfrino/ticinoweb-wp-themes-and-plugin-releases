<?php
/**
 * Cross-sells
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/cart/cross-sells.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see https://woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 9.6.0
 */

defined( 'ABSPATH' ) || exit;

if ( $cross_sells ) : ?>

	<div class="cross-sells synergy-cross-sells-section">
		<?php
		$heading = apply_filters( 'woocommerce_product_cross_sells_products_heading', synergy_t( 'Completa la tua routine', 'cross-sells:heading' ) );

		if ( $heading ) :
			?>
			<div class="synergy-cross-sells-header">
				<h2><?php echo esc_html( $heading ); ?></h2>
				<p><?php echo esc_html( synergy_t( 'Una selezione di prodotti coerenti con il tuo percorso di cura.', 'cross-sells:subtitle' ) ); ?></p>
			</div>
		<?php endif; ?>

		<div class="prodotti-grid">
			<?php foreach ( $cross_sells as $cross_sell ) : ?>
				<?php
					$post_object = get_post( $cross_sell->get_id() );
					setup_postdata( $GLOBALS['post'] = $post_object ); // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited, Squiz.PHP.DisallowMultipleAssignments.Found
					
					// Use the custom function defined in functions.php to render the exact same card as the products page
					if ( function_exists('synergy_render_product_card') ) {
						echo synergy_render_product_card( $post_object->ID );
					} else {
						wc_get_template_part( 'content', 'product' );
					}
				?>
			<?php endforeach; ?>
		</div>

	</div>
	<?php
endif;

wp_reset_postdata();
