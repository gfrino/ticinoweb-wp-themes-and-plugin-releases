<?php
/**
 * Custom Checkout coupon form template override
 * Overrides woocommerce/checkout/form-coupon.php
 *
 * @package SynergyAdvancedAesthetics
 * @version 9.8.0
 */

defined( 'ABSPATH' ) || exit;

if ( ! wc_coupons_enabled() ) {
	return;
}
?>
<div class="woocommerce-form-coupon-toggle">
	<?php
		wc_print_notice( apply_filters( 'woocommerce_checkout_coupon_message', esc_html( synergy_t( 'Hai un codice promozionale?', 'checkout:coupon:title' ) ) . ' <a href="#" role="button" aria-controls="woocommerce-checkout-form-coupon" aria-expanded="false" class="showcoupon">' . esc_html( synergy_t( 'Clicca qui per inserire il tuo codice', 'checkout:coupon:toggle' ) ) . '</a>' ), 'notice' );
	?>
</div>

<form class="checkout_coupon woocommerce-form-coupon" method="post" style="display:none" id="woocommerce-checkout-form-coupon">
	<p class="coupon-intro-text synergy-coupon-feedback" aria-live="polite"><?php echo esc_html( synergy_t( 'Se possiedi un codice promozionale, inseriscilo qui sotto.', 'checkout:coupon:intro' ) ); ?></p>

	<div class="synergy-coupon-row">
		<input type="text" name="coupon_code" class="input-text synergy-coupon-input" placeholder="<?php echo esc_attr( synergy_t( 'Inserisci codice promozionale', 'checkout:coupon:placeholder' ) ); ?>" id="coupon_code" value="" />
		<button type="submit" class="button synergy-coupon-btn" name="apply_coupon" value="<?php echo esc_attr( synergy_t( 'Applica codice promozionale', 'checkout:coupon:apply' ) ); ?>"><?php echo esc_html( synergy_t( 'Applica codice promozionale', 'checkout:coupon:apply' ) ); ?></button>
	</div>
</form>
