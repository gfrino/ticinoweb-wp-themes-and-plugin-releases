<?php
/**
 * Custom Luxury Checkout Form Template
 * Overrides woocommerce/checkout/form-checkout.php
 *
 * @package SynergyAdvancedAesthetics
 * @version 9.4.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

do_action( 'woocommerce_before_checkout_form', $checkout );

// If checkout registration is disabled and not logged in, the user cannot checkout.
if ( ! $checkout->is_registration_enabled() && $checkout->is_registration_required() && ! is_user_logged_in() ) {
	echo esc_html( apply_filters( 'woocommerce_checkout_must_be_logged_in_message', __( 'You must be logged in to checkout.', 'woocommerce' ) ) );
	return;
}
?>

<form name="checkout" method="post" class="checkout woocommerce-checkout synergy-checkout-form" action="<?php echo esc_url( wc_get_checkout_url() ); ?>" enctype="multipart/form-data" autocomplete="off" aria-label="<?php echo esc_attr__( 'Checkout', 'woocommerce' ); ?>">

	<div class="synergy-checkout-grid">
		<!-- COLONNA SINISTRA: DATI DI FATTURAZIONE E SPEDIZIONE -->
		<div class="synergy-checkout-col-left">
			<?php if ( $checkout->get_checkout_fields() ) : ?>

				<?php do_action( 'woocommerce_checkout_before_customer_details' ); ?>

				<div class="synergy-checkout-section-card" id="customer_details">
					<div class="synergy-checkout-card-header">
						<span class="synergy-step-badge">01</span>
						<h2 class="synergy-card-title"><?php echo esc_html( synergy_t( 'Dati di Spedizione e Fatturazione', 'checkout:billing_title' ) ); ?></h2>
					</div>
					
					<div class="synergy-card-body">
						<div class="col-1">
							<?php do_action( 'woocommerce_checkout_billing' ); ?>
						</div>

						<div class="col-2">
							<?php do_action( 'woocommerce_checkout_shipping' ); ?>
						</div>
					</div>
				</div>

				<?php do_action( 'woocommerce_checkout_after_customer_details' ); ?>

			<?php endif; ?>
		</div>

		<!-- COLONNA DESTRA: RIEPILOGO ORDINE & PAGAMENTO -->
		<div class="synergy-checkout-col-right">
			<div class="synergy-checkout-section-card synergy-order-review-card">
				<div class="synergy-checkout-card-header">
					<span class="synergy-step-badge">02</span>
					<h2 class="synergy-card-title"><?php echo esc_html( synergy_t( 'Riepilogo Ordine', 'checkout:order_review_title' ) ); ?></h2>
				</div>

				<div class="synergy-card-body">
					<?php do_action( 'woocommerce_checkout_before_order_review_heading' ); ?>
					<?php do_action( 'woocommerce_checkout_before_order_review' ); ?>

					<div id="order_review" class="woocommerce-checkout-review-order">
						<?php do_action( 'woocommerce_checkout_order_review' ); ?>
					</div>

					<?php do_action( 'woocommerce_checkout_after_order_review' ); ?>

					<!-- TRUST BADGES -->
					<div class="synergy-checkout-trust-badges">
						<div class="trust-item">
							<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.5"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path></svg>
							<span><?php echo esc_html( synergy_t( 'Pagamento 100% Sicuro SSL', 'checkout:trust:1' ) ); ?></span>
						</div>
						<div class="trust-item">
							<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.5"><rect x="1" y="3" width="15" height="13"></rect><polygon points="16 8 20 8 23 11 23 16 16 16 16 8"></polygon><circle cx="5.5" cy="18.5" r="2.5"></circle><circle cx="18.5" cy="18.5" r="2.5"></circle></svg>
							<span><?php echo esc_html( synergy_t( 'Spedizione Veloce in Svizzera', 'checkout:trust:2' ) ); ?></span>
						</div>
						<div class="trust-item">
							<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path></svg>
							<span><?php echo esc_html( synergy_t( 'Garanzia Ufficiale Synergy', 'checkout:trust:3' ) ); ?></span>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

</form>

<?php do_action( 'woocommerce_after_checkout_form', $checkout ); ?>
