<?php
/**
 * Template per singolo prodotto WooCommerce
 * Sovrascrive il layout standard di WooCommerce
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

get_header();

$product_id = get_the_ID();
$product = function_exists('wc_get_product') ? wc_get_product( $product_id ) : false;

// Se WooCommerce non è attivo o il prodotto non esiste
if ( ! class_exists( 'WooCommerce' ) || ! $product ) {
    echo '<div class="container text-center" style="padding: 100px 0;"><h3>' . esc_html( synergy_t( 'Il prodotto non è al momento disponibile.', 'product:unavailable' ) ) . '</h3></div>';
    get_footer();
    exit;
}

// Fetch Dati
$title = get_the_title();
$price_html = $product->get_price_html();
$short_desc = $product->get_short_description();
$full_desc = get_the_content();
if ( empty( $full_desc ) ) {
    $full_desc = $short_desc;
}
if ( empty( $full_desc ) ) {
    $full_desc = synergy_t_html( '<p>Per maggiori informazioni su questo prodotto, contattaci: ti aiuteremo a capire se è adatto alla tua routine.</p>', 'product:description_fallback' );
}

$is_on_sale = $product->is_on_sale();
$quick_price_html = $price_html;

if ( $is_on_sale ) {
    $regular_price = $product->get_regular_price();
    $sale_price = $product->get_sale_price();

    if ( '' !== $regular_price && '' !== $sale_price ) {
        $regular_price_html = wc_price( $regular_price );
        $sale_price_html = wc_price( $sale_price );
        $regular_price_label = html_entity_decode( wp_strip_all_tags( $regular_price_html ), ENT_QUOTES, 'UTF-8' );
        $sale_price_label = html_entity_decode( wp_strip_all_tags( $sale_price_html ), ENT_QUOTES, 'UTF-8' );
        $price_accessible_label = sprintf(
            synergy_t( 'Prezzo precedente %1$s. Prezzo attuale %2$s.', 'product:price:sr_label' ),
            $regular_price_label,
            $sale_price_label
        );

        $quick_price_html = sprintf(
            '<span class="sp-quick-price sp-quick-price--sale" aria-label="%1$s"><del aria-hidden="true">%2$s</del><ins aria-hidden="true">%3$s</ins></span>',
            esc_attr( $price_accessible_label ),
            $regular_price_html,
            $sale_price_html
        );
    }
}

$sku = $product->get_sku();
$stock_status = $product->get_stock_status(); // 'instock', 'outofstock', 'onbackorder'
$availability = '';
if ( $stock_status === 'instock' ) $availability = synergy_t( 'Disponibile', 'product:availability:instock' );
elseif ( $stock_status === 'outofstock' ) $availability = synergy_t( 'Esaurito', 'product:availability:outofstock' );

// Categorie e Marchi
$terms_cat = get_the_terms( $product_id, 'product_cat' );
$primary_cat = '';
$primary_cat_slug = '';
if ( $terms_cat && ! is_wp_error( $terms_cat ) ) {
    $primary_cat = $terms_cat[0]->name;
    $primary_cat_slug = $terms_cat[0]->slug;
}

$terms_brand = get_the_terms( $product_id, 'product_brand' );
$brand = '';
$brand_slug = '';
if ( $terms_brand && ! is_wp_error( $terms_brand ) ) {
    $brand = $terms_brand[0]->name;
    $brand_slug = $terms_brand[0]->slug;
}

// URLs
$catalog_url = home_url( '/prodotti/' );
$contact_url = add_query_arg( 'prodotto', urlencode( $title ), home_url( '/contatti/' ) );

// Immagine in evidenza e placeholder
$image_html = '';
if ( has_post_thumbnail( $product_id ) ) {
    $image_html = get_the_post_thumbnail( $product_id, 'large', array( 'class' => 'sp-img' ) );
} else {
    $image_html = '<div class="sp-img-placeholder">
                       <svg viewBox="0 0 24 24" width="60" height="60" stroke="currentColor" stroke-width="1.5" fill="none"><path d="M20.24 12.24a6 6 0 0 0-8.49-8.49L5 10.5V19h8.5z"></path><line x1="16" y1="8" x2="2" y2="22"></line><line x1="17.5" y1="15" x2="9" y2="6.5"></line></svg>
                       <span>' . ( $brand ? esc_html($brand) : 'Synergy' ) . '</span>
                   </div>';
}
?>

<main id="main" class="site-main sp-main">



    <!-- 2. HERO PRODOTTO -->
    <section class="sp-hero">
        <div class="container sp-hero-grid">
            <!-- Left: Image -->
            <div class="sp-hero-image-col">

                <div class="sp-image-box">
                    <?php if ( $is_on_sale ) : ?>
                        <span class="sp-badge sale"><?php echo esc_html( synergy_t( 'In offerta', 'product:badge:sale' ) ); ?></span>
                    <?php endif; ?>
                    <?php echo $image_html; ?>
                </div>
            </div>
            
            <!-- Right: Info -->
            <div class="sp-hero-info-col">
                <div class="sp-info-header">
                    <?php if ( $primary_cat ) : ?>
                        <span class="sp-cat-badge"><?php echo esc_html( $primary_cat ); ?></span>
                    <?php endif; ?>
                    <?php if ( $brand ) : ?>
                        <span class="sp-brand"><?php echo esc_html( $brand ); ?></span>
                    <?php endif; ?>
                </div>

                <h1 class="sp-title"><?php echo esc_html( $title ); ?></h1>
                


                <?php if ( $short_desc ) : ?>
                    <div class="sp-short-desc">
                        <?php echo wp_kses_post( $short_desc ); ?>
                    </div>
                <?php endif; ?>

                <div class="sp-ecommerce-area">
                    <?php if ( $price_html ) : ?>
                        <div class="sp-price-box">
                            <span class="sp-price-display"><?php echo $price_html; ?></span>
                            <?php if ( $product->is_purchasable() && $product->is_in_stock() ) : ?>
                                <div class="sp-availability-badge">
                                    <svg viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg>
                                    <?php echo esc_html( synergy_t( 'Disponibile all\'acquisto', 'product:availability:purchasable' ) ); ?>
                                </div>
                            <?php elseif ( ! $product->is_in_stock() ) : ?>
                                <div class="sp-availability-badge out-of-stock">
                                    <svg viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="15" y1="9" x2="9" y2="15"></line><line x1="9" y1="9" x2="15" y2="15"></line></svg>
                                    <?php echo esc_html( synergy_t( 'Prodotto esaurito', 'product:availability:soldout' ) ); ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>

                    <div class="sp-actions">
                        <?php 
                        if ( $product->is_purchasable() && $product->is_in_stock() ) {
                            woocommerce_template_single_add_to_cart();
                        } elseif ( ! $product->is_purchasable() ) {
                            echo '<p class="sp-price-request">' . esc_html( synergy_t( 'Prezzo su richiesta', 'product:price_on_request' ) ) . '</p>';
                        }
                        ?>
                    </div>

                    <div class="sp-trust-badges">
                        <div class="trust-badge">
                            <svg viewBox="0 0 24 24" width="14" height="14" stroke="currentColor" stroke-width="2" fill="none"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>
                            <span><?php echo esc_html( synergy_t( 'Consulenza disponibile in istituto', 'product:trust:1' ) ); ?></span>
                        </div>
                        <div class="trust-badge">
                            <svg viewBox="0 0 24 24" width="14" height="14" stroke="currentColor" stroke-width="2" fill="none"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>
                            <span><?php echo esc_html( synergy_t( 'Acquisto gestito dal centro', 'product:trust:2' ) ); ?></span>
                        </div>
                    </div>

                    <div class="sp-secondary-actions">
                        <a href="<?php echo esc_url( $contact_url ); ?>" class="btn-sp-link-outline"><?php echo esc_html( synergy_t( 'Chiedi consiglio sul prodotto', 'product:cta:advice' ) ); ?></a>
                        <a href="<?php echo esc_url( $catalog_url ); ?>" class="btn-sp-link"><?php echo esc_html( synergy_t( 'Torna al catalogo', 'product:cta:back' ) ); ?></a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- 3. SCHEDA RAPIDA INTEGRATA -->
    <section class="sp-quick-info-section">
        <div class="container">
            <h3 class="sp-quick-info-title"><?php echo esc_html( synergy_t( 'Informazioni prodotto', 'product:info:title' ) ); ?></h3>
            <div class="sp-quick-info-card">
                <?php if ( $primary_cat ) : ?>
                    <div class="qi-item">
                        <span class="qi-label"><?php echo esc_html( synergy_t( 'Categoria', 'product:info:category' ) ); ?></span>
                        <span class="qi-value"><?php echo esc_html( $primary_cat ); ?></span>
                    </div>
                <?php endif; ?>
                
                <?php if ( $brand ) : ?>
                    <div class="qi-item">
                        <span class="qi-label"><?php echo esc_html( synergy_t( 'Marchio', 'product:info:brand' ) ); ?></span>
                        <span class="qi-value"><?php echo esc_html( $brand ); ?></span>
                    </div>
                <?php endif; ?>

                <?php if ( $quick_price_html ) : ?>
                    <div class="qi-item">
                        <span class="qi-label"><?php echo esc_html( synergy_t( 'Prezzo', 'product:info:price' ) ); ?></span>
                        <span class="qi-value sp-clean-price"><?php echo wp_kses_post( $quick_price_html ); ?></span>
                    </div>
                <?php endif; ?>

                <?php if ( $availability ) : ?>
                    <div class="qi-item">
                        <span class="qi-label"><?php echo esc_html( synergy_t( 'Disponibilità', 'product:info:availability' ) ); ?></span>
                        <span class="qi-value <?php echo $stock_status === 'instock' ? 'in-stock' : 'out-of-stock'; ?>"><?php echo esc_html( $availability ); ?></span>
                    </div>
                <?php elseif ( $sku ) : ?>
                    <div class="qi-item">
                        <span class="qi-label"><?php echo esc_html( synergy_t( 'SKU', 'product:info:sku' ) ); ?></span>
                        <span class="qi-value"><?php echo esc_html( $sku ); ?></span>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </section>

    <!-- 4. DESCRIZIONE PRODOTTO EDITORIALE -->
    <section class="sp-description">
        <div class="container">
            <div class="sp-desc-grid">
                <div class="sp-desc-main">
                    <h2 class="sp-section-title"><?php echo esc_html( synergy_t( 'Descrizione prodotto', 'product:description:title' ) ); ?></h2>
                    <div class="sp-content-wrapper">
                        <?php echo wp_kses_post( $full_desc ); ?>
                    </div>
                </div>
                <div class="sp-desc-sidebar">
                    <div class="sp-pro-advice-box">
                        <h3><?php echo esc_html( synergy_t( 'Consiglio professionale', 'product:advice:title' ) ); ?></h3>
                        <p><?php echo esc_html( synergy_t( 'Per scegliere correttamente il prodotto, il team può aiutarti a inserirlo nella routine più adatta alla tua pelle, ai trattamenti svolti in istituto e agli obiettivi desiderati.', 'product:advice:text' ) ); ?></p>
                        <a href="<?php echo esc_url( $contact_url ); ?>" class="btn-pro-advice"><?php echo esc_html( synergy_t( 'Chiedi consiglio', 'product:advice:cta' ) ); ?></a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- 5. CONSIGLIO PROFESSIONALE -->
    <section class="sp-useful-info">
        <div class="container">
            <div class="sp-ui-header">
                <h2 class="sp-section-title"><?php echo esc_html( synergy_t( 'Perché acquistarlo con una consulenza professionale', 'product:why:title' ) ); ?></h2>
                <p class="sp-section-subtitle"><?php echo esc_html( synergy_t( 'Ogni prodotto può essere scelto in modo più consapevole se inserito in una routine coerente con la pelle, i trattamenti e gli obiettivi personali.', 'product:why:subtitle' ) ); ?></p>
            </div>
            <div class="sp-ui-grid">
                <div class="sp-ui-card">
                    <div class="ui-icon">
                        <svg viewBox="0 0 24 24" width="28" height="28" stroke="currentColor" stroke-width="1.5" fill="none"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path></svg>
                    </div>
                    <div class="ui-text-wrap">
                        <h4 class="ui-title"><?php echo esc_html( synergy_t( 'Routine su misura', 'product:why:1:title' ) ); ?></h4>
                        <p class="ui-desc"><?php echo esc_html( synergy_t( 'Ti aiutiamo a capire quando e come inserirlo nella cura quotidiana.', 'product:why:1:text' ) ); ?></p>
                    </div>
                </div>
                <div class="sp-ui-card">
                    <div class="ui-icon">
                        <svg viewBox="0 0 24 24" width="28" height="28" stroke="currentColor" stroke-width="1.5" fill="none"><path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"></path></svg>
                    </div>
                    <div class="ui-text-wrap">
                        <h4 class="ui-title"><?php echo esc_html( synergy_t( 'Coerenza con i trattamenti', 'product:why:2:title' ) ); ?></h4>
                        <p class="ui-desc"><?php echo esc_html( synergy_t( 'Il prodotto può accompagnare i percorsi svolti in istituto e il mantenimento a casa.', 'product:why:2:text' ) ); ?></p>
                    </div>
                </div>
                <div class="sp-ui-card">
                    <div class="ui-icon">
                        <svg viewBox="0 0 24 24" width="28" height="28" stroke="currentColor" stroke-width="1.5" fill="none"><path d="M20.59 13.41l-7.17 7.17a2 2 0 0 1-2.83 0L2 12V2h10l8.59 8.59a2 2 0 0 1 0 2.82z"></path><line x1="7" y1="7" x2="7.01" y2="7"></line></svg>
                    </div>
                    <div class="ui-text-wrap">
                        <h4 class="ui-title"><?php echo esc_html( synergy_t( 'Scelta più consapevole', 'product:why:3:title' ) ); ?></h4>
                        <p class="ui-desc"><?php echo esc_html( synergy_t( 'Valutiamo categoria, esigenza e obiettivo prima di consigliarlo.', 'product:why:3:text' ) ); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- 6. PRODOTTI CORRELATI -->
    <?php
    $related_args = array(
        'post_type'      => 'product',
        'post_status'    => 'publish',
        'posts_per_page' => 4,
        'post__not_in'   => array( $product_id ),
    );
    
    // Try by category first, if none, by tag
    $tax_query = array( 'relation' => 'OR' );
    if ( $primary_cat_slug ) {
        $tax_query[] = array(
            'taxonomy' => 'product_cat',
            'field'    => 'slug',
            'terms'    => $primary_cat_slug,
        );
    }
    if ( $brand_slug ) {
        $tax_query[] = array(
            'taxonomy' => 'product_brand',
            'field'    => 'slug',
            'terms'    => $brand_slug,
        );
    }
    if ( count( $tax_query ) > 1 ) {
        $related_args['tax_query'] = $tax_query;
    }

    $related_query = new WP_Query( $related_args );

    if ( $related_query->have_posts() && function_exists('synergy_render_product_card') ) :
    ?>
    <section class="sp-related">
        <div class="container">
            <div class="sp-related-header">
                <h2 class="sp-section-title"><?php echo esc_html( synergy_t( 'Potrebbe interessarti anche', 'product:related:title' ) ); ?></h2>
                <p class="sp-section-subtitle"><?php echo esc_html( synergy_t( 'Una selezione di prodotti simili per categoria o marchio.', 'product:related:subtitle' ) ); ?></p>
            </div>
            <div class="sp-related-grid synergy-catalog-grid">
                <?php 
                while ( $related_query->have_posts() ) {
                    $related_query->the_post();
                    // Assicuriamoci che il prodotto non sia "vuoto" senza titolo
                    if( get_the_title() ) {
                        echo synergy_render_product_card( get_the_ID() );
                    }
                }
                wp_reset_postdata();
                ?>
            </div>
        </div>
    </section>
    <?php endif; ?>




</main>

<?php get_footer(); ?>
