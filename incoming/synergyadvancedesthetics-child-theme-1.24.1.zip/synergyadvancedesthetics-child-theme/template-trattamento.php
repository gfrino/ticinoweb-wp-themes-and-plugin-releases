<?php
/**
 * Template Name: Template Trattamento
 * Description: Un template premium e dinamico per le pagine dei singoli trattamenti.
 */

get_header(); ?>

<main id="primary" class="site-main synergy-treatment-page">
    <?php
    while ( have_posts() ) :
        the_post();
        
        // 1. Hero Dinamica
        get_template_part( 'template-parts/treatment/treatment', 'hero' );
        
        // 2. Contenuto Principale (Editor + Sidebar)
        get_template_part( 'template-parts/treatment/treatment', 'content' );
        
        // 3. Processo Comune
        get_template_part( 'template-parts/treatment/treatment', 'process' );
        
        // 4. Pagine Correlate
        get_template_part( 'template-parts/treatment/treatment', 'related' );
        
        // 5. FAQ e CTA Finale
        get_template_part( 'template-parts/treatment/treatment', 'cta-faq' );

    endwhile;
    ?>
</main><!-- #main -->

<?php
get_footer();
