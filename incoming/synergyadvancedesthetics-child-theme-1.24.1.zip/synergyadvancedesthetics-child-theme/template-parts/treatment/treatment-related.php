<?php
/**
 * Sezione "Pagine correlate" per il Template Trattamento
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

$post_id = get_the_ID();
$parent_id = wp_get_post_parent_id( $post_id );

$query_args = array(
    'post_type'      => 'page',
    'posts_per_page' => 3, // 3 colonne desktop
    'post__not_in'   => array( $post_id ),
    'orderby'        => 'menu_order title',
    'order'          => 'ASC',
);

$has_related = false;
$related_context = '';

if ( $parent_id ) {
    // Fratelli
    $query_args['post_parent'] = $parent_id;
    $has_related = true;
    $related_context = get_the_title( $parent_id );
} else {
    // Figli
    $children = get_children( array(
        'post_parent' => $post_id,
        'post_type'   => 'page',
        'numberposts' => 1
    ) );
    if ( ! empty( $children ) ) {
        $query_args['post_parent'] = $post_id;
        $has_related = true;
        $related_context = get_the_title( $post_id );
    }
}

if ( $has_related ) {
    $related_query = new WP_Query( $query_args );

    if ( $related_query->have_posts() ) : ?>

        <section class="treatment-related-premium reveal-on-scroll">
            <div class="treatment-container">
                
                <div class="related-header">
                    <h3 class="related-title"><?php echo esc_html( synergy_t( 'Esplora altri percorsi', 'treatment:related:title' ) ); ?></h3>
                    <?php if ( $related_context ) : ?>
                        <p class="related-subtitle"><?php echo esc_html( sprintf( synergy_t( 'Scopri i trattamenti correlati all\'area %s', 'treatment:related:subtitle' ), $related_context ) ); ?></p>
                    <?php endif; ?>
                </div>
                
                <div class="related-grid-premium">
                    <?php while ( $related_query->have_posts() ) : $related_query->the_post(); 
                        $thumb = get_the_post_thumbnail_url( get_the_ID(), 'medium_large' );
                        $rel_excerpt = get_the_excerpt();
                        if ( empty( $rel_excerpt ) ) {
                            $rel_excerpt = wp_trim_words( strip_tags( get_post_field('post_content', get_the_ID()) ), 18, '...' );
                        }
                    ?>
                        <a href="<?php the_permalink(); ?>" class="related-premium-card">
                            <div class="related-img-box">
                                <?php if ( $thumb ) : ?>
                                    <div class="related-img-bg" style="background-image: url('<?php echo esc_url( $thumb ); ?>');"></div>
                                <?php else : ?>
                                    <div class="related-img-bg fallback-bg"></div>
                                <?php endif; ?>
                            </div>
                            
                            <div class="related-info-box">
                                <h4><?php the_title(); ?></h4>
                                <p><?php echo esc_html( $rel_excerpt ); ?></p>
                                <span class="related-link">
                                    <?php echo esc_html( synergy_t( 'Scopri il percorso', 'treatment:related:cta' ) ); ?>
                                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
                                </span>
                            </div>
                        </a>
                    <?php endwhile; wp_reset_postdata(); ?>
                </div>

            </div>
        </section>

    <?php endif;
}
?>
