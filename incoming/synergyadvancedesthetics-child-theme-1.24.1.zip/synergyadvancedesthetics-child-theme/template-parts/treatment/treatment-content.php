<?php
/**
 * Sezione Editoriale e Sidebar per il Template Trattamento
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

$post_id = get_the_ID();
$parent_id = wp_get_post_parent_id( $post_id );
$parent_title = $parent_id ? get_the_title( $parent_id ) : '';

// Ricerca "sorelle" (fino a 5, escludendo pagina corrente)
$siblings = array();
if ( $parent_id ) {
    $siblings = get_posts( array(
        'post_type'      => 'page',
        'post_parent'    => $parent_id,
        'posts_per_page' => 5,
        'post__not_in'   => array( $post_id ),
        'orderby'        => 'menu_order title',
        'order'          => 'ASC',
    ) );
}
?>

<section class="treatment-content-premium">
    <div class="treatment-container content-container">
        
        <!-- Colonna Principale -->
        <article class="treatment-main-col">
            <div class="synergy-editor-content">
                <?php 
                $raw_content = get_the_content();
                $clean_text = preg_replace( '/<!--(.*?)-->/s', '', $raw_content );
                $clean_text = trim( strip_tags( $clean_text ) );

                if ( empty( $clean_text ) ) {
                    echo synergy_get_default_treatment_content( get_the_title() );
                } else {
                    the_content();
                }
                ?>
            </div>
            
            <?php
            // Riquadro riepilogativo dei prezzi della categoria di questa pagina.
            // Non stampa nulla se la pagina non ha una categoria di listino.
            if ( function_exists( 'synergy_render_treatment_price_box' ) ) {
                synergy_render_treatment_price_box( get_the_ID() );
            }
            ?>

            <!-- Box di chiusura automatico -->
            <div class="treatment-why-box reveal-on-scroll">
                <h4><?php echo esc_html( synergy_t( 'Perché scegliere questo percorso', 'treatment:content:why:title' ) ); ?></h4>
                <p><?php echo esc_html( synergy_t( 'Ogni trattamento viene valutato in base alle esigenze della persona, con un approccio professionale, attento e personalizzato.', 'treatment:content:why:text' ) ); ?></p>
            </div>
        </article>

        <!-- Colonna Sidebar -->
        <aside class="treatment-sidebar-col">
            <div class="treatment-sticky-sidebar">
                
                <!-- Card Consulenza -->
                <div class="consultation-card">
                    <div class="card-glow"></div>
                    <div class="card-inner">
                        <h3><?php echo esc_html( synergy_t( 'Hai dubbi sul trattamento più adatto?', 'treatment:content:cta:title' ) ); ?></h3>
                        <p><?php echo esc_html( synergy_t( 'Ogni percorso nasce da una valutazione personalizzata. Ti aiutiamo a scegliere la soluzione più adatta alle tue esigenze.', 'treatment:content:cta:text' ) ); ?></p>
                        
                        <a href="<?php echo esc_url(home_url('/contatti/')); ?>" class="btn-treatment-primary btn-full"><?php echo esc_html( synergy_t( 'Prenota una consulenza', 'treatment:content:cta:btn' ) ); ?></a>
                        
                        <div class="consultation-info">
                            <?php
                            // Telefono e indirizzo arrivano dal CMS ticinoWEB, come nel footer:
                            // vanno aggiornati in un solo punto, non nei template.
                            $tw_phone   = get_option( 'ticinoweb_contact_phone' );
                            $tw_address = get_option( 'ticinoweb_contact_address' );
                            $tw_tel     = $tw_phone ? preg_replace( '/[^0-9+]/', '', str_replace( '(0)', '', $tw_phone ) ) : '';
                            // L'indirizzo puo' contenere <br>: qui sta su una riga sola.
                            $tw_address_line = $tw_address ? trim( preg_replace( '/\s*(<br\s*\/?>)+\s*/i', ', ', wp_strip_all_tags( $tw_address, false ) ) ) : '';
                            ?>
                            <?php if ( $tw_phone ) : ?>
                            <div class="info-row">
                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path></svg>
                                <a href="tel:<?php echo esc_attr( $tw_tel ); ?>"><?php echo esc_html( $tw_phone ); ?></a>
                            </div>
                            <?php endif; ?>
                            <?php if ( $tw_address_line ) : ?>
                            <div class="info-row">
                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path><circle cx="12" cy="10" r="3"></circle></svg>
                                <a href="<?php echo esc_url( 'https://maps.google.com/?q=' . rawurlencode( $tw_address_line ) ); ?>" target="_blank" rel="noopener"><?php echo esc_html( $tw_address_line ); ?></a>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <!-- Navigazione Sorelle -->
                <?php if ( ! empty( $siblings ) ) : ?>
                    <div class="sidebar-nav-card">
                        <h4><?php echo esc_html( sprintf( synergy_t( 'Altri trattamenti %s', 'treatment:content:siblings:title' ), $parent_title ) ); ?></h4>
                        <ul class="sidebar-sibling-list">
                            <?php foreach ( $siblings as $sibling ) : ?>
                                <li>
                                    <a href="<?php echo get_permalink( $sibling->ID ); ?>">
                                        <?php echo get_the_title( $sibling->ID ); ?>
                                    </a>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>

            </div>
        </aside>

    </div>
</section>
