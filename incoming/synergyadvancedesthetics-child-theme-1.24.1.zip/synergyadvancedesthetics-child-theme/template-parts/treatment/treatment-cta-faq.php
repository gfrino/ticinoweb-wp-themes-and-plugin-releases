<?php
/**
 * Sezione FAQ e CTA Finale per il Template Trattamento
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
$post_id = get_the_ID();

$faq_title = get_post_meta( $post_id, '_synergy_faq_title', true ) ?: ( get_option( 'synergy_g_faq_title' ) ?: 'Informazioni utili' );

$f1_q = get_post_meta( $post_id, '_synergy_faq1_q', true ) ?: ( get_option( 'synergy_g_faq1_q' ) ?: 'Come scelgo il trattamento più adatto?' );
$f1_a = get_post_meta( $post_id, '_synergy_faq1_a', true ) ?: ( get_option( 'synergy_g_faq1_a' ) ?: 'Ogni trattamento viene valutato in base alle esigenze della persona. Per questo è consigliata una consulenza iniziale approfondita per delineare il percorso perfetto per te e la tua pelle.' );

$f2_q = get_post_meta( $post_id, '_synergy_faq2_q', true ) ?: ( get_option( 'synergy_g_faq2_q' ) ?: 'I risultati sono uguali per tutti?' );
$f2_a = get_post_meta( $post_id, '_synergy_faq2_a', true ) ?: ( get_option( 'synergy_g_faq2_a' ) ?: 'Ogni persona è unica. Il nostro centro non promette risultati miracolosi standardizzati, ma costruisce percorsi personalizzati con estrema professionalità e attenzione per massimizzare le tue potenzialità.' );

$f3_q = get_post_meta( $post_id, '_synergy_faq3_q', true ) ?: ( get_option( 'synergy_g_faq3_q' ) ?: 'Posso richiedere un appuntamento online?' );
$f3_a = get_post_meta( $post_id, '_synergy_faq3_a', true ) ?: ( get_option( 'synergy_g_faq3_a' ) ?: 'Sì, puoi inviare una richiesta di appuntamento in qualsiasi momento tramite il sito. La conferma definitiva ti verrà inviata dal centro dopo aver verificato la disponibilità effettiva in agenda.' );
?>

<!-- FAQ SECTION -->
<section class="treatment-faq-premium reveal-on-scroll">
    <div class="faq-container-narrow">
        
        <div class="faq-header-center">
            <h3 class="faq-title"><?php echo esc_html( synergy_t( $faq_title, 'treatment:faq:title' ) ); ?></h3>
        </div>
        
        <div class="premium-accordion">
            <!-- FAQ 1 -->
            <div class="accordion-item">
                <button class="accordion-header" aria-expanded="false">
                    <?php echo esc_html( synergy_t( $f1_q, 'treatment:faq:1:q' ) ); ?>
                    <span class="acc-icon">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></svg>
                    </span>
                </button>
                <div class="accordion-body">
                    <p><?php echo esc_html( synergy_t( $f1_a, 'treatment:faq:1:a' ) ); ?></p>
                </div>
            </div>
            
            <!-- FAQ 2 -->
            <div class="accordion-item">
                <button class="accordion-header" aria-expanded="false">
                    <?php echo esc_html( synergy_t( $f2_q, 'treatment:faq:2:q' ) ); ?>
                    <span class="acc-icon">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></svg>
                    </span>
                </button>
                <div class="accordion-body">
                    <p><?php echo esc_html( synergy_t( $f2_a, 'treatment:faq:2:a' ) ); ?></p>
                </div>
            </div>

            <!-- FAQ 3 -->
            <div class="accordion-item">
                <button class="accordion-header" aria-expanded="false">
                    <?php echo esc_html( synergy_t( $f3_q, 'treatment:faq:3:q' ) ); ?>
                    <span class="acc-icon">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></svg>
                    </span>
                </button>
                <div class="accordion-body">
                    <p><?php echo esc_html( synergy_t( $f3_a, 'treatment:faq:3:a' ) ); ?></p>
                </div>
            </div>
        </div>

    </div>
</section>


