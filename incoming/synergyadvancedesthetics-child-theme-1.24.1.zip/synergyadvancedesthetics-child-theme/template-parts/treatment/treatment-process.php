<?php
/**
 * Sezione "Come funziona il percorso" (Timeline) per il Template Trattamento
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
$post_id = get_the_ID();

$proc_title = get_post_meta( $post_id, '_synergy_process_title', true ) ?: ( get_option( 'synergy_g_process_title' ) ?: 'Un percorso costruito intorno a te.' );
$proc_desc  = get_post_meta( $post_id, '_synergy_process_desc', true ) ?: ( get_option( 'synergy_g_process_desc' ) ?: 'Ogni trattamento viene scelto con attenzione, partendo dall’ascolto delle tue esigenze, dalla valutazione degli obiettivi e dalla professionalità del centro.' );

$s1_t = get_post_meta( $post_id, '_synergy_step1_title', true ) ?: ( get_option( 'synergy_g_step1_title' ) ?: 'Ascolto' );
$s1_c = get_post_meta( $post_id, '_synergy_step1_text', true ) ?: ( get_option( 'synergy_g_step1_text' ) ?: 'Comprendiamo le tue esigenze e i tuoi obiettivi attraverso un colloquio dedicato.' );

$s2_t = get_post_meta( $post_id, '_synergy_step2_title', true ) ?: ( get_option( 'synergy_g_step2_title' ) ?: 'Valutazione' );
$s2_c = get_post_meta( $post_id, '_synergy_step2_text', true ) ?: ( get_option( 'synergy_g_step2_text' ) ?: 'Analizziamo il percorso più adatto in base al trattamento richiesto e al tuo tipo di pelle o corpo.' );

$s3_t = get_post_meta( $post_id, '_synergy_step3_title', true ) ?: ( get_option( 'synergy_g_step3_title' ) ?: 'Trattamento' );
$s3_c = get_post_meta( $post_id, '_synergy_step3_text', true ) ?: ( get_option( 'synergy_g_step3_text' ) ?: 'Applichiamo manualità, tecnologie avanzate e prodotti professionali rigorosamente selezionati.' );

$s4_t = get_post_meta( $post_id, '_synergy_step4_title', true ) ?: ( get_option( 'synergy_g_step4_title' ) ?: 'Continuità' );
$s4_c = get_post_meta( $post_id, '_synergy_step4_text', true ) ?: ( get_option( 'synergy_g_step4_text' ) ?: 'Ti consigliamo i passaggi migliori per proseguire la cura anche a casa e mantenere i risultati.' );
?>

<section class="treatment-process-premium reveal-on-scroll" id="percorso">
    <div class="treatment-container">
        
        <div class="process-header-center">
            <h2 class="process-title"><?php echo esc_html( synergy_t( $proc_title, 'treatment:process:title' ) ); ?></h2>
            <p class="process-desc"><?php echo esc_html( synergy_t( $proc_desc, 'treatment:process:desc' ) ); ?></p>
        </div>

        <div class="process-timeline-grid">
            
            <!-- Step 1 -->
            <div class="timeline-step">
                <div class="step-content">
                    <div class="step-card-header">
                        <span class="step-num">01</span>
                        <div class="step-line"></div>
                    </div>
                    <h4 class="step-title"><?php echo esc_html( synergy_t( $s1_t, 'treatment:process:step:1:title' ) ); ?></h4>
                    <p class="step-text"><?php echo esc_html( synergy_t( $s1_c, 'treatment:process:step:1:text' ) ); ?></p>
                </div>
            </div>
            
            <!-- Step 2 -->
            <div class="timeline-step">
                <div class="step-content">
                    <div class="step-card-header">
                        <span class="step-num">02</span>
                        <div class="step-line"></div>
                    </div>
                    <h4 class="step-title"><?php echo esc_html( synergy_t( $s2_t, 'treatment:process:step:2:title' ) ); ?></h4>
                    <p class="step-text"><?php echo esc_html( synergy_t( $s2_c, 'treatment:process:step:2:text' ) ); ?></p>
                </div>
            </div>
            
            <!-- Step 3 -->
            <div class="timeline-step">
                <div class="step-content">
                    <div class="step-card-header">
                        <span class="step-num">03</span>
                        <div class="step-line"></div>
                    </div>
                    <h4 class="step-title"><?php echo esc_html( synergy_t( $s3_t, 'treatment:process:step:3:title' ) ); ?></h4>
                    <p class="step-text"><?php echo esc_html( synergy_t( $s3_c, 'treatment:process:step:3:text' ) ); ?></p>
                </div>
            </div>
            
            <!-- Step 4 -->
            <div class="timeline-step">
                <div class="step-content">
                    <div class="step-card-header">
                        <span class="step-num">04</span>
                        <div class="step-line last-line"></div>
                    </div>
                    <h4 class="step-title"><?php echo esc_html( synergy_t( $s4_t, 'treatment:process:step:4:title' ) ); ?></h4>
                    <p class="step-text"><?php echo esc_html( synergy_t( $s4_c, 'treatment:process:step:4:text' ) ); ?></p>
                </div>
            </div>

        </div>

    </div>
</section>
