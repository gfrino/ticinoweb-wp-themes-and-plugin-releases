<?php
/**
 * Hero Section Premium per il Template Trattamento
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

$post_id = get_the_ID();
$title = get_the_title();

// 1. Dati Dinamici: Excerpt / Fallback
$excerpt = get_the_excerpt();
if ( empty( $excerpt ) ) {
    $content = get_post_field( 'post_content', $post_id );
    $excerpt = wp_trim_words( strip_tags( $content ), 26, '...' );
}
if ( empty( $excerpt ) ) {
    $excerpt = synergy_t( 'Un percorso personalizzato pensato per accompagnarti con attenzione, professionalità e cura.', 'treatment:hero:excerpt_fallback' );
}

// 2. Dati Dinamici: Immagine in evidenza
$image_url = get_the_post_thumbnail_url( $post_id, 'large' );

if ( empty( $image_url ) ) {
    $upload_dir = wp_upload_dir();
    $heroes_dir = $upload_dir['basedir'] . '/treatment-heroes/';
    $heroes_url = $upload_dir['baseurl'] . '/treatment-heroes/';

    if ( ( stripos( $title, 'peeling' ) !== false || stripos( $title, 'rigeneraz' ) !== false ) && file_exists( $heroes_dir . 'peeling.png' ) ) {
        $image_url = $heroes_url . 'peeling.png';
    } elseif ( ( stripos( $title, 'pulizia' ) !== false ) && file_exists( $heroes_dir . 'pulizia.png' ) ) {
        $image_url = $heroes_url . 'pulizia.png';
    } elseif ( ( stripos( $title, 'avanzati' ) !== false ) && file_exists( $heroes_dir . 'avanzati.png' ) ) {
        $image_url = $heroes_url . 'avanzati.png';
    } elseif ( ( stripos( $title, 'cellulite' ) !== false || stripos( $title, 'drenagg' ) !== false ) && file_exists( $heroes_dir . 'cellulite.png' ) ) {
        $image_url = $heroes_url . 'cellulite.png';
    } elseif ( ( stripos( $title, 'tonificaz' ) !== false ) && file_exists( $heroes_dir . 'tonificazione.png' ) ) {
        $image_url = $heroes_url . 'tonificazione.png';
    } elseif ( ( stripos( $title, 'rimodellament' ) !== false ) && file_exists( $heroes_dir . 'rimodellamento.png' ) ) {
        $image_url = $heroes_url . 'rimodellamento.png';
    } elseif ( ( stripos( $title, 'dimagrant' ) !== false || stripos( $title, 'snellent' ) !== false ) && file_exists( $heroes_dir . 'dimagranti.png' ) ) {
        $image_url = $heroes_url . 'dimagranti.png';
    } elseif ( ( stripos( $title, 'smagliatur' ) !== false || stripos( $title, 'cicatric' ) !== false ) && file_exists( $heroes_dir . 'smagliature.png' ) ) {
        $image_url = $heroes_url . 'smagliature.png';
    } elseif ( ( stripos( $title, 'cigli' ) !== false || stripos( $title, 'sopraccigli' ) !== false ) && file_exists( $heroes_dir . 'ciglia.png' ) ) {
        $image_url = $heroes_url . 'ciglia.png';
    } elseif ( ( stripos( $title, 'epilaz' ) !== false || stripos( $title, 'depilaz' ) !== false ) && file_exists( $heroes_dir . 'epilazione.png' ) ) {
        $image_url = $heroes_url . 'epilazione.png';
    } elseif ( ( stripos( $title, 'mani' ) !== false || stripos( $title, 'piedi' ) !== false ) && file_exists( $heroes_dir . 'mani.png' ) ) {
        $image_url = $heroes_url . 'mani.png';
    } elseif ( ( stripos( $title, 'massagg' ) !== false || stripos( $title, 'benessere' ) !== false ) && file_exists( $heroes_dir . 'massaggi.png' ) ) {
        $image_url = $heroes_url . 'massaggi.png';
    } elseif ( ( stripos( $title, 'anti-age' ) !== false || stripos( $title, 'anti age' ) !== false ) && file_exists( $heroes_dir . 'antiage.png' ) ) {
        $image_url = $heroes_url . 'antiage.png';
    } elseif ( ( stripos( $title, 'acne' ) !== false || stripos( $title, 'luminos' ) !== false || stripos( $title, 'macchi' ) !== false ) && file_exists( $heroes_dir . 'acne.png' ) ) {
        $image_url = $heroes_url . 'acne.png';
    }
}

// 3. Dati Dinamici: Logica Parent per Breadcrumb, Eyebrow e Badge
$eyebrow = synergy_t( 'TRATTAMENTO PERSONALIZZATO', 'treatment:hero:eyebrow:default' );
$badge_text = synergy_t( 'Percorso personalizzato', 'treatment:hero:badge:default' );
$breadcrumb_parent_title = '';
$breadcrumb_parent_url = '';

if ( wp_get_post_parent_id( $post_id ) ) {
    $parent_id = wp_get_post_parent_id( $post_id );
    $parent_title = get_the_title( $parent_id );
    $breadcrumb_parent_title = $parent_title;
    $breadcrumb_parent_url = get_permalink( $parent_id );
    
    if ( stripos( $parent_title, 'Viso' ) !== false ) {
        $eyebrow = synergy_t( 'TRATTAMENTI VISO', 'treatment:hero:eyebrow:skin' );
        $badge_text = synergy_t( 'Cura della pelle', 'treatment:hero:badge:skin' );
    } elseif ( stripos( $parent_title, 'Corpo' ) !== false ) {
        $eyebrow = synergy_t( 'TRATTAMENTI CORPO', 'treatment:hero:eyebrow:body' );
        $badge_text = synergy_t( 'Rimodellamento & benessere', 'treatment:hero:badge:body' );
    } elseif ( stripos( $parent_title, 'Beauty' ) !== false ) {
        $eyebrow = synergy_t( 'BEAUTY ESSENTIALS', 'treatment:hero:eyebrow:beauty' );
        $badge_text = synergy_t( 'Beauty essentials', 'treatment:hero:badge:beauty' );
    } else {
        $eyebrow = strtoupper( $parent_title );
    }
} else {
    // Controllo sul titolo se non ha un parent
    if ( stripos( $title, 'Viso' ) !== false ) {
        $eyebrow = synergy_t( 'TRATTAMENTI VISO', 'treatment:hero:eyebrow:skin' );
        $badge_text = synergy_t( 'Cura della pelle', 'treatment:hero:badge:skin' );
    } elseif ( stripos( $title, 'Corpo' ) !== false ) {
        $eyebrow = synergy_t( 'TRATTAMENTI CORPO', 'treatment:hero:eyebrow:body' );
        $badge_text = synergy_t( 'Rimodellamento & benessere', 'treatment:hero:badge:body' );
    } elseif ( stripos( $title, 'Beauty' ) !== false ) {
        $eyebrow = synergy_t( 'BEAUTY ESSENTIALS', 'treatment:hero:eyebrow:beauty' );
        $badge_text = synergy_t( 'Beauty essentials', 'treatment:hero:badge:beauty' );
    }
}
?>

<section class="treatment-hero-premium">
    <div class="treatment-hero-bg"></div>
    
    <div class="treatment-container hero-container">
        <!-- Colonna Sinistra (Testo) -->
        <div class="hero-text-col reveal-on-scroll">
            
            <nav class="treatment-breadcrumb" aria-label="<?php echo esc_attr( synergy_t( 'Breadcrumb', 'treatment:hero:breadcrumb:aria' ) ); ?>">
                <a href="<?php echo esc_url( home_url('/') ); ?>"><?php echo esc_html( synergy_t( 'Home', 'treatment:hero:breadcrumb:home' ) ); ?></a>
                <span class="sep">/</span>
                <a href="<?php echo esc_url( home_url('/trattamenti/') ); ?>"><?php echo esc_html( synergy_t( 'Trattamenti', 'treatment:hero:breadcrumb:treatments' ) ); ?></a>
                <?php if ( $breadcrumb_parent_title ) : ?>
                    <span class="sep">/</span>
                    <a href="<?php echo esc_url( $breadcrumb_parent_url ); ?>"><?php echo esc_html( $breadcrumb_parent_title ); ?></a>
                <?php endif; ?>
                <span class="sep">/</span>
                <span class="current"><?php echo esc_html( $title ); ?></span>
            </nav>

            <span class="treatment-eyebrow"><?php echo esc_html( $eyebrow ); ?></span>
            <h1 class="treatment-title"><?php echo esc_html( $title ); ?></h1>
            
            <div class="treatment-hero-actions">
                <a href="<?php echo esc_url(home_url('/contatti/')); ?>" class="btn-treatment-primary"><?php echo esc_html( synergy_t( 'Prenota una consulenza', 'treatment:hero:cta' ) ); ?></a>
            </div>
            
            <div class="treatment-trust-points">
                <div class="trust-point">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"></polyline></svg>
                    <span><?php echo esc_html( synergy_t( 'Analisi personalizzata', 'treatment:hero:point:1' ) ); ?></span>
                </div>
                <div class="trust-point">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"></polyline></svg>
                    <span><?php echo esc_html( synergy_t( 'Metodo su misura', 'treatment:hero:point:2' ) ); ?></span>
                </div>
                <div class="trust-point">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"></polyline></svg>
                    <span><?php echo esc_html( synergy_t( 'Tecnologie professionali', 'treatment:hero:point:3' ) ); ?></span>
                </div>
            </div>
        </div>

        <!-- Colonna Destra (Immagine) -->
        <div class="hero-image-col reveal-on-scroll delay-1">
            <div class="hero-image-frame parallax-image">
                <?php if ( $image_url ) : ?>
                    <img src="<?php echo esc_url( $image_url ); ?>" alt="<?php echo esc_attr( $title ); ?>" class="hero-featured-image">
                <?php else : ?>
                    <div class="hero-image-fallback">
                        <div class="fallback-glow"></div>
                    </div>
                <?php endif; ?>
                
                <div class="hero-image-overlay"></div>
                <div class="hero-badge">
                    <span class="badge-dot"></span>
                    <?php echo esc_html( $badge_text ); ?>
                </div>
            </div>
        </div>
    </div>
</section>
