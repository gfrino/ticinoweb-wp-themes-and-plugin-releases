<?php
/**
 * Template Name: Tecnologie
 * Description: Template dedicato alla pagina Tecnologie Estetiche
 */

get_header();

// Ottieni i dati dal CMS
$pt_data = get_option('synergy_products_technologies_data');
$tecnologie = array();

if (!empty($pt_data['items'])) {
    foreach ($pt_data['items'] as $item) {
        if ((!isset($item['active']) || $item['active']) && isset($item['category']) && $item['category'] === 'Tecnologia estetica') {
            $tecnologie[] = $item;
        }
    }
}

// Ordina per 'area' (categoria) e poi per 'order'
usort($tecnologie, function($a, $b) {
    $area_a = isset($a['area']) ? strtolower(trim($a['area'])) : '';
    $area_b = isset($b['area']) ? strtolower(trim($b['area'])) : '';
    
    // Se le aree sono diverse, ordina alfabeticamente per area
    if ($area_a !== $area_b) {
        return strcmp($area_a, $area_b);
    }
    
    // A parità di area, mantieni l'ordine impostato nel CMS
    $order_a = isset($a['order']) ? intval($a['order']) : 999;
    $order_b = isset($b['order']) ? intval($b['order']) : 999;
    return $order_a - $order_b;
});

// Funzione per normalizzare le stringhe delle categorie
if (!function_exists('synergy_normalize_category_slug')) {
    function synergy_normalize_category_slug($category) {
        $slug = strtolower($category);
        $slug = str_replace(array(' e ', ',', '.', ' / ', '/'), ' ', $slug);
        
        // Rimuovi accenti comuni
        $unwanted_array = array(
            'Š'=>'S', 'š'=>'s', 'Ž'=>'Z', 'ž'=>'z', 'À'=>'A', 'Á'=>'A', 'Â'=>'A', 'Ã'=>'A', 'Ä'=>'A', 'Å'=>'A', 'Æ'=>'A', 'Ç'=>'C', 'È'=>'E', 'É'=>'E',
            'Ê'=>'E', 'Ë'=>'E', 'Ì'=>'I', 'Í'=>'I', 'Î'=>'I', 'Ï'=>'I', 'Ñ'=>'N', 'Ò'=>'O', 'Ó'=>'O', 'Ô'=>'O', 'Õ'=>'O', 'Ö'=>'O', 'Ø'=>'O', 'Ù'=>'U',
            'Ú'=>'U', 'Û'=>'U', 'Ü'=>'U', 'Ý'=>'Y', 'Þ'=>'B', 'ß'=>'Ss', 'à'=>'a', 'á'=>'a', 'â'=>'a', 'ã'=>'a', 'ä'=>'a', 'å'=>'a', 'æ'=>'a', 'ç'=>'c',
            'è'=>'e', 'é'=>'e', 'ê'=>'e', 'ë'=>'e', 'ì'=>'i', 'í'=>'i', 'î'=>'i', 'ï'=>'i', 'ð'=>'o', 'ñ'=>'n', 'ò'=>'o', 'ó'=>'o', 'ô'=>'o', 'õ'=>'o',
            'ö'=>'o', 'ø'=>'o', 'ù'=>'u', 'ú'=>'u', 'û'=>'u', 'ý'=>'y', 'þ'=>'b', 'ÿ'=>'y'
        );
        $slug = strtr($slug, $unwanted_array);
        
        // Sostituisci spazi multipli con spazio singolo e formatta per slug se necessario, ma qui ci servono le classi CSS (quindi separate da spazio)
        $slug = preg_replace('/\s+/', ' ', $slug);
        return trim($slug);
    }
}

// Estrai categorie univoche
$unique_areas = array();
if (!empty($tecnologie)) {
    foreach ($tecnologie as $tech) {
        $area_raw = isset($tech['area']) ? $tech['area'] : '';
        if (!empty($area_raw)) {
            // Usa una separazione personalizzata per ottenere i nomi corretti per i bottoni
            // Dividiamo su '/' o ' e '
            $parts = preg_split('/(\/| e |,)/i', $area_raw);
            foreach ($parts as $part) {
                $clean_part = trim($part);
                if (!empty($clean_part)) {
                    // Capitalizza la prima lettera
                    $clean_part = ucfirst(strtolower($clean_part));
                    
                    // Slug per confronto
                    $slug = synergy_normalize_category_slug($clean_part);
                    
                    if (!isset($unique_areas[$slug])) {
                        $unique_areas[$slug] = $clean_part;
                    }
                }
            }
        }
    }
}

// Ordina in ordine alfabetico le aree
asort($unique_areas);

?>

<main id="primary" class="site-main page-tecnologie">

    <!-- 1. HERO TECNOLOGIE -->
    <section class="tecnologie-hero section relative overflow-hidden">
        <div class="tecnologie-hero-bg"></div>
        <div class="container relative z-10 flex-col lg-flex-row align-center hero-split">
            <div class="hero-content reveal">
                <span class="eyebrow"><?php echo esc_html( synergy_t( 'ESTETICA AVANZATA A LUGANO', 'tecnologie:hero:eyebrow' ) ); ?></span>
                <h1 class="hero-title"><?php echo esc_html( synergy_t( 'Tecnologie estetiche avanzate, scelte con metodo.', 'tecnologie:hero:title' ) ); ?></h1>
                <p class="hero-desc"><?php echo esc_html( synergy_t( 'Ogni tecnologia viene utilizzata all’interno di un percorso personalizzato, dopo una valutazione attenta delle esigenze della pelle, del corpo e degli obiettivi della persona.', 'tecnologie:hero:desc' ) ); ?></p>
                <div class="hero-actions">
                    <a href="<?php echo esc_url(home_url('/contatti/')); ?>" class="btn btn-primary"><?php echo esc_html( synergy_t( 'Prenota una consulenza', 'tecnologie:hero:cta_primary' ) ); ?></a>
                    <a href="#lab" class="btn btn-outline-silver"><?php echo esc_html( synergy_t( 'Scopri le tecnologie', 'tecnologie:hero:cta_secondary' ) ); ?></a>
                </div>
            </div>
            <?php
            // Foto della hero: immagine in evidenza della pagina (Pagine → Tecnologie).
            // Se non è impostata resta l'astrazione HTML/CSS qui sotto.
            $tech_hero_id   = get_queried_object_id();
            $tech_hero_img  = $tech_hero_id ? get_the_post_thumbnail(
                $tech_hero_id,
                'large',
                array(
                    'class'    => 'tech-hero-photo',
                    'loading'  => 'eager',
                    'decoding' => 'async',
                )
            ) : '';
            ?>
            <div class="hero-visual reveal delay-1<?php echo $tech_hero_img ? ' hero-visual--photo' : ''; ?>">
                <?php if ( $tech_hero_img ) : ?>
                    <div class="tech-hero-photo-frame">
                        <?php echo $tech_hero_img; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- markup generato da WordPress. ?>
                    </div>
                <?php else : ?>
                <!-- Astrazione HTML/CSS Tecnologica -->
                <div class="tech-visual-container">
                    <div class="tech-orb orb-large"></div>
                    <div class="tech-orb orb-medium"></div>
                    <div class="tech-orb orb-small"></div>
                    <div class="tech-glow"></div>
                    <div class="tech-nodes">
                        <div class="node n1"></div>
                        <div class="node n2"></div>
                        <div class="node n3"></div>
                        <div class="node n4"></div>
                        <div class="node n5"></div>
                    </div>
                    <div class="tech-lines">
                        <svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
                            <path d="M 20,100 Q 80,20 100,100 T 180,100" fill="none" class="tech-svg-line" />
                            <path d="M 50,150 Q 100,180 150,150" fill="none" class="tech-svg-line delay" />
                        </svg>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </section>

    <!-- 2. INTRO METODO -->
    <section class="tecnologie-intro section bg-ivory">
        <div class="container text-center reveal">
            <h2 class="h2-silver-glow"><?php echo esc_html( synergy_t( 'La tecnologia non sostituisce il metodo. Lo completa.', 'tecnologie:intro:title' ) ); ?></h2>
            <p class="intro-desc"><?php echo esc_html( synergy_t( 'Nel centro ogni apparecchio viene scelto in base al percorso più adatto, combinando ascolto, valutazione, manualità, prodotti professionali e tecnologie estetiche. L’obiettivo è proporre trattamenti mirati, realistici e personalizzati.', 'tecnologie:intro:desc' ) ); ?></p>
            
            <div class="intro-keypoints">
                <div class="kp-item">
                    <span class="kp-icon">01</span>
                    <h4><?php echo esc_html( synergy_t( 'Valutazione iniziale', 'tecnologie:intro:keypoint:1' ) ); ?></h4>
                </div>
                <div class="kp-line"></div>
                <div class="kp-item">
                    <span class="kp-icon">02</span>
                    <h4><?php echo esc_html( synergy_t( 'Scelta della tecnologia più adatta', 'tecnologie:intro:keypoint:2' ) ); ?></h4>
                </div>
                <div class="kp-line"></div>
                <div class="kp-item">
                    <span class="kp-icon">03</span>
                    <h4><?php echo esc_html( synergy_t( 'Percorso personalizzato', 'tecnologie:intro:keypoint:3' ) ); ?></h4>
                </div>
            </div>
        </div>
    </section>

    <!-- 3. TECHNOLOGY LAB INTERATTIVO -->
    <section id="lab" class="tecnologie-lab section bg-charcoal text-white relative">
        <!-- Sfondo dinamico -->
        <div class="lab-dynamic-bg">
            <div class="lab-gradient"></div>
            <div class="lab-particles" id="lab-particles"></div>
            <div class="lab-mesh"></div>
        </div>

        <div class="container relative z-10 reveal">
            <div class="section-header text-center lab-header">
                <h2 class="text-white lab-title-glow"><?php echo esc_html( synergy_t( 'Technology Lab', 'tecnologie:lab:title' ) ); ?></h2>
                <p class="silver-text"><?php echo esc_html( synergy_t( 'Scopri i macchinari e i sistemi avanzati a disposizione nel nostro centro.', 'tecnologie:lab:desc' ) ); ?></p>
            </div>
            
            <div class="lab-interactive">
                <!-- Sezione layout a 3 colonne -->
                <div class="lab-layout-3col">
                    <!-- Colonna SX: Categorie -->
                    <div class="lab-col-left lab-categories">
                        <button type="button" class="lab-cat-btn active" data-target="viso">
                            <span class="cat-name"><?php echo esc_html( synergy_t( 'Viso', 'tecnologie:lab:category:viso:name' ) ); ?></span>
                            <span class="cat-micro"><?php echo esc_html( synergy_t( 'Luminosità, tono, pelle', 'tecnologie:lab:category:viso:micro' ) ); ?></span>
                        </button>
                        <button type="button" class="lab-cat-btn" data-target="corpo">
                            <span class="cat-name"><?php echo esc_html( synergy_t( 'Corpo', 'tecnologie:lab:category:corpo:name' ) ); ?></span>
                            <span class="cat-micro"><?php echo esc_html( synergy_t( 'Rimodellamento e compattezza', 'tecnologie:lab:category:corpo:micro' ) ); ?></span>
                        </button>
                        <button type="button" class="lab-cat-btn" data-target="epilazione">
                            <span class="cat-name"><?php echo esc_html( synergy_t( 'Epilazione', 'tecnologie:lab:category:epilazione:name' ) ); ?></span>
                            <span class="cat-micro"><?php echo esc_html( synergy_t( 'Riduzione progressiva peli', 'tecnologie:lab:category:epilazione:micro' ) ); ?></span>
                        </button>
                        <button type="button" class="lab-cat-btn" data-target="pelle">
                            <span class="cat-name"><?php echo esc_html( synergy_t( 'Pelle', 'tecnologie:lab:category:pelle:name' ) ); ?></span>
                            <span class="cat-micro"><?php echo esc_html( synergy_t( 'Rigenerazione e qualità', 'tecnologie:lab:category:pelle:micro' ) ); ?></span>
                        </button>
                        <button type="button" class="lab-cat-btn" data-target="drenaggio">
                            <span class="cat-name"><?php echo esc_html( synergy_t( 'Drenaggio', 'tecnologie:lab:category:drenaggio:name' ) ); ?></span>
                            <span class="cat-micro"><?php echo esc_html( synergy_t( 'Leggerezza e benessere', 'tecnologie:lab:category:drenaggio:micro' ) ); ?></span>
                        </button>
                        <button type="button" class="lab-cat-btn" data-target="rimodellamento">
                            <span class="cat-name"><?php echo esc_html( synergy_t( 'Rimodellamento', 'tecnologie:lab:category:rimodellamento:name' ) ); ?></span>
                            <span class="cat-micro"><?php echo esc_html( synergy_t( 'Forma e silhouette', 'tecnologie:lab:category:rimodellamento:micro' ) ); ?></span>
                        </button>
                    </div>
                    
                    <!-- Colonna CENTRO: Nucleo e Chips -->
                    <div class="lab-col-center lab-core">
                        <div class="lab-beam" id="lab-beam"></div>
                        <div class="lab-core-circle">
                            <!-- SVG Orbite -->
                            <svg class="lab-svg-orbits" viewBox="0 0 400 400" xmlns="http://www.w3.org/2000/svg">
                                <circle cx="200" cy="200" r="190" class="orbit-line o1" />
                                <circle cx="200" cy="200" r="140" class="orbit-line o2" />
                                <circle cx="200" cy="200" r="90" class="orbit-line o3" />
                                <!-- Punti luce sulle orbite (gestiti via animazione CSS) -->
                                <circle cx="200" cy="10" r="3" class="orbit-dot d1" />
                                <circle cx="60" cy="200" r="2.5" class="orbit-dot d2" />
                                <circle cx="200" cy="290" r="2" class="orbit-dot d3" />
                            </svg>
                            <div class="lab-core-glow" id="lab-core-glow"></div>
                            
                            <!-- Contenitore Chips animate -->
                            <div class="lab-chips-container" id="lab-chips-container">
                                <!-- Generato via JS -->
                            </div>
                        </div>
                    </div>

                    <!-- Colonna DX: Pannello Dettagli -->
                    <div class="lab-col-right lab-panel">
                        <div class="lab-panel-content" id="lab-panel-content">
                            <span class="panel-area" id="lab-panel-area"><?php echo esc_html( synergy_t( 'Area Viso', 'tecnologie:panel:area' ) ); ?></span>
                            <h3 id="lab-panel-title"><?php echo esc_html( synergy_t( 'Tecnologie per il viso', 'tecnologie:panel:title' ) ); ?></h3>
                            <p id="lab-panel-desc"><?php echo esc_html( synergy_t( 'Sistemi professionali pensati per supportare luminosità, tono, rigenerazione e qualità della pelle.', 'tecnologie:panel:desc' ) ); ?></p>
                            
                            <div class="panel-list-wrapper">
                                <h4><?php echo esc_html( synergy_t( 'Tecnologie collegate:', 'tecnologie:panel:list_title' ) ); ?></h4>
                                <ul id="lab-panel-list">
                                    <!-- Generato via JS -->
                                </ul>
                            </div>
                            
                            <div class="panel-cta">
                                <a href="#tech-grid-container" class="btn btn-outline-silver btn-sm" style="color: var(--synergy-white-soft); border-color: var(--synergy-silver);"><?php echo esc_html( synergy_t( 'Esplora la griglia', 'tecnologie:panel:cta' ) ); ?></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- 4. FILTRI E GRIGLIA -->
    <section class="tecnologie-grid-section section bg-pearl">
        <div class="container reveal">


            <!-- Griglia -->
            <div class="tech-grid" id="tech-grid-container">
                <?php 
                if (!empty($tecnologie)) {
                    $count = 1;
                    foreach ($tecnologie as $tech) {
                        $name = esc_html( synergy_t( $tech['name'], 'tecnologie:item:' . sanitize_title( $tech['name'] ) . ':name' ) );
                        $desc = esc_html( synergy_t( $tech['description'], 'tecnologie:item:' . sanitize_title( $tech['name'] ) . ':description' ) );
                        $area_raw = isset($tech['area']) ? $tech['area'] : '';
                        $area = esc_html( synergy_t( $area_raw, 'tecnologie:area:' . sanitize_title( $area_raw ) ) );
                        
                        // Per il data-categories, usiamo il normalizzatore robusto
                        $filter_classes = synergy_normalize_category_slug($area_raw);
                        
                        // Icona SVG statica fallback
                        $icon_svg = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><rect x="2" y="3" width="20" height="14" rx="2" ry="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/></svg>';
                        
                        echo '<div class="tech-card reveal" data-categories="' . esc_attr($filter_classes) . '">';
                        echo '  <div class="tech-card-header">';
                        echo '      <span class="tech-number">' . sprintf('%02d', $count) . '</span>';
                        echo '      <span class="tech-badge">' . $area . '</span>';
                        echo '  </div>';
                        echo '  <div class="tech-card-body">';
                        echo '      <div class="tech-icon">' . $icon_svg . '</div>';
                        echo '      <h3 class="tech-name">' . $name . '</h3>';
                        echo '      <p class="tech-desc">' . $desc . '</p>';
                        echo '  </div>';
                        echo '  <div class="tech-card-footer">';
                        echo '      <a href="' . esc_url(home_url('/contatti/')) . '" class="tech-link">' . esc_html( synergy_t( 'Richiedi consulenza', 'tecnologie:item:cta' ) ) . ' <svg viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" stroke-width="2" fill="none"><polyline points="9 18 15 12 9 6"></polyline></svg></a>';
                        echo '  </div>';
                        echo '</div>';
                        $count++;
                    }
                } else {
                    echo '<p class="text-center w-100">' . esc_html( synergy_t( 'Nessuna tecnologia disponibile al momento.', 'tecnologie:empty' ) ) . '</p>';
                }
                ?>
            </div>
        </div>
    </section>

    <!-- 6. COME SCEGLIAMO -->
    <section class="tecnologie-process section bg-white">
        <div class="container reveal">
            <div class="section-header text-center">
                <h2><?php echo esc_html( synergy_t( 'Come scegliamo la tecnologia più adatta.', 'tecnologie:method:title' ) ); ?></h2>
            </div>
            
            <div class="tech-timeline">
                <div class="timeline-item reveal delay-1">
                    <div class="t-num">01</div>
                    <div class="timeline-content">
                        <h4><?php echo esc_html( synergy_t( 'Ascolto', 'tecnologie:method:1:title' ) ); ?></h4>
                        <p><?php echo esc_html( synergy_t( 'Comprendiamo esigenze, obiettivi e aspettative.', 'tecnologie:method:1:text' ) ); ?></p>
                    </div>
                </div>
                <div class="timeline-item reveal delay-2">
                    <div class="t-num">02</div>
                    <div class="timeline-content">
                        <h4><?php echo esc_html( synergy_t( 'Valutazione', 'tecnologie:method:2:title' ) ); ?></h4>
                        <p><?php echo esc_html( synergy_t( 'Analizziamo pelle, corpo, zona da trattare e priorità.', 'tecnologie:method:2:text' ) ); ?></p>
                    </div>
                </div>
                <div class="timeline-item reveal delay-3">
                    <div class="t-num">03</div>
                    <div class="timeline-content">
                        <h4><?php echo esc_html( synergy_t( 'Scelta', 'tecnologie:method:3:title' ) ); ?></h4>
                        <p><?php echo esc_html( synergy_t( 'Selezioniamo manualità, prodotti e tecnologia più coerenti.', 'tecnologie:method:3:text' ) ); ?></p>
                    </div>
                </div>
                <div class="timeline-item reveal delay-4">
                    <div class="t-num">04</div>
                    <div class="timeline-content">
                        <h4><?php echo esc_html( synergy_t( 'Percorso', 'tecnologie:method:4:title' ) ); ?></h4>
                        <p><?php echo esc_html( synergy_t( 'Costruiamo un trattamento realistico, personalizzato e progressivo.', 'tecnologie:method:4:text' ) ); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </section>

</main>

<?php get_footer(); ?>
