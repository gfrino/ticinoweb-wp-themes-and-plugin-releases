<?php
require_once '../../../../wp-load.php'; // wait, wp-content/themes/child/test-unique.php -> wp-load is at ../../../wp-load.php
$data = get_option('synergy_price_list_data');
$json = wp_json_encode($data);
if ($json === false) {
    echo "FAILED: " . json_last_error_msg();
} else {
    echo "SUCCESS_LEN: " . strlen($json);
}
