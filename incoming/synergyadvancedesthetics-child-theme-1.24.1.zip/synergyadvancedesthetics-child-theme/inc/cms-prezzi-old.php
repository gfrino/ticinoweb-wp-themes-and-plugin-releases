<?php
/**
 * CMS Backend per la gestione del Listino Prezzi Viso
 */

if (!defined('ABSPATH')) {
    exit;
}

// 1. Hook per aggiungere la pagina al menu
add_action('admin_menu', 'synergy_add_price_list_menu', 100);
function synergy_add_price_list_menu() {
    add_submenu_page(
        'ticinoweb-cms', // Parent slug
        'Listino Prezzi',
        'Listino Prezzi',
        'manage_options', // Updated from edit_pages to manage_options for better security match
        'synergy-price-list',
        'synergy_render_price_list_page'
    );
}

// 2. Dati iniziali di default dal PDF (Backup)
function synergy_get_default_price_list_data() {
    return [
        'settings' => [
            'enabled' => true,
            'eyebrow' => 'Listino trattamenti',
            'title' => 'Prezzi trattamenti estetici viso',
            'subtitle' => 'Una selezione di trattamenti viso personalizzati, protocolli professionali e tecnologie avanzate.',
            'note' => 'I prezzi possono variare in base alla valutazione iniziale e al percorso consigliato.',
            'cta_label' => 'Prenota una consulenza',
            'cta_url' => '/contatti/',
            'max_items' => 8,
            'show_featured_first' => true,
            'show_load_more' => true,
        ],
        'categories' => [
            [
                'id' => 'rigenerazione-biohacking',
                'title' => 'Rigenerazione avanzata & Biohacking cellulare',
                'short_title' => 'Rigenerazione',
                'description' => 'Protocolli avanzati per rigenerazione cutanea, qualità della pelle, rughe, cicatrici e densità cutanea.',
                'order' => 1,
                'visible' => true
            ],
            [
                'id' => 'peeling-rinnovamento',
                'title' => 'Peeling clinici & Rinnovamento cutaneo',
                'short_title' => 'Peeling',
                'description' => 'Peeling professionali e trattamenti di rinnovamento per macchie, acne, pori, texture e luminosità.',
                'order' => 2,
                'visible' => true
            ],
            [
                'id' => 'manuali-massaggi',
                'title' => 'Trattamenti manuali & Massaggi',
                'short_title' => 'Manuali & Massaggi',
                'description' => 'Trattamenti manuali e massaggi viso per pulizia, modellamento, idratazione e cura personalizzata.',
                'order' => 3,
                'visible' => true
            ],
            [
                'id' => 'tecnologie-dermatologiche',
                'title' => 'Tecnologie dermatologiche avanzate',
                'short_title' => 'Tecnologie',
                'description' => 'Tecnologie professionali per analisi, idratazione, lifting, radiofrequenza, plasma freddo e trattamenti mirati.',
                'order' => 4,
                'visible' => true
            ]
        ],
        'items' => [
            // Cat 1: rigenerazione-biohacking
            [
                'id' => 'terapia-peptidica-microneedling',
                'category_id' => 'rigenerazione-biohacking',
                'name' => 'Terapia Peptidica Avanzata & Microneedling',
                'duration' => '80 min.',
                'price_type' => 'fixed',
                'price_fixed' => 205,
                'price_min' => '',
                'price_max' => '',
                'price_label' => 'CHF 205.00',
                'description' => 'Infiltrazioni con micro-aghi di peptidi biomimetici (GHK-Cu), acido ialuronico e vitamine per rigenerazione profonda, rughe e cicatrici.',
                'featured' => true,
                'visible' => true,
                'order' => 1,
                'variants' => []
            ],
            [
                'id' => 'esosomi-nidosomi-celltermi',
                'category_id' => 'rigenerazione-biohacking',
                'name' => 'Trattamento agli Esosomi e Nidosomi (Celltermi Revive NX)',
                'duration' => '75 min.',
                'price_type' => 'fixed',
                'price_fixed' => 220,
                'price_min' => '',
                'price_max' => '',
                'price_label' => 'CHF 220.00',
                'description' => 'Biohacking biotecnologico d\'avanguardia per la rigenerazione cellulare profonda e il ripristino della densità cutanea.',
                'featured' => false,
                'visible' => true,
                'order' => 2,
                'variants' => []
            ],
            
            // Cat 2: peeling-rinnovamento
            [
                'id' => 'green-peel-classic',
                'category_id' => 'peeling-rinnovamento',
                'name' => 'GREEN PEEL Classic (Dott. Schrammek)',
                'duration' => '',
                'price_type' => 'fixed',
                'price_fixed' => 415,
                'price_min' => '',
                'price_max' => '',
                'price_label' => 'CHF 415.00',
                'description' => 'Peeling intensivo alle erbe per rigenerazione, ringiovanimento, rimozione di macchie senili, acne e smagliature.',
                'featured' => true,
                'visible' => true,
                'order' => 1,
                'variants' => []
            ],
            [
                'id' => 'green-peel-energy',
                'category_id' => 'peeling-rinnovamento',
                'name' => 'GREEN PEEL Energy (Dott. Schrammek)',
                'duration' => '90 min.',
                'price_type' => 'fixed',
                'price_fixed' => 195,
                'price_min' => '',
                'price_max' => '',
                'price_label' => 'CHF 195.00',
                'description' => 'Prevenzione dell\'invecchiamento cutaneo e rimozione di pigmentazioni solari.',
                'featured' => false,
                'visible' => true,
                'order' => 2,
                'variants' => []
            ],
            [
                'id' => 'green-peel-fresh-up',
                'category_id' => 'peeling-rinnovamento',
                'name' => 'GREEN PEEL Fresh Up (Dott. Schrammek)',
                'duration' => '90 min.',
                'price_type' => 'fixed',
                'price_fixed' => 135,
                'price_min' => '',
                'price_max' => '',
                'price_label' => 'CHF 135.00',
                'description' => 'Freschezza, metabolismo attivo ed idratazione profonda.',
                'featured' => false,
                'visible' => true,
                'order' => 3,
                'variants' => []
            ],
            [
                'id' => 'cosmelan-mesoestetic',
                'category_id' => 'peeling-rinnovamento',
                'name' => 'Cosmelan (Mesoestetic)',
                'duration' => '',
                'price_type' => 'fixed',
                'price_fixed' => 990,
                'price_min' => '',
                'price_max' => '',
                'price_label' => 'CHF 990.00',
                'description' => 'Peeling potente anti-macchie.',
                'featured' => true,
                'visible' => true,
                'order' => 4,
                'variants' => []
            ],
            [
                'id' => 'acne-peel-system',
                'category_id' => 'peeling-rinnovamento',
                'name' => 'Acne Peel System (Mesoestetic)',
                'duration' => '45 min.',
                'price_type' => 'from',
                'price_fixed' => '',
                'price_min' => 125,
                'price_max' => '',
                'price_label' => 'da CHF 125.00',
                'description' => 'Cura efficace contro l\'acne giovanile e tardiva.',
                'featured' => false,
                'visible' => true,
                'order' => 5,
                'variants' => []
            ],
            [
                'id' => 'dermapeels-peeling-chimici',
                'category_id' => 'peeling-rinnovamento',
                'name' => 'Dermapeels / Peeling Chimici Mirati (Mesoestetic)',
                'duration' => '60 min.',
                'price_type' => 'from',
                'price_fixed' => '',
                'price_min' => 115,
                'price_max' => '',
                'price_label' => 'da CHF 115.00',
                'description' => 'Acido glicolico, salicilico, mandelico, lattico, TCA per ringiovanimento, depigmentazione, pori allargati, acne e segni dell\'acne.',
                'featured' => false,
                'visible' => true,
                'order' => 6,
                'variants' => []
            ],
            [
                'id' => 'prx-t33-prx-plus',
                'category_id' => 'peeling-rinnovamento',
                'name' => 'PRX-T33 / PRX-PLUS',
                'duration' => '60 min.',
                'price_type' => 'from',
                'price_fixed' => '',
                'price_min' => 135,
                'price_max' => '',
                'price_label' => 'da CHF 135.00',
                'description' => 'Anti-age, macchie, pelle sottile e rugosa, pori ostruiti e acne.',
                'featured' => false,
                'visible' => true,
                'order' => 7,
                'variants' => []
            ],
            
            // Cat 3: manuali-massaggi
            [
                'id' => 'pulizia-manuale-pelle',
                'category_id' => 'manuali-massaggi',
                'name' => 'La Pulizia Manuale della Pelle',
                'duration' => '75 min.',
                'price_type' => 'from',
                'price_fixed' => '',
                'price_min' => 105,
                'price_max' => '',
                'price_label' => 'da CHF 105.00',
                'description' => 'Effettuata con prodotti adatti al vostro tipo di pelle.',
                'featured' => true,
                'visible' => true,
                'order' => 1,
                'variants' => []
            ],
            [
                'id' => 'massaggio-giapponese-cobidu',
                'category_id' => 'manuali-massaggi',
                'name' => 'Massaggio Giapponese Modellante COBIDU',
                'duration' => '40 min.',
                'price_type' => 'fixed',
                'price_fixed' => 65,
                'price_min' => '',
                'price_max' => '',
                'price_label' => 'CHF 65.00',
                'description' => 'Con la maschera liftante o idratante.',
                'featured' => false,
                'visible' => true,
                'order' => 2,
                'variants' => []
            ],
            
            // Cat 4: tecnologie-dermatologiche
            [
                'id' => 'analisi-pelle-skin-solutionist',
                'category_id' => 'tecnologie-dermatologiche',
                'name' => 'Analisi della Pelle con SKIN SOLUTIONIST',
                'duration' => '35 min.',
                'price_type' => 'fixed',
                'price_fixed' => 50,
                'price_min' => '',
                'price_max' => '',
                'price_label' => 'CHF 50.00',
                'description' => 'Analisi di idratazione, collagene, pori, sensibilità, capillari, acne ecc.',
                'featured' => false,
                'visible' => true,
                'order' => 1,
                'variants' => []
            ],
            [
                'id' => 'hydrofacial-synergy',
                'category_id' => 'tecnologie-dermatologiche',
                'name' => 'Hydrofacial (Synergy+)',
                'duration' => '50 min.',
                'price_type' => 'from',
                'price_fixed' => '',
                'price_min' => 115,
                'price_max' => '',
                'price_label' => 'da CHF 115.00',
                'description' => 'Pulizia viso anti-age profonda con vacuum.',
                'featured' => false,
                'visible' => true,
                'order' => 2,
                'variants' => []
            ],
            [
                'id' => 'ice-fire-is-clinical',
                'category_id' => 'tecnologie-dermatologiche',
                'name' => 'Ice & Fire (iS Clinical)',
                'duration' => '75 min.',
                'price_type' => 'fixed',
                'price_fixed' => 145,
                'price_min' => '',
                'price_max' => '',
                'price_label' => 'CHF 145.00',
                'description' => 'Con microcorrenti — ringiovanimento della pelle, lifting.',
                'featured' => false,
                'visible' => true,
                'order' => 3,
                'variants' => []
            ],
            [
                'id' => 'radiofrequenza-monopolare-bipolare',
                'category_id' => 'tecnologie-dermatologiche',
                'name' => 'Radiofrequenza Monopolare / Bipolare (CoaxMed)',
                'duration' => '75 min.',
                'price_type' => 'fixed',
                'price_fixed' => 135,
                'price_min' => '',
                'price_max' => '',
                'price_label' => 'CHF 135.00',
                'description' => 'Drenaggio, doppio mento, rughe, rilassamento cutaneo, pori, acne, iperpigmentazione.',
                'featured' => false,
                'visible' => true,
                'order' => 4,
                'variants' => []
            ],
            [
                'id' => 'radiofrequenza-frazionata-microaghi',
                'category_id' => 'tecnologie-dermatologiche',
                'name' => 'Radiofrequenza Frazionata con Microaghi (CoaxMed)',
                'duration' => '75 min.',
                'price_type' => 'fixed',
                'price_fixed' => 165,
                'price_min' => '',
                'price_max' => '',
                'price_label' => 'CHF 165.00',
                'description' => 'Rigenerazione e ristrutturazione profonda della pelle.',
                'featured' => false,
                'visible' => true,
                'order' => 5,
                'variants' => []
            ],
            [
                'id' => 'smas-lifting',
                'category_id' => 'tecnologie-dermatologiche',
                'name' => 'SMAS-Lifting',
                'duration' => '',
                'price_type' => 'range',
                'price_fixed' => '',
                'price_min' => 220,
                'price_max' => 550,
                'price_label' => 'da CHF 220.00 a CHF 550.00',
                'description' => 'Ultrasuono focalizzato: effetto lifting non chirurgico per contorno del viso, collo, sopracciglia ecc.',
                'featured' => true,
                'visible' => true,
                'order' => 6,
                'variants' => [
                    [
                        'id' => 'smas-contorno-viso',
                        'name' => 'Contorno viso',
                        'duration' => '60 min.',
                        'price_fixed' => 220,
                        'price_label' => 'CHF 220.00',
                        'order' => 1,
                        'visible' => true
                    ],
                    [
                        'id' => 'smas-contorno-viso-collo',
                        'name' => 'Contorno viso + collo',
                        'duration' => '70 min.',
                        'price_fixed' => 320,
                        'price_label' => 'CHF 320.00',
                        'order' => 2,
                        'visible' => true
                    ],
                    [
                        'id' => 'smas-viso-collo',
                        'name' => 'Viso + collo',
                        'duration' => '90 min.',
                        'price_fixed' => 400,
                        'price_label' => 'CHF 400.00',
                        'order' => 3,
                        'visible' => true
                    ],
                    [
                        'id' => 'smas-collo-decollete-30',
                        'name' => 'Collo + décolleté',
                        'duration' => '30 min.',
                        'price_fixed' => 220,
                        'price_label' => 'CHF 220.00',
                        'order' => 4,
                        'visible' => true
                    ],
                    [
                        'id' => 'smas-collo-decollete-70',
                        'name' => 'Collo + décolleté',
                        'duration' => '70 min.',
                        'price_fixed' => 320,
                        'price_label' => 'CHF 320.00',
                        'order' => 5,
                        'visible' => true
                    ],
                    [
                        'id' => 'smas-fulle-face',
                        'name' => 'Fulle face',
                        'duration' => '120 min.',
                        'price_fixed' => 550,
                        'price_label' => 'CHF 550.00',
                        'order' => 6,
                        'visible' => true
                    ]
                ]
            ],
            [
                'id' => 'elettrocoagulazione',
                'category_id' => 'tecnologie-dermatologiche',
                'name' => 'Elettrocoagulazione',
                'duration' => '1 min.',
                'price_type' => 'fixed',
                'price_fixed' => 3,
                'price_min' => '',
                'price_max' => '',
                'price_label' => 'CHF 3.00',
                'description' => 'Anomalie della pelle: angiomi, capillari, papilomi ecc.',
                'featured' => false,
                'visible' => true,
                'order' => 7,
                'variants' => []
            ],
            [
                'id' => 'cold-plasma-cnc',
                'category_id' => 'tecnologie-dermatologiche',
                'name' => 'Cold Plasma / Plasma Freddo (CNC)',
                'duration' => '70 min.',
                'price_type' => 'fixed',
                'price_fixed' => 115,
                'price_min' => '',
                'price_max' => '',
                'price_label' => 'CHF 115.00',
                'description' => 'Idratazione, anti-age, cura dell\'acne, acne rosacea, couperose, macchie ecc. Cura delle anomalie della pelle: verruche, funghi, herpes, micosi ecc. 10 min. — CHF 20.00 / 1 min. — CHF 3.00.',
                'featured' => false,
                'visible' => true,
                'order' => 8,
                'variants' => [
                    [
                        'id' => 'cold-plasma-anomalie-10',
                        'name' => 'Cura anomalie della pelle',
                        'duration' => '10 min.',
                        'price_fixed' => 20,
                        'price_label' => 'CHF 20.00',
                        'order' => 1,
                        'visible' => true
                    ],
                    [
                        'id' => 'cold-plasma-anomalie-1',
                        'name' => 'Cura anomalie della pelle',
                        'duration' => '1 min.',
                        'price_fixed' => 3,
                        'price_label' => 'CHF 3.00',
                        'order' => 2,
                        'visible' => true
                    ]
                ]
            ],
            [
                'id' => 'hidro-elettroporazione-hd-m20',
                'category_id' => 'tecnologie-dermatologiche',
                'name' => 'Hidro-Elettroporazione HD-M20 (X-PRO Technology)',
                'duration' => '60 min.',
                'price_type' => 'from',
                'price_fixed' => '',
                'price_min' => 125,
                'price_max' => '',
                'price_label' => 'da CHF 125.00',
                'description' => 'Nutrimento e idratazione, produzione di collagene, lifting, rughe, lassità cutanea ecc.',
                'featured' => false,
                'visible' => true,
                'order' => 9,
                'variants' => []
            ],
            [
                'id' => 'oxygeneo-pologen',
                'category_id' => 'tecnologie-dermatologiche',
                'name' => 'Oxygeneo+ (Pologen)',
                'duration' => '50 min.',
                'price_type' => 'from',
                'price_fixed' => '',
                'price_min' => 115,
                'price_max' => '',
                'price_label' => 'da CHF 115.00',
                'description' => 'Detox, Anti Age, Illuminante, Idratante, indicato anche per pelle grassa con pori allargati.',
                'featured' => false,
                'visible' => true,
                'order' => 10,
                'variants' => []
            ]
        ]
    ];
}

add_action('admin_init', 'synergy_maybe_seed_price_list_data');
function synergy_maybe_seed_price_list_data() {
    $saved_data = get_option('synergy_price_list_data');
    if (empty($saved_data)) {
        update_option('synergy_price_list_data', synergy_get_default_price_list_data());
    }
}

// 3. Render Page UI
function synergy_render_price_list_page() {
    if (!current_user_can('manage_options')) {
        return;
    }

    // Gestione salvataggio
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['synergy_price_list_nonce']) && wp_verify_nonce($_POST['synergy_price_list_nonce'], 'synergy_save_price_list')) {
        
        if (isset($_POST['action']) && $_POST['action'] === 'restore_pdf') {
            $data = synergy_get_default_price_list_data();
            update_option('synergy_price_list_data', $data);
            echo '<div class="notice notice-success is-dismissible"><p>Listino ripristinato con i dati originali del PDF.</p></div>';
        } else {
            $data_json = wp_unslash($_POST['synergy_price_list_data_json']);
            $data = json_decode($data_json, true);
            if ($data) {
                // Basic sanitization
                $sanitized_data = [];
                
                // Settings
                $sanitized_data['settings'] = [
                    'enabled' => !empty($data['settings']['enabled']),
                    'eyebrow' => sanitize_text_field($data['settings']['eyebrow'] ?? ''),
                    'title' => sanitize_text_field($data['settings']['title'] ?? ''),
                    'subtitle' => sanitize_textarea_field($data['settings']['subtitle'] ?? ''),
                    'note' => sanitize_textarea_field($data['settings']['note'] ?? ''),
                    'cta_label' => sanitize_text_field($data['settings']['cta_label'] ?? ''),
                    'cta_url' => esc_url_raw($data['settings']['cta_url'] ?? ''),
                    'max_items' => intval($data['settings']['max_items'] ?? 8),
                    'show_featured_first' => !empty($data['settings']['show_featured_first']),
                    'show_load_more' => !empty($data['settings']['show_load_more']) ?? true,
                ];
                
                // Categories
                $sanitized_data['categories'] = [];
                if (!empty($data['categories']) && is_array($data['categories'])) {
                    foreach ($data['categories'] as $cat) {
                        $sanitized_data['categories'][] = [
                            'id' => sanitize_text_field($cat['id']),
                            'title' => sanitize_text_field($cat['title']),
                            'short_title' => sanitize_text_field($cat['short_title'] ?? ''),
                            'description' => sanitize_textarea_field($cat['description']),
                            'order' => intval($cat['order']),
                            'visible' => !empty($cat['visible'])
                        ];
                    }
                }
                
                // Items
                $sanitized_data['items'] = [];
                if (!empty($data['items']) && is_array($data['items'])) {
                    foreach ($data['items'] as $item) {
                        $sanitized_item = [
                            'id' => sanitize_text_field($item['id']),
                            'category_id' => sanitize_text_field($item['category_id']),
                            'name' => sanitize_text_field($item['name']),
                            'duration' => sanitize_text_field($item['duration']),
                            'price_type' => sanitize_text_field($item['price_type'] ?? 'fixed'),
                            'price_fixed' => sanitize_text_field($item['price_fixed'] ?? ''),
                            'price_min' => sanitize_text_field($item['price_min'] ?? ''),
                            'price_max' => sanitize_text_field($item['price_max'] ?? ''),
                            'price_label' => sanitize_text_field($item['price_label']),
                            'description' => sanitize_textarea_field($item['description']),
                            'featured' => !empty($item['featured']),
                            'visible' => !empty($item['visible']),
                            'order' => intval($item['order']),
                            'variants' => []
                        ];
                        
                        if (!empty($item['variants']) && is_array($item['variants'])) {
                            foreach ($item['variants'] as $var) {
                                $sanitized_item['variants'][] = [
                                    'id' => sanitize_text_field($var['id']),
                                    'name' => sanitize_text_field($var['name']),
                                    'duration' => sanitize_text_field($var['duration']),
                                    'price_fixed' => sanitize_text_field($var['price_fixed'] ?? ''),
                                    'price_label' => sanitize_text_field($var['price_label']),
                                    'order' => intval($var['order']),
                                    'visible' => !empty($var['visible'])
                                ];
                            }
                        }
                        $sanitized_data['items'][] = $sanitized_item;
                    }
                }

                update_option('synergy_price_list_data', $sanitized_data);
                echo '<div class="notice notice-success is-dismissible"><p>Modifiche salvate con successo.</p></div>';
            } else {
                echo '<div class="notice notice-error is-dismissible"><p>Errore durante il salvataggio dei dati (JSON non valido).</p></div>';
            }
        }
    }

    $saved_data = get_option('synergy_price_list_data');
    if (empty($saved_data)) {
        $saved_data = synergy_get_default_price_list_data();
        update_option('synergy_price_list_data', $saved_data);
    }
    
    // Inject CSS
    synergy_price_list_admin_styles();
    ?>

    <div class="wrap sy-admin-wrap" id="sy-app">
        
        <!-- Header -->
        <div class="sy-header">
            <div class="sy-header-title">
                <h1>Listino Prezzi Viso</h1>
                <p>Gestisci categorie, trattamenti, durate, prezzi e varianti visualizzati nella Home.</p>
            </div>
            
            <div class="sy-header-actions">
                <a href="<?php echo esc_url(home_url('/#listino-prezzi')); ?>" target="_blank" class="sy-btn sy-btn-outline">Anteprima Home &rarr;</a>
                <button type="button" class="sy-btn sy-btn-primary" onclick="sySaveForm()">Salva modifiche</button>
            </div>
        </div>
        
        <!-- Stats -->
        <div class="sy-stats">
            <div class="sy-stat-box">
                <span class="sy-stat-label">Categorie attive</span>
                <span class="sy-stat-val" id="stat-cats">0</span>
            </div>
            <div class="sy-stat-box">
                <span class="sy-stat-label">Trattamenti visibili</span>
                <span class="sy-stat-val" id="stat-items">0</span>
            </div>
            <div class="sy-stat-box">
                <span class="sy-stat-label">Fascia prezzo stimata</span>
                <span class="sy-stat-val" id="stat-price">-</span>
            </div>
        </div>

        <div class="sy-layout">
            
            <!-- Settings Card -->
            <div class="sy-card sy-settings-card">
                <div class="sy-card-header">
                    <h3>Impostazioni sezione</h3>
                    <label class="sy-toggle">
                        <input type="checkbox" id="set_enabled">
                        <span class="sy-slider"></span>
                        <span class="sy-toggle-label">Sezione attiva</span>
                    </label>
                </div>
                <div class="sy-card-body">
                    <div class="sy-form-grid">
                        <div class="sy-form-group">
                            <label>Eyebrow</label>
                            <input type="text" id="set_eyebrow" placeholder="es. Listino trattamenti">
                        </div>
                        <div class="sy-form-group">
                            <label>Titolo principale</label>
                            <input type="text" id="set_title" placeholder="es. Prezzi trattamenti estetici viso">
                        </div>
                        <div class="sy-form-group sy-col-full">
                            <label>Sottotitolo</label>
                            <textarea id="set_subtitle" rows="2"></textarea>
                        </div>
                        <div class="sy-form-group sy-col-full">
                            <label>Nota sotto il listino</label>
                            <textarea id="set_note" rows="2" placeholder="I prezzi possono variare..."></textarea>
                        </div>
                        <div class="sy-form-group">
                            <label>Testo pulsante CTA</label>
                            <input type="text" id="set_cta_label">
                        </div>
                        <div class="sy-form-group">
                            <label>Link CTA</label>
                            <input type="text" id="set_cta_url">
                        </div>
                        <div class="sy-form-group">
                            <label>Trattamenti visibili in Home</label>
                            <input type="number" id="set_max_items" style="max-width: 80px;">
                            <span class="sy-help">Max elementi prima di "Mostra tutti"</span>
                        </div>
                        <div class="sy-form-group" style="align-self: center;">
                            <label class="sy-toggle" style="margin-top:20px;">
                                <input type="checkbox" id="set_show_featured">
                                <span class="sy-slider"></span>
                                <span class="sy-toggle-label">Mostra "In evidenza" per primi</span>
                            </label>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Categories Area -->
            <div class="sy-categories-header">
                <h2>Categorie listino</h2>
                <button type="button" class="sy-btn sy-btn-secondary" onclick="syOpenCategoryModal()">+ Aggiungi categoria</button>
            </div>

            <div id="sy-categories-container" class="sy-categories-list">
                <!-- Javascript will render categories here -->
            </div>

            <!-- Advanced Tools -->
            <div class="sy-card sy-advanced-tools">
                <div class="sy-card-header" onclick="document.getElementById('sy-advanced-body').classList.toggle('sy-hidden')" style="cursor:pointer;">
                    <h3>Strumenti avanzati <small>(Solo per sviluppatori)</small></h3>
                    <span>&#9660;</span>
                </div>
                <div class="sy-card-body sy-hidden" id="sy-advanced-body">
                    <p class="sy-help" style="color: #b7791f;">Attenzione: Area tecnica. Modificare questi dati può corrompere il listino.</p>
                    
                    <form method="post" id="sy-main-form">
                        <?php wp_nonce_field('synergy_save_price_list', 'synergy_price_list_nonce'); ?>
                        <input type="hidden" name="action" id="sy_form_action" value="save">
                        <textarea name="synergy_price_list_data_json" id="synergy_price_list_data_json" class="sy-json-editor"><?php echo htmlspecialchars(wp_json_encode($saved_data, JSON_PRETTY_PRINT)); ?></textarea>
                    </form>

                    <div style="margin-top: 20px; display:flex; gap:10px;">
                        <button type="button" class="sy-btn" onclick="syForceUpdateFromJson()">Aggiorna UI da JSON</button>
                        <form method="post" style="margin:0;" onsubmit="return confirm('ATTENZIONE: Questo formatterà tutto e ripristinerà i dati originali dal PDF. Tutti i tuoi nuovi prezzi e trattamenti andranno persi. Sei sicuro?');">
                            <?php wp_nonce_field('synergy_save_price_list', 'synergy_price_list_nonce'); ?>
                            <input type="hidden" name="action" value="restore_pdf">
                            <button type="submit" class="sy-btn sy-btn-danger">Ripristina listino dal PDF</button>
                        </form>
                    </div>
                </div>
            </div>

        </div> <!-- /sy-layout -->
    </div> <!-- /wrap -->

    <!-- Modal Categoria -->
    <div id="sy-cat-modal" class="sy-modal">
        <div class="sy-modal-content">
            <div class="sy-modal-header">
                <h3 id="sy-cat-modal-title">Modifica Categoria</h3>
                <span class="sy-close" onclick="syCloseModal('sy-cat-modal')">&times;</span>
            </div>
            <div class="sy-modal-body">
                <input type="hidden" id="cat_edit_id">
                <div class="sy-form-group">
                    <label>Titolo Categoria</label>
                    <input type="text" id="cat_edit_title" style="width:100%;">
                </div>
                <div class="sy-form-group">
                    <label>Titolo Corto (per filtri/tab)</label>
                    <input type="text" id="cat_edit_short_title" style="width:100%;">
                </div>
                <div class="sy-form-group">
                    <label>Descrizione</label>
                    <textarea id="cat_edit_desc" style="width:100%;" rows="3"></textarea>
                </div>
                <div class="sy-form-group">
                    <label class="sy-toggle">
                        <input type="checkbox" id="cat_edit_visible">
                        <span class="sy-slider"></span>
                        <span class="sy-toggle-label">Categoria Visibile</span>
                    </label>
                </div>
            </div>
            <div class="sy-modal-footer">
                <button type="button" class="sy-btn" onclick="syCloseModal('sy-cat-modal')">Annulla</button>
                <button type="button" class="sy-btn sy-btn-primary" onclick="sySaveCategory()">Salva Categoria</button>
            </div>
        </div>
    </div>

    <!-- Modal Trattamento -->
    <div id="sy-item-modal" class="sy-modal sy-modal-large">
        <div class="sy-modal-content">
            <div class="sy-modal-header">
                <h3 id="sy-item-modal-title">Modifica Trattamento</h3>
                <span class="sy-close" onclick="syCloseModal('sy-item-modal')">&times;</span>
            </div>
            <div class="sy-modal-body">
                
                <div class="sy-item-layout">
                    <!-- Left Column: Details -->
                    <div class="sy-item-main">
                        <input type="hidden" id="item_edit_id">
                        
                        <div class="sy-form-group">
                            <label>Categoria</label>
                            <select id="item_edit_cat" style="width:100%;"></select>
                        </div>

                        <div class="sy-form-group">
                            <label>Nome Trattamento</label>
                            <input type="text" id="item_edit_name" style="width:100%;">
                        </div>

                        <div class="sy-form-group">
                            <label>Descrizione Breve</label>
                            <textarea id="item_edit_desc" style="width:100%;" rows="2"></textarea>
                        </div>
                        
                        <div class="sy-form-grid" style="margin-top: 20px;">
                            <div class="sy-form-group">
                                <label>Durata (es. 80 min.)</label>
                                <input type="text" id="item_edit_duration">
                            </div>
                            <div class="sy-form-group">
                                <label>Stato</label>
                                <div style="display:flex; gap:15px; margin-top:5px;">
                                    <label class="sy-toggle">
                                        <input type="checkbox" id="item_edit_visible">
                                        <span class="sy-slider"></span>
                                        <span class="sy-toggle-label">Visibile</span>
                                    </label>
                                    <label class="sy-toggle">
                                        <input type="checkbox" id="item_edit_featured">
                                        <span class="sy-slider"></span>
                                        <span class="sy-toggle-label">In evidenza</span>
                                    </label>
                                </div>
                            </div>
                        </div>
                        
                        <hr style="margin:20px 0; border:none; border-top:1px solid #ddd;">
                        
                        <!-- Price Generator UI -->
                        <h4>Generatore Prezzo</h4>
                        <div class="sy-price-generator">
                            <div class="sy-form-group">
                                <label>Tipo di Prezzo</label>
                                <select id="item_edit_price_type" onchange="syUpdatePriceFields()">
                                    <option value="fixed">Fisso (es. CHF 100.00)</option>
                                    <option value="from">Da (es. da CHF 100.00)</option>
                                    <option value="range">Range (es. da CHF 100.00 a 200.00)</option>
                                    <option value="custom">Testo Libero</option>
                                </select>
                            </div>
                            
                            <div class="sy-form-grid" id="sy-price-inputs" style="margin-top:10px;">
                                <!-- Populated dynamically based on type -->
                            </div>
                            
                            <div class="sy-form-group" style="margin-top:15px;">
                                <label>Etichetta Prezzo Finale (Generata automaticamente)</label>
                                <input type="text" id="item_edit_price_label" style="width:100%; font-weight:bold; color:#198754;">
                            </div>
                        </div>

                    </div>
                    
                    <!-- Right Column: Variants -->
                    <div class="sy-item-sidebar">
                        <h4>Anteprima Home</h4>
                        <div class="sy-preview-card" id="sy-preview-box">
                            <h5 id="sy-prev-title">Nome Trattamento</h5>
                            <p id="sy-prev-desc">Descrizione breve del trattamento che compare nella lista.</p>
                            <div class="sy-prev-meta">
                                <span id="sy-prev-dur" class="sy-prev-badge">[80 min.]</span>
                                <span id="sy-prev-price" class="sy-prev-price">CHF 0.00</span>
                            </div>
                        </div>

                        <hr style="margin:20px 0; border:none; border-top:1px solid #ddd;">

                        <h4>Varianti / Opzioni Prezzo</h4>
                        <p class="sy-help">Usate per opzioni come (Viso + collo) nello SMAS-Lifting.</p>
                        
                        <div id="sy-variants-container" style="margin-top:15px; margin-bottom:15px;">
                            <!-- Variants injected here -->
                        </div>
                        <button type="button" class="sy-btn sy-btn-outline" onclick="syAddVariant()">+ Aggiungi variante</button>
                    </div>
                </div>

            </div>
            <div class="sy-modal-footer">
                <button type="button" class="sy-btn" onclick="syCloseModal('sy-item-modal')">Annulla</button>
                <button type="button" class="sy-btn sy-btn-primary" onclick="sySaveItem()">Salva Trattamento</button>
            </div>
        </div>
    </div>

    <?php synergy_price_list_admin_scripts(); ?>

    <?php
}

function synergy_price_list_admin_styles() {
    ?>
    <style>
        /* Admin variables */
        :root {
            --sy-main: #1f1f1f;
            --sy-accent: #c7ad7a;
            --sy-accent-hover: #b49863;
            --sy-border: #e5ded2;
            --sy-bg: #f7f4ef;
            --sy-text: #202020;
            --sy-muted: #6f6a63;
            --sy-success: #198754;
            --sy-danger: #d93b3b;
        }

        .sy-admin-wrap { max-width: 1200px; margin: 20px 20px 20px 0; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif; color: var(--sy-text); }
        .sy-admin-wrap * { box-sizing: border-box; }
        
        /* Header */
        .sy-header { display: flex; justify-content: space-between; align-items: flex-end; margin-bottom: 20px; padding-bottom: 20px; border-bottom: 1px solid var(--sy-border); }
        .sy-header h1 { font-size: 28px; margin: 0 0 5px 0; color: var(--sy-main); font-weight: 600; }
        .sy-header p { margin: 0; color: var(--sy-muted); font-size: 14px; }
        .sy-header-actions { display: flex; gap: 10px; }

        /* Buttons */
        .sy-btn { display: inline-flex; align-items: center; justify-content: center; padding: 8px 16px; font-size: 14px; font-weight: 500; border-radius: 6px; cursor: pointer; transition: all 0.2s; border: 1px solid transparent; text-decoration: none; }
        .sy-btn-primary { background: var(--sy-accent); color: #fff; }
        .sy-btn-primary:hover { background: var(--sy-accent-hover); color: #fff; }
        .sy-btn-secondary { background: #fff; border-color: var(--sy-accent); color: var(--sy-accent); }
        .sy-btn-secondary:hover { background: var(--sy-bg); color: var(--sy-accent); }
        .sy-btn-outline { background: #fff; border-color: #ccc; color: var(--sy-text); }
        .sy-btn-outline:hover { border-color: #999; }
        .sy-btn-danger { background: #fff; border-color: var(--sy-danger); color: var(--sy-danger); }
        .sy-btn-danger:hover { background: var(--sy-danger); color: #fff; }
        .sy-btn-small { padding: 4px 8px; font-size: 12px; }
        .sy-btn-icon { width: 28px; height: 28px; padding: 0; display: inline-flex; justify-content: center; align-items: center; font-weight:bold; }

        /* Stats */
        .sy-stats { display: flex; gap: 20px; margin-bottom: 30px; }
        .sy-stat-box { background: #fff; border: 1px solid var(--sy-border); border-radius: 8px; padding: 15px 20px; flex: 1; display: flex; flex-direction: column; box-shadow: 0 2px 4px rgba(0,0,0,0.02); }
        .sy-stat-label { font-size: 13px; color: var(--sy-muted); text-transform: uppercase; letter-spacing: 0.5px; }
        .sy-stat-val { font-size: 24px; font-weight: 600; color: var(--sy-main); margin-top: 5px; }

        /* Layout */
        .sy-layout { display: flex; flex-direction: column; gap: 30px; }
        
        /* Cards */
        .sy-card { background: #fff; border: 1px solid var(--sy-border); border-radius: 10px; overflow: hidden; box-shadow: 0 2px 8px rgba(0,0,0,0.02); }
        .sy-card-header { padding: 15px 20px; background: #faf9f7; border-bottom: 1px solid var(--sy-border); display: flex; justify-content: space-between; align-items: center; }
        .sy-card-header h3 { margin: 0; font-size: 16px; font-weight: 600; }
        .sy-card-body { padding: 20px; }

        /* Forms */
        .sy-form-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
        .sy-col-full { grid-column: 1 / -1; }
        .sy-form-group { display: flex; flex-direction: column; gap: 5px; }
        .sy-form-group label { font-weight: 500; color: var(--sy-main); font-size: 13px; }
        .sy-form-group input[type="text"], .sy-form-group input[type="number"], .sy-form-group textarea, .sy-form-group select { border: 1px solid #ccc; border-radius: 4px; padding: 8px 10px; font-size: 14px; box-shadow: none; max-width: 100%; transition: border-color 0.2s; }
        .sy-form-group input:focus, .sy-form-group textarea:focus { border-color: var(--sy-accent); outline: none; box-shadow: 0 0 0 1px var(--sy-accent); }
        .sy-help { font-size: 12px; color: var(--sy-muted); }

        /* Custom Toggle Switch */
        .sy-toggle { position: relative; display: inline-flex; align-items: center; cursor: pointer; gap: 10px; }
        .sy-toggle input { opacity: 0; width: 0; height: 0; position: absolute; }
        .sy-slider { position: relative; width: 36px; height: 20px; background-color: #ccc; border-radius: 20px; transition: .4s; }
        .sy-slider:before { position: absolute; content: ""; height: 14px; width: 14px; left: 3px; bottom: 3px; background-color: white; border-radius: 50%; transition: .4s; }
        .sy-toggle input:checked + .sy-slider { background-color: var(--sy-success); }
        .sy-toggle input:checked + .sy-slider:before { transform: translateX(16px); }
        .sy-toggle-label { font-size: 13px; font-weight: 500; }

        /* Categories List */
        .sy-categories-header { display: flex; justify-content: space-between; align-items: center; margin-top: 10px; }
        .sy-categories-list { display: flex; flex-direction: column; gap: 15px; margin-top: 15px; }
        
        .sy-cat-box { background: #fff; border: 1px solid var(--sy-border); border-radius: 8px; overflow: hidden; box-shadow: 0 2px 4px rgba(0,0,0,0.02); }
        .sy-cat-header { padding: 15px 20px; display: flex; justify-content: space-between; align-items: center; background: #faf9f7; cursor: pointer; user-select: none; }
        .sy-cat-header:hover { background: #f2f0eb; }
        .sy-cat-title { font-size: 16px; font-weight: 600; margin: 0; display:flex; align-items:center; gap:10px; }
        .sy-cat-meta { font-size: 13px; color: var(--sy-muted); display:flex; align-items:center; gap:15px; }
        .sy-cat-actions { display: flex; gap: 8px; align-items:center; }
        .sy-cat-body { padding: 20px; border-top: 1px solid var(--sy-border); display: none; }
        .sy-cat-box.open .sy-cat-body { display: block; }

        .sy-badge { padding: 3px 8px; border-radius: 12px; font-size: 11px; font-weight: 600; text-transform: uppercase; }
        .sy-badge-visible { background: #e6f4ea; color: #1e8e3e; }
        .sy-badge-hidden { background: #fce8e6; color: #d93025; }
        .sy-badge-featured { background: #fef7e0; color: #b08a00; border: 1px solid #f9eba0; }

        /* Items List */
        .sy-item-list { display: flex; flex-direction: column; gap: 10px; margin-top: 15px; }
        .sy-item-row { display: flex; justify-content: space-between; align-items: center; padding: 12px 15px; border: 1px solid #e0e0e0; border-radius: 6px; background: #fff; transition: background 0.2s; }
        .sy-item-row:hover { background: #f9f9f9; border-color: #ccc; }
        .sy-item-row.is-hidden { opacity: 0.6; background: #f5f5f5; }
        .sy-item-info { flex: 1; }
        .sy-item-name { font-weight: 600; font-size: 14px; margin-bottom: 4px; display:flex; align-items:center; gap:8px;}
        .sy-item-details { font-size: 12px; color: var(--sy-muted); display: flex; gap: 10px; align-items: center; }
        .sy-item-actions { display: flex; gap: 5px; }

        /* Modal */
        .sy-modal { display: none; position: fixed; z-index: 99999; left: 0; top: 0; width: 100%; height: 100%; overflow: auto; background-color: rgba(0,0,0,0.5); backdrop-filter: blur(4px); }
        .sy-modal-content { background-color: #fff; margin: 5% auto; border-radius: 10px; width: 90%; max-width: 600px; box-shadow: 0 15px 30px rgba(0,0,0,0.2); animation: sy-slide-down 0.3s ease-out; display:flex; flex-direction:column; max-height:90vh; }
        .sy-modal-large .sy-modal-content { max-width: 900px; }
        @keyframes sy-slide-down { from { transform: translateY(-30px); opacity: 0; } to { transform: translateY(0); opacity: 1; } }
        .sy-modal-header { padding: 20px; border-bottom: 1px solid var(--sy-border); display: flex; justify-content: space-between; align-items: center; }
        .sy-modal-header h3 { margin: 0; font-size: 18px; }
        .sy-close { color: #aaa; font-size: 28px; font-weight: bold; cursor: pointer; line-height: 1; }
        .sy-close:hover { color: #333; }
        .sy-modal-body { padding: 20px; overflow-y: auto; flex: 1; }
        .sy-modal-footer { padding: 20px; border-top: 1px solid var(--sy-border); display: flex; justify-content: flex-end; gap: 10px; background: #faf9f7; border-radius: 0 0 10px 10px; }

        /* Modale Layout */
        .sy-item-layout { display: flex; gap: 30px; }
        .sy-item-main { flex: 1; min-width:0; }
        .sy-item-sidebar { width: 300px; flex-shrink: 0; background: #fdfdfc; padding: 15px; border-radius: 8px; border: 1px solid var(--sy-border); }

        /* Preview Card */
        .sy-preview-card { background: #fff; border: 1px solid var(--sy-accent); border-radius: 8px; padding: 15px; box-shadow: 0 4px 10px rgba(199, 173, 122, 0.1); }
        .sy-preview-card h5 { font-family: "Cormorant Garamond", serif; font-size: 18px; margin: 0 0 5px 0; color: var(--sy-main); }
        .sy-preview-card p { font-size: 12px; color: var(--sy-muted); margin: 0 0 10px 0; line-height: 1.4; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; }
        .sy-prev-meta { display: flex; justify-content: space-between; align-items: center; }
        .sy-prev-badge { background: #f5f5f5; padding: 4px 8px; border-radius: 12px; font-size: 11px; }
        .sy-prev-price { font-family: "Cormorant Garamond", serif; font-size: 16px; font-weight: bold; }

        /* Variants UI */
        .sy-var-row { display: grid; grid-template-columns: 2fr 1fr 1.5fr auto; gap: 10px; margin-bottom: 10px; align-items: center; padding:10px; background:#fff; border:1px solid #ddd; border-radius:6px; }
        .sy-var-row input { width: 100%; font-size: 12px; padding: 6px; }

        /* Utils */
        .sy-hidden { display: none !important; }
        .sy-json-editor { width: 100%; height: 300px; font-family: monospace; font-size: 12px; padding: 10px; background: #2d2d2d; color: #ccc; border-radius: 6px; border: none; }
        
        /* Mobile */
        @media (max-width: 782px) {
            .sy-form-grid { grid-template-columns: 1fr; }
            .sy-item-layout { flex-direction: column; }
            .sy-item-sidebar { width: 100%; }
        }
    </style>
    <?php
}

function synergy_price_list_admin_scripts() {
    $saved_data = get_option('synergy_price_list_data');
    if (empty($saved_data)) {
        $saved_data = synergy_get_default_price_list_data();
    }
    ?>
    <script>
    // Global State
    let synergyState = {
        settings: {},
        categories: [],
        items: []
    };

    document.addEventListener('DOMContentLoaded', function() {
        // Init data from hidden JSON textarea
        const textarea = document.getElementById('synergy_price_list_data_json');
        try {
            synergyState = <?php echo wp_json_encode($saved_data); ?>;
            if (typeof synergyState !== 'object' || synergyState === null) {
                throw new Error("Invalid JSON from PHP");
            }
        } catch(e) {
            console.error('JSON errato', e);
            alert('Errore nel caricamento del listino: ' + e.message);
            synergyState = {};
        }
        
        // Fallback se mancano chiavi
        if (!synergyState) synergyState = {};
        if (!synergyState.settings) synergyState.settings = {};
        if (!synergyState.categories) synergyState.categories = [];
        if (!synergyState.items) synergyState.items = [];

        // Popola Form Impostazioni
        document.getElementById('set_enabled').checked = synergyState.settings.enabled;
        document.getElementById('set_eyebrow').value = synergyState.settings.eyebrow || '';
        document.getElementById('set_title').value = synergyState.settings.title || '';
        document.getElementById('set_subtitle').value = synergyState.settings.subtitle || '';
        document.getElementById('set_note').value = synergyState.settings.note || '';
        document.getElementById('set_cta_label').value = synergyState.settings.cta_label || '';
        document.getElementById('set_cta_url').value = synergyState.settings.cta_url || '';
        document.getElementById('set_max_items').value = synergyState.settings.max_items || 8;
        document.getElementById('set_show_featured').checked = synergyState.settings.show_featured_first;

        // Render UI
        syRenderApp();
    });

    // ==========================================
    // RENDER FUNCTIONS
    // ==========================================

    function syRenderApp() {
        syRenderStats();
        syRenderCategories();
        sySyncToJSON();
    }

    function syRenderStats() {
        const activeCats = synergyState.categories.filter(c => c.visible).length;
        const activeItems = synergyState.items.filter(i => i.visible).length;
        
        document.getElementById('stat-cats').innerText = activeCats;
        document.getElementById('stat-items').innerText = activeItems;

        // Calculate price range
        let minPrice = Infinity;
        let maxPrice = 0;
        
        synergyState.items.forEach(item => {
            if(!item.visible) return;
            
            // Estrazione grossolana di numeri dalla stringa price_label
            let prices = item.price_label.match(/\d+(\.\d+)?/g);
            if (prices) {
                prices.forEach(p => {
                    let num = parseFloat(p);
                    if (num > 0) {
                        if (num < minPrice) minPrice = num;
                        if (num > maxPrice) maxPrice = num;
                    }
                });
            }
            // Check varianti
            if (item.variants && item.variants.length > 0) {
                item.variants.forEach(v => {
                    if(!v.visible) return;
                    let vPrices = v.price_label.match(/\d+(\.\d+)?/g);
                    if (vPrices) {
                        vPrices.forEach(p => {
                            let num = parseFloat(p);
                            if (num > 0) {
                                if (num < minPrice) minPrice = num;
                                if (num > maxPrice) maxPrice = num;
                            }
                        });
                    }
                });
            }
        });

        const statPriceEl = document.getElementById('stat-price');
        if (minPrice !== Infinity && maxPrice !== 0) {
            if (minPrice === maxPrice) {
                statPriceEl.innerText = `CHF ${minPrice.toFixed(2)}`;
            } else {
                statPriceEl.innerText = `CHF ${minPrice.toFixed(2)} – ${maxPrice.toFixed(2)}`;
            }
        } else {
            statPriceEl.innerText = '-';
        }
    }

    function syRenderCategories() {
        const container = document.getElementById('sy-categories-container');
        container.innerHTML = '';
        
        // Ordina categorie
        synergyState.categories.sort((a,b) => (a.order || 0) - (b.order || 0));

        synergyState.categories.forEach((cat, index) => {
            const catItems = synergyState.items.filter(i => i.category_id === cat.id);
            catItems.sort((a,b) => (a.order || 0) - (b.order || 0));
            
            const badgeVisible = cat.visible ? `<span class="sy-badge sy-badge-visible">Visibile</span>` : `<span class="sy-badge sy-badge-hidden">Nascosta</span>`;
            
            const catHtml = `
            <div class="sy-cat-box" id="cat-box-${cat.id}">
                <div class="sy-cat-header" onclick="this.parentElement.classList.toggle('open')">
                    <h3 class="sy-cat-title">
                        <span style="color:#aaa;">#${index+1}</span> ${escapeHtml(cat.title)} 
                    </h3>
                    <div class="sy-cat-meta">
                        <span>${catItems.length} trattamenti</span>
                        ${badgeVisible}
                        <span>&#9660;</span>
                    </div>
                </div>
                <div class="sy-cat-body">
                    <div style="display:flex; justify-content:space-between; margin-bottom:15px;">
                        <p style="margin:0; color:#666;">${escapeHtml(cat.description || 'Nessuna descrizione.')}</p>
                        <div class="sy-cat-actions">
                            <button type="button" class="sy-btn sy-btn-small sy-btn-icon" onclick="syMoveCategory('${cat.id}', -1)" title="Su">&uarr;</button>
                            <button type="button" class="sy-btn sy-btn-small sy-btn-icon" onclick="syMoveCategory('${cat.id}', 1)" title="Giù">&darr;</button>
                            <button type="button" class="sy-btn sy-btn-small sy-btn-outline" onclick="syOpenCategoryModal('${cat.id}')">Modifica Categoria</button>
                            <button type="button" class="sy-btn sy-btn-small sy-btn-danger" onclick="syDeleteCategory('${cat.id}')">Elimina</button>
                        </div>
                    </div>
                    
                    <div class="sy-item-list" id="list-${cat.id}">
                        ${catItems.map((item, iIndex) => renderItemRow(item, iIndex)).join('')}
                    </div>
                    
                    <button type="button" class="sy-btn sy-btn-outline" style="margin-top:15px; width:100%; border-style:dashed;" onclick="syOpenItemModal(null, '${cat.id}')">
                        + Aggiungi Trattamento
                    </button>
                </div>
            </div>
            `;
            container.insertAdjacentHTML('beforeend', catHtml);
        });
    }

    function renderItemRow(item, index) {
        const hiddenClass = item.visible ? '' : 'is-hidden';
        const badgeVisible = item.visible ? '' : `<span class="sy-badge sy-badge-hidden">Nascosto</span>`;
        const badgeFeat = item.featured ? `<span class="sy-badge sy-badge-featured">Evidenza</span>` : '';
        const variantCount = item.variants ? item.variants.length : 0;
        const variantMeta = variantCount > 0 ? `<span title="Varianti">&#9863; ${variantCount}</span>` : '';
        
        return `
        <div class="sy-item-row ${hiddenClass}">
            <div class="sy-item-info">
                <div class="sy-item-name">
                    ${escapeHtml(item.name)}
                    ${badgeFeat}
                    ${badgeVisible}
                </div>
                <div class="sy-item-details">
                    <span><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="vertical-align:middle;margin-top:-2px;"><circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 16 14"></polyline></svg> ${escapeHtml(item.duration || '-')}</span>
                    <span><strong>${escapeHtml(item.price_label)}</strong></span>
                    ${variantMeta}
                </div>
            </div>
            <div class="sy-item-actions">
                <button type="button" class="sy-btn sy-btn-small sy-btn-icon" onclick="syMoveItem('${item.id}', -1)" title="Su">&uarr;</button>
                <button type="button" class="sy-btn sy-btn-small sy-btn-icon" onclick="syMoveItem('${item.id}', 1)" title="Giù">&darr;</button>
                <button type="button" class="sy-btn sy-btn-small sy-btn-outline" onclick="syToggleItemVisibility('${item.id}')">${item.visible ? 'Nascondi' : 'Mostra'}</button>
                <button type="button" class="sy-btn sy-btn-small sy-btn-outline" onclick="syDuplicateItem('${item.id}')" title="Duplica">Copia</button>
                <button type="button" class="sy-btn sy-btn-small sy-btn-primary" onclick="syOpenItemModal('${item.id}')">Modifica</button>
                <button type="button" class="sy-btn sy-btn-small sy-btn-danger sy-btn-icon" onclick="syDeleteItem('${item.id}')" title="Elimina">&times;</button>
            </div>
        </div>
        `;
    }

    // ==========================================
    // MODALS & FORMS
    // ==========================================

    function syCloseModal(id) {
        document.getElementById(id).style.display = 'none';
    }

    // --- CATEGORY ---
    function syOpenCategoryModal(catId = null) {
        const modal = document.getElementById('sy-cat-modal');
        const title = document.getElementById('sy-cat-modal-title');
        
        if (catId) {
            const cat = synergyState.categories.find(c => c.id === catId);
            if(cat) {
                title.innerText = 'Modifica Categoria';
                document.getElementById('cat_edit_id').value = cat.id;
                document.getElementById('cat_edit_title').value = cat.title;
                document.getElementById('cat_edit_short_title').value = cat.short_title || '';
                document.getElementById('cat_edit_desc').value = cat.description;
                document.getElementById('cat_edit_visible').checked = cat.visible;
            }
        } else {
            title.innerText = 'Aggiungi Categoria';
            document.getElementById('cat_edit_id').value = 'new';
            document.getElementById('cat_edit_title').value = '';
            document.getElementById('cat_edit_short_title').value = '';
            document.getElementById('cat_edit_desc').value = '';
            document.getElementById('cat_edit_visible').checked = true;
        }
        modal.style.display = 'block';
    }

    function sySaveCategory() {
        const id = document.getElementById('cat_edit_id').value;
        const title = document.getElementById('cat_edit_title').value.trim();
        const short_title = document.getElementById('cat_edit_short_title').value.trim();
        const desc = document.getElementById('cat_edit_desc').value;
        const visible = document.getElementById('cat_edit_visible').checked;
        
        if(!title) { alert('Il titolo della categoria è obbligatorio.'); return; }
        
        if (id === 'new') {
            const newId = 'cat-' + Date.now();
            const order = synergyState.categories.length > 0 ? Math.max(...synergyState.categories.map(c => c.order || 0)) + 1 : 1;
            synergyState.categories.push({
                id: newId, title: title, short_title: short_title, description: desc, visible: visible, order: order
            });
        } else {
            const cat = synergyState.categories.find(c => c.id === id);
            if(cat) {
                cat.title = title;
                cat.short_title = short_title;
                cat.description = desc;
                cat.visible = visible;
            }
        }
        
        syCloseModal('sy-cat-modal');
        syRenderApp();
    }

    function syDeleteCategory(id) {
        const catItems = synergyState.items.filter(i => i.category_id === id);
        if (catItems.length > 0) {
            if(!confirm(`ATTENZIONE: Questa categoria contiene ${catItems.length} trattamenti. Eliminandola, verranno eliminati anche tutti i trattamenti al suo interno. Procedere?`)) {
                return;
            }
        } else {
            if(!confirm('Sei sicuro di voler eliminare questa categoria?')) return;
        }
        
        synergyState.categories = synergyState.categories.filter(c => c.id !== id);
        synergyState.items = synergyState.items.filter(i => i.category_id !== id);
        syRenderApp();
    }

    function syMoveCategory(id, direction) {
        const idx = synergyState.categories.findIndex(c => c.id === id);
        if (idx < 0) return;
        if (direction === -1 && idx > 0) {
            const temp = synergyState.categories[idx].order;
            synergyState.categories[idx].order = synergyState.categories[idx-1].order;
            synergyState.categories[idx-1].order = temp;
        } else if (direction === 1 && idx < synergyState.categories.length - 1) {
            const temp = synergyState.categories[idx].order;
            synergyState.categories[idx].order = synergyState.categories[idx+1].order;
            synergyState.categories[idx+1].order = temp;
        }
        syRenderApp();
    }


    // --- ITEM ---
    function syOpenItemModal(itemId = null, defaultCat = null) {
        const modal = document.getElementById('sy-item-modal');
        const title = document.getElementById('sy-item-modal-title');
        const select = document.getElementById('item_edit_cat');
        
        // Popola select categorie
        select.innerHTML = synergyState.categories.map(c => `<option value="${c.id}">${escapeHtml(c.title)}</option>`).join('');
        
        document.getElementById('sy-variants-container').innerHTML = ''; // reset variants
        
        if (itemId) {
            const item = synergyState.items.find(i => i.id === itemId);
            if(item) {
                title.innerText = 'Modifica Trattamento';
                document.getElementById('item_edit_id').value = item.id;
                select.value = item.category_id;
                document.getElementById('item_edit_name').value = item.name;
                document.getElementById('item_edit_desc').value = item.description || '';
                document.getElementById('item_edit_duration').value = item.duration || '';
                document.getElementById('item_edit_visible').checked = item.visible;
                document.getElementById('item_edit_featured').checked = item.featured || false;
                document.getElementById('item_edit_price_label').value = item.price_label;
                
                let pType = item.price_type || 'custom';
                document.getElementById('item_edit_price_type').value = pType;
                syUpdatePriceFields(true);
                
                if (pType === 'fixed') {
                    if(document.getElementById('price_in_1')) document.getElementById('price_in_1').value = item.price_fixed || '';
                } else if (pType === 'from') {
                    if(document.getElementById('price_in_1')) document.getElementById('price_in_1').value = item.price_min || '';
                } else if (pType === 'range') {
                    if(document.getElementById('price_in_1')) document.getElementById('price_in_1').value = item.price_min || '';
                    if(document.getElementById('price_in_2')) document.getElementById('price_in_2').value = item.price_max || '';
                } else {
                    if(document.getElementById('price_in_custom')) document.getElementById('price_in_custom').value = item.price_label || '';
                }
                
                // Popola varianti se ci sono
                if (item.variants && item.variants.length > 0) {
                    item.variants.forEach(v => syAddVariantRow(v));
                }
            }
        } else {
            title.innerText = 'Aggiungi Trattamento';
            document.getElementById('item_edit_id').value = 'new';
            if(defaultCat) select.value = defaultCat;
            document.getElementById('item_edit_name').value = '';
            document.getElementById('item_edit_desc').value = '';
            document.getElementById('item_edit_duration').value = '';
            document.getElementById('item_edit_visible').checked = true;
            document.getElementById('item_edit_featured').checked = false;
            document.getElementById('item_edit_price_label').value = 'CHF 0.00';
            document.getElementById('item_edit_price_type').value = 'fixed';
            syUpdatePriceFields();
        }
        
        syUpdatePreview();
        modal.style.display = 'flex';
        
        // Listeners for live preview
        document.getElementById('item_edit_name').addEventListener('input', syUpdatePreview);
        document.getElementById('item_edit_desc').addEventListener('input', syUpdatePreview);
        document.getElementById('item_edit_duration').addEventListener('input', syUpdatePreview);
        document.getElementById('item_edit_price_label').addEventListener('input', syUpdatePreview);
    }

    function syUpdatePriceFields(skipLabelGeneration = false) {
        const type = document.getElementById('item_edit_price_type').value;
        const container = document.getElementById('sy-price-inputs');
        let html = '';
        
        if (type === 'fixed') {
            html = `<div class="sy-form-group"><label>Prezzo (es. 205)</label><input type="number" id="price_in_1" oninput="syGeneratePriceLabel()"></div>`;
        } else if (type === 'from') {
            html = `<div class="sy-form-group"><label>Prezzo Minimo (es. 115)</label><input type="number" id="price_in_1" oninput="syGeneratePriceLabel()"></div>`;
        } else if (type === 'range') {
            html = `
            <div class="sy-form-group"><label>Prezzo Minimo (es. 220)</label><input type="number" id="price_in_1" oninput="syGeneratePriceLabel()"></div>
            <div class="sy-form-group"><label>Prezzo Massimo (es. 550)</label><input type="number" id="price_in_2" oninput="syGeneratePriceLabel()"></div>
            `;
        } else {
            html = `<div class="sy-form-group sy-col-full"><label>Testo Libero</label><input type="text" id="price_in_custom" oninput="syGeneratePriceLabel()"></div>`;
        }
        
        container.innerHTML = html;
        if(!skipLabelGeneration) syGeneratePriceLabel();
    }

    window.syGeneratePriceLabel = function() {
        const type = document.getElementById('item_edit_price_type').value;
        const target = document.getElementById('item_edit_price_label');
        
        if (type === 'fixed') {
            const v = document.getElementById('price_in_1').value;
            target.value = v ? `CHF ${parseFloat(v).toFixed(2)}` : 'CHF 0.00';
        } else if (type === 'from') {
            const v = document.getElementById('price_in_1').value;
            target.value = v ? `da CHF ${parseFloat(v).toFixed(2)}` : 'da CHF 0.00';
        } else if (type === 'range') {
            const v1 = document.getElementById('price_in_1').value;
            const v2 = document.getElementById('price_in_2').value;
            let str = 'da CHF ';
            str += v1 ? parseFloat(v1).toFixed(2) : '0.00';
            str += ' a CHF ';
            str += v2 ? parseFloat(v2).toFixed(2) : '0.00';
            target.value = str;
        } else {
            const v = document.getElementById('price_in_custom').value;
            target.value = v;
        }
        syUpdatePreview();
    };

    function syUpdatePreview() {
        document.getElementById('sy-prev-title').innerText = document.getElementById('item_edit_name').value || 'Nome Trattamento';
        document.getElementById('sy-prev-desc').innerText = document.getElementById('item_edit_desc').value || 'Descrizione breve...';
        const dur = document.getElementById('item_edit_duration').value;
        const durEl = document.getElementById('sy-prev-dur');
        if (dur) { durEl.innerText = dur; durEl.style.display = 'inline-block'; } else { durEl.style.display = 'none'; }
        document.getElementById('sy-prev-price').innerText = document.getElementById('item_edit_price_label').value || 'CHF 0.00';
    }

    // Varianti
    window.syAddVariant = function() {
        syAddVariantRow({id: 'var-'+Date.now(), name: '', duration: '', price_label: 'CHF 0.00', visible: true});
    };

    function syAddVariantRow(v) {
        const container = document.getElementById('sy-variants-container');
        const row = document.createElement('div');
        row.className = 'sy-var-row';
        row.innerHTML = `
            <input type="text" placeholder="Nome (es. Viso + collo)" value="${escapeHtml(v.name)}" class="var-name">
            <input type="text" placeholder="Durata" value="${escapeHtml(v.duration)}" class="var-dur">
            <input type="text" placeholder="Prezzo (es. CHF 320.00)" value="${escapeHtml(v.price_label)}" class="var-price">
            <button type="button" class="sy-btn sy-btn-danger sy-btn-icon" onclick="this.parentElement.remove()" title="Rimuovi">&times;</button>
        `;
        container.appendChild(row);
    }

    function sySaveItem() {
        const id = document.getElementById('item_edit_id').value;
        const catId = document.getElementById('item_edit_cat').value;
        const name = document.getElementById('item_edit_name').value.trim();
        const desc = document.getElementById('item_edit_desc').value;
        const dur = document.getElementById('item_edit_duration').value;
        const visible = document.getElementById('item_edit_visible').checked;
        const featured = document.getElementById('item_edit_featured').checked;
        const priceLabel = document.getElementById('item_edit_price_label').value.trim();
        const priceType = document.getElementById('item_edit_price_type').value;
        
        let pFixed = '';
        let pMin = '';
        let pMax = '';
        
        if (priceType === 'fixed') {
            pFixed = document.getElementById('price_in_1') ? document.getElementById('price_in_1').value : '';
        } else if (priceType === 'from') {
            pMin = document.getElementById('price_in_1') ? document.getElementById('price_in_1').value : '';
        } else if (priceType === 'range') {
            pMin = document.getElementById('price_in_1') ? document.getElementById('price_in_1').value : '';
            pMax = document.getElementById('price_in_2') ? document.getElementById('price_in_2').value : '';
        }
        
        if(!name) { alert('Il nome del trattamento è obbligatorio.'); return; }
        
        // Estrai Varianti
        const variants = [];
        const varRows = document.querySelectorAll('.sy-var-row');
        varRows.forEach((row, idx) => {
            const vName = row.querySelector('.var-name').value.trim();
            if(vName) {
                // Selezioniamo anche il prezzo numerico per la variante estraendolo approssimativamente se è fisso, ma per ora il pdf ha prezzi fissi
                let vPriceLabel = row.querySelector('.var-price').value.trim() || 'CHF 0.00';
                let vFixed = vPriceLabel.replace(/[^0-9.]/g, '');
                
                variants.push({
                    id: 'var-' + Date.now() + '-' + idx,
                    name: vName,
                    duration: row.querySelector('.var-dur').value.trim(),
                    price_label: vPriceLabel,
                    price_fixed: vFixed,
                    order: idx + 1,
                    visible: true
                });
            }
        });

        if (id === 'new') {
            const catItems = synergyState.items.filter(i => i.category_id === catId);
            const order = catItems.length > 0 ? Math.max(...catItems.map(i => i.order || 0)) + 1 : 1;
            synergyState.items.push({
                id: 'item-' + Date.now(),
                category_id: catId,
                name: name,
                description: desc,
                duration: dur,
                price_type: priceType,
                price_fixed: pFixed,
                price_min: pMin,
                price_max: pMax,
                price_label: priceLabel || 'CHF 0.00',
                visible: visible,
                featured: featured,
                order: order,
                variants: variants
            });
        } else {
            const item = synergyState.items.find(i => i.id === id);
            if(item) {
                item.category_id = catId;
                item.name = name;
                item.description = desc;
                item.duration = dur;
                item.price_type = priceType;
                item.price_fixed = pFixed;
                item.price_min = pMin;
                item.price_max = pMax;
                item.price_label = priceLabel;
                item.visible = visible;
                item.featured = featured;
                item.variants = variants;
            }
        }
        
        syCloseModal('sy-item-modal');
        syRenderApp();
    }

    function syDeleteItem(id) {
        if(!confirm('Sei sicuro di voler eliminare questo trattamento? In alternativa puoi solo nasconderlo.')) return;
        synergyState.items = synergyState.items.filter(i => i.id !== id);
        syRenderApp();
    }
    
    function syToggleItemVisibility(id) {
        const item = synergyState.items.find(i => i.id === id);
        if(item) {
            item.visible = !item.visible;
            syRenderApp();
        }
    }
    
    function syDuplicateItem(id) {
        const item = synergyState.items.find(i => i.id === id);
        if(item) {
            const newItem = JSON.parse(JSON.stringify(item));
            newItem.id = 'item-' + Date.now();
            newItem.name = newItem.name + ' (Copia)';
            newItem.visible = false; // nascosto di default per sicurezza
            synergyState.items.push(newItem);
            syRenderApp();
        }
    }

    function syMoveItem(id, direction) {
        const item = synergyState.items.find(i => i.id === id);
        if(!item) return;
        
        const catItems = synergyState.items.filter(i => i.category_id === item.category_id);
        catItems.sort((a,b) => (a.order || 0) - (b.order || 0));
        
        const idx = catItems.findIndex(i => i.id === id);
        if (idx < 0) return;
        
        if (direction === -1 && idx > 0) {
            const temp = catItems[idx].order;
            catItems[idx].order = catItems[idx-1].order;
            catItems[idx-1].order = temp;
        } else if (direction === 1 && idx < catItems.length - 1) {
            const temp = catItems[idx].order;
            catItems[idx].order = catItems[idx+1].order;
            catItems[idx+1].order = temp;
        }
        syRenderApp();
    }


    // ==========================================
    // SYNC & SAVE
    // ==========================================

    function sySyncToJSON() {
        // Leggi impostazioni da input
        synergyState.settings.enabled = document.getElementById('set_enabled').checked;
        synergyState.settings.eyebrow = document.getElementById('set_eyebrow').value;
        synergyState.settings.title = document.getElementById('set_title').value;
        synergyState.settings.subtitle = document.getElementById('set_subtitle').value;
        synergyState.settings.note = document.getElementById('set_note').value;
        synergyState.settings.cta_label = document.getElementById('set_cta_label').value;
        synergyState.settings.cta_url = document.getElementById('set_cta_url').value;
        synergyState.settings.max_items = parseInt(document.getElementById('set_max_items').value) || 8;
        synergyState.settings.show_featured_first = document.getElementById('set_show_featured').checked;

        const textarea = document.getElementById('synergy_price_list_data_json');
        textarea.value = JSON.stringify(synergyState, null, 4);
    }

    window.sySaveForm = function() {
        sySyncToJSON();
        document.getElementById('sy_form_action').value = 'save';
        document.getElementById('sy-main-form').submit();
    };
    
    window.syForceUpdateFromJson = function() {
        if(!confirm('Questo sovrascriverà l\'interfaccia con i dati attualmente scritti nel box JSON tecnico. Sei sicuro?')) return;
        const textarea = document.getElementById('synergy_price_list_data_json');
        try {
            synergyState = JSON.parse(textarea.value);
            syRenderApp();
            alert('UI Aggiornata dal JSON.');
        } catch(e) {
            alert('Errore di sintassi nel JSON. Impossibile aggiornare la UI.');
        }
    };

    // Utilities
    function escapeHtml(unsafe) {
        if(!unsafe) return '';
        return (unsafe+'').replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#039;");
    }

    });
    </script>
    <?php
}
