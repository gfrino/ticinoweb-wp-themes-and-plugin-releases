<?php
/**
 * CMS Backend Section for Prodotti & Tecnologie
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Normalizza la categoria storica "Trattamento professionale" (singolare) nella
 * forma attuale "Trattamenti Professionali". La categoria e' la chiave con cui
 * gli elementi vengono raggruppati: un valore non allineato li farebbe sparire
 * dalla home senza alcun errore. Il filtro copre ogni lettura dell'opzione, cosi'
 * anche un backup ripristinato resta leggibile.
 */
add_filter('option_synergy_products_technologies_data', 'synergy_pt_normalizza_categorie');
function synergy_pt_normalizza_categorie($data) {
    if (!is_array($data) || empty($data['items']) || !is_array($data['items'])) {
        return $data;
    }
    $legacy = array('Trattamento professionale' => 'Trattamenti Professionali');
    foreach ($data['items'] as $i => $item) {
        if (isset($item['category'], $legacy[$item['category']])) {
            $data['items'][$i]['category'] = $legacy[$item['category']];
        }
    }
    return $data;
}

// 1. ADD SUBMENU PAGE
add_action('admin_menu', 'synergy_add_products_submenu', 20);
function synergy_add_products_submenu() {
    add_submenu_page(
        'ticinoweb-cms',
        'Prodotti & Tecnologie',
        'Prodotti & Tecnologie',
        'edit_pages',
        'ticinoweb-products-technologies',
        'synergy_render_products_page'
    );
}

// 2. PREPOPULATE DATA
add_action('admin_init', 'synergy_prepopulate_products_data');
function synergy_prepopulate_products_data() {
    $existing = get_option('synergy_products_technologies_data', null);
    
    // Only pre-populate if the option doesn't exist at all
    if ($existing === null) {
        synergy_do_prepopulate_products_data();
    }
}

function synergy_do_prepopulate_products_data() {
    $default_data = array(
        'section_title' => 'Prodotti e tecnologie professionali per la tua cura.',
        'section_description' => 'Nel centro selezioniamo prodotti cosmetici professionali e tecnologie estetiche avanzate per accompagnare ogni trattamento con qualità, precisione e attenzione alle esigenze della persona.',
        'items' => array(
            // GRUPPO 1: PRODOTTI PROFESSIONALI
            array('name' => 'Ericson Laboratoire', 'category' => 'Prodotti professionali', 'area' => 'Viso e corpo', 'description' => 'Linea cosmetica professionale utilizzata per trattamenti viso e corpo, con formulazioni dedicate alla cura estetica avanzata.', 'order' => 10, 'active' => 1),
            array('name' => 'Mesoestetic', 'category' => 'Prodotti professionali', 'area' => 'Viso e corpo', 'description' => 'Brand professionale specializzato in trattamenti cosmetici mirati, skincare e programmi estetici per la qualità della pelle.', 'order' => 20, 'active' => 1),
            array('name' => 'Swissestetic', 'category' => 'Prodotti professionali', 'area' => 'Viso e corpo', 'description' => 'Prodotti selezionati per supportare trattamenti estetici professionali e percorsi personalizzati di cura della pelle.', 'order' => 30, 'active' => 1),
            array('name' => 'Uniqa Pea Cosmetic', 'category' => 'Prodotti professionali', 'area' => 'Viso', 'description' => 'Cosmetici professionali dedicati alla cura del viso e al mantenimento quotidiano dei risultati.', 'order' => 40, 'active' => 1),
            array('name' => 'CNC Skincare', 'category' => 'Prodotti professionali', 'area' => 'Viso e mani', 'description' => 'Linea skincare professionale utilizzata per trattamenti specifici e routine di bellezza mirate.', 'order' => 50, 'active' => 1),
            array('name' => 'Gehwol', 'category' => 'Prodotti professionali', 'area' => 'Mani e piedi', 'description' => 'Prodotti professionali per la cura del piede, pedicure e trattamenti dedicati al benessere di mani e piedi.', 'order' => 60, 'active' => 1),
            array('name' => 'CND Creative', 'category' => 'Prodotti professionali', 'area' => 'Mani e smalti', 'description' => 'Brand professionale per manicure, smalti, trattamenti unghie e cura estetica delle mani.', 'order' => 70, 'active' => 1),
            array('name' => 'Mavex', 'category' => 'Prodotti professionali', 'area' => 'Viso, mani e piedi', 'description' => 'Prodotti cosmetici professionali per trattamenti viso, manicure, pedicure e cura specifica della pelle.', 'order' => 80, 'active' => 1),
            array('name' => 'Beautylines', 'category' => 'Prodotti professionali', 'area' => 'Ciglia, capelli e labbra', 'description' => 'Prodotti dedicati a ciglia, capelli, labbra e servizi beauty essentials.', 'order' => 90, 'active' => 1),

            // GRUPPO 2: TECNOLOGIE E MACCHINARI
            array('name' => 'Radiofrequenza CoaxMED', 'category' => 'Tecnologia estetica', 'area' => 'Viso e corpo', 'description' => 'Tecnologia professionale per trattamenti di ringiovanimento, rassodamento e miglioramento della qualità della pelle.', 'order' => 100, 'active' => 1),
            array('name' => 'RF SMAS-lifting X-PRO Technology', 'category' => 'Tecnologia estetica', 'area' => 'Viso e corpo', 'description' => 'Trattamento non chirurgico pensato per supportare effetto lifting, compattezza e tonicità dei tessuti.', 'order' => 110, 'active' => 1),
            array('name' => 'HIFU / SMAS', 'category' => 'Tecnologia estetica', 'area' => 'Viso e corpo', 'description' => 'Tecnologia focalizzata per trattamenti mirati di rassodamento e rimodellamento, senza approccio invasivo.', 'order' => 120, 'active' => 1),
            array('name' => 'Cold Plasma CNC', 'category' => 'Tecnologia estetica', 'area' => 'Pelle', 'description' => 'Tecnologia avanzata utilizzata per trattamenti mirati della pelle e supporto a percorsi estetici specifici.', 'order' => 130, 'active' => 1),
            array('name' => 'ELOS-IPL ArtMED', 'category' => 'Tecnologia estetica', 'area' => 'Viso', 'description' => 'Tecnologia utilizzata per trattamenti di fotoringiovanimento e miglioramento dell’aspetto della pelle.', 'order' => 140, 'active' => 1),
            array('name' => 'Laser diodo ArtMED', 'category' => 'Tecnologia estetica', 'area' => 'Viso', 'description' => 'Tecnologia laser indicata nel vecchio sito per trattamenti specifici come acne e inestetismi cutanei.', 'order' => 150, 'active' => 1),
            array('name' => 'Epilazione laser diodo', 'category' => 'Tecnologia estetica', 'area' => 'Viso e corpo', 'description' => 'Soluzione professionale per epilazione progressiva su viso e corpo, adatta anche a trattamenti maschili.', 'order' => 160, 'active' => 1),
            array('name' => 'Spazzola ultrasuono UNA', 'category' => 'Tecnologia estetica', 'area' => 'Viso', 'description' => 'Tecnologia per la pulizia delicata della pelle, utile per pori, sebo e preparazione ai trattamenti.', 'order' => 170, 'active' => 1),
            array('name' => 'Ultrasuono Ionoforesi UNA', 'category' => 'Tecnologia estetica', 'area' => 'Viso', 'description' => 'Sistema professionale per supportare nutrimento, idratazione e veicolazione di principi attivi.', 'order' => 180, 'active' => 1),
            array('name' => 'Elettrostimolazione UNA', 'category' => 'Tecnologia estetica', 'area' => 'Viso', 'description' => 'Tecnologia per la stimolazione dei muscoli del viso e il supporto a trattamenti tonificanti.', 'order' => 190, 'active' => 1),
            array('name' => 'OndaVacu Gym', 'category' => 'Tecnologia estetica', 'area' => 'Corpo', 'description' => 'Tecnologia dedicata a percorsi corpo, dimagrimento, detox e supporto ai trattamenti rimodellanti.', 'order' => 200, 'active' => 1),
            array('name' => 'Body Shaping Sculpt', 'category' => 'Tecnologia estetica', 'area' => 'Corpo', 'description' => 'Tecnologia orientata al rafforzamento muscolare, alla tonificazione e al supporto dei percorsi corpo.', 'order' => 210, 'active' => 1),
            array('name' => 'OndaWave', 'category' => 'Tecnologia estetica', 'area' => 'Corpo', 'description' => 'Tecnologia a onde di pressione acustica utilizzata nei percorsi per cellulite, compattezza e tono della pelle.', 'order' => 220, 'active' => 1),
            array('name' => 'Cavitazione ultrasonica', 'category' => 'Tecnologia estetica', 'area' => 'Corpo', 'description' => 'Tecnologia impiegata nei percorsi rimodellanti e nel trattamento degli inestetismi legati agli accumuli localizzati.', 'order' => 230, 'active' => 1),
            array('name' => 'Vacuum pulsante', 'category' => 'Tecnologia estetica', 'area' => 'Corpo', 'description' => 'Trattamento professionale per drenaggio, rimodellamento e supporto al benessere dei tessuti.', 'order' => 240, 'active' => 1),
            array('name' => 'Pressoterapia', 'category' => 'Tecnologia estetica', 'area' => 'Corpo', 'description' => 'Tecnologia indicata per favorire drenaggio, leggerezza e benessere delle gambe.', 'order' => 250, 'active' => 1),
            array('name' => 'Criolipolisi', 'category' => 'Tecnologia estetica', 'area' => 'Corpo', 'description' => 'Tecnologia dedicata al trattamento localizzato degli accumuli adiposi e ai percorsi corpo mirati.', 'order' => 260, 'active' => 1),
            array('name' => 'Laser diodo CoaxMED', 'category' => 'Tecnologia estetica', 'area' => 'Corpo', 'description' => 'Piattaforma professionale citata nel vecchio sito per trattamenti corpo e percorsi estetici avanzati.', 'order' => 270, 'active' => 1),

            // GRUPPO 3: TRATTAMENTI SPECIFICI
            array('name' => 'Green Peel Fresh Up - Dr. C. Schrammek', 'category' => 'Trattamenti Professionali', 'area' => 'Viso', 'description' => 'Trattamento professionale pensato per migliorare freschezza, luminosità e qualità della pelle.', 'order' => 280, 'active' => 1),
            array('name' => 'Global-Eyecon - Mesoestetic', 'category' => 'Trattamenti Professionali', 'area' => 'Contorno occhi', 'description' => 'Trattamento specifico per la zona occhi, dedicato a un’area delicata e particolarmente espressiva del viso.', 'order' => 290, 'active' => 1),
            array('name' => 'T-Shock 31 - Baldan', 'category' => 'Trattamenti Professionali', 'area' => 'Corpo', 'description' => 'Trattamento citato nel vecchio sito per modellamento, detossinazione e supporto ai percorsi corpo.', 'order' => 300, 'active' => 1),
            array('name' => 'Cellulit’Vib - Ericson', 'category' => 'Trattamenti Professionali', 'area' => 'Corpo', 'description' => 'Trattamento professionale orientato agli inestetismi della cellulite e al miglioramento della qualità cutanea.', 'order' => 310, 'active' => 1),
            array('name' => 'Slim & Lift - Ericson', 'category' => 'Trattamenti Professionali', 'area' => 'Corpo', 'description' => 'Trattamento dedicato alla silhouette, al tono e ai percorsi corpo personalizzati.', 'order' => 320, 'active' => 1),
            array('name' => 'Impacchi con fango - Janssen', 'category' => 'Trattamenti Professionali', 'area' => 'Corpo', 'description' => 'Trattamenti con fanghi professionali dedicati a snellimento, tonificazione e benessere della pelle.', 'order' => 330, 'active' => 1)
        )
    );

    update_option('synergy_products_technologies_data', $default_data);
}

// 3. HANDLE SAVE
add_action('admin_post_synergy_save_products', 'synergy_save_products_data');
function synergy_save_products_data() {
    if (!current_user_can('edit_pages')) {
        wp_die('Permessi insufficienti.');
    }
    
    check_admin_referer('synergy_save_products_nonce', 'synergy_save_products_nonce_field');
    
    $data = array(
        'section_title' => isset($_POST['section_title']) ? sanitize_text_field(wp_unslash($_POST['section_title'])) : '',
        'section_description' => isset($_POST['section_description']) ? sanitize_textarea_field(wp_unslash($_POST['section_description'])) : '',
        'items' => array()
    );

    if (isset($_POST['items']) && is_array($_POST['items'])) {
        foreach ($_POST['items'] as $item) {
            if (empty(trim($item['name']))) continue;

            // Handle the quick toggle 'active' vs 'inactive' gracefully
            $active = 0;
            if (isset($item['active']) && ($item['active'] == '1' || $item['active'] === 'on')) {
                $active = 1;
            }

            $data['items'][] = array(
                'name' => sanitize_text_field($item['name']),
                'category' => sanitize_text_field($item['category']),
                'area' => sanitize_text_field($item['area']),
                'description' => sanitize_textarea_field($item['description']),
                'order' => isset($item['order']) ? absint($item['order']) : 0,
                'active' => $active,
                'image_id' => isset($item['image_id']) ? absint($item['image_id']) : 0,
            );
        }
        
        // Sort by order
        usort($data['items'], function($a, $b) {
            return $a['order'] - $b['order'];
        });
    }

    update_option('synergy_products_technologies_data', $data);

    wp_safe_redirect(add_query_arg(
        array('page' => 'ticinoweb-products-technologies', 'updated' => 'true'),
        admin_url('admin.php')
    ));
    exit;
}

// RESTORE DEFAULT DATA
add_action('admin_post_synergy_restore_products', 'synergy_restore_products_data');
function synergy_restore_products_data() {
    if (!current_user_can('edit_pages')) {
        wp_die('Permessi insufficienti.');
    }
    check_admin_referer('synergy_restore_products_nonce', 'synergy_restore_products_nonce_field');
    
    synergy_do_prepopulate_products_data();
    
    wp_safe_redirect(add_query_arg(
        array('page' => 'ticinoweb-products-technologies', 'restored' => 'true'),
        admin_url('admin.php')
    ));
    exit;
}

// 4. RENDER PAGE
function synergy_render_products_page() {
    $data = get_option('synergy_products_technologies_data', array());
    $title = isset($data['section_title']) ? $data['section_title'] : '';
    $desc = isset($data['section_description']) ? $data['section_description'] : '';
    $items = isset($data['items']) && is_array($data['items']) ? $data['items'] : array();
    
    // Counts
    $count_all = count($items);
    $count_prod = 0;
    $count_tec = 0;
    $count_trat = 0;
    $count_active = 0;
    $count_inactive = 0;

    foreach ($items as $it) {
        if ($it['category'] === 'Prodotti professionali') $count_prod++;
        if ($it['category'] === 'Tecnologia estetica') $count_tec++;
        if ($it['category'] === 'Trattamenti Professionali') $count_trat++;
        if (!isset($it['active']) || $it['active']) $count_active++;
        else $count_inactive++;
    }

    wp_enqueue_script('jquery-ui-sortable');
    wp_enqueue_media();
    ?>
    <style>
        .pt-admin-wrap { max-width: 900px; margin-top: 20px; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif; }
        .pt-header-top { display: flex; justify-content: space-between; align-items: flex-end; margin-bottom: 20px; }
        .pt-filters-bar { background: #fff; padding: 15px 20px; border-radius: 8px; box-shadow: 0 1px 3px rgba(0,0,0,0.05); margin-bottom: 20px; display: flex; justify-content: space-between; align-items: center; border: 1px solid #ccd0d4; }
        .pt-filters { display: flex; gap: 10px; flex-wrap: wrap; }
        .pt-filter-btn { background: #f0f0f1; border: 1px solid #dcdcde; padding: 5px 12px; border-radius: 20px; cursor: pointer; font-size: 13px; color: #3c434a; transition: 0.2s; }
        .pt-filter-btn:hover { background: #e6e6e6; }
        .pt-filter-btn.active { background: #2271b1; color: #fff; border-color: #2271b1; }
        .pt-search-input { width: 100%; max-width: 250px; padding: 5px 10px; border-radius: 4px; border: 1px solid #8c8f94; }
        
        .pt-accordion-box { background: #fff; border: 1px solid #ccd0d4; border-radius: 4px; margin-bottom: 15px; box-shadow: 0 1px 2px rgba(0,0,0,0.03); }
        .pt-accordion-header { padding: 12px 15px; display: flex; align-items: center; justify-content: space-between; cursor: pointer; background: #fafafa; border-radius: 4px; }
        .pt-accordion-header:hover { background: #f0f0f1; }
        .pt-accordion-body { padding: 20px; border-top: 1px solid #ccd0d4; display: none; }
        
        /* Specifics for Items */
        .pt-item-card { position: relative; }
        .pt-item-drag { cursor: move; color: #8c8f94; padding-right: 15px; font-size: 18px; line-height: 1; }
        .pt-item-title { font-weight: 600; font-size: 14px; color: #1d2327; flex-grow: 1; }
        .pt-item-badge { font-size: 11px; text-transform: uppercase; background: #e0e0e0; color: #555; padding: 2px 6px; border-radius: 3px; margin-left: 10px; }
        .pt-item-badge.prod { background: #e3f2fd; color: #0d47a1; }
        .pt-item-badge.tec { background: #e8f5e9; color: #1b5e20; }
        .pt-item-badge.trat { background: #fff3e0; color: #e65100; }
        
        .pt-item-actions { display: flex; gap: 12px; align-items: center; }
        .pt-action-link { text-decoration: none; font-size: 13px; color: #2271b1; background: none; border: none; padding: 0; cursor: pointer; }
        .pt-action-link:hover { text-decoration: underline; }
        .pt-action-link.delete { color: #d63638; }
        
        /* Toggle Switch */
        .pt-toggle-switch { position: relative; display: inline-block; width: 34px; height: 20px; margin: 0; }
        .pt-toggle-switch input { opacity: 0; width: 0; height: 0; }
        .pt-slider { position: absolute; cursor: pointer; top: 0; left: 0; right: 0; bottom: 0; background-color: #ccc; transition: .4s; border-radius: 20px; }
        .pt-slider:before { position: absolute; content: ""; height: 14px; width: 14px; left: 3px; bottom: 3px; background-color: white; transition: .4s; border-radius: 50%; }
        input:checked + .pt-slider { background-color: #00a32a; }
        input:checked + .pt-slider:before { transform: translateX(14px); }
        
        /* Form adjustments */
        .pt-form-row { margin-bottom: 15px; display: flex; align-items: flex-start; gap: 15px; }
        .pt-form-label { width: 120px; font-weight: 600; padding-top: 5px; flex-shrink: 0; }
        .pt-form-input { flex-grow: 1; }
        .pt-form-input input[type="text"], .pt-form-input textarea, .pt-form-input select { width: 100%; max-width: 500px; }
        .pt-form-input textarea { height: 80px; }
    </style>

    <div class="wrap pt-admin-wrap">
        <div class="pt-header-top">
            <div>
                <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/images/logo-ticinoweb-2025.png'); ?>" alt="ticinoWEB" style="max-width: 130px; margin-bottom: 10px; display: block;">
                <h1 style="margin: 0;"><?php _e('Prodotti & Tecnologie', 'synergyadvancedesthetics-child-theme'); ?></h1>
                <p style="margin: 5px 0 0; color: #646970;"><?php _e('Gestisci dinamicamente la sezione. Usa i filtri per trovare rapidamente gli elementi.', 'synergyadvancedesthetics-child-theme'); ?></p>
            </div>
            <div>
                <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" style="display:inline;" id="pt-restore-form">
                    <input type="hidden" name="action" value="synergy_restore_products">
                    <?php wp_nonce_field('synergy_restore_products_nonce', 'synergy_restore_products_nonce_field'); ?>
                    <button type="button" id="pt-btn-restore" class="button button-secondary" style="color: #d63638; border-color: #d63638;"><?php _e('Ripristina Dati Iniziali', 'synergyadvancedesthetics-child-theme'); ?></button>
                </form>
            </div>
        </div>

        <?php if (isset($_GET['updated']) && $_GET['updated'] == 'true'): ?>
            <div class="notice notice-success is-dismissible"><p><?php _e('Dati salvati con successo.', 'synergyadvancedesthetics-child-theme'); ?></p></div>
        <?php endif; ?>
        <?php if (isset($_GET['restored']) && $_GET['restored'] == 'true'): ?>
            <div class="notice notice-warning is-dismissible"><p><?php _e('I dati iniziali sono stati ripristinati.', 'synergyadvancedesthetics-child-theme'); ?></p></div>
        <?php endif; ?>

        <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" id="pt-main-form">
            <input type="hidden" name="action" value="synergy_save_products">
            <?php wp_nonce_field('synergy_save_products_nonce', 'synergy_save_products_nonce_field'); ?>

            <!-- Testi della Sezione (Accordion) -->
            <div class="pt-accordion-box">
                <div class="pt-accordion-header" id="pt-texts-header">
                    <div style="font-weight: 600; font-size: 15px;">
                        <span class="dashicons dashicons-edit" style="margin-right: 8px;"></span>
                        <?php _e('Testi della Sezione', 'synergyadvancedesthetics-child-theme'); ?>
                        <span style="font-weight: normal; color: #8c8f94; font-size: 13px; margin-left: 10px;" id="pt-texts-preview">
                            <?php echo esc_html(wp_trim_words($title, 8, '...')); ?>
                        </span>
                    </div>
                    <span class="dashicons dashicons-arrow-down-alt2"></span>
                </div>
                <div class="pt-accordion-body" id="pt-texts-body">
                    <div class="pt-form-row">
                        <div class="pt-form-label"><label for="section_title"><?php _e('Titolo Sezione', 'synergyadvancedesthetics-child-theme'); ?></label></div>
                        <div class="pt-form-input">
                            <input type="text" id="section_title" name="section_title" value="<?php echo esc_attr($title); ?>">
                        </div>
                    </div>
                    <div class="pt-form-row">
                        <div class="pt-form-label"><label for="section_description"><?php _e('Descrizione', 'synergyadvancedesthetics-child-theme'); ?></label></div>
                        <div class="pt-form-input">
                            <textarea id="section_description" name="section_description"><?php echo esc_textarea($desc); ?></textarea>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Filters Bar -->
            <div class="pt-filters-bar">
                <div class="pt-filters" id="pt-filter-group">
                    <button type="button" class="pt-filter-btn active" data-filter="all">Tutti (<span id="c-all"><?php echo $count_all; ?></span>)</button>
                    <button type="button" class="pt-filter-btn" data-filter="Prodotti professionali">Prodotti (<span id="c-prod"><?php echo $count_prod; ?></span>)</button>
                    <button type="button" class="pt-filter-btn" data-filter="Tecnologia estetica">Tecnologie (<span id="c-tec"><?php echo $count_tec; ?></span>)</button>
                    <button type="button" class="pt-filter-btn" data-filter="Trattamenti Professionali">Trattamenti (<span id="c-trat"><?php echo $count_trat; ?></span>)</button>
                    <button type="button" class="pt-filter-btn" data-filter="status-active">Attivi (<span id="c-active"><?php echo $count_active; ?></span>)</button>
                    <button type="button" class="pt-filter-btn" data-filter="status-inactive">Disattivati (<span id="c-inactive"><?php echo $count_inactive; ?></span>)</button>
                </div>
                <div>
                    <input type="text" id="pt-search" class="pt-search-input" placeholder="Cerca prodotto, tecnologia...">
                </div>
            </div>

            <!-- Items Header & Add Button -->
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px;">
                <h3 style="margin: 0;"><?php _e('Lista Elementi', 'synergyadvancedesthetics-child-theme'); ?></h3>
                <button type="button" class="button button-primary" id="add-new-item"><?php _e('+ Aggiungi Nuovo', 'synergyadvancedesthetics-child-theme'); ?></button>
            </div>

            <div id="items-container">
                <?php 
                $index = 0;
                foreach ($items as $item): 
                    $is_active = (!isset($item['active']) || $item['active']) ? true : false;
                    $cat_class = 'prod';
                    if ($item['category'] === 'Tecnologia estetica') $cat_class = 'tec';
                    if ($item['category'] === 'Trattamenti Professionali') $cat_class = 'trat';
                ?>
                    <div class="pt-accordion-box pt-item-card" data-category="<?php echo esc_attr($item['category']); ?>" data-status="<?php echo $is_active ? 'active' : 'inactive'; ?>">
                        
                        <div class="pt-accordion-header pt-card-head">
                            <div style="display: flex; align-items: center; flex-grow: 1;">
                                <div class="pt-item-drag" title="Trascina per riordinare">☰</div>
                                <div class="pt-item-title">
                                    <span class="the-name"><?php echo esc_html($item['name']); ?></span>
                                    <span class="pt-item-badge <?php echo $cat_class; ?> the-cat-badge"><?php echo esc_html($item['category']); ?></span>
                                    <span style="color: #888; font-size: 12px; margin-left: 5px; font-weight: normal;" class="the-area">&middot; <?php echo esc_html($item['area']); ?></span>
                                </div>
                            </div>
                            
                            <div class="pt-item-actions">
                                <label class="pt-toggle-switch" title="Attiva/Disattiva">
                                    <input type="checkbox" class="pt-quick-toggle" <?php checked($is_active); ?>>
                                    <span class="pt-slider"></span>
                                </label>
                                <button type="button" class="pt-action-link pt-edit-btn">Modifica</button>
                                <button type="button" class="pt-action-link pt-dup-btn">Duplica</button>
                                <button type="button" class="pt-action-link delete pt-del-btn">Rimuovi</button>
                            </div>
                        </div>

                        <div class="pt-accordion-body pt-card-body">
                            <div class="pt-form-row">
                                <div class="pt-form-label"><label>Nome</label></div>
                                <div class="pt-form-input"><input type="text" name="items[<?php echo $index; ?>][name]" value="<?php echo esc_attr($item['name']); ?>" class="input-name" required></div>
                            </div>
                            <div class="pt-form-row">
                                <div class="pt-form-label"><label>Categoria</label></div>
                                <div class="pt-form-input">
                                    <select name="items[<?php echo $index; ?>][category]" class="input-category">
                                        <option value="Prodotti professionali" <?php selected($item['category'], 'Prodotti professionali'); ?>>Prodotti professionali</option>
                                        <option value="Tecnologia estetica" <?php selected($item['category'], 'Tecnologia estetica'); ?>>Tecnologia estetica</option>
                                        <option value="Trattamenti Professionali" <?php selected($item['category'], 'Trattamenti Professionali'); ?>>Trattamenti Professionali</option>
                                    </select>
                                </div>
                            </div>
                            <div class="pt-form-row">
                                <div class="pt-form-label"><label>Area</label></div>
                                <div class="pt-form-input"><input type="text" name="items[<?php echo $index; ?>][area]" value="<?php echo esc_attr($item['area']); ?>" class="input-area" placeholder="es. Viso e corpo"></div>
                            </div>
                            <div class="pt-form-row">
                                <div class="pt-form-label"><label>Descrizione</label></div>
                                <div class="pt-form-input"><textarea name="items[<?php echo $index; ?>][description]" class="input-desc"><?php echo esc_textarea($item['description']); ?></textarea></div>
                            </div>
                            
                            <!-- Hidden Fields -->
                            <input type="hidden" name="items[<?php echo $index; ?>][active]" value="<?php echo $is_active ? '1' : '0'; ?>" class="input-active">
                            <input type="hidden" name="items[<?php echo $index; ?>][order]" value="<?php echo esc_attr($item['order']); ?>" class="input-order">
                        </div>

                    </div>
                <?php 
                $index++;
                endforeach; 
                ?>
            </div>

            <div style="position: sticky; bottom: 0; background: #f1f1f1; padding: 15px 0; border-top: 1px solid #ccd0d4; margin-top: 20px; z-index: 100;">
                <input type="submit" name="submit" class="button button-primary button-large" value="<?php _e('Salva Tutte le Modifiche', 'synergyadvancedesthetics-child-theme'); ?>">
            </div>
        </form>
    </div>

    <!-- Template for new item -->
    <script type="text/template" id="item-template">
        <div class="pt-accordion-box pt-item-card" data-category="Prodotti professionali" data-status="active">
            <div class="pt-accordion-header pt-card-head">
                <div style="display: flex; align-items: center; flex-grow: 1;">
                    <div class="pt-item-drag" title="Trascina per riordinare">☰</div>
                    <div class="pt-item-title">
                        <span class="the-name">Nuovo Elemento</span>
                        <span class="pt-item-badge prod the-cat-badge">Prodotti professionali</span>
                        <span style="color: #888; font-size: 12px; margin-left: 5px; font-weight: normal;" class="the-area"></span>
                    </div>
                </div>
                <div class="pt-item-actions">
                    <label class="pt-toggle-switch" title="Attiva/Disattiva">
                        <input type="checkbox" class="pt-quick-toggle" checked>
                        <span class="pt-slider"></span>
                    </label>
                    <button type="button" class="pt-action-link pt-edit-btn">Modifica</button>
                    <button type="button" class="pt-action-link pt-dup-btn">Duplica</button>
                    <button type="button" class="pt-action-link delete pt-del-btn">Rimuovi</button>
                </div>
            </div>
            <div class="pt-accordion-body pt-card-body" style="display: block;">
                <div class="pt-form-row">
                    <div class="pt-form-label"><label>Nome</label></div>
                    <div class="pt-form-input"><input type="text" name="items[{{index}}][name]" value="Nuovo Elemento" class="input-name" required></div>
                </div>
                <div class="pt-form-row">
                    <div class="pt-form-label"><label>Categoria</label></div>
                    <div class="pt-form-input">
                        <select name="items[{{index}}][category]" class="input-category">
                            <option value="Prodotti professionali" selected>Prodotti professionali</option>
                            <option value="Tecnologia estetica">Tecnologia estetica</option>
                            <option value="Trattamenti Professionali">Trattamenti Professionali</option>
                        </select>
                    </div>
                </div>
                <div class="pt-form-row">
                    <div class="pt-form-label"><label>Area</label></div>
                    <div class="pt-form-input"><input type="text" name="items[{{index}}][area]" value="" class="input-area" placeholder="es. Viso e corpo"></div>
                </div>
                <div class="pt-form-row">
                    <div class="pt-form-label"><label>Descrizione</label></div>
                    <div class="pt-form-input"><textarea name="items[{{index}}][description]" class="input-desc"></textarea></div>
                </div>
                <input type="hidden" name="items[{{index}}][active]" value="1" class="input-active">
                <input type="hidden" name="items[{{index}}][order]" value="{{order}}" class="input-order">
            </div>
        </div>
    </script>

    <script>
    jQuery(document).ready(function($) {
        let itemIndex = <?php echo $index; ?>;
        
        // --- 1. ACCORDION LOGIC ---
        // Testi Section
        $('#pt-texts-header').on('click', function() {
            $('#pt-texts-body').slideToggle(200);
        });

        // Items Accordion
        $(document).on('click', '.pt-card-head', function(e) {
            // Prevent toggling if clicked on inputs or action buttons
            if($(e.target).closest('.pt-item-actions').length) return;
            $(this).next('.pt-card-body').slideToggle(200);
        });
        $(document).on('click', '.pt-edit-btn', function(e) {
            e.preventDefault();
            $(this).closest('.pt-item-card').find('.pt-card-body').slideToggle(200);
        });

        // --- 2. LIVE BINDINGS (Update Header on Input Change) ---
        $(document).on('input', '.input-name', function() {
            $(this).closest('.pt-item-card').find('.the-name').text($(this).val() || 'Senza Nome');
        });
        $(document).on('input', '.input-area', function() {
            let val = $(this).val();
            $(this).closest('.pt-item-card').find('.the-area').html(val ? '&middot; ' + val : '');
        });
        $(document).on('change', '.input-category', function() {
            let val = $(this).val();
            let badge = $(this).closest('.pt-item-card').find('.the-cat-badge');
            badge.text(val);
            badge.removeClass('prod tec trat');
            if(val === 'Tecnologia estetica') badge.addClass('tec');
            else if(val === 'Trattamenti Professionali') badge.addClass('trat');
            else badge.addClass('prod');
            
            $(this).closest('.pt-item-card').attr('data-category', val);
            updateCounts();
        });

        // --- 3. QUICK TOGGLE (Active/Inactive) ---
        $(document).on('change', '.pt-quick-toggle', function() {
            let isChecked = $(this).is(':checked');
            let card = $(this).closest('.pt-item-card');
            card.find('.input-active').val(isChecked ? '1' : '0');
            card.attr('data-status', isChecked ? 'active' : 'inactive');
            updateCounts();
        });

        // --- 4. ACTIONS: REMOVE, DUPLICATE, ADD ---
        // Remove
        $(document).on('click', '.pt-del-btn', function(e) {
            e.preventDefault();
            if (confirm('Sicuro di voler rimuovere questo elemento?')) {
                $(this).closest('.pt-item-card').fadeOut(200, function() {
                    $(this).remove();
                    updateOrders();
                    updateCounts();
                });
            }
        });

        // Duplicate
        $(document).on('click', '.pt-dup-btn', function(e) {
            e.preventDefault();
            let originalCard = $(this).closest('.pt-item-card');
            let clone = originalCard.clone();
            
            // Re-index inputs
            clone.find('input, select, textarea').each(function() {
                let nameAttr = $(this).attr('name');
                if(nameAttr) {
                    $(this).attr('name', nameAttr.replace(/\[\d+\]/, '[' + itemIndex + ']'));
                }
            });
            
            // Append and expand
            clone.find('.pt-card-body').show();
            clone.find('.the-name').text(clone.find('.input-name').val() + ' (Copia)');
            clone.find('.input-name').val(clone.find('.input-name').val() + ' (Copia)');
            
            originalCard.after(clone);
            itemIndex++;
            updateOrders();
            updateCounts();
            
            // Highlight
            clone.css('background-color', '#ffffe0');
            setTimeout(() => clone.css('background-color', ''), 1000);
        });

        // Add New
        $('#add-new-item').on('click', function() {
            var template = $('#item-template').html();
            var newOrder = $('#items-container .pt-item-card').length * 10;
            template = template.replace(/{{index}}/g, itemIndex);
            template = template.replace(/{{order}}/g, newOrder);
            $('#items-container').prepend(template);
            itemIndex++;
            updateOrders();
            updateCounts();
        });

        // --- 5. DRAG & DROP SORTING ---
        $('#items-container').sortable({
            handle: '.pt-item-drag',
            axis: 'y',
            update: function() { updateOrders(); }
        });

        function updateOrders() {
            $('#items-container .pt-item-card').each(function(i) {
                $(this).find('.input-order').val(i * 10);
            });
        }

        // --- 6. SEARCH & FILTERS ---
        let currentFilter = 'all';
        
        $('.pt-filter-btn').on('click', function() {
            $('.pt-filter-btn').removeClass('active');
            $(this).addClass('active');
            currentFilter = $(this).data('filter');
            applyFilters();
        });

        $('#pt-search').on('keyup', function() {
            applyFilters();
        });

        function applyFilters() {
            let query = $('#pt-search').val().toLowerCase();
            
            $('#items-container .pt-item-card').each(function() {
                let card = $(this);
                let cat = card.attr('data-category');
                let status = card.attr('data-status');
                
                // Text search
                let textContent = (
                    card.find('.input-name').val() + ' ' + 
                    cat + ' ' + 
                    card.find('.input-area').val() + ' ' + 
                    card.find('.input-desc').val()
                ).toLowerCase();
                
                let textMatch = textContent.includes(query);
                
                // Filter match
                let filterMatch = false;
                if(currentFilter === 'all') filterMatch = true;
                else if(currentFilter === 'status-active' && status === 'active') filterMatch = true;
                else if(currentFilter === 'status-inactive' && status === 'inactive') filterMatch = true;
                else if(currentFilter === cat) filterMatch = true;

                if(textMatch && filterMatch) {
                    card.show();
                } else {
                    card.hide();
                }
            });
        }

        function updateCounts() {
            let t=0, p=0, tec=0, trat=0, act=0, inact=0;
            $('#items-container .pt-item-card').each(function() {
                t++;
                let cat = $(this).attr('data-category');
                let stat = $(this).attr('data-status');
                
                if(cat === 'Prodotti professionali') p++;
                else if(cat === 'Tecnologia estetica') tec++;
                else if(cat === 'Trattamenti Professionali') trat++;
                
                if(stat === 'active') act++;
                else inact++;
            });
            $('#c-all').text(t);
            $('#c-prod').text(p);
            $('#c-tec').text(tec);
            $('#c-trat').text(trat);
            $('#c-active').text(act);
            $('#c-inactive').text(inact);
        }

        // --- 7. RESTORE DEFAULT ---
        $('#pt-btn-restore').on('click', function(e) {
            e.preventDefault();
            if(confirm('ATTENZIONE: Questa azione sovrascriverà tutti i dati attuali con i dati iniziali di default (verranno cancellate tutte le tue modifiche e nuovi inserimenti). Vuoi davvero procedere?')) {
                $('#pt-restore-form').submit();
            }
        });
    });
    </script>
    <?php
}
