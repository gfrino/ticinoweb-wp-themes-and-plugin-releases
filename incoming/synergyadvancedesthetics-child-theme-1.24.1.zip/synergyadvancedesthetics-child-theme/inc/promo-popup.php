<?php
/**
 * Pop-up Promozione Dinamico da CMS per Synergy Advanced Aesthetics
 * 
 * Prende i dati direttamente da:
 * CMS -> Promozioni (ticinoweb-cms#promozioni)
 * 
 * @package SynergyAdvancedAesthetics
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

function synergy_render_promo_popup() {
    // Solo in home page. La home di questo sito e' l'indice dei post
    // (show_on_front = posts, nessuna pagina statica assegnata), quindi la
    // condizione giusta e' is_front_page(): vale sia ora sia se in futuro
    // venisse assegnata una pagina statica.
    if ( ! is_front_page() ) {
        return;
    }

    $promo_disabled = get_option( 'ticinoweb_disable_promozioni' );
    if ( $promo_disabled ) {
        return;
    }

    $promo_title = get_option( 'ticinoweb_promozioni_title' );
    $promo_text  = get_option( 'ticinoweb_promozioni_text' );
    $promo_image = get_option( 'ticinoweb_promozioni_image' );
    $promo_link  = get_option( 'ticinoweb_promozioni_link' ) ?: home_url( '/#contatti' );

    // Fallback elegante se non ancora compilato nel CMS
    $title_context = 'promo-popup:title';
    $text_context  = 'promo-popup:text';
    if ( empty( $promo_title ) && empty( $promo_text ) && empty( $promo_image ) ) {
        $promo_title = 'Rigenerazione Viso & Protocolli d’Eccellenza';
        $promo_text  = 'Scopri le offerte speciali e i percorsi personalizzati per viso, corpo ed epilazione laser a Paradiso (Lugano). Prenota ora una consulenza con le nostre professioniste per una valutazione su misura.';
        $title_context = 'promo-popup:title_fallback';
        $text_context  = 'promo-popup:text_fallback';
    }

    if ( empty( $promo_title ) && empty( $promo_text ) && empty( $promo_image ) ) {
        return;
    }
    ?>
    <!-- SYNERGY PROMO POPUP MODAL -->
    <div id="synergy-promo-popup-modal" class="synergy-promo-modal" aria-hidden="true" role="dialog" aria-modal="true" aria-labelledby="synergy-promo-modal-title">
        <div class="synergy-promo-modal-overlay" id="synergy-promo-modal-overlay"></div>
        <div class="synergy-promo-modal-wrapper">
            <div class="synergy-promo-modal-card">
                
                <!-- Pulsante Chiusura X -->
                <button type="button" class="synergy-promo-modal-close" id="synergy-promo-modal-close" aria-label="<?php echo esc_attr( synergy_t( 'Chiudi promozione', 'promo-popup:close' ) ); ?>">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
                        <line x1="18" y1="6" x2="6" y2="18"></line>
                        <line x1="6" y1="6" x2="18" y2="18"></line>
                    </svg>
                </button>

                <div class="synergy-promo-modal-inner <?php echo empty( $promo_image ) ? 'no-image' : 'has-image'; ?>">
                    
                    <?php if ( ! empty( $promo_image ) ) : ?>
                        <div class="synergy-promo-modal-media">
                            <img src="<?php echo esc_url( $promo_image ); ?>" alt="<?php echo esc_attr( $promo_title ? synergy_t( $promo_title, $title_context ) : synergy_t( 'Offerta Promozione Synergy', 'promo-popup:image_alt' ) ); ?>" class="synergy-promo-modal-img" loading="eager" />
                            <div class="synergy-promo-modal-media-overlay"></div>
                        </div>
                    <?php endif; ?>

                    <div class="synergy-promo-modal-content">
                        <div class="synergy-promo-modal-badge">
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor">
                                <path d="M12 2l2.4 7.4h7.6l-6.2 4.5 2.4 7.5-6.2-4.6-6.2 4.6 2.4-7.5-6.2-4.5h7.6z"/>
                            </svg>
                            <span><?php echo esc_html( synergy_t( 'OFFERTA SPECIALE', 'promo-popup:badge' ) ); ?></span>
                        </div>

                        <?php if ( ! empty( $promo_title ) ) : ?>
                            <h3 id="synergy-promo-modal-title" class="synergy-promo-modal-heading">
                                <?php echo esc_html( synergy_t( $promo_title, $title_context ) ); ?>
                            </h3>
                        <?php endif; ?>

                        <?php if ( ! empty( $promo_text ) ) : ?>
                            <div class="synergy-promo-modal-desc">
                                <?php echo wp_kses_post( synergy_t_html( wpautop( $promo_text ), $text_context ) ); ?>
                            </div>
                        <?php endif; ?>

                        <?php
                        /*
                         * Quando la promozione rimanda a WhatsApp il pulsante cambia
                         * aspetto e testo: verde del marchio, icona e "scrivici". Lo
                         * stile e' legato al link, non impostato a mano, cosi' se la
                         * promozione tornera' a puntare a una pagina del sito il
                         * pulsante torna da solo a quello champagne di prima.
                         */
                        $promo_is_whatsapp = (bool) preg_match( '~^https?://(wa\.me|api\.whatsapp\.com|web\.whatsapp\.com)/~i', $promo_link );
                        $promo_cta_label   = $promo_is_whatsapp
                            ? synergy_t( 'Contattaci', 'promo-popup:btn:whatsapp' )
                            : synergy_t( 'Approfitta dell\'Offerta', 'promo-popup:btn' );
                        ?>
                        <div class="synergy-promo-modal-actions">
                            <a href="<?php echo esc_url( $promo_link ); ?>"
                               class="btn synergy-promo-modal-cta<?php echo $promo_is_whatsapp ? ' is-whatsapp' : ''; ?>"
                               id="synergy-promo-modal-cta-btn"
                               <?php if ( $promo_is_whatsapp ) : ?>target="_blank" rel="noopener"<?php endif; ?>>
                                <?php if ( $promo_is_whatsapp ) : ?>
                                    <?php // glifo ufficiale WhatsApp: sorgente in assets/images/whatsapp-glyph.svg ?>
                                    <svg class="synergy-promo-cta-icon" viewBox="-1.66 0 740.824 740.824" width="20" height="20" fill="currentColor" aria-hidden="true" focusable="false">
                                        <path fill-rule="evenodd" clip-rule="evenodd" d="M630.056 107.658C560.727 38.271 468.525.039 370.294 0 167.891 0 3.16 164.668 3.079 367.072c-.027 64.699 16.883 127.855 49.016 183.523L0 740.824l194.666-51.047c53.634 29.244 114.022 44.656 175.481 44.682h.151c202.382 0 367.128-164.689 367.21-367.094.039-98.088-38.121-190.32-107.452-259.707m-259.758 564.8h-.125c-54.766-.021-108.483-14.729-155.343-42.529l-11.146-6.613-115.516 30.293 30.834-112.592-7.258-11.543c-30.552-48.58-46.689-104.729-46.665-162.379C65.146 198.865 202.065 62 370.419 62c81.521.031 158.154 31.81 215.779 89.482s89.342 134.332 89.311 215.859c-.07 168.242-136.987 305.117-305.211 305.117m167.415-228.514c-9.176-4.591-54.286-26.782-62.697-29.843-8.41-3.061-14.526-4.591-20.644 4.592-6.116 9.182-23.7 29.843-29.054 35.964-5.351 6.122-10.703 6.888-19.879 2.296-9.175-4.591-38.739-14.276-73.786-45.526-27.275-24.32-45.691-54.36-51.043-63.542-5.352-9.183-.569-14.148 4.024-18.72 4.127-4.11 9.175-10.713 13.763-16.07 4.587-5.356 6.116-9.182 9.174-15.303 3.059-6.122 1.53-11.479-.764-16.07-2.294-4.591-20.643-49.739-28.29-68.104-7.447-17.886-15.012-15.466-20.644-15.746-5.346-.266-11.469-.323-17.585-.323-6.117 0-16.057 2.296-24.468 11.478-8.41 9.183-32.112 31.374-32.112 76.521s32.877 88.763 37.465 94.885c4.587 6.122 64.699 98.771 156.741 138.502 21.891 9.45 38.982 15.093 52.307 19.323 21.981 6.979 41.983 5.994 57.793 3.633 17.628-2.633 54.285-22.19 61.932-43.616 7.646-21.426 7.646-39.791 5.352-43.617-2.293-3.826-8.41-6.122-17.585-10.714"/>
                                    </svg>
                                <?php endif; ?>
                                <span><?php echo esc_html( $promo_cta_label ); ?></span>
                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                    <line x1="5" y1="12" x2="19" y2="12"></line>
                                    <polyline points="12 5 19 12 12 19"></polyline>
                                </svg>
                            </a>
                            <button type="button" class="synergy-promo-modal-dismiss" id="synergy-promo-modal-dismiss">
                                <?php echo esc_html( synergy_t( 'Continua la navigazione', 'promo-popup:dismiss' ) ); ?>
                            </button>
                        </div>
                    </div>

                </div>

            </div>
        </div>
    </div>
    <?php
}
add_action( 'wp_footer', 'synergy_render_promo_popup', 50 );
