<?php
/**
 * 301 dai vecchi permalink delle pagine.
 *
 * WordPress registra _wp_old_slug e reindirizza da solo solo per i post type
 * NON gerarchici: wp_check_for_changed_slugs() esce subito quando
 * is_post_type_hierarchical() e' vero, quindi le pagine restano scoperte e un
 * permalink rinominato finisce in 404 (o viene "indovinato" verso la home da
 * redirect_guess_404_permalink, che e' peggio: perde la pertinenza).
 *
 * Qui si colma quella lacuna per le pagine di questo sito: il vecchio slug va
 * salvato nel meta _wp_old_slug e questa funzione lo risolve verso il
 * permalink corrente.
 *
 * Tutto e' limitato al blog corrente: get_posts() e home_url() lavorano sulle
 * tabelle e sul dominio di questo sottosito, mai sulla rete.
 *
 * @package synergy-child
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

add_action( 'template_redirect', 'synergy_old_page_slug_redirect', 9 );

/**
 * Reindirizza una richiesta 404 alla pagina che aveva quel vecchio slug.
 */
function synergy_old_page_slug_redirect() {
    // Gira solo sui 404 del frontend: nessun costo sulle pagine che esistono.
    if ( is_admin() || ! is_404() || is_robots() || is_feed() ) {
        return;
    }

    $request = isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '';
    $path    = wp_parse_url( $request, PHP_URL_PATH );
    if ( ! $path ) {
        return;
    }

    // Solo l'ultimo segmento, normalizzato: l'input e' dell'utente, non ci si fida.
    $slug = sanitize_title( basename( untrailingslashit( $path ) ) );
    if ( $slug === '' ) {
        return;
    }

    $matches = get_posts(
        array(
            'post_type'              => 'page',
            'post_status'            => 'publish',
            'posts_per_page'         => 1,
            'fields'                 => 'ids',
            'no_found_rows'          => true,
            'ignore_sticky_posts'    => true,
            'update_post_term_cache' => false,
            'meta_query'             => array(
                array(
                    'key'   => '_wp_old_slug',
                    'value' => $slug,
                ),
            ),
        )
    );

    if ( empty( $matches ) ) {
        return;
    }

    $target = get_permalink( $matches[0] );
    if ( ! $target ) {
        return;
    }

    // wp_safe_redirect: il target resta sull'host di questo sottosito.
    wp_safe_redirect( $target, 301 );
    exit;
}
