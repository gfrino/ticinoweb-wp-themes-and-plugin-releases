<?php
/**
 * Destinazione delle schede servizio della home.
 *
 * Le schede arrivano da `ticinoweb_services` del parent theme, che gestisce
 * immagine, titolo e descrizione ma non una destinazione: il suo sanitizer
 * scarta le chiavi che non conosce, quindi un campo "link" aggiunto li'
 * andrebbe perso al primo salvataggio. La corrispondenza vive percio' qui,
 * agganciata all'id stabile del servizio, e resta modificabile dal backend.
 *
 * @package synergy-child
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

const SYNERGY_SERVICE_LINKS = 'synergy_service_links';

/**
 * Elenco dei servizi definiti nel CMS del parent.
 *
 * @return array
 */
function synergy_get_cms_services() {
    $s = function_exists( 'ticinoweb_get_services' ) ? ticinoweb_get_services() : get_option( 'ticinoweb_services', array() );
    return is_array( $s ) ? $s : array();
}

/**
 * Destinazione di una scheda servizio.
 *
 * @param array $service Voce di ticinoweb_services.
 * @return string URL, stringa vuota se non impostata o se la pagina non esiste piu'.
 */
function synergy_get_service_link( $service ) {
    $id = isset( $service['id'] ) ? $service['id'] : '';
    if ( $id === '' ) {
        return '';
    }

    $map = get_option( SYNERGY_SERVICE_LINKS, array() );
    $val = isset( $map[ $id ] ) ? $map[ $id ] : '';
    if ( $val === '' ) {
        return '';
    }

    // Il valore e' un ID di pagina: si risolve al momento, cosi' se lo slug
    // cambia il link segue da solo invece di rompersi.
    if ( ctype_digit( (string) $val ) ) {
        $p = get_post( (int) $val );
        return ( $p && $p->post_status === 'publish' ) ? get_permalink( $p ) : '';
    }

    return esc_url_raw( $val );
}

/* ---------------------------------------------------------------- admin */

add_action( 'admin_menu', 'synergy_service_links_menu', 21 );

/**
 * Pannello sotto il CMS ticinoWEB.
 */
function synergy_service_links_menu() {
    add_submenu_page(
        'ticinoweb-cms',
        'Destinazione schede servizi',
        'Link schede servizi',
        'manage_options',
        'synergy-service-links',
        'synergy_service_links_page'
    );
}

/**
 * Una tendina di pagine per ogni scheda servizio.
 */
function synergy_service_links_page() {
    if ( ! current_user_can( 'manage_options' ) ) {
        return;
    }

    $services = synergy_get_cms_services();

    if ( isset( $_POST['synergy_service_links_nonce'] )
        && wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['synergy_service_links_nonce'] ) ), 'synergy_save_service_links' ) ) {

        $valid = wp_list_pluck( $services, 'id' );
        $in    = isset( $_POST['synergy_service_link'] ) ? (array) wp_unslash( $_POST['synergy_service_link'] ) : array();
        $out   = array();
        foreach ( $in as $sid => $pid ) {
            $sid = sanitize_key( $sid );
            $pid = absint( $pid );
            if ( $pid && in_array( $sid, $valid, true ) ) {
                $out[ $sid ] = (string) $pid;
            }
        }
        update_option( SYNERGY_SERVICE_LINKS, $out );
        echo '<div class="notice notice-success is-dismissible"><p>Destinazioni salvate.</p></div>';
    }

    $map = get_option( SYNERGY_SERVICE_LINKS, array() );
    ?>
    <div class="wrap">
        <h1>Destinazione schede servizi</h1>
        <p class="description">
            Le schede della sezione &laquo;Trattamenti pensati per viso, corpo e benessere&raquo; in home page.
            Scegli a quale pagina porta ognuna: quelle senza pagina restano non cliccabili.
            Titoli, testi e immagini si modificano nel CMS, alla voce Servizi.
        </p>

        <?php if ( ! $services ) : ?>
            <p><em>Nessun servizio definito nel CMS.</em></p>
        <?php else : ?>
        <form method="post">
            <?php wp_nonce_field( 'synergy_save_service_links', 'synergy_service_links_nonce' ); ?>
            <table class="form-table" role="presentation">
                <tbody>
                <?php foreach ( $services as $s ) :
                    $sid = isset( $s['id'] ) ? $s['id'] : '';
                    if ( $sid === '' ) { continue; }
                    ?>
                    <tr>
                        <th scope="row"><label for="svc-<?php echo esc_attr( $sid ); ?>"><?php echo esc_html( $s['title'] ); ?></label></th>
                        <td>
                            <?php
                            wp_dropdown_pages( array(
                                'name'             => 'synergy_service_link[' . esc_attr( $sid ) . ']',
                                'id'               => 'svc-' . esc_attr( $sid ),
                                'selected'         => isset( $map[ $sid ] ) ? (int) $map[ $sid ] : 0,
                                'show_option_none' => '— nessuna destinazione —',
                                'option_none_value'=> '0',
                            ) );
                            ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            <?php submit_button( 'Salva destinazioni' ); ?>
        </form>
        <?php endif; ?>
    </div>
    <?php
}
