<?php
/**
 * Listino completo come shortcode, e metabox per collegare una pagina a una
 * o piu' sezioni di listino.
 *
 * Prima di questo file i prezzi vivevano in due posti: l'opzione
 * synergy_price_list_data e, scritti a mano, nel contenuto della pagina
 * /listino-prezzi/. Due fonti per lo stesso dato divergono sempre. Ora la
 * pagina contiene solo lo shortcode [synergy_listino_completo] e legge la
 * stessa fonte di home page e riquadri.
 *
 * @package synergy-child
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/* -------------------------------------------------------------------------
 * Listino completo
 * ---------------------------------------------------------------------- */

add_shortcode( 'synergy_listino_completo', 'synergy_render_full_price_list' );

/**
 * Macro-categoria (Viso, Corpo, Beauty...) di ogni sezione di listino.
 *
 * Il raggruppamento non e' un dato in piu' da tenere allineato: si legge
 * dal menu principale. Sotto "Trattamenti" le voci di secondo livello sono le
 * macro-categorie; le pagine appese sotto di esse dichiarano le loro sezioni
 * di listino nel meta _synergy_price_category. Se si sposta una pagina nel
 * menu, il listino segue da solo.
 *
 * @return array<string,string> id sezione => titolo macro-categoria
 */
function synergy_price_list_groups() {
    $locations = get_nav_menu_locations();
    $menu_id   = isset( $locations['primary'] ) ? (int) $locations['primary'] : 0;
    $items     = $menu_id ? wp_get_nav_menu_items( $menu_id ) : array();
    if ( empty( $items ) ) {
        return array();
    }

    $by_id = array();
    foreach ( $items as $item ) {
        $by_id[ (int) $item->ID ] = $item;
    }

    $map = array();
    foreach ( $items as $item ) {
        $parent_id = (int) $item->menu_item_parent;
        if ( ! $parent_id || ! isset( $by_id[ $parent_id ] ) ) {
            continue;
        }
        $parent = $by_id[ $parent_id ];
        // Serve il terzo livello: pagina -> macro-categoria -> "Trattamenti".
        if ( ! (int) $parent->menu_item_parent || $item->object !== 'page' ) {
            continue;
        }
        foreach ( synergy_get_treatment_price_categories( (int) $item->object_id ) as $cat_id ) {
            if ( ! isset( $map[ $cat_id ] ) ) {
                $map[ $cat_id ] = wp_strip_all_tags( html_entity_decode( $parent->title, ENT_QUOTES, 'UTF-8' ) );
            }
        }
    }

    return $map;
}

/**
 * Stampa tutte le sezioni visibili del listino, con ancore.
 *
 * @return string
 */
function synergy_render_full_price_list() {
    if ( ! function_exists( 'synergy_get_price_list_data' ) ) {
        return '';
    }

    $data       = synergy_get_price_list_data();
    $categories = array_filter(
        $data['categories'],
        function ( $c ) {
            return ! empty( $c['visible'] );
        }
    );
    usort(
        $categories,
        function ( $a, $b ) {
            return ( $a['order'] ?? 0 ) <=> ( $b['order'] ?? 0 );
        }
    );

    $groups        = synergy_price_list_groups();
    $current_group = '';

    ob_start();
    $n = 0;
    foreach ( $categories as $category ) {
        $items = synergy_get_price_items_by_category( $category['id'] );
        if ( empty( $items ) ) {
            continue;
        }
        $n++;

        // Una sezione senza pagina nel menu resta nel gruppo della precedente.
        $group = isset( $groups[ $category['id'] ] ) ? $groups[ $category['id'] ] : $current_group;
        if ( $group !== '' && $group !== $current_group ) {
            $current_group = $group;
            echo '<h2 class="synergy-listino-group" id="' . esc_attr( 'gruppo-' . sanitize_title( $group ) ) . '">' . esc_html( synergy_t( $group, 'price-list-page:group:' . sanitize_title( $group ) ) ) . '</h2>';
        }
        $anchor = synergy_price_list_anchor( $category['title'] );
        $cat_key = 'price-list-page:category:' . sanitize_title( $category['title'] );
        ?>
        <section class="synergy-listino-section">
            <h2 class="synergy-listino-title" id="<?php echo esc_attr( $anchor ); ?>">
                <?php echo esc_html( $n . '. ' . synergy_t( $category['title'], $cat_key . ':title' ) ); ?>
            </h2>

            <?php foreach ( $items as $item ) :
                $variants = array_filter(
                    $item['variants'] ?? array(),
                    function ( $v ) {
                        return ! empty( $v['visible'] );
                    }
                );
                usort(
                    $variants,
                    function ( $a, $b ) {
                        return ( $a['order'] ?? 0 ) <=> ( $b['order'] ?? 0 );
                    }
                );

                $meta = array_filter( array( $item['duration'] ?? '', $item['price_label'] ?? '' ), 'strlen' );
                $item_key = 'price-list-page:item:' . sanitize_title( $item['name'] );
                ?>
                <article class="synergy-listino-item">
                    <h3 class="synergy-listino-item-name"><?php echo esc_html( synergy_t( $item['name'], $item_key . ':name' ) ); ?></h3>
                    <?php if ( $meta ) : ?>
                        <p class="synergy-listino-item-meta"><strong><?php echo esc_html( implode( ' — ', $meta ) ); ?></strong></p>
                    <?php endif; ?>
                    <?php if ( ! empty( $item['description'] ) ) : ?>
                        <p class="synergy-listino-item-desc"><?php echo esc_html( synergy_t( $item['description'], $item_key . ':desc' ) ); ?></p>
                    <?php endif; ?>
                    <?php if ( $variants ) : ?>
                        <ul class="synergy-listino-variants">
                            <?php foreach ( $variants as $variant ) :
                                $vmeta = array_filter( array( $variant['duration'] ?? '', $variant['price_label'] ?? '' ), 'strlen' );
                                ?>
                                <li>
                                    <?php echo esc_html( synergy_t( $variant['name'], $item_key . ':variant:' . sanitize_title( $variant['name'] ) . ':name' ) ); ?>
                                    <?php if ( $vmeta ) : ?>
                                        &mdash; <strong><?php echo esc_html( implode( ' — ', $vmeta ) ); ?></strong>
                                    <?php endif; ?>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    <?php endif; ?>
                </article>
            <?php endforeach; ?>

            <?php if ( ! empty( $category['description'] ) ) : ?>
                <p class="synergy-listino-note"><em><?php echo esc_html( synergy_t( $category['description'], $cat_key . ':note' ) ); ?></em></p>
            <?php endif; ?>
        </section>
        <?php
    }

    if ( ! empty( $data['settings']['note'] ) ) {
        echo '<p class="synergy-listino-note synergy-listino-note--global"><em>' . esc_html( synergy_t( $data['settings']['note'], 'price-list-page:note' ) ) . '</em></p>';
    }

    return ob_get_clean();
}

/* -------------------------------------------------------------------------
 * Metabox: sezioni di listino della pagina
 * ---------------------------------------------------------------------- */

add_action( 'add_meta_boxes', 'synergy_price_category_metabox' );

/**
 * Registra il metabox sulle pagine.
 */
function synergy_price_category_metabox() {
    add_meta_box(
        'synergy-price-category',
        __( 'Sezioni del listino', 'synergy' ),
        'synergy_price_category_metabox_render',
        'page',
        'side',
        'default'
    );
}

/**
 * Checkbox delle categorie di listino.
 *
 * @param WP_Post $post
 */
function synergy_price_category_metabox_render( $post ) {
    if ( ! function_exists( 'synergy_get_price_list_data' ) ) {
        return;
    }

    wp_nonce_field( 'synergy_save_price_category', 'synergy_price_category_nonce' );

    $selected = synergy_get_treatment_price_categories( $post->ID );
    $data     = synergy_get_price_list_data();

    $categories = array_filter(
        $data['categories'],
        function ( $c ) {
            return ! empty( $c['visible'] );
        }
    );
    usort(
        $categories,
        function ( $a, $b ) {
            return ( $a['order'] ?? 0 ) <=> ( $b['order'] ?? 0 );
        }
    );

    echo '<p class="description">' . esc_html__( 'Le sezioni selezionate compaiono come riquadro prezzi in fondo alla pagina. Lascia vuoto per non mostrare nessun riquadro.', 'synergy' ) . '</p>';
    echo '<div style="max-height:260px;overflow:auto;margin-top:8px;">';
    foreach ( $categories as $c ) {
        $count = count( synergy_get_price_items_by_category( $c['id'] ) );
        printf(
            '<label style="display:block;margin-bottom:6px;"><input type="checkbox" name="synergy_price_category[]" value="%s"%s> %s <span style="color:#777;">(%d)</span></label>',
            esc_attr( $c['id'] ),
            checked( in_array( $c['id'], $selected, true ), true, false ),
            esc_html( $c['title'] ),
            (int) $count
        );
    }
    echo '</div>';
}

add_action( 'save_post_page', 'synergy_save_price_category', 10, 2 );

/**
 * Salva le categorie selezionate, conservando l'ordine gia' impostato.
 *
 * @param int     $post_id
 * @param WP_Post $post
 */
function synergy_save_price_category( $post_id, $post ) {
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
        return;
    }
    if ( ! isset( $_POST['synergy_price_category_nonce'] )
        || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['synergy_price_category_nonce'] ) ), 'synergy_save_price_category' ) ) {
        return;
    }
    if ( ! current_user_can( 'edit_page', $post_id ) ) {
        return;
    }

    $submitted = isset( $_POST['synergy_price_category'] ) ? (array) wp_unslash( $_POST['synergy_price_category'] ) : array();
    $submitted = array_map( 'sanitize_key', $submitted );

    // Solo id di categorie realmente esistenti.
    $valid = array();
    if ( function_exists( 'synergy_get_price_list_data' ) ) {
        foreach ( synergy_get_price_list_data()['categories'] as $c ) {
            $valid[] = $c['id'];
        }
    }
    $submitted = array_values( array_intersect( $submitted, $valid ) );

    // L'ordine dei riquadri e' quello gia' salvato: le sezioni scelte prima
    // restano al loro posto, le nuove si accodano. Cosi' un ordine voluto
    // (es. laser prima della cera) non viene ribaltato a ogni salvataggio.
    $previous = synergy_get_treatment_price_categories( $post_id );
    $ordered  = array_values( array_intersect( $previous, $submitted ) );
    foreach ( $submitted as $id ) {
        if ( ! in_array( $id, $ordered, true ) ) {
            $ordered[] = $id;
        }
    }

    if ( $ordered ) {
        update_post_meta( $post_id, '_synergy_price_category', implode( ',', $ordered ) );
    } else {
        delete_post_meta( $post_id, '_synergy_price_category' );
    }
}
