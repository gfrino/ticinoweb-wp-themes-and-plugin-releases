<?php
/**
 * Riquadro riepilogativo dei prezzi nelle pagine trattamento.
 *
 * I prezzi restano in un solo posto: l'opzione synergy_price_list_data, la
 * stessa che alimenta il listino della home. Ogni pagina trattamento dichiara
 * a quale categoria appartiene tramite il meta _synergy_price_category e il
 * riquadro si aggiorna da solo quando il listino cambia.
 *
 * @package synergy-child
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Categorie di listino associate alla pagina.
 *
 * Il meta _synergy_price_category accetta un solo id oppure piu' id separati
 * da virgola: una pagina come "Epilazione laser & Depilazione" deve poter
 * mostrare il listino donna e quello uomo uno sotto l'altro.
 *
 * @param int $post_id
 * @return string[] Elenco vuoto se la pagina non ne ha nessuna.
 */
function synergy_get_treatment_price_categories( $post_id ) {
    $raw = get_post_meta( $post_id, '_synergy_price_category', true );
    if ( ! is_string( $raw ) || trim( $raw ) === '' ) {
        return array();
    }

    $ids = array_map( 'trim', explode( ',', $raw ) );
    $ids = array_filter( $ids, 'strlen' );

    return array_values( array_unique( $ids ) );
}

/**
 * Prima categoria associata alla pagina.
 *
 * Mantenuta per compatibilita' con eventuali chiamate esistenti.
 *
 * @param int $post_id
 * @return string
 */
function synergy_get_treatment_price_category( $post_id ) {
    $ids = synergy_get_treatment_price_categories( $post_id );
    return $ids ? $ids[0] : '';
}

/**
 * Voci visibili di una categoria, gia' ordinate.
 *
 * @param string $category_id
 * @return array
 */
function synergy_get_price_items_by_category( $category_id ) {
    if ( $category_id === '' || ! function_exists( 'synergy_get_price_list_data' ) ) {
        return array();
    }

    $data  = synergy_get_price_list_data();
    $items = array_filter(
        $data['items'],
        function ( $i ) use ( $category_id ) {
            return ! empty( $i['visible'] ) && isset( $i['category_id'] ) && $i['category_id'] === $category_id;
        }
    );
    usort(
        $items,
        function ( $a, $b ) {
            return ( $a['order'] ?? 0 ) <=> ( $b['order'] ?? 0 );
        }
    );

    return $items;
}

/**
 * Stampa il riquadro riepilogativo. Non produce nulla se la pagina non ha una
 * categoria associata o se quella categoria non ha voci visibili.
 *
 * @param int $post_id
 */
function synergy_render_treatment_price_box( $post_id ) {
    $categories = synergy_get_treatment_price_categories( $post_id );

    // Con una sola categoria il suo nome e' gia' l'H1 della pagina, quindi il
    // titolo del riquadro annuncia il contenuto. Con piu' categorie servono
    // invece titoli distinti, altrimenti la pagina avrebbe due H2 identici.
    $use_category_as_title = count( $categories ) > 1;

    foreach ( $categories as $category_id ) {
        synergy_render_price_box_section( $category_id, $use_category_as_title );
    }
}

/**
 * Stampa il riquadro di una singola categoria.
 *
 * @param string $category_id
 */
function synergy_render_price_box_section( $category_id, $use_category_as_title = false ) {
    $items = synergy_get_price_items_by_category( $category_id );

    if ( empty( $items ) ) {
        return;
    }

    $data     = synergy_get_price_list_data();
    $category = null;
    foreach ( $data['categories'] as $c ) {
        if ( isset( $c['id'] ) && $c['id'] === $category_id ) {
            $category = $c;
            break;
        }
    }
    if ( ! $category || empty( $category['visible'] ) ) {
        return;
    }
    ?>
    <section class="synergy-treatment-prices" aria-labelledby="prezzi-<?php echo esc_attr( $category_id ); ?>">
        <?php
        // "Prezzi e durate" solo se almeno una voce ha una durata: la
        // depilazione, per esempio, e' a prezzo per zona e non ha durate.
        $has_duration = false;
        foreach ( $items as $i ) {
            if ( ! empty( $i['duration'] ) ) {
                $has_duration = true;
                break;
            }
        }
        $section_context = 'price-list:section:' . sanitize_title( $category_id );
        $box_title = $use_category_as_title
            ? synergy_t( $category['title'], $section_context . ':title' )
            : ( $has_duration ? synergy_t( 'Prezzi e durate', 'price-box:title:prices_durations' ) : synergy_t( 'Prezzi', 'price-box:title:prices' ) );
        ?>
        <header class="stp-head">
            <?php if ( ! $use_category_as_title ) : ?>
                <span class="stp-eyebrow"><?php echo esc_html( synergy_t( $category['title'], $section_context . ':title' ) ); ?></span>
            <?php else : ?>
                <span class="stp-eyebrow"><?php echo esc_html( synergy_t( 'Listino', 'price-box:eyebrow' ) ); ?></span>
            <?php endif; ?>
            <h2 class="stp-title" id="prezzi-<?php echo esc_attr( $category_id ); ?>"><?php echo esc_html( $box_title ); ?></h2>
        </header>

        <ul class="stp-list">
            <?php foreach ( $items as $item ) :
                $variants = array_filter(
                    $item['variants'] ?? array(),
                    function ( $v ) {
                        return ! empty( $v['visible'] );
                    }
                );
                usort(
                    $variants,
                    function ( $a, $b ) {
                        return ( $a['order'] ?? 0 ) <=> ( $b['order'] ?? 0 );
                    }
                );
                $item_context = 'price-list:item:' . sanitize_title( ! empty( $item['id'] ) ? $item['id'] : $item['name'] );
                ?>
                <li class="stp-item">
                    <div class="stp-row">
                        <span class="stp-name"><?php echo esc_html( synergy_t( $item['name'], $item_context . ':name' ) ); ?></span>
                        <span class="stp-dots" aria-hidden="true"></span>
                        <span class="stp-price">
                            <?php if ( ! empty( $item['duration'] ) ) : ?>
                                <span class="stp-duration"><?php echo esc_html( synergy_t( $item['duration'], 'price-list:duration' ) ); ?></span>
                            <?php endif; ?>
                            <span class="stp-amount"><?php echo esc_html( $item['price_label'] ); ?></span>
                        </span>
                    </div>

                    <?php if ( $variants ) : ?>
                        <ul class="stp-variants">
                            <?php foreach ( $variants as $variant ) :
                                $variant_context = $item_context . ':variant:' . sanitize_title( ! empty( $variant['id'] ) ? $variant['id'] : $variant['name'] );
                                ?>
                                <li class="stp-row stp-row--variant">
                                    <span class="stp-name"><?php echo esc_html( synergy_t( $variant['name'], $variant_context . ':name' ) ); ?></span>
                                    <span class="stp-dots" aria-hidden="true"></span>
                                    <span class="stp-price">
                                        <?php if ( ! empty( $variant['duration'] ) ) : ?>
                                            <span class="stp-duration"><?php echo esc_html( synergy_t( $variant['duration'], 'price-list:duration' ) ); ?></span>
                                        <?php endif; ?>
                                        <span class="stp-amount"><?php echo esc_html( $variant['price_label'] ); ?></span>
                                    </span>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    <?php endif; ?>
                </li>
            <?php endforeach; ?>
        </ul>

        <?php if ( ! empty( $category['description'] ) ) : ?>
            <p class="stp-note"><?php echo esc_html( synergy_t( $category['description'], $section_context . ':description' ) ); ?></p>
        <?php endif; ?>

        <p class="stp-cta">
            <a href="<?php echo esc_url( home_url( '/listino-prezzi/' ) ); ?>"><?php echo esc_html( synergy_t( 'Vedi il listino completo', 'price-box:full_list' ) ); ?> &rarr;</a>
        </p>
    </section>
    <?php
}

/**
 * Ancora (#fragment) della sezione di listino di una categoria.
 *
 * Usata sia per generare gli id sugli <h2> della pagina listino sia per i
 * link del megamenu: derivandola sempre dal titolo della categoria le due
 * parti restano allineate senza una tabella di corrispondenza da mantenere.
 *
 * @param string $category_title
 * @return string
 */
function synergy_price_list_anchor( $category_title ) {
    return sanitize_title( $category_title );
}

/**
 * ID della pagina che ospita il listino completo.
 *
 * @return int 0 se la pagina non esiste.
 */
function synergy_get_price_list_page_id() {
    $page = get_page_by_path( 'listino-prezzi' );
    /**
     * Permette di spostare il listino su un'altra pagina senza toccare il tema.
     *
     * @param int $page_id
     */
    return (int) apply_filters( 'synergy_price_list_page_id', $page ? $page->ID : 0 );
}

/**
 * Categorie visibili con la loro ancora, per costruire un indice del listino.
 *
 * @return array<int,array{title:string,url:string,count:int}>
 */
function synergy_get_price_list_index() {
    if ( ! function_exists( 'synergy_get_price_list_data' ) ) {
        return array();
    }

    $page_id = synergy_get_price_list_page_id();
    if ( ! $page_id ) {
        return array();
    }

    $base = get_permalink( $page_id );
    $data = synergy_get_price_list_data();

    $categories = array_filter(
        $data['categories'],
        function ( $c ) {
            return ! empty( $c['visible'] );
        }
    );
    usort(
        $categories,
        function ( $a, $b ) {
            return ( $a['order'] ?? 0 ) <=> ( $b['order'] ?? 0 );
        }
    );

    $index = array();
    foreach ( $categories as $c ) {
        $items = synergy_get_price_items_by_category( $c['id'] );
        if ( empty( $items ) ) {
            continue;
        }
        $index[] = array(
            'title' => $c['title'],
            'url'   => $base . '#' . synergy_price_list_anchor( $c['title'] ),
            'count' => count( $items ),
        );
    }

    return $index;
}
