<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Funzione per renderizzare una singola card prodotto
 */
function synergy_render_product_card( $post_id ) {
    $product = wc_get_product( $post_id );
    if ( ! $product ) return '';

    $title = $product->get_name();
    $short_desc = $product->get_short_description();
    if ( empty( $short_desc ) ) {
        $short_desc = wp_trim_words( $product->get_description(), 15, '...' );
    } else {
        $short_desc = wp_trim_words( $short_desc, 15, '...' );
    }

    // Prezzo
    $price_html = '';
    $price = $product->get_price();
    if ( '' === $price ) {
        $price_html = '<span class="product-price">' . esc_html( synergy_t( 'Prezzo su richiesta', 'ajax:price_on_request' ) ) . '</span>';
    } else {
        if ( $product->is_on_sale() ) {
            $price_html .= '<span class="product-price on-sale">';
            $price_html .= '<del>' . wc_price( $product->get_regular_price() ) . '</del> ';
            $price_html .= '<ins>' . wc_price( $product->get_sale_price() ) . '</ins>';
            $price_html .= '</span>';
        } else {
            $price_html = '<span class="product-price">' . wc_price( $price ) . '</span>';
        }
    }

    // Badge offerta
    $badge_html = '';
    if ( $product->is_on_sale() ) {
        $badge_html = '<span class="product-badge sale-badge">' . esc_html( synergy_t( 'In offerta', 'ajax:badge:sale' ) ) . '</span>';
    }

    // Immagine
    $image_id = $product->get_image_id();
    $image_html = '';
    if ( $image_id ) {
        $image_html = wp_get_attachment_image( $image_id, 'medium', false, array( 'class' => 'product-img' ) );
    } else {
        // Placeholder elegante
        $brand_name = '';
        $brand_terms = get_the_terms( $post_id, 'product_brand' );
        if ( $brand_terms && ! is_wp_error( $brand_terms ) ) {
            $brand_name = $brand_terms[0]->name;
        }
        $image_html = '<div class="product-img-placeholder">';
        $image_html .= '<svg viewBox="0 0 24 24" width="32" height="32" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"/></svg>';
        if ( $brand_name ) {
            $image_html .= '<span class="placeholder-brand">' . esc_html( $brand_name ) . '</span>';
        }
        $image_html .= '</div>';
    }

    // Categoria principale (prima categoria trovata)
    $primary_cat = '';
    $cat_terms = get_the_terms( $post_id, 'product_cat' );
    if ( $cat_terms && ! is_wp_error( $cat_terms ) ) {
        $primary_cat = $cat_terms[0]->name;
    }

    // Marchio (tassonomia product_brand)
    $brand = '';
    $brand_terms = get_the_terms( $post_id, 'product_brand' );
    if ( $brand_terms && ! is_wp_error( $brand_terms ) ) {
        $brand = $brand_terms[0]->name;
    }

    // URLs
    $product_url = get_permalink( $post_id );
    $contact_url = home_url( '/contatti/' );
    $info_url = add_query_arg( 'prodotto', urlencode( $title ), $contact_url );

    ob_start();
    ?>
    <div class="synergy-product-card">
        <a href="<?php echo esc_url( $product_url ); ?>" class="product-card-clickable-area">
            <div class="product-card-image-wrap">
                <?php echo $badge_html; ?>
                <div class="product-img-link">
                    <?php echo $image_html; ?>
                </div>
            </div>
            <div class="product-card-body">
                <?php if ( $primary_cat ) : ?>
                    <span class="product-cat-badge"><?php echo esc_html( $primary_cat ); ?></span>
                <?php endif; ?>
                
                <h3 class="product-title"><?php echo esc_html( $title ); ?></h3>
                
                <?php if ( $brand ) : ?>
                    <span class="product-brand"><?php echo esc_html( $brand ); ?></span>
                <?php endif; ?>
                
                <div class="product-desc">
                    <?php echo wp_kses_post( $short_desc ); ?>
                </div>
            </div>
        </a>
        <div class="product-card-footer">
            <a href="<?php echo esc_url( $product_url ); ?>" class="product-price-wrapper product-price-link">
                <?php echo $price_html; ?>
            </a>
            <div class="product-card-actions">
                <button type="button" class="btn btn-primary btn-scopri synergy-add-to-cart-btn" data-product_id="<?php echo esc_attr( $post_id ); ?>"><?php echo esc_html( synergy_t( 'Aggiungi al carrello', 'ajax:card:add_to_cart' ) ); ?></button>
                <a href="<?php echo esc_url( $info_url ); ?>" class="secondary-link"><?php echo esc_html( synergy_t( 'Richiedi informazioni', 'ajax:card:info' ) ); ?></a>
            </div>
        </div>
    </div>
    <?php
    return ob_get_clean();
}

/**
 * AJAX Add to Cart Handler
 */
add_action( 'wp_ajax_synergy_add_to_cart', 'synergy_add_to_cart_ajax' );
add_action( 'wp_ajax_nopriv_synergy_add_to_cart', 'synergy_add_to_cart_ajax' );

function synergy_add_to_cart_ajax() {
    $product_id = isset( $_POST['product_id'] ) ? intval( $_POST['product_id'] ) : 0;
    $quantity   = isset( $_POST['quantity'] ) ? intval( $_POST['quantity'] ) : 1;
    if ( $quantity < 1 ) {
        $quantity = 1;
    }

    if ( $product_id && function_exists( 'WC' ) ) {
        // Ensure WooCommerce session and customer cookies are loaded during AJAX
        if ( null === WC()->session ) {
            $session_class = apply_filters( 'woocommerce_session_handler', 'WC_Session_Handler' );
            WC()->session = new $session_class();
            WC()->session->init();
        }
        if ( ! WC()->session->has_session() ) {
            WC()->session->set_customer_session_cookie( true );
        }
        if ( null === WC()->customer ) {
            WC()->customer = new WC_Customer( get_current_user_id(), true );
        }
        if ( null === WC()->cart ) {
            WC()->cart = new WC_Cart();
        }

        $passed_validation = apply_filters( 'woocommerce_add_to_cart_validation', true, $product_id, $quantity );
        if ( $passed_validation ) {
            $cart_item_key = WC()->cart->add_to_cart( $product_id, $quantity );
            if ( $cart_item_key ) {
                // Force WooCommerce session cookie & cart cookie persistence so items persist across page views
                WC()->session->set_customer_session_cookie( true );
                if ( function_exists( 'wc_set_cart_cookie' ) ) {
                    wc_set_cart_cookie( true );
                }
                WC()->cart->set_session();

                do_action( 'woocommerce_ajax_added_to_cart', $product_id );
                
                $cart_count = WC()->cart->get_cart_contents_count();
                $cart_hash  = WC()->cart->get_cart_hash();
                $fragments  = apply_filters( 'woocommerce_add_to_cart_fragments', array() );

                wp_send_json_success( array( 
                    'product_id' => $product_id,
                    'cart_count' => $cart_count,
                    'cart_hash'  => $cart_hash,
                    'fragments'  => $fragments
                ) );
            }
        }
    }
    wp_send_json_error( array( 'message' => synergy_t( 'Impossibile aggiungere il prodotto al carrello.', 'ajax:cart_error' ) ) );
}

/**
 * AJAX Handler
 */
add_action( 'wp_ajax_synergy_filter_products', 'synergy_filter_products_ajax' );
add_action( 'wp_ajax_nopriv_synergy_filter_products', 'synergy_filter_products_ajax' );

function synergy_filter_products_ajax() {
    $paged    = isset( $_GET['paged'] ) ? intval( $_GET['paged'] ) : 1;
    $search   = isset( $_GET['search'] ) ? sanitize_text_field( $_GET['search'] ) : '';
    $category = isset( $_GET['category'] ) ? sanitize_text_field( $_GET['category'] ) : '';
    $brand    = isset( $_GET['brand'] ) ? sanitize_text_field( $_GET['brand'] ) : '';
    $min_price= isset( $_GET['min_price'] ) ? floatval( $_GET['min_price'] ) : 0;
    $max_price= isset( $_GET['max_price'] ) ? floatval( $_GET['max_price'] ) : 0;
    $orderby  = isset( $_GET['orderby'] ) ? sanitize_text_field( $_GET['orderby'] ) : 'default';

    $args = array(
        'post_type'      => 'product',
        'post_status'    => 'publish',
        'posts_per_page' => 24,
        'paged'          => $paged,
    );

    // Search
    if ( ! empty( $search ) ) {
        $args['s'] = $search;
    }

    // Taxonomy Query
    $tax_query = array();
    
    if ( ! empty( $category ) ) {
        $cat_array = explode( ',', $category );
        $tax_query[] = array(
            'taxonomy' => 'product_cat',
            'field'    => 'slug',
            'terms'    => $cat_array,
            'operator' => 'IN'
        );
    }

    if ( ! empty( $brand ) ) {
        $brand_array = explode( ',', $brand );
        $tax_query[] = array(
            'taxonomy' => 'product_brand',
            'field'    => 'slug',
            'terms'    => $brand_array,
            'operator' => 'IN'
        );
    }

    if ( count( $tax_query ) > 0 ) {
        $tax_query['relation'] = 'AND';
        $args['tax_query'] = $tax_query;
    }

    // Meta Query (Price)
    if ( $min_price > 0 || $max_price > 0 ) {
        $meta_query = array();
        if ( $max_price > 0 ) {
            $meta_query[] = array(
                'key'     => '_price',
                'value'   => array( $min_price, $max_price ),
                'compare' => 'BETWEEN',
                'type'    => 'NUMERIC'
            );
        } else {
            $meta_query[] = array(
                'key'     => '_price',
                'value'   => $min_price,
                'compare' => '>=',
                'type'    => 'NUMERIC'
            );
        }
        $args['meta_query'] = $meta_query;
    }

    // Orderby
    switch ( $orderby ) {
        case 'price_asc':
            $args['meta_key'] = '_price';
            $args['orderby']  = 'meta_value_num';
            $args['order']    = 'ASC';
            break;
        case 'price_desc':
            $args['meta_key'] = '_price';
            $args['orderby']  = 'meta_value_num';
            $args['order']    = 'DESC';
            break;
        case 'title_asc':
            $args['orderby'] = 'title';
            $args['order']   = 'ASC';
            break;
        case 'title_desc':
            $args['orderby'] = 'title';
            $args['order']   = 'DESC';
            break;
        default:
            $args['orderby'] = 'menu_order date';
            $args['order']   = 'DESC';
            break;
    }

    $query = new WP_Query( $args );

    $html = '';
    if ( $query->have_posts() ) {
        while ( $query->have_posts() ) {
            $query->the_post();
            $html .= synergy_render_product_card( get_the_ID() );
        }
    } else {
        $html = '<div class="synergy-empty-state">';
        $html .= '<h3>' . esc_html( synergy_t( 'Nessun prodotto trovato', 'ajax:empty:title' ) ) . '</h3>';
        $html .= '<p>' . esc_html( synergy_t( 'Prova a modificare i filtri o contattaci per ricevere un consiglio personalizzato.', 'ajax:empty:text' ) ) . '</p>';
        $html .= '<button type="button" class="btn btn-outline" id="synergy-reset-empty">' . esc_html( synergy_t( 'Cancella filtri', 'ajax:empty:reset' ) ) . '</button>';
        $html .= '</div>';
    }

    // Calculate Dynamic Term Counts
    $counts = synergy_get_filter_counts( $search, $category, $brand, $min_price, $max_price );

    $response = array(
        'html'       => $html,
        'total'      => $query->found_posts,
        'max_pages'  => $query->max_num_pages,
        'paged'      => $paged,
        'counts'     => $counts
    );

    wp_reset_postdata();
    wp_send_json_success( $response );
}

/**
 * Get dynamic filter counts for Categories and Brands
 */
function synergy_get_filter_counts( $search, $category, $brand, $min_price, $max_price ) {
    global $wpdb;
    
    // Helper to get matching post IDs ignoring ONE taxonomy
    $get_matching_ids = function( $ignore_tax = '' ) use ( $search, $category, $brand, $min_price, $max_price ) {
        $args = array(
            'post_type'      => 'product',
            'post_status'    => 'publish',
            'posts_per_page' => -1,
            'fields'         => 'ids',
            'no_found_rows'  => true,
            'update_post_meta_cache' => false,
            'update_post_term_cache' => false,
        );

        if ( ! empty( $search ) ) {
            $args['s'] = $search;
        }

        $tax_query = array();
        
        if ( $ignore_tax !== 'product_cat' && ! empty( $category ) ) {
            $tax_query[] = array(
                'taxonomy' => 'product_cat',
                'field'    => 'slug',
                'terms'    => explode( ',', $category ),
                'operator' => 'IN'
            );
        }

        if ( $ignore_tax !== 'product_brand' && ! empty( $brand ) ) {
            $tax_query[] = array(
                'taxonomy' => 'product_brand',
                'field'    => 'slug',
                'terms'    => explode( ',', $brand ),
                'operator' => 'IN'
            );
        }

        if ( count( $tax_query ) > 0 ) {
            $tax_query['relation'] = 'AND';
            $args['tax_query'] = $tax_query;
        }

        if ( $min_price > 0 || $max_price > 0 ) {
            $meta_query = array();
            if ( $max_price > 0 ) {
                $meta_query[] = array(
                    'key'     => '_price',
                    'value'   => array( $min_price, $max_price ),
                    'compare' => 'BETWEEN',
                    'type'    => 'NUMERIC'
                );
            } else {
                $meta_query[] = array(
                    'key'     => '_price',
                    'value'   => $min_price,
                    'compare' => '>=',
                    'type'    => 'NUMERIC'
                );
            }
            $args['meta_query'] = $meta_query;
        }

        $query = new WP_Query( $args );
        return $query->posts;
    };

    $cat_ids = $get_matching_ids( 'product_cat' );
    $brand_ids = $get_matching_ids( 'product_brand' );

    $counts = array(
        'product_cat' => array(),
        'product_brand' => array()
    );

    // Get term counts from DB for these IDs
    $get_term_counts = function( $post_ids, $taxonomy ) use ( $wpdb ) {
        if ( empty( $post_ids ) ) return array();
        
        $ids_list = implode( ',', array_map( 'intval', $post_ids ) );
        $query = $wpdb->prepare( "
            SELECT t.slug, COUNT(tr.object_id) as count
            FROM {$wpdb->term_relationships} tr
            INNER JOIN {$wpdb->term_taxonomy} tt ON tr.term_taxonomy_id = tt.term_taxonomy_id
            INNER JOIN {$wpdb->terms} t ON tt.term_id = t.term_id
            WHERE tt.taxonomy = %s
            AND tr.object_id IN ($ids_list)
            GROUP BY t.term_id
        ", $taxonomy );
        
        $results = $wpdb->get_results( $query );
        $term_counts = array();
        foreach ( $results as $row ) {
            $term_counts[ $row->slug ] = intval( $row->count );
        }
        return $term_counts;
    };

    $counts['product_cat'] = $get_term_counts( $cat_ids, 'product_cat' );
    $counts['product_brand'] = $get_term_counts( $brand_ids, 'product_brand' );

    return $counts;
}
