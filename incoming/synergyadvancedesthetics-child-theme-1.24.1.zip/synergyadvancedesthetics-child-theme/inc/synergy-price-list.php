<?php
/**
 * Synergy Advanced Aesthetics - Price List Module
 */

if (!defined('ABSPATH')) exit; // Exit if accessed directly

/**
 * Ritorna i dati iniziali di default dal PDF
 */
function synergy_price_list_default_data() {
    return [
        'settings' => [
            'enabled' => true,
            'eyebrow' => 'Listino trattamenti',
            'title' => 'Prezzi trattamenti estetici viso',
            'subtitle' => 'Una selezione di trattamenti viso personalizzati, protocolli professionali e tecnologie avanzate.',
            'note' => 'I prezzi possono variare in base alla valutazione iniziale e al percorso consigliato.',
            'cta_label' => 'Prenota una consulenza',
            'cta_url' => '/contatti/',
            'max_items' => 8,
            'show_featured_first' => true,
            'show_load_more' => true,
        ],
        'categories' => [
            [
                'id' => 'rigenerazione-biohacking',
                'title' => 'Rigenerazione avanzata & Biohacking cellulare',
                'short_title' => 'Rigenerazione',
                'description' => 'Protocolli avanzati per rigenerazione cutanea, qualità della pelle, rughe, cicatrici e densità cutanea.',
                'order' => 1,
                'visible' => true
            ],
            [
                'id' => 'peeling-rinnovamento',
                'title' => 'Peeling clinici & Rinnovamento cutaneo',
                'short_title' => 'Peeling',
                'description' => 'Peeling professionali e trattamenti di rinnovamento per macchie, acne, pori, texture e luminosità.',
                'order' => 2,
                'visible' => true
            ],
            [
                'id' => 'manuali-massaggi',
                'title' => 'Trattamenti manuali & Massaggi',
                'short_title' => 'Manuali & Massaggi',
                'description' => 'Trattamenti manuali e massaggi viso per pulizia, modellamento, idratazione e cura personalizzata.',
                'order' => 3,
                'visible' => true
            ],
            [
                'id' => 'tecnologie-dermatologiche',
                'title' => 'Tecnologie dermatologiche avanzate',
                'short_title' => 'Tecnologie',
                'description' => 'Tecnologie professionali per analisi, idratazione, lifting, radiofrequenza, plasma freddo e trattamenti mirati.',
                'order' => 4,
                'visible' => true
            ]
        ],
        'items' => [
            // Categoria 1
            [
                'id' => 'terapia-peptidica-microneedling',
                'category_id' => 'rigenerazione-biohacking',
                'name' => 'Terapia Peptidica Avanzata & Microneedling',
                'duration' => '80 min.',
                'price_type' => 'fixed',
                'price_fixed' => 205,
                'price_min' => '',
                'price_max' => '',
                'price_label' => 'CHF 205.00',
                'description' => 'Infiltrazioni con micro-aghi di peptidi biomimetici (GHK-Cu), acido ialuronico e vitamine per rigenerazione profonda, rughe e cicatrici.',
                'featured' => true,
                'visible' => true,
                'order' => 1,
                'variants' => []
            ],
            [
                'id' => 'esosomi-nidosomi-celltermi',
                'category_id' => 'rigenerazione-biohacking',
                'name' => 'Trattamento agli Esosomi e Nidosomi (Celltermi Revive NX)',
                'duration' => '75 min.',
                'price_type' => 'fixed',
                'price_fixed' => 220,
                'price_min' => '',
                'price_max' => '',
                'price_label' => 'CHF 220.00',
                'description' => 'Biohacking biotecnologico d\'avanguardia per la rigenerazione cellulare profonda e il ripristino della densità cutanea.',
                'featured' => false,
                'visible' => true,
                'order' => 2,
                'variants' => []
            ],
            
            // Categoria 2
            [
                'id' => 'green-peel-classic',
                'category_id' => 'peeling-rinnovamento',
                'name' => 'GREEN PEEL Classic (Dott. Schrammek)',
                'duration' => '',
                'price_type' => 'fixed',
                'price_fixed' => 415,
                'price_min' => '',
                'price_max' => '',
                'price_label' => 'CHF 415.00',
                'description' => 'Peeling intensivo alle erbe per rigenerazione, ringiovanimento, rimozione di macchie senili, acne e smagliature.',
                'featured' => true,
                'visible' => true,
                'order' => 1,
                'variants' => []
            ],
            [
                'id' => 'green-peel-energy',
                'category_id' => 'peeling-rinnovamento',
                'name' => 'GREEN PEEL Energy (Dott. Schrammek)',
                'duration' => '90 min.',
                'price_type' => 'fixed',
                'price_fixed' => 195,
                'price_min' => '',
                'price_max' => '',
                'price_label' => 'CHF 195.00',
                'description' => 'Prevenzione dell\'invecchiamento cutaneo e rimozione di pigmentazioni solari.',
                'featured' => false,
                'visible' => true,
                'order' => 2,
                'variants' => []
            ],
            [
                'id' => 'green-peel-fresh-up',
                'category_id' => 'peeling-rinnovamento',
                'name' => 'GREEN PEEL Fresh Up (Dott. Schrammek)',
                'duration' => '90 min.',
                'price_type' => 'fixed',
                'price_fixed' => 135,
                'price_min' => '',
                'price_max' => '',
                'price_label' => 'CHF 135.00',
                'description' => 'Freschezza, metabolismo attivo ed idratazione profonda.',
                'featured' => false,
                'visible' => true,
                'order' => 3,
                'variants' => []
            ],
            [
                'id' => 'cosmelan-mesoestetic',
                'category_id' => 'peeling-rinnovamento',
                'name' => 'Cosmelan (Mesoestetic)',
                'duration' => '',
                'price_type' => 'fixed',
                'price_fixed' => 990,
                'price_min' => '',
                'price_max' => '',
                'price_label' => 'CHF 990.00',
                'description' => 'Peeling potente anti-macchie.',
                'featured' => true,
                'visible' => true,
                'order' => 4,
                'variants' => []
            ],
            [
                'id' => 'acne-peel-system',
                'category_id' => 'peeling-rinnovamento',
                'name' => 'Acne Peel System (Mesoestetic)',
                'duration' => '45 min.',
                'price_type' => 'from',
                'price_fixed' => '',
                'price_min' => 125,
                'price_max' => '',
                'price_label' => 'da CHF 125.00',
                'description' => 'Cura efficace contro l\'acne giovanile e tardiva.',
                'featured' => false,
                'visible' => true,
                'order' => 5,
                'variants' => []
            ],
            [
                'id' => 'dermapeels-peeling-chimici',
                'category_id' => 'peeling-rinnovamento',
                'name' => 'Dermapeels / Peeling Chimici Mirati (Mesoestetic)',
                'duration' => '60 min.',
                'price_type' => 'from',
                'price_fixed' => '',
                'price_min' => 115,
                'price_max' => '',
                'price_label' => 'da CHF 115.00',
                'description' => 'Acido glicolico, salicilico, mandelico, lattico, TCA per ringiovanimento, depigmentazione, pori allargati, acne e segni dell\'acne.',
                'featured' => false,
                'visible' => true,
                'order' => 6,
                'variants' => []
            ],
            [
                'id' => 'prx-t33-prx-plus',
                'category_id' => 'peeling-rinnovamento',
                'name' => 'PRX-T33 / PRX-PLUS',
                'duration' => '60 min.',
                'price_type' => 'from',
                'price_fixed' => '',
                'price_min' => 135,
                'price_max' => '',
                'price_label' => 'da CHF 135.00',
                'description' => 'Anti-age, macchie, pelle sottile e rugosa, pori ostruiti e acne.',
                'featured' => false,
                'visible' => true,
                'order' => 7,
                'variants' => []
            ],
            
            // Categoria 3
            [
                'id' => 'pulizia-manuale-pelle',
                'category_id' => 'manuali-massaggi',
                'name' => 'La Pulizia Manuale della Pelle',
                'duration' => '75 min.',
                'price_type' => 'from',
                'price_fixed' => '',
                'price_min' => 105,
                'price_max' => '',
                'price_label' => 'da CHF 105.00',
                'description' => 'Effettuata con prodotti adatti al vostro tipo di pelle.',
                'featured' => true,
                'visible' => true,
                'order' => 1,
                'variants' => []
            ],
            [
                'id' => 'massaggio-giapponese-cobidu',
                'category_id' => 'manuali-massaggi',
                'name' => 'Massaggio Giapponese Modellante COBIDU',
                'duration' => '40 min.',
                'price_type' => 'fixed',
                'price_fixed' => 65,
                'price_min' => '',
                'price_max' => '',
                'price_label' => 'CHF 65.00',
                'description' => 'Con la maschera liftante o idratante.',
                'featured' => false,
                'visible' => true,
                'order' => 2,
                'variants' => []
            ],
            
            // Categoria 4
            [
                'id' => 'analisi-pelle-skin-solutionist',
                'category_id' => 'tecnologie-dermatologiche',
                'name' => 'Analisi della Pelle con SKIN SOLUTIONIST',
                'duration' => '35 min.',
                'price_type' => 'fixed',
                'price_fixed' => 50,
                'price_min' => '',
                'price_max' => '',
                'price_label' => 'CHF 50.00',
                'description' => 'Analisi di idratazione, collagene, pori, sensibilità, capillari, acne ecc.',
                'featured' => false,
                'visible' => true,
                'order' => 1,
                'variants' => []
            ],
            [
                'id' => 'hydrofacial-synergy',
                'category_id' => 'tecnologie-dermatologiche',
                'name' => 'Hydrofacial (Synergy+)',
                'duration' => '50 min.',
                'price_type' => 'from',
                'price_fixed' => '',
                'price_min' => 115,
                'price_max' => '',
                'price_label' => 'da CHF 115.00',
                'description' => 'Pulizia viso anti-age profonda con vacuum.',
                'featured' => false,
                'visible' => true,
                'order' => 2,
                'variants' => []
            ],
            [
                'id' => 'ice-fire-is-clinical',
                'category_id' => 'tecnologie-dermatologiche',
                'name' => 'Ice & Fire (iS Clinical)',
                'duration' => '75 min.',
                'price_type' => 'fixed',
                'price_fixed' => 145,
                'price_min' => '',
                'price_max' => '',
                'price_label' => 'CHF 145.00',
                'description' => 'Con microcorrenti — ringiovanimento della pelle, lifting.',
                'featured' => false,
                'visible' => true,
                'order' => 3,
                'variants' => []
            ],
            [
                'id' => 'radiofrequenza-monopolare-bipolare',
                'category_id' => 'tecnologie-dermatologiche',
                'name' => 'Radiofrequenza Monopolare / Bipolare (CoaxMed)',
                'duration' => '75 min.',
                'price_type' => 'fixed',
                'price_fixed' => 135,
                'price_min' => '',
                'price_max' => '',
                'price_label' => 'CHF 135.00',
                'description' => 'Drenaggio, doppio mento, rughe, rilassamento cutaneo, pori, acne, iperpigmentazione.',
                'featured' => false,
                'visible' => true,
                'order' => 4,
                'variants' => []
            ],
            [
                'id' => 'radiofrequenza-frazionata-microaghi',
                'category_id' => 'tecnologie-dermatologiche',
                'name' => 'Radiofrequenza Frazionata con Microaghi (CoaxMed)',
                'duration' => '75 min.',
                'price_type' => 'fixed',
                'price_fixed' => 165,
                'price_min' => '',
                'price_max' => '',
                'price_label' => 'CHF 165.00',
                'description' => 'Rigenerazione e ristrutturazione profonda della pelle.',
                'featured' => false,
                'visible' => true,
                'order' => 5,
                'variants' => []
            ],
            [
                'id' => 'smas-lifting',
                'category_id' => 'tecnologie-dermatologiche',
                'name' => 'SMAS-Lifting',
                'duration' => '',
                'price_type' => 'range',
                'price_fixed' => '',
                'price_min' => 220,
                'price_max' => 550,
                'price_label' => 'da CHF 220.00 a CHF 550.00',
                'description' => 'Ultrasuono focalizzato: effetto lifting non chirurgico per contorno del viso, collo, sopracciglia ecc.',
                'featured' => true,
                'visible' => true,
                'order' => 6,
                'variants' => [
                    ['id' => 'var-1', 'name' => 'Contorno viso', 'duration' => '60 min.', 'price_fixed' => 220, 'price_label' => 'CHF 220.00', 'order' => 1, 'visible' => true],
                    ['id' => 'var-2', 'name' => 'Contorno viso + collo', 'duration' => '70 min.', 'price_fixed' => 320, 'price_label' => 'CHF 320.00', 'order' => 2, 'visible' => true],
                    ['id' => 'var-3', 'name' => 'Viso + collo', 'duration' => '90 min.', 'price_fixed' => 400, 'price_label' => 'CHF 400.00', 'order' => 3, 'visible' => true],
                    ['id' => 'var-4', 'name' => 'Collo + décolleté', 'duration' => '30 min.', 'price_fixed' => 220, 'price_label' => 'CHF 220.00', 'order' => 4, 'visible' => true],
                    ['id' => 'var-5', 'name' => 'Collo + décolleté', 'duration' => '70 min.', 'price_fixed' => 320, 'price_label' => 'CHF 320.00', 'order' => 5, 'visible' => true],
                    ['id' => 'var-6', 'name' => 'Fulle face', 'duration' => '120 min.', 'price_fixed' => 550, 'price_label' => 'CHF 550.00', 'order' => 6, 'visible' => true]
                ]
            ],
            [
                'id' => 'elettrocoagulazione',
                'category_id' => 'tecnologie-dermatologiche',
                'name' => 'Elettrocoagulazione',
                'duration' => '1 min.',
                'price_type' => 'fixed',
                'price_fixed' => 3,
                'price_min' => '',
                'price_max' => '',
                'price_label' => 'CHF 3.00',
                'description' => 'Anomalie della pelle: angiomi, capillari, papilomi ecc.',
                'featured' => false,
                'visible' => true,
                'order' => 7,
                'variants' => []
            ],
            [
                'id' => 'cold-plasma-cnc',
                'category_id' => 'tecnologie-dermatologiche',
                'name' => 'Cold Plasma / Plasma Freddo (CNC)',
                'duration' => '70 min.',
                'price_type' => 'fixed',
                'price_fixed' => 115,
                'price_min' => '',
                'price_max' => '',
                'price_label' => 'CHF 115.00',
                'description' => 'Idratazione, anti-age, cura dell\'acne, acne rosacea, couperose, macchie ecc. Cura delle anomalie della pelle: verruche, funghi, herpes, micosi ecc. 10 min. — CHF 20.00 / 1 min. — CHF 3.00.',
                'featured' => false,
                'visible' => true,
                'order' => 8,
                'variants' => [
                    ['id' => 'var-p-1', 'name' => 'Cura anomalie della pelle', 'duration' => '10 min.', 'price_fixed' => 20, 'price_label' => 'CHF 20.00', 'order' => 1, 'visible' => true],
                    ['id' => 'var-p-2', 'name' => 'Cura anomalie della pelle', 'duration' => '1 min.', 'price_fixed' => 3, 'price_label' => 'CHF 3.00', 'order' => 2, 'visible' => true]
                ]
            ],
            [
                'id' => 'hidro-elettroporazione-hd-m20',
                'category_id' => 'tecnologie-dermatologiche',
                'name' => 'Hidro-Elettroporazione HD-M20 (X-PRO Technology)',
                'duration' => '60 min.',
                'price_type' => 'from',
                'price_fixed' => '',
                'price_min' => 125,
                'price_max' => '',
                'price_label' => 'da CHF 125.00',
                'description' => 'Nutrimento e idratazione, produzione di collagene, lifting, rughe, lassità cutanea ecc.',
                'featured' => false,
                'visible' => true,
                'order' => 9,
                'variants' => []
            ],
            [
                'id' => 'oxygeneo-pologen',
                'category_id' => 'tecnologie-dermatologiche',
                'name' => 'Oxygeneo+ (Pologen)',
                'duration' => '50 min.',
                'price_type' => 'from',
                'price_fixed' => '',
                'price_min' => 115,
                'price_max' => '',
                'price_label' => 'da CHF 115.00',
                'description' => 'Detox, Anti Age, Illuminante, Idratante, indicato anche per pelle grassa con pori allargati.',
                'featured' => false,
                'visible' => true,
                'order' => 10,
                'variants' => []
            ]
        ]
    ];
}

/**
 * Ottiene i dati sicuri
 */
function synergy_get_price_list_data() {
    $data = get_option('synergy_price_list_data');
    $default = synergy_price_list_default_data();
    
    if (empty($data) || !is_array($data)) {
        return $default;
    }
    
    // Merge settings
    if (empty($data['settings']) || !is_array($data['settings'])) {
        $data['settings'] = $default['settings'];
    } else {
        $data['settings'] = wp_parse_args($data['settings'], $default['settings']);
    }
    
    // Assicura array
    if (empty($data['categories']) || !is_array($data['categories'])) $data['categories'] = [];
    if (empty($data['items']) || !is_array($data['items'])) $data['items'] = [];
    
    return $data;
}

/**
 * Sanitizza e salva i dati dal form POST
 */
function synergy_save_price_list_data() {
    if (!isset($_POST['synergy_price_list_nonce']) || !wp_verify_nonce($_POST['synergy_price_list_nonce'], 'synergy_save_price_list')) {
        return;
    }
    
    if (!current_user_can('edit_pages')) {
        return;
    }

    if (isset($_POST['action']) && $_POST['action'] === 'restore_pdf') {
        update_option('synergy_price_list_data', synergy_price_list_default_data());
        add_settings_error('synergy_price_list', 'synergy_price_list_restored', 'Listino ripristinato con i dati del PDF.', 'success');
        return;
    }

    if (isset($_POST['action']) && $_POST['action'] === 'save_list' && isset($_POST['synergy_price_list_data'])) {
        $raw = $_POST['synergy_price_list_data'];
        $clean = [
            'settings' => [],
            'categories' => [],
            'items' => []
        ];
        
        // Settings
        $raw_set = $raw['settings'] ?? [];
        $clean['settings'] = [
            'enabled' => isset($raw_set['enabled']) ? true : false,
            'eyebrow' => sanitize_text_field($raw_set['eyebrow'] ?? ''),
            'title' => sanitize_text_field($raw_set['title'] ?? ''),
            'subtitle' => sanitize_textarea_field($raw_set['subtitle'] ?? ''),
            'note' => sanitize_textarea_field($raw_set['note'] ?? ''),
            'cta_label' => sanitize_text_field($raw_set['cta_label'] ?? ''),
            'cta_url' => esc_url_raw($raw_set['cta_url'] ?? ''),
            'max_items' => intval($raw_set['max_items'] ?? 8),
            'show_featured_first' => isset($raw_set['show_featured_first']) ? true : false,
            'show_load_more' => isset($raw_set['show_load_more']) ? true : false
        ];
        
        // Categories
        if (!empty($raw['categories']) && is_array($raw['categories'])) {
            foreach ($raw['categories'] as $cat) {
                if (empty($cat['id'])) continue;
                $clean['categories'][] = [
                    'id' => sanitize_text_field($cat['id']),
                    'title' => sanitize_text_field($cat['title'] ?? ''),
                    'short_title' => sanitize_text_field($cat['short_title'] ?? ''),
                    'description' => sanitize_textarea_field($cat['description'] ?? ''),
                    'order' => intval($cat['order'] ?? 0),
                    'visible' => isset($cat['visible']) ? true : false
                ];
            }
            usort($clean['categories'], function($a, $b) { return $a['order'] <=> $b['order']; });
        }
        
        // Items
        if (!empty($raw['items']) && is_array($raw['items'])) {
            foreach ($raw['items'] as $item) {
                if (empty($item['id'])) continue;
                
                $clean_item = [
                    'id' => sanitize_text_field($item['id']),
                    'category_id' => sanitize_text_field($item['category_id'] ?? ''),
                    'name' => sanitize_text_field($item['name'] ?? ''),
                    'duration' => sanitize_text_field($item['duration'] ?? ''),
                    'price_type' => sanitize_text_field($item['price_type'] ?? 'fixed'),
                    'price_fixed' => sanitize_text_field($item['price_fixed'] ?? ''),
                    'price_min' => sanitize_text_field($item['price_min'] ?? ''),
                    'price_max' => sanitize_text_field($item['price_max'] ?? ''),
                    'price_label' => sanitize_text_field($item['price_label'] ?? ''),
                    'description' => sanitize_textarea_field($item['description'] ?? ''),
                    'featured' => isset($item['featured']) ? true : false,
                    'visible' => isset($item['visible']) ? true : false,
                    'order' => intval($item['order'] ?? 0),
                    'variants' => []
                ];
                
                if (!empty($item['variants']) && is_array($item['variants'])) {
                    foreach ($item['variants'] as $var) {
                        if (empty($var['id'])) continue;
                        $clean_item['variants'][] = [
                            'id' => sanitize_text_field($var['id']),
                            'name' => sanitize_text_field($var['name'] ?? ''),
                            'duration' => sanitize_text_field($var['duration'] ?? ''),
                            'price_fixed' => sanitize_text_field($var['price_fixed'] ?? ''),
                            'price_label' => sanitize_text_field($var['price_label'] ?? ''),
                            'order' => intval($var['order'] ?? 0),
                            'visible' => isset($var['visible']) ? true : false
                        ];
                    }
                    usort($clean_item['variants'], function($a, $b) { return $a['order'] <=> $b['order']; });
                }
                
                $clean['items'][] = $clean_item;
            }
            usort($clean['items'], function($a, $b) { return $a['order'] <=> $b['order']; });
        }
        
        update_option('synergy_price_list_data', $clean);
        add_settings_error('synergy_price_list', 'synergy_price_list_saved', 'Modifiche salvate con successo.', 'success');
    }
}

/**
 * Hook admin init per salvare
 */
add_action('admin_init', 'synergy_save_price_list_data');

/**
 * Registra pagina admin
 */
add_action('admin_menu', 'synergy_register_price_list_admin_page', 100);
function synergy_register_price_list_admin_page() {
    add_submenu_page(
        'ticinoweb-cms',
        'Listino Prezzi Viso',
        'Listino Prezzi',
        'edit_pages',
        'synergy-price-list',
        'synergy_render_price_list_admin_page'
    );
}

/**
 * Render pagina Admin
 */
function synergy_render_price_list_admin_page() {
    if (!current_user_can('edit_pages')) {
        return;
    }
    
    $data = synergy_get_price_list_data();
    $settings = $data['settings'];
    $categories = $data['categories'];
    $items = $data['items'];
    
    $active_cats = count(array_filter($categories, function($c) { return !empty($c['visible']); }));
    $visible_items = count(array_filter($items, function($i) { return !empty($i['visible']); }));
    
    $min_price = PHP_INT_MAX;
    $max_price = 0;
    foreach($items as $i) {
        if (empty($i['visible'])) continue;
        $pf = floatval(preg_replace('/[^0-9.]/', '', $i['price_fixed'] ?? 0));
        $pmin = floatval(preg_replace('/[^0-9.]/', '', $i['price_min'] ?? 0));
        $pmax = floatval(preg_replace('/[^0-9.]/', '', $i['price_max'] ?? 0));
        
        if ($pf > 0) { $min_price = min($min_price, $pf); $max_price = max($max_price, $pf); }
        if ($pmin > 0) { $min_price = min($min_price, $pmin); $max_price = max($max_price, $pmin); }
        if ($pmax > 0) { $min_price = min($min_price, $pmax); $max_price = max($max_price, $pmax); }
        
        if (!empty($i['variants'])) {
            foreach($i['variants'] as $v) {
                if(empty($v['visible'])) continue;
                $vpf = floatval(preg_replace('/[^0-9.]/', '', $v['price_fixed'] ?? 0));
                if ($vpf > 0) { $min_price = min($min_price, $vpf); $max_price = max($max_price, $vpf); }
            }
        }
    }
    $price_range = ($min_price !== PHP_INT_MAX && $max_price > 0) ? 'CHF ' . number_format($min_price, 2, '.', '') . ' - CHF ' . number_format($max_price, 2, '.', '') : '-';
    
    settings_errors('synergy_price_list');
    ?>
    <div class="wrap sy-wrap">
        <h1 class="wp-heading-inline">Listino Prezzi Viso</h1>
        <hr class="wp-header-end">
        
        <form method="post" action="<?php echo esc_url(admin_url('admin.php?page=synergy-price-list')); ?>" id="synergy-price-list-form">
            <?php wp_nonce_field('synergy_save_price_list', 'synergy_price_list_nonce'); ?>
            <input type="hidden" name="action" id="synergy-action" value="save_list">
            
            <div class="sy-header-actions">
                <button type="button" class="button" onclick="if(confirm('Vuoi davvero ripristinare il listino dal PDF? Tutte le modifiche andranno perse!')) { document.getElementById('synergy-action').value='restore_pdf'; document.getElementById('synergy-price-list-form').submit(); }">Ripristina listino dal PDF</button>
                <a href="<?php echo esc_url(home_url('/#listino-prezzi')); ?>" target="_blank" class="button">Anteprima Home &rarr;</a>
                <button type="submit" class="button button-primary button-hero">Salva modifiche</button>
            </div>
            
            <div class="sy-stats-grid">
                <div class="sy-stat-card">
                    <div class="sy-stat-label">CATEGORIE ATTIVE</div>
                    <div class="sy-stat-value"><?php echo $active_cats; ?></div>
                </div>
                <div class="sy-stat-card">
                    <div class="sy-stat-label">TRATTAMENTI VISIBILI</div>
                    <div class="sy-stat-value"><?php echo $visible_items; ?></div>
                </div>
                <div class="sy-stat-card">
                    <div class="sy-stat-label">FASCIA PREZZO STIMATA</div>
                    <div class="sy-stat-value"><?php echo $price_range; ?></div>
                </div>
            </div>
            
            <!-- IMPOSTAZIONI -->
            <div class="sy-card">
                <div class="sy-card-header">
                    <h2>Impostazioni sezione</h2>
                    <label class="sy-toggle">
                        <input type="checkbox" name="synergy_price_list_data[settings][enabled]" value="1" <?php checked($settings['enabled']); ?>> Sezione attiva in Home
                    </label>
                </div>
                <div class="sy-card-body">
                    <div class="sy-grid-2">
                        <div class="sy-form-group">
                            <label>Eyebrow</label>
                            <input type="text" class="regular-text w100" name="synergy_price_list_data[settings][eyebrow]" value="<?php echo esc_attr($settings['eyebrow']); ?>">
                        </div>
                        <div class="sy-form-group">
                            <label>Titolo principale</label>
                            <input type="text" class="regular-text w100" name="synergy_price_list_data[settings][title]" value="<?php echo esc_attr($settings['title']); ?>">
                        </div>
                    </div>
                    <div class="sy-form-group">
                        <label>Sottotitolo</label>
                        <textarea class="large-text" rows="2" name="synergy_price_list_data[settings][subtitle]"><?php echo esc_textarea($settings['subtitle']); ?></textarea>
                    </div>
                    <div class="sy-form-group">
                        <label>Nota sotto il listino</label>
                        <textarea class="large-text" rows="2" name="synergy_price_list_data[settings][note]"><?php echo esc_textarea($settings['note']); ?></textarea>
                    </div>
                    <div class="sy-grid-2">
                        <div class="sy-form-group">
                            <label>Testo pulsante CTA</label>
                            <input type="text" class="regular-text w100" name="synergy_price_list_data[settings][cta_label]" value="<?php echo esc_attr($settings['cta_label']); ?>">
                        </div>
                        <div class="sy-form-group">
                            <label>Link CTA</label>
                            <input type="text" class="regular-text w100" name="synergy_price_list_data[settings][cta_url]" value="<?php echo esc_attr($settings['cta_url']); ?>">
                        </div>
                    </div>
                    <div class="sy-grid-3" style="align-items: center; margin-top:20px;">
                        <div class="sy-form-group">
                            <label>Trattamenti visibili in Home (prima di Mostra tutti)</label>
                            <input type="number" class="small-text" name="synergy_price_list_data[settings][max_items]" value="<?php echo esc_attr($settings['max_items']); ?>" min="1">
                        </div>
                        <div class="sy-form-group">
                            <label><input type="checkbox" name="synergy_price_list_data[settings][show_featured_first]" value="1" <?php checked($settings['show_featured_first']); ?>> Mostra "In evidenza" per primi</label>
                        </div>
                        <div class="sy-form-group">
                            <label><input type="checkbox" name="synergy_price_list_data[settings][show_load_more]" value="1" <?php checked($settings['show_load_more']); ?>> Mostra pulsante "Mostra tutto"</label>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- CATEGORIE -->
            <div class="sy-section-header">
                <h2>Categorie Listino</h2>
                <button type="button" class="button" onclick="syAddCategory()">+ Aggiungi categoria</button>
            </div>
            
            <div id="sy-categories-container">
                <?php 
                $c_idx = 0;
                foreach ($categories as $cat): 
                ?>
                <div class="sy-accordion sy-category-accordion" data-index="<?php echo $c_idx; ?>">
                    <div class="sy-accordion-header" onclick="syToggleAccordion(this)">
                        <div class="sy-acc-title">
                            <span class="dashicons dashicons-menu drag-handle"></span>
                            <strong><?php echo esc_html($cat['title'] ?: 'Nuova Categoria'); ?></strong>
                        </div>
                        <div class="sy-acc-actions">
                            <span class="badge <?php echo $cat['visible'] ? 'badge-green' : 'badge-red'; ?>"><?php echo $cat['visible'] ? 'Visibile' : 'Nascosta'; ?></span>
                            <button type="button" class="button button-small" onclick="event.stopPropagation(); syRemoveAccordion(this, 'Vuoi eliminare questa categoria?')">Elimina</button>
                            <span class="dashicons dashicons-arrow-down-alt2 toggle-icon"></span>
                        </div>
                    </div>
                    <div class="sy-accordion-body">
                        <input type="hidden" name="synergy_price_list_data[categories][<?php echo $c_idx; ?>][id]" value="<?php echo esc_attr($cat['id']); ?>" class="cat-id">
                        <div class="sy-grid-3">
                            <div class="sy-form-group">
                                <label>Ordine</label>
                                <input type="number" name="synergy_price_list_data[categories][<?php echo $c_idx; ?>][order]" value="<?php echo esc_attr($cat['order']); ?>" class="small-text order-input">
                            </div>
                            <div class="sy-form-group">
                                <label><br><input type="checkbox" name="synergy_price_list_data[categories][<?php echo $c_idx; ?>][visible]" value="1" <?php checked($cat['visible']); ?>> Visibile in Home</label>
                            </div>
                        </div>
                        <div class="sy-grid-2">
                            <div class="sy-form-group">
                                <label>Titolo Categoria</label>
                                <input type="text" class="regular-text w100" name="synergy_price_list_data[categories][<?php echo $c_idx; ?>][title]" value="<?php echo esc_attr($cat['title']); ?>" oninput="syUpdateAccTitle(this)">
                            </div>
                            <div class="sy-form-group">
                                <label>Titolo Corto (Tab Home)</label>
                                <input type="text" class="regular-text w100" name="synergy_price_list_data[categories][<?php echo $c_idx; ?>][short_title]" value="<?php echo esc_attr($cat['short_title']); ?>">
                            </div>
                        </div>
                        <div class="sy-form-group">
                            <label>Descrizione Categoria</label>
                            <textarea class="large-text" rows="2" name="synergy_price_list_data[categories][<?php echo $c_idx; ?>][description]"><?php echo esc_textarea($cat['description']); ?></textarea>
                        </div>
                    </div>
                </div>
                <?php $c_idx++; endforeach; ?>
            </div>
            
            <!-- TRATTAMENTI -->
            <div class="sy-section-header" style="margin-top: 40px;">
                <h2>Trattamenti Listino</h2>
                <button type="button" class="button" onclick="syAddItem()">+ Aggiungi trattamento</button>
            </div>
            
            <div id="sy-items-container">
                <?php 
                $i_idx = 0;
                $v_idx = 0;
                foreach ($items as $item): 
                ?>
                <div class="sy-accordion sy-item-accordion" data-index="<?php echo $i_idx; ?>">
                    <div class="sy-accordion-header" onclick="syToggleAccordion(this)">
                        <div class="sy-acc-title">
                            <span class="dashicons dashicons-menu drag-handle"></span>
                            <strong><?php echo esc_html($item['name'] ?: 'Nuovo Trattamento'); ?></strong>
                            <span style="color:#777; font-size:12px; margin-left:10px;">[<?php echo esc_html($item['price_label']); ?>]</span>
                        </div>
                        <div class="sy-acc-actions">
                            <?php if(!empty($item['featured'])) echo '<span class="badge badge-blue">Evidenza</span>'; ?>
                            <span class="badge <?php echo $item['visible'] ? 'badge-green' : 'badge-red'; ?>"><?php echo $item['visible'] ? 'Visibile' : 'Nascosto'; ?></span>
                            <button type="button" class="button button-small" onclick="event.stopPropagation(); syDuplicateItem(this)">Duplica</button>
                            <button type="button" class="button button-small" onclick="event.stopPropagation(); syRemoveAccordion(this, 'Vuoi eliminare questo trattamento?')">Elimina</button>
                            <span class="dashicons dashicons-arrow-down-alt2 toggle-icon"></span>
                        </div>
                    </div>
                    <div class="sy-accordion-body">
                        <input type="hidden" name="synergy_price_list_data[items][<?php echo $i_idx; ?>][id]" value="<?php echo esc_attr($item['id']); ?>" class="item-id">
                        
                        <div class="sy-grid-3">
                            <div class="sy-form-group">
                                <label>Categoria</label>
                                <select name="synergy_price_list_data[items][<?php echo $i_idx; ?>][category_id]" class="w100 cat-select">
                                    <option value="">-- Seleziona Categoria --</option>
                                    <?php foreach($categories as $c) {
                                        echo '<option value="'.esc_attr($c['id']).'" '.selected($item['category_id'], $c['id'], false).'>'.esc_html($c['title']).'</option>';
                                    } ?>
                                </select>
                            </div>
                            <div class="sy-form-group">
                                <label>Ordine Globale</label>
                                <input type="number" name="synergy_price_list_data[items][<?php echo $i_idx; ?>][order]" value="<?php echo esc_attr($item['order']); ?>" class="small-text order-input">
                            </div>
                            <div class="sy-form-group" style="padding-top:20px;">
                                <label style="display:inline-block; margin-right:15px;"><input type="checkbox" name="synergy_price_list_data[items][<?php echo $i_idx; ?>][visible]" value="1" <?php checked($item['visible']); ?>> Visibile</label>
                                <label style="display:inline-block;"><input type="checkbox" name="synergy_price_list_data[items][<?php echo $i_idx; ?>][featured]" value="1" <?php checked($item['featured']); ?>> In Evidenza</label>
                            </div>
                        </div>
                        
                        <div class="sy-grid-2">
                            <div class="sy-form-group">
                                <label>Nome Trattamento</label>
                                <input type="text" class="regular-text w100" name="synergy_price_list_data[items][<?php echo $i_idx; ?>][name]" value="<?php echo esc_attr($item['name']); ?>" oninput="syUpdateAccTitle(this)">
                            </div>
                            <div class="sy-form-group">
                                <label>Durata (es. 60 min.)</label>
                                <input type="text" class="regular-text w100" name="synergy_price_list_data[items][<?php echo $i_idx; ?>][duration]" value="<?php echo esc_attr($item['duration']); ?>">
                            </div>
                        </div>
                        
                        <div class="sy-form-group">
                            <label>Descrizione Trattamento</label>
                            <textarea class="large-text" rows="2" name="synergy_price_list_data[items][<?php echo $i_idx; ?>][description]"><?php echo esc_textarea($item['description']); ?></textarea>
                        </div>
                        
                        <hr style="margin:20px 0; border:0; border-top:1px solid #ddd;">
                        
                        <div class="sy-grid-4">
                            <div class="sy-form-group">
                                <label>Tipo Prezzo</label>
                                <select name="synergy_price_list_data[items][<?php echo $i_idx; ?>][price_type]" class="w100" onchange="syUpdatePriceFields(this)">
                                    <option value="fixed" <?php selected($item['price_type'], 'fixed'); ?>>Fisso</option>
                                    <option value="from" <?php selected($item['price_type'], 'from'); ?>>A partire da</option>
                                    <option value="range" <?php selected($item['price_type'], 'range'); ?>>Range (Min-Max)</option>
                                    <option value="custom" <?php selected($item['price_type'], 'custom'); ?>>Testo Personalizzato</option>
                                </select>
                            </div>
                            <div class="sy-form-group p-fixed">
                                <label>Prezzo Fisso (solo numero)</label>
                                <input type="number" step="0.01" class="w100" name="synergy_price_list_data[items][<?php echo $i_idx; ?>][price_fixed]" value="<?php echo esc_attr($item['price_fixed']); ?>">
                            </div>
                            <div class="sy-form-group p-min">
                                <label>Prezzo Minimo</label>
                                <input type="number" step="0.01" class="w100" name="synergy_price_list_data[items][<?php echo $i_idx; ?>][price_min]" value="<?php echo esc_attr($item['price_min']); ?>">
                            </div>
                            <div class="sy-form-group p-max">
                                <label>Prezzo Massimo</label>
                                <input type="number" step="0.01" class="w100" name="synergy_price_list_data[items][<?php echo $i_idx; ?>][price_max]" value="<?php echo esc_attr($item['price_max']); ?>">
                            </div>
                        </div>
                        
                        <div class="sy-form-group">
                            <label>Label Prezzo Finale (mostrato nel frontend)</label>
                            <input type="text" class="regular-text w100" name="synergy_price_list_data[items][<?php echo $i_idx; ?>][price_label]" value="<?php echo esc_attr($item['price_label']); ?>" placeholder="es. CHF 100.00" oninput="syUpdateAccPrice(this)">
                        </div>
                        
                        <!-- VARIANTI -->
                        <div class="sy-variants-section" style="margin-top:20px; background:#f9f9f9; padding:15px; border:1px solid #ddd;">
                            <h4>Varianti (opzionali)</h4>
                            <div class="sy-variants-container">
                                <?php if(!empty($item['variants'])) { foreach($item['variants'] as $var) { ?>
                                    <div class="sy-variant-row" style="display:flex; gap:10px; margin-bottom:10px; align-items:flex-end;">
                                        <input type="hidden" name="synergy_price_list_data[items][<?php echo $i_idx; ?>][variants][<?php echo $v_idx; ?>][id]" value="<?php echo esc_attr($var['id']); ?>">
                                        <div style="flex:2;">
                                            <label style="font-size:11px;">Nome variante</label>
                                            <input type="text" class="w100" name="synergy_price_list_data[items][<?php echo $i_idx; ?>][variants][<?php echo $v_idx; ?>][name]" value="<?php echo esc_attr($var['name']); ?>">
                                        </div>
                                        <div style="flex:1;">
                                            <label style="font-size:11px;">Durata</label>
                                            <input type="text" class="w100" name="synergy_price_list_data[items][<?php echo $i_idx; ?>][variants][<?php echo $v_idx; ?>][duration]" value="<?php echo esc_attr($var['duration']); ?>">
                                        </div>
                                        <div style="flex:1;">
                                            <label style="font-size:11px;">Prezzo fisso</label>
                                            <input type="number" step="0.01" class="w100" name="synergy_price_list_data[items][<?php echo $i_idx; ?>][variants][<?php echo $v_idx; ?>][price_fixed]" value="<?php echo esc_attr($var['price_fixed']); ?>">
                                        </div>
                                        <div style="flex:1.5;">
                                            <label style="font-size:11px;">Label (mostrato)</label>
                                            <input type="text" class="w100" name="synergy_price_list_data[items][<?php echo $i_idx; ?>][variants][<?php echo $v_idx; ?>][price_label]" value="<?php echo esc_attr($var['price_label']); ?>">
                                        </div>
                                        <div style="flex:0.5;">
                                            <label style="font-size:11px;">Ordine</label>
                                            <input type="number" class="w100" name="synergy_price_list_data[items][<?php echo $i_idx; ?>][variants][<?php echo $v_idx; ?>][order]" value="<?php echo esc_attr($var['order']); ?>">
                                        </div>
                                        <div>
                                            <label style="font-size:11px; display:block;">Visibile</label>
                                            <input type="checkbox" name="synergy_price_list_data[items][<?php echo $i_idx; ?>][variants][<?php echo $v_idx; ?>][visible]" value="1" <?php checked($var['visible']); ?>>
                                        </div>
                                        <div>
                                            <button type="button" class="button" onclick="syRemoveVariantRow(this)">&times;</button>
                                        </div>
                                    </div>
                                <?php $v_idx++; } } ?>
                            </div>
                            <button type="button" class="button button-small" onclick="syAddVariant(this, <?php echo $i_idx; ?>)">+ Aggiungi variante</button>
                        </div>
                        
                    </div>
                </div>
                <?php $i_idx++; endforeach; ?>
            </div>
            
            <p class="submit">
                <button type="submit" class="button button-primary button-hero">Salva modifiche</button>
            </p>
        </form>
    </div>
    
    <?php synergy_price_list_admin_styles(); ?>
    <?php synergy_price_list_admin_scripts_html($c_idx, $i_idx, $v_idx); ?>
    
    <?php
}

function synergy_price_list_admin_styles() {
    ?>
    <style>
        .sy-wrap { max-width: 1200px; }
        .sy-header-actions { display: flex; gap: 10px; margin-bottom: 20px; align-items:center; }
        .sy-stats-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; margin-bottom: 30px; }
        .sy-stat-card { background: #fff; border: 1px solid #ccd0d4; padding: 20px; border-radius: 4px; box-shadow: 0 1px 1px rgba(0,0,0,.04); }
        .sy-stat-label { font-size: 11px; font-weight: 600; color: #646970; margin-bottom: 8px; text-transform: uppercase; }
        .sy-stat-value { font-size: 28px; font-weight: 300; line-height: 1; color: #1d2327; }
        
        .sy-card { background: #fff; border: 1px solid #ccd0d4; padding: 20px; border-radius: 4px; margin-bottom: 20px; }
        .sy-card-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; border-bottom: 1px solid #eee; padding-bottom: 15px; }
        .sy-card-header h2 { margin: 0; font-size: 18px; }
        
        .sy-grid-2 { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
        .sy-grid-3 { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 20px; }
        .sy-grid-4 { display: grid; grid-template-columns: 1fr 1fr 1fr 1fr; gap: 20px; }
        
        .sy-form-group { margin-bottom: 15px; }
        .sy-form-group label { display: block; font-weight: 600; margin-bottom: 5px; color: #1d2327; }
        .w100 { width: 100%; }
        
        .sy-section-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px; border-bottom:2px solid #ddd; padding-bottom:10px; }
        .sy-section-header h2 { margin: 0; font-size: 20px; }
        
        .sy-accordion { background: #fff; border: 1px solid #ccd0d4; margin-bottom: 10px; border-radius: 4px; }
        .sy-accordion-header { padding: 12px 15px; cursor: pointer; display: flex; justify-content: space-between; align-items: center; background: #f8f9fa; border-radius: 4px; }
        .sy-accordion-header:hover { background: #f0f0f1; }
        .sy-acc-title { display: flex; align-items: center; gap: 10px; font-size: 14px; }
        .sy-acc-actions { display: flex; align-items: center; gap: 10px; }
        .sy-accordion-body { padding: 20px; border-top: 1px solid #ccd0d4; display: none; }
        .sy-accordion.open .sy-accordion-body { display: block; }
        .sy-accordion.open .toggle-icon { transform: rotate(180deg); }
        .drag-handle { cursor: grab; color: #8c8f94; }
        
        .badge { padding: 3px 8px; border-radius: 12px; font-size: 11px; font-weight: 600; color: #fff; }
        .badge-green { background: #46b450; }
        .badge-red { background: #d63638; }
        .badge-blue { background: #2271b1; }
        
        /* Toggle Switch */
        .sy-toggle { display: inline-flex; align-items: center; cursor: pointer; }
        .sy-toggle input { display: none; }
    </style>
    <?php
}

function synergy_price_list_admin_scripts_html($c_idx, $i_idx, $v_idx) {
    ?>
    <script>
    let globalCatIdx = <?php echo $c_idx; ?>;
    let globalItemIdx = <?php echo $i_idx; ?>;
    let globalVarIdx = <?php echo $v_idx; ?>;

    function syToggleAccordion(el) {
        const acc = el.closest('.sy-accordion');
        acc.classList.toggle('open');
        // trigger change su select per aggiornare visibility p-min p-max
        if (acc.classList.contains('open')) {
            const selects = acc.querySelectorAll('select[name$="[price_type]"]');
            selects.forEach(s => syUpdatePriceFields(s));
        }
    }

    function syRemoveAccordion(el, msg) {
        if(confirm(msg)) {
            el.closest('.sy-accordion').remove();
        }
    }

    function syUpdateAccTitle(input) {
        const acc = input.closest('.sy-accordion');
        const title = acc.querySelector('.sy-acc-title strong');
        title.innerText = input.value || 'Nuovo Elemento';
    }

    function syUpdateAccPrice(input) {
        const acc = input.closest('.sy-accordion');
        const priceSpan = acc.querySelector('.sy-acc-title span');
        if(priceSpan) priceSpan.innerText = '[' + (input.value || 'CHF 0.00') + ']';
    }

    function syUpdatePriceFields(select) {
        const row = select.closest('.sy-grid-4');
        const v = select.value;
        row.querySelector('.p-fixed').style.display = (v === 'fixed') ? 'block' : 'none';
        row.querySelector('.p-min').style.display = (v === 'from' || v === 'range') ? 'block' : 'none';
        row.querySelector('.p-max').style.display = (v === 'range') ? 'block' : 'none';
    }

    // Initialize all price fields
    document.querySelectorAll('select[name$="[price_type]"]').forEach(s => syUpdatePriceFields(s));

    function generateId(prefix) {
        return prefix + '-' + Math.random().toString(36).substr(2, 9);
    }

    // CLONE FUNCTIONS
    function syAddCategory() {
        const container = document.getElementById('sy-categories-container');
        const idx = globalCatIdx++;
        const id = generateId('cat');
        const html = `
        <div class="sy-accordion sy-category-accordion open" data-index="${idx}">
            <div class="sy-accordion-header" onclick="syToggleAccordion(this)">
                <div class="sy-acc-title">
                    <span class="dashicons dashicons-menu drag-handle"></span>
                    <strong>Nuova Categoria</strong>
                </div>
                <div class="sy-acc-actions">
                    <span class="badge badge-green">Visibile</span>
                    <button type="button" class="button button-small" onclick="event.stopPropagation(); syRemoveAccordion(this, 'Vuoi eliminare?')">Elimina</button>
                    <span class="dashicons dashicons-arrow-down-alt2 toggle-icon"></span>
                </div>
            </div>
            <div class="sy-accordion-body">
                <input type="hidden" name="synergy_price_list_data[categories][${idx}][id]" value="${id}">
                <div class="sy-grid-3">
                    <div class="sy-form-group"><label>Ordine</label><input type="number" name="synergy_price_list_data[categories][${idx}][order]" value="99" class="small-text"></div>
                    <div class="sy-form-group"><label><br><input type="checkbox" name="synergy_price_list_data[categories][${idx}][visible]" value="1" checked> Visibile in Home</label></div>
                </div>
                <div class="sy-grid-2">
                    <div class="sy-form-group"><label>Titolo</label><input type="text" class="regular-text w100" name="synergy_price_list_data[categories][${idx}][title]" value="Nuova Categoria" oninput="syUpdateAccTitle(this)"></div>
                    <div class="sy-form-group"><label>Titolo Corto</label><input type="text" class="regular-text w100" name="synergy_price_list_data[categories][${idx}][short_title]" value=""></div>
                </div>
                <div class="sy-form-group"><label>Descrizione</label><textarea class="large-text" rows="2" name="synergy_price_list_data[categories][${idx}][description]"></textarea></div>
            </div>
        </div>`;
        container.insertAdjacentHTML('beforeend', html);
    }

    function syAddItem() {
        const container = document.getElementById('sy-items-container');
        const idx = globalItemIdx++;
        const id = generateId('item');
        // Prendo le categorie dal DOM per ripopolare la select (clonando la prima select che trovo)
        let catOptions = '<option value="">-- Seleziona Categoria --</option>';
        const primaSelect = document.querySelector('.cat-select');
        if (primaSelect) catOptions = primaSelect.innerHTML; // mantiene le stesse options

        const html = `
        <div class="sy-accordion sy-item-accordion open" data-index="${idx}">
            <div class="sy-accordion-header" onclick="syToggleAccordion(this)">
                <div class="sy-acc-title">
                    <span class="dashicons dashicons-menu drag-handle"></span>
                    <strong>Nuovo Trattamento</strong>
                    <span style="color:#777; font-size:12px; margin-left:10px;">[CHF 0.00]</span>
                </div>
                <div class="sy-acc-actions">
                    <span class="badge badge-green">Visibile</span>
                    <button type="button" class="button button-small" onclick="event.stopPropagation(); syRemoveAccordion(this, 'Vuoi eliminare?')">Elimina</button>
                    <span class="dashicons dashicons-arrow-down-alt2 toggle-icon"></span>
                </div>
            </div>
            <div class="sy-accordion-body">
                <input type="hidden" name="synergy_price_list_data[items][${idx}][id]" value="${id}">
                <div class="sy-grid-3">
                    <div class="sy-form-group"><label>Categoria</label><select name="synergy_price_list_data[items][${idx}][category_id]" class="w100 cat-select">${catOptions}</select></div>
                    <div class="sy-form-group"><label>Ordine</label><input type="number" name="synergy_price_list_data[items][${idx}][order]" value="99" class="small-text"></div>
                    <div class="sy-form-group" style="padding-top:20px;">
                        <label style="display:inline-block; margin-right:15px;"><input type="checkbox" name="synergy_price_list_data[items][${idx}][visible]" value="1" checked> Visibile</label>
                        <label style="display:inline-block;"><input type="checkbox" name="synergy_price_list_data[items][${idx}][featured]" value="1"> In Evidenza</label>
                    </div>
                </div>
                <div class="sy-grid-2">
                    <div class="sy-form-group"><label>Nome Trattamento</label><input type="text" class="regular-text w100" name="synergy_price_list_data[items][${idx}][name]" value="Nuovo Trattamento" oninput="syUpdateAccTitle(this)"></div>
                    <div class="sy-form-group"><label>Durata</label><input type="text" class="regular-text w100" name="synergy_price_list_data[items][${idx}][duration]" value=""></div>
                </div>
                <div class="sy-form-group"><label>Descrizione</label><textarea class="large-text" rows="2" name="synergy_price_list_data[items][${idx}][description]"></textarea></div>
                <hr style="margin:20px 0; border:0; border-top:1px solid #ddd;">
                <div class="sy-grid-4">
                    <div class="sy-form-group"><label>Tipo Prezzo</label><select name="synergy_price_list_data[items][${idx}][price_type]" class="w100" onchange="syUpdatePriceFields(this)"><option value="fixed" selected>Fisso</option><option value="from">A partire da</option><option value="range">Range (Min-Max)</option><option value="custom">Testo Personalizzato</option></select></div>
                    <div class="sy-form-group p-fixed"><label>Prezzo Fisso</label><input type="number" step="0.01" class="w100" name="synergy_price_list_data[items][${idx}][price_fixed]" value=""></div>
                    <div class="sy-form-group p-min" style="display:none;"><label>Prezzo Min</label><input type="number" step="0.01" class="w100" name="synergy_price_list_data[items][${idx}][price_min]" value=""></div>
                    <div class="sy-form-group p-max" style="display:none;"><label>Prezzo Max</label><input type="number" step="0.01" class="w100" name="synergy_price_list_data[items][${idx}][price_max]" value=""></div>
                </div>
                <div class="sy-form-group"><label>Label Prezzo Finale</label><input type="text" class="regular-text w100" name="synergy_price_list_data[items][${idx}][price_label]" value="" oninput="syUpdateAccPrice(this)"></div>
                
                <div class="sy-variants-section" style="margin-top:20px; background:#f9f9f9; padding:15px; border:1px solid #ddd;">
                    <h4>Varianti</h4><div class="sy-variants-container"></div>
                    <button type="button" class="button button-small" onclick="syAddVariant(this, ${idx})">+ Aggiungi variante</button>
                </div>
            </div>
        </div>`;
        container.insertAdjacentHTML('beforeend', html);
    }

    function syDuplicateItem(btn) {
        const acc = btn.closest('.sy-item-accordion');
        const clone = acc.cloneNode(true);
        const idx = globalItemIdx++;
        
        // Change the ID and name attributes
        clone.dataset.index = idx;
        const newId = generateId('item-copy');
        
        // Find inputs and fix names
        const oldIdx = acc.dataset.index;
        const regex = new RegExp(`\\[items\\]\\[${oldIdx}\\]`, 'g');
        
        clone.querySelectorAll('input, select, textarea').forEach(el => {
            if(el.name) el.name = el.name.replace(regex, `[items][${idx}]`);
            if(el.classList.contains('item-id')) el.value = newId;
            if(el.name.includes('[name]')) el.value = el.value + ' (Copia)';
        });
        
        // Update Title
        const title = clone.querySelector('.sy-acc-title strong');
        if(title) title.innerText = title.innerText + ' (Copia)';
        
        acc.parentNode.insertBefore(clone, acc.nextSibling);
        clone.classList.add('open');
    }

    function syAddVariant(btn, itemIdx) {
        const container = btn.previousElementSibling;
        const vIdx = globalVarIdx++;
        const id = generateId('var');
        
        const html = `
        <div class="sy-variant-row" style="display:flex; gap:10px; margin-bottom:10px; align-items:flex-end;">
            <input type="hidden" name="synergy_price_list_data[items][${itemIdx}][variants][${vIdx}][id]" value="${id}">
            <div style="flex:2;"><label style="font-size:11px;">Nome</label><input type="text" class="w100" name="synergy_price_list_data[items][${itemIdx}][variants][${vIdx}][name]" value="Nuova variante"></div>
            <div style="flex:1;"><label style="font-size:11px;">Durata</label><input type="text" class="w100" name="synergy_price_list_data[items][${itemIdx}][variants][${vIdx}][duration]" value=""></div>
            <div style="flex:1;"><label style="font-size:11px;">Fisso</label><input type="number" step="0.01" class="w100" name="synergy_price_list_data[items][${itemIdx}][variants][${vIdx}][price_fixed]" value=""></div>
            <div style="flex:1.5;"><label style="font-size:11px;">Label</label><input type="text" class="w100" name="synergy_price_list_data[items][${itemIdx}][variants][${vIdx}][price_label]" value=""></div>
            <div style="flex:0.5;"><label style="font-size:11px;">Ord.</label><input type="number" class="w100" name="synergy_price_list_data[items][${itemIdx}][variants][${vIdx}][order]" value="99"></div>
            <div><label style="font-size:11px; display:block;">Vis.</label><input type="checkbox" name="synergy_price_list_data[items][${itemIdx}][variants][${vIdx}][visible]" value="1" checked></div>
            <div><button type="button" class="button" onclick="syRemoveVariantRow(this)">&times;</button></div>
        </div>`;
        container.insertAdjacentHTML('beforeend', html);
    }

    function syRemoveVariantRow(btn) {
        btn.closest('.sy-variant-row').remove();
    }
    </script>
    <?php
}

/**
 * Renderizza il listino prezzi frontend (nella Home)
 */
function synergy_render_home_price_list() {
    $data = synergy_get_price_list_data();
    $settings = $data['settings'];
    
    if (empty($settings['enabled'])) {
        return; // Sezione disattivata
    }
    
    $categories = array_filter($data['categories'], function($c) { return !empty($c['visible']); });
    usort($categories, function($a, $b) { return ($a['order'] ?? 0) <=> ($b['order'] ?? 0); });
    
    // L'ordine delle voci e' relativo alla categoria (riparte da 1 in ognuna):
    // ordinare globalmente su 'order' interlaccerebbe le categorie fra loro.
    // Si ordina quindi per posizione della categoria e, a parita', per 'order'.
    $cat_order = [];
    foreach ($categories as $ci => $c) {
        $cat_order[$c['id']] = $c['order'] ?? ($ci + 1);
    }
    $cat_pos = function ($item) use ($cat_order) {
        $cid = $item['category_id'] ?? '';
        return $cat_order[$cid] ?? PHP_INT_MAX; // voci orfane in coda
    };

    $items = array_filter($data['items'], function($i) { return !empty($i['visible']); });
    usort($items, function($a, $b) use ($cat_pos, $settings) {
        $ca = $cat_pos($a);
        $cb = $cat_pos($b);
        if ($ca !== $cb) return $ca <=> $cb;
        // "In evidenza per primi" agisce dentro la categoria, per non rompere
        // la struttura del listino fornita dal centro.
        if (!empty($settings['show_featured_first'])) {
            $a_f = !empty($a['featured']) ? 1 : 0;
            $b_f = !empty($b['featured']) ? 1 : 0;
            if ($a_f !== $b_f) return $b_f - $a_f;
        }
        return ($a['order'] ?? 0) <=> ($b['order'] ?? 0);
    });
    
    $max_visible = $settings['max_items'];
    $featured_count = 0;
    
    $cat_lookup = [];
    foreach ($categories as $c) {
        $cat_lookup[$c['id']] = $c['title'];
    }
    
    ?>
    <section class="synergy-prices-section section relative" id="listino-prezzi">
        <div class="container relative-z synergy-prices-container">
            
            <div class="synergy-prices-header text-center reveal">
                <?php if (!empty($settings['eyebrow'])): ?>
                    <span class="synergy-prices-eyebrow"><?php echo esc_html(synergy_t($settings['eyebrow'], 'price-list:eyebrow')); ?></span>
                <?php endif; ?>
                <?php if (!empty($settings['title'])): ?>
                    <h2 class="synergy-prices-title"><?php echo esc_html(synergy_t($settings['title'], 'price-list:title')); ?></h2>
                <?php endif; ?>
                <div class="synergy-prices-divider"></div>
                <?php if (!empty($settings['subtitle'])): ?>
                    <p class="synergy-prices-subtitle mx-auto"><?php echo esc_html(synergy_t($settings['subtitle'], 'price-list:subtitle')); ?></p>
                <?php endif; ?>
            </div>
            
            <div class="synergy-prices-wrapper reveal delay-1">
                
                <div class="synergy-price-tabs">
                    <button class="synergy-price-tab active" data-category="all" title="<?php echo esc_attr(synergy_t('Tutti', 'price-list:tab:all')); ?>"><?php echo esc_html(synergy_t('Tutti', 'price-list:tab:all')); ?></button>
                    <?php foreach ($categories as $cat): 
                        $short = !empty($cat['short_title']) ? $cat['short_title'] : trim(explode('&', $cat['title'])[0]);
                        $cat_context = 'price-list:section:' . sanitize_title($cat['id']);
                    ?>
                        <button class="synergy-price-tab" data-category="<?php echo esc_attr($cat['id']); ?>" title="<?php echo esc_attr(synergy_t($cat['title'], $cat_context . ':title')); ?>">
                            <?php echo esc_html(synergy_t($short, $cat_context . ':short_title')); ?>
                        </button>
                    <?php endforeach; ?>
                </div>

                <div class="synergy-price-list">
                    <?php 
                    $item_count = 0;
                    foreach ($items as $item): 
                        $item_count++;
                        $hidden_class = ($item_count > $max_visible) ? 'synergy-item-hidden' : '';
                        
                        $variants = array_filter($item['variants'] ?? [], function($v) { return !empty($v['visible']); });
                        usort($variants, function($a, $b) { return ($a['order'] ?? 0) <=> ($b['order'] ?? 0); });
                        $has_variants = count($variants) > 0;
                        
                        $is_featured = false;
                        if (!empty($item['featured']) && $featured_count < 3) {
                            $is_featured = true;
                            $featured_count++;
                        }
                        
                        $cat_name = $cat_lookup[$item['category_id']] ?? '';
                        $item_context = 'price-list:item:' . sanitize_title(!empty($item['id']) ? $item['id'] : $item['name']);
                    ?>
                        <div class="synergy-price-card <?php echo esc_attr($hidden_class); ?>" data-category="<?php echo esc_attr($item['category_id']); ?>">
                            <div class="synergy-price-card__inner <?php echo $has_variants ? 'has-variants' : ''; ?>">
                                
                                <div class="synergy-price-card__content">
                                    <div class="synergy-price-card__cat-label"><?php echo esc_html(synergy_t($cat_name, 'price-list:section:' . sanitize_title($item['category_id'] ?? '') . ':title')); ?></div>
                                    <h4 class="synergy-price-card__name">
                                        <?php echo esc_html(synergy_t($item['name'], $item_context . ':name')); ?>
                                        <?php if ($is_featured): ?>
                                            <span class="synergy-price-card__badge"><?php echo esc_html(synergy_t('In Evidenza', 'price-list:badge:featured')); ?></span>
                                        <?php endif; ?>
                                    </h4>
                                    <?php if (!empty($item['description'])): ?>
                                        <p class="synergy-price-card__desc"><?php echo wp_kses_post(synergy_t_html($item['description'], $item_context . ':description')); ?></p>
                                    <?php endif; ?>
                                    
                                    <div class="synergy-price-card__meta">
                                        <?php if (!empty($item['duration'])): ?>
                                            <span class="synergy-price-card__duration">
                                                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 16 14"></polyline></svg>
                                                <?php echo esc_html(synergy_t($item['duration'], 'price-list:duration')); ?>
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                
                                <div class="synergy-price-card__price-col">
                                    <span class="synergy-price-card__price-amount"><?php echo esc_html($item['price_label']); ?></span>
                                    <?php if ($has_variants): ?>
                                        <button class="synergy-price-card__toggle"><?php echo esc_html(synergy_t('Vedi opzioni', 'price-list:toggle:options')); ?> <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 9l6 6 6-6"/></svg></button>
                                    <?php endif; ?>
                                </div>
                                
                            </div>
                            
                            <?php if ($has_variants): ?>
                                <div class="synergy-price-card__variants">
                                    <?php foreach ($variants as $var):
                                        $variant_context = $item_context . ':variant:' . sanitize_title(!empty($var['id']) ? $var['id'] : $var['name']);
                                    ?>
                                        <div class="synergy-price-variant-row">
                                            <div class="synergy-price-variant-name"><?php echo esc_html(synergy_t($var['name'], $variant_context . ':name')); ?></div>
                                            <div class="synergy-price-variant-meta">
                                                <?php if (!empty($var['duration'])): ?>
                                                    <span class="synergy-price-variant-duration"><?php echo esc_html(synergy_t($var['duration'], 'price-list:duration')); ?></span>
                                                <?php endif; ?>
                                                <span class="synergy-price-variant-price"><?php echo esc_html($var['price_label']); ?></span>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                </div>

                <?php if ($settings['show_load_more'] && $item_count > $max_visible): ?>
                    <div class="synergy-prices-actions text-center">
                        <button class="synergy-prices-loadmore" id="synergy-load-more"><?php echo esc_html(synergy_t('Mostra tutti i trattamenti', 'price-list:load_more')); ?></button>
                    </div>
                <?php endif; ?>

            </div>

            <?php if (!empty($settings['note'])): ?>
                <div class="synergy-prices-note text-center reveal delay-2">
                    <p><?php echo esc_html(synergy_t($settings['note'], 'price-list:note')); ?></p>
                </div>
            <?php endif; ?>

            <?php if (!empty($settings['cta_label']) && !empty($settings['cta_url'])): 
                $cta_link = $settings['cta_url'];
                if (strpos($cta_link, 'http') !== 0 && strpos($cta_link, '/') === 0) {
                    $cta_link = home_url($cta_link);
                }
            ?>
                <div class="synergy-prices-cta text-center reveal delay-3">
                    <a href="<?php echo esc_url($cta_link); ?>" class="btn btn-primary synergy-btn-premium">
                        <?php echo esc_html(synergy_t($settings['cta_label'], 'price-list:cta')); ?>
                    </a>
                </div>
            <?php endif; ?>

        </div>
    </section>
    <?php
}
