<?php
/**
 * Testi frontend traducibili.
 *
 * Il child theme sovrascrive i template del parent e stampa molti testi
 * (hard-coded o letti dalle opzioni CMS) senza passare dal filtro
 * `ticinoweb_frontend_text` che il parent espone e che tW Translate Plus
 * intercetta. Risultato: nelle lingue aggiuntive (/ru/…) menu e contenuti
 * dei post erano tradotti, ma hero, sezioni, pulsanti e footer restavano
 * in italiano, e il plugin non poteva nemmeno sapere che esistevano.
 *
 * Ogni testo visibile del child passa da qui. L'escaping resta a carico
 * del chiamante (esc_html / esc_attr / wp_kses_post), come nel parent.
 *
 * @package synergyadvancedesthetics-child-theme
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Testo semplice traducibile.
 *
 * Il contesto è una chiave stabile che identifica il punto del template
 * (es. `front:hero:eyebrow`, `footer:cta:title`); viene prefissata con
 * `theme:synergy:` così le voci sono riconoscibili nel tab Traduzioni del
 * plugin e non collidono con quelle del parent (`theme:slider:…`).
 *
 * @param string $text    Testo originale (lingua principale).
 * @param string $context Chiave di contesto, senza prefisso.
 * @param array  $args    Metadati opzionali passati al filtro.
 * @return string Testo tradotto, o l'originale.
 */
function synergy_t( $text, $context, $args = array() ) {
    if ( ! is_string( $text ) || $text === '' || $context === '' ) {
        return $text;
    }
    $context = 'theme:synergy:' . ltrim( $context, ':' );
    if ( function_exists( 'ticinoweb_frontend_text' ) ) {
        return ticinoweb_frontend_text( $text, $context, $args );
    }
    return apply_filters( 'ticinoweb_frontend_text', $text, $context, $args );
}

/**
 * Frammento HTML traducibile (paragrafi, elenchi, titoli).
 *
 * Usa lo splitter di tW Translate Plus per tradurre blocco per blocco,
 * come fa il plugin con il contenuto dei post: blocchi più corti significano
 * traduzioni più precise e riutilizzabili. Se il plugin non è attivo, o la
 * pagina è nella lingua principale, il frammento torna intatto.
 *
 * @param string $html    Frammento HTML originale.
 * @param string $context Chiave di contesto, senza prefisso.
 * @return string
 */
function synergy_t_html( $html, $context ) {
    if ( ! is_string( $html ) || trim( $html ) === '' || $context === '' ) {
        return $html;
    }
    if ( class_exists( 'Twtr_Content' ) ) {
        $out = '';
        foreach ( Twtr_Content::split_html( $html ) as $chunk ) {
            $out .= Twtr_Content::is_translatable_chunk( $chunk ) ? synergy_t( $chunk, $context ) : $chunk;
        }
        return $out;
    }
    return synergy_t( $html, $context );
}
