<?php
/**
 * Seeder automatico per articoli del blog per Synergy Advanced Aesthetics
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

function synergy_seed_initial_blog_posts() {
    // Esegui una sola volta
    if ( get_option( 'synergy_blog_sample_seeded_v1' ) ) {
        return;
    }

    $sample_articles = array(
        array(
            'title'    => 'I segreti per una pelle radiosa: guida alla skincare avanzata',
            'category' => 'Trattamenti Viso',
            'excerpt'  => 'Scopri i rituali, gli attivi mirati e i trattamenti professionali indispensabili per mantenere la barriera cutanea protetta, elastica e naturalmente luminosa.',
            'content'  => '<p>Una pelle luminosa, distesa e sana non è il risultato di formule miracolose, ma di una <strong>costanza consapevole</strong> e di trattamenti studiati su misura per le specifiche caratteristiche del tuo viso.</p>
<h2>1. L\'importanza della detersione e dell\'esfoliazione dolce</h2>
<p>Nel corso della giornata, smog, impurità e residui di sebo si depositano sui pori, opacizzando l\'incarnato. L\'uso quotidiano di detergenti a pH bilanciato e un\'esfoliazione enzimatica periodica favoriscono il naturale ricambio cellulare senza aggredire il film idrolipidico.</p>
<h2>2. Attivi mirati: Idratazione profonda e antiossidanti</h2>
<p>L\'integrazione di sieri a base di <em>acido ialuronico a differente peso molecolare</em> e vitamina C ad alta stabilità contrasta lo stress ossidativo e previene la comparsa dei primi segni di espressione.</p>
<h2>3. Il valore del percorso in cabina</h2>
<p>Presso <strong>Synergy Advanced Aesthetics</strong> a Paradiso, ogni percorso viso inizia con un\'attenta analisi cutanea. Tecnologie innovative e manualità mirate permettono di veicolare principi attivi negli strati più profondi per risultati visibili e duraturi.</p>',
        ),
        array(
            'title'    => 'Epilazione Laser a Diodo: efficacia, benefici e consigli utili',
            'category' => 'Epilazione Laser',
            'excerpt'  => 'Tutto quello che c\'è da sapere sull\'epilazione laser progressiva permanente: come funziona la tecnologia a diodo, quante sedute occorrono e come preparare la cute.',
            'content'  => '<p>L\'epilazione laser progressiva permanente è oggi la soluzione più avanzata, sicura e confortevole per liberarsi dai peli superflui e prevenire fastidiose follicoliti.</p>
<h2>Come agisce il laser a diodo</h2>
<p>Il fascio di luce emesso dal laser sfrutta il principio della <em>fototermolisi selettiva</em>: l\'energia luminosa viene assorbita dalla melanina del pelo e trasformata in calore, disattivando il bulbo pilifero senza surriscaldare la cute circostante.</p>
<h2>La preparazione ideale prima della seduta</h2>
<ul>
    <li>Evitare l\'esposizione solare diretta o lampade abbronzanti nei giorni precedenti.</li>
    <li>Rendere la pelle morbida e idratata nei giorni prima del trattamento.</li>
    <li>Rasare delicatamente la zona da trattare 24-48 ore prima della seduta.</li>
</ul>
<p>Affidati all\'esperienza delle nostre estetiste specializzate per una consulenza personalizzata e un piano di sedute calibrate sulle tue esigenze.</p>',
        ),
        array(
            'title'    => 'Rimodellamento corpo: l\'unione vincente tra manualità e tecnologia',
            'category' => 'Cura del Corpo',
            'excerpt'  => 'Come contrastare ritenzione idrica e atonia combinando massaggi drenanti specializzati e tecnologie estetiche di ultima generazione per una silhouette armoniosa.',
            'content'  => '<p>Prendersi cura della silhouette richiede un approccio sinergico che rispetti la fisiologia del corpo e valorizzi le forme naturali.</p>
<h2>Stimolare il microcircolo e drenare i liquidi</h2>
<p>La ritenzione idrica e la pesantezza agli arti inferiori possono essere alleviate con protocolli mirati che combinano manualità drenanti esperte e trattamenti avanzati per stimolare la circolazione linfatica.</p>
<h2>Tecnologia ed efficacia su misura</h2>
<p>Presso il nostro centro estetico a Paradiso (Lugano) utilizziamo tecnologie all\'avanguardia per agire in modo mirato su adiposità localizzate e perdita di tono cutaneo, garantendo trattamenti piacevoli e rigeneranti.</p>',
        ),
    );

    foreach ( $sample_articles as $art ) {
        $check = get_page_by_title( $art['title'], OBJECT, 'post' );
        if ( ! $check ) {
            $post_id = wp_insert_post( array(
                'post_title'   => $art['title'],
                'post_excerpt' => $art['excerpt'],
                'post_content' => $art['content'],
                'post_status'  => 'publish',
                'post_type'    => 'post',
                'post_author'  => 1,
            ) );

            if ( $post_id && ! is_wp_error( $post_id ) ) {
                wp_set_object_terms( $post_id, $art['category'], 'category' );
            }
        }
    }

    // Rimuovi post di default "Hello world!" se presente
    $hello = get_page_by_title( 'Hello world!', OBJECT, 'post' );
    if ( $hello ) {
        wp_delete_post( $hello->ID, true );
    }

    update_option( 'synergy_blog_sample_seeded_v1', 1 );
}
add_action( 'init', 'synergy_seed_initial_blog_posts' );
