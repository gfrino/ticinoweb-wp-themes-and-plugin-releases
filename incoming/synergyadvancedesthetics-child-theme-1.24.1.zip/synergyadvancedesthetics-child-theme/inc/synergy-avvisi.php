<?php
/**
 * Avvisi per la clientela.
 *
 * Oggi contiene la politica di disdetta, che deve comparire identica in piu'
 * punti (pagina Contatti, condizioni di vendita, in futuro le email di
 * conferma). Il testo vive quindi in UNA opzione e chi lo mostra la legge:
 * niente copie da tenere allineate a mano.
 *
 * @package synergy-child
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

const SYNERGY_AVVISO_DISDETTA = 'synergy_avviso_disdetta';

/**
 * Testo dell'avviso di disdetta, vuoto se non compilato.
 *
 * @return string
 */
function synergy_get_avviso_disdetta() {
    return trim( (string) get_option( SYNERGY_AVVISO_DISDETTA, '' ) );
}

/**
 * Stampa l'avviso come riquadro, se compilato.
 *
 * @param string $classe Classe aggiuntiva del contenitore.
 */
function synergy_render_avviso_disdetta( $classe = '' ) {
    $testo = synergy_get_avviso_disdetta();
    if ( $testo === '' ) {
        return;
    }
    $righe = array_values( array_filter( array_map( 'trim', preg_split( '/\r\n|\r|\n/', $testo ) ), 'strlen' ) );
    $titolo = array_shift( $righe );
    ?>
    <aside class="synergy-avviso <?php echo esc_attr( $classe ); ?>" role="note">
        <svg class="synergy-avviso-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
            <circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="12"></line><line x1="12" y1="16" x2="12.01" y2="16"></line>
        </svg>
        <div class="synergy-avviso-body">
            <p class="synergy-avviso-title"><?php echo esc_html( synergy_t( $titolo, 'avviso:disdetta:titolo' ) ); ?></p>
            <?php foreach ( $righe as $i => $riga ) : ?>
                <p><?php echo esc_html( synergy_t( $riga, 'avviso:disdetta:' . $i ) ); ?></p>
            <?php endforeach; ?>
        </div>
    </aside>
    <?php
}

/* ---------------------------------------------------------------- admin */

add_action( 'admin_menu', 'synergy_avvisi_menu', 20 );

/**
 * Pannello sotto il CMS ticinoWEB, come gli altri del child.
 */
function synergy_avvisi_menu() {
    add_submenu_page(
        'ticinoweb-cms',
        'Avvisi per la clientela',
        'Avvisi',
        'manage_options',
        'synergy-avvisi',
        'synergy_avvisi_page'
    );
}

/**
 * Pagina con il solo campo dell'avviso.
 */
function synergy_avvisi_page() {
    if ( ! current_user_can( 'manage_options' ) ) {
        return;
    }

    if ( isset( $_POST['synergy_avvisi_nonce'] )
        && wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['synergy_avvisi_nonce'] ) ), 'synergy_save_avvisi' ) ) {
        $val = isset( $_POST[ SYNERGY_AVVISO_DISDETTA ] ) ? sanitize_textarea_field( wp_unslash( $_POST[ SYNERGY_AVVISO_DISDETTA ] ) ) : '';
        update_option( SYNERGY_AVVISO_DISDETTA, $val );
        echo '<div class="notice notice-success is-dismissible"><p>Avviso salvato.</p></div>';
    }
    ?>
    <div class="wrap">
        <h1>Avvisi per la clientela</h1>
        <form method="post">
            <?php wp_nonce_field( 'synergy_save_avvisi', 'synergy_avvisi_nonce' ); ?>
            <h2 class="title">Politica di disdetta</h2>
            <p class="description">
                Compare nella pagina Contatti e nelle Condizioni di vendita.
                La <strong>prima riga</strong> fa da titolo del riquadro, le successive sono i paragrafi.
                Lascia vuoto per non mostrare nessun avviso.
            </p>
            <textarea name="<?php echo esc_attr( SYNERGY_AVVISO_DISDETTA ); ?>" rows="8" class="large-text code"><?php echo esc_textarea( get_option( SYNERGY_AVVISO_DISDETTA, '' ) ); ?></textarea>
            <?php submit_button( 'Salva avviso' ); ?>
        </form>
    </div>
    <?php
}
