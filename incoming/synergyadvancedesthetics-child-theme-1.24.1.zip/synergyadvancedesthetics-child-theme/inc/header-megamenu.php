<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Funzione per estrarre e strutturare gli elementi del menu
 */
function synergy_get_menu_tree($menu_name = 'Menu Principale') {
    $menu = wp_get_nav_menu_object($menu_name);
    
    // Se non troviamo per nome, proviamo per location
    if (!$menu) {
        $locations = get_nav_menu_locations();
        if (isset($locations['primary'])) {
            $menu = wp_get_nav_menu_object($locations['primary']);
        }
    }

    if (!$menu) {
        return array();
    }

    $items = wp_get_nav_menu_items($menu->term_id);
    if (!$items) {
        return array();
    }

    $tree = array();
    $references = array();

    foreach ($items as $item) {
        $references[$item->ID] = array(
            'id' => $item->ID,
            'title' => $item->title,
            'url' => $item->url,
            'object_id' => $item->object_id, // pagina puntata: serve a riconoscere il listino
            'description' => $item->description,
            'classes' => $item->classes,
            'target' => $item->target,
            'children' => array()
        );
    }

    foreach ($items as $item) {
        if ($item->menu_item_parent == 0) {
            $tree[$item->ID] = &$references[$item->ID];
        } else {
            $references[$item->menu_item_parent]['children'][$item->ID] = &$references[$item->ID];
        }
    }

    return $tree;
}

/**
 * Fallback descrizioni trattamenti
 */
function synergy_get_service_fallback_description($title) {
    $fallbacks = array(
        'Acne, macchie e luminosità' => 'Percorsi mirati per uniformare, illuminare e migliorare la qualità della pelle.',
        'Anti-age' => 'Trattamenti pensati per tono, compattezza e segni del tempo.',
        'Peeling e rigenerazione' => 'Soluzioni professionali per rinnovare e rendere la pelle più luminosa.',
        'Pulizia viso' => 'Cura profonda e delicata per una pelle più fresca e pulita.',
        'Trattamenti Viso Avanzati' => 'Percorsi completi e personalizzati per il benessere della pelle.',
        'Cellulite e drenaggio' => 'Trattamenti per leggerezza, drenaggio e inestetismi della cellulite.',
        'Tonificazione' => 'Percorsi dedicati a tono, compattezza e forma.',
        'Trattamenti Corpo & Rimodellamento' => 'Programmi personalizzati per silhouette, drenaggio e benessere.',
        'Trattamenti dimagranti' => 'Soluzioni professionali a supporto dei percorsi corpo.',
        'Smagliature e cicatrici' => 'Trattamenti mirati per migliorare l’aspetto della pelle.',
        'Ciglia e sopracciglia' => 'Servizi beauty per valorizzare lo sguardo.',
        'Epilazione Laser & Depilazione' => 'Soluzioni professionali per viso e corpo, anche per uomo.',
        'Mani, Piedi & Beauty Essentials' => 'Manicure, pedicure e cura estetica quotidiana.',
        'Massaggi & Benessere' => 'Trattamenti per relax, drenaggio, leggerezza e benessere.'
    );

    foreach ($fallbacks as $key => $desc) {
        // Usa stripos per matchare parzialmente ignorando il case
        if (stripos($title, $key) !== false || stripos($key, $title) !== false) {
            return synergy_t($desc, 'megamenu:desc:' . sanitize_title($key));
        }
    }
    return synergy_t('Scopri i dettagli di questo trattamento personalizzato e prenota la tua consulenza.', 'megamenu:fallback_desc');
}

/**
 * Renderizza l'header completo
 */
function synergy_build_dynamic_header() {
    $tree = synergy_get_menu_tree('Menu Principale');
    
    // Configura i link
    $home_url = esc_url(home_url('/'));
    
    ?>
    <header class="synergy-header" id="synergy-main-header">
        <div class="synergy-header-container">
            
            <!-- Logo -->
            <a href="<?php echo $home_url; ?>" class="synergy-logo" aria-label="<?php echo esc_attr(synergy_t('Synergy Advanced Aesthetics Home', 'header:logo:aria')); ?>">
                <?php 
                $tw_logo = get_option('ticinoweb_site_logo');
                if ( !empty($tw_logo) ) {
                    echo '<img src="' . esc_url($tw_logo) . '" alt="' . esc_attr(sprintf(synergy_t('%s Logo', 'header:logo:alt'), get_bloginfo('name'))) . '" class="synergy-dynamic-logo">';
                } elseif ( has_custom_logo() ) {
                    the_custom_logo();
                } else {
                    echo '<span class="synergy-logo-text">SYNERGY</span>';
                }
                ?>
            </a>

            <!-- Desktop Nav -->
            <nav class="synergy-nav-desktop">
                <ul class="synergy-nav-list">
                    <?php 
                    if (!empty($tree)) {
                        foreach ($tree as $item_id => $item) {
                            $is_trattamenti = (stripos($item['title'], 'Trattamenti') !== false);
                            
                            if ($is_trattamenti && !empty($item['children'])) {
                                echo '<li class="synergy-nav-item has-megamenu">';
                                echo '<button type="button" class="synergy-nav-link mega-toggle" aria-expanded="false" aria-controls="synergy-mega-menu">';
                                echo esc_html($item['title']);
                                echo '<svg width="10" height="6" viewBox="0 0 10 6" fill="none" class="megamenu-chevron"><path d="M1 1L5 5L9 1" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>';
                                echo '</button>';
                                
                                // Render Mega Menu
                                echo '<div class="synergy-mega-menu" id="synergy-mega-menu" aria-hidden="true" inert>';
                                echo '<div class="synergy-mega-menu-inner">';
                                
                                // Le voci di secondo livello CON figli diventano tab
                                // (Viso, Corpo, Beauty); quelle SENZA figli non hanno un
                                // pannello da mostrare e diventano link diretti in fondo
                                // alla colonna, validi per tutti i percorsi: e' il caso
                                // del Listino Prezzi, che non appartiene a una sola
                                // categoria. Sta fuori dal tablist per non rompere lo
                                // schema ARIA tab/tabpanel.
                                $mega_tabs  = array();
                                $mega_links = array();
                                foreach ($item['children'] as $cat_id => $cat) {
                                    if (!empty($cat['children'])) {
                                        $mega_tabs[$cat_id] = $cat;
                                    } else {
                                        $mega_links[$cat_id] = $cat;
                                    }
                                }

                                // A. Colonna Laterale "Percorsi"
                                echo '<div class="synergy-mega-sidebar">';
                                echo '<h4 class="mega-sidebar-title">' . esc_html(synergy_t('Percorsi', 'megamenu:sidebar:title')) . '</h4>';
                                echo '<ul class="mega-sidebar-list" role="tablist" aria-label="' . esc_attr(synergy_t('Categorie trattamenti', 'megamenu:sidebar:aria')) . '">';
                                $first_cat = true;
                                foreach ($mega_tabs as $cat_id => $cat) {
                                    $active_class = $first_cat ? 'active' : '';
                                    $selected = $first_cat ? 'true' : 'false';
                                    echo '<li class="mega-sidebar-item ' . $active_class . '" data-target="mega-panel-' . absint($cat_id) . '" role="presentation">';
                                    echo '<button type="button" class="mega-sidebar-link" id="mega-tab-' . absint($cat_id) . '" role="tab" aria-selected="' . $selected . '" aria-controls="mega-panel-' . absint($cat_id) . '" tabindex="' . ($first_cat ? '0' : '-1') . '">';
                                    echo esc_html($cat['title']);
                                    echo '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 18 15 12 9 6"></polyline></svg>';
                                    echo '</button>';
                                    echo '</li>';
                                    $first_cat = false;
                                }
                                echo '</ul>';
                                echo '<div class="mega-sidebar-trail"></div>'; // Focus trail

                                if (!empty($mega_links)) {
                                    echo '<ul class="mega-sidebar-links">';
                                    foreach ($mega_links as $link_id => $link) {
                                        // data-target: senza, il JS spegnerebbe tutti i
                                        // pannelli lasciando il megamenu vuoto in hover.
                                        echo '<li class="mega-sidebar-item is-direct" data-target="mega-panel-' . absint($link_id) . '">';
                                        echo '<a href="' . esc_url($link['url']) . '" class="mega-sidebar-link mega-sidebar-link--direct">';
                                        echo esc_html($link['title']);
                                        echo '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg>';
                                        echo '</a>';
                                        echo '</li>';
                                    }
                                    echo '</ul>';
                                }

                                echo '</div>'; // end mega-sidebar
                                
                                // B. Pannello Centrale Dinamico
                                echo '<div class="synergy-mega-panels">';
                                $first_cat = true;
                                foreach ($mega_tabs as $cat_id => $cat) {
                                    $active_class = $first_cat ? 'active' : '';
                                    echo '<div class="synergy-mega-panel ' . $active_class . '" id="mega-panel-' . absint($cat_id) . '" role="tabpanel" aria-labelledby="mega-tab-' . absint($cat_id) . '" aria-hidden="' . ($first_cat ? 'false' : 'true') . '"' . ($first_cat ? '' : ' inert') . '>';
                                    echo '<div class="mega-panel-grid">';
                                    if (!empty($cat['children'])) {
                                        foreach ($cat['children'] as $service_id => $service) {
                                            $desc = !empty($service['description']) ? synergy_t($service['description'], 'megamenu:desc:menu-item-' . absint($service['id'])) : synergy_get_service_fallback_description($service['title']);
                                            
                                            // Utilizziamo l'URL impostato nel menu di WordPress
                                            $s_url = $service['url'];

                                            echo '<a href="' . esc_url($s_url) . '" class="mega-service-card">';
                                            echo '<div class="mega-service-content">';
                                            echo '<h5 class="mega-service-title">' . esc_html($service['title']) . '</h5>';
                                            echo '<p class="mega-service-desc">' . esc_html($desc) . '</p>';
                                            echo '</div>';
                                            echo '<div class="mega-service-icon"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg></div>';
                                            echo '</a>';
                                        }
                                    }
                                    echo '</div>'; // end mega-panel-grid
                                    echo '</div>'; // end synergy-mega-panel
                                    $first_cat = false;
                                }

                                // Pannello dei link diretti. Per il listino prezzi si
                                // costruisce un indice delle sezioni: cosi' il pannello
                                // non resta vuoto e si salta direttamente alla sezione.
                                $price_page_id = function_exists('synergy_get_price_list_page_id') ? synergy_get_price_list_page_id() : 0;
                                foreach ($mega_links as $link_id => $link) {
                                    $index = ($price_page_id && (int) $link['object_id'] === $price_page_id && function_exists('synergy_get_price_list_index'))
                                        ? synergy_get_price_list_index()
                                        : array();

                                    echo '<div class="synergy-mega-panel" id="mega-panel-' . absint($link_id) . '" role="region" aria-label="' . esc_attr($link['title']) . '" aria-hidden="true" inert>';
                                    if ($index) {
                                        echo '<div class="mega-panel-grid mega-panel-grid--compact">';
                                        foreach ($index as $section) {
                                            echo '<a href="' . esc_url($section['url']) . '" class="mega-service-card mega-service-card--compact">';
                                            echo '<div class="mega-service-content">';
                                            echo '<h5 class="mega-service-title">' . esc_html($section['title']) . '</h5>';
                                            $count_label = ((int) $section['count'] === 1)
                                                ? synergy_t('%d trattamento', 'megamenu:price_index:count:one')
                                                : synergy_t('%d trattamenti', 'megamenu:price_index:count:many');
                                            echo '<p class="mega-service-desc">' . esc_html(sprintf($count_label, $section['count'])) . '</p>';
                                            echo '</div>';
                                            echo '</a>';
                                        }
                                        echo '</div>';
                                    } else {
                                        echo '<div class="mega-panel-grid"></div>';
                                    }
                                    echo '</div>'; // end synergy-mega-panel
                                }

                                echo '</div>'; // end synergy-mega-panels
                                
                                // C. Pannello Destro "Consulenza"
                                echo '<div class="synergy-mega-cta-box">';
                                echo '<div class="mega-cta-content">';
                                echo '<h4>' . esc_html(synergy_t('Non sai quale trattamento scegliere?', 'megamenu:cta:title')) . '</h4>';
                                echo '<p>' . esc_html(synergy_t('Ogni percorso nasce dall’ascolto e da una valutazione personalizzata. Ti aiutiamo a capire il trattamento più adatto alle tue esigenze.', 'megamenu:cta:text')) . '</p>';
                                echo '<a href="' . esc_url(home_url('/contatti/')) . '" class="btn btn-primary btn-mega-cta">' . esc_html(synergy_t('Prenota una consulenza', 'megamenu:cta:btn')) . '</a>';
                                echo '<ul class="mega-trust-points">';
                                echo '<li><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg> ' . esc_html(synergy_t('Analisi personalizzata', 'megamenu:cta:point:1')) . '</li>';
                                echo '<li><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg> ' . esc_html(synergy_t('Tecnologie professionali', 'megamenu:cta:point:2')) . '</li>';
                                echo '<li><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg> ' . esc_html(synergy_t('Metodo su misura', 'megamenu:cta:point:3')) . '</li>';
                                echo '</ul>';
                                echo '</div>';
                                echo '</div>'; // end synergy-mega-cta-box
                                
                                // D. Footer interno
                                echo '<div class="synergy-mega-footer">';
                                echo '<div class="mega-footer-inner">';
                                echo '<span class="mega-footer-text">' . esc_html(synergy_t('Estetica avanzata a Paradiso, Lugano', 'megamenu:footer:tagline')) . '</span>';
                                echo '<span class="mega-footer-divider">|</span>';
                                echo '<a href="tel:+41792886177" class="mega-footer-link">+41 (0)79 288 61 77</a>';
                                echo '<span class="mega-footer-divider">|</span>';
                                echo '<a href="' . esc_url(home_url('/contatti/')) . '" class="mega-footer-link">' . esc_html(synergy_t('Contatti', 'megamenu:footer:contacts')) . '</a>';
                                echo '</div>';
                                echo '</div>'; // end synergy-mega-footer
                                
                                echo '</div>'; // end synergy-mega-menu-inner
                                echo '</div>'; // end synergy-mega-menu
                                echo '</li>';
                            } else {
                                echo '<li class="synergy-nav-item">';
                                echo '<a href="' . esc_url($item['url']) . '" class="synergy-nav-link">' . esc_html($item['title']) . '</a>';
                                echo '</li>';
                            }
                        }
                    } else {
                        // Fallback se menu vuoto
                        echo '<li class="synergy-nav-item"><a href="'.$home_url.'" class="synergy-nav-link">' . esc_html(synergy_t('Home', 'megamenu:nav:home')) . '</a></li>';
                    }
                    ?>
                </ul>
            </nav>

            <!-- CTA & Cart Desktop/Mobile -->
            <div class="synergy-header-actions">
                <?php if ( class_exists( 'WooCommerce' ) ) : ?>
                    <?php 
                    if ( null === WC()->cart ) {
                        WC()->cart = new WC_Cart();
                    }
                    $cart_count = WC()->cart ? WC()->cart->get_cart_contents_count() : 0; 
                    ?>
                    <a href="<?php echo esc_url( wc_get_cart_url() ); ?>" class="header-cart-link" aria-label="<?php echo esc_attr( synergy_t( 'Vai al carrello', 'header:cart:aria' ) ); ?>">
                        <svg viewBox="0 0 24 24" width="22" height="22" stroke="currentColor" stroke-width="1.5" fill="none" stroke-linecap="round" stroke-linejoin="round">
                            <circle cx="9" cy="21" r="1"></circle>
                            <circle cx="20" cy="21" r="1"></circle>
                            <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"></path>
                        </svg>
                        <span class="header-cart-badge" <?php echo ($cart_count == 0) ? 'style="display:none;"' : 'style="display:inline-flex;"'; ?>>
                            <?php echo esc_html( $cart_count ); ?>
                        </span>
                    </a>
                <?php endif; ?>

                <a href="<?php echo esc_url(home_url('/contatti/')); ?>" class="btn btn-primary header-cta-btn"><?php echo esc_html( synergy_t( 'Prenota una consulenza', 'header:cta:book' ) ); ?></a>
                
                <!-- Burger Button -->
                <button class="synergy-burger-btn" id="synergy-mobile-toggle" aria-label="<?php echo esc_attr( synergy_t( 'Apri menu', 'header:burger:open' ) ); ?>" aria-controls="synergy-mobile-menu" aria-expanded="false">
                    <span class="burger-line"></span>
                    <span class="burger-line"></span>
                    <span class="burger-line"></span>
                </button>
            </div>
            
        </div>
    </header>

    <!-- Mobile Menu Overlay -->
    <div class="synergy-mobile-menu" id="synergy-mobile-menu" role="dialog" aria-modal="true" aria-label="<?php echo esc_attr( synergy_t( 'Menu principale', 'mobile:menu:aria' ) ); ?>" aria-hidden="true" inert>
        <div class="mobile-menu-inner">
            <div class="mobile-menu-header">
                <a href="<?php echo $home_url; ?>" class="synergy-logo" aria-label="<?php echo esc_attr(synergy_t('Synergy Advanced Aesthetics Home', 'header:logo:aria')); ?>">
                    <span class="synergy-logo-text">SYNERGY</span>
                </a>
                <button class="synergy-mobile-close" id="synergy-mobile-close" aria-label="<?php echo esc_attr( synergy_t( 'Chiudi menu', 'mobile:menu:close' ) ); ?>">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
                </button>
            </div>
            
            <nav class="mobile-nav">
                <ul class="mobile-nav-list">
                    <?php 
                    if (!empty($tree)) {
                        foreach ($tree as $item_id => $item) {
                            if (!empty($item['children'])) {
                                $mobile_accordion_id = 'mobile-accordion-' . absint($item_id);
                                echo '<li class="mobile-nav-item has-accordion">';
                                echo '<button type="button" class="mobile-accordion-toggle" aria-expanded="false" aria-controls="' . esc_attr($mobile_accordion_id) . '">';
                                echo '<span class="mobile-nav-title">' . esc_html($item['title']) . '</span>';
                                echo '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="accordion-icon"><polyline points="6 9 12 15 18 9"></polyline></svg>';
                                echo '</button>';
                                
                                echo '<ul class="mobile-accordion-content" id="' . esc_attr($mobile_accordion_id) . '">';
                                foreach ($item['children'] as $cat_id => $cat) {
                                    if (!empty($cat['children'])) {
                                        $mobile_sub_accordion_id = 'mobile-sub-accordion-' . absint($cat_id);
                                        echo '<li class="mobile-sub-accordion">';
                                        echo '<button type="button" class="mobile-accordion-toggle sub-toggle" aria-expanded="false" aria-controls="' . esc_attr($mobile_sub_accordion_id) . '">';
                                        echo '<span class="mobile-nav-subtitle">' . esc_html($cat['title']) . '</span>';
                                        echo '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="accordion-icon"><polyline points="6 9 12 15 18 9"></polyline></svg>';
                                        echo '</button>';
                                        
                                        echo '<ul class="mobile-accordion-content sub-content" id="' . esc_attr($mobile_sub_accordion_id) . '">';
                                        foreach ($cat['children'] as $service_id => $service) {
                                            echo '<li><a href="' . esc_url($service['url']) . '" class="mobile-nav-link sub-link">' . esc_html($service['title']) . '</a></li>';
                                        }
                                        echo '</ul>';
                                        echo '</li>';
                                    } else {
                                        echo '<li><a href="' . esc_url($cat['url']) . '" class="mobile-nav-link">' . esc_html($cat['title']) . '</a></li>';
                                    }
                                }
                                echo '</ul>';
                                echo '</li>';
                            } else {
                                echo '<li class="mobile-nav-item">';
                                echo '<a href="' . esc_url($item['url']) . '" class="mobile-nav-link main-link">' . esc_html($item['title']) . '</a>';
                                echo '</li>';
                            }
                        }
                    }
                    ?>
                </ul>
            </nav>
            
            <div class="mobile-menu-footer">
                <a href="<?php echo esc_url(home_url('/contatti/')); ?>" class="btn btn-primary mobile-cta"><?php echo esc_html( synergy_t( 'Prenota una consulenza', 'mobile:cta:book' ) ); ?></a>
                <div class="mobile-contact-info">
                    <a href="tel:+41792886177">+41 (0)79 288 61 77</a>
                    <span><?php echo esc_html( synergy_t( 'Estetica avanzata a Paradiso, Lugano', 'mobile:footer:tagline' ) ); ?></span>
                </div>
            </div>
        </div>
    </div>
    <?php
}
