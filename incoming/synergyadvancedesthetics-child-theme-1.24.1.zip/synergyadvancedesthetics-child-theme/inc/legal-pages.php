<?php
/**
 * Gestione e creazione automatica delle pagine legali (Privacy Policy e Cookie Policy).
 * Conforme alla Legge federale svizzera sulla protezione dei dati (LPD) e GDPR.
 *
 * @package SynergyAdvancedAesthetics
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

add_action( 'init', 'synergy_create_legal_pages', 20 );

function synergy_create_legal_pages() {
    if ( get_option( 'synergy_legal_pages_version' ) === '1.0' ) {
        return;
    }

    $cms_name    = get_option( 'ticinoweb_site_name', 'Synergy Advanced Aesthetics' );
    $cms_email   = get_option( 'ticinoweb_contact_email', 'info@synergyaesthetics.ch' );
    $cms_phone   = get_option( 'ticinoweb_contact_phone', '+41 (0)79 288 61 77' );
    $cms_address = get_option( 'ticinoweb_contact_address', 'Via Generale Guisan 10, Paradiso, Lugano' );

    $identity = '<div class="legal-identity-box">
        <p><strong>' . esc_html( $cms_name ) . '</strong><br>
        ' . wp_kses_post( $cms_address ) . '<br>
        Tel: <a href="tel:' . esc_attr( preg_replace('/[^0-9+]/', '', $cms_phone) ) . '">' . esc_html( $cms_phone ) . '</a><br>
        Email: <a href="mailto:' . esc_attr( $cms_email ) . '">' . esc_html( $cms_email ) . '</a></p>
    </div>';

    $pages = array(
        'privacy-policy' => array(
            'title'   => 'Privacy Policy',
            'content' => '<div class="synergy-legal-wrapper">
                <p class="legal-updated"><em>Ultimo aggiornamento: Agosto 2026</em></p>
                <p>La presente informativa descrive le modalità di trattamento dei dati personali raccolti da <strong>' . esc_html( $cms_name ) . '</strong> attraverso il sito web, nel pieno rispetto della <strong>Legge federale svizzera sulla protezione dei dati (LPD)</strong> e, per quanto applicabile, del Regolamento Generale europeo sulla Protezione dei Dati (<strong>GDPR</strong>).</p>

                <h2>1. Titolare del Trattamento</h2>
                ' . $identity . '

                <h2>2. Tipologie di Dati Raccolti</h2>
                <p>Nello svolgimento delle nostre attività e tramite il sito web possiamo raccogliere e trattare le seguenti categorie di dati:</p>
                <ul>
                    <li><strong>Dati forniti volontariamente:</strong> nome, cognome, indirizzo email, recapito telefonico, indirizzo di spedizione/fatturazione e ogni altra informazione inviata tramite i moduli di contatto, prenotazione trattamenti o acquisto nello shop e-commerce.</li>
                    <li><strong>Dati di navigazione e tecnici:</strong> indirizzo IP, tipo di browser, dispositivo utilizzato, data e ora di accesso, pagine visitate e log di sicurezza necessari al corretto funzionamento dell’infrastruttura.</li>
                    <li><strong>Dati relativi agli ordini e appuntamenti:</strong> dettagli dei prodotti o trattamenti acquistati, preferenze e storico delle consulenze.</li>
                </ul>

                <h2>3. Finalità e Base Giuridica del Trattamento</h2>
                <p>I dati personali raccolti sono trattati per le seguenti finalità:</p>
                <ul>
                    <li><strong>Esecuzione dei servizi richiesti:</strong> gestione degli ordini WooCommerce, evasione delle spedizioni, prenotazione e organizzazione di trattamenti e consulenze estetiche.</li>
                    <li><strong>Assistenza clienti:</strong> rispondere a richieste inviate via form di contatto, chat o email.</li>
                    <li><strong>Adempimenti fiscali e legali:</strong> tenuta della contabilità e rispetto degli obblighi di legge svizzeri e internazionali.</li>
                    <li><strong>Sicurezza e prevenzione abusi:</strong> monitoraggio dell’integrità del sito e prevenzione di frodi o accessi non autorizzati.</li>
                </ul>

                <h2>4. Comunicazione dei Dati a Terzi</h2>
                <p>I dati personali non vengono ceduti né venduti a terzi per scopi di marketing. Possono tuttavia essere comunicati a fornitori di servizi tecnici e partner necessari al funzionamento delle attività (es. hosting provider, piattaforme di pagamento sicuro come Stripe o bonifico, corrieri per le consegne, consulenti contabili e legali), tutti vincolati a rigorosi obblighi di riservatezza e conformità normativa.</p>

                <h2>5. Luogo di Trattamento e Trasferimenti all\'Estero</h2>
                <p>I dati sono conservati e trattati prevalentemente in <strong>Svizzera</strong> e all\'interno dell\'Unione Europea. Nel caso in cui alcuni strumenti o servizi tecnici risiedano al di fuori di tali territori, garantiamo l\'adozione di garanzie adeguate conformi alla LPD svizzera (decisioni di adeguatezza o clausole contrattuali standard riconosciute).</p>

                <h2>6. Periodo di Conservazione dei Dati</h2>
                <p>I dati vengono conservati per il tempo strettamente necessario a conseguire le finalità per cui sono stati raccolti e per adempiere agli obblighi legali e fiscali (fino a 10 anni per la documentazione contabile e d\'acquisto, conformemente al Codice delle Obbligazioni svizzero).</p>

                <h2>7. Diritti dell\'Interessato</h2>
                <p>In qualità di interessato, la legge LPD / GDPR ti garantisce specifici diritti, tra cui:</p>
                <ul>
                    <li>Diritto di accesso e informazione sui dati trattati;</li>
                    <li>Diritto di rettifica di dati inesatti o incompleti;</li>
                    <li>Diritto di cancellazione dei propri dati personali (salvo obblighi di legge contrari);</li>
                    <li>Diritto di limitazione o revoca del consenso;</li>
                    <li>Diritto di proporre reclamo all\'<strong>Incaricato federale della protezione dei dati e della trasparenza (IFPDT)</strong> in Svizzera.</li>
                </ul>
                <p>Per esercitare i tuoi diritti puoi scrivere in qualsiasi momento a <a href="mailto:' . esc_attr( $cms_email ) . '">' . esc_html( $cms_email ) . '</a>.</p>

                <h2>8. Misure di Sicurezza</h2>
                <p>Adottiamo misure di sicurezza tecniche e organizzative avanzate (inclusa la cifratura HTTPS con certificato SSL) per proteggere i tuoi dati da accessi non autorizzati, alterazioni, perdite o divulgazioni illecite.</p>
            </div>',
        ),
        'cookie-policy'  => array(
            'title'   => 'Cookie Policy',
            'content' => '<div class="synergy-legal-wrapper">
                <p class="legal-updated"><em>Ultimo aggiornamento: Agosto 2026</em></p>
                <p>Questa Cookie Policy illustra cosa sono i cookie, come vengono utilizzati su <strong>' . esc_html( $cms_name ) . '</strong> e come puoi gestire le tue preferenze di navigazione.</p>

                <h2>1. Cosa sono i Cookie</h2>
                <p>I cookie sono piccoli file di testo che i siti web visitati inviano al dispositivo dell\'utente (computer, smartphone o tablet), dove vengono memorizzati per essere poi ritrasmessi agli stessi siti alla visita successiva. I cookie consentono di migliorare l\'esperienza di navigazione, ricordare preferenze e garantire funzionalità essenziali.</p>

                <h2>2. Tipologie di Cookie Utilizzati</h2>
                <p>Sul nostro sito utilizziamo le seguenti categorie di cookie e tecnologie analoghe:</p>
                
                <h3>A. Cookie Tecnici e di Sessione (Strettamente Necessari)</h3>
                <p>Questi cookie sono indispensabili per il corretto funzionamento del sito e non possono essere disattivati nei nostri sistemi. Comprendono ad esempio:</p>
                <ul>
                    <li>Cookie di sessione per la gestione del carrello WooCommerce e del processo di checkout;</li>
                    <li>Cookie di sicurezza e prevenzione di richieste fraudolente (CSRF / nonce);</li>
                    <li>Cookie per memorizzare le preferenze di consenso.</li>
                </ul>

                <h3>B. Cookie Funzionali e Servizi di Terze Parti</h3>
                <p>Permettono di abilitare funzionalità avanzate e personalizzazioni:</p>
                <ul>
                    <li><strong>Google Maps:</strong> nella pagina Contatti è integrata una mappa interattiva di Google. Il caricamento della mappa può comportare l\'impostazione di cookie da parte di Google Inc.</li>
                    <li><strong>Font e Risorse Statiche:</strong> per garantire una tipografia curata e uniforme, il sito può richiamare font e librerie grafiche protette.</li>
                </ul>

                <h3>C. Cookie Analitici e di Prestazione</h3>
                <p>Se attivi, raccolgono informazioni anonime e aggregate su come gli utenti navigano il sito, consentendoci di misurare e migliorare le prestazioni delle pagine senza identificare personalmente il visitatore.</p>

                <h2>3. Gestione e Disabilitazione dei Cookie</h2>
                <p>Puoi scegliere di accettare, rifiutare o cancellare i cookie in qualsiasi momento direttamente dalle impostazioni del tuo browser web. Di seguito i collegamenti alle guide ufficiali dei browser più diffusi:</p>
                <ul>
                    <li><a href="https://support.google.com/chrome/answer/95647" target="_blank" rel="noopener">Google Chrome</a></li>
                    <li><a href="https://support.apple.com/it-it/guide/safari/sfri11471/mac" target="_blank" rel="noopener">Apple Safari</a></li>
                    <li><a href="https://support.mozilla.org/it/kb/Gestione%20dei%20cookie" target="_blank" rel="noopener">Mozilla Firefox</a></li>
                    <li><a href="https://support.microsoft.com/it-it/windows/eliminare-e-gestire-i-cookie-168dab11-0753-043d-7c16-ede5947fc64d" target="_blank" rel="noopener">Microsoft Edge</a></li>
                </ul>
                <p><em>Nota: La disabilitazione dei cookie tecnici potrebbe compromettere la navigazione e impedire l\'utilizzo di alcune funzioni del negozio online (come l\'aggiunta al carrello o il completamento degli acquisti).</em></p>

                <h2>4. Contatti</h2>
                <p>Per ulteriori chiarimenti sull\'utilizzo dei cookie o per consultare l\'informativa completa sul trattamento dei dati, visita la nostra <a href="' . esc_url( home_url( '/privacy-policy/' ) ) . '">Privacy Policy</a> o contattaci a:</p>
                ' . $identity . '
            </div>',
        ),
    );

    foreach ( $pages as $slug => $page_data ) {
        $existing_page = get_page_by_path( $slug, OBJECT, 'page' );
        if ( ! $existing_page ) {
            $page_id = wp_insert_post( array(
                'post_type'    => 'page',
                'post_status'  => 'publish',
                'post_title'   => $page_data['title'],
                'post_name'    => $slug,
                'post_content' => $page_data['content'],
                'post_author'  => 1,
            ), true );
        }
    }

    update_option( 'synergy_legal_pages_version', '1.0', false );
}
