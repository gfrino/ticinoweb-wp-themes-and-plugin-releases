<?php
/**
 * Gestione dinamica Sezione "IL TEAM" per Synergy Advanced Aesthetics
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// Registrazione menu Admin "IL TEAM"
function synergy_register_team_admin_menu() {
    add_menu_page(
        'Gestione Il Team',
        'IL TEAM',
        'manage_options',
        'synergy-team',
        'synergy_render_team_admin_page',
        'dashicons-groups',
        25
    );
}
add_action( 'admin_menu', 'synergy_register_team_admin_menu' );

// Enqueue WP Media Uploader per la pagina del Team
function synergy_team_admin_scripts( $hook ) {
    if ( $hook !== 'toplevel_page_synergy-team' ) {
        return;
    }
    wp_enqueue_media();
}
add_action( 'admin_enqueue_scripts', 'synergy_team_admin_scripts' );

// Helper per ottenere i membri del team (con fallback di default)
function synergy_get_team_members() {
    $members = get_option( 'synergy_team_members', false );
    
    if ( false === $members || ! is_array( $members ) || empty( $members ) ) {
        // Fallback membri predefiniti se non ancora salvati
        $members = array(
            array(
                'name'  => 'Olena Utkina',
                'role'  => 'Estetista con diploma AFC',
                'title' => 'Specialista Viso & Corpo',
                'photo' => '',
            ),
            array(
                'name'  => 'Oksana Korolisina',
                'role'  => 'Estetista',
                'title' => 'Specialista Trattamenti',
                'photo' => '',
            ),
        );
    }
    return $members;
}

// Render Pagina Admin
function synergy_render_team_admin_page() {
    if ( ! current_user_can( 'manage_options' ) ) {
        return;
    }

    // Salvataggio Form
    if ( isset( $_POST['synergy_team_nonce'] ) && wp_verify_nonce( $_POST['synergy_team_nonce'], 'synergy_save_team_options' ) ) {
        
        $eyebrow     = isset( $_POST['synergy_team_eyebrow'] ) ? sanitize_text_field( $_POST['synergy_team_eyebrow'] ) : 'IL TEAM';
        $title       = isset( $_POST['synergy_team_title'] ) ? sanitize_text_field( $_POST['synergy_team_title'] ) : '';
        $description = isset( $_POST['synergy_team_description'] ) ? sanitize_textarea_field( $_POST['synergy_team_description'] ) : '';

        update_option( 'synergy_team_eyebrow', $eyebrow );
        update_option( 'synergy_team_title', $title );
        update_option( 'synergy_team_description', $description );

        // Processa membri
        $raw_members = isset( $_POST['synergy_team'] ) && is_array( $_POST['synergy_team'] ) ? $_POST['synergy_team'] : array();
        $clean_members = array();

        foreach ( $raw_members as $item ) {
            $name  = isset( $item['name'] ) ? sanitize_text_field( $item['name'] ) : '';
            $role  = isset( $item['role'] ) ? sanitize_text_field( $item['role'] ) : '';
            $t_opt = isset( $item['title'] ) ? sanitize_text_field( $item['title'] ) : '';
            $photo = isset( $item['photo'] ) ? esc_url_raw( $item['photo'] ) : '';
            $bio   = isset( $item['bio'] ) ? sanitize_textarea_field( $item['bio'] ) : '';

            if ( ! empty( $name ) || ! empty( $photo ) || ! empty( $role ) ) {
                $clean_members[] = array(
                    'name'  => $name,
                    'role'  => $role,
                    'title' => $t_opt,
                    'photo' => $photo,
                    'bio'   => $bio,
                );
            }
        }

        update_option( 'synergy_team_members', $clean_members );

        echo '<div class="notice notice-success is-dismissible" style="margin: 20px 0;"><p><strong>Sezione "IL TEAM" salvata con successo! Le modifiche sono ora visibili nel sito.</strong></p></div>';
    }

    // Caricamento opzioni salvate
    $eyebrow     = get_option( 'synergy_team_eyebrow', 'IL TEAM' );
    $title       = get_option( 'synergy_team_title', 'Le professioniste dietro ogni percorso.' );
    $description = get_option( 'synergy_team_description', 'Ogni trattamento nasce dall’ascolto, dall’esperienza e da una cura autentica per la persona. Da Synergy Advanced Aesthetics trovi competenze professionali, discrezione e un approccio su misura per accompagnarti con fiducia in ogni fase del tuo percorso estetico.' );
    $members     = synergy_get_team_members();
    ?>

    <div class="wrap synergy-team-admin-wrap" style="max-width: 1000px; margin-top: 20px;">
        <h1 style="font-size: 2rem; font-weight: 600; margin-bottom: 8px;">✨ Gestione Sezione "IL TEAM"</h1>
        <p style="font-size: 1rem; color: #666; margin-bottom: 24px;">Da questa schermata puoi personalizzare i testi principali e gestire le collaboratrici visibili in homepage e nel sito. Puoi aggiungere, modificare o rimuovere componenti del team in qualsiasi momento.</p>

        <form method="post" action="">
            <?php wp_nonce_field( 'synergy_save_team_options', 'synergy_team_nonce' ); ?>

            <!-- SCHEDA INTESTAZIONE SEZIONE -->
            <div style="background: #ffffff; border: 1px solid #ccd0d4; border-radius: 12px; padding: 24px; margin-bottom: 24px; box-shadow: 0 4px 12px rgba(0,0,0,0.03);">
                <h2 style="font-size: 1.2rem; margin-top: 0; margin-bottom: 16px; border-bottom: 1px solid #eee; padding-bottom: 10px;">📌 Titolo e Descrizione Sezione</h2>
                
                <table class="form-table" style="margin: 0; width: 100%;">
                    <tr>
                        <th scope="row" style="width: 200px;"><label for="synergy_team_eyebrow">Titoletto (Eyebrow)</label></th>
                        <td>
                            <input type="text" id="synergy_team_eyebrow" name="synergy_team_eyebrow" value="<?php echo esc_attr( $eyebrow ); ?>" class="regular-text" placeholder="IL TEAM" />
                            <p class="description">Piccola etichetta in maiuscolo sopra il titolo.</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="synergy_team_title">Titolo Principale</label></th>
                        <td>
                            <input type="text" id="synergy_team_title" name="synergy_team_title" value="<?php echo esc_attr( $title ); ?>" class="large-text" placeholder="Le professioniste dietro ogni percorso." />
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="synergy_team_description">Descrizione Sezione</label></th>
                        <td>
                            <textarea id="synergy_team_description" name="synergy_team_description" rows="4" class="large-text"><?php echo esc_textarea( $description ); ?></textarea>
                            <p class="description">Testo introduttivo che spiega la filosofia del team.</p>
                        </td>
                    </tr>
                </table>
            </div>

            <!-- SCHEDA GESTIONE COLLABORATRICI -->
            <div style="background: #ffffff; border: 1px solid #ccd0d4; border-radius: 12px; padding: 24px; margin-bottom: 24px; box-shadow: 0 4px 12px rgba(0,0,0,0.03);">
                <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 20px; border-bottom: 1px solid #eee; padding-bottom: 12px;">
                    <div>
                        <h2 style="font-size: 1.2rem; margin: 0;">👩‍⚕️ Collaboratrici / Componenti del Team</h2>
                        <p style="margin: 4px 0 0 0; color: #666; font-size: 0.9rem;">Aggiungi foto, nome, ruolo o titolo per ciascuna collaboratrice. Puoi riordinarle o aggiungerne di nuove.</p>
                    </div>
                    <button type="button" class="button button-primary add-team-member-btn" style="height: 38px; padding: 0 16px; font-weight: 600;">+ Aggiungi Collaboratrice</button>
                </div>

                <div id="team-members-container" style="display: flex; flex-direction: column; gap: 16px;">
                    <?php
                    if ( ! empty( $members ) ) :
                        foreach ( $members as $index => $member ) :
                            $m_name  = isset( $member['name'] ) ? $member['name'] : '';
                            $m_role  = isset( $member['role'] ) ? $member['role'] : '';
                            $m_title = isset( $member['title'] ) ? $member['title'] : '';
                            $m_photo = isset( $member['photo'] ) ? $member['photo'] : '';
                            $m_bio   = isset( $member['bio'] ) ? $member['bio'] : '';
                            ?>
                            <div class="team-member-card" style="background: #fdfbf8; border: 1px solid #e2d9cc; border-radius: 10px; padding: 18px; position: relative;">
                                <div style="display: flex; gap: 20px; align-items: flex-start; flex-wrap: wrap;">
                                    
                                    <!-- Anteprima Foto -->
                                    <div style="width: 110px; text-align: center;">
                                        <div class="photo-preview" style="width: 100px; height: 120px; background: #ece9e2; border-radius: 10px; border: 1px solid #ccc; display: flex; align-items: center; justify-content: center; overflow: hidden; margin-bottom: 8px;">
                                            <?php if ( ! empty( $m_photo ) ) : ?>
                                                <img src="<?php echo esc_url( $m_photo ); ?>" style="width: 100%; height: 100%; object-fit: cover;" />
                                            <?php else : ?>
                                                <span style="color: #999; font-size: 0.8rem; text-align: center; padding: 4px;">Nessuna Foto</span>
                                            <?php endif; ?>
                                        </div>
                                        <input type="hidden" class="member-photo-input" name="synergy_team[<?php echo $index; ?>][photo]" value="<?php echo esc_attr( $m_photo ); ?>" />
                                        <button type="button" class="button button-secondary upload-photo-btn" style="font-size: 11px; padding: 0 8px;">Scegli Foto</button>
                                    </div>

                                    <!-- Campi Testo -->
                                    <div style="flex: 1; min-width: 260px;">
                                        <div style="margin-bottom: 10px;">
                                            <label style="font-weight: 600; display: block; margin-bottom: 4px; font-size: 0.85rem;">Nome e Cognome</label>
                                            <input type="text" name="synergy_team[<?php echo $index; ?>][name]" value="<?php echo esc_attr( $m_name ); ?>" class="large-text" placeholder="Es. Olena Utkina" required />
                                        </div>
                                        <div style="display: flex; gap: 12px; flex-wrap: wrap;">
                                            <div style="flex: 1; min-width: 180px;">
                                                <label style="font-weight: 600; display: block; margin-bottom: 4px; font-size: 0.85rem;">Ruolo / Lavoro / Diploma</label>
                                                <input type="text" name="synergy_team[<?php echo $index; ?>][role]" value="<?php echo esc_attr( $m_role ); ?>" class="large-text" placeholder="Es. Estetista con diploma AFC" />
                                            </div>
                                            <div style="flex: 1; min-width: 180px;">
                                                <label style="font-weight: 600; display: block; margin-bottom: 4px; font-size: 0.85rem;">Titoletto / Specializzazione (Opzionale)</label>
                                                <input type="text" name="synergy_team[<?php echo $index; ?>][title]" value="<?php echo esc_attr( $m_title ); ?>" class="large-text" placeholder="Es. Specialista Trattamenti Viso" />
                                            </div>
                                        </div>

                                        <div style="margin-top: 12px;">
                                            <label style="font-weight: 600; display: block; margin-bottom: 4px; font-size: 0.85rem;">Qualifiche e formazione (una per riga)</label>
                                            <textarea name="synergy_team[<?php echo $index; ?>][bio]" rows="5" class="large-text" placeholder="Estetista con Diploma Federale Svizzero&#10;Cosmetologa specializzata in Estetica Avanzata e Anti-Aging&#10;Nutrizionista"><?php echo esc_textarea( $m_bio ); ?></textarea>
                                            <p class="description">Ogni riga diventa una voce dell'elenco sotto la foto. Lascia vuoto per non mostrare nulla.</p>
                                        </div>
                                    </div>

                                    <!-- Azioni -->
                                    <div style="display: flex; flex-direction: column; gap: 6px; align-items: flex-end;">
                                        <button type="button" class="button remove-member-btn" style="color: #b42318; border-color: #b42318; background: #fff;">Elimina</button>
                                        <div style="display: flex; gap: 4px; margin-top: 10px;">
                                            <button type="button" class="button move-up-btn" title="Sposta su">▲</button>
                                            <button type="button" class="button move-down-btn" title="Sposta giù">▼</button>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        <?php endforeach;
                    endif; ?>
                </div>

                <div style="margin-top: 20px; text-align: center;">
                    <button type="button" class="button button-secondary add-team-member-btn" style="padding: 6px 20px; font-weight: 600;">+ Aggiungi Nuova Collaboratrice</button>
                </div>
            </div>

            <!-- PULSANTE SALVA MODIFICHE -->
            <div style="margin-top: 24px;">
                <input type="submit" name="submit" id="submit" class="button button-primary button-hero" value="💾 Salva Modifiche Il Team" style="font-size: 1.1rem; height: 46px; padding: 0 32px; border-radius: 6px;" />
            </div>

        </form>
    </div>

    <!-- Script Media Library & Dynamicity -->
    <script>
    jQuery(document).ready(function($){
        
        // Media Library Uploader
        $(document).on('click', '.upload-photo-btn', function(e){
            e.preventDefault();
            var $btn = $(this);
            var $card = $btn.closest('.team-member-card');
            var $input = $card.find('.member-photo-input');
            var $preview = $card.find('.photo-preview');

            var mediaFrame = wp.media({
                title: 'Seleziona Foto Collaboratrice',
                button: { text: 'Usa questa foto' },
                multiple: false
            });

            mediaFrame.on('select', function(){
                var attachment = mediaFrame.state().get('selection').first().toJSON();
                $input.val(attachment.url);
                $preview.html('<img src="' + attachment.url + '" style="width:100%; height:100%; object-fit:cover;" />');
            });

            mediaFrame.open();
        });

        // Add New Member
        $('.add-team-member-btn').on('click', function(e){
            e.preventDefault();
            var index = $('#team-members-container .team-member-card').length;
            var html = `
                <div class="team-member-card" style="background: #fdfbf8; border: 1px solid #e2d9cc; border-radius: 10px; padding: 18px; position: relative;">
                    <div style="display: flex; gap: 20px; align-items: flex-start; flex-wrap: wrap;">
                        <div style="width: 110px; text-align: center;">
                            <div class="photo-preview" style="width: 100px; height: 120px; background: #ece9e2; border-radius: 10px; border: 1px solid #ccc; display: flex; align-items: center; justify-content: center; overflow: hidden; margin-bottom: 8px;">
                                <span style="color: #999; font-size: 0.8rem; text-align: center; padding: 4px;">Nessuna Foto</span>
                            </div>
                            <input type="hidden" class="member-photo-input" name="synergy_team[${index}][photo]" value="" />
                            <button type="button" class="button button-secondary upload-photo-btn" style="font-size: 11px; padding: 0 8px;">Scegli Foto</button>
                        </div>
                        <div style="flex: 1; min-width: 260px;">
                            <div style="margin-bottom: 10px;">
                                <label style="font-weight: 600; display: block; margin-bottom: 4px; font-size: 0.85rem;">Nome e Cognome</label>
                                <input type="text" name="synergy_team[${index}][name]" value="" class="large-text" placeholder="Es. Nome Collaboratrice" required />
                            </div>
                            <div style="display: flex; gap: 12px; flex-wrap: wrap;">
                                <div style="flex: 1; min-width: 180px;">
                                    <label style="font-weight: 600; display: block; margin-bottom: 4px; font-size: 0.85rem;">Ruolo / Lavoro / Diploma</label>
                                    <input type="text" name="synergy_team[${index}][role]" value="" class="large-text" placeholder="Es. Estetista / Specialista" />
                                </div>
                                <div style="flex: 1; min-width: 180px;">
                                    <label style="font-weight: 600; display: block; margin-bottom: 4px; font-size: 0.85rem;">Titoletto / Specializzazione (Opzionale)</label>
                                    <input type="text" name="synergy_team[${index}][title]" value="" class="large-text" placeholder="Es. Trattamenti Viso" />
                                </div>
                            </div>
                        </div>
                        <div style="display: flex; flex-direction: column; gap: 6px; align-items: flex-end;">
                            <button type="button" class="button remove-member-btn" style="color: #b42318; border-color: #b42318; background: #fff;">Elimina</button>
                            <div style="display: flex; gap: 4px; margin-top: 10px;">
                                <button type="button" class="button move-up-btn" title="Sposta su">▲</button>
                                <button type="button" class="button move-down-btn" title="Sposta giù">▼</button>
                            </div>
                        </div>
                    </div>
                </div>
            `;
            $('#team-members-container').append(html);
        });

        // Remove Member
        $(document).on('click', '.remove-member-btn', function(e){
            e.preventDefault();
            if(confirm('Vuoi davvero rimuovere questa collaboratrice dal team?')) {
                $(this).closest('.team-member-card').remove();
            }
        });

        // Move Up / Down
        $(document).on('click', '.move-up-btn', function(e){
            e.preventDefault();
            var $card = $(this).closest('.team-member-card');
            $card.insertBefore($card.prev());
        });
        $(document).on('click', '.move-down-btn', function(e){
            e.preventDefault();
            var $card = $(this).closest('.team-member-card');
            $card.insertAfter($card.next());
        });

    });
    </script>
    <?php
}
