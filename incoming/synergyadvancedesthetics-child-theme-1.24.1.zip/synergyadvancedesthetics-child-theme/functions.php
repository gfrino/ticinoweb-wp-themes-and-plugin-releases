<?php
/**
 * Synergy Advanced Aesthetics Child Theme functions and definitions
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

/** Helper di traduzione frontend (synergy_t / synergy_t_html): va caricato prima di ogni altro inc/. */
require_once get_stylesheet_directory() . '/inc/translation.php';

/** Keep checkout assets available on the native WooCommerce checkout page. */
function synergy_is_checkout_context() {
    return ( function_exists( 'is_checkout' ) && is_checkout() )
        || is_page( 'checkout' );
}

/**
 * Keep personal data from a previous WooCommerce customer/session out of a
 * newly opened checkout. Posted values still win inside WC_Checkout::get_value,
 * so validation errors never erase information the current customer entered.
 */
function synergy_checkout_empty_initial_values( $value, $input ) {
    if ( ! synergy_is_checkout_context() ) {
        return $value;
    }

    if ( function_exists( 'is_wc_endpoint_url' ) && ( is_wc_endpoint_url( 'order-pay' ) || is_wc_endpoint_url( 'order-received' ) ) ) {
        return $value;
    }

    $request_method = isset( $_SERVER['REQUEST_METHOD'] ) ? strtoupper( sanitize_text_field( wp_unslash( $_SERVER['REQUEST_METHOD'] ) ) ) : 'GET';
    if ( 'GET' !== $request_method ) {
        return $value;
    }

    if ( 0 === strpos( $input, 'billing_' ) || 0 === strpos( $input, 'shipping_' ) || 'order_comments' === $input ) {
        return '';
    }

    return $value;
}
add_filter( 'woocommerce_checkout_get_value', 'synergy_checkout_empty_initial_values', 20, 2 );

/** Add clear Italian hints and prevent browser-level reuse of another client. */
function synergy_checkout_field_placeholders( $fields ) {
    $address_placeholders = array(
        'first_name' => synergy_t( 'Nome', 'checkout:placeholder:first_name' ),
        'last_name'  => synergy_t( 'Cognome', 'checkout:placeholder:last_name' ),
        'company'    => synergy_t( 'Azienda (facoltativo)', 'checkout:placeholder:company' ),
        'country'    => synergy_t( 'Seleziona paese/regione…', 'checkout:placeholder:country' ),
        'address_1'  => synergy_t( 'Via/Piazza e Numero Civico', 'checkout:placeholder:address_1' ),
        'address_2'  => synergy_t( 'Appartamento, suite, unità, ecc. (facoltativo)', 'checkout:placeholder:address_2' ),
        'city'       => synergy_t( 'Città', 'checkout:placeholder:city' ),
        'state'      => synergy_t( 'Cantone / Provincia', 'checkout:placeholder:state' ),
        'postcode'   => synergy_t( 'CAP', 'checkout:placeholder:postcode' ),
        'phone'      => synergy_t( 'Numero di telefono', 'checkout:placeholder:phone' ),
    );

    foreach ( array( 'billing', 'shipping' ) as $fieldset ) {
        if ( empty( $fields[ $fieldset ] ) || ! is_array( $fields[ $fieldset ] ) ) {
            continue;
        }

        foreach ( $fields[ $fieldset ] as $field_key => &$field ) {
            $short_key = preg_replace( '/^(billing|shipping)_/', '', $field_key );
            if ( isset( $address_placeholders[ $short_key ] ) ) {
                $field['placeholder'] = $address_placeholders[ $short_key ];
            }
            $field['autocomplete'] = 'off';
        }
        unset( $field );
    }

    if ( isset( $fields['billing']['billing_email'] ) ) {
        $fields['billing']['billing_email']['placeholder']  = synergy_t( 'Indirizzo email', 'checkout:placeholder:email' );
        $fields['billing']['billing_email']['autocomplete'] = 'off';
    }

    if ( isset( $fields['order']['order_comments'] ) ) {
        $fields['order']['order_comments']['placeholder']  = synergy_t( 'Note sull’ordine (facoltativo)', 'checkout:placeholder:order_comments' );
        $fields['order']['order_comments']['autocomplete'] = 'off';
    }

    return $fields;
}
add_filter( 'woocommerce_checkout_fields', 'synergy_checkout_field_placeholders', 20 );

/**
 * Checkout page shell rendered inside an ordinary WordPress page.
 * WooCommerce retains ownership of the form, fields, totals and submission;
 * this shortcode only provides Synergy's page structure.
 */
function synergy_render_checkout_shell() {
    if ( ! class_exists( 'WooCommerce' ) ) {
        return '';
    }

    ob_start();
    ?>
    <section class="synergy-checkout-shell" aria-labelledby="synergy-checkout-title">
        <div class="synergy-checkout-wrapper">
            <div class="container">
                <header class="checkout-page-header text-center">
                    <h1 id="synergy-checkout-title" class="checkout-page-title"><?php echo esc_html( synergy_t( 'Cassa e Pagamento', 'checkout:title' ) ); ?></h1>
                    <p class="checkout-page-subtitle"><?php echo esc_html( synergy_t( 'Inserisci i tuoi dati per completare l’ordine in tutta sicurezza.', 'checkout:subtitle' ) ); ?></p>
                </header>

                <div class="checkout-page-content">
                    <?php echo do_shortcode( '[woocommerce_checkout]' ); ?>
                </div>
            </div>
        </div>
    </section>
    <?php

    return ob_get_clean();
}
add_shortcode( 'synergy_checkout', 'synergy_render_checkout_shell' );

add_action( 'wp_enqueue_scripts', 'synergy_advanced_aesthetics_enqueue_styles' );

/**
 * Stringhe per i JS del child (oggetto globale `synergyI18n`).
 * Il pannello "Technology Lab" della pagina Tecnologie e' incluso solo li'.
 */
function synergy_frontend_i18n() {
    $i18n = array(
        'showAll'       => synergy_t( 'Mostra tutto', 'js:show_all' ),
        'showLess'      => synergy_t( 'Mostra meno', 'js:show_less' ),
        'sortDefault'   => synergy_t( 'Ordinamento predefinito', 'prodotti:sort:default' ),
        'addToCart'     => synergy_t( 'Aggiungi al carrello', 'product:add_to_cart' ),
        'adding'        => synergy_t( 'Aggiunta...', 'js:cart:adding' ),
        'added'         => synergy_t( 'Aggiunto ✓', 'js:cart:added' ),
        'error'         => synergy_t( 'Errore', 'js:cart:error' ),
        'couponError'   => synergy_t( 'Il codice promozionale inserito non è valido. Controllalo e riprova.', 'js:coupon:error' ),
        'couponSuccess' => synergy_t( 'Codice promozionale applicato con successo.', 'js:coupon:success' ),
        'couponHint'    => synergy_t( 'Se possiedi un codice promozionale, inseriscilo qui sotto.', 'js:coupon:hint' ),
        'menuOpen'      => synergy_t( 'Apri menu', 'header:burger:open' ),
        'menuClose'     => synergy_t( 'Chiudi menu', 'header:burger:close' ),
    );

    if ( is_page_template( 'template-tecnologie.php' ) ) {
        $lab = array(
            'viso'           => array( 'Area Viso', 'Tecnologie per il viso', 'Sistemi professionali pensati per supportare luminosità, tono, rigenerazione e qualità della pelle.', array( 'Radiofrequenza', 'HIFU / SMAS', 'Cold Plasma', 'ELOS-IPL', 'Ultrasuoni', 'Ionoforesi', 'Elettrostimolazione' ) ),
            'corpo'          => array( 'Area Corpo', 'Rimodellamento corpo', 'Sistemi avanzati per la tonificazione e il trattamento degli inestetismi corporei.', array( 'Radiofrequenza corpo', 'Cavitazione', 'Vacuum', 'Criolipolisi', 'OndaVacu Gym', 'Body Shaping Sculpt', 'OndaWave' ) ),
            'epilazione'     => array( 'Area Epilazione', 'Epilazione progressiva', "Soluzioni laser di ultima generazione per un'epilazione efficace e confortevole.", array( 'Laser diodo', 'Laser diodo ArtMED', 'Laser diodo CoaxMED' ) ),
            'pelle'          => array( 'Area Pelle', 'Rigenerazione cutanea', "Apparecchiature specifiche per la purificazione profonda e l'equilibrio della pelle.", array( 'Cold Plasma', 'ELOS-IPL', 'Spazzola ultrasuono' ) ),
            'drenaggio'      => array( 'Area Drenaggio', 'Leggerezza e benessere', 'Tecnologie studiate per favorire il microcircolo e ridurre la ritenzione idrica.', array( 'Pressoterapia', 'Vacuum pulsante', 'OndaVacu Gym' ) ),
            'rimodellamento' => array( 'Area Silhouette', 'Forma e silhouette', 'Sinergia di tecnologie per trattare adiposità localizzate e ridefinire i contorni.', array( 'Criolipolisi', 'Cavitazione', 'Radiofrequenza', 'Body Shaping Sculpt', 'OndaWave' ) ),
        );
        $lab_data = array();
        foreach ( $lab as $key => $row ) {
            $items = array();
            foreach ( $row[3] as $item ) {
                $items[] = synergy_t( $item, 'tecnologie:lab:item:' . sanitize_title( $item ) );
            }
            $lab_data[ $key ] = array(
                'area'  => synergy_t( $row[0], 'tecnologie:lab:' . $key . ':area' ),
                'title' => synergy_t( $row[1], 'tecnologie:lab:' . $key . ':title' ),
                'desc'  => synergy_t( $row[2], 'tecnologie:lab:' . $key . ':desc' ),
                'items' => $items,
            );
        }
        $i18n['labData'] = $lab_data;
    }

    return $i18n;
}

function synergy_advanced_aesthetics_enqueue_styles() {
    $version = wp_get_theme()->get('Version');

    // Carica lo stile del parent theme (ticinoweb-ai-theme)
    wp_enqueue_style( 'parent-style', get_template_directory_uri() . '/style.css', array(), $version );
    
    // Google Fonts (Cormorant Garamond per heading, Inter per body)
    wp_enqueue_style( 'synergy-fonts', 'https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@400;500;600&family=Inter:wght@300;400;500;600&display=swap', false, null );

    // Carica lo stile base del child theme
    wp_enqueue_style( 'child-style', get_stylesheet_directory_uri() . '/style.css', array( 'parent-style' ), $version );
    
    // Carica stili custom
    $global_css_path = get_stylesheet_directory() . '/assets/css/global.css';
    $global_css_ver  = file_exists($global_css_path) ? filemtime($global_css_path) : $version;
    wp_enqueue_style( 'synergy-global', get_stylesheet_directory_uri() . '/assets/css/global.css', array('child-style'), $global_css_ver );
    
    // Banner cookie del parent ridisegnato come il popup promo (solo CSS)
    $cookie_css_path = get_stylesheet_directory() . '/assets/css/cookie-banner.css';
    $cookie_css_ver  = file_exists($cookie_css_path) ? filemtime($cookie_css_path) : $version;
    wp_enqueue_style( 'synergy-cookie-banner-css', get_stylesheet_directory_uri() . '/assets/css/cookie-banner.css', array('synergy-global'), $cookie_css_ver );

    // Header stili e script
    $header_css_path = get_stylesheet_directory() . '/assets/css/header.css';
    $header_css_ver  = file_exists($header_css_path) ? filemtime($header_css_path) : $version;
    wp_enqueue_style( 'synergy-header-css', get_stylesheet_directory_uri() . '/assets/css/header.css', array('synergy-global'), $header_css_ver );
    
    $header_js_path = get_stylesheet_directory() . '/assets/js/header.js';
    $header_js_ver  = file_exists($header_js_path) ? filemtime($header_js_path) : $version;
    wp_enqueue_script( 'synergy-header-js', get_stylesheet_directory_uri() . '/assets/js/header.js', array('jquery'), $header_js_ver, true );
    // Stringhe visibili usate dai JS del child (tutti dipendono da header.js in ordine di caricamento):
    // tradotte lato PHP con synergy_t, i JS tengono l'italiano come fallback.
    wp_localize_script( 'synergy-header-js', 'synergyI18n', synergy_frontend_i18n() );
    
    if ( class_exists( 'WooCommerce' ) ) {
        wp_enqueue_script( 'wc-cart-fragments' );
    }
    
    // Footer stili
    $footer_css_path = get_stylesheet_directory() . '/assets/css/footer.css';
    $footer_css_ver  = file_exists($footer_css_path) ? filemtime($footer_css_path) : $version;
    wp_enqueue_style( 'synergy-footer-css', get_stylesheet_directory_uri() . '/assets/css/footer.css', array('synergy-global'), $footer_css_ver );
    
    if ( is_front_page() || is_home() || is_page_template('front-page.php') ) {
        $home_css_path = get_stylesheet_directory() . '/assets/css/home.css';
        $home_css_ver  = file_exists($home_css_path) ? filemtime($home_css_path) : $version;
        wp_enqueue_style( 'synergy-home', get_stylesheet_directory_uri() . '/assets/css/home.css', array('synergy-global'), $home_css_ver );
        
        $main_js_path = get_stylesheet_directory() . '/assets/js/main.js';
        $main_js_ver  = file_exists($main_js_path) ? filemtime($main_js_path) : $version;
        wp_enqueue_script( 'synergy-main-js', get_stylesheet_directory_uri() . '/assets/js/main.js', array(), $main_js_ver, true );
        
        // Listino Prezzi assets
        $prezzi_css_path = get_stylesheet_directory() . '/assets/css/prezzi.css';
        $prezzi_css_ver  = file_exists($prezzi_css_path) ? filemtime($prezzi_css_path) : $version;
        wp_enqueue_style( 'synergy-prezzi-css', get_stylesheet_directory_uri() . '/assets/css/prezzi.css', array('synergy-global'), $prezzi_css_ver );
        
        $prezzi_js_path = get_stylesheet_directory() . '/assets/js/prezzi.js';
        $prezzi_js_ver  = file_exists($prezzi_js_path) ? filemtime($prezzi_js_path) : $version;
        wp_enqueue_script( 'synergy-prezzi-js', get_stylesheet_directory_uri() . '/assets/js/prezzi.js', array('jquery'), $prezzi_js_ver, true );
    }
    
    // Treatment Template assets
    if ( is_page_template('template-trattamento.php') ) {
        $treatment_css_path = get_stylesheet_directory() . '/assets/css/treatment.css';
        $treatment_css_ver  = file_exists($treatment_css_path) ? filemtime($treatment_css_path) : $version;
        wp_enqueue_style( 'synergy-treatment-css', get_stylesheet_directory_uri() . '/assets/css/treatment.css', array('synergy-global'), $treatment_css_ver );
        
        $treatment_js_path = get_stylesheet_directory() . '/assets/js/treatment.js';
        $treatment_js_ver  = file_exists($treatment_js_path) ? filemtime($treatment_js_path) : $version;
        wp_enqueue_script( 'synergy-treatment-js', get_stylesheet_directory_uri() . '/assets/js/treatment.js', array(), $treatment_js_ver, true );
    }

    // Trattamenti (indice) Template assets
    if ( is_page_template('template-trattamenti.php') ) {
        $trattamenti_css_path = get_stylesheet_directory() . '/assets/css/trattamenti.css';
        $trattamenti_css_ver  = file_exists($trattamenti_css_path) ? filemtime($trattamenti_css_path) : $version;
        wp_enqueue_style( 'synergy-trattamenti-css', get_stylesheet_directory_uri() . '/assets/css/trattamenti.css', array('synergy-global'), $trattamenti_css_ver );
    }

    // Contatti Template assets
    if ( is_page_template('template-contatti.php') ) {
        $contatti_css_path = get_stylesheet_directory() . '/assets/css/contatti.css';
        $contatti_css_ver  = file_exists($contatti_css_path) ? filemtime($contatti_css_path) : $version;
        wp_enqueue_style( 'synergy-contatti-css', get_stylesheet_directory_uri() . '/assets/css/contatti.css', array('synergy-global'), $contatti_css_ver );
    }
    
    // Chi Siamo Template assets
    if ( is_page_template('template-chi-siamo.php') ) {
        $chisiamo_css_path = get_stylesheet_directory() . '/assets/css/chi-siamo.css';
        $chisiamo_css_ver  = file_exists($chisiamo_css_path) ? filemtime($chisiamo_css_path) : $version;
        wp_enqueue_style( 'synergy-chi-siamo-css', get_stylesheet_directory_uri() . '/assets/css/chi-siamo.css', array('synergy-global'), $chisiamo_css_ver );
    }
    
    // Tecnologie Template assets
    if ( is_page_template('template-tecnologie.php') ) {
        $tecnologie_css_path = get_stylesheet_directory() . '/assets/css/tecnologie.css';
        $tecnologie_css_ver  = file_exists($tecnologie_css_path) ? filemtime($tecnologie_css_path) : $version;
        wp_enqueue_style( 'synergy-tecnologie-css', get_stylesheet_directory_uri() . '/assets/css/tecnologie.css', array('synergy-global'), $tecnologie_css_ver );
        
        $tecnologie_js_path = get_stylesheet_directory() . '/assets/js/tecnologie.js';
        $tecnologie_js_ver  = file_exists($tecnologie_js_path) ? filemtime($tecnologie_js_path) : $version;
        wp_enqueue_script( 'synergy-tecnologie-js', get_stylesheet_directory_uri() . '/assets/js/tecnologie.js', array(), $tecnologie_js_ver, true );
    }
    // Prodotti Template assets
    if ( is_page_template('template-prodotti.php') ) {
        // noUiSlider for price histogram
        wp_enqueue_style( 'nouislider-css', 'https://cdnjs.cloudflare.com/ajax/libs/noUiSlider/15.7.0/nouislider.min.css', array(), '15.7.0' );
        wp_enqueue_script( 'nouislider-js', 'https://cdnjs.cloudflare.com/ajax/libs/noUiSlider/15.7.0/nouislider.min.js', array(), '15.7.0', true );

        $prodotti_css_path = get_stylesheet_directory() . '/assets/css/prodotti.css';
        $prodotti_css_ver  = file_exists($prodotti_css_path) ? filemtime($prodotti_css_path) : $version;
        wp_enqueue_style( 'synergy-prodotti-css', get_stylesheet_directory_uri() . '/assets/css/prodotti.css', array('synergy-global', 'nouislider-css'), $prodotti_css_ver );
        
        $prodotti_js_path = get_stylesheet_directory() . '/assets/js/prodotti.js';
        $prodotti_js_ver  = file_exists($prodotti_js_path) ? filemtime($prodotti_js_path) : $version;
        wp_enqueue_script( 'synergy-prodotti-js', get_stylesheet_directory_uri() . '/assets/js/prodotti.js', array('jquery', 'nouislider-js'), $prodotti_js_ver, true );
        
        // Pass AJAX URL to JS
        wp_localize_script( 'synergy-prodotti-js', 'synergyAjax', array(
            'ajaxurl' => admin_url( 'admin-ajax.php' )
        ));
    }

    // Single Product Template assets
    if ( is_product() || is_singular('product') ) {
        // Enqueue prodotti.css for the related product cards
        $prodotti_css_path = get_stylesheet_directory() . '/assets/css/prodotti.css';
        $prodotti_css_ver  = file_exists($prodotti_css_path) ? filemtime($prodotti_css_path) : $version;
        wp_enqueue_style( 'synergy-prodotti-css', get_stylesheet_directory_uri() . '/assets/css/prodotti.css', array('synergy-global'), $prodotti_css_ver );

        $single_product_css_path = get_stylesheet_directory() . '/assets/css/single-product.css';
        $single_product_css_ver  = file_exists($single_product_css_path) ? filemtime($single_product_css_path) : $version;
        wp_enqueue_style( 'synergy-single-product-css', get_stylesheet_directory_uri() . '/assets/css/single-product.css', array('synergy-global', 'synergy-prodotti-css'), $single_product_css_ver );
        
        $single_product_js_path = get_stylesheet_directory() . '/assets/js/single-product.js';
        $single_product_js_ver  = file_exists($single_product_js_path) ? filemtime($single_product_js_path) : $version;
        wp_enqueue_script( 'synergy-single-product-js', get_stylesheet_directory_uri() . '/assets/js/single-product.js', array('jquery'), $single_product_js_ver, true );
        
        // Pass AJAX URL to JS
        wp_localize_script( 'synergy-single-product-js', 'synergyAjax', array(
            'ajaxurl' => admin_url( 'admin-ajax.php' )
        ));
    }

    // Cart Page assets
    if ( class_exists( 'WooCommerce' ) && is_cart() ) {
        // Enqueue prodotti.css for the cross-sells cards
        $prodotti_css_path = get_stylesheet_directory() . '/assets/css/prodotti.css';
        $prodotti_css_ver  = file_exists($prodotti_css_path) ? filemtime($prodotti_css_path) : $version;
        wp_enqueue_style( 'synergy-prodotti-css', get_stylesheet_directory_uri() . '/assets/css/prodotti.css', array('synergy-global'), $prodotti_css_ver );

        $cart_css_path = get_stylesheet_directory() . '/assets/css/cart.css';
        $cart_css_ver  = file_exists($cart_css_path) ? filemtime($cart_css_path) : $version;
        wp_enqueue_style( 'synergy-cart-css', get_stylesheet_directory_uri() . '/assets/css/cart.css', array('synergy-global', 'synergy-prodotti-css'), $cart_css_ver );
        
        $cart_js_path = get_stylesheet_directory() . '/assets/js/cart.js';
        $cart_js_ver  = file_exists($cart_js_path) ? filemtime($cart_js_path) : $version;
        wp_enqueue_script( 'synergy-cart-js', get_stylesheet_directory_uri() . '/assets/js/cart.js', array('jquery'), $cart_js_ver, true );
    }

    // Checkout Page assets
    if ( class_exists( 'WooCommerce' ) && synergy_is_checkout_context() ) {
        wp_enqueue_style(
            'synergy-checkout-fonts',
            'https://fonts.googleapis.com/css2?family=Cinzel:wght@500;600;700&family=Montserrat:wght@400;500;600;700&display=swap',
            array(),
            null
        );

        $checkout_css_path = get_stylesheet_directory() . '/assets/css/checkout.css';
        $checkout_css_ver  = file_exists($checkout_css_path) ? filemtime($checkout_css_path) : $version;
        wp_enqueue_style( 'synergy-checkout-css', get_stylesheet_directory_uri() . '/assets/css/checkout.css', array( 'synergy-global', 'synergy-checkout-fonts' ), $checkout_css_ver );

        $checkout_js_path = get_stylesheet_directory() . '/assets/js/checkout.js';
        $checkout_js_ver  = file_exists($checkout_js_path) ? filemtime($checkout_js_path) : $version;
        wp_enqueue_script( 'synergy-checkout-js', get_stylesheet_directory_uri() . '/assets/js/checkout.js', array('jquery'), $checkout_js_ver, true );
    }

    // Singolo Articolo Blog
    if ( is_singular( 'post' ) ) {
        $home_css_path = get_stylesheet_directory() . '/assets/css/home.css';
        $home_css_ver  = file_exists( $home_css_path ) ? filemtime( $home_css_path ) : $version;
        wp_enqueue_style( 'synergy-home', get_stylesheet_directory_uri() . '/assets/css/home.css', array( 'synergy-global' ), $home_css_ver );

        $blog_single_css_path = get_stylesheet_directory() . '/assets/css/blog-single.css';
        $blog_single_css_ver  = file_exists( $blog_single_css_path ) ? filemtime( $blog_single_css_path ) : $version;
        wp_enqueue_style( 'synergy-blog-single-css', get_stylesheet_directory_uri() . '/assets/css/blog-single.css', array( 'synergy-global', 'synergy-home' ), $blog_single_css_ver );
    }

    // Promo Popup assets: solo in home page, dove il popup viene renderizzato,
    // e solo se le promozioni sono attive da CMS. Senza il vincolo di pagina
    // questi due file venivano scaricati su tutto il sito senza mai servire.
    if ( is_front_page() && ! get_option( 'ticinoweb_disable_promozioni' ) ) {
        $promo_css_path = get_stylesheet_directory() . '/assets/css/promo-popup.css';
        $promo_css_ver  = file_exists( $promo_css_path ) ? filemtime( $promo_css_path ) : $version;
        wp_enqueue_style( 'synergy-promo-popup-css', get_stylesheet_directory_uri() . '/assets/css/promo-popup.css', array( 'synergy-global' ), $promo_css_ver );

        $promo_js_path = get_stylesheet_directory() . '/assets/js/promo-popup.js';
        $promo_js_ver  = file_exists( $promo_js_path ) ? filemtime( $promo_js_path ) : $version;
        wp_enqueue_script( 'synergy-promo-popup-js', get_stylesheet_directory_uri() . '/assets/js/promo-popup.js', array(), $promo_js_ver, true );
    }
}

// Supporto Tema
function synergy_theme_setup() {
    add_theme_support( 'custom-logo' );
    add_theme_support( 'menus' );
    
    register_nav_menus( array(
        'primary' => esc_html__( 'Primary Menu', 'synergyadvancedesthetics-child-theme' ),
        'footer'  => esc_html__( 'Footer Menu', 'synergyadvancedesthetics-child-theme' ),
    ) );
}
add_action( 'after_setup_theme', 'synergy_theme_setup' );

// Backend logic for Prodotti & Tecnologie
require_once get_stylesheet_directory() . '/inc/cms-prodotti-tecnologie.php';

// Nuova logica Header Megamenu
require_once get_stylesheet_directory() . '/inc/header-megamenu.php';

// Logica AJAX per Catalogo Prodotti
require_once get_stylesheet_directory() . '/inc/ajax-prodotti.php';

// Pagine Legali (Privacy Policy e Cookie Policy)
require_once get_stylesheet_directory() . '/inc/legal-pages.php';

// Gestione dinamica Sezione "IL TEAM"
require_once get_stylesheet_directory() . '/inc/synergy-team-manager.php';

// Seeder articoli Blog / Notizie
require_once get_stylesheet_directory() . '/inc/blog-seeder.php';

// Pop-up Promozioni Dinamico da CMS
require_once get_stylesheet_directory() . '/inc/promo-popup.php';

/**
 * Helper: Formatta gli orari di apertura dal CMS ticinoWEB raggruppando giorni consecutivi con gli stessi orari.
 */
function synergy_get_formatted_hours() {
    $hours = get_option('ticinoweb_contact_opening_hours', array());
    $notes = get_option('ticinoweb_contact_opening_hours_note', '');
    
    if (empty($hours) && empty($notes)) {
        return synergy_t_html( 'Lunedì - Venerdì: 9:30 - 18:30<br>Sabato: su appuntamento<br>Domenica: chiuso', 'hours:fallback' );
    }

    $days_labels = array(
        'monday'    => synergy_t( 'Lunedì', 'hours:day:monday' ),
        'tuesday'   => synergy_t( 'Martedì', 'hours:day:tuesday' ),
        'wednesday' => synergy_t( 'Mercoledì', 'hours:day:wednesday' ),
        'thursday'  => synergy_t( 'Giovedì', 'hours:day:thursday' ),
        'friday'    => synergy_t( 'Venerdì', 'hours:day:friday' ),
        'saturday'  => synergy_t( 'Sabato', 'hours:day:saturday' ),
        'sunday'    => synergy_t( 'Domenica', 'hours:day:sunday' ),
    );

    $formatted_days = array();
    foreach ($days_labels as $day_key => $label) {
        if (isset($hours[$day_key]) && empty($hours[$day_key]['closed']) && !empty($hours[$day_key]['slots'])) {
            $slots_str = array();
            foreach ($hours[$day_key]['slots'] as $slot) {
                if (!empty($slot['open']) && !empty($slot['close'])) {
                    $slots_str[] = $slot['open'] . ' - ' . $slot['close'];
                }
            }
            $formatted_days[$day_key] = implode(', ', $slots_str);
        } else {
            $formatted_days[$day_key] = synergy_t( 'Chiuso', 'hours:closed' );
        }
    }

    // Grouping logic
    $grouped = array();
    $current_group_start = null;
    $current_group_end = null;
    $current_val = null;
    $day_keys = array_keys($days_labels);

    foreach ($day_keys as $key) {
        $val = $formatted_days[$key];
        
        if ($val !== $current_val) {
            if ($current_group_start !== null) {
                $grouped[] = array(
                    'start' => $current_group_start,
                    'end'   => $current_group_end,
                    'val'   => $current_val
                );
            }
            $current_group_start = $key;
            $current_group_end = $key;
            $current_val = $val;
        } else {
            $current_group_end = $key;
        }
    }
    if ($current_group_start !== null) {
        $grouped[] = array(
            'start' => $current_group_start,
            'end'   => $current_group_end,
            'val'   => $current_val
        );
    }

    // Build HTML output
    $output = '';
    foreach ($grouped as $g) {
        if ($g['val'] === 'Chiuso' && count($grouped) > 1 && empty($notes)) {
            // Selezionando di mostrare il "Chiuso" solo se necessario. Qui per ora lo mostriamo.
        }
        
        $start_label = $days_labels[$g['start']];
        $end_label   = $days_labels[$g['end']];
        
        if ($g['start'] === $g['end']) {
            $output .= $start_label . ': ' . strtolower($g['val']) . '<br>';
        } else {
            $output .= $start_label . ' - ' . $end_label . ': ' . strtolower($g['val']) . '<br>';
        }
    }

    if (!empty($notes)) {
        $output .= '<em>' . esc_html($notes) . '</em>';
    }

    return $output;
}

/**
 * Update WooCommerce cart badge count via AJAX fragments
 */
add_filter( 'woocommerce_add_to_cart_fragments', 'synergy_cart_count_fragments', 10, 1 );
function synergy_cart_count_fragments( $fragments ) {
    if ( class_exists( 'WooCommerce' ) ) {
        $cart_count = WC()->cart->get_cart_contents_count();
        $display = ($cart_count == 0) ? 'style="display:none;"' : 'style="display:inline-flex;"';
        $fragments['span.header-cart-badge'] = '<span class="header-cart-badge" ' . $display . '>' . esc_html( $cart_count ) . '</span>';
    }
    return $fragments;
}

/**
 * Personalizza il testo del bottone Aggiungi al carrello nelle schede prodotto
 */
add_filter( 'woocommerce_product_single_add_to_cart_text', 'synergy_custom_add_to_cart_text' );
add_filter( 'woocommerce_product_add_to_cart_text', 'synergy_custom_add_to_cart_text' );
function synergy_custom_add_to_cart_text() {
    return synergy_t( 'Aggiungi al carrello', 'product:add_to_cart' );
}

// Inclusione gestione Listino Prezzi
require_once get_stylesheet_directory() . '/inc/synergy-price-list.php';
require_once get_stylesheet_directory() . '/inc/treatment-price-box.php';
require_once get_stylesheet_directory() . '/inc/price-list-page.php';
require_once get_stylesheet_directory() . '/inc/synergy-avvisi.php';
require_once get_stylesheet_directory() . '/inc/synergy-service-links.php';
require_once get_stylesheet_directory() . '/inc/page-slug-redirects.php';

/* ==========================================
   PERFORMANCE OPTIMIZATIONS (Lighthouse)
========================================== */

// 1. Preconnect Google Fonts
function synergy_preconnect_fonts() {
    echo '<link rel="preconnect" href="https://fonts.googleapis.com">';
    echo '<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>';
}
add_action('wp_head', 'synergy_preconnect_fonts', 1);

// 2. Defer non-critical JavaScript
function synergy_defer_scripts( $tag, $handle, $src ) {
    // Non deferire gli script nel pannello di amministrazione
    if ( is_admin() ) {
        return $tag;
    }
    
    // Escudi jQuery perché molti script inline ne dipendono
    if ( strpos($handle, 'jquery') !== false ) {
        return $tag;
    }
    return str_replace( ' src', ' defer="defer" src', $tag );
}
add_filter( 'script_loader_tag', 'synergy_defer_scripts', 10, 3 );

// 3. Remove Emojis (inutile CSS/JS extra)
function synergy_disable_emojis() {
    remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
    remove_action( 'admin_print_scripts', 'print_emoji_detection_script' );
    remove_action( 'wp_print_styles', 'print_emoji_styles' );
    remove_action( 'admin_print_styles', 'print_emoji_styles' ); 
    remove_filter( 'the_content_feed', 'wp_staticize_emoji' );
    remove_filter( 'comment_text_rss', 'wp_staticize_emoji' ); 
    remove_filter( 'wp_mail', 'wp_staticize_emoji_for_email' );
}
add_action( 'init', 'synergy_disable_emojis' );

// 4. Remove Dashicons per gli utenti non loggati
function synergy_dequeue_dashicons() {
    if ( ! is_user_logged_in() ) {
        wp_deregister_style( 'dashicons' );
    }
}
add_action( 'wp_enqueue_scripts', 'synergy_dequeue_dashicons' );

// 5. Cleanup WP Head (Sicurezza e Performance)
function synergy_cleanup_wp_head() {
    remove_action('wp_head', 'wp_generator'); // Rimuove versione WP
    remove_action('wp_head', 'wlwmanifest_link'); // Rimuove Windows Live Writer
    remove_action('wp_head', 'rsd_link'); // Rimuove EditURI
    remove_action('wp_head', 'rest_output_link_wp_head', 10); // Rimuove link REST API dal head
    remove_action('wp_head', 'wp_oembed_add_discovery_links', 10); // Rimuove oEmbed discovery links
}
add_action('init', 'synergy_cleanup_wp_head');

/* ==========================================
   AUTOMATIC TREATMENT TEMPLATE ASSIGNMENT
========================================== */
function synergy_auto_assign_treatment_template( $template ) {
    if ( is_page() ) {
        $post_id = get_the_ID();
        $slug = get_post_field( 'post_name', $post_id );
        $title = get_the_title( $post_id );
        
        // Escludi pagine principali del sito
        $main_pages = array( 'home', 'front-page', 'trattamenti', 'contatti', 'chi-siamo', 'tecnologie', 'prodotti', 'cart', 'checkout', 'my-account' );
        if ( in_array( $slug, $main_pages ) ) {
            return $template;
        }

        $parent_id = wp_get_post_parent_id( $post_id );
        $parent_title = $parent_id ? get_the_title( $parent_id ) : '';
        
        $is_treatment_page = false;
        
        // Se il genitore è legato ai trattamenti
        if ( $parent_title && ( stripos( $parent_title, 'Trattament' ) !== false || stripos( $parent_title, 'Viso' ) !== false || stripos( $parent_title, 'Corpo' ) !== false || stripos( $parent_title, 'Beauty' ) !== false ) ) {
            $is_treatment_page = true;
        }
        
        // O se il titolo/slug contiene parole chiave dei trattamenti
        $treatment_keywords = array('trattament', 'viso', 'corpo', 'acne', 'anti-age', 'peeling', 'pulizia', 'cellulite', 'tonificazione', 'epilazione', 'laser', 'mani', 'piedi', 'massagg', 'beauty', 'smagliature', 'ciglia', 'sopracciglia', 'laminazione');
        foreach ( $treatment_keywords as $keyword ) {
            if ( stripos( $title, $keyword ) !== false || stripos( $slug, $keyword ) !== false ) {
                $is_treatment_page = true;
                break;
            }
        }
        
        if ( $is_treatment_page ) {
            $current_template = get_page_template_slug( $post_id );
            if ( $current_template !== 'template-trattamento.php' ) {
                update_post_meta( $post_id, '_wp_page_template', 'template-trattamento.php' );
            }
            $custom_template = get_stylesheet_directory() . '/template-trattamento.php';
            if ( file_exists( $custom_template ) ) {
                return $custom_template;
            }
        }
    }
    return $template;
}
add_filter( 'template_include', 'synergy_auto_assign_treatment_template', 99 );

/**
 * Contenuto di fallback elegante per i trattamenti se l'editor WP è vuoto
 */
/**
 * Blocco HTML di default di un trattamento: tradotto per il frontend, grezzo
 * per il seeder che lo scrive come post_content (il contenuto dei post lo
 * traduce già il plugin; persistere una traduzione sarebbe un bug).
 */
function synergy_treatment_default_html( $html, $context, $translate = true ) {
    return $translate ? synergy_t_html( $html, $context ) : $html;
}

function synergy_get_default_treatment_content( $title, $translate = true ) {
    $t_lower = strtolower( $title );
    
    if ( strpos( $t_lower, 'anti-age' ) !== false || strpos( $t_lower, 'anti age' ) !== false ) {
        return synergy_treatment_default_html( '<p>Con il passare del tempo, la pelle del viso perde gradualmente la sua naturale capacità di produrre collagene ed elastina, manifestando i primi segni di cedimento cutaneo, rughe d’espressione e svuotamento dei volumi. Presso Synergy Advanced Aesthetics a Paradiso-Lugano, proponiamo un vero e proprio percorso di rigenerazione tissutale avanzata: un approccio su misura che unisce l’ascolto attento a una diagnosi approfondita della cute. In base alle necessità, integriamo tecnologie estetiche come radiofrequenza ed elettroporazione, cosmeceutici ad altissima concentrazione di principi attivi e prodotti di mantenimento a casa.</p>

<p>L’obiettivo è accompagnare la pelle verso un ripristino naturale del collagene e dell’elastina, per un aspetto più disteso, fresco e compatto, senza stravolgere la naturale espressività del viso. I nostri protocolli integrano trattamenti mirati come programmi di biorivitalizzazione non invasiva, protocolli rassodanti e trattamenti cosmeceutici antietà di alto livello con Mesoestetic ed Ericson. Questa base permette di raccontare il servizio come un percorso mirato, adatto a chi cerca più tono, definizione e vitalità nel viso.</p>

<p>È un trattamento consigliato quando la pelle appare meno tonica, segnata da rughe d’espressione, con perdita di definizione lungo l’ovale del viso o colorito spento. La consulenza iniziale è importante per scegliere intensità, frequenza e combinazione più adatta, soprattutto in caso di pelli particolarmente delicate o mature.</p>

<h4>Punti chiave</h4>
<ul>
  <li>Valutazione iniziale approfondita dello stato cutaneo e delle sue esigenze reali</li>
  <li>Percorsi mirati per rughe, perdita di tono, lassità e contorni del viso</li>
  <li>Possibile integrazione di radiofrequenza, prodotti professionali e tecnologie estetiche</li>
  <li>Routine di mantenimento consigliata per proseguire la cura anche a casa</li>
</ul>', 'treatment:default:anti-age:content', $translate );
    }

    if ( strpos( $t_lower, 'avanzati' ) !== false ) {
        return synergy_treatment_default_html( '<p>Unire la precisione delle più innovative apparecchiature estetiche all’efficacia di formulazioni cosmeceutiche ad alta concentrazione è il cuore del nostro approccio per il viso. I Trattamenti Viso Avanzati rappresentano la risposta su misura per chi desidera risultati visibili e progressivi attraverso una stimolazione profonda dei tessuti. Ogni percorso nasce da un’analisi diagnostica iniziale e combina in modo sinergico tecnologie come radiofrequenza, elettroporazione e fotobiomodulazione con l’eccellenza di brand cosmeceutici leader come Mesoestetic ed Ericson Laboratoire.</p>

<p>L’obiettivo è combinare la massima sinergia tra apparecchiature estetiche all’avanguardia e formulazioni cosmeceutiche ad alta concentrazione di principi attivi. I nostri protocolli integrano trattamenti esclusivi per il rigeneramento cellulare, la rimodellazione dei contorni e il miglioramento della texture cutanea.</p>

<p>È un percorso raccomandato per chi desidera intervenire in modo mirato su inestetismi complessi, perdita di tono marcata o per chi vuole donare al viso una sferzata di giovinezza e compattezza senza ricorrere a metodiche invasive. La consulenza iniziale permette di definire la frequenza e la sequenza di trattamenti più idonea per raggiungere e mantenere il massimo risultato estetico.</p>

<h4>Punti chiave</h4>
<ul>
  <li>Diagnosi e valutazione tissutale iniziale per un protocollo altamente personalizzato</li>
  <li>Integrazione sinergica delle più avanzate tecnologie estetiche per il viso</li>
  <li>Veicolazione profonda di cosmeceutici ad altissima concentrazione di attivi</li>
  <li>Risultati visibili e progressivi su compattezza, tono e luminosità cutanea</li>
</ul>', 'treatment:default:trattamenti-viso-avanzati:content', $translate );
    }

    if ( strpos( $t_lower, 'pulizia' ) !== false ) {
        return synergy_treatment_default_html( '<p>Liberare i pori dalle impurità quotidiane, dall’eccesso di sebo e dall’inquinamento è il gesto fondamentale per far respirare la pelle ed esaltarne la naturale freschezza. Presso Synergy Advanced Aesthetics a Paradiso-Lugano, la pulizia del viso va ben oltre un semplice trattamento di routine: è un vero rito di detersione e benessere tissutale. Attraverso una diagnosi cutanea preventiva, combiniamo detersione profonda, vapore idratante o spremitura igienica delicata, maschere lenitive e sieri ad alta concentrazione.</p>

<p>L’obiettivo è donare al viso un’immediata sensazione di freschezza, traspirazione e luminosità, preparando la pelle a ricevere al meglio i principi attivi dei successivi trattamenti. I nostri protocolli combinano detersione profonda, esfoliazione delicata, maschere lenitive e sieri ad alta concentrazione con prodotti cosmeceutici di eccellenza come Ericson Laboratoire e Mesoestetic.</p>

<p>È un trattamento ideale ad ogni cambio di stagione o come primo fondamentale passaggio prima di intraprendere qualsiasi percorso specifico antietà o purificante. La consulenza iniziale permette di personalizzare la scelta degli attivi e della maschera finale in base alle esigenze di pelli secche, miste o sensibili.</p>

<h4>Punti chiave</h4>
<ul>
  <li>Diagnosi iniziale per una pulizia profonda e personalizzata</li>
  <li>Rimozione delicata di impurità e cellule morte senza traumi</li>
  <li>Ripristino della freschezza cutanea e della naturale luminosità</li>
  <li>Preparazione ottimale della pelle ai trattamenti successivi</li>
</ul>', 'treatment:default:pulizia-viso:content', $translate );
    }

    if ( strpos( $t_lower, 'peeling' ) !== false || strpos( $t_lower, 'rigeneraz' ) !== false ) {
        return synergy_treatment_default_html( '<p>Rinnovare la superficie cutanea ed eliminare il velo di opacità causato dalle cellule morte è il primo vero segreto per restituire al viso una luminosità straordinaria. Il nostro percorso di Peeling e rigenerazione accompagna la pelle attraverso un processo di rinnovamento controllato e mai aggressivo. Partendo da una valutazione attenta dello stato cutaneo, il trattamento seleziona peeling chimici o enzimatici specifici, attivi idratanti e rigeneranti profondi e soluzioni di cura domiciliare.</p>

<p>L’obiettivo è restituire al viso una grana affinata, un incarnato omogeneo ed una spiccata luminosità naturale, riducendo al tempo stesso piccole imperfezioni, pori dilatati e prime rughe sottili. Tra i nostri protocolli integrabili proponiamo trattamenti rigeneranti come Chemical Peelings, Green Peel Fresh Up, soluzioni rigeneranti con acido glicolico o mandelico e programmi cosmeceutici Mesoestetic. Questa base permette di raccontare il servizio come un percorso su misura, adatto a chi cerca una pelle visibilmente rinnovata e levigata.</p>

<p>È un trattamento consigliato ad ogni cambio di stagione, oppure quando la pelle appare opaca, ispessita, segnata da macchie superficiali o colorito disomogeneo. La consulenza iniziale è fondamentale per selezionare il tipo di peeling, l’intensità e la frequenza ideale, garantendo la massima sicurezza ed efficacia anche sulle pelli più sensibili.</p>

<h4>Punti chiave</h4>
<ul>
  <li>Valutazione iniziale della pelle e scelta del tipo di peeling più idoneo</li>
  <li>Azione levigante per affinare la grana cutanea e restringere i pori</li>
  <li>Stimolazione del rinnovamento cellulare per una luminosità immediata</li>
  <li>Protocolli rigeneranti per contrastare macchie e discromie superficiali</li>
</ul>', 'treatment:default:peeling-e-rigenerazione:content', $translate );
    }

    if ( strpos( $t_lower, 'tonificaz' ) !== false ) {
        return synergy_treatment_default_html( '<p>Restituire compattezza, densità ed elasticità ai tessuti che hanno perso il loro naturale sostegno è l’obiettivo centrale per chi desidera un corpo visibilmente più sodo e scolpito. Presso Synergy Advanced Aesthetics a Paradiso-Lugano, il percorso Tonificazione nasce per contrastare la lassità cutanea dovuta a variazioni di peso, avanzamento dell’età o atonia muscolare, combinando la precisione della radiofrequenza multipolare a trattamenti di stimolazione profonda delle fibre di collagene.</p>

<p>L’obiettivo è rimodellare le zone più critiche (come addome, interno cosce, braccia e glutei), promuovendo un immediato effetto lifting e compattante sulle strutture dermiche. I nostri protocolli integrano tecnologie estetiche di ultima generazione ed avvolgenti impacchi rassodanti a base di principi attivi cosmeceutici avanzati firmati da brand leader del settore come Ericson Laboratoire e Mesoestetic.</p>

<p>È un percorso ideale per chi cerca una risposta efficace senza interventi invasivi, per ridefinire i contorni della silhouette e migliorare la grana della pelle. La consulenza iniziale diagnostica permette di personalizzare l’intensità delle tecnologie e la frequenza delle sedute in base al livello di lassità e agli obiettivi desiderati.</p>

<h4>Punti chiave</h4>
<ul>
  <li>Valutazione e diagnosi elastometrica della lassità cutanea e muscolare</li>
  <li>Stimolazione profonda della produzione di nuovo collagene ed elastina</li>
  <li>Azione rimodellante mirata su addome, braccia, glutei e interno cosce</li>
  <li>Risultati progressivi per una pelle visibilmente più soda, densa e compatta</li>
</ul>', 'treatment:default:tonificazione:content', $translate );
    }

    if ( strpos( $t_lower, 'rimodellament' ) !== false ) {
        return synergy_treatment_default_html( '<p>Armonizzare i volumi della silhouette e ridefinire i contorni del corpo attraverso un’azione profonda e mirata sui tessuti rappresenta l’eccellenza della moderna estetica corporea. Presso Synergy Advanced Aesthetics a Paradiso-Lugano, il percorso Trattamenti Corpo & Rimodellamento nasce dall’unione di tecnologie avanzate per il modellamento tissutale e manualità estetiche ad altissima precisione, studiate per risvegliare il metabolismo cutaneo.</p>

<p>L’obiettivo è lavorare in sinergia su adipe localizzato, perdita di definizione e rilassamento cutaneo in aree strategiche come fianchi, addome, cosce e glutei. I nostri protocolli integrano apparecchiature come la radiofrequenza capacitiva e resistiva, la pressoterapia e bendaggi modellanti ad elevata concentrazione di attivi, sfruttando le proprietà di linee cosmeceutiche di prestigio come Mesoestetic ed Ericson Laboratoire.</p>

<p>È un percorso su misura raccomandato a chi desidera una figura più armonica, compattare i tessuti e ridisegnare la silhouette senza metodiche invasive. La consulenza diagnostica iniziale consente di strutturare una sequenza personalizzata di sedute, monitorando progressivamente i risultati ottenuti.</p>

<h4>Punti chiave</h4>
<ul>
  <li>Analisi diagnostica iniziale per un programma di rimodellamento personalizzato</li>
  <li>Azione mirata su adipe localizzato, silhouette e rilassamento dei tessuti</li>
  <li>Sinergia di tecnologie estetiche avanzate e manualità modellanti profonde</li>
  <li>Risultati visibili e progressivi per una figura più armonica e ridefinita</li>
</ul>', 'treatment:default:trattamenti-corpo-rimodellamento:content', $translate );
    }

    if ( strpos( $t_lower, 'dimagrant' ) !== false || strpos( $t_lower, 'snellent' ) !== false ) {
        return synergy_treatment_default_html( '<p>Favorire la riduzione progressiva degli accumuli adiposi localizzati ed accelerare il metabolismo lipolitico è il percorso ideale per chi desidera snellire punti critici e ridefinire i volumi del corpo. Presso Synergy Advanced Aesthetics a Paradiso-Lugano, i Trattamenti Dimagranti uniscono tecnologie dimagranti di ultima generazione a bendaggi termogenici e protocolli snellenti ad alta intensità per risultati visibili e duraturi.</p>

<p>L’obiettivo è agire in profondità sul tessuto adiposo di addome, fianchi, cosce e braccia, stimolando la lipolisi cellulare e riducendo le adiposità che resistono ai normali programmi alimentari o all’attività fisica. I nostri interventi integrano tecnologie come la cavitazione estetica, la radiofrequenza lipolitica e fanghi attivi termo-drenanti avvalendosi dei cosmeceutici avanzati di brand leader come Mesoestetic ed Ericson Laboratoire.</p>

<p>È un percorso raccomandato a chi desidera ritrovare una silhouette più svelta, armoniosa e leggera con un programma professionale non invasivo. La consulenza iniziale è essenziale per misurare la composizione corporea e stabilire un ciclo di sedute personalizzato sulla base degli obiettivi di dimagrimento prefissati.</p>

<h4>Punti chiave</h4>
<ul>
  <li>Valutazione corporea diagnostica ed analisi delle adiposità localizzate</li>
  <li>Stimolazione lipolitica profonda per favorire la riduzione dei centimetri</li>
  <li>Azione snellente e modellante mirata su addome, fianchi e cosce</li>
  <li>Protocolli combinati con apparecchiature avanzate e bendaggi termogenici</li>
</ul>', 'treatment:default:trattamenti-dimagranti:content', $translate );
    }

    if ( strpos( $t_lower, 'smagliatur' ) !== false || strpos( $t_lower, 'cicatric' ) !== false ) {
        return synergy_treatment_default_html( '<p>Rigenerare la trama cutanea e stimolare la sintesi di nuova matrice di collagene ed elastina è la soluzione clinico-estetica fondamentale per attenuare visibilmente smagliature e cicatrici. Presso Synergy Advanced Aesthetics a Paradiso-Lugano, il percorso Smagliature e Cicatrici unisce la precisione del microneedling guidato, peeling rigeneranti ad alta penetrazione e tecnologie di biostimolazione dermica per ristrutturare la pelle in profondità.</p>

<p>L’obiettivo è levigare i tessuti segnati da esiti cicatriziali (inclusi gli esiti post-acneici), rimpolpare le striature da smagliature bianche o rosse su addome, seno, glutei e cosce, e ripristinare un colorito ed una tessitura cutanea uniforme. I nostri protocolli integrano trattamenti avanzati di resurfacing e rigenerazione epidermica come Green Peel, soluzioni schiarenti e ristrutturanti Mesoestetic e sieri biostimolanti ad elevata concentrazione di fattori di crescita.</p>

<p>È un percorso fortemente indicato per chi desidera migliorare l’aspetto estetico di cicatrici vecchie e nuove o smagliature dovute a cambi di peso, gravidanza o crescita. Durante la consulenza diagnostica iniziale, esaminiamo lo stadio e la profondità dei tessuti per calibrare l’intensità delle metodiche e strutturare un piano di rigenerazione progressiva su misura.</p>

<h4>Punti chiave</h4>
<ul>
  <li>Diagnosi approfondita della profondità delle smagliature e tipologia di cicatrici</li>
  <li>Biostimolazione profonda per la produzione di nuovo collagene ed elastina</li>
  <li>Attenuazione evidente di smagliature rosse/bianche ed esiti cicatriziali post-acne</li>
  <li>Protocolli integrati di microneedling, peeling rigeneranti e sieri cosmeceutici</li>
</ul>', 'treatment:default:smagliature-e-cicatrici:content', $translate );
    }

    if ( strpos( $t_lower, 'cigli' ) !== false || strpos( $t_lower, 'sopraccigli' ) !== false ) {
        return synergy_treatment_default_html( '<p>Valorizzare l’espressività dello sguardo e definire l’architettura del volto con trattamenti di precisione è l’arte dedicata alla cura di ciglia e sopracciglia. Presso Synergy Advanced Aesthetics a Paradiso-Lugano, il percorso Ciglia e Sopracciglia unisce la laminazione nutriente alla cheratina, il tinting professionale e lo studio delle proporzioni dell’arcata sopraccigliare per uno sguardo naturalmente aperto, intenso e curato.</p>

<p>L’obiettivo è donare curvatura, lunghezza e corpo alle ciglia naturali senza l’uso di extension artificiali, ed al contempo ridefinire la forma e la densità delle sopracciglia con pigmenti delicati e complessi vitaminici idratanti. I nostri trattamenti sfruttano le proprietà di sieri ristrutturanti avanzati ricchi di cheratina, aminoacidi ed oli nutrienti, garantendo una disciplina ed un ordine impeccabile fino a 6-8 settimane.</p>

<p>È un servizio raccomandato a chi desidera uno sguardo sempre in ordine senza necessità di mascara quotidiano o matite per sopracciglia, oppure a chi vuole rinvigorire ciglia sottili e sfoltite. Durante la seduta, la nostra specialista analizza i tratti somatici del viso per consigliare la curvatura e la tonalità di colore più armonica.</p>

<h4>Punti chiave</h4>
<ul>
  <li>Studio della forma e architettura personalizzata dell’arcata sopraccigliare</li>
  <li>Laminazione ciglia con cheratina e complessi vitaminici per massima curvatura e volume</li>
  <li>Tinting e colorazione professionale per ciglia e sopracciglia sempre definite</li>
  <li>Trattamento idratante e rinforzante per una disciplina naturale fino a 8 settimane</li>
</ul>', 'treatment:default:ciglia-e-sopracciglia:content', $translate );
    }

    if ( strpos( $t_lower, 'epilaz' ) !== false || strpos( $t_lower, 'depilaz' ) !== false ) {
        return synergy_treatment_default_html( '<p>Ottenere una pelle permanentemente liscia, vellutata e priva di peli superflui grazie a tecnologie ad altissima precisione è l’obiettivo della moderna epilazione progressiva. Presso Synergy Advanced Aesthetics a Paradiso-Lugano, il percorso Epilazione Laser & Depilazione combina l’efficacia del laser ad alta potenza con sistemi di raffreddamento integrato per sedute rapide, sicure ed indolori su ogni fototipo cutaneo.</p>

<p>L’obiettivo è neutralizzare alla radice il bulbo pilifero ed interrompere la ricrescita del pelo in modo permanente su zone delicate come viso, ascelle, inguine, braccia, addome e gambe. I nostri protocolli utilizzano apparecchiature laser di ultima generazione ad impulsi controllati, affiancate da tradizionali servizi di depilazione delicata con cere cosmeceutiche lenitive ad azione emolliente.</p>

<p>È la scelta ideale per chi vuole dire addio per sempre a follicoliti, peli incarniti ed alle frequenti rasature quotidiane, garantendo la massima delicatezza anche sulle pelli più sensibili. Durante la consulenza diagnostica iniziale, analizziamo il fototipo e la struttura del pelo per impostare i parametri d’onda ottimali e pianificare un ciclo di sedute personalizzato.</p>

<h4>Punti chiave</h4>
<ul>
  <li>Valutazione del fototipo e del bulbo pilifero prima di iniziare il percorso</li>
  <li>Tecnologia Laser a diodo con sistema di raffreddamento integrato per massimo comfort</li>
  <li>Risultati progressivamente permanenti su ogni zona del corpo e del viso</li>
  <li>Trattamenti indolori, rapidi e sicuri senza rischi di follicolite o peli incarniti</li>
</ul>', 'treatment:default:epilazione-laser-e-depilazione:content', $translate );
    }

    if ( strpos( $t_lower, 'mani' ) !== false || strpos( $t_lower, 'piedi' ) !== false ) {
        return synergy_treatment_default_html( '<p>Dedicare una cura meticolosa ai dettagli del proprio benessere quotidiano attraverso trattamenti estetici di alta precisione è il segreto per mani e piedi sempre perfetti ed una pelle visibilmente curata. Presso Synergy Advanced Aesthetics a Paradiso-Lugano, il percorso Mani, Piedi & Beauty Essentials unisce la bellezza della manicure e pedicure SPA a rituali cosmetici essenziali pensati per esaltare l’armonia naturale di ogni persona.</p>

<p>L’obiettivo è nutrire in profondità le cuticole, levigare la pelle delle mani e dei piedi, eliminare le ruvidezze e definire la lamina ungueale con smalti classici, semipermanenti o gel ad altissima durata. I nostri trattamenti impiegano scrub rigeneranti a base di principi attivi naturali, impacchi emollienti ed oli dermo-affini cosmeceutici, affiancati da essenziali beauty per una bellezza quotidiana senza sforzo.</p>

<p>È un rituale di benessere indispensabile sia per donne che per uomini che desiderano presentarsi sempre con mani ordinate e piedi morbidi, sani e distesi. La nostra specialista personalizza la scelta dei trattamenti e delle tonalità in base alle abitudini personali ed alla sensibilità della pelle.</p>

<h4>Punti chiave</h4>
<ul>
  <li>Manicure e Pedicure SPA con scrub rigeneranti ed idratazione profonda</li>
  <li>Applicazione di smalti tradizionali, semipermanenti e gel ad alta tenuta</li>
  <li>Cura specifica delle cuticole e levigazione della pelle secca o fessurata</li>
  <li>Rituali Beauty Essentials su misura per mani e piedi sempre impeccabili</li>
</ul>', 'treatment:default:mani-piedi-beauty-essentials:content', $translate );
    }

    if ( strpos( $t_lower, 'massagg' ) !== false || strpos( $t_lower, 'benessere' ) !== false ) {
        return synergy_treatment_default_html( '<p>Ritrovare una profonda armonia psico-fisica e sciogliere le tensioni accumulate attraverso manualità avvolgenti e sieri dermo-nutrienti è l’essenza del vero benessere corporeo. Presso Synergy Advanced Aesthetics a Paradiso-Lugano, il percorso Massaggi & Benessere offre un’esperienza olistica rigenerante, dove ogni manovra è studiata per riequilibrare l’energia corporea e donare un sollievo immediato a muscoli e mente.</p>

<p>L’obiettivo è sciogliere le contratture muscolari, favorire il drenaggio linfatico e riattivare la microcircolazione, regalando al contempo una sensazione di assoluta leggerezza e relax. I nostri protocolli integrano massaggi svedesi, decontratturanti, linfodrenanti e rituali aromatici con oli caldi ed essenze naturali prive di allergeni, personalizzati in base allo stato di stress ed alle esigenze specifiche di ciascun ospite.</p>

<p>È il trattamento perfetto per staccare dalla frenesia quotidiana, alleviare la stanchezza fisica o completare un percorso di rimodellamento e tonificazione corpo. Durante il colloquio iniziale, la nostra specialista individua l’approccio manuale e le essenze più idonee per garantire un benessere profondo e duraturo.</p>

<h4>Punti chiave</h4>
<ul>
  <li>Manualità personalizzate (decontratturanti, rilassanti, drenanti e linfatiche)</li>
  <li>Impiego di oli caldi biologici ed essenze aromatiche pure prive di allergeni</li>
  <li>Scioglimento immediato di tensioni muscolari e contratture da stress</li>
  <li>Ripristino dell’equilibrio energetico per mente e corpo in ambiente riservato</li>
</ul>', 'treatment:default:massaggi-e-benessere:content', $translate );
    }

    if ( strpos( $t_lower, 'cellulite' ) !== false || strpos( $t_lower, 'drenagg' ) !== false ) {
        return synergy_treatment_default_html( '<p>Favorire lo smaltimento dei liquidi in eccesso e contrastare gli inestetismi della cellulite è la chiave fondamentale per ritrovare una silhouette svelta, gambe leggere e tessuti visibilmente più tonici. Presso Synergy Advanced Aesthetics a Paradiso-Lugano, il percorso Cellulite e drenaggio unisce l’efficacia delle più moderne tecnologie di stimolazione vascolare e linfatica a manualità rimodellanti profonde e bendaggi funzionali ad alta concentrazione.</p>

<p>L’obiettivo è riattivare la microcircolazione, stimolare il sistema linfatico e ridurre la ritenzione idrica e gli accumuli adiposi localizzati, eliminando la fastidiosa sensazione di pesantezza agli arti inferiori. I nostri protocolli corpo integrano trattamenti avanzati come pressoterapia, radiofrequenza corpo, fangoterapia drenante e programmi cosmetici di precisione avvalendosi delle formulazioni ad alta performance di brand leader come Ericson Laboratoire e Mesoestetic.</p>

<p>È un percorso particolarmente raccomandato nei periodi di forte ritenzione, prima dell’estate o come programma d’urto per ridefinire la grana cutanea e contrastare la pelle a buccia d’arancia. Durante la consulenza iniziale, valutiamo attentamente il tipo di cellulite (edematosa, fibrosa o flaccida) per strutturare un calendario di sedute mirato e personalizzato.</p>

<h4>Punti chiave</h4>
<ul>
  <li>Diagnosi corporea iniziale per individuare lo stadio e la tipologia di cellulite</li>
  <li>Stimolazione profonda della microcircolazione e del microcircolo linfatico</li>
  <li>Riduzione evidente di ritenzione idrica, gonfiore e pelle a buccia d’arancia</li>
  <li>Protocolli integrati con pressoterapia, bendaggi e cosmeceutici specifici</li>
</ul>', 'treatment:default:cellulite-e-drenaggio:content', $translate );
    }

    if ( strpos( $t_lower, 'acne' ) !== false || strpos( $t_lower, 'luminos' ) !== false || strpos( $t_lower, 'macchi' ) !== false ) {
        return synergy_treatment_default_html( '<p>Macchie cutanee, esiti cicatriziali post-acne, pori dilatati ed un colorito disomogeneo richiedono una strategia rigenerante mirata e profonda. Presso il nostro centro, la pelle non viene mai trattata come un problema isolato, ma come un equilibrio naturale da ripristinare: per questo il percorso Acne, Macchie e Luminosità prende vita da un’analisi attenta delle esigenze cutanee, integrando pulizie professionali, peeling schiarenti, cosmetici mirati e tecnologie cosmetiche non invasive.</p>

<p>L’obiettivo è accompagnare la pelle verso un aspetto più uniforme, fresco e luminoso, senza forzare protocolli standardizzati. I nostri protocolli includono trattamenti specifici per acne, macchie e rinnovamento cutaneo, tra cui Acne Peel System, Cosmelan, Chemical Peelings, Green Peel Fresh Up e programmi professionali con Mesoestetic ed Ericson. Questa base permette di raccontare il servizio come un percorso mirato, adatto a chi cerca più ordine, pulizia, omogeneità e vitalità nel viso.</p>

<p>È un trattamento consigliato quando la pelle appare spenta, segnata da imperfezioni, più lucida del solito, irregolare o con macchie superficiali. La consulenza iniziale è importante per scegliere intensità, frequenza e combinazione più adatta, soprattutto in caso di pelle sensibile, acne attiva o discromie evidenti.</p>

<h4>Punti chiave</h4>
<ul>
  <li>Valutazione iniziale della pelle e delle sue esigenze reali</li>
  <li>Percorsi per acne, impurità, macchie, discromie e pelle spenta</li>
  <li>Possibile integrazione di peeling, prodotti professionali e tecnologie estetiche</li>
</ul>', 'treatment:default:acne-macchie-e-luminosita:content', $translate );
    }

    return synergy_treatment_default_html( '<p>Questo percorso è pensato per chi desidera un trattamento personalizzato ed efficace, lavorando sull’armonia e il benessere della pelle e del corpo. Il percorso parte sempre dall’ascolto delle esigenze e da una valutazione attenta dello stato cutaneo o corporeo. In base alla situazione, il trattamento può integrare tecnologie estetiche all’avanguardia, prodotti cosmetici mirati e indicazioni per la cura quotidiana a casa.</p>

<p>L’obiettivo è accompagnare la pelle verso risultati visibili, naturali e duraturi, senza forzare protocolli standardizzati. Questa base permette di raccontare il servizio come un percorso mirato, adatto a chi cerca equilibrio, qualità e risultati reali.</p>

<p>La consulenza iniziale è importante per definire la frequenza, la combinazione di trattamenti e il programma più idoneo per te.</p>

<h4>Punti chiave</h4>
<ul>
  <li>Valutazione iniziale approfondita delle esigenze reali</li>
  <li>Protocolli personalizzati e tecnologie estetiche avanzate</li>
  <li>Integrazione di prodotti professionali e cura domiciliare</li>
</ul>', 'treatment:default:generic:content', $translate );
}

/**
 * Scrive ed aggiorna in modo permanente il testo pulito nel pannello/database di WordPress per la pagina Anti-age
 */
function synergy_persist_antiage_content() {
    $page = get_page_by_path('anti-age');
    if ( ! $page ) {
        $page = get_page_by_path('antiage');
    }
    if ( $page && get_post_meta($page->ID, '_synergy_content_persisted_v4', true) !== 'yes' ) {
        $clean_html = synergy_get_default_treatment_content( 'anti-age', false );
        wp_update_post( array(
            'ID'           => $page->ID,
            'post_content' => $clean_html,
        ) );
        update_post_meta($page->ID, '_synergy_content_persisted_v4', 'yes');
    }

    // Persist per Peeling e rigenerazione
    $peeling_page = get_page_by_path('peeling-e-rigenerazione');
    if ( ! $peeling_page ) {
        $peeling_page = get_page_by_path('peeling');
    }
    if ( $peeling_page && get_post_meta($peeling_page->ID, '_synergy_content_persisted_v4', true) !== 'yes' ) {
        $clean_peeling_html = synergy_get_default_treatment_content( 'peeling-e-rigenerazione', false );
        wp_update_post( array(
            'ID'           => $peeling_page->ID,
            'post_content' => $clean_peeling_html,
        ) );
        update_post_meta($peeling_page->ID, '_synergy_content_persisted_v4', 'yes');
    }

    // Persist per Pulizia viso
    $pulizia_page = get_page_by_path('pulizia-viso');
    if ( ! $pulizia_page ) {
        $pulizia_page = get_page_by_path('puliziaviso');
    }
    if ( $pulizia_page && get_post_meta($pulizia_page->ID, '_synergy_content_persisted_v4', true) !== 'yes' ) {
        $clean_pulizia_html = synergy_get_default_treatment_content( 'pulizia-viso', false );
        wp_update_post( array(
            'ID'           => $pulizia_page->ID,
            'post_content' => $clean_pulizia_html,
        ) );
        update_post_meta($pulizia_page->ID, '_synergy_content_persisted_v4', 'yes');
    }

    // Persist per Trattamenti Viso Avanzati
    $avanzati_page = get_page_by_path('trattamenti-viso-avanzati');
    if ( ! $avanzati_page ) {
        $avanzati_page = get_page_by_path('viso-avanzati');
    }
    if ( $avanzati_page && get_post_meta($avanzati_page->ID, '_synergy_content_persisted_v4', true) !== 'yes' ) {
        $clean_avanzati_html = synergy_get_default_treatment_content( 'trattamenti-viso-avanzati', false );
        wp_update_post( array(
            'ID'           => $avanzati_page->ID,
            'post_content' => $clean_avanzati_html,
        ) );
        update_post_meta($avanzati_page->ID, '_synergy_content_persisted_v4', 'yes');
    }

    // Persist per Acne, macchie e luminosita
    $acne_page = get_page_by_path('acne-macchie-e-luminosita');
    if ( ! $acne_page ) {
        $acne_page = get_page_by_path('acne-macchie-luminosita');
    }
    if ( $acne_page && get_post_meta($acne_page->ID, '_synergy_content_persisted_v4', true) !== 'yes' ) {
        $clean_acne_html = synergy_get_default_treatment_content( 'acne-macchie-e-luminosita', false );
        wp_update_post( array(
            'ID'           => $acne_page->ID,
            'post_content' => $clean_acne_html,
        ) );
        update_post_meta($acne_page->ID, '_synergy_content_persisted_v4', 'yes');
    }

    // Persist per Cellulite e drenaggio
    $cellulite_page = get_page_by_path('cellulite-e-drenaggio');
    if ( ! $cellulite_page ) {
        $cellulite_page = get_page_by_path('cellulite');
    }
    if ( $cellulite_page && get_post_meta($cellulite_page->ID, '_synergy_content_persisted_v4', true) !== 'yes' ) {
        $clean_cellulite_html = synergy_get_default_treatment_content( 'cellulite-e-drenaggio', false );
        wp_update_post( array(
            'ID'           => $cellulite_page->ID,
            'post_content' => $clean_cellulite_html,
        ) );
        update_post_meta($cellulite_page->ID, '_synergy_content_persisted_v4', 'yes');
    }

    // Persist per Tonificazione
    $tonific_page = get_page_by_path('tonificazione');
    if ( ! $tonific_page ) {
        $tonific_page = get_page_by_path('tonificazione-corpo');
    }
    if ( $tonific_page && get_post_meta($tonific_page->ID, '_synergy_content_persisted_v4', true) !== 'yes' ) {
        $clean_tonific_html = synergy_get_default_treatment_content( 'tonificazione', false );
        wp_update_post( array(
            'ID'           => $tonific_page->ID,
            'post_content' => $clean_tonific_html,
        ) );
        update_post_meta($tonific_page->ID, '_synergy_content_persisted_v4', 'yes');
    }

    // Persist per Trattamenti Corpo & Rimodellamento
    $rimodel_page = get_page_by_path('trattamenti-corpo-rimodellamento');
    if ( ! $rimodel_page ) {
        $rimodel_page = get_page_by_path('corpo-rimodellamento');
    }
    if ( ! $rimodel_page ) {
        $rimodel_page = get_page_by_path('rimodellamento');
    }
    if ( $rimodel_page && get_post_meta($rimodel_page->ID, '_synergy_content_persisted_v4', true) !== 'yes' ) {
        $clean_rimodel_html = synergy_get_default_treatment_content( 'trattamenti-corpo-rimodellamento', false );
        wp_update_post( array(
            'ID'           => $rimodel_page->ID,
            'post_content' => $clean_rimodel_html,
        ) );
        update_post_meta($rimodel_page->ID, '_synergy_content_persisted_v4', 'yes');
    }

    // Persist per Trattamenti dimagranti
    $dimagr_page = get_page_by_path('trattamenti-dimagranti');
    if ( ! $dimagr_page ) {
        $dimagr_page = get_page_by_path('dimagranti');
    }
    if ( $dimagr_page && get_post_meta($dimagr_page->ID, '_synergy_content_persisted_v4', true) !== 'yes' ) {
        $clean_dimagr_html = synergy_get_default_treatment_content( 'trattamenti-dimagranti', false );
        wp_update_post( array(
            'ID'           => $dimagr_page->ID,
            'post_content' => $clean_dimagr_html,
        ) );
        update_post_meta($dimagr_page->ID, '_synergy_content_persisted_v4', 'yes');
    }

    // Persist per Smagliature e cicatrici
    $smagliat_page = get_page_by_path('smagliature-e-cicatrici');
    if ( ! $smagliat_page ) {
        $smagliat_page = get_page_by_path('smagliature-cicatrici');
    }
    if ( ! $smagliat_page ) {
        $smagliat_page = get_page_by_path('smagliature');
    }
    if ( $smagliat_page && get_post_meta($smagliat_page->ID, '_synergy_content_persisted_v4', true) !== 'yes' ) {
        $clean_smagliat_html = synergy_get_default_treatment_content( 'smagliature-e-cicatrici', false );
        wp_update_post( array(
            'ID'           => $smagliat_page->ID,
            'post_content' => $clean_smagliat_html,
        ) );
        update_post_meta($smagliat_page->ID, '_synergy_content_persisted_v4', 'yes');
    }

    // Persist per Ciglia e sopracciglia
    $ciglia_page = get_page_by_path('ciglia-e-sopracciglia');
    if ( ! $ciglia_page ) {
        $ciglia_page = get_page_by_path('ciglia-sopracciglia');
    }
    if ( ! $ciglia_page ) {
        $ciglia_page = get_page_by_path('ciglia');
    }
    if ( $ciglia_page && get_post_meta($ciglia_page->ID, '_synergy_content_persisted_v5', true) !== 'yes' ) {
        $clean_ciglia_html = synergy_get_default_treatment_content( 'ciglia-e-sopracciglia', false );
        wp_update_post( array(
            'ID'           => $ciglia_page->ID,
            'post_content' => $clean_ciglia_html,
        ) );
        update_post_meta($ciglia_page->ID, '_synergy_content_persisted_v5', 'yes');
    }

    // Persist per Epilazione Laser & Depilazione
    $epilaz_page = get_page_by_path('epilazione-laser-e-depilazione');
    if ( ! $epilaz_page ) {
        $epilaz_page = get_page_by_path('epilazione-laser');
    }
    if ( ! $epilaz_page ) {
        $epilaz_page = get_page_by_path('epilazione');
    }
    if ( $epilaz_page && get_post_meta($epilaz_page->ID, '_synergy_content_persisted_v4', true) !== 'yes' ) {
        $clean_epilaz_html = synergy_get_default_treatment_content( 'epilazione-laser-e-depilazione', false );
        wp_update_post( array(
            'ID'           => $epilaz_page->ID,
            'post_content' => $clean_epilaz_html,
        ) );
        update_post_meta($epilaz_page->ID, '_synergy_content_persisted_v4', 'yes');
    }

    // Persist per Mani, Piedi & Beauty Essentials
    $manipiedi_page = get_page_by_path('mani-piedi-beauty-essentials');
    if ( ! $manipiedi_page ) {
        $manipiedi_page = get_page_by_path('mani-piedi-e-beauty-essentials');
    }
    if ( ! $manipiedi_page ) {
        $manipiedi_page = get_page_by_path('mani-piedi');
    }
    if ( $manipiedi_page && get_post_meta($manipiedi_page->ID, '_synergy_content_persisted_v5', true) !== 'yes' ) {
        $clean_manipiedi_html = synergy_get_default_treatment_content( 'mani-piedi-beauty-essentials', false );
        wp_update_post( array(
            'ID'           => $manipiedi_page->ID,
            'post_content' => $clean_manipiedi_html,
        ) );
        update_post_meta($manipiedi_page->ID, '_synergy_content_persisted_v5', 'yes');
    }

    // Persist per Massaggi & Benessere
    $massaggi_page = get_page_by_path('massaggi-e-benessere');
    if ( ! $massaggi_page ) {
        $massaggi_page = get_page_by_path('massaggi-benessere');
    }
    if ( ! $massaggi_page ) {
        $massaggi_page = get_page_by_path('massaggi');
    }
    if ( $massaggi_page && get_post_meta($massaggi_page->ID, '_synergy_content_persisted_v5', true) !== 'yes' ) {
        $clean_massaggi_html = synergy_get_default_treatment_content( 'massaggi-e-benessere', false );
        wp_update_post( array(
            'ID'           => $massaggi_page->ID,
            'post_content' => $clean_massaggi_html,
        ) );
        update_post_meta($massaggi_page->ID, '_synergy_content_persisted_v5', 'yes');
    }
}
add_action( 'init', 'synergy_persist_antiage_content' );

/**
 * Copia automaticamente le immagini Hero generate nella cartella wp-content/uploads/treatment-heroes/
 */
function synergy_auto_copy_treatment_images() {
    $upload_dir = wp_upload_dir();
    $target_dir = $upload_dir['basedir'] . '/treatment-heroes/';
    if ( ! file_exists( $target_dir ) ) {
        wp_mkdir_p( $target_dir );
    }
    
    $source_peeling     = '/Users/marketing/.gemini/antigravity-ide/brain/1e0cd677-341e-4167-8366-fc9efe25b623/peeling_rigenerazione_treatment_1785842275599.png';
    $source_antiage     = '/Users/marketing/.gemini/antigravity-ide/brain/1e0cd677-341e-4167-8366-fc9efe25b623/antiage_treatment_1785834627495.png';
    $source_acne        = '/Users/marketing/.gemini/antigravity-ide/brain/1e0cd677-341e-4167-8366-fc9efe25b623/acne_luminosita_treatment_1785832494434.png';
    $source_pulizia     = '/Users/marketing/.gemini/antigravity-ide/brain/1e0cd677-341e-4167-8366-fc9efe25b623/pulizia_viso_treatment_v5_1785850879639.png';
    $source_avanzati    = '/Users/marketing/.gemini/antigravity-ide/brain/1e0cd677-341e-4167-8366-fc9efe25b623/trattamenti_viso_avanzati_treatment_1785844295411.png';
    $source_cellulite   = '/Users/marketing/.gemini/antigravity-ide/brain/1e0cd677-341e-4167-8366-fc9efe25b623/cellulite_drenaggio_treatment_1785845539533.png';
    $source_tonific     = '/Users/marketing/.gemini/antigravity-ide/brain/1e0cd677-341e-4167-8366-fc9efe25b623/tonificazione_treatment_v2_1785846455259.png';
    $source_rimodel     = '/Users/marketing/.gemini/antigravity-ide/brain/1e0cd677-341e-4167-8366-fc9efe25b623/corpo_rimodellamento_treatment_1785846716516.png';
    $source_dimagr      = '/Users/marketing/.gemini/antigravity-ide/brain/1e0cd677-341e-4167-8366-fc9efe25b623/trattamenti_dimagranti_treatment_v4_1785847747596.png';
    $source_smagliat    = '/Users/marketing/.gemini/antigravity-ide/brain/1e0cd677-341e-4167-8366-fc9efe25b623/smagliature_cicatrici_treatment_1785848053403.png';
    $source_ciglia      = '/Users/marketing/.gemini/antigravity-ide/brain/1e0cd677-341e-4167-8366-fc9efe25b623/ciglia_sopracciglia_treatment_v3_1785849078628.png';
    $source_epilaz      = '/Users/marketing/.gemini/antigravity-ide/brain/1e0cd677-341e-4167-8366-fc9efe25b623/epilazione_laser_treatment_1785849422528.png';
    $source_manipiedi   = '/Users/marketing/.gemini/antigravity-ide/brain/1e0cd677-341e-4167-8366-fc9efe25b623/mani_piedi_beauty_treatment_1785849878996.png';
    $source_massaggi    = '/Users/marketing/.gemini/antigravity-ide/brain/1e0cd677-341e-4167-8366-fc9efe25b623/massaggi_benessere_treatment_v2_1785850575176.png';
    
    if ( file_exists( $source_peeling ) ) {
        copy( $source_peeling, $target_dir . 'peeling.png' );
    }
    if ( file_exists( $source_antiage ) ) {
        copy( $source_antiage, $target_dir . 'antiage.png' );
    }
    if ( file_exists( $source_acne ) ) {
        copy( $source_acne, $target_dir . 'acne.png' );
    }
    if ( file_exists( $source_pulizia ) ) {
        copy( $source_pulizia, $target_dir . 'pulizia.png' );
    }
    if ( file_exists( $source_avanzati ) ) {
        copy( $source_avanzati, $target_dir . 'avanzati.png' );
    }
    if ( file_exists( $source_cellulite ) ) {
        copy( $source_cellulite, $target_dir . 'cellulite.png' );
    }
    if ( file_exists( $source_tonific ) ) {
        copy( $source_tonific, $target_dir . 'tonificazione.png' );
    }
    if ( file_exists( $source_rimodel ) ) {
        copy( $source_rimodel, $target_dir . 'rimodellamento.png' );
    }
    if ( file_exists( $source_dimagr ) ) {
        copy( $source_dimagr, $target_dir . 'dimagranti.png' );
    }
    if ( file_exists( $source_smagliat ) ) {
        copy( $source_smagliat, $target_dir . 'smagliature.png' );
    }
    if ( file_exists( $source_ciglia ) ) {
        copy( $source_ciglia, $target_dir . 'ciglia.png' );
    }
    if ( file_exists( $source_epilaz ) ) {
        copy( $source_epilaz, $target_dir . 'epilazione.png' );
    }
    if ( file_exists( $source_manipiedi ) ) {
        copy( $source_manipiedi, $target_dir . 'mani.png' );
    }
    if ( file_exists( $source_massaggi ) ) {
        copy( $source_massaggi, $target_dir . 'massaggi.png' );
    }
}
add_action( 'init', 'synergy_auto_copy_treatment_images' );

/**
 * Registrazione Metabox per la personalizzazione da Admin WordPress (4 Step & FAQ)
 */
function synergy_register_treatment_metaboxes() {
    add_meta_box(
        'synergy_treatment_customization',
        '✨ Personalizzazione Pagina Trattamento (4 Step & FAQ)',
        'synergy_render_treatment_metabox',
        'page',
        'normal',
        'high'
    );
}
add_action( 'add_meta_boxes', 'synergy_register_treatment_metaboxes' );

function synergy_render_treatment_metabox( $post ) {
    wp_nonce_field( 'synergy_save_treatment_meta', 'synergy_treatment_meta_nonce' );

    // Valori salvati o default
    $proc_title = get_post_meta( $post->ID, '_synergy_process_title', true );
    $proc_desc  = get_post_meta( $post->ID, '_synergy_process_desc', true );
    
    $s1_t = get_post_meta( $post->ID, '_synergy_step1_title', true );
    $s1_c = get_post_meta( $post->ID, '_synergy_step1_text', true );
    $s2_t = get_post_meta( $post->ID, '_synergy_step2_title', true );
    $s2_c = get_post_meta( $post->ID, '_synergy_step2_text', true );
    $s3_t = get_post_meta( $post->ID, '_synergy_step3_title', true );
    $s3_c = get_post_meta( $post->ID, '_synergy_step3_text', true );
    $s4_t = get_post_meta( $post->ID, '_synergy_step4_title', true );
    $s4_c = get_post_meta( $post->ID, '_synergy_step4_text', true );

    $faq_title = get_post_meta( $post->ID, '_synergy_faq_title', true );
    $f1_q = get_post_meta( $post->ID, '_synergy_faq1_q', true );
    $f1_a = get_post_meta( $post->ID, '_synergy_faq1_a', true );
    $f2_q = get_post_meta( $post->ID, '_synergy_faq2_q', true );
    $f2_a = get_post_meta( $post->ID, '_synergy_faq2_a', true );
    $f3_q = get_post_meta( $post->ID, '_synergy_faq3_q', true );
    $f3_a = get_post_meta( $post->ID, '_synergy_faq3_a', true );
    ?>
    <style>
        .synergy-meta-group { margin-bottom: 25px; padding: 18px; background: #faf9f7; border: 1px solid #e2ded9; border-radius: 8px; }
        .synergy-meta-group h3 { margin-top: 0; color: #1a1a1a; font-size: 16px; border-bottom: 1px solid #d5cfc7; padding-bottom: 8px; }
        .synergy-field-row { margin-bottom: 12px; }
        .synergy-field-row label { display: block; font-weight: 600; margin-bottom: 4px; color: #444; }
        .synergy-field-row input[type="text"], .synergy-field-row textarea { width: 100%; padding: 8px 12px; border: 1px solid #ccc; border-radius: 4px; }
        .synergy-grid-2 { display: grid; grid-template-columns: 1fr 1fr; gap: 15px; }
    </style>

    <div class="synergy-meta-group">
        <h3>1. Sezione "Un percorso costruito intorno a te" (4 Step)</h3>
        <div class="synergy-field-row">
            <label for="_synergy_process_title">Titolo Principale Sezione:</label>
            <input type="text" id="_synergy_process_title" name="_synergy_process_title" value="<?php echo esc_attr( $proc_title ); ?>" placeholder="Default: Un percorso costruito intorno a te.">
        </div>
        <div class="synergy-field-row">
            <label for="_synergy_process_desc">Sottotitolo / Descrizione:</label>
            <textarea id="_synergy_process_desc" name="_synergy_process_desc" rows="2" placeholder="Default: Ogni trattamento viene scelto con attenzione, partendo dall’ascolto delle tue esigenze..."><?php echo esc_textarea( $proc_desc ); ?></textarea>
        </div>

        <div class="synergy-grid-2">
            <div class="synergy-field-row">
                <label>Step 01 - Titolo:</label>
                <input type="text" name="_synergy_step1_title" value="<?php echo esc_attr( $s1_t ); ?>" placeholder="Default: Ascolto">
                <label style="margin-top:6px;">Step 01 - Testo:</label>

                <textarea name="_synergy_step1_text" rows="2" placeholder="Default: Comprendiamo le tue esigenze..."><?php echo esc_textarea( $s1_c ); ?></textarea>
            </div>
            <div class="synergy-field-row">
                <label>Step 02 - Titolo:</label>
                <input type="text" name="_synergy_step2_title" value="<?php echo esc_attr( $s2_t ); ?>" placeholder="Default: Valutazione">
                <label style="margin-top:6px;">Step 02 - Testo:</label>
                <textarea name="_synergy_step2_text" rows="2" placeholder="Default: Analizziamo il percorso più adatto..."><?php echo esc_textarea( $s2_c ); ?></textarea>
            </div>
            <div class="synergy-field-row">
                <label>Step 03 - Titolo:</label>
                <input type="text" name="_synergy_step3_title" value="<?php echo esc_attr( $s3_t ); ?>" placeholder="Default: Trattamento">
                <label style="margin-top:6px;">Step 03 - Testo:</label>
                <textarea name="_synergy_step3_text" rows="2" placeholder="Default: Applichiamo manualità, tecnologie avanzate..."><?php echo esc_textarea( $s3_c ); ?></textarea>
            </div>
            <div class="synergy-field-row">
                <label>Step 04 - Titolo:</label>
                <input type="text" name="_synergy_step4_title" value="<?php echo esc_attr( $s4_t ); ?>" placeholder="Default: Continuità">
                <label style="margin-top:6px;">Step 04 - Testo:</label>
                <textarea name="_synergy_step4_text" rows="2" placeholder="Default: Ti consigliamo i passaggi migliori..."><?php echo esc_textarea( $s4_c ); ?></textarea>
            </div>
        </div>
    </div>

    <div class="synergy-meta-group">
        <h3>2. Sezione "Informazioni utili" (FAQ / Domande Frequenti)</h3>
        <div class="synergy-field-row">
            <label for="_synergy_faq_title">Titolo Sezione FAQ:</label>
            <input type="text" id="_synergy_faq_title" name="_synergy_faq_title" value="<?php echo esc_attr( $faq_title ); ?>" placeholder="Default: Informazioni utili">
        </div>

        <div class="synergy-field-row">
            <label>Domanda 1:</label>
            <input type="text" name="_synergy_faq1_q" value="<?php echo esc_attr( $f1_q ); ?>" placeholder="Default: Come scelgo il trattamento più adatto?">
            <label style="margin-top:6px;">Risposta 1:</label>
            <textarea name="_synergy_faq1_a" rows="2" placeholder="Default: Ogni trattamento viene valutato in base alle esigenze..."><?php echo esc_textarea( $f1_a ); ?></textarea>
        </div>

        <div class="synergy-field-row">
            <label>Domanda 2:</label>
            <input type="text" name="_synergy_faq2_q" value="<?php echo esc_attr( $f2_q ); ?>" placeholder="Default: I risultati sono uguali per tutti?">
            <label style="margin-top:6px;">Risposta 2:</label>
            <textarea name="_synergy_faq2_a" rows="2" placeholder="Default: Ogni persona è unica. Il nostro centro non promette..."><?php echo esc_textarea( $f2_a ); ?></textarea>
        </div>

        <div class="synergy-field-row">
            <label>Domanda 3:</label>
            <input type="text" name="_synergy_faq3_q" value="<?php echo esc_attr( $f3_q ); ?>" placeholder="Default: Posso richiedere un appuntamento online?">
            <label style="margin-top:6px;">Risposta 3:</label>
            <textarea name="_synergy_faq3_a" rows="2" placeholder="Default: Sì, puoi inviare una richiesta di appuntamento..."><?php echo esc_textarea( $f3_a ); ?></textarea>
        </div>
    </div>
    <?php
}

function synergy_save_treatment_meta( $post_id ) {
    if ( ! isset( $_POST['synergy_treatment_meta_nonce'] ) || ! wp_verify_nonce( $_POST['synergy_treatment_meta_nonce'], 'synergy_save_treatment_meta' ) ) {
        return;
    }
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
        return;
    }
    if ( ! current_user_can( 'edit_page', $post_id ) ) {
        return;
    }

    $fields = array(
        '_synergy_process_title', '_synergy_process_desc',
        '_synergy_step1_title', '_synergy_step1_text',
        '_synergy_step2_title', '_synergy_step2_text',
        '_synergy_step3_title', '_synergy_step3_text',
        '_synergy_step4_title', '_synergy_step4_text',
        '_synergy_faq_title',
        '_synergy_faq1_q', '_synergy_faq1_a',
        '_synergy_faq2_q', '_synergy_faq2_a',
        '_synergy_faq3_q', '_synergy_faq3_a',
    );

    foreach ( $fields as $field ) {
        if ( isset( $_POST[ $field ] ) ) {
            update_post_meta( $post_id, $field, sanitize_text_field( $_POST[ $field ] ) );
        }
    }
}
add_action( 'save_post', 'synergy_save_treatment_meta' );

// Redirect WooCommerce return to shop links to custom /prodotti/ page
add_filter( 'woocommerce_return_to_shop_redirect', function() {
    return home_url( '/prodotti/' );
} );

// Disable WooCommerce Coming Soon mode & Theme Maintenance mode completely
add_filter( 'woocommerce_coming_soon_exclude', '__return_true', 999 );
add_filter( 'option_woocommerce_coming_soon', '__return_null', 999 );
add_filter( 'option_ticinoweb_maintenance_mode', '__return_false', 999 );

add_action( 'init', function() {
    if ( get_option( 'woocommerce_coming_soon' ) === 'yes' ) {
        update_option( 'woocommerce_coming_soon', 'no' );
    }
    if ( get_option( 'ticinoweb_maintenance_mode' ) ) {
        update_option( 'ticinoweb_maintenance_mode', 0 );
    }
}, 1 );

// Suppress native WooCommerce notice banner generation for coupon errors in checkout
add_filter( 'woocommerce_add_error', function( $error ) {
    if ( synergy_is_checkout_context() && ( strpos( strtolower( $error ), 'coupon' ) !== false || strpos( strtolower( $error ), 'codice' ) !== false || strpos( strtolower( $error ), 'promozionale' ) !== false || strpos( strtolower( $error ), 'non esiste' ) !== false || strpos( strtolower( $error ), 'inserire' ) !== false ) ) {
        return '';
    }
    return $error;
}, 999 );

// Change coupon label in checkout to match cart ("Sconto promozionale")
add_filter( 'woocommerce_cart_totals_coupon_label', function( $label, $coupon ) {
    return synergy_t( 'Sconto promozionale', 'checkout:coupon_label' );
}, 10, 2 );
