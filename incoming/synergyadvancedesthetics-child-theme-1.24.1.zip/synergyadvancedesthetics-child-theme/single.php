<?php
/**
 * The template for displaying all single blog posts
 *
 * @package SynergyAdvancedAesthetics
 */

get_header();
?>

<main id="primary" class="site-main synergy-blog-single-main">
    
    <?php while ( have_posts() ) : the_post(); 
        $categories   = get_the_category();
        $cat_name     = ! empty( $categories ) ? $categories[0]->name : synergy_t( 'Consigli di Bellezza', 'single:category_fallback' );
        $has_thumb    = has_post_thumbnail();
        $thumb_url    = $has_thumb ? get_the_post_thumbnail_url( get_the_ID(), 'full' ) : '';
        $word_count   = str_word_count( wp_strip_all_tags( get_the_content() ) );
        $reading_time = max( 1, ceil( $word_count / 200 ) );
    ?>

    <!-- ARTICLE HEADER / HERO -->
    <article id="post-<?php the_ID(); ?>" <?php post_class('synergy-blog-single-article'); ?>>
        
        <header class="blog-single-header">
            <div class="container">
                <div class="blog-header-inner text-center">
                    
                    <!-- Back Link & Category -->
                    <div class="blog-header-top-meta">
                        <a href="<?php echo esc_url( home_url( '/#blog' ) ); ?>" class="blog-back-btn">
                            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="19" y1="12" x2="5" y2="12"></line><polyline points="12 19 5 12 12 5"></polyline></svg>
                            <span><?php echo esc_html( synergy_t( 'Torna al Blog', 'single:back_to_blog' ) ); ?></span>
                        </a>
                        <span class="blog-single-badge"><?php echo esc_html( $cat_name ); ?></span>
                    </div>

                    <!-- Article Title -->
                    <h1 class="blog-single-title"><?php the_title(); ?></h1>

                    <!-- Meta Details -->
                    <div class="blog-single-meta">
                        <div class="meta-item">
                            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line></svg>
                            <span><?php echo get_the_date( 'd F Y' ); ?></span>
                        </div>
                        <span class="meta-sep">•</span>
                        <div class="meta-item">
                            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 16 14"></polyline></svg>
                            <span><?php echo esc_html( sprintf( synergy_t( '%d min di lettura', 'single:meta:reading_time' ), (int) $reading_time ) ); ?></span>
                        </div>
                        <span class="meta-sep">•</span>
                        <div class="meta-item">
                            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>
                            <span>Synergy Advanced Aesthetics</span>
                        </div>
                    </div>

                </div>
            </div>
        </header>

        <!-- FEATURED COVER IMAGE -->
        <div class="blog-single-cover-section">
            <div class="container">
                <div class="blog-cover-wrapper">
                    <?php if ( $has_thumb ) : ?>
                        <img src="<?php echo esc_url( $thumb_url ); ?>" alt="<?php the_title_attribute(); ?>" class="blog-cover-img" />
                    <?php else : ?>
                        <div class="blog-cover-placeholder">
                            <div class="cover-placeholder-glow"></div>
                            <div class="cover-placeholder-pattern"></div>
                            <div class="cover-placeholder-content">
                                <div class="placeholder-monogram">
                                    <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.2"><path d="M12 2L2 7l10 5 10-5-10-5z"/><path d="M2 17l10 5 10-5"/><path d="M2 12l10 5 10-5"/></svg>
                                </div>
                                <span class="placeholder-brand">SYNERGY ADVANCED AESTHETICS</span>
                                <span class="placeholder-cat"><?php echo esc_html( $cat_name ); ?></span>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- ARTICLE BODY -->
        <div class="blog-single-body-section">
            <div class="container">
                <div class="blog-content-wrapper">
                    
                    <div class="entry-content blog-post-content">
                        <?php the_content(); ?>
                    </div>

                    <!-- SHARE & FOOTER OF POST -->
                    <div class="blog-post-share-card">
                        <div class="share-prompt">
                            <h4><?php echo esc_html( synergy_t( 'Ti è piaciuto questo articolo?', 'single:cta:title' ) ); ?></h4>
                            <p><?php echo esc_html( synergy_t( 'Condividi i consigli di bellezza con chi ami o prenota una consulenza con le nostre specialiste.', 'single:cta:text' ) ); ?></p>
                        </div>
                        <div class="share-actions">
                            <a href="<?php echo esc_url( home_url( '/#contatti' ) ); ?>" class="btn btn-primary">
                                <span><?php echo esc_html( synergy_t( 'Prenota una Consulenza', 'single:cta:button' ) ); ?></span>
                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg>
                            </a>
                        </div>
                    </div>

                </div>
            </div>
        </div>

    </article>
    <?php endwhile; ?>

    <!-- RELATED POSTS SECTION -->
    <?php
    $current_id = get_the_ID();
    $related_query = new WP_Query( array(
        'post_type'      => 'post',
        'posts_per_page' => 3,
        'post__not_in'   => array( $current_id ),
        'post_status'    => 'publish',
        'orderby'        => 'date',
        'order'          => 'DESC',
    ) );

    if ( $related_query->have_posts() ) : ?>
        <section class="blog-related-section section">
            <div class="container">
                <div class="related-header text-center">
                    <span class="section-eyebrow"><?php echo esc_html( synergy_t( 'CONTINUA A LEGGERE', 'single:related:eyebrow' ) ); ?></span>
                    <h2 class="related-title"><?php echo esc_html( synergy_t( 'Altri articoli e consigli di bellezza', 'single:related:title' ) ); ?></h2>
                </div>

                <div class="synergy-blog-grid">
                    <?php 
                    $rel_idx = 0;
                    while ( $related_query->have_posts() ) : $related_query->the_post(); 
                        $rel_idx++;
                        $rel_cats     = get_the_category();
                        $rel_cat_name = ! empty( $rel_cats ) ? $rel_cats[0]->name : synergy_t( 'Bellezza & Benessere', 'single:related:category_fallback' );
                        $rel_thumb    = has_post_thumbnail() ? get_the_post_thumbnail_url( get_the_ID(), 'large' ) : '';
                        $rel_read     = max( 1, ceil( str_word_count( wp_strip_all_tags( get_the_content() ) ) / 200 ) );
                        ?>
                        <article class="synergy-blog-card">
                            <a href="<?php the_permalink(); ?>" class="blog-card-thumb-link" aria-label="<?php the_title_attribute(); ?>">
                                <div class="blog-card-thumb-wrapper">
                                    <?php if ( $rel_thumb ) : ?>
                                        <div class="blog-card-thumb" style="background-image: url('<?php echo esc_url( $rel_thumb ); ?>');"></div>
                                    <?php else : ?>
                                        <div class="blog-card-thumb blog-thumb-placeholder">
                                            <div class="thumb-pattern"></div>
                                            <span class="placeholder-icon">
                                                <svg width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M12 2L2 7l10 5 10-5-10-5z"/><path d="M2 17l10 5 10-5"/><path d="M2 12l10 5 10-5"/></svg>
                                            </span>
                                        </div>
                                    <?php endif; ?>
                                    <span class="blog-card-badge"><?php echo esc_html( $rel_cat_name ); ?></span>
                                </div>
                            </a>

                            <div class="blog-card-body">
                                <div class="blog-card-meta">
                                    <span class="blog-date">
                                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line></svg>
                                        <?php echo get_the_date( 'd M Y' ); ?>
                                    </span>
                                    <span class="blog-meta-sep">•</span>
                                    <span class="blog-read-time"><?php echo esc_html( sprintf( synergy_t( '%d min', 'single:related:reading_time' ), (int) $rel_read ) ); ?></span>
                                </div>

                                <h3 class="blog-card-title">
                                    <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                                </h3>

                                <p class="blog-card-excerpt">
                                    <?php echo esc_html( wp_trim_words( get_the_excerpt() ?: get_the_content(), 16, '…' ) ); ?>
                                </p>

                                <div class="blog-card-footer">
                                    <a href="<?php the_permalink(); ?>" class="blog-read-more">
                                        <span><?php echo esc_html( synergy_t( 'Leggi l\'articolo', 'single:related:read_more' ) ); ?></span>
                                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg>
                                    </a>
                                </div>
                            </div>
                        </article>
                    <?php endwhile; ?>
                </div>
            </div>
        </section>
    <?php 
    wp_reset_postdata();
    endif; 
    ?>

</main>

<?php
get_footer();
