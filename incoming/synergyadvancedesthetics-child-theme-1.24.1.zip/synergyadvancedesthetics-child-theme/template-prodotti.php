<?php
/**
 * Template Name: Prodotti
 */

get_header();

// Fetch initial data for SSR & Filters
$paged = max( 1, get_query_var('paged') );
$initial_args = array(
    'post_type'      => 'product',
    'post_status'    => 'publish',
    'posts_per_page' => 24,
    'paged'          => $paged,
    'orderby'        => 'menu_order date',
    'order'          => 'DESC'
);
$initial_query = new WP_Query( $initial_args );

// Fetch terms for filters
$categories = get_terms( array( 'taxonomy' => 'product_cat', 'hide_empty' => true ) );
$brands     = get_terms( array( 'taxonomy' => 'product_brand', 'hide_empty' => true ) );

// Fetch max price for slider
global $wpdb;
$max_price = $wpdb->get_var( "
    SELECT MAX(CAST(meta_value AS UNSIGNED)) 
    FROM {$wpdb->postmeta} 
    WHERE meta_key = '_price' 
    AND post_id IN (SELECT ID FROM {$wpdb->posts} WHERE post_type = 'product' AND post_status = 'publish')
" );
$max_price = $max_price ? ceil($max_price) : 500;

// Fetch initial counts for SSR
$init_search   = isset($_GET['search']) ? sanitize_text_field($_GET['search']) : '';
$init_category = isset($_GET['category']) ? sanitize_text_field($_GET['category']) : '';
$init_brand    = isset($_GET['brand']) ? sanitize_text_field($_GET['brand']) : '';
$init_min_price= isset($_GET['min_price']) ? floatval($_GET['min_price']) : 0;
$init_max_price= isset($_GET['max_price']) ? floatval($_GET['max_price']) : 0;
$initial_counts = synergy_get_filter_counts( $init_search, $init_category, $init_brand, $init_min_price, $init_max_price );
?>

<main id="main" class="site-main page-prodotti">

    <!-- HERO PRODOTTI -->
    <section class="prodotti-hero">
        <div class="container text-center">
            <span class="hero-eyebrow"><?php echo esc_html( synergy_t( 'SHOP PROFESSIONALE', 'prodotti:hero:eyebrow' ) ); ?></span>
            <h1 class="hero-title"><?php echo esc_html( synergy_t( 'Prodotti professionali per la tua routine di bellezza.', 'prodotti:hero:title' ) ); ?></h1>
            <p class="hero-desc"><?php echo esc_html( synergy_t( 'Una selezione di cosmetici professionali per viso, corpo, mani, piedi e skincare avanzata, scelti per accompagnare i trattamenti in istituto e la cura quotidiana a casa.', 'prodotti:hero:desc' ) ); ?></p>
            <div class="hero-actions">
                <a href="#catalogo" class="btn btn-primary"><?php echo esc_html( synergy_t( 'Esplora i prodotti', 'prodotti:hero:cta_primary' ) ); ?></a>
                <a href="<?php echo esc_url(home_url('/contatti/')); ?>" class="btn btn-outline-champagne"><?php echo esc_html( synergy_t( 'Chiedi consiglio', 'prodotti:hero:cta_secondary' ) ); ?></a>
            </div>
        </div>
    </section>

    <!-- CATALOGO -->
    <section id="catalogo" class="prodotti-catalog-section relative-z">
        <div class="container">
            
            <!-- BARRA RIEPILOGO -->
            <div class="catalog-top-bar">
                <div class="catalog-results-count">
                    <span id="results-count-text"><?php echo wp_kses_post( sprintf( synergy_t( 'Trovati %s prodotti', 'prodotti:results:count' ), '<strong>' . (int) $initial_query->found_posts . '</strong>' ) ); ?></span>
                </div>
                
                <div class="catalog-active-filters" id="active-filters-container">
                    <!-- Chip filtri attivi appariranno qui -->
                </div>

                <div class="catalog-actions">
                    <button type="button" class="btn-clear-filters hidden" id="clear-filters-btn"><?php echo esc_html( synergy_t( 'Cancella filtri', 'prodotti:filters:clear' ) ); ?> &times;</button>
                    
                    <div class="catalog-sort">
                        <select id="prodotti-sort" class="sort-select-hidden" aria-label="<?php echo esc_attr( synergy_t( 'Ordina prodotti', 'prodotti:sort:aria_label' ) ); ?>" style="display: none !important;">
                            <option value="default"><?php echo esc_html( synergy_t( 'Ordinamento predefinito', 'prodotti:sort:default' ) ); ?></option>
                            <option value="price_asc"><?php echo esc_html( synergy_t( 'Prezzo: dal più economico', 'prodotti:sort:price_asc' ) ); ?></option>
                            <option value="price_desc"><?php echo esc_html( synergy_t( 'Prezzo: dal più caro', 'prodotti:sort:price_desc' ) ); ?></option>
                            <option value="title_asc"><?php echo esc_html( synergy_t( 'Nome: A-Z', 'prodotti:sort:title_asc' ) ); ?></option>
                            <option value="title_desc"><?php echo esc_html( synergy_t( 'Nome: Z-A', 'prodotti:sort:title_desc' ) ); ?></option>
                        </select>

                        <div class="synergy-custom-dropdown" id="synergy-sort-dropdown">
                            <button type="button" class="synergy-dropdown-trigger" id="sort-dropdown-trigger" aria-expanded="false" aria-controls="sort-dropdown-menu" aria-haspopup="listbox">
                                <span class="synergy-dropdown-label"><?php echo esc_html( synergy_t( 'Ordinamento predefinito', 'prodotti:sort:default' ) ); ?></span>
                                <svg class="synergy-dropdown-chevron" viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" stroke-width="2" fill="none"><polyline points="6 9 12 15 18 9"></polyline></svg>
                            </button>
                            <div class="synergy-dropdown-menu" id="sort-dropdown-menu" role="listbox" aria-label="<?php echo esc_attr( synergy_t( 'Ordina prodotti', 'prodotti:sort:aria_label' ) ); ?>">
                                <button type="button" class="synergy-dropdown-item active" role="option" aria-selected="true" data-value="default"><?php echo esc_html( synergy_t( 'Ordinamento predefinito', 'prodotti:sort:default' ) ); ?></button>
                                <button type="button" class="synergy-dropdown-item" role="option" aria-selected="false" data-value="price_asc"><?php echo esc_html( synergy_t( 'Prezzo: dal più economico', 'prodotti:sort:price_asc' ) ); ?></button>
                                <button type="button" class="synergy-dropdown-item" role="option" aria-selected="false" data-value="price_desc"><?php echo esc_html( synergy_t( 'Prezzo: dal più caro', 'prodotti:sort:price_desc' ) ); ?></button>
                                <button type="button" class="synergy-dropdown-item" role="option" aria-selected="false" data-value="title_asc"><?php echo esc_html( synergy_t( 'Nome: A-Z', 'prodotti:sort:title_asc' ) ); ?></button>
                                <button type="button" class="synergy-dropdown-item" role="option" aria-selected="false" data-value="title_desc"><?php echo esc_html( synergy_t( 'Nome: Z-A', 'prodotti:sort:title_desc' ) ); ?></button>
                            </div>
                        </div>
                    </div>

                    <button type="button" class="btn-mobile-filter" id="mobile-filter-trigger" aria-expanded="false" aria-controls="catalog-sidebar">
                        <svg viewBox="0 0 24 24" width="20" height="20" stroke="currentColor" stroke-width="2" fill="none"><polygon points="22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3"></polygon></svg>
                        <?php echo esc_html( synergy_t( 'Filtra', 'prodotti:filters:toggle' ) ); ?>
                    </button>
                </div>
            </div>

            <!-- LAYOUT PRINCIPALE -->
            <div class="catalog-layout">
                
                <!-- GRIGLIA PRODOTTI (LEFT) -->
                <div class="catalog-main">
                    <div class="prodotti-grid" id="prodotti-grid">
                        <?php 
                        if ( $initial_query->have_posts() ) {
                            while ( $initial_query->have_posts() ) {
                                $initial_query->the_post();
                                echo synergy_render_product_card( get_the_ID() );
                            }
                        } else {
                            echo '<div class="synergy-empty-state">' . esc_html( synergy_t( 'Nessun prodotto trovato.', 'prodotti:empty' ) ) . '</div>';
                        }
                        wp_reset_postdata();
                        ?>
                    </div>

                    <!-- LOAD MORE -->
                    <div class="catalog-load-more text-center">
                        <button type="button" class="btn btn-outline" id="load-more-btn" <?php echo ($initial_query->max_num_pages <= 1) ? 'style="display:none;"' : ''; ?>>
                            <?php echo esc_html( synergy_t( 'Carica altri', 'prodotti:load_more' ) ); ?>
                        </button>
                    </div>
                </div>

                <!-- SIDEBAR FILTRI (RIGHT) -->
                <aside class="catalog-sidebar" id="catalog-sidebar" aria-label="<?php echo esc_attr( synergy_t( 'Filtri prodotti', 'prodotti:filters:aria_label' ) ); ?>">
                    <div class="sidebar-header-mobile">
                        <h3><?php echo esc_html( synergy_t( 'Filtra Prodotti', 'prodotti:filters:title' ) ); ?></h3>
                        <button type="button" id="close-mobile-filter" aria-label="<?php echo esc_attr( synergy_t( 'Chiudi filtri', 'prodotti:filters:close' ) ); ?>">&times;</button>
                    </div>

                    <div class="sidebar-inner">
                        
                        <!-- CERCA -->
                        <div class="filter-widget">
                            <h4 class="filter-title"><?php echo esc_html( synergy_t( 'Cerca prodotto', 'prodotti:filters:search_title' ) ); ?></h4>
                            <div class="search-input-wrapper">
                                <input type="text" id="filter-search" placeholder="<?php echo esc_attr( synergy_t( 'Es. siero viso...', 'prodotti:filters:search_placeholder' ) ); ?>" aria-label="<?php echo esc_attr( synergy_t( 'Cerca', 'prodotti:filters:search_aria_label' ) ); ?>">
                                <svg viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" stroke-width="2" fill="none"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>
                            </div>
                        </div>

                        <!-- CATEGORIE -->
                        <?php if ( ! empty( $categories ) && ! is_wp_error( $categories ) ) : ?>
                        <details class="filter-widget" open>
                            <summary class="filter-title"><?php echo esc_html( synergy_t( 'Categoria', 'prodotti:filters:category' ) ); ?></summary>
                            <div class="filter-checkbox-list">
                                <?php 
                                // Merge "Ciglia" and "Capelli & Labbra"
                                $merged_categories = array();
                                $has_ciglia = false;
                                $has_capelli = false;
                                $merged_count = 0;
                                
                                foreach ( $categories as $cat ) {
                                    $count = isset( $initial_counts['product_cat'][$cat->slug] ) ? $initial_counts['product_cat'][$cat->slug] : 0;
                                    
                                    if ( $cat->slug === 'ciglia' ) {
                                        $has_ciglia = true;
                                        $merged_count += $count;
                                        continue; // Skip rendering
                                    }
                                    if ( $cat->slug === 'capelli-labbra' || strtolower($cat->name) === 'capelli & labbra' ) {
                                        $has_capelli = true;
                                        $merged_count += $count;
                                        $cat->is_merged = true; // Mark as merged
                                        $merged_categories[] = $cat;
                                        continue;
                                    }
                                    $merged_categories[] = $cat;
                                }

                                foreach ( $merged_categories as $cat ) : 
                                    if ( isset($cat->is_merged) && $cat->is_merged ) {
                                        $count = $merged_count;
                                        $slug_val = 'ciglia,' . $cat->slug;
                                        $cat_name = synergy_t( 'Ciglia, Capelli e Labbra', 'prodotti:filters:category:merged_label' );
                                        $data_slug = 'ciglia-capelli-labbra';
                                    } else {
                                        $count = isset( $initial_counts['product_cat'][$cat->slug] ) ? $initial_counts['product_cat'][$cat->slug] : 0;
                                        $slug_val = $cat->slug;
                                        $cat_name = $cat->name;
                                        $data_slug = $cat->slug;
                                    }
                                    
                                    $empty_class = ( $count === 0 ) ? 'filter-empty' : '';
                                ?>
                                    <label class="custom-checkbox <?php echo esc_attr( $empty_class ); ?>" data-tax="product_cat" data-slug="<?php echo esc_attr( $data_slug ); ?>">
                                        <input type="checkbox" name="filter_cat" value="<?php echo esc_attr( $slug_val ); ?>" data-label="<?php echo esc_attr( $cat_name ); ?>">
                                        <span class="checkmark"></span>
                                        <span class="checkbox-label">
                                            <?php echo esc_html( $cat_name ); ?> 
                                            <span class="term-count" data-term-slug="<?php echo esc_attr( $data_slug ); ?>">(<?php echo esc_html( $count ); ?>)</span>
                                        </span>
                                    </label>
                                <?php endforeach; ?>
                            </div>
                        </details>
                        <?php endif; ?>

                        <!-- MARCHI -->
                        <?php if ( ! empty( $brands ) && ! is_wp_error( $brands ) ) : ?>
                        <details class="filter-widget" open>
                            <summary class="filter-title"><?php echo esc_html( synergy_t( 'Marchio', 'prodotti:filters:brand' ) ); ?></summary>
                            <div class="filter-checkbox-list">
                                <?php foreach ( $brands as $brand ) : 
                                    $count = isset( $initial_counts['product_brand'][$brand->slug] ) ? $initial_counts['product_brand'][$brand->slug] : 0;
                                    $empty_class = ( $count === 0 ) ? 'filter-empty' : '';
                                ?>
                                    <label class="custom-checkbox <?php echo esc_attr( $empty_class ); ?>" data-tax="product_brand" data-slug="<?php echo esc_attr( $brand->slug ); ?>">
                                        <input type="checkbox" name="filter_brand" value="<?php echo esc_attr( $brand->slug ); ?>" data-label="<?php echo esc_attr( $brand->name ); ?>">
                                        <span class="checkmark"></span>
                                        <span class="checkbox-label">
                                            <?php echo esc_html( $brand->name ); ?> 
                                            <span class="term-count" data-term-slug="<?php echo esc_attr( $brand->slug ); ?>">(<?php echo esc_html( $count ); ?>)</span>
                                        </span>
                                    </label>
                                <?php endforeach; ?>
                            </div>
                        </details>
                        <?php endif; ?>

                        <!-- PREZZO -->
                        <div class="filter-widget price-filter-widget">
                            <h4 class="filter-title"><?php echo esc_html( synergy_t( 'Prezzo', 'prodotti:filters:price' ) ); ?></h4>
                            
                            <?php
                            // Calculate Histogram Data
                            $all_prices = $wpdb->get_col( "
                                SELECT CAST(meta_value AS UNSIGNED) 
                                FROM {$wpdb->postmeta} 
                                WHERE meta_key = '_price' 
                                AND post_id IN (SELECT ID FROM {$wpdb->posts} WHERE post_type = 'product' AND post_status = 'publish')
                                AND meta_value != ''
                            " );
                            
                            $bins_count = 24; // Number of bars in histogram
                            $histogram = array_fill(0, $bins_count, 0);
                            $bin_width = max(1, ceil($max_price / $bins_count));
                            
                            foreach ($all_prices as $p) {
                                $bin_index = min($bins_count - 1, floor($p / $bin_width));
                                $histogram[$bin_index]++;
                            }
                            
                            $max_freq = max(1, max($histogram));
                            ?>
                            
                            <div class="price-histogram" id="price-histogram">
                                <?php foreach ($histogram as $index => $count) : 
                                    $height_pct = ($count / $max_freq) * 100;
                                    // Set a minimum height for visibility if there is at least 1 product, else 0
                                    $height_pct = ($count > 0 && $height_pct < 10) ? 10 : $height_pct;
                                ?>
                                    <div class="histogram-bar" data-index="<?php echo $index; ?>" style="height: <?php echo $height_pct; ?>%;"></div>
                                <?php endforeach; ?>
                            </div>
                            
                            <div class="price-slider-wrapper">
                                <div id="price-slider"></div>
                            </div>
                            
                            <div class="price-range-wrapper">
                                <div class="price-inputs">
                                    <div class="price-input-box">
                                        <div class="input-suffix-wrapper">
                                            <input type="number" id="price-min" min="0" max="<?php echo $max_price; ?>" aria-label="<?php echo esc_attr( synergy_t( 'Prezzo minimo', 'prodotti:filters:price_min' ) ); ?>" value="<?php echo $init_min_price ? $init_min_price : 0; ?>">
                                            <span class="currency-suffix">CHF</span>
                                        </div>
                                        <span class="price-input-label"><?php echo esc_html( synergy_t( 'Prezzo minimo', 'prodotti:filters:price_min' ) ); ?></span>
                                    </div>
                                    <div class="price-input-box">
                                        <div class="input-suffix-wrapper">
                                            <input type="number" id="price-max" min="0" max="<?php echo $max_price; ?>" aria-label="<?php echo esc_attr( synergy_t( 'Prezzo massimo', 'prodotti:filters:price_max' ) ); ?>" value="<?php echo $init_max_price ? $init_max_price : $max_price; ?>">
                                            <span class="currency-suffix">CHF</span>
                                        </div>
                                        <span class="price-input-label"><?php echo esc_html( synergy_t( 'Prezzo massimo', 'prodotti:filters:price_max' ) ); ?></span>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                    
                    <div class="sidebar-footer-mobile">
                        <button type="button" class="btn btn-outline" id="mobile-reset-filters"><?php echo esc_html( synergy_t( 'Reset', 'prodotti:filters:reset' ) ); ?></button>
                        <button type="button" class="btn btn-primary" id="mobile-apply-filters"><?php echo esc_html( sprintf( synergy_t( 'Vedi %d prodotti', 'prodotti:filters:apply' ), (int) $initial_query->found_posts ) ); ?></button>
                    </div>
                </aside>
                
                <!-- MOBILE OVERLAY -->
                <div class="mobile-drawer-overlay" id="mobile-drawer-overlay" aria-hidden="true"></div>

            </div> <!-- /.catalog-layout -->
        </div> <!-- /.container -->
    </section>

</main>

<?php get_footer(); ?>
