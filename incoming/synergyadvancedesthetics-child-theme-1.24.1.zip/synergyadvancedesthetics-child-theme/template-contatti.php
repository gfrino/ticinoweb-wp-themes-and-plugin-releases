<?php
/**
 * Template Name: Contatti
 * Description: Template per la pagina contatti con mappa interattiva e form
 */

get_header();

// Dati dal CMS
$cms_name    = get_option('ticinoweb_site_name', 'Synergy Advanced Aesthetics');
$cms_email   = get_option('ticinoweb_contact_email', 'info@synergyaesthetics.ch');
$cms_phone   = get_option('ticinoweb_contact_phone', '+41 (0)79 288 61 77');
$cms_address = get_option('ticinoweb_contact_address', "Via Generale Guisan 10<br>Paradiso, Lugano");

// Clean phone for link
$clean_phone = preg_replace('/[^0-9+]/', '', str_replace('(0)', '', $cms_phone));
?>

<main id="primary" class="site-main contatti-page">
    
    <!-- 1. HERO SECTION -->
    <section class="contatti-hero section">
        <div class="hero-bg">
            <div class="hero-texture"></div>
            <div class="hero-glow"></div>
        </div>
        <div class="container relative-z">
            <div class="hero-content text-center reveal">
                <span class="section-eyebrow"><?php echo esc_html( synergy_t( 'SIAMO QUI PER TE', 'contatti:hero:eyebrow' ) ); ?></span>
                <h1 class="hero-title"><?php echo esc_html( synergy_t( 'Contatti', 'contatti:hero:title' ) ); ?></h1>
                <p class="hero-lead"><?php echo esc_html( synergy_t( 'Prenota il tuo appuntamento o contattaci per una consulenza personalizzata. Saremo felici di accoglierti.', 'contatti:hero:lead' ) ); ?></p>
            </div>
        </div>
    </section>

    <!-- 2. CONTACT INFO & MAP -->
    <section class="contatti-section section bg-ivory relative" style="position: relative; z-index: 1;">
        <!-- Decorazioni di sfondo leggere -->
        <div class="contatti-bg-pattern" style="position: absolute; inset: 0; pointer-events: none; opacity: 0.3; background-image: radial-gradient(rgba(206,189,173,0.4) 1px, transparent 1px); background-size: 30px 30px;"></div>
        <div class="contatti-bg-glow" style="position: absolute; right: 0; top: 20%; width: 50%; height: 60%; background: radial-gradient(circle, rgba(230,215,189,0.15) 0%, rgba(255,255,255,0) 70%); filter: blur(50px); pointer-events: none;"></div>

        <div class="container contatti-grid relative" style="z-index: 2;">
            
            <!-- Colonna Sinistra (Testi e Card) -->
            <div class="contatti-content reveal">
                <span class="eyebrow"><?php echo esc_html( synergy_t( 'DOVE SIAMO', 'contatti:where:eyebrow' ) ); ?></span>
                <h2 class="contatti-title"><?php echo esc_html( synergy_t( 'Vieni a trovarci', 'contatti:where:title' ) ); ?></h2>
                <p class="contatti-desc"><?php echo esc_html( synergy_t( 'Un ambiente elegante, discreto e accogliente, pensato per accompagnarti in ogni trattamento con attenzione, professionalità e cura.', 'contatti:where:desc' ) ); ?></p>
                
                <div class="contact-cards-grid">
                    <!-- Card 1: Indirizzo -->
                    <div class="contact-card">
                        <div class="cc-icon">
                            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path><circle cx="12" cy="10" r="3"></circle></svg>
                        </div>
                        <div class="cc-text">
                            <h4><?php echo esc_html( synergy_t( 'Indirizzo', 'contatti:card:indirizzo:title' ) ); ?></h4>
                            <p><strong><?php echo esc_html($cms_name); ?></strong><br>
                               <?php echo wp_kses_post( synergy_t_html( $cms_address, 'contatti:card:indirizzo:address' ) ); ?>
                            </p>
                        </div>
                    </div>
                    
                    <!-- Card 2: Telefono -->
                    <div class="contact-card">
                        <div class="cc-icon">
                            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path></svg>
                        </div>
                        <div class="cc-text">
                            <h4><?php echo esc_html( synergy_t( 'Telefono', 'contatti:card:telefono:title' ) ); ?></h4>
                            <p><a href="tel:<?php echo esc_attr($clean_phone); ?>" class="contact-link"><?php echo esc_html($cms_phone); ?></a></p>
                        </div>
                    </div>

                    <!-- Card 3: Email -->
                    <div class="contact-card">
                        <div class="cc-icon">
                            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path><polyline points="22,6 12,13 2,6"></polyline></svg>
                        </div>
                        <div class="cc-text">
                            <h4><?php echo esc_html( synergy_t( 'Email', 'contatti:card:email:title' ) ); ?></h4>
                            <p><a href="mailto:<?php echo esc_attr($cms_email); ?>" class="contact-link"><?php echo esc_html($cms_email); ?></a></p>
                        </div>
                    </div>
                    
                    <!-- Card 4: Orari -->
                    <div class="contact-card">
                        <div class="cc-icon">
                            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 16 14"></polyline></svg>
                        </div>
                        <div class="cc-text">
                            <h4><?php echo esc_html( synergy_t( 'Orari', 'contatti:card:orari:title' ) ); ?></h4>
                            <p><?php echo function_exists('synergy_get_formatted_hours') ? synergy_get_formatted_hours() : wp_kses_post( synergy_t_html( 'Lun - Sab: 09:00 - 19:00<br>Domenica: Chiuso', 'contatti:hours:fallback' ) ); ?></p>
                        </div>
                    </div>
                </div>

                    <?php
                    /* Avviso di disdetta sotto le card dei contatti, dentro la colonna
                       di sinistra: come fratello della griglia finiva a occupare la
                       colonna della mappa, spingendola fuori. */
                    if ( function_exists( 'synergy_render_avviso_disdetta' ) ) {
                        synergy_render_avviso_disdetta( 'synergy-avviso--contatti' );
                    }
                    ?>
            </div>

            
            <!-- Colonna Destra (Mappa Premium) -->
            <div class="contatti-map-col reveal delay-2">
                <div class="premium-map-placeholder">
                    <?php 
                    $map_query = urlencode(str_replace('<br>', ', ', $cms_address));
                    // Lingua dell'interfaccia mappa: segue la lingua corrente del sito,
                    // italiano come default quando tW Translate Plus non e' attivo.
                    $map_lang = function_exists('twtr_get_current_language') ? twtr_get_current_language() : 'it';
                    ?>
                    <iframe src="https://maps.google.com/maps?q=<?php echo $map_query; ?>&t=&z=15&hl=<?php echo esc_attr($map_lang); ?>&ie=UTF8&iwloc=&output=embed" width="100%" height="100%" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                </div>
            </div>
            
        </div>
    </section>

</main>

<?php get_footer(); ?>
