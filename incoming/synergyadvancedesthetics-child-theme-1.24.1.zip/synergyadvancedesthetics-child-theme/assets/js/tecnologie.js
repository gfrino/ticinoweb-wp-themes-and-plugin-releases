/**
 * Tecnologie Page Scripts
 * Handles filtering, interactive lab, and scroll animations
 */
document.addEventListener('DOMContentLoaded', function() {

    // 1. SCROLL REVEAL ANIMATIONS
    const revealElements = document.querySelectorAll('.reveal');
    
    if (revealElements.length > 0 && 'IntersectionObserver' in window) {
        const revealObserver = new IntersectionObserver((entries, observer) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('active');
                    observer.unobserve(entry.target);
                }
            });
        }, {
            root: null,
            threshold: 0.1,
            rootMargin: "0px 0px -50px 0px"
        });

        revealElements.forEach(el => {
            revealObserver.observe(el);
        });
    } else {
        // Fallback for older browsers
        revealElements.forEach(el => el.classList.add('active'));
    }

    // 2. GRID FILTERS (DYNAMIC LOGIC)
    const filterBtns = document.querySelectorAll('.tech-filter');
    const techCards = document.querySelectorAll('.tech-card');

    if (filterBtns.length > 0 && techCards.length > 0) {
        filterBtns.forEach(btn => {
            btn.addEventListener('click', function(e) {
                e.preventDefault();
                
                const filterValue = this.getAttribute('data-filter');
                
                // Aggiorna stato attivo sui bottoni e attributi ARIA
                filterBtns.forEach(b => {
                    b.classList.remove('is-active');
                    b.setAttribute('aria-pressed', 'false');
                });
                this.classList.add('is-active');
                this.setAttribute('aria-pressed', 'true');

                // Filtra le card
                techCards.forEach(card => {
                    const categoriesStr = card.getAttribute('data-categories') || '';
                    const categories = categoriesStr.split(' ');
                    
                    const shouldShow = (filterValue === 'all') || categories.includes(filterValue);
                    
                    if (shouldShow) {
                        card.classList.remove('is-hidden');
                        card.removeAttribute('aria-hidden');
                        // Ritocca animazione se necessario
                        card.style.animation = 'none';
                        card.offsetHeight; /* trigger reflow */
                        card.style.animation = null; 
                    } else {
                        card.classList.add('is-hidden');
                        card.setAttribute('aria-hidden', 'true');
                    }
                });
            });
        });
    }

    // 3. TECHNOLOGY LAB (INTERACTIVE SECTION)
    // Testi del pannello: tradotti lato PHP (synergy_t) e passati via wp_localize_script;
    // l'oggetto letterale resta come fallback nella lingua principale.
    const labData = (window.synergyI18n && window.synergyI18n.labData) || {
        'viso': {
            area: 'Area Viso',
            title: 'Tecnologie per il viso',
            desc: 'Sistemi professionali pensati per supportare luminosità, tono, rigenerazione e qualità della pelle.',
            items: ['Radiofrequenza', 'HIFU / SMAS', 'Cold Plasma', 'ELOS-IPL', 'Ultrasuoni', 'Ionoforesi', 'Elettrostimolazione']
        },
        'corpo': {
            area: 'Area Corpo',
            title: 'Rimodellamento corpo',
            desc: 'Sistemi avanzati per la tonificazione e il trattamento degli inestetismi corporei.',
            items: ['Radiofrequenza corpo', 'Cavitazione', 'Vacuum', 'Criolipolisi', 'OndaVacu Gym', 'Body Shaping Sculpt', 'OndaWave']
        },
        'epilazione': {
            area: 'Area Epilazione',
            title: 'Epilazione progressiva',
            desc: 'Soluzioni laser di ultima generazione per un\'epilazione efficace e confortevole.',
            items: ['Laser diodo', 'Laser diodo ArtMED', 'Laser diodo CoaxMED']
        },
        'pelle': {
            area: 'Area Pelle',
            title: 'Rigenerazione cutanea',
            desc: 'Apparecchiature specifiche per la purificazione profonda e l\'equilibrio della pelle.',
            items: ['Cold Plasma', 'ELOS-IPL', 'Spazzola ultrasuono']
        },
        'drenaggio': {
            area: 'Area Drenaggio',
            title: 'Leggerezza e benessere',
            desc: 'Tecnologie studiate per favorire il microcircolo e ridurre la ritenzione idrica.',
            items: ['Pressoterapia', 'Vacuum pulsante', 'OndaVacu Gym']
        },
        'rimodellamento': {
            area: 'Area Silhouette',
            title: 'Forma e silhouette',
            desc: 'Sinergia di tecnologie per trattare adiposità localizzate e ridefinire i contorni.',
            items: ['Criolipolisi', 'Cavitazione', 'Radiofrequenza', 'Body Shaping Sculpt', 'OndaWave']
        }
    };

    const labCatBtns = document.querySelectorAll('.lab-cat-btn');
    const labMobileSelect = document.getElementById('lab-mobile-select');
    
    // Elementi Pannello (DX)
    const labPanelArea = document.getElementById('lab-panel-area');
    const labPanelTitle = document.getElementById('lab-panel-title');
    const labPanelDesc = document.getElementById('lab-panel-desc');
    const labPanelList = document.getElementById('lab-panel-list');
    const labPanelContent = document.getElementById('lab-panel-content');
    
    // Elementi Nucleo (Centro)
    const labChipsContainer = document.getElementById('lab-chips-container');
    const labCoreGlow = document.getElementById('lab-core-glow');

    function updateLabCore(targetKey) {
        const data = labData[targetKey];
        if (!data || !labPanelTitle || !labChipsContainer) return;

        // Reset animazioni pannello
        labPanelContent.classList.remove('fade-in-content');
        void labPanelContent.offsetWidth; // trigger reflow
        
        // Update Testi Pannello DX
        if(labPanelArea) labPanelArea.textContent = data.area;
        labPanelTitle.textContent = data.title;
        labPanelDesc.textContent = data.desc;
        
        // Update Lista Pannello DX
        labPanelList.innerHTML = '';
        data.items.forEach(item => {
            const li = document.createElement('li');
            li.textContent = item;
            labPanelList.appendChild(li);
        });

        // Update Chips Centrali con animazione Stagger
        labChipsContainer.innerHTML = '';
        data.items.forEach((item, index) => {
            const chip = document.createElement('div');
            chip.className = 'tech-chip';
            chip.textContent = item;
            
            // Ritardo progressivo per ogni chip (stagger)
            chip.style.animationDelay = `${index * 0.08}s`;
            
            labChipsContainer.appendChild(chip);
            
            // Aggiungi classe animazione in un secondo momento per sicurezza
            requestAnimationFrame(() => {
                chip.classList.add('chip-enter');
            });
        });
        
        // Effetto Glow pulsante cambio categoria
        if(labCoreGlow) {
            labCoreGlow.style.opacity = '0.5';
            setTimeout(() => { labCoreGlow.style.opacity = ''; }, 300);
        }

        // Riapplica animazione pannello
        labPanelContent.classList.add('fade-in-content');
    }

    // Desktop Tabs Event
    if (labCatBtns.length > 0) {
        labCatBtns.forEach(btn => {
            // Support hover for desktop feeling
            btn.addEventListener('mouseenter', function() {
                labCatBtns.forEach(b => b.classList.remove('active'));
                this.classList.add('active');
                
                const target = this.getAttribute('data-target');
                updateLabCore(target);
                
                if(labMobileSelect) labMobileSelect.value = target;
            });
            
            // Support click for touch/hybrid devices
            btn.addEventListener('click', function(e) {
                e.preventDefault();
                labCatBtns.forEach(b => b.classList.remove('active'));
                this.classList.add('active');
                
                const target = this.getAttribute('data-target');
                updateLabCore(target);
                
                if(labMobileSelect) labMobileSelect.value = target;
            });
        });
        
        // Init primo elemento
        if(labCatBtns[0]) {
            updateLabCore(labCatBtns[0].getAttribute('data-target'));
        }
    }

    // Mobile Select Event
    if (labMobileSelect) {
        labMobileSelect.addEventListener('change', function() {
            const target = this.value;
            updateLabCore(target);
            
            // Sync desktop tabs
            if (labCatBtns.length > 0) {
                labCatBtns.forEach(b => {
                    if(b.getAttribute('data-target') === target) {
                        b.classList.add('active');
                    } else {
                        b.classList.remove('active');
                    }
                });
            }
        });
    }

});
