document.addEventListener('DOMContentLoaded', function() {
    
    // --- 1. Sticky Header Logic ---
    const header = document.getElementById('synergy-main-header');
    
    function checkScroll() {
        if (window.scrollY > 50) {
            header.classList.add('scrolled');
        } else {
            header.classList.remove('scrolled');
        }
    }
    
    window.addEventListener('scroll', checkScroll);
    checkScroll(); // Check on init

    // --- 2. Mega Menu Logic ---
    const megaMenuItem = document.querySelector('.has-megamenu');
    const megaMenu = document.getElementById('synergy-mega-menu');
    const megaToggleLink = document.querySelector('.mega-toggle');
    
    if (megaMenuItem && megaMenu && megaToggleLink) {

        function setMegaMenuOpen(isOpen, restoreFocus = false) {
            megaMenuItem.classList.toggle('megamenu-active', isOpen);
            megaToggleLink.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
            megaMenu.setAttribute('aria-hidden', isOpen ? 'false' : 'true');

            if (isOpen) {
                megaMenu.removeAttribute('inert');
            } else {
                megaMenu.setAttribute('inert', '');
            }

            if (isOpen) {
                updateTrailPosition();
            } else if (restoreFocus) {
                megaToggleLink.focus();
            }
        }

        megaToggleLink.addEventListener('click', function(e) {
            e.preventDefault(); // Evita scroll top
            const willOpen = !megaMenuItem.classList.contains('megamenu-active');
            setMegaMenuOpen(willOpen);
        });

        // Chiudi se clicco fuori
        document.addEventListener('click', function(e) {
            if (!megaMenuItem.contains(e.target)) {
                setMegaMenuOpen(false);
            }
        });

        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape' && megaMenuItem.classList.contains('megamenu-active')) {
                e.preventDefault();
                setMegaMenuOpen(false, true);
            }
        });

        // Gestione pannelli interni e focus trail
        const sidebarItems = document.querySelectorAll('.mega-sidebar-item');
        const panels = document.querySelectorAll('.synergy-mega-panel');
        const trail = document.querySelector('.mega-sidebar-trail');

        function activateSidebarItem(item) {
            const targetId = item.getAttribute('data-target');
            const targetPanel = targetId ? document.getElementById(targetId) : null;

            sidebarItems.forEach(sidebarItem => {
                const tab = sidebarItem.querySelector('[role="tab"]');
                const isActive = sidebarItem === item;

                sidebarItem.classList.toggle('active', isActive);
                if (tab) {
                    tab.setAttribute('aria-selected', isActive ? 'true' : 'false');
                    tab.setAttribute('tabindex', isActive ? '0' : '-1');
                }
            });

            panels.forEach(panel => {
                const isActive = panel === targetPanel;
                panel.classList.toggle('active', isActive);
                panel.setAttribute('aria-hidden', isActive ? 'false' : 'true');
                if (isActive) {
                    panel.removeAttribute('inert');
                } else {
                    panel.setAttribute('inert', '');
                }
            });

            updateTrailPosition();
        }

        function updateTrailPosition() {
            const activeItem = document.querySelector('.mega-sidebar-item.active');
            if (activeItem && trail) {
                // Calcola la posizione top dell'elemento attivo sommando l'offset della lista
                // Il link diretto (es. Listino Prezzi) vive in .mega-sidebar-links,
                // fuori dal tablist: senza includerlo il trail si posizionerebbe male.
                const list = activeItem.closest('.mega-sidebar-list, .mega-sidebar-links');
                const listOffset = list ? list.offsetTop : 0;
                const topPos = activeItem.offsetTop + listOffset;
                
                trail.style.top = topPos + 'px';
                trail.style.height = activeItem.offsetHeight + 'px';
            }
        }

        sidebarItems.forEach(item => {
            const tab = item.querySelector('[role="tab"]');

            item.addEventListener('mouseenter', function() {
                activateSidebarItem(this);
            });

            if (tab) {
                tab.addEventListener('focus', function() {
                    activateSidebarItem(item);
                });

                tab.addEventListener('click', function() {
                    activateSidebarItem(item);
                });

                tab.addEventListener('keydown', function(e) {
                    const tabs = Array.from(document.querySelectorAll('.mega-sidebar-link[role="tab"]'));
                    const currentIndex = tabs.indexOf(this);
                    let nextIndex = currentIndex;

                    if (e.key === 'ArrowDown' || e.key === 'ArrowRight') {
                        nextIndex = (currentIndex + 1) % tabs.length;
                    } else if (e.key === 'ArrowUp' || e.key === 'ArrowLeft') {
                        nextIndex = (currentIndex - 1 + tabs.length) % tabs.length;
                    } else if (e.key === 'Home') {
                        nextIndex = 0;
                    } else if (e.key === 'End') {
                        nextIndex = tabs.length - 1;
                    } else {
                        return;
                    }

                    e.preventDefault();
                    tabs[nextIndex].focus();
                });
            }
        });
        
        // Init trail position after a short delay to ensure DOM is rendered
        setTimeout(updateTrailPosition, 100);
    }

    // --- 3. Mobile Menu Logic ---
    const mobileToggleBtn = document.getElementById('synergy-mobile-toggle');
    const mobileCloseBtn = document.getElementById('synergy-mobile-close');
    const mobileMenu = document.getElementById('synergy-mobile-menu');
    const body = document.body;

    if (mobileToggleBtn && mobileMenu) {
        let previouslyFocusedElement = null;

        function getMobileMenuFocusableElements() {
            return Array.from(mobileMenu.querySelectorAll(
                'a[href], button:not([disabled]), input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])'
            )).filter(element => !element.closest('[aria-hidden="true"]') && element.getClientRects().length > 0);
        }

        function toggleMobileMenu() {
            const isOpen = mobileMenu.classList.contains('active');
            if (isOpen) {
                closeMobileMenu();
            } else {
                openMobileMenu();
            }
        }

        function openMobileMenu() {
            previouslyFocusedElement = document.activeElement;
            mobileMenu.classList.add('active');
            mobileMenu.removeAttribute('inert');
            mobileMenu.setAttribute('aria-hidden', 'false');
            mobileToggleBtn.classList.add('is-active');
            mobileToggleBtn.setAttribute('aria-expanded', 'true');
            mobileToggleBtn.setAttribute('aria-label', (window.synergyI18n && window.synergyI18n.menuClose) || 'Chiudi menu');
            body.classList.add('mobile-menu-open');

            window.requestAnimationFrame(function() {
                const firstFocusable = getMobileMenuFocusableElements()[0];
                if (firstFocusable) {
                    firstFocusable.focus();
                }
            });
        }

        function closeMobileMenu(restoreFocus = true) {
            mobileMenu.classList.remove('active');
            mobileMenu.setAttribute('aria-hidden', 'true');
            mobileMenu.setAttribute('inert', '');
            mobileToggleBtn.classList.remove('is-active');
            mobileToggleBtn.setAttribute('aria-expanded', 'false');
            mobileToggleBtn.setAttribute('aria-label', (window.synergyI18n && window.synergyI18n.menuOpen) || 'Apri menu');
            body.classList.remove('mobile-menu-open');

            if (restoreFocus && previouslyFocusedElement && typeof previouslyFocusedElement.focus === 'function') {
                previouslyFocusedElement.focus();
            }
        }

        mobileToggleBtn.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            toggleMobileMenu();
        });

        if (mobileCloseBtn) {
            mobileCloseBtn.addEventListener('click', function(e) {
                e.preventDefault();
                closeMobileMenu();
            });
        }

        // Chiudi il menu se si clicca su un link del menu mobile
        const mobileNavLinks = mobileMenu.querySelectorAll('a:not(.mobile-accordion-toggle)');
        mobileNavLinks.forEach(link => {
            link.addEventListener('click', function() {
                closeMobileMenu(false);
            });
        });

        // Chiudi con il tasto ESC
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape' && mobileMenu.classList.contains('active')) {
                e.preventDefault();
                closeMobileMenu();
                return;
            }

            if (e.key === 'Tab' && mobileMenu.classList.contains('active')) {
                const focusableElements = getMobileMenuFocusableElements();
                if (!focusableElements.length) {
                    return;
                }

                const firstFocusable = focusableElements[0];
                const lastFocusable = focusableElements[focusableElements.length - 1];

                if (e.shiftKey && document.activeElement === firstFocusable) {
                    e.preventDefault();
                    lastFocusable.focus();
                } else if (!e.shiftKey && document.activeElement === lastFocusable) {
                    e.preventDefault();
                    firstFocusable.focus();
                }
            }
        });
    }

    // Mobile Accordion
    const accordions = document.querySelectorAll('.mobile-accordion-toggle');
    
    accordions.forEach(acc => {
        acc.addEventListener('click', function(e) {
            e.preventDefault();
            
            const parentLi = this.parentElement;
            const content = this.nextElementSibling;
            
            // Chiudi i fratelli
            const siblings = parentLi.parentElement.children;
            for(let i=0; i<siblings.length; i++) {
                if(siblings[i] !== parentLi && siblings[i].classList.contains('active')) {
                    siblings[i].classList.remove('active');
                    siblings[i].querySelectorAll('.mobile-accordion-toggle').forEach(toggle => {
                        toggle.setAttribute('aria-expanded', 'false');
                    });
                    jQuery(siblings[i].querySelectorAll('.mobile-accordion-content')).stop(true, true).slideUp(300);
                }
            }
            
            // Toggle se stesso
            if(parentLi.classList.contains('active')) {
                parentLi.classList.remove('active');
                this.setAttribute('aria-expanded', 'false');
                jQuery(content).stop(true, true).slideUp(300);
            } else {
                parentLi.classList.add('active');
                this.setAttribute('aria-expanded', 'true');
                jQuery(content).stop(true, true).slideDown(300);
            }
        });
    });

    // --- 4. Global Reveal on Scroll (Intersection Observer) ---
    const revealElements = document.querySelectorAll('.reveal');
    if (revealElements.length > 0) {
        const revealObserver = new IntersectionObserver((entries, observer) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('active');
                    observer.unobserve(entry.target);
                }
            });
        }, {
            root: null,
            threshold: 0.15,
            rootMargin: "0px 0px -50px 0px"
        });
        
        revealElements.forEach(el => revealObserver.observe(el));
    }
});
