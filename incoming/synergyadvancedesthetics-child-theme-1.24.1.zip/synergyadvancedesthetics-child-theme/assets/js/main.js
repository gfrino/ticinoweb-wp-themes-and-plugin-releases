document.addEventListener('DOMContentLoaded', () => {
  
// Reveal observer spostato in header.js per renderlo globale

  // 2. Sticky Header / Glassmorphism state change
  const header = document.querySelector('.site-header');
  if (header) {
    window.addEventListener('scroll', () => {
      if (window.scrollY > 50) {
        header.classList.add('header-scrolled');
      } else {
        header.classList.remove('header-scrolled');
      }
    });
  }

  // 3. Hero Video Background Logic
  const heroVideo = document.getElementById('hero-video');
  if (heroVideo) {
    heroVideo.addEventListener('timeupdate', () => {
      // Fade out slightly before it ends to create a smooth transition when it loops
      if (heroVideo.duration - heroVideo.currentTime < 1) {
        heroVideo.classList.add('fade-out');
      } else if (heroVideo.currentTime < 1) {
        heroVideo.classList.remove('fade-out');
      }
    });
  }


  // 4. Timeline Animation (Metodo)
  const timelineContainer = document.querySelector('.timeline-container');
  if (timelineContainer) {
    const timelineObserver = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('in-view');
          timelineObserver.unobserve(entry.target);
        }
      });
    }, {
      root: null,
      threshold: 0.3
    });
    timelineObserver.observe(timelineContainer);
  }

  // 5. Prodotti & Tecnologie (Tabs and Expand)
  const ptTabBtns = document.querySelectorAll('.pt-tab-btn');
  const ptPanels = document.querySelectorAll('.pt-panel');
  
  if (ptTabBtns.length > 0) {
    ptTabBtns.forEach(btn => {
      btn.addEventListener('click', () => {
        // Remove active class from all buttons and panels
        ptTabBtns.forEach(b => b.classList.remove('active'));
        ptPanels.forEach(p => p.classList.remove('active'));
        
        // Add active class to clicked button
        btn.classList.add('active');
        
        // Add active class to corresponding panel
        const targetId = btn.getAttribute('data-target');
        const targetPanel = document.getElementById('panel-' + targetId);
        if (targetPanel) {
          targetPanel.classList.add('active');
          
          // Reset 'mostra tutto' state if it was expanded
          const hiddenCards = targetPanel.querySelectorAll('.pt-card.hidden-card');
          const revealedCards = targetPanel.querySelectorAll('.pt-card:not(.hidden-card):nth-child(n+7)');
          const toggleBtn = targetPanel.querySelector('.pt-mostra-tutto');
          
          if (revealedCards.length > 0) {
              revealedCards.forEach(c => c.classList.add('hidden-card'));
              if (toggleBtn) {
                  toggleBtn.textContent = (window.synergyI18n && window.synergyI18n.showAll) || 'Mostra tutto';
                  toggleBtn.classList.remove('expanded');
              }
          }
        }
      });
    });
  }

  const ptToggleBtns = document.querySelectorAll('.pt-mostra-tutto');
  if (ptToggleBtns.length > 0) {
      ptToggleBtns.forEach(btn => {
          btn.addEventListener('click', (e) => {
              const targetId = btn.getAttribute('data-target');
              const targetPanel = document.getElementById(targetId);
              
              if (targetPanel) {
                  const allCards = targetPanel.querySelectorAll('.pt-card');
                  const isExpanded = btn.classList.contains('expanded');
                  
                  if (isExpanded) {
                      // Collapse
                      allCards.forEach((c, index) => {
                          if (index >= 6) {
                              c.classList.add('hidden-card');
                          }
                      });
                      btn.textContent = (window.synergyI18n && window.synergyI18n.showAll) || 'Mostra tutto';
                      btn.classList.remove('expanded');
                      
                      // Scroll slightly back up to tabs if too far down
                      const tabsContainer = document.querySelector('.pt-tabs-container');
                      if (tabsContainer) {
                          tabsContainer.scrollIntoView({ behavior: 'smooth', block: 'start' });
                      }
                  } else {
                      // Expand
                      allCards.forEach(c => {
                          c.classList.remove('hidden-card');
                      });
                      btn.textContent = (window.synergyI18n && window.synergyI18n.showLess) || 'Mostra meno';
                      btn.classList.add('expanded');
                  }
              }
          });
      });
  }


  // --- MOLECULAR BACKGROUND ANIMATION ---
  const moleculeContainer = document.getElementById('synergy-molecules');
  const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  if (moleculeContainer && !prefersReducedMotion) {
      const isMobile = window.innerWidth <= 768;
      const numDots = isMobile ? 8 : 20; // Reduced for mobile
      const maxDistance = isMobile ? 120 : 180;
      
      const dots = [];
      const lines = [];
      
      // Create SVG layer for lines
      const svgNamespace = "http://www.w3.org/2000/svg";
      const svg = document.createElementNS(svgNamespace, "svg");
      svg.style.position = 'absolute';
      svg.style.top = '0';
      svg.style.left = '0';
      svg.style.width = '100%';
      svg.style.height = '100%';
      moleculeContainer.appendChild(svg);
      
      // Initialize Dots
      for (let i = 0; i < numDots; i++) {
          const dot = document.createElement('div');
          dot.className = 'syn-dot';
          
          const x = Math.random() * 100;
          const y = Math.random() * 100;
          
          dot.style.left = `${x}%`;
          dot.style.top = `${y}%`;
          
          // Random velocity
          const vx = (Math.random() - 0.5) * 0.05;
          const vy = (Math.random() - 0.5) * 0.05;
          
          moleculeContainer.appendChild(dot);
          
          dots.push({
              el: dot,
              x: x, // percentage
              y: y,
              vx: vx,
              vy: vy
          });
      }
      
      // Animation Loop
      function animateMolecules() {
          const width = moleculeContainer.offsetWidth;
          const height = moleculeContainer.offsetHeight;
          
          // Clear previous lines
          while (svg.firstChild) {
              svg.removeChild(svg.firstChild);
          }
          
          // Move dots
          dots.forEach(dot => {
              dot.x += dot.vx;
              dot.y += dot.vy;
              
              // Bounce off invisible walls (-10% to 110%)
              if (dot.x < -10 || dot.x > 110) dot.vx *= -1;
              if (dot.y < -10 || dot.y > 110) dot.vy *= -1;
              
              dot.el.style.left = `${dot.x}%`;
              dot.el.style.top = `${dot.y}%`;
          });
          
          // Draw lines between close dots
          for (let i = 0; i < dots.length; i++) {
              for (let j = i + 1; j < dots.length; j++) {
                  const dx = (dots[i].x / 100 * width) - (dots[j].x / 100 * width);
                  const dy = (dots[i].y / 100 * height) - (dots[j].y / 100 * height);
                  const dist = Math.sqrt(dx * dx + dy * dy);
                  
                  if (dist < maxDistance) {
                      const line = document.createElementNS(svgNamespace, "line");
                      line.setAttribute("x1", `${dots[i].x}%`);
                      line.setAttribute("y1", `${dots[i].y}%`);
                      line.setAttribute("x2", `${dots[j].x}%`);
                      line.setAttribute("y2", `${dots[j].y}%`);
                      
                      // Opacity based on distance (closer = more opaque, up to 0.3)
                      const opacity = (1 - (dist / maxDistance)) * 0.3;
                      line.setAttribute("stroke", `rgba(201,201,201,${opacity})`);
                      line.setAttribute("stroke-width", "1");
                      
                      svg.appendChild(line);
                  }
              }
          }
          
          requestAnimationFrame(animateMolecules);
      }
      
      // Start only if in view (Intersection Observer)
      const moleculeObserver = new IntersectionObserver((entries) => {
          entries.forEach(entry => {
              if (entry.isIntersecting) {
                  animateMolecules();
                  moleculeObserver.disconnect(); // Run continuously once triggered
              }
          });
      }, { threshold: 0.1 });
      
      moleculeObserver.observe(moleculeContainer);
  }

});
