/**
 * Script per il listino prezzi dinamico - Frontend Premium
 */

document.addEventListener('DOMContentLoaded', function() {
    
    const tabs = document.querySelectorAll('.synergy-price-tab');
    const items = document.querySelectorAll('.synergy-price-card');
    const showAllBtn = document.querySelector('#synergy-load-more');
    
    // Inizializza visualizzazione label "Categoria" in base al tab "Tutti"
    function updateCategoryLabelsVisibility(isAll) {
        items.forEach(item => {
            if (isAll) {
                item.classList.add('show-cat');
            } else {
                item.classList.remove('show-cat');
            }
        });
    }
    
    // Inizialmente siamo su "Tutti"
    updateCategoryLabelsVisibility(true);

    if (showAllBtn) {
        showAllBtn.addEventListener('click', function(e) {
            e.preventDefault();
            items.forEach(item => {
                item.classList.remove('synergy-item-hidden');
                item.style.display = 'block';
                item.style.opacity = '1';
            });
            this.parentElement.style.display = 'none'; // nascondi il bottone
        });
    }

    // Tabs logic
    tabs.forEach(tab => {
        tab.addEventListener('click', function(e) {
            e.preventDefault();
            
            // Remove active from all tabs
            tabs.forEach(t => t.classList.remove('active'));
            this.classList.add('active');
            
            const category = this.getAttribute('data-category');
            const isAll = category === 'all';
            
            updateCategoryLabelsVisibility(isAll);
            
            // Hide "Show All" button when filtering specific categories
            if (!isAll && showAllBtn) {
                showAllBtn.parentElement.style.display = 'none';
            }
            
            items.forEach(item => {
                const itemCat = item.getAttribute('data-category');
                
                // Reset display state
                item.style.display = 'none';
                item.style.opacity = '0';
                
                if (isAll || category === itemCat) {
                    // Rispettiamo l'hidden iniziale se "Mostra tutti" è attivo
                    if (isAll && showAllBtn && showAllBtn.parentElement.style.display !== 'none' && item.classList.contains('synergy-item-hidden')) {
                        // resta nascosto logicamente
                    } else {
                        item.style.display = 'block';
                        // Fade in effect
                        setTimeout(() => {
                            item.style.opacity = '1';
                        }, 50);
                    }
                }
            });
            
            if (isAll && showAllBtn) {
                // Controlla se ci sono elementi nascosti con la classe synergy-item-hidden
                const hiddenItems = document.querySelectorAll('.synergy-price-card.synergy-item-hidden');
                if (hiddenItems.length > 0) {
                    showAllBtn.parentElement.style.display = 'block';
                }
            }
            
        });
    });
    
    // Accordion Variants
    const headers = document.querySelectorAll('.synergy-price-card__inner.has-variants');
    headers.forEach(header => {
        header.addEventListener('click', function(e) {
            e.preventDefault();
            const parentItem = this.closest('.synergy-price-card');
            const variantsBox = parentItem.querySelector('.synergy-price-card__variants');
            
            if (variantsBox) {
                if (variantsBox.style.display === 'block') {
                    // Close
                    variantsBox.style.display = 'none';
                    parentItem.classList.remove('variants-open');
                } else {
                    // Open
                    variantsBox.style.display = 'block';
                    parentItem.classList.add('variants-open');
                }
            }
        });
    });

});
