(function($) {
    'use strict';

    $(document).ready(function() {
        
        let currentPage = 1;
        let isFetching = false;
        
        const $grid = $('#prodotti-grid');
        const $loadMoreBtn = $('#load-more-btn');
        const $resultsCount = $('#results-count-text');
        const $activeFiltersContainer = $('#active-filters-container');
        const $clearFiltersBtn = $('#clear-filters-btn');

        // Mobile drawer elements
        const $sidebar = $('#catalog-sidebar');
        const $overlay = $('#mobile-drawer-overlay');
        const $mobileFilterTrigger = $('#mobile-filter-trigger');
        const $closeMobileFilter = $('#close-mobile-filter');
        const $mobileApplyBtn = $('#mobile-apply-filters');
        const $mobileResetBtn = $('#mobile-reset-filters');
        const mobileDrawerQuery = window.matchMedia('(max-width: 1024px)');
        let drawerPreviouslyFocused = null;

        // Initialise state from URL if present
        function initFromUrl() {
            const params = new URLSearchParams(window.location.search);
            
            if(params.has('search')) $('#filter-search').val(params.get('search'));
            if(params.has('orderby')) {
                const orderVal = params.get('orderby');
                $('#prodotti-sort').val(orderVal);
                if ($customDropdown && $customDropdown.length) {
                    const $matchingItem = $dropdownItems.filter('[data-value="' + orderVal + '"]');
                    if ($matchingItem.length) {
                        $dropdownItems.removeClass('active').attr('aria-selected', 'false');
                        $matchingItem.addClass('active').attr('aria-selected', 'true');
                        $dropdownLabel.text($matchingItem.text());
                    }
                }
            }
            if(params.has('min_price')) $('#price-min').val(params.get('min_price'));
            if(params.has('max_price')) $('#price-max').val(params.get('max_price'));
            
            if(params.has('category')) {
                const cats = params.get('category').split(',');
                $('input[name="filter_cat"]').each(function() {
                    if (cats.includes($(this).val())) $(this).prop('checked', true);
                });
            }
            if(params.has('brand')) {
                const brands = params.get('brand').split(',');
                $('input[name="filter_brand"]').each(function() {
                    if (brands.includes($(this).val())) $(this).prop('checked', true);
                });
            }
            
            updateActiveFilterChips();
        }

        function getFilterState() {
            const state = {
                search: $('#filter-search').val().trim(),
                orderby: $('#prodotti-sort').val(),
                min_price: $('#price-min').val(),
                max_price: $('#price-max').val(),
                category: [],
                brand: []
            };

            $('input[name="filter_cat"]:checked').each(function() {
                state.category.push($(this).val());
            });

            $('input[name="filter_brand"]:checked').each(function() {
                state.brand.push($(this).val());
            });

            return state;
        }

        function updateUrl(state) {
            const params = new URLSearchParams();
            
            if (state.search) params.set('search', state.search);
            if (state.orderby && state.orderby !== 'default') params.set('orderby', state.orderby);
            if (state.min_price) params.set('min_price', state.min_price);
            if (state.max_price) params.set('max_price', state.max_price);
            if (state.category.length > 0) params.set('category', state.category.join(','));
            if (state.brand.length > 0) params.set('brand', state.brand.join(','));

            const newUrl = window.location.pathname + (params.toString() ? '?' + params.toString() : '');
            window.history.pushState({path: newUrl}, '', newUrl);
        }

        function updateActiveFilterChips() {
            $activeFiltersContainer.empty();
            const state = getFilterState();
            let hasFilters = false;

            if (state.search) {
                hasFilters = true;
                $activeFiltersContainer.append(`<div class="filter-chip" data-type="search">Ricerca: ${state.search} <span class="remove">&times;</span></div>`);
            }

            const inputMaxEl = document.getElementById('price-max');
            const defaultMax = inputMaxEl ? (parseInt(inputMaxEl.getAttribute('max')) || 500) : 500;
            const currentMin = parseInt(state.min_price) || 0;
            const currentMax = parseInt(state.max_price) || defaultMax;

            if (currentMin > 0 || (currentMax > 0 && currentMax < defaultMax)) {
                hasFilters = true;
                $activeFiltersContainer.append(`<div class="filter-chip" data-type="price">CHF ${currentMin} - ${currentMax} <span class="remove">&times;</span></div>`);
            }

            $('input[name="filter_cat"]:checked').each(function() {
                hasFilters = true;
                $activeFiltersContainer.append(`<div class="filter-chip" data-type="cat" data-val="${$(this).val()}">${$(this).data('label')} <span class="remove">&times;</span></div>`);
            });

            $('input[name="filter_brand"]:checked').each(function() {
                hasFilters = true;
                $activeFiltersContainer.append(`<div class="filter-chip" data-type="brand" data-val="${$(this).val()}">${$(this).data('label')} <span class="remove">&times;</span></div>`);
            });

            // Sync Category Pills Bar active state
            const $categoryPillBtns = $('.category-pill-btn');
            if ($categoryPillBtns.length) {
                const checkedCats = $('input[name="filter_cat"]:checked');
                $categoryPillBtns.removeClass('active');
                if (checkedCats.length === 1) {
                    const activeSlug = checkedCats.first().val();
                    const $matchingPill = $categoryPillBtns.filter(`[data-slug="${activeSlug}"]`);
                    if ($matchingPill.length) {
                        $matchingPill.addClass('active');
                    } else {
                        $categoryPillBtns.filter('[data-slug="all"]').addClass('active');
                    }
                } else if (checkedCats.length === 0) {
                    $categoryPillBtns.filter('[data-slug="all"]').addClass('active');
                }
            }

            if (hasFilters) {
                $clearFiltersBtn.removeClass('hidden');
            } else {
                $clearFiltersBtn.addClass('hidden');
            }
        }

        function fetchProducts(append = false) {
            if (isFetching) return;
            isFetching = true;

            const state = getFilterState();
            updateUrl(state);
            updateActiveFilterChips();

            if (!append) {
                currentPage = 1;
                $grid.addClass('loading');
            }

            $.ajax({
                url: synergyAjax.ajaxurl,
                type: 'GET',
                data: {
                    action: 'synergy_filter_products',
                    paged: currentPage,
                    search: state.search,
                    category: state.category.join(','),
                    brand: state.brand.join(','),
                    min_price: state.min_price,
                    max_price: state.max_price,
                    orderby: state.orderby
                },
                success: function(res) {
                    if (res.success) {
                        if (append) {
                            $grid.append(res.data.html);
                        } else {
                            $grid.html(res.data.html);
                            $grid.removeClass('loading');
                        }

                        $resultsCount.html(`Trovati <strong>${res.data.total}</strong> prodotti`);
                        $('#mobile-apply-filters').text(`Vedi ${res.data.total} prodotti`);

                        if (currentPage >= res.data.max_pages) {
                            $loadMoreBtn.hide();
                        } else {
                            $loadMoreBtn.show();
                        }
                        
                        // Update dynamic counts
                        if (res.data.counts) {
                            // Reset all labels to 0 and add filter-empty class
                            $('.custom-checkbox').addClass('filter-empty');
                            $('.term-count').text('(0)');
                            
                            // Update categories
                            if (res.data.counts.product_cat) {
                                let cigliaCapelliCount = 0;
                                
                                $.each(res.data.counts.product_cat, function(slug, count) {
                                    if (slug === 'ciglia' || slug === 'capelli-labbra') {
                                        cigliaCapelliCount += count;
                                    }
                                    let $checkbox = $(`.custom-checkbox[data-tax="product_cat"][data-slug="${slug}"]`);
                                    if ($checkbox.length) {
                                        $checkbox.removeClass('filter-empty');
                                        $checkbox.find('.term-count').text(`(${count})`);
                                    }
                                });
                                
                                // Update merged category
                                let $mergedCheckbox = $(`.custom-checkbox[data-tax="product_cat"][data-slug="ciglia-capelli-labbra"]`);
                                if ($mergedCheckbox.length && cigliaCapelliCount > 0) {
                                    $mergedCheckbox.removeClass('filter-empty');
                                    $mergedCheckbox.find('.term-count').text(`(${cigliaCapelliCount})`);
                                }
                            }
                            
                            // Update brands
                            if (res.data.counts.product_brand) {
                                $.each(res.data.counts.product_brand, function(slug, count) {
                                    let $checkbox = $(`.custom-checkbox[data-tax="product_brand"][data-slug="${slug}"]`);
                                    if ($checkbox.length) {
                                        $checkbox.removeClass('filter-empty');
                                        $checkbox.find('.term-count').text(`(${count})`);
                                    }
                                });
                            }
                        }
                    }
                    isFetching = false;
                },
                error: function() {
                    $grid.removeClass('loading');
                    isFetching = false;
                }
            });
        }

        // Event Listeners
        
        // noUiSlider Initialization
        const sliderElement = document.getElementById('price-slider');
        const inputMin = document.getElementById('price-min');
        const inputMax = document.getElementById('price-max');
        
        if (sliderElement && inputMin && inputMax) {
            const maxVal = parseInt(inputMax.getAttribute('max')) || 500;
            const initMin = parseInt(inputMin.value) || 0;
            const initMax = parseInt(inputMax.value) || maxVal;
            
            noUiSlider.create(sliderElement, {
                start: [initMin, initMax],
                connect: true,
                step: 1,
                range: {
                    'min': 0,
                    'max': maxVal
                },
                format: {
                    to: function (value) { return Math.round(value); },
                    from: function (value) { return Math.round(value); }
                }
            });

            // EASTER EGG VARIABLES
            let eeLastValue = null;
            let eeLastDirection = null;
            let eeDirectionChanges = [];
            let eeIsRunning = false;
            let eeLastTriggerTime = 0;

            function triggerProductEarthquake() {
                if (eeIsRunning) return;

                eeIsRunning = true;

                const grid = document.querySelector('.prodotti-grid');
                if (!grid) {
                    eeIsRunning = false;
                    return;
                }

                const cards = grid.querySelectorAll('.product-card, .synergy-product-card');
                if (!cards.length) {
                    eeIsRunning = false;
                    return;
                }

                const isMobile = window.matchMedia('(max-width: 768px)').matches;
                const viewportFall = window.innerHeight + (isMobile ? 180 : 340);
                const viewportReturn = -(window.innerHeight + (isMobile ? 160 : 300));

                grid.classList.add('is-earthquake');

                cards.forEach((card, index) => {
                    const delay = Math.min(index * (isMobile ? 22 : 34), isMobile ? 180 : 320);
                    const fallX = Math.round(-90 + Math.random() * 180);
                    const fallY = Math.round(viewportFall + Math.random() * 220);
                    const fallRotate = (-18 + Math.random() * 36).toFixed(2);
                    const returnX = Math.round(-60 + Math.random() * 120);
                    const returnY = Math.round(viewportReturn - Math.random() * 180);
                    const returnRotate = (-10 + Math.random() * 20).toFixed(2);
                    const quakeX = Math.round(-8 + Math.random() * 16);

                    card.style.setProperty('--delay', `${delay}ms`);
                    card.style.setProperty('--quake-x', `${quakeX}px`);
                    card.style.setProperty('--fall-x', `${fallX}px`);
                    card.style.setProperty('--fall-y', `${fallY}px`);
                    card.style.setProperty('--fall-rotate', `${fallRotate}deg`);
                    card.style.setProperty('--return-x', `${returnX}px`);
                    card.style.setProperty('--return-y', `${returnY}px`);
                    card.style.setProperty('--return-rotate', `${returnRotate}deg`);
                });

                const totalDuration = isMobile ? 3400 : 4100;

                setTimeout(() => {
                    resetProductEarthquake(grid, cards);
                }, totalDuration);
            }

            function resetProductEarthquake(grid, cards) {
                grid.classList.remove('is-earthquake');

                cards.forEach(card => {
                    card.style.removeProperty('--delay');
                    card.style.removeProperty('--quake-x');
                    card.style.removeProperty('--fall-x');
                    card.style.removeProperty('--fall-y');
                    card.style.removeProperty('--fall-rotate');
                    card.style.removeProperty('--return-x');
                    card.style.removeProperty('--return-y');
                    card.style.removeProperty('--return-rotate');
                    card.style.transform = '';
                    card.style.opacity = '';
                    card.style.pointerEvents = '';
                });

                eeIsRunning = false;
            }

            // Sync Slider -> Inputs
            sliderElement.noUiSlider.on('update', function (values, handle) {
                if (handle === 0) {
                    inputMin.value = values[0];
                } else {
                    inputMax.value = values[1];
                }
                updateHistogramVisuals(values[0], values[1], maxVal);

                // EASTER EGG LOGIC
                const currentValue = parseFloat(values[handle]);
                if (eeLastValue === null) {
                    eeLastValue = currentValue;
                } else {
                    const diff = currentValue - eeLastValue;
                    if (diff !== 0) {
                        const direction = diff > 0 ? 'up' : 'down';
                        if (eeLastDirection && direction !== eeLastDirection) {
                            const now = Date.now();
                            eeDirectionChanges.push(now);
                            eeDirectionChanges = eeDirectionChanges.filter(t => now - t < 2500);

                            if (eeDirectionChanges.length >= 8 && !eeIsRunning && now - eeLastTriggerTime > 12000) {
                                triggerProductEarthquake();
                                eeLastTriggerTime = now;
                                eeDirectionChanges = [];
                            }
                        }
                        eeLastDirection = direction;
                    }
                    eeLastValue = currentValue;
                }
            });

            // Trigger fetch on slider change (end of drag)
            sliderElement.noUiSlider.on('change', function () {
                fetchProducts(false);
            });

            // Sync Inputs -> Slider
            inputMin.addEventListener('change', function () {
                sliderElement.noUiSlider.set([this.value, null]);
                fetchProducts(false);
            });

            inputMax.addEventListener('change', function () {
                sliderElement.noUiSlider.set([null, this.value]);
                fetchProducts(false);
            });
            
            function updateHistogramVisuals(min, max, maxPrice) {
                const totalBars = $('.histogram-bar').length;
                if (totalBars === 0) return;
                
                const binWidth = Math.max(1, Math.ceil(maxPrice / totalBars));
                
                $('.histogram-bar').each(function(i) {
                    const binMin = i * binWidth;
                    const binMax = (i + 1) * binWidth;
                    
                    // If the bin overlaps with the selected range, make it active
                    if (binMax >= min && binMin <= max) {
                        $(this).removeClass('inactive');
                    } else {
                        $(this).addClass('inactive');
                    }
                });
            }
        }

        let debounceTimer;
        $('#filter-search').on('input', function() {
            clearTimeout(debounceTimer);
            debounceTimer = setTimeout(() => {
                fetchProducts(false);
            }, 500);
        });

        $('input[name="filter_cat"], input[name="filter_brand"], #prodotti-sort').on('change', function() {
            fetchProducts(false);
        });

        $loadMoreBtn.on('click', function() {
            currentPage++;
            fetchProducts(true);
        });

        $clearFiltersBtn.on('click', function() {
            resetAllFilters();
            fetchProducts(false);
        });

        $(document).on('click', '#synergy-reset-empty', function() {
            resetAllFilters();
            fetchProducts(false);
        });

        // Click sulle X dei chip
        $activeFiltersContainer.on('click', '.filter-chip', function(e) {
            e.preventDefault();
            e.stopPropagation();
            const type = $(this).data('type');
            const val = $(this).data('val');

            if (type === 'search') $('#filter-search').val('');
            if (type === 'price') {
                const sliderEl = document.getElementById('price-slider');
                const maxEl = document.getElementById('price-max');
                $('#price-min').val('');
                $('#price-max').val('');
                if (sliderEl && sliderEl.noUiSlider) {
                    const maxVal = maxEl ? (parseInt(maxEl.getAttribute('max')) || 500) : 500;
                    sliderEl.noUiSlider.set([0, maxVal]);
                }
            }
            if (type === 'cat') $(`input[name="filter_cat"][value="${val}"]`).prop('checked', false);
            if (type === 'brand') $(`input[name="filter_brand"][value="${val}"]`).prop('checked', false);

            fetchProducts(false);
        });

        function resetAllFilters() {
            $('#filter-search').val('');
            const sliderEl = document.getElementById('price-slider');
            const maxEl = document.getElementById('price-max');
            $('#price-min').val('');
            $('#price-max').val('');
            if (sliderEl && sliderEl.noUiSlider) {
                const maxVal = maxEl ? (parseInt(maxEl.getAttribute('max')) || 500) : 500;
                sliderEl.noUiSlider.set([0, maxVal]);
            }
            $('#prodotti-sort').val('default');
            if ($customDropdown && $customDropdown.length) {
                $dropdownItems.removeClass('active').attr('aria-selected', 'false');
                $dropdownItems.filter('[data-value="default"]').addClass('active').attr('aria-selected', 'true');
                $dropdownLabel.text((window.synergyI18n && window.synergyI18n.sortDefault) || 'Ordinamento predefinito');
            }
            $('input[type="checkbox"]').prop('checked', false);
        }

        // --- Custom Synergy Sort Dropdown Component Logic ---
        const $customDropdown = $('#synergy-sort-dropdown');
        const $dropdownTrigger = $('#sort-dropdown-trigger');
        const $dropdownLabel = $customDropdown.find('.synergy-dropdown-label');
        const $dropdownItems = $customDropdown.find('.synergy-dropdown-item');

        if ($customDropdown.length) {
            function openSortDropdown($itemToFocus) {
                $customDropdown.addClass('active');
                $dropdownTrigger.attr('aria-expanded', 'true');

                if ($itemToFocus && $itemToFocus.length) {
                    window.requestAnimationFrame(function() {
                        $itemToFocus.trigger('focus');
                    });
                }
            }

            function closeSortDropdown(restoreFocus) {
                $customDropdown.removeClass('active');
                $dropdownTrigger.attr('aria-expanded', 'false');

                if (restoreFocus) {
                    $dropdownTrigger.trigger('focus');
                }
            }

            function selectSortOption($item) {
                const value = $item.data('value');
                const labelText = $item.text();

                $dropdownItems.removeClass('active').attr('aria-selected', 'false');
                $item.addClass('active').attr('aria-selected', 'true');
                $dropdownLabel.text(labelText);
                closeSortDropdown(true);
                $('#prodotti-sort').val(value).trigger('change');
            }

            $dropdownTrigger.on('click', function(e) {
                e.stopPropagation();
                if ($customDropdown.hasClass('active')) {
                    closeSortDropdown(false);
                } else {
                    openSortDropdown();
                }
            });

            $dropdownTrigger.on('keydown', function(e) {
                if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
                    e.preventDefault();
                    const $selected = $dropdownItems.filter('[aria-selected="true"]');
                    const $fallback = e.key === 'ArrowUp' ? $dropdownItems.last() : $dropdownItems.first();
                    openSortDropdown($selected.length ? $selected : $fallback);
                }
            });

            $dropdownItems.on('click', function(e) {
                e.stopPropagation();
                selectSortOption($(this));
            });

            $dropdownItems.on('keydown', function(e) {
                const currentIndex = $dropdownItems.index(this);
                let nextIndex = currentIndex;

                if (e.key === 'ArrowDown') nextIndex = (currentIndex + 1) % $dropdownItems.length;
                if (e.key === 'ArrowUp') nextIndex = (currentIndex - 1 + $dropdownItems.length) % $dropdownItems.length;
                if (e.key === 'Home') nextIndex = 0;
                if (e.key === 'End') nextIndex = $dropdownItems.length - 1;

                if (nextIndex !== currentIndex) {
                    e.preventDefault();
                    $dropdownItems.eq(nextIndex).trigger('focus');
                } else if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    selectSortOption($(this));
                } else if (e.key === 'Escape') {
                    e.preventDefault();
                    closeSortDropdown(true);
                } else if (e.key === 'Tab') {
                    closeSortDropdown(false);
                }
            });

            $(document).on('click', function(e) {
                if (!$(e.target).closest('#synergy-sort-dropdown').length) {
                    closeSortDropdown(false);
                }
            });

            $(document).on('keydown', function(e) {
                if (e.key === 'Escape' && $customDropdown.hasClass('active')) {
                    closeSortDropdown(true);
                }
            });
        }

        // --- Category Pills Bar Logic ---
        const $categoryPillBtns = $('.category-pill-btn');
        if ($categoryPillBtns.length) {
            $categoryPillBtns.on('click', function(e) {
                e.preventDefault();
                const slug = $(this).data('slug');

                $categoryPillBtns.removeClass('active');
                $(this).addClass('active');

                $('input[name="filter_cat"]').prop('checked', false);

                if (slug !== 'all') {
                    const $targetCheckbox = $(`input[name="filter_cat"][value="${slug}"]`);
                    if ($targetCheckbox.length) {
                        $targetCheckbox.prop('checked', true);
                    }
                }

                fetchProducts(false);
            });
        }

        // --- AJAX Add to Cart for Product Cards ---
        $(document).on('click', '.synergy-add-to-cart-btn', function(e) {
            e.preventDefault();
            e.stopPropagation();

            const $btn = $(this);
            const productId = $btn.data('product_id');
            if (!productId || $btn.hasClass('loading')) return;

            const originalText = (window.synergyI18n && window.synergyI18n.addToCart) || 'Aggiungi al carrello';
            $btn.addClass('loading').text((window.synergyI18n && window.synergyI18n.adding) || 'Aggiunta...');

            $.ajax({
                type: 'POST',
                url: synergyAjax.ajaxurl,
                data: {
                    action: 'synergy_add_to_cart',
                    product_id: productId
                },
                success: function(res) {
                    if (res && res.success) {
                        $btn.removeClass('loading').addClass('added').text((window.synergyI18n && window.synergyI18n.added) || 'Aggiunto ✓');
                        
                        var newCount = (res.data && res.data.cart_count !== undefined) ? parseInt(res.data.cart_count, 10) : 0;
                        var fragments = res.data ? res.data.fragments : null;
                        var cartHash = res.data ? res.data.cart_hash : '';

                        var $badge = $('.header-cart-badge');
                        if ($badge.length) {
                            $badge.text(newCount);
                            if (newCount > 0) {
                                $badge.css('display', 'inline-flex').show().addClass('pop');
                                setTimeout(function() {
                                    $badge.removeClass('pop');
                                }, 400);
                            } else {
                                $badge.hide();
                            }
                        }

                        // Aggiorna sessionStorage di WooCommerce per preservare i frammenti tra le pagine
                        if (typeof wc_cart_fragments_params !== 'undefined' && fragments) {
                            try {
                                sessionStorage.setItem(wc_cart_fragments_params.fragment_name, JSON.stringify(fragments));
                                if (cartHash) {
                                    sessionStorage.setItem(wc_cart_fragments_params.cart_hash_key, cartHash);
                                }
                            } catch(e) {}
                        }

                        $(document.body).trigger('wc_fragment_refresh');
                        $(document.body).trigger('added_to_cart', [fragments, cartHash, $btn]);

                        setTimeout(function() {
                            $btn.removeClass('added').text(originalText);
                        }, 2200);
                    } else {
                        $btn.removeClass('loading').text((window.synergyI18n && window.synergyI18n.error) || 'Errore');
                        setTimeout(function() {
                            $btn.text(originalText);
                        }, 2000);
                    }
                },
                error: function() {
                    $btn.removeClass('loading').text((window.synergyI18n && window.synergyI18n.error) || 'Errore');
                    setTimeout(function() {
                        $btn.text(originalText);
                    }, 2000);
                }
            });
        });

        // Mobile Drawer logic
        function syncDrawerAccessibility() {
            const isMobileDrawer = mobileDrawerQuery.matches;
            const isOpen = $sidebar.hasClass('drawer-open');

            if (isMobileDrawer) {
                $sidebar.attr({
                    'role': 'dialog',
                    'aria-modal': 'true',
                    'aria-hidden': isOpen ? 'false' : 'true'
                });
                $sidebar.prop('inert', !isOpen);
            } else {
                $sidebar.removeAttr('role aria-modal aria-hidden').prop('inert', false);
                $sidebar.removeClass('drawer-open');
                $overlay.removeClass('active');
                $('body').removeClass('filters-open');
                $mobileFilterTrigger.attr('aria-expanded', 'false');
            }
        }

        function getDrawerFocusableElements() {
            return $sidebar.find('a[href], button:not([disabled]), input:not([disabled]), select:not([disabled]), textarea:not([disabled]), details > summary, [tabindex]:not([tabindex="-1"])').filter(function() {
                return this.getClientRects().length > 0;
            });
        }

        function openDrawer() {
            drawerPreviouslyFocused = document.activeElement;
            $sidebar.addClass('drawer-open');
            $overlay.addClass('active');
            $('body').addClass('filters-open');
            $mobileFilterTrigger.attr('aria-expanded', 'true');
            syncDrawerAccessibility();

            window.requestAnimationFrame(function() {
                $closeMobileFilter.trigger('focus');
            });
        }

        function closeDrawer(restoreFocus) {
            $sidebar.removeClass('drawer-open');
            $overlay.removeClass('active');
            $('body').removeClass('filters-open');
            $mobileFilterTrigger.attr('aria-expanded', 'false');
            syncDrawerAccessibility();

            if (restoreFocus !== false) {
                const focusTarget = drawerPreviouslyFocused && document.contains(drawerPreviouslyFocused)
                    ? drawerPreviouslyFocused
                    : $mobileFilterTrigger.get(0);
                if (focusTarget) focusTarget.focus();
            }
        }

        $mobileFilterTrigger.on('click', openDrawer);
        $closeMobileFilter.on('click', function() { closeDrawer(true); });
        $overlay.on('click', function() { closeDrawer(true); });
        
        // Close with Escape key
        $(document).on('keydown', function(e) {
            if (e.key === "Escape" && $('body').hasClass('filters-open')) {
                closeDrawer(true);
                return;
            }

            if (e.key === 'Tab' && $('body').hasClass('filters-open')) {
                const $focusable = getDrawerFocusableElements();
                if (!$focusable.length) return;

                const firstElement = $focusable.get(0);
                const lastElement = $focusable.get($focusable.length - 1);

                if (e.shiftKey && document.activeElement === firstElement) {
                    e.preventDefault();
                    lastElement.focus();
                } else if (!e.shiftKey && document.activeElement === lastElement) {
                    e.preventDefault();
                    firstElement.focus();
                }
            }
        });
        
        $mobileApplyBtn.on('click', function() {
            closeDrawer(true);
            fetchProducts(false);
        });

        $mobileResetBtn.on('click', function() {
            resetAllFilters();
            // User sees them empty, can then apply
        });

        syncDrawerAccessibility();
        if (typeof mobileDrawerQuery.addEventListener === 'function') {
            mobileDrawerQuery.addEventListener('change', syncDrawerAccessibility);
        } else {
            mobileDrawerQuery.addListener(syncDrawerAccessibility);
        }

        // Initialize
        initFromUrl();
        // We don't fetchProducts on load if it's the first time because PHP already rendered it,
        // but if URL has params, we should fetch immediately to reflect filters correctly.
        if (window.location.search) {
            fetchProducts(false);
        }

    });

})(jQuery);
