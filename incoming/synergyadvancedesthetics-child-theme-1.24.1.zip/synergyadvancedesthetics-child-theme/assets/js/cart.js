(function($) {
    'use strict';

    $(document).ready(function() {

        var cartScrollPosition = null;
        var cartCouponScrollPosition = null;

        // WooCommerce inserisce gli errori del coupon direttamente nella riga
        // flex del coupon e, dopo l'aggiornamento AJAX, esegue uno scroll verso
        // l'alert. Usiamo invece un feedback del tema, come nel checkout.
        var cartCouponErrorText = (window.synergyI18n && window.synergyI18n.couponError) || 'Il codice promozionale inserito non è valido. Controllalo e riprova.';
        var cartCouponSuccessText = (window.synergyI18n && window.synergyI18n.couponSuccess) || 'Codice promozionale applicato con successo.';

        function removeNativeCartCouponSuccess() {
            $('.woocommerce-message').filter(function() {
                var messageText = $(this).text().toLowerCase();
                return messageText.indexOf('codice promozionale') !== -1 ||
                    messageText.indexOf('coupon') !== -1 ||
                    messageText.indexOf('applicato con successo') !== -1;
            }).remove();
        }

        function removeCartCouponSuccess() {
            $('.synergy-cart-coupon-success').remove();
        }

        function showCartCouponSuccess() {
            var $couponCard = $('.synergy-coupon-card');

            if (!$couponCard.length) {
                return;
            }

            removeCartCouponSuccess();
            $('<p>', {
                class: 'synergy-cart-coupon-success',
                role: 'status',
                'aria-live': 'polite',
                text: cartCouponSuccessText
            }).insertAfter($couponCard);
        }

        function restoreCartCouponPosition() {
            if (cartCouponScrollPosition === null) {
                return;
            }

            var savedScrollPosition = cartCouponScrollPosition;
            cartCouponScrollPosition = null;

            window.setTimeout(function() {
                $('html, body').stop(true, true).scrollTop(savedScrollPosition);
            }, 0);
        }

        function removeNativeCartCouponError() {
            var $coupon = $('.synergy-coupon-card .coupon');

            $coupon.find('.coupon-error-notice').remove();
            $coupon.find('#coupon_code')
                .removeClass('has-error')
                .removeAttr('aria-invalid')
                .removeAttr('aria-describedby');
        }

        function resetCartCouponError() {
            removeNativeCartCouponError();
            $('.synergy-coupon-card')
                .removeClass('synergy-coupon-has-error')
                .find('.synergy-cart-coupon-feedback')
                .remove();
        }

        function resetCartCouponFeedback() {
            resetCartCouponError();
            removeCartCouponSuccess();
        }

        function setCartCouponError() {
            var $card = $('.synergy-coupon-card');

            removeNativeCartCouponError();
            $card.addClass('synergy-coupon-has-error');
            $card.find('#coupon_code')
                .attr('aria-invalid', 'true')
                .attr('aria-describedby', 'synergy-cart-coupon-feedback');
            $card.find('.synergy-cart-coupon-feedback').remove();
            $('<p>', {
                id: 'synergy-cart-coupon-feedback',
                class: 'synergy-cart-coupon-feedback',
                role: 'alert',
                text: cartCouponErrorText
            }).appendTo($card);
        }

        resetCartCouponError();

        $(document.body).on('applied_coupon.synergyCartCoupon', function() {
            var hasError = $('.synergy-coupon-card .coupon-error-notice').length > 0;

            if (hasError) {
                setCartCouponError();
            } else {
                resetCartCouponError();
                removeNativeCartCouponSuccess();
                showCartCouponSuccess();
            }

            // L'errore viene ricreato da WooCommerce durante updated_wc_div.
            // Lo sostituiamo prima del completamento AJAX: così non resta alcun
            // alert nativo verso cui il core possa effettuare lo scroll.
            $(document.body).one('updated_wc_div.synergyCartCoupon', function() {
                if (hasError) {
                    setCartCouponError();
                } else {
                    resetCartCouponError();
                    removeNativeCartCouponSuccess();
                    showCartCouponSuccess();
                }
                restoreCartCouponPosition();
            });
        });

        $(document.body).on('input.synergyCartCoupon', '.synergy-coupon-card #coupon_code', resetCartCouponFeedback);
        $(document.body).on('click.synergyCartCoupon', '.synergy-coupon-card button[name="apply_coupon"]', function() {
            cartCouponScrollPosition = window.pageYOffset || window.scrollY || 0;
            resetCartCouponFeedback();
        });
        $(document.body).on('keydown.synergyCartCoupon', '.synergy-coupon-card #coupon_code', function(event) {
            if (event.key === 'Enter') {
                cartCouponScrollPosition = window.pageYOffset || window.scrollY || 0;
                resetCartCouponFeedback();
            }
        });
        $(document.body).on('click.synergyCartCoupon', '.woocommerce-remove-coupon', function() {
            cartCouponScrollPosition = window.pageYOffset || window.scrollY || 0;
            removeCartCouponSuccess();
        });
        $(document.body).on('removed_coupon.synergyCartCoupon', function() {
            removeNativeCartCouponSuccess();

            $(document.body).one('updated_wc_div.synergyCartCouponRemoval', function() {
                removeNativeCartCouponSuccess();
                restoreCartCouponPosition();
            });
        });
        $(document.body).on('updated_wc_div.synergyCartCoupon', resetCartCouponError);

        // 1. Inietta bottoni quantità custom
        function initCustomQuantity() {
            var $qtyInputs = $('form.woocommerce-cart-form .quantity input[type="number"]');
            
            $qtyInputs.each(function() {
                var $qtyInput = $(this);
                
                // Evita di aggiungere bottoni doppi se lo script gira più volte
                if ($qtyInput.siblings('.qty-btn').length > 0) return;
                
                var min = parseFloat($qtyInput.attr('min')) || 0;
                var max = parseFloat($qtyInput.attr('max')) || 999;
                
                var $minusBtn = $('<button type="button" class="qty-btn qty-minus">-</button>');
                var $plusBtn = $('<button type="button" class="qty-btn qty-plus">+</button>');
                
                $minusBtn.insertBefore($qtyInput);
                $plusBtn.insertAfter($qtyInput);

                $plusBtn.on('click', function() {
                    var currentVal = parseFloat($qtyInput.val()) || 0;
                    if (currentVal < max) {
                        $qtyInput.val(currentVal + 1).trigger('change');
                    }
                });

                $minusBtn.on('click', function() {
                    var currentVal = parseFloat($qtyInput.val()) || 0;
                    if (currentVal > min) {
                        $qtyInput.val(currentVal - 1).trigger('change');
                    }
                });
            });
        }

        // Inizializza al caricamento della pagina
        initCustomQuantity();

        // Ri-inizializza dopo che WooCommerce aggiorna il carrello via AJAX
        $(document.body).on('updated_wc_div', function() {
            initCustomQuantity();

            // WooCommerce prova a scorrere verso i notice dopo l'update AJAX.
            // Per le modifiche quantità manteniamo invece l'utente sul prodotto
            // che sta aggiornando, sia su desktop sia su mobile.
            if (cartScrollPosition !== null) {
                var savedScrollPosition = cartScrollPosition;
                cartScrollPosition = null;

                window.setTimeout(function() {
                    $('html, body').stop(true).scrollTop(savedScrollPosition);
                }, 0);
            }
        });


        // 2. Accordion Coupon
        $(document).on('click', '.synergy-coupon-toggle', function() {
            $(this).toggleClass('active');
            $(this).next('.synergy-coupon-content').slideToggle(300);
        });

        // Simula il click del bottone aggiorna carrello quando cambia la quantità
        // (WooCommerce di solito lo fa nativamente se il bottone non è disabilitato,
        // ma forzarlo rende l'UX più fluida senza che l'utente debba cliccare 'Aggiorna carrello').
        var timeout;
        $(document.body).on('change', 'form.woocommerce-cart-form .quantity input[type="number"]', function() {
            cartScrollPosition = window.pageYOffset || window.scrollY || 0;

            if ( timeout !== undefined ) {
                clearTimeout( timeout );
            }
            timeout = setTimeout(function() {
                $('[name="update_cart"]').trigger('click');
            }, 500 );
        });

        // Salva la posizione di scroll anche quando si rimuove un prodotto dal carrello
        $(document.body).on('click', 'form.woocommerce-cart-form .remove', function() {
            cartScrollPosition = window.pageYOffset || window.scrollY || 0;
        });

    });

})(jQuery);
