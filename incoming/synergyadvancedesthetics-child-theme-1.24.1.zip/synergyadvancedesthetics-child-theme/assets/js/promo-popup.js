/**
 * Synergy Advanced Aesthetics - Promotion Popup Script
 * 
 * Manages the automatic appearance, dismiss state, and smooth transitions
 * for the dynamic CMS promo modal.
 */

(function() {
    'use strict';

    document.addEventListener('DOMContentLoaded', function() {
        var modal = document.getElementById('synergy-promo-popup-modal');
        if (!modal) return;

        var overlay = document.getElementById('synergy-promo-modal-overlay');
        var closeBtn = document.getElementById('synergy-promo-modal-close');
        var dismissBtn = document.getElementById('synergy-promo-modal-dismiss');
        var ctaBtn = document.getElementById('synergy-promo-modal-cta-btn');

        function openModal() {
            modal.classList.add('is-active');
            modal.setAttribute('aria-hidden', 'false');
            document.body.classList.add('synergy-modal-open');
        }

        function closeModal() {
            modal.classList.remove('is-active');
            modal.setAttribute('aria-hidden', 'true');
            document.body.classList.remove('synergy-modal-open');
        }

        // Trigger on load: always display on page refresh/visit
        setTimeout(function() {
            openModal();
        }, 750);

        // Close triggers
        if (closeBtn) {
            closeBtn.addEventListener('click', function(e) {
                e.preventDefault();
                closeModal();
            });
        }

        if (dismissBtn) {
            dismissBtn.addEventListener('click', function(e) {
                e.preventDefault();
                closeModal();
            });
        }

        if (overlay) {
            overlay.addEventListener('click', function(e) {
                e.preventDefault();
                closeModal();
            });
        }

        // Close on ESC key
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape' || e.keyCode === 27) {
                if (modal.classList.contains('is-active')) {
                    closeModal();
                }
            }
        });

        // CTA button handling
        if (ctaBtn) {
            ctaBtn.addEventListener('click', function(e) {
                var targetHref = ctaBtn.getAttribute('href');
                closeModal();

                if (targetHref && targetHref.indexOf('#') !== -1) {
                    var hash = targetHref.substring(targetHref.indexOf('#'));
                    var targetEl = document.querySelector(hash);
                    if (targetEl) {
                        e.preventDefault();
                        setTimeout(function() {
                            targetEl.scrollIntoView({ behavior: 'smooth' });
                        }, 250);
                    }
                }
            });
        }
    });
})();
