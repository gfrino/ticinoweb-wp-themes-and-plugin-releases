(function($) {
    'use strict';

    $(document).ready(function() {

        // 1. Inietta bottoni quantità custom se esiste il campo quantità
        var $qtyInput = $('form.cart .quantity input[type="number"]');
        if ( $qtyInput.length ) {
            // Rimuovi eventuali bottoni preesistenti per sicurezza
            $('form.cart .quantity .qty-btn').remove();

            var min = parseFloat($qtyInput.attr('min')) || 1;
            var max = parseFloat($qtyInput.attr('max')) || 999;
            
            $('<button type="button" class="qty-btn qty-minus">-</button>').insertBefore($qtyInput);
            $('<button type="button" class="qty-btn qty-plus">+</button>').insertAfter($qtyInput);

            $(document).on('click', '.qty-plus', function() {
                var currentVal = parseFloat($qtyInput.val()) || 0;
                if (currentVal < max) {
                    $qtyInput.val(currentVal + 1).trigger('change');
                }
            });

            $(document).on('click', '.qty-minus', function() {
                var currentVal = parseFloat($qtyInput.val()) || 0;
                if (currentVal > min) {
                    $qtyInput.val(currentVal - 1).trigger('change');
                }
            });
        }

        // 2. AJAX Add to Cart per prodotti singoli
        $(document).on('submit', 'form.cart', function(e) {
            var $form = $(this);
            var $btn = $form.find('.single_add_to_cart_button');

            // Se il prodotto è variabile o raggruppato (ha altri campi nascosti particolari), lasciamo fare al form nativo
            if ( $btn.is('.disabled') || $form.find('input[name="variation_id"]').length > 0 ) {
                return; // Fallback to standard behavior for complex products
            }

            e.preventDefault();

            var productId = $form.find('input[name="add-to-cart"]').val() || 
                            $form.find('[name="add-to-cart"]').val() || 
                            $btn.val() || 
                            $form.find('input[name="product_id"]').val();

            var data = {
                action: 'synergy_add_to_cart',
                product_id: productId,
                quantity: $form.find('[name="quantity"]').val() || 1
            };

            // Se ci sono altri dati (es. attributi semplici) raccoglili
            $form.find('select, input').each(function() {
                if (this.name && this.name !== 'add-to-cart' && this.name !== 'quantity') {
                    data[this.name] = $(this).val();
                }
            });

            $btn.removeClass('added').addClass('loading');

            $.ajax({
                type: 'POST',
                url: synergyAjax.ajaxurl,
                data: data,
                success: function(response) {
                    if (response && response.success) {
                        $btn.removeClass('loading').addClass('added');

                        var count = (response.data && response.data.cart_count !== undefined) ? parseInt(response.data.cart_count, 10) : 0;
                        var fragments = response.data ? response.data.fragments : null;
                        var cartHash = response.data ? response.data.cart_hash : '';

                        // Aggiorna il contatore ed il badge nell'header
                        var $badge = $('.header-cart-badge');
                        if ($badge.length) {
                            $badge.text(count);
                            if (count > 0) {
                                $badge.css('display', 'inline-flex').show().addClass('pop');
                                setTimeout(function() {
                                    $badge.removeClass('pop');
                                }, 400);
                            } else {
                                $badge.hide();
                            }
                        }

                        // Aggiorna sessionStorage di WooCommerce per preservare i frammenti tra le pagine
                        if (typeof wc_cart_fragments_params !== 'undefined' && fragments) {
                            try {
                                sessionStorage.setItem(wc_cart_fragments_params.fragment_name, JSON.stringify(fragments));
                                if (cartHash) {
                                    sessionStorage.setItem(wc_cart_fragments_params.cart_hash_key, cartHash);
                                }
                            } catch(e) {}
                        }

                        // Trigger standard WooCommerce events to update fragments
                        $(document.body).trigger('wc_fragment_refresh');
                        $(document.body).trigger('added_to_cart', [fragments, cartHash, $btn]);

                        // Mostra il toast custom
                        var productName = $('.sp-title').text() || 'Prodotto';
                        showToastNotification(productName);
                        
                        setTimeout(function() {
                            $btn.removeClass('added');
                        }, 2000);
                    } else {
                        $form.off('submit').submit();
                    }
                },
                error: function() {
                    // Fallback in caso di errore
                    $form.off('submit').submit();
                }
            });
        });

        // 3. Animazione Carrello Header su update
        $(document.body).on('added_to_cart removed_from_cart wc_fragments_refreshed wc_fragments_loaded', function() {
            var $badge = $('.header-cart-badge');
            if ($badge.length) {
                var count = parseInt($badge.text(), 10) || 0;
                if (count > 0) {
                    $badge.css('display', 'inline-flex').show().addClass('pop');
                    setTimeout(function() {
                        $badge.removeClass('pop');
                    }, 400);
                } else {
                    $badge.hide();
                }
            }
        });

        // 4. Toast Notification Function
        function showToastNotification(productName) {
            // Rimuove eventuali toast precedenti
            $('.synergy-toast').remove();

            var toastHTML = `
                <div class="synergy-toast">
                    <div class="synergy-toast-inner">
                        <div class="synergy-toast-icon">
                            <svg viewBox="0 0 24 24" width="20" height="20" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg>
                        </div>
                        <div class="synergy-toast-content">
                            <h4>Prodotto aggiunto!</h4>
                            <p>Hai aggiunto "${productName}" al tuo carrello.</p>
                            <div class="synergy-toast-actions">
                                <a href="${wc_add_to_cart_params ? wc_add_to_cart_params.cart_url : '/carrello'}" class="btn-toast-link">Vai al carrello</a>
                                <button type="button" class="btn-toast-close-action">Continua gli acquisti</button>
                            </div>
                        </div>
                        <button type="button" class="synergy-toast-close" aria-label="Chiudi">&times;</button>
                    </div>
                </div>
            `;

            $('body').append(toastHTML);
            var $toast = $('.synergy-toast');
            
            // Forza il reflow per l'animazione
            $toast[0].offsetHeight;
            $toast.addClass('show');

            var closeToast = function() {
                $toast.removeClass('show');
                setTimeout(function() {
                    $toast.remove();
                }, 300);
            };

            $toast.find('.synergy-toast-close, .btn-toast-close-action').on('click', closeToast);

            // Autoclose dopo 5 secondi
            setTimeout(closeToast, 5000);
        }
    });

})(jQuery);
