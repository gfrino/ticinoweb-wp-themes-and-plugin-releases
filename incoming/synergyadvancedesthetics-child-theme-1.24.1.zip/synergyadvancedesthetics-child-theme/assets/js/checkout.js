/**
 * Synergy Advanced Aesthetics - Checkout JavaScript
 * Inline Coupon Error Validation Handler
 */
(function($) {
    'use strict';

    var originalText = (window.synergyI18n && window.synergyI18n.couponHint) || 'Se possiedi un codice promozionale, inseriscilo qui sotto.';
    var errorText    = (window.synergyI18n && window.synergyI18n.couponError) || 'Il codice promozionale inserito non è valido. Controllalo e riprova.';

    function removeCouponErrorNoticesOnly() {
        // WooCommerce appends this span to .synergy-coupon-row after a rejected
        // coupon. It is a sibling of the input, not a .woocommerce-error notice.
        $('.synergy-coupon-row .coupon-error-notice').remove();
        $('form.checkout_coupon, .synergy-coupon-row').find('.woocommerce-error, ul.woocommerce-error').remove();
        $('.woocommerce-error li').each(function() {
            var txt = $(this).text().toLowerCase();
            if (txt.indexOf('coupon') !== -1 || txt.indexOf('codice') !== -1 || txt.indexOf('promozionale') !== -1 || txt.indexOf('non esiste') !== -1) {
                var $ul = $(this).closest('.woocommerce-error');
                $(this).remove();
                if ($ul.find('li').length === 0) {
                    $ul.remove();
                }
            }
        });
    }

    function setCouponErrorState() {
        var $form = $('form.checkout_coupon');
        var $input = $form.find('input[name="coupon_code"]');
        var $feedback = $form.find('.synergy-coupon-feedback');

        $form.addClass('synergy-coupon-has-error');
        $input.attr('aria-invalid', 'true');
        if ($feedback.length) {
            $feedback.text(errorText);
        }

        removeCouponErrorNoticesOnly();
    }

    function resetCouponErrorState() {
        var $form = $('form.checkout_coupon');
        var $input = $form.find('input[name="coupon_code"]');
        var $feedback = $form.find('.synergy-coupon-feedback');

        if ($form.hasClass('synergy-coupon-has-error')) {
            $form.removeClass('synergy-coupon-has-error');
            $input.attr('aria-invalid', 'false');
            if ($feedback.length) {
                $feedback.text(originalText);
            }
        }
        removeCouponErrorNoticesOnly();
    }

    function initCouponFeedback() {
        $(document.body).off('input.synergyCouponValidation keyup.synergyCouponValidation', 'form.checkout_coupon input[name="coupon_code"]');
        $(document).off('ajaxComplete.synergyCouponValidation');
        $(document.body).off('applied_coupon_in_checkout.synergyCouponValidation applied_coupon_failed.synergyCouponValidation');

        $(document.body).on('input.synergyCouponValidation keyup.synergyCouponValidation', 'form.checkout_coupon input[name="coupon_code"]', function() {
            resetCouponErrorState();
        });

        $(document.body).on('applied_coupon_in_checkout.synergyCouponValidation', function() {
            resetCouponErrorState();
        });

        $(document.body).on('applied_coupon_failed.synergyCouponValidation', function() {
            setCouponErrorState();
        });

        $(document).on('ajaxComplete.synergyCouponValidation', function(event, xhr, settings) {
            if (settings && settings.url && (settings.url.indexOf('apply_coupon') !== -1 || (settings.data && settings.data.indexOf('apply_coupon') !== -1))) {
                try {
                    var responseText = xhr.responseText || '';
                    if (responseText.indexOf('woocommerce-error') !== -1 || responseText.indexOf('non esiste') !== -1 || responseText.indexOf('non è valido') !== -1 || responseText.indexOf('error') !== -1) {
                        setCouponErrorState();
                    } else if (responseText.indexOf('woocommerce-message') !== -1 || responseText.indexOf('applicato') !== -1) {
                        resetCouponErrorState();
                    }
                } catch(e) {}
            }
            removeCouponErrorNoticesOnly();
        });
    }

    var horizontalLockFrame = null;

    function lockCheckoutHorizontalViewport() {
        document.documentElement.classList.add('synergy-checkout-viewport');

        // Preserve the vertical reading position while clearing any horizontal
        // offset created by iOS overscroll or a WooCommerce DOM refresh.
        if (window.scrollX !== 0) {
            window.scrollTo(0, window.scrollY);
        }
    }

    function scheduleHorizontalViewportLock() {
        if (horizontalLockFrame !== null) {
            return;
        }

        horizontalLockFrame = window.requestAnimationFrame(function() {
            horizontalLockFrame = null;
            lockCheckoutHorizontalViewport();
        });
    }

    $(document).ready(function() {
        lockCheckoutHorizontalViewport();
        initCouponFeedback();
        removeCouponErrorNoticesOnly();
    });

    $(document.body).on('updated_checkout.synergyCouponValidation', function() {
        scheduleHorizontalViewportLock();
        initCouponFeedback();
        removeCouponErrorNoticesOnly();
    });

    window.addEventListener('pageshow', scheduleHorizontalViewportLock);
    window.addEventListener('resize', scheduleHorizontalViewportLock, { passive: true });
    window.addEventListener('orientationchange', scheduleHorizontalViewportLock);
    window.addEventListener('scroll', function() {
        if (window.scrollX !== 0) {
            scheduleHorizontalViewportLock();
        }
    }, { passive: true });

})(jQuery);
