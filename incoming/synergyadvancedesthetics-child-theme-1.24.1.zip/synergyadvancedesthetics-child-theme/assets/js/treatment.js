/**
 * JS logica per il Template Trattamento
 */

document.addEventListener('DOMContentLoaded', function() {

    // --- 1. Reveal On Scroll ---
    const revealElements = document.querySelectorAll('.reveal-on-scroll');
    
    if (revealElements.length > 0) {
        const revealOptions = {
            threshold: 0.1,
            rootMargin: "0px 0px -50px 0px"
        };

        const revealObserver = new IntersectionObserver(function(entries, observer) {
            entries.forEach(entry => {
                if (!entry.isIntersecting) {
                    return;
                }
                entry.target.classList.add('is-visible');
                observer.unobserve(entry.target);
            });
        }, revealOptions);

        revealElements.forEach(el => {
            revealObserver.observe(el);
        });
    }

    // --- 2. FAQ Accordion ---
    const accordions = document.querySelectorAll('.accordion-header');
    
    accordions.forEach(acc => {
        acc.addEventListener('click', function() {
            const isExpanded = this.getAttribute('aria-expanded') === 'true';
            const body = this.nextElementSibling;
            
            // Chiudi tutti gli altri
            accordions.forEach(otherAcc => {
                if (otherAcc !== this) {
                    otherAcc.setAttribute('aria-expanded', 'false');
                    otherAcc.nextElementSibling.style.maxHeight = null;
                }
            });

            // Toggle questo
            if (isExpanded) {
                this.setAttribute('aria-expanded', 'false');
                body.style.maxHeight = null;
            } else {
                this.setAttribute('aria-expanded', 'true');
                body.style.maxHeight = body.scrollHeight + 'px';
            }
        });
    });

    // --- 3. Light Parallax su Hero (Desktop solo) ---
    const parallaxEl = document.querySelector('.parallax-image');
    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    if (parallaxEl && !prefersReducedMotion && window.innerWidth > 991) {
        window.addEventListener('scroll', function() {
            let scrollY = window.scrollY;
            if (scrollY < window.innerHeight) {
                // Sposta leggermente in basso l'immagine mentre scendi
                parallaxEl.style.transform = `translateY(${scrollY * 0.15}px)`;
            }
        }, { passive: true });
    }

});
