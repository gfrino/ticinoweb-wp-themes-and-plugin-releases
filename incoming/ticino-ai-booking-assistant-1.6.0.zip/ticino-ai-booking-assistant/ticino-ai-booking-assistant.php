<?php
/**
 * Plugin Name:       ticinoWEB AI WEB Agent
 * Plugin URI:        https://ticinoweb.com
 * Description:       Agente AI conversazionale per qualsiasi sito WordPress: Gemini o OpenAI, conoscenza dinamica del sito, documenti PDF nella Knowledge Base, bottoni rapidi configurabili, due modalita' (richieste di appuntamento con sync Apple Calendar oppure generazione contatti/lead).
 * Version:           1.6.0
 * Author:            ticinoWEB
 * Author URI:        https://ticinoweb.com
 * License:           Proprietary
 * Text Domain:       ticino-ai-booking
 * Requires PHP:      7.4
 * Update URI:        https://github.com/gfrino/ticinoweb-wp-themes-and-plugin-releases
 */

// Se chiamato direttamente, abortisci.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Definizioni versioni e costanti principali.
 */
define( 'TICINO_AI_BOOKING_VERSION', '1.6.0' );
define( 'TICINO_AI_BOOKING_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'TICINO_AI_BOOKING_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'TICINO_AI_BOOKING_PLUGIN_BASENAME', plugin_basename( __FILE__ ) );
// Versione di includes/tw-release-updater.php incluso (tenerla allineata al suo header).
define( 'TICINO_AI_BOOKING_RELEASE_UPDATER_VERSION', '1.2.0' );

/**
 * Aggiornamenti dal repo delle release ticinoWEB (header Update URI, 1.4.0).
 * Il loader e' generico e viene installato anche come mu-plugin, cosi' gli
 * aggiornamenti funzionano in bacheca di rete e nel cron del sito principale,
 * dove un plugin attivo solo su alcuni siti non viene caricato. Se il
 * mu-plugin e' gia' caricato questo include non fa nulla.
 */
require_once TICINO_AI_BOOKING_PLUGIN_DIR . 'includes/tw-release-updater.php';

function ticino_ai_booking_install_release_updater() {
	if ( ! class_exists( 'TW_Release_Updater' ) || TW_Release_Updater::mu_is_current( TICINO_AI_BOOKING_RELEASE_UPDATER_VERSION ) ) {
		return;
	}
	if ( get_site_transient( 'ticino_ai_release_updater_failed' ) ) {
		return;
	}
	$result = TW_Release_Updater::install_mu( TICINO_AI_BOOKING_PLUGIN_DIR . 'includes/tw-release-updater.php' );
	if ( is_wp_error( $result ) ) {
		set_site_transient( 'ticino_ai_release_updater_failed', $result->get_error_message(), 12 * HOUR_IN_SECONDS );
	}
}
register_activation_hook( __FILE__, 'ticino_ai_booking_install_release_updater' );
add_action( 'admin_init', function () {
	if ( current_user_can( is_multisite() ? 'manage_network_plugins' : 'activate_plugins' ) ) {
		ticino_ai_booking_install_release_updater();
	}
}, 20 );

/**
 * Il codice di attivazione.
 */
require_once TICINO_AI_BOOKING_PLUGIN_DIR . 'includes/class-activator.php';
register_activation_hook( __FILE__, array( 'Ticino_AI_Booking_Activator', 'activate' ) );

/**
 * Il codice di disattivazione.
 */
require_once TICINO_AI_BOOKING_PLUGIN_DIR . 'includes/class-deactivator.php';
register_deactivation_hook( __FILE__, array( 'Ticino_AI_Booking_Deactivator', 'deactivate' ) );

/**
 * Include the core plugin class.
 */
require_once TICINO_AI_BOOKING_PLUGIN_DIR . 'includes/class-plugin.php';

/**
 * Avvia l'esecuzione del plugin.
 */
function run_ticino_ai_booking() {
	$plugin = new Ticino_AI_Booking_Plugin();
	$plugin->run();
}
run_ticino_ai_booking();
