/* Albatros 1.7.0 — native scroll and continuous, preference-aware light loops. */
(() => {
  'use strict';
  const root = document.documentElement;
  const heroStage = document.querySelector('.alb-hero-stage');
  const hero = document.querySelector('.alb-hero-media') || heroStage;
  if (!hero || !('IntersectionObserver' in window)) return;
  const heroScene = heroStage || hero;

  const reduced = window.matchMedia('(prefers-reduced-motion: reduce)');
  const desktop = window.matchMedia('(min-width: 1024px) and (min-height: 650px)');
  const finePointer = window.matchMedia('(hover: hover) and (pointer: fine)');
  const cards = [...document.querySelectorAll('.alb-service')];
  const waypoints = [...document.querySelectorAll('.alb-service-waypoint')];
  const deck = document.querySelector('.alb-service-index');
  const deckLinks = [...document.querySelectorAll('.alb-deck-links a')];
  const deckCurrent = document.querySelector('.alb-deck-current');
  const cardTitles = cards.map((card) => card.querySelector('h3')?.textContent || '');
  const about = document.querySelector('.alb-about-photo');
  const header = document.querySelector('.alb-header');
  const progress = document.querySelector('.alb-scroll-progress');
  const atmosphere = document.querySelector('.alb-atmosphere');
  const main = document.querySelector('main');
  const subscription = document.querySelector('.alb-subscription');
  const serviceSection = document.getElementById('servizi');
  const effects = new Set();
  const activePhotos = new Set();
  const seen = new WeakSet();
  try { localStorage.removeItem('albatros_motion'); } catch (_) { /* Obsolete UI preference is optional. */ }
  let frame = 0;
  let heroVisible = true;
  let aboutVisible = false;
  let atmosphereVisible = true;
  let lightStart = 0;
  let lightHeight = 1;
  let sceneStart = 0;
  let sceneRange = 1;
  let pointerBounds;
  let pointerX = 0;
  let pointerY = 0;
  let photoPointer = null;
  let stickyTop = 124;
  let viewportHeight = window.innerHeight;
  let scrollRange = 1;
  const enabled = () => !reduced.matches;
  const clamp = (value, min = 0, max = 1) => Math.max(min, Math.min(max, value));

  const links = [...document.querySelectorAll('.alb-menu a')].map((link) => {
    const url = new URL(link.href, window.location.href);
    return {link, section: url.hash ? document.getElementById(decodeURIComponent(url.hash.slice(1))) : null};
  }).filter((item) => item.section);

  const animate = (element, keyframes, options = {}) => {
    if (!element || !enabled() || document.hidden || typeof element.animate !== 'function') return;
    const effect = element.animate(keyframes, {duration:700, easing:'cubic-bezier(.16,1,.3,1)', ...options});
    effects.add(effect);
    effect.finished.then(() => effects.delete(effect), () => effects.delete(effect));
  };
  const schedule = () => {
    if (!frame && !document.hidden) frame = requestAnimationFrame(render);
  };
  const measure = () => {
    viewportHeight = window.innerHeight;
    const headerEdge = Math.ceil(header?.getBoundingClientRect().bottom || 104);
    stickyTop = headerEdge + (desktop.matches && !reduced.matches && deck ? deck.offsetHeight + 48 : 20);
    const scrollPadding = parseFloat(getComputedStyle(root).scrollPaddingTop) || 0;
    scrollRange = Math.max(1, document.documentElement.scrollHeight - viewportHeight);
    sceneStart = window.scrollY + heroScene.getBoundingClientRect().top - headerEdge;
    sceneRange = Math.max(1, heroScene.offsetHeight * .8);
    if (atmosphere && main) {
      const mainTop = main.getBoundingClientRect().top;
      lightStart = window.scrollY + mainTop;
      const boundary = subscription ? subscription.getBoundingClientRect().top : serviceSection ? serviceSection.getBoundingClientRect().bottom : mainTop + viewportHeight;
      lightHeight = Math.max(1, boundary - mainTop);
    }
    root.style.setProperty('--alb-sticky-top', `${stickyTop}px`);
    root.style.setProperty('--alb-deck-top', `${headerEdge + 8}px`);
    root.style.setProperty('--alb-service-anchor-offset', `${Math.max(0, stickyTop - scrollPadding + 8)}px`);
    atmosphere?.style.setProperty('--alb-light-height', `${Math.ceil(lightHeight)}px`);
    pointerBounds = undefined;
    schedule();
  };

  function render() {
    frame = 0;
    if (document.hidden) return;
    const running = enabled();
    const positions = cards.map((card) => card.getBoundingClientRect());
    // Static waypoints keep the hand-off independent of the transformed sticky planes.
    const stops = waypoints.map((point) => point.getBoundingClientRect().top);
    const heights = cards.map((card) => card.offsetHeight);
    const photoRect = photoPointer?.photo ? photoPointer.photo.getBoundingClientRect() : null;
    const photoX = photoRect ? clamp((photoPointer.clientX - photoRect.left) / photoRect.width * 2 - 1, -1, 1) * 6 : 0;
    const photoY = photoRect ? clamp((photoPointer.clientY - photoRect.top) / photoRect.height * 2 - 1, -1, 1) * 4 : 0;
    const aboutRect = aboutVisible && about ? about.getBoundingClientRect() : null;
    const sections = links.map(({section}) => section.getBoundingClientRect().top);
    // Read layout first; all writes follow so scrolling does not alternate layout reads/writes.
    progress?.style.setProperty('--alb-scroll-progress', String(clamp(window.scrollY / scrollRange)));
    let active = -1;
    sections.forEach((top, index) => { if (top <= stickyTop + 100) active = index; });
    links.forEach(({link}, index) => {
      if (index === active) link.setAttribute('aria-current', 'location');
      else link.removeAttribute('aria-current');
    });
    let chapter = 0;
    stops.forEach((top, index) => { if (top <= stickyTop + 100) chapter = index; });
    deckLinks.forEach((link, index) => {
      if (index === chapter) link.setAttribute('aria-current', 'step');
      else link.removeAttribute('aria-current');
    });
    if (deckCurrent && cardTitles[chapter] && deckCurrent.textContent !== cardTitles[chapter]) {
      deckCurrent.textContent = cardTitles[chapter];
    }
    cards.forEach((card, index) => {
      card.classList.toggle('alb-service-current', index === chapter);
      const tooTall = desktop.matches && !reduced.matches && heights[index] > viewportHeight - stickyTop - 12;
      if (card.classList.contains('alb-service-tall') !== tooTall) {
        card.classList.toggle('alb-service-tall', tooTall);
        schedule();
      }
    });
    if (!running) return;
    if (atmosphere && atmosphereVisible && desktop.matches) {
      atmosphere.style.setProperty('--alb-light-scroll', `${(clamp((window.scrollY - lightStart) / Math.max(1, lightHeight - viewportHeight)) * -38).toFixed(2)}px`);
      atmosphere.style.setProperty('--alb-light-x', `${(heroVisible ? pointerX * 10 : 0).toFixed(2)}px`);
    }
    if (heroVisible) {
      if (heroStage) {
        heroStage.style.setProperty('--alb-scene-progress', clamp((window.scrollY - sceneStart) / sceneRange).toFixed(3));
        heroStage.style.setProperty('--alb-scene-x', `${(pointerX * 8).toFixed(2)}px`);
      } else {
        hero.style.setProperty('--alb-hero-pan', `${clamp(window.scrollY * .065, 0, 42).toFixed(2)}px`);
        hero.style.setProperty('--alb-tilt-x', `${pointerX * 2.1}deg`);
        hero.style.setProperty('--alb-tilt-y', `${pointerY * -1.8}deg`);
      }
    }
    cards.forEach((card, index) => {
      const tooTall = card.classList.contains('alb-service-tall');
      const span = Math.max(1, viewportHeight - stickyTop);
      const next = stops[index + 1];
      const handoff = desktop.matches && next !== undefined && !tooTall ? clamp((viewportHeight - next) / span) : 0;
      const arrival = desktop.matches ? clamp((viewportHeight - (stops[index] ?? positions[index].top)) / span) : 1;
      const depth = handoff * handoff * (3 - 2 * handoff);
      card.style.setProperty('--alb-card-depth', depth.toFixed(3));
      card.style.setProperty('--alb-card-arrival', arrival.toFixed(3));
      card.style.setProperty('--alb-card-glint', Math.sin(arrival * Math.PI).toFixed(3));
      if (desktop.matches && activePhotos.has(card)) {
        const pan = clamp((positions[index].top + positions[index].height / 2 - viewportHeight / 2) / viewportHeight, -1, 1) * -20;
        card.style.setProperty('--alb-photo-pan', `${pan.toFixed(2)}px`);
      }
      if (photoPointer?.card === card) {
        card.style.setProperty('--alb-photo-x', `${photoX.toFixed(2)}px`);
        card.style.setProperty('--alb-photo-y', `${photoY.toFixed(2)}px`);
      }
    });
    if (aboutRect && desktop.matches) {
      const pan = clamp((aboutRect.top + aboutRect.height / 2 - viewportHeight / 2) / viewportHeight, -1, 1) * -22;
      about.style.setProperty('--alb-about-pan', `${pan.toFixed(2)}px`);
    }
  }

  const applyState = () => {
    const running = enabled();
    root.classList.toggle('alb-motion-paused', !running);
    root.dataset.albMotion = running ? 'running' : 'paused';
    if (!running) {
      effects.forEach((effect) => effect.cancel());
      hero.removeAttribute('style');
      heroStage?.style.removeProperty('--alb-scene-progress');
      heroStage?.style.removeProperty('--alb-scene-x');
      about?.removeAttribute('style');
      cards.forEach((card) => {
        card.style.setProperty('--alb-card-depth', '0');
        card.style.removeProperty('--alb-photo-pan');
        card.style.removeProperty('--alb-photo-x');
        card.style.removeProperty('--alb-photo-y');
        card.style.setProperty('--alb-card-arrival', '1');
        card.style.setProperty('--alb-card-glint', '0');
      });
      photoPointer = null;
      atmosphere?.style.removeProperty('--alb-light-scroll');
      atmosphere?.style.removeProperty('--alb-light-x');
    }
    measure();
  };

  cards.forEach((card, index) => card.style.setProperty('--alb-card-index', String(index + 1)));
  root.classList.add('alb-motion-ready');
  root.classList.toggle('alb-page-hidden', document.hidden);
  applyState();
  reduced.addEventListener('change', applyState);
  desktop.addEventListener('change', measure);

  const zoneObserver = new IntersectionObserver((entries) => {
    entries.forEach(({target, isIntersecting}) => {
      target.classList.toggle('alb-loop-visible', isIntersecting);
      if (target === heroScene) heroVisible = isIntersecting;
      if (target === about) aboutVisible = isIntersecting;
      if (target === atmosphere) atmosphereVisible = isIntersecting;
      if (target.classList.contains('alb-service')) {
        if (isIntersecting) activePhotos.add(target); else activePhotos.delete(target);
      }
    });
    schedule();
  });
  [...new Set([hero, heroScene, about, atmosphere, subscription, ...cards])].filter(Boolean).forEach((element) => zoneObserver.observe(element));

  const entrances = new IntersectionObserver((entries) => {
    entries.forEach(({target, isIntersecting}) => {
      if (!isIntersecting || seen.has(target)) return;
      seen.add(target);
      entrances.unobserve(target);
      if (target.classList.contains('alb-service')) {
        if (!desktop.matches) animate(target.querySelector('.alb-service-photo'), [{clipPath:'inset(0 8% 0 0)', transform:'translateX(-12px)'}, {clipPath:'inset(0)', transform:'translateX(0)'}], {duration:650});
      } else if (target.classList.contains('alb-about-photo')) {
        animate(target, [{clipPath:'inset(8% 0 0 0)'}, {clipPath:'inset(0)'}], {duration:850});
      }
    });
  }, {threshold:.12});
  document.querySelectorAll('.alb-service, .alb-about-photo').forEach((element) => entrances.observe(element));

  const titleLines = [...document.querySelectorAll('.alb-hero-line')];
  (titleLines.length ? titleLines : [document.querySelector('.alb-hero h1')]).forEach((line, index) => {
    animate(line, [{clipPath:'inset(0 0 100% 0)', transform:'translateY(28px)'}, {clipPath:'inset(0)', transform:'translateY(0)'}], {duration:950, delay:index * 140, fill:'backwards'});
  });
  animate(document.querySelector('.alb-hero .alb-lead'), [{opacity:.3, transform:'translateY(15px)'}, {opacity:1, transform:'translateY(0)'}], {duration:650, delay:160, fill:'backwards'});

  heroScene.addEventListener('pointerenter', () => { pointerBounds = heroScene.getBoundingClientRect(); });
  heroScene.addEventListener('pointermove', (event) => {
    if (!enabled() || !desktop.matches || !finePointer.matches) return;
    if (!pointerBounds) pointerBounds = heroScene.getBoundingClientRect();
    pointerX = clamp((event.clientX - pointerBounds.left) / pointerBounds.width * 2 - 1, -1, 1);
    pointerY = clamp((event.clientY - pointerBounds.top) / pointerBounds.height * 2 - 1, -1, 1);
    schedule();
  }, {passive:true});
  heroScene.addEventListener('pointerleave', () => { pointerX = pointerY = 0; schedule(); });
  cards.forEach((card) => {
    const photo = card.querySelector('.alb-service-photo');
    photo?.addEventListener('pointermove', (event) => {
      if (!enabled() || !desktop.matches || !finePointer.matches) return;
      photoPointer = {card, photo, clientX:event.clientX, clientY:event.clientY};
      schedule();
    }, {passive:true});
    photo?.addEventListener('pointerleave', () => { photoPointer = {card}; schedule(); });
  });
  window.addEventListener('scroll', schedule, {passive:true});
  window.addEventListener('resize', measure, {passive:true});
  document.addEventListener('toggle', measure, true);
  document.addEventListener('visibilitychange', () => {
    root.classList.toggle('alb-page-hidden', document.hidden);
    if (document.hidden) {
      cancelAnimationFrame(frame);
      frame = 0;
      effects.forEach((effect) => effect.cancel());
    } else measure();
  });
  window.addEventListener('load', measure, {once:true});
  document.fonts?.ready.then(measure);
  // Native details, images and CMS edits can change the page height without a viewport resize.
  if ('ResizeObserver' in window) {
    const sizeObserver = new ResizeObserver(measure);
    if (main) sizeObserver.observe(main);
  }
})();
