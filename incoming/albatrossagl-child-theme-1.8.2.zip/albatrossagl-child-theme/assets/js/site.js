/* Albatros: progressive navigation and direct contact links. */
(() => {
  'use strict';
  document.documentElement.classList.add('alb-js');
  const toggle = document.querySelector('.alb-menu-toggle');
  const navigation = document.querySelector('.alb-nav');
  const closeMenu = (restoreFocus = false) => {
    if (!toggle || !navigation) return;
    toggle.setAttribute('aria-expanded', 'false');
    navigation.classList.remove('is-open');
    if (restoreFocus) toggle.focus();
  };
  toggle?.addEventListener('click', () => {
    const open = toggle.getAttribute('aria-expanded') !== 'true';
    toggle.setAttribute('aria-expanded', String(open));
    navigation?.classList.toggle('is-open', open);
  });
  navigation?.addEventListener('click', (event) => {
    if (event.target.closest('a')) closeMenu();
  });
  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape' && toggle?.getAttribute('aria-expanded') === 'true') closeMenu(true);
  });
  document.querySelector('.alb-cookie-settings')?.addEventListener('click', () => {
    // The parent removes its consent UI after a choice. Reload it after clearing only its cookies.
    ['tw_cookie_consent', 'tw_cookie_preferences'].forEach((key) => {
      document.cookie = `${key}=; max-age=0; path=/; SameSite=Lax`;
    });
    window.location.reload();
  });
  // Native page buttons keep #servizi as their no-JS fallback. The editor's route
  // class references a CMS service key, never a hardcoded title or generated ID.
  document.querySelectorAll('.alb-audience .wp-block-button').forEach((button) => {
    const route = [...button.classList].find((name) => name.startsWith('alb-route-'))?.slice(10);
    const card = route && [...document.querySelectorAll('.alb-service[data-service-key]')].find((item) => item.dataset.serviceKey === route);
    const point = card?.previousElementSibling;
    const link = button.querySelector('a');
    if (link && point?.classList.contains('alb-service-waypoint') && point.id) link.setAttribute('href', `#${encodeURIComponent(point.id)}`);
  });
  const contacts = document.querySelector('.alb-contact-direct');
  // Direct contacts replace the fixed shortcuts while they are actually in view.
  if (contacts && 'IntersectionObserver' in window) {
    new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        document.documentElement.classList.toggle('alb-contact-visible', entry.isIntersecting);
      });
    }, {rootMargin:'-100px 0px -80px 0px'}).observe(contacts);
  }
})();
