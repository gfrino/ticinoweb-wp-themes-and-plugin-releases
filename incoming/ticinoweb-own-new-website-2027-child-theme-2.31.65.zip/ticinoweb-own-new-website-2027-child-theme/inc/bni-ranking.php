<?php
/**
 * Classifica referenze BNI (pagina con template «ticinoWEB — Classifica BNI»).
 *
 * I dati stanno nell'opzione del sito `tw_bni_ranking`, un JSON:
 *   {"updated":"2026-10-23","members":[{"name":"Paolo Della Giovanna","referrals":2}, ...]}
 * Si aggiorna senza rilasciare il tema, per esempio con WP-CLI:
 *   wp --url=https://ticinoweb.com option update tw_bni_ranking '<json>' --format=json
 * La pagina va in noindex dal metabox SEO del parent (`_tw_seo_robots`).
 *
 * @package ticinoWEB_Child_Theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Legge e ordina la classifica. Pari merito = stessa posizione (1, 1, 3...).
 *
 * @return array{updated:string,members:array<int,array{name:string,referrals:int,rank:int}>}
 */
function tw_bni_ranking_data() {
	$raw = get_option( 'tw_bni_ranking', array() );
	if ( is_string( $raw ) ) {
		$raw = json_decode( $raw, true );
	}
	$raw     = is_array( $raw ) ? $raw : array();
	$members = array();
	foreach ( (array) ( $raw['members'] ?? array() ) as $member ) {
		$name = isset( $member['name'] ) ? sanitize_text_field( (string) $member['name'] ) : '';
		if ( '' === $name ) {
			continue;
		}
		$members[] = array(
			'name'      => $name,
			'referrals' => max( 0, (int) ( $member['referrals'] ?? 0 ) ),
		);
	}
	usort(
		$members,
		static function ( $a, $b ) {
			return ( $b['referrals'] <=> $a['referrals'] ) ?: strcasecmp( $a['name'], $b['name'] );
		}
	);
	foreach ( $members as $i => $member ) {
		$members[ $i ]['rank'] = ( $i > 0 && $members[ $i - 1 ]['referrals'] === $member['referrals'] ) ? $members[ $i - 1 ]['rank'] : $i + 1;
	}
	$updated = isset( $raw['updated'] ) && preg_match( '/^\d{4}-\d{2}-\d{2}$/', (string) $raw['updated'] ) ? (string) $raw['updated'] : '';
	return array(
		'updated' => $updated,
		'members' => $members,
	);
}

/**
 * Carica il CSS solo sulla pagina della classifica.
 */
function tw_bni_ranking_enqueue() {
	if ( ! is_page_template( 'page-classifica-bni.php' ) ) {
		return;
	}
	wp_enqueue_style(
		'ticinoweb-child-bni-ranking',
		get_stylesheet_directory_uri() . '/assets/css/bni-ranking.css',
		array( 'ticinoweb-child-site' ),
		wp_get_theme()->get( 'Version' )
	);
}
add_action( 'wp_enqueue_scripts', 'tw_bni_ranking_enqueue', 30 );
