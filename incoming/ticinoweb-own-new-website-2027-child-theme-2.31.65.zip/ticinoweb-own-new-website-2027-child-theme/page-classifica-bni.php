<?php
/**
 * Template Name: ticinoWEB — Classifica BNI
 *
 * Classifica dei membri del capitolo BNI per referenze passate a ticinoWEB.
 * Titolo e testo introduttivo (estratto) dall'editor; i dati dall'opzione
 * `tw_bni_ranking` (vedi inc/bni-ranking.php). Pensata per il telefono.
 */
if ( ! defined( 'ABSPATH' ) ) exit;
get_header();
$tw_bni = function_exists( 'tw_bni_ranking_data' ) ? tw_bni_ranking_data() : array( 'updated' => '', 'members' => array() );
while ( have_posts() ) :
	the_post();
	?>
<main id="main-content" class="tw-bni">
	<div class="tw-bni__wrap">
		<header class="tw-bni__head">
			<img class="tw-bni__logo" src="<?php echo esc_url( get_stylesheet_directory_uri() . '/assets/images/bni-logo.png' ); ?>" width="480" height="185" alt="BNI" decoding="async">
			<h1><?php the_title(); ?></h1>
			<?php if ( has_excerpt() ) : ?><p class="tw-bni__lead"><?php echo esc_html( get_the_excerpt() ); ?></p><?php endif; ?>
			<?php if ( $tw_bni['updated'] ) : ?>
				<p class="tw-bni__updated"><?php echo esc_html( sprintf( __( 'Aggiornata il %s', 'ticinoweb-child-theme' ), date_i18n( 'j F Y', strtotime( $tw_bni['updated'] ) ) ) ); ?></p>
			<?php endif; ?>
		</header>

		<?php if ( $tw_bni['members'] ) : ?>
			<ol class="tw-bni__list">
				<?php foreach ( $tw_bni['members'] as $tw_member ) : ?>
					<li class="tw-bni__row<?php echo ( $tw_member['referrals'] > 0 && $tw_member['rank'] <= 3 ) ? ' is-top' : ''; ?>">
						<span class="tw-bni__rank"><?php echo esc_html( $tw_member['rank'] ); ?></span>
						<span class="tw-bni__name"><?php echo esc_html( $tw_member['name'] ); ?></span>
						<span class="tw-bni__count">
							<strong><?php echo esc_html( $tw_member['referrals'] ); ?></strong>
							<small><?php echo esc_html( 1 === $tw_member['referrals'] ? __( 'referenza', 'ticinoweb-child-theme' ) : __( 'referenze', 'ticinoweb-child-theme' ) ); ?></small>
						</span>
					</li>
				<?php endforeach; ?>
			</ol>
		<?php else : ?>
			<p class="tw-bni__empty"><?php esc_html_e( 'La classifica sarà pubblicata a breve.', 'ticinoweb-child-theme' ); ?></p>
		<?php endif; ?>
	</div>
</main>
	<?php
endwhile;
get_footer();
