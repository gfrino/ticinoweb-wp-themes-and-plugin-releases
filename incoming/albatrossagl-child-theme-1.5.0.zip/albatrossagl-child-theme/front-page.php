<?php
/** Homepage built in the native editor; the child owns presentation only. */
defined('ABSPATH') || exit;
get_header();
?>
<div class="alb-atmosphere" aria-hidden="true">
    <div class="alb-atmosphere-screen">
        <span class="alb-atmosphere-wash"></span>
        <span class="alb-atmosphere-optics">
            <span class="alb-light-pane alb-light-pane-a"></span>
            <span class="alb-light-pane alb-light-pane-b"></span>
            <span class="alb-light-seam"></span>
        </span>
    </div>
</div>
<?php
while (have_posts()) {
    the_post();
    the_content();
}
get_footer();
