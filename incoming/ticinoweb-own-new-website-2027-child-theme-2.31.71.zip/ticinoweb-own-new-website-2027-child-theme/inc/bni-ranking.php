<?php
/**
 * Classifica referenze BNI Verzasca (pagina con template «ticinoWEB — Classifica BNI»).
 *
 * I dati si leggono da Odoo (ticinoweb.online, menu «BNI Verzasca») con la connessione
 * dei form (inc/odoo-integration.php): membri attivi `x_bni_member` e referenze `x_bni_referral`
 * del gioco (`x_game`): le referenze ricevute da ticinoWEB prima dell'inizio del gioco non contano.
 * Quando in Odoo si aggiunge una referenza, la pagina si aggiorna da sola entro 15 minuti.
 * Se Odoo non risponde si mostra l'ultima classifica letta.
 *
 * Colonne: settimana (da mercoledì a martedì), mese e anno in corso, nel fuso del sito.
 * La pagina va in noindex dal metabox SEO del parent (`_tw_seo_robots`).
 *
 * @package ticinoWEB_Child_Theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

const TW_BNI_CACHE = 'tw_bni_ranking_cache';
const TW_BNI_LAST  = 'tw_bni_ranking_last';

/**
 * Membri attivi e date delle referenze da Odoo, con cache di 15 minuti.
 *
 * @return array{members:array<int,array{id:int,name:string}>,referrals:array<int,array{member:int,date:string}>,fetched:string}|null
 */
function tw_bni_ranking_fetch() {
	$cached = get_transient( TW_BNI_CACHE );
	if ( is_array( $cached ) ) {
		return $cached;
	}
	$data = null;
	if ( function_exists( 'tw_odoo_call' ) ) {
		$since   = min( current_datetime()->format( 'Y' ) . '-01-01', current_datetime()->modify( '-7 days' )->format( 'Y-m-d' ) );
		$members = tw_odoo_call( 'x_bni_member', 'search_read', array( array( array( 'x_active', '=', true ) ) ), array( 'fields' => array( 'x_name' ) ) );
		$refs    = tw_odoo_call( 'x_bni_referral', 'search_read', array( array( array( 'x_game', '=', true ), array( 'x_date', '>=', $since ) ) ), array( 'fields' => array( 'x_date', 'x_member_id' ) ) );
		if ( is_array( $members ) && is_array( $refs ) && ! is_wp_error( $members ) && ! is_wp_error( $refs ) ) {
			$data = array( 'members' => array(), 'referrals' => array(), 'fetched' => current_datetime()->format( 'Y-m-d H:i' ) );
			foreach ( $members as $m ) {
				if ( ! empty( $m['id'] ) && ! empty( $m['x_name'] ) ) {
					$data['members'][] = array( 'id' => (int) $m['id'], 'name' => sanitize_text_field( (string) $m['x_name'] ) );
				}
			}
			foreach ( $refs as $r ) {
				if ( ! empty( $r['x_date'] ) && ! empty( $r['x_member_id'][0] ) ) {
					$data['referrals'][] = array( 'member' => (int) $r['x_member_id'][0], 'date' => substr( (string) $r['x_date'], 0, 10 ) );
				}
			}
			update_option( TW_BNI_LAST, $data, false );
		}
	}
	if ( null === $data ) {
		$last = get_option( TW_BNI_LAST );
		$data = is_array( $last ) ? $last : null;
	}
	if ( null !== $data ) {
		set_transient( TW_BNI_CACHE, $data, 15 * MINUTE_IN_SECONDS );
	}
	return $data;
}

/**
 * Settimana (mercoledì–martedì) che contiene il giorno dato.
 *
 * @param DateTimeImmutable $day Giorno di riferimento.
 * @return array{0:string,1:string} Primo e ultimo giorno, Y-m-d.
 */
function tw_bni_week( DateTimeImmutable $day ) {
	$back  = ( (int) $day->format( 'N' ) - 3 + 7 ) % 7; // N: 1 = lunedì … 7 = domenica; 3 = mercoledì.
	$start = $day->modify( "-{$back} days" );
	return array( $start->format( 'Y-m-d' ), $start->modify( '+6 days' )->format( 'Y-m-d' ) );
}

/**
 * Classifica: referenze di settimana, mese e anno per ogni membro attivo.
 * Ordine e posizione seguono l'anno (pari merito = stessa posizione), poi mese e settimana.
 *
 * @param DateTimeImmutable|null $today Oggi (per i test).
 * @param array|null             $data  Dati già letti (per i test).
 * @return array{ok:bool,today:string,week_from:string,week_to:string,year:string,total:int,members:array<int,array{name:string,week:int,month:int,year:int,rank:int}>}
 */
function tw_bni_ranking_data( $today = null, $data = null ) {
	$today = $today instanceof DateTimeImmutable ? $today : current_datetime();
	$data  = null === $data ? tw_bni_ranking_fetch() : $data;
	list( $week_from, $week_to ) = tw_bni_week( $today );
	$month = $today->format( 'Y-m' );
	$year  = $today->format( 'Y' );

	$rows = array();
	foreach ( (array) ( $data['members'] ?? array() ) as $m ) {
		$rows[ $m['id'] ] = array( 'name' => $m['name'], 'week' => 0, 'month' => 0, 'year' => 0 );
	}
	$total = 0;
	foreach ( (array) ( $data['referrals'] ?? array() ) as $r ) {
		if ( ! isset( $rows[ $r['member'] ] ) || $r['date'] > $today->format( 'Y-m-d' ) ) {
			continue;
		}
		if ( substr( $r['date'], 0, 4 ) === $year ) {
			++$rows[ $r['member'] ]['year'];
			++$total;
		}
		if ( substr( $r['date'], 0, 7 ) === $month ) {
			++$rows[ $r['member'] ]['month'];
		}
		if ( $r['date'] >= $week_from && $r['date'] <= $week_to ) {
			++$rows[ $r['member'] ]['week'];
		}
	}
	$members = array_values( $rows );
	usort(
		$members,
		static function ( $a, $b ) {
			return ( $b['year'] <=> $a['year'] ) ?: ( $b['month'] <=> $a['month'] ) ?: ( $b['week'] <=> $a['week'] ) ?: strcasecmp( $a['name'], $b['name'] );
		}
	);
	foreach ( $members as $i => $m ) {
		$members[ $i ]['rank'] = ( $i > 0 && $members[ $i - 1 ]['year'] === $m['year'] ) ? $members[ $i - 1 ]['rank'] : $i + 1;
	}
	return array(
		'ok'        => null !== $data,
		'today'     => $today->format( 'Y-m-d' ),
		'week_from' => $week_from,
		'week_to'   => $week_to,
		'year'      => $year,
		'total'     => $total,
		'members'   => $members,
	);
}

/**
 * Una sezione della classifica: solo i membri con almeno una referenza nel periodo,
 * ordinati per quel periodo (pari merito = stessa posizione, poi in ordine alfabetico).
 *
 * @param array  $members Righe di tw_bni_ranking_data()['members'].
 * @param string $key     'week', 'month' o 'year'.
 * @return array<int,array{name:string,count:int,rank:int}>
 */
function tw_bni_ranking_section( array $members, $key ) {
	$rows = array();
	foreach ( $members as $m ) {
		if ( ! empty( $m[ $key ] ) ) {
			$rows[] = array( 'name' => $m['name'], 'count' => (int) $m[ $key ] );
		}
	}
	usort(
		$rows,
		static function ( $a, $b ) {
			return ( $b['count'] <=> $a['count'] ) ?: strcasecmp( $a['name'], $b['name'] );
		}
	);
	foreach ( $rows as $i => $r ) {
		$rows[ $i ]['rank'] = ( $i > 0 && $rows[ $i - 1 ]['count'] === $r['count'] ) ? $rows[ $i - 1 ]['rank'] : $i + 1;
	}
	return $rows;
}

/**
 * Carica il CSS solo sulla pagina della classifica.
 */
function tw_bni_ranking_enqueue() {
	if ( ! is_page_template( 'page-classifica-bni.php' ) ) {
		return;
	}
	wp_enqueue_style(
		'ticinoweb-child-bni-ranking',
		get_stylesheet_directory_uri() . '/assets/css/bni-ranking.css',
		array( 'ticinoweb-child-site' ),
		wp_get_theme()->get( 'Version' )
	);
}
add_action( 'wp_enqueue_scripts', 'tw_bni_ranking_enqueue', 30 );
