<?php
/**
 * Template Name: ticinoWEB — Classifica BNI
 *
 * Classifiche del capitolo BNI Verzasca in tre sezioni: settimana (mercoledì–martedì),
 * mese e anno, ognuna ordinata per le referenze di quel periodo. Titolo e testo
 * introduttivo (estratto) dall'editor; i dati da Odoo (vedi inc/bni-ranking.php).
 * Pensata per il telefono.
 */
if ( ! defined( 'ABSPATH' ) ) exit;
// La cache di pagina di LiteSpeed dura quanto la cache dei dati Odoo (15 minuti), così le nuove referenze compaiono da sole.
do_action( 'litespeed_control_set_ttl', 15 * MINUTE_IN_SECONDS );
get_header();
$tw_bni = function_exists( 'tw_bni_ranking_data' ) ? tw_bni_ranking_data() : array( 'ok' => false, 'members' => array() );
if ( $tw_bni['ok'] ) {
	$tw_bni_sections = array(
		'week'  => array(
			'title' => __( 'Classifica della settimana', 'ticinoweb-child-theme' ),
			'range' => date_i18n( 'D j M', strtotime( $tw_bni['week_from'] ) ) . ' – ' . date_i18n( 'D j M', strtotime( $tw_bni['week_to'] ) ),
		),
		'month' => array(
			'title' => __( 'Classifica del mese', 'ticinoweb-child-theme' ),
			'range' => date_i18n( 'F Y', strtotime( $tw_bni['today'] ) ),
		),
		'year'  => array(
			'title' => __( 'Classifica dell’anno', 'ticinoweb-child-theme' ),
			'range' => $tw_bni['year'],
		),
	);
}
while ( have_posts() ) :
	the_post();
	?>
<main id="main-content" class="tw-bni">
	<div class="tw-bni__wrap">
		<header class="tw-bni__head">
			<img class="tw-bni__logo" src="<?php echo esc_url( get_stylesheet_directory_uri() . '/assets/images/bni-logo.png' ); ?>" width="480" height="185" alt="BNI" decoding="async">
			<h1><?php the_title(); ?></h1>
			<?php if ( has_excerpt() ) : ?><p class="tw-bni__lead"><?php echo esc_html( get_the_excerpt() ); ?></p><?php endif; ?>
		</header>

		<?php if ( $tw_bni['ok'] && $tw_bni['members'] ) : ?>
			<dl class="tw-bni__kpi">
				<div><dt><?php echo esc_html( sprintf( __( 'Referenze scambiate nel %s', 'ticinoweb-child-theme' ), $tw_bni['year'] ) ); ?></dt><dd><?php echo esc_html( $tw_bni['total'] ); ?></dd></div>
				<div><dt><?php esc_html_e( 'Periodo', 'ticinoweb-child-theme' ); ?></dt><dd class="is-period"><?php echo esc_html( date_i18n( 'j M Y', strtotime( $tw_bni['year'] . '-01-01' ) ) . ' – ' . date_i18n( 'j M Y', strtotime( $tw_bni['today'] ) ) ); ?></dd></div>
			</dl>

			<nav class="tw-bni__jump" aria-label="<?php esc_attr_e( 'Classifiche', 'ticinoweb-child-theme' ); ?>">
				<a href="#settimana"><?php esc_html_e( 'Settimana', 'ticinoweb-child-theme' ); ?></a>
				<a href="#mese"><?php esc_html_e( 'Mese', 'ticinoweb-child-theme' ); ?></a>
				<a href="#anno"><?php esc_html_e( 'Anno', 'ticinoweb-child-theme' ); ?></a>
			</nav>

			<?php foreach ( $tw_bni_sections as $tw_key => $tw_section ) :
				$tw_rows  = tw_bni_ranking_section( $tw_bni['members'], $tw_key );
				$tw_zero  = count( $tw_bni['members'] ) - count( $tw_rows );
				$tw_anchor = array( 'week' => 'settimana', 'month' => 'mese', 'year' => 'anno' )[ $tw_key ];
				?>
				<section class="tw-bni__section" id="<?php echo esc_attr( $tw_anchor ); ?>" aria-labelledby="tw-bni-<?php echo esc_attr( $tw_key ); ?>">
					<header class="tw-bni__section-head">
						<h2 id="tw-bni-<?php echo esc_attr( $tw_key ); ?>"><?php echo esc_html( $tw_section['title'] ); ?></h2>
						<p><?php echo esc_html( $tw_section['range'] ); ?></p>
					</header>
					<?php if ( $tw_rows ) : ?>
						<ol class="tw-bni__list">
							<?php foreach ( $tw_rows as $tw_i => $tw_row ) : ?>
								<li class="tw-bni__row<?php echo $tw_row['rank'] <= 3 ? ' is-top' : ''; ?>">
									<span class="tw-bni__rank"><span><?php echo ( $tw_i > 0 && $tw_rows[ $tw_i - 1 ]['rank'] === $tw_row['rank'] ) ? '' : esc_html( $tw_row['rank'] ); ?></span></span>
									<span class="tw-bni__name"><?php echo esc_html( $tw_row['name'] ); ?></span>
									<span class="tw-bni__count"><strong><?php echo esc_html( $tw_row['count'] ); ?></strong> <small><?php echo esc_html( 1 === $tw_row['count'] ? __( 'referenza', 'ticinoweb-child-theme' ) : __( 'referenze', 'ticinoweb-child-theme' ) ); ?></small></span>
								</li>
							<?php endforeach; ?>
						</ol>
						<?php if ( $tw_zero > 0 ) : ?><p class="tw-bni__others"><?php echo esc_html( sprintf( _n( 'Ancora nessuna referenza per %d altro membro.', 'Ancora nessuna referenza per gli altri %d membri.', $tw_zero, 'ticinoweb-child-theme' ), $tw_zero ) ); ?></p><?php endif; ?>
					<?php else : ?>
						<p class="tw-bni__others"><?php esc_html_e( 'Ancora nessuna referenza in questo periodo.', 'ticinoweb-child-theme' ); ?></p>
					<?php endif; ?>
				</section>
			<?php endforeach; ?>
		<?php else : ?>
			<p class="tw-bni__empty"><?php esc_html_e( 'La classifica sarà pubblicata a breve.', 'ticinoweb-child-theme' ); ?></p>
		<?php endif; ?>
	</div>
</main>
	<?php
endwhile;
get_footer();
