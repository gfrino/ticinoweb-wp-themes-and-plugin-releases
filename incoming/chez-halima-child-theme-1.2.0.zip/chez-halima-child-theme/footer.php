<?php
/**
 * Footer di Chez Halima come su chezhalima.ch: quattro colonne su fondo nero (marchio, regole,
 * ultime novità, navigazione) e barra del copyright. Logo, menu e news vengono dal CMS.
 */
defined('ABSPATH') || exit;

$site_name = get_bloginfo('name');
$logo = function_exists('ticinoweb_get_site_logo') ? ticinoweb_get_site_logo() : '';
$recent = chezhalima_recent_posts(3);
?>
<footer class="ch-footer">
    <div class="ch-wrap ch-footer__cols">
        <div class="ch-footer__col">
            <h2 class="ch-footer__title"><?php echo esc_html($site_name); ?></h2>
            <?php if ($logo) : ?>
                <a href="<?php echo esc_url(home_url('/')); ?>"><img class="ch-footer__logo" src="<?php echo esc_url($logo); ?>" alt="<?php echo esc_attr($site_name); ?>" loading="lazy"></a>
            <?php endif; ?>
        </div>
        <?php if (has_nav_menu('chezhalima_topbar')) : ?>
            <nav class="ch-footer__col" aria-label="<?php esc_attr_e('Regole', 'chez-halima-child-theme'); ?>">
                <h2 class="ch-footer__title"><?php esc_html_e('Regole', 'chez-halima-child-theme'); ?></h2>
                <?php wp_nav_menu(array('theme_location' => 'chezhalima_topbar', 'container' => false, 'menu_class' => 'ch-footer__links', 'depth' => 1, 'fallback_cb' => false)); ?>
            </nav>
        <?php endif; ?>
        <?php if ($recent) : ?>
            <div class="ch-footer__col">
                <h2 class="ch-footer__title"><?php esc_html_e('Ultime novità', 'chez-halima-child-theme'); ?></h2>
                <?php echo $recent; // phpcs:ignore WordPress.Security.EscapeOutput -- costruito con escape in chezhalima_recent_posts() ?>
            </div>
        <?php endif; ?>
        <?php if (has_nav_menu('primary')) : ?>
            <nav class="ch-footer__col" aria-label="<?php esc_attr_e('Naviga', 'chez-halima-child-theme'); ?>">
                <h2 class="ch-footer__title"><?php esc_html_e('Naviga', 'chez-halima-child-theme'); ?></h2>
                <?php wp_nav_menu(array('theme_location' => 'primary', 'container' => false, 'menu_class' => 'ch-footer__links', 'depth' => 1, 'fallback_cb' => false)); ?>
            </nav>
        <?php endif; ?>
    </div>
    <div class="ch-footer__bottom">
        <div class="ch-wrap ch-footer__bottom-inner">
            <p>
                <?php
                printf(
                    /* translators: 1: anno, 2: nome del sito */
                    esc_html__('Copyright %1$s © %2$s - Tutti i diritti riservati', 'chez-halima-child-theme'),
                    esc_html(wp_date('Y')),
                    '<strong>' . esc_html($site_name) . '</strong>'
                );
                ?>
            </p>
            <p class="ch-footer__credits">
                <?php if (function_exists('get_privacy_policy_url') && get_privacy_policy_url()) : ?>
                    <a href="<?php echo esc_url(get_privacy_policy_url()); ?>"><?php esc_html_e('Privacy Policy', 'chez-halima-child-theme'); ?></a>
                <?php endif; ?>
                <span>Design by <a href="https://ticinoweb.com" target="_blank" rel="noopener">ticinoWEB</a></span>
            </p>
        </div>
    </div>
</footer>
<?php wp_footer(); ?>
</body>
</html>
