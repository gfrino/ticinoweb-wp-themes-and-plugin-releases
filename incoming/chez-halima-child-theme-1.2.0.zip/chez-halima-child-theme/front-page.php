<?php
/**
 * Home di Chez Halima come su chezhalima.ch: foto a tutto schermo con titolo ed estratto della pagina
 * sotto l'header trasparente, poi il contenuto della pagina (sezioni) e le ultime news.
 */
defined('ABSPATH') || exit;

get_header();
the_post();
?>
<main id="ch-main" class="ch-home">
    <section class="ch-hero">
        <?php if (has_post_thumbnail()) : ?>
            <?php the_post_thumbnail('full', array('class' => 'ch-hero__image', 'fetchpriority' => 'high', 'loading' => 'eager', 'alt' => '')); ?>
        <?php endif; ?>
        <div class="ch-hero__text">
            <h1><?php the_title(); ?></h1>
            <?php if (has_excerpt()) : ?><p><?php echo esc_html(get_the_excerpt()); ?></p><?php endif; ?>
        </div>
    </section>

    <?php the_content(); ?>

    <?php
    $news = new WP_Query(array('posts_per_page' => 3, 'ignore_sticky_posts' => true, 'no_found_rows' => true));
    if ($news->have_posts()) :
        ?>
        <section class="ch-section ch-wrap">
            <h2 class="ch-lined"><span><?php esc_html_e('Latest News', 'chez-halima-child-theme'); ?></span></h2>
            <div class="ch-news-grid">
                <?php while ($news->have_posts()) : $news->the_post(); ?>
                    <?php get_template_part('template-parts/news-card'); ?>
                <?php endwhile; ?>
            </div>
        </section>
        <?php
    endif;
    wp_reset_postdata();
    ?>
</main>
<?php
get_footer();
