/* Header di Chez Halima.
 * - Telefono e tablet: il pulsante apre e chiude la navigazione del parent.
 * - Home: l'header sta trasparente sopra la foto e diventa bianco e fisso quando si scorre.
 * Senza questo script il menu resta visibile come lo stampa il parent. */
(function () {
    var header = document.querySelector('.site-header');
    var nav = header && header.querySelector('.main-navigation');
    var button = header && header.querySelector('.ch-menu-toggle');
    if (!nav || !button) {
        return;
    }
    var label = button.querySelector('.ch-menu-toggle__label');
    var compact = window.matchMedia('(max-width: 849px)');

    // Il pulsante va prima del logo, a sinistra come su chezhalima.ch, e prima del menu per il tasto Tab.
    header.insertBefore(button, header.firstChild);
    nav.id = nav.id || 'ch-primary-nav';
    button.setAttribute('aria-controls', nav.id);
    header.classList.add('ch-nav-ready');

    function setOpen(open) {
        header.classList.toggle('is-menu-open', open);
        button.setAttribute('aria-expanded', open ? 'true' : 'false');
        label.textContent = open ? button.dataset.labelClose : button.dataset.labelOpen;
    }

    button.addEventListener('click', function () {
        setOpen(button.getAttribute('aria-expanded') !== 'true');
    });

    document.addEventListener('keydown', function (event) {
        if (event.key === 'Escape' && header.classList.contains('is-menu-open')) {
            setOpen(false);
            button.focus();
        }
    });

    nav.addEventListener('click', function (event) {
        if (event.target.closest('a')) {
            setOpen(false);
        }
    });

    compact.addEventListener('change', function () {
        setOpen(false);
    });

    if (document.body.classList.contains('home')) {
        var ticking = false;
        var update = function () {
            header.classList.toggle('is-stuck', window.scrollY > 160);
            ticking = false;
        };
        window.addEventListener('scroll', function () {
            if (!ticking) {
                ticking = true;
                window.requestAnimationFrame(update);
            }
        }, { passive: true });
        update();
    }
})();
