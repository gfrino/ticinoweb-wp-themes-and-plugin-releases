<?php
/**
 * Read ordered image attachments from the parent theme media galleries.
 *
 * @package TelecomSecurityChild
 */

defined( 'ABSPATH' ) || exit;

/**
 * Return valid image attachment IDs assigned to a CMS gallery.
 *
 * The gallery manager stores membership in the `ticinoweb_media_gallery`
 * taxonomy and its manual sequence in `_ticinoweb_gallery_order` term meta.
 * IDs missing from the saved sequence are appended in their query order.
 *
 * @param int $gallery_id Gallery term ID.
 * @return int[]
 */
function telecomsecurity_get_media_gallery_attachment_ids( int $gallery_id ): array {
	if ( $gallery_id < 1 || ! taxonomy_exists( 'ticinoweb_media_gallery' ) ) {
		return array();
	}

	$attachment_ids = get_posts(
		array(
			'post_type'              => 'attachment',
			'post_status'            => 'inherit',
			'post_mime_type'         => 'image',
			'posts_per_page'         => 500,
			'fields'                 => 'ids',
			'orderby'                => 'ID',
			'order'                  => 'ASC',
			'no_found_rows'          => true,
			'update_post_meta_cache' => false,
			'update_post_term_cache' => false,
			'tax_query'              => array(
				array(
					'taxonomy' => 'ticinoweb_media_gallery',
					'field'    => 'term_id',
					'terms'    => $gallery_id,
				),
			),
		)
	);

	$attachment_ids = array_values( array_filter( array_map( 'absint', $attachment_ids ) ) );
	if ( empty( $attachment_ids ) ) {
		return array();
	}

	$saved_order = get_term_meta( $gallery_id, '_ticinoweb_gallery_order', true );
	if ( ! is_array( $saved_order ) || empty( $saved_order ) ) {
		return $attachment_ids;
	}

	$saved_order = array_values( array_filter( array_map( 'absint', $saved_order ) ) );
	$ordered     = array_values( array_intersect( $saved_order, $attachment_ids ) );
	$remaining   = array_values( array_diff( $attachment_ids, $ordered ) );

	return array_merge( $ordered, $remaining );
}

/**
 * Same list, found by the gallery slug instead of its numeric term ID.
 *
 * Lo slug è la chiave stabile della galleria: il tema resta installabile su un
 * altro sito e il gestore gallerie può sostituire le immagini senza toccare il
 * codice.
 *
 * @param string $slug Gallery slug, e.g. `iso`.
 * @return int[]
 */
function telecomsecurity_get_media_gallery_ids_by_slug( string $slug ): array {
	$slug = sanitize_title( $slug );
	if ( '' === $slug || ! taxonomy_exists( 'ticinoweb_media_gallery' ) ) {
		return array();
	}

	$gallery = get_term_by( 'slug', $slug, 'ticinoweb_media_gallery' );
	if ( ! $gallery instanceof WP_Term ) {
		return array();
	}

	return telecomsecurity_get_media_gallery_attachment_ids( absint( $gallery->term_id ) );
}

/**
 * Resolve an attachment from its stable Media Library slug.
 *
 * @param string $slug Attachment slug, e.g. `logo-azienda-formatrice`.
 * @return int Attachment ID, or 0 when the file is not in the library.
 */
function telecomsecurity_get_attachment_id_by_slug( string $slug ): int {
	$slug = sanitize_title( $slug );
	if ( '' === $slug ) {
		return 0;
	}

	// Non si usa get_page_by_path(): un allegato caricato dall'editor di una
	// pagina ha un post_parent e non verrebbe trovato.
	$attachment_ids = get_posts(
		array(
			'post_type'              => 'attachment',
			'post_status'            => 'inherit',
			'name'                   => $slug,
			'posts_per_page'         => 1,
			'fields'                 => 'ids',
			'no_found_rows'          => true,
			'update_post_meta_cache' => false,
			'update_post_term_cache' => false,
		)
	);

	return $attachment_ids ? absint( $attachment_ids[0] ) : 0;
}
