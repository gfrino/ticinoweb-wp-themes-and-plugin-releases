<?php
/**
 * Il CMS visto dal Patriziato: un cruscotto con le operazioni di tutti i giorni e un menu corto.
 * Gli amministratori (ticinoWEB) vedono tutto come sempre.
 */
if (!defined('ABSPATH')) {
	exit;
}

function pi_e_cliente() {
	return !current_user_can('manage_options');
}

add_action('admin_menu', function () {
	add_menu_page('Il sito del Patriziato', 'Cruscotto', 'edit_posts', 'pi-cruscotto', 'pi_pagina_cruscotto', 'dashicons-admin-home', 1);
}, 5);

add_action('admin_menu', function () {
	if (!pi_e_cliente()) {
		return;
	}
	foreach (['index.php', 'edit-comments.php', 'tools.php', 'themes.php', 'options-general.php', 'plugins.php', 'edit.php', 'edit.php?post_type=pi_documento', 'edit.php?post_type=page', 'upload.php'] as $m) {
		remove_menu_page($m);
	}
	remove_menu_page('edit.php?post_type=tw_faq');
	remove_submenu_page('edit.php', 'edit-tags.php?taxonomy=category');
	remove_submenu_page('edit.php', 'edit-tags.php?taxonomy=post_tag');
	global $menu;
	foreach ((array) $menu as $i => $voce) {
		if (($voce[2] ?? '') === 'upload.php') {
			$menu[$i][0] = 'Foto e file';
		}
	}
}, 999);

add_filter('custom_menu_order', '__return_true', 1000);
add_filter('menu_order', function ($ordine) {
	$prima = ['pi-cruscotto', 'pi-pubblicazioni', 'pi-documenti', 'ticinoweb-cms', 'edit.php', 'edit.php?post_type=pi_documento', 'edit.php?post_type=page', 'upload.php'];
	$resto = array_values(array_diff($ordine, $prima));
	return array_merge(array_values(array_intersect($prima, $ordine)), $resto);
}, 1001);

// Dopo l'accesso, e da «Bacheca», il Patriziato arriva al suo cruscotto.
add_filter('login_redirect', function ($to, $req, $user) {
	if ($user instanceof WP_User && !user_can($user, 'manage_options') && user_can($user, 'edit_posts')) {
		return admin_url('admin.php?page=pi-cruscotto');
	}
	return $to;
}, 20, 3);
add_action('load-index.php', function () {
	if (pi_e_cliente()) {
		wp_safe_redirect(admin_url('admin.php?page=pi-cruscotto'));
		exit;
	}
});

// Niente avvisi tecnici (aggiornamenti, plugin) per il Patriziato.
add_action('admin_head', function () {
	if (pi_e_cliente()) {
		remove_all_actions('admin_notices');
		remove_all_actions('all_admin_notices');
	}
}, 1);

add_filter('admin_footer_text', function ($t) {
	return pi_e_cliente() ? 'Hai bisogno di aiuto? Contatta <a href="https://ticinoweb.com" target="_blank" rel="noopener">ticinoWEB</a>.' : $t;
});

add_action('admin_enqueue_scripts', function ($hook) {
	$schermo = get_current_screen();
	$tipo = $schermo->post_type ?? '';
	$nostre = in_array($hook, ['toplevel_page_pi-cruscotto', 'ticinoweb-cms_page_pi-patriziato', 'toplevel_page_pi-pubblicazioni', 'pubblicazioni_page_pi-pubblica', 'toplevel_page_pi-documenti'], true) || strpos($hook, 'pi-pubblica') !== false
		|| in_array($tipo, ['post', 'pi_documento', 'page'], true);
	if (!$nostre) {
		return;
	}
	if (in_array($hook, ['post.php', 'post-new.php'], true)) {
		wp_enqueue_media();
	}
	wp_enqueue_style('pi-admin', PI_URI . '/assets/css/admin.css', [], PI_VERSIONE);
	wp_enqueue_script('pi-admin', PI_URI . '/assets/js/admin.js', ['jquery'], PI_VERSIONE, true);
});

/** Riga di un elenco nel cruscotto. */
function pi_cruscotto_riga($p, $nota = '') {
	printf(
		'<li><a href="%s"><span class="pi-c-tipo">%s</span> %s</a><span class="pi-c-meta">%s%s</span></li>',
		esc_url((string) get_edit_post_link($p->ID)),
		esc_html($p->post_type === 'pi_documento' ? 'Documento' : pi_tipo_etichetta(pi_tipo_di($p->ID))),
		esc_html(pi_titolo_pulito(get_the_title($p)) ?: '(senza titolo)'),
		esc_html(get_the_date('d.m.Y', $p)),
		$nota ? ' · ' . esc_html($nota) : ''
	);
}

function pi_pagina_cruscotto() {
	$utente = wp_get_current_user();
	$ora = (int) current_time('G');
	$saluto = $ora < 12 ? 'Buongiorno' : ($ora < 18 ? 'Buon pomeriggio' : 'Buonasera');
	$catalogo = get_page_by_path('catalogo-elettorale', OBJECT, 'pi_documento');
	$elenco = get_page_by_path('elenco-dei-patrizi', OBJECT, 'pi_documento');
	$avvisi = pi_avvisi_attivi(5);
	$ev = pi_assemblea_in_evidenza();
	$ultimi = get_posts(['post_type' => 'post', 'posts_per_page' => 6, 'no_found_rows' => true]);
	$bozze = get_posts(['post_type' => ['post', 'pi_documento'], 'post_status' => ['draft', 'pending', 'future'], 'posts_per_page' => 5, 'no_found_rows' => true]);
	?>
	<div class="wrap pi-cruscotto">
		<h1><?php echo esc_html($saluto . ($utente->first_name ? ', ' . $utente->first_name : '')); ?></h1>
		<p class="pi-aiuto">Da qui pubblichi tutto. Il sito sistema da solo sezione, data, prima pagina e archivio. <a href="<?php echo esc_url(home_url('/')); ?>" target="_blank" rel="noopener">Apri il sito ↗</a></p>

		<div class="pi-azioni-grandi">
			<a class="pi-azione pi-azione--prima" href="<?php echo esc_url(admin_url('admin.php?page=pi-pubblica')); ?>">
				<strong>Nuova pubblicazione</strong>
				<span>Titolo, file, «Pubblica». Il resto lo fa il sito.</span>
			</a>
			<?php if ($catalogo) : ?>
				<a class="pi-azione" href="<?php echo esc_url((string) get_edit_post_link($catalogo->ID)); ?>">
					<strong>Aggiorna il catalogo elettorale</strong>
					<span>Carica il PDF nuovo: il vecchio va nello storico.</span>
				</a>
			<?php endif; ?>
			<?php if ($elenco) : ?>
				<a class="pi-azione" href="<?php echo esc_url((string) get_edit_post_link($elenco->ID)); ?>">
					<strong>Aggiorna l'elenco dei patrizi</strong>
					<span>Stessa cosa, per l'elenco completo.</span>
				</a>
			<?php endif; ?>
			<a class="pi-azione" href="<?php echo esc_url(admin_url('admin.php?page=pi-documenti')); ?>">
				<strong>Regolamenti e documenti</strong>
				<span>Aggiungi o sostituisci un regolamento.</span>
			</a>
			<a class="pi-azione" href="<?php echo esc_url(admin_url('admin.php?page=pi-patriziato')); ?>">
				<strong>Ufficio patriziale e gettoni</strong>
				<span>Chi fa parte dell'amministrazione, dove si comprano i gettoni.</span>
			</a>
		</div>

		<div class="pi-pannelli">
			<section class="pi-pannello">
				<h2>Avvisi in prima pagina</h2>
				<?php if ($avvisi) : ?>
					<ul>
						<?php foreach ($avvisi as $a) {
							pi_cruscotto_riga($a, 'fino al ' . pi_data_breve(get_post_meta($a->ID, '_pi_evidenza_fino', true)));
						} ?>
					</ul>
				<?php else : ?>
					<p class="pi-vuoto">Nessun avviso in prima pagina. Quando pubblichi qualcosa di importante, spunta «È un avviso importante».</p>
				<?php endif; ?>
			</section>

			<section class="pi-pannello">
				<h2><?php echo $ev && $ev['futura'] ? 'Prossima assemblea' : 'Ultima assemblea'; ?></h2>
				<?php if ($ev) :
					$t = $ev['term'];
					$atti = pi_atti_assemblea($t->term_id);
					$presenti = array_map(function ($p) {
						return pi_tipo_di($p->ID);
					}, $atti);
					$attesi = $ev['futura'] ? ['convocazione'] : ['convocazione', 'verbale', 'risoluzioni'];
					$mancano = array_diff($attesi, $presenti); ?>
					<p><strong><?php echo esc_html(pi_data_lunga(pi_assemblea_data($t))); ?></strong> · <a href="<?php echo esc_url(get_term_link($t)); ?>" target="_blank" rel="noopener">pagina sul sito ↗</a></p>
					<ul>
						<?php foreach ($atti as $a) {
							pi_cruscotto_riga($a);
						} ?>
					</ul>
					<?php if ($mancano) : ?>
						<p class="pi-manca">Ancora da pubblicare: <?php echo esc_html(implode(', ', array_map('pi_tipo_etichetta', $mancano))); ?>.</p>
					<?php endif; ?>
				<?php else : ?>
					<p class="pi-vuoto">Nessuna assemblea ancora.</p>
				<?php endif; ?>
			</section>

			<section class="pi-pannello">
				<h2>Ultime pubblicazioni</h2>
				<ul>
					<?php foreach ($ultimi as $p) {
						pi_cruscotto_riga($p);
					} ?>
				</ul>
				<p><a href="<?php echo esc_url(admin_url('admin.php?page=pi-pubblicazioni')); ?>">Tutte le pubblicazioni →</a></p>
			</section>

			<?php if ($bozze) : ?>
				<section class="pi-pannello">
					<h2>Bozze e pubblicazioni programmate</h2>
					<ul>
						<?php foreach ($bozze as $p) {
							pi_cruscotto_riga($p, $p->post_status === 'future' ? 'esce il ' . get_the_date('d.m.Y', $p) : 'bozza');
						} ?>
					</ul>
				</section>
			<?php endif; ?>
		</div>
	</div>
	<?php
}
