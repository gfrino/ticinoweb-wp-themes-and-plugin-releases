<?php
defined('ABSPATH') || exit;
function qz_home($key) {
    $data=get_post_meta((int)get_option('page_on_front'),'_qz_home',true);
    if('contact_url'===$key){$mapping=(array)get_option('ticinoweb_page_mapping',[]);return !empty($mapping['page_contatti'])?get_permalink((int)$mapping['page_contatti']):'';}
    if('brands_url'===$key&&!empty($data['brands_page_id']))return get_permalink((int)$data['brands_page_id']);
    if('scene_link'===$key&&!empty($data['scene_category_id'])){$link=get_term_link((int)$data['scene_category_id'],'product_cat');return is_wp_error($link)?'':$link;}
    $value=is_array($data)&&isset($data[$key])?$data[$key]:'';
    return is_string($value)&&function_exists('ticinoweb_frontend_text')?ticinoweb_frontend_text($value,'qz:home:'.$key):$value;
}
function qz_option($key) {return function_exists('ticinoweb_frontend_text')?ticinoweb_frontend_text((string)get_option($key,''),'qz:option:'.$key):(string)get_option($key,'');}
function qz_photo($value,$size='large',$attributes=[]) {
    $id=is_numeric($value)?absint($value):attachment_url_to_postid($value);
    if($id)echo wp_get_attachment_image($id,$size,false,array_merge(['loading'=>'lazy','decoding'=>'async'],$attributes));
}
/** Theme-owned decorative artwork follows the existing category, never its position. */
function qz_department_drawing($term) {
    $original_id=apply_filters('wpml_object_id',$term->term_id,'product_cat',true,apply_filters('wpml_default_language',null));
    $original=$original_id!==$term->term_id?get_term($original_id,'product_cat'):$term;
    $slug=sanitize_file_name(!is_wp_error($original)&&$original?$original->slug:$term->slug);
    $asset='/assets/illustrations/'.$slug.'.webp';
    if(!is_file(get_stylesheet_directory().$asset))return;
    echo '<span class="qz-animal__drawing" aria-hidden="true"><img src="'.esc_url(get_stylesheet_directory_uri().$asset).'" width="640" height="640" alt="" loading="lazy" decoding="async" fetchpriority="low"></span>';
}
function qz_title($text,$tag='h2',$class='') {
    if(!$text)return;
    $tag=in_array($tag,['h1','h2','h3'],true)?$tag:'h2';
    echo '<'.$tag.' class="'.esc_attr($class).'">';
    $lines=explode("\n",$text);foreach($lines as $i=>$line){echo '<span>'.esc_html($line).'</span>';}
    echo '</'.$tag.'>';
}
function qz_icon($name='arrow') {
    $paths=[
        'chevron'=>'<path d="m6 9 6 6 6-6"/>',
        'arrow'=>'<path d="M5 12h14m-5-5 5 5-5 5"/>',
        'play'=>'<path d="m9 5 11 7-11 7Z"/>',
        'pause'=>'<path d="M9 5v14m6-14v14"/>',
        'search'=>'<circle cx="10.5" cy="10.5" r="6.5"/><path d="m16 16 5 5"/>',
        'cart'=>'<path d="M5 7h15l-2 10H7L4 3H2"/><circle cx="8" cy="21" r="1"/><circle cx="17" cy="21" r="1"/>',
        'user'=>'<circle cx="12" cy="8" r="4"/><path d="M4 22v-2a8 8 0 0 1 16 0v2"/>',
        'menu'=>'<path d="M4 7h16M4 12h16M4 17h16"/>',
        'close'=>'<path d="m6 6 12 12M6 18 18 6"/>',
        'heart'=>'<path d="M20 5c-3-3-6-1-8 1-2-2-5-4-8-1-5 5 5 12 8 15 3-3 13-10 8-15Z"/>',
        'paw'=>'<ellipse cx="7" cy="6" rx="2" ry="3"/><ellipse cx="16" cy="5" rx="2" ry="3"/><ellipse cx="3" cy="12" rx="1.5" ry="2.5"/><ellipse cx="21" cy="11" rx="1.5" ry="2.5"/><path d="M5 19c0-3 4-8 7-8s7 5 7 8c0 5-5 1-7 1s-7 4-7-1Z"/>',
        'pin'=>'<path d="M20 10c0 6-8 12-8 12S4 16 4 10a8 8 0 1 1 16 0Z"/><circle cx="12" cy="10" r="3"/>',
        'fish'=>'<path d="M4 12C8 4 15 4 19 12c-4 8-11 8-15 0Z"/><path d="m4 12-3-4v8l3-4m8-6v12"/><circle cx="16" cy="11" r=".6"/>',
        'turtle'=>'<ellipse cx="12" cy="13" rx="7" ry="6"/><circle cx="12" cy="4" r="2"/><path d="m5 10-3-2m17 2 3-2M6 17l-3 3m15-3 3 3m-9-1v3M9 9l-2 5 5 3 5-3-2-5Z"/>',
        'pond'=>'<path d="M2 17c3-3 5 3 8 0s5 3 8 0 4 0 4 0M2 22c3-3 5 3 8 0s5 3 8 0 4 0 4 0M12 15V5m0 6C5 12 4 8 4 4c5 0 8 3 8 7Zm0-3c6 0 7-4 7-7-4 0-7 3-7 7Z"/>',
        'bag'=>'<path d="M4 7h16l-1 15H5L4 7Zm4 0V5a4 4 0 0 1 8 0v2"/><path d="M10 13c1-2 3-2 4 0s-2 4-2 4-3-2-2-4Z"/>',
        'leaf'=>'<path d="M20 3C7 2 2 7 4 15s17 8 16-12ZM4 21 16 9"/>',
    ];
    return '<svg class="qz-icon qz-icon--'.esc_attr(isset($paths[$name])?$name:'arrow').'" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">'.($paths[$name]??$paths['arrow']).'</svg>';
}
function qz_cart_link(){
    echo '<a class="qz-cart" href="'.esc_url(ticinoweb_get_cart_url()).'" aria-label="'.esc_attr__('Vai al carrello','qualazampa').'">'.qz_icon('cart').'<span class="qz-cart__label">'.esc_html__('Carrello','qualazampa').'</span><span class="qz-cart__count">'.esc_html(ticinoweb_get_cart_count()).'</span></a>';
}
function qz_departments(){
    $ids=array_filter(array_map('absint',explode(',',(string)qz_home('category_ids'))));
    return get_terms(['taxonomy'=>'product_cat','hide_empty'=>false,'include'=>$ids,'orderby'=>'include']);
}
function qz_product_list($ids,$limit=4){
    if(!function_exists('wc_get_products'))return [];
    $ids=array_slice(array_filter(array_map('absint',(array)$ids)),0,$limit);
    return $ids?wc_get_products(['include'=>$ids,'limit'=>$limit,'status'=>'publish','orderby'=>'include']):[];
}
function qz_product_grid($products){
    if(!$products)return;
    $old=$GLOBALS['post']??null;$old_product=$GLOBALS['product']??null;
    wc_set_loop_prop('columns',4);woocommerce_product_loop_start();
    foreach($products as $item){$GLOBALS['post']=get_post($item->get_id());setup_postdata($GLOBALS['post']);$GLOBALS['product']=$item;wc_get_template_part('content','product');}
    woocommerce_product_loop_end();$GLOBALS['post']=$old;$GLOBALS['product']=$old_product;wp_reset_postdata();
}
function qz_hours(){
    $days=['monday'=>__('Lunedì','qualazampa'),'tuesday'=>__('Martedì','qualazampa'),'wednesday'=>__('Mercoledì','qualazampa'),'thursday'=>__('Giovedì','qualazampa'),'friday'=>__('Venerdì','qualazampa'),'saturday'=>__('Sabato','qualazampa'),'sunday'=>__('Domenica','qualazampa')];
    $hours=get_option('ticinoweb_contact_opening_hours',[]);
    echo '<dl class="qz-hours">';foreach($days as $key=>$label){if(isset($hours[$key]))echo '<div><dt>'.esc_html($label).'</dt><dd>'.esc_html(ticinoweb_format_day_hours($hours[$key])).'</dd></div>'; }echo '</dl>';
}

/** Brand names come from the catalogue; artwork comes from the existing Partner inputs. */
function qz_home_brands($limit=18){
    $logos=[];$preferred=[];
    for($i=1;$i<=min(48,(int)get_option('ticinoweb_partner_count',0));$i++){
        $params=[];wp_parse_str((string)wp_parse_url(get_option('ticinoweb_partner_link_'.$i),PHP_URL_QUERY),$params);
        $id=absint($params['qz_brand']??0);$logo=get_option('ticinoweb_partner_logo_'.$i);
        if($id&&$logo){$logos[$id]=$logo;$preferred[]=$id;}
    }
    $terms=get_terms(['taxonomy'=>'pa_marche','hide_empty'=>true,'orderby'=>'count','order'=>'DESC']);
    if(is_wp_error($terms))return [];
    $order=array_flip($preferred);
    usort($terms,static function($a,$b)use($order){$ai=$order[$a->term_id]??10000;$bi=$order[$b->term_id]??10000;return $ai===$bi?$b->count<=>$a->count:$ai<=>$bi;});
    return array_map(static fn($term)=>['term'=>$term,'logo'=>$logos[$term->term_id]??''],array_slice($terms,0,$limit));
}
