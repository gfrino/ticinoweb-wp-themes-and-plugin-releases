<?php
/**
 * City pages: which page belongs to which service area, and the links to them.
 *
 * The towns themselves are the list on the front page (inc/service-areas.php). A
 * city page says which of those towns it is about with one select in its sidebar;
 * from that the footer, the front-page tags and the service pages link to it, and
 * the page gets a Service schema for that town (inc/structured-data.php).
 *
 * Pages nobody has assigned yet are found by slug, when exactly one top-level page
 * ends in "-<town>" (plumbing-service-cambridge, plumber-guelph). That keeps the
 * existing sites linked without touching their database; picking a town in the
 * select always wins over the guess, and "not a city page" switches it off.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

const ECO_CITY_META      = '_eco_city_area';
const ECO_CITY_NONE      = '-';
const ECO_CITY_TRANSIENT = 'eco_city_pages';

/**
 * This site's city pages, in the order of the service-area list.
 *
 * @return array List of {name, id, url}. Towns without a page are left out.
 */
function eco_city_pages() {
    static $pages = null;

    if ( $pages !== null ) {
        return $pages;
    }

    $map = get_transient( ECO_CITY_TRANSIENT );
    if ( ! is_array( $map ) ) {
        $map = eco_city_build_map();
        set_transient( ECO_CITY_TRANSIENT, $map, DAY_IN_SECONDS );
    }

    $pages = array();
    foreach ( eco_sa_areas() as $area ) {
        $key = eco_city_key( $area['name'] );
        if ( empty( $map[ $key ] ) ) {
            continue;
        }

        $pages[] = array(
            'name' => $area['name'],
            'id'   => (int) $map[ $key ],
            'url'  => get_permalink( (int) $map[ $key ] ),
        );
    }

    return $pages;
}

/**
 * Link to a town's page, or '' when it has none.
 *
 * @param string $name Town as written in the service-area list.
 * @return string
 */
function eco_city_page_url( $name ) {
    foreach ( eco_city_pages() as $page ) {
        if ( eco_city_key( $page['name'] ) === eco_city_key( $name ) ) {
            return $page['url'];
        }
    }

    return '';
}

/**
 * The town the current page is about, or '' when it is not a city page.
 *
 * @param int $post_id
 * @return string
 */
function eco_city_of_page( $post_id ) {
    foreach ( eco_city_pages() as $page ) {
        if ( $page['id'] === (int) $post_id ) {
            return $page['name'];
        }
    }

    return '';
}

/**
 * @param string $name
 * @return string
 */
function eco_city_key( $name ) {
    return sanitize_title( $name );
}

/**
 * Town key → page ID, explicit choices first, slug guesses for the rest.
 *
 * @return array
 */
function eco_city_build_map() {
    global $wpdb;

    $map     = array();
    $opt_out = array();

    $assigned = get_posts( array(
        'post_type'      => 'page',
        'post_status'    => 'publish',
        'posts_per_page' => -1,
        'meta_key'       => ECO_CITY_META,
        'orderby'        => 'ID',
        'order'          => 'ASC',
        'fields'         => 'ids',
        'no_found_rows'  => true,
    ) );

    foreach ( $assigned as $page_id ) {
        $value = (string) get_post_meta( $page_id, ECO_CITY_META, true );
        if ( $value === ECO_CITY_NONE ) {
            $opt_out[] = (int) $page_id;
            continue;
        }

        $key = eco_city_key( $value );
        if ( $key !== '' && ! isset( $map[ $key ] ) ) {
            $map[ $key ] = (int) $page_id;
        }
    }

    $slugs = $wpdb->get_results(
        "SELECT ID, post_name FROM {$wpdb->posts} WHERE post_type = 'page' AND post_status = 'publish' AND post_parent = 0"
    );

    foreach ( eco_sa_areas() as $area ) {
        $key = eco_city_key( $area['name'] );
        if ( $key === '' || isset( $map[ $key ] ) ) {
            continue;
        }

        $matches = array();
        foreach ( $slugs as $row ) {
            if ( substr( $row->post_name, -strlen( '-' . $key ) ) === '-' . $key && ! in_array( (int) $row->ID, $opt_out, true ) ) {
                $matches[] = (int) $row->ID;
            }
        }

        // Two candidates means the guess could be wrong; leave it to the editor.
        if ( count( $matches ) === 1 && ! in_array( $matches[0], $map, true ) ) {
            $map[ $key ] = $matches[0];
        }
    }

    return $map;
}

/**
 * Any page saved, trashed or deleted can change the map, and so can the
 * service-area list, which lives on the front page.
 */
function eco_city_flush() {
    delete_transient( ECO_CITY_TRANSIENT );
}
add_action( 'save_post_page', 'eco_city_flush' );
add_action( 'deleted_post', 'eco_city_flush' );
add_action( 'trashed_post', 'eco_city_flush' );
add_action( 'update_option_page_on_front', 'eco_city_flush' );

/**
 * Inline list of links to the city pages.
 *
 * @param string $heading Optional heading printed above the list.
 * @return void
 */
function eco_city_links( $heading = '' ) {
    $pages = eco_city_pages();
    if ( ! $pages ) {
        return;
    }

    $current = is_singular() ? get_queried_object_id() : 0;
    ?>
    <nav class="eco-city-links" aria-label="<?php esc_attr_e( 'Areas we serve', 'ecoproplumbing-child-theme' ); ?>">
        <?php if ( $heading !== '' ) : ?>
            <h2 class="eco-city-links__title"><?php echo esc_html( $heading ); ?></h2>
        <?php endif; ?>
        <ul class="eco-city-links__list">
            <?php foreach ( $pages as $page ) : ?>
                <li>
                    <?php if ( $page['id'] === $current ) : ?>
                        <span class="eco-city-links__link is-current" aria-current="page"><?php echo esc_html( $page['name'] ); ?></span>
                    <?php else : ?>
                        <a class="eco-city-links__link" href="<?php echo esc_url( $page['url'] ); ?>"><?php echo esc_html( $page['name'] ); ?></a>
                    <?php endif; ?>
                </li>
            <?php endforeach; ?>
        </ul>
    </nav>
    <?php
}

/* -------------------------------------------------------------------------
 * Admin: "this page is about…" select in the page sidebar
 * ---------------------------------------------------------------------- */

add_action( 'add_meta_boxes_page', 'eco_city_add_meta_box' );
function eco_city_add_meta_box( $post ) {
    if ( (int) $post->ID === eco_sa_source_page_id() ) {
        return;
    }

    add_meta_box( 'eco-city-page', __( 'Pagina città', 'ecoproplumbing-child-theme' ), 'eco_city_render_meta_box', 'page', 'side', 'default' );
}

/**
 * @param WP_Post $post
 */
function eco_city_render_meta_box( $post ) {
    wp_nonce_field( 'eco_city_save', 'eco_city_nonce' );

    $areas   = eco_sa_areas();
    $stored  = (string) get_post_meta( $post->ID, ECO_CITY_META, true );
    $guessed = $stored === '' ? eco_city_of_page( $post->ID ) : '';
    // A guessed page shows its town, so saving it simply makes the guess explicit.
    $current = $stored !== '' ? $stored : ( $guessed !== '' ? $guessed : ECO_CITY_NONE );
    ?>
    <p>
        <label for="eco_city_area"><?php esc_html_e( 'Questa pagina parla della località:', 'ecoproplumbing-child-theme' ); ?></label>
        <select id="eco_city_area" name="eco_city_area" class="widefat">
            <option value="<?php echo esc_attr( ECO_CITY_NONE ); ?>" <?php selected( $current, ECO_CITY_NONE ); ?>><?php esc_html_e( '— non è una pagina città —', 'ecoproplumbing-child-theme' ); ?></option>
            <?php foreach ( $areas as $area ) : ?>
                <option value="<?php echo esc_attr( $area['name'] ); ?>" <?php selected( eco_city_key( $current ), eco_city_key( $area['name'] ) ); ?>><?php echo esc_html( $area['name'] ); ?></option>
            <?php endforeach; ?>
        </select>
    </p>
    <p class="description">
        <?php esc_html_e( 'La pagina viene linkata nel footer, nelle pagine servizio e dal nome della località in home. Le località sono quelle della lista "Service Areas" sulla home: se manca, aggiungila lì.', 'ecoproplumbing-child-theme' ); ?>
        <?php if ( $guessed !== '' ) : ?>
            <br><em><?php printf( esc_html__( 'Ora è collegata automaticamente a %s in base all\'indirizzo della pagina.', 'ecoproplumbing-child-theme' ), esc_html( $guessed ) ); ?></em>
        <?php endif; ?>
    </p>
    <?php
}

add_action( 'save_post_page', 'eco_city_save_meta_box', 5 );
/**
 * @param int $post_id
 */
function eco_city_save_meta_box( $post_id ) {
    if ( ! isset( $_POST['eco_city_nonce'] ) || ! wp_verify_nonce( sanitize_key( $_POST['eco_city_nonce'] ), 'eco_city_save' ) ) {
        return;
    }

    if ( wp_is_post_revision( $post_id ) || wp_is_post_autosave( $post_id ) || ! current_user_can( 'edit_post', $post_id ) ) {
        return;
    }

    $value = isset( $_POST['eco_city_area'] ) ? sanitize_text_field( wp_unslash( $_POST['eco_city_area'] ) ) : '';

    // A page nobody ever pointed at a town stays meta-free, so a later slug or
    // list change can still find it; an editor's explicit choice is stored.
    $guess_or_none = eco_city_of_page( $post_id ) !== '' ? eco_city_of_page( $post_id ) : ECO_CITY_NONE;
    if ( $value === '' || ( get_post_meta( $post_id, ECO_CITY_META, true ) === '' && $value === $guess_or_none ) ) {
        return;
    }

    update_post_meta( $post_id, ECO_CITY_META, $value );
}
