<?php
/**
 * Structured data: tells Google and AI assistants this is a plumber, where it is
 * and which towns it covers.
 *
 * The parent prints one Organization block on the home page. Through its filter
 * that block becomes a Plumber (a LocalBusiness subtype) with the phone, email,
 * address and opening hours from ticinoWEB CMS and the towns of the service-area
 * list. City pages get a Service block for their own town, pointing back to the
 * same business. Nothing is typed in here: every value is read from the site.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Stable identifier of the business node, shared by every block that names it.
 *
 * @return string
 */
function ecoproplumbing_business_id() {
    return home_url( '/#business' );
}

/**
 * Contact and location properties of the business, skipping any that are empty.
 *
 * @return array
 */
function ecoproplumbing_business_properties() {
    $props = array(
        '@id' => ecoproplumbing_business_id(),
    );

    $phone = trim( (string) get_option( 'ticinoweb_contact_phone', '' ) );
    if ( $phone !== '' ) {
        $props['telephone'] = $phone;
    }

    $email = sanitize_email( (string) get_option( 'ticinoweb_contact_email', '' ) );
    if ( $email !== '' ) {
        $props['email'] = $email;
    }

    $address = trim( (string) get_option( 'ticinoweb_contact_address', '' ) );
    if ( $address !== '' ) {
        $props['address'] = array(
            '@type'         => 'PostalAddress',
            'streetAddress' => $address,
        );
    }

    $hours = ecoproplumbing_opening_hours_schema();
    if ( $hours ) {
        $props['openingHoursSpecification'] = $hours;
    }

    $areas = array();
    foreach ( eco_sa_areas() as $area ) {
        $areas[] = array(
            '@type' => 'City',
            'name'  => $area['name'],
        );
    }
    if ( $areas ) {
        $props['areaServed'] = $areas;
    }

    return $props;
}

/**
 * Opening hours from ticinoWEB CMS as OpeningHoursSpecification entries.
 *
 * @return array
 */
function ecoproplumbing_opening_hours_schema() {
    $hours = get_option( 'ticinoweb_contact_opening_hours', array() );
    if ( ! is_array( $hours ) ) {
        return array();
    }

    $days = array(
        'monday'    => 'Monday',
        'tuesday'   => 'Tuesday',
        'wednesday' => 'Wednesday',
        'thursday'  => 'Thursday',
        'friday'    => 'Friday',
        'saturday'  => 'Saturday',
        'sunday'    => 'Sunday',
    );

    $specs = array();
    foreach ( $days as $key => $day ) {
        if ( empty( $hours[ $key ] ) || ! empty( $hours[ $key ]['closed'] ) ) {
            continue;
        }

        if ( ! empty( $hours[ $key ]['open_24h'] ) ) {
            $specs[] = array(
                '@type'     => 'OpeningHoursSpecification',
                'dayOfWeek' => 'https://schema.org/' . $day,
                'opens'     => '00:00',
                'closes'    => '23:59',
            );
            continue;
        }

        foreach ( (array) ( $hours[ $key ]['slots'] ?? array() ) as $slot ) {
            $opens  = ecoproplumbing_schema_time( $slot['open'] ?? '' );
            $closes = ecoproplumbing_schema_time( $slot['close'] ?? '' );
            if ( $opens === '' || $closes === '' ) {
                continue;
            }

            $specs[] = array(
                '@type'     => 'OpeningHoursSpecification',
                'dayOfWeek' => 'https://schema.org/' . $day,
                'opens'     => $opens,
                'closes'    => $closes,
            );
        }
    }

    return $specs;
}

/**
 * "8:30", "08.30" or "8" → "08:30"; anything else → ''.
 *
 * @param string $time
 * @return string
 */
function ecoproplumbing_schema_time( $time ) {
    if ( ! preg_match( '/^\s*(\d{1,2})(?:[:.](\d{2}))?\s*$/', (string) $time, $m ) ) {
        return '';
    }

    $h   = (int) $m[1];
    $min = isset( $m[2] ) ? (int) $m[2] : 0;
    if ( $h > 24 || $min > 59 ) {
        return '';
    }

    return sprintf( '%02d:%02d', $h, $min );
}

/**
 * Home page: the parent's Organization block becomes a Plumber.
 *
 * @param array $schema
 * @return array
 */
add_filter( 'ticinoweb_seo_jsonld_org_schema', 'ecoproplumbing_org_schema' );
function ecoproplumbing_org_schema( $schema ) {
    // The parent's LocalBusiness branch reads tw_seo_business_*; the CMS contact
    // fields are the ones the footer shows, so those replace it.
    unset( $schema['telephone'], $schema['address'] );

    $schema['@type'] = 'Plumber';

    return array_merge( $schema, ecoproplumbing_business_properties() );
}

/**
 * City pages: a Service block for that town, provided by the business.
 */
add_action( 'wp_footer', 'ecoproplumbing_city_service_schema' );
function ecoproplumbing_city_service_schema() {
    if ( ! is_page() || is_front_page() || get_option( 'tw_seo_enable_schema', '1' ) !== '1' ) {
        return;
    }

    $city = eco_city_of_page( get_queried_object_id() );
    if ( $city === '' ) {
        return;
    }

    $provider = array_merge(
        array(
            '@type' => 'Plumber',
            'name'  => get_option( 'tw_seo_org_name', get_bloginfo( 'name' ) ),
            'url'   => home_url( '/' ),
        ),
        ecoproplumbing_business_properties()
    );
    // The full town list belongs to the business on the home page; here the
    // page is about one town.
    unset( $provider['areaServed'] );

    $schema = array(
        '@context'    => 'https://schema.org',
        '@type'       => 'Service',
        'serviceType' => 'Plumbing',
        'name'        => wp_strip_all_tags( get_the_title() ),
        'url'         => get_permalink(),
        'areaServed'  => array(
            '@type' => 'City',
            'name'  => $city,
        ),
        'provider'    => $provider,
    );

    echo '<script type="application/ld+json">' . wp_json_encode( $schema, JSON_UNESCAPED_UNICODE ) . '</script>' . "\n";
}
