<?php
/**
 * Business facts: one value per claim, read by every template that states it.
 *
 * The emergency response time used to be typed into three templates (30 minutes on
 * the home and service pages, 45 on the emergency page), and the years in business
 * into the About page. Google, AI assistants and careful customers all read a site
 * that contradicts itself as less trustworthy, so each claim now has one per-site
 * option in ticinoWEB CMS and the templates only print it.
 *
 * Defaults apply only while an option has never been saved, so the update changes
 * nothing that was not already on the emergency and About pages. Saving the years
 * empty hides that claim; saving the response time empty makes every response-time
 * sentence say "same-day service" instead (ecoproplumbing.ca since November 2026: the
 * owner does not promise minutes, which depend on distance and the day's bookings).
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Emergency response time in minutes, or 0 when the site promises same-day service instead.
 *
 * @return int
 */
function ecoproplumbing_response_minutes() {
    // 45 was the emergency page's figure, the more cautious of the two the site gave.
    return absint( get_option( 'ecopro_response_minutes', 45 ) );
}

/**
 * Years in business, or 0 when the site states none.
 *
 * @return int
 */
function ecoproplumbing_years_in_business() {
    return absint( get_option( 'ecopro_years_in_business', 15 ) );
}

/**
 * "within 45 minutes" — the phrase every response-time sentence is built around.
 *
 * @return string Plain text, or '' when no response time is set.
 */
function ecoproplumbing_response_phrase() {
    $minutes = ecoproplumbing_response_minutes();
    if ( ! $minutes ) {
        return '';
    }

    /* translators: %d: emergency response time in minutes */
    return sprintf( _n( 'within %d minute', 'within %d minutes', $minutes, 'ecoproplumbing-child-theme' ), $minutes );
}

/* -------------------------------------------------------------------------
 * Admin — fields inside the ticinoWEB CMS form (same group as the license number)
 * ---------------------------------------------------------------------- */

add_action( 'admin_init', 'ecoproplumbing_register_business_facts' );
function ecoproplumbing_register_business_facts() {
    // The parent's standalone Settings page posts the same option group without
    // these fields, and options.php then saves null for every missing one. Treat
    // null as "not on this form" and keep what the site already states; only an
    // empty field the editor actually submitted hides the claim.
    $sanitizer = static function ( $current ) {
        return static function ( $value ) use ( $current ) {
            if ( $value === null ) {
                return $current ? (string) call_user_func( $current ) : '';
            }

            $value = trim( (string) $value );

            return $value === '' ? '' : (string) absint( $value );
        };
    };

    register_setting( 'ticinoweb_settings_group', 'ecopro_response_minutes', array(
        'type'              => 'string',
        'sanitize_callback' => $sanitizer( 'ecoproplumbing_response_minutes' ),
    ) );

    register_setting( 'ticinoweb_settings_group', 'ecopro_years_in_business', array(
        'type'              => 'string',
        'sanitize_callback' => $sanitizer( 'ecoproplumbing_years_in_business' ),
    ) );

    add_settings_section(
        'ecopro_business_facts_section',
        __( 'Dati dell\'azienda — uguali su tutto il sito', 'ecoproplumbing' ),
        'ecoproplumbing_business_facts_intro',
        'ticinoweb_settings_group'
    );

    add_settings_field(
        'ecopro_response_minutes',
        __( 'Tempo di intervento d\'emergenza (minuti)', 'ecoproplumbing' ),
        'ecoproplumbing_business_fact_field',
        'ticinoweb_settings_group',
        'ecopro_business_facts_section',
        array(
            'option' => 'ecopro_response_minutes',
            'value'  => ecoproplumbing_response_minutes(),
            'help'   => __( 'Compare nel blocco 24/7 della home, delle pagine servizio e della pagina emergenze, e nel testo delle zone servite. Lascia vuoto per scrivere «Same day service» al posto dei minuti.', 'ecoproplumbing' ),
        )
    );

    add_settings_field(
        'ecopro_years_in_business',
        __( 'Anni di attività', 'ecoproplumbing' ),
        'ecoproplumbing_business_fact_field',
        'ticinoweb_settings_group',
        'ecopro_business_facts_section',
        array(
            'option' => 'ecopro_years_in_business',
            'value'  => ecoproplumbing_years_in_business(),
            'help'   => __( 'Compare nella pagina About us come "25+ Years of Experience".', 'ecoproplumbing' ),
        )
    );
}

function ecoproplumbing_business_facts_intro() {
    echo '<p>' . esc_html__( 'Ogni numero si scrive una volta sola qui e il sito lo ripete uguale ovunque. Lascia vuoto il tempo di intervento per scrivere «Same day service»; lascia vuoti gli anni per non mostrarli. I testi scritti nelle pagine (per esempio le pagine città) vanno tenuti allineati a mano.', 'ecoproplumbing' ) . '</p>';
}

/**
 * @param array $args {option, value, help}
 */
function ecoproplumbing_business_fact_field( $args ) {
    $value = $args['value'] ? (string) $args['value'] : '';
    ?>
    <input type="number" min="0" step="1" id="<?php echo esc_attr( $args['option'] ); ?>"
           name="<?php echo esc_attr( $args['option'] ); ?>"
           value="<?php echo esc_attr( $value ); ?>" class="small-text">
    <p class="description"><?php echo esc_html( $args['help'] ); ?></p>
    <?php
}
