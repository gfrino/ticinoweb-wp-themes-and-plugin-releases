<?php defined('ABSPATH') || exit;get_header(); ?>
<main id="main-content" class="qz-shop qz-container qz-section<?php echo is_product()?' qz-product':' qz-catalog'; ?>"><?php if(is_product())woocommerce_breadcrumb(); woocommerce_content(); ?></main><?php get_footer(); ?>
