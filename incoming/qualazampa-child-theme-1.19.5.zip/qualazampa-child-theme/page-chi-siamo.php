<?php
defined('ABSPATH') || exit;
get_header();
$settings=qz_about_data();$team=qz_about_team();$gallery=qz_about_gallery();
$rate=absint($settings['rate']??0);$purchases=absint($settings['purchases']??0);$contact=qz_home('contact_url');
?>
<main id="main-content" class="qz-about">
<?php while(have_posts()):the_post(); ?>
    <section class="qz-about-opening qz-container" aria-labelledby="qz-about-title">
        <div class="qz-about-opening__copy">
            <h1 id="qz-about-title" class="qz-about-title"><?php echo nl2br(esc_html(qz_option('ticinoweb_chi_siamo_title')?:get_the_title())); ?></h1>
            <div class="qz-about-intro"><?php echo wp_kses_post(wpautop(qz_option('ticinoweb_chi_siamo_text'))); ?></div>
            <?php if($rate&&$purchases): ?><a class="qz-button" href="#tessera-fedelta"><?php esc_html_e('Scopri la tessera fedeltà','qualazampa'); ?></a><?php endif; ?>
        </div>
        <figure class="qz-about-opening__photo"><?php qz_photo(qz_option('ticinoweb_chi_siamo_image'),'large',['loading'=>'eager','fetchpriority'=>'high','sizes'=>'(max-width: 760px) 100vw, 50vw']); ?></figure>
    </section>
    <section class="qz-about-story qz-container" aria-labelledby="qz-about-story-title">
        <h2 id="qz-about-story-title"><?php the_title(); ?></h2>
        <div class="qz-about-story__text"><?php the_content(); ?></div>
    </section>
    <?php if($team): ?>
    <section class="qz-about-team" aria-labelledby="qz-team-title">
        <div class="qz-container qz-about-team__inner">
            <header><h2 id="qz-team-title" class="qz-about-heading"><?php echo nl2br(esc_html(qz_about_text('team_title'))); ?></h2><p><?php echo esc_html(qz_about_text('team_text')); ?></p></header>
            <div class="qz-team-portraits">
                <?php foreach($team as $member):if(!has_post_thumbnail($member))continue; ?>
                <figure class="qz-team-person">
                    <?php echo get_the_post_thumbnail($member,'medium_large',['sizes'=>'(max-width: 600px) 70vw, 260px','loading'=>'lazy','alt'=>$member->post_title]); ?>
                    <?php if($member->post_excerpt): ?><figcaption><?php echo esc_html(get_the_title($member)); ?><span><?php echo esc_html(get_the_excerpt($member)); ?></span></figcaption><?php endif; ?>
                </figure>
                <?php endforeach; ?>
            </div>
        </div>
    </section>
    <?php endif; ?>
    <?php if($rate&&$purchases): ?>
    <section id="tessera-fedelta" class="qz-about-loyalty qz-container" aria-labelledby="qz-loyalty-title">
        <div class="qz-about-loyalty__copy">
            <h2 id="qz-loyalty-title" class="qz-about-heading"><?php echo nl2br(esc_html(qz_about_text('loyalty_title'))); ?></h2>
            <p class="qz-about-loyalty__lead"><?php echo esc_html(sprintf(__('Con la tessera fedeltà, uno sconto del %1$s%% sul totale di %2$s acquisti.','qualazampa'),$rate,$purchases)); ?></p>
            <div><?php echo wp_kses_post(wpautop(qz_about_text('loyalty_text'))); ?></div>
            <?php if($contact): ?><a href="<?php echo esc_url($contact); ?>" class="qz-button"><?php esc_html_e('Vieni a trovarci','qualazampa'); ?></a><?php endif; ?>
        </div>
        <div class="qz-loyalty-card">
            <div class="qz-loyalty-card__top"><?php qz_photo(qz_option('ticinoweb_site_logo'),'medium',['alt'=>get_bloginfo('name'),'loading'=>'lazy']); ?><span><?php esc_html_e('Tessera fedeltà','qualazampa'); ?></span></div>
            <div class="qz-loyalty-card__reward"><strong><?php echo esc_html($rate); ?><span>%</span></strong><p><?php echo esc_html(sprintf(__('sul totale di %s acquisti','qualazampa'),$purchases)); ?></p></div>
            <div class="qz-loyalty-card__stamps" aria-hidden="true"><?php for($i=0;$i<min($purchases,10);$i++)echo qz_icon('paw'); ?></div>
            <p class="qz-loyalty-card__foot"><?php esc_html_e('Una piccola attenzione, in negozio.','qualazampa'); ?></p>
        </div>
    </section>
    <?php endif; ?>
    <?php if($gallery): ?>
    <section class="qz-about-gallery" aria-labelledby="qz-gallery-title">
        <header class="qz-container qz-about-gallery__heading"><h2 id="qz-gallery-title" class="qz-about-heading"><?php echo nl2br(esc_html(qz_about_text('gallery_title'))); ?></h2><p><?php echo esc_html(qz_about_text('gallery_text')); ?></p></header>
        <div class="qz-shop-ribbon" data-shop-ribbon tabindex="0" role="region" aria-label="<?php esc_attr_e('Fotografie del negozio, scorri per esplorare','qualazampa'); ?>">
            <div class="qz-shop-ribbon__track" data-ribbon-track>
                <?php foreach($gallery as $id): ?><figure><?php echo wp_get_attachment_image($id,'large',false,['sizes'=>'(max-width: 760px) 80vw, 560px','loading'=>'lazy']); ?></figure><?php endforeach; ?>
            </div>
        </div>
        <div class="qz-container qz-about-gallery__close"><p><?php esc_html_e('Il nostro negozio, anche online.','qualazampa'); ?></p><a class="qz-button" href="<?php echo esc_url(wc_get_page_permalink('shop')); ?>"><?php esc_html_e('Esplora lo shop','qualazampa'); ?></a></div>
    </section>
    <?php endif; ?>
<?php endwhile; ?>
</main>
<?php get_footer(); ?>
