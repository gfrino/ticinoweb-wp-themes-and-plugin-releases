<?php
defined('ABSPATH') || exit;
$commerce=function_exists('is_cart')&&(is_cart()||is_checkout());
$account=function_exists('is_account_page')&&is_account_page();
$scope=$commerce?' qz-commerce '.(is_cart()?'qz-commerce--cart':'qz-commerce--checkout'):($account?' qz-account-page':'');
get_header();
?>
<main id="main-content" class="qz-page qz-container qz-section<?php echo esc_attr($scope); ?>">
    <?php while(have_posts()):the_post(); ?>
    <h1><?php the_title(); ?></h1>
    <div class="<?php echo $commerce?'qz-commerce__content':($account?'qz-account__content':'qz-prose'); ?>"><?php the_content(); ?></div>
    <?php endwhile; ?>
</main>
<?php get_footer(); ?>
