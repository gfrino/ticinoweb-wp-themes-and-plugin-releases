<?php
/** Single-product presentation. Native products, gallery, cart and related loop remain authoritative. */
defined('ABSPATH') || exit;

add_action('wp', static function () {
    if(!is_product())return;
    remove_action('woocommerce_after_single_product_summary','woocommerce_output_product_data_tabs',10);
    add_action('woocommerce_after_single_product_summary','qz_product_details',10);
    remove_action('woocommerce_single_product_summary','woocommerce_template_single_meta',40);
    add_action('woocommerce_single_product_summary','qz_product_meta',40);
});

/** Preserve Woo's variation SKU target, leaving it empty until a real code is available. */
function qz_product_meta(){
    global $product;
    if(!$product)return;
    echo '<div class="product_meta">';
    do_action('woocommerce_product_meta_start');
    if(wc_product_sku_enabled()&&($product->get_sku()||$product->is_type('variable'))){
        echo '<span class="sku_wrapper">'.esc_html__('Codice articolo:','qualazampa').' <span class="sku">'.esc_html($product->get_sku()).'</span></span>';
    }
    echo wc_get_product_category_list($product->get_id(),', ','<span class="posted_in">'._n('Categoria:','Categorie:',count($product->get_category_ids()),'qualazampa').' ','</span>'); // Native Woo term links, already escaped.
    do_action('woocommerce_product_meta_end');
    echo '</div>';
}

/** Keep descriptions and specifications readable together, without hidden or empty tab panels. */
function qz_product_details(){
    $tabs=apply_filters('woocommerce_product_tabs',[]);
    $tabs=array_filter($tabs,static fn($tab)=>isset($tab['callback'])&&is_callable($tab['callback']));
    if(!$tabs)return;
    echo '<div class="qz-product-details'.(count($tabs)===1?' qz-product-details--single':'').'">';
    foreach($tabs as $key=>$tab){
        echo '<section class="qz-product-details__section qz-product-details__section--'.esc_attr(sanitize_html_class($key)).'" id="product-'.esc_attr(sanitize_html_class($key)).'">';
        call_user_func($tab['callback'],$key,$tab);
        echo '</section>';
    }
    echo '</div>';
}

add_filter('woocommerce_display_product_attributes',static function($attributes,$product){
    if(!is_product())return $attributes;
    foreach($attributes as $key=>$attribute){
        if(in_array(trim(wp_strip_all_tags($attribute['value'])),['','N/A'],true))unset($attributes[$key]);
    }
    return $attributes;
},10,2);

// Legacy media often has the shop name as its alt; the native gallery can use the product's real name.
add_filter('woocommerce_gallery_image_html_attachment_image_params',static function($params){
    global $product;
    $alt=trim(preg_replace('/Qua la Zampa\s*(?:\|\s*Biasca)?/i','',(string)($params['alt']??'')));
    if(is_product()&&$product&&''===$alt){
        $params['alt']=$product->get_name();
    }
    return $params;
});
