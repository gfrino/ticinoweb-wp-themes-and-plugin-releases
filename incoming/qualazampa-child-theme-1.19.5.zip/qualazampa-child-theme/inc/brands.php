<?php
/** Brand artwork extends native attribute terms; existing Partner logos keep one owner. */
defined('ABSPATH') || exit;
function qz_partner_brand_logos(){
    static $logos=null;if(null!==$logos)return $logos;$logos=[];
    for($i=1;$i<=min(24,(int)get_option('ticinoweb_partner_count',0));$i++){
        $query=[];wp_parse_str((string)wp_parse_url(get_option('ticinoweb_partner_link_'.$i),PHP_URL_QUERY),$query);
        $id=isset($query['qz_brand'])&&is_scalar($query['qz_brand'])?absint($query['qz_brand']):0;
        $logo=get_option('ticinoweb_partner_logo_'.$i);if($id&&$logo)$logos[$id]=$logo;
    }
    return $logos;
}
function qz_brand_logo($term_id){
    $partners=qz_partner_brand_logos();
    return $partners[(int)$term_id]??(int)get_term_meta($term_id,'thumbnail_id',true);
}
function qz_brand_logo_field($term=null){
    $id=$term instanceof WP_Term?$term->term_id:0;$partners=qz_partner_brand_logos();$logo=$id?qz_brand_logo($id):0;
    $content='<div data-brand-logo-field><div data-brand-logo-preview style="width:180px;padding:10px;background:'.($id&&get_term_meta($id,'_qz_logo_dark',true)?'#342627':'transparent').'">';ob_start();if($logo)qz_photo($logo,'medium',['alt'=>'','style'=>'max-width:160px;max-height:100px;object-fit:contain']);$content.=ob_get_clean().'</div>';
    if(isset($partners[$id]))$content.='<p>'.esc_html__('Questo logo è gestito in ticinoWEB CMS → Partner.','qualazampa').'</p>';
    else{
        $content.='<input type="hidden" name="qz_brand_logo" value="'.esc_attr((int)$logo).'">'.wp_nonce_field('qz_brand_logo','qz_brand_logo_nonce',true,false).'<p><button type="button" class="button" data-brand-logo-pick>'.esc_html__('Scegli logo','qualazampa').'</button> <button type="button" class="button" data-brand-logo-remove>'.esc_html__('Rimuovi logo','qualazampa').'</button></p><label><input type="checkbox" name="qz_brand_dark" value="1" '.checked(1,$id?(int)get_term_meta($id,'_qz_logo_dark',true):0,false).'> '.esc_html__('Sfondo scuro per loghi bianchi','qualazampa').'</label>';
    }
    $content.='</div>';
    if($term instanceof WP_Term)echo '<tr class="form-field"><th scope="row">'.esc_html__('Logo marca','qualazampa').'</th><td>'.$content.'</td></tr>';
    else echo '<div class="form-field"><label>'.esc_html__('Logo marca','qualazampa').'</label>'.$content.'</div>';
}
add_action('pa_marche_add_form_fields','qz_brand_logo_field');
add_action('pa_marche_edit_form_fields','qz_brand_logo_field');
function qz_save_brand_logo($term_id){
    if(!current_user_can('manage_product_terms')||!isset($_POST['qz_brand_logo_nonce'],$_POST['qz_brand_logo'])||!is_scalar($_POST['qz_brand_logo_nonce'])||!wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['qz_brand_logo_nonce'])),'qz_brand_logo')||!is_scalar($_POST['qz_brand_logo']))return;
    if(isset(qz_partner_brand_logos()[$term_id]))return;
    $id=absint($_POST['qz_brand_logo']);if($id&&!wp_attachment_is_image($id))return;
    if($id)update_term_meta($term_id,'thumbnail_id',$id);else delete_term_meta($term_id,'thumbnail_id');
    if(isset($_POST['qz_brand_dark']))update_term_meta($term_id,'_qz_logo_dark',1);else delete_term_meta($term_id,'_qz_logo_dark');
}
add_action('created_pa_marche','qz_save_brand_logo');add_action('edited_pa_marche','qz_save_brand_logo');
add_action('admin_enqueue_scripts',static function(){
    $screen=get_current_screen();if(!$screen||'pa_marche'!==$screen->taxonomy)return;
    wp_enqueue_media();wp_enqueue_script('qz-brand-editor',get_stylesheet_directory_uri().'/assets/js/brand-editor.js',[],qz_asset_version('assets/js/brand-editor.js'),true);
    wp_localize_script('qz-brand-editor','qzBrandEditor',['title'=>__('Scegli logo','qualazampa'),'use'=>__('Usa questo logo','qualazampa')]);
});
