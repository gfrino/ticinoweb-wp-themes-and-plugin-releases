<?php
/** Presentation wrapper only: WooCommerce retains every field, calculation and AJAX target. */
defined('ABSPATH') || exit;
// Order emails follow the same logo field as the storefront and login page.
add_filter('pre_option_woocommerce_email_header_image',static function(){
    return ticinoweb_get_site_logo() ?: '';
});
add_action('woocommerce_checkout_before_order_review_heading',static function(){
    if(is_checkout())echo '<aside class="qz-order-panel" aria-labelledby="order_review_heading">';
},5);
add_action('woocommerce_checkout_after_order_review',static function(){
    if(is_checkout())echo '</aside>';
},100);
