<?php
defined('ABSPATH') || exit;
function qz_editor_fields(){return [
    'categories_title'=>__('Titolo reparti','qualazampa'),'categories_text'=>__('Testo reparti','qualazampa'),
    'selection_title'=>__('Titolo prodotti','qualazampa'),'selection_text'=>__('Testo prodotti','qualazampa'),
    'scene_title'=>__('Titolo passaggio fotografico','qualazampa'),'scene_text'=>__('Testo passaggio fotografico','qualazampa'),
    'brands_title'=>__('Titolo marche','qualazampa'),'news_title'=>__('Titolo notizie','qualazampa'),
    'store_title'=>__('Titolo visita in negozio','qualazampa'),'store_text'=>__('Testo visita in negozio','qualazampa'),
    'hero_note'=>__('Nota sotto i pulsanti iniziali','qualazampa'),'footer_text'=>__('Testo del footer','qualazampa'),
    'android_url'=>__('Link Google Play','qualazampa'),'ios_url'=>__('Link App Store','qualazampa'),
    'app_title'=>__('Titolo app','qualazampa'),'app_text'=>__('Testo app','qualazampa'),
];}
add_action('add_meta_boxes_page',static function($post){
    if((int)$post->ID!==(int)get_option('page_on_front'))return;
    add_meta_box('qz-home-editor',__('La home del negozio','qualazampa'),'qz_home_metabox','page','normal','high');
});
function qz_home_metabox($post){
    wp_nonce_field('qz_save_home','qz_home_nonce');
    echo '<p>'.esc_html__('Fotografie e testi della hero: ticinoWEB CMS → Slider. Il testo 1 apre la scena; il testo 2 accompagna la vetrina dopo la trasformazione. Storia, logo e contatti si aggiornano nel CMS. Qui gestisci le sezioni specifiche della home.','qualazampa').'</p>';
    $film=(array)get_post_meta($post->ID,'_qz_hero_film',true);
    foreach(['desktop'=>__('Video hero MP4','qualazampa'),'mobile'=>__('Video leggero per telefono (facoltativo)','qualazampa')] as $format=>$label){
        $attachment=absint($film[$format]??0);$file=$attachment?get_attached_file($attachment):'';
        echo '<div data-film-field data-title="'.esc_attr__('Scegli video','qualazampa').'" data-use="'.esc_attr__('Usa questo video','qualazampa').'"><p><strong>'.esc_html($label).'</strong><br><input type="hidden" name="qz_film_'.esc_attr($format).'" value="'.esc_attr($attachment).'"><span data-film-name>'.esc_html($file?wp_basename($file):'').'</span><br><button class="button" type="button" data-film-pick>'.esc_html__('Scegli video','qualazampa').'</button> <button class="button" type="button" data-film-remove>'.esc_html__('Rimuovi video','qualazampa').'</button></p></div>';
    }
    echo '<p>'.esc_html__('La fotografia della slide 1 resta la copertina. Il video è silenzioso e si ferma fuori schermo; con movimento ridotto o risparmio dati resta la fotografia.','qualazampa').'</p>';
    foreach(qz_editor_fields() as $key=>$label){echo '<p><label><strong>'.esc_html($label).'</strong><br><textarea style="width:100%" rows="2" name="qz_home['.esc_attr($key).']">'.esc_textarea(qz_home($key)).'</textarea></label></p>';}
    $settings=(array)get_post_meta($post->ID,'_qz_home',true);
    $categories=get_terms(['taxonomy'=>'product_cat','hide_empty'=>false]);
    $selected=array_map('absint',explode(',',(string)($settings['category_ids']??'')));
    if(!is_wp_error($categories)){$order=array_flip($selected);usort($categories,static function($a,$b)use($order){return ($order[$a->term_id]??1000000+$a->term_id)<=>($order[$b->term_id]??1000000+$b->term_id);});}
    echo '<p><label><strong>'.esc_html__('Reparti da mostrare nella home','qualazampa').'</strong><br><select name="qz_categories[]" multiple size="8" style="min-width:260px">';
    if(!is_wp_error($categories))foreach($categories as $term)echo '<option value="'.esc_attr($term->term_id).'" '.selected(in_array($term->term_id,$selected,true),true,false).'>'.esc_html($term->name).'</option>';
    echo '</select></label></p><p><label><strong>'.esc_html__('Reparto del passaggio fotografico','qualazampa').'</strong><br><select name="qz_scene_category">';
    if(!is_wp_error($categories))foreach($categories as $term)echo '<option value="'.esc_attr($term->term_id).'" '.selected((int)($settings['scene_category_id']??0),$term->term_id,false).'>'.esc_html($term->name).'</option>';
    echo '</select></label></p><p><label><strong>'.esc_html__('Pagina delle marche','qualazampa').'</strong><br>';
    wp_dropdown_pages(['name'=>'qz_brands_page','selected'=>(int)($settings['brands_page_id']??0),'show_option_none'=>__('Scegli una pagina','qualazampa')]);
    echo '</label></p><p>'.esc_html__('Il collegamento ai contatti usa la pagina Contatti del CMS. Le immagini dei reparti si aggiornano in Prodotti → Categorie.','qualazampa').'</p>';
    $ids=(array)get_post_meta($post->ID,'_qz_selection_ids',true);
    echo '<p><label><strong>'.esc_html__('Prodotti da mostrare nella home','qualazampa').'</strong></label><br><select class="wc-product-search" multiple="multiple" style="width:100%" name="qz_selection[]" data-placeholder="'.esc_attr__('Cerca un prodotto…','qualazampa').'" data-action="woocommerce_json_search_products" data-exclude_type="variation">';
    foreach($ids as $id){$p=wc_get_product($id);if($p)echo '<option selected value="'.esc_attr($id).'">'.esc_html($p->get_formatted_name()).'</option>';}
    echo '</select></p><p>'.esc_html__('La vetrina iniziale mostra fino a 15 prodotti, tre alla volta su desktop. I primi otto compaiono anche nella selezione più sotto. Immagini e prezzi provengono dal catalogo.','qualazampa').'</p>';
}
add_action('admin_enqueue_scripts',static function($hook){if(!in_array($hook,['post.php','post-new.php'],true))return;wp_enqueue_script('wc-enhanced-select');wp_enqueue_style('woocommerce_admin_styles');global $post;if(!$post||(int)$post->ID!==(int)get_option('page_on_front'))return;wp_enqueue_media();wp_enqueue_script('qz-home-editor',get_stylesheet_directory_uri().'/assets/js/home-editor.js',[],qz_asset_version('assets/js/home-editor.js'),true);});
add_action('save_post_page',static function($id){
    if(!isset($_POST['qz_home_nonce'])||!wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['qz_home_nonce'])),'qz_save_home')||!current_user_can('edit_post',$id)||wp_is_post_revision($id)||wp_is_post_autosave($id))return;
    $old=(array)get_post_meta($id,'_qz_home',true);$raw=isset($_POST['qz_home'])&&is_array($_POST['qz_home'])?wp_unslash($_POST['qz_home']):[];
    if((int)$id===(int)get_option('page_on_front')&&isset($_POST['qz_film_desktop'],$_POST['qz_film_mobile'])){
        $film=(array)get_post_meta($id,'_qz_hero_film',true);
        foreach(['desktop','mobile'] as $format)if(is_scalar($_POST['qz_film_'.$format])){$media=absint($_POST['qz_film_'.$format]);if(!$media||('attachment'===get_post_type($media)&&'video/mp4'===get_post_mime_type($media)))$film[$format]=$media;}
        update_post_meta($id,'_qz_hero_film',$film);
    }
    foreach(qz_editor_fields() as $key=>$label){if(isset($raw[$key])&&is_scalar($raw[$key]))$old[$key]=str_ends_with($key,'_url')?esc_url_raw($raw[$key]):sanitize_textarea_field($raw[$key]);}
    if(isset($_POST['qz_categories'])&&is_array($_POST['qz_categories'])){$ids=array_filter(array_map('absint',$_POST['qz_categories']),static function($term_id){return (bool)term_exists($term_id,'product_cat');});$old['category_ids']=implode(',',array_slice($ids,0,20));}
    if(isset($_POST['qz_scene_category'])&&term_exists(absint($_POST['qz_scene_category']),'product_cat'))$old['scene_category_id']=absint($_POST['qz_scene_category']);
    if(isset($_POST['qz_brands_page'])&&'page'===get_post_type(absint($_POST['qz_brands_page'])))$old['brands_page_id']=absint($_POST['qz_brands_page']);
    update_post_meta($id,'_qz_home',$old);
    $ids=isset($_POST['qz_selection'])&&is_array($_POST['qz_selection'])?array_slice(array_map('absint',$_POST['qz_selection']),0,15):[];
    update_post_meta($id,'_qz_selection_ids',array_values(array_filter($ids,static function($id){return 'product'===get_post_type($id);})));
});
