<?php
/** Native menu destinations, grouped into one photographic animal disclosure. */
defined('ABSPATH') || exit;
class QZ_Navigation_Walker extends Walker_Nav_Menu {
    protected $animal_items=[];
    public function walk($elements,$max_depth,...$args){
        if(!$elements)return '';
        $animals=array_values(array_filter($elements,static fn($item)=>'product_cat'===$item->object));
        if(!$animals)return parent::walk($elements,$max_depth,...$args);
        $this->animal_items=$animals;
        $removed=array_fill_keys(array_map(static fn($item)=>(int)$item->ID,$animals),true);
        // Absorb an old section-link wrapper only when every child is already grouped.
        do{$changed=false;foreach($elements as $item){
            if(isset($removed[$item->ID])||'custom'!==$item->type||!wp_parse_url($item->url,PHP_URL_FRAGMENT))continue;
            $children=array_filter($elements,static fn($child)=>(int)$child->menu_item_parent===(int)$item->ID);
            if($children&&!array_filter($children,static fn($child)=>!isset($removed[$child->ID]))){$removed[$item->ID]=true;$changed=true;}
        }}while($changed);
        $group=clone $animals[0];$group->object='qz_animals';$group->menu_item_parent=0;
        $grouped=[];foreach($elements as $item){if((int)$item->ID===(int)$animals[0]->ID)$grouped[]=$group;if(!isset($removed[$item->ID]))$grouped[]=$item;}
        return parent::walk($grouped,$max_depth,...$args);
    }
    public function start_el(&$output,$data_object,$depth=0,$args=null,$current_object_id=0){
        if('qz_animals'!==$data_object->object){parent::start_el($output,$data_object,$depth,$args,$current_object_id);return;}
        ob_start(); ?>
        <li class="qz-menu__animals"><details class="qz-animal-menu" data-animal-menu>
            <summary aria-controls="qz-animal-panel"><span><?php esc_html_e('Animali','qualazampa'); ?></span><?php echo qz_icon('chevron'); ?></summary>
            <div class="qz-mega" id="qz-animal-panel" data-animal-panel data-lenis-prevent>
                <div class="qz-container qz-mega__inner">
                    <div class="qz-mega__intro"><?php qz_title(qz_home('categories_title'),'h2','qz-mega__title'); ?><p><?php echo esc_html(qz_home('categories_text')); ?></p></div>
                    <ul class="qz-mega__animals"><?php qz_menu_animals($this->animal_items); ?></ul>
                </div>
            </div>
        </details><?php $output.=ob_get_clean();
    }
}
function qz_menu_animals($items){
    $terms=get_terms(['taxonomy'=>'product_cat','hide_empty'=>false,'include'=>array_map(static fn($item)=>(int)$item->object_id,$items)]);
    $terms=is_wp_error($terms)?[]:array_column($terms,null,'term_id');
    $photos=[];foreach($terms as $term){$id=(int)get_term_meta($term->term_id,'thumbnail_id',true);if($id)$photos[]=$id;}
    if($photos)get_posts(['post_type'=>'attachment','post_status'=>'inherit','post__in'=>$photos,'posts_per_page'=>count($photos),'update_post_term_cache'=>false]);
    foreach($items as $index=>$item){$term=$terms[(int)$item->object_id]??null;$id=$term?(int)get_term_meta($term->term_id,'thumbnail_id',true):0; ?>
        <li style="--animal-order:<?php echo esc_attr($index); ?>"><a class="qz-mega__animal" href="<?php echo esc_url($item->url); ?>"<?php if($term&&is_product_category($term->term_id))echo ' aria-current="page"'; ?>>
            <span class="qz-mega__portrait" aria-hidden="true"><?php if($id)qz_photo($id,'medium',['alt'=>'','loading'=>'lazy','sizes'=>'(max-width:760px) 76px, 108px']);else echo qz_icon('paw'); ?></span>
            <span class="qz-mega__name"><?php echo esc_html($item->title); ?></span>
            <?php if($term): ?><span class="qz-mega__count"><?php /* translators: %s: Product count. */ echo esc_html(sprintf(_n('%s prodotto','%s prodotti',$term->count,'qualazampa'),number_format_i18n($term->count))); ?></span><?php endif; ?>
        </a></li>
    <?php }
}
