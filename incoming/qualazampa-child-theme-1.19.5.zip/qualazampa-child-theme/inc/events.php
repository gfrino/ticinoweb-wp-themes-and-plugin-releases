<?php
/** Store appointments: native legacy event records, registered by the parent CMS. */
defined('ABSPATH') || exit;

// The parent remains the only CPT registrar. Retain the old records and simplify their editor.
add_filter('register_post_type_args', static function ($args, $type) {
    if ('mec-events' !== $type) return $args;
    $args['supports'] = ['title', 'editor', 'thumbnail', 'revisions'];
    $args['show_in_rest'] = false;
    $args['rewrite'] = ['slug' => 'eventi', 'with_front' => false];
    $args['has_archive'] = false;
    return $args;
}, 20, 2);

add_action('admin_menu', static function () {
    if (!post_type_exists('mec-events')) return;
    remove_menu_page('edit.php?post_type=mec-events');
    add_submenu_page('ticinoweb-cms', __('Eventi', 'qualazampa'), __('Eventi', 'qualazampa'), 'edit_posts', 'edit.php?post_type=mec-events');
}, 100);
add_filter('parent_file', static function ($parent) {
    global $typenow;
    return 'mec-events' === $typenow ? 'ticinoweb-cms' : $parent;
});
add_filter('enter_title_here', static function ($title, $post) {
    return 'mec-events' === $post->post_type ? __('Titolo dell’evento', 'qualazampa') : $title;
}, 10, 2);

function qz_event_date($value) {
    if (!is_string($value)) return false;
    $date = DateTimeImmutable::createFromFormat('!Y-m-d', $value, wp_timezone());
    return $date && $date->format('Y-m-d') === $value ? $date : false;
}
function qz_event_time($value) {
    return is_string($value) && (bool) preg_match('/^(?:[01][0-9]|2[0-3]):[0-5][0-9]$/D', $value);
}
function qz_event_validate($raw) {
    $data = [];
    foreach (['start_date', 'end_date', 'start_time', 'end_time', 'place', 'organizer', 'link'] as $key) {
        if (isset($raw[$key]) && !is_scalar($raw[$key])) return new WP_Error('fields', __('Controlla i campi dell’evento.', 'qualazampa'));
        $data[$key] = sanitize_text_field((string) ($raw[$key] ?? ''));
    }
    $data['end_date'] = $data['end_date'] ?: $data['start_date'];
    $start = qz_event_date($data['start_date']);
    $end = qz_event_date($data['end_date']);
    if (!$start || !$end) return new WP_Error('dates', __('Inserisci una data di inizio valida.', 'qualazampa'));
    if ($end < $start) return new WP_Error('dates', __('La fine dell’evento non può precedere l’inizio.', 'qualazampa'));
    foreach (['start_time', 'end_time'] as $key) {
        if ($data[$key] && !qz_event_time($data[$key])) return new WP_Error('times', __('Controlla gli orari dell’evento.', 'qualazampa'));
    }
    if ($data['end_time'] && !$data['start_time']) return new WP_Error('times', __('Inserisci anche l’ora di inizio, oppure lascia entrambi gli orari vuoti.', 'qualazampa'));
    if ($data['end_time'] && $end == $start && $data['end_time'] <= $data['start_time']) return new WP_Error('times', __('L’ora di fine deve essere successiva all’inizio.', 'qualazampa'));
    if ($data['link']) {
        $data['link'] = esc_url_raw($data['link'], ['http', 'https']);
        if (!$data['link'] || !wp_parse_url($data['link'], PHP_URL_HOST)) return new WP_Error('link', __('Inserisci un collegamento completo e valido, oppure lascialo vuoto.', 'qualazampa'));
    }
    return $data;
}
function qz_event_input_time($id, $edge) {
    if (get_post_meta($id, 'mec_allday', true) || ('end' === $edge && get_post_meta($id, 'mec_hide_end_time', true))) return '';
    $hour = get_post_meta($id, 'mec_'.$edge.'_time_hour', true);
    if ('' === $hour) return '';
    $hour = (int) $hour;
    $ampm = strtoupper((string) get_post_meta($id, 'mec_'.$edge.'_time_ampm', true));
    if (in_array($ampm, ['AM', 'PM'], true)) $hour = $hour % 12 + ('PM' === $ampm ? 12 : 0);
    return sprintf('%02d:%02d', $hour, (int) get_post_meta($id, 'mec_'.$edge.'_time_minutes', true));
}
function qz_event_fields($id) {
    return [
        'start_date' => (string) get_post_meta($id, 'mec_start_date', true),
        'end_date' => (string) get_post_meta($id, 'mec_end_date', true),
        'start_time' => qz_event_input_time($id, 'start'),
        'end_time' => qz_event_input_time($id, 'end'),
        'place' => (string) get_post_meta($id, '_qz_event_place', true),
        'organizer' => (string) get_post_meta($id, '_qz_event_organizer', true),
        'link' => (string) get_post_meta($id, 'mec_more_info', true),
    ];
}
function qz_event_write($id, $data) {
    // Keep MEC's native date representation, including its own derived time indexes.
    $date = ['allday' => $data['start_time'] ? '0' : '1'];
    foreach (['start', 'end'] as $edge) {
        $time = $data[$edge.'_time'] ?: ('end' === $edge ? '23:59' : '00:00');
        [$hour, $minute] = array_map('intval', explode(':', $time));
        $part = ['date' => $data[$edge.'_date'], 'hour' => (string) ($hour % 12 ?: 12), 'minutes' => (string) $minute, 'ampm' => $hour >= 12 ? 'PM' : 'AM'];
        $date[$edge] = $part;
        update_post_meta($id, 'mec_'.$edge.'_date', $part['date']);
        update_post_meta($id, 'mec_'.$edge.'_time_hour', $part['hour']);
        update_post_meta($id, 'mec_'.$edge.'_time_minutes', $part['minutes']);
        update_post_meta($id, 'mec_'.$edge.'_time_ampm', $part['ampm']);
        update_post_meta($id, 'mec_'.$edge.'_day_seconds', $hour * 3600 + $minute * 60);
        update_post_meta($id, 'mec_'.$edge.'_datetime', $part['date'].' '.sprintf('%02d:%02d', (int) $part['hour'], $minute).' '.$part['ampm']);
    }
    update_post_meta($id, 'mec_date', $date);
    update_post_meta($id, 'mec_allday', $date['allday']);
    update_post_meta($id, 'mec_hide_end_time', $data['end_time'] ? '0' : '1');
    foreach (['place', 'organizer'] as $key) {
        if ($data[$key]) update_post_meta($id, '_qz_event_'.$key, $data[$key]);
        else delete_post_meta($id, '_qz_event_'.$key);
    }
    if ($data['link']) update_post_meta($id, 'mec_more_info', $data['link']);
    else delete_post_meta($id, 'mec_more_info');
    qz_event_refresh($id);
}

add_action('add_meta_boxes_mec-events', static function () {
    add_meta_box('qz-event-details', __('Quando e dove', 'qualazampa'), 'qz_event_metabox', 'mec-events', 'normal', 'high');
});
function qz_event_metabox($post) {
    $data = qz_event_fields($post->ID);
    wp_nonce_field('qz_save_event', 'qz_event_nonce');
    echo '<p>'.esc_html__('Pubblica l’evento per annunciarlo in home. Sarà visibile fino alla fine indicata; le bozze e gli eventi terminati restano nascosti. La data di pubblicazione di WordPress non è la data dell’appuntamento.', 'qualazampa').'</p>';
    echo '<table class="form-table" role="presentation"><tbody>';
    foreach ([
        'start_date' => [__('Data di inizio', 'qualazampa'), 'date'],
        'end_date' => [__('Data di fine (facoltativa)', 'qualazampa'), 'date'],
        'start_time' => [__('Ora di inizio (facoltativa)', 'qualazampa'), 'time'],
        'end_time' => [__('Ora di fine (facoltativa)', 'qualazampa'), 'time'],
        'place' => [__('Luogo (facoltativo)', 'qualazampa'), 'text'],
        'organizer' => [__('Organizzatore o marca (facoltativo)', 'qualazampa'), 'text'],
        'link' => [__('Collegamento esterno (facoltativo)', 'qualazampa'), 'url'],
    ] as $key => $field) {
        echo '<tr><th scope="row"><label for="qz-event-'.esc_attr($key).'">'.esc_html($field[0]).'</label></th><td><input class="regular-text" type="'.esc_attr($field[1]).'" id="qz-event-'.esc_attr($key).'" name="qz_event['.esc_attr($key).']" value="'.esc_attr($data[$key]).'"'.('start_date' === $key ? ' required' : '').'>';
        if ('end_date' === $key) echo '<p class="description">'.esc_html__('Se vuota, l’evento dura un solo giorno.', 'qualazampa').'</p>';
        if ('end_time' === $key) echo '<p class="description">'.esc_html__('Senza orari mostriamo solo le date. Senza un’ora di fine, l’evento resta visibile fino a fine giornata.', 'qualazampa').'</p>';
        if ('place' === $key) echo '<p class="description">'.esc_html__('Se vuoto, usiamo l’indirizzo del negozio già presente nel CMS.', 'qualazampa').'</p>';
        echo '</td></tr>';
    }
    echo '</tbody></table><p>'.esc_html__('Il titolo e la descrizione si compilano nei campi della pagina. La foto si sceglie in Immagine in evidenza.', 'qualazampa').'</p>';
}
function qz_event_submission() {
    if (!isset($_POST['qz_event_nonce']) || !is_scalar($_POST['qz_event_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['qz_event_nonce'])), 'qz_save_event')) return null;
    if (!isset($_POST['qz_event']) || !is_array($_POST['qz_event'])) return new WP_Error('fields');
    return qz_event_validate(wp_unslash($_POST['qz_event']));
}
add_filter('wp_insert_post_data', static function ($data, $postarr) {
    if ('mec-events' !== $data['post_type'] || !current_user_can('edit_post', absint($postarr['ID'] ?? 0))) return $data;
    $fields = qz_event_submission();
    if ((is_wp_error($fields) || (is_array($fields) && !trim(wp_strip_all_tags($data['post_title'])))) && !in_array($data['post_status'], ['auto-draft', 'trash'], true)) $data['post_status'] = 'draft';
    return $data;
}, 20, 2);
add_action('save_post_mec-events', static function ($id) {
    if (!current_user_can('edit_post', $id) || wp_is_post_revision($id) || wp_is_post_autosave($id)) return;
    $data = qz_event_submission();
    if (null === $data) { qz_event_refresh($id); return; }
    if (is_wp_error($data) || !trim(get_post_field('post_title', $id))) {
        add_filter('redirect_post_location', static fn($url) => add_query_arg('qz_event_invalid', '1', $url));
        return;
    }
    qz_event_write($id, $data);
});
add_action('admin_notices', static function () {
    $screen = get_current_screen();
    if (!$screen || 'mec-events' !== $screen->post_type) return;
    if (isset($_GET['qz_event_invalid'])) echo '<div class="notice notice-error"><p>'.esc_html__('Evento salvato come bozza: controlla il titolo, le date, gli orari e il collegamento. La fine deve seguire l’inizio. Non verrà mostrato in home finché i dati non sono validi e l’evento non viene pubblicato.', 'qualazampa').'</p></div>';
    if ('edit' === $screen->base) echo '<div class="notice notice-info"><p>'.esc_html__('Qui trovi anche gli eventi del vecchio sito, conservati in bozza. Per mostrarne uno: aprilo, controlla la data e premi Pubblica. Gli eventi terminati scompaiono automaticamente dalla home.', 'qualazampa').'</p></div>';
    if (get_post_meta(get_the_ID(), '_qz_event_demo', true)) echo '<div class="notice notice-warning"><p>'.esc_html__('Questo è un evento dimostrativo, non un appuntamento reale. Puoi spostarlo nel cestino dopo la prova.', 'qualazampa').'</p></div>';
});
add_filter('manage_mec-events_posts_columns', static function ($columns) {
    unset($columns['date']);
    $columns['qz_event_when'] = __('Date dell’evento', 'qualazampa');
    $columns['qz_event_visibility'] = __('In home', 'qualazampa');
    return $columns;
});
add_action('manage_mec-events_posts_custom_column', static function ($column, $id) {
    if ('qz_event_when' === $column) echo esc_html(qz_event_date_label($id));
    if ('qz_event_visibility' === $column) echo esc_html(qz_event_visible($id) ? __('Visibile', 'qualazampa') : __('Nascosto', 'qualazampa'));
}, 10, 2);

function qz_event_bounds($id) {
    $start = qz_event_date(get_post_meta($id, 'mec_start_date', true));
    $end = qz_event_date(get_post_meta($id, 'mec_end_date', true)) ?: $start;
    if (!$start || !$end || $end < $start) return false;
    $all_day = (bool) get_post_meta($id, 'mec_allday', true);
    $a = $all_day ? '00:00' : (qz_event_input_time($id, 'start') ?: '00:00');
    $b = $all_day ? '23:59' : (qz_event_input_time($id, 'end') ?: '23:59');
    return [$start->setTime((int) substr($a, 0, 2), (int) substr($a, 3, 2)), $end->setTime((int) substr($b, 0, 2), (int) substr($b, 3, 2), 59)];
}
function qz_event_visible($id, $now = null) {
    $bounds = qz_event_bounds($id);
    return 'publish' === get_post_status($id) && !get_post_field('post_password', $id) && trim(get_post_field('post_title', $id)) && $bounds && $bounds[1] >= ($now ?: current_datetime());
}
function qz_upcoming_events($limit = 6, $now = null) {
    if (!post_type_exists('mec-events')) return [];
    $now = $now ?: current_datetime();
    $day = $now->format('Y-m-d');
    $seconds = (int) $now->format('H') * 3600 + (int) $now->format('i') * 60;
    $events = get_posts([
        'post_type' => 'mec-events', 'post_status' => 'publish', 'has_password' => false, 'posts_per_page' => min(12, max(1, (int) $limit)),
        'meta_key' => 'mec_start_date', 'orderby' => ['meta_value' => 'ASC', 'ID' => 'ASC'], 'no_found_rows' => true, 'suppress_filters' => false,
        'meta_query' => ['relation' => 'OR',
            ['key' => 'mec_end_date', 'value' => $day, 'compare' => '>', 'type' => 'DATE'],
            ['relation' => 'AND', ['key' => 'mec_end_date', 'value' => $day, 'compare' => '=', 'type' => 'DATE'],
                ['relation' => 'OR', ['key' => 'mec_allday', 'value' => '1'], ['key' => 'mec_end_day_seconds', 'value' => $seconds, 'compare' => '>=', 'type' => 'NUMERIC']]],
        ],
    ]);
    return array_values(array_filter($events, static fn($event) => qz_event_visible($event->ID, $now)));
}
function qz_event_date_label($id) {
    $bounds = qz_event_bounds($id);
    if (!$bounds) return '';
    $label = wp_date('j F Y', $bounds[0]->getTimestamp());
    if ($bounds[0]->format('Y-m-d') !== $bounds[1]->format('Y-m-d')) $label .= ' – '.wp_date('j F Y', $bounds[1]->getTimestamp());
    return $label;
}
function qz_event_time_label($id) {
    $start = qz_event_input_time($id, 'start');
    $end = qz_event_input_time($id, 'end');
    return $start ? $start.($end ? ' – '.$end : '') : '';
}
function qz_event_text($id, $key) {
    $value = (string) get_post_meta($id, '_qz_event_'.$key, true);
    return function_exists('ticinoweb_frontend_text') ? ticinoweb_frontend_text($value, 'qz:event:'.$id.':'.$key) : $value;
}
function qz_event_place($id) {
    return qz_event_text($id, 'place') ?: qz_option('ticinoweb_contact_address');
}
function qz_event_refresh($id) {
    wp_clear_scheduled_hook('qz_event_boundary', [$id]);
    $bounds = qz_event_bounds($id);
    if ('publish' === get_post_status($id) && $bounds && $bounds[1]->getTimestamp() >= time()) wp_schedule_single_event($bounds[1]->getTimestamp() + 1, 'qz_event_boundary', [$id]);
    do_action('litespeed_purge_url', home_url('/'));
}
add_action('qz_event_boundary', static function ($id) { clean_post_cache($id); do_action('litespeed_purge_url', home_url('/')); });
add_action('transition_post_status', static function ($new, $old, $post) { if ('mec-events' === $post->post_type && $new !== $old) qz_event_refresh($post->ID); }, 10, 3);
add_action('before_delete_post', static function ($id, $post) { if ('mec-events' === $post->post_type) { wp_clear_scheduled_hook('qz_event_boundary', [$id]); do_action('litespeed_purge_url', home_url('/')); } }, 10, 2);

function qz_event_demo_note($id) {
    if (get_post_meta($id, '_qz_event_demo', true)) echo '<p class="qz-event__demo">'.esc_html__('Evento dimostrativo · non è un appuntamento reale', 'qualazampa').'</p>';
}
function qz_render_events() {
    $events = qz_upcoming_events();
    if (!$events) return;
    ?>
    <section class="qz-events qz-section" aria-labelledby="qz-events-title"><div class="qz-container">
        <div class="qz-section-heading"><h2 id="qz-events-title"><?php esc_html_e('I prossimi appuntamenti', 'qualazampa'); ?></h2></div>
        <div class="qz-events__list">
        <?php foreach ($events as $event): $id = $event->ID; $bounds = qz_event_bounds($id); $image = get_post_thumbnail_id($id); ?>
            <article class="qz-event<?php if (!$image) echo ' qz-event--no-image'; ?>">
                <div class="qz-event__date" aria-label="<?php echo esc_attr(qz_event_date_label($id)); ?>"><span><?php echo esc_html(wp_date('d', $bounds[0]->getTimestamp())); ?></span><time datetime="<?php echo esc_attr($bounds[0]->format('Y-m-d')); ?>"><?php echo esc_html(wp_date('M Y', $bounds[0]->getTimestamp())); ?></time></div>
                <?php if ($image): ?><a class="qz-event__photo" href="<?php echo esc_url(get_permalink($id)); ?>" tabindex="-1" aria-hidden="true"><?php qz_photo($image, 'large', ['alt' => '', 'sizes' => '(max-width:760px) 90vw, 30vw']); ?></a><?php endif; ?>
                <div class="qz-event__copy"><?php qz_event_demo_note($id); ?><h3><a href="<?php echo esc_url(get_permalink($id)); ?>"><?php echo esc_html(get_the_title($id)); ?></a></h3>
                    <p class="qz-event__when"><?php echo esc_html(qz_event_date_label($id)); ?><?php $hours = qz_event_time_label($id); if ($hours) echo ' · '.esc_html($hours); ?></p>
                    <?php if (qz_event_place($id)): ?><p class="qz-event__place"><?php echo qz_icon('pin'); echo esc_html(qz_event_place($id)); ?></p><?php endif; ?>
                    <?php $summary = wp_trim_words(wp_strip_all_tags($event->post_excerpt ?: $event->post_content), 36); if (function_exists('ticinoweb_frontend_text')) $summary = ticinoweb_frontend_text($summary, 'qz:event:'.$id.':summary'); if ($summary): ?><p><?php echo esc_html($summary); ?></p><?php endif; ?>
                    <a class="qz-button" href="<?php echo esc_url(get_permalink($id)); ?>"><?php esc_html_e('Scopri l’evento', 'qualazampa'); ?></a>
                </div>
            </article>
        <?php endforeach; ?>
        </div>
    </div></section>
    <?php
}
add_filter('wp_robots', static function ($robots) {
    if (is_singular('mec-events') && get_post_meta(get_queried_object_id(), '_qz_event_demo', true)) { $robots['noindex'] = true; $robots['nofollow'] = true; }
    return $robots;
});
add_filter('wp_sitemaps_posts_query_args', static function ($args, $type) {
    if ('mec-events' === $type) $args['meta_query'][] = ['key' => '_qz_event_demo', 'compare' => 'NOT EXISTS'];
    return $args;
}, 10, 2);
