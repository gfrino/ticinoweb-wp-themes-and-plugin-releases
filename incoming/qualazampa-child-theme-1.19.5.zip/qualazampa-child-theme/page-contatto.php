<?php
/* Template Name: Contatti del negozio */
defined('ABSPATH') || exit;
$address=qz_option('ticinoweb_contact_address');
$phone=preg_replace('/[^+0-9]/','',(string)get_option('ticinoweb_contact_phone',''));
$phone_display=qz_option('ticinoweb_contact_phone_display')?:$phone;
$email=sanitize_email(get_option('ticinoweb_contact_email',''));
$hours=(array)get_option('ticinoweb_contact_opening_hours',[]);
$note=qz_option('ticinoweb_contact_opening_hours_note');
$map=esc_url(get_option('ticinoweb_contact_map_url',''));
if(!$map&&$address)$map='https://www.google.com/maps/dir/?api=1&destination='.rawurlencode($address);
$social=[];
foreach(['facebook'=>'Facebook','instagram'=>'Instagram'] as $key=>$label){$url=esc_url(get_option('ticinoweb_contact_'.$key,''));if($url)$social[$label]=$url;}
get_header();
?>
<main id="main-content" class="qz-contact">
    <?php while(have_posts()):the_post();
        $photo=get_post_thumbnail_id();
        if(!$photo)$photo=attachment_url_to_postid(qz_option('ticinoweb_chi_siamo_image'));
        $photo=$photo&&wp_attachment_is_image($photo)?$photo:0;
    ?>
    <section class="qz-contact-opening qz-container<?php echo $photo?'':' qz-contact-opening--text'; ?>" aria-labelledby="qz-contact-title">
        <div class="qz-contact-opening__copy">
            <h1 id="qz-contact-title"><?php the_title(); ?></h1>
            <div class="qz-contact-intro"><?php the_content(); ?></div>
            <?php if($phone||$email): ?>
            <dl class="qz-contact-methods">
                <?php if($phone): ?><div><dt><?php esc_html_e('Chiamaci','qualazampa'); ?></dt><dd><a href="<?php echo esc_url('tel:'.$phone); ?>"><?php echo esc_html($phone_display); ?></a></dd></div><?php endif; ?>
                <?php if($email): ?><div><dt><?php esc_html_e('Scrivici via email','qualazampa'); ?></dt><dd><a href="<?php echo esc_url('mailto:'.$email); ?>"><?php echo esc_html($email); ?></a></dd></div><?php endif; ?>
            </dl>
            <?php endif; ?>
        </div>
        <?php if($photo): ?><figure class="qz-contact-photo"><?php echo wp_get_attachment_image($photo,'large',false,['loading'=>'eager','fetchpriority'=>'high','sizes'=>'(max-width: 760px) calc(100vw - 36px), 50vw']); ?></figure><?php endif; ?>
    </section>
    <?php if($address||$hours): ?>
    <section class="qz-contact-visit" aria-label="<?php esc_attr_e('Visita il negozio','qualazampa'); ?>">
        <div class="qz-container qz-contact-visit__layout">
            <?php if($address): ?>
            <div class="qz-contact-address">
                <h2><?php esc_html_e('Ci trovi qui.','qualazampa'); ?></h2>
                <address><?php echo nl2br(esc_html($address)); ?></address>
                <?php if($map): ?><a class="qz-button" href="<?php echo esc_url($map); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e('Indicazioni stradali','qualazampa'); ?><span class="screen-reader-text"> <?php esc_html_e('(si apre in una nuova scheda)','qualazampa'); ?></span></a><?php endif; ?>
                <?php if($social): ?><div class="qz-contact-social"><p><?php esc_html_e('Rimaniamo vicini.','qualazampa'); ?></p><div><?php foreach($social as $label=>$url): ?><a href="<?php echo esc_url($url); ?>" target="_blank" rel="noopener noreferrer" aria-label="<?php echo esc_attr($label.' '.__('(si apre in una nuova scheda)','qualazampa')); ?>"><?php echo esc_html($label); ?></a><?php endforeach; ?></div></div><?php endif; ?>
            </div>
            <?php endif; ?>
            <?php if($hours): ?>
            <div class="qz-contact-hours"><h2><?php esc_html_e('I nostri orari','qualazampa'); ?></h2><?php qz_hours(); ?><?php if($note): ?><p class="qz-contact-hours__note"><?php echo esc_html($note); ?></p><?php endif; ?></div>
            <?php endif; ?>
        </div>
    </section>
    <?php endif; ?>
    <?php endwhile; ?>
</main>
<?php get_footer(); ?>
