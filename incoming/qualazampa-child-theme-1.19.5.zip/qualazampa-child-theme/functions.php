<?php
/** Presentation only; products and common CMS services remain owned by WooCommerce and the parent. */
defined('ABSPATH') || exit;
define('QZ_VERSION', wp_get_theme()->get('Version'));
// Local previews must pick up each edit while the published updater keeps the theme version.
function qz_asset_version($asset){
    $host=wp_parse_url(home_url('/'),PHP_URL_HOST);
    $file=get_stylesheet_directory().'/'.$asset;
    return in_array($host,['localhost','127.0.0.1','::1'],true)&&is_file($file)?QZ_VERSION.'.'.filemtime($file):QZ_VERSION;
}
require_once __DIR__.'/inc/content.php';
require_once __DIR__.'/inc/home-editor.php';
require_once __DIR__.'/inc/shop.php';
require_once __DIR__.'/inc/brands.php';
require_once __DIR__.'/inc/navigation.php';
require_once __DIR__.'/inc/about.php';
require_once __DIR__.'/inc/commerce.php';
require_once __DIR__.'/inc/product.php';
require_once __DIR__.'/inc/events.php';
add_action('after_setup_theme', static function () {
    load_child_theme_textdomain('qualazampa', get_stylesheet_directory().'/languages');
    register_nav_menus(['qz_footer'=>__('Menu informazioni', 'qualazampa')]);
    remove_action('wp_enqueue_scripts','ticinoweb_ai_assets');
    add_post_type_support('page','excerpt');
}, 100);
add_action('wp_enqueue_scripts', static function () {
    $uri=get_stylesheet_directory_uri();
    wp_enqueue_style('qz-site',$uri.'/assets/css/site.css',[],qz_asset_version('assets/css/site.css'));
    $palette=['ticinoweb_palette_primary'=>'--qz-orange','ticinoweb_palette_suggested_1'=>'--qz-paper','ticinoweb_palette_suggested_2'=>'--qz-lilac','ticinoweb_palette_suggested_3'=>'--qz-ink'];
    $variables='';foreach($palette as $key=>$property){$color=sanitize_hex_color(get_option($key,''));if($color)$variables.=$property.':'.$color.';';}
    foreach(['ticinoweb_font_headings'=>'--qz-heading','ticinoweb_font_subheadings'=>'--qz-subheading','ticinoweb_font_body'=>'--qz-body'] as $key=>$property){$available=['Bricolage Grotesque'=>'Bricolage','Figtree'=>'Figtree'];$choice=(string)get_option($key,'');$font=$available[$choice]??($key==='ticinoweb_font_body'?'Figtree':'Bricolage');$variables.=$property.':"'.$font.'",sans-serif;';}
    if($variables)wp_add_inline_style('qz-site',':root{'.$variables.'}');
    wp_enqueue_script('qz-site',$uri.'/assets/js/site.js',[],qz_asset_version('assets/js/site.js'),true);
    if(qz_is_about()){
        wp_enqueue_style('qz-about',$uri.'/assets/css/about.css',['qz-site'],qz_asset_version('assets/css/about.css'));
        wp_enqueue_script('qz-about',$uri.'/assets/js/about.js',[],qz_asset_version('assets/js/about.js'),true);
    }
    if(is_page_template('page-contatto.php'))wp_enqueue_style('qz-contact',$uri.'/assets/css/contact.css',['qz-site'],qz_asset_version('assets/css/contact.css'));
    if(is_cart()||is_checkout())wp_enqueue_style('qz-commerce',$uri.'/assets/css/commerce.css',['qz-site'],qz_asset_version('assets/css/commerce.css'));
    if(is_account_page())wp_enqueue_style('qz-account',$uri.'/assets/css/account.css',['qz-site'],qz_asset_version('assets/css/account.css'));
    if(is_product())wp_enqueue_style('qz-product',$uri.'/assets/css/product.css',['qz-site'],qz_asset_version('assets/css/product.css'));
    wp_enqueue_script('qz-lenis',$uri.'/assets/vendor/lenis.min.js',[],QZ_VERSION,true);
    if(!is_front_page())wp_enqueue_script('qz-scroll',$uri.'/assets/js/scroll.js',['qz-lenis'],qz_asset_version('assets/js/scroll.js'),true);
    if(is_shop()||is_product_taxonomy()){
        wp_enqueue_style('qz-shop',$uri.'/assets/css/shop.css',['qz-site'],qz_asset_version('assets/css/shop.css'));
        wp_enqueue_script('qz-facet-model',$uri.'/assets/js/facet-model.js',[],qz_asset_version('assets/js/facet-model.js'),true);
        wp_enqueue_script('qz-shop',$uri.'/assets/js/shop.js',['qz-facet-model'],qz_asset_version('assets/js/shop.js'),true);
        wp_localize_script('qz-shop','qzShop',['search'=>__('Cerca tra le opzioni','qualazampa'),'empty'=>__('Nessuna opzione trovata','qualazampa'),'sort'=>__('Ordina per','qualazampa'),'updated'=>__('Opzioni aggiornate in base ai filtri selezionati.','qualazampa'),'cleared'=>__('Opzioni aggiornate; le selezioni non più compatibili sono state rimosse.','qualazampa')]);
    }
    if(function_exists('WC')) wp_enqueue_script('wc-cart-fragments');
    if(is_singular('mec-events')||(is_front_page()&&qz_upcoming_events()))wp_enqueue_style('qz-events',$uri.'/assets/css/events.css',['qz-site'],qz_asset_version('assets/css/events.css'));
    if(is_front_page()) {
        wp_enqueue_style('qz-home',$uri.'/assets/css/home.css',['qz-site'],qz_asset_version('assets/css/home.css'));
        wp_enqueue_script('qz-animal-motion',$uri.'/assets/js/animal-motion.js',[],qz_asset_version('assets/js/animal-motion.js'),true);
        wp_enqueue_script('qz-hero-video',$uri.'/assets/js/hero-video.js',[],qz_asset_version('assets/js/hero-video.js'),true);
        wp_enqueue_script('qz-home',$uri.'/assets/js/home.js',['qz-lenis','qz-animal-motion'],qz_asset_version('assets/js/home.js'),true);
    }
},30);
add_action('wp_head',static function(){
    // Remove the Home header's layout slot before first paint; no-JS keeps ordinary navigation.
    if(is_front_page())echo '<script>document.documentElement.setAttribute("data-qz-opening-nav","");document.documentElement.setAttribute("data-qz-hero-header","");</script>';
    echo '<link rel="preload" as="font" type="font/ttf" crossorigin href="'.esc_url(get_stylesheet_directory_uri().'/assets/fonts/bricolage-700.ttf').'">';
},2);
add_filter('body_class',static function($classes){$classes[]='qz-site';return $classes;});
add_filter('woocommerce_add_to_cart_fragments',static function($fragments){ob_start();qz_cart_link();$fragments['a.qz-cart']=ob_get_clean();return $fragments;});
// Carry existing per-product SEO values into the parent's single SEO owner.
add_filter('get_post_metadata',static function($value,$id,$key,$single){
    static $reading=false;
    if($reading)return $value;
    $map=['_tw_seo_title'=>'_seopress_titles_title','_tw_seo_description'=>'_seopress_titles_desc'];
    if(null!==$value || !isset($map[$key]) || 'product'!==get_post_type($id))return $value;
    $reading=true;
    $native=get_post_meta($id,$key,$single);
    $reading=false;
    if(false!==$native && ''!==$native && null!==$native)return $value;
    $legacy=get_post_meta($id,$map[$key],true);
    return $legacy ? ($single?$legacy:[$legacy]) : $value;
},10,4);

// Extend the existing parent font selectors with the self-hosted theme faces.
add_action('admin_enqueue_scripts',static function(){
    wp_enqueue_script('qz-editor',get_stylesheet_directory_uri().'/assets/js/editor.js',[],QZ_VERSION,true);
    wp_localize_script('qz-editor','qzEditorFonts',[
        'headings'=>(string)get_option('ticinoweb_font_headings',''),
        'subheadings'=>(string)get_option('ticinoweb_font_subheadings',''),
        'body'=>(string)get_option('ticinoweb_font_body',''),
    ]);
});
