(function(root){
  'use strict';
  const slots={qz_animal:0,qz_brand:1,qz_kind:2};
  class QZFacetModel{
    constructor(rows){this.rows=rows;}
    available(state,own){
      const choices=new Set();
      for(const row of this.rows){
        if(state.qz_stock&&!row[3])continue;
        if(Object.entries(slots).some(([key,slot])=>key!==own&&state[key]&&!row[slot].includes(Number(state[key]))))continue;
        row[slots[own]].forEach(id=>choices.add(String(id)));
      }
      return choices;
    }
    reconcile(state,changed){
      const next={...state};
      for(const key of Object.keys(slots))if(key!==changed&&next[key]&&!this.available(next,key).has(String(next[key])))next[key]='';
      return next;
    }
  }
  if(typeof module==='object'&&module.exports)module.exports=QZFacetModel;
  else root.QZFacetModel=QZFacetModel;
})(typeof window==='undefined'?{}:window);
