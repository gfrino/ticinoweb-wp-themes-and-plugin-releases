(() => {
  'use strict';
  const ribbon=document.querySelector('[data-shop-ribbon]');
  if(!ribbon)return;
  const track=ribbon.querySelector('[data-ribbon-track]');
  const reduced=matchMedia('(prefers-reduced-motion:reduce)');
  let frame=0,last=0,visible=false,hover=false,focused=false,drag=null,resumeAt=0;
  let clones=[],span=0;
  function stop(){cancelAnimationFrame(frame);frame=0;last=0;}
  function canRun(){return visible&&!document.hidden&&!reduced.matches&&!hover&&!focused&&!drag;}
  function wake(){if(canRun()&&!frame)frame=requestAnimationFrame(tick);}
  function tick(time){
    frame=0;if(!canRun())return;
    const elapsed=last?Math.min(time-last,48):0;last=time;
    if(time>=resumeAt&&span){
      ribbon.scrollLeft+=elapsed*.026;
      if(ribbon.scrollLeft>=span)ribbon.scrollLeft-=span;
    }
    wake();
  }
  function measure(){
    clones.forEach(item=>item.remove());clones=[];span=0;
    if(reduced.matches||track.children.length<2)return;
    const originals=Array.from(track.children);
    originals.forEach(item=>{const clone=item.cloneNode(true);clone.setAttribute('aria-hidden','true');clone.inert=true;track.appendChild(clone);clones.push(clone);});
    span=clones[0].offsetLeft-originals[0].offsetLeft;
  }
  ribbon.addEventListener('pointerenter',event=>{if(event.pointerType==='mouse'){hover=true;stop();}});
  ribbon.addEventListener('pointerleave',()=>{hover=false;wake();});
  ribbon.addEventListener('focusin',()=>{focused=true;stop();});
  ribbon.addEventListener('focusout',event=>{focused=ribbon.contains(event.relatedTarget);wake();});
  ribbon.addEventListener('pointerdown',event=>{
    resumeAt=performance.now()+4500;
    if(event.pointerType!=='mouse'||event.button!==0)return;
    drag={x:event.clientX,left:ribbon.scrollLeft};ribbon.setPointerCapture(event.pointerId);stop();
  });
  ribbon.addEventListener('pointermove',event=>{if(drag)ribbon.scrollLeft=drag.left+drag.x-event.clientX;});
  function release(){drag=null;wake();}
  ribbon.addEventListener('pointerup',release);ribbon.addEventListener('pointercancel',release);
  ribbon.addEventListener('wheel',()=>{resumeAt=performance.now()+4500;},{passive:true});
  const observer=new IntersectionObserver(entries=>{visible=entries[0].isIntersecting;visible?wake():stop();},{threshold:.01});observer.observe(ribbon);
  const resize=new ResizeObserver(()=>{measure();wake();});resize.observe(ribbon);
  reduced.addEventListener('change',()=>{stop();measure();wake();});
  document.addEventListener('visibilitychange',()=>document.hidden?stop():wake());
  window.addEventListener('pagehide',stop);window.addEventListener('pageshow',wake);
  measure();wake();
})();
