(() => {
  'use strict';
  const video=document.querySelector('[data-hero-film]');
  if(!video)return;
  const surface=video.closest('[data-hero-surface]'),control=document.querySelector('[data-hero-video-toggle]');
  const reduced=matchMedia('(prefers-reduced-motion:reduce)'),connection=navigator.connection;
  let visible=false,paused=false,suspended=false,failed=false,loaded=false;
  const eligible=()=>!reduced.matches&&!connection?.saveData;
  const shouldPlay=()=>eligible()&&visible&&!document.hidden&&!suspended&&!paused&&!failed;
  function label(){
    const stopped=paused||video.paused;
    control.toggleAttribute('data-paused',stopped);
    control.setAttribute('aria-label',stopped?control.dataset.play:control.dataset.pause);
    control.title=stopped?control.dataset.play:control.dataset.pause;
  }
  function sync(){
    if(!eligible()||failed){video.pause();surface.removeAttribute('data-video-ready');control.hidden=true;return;}
    if(!shouldPlay()){video.pause();label();return;}
    if(!loaded){
      video.muted=true;video.defaultMuted=true;
      video.src=(matchMedia('(max-width:760px)').matches&&video.dataset.mobileSrc)||video.dataset.src;
      loaded=true;
    }
    video.play().then(()=>{if(!shouldPlay())video.pause();}).catch(error=>{
      if(error.name==='AbortError'||!shouldPlay())return;
      failed=true;video.pause();surface.removeAttribute('data-video-ready');control.hidden=true;
    });
  }
  video.addEventListener('playing',()=>{if(shouldPlay()){surface.setAttribute('data-video-ready','');control.hidden=false;}label();});
  video.addEventListener('pause',label);
  video.addEventListener('error',()=>{failed=true;surface.removeAttribute('data-video-ready');control.hidden=true;});
  control.addEventListener('click',()=>{paused=!paused;label();sync();});
  if(typeof IntersectionObserver==='function')new IntersectionObserver(entries=>{visible=entries[0].isIntersecting;sync();},{threshold:.08}).observe(video.closest('[data-hero-photo]'));
  else{visible=true;sync();}
  document.addEventListener('visibilitychange',sync);
  reduced.addEventListener('change',sync);
  connection?.addEventListener?.('change',sync);
  window.addEventListener('pagehide',()=>{suspended=true;video.pause();});
  window.addEventListener('pageshow',()=>{suspended=false;sync();});
})();
