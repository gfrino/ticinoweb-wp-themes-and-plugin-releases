(() => {
  'use strict';
  // Home owns its existing motion clock. This file is loaded only on other pages.
  const reduced=matchMedia('(prefers-reduced-motion:reduce)'),desktop=matchMedia('(min-width:761px) and (hover:hover) and (pointer:fine)');
  let lenis=null,frame=0;
  function render(time){frame=0;if(!lenis||document.hidden)return;lenis.raf(time);if(lenis.isScrolling)wake();}
  function wake(){if(lenis&&!frame&&!document.hidden)frame=requestAnimationFrame(render);}
  function configure(){
    cancelAnimationFrame(frame);frame=0;lenis?.destroy();lenis=null;
    if(!reduced.matches&&desktop.matches&&typeof Lenis==='function'){
      lenis=new Lenis({lerp:.085,smoothWheel:true,syncTouch:false,autoRaf:false,anchors:false,
        prevent:node=>node.matches?.('textarea,select,[contenteditable="true"],[data-lenis-prevent]')});wake();
    }
  }
  window.addEventListener('wheel',wake,{passive:true});window.addEventListener('scroll',wake,{passive:true});
  document.addEventListener('click',event=>{
    if(!lenis||event.defaultPrevented||event.button!==0||event.metaKey||event.ctrlKey||event.altKey||event.shiftKey)return;
    const link=event.target.closest('a[href]');if(!link||link.hasAttribute('download')||link.target==='_blank')return;
    const url=new URL(link.href,location.href);if(url.origin!==location.origin||url.pathname!==location.pathname||url.search!==location.search||!url.hash)return;
    let target;try{target=document.getElementById(decodeURIComponent(url.hash.slice(1)));}catch{return;}
    if(!target)return;
    // Keep focus/semantics native; only interpolate the viewport movement.
    event.preventDefault();history.pushState(history.state,'',url.hash);
    if(!target.hasAttribute('tabindex')&&!target.matches('a,button,input,select,textarea')){target.tabIndex=-1;target.addEventListener('blur',()=>target.removeAttribute('tabindex'),{once:true});}
    target.focus({preventScroll:true});const padding=parseFloat(getComputedStyle(document.documentElement).scrollPaddingTop)||0;
    lenis.scrollTo(target,{offset:-padding});wake();
  });
  document.addEventListener('visibilitychange',()=>{if(document.hidden){cancelAnimationFrame(frame);frame=0;}else wake();});
  window.addEventListener('pagehide',()=>{cancelAnimationFrame(frame);frame=0;lenis?.destroy();lenis=null;});
  window.addEventListener('pageshow',event=>{if(event.persisted)configure();});
  reduced.addEventListener('change',configure);desktop.addEventListener('change',configure);configure();
})();
