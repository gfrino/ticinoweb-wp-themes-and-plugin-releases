(() => {
  // Use the CMS's existing tab and fields when arriving from the About editor.
  if (window.location.hash === '#chi-siamo' && window.jQuery) {
    window.jQuery(() => {
      document.querySelector('.ticinoweb-settings-tabs .nav-tab[href="#chi-siamo"]')?.click();
    });
  }
  const current=window.qzEditorFonts||{};
  for(const key of ['headings','subheadings','body']){
    const select=document.getElementById('ticinoweb_font_'+key);if(!select)continue;
    for(const name of ['Bricolage Grotesque','Figtree'])if(![...select.options].some(o=>o.value===name))select.add(new Option(name,name));
    for(const option of [...select.options])if(!['Bricolage Grotesque','Figtree'].includes(option.value))option.remove();
    select.value=['Bricolage Grotesque','Figtree'].includes(current[key])?current[key]:(key==='body'?'Figtree':'Bricolage Grotesque');
  }
})();
