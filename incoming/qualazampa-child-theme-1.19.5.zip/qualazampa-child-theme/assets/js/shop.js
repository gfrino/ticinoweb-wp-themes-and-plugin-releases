(() => {
  'use strict';
  const words=window.qzShop||{}, controls=new Map();
  let opened=null;
  document.querySelectorAll('[data-qz-select],.woocommerce-ordering select').forEach((select,index)=>{
    const wrap=document.createElement('div');wrap.className='qz-choice';
    const trigger=document.createElement('button');trigger.type='button';trigger.className='qz-choice__trigger';
    const value=document.createElement('span');trigger.append(value);
    const popup=document.createElement('div');popup.className='qz-choice__popup';popup.hidden=true;popup.setAttribute('data-lenis-prevent','');
    const list=document.createElement('ul');list.id='qz-options-'+index;list.className='qz-choice__list';list.setAttribute('role','listbox');
    const label=select.id?document.querySelector('label[for="'+select.id+'"]'):null;
    const name=label?.textContent||words.sort||select.getAttribute('aria-label')||'';
    trigger.id='qz-choice-'+index;trigger.setAttribute('aria-label',name);trigger.setAttribute('aria-haspopup','listbox');trigger.setAttribute('aria-expanded','false');trigger.setAttribute('aria-controls',list.id);
    list.setAttribute('aria-label',name);
    const options=Array.from(select.options).map(option=>{
      const item=document.createElement('li');item.className='qz-choice__option';item.textContent=option.textContent;item.setAttribute('role','option');item.tabIndex=-1;
      item.addEventListener('click',()=>choose(option.index));list.append(item);return item;
    });
    let search=null;
    if(options.length>10){
      search=document.createElement('input');search.type='search';search.className='qz-choice__search';search.placeholder=words.search;search.setAttribute('aria-label',words.search);search.setAttribute('aria-controls',list.id);
      search.addEventListener('input',()=>{
        const query=search.value.trim().toLocaleLowerCase();
        options.forEach((item,i)=>{item.hidden=select.options[i].hidden||(i!==0&&!item.textContent.toLocaleLowerCase().includes(query));});
        empty.hidden=options.some((item,i)=>i>0&&!item.hidden);
      });popup.append(search);
    }
    const empty=document.createElement('p');empty.className='qz-choice__empty';empty.textContent=words.empty;empty.hidden=true;empty.setAttribute('role','status');
    popup.append(list,empty);wrap.append(trigger,popup);select.after(wrap);
    // Native GET form and Woo sorting stay the only data owners; JS adds the popup.
    select.hidden=true;if(label)label.htmlFor=trigger.id;
    function sync(){value.textContent=select.options[select.selectedIndex]?.textContent||'';trigger.setAttribute('aria-label',name+': '+value.textContent);options.forEach((item,i)=>{item.setAttribute('aria-selected',String(i===select.selectedIndex));item.hidden=select.options[i].hidden;});}
    function close(restore=false){popup.hidden=true;trigger.setAttribute('aria-expanded','false');if(opened===api)opened=null;if(restore)trigger.focus();}
    function open(){
      opened?.close();opened=api;popup.hidden=false;trigger.setAttribute('aria-expanded','true');
      if(search){search.value='';options.forEach((item,i)=>item.hidden=select.options[i].hidden);empty.hidden=true;search.focus();}
      else options[select.selectedIndex]?.focus({preventScroll:true});
    }
    function choose(i){select.selectedIndex=i;sync();close(true);select.dispatchEvent(new Event('change',{bubbles:true}));}
    const api={close,wrap,sync};controls.set(select,api);
    trigger.addEventListener('click',()=>popup.hidden?open():close());
    trigger.addEventListener('keydown',event=>{if(['ArrowDown','ArrowUp'].includes(event.key)){event.preventDefault();open();}});
    popup.addEventListener('keydown',event=>{
      const visible=options.filter(item=>!item.hidden),at=visible.indexOf(document.activeElement);
      if(event.key==='Escape'){event.preventDefault();event.stopPropagation();close(true);return;}
      if(event.key==='Tab'){close();return;}
      if(['ArrowDown','ArrowUp','Home','End'].includes(event.key)&&(!search||document.activeElement!==search||event.key.startsWith('Arrow'))){
        event.preventDefault();const next=event.key==='Home'?0:event.key==='End'?visible.length-1:Math.max(0,Math.min(visible.length-1,at+(event.key==='ArrowDown'?1:-1)));visible[next]?.focus({preventScroll:true});visible[next]?.scrollIntoView({block:'nearest'});
      }
      if(event.key==='Enter'&&document.activeElement===search){event.preventDefault();return;}
      if(['Enter',' '].includes(event.key)&&options.includes(document.activeElement)){event.preventDefault();document.activeElement.click();}
    });
    select.addEventListener('change',sync);sync();
  });
  const form=document.querySelector('.qz-filters'),data=form?.querySelector('[data-qz-facets]');
  if(data&&typeof window.QZFacetModel==='function'){
    try{
      const model=new window.QZFacetModel(JSON.parse(data.textContent)),selects=Array.from(form.querySelectorAll('[data-qz-select]'));
      function update(changed){
        const state=Object.fromEntries(selects.map(select=>[select.name,select.value]));state.qz_stock=!!form.querySelector('[name="qz_stock"]')?.checked;
        const next=changed?model.reconcile(state,changed):state;
        selects.forEach(select=>{select.value=next[select.name]||'';const available=model.available(next,select.name);
          Array.from(select.options).forEach(option=>{const valid=!option.value||available.has(option.value)||option.selected;option.hidden=!valid;option.disabled=!valid;});controls.get(select)?.sync();
        });
        if(changed){const cleared=selects.some(select=>state[select.name]!==next[select.name]);form.querySelector('[data-facet-status]').textContent=cleared?words.cleared:words.updated;}
      }
      form.addEventListener('change',event=>{if(event.target.matches('[data-qz-select],[name="qz_stock"]'))update(event.target.name);});update();
    }catch{/* Native GET selects remain usable if the optional index is unavailable. */}
  }
  document.addEventListener('click',event=>{if(opened&&!opened.wrap.contains(event.target))opened.close();});
  document.addEventListener('focusin',event=>{if(opened&&!opened.wrap.contains(event.target))opened.close();});
  window.addEventListener('pagehide',()=>opened?.close());
})();
