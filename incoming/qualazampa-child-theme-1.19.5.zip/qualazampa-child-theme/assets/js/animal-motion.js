/* Local gestures deform the original alpha artwork; one renderer, one texture. */
(() => {
  'use strict';
  const rigs={
    cani:{duration:1500,rest:2400,joints:[{pivot:[.64,.24],region:[.59,.37,.14,.19],angle:.14}]},
    gatti:{duration:1800,rest:2600,joints:[{pivot:[.44,.57],region:[.27,.57,.20,.085],angle:.17}]},
    uccelli:{duration:1700,rest:2500,joints:[{pivot:[.57,.43],region:[.44,.55,.18,.23],angle:.10}]},
    roditori:{duration:1500,rest:2400,joints:[{pivot:[.62,.35],region:[.47,.23,.25,.23],angle:.15}]},
    acquaristica:{duration:2200,rest:1800,joints:[{pivot:[.63,.48],region:[.29,.53,.39,.40],angle:.10}]},
    rettili:{duration:2300,rest:2600,joints:[{pivot:[.65,.60],region:[.67,.70,.12,.13],angle:.20},{pivot:[.25,.62],region:[.24,.72,.13,.13],angle:-.17}]},
    stagno:{duration:2200,rest:1900,joints:[{pivot:[.57,.38],region:[.65,.22,.27,.25],angle:.12}]},
    diversi:{duration:1600,rest:2400,joints:[{pivot:[.75,.55],region:[.80,.36,.20,.24],angle:.17}]}
  };
  const vertex=`
    attribute vec2 aUv;
    varying vec2 vUv;
    uniform vec2 uAspect,uAngle,uPivot0,uPivot1;
    uniform vec4 uRegion0,uRegion1;
    vec2 bend(vec2 p,vec2 pivot,vec4 region,float angle){
      vec2 delta=(aUv-region.xy)/region.zw;
      float weight=1.0-smoothstep(.12,1.0,dot(delta,delta));
      float c=cos(angle),s=sin(angle);
      vec2 d=p-pivot;
      vec2 rotated=vec2(c*d.x-s*d.y,s*d.x+c*d.y)+pivot;
      return mix(p,rotated,weight);
    }
    void main(){
      vec2 p=bend(aUv,uPivot0,uRegion0,uAngle.x);
      p=bend(p,uPivot1,uRegion1,uAngle.y);
      gl_Position=vec4((p.x*2.0-1.0)*uAspect.x,(1.0-p.y*2.0)*uAspect.y,0.0,1.0);
      vUv=aUv;
    }`;
  const fragment=`precision mediump float;varying vec2 vUv;uniform sampler2D uArt;void main(){gl_FragColor=texture2D(uArt,vUv);}`;
  class AnimalMotion {
    constructor(wake){this.wake=wake;this.root=null;this.timer=0;this.token=0;this.failed=false;this.ready=false;this.started=null;this.pending=false;}
    initialize(){
      if(this.gl)return true;
      const canvas=document.createElement('canvas');
      const gl=canvas.getContext('webgl',{alpha:true,antialias:true,premultipliedAlpha:true,powerPreference:'low-power',preserveDrawingBuffer:false});
      if(!gl)return false;
      this.canvas=canvas;this.gl=gl;
      canvas.className='qz-animal__canvas';canvas.setAttribute('aria-hidden','true');
      canvas.addEventListener('webglcontextlost',event=>{event.preventDefault();this.fail();});
      const shaders=[];
      try{
        for(const [type,source] of [[gl.VERTEX_SHADER,vertex],[gl.FRAGMENT_SHADER,fragment]]){
          const shader=gl.createShader(type);gl.shaderSource(shader,source);gl.compileShader(shader);shaders.push(shader);
          if(!gl.getShaderParameter(shader,gl.COMPILE_STATUS))throw new Error('Shader unavailable');
        }
        const program=gl.createProgram();shaders.forEach(shader=>gl.attachShader(program,shader));gl.linkProgram(program);
        if(!gl.getProgramParameter(program,gl.LINK_STATUS))throw new Error('Renderer unavailable');
        this.program=program;gl.useProgram(program);
        const vertices=[],indices=[],segments=56;
        for(let y=0;y<=segments;y++)for(let x=0;x<=segments;x++)vertices.push(x/segments,y/segments);
        for(let y=0;y<segments;y++)for(let x=0;x<segments;x++){
          const a=y*(segments+1)+x,b=a+segments+1;indices.push(a,b,a+1,a+1,b,b+1);
        }
        this.vertices=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,this.vertices);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array(vertices),gl.STATIC_DRAW);
        const attribute=gl.getAttribLocation(program,'aUv');gl.enableVertexAttribArray(attribute);gl.vertexAttribPointer(attribute,2,gl.FLOAT,false,0,0);
        this.indices=gl.createBuffer();gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER,this.indices);gl.bufferData(gl.ELEMENT_ARRAY_BUFFER,new Uint16Array(indices),gl.STATIC_DRAW);this.count=indices.length;
        this.texture=gl.createTexture();gl.bindTexture(gl.TEXTURE_2D,this.texture);
        gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.LINEAR);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.LINEAR);
        gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE);
        gl.pixelStorei(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL,true);gl.clearColor(0,0,0,0);
        this.uniforms={};for(const name of ['uAspect','uAngle','uPivot0','uPivot1','uRegion0','uRegion1','uArt'])this.uniforms[name]=gl.getUniformLocation(program,name);
        gl.uniform1i(this.uniforms.uArt,0);
        return true;
      }catch{this.failed=true;return false;}
      finally{shaders.forEach(shader=>gl.deleteShader(shader));}
    }
    select(root,width){
      if(!root||this.failed){this.clear();return;}
      if(root===this.root){if(this.ready&&(this.size!==width||this.pixelRatio!==Math.min(devicePixelRatio||1,2))){this.resize(width);this.draw(0);}return;}
      this.clear();
      const image=root.querySelector('img');
      const key=image?.getAttribute('src')?.split('/').pop().replace(/\.webp(?:\?.*)?$/,'');
      const rig=rigs[key];if(!image||!rig)return;
      try{if(!this.initialize()){this.fail();return;}}catch{this.fail();return;}
      this.root=root;this.image=image;this.rig=rig;
      const token=++this.token;
      const begin=()=>{
        if(token!==this.token||this.root!==root||!image.naturalWidth)return;
        try{
          const gl=this.gl;gl.bindTexture(gl.TEXTURE_2D,this.texture);gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,gl.RGBA,gl.UNSIGNED_BYTE,image);
          if(gl.getError()!==gl.NO_ERROR)throw new Error('Artwork unavailable');
          this.rig.joints.concat([{pivot:[.5,.5],region:[.5,.5,1,1],angle:0}]).slice(0,2).forEach((joint,i)=>{
            gl.uniform2fv(this.uniforms['uPivot'+i],joint.pivot);gl.uniform4fv(this.uniforms['uRegion'+i],joint.region);
          });
          this.resize(width);this.ready=true;this.draw(0);root.append(this.canvas);root.setAttribute('data-companion-live','');
          this.pending=true;this.started=null;this.wake();
        }catch{this.fail();}
      };
      if(image.complete)begin();else if(typeof image.decode==='function')image.decode().then(begin,()=>{if(token===this.token)this.clear();});else image.addEventListener('load',begin,{once:true});
    }
    resize(width){
      this.size=width;
      this.pixelRatio=Math.min(devicePixelRatio||1,2);
      const side=Math.min(768,Math.max(128,Math.ceil(width*this.pixelRatio)));
      this.canvas.width=side;this.canvas.height=side;this.gl.viewport(0,0,side,side);
      const ratio=this.image.naturalWidth/this.image.naturalHeight;
      this.gl.uniform2f(this.uniforms.uAspect,Math.min(1,ratio),Math.min(1,1/ratio));
    }
    draw(gesture){
      const gl=this.gl;if(!gl||!this.rig)return;
      gl.uniform2f(this.uniforms.uAngle,this.rig.joints[0].angle*gesture,(this.rig.joints[1]?.angle||0)*gesture);
      gl.clear(gl.COLOR_BUFFER_BIT);gl.drawElements(gl.TRIANGLES,this.count,gl.UNSIGNED_SHORT,0);
    }
    tick(time){
      if(!this.ready||!this.root||this.failed)return false;
      if(this.pixelRatio!==Math.min(devicePixelRatio||1,2)){this.resize(this.size);this.draw(0);}
      if(this.pending){this.pending=false;this.started=time;this.lastDraw=-Infinity;}
      if(this.started===null)return false;
      const t=Math.min(1,(time-this.started)/this.rig.duration);
      if(t>=1){
        this.draw(0);this.started=null;
        this.timer=setTimeout(()=>{this.timer=0;if(this.ready){this.pending=true;this.wake();}},this.rig.rest);
        return false;
      }
      if(time-this.lastDraw>=1000/30){this.draw(Math.sin(t*Math.PI*2)*Math.sin(t*Math.PI)**2);this.lastDraw=time;}
      return true;
    }
    clear(){
      clearTimeout(this.timer);this.timer=0;
      if(!this.root)return;
      this.token++;this.root.removeAttribute('data-companion-live');this.canvas?.remove();
      this.root=null;this.image=null;this.ready=false;this.pending=false;this.started=null;
      if(this.gl&&!this.gl.isContextLost()){
        this.gl.bindTexture(this.gl.TEXTURE_2D,this.texture);
        this.gl.texImage2D(this.gl.TEXTURE_2D,0,this.gl.RGBA,1,1,0,this.gl.RGBA,this.gl.UNSIGNED_BYTE,new Uint8Array(4));
      }
    }
    fail(){this.clear();this.failed=true;}
  }
  window.QZAnimalMotion=AnimalMotion;
})();
