(() => {
  'use strict';
  if(!window.wp?.media)return;
  document.querySelectorAll('[data-film-field]').forEach(field=>{
    const input=field.querySelector('input'),name=field.querySelector('[data-film-name]');
    field.querySelector('[data-film-pick]').addEventListener('click',()=>{
      const frame=wp.media({title:field.dataset.title,button:{text:field.dataset.use},library:{type:'video/mp4'},multiple:false});
      frame.on('select',()=>{const file=frame.state().get('selection').first().toJSON();input.value=file.id;name.textContent=file.filename||file.title;});frame.open();
    });
    field.querySelector('[data-film-remove]').addEventListener('click',()=>{input.value='0';name.textContent='';});
  });
})();
