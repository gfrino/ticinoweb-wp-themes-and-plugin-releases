(() => {
  'use strict';
  const field=document.querySelector('[data-brand-logo-field]'),pick=field?.querySelector('[data-brand-logo-pick]');
  if(!pick||!window.wp?.media)return;
  const input=field.querySelector('[name="qz_brand_logo"]'),preview=field.querySelector('[data-brand-logo-preview]');
  let frame;
  pick.addEventListener('click',()=>{
    if(!frame){
      frame=wp.media({title:window.qzBrandEditor.title,button:{text:window.qzBrandEditor.use},library:{type:'image'},multiple:false});
      frame.on('select',()=>{const attachment=frame.state().get('selection').first().toJSON();input.value=attachment.id;preview.replaceChildren();const img=document.createElement('img');img.src=attachment.sizes?.medium?.url||attachment.url;img.alt='';img.style.cssText='max-width:180px;max-height:100px;object-fit:contain';preview.append(img);});
    }
    frame.open();
  });
  field.querySelector('[data-brand-logo-remove]').addEventListener('click',()=>{input.value='0';preview.replaceChildren();});
  field.querySelector('[name="qz_brand_dark"]').addEventListener('change',event=>{preview.style.background=event.target.checked?'#342627':'transparent';});
})();
