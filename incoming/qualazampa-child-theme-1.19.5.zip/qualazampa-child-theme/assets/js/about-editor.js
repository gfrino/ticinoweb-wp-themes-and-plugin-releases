(() => {
  'use strict';
  const preview=document.querySelector('[data-loyalty-preview]');
  const rate=document.getElementById('qz-about-rate'),purchases=document.getElementById('qz-about-purchases');
  if(!preview||!rate||!purchases)return;
  function update(){
    const a=Math.min(100,Math.max(0,Math.trunc(Number(rate.value)||0)));
    const b=Math.min(1000,Math.max(0,Math.trunc(Number(purchases.value)||0)));
    preview.textContent=a&&b?preview.dataset.pattern.replace('%1$s',a).replace('%2$s',b).replace('%%','%'):preview.dataset.empty;
  }
  rate.addEventListener('input',update);purchases.addEventListener('input',update);
  update();
})();
