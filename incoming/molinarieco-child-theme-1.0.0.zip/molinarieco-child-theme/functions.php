<?php
/**
 * Garage Molinari child theme setup.
 *
 * @package Molinarieco
 */
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
add_action( 'wp_enqueue_scripts', function () {
    wp_enqueue_style( 'molinarieco-parent', get_template_directory_uri() . '/style.css', array(), wp_get_theme( get_template() )->get( 'Version' ) );
}, 9 );

// The parent registers Google Fonts; use the system font on this site to avoid a third-party request.
add_action( 'wp_enqueue_scripts', function () {
    wp_dequeue_style( 'poppins-font' );
    wp_deregister_style( 'poppins-font' );
    wp_register_style( 'poppins-font', false );
}, 11 );

add_action( 'ticinoweb_footer_links', function () {
    $services = get_page_by_path( 'servizi' );
    if ( $services ) {
        echo '<li><a href="' . esc_url( get_permalink( $services ) ) . '">' . esc_html( get_the_title( $services ) ) . '</a></li>';
    }
} );
