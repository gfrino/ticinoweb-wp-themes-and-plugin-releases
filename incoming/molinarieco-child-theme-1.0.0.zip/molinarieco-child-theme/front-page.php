<?php
/** Front page. */
get_header();
$front_id = (int) get_option( 'page_on_front' );
$hero_id  = $front_id ? get_post_thumbnail_id( $front_id ) : 0;
?>
<main id="main" class="mol-container">
<section class="mol-hero" aria-labelledby="mol-hero-title">
<?php if ( $hero_id ) : echo wp_get_attachment_image( $hero_id, 'full', false, array( 'fetchpriority' => 'high', 'loading' => 'eager' ) ); endif; ?>
<div class="mol-hero-content"><h1 id="mol-hero-title"><?php echo esc_html( get_bloginfo( 'name' ) ); ?></h1><p><?php echo esc_html( get_bloginfo( 'description' ) ); ?></p><a class="mol-button" href="<?php echo esc_url( home_url( '/servizi/' ) ); ?>"><?php esc_html_e( 'Scopri i servizi', 'molinarieco-child-theme' ); ?></a></div>
</section>
<?php if ( $front_id ) : $front = get_post( $front_id ); if ( $front ) : ?><div class="mol-home-sections"><?php echo apply_filters( 'the_content', $front->post_content ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div><?php endif; endif; ?>
</main>
<?php get_footer(); ?>
