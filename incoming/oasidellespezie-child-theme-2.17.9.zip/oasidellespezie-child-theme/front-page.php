<?php
/**
 * Front Page Template - Oasi delle Spezie
 *
 * Unica struttura completa e lineare della Home Page che racchiude:
 *  1. Hero Dinamica (Video/Immagine da ticinoWEB CMS)
 *  2. Barra di Fiducia & Servizio (Spedizioni CH, soglia gratuita da WooCommerce, Pagamenti sicuri, Assistenza)
 *  3. I Nostri Bestseller (Top 6 prodotti reali da storico ordini HPOS)
 *  4. Banner Narrativo 1 (Macinazione espressa su ordinazione)
 *  5. Creazioni Esclusive MIXTIS Bio (Miscele artigianali brevettate)
 *  6. Cofanetti & Idee Regalo Gourmet
 *  7. Banner Narrativo 2 (100% Naturale & Certificazione Bio Inspecta)
 *  8. Storia & Atelier Artigianale (Chi siamo - Laboratorio Oasi delle Spezie)
 *  9. Esplora le Categorie per Macro-Gruppi (Navigazione interattiva a schede / fisarmonica per 45 categorie)
 * 10. Newsletter del Laboratorio
 *
 * @package OasiDelleSpezieChild
 * @version 0.6.2
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

// Dati e query preparati tramite inc/home-functions.php
$contact             = oasi_get_contact_data();
$hero                = oasi_get_hero_data();
$mixtis              = oasi_get_mixtis_products();
$gift_boxes          = oasi_get_gift_boxes();
$macro_groups        = oasi_get_category_macro_groups();

// Contenuto "Chi siamo" gestito dal ticinoWEB CMS. L'immagine CMS non viene
// mostrata in Home: resta disponibile per le altre pagine che la utilizzano.
$about_title = trim( (string) get_option( 'ticinoweb_chi_siamo_title', '' ) );
$about_text  = trim( (string) get_option( 'ticinoweb_chi_siamo_text', '' ) );
$about_link  = trim( (string) get_option( 'ticinoweb_chi_siamo_link', '' ) );

if ( '' === $about_title ) {
	$about_title = __( "Benvenuti nell'Oasi delle Spezie", 'oasidellespezie-child-theme' );
}
if ( '' === $about_text ) {
	$about_text = __( "Siamo una piccola azienda familiare svizzera nata con l'obiettivo di condividere la profonda conoscenza e l'amore per le spezie più pregiate del mondo.\n\nL'Oasi delle Spezie non è un negozio con vetrina su strada: è un autentico laboratorio artigianale. Qui selezioniamo spezie d'origine controllata, erbe aromatiche biologiche, pepi rari e sali incontaminati. Per preservare intatti i preziosi oli essenziali e l'intensità del bouquet olfattivo, maciniamo le singole spezie solo ed esclusivamente al momento dell'ordine.", 'oasidellespezie-child-theme' );
}
if ( '' === $about_link ) {
	$about_link = home_url( '/chi-siamo/' );
}

$grinding_bg = wp_get_attachment_image_url( 33435, '1536x1536' );
if ( ! $grinding_bg ) {
	$grinding_bg = oasi_upload_url( '2022/02/male-hands-grinding-spices-top-view.jpg' );
}

$natural_bg = wp_get_attachment_image_url( 33456, '1536x1536' );
if ( ! $natural_bg ) {
	$natural_bg = oasi_upload_url( '2022/02/spices-ingredients-for-cooking-spices-concept-1-1.jpg' );
}

$cert_logo_url           = oasi_get_master_logo_url();
$cert_logo_attachment_id = $cert_logo_url ? attachment_url_to_postid( $cert_logo_url ) : 0;
$cert_logo_alt           = sprintf( __( 'Logo %s', 'oasidellespezie-child-theme' ), get_bloginfo( 'name' ) );

$spezie_term = get_term_by( 'slug', 'spezie-bio', 'product_cat' );
$spezie_link = $spezie_term ? get_term_link( $spezie_term ) : home_url( '/categoria-prodotto/spezie-bio/' );

$mixtis_term = get_term_by( 'slug', 'miscele-di-spezie-bio', 'product_cat' );
$mixtis_link = $mixtis_term ? get_term_link( $mixtis_term ) : home_url( '/categoria-prodotto/miscele-di-spezie-bio/' );

$gift_term = get_term_by( 'slug', 'idee-regalo', 'product_cat' );
$gift_link = $gift_term ? get_term_link( $gift_term ) : home_url( '/categoria-prodotto/idee-regalo/' );
?>

<div id="primary" class="site-main oasi-home-main">

	<!-- =======================================================================
	     1. HERO DINAMICA (CMS ticinoWEB)
	     ======================================================================= -->
	<section class="oasi-hero" aria-label="<?php esc_attr_e( 'Presentazione Oasi delle Spezie', 'oasidellespezie-child-theme' ); ?>">
		<div class="oasi-hero__media">
			<?php if ( $hero['is_video'] ) : ?>
				<video class="oasi-hero__video" autoplay loop muted playsinline poster="<?php echo esc_url( $hero['poster_url'] ); ?>">
					<source src="<?php echo esc_url( $hero['media_url'] ); ?>" type="video/mp4">
				</video>
			<?php else : ?>
				<img class="oasi-hero__img" src="<?php echo esc_url( $hero['media_url'] ); ?>" alt="<?php echo esc_attr( $hero['title'] ); ?>" loading="eager" width="1920" height="1080">
			<?php endif; ?>
			<div class="oasi-hero__overlay"></div>
		</div>

		<div class="oasi-container oasi-hero__inner">
			<div class="oasi-hero__content">
				<span class="oasi-hero__tagline">
					<svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M12 2L15.09 8.26L22 9.27L17 14.14L18.18 21.02L12 17.77L5.82 21.02L7 14.14L2 9.27L8.91 8.26L12 2Z"/></svg>
					<?php echo esc_html( $hero['tagline'] ); ?>
				</span>

				<h1 class="oasi-hero__title">
					<?php echo esc_html( $hero['title'] ); ?>
				</h1>

				<p class="oasi-hero__desc">
					<?php echo nl2br( esc_html( $hero['description'] ) ); ?>
				</p>

				<div class="oasi-hero__cta-group">
					<a href="<?php echo esc_url( $hero['btn_link'] ); ?>" class="oasi-btn oasi-btn--primary oasi-btn--lg">
						<span><?php echo esc_html( $hero['btn_text'] ); ?></span>
						<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg>
					</a>

					<a href="<?php echo esc_url( home_url( '/chi-siamo/' ) ); ?>" class="oasi-btn oasi-btn--outline-light oasi-btn--lg">
						<span><?php esc_html_e( 'Il nostro laboratorio', 'oasidellespezie-child-theme' ); ?></span>
					</a>
				</div>

				<ul class="oasi-hero__features" aria-label="<?php esc_attr_e( 'Caratteristiche principali', 'oasidellespezie-child-theme' ); ?>">
					<li>
						<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
						<span>100% Naturale & Bio</span>
					</li>
					<li>
						<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
						<span>Macinato all'ordine</span>
					</li>
					<li>
						<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/></svg>
						<span>Spedizioni in tutta la Svizzera</span>
					</li>
				</ul>
			</div>
		</div>
	</section>


	<!-- =======================================================================
	     2. TRUST & SERVICE BAR
	     ======================================================================= -->
	<section class="oasi-trust-bar" aria-label="<?php esc_attr_e( 'Informazioni di servizio e garanzie', 'oasidellespezie-child-theme' ); ?>">
		<div class="oasi-container">
			<div class="oasi-trust-grid">
				<div class="oasi-trust-item">
					<div class="oasi-trust-item__icon" aria-hidden="true">
						<svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="1" y="3" width="15" height="13"></rect><polygon points="16 8 20 8 23 11 23 16 16 16 16 8"></polygon><circle cx="5.5" cy="18.5" r="2.5"></circle><circle cx="18.5" cy="18.5" r="2.5"></circle></svg>
					</div>
					<div class="oasi-trust-item__text">
						<span class="oasi-trust-item__title">SPEDIZIONE 5-10 GIORNI</span>
						<span class="oasi-trust-item__desc">Lavorativi in tutta la Svizzera</span>
					</div>
				</div>

				<div class="oasi-trust-item">
					<div class="oasi-trust-item__icon" aria-hidden="true">
						<svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 12 20 22 4 22 4 12"></polyline><rect x="2" y="7" width="20" height="5"></rect><line x1="12" y1="22" x2="12" y2="7"></line><path d="M12 7H7.5a2.5 2.5 0 0 1 0-5C11 2 12 7 12 7z"></path><path d="M12 7h4.5a2.5 2.5 0 0 0 0-5C13 2 12 7 12 7z"></path></svg>
					</div>
					<div class="oasi-trust-item__text">
						<span class="oasi-trust-item__title"><?php esc_html_e( 'SPEDIZIONE GRATUITA', 'oasidellespezie-child-theme' ); ?></span>
						<span class="oasi-trust-item__desc"><?php echo esc_html( sprintf( /* translators: 1: amount in CHF, 2: city. */ __( 'Da %1$s CHF o ritiro a %2$s', 'oasidellespezie-child-theme' ), ( function_exists( 'oasi_free_shipping_threshold' ) ? oasi_free_shipping_threshold() : '' ), $contact['city'] ) ); ?></span>
					</div>
				</div>

				<div class="oasi-trust-item">
					<div class="oasi-trust-item__icon" aria-hidden="true">
						<svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="1" y="4" width="22" height="16" rx="2" ry="2"></rect><line x1="1" y1="10" x2="23" y2="10"></line></svg>
					</div>
					<div class="oasi-trust-item__text">
						<span class="oasi-trust-item__title"><?php esc_html_e( 'PAGAMENTO SICURO', 'oasidellespezie-child-theme' ); ?></span>
						<span class="oasi-trust-item__desc"><?php esc_html_e( 'TWINT, PostFinance, Carte, Bonifico', 'oasidellespezie-child-theme' ); ?></span>
					</div>
				</div>

				<div class="oasi-trust-item">
					<div class="oasi-trust-item__icon" aria-hidden="true">
						<svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path></svg>
					</div>
					<div class="oasi-trust-item__text">
						<span class="oasi-trust-item__title"><?php esc_html_e( 'SERVIZIO CLIENTI', 'oasidellespezie-child-theme' ); ?></span>
						<span class="oasi-trust-item__desc">
							<a href="<?php echo esc_url( 'tel:' . $contact['phone_tel'] ); ?>" class="oasi-trust-item__phone-link"><?php echo esc_html( $contact['phone'] ); ?></a>
							<span class="oasi-trust-item__sep">•</span>
							<span><?php echo esc_html( $contact['hours_short'] ); ?></span>
						</span>
					</div>
				</div>
			</div>
		</div>
	</section>


	<!-- =======================================================================
	     3. BESTSELLER REALI WOOCOMMERCE - VETRINA DINAMICA A DOPPIA CORSIA
	     ======================================================================= -->
	<?php get_template_part( 'template-parts/home/bestsellers' ); ?>


	<!-- =======================================================================
	     5. BANNER NARRATIVO 1: MACINAZIONE SU ORDINAZIONE
	     ======================================================================= -->
	<section class="oasi-narrative-banner oasi-narrative-banner--grinding" style="background-image: url('<?php echo esc_url( $grinding_bg ); ?>');" aria-label="<?php esc_attr_e( 'Filosofia di macinazione Oasi delle Spezie', 'oasidellespezie-child-theme' ); ?>">
		<div class="oasi-narrative-banner__overlay"></div>
		<div class="oasi-container oasi-narrative-banner__inner">
			<div class="oasi-narrative-banner__content">
				<span class="oasi-narrative-banner__badge">
					<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 16 14"></polyline></svg>
					Freschezza Assoluta
				</span>

				<h2 class="oasi-narrative-banner__title">
					A l'Oasi delle Spezie, tutte le nostre singole spezie sono macinate solo quando vengono ordinate!
				</h2>

				<p class="oasi-narrative-banner__desc">
					Gli oli essenziali e i principi attivi naturali si disperdono rapidamente dopo la macinazione. Il nostro metodo artigianale garantisce che ogni grammo mantenga l'integrità del suo profilo aromatico e tutte le sue proprietà benefiche.
				</p>

				<div class="oasi-narrative-banner__cta">
					<a href="<?php echo esc_url( $spezie_link ); ?>" class="oasi-btn oasi-btn--primary oasi-btn--lg">
						<span>Scopri le nostre Spezie Pure</span>
						<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg>
					</a>
				</div>
			</div>
		</div>
	</section>


	<!-- =======================================================================
	     6. CREAZIONI ESCLUSIVE "MIXTIS" BIO
	     ======================================================================= -->
	<?php if ( ! empty( $mixtis ) ) : ?>
		<section class="oasi-mixtis oasi-section" aria-labelledby="oasi-mixtis-title">
			<div class="oasi-container">
				<div class="oasi-section-header">
					<span class="oasi-section-eyebrow">Creazioni Esclusive Artigianali</span>
					<h2 id="oasi-mixtis-title" class="oasi-section-title">
						Nostre creazioni "MIXTIS" bio
					</h2>
					<div class="oasi-section-divider"></div>
					<p class="oasi-section-subtitle oasi-mixtis__intro">
						La macinazione de le nostre miscele di spezie della "Linea Mixtis" (interamente biologica) è fatta in piccola quantità, in modo da poter rinnovare regolarmente il nostro stock. Questo ci permette di offrirvi miscele di spezie biologiche recentemente macinate, per garantire la massima freschezza mantenendo i loro sapori, olii essenziali, vitamine e minerali!
					</p>
				</div>

				<div class="oasi-products-grid oasi-products-grid--5cols">
					<?php foreach ( $mixtis as $product ) : ?>
						<?php oasi_render_product_card( $product, 'MIXTIS Bio', __( 'Scegli', 'oasidellespezie-child-theme' ) ); ?>
					<?php endforeach; ?>
				</div>

				<div class="oasi-section-footer">
					<a href="<?php echo esc_url( $mixtis_link ); ?>" class="oasi-btn oasi-btn--outline">
						<span>Esplora tutte le Miscele MIXTIS</span>
						<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg>
					</a>
				</div>
			</div>
		</section>
	<?php endif; ?>


	<!-- =======================================================================
	     7. COFANETTI & IDEE REGALO GOURMET
	     ======================================================================= -->
	<?php if ( ! empty( $gift_boxes ) ) : ?>
		<section class="oasi-gift-boxes oasi-section oasi-section--bg-sand" aria-labelledby="oasi-gifts-title">
			<div class="oasi-container">
				<div class="oasi-section-header">
					<span class="oasi-section-eyebrow">Cofanetti & Confezioni Artigianali</span>
					<h2 id="oasi-gifts-title" class="oasi-section-title">
						Scoprite le nostre idee regalo...
					</h2>
					<div class="oasi-section-divider"></div>
					<p class="oasi-gift-boxes__subtitle">
						Cambiamo le nostre abitudini! Un regalo originale fa sempre piacere!
					</p>
				</div>

				<div class="oasi-products-grid oasi-products-grid--5cols">
					<?php foreach ( $gift_boxes as $product ) : ?>
						<?php oasi_render_product_card( $product, 'Idea Regalo' ); ?>
					<?php endforeach; ?>
				</div>

				<div class="oasi-section-footer">
					<a href="<?php echo esc_url( $gift_link ); ?>" class="oasi-btn oasi-btn--warm">
						<span>Scopri altre nostre idee regalo</span>
						<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg>
					</a>
				</div>
			</div>
		</section>
	<?php endif; ?>


	<!-- =======================================================================
	     8. BANNER NARRATIVO 2: 100% NATURALE & BIO
	     ======================================================================= -->
	<section class="oasi-narrative-banner oasi-narrative-banner--natural" style="background-image: url('<?php echo esc_url( $natural_bg ); ?>');" aria-label="<?php esc_attr_e( 'Garanzia naturale e certificazioni', 'oasidellespezie-child-theme' ); ?>">
		<div class="oasi-narrative-banner__overlay oasi-narrative-banner__overlay--warm"></div>
		<div class="oasi-container oasi-narrative-banner__inner">
			<div class="oasi-narrative-banner__content">
				<div class="oasi-narrative-banner__cert-badge">
					<?php if ( $cert_logo_url ) : ?>
						<?php if ( $cert_logo_attachment_id ) : ?>
							<?php echo wp_get_attachment_image( $cert_logo_attachment_id, 'full', false, array( 'alt' => $cert_logo_alt, 'class' => 'oasi-cert-img', 'loading' => 'lazy', 'decoding' => 'async', 'sizes' => '(max-width: 600px) 220px, 320px' ) ); ?>
						<?php else : ?>
							<img src="<?php echo esc_url( $cert_logo_url ); ?>" alt="<?php echo esc_attr( $cert_logo_alt ); ?>" width="320" height="195" class="oasi-cert-img" loading="lazy" decoding="async">
						<?php endif; ?>
					<?php endif; ?>
					<span class="oasi-cert-label">Certificazione Ufficiale Bio • CH-BIO-006</span>
				</div>

				<h2 class="oasi-narrative-banner__title">
					Tutte le nostre erbe, spezie e miscele di spezie sono naturali al 100%, senza conservanti o additivi.
				</h2>

				<p class="oasi-narrative-banner__desc">
					Rifiutiamo aromi sintetici, esaltatori di sapidità, conservanti e addensanti. Solo pura materia prima selezionata, coltivata nel rispetto della terra e lavorata con rigore svizzero.
				</p>

				<div class="oasi-narrative-banner__cta">
					<a href="<?php echo esc_url( home_url( '/chi-siamo/' ) ); ?>" class="oasi-btn oasi-btn--primary oasi-btn--lg">
						<span>Approfondisci la Nostra Filosofia</span>
						<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg>
					</a>
				</div>
			</div>
		</div>
	</section>


	<!-- =======================================================================
	     8. STORIA & ATELIER ARTIGIANALE (CHI SIAMO)
	     ======================================================================= -->
	<section class="oasi-welcome oasi-section" aria-labelledby="oasi-welcome-title">
		<div class="oasi-container">
			<div class="oasi-welcome__grid">
				<div class="oasi-welcome__text-col">
					<span class="oasi-section-eyebrow">Passione, Purezza & Tradizione</span>
					<h2 id="oasi-welcome-title" class="oasi-section-title">
						<?php echo esc_html( $about_title ); ?>
					</h2>
					<div class="oasi-section-divider"></div>

					<div class="oasi-welcome__cms-copy">
						<?php echo wp_kses_post( wpautop( esc_html( $about_text ) ) ); ?>
					</div>

					<div class="oasi-welcome__badges">
						<div class="oasi-pill">
							<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
							<span>Origine 100% Controllata</span>
						</div>
						<div class="oasi-pill">
							<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/></svg>
							<span>Macinazione su Ordinazione</span>
						</div>
						<div class="oasi-pill">
							<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
							<span>Qualità Svizzera & Bio</span>
						</div>
					</div>

					<div class="oasi-welcome__cta">
						<a href="<?php echo esc_url( $about_link ); ?>" class="oasi-btn oasi-btn--outline">
							<span>Scopri la nostra storia</span>
							<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg>
						</a>
					</div>
				</div>
			</div>

			<!-- Box Contatti & Punto Ritiro Atelier Dinamico dal CMS (ticinoweb-cms#contatti) -->
			<div class="oasi-lab-contact-box" aria-label="<?php esc_attr_e( 'Dati di contatto e laboratorio', 'oasidellespezie-child-theme' ); ?>">
				<div class="oasi-lab-contact-box__header">
					<div class="oasi-lab-contact-box__badge">
						<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path><circle cx="12" cy="10" r="3"></circle></svg>
						<span><?php esc_html_e( 'Punto Ritiro & Atelier Artigianale', 'oasidellespezie-child-theme' ); ?></span>
					</div>
					<h3 class="oasi-lab-contact-box__title">
						<?php echo esc_html( sprintf( __( 'Vieni a Trovarci o Ritira il Tuo Ordine a %s', 'oasidellespezie-child-theme' ), $contact['city'] ) ); ?>
					</h3>
					<p class="oasi-lab-contact-box__intro">
						<?php esc_html_e( 'Ordina online e seleziona il ritiro gratuito presso il nostro laboratorio, oppure contattaci per consulenze su spezie rare, miscele su misura e grandi formati.', 'oasidellespezie-child-theme' ); ?>
					</p>
				</div>

				<div class="oasi-lab-contact-box__grid">
					<!-- Indirizzo -->
					<div class="oasi-lab-card">
						<div class="oasi-lab-card__icon" aria-hidden="true">
							<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path><circle cx="12" cy="10" r="3"></circle></svg>
						</div>
						<div class="oasi-lab-card__body">
							<span class="oasi-lab-card__label"><?php esc_html_e( 'Sede Laboratorio', 'oasidellespezie-child-theme' ); ?></span>
							<address class="oasi-lab-card__value oasi-lab-card__value--address">
								<?php echo esc_html( $contact['address'] ); ?>
							</address>
							<a href="<?php echo esc_url( $contact['maps_url'] ); ?>" target="_blank" rel="noopener noreferrer" class="oasi-lab-card__link-action">
								<span><?php esc_html_e( 'Mappa e indicazioni', 'oasidellespezie-child-theme' ); ?></span>
								<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><line x1="7" y1="17" x2="17" y2="7"></line><polyline points="7 7 17 7 17 17"></polyline></svg>
							</a>
						</div>
					</div>

					<!-- Telefono Diretto -->
					<div class="oasi-lab-card">
						<div class="oasi-lab-card__icon" aria-hidden="true">
							<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path></svg>
						</div>
						<div class="oasi-lab-card__body">
							<span class="oasi-lab-card__label"><?php esc_html_e( 'Telefono & WhatsApp', 'oasidellespezie-child-theme' ); ?></span>
							<div class="oasi-lab-card__value">
								<a href="<?php echo esc_url( 'tel:' . $contact['phone_tel'] ); ?>" class="oasi-lab-card__main-link">
									<?php echo esc_html( $contact['phone'] ); ?>
								</a>
							</div>
							<span class="oasi-lab-card__hint"><?php esc_html_e( 'Assistenza per ordini e consigli', 'oasidellespezie-child-theme' ); ?></span>
						</div>
					</div>

					<!-- Email -->
					<div class="oasi-lab-card">
						<div class="oasi-lab-card__icon" aria-hidden="true">
							<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path><polyline points="22,6 12,13 2,6"></polyline></svg>
						</div>
						<div class="oasi-lab-card__body">
							<span class="oasi-lab-card__label"><?php esc_html_e( 'Email Ufficiale', 'oasidellespezie-child-theme' ); ?></span>
							<div class="oasi-lab-card__value">
								<a href="<?php echo esc_url( 'mailto:' . $contact['email'] ); ?>" class="oasi-lab-card__main-link">
									<?php echo esc_html( $contact['email'] ); ?>
								</a>
							</div>
							<span class="oasi-lab-card__hint"><?php esc_html_e( 'Rispondiamo entro 24 ore', 'oasidellespezie-child-theme' ); ?></span>
						</div>
					</div>

					<!-- Orari -->
					<div class="oasi-lab-card">
						<div class="oasi-lab-card__icon" aria-hidden="true">
							<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 16 14"></polyline></svg>
						</div>
						<div class="oasi-lab-card__body">
							<span class="oasi-lab-card__label"><?php esc_html_e( 'Orari di Apertura & Ritiro', 'oasidellespezie-child-theme' ); ?></span>
							<div class="oasi-lab-card__value oasi-lab-card__value--hours">
								<?php echo esc_html( $contact['hours_summary'] ); ?>
							</div>
							<span class="oasi-lab-card__hint"><?php esc_html_e( 'Domenica e festivi chiuso', 'oasidellespezie-child-theme' ); ?></span>
						</div>
					</div>
				</div>

				<div class="oasi-lab-contact-box__actions">
					<a href="<?php echo esc_url( home_url( '/contatto/' ) ); ?>" class="oasi-btn oasi-btn--primary">
						<span><?php esc_html_e( 'Invia un Messaggio', 'oasidellespezie-child-theme' ); ?></span>
						<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg>
					</a>
					<a href="<?php echo esc_url( $contact['maps_url'] ); ?>" target="_blank" rel="noopener noreferrer" class="oasi-btn oasi-btn--outline">
						<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path><circle cx="12" cy="10" r="3"></circle></svg>
						<span><?php esc_html_e( 'Indicazioni Stradali', 'oasidellespezie-child-theme' ); ?></span>
					</a>
				</div>
			</div>
		</div>
	</section>


	<!-- =======================================================================
	     9. ESPLORA LE CATEGORIE PER MACRO-GRUPPI (ACCORDION & TABS)
	     ======================================================================= -->
	<section class="oasi-categories oasi-section" id="esplora-categorie" aria-labelledby="oasi-categories-title">
		<div class="oasi-container">
			<div class="oasi-section-header">
				<span class="oasi-section-eyebrow"><?php esc_html_e( 'Esplorazione Guidata dello Shop', 'oasidellespezie-child-theme' ); ?></span>
				<h2 id="oasi-categories-title" class="oasi-section-title">
					<?php esc_html_e( 'I Mondi Aromatici di Oasi delle Spezie', 'oasidellespezie-child-theme' ); ?>
				</h2>
				<div class="oasi-section-divider"></div>
				<p class="oasi-section-subtitle">
					<?php esc_html_e( 'Seleziona un macro-gruppo per scoprire tutte le categorie dedicate: clicca sul titolo o sul pulsante per accedere direttamente al catalogo.', 'oasidellespezie-child-theme' ); ?>
				</p>
			</div>

			<!-- Navigazione a Schede / Selettore Macro-Gruppi (Desktop & Tablet) -->
			<div class="oasi-macro-tabs-wrapper">
				<div class="oasi-macro-tabs" role="tablist" aria-label="<?php esc_attr_e( 'Macro-Gruppi Categorie', 'oasidellespezie-child-theme' ); ?>">
					<?php $idx = 0; foreach ( $macro_groups as $gid => $group ) : $idx++; $active = ( $idx === 1 ); ?>
						<button type="button"
						        class="oasi-macro-tab <?php echo $active ? 'oasi-macro-tab--active' : ''; ?>"
						        role="tab"
						        id="tab-<?php echo esc_attr( $gid ); ?>"
						        aria-selected="<?php echo $active ? 'true' : 'false'; ?>"
						        aria-controls="panel-<?php echo esc_attr( $gid ); ?>"
						        data-group="<?php echo esc_attr( $gid ); ?>">
							<span class="oasi-macro-tab__icon" aria-hidden="true"><?php echo esc_html( $group['icon'] ); ?></span>
							<span class="oasi-macro-tab__content">
								<span class="oasi-macro-tab__title"><?php echo esc_html( $group['short_name'] ); ?></span>
								<span class="oasi-macro-tab__badge" aria-label="<?php echo esc_attr( sprintf( _n( '%s categoria', '%s categorie', $group['cat_count'], 'oasidellespezie-child-theme' ), $group['cat_count'] ) ); ?>">
									<?php echo esc_html( $group['cat_count'] ); ?>
								</span>
							</span>
						</button>
					<?php endforeach; ?>
				</div>
			</div>

			<!-- Struttura Fisarmonica & Pannelli Categorie -->
			<div class="oasi-macro-accordion">
				<?php $idx = 0; foreach ( $macro_groups as $gid => $group ) : $idx++; $is_open = ( $idx === 1 ); ?>
					<div class="oasi-macro-group <?php echo $is_open ? 'oasi-macro-group--open' : ''; ?>" 
					     id="group-<?php echo esc_attr( $gid ); ?>"
					     data-group-id="<?php echo esc_attr( $gid ); ?>">

						<!-- Trigger Fisarmonica per Mobile -->
						<button type="button" 
						        class="oasi-macro-accordion__trigger <?php echo $is_open ? 'oasi-macro-accordion__trigger--active' : ''; ?>"
						        aria-expanded="<?php echo $is_open ? 'true' : 'false'; ?>"
						        aria-controls="panel-<?php echo esc_attr( $gid ); ?>"
						        data-group="<?php echo esc_attr( $gid ); ?>">
							<div class="oasi-macro-accordion__trigger-left">
								<span class="oasi-macro-accordion__icon" aria-hidden="true"><?php echo esc_html( $group['icon'] ); ?></span>
								<div class="oasi-macro-accordion__meta">
									<span class="oasi-macro-accordion__title"><?php echo esc_html( $group['name'] ); ?></span>
									<span class="oasi-macro-accordion__count">
										<?php echo esc_html( sprintf( _n( '%s categoria', '%s categorie', $group['cat_count'], 'oasidellespezie-child-theme' ), $group['cat_count'] ) ); ?>
										• <?php echo esc_html( sprintf( __( '%s prodotti', 'oasidellespezie-child-theme' ), number_format_i18n( $group['total_products'] ) ) ); ?>
									</span>
								</div>
							</div>
							<span class="oasi-macro-accordion__arrow" aria-hidden="true">
								<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"></polyline></svg>
							</span>
						</button>

						<!-- Pannello Categorie (Visualizzato al click del gruppo) -->
						<div class="oasi-macro-panel <?php echo $is_open ? 'oasi-macro-panel--active' : ''; ?>"
						     id="panel-<?php echo esc_attr( $gid ); ?>"
						     role="tabpanel"
						     aria-labelledby="tab-<?php echo esc_attr( $gid ); ?>">

							<div class="oasi-macro-panel__intro">
								<div class="oasi-macro-panel__intro-header">
									<span class="oasi-macro-panel__badge"><?php echo esc_html( $group['badge'] ); ?></span>
									<span class="oasi-macro-panel__products-count">
										<?php echo esc_html( sprintf( __( '%s prodotti disponibili', 'oasidellespezie-child-theme' ), number_format_i18n( $group['total_products'] ) ) ); ?>
									</span>
								</div>
								<h3 class="oasi-macro-panel__heading"><?php echo esc_html( $group['name'] ); ?></h3>
								<p class="oasi-macro-panel__desc"><?php echo esc_html( $group['description'] ); ?></p>
							</div>

							<div class="oasi-categories-cards-grid">
								<?php foreach ( $group['categories'] as $cat ) : ?>
									<article class="oasi-cat-item" data-cat-id="<?php echo esc_attr( $cat['id'] ); ?>">
										<a href="<?php echo esc_url( $cat['url'] ); ?>" 
										   class="oasi-cat-item__thumb-wrap" 
										   tabindex="-1" 
										   aria-hidden="true">
											<?php if ( ! empty( $cat['image_url'] ) ) : ?>
												<img src="<?php echo esc_url( $cat['image_url'] ); ?>" 
												     alt="<?php echo esc_attr( $cat['name'] ); ?>" 
												     loading="lazy" 
												     width="320" 
												     height="240" 
												     class="oasi-cat-item__img">
											<?php else : ?>
												<div class="oasi-cat-item__placeholder">
													<span class="oasi-cat-item__placeholder-icon"><?php echo esc_html( $group['icon'] ); ?></span>
												</div>
											<?php endif; ?>
											<span class="oasi-cat-item__count-pill">
												<?php echo esc_html( sprintf( _n( '%s prodotto', '%s prodotti', $cat['count'], 'oasidellespezie-child-theme' ), number_format_i18n( $cat['count'] ) ) ); ?>
											</span>
										</a>

										<div class="oasi-cat-item__body">
											<h4 class="oasi-cat-item__title">
												<a href="<?php echo esc_url( $cat['url'] ); ?>">
													<?php echo esc_html( $cat['name'] ); ?>
												</a>
											</h4>

											<a href="<?php echo esc_url( $cat['url'] ); ?>" 
											   class="oasi-cat-item__cta" 
											   aria-label="<?php echo esc_attr( sprintf( __( 'Esplora la categoria %s', 'oasidellespezie-child-theme' ), $cat['name'] ) ); ?>">
												<span><?php esc_html_e( 'Esplora', 'oasidellespezie-child-theme' ); ?></span>
												<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg>
											</a>
										</div>
									</article>
								<?php endforeach; ?>
							</div>
						</div>

					</div>
				<?php endforeach; ?>
			</div>
		</div>
	</section>


	<!-- =======================================================================
	     10. NEWSLETTER DEL LABORATORIO
	     Hidden until connected to a real newsletter service: the form only showed
	     "Grazie per esserti iscritto!" without subscribing anyone (misleading).
	     Enable with add_filter( 'oasi_show_newsletter', '__return_true' ).
	     ======================================================================= -->
	<?php if ( apply_filters( 'oasi_show_newsletter', false ) ) : ?>
	<section class="oasi-newsletter" aria-label="<?php esc_attr_e( 'Iscrizione alla newsletter', 'oasidellespezie-child-theme' ); ?>">
		<div class="oasi-container">
			<div class="oasi-newsletter__inner">
				<div class="oasi-newsletter__brand">
					<div class="oasi-newsletter__icon" aria-hidden="true">
						<svg width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
							<path d="M10 2v4a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V2"></path>
							<rect x="4" y="8" width="6" height="14" rx="1"></rect>
							<path d="M18 6v2a2 2 0 0 1-2 2h-2"></path>
							<rect x="14" y="10" width="6" height="12" rx="1"></rect>
						</svg>
					</div>
					<h2 class="oasi-newsletter__title">
						Scopri iscrivendoti alla newsletter
					</h2>
				</div>

				<form class="oasi-newsletter__form" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" method="post" onsubmit="event.preventDefault(); this.querySelector('.oasi-newsletter__success').style.display='block'; this.querySelector('.oasi-newsletter__fields').style.display='none';">
					<div class="oasi-newsletter__fields">
						<label for="oasi-newsletter-email" class="screen-reader-text"><?php esc_html_e( 'Il tuo indirizzo email', 'oasidellespezie-child-theme' ); ?></label>
						<input type="email" id="oasi-newsletter-email" name="email" required placeholder="<?php esc_attr_e( 'La tua email...', 'oasidellespezie-child-theme' ); ?>" class="oasi-newsletter__input">
						<button type="submit" class="oasi-newsletter__submit">
							<span><?php esc_html_e( 'Iscriviti', 'oasidellespezie-child-theme' ); ?></span>
						</button>
					</div>
					<div class="oasi-newsletter__success" style="display: none;" role="status">
						<p><?php esc_html_e( 'Grazie per esserti iscritto! Riceverai le nostre novità aromatiche e offerte riservate.', 'oasidellespezie-child-theme' ); ?></p>
					</div>
					<p class="oasi-newsletter__privacy">
						<?php esc_html_e( 'Niente spam. Puoi disiscriverti in qualsiasi momento.', 'oasidellespezie-child-theme' ); ?>
					</p>
				</form>
			</div>
		</div>
	</section>
	<?php endif; ?>

</div>

<?php
get_footer();
