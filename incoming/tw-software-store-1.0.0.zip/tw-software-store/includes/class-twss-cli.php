<?php
if (!defined('ABSPATH')) {
    exit;
}

/** wp tw-store sync|list|link */
class Twss_Cli {
    /**
     * Sincronizza le release con i prodotti.
     *
     * ## OPTIONS
     * [<slug>]
     * : Solo questo plugin.
     * [--dry-run]
     * : Mostra cosa farebbe, senza scrivere.
     * [--force]
     * : Rilegge tutte le release e rielabora anche le versioni già viste.
     */
    public function sync($args, $assoc) {
        $rows = Twss_Sync::run(array(
            'dry' => isset($assoc['dry-run']), 'force' => isset($assoc['force']), 'reprocess' => isset($assoc['force']),
            'slug' => isset($args[0]) ? $args[0] : '',
        ));
        if (is_wp_error($rows)) {
            WP_CLI::error($rows->get_error_message());
        }
        $rows ? WP_CLI\Utils\format_items('table', $rows, array('slug', 'version', 'action', 'notes')) : WP_CLI::success('Nulla da fare.');
    }

    /** Elenca i plugin noti e il loro prodotto. */
    public function list_() {
        $rows = array();
        foreach (Twss_Settings::state() as $slug => $st) {
            $rows[] = array('slug' => $slug, 'type' => $st['type'], 'version' => $st['version'] ?? '', 'product' => $st['product_id'] ?? '');
        }
        WP_CLI\Utils\format_items('table', $rows, array('slug', 'type', 'version', 'product'));
    }

    /**
     * Collega un prodotto esistente a uno slug (testi e prezzo restano a mano).
     *
     * ## OPTIONS
     * <slug>
     * <product_id>
     */
    public function link($args) {
        Twss_Product::link($args[0], (int) $args[1]) ? WP_CLI::success('Collegato.') : WP_CLI::error('Prodotto non trovato.');
    }
}
WP_CLI::add_command('tw-store', 'Twss_Cli', array('shortdesc' => 'tW Software Store'));
