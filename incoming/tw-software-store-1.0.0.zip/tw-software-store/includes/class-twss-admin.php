<?php
if (!defined('ABSPATH')) {
    exit;
}

/** WooCommerce → Software Store: stato dei prodotti, impostazioni e registro. */
class Twss_Admin {
    public static function init() {
        add_action('admin_menu', function () {
            add_submenu_page('woocommerce', __('Software Store', 'tw-software-store'), __('Software Store', 'tw-software-store'),
                'manage_woocommerce', 'tw-software-store', array(__CLASS__, 'page'));
        });
        add_action('admin_post_twss_sync', array(__CLASS__, 'do_sync'));
        add_action('admin_post_twss_save', array(__CLASS__, 'do_save'));
    }

    private static function back($notice) {
        wp_safe_redirect(add_query_arg(array('page' => 'tw-software-store', 'twss' => rawurlencode($notice)), admin_url('admin.php')));
        exit;
    }

    public static function do_sync() {
        if (!current_user_can('manage_woocommerce')) {
            wp_die(esc_html__('Permesso negato.', 'tw-software-store'));
        }
        check_admin_referer('twss_sync');
        delete_option(Twss_Github::ETAG);
        $rows = Twss_Sync::run();
        if (is_wp_error($rows)) {
            self::back($rows->get_error_message());
        }
        /* translators: %d: number of plugins processed */
        self::back(sprintf(_n('%d plugin elaborato.', '%d plugin elaborati.', count($rows), 'tw-software-store'), count($rows)));
    }

    public static function do_save() {
        if (!current_user_can('manage_woocommerce')) {
            wp_die(esc_html__('Permesso negato.', 'tw-software-store'));
        }
        check_admin_referer('twss_save');
        Twss_Settings::save(wp_unslash($_POST)); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- sanitizzato in save()
        self::back(__('Impostazioni salvate.', 'tw-software-store'));
    }

    public static function page() {
        if (!current_user_can('manage_woocommerce')) {
            return;
        }
        $s = Twss_Settings::all();
        $state = Twss_Settings::state();
        $log = get_option(Twss_Settings::LOG, array());
        $plugins = array_filter($state, function ($x) { return isset($x['type']) && 'plugin' === $x['type']; });
        $secret = Twss_Settings::ping_secret();
        echo '<div class="wrap"><h1>' . esc_html__('Software Store', 'tw-software-store') . '</h1>';
        if (isset($_GET['twss'])) { // phpcs:ignore WordPress.Security.NonceVerification
            echo '<div class="notice notice-info is-dismissible"><p>' . esc_html(wp_unslash($_GET['twss'])) . '</p></div>'; // phpcs:ignore
        }
        echo '<p>' . esc_html__('Ogni plugin WordPress pubblicato nel repo delle release diventa da solo un prodotto del negozio e si aggiorna a ogni nuova versione. I temi sono ignorati.', 'tw-software-store') . '</p>';
        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" style="margin:12px 0">';
        wp_nonce_field('twss_sync');
        echo '<input type="hidden" name="action" value="twss_sync"><button class="button button-primary">' . esc_html__('Sincronizza ora', 'tw-software-store') . '</button> ';
        echo '<span class="description">' . esc_html__('Il controllo automatico avviene ogni ora e subito dopo ogni rilascio.', 'tw-software-store') . '</span></form>';

        echo '<h2>' . esc_html__('Plugin nel negozio', 'tw-software-store') . '</h2>';
        if (!$plugins) {
            echo '<p>' . esc_html__('Ancora nessun plugin: premi «Sincronizza ora».', 'tw-software-store') . '</p>';
        } else {
            echo '<table class="widefat striped" style="max-width:900px"><thead><tr><th>' . esc_html__('Plugin', 'tw-software-store') . '</th><th>' . esc_html__('Versione', 'tw-software-store') . '</th><th>' . esc_html__('Prodotto', 'tw-software-store') . '</th><th>' . esc_html__('Stato', 'tw-software-store') . '</th></tr></thead><tbody>';
            foreach ($plugins as $slug => $st) {
                $pid = (int) ($st['product_id'] ?? 0);
                $status = $pid ? get_post_status($pid) : '';
                echo '<tr><td><code>' . esc_html($slug) . '</code></td><td>' . esc_html($st['version'] ?? '') . '</td><td>';
                echo $pid ? '<a href="' . esc_url(get_edit_post_link($pid)) . '">' . esc_html(get_the_title($pid)) . '</a>' : '—';
                echo '</td><td>' . esc_html('publish' === $status ? __('Pubblicato', 'tw-software-store') : ('draft' === $status ? __('Bozza: da rivedere e pubblicare', 'tw-software-store') : '—')) . '</td></tr>';
            }
            echo '</tbody></table>';
        }

        echo '<h2>' . esc_html__('Impostazioni', 'tw-software-store') . '</h2><form method="post" action="' . esc_url(admin_url('admin-post.php')) . '"><input type="hidden" name="action" value="twss_save">';
        wp_nonce_field('twss_save');
        echo '<table class="form-table"><tr><th>' . esc_html__('Prezzo predefinito (CHF)', 'tw-software-store') . '</th><td><input name="price" value="' . esc_attr($s['price']) . '" class="small-text"> <span class="description">' . esc_html__('Solo per i nuovi prodotti: i prezzi già impostati non si toccano mai.', 'tw-software-store') . '</span></td></tr>';
        echo '<tr><th>' . esc_html__('Stato dei nuovi prodotti', 'tw-software-store') . '</th><td><select name="new_status"><option value="draft"' . selected($s['new_status'], 'draft', false) . '>' . esc_html__('Bozza (li rivedo prima di pubblicarli)', 'tw-software-store') . '</option><option value="publish"' . selected($s['new_status'], 'publish', false) . '>' . esc_html__('Pubblicato subito', 'tw-software-store') . '</option></select></td></tr>';
        echo '<tr><th>' . esc_html__('Categoria', 'tw-software-store') . '</th><td><input name="category" value="' . esc_attr($s['category']) . '" class="regular-text"> <span class="description">' . esc_html__('Slug della categoria prodotti (si crea se manca).', 'tw-software-store') . '</span></td></tr>';
        echo '<tr><th>' . esc_html__('Plugin da non vendere', 'tw-software-store') . '</th><td><textarea name="excluded" rows="3" class="large-text">' . esc_textarea($s['excluded']) . '</textarea><p class="description">' . esc_html__('Uno slug per riga (plugin fatti su misura per un cliente). In alternativa "shop": false nel details.json del plugin.', 'tw-software-store') . '</p></td></tr>';
        echo '<tr><th>' . esc_html__('Elimina dati alla disinstallazione', 'tw-software-store') . '</th><td><label><input type="checkbox" name="delete_on_uninstall" value="1"' . checked(!empty($s['delete_on_uninstall']), true, false) . '> ' . esc_html__('Sì (prodotti e ordini restano comunque)', 'tw-software-store') . '</label></td></tr></table>';
        echo '<p><button class="button button-primary">' . esc_html__('Salva', 'tw-software-store') . '</button></p></form>';

        echo '<h2>' . esc_html__('Sincronizzazione immediata dal repo', 'tw-software-store') . '</h2><p class="description">' . esc_html__('Segreto per il workflow GitHub (secret TW_STORE_SECRET del repo delle release). Senza, i prodotti si aggiornano comunque entro un’ora.', 'tw-software-store') . '</p><p><code>' . esc_html(substr($secret, 0, 6) . str_repeat('•', 20)) . '</code> ' . esc_html__('(mostrato per intero solo via WP-CLI: wp eval "echo Twss_Settings::ping_secret();")', 'tw-software-store') . '</p>';

        echo '<h2>' . esc_html__('Registro', 'tw-software-store') . '</h2>';
        if (!$log) {
            echo '<p>' . esc_html__('Vuoto.', 'tw-software-store') . '</p>';
        } else {
            echo '<table class="widefat striped" style="max-width:900px"><tbody>';
            foreach (array_slice($log, 0, 50) as $e) {
                echo '<tr><td>' . esc_html(wp_date('d.m.Y H:i', $e['t'])) . '</td><td><code>' . esc_html($e['slug']) . '</code></td><td' . ('error' === $e['level'] ? ' style="color:#b32d2e"' : '') . '>' . esc_html($e['msg']) . '</td></tr>';
            }
            echo '</tbody></table>';
        }
        echo '</div>';
    }
}
