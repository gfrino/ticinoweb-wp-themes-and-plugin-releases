<?php
if (!defined('ABSPATH')) {
    exit;
}

/** Scheda prodotto: tab «Versioni e changelog» con compatibilità. */
class Twss_Frontend {
    public static function init() {
        add_filter('woocommerce_product_tabs', array(__CLASS__, 'tabs'));
    }

    public static function tabs($tabs) {
        global $product;
        if (!$product || !get_post_meta($product->get_id(), '_twss_slug', true) || !get_post_meta($product->get_id(), '_twss_version', true)) {
            return $tabs;
        }
        $tabs['twss_versions'] = array(
            'title'    => __('Versioni e changelog', 'tw-software-store'),
            'priority' => 25,
            'callback' => array(__CLASS__, 'render'),
        );
        return $tabs;
    }

    public static function render() {
        global $product;
        $id = $product->get_id();
        $ver = get_post_meta($id, '_twss_version', true);
        $date = get_post_meta($id, '_twss_released', true);
        $compat = get_post_meta($id, '_twss_compat', true);
        echo '<div class="twss-versions">';
        echo '<p><strong>' . esc_html__('Ultima versione', 'tw-software-store') . ':</strong> ' . esc_html($ver);
        if ($date) {
            echo ' · ' . esc_html(wp_date(get_option('date_format'), strtotime($date)));
        }
        echo '</p><p>' . esc_html__('Licenza perpetua: si paga una volta sola, nessun canone annuale.', 'tw-software-store') . '</p>';
        if (is_array($compat) && $compat) {
            echo '<h3>' . esc_html__('Compatibilità', 'tw-software-store') . '</h3><ul>';
            foreach ($compat as $k => $v) {
                /* translators: 1: software (WordPress, PHP…), 2: minimum version */
                echo '<li>' . esc_html(sprintf(__('%1$s %2$s o successivo', 'tw-software-store'), $k, $v)) . '</li>';
            }
            echo '</ul>';
        }
        $log = get_post_meta($id, '_twss_changelog', true);
        if ($log) {
            echo '<h3>' . esc_html__('Novità', 'tw-software-store') . '</h3>' . wp_kses_post($log);
        }
        echo '</div>';
    }
}
