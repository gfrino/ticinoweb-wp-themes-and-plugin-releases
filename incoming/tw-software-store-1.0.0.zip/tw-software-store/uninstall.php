<?php
/**
 * Prodotti e ordini restano sempre. Opzioni ed eventi si rimuovono solo se l'utente l'ha scelto.
 *
 * @package tw-software-store
 */
if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}
$twss = get_option('twss_settings', array());
wp_clear_scheduled_hook('twss_sync');
if (is_array($twss) && !empty($twss['delete_on_uninstall'])) {
    foreach (array('twss_settings', 'twss_state', 'twss_log', 'twss_etag') as $opt) {
        delete_option($opt);
    }
}
