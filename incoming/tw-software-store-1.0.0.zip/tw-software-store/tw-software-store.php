<?php
/**
 * Plugin Name:       tW Software Store
 * Plugin URI:        https://ticinoweb.com
 * Description:       Pubblica da solo nel negozio WooCommerce ogni plugin WordPress che ticinoWEB rilascia: crea il prodotto alla prima release e lo tiene aggiornato (versione, novità, file scaricabile) a ogni nuova versione. Prezzo e licenza perpetua di default, i temi sono ignorati.
 * Version:           1.0.0
 * Requires at least: 6.2
 * Requires PHP:      7.4
 * Requires Plugins:  woocommerce
 * Author:            ticinoWEB
 * License:           Proprietary — Licenza d'uso esclusiva ticinoWEB
 * Text Domain:       tw-software-store
 * Update URI:        https://github.com/gfrino/ticinoweb-wp-themes-and-plugin-releases
 *
 * @package tw-software-store
 */

if (!defined('ABSPATH')) {
    exit;
}

define('TWSS_VERSION', '1.0.0');
define('TWSS_FILE', __FILE__);
define('TWSS_DIR', plugin_dir_path(__FILE__));
// Version of the bundled includes/tw-release-updater.php (keep in sync with its header).
define('TWSS_RELEASE_UPDATER_VERSION', '1.2.0');

// Repo pubblico delle release da cui nascono i prodotti (owner/repo).
if (!defined('TWSS_REPO')) {
    define('TWSS_REPO', 'gfrino/ticinoweb-wp-themes-and-plugin-releases');
}

require_once TWSS_DIR . 'includes/tw-release-updater.php';
require_once TWSS_DIR . 'includes/class-twss-settings.php';
require_once TWSS_DIR . 'includes/class-twss-markdown.php';
require_once TWSS_DIR . 'includes/class-twss-github.php';
require_once TWSS_DIR . 'includes/class-twss-package.php';
require_once TWSS_DIR . 'includes/class-twss-product.php';
require_once TWSS_DIR . 'includes/class-twss-sync.php';
require_once TWSS_DIR . 'includes/class-twss-frontend.php';
require_once TWSS_DIR . 'includes/class-twss-rest.php';
if (is_admin()) {
    require_once TWSS_DIR . 'includes/class-twss-admin.php';
    Twss_Admin::init();
}
if (defined('WP_CLI') && WP_CLI) {
    require_once TWSS_DIR . 'includes/class-twss-cli.php';
}

Twss_Frontend::init();
Twss_Rest::init();
add_action(Twss_Sync::HOOK, array('Twss_Sync', 'cron'));

/** Sincronizzazione oraria: si programma da sola se manca (attivazione, aggiornamento, cron perso). */
add_action('init', function () {
    if (!wp_next_scheduled(Twss_Sync::HOOK)) {
        wp_schedule_event(time() + 120, 'hourly', Twss_Sync::HOOK);
    }
});

register_deactivation_hook(__FILE__, function () {
    wp_clear_scheduled_hook(Twss_Sync::HOOK);
});

/** Aggiornatore condiviso come mu-plugin (vedi tw-translate-plus). */
add_action('admin_init', function () {
    if (!class_exists('TW_Release_Updater') || TW_Release_Updater::mu_is_current(TWSS_RELEASE_UPDATER_VERSION)) {
        return;
    }
    if (!current_user_can(is_multisite() ? 'manage_network_plugins' : 'activate_plugins') || get_site_transient('twss_release_updater_failed')) {
        return;
    }
    $result = TW_Release_Updater::install_mu(TWSS_DIR . 'includes/tw-release-updater.php');
    if (is_wp_error($result)) {
        set_site_transient('twss_release_updater_failed', $result->get_error_message(), 12 * HOUR_IN_SECONDS);
    }
}, 20);
