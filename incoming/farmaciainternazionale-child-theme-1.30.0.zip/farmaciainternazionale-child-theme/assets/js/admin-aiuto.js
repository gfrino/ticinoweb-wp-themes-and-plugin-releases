/*
 * Pannello «Badge Aiuto»: aggiungere, togliere e riordinare le domande.
 *
 * PERCHE' LA RINUMERAZIONE E' IL CUORE DI QUESTO FILE: WordPress riceve queste
 * domande come un array, e la posizione sta scritta nel nome di ogni campo
 * (`fi_aiuto_voci[2][testo]`). Dopo una rimozione o uno spostamento i nomi non
 * corrispondono piu' all'ordine visibile, e senza rinumerare si salverebbe un
 * elenco diverso da quello che si vede. Quindi si rinumera dopo ogni modifica —
 * e di nuovo appena prima dell'invio, per sicurezza.
 *
 * La riga nuova non e' scritta qui: si copia dal <template> che il PHP ha
 * stampato con gli stessi campi delle altre. Cosi' non esistono due versioni
 * dello stesso modulo da tenere allineate a mano.
 */
document.addEventListener('DOMContentLoaded', function () {
    var form = document.getElementById('fi_aiuto_form');
    if (!form) {
        return;
    }

    var lista = document.getElementById('fi_aiuto_lista');
    var modello = document.getElementById('fi_aiuto_modello');
    var aggiungi = document.getElementById('fi_aiuto_aggiungi');
    if (!lista || !modello || !aggiungi) {
        return;
    }

    var NOME = 'fi_aiuto_voci';

    function righe() {
        return Array.prototype.slice.call(lista.querySelectorAll('.fi-ai-item'));
    }

    function rinumera() {
        var tutte = righe();

        tutte.forEach(function (riga, indice) {
            var numero = riga.querySelector('.fi-ai-numero');
            if (numero) {
                numero.textContent = indice + 1;
            }

            riga.querySelectorAll('[data-field]').forEach(function (campo) {
                campo.name = NOME + '[' + indice + '][' + campo.dataset.field + ']';
            });

            /* Le frecce ai due estremi non hanno dove andare: spente, non
               nascoste, cosi' i pulsanti non ballano da una riga all'altra. */
            var su = riga.querySelector('.fi-ai-su');
            var giu = riga.querySelector('.fi-ai-giu');
            if (su) {
                su.disabled = 0 === indice;
            }
            if (giu) {
                giu.disabled = indice === tutte.length - 1;
            }
        });
    }

    /**
     * Riporta il fuoco su un pulsante dopo aver spostato la sua riga.
     *
     * Senza questo, chi naviga da tastiera perde il punto in cui era: lo
     * spostamento stacca e riattacca l'elemento, e il browser rimanda il fuoco
     * all'inizio della pagina.
     */
    function riprendiFuoco(riga, selettore) {
        var bersaglio = riga.querySelector(selettore);
        if (bersaglio && !bersaglio.disabled) {
            bersaglio.focus();
            return;
        }
        var alternativa = riga.querySelector('.fi-ai-su:not([disabled]), .fi-ai-giu:not([disabled])');
        if (alternativa) {
            alternativa.focus();
        }
    }

    aggiungi.addEventListener('click', function () {
        var copia = modello.content.cloneNode(true);

        /* L'indice vero lo mette rinumera(): qui basta che i nomi siano distinti
           da quelli delle righe esistenti, altrimenti un campo sovrascriverebbe
           l'altro nell'attimo fra l'inserimento e la rinumerazione. */
        copia.querySelectorAll('[data-field]').forEach(function (campo) {
            campo.name = campo.name.replace('__i__', 'nuova');
        });

        lista.appendChild(copia);
        rinumera();

        var ultima = righe().pop();
        if (ultima) {
            var primoCampo = ultima.querySelector('[data-field="voce"]');
            if (primoCampo) {
                primoCampo.focus();
            }
            ultima.scrollIntoView({ block: 'nearest' });
        }
    });

    form.addEventListener('click', function (evento) {
        var pulsante = evento.target.closest('.fi-ai-su, .fi-ai-giu, .fi-ai-togli');
        if (!pulsante) {
            return;
        }

        var riga = pulsante.closest('.fi-ai-item');
        if (!riga) {
            return;
        }

        if (pulsante.classList.contains('fi-ai-togli')) {
            var voce = riga.querySelector('[data-field="voce"]');
            var etichetta = voce && voce.value ? '«' + voce.value + '»' : 'questa domanda';
            if (!window.confirm('Rimuovere ' + etichetta + '? Per nasconderla senza perdere il testo puoi invece spegnere l’interruttore Attiva.')) {
                return;
            }
            riga.remove();
            rinumera();
            return;
        }

        if (pulsante.classList.contains('fi-ai-su')) {
            var precedente = riga.previousElementSibling;
            if (precedente) {
                lista.insertBefore(riga, precedente);
            }
        } else {
            var successiva = riga.nextElementSibling;
            if (successiva) {
                lista.insertBefore(successiva, riga);
            }
        }

        rinumera();
        riprendiFuoco(riga, pulsante.classList.contains('fi-ai-su') ? '.fi-ai-su' : '.fi-ai-giu');
    });

    form.addEventListener('input', function (evento) {
        if ('voce' !== evento.target.dataset.field) {
            return;
        }
        var riga = evento.target.closest('.fi-ai-item');
        if (!riga) {
            return;
        }
        var vivo = riga.querySelector('.fi-ai-titolo-vivo');
        if (vivo) {
            vivo.textContent = evento.target.value || 'Nuova domanda';
        }
    });

    /* Il segnaposto del pulsante cambia col modo di contatto: se non si scrive
       niente, il sito usera' quella scritta, e va vista prima di salvare. */
    form.addEventListener('change', function (evento) {
        if ('contatto' !== evento.target.dataset.field) {
            return;
        }
        var riga = evento.target.closest('.fi-ai-item');
        var pulsante = riga && riga.querySelector('[data-field="pulsante"]');
        if (pulsante) {
            pulsante.placeholder = 'telefono' === evento.target.value
                ? (form.dataset.predefTelefono || '')
                : (form.dataset.predefEmail || '');
        }
    });

    form.addEventListener('submit', rinumera);
    rinumera();
});
