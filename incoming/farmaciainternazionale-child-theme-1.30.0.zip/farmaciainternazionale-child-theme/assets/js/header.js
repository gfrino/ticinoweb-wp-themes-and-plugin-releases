document.addEventListener('DOMContentLoaded', () => {
    const header = document.getElementById('fi-main-header');
    const mobileToggle = document.getElementById('fi-mobile-toggle');
    const mobileOverlay = document.getElementById('fi-mobile-overlay');
    const body = document.body;

    // --- STICKY HEADER LOGIC ---
    function handleScroll() {
        if (window.scrollY > 50) {
            header.classList.add('fi-header-scrolled');
        } else {
            header.classList.remove('fi-header-scrolled');
        }
    }
    
    // Initial check and scroll event
    handleScroll();
    window.addEventListener('scroll', handleScroll, { passive: true });

    // --- MOBILE MENU LOGIC ---
    function toggleMobileMenu() {
        const isExpanded = mobileToggle.getAttribute('aria-expanded') === 'true';
        
        mobileToggle.setAttribute('aria-expanded', !isExpanded);
        mobileToggle.classList.toggle('is-active');
        mobileOverlay.classList.toggle('is-active');
        
        // Prevent body scrolling when menu is open
        if (!isExpanded) {
            body.style.overflow = 'hidden';
        } else {
            body.style.overflow = '';
        }
    }

    if (mobileToggle && mobileOverlay) {
        mobileToggle.addEventListener('click', toggleMobileMenu);

        // Close menu when clicking on a link
        const mobileLinks = mobileOverlay.querySelectorAll('a');
        mobileLinks.forEach(link => {
            link.addEventListener('click', () => {
                if (mobileToggle.classList.contains('is-active')) {
                    toggleMobileMenu();
                }
            });
        });

        // Close menu when clicking outside (on the overlay background)
        mobileOverlay.addEventListener('click', (e) => {
            if (e.target === mobileOverlay) {
                toggleMobileMenu();
            }
        });
    }

    // --- GLOBAL REVEAL ANIMATIONS ---
    const revealElements = document.querySelectorAll('.reveal-up');
    if (revealElements.length > 0) {
        const revealObserver = new IntersectionObserver((entries, observer) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('is-visible');
                    observer.unobserve(entry.target);
                }
            });
        }, { 
            root: null, 
            rootMargin: '0px 0px -10% 0px', 
            threshold: 0.1 
        });
        
        revealElements.forEach(el => {
            revealObserver.observe(el);
        });
    }
});
