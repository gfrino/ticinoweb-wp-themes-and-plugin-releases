/*
 * Pannello "Come possiamo aiutarti".
 *
 * MIGLIORAMENTO PROGRESSIVO. La pastiglia nasce nel markup come collegamento
 * alla pagina Contatti: se questo file non arriva, cliccarla porta comunque a
 * indirizzo, orari e recapiti. Qui la si trasforma in un comando che apre il
 * pannello, e solo da qui il documento riceve la marca `data-fi-aiuto-js` che
 * il CSS aspetta per dargli l'aspetto di un pulsante.
 *
 * IL PANNELLO E' UN DIALOGO: mentre e' aperto il fuoco resta dentro, Escape lo
 * chiude e alla chiusura il fuoco torna sulla pastiglia. Senza questo, chi
 * naviga da tastiera lo aprirebbe e poi continuerebbe a tabulare nella pagina
 * sotto, senza capire dove e' finito.
 */
(function () {
	'use strict';

	var radice = document.querySelector('[data-fi-aiuto]');
	if (!radice) {
		return;
	}

	var pastiglia = radice.querySelector('[data-fi-aiuto-apri]');
	var pannello = radice.querySelector('[data-fi-aiuto-pannello]');
	var chiudi = radice.querySelector('[data-fi-aiuto-chiudi]');
	var elenco = radice.querySelector('[data-fi-aiuto-elenco]');
	var voci = radice.querySelectorAll('[data-fi-aiuto-va]');
	var risposte = radice.querySelectorAll('[data-fi-aiuto-risposta]');
	var indietro = radice.querySelectorAll('[data-fi-aiuto-indietro]');

	if (!pastiglia || !pannello || !elenco) {
		return;
	}

	document.documentElement.setAttribute('data-fi-aiuto-js', '');

	/*
	 * Da collegamento a comando. Si toglie href perche' un elemento con href
	 * resta annunciato come collegamento anche con role="button": meglio un
	 * <a> senza href, che gli screen reader trattano da comando.
	 */
	pastiglia.removeAttribute('href');
	pastiglia.setAttribute('role', 'button');
	pastiglia.setAttribute('tabindex', '0');
	pastiglia.setAttribute('aria-expanded', 'false');

	var aperto = false;

	function mostraElenco() {
		elenco.hidden = false;
		Array.prototype.forEach.call(risposte, function (r) {
			r.hidden = true;
		});
	}

	function mostraRisposta(id) {
		elenco.hidden = true;
		Array.prototype.forEach.call(risposte, function (r) {
			var suo = r.getAttribute('data-fi-aiuto-risposta') === id;
			r.hidden = !suo;
			if (suo) {
				/*
				 * Il fuoco va sul titolo della risposta, non sul primo pulsante:
				 * chi usa uno screen reader deve sentire di che cosa si parla
				 * prima di sentire che c'e' un pulsante per contattare.
				 */
				var titolo = r.querySelector('.fi-aiuto__risposta-titolo');
				if (titolo) {
					titolo.setAttribute('tabindex', '-1');
					titolo.focus();
				}
			}
		});
	}

	function apri() {
		pannello.hidden = false;
		pastiglia.setAttribute('aria-expanded', 'true');
		aperto = true;
		mostraElenco();
		var prima = radice.querySelector('[data-fi-aiuto-va]');
		if (prima) {
			prima.focus();
		}
	}

	function chiudiPannello() {
		pannello.hidden = true;
		pastiglia.setAttribute('aria-expanded', 'false');
		aperto = false;
		mostraElenco();
		pastiglia.focus();
	}

	pastiglia.addEventListener('click', function (e) {
		e.preventDefault();
		if (aperto) {
			chiudiPannello();
		} else {
			apri();
		}
	});

	/* Un <a> senza href non risponde da solo a Spazio e Invio: glielo si insegna. */
	pastiglia.addEventListener('keydown', function (e) {
		if (' ' === e.key || 'Enter' === e.key) {
			e.preventDefault();
			pastiglia.click();
		}
	});

	if (chiudi) {
		chiudi.addEventListener('click', chiudiPannello);
	}

	Array.prototype.forEach.call(voci, function (v) {
		v.addEventListener('click', function () {
			mostraRisposta(v.getAttribute('data-fi-aiuto-va'));
		});
	});

	Array.prototype.forEach.call(indietro, function (b) {
		b.addEventListener('click', function () {
			mostraElenco();
			var prima = radice.querySelector('[data-fi-aiuto-va]');
			if (prima) {
				prima.focus();
			}
		});
	});

	document.addEventListener('keydown', function (e) {
		if (!aperto) {
			return;
		}

		if ('Escape' === e.key) {
			chiudiPannello();
			return;
		}

		if ('Tab' !== e.key) {
			return;
		}

		/*
		 * Il fuoco gira dentro il pannello. La lista si ricalcola a ogni Tab
		 * perche' cambia: nell'elenco ci sono otto voci, nella risposta un
		 * paio di pulsanti, e una lista salvata all'apertura sarebbe sbagliata
		 * un attimo dopo.
		 */
		var fuoco = pannello.querySelectorAll('button, [href]');
		var vivi = Array.prototype.filter.call(fuoco, function (el) {
			return null !== el.offsetParent;
		});
		if (!vivi.length) {
			return;
		}

		var primo = vivi[0];
		var ultimo = vivi[vivi.length - 1];

		if (e.shiftKey && document.activeElement === primo) {
			e.preventDefault();
			ultimo.focus();
		} else if (!e.shiftKey && document.activeElement === ultimo) {
			e.preventDefault();
			primo.focus();
		}
	});

	/* Un clic fuori chiude, come si aspetta chiunque abbia mai usato un pannello. */
	document.addEventListener('click', function (e) {
		if (aperto && !radice.contains(e.target)) {
			chiudiPannello();
		}
	});
}());
