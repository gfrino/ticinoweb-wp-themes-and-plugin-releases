/*
 * Pannello «Immagini del sito»: il selettore della Libreria media.
 *
 * Ogni riquadro contiene un campo nascosto con l'ID dell'allegato, l'anteprima e
 * due pulsanti. Aprire la Libreria, scegliere, aggiornare l'anteprima: niente
 * viene salvato finche' non si preme «Salva immagini», come in qualunque altra
 * pagina di impostazioni di WordPress.
 *
 * PERCHE' wp.media E NON UN CAMPO DOVE INCOLLARE UN INDIRIZZO: e' lo strumento
 * che chi pubblica usa gia' per ogni immagine del sito, sa cercarci dentro e sa
 * caricare da li'. E restituisce un ID, che e' il dato che vogliamo salvare —
 * un indirizzo incollato a mano si rompe alla prima migrazione.
 */
(function ($) {
    'use strict';

    $(function () {
        var $form = $('#fi_immagini_form');
        if (!$form.length) {
            return;
        }

        /* Un solo pannello per riquadro, tenuto da parte: riaprirlo ricorda la
           cartella in cui si era arrivati invece di ripartire dall'inizio. */
        var pannelli = [];

        function aggiornaAnteprima($riquadro, allegato) {
            var $anteprima = $riquadro.find('[data-fi-media-anteprima]');

            if (!allegato) {
                $anteprima.html('<span class="dashicons dashicons-format-image" aria-hidden="true"></span>');
                return;
            }

            /* Il formato medio se c'e', altrimenti l'originale: in un riquadro di
               anteprima non serve scaricare un file da tre megabyte. */
            var url = allegato.url;
            if (allegato.sizes && allegato.sizes.medium) {
                url = allegato.sizes.medium.url;
            }

            $anteprima.html($('<img>', { src: url, alt: '' }));
        }

        function apriLibreria($riquadro, indice) {
            if (!pannelli[indice]) {
                pannelli[indice] = wp.media({
                    title: 'Scegli l’immagine',
                    button: { text: 'Usa questa immagine' },
                    library: { type: 'image' },
                    multiple: false
                });

                pannelli[indice].on('select', function () {
                    var allegato = pannelli[indice].state().get('selection').first().toJSON();

                    $riquadro.find('[data-fi-media-valore]').val(allegato.id);
                    aggiornaAnteprima($riquadro, allegato);

                    $riquadro.find('[data-fi-media-scegli]').text('Cambia');
                    $riquadro.find('[data-fi-media-svuota]').prop('disabled', false);
                    /* L'avviso della foto d'archivio non ha piu' senso: e' stata
                       appena sostituita. */
                    $riquadro.find('[data-fi-media-avviso]').remove();
                });
            }

            pannelli[indice].open();
        }

        $form.on('click', '[data-fi-media-scegli]', function (evento) {
            evento.preventDefault();
            var $riquadro = $(this).closest('[data-fi-media]');
            apriLibreria($riquadro, $form.find('[data-fi-media]').index($riquadro));
        });

        $form.on('click', '[data-fi-media-svuota]', function (evento) {
            evento.preventDefault();

            var $riquadro = $(this).closest('[data-fi-media]');
            $riquadro.find('[data-fi-media-valore]').val('');
            aggiornaAnteprima($riquadro, null);
            $riquadro.find('[data-fi-media-scegli]').text('Scegli dalla Libreria media');
            $(this).prop('disabled', true);
        });
    });
})(jQuery);
