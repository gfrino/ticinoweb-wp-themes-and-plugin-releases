document.addEventListener('DOMContentLoaded', function() {
    
    // 1. Reveal Animations on Scroll (for all sections and hero content)
    const revealElements = document.querySelectorAll('.reveal-up');
    const revealObserver = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('is-visible');
                // Optional: stop observing once revealed
                observer.unobserve(entry.target);
            }
        });
    }, { 
        root: null, 
        rootMargin: '0px 0px -10% 0px', 
        threshold: 0.1 
    });
    
    revealElements.forEach(el => {
        revealObserver.observe(el);
    });

    // 2. Galleria intro: dissolvenza fra una foto e l'altra
    //    Prima scorreva di lato in continuazione (speed 5000, delay 0): qui
    //    ogni foto resta ferma 3s e passa alla successiva con un crossfade,
    //    non uno scivolamento.
    if (typeof Swiper !== 'undefined' && document.querySelector('.intro-infinite-swiper')) {
        new Swiper('.intro-infinite-swiper', {
            loop: true,
            effect: 'fade',
            fadeEffect: { crossFade: true },
            speed: 1000,
            autoplay: {
                delay: 3000,
                disableOnInteraction: false,
            },
            slidesPerView: 1,
            spaceBetween: 0,
            allowTouchMove: false,
        });
    }

    // Le animazioni degli aloni (glows) sono interamente gestite tramite CSS keyframes 
    // (@keyframes float-glow) per garantire le massime performance e fluidità senza sovraccaricare il JS.
});
