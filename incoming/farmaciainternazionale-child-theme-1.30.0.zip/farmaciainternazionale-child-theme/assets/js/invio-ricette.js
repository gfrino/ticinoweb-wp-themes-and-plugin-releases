/*
 * Modulo di invio ricette: scelta, elenco e rimozione dei documenti.
 *
 * IL PROBLEMA CHE RISOLVE QUESTO FILE. Un campo `<input type="file" multiple>`
 * non permette di togliere un singolo documento: la sua lista e' di sola
 * lettura, e riaprire il selettore SOSTITUISCE tutto quello che c'era. Chi
 * sceglieva quattro foto e sbagliava la terza doveva ricominciare da capo.
 *
 * COME SI AGGIRA. Qui la lista dei file la tiene il JavaScript, e il campo viene
 * ricostruito da quella tramite DataTransfer — l'unico modo consentito di
 * scrivere in `input.files`. Effetti collaterali graditi: si possono aggiungere
 * documenti in piu' riprese senza perdere i precedenti, e si puo' rimuoverne uno
 * solo.
 *
 * SENZA JAVASCRIPT il campo resta un normale campo a scelta multipla: si
 * scelgono i file e si invia. Si perde solo la comodita' di toglierne uno.
 */
document.addEventListener('DOMContentLoaded', function () {
    const form = document.querySelector('.fi-rx-form');
    if (!form) return;

    const maxBytes = Number(form.dataset.maxBytes || 0);
    const maxFiles = Number(form.dataset.maxFiles || 0);
    const maxTotalBytes = Number(form.dataset.maxTotalBytes || 0);
    const allowedTypes = ['image/jpeg', 'image/png', 'application/pdf'];
    const errorBox = form.querySelector('.fi-rx-client-error');
    const submit = form.querySelector('.fi-rx-submit');

    /* Se il browser non sa costruire un DataTransfer non si puo' riscrivere il
       campo: meglio lasciare il comportamento nativo che offrire pulsanti di
       rimozione che non rimuovono niente. */
    let sostituzioneSupportata = true;
    try {
        new DataTransfer();
    } catch (e) {
        sostituzioneSupportata = false;
    }

    function formatSize(bytes) {
        return bytes >= 1048576
            ? (bytes / 1048576).toFixed(1) + ' MB'
            : Math.max(1, Math.round(bytes / 1024)) + ' KB';
    }

    function showError(message) {
        errorBox.textContent = message;
        errorBox.classList.add('is-visible');
    }

    function nascondiErrore() {
        errorBox.classList.remove('is-visible');
    }

    /* Un file e' "lo stesso" se combaciano nome, peso e data di modifica: basta
       a non inserire due volte lo stesso documento scelto per sbaglio. */
    function impronta(file) {
        return file.name + '|' + file.size + '|' + (file.lastModified || 0);
    }

    const campi = Array.from(form.querySelectorAll('input[type="file"]')).map(function (input) {
        return {
            input: input,
            upload: input.closest('.fi-rx-upload'),
            meta: input.closest('.fi-rx-upload').querySelector('.fi-rx-file-meta'),
            elenco: form.querySelector('[data-fi-rx-elenco="' + input.id + '"]'),
            scelti: [],
        };
    });

    function pesoTotale() {
        return campi.reduce(function (somma, c) {
            return somma + c.scelti.reduce(function (s, f) { return s + f.size; }, 0);
        }, 0);
    }

    /**
     * Riscrive il campo file a partire dalla lista tenuta in memoria.
     * E' l'unico punto che tocca input.files.
     */
    function riscriviCampo(c) {
        const dt = new DataTransfer();
        c.scelti.forEach(function (f) { dt.items.add(f); });
        c.input.files = dt.files;
    }

    function disegna(c) {
        const n = c.scelti.length;
        c.elenco.innerHTML = '';
        c.elenco.hidden = 0 === n;
        c.upload.classList.toggle('has-file', n > 0);

        if (0 === n) {
            c.meta.textContent = '';
            return;
        }

        const peso = c.scelti.reduce(function (s, f) { return s + f.size; }, 0);
        c.meta.textContent = 1 === n
            ? '1 documento · ' + formatSize(peso)
            : n + ' documenti · ' + formatSize(peso);

        c.scelti.forEach(function (file, i) {
            const li = document.createElement('li');
            li.className = 'fi-rx-elenco-riga';

            const nome = document.createElement('span');
            nome.className = 'fi-rx-elenco-nome';
            nome.textContent = file.name;

            const dim = document.createElement('span');
            dim.className = 'fi-rx-elenco-dim';
            dim.textContent = formatSize(file.size);

            const via = document.createElement('button');
            via.type = 'button';
            via.className = 'fi-rx-elenco-via';
            /* L'etichetta nomina il documento: con dieci pulsanti «Rimuovi»
               identici, chi usa uno screen reader non saprebbe quale sta per
               premere. */
            via.setAttribute('aria-label', 'Rimuovi ' + file.name);
            via.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false">'
                + '<path d="M6 6l12 12M18 6L6 18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>';
            via.addEventListener('click', function () {
                rimuovi(c, i);
            });

            li.appendChild(nome);
            li.appendChild(dim);
            li.appendChild(via);
            c.elenco.appendChild(li);
        });
    }

    function rimuovi(c, i) {
        const toltoNome = c.scelti[i] ? c.scelti[i].name : '';
        c.scelti.splice(i, 1);
        riscriviCampo(c);
        c.upload.classList.remove('has-error');
        nascondiErrore();
        disegna(c);

        /*
         * Il fuoco non deve cadere nel vuoto: dopo aver premuto la X su una riga
         * che spariva, senza questo si tornerebbe all'inizio della pagina.
         * Si va sul pulsante che ha preso il posto di quello premuto, o
         * sull'ultimo rimasto, o in mancanza di righe sul campo stesso.
         */
        const restanti = c.elenco.querySelectorAll('.fi-rx-elenco-via');
        if (restanti.length) {
            (restanti[i] || restanti[restanti.length - 1]).focus();
        } else {
            c.input.focus();
        }

        if (toltoNome) {
            c.meta.textContent = c.scelti.length
                ? c.meta.textContent
                : 'Nessun documento scelto';
        }
    }

    function aggiungi(c, nuovi) {
        nascondiErrore();
        c.upload.classList.remove('has-error');

        const scartati = [];
        const gia = c.scelti.map(impronta);

        nuovi.forEach(function (file) {
            if (c.scelti.length >= maxFiles && maxFiles) {
                scartati.push({ nome: file.name, motivo: 'troppi' });
                return;
            }
            if (file.type && !allowedTypes.includes(file.type)) {
                scartati.push({ nome: file.name, motivo: 'formato' });
                return;
            }
            if (maxBytes && file.size > maxBytes) {
                scartati.push({ nome: file.name, motivo: 'peso' });
                return;
            }
            if (gia.includes(impronta(file))) {
                scartati.push({ nome: file.name, motivo: 'doppio' });
                return;
            }
            c.scelti.push(file);
            gia.push(impronta(file));
        });

        /* Il tetto complessivo si controlla a scelta conclusa: riguarda la somma
           dei due campi, non il singolo file. */
        while (maxTotalBytes && pesoTotale() > maxTotalBytes && c.scelti.length > 1) {
            const ultimo = c.scelti.pop();
            scartati.push({ nome: ultimo.name, motivo: 'totale' });
        }

        riscriviCampo(c);
        disegna(c);

        if (scartati.length) {
            const motivi = {
                troppi: 'oltre il massimo di ' + maxFiles + ' documenti',
                formato: 'formato non ammesso (servono JPG, PNG o PDF)',
                peso: 'più pesante di ' + formatSize(maxBytes),
                doppio: 'già presente nell\'elenco',
                totale: 'i documenti superano insieme ' + formatSize(maxTotalBytes),
            };
            c.upload.classList.add('has-error');
            showError(scartati.map(function (s) {
                return '«' + s.nome + '»: ' + motivi[s.motivo];
            }).join(' · '));
        }
    }

    campi.forEach(function (c) {
        if (!c.elenco || !sostituzioneSupportata) {
            /* Ripiego: nessun elenco, si mostra solo il riepilogo come prima. */
            c.input.addEventListener('change', function () {
                const files = Array.from(c.input.files || []);
                c.upload.classList.toggle('has-file', files.length > 0);
                c.meta.textContent = files.length
                    ? (1 === files.length ? files[0].name + ' · ' + formatSize(files[0].size)
                                          : files.length + ' documenti')
                    : '';
            });
            return;
        }

        c.input.addEventListener('change', function () {
            /* I file arrivati ora vanno letti PRIMA di riscrivere il campo,
               perche' riscriverlo azzera questa stessa lista. */
            const nuovi = Array.from(c.input.files || []);
            if (!nuovi.length) return;
            aggiungi(c, nuovi);
        });
    });

    form.addEventListener('submit', function (event) {
        nascondiErrore();

        if (!form.checkValidity()) {
            event.preventDefault();
            showError('Completa tutti i campi obbligatori e allega i documenti richiesti.');
            form.reportValidity();
            return;
        }

        if (maxTotalBytes && pesoTotale() > maxTotalBytes) {
            event.preventDefault();
            showError('I documenti superano insieme ' + formatSize(maxTotalBytes) + '. Rimuovine qualcuno o scegline di più leggeri.');
            return;
        }

        submit.disabled = true;
        submit.classList.add('is-loading');
        submit.querySelector('.fi-rx-submit-label').textContent = 'Invio in corso…';
    });

    const result = document.querySelector('.fi-rx-alert, .fi-rx-result');
    if (result) result.focus();
});
