/*
 * Pannello «Numeri Emergenze».
 *
 * Aggiunge, toglie e rinumera le schede dei numeri principali. La rinumerazione
 * non e' un dettaglio: WordPress salva questi campi come un array, e l'indice sta
 * nel nome del campo (`fi_em_main_cards[2][phone]`). Se dopo una rimozione gli
 * indici restassero con un buco, il salvataggio arriverebbe scombinato.
 *
 * La sezione «Contatti fuori orario» non esiste piu': il codice che la gestiva e'
 * stato tolto da qui insieme al resto.
 */
document.addEventListener('DOMContentLoaded', function () {
    const form = document.getElementById('fi_emergenze_form');
    if (!form) return;

    const mainList = document.getElementById('fi_main_cards_body');
    const addButton = document.getElementById('fi_add_card_row');
    if (!mainList || !addButton) return;

    function normalizePhone(value) {
        const clean = String(value || '').trim();
        return (clean.startsWith('+') ? '+' : '') + clean.replace(/\D/g, '');
    }

    function updatePreview(input) {
        const preview = input.parentElement.querySelector('.fi-em-tel-preview');
        if (preview) preview.textContent = 'Link generato: tel:' + normalizePhone(input.value);
    }

    function mainTemplate() {
        return `<article class="fi-em-main-item"><div class="fi-em-item-top"><span class="fi-em-order-badge"></span><strong class="fi-em-item-title">Nuovo numero</strong><label class="fi-em-active-toggle"><input type="checkbox" data-field="active" value="1" checked><span aria-hidden="true"></span><em>Attivo</em></label><button type="button" class="fi-em-icon-button fi-remove-main" aria-label="Rimuovi numero principale"><span class="dashicons dashicons-trash" aria-hidden="true"></span></button></div><div class="fi-em-main-fields"><div class="fi-em-field"><label>Titolo</label><input type="text" data-field="title" placeholder="Ambulanza e pronto soccorso"></div><div class="fi-em-field"><label>Numero</label><input type="text" class="fi-em-phone-input" data-field="phone" inputmode="tel" placeholder="+41 91 800 18 28"><small class="fi-em-tel-preview">Link generato: tel:</small></div><div class="fi-em-field"><label>Nota breve <span>(opzionale)</span></label><input type="text" data-field="note" placeholder="Disponibile 24 ore su 24"></div></div></article>`;
    }

    function reindex() {
        mainList.querySelectorAll('.fi-em-main-item').forEach(function (item, index) {
            item.querySelector('.fi-em-order-badge').textContent = index + 1;
            item.querySelectorAll('[data-field]').forEach(function (field) {
                field.name = `fi_em_main_cards[${index}][${field.dataset.field}]`;
            });
        });
    }

    addButton.addEventListener('click', function () {
        mainList.insertAdjacentHTML('beforeend', mainTemplate());
        reindex();
    });

    form.addEventListener('click', function (event) {
        const button = event.target.closest('.fi-remove-main');
        if (!button) return;
        button.closest('.fi-em-main-item').remove();
        reindex();
    });

    form.addEventListener('input', function (event) {
        if (event.target.classList.contains('fi-em-phone-input')) {
            updatePreview(event.target);
        }
        if ('title' === event.target.dataset.field) {
            event.target.closest('.fi-em-main-item').querySelector('.fi-em-item-title').textContent = event.target.value || 'Nuovo numero';
        }
    });

    /* Anche al momento dell'invio: se il browser ha ripristinato dei campi dopo
       un ritorno indietro, gli indici potrebbero non corrispondere piu'. */
    form.addEventListener('submit', reindex);
    reindex();
});
