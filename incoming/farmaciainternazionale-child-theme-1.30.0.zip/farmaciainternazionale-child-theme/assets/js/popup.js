/*
 * Popup del sito.
 *
 * COSA FA IL CSS E COSA FA QUESTO FILE: il popup nasce con l'attributo `hidden`
 * e in posizione fissa, quindi non occupa spazio e non sposta nulla al
 * caricamento. Qui si decide soltanto SE e QUANDO scoprirlo, e si gestisce la
 * chiusura. L'animazione e' tutta nel CSS.
 *
 * LA MEMORIA e' legata a una chiave che contiene la data di ultima modifica del
 * popup: se chi pubblica lo aggiorna, la chiave cambia e chi l'aveva chiuso lo
 * rivede. Senza questo, un avviso nuovo resterebbe invisibile a chi era gia'
 * passato dal sito.
 */
(function () {
    'use strict';

    var pop = document.querySelector('[data-fi-popup]');
    if (!pop) {
        return;
    }

    var velo = pop.querySelector('[data-fi-popup-velo]');
    var scatola = pop.querySelector('.fi-pop__scatola');
    var chiudi = pop.querySelector('[data-fi-popup-chiudi]');
    var chiave = pop.getAttribute('data-chiave') || '';
    /* Senza indicazione si mostra a ogni caricamento: se qualcosa va storto nel
       salvataggio, e' meglio un popup che si rivede di uno che sparisce. */
    var frequenza = pop.getAttribute('data-frequenza') || 'sempre';
    var ritardo = parseInt(pop.getAttribute('data-ritardo'), 10);
    if (isNaN(ritardo) || ritardo < 0) {
        ritardo = 0;
    }

    var apertoDa = null; // elemento che aveva il fuoco prima dell'apertura

    /**
     * Il magazzino giusto per la frequenza chiesta.
     * `sempre` non ha memoria, quindi restituisce null.
     */
    function magazzino() {
        try {
            if ('sessione' === frequenza) {
                return window.sessionStorage;
            }
            if ('utente' === frequenza) {
                return window.localStorage;
            }
        } catch (e) {
            /*
             * In navigazione privata o con i cookie bloccati l'accesso puo'
             * lanciare un errore. Non e' un caso da gestire con un avviso: si
             * rinuncia alla memoria e il popup si comporta come "sempre".
             */
            return null;
        }
        return null;
    }

    function giaChiuso() {
        var m = magazzino();
        if (!m) {
            return false;
        }
        try {
            return '1' === m.getItem(chiave);
        } catch (e) {
            return false;
        }
    }

    function ricordaChiuso() {
        var m = magazzino();
        if (!m) {
            return;
        }
        try {
            m.setItem(chiave, '1');
        } catch (e) {
            /* Magazzino pieno o non scrivibile: pazienza, si riaprira'. */
        }
    }

    function elementiFocalizzabili() {
        return Array.prototype.filter.call(
            scatola.querySelectorAll('a[href], button, [tabindex]:not([tabindex="-1"])'),
            function (el) { return null !== el.offsetParent; }
        );
    }

    function apri() {
        apertoDa = document.activeElement;
        pop.hidden = false;
        /*
         * La classe che avvia l'animazione si aggiunge nel fotogramma dopo: se
         * si mettesse subito, il browser non avrebbe uno stato di partenza da
         * cui muoversi e la comparsa sarebbe secca.
         */
        window.requestAnimationFrame(function () {
            pop.classList.add('is-aperto');
        });
        document.body.classList.add('fi-pop-bloccato');

        if (chiudi) {
            chiudi.focus();
        }
    }

    function chiudiPopup() {
        pop.classList.remove('is-aperto');
        document.body.classList.remove('fi-pop-bloccato');
        ricordaChiuso();

        /* Si aspetta la fine dell'animazione prima di togliere l'elemento dal
           flusso, altrimenti la dissolvenza in uscita non si vedrebbe. */
        var fine = function () {
            pop.hidden = true;
            pop.removeEventListener('transitionend', fine);
        };
        pop.addEventListener('transitionend', fine);
        /* Rete di sicurezza: se le transizioni sono spente (preferenza di
           sistema) transitionend non arriva mai. */
        window.setTimeout(function () {
            if (!pop.classList.contains('is-aperto')) {
                pop.hidden = true;
            }
        }, 400);

        if (apertoDa && 'function' === typeof apertoDa.focus) {
            apertoDa.focus();
        }
    }

    if (giaChiuso()) {
        return;
    }

    if (chiudi) {
        chiudi.addEventListener('click', chiudiPopup);
    }
    if (velo) {
        velo.addEventListener('click', chiudiPopup);
    }

    document.addEventListener('keydown', function (e) {
        if (pop.hidden) {
            return;
        }

        if ('Escape' === e.key) {
            chiudiPopup();
            return;
        }

        if ('Tab' !== e.key) {
            return;
        }

        /* Il fuoco resta dentro il popup finche' e' aperto: e' un dialogo, e chi
           naviga da tastiera non deve finire a tabulare nella pagina sotto. */
        var vivi = elementiFocalizzabili();
        if (!vivi.length) {
            return;
        }
        var primo = vivi[0];
        var ultimo = vivi[vivi.length - 1];

        if (e.shiftKey && document.activeElement === primo) {
            e.preventDefault();
            ultimo.focus();
        } else if (!e.shiftKey && document.activeElement === ultimo) {
            e.preventDefault();
            primo.focus();
        }
    });

    if (ritardo > 0) {
        window.setTimeout(apri, ritardo * 1000);
    } else {
        apri();
    }
}());
