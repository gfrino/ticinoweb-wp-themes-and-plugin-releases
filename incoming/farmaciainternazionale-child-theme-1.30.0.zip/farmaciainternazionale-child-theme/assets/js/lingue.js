/*
 * SELETTORE DI LINGUA — ROBUSTEZZA SUL TELEFONO.
 *
 * IL PROBLEMA. GTranslate non carica subito la libreria di traduzione di Google:
 * la chiede al primo `pointerenter` o `focusin` sul riquadro delle bandiere.
 * Cioe' **al passaggio del mouse**. Su un computer funziona bene: mentre porti il
 * puntatore verso la bandiera passano centinaia di millisecondi e la libreria
 * arriva prima del clic.
 *
 * SU UNO SCHERMO A TOCCO quel passaggio non esiste. Il dito arriva e tocca nello
 * stesso istante: la libreria comincia a scaricarsi *insieme* al tocco. Il plugin
 * se ne accorge e riprova ogni mezzo secondo — finche' non e' pronta. Con una
 * rete veloce sono meno di due secondi e non si nota; con una rete lenta sono
 * molti, e se la richiesta a Google non va a buon fine il tentativo si ripete
 * all'infinito: l'anello si sposta sulla bandiera scelta, ma **il testo della
 * pagina non cambia mai**. Da fuori sembra un pulsante che non funziona.
 *
 * DUE RIMEDI, IN ORDINE.
 *
 * 1. SCALDARE PRIMA. Appena si apre il menu del telefono — cioe' secondi prima
 *    che il dito raggiunga le bandiere — si chiede la libreria in anticipo. Non
 *    si duplica nulla del plugin: gli si lancia il suo stesso `focusin`, quindi
 *    resta lui a decidere cosa e da dove caricare. Misurato: con la libreria
 *    calda la traduzione arriva in 311ms invece di 955ms.
 *
 * 2. UNA RETE DI SICUREZZA. Se dopo alcuni secondi la pagina non risulta
 *    tradotta ma la lingua e' stata scelta, si ricarica. Non e' un ripiego
 *    qualunque: al caricamento successivo il plugin vede il cookie, capisce di
 *    non essere nella lingua di partenza e chiede la libreria **subito**, senza
 *    aspettare un passaggio del mouse che sul telefono non arrivera' mai. Cosi'
 *    «non succede niente, per sempre» diventa «la pagina si ricarica tradotta».
 *
 * 3. E SI CHIUDE IL MENU. Il tema chiude il menu quando si toccano i suoi link,
 *    ma li raccoglie a pagina caricata: se le bandiere — che le disegna il
 *    JavaScript del plugin — arrivano dopo, restano fuori da quell'elenco e il
 *    menu rimane aperto a coprire la pagina che si sta traducendo. Qui si chiude
 *    per delega, che funziona a prescindere dall'ordine di arrivo.
 */
(function () {
    'use strict';

    /* Quanto si aspetta prima di ricaricare. Generoso: la rete di sicurezza
       deve scattare solo quando la strada normale ha davvero fallito. */
    var ATTESA = 4000;

    /* Ci si ricorda di aver ricaricato, per non entrare in un anello infinito
       se il problema fosse altrove. Una ricarica per lingua scelta, non piu'. */
    var CHIAVE = 'fiLingueRicaricato';

    function contenitori() {
        return document.querySelectorAll('.fi-lingue .gtranslate_wrapper');
    }

    /* La pagina risulta tradotta? Google marca <html> con `translated-ltr`
       (o `-rtl`) quando ha finito di riscrivere il testo. */
    function tradotta() {
        return /\btranslated-(ltr|rtl)\b/.test(document.documentElement.className);
    }

    /* Dal cookie `googtrans=/it/de`: lingua di partenza e lingua scelta. */
    function scelta() {
        var m = document.cookie.match(/googtrans=\/([^/;]+)\/([^;]+)/);
        return m ? { da: m[1], a: m[2] } : null;
    }

    function ricorda(valore) {
        try {
            if (valore === null) {
                window.sessionStorage.removeItem(CHIAVE);
            } else {
                window.sessionStorage.setItem(CHIAVE, valore);
            }
        } catch (e) {
            /* Navigazione anonima o memoria piena: si prosegue senza. */
        }
    }

    function ricordato() {
        try {
            return window.sessionStorage.getItem(CHIAVE);
        } catch (e) {
            return null;
        }
    }

    /* 1. SCALDA — lancia al plugin il suo stesso segnale di «sto arrivando». */
    var scaldato = false;
    function scalda() {
        if (scaldato) {
            return;
        }
        var box = contenitori();
        if (!box.length) {
            return;
        }
        scaldato = true;
        Array.prototype.forEach.call(box, function (w) {
            w.dispatchEvent(new Event('focusin', { bubbles: true }));
        });
    }

    /* 2. RETE DI SICUREZZA — se non e' tradotta, ricarica una volta. */
    function controlla() {
        if (tradotta()) {
            return;
        }
        var s = scelta();
        if (!s || s.da === s.a) {
            return;
        }
        if (ricordato() === s.a) {
            return; /* Gia' provato per questa lingua: non si insiste. */
        }
        ricorda(s.a);
        window.location.reload();
    }

    /* 3. CHIUDE IL MENU, riusando il pulsante del tema invece di duplicarne la
          logica di apertura e chiusura. */
    function chiudiMenu() {
        var t = document.getElementById('fi-mobile-toggle');
        if (t && t.classList.contains('is-active')) {
            t.click();
        }
    }

    document.addEventListener('DOMContentLoaded', function () {
        /* Se siamo arrivati tradotti, la ricarica precedente ha funzionato:
           si azzera il ricordo, cosi' la rete di sicurezza resta disponibile. */
        if (tradotta()) {
            ricorda(null);
        }

        var apri = document.getElementById('fi-mobile-toggle');
        if (apri) {
            apri.addEventListener('click', scalda);
        }
    });

    /* Per delega: le bandiere arrivano dopo, e questo funziona comunque. */
    document.addEventListener('pointerdown', function (e) {
        if (e.target.closest && e.target.closest('.fi-lingue')) {
            scalda();
        }
    }, true);

    document.addEventListener('click', function (e) {
        var a = e.target.closest && e.target.closest('.fi-lingue a.glink');
        if (!a) {
            return;
        }
        chiudiMenu();
        window.setTimeout(controlla, ATTESA);
    });
}());
