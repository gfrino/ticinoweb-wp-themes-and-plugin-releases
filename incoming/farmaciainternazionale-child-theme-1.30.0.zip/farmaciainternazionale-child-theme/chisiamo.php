<?php
/**
 * Template Name: Chi Siamo
 * Description: Template dedicato alla pagina Chi Siamo della farmacia.
 */

get_header();

// 1. Recupero dati CMS
$cms_title = get_option('ticinoweb_chi_siamo_title');
$cms_text  = get_option('ticinoweb_chi_siamo_text');

// Fallbacks
$page_title = !empty($cms_title) ? $cms_title : 'Da oltre 30 anni, vicini al tuo benessere';
$hero_desc = fi_heading('about_hero')['text'];
$full_text = !empty($cms_text) ? $cms_text : 'Fondata oltre tre decenni fa, Farmacia Internazionale è un punto di riferimento a Locarno. Da padre in figlio, continua a unire ascolto, competenza e attenzione alla persona, combinando la tradizione farmaceutica con un approccio sempre più naturale.';
/* Stessa immagine della sezione «Una storia di famiglia» in homepage: si
   sceglie una volta dal pannello «Immagini del sito» e vale in entrambi i posti. */
$main_img = fi_immagine('storia');

$contact_page = function_exists('ticinoweb_get_mapped_page_url') ? ticinoweb_get_mapped_page_url('page_contatti') : '#contatti';
$map_link = function_exists('ticinoweb_get_contact_info') ? (ticinoweb_get_contact_info()['google_maps_url'] ?? '#') : '#';

?>

<main id="primary" class="site-main fi-chisiamo-page">

    <!-- 1. HERO INTERNA CHI SIAMO (LAYOUT SERVIZI) -->
    <section class="fi-servizi-hero">
        <div class="fi-hero-bg-glow glow-1"></div>
        <div class="fi-hero-bg-glow glow-2"></div>
        <div class="fi-hero-botanical-pattern"></div>
        <div class="container">
            <div class="fi-servizi-hero-content text-center">
                <div class="fi-hero-badges">
                    <?php fi_heading_badges('about_hero'); ?>
                </div>
                <h1 class="fi-servizi-title reveal-text"><?php echo wp_kses_post($page_title); ?></h1>
                <?php if ('' !== $hero_desc) : ?>
                <p class="fi-servizi-subtitle reveal-text delay-1"><?php echo esc_html($hero_desc); ?></p>
                <?php endif; ?>
            </div>
        </div>
    </section>

    <!-- 2. SEZIONE STORIA EDITORIALE -->
    <section class="fi-cs-editorial-story fi-section-spacing">
        <div class="fi-cs-editorial-bg-wrapper">
            <div class="fi-cs-bg-glow glow-story"></div>
            <div class="fi-cs-big-watermark">30+</div>
        </div>
        
        <div class="container relative">
            <div class="fi-editorial-grid">
                <!-- Titolo e Eyebrow -->
                <div class="editorial-title reveal-up">
                    <?php if ('' !== fi_heading('about_story')['kicker']) : ?><span class="fi-sub-heading fi-sub-heading-green"><?php echo esc_html(fi_heading('about_story')['kicker']); ?></span><?php endif; ?>
                    <h2 class="fi-section-title mb-4"><?php echo wp_kses_post($page_title); ?></h2>
                </div>
                
                <!-- Immagine e Micro-card -->
                <div class="editorial-image reveal-up delay-1">
                    <div class="fi-cs-editorial-img-wrapper">
                        <img src="<?php echo esc_url($main_img); ?>" alt="<?php echo esc_attr(strip_tags($page_title)); ?>" class="img-fluid" />
                        <div class="fi-cs-botanical-lines"></div>
                    </div>
                    
                    <div class="fi-cs-micro-card reveal-up delay-3">
                        <div class="micro-icon">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" width="24" height="24"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
                        </div>
                        <div class="micro-text">
                            <strong>Da padre in figlio</strong>
                            <span>Oltre 30 anni di fiducia</span>
                        </div>
                    </div>
                </div>
                
                <!-- Testo Completo -->
                <div class="editorial-text reveal-up delay-2">
                    <div class="fi-cs-editorial-content">
                        <?php echo wpautop(wp_kses_post($full_text)); ?>
                    </div>
                    <a href="<?php echo esc_url(home_url('/contatti/')); ?>" class="fi-btn fi-btn-secondary mt-4">Contattaci</a>
                </div>
            </div>
        </div>
    </section>

    <!-- 4. SEZIONE VALORI -->
    <section class="fi-cs-values fi-section-spacing">
        <div class="container">
            <div class="text-center mb-5">
                <h2 class="fi-section-title"><?php echo esc_html(fi_heading('about_values')['title']); ?></h2>
            </div>
            
            <div class="fi-cs-values-grid">
                <?php foreach (fi_get_site_blocks('about_values') as $index => $block) : ?>
                    <div class="fi-cs-value-card reveal-up<?php echo $index % 3 ? ' delay-' . esc_attr($index % 3) : ''; ?>">
                        <div class="fi-cs-val-icon"><?php echo fi_get_dynamic_block_icon($block['title'], $block['text']); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div>
                        <h4><?php echo esc_html($block['title']); ?></h4>
                        <p><?php echo esc_html($block['text']); ?></p>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- 5. SEZIONE NATURA E COMPETENZA (Dynamic Layout) -->
    <?php
    /*
     * L'immagine si sceglie dal pannello «Immagini del sito». Se non e' stata
     * scelta, fi_immagine() cerca da sola nella galleria 5 come faceva la query
     * che stava qui, e in ultimo usa la foto di riserva.
     */
    $gallery_img_url = fi_immagine('chisiamo_lato');
    ?>
    <section class="fi-nature-section section-pad">
        <div class="fi-nature-bg"></div>
        <div class="container">
            <div class="nature-layout">
                <div class="nature-image-col reveal-up">
                    <div class="nature-img-wrapper">
                        <img src="<?php echo esc_url($gallery_img_url); ?>" alt="Il tuo punto di riferimento per la salute a Locarno" />
                        <div class="nature-floating-botanical b1">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M11 20A7 7 0 0 1 9.8 6.1C15.5 5 17 4.48 19 2c1 2 2 4.18 2 8 0 5.5-4.78 10-10 10Z"></path><path d="M2 21c0-3 1.85-5.36 5.08-6C9.5 14.52 12 13 13 12"></path></svg>
                        </div>
                        <div class="nature-floating-botanical b2">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22c5.523 0 10-4.477 10-10S17.523 2 12 2 2 6.477 2 12s4.477 10 10 10z"></path><path d="M2 12h20"></path><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"></path></svg>
                        </div>
                    </div>
                </div>
                <div class="nature-text-col reveal-up" style="transition-delay: 0.2s;">
                    <?php if ('' !== fi_heading('about_more')['kicker']) : ?><span class="fi-sub-heading text-green"><?php echo esc_html(fi_heading('about_more')['kicker']); ?></span><?php endif; ?>
                    <h2 class="fi-section-title"><?php echo esc_html(fi_heading('about_more')['title']); ?></h2>
                    <?php if ('' !== fi_heading('about_more')['text']) : ?><p class="fi-lead"><?php echo esc_html(fi_heading('about_more')['text']); ?></p><?php endif; ?>

                    <div class="nature-features-list">
                        <?php foreach (fi_get_site_blocks('about_nature') as $block) : ?>
                            <div class="nature-feature-item">
                                <div class="nf-icon"><?php echo fi_get_dynamic_block_icon($block['title'], $block['text'], $block['icon']); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div>
                                <div class="nf-content">
                                    <h3><?php echo esc_html($block['title']); ?></h3>
                                    <p><?php echo esc_html($block['text']); ?></p>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>
    </section>

</main>

<?php get_footer(); ?>
