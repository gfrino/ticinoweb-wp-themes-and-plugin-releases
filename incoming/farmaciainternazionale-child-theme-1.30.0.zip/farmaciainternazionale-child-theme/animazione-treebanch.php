<?php
/**
 * Global background animation with treebanch.svg
 */
$theme_uri = get_stylesheet_directory_uri();
?>
<div id="fi-global-tree-bg" aria-hidden="true">
    <img src="<?php echo esc_url($theme_uri . '/assets/images/treebanch.svg'); ?>" alt="" class="fi-tree-img" />
</div>

<style>
#fi-global-tree-bg {
    position: fixed;
    top: 0;
    left: 0;
    width: 100vw;
    height: 100vh;
    z-index: -1; /* Posizionato dietro i contenuti ma sopra lo sfondo base del browser */
    pointer-events: none;
    opacity: 0.5; /* Richiesto trasparenza 50% */
    overflow: hidden;
}

/* Rendi trasparenti i background solidi per poter intravedere l'albero */
html, body {
    background-color: transparent !important;
}
.bg-white, .fi-bg-white, .fi-white-bg {
    background-color: rgba(255, 255, 255, 0.85) !important;
}
.fi-premium-card, .fi-contact-card, .fi-servizio-card, .fi-card {
    background-color: rgba(255, 255, 255, 0.9) !important;
    backdrop-filter: blur(5px);
}
#fi-global-tree-bg .fi-tree-img {
    width: 100vw;
    height: 100vh;
    object-fit: cover;
    object-position: bottom center;
    /* Maschera iniziale: un cerchio invisibile sul lato sinistro (da dove nascono i rami) */
    clip-path: circle(0% at 0% 40%);
    will-change: clip-path;
    transition: clip-path 0.1s ease-out; /* Smoothness during scroll */
}
</style>

<script>
document.addEventListener("DOMContentLoaded", function() {
    const treeImg = document.querySelector('.fi-tree-img');
    if (!treeImg) return;

    function updateTreeGrowth() {
        const scrollTop = window.scrollY || document.documentElement.scrollTop;
        const docHeight = Math.max(
            document.body.scrollHeight, document.documentElement.scrollHeight,
            document.body.offsetHeight, document.documentElement.offsetHeight,
            document.body.clientHeight, document.documentElement.clientHeight
        );
        const winHeight = window.innerHeight || document.documentElement.clientHeight;
        const maxScroll = docHeight - winHeight;

        if (maxScroll <= 0) {
            treeImg.style.clipPath = 'polygon(0 0, 100% 0, 100% 100%, 0 100%)';
            return;
        }

        let scrollFraction = scrollTop / maxScroll;
        
        // Full growth at 55% of the page scroll
        const bloomPoint = 0.55; 
        
        let growthFraction = scrollFraction / bloomPoint;
        if (growthFraction > 1) growthFraction = 1;

        // Calculate radius from 0% to 150% to ensure it covers the whole screen
        const radiusPercent = growthFraction * 150;
        
        // The branches seem to originate from the middle-left of the screen
        treeImg.style.clipPath = `circle(${radiusPercent}% at 0% 40%)`;
    }

    window.addEventListener('scroll', updateTreeGrowth, { passive: true });
    window.addEventListener('resize', updateTreeGrowth, { passive: true });
    
    // Initial call
    updateTreeGrowth();
});
</script>
