<?php
/**
 * Template Name: Invio Ricette
 * Description: Invio temporaneo e sicuro di ricetta e cassa malati alla farmacia.
 *
 * @package Farmacia_Internazionale
 */

get_header();

$settings       = fi_ricette_get_settings();
$service_ready  = !empty($settings['enabled']) && is_email($settings['recipient_email']);
$status         = isset($_GET['fi_ricette_status']) ? sanitize_key(wp_unslash($_GET['fi_ricette_status'])) : '';
$privacy_url    = get_privacy_policy_url();
$allowed_mimes  = fi_ricette_allowed_mimes($settings['allowed_formats']);
$accept         = implode(',', array_values(array_unique($allowed_mimes)));
$server_max_mb  = max(1, (int) floor(wp_max_upload_size() / MB_IN_BYTES));
$max_upload_mb  = min((int) $settings['max_upload_mb'], $server_max_mb);
$phone          = get_option('ticinoweb_contact_phone', '');
$phone_clean    = preg_replace('/[^0-9+]/', '', $phone);
?>

<main id="primary" class="site-main fi-ricette-page">
    <section class="fi-ricette-hero">
        <div class="fi-rx-glow fi-rx-glow-one" aria-hidden="true"></div>
        <div class="fi-rx-glow fi-rx-glow-two" aria-hidden="true"></div>
        <div class="container">
            <div class="fi-ricette-hero-content reveal-up">
                <span class="fi-rx-hero-kicker">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><rect x="5" y="10" width="14" height="11" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/></svg>
                    <?php esc_html_e('Servizio digitale della farmacia', 'farmaciainternazionale-child-theme'); ?>
                </span>
                <h1><?php echo esc_html($settings['page_title']); ?></h1>
                <p><?php echo esc_html($settings['intro_text']); ?></p>
                <div class="fi-ricette-badges" aria-label="Caratteristiche del servizio">
                    <span><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><path d="m9 12 2 2 4-5"/></svg><?php esc_html_e('Invio sicuro', 'farmaciainternazionale-child-theme'); ?></span>
                    <span><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M4 20h16M6 20V7l6-4 6 4v13M9 11h6M9 15h6"/></svg><?php esc_html_e('Documenti gestiti dalla farmacia', 'farmaciainternazionale-child-theme'); ?></span>
                    <span><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.8 19.8 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.12 4.18 2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72"/></svg><?php esc_html_e('Contatto telefonico se necessario', 'farmaciainternazionale-child-theme'); ?></span>
                </div>
            </div>
        </div>
    </section>

    <section class="fi-ricette-content" id="fi-invio-ricette-form">
        <div class="container">
            <?php if ('success' === $status) : ?>
                <div class="fi-rx-result fi-rx-success" role="status" tabindex="-1">
                    <div class="fi-rx-result-icon" aria-hidden="true">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 6 9 17l-5-5"/></svg>
                    </div>
                    <h2><?php esc_html_e('Invio completato', 'farmaciainternazionale-child-theme'); ?></h2>
                    <p><?php echo esc_html($settings['success_message']); ?></p>
                    <div class="fi-rx-result-actions">
                        <a class="fi-btn fi-btn-primary" href="<?php echo esc_url(home_url('/')); ?>"><?php esc_html_e('Torna alla home', 'farmaciainternazionale-child-theme'); ?></a>
                        <a class="fi-btn fi-btn-secondary" href="<?php echo esc_url(home_url('/contatti/')); ?>"><?php esc_html_e('Contattaci', 'farmaciainternazionale-child-theme'); ?></a>
                    </div>
                </div>
            <?php else : ?>
                <?php if ('error' === $status) : ?>
                    <div class="fi-rx-alert fi-rx-alert-error" role="alert" tabindex="-1">
                        <?php echo esc_html($settings['error_message']); ?>
                    </div>
                <?php endif; ?>

                <?php if (!$service_ready || 'unavailable' === $status) : ?>
                    <div class="fi-rx-result fi-rx-unavailable" role="status">
                        <div class="fi-rx-result-icon" aria-hidden="true">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="12" r="9"/><path d="M12 7v6l4 2"/></svg>
                        </div>
                        <h2><?php esc_html_e('Servizio momentaneamente non disponibile', 'farmaciainternazionale-child-theme'); ?></h2>
                        <p><?php esc_html_e('Il servizio di invio ricette è momentaneamente non disponibile. Contattaci telefonicamente per maggiori informazioni.', 'farmaciainternazionale-child-theme'); ?></p>
                        <?php if ($phone) : ?>
                            <a class="fi-btn fi-btn-primary" href="tel:<?php echo esc_attr($phone_clean); ?>"><?php echo esc_html(sprintf(__('Chiama %s', 'farmaciainternazionale-child-theme'), $phone)); ?></a>
                        <?php endif; ?>
                    </div>
                <?php else : ?>
                    <div class="fi-ricette-layout">
                        <aside class="fi-rx-info reveal-up">
                            <span class="fi-rx-eyebrow"><?php esc_html_e('Prima di inviare', 'farmaciainternazionale-child-theme'); ?></span>
                            <h2><?php esc_html_e('Tre semplici controlli', 'farmaciainternazionale-child-theme'); ?></h2>
                            <ol class="fi-rx-checklist">
                                <li><span>1</span><div><strong><?php esc_html_e('Ricetta leggibile', 'farmaciainternazionale-child-theme'); ?></strong><p><?php esc_html_e('Assicurati che testo, timbro e prescrizione siano nitidi.', 'farmaciainternazionale-child-theme'); ?></p></div></li>
                                <li><span>2</span><div><strong><?php esc_html_e('Cassa malati pronta', 'farmaciainternazionale-child-theme'); ?></strong><p><?php esc_html_e('Carica anche la foto della tessera o dei relativi dati.', 'farmaciainternazionale-child-theme'); ?></p></div></li>
                                <li><span>3</span><div><strong><?php esc_html_e('Telefono corretto', 'farmaciainternazionale-child-theme'); ?></strong><p><?php esc_html_e('Inserisci un numero al quale possiamo contattarti se necessario.', 'farmaciainternazionale-child-theme'); ?></p></div></li>
                            </ol>
                            <div class="fi-rx-info-cards">
                                <div class="fi-rx-security-note">
                                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><rect x="5" y="10" width="14" height="11" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/></svg>
                                    <p><strong><?php esc_html_e('Privacy al centro', 'farmaciainternazionale-child-theme'); ?></strong><br><?php esc_html_e('I documenti non vengono salvati nella Media Library o archiviati nel sito.', 'farmaciainternazionale-child-theme'); ?></p>
                                </div>
                                <div class="fi-rx-after-note">
                                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><path d="M4 4h16v12H7l-3 3z"/><path d="M8 9h8M8 12h5"/></svg>
                                    <p><strong><?php esc_html_e('Dopo l’invio', 'farmaciainternazionale-child-theme'); ?></strong><br><?php esc_html_e('La farmacia riceverà i documenti e ti contatterà telefonicamente solo se necessario.', 'farmaciainternazionale-child-theme'); ?></p>
                                </div>
                            </div>
                        </aside>

                        <div class="fi-rx-form-card reveal-up">
                            <div class="fi-rx-form-heading">
                                <span class="fi-rx-eyebrow"><?php esc_html_e('Richiesta online', 'farmaciainternazionale-child-theme'); ?></span>
                                <h2><?php esc_html_e('Invia i documenti', 'farmaciainternazionale-child-theme'); ?></h2>
                                <p><?php echo esc_html(sprintf(__('Formati consentiti: %1$s. Massimo %2$d MB per file.', 'farmaciainternazionale-child-theme'), strtoupper(implode(', ', $settings['allowed_formats'])), $max_upload_mb)); ?></p>
                            </div>

                            <div class="fi-rx-form-privacy">
                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><rect x="5" y="10" width="14" height="11" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/></svg>
                                <p><?php esc_html_e('Per la tua privacy, i file non vengono archiviati nella Media Library e vengono gestiti solo per questa richiesta.', 'farmaciainternazionale-child-theme'); ?></p>
                            </div>

                            <form class="fi-rx-form" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" method="post" enctype="multipart/form-data" data-max-bytes="<?php echo esc_attr($max_upload_mb * MB_IN_BYTES); ?>"
                                  data-max-files="<?php echo esc_attr(FI_RICETTE_MAX_FILE_PER_CAMPO); ?>"
                                  data-max-total-bytes="<?php echo esc_attr(FI_RICETTE_MAX_MB_TOTALE * MB_IN_BYTES); ?>" novalidate>
                                <input type="hidden" name="action" value="fi_submit_ricetta">
                                <?php wp_nonce_field('fi_submit_ricetta', 'fi_ricette_nonce'); ?>
                                <div class="fi-rx-honeypot" aria-hidden="true">
                                    <label for="fi-company-website">Website</label>
                                    <input id="fi-company-website" type="text" name="fi_company_website" value="" tabindex="-1" autocomplete="off">
                                </div>

                                <div class="fi-rx-field">
                                    <label for="fi-prescription"><span class="fi-rx-field-icon" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M7 3h7l4 4v14H7z"/><path d="M14 3v5h5M10 13h5M10 17h5"/></svg></span><?php esc_html_e('Foto della ricetta', 'farmaciainternazionale-child-theme'); ?> <em>*</em></label>
                                    <label class="fi-rx-upload" for="fi-prescription">
                                        <input id="fi-prescription" type="file" name="fi_prescription[]" accept="<?php echo esc_attr($accept); ?>" aria-describedby="fi-prescription-meta" multiple required>
                                        <span class="fi-rx-upload-icon" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M12 16V4m0 0L7 9m5-5 5 5M5 15v4h14v-4"/></svg></span>
                                        <span class="fi-rx-upload-copy"><strong><?php esc_html_e('Scegli i file', 'farmaciainternazionale-child-theme'); ?></strong><small><?php printf(esc_html__('Foto chiare e leggibili della ricetta. Puoi sceglierne fino a %d.', 'farmaciainternazionale-child-theme'), FI_RICETTE_MAX_FILE_PER_CAMPO); ?></small></span>
                                        <span class="fi-rx-file-meta" id="fi-prescription-meta" role="status" aria-live="polite"></span>
                                    </label>
                                    <?php
                                    /*
                                     * L'ELENCO STA FUORI DALLA <label>, non dentro: qualsiasi
                                     * clic dentro un'etichetta collegata a un campo file apre
                                     * il selettore, quindi un pulsante «rimuovi» messo la'
                                     * dentro aprirebbe la finestra dei file invece di
                                     * togliere il documento. Nasce vuoto e con hidden: lo
                                     * riempie il JavaScript, e senza JavaScript il campo
                                     * resta un normale campo a scelta multipla.
                                     */
                                    ?>
                                    <ul class="fi-rx-elenco" data-fi-rx-elenco="fi-prescription" hidden></ul>
                                </div>

                                <div class="fi-rx-field">
                                    <label for="fi-insurance-card"><span class="fi-rx-field-icon" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 9h18M7 14h4"/></svg></span><?php esc_html_e('Foto della cassa malati', 'farmaciainternazionale-child-theme'); ?> <em>*</em></label>
                                    <label class="fi-rx-upload" for="fi-insurance-card">
                                        <input id="fi-insurance-card" type="file" name="fi_insurance_card[]" accept="<?php echo esc_attr($accept); ?>" aria-describedby="fi-insurance-meta" multiple required>
                                        <span class="fi-rx-upload-icon" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M12 16V4m0 0L7 9m5-5 5 5M5 15v4h14v-4"/></svg></span>
                                        <span class="fi-rx-upload-copy"><strong><?php esc_html_e('Scegli i file', 'farmaciainternazionale-child-theme'); ?></strong><small><?php printf(esc_html__('Tessera della cassa malati, fronte e retro se serve. Fino a %d file.', 'farmaciainternazionale-child-theme'), FI_RICETTE_MAX_FILE_PER_CAMPO); ?></small></span>
                                        <span class="fi-rx-file-meta" id="fi-insurance-meta" role="status" aria-live="polite"></span>
                                    </label>
                                    <?php
                                    /*
                                     * L'ELENCO STA FUORI DALLA <label>, non dentro: qualsiasi
                                     * clic dentro un'etichetta collegata a un campo file apre
                                     * il selettore, quindi un pulsante «rimuovi» messo la'
                                     * dentro aprirebbe la finestra dei file invece di
                                     * togliere il documento. Nasce vuoto e con hidden: lo
                                     * riempie il JavaScript, e senza JavaScript il campo
                                     * resta un normale campo a scelta multipla.
                                     */
                                    ?>
                                    <ul class="fi-rx-elenco" data-fi-rx-elenco="fi-insurance-card" hidden></ul>
                                </div>

                                <div class="fi-rx-field">
                                    <label for="fi-phone"><span class="fi-rx-field-icon" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.8 19.8 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.12 4.18 2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.12.9.36 1.78.7 2.61a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.83.34 1.71.58 2.61.7A2 2 0 0 1 22 16.92z"/></svg></span><?php esc_html_e('Numero di telefono', 'farmaciainternazionale-child-theme'); ?> <em>*</em></label>
                                    <input id="fi-phone" type="tel" name="fi_phone" required maxlength="30" autocomplete="tel" inputmode="tel" pattern="[0-9+().\-\s]{7,30}" aria-describedby="fi-phone-help" placeholder="<?php esc_attr_e('Es. +41 79 123 45 67', 'farmaciainternazionale-child-theme'); ?>">
                                    <small class="fi-rx-field-help" id="fi-phone-help"><?php esc_html_e('Usa un numero al quale la farmacia può contattarti.', 'farmaciainternazionale-child-theme'); ?></small>
                                </div>

                                <label class="fi-rx-consent">
                                    <input type="checkbox" name="fi_privacy" value="1" required>
                                    <span><?php echo esc_html($settings['privacy_text']); ?><?php if ($privacy_url) : ?> <a href="<?php echo esc_url($privacy_url); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e('Leggi la privacy policy', 'farmaciainternazionale-child-theme'); ?></a>.<?php endif; ?></span>
                                </label>

                                <div class="fi-rx-client-error" role="alert" aria-live="assertive"></div>
                                <button class="fi-rx-submit" type="submit">
                                    <span class="fi-rx-submit-label"><?php esc_html_e('Invia ricetta', 'farmaciainternazionale-child-theme'); ?></span>
                                    <span class="fi-rx-spinner" aria-hidden="true"></span>
                                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="m5 12 14-7-4 14-3-6z"/></svg>
                                </button>
                                <p class="fi-rx-submit-note"><?php esc_html_e('Non chiudere la pagina durante l’invio.', 'farmaciainternazionale-child-theme'); ?></p>
                            </form>
                        </div>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </section>
</main>

<?php get_footer(); ?>
