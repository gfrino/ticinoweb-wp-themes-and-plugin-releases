<?php
/**
 * Farmacia Internazionale Child Theme functions and definitions
 */

add_action('wp_enqueue_scripts', 'farmaciainternazionale_child_enqueue_styles');
function farmaciainternazionale_child_enqueue_styles()
{
    // Carica il foglio di stile del child theme. Il parent (ticinoweb-ai-theme)
    // viene presumibilmente gestito o si auto-carica come da prassi di quel tema.
    wp_enqueue_style('farmaciainternazionale-child-style', get_stylesheet_uri(), array(), wp_get_theme()->get('Version'));

    // Script globale per l'header (sticky e mobile menu)
    wp_enqueue_script('fi-header-script', get_stylesheet_directory_uri() . '/assets/js/header.js', array(), wp_get_theme()->get('Version'), true);

    // Selettore di lingua: prepara in anticipo la libreria di Google e rimedia
    // se la traduzione non parte. Serve solo dove ci sono le bandiere, cioe' se
    // il plugin GTranslate e' attivo.
    if (function_exists('fi_lingue_plugin_attivo') && fi_lingue_plugin_attivo()) {
        wp_enqueue_script('fi-lingue', get_stylesheet_directory_uri() . '/assets/js/lingue.js', array(), wp_get_theme()->get('Version'), true);
    }

    // Carica gli script della homepage solo nella front-page
    if (is_front_page() || is_home()) {
        wp_enqueue_style('swiper-css', 'https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css', array(), '11.0.0');
        wp_enqueue_script('swiper-js', 'https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js', array(), '11.0.0', true);
        wp_enqueue_script('fi-home-animations', get_stylesheet_directory_uri() . '/assets/js/home-animations.js', array('swiper-js'), wp_get_theme()->get('Version'), true);
    }

    if (is_page_template('invio-ricette.php')) {
        wp_enqueue_script(
            'fi-invio-ricette',
            get_stylesheet_directory_uri() . '/assets/js/invio-ricette.js',
            array(),
            wp_get_theme()->get('Version'),
            true
        );
    }
}

/**
 * Indirizzo di un'immagine della Libreria media, cercata per nome.
 *
 * Serve dove il tema ha bisogno di un file preciso (sfondi, filigrane) che il
 * committente carica dal pannello. Cercarlo per nome invece di scriverne
 * l'indirizzo e' l'unica forma che sopravvive a una migrazione: in Multisite il
 * numero del sito cambia, e con esso tutta la cartella degli upload.
 *
 * Il risultato e' in cache per la durata della richiesta: la homepage puo'
 * chiamare la stessa immagine piu' volte e la query si paga una volta sola.
 *
 * @param string $nome Slug dell'allegato, cioe' il nome file senza estensione.
 * @return string Indirizzo completo, oppure stringa vuota se l'immagine non c'e'.
 */
function farmaciainternazionale_media_url( $nome ) {

	static $cache = array();

	if ( isset( $cache[ $nome ] ) ) {
		return $cache[ $nome ];
	}

	$trovati = get_posts(
		array(
			'post_type'      => 'attachment',
			'post_status'    => 'inherit',
			'name'           => $nome,
			'posts_per_page' => 1,
			'fields'         => 'ids',
			'no_found_rows'  => true,
		)
	);

	/* wp_get_attachment_image_url passa da wp_upload_dir(), quindi la cartella
	   del sito corrente la calcola WordPress e non noi. */
	$cache[ $nome ] = $trovati ? (string) wp_get_attachment_image_url( $trovati[0], 'full' ) : '';

	return $cache[ $nome ];
}

/**
 * Icona di una scheda Servizio, dai dati del pannello ticinoWEB CMS.
 *
 * Il pannello offre TRE modi di dare un'icona a un servizio — un'immagine
 * caricata, un SVG incollato a mano, o un'icona scelta dall'elenco Dashicons —
 * ma il tema ne leggeva soltanto uno: l'immagine. Chi scegliesse un'icona
 * dall'elenco o incollasse un SVG non vedeva niente e si ritrovava il cerchio
 * col piu' generico, senza capire perche'.
 *
 * L'ORDINE DI PRECEDENZA tiene l'immagine per prima di proposito: i servizi
 * gia' pubblicati hanno sia l'immagine sia un dashicon, e mostrano l'immagine.
 * Mettere il dashicon davanti cambierebbe l'aspetto di schede gia' approvate.
 *
 * @param array $servizio Una voce dell'opzione ticinoweb_services.
 * @return string Markup dell'icona, gia' pronto da stampare.
 */
function farmaciainternazionale_icona_servizio($servizio)
{
    $svg    = isset($servizio['icon_svg']) ? trim((string) $servizio['icon_svg']) : '';
    $icona  = isset($servizio['icon']) ? trim((string) $servizio['icon']) : '';
    $titolo = isset($servizio['title']) ? (string) $servizio['title'] : '';

    /*
     * LA FOTOGRAFIA NON ENTRA QUI, ed e' una scelta non un'omissione. Il
     * cerchietto della scheda misura 24x24 px: una foto da 1832x1204 ci finisce
     * schiacciata in una macchia illeggibile. Il campo Immagine del pannello
     * resta salvato e intatto — semplicemente non lo si usa come icona.
     *
     * Se un domani si volesse mostrare quella foto per davvero, il posto giusto
     * e' una fascia in cima alla scheda, non il cerchietto: e' un lavoro di
     * grafica, non un cambio di priorita' qui dentro.
     */

    /* Un SVG incollato dal pannello: si ripulisce, non si stampa alla cieca. */
    if ('' !== $svg && false !== strpos($svg, '<svg')) {
        return wp_kses($svg, farmaciainternazionale_svg_consentito());
    }

    /* Icona dall'elenco Dashicons. Il foglio di stile lo accoda
       farmaciainternazionale_dashicons_se_servono(), solo quando serve. */
    if (0 === strpos($icona, 'dashicons-') && !farmaciainternazionale_icona_predefinita($icona)) {
        return '<span class="dashicons ' . esc_attr($icona) . '" aria-hidden="true"></span>';
    }

    /* Un'icona di Font Awesome, per i servizi scritti prima a mano. */
    if (false !== strpos($icona, 'fa-')) {
        return '<i class="fas ' . esc_attr($icona) . '" aria-hidden="true"></i>';
    }

    /* Niente di scelto: invece del cerchio col piu', si deduce un'icona dalle
       parole del servizio, come fanno gia' le altre schede del sito. */
    return fi_get_dynamic_block_icon($titolo, isset($servizio['description']) ? $servizio['description'] : '');
}

/**
 * Riconosce l'icona che il pannello mette da solo, non quella scelta da qualcuno.
 *
 * `dashicons-admin-tools` — una chiave inglese — e' il valore con cui il pannello
 * del tema padre crea ogni nuovo servizio ed e' anche il suo segnaposto (vedi
 * inc/admin-settings.php, righe 2350 e 3959). Trovarlo non significa che
 * qualcuno l'abbia scelto: significa che nessuno ha toccato quel campo. Tutti e
 * cinque i servizi pubblicati ce l'hanno identico, prova che e' rimasto quello
 * predefinito.
 *
 * Trattandolo come "niente scelto" si lascia il posto all'icona dedotta dalle
 * parole del servizio, che e' pertinente. Chi sceglie davvero un'icona
 * dall'elenco la vede rispettata come sempre.
 *
 * @param string $icona Valore del campo icona.
 * @return bool
 */
function farmaciainternazionale_icona_predefinita($icona)
{
    return 'dashicons-admin-tools' === $icona;
}

/**
 * Tag e attributi ammessi in un SVG incollato dal pannello.
 *
 * wp_kses() con questa lista lascia passare un disegno e blocca gli attributi
 * che eseguono codice: un campo di testo libero nell'amministrazione non deve
 * poter iniettare uno `onload` nella homepage.
 *
 * @return array
 */
function farmaciainternazionale_svg_consentito()
{
    $comuni = array(
        'fill' => true, 'stroke' => true, 'stroke-width' => true, 'stroke-linecap' => true,
        'stroke-linejoin' => true, 'opacity' => true, 'transform' => true, 'class' => true,
    );

    return array(
        'svg'      => array_merge($comuni, array('viewbox' => true, 'xmlns' => true, 'width' => true, 'height' => true, 'aria-hidden' => true, 'focusable' => true)),
        'g'        => $comuni,
        'path'     => array_merge($comuni, array('d' => true)),
        'circle'   => array_merge($comuni, array('cx' => true, 'cy' => true, 'r' => true)),
        'ellipse'  => array_merge($comuni, array('cx' => true, 'cy' => true, 'rx' => true, 'ry' => true)),
        'rect'     => array_merge($comuni, array('x' => true, 'y' => true, 'width' => true, 'height' => true, 'rx' => true, 'ry' => true)),
        'line'     => array_merge($comuni, array('x1' => true, 'y1' => true, 'x2' => true, 'y2' => true)),
        'polyline' => array_merge($comuni, array('points' => true)),
        'polygon'  => array_merge($comuni, array('points' => true)),
    );
}

add_action('wp_enqueue_scripts', 'farmaciainternazionale_dashicons_se_servono');
/**
 * Accoda i Dashicons soltanto se un servizio ne usa davvero uno.
 *
 * WordPress non li carica sul sito pubblico, solo nell'amministrazione. Si
 * accodano solo quando servono per non aggiungere un foglio di stile a ogni
 * visita per un'icona che magari nessuno ha scelto.
 */
function farmaciainternazionale_dashicons_se_servono()
{
    if (!is_front_page() && !is_home()) {
        return;
    }

    $servizi = function_exists('ticinoweb_get_services') ? ticinoweb_get_services() : array();
    if (empty($servizi) || !is_array($servizi)) {
        return;
    }

    foreach ($servizi as $servizio) {
        $svg   = isset($servizio['icon_svg']) ? trim((string) $servizio['icon_svg']) : '';
        $icona = isset($servizio['icon']) ? trim((string) $servizio['icon']) : '';
        /* Le stesse condizioni con cui farmaciainternazionale_icona_servizio()
           stampa davvero un dashicon: un SVG incollato gli passa davanti. */
        if ('' === $svg && 0 === strpos($icona, 'dashicons-') && !farmaciainternazionale_icona_predefinita($icona)) {
            wp_enqueue_style('dashicons');
            return;
        }
    }
}

/**
 * I social configurati nel pannello, con le loro icone.
 *
 * PERCHE' SVG E NON FONT AWESOME: il footer usava `<i class="fab fa-facebook-f">`,
 * ma Font Awesome non e' accodato da nessuna parte in questo tema. Il risultato
 * erano cerchietti vuoti: lo sfondo tondo del CSS c'era, l'icona dentro no.
 * Un SVG in linea non ha dipendenze e non puo' mancare.
 *
 * Copre tutti e sei i social che il pannello del tema padre permette di
 * compilare, non solo i due che il footer leggeva prima.
 *
 * @return array Elenco di array con chiave, etichetta, indirizzo e disegno.
 */
function farmaciainternazionale_social()
{
    /* I tracciati sono pieni (fill), non a tratto: i marchi si riconoscono dalla
       sagoma, e a 16px un contorno sottile diventa illeggibile. */
    $disegni = array(
        'facebook'  => '<path d="M22 12.06C22 6.5 17.52 2 12 2S2 6.5 2 12.06c0 5.02 3.66 9.18 8.44 9.94v-7.03H7.9v-2.91h2.54V9.85c0-2.51 1.49-3.9 3.77-3.9 1.09 0 2.23.2 2.23.2v2.46h-1.26c-1.24 0-1.63.77-1.63 1.56v1.89h2.78l-.45 2.91h-2.33V22c4.78-.76 8.44-4.92 8.44-9.94z"/>',
        /*
         * INSTAGRAM E' DISEGNATO CON FORME, NON CON UN TRACCIATO.
         *
         * Il tracciato precedente l'avevo scritto a mano e veniva storto: il
         * contorno arrotondato si spezzava e la sagoma risultava schiacciata.
         * Un marchio fatto di un rettangolo arrotondato, un cerchio al centro e
         * un punto in alto a destra si controlla a occhio guardando i numeri —
         * il quadrato e' centrato (3..21 su 24), il cerchio sta in 12,12 — e non
         * puo' venire asimmetrico.
         *
         * Il contorno e' a tratto perche' il marchio Instagram e' cosi'; lo
         * spessore 2.2 lo tiene visivamente pesante come le altre cinque icone,
         * che invece sono piene.
         */
        'instagram' => '<rect x="3" y="3" width="18" height="18" rx="5.2" fill="none" stroke="currentColor" stroke-width="2.2"/>'
            . '<circle cx="12" cy="12" r="4.1" fill="none" stroke="currentColor" stroke-width="2.2"/>'
            . '<circle cx="17.1" cy="6.9" r="1.35"/>',
        'linkedin'  => '<path d="M6.94 5.5a1.94 1.94 0 1 1-3.88 0 1.94 1.94 0 0 1 3.88 0zM6.7 8.98H3.3V21h3.4V8.98zm5.43 0H8.75V21h3.35v-6.31c0-1.72.32-3.39 2.45-3.39 2.1 0 2.13 1.97 2.13 3.5V21H20v-6.87c0-2.91-.63-5.15-4.03-5.15-1.64 0-2.74.9-3.19 1.75h-.05V8.98z"/>',
        'youtube'   => '<path d="M21.58 7.19a2.76 2.76 0 0 0-1.94-1.96C17.92 4.77 12 4.77 12 4.77s-5.92 0-7.64.46A2.76 2.76 0 0 0 2.42 7.2C2 8.93 2 12 2 12s0 3.08.42 4.81a2.76 2.76 0 0 0 1.94 1.96c1.72.46 7.64.46 7.64.46s5.92 0 7.64-.46a2.76 2.76 0 0 0 1.94-1.96C22 15.08 22 12 22 12s0-3.07-.42-4.81zM10.05 15.3V8.7L15.8 12l-5.75 3.3z"/>',
        'tiktok'    => '<path d="M16.6 5.82A4.28 4.28 0 0 1 15.54 3h-3.09v12.4a2.59 2.59 0 1 1-1.85-2.48V9.78a5.68 5.68 0 1 0 4.94 5.62V9.01a7.35 7.35 0 0 0 4.3 1.38V7.3a4.29 4.29 0 0 1-3.24-1.48z"/>',
        'x'         => '<path d="M18.24 2.25h3.31l-7.23 8.26 8.5 11.24h-6.64l-5.2-6.8-5.95 6.8H1.71l7.49-8.56L1.05 2.25h6.81l4.9 6.47 5.48-6.47zm-1.17 17.52h1.83L7.02 4.13H5.06l12.01 15.64z"/>',
    );

    $etichette = array(
        'facebook'  => 'Facebook',
        'instagram' => 'Instagram',
        'linkedin'  => 'LinkedIn',
        'youtube'   => 'YouTube',
        'tiktok'    => 'TikTok',
        'x'         => 'X',
    );

    $trovati = array();

    foreach ($disegni as $chiave => $disegno) {
        $url = farmaciainternazionale_social_url(get_option('ticinoweb_contact_' . $chiave, ''));
        if ('' === $url) {
            continue;
        }
        $trovati[] = array(
            'chiave'    => $chiave,
            'etichetta' => isset($etichette[$chiave]) ? $etichette[$chiave] : ucfirst($chiave),
            'url'       => $url,
            'svg'       => '<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true" focusable="false">' . $disegno . '</svg>',
        );
    }

    return $trovati;
}

/**
 * Riconosce un indirizzo social utilizzabile, e scarta tutto il resto.
 *
 * NON BASTA "NON VUOTO". In questi campi finiscono, per prove o per sbaglio, cose
 * che non portano da nessuna parte: un cancelletto, il solo `https://`, un
 * trattino. Mostrarne l'icona significa dare al visitatore un collegamento che
 * non funziona, il che e' peggio che non mostrarla.
 *
 * Chi scrive `instagram.com/nome` senza lo schema non ha sbagliato niente: gli si
 * completa l'indirizzo invece di far sparire l'icona senza spiegazioni.
 *
 * @param mixed $valore Valore grezzo dell'opzione.
 * @return string Indirizzo usabile, oppure stringa vuota.
 */
function farmaciainternazionale_social_url($valore)
{
    $url = trim((string) $valore);

    if ('' === $url || '#' === $url || '-' === $url) {
        return '';
    }

    if (!preg_match('#^[a-z][a-z0-9+.-]*://#i', $url)) {
        /* Senza schema: si completa solo se somiglia a un dominio. Una parola
           qualsiasi resta quello che e', cioe' non un indirizzo. */
        if (!preg_match('#^[^/\s]+\.[a-z]{2,}#i', $url)) {
            return '';
        }
        $url = 'https://' . $url;
    }

    $pezzi  = wp_parse_url($url);
    $schema = isset($pezzi['scheme']) ? strtolower($pezzi['scheme']) : '';

    if (empty($pezzi['host']) || !in_array($schema, array('http', 'https'), true)) {
        return '';
    }

    return $url;
}

/**
 * Gli indirizzi social devono potersi CANCELLARE dal pannello.
 *
 * IL PROBLEMA. Il tema padre salva questi sei campi con tw_preserve_url_option()
 * (inc/admin-settings.php, riga 320 e seguenti), che davanti a un campo vuoto NON
 * cancella: rimette il valore che c'era. Il ripristino si salta solo se il modulo
 * invia un campo nascosto `{opzione}_clear=1`, e per i social quel campo non
 * esiste da nessuna parte — l'ho cercato. Risultato: si cancella il testo, si
 * salva, e il collegamento torna. L'icona nel footer non se ne va piu'.
 *
 * PERCHE' SI RISOLVE QUI. Il tema padre non si modifica, e questa e' la ragione
 * per cui esiste un child theme. Si annulla la registrazione dell'impostazione —
 * unregister_setting() togli anche il filtro del padre, perche' WordPress si e'
 * tenuto da parte la sua funzione — e si registra di nuovo con un sanificatore
 * che tratta il vuoto come una scelta invece che come una distrazione.
 *
 * La priorita' 20 serve a passare DOPO ticinoweb_register_settings(), che gira su
 * admin_init a priorita' 10.
 */
add_action('admin_init', 'farmaciainternazionale_social_svuotabili', 20);
function farmaciainternazionale_social_svuotabili()
{
    foreach (array('facebook', 'instagram', 'linkedin', 'tiktok', 'x', 'youtube') as $rete) {
        $opzione = 'ticinoweb_contact_' . $rete;

        unregister_setting('ticinoweb_settings_group', $opzione);
        register_setting(
            'ticinoweb_settings_group',
            $opzione,
            array('type' => 'string', 'sanitize_callback' => 'farmaciainternazionale_social_sanifica')
        );
    }
}

/**
 * Ripulisce un indirizzo social in arrivo dal pannello.
 *
 * Il campo vuoto resta vuoto: e' tutta la differenza con il comportamento del
 * tema padre.
 *
 * @param mixed $valore Valore inviato dal modulo.
 * @return string
 */
function farmaciainternazionale_social_sanifica($valore)
{
    $valore = trim((string) $valore);

    return '' === $valore ? '' : esc_url_raw($valore);
}

/**
 * Indirizzo della mappa incorporata di Google.
 *
 * PERCHE' SI CERCA IL NOME E NON LA VIA: interrogando Google con la via, la
 * mappa trova un civico e il segnaposto si chiama "5". Cercando il nome
 * dell'attivita' trova la SCHEDA, e il segnaposto porta "Internazionale" con
 * indirizzo, valutazione e il pulsante per le indicazioni.
 *
 * La via viene scartata di proposito anche per un secondo motivo: il CMS dice
 * Via Vincenzo Vela 5, la scheda Google dice Via Serafino Balestra 6, e finche'
 * i due non concordano una mappa costruita sulla via rischia di inquadrare il
 * posto sbagliato. Nome e localita' bastano e non sono in discussione.
 *
 * @param int $zoom Livello di ingrandimento.
 * @return string Indirizzo per l'iframe, oppure stringa vuota se manca il nome.
 */
function farmaciainternazionale_map_embed_src($zoom = 17)
{
    $indirizzo = (string) get_option('ticinoweb_contact_address', '');
    $indirizzo = str_replace(array("\n", "\r", '(Indirizzo dal CMS)'), ' ', $indirizzo);
    $indirizzo = preg_replace('/\s+/', ' ', trim($indirizzo));

    /* Dal codice postale in poi: "Via Vincenzo Vela 5, 6600 Locarno" -> "6600 Locarno". */
    $localita = '';
    if (preg_match('/(\d{4}\s+\D.*)$/u', $indirizzo, $trovato)) {
        $localita = trim($trovato[1], " ,");
    }

    $pezzi = array_filter(array(trim((string) get_bloginfo('name')), $localita));
    if (empty($pezzi)) {
        return '';
    }

    return 'https://maps.google.com/maps?q=' . rawurlencode(implode(', ', $pezzi))
        . '&t=&z=' . (int) $zoom . '&ie=UTF8&iwloc=&output=embed';
}

/**
 * Forza il link "Home" nel menu di WordPress a puntare alla vera homepage
 * anche se l'utente ha inserito la pagina "Home" (che punta a /home/) nel menu.
 */
add_filter('nav_menu_link_attributes', 'fi_fix_home_menu_link', 10, 3);
function fi_fix_home_menu_link($atts, $item, $args) {
    if (strtolower(trim($item->title)) === 'home') {
        $atts['href'] = site_url('/');
    }
    return $atts;
}

// Registro delle immagini fisse del tema e pannello per sostituirle.
require_once get_stylesheet_directory() . '/inc/admin-immagini.php';

// Dati condivisi e opzioni backend per la pagina Emergenze.
require_once get_stylesheet_directory() . '/inc/admin-emergenze.php';

// Gestione centralizzata dei blocchi editoriali presenti nelle pagine.
require_once get_stylesheet_directory() . '/inc/site-blocks.php';
/* Occhielli, titoli e testi delle sezioni: stessa pagina «Blocchi del sito». */
require_once get_stylesheet_directory() . '/inc/site-headings.php';

// Impostazioni, provisioning pagina e gestione sicura del form Invio Ricette.
require_once get_stylesheet_directory() . '/inc/invio-ricette.php';

// Dati e pannello «Badge Aiuto»: le domande della pastiglia.
// PRIMA di aiuto.php, che usa le sue funzioni per leggere gli argomenti.
require_once get_stylesheet_directory() . '/inc/admin-aiuto.php';

// Pastiglia "Come possiamo aiutarti": la resa a schermo.
require_once get_stylesheet_directory() . '/inc/aiuto.php';

// Pagina dell'informativa privacy: creazione, template e registrazione in WordPress.
require_once get_stylesheet_directory() . '/inc/privacy.php';

// Popup gestibili dal pannello: elenco, editor e uscita sul sito.
require_once get_stylesheet_directory() . '/inc/popup.php';

// Selettore di lingua a bandiere: impostazioni del plugin, uscita e avvisi.
require_once get_stylesheet_directory() . '/inc/lingue.php';

// Dopo l'aggiornamento: svuota la cache del server e marca la versione.
require_once get_stylesheet_directory() . '/inc/aggiornamento.php';
