<?php
/**
 * Template Name: Servizi
 * Description: Template dedicato alla presentazione dei servizi della farmacia.
 */

get_header();

// Recupero i servizi dal CMS
$services = function_exists('ticinoweb_get_services') ? ticinoweb_get_services() : [];
$page_title = get_the_title();
/* Il riassunto della pagina vince; altrimenti il testo di Blocchi del sito. */
$page_desc = has_excerpt() ? get_the_excerpt() : fi_heading('services_hero')['text'];

// Fallback CTA
$contact_page = function_exists('ticinoweb_get_mapped_page_url') ? ticinoweb_get_mapped_page_url('page_contatti') : '#contatti';
$map_link = function_exists('ticinoweb_get_contact_info') ? (ticinoweb_get_contact_info()['google_maps_url'] ?? '#') : '#';

/**
 * Funzione helper per ottenere l'icona SVG corretta in base al titolo
 */
function fi_get_fallback_icon($title) {
    $title = strtolower($title);
    if (strpos($title, 'consulenza') !== false) {
        return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/></svg>';
    } elseif (strpos($title, 'natur') !== false || strpos($title, 'fito') !== false) {
        return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M12 22c5.523 0 10-4.477 10-10S17.523 2 12 2 2 6.477 2 12s4.477 10 10 10z"/><path d="M12 16v-4"/><path d="M12 8h.01"/></svg>'; 
    } elseif (strpos($title, 'salute') !== false || strpos($title, 'benessere') !== false) {
        return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M20.42 4.58a5.4 5.4 0 0 0-7.65 0l-.77.78-.77-.78a5.4 5.4 0 0 0-7.65 0C1.46 6.7 1.33 10.28 4 13l8 8 8-8c2.67-2.72 2.54-6.3.42-8.42z"/></svg>';
    } elseif (strpos($title, 'cura') !== false || strpos($title, 'viso') !== false) {
        return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M18 11V6a2 2 0 0 0-2-2v0a2 2 0 0 0-2 2v0"/><path d="M14 10V4a2 2 0 0 0-2-2v0a2 2 0 0 0-2 2v2"/><path d="M10 10.5V6a2 2 0 0 0-2-2v0a2 2 0 0 0-2 2v8"/><path d="M18 8a2 2 0 1 1 4 0v6a8 8 0 0 1-8 8h-2c-2.8 0-4.5-.86-5.99-2.34l-3.6-3.6a2 2 0 0 1 2.83-2.82L7 15"/></svg>';
    } elseif (strpos($title, 'orientamento') !== false || strpos($title, 'sanitario') !== false) {
        return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><circle cx="12" cy="12" r="10"/><path d="m16.24 7.76-2.12 6.36-6.36 2.12 2.12-6.36 6.36-2.12z"/></svg>';
    } else {
        return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>';
    }
}
?>

<main id="primary" class="site-main fi-servizi-page">

    <!-- 1. HERO INTERNA SERVIZI -->
    <section class="fi-servizi-hero">
        <div class="fi-hero-bg-glow glow-1"></div>
        <div class="fi-hero-bg-glow glow-2"></div>
        <div class="fi-hero-botanical-pattern"></div>
        <div class="container">
            <div class="fi-servizi-hero-content text-center">
                <div class="fi-hero-badges">
                    <?php fi_heading_badges('services_hero'); ?>
                </div>
                <h1 class="fi-servizi-title reveal-text"><?php echo esc_html($page_title); ?></h1>
                <?php if ('' !== $page_desc) : ?>
                <p class="fi-servizi-subtitle reveal-text delay-1"><?php echo esc_html($page_desc); ?></p>
                <?php endif; ?>
            </div>
        </div>
    </section>

    <!-- 2. INTRODUZIONE BREVE -->
    <section class="fi-servizi-intro fi-section-spacing">
        <div class="container">
            <div class="row justify-content-center text-center">
                <div class="col-lg-8">
                    <p class="fi-text-lead reveal-text">I nostri servizi nascono per offrirti molto più di un semplice prodotto. Crediamo nel valore dell'ascolto e della prevenzione, sostenuti da decenni di competenza farmaceutica e da un aggiornamento costante sulle evidenze scientifiche.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- 3. SERVIZI DINAMICI DAL CMS -->
    <section class="fi-servizi-list fi-section-spacing bg-light-green">
        <div class="container">
            <?php if (!empty($services)) : ?>
                <div class="fi-servizi-wrapper">
                    <?php 
                    $count = 0;
                    foreach ($services as $service) : 
                        $count++;
                        $is_even = $count % 2 == 0;
                        $has_image = !empty($service['image']);
                        $title = $service['title'] ?? '';
                        $desc = $service['description'] ?? '';
                        
                        // Pulizia HTML
                        $desc_clean = wp_strip_all_tags($desc);
                    ?>
                        <div class="fi-servizio-block <?php echo $is_even && $has_image ? 'layout-reversed' : ''; ?> <?php echo !$has_image ? 'no-image-layout' : ''; ?>">
                            
                            <?php if ($has_image) : ?>
                                <div class="fi-servizio-image-col">
                                    <div class="fi-servizio-img-wrapper">
                                        <img src="<?php echo esc_url($service['image']); ?>" alt="<?php echo esc_attr($title); ?>" loading="lazy">
                                    </div>
                                </div>
                            <?php endif; ?>

                            <div class="fi-servizio-content-col">
                                <div class="fi-servizio-card">
                                    <div class="fi-servizio-header">
                                        <div class="fi-servizio-icon">
                                            <?php 
                                            if (!empty($service['icon_svg'])) {
                                                echo '<img src="' . esc_url($service['icon_svg']) . '" alt="icona" class="custom-svg-icon">';
                                            } elseif (!empty($service['icon'])) {
                                                echo '<span class="dashicons ' . esc_attr($service['icon']) . '"></span>';
                                            } else {
                                                echo fi_get_fallback_icon($title);
                                            }
                                            ?>
                                        </div>
                                        <h3 class="fi-servizio-title"><?php echo esc_html($title); ?></h3>
                                    </div>
                                    
                                    <div class="fi-servizio-desc-wrapper">
                                        <p class="fi-servizio-desc"><?php echo esc_html($desc_clean); ?></p>
                                    </div>
                                    
                                    <a href="<?php echo esc_url(home_url('/contatti/')); ?>" class="fi-btn-link">Richiedi consiglio <i class="fas fa-arrow-right"></i></a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else : ?>
                <div class="text-center py-5">
                    <p class="fi-text-muted">I servizi verranno aggiornati a breve.</p>
                </div>
            <?php endif; ?>
        </div>
    </section>

    <!-- 4. METODO / COME TI ACCOMPAGNIAMO -->
    <section class="fi-servizi-process fi-section-spacing">
        <div class="container">
            <div class="text-center mb-5">
                <h2 class="fi-section-title"><?php echo esc_html(fi_heading('services_method')['title']); ?></h2>
                <?php if ('' !== fi_heading('services_method')['text']) : ?><p class="fi-text-lead mx-auto" style="max-width:600px; margin: 0 auto;"><?php echo esc_html(fi_heading('services_method')['text']); ?></p><?php endif; ?>
            </div>
            
            <div class="fi-process-timeline">
                <div class="fi-process-line"></div>
                <?php foreach (fi_get_site_blocks('services_process') as $index => $block) : ?>
                    <div class="fi-process-step">
                        <div class="fi-step-node">
                            <span class="fi-step-number"><?php echo esc_html($index + 1); ?></span>
                            <div class="fi-step-icon"><?php echo fi_get_dynamic_block_icon($block['title'], $block['text'], $block['icon']); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div>
                        </div>
                        <div class="fi-step-content">
                            <h4><?php echo esc_html($block['title']); ?></h4>
                            <p><?php echo esc_html($block['text']); ?></p>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- 5. VALORI / ESPERIENZA -->
    <section class="fi-servizi-values fi-section-spacing bg-light-green">
        <div class="container">
            <div class="text-center mb-5">
                <h2 class="fi-section-title"><?php echo esc_html(fi_heading('services_values')['title']); ?></h2>
                <?php if ('' !== fi_heading('services_values')['text']) : ?><p class="fi-text-lead mx-auto" style="max-width: 700px; margin: 0 auto;"><?php echo esc_html(fi_heading('services_values')['text']); ?></p><?php endif; ?>
            </div>
            
            <div class="fi-values-grid">
                <?php foreach (fi_get_site_blocks('services_values') as $block) : ?>
                    <div class="fi-value-card">
                        <div class="fi-value-icon"><?php echo fi_get_dynamic_block_icon($block['title'], $block['text'], $block['icon']); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div>
                        <div class="fi-value-text">
                            <span class="fi-value-title"><?php echo esc_html($block['title']); ?></span>
                            <p><?php echo esc_html($block['text']); ?></p>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>
    
    <!-- Fine contenuti principali -->


</main>

<?php get_footer(); ?>
