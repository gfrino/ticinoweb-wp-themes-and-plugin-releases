<?php
/**
 * Template Name: Homepage Farmacia Internazionale
 */
get_header();

?>

<main id="primary" class="site-main fi-home">

    <!-- 1. CLEAN HERO PREMIUM -->
    <section class="fi-clean-hero">
        <div class="fi-hero-noise"></div>

        <!-- Elemento Botanico Premium in basso a sx -->
        <div class="fi-hero-branch-wrapper">
            <svg class="fi-hero-branch-svg" viewBox="0 0 200 300" xmlns="http://www.w3.org/2000/svg">
                <!-- Stelo sottile ed elegante -->
                <path d="M 20,280 C 40,180 90,80 150,10" fill="none" stroke="currentColor" stroke-width="1.5"
                    stroke-linecap="round" />
                <!-- Silhouette foglie allungate -->
                <path d="M 25,230 C -5,220 5,160 30,150 C 45,170 45,210 25,230" fill="currentColor" />
                <path d="M 45,190 C 75,185 105,210 100,245 C 80,235 55,215 45,190" fill="currentColor" />
                <path d="M 55,140 C 25,120 20,60 50,55 C 65,80 75,120 55,140" fill="currentColor" />
                <path d="M 80,110 C 110,100 145,120 140,155 C 120,140 90,120 80,110" fill="currentColor" />
                <path d="M 105,50 C 85,25 90,-10 120,-5 C 130,15 125,40 105,50" fill="currentColor" />
                <path d="M 125,30 C 155,20 185,45 170,80 C 155,60 135,40 125,30" fill="currentColor" />
            </svg>
        </div>

        <div class="fi-hero-glows">
            <div class="fi-glow glow-primary"></div>
            <div class="fi-glow glow-secondary"></div>
        </div>

        <div class="container clean-hero-container">
            <?php
            // Fetch first slide for Hero content
            $image = get_option("ticinoweb_slider_image_1") ?: get_theme_mod("slider_image_1");

            // Apertura Hero: gestita in «Blocchi del sito» (con fallback su opzioni storiche e default)
            $hero_blocks = function_exists('fi_get_site_blocks') ? fi_get_site_blocks('home_hero') : array();
            $hero_block  = !empty($hero_blocks) ? $hero_blocks[0] : null;

            $title = !empty($hero_block['title'])
                ? $hero_block['title']
                : (get_option("ticinoweb_slider_title_1") ?: get_theme_mod("slider_title_1", "Benvenuti alla Farmacia Internazionale di Locarno"));

            $desc = !empty($hero_block['text'])
                ? $hero_block['text']
                : (get_option("ticinoweb_slider_desc_1") ?: get_theme_mod("slider_desc_1", "Da oltre 30 anni siamo al servizio della tua salute.\nUn punto di riferimento per consulenza farmaceutica, prodotti naturali, prevenzione e orientamento verso i servizi sanitari più adatti."));

            $btn1_text = get_option("ticinoweb_slider_btn_text_1") ?: get_theme_mod("slider_btn1_text_1", "I Nostri Servizi");
            $btn1_link = get_option("ticinoweb_slider_btn_link_1") ?: get_theme_mod("slider_btn1_link_1", "#servizi");

            // Pulsante 2
            $btn2_text = get_option("ticinoweb_slider_btn2_text_1") ?: get_theme_mod("slider_btn2_text_1");
            $btn2_link = get_option("ticinoweb_slider_btn2_link_1") ?: get_theme_mod("slider_btn2_link_1");
            ?>

            <!-- COLONNA SINISTRA (TESTO) -->
            <div class="hero-content-left reveal-up">

                <h1 class="fi-hero-title"><?php echo wp_kses_post($title); ?></h1>
                <?php
                /*
                 * nl2br PERCHE' IL CAMPO NEL PANNELLO E' UN'AREA DI TESTO.
                 *
                 * Chi scrive due frasi su due righe si aspetta di vederle su due
                 * righe. Il pannello del tema padre salva questo campo con
                 * sanitize_textarea_field, che conserva gli a-capo — ma in HTML un
                 * a-capo non si vede, quindi finora andavano perduti in silenzio.
                 */
                ?>
                <p class="fi-hero-desc"><?php echo nl2br(wp_kses_post($desc)); ?></p>

                <div class="fi-hero-actions">
                    <?php if (!empty($btn1_text)): ?>
                        <a href="<?php echo esc_url($btn1_link); ?>"
                            class="fi-btn fi-btn-primary"><?php echo esc_html($btn1_text); ?></a>
                    <?php endif; ?>
                    <?php if (!empty($btn2_text) && $btn2_text !== $btn1_text): ?>
                        <a href="<?php echo esc_url($btn2_link); ?>"
                            class="fi-btn fi-btn-secondary"><?php echo esc_html($btn2_text); ?></a>
                    <?php endif; ?>
                </div>
            </div>

            <!-- COLONNA DESTRA (IMMAGINE) -->
            <div class="hero-image-right reveal-up" style="transition-delay: 0.2s;">
                <div class="fi-hero-image-wrapper">
                    <?php
                    /* L'immagine viene dal pannello «Immagini del sito», che
                       ripiega da solo su quel che c'era prima. */
                    $hero_img = fi_immagine('hero');
                    ?>
                    <?php if ('' !== $hero_img) : ?>
                        <img src="<?php echo esc_url($hero_img); ?>" alt="<?php echo esc_attr(get_bloginfo('name')); ?>" class="fi-hero-img" />
                    <?php endif; ?>

                    <div class="fi-image-micro-card">
                        <div class="micro-card-icon">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"
                                stroke-linecap="round" stroke-linejoin="round" style="width:20px;height:20px;">
                                <path d="M22 12h-4l-3 9L9 3l-3 9H2"></path>
                            </svg>
                        </div>
                        <div class="micro-card-text">
                            <strong>Supporto Sanitario</strong>
                            <span>Consulenza personalizzata</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- 2. SEZIONE INTRODUZIONE "UNA FARMACIA DIVERSA" -->
    <section class="fi-intro-section section-pad" id="chi-siamo">
        <div class="fi-intro-bg-glow"></div>
        <div class="container">
            <div class="fi-intro-header-grid reveal-up">
                <div class="intro-gallery-col">
                    <?php
                    $gallery_id = 3;
                    $gallery_images = get_posts([
                        'post_type'      => 'attachment',
                        'post_status'    => 'inherit',
                        'posts_per_page' => -1,
                        'tax_query'      => [
                            [
                                'taxonomy' => 'ticinoweb_media_gallery',
                                'field'    => 'term_id',
                                'terms'    => $gallery_id,
                            ],
                        ],
                    ]);

                    // Sort using custom gallery order if available
                    $saved_order = get_term_meta($gallery_id, '_ticinoweb_gallery_order', true);
                    if (!empty($saved_order) && is_array($saved_order) && $gallery_images) {
                        usort($gallery_images, function ($a, $b) use ($saved_order) {
                            $posA = array_search($a->ID, $saved_order);
                            $posB = array_search($b->ID, $saved_order);
                            if ($posA === false) $posA = 999999;
                            if ($posB === false) $posB = 999999;
                            return $posA - $posB;
                        });
                    }
                    ?>
                    <div class="intro-gallery-wrapper">
                        <div class="swiper intro-infinite-swiper">
                            <div class="swiper-wrapper">
                                <?php if ($gallery_images) : ?>
                                    <?php foreach ($gallery_images as $image) : ?>
                                        <div class="swiper-slide">
                                            <?php echo wp_get_attachment_image($image->ID, 'large', false, ['class' => 'intro-slide-img']); ?>
                                        </div>
                                    <?php endforeach; ?>
                                <?php else : ?>
                                    <?php
                                    /*
                                     * NESSUNA FOTO ASSEGNATA ALLA GALLERIA: si mostra
                                     * l'immagine scelta per l'apertura della homepage,
                                     * che almeno e' della farmacia, invece delle due
                                     * fotografie d'archivio che stavano qui.
                                     *
                                     * Le foto di questa fascia si compongono dalla
                                     * Libreria media assegnandole alla galleria: e' la
                                     * strada indicata dal pannello «Immagini del sito».
                                     */
                                    $riserva_intro = fi_immagine('hero');
                                    ?>
                                    <?php if ('' !== $riserva_intro) : ?>
                                        <div class="swiper-slide"><img src="<?php echo esc_url($riserva_intro); ?>" class="intro-slide-img" alt="" /></div>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="intro-text-col">
                    <?php if ('' !== fi_heading('home_intro')['kicker']) : ?><span class="fi-sub-heading"><?php echo esc_html(fi_heading('home_intro')['kicker']); ?></span><?php endif; ?>
                    <h2 class="fi-section-title"><?php echo esc_html(fi_heading('home_intro')['title']); ?></h2>
                    <?php if ('' !== fi_heading('home_intro')['text']) : ?><p class="fi-lead"><?php echo esc_html(fi_heading('home_intro')['text']); ?></p><?php endif; ?>
                </div>
            </div>

            <div class="fi-intro-cards">
                <?php
                $home_intro_blocks = fi_get_site_blocks('home_intro');
                $intro_classes = array('card-left', 'card-center', 'card-right');
                foreach ($home_intro_blocks as $index => $block) :
                    $delay = $index ? 'transition-delay: ' . ($index * 0.1) . 's;' : '';
                    ?>
                    <div class="fi-card intro-card <?php echo esc_attr($intro_classes[$index]); ?> reveal-up" <?php echo $delay ? 'style="' . esc_attr($delay) . '"' : ''; ?>>
                        <?php /* Il terzo argomento rispetta l'icona fissata nel registro, come già fanno le altre sezioni. */ ?>
                        <div class="card-icon"><?php echo fi_get_dynamic_block_icon($block['title'], $block['text'], $block['icon']); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div>
                        <h3><?php echo esc_html($block['title']); ?></h3>
                        <p><?php echo esc_html($block['text']); ?></p>
                    </div>
                <?php endforeach; ?>
            </div>

            <div class="fi-intro-cta text-center reveal-up" style="transition-delay: 0.3s; margin-top: 50px;">
                <a href="<?php echo esc_url(home_url('/chi-siamo/')); ?>" class="fi-btn fi-btn-secondary">Scopri la nostra storia</a>
            </div>
        </div>
    </section>

    <!-- 3. SEZIONE SERVIZI PRINCIPALI -->
    <section class="fi-services-section section-pad" id="servizi">
        <div class="fi-services-bg-glow"></div>
        <?php
        /*
         * Lo sfondo acquerello sta nella Libreria media di QUESTO sito e lo si
         * cerca per nome, non per indirizzo. Prima era scritto per esteso e
         * puntava a localhost:8081/.../sites/22/, cioe' al computer di chi lo
         * aveva caricato: fuori da quella macchina non si e' mai visto, e in
         * Multisite l'identificativo del sito cambia a ogni migrazione.
         * Se l'immagine non c'e', la sezione resta senza sfondo invece di
         * chiedere al browser un file che non esiste.
         */
        $fi_watercolor = farmaciainternazionale_media_url( 'hand-painted-watercolor-nature-background-easy' );
        ?>
        <?php if ( '' !== $fi_watercolor ) : ?>
            <div class="fi-services-watercolor-bg" style="background-image: url('<?php echo esc_url( $fi_watercolor ); ?>');"></div>
        <?php endif; ?>
        <div class="container">
            <div class="fi-section-header text-center reveal-up">
                <?php if ('' !== fi_heading('home_services')['kicker']) : ?><span class="fi-sub-heading"><?php echo esc_html(fi_heading('home_services')['kicker']); ?></span><?php endif; ?>
                <h2 class="fi-section-title"><?php echo esc_html(fi_heading('home_services')['title']); ?></h2>
                <?php if ('' !== fi_heading('home_services')['text']) : ?><p class="fi-lead" style="max-width: 700px; margin: 0 auto 50px;"><?php echo esc_html(fi_heading('home_services')['text']); ?></p><?php endif; ?>
            </div>

            <?php
            // Preleva servizi dal CMS (fallback statici eleganti se vuoto)
            $cms_services = function_exists('ticinoweb_get_services') ? ticinoweb_get_services() : [];
            $services = [];

            if (!empty($cms_services)) {
                foreach ($cms_services as $srv) {
                    if (empty($srv['title']))
                        continue;
                    $services[] = [
                        'title' => $srv['title'],
                        'desc' => isset($srv['description']) ? wp_trim_words($srv['description'], 15) : '',
                        /* L'icona rispetta tutte e tre le scelte del pannello:
                           immagine, SVG incollato o icona dall'elenco. */
                        'icon' => farmaciainternazionale_icona_servizio($srv),
                        /*
                         * NESSUNA DESTINAZIONE INVENTATA. Prima qui c'era
                         * home_url('/' . sanitize_title($title)): una pagina che
                         * non esiste, e ogni scheda rimbalzava in homepage con un
                         * 301. Il pannello non ha un campo per il collegamento,
                         * quindi di norma resta vuoto e la scheda non e' un link.
                         */
                        'link' => !empty($srv['link']) ? $srv['link'] : ''
                    ];
                }
            }

            if (empty($services)) {
                $services = [
                    ['title' => 'Consulenza', 'desc' => 'Risposte chiare per un uso corretto e sicuro dei medicamenti.', 'icon' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="12" y1="13" x2="12" y2="19"></line><line x1="9" y1="16" x2="15" y2="16"></line></svg>', 'link' => ''],
                    ['title' => 'Fitoterapia', 'desc' => 'Il potere delle piante officinali per curare con dolcezza.', 'icon' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M11 20A7 7 0 0 1 9.8 6.1C15.5 5 17 4.48 19 2c1 2 2 4.18 2 8 0 5.5-4.78 10-10 10Z"></path><path d="M2 21c0-3 1.85-5.36 5.08-6C9.5 14.52 12 13 13 12"></path></svg>', 'link' => ''],
                    ['title' => 'Benessere', 'desc' => 'Integrazione nutrizionale per sentirsi vitali ogni giorno.', 'icon' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M20.42 4.58a5.4 5.4 0 0 0-7.65 0l-.77.78-.77-.78a5.4 5.4 0 0 0-7.65 0C1.46 6.7 1.33 10.28 4 13l8 8 8-8c2.67-2.72 2.54-6.3.42-8.42z"></path></svg>', 'link' => ''],
                    ['title' => 'Cura Persona', 'desc' => 'Dermocosmesi di alta qualità per pelli sensibili.', 'icon' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22a7 7 0 0 0 7-7c0-2-1-3.9-3-5.5s-3.5-4-4-6.5c-.5 2.5-2 4.9-4 6.5C6 11.1 5 13 5 15a7 7 0 0 0 7 7z"></path></svg>', 'link' => ''],
                    ['title' => 'Maternità', 'desc' => 'Prodotti delicati e sicuri per mamma e bambino.', 'icon' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><path d="M8 14s1.5 2 4 2 4-2 4-2"></path><line x1="9" y1="9" x2="9.01" y2="9"></line><line x1="15" y1="9" x2="15.01" y2="9"></line></svg>', 'link' => ''],
                ];
            }
            ?>

            <div class="fi-services-grid">
                <?php foreach ($services as $index => $srv): ?>
                    <?php
                    /*
                     * LINK SOLO SE C'E' DOVE ANDARE. Il pannello non ha un campo
                     * per il collegamento, quindi di regola la scheda e' un <div>:
                     * meglio una scheda che si legge di un link che riporta in
                     * homepage. Se un giorno quel campo arrivera', la scheda
                     * ridiventa un link da sola, senza toccare niente qui.
                     */
                    $srv_link = isset($srv['link']) ? trim((string) $srv['link']) : '';
                    $srv_cliccabile = '' !== $srv_link && '#' !== $srv_link;
                    $srv_tag = $srv_cliccabile ? 'a' : 'div';
                    ?>
                    <<?php echo $srv_tag; ?> <?php if ($srv_cliccabile) : ?>href="<?php echo esc_url($srv_link); ?>" <?php endif; ?>class="fi-service-card reveal-up"
                        style="transition-delay: <?php echo ($index % 3) * 0.1; ?>s;">
                        <div class="srv-icon">
                            <?php
                            /* Markup gia' costruito e ripulito a monte: per i servizi
                               del CMS da farmaciainternazionale_icona_servizio(),
                               per quelli di ripiego scritto qui nel tema. */
                            echo $srv['icon']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
                            ?>
                        </div>
                        <div class="srv-content">
                            <h3 class="srv-title"><?php echo esc_html($srv['title']); ?></h3>
                            <p class="srv-desc"><?php echo esc_html($srv['desc']); ?></p>
                            <?php if ($srv_cliccabile) : ?>
                                <span class="srv-link-text">Scopri di più <i class="fas fa-arrow-right"></i></span>
                            <?php endif; ?>
                        </div>
                    </<?php echo $srv_tag; ?>>
                <?php endforeach; ?>

                <?php
                /*
                 * QUI C'ERA UNA SCHEDA "Hai bisogno di un consiglio?" con il
                 * pulsante Contattaci. E' stata tolta per fare posto a un
                 * servizio vero: l'invito a contattare resta comunque in due
                 * punti della stessa pagina, la fascia in fondo e la pastiglia
                 * "Come possiamo aiutarti", quindi non si perde niente.
                 */
                ?>
            </div>
        </div>
    </section>

    <!-- 4. SEZIONE NATURALE & BENESSERE -->
    <?php
    /*
     * L'immagine si sceglie dal pannello «Immagini del sito». Se non e' stata
     * scelta, fi_immagine() cerca da sola nella galleria 5 come faceva la query
     * che stava qui, e in ultimo usa la foto di riserva.
     */
    $gallery_img_url = fi_immagine('benessere');
    ?>
    <section class="fi-nature-section section-pad">
        <div class="fi-nature-bg"></div>
        <div class="container">
            <div class="nature-layout">
                <div class="nature-image-col reveal-up">
                    <div class="nature-img-wrapper">
                        <!-- Immagine Premium Fitoterapia Dinamica -->
                        <img src="<?php echo esc_url($gallery_img_url); ?>"
                            alt="Fitoterapia e Rimedi Naturali" />
                        <div class="nature-floating-botanical b1">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M11 20A7 7 0 0 1 9.8 6.1C15.5 5 17 4.48 19 2c1 2 2 4.18 2 8 0 5.5-4.78 10-10 10Z"></path><path d="M2 21c0-3 1.85-5.36 5.08-6C9.5 14.52 12 13 13 12"></path></svg>
                        </div>
                        <div class="nature-floating-botanical b2">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22c5.523 0 10-4.477 10-10S17.523 2 12 2 2 6.477 2 12s4.477 10 10 10z"></path><path d="M2 12h20"></path><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"></path></svg>
                        </div>
                    </div>
                </div>
                <div class="nature-text-col reveal-up" style="transition-delay: 0.2s;">
                    <?php if ('' !== fi_heading('home_nature')['kicker']) : ?><span class="fi-sub-heading text-green"><?php echo esc_html(fi_heading('home_nature')['kicker']); ?></span><?php endif; ?>
                    <h2 class="fi-section-title"><?php echo esc_html(fi_heading('home_nature')['title']); ?></h2>
                    <?php if ('' !== fi_heading('home_nature')['text']) : ?><p class="fi-lead"><?php echo esc_html(fi_heading('home_nature')['text']); ?></p><?php endif; ?>

                    <div class="nature-features-list">
                        <?php foreach (fi_get_site_blocks('home_nature') as $block) : ?>
                            <div class="nature-feature-item">
                                <div class="nf-icon"><?php echo fi_get_dynamic_block_icon($block['title'], $block['text'], $block['icon']); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div>
                                <div class="nf-content">
                                    <h3><?php echo esc_html($block['title']); ?></h3>
                                    <p><?php echo esc_html($block['text']); ?></p>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>

                    <div class="nature-cta">
                        <a href="<?php echo esc_url(home_url('/contatti/')); ?>" class="fi-btn fi-btn-secondary">Parla con un nostro esperto</a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- 5. SEZIONE SUPPORTO SANITARIO -->
    <section class="fi-support-section section-pad" style="position: relative; overflow-x: clip;">
        <?php $filigrana = fi_immagine('filigrana'); ?>
        <?php if ('' !== $filigrana) : ?>
            <div class="fi-floating-watermark">
                <?php /* Decorativa: alt vuoto, cosi' i lettori di schermo la saltano. */ ?>
                <img src="<?php echo esc_url($filigrana); ?>" alt="">
            </div>
        <?php endif; ?>
        
        <div class="container position-relative" style="z-index: 2;">
            <div class="fi-section-header text-center reveal-up">
                <?php if ('' !== fi_heading('home_orient')['kicker']) : ?><span class="fi-sub-heading"><?php echo esc_html(fi_heading('home_orient')['kicker']); ?></span><?php endif; ?>
                <h2 class="fi-section-title"><?php echo esc_html(fi_heading('home_orient')['title']); ?></h2>
                <?php if ('' !== fi_heading('home_orient')['text']) : ?><p class="fi-lead" style="max-width: 700px; margin: 0 auto;"><?php echo esc_html(fi_heading('home_orient')['text']); ?></p><?php endif; ?>
            </div>

            <div class="roadmap-wrapper">
                <div class="roadmap-bg-glow"></div>
                <div class="roadmap-bg-path reveal-up">
                    <svg viewBox="0 0 1000 250" preserveAspectRatio="none">
                        <!-- Curva morbida ed elegante -->
                        <path class="rm-main-path" d="M 50,150 C 250,250 750,50 950,150" fill="none" stroke="currentColor" stroke-width="2.5" stroke-dasharray="8 8" />
                        <!-- Micro dettagli di percorso -->
                        <circle cx="50" cy="150" r="4" fill="currentColor" />
                        <circle cx="500" cy="150" r="3" fill="currentColor" opacity="0.5" />
                        <circle cx="950" cy="150" r="4" fill="currentColor" />
                        <!-- Freccia finale -->
                        <polyline points="940,140 950,150 940,160" fill="none" stroke="currentColor" stroke-width="2" />
                    </svg>
                </div>

                <?php foreach (fi_get_site_blocks('home_support') as $index => $block) : ?>
                    <div class="roadmap-step rm-step-<?php echo esc_attr($index + 1); ?> reveal-up" style="transition-delay: <?php echo esc_attr(0.1 + ($index * 0.2)); ?>s;">
                        <div class="rm-card<?php echo 1 === $index ? ' center-card' : ''; ?>">
                            <div class="rm-node-badge<?php echo 1 === $index ? ' center-badge' : ''; ?>"><?php echo esc_html($index + 1); ?></div>
                            <div class="rm-icon"><?php echo fi_get_dynamic_block_icon($block['title'], $block['text']); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div>
                            <h3><?php echo esc_html($block['title']); ?></h3>
                            <p><?php echo esc_html($block['text']); ?></p>
                            <?php $fi_orient_badges = fi_heading('home_orient')['badges']; ?>
                            <?php if (2 === $index && !empty($fi_orient_badges)) : ?>
                                <div class="rm-micro-label">
                                    <?php /* Icona del segnaposto, fissa: e' un luogo qualunque sia il testo. */ ?>
                                    <?php echo fi_get_dynamic_block_icon('', '', 'pin'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
                                    <?php echo esc_html($fi_orient_badges[0]); ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- 6. SEZIONE STORIA 30+ ANNI (DINAMICA CMS) -->
    <?php
    $cms_title = get_option('ticinoweb_chi_siamo_title');
    $cms_text  = get_option('ticinoweb_chi_siamo_text');
    
    // Fallbacks
    $section_title = !empty($cms_title) ? $cms_title : 'Una storia di famiglia,<br>da oltre 30 anni.';
    $full_text = !empty($cms_text) ? $cms_text : 'Fondata oltre tre decenni fa, Farmacia Internazionale è un punto di riferimento a Locarno. Da padre in figlio, continua a unire ascolto, competenza e attenzione alla persona, combinando la tradizione farmaceutica con l\'approccio naturale.';
    $excerpt = wp_trim_words($full_text, 30, '&hellip;');
    
    $main_img_url = fi_immagine('storia');
    
    // Il link "Chi siamo" può arrivare dal custom link del CMS o dalla mappatura
    $cms_link = get_option('ticinoweb_chi_siamo_link');
    $mapped_url = function_exists('ticinoweb_get_mapped_page_url') ? ticinoweb_get_mapped_page_url('page_chi_siamo') : '';
    $cta_link = !empty($cms_link) ? $cms_link : (!empty($mapped_url) ? $mapped_url : '#chi-siamo');
    ?>
    <section class="fi-history-section section-pad">
        <div class="history-bg-noise"></div>
        <div class="history-big-watermark">30+</div>
        <div class="container">
            <div class="history-layout">
                
                <!-- Colonna Testo -->
                <div class="history-text reveal-up">
                    <?php if ('' !== fi_heading('home_history')['kicker']) : ?><span class="fi-sub-heading fi-sub-heading-light"><?php echo esc_html(fi_heading('home_history')['kicker']); ?></span><?php endif; ?>
                    <h2 class="fi-section-title"><?php echo wp_kses_post($section_title); ?></h2>
                    <p class="fi-lead-light">
                        <?php echo esc_html($excerpt); ?>
                    </p>
                    <a href="<?php echo esc_url($cta_link); ?>" class="fi-btn fi-btn-outline-light mt-3">Scopri di più</a>
                </div>

                <!-- Colonna Visuale -->
                <div class="history-visual-composition reveal-up" style="transition-delay: 0.2s;">
                    <div class="hist-img-main-wrapper" style="width: 100%;">
                        <img src="<?php echo esc_url($main_img_url); ?>" alt="<?php echo esc_attr(strip_tags($section_title)); ?>" class="hist-img-main" />
                    </div>

                    <div class="hist-micro-card reveal-up" style="transition-delay: 0.6s;">
                        <div class="hmc-icon">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20.2 7.8l-7.7 7.7-4-4-5.7 5.7"/><path d="M15 7h6v6"/></svg>
                        </div>
                        <div class="hmc-text">
                            <strong>30+ anni</strong>
                            <span>Da padre in figlio</span>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </section>

    <!-- 6.5 SEZIONE GALLERIA DINAMICA -->
    <section class="fi-gallery-section section-pad bg-white position-relative" style="position: relative; overflow: hidden;"><!-- `position: relative` sta qui e non solo nel foglio di stile perche' deve valere dal primo istante: e' quello che rende efficace l'`overflow: hidden` accanto, e senza di esso i bagliori qui sotto allargano la pagina di 50px finche' il CSS non arriva. La classe `position-relative` del markup non e' definita da nessuna parte. -->
        <!-- Sfondi decorativi leggeri -->
        <div class="fi-gallery-bg-glow" style="position: absolute; top: -100px; left: -100px; width: 400px; height: 400px; background: radial-gradient(circle, rgba(3,93,41,0.03) 0%, rgba(255,255,255,0) 70%); border-radius: 50%; pointer-events: none;"></div>
        <div class="fi-gallery-bg-glow" style="position: absolute; bottom: -150px; right: -50px; width: 500px; height: 500px; background: radial-gradient(circle, rgba(3,93,41,0.04) 0%, rgba(255,255,255,0) 70%); border-radius: 50%; pointer-events: none;"></div>
        
        <div class="container position-relative z-1">
            <div class="fi-section-header reveal-up text-center mb-5 mx-auto" style="max-width: 650px; text-align: center !important; margin-left: auto !important; margin-right: auto !important; display: flex !important; flex-direction: column !important; align-items: center !important;">
                <?php if ('' !== fi_heading('home_spaces')['kicker']) : ?><span class="fi-sub-heading d-block mb-2" style="font-size: 0.85rem; letter-spacing: 2px; text-transform: uppercase; color: #035D29; font-weight: 600; text-align: center !important; width: 100%;"><?php echo esc_html(fi_heading('home_spaces')['kicker']); ?></span><?php endif; ?>
                <h2 class="fi-section-title mb-3" style="text-align: center !important; width: 100%;"><?php echo esc_html(fi_heading('home_spaces')['title']); ?></h2>
                <div style="width: 40px; height: 2px; background-color: #035D29; margin: 0 auto 1.5rem; border-radius: 2px; opacity: 0.7;"></div>
                <?php if ('' !== fi_heading('home_spaces')['text']) : ?><p class="fi-lead" style="color: #555; text-align: center !important; width: 100%;"><?php echo esc_html(fi_heading('home_spaces')['text']); ?></p><?php endif; ?>
            </div>
            
            <?php
            $gallery_id = 6;
            $images_query = new WP_Query(array(
                'post_type'      => 'attachment',
                'post_status'    => 'inherit',
                'posts_per_page' => 50,
                'tax_query' => array(
                    array(
                        'taxonomy' => 'ticinoweb_media_gallery',
                        'field' => 'term_id',
                        'terms' => $gallery_id,
                    )
                )
            ));

            $saved_order = get_term_meta($gallery_id, '_ticinoweb_gallery_order', true);
            $ordered_images = array();
            if (!empty($saved_order) && is_array($saved_order)) {
                $unordered = array();
                foreach ($images_query->posts as $img) {
                    $unordered[$img->ID] = $img;
                }
                foreach ($saved_order as $id) {
                    if (isset($unordered[$id])) {
                        $ordered_images[] = $unordered[$id];
                        unset($unordered[$id]);
                    }
                }
                $ordered_images = array_merge($ordered_images, array_values($unordered));
            } else {
                $ordered_images = $images_query->posts;
            }

            if (!empty($ordered_images)) :
                $total_slides = count($ordered_images);
            ?>
            <div class="fi-gallery-swiper-container reveal-up delay-1" style="position: relative;">
                <div class="swiper fi-gallery-swiper">
                    <div class="swiper-wrapper">
                        <?php foreach ($ordered_images as $image) : 
                            $img_url = wp_get_attachment_image_url($image->ID, 'large');
                            $img_alt = get_post_meta($image->ID, '_wp_attachment_image_alt', true);
                            if (empty($img_alt)) $img_alt = $image->post_title;
                        ?>
                            <div class="swiper-slide">
                                <div class="fi-gallery-slide-inner">
                                    <img src="<?php echo esc_url($img_url); ?>" alt="<?php echo esc_attr($img_alt); ?>" class="fi-gallery-img">
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                
                <!-- Custom Navigation (outside swiper container on desktop) -->
                <button class="swiper-button-prev fi-gallery-prev" aria-label="Immagine precedente"></button>
                <button class="swiper-button-next fi-gallery-next" aria-label="Immagine successiva"></button>

                <!-- Custom Pagination: Progress Bar + Fraction -->
                <div class="fi-gallery-controls">
                    <div class="fi-gallery-fraction">
                        <span class="fi-gallery-current">01</span>
                        <span class="fi-gallery-separator">/</span>
                        <span class="fi-gallery-total"><?php echo sprintf('%02d', $total_slides); ?></span>
                    </div>
                    <div class="fi-gallery-progress-bar">
                        <div class="fi-gallery-progress-fill"></div>
                    </div>
                </div>
            </div>
            
            <script>
            document.addEventListener("DOMContentLoaded", function() {
                if (typeof Swiper !== 'undefined') {
                    const progressFill = document.querySelector('.fi-gallery-progress-fill');
                    const currentNum = document.querySelector('.fi-gallery-current');
                    const totalSlides = <?php echo $total_slides; ?>;
                    
                    const gallerySwiper = new Swiper(".fi-gallery-swiper", {
                        slidesPerView: 1,
                        spaceBetween: 20,
                        centeredSlides: true,
                        loop: true,
                        speed: 800,
                        autoplay: {
                            delay: 5000,
                            disableOnInteraction: false,
                            pauseOnMouseEnter: true
                        },
                        navigation: {
                            nextEl: ".fi-gallery-next",
                            prevEl: ".fi-gallery-prev",
                        },
                        breakpoints: {
                            768: {
                                slidesPerView: 1.5,
                                spaceBetween: 30,
                            },
                            1024: {
                                slidesPerView: 2.2,
                                spaceBetween: 40,
                            },
                            1200: {
                                slidesPerView: 2.6,
                                spaceBetween: 50,
                            }
                        },
                        on: {
                            init: function () {
                                updateProgress(this.realIndex);
                            },
                            slideChange: function () {
                                updateProgress(this.realIndex);
                            }
                        }
                    });
                    
                    function updateProgress(realIndex) {
                        if(progressFill && currentNum) {
                            let current = realIndex + 1;
                            let percentage = (current / totalSlides) * 100;
                            progressFill.style.width = percentage + '%';
                            currentNum.textContent = current < 10 ? '0' + current : current;
                        }
                    }
                }
            });
            </script>
            <style>
                .fi-gallery-swiper-container {
                    padding: 20px 0;
                    margin: 0 -15px; /* Compensa padding su mobile */
                }
                
                @media (min-width: 768px) {
                    .fi-gallery-swiper-container {
                        margin: 0;
                        padding: 20px 40px;
                    }
                }
                
                /* Configurazione slide per effetto premium */
                .fi-gallery-swiper .swiper-slide {
                    transition: all 0.6s cubic-bezier(0.25, 1, 0.5, 1);
                    opacity: 0.6;
                    transform: scale(0.92);
                    border-radius: 24px;
                    overflow: hidden;
                    box-shadow: 0 5px 15px rgba(0,0,0,0.03);
                }
                
                .fi-gallery-swiper .swiper-slide-active {
                    opacity: 1;
                    transform: scale(1);
                    box-shadow: 0 15px 35px rgba(3,93,41,0.08);
                    z-index: 2;
                }
                
                .fi-gallery-slide-inner {
                    width: 100%;
                    height: 350px;
                    overflow: hidden;
                    border-radius: 24px;
                    position: relative;
                }
                
                @media (min-width: 768px) {
                    .fi-gallery-slide-inner {
                        height: 420px;
                    }
                }
                
                @media (min-width: 1024px) {
                    .fi-gallery-slide-inner {
                        height: 480px;
                    }
                }
                
                .fi-gallery-img {
                    width: 100%;
                    height: 100%;
                    object-fit: cover;
                    transition: transform 1.2s cubic-bezier(0.25, 1, 0.5, 1);
                    display: block;
                }
                
                /* Effetto hover solo sulla slide attiva per evitare caos */
                @media (prefers-reduced-motion: no-preference) {
                    .fi-gallery-swiper .swiper-slide-active:hover .fi-gallery-img {
                        transform: scale(1.05);
                    }
                }
                
                /* Frecce personalizzate */
                .fi-gallery-prev, 
                .fi-gallery-next {
                    position: absolute;
                    top: 45%;
                    transform: translateY(-50%);
                    width: 48px;
                    height: 48px;
                    background: #fff;
                    border: 1px solid rgba(3,93,41,0.15);
                    border-radius: 50%;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    color: #035D29;
                    box-shadow: 0 4px 15px rgba(0,0,0,0.06);
                    z-index: 10;
                    cursor: pointer;
                    transition: all 0.3s ease;
                }
                
                .fi-gallery-prev::after,
                .fi-gallery-next::after {
                    font-size: 16px;
                    font-weight: 900;
                }
                
                .fi-gallery-prev {
                    left: 10px;
                }
                
                .fi-gallery-next {
                    right: 10px;
                }
                
                @media (min-width: 1024px) {
                    .fi-gallery-prev {
                        left: -24px;
                    }
                    .fi-gallery-next {
                        right: -24px;
                    }
                }
                
                .fi-gallery-prev:hover,
                .fi-gallery-next:hover {
                    background: #035D29;
                    color: #fff;
                    box-shadow: 0 6px 20px rgba(3,93,41,0.2);
                    border-color: #035D29;
                }
                
                @media (max-width: 767px) {
                    .fi-gallery-prev, .fi-gallery-next {
                        display: none; /* Nascondi frecce su mobile per dare priorità allo swipe */
                    }
                }

                /* Controlli inferiori (Frazione + Barra di progresso) */
                .fi-gallery-controls {
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    gap: 20px;
                    margin-top: 40px;
                    max-width: 300px;
                    margin-left: auto;
                    margin-right: auto;
                }
                
                .fi-gallery-fraction {
                    font-family: var(--fi-font-heading, "Inter", sans-serif);
                    font-size: 0.9rem;
                    color: #035D29;
                    font-weight: 600;
                    display: flex;
                    align-items: center;
                    gap: 4px;
                    min-width: 50px;
                }
                
                .fi-gallery-separator {
                    opacity: 0.4;
                    font-weight: 400;
                }
                
                .fi-gallery-total {
                    opacity: 0.6;
                    font-weight: 400;
                }
                
                .fi-gallery-progress-bar {
                    flex-grow: 1;
                    height: 2px;
                    background: rgba(3,93,41,0.15);
                    border-radius: 2px;
                    position: relative;
                    overflow: hidden;
                }
                
                .fi-gallery-progress-fill {
                    position: absolute;
                    top: 0;
                    left: 0;
                    height: 100%;
                    background: #035D29;
                    border-radius: 2px;
                    transition: width 0.4s ease;
                }
            </style>
            <?php endif; ?>
        </div>
    </section>
    <!-- 7. SEZIONE CATEGORIE (Vetrina Dinamica) -->
    <section class="fi-categories-section section-pad bg-light">
        <div class="container">
            <div class="fi-section-header reveal-up">
                <h2 class="fi-section-title"><?php echo esc_html(fi_heading('home_categories')['title']); ?></h2>
            </div>
            <div class="fi-category-grid">
                <?php
                /* Titoli e fotografie vengono dal pannello «Immagini del sito». */
                foreach (fi_reparti() as $index => $cat) :
                    ?>
                    <?php
                    /*
                     * DIV E NON <a>: queste quattro schede non hanno una pagina
                     * di reparto a cui portare, e prima puntavano a "#" — un
                     * link che finge di funzionare ma non va da nessuna parte.
                     * Meglio dichiarare che non sono cliccabili piuttosto che
                     * promettere una destinazione che non esiste.
                     */
                    ?>
                    <div class="fi-cat-card reveal-up<?php echo '' === $cat['url'] ? ' fi-cat-card--senza-foto' : ''; ?>" style="transition-delay: <?php echo ($index * 0.1); ?>s;">
                        <?php /* Senza fotografia il riquadro resta in tinta: il CSS
                                 di .fi-cat-card--senza-foto ci mette un fondo verde
                                 invece di lasciare un rettangolo bianco vuoto. */ ?>
                        <div class="cat-img"<?php if ('' !== $cat['url']) : ?> style="background-image: url('<?php echo esc_url($cat['url']); ?>');"<?php endif; ?>></div>
                        <div class="cat-overlay">
                            <h3><?php echo esc_html($cat['titolo']); ?></h3>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- 8. CONTATTO VELOCE -->
    <section class="fi-contact-section section-pad" id="contatti">
        <?php
        /* Recapiti solo dal CMS: un campo vuoto nasconde la riga, niente dati inventati. */
        $c_phone = trim((string) get_option('ticinoweb_contact_phone', ''));
        $c_phone_clean = str_replace(array(' ', '(', ')', '-'), '', $c_phone);
        $c_email = trim((string) get_option('ticinoweb_contact_email', ''));
        $c_address = trim((string) get_option('ticinoweb_contact_address', ''));
        $c_map_link = trim((string) get_option('ticinoweb_contact_map_link', ''));
        $c_hours = get_option('ticinoweb_contact_opening_hours', '');
        ?>
        <div class="container">
            <div class="contact-box panel-3d reveal-up">
                <div class="contact-info">
                    <h2><?php echo esc_html(fi_heading('home_contact')['title']); ?></h2>
                    <?php if ('' !== fi_heading('home_contact')['text']) : ?><p><?php echo esc_html(fi_heading('home_contact')['text']); ?></p><?php endif; ?>
                    <ul class="contact-list">
                        <?php if ('' !== $c_address) : ?>
                        <li>
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" class="fi-contact-icon"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path><circle cx="12" cy="10" r="3"></circle></svg>
                            <span><?php echo wp_kses_post(nl2br($c_address)); ?></span>
                        </li>
                        <?php endif; ?>
                        <?php if ('' !== $c_phone) : ?>
                        <li>
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" class="fi-contact-icon"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path></svg>
                            <span><?php echo esc_html($c_phone); ?></span>
                        </li>
                        <?php endif; ?>
                        <?php if ('' !== $c_email) : ?>
                        <li>
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" class="fi-contact-icon"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path><polyline points="22,6 12,13 2,6"></polyline></svg>
                            <span><a href="mailto:<?php echo esc_attr($c_email); ?>" style="color:inherit;text-decoration:none;"><?php echo esc_html($c_email); ?></a></span>
                        </li>
                        <?php endif; ?>
                        <li>
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" class="fi-contact-icon"><circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 16 14"></polyline></svg>
                            <span>
                            <?php
                            $has_v_hours = false;
                            $hours_list_html = '';
                            if (!empty($c_hours) && is_array($c_hours)) {
                                $days_map = array(
                                    'monday'    => 'Lun',
                                    'tuesday'   => 'Mar',
                                    'wednesday' => 'Mer',
                                    'thursday'  => 'Gio',
                                    'friday'    => 'Ven',
                                    'saturday'  => 'Sab',
                                    'sunday'    => 'Dom',
                                );
                                foreach ($days_map as $key => $label) {
                                    $day_data = isset($c_hours[$key]) ? $c_hours[$key] : array();
                                    if (isset($day_data['closed']) && $day_data['closed']) {
                                        $hours_list_html .= esc_html($label) . ': Chiuso<br>';
                                    } else {
                                        $slots = (isset($day_data['slots']) && is_array($day_data['slots'])) ? $day_data['slots'] : array();
                                        $slots_strings = array();
                                        foreach ($slots as $slot) {
                                            if (!empty($slot['open']) && !empty($slot['close'])) {
                                                $open = substr($slot['open'], 0, 5);
                                                $close = substr($slot['close'], 0, 5);
                                                $slots_strings[] = $open . ' - ' . $close;
                                                $has_v_hours = true;
                                            }
                                        }
                                        $hours_str = !empty($slots_strings) ? implode(', ', $slots_strings) : 'Chiuso';
                                        $hours_list_html .= esc_html($label) . ': ' . esc_html($hours_str) . '<br>';
                                    }
                                }
                            } elseif (is_string($c_hours) && !empty($c_hours)) {
                                $hours_list_html = wp_kses_post(nl2br($c_hours));
                                $has_v_hours = true;
                            }
                            
                            /* Senza orari nel CMS si invita a chiamare: mai orari inventati. */
                            if ($has_v_hours) {
                                echo $hours_list_html; // phpcs:ignore WordPress.Security.EscapeOutput -- costruito con esc_html sopra.
                            } else {
                                esc_html_e('Contattaci per confermare i nostri orari di apertura.', 'farmaciainternazionale-child-theme');
                            }
                            ?>
                        </span>
                        </li>
                    </ul>
                    <?php if ('' !== $c_phone) : ?>
                    <div class="contact-actions">
                        <a href="tel:<?php echo esc_attr($c_phone_clean); ?>" class="fi-btn fi-btn-primary"><i class="fas fa-phone-alt"></i> Chiama Ora</a>
                    </div>
                    <?php endif; ?>
                </div>
                <div class="contact-map">
                    <?php
                    /*
                     * Cercando l'indirizzo, Google trovava il civico e il
                     * segnaposto si chiamava "5". Ora si cerca la scheda
                     * dell'attivita': vedi farmaciainternazionale_map_embed_src()
                     * in functions.php.
                     */
                    $map_embed = farmaciainternazionale_map_embed_src(16);
                    ?>
                    <?php if ('' !== $map_embed) : ?>
                        <iframe
                            width="100%"
                            height="100%"
                            frameborder="0"
                            style="border:0; min-height: 400px; width: 100%; height: 100%;"
                            title="Mappa: dove siamo"
                            src="<?php echo esc_url($map_embed); ?>"
                            loading="lazy"
                            allowfullscreen>
                        </iframe>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>

</main>

<?php get_footer(); ?>
