<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php
    /*
     * PRIMA DI TUTTO IL RESTO: LA PAGINA NON DEVE POTER SCORRERE DI LATO.
     *
     * IL PROBLEMA, RIPRODOTTO. Il divieto di scorrimento orizzontale sta in
     * `style.css`, sul body. Finche' quel foglio non e' applicato il divieto non
     * esiste: la pagina senza stili e' larga 2016px, il telefono la lascia
     * scorrere di lato, e quando il foglio arriva la posizione resta storta.
     * Misurato su telefono con il foglio in ritardo di tre secondi — cioe' una
     * normale rete mobile, o un plugin di cache che carica il CSS in differita:
     * 456px di scorrimento durante il caricamento.
     *
     * PERCHE' QUI E NON NEL FOGLIO DI STILE. Queste righe sono dentro l'HTML:
     * valgono dal primo istante in cui il browser legge la pagina, senza
     * aspettare nessuna richiesta di rete. Un foglio esterno, per quanto
     * piccolo, e' sempre una richiesta che puo' tardare o essere rimandata.
     *
     * `data-no-optimize` dice a LiteSpeed di non toccarle: se le accorpasse al
     * resto del CSS tornerebbero a essere un file da scaricare, e il rimedio
     * perderebbe l'unica cosa che lo rende un rimedio.
     *
     * Sono la rete di sicurezza, non la regola: le misure vere restano in
     * style.css, che sovrascrive queste appena arriva.
     */
    ?>
    <style data-no-optimize="1" data-noptimize="1">html,body{overflow-x:clip}img,svg,video,iframe{max-width:100%;height:auto}</style>
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?> id="home">
<?php wp_body_open(); ?>

<?php
/*
 * Il selettore di lingua a bandiere sta in inc/lingue.php, insieme alle
 * impostazioni del plugin GTranslate e all'avviso che compare nel pannello se
 * il plugin non e' attivo. Qui sotto si chiama solo `fi_stampa_lingue()`, due
 * volte: la barra in alto e il menu del telefono.
 */

/*
 * L'INDIRIZZO DI BASE SI CALCOLA UNA VOLTA SOLA, QUI.
 *
 * Prima veniva calcolato dentro i due rami di ripiego delle navigazioni — quelli
 * che entrano in funzione solo se nessun menu e' configurato in WordPress. Ma il
 * pulsante «Contattaci Subito» del menu mobile lo usa fuori da quei rami: col
 * menu configurato (cioe' sempre, in condizioni normali) la variabile non
 * esisteva e il collegamento diventava relativo. Da /servizi/ portava a
 * /servizi/contatti/, che non esiste.
 */
$base_home_url = esc_url(str_replace('/homepage/', '/', site_url('/')));
?>

<!-- HEADER PRINCIPALE -->
<header class="fi-site-header" id="fi-main-header">
    <div class="fi-header-container container">
        
        <!-- LOGO BRAND -->
        <div class="fi-header-brand">
            <a href="<?php echo esc_url(home_url('/')); ?>" rel="home">
                <?php 
                $logo = '';
                if (function_exists('ticinoweb_get_site_logo')) {
                    $logo = ticinoweb_get_site_logo();
                }
                if (empty($logo) && get_option('ticinoweb_site_logo')) {
                    $logo = get_option('ticinoweb_site_logo');
                }
                if (empty($logo) && get_option('ticinoweb_site_icon')) {
                    $logo = get_option('ticinoweb_site_icon');
                }
                if (empty($logo) && get_option('ticinoweb_page_header_overlay_image')) {
                    $logo = get_option('ticinoweb_page_header_overlay_image');
                }
                if (empty($logo) && get_option('ticinoweb_page_header_bg_image')) {
                    $logo = get_option('ticinoweb_page_header_bg_image');
                }
                if (is_numeric($logo)) {
                    $logo = wp_get_attachment_image_url($logo, 'full');
                }
                
                if (!empty($logo)): 
                ?>
                    <img src="<?php echo esc_url($logo); ?>" alt="<?php bloginfo('name'); ?>" class="fi-logo-img">
                <?php else: ?>
                    <span class="fi-logo-text"><?php bloginfo('name'); ?></span>
                <?php endif; ?>
            </a>
        </div>

        <!-- NAVIGAZIONE DESKTOP -->
        <nav class="fi-desktop-nav">
            <?php
            if (has_nav_menu('primary')) {
                wp_nav_menu(array(
                    'theme_location' => 'primary',
                    'menu_class'     => 'fi-nav-list',
                    'container'      => false,
                    'fallback_cb'    => false,
                ));
            } else {
                /* $base_home_url e' gia' pronto in cima al file. */
                echo '<ul class="fi-nav-list">';
                echo '<li><a href="' . $base_home_url . '">Home</a></li>';
                echo '<li><a href="' . $base_home_url . 'chi-siamo/">Chi siamo</a></li>';
                echo '<li><a href="' . $base_home_url . 'servizi/">Servizi</a></li>';
                echo '<li><a href="' . $base_home_url . 'emergenze/">Emergenze</a></li>';
                echo '<li><a href="' . $base_home_url . 'contatti/">Contatti</a></li>';
                echo '</ul>';
            }
            ?>
        </nav>


        <?php
        /* Fra la navigazione e il pulsante del menu: e' il posto in cui si cerca
           un cambio lingua, e su schermo stretto lo nasconde il CSS perche' la'
           lo stesso selettore compare dentro il menu. */
        fi_stampa_lingue('barra');
        ?>

        <!-- HAMBURGER BUTTON (MOBILE) -->
        <button class="fi-hamburger-btn" aria-label="Menu" aria-expanded="false" id="fi-mobile-toggle">
            <span class="fi-hamburger-line"></span>
            <span class="fi-hamburger-line"></span>
            <span class="fi-hamburger-line"></span>
        </button>

    </div>
</header>

<!-- MOBILE MENU OVERLAY -->
<div class="fi-mobile-overlay" id="fi-mobile-overlay">
    <div class="fi-mobile-menu-container">
        <nav class="fi-mobile-nav">
            <?php
            if (has_nav_menu('primary')) {
                wp_nav_menu(array(
                    'theme_location' => 'primary',
                    'menu_class'     => 'fi-mobile-nav-list',
                    'container'      => false,
                    'fallback_cb'    => false,
                ));
            } else {
                /* $base_home_url e' gia' pronto in cima al file. */
                echo '<ul class="fi-mobile-nav-list">';
                echo '<li><a href="' . $base_home_url . '" class="fi-mobile-link">Home</a></li>';
                echo '<li><a href="' . $base_home_url . 'chi-siamo/" class="fi-mobile-link">Chi siamo</a></li>';
                echo '<li><a href="' . $base_home_url . 'servizi/" class="fi-mobile-link">Servizi</a></li>';
                echo '<li><a href="' . $base_home_url . 'emergenze/" class="fi-mobile-link">Emergenze</a></li>';
                echo '<li><a href="' . $base_home_url . 'contatti/" class="fi-mobile-link">Contatti</a></li>';
                echo '</ul>';
            }
            ?>
        </nav>
        
        <?php
        /* Nel menu del telefono le bandiere stanno sopra i pulsanti di contatto:
           chi apre il menu per cambiare lingua la trova senza scorrere fino in
           fondo, e chi lo apre per telefonare non se la trova davanti. */
        ?>
        <div class="fi-mobile-lingue">
            <?php
            /*
             * L'ETICHETTA NON SI TRADUCE — `notranslate` e `translate="no"`.
             *
             * Senza questo, Google la traduceva: in tedesco «Lingua» diventava
             * «Zunge», che e' la lingua dentro la bocca. Un selettore di lingua
             * tiene la propria etichetta ferma nella lingua del sito: e' il
             * modo in cui li scrivono tutti, e non c'e' niente da tradurre in
             * una fila di bandiere.
             */
            ?>
            <span class="fi-mobile-lingue__titolo notranslate" translate="no">Lingua</span>
            <?php fi_stampa_lingue('menu'); ?>
        </div>

        <div class="fi-mobile-bottom-cta">
            <a href="<?php echo esc_url($base_home_url . 'contatti/'); ?>" class="fi-btn fi-btn-primary w-100 text-center">Contattaci Subito</a>
            <?php 
            $contact = function_exists('ticinoweb_get_contact_info') ? ticinoweb_get_contact_info() : null;
            if ($contact && !empty($contact['phone'])): ?>
                <a href="tel:<?php echo esc_attr(preg_replace('/[^0-9+]/', '', $contact['phone'])); ?>" class="fi-mobile-phone-link">
                    <i class="fas fa-phone-alt"></i> <?php echo esc_html($contact['phone']); ?>
                </a>
            <?php endif; ?>
        </div>
    </div>
</div>
