<?php
/**
 * DOPO L'AGGIORNAMENTO DEL TEMA: SVUOTA LA CACHE E LASCIA UNA TRACCIA.
 *
 * IL PROBLEMA. Caricato il tema nuovo sul sito in linea, le modifiche non si
 * vedono. Non perche' il caricamento sia andato male: il server usa LiteSpeed,
 * che tiene in memoria le pagine gia' costruite e continua a servire quelle
 * vecchie. Il tema e' nuovo, la pagina che arriva al visitatore no.
 *
 * COSA FA QUESTO FILE. Tiene da parte il numero di versione dell'ultima volta.
 * Quando non corrisponde piu' a quello del tema installato — cioe' esattamente
 * una volta per aggiornamento — chiede a LiteSpeed di buttare via tutto il
 * salvato e riscrive il numero. Nessun gesto da fare a mano, nessun costo nelle
 * richieste normali: solo una lettura di un'opzione gia' in memoria.
 *
 * E LASCIA UNA TRACCIA. Nel codice della pagina finisce un commento con la
 * versione del tema. I visitatori non lo vedono; serve a rispondere in due
 * secondi, guardando il sito da fuori, alla domanda «l'aggiornamento e'
 * arrivato?» — senza dover entrare nel pannello.
 *
 * @package FarmaciaInternazionale
 */

if (!defined('ABSPATH')) {
    exit;
}

/** Dove si tiene da parte la versione vista l'ultima volta. */
define('FI_VERSIONE_VISTA', 'fi_versione_tema_vista');

/**
 * La versione dichiarata in style.css.
 *
 * @return string
 */
function fi_versione_tema()
{
    $tema = wp_get_theme(get_stylesheet());

    return (string) $tema->get('Version');
}

/**
 * SVUOTA LA CACHE QUANDO LA VERSIONE CAMBIA.
 *
 * L'opzione e' fra quelle caricate in blocco a ogni richiesta, quindi il
 * confronto non costa una query in piu'. Si scrive solo quando cambia davvero.
 *
 * Il numero si aggiorna *prima* di chiedere lo svuotamento: se qualcosa andasse
 * storto dentro il plugin della cache, non si resta a ripetere lo svuotamento a
 * ogni singola visita.
 *
 * @return void
 */
function fi_aggiornamento_controlla_versione()
{
    $adesso = fi_versione_tema();
    if ('' === $adesso || get_option(FI_VERSIONE_VISTA) === $adesso) {
        return;
    }

    update_option(FI_VERSIONE_VISTA, $adesso, false);

    /**
     * Prima dello svuotamento, per chi volesse aggiungere altre cache.
     *
     * @param string $adesso Versione appena installata.
     */
    do_action('fi_tema_aggiornato', $adesso);

    // LiteSpeed Cache: `litespeed_purge_all` e' l'aggancio pubblico del plugin
    // (src/api.cls.php). Se il plugin non c'e', questa riga non fa nulla.
    do_action('litespeed_purge_all');
}
add_action('init', 'fi_aggiornamento_controlla_versione');

/**
 * La versione, come commento nel codice della pagina.
 *
 * @return void
 */
function fi_aggiornamento_traccia()
{
    printf("<!-- tema farmaciainternazionale %s -->\n", esc_html(fi_versione_tema()));
}
add_action('wp_head', 'fi_aggiornamento_traccia', 1);
