<?php
/**
 * Gestione condivisa dei numeri di emergenza e dashboard amministrativa.
 *
 * @package Farmacia_Internazionale
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Normalizza un numero per un collegamento telefonico.
 *
 * @param string $phone Numero visualizzato.
 * @return string
 */
function fi_normalize_phone_for_tel($phone) {
    $phone      = trim(wp_strip_all_tags((string) $phone));
    $has_prefix = 0 === strpos($phone, '+');
    $digits     = preg_replace('/\D+/', '', $phone);

    return ($has_prefix ? '+' : '') . $digits;
}

/**
 * Mantiene solo i caratteri utili alla visualizzazione di un telefono.
 *
 * @param mixed $phone Valore inserito.
 * @return string
 */
function fi_emergenze_sanitize_phone($phone) {
    $phone = sanitize_text_field(wp_unslash((string) $phone));
    return trim(preg_replace('/[^0-9+().\s\-\/]/u', '', $phone));
}

/**
 * Valori predefiniti dei numeri principali.
 *
 * @return array
 */
function fi_emergenze_default_main_cards() {
    return array(
        array('title' => 'Ambulanza e pronto soccorso', 'phone' => '144', 'note' => '', 'active' => 1),
        array('title' => 'Casi urgenti di intossicazione', 'phone' => '145', 'note' => '', 'active' => 1),
        array('title' => 'Ente Ospedaliero Cantonale', 'phone' => '+41 91 811 13 03', 'note' => '', 'active' => 1),
        /*
         * La farmacia di turno era raggiungibile solo scorrendo fino al servizio
         * notturno, dentro la riga "Locarnese e Valli". E' pero' il numero che
         * serve piu' spesso a chi arriva su questa pagina di sera, quindi ha una
         * scheda sua in cima come gli altri. Il numero resta anche la' dentro:
         * la' e' l'informazione per regione, qui e' il contatto rapido.
         */
        array('title' => 'Farmacia di turno', 'phone' => '079 214 60 84', 'note' => 'Locarnese e Valli', 'active' => 1),
        array('title' => 'Medico d\'urgenza', 'phone' => '+41 91 800 18 28', 'note' => '', 'active' => 1),
    );
}

/**
 * Icona di una scheda dei numeri principali.
 *
 * PERCHE' NON PIU' PER POSIZIONE: prima emergenze.php pescava l'icona da un
 * elenco usando l'indice della scheda. Bastava scambiare due voci d'ordine per
 * ritrovarsi il battito cardiaco sulla farmacia di turno e il calendario sul
 * medico d'urgenza. Qui l'icona segue la SCHEDA, riconosciuta dalle parole del
 * titolo, quindi l'ordine si puo' cambiare liberamente.
 *
 * Funziona anche per le schede modificate dal pannello, che arrivano dal
 * database senza nessun campo icona.
 *
 * @param array $card Una scheda di fi_emergenze_default_main_cards().
 * @return string Markup SVG pronto da stampare.
 */
function fi_emergenze_icona($card) {
    $disegni = array(
        /* croce nel cerchio: pronto soccorso */
        'soccorso'   => '<circle cx="12" cy="12" r="9"/><path d="M12 8v8M8 12h8"/>',
        /* triangolo con il punto esclamativo: pericolo, intossicazioni */
        'pericolo'   => '<path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/>',
        /* edificio con la croce: ospedale */
        'ospedale'   => '<path d="M3 21h18"/><path d="M5 21V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v16"/><path d="M12 10v4"/><path d="M10 12h4"/>',
        /* calendario con la croce: il turno, cioe\' chi e\' aperto adesso */
        'calendario' => '<rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/><path d="M12 12v6"/><path d="M9 15h6"/>',
        /* linea del battito: il medico */
        'battito'    => '<path d="M22 12h-4l-3 9L9 3l-3 9H2"/>',
    );

    $scelta = isset($card['icon']) ? trim((string) $card['icon']) : '';

    if ('' === $scelta || !isset($disegni[$scelta])) {
        /* L'ORDINE CONTA: "Casi urgenti di intossicazione" va riconosciuto come
           intossicazione prima che come urgenza, e "Farmacia di turno" come
           turno prima che come medico. */
        $regole = array(
            'soccorso'   => array('ambulanza', 'soccorso'),
            'pericolo'   => array('intossicaz', 'avvelen', 'veleno'),
            'ospedale'   => array('ospedal', 'clinica'),
            'calendario' => array('turno', 'farmacia'),
            'battito'    => array('medico', 'urgenz', 'picchetto'),
        );

        $testo = strtolower(remove_accents((isset($card['title']) ? $card['title'] : '') . ' ' . (isset($card['note']) ? $card['note'] : '')));
        $scelta = 'soccorso';

        foreach ($regole as $nome => $parole) {
            foreach ($parole as $parola) {
                if (false !== strpos($testo, $parola)) {
                    $scelta = $nome;
                    break 2;
                }
            }
        }
    }

    return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" aria-hidden="true" focusable="false">'
        . $disegni[$scelta] . '</svg>';
}

/**
 * Normalizza dati principali nuovi e legacy.
 *
 * @param mixed $cards Dati opzione.
 * @return array
 */
function fi_emergenze_normalize_main_cards($cards) {
    if (!is_array($cards)) {
        return array();
    }

    $normalized = array();
    foreach ($cards as $card) {
        if (!is_array($card)) {
            continue;
        }

        $title  = sanitize_text_field($card['title'] ?? '');
        $phone  = fi_emergenze_sanitize_phone($card['phone'] ?? ($card['number'] ?? ''));
        $note   = sanitize_text_field($card['note'] ?? '');
        $active = array_key_exists('active', $card) ? !empty($card['active']) : true;

        if ('' === $title && '' === $phone) {
            continue;
        }

        $normalized[] = array('title' => $title, 'phone' => $phone, 'note' => $note, 'active' => $active ? 1 : 0);
    }

    return $normalized;
}

function fi_emergenze_sanitize_main_cards($input) {
    return fi_emergenze_normalize_main_cards(wp_unslash($input));
}

add_action('admin_init', 'fi_emergenze_register_settings');
/*
 * L'OPZIONE `fi_em_afterhours` NON SI REGISTRA PIU'.
 *
 * La sezione «Contatti fuori orario» e' stata tolta dalla pagina Emergenze e dal
 * pannello. Quel che era stato salvato resta nel database, non cancellato di
 * proposito: e' un elenco di numeri di picchetto per circolo, e buttarlo via
 * sarebbe irreversibile. Semplicemente nessuno lo legge piu'. Se un giorno la
 * sezione dovesse tornare, i dati sono ancora al loro posto.
 */
function fi_emergenze_register_settings() {
    register_setting('fi_emergenze_group', 'fi_em_main_cards', array('type' => 'array', 'sanitize_callback' => 'fi_emergenze_sanitize_main_cards'));
}

add_action('admin_menu', 'fi_emergenze_admin_menu');
function fi_emergenze_admin_menu() {
    add_menu_page(
        __('Numeri Emergenze', 'farmaciainternazionale-child-theme'),
        __('Numeri Emergenze', 'farmaciainternazionale-child-theme'),
        'manage_options',
        'fi-emergenze',
        'fi_emergenze_admin_page',
        'dashicons-phone',
        30
    );
}

add_action('admin_enqueue_scripts', 'fi_emergenze_admin_assets');
function fi_emergenze_admin_assets($hook) {
    if ('toplevel_page_fi-emergenze' !== $hook) {
        return;
    }

    wp_enqueue_style('fi-admin-emergenze', get_stylesheet_directory_uri() . '/assets/css/admin-emergenze.css', array(), wp_get_theme()->get('Version'));
    wp_enqueue_script('fi-admin-emergenze', get_stylesheet_directory_uri() . '/assets/js/admin-emergenze.js', array(), wp_get_theme()->get('Version'), true);
}

/**
 * Pagina amministrativa.
 */
function fi_emergenze_admin_page() {
    if (!current_user_can('manage_options')) {
        wp_die(esc_html__('Non sei autorizzato ad accedere a questa pagina.', 'farmaciainternazionale-child-theme'));
    }

    $stored_main  = get_option('fi_em_main_cards', null);
    $main_cards   = fi_emergenze_normalize_main_cards(null === $stored_main ? fi_emergenze_default_main_cards() : $stored_main);
    ?>
    <div class="wrap fi-em-admin">
        <header class="fi-em-admin-hero">
            <div class="fi-em-admin-title"><span class="dashicons dashicons-phone" aria-hidden="true"></span><div><h1><?php esc_html_e('Gestione Numeri Emergenze', 'farmaciainternazionale-child-theme'); ?></h1><p><?php esc_html_e('Configura i numeri mostrati nella pagina Emergenze.', 'farmaciainternazionale-child-theme'); ?></p></div></div>
            <div class="fi-em-admin-badges"><span><?php echo esc_html(sprintf(__('%d numeri principali', 'farmaciainternazionale-child-theme'), count($main_cards))); ?></span><span class="is-green"><span class="dashicons dashicons-admin-links" aria-hidden="true"></span><?php esc_html_e('Link telefonici automatici', 'farmaciainternazionale-child-theme'); ?></span></div>
        </header>

        <?php settings_errors(); ?>
        <?php if (isset($_GET['settings-updated']) && 'true' === sanitize_key(wp_unslash($_GET['settings-updated']))) : ?><div class="fi-em-saved" role="status"><span class="dashicons dashicons-yes-alt" aria-hidden="true"></span><?php esc_html_e('Impostazioni salvate correttamente.', 'farmaciainternazionale-child-theme'); ?></div><?php endif; ?>

        <div class="fi-em-admin-info"><span class="dashicons dashicons-info-outline" aria-hidden="true"></span><div><strong><?php esc_html_e('Nessun codice da inserire', 'farmaciainternazionale-child-theme'); ?></strong><p><?php esc_html_e('Scrivi solo i numeri di telefono: i link cliccabili vengono generati automaticamente sul sito. Non inserire codice HTML.', 'farmaciainternazionale-child-theme'); ?></p></div></div>

        <form method="post" action="options.php" id="fi_emergenze_form">
            <?php settings_fields('fi_emergenze_group'); ?>

            <section class="fi-em-admin-section">
                <div class="fi-em-section-heading"><div><h2><?php esc_html_e('Numeri principali', 'farmaciainternazionale-child-theme'); ?></h2><p><?php esc_html_e('Le chiamate più importanti mostrate come card nella parte alta della pagina.', 'farmaciainternazionale-child-theme'); ?></p></div><span class="fi-em-feature-badge"><?php esc_html_e('Numero cliccabile', 'farmaciainternazionale-child-theme'); ?></span></div>
                <div class="fi-em-main-list" id="fi_main_cards_body">
                    <?php foreach ($main_cards as $index => $card) : ?>
                        <article class="fi-em-main-item">
                            <div class="fi-em-item-top"><span class="fi-em-order-badge"><?php echo esc_html($index + 1); ?></span><strong class="fi-em-item-title"><?php echo esc_html($card['title'] ?: __('Nuovo numero', 'farmaciainternazionale-child-theme')); ?></strong><label class="fi-em-active-toggle"><input type="checkbox" data-field="active" name="fi_em_main_cards[<?php echo esc_attr($index); ?>][active]" value="1" <?php checked(1, $card['active']); ?>><span aria-hidden="true"></span><em><?php esc_html_e('Attivo', 'farmaciainternazionale-child-theme'); ?></em></label><button type="button" class="fi-em-icon-button fi-remove-main" aria-label="<?php esc_attr_e('Rimuovi numero principale', 'farmaciainternazionale-child-theme'); ?>"><span class="dashicons dashicons-trash" aria-hidden="true"></span></button></div>
                            <div class="fi-em-main-fields">
                                <div class="fi-em-field"><label><?php esc_html_e('Titolo', 'farmaciainternazionale-child-theme'); ?></label><input type="text" data-field="title" name="fi_em_main_cards[<?php echo esc_attr($index); ?>][title]" value="<?php echo esc_attr($card['title']); ?>" placeholder="Ambulanza e pronto soccorso"></div>
                                <div class="fi-em-field"><label><?php esc_html_e('Numero', 'farmaciainternazionale-child-theme'); ?></label><input type="text" class="fi-em-phone-input" data-field="phone" name="fi_em_main_cards[<?php echo esc_attr($index); ?>][phone]" value="<?php echo esc_attr($card['phone']); ?>" inputmode="tel" placeholder="+41 91 800 18 28"><small class="fi-em-tel-preview"><?php echo esc_html(__('Link generato:', 'farmaciainternazionale-child-theme') . ' tel:' . fi_normalize_phone_for_tel($card['phone'])); ?></small></div>
                                <div class="fi-em-field"><label><?php esc_html_e('Nota breve', 'farmaciainternazionale-child-theme'); ?> <span><?php esc_html_e('(opzionale)', 'farmaciainternazionale-child-theme'); ?></span></label><input type="text" data-field="note" name="fi_em_main_cards[<?php echo esc_attr($index); ?>][note]" value="<?php echo esc_attr($card['note']); ?>" placeholder="Disponibile 24 ore su 24"></div>
                            </div>
                        </article>
                    <?php endforeach; ?>
                </div>
                <button type="button" class="button fi-em-add-button" id="fi_add_card_row"><span class="dashicons dashicons-plus-alt2" aria-hidden="true"></span><?php esc_html_e('Aggiungi numero principale', 'farmaciainternazionale-child-theme'); ?></button>
            </section>

            <div class="fi-em-savebar"><div><strong><?php esc_html_e('Configurazione pronta?', 'farmaciainternazionale-child-theme'); ?></strong><span><?php esc_html_e('Salva per aggiornare immediatamente la pagina Emergenze.', 'farmaciainternazionale-child-theme'); ?></span></div><?php submit_button(__('Salva impostazioni', 'farmaciainternazionale-child-theme'), 'primary fi-em-save-button', 'submit', false); ?></div>
        </form>
    </div>
    <?php
}
