<?php
/**
 * Backend e form handler per il servizio Invio Ricette.
 *
 * I file vengono conservati solo nella directory temporanea di PHP per il
 * tempo necessario all'invio e non vengono aggiunti alla Media Library.
 *
 * @package Farmacia_Internazionale
 */

if (!defined('ABSPATH')) {
    exit;
}

define('FI_RICETTE_OPTION', 'fi_invio_ricette_settings');
define('FI_RICETTE_MAX_MB', 12);

/*
 * Quanti file si possono allegare per ciascun campo. Una ricetta sta spesso su
 * piu' fogli e la tessera ha fronte e retro, quindi uno non basta. Il tetto
 * serve a non ritrovarsi una mail con quaranta allegati.
 */
define('FI_RICETTE_MAX_FILE_PER_CAMPO', 5);

/*
 * Tetto al peso COMPLESSIVO degli allegati di un singolo invio. Il limite per
 * file da solo non basta: cinque file da 8 MB per due campi farebbero 80 MB, e
 * una mail cosi' non parte — SendGrid la rifiuta sopra i 30 MB e i server di
 * posta hanno soglie ancora piu' basse. Meglio dirlo alla persona subito che
 * far finire l'invio in un errore muto.
 */
define('FI_RICETTE_MAX_MB_TOTALE', 20);

/**
 * Restituisce le impostazioni complete del servizio.
 *
 * @return array
 */
function fi_ricette_get_settings() {
    $defaults = array(
        'enabled'         => 0,
        'recipient_email' => '',
        'page_title'      => 'Invia la tua ricetta',
        'intro_text'      => 'Carica la foto della tua ricetta e della tua cassa malati. La farmacia riceverà la richiesta e ti contatterà se necessario.',
        'privacy_text'    => 'Acconsento all\'invio dei dati e delle immagini caricate alla farmacia per la gestione della richiesta.',
        'success_message' => 'La tua richiesta è stata inviata correttamente. La farmacia prenderà in carico la ricetta e ti contatterà se necessario.',
        'error_message'   => 'Si è verificato un errore durante l\'invio. Riprova o contatta direttamente la farmacia.',
        'max_upload_mb'   => 8,
        'allowed_formats' => array('jpg', 'jpeg', 'png', 'pdf'),
    );

    $saved    = get_option(FI_RICETTE_OPTION, array());
    $settings = wp_parse_args(is_array($saved) ? $saved : array(), $defaults);

    foreach (array('page_title', 'intro_text', 'privacy_text', 'success_message', 'error_message') as $key) {
        if ('' === trim((string) $settings[$key])) {
            $settings[$key] = $defaults[$key];
        }
    }

    return $settings;
}

/**
 * Sanitizza le impostazioni e impedisce la sostituzione con una email errata.
 *
 * @param mixed $input Dati inviati dal form impostazioni.
 * @return array
 */
function fi_ricette_sanitize_settings($input) {
    $input    = is_array($input) ? $input : array();
    $current  = fi_ricette_get_settings();
    $email_in = isset($input['recipient_email']) ? trim(wp_unslash($input['recipient_email'])) : '';
    $email    = sanitize_email($email_in);

    if ('' !== $email_in && (!is_email($email_in) || $email !== $email_in)) {
        add_settings_error(
            FI_RICETTE_OPTION,
            'fi_ricette_invalid_email',
            __('L\'email HIN non è valida. Il valore precedente è stato mantenuto.', 'farmaciainternazionale-child-theme'),
            'error'
        );
        $email = $current['recipient_email'];
    }

    $allowed = array('jpg', 'jpeg', 'png', 'pdf');
    $formats = isset($input['allowed_formats']) ? (array) $input['allowed_formats'] : array();
    $formats = array_values(array_intersect($allowed, array_map('sanitize_key', $formats)));

    if (empty($formats)) {
        $formats = $allowed;
    }

    $max_mb = isset($input['max_upload_mb']) ? absint($input['max_upload_mb']) : 8;
    $max_mb = max(1, min(FI_RICETTE_MAX_MB, $max_mb));

    $enabled = empty($input['enabled']) ? 0 : 1;
    if ($enabled && empty($email)) {
        $enabled = 0;
        add_settings_error(
            FI_RICETTE_OPTION,
            'fi_ricette_email_required',
            __('Il servizio non è stato attivato perché manca una email HIN valida.', 'farmaciainternazionale-child-theme'),
            'error'
        );
    }

    return array(
        'enabled'         => $enabled,
        'recipient_email' => $email,
        'page_title'      => sanitize_text_field($input['page_title'] ?? ''),
        'intro_text'      => sanitize_textarea_field($input['intro_text'] ?? ''),
        'privacy_text'    => sanitize_textarea_field($input['privacy_text'] ?? ''),
        'success_message' => sanitize_textarea_field($input['success_message'] ?? ''),
        'error_message'   => sanitize_textarea_field($input['error_message'] ?? ''),
        'max_upload_mb'   => $max_mb,
        'allowed_formats' => $formats,
    );
}

add_action('admin_init', 'fi_ricette_register_settings');
function fi_ricette_register_settings() {
    register_setting(
        'fi_ricette_group',
        FI_RICETTE_OPTION,
        array(
            'type'              => 'array',
            'sanitize_callback' => 'fi_ricette_sanitize_settings',
            'default'           => fi_ricette_get_settings(),
        )
    );
}

add_action('admin_menu', 'fi_ricette_admin_menu');
function fi_ricette_admin_menu() {
    add_menu_page(
        __('Invio Ricette', 'farmaciainternazionale-child-theme'),
        __('Invio Ricette', 'farmaciainternazionale-child-theme'),
        'manage_options',
        'fi-invio-ricette',
        'fi_ricette_admin_page',
        'dashicons-media-document',
        31
    );
}

/**
 * Crea una volta la pagina pubblica e le assegna il template del child theme.
 */
add_action('admin_init', 'fi_ricette_maybe_create_page');
function fi_ricette_maybe_create_page() {
    if (!current_user_can('manage_options') || get_option('fi_ricette_page_provisioned')) {
        return;
    }

    $page = get_page_by_path('invio-ricette', OBJECT, 'page');

    if (!$page) {
        $page_id = wp_insert_post(
            array(
                'post_title'   => 'Invio Ricette',
                'post_name'    => 'invio-ricette',
                'post_status'  => 'publish',
                'post_type'    => 'page',
                'post_content' => '',
            ),
            true
        );
    } else {
        $page_id = $page->ID;
    }

    if (!is_wp_error($page_id)) {
        update_post_meta($page_id, '_wp_page_template', 'invio-ricette.php');
        update_option('fi_ricette_page_provisioned', absint($page_id), false);
    }
}

/**
 * Render della pagina impostazioni.
 */
function fi_ricette_admin_page() {
    if (!current_user_can('manage_options')) {
        wp_die(esc_html__('Non sei autorizzato ad accedere a questa pagina.', 'farmaciainternazionale-child-theme'));
    }

    $settings    = fi_ricette_get_settings();
    $option      = FI_RICETTE_OPTION;
    $is_https    = 'https' === wp_parse_url(home_url('/'), PHP_URL_SCHEME);
    $email_valid = is_email($settings['recipient_email']);
    $is_enabled  = !empty($settings['enabled']) && $email_valid;
    $page_id     = absint(get_option('fi_ricette_page_provisioned'));
    $page_url    = $page_id ? get_permalink($page_id) : home_url('/invio-ricette/');
    $formats     = implode(', ', array_map('strtoupper', $settings['allowed_formats']));
    ?>
    <div class="wrap fi-ricette-admin">
        <div class="fi-admin-hero">
            <div class="fi-admin-hero-copy">
                <span class="dashicons dashicons-media-document" aria-hidden="true"></span>
                <div>
                    <h1><?php esc_html_e('Invio Ricette', 'farmaciainternazionale-child-theme'); ?></h1>
                    <p><?php esc_html_e('Configura il servizio di ricezione sicura delle ricette inviate dai clienti.', 'farmaciainternazionale-child-theme'); ?></p>
                </div>
            </div>
            <div class="fi-admin-statuses" aria-label="<?php esc_attr_e('Stato configurazione', 'farmaciainternazionale-child-theme'); ?>">
                <span class="fi-status-badge <?php echo $is_enabled ? 'is-positive' : 'is-neutral'; ?>">
                    <i aria-hidden="true"></i><?php echo esc_html($is_enabled ? __('Servizio attivo', 'farmaciainternazionale-child-theme') : __('Servizio disattivo', 'farmaciainternazionale-child-theme')); ?>
                </span>
                <span class="fi-status-badge <?php echo $is_https ? 'is-positive' : 'is-critical'; ?>">
                    <i aria-hidden="true"></i><?php echo esc_html($is_https ? __('HTTPS attivo', 'farmaciainternazionale-child-theme') : __('HTTPS consigliato', 'farmaciainternazionale-child-theme')); ?>
                </span>
                <span class="fi-status-badge <?php echo $email_valid ? 'is-positive' : 'is-warning'; ?>">
                    <i aria-hidden="true"></i><?php echo esc_html($email_valid ? __('Email HIN configurata', 'farmaciainternazionale-child-theme') : __('Email HIN mancante', 'farmaciainternazionale-child-theme')); ?>
                </span>
            </div>
        </div>

        <?php settings_errors(FI_RICETTE_OPTION); ?>
        <?php if (isset($_GET['settings-updated']) && 'true' === sanitize_key(wp_unslash($_GET['settings-updated']))) : ?>
            <div class="fi-admin-saved" role="status"><span class="dashicons dashicons-yes-alt" aria-hidden="true"></span><?php esc_html_e('Impostazioni salvate correttamente.', 'farmaciainternazionale-child-theme'); ?></div>
        <?php endif; ?>

        <div class="fi-admin-alerts">
            <?php if (!$is_https) : ?>
                <div class="fi-admin-alert is-critical"><span class="dashicons dashicons-shield" aria-hidden="true"></span><div><strong><?php esc_html_e('Connessione HTTPS richiesta', 'farmaciainternazionale-child-theme'); ?></strong><p><?php esc_html_e('Per l’invio di dati sensibili è fortemente consigliato utilizzare HTTPS.', 'farmaciainternazionale-child-theme'); ?></p></div></div>
            <?php endif; ?>

            <?php if (!$email_valid) : ?>
                <div class="fi-admin-alert is-warning"><span class="dashicons dashicons-email-alt" aria-hidden="true"></span><div><strong><?php esc_html_e('Email HIN da configurare', 'farmaciainternazionale-child-theme'); ?></strong><p><?php esc_html_e('L’email HIN destinataria non è impostata. Inseriscila prima di attivare il servizio.', 'farmaciainternazionale-child-theme'); ?></p></div></div>
            <?php endif; ?>

            <div class="fi-admin-alert is-info"><span class="dashicons dashicons-privacy" aria-hidden="true"></span><div><strong><?php esc_html_e('Nessuna archiviazione', 'farmaciainternazionale-child-theme'); ?></strong><p><?php esc_html_e('Per sicurezza, gli invii e i documenti sanitari non vengono archiviati nel database WordPress.', 'farmaciainternazionale-child-theme'); ?></p></div></div>

            <?php if ((int) $settings['max_upload_mb'] > 8) : ?>
                <div class="fi-admin-alert is-warning"><span class="dashicons dashicons-warning" aria-hidden="true"></span><div><strong><?php esc_html_e('Upload superiore al valore consigliato', 'farmaciainternazionale-child-theme'); ?></strong><p><?php esc_html_e('Verifica i limiti del server di posta prima di consentire file superiori a 8 MB.', 'farmaciainternazionale-child-theme'); ?></p></div></div>
            <?php endif; ?>
        </div>

        <form action="options.php" method="post" class="fi-admin-form">
            <?php settings_fields('fi_ricette_group'); ?>

            <div class="fi-admin-grid">
                <div class="fi-admin-main">
                    <section class="fi-admin-card fi-service-card">
                        <div class="fi-card-heading"><span class="fi-card-icon"><span class="dashicons dashicons-controls-play" aria-hidden="true"></span></span><div><h2><?php esc_html_e('Stato servizio', 'farmaciainternazionale-child-theme'); ?></h2><p><?php esc_html_e('Controlla la disponibilità del form per i clienti.', 'farmaciainternazionale-child-theme'); ?></p></div></div>
                        <label class="fi-switch-row" for="fi-service-enabled">
                            <span><strong><?php esc_html_e('Attiva servizio Invio Ricette', 'farmaciainternazionale-child-theme'); ?></strong><small><?php esc_html_e('Quando attivo, i clienti possono inviare ricette dalla pagina dedicata.', 'farmaciainternazionale-child-theme'); ?></small></span>
                            <span class="fi-switch"><input id="fi-service-enabled" type="checkbox" name="<?php echo esc_attr($option); ?>[enabled]" value="1" <?php checked(1, $settings['enabled']); ?><?php if (!$email_valid) : ?> aria-describedby="fi-service-requirement"<?php endif; ?>><i aria-hidden="true"></i></span>
                        </label>
                        <?php if (!$email_valid) : ?><p id="fi-service-requirement" class="fi-inline-warning"><span class="dashicons dashicons-info-outline" aria-hidden="true"></span><?php esc_html_e('Imposta prima l’email HIN destinataria. Il controllo di salvataggio impedirà l’attivazione senza un indirizzo valido.', 'farmaciainternazionale-child-theme'); ?></p><?php endif; ?>
                    </section>

                    <section class="fi-admin-card">
                        <div class="fi-card-heading"><span class="fi-card-icon"><span class="dashicons dashicons-email-alt" aria-hidden="true"></span></span><div><h2><?php esc_html_e('Email HIN destinataria', 'farmaciainternazionale-child-theme'); ?></h2><p><?php esc_html_e('Destinazione protetta alla quale saranno inviati i documenti.', 'farmaciainternazionale-child-theme'); ?></p></div><span class="fi-field-state <?php echo $email_valid ? 'is-valid' : 'needs-setup'; ?>"><?php echo esc_html($email_valid ? __('Email valida', 'farmaciainternazionale-child-theme') : __('Da configurare', 'farmaciainternazionale-child-theme')); ?></span></div>
                        <div class="fi-field-group">
                            <label for="fi-recipient-email"><?php esc_html_e('Indirizzo email HIN', 'farmaciainternazionale-child-theme'); ?></label>
                            <input id="fi-recipient-email" type="email" name="<?php echo esc_attr($option); ?>[recipient_email]" value="<?php echo esc_attr($settings['recipient_email']); ?>" placeholder="farmacia@hin.ch" required>
                            <p><?php esc_html_e('Inserisci l’indirizzo HIN sicuro sul quale ricevere le ricette inviate dai clienti.', 'farmaciainternazionale-child-theme'); ?></p>
                        </div>
                    </section>

                    <section class="fi-admin-card">
                        <div class="fi-card-heading"><span class="fi-card-icon"><span class="dashicons dashicons-edit-page" aria-hidden="true"></span></span><div><h2><?php esc_html_e('Testi visualizzati nella pagina', 'farmaciainternazionale-child-theme'); ?></h2><p><?php esc_html_e('Personalizza le informazioni e i messaggi mostrati nel frontend.', 'farmaciainternazionale-child-theme'); ?></p></div></div>
                        <div class="fi-fields-grid">
                            <div class="fi-field-group is-full"><label for="fi-page-title"><?php esc_html_e('Titolo pagina', 'farmaciainternazionale-child-theme'); ?></label><input id="fi-page-title" type="text" name="<?php echo esc_attr($option); ?>[page_title]" value="<?php echo esc_attr($settings['page_title']); ?>"><p><?php esc_html_e('Titolo principale visibile nella hero della pagina.', 'farmaciainternazionale-child-theme'); ?></p></div>
                            <div class="fi-field-group is-full"><label for="fi-intro"><?php esc_html_e('Testo introduttivo', 'farmaciainternazionale-child-theme'); ?></label><textarea id="fi-intro" rows="3" name="<?php echo esc_attr($option); ?>[intro_text]"><?php echo esc_textarea($settings['intro_text']); ?></textarea><p><?php esc_html_e('Breve spiegazione mostrata sotto il titolo.', 'farmaciainternazionale-child-theme'); ?></p></div>
                            <div class="fi-field-group"><label for="fi-success"><?php esc_html_e('Messaggio di conferma', 'farmaciainternazionale-child-theme'); ?></label><textarea id="fi-success" rows="3" name="<?php echo esc_attr($option); ?>[success_message]"><?php echo esc_textarea($settings['success_message']); ?></textarea><p><?php esc_html_e('Mostrato dopo un invio riuscito.', 'farmaciainternazionale-child-theme'); ?></p></div>
                            <div class="fi-field-group"><label for="fi-error"><?php esc_html_e('Messaggio di errore', 'farmaciainternazionale-child-theme'); ?></label><textarea id="fi-error" rows="3" name="<?php echo esc_attr($option); ?>[error_message]"><?php echo esc_textarea($settings['error_message']); ?></textarea><p><?php esc_html_e('Messaggio generico, senza dettagli tecnici.', 'farmaciainternazionale-child-theme'); ?></p></div>
                        </div>
                    </section>

                    <section class="fi-admin-card fi-privacy-card">
                        <div class="fi-card-heading"><span class="fi-card-icon"><span class="dashicons dashicons-lock" aria-hidden="true"></span></span><div><h2><?php esc_html_e('Privacy e consenso', 'farmaciainternazionale-child-theme'); ?></h2><p><?php esc_html_e('Definisci il consenso richiesto prima dell’invio.', 'farmaciainternazionale-child-theme'); ?></p></div><span class="fi-required-badge"><?php esc_html_e('Obbligatorio', 'farmaciainternazionale-child-theme'); ?></span></div>
                        <div class="fi-field-group"><label for="fi-privacy"><?php esc_html_e('Testo del consenso', 'farmaciainternazionale-child-theme'); ?></label><textarea id="fi-privacy" rows="3" name="<?php echo esc_attr($option); ?>[privacy_text]"><?php echo esc_textarea($settings['privacy_text']); ?></textarea><p><?php esc_html_e('Questo testo viene mostrato accanto alla checkbox obbligatoria nel form frontend.', 'farmaciainternazionale-child-theme'); ?></p></div>
                        <div class="fi-privacy-note"><span class="dashicons dashicons-yes-alt" aria-hidden="true"></span><?php esc_html_e('Il cliente non potrà inviare la ricetta senza accettare il consenso.', 'farmaciainternazionale-child-theme'); ?></div>
                    </section>
                </div>

                <aside class="fi-admin-sidebar">
                    <section class="fi-admin-card fi-security-card">
                        <div class="fi-card-heading is-compact"><span class="fi-card-icon"><span class="dashicons dashicons-shield-alt" aria-hidden="true"></span></span><div><h2><?php esc_html_e('Stato sicurezza', 'farmaciainternazionale-child-theme'); ?></h2></div></div>
                        <ul class="fi-security-list">
                            <li><span class="dashicons <?php echo $is_https ? 'dashicons-yes-alt is-ok' : 'dashicons-warning is-alert'; ?>" aria-hidden="true"></span><span><strong>HTTPS</strong><small><?php echo esc_html($is_https ? __('Connessione protetta attiva', 'farmaciainternazionale-child-theme') : __('Connessione da proteggere', 'farmaciainternazionale-child-theme')); ?></small></span></li>
                            <li><span class="dashicons <?php echo $email_valid ? 'dashicons-yes-alt is-ok' : 'dashicons-warning is-alert'; ?>" aria-hidden="true"></span><span><strong><?php esc_html_e('Destinazione HIN', 'farmaciainternazionale-child-theme'); ?></strong><small><?php echo esc_html($email_valid ? __('Indirizzo configurato', 'farmaciainternazionale-child-theme') : __('Indirizzo mancante', 'farmaciainternazionale-child-theme')); ?></small></span></li>
                            <li><span class="dashicons dashicons-yes-alt is-ok" aria-hidden="true"></span><span><strong><?php esc_html_e('Dati minimizzati', 'farmaciainternazionale-child-theme'); ?></strong><small><?php esc_html_e('Nessun archivio degli invii', 'farmaciainternazionale-child-theme'); ?></small></span></li>
                        </ul>
                    </section>

                    <section class="fi-admin-card">
                        <div class="fi-card-heading is-compact"><span class="fi-card-icon"><span class="dashicons dashicons-upload" aria-hidden="true"></span></span><div><h2><?php esc_html_e('Upload e sicurezza', 'farmaciainternazionale-child-theme'); ?></h2></div></div>
                        <div class="fi-size-control"><label for="fi-max-upload"><?php esc_html_e('Dimensione massima per file', 'farmaciainternazionale-child-theme'); ?></label><div><input id="fi-max-upload" type="number" min="1" max="<?php echo esc_attr(FI_RICETTE_MAX_MB); ?>" name="<?php echo esc_attr($option); ?>[max_upload_mb]" value="<?php echo esc_attr($settings['max_upload_mb']); ?>"><span>MB</span></div><p><?php printf(esc_html__('Consigliato 8 MB, massimo %d MB.', 'farmaciainternazionale-child-theme'), FI_RICETTE_MAX_MB); ?></p></div>
                        <fieldset class="fi-admin-formats"><legend><?php esc_html_e('Formati permessi', 'farmaciainternazionale-child-theme'); ?></legend><div class="fi-format-grid"><?php foreach (array('jpg', 'jpeg', 'png', 'pdf') as $format) : ?><label><input type="checkbox" name="<?php echo esc_attr($option); ?>[allowed_formats][]" value="<?php echo esc_attr($format); ?>" <?php checked(in_array($format, $settings['allowed_formats'], true)); ?>><span><?php echo esc_html(strtoupper($format)); ?></span></label><?php endforeach; ?></div></fieldset>
                        <div class="fi-file-lifecycle"><span class="dashicons dashicons-trash" aria-hidden="true"></span><div><strong><?php esc_html_e('File temporanei cancellati', 'farmaciainternazionale-child-theme'); ?></strong><p><?php esc_html_e('Gli allegati vengono rimossi dal server subito dopo ogni tentativo di invio.', 'farmaciainternazionale-child-theme'); ?></p></div></div>
                    </section>

                    <section class="fi-admin-card fi-summary-card">
                        <h2><?php esc_html_e('Riepilogo', 'farmaciainternazionale-child-theme'); ?></h2>
                        <dl><div><dt><?php esc_html_e('Servizio', 'farmaciainternazionale-child-theme'); ?></dt><dd class="<?php echo $is_enabled ? 'is-ok' : ''; ?>"><?php echo esc_html($is_enabled ? __('Attivo', 'farmaciainternazionale-child-theme') : __('Disattivo', 'farmaciainternazionale-child-theme')); ?></dd></div><div><dt><?php esc_html_e('Email HIN', 'farmaciainternazionale-child-theme'); ?></dt><dd class="<?php echo $email_valid ? 'is-ok' : ''; ?>"><?php echo esc_html($email_valid ? __('Configurata', 'farmaciainternazionale-child-theme') : __('Mancante', 'farmaciainternazionale-child-theme')); ?></dd></div><div><dt>HTTPS</dt><dd class="<?php echo $is_https ? 'is-ok' : ''; ?>"><?php echo esc_html($is_https ? __('Attivo', 'farmaciainternazionale-child-theme') : __('Non attivo', 'farmaciainternazionale-child-theme')); ?></dd></div><div><dt><?php esc_html_e('Max upload', 'farmaciainternazionale-child-theme'); ?></dt><dd><?php echo esc_html($settings['max_upload_mb'] . ' MB'); ?></dd></div><div><dt><?php esc_html_e('Formati', 'farmaciainternazionale-child-theme'); ?></dt><dd><?php echo esc_html($formats); ?></dd></div></dl>
                        <?php submit_button(__('Salva impostazioni', 'farmaciainternazionale-child-theme'), 'primary fi-save-button', 'submit', false); ?>
                        <?php if ($page_url) : ?><a class="fi-preview-link" href="<?php echo esc_url($page_url); ?>" target="_blank" rel="noopener noreferrer"><span class="dashicons dashicons-external" aria-hidden="true"></span><?php esc_html_e('Visualizza pagina Invio Ricette', 'farmaciainternazionale-child-theme'); ?></a><?php endif; ?>
                    </section>
                </aside>
            </div>
        </form>
    </div>
    <style>
        .fi-ricette-admin { --fi-admin-green: #035d29; --fi-admin-green-soft: #edf6f0; --fi-admin-border: #dfe7e1; width: auto; max-width: none; margin: 24px 20px 40px 2px; color: #25332a; }
        .fi-admin-hero { display: flex; justify-content: space-between; gap: 28px; align-items: center; padding: 26px 30px; border: 1px solid var(--fi-admin-border); border-radius: 16px; background: linear-gradient(135deg, #fff 50%, #f1f7f3); box-shadow: 0 8px 30px rgba(3,93,41,.06); }
        .fi-admin-hero-copy { display: flex; gap: 17px; align-items: center; }
        .fi-admin-hero-copy > .dashicons { display: grid; width: 50px; height: 50px; place-items: center; border-radius: 14px; background: var(--fi-admin-green); color: #fff; font-size: 26px; }
        .fi-admin-hero h1 { margin: 0 0 5px; padding: 0; color: #173b25; font-size: 25px; line-height: 1.2; }
        .fi-admin-hero p { margin: 0; color: #607067; font-size: 14px; }
        .fi-admin-statuses { display: flex; flex-wrap: wrap; justify-content: flex-end; gap: 8px; }
        .fi-status-badge { display: inline-flex; align-items: center; gap: 7px; padding: 7px 11px; border: 1px solid #d9e2dc; border-radius: 999px; background: #fff; color: #59665e; font-size: 12px; font-weight: 650; white-space: nowrap; }
        .fi-status-badge i { width: 7px; height: 7px; border-radius: 50%; background: #8c9690; }
        .fi-status-badge.is-positive { border-color: #b9ddc5; background: #eff9f2; color: #176532; } .fi-status-badge.is-positive i { background: #23a455; }
        .fi-status-badge.is-warning { border-color: #f0d696; background: #fff9e8; color: #805d05; } .fi-status-badge.is-warning i { background: #dba617; }
        .fi-status-badge.is-critical { border-color: #efc1be; background: #fff3f2; color: #962d26; } .fi-status-badge.is-critical i { background: #d63638; }
        .fi-ricette-admin > .notice { max-width: 850px; margin: 16px 0 0; border: 0; border-radius: 10px; box-shadow: 0 4px 14px rgba(0,0,0,.05); }
        .fi-admin-saved { display: flex; width: fit-content; gap: 8px; align-items: center; margin: 16px 0 0; padding: 11px 15px; border: 1px solid #b9ddc5; border-radius: 10px; background: #eff9f2; color: #176532; font-size: 13px; font-weight: 650; box-shadow: 0 4px 14px rgba(3,93,41,.05); }
        .fi-admin-alerts { display: grid; grid-template-columns: repeat(2, minmax(0,1fr)); gap: 10px; margin: 16px 0 22px; }
        .fi-admin-alert { display: flex; gap: 12px; align-items: flex-start; padding: 13px 15px; border: 1px solid; border-radius: 11px; background: #fff; }
        .fi-admin-alert > .dashicons { flex: 0 0 22px; margin-top: 1px; } .fi-admin-alert strong { display: block; margin-bottom: 2px; font-size: 13px; } .fi-admin-alert p { margin: 0; font-size: 12px; line-height: 1.45; }
        .fi-admin-alert.is-info { border-color: #cbddec; background: #f4f9fd; color: #315b78; } .fi-admin-alert.is-warning { border-color: #efd99e; background: #fffaf0; color: #735a17; } .fi-admin-alert.is-critical { border-color: #edc2bf; background: #fff5f4; color: #8d302a; }
        .fi-admin-grid { display: grid; grid-template-columns: minmax(0,2fr) minmax(350px,.72fr); gap: 20px; align-items: start; }
        .fi-admin-main, .fi-admin-sidebar { display: grid; gap: 18px; min-width: 0; }
        .fi-admin-sidebar { position: sticky; top: 42px; }
        .fi-admin-card { padding: 23px; border: 1px solid var(--fi-admin-border); border-radius: 14px; background: #fff; box-shadow: 0 5px 20px rgba(3,93,41,.045); }
        .fi-card-heading { display: flex; gap: 13px; align-items: flex-start; margin-bottom: 21px; } .fi-card-heading.is-compact { margin-bottom: 16px; align-items: center; }
        .fi-card-icon { display: grid; flex: 0 0 38px; width: 38px; height: 38px; place-items: center; border-radius: 10px; background: var(--fi-admin-green-soft); color: var(--fi-admin-green); }
        .fi-card-icon .dashicons { width: auto; height: auto; font-size: 20px; }
        .fi-card-heading h2, .fi-summary-card h2 { margin: 1px 0 4px; color: #173b25; font-size: 16px; line-height: 1.3; }
        .fi-card-heading p { margin: 0; color: #718078; font-size: 12.5px; line-height: 1.45; }
        .fi-field-state, .fi-required-badge { margin-left: auto; padding: 5px 9px; border-radius: 999px; font-size: 11px; font-weight: 700; white-space: nowrap; }
        .fi-field-state.is-valid { background: #eaf7ee; color: #177039; } .fi-field-state.needs-setup { background: #fff5df; color: #85610a; } .fi-required-badge { background: #f3ecec; color: #873d3d; }
        .fi-switch-row { display: flex; justify-content: space-between; gap: 24px; align-items: center; padding: 16px 17px; border: 1px solid #e4ebe6; border-radius: 11px; background: #fafcfb; cursor: pointer; }
        .fi-switch-row strong, .fi-switch-row small { display: block; } .fi-switch-row strong { margin-bottom: 4px; color: #263d2e; font-size: 14px; } .fi-switch-row small { color: #718078; font-size: 12px; }
        .fi-switch { position: relative; flex: 0 0 46px; width: 46px; height: 25px; } .fi-switch input { position: absolute; opacity: 0; pointer-events: none; }
        .fi-switch i { position: absolute; inset: 0; border-radius: 999px; background: #b9c1bc; transition: .2s ease; } .fi-switch i:after { content: ""; position: absolute; top: 3px; left: 3px; width: 19px; height: 19px; border-radius: 50%; background: #fff; box-shadow: 0 2px 5px rgba(0,0,0,.22); transition: .2s ease; }
        .fi-switch input:checked + i { background: var(--fi-admin-green); } .fi-switch input:checked + i:after { transform: translateX(21px); } .fi-switch input:focus-visible + i { box-shadow: 0 0 0 3px rgba(3,93,41,.18); }
        .fi-inline-warning { display: flex; gap: 6px; align-items: center; margin: 10px 2px 0; color: #8a6200; font-size: 12px; }
        .fi-field-group label, .fi-size-control > label, .fi-admin-formats legend { display: block; margin-bottom: 7px; color: #2c3c31; font-size: 12.5px; font-weight: 650; }
        .fi-field-group input[type="text"], .fi-field-group input[type="email"], .fi-field-group textarea { width: 100%; max-width: none; margin: 0; padding: 9px 11px; border-color: #ccd8d0; border-radius: 8px; box-shadow: none; font-size: 13px; line-height: 1.5; box-sizing: border-box; }
        .fi-field-group input { min-height: 39px; } .fi-field-group textarea { min-height: 74px; resize: vertical; }
        .fi-field-group input:focus, .fi-field-group textarea:focus, .fi-size-control input:focus { border-color: var(--fi-admin-green); box-shadow: 0 0 0 2px rgba(3,93,41,.1); }
        .fi-field-group > p, .fi-size-control > p { margin: 6px 1px 0; color: #7a8780; font-size: 11.5px; line-height: 1.4; }
        .fi-fields-grid { display: grid; grid-template-columns: repeat(2,minmax(0,1fr)); gap: 18px; } .fi-fields-grid .is-full { grid-column: 1 / -1; }
        .fi-privacy-card { border-color: #cadfd1; } .fi-privacy-note { display: flex; gap: 8px; align-items: center; margin-top: 14px; padding: 11px 13px; border-radius: 8px; background: var(--fi-admin-green-soft); color: #2b6540; font-size: 12px; font-weight: 600; }
        .fi-security-list { display: grid; gap: 12px; margin: 0; } .fi-security-list li { display: flex; gap: 10px; align-items: center; margin: 0; } .fi-security-list .dashicons { flex: 0 0 20px; } .fi-security-list .is-ok { color: #219653; } .fi-security-list .is-alert { color: #d49b0c; }
        .fi-security-list strong, .fi-security-list small { display: block; } .fi-security-list strong { color: #34463a; font-size: 12.5px; } .fi-security-list small { margin-top: 1px; color: #7b8880; font-size: 11px; }
        .fi-size-control > div { display: flex; max-width: 150px; } .fi-size-control input { width: 92px; min-height: 40px; margin: 0; border: 1px solid #ccd8d0; border-radius: 8px 0 0 8px; box-shadow: none; }
        .fi-size-control > div span { display: grid; padding: 0 12px; place-items: center; border: 1px solid #ccd8d0; border-left: 0; border-radius: 0 8px 8px 0; background: #f3f6f4; color: #526158; font-weight: 700; }
        .fi-admin-formats { margin: 20px 0 0; padding: 0; border: 0; } .fi-format-grid { display: grid; grid-template-columns: repeat(2,minmax(0,1fr)); gap: 8px; }
        .fi-format-grid label { position: relative; cursor: pointer; } .fi-format-grid input { position: absolute; opacity: 0; } .fi-format-grid span { display: block; padding: 9px 6px; border: 1px solid #d7e0da; border-radius: 8px; background: #fafcfb; color: #627068; font-size: 11px; font-weight: 750; text-align: center; transition: .15s ease; }
        .fi-format-grid input:checked + span { border-color: #70a983; background: var(--fi-admin-green-soft); color: var(--fi-admin-green); box-shadow: inset 0 0 0 1px #70a983; } .fi-format-grid input:focus-visible + span { box-shadow: 0 0 0 3px rgba(3,93,41,.15); }
        .fi-file-lifecycle { display: flex; gap: 10px; margin-top: 18px; padding: 12px; border-radius: 9px; background: #f3f8f4; color: #326542; } .fi-file-lifecycle > .dashicons { flex: 0 0 20px; } .fi-file-lifecycle strong { display: block; font-size: 12px; } .fi-file-lifecycle p { margin: 3px 0 0; color: #63766a; font-size: 11px; line-height: 1.4; }
        .fi-summary-card dl { margin: 14px 0 20px; } .fi-summary-card dl > div { display: flex; justify-content: space-between; gap: 15px; padding: 9px 0; border-bottom: 1px solid #edf0ee; } .fi-summary-card dt { color: #718078; font-size: 12px; } .fi-summary-card dd { margin: 0; color: #3d4c42; font-size: 12px; font-weight: 650; text-align: right; } .fi-summary-card dd.is-ok { color: #167139; }
        .fi-ricette-admin .fi-save-button { width: 100%; min-height: 42px; margin: 0; border-color: var(--fi-admin-green); border-radius: 8px; background: var(--fi-admin-green); font-weight: 650; box-shadow: 0 5px 14px rgba(3,93,41,.18); } .fi-ricette-admin .fi-save-button:hover, .fi-ricette-admin .fi-save-button:focus { border-color: #02471f; background: #02471f; }
        .fi-preview-link { display: flex; justify-content: center; gap: 6px; align-items: center; margin-top: 13px; color: var(--fi-admin-green); font-size: 12px; font-weight: 600; text-decoration: none; } .fi-preview-link:hover { color: #02471f; text-decoration: underline; } .fi-preview-link .dashicons { font-size: 16px; }
        @media (max-width: 1050px) { .fi-admin-grid { grid-template-columns: 1fr; } .fi-admin-sidebar { position: static; grid-template-columns: repeat(2,minmax(0,1fr)); } .fi-summary-card { grid-column: 1 / -1; } }
        @media (max-width: 782px) { .fi-ricette-admin { margin-right: 12px; } .fi-admin-hero { align-items: flex-start; padding: 21px; } .fi-admin-hero, .fi-admin-hero-copy { flex-direction: column; } .fi-admin-statuses { justify-content: flex-start; } .fi-admin-alerts, .fi-admin-sidebar, .fi-fields-grid { grid-template-columns: 1fr; } .fi-fields-grid .is-full, .fi-summary-card { grid-column: auto; } .fi-admin-card { padding: 19px; } .fi-switch-row { align-items: flex-start; } .fi-field-state, .fi-required-badge { align-self: flex-start; } }
        @media (max-width: 480px) { .fi-admin-hero { padding: 18px; } .fi-admin-statuses { display: grid; width: 100%; } .fi-status-badge { justify-content: flex-start; } .fi-card-heading { flex-wrap: wrap; } .fi-field-state, .fi-required-badge { margin-left: 51px; } .fi-switch-row { gap: 12px; padding: 14px; } .fi-format-grid { grid-template-columns: 1fr 1fr; } }
    </style>
    <?php
}

/**
 * Restituisce la whitelist MIME in base alla configurazione.
 *
 * @param array $formats Estensioni abilitate.
 * @return array
 */
function fi_ricette_allowed_mimes($formats) {
    $available = array(
        'jpg'  => 'image/jpeg',
        'jpeg' => 'image/jpeg',
        'png'  => 'image/png',
        'pdf'  => 'application/pdf',
    );

    return array_intersect_key($available, array_flip((array) $formats));
}

/**
 * Riporta un campo di $_FILES a un semplice elenco di file.
 *
 * Con `name="fi_prescription[]"` PHP non consegna un file per volta: consegna
 * un array PARALLELO per ogni chiave — name, type, tmp_name, error, size —
 * dove l'indice lega fra loro i pezzi dello stesso file. Qui quella struttura
 * scomoda torna a essere quello che serve: un elenco di file, ognuno completo.
 *
 * Accetta anche la forma a file singolo, cosi' se un domani si togliesse
 * `multiple` dal markup il codice continua a funzionare.
 *
 * @param string $campo Nome del campo in $_FILES.
 * @return array Elenco di array in forma $_FILES a file singolo.
 */
function fi_ricette_elenco_file($campo) {
    if (!isset($_FILES[$campo]) || !is_array($_FILES[$campo])) {
        return array();
    }

    $grezzo = $_FILES[$campo]; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
    if (!isset($grezzo['name'])) {
        return array();
    }

    /* Forma a file singolo: si restituisce cosi' com'e'. */
    if (!is_array($grezzo['name'])) {
        return array($grezzo);
    }

    $elenco = array();
    foreach (array_keys($grezzo['name']) as $i) {
        /*
         * Un campo `multiple` lasciato vuoto arriva con una riga fantasma:
         * nome vuoto ed errore UPLOAD_ERR_NO_FILE. Non e' un file mancante da
         * segnalare, e' semplicemente nulla, e va scartata in silenzio.
         */
        if ('' === (string) $grezzo['name'][$i] && UPLOAD_ERR_NO_FILE === (int) $grezzo['error'][$i]) {
            continue;
        }

        $elenco[] = array(
            'name'     => $grezzo['name'][$i],
            'type'     => isset($grezzo['type'][$i]) ? $grezzo['type'][$i] : '',
            'tmp_name' => isset($grezzo['tmp_name'][$i]) ? $grezzo['tmp_name'][$i] : '',
            'error'    => isset($grezzo['error'][$i]) ? $grezzo['error'][$i] : UPLOAD_ERR_NO_FILE,
            'size'     => isset($grezzo['size'][$i]) ? $grezzo['size'][$i] : 0,
        );
    }

    return $elenco;
}

/**
 * Valida e sposta un upload nella directory temporanea di sistema.
 *
 * @param array $file       Elemento di $_FILES.
 * @param int   $max_bytes  Dimensione massima.
 * @param array $mimes      MIME consentiti per estensione.
 * @return string|WP_Error Percorso temporaneo o errore generico.
 */
function fi_ricette_prepare_upload($file, $max_bytes, $mimes) {
    if (!is_array($file) || !isset($file['error'], $file['tmp_name'], $file['name'], $file['size'])) {
        return new WP_Error('invalid_upload');
    }

    if (UPLOAD_ERR_OK !== (int) $file['error'] || !is_uploaded_file($file['tmp_name'])) {
        return new WP_Error('upload_failed');
    }

    if ((int) $file['size'] < 1 || (int) $file['size'] > $max_bytes) {
        return new WP_Error('invalid_size');
    }

    $original_name = sanitize_file_name(wp_basename($file['name']));
    $extension     = strtolower(pathinfo($original_name, PATHINFO_EXTENSION));

    if (!isset($mimes[$extension])) {
        return new WP_Error('invalid_extension');
    }

    $checked = wp_check_filetype_and_ext($file['tmp_name'], $original_name, $mimes);
    $real_mime = '';

    if (function_exists('finfo_open')) {
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        if ($finfo) {
            $real_mime = (string) finfo_file($finfo, $file['tmp_name']);
            finfo_close($finfo);
        }
    }

    if (empty($checked['ext']) || empty($checked['type']) || $checked['type'] !== $mimes[$extension]) {
        return new WP_Error('invalid_filetype');
    }

    if ('' !== $real_mime && $real_mime !== $mimes[$extension]) {
        return new WP_Error('invalid_mime');
    }

    $temp_dir = get_temp_dir();
    if (!$temp_dir || !is_dir($temp_dir) || !is_writable($temp_dir)) {
        return new WP_Error('temp_unavailable');
    }

    $random_name = 'fi-rx-' . wp_generate_uuid4() . '.' . $extension;
    $destination = trailingslashit($temp_dir) . $random_name;

    if (!move_uploaded_file($file['tmp_name'], $destination)) {
        return new WP_Error('move_failed');
    }

    @chmod($destination, 0600);
    return $destination;
}

/**
 * Identificatore rate limit non reversibile; nessun IP viene memorizzato.
 *
 * @return string
 */
function fi_ricette_rate_key() {
    $ip = isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR'])) : 'unknown';
    return 'fi_rx_rate_' . hash_hmac('sha256', $ip, wp_salt('nonce'));
}

/**
 * Registra soltanto errori tecnici non sensibili quando il debug log è attivo.
 *
 * @param string $code Codice interno privo di dati cliente.
 */
function fi_ricette_log_error($code) {
    if (defined('WP_DEBUG_LOG') && WP_DEBUG_LOG) {
        error_log('Invio Ricette: ' . sanitize_key($code));
    }
}

/**
 * Invia tramite il trasporto ticinoWEB configurato, preservando gli allegati.
 *
 * Il parent theme intercetta SendGrid ma non trasferisce gli attachments di
 * wp_mail. Per quel solo metodo viene quindi usata la stessa API con payload
 * completo; SMTP e mail() continuano a passare dalla API WordPress.
 *
 * @param string $to          Destinatario.
 * @param string $subject     Oggetto.
 * @param string $message     Corpo plain text.
 * @param array  $attachments Percorsi temporanei.
 * @return bool
 */
function fi_ricette_send_mail($to, $subject, $message, $attachments) {
    if ('sendgrid' !== get_option('ticinoweb_email_method', 'default')) {
        return wp_mail(
            $to,
            $subject,
            $message,
            array('Content-Type: text/plain; charset=UTF-8'),
            $attachments
        );
    }

    $api_key    = trim((string) get_option('ticinoweb_sendgrid_api_key'));
    $from_email = sanitize_email(get_option('ticinoweb_sendgrid_from_email'));
    $from_name  = sanitize_text_field(get_option('ticinoweb_sendgrid_from_name', get_bloginfo('name')));

    if (empty($api_key) || !is_email($from_email)) {
        return false;
    }

    $names       = array('ricetta', 'cassa-malati');
    $sg_files    = array();
    foreach ($attachments as $index => $path) {
        if (!is_readable($path)) {
            return false;
        }

        $contents = file_get_contents($path);
        if (false === $contents) {
            return false;
        }

        $filetype   = wp_check_filetype($path);
        $extension  = !empty($filetype['ext']) ? $filetype['ext'] : 'dat';
        $sg_files[] = array(
            'content'     => base64_encode($contents),
            'type'        => !empty($filetype['type']) ? $filetype['type'] : 'application/octet-stream',
            'filename'    => ($names[$index] ?? 'documento') . '.' . $extension,
            'disposition' => 'attachment',
        );
    }

    $payload = array(
        'personalizations' => array(array('to' => array(array('email' => $to)))),
        'from'             => array('email' => $from_email, 'name' => $from_name),
        'subject'          => $subject,
        'content'          => array(array('type' => 'text/plain', 'value' => $message)),
        'attachments'      => $sg_files,
    );

    $response = wp_remote_post(
        'https://api.sendgrid.com/v3/mail/send',
        array(
            'headers' => array(
                'Authorization' => 'Bearer ' . $api_key,
                'Content-Type'  => 'application/json',
            ),
            'body'    => wp_json_encode($payload),
            'timeout' => 30,
        )
    );

    return !is_wp_error($response) && 202 === wp_remote_retrieve_response_code($response);
}

/**
 * Redirect PRG verso la pagina di provenienza.
 *
 * @param string $status Stato pubblico generico.
 */
function fi_ricette_redirect($status) {
    $fallback = home_url('/invio-ricette/');
    $referer  = wp_get_referer();
    $target   = $referer ? remove_query_arg('fi_ricette_status', $referer) : $fallback;
    wp_safe_redirect(add_query_arg('fi_ricette_status', sanitize_key($status), $target) . '#fi-invio-ricette-form');
    exit;
}

add_action('admin_post_nopriv_fi_submit_ricetta', 'fi_ricette_handle_submission');
add_action('admin_post_fi_submit_ricetta', 'fi_ricette_handle_submission');
function fi_ricette_handle_submission() {
    $temp_files = array();

    if ('POST' !== strtoupper($_SERVER['REQUEST_METHOD'] ?? '')) {
        fi_ricette_redirect('error');
    }

    $settings = fi_ricette_get_settings();
    if (empty($settings['enabled']) || !is_email($settings['recipient_email'])) {
        fi_ricette_redirect('unavailable');
    }

    $nonce = isset($_POST['fi_ricette_nonce']) ? sanitize_text_field(wp_unslash($_POST['fi_ricette_nonce'])) : '';
    if (!wp_verify_nonce($nonce, 'fi_submit_ricetta')) {
        fi_ricette_log_error('nonce_failed');
        fi_ricette_redirect('error');
    }

    if (!empty($_POST['fi_company_website'])) {
        fi_ricette_log_error('honeypot');
        fi_ricette_redirect('success');
    }

    $rate_key = fi_ricette_rate_key();
    $attempts = (int) get_transient($rate_key);
    if ($attempts >= 3) {
        fi_ricette_log_error('rate_limited');
        fi_ricette_redirect('error');
    }
    set_transient($rate_key, $attempts + 1, 15 * MINUTE_IN_SECONDS);

    $phone   = isset($_POST['fi_phone']) ? sanitize_text_field(wp_unslash($_POST['fi_phone'])) : '';
    $privacy = !empty($_POST['fi_privacy']);

    if (!$privacy || !preg_match('/^[0-9+().\x{00A0}\s\-]{7,30}$/u', $phone)) {
        fi_ricette_redirect('error');
    }

    $status = 'error';

    try {
        $server_limit = wp_max_upload_size();
        $max_bytes    = min((int) $settings['max_upload_mb'] * MB_IN_BYTES, $server_limit);
        $mimes        = fi_ricette_allowed_mimes($settings['allowed_formats']);

        $totale_bytes = 0;
        $conteggio    = array();

        foreach (array('fi_prescription' => __('ricetta', 'farmaciainternazionale-child-theme'), 'fi_insurance_card' => __('cassa malati', 'farmaciainternazionale-child-theme')) as $field => $etichetta) {
            $elenco = fi_ricette_elenco_file($field);

            /* Almeno un file per campo: entrambi restano obbligatori. */
            if (empty($elenco)) {
                throw new RuntimeException('missing_file');
            }

            if (count($elenco) > FI_RICETTE_MAX_FILE_PER_CAMPO) {
                throw new RuntimeException('too_many_files');
            }

            foreach ($elenco as $file) {
                $path = fi_ricette_prepare_upload($file, $max_bytes, $mimes);

                if (is_wp_error($path)) {
                    throw new RuntimeException($path->get_error_code());
                }

                $temp_files[] = $path;
                $totale_bytes += (int) $file['size'];

                /* Il tetto complessivo si controlla mentre si accumula, cosi' un
                   invio smisurato si ferma prima di aver spostato tutti i file. */
                if ($totale_bytes > FI_RICETTE_MAX_MB_TOTALE * MB_IN_BYTES) {
                    throw new RuntimeException('total_size_exceeded');
                }
            }

            $conteggio[$etichetta] = count($elenco);
        }

        $righe_allegati = array();
        foreach ($conteggio as $etichetta => $quanti) {
            $righe_allegati[] = sprintf(
                /* translators: 1: quantità, 2: tipo di documento. */
                _n('%1$d file (%2$s)', '%1$d file (%2$s)', $quanti, 'farmaciainternazionale-child-theme'),
                $quanti,
                $etichetta
            );
        }

        $subject = __('Nuovo invio ricetta dal sito - Farmacia Internazionale', 'farmaciainternazionale-child-theme');
        $message = implode("\n", array(
            __('È stata ricevuta una nuova richiesta di invio ricetta dal sito.', 'farmaciainternazionale-child-theme'),
            '',
            __('Telefono cliente:', 'farmaciainternazionale-child-theme') . ' ' . $phone,
            __('Data invio:', 'farmaciainternazionale-child-theme') . ' ' . wp_date('d/m/Y H:i'),
            __('Consenso privacy: confermato', 'farmaciainternazionale-child-theme'),
            __('Allegati:', 'farmaciainternazionale-child-theme') . ' ' . implode(' + ', $righe_allegati),
        ));

        $sent = fi_ricette_send_mail(
            sanitize_email($settings['recipient_email']),
            $subject,
            $message,
            $temp_files
        );

        if (!$sent) {
            throw new RuntimeException('mail_failed');
        }

        $status = 'success';
    } catch (Throwable $error) {
        fi_ricette_log_error($error->getMessage());
    } finally {
        foreach ($temp_files as $temp_file) {
            if (is_string($temp_file) && file_exists($temp_file)) {
                wp_delete_file($temp_file);
            }
        }
    }

    fi_ricette_redirect($status);
}
