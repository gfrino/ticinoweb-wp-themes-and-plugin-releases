<?php
/**
 * Gestione centralizzata dei blocchi editoriali del sito.
 *
 * @package FarmaciaInternazionaleChild
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Elenco dei gruppi e contenuti predefiniti.
 */
function fi_site_blocks_registry()
{
    return array(
        'home_hero' => array(
            'page' => 'Home',
            'label' => 'Apertura (Hero)',
            'description' => 'Titolo principale e testo di presentazione in cima alla Home page.',
            'blocks' => array(
                array(
                    'id' => 'welcome',
                    'title' => 'Benvenuti alla Farmacia Internazionale di Locarno',
                    'text' => "Da oltre 30 anni siamo al servizio della tua salute.\nUn punto di riferimento per consulenza farmaceutica, prodotti naturali, prevenzione e orientamento verso i servizi sanitari più adatti.",
                    'icon' => 'sparkle',
                ),
            ),
        ),
        'home_intro' => array(
            'page' => 'Home',
            'label' => 'Valori in evidenza',
            'description' => 'Le tre card introduttive sotto la presentazione della farmacia.',
            'blocks' => array(
                array('id' => 'family', 'title' => 'Esperienza Familiare', 'text' => 'Da padre in figlio, una continuità fatta di fiducia, ascolto e conoscenza delle esigenze dei nostri clienti.'),
                /*
                 * ICONA FISSATA: il testo di questa scheda contiene "esperienza",
                 * e la deduzione automatica le darebbe l'orologio — lo stesso
                 * della scheda accanto. Tre schede affiancate con due icone
                 * uguali sembrano un errore di montaggio.
                 */
                array('id' => 'clinica', 'title' => 'Competenza Clinica', 'text' => 'Formazione continua ed esperienza ospedaliera, per consigli fondati sulle evidenze scientifiche.', 'icon' => 'award'),
                array('id' => 'health', 'title' => 'Supporto Sanitario', 'text' => 'Ti orientiamo con sicurezza verso i percorsi e le strutture cliniche più adatte quando ne hai bisogno.'),
            ),
        ),
        'home_nature' => array(
            'page' => 'Home',
            'label' => 'I tre pilastri',
            'description' => 'I tre pilastri nella sezione "Prevenire è meglio che curare" della home.',
            /*
             * ICONA IMPOSTATA A MANO, come su about_nature. Qui la deduzione
             * automatica sbagliava tutte e tre, perche' questi testi sono lunghi
             * e contengono parole che pesano piu' del titolo: "territorio"
             * portava Prevenzione sul segnaposto della mappa, "esperienza"
             * portava Competenza sull'orologio, "sanitario" portava
             * Accompagnamento sullo scudo.
             */
            'blocks' => array(
                array('id' => 'prevention', 'title' => 'Prevenzione', 'text' => 'Promuoviamo uno stile di vita sano attraverso consulenze personalizzate, educazione sanitaria, campagne di prevenzione e collaborazioni con realtà del territorio, aiutando ogni persona a prendersi cura della propria salute.', 'icon' => 'check'),
                array('id' => 'competence', 'title' => 'Competenza professionale', 'text' => 'La formazione continua e l\'esperienza maturata anche in ambito ospedaliero ci permettono di offrire consulenze e servizi di elevata qualità, fondati sulle più aggiornate evidenze scientifiche.', 'icon' => 'award'),
                array('id' => 'support', 'title' => 'Accompagnamento', 'text' => 'Ti aiutiamo a orientarti nel sistema sanitario, a comprendere le terapie e a individuare i servizi più adatti alle tue esigenze, accompagnandoti con competenza lungo il tuo percorso di salute.', 'icon' => 'compass'),
            ),
        ),
        'home_support' => array(
            'page' => 'Home',
            'label' => 'Percorso di supporto',
            'description' => 'I tre passaggi della sezione di orientamento sanitario.',
            'blocks' => array(
                array('id' => 'listen', 'title' => 'Ascoltiamo', 'text' => 'Valutiamo la tua esigenza con attenzione, professionalità e la massima discrezione.'),
                array('id' => 'advise', 'title' => 'Consigliamo', 'text' => 'Offriamo il primo soccorso e il consiglio farmaceutico opportuno per il tuo benessere.'),
                array('id' => 'guide', 'title' => 'Orientiamo', 'text' => 'Ti indirizziamo in totale sicurezza verso i migliori specialisti e cliniche del territorio.'),
            ),
        ),
        'services_process' => array(
            'page' => 'Servizi',
            'label' => 'Il nostro metodo',
            'description' => 'I tre passaggi che spiegano come viene accompagnato il cliente.',
            'blocks' => array(
                array('id' => 'listen', 'title' => 'Ascoltiamo', 'text' => 'Dedichiamo il tempo necessario per capire a fondo le tue esigenze, i tuoi sintomi e il tuo stile di vita.'),
                array('id' => 'advise', 'title' => 'Consigliamo', 'text' => 'Individuiamo i prodotti e i percorsi più adatti a te, orientandoti verso rimedi sicuri, efficaci e preferibilmente naturali.'),
                array('id' => 'follow', 'title' => 'Accompagniamo', 'text' => 'Non ti lasciamo solo. Restiamo a tua disposizione per seguire i tuoi progressi e adeguare le cure nel tempo.'),
            ),
        ),
        'services_values' => array(
            'page' => 'Servizi',
            'label' => 'Esperienza, sicurezza e vicinanza',
            'description' => 'Le tre card dei valori nella parte finale della pagina Servizi.',
            'blocks' => array(
                array('id' => 'experience', 'title' => '30+ anni di esperienza', 'text' => 'Una tradizione familiare che si tramanda con passione, offrendo sicurezza e affidabilità.'),
                /*
                 * Qui l'icona NON e' fissata: "terapia" nel titolo porta da sola
                 * alla capsula, che e' pertinente e diversa dalle altre due della
                 * riga (orologio e segnaposto). Fissarla sarebbe rumore inutile.
                 */
                array('id' => 'sicurezza', 'title' => 'Sicurezza della terapia', 'text' => 'Verifichiamo interazioni, dosaggi e compatibilità, perché ogni cura resti efficace e sicura.'),
                array('id' => 'location', 'title' => 'A Locarno e dintorni', 'text' => 'Un punto di ascolto vicino a te, radicato nel territorio e sempre aperto alle tue necessità.'),
            ),
        ),
        'about_values' => array(
            'page' => 'Chi siamo',
            'label' => 'I nostri valori',
            'description' => 'Le sei card che raccontano i valori della farmacia.',
            'blocks' => array(
                array('id' => 'listening', 'title' => 'Ascolto', 'text' => 'Diamo importanza a ogni parola per capire davvero i tuoi bisogni.'),
                array('id' => 'trust', 'title' => 'Fiducia', 'text' => 'Un rapporto trasparente e rassicurante, costruito giorno dopo giorno.'),
                array('id' => 'competence', 'title' => 'Competenza', 'text' => 'Aggiornamento continuo per offrire consulenze sicure e professionali.'),
                array('id' => 'nature', 'title' => 'Naturalezza', 'text' => 'Prediligiamo l’integrazione di cure naturali e fitoterapiche sicure.'),
                array('id' => 'nearby', 'title' => 'Vicinanza', 'text' => 'Radicati a Locarno, sempre accessibili e a disposizione della comunità.'),
                array('id' => 'responsibility', 'title' => 'Responsabilità', 'text' => 'Prendiamo a cuore la tua salute, seguendoti passo dopo passo.'),
            ),
        ),
        'about_nature' => array(
            'page' => 'Chi siamo',
            'label' => 'Molto piu\' di una farmacia',
            'description' => 'I tre punti informativi in fondo alla pagina Chi siamo.',
            /*
             * ICONA IMPOSTATA A MANO su queste tre. Di norma l'icona si deduce
             * dalle parole (vedi fi_get_dynamic_block_icon), ma qui la deduzione
             * dava lo stesso fumetto a "Competenza" e "Personalizzazione",
             * perche' entrambi i testi contengono "consigli": tre schede
             * affiancate con due icone identiche sembrano un errore. Fissandola
             * resta stabile anche se il committente riscrive i testi dal
             * pannello.
             */
            'blocks' => array(
                array('id' => 'competence', 'title' => 'Competenza', 'text' => 'Consigli professionali fondati sulle evidenze scientifiche.', 'icon' => 'award'),
                array('id' => 'personalization', 'title' => 'Personalizzazione', 'text' => 'Ogni persona è unica. Anche il consiglio deve esserlo.', 'icon' => 'compass'),
                array('id' => 'prevention', 'title' => 'Prevenzione', 'text' => 'Per vivere meglio oggi e preservare la salute di domani.', 'icon' => 'check'),
            ),
        ),
    );
}

/**
 * Restituisce un gruppo, completando eventuali dati mancanti con i fallback.
 */
function fi_get_site_blocks($group_key)
{
    $registry = fi_site_blocks_registry();
    if (!isset($registry[$group_key])) {
        return array();
    }

    $saved = get_option('fi_site_blocks', array());
    $saved_group = isset($saved[$group_key]) && is_array($saved[$group_key]) ? $saved[$group_key] : array();
    $blocks = array();

    foreach ($registry[$group_key]['blocks'] as $default) {
        $custom = isset($saved_group[$default['id']]) && is_array($saved_group[$default['id']]) ? $saved_group[$default['id']] : array();
        $title_fallback = $default['title'];
        $text_fallback  = $default['text'];

        /*
         * Per l'apertura della Home, se l'opzione centralizzata fi_site_blocks
         * non e' ancora stata salvata, recupera i valori storici salvati nel
         * database (vecchio slider del tema padre) per non perdere nulla.
         */
        if ('home_hero' === $group_key && 'welcome' === $default['id']) {
            $legacy_title = get_option('ticinoweb_slider_title_1');
            if (!empty($legacy_title)) {
                $title_fallback = $legacy_title;
            }
            $legacy_desc = get_option('ticinoweb_slider_desc_1');
            if (!empty($legacy_desc)) {
                $text_fallback = $legacy_desc;
            }
        }

        $blocks[] = array(
            'id' => $default['id'],
            'title' => isset($custom['title']) && '' !== $custom['title'] ? $custom['title'] : $title_fallback,
            'text' => isset($custom['text']) && '' !== $custom['text'] ? $custom['text'] : $text_fallback,
            /*
             * L'icona NON e' modificabile dal pannello: o la deduce il codice
             * dalle parole, o e' fissata nel registro. Passa da qui perche'
             * altrimenti la chiave si perderebbe per strada.
             */
            'icon' => isset($default['icon']) ? $default['icon'] : '',
        );
    }

    return $blocks;
}

/**
 * Sceglie un'icona controllata in base alle parole usate nel titolo e nel testo.
 */
function fi_get_dynamic_block_icon($title, $text = '', $forced = '')
{
    $content = strtolower(remove_accents($title . ' ' . $text));
    $icon = 'sparkle';
    /*
     * L'ORDINE CONTA: vince la prima regola che trova una parola, quindi le piu'
     * specifiche stanno in cima. Le cinque qui sotto servono ai servizi della
     * farmacia, dove le regole generiche sbagliavano: "Consulenza prodotti
     * online" pescava il fumetto per la parola "consulenza", e "Revisione
     * farmacia domestica" le pillole per "medicamenti", perdendo il senso.
     *
     * `casa` sta davanti a `pillole` di proposito: il testo della farmacia
     * domestica parla di "medicamenti presenti a casa", e senza questa
     * precedenza sarebbero due schede con la stessa capsula.
     */
    $rules = array(
        'battito'   => array('pressione', 'glicemia', 'misuraz', 'parametri'),
        'schermo'   => array('online', 'digitale', 'remoto', 'a distanza'),
        'aereo'     => array('viagg', 'partire', 'estero', 'vacanz'),
        'casa'      => array('domestic', 'armadiett', 'a casa'),
        'valigetta' => array('emergenz', 'urgenz', 'kit'),
        /* NIENTE 'farmac' qui: su un sito di farmacia quella radice sta
           dappertutto, e catturava "consiglio farmaceutico" nella sezione
           Percorso di supporto, rubandole il fumetto dell'ascolto. */
        'pillole'   => array('terapeutic', 'terapia', 'medicament', 'posologia'),

        'clock' => array('esperienza', 'anni', 'tradizione', 'storico'),
        'leaf' => array('natur', 'piant', 'fitoterap', 'olist', 'erbor'),
        'pin' => array('locarno', 'territorio', 'vicinanza', 'vicino', 'dintorni', 'comunita'),
        'shield' => array('sanitario', 'salute', 'sicurezza', 'sicure', 'protezione', 'responsabil'),
        'heart' => array('famiglia', 'familiare', 'fiducia', 'cuore', 'passione'),
        'chat' => array('ascolt', 'consulenza', 'parola', 'consigli'),
        'award' => array('competenza', 'qualificat', 'profession', 'certificat'),
        'compass' => array('orient', 'percorso', 'indirizz', 'accompagn'),
        'plus' => array('integraz', 'supplement', 'medicina', 'soccorso'),
        'check' => array('prevenzione', 'efficac', 'garantit', 'selezionat'),
    );

    foreach ($rules as $candidate => $keywords) {
        foreach ($keywords as $keyword) {
            if (false !== strpos($content, $keyword)) {
                $icon = $candidate;
                break 2;
            }
        }
    }

    $paths = array(
        /* --- icone tematiche dei servizi della farmacia --- */
        /* cuore col battito: misurazioni di pressione e glicemia */
        'battito'   => '<path d="M20.8 5.6a5.4 5.4 0 0 0-7.7 0L12 6.7l-1.1-1.1a5.4 5.4 0 0 0-7.7 7.7L12 21.2l8.6-8.8a5.4 5.4 0 0 0 0-6.8Z"></path><path d="M4.6 12.4h3.1l1.6-2.6 2.1 4.6 1.6-2.6h4.4"></path>',
        /* schermo: consulenza a distanza */
        'schermo'   => '<rect x="2" y="4" width="20" height="13" rx="2"></rect><path d="M8 21h8M12 17v4"></path>',
        /* aeroplano: medicina di viaggio */
        'aereo'     => '<path d="M17.8 19.2 16 11l3.5-3.5a2.1 2.1 0 0 0-3-3L13 8 4.8 6.2a1 1 0 0 0-.9 1.7l5.3 3.6-2.4 2.4-2.3-.5a1 1 0 0 0-.9 1.6l4 4a1 1 0 0 0 1.6-.9l-.5-2.3 2.4-2.4 3.6 5.3a1 1 0 0 0 1.7-.9z"></path>',
        /* casa con la croce: la farmacia domestica */
        'casa'      => '<path d="M3 10.5 12 3l9 7.5"></path><path d="M5 9.5V20a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V9.5"></path><path d="M12 12v5M9.5 14.5h5"></path>',
        /* valigetta con la croce: la farmacia d\'emergenza */
        'valigetta' => '<rect x="2" y="7" width="20" height="14" rx="2"></rect><path d="M9 7V5a2 2 0 0 1 2-2h2a2 2 0 0 1 2 2v2"></path><path d="M12 11v6M9 14h6"></path>',
        /* capsula: la terapia e i medicamenti */
        'pillole'   => '<path d="M13.5 3.5a5 5 0 0 1 7 7l-7 7a5 5 0 0 1-7-7z"></path><path d="M8.5 8.5 15.5 15.5"></path>',

        'clock' => '<circle cx="12" cy="12" r="9"></circle><path d="M12 7v5l3 2"></path>',
        'leaf' => '<path d="M11 20A7 7 0 0 1 9.8 6.1C15.5 5 17 4.5 19 2c1 2 2 4.2 2 8 0 5.5-4.8 10-10 10Z"></path><path d="M2 21c0-3 1.9-5.4 5.1-6C9.5 14.5 12 13 13 12"></path>',
        'pin' => '<path d="M20 10c0 5-8 12-8 12S4 15 4 10a8 8 0 1 1 16 0Z"></path><circle cx="12" cy="10" r="2.5"></circle>',
        'shield' => '<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10Z"></path><path d="M12 8v8M8 12h8"></path>',
        'heart' => '<path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1.1-1.1a5.5 5.5 0 0 0-7.8 7.8l1.1 1.1L12 21.2l7.8-7.8 1.1-1.1a5.5 5.5 0 0 0-.1-7.7Z"></path>',
        'chat' => '<path d="M21 11.5a8.5 8.5 0 0 1-12.3 7.6L3 21l1.9-5.7A8.5 8.5 0 1 1 21 11.5Z"></path><path d="M8 12h8M8 9h5"></path>',
        'award' => '<circle cx="12" cy="8" r="5"></circle><path d="m8.5 12-1 10 4.5-3 4.5 3-1-10"></path><path d="m10 8 1.3 1.3L14 6.5"></path>',
        'compass' => '<circle cx="12" cy="12" r="9"></circle><path d="m16 8-2.5 5.5L8 16l2.5-5.5L16 8Z"></path>',
        'plus' => '<circle cx="12" cy="12" r="9"></circle><path d="M12 8v8M8 12h8"></path>',
        'check' => '<circle cx="12" cy="12" r="9"></circle><path d="m8 12 2.5 2.5L16 9"></path>',
        'sparkle' => '<path d="m12 3 1.4 4.6L18 9l-4.6 1.4L12 15l-1.4-4.6L6 9l4.6-1.4L12 3Z"></path><path d="m18.5 15 .8 2.2 2.2.8-2.2.8-.8 2.2-.8-2.2-2.2-.8 2.2-.8.8-2.2Z"></path>',
    );

    /*
     * L'icona scelta a mano vince, ma solo se e' una di quelle disegnate qui:
     * un nome sbagliato nel registro deve ricadere sulla deduzione, non
     * produrre un buco al posto dell'icona.
     */
    if ('' !== $forced && isset($paths[$forced])) {
        $icon = $forced;
    }

    return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="fi-svg-icon" aria-hidden="true" focusable="false">' . $paths[$icon] . '</svg>';
}

/**
 * Sanitizza esclusivamente i gruppi e gli ID conosciuti.
 */
function fi_sanitize_site_blocks($input)
{
    $registry = fi_site_blocks_registry();
    $clean = array();

    if (!is_array($input)) {
        return $clean;
    }

    foreach ($registry as $group_key => $group) {
        foreach ($group['blocks'] as $default) {
            $submitted = isset($input[$group_key][$default['id']]) && is_array($input[$group_key][$default['id']])
                ? $input[$group_key][$default['id']]
                : array();
            $clean[$group_key][$default['id']] = array(
                'title' => isset($submitted['title']) ? sanitize_text_field($submitted['title']) : $default['title'],
                'text' => isset($submitted['text']) ? sanitize_textarea_field($submitted['text']) : $default['text'],
            );
        }
    }

    return $clean;
}

add_action('admin_menu', 'fi_site_blocks_admin_menu');
function fi_site_blocks_admin_menu()
{
    add_menu_page(
        'Blocchi del sito',
        'Blocchi del sito',
        'manage_options',
        'fi-site-blocks',
        'fi_render_site_blocks_admin',
        'dashicons-screenoptions',
        31
    );
}

add_action('admin_init', 'fi_site_blocks_register_settings');
function fi_site_blocks_register_settings()
{
    register_setting(
        'fi_site_blocks_settings',
        'fi_site_blocks',
        array(
            'type' => 'array',
            'sanitize_callback' => 'fi_sanitize_site_blocks',
            'default' => array(),
        )
    );
}

add_action('admin_enqueue_scripts', 'fi_site_blocks_admin_assets');
function fi_site_blocks_admin_assets($hook)
{
    if ('toplevel_page_fi-site-blocks' !== $hook) {
        return;
    }

    wp_enqueue_style(
        'fi-admin-site-blocks',
        get_stylesheet_directory_uri() . '/assets/css/admin-site-blocks.css',
        array(),
        wp_get_theme()->get('Version')
    );
}

/**
 * Dashboard di modifica dei blocchi.
 */
function fi_render_site_blocks_admin()
{
    if (!current_user_can('manage_options')) {
        wp_die(esc_html__('Non hai i permessi per accedere a questa pagina.', 'farmaciainternazionale'));
    }

    $registry = fi_site_blocks_registry();
    $pages = array();
    $total = 0;
    foreach ($registry as $key => $group) {
        $pages[$group['page']][$key] = $group;
        $total += count($group['blocks']);
    }
    /* Le pagine che hanno solo titoli di sezione (Contatti, Emergenze, Footer). */
    foreach (array_keys(fi_site_headings_registry()) as $heading_page) {
        if (!isset($pages[$heading_page])) {
            $pages[$heading_page] = array();
        }
        $total += fi_site_headings_count($heading_page);
    }
    ?>
    <div class="wrap fi-blocks-admin">
        <header class="fi-blocks-hero">
            <div class="fi-blocks-hero-icon"><?php echo fi_get_dynamic_block_icon('Blocchi del sito', 'contenuti'); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div>
            <div>
                <h1>Blocchi del sito</h1>
                <p>Modifica i titoli delle sezioni e le card editoriali di ogni pagina. L’icona delle card viene scelta automaticamente in base al contenuto.</p>
            </div>
            <div class="fi-blocks-stats">
                <span><strong><?php echo esc_html($total); ?></strong> voci modificabili</span>
                <span><strong><?php echo esc_html(count($pages)); ?></strong> pagine</span>
                <span class="is-green">Icone automatiche</span>
            </div>
        </header>

        <?php settings_errors(); ?>

        <div class="fi-blocks-note">
            <span class="dashicons dashicons-lightbulb"></span>
            <div><strong>Gestione semplice e sicura</strong><p>Non devi scegliere o caricare icone: modifica le parole e, al salvataggio, il sistema assegnerà l’icona più coerente.</p></div>
        </div>

        <form method="post" action="options.php">
            <?php settings_fields('fi_site_blocks_settings'); ?>
            <div class="fi-blocks-layout">
                <main class="fi-blocks-main">
                    <?php foreach ($pages as $page_name => $groups) : ?>
                        <section class="fi-blocks-page">
                            <div class="fi-blocks-page-heading">
                                <span class="dashicons dashicons-admin-page"></span>
                                <div><span>Pagina</span><h2><?php echo esc_html($page_name); ?></h2></div>
                            </div>

                            <?php foreach ($groups as $group_key => $group) : ?>
                                <?php $blocks = fi_get_site_blocks($group_key); ?>
                                <div class="fi-blocks-group">
                                    <div class="fi-blocks-group-heading">
                                        <div><h3><?php echo esc_html($group['label']); ?></h3><p><?php echo esc_html($group['description']); ?></p></div>
                                        <span><?php echo esc_html(count($blocks)); ?> blocchi</span>
                                    </div>
                                    <div class="fi-blocks-grid">
                                        <?php foreach ($blocks as $index => $block) : ?>
                                            <?php
                                            $is_hero = ('home_hero' === $group_key);
                                            $text_rows = $is_hero ? 4 : 3;
                                            $text_maxlength = $is_hero ? 600 : 360;
                                            $block_icon = !empty($block['icon']) ? $block['icon'] : '';
                                            ?>
                                            <article class="fi-block-editor">
                                                <div class="fi-block-editor-head">
                                                    <div class="fi-block-icon-preview"><?php echo fi_get_dynamic_block_icon($block['title'], $block['text'], $block_icon); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div>
                                                    <div>
                                                        <strong><?php echo $is_hero ? 'Testo di apertura' : sprintf(esc_html__('Blocco %d', 'farmaciainternazionale'), $index + 1); ?></strong>
                                                        <small><?php echo $is_hero ? 'Intestazione principale' : 'Icona automatica'; ?></small>
                                                    </div>
                                                </div>
                                                <label>
                                                    <span>Titolo</span>
                                                    <input type="text" name="fi_site_blocks[<?php echo esc_attr($group_key); ?>][<?php echo esc_attr($block['id']); ?>][title]" value="<?php echo esc_attr($block['title']); ?>" maxlength="150">
                                                </label>
                                                <label>
                                                    <span>Descrizione / testo</span>
                                                    <textarea name="fi_site_blocks[<?php echo esc_attr($group_key); ?>][<?php echo esc_attr($block['id']); ?>][text]" rows="<?php echo esc_attr($text_rows); ?>" maxlength="<?php echo esc_attr($text_maxlength); ?>"><?php echo esc_textarea($block['text']); ?></textarea>
                                                </label>
                                            </article>
                                        <?php endforeach; ?>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                            <?php fi_render_site_headings_admin($page_name); ?>
                        </section>
                    <?php endforeach; ?>
                </main>

                <aside class="fi-blocks-sidebar">
                    <div class="fi-blocks-summary">
                        <h2>Riepilogo</h2>
                        <ul>
                            <?php foreach ($pages as $page_name => $groups) : ?>
                                <?php
                                $page_total = fi_site_headings_count($page_name);
                                foreach ($groups as $group) {
                                    $page_total += count($group['blocks']);
                                }
                                ?>
                                <li><span><?php echo esc_html($page_name); ?></span><strong><?php echo esc_html($page_total); ?> voci</strong></li>
                            <?php endforeach; ?>
                        </ul>
                        <?php submit_button('Salva tutto', 'primary fi-blocks-save', 'submit', false); ?>
                        <p class="fi-blocks-save-help">Le modifiche diventano visibili subito sul sito.</p>
                    </div>
                </aside>
            </div>
        </form>
    </div>
    <?php
}
