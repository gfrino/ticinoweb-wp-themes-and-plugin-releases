<?php
/**
 * TITOLI DELLE SEZIONI — occhielli, titoli, testi introduttivi ed etichette.
 *
 * Prima stavano scritti nei template: per cambiare «Siamo qui per aiutarti.»
 * serviva lo sviluppatore. Ora si modificano da Bacheca → Blocchi del sito,
 * nella stessa pagina delle card, sotto la voce «Titoli delle sezioni».
 *
 * COME FUNZIONA. Ogni voce del registro dichiara SOLO i campi che ha davvero
 * nella pagina (un titolo senza occhiello non mostra il campo occhiello). Il
 * testo nel registro e' il valore di partenza: vale finche' il cliente non salva.
 *
 * CAMPO VUOTO. Il titolo vuoto torna al valore di partenza (una sezione senza
 * titolo sarebbe un buco). Occhiello, testo ed etichette vuoti invece SPARISCONO
 * dalla pagina: e' il modo per togliere un'etichetta che non serve piu'.
 *
 * I dati che il CMS ha gia' altrove NON stanno qui, per non averli in due posti:
 * il titolo di Chi siamo (ticinoWEB CMS → Chi siamo), i recapiti e gli orari
 * (ticinoWEB CMS → Contatti), il nome della farmacia (Impostazioni → Generali).
 *
 * @package FarmaciaInternazionaleChild
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Nomi dei campi come li legge il cliente nel pannello.
 */
function fi_site_headings_field_labels()
{
    return array(
        'kicker' => 'Occhiello (testo piccolo sopra il titolo)',
        'title'  => 'Titolo',
        'text'   => 'Testo',
        'badges' => 'Etichette (una per riga)',
    );
}

/**
 * Registro: pagina → voci. Ogni voce ha un'etichetta per il pannello e i suoi campi.
 */
function fi_site_headings_registry()
{
    return array(
        'Home' => array(
            'home_intro' => array(
                'label'  => 'Presentazione della farmacia',
                'kicker' => 'Farmacia Internazionale',
                'title'  => 'Esperienza e supporto vicino a te.',
                'text'   => "Da oltre trent'anni accompagniamo le persone nelle loro scelte di salute. Oggi continuiamo questa storia con una visione ancora più ampia: una farmacia dove competenza scientifica, prevenzione, ascolto e consulenza personalizzata si uniscono per aiutare ogni persona a prendersi cura della propria salute.",
            ),
            'home_services' => array(
                'label'  => 'Servizi',
                'kicker' => 'I Nostri Servizi',
                'title'  => 'Servizi pensati per il tuo benessere.',
                'text'   => 'Dalla consulenza farmaceutica ai prodotti naturali, ti accompagniamo con soluzioni progettate su misura per il tuo benessere quotidiano.',
            ),
            'home_nature' => array(
                'label'  => 'Prevenire è meglio che curare',
                'kicker' => "L'essenza della nostra farmacia",
                'title'  => 'Prevenire è meglio che curare.',
                'text'   => 'Crediamo che la salute si costruisca ogni giorno, attraverso le scelte e le attenzioni quotidiane. Per questo la nostra farmacia promuove un approccio moderno, in cui prevenzione, competenza professionale e accompagnamento del paziente rappresentano i pilastri del nostro lavoro.',
            ),
            'home_orient' => array(
                'label'  => 'Orientamento clinico (percorso in tre passi)',
                'kicker' => 'Orientamento Clinico',
                'title'  => 'Siamo qui per guidarti.',
                'text'   => "Quando la situazione richiede l'intervento di un medico o di una struttura specializzata, ti aiutiamo a trovare il percorso sanitario più adatto a Locarno e dintorni.",
                'badges' => 'Locarno e dintorni',
                'help'   => "L'etichetta compare sotto il terzo passo.",
            ),
            'home_history' => array(
                'label'  => 'Una storia di famiglia',
                'kicker' => 'La nostra storia',
                'help'   => 'Titolo e testo di questa sezione arrivano da ticinoWEB CMS → Chi siamo.',
            ),
            'home_spaces' => array(
                'label'  => 'La nostra farmacia (foto degli spazi)',
                'kicker' => 'Ambiente e spazi',
                'title'  => 'La nostra farmacia',
                'text'   => 'Un ambiente accogliente e professionale, pensato per il tuo benessere.',
            ),
            'home_categories' => array(
                'label' => 'Reparti',
                'title' => 'I nostri reparti',
            ),
            'home_contact' => array(
                'label' => 'Vieni a trovarci (recapiti)',
                'title' => 'Vieni a trovarci',
                'text'  => 'Il nostro team è pronto ad accoglierti con competenza e un sorriso.',
                'help'  => 'Indirizzo, telefono, e-mail e orari arrivano da ticinoWEB CMS → Contatti.',
            ),
        ),
        'Servizi' => array(
            'services_hero' => array(
                'label'  => 'Apertura della pagina',
                'badges' => "Consulenza professionale\nSupporto personalizzato",
                'text'   => 'Consulenza, prodotti naturali, prevenzione e supporto personalizzato: ti accompagniamo ogni giorno con competenza e attenzione.',
                'help'   => "Il titolo è quello della pagina (Pagine → Servizi). Se la pagina ha un riassunto, vale il riassunto al posto di questo testo.",
            ),
            'services_method' => array(
                'label' => 'Il nostro metodo',
                'title' => 'Il nostro metodo',
                'text'  => 'Tre passi fondamentali per garantirti il miglior supporto possibile, mettendo sempre la persona al centro.',
            ),
            'services_values' => array(
                'label' => 'Esperienza, ascolto e natura',
                'title' => "L'unione tra esperienza, ascolto e natura",
                'text'  => 'La nostra farmacia è un punto di riferimento storico che ha saputo evolversi mantenendo saldi i propri valori fondanti.',
            ),
        ),
        'Chi siamo' => array(
            'about_hero' => array(
                'label'  => 'Apertura della pagina',
                'badges' => "30+ anni\nLocarno\nTradizione familiare",
                'text'   => 'Una farmacia storica a Locarno, nata come realtà familiare e cresciuta nel tempo grazie alla fiducia delle persone.',
                'help'   => 'Il titolo arriva da ticinoWEB CMS → Chi siamo.',
            ),
            'about_story' => array(
                'label'  => 'La nostra storia',
                'kicker' => 'La nostra storia',
            ),
            'about_values' => array(
                'label' => 'I nostri valori',
                'title' => 'I nostri valori',
            ),
            'about_more' => array(
                'label'  => 'Molto più di una farmacia',
                'kicker' => 'Molto più di una farmacia',
                'title'  => 'Il tuo punto di riferimento per la salute.',
                'text'   => 'Crediamo che il ruolo del farmacista non sia solo dispensare farmaci, ma accompagnare ogni persona nelle proprie scelte di salute. Per questo uniamo competenza clinica, prevenzione, educazione sanitaria e una selezione rigorosa di farmaci, integratori e rimedi naturali basati sulle migliori evidenze disponibili.',
            ),
        ),
        'Contatti' => array(
            'contact_hero' => array(
                'label'  => 'Apertura della pagina',
                'badges' => "Locarno\nSempre a disposizione",
                'title'  => 'Contatti',
                'text'   => 'Hai bisogno di un consiglio, vuoi prenotare un prodotto o semplicemente sapere dove siamo? Trovi qui tutti i nostri recapiti.',
            ),
            'contact_card' => array(
                'label' => 'Riquadro dei recapiti',
                'title' => 'Farmacia Internazionale',
                'text'  => 'Siamo a tua disposizione per qualsiasi necessità.',
            ),
            'contact_hours' => array(
                'label' => 'Riquadro degli orari',
                'title' => 'Orari di apertura',
                'text'  => 'Controlla quando siamo aperti.',
            ),
            'contact_where' => array(
                'label' => 'Riquadro «Dove siamo»',
                'title' => 'Dove siamo',
                'text'  => 'Vieni a trovarci a Locarno.',
                'help'  => 'Compare al posto degli orari solo se gli orari non sono compilati.',
            ),
        ),
        'Emergenze' => array(
            'emergency_hero' => array(
                'label'  => 'Apertura della pagina',
                'badges' => "Contatti utili\nEmergenze e fuori orario",
                'title'  => 'Numeri importanti e supporto fuori orario',
                'text'   => 'Una raccolta di contatti utili per situazioni urgenti, pronto soccorso, intossicazioni e servizi sanitari fuori orario nel territorio.',
            ),
        ),
        'Footer (in fondo a ogni pagina)' => array(
            'footer_cta' => array(
                'label'  => 'Invito a contattarci',
                'kicker' => 'Hai bisogno di un consiglio?',
                'title'  => 'Siamo qui per aiutarti.',
                'text'   => 'Passa in farmacia o contattaci: ti accompagneremo verso il percorso più adatto alle tue esigenze.',
            ),
            'footer_brand' => array(
                'label'  => 'Colonna con il nome',
                'badges' => 'Da oltre 30 anni a Locarno',
                'text'   => "Uniamo l'esperienza farmaceutica all'aggiornamento clinico costante, per offrirti una consulenza professionale a Locarno.",
                'help'   => 'Il nome è quello del sito (Impostazioni → Generali). Il testo vale solo se in ticinoWEB CMS → Chi siamo il testo è vuoto: altrimenti si usano le sue prime 20 parole.',
            ),
        ),
    );
}

/**
 * Trova una voce nel registro, qualunque sia la pagina.
 *
 * @param string $key Chiave della voce.
 * @return array|null
 */
function fi_site_heading_definition($key)
{
    foreach (fi_site_headings_registry() as $items) {
        if (isset($items[$key])) {
            return $items[$key];
        }
    }

    return null;
}

/**
 * Valori di una voce, pronti per il template.
 *
 * Restituisce sempre tutte e quattro le chiavi: kicker, title, text (stringhe)
 * e badges (array di stringhe). Un campo che la voce non ha resta vuoto.
 *
 * @param string $key Chiave della voce.
 * @return array
 */
function fi_heading($key)
{
    $out = array('kicker' => '', 'title' => '', 'text' => '', 'badges' => array());
    $def = fi_site_heading_definition($key);
    if (null === $def) {
        return $out;
    }

    $saved = get_option('fi_site_headings', array());
    $saved = (is_array($saved) && isset($saved[$key]) && is_array($saved[$key])) ? $saved[$key] : array();

    foreach (array('kicker', 'title', 'text', 'badges') as $field) {
        if (!isset($def[$field])) {
            continue;
        }
        $value = $def[$field];
        if (array_key_exists($field, $saved)) {
            $value = trim((string) $saved[$field]);
            /* Il titolo non puo' restare vuoto: torna quello di partenza. */
            if ('title' === $field && '' === $value) {
                $value = $def[$field];
            }
        }

        if ('badges' === $field) {
            $out['badges'] = array_values(array_filter(array_map('trim', preg_split('/\r\n|\r|\n/', $value))));
        } else {
            $out[$field] = $value;
        }
    }

    return $out;
}

/**
 * Pulisce cio' che arriva dal pannello: solo voci e campi conosciuti.
 *
 * @param mixed $input Valori inviati.
 * @return array
 */
function fi_sanitize_site_headings($input)
{
    $clean = array();
    if (!is_array($input)) {
        return $clean;
    }

    foreach (fi_site_headings_registry() as $items) {
        foreach ($items as $key => $def) {
            foreach (array('kicker', 'title', 'text', 'badges') as $field) {
                if (!isset($def[$field]) || !isset($input[$key][$field])) {
                    continue;
                }
                /* options.php ha gia' tolto le barre aggiunte da WordPress. */
                $raw = (string) $input[$key][$field];
                $clean[$key][$field] = in_array($field, array('text', 'badges'), true)
                    ? sanitize_textarea_field($raw)
                    : sanitize_text_field($raw);
            }
        }
    }

    return $clean;
}

add_action('admin_init', 'fi_site_headings_register_setting');
function fi_site_headings_register_setting()
{
    /* Stesso gruppo dei blocchi: un solo pulsante «Salva» salva entrambi. */
    register_setting(
        'fi_site_blocks_settings',
        'fi_site_headings',
        array(
            'type' => 'array',
            'sanitize_callback' => 'fi_sanitize_site_headings',
            'default' => array(),
        )
    );
}

/**
 * Numero di voci di una pagina, per il riepilogo del pannello.
 *
 * @param string $page Nome della pagina.
 * @return int
 */
function fi_site_headings_count($page)
{
    $registry = fi_site_headings_registry();
    return isset($registry[$page]) ? count($registry[$page]) : 0;
}

/**
 * Disegna nel pannello le voci di una pagina.
 *
 * @param string $page Nome della pagina, come nel registro.
 */
function fi_render_site_headings_admin($page)
{
    $registry = fi_site_headings_registry();
    if (empty($registry[$page])) {
        return;
    }
    $labels = fi_site_headings_field_labels();
    ?>
    <div class="fi-blocks-group">
        <div class="fi-blocks-group-heading">
            <div>
                <h3>Titoli delle sezioni</h3>
                <p>Occhielli, titoli e testi introduttivi delle sezioni. Lascia vuoto un occhiello, un testo o le etichette per toglierli dalla pagina.</p>
            </div>
            <span><?php echo esc_html(count($registry[$page])); ?> sezioni</span>
        </div>
        <div class="fi-blocks-grid">
            <?php foreach ($registry[$page] as $key => $def) : ?>
                <?php $val = fi_heading($key); ?>
                <article class="fi-block-editor">
                    <div class="fi-block-editor-head">
                        <div>
                            <strong><?php echo esc_html($def['label']); ?></strong>
                            <?php if (!empty($def['help'])) : ?>
                                <small><?php echo esc_html($def['help']); ?></small>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php foreach ($labels as $field => $label) : ?>
                        <?php
                        if (!isset($def[$field])) {
                            continue;
                        }
                        $name = 'fi_site_headings[' . $key . '][' . $field . ']';
                        ?>
                        <label>
                            <span><?php echo esc_html($label); ?></span>
                            <?php if ('text' === $field) : ?>
                                <textarea name="<?php echo esc_attr($name); ?>" rows="3" maxlength="600"><?php echo esc_textarea($val['text']); ?></textarea>
                            <?php elseif ('badges' === $field) : ?>
                                <textarea name="<?php echo esc_attr($name); ?>" rows="<?php echo esc_attr(max(2, count($val['badges']))); ?>" maxlength="300"><?php echo esc_textarea(implode("\n", $val['badges'])); ?></textarea>
                            <?php else : ?>
                                <input type="text" name="<?php echo esc_attr($name); ?>" value="<?php echo esc_attr($val[$field]); ?>" maxlength="150">
                            <?php endif; ?>
                        </label>
                    <?php endforeach; ?>
                </article>
            <?php endforeach; ?>
        </div>
    </div>
    <?php
}

/**
 * Stampa le etichette (badge) di una voce.
 *
 * @param string $key        Chiave della voce.
 * @param string $class      Classe CSS di ogni etichetta.
 * @param string $first_icon SVG (scritto nel tema) davanti alla prima etichetta.
 */
function fi_heading_badges($key, $class = 'fi-badge', $first_icon = '')
{
    $badges = fi_heading($key)['badges'];
    foreach ($badges as $i => $badge) {
        echo '<span class="' . esc_attr($class) . '">';
        if (0 === $i && '' !== $first_icon) {
            echo $first_icon; // phpcs:ignore WordPress.Security.EscapeOutput -- SVG scritto nel tema, non dal pannello.
        }
        echo esc_html($badge) . '</span>';
    }
}
