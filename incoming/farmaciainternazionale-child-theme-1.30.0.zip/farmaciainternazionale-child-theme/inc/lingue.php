<?php
/**
 * SELETTORE DI LINGUA — bandiere italiano / tedesco / francese / inglese.
 *
 * Le bandiere le disegna il plugin GTranslate. Il tema fornisce solo i due posti
 * in cui compaiono (la barra in alto e il menu del telefono) e l'aspetto.
 *
 * PERCHE' QUESTO FILE ESISTE. Le bandiere dipendono da due cose che stanno nella
 * banca dati del singolo sito e che *non* viaggiano con il file .zip del tema:
 * il plugin attivato su questo sito, e le sue impostazioni. Aggiornando il tema
 * sul sito in linea le bandiere non comparivano, e non compariva nemmeno un
 * avviso: il tema non trovava lo shortcode e stampava il nulla, in silenzio.
 * Qui quel silenzio viene rotto in tre modi:
 *
 *   1. le impostazioni del plugin le scrive il tema, una volta sola, se non
 *      esistono ancora: cosi' l'unico gesto che resta da fare a mano e'
 *      attivare il plugin;
 *   2. se il plugin non e' attivo, nel pannello di WordPress compare un avviso
 *      con scritto cosa fare;
 *   3. nel codice della pagina resta un commento invisibile ai visitatori, che
 *      permette di capire cosa manca guardando il sito da fuori.
 *
 * @package FarmaciaInternazionale
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Le quattro lingue del sito, nell'ordine in cui compaiono le bandiere.
 *
 * La prima e' la lingua in cui il sito e' scritto: GTranslate la usa come
 * punto di partenza, non la traduce.
 */
define('FI_LINGUE_CODICI', array('it', 'de', 'fr', 'en'));

/** Percorso del plugin dentro la cartella dei plugin. */
define('FI_LINGUE_PLUGIN', 'gtranslate/gtranslate.php');

/**
 * Il plugin e' presente sul server?
 *
 * Presente e attivo sono due cose diverse: sulla rete multisito il plugin puo'
 * essere installato per tutti i siti ma acceso solo su alcuni. Distinguere i
 * due casi serve per dare l'istruzione giusta nell'avviso.
 *
 * @return bool
 */
function fi_lingue_plugin_installato()
{
    return file_exists(WP_PLUGIN_DIR . '/' . FI_LINGUE_PLUGIN);
}

/**
 * Il plugin e' attivo su questo sito?
 *
 * Si controlla lo shortcode e non l'elenco dei plugin attivi, perche' e' lo
 * shortcode la cosa che serve davvero: copre anche l'attivazione di rete, dove
 * il plugin funziona pur non comparendo nell'elenco del singolo sito.
 *
 * @return bool
 */
function fi_lingue_plugin_attivo()
{
    return shortcode_exists('gtranslate');
}

/**
 * SCRIVE LE IMPOSTAZIONI DEL PLUGIN, UNA VOLTA SOLA.
 *
 * Senza questo, un plugin appena attivato mostra le sue dieci bandiere di
 * partenza (inglese, spagnolo, portoghese, russo, arabo, cinese...) invece
 * delle quattro che servono qui.
 *
 * NON SOVRASCRIVE MAI UNA SCELTA FATTA A MANO: agisce solo se l'opzione non
 * esiste ancora, cioe' se nessuno ha mai salvato la pagina delle impostazioni
 * di GTranslate su questo sito. Da quel momento in poi decide chi usa il
 * pannello, non il tema.
 *
 * Le chiavi non elencate qui il plugin le riempie da se' con i propri valori di
 * partenza, che vanno già bene.
 *
 * @return void
 */
function fi_lingue_prepara_impostazioni()
{
    if (false !== get_option('GTranslate')) {
        return;
    }

    add_option('GTranslate', array(
        'default_language'           => 'it',
        'incl_langs'                 => FI_LINGUE_CODICI,
        'fincl_langs'                => FI_LINGUE_CODICI,
        'widget_look'                => 'flags',
        'flag_size'                  => 24,
        'flag_style'                 => '2d',
        // Nomi nel loro alfabeto: passando il mouse si legge «Deutsch», non «German».
        'native_language_names'      => 1,
        // Niente riquadro fisso in un angolo dello schermo: le bandiere stanno
        // dove le mette il tema.
        'floating_language_selector' => 'no',
        'wrapper_selector'           => '.gtranslate_wrapper',
    ));
}
add_action('init', 'fi_lingue_prepara_impostazioni');

/**
 * STAMPA UN GRUPPO DI BANDIERE.
 *
 * PERCHE' PASSA DA UNA FUNZIONE E NON DALLO SHORTCODE SCRITTO DUE VOLTE: il
 * selettore serve in due posti — la barra in alto e il menu del telefono — e
 * ripetere lo shortcode significherebbe ritrovarsi due varianti da tenere
 * allineate a mano.
 *
 * OGNI ISTANZA E' INDIPENDENTE: GTranslate assegna a ciascuna un contenitore
 * con un id proprio e una configurazione a parte, quindi le due copie non si
 * disturbano. Le bandiere le disegna il suo JavaScript dentro il contenitore
 * vuoto, non arrivano gia' scritte dal server.
 *
 * SE IL PLUGIN NON C'E' non si stampa il riquadro — senza questo controllo in
 * cima a ogni pagina comparirebbe la scritta `[gtranslate ...]` — ma si lascia
 * un commento nel codice della pagina. I visitatori non lo vedono; serve a
 * capire dall'esterno perche' le bandiere mancano.
 *
 * @param string $posto Classe aggiuntiva per distinguere i due punti.
 * @return void
 */
function fi_stampa_lingue($posto)
{
    if (!fi_lingue_plugin_attivo()) {
        echo "\n<!-- lingue: il plugin GTranslate non e' attivo su questo sito -->\n";
        return;
    }
    ?>
    <div class="fi-lingue fi-lingue--<?php echo esc_attr($posto); ?>">
        <?php echo do_shortcode('[gtranslate widget_look="flags"]'); ?>
    </div>
    <?php
}

/**
 * L'ORDINE DELLE BANDIERE: PRIMA L'ITALIANO.
 *
 * L'italiano e' la lingua in cui il sito e' scritto, e in un selettore va per
 * prima: e' quella in cui il visitatore sta leggendo quando arriva.
 *
 * PERCHE' NON BASTAVA SISTEMARLO NEL PANNELLO. GTranslate salva le lingue
 * nell'ordine in cui stanno nel suo elenco di caselle, che e' alfabetico sui
 * nomi inglesi: spuntando italiano, tedesco, francese e inglese si ottiene
 * `en, fr, de, it`, con l'italiano ultimo. Quell'ordine finisce nella banca dati
 * del singolo sito, quindi non viaggia col file .zip e tornerebbe cosi' ad ogni
 * nuovo sito o ad ogni salvataggio del pannello.
 *
 * SI RIORDINA, NON SI DECIDE. Questo filtro non aggiunge e non toglie nessuna
 * lingua: quelle le sceglie chi usa il pannello. Mette in testa quelle che il
 * tema conosce, nell'ordine di FI_LINGUE_CODICI, e lascia in coda — nel loro
 * ordine — eventuali lingue aggiunte in futuro, che restano visibili.
 *
 * Le impostazioni salvate non vengono riscritte: si interviene solo al momento
 * della lettura.
 *
 * SE UN GIORNO SERVISSE un altro ordine:
 *     add_filter('fi_lingue_ordina', '__return_false');
 *
 * @param mixed $dati Le impostazioni di GTranslate, di norma un array.
 * @return mixed
 */
function fi_lingue_ordina_bandiere($dati)
{
    if (!is_array($dati) || !apply_filters('fi_lingue_ordina', true)) {
        return $dati;
    }

    // `fincl_langs` comanda le bandiere, `incl_langs` la tendina: si allineano
    // entrambe, cosi' l'ordine e' lo stesso in qualunque aspetto.
    foreach (array('fincl_langs', 'incl_langs') as $chiave) {
        if (empty($dati[$chiave]) || !is_array($dati[$chiave])) {
            continue;
        }

        $presenti = $dati[$chiave];
        $prima = array_values(array_intersect(FI_LINGUE_CODICI, $presenti));
        $dopo = array_values(array_diff($presenti, FI_LINGUE_CODICI));

        $dati[$chiave] = array_merge($prima, $dopo);
    }

    return $dati;
}
add_filter('option_GTranslate', 'fi_lingue_ordina_bandiere');

/**
 * UNA COPIA SOLA PER POSTO: VIA LE COPIE CHE IL PLUGIN AGGIUNGE DA SE'.
 *
 * IL PROBLEMA. GTranslate sa mettersi in pagina da solo, in tre modi, ognuno
 * comandato da un'impostazione salvata nella banca dati del singolo sito:
 *
 *   - `show_in_menu` lo attacca in coda a una navigazione (`wp_nav_menu_items`);
 *   - `floating_language_selector` lo incolla in un angolo dello schermo;
 *   - un `wrapper_selector` personalizzato lo stampa a fondo pagina.
 *
 * Sul sito in linea era attivo il primo. Risultato: un menu a tendina in piu',
 * con un aspetto diverso dalle bandiere, appeso dopo l'ultima voce del menu — e
 * siccome il plugin lo avvolge in un `position: absolute`, sul desktop finiva
 * sopra le nostre bandiere. Nel menu del telefono compariva una seconda volta,
 * sopra la nostra sezione «Lingua».
 *
 * LA DECISIONE. Il posto del selettore lo decide il tema, che ne ha scelti due
 * con cura: la barra in alto e il menu del telefono. Quelle impostazioni sono
 * per-sito e non viaggiano col file .zip, quindi non basta spegnerle una volta a
 * mano: al prossimo sito, o alla prossima persona che apre il pannello di
 * GTranslate, tornerebbero. Qui si stacca l'aggancio, cosi' la regola vale
 * sempre e da sola.
 *
 * NON SI TOCCANO LE SUE IMPOSTAZIONI: restano scritte come le ha lasciate chi
 * ha usato il pannello. Si toglie solo l'uscita in pagina. E la traduzione non
 * ne soffre: quella la fanno gli script delle nostre due istanze.
 *
 * SE UN GIORNO SERVISSE il selettore dentro il menu, basta:
 *     add_filter('fi_lingue_una_copia_sola', '__return_false');
 *
 * @return void
 */
function fi_lingue_togli_copie_del_plugin()
{
    /**
     * Vale la regola «una copia sola per posto»?
     *
     * @param bool $attiva
     */
    if (!apply_filters('fi_lingue_una_copia_sola', true)) {
        return;
    }

    // In coda alle navigazioni. Il plugin registra questo filtro solo se
    // l'impostazione e' accesa; se non c'e', togliere non fa nulla.
    remove_filter('wp_nav_menu_items', 'gtranslate_menu_item', 10);

    // Riquadro fisso in un angolo dello schermo.
    remove_action('wp_footer', 'gtranslate_display_floating');

    // Copia a fondo pagina, quando il contenitore e' personalizzato.
    remove_action('wp_footer', 'gtranslate_add_inline_selector');
}
add_action('init', 'fi_lingue_togli_copie_del_plugin', 20);

/**
 * AVVISO NEL PANNELLO QUANDO LE BANDIERE NON POSSONO FUNZIONARE.
 *
 * Si mostra solo a chi puo' rimediare e solo finche' il problema c'e': appena
 * il plugin viene attivato l'avviso sparisce da se'.
 *
 * @return void
 */
function fi_lingue_avviso_admin()
{
    if (fi_lingue_plugin_attivo() || !current_user_can('activate_plugins')) {
        return;
    }

    if (fi_lingue_plugin_installato()) {
        $azione = sprintf(
            'Vai in <a href="%s"><strong>Plugin</strong></a> e premi «Attiva» su <strong>GTranslate</strong>. Se nell\'elenco non c\'e\', cercalo in <strong>I miei siti &rarr; Amministrazione network &rarr; Plugin</strong>.',
            esc_url(admin_url('plugins.php?s=GTranslate&plugin_status=all'))
        );
    } else {
        $azione = sprintf(
            'Il plugin non e\' installato su questo server: installalo da <a href="%s"><strong>Plugin &rarr; Aggiungi nuovo</strong></a> cercando «GTranslate».',
            esc_url(admin_url('plugin-install.php?tab=search&type=term&s=GTranslate'))
        );
    }
    ?>
    <div class="notice notice-warning">
        <p>
            <strong>Le bandiere delle lingue non sono visibili sul sito.</strong>
            Il tema le prevede in cima alle pagine e nel menu del telefono, ma le
            disegna il plugin <strong>GTranslate</strong>, che ora non e' attivo.
        </p>
        <p><?php echo wp_kses_post($azione); ?></p>
        <p>
            Le lingue (italiano, tedesco, francese, inglese) sono gia' impostate
            dal tema: dopo l'attivazione non serve configurare nulla.
        </p>
    </div>
    <?php
}
add_action('admin_notices', 'fi_lingue_avviso_admin');
