<?php

/**
 * PANNELLO «IMMAGINI DEL SITO».
 *
 * Un posto solo da cui cambiare ogni immagine fissa del tema: l'apertura della
 * homepage, la foto della storia, la filigrana, le quattro schede dei reparti.
 * Prima alcune di queste erano scritte nel codice e per sostituirle serviva un
 * intervento sul tema.
 *
 * IL VIDEO DI SFONDO NON STA QUI DI PROPOSITO: resta quello scritto in
 * dna-animation.php e non si cambia dal pannello.
 *
 * SI SALVA L'ID DELL'ALLEGATO, NON IL SUO INDIRIZZO. Questo sito e' stato
 * migrato tre volte, e ogni volta gli indirizzi degli upload sono cambiati —
 * dominio, porta, numero del sito nel Multisite — lasciando immagini rotte
 * dietro di se'. L'ID no: e' un numero interno che WordPress risolve
 * nell'indirizzo giusto sul posto in cui si trova.
 *
 * NON TOCCARE NIENTE DEVE LASCIARE IL SITO IDENTICO. Ogni voce del registro
 * dichiara da dove l'immagine veniva prima (un'opzione del CMS, una galleria,
 * un indirizzo di riserva), e fi_immagine() ripercorre quella strada quando dal
 * pannello non e' stato scelto niente. Il tema aggiornato mostra quindi le
 * stesse immagini di oggi finche' qualcuno non decide di cambiarle.
 *
 * @package farmaciainternazionale-child-theme
 */

if (!defined('ABSPATH')) {
    exit;
}

/** Opzione con le immagini singole: chiave del registro => ID dell'allegato. */
define('FI_IMMAGINI_OPZIONE', 'fi_immagini');

/** Opzione con le quattro schede dei reparti. */
define('FI_REPARTI_OPZIONE', 'fi_immagini_reparti');

/**
 * Il registro delle immagini fisse del tema.
 *
 * Campi di ogni voce:
 *   etichetta   nome della posizione, come lo leggerebbe chi non ha scritto il tema
 *   dove        in che pagina e in che punto compare
 *   consiglio   proporzioni o misura consigliata
 *   origine     dove stava l'immagine prima del pannello:
 *                 'opzione'   nome di un'opzione del CMS che contiene un indirizzo
 *                 'theme_mod' nome di una personalizzazione del tema
 *                 'galleria'  ID di un termine della tassonomia delle gallerie
 *   riserva     indirizzo usato quando non c'e' proprio nient'altro
 *
 * @return array
 */
function fi_immagini_registro()
{
    /*
     * GLI INDIRIZZI DI RISERVA SONO FOTOGRAFIE DI ARCHIVIO (Unsplash) che erano
     * gia' scritte nei template. Restano come ultima rete: una pagina senza
     * immagine si sfascia, e una foto generica e' meno grave di un buco. Il
     * pannello segnala con un avviso ogni posizione che sta ancora usando la
     * riserva, cosi' si vede subito quali immagini vanno sostituite davvero.
     */
    return array(
        'hero' => array(
            'etichetta' => __('Apertura della homepage', 'farmaciainternazionale-child-theme'),
            'dove'      => __('Homepage, la foto grande accanto al titolo.', 'farmaciainternazionale-child-theme'),
            'consiglio' => __('Verticale o quadrata, almeno 800 px di lato.', 'farmaciainternazionale-child-theme'),
            'origine'   => array('opzione' => 'ticinoweb_slider_image_1', 'theme_mod' => 'slider_image_1'),
            'riserva'   => 'https://images.unsplash.com/photo-1576602976047-174e57a47881?auto=format&fit=crop&q=80&w=800',
        ),
        'storia' => array(
            'etichetta' => __('La storia della farmacia', 'farmaciainternazionale-child-theme'),
            'dove'      => __('Homepage, sezione «Una storia di famiglia», e pagina Chi siamo.', 'farmaciainternazionale-child-theme'),
            'consiglio' => __('Verticale, almeno 800 px di lato.', 'farmaciainternazionale-child-theme'),
            'origine'   => array('opzione' => 'ticinoweb_chi_siamo_image'),
            'riserva'   => 'https://images.unsplash.com/photo-1576602976047-174e57a47881?auto=format&fit=crop&q=80&w=800',
        ),
        'benessere' => array(
            'etichetta' => __('Sezione benessere', 'farmaciainternazionale-child-theme'),
            'dove'      => __('Homepage, la foto della sezione dedicata al benessere.', 'farmaciainternazionale-child-theme'),
            'consiglio' => __('Orizzontale, almeno 1000 px di lato lungo.', 'farmaciainternazionale-child-theme'),
            'origine'   => array('galleria' => 5),
            'riserva'   => 'https://images.unsplash.com/photo-1611078443245-563d76206d9a?auto=format&fit=crop&q=80&w=800',
        ),
        'chisiamo_lato' => array(
            'etichetta' => __('Chi siamo — foto affiancata', 'farmaciainternazionale-child-theme'),
            'dove'      => __('Pagina Chi siamo, la foto nella parte centrale.', 'farmaciainternazionale-child-theme'),
            'consiglio' => __('Orizzontale, almeno 1000 px di lato lungo.', 'farmaciainternazionale-child-theme'),
            'origine'   => array('galleria' => 5),
            'riserva'   => 'https://images.unsplash.com/photo-1540420773420-3366772f4999?auto=format&fit=crop&q=80&w=800',
        ),
        'filigrana' => array(
            'etichetta' => __('Filigrana di sfondo', 'farmaciainternazionale-child-theme'),
            'dove'      => __('Homepage, il simbolo tenue che galleggia nella sezione del supporto sanitario.', 'farmaciainternazionale-child-theme'),
            'consiglio' => __('Meglio un PNG o un SVG con lo sfondo trasparente.', 'farmaciainternazionale-child-theme'),
            'origine'   => array('opzione' => 'ticinoweb_page_header_bg_image'),
            /* Nessuna riserva: se non c'e', la filigrana semplicemente non
               compare. E' una decorazione, e un'immagine di archivio al suo
               posto sarebbe soltanto rumore. */
            'riserva'   => '',
        ),
    );
}

/**
 * Le quattro schede di «I nostri reparti», come erano scritte nel tema.
 *
 * @return array
 */
function fi_reparti_predefiniti()
{
    return array(
        array('titolo' => 'Naturale & Bio', 'immagine' => 0, 'riserva' => 'https://images.unsplash.com/photo-1608222351212-18fe0ec7b13b?auto=format&fit=crop&q=80&w=600'),
        array('titolo' => 'Dermocosmesi', 'immagine' => 0, 'riserva' => 'https://images.unsplash.com/photo-1556228578-0d85b1a4d571?auto=format&fit=crop&q=80&w=600'),
        array('titolo' => 'Integrazione Sportiva', 'immagine' => 0, 'riserva' => 'https://images.unsplash.com/photo-1517836357463-d25dfeac3438?auto=format&fit=crop&q=80&w=600'),
        array('titolo' => 'Maternità', 'immagine' => 0, 'riserva' => 'https://images.unsplash.com/photo-1519689680058-324335c77eba?auto=format&fit=crop&q=80&w=600'),
    );
}

/**
 * ID dell'allegato scelto dal pannello per una posizione, se c'e'.
 *
 * @param string $chiave Chiave del registro.
 * @return int 0 se non e' stato scelto niente.
 */
function fi_immagine_id($chiave)
{
    $salvate = get_option(FI_IMMAGINI_OPZIONE, array());
    if (!is_array($salvate) || empty($salvate[$chiave])) {
        return 0;
    }

    return absint($salvate[$chiave]);
}

/**
 * Indirizzo dell'immagine di una posizione, cercandola dove serve.
 *
 * L'ordine e' quello che tiene il sito uguale a prima: prima la scelta fatta dal
 * pannello, poi la strada da cui l'immagine arrivava fino a ieri, e solo in
 * ultimo l'immagine di riserva.
 *
 * @param string $chiave     Chiave del registro.
 * @param string $dimensione Formato WordPress da restituire.
 * @return string Indirizzo, oppure stringa vuota.
 */
function fi_immagine($chiave, $dimensione = 'large')
{
    $registro = fi_immagini_registro();
    if (!isset($registro[$chiave])) {
        return '';
    }

    $voce = $registro[$chiave];

    /* 1. La scelta fatta dal pannello. */
    $id = fi_immagine_id($chiave);
    if ($id) {
        $url = wp_get_attachment_image_url($id, $dimensione);
        if ($url) {
            return $url;
        }
    }

    /* 2. Da dove l'immagine arrivava prima. */
    $origine = isset($voce['origine']) ? $voce['origine'] : array();

    if (!empty($origine['opzione'])) {
        $valore = get_option($origine['opzione'], '');
        $url = fi_immagine_da_valore($valore, $dimensione);
        if ('' !== $url) {
            return $url;
        }
    }

    if (!empty($origine['theme_mod'])) {
        $url = fi_immagine_da_valore(get_theme_mod($origine['theme_mod'], ''), $dimensione);
        if ('' !== $url) {
            return $url;
        }
    }

    if (!empty($origine['galleria'])) {
        $url = fi_immagine_da_galleria((int) $origine['galleria'], $dimensione);
        if ('' !== $url) {
            return $url;
        }
    }

    /* 3. L'immagine di riserva, se questa posizione ne ha una. */
    return isset($voce['riserva']) ? (string) $voce['riserva'] : '';
}

/**
 * Traduce in indirizzo un valore che puo' essere un ID o un indirizzo.
 *
 * Le opzioni del pannello del tema padre contengono a volte un numero e a volte
 * un indirizzo, a seconda di come e da quale versione sono state salvate.
 *
 * @param mixed  $valore     Valore grezzo.
 * @param string $dimensione Formato WordPress.
 * @return string
 */
function fi_immagine_da_valore($valore, $dimensione = 'large')
{
    if (is_numeric($valore) && (int) $valore > 0) {
        $url = wp_get_attachment_image_url((int) $valore, $dimensione);
        return $url ? $url : '';
    }

    $valore = trim((string) $valore);

    return '' !== $valore ? $valore : '';
}

/**
 * La prima immagine di una galleria della tassonomia del tema padre.
 *
 * @param int    $termine    ID del termine della galleria.
 * @param string $dimensione Formato WordPress.
 * @return string
 */
function fi_immagine_da_galleria($termine, $dimensione = 'large')
{
    if ($termine <= 0) {
        return '';
    }

    $trovate = get_posts(
        array(
            'post_type'      => 'attachment',
            'post_status'    => 'inherit',
            'posts_per_page' => 1,
            'fields'         => 'ids',
            'no_found_rows'  => true,
            'tax_query'      => array(
                array(
                    'taxonomy' => 'ticinoweb_media_gallery',
                    'field'    => 'term_id',
                    'terms'    => $termine,
                ),
            ),
        )
    );

    if (empty($trovate)) {
        return '';
    }

    $url = wp_get_attachment_image_url($trovate[0], $dimensione);

    return $url ? $url : '';
}

/**
 * Le quattro schede dei reparti, pronte da stampare.
 *
 * PERCHE' LE FOTO D'ARCHIVIO SPARISCONO AL PRIMO SALVATAGGIO: finche' nessuno
 * ha aperto il pannello, le schede sono quelle scritte nel tema, foto di
 * archivio comprese — il sito resta come oggi. Appena si salva, comandano le
 * schede del pannello: una scheda senza fotografia diventa un riquadro in tinta
 * col suo titolo, non riprende la foto di archivio.
 *
 * Legare le riserve alla posizione sarebbe stata la scelta sbagliata: bastava
 * cancellare la prima scheda perche' la seconda si ritrovasse addosso la foto
 * della prima.
 *
 * @return array Ogni voce ha 'titolo' e 'url' (l'indirizzo puo' essere vuoto).
 */
function fi_reparti()
{
    $salvati = get_option(FI_REPARTI_OPZIONE, null);

    if (null === $salvati) {
        $schede = array();
        foreach (fi_reparti_predefiniti() as $riga) {
            $schede[] = array('titolo' => $riga['titolo'], 'url' => $riga['riserva']);
        }
        return $schede;
    }

    $schede = array();

    foreach (fi_reparti_normalizza($salvati) as $riga) {
        $url = $riga['immagine']
            ? (string) wp_get_attachment_image_url($riga['immagine'], 'large')
            : '';

        $schede[] = array('titolo' => $riga['titolo'], 'url' => $url);
    }

    return $schede;
}

/**
 * Ripulisce le schede dei reparti.
 *
 * @param mixed $righe Dati grezzi.
 * @return array
 */
function fi_reparti_normalizza($righe)
{
    if (!is_array($righe)) {
        return array();
    }

    $puliti = array();

    foreach ($righe as $riga) {
        if (!is_array($riga)) {
            continue;
        }

        $titolo   = sanitize_text_field($riga['titolo'] ?? '');
        $immagine = absint($riga['immagine'] ?? 0);

        if ('' === $titolo && 0 === $immagine) {
            continue;
        }

        $puliti[] = array('titolo' => $titolo, 'immagine' => $immagine);
    }

    return $puliti;
}

/**
 * Ripulisce le immagini singole: solo chiavi del registro, solo numeri.
 *
 * @param mixed $input Dati inviati.
 * @return array
 */
function fi_immagini_sanifica($input)
{
    $registro = fi_immagini_registro();
    $puliti   = array();

    if (!is_array($input)) {
        return $puliti;
    }

    foreach ($input as $chiave => $id) {
        /* Si accettano solo le chiavi che il tema conosce: un nome inventato
           finirebbe nel database e non lo leggerebbe mai nessuno. */
        if (!isset($registro[$chiave])) {
            continue;
        }
        $id = absint($id);
        if ($id) {
            $puliti[$chiave] = $id;
        }
    }

    return $puliti;
}

add_action('admin_init', 'fi_immagini_registra_impostazioni');
function fi_immagini_registra_impostazioni()
{
    register_setting('fi_immagini_group', FI_IMMAGINI_OPZIONE, array('type' => 'array', 'sanitize_callback' => 'fi_immagini_sanifica'));
    register_setting('fi_immagini_group', FI_REPARTI_OPZIONE, array('type' => 'array', 'sanitize_callback' => 'fi_reparti_normalizza'));
}

add_action('admin_menu', 'fi_immagini_menu');
function fi_immagini_menu()
{
    add_menu_page(
        __('Immagini del sito', 'farmaciainternazionale-child-theme'),
        __('Immagini del sito', 'farmaciainternazionale-child-theme'),
        'manage_options',
        'fi-immagini',
        'fi_immagini_pagina',
        'dashicons-format-image',
        29
    );
}

add_action('admin_enqueue_scripts', 'fi_immagini_asset_admin');
function fi_immagini_asset_admin($hook)
{
    if ('toplevel_page_fi-immagini' !== $hook) {
        return;
    }

    /* Serve la Libreria media di WordPress: e' lo strumento che chi pubblica
       conosce gia', invece di un campo in cui incollare un indirizzo. */
    wp_enqueue_media();

    wp_enqueue_style('fi-admin-emergenze', get_stylesheet_directory_uri() . '/assets/css/admin-emergenze.css', array(), wp_get_theme()->get('Version'));
    wp_enqueue_style('fi-admin-immagini', get_stylesheet_directory_uri() . '/assets/css/admin-immagini.css', array('fi-admin-emergenze'), wp_get_theme()->get('Version'));
    wp_enqueue_script('fi-admin-immagini', get_stylesheet_directory_uri() . '/assets/js/admin-immagini.js', array('jquery'), wp_get_theme()->get('Version'), true);
}

/**
 * Un riquadro con l'anteprima, il pulsante di scelta e quello per tornare
 * all'immagine di prima.
 *
 * @param array $argomenti Chiavi: nome, id, url, riserva.
 * @return void
 */
function fi_immagini_riquadro($argomenti)
{
    $id      = absint($argomenti['id'] ?? 0);
    $url     = (string) ($argomenti['url'] ?? '');
    $riserva = !empty($argomenti['riserva']);
    ?>
    <div class="fi-im-riquadro" data-fi-media>
        <input type="hidden" name="<?php echo esc_attr($argomenti['nome']); ?>" value="<?php echo esc_attr($id ? $id : ''); ?>" data-fi-media-valore>

        <div class="fi-im-anteprima" data-fi-media-anteprima>
            <?php if ('' !== $url) : ?>
                <img src="<?php echo esc_url($url); ?>" alt="">
            <?php else : ?>
                <span class="dashicons dashicons-format-image" aria-hidden="true"></span>
            <?php endif; ?>
        </div>

        <div class="fi-im-comandi">
            <button type="button" class="button fi-im-scegli" data-fi-media-scegli>
                <?php echo $id ? esc_html__('Cambia', 'farmaciainternazionale-child-theme') : esc_html__('Scegli dalla Libreria media', 'farmaciainternazionale-child-theme'); ?>
            </button>
            <button type="button" class="button-link-delete fi-im-svuota" data-fi-media-svuota <?php disabled(0, $id); ?>>
                <?php esc_html_e('Torna all’immagine di prima', 'farmaciainternazionale-child-theme'); ?>
            </button>
        </div>

        <?php if ($riserva) : ?>
            <p class="fi-im-avviso" data-fi-media-avviso>
                <span class="dashicons dashicons-warning" aria-hidden="true"></span>
                <?php esc_html_e('Sta usando una fotografia d’archivio, non della farmacia. Vale la pena sostituirla.', 'farmaciainternazionale-child-theme'); ?>
            </p>
        <?php endif; ?>
    </div>
    <?php
}

/**
 * La pagina di amministrazione.
 */
function fi_immagini_pagina()
{
    if (!current_user_can('manage_options')) {
        wp_die(esc_html__('Non sei autorizzato ad accedere a questa pagina.', 'farmaciainternazionale-child-theme'));
    }

    $registro = fi_immagini_registro();

    $salvati_reparti = get_option(FI_REPARTI_OPZIONE, null);
    $reparti_mai_salvati = (null === $salvati_reparti);
    $reparti = $reparti_mai_salvati ? fi_reparti_predefiniti() : fi_reparti_normalizza($salvati_reparti);

    /*
     * IL PANNELLO MOSTRA SEMPRE QUATTRO SCHEDE, anche se ne sono state salvate
     * meno. Le schede vuote non finiscono nel database e non compaiono sul sito,
     * ma senza queste righe in bianco chi ne svuota una non avrebbe piu' modo di
     * riempirla: la fascia della homepage e' una griglia da quattro, non un
     * elenco che si allunga, quindi non serve un pulsante «aggiungi» — serve che
     * i quattro posti siano sempre visibili.
     */
    for ($i = count($reparti); $i < 4; $i++) {
        $reparti[$i] = array('titolo' => '', 'immagine' => 0);
    }

    /* Quante posizioni stanno ancora mostrando una foto d'archivio. */
    $da_sostituire = 0;
    foreach ($registro as $chiave => $voce) {
        if (!empty($voce['riserva']) && fi_immagine($chiave) === $voce['riserva']) {
            $da_sostituire++;
        }
    }
    ?>
    <div class="wrap fi-em-admin fi-im-admin">
        <header class="fi-em-admin-hero">
            <div class="fi-em-admin-title">
                <span class="dashicons dashicons-format-image" aria-hidden="true"></span>
                <div>
                    <h1><?php esc_html_e('Immagini del sito', 'farmaciainternazionale-child-theme'); ?></h1>
                    <p><?php esc_html_e('Tutte le immagini fisse del tema, in un posto solo.', 'farmaciainternazionale-child-theme'); ?></p>
                </div>
            </div>
            <div class="fi-em-admin-badges">
                <span><?php echo esc_html(sprintf(_n('%d posizione', '%d posizioni', count($registro), 'farmaciainternazionale-child-theme'), count($registro))); ?></span>
                <?php if ($da_sostituire) : ?>
                    <span><?php echo esc_html(sprintf(_n('%d foto d’archivio da sostituire', '%d foto d’archivio da sostituire', $da_sostituire, 'farmaciainternazionale-child-theme'), $da_sostituire)); ?></span>
                <?php else : ?>
                    <span class="is-green"><?php esc_html_e('Nessuna foto d’archivio', 'farmaciainternazionale-child-theme'); ?></span>
                <?php endif; ?>
            </div>
        </header>

        <?php settings_errors(); ?>
        <?php if (isset($_GET['settings-updated']) && 'true' === sanitize_key(wp_unslash($_GET['settings-updated']))) : ?>
            <div class="fi-em-saved" role="status"><span class="dashicons dashicons-yes-alt" aria-hidden="true"></span><?php esc_html_e('Immagini salvate.', 'farmaciainternazionale-child-theme'); ?></div>
        <?php endif; ?>

        <div class="fi-em-admin-info">
            <span class="dashicons dashicons-info-outline" aria-hidden="true"></span>
            <div>
                <strong><?php esc_html_e('Le gallerie che scorrono si gestiscono altrove', 'farmaciainternazionale-child-theme'); ?></strong>
                <p>
                    <?php esc_html_e('Qui ci sono le immagini singole. Le raccolte di foto che scorrono sulla homepage e nella pagina Chi siamo si compongono dalla Libreria media, assegnando le foto a una galleria.', 'farmaciainternazionale-child-theme'); ?>
                    <a href="<?php echo esc_url(admin_url('upload.php')); ?>"><?php esc_html_e('Apri la Libreria media', 'farmaciainternazionale-child-theme'); ?></a>
                </p>
            </div>
        </div>

        <form method="post" action="options.php" id="fi_immagini_form">
            <?php settings_fields('fi_immagini_group'); ?>

            <section class="fi-em-admin-section">
                <div class="fi-em-section-heading">
                    <div>
                        <h2><?php esc_html_e('Immagini delle pagine', 'farmaciainternazionale-child-theme'); ?></h2>
                        <p><?php esc_html_e('Ogni riquadro dice in che pagina e in che punto compare l’immagine.', 'farmaciainternazionale-child-theme'); ?></p>
                    </div>
                </div>

                <div class="fi-im-griglia">
                    <?php foreach ($registro as $chiave => $voce) : ?>
                        <?php
                        $id  = fi_immagine_id($chiave);
                        $url = fi_immagine($chiave, 'medium');
                        ?>
                        <article class="fi-im-scheda">
                            <h3><?php echo esc_html($voce['etichetta']); ?></h3>
                            <p class="fi-im-dove"><?php echo esc_html($voce['dove']); ?></p>
                            <?php
                            fi_immagini_riquadro(
                                array(
                                    'nome'    => FI_IMMAGINI_OPZIONE . '[' . $chiave . ']',
                                    'id'      => $id,
                                    'url'     => $url,
                                    'riserva' => !empty($voce['riserva']) && $url === $voce['riserva'],
                                )
                            );
                            ?>
                            <p class="fi-im-consiglio"><?php echo esc_html($voce['consiglio']); ?></p>
                        </article>
                    <?php endforeach; ?>
                </div>
            </section>

            <section class="fi-em-admin-section">
                <div class="fi-em-section-heading">
                    <div>
                        <h2><?php esc_html_e('I nostri reparti', 'farmaciainternazionale-child-theme'); ?></h2>
                        <p><?php esc_html_e('Le quattro schede in fondo alla homepage: titolo e fotografia.', 'farmaciainternazionale-child-theme'); ?></p>
                    </div>
                </div>

                <div class="fi-im-griglia">
                    <?php foreach ($reparti as $i => $reparto) : ?>
                        <?php
                        $id_rep  = absint($reparto['immagine'] ?? 0);
                        $url_rep = $id_rep ? (string) wp_get_attachment_image_url($id_rep, 'medium') : '';
                        /* La foto d'archivio si mostra solo finche' il pannello
                           non e' mai stato salvato: dopo, il sito non la usa
                           piu' e farla vedere qui sarebbe una bugia. */
                        $riserva_rep = ('' === $url_rep && $reparti_mai_salvati && isset($reparto['riserva']))
                            ? $reparto['riserva']
                            : '';
                        ?>
                        <article class="fi-im-scheda">
                            <div class="fi-em-field">
                                <label for="fi_rep_<?php echo esc_attr($i); ?>"><?php esc_html_e('Titolo della scheda', 'farmaciainternazionale-child-theme'); ?></label>
                                <input id="fi_rep_<?php echo esc_attr($i); ?>" type="text" name="<?php echo esc_attr(FI_REPARTI_OPZIONE); ?>[<?php echo esc_attr($i); ?>][titolo]" value="<?php echo esc_attr($reparto['titolo'] ?? ''); ?>">
                            </div>
                            <?php
                            fi_immagini_riquadro(
                                array(
                                    'nome'    => FI_REPARTI_OPZIONE . '[' . $i . '][immagine]',
                                    'id'      => $id_rep,
                                    'url'     => '' !== $url_rep ? $url_rep : $riserva_rep,
                                    'riserva' => '' !== $riserva_rep,
                                )
                            );
                            ?>
                        </article>
                    <?php endforeach; ?>
                </div>
                <p class="fi-im-nota"><?php esc_html_e('Una scheda senza titolo e senza fotografia non compare sulla homepage. Una scheda col titolo ma senza fotografia diventa un riquadro in tinta.', 'farmaciainternazionale-child-theme'); ?></p>
            </section>

            <div class="fi-em-savebar">
                <div>
                    <strong><?php esc_html_e('Fatto?', 'farmaciainternazionale-child-theme'); ?></strong>
                    <span><?php esc_html_e('Salva per aggiornare subito il sito.', 'farmaciainternazionale-child-theme'); ?></span>
                </div>
                <?php submit_button(__('Salva immagini', 'farmaciainternazionale-child-theme'), 'primary fi-em-save-button', 'submit', false); ?>
            </div>
        </form>
    </div>
    <?php
}
