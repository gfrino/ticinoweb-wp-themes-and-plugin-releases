<?php

/**
 * PAGINA «INFORMATIVA SULLA PRIVACY».
 *
 * Crea la pagina una volta sola, le assegna il template privacy.php e la
 * registra come informativa ufficiale del sito.
 *
 * PERCHE' REGISTRARLA COME INFORMATIVA UFFICIALE E NON SOLO CREARLA: WordPress
 * ha un suo concetto di pagina della privacy (`wp_page_for_privacy_policy`) e
 * get_privacy_policy_url() legge da li'. Quella funzione la chiama gia'
 * invio-ricette.php per il collegamento accanto alla casella di consenso: finche'
 * l'informativa non era registrata, il modulo chiedeva di acconsentire al
 * trattamento dei dati senza poter mostrare a che cosa. Registrandola, quel
 * collegamento compare da solo.
 *
 * PERCHE' IL TESTO STA NEL TEMPLATE E NON NEL CONTENUTO DELLA PAGINA: questo
 * sito e' stato migrato tre volte e ogni volta il database e' stato sovrascritto.
 * Un'informativa che vive nel contenuto di una pagina si perde in un import; nel
 * tema viaggia con Git e con lo zip. La pagina resta un guscio vuoto, e i dati
 * che cambiano — indirizzo, telefono, email — il template li legge dal CMS.
 *
 * @package farmaciainternazionale-child-theme
 */

if (!defined('ABSPATH')) {
    exit;
}

add_action('admin_init', 'fi_privacy_prepara_pagina');
/**
 * Crea la pagina, le assegna il template e la dichiara informativa del sito.
 */
function fi_privacy_prepara_pagina()
{
    if (!current_user_can('manage_options')) {
        return;
    }

    $segnata = absint(get_option('fi_privacy_page_provisioned', 0));

    /* Se la pagina segnata e' stata cancellata o messa nel cestino si riparte:
       senza questo controllo, cancellarla per sbaglio la farebbe sparire per
       sempre e il modulo ricette tornerebbe senza collegamento. */
    if ($segnata && 'page' === get_post_type($segnata) && 'publish' === get_post_status($segnata)) {
        fi_privacy_dichiara_ufficiale($segnata);
        return;
    }

    /* Si riusa una pagina con lo stesso slug se esiste gia': meglio adottarla che
       ritrovarsi due informative con indirizzi diversi. */
    $esistente = get_page_by_path('privacy', OBJECT, 'page');

    if ($esistente) {
        $id = $esistente->ID;
    } else {
        $id = wp_insert_post(
            array(
                'post_title'   => 'Informativa sulla privacy',
                'post_name'    => 'privacy',
                'post_status'  => 'publish',
                'post_type'    => 'page',
                'post_content' => '',
                /* Fuori dai menu e dalla ricerca interna: si raggiunge dal footer
                   e dal modulo, non e' una pagina da promuovere. */
                'menu_order'   => 100,
            ),
            true
        );
    }

    if (is_wp_error($id) || !$id) {
        return;
    }

    update_post_meta($id, '_wp_page_template', 'privacy.php');
    update_option('fi_privacy_page_provisioned', absint($id), false);

    fi_privacy_dichiara_ufficiale($id);
}

/**
 * Dichiara la pagina come informativa privacy del sito, se nessun'altra lo e'.
 *
 * Non si sovrascrive una scelta fatta a mano: se qualcuno ha indicato un'altra
 * pagina in Impostazioni → Privacy, quella resta.
 *
 * @param int $id ID della pagina.
 * @return void
 */
function fi_privacy_dichiara_ufficiale($id)
{
    $attuale = absint(get_option('wp_page_for_privacy_policy', 0));

    if ($attuale && 'page' === get_post_type($attuale) && 'trash' !== get_post_status($attuale)) {
        return;
    }

    update_option('wp_page_for_privacy_policy', absint($id));
}

/**
 * Indirizzo dell'informativa, con un ripiego che non lascia mai un link morto.
 *
 * get_privacy_policy_url() restituisce vuoto se la pagina non e' pubblicata; in
 * quel caso si prova lo slug, e solo se manca anche quello si restituisce vuoto —
 * chi stampa il collegamento deve poter decidere di non stamparlo.
 *
 * @return string
 */
function fi_privacy_url()
{
    $url = get_privacy_policy_url();
    if ('' !== $url) {
        return $url;
    }

    $pagina = get_page_by_path('privacy', OBJECT, 'page');

    return ($pagina && 'publish' === $pagina->post_status) ? (string) get_permalink($pagina) : '';
}
