<?php

/**
 * PANNELLO DI AMMINISTRAZIONE DELLA PASTIGLIA «COME POSSIAMO AIUTARTI».
 *
 * Qui si aggiungono, si togliono, si riordinano e si riscrivono gli argomenti
 * che compaiono nella pastiglia in basso a destra del sito. La pastiglia stessa
 * e' in inc/aiuto.php: questo file si occupa soltanto dei dati.
 *
 * COME CONVIVONO I TESTI SCRITTI NEL TEMA E QUELLI SALVATI DAL PANNELLO: gli
 * otto argomenti di partenza restano scritti nel codice, in
 * fi_aiuto_argomenti_predefiniti(). Finche' nessuno salva dal pannello,
 * l'opzione nel database non esiste e il sito mostra quelli. Al primo
 * salvataggio l'opzione nasce e da quel momento comanda lei.
 *
 * Questo doppio binario non e' un'esitazione: significa che aggiornare il tema
 * non sovrascrive mai il lavoro fatto dal pannello, e che un sito appena
 * installato ha comunque contenuti sensati senza dover compilare nulla.
 *
 * @package farmaciainternazionale-child-theme
 */

if (!defined('ABSPATH')) {
    exit;
}

/** Nome dell'opzione che contiene l'elenco degli argomenti. */
define('FI_AIUTO_OPZIONE', 'fi_aiuto_voci');

/**
 * Gli argomenti di partenza, scritti nel tema.
 *
 * Campi:
 *   attivo    0 nasconde l'argomento senza cancellarlo
 *   emoji     il simbolo mostrato accanto alla voce
 *   voce      il testo del pulsante nell'elenco
 *   titolo    l'intestazione della risposta
 *   testo     la risposta: cosa fa concretamente la farmacia
 *   nota      riga in evidenza, opzionale
 *   contatto  'email' apre un'email con l'oggetto precompilato,
 *             'telefono' propone solo la telefonata e la visita di persona
 *   pulsante  scritta del pulsante principale; vuoto = quella predefinita
 *
 * @return array
 */
function fi_aiuto_argomenti_predefiniti()
{
    return array(
        /*
         * LA ZECCA STA PER PRIMA, ed e' una scelta: e' l'unica voce dell'elenco
         * che riguarda adesso. Tutte le altre sono consulenze che si pianificano
         * — smettere di fumare, preparare un viaggio, rivedere una terapia — e
         * chi le cerca ha tempo di scorrere. Chi ha una zecca attaccata addosso
         * no. Dal pannello si sposta con una freccia, se si preferisce altrove.
         *
         * IL CONTATTO E' IL TELEFONO E NON L'EMAIL per la stessa ragione: qui la
         * cosa utile e' venire in farmacia subito, non scrivere e aspettare una
         * risposta.
         */
        array(
            'attivo' => 1,
            'emoji' => '🕷️',
            'voce' => 'Devo togliere una zecca',
            'titolo' => 'Rimozione di una zecca',
            'testo' => 'Passa in farmacia: la togliamo noi con la pinzetta adatta, afferrandola vicino alla pelle e sfilandola intera. Nell’attesa non metterci olio, alcol o creme e non schiacciarla: irritarla aumenta il rischio che rilasci quello che ha dentro. Dopo la rimozione disinfettiamo, ti segniamo la data e ti spieghiamo che cosa tenere d’occhio nelle settimane successive.',
            'nota' => 'Rivolgiti al medico se intorno al morso compare un arrossamento che si allarga nei giorni o nelle settimane dopo, oppure se arrivano febbre, mal di testa o dolori alle articolazioni.',
            'contatto' => 'telefono',
            'pulsante' => '',
        ),
        array(
            'attivo' => 1,
            'emoji' => '🫁',
            'voce' => 'Vorrei smettere di fumare',
            'titolo' => 'Smettere di fumare',
            'testo' => 'Smettere da soli è difficile, con un accompagnamento è un’altra cosa. Valutiamo insieme quanto è forte la dipendenza, ti spieghiamo le possibilità disponibili — dai sostituti della nicotina ai percorsi da concordare con il medico — e restiamo a disposizione nelle settimane in cui la motivazione cala.',
            'nota' => '',
            'contatto' => 'email',
            'pulsante' => '',
        ),
        array(
            'attivo' => 1,
            'emoji' => '❤️',
            'voce' => 'Vorrei prevenire problemi cardiovascolari',
            'titolo' => 'Prevenzione cardiovascolare',
            'testo' => 'Pressione, colesterolo e glicemia raccontano molto prima che compaia un sintomo. In farmacia possiamo misurarli, spiegarti che cosa significano i valori che leggi e dirti quando vale la pena parlarne con il tuo medico.',
            'nota' => '',
            'contatto' => 'email',
            'pulsante' => '',
        ),
        array(
            'attivo' => 1,
            'emoji' => '👩',
            'voce' => 'Ho bisogno di aiuto o supporto',
            'titolo' => 'Aiuto e supporto',
            'testo' => 'Puoi parlarne con noi in riservatezza, anche solo per capire a chi rivolgerti. Ti aiutiamo a orientarti fra i servizi del territorio, con i tuoi tempi e senza che tu debba spiegare più di quanto vuoi.',
            /*
             * QUESTA VOCE NON PROPONE L'EMAIL, ed e' una scelta di sicurezza, non
             * una dimenticanza: un messaggio con un oggetto esplicito resta nella
             * posta inviata di chi scrive, e su un telefono condiviso o
             * controllato puo' metterla in pericolo. Restano la telefonata e la
             * visita di persona, che non lasciano tracce scritte.
             *
             * Dal pannello si puo' cambiare, ma nel campo c'e' un avviso che
             * spiega perche' conviene lasciare «solo telefono».
             */
            'nota' => 'Se sei in pericolo immediato chiama il 117. Per parlare con qualcuno subito, a qualsiasi ora, c’è il 143 — Telefono Amico.',
            'contatto' => 'telefono',
            'pulsante' => '',
        ),
        array(
            'attivo' => 1,
            'emoji' => '✈️',
            'voce' => 'Sto preparando un viaggio',
            'titolo' => 'Medicina di viaggio',
            'testo' => 'Vaccinazioni, profilassi antimalarica, che farmaci mettere in valigia e come conservarli: ne parliamo prima che tu parta. Meglio muoversi qualche settimana in anticipo, perché certe vaccinazioni richiedono più dosi a distanza di tempo.',
            'nota' => '',
            'contatto' => 'email',
            'pulsante' => '',
        ),
        array(
            'attivo' => 1,
            'emoji' => '💊',
            'voce' => 'Vorrei rivedere la mia terapia',
            'titolo' => 'Revisione della terapia',
            'testo' => 'Quando i farmaci sono diversi può capitare che si sovrappongano o si ostacolino a vicenda. Portaci l’elenco completo, comprese le cose che prendi da te — integratori, tisane, prodotti da banco — e controlliamo le interazioni, parlandone con il tuo medico se serve.',
            'nota' => '',
            'contatto' => 'email',
            'pulsante' => '',
        ),
        array(
            'attivo' => 1,
            'emoji' => '🥗',
            'voce' => 'Vorrei migliorare alimentazione e benessere',
            'titolo' => 'Alimentazione e benessere',
            'testo' => 'Non serve una dieta drastica per stare meglio. Partiamo da come mangi davvero, guardiamo se ci sono carenze e ragioniamo su cambiamenti che riesci a mantenere, con l’integrazione soltanto dove ha senso.',
            'nota' => '',
            'contatto' => 'email',
            'pulsante' => '',
        ),
        array(
            'attivo' => 1,
            'emoji' => '👴',
            'voce' => 'Mi prendo cura di un familiare',
            'titolo' => 'Assistenza a un familiare',
            'testo' => 'Assistere una persona cara pesa, anche quando lo si fa volentieri. Possiamo semplificarti la gestione dei farmaci, procurarti materiale sanitario e presidi, e indicarti i servizi di appoggio che esistono a Locarno e dintorni.',
            'nota' => '',
            'contatto' => 'email',
            'pulsante' => '',
        ),
        array(
            'attivo' => 1,
            'emoji' => '🤰',
            'voce' => 'Gravidanza e allattamento',
            'titolo' => 'Gravidanza e allattamento',
            'testo' => 'In gravidanza e durante l’allattamento non tutto è compatibile, ma molte più cose di quanto si creda lo sono. Verifichiamo insieme che cosa puoi assumere in sicurezza, dagli integratori ai rimedi per i disturbi più comuni.',
            'nota' => '',
            'contatto' => 'email',
            'pulsante' => '',
        ),
    );
}

/**
 * Scritta predefinita del pulsante principale, secondo il modo di contatto.
 *
 * Sta in una funzione sola perche' la usano sia il sito sia il segnaposto del
 * campo nel pannello: cambiandola qui cambia in entrambi i posti, e chi guarda
 * il campo vuoto legge esattamente quel che comparira' sul sito.
 *
 * @param string $contatto 'email' oppure 'telefono'.
 * @param string $telefono Numero da includere nella scritta della telefonata.
 * @return string
 */
function fi_aiuto_pulsante_predefinito($contatto, $telefono = '')
{
    if ('telefono' !== $contatto) {
        return __('Contattaci per maggiori informazioni', 'farmaciainternazionale-child-theme');
    }

    $telefono = trim((string) $telefono);
    if ('' === $telefono) {
        $telefono = trim((string) get_option('ticinoweb_contact_phone', ''));
    }

    /* translators: %s e' il numero di telefono della farmacia. */
    return '' !== $telefono
        ? sprintf(__('Chiama %s', 'farmaciainternazionale-child-theme'), $telefono)
        : __('Chiamaci', 'farmaciainternazionale-child-theme');
}

/**
 * Rimette in ordine e ripulisce i dati, da qualunque parte arrivino.
 *
 * La stessa funzione serve per i dati salvati nel database e per quelli appena
 * inviati dal modulo: cosi' il sito e il pannello non possono mai divergere su
 * cosa sia un argomento valido.
 *
 * @param mixed $righe Dati grezzi.
 * @return array
 */
function fi_aiuto_normalizza($righe)
{
    if (!is_array($righe)) {
        return array();
    }

    $puliti = array();

    foreach ($righe as $riga) {
        if (!is_array($riga)) {
            continue;
        }

        $voce  = sanitize_text_field($riga['voce'] ?? '');
        $testo = sanitize_textarea_field($riga['testo'] ?? '');

        /* Una riga senza domanda ne' risposta e' una riga aggiunta per sbaglio e
           poi lasciata vuota: si butta, invece di stampare un pulsante muto. */
        if ('' === $voce && '' === $testo) {
            continue;
        }

        $contatto = ($riga['contatto'] ?? '') === 'telefono' ? 'telefono' : 'email';

        /* L'emoji si taglia a otto caratteri: alcune sono composte da piu' pezzi
           (👩‍⚕️ ne conta quattro), ma oltre quella soglia si tratta di testo
           incollato per errore e sfonderebbe l'impaginazione della voce. */
        $emoji = trim(sanitize_text_field($riga['emoji'] ?? ''));
        if (function_exists('mb_substr')) {
            $emoji = mb_substr($emoji, 0, 8);
        }

        $titolo = sanitize_text_field($riga['titolo'] ?? '');

        $puliti[] = array(
            /* L'assenza della casella nel modulo inviato significa «spenta»:
               un checkbox non selezionato non viene inviato dal browser. */
            'attivo'   => empty($riga['attivo']) ? 0 : 1,
            'emoji'    => $emoji,
            'voce'     => $voce,
            /* Senza titolo si riusa la voce: e' sempre meglio di un'intestazione
               vuota, e chi non compila il campo probabilmente voleva quello. */
            'titolo'   => '' !== $titolo ? $titolo : $voce,
            'testo'    => $testo,
            'nota'     => sanitize_text_field($riga['nota'] ?? ''),
            'contatto' => $contatto,
            'pulsante' => sanitize_text_field($riga['pulsante'] ?? ''),
        );
    }

    return $puliti;
}

/**
 * Ripulisce i dati in arrivo dal modulo.
 *
 * @param mixed $input Dati inviati.
 * @return array
 */
function fi_aiuto_sanifica($input)
{
    return fi_aiuto_normalizza(wp_unslash($input));
}

add_action('admin_init', 'fi_aiuto_registra_impostazioni');
function fi_aiuto_registra_impostazioni()
{
    register_setting(
        'fi_aiuto_group',
        FI_AIUTO_OPZIONE,
        array('type' => 'array', 'sanitize_callback' => 'fi_aiuto_sanifica')
    );
    register_setting(
        'fi_aiuto_group',
        'fi_aiuto_pastiglia_emoji',
        array('type' => 'string', 'sanitize_callback' => 'sanitize_text_field')
    );
    register_setting(
        'fi_aiuto_group',
        'fi_aiuto_pastiglia_testo',
        array('type' => 'string', 'sanitize_callback' => 'sanitize_text_field')
    );
    register_setting(
        'fi_aiuto_group',
        'fi_aiuto_pannello_titolo',
        array('type' => 'string', 'sanitize_callback' => 'sanitize_text_field')
    );
}

add_action('admin_menu', 'fi_aiuto_menu');
function fi_aiuto_menu()
{
    add_menu_page(
        __('Badge Aiuto', 'farmaciainternazionale-child-theme'),
        __('Badge Aiuto', 'farmaciainternazionale-child-theme'),
        'manage_options',
        'fi-aiuto',
        'fi_aiuto_pagina',
        'dashicons-editor-help',
        31
    );
}

add_action('admin_enqueue_scripts', 'fi_aiuto_asset_admin');
function fi_aiuto_asset_admin($hook)
{
    if ('toplevel_page_fi-aiuto' !== $hook) {
        return;
    }

    /*
     * SI RIUSA IL FOGLIO DI STILE DEL PANNELLO EMERGENZE, di proposito. Le due
     * pagine hanno la stessa impalcatura — intestazione, sezioni, righe con i
     * campi, barra di salvataggio appiccicata in basso — e riscriverla
     * significherebbe mantenere due volte lo stesso aspetto. Da qui i nomi di
     * classe `fi-em-*` anche su questa pagina: leggeteli come «pannello del
     * tema», non come «pannello emergenze».
     */
    wp_enqueue_style('fi-admin-emergenze', get_stylesheet_directory_uri() . '/assets/css/admin-emergenze.css', array(), wp_get_theme()->get('Version'));
    wp_enqueue_style('fi-admin-aiuto', get_stylesheet_directory_uri() . '/assets/css/admin-aiuto.css', array('fi-admin-emergenze'), wp_get_theme()->get('Version'));
    wp_enqueue_script('fi-admin-aiuto', get_stylesheet_directory_uri() . '/assets/js/admin-aiuto.js', array(), wp_get_theme()->get('Version'), true);
}

/**
 * Stampa i campi di un argomento.
 *
 * Sta in una funzione perche' lo stesso blocco serve due volte: per le righe
 * esistenti e per il modello nascosto da cui il JavaScript copia le righe nuove.
 * Duplicarlo a mano vorrebbe dire che prima o poi le due copie si differenziano.
 *
 * @param array $a       Argomento gia' normalizzato.
 * @param mixed $indice  Numero della riga, o '__i__' nel modello.
 * @return void
 */
function fi_aiuto_campi_riga($a, $indice)
{
    $n = FI_AIUTO_OPZIONE . '[' . $indice . ']';
    ?>
    <article class="fi-em-main-item fi-ai-item">
        <div class="fi-em-item-top">
            <span class="fi-em-order-badge fi-ai-numero"></span>
            <strong class="fi-em-item-title fi-ai-titolo-vivo"><?php echo esc_html('' !== $a['voce'] ? $a['voce'] : __('Nuova domanda', 'farmaciainternazionale-child-theme')); ?></strong>

            <label class="fi-em-active-toggle">
                <input type="checkbox" data-field="attivo" name="<?php echo esc_attr($n); ?>[attivo]" value="1" <?php checked(1, $a['attivo']); ?>>
                <span aria-hidden="true"></span>
                <em><?php esc_html_e('Attiva', 'farmaciainternazionale-child-theme'); ?></em>
            </label>

            <span class="fi-ai-ordine">
                <button type="button" class="fi-em-icon-button fi-ai-su" aria-label="<?php esc_attr_e('Sposta in alto', 'farmaciainternazionale-child-theme'); ?>"><span class="dashicons dashicons-arrow-up-alt2" aria-hidden="true"></span></button>
                <button type="button" class="fi-em-icon-button fi-ai-giu" aria-label="<?php esc_attr_e('Sposta in basso', 'farmaciainternazionale-child-theme'); ?>"><span class="dashicons dashicons-arrow-down-alt2" aria-hidden="true"></span></button>
            </span>

            <button type="button" class="fi-em-icon-button fi-ai-togli" aria-label="<?php esc_attr_e('Rimuovi questa domanda', 'farmaciainternazionale-child-theme'); ?>"><span class="dashicons dashicons-trash" aria-hidden="true"></span></button>
        </div>

        <div class="fi-ai-griglia">
            <div class="fi-em-field fi-ai-emoji">
                <label><?php esc_html_e('Emoji', 'farmaciainternazionale-child-theme'); ?></label>
                <input type="text" data-field="emoji" name="<?php echo esc_attr($n); ?>[emoji]" value="<?php echo esc_attr($a['emoji']); ?>" placeholder="❤️" maxlength="24">
                <small><?php esc_html_e('Sul Mac: Control + Comando + Spazio.', 'farmaciainternazionale-child-theme'); ?></small>
            </div>

            <div class="fi-em-field fi-ai-voce">
                <label><?php esc_html_e('Domanda — come si legge nell’elenco', 'farmaciainternazionale-child-theme'); ?></label>
                <input type="text" data-field="voce" name="<?php echo esc_attr($n); ?>[voce]" value="<?php echo esc_attr($a['voce']); ?>" placeholder="<?php esc_attr_e('Vorrei smettere di fumare', 'farmaciainternazionale-child-theme'); ?>">
            </div>

            <div class="fi-em-field fi-ai-titolo">
                <label><?php esc_html_e('Titolo della risposta', 'farmaciainternazionale-child-theme'); ?> <span><?php esc_html_e('(vuoto: usa la domanda)', 'farmaciainternazionale-child-theme'); ?></span></label>
                <input type="text" data-field="titolo" name="<?php echo esc_attr($n); ?>[titolo]" value="<?php echo esc_attr($a['titolo']); ?>" placeholder="<?php esc_attr_e('Smettere di fumare', 'farmaciainternazionale-child-theme'); ?>">
            </div>

            <div class="fi-em-field fi-ai-testo">
                <label><?php esc_html_e('Risposta', 'farmaciainternazionale-child-theme'); ?></label>
                <textarea data-field="testo" name="<?php echo esc_attr($n); ?>[testo]" rows="4" placeholder="<?php esc_attr_e('Che cosa fa concretamente la farmacia per questa persona.', 'farmaciainternazionale-child-theme'); ?>"><?php echo esc_textarea($a['testo']); ?></textarea>
                <small><?php esc_html_e('Solo testo: eventuale HTML viene rimosso.', 'farmaciainternazionale-child-theme'); ?></small>
            </div>

            <div class="fi-em-field fi-ai-nota">
                <label><?php esc_html_e('Riga in evidenza', 'farmaciainternazionale-child-theme'); ?> <span><?php esc_html_e('(opzionale)', 'farmaciainternazionale-child-theme'); ?></span></label>
                <input type="text" data-field="nota" name="<?php echo esc_attr($n); ?>[nota]" value="<?php echo esc_attr($a['nota']); ?>" placeholder="<?php esc_attr_e('Numeri utili, avvertenze, tempi da rispettare…', 'farmaciainternazionale-child-theme'); ?>">
            </div>

            <div class="fi-em-field fi-ai-contatto">
                <label><?php esc_html_e('Come proseguire', 'farmaciainternazionale-child-theme'); ?></label>
                <select data-field="contatto" name="<?php echo esc_attr($n); ?>[contatto]">
                    <option value="email" <?php selected($a['contatto'], 'email'); ?>><?php esc_html_e('Email + telefono', 'farmaciainternazionale-child-theme'); ?></option>
                    <option value="telefono" <?php selected($a['contatto'], 'telefono'); ?>><?php esc_html_e('Solo telefono (argomenti delicati)', 'farmaciainternazionale-child-theme'); ?></option>
                </select>
                <small><?php esc_html_e('Per argomenti delicati scegli «solo telefono»: un’email resta scritta nella posta inviata di chi la manda, anche su un telefono condiviso.', 'farmaciainternazionale-child-theme'); ?></small>
            </div>

            <div class="fi-em-field fi-ai-pulsante">
                <label><?php esc_html_e('Scritta del pulsante', 'farmaciainternazionale-child-theme'); ?> <span><?php esc_html_e('(vuoto: quella predefinita)', 'farmaciainternazionale-child-theme'); ?></span></label>
                <input type="text" data-field="pulsante" name="<?php echo esc_attr($n); ?>[pulsante]" value="<?php echo esc_attr($a['pulsante']); ?>" placeholder="<?php echo esc_attr(fi_aiuto_pulsante_predefinito($a['contatto'])); ?>">
            </div>
        </div>
    </article>
    <?php
}

/**
 * La pagina di amministrazione.
 */
function fi_aiuto_pagina()
{
    if (!current_user_can('manage_options')) {
        wp_die(esc_html__('Non sei autorizzato ad accedere a questa pagina.', 'farmaciainternazionale-child-theme'));
    }

    $salvati   = get_option(FI_AIUTO_OPZIONE, null);
    $argomenti = fi_aiuto_normalizza(null === $salvati ? fi_aiuto_argomenti_predefiniti() : $salvati);

    $attive = 0;
    foreach ($argomenti as $a) {
        if ($a['attivo']) {
            $attive++;
        }
    }

    /* La riga vuota del modello: gli stessi campi, senza contenuto. */
    $vuota = array(
        'attivo' => 1, 'emoji' => '', 'voce' => '', 'titolo' => '',
        'testo' => '', 'nota' => '', 'contatto' => 'email', 'pulsante' => '',
    );
    ?>
    <div class="wrap fi-em-admin fi-ai-admin">
        <header class="fi-em-admin-hero">
            <div class="fi-em-admin-title">
                <span class="dashicons dashicons-editor-help" aria-hidden="true"></span>
                <div>
                    <h1><?php esc_html_e('Badge «Come possiamo aiutarti»', 'farmaciainternazionale-child-theme'); ?></h1>
                    <p><?php esc_html_e('Le domande della pastiglia in basso a destra del sito: testi, emoji e pulsanti.', 'farmaciainternazionale-child-theme'); ?></p>
                </div>
            </div>
            <div class="fi-em-admin-badges">
                <span><?php echo esc_html(sprintf(_n('%d domanda', '%d domande', count($argomenti), 'farmaciainternazionale-child-theme'), count($argomenti))); ?></span>
                <span class="is-green"><?php echo esc_html(sprintf(__('%d attive sul sito', 'farmaciainternazionale-child-theme'), $attive)); ?></span>
            </div>
        </header>

        <?php settings_errors(); ?>
        <?php if (isset($_GET['settings-updated']) && 'true' === sanitize_key(wp_unslash($_GET['settings-updated']))) : ?>
            <div class="fi-em-saved" role="status"><span class="dashicons dashicons-yes-alt" aria-hidden="true"></span><?php esc_html_e('Domande salvate.', 'farmaciainternazionale-child-theme'); ?></div>
        <?php endif; ?>

        <div class="fi-em-admin-info">
            <span class="dashicons dashicons-info-outline" aria-hidden="true"></span>
            <div>
                <strong><?php esc_html_e('L’ordine che vedi qui è l’ordine sul sito', 'farmaciainternazionale-child-theme'); ?></strong>
                <p><?php esc_html_e('Usa le frecce per spostare una domanda. Per togliere una domanda dal sito senza perdere il testo, spegni l’interruttore «Attiva» invece di cancellarla.', 'farmaciainternazionale-child-theme'); ?></p>
            </div>
        </div>

        <?php
        /*
         * Le due scritte predefinite viaggiano negli attributi del modulo perche'
         * il JavaScript deve poter aggiornare il segnaposto del campo «Scritta del
         * pulsante» quando si cambia il modo di contatto. Scriverle anche nel
         * JavaScript significherebbe averle in due posti e vederle divergere: qui
         * le calcola la stessa funzione che le usa sul sito, numero di telefono
         * compreso.
         */
        ?>
        <form method="post" action="options.php" id="fi_aiuto_form"
            data-predef-email="<?php echo esc_attr(fi_aiuto_pulsante_predefinito('email')); ?>"
            data-predef-telefono="<?php echo esc_attr(fi_aiuto_pulsante_predefinito('telefono')); ?>">
            <?php settings_fields('fi_aiuto_group'); ?>

            <section class="fi-em-admin-section">
                <div class="fi-em-section-heading">
                    <div>
                        <h2><?php esc_html_e('La pastiglia', 'farmaciainternazionale-child-theme'); ?></h2>
                        <p><?php esc_html_e('Quello che si legge prima di aprire il pannello.', 'farmaciainternazionale-child-theme'); ?></p>
                    </div>
                </div>
                <div class="fi-ai-generali">
                    <div class="fi-em-field fi-ai-emoji">
                        <label for="fi_ai_emoji"><?php esc_html_e('Emoji', 'farmaciainternazionale-child-theme'); ?></label>
                        <input id="fi_ai_emoji" type="text" name="fi_aiuto_pastiglia_emoji" value="<?php echo esc_attr(get_option('fi_aiuto_pastiglia_emoji', '')); ?>" placeholder="❤️" maxlength="24">
                    </div>
                    <div class="fi-em-field">
                        <label for="fi_ai_pastiglia"><?php esc_html_e('Scritta della pastiglia', 'farmaciainternazionale-child-theme'); ?></label>
                        <input id="fi_ai_pastiglia" type="text" name="fi_aiuto_pastiglia_testo" value="<?php echo esc_attr(get_option('fi_aiuto_pastiglia_testo', '')); ?>" placeholder="<?php esc_attr_e('Come possiamo aiutarti?', 'farmaciainternazionale-child-theme'); ?>">
                    </div>
                    <div class="fi-em-field">
                        <label for="fi_ai_titolo"><?php esc_html_e('Titolo dentro il pannello', 'farmaciainternazionale-child-theme'); ?></label>
                        <input id="fi_ai_titolo" type="text" name="fi_aiuto_pannello_titolo" value="<?php echo esc_attr(get_option('fi_aiuto_pannello_titolo', '')); ?>" placeholder="<?php esc_attr_e('Come possiamo aiutarti oggi?', 'farmaciainternazionale-child-theme'); ?>">
                    </div>
                </div>
            </section>

            <section class="fi-em-admin-section">
                <div class="fi-em-section-heading">
                    <div>
                        <h2><?php esc_html_e('Le domande', 'farmaciainternazionale-child-theme'); ?></h2>
                        <p><?php esc_html_e('Ogni domanda è una voce dell’elenco, con la sua risposta e il suo pulsante.', 'farmaciainternazionale-child-theme'); ?></p>
                    </div>
                    <span class="fi-em-feature-badge"><?php esc_html_e('Ordine modificabile', 'farmaciainternazionale-child-theme'); ?></span>
                </div>

                <?php
                /*
                 * SEGNAPOSTO INDISPENSABILE. WordPress aggiorna un'opzione solo
                 * se il modulo la invia: se si cancellassero tutte le domande e
                 * si salvasse, il browser non manderebbe nessun campo con questo
                 * nome e le vecchie domande resterebbero nel database. Questa
                 * riga fantasma garantisce che l'opzione arrivi sempre. Non
                 * diventa una domanda: fi_aiuto_normalizza() scarta le righe
                 * senza domanda e senza risposta, e questa non ha ne' l'una ne'
                 * l'altra.
                 */
                ?>
                <input type="hidden" name="<?php echo esc_attr(FI_AIUTO_OPZIONE); ?>[segnaposto][voce]" value="">

                <div class="fi-ai-lista" id="fi_aiuto_lista">
                    <?php foreach ($argomenti as $indice => $a) : ?>
                        <?php fi_aiuto_campi_riga($a, $indice); ?>
                    <?php endforeach; ?>
                </div>

                <button type="button" class="button fi-em-add-button" id="fi_aiuto_aggiungi">
                    <span class="dashicons dashicons-plus-alt2" aria-hidden="true"></span><?php esc_html_e('Aggiungi una domanda', 'farmaciainternazionale-child-theme'); ?>
                </button>

                <?php
                /*
                 * IL MODELLO DELLA RIGA NUOVA, generato dal PHP con i campi
                 * identici alle altre righe. Sta in un <template>, quindi il
                 * browser non lo mostra e non invia i suoi campi al salvataggio.
                 * L'indice segnaposto `__i__` viene sostituito dal JavaScript.
                 */
                ?>
                <template id="fi_aiuto_modello"><?php fi_aiuto_campi_riga($vuota, '__i__'); ?></template>
            </section>

            <div class="fi-em-savebar">
                <div>
                    <strong><?php esc_html_e('Fatto?', 'farmaciainternazionale-child-theme'); ?></strong>
                    <span><?php esc_html_e('Salva per aggiornare subito la pastiglia sul sito.', 'farmaciainternazionale-child-theme'); ?></span>
                </div>
                <?php submit_button(__('Salva domande', 'farmaciainternazionale-child-theme'), 'primary fi-em-save-button', 'submit', false); ?>
            </div>
        </form>
    </div>
    <?php
}
