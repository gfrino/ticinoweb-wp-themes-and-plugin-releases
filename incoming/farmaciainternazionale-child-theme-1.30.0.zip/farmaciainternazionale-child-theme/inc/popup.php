<?php

/**
 * POPUP GESTIBILI DAL PANNELLO.
 *
 * PERCHE' UN TIPO DI CONTENUTO E NON UN'OPZIONE: creare, modificare, eliminare,
 * vedere l'elenco con lo stato, avere un editor di testo, un'immagine con il suo
 * testo alternativo e i permessi giusti sono cose che WordPress fa gia'. Metterle
 * dentro una pagina di opzioni con un array vorrebbe dire riscrivere a mano
 * elenco, cestino, revisioni e controllo degli accessi. Qui si riusa quello che
 * c'e': il titolo del post e' il titolo del popup, il contenuto e' il testo,
 * l'immagine in evidenza e' l'immagine, e tutto il resto sta in un solo riquadro
 * di impostazioni.
 *
 * SI MOSTRA UN SOLO POPUP per caricamento, il piu' recente fra quelli validi:
 * due finestre sovrapposte sono un fastidio, non una funzione.
 *
 * @package Farmacia_Internazionale
 */

if (!defined('ABSPATH')) {
    exit;
}

define('FI_POPUP_TIPO', 'fi_popup');

/* Prefisso unico per i campi salvati, cosi' non collidono con quelli di altri. */
define('FI_POPUP_META', '_fi_popup_');

/**
 * Elenco dei campi con il loro valore predefinito e come vanno ripuliti.
 *
 * Tenerli in un unico posto evita la classica dimenticanza: campo aggiunto al
 * form ma non al salvataggio, o salvato senza essere ripulito.
 *
 * @return array
 */
function fi_popup_campi()
{
    return array(
        'attivo'         => array('default' => 0,        'tipo' => 'bool'),
        'cta_mostra'     => array('default' => 1,        'tipo' => 'bool'),
        'cta_testo'      => array('default' => '',       'tipo' => 'testo'),
        'cta_link'       => array('default' => '',       'tipo' => 'url'),
        'cta_nuova'      => array('default' => 0,        'tipo' => 'bool'),
        'da'             => array('default' => '',       'tipo' => 'data'),
        'a'              => array('default' => '',       'tipo' => 'data'),
        'dove'           => array('default' => 'tutto',  'tipo' => 'scelta', 'valori' => array('tutto', 'home', 'specifiche')),
        'pagine'         => array('default' => array(),  'tipo' => 'id_multipli'),
        'frequenza'      => array('default' => 'sempre', 'tipo' => 'scelta', 'valori' => array('sempre', 'sessione', 'utente')),
        'ritardo'        => array('default' => 0,        'tipo' => 'secondi'),
    );
}

/**
 * Legge un campo del popup, con il ripiego previsto.
 *
 * @param int    $id    ID del popup.
 * @param string $campo Nome breve del campo.
 * @return mixed
 */
function fi_popup_valore($id, $campo)
{
    $campi = fi_popup_campi();
    if (!isset($campi[$campo])) {
        return null;
    }

    $salvato = get_post_meta($id, FI_POPUP_META . $campo, true);

    /* Mai salvato: si usa il predefinito. La stringa vuota invece e' una scelta
       legittima (per esempio nessuna data), quindi si distingue con metadata_exists. */
    if (!metadata_exists('post', $id, FI_POPUP_META . $campo)) {
        return $campi[$campo]['default'];
    }

    if ('bool' === $campi[$campo]['tipo']) {
        return $salvato ? 1 : 0;
    }
    if ('id_multipli' === $campi[$campo]['tipo']) {
        return is_array($salvato) ? array_map('absint', $salvato) : array();
    }
    if ('secondi' === $campi[$campo]['tipo']) {
        return absint($salvato);
    }

    return $salvato;
}

/* -------------------------------------------------------------------------
   Registrazione del tipo di contenuto
   ------------------------------------------------------------------------- */

add_action('init', 'fi_popup_registra_tipo');
function fi_popup_registra_tipo()
{
    register_post_type(
        FI_POPUP_TIPO,
        array(
            'labels' => array(
                'name'               => __('Popup', 'farmaciainternazionale-child-theme'),
                'singular_name'      => __('Popup', 'farmaciainternazionale-child-theme'),
                'add_new'            => __('Aggiungi popup', 'farmaciainternazionale-child-theme'),
                'add_new_item'       => __('Nuovo popup', 'farmaciainternazionale-child-theme'),
                'edit_item'          => __('Modifica popup', 'farmaciainternazionale-child-theme'),
                'new_item'           => __('Nuovo popup', 'farmaciainternazionale-child-theme'),
                'view_item'          => __('Vedi popup', 'farmaciainternazionale-child-theme'),
                'search_items'       => __('Cerca popup', 'farmaciainternazionale-child-theme'),
                'not_found'          => __('Nessun popup creato', 'farmaciainternazionale-child-theme'),
                'not_found_in_trash' => __('Nessun popup nel cestino', 'farmaciainternazionale-child-theme'),
                'all_items'          => __('Tutti i popup', 'farmaciainternazionale-child-theme'),
                'menu_name'          => __('Popup', 'farmaciainternazionale-child-theme'),
            ),
            /*
             * NON PUBBLICO: un popup non e' una pagina e non deve avere un
             * indirizzo proprio ne' finire nei risultati di ricerca o nella
             * sitemap. Serve solo nel pannello e nel footer del sito.
             */
            'public'              => false,
            'publicly_queryable'  => false,
            'exclude_from_search' => true,
            'show_ui'             => true,
            'show_in_menu'        => true,
            'show_in_rest'        => false,
            'menu_position'       => 32,
            'menu_icon'           => 'dashicons-external',
            'supports'            => array('title', 'editor', 'thumbnail'),
            'capability_type'     => 'page',
            'map_meta_cap'        => true,
            'has_archive'         => false,
            'rewrite'             => false,
            'can_export'          => true,
        )
    );
}

/*
 * EDITOR CLASSICO e non a blocchi. Per chi non e' tecnico una casella di testo
 * con grassetto, corsivo e link e' piu' semplice della gestione a blocchi, e per
 * il testo di un popup non serve altro. Produce anche HTML piu' prevedibile da
 * ripulire in uscita.
 */
add_filter('use_block_editor_for_post_type', 'fi_popup_editor_classico', 10, 2);
function fi_popup_editor_classico($usa_blocchi, $tipo)
{
    return FI_POPUP_TIPO === $tipo ? false : $usa_blocchi;
}

/* -------------------------------------------------------------------------
   Riquadro delle impostazioni
   ------------------------------------------------------------------------- */

add_action('add_meta_boxes', 'fi_popup_riquadri');
function fi_popup_riquadri()
{
    add_meta_box(
        'fi-popup-impostazioni',
        __('Impostazioni del popup', 'farmaciainternazionale-child-theme'),
        'fi_popup_riquadro',
        FI_POPUP_TIPO,
        'normal',
        'high'
    );
}

/**
 * Disegna il riquadro delle impostazioni.
 *
 * @param WP_Post $post Popup in modifica.
 */
function fi_popup_riquadro($post)
{
    wp_nonce_field('fi_popup_salva_' . $post->ID, 'fi_popup_nonce');

    $v = array();
    foreach (array_keys(fi_popup_campi()) as $campo) {
        $v[$campo] = fi_popup_valore($post->ID, $campo);
    }

    $pagine = get_pages(array('sort_column' => 'menu_order,post_title', 'number' => 200));
?>
    <div class="fi-pop-admin">

        <div class="fi-pop-riga fi-pop-riga--stato">
            <label class="fi-pop-switch">
                <input type="checkbox" name="fi_popup[attivo]" value="1" <?php checked($v['attivo'], 1); ?>>
                <span class="fi-pop-switch-cursore" aria-hidden="true"></span>
                <span class="fi-pop-switch-testo">
                    <strong><?php esc_html_e('Popup attivo', 'farmaciainternazionale-child-theme'); ?></strong>
                    <small><?php esc_html_e('Spento, il popup resta salvato ma non compare sul sito.', 'farmaciainternazionale-child-theme'); ?></small>
                </span>
            </label>
        </div>

        <h4 class="fi-pop-titolo-gruppo"><?php esc_html_e('Pulsante', 'farmaciainternazionale-child-theme'); ?></h4>

        <div class="fi-pop-riga">
            <label class="fi-pop-check">
                <input type="checkbox" name="fi_popup[cta_mostra]" value="1" <?php checked($v['cta_mostra'], 1); ?>>
                <span><?php esc_html_e('Mostra il pulsante', 'farmaciainternazionale-child-theme'); ?></span>
            </label>
        </div>

        <div class="fi-pop-griglia">
            <p class="fi-pop-campo">
                <label for="fi-pop-cta-testo"><?php esc_html_e('Testo del pulsante', 'farmaciainternazionale-child-theme'); ?></label>
                <input id="fi-pop-cta-testo" type="text" name="fi_popup[cta_testo]" value="<?php echo esc_attr($v['cta_testo']); ?>" placeholder="<?php esc_attr_e('Es. Scopri di più', 'farmaciainternazionale-child-theme'); ?>" maxlength="60">
            </p>
            <p class="fi-pop-campo">
                <label for="fi-pop-cta-link"><?php esc_html_e('Indirizzo del pulsante', 'farmaciainternazionale-child-theme'); ?></label>
                <input id="fi-pop-cta-link" type="url" name="fi_popup[cta_link]" value="<?php echo esc_attr($v['cta_link']); ?>" placeholder="https://">
            </p>
        </div>

        <div class="fi-pop-riga">
            <label class="fi-pop-check">
                <input type="checkbox" name="fi_popup[cta_nuova]" value="1" <?php checked($v['cta_nuova'], 1); ?>>
                <span><?php esc_html_e('Apri in una nuova scheda', 'farmaciainternazionale-child-theme'); ?></span>
            </label>
        </div>

        <h4 class="fi-pop-titolo-gruppo"><?php esc_html_e('Dove mostrarlo', 'farmaciainternazionale-child-theme'); ?></h4>

        <div class="fi-pop-riga">
            <?php
            $dove = array(
                'tutto'      => __('In tutto il sito', 'farmaciainternazionale-child-theme'),
                'home'       => __('Solo in homepage', 'farmaciainternazionale-child-theme'),
                'specifiche' => __('Solo nelle pagine scelte qui sotto', 'farmaciainternazionale-child-theme'),
            );
            foreach ($dove as $chiave => $etichetta) :
                ?>
                <label class="fi-pop-radio">
                    <input type="radio" name="fi_popup[dove]" value="<?php echo esc_attr($chiave); ?>" <?php checked($v['dove'], $chiave); ?>>
                    <span><?php echo esc_html($etichetta); ?></span>
                </label>
            <?php endforeach; ?>
        </div>

        <p class="fi-pop-campo fi-pop-campo--pagine">
            <label for="fi-pop-pagine"><?php esc_html_e('Pagine scelte', 'farmaciainternazionale-child-theme'); ?></label>
            <select id="fi-pop-pagine" name="fi_popup[pagine][]" multiple size="7">
                <?php foreach ($pagine as $pagina) : ?>
                    <option value="<?php echo esc_attr($pagina->ID); ?>" <?php selected(in_array($pagina->ID, (array) $v['pagine'], true)); ?>>
                        <?php echo esc_html($pagina->post_title); ?>
                    </option>
                <?php endforeach; ?>
            </select>
            <small><?php esc_html_e('Tieni premuto Cmd (o Ctrl) per scegliere più pagine. Vale solo con l\'opzione «pagine scelte».', 'farmaciainternazionale-child-theme'); ?></small>
        </p>

        <h4 class="fi-pop-titolo-gruppo"><?php esc_html_e('Quando e ogni quanto', 'farmaciainternazionale-child-theme'); ?></h4>

        <div class="fi-pop-griglia">
            <p class="fi-pop-campo">
                <label for="fi-pop-da"><?php esc_html_e('Dal giorno', 'farmaciainternazionale-child-theme'); ?></label>
                <input id="fi-pop-da" type="date" name="fi_popup[da]" value="<?php echo esc_attr($v['da']); ?>">
                <small><?php esc_html_e('Vuoto: nessuna data d\'inizio.', 'farmaciainternazionale-child-theme'); ?></small>
            </p>
            <p class="fi-pop-campo">
                <label for="fi-pop-a"><?php esc_html_e('Al giorno', 'farmaciainternazionale-child-theme'); ?></label>
                <input id="fi-pop-a" type="date" name="fi_popup[a]" value="<?php echo esc_attr($v['a']); ?>">
                <small><?php esc_html_e('Vuoto: nessuna scadenza. Il giorno indicato è compreso.', 'farmaciainternazionale-child-theme'); ?></small>
            </p>
        </div>

        <div class="fi-pop-griglia">
            <p class="fi-pop-campo">
                <label for="fi-pop-frequenza"><?php esc_html_e('Ogni quanto mostrarlo', 'farmaciainternazionale-child-theme'); ?></label>
                <select id="fi-pop-frequenza" name="fi_popup[frequenza]">
                    <option value="sempre" <?php selected($v['frequenza'], 'sempre'); ?>><?php esc_html_e('Sempre — a ogni apertura della pagina', 'farmaciainternazionale-child-theme'); ?></option>
                    <option value="sessione" <?php selected($v['frequenza'], 'sessione'); ?>><?php esc_html_e('Una volta per visita — chi lo chiude non lo rivede finché non riapre il browser', 'farmaciainternazionale-child-theme'); ?></option>
                    <option value="utente" <?php selected($v['frequenza'], 'utente'); ?>><?php esc_html_e('Una volta sola — chi lo chiude non lo rivede mai più', 'farmaciainternazionale-child-theme'); ?></option>
                </select>
                <small><?php esc_html_e('Lascia «Sempre» se vuoi che il popup si riapra ogni volta che si entra nella pagina. Con le altre due scelte il visitatore che lo chiude non lo rivede, finché non modifichi il popup: a ogni modifica il conteggio riparte.', 'farmaciainternazionale-child-theme'); ?></small>
            </p>
            <p class="fi-pop-campo">
                <label for="fi-pop-ritardo"><?php esc_html_e('Ritardo di apertura', 'farmaciainternazionale-child-theme'); ?></label>
                <input id="fi-pop-ritardo" type="number" min="0" max="120" step="1" name="fi_popup[ritardo]" value="<?php echo esc_attr($v['ritardo']); ?>">
                <small><?php esc_html_e('Secondi dopo il caricamento. 0 = subito.', 'farmaciainternazionale-child-theme'); ?></small>
            </p>
        </div>

        <p class="fi-pop-nota">
            <?php esc_html_e('Il titolo in alto e il testo dell\'editor sono quelli che si vedono nel popup. L\'immagine si imposta con «Immagine in evidenza»: il suo testo alternativo viene preso dalla Libreria media.', 'farmaciainternazionale-child-theme'); ?>
        </p>
    </div>
<?php
}

add_action('save_post_' . FI_POPUP_TIPO, 'fi_popup_salva', 10, 2);
/**
 * Salva le impostazioni del popup.
 *
 * @param int     $id   ID del popup.
 * @param WP_Post $post Oggetto.
 */
function fi_popup_salva($id, $post)
{
    /* Salvataggi automatici e revisioni non portano il riquadro: si ignorano,
       altrimenti sovrascriverebbero i valori con i predefiniti. */
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }
    if (wp_is_post_revision($id)) {
        return;
    }

    $nonce = isset($_POST['fi_popup_nonce']) ? sanitize_text_field(wp_unslash($_POST['fi_popup_nonce'])) : '';
    if (!wp_verify_nonce($nonce, 'fi_popup_salva_' . $id)) {
        return;
    }
    if (!current_user_can('edit_post', $id)) {
        return;
    }

    $inviato = isset($_POST['fi_popup']) && is_array($_POST['fi_popup'])
        ? wp_unslash($_POST['fi_popup']) // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
        : array();

    foreach (fi_popup_campi() as $campo => $regole) {
        $grezzo = isset($inviato[$campo]) ? $inviato[$campo] : null;

        switch ($regole['tipo']) {
            case 'bool':
                /* Una casella non spuntata non viene inviata: assente = spenta. */
                $pulito = !empty($grezzo) ? 1 : 0;
                break;

            case 'url':
                $pulito = '' === trim((string) $grezzo) ? '' : esc_url_raw(trim((string) $grezzo));
                break;

            case 'data':
                $pulito = '';
                $testo  = trim((string) $grezzo);
                /* Solo il formato del campo date del browser, e solo se e' una
                   data che esiste davvero: il 2026-02-31 non passa. */
                if (preg_match('/^(\d{4})-(\d{2})-(\d{2})$/', $testo, $p) && checkdate((int) $p[2], (int) $p[3], (int) $p[1])) {
                    $pulito = $testo;
                }
                break;

            case 'scelta':
                $pulito = in_array($grezzo, $regole['valori'], true) ? $grezzo : $regole['default'];
                break;

            case 'id_multipli':
                $pulito = array();
                foreach ((array) $grezzo as $pid) {
                    $pid = absint($pid);
                    if ($pid && 'page' === get_post_type($pid)) {
                        $pulito[] = $pid;
                    }
                }
                break;

            case 'secondi':
                $pulito = min(120, absint($grezzo));
                break;

            default:
                $pulito = sanitize_text_field((string) $grezzo);
        }

        update_post_meta($id, FI_POPUP_META . $campo, $pulito);
    }
}

/* -------------------------------------------------------------------------
   Elenco nel pannello: colonna stato e interruttore rapido
   ------------------------------------------------------------------------- */

add_filter('manage_' . FI_POPUP_TIPO . '_posts_columns', 'fi_popup_colonne');
function fi_popup_colonne($colonne)
{
    $nuove = array();
    foreach ($colonne as $chiave => $etichetta) {
        $nuove[$chiave] = $etichetta;
        if ('title' === $chiave) {
            $nuove['fi_stato'] = __('Stato', 'farmaciainternazionale-child-theme');
            $nuove['fi_dove']  = __('Dove', 'farmaciainternazionale-child-theme');
            $nuove['fi_quando'] = __('Periodo', 'farmaciainternazionale-child-theme');
        }
    }
    return $nuove;
}

add_action('manage_' . FI_POPUP_TIPO . '_posts_custom_column', 'fi_popup_colonna_contenuto', 10, 2);
function fi_popup_colonna_contenuto($colonna, $id)
{
    if ('fi_stato' === $colonna) {
        $attivo = fi_popup_valore($id, 'attivo');
        $in_corso = fi_popup_nel_periodo($id);

        printf(
            '<span class="fi-pop-pallino %s">%s</span>',
            esc_attr($attivo ? 'is-on' : 'is-off'),
            esc_html($attivo ? __('Attivo', 'farmaciainternazionale-child-theme') : __('Disattivato', 'farmaciainternazionale-child-theme'))
        );

        /* Attivo ma fuori dal periodo: e' la trappola in cui si cade piu'
           facilmente, quindi va detto qui e non solo nella scheda. */
        if ($attivo && !$in_corso) {
            printf(
                '<br><small class="fi-pop-avviso">%s</small>',
                esc_html__('fuori dal periodo impostato', 'farmaciainternazionale-child-theme')
            );
        }

        $url = wp_nonce_url(
            add_query_arg(
                array('fi_popup_scambia' => $id),
                admin_url('edit.php?post_type=' . FI_POPUP_TIPO)
            ),
            'fi_popup_scambia_' . $id
        );
        printf(
            '<br><a class="fi-pop-scambia" href="%s">%s</a>',
            esc_url($url),
            esc_html($attivo ? __('Disattiva', 'farmaciainternazionale-child-theme') : __('Attiva', 'farmaciainternazionale-child-theme'))
        );
        return;
    }

    if ('fi_dove' === $colonna) {
        $dove = fi_popup_valore($id, 'dove');
        $mappa = array(
            'tutto'      => __('Tutto il sito', 'farmaciainternazionale-child-theme'),
            'home'       => __('Solo homepage', 'farmaciainternazionale-child-theme'),
            'specifiche' => __('Pagine scelte', 'farmaciainternazionale-child-theme'),
        );
        echo esc_html(isset($mappa[$dove]) ? $mappa[$dove] : $dove);

        if ('specifiche' === $dove) {
            $titoli = array();
            foreach ((array) fi_popup_valore($id, 'pagine') as $pid) {
                $titoli[] = get_the_title($pid);
            }
            if ($titoli) {
                printf('<br><small>%s</small>', esc_html(implode(', ', $titoli)));
            }
        }
        return;
    }

    if ('fi_quando' === $colonna) {
        $da = fi_popup_valore($id, 'da');
        $a  = fi_popup_valore($id, 'a');
        if ('' === $da && '' === $a) {
            echo '<span class="fi-pop-tenue">' . esc_html__('sempre', 'farmaciainternazionale-child-theme') . '</span>';
            return;
        }
        echo esc_html(($da !== '' ? $da : '…') . ' → ' . ($a !== '' ? $a : '…'));
    }
}

add_action('admin_init', 'fi_popup_porta_a_sempre');
/**
 * Porta i popup gia' salvati a «Sempre», una volta sola.
 *
 * PERCHE' SERVE: fino alla 1.12.5 il campo «Ogni quanto mostrarlo» nasceva su
 * «Una volta per visita». Chi ha creato un popup senza toccare quel campo si e'
 * ritrovato un avviso che compariva al primo ingresso e poi non si rivedeva piu'
 * tornando sulla stessa pagina — che non e' un difetto del codice ma non e'
 * quello che si voleva. Cambiare il predefinito sistema solo i popup futuri: il
 * valore vecchio resta scritto accanto a quelli che ci sono gia'.
 *
 * PERCHE' UNA VOLTA SOLA: subito dopo la conversione si segna un'opzione. Cosi'
 * chi in futuro scegliera' «Una volta per visita» di proposito se la tiene, e
 * questa funzione non gli rimette «Sempre» al caricamento successivo.
 *
 * Si tocca solo chi aveva «sessione», cioe' il vecchio predefinito. Chi aveva
 * scelto «Una volta sola» (`utente`) ha fatto una scelta esplicita e non si
 * cambia.
 */
function fi_popup_porta_a_sempre()
{
    static $fatto = false;

    if ($fatto || get_option('fi_popup_frequenza_convertita')) {
        return;
    }

    /* La guardia dentro la richiesta e' questa variabile statica; l'opzione si
       scrive solo DOPO aver convertito. Segnare prima sembrava piu' prudente ma
       era il contrario: se la query non andasse a buon fine, l'unica occasione
       di convertire sarebbe bruciata e i popup vecchi resterebbero come sono. */
    $fatto = true;

    $popup = get_posts(
        array(
            'post_type'      => FI_POPUP_TIPO,
            'post_status'    => 'any',
            'posts_per_page' => -1,
            'fields'         => 'ids',
            'no_found_rows'  => true,
        )
    );

    foreach ($popup as $id) {
        if ('sessione' === get_post_meta($id, FI_POPUP_META . 'frequenza', true)) {
            update_post_meta($id, FI_POPUP_META . 'frequenza', 'sempre');
        }
    }

    update_option('fi_popup_frequenza_convertita', 1, false);
}

add_action('admin_init', 'fi_popup_gestisci_scambio');
/**
 * Accende o spegne un popup dall'elenco, con un clic.
 */
function fi_popup_gestisci_scambio()
{
    if (!isset($_GET['fi_popup_scambia'])) {
        return;
    }

    $id = absint($_GET['fi_popup_scambia']);
    if (!$id || FI_POPUP_TIPO !== get_post_type($id)) {
        return;
    }
    check_admin_referer('fi_popup_scambia_' . $id);
    if (!current_user_can('edit_post', $id)) {
        wp_die(esc_html__('Non sei autorizzato a modificare questo popup.', 'farmaciainternazionale-child-theme'));
    }

    update_post_meta($id, FI_POPUP_META . 'attivo', fi_popup_valore($id, 'attivo') ? 0 : 1);

    wp_safe_redirect(admin_url('edit.php?post_type=' . FI_POPUP_TIPO));
    exit;
}

add_action('admin_enqueue_scripts', 'fi_popup_asset_admin');
function fi_popup_asset_admin($hook)
{
    $schermo = get_current_screen();
    if (!$schermo || FI_POPUP_TIPO !== $schermo->post_type) {
        return;
    }

    wp_enqueue_style(
        'fi-admin-popup',
        get_stylesheet_directory_uri() . '/assets/css/admin-popup.css',
        array(),
        wp_get_theme()->get('Version')
    );
}

/* -------------------------------------------------------------------------
   Scelta del popup da mostrare
   ------------------------------------------------------------------------- */

/**
 * Dice se oggi il popup rientra nel periodo impostato.
 *
 * @param int $id ID del popup.
 * @return bool
 */
function fi_popup_nel_periodo($id)
{
    $oggi = wp_date('Y-m-d');
    $da   = fi_popup_valore($id, 'da');
    $a    = fi_popup_valore($id, 'a');

    if ('' !== $da && $oggi < $da) {
        return false;
    }
    /* Il giorno di fine e' compreso: chi scrive "al 31 dicembre" si aspetta che
       il 31 dicembre il popup si veda ancora. */
    if ('' !== $a && $oggi > $a) {
        return false;
    }

    return true;
}

/**
 * Dice se il popup va mostrato sulla pagina che si sta guardando.
 *
 * @param int $id ID del popup.
 * @return bool
 */
function fi_popup_qui($id)
{
    $dove = fi_popup_valore($id, 'dove');

    if ('tutto' === $dove) {
        return true;
    }
    if ('home' === $dove) {
        return is_front_page() || is_home();
    }
    if ('specifiche' === $dove) {
        $pagine = (array) fi_popup_valore($id, 'pagine');
        return is_page() && in_array(get_queried_object_id(), $pagine, true);
    }

    return false;
}

/**
 * Trova il popup da mostrare adesso, oppure null.
 *
 * @return WP_Post|null
 */
function fi_popup_da_mostrare()
{
    static $scelto = false;
    if (false !== $scelto) {
        return $scelto;
    }

    $scelto = null;

    if (is_admin() || is_feed() || is_404() || is_robots()) {
        return $scelto;
    }
    /* In anteprima o in personalizzazione si sta lavorando alla pagina: un popup
       che si apre in mezzo darebbe fastidio. */
    if (is_preview() || is_customize_preview()) {
        return $scelto;
    }

    $candidati = get_posts(
        array(
            'post_type'        => FI_POPUP_TIPO,
            'post_status'      => 'publish',
            'posts_per_page'   => 20,
            'orderby'          => 'modified',
            'order'            => 'DESC',
            'no_found_rows'    => true,
            'suppress_filters' => false,
            'meta_query'       => array(
                array(
                    'key'   => FI_POPUP_META . 'attivo',
                    'value' => '1',
                ),
            ),
        )
    );

    foreach ($candidati as $popup) {
        if (fi_popup_nel_periodo($popup->ID) && fi_popup_qui($popup->ID)) {
            $scelto = $popup;
            break;
        }
    }

    return $scelto;
}

/* -------------------------------------------------------------------------
   Uscita sul sito
   ------------------------------------------------------------------------- */

add_action('wp_enqueue_scripts', 'fi_popup_asset_sito');
/**
 * Accoda stile e script SOLO quando un popup verra' davvero mostrato.
 */
function fi_popup_asset_sito()
{
    if (!fi_popup_da_mostrare()) {
        return;
    }

    $versione = wp_get_theme()->get('Version');

    wp_enqueue_style(
        'fi-popup',
        get_stylesheet_directory_uri() . '/assets/css/popup.css',
        array('farmaciainternazionale-child-style'),
        $versione
    );
    wp_enqueue_script(
        'fi-popup',
        get_stylesheet_directory_uri() . '/assets/js/popup.js',
        array(),
        $versione,
        true
    );
}

add_action('wp_footer', 'fi_popup_stampa');
/**
 * Stampa il popup nel footer.
 *
 * Nasce con l'attributo hidden e in posizione fissa: non entra nel flusso della
 * pagina, quindi non sposta niente al caricamento (nessun salto di layout).
 */
function fi_popup_stampa()
{
    $popup = fi_popup_da_mostrare();
    if (!$popup) {
        return;
    }

    $id          = $popup->ID;
    $titolo      = get_the_title($popup);
    $testo       = apply_filters('the_content', $popup->post_content);
    $cta_mostra  = fi_popup_valore($id, 'cta_mostra');
    $cta_testo   = trim((string) fi_popup_valore($id, 'cta_testo'));
    $cta_link    = trim((string) fi_popup_valore($id, 'cta_link'));
    $cta_nuova   = fi_popup_valore($id, 'cta_nuova');
    $ha_pulsante = $cta_mostra && '' !== $cta_testo && '' !== $cta_link;

    $immagine = '';
    if (has_post_thumbnail($id)) {
        /*
         * Con width e height nell'HTML il browser conosce le proporzioni prima di
         * scaricare il file e non ridisegna il popup quando l'immagine arriva.
         */
        $immagine = get_the_post_thumbnail(
            $id,
            'large',
            array(
                'class'    => 'fi-pop__img',
                'loading'  => 'lazy',
                'decoding' => 'async',
            )
        );
    }

    /*
     * La chiave per ricordare che e' stato chiuso contiene la data di ultima
     * modifica: se il popup viene aggiornato, chi l'aveva chiuso lo rivede. E'
     * quello che si aspetta chi pubblica un avviso nuovo.
     */
    $chiave = 'fi-popup-' . $id . '-' . get_post_modified_time('U', true, $popup);
?>
    <div class="fi-pop" data-fi-popup
        data-chiave="<?php echo esc_attr($chiave); ?>"
        data-frequenza="<?php echo esc_attr(fi_popup_valore($id, 'frequenza')); ?>"
        data-ritardo="<?php echo esc_attr(fi_popup_valore($id, 'ritardo')); ?>"
        hidden>
        <div class="fi-pop__velo" data-fi-popup-velo></div>
        <div class="fi-pop__scatola" role="dialog" aria-modal="true" aria-labelledby="fi-pop-titolo-<?php echo esc_attr($id); ?>">
            <button type="button" class="fi-pop__chiudi" data-fi-popup-chiudi
                aria-label="<?php esc_attr_e('Chiudi', 'farmaciainternazionale-child-theme'); ?>">
                <svg viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                    <path d="M6 6l12 12M18 6L6 18" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" />
                </svg>
            </button>

            <?php if ('' !== $immagine) : ?>
                <div class="fi-pop__figura"><?php echo $immagine; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div>
            <?php endif; ?>

            <div class="fi-pop__corpo">
                <h2 class="fi-pop__titolo" id="fi-pop-titolo-<?php echo esc_attr($id); ?>"><?php echo esc_html($titolo); ?></h2>

                <?php if ('' !== trim(wp_strip_all_tags($testo))) : ?>
                    <div class="fi-pop__testo"><?php echo wp_kses_post($testo); ?></div>
                <?php endif; ?>

                <?php if ($ha_pulsante) : ?>
                    <a class="fi-pop__btn" href="<?php echo esc_url($cta_link); ?>"
                        <?php if ($cta_nuova) : ?>target="_blank" rel="noopener noreferrer"<?php endif; ?>>
                        <?php echo esc_html($cta_testo); ?>
                        <?php if ($cta_nuova) : ?>
                            <span class="screen-reader-text"><?php esc_html_e('(si apre in una nuova scheda)', 'farmaciainternazionale-child-theme'); ?></span>
                        <?php endif; ?>
                    </a>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php
}
