<?php

/**
 * PANNELLO "COME POSSIAMO AIUTARTI" — pastiglia in basso a destra.
 *
 * Si apre su un elenco di argomenti; scelto l'argomento mostra una risposta
 * scritta e i modi per proseguire il discorso con la farmacia.
 *
 * QUI C'E' SOLO LA RESA A SCHERMO. Le domande, le risposte, le emoji e le
 * scritte dei pulsanti si modificano dal pannello «Badge Aiuto»; i valori di
 * partenza e la pagina di amministrazione stanno in inc/admin-aiuto.php.
 *
 * @package farmaciainternazionale-child-theme
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Gli argomenti da mostrare, nell'ordine in cui compaiono.
 *
 * Legge quel che e' stato salvato dal pannello «Badge Aiuto». Se non e' mai
 * stato salvato niente — sito appena installato, oppure tema aggiornato senza
 * che nessuno abbia toccato il pannello — usa i valori scritti nel tema, cosi'
 * la pastiglia ha comunque contenuti sensati.
 *
 * Gli argomenti spenti restano nel database ma non arrivano al sito: spegnere
 * l'interruttore e' il modo di togliere una domanda senza perderne il testo.
 *
 * L'`id` non e' un dato salvato: si costruisce qui dalla posizione, e serve solo
 * ad appaiare la voce dell'elenco con la sua risposta dentro la stessa pagina.
 *
 * @return array
 */
function fi_aiuto_argomenti()
{
    $salvati = get_option(FI_AIUTO_OPZIONE, null);
    $righe   = fi_aiuto_normalizza(null === $salvati ? fi_aiuto_argomenti_predefiniti() : $salvati);

    $argomenti = array();
    foreach ($righe as $riga) {
        if (empty($riga['attivo'])) {
            continue;
        }
        $riga['id']  = 'fi-arg-' . count($argomenti);
        $argomenti[] = $riga;
    }

    return $argomenti;
}

/**
 * Le scritte fisse della pastiglia, con i valori di ripiego.
 *
 * @return array
 */
function fi_aiuto_scritte()
{
    $emoji     = trim((string) get_option('fi_aiuto_pastiglia_emoji', ''));
    $pastiglia = trim((string) get_option('fi_aiuto_pastiglia_testo', ''));
    $titolo    = trim((string) get_option('fi_aiuto_pannello_titolo', ''));

    return array(
        'emoji'     => '' !== $emoji ? $emoji : '❤️',
        'pastiglia' => '' !== $pastiglia ? $pastiglia : __('Come possiamo aiutarti?', 'farmaciainternazionale-child-theme'),
        'titolo'    => '' !== $titolo ? $titolo : __('Come possiamo aiutarti oggi?', 'farmaciainternazionale-child-theme'),
    );
}

/**
 * Recapiti della farmacia, presi dal CMS con un ripiego prudente.
 *
 * @return array
 */
function fi_aiuto_recapiti()
{
    return array(
        'telefono' => (string) get_option('ticinoweb_contact_phone', ''),
        'email' => (string) get_option('ticinoweb_contact_email', ''),
    );
}

add_action('wp_enqueue_scripts', 'fi_aiuto_enqueue');
function fi_aiuto_enqueue()
{
    /* Miglioramento progressivo: senza questo file la pastiglia resta un
       collegamento alla pagina Contatti, che funziona comunque. */
    wp_enqueue_script(
        'fi-aiuto',
        get_stylesheet_directory_uri() . '/assets/js/aiuto.js',
        array(),
        wp_get_theme()->get('Version'),
        true
    );
}

add_action('wp_footer', 'fi_aiuto_render');
/**
 * Stampa la pastiglia e il pannello.
 *
 * Nel pannello di amministrazione non serve, e nemmeno sulla pagina dell’invio
 * ricette: la' la persona sta gia' compilando un modulo per la farmacia, e una
 * pastiglia che chiede "come possiamo aiutarti" le si metterebbe davanti.
 */
function fi_aiuto_render()
{
    if (is_admin() || is_page_template('invio-ricette.php')) {
        return;
    }

    $argomenti = fi_aiuto_argomenti();

    /* Se tutte le domande sono state spente o cancellate dal pannello, la
       pastiglia non ha niente da mostrare: meglio non stamparla affatto che
       aprire un pannello vuoto. */
    if (empty($argomenti)) {
        return;
    }

    $scritte = fi_aiuto_scritte();
    $recapiti = fi_aiuto_recapiti();
    $tel_pulito = preg_replace('/[^0-9+]/', '', $recapiti['telefono']);
?>
    <div class="fi-aiuto" data-fi-aiuto>

        <?php
        /*
         * NASCE COME COLLEGAMENTO alla pagina Contatti: se il JavaScript non
         * parte la pastiglia porta comunque da qualche parte. Lo script la
         * trasforma in un comando che apre il pannello.
         */
        ?>
        <a class="fi-aiuto__pastiglia" href="<?php echo esc_url(home_url('/contatti/')); ?>" data-fi-aiuto-apri>
            <span class="fi-aiuto__pastiglia-emoji" aria-hidden="true"><?php echo esc_html($scritte['emoji']); ?></span>
            <span class="fi-aiuto__pastiglia-testo"><?php echo esc_html($scritte['pastiglia']); ?></span>
        </a>

        <div class="fi-aiuto__pannello" data-fi-aiuto-pannello role="dialog" aria-modal="true"
            aria-labelledby="fi-aiuto-titolo" hidden>

            <div class="fi-aiuto__testa">
                <p class="fi-aiuto__titolo" id="fi-aiuto-titolo">
                    <span aria-hidden="true"><?php echo esc_html($scritte['emoji']); ?></span> <?php echo esc_html($scritte['titolo']); ?>
                </p>
                <button type="button" class="fi-aiuto__chiudi" data-fi-aiuto-chiudi aria-label="Chiudi">
                    <svg viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                        <path d="M6 6l12 12M18 6L6 18" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" />
                    </svg>
                </button>
            </div>

            <div class="fi-aiuto__corpo">

                <ul class="fi-aiuto__elenco" data-fi-aiuto-elenco>
                    <?php foreach ($argomenti as $a) : ?>
                        <li>
                            <button type="button" class="fi-aiuto__voce" data-fi-aiuto-va="<?php echo esc_attr($a['id']); ?>">
                                <span class="fi-aiuto__voce-emoji" aria-hidden="true"><?php echo esc_html($a['emoji']); ?></span>
                                <span class="fi-aiuto__voce-testo"><?php echo esc_html($a['voce']); ?></span>
                                <span class="fi-aiuto__voce-frec" aria-hidden="true">
                                    <svg viewBox="0 0 24 24"><path d="M9 5l7 7-7 7" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" /></svg>
                                </span>
                            </button>
                        </li>
                    <?php endforeach; ?>
                </ul>

                <?php foreach ($argomenti as $a) : ?>
                    <?php
                    $oggetto = 'Richiesta di informazioni: ' . $a['voce'];
                    $mailto = '' !== $recapiti['email']
                        ? 'mailto:' . $recapiti['email'] . '?subject=' . rawurlencode($oggetto)
                        : '';
                    /*
                     * Il pannello permette di riscrivere la scritta del pulsante
                     * principale. Lasciata vuota vale quella predefinita — e per
                     * il telefono la predefinita include il numero («Chiama 091
                     * ...»), mentre una scritta scelta a mano resta com'e': se
                     * qualcuno scrive «Parliamone di persona», appiccicarci il
                     * numero dietro la storpierebbe.
                     */
                    $etichetta = '' !== $a['pulsante']
                        ? $a['pulsante']
                        : fi_aiuto_pulsante_predefinito($a['contatto']);
                    $etichetta_tel = '' !== $a['pulsante']
                        ? $a['pulsante']
                        : fi_aiuto_pulsante_predefinito('telefono', $recapiti['telefono']);
                    ?>
                    <div class="fi-aiuto__risposta" data-fi-aiuto-risposta="<?php echo esc_attr($a['id']); ?>" hidden>

                        <button type="button" class="fi-aiuto__indietro" data-fi-aiuto-indietro>
                            <svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M15 5l-7 7 7 7" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" /></svg>
                            Tutti gli argomenti
                        </button>

                        <h3 class="fi-aiuto__risposta-titolo">
                            <span aria-hidden="true"><?php echo esc_html($a['emoji']); ?></span>
                            <?php echo esc_html($a['titolo']); ?>
                        </h3>

                        <p class="fi-aiuto__risposta-testo"><?php echo esc_html($a['testo']); ?></p>

                        <?php if ('' !== $a['nota']) : ?>
                            <p class="fi-aiuto__nota"><?php echo esc_html($a['nota']); ?></p>
                        <?php endif; ?>

                        <div class="fi-aiuto__azioni">
                            <?php if ('email' === $a['contatto'] && '' !== $mailto) : ?>
                                <a class="fi-aiuto__btn fi-aiuto__btn--primario" href="<?php echo esc_url($mailto); ?>">
                                    <?php echo esc_html($etichetta); ?>
                                </a>
                                <?php if ('' !== $tel_pulito) : ?>
                                    <a class="fi-aiuto__btn fi-aiuto__btn--secondario" href="tel:<?php echo esc_attr($tel_pulito); ?>">
                                        Chiama <?php echo esc_html($recapiti['telefono']); ?>
                                    </a>
                                <?php endif; ?>
                            <?php elseif ('' !== $tel_pulito) : ?>
                                <a class="fi-aiuto__btn fi-aiuto__btn--primario" href="tel:<?php echo esc_attr($tel_pulito); ?>">
                                    <?php echo esc_html($etichetta_tel); ?>
                                </a>
                                <a class="fi-aiuto__btn fi-aiuto__btn--secondario" href="<?php echo esc_url(home_url('/contatti/')); ?>">
                                    Orari e indirizzo
                                </a>
                            <?php endif; ?>
                        </div>

                    </div>
                <?php endforeach; ?>

            </div>
        </div>
    </div>
<?php
}
