<?php
/**
 * Template Name: Emergenze
 * Description: Pagina dei contatti utili per le urgenze.
 */

get_header();

$contact_page = function_exists('ticinoweb_get_mapped_page_url') ? ticinoweb_get_mapped_page_url('page_contatti') : '#contatti';
$map_link = function_exists('ticinoweb_get_contact_info') ? (ticinoweb_get_contact_info()['google_maps_url'] ?? '#') : '#';

// Lettura compatibile sia con il nuovo formato strutturato sia con i dati legacy.
$stored_main  = get_option('fi_em_main_cards', null);
$main_cards   = fi_emergenze_normalize_main_cards(null === $stored_main ? fi_emergenze_default_main_cards() : $stored_main);

?>

<main id="primary" class="site-main fi-em-page">

    <!-- 1. HERO EMERGENZE (LAYOUT COMPATTO) -->
    <section class="fi-servizi-hero" style="padding: 150px 0 90px;">
        <div class="fi-hero-bg-glow glow-1"></div>
        <div class="fi-hero-bg-glow glow-2"></div>
        <div class="fi-hero-botanical-pattern"></div>
        <div class="container">
            <div class="fi-servizi-hero-content text-center">
                <div class="fi-hero-badges mb-3">
                    <?php
                    /* Davanti alla prima etichetta, la cornetta del telefono (disegnata qui, non dal pannello). */
                    fi_heading_badges('emergency_hero', 'fi-badge', '<svg class="me-1" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="margin-bottom: 2px;"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path></svg> ');
                    ?>
                </div>
                <h1 class="fi-servizi-title reveal-text"><?php echo esc_html(fi_heading('emergency_hero')['title']); ?></h1>
                <?php if ('' !== fi_heading('emergency_hero')['text']) : ?><p class="fi-servizi-subtitle reveal-text delay-1 mb-4"><?php echo esc_html(fi_heading('emergency_hero')['text']); ?></p><?php endif; ?>
                <div class="fi-em-hero-mini-card reveal-up delay-2">
                    <i class="fas fa-exclamation-circle text-danger me-2"></i> In caso di emergenza grave, chiama il <strong><a href="tel:144" class="text-danger text-decoration-none">144</a></strong>
                </div>
            </div>
        </div>
    </section>

    <!-- 2. NUMERI PRINCIPALI -->
    <section class="fi-em-numbers bg-white">
        <div class="container">
            <div class="fi-em-grid">
                <?php 
                $delays = array('', 'delay-1', '', 'delay-1');
                $card_count = count($main_cards);
                for ($i = 0; $i < $card_count; $i++): 
                    $card = isset($main_cards[$i]) ? $main_cards[$i] : null;
                    if (!$card || empty($card['active']) || '' === fi_normalize_phone_for_tel($card['phone'])) continue;
                    /* L'icona segue la scheda, non la casella: vedi
                       fi_emergenze_icona() in inc/admin-emergenze.php. */
                    $svg = fi_emergenze_icona($card);
                    $delay = isset($delays[$i]) ? $delays[$i] : '';
                    $fs = strlen($card['phone']) > 5 ? ' style="font-size: 1.5rem;"' : '';
                    $tel = fi_normalize_phone_for_tel($card['phone']);
                ?>
                <a href="<?php echo esc_attr('tel:' . $tel); ?>" class="fi-em-card reveal-up <?php echo esc_attr($delay); ?> text-decoration-none h-100">
                    <div class="fi-em-card-icon">
                        <?php echo $svg; ?>
                    </div>
                    <h3 class="fi-em-card-title"><?php echo esc_html($card['title']); ?></h3>
                    <div class="fi-em-card-number"<?php echo $fs; ?>><?php echo esc_html($card['phone']); ?></div>
                    <?php if (!empty($card['note'])) : ?><p class="fi-em-card-note"><?php echo esc_html($card['note']); ?></p><?php endif; ?>
                    <div class="fi-btn fi-btn-primary w-100">Chiama ora</div>
                </a>
                <?php endfor; ?>
            </div>
        </div>
    </section>

</main>

<?php get_footer(); ?>
