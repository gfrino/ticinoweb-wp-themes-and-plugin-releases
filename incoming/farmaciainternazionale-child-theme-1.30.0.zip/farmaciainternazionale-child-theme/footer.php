<?php
/**
 * The template for displaying the footer
 *
 * @package Farmacia Internazionale
 */

/*
 * Recapiti solo dal pannello ticinoWEB CMS → Contatti. Niente valori di riserva
 * scritti qui: un campo vuoto nasconde la sua riga invece di mostrare un dato
 * inventato o vecchio.
 */
$phone = trim((string) get_option('ticinoweb_contact_phone', ''));
$email = trim((string) get_option('ticinoweb_contact_email', ''));
$address = trim((string) get_option('ticinoweb_contact_address', ''));
$hours = get_option('ticinoweb_contact_opening_hours', '');
$map_link = trim((string) get_option('ticinoweb_contact_map_link', ''));


$chi_siamo = get_option('ticinoweb_chi_siamo_text');
$desc = !empty($chi_siamo) ? wp_trim_words($chi_siamo, 20, '&hellip;') : fi_heading('footer_brand')['text'];

/* Nome della farmacia da Impostazioni → Generali: la prima parola sta sulla prima riga. */
$fi_nome = explode(' ', trim(get_bloginfo('name')), 2);

// Funzione pulizia telefono per href
$phone_clean = str_replace(array(' ', '(', ')', '-'), '', $phone);
?>

<div class="fi-footer-wrapper">
    
    <!-- TOP CTA FOOTER -->
    <div class="fi-footer-cta-container">
        <div class="container">
            <div class="fi-footer-cta">
                <div class="cta-content">
                    <?php if ('' !== fi_heading('footer_cta')['kicker']) : ?><span class="fi-sub-heading"><?php echo esc_html(fi_heading('footer_cta')['kicker']); ?></span><?php endif; ?>
                    <h2><?php echo esc_html(fi_heading('footer_cta')['title']); ?></h2>
                    <?php if ('' !== fi_heading('footer_cta')['text']) : ?><p><?php echo esc_html(fi_heading('footer_cta')['text']); ?></p><?php endif; ?>
                </div>
                <div class="cta-actions" style="display: flex; align-items: center; gap: 60px;">
                    <?php 
                    // Usiamo la funzione nativa di ticinoWEB che funziona sicuramente (è la stessa dell'header!)
                    $favicon_url = '';
                    if (function_exists('ticinoweb_get_site_logo')) {
                        $favicon_url = ticinoweb_get_site_logo();
                    } 
                    if (empty($favicon_url) && get_option('ticinoweb_site_icon')) {
                        $favicon_url = get_option('ticinoweb_site_icon');
                    } 
                    if (empty($favicon_url) && get_option('ticinoweb_site_logo')) {
                        $favicon_url = get_option('ticinoweb_site_logo');
                    }
                    if (empty($favicon_url) && get_option('ticinoweb_page_header_bg_image')) {
                        // FALLBACK: L'utente l'ha caricata per sbaglio in "Immagine Sfondo Barra"
                        $favicon_url = get_option('ticinoweb_page_header_bg_image');
                    }
                    
                    if (is_numeric($favicon_url)) {
                        $favicon_url = wp_get_attachment_image_url($favicon_url, 'full');
                    }
                    ?>

                    <a href="<?php echo esc_url(home_url('/contatti/')); ?>" class="fi-btn fi-btn-primary">Contattaci</a>
                    <?php if (!empty($map_link) && $map_link !== '#') : ?>
                        <a href="<?php echo esc_url($map_link); ?>" target="_blank" rel="noopener noreferrer" class="fi-btn fi-btn-secondary"><i class="fas fa-directions"></i> Indicazioni</a>
                    <?php endif; ?>
                    
                    <?php 
                    if (!empty($favicon_url)) : 
                    ?>
                        <img src="<?php echo esc_url($favicon_url); ?>" alt="Icona" style="height: 130px; width: auto; max-width: 250px; object-fit: contain; z-index: 10;">
                    <?php endif; ?>
                </div>
                <div class="cta-bg-glow"></div>
                <div class="cta-botanical-overlay"></div>
            </div>
        </div>
    </div>

    <!-- MAIN FOOTER -->
    <footer class="fi-footer">
        
        <!-- Elementi naturali decorativi -->
        <div class="fi-footer-botanical botanical-left">
            <svg viewBox="0 0 200 400" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M50,400 Q80,200 0,0 Q120,50 150,200 Q180,350 50,400" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" fill="none" opacity="0.05"/>
                <circle cx="150" cy="200" r="3" fill="currentColor" opacity="0.05"/>
                <circle cx="20" cy="100" r="2" fill="currentColor" opacity="0.05"/>
            </svg>
        </div>
        <div class="fi-footer-botanical botanical-right">
            <svg viewBox="0 0 200 400" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M150,400 Q120,200 200,0 Q80,50 50,200 Q20,350 150,400" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" fill="none" opacity="0.05"/>
                <circle cx="50" cy="200" r="3" fill="currentColor" opacity="0.05"/>
                <circle cx="180" cy="100" r="2" fill="currentColor" opacity="0.05"/>
            </svg>
        </div>

        <div class="container relative-z">
            <div class="fi-footer-grid">
                
                <!-- Colonna 1: Info Brand -->
                <div class="footer-col brand-col">
                    <h3 class="footer-logo-text"><?php echo esc_html($fi_nome[0]); ?><?php if (isset($fi_nome[1])) : ?><br><?php echo esc_html($fi_nome[1]); ?><?php endif; ?></h3>
                    <?php if ('' !== $desc) : ?>
                    <p class="footer-desc"><?php echo esc_html($desc); ?></p>
                    <?php endif; ?>
                    <?php foreach (fi_heading('footer_brand')['badges'] as $fi_badge) : ?>
                    <div class="footer-badge">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" width="16" height="16"><circle cx="12" cy="8" r="7"></circle><polyline points="8.21 13.89 7 23 12 20 17 23 15.79 13.88"></polyline></svg>
                        <?php echo esc_html($fi_badge); ?>
                    </div>
                    <?php endforeach; ?>
                </div>

                <!-- Colonna 2: Link Rapidi -->
                <div class="footer-col links-col">
                    <h4>Navigazione</h4>
                    <?php
                    if (has_nav_menu('footer')) {
                        wp_nav_menu(array(
                            'theme_location' => 'footer',
                            'container'      => false,
                            'menu_class'     => 'footer-menu',
                        ));
                    } else {
                        // Fallback Menu
                        ?>
                        <ul class="footer-menu">
                            <li><a href="<?php echo home_url('/'); ?>">Home</a></li>
                            <li><a href="<?php echo home_url('/chi-siamo/'); ?>">Chi Siamo</a></li>
                            <li><a href="<?php echo home_url('/servizi/'); ?>">Servizi</a></li>
                            <li><a href="<?php echo home_url('/emergenze/'); ?>">Emergenze</a></li>
                            <li><a href="<?php echo home_url('/contatti/'); ?>">Contatti</a></li>
                        </ul>
                        <?php
                    }
                    ?>
                </div>

                <!-- Colonna 3: Contatti -->
                <div class="footer-col contacts-col">
                    <h4>Contatti</h4>
                    <ul class="footer-contacts">
                        <?php if ('' !== $address) : ?>
                        <li>
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path><circle cx="12" cy="10" r="3"></circle></svg>
                            <?php if ('' !== $map_link && '#' !== $map_link) : ?>
                                <a href="<?php echo esc_url($map_link); ?>" target="_blank" rel="noopener noreferrer"><?php echo wp_kses_post(nl2br($address)); ?></a>
                            <?php else : ?>
                                <span><?php echo wp_kses_post(nl2br($address)); ?></span>
                            <?php endif; ?>
                        </li>
                        <?php endif; ?>
                        <?php if ('' !== $phone) : ?>
                        <li>
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path></svg>
                            <a href="tel:<?php echo esc_attr($phone_clean); ?>"><?php echo esc_html($phone); ?></a>
                        </li>
                        <?php endif; ?>
                        <?php if ('' !== $email) : ?>
                        <li>
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path><polyline points="22,6 12,13 2,6"></polyline></svg>
                            <a href="mailto:<?php echo esc_attr($email); ?>"><?php echo esc_html($email); ?></a>
                        </li>
                        <?php endif; ?>
                    </ul>
                    
                    <?php $fi_social = farmaciainternazionale_social(); ?>
                    <?php if (!empty($fi_social)) : ?>
                    <ul class="footer-socials">
                        <?php foreach ($fi_social as $fi_rete) : ?>
                        <li>
                            <a href="<?php echo esc_url($fi_rete['url']); ?>"
                               class="footer-social footer-social--<?php echo esc_attr($fi_rete['chiave']); ?>"
                               target="_blank"
                               rel="noopener"
                               aria-label="<?php echo esc_attr($fi_rete['etichetta']); ?>">
                                <?php echo $fi_rete['svg']; // phpcs:ignore WordPress.Security.EscapeOutput -- SVG scritto nel tema, non dal pannello. ?>
                            </a>
                        </li>
                        <?php endforeach; ?>
                    </ul>
                    <?php endif; ?>
                </div>

                <!-- Colonna 4: Orari -->
                <div class="footer-col hours-col">
                    <h4>Orari di Apertura</h4>
                    <div class="footer-hours">
                    <?php 
                    $has_valid_hours = false;
                    $hours_html = '';

                    if (!empty($hours) && is_array($hours)) {
                        $days_map = array(
                            'monday'    => 'Lun',
                            'tuesday'   => 'Mar',
                            'wednesday' => 'Mer',
                            'thursday'  => 'Gio',
                            'friday'    => 'Ven',
                            'saturday'  => 'Sab',
                            'sunday'    => 'Dom',
                        );
                        
                        foreach ($days_map as $key => $label) {
                            $day_data = isset($hours[$key]) ? $hours[$key] : array();
                            if (isset($day_data['closed']) && $day_data['closed']) {
                                $hours_html .= '<p><strong>' . esc_html($label) . '</strong> <span>Chiuso</span></p>';
                            } else {
                                $slots = (isset($day_data['slots']) && is_array($day_data['slots'])) ? $day_data['slots'] : array();
                                $slots_strings = array();
                                foreach ($slots as $slot) {
                                    if (!empty($slot['open']) && !empty($slot['close'])) {
                                        $open = substr($slot['open'], 0, 5);
                                        $close = substr($slot['close'], 0, 5);
                                        $slots_strings[] = $open . ' - ' . $close;
                                        $has_valid_hours = true;
                                    }
                                }
                                $hours_str = !empty($slots_strings) ? implode(', ', $slots_strings) : 'Chiuso';
                                $hours_html .= '<p><strong>' . esc_html($label) . '</strong> <span>' . esc_html($hours_str) . '</span></p>';
                            }
                        }
                    } elseif (is_string($hours) && !empty($hours)) {
                        $hours_html = wp_kses_post(nl2br($hours));
                        $has_valid_hours = true;
                    }

                    if ($has_valid_hours) {
                        echo $hours_html;
                    } else {
                        // Fallback pulito quando tutti i giorni sono vuoti o chiusi (nessun orario impostato)
                        ?>
                        <p class="hours-fallback">Contattaci per confermare i nostri orari di apertura.</p>
                        <?php
                    }
                    ?>
                    </div>
                </div>

            </div>
        </div>

        <!-- BOTTOM BAR -->
        <div class="fi-footer-bottom">
            <div class="container">
                <div class="bottom-bar-content">
                    <div class="copyright">
                        &copy; <?php echo date('Y'); ?> Farmacia Internazionale. Tutti i diritti riservati.
                    </div>
                    <div class="bottom-links">
                        <?php
                        /*
                         * INFORMATIVA PRIVACY. Il collegamento si stampa solo se la
                         * pagina esiste davvero: un link a un'informativa che non c'e'
                         * e' peggio del non averlo. fi_privacy_url() prova prima quella
                         * dichiarata in Impostazioni → Privacy, poi lo slug.
                         */
                        $fi_privacy = function_exists('fi_privacy_url') ? fi_privacy_url() : '';
                        if ('' !== $fi_privacy) : ?>
                            <a href="<?php echo esc_url($fi_privacy); ?>">Privacy</a>
                        <?php endif; ?>
                        <?php
                        /*
                         * AREA RISERVATA.
                         *
                         * NON si punta a wp-admin: il tema padre (inc/security.php)
                         * maschera l'accesso su /tw-login e BLOCCA wp-admin a chi non e'
                         * autenticato, restituendo un 404. Un collegamento a wp-admin
                         * porterebbe quindi a una pagina inesistente proprio le persone
                         * che devono ancora entrare.
                         *
                         * Si usa wp_login_url() e non `home_url('/tw-login/')` scritto a
                         * mano come fanno gli altri child theme del progetto: il padre
                         * filtra quella funzione, quindi se un domani lo slug cambia in
                         * security.php questo collegamento segue da solo, mentre gli
                         * altri si romperebbero.
                         *
                         * Chi e' gia' entrato va diritto alla bacheca, senza passare da
                         * una schermata d'accesso che non gli serve.
                         *
                         * nofollow perche' non e' una pagina da indicizzare.
                         */
                        $fi_area_riservata = is_user_logged_in()
                            ? admin_url()
                            : wp_login_url(admin_url());
                        ?>
                        <a class="fi-area-riservata" href="<?php echo esc_url($fi_area_riservata); ?>" rel="nofollow">
                            <svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><rect x="5" y="11" width="14" height="10" rx="2" fill="none" stroke="currentColor" stroke-width="1.7"/><path d="M8 11V7.5a4 4 0 0 1 8 0V11" fill="none" stroke="currentColor" stroke-width="1.7"/></svg>
                            <?php esc_html_e('Area riservata', 'farmaciainternazionale-child-theme'); ?>
                        </a>
                        <a href="https://ticinoweb.com/" target="_blank" rel="noopener noreferrer">designed by ticinoWEB</a>
                    </div>
                </div>
            </div>
        </div>
    </footer>
</div>

<?php 
// get_template_part('animazione', 'treebanch'); 
get_template_part('dna', 'animation'); 
?>
<?php wp_footer(); ?>
</body>
</html>
