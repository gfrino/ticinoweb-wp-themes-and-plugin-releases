<?php
/**
 * Template Name: Contatti
 * Description: Pagina ufficiale dei contatti della farmacia.
 */

get_header();

// Recupero dati di contatto dal tema (dinamici o fallback vuoti)
$phone = get_option('ticinoweb_contact_phone', '');
$email = get_option('ticinoweb_contact_email', '');
$address = get_option('ticinoweb_contact_address', '');
$hours_raw = get_option('ticinoweb_contact_opening_hours', '');
$map_link = get_option('ticinoweb_contact_map_link', '');
$desc = fi_heading('contact_hero')['text'];

// Cleanup telefono per link
$phone_clean = !empty($phone) ? str_replace(array(' ', '(', ')', '-'), '', $phone) : '';

// Gestione Sicura Orari (Supporto CMS: array con slots e closed)
$hours_html = '';
if (!empty($hours_raw)) {
    if (is_array($hours_raw)) {
        $hours_html .= '<ul class="fi-hours-list">';
        foreach ($hours_raw as $day_name => $day_data) {
            if (!is_array($day_data)) {
                // Retro-compatibilità array semplice (key => value)
                if (!is_numeric($day_name)) {
                    $is_closed = (stripos($day_data, 'chius') !== false);
                    $time_class = $is_closed ? 'fi-time fi-time-closed' : 'fi-time';
                    $hours_html .= '<li><span class="fi-day">' . esc_html(ucfirst($day_name)) . '</span><span class="' . esc_attr($time_class) . '">' . esc_html($day_data) . '</span></li>';
                }
                continue;
            }

            // Mappatura giorni in italiano
            $days_it = [
                'monday'    => 'Lunedì',
                'tuesday'   => 'Martedì',
                'wednesday' => 'Mercoledì',
                'thursday'  => 'Giovedì',
                'friday'    => 'Venerdì',
                'saturday'  => 'Sabato',
                'sunday'    => 'Domenica'
            ];
            
            $day_name_lower = strtolower(trim($day_name));
            $day_label = isset($days_it[$day_name_lower]) ? $days_it[$day_name_lower] : ucfirst(str_replace('_', ' ', $day_name));
            
            // Logica del nuovo CMS
            if (isset($day_data['closed']) && $day_data['closed']) {
                $hours_html .= '<li><span class="fi-day">' . esc_html($day_label) . '</span><span class="fi-time fi-time-closed">Chiuso</span></li>';
            } elseif (isset($day_data['slots']) && is_array($day_data['slots'])) {
                $slots_text = [];
                foreach ($day_data['slots'] as $slot) {
                    if (!empty($slot['open']) && !empty($slot['close'])) {
                        $slots_text[] = esc_html($slot['open']) . ' - ' . esc_html($slot['close']);
                    }
                }
                if (!empty($slots_text)) {
                    $hours_html .= '<li><span class="fi-day">' . esc_html($day_label) . '</span><span class="fi-time">' . implode('<br>', $slots_text) . '</span></li>';
                } else {
                    $hours_html .= '<li><span class="fi-day">' . esc_html($day_label) . '</span><span class="fi-time fi-time-closed">Chiuso</span></li>';
                }
            }
        }
        
        // Aggiunta note orari se presenti
        $hours_note = get_option('ticinoweb_contact_opening_hours_note', '');
        if (!empty($hours_note)) {
            $hours_html .= '<li class="fi-hours-note text-center" style="margin-top: 15px; padding-top: 15px; border-top: 1px solid rgba(3,93,41,0.1); font-size: 0.95rem; color: var(--fi-text-muted); display: block;">' . wp_kses_post($hours_note) . '</li>';
        }
        
        $hours_html .= '</ul>';
    } elseif (is_string($hours_raw)) {
        // Fallback se è una stringa diretta
        $hours_html = wpautop(wp_kses_post($hours_raw));
    }
}
?>

<main id="primary" class="site-main fi-contatti-page">

    <!-- 1. HERO CONTATTI -->
    <section class="fi-servizi-hero fi-hero-compact">
        <div class="fi-hero-bg-glow glow-1"></div>
        <div class="container">
            <div class="fi-servizi-hero-content text-center">
                <div class="fi-hero-badges">
                    <?php fi_heading_badges('contact_hero'); ?>
                </div>
                <h1 class="fi-servizi-title"><?php echo esc_html(fi_heading('contact_hero')['title']); ?></h1>
                <?php if ('' !== $desc) : ?>
                <p class="fi-servizi-subtitle" style="max-width: 600px; margin: 0 auto;"><?php echo esc_html($desc); ?></p>
                <?php endif; ?>
            </div>
        </div>
    </section>

    <!-- 2. BLOCCO CONTATTI PRINCIPALE (2 COLONNE) -->
    <section class="fi-main-contacts-section">
        <div class="container">
            <div class="fi-contacts-main-layout">
                
                <!-- Colonna Sinistra: Card Principale -->
                <div class="fi-premium-card fi-main-card">
                    <div class="fi-pc-header">
                        <h2><?php echo esc_html(fi_heading('contact_card')['title']); ?></h2>
                        <?php if ('' !== fi_heading('contact_card')['text']) : ?><p><?php echo esc_html(fi_heading('contact_card')['text']); ?></p><?php endif; ?>
                    </div>
                    
                    <div class="fi-pc-body">
                        <?php if (!empty($address)): ?>
                        <div class="fi-contact-row">
                            <div class="fi-cr-icon">
                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>
                            </div>
                            <div class="fi-cr-text">
                                <strong>Vieni a trovarci</strong>
                                <span><?php echo wp_kses_post($address); ?></span>
                            </div>
                        </div>
                        <?php endif; ?>

                        <?php if (!empty($phone)): ?>
                        <div class="fi-contact-row">
                            <div class="fi-cr-icon">
                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/></svg>
                            </div>
                            <div class="fi-cr-text">
                                <strong>Chiamaci</strong>
                                <span><?php echo esc_html($phone); ?></span>
                            </div>
                        </div>
                        <?php endif; ?>

                        <?php if (!empty($email)): ?>
                        <div class="fi-contact-row">
                            <div class="fi-cr-icon">
                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>
                            </div>
                            <div class="fi-cr-text">
                                <strong>Scrivici</strong>
                                <span><?php echo esc_html($email); ?></span>
                            </div>
                        </div>
                        <?php endif; ?>
                    </div>

                    <div class="fi-pc-actions">
                        <?php if (!empty($phone)): ?>
                            <a href="tel:<?php echo esc_attr($phone_clean); ?>" class="fi-action-btn fi-action-primary">
                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/></svg>
                                Chiama ora
                            </a>
                        <?php endif; ?>
                        
                        <?php if (!empty($map_link) && $map_link !== '#'): ?>
                            <a href="<?php echo esc_url($map_link); ?>" target="_blank" rel="noopener noreferrer" class="fi-action-btn fi-action-secondary">
                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>
                                Indicazioni
                            </a>
                        <?php endif; ?>
                        
                        <?php if (!empty($email)): ?>
                            <a href="mailto:<?php echo esc_attr($email); ?>" class="fi-action-btn fi-action-outline">
                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>
                                Invia Email
                            </a>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Colonna Destra: Orari -->
                <?php if (!empty($hours_html)): ?>
                <div class="fi-premium-card fi-hours-card">
                    <div class="fi-pc-header">
                        <h2><?php echo esc_html(fi_heading('contact_hours')['title']); ?></h2>
                        <?php if ('' !== fi_heading('contact_hours')['text']) : ?><p><?php echo esc_html(fi_heading('contact_hours')['text']); ?></p><?php endif; ?>
                    </div>
                    <div class="fi-pc-body">
                        <?php echo $hours_html; // Già sanitizzato sopra ?>
                    </div>
                    <div class="fi-pc-icon-bg">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
                    </div>
                </div>
                <?php else: ?>
                <!-- Fallback se non ci sono orari: Mappa segnaposto elegante -->
                <div class="fi-premium-card fi-map-placeholder-card">
                    <div class="fi-pc-header">
                        <h2><?php echo esc_html(fi_heading('contact_where')['title']); ?></h2>
                        <?php if ('' !== fi_heading('contact_where')['text']) : ?><p><?php echo esc_html(fi_heading('contact_where')['text']); ?></p><?php endif; ?>
                    </div>
                    <div class="fi-pc-body text-center pt-4 pb-4">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1" width="80" height="80" style="color: var(--fi-green-accent); opacity: 0.5;"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>
                    </div>
                    <?php if (!empty($map_link) && $map_link !== '#'): ?>
                    <div class="fi-pc-actions justify-content-center">
                        <a href="<?php echo esc_url($map_link); ?>" target="_blank" rel="noopener noreferrer" class="fi-btn fi-btn-primary w-100">Apri Google Maps</a>
                    </div>
                    <?php endif; ?>
                </div>
                <?php endif; ?>

            </div>
        </div>
    </section>

    <!-- 3. MAPPA GOOGLE -->
    <section class="fi-contact-map-section bg-white pb-5" style="margin-bottom: 60px;">
        <div class="container">
            <div class="fi-contact-map-wrapper mb-5">
                <?php
                /*
                 * Prima qui c'era un embed scritto per esteso che inquadrava
                 * PIAZZA GRANDE, cioe' il posto sbagliato. Ora la mappa esce da
                 * farmaciainternazionale_map_embed_src(), che cerca la scheda
                 * dell'attivita': vedi il perche' in functions.php.
                 */
                $map_embed = farmaciainternazionale_map_embed_src(17);
                ?>
                <?php if ('' !== $map_embed) : ?>
                    <iframe
                        src="<?php echo esc_url($map_embed); ?>"
                        width="100%"
                        height="450"
                        style="border:0;"
                        title="Mappa: dove siamo"
                        allowfullscreen=""
                        loading="lazy"
                        referrerpolicy="no-referrer-when-downgrade">
                    </iframe>
                <?php endif; ?>
            </div>
        </div>
    </section>



</main>

<?php
get_footer();
