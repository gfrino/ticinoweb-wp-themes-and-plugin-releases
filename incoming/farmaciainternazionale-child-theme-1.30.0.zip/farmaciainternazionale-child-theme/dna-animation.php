<?php
/**
 * Animazione di sfondo presente su tutte le pagine.
 *
 * L'INDIRIZZO STA QUI E NON NEL PANNELLO, per scelta: e' un elemento grafico
 * fisso del tema, non un contenuto da cambiare. Per sostituirlo si modifica
 * questa riga.
 */
$fi_video_sfondo = 'https://strvid.nyc3.cdn.digitaloceanspaces.com/motionsite/dna_video.mp4';
?>
<div id="fi-global-dna-bg" aria-hidden="true">
    <?php /* Due elementi identici: il JavaScript alterna fra i due per far
             ripartire il filmato senza lo scatto del salto all'inizio. */ ?>
    <video id="dna-v1" class="fi-dna-video active" src="<?php echo esc_url($fi_video_sfondo); ?>" autoplay muted playsinline></video>
    <video id="dna-v2" class="fi-dna-video inactive" src="<?php echo esc_url($fi_video_sfondo); ?>" autoplay muted playsinline></video>
    <div class="fi-dna-overlay"></div>
</div>

<style>
#fi-global-dna-bg {
    position: fixed;
    top: 0;
    left: 0;
    width: 100vw;
    height: 100vh;
    z-index: -1;
    pointer-events: none;
    overflow: hidden;
}

#fi-global-dna-bg .fi-dna-video {
    width: 100%;
    height: 100%;
    object-fit: cover;
    position: absolute;
    top: 0;
    left: 0;
    z-index: -2;
    transition: opacity 2s ease-in-out; /* Morbida transizione di 2 secondi */
}

/* Regolazione della trasparenza per rendere l'animazione più leggera ma visibile */
#fi-global-dna-bg .fi-dna-video.active {
    opacity: 0.55; /* Via di mezzo tra 1.0 (prima) e 0.25 (ora) */
}
#fi-global-dna-bg .fi-dna-video.inactive {
    opacity: 0;
}

#fi-global-dna-bg .fi-dna-overlay {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    z-index: -1;
    /* Reso uniforme su tutto lo schermo invece che sfumato da sinistra a destra */
    background-color: rgba(255, 255, 255, 0.6); 
}

/* Rendi trasparenti i background solidi e applica sfumature di colore tra le sezioni
   (nessun 'buco' trasparente, ma morbide transizioni cromatiche) */
html, body {
    background-color: transparent !important;
}

/* Base per tutte le sezioni per garantire continuità (Hero, Intro, Storia, Categorie, Contatti, ecc) */
.fi-clean-hero, .fi-intro-section, .fi-history-section, .fi-categories-section, .fi-contact-section, .bg-white, .fi-bg-white, .fi-white-bg, .bg-light, .fi-bg-light, .fi-light-bg {
    background-color: rgba(255, 255, 255, 0.75) !important;
    background-image: none !important; /* Rimuove eventuali gradienti precedenti */
}

/* Sfumatura in uscita per i Servizi: svanisce nel vuoto prima della Natura */
.fi-services-section {
    background: linear-gradient(180deg, 
        rgba(255, 255, 255, 0.75) 0%, 
        rgba(255, 255, 255, 0.75) calc(100% - 150px), 
        rgba(255, 255, 255, 0) 100%
    ) !important;
}

/* Sfondo completamente trasparente per la sezione Natura */
.fi-nature-section {
    background-color: transparent !important;
}

/* Sfumatura in entrata per il Supporto: nasce dal vuoto dopo la Natura */
.fi-support-section {
    background: linear-gradient(180deg, 
        rgba(255, 255, 255, 0) 0%, 
        rgba(255, 255, 255, 0.75) 150px, 
        rgba(255, 255, 255, 0.75) 100%
    ) !important;
}

/* Nascondi i vecchi layer decorativi che "tagliano" i bordi creando stacchi netti */
.fi-services-watercolor-bg, 
.fi-nature-bg, 
.history-bg-noise, 
.fi-intro-bg-glow {
    display: none !important;
    opacity: 0 !important;
}

/* Rimuovi overflow: hidden dalle sezioni per evitare qualsiasi tipo di taglio netto */
.fi-nature-section, 
.fi-history-section, 
.fi-services-section {
    overflow: visible !important;
}

/* Estendi lo sfondo bianco della sezione contatti per coprire il margin-top del footer, 
   evitando che si veda la linea trasparente dietro la CTA del footer */
.fi-contact-section {
    padding-bottom: 160px !important;
    margin-bottom: -60px !important;
}

.fi-premium-card, .fi-contact-card, .fi-servizio-card, .fi-card, .fi-cat-card, .rm-card, .contact-box {
    background-color: rgba(255, 255, 255, 0.85) !important;
    backdrop-filter: blur(8px);
    border: 1px solid rgba(255, 255, 255, 0.3);
}
</style>

<script>
document.addEventListener("DOMContentLoaded", function() {
    const v1 = document.getElementById('dna-v1');
    const v2 = document.getElementById('dna-v2');
    if (!v1 || !v2) return;

    // Rallenta per un effetto più fluido ed elegante (es. 60% della velocità)
    v1.playbackRate = 0.6;
    v2.playbackRate = 0.6;

    const fadeDuration = 2; // Secondi di crossfade (stesso della transition CSS)
    let isV1Playing = true;

    function handleLoop(primary, secondary) {
        primary.addEventListener('timeupdate', function() {
            if (!primary.duration) return;
            const timeLeft = primary.duration - primary.currentTime;
            
            // Inizia il crossfade poco prima della fine
            if (timeLeft <= fadeDuration && secondary.paused) {
                secondary.currentTime = 0;
                secondary.play();
                secondary.classList.remove('inactive');
                secondary.classList.add('active');
                primary.classList.remove('active');
                primary.classList.add('inactive');
            }
            
            // Quando il primario finisce, mettilo in pausa e preparalo per il prossimo ciclo
            if (timeLeft <= 0.1) {
                primary.pause();
                primary.currentTime = 0;
            }
        });
    }

    handleLoop(v1, v2);
    handleLoop(v2, v1);
});
</script>
