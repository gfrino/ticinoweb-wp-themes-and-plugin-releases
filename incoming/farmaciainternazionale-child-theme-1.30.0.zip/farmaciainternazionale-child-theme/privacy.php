<?php
/**
 * Template Name: Informativa sulla privacy
 * Description: Informativa sul trattamento dei dati personali.
 *
 * IL TESTO STA QUI, NON NEL CONTENUTO DELLA PAGINA, perche' il database di questo
 * sito e' stato sovrascritto tre volte da altrettanti import: un'informativa
 * scritta nell'editor si perderebbe, mentre nel tema viaggia con Git e con lo zip.
 * I dati che cambiano — indirizzo, telefono, email — arrivano dal CMS, cosi' non
 * esistono due versioni dei recapiti che possono divergere.
 *
 * QUESTA DATA VA CAMBIATA A MANO quando si modifica il testo qui sotto. Non si usa
 * la data del file: un semplice ricaricamento del tema la sposterebbe senza che
 * una parola sia cambiata, e una data falsa su un'informativa e' peggio che
 * nessuna data.
 */

get_header();

$aggiornata = '21 agosto 2026';

$nome     = get_bloginfo('name');
$indirizzo = trim((string) get_option('ticinoweb_contact_address', ''));
$telefono = trim((string) get_option('ticinoweb_contact_phone', ''));
$email    = trim((string) get_option('ticinoweb_contact_email', ''));
$tel_link = preg_replace('/[^0-9+]/', '', $telefono);

/* La pagina dell'invio ricette esiste solo se il servizio e' stato attivato: si
   rimanda a lei soltanto in quel caso, invece di promettere una pagina che non c'e'. */
$pagina_ricette = absint(get_option('fi_ricette_page_provisioned', 0));
$url_ricette    = ($pagina_ricette && 'publish' === get_post_status($pagina_ricette))
    ? get_permalink($pagina_ricette)
    : '';
?>

<main id="primary" class="site-main fi-legale-page">

    <section class="fi-servizi-hero" style="padding: 150px 0 60px;">
        <div class="fi-hero-bg-glow glow-1"></div>
        <div class="container">
            <div class="text-center">
                <span class="fi-badge">Informativa</span>
                <h1 class="fi-servizi-title">Come trattiamo i tuoi dati</h1>
                <p class="fi-servizi-subtitle mx-auto" style="max-width: 640px;">
                    Questa pagina spiega quali dati raccoglie questo sito, cosa ne facciamo e per quanto tempo li conserviamo. È scritta per essere letta, non per essere accettata senza leggerla.
                </p>
            </div>
        </div>
    </section>

    <section class="fi-legale-corpo">
        <div class="container">
            <article class="fi-legale-testo">

                <p class="fi-legale-data">Ultimo aggiornamento: <strong><?php echo esc_html($aggiornata); ?></strong></p>

                <h2>Chi tratta i tuoi dati</h2>
                <p>
                    Il responsabile del trattamento è <strong><?php echo esc_html($nome); ?></strong><?php if ('' !== $indirizzo) : ?>, <?php echo esc_html(str_replace("\n", ', ', $indirizzo)); ?><?php endif; ?>.
                </p>
                <ul>
                    <?php if ('' !== $telefono) : ?>
                        <li>Telefono: <a href="tel:<?php echo esc_attr($tel_link); ?>"><?php echo esc_html($telefono); ?></a></li>
                    <?php endif; ?>
                    <?php if ('' !== $email) : ?>
                        <li>Email: <a href="mailto:<?php echo esc_attr($email); ?>"><?php echo esc_html($email); ?></a></li>
                    <?php endif; ?>
                </ul>
                <p>
                    Il trattamento è soggetto alla Legge federale svizzera sulla protezione dei dati (LPD). Per le persone che ci scrivono dall’Unione europea si applica, nei limiti previsti, anche il Regolamento europeo (GDPR).
                </p>
                <p>
                    In quanto farmacisti siamo inoltre vincolati al <strong>segreto professionale</strong> (art. 321 del Codice penale svizzero). Vale per tutto quello che ci dici, in farmacia come attraverso questo sito.
                </p>

                <h2>Se visiti il sito e non fai altro</h2>
                <p>
                    Non ti chiediamo di registrarti e non ti profiliamo. Succedono due cose:
                </p>
                <ul>
                    <li>
                        <strong>Il server registra la richiesta.</strong> Come qualunque sito, il nostro fornitore di hosting conserva per un periodo limitato i registri tecnici delle pagine richieste, che includono l’indirizzo IP. Servono a far funzionare il sito e a difenderlo dagli attacchi, non a sapere chi sei.
                    </li>
                    <li>
                        <strong>Contiamo le visite del giorno.</strong> Il sito deposita un cookie tecnico chiamato <code>ticinoweb_visit_</code> seguito dalla data, che dura <strong>24 ore</strong>. Serve solo a non contare due volte la stessa persona nello stesso giorno. Quello che finisce nel nostro archivio è un numero per data — quante visite, non chi — e non contiene né il tuo indirizzo IP né altro che ti riguardi.
                    </li>
                </ul>
                <p>
                    Su questo sito <strong>non sono attivi Google Analytics né altri strumenti di statistica o pubblicità</strong> che seguano le persone da un sito all’altro.
                </p>

                <h2>Se ci mandi una ricetta dal sito</h2>
                <?php if ('' !== $url_ricette) : ?>
                    <p>
                        Dalla pagina <a href="<?php echo esc_url($url_ricette); ?>">Invio ricette</a> ci mandi dati sanitari, che la legge protegge in modo particolare. Ecco esattamente cosa succede.
                    </p>
                <?php else : ?>
                    <p>
                        Se attraverso il sito ci mandi una ricetta, ci stai mandando dati sanitari, che la legge protegge in modo particolare. Ecco esattamente cosa succede.
                    </p>
                <?php endif; ?>
                <p><strong>Cosa ci arriva:</strong> il tuo numero di telefono, la fotografia o il PDF della ricetta e, se la carichi, quella della tessera della cassa malati. Nient’altro: il modulo non chiede né nome né indirizzo.</p>
                <p><strong>Dove finisce:</strong> i file <strong>non entrano nella libreria immagini del sito e non vengono salvati nel database</strong>. Restano in una cartella temporanea del server, con un nome casuale e leggibili soltanto dal sistema, per il tempo necessario a inoltrarli — poi vengono cancellati.</p>
                <p><strong>Come ci arrivano:</strong> per email, all’indirizzo della farmacia dedicato a questo servizio. L’invio passa dal servizio di posta configurato sul sito, che gestisce il messaggio per il tempo della consegna.</p>
                <p><strong>Perché lo facciamo:</strong> per preparare la tua richiesta e per poterti richiamare se qualcosa non è chiaro. Senza questi dati non possiamo evadere la ricetta.</p>
                <p><strong>Per quanto tempo:</strong> il sito non conserva nulla. Il messaggio e i suoi allegati entrano nella normale gestione documentale della farmacia e seguono i termini di conservazione previsti per la documentazione farmaceutica.</p>
                <p>
                    Nel modulo c’è una casella che ti chiede di acconsentire: quel consenso riguarda esattamente quanto scritto qui. Se preferisci non usare il sito, la ricetta puoi portarla o telefonarci: non cambia nulla per te.
                </p>

                <h2>Se ci scrivi o ci telefoni</h2>
                <p>
                    Se ci mandi un’email o ci chiami, trattiamo quello che ci dici per risponderti. È il modo più diretto, ed è anche quello che lascia meno tracce sul sito: un’email arriva alla nostra casella e non passa da questo sito web.
                </p>
                <p>
                    Una nota pratica: <strong>l’email non è un canale riservato</strong>. Se devi parlarci di qualcosa di delicato, la telefonata o due parole al banco sono più sicure — un messaggio scritto resta nella posta inviata di chi lo manda, e su un telefono condiviso può essere letto da altri.
                </p>

                <h2>Cookie e memoria del browser</h2>
                <ul>
                    <li><strong>Cookie di conteggio giornaliero</strong> — quello descritto sopra, 24 ore, tecnico.</li>
                    <li><strong>Cookie di accesso</strong> — solo per chi lavora in farmacia e entra nell’area riservata. Se sei un visitatore non ne ricevi nessuno.</li>
                    <li><strong>Memoria del browser</strong> — quando il sito mostra un avviso in primo piano, può ricordare nel tuo browser che l’hai già chiuso, per non riproportelo. È un dato che resta sul tuo dispositivo, non arriva a noi, e si cancella svuotando i dati del sito dal browser.</li>
                    <li><strong>Cookie della lingua</strong> — se scegli una lingua diversa dall’italiano cliccando una bandiera, viene depositato un cookie chiamato <code>googtrans</code> che ricorda la tua scelta. Se non tocchi le bandiere non viene creato.</li>
                </ul>
                <p>
                    Nessuno di questi serve a pubblicità o a profilazione: contano le visite, ti fanno restare collegato se lavori qui, o ricordano una tua scelta. Per questo il sito non ti mette davanti una finestra di consenso ai cookie: non ci sono cookie per cui chiedertelo.
                </p>

                <h2>Servizi di altri che il sito richiama</h2>
                <p>
                    Alcune parti del sito arrivano da fornitori esterni. Quando la pagina li carica, il tuo browser si collega a loro e quei fornitori vedono almeno il tuo indirizzo IP e la pagina da cui arriva la richiesta. Sono questi:
                </p>
                <ul>
                    <li>
                        <strong>Google Translate</strong> — la traduzione del sito in tedesco, francese e inglese. È importante che tu lo sappia: quando scegli una di queste lingue, <strong>il testo delle pagine che visiti viene inviato a Google</strong> per essere tradotto. La traduzione è automatica, quindi può contenere imprecisioni: <strong>in italiano, che è la lingua originale, non passa nulla da Google</strong> e nessuna traduzione viene richiesta. Se preferisci non coinvolgere Google, ti basta non toccare le bandiere.
                    </li>
                    <li><strong>Google Fonts</strong> — i caratteri tipografici del sito.</li>
                    <li><strong>Google Maps</strong> — la mappa con la posizione della farmacia. La mappa è una finestra ospitata da Google, che applica le proprie regole sui dati.</li>
                    <li><strong>jsDelivr</strong> — la libreria che fa scorrere le fotografie in home page.</li>
                    <li><strong>DigitalOcean Spaces</strong> — il breve filmato che fa da sfondo alle pagine.</li>
                    <li><strong>Unsplash</strong> — alcune fotografie d’archivio non ancora sostituite con foto nostre.</li>
                    <li><strong>Il servizio di posta</strong> che consegna i messaggi del modulo ricette, e <strong>il fornitore di hosting</strong> su cui il sito è ospitato.</li>
                </ul>
                <p>
                    Non abbiamo alcun accordo pubblicitario con nessuno di loro e non gli mandiamo i tuoi dati sanitari, con l’unica eccezione del servizio di posta, che deve necessariamente trasportare il messaggio.
                </p>

                <h2>Come proteggiamo tutto questo</h2>
                <p>
                    Il sito viaggia su connessione cifrata. Il modulo delle ricette accetta solo immagini e PDF, controlla il contenuto reale dei file e non solo il nome, limita quanti e quanto grandi possono essere, e conserva i file temporanei in modo che nessun altro utente del server possa leggerli. Contro gli invii automatici usiamo un limite di frequenza calcolato su un identificatore non reversibile: <strong>il tuo indirizzo IP non viene memorizzato</strong> per questo scopo.
                </p>

                <h2>I tuoi diritti</h2>
                <p>Puoi chiederci, in qualsiasi momento e gratuitamente:</p>
                <ul>
                    <li>quali dati che ti riguardano abbiamo e da dove vengono;</li>
                    <li>di correggerli, se sono sbagliati;</li>
                    <li>di cancellarli, quando non abbiamo un obbligo di legge di conservarli;</li>
                    <li>di limitarne l’uso o di opporti a un trattamento;</li>
                    <li>di ricevere in un formato leggibile i dati che ci hai dato tu;</li>
                    <li>di revocare un consenso che ci avevi dato. Revocarlo non rende illecito quello che è stato fatto prima.</li>
                </ul>
                <p>
                    Ci scrivi<?php if ('' !== $email) : ?> a <a href="mailto:<?php echo esc_attr($email); ?>"><?php echo esc_html($email); ?></a><?php endif; ?><?php if ('' !== $telefono) : ?> o ci telefoni al <a href="tel:<?php echo esc_attr($tel_link); ?>"><?php echo esc_html($telefono); ?></a><?php endif; ?>. Per proteggere te, prima di darti informazioni potremmo chiederti di dimostrare che sei chi dici di essere.
                </p>
                <p>
                    Se ritieni che il trattamento non sia corretto puoi rivolgerti all’Incaricato federale della protezione dei dati e della trasparenza (IFPDT), a Berna.
                </p>

                <h2>Se questa pagina cambia</h2>
                <p>
                    Se cambia il modo in cui trattiamo i dati, aggiorniamo questa pagina e la data in cima. Vale la versione che leggi qui.
                </p>

            </article>
        </div>
    </section>

</main>

<?php get_footer(); ?>
