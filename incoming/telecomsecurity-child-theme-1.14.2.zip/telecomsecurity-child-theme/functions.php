<?php
/**
 * Telecom Security Child Theme Functions
 *
 * @package TelecomSecurityChild
 * @version 1.14.2
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'TELECOMSECURITY_THEME_VERSION', '1.14.2' );

// Include helper per la homepage e dati CMS
require_once get_stylesheet_directory() . '/inc/home-functions.php';
require_once get_stylesheet_directory() . '/inc/contact-functions.php';
require_once get_stylesheet_directory() . '/inc/telenews-functions.php';
require_once get_stylesheet_directory() . '/inc/media-gallery-functions.php';
require_once get_stylesheet_directory() . '/inc/services-admin.php';
require_once get_stylesheet_directory() . '/inc/service-content.php';
require_once get_stylesheet_directory() . '/inc/service-content-admin.php';

// Include gestione e helper per la sezione "Il nostro metodo"
require_once get_stylesheet_directory() . '/inc/method-functions.php';
require_once get_stylesheet_directory() . '/inc/method-admin.php';

require_once get_stylesheet_directory() . '/inc/header-menu.php';
require_once get_stylesheet_directory() . '/inc/legal-pages.php';

// Include componente Security Signal Rail
require_once get_stylesheet_directory() . '/inc/signal-rail.php';

/**
 * Setup child theme supports and navigation menus.
 */
function telecomsecurity_child_setup(): void {
	// Carica textdomain per le traduzioni del child theme
	load_child_theme_textdomain( 'telecomsecurity-child-theme', get_stylesheet_directory() . '/languages' );

	// Supporti standard del tema
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'align-wide' );
	add_theme_support( 'responsive-embeds' );
	add_theme_support(
		'html5',
		array(
			'search-form',
			'comment-form',
			'comment-list',
			'gallery',
			'caption',
			'style',
			'script',
		)
	);

	// Registrazione menu di navigazione
	register_nav_menus(
		array(
			'primary'   => __( 'Menu Principale (Header)', 'telecomsecurity-child-theme' ),
			'footer'    => __( 'Menu Footer', 'telecomsecurity-child-theme' ),
			'secondary' => __( 'Menu Secondario / Utility', 'telecomsecurity-child-theme' ),
		)
	);
}
add_action( 'after_setup_theme', 'telecomsecurity_child_setup' );

/**
 * Enqueue parent and child stylesheets and scripts cleanly.
 *
 * Sincronizza lo stile del parent theme, carica lo stile child globale
 * e include selettivamente gli asset della Home solo dove necessari.
 */
function telecomsecurity_child_enqueue_styles(): void {
	$parent_theme = wp_get_theme( get_template() );
	$child_theme  = wp_get_theme();

	$parent_version = $parent_theme->exists() ? $parent_theme->get( 'Version' ) : '1.0.0';
	$child_version  = $child_theme->exists() ? $child_theme->get( 'Version' ) : TELECOMSECURITY_THEME_VERSION;

	// De-registra l'handle del parent registrato con get_stylesheet_uri()
	wp_dequeue_style( 'ticinoweb-ai-style' );
	wp_deregister_style( 'ticinoweb-ai-style' );

	// Carica il CSS reale del parent theme
	wp_enqueue_style(
		'ticinoweb-ai-style',
		get_template_directory_uri() . '/style.css',
		array(),
		$parent_version
	);

	// Carica il CSS del child theme
	wp_enqueue_style(
		'telecomsecurity-child-style',
		get_stylesheet_uri(),
		array( 'ticinoweb-ai-style' ),
		$child_version
	);

	// Carica Security Signal Rail su tutto il frontend
	wp_enqueue_style(
		'telecomsecurity-signal-rail-style',
		get_stylesheet_directory_uri() . '/assets/css/signal-rail.css',
		array( 'telecomsecurity-child-style' ),
		(string) filemtime( get_stylesheet_directory() . '/assets/css/signal-rail.css' )
	);

	wp_enqueue_script(
		'telecomsecurity-signal-rail-js',
		get_stylesheet_directory_uri() . '/assets/js/signal-rail.js',
		array(),
		(string) filemtime( get_stylesheet_directory() . '/assets/js/signal-rail.js' ),
		true
	);

	// Enqueue selettivo per la Homepage
	if ( is_front_page() ) {
		wp_enqueue_style(
			'telecomsecurity-preloader',
			get_stylesheet_directory_uri() . '/assets/css/preloader.css',
			array( 'telecomsecurity-child-style' ),
			(string) filemtime( get_stylesheet_directory() . '/assets/css/preloader.css' )
		);

		wp_enqueue_script(
			'telecomsecurity-preloader',
			get_stylesheet_directory_uri() . '/assets/js/preloader.js',
			array(),
			(string) filemtime( get_stylesheet_directory() . '/assets/js/preloader.js' ),
			false
		);
		$preloader_data = telecomsecurity_get_preloader_data();
		wp_add_inline_script(
			'telecomsecurity-preloader',
			'window.telecomsecurityPreloaderConfig=' . wp_json_encode(
				array(
					'isHome'      => true,
					'sessionKey'  => $preloader_data['session_key'],
					'loadingText' => $preloader_data['loading_text'],
					'readyText'   => $preloader_data['ready_text'],
					'minimumMs'   => 1600,
					'maximumMs'   => 6000,
					'technicalMs' => 1800,
				)
			) . ';',
			'before'
		);

		wp_enqueue_style(
			'telecomsecurity-home-style',
			get_stylesheet_directory_uri() . '/assets/css/home.css',
			array( 'telecomsecurity-child-style', 'telecomsecurity-signal-rail-style' ),
			(string) filemtime( get_stylesheet_directory() . '/assets/css/home.css' )
		);

		// Existing repository GSAP distribution, bundled locally for a portable child theme.
		wp_enqueue_script( 'telecomsecurity-gsap', get_stylesheet_directory_uri() . '/assets/vendor/gsap.min.js', array(), '3.15.0', true );
		wp_enqueue_script( 'telecomsecurity-scrolltrigger', get_stylesheet_directory_uri() . '/assets/vendor/ScrollTrigger.min.js', array( 'telecomsecurity-gsap' ), '3.15.0', true );

		wp_enqueue_script(
			'telecomsecurity-home-js',
			get_stylesheet_directory_uri() . '/assets/js/home.js',
			array( 'telecomsecurity-scrolltrigger' ),
			(string) filemtime( get_stylesheet_directory() . '/assets/js/home.js' ),
			true
		);
	}

	if ( is_front_page() || is_page( 'chi-siamo' ) ) {
		$partner_dependencies = is_front_page()
			? array( 'telecomsecurity-home-style' )
			: array( 'telecomsecurity-child-style', 'telecomsecurity-signal-rail-style' );
		wp_enqueue_style(
			'telecomsecurity-partners',
			get_stylesheet_directory_uri() . '/assets/css/partners.css',
			$partner_dependencies,
			(string) filemtime( get_stylesheet_directory() . '/assets/css/partners.css' )
		);
	}

	if ( is_page() && function_exists( 'telecomsecurity_is_service_page' ) && telecomsecurity_is_service_page( get_queried_object_id() ) ) {
		wp_enqueue_style(
			'telecomsecurity-service-single',
			get_stylesheet_directory_uri() . '/assets/css/service-single.css',
			array( 'telecomsecurity-child-style', 'telecomsecurity-signal-rail-style' ),
			(string) filemtime( get_stylesheet_directory() . '/assets/css/service-single.css' )
		);
		wp_enqueue_script(
			'telecomsecurity-service-single',
			get_stylesheet_directory_uri() . '/assets/js/service-single.js',
			array(),
			(string) filemtime( get_stylesheet_directory() . '/assets/js/service-single.js' ),
			true
		);
	}

	if ( is_page( 'chi-siamo' ) ) {
		wp_enqueue_style(
			'telecomsecurity-about-page',
			get_stylesheet_directory_uri() . '/assets/css/about.css',
			array( 'telecomsecurity-partners' ),
			(string) filemtime( get_stylesheet_directory() . '/assets/css/about.css' )
		);
	}

	if ( function_exists( 'telecomsecurity_contact_is_page' ) && telecomsecurity_contact_is_page() ) {
		wp_enqueue_style(
			'telecomsecurity-contact-page',
			get_stylesheet_directory_uri() . '/assets/css/contact.css',
			array( 'telecomsecurity-child-style' ),
			(string) filemtime( get_stylesheet_directory() . '/assets/css/contact.css' )
		);
		wp_enqueue_script(
			'telecomsecurity-contact-page',
			get_stylesheet_directory_uri() . '/assets/js/contact.js',
			array(),
			(string) filemtime( get_stylesheet_directory() . '/assets/js/contact.js' ),
			true
		);
		wp_localize_script(
			'telecomsecurity-contact-page',
			'telecomsecurityContactConfig',
			array(
				'ajaxUrl'      => admin_url( 'admin-ajax.php' ),
				'tokenAction'  => 'telecomsecurity_contact_token',
				'submitAction' => 'telecomsecurity_contact_submit',
				'genericError' => __( 'Non è stato possibile inviare la richiesta. Controlla i campi e riprova.', 'telecomsecurity-child-theme' ),
				'networkError' => __( 'La connessione si è interrotta. Riprova oppure contattaci telefonicamente.', 'telecomsecurity-child-theme' ),
			)
		);
	}

	if ( is_page( 'telenews' ) || is_singular( 'post' ) ) {
		wp_enqueue_style(
			'telecomsecurity-telenews',
			get_stylesheet_directory_uri() . '/assets/css/telenews.css',
			array( 'telecomsecurity-child-style', 'telecomsecurity-signal-rail-style' ),
			(string) filemtime( get_stylesheet_directory() . '/assets/css/telenews.css' )
		);
	}

	if ( is_page( 'telenews' ) ) {
		wp_enqueue_script(
			'telecomsecurity-telenews',
			get_stylesheet_directory_uri() . '/assets/js/telenews.js',
			array(),
			(string) filemtime( get_stylesheet_directory() . '/assets/js/telenews.js' ),
			true
		);
	}
}
add_action( 'wp_enqueue_scripts', 'telecomsecurity_child_enqueue_styles', 20 );

// Shared header assets follow Home overrides and also load on internal pages.
add_action('wp_enqueue_scripts', function () {
    $deps = array('telecomsecurity-child-style');
    if (is_front_page()) $deps[] = 'telecomsecurity-home-style';
    wp_enqueue_style('telecomsecurity-header', get_stylesheet_directory_uri() . '/assets/css/header.css', $deps, filemtime(get_stylesheet_directory() . '/assets/css/header.css'));
    wp_enqueue_script('telecomsecurity-header', get_stylesheet_directory_uri() . '/assets/js/header.js', array(), filemtime(get_stylesheet_directory() . '/assets/js/header.js'), true);
	if ( ! is_front_page() ) {
		$preloader_data = telecomsecurity_get_preloader_data();
		wp_add_inline_script( 'telecomsecurity-header', 'try{sessionStorage.setItem(' . wp_json_encode( $preloader_data['session_key'] ) . ',"1")}catch(e){}', 'before' );
	}
}, 30);


/**
 * Aggiunge classi body personalizzate per il child theme.
 *
 * @param array $classes Classi body esistenti.
 * @return array Classi body modificate.
 */
function telecomsecurity_body_classes( array $classes ): array {
	$classes[] = 'telecomsecurity-theme';
	if ( is_front_page() ) {
		$classes[] = 'ts-front-page';
	}
	if ( function_exists( 'telecomsecurity_is_services_archive' ) && telecomsecurity_is_services_archive() ) {
		$classes[] = 'ts-services-archive';
	}
	if ( is_page() && function_exists( 'telecomsecurity_is_service_page' ) && telecomsecurity_is_service_page( get_queried_object_id() ) ) {
		$classes[] = 'ts-service-page';
	}
	if ( is_page( 'chi-siamo' ) ) {
		$classes[] = 'ts-about-page';
	}
	if ( function_exists( 'telecomsecurity_contact_is_page' ) && telecomsecurity_contact_is_page() ) {
		$classes[] = 'ts-contact-page';
	}
	if ( is_page( 'telenews' ) ) {
		$classes[] = 'ts-telenews-page-view';
	}
	if ( is_singular( 'post' ) ) {
		$classes[] = 'ts-telenews-single-view';
	}
	return $classes;
}
add_filter( 'body_class', 'telecomsecurity_body_classes' );

/**
 * Redirect 301 canonici per i vecchi URL dei servizi verso i nuovi URL ufficiali.
 */
function telecomsecurity_service_legacy_301_redirects(): void {
	if ( is_admin() || wp_doing_ajax() ) {
		return;
	}

	$request_uri = isset( $_SERVER['REQUEST_URI'] ) ? (string) $_SERVER['REQUEST_URI'] : '';
	$raw_path    = trim( (string) parse_url( $request_uri, PHP_URL_PATH ), '/' );

	// Mappa dei vecchi percorsi verso i nuovi percorsi ufficiali
	$redirect_map = array(
		'telecomsecurity/servizi/impianti-antintrusione' => 'telecomsecurity/servizi/allarmi-scasso-tradizionali-via-radio/',
		'telecomsecurity/servizi/rilevazione-incendio'   => 'telecomsecurity/servizi/allarmi-fuoco/',
		'telecomsecurity/servizi/videosorveglianza'      => 'telecomsecurity/servizi/sistemi-sorveglianza-video/',
		'telecomsecurity/servizi/multimedia'             => 'telecomsecurity/servizi/sonorizzazione-diffusione-musicale-proiezione-video/',
		'telecomsecurity/servizi/reti-radio'             => 'telecomsecurity/servizi/telecomunicazioni-grandi-reti-radio/',
		'telecomsecurity/servizi/telecomunicazioni-e-natel' => 'telecomsecurity/servizi/telecomunicazioni-grandi-reti-radio/',
		'servizi/impianti-antintrusione'                 => 'telecomsecurity/servizi/allarmi-scasso-tradizionali-via-radio/',
		'servizi/rilevazione-incendio'                   => 'telecomsecurity/servizi/allarmi-fuoco/',
		'servizi/videosorveglianza'                      => 'telecomsecurity/servizi/sistemi-sorveglianza-video/',
		'servizi/multimedia'                             => 'telecomsecurity/servizi/sonorizzazione-diffusione-musicale-proiezione-video/',
		'servizi/reti-radio'                             => 'telecomsecurity/servizi/telecomunicazioni-grandi-reti-radio/',
		'servizi/telecomunicazioni-e-natel'              => 'telecomsecurity/servizi/telecomunicazioni-grandi-reti-radio/',
	);

	foreach ( $redirect_map as $old_path => $new_relative_url ) {
		if ( $raw_path === $old_path ) {
			wp_safe_redirect( home_url( '/' . ltrim( str_replace( 'telecomsecurity/', '', $new_relative_url ), '/' ) ), 301 );
			exit;
		}
	}
}
add_action( 'template_redirect', 'telecomsecurity_service_legacy_301_redirects', 1 );

/** Redirect the retired Gallery route to the renamed TeleNews page. */
function telecomsecurity_gallery_to_telenews_redirect(): void {
	if ( is_admin() || wp_doing_ajax() ) {
		return;
	}

	$request_uri  = isset( $_SERVER['REQUEST_URI'] ) ? (string) $_SERVER['REQUEST_URI'] : '';
	$request_path = untrailingslashit( rawurldecode( (string) wp_parse_url( $request_uri, PHP_URL_PATH ) ) );
	$gallery_path = untrailingslashit( rawurldecode( (string) wp_parse_url( home_url( '/galleria/' ), PHP_URL_PATH ) ) );

	if ( '' !== $request_path && $request_path === $gallery_path ) {
		wp_safe_redirect( home_url( '/telenews/' ), 301 );
		exit;
	}
}
add_action( 'template_redirect', 'telecomsecurity_gallery_to_telenews_redirect', 0 );

require_once get_stylesheet_directory() . '/inc/secure-geometry.php';
require_once get_stylesheet_directory() . '/inc/identity-admin.php';
