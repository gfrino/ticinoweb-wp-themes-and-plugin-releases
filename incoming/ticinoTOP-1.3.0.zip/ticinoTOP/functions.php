<?php
/**
 * Ticino Top Theme functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package Ticino Top
 * @since 1.0.0
 */

function ticinotop_enqueue_styles() {
    // Il parent accoda get_stylesheet_uri() (= questo style.css) come 'ticinoweb-ai-style' insieme a Poppins da Google Fonts:
    // il child lo riaccoda con la propria versione, quindi senza dequeue il file arrivava due volte e Poppins (non usato) da Google.
    wp_dequeue_style( 'ticinoweb-ai-style' );
    wp_dequeue_style( 'poppins-font' );

    $parent_version = wp_get_theme( get_template() )->get( 'Version' );
    wp_enqueue_style( 'parent-style', get_template_directory_uri() . '/style.css', array(), $parent_version );
    $version = filemtime( get_stylesheet_directory() . '/style.css' );
    wp_enqueue_style( 'child-style', get_stylesheet_uri(), array( 'parent-style' ), $version );
}
add_action( 'wp_enqueue_scripts', 'ticinotop_enqueue_styles', 20 );

function ticinotop_register_menus() {
    register_nav_menus( array(
        'primary' => __( 'Menu Principale', 'ticinotop' ),
    ) );
}
add_action( 'after_setup_theme', 'ticinotop_register_menus', 20 );

/**
 * Smart fallback callback for WordPress nav menus.
 * 1. Automatically loads the first available custom menu if none is assigned to a theme location.
 * 2. Displays the elegant hardcoded links if no custom menus exist in the system.
 */
function ticinotop_menu_fallback( $args ) {
    $menus = wp_get_nav_menus();
    if ( ! empty( $menus ) ) {
        // Fallback to the first created custom menu
        unset( $args['theme_location'] ); // CRITICAL FIX: allow menu parameter to load correctly
        $args['menu'] = $menus[0]->term_id;
        $args['fallback_cb'] = false; // Prevent infinite loop
        wp_nav_menu( $args );
    } else {
        $hide_classifiche = get_theme_mod( 'ticinotop_hide_classifiche_evidenza', false );
        // Fallback to static prototype links
        if ( isset($args['menu_class']) && $args['menu_class'] === 'tt-footer-menu' ) {
            echo '<ul class="tt-footer-menu">';
            echo '<li><a href="' . esc_url(home_url('/')) . '">Home</a></li>';
            if ( ! $hide_classifiche ) {
                echo '<li><a href="' . esc_url(home_url('/classifica/')) . '">Classifiche</a></li>';
            }
            echo '<li><a href="' . esc_url(home_url('/categorie/')) . '">Categorie</a></li>';
            echo '<li><a href="' . esc_url(home_url('/awards/')) . '">Awards</a></li>';
            echo '<li><a href="' . esc_url(home_url('/magazine/')) . '">Blog</a></li>';
            echo '<li><a href="' . esc_url(home_url('/topscan/')) . '">TopScan</a></li>';
            echo '<li><a href="' . esc_url(home_url('/chi-siamo/')) . '">Chi Siamo</a></li>';
            echo '<li><a href="' . esc_url(home_url('/candidati/')) . '">Candidati</a></li>';
            echo '</ul>';
        } else {
            echo '<a href="' . esc_url(home_url('/')) . '">Home</a>';
            if ( ! $hide_classifiche ) {
                echo '<a href="' . esc_url(home_url('/classifica/')) . '">Classifiche</a>';
            }
            echo '<a href="' . esc_url(home_url('/categorie/')) . '">Categorie</a>';
            echo '<a href="' . esc_url(home_url('/awards/')) . '">Awards</a>';
            echo '<a href="' . esc_url(home_url('/magazine/')) . '">Blog</a>';
            echo '<a href="' . esc_url(home_url('/topscan/')) . '">TopScan</a>';
            echo '<a href="' . esc_url(home_url('/chi-siamo/')) . '">Chi Siamo</a>';
        }
    }
}

// Include Custom Post Types and Meta Boxes
require_once get_stylesheet_directory() . '/inc/post-types.php';
require_once get_stylesheet_directory() . '/inc/badges.php';
require_once get_stylesheet_directory() . '/inc/google-rating.php';

// AI Scanner Engine Backend
require_once get_stylesheet_directory() . '/inc/ai-scanner.php';

// AJAX Search Autocomplete
add_action('wp_ajax_nopriv_tt_autocomplete_search', 'tt_autocomplete_search_handler');
add_action('wp_ajax_tt_autocomplete_search', 'tt_autocomplete_search_handler');

function tt_autocomplete_search_handler() {
    $keyword = isset($_POST['keyword']) ? sanitize_text_field($_POST['keyword']) : '';
    
    if (strlen($keyword) < 2) {
        wp_send_json_success([]);
    }

    $args = [
        'post_type' => 'azienda',
        'post_status' => 'publish',
        'posts_per_page' => 5,
        's' => $keyword
    ];

    $query = new WP_Query($args);
    $results = [];

    if ($query->have_posts()) {
        while ($query->have_posts()) {
            $query->the_post();
            
            $terms = get_the_terms(get_the_ID(), 'categoria_azienda');
            $cat_name = ($terms && !is_wp_error($terms)) ? $terms[0]->name : '';
            
            $results[] = [
                'title' => get_the_title(),
                'url' => get_permalink(),
                'category' => $cat_name,
                'score' => get_post_meta(get_the_ID(), '_tt_voto', true),
            ];
        }
        wp_reset_postdata();
    }

    wp_send_json_success($results);
}

// -----------------------------------------------------------------------------
// Smart Search (Keywords & Taxonomies)
// -----------------------------------------------------------------------------

function tt_extend_search( $search, $wp_query ) {
    global $wpdb;

    if ( empty( $search ) ) {
        return $search;
    }

    $q = $wp_query->query_vars;
    
    // Solo per la ricerca principale o per il nostro AJAX
    if ( (is_search() || (defined('DOING_AJAX') && DOING_AJAX && isset($_POST['action']) && $_POST['action'] === 'tt_autocomplete_search')) && isset($q['s']) ) {
        
        $search = '';
        $searchand = '';
        $n = ! empty( $q['exact'] ) ? '' : '%';
        
        $search_terms = array_filter( array_map( 'trim', explode( ' ', $q['s'] ) ) );
        
        foreach ( (array) $search_terms as $term ) {
            $term = esc_sql( $wpdb->esc_like( $term ) );
            $like = $n . $term . $n;
            
            $search .= "{$searchand}(
                ($wpdb->posts.post_title LIKE '{$like}') OR 
                ($wpdb->posts.post_content LIKE '{$like}') OR 
                ($wpdb->posts.post_excerpt LIKE '{$like}') OR 
                (tt_meta.meta_value LIKE '{$like}') OR 
                (tt_terms.name LIKE '{$like}')
            )";
            $searchand = ' AND ';
        }
        
        if ( ! empty( $search ) ) {
            $search = " AND ({$search}) ";
            if ( ! is_user_logged_in() ) {
                $search .= " AND ($wpdb->posts.post_password = '') ";
            }
        }
    }

    return $search;
}
add_filter( 'posts_search', 'tt_extend_search', 10, 2 );

function tt_search_join( $join, $wp_query ) {
    global $wpdb;
    if ( (is_search() || (defined('DOING_AJAX') && DOING_AJAX && isset($_POST['action']) && $_POST['action'] === 'tt_autocomplete_search')) && !empty($wp_query->query_vars['s']) ) {
        // Solo le keywords: il join su tutti i meta moltiplicava le righe e cercava anche nei meta privati
        $join .= " LEFT JOIN $wpdb->postmeta tt_meta ON ($wpdb->posts.ID = tt_meta.post_id AND tt_meta.meta_key = '_tt_keywords') ";
        $join .= " LEFT JOIN $wpdb->term_relationships tt_tr ON $wpdb->posts.ID = tt_tr.object_id ";
        $join .= " LEFT JOIN $wpdb->term_taxonomy tt_tt ON tt_tr.term_taxonomy_id = tt_tt.term_taxonomy_id ";
        $join .= " LEFT JOIN $wpdb->terms tt_terms ON tt_tt.term_id = tt_terms.term_id ";
    }
    return $join;
}
add_filter( 'posts_join', 'tt_search_join', 10, 2 );

function tt_search_distinct( $where, $wp_query ) {
    if ( (is_search() || (defined('DOING_AJAX') && DOING_AJAX && isset($_POST['action']) && $_POST['action'] === 'tt_autocomplete_search')) && !empty($wp_query->query_vars['s']) ) {
        return "DISTINCT";
    }
    return $where;
}
add_filter( 'posts_distinct', 'tt_search_distinct', 10, 2 );

// -----------------------------------------------------------------------------
// Auto-sideload per le immagini esterne delle aziende e delle classifiche
// -----------------------------------------------------------------------------
function tt_sideload_external_images($post_id, $post) {
    if (wp_is_post_revision($post_id) || (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) || !current_user_can('edit_post', $post_id)) {
        return;
    }

    $img_meta = get_post_meta($post_id, '_tt_image', true);
    if (empty($img_meta)) {
        return;
    }

    // Solo URL esterni validi (wp_http_validate_url esclude host interni)
    $is_external = (strpos($img_meta, 'http') === 0) && (strpos($img_meta, site_url()) === false);
    if (!$is_external || !wp_http_validate_url($img_meta)) {
        return;
    }

    require_once(ABSPATH . 'wp-admin/includes/image.php');
    require_once(ABSPATH . 'wp-admin/includes/file.php');
    require_once(ABSPATH . 'wp-admin/includes/media.php');

    $temp_file = download_url($img_meta, 20);
    if (is_wp_error($temp_file)) {
        return;
    }

    $file_array = [
        'name' => sanitize_file_name(basename((string) wp_parse_url($img_meta, PHP_URL_PATH))),
        'tmp_name' => $temp_file
    ];
    if (strpos($file_array['name'], '.') === false) {
        $file_array['name'] .= '.jpg';
    }

    $attachment_id = media_handle_sideload($file_array, $post_id, $post->post_title);
    if (is_wp_error($attachment_id)) {
        @unlink($temp_file);
        return;
    }

    update_post_meta($post_id, '_tt_image', wp_get_attachment_url($attachment_id));
    set_post_thumbnail($post_id, $attachment_id);
}
// Prima girava su ogni admin_init con get_posts(-1) di tutte le aziende e classifiche: ora solo sul post salvato
add_action('save_post_azienda', 'tt_sideload_external_images', 20, 2);
add_action('save_post_classifica', 'tt_sideload_external_images', 20, 2);

// -----------------------------------------------------------------------------
// Sideload e gestione dinamica dei file del brand in Libreria Media (upload.php)
// Con supporto completo alla migrazione e risoluzione automatica degli URL
// -----------------------------------------------------------------------------
function tt_clean_migration_url($url) {
    if (empty($url)) {
        return $url;
    }
    
    // Rimuove slash finale per coerenza
    $site_url = rtrim(site_url(), '/');
    
    // Se è un percorso relativo (non inizia con http o //)
    if (strpos($url, 'http') !== 0 && strpos($url, '//') !== 0) {
        $url = ltrim($url, '/');
        $url = $site_url . '/' . $url;
    } else {
        // Estraiamo l'host e lo schema correnti dalla site_url corrente
        $site_parts = wp_parse_url($site_url);
        $site_scheme = isset($site_parts['scheme']) ? $site_parts['scheme'] : 'http';
        $site_host = isset($site_parts['host']) ? $site_parts['host'] : 'localhost';
        $site_port = isset($site_parts['port']) ? ':' . $site_parts['port'] : '';
        
        // Estraiamo l'host e lo schema dall'URL dell'immagine originale
        $url_parts = wp_parse_url($url);
        $url_scheme = isset($url_parts['scheme']) ? $url_parts['scheme'] : 'http';
        $url_host = isset($url_parts['host']) ? $url_parts['host'] : 'localhost';
        $url_port = isset($url_parts['port']) ? ':' . $url_parts['port'] : '';
        
        // Calcola le basi da scambiare (solo schema, host e porta)
        $local_base = $url_scheme . '://' . $url_host . $url_port;
        $current_base = $site_scheme . '://' . $site_host . $site_port;
        
        // Sostituisce la base originale solo all'inizio dell'URL
        if (strpos($url, $local_base) === 0) {
            $url = $current_base . substr($url, strlen($local_base));
        }
    }
    
    return $url;
}

// Filtra dinamicamente la query di recupero di _tt_image per renderla bulletproof su ogni dominio/pagina
function tt_filter_tt_image_metadata($value, $object_id, $meta_key, $single) {
    if ($meta_key === '_tt_image') {
        // Rimuove temporaneamente il filtro per evitare ricorsione infinita
        remove_filter('get_post_metadata', 'tt_filter_tt_image_metadata', 10);
        
        $original_value = get_post_meta($object_id, '_tt_image', $single);
        
        // Riaggiunge il filtro
        add_filter('get_post_metadata', 'tt_filter_tt_image_metadata', 10, 4);
        
        if (empty($original_value)) {
            return $original_value;
        }
        
        if ($single) {
            return tt_clean_migration_url($original_value);
        } else {
            return array_map('tt_clean_migration_url', $original_value);
        }
    }
    return $value;
}
add_filter('get_post_metadata', 'tt_filter_tt_image_metadata', 10, 4);

function tt_get_brand_image_url($filename) {
    global $wpdb;
    static $resolved = [];

    if (isset($resolved[$filename])) {
        return $resolved[$filename];
    }

    // Rimuove l'estensione per calcolare lo slug dell'allegato
    $slug = sanitize_title(pathinfo($filename, PATHINFO_FILENAME));

    // Cache persistente: prima ogni logo/badge faceva una query SQL a ogni pagina
    $cache_key = 'tt_brand_img_' . md5($filename);
    $attachment_id = get_transient($cache_key);

    if ($attachment_id === false) {
        $attachment_id = (int) $wpdb->get_var($wpdb->prepare(
            "SELECT ID FROM $wpdb->posts WHERE post_name = %s AND post_type = 'attachment'",
            $slug
        ));
        if ($attachment_id) {
            set_transient($cache_key, $attachment_id, DAY_IN_SECONDS);
        }
    }

    if ($attachment_id) {
        $url = wp_get_attachment_url($attachment_id);
        if ($url) {
            return $resolved[$filename] = tt_clean_migration_url($url);
        }
        delete_transient($cache_key);
    }

    // Se non esiste, importiamo l'immagine dal tema nella Libreria Media (solo in admin, mai durante una visita)
    $theme_file_path = get_stylesheet_directory() . '/images/' . $filename;

    if (is_admin() && current_user_can('upload_files') && file_exists($theme_file_path)) {
        require_once(ABSPATH . 'wp-admin/includes/image.php');
        require_once(ABSPATH . 'wp-admin/includes/file.php');
        require_once(ABSPATH . 'wp-admin/includes/media.php');
        
        // Copia il file in una cartella temporanea per non intaccare i file del tema
        $tmp_dir = get_temp_dir();
        $tmp_file = $tmp_dir . $filename;
        @copy($theme_file_path, $tmp_file);
        
        $file_array = [
            'name' => $filename,
            'tmp_name' => $tmp_file
        ];
        
        // Esegue il caricamento automatico nei media
        $attachment_id = media_handle_sideload($file_array, 0, ucfirst(str_replace('-', ' ', $slug)));
        
        if (!is_wp_error($attachment_id)) {
            set_transient($cache_key, (int) $attachment_id, DAY_IN_SECONDS);
            $url = wp_get_attachment_url($attachment_id);
            return $resolved[$filename] = tt_clean_migration_url($url);
        }
    }

    // Fallback: file del tema
    $url = get_stylesheet_directory_uri() . '/images/' . $filename;
    return $resolved[$filename] = tt_clean_migration_url($url);
}

// SVG: il supporto upload e' gestito dal parent (inc/image-upload-validation.php).
// Il child non modifica piu' upload_filetypes di rete, che valeva per tutti i siti del network.

// -----------------------------------------------------------------------------
// Personalizzazione Customizer per il tema Child (Impostazioni Home Page)
// -----------------------------------------------------------------------------
function ticinotop_customize_register( $wp_customize ) {
    // Aggiungi sezione "Impostazioni Ticino Top"
    $wp_customize->add_section( 'ticinotop_settings', array(
        'title'    => __( 'Impostazioni Ticino Top', 'ticinotop' ),
        'priority' => 30,
    ) );

    // 1. Aggiungi setting per nascondere la sezione "Classifiche in Evidenza"
    $wp_customize->add_setting( 'ticinotop_hide_classifiche_evidenza', array(
        'default'           => false,
        'sanitize_callback' => 'ticinotop_sanitize_checkbox',
    ) );
    $wp_customize->add_control( 'ticinotop_hide_classifiche_evidenza', array(
        'label'    => __( 'Nascondi la sezione "Classifiche in Evidenza"', 'ticinotop' ),
        'section'  => 'ticinotop_settings',
        'settings' => 'ticinotop_hide_classifiche_evidenza',
        'type'     => 'checkbox',
    ) );

    // 2. Aggiungi setting per nascondere la barra di ricerca e i pulsanti Hero
    $wp_customize->add_setting( 'ticinotop_hide_hero_search', array(
        'default'           => false,
        'sanitize_callback' => 'ticinotop_sanitize_checkbox',
    ) );
    $wp_customize->add_control( 'ticinotop_hide_hero_search', array(
        'label'    => __( 'Nascondi barra di ricerca e pulsanti nel Hero', 'ticinotop' ),
        'section'  => 'ticinotop_settings',
        'settings' => 'ticinotop_hide_hero_search',
        'type'     => 'checkbox',
    ) );

    // 3. Aggiungi setting per abilitare il layout blog sulla Homepage
    $wp_customize->add_setting( 'ticinotop_home_blog_layout', array(
        'default'           => false,
        'sanitize_callback' => 'ticinotop_sanitize_checkbox',
    ) );
    $wp_customize->add_control( 'ticinotop_home_blog_layout', array(
        'label'    => __( 'Attiva layout Blog (articoli) per la Home Page', 'ticinotop' ),
        'section'  => 'ticinotop_settings',
        'settings' => 'ticinotop_home_blog_layout',
        'type'     => 'checkbox',
    ) );
}
add_action( 'customize_register', 'ticinotop_customize_register' );

// Callback di sanitizzazione per checkbox
function ticinotop_sanitize_checkbox( $checked ) {
    return ( ( isset( $checked ) && true === $checked ) ? true : false );
}

/**
 * Dynamic menu filter: hide Classifiche from menus when hidden from homepage
 */
function ticinotop_filter_menu_items( $items, $args ) {
    if ( get_theme_mod( 'ticinotop_hide_classifiche_evidenza', false ) ) {
        foreach ( $items as $key => $item ) {
            $url = isset( $item->url ) ? $item->url : '';
            $title = isset( $item->title ) ? $item->title : '';
            
            if ( 
                strpos( strtolower( $url ), '/classifica/' ) !== false || 
                strcasecmp( $title, 'classifiche' ) === 0 || 
                strcasecmp( $title, 'classifica' ) === 0 
            ) {
                unset( $items[$key] );
            }
        }
    }
    return $items;
}
add_filter( 'wp_nav_menu_objects', 'ticinotop_filter_menu_items', 10, 2 );

/**
 * Auto-create Privacy Policy page and set it as the official page in WP settings
 */
function ticinotop_create_privacy_policy_page() {
    // Gira una volta sola: prima ricostruiva l'HTML e interrogava il DB a ogni pagina admin
    if ( get_option( 'ticinotop_privacy_page_setup' ) === '2' ) {
        return;
    }
    update_option( 'ticinotop_privacy_page_setup', '2' );

    $page_slug = 'privacy-policy';
    $page_exists = get_page_by_path( $page_slug );

    // Titolare del trattamento dai contatti del parent (ticinoWEB CMS): niente dati duplicati nel child
    $owner_email   = sanitize_email( get_option( 'ticinoweb_contact_email' ) ) ?: 'info@ticinotop.ch';
    $owner_address = trim( (string) get_option( 'ticinoweb_contact_address', '' ) );
    $owner_name    = get_option( 'tw_seo_org_name' ) ?: get_bloginfo( 'name' );
    $owner_html    = esc_html( $owner_name ) . ( $owner_address ? '<br><span style="font-weight: 400; color: #64748b; font-size: 14px;">' . nl2br( esc_html( $owner_address ) ) . '</span>' : '' );
    
    $privacy_content = '<div class="tt-privacy-wrapper" style="max-width: 800px; margin: 40px auto; padding: 48px; background: #ffffff; border: 1px solid #e2e8f0; border-radius: 16px; box-shadow: 0 10px 30px rgba(0,0,0,0.015); font-family: var(--tt-font-sans, sans-serif); color: #334155; line-height: 1.75;">
    
    <div style="text-align: center; margin-bottom: 40px; border-bottom: 2px solid #f1f5f9; padding-bottom: 30px;">
        <span style="background: rgba(212, 175, 55, 0.1); color: #b89130; padding: 6px 14px; border-radius: 20px; font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.1em; display: inline-block; margin-bottom: 12px;">Documento Legale</span>
        <h1 style="font-family: var(--tt-font-serif, serif); font-size: 38px; color: #0f172a; margin: 0 0 10px 0; font-weight: 700; line-height: 1.2;">Privacy Policy</h1>
        <p style="font-size: 14px; color: #64748b; margin: 0;">Ultimo aggiornamento: <strong style="color: #0f172a;">01.06.2026</strong></p>
    </div>

    <p style="font-size: 15.5px; margin-bottom: 32px; color: #475569; text-align: justify;">La presente Privacy Policy descrive le modalità di raccolta, utilizzo e protezione dei dati personali degli utenti che visitano il sito <a href="https://ticinotop.ch/" style="color: #b89130; text-decoration: none; font-weight: 600; border-bottom: 1px dashed rgba(212, 175, 55, 0.4); transition: all 0.3s ease;">TicinoTop.ch</a> (di seguito il “Sito”), in conformità alla Legge federale svizzera sulla protezione dei dati (nLPD) e, ove applicabile, al Regolamento Generale sulla Protezione dei Dati (GDPR) dell’Unione Europea.</p>

    <!-- Sezione 1 -->
    <div style="margin-bottom: 32px; padding: 24px; background: #f8fafc; border-radius: 12px; border-left: 4px solid #d4af37;">
        <h3 style="margin-top: 0; font-size: 18px; color: #0f172a; font-weight: 700; margin-bottom: 12px;">1. Titolare del trattamento</h3>
        <p style="margin: 0; font-size: 15px; color: #475569;">Il titolare del trattamento dei dati personali raccolti tramite il presente sito è:</p>
        <p style="margin: 10px 0 0 0; font-size: 16px; color: #0f172a; font-weight: 600; line-height: 1.5;">' . $owner_html . '<br><span style="font-weight: 400; color: #64748b; font-size: 14px;">Email:</span> <a href="mailto:' . esc_attr( $owner_email ) . '" style="color: #b89130; text-decoration: none;">' . esc_html( $owner_email ) . '</a></p>
    </div>

    <!-- Sezione 2 -->
    <div style="margin-bottom: 32px;">
        <h3 style="font-size: 20px; color: #0f172a; font-weight: 700; border-bottom: 1px solid #f1f5f9; padding-bottom: 8px; margin-bottom: 16px;">2. Dati raccolti</h3>
        <p style="font-size: 15px; color: #475569; margin-bottom: 16px;">Durante la navigazione sul Sito possono essere raccolte le seguenti categorie di dati:</p>
        
        <h4 style="font-size: 15.5px; color: #1e293b; font-weight: 600; margin: 20px 0 10px 0;">Dati forniti volontariamente dall’utente</h4>
        <ul style="padding-left: 20px; margin-bottom: 20px; color: #475569;">
            <li style="margin-bottom: 8px; font-size: 14.5px;">Nome e cognome</li>
            <li style="margin-bottom: 8px; font-size: 14.5px;">Indirizzo email</li>
            <li style="margin-bottom: 8px; font-size: 14.5px;">Numero di telefono</li>
            <li style="margin-bottom: 8px; font-size: 14.5px;">Informazioni inviate tramite moduli di contatto</li>
            <li style="margin-bottom: 8px; font-size: 14.5px;">Qualsiasi altro dato comunicato spontaneamente dall’utente</li>
        </ul>
        
        <h4 style="font-size: 15.5px; color: #1e293b; font-weight: 600; margin: 20px 0 10px 0;">Dati raccolti automaticamente</h4>
        <ul style="padding-left: 20px; margin-bottom: 0; color: #475569;">
            <li style="margin-bottom: 8px; font-size: 14.5px;">Indirizzo IP</li>
            <li style="margin-bottom: 8px; font-size: 14.5px;">Tipo di browser e dispositivo utilizzato</li>
            <li style="margin-bottom: 8px; font-size: 14.5px;">Sistema operativo</li>
            <li style="margin-bottom: 8px; font-size: 14.5px;">Data e ora di accesso</li>
            <li style="margin-bottom: 8px; font-size: 14.5px;">Pagine visitate</li>
            <li style="margin-bottom: 8px; font-size: 14.5px;">Informazioni tecniche necessarie al funzionamento del sito</li>
        </ul>
    </div>

    <!-- Sezione 3 -->
    <div style="margin-bottom: 32px;">
        <h3 style="font-size: 20px; color: #0f172a; font-weight: 700; border-bottom: 1px solid #f1f5f9; padding-bottom: 8px; margin-bottom: 16px;">3. Finalità del trattamento</h3>
        <p style="font-size: 15px; color: #475569; margin-bottom: 12px;">I dati personali vengono trattati per le seguenti finalità:</p>
        <ul style="padding-left: 20px; color: #475569;">
            <li style="margin-bottom: 8px; font-size: 14.5px;">Rispondere alle richieste inviate tramite il sito;</li>
            <li style="margin-bottom: 8px; font-size: 14.5px;">Fornire informazioni sui servizi e contenuti presenti sul portale;</li>
            <li style="margin-bottom: 8px; font-size: 14.5px;">Migliorare l’esperienza di navigazione;</li>
            <li style="margin-bottom: 8px; font-size: 14.5px;">Garantire la sicurezza del sito e prevenire utilizzi fraudolenti;</li>
            <li style="margin-bottom: 8px; font-size: 14.5px;">Adempiere ad obblighi legali e normativi.</li>
        </ul>
    </div>

    <!-- Sezione 4 -->
    <div style="margin-bottom: 32px;">
        <h3 style="font-size: 20px; color: #0f172a; font-weight: 700; border-bottom: 1px solid #f1f5f9; padding-bottom: 8px; margin-bottom: 16px;">4. Base giuridica del trattamento</h3>
        <p style="font-size: 15px; color: #475569; margin-bottom: 12px;">Il trattamento dei dati avviene sulla base di:</p>
        <ul style="padding-left: 20px; color: #475569;">
            <li style="margin-bottom: 8px; font-size: 14.5px;">Consenso dell’utente;</li>
            <li style="margin-bottom: 8px; font-size: 14.5px;">Necessità di eseguire misure precontrattuali o contrattuali;</li>
            <li style="margin-bottom: 8px; font-size: 14.5px;">Interesse legittimo del titolare alla gestione e sicurezza del sito;</li>
            <li style="margin-bottom: 8px; font-size: 14.5px;">Adempimento di obblighi legali.</li>
        </ul>
    </div>

    <!-- Sezione 5 -->
    <div style="margin-bottom: 32px; padding: 20px; background: #fffcf4; border-radius: 12px; border: 1px dashed #d4af37;">
        <h3 style="margin-top: 0; font-size: 18px; color: #0f172a; font-weight: 700; margin-bottom: 12px;">5. Conservazione dei dati</h3>
        <p style="margin: 0; font-size: 15px; color: #475569; text-align: justify;">I dati personali vengono conservati per il tempo strettamente necessario al raggiungimento delle finalità indicate nella presente informativa e nel rispetto degli obblighi di legge applicabili.</p>
    </div>

    <!-- Sezione 6 -->
    <div style="margin-bottom: 32px;">
        <h3 style="font-size: 20px; color: #0f172a; font-weight: 700; border-bottom: 1px solid #f1f5f9; padding-bottom: 8px; margin-bottom: 16px;">6. Comunicazione dei dati a terzi</h3>
        <p style="font-size: 15px; color: #475569; margin-bottom: 12px;">I dati personali non vengono venduti né ceduti a terzi. Potranno tuttavia essere comunicati a:</p>
        <ul style="padding-left: 20px; margin-bottom: 16px; color: #475569;">
            <li style="margin-bottom: 8px; font-size: 14.5px;">Fornitori di servizi informatici e hosting;</li>
            <li style="margin-bottom: 8px; font-size: 14.5px;">Collaboratori e consulenti incaricati della gestione del sito;</li>
            <li style="margin-bottom: 8px; font-size: 14.5px;">Autorità competenti qualora richiesto dalla legge.</li>
        </ul>
        <p style="font-size: 14px; color: #64748b; font-style: italic; margin: 0;">Tali soggetti trattano i dati esclusivamente per le finalità indicate e nel rispetto della normativa vigente.</p>
    </div>

    <!-- Sezione 7 -->
    <div style="margin-bottom: 32px;">
        <h3 style="font-size: 20px; color: #0f172a; font-weight: 700; border-bottom: 1px solid #f1f5f9; padding-bottom: 8px; margin-bottom: 16px;">7. Cookie</h3>
        <p style="font-size: 15px; color: #475569; margin-bottom: 12px;">Il Sito può utilizzare cookie tecnici e, previo consenso ove richiesto, cookie analitici o di terze parti.</p>
        <p style="font-size: 15px; color: #475569; margin-bottom: 12px;">I cookie sono piccoli file di testo salvati sul dispositivo dell’utente e consentono il corretto funzionamento del sito e l’analisi dell’utilizzo delle pagine.</p>
        <p style="font-size: 15px; color: #475569; margin: 0;">L’utente può gestire o disabilitare i cookie tramite le impostazioni del proprio browser.</p>
    </div>

    <!-- Sezione 8 -->
    <div style="margin-bottom: 32px;">
        <h3 style="font-size: 20px; color: #0f172a; font-weight: 700; border-bottom: 1px solid #f1f5f9; padding-bottom: 8px; margin-bottom: 16px;">8. Sicurezza dei dati</h3>
        <p style="font-size: 15px; color: #475569; margin: 0; text-align: justify;">Adottiamo misure tecniche e organizzative adeguate per proteggere i dati personali da accessi non autorizzati, perdita, divulgazione o alterazione.</p>
    </div>

    <!-- Sezione 9 -->
    <div style="margin-bottom: 32px;">
        <h3 style="font-size: 20px; color: #0f172a; font-weight: 700; border-bottom: 1px solid #f1f5f9; padding-bottom: 8px; margin-bottom: 16px;">9. Diritti dell’utente</h3>
        <p style="font-size: 15px; color: #475569; margin-bottom: 12px;">L’utente può esercitare in qualsiasi momento i diritti previsti dalla normativa applicabile, tra cui:</p>
        <ul style="padding-left: 20px; color: #475569;">
            <li style="margin-bottom: 8px; font-size: 14.5px;">Diritto di accesso ai dati personali;</li>
            <li style="margin-bottom: 8px; font-size: 14.5px;">Diritto di rettifica;</li>
            <li style="margin-bottom: 8px; font-size: 14.5px;">Diritto di cancellazione;</li>
            <li style="margin-bottom: 8px; font-size: 14.5px;">Diritto di limitazione del trattamento;</li>
            <li style="margin-bottom: 8px; font-size: 14.5px;">Diritto di opposizione;</li>
            <li style="margin-bottom: 8px; font-size: 14.5px;">Diritto alla portabilità dei dati, ove applicabile;</li>
            <li style="margin-bottom: 8px; font-size: 14.5px;">Diritto di revocare il consenso prestato.</li>
        </ul>
        <p style="font-size: 15px; color: #475569; margin-top: 12px;">Per esercitare tali diritti è possibile contattare il titolare all’indirizzo email indicato sopra.</p>
    </div>

    <!-- Sezione 10 -->
    <div style="margin-bottom: 32px;">
        <h3 style="font-size: 20px; color: #0f172a; font-weight: 700; border-bottom: 1px solid #f1f5f9; padding-bottom: 8px; margin-bottom: 16px;">10. Modifiche alla presente Privacy Policy</h3>
        <p style="font-size: 15px; color: #475569; margin: 0;">La presente Privacy Policy può essere aggiornata in qualsiasi momento. Eventuali modifiche saranno pubblicate su questa pagina con indicazione della data di aggiornamento.</p>
    </div>

    <!-- Sezione 11 -->
    <div style="padding: 24px; background: #f8fafc; border-radius: 12px; border-left: 4px solid #b89130;">
        <h3 style="margin-top: 0; font-size: 18px; color: #0f172a; font-weight: 700; margin-bottom: 12px;">11. Contatti</h3>
        <p style="margin: 0 0 8px 0; font-size: 15px; color: #475569;">Per qualsiasi domanda relativa alla presente Privacy Policy o al trattamento dei dati personali, è possibile contattare:</p>
        <p style="margin: 0; font-size: 16px; color: #0f172a; font-weight: 600;">Email: <a href="mailto:' . esc_attr( $owner_email ) . '" style="color: #b89130; text-decoration: none;">' . esc_html( $owner_email ) . '</a></p>
    </div>

</div>';

    if ( !$page_exists ) {
        $page_id = wp_insert_post( array(
            'post_title'   => 'Privacy Policy',
            'post_content' => $privacy_content,
            'post_status'  => 'publish',
            'post_type'    => 'page',
            'post_name'    => $page_slug,
        ) );
        
        if ( $page_id && !is_wp_error( $page_id ) ) {
            update_option( 'wp_page_for_privacy_policy', $page_id );
        }
    } elseif ( ! get_option( 'wp_page_for_privacy_policy' ) ) {
        // Imposta la pagina solo se nessuna e' stata scelta in Impostazioni > Privacy
        update_option( 'wp_page_for_privacy_policy', $page_exists->ID );
    }
}
add_action( 'admin_init', 'ticinotop_create_privacy_policy_page' );

// AJAX Load More for Blog
add_action('wp_ajax_nopriv_tt_load_more_posts', 'tt_load_more_posts_handler');
add_action('wp_ajax_tt_load_more_posts', 'tt_load_more_posts_handler');

function tt_load_more_posts_handler() {
    $page = isset($_POST['page']) ? max(1, min(100, intval($_POST['page']))) : 1;
    $featured_id = isset($_POST['featured']) ? intval($_POST['featured']) : 0;
    
    $args = [
        'post_type' => 'post',
        'post_status' => 'publish',
        'posts_per_page' => 9,
        'paged' => $page
    ];
    if ($featured_id > 0) {
        $args['post__not_in'] = [$featured_id];
    }
    
    $query = new WP_Query($args);
    
    if ($query->have_posts()) {
        while ($query->have_posts()) {
            $query->the_post();
            
            $p_id = get_the_ID();
            $p_title = get_the_title();
            $p_excerpt = get_the_excerpt() ?: wp_trim_words(get_the_content(), 25);
            $p_img = get_the_post_thumbnail_url($p_id, 'full') ?: get_stylesheet_directory_uri() . '/images/category-default.jpg';
            $p_url = get_permalink();
            
            $categories = get_the_category();
            $p_category = ($categories) ? $categories[0]->name : 'Trend & Insight';
            $p_date = get_the_date('j F Y');
            ?>
            <a href="<?php echo esc_url($p_url); ?>" class="tt-card tt-blog-card" style="display: flex; flex-direction: column; text-decoration: none; border-radius: var(--tt-radius-md); overflow: hidden; background: var(--tt-white); box-shadow: var(--tt-shadow-sm); border: 1px solid var(--tt-gray-border); height: 100%; transition: all 0.3s ease; padding: 0; box-shadow: none;">
                <div style="height: 240px; background: url('<?php echo esc_url($p_img); ?>') center/cover; position: relative;">
                    <div style="position: absolute; top: 16px; left: 16px;">
                        <span class="tt-badge" style="background: rgba(255,255,255,0.95); backdrop-filter: blur(4px); -webkit-backdrop-filter: blur(4px); color: var(--tt-black); border-color: rgba(255,255,255,0.5); font-weight: 600;"><?php echo esc_html($p_category); ?></span>
                    </div>
                </div>
                <div style="padding: 28px; flex-grow: 1; display: flex; flex-direction: column; justify-content: space-between; background: var(--tt-white);">
                    <div>
                        <span style="color: var(--tt-gray-text); font-size: 12px; display: block; margin-bottom: 12px; font-weight: 500;"><?php echo esc_html($p_date); ?></span>
                        <h3 style="font-size: 22px; margin: 0 0 12px 0; font-family: var(--tt-font-serif); color: var(--tt-black); line-height: 1.3; transition: color 0.3s ease;"><?php echo esc_html($p_title); ?></h3>
                        <p style="font-size: 14.5px; color: var(--tt-gray-text); margin: 0; line-height: 1.6; display: -webkit-box; -webkit-line-clamp: 3; -webkit-box-orient: vertical; overflow: hidden;"><?php echo esc_html($p_excerpt); ?></p>
                    </div>
                    <div style="margin-top: 24px; font-weight: 600; font-size: 14px; color: var(--tt-gold-champagne); display: flex; align-items: center; gap: 4px;">
                        Leggi Articolo →
                    </div>
                </div>
            </a>
            <?php
        }
        wp_reset_postdata();
    }
    wp_die();
}

// Le email della simulazione TopScan e le candidature passano dal gestore form del parent
// (ticinoweb_submit_form: token fresco, honeypot, rate limit, reCAPTCHA, tab "Invii Ricevuti").
require_once get_stylesheet_directory() . '/inc/forms.php';
