<?php
/**
 * Header and Mega Menu dynamic functionality for Oasi delle Spezie Child Theme.
 *
 * @package OasiDelleSpezieChild
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Retrieve the attachment thumbnail URL for a category term or its children.
 *
 * @param int $term_id Product category term ID.
 * @return string Image URL or fallback placeholder from media library.
 */
function oasi_get_category_term_thumbnail_url( int $term_id ): string {
	if ( $term_id > 0 ) {
		$thumb_id = (int) get_term_meta( $term_id, 'thumbnail_id', true );
		if ( $thumb_id > 0 ) {
			$img = wp_get_attachment_image_url( $thumb_id, 'large' );
			if ( $img ) {
				return $img;
			}
		}

		// Check first child category thumbnail
		$children = get_terms(
			array(
				'taxonomy'   => 'product_cat',
				'parent'     => $term_id,
				'hide_empty' => false,
				'number'     => 5,
			)
		);
		if ( ! is_wp_error( $children ) && ! empty( $children ) ) {
			foreach ( $children as $child ) {
				$ch_thumb_id = (int) get_term_meta( $child->term_id, 'thumbnail_id', true );
				if ( $ch_thumb_id > 0 ) {
					$img = wp_get_attachment_image_url( $ch_thumb_id, 'large' );
					if ( $img ) {
						return $img;
					}
				}
			}
		}
	}

	// Safe Media Library fallback from existing product photography
	$fallback_id = 34177; // Spezie Bio hero photo
	$fallback_url = wp_get_attachment_image_url( $fallback_id, 'large' );
	if ( ! $fallback_url ) {
		$fallback_url = oasi_upload_url( '2022/02/spices-2.jpg' );
	}

	return $fallback_url;
}

/**
 * Decorate Primary nav menu link attributes with accessibility and trigger hooks for the Mega Menu.
 *
 * @param array    $atts Nav menu link attributes.
 * @param WP_Post  $item Nav menu item object.
 * @param stdClass $args Nav menu arguments.
 * @param int      $depth Depth of current item.
 * @return array Modified attributes.
 */
function oasi_filter_primary_nav_menu_link_attributes( array $atts, $item, $args, $depth ): array {
	if ( isset( $args->theme_location ) && 'primary' === $args->theme_location ) {
		$title_lower = strtolower( trim( (string) $item->title ) );
		$url         = (string) $item->url;
		$is_shop     = ( 'shop' === $title_lower || str_contains( $url, 'shop' ) );

		if ( $is_shop ) {
			$atts['class']         = trim( ( $atts['class'] ?? '' ) . ' oasi-nav-link--megamenu-trigger' );
			$atts['aria-haspopup'] = 'true';
			$atts['aria-expanded'] = 'false';
			$atts['id']            = 'oasi-shop-megamenu-trigger';
		}
	}
	return $atts;
}
add_filter( 'nav_menu_link_attributes', 'oasi_filter_primary_nav_menu_link_attributes', 10, 4 );

/**
 * Decorate Primary nav menu item classes with mega menu indicator.
 *
 * @param string[] $classes Nav menu item class list.
 * @param WP_Post  $item Nav menu item object.
 * @param stdClass $args Nav menu arguments.
 * @param int      $depth Depth of current item.
 * @return string[] Modified classes.
 */
function oasi_filter_primary_nav_menu_css_class( array $classes, $item, $args, $depth ): array {
	if ( isset( $args->theme_location ) && 'primary' === $args->theme_location ) {
		$title_lower = strtolower( trim( (string) $item->title ) );
		if ( 'shop' === $title_lower || str_contains( (string) $item->url, 'shop' ) ) {
			$classes[] = 'oasi-menu-item--has-megamenu';
		}
	}
	return $classes;
}
add_filter( 'nav_menu_css_class', 'oasi_filter_primary_nav_menu_css_class', 10, 4 );

/**
 * Append an elegant dropdown indicator icon to the Shop nav item in Primary Navigation.
 *
 * @param string   $title The menu item's title.
 * @param WP_Post  $item  The current menu item object.
 * @param stdClass $args  Nav menu arguments.
 * @param int      $depth Depth of current item.
 * @return string Modified title HTML with dropdown indicator icon.
 */
function oasi_filter_primary_nav_menu_item_title( string $title, $item, $args, int $depth ): string {
	if ( isset( $args->theme_location ) && ( 'primary' === $args->theme_location || 'menu-1' === $args->theme_location ) ) {
		$title_lower = strtolower( trim( (string) $item->title ) );
		$url         = (string) ( $item->url ?? '' );
		$is_shop     = ( 'shop' === $title_lower || str_contains( $url, 'shop' ) );

		if ( $is_shop ) {
			$icon = '<svg class="oasi-nav-dropdown-icon" width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="6 9 12 15 18 9"></polyline></svg>';
			return esc_html( $title ) . '<span class="oasi-nav-dropdown-arrow-wrap">' . $icon . '</span>';
		}
	}
	return $title;
}
add_filter( 'nav_menu_item_title', 'oasi_filter_primary_nav_menu_item_title', 10, 4 );

/**
 * Extract the catalog navigation tree from the WooCommerce category hierarchy.
 *
 * @return array[] Array of parent families with their child items, images, and counts.
 */
function oasi_get_megamenu_tree(): array {
	// Rendered twice per page (desktop panel and mobile drawer) and on every
	// uncached page: build once, cache per locale until a menu or category changes.
	return function_exists( 'oasi_catalog_cached' )
		? oasi_catalog_cached( 'megamenu_tree', 'oasi_build_megamenu_tree' )
		: oasi_build_megamenu_tree();
}

/**
 * Build the mega menu tree from product_cat (uncached).
 *
 * Top-level categories are the menu families. Their direct children populate
 * the centre panel. Using WooCommerce's native hierarchy means adding,
 * reordering, renaming or removing a category updates the frontend without a
 * second edit in Appearance -> Menus.
 *
 * @return array[]
 */
function oasi_build_megamenu_tree(): array {
	$terms = get_terms(
		array(
			'taxonomy'   => 'product_cat',
			'hide_empty' => false,
			'orderby'    => 'menu_order',
			'order'      => 'ASC',
			'pad_counts' => true,
		)
	);

	if ( is_wp_error( $terms ) || empty( $terms ) ) {
		return array();
	}

	$children_by_parent = array();
	foreach ( $terms as $term ) {
		if ( 'uncategorized' === $term->slug ) {
			continue;
		}
		$children_by_parent[ (int) $term->parent ][] = $term;
	}
	$aggregate_counts = oasi_category_aggregate_counts( $terms );

	$tree = array();
	foreach ( $children_by_parent[0] ?? array() as $index => $parent_term ) {
		$term_id    = (int) $parent_term->term_id;
		$term_url   = get_term_link( $parent_term, 'product_cat' );
		$thumb_url  = oasi_get_category_term_thumbnail_url( $term_id );
		$children   = array();

		foreach ( $children_by_parent[ $term_id ] ?? array() as $child_term ) {
			$child_url = get_term_link( $child_term, 'product_cat' );
			$children[] = array(
				'id'      => (int) $child_term->term_id,
				'title'   => html_entity_decode( (string) $child_term->name, ENT_QUOTES, 'UTF-8' ),
				'url'     => is_wp_error( $child_url ) ? '' : (string) $child_url,
				'term_id' => (int) $child_term->term_id,
				'count'   => $aggregate_counts[ (int) $child_term->term_id ] ?? (int) $child_term->count,
			);
		}

		// A new parent can be useful before its own image is uploaded: use the
		// first child image while preserving the Media Library fallback chain.
		if ( ! empty( $children ) && 0 === (int) get_term_meta( $term_id, 'thumbnail_id', true ) ) {
			foreach ( $children as $ch ) {
				$ch_thumb = oasi_get_category_term_thumbnail_url( $ch['term_id'] );
				if ( $ch_thumb ) {
					$thumb_url = $ch_thumb;
					break;
				}
			}
		}

		$tree[] = array(
			'id'          => $term_id,
			'title'       => html_entity_decode( (string) $parent_term->name, ENT_QUOTES, 'UTF-8' ),
			'url'         => is_wp_error( $term_url ) ? '' : (string) $term_url,
			'term_id'     => $term_id,
			'count'       => $aggregate_counts[ $term_id ] ?? (int) $parent_term->count,
			'thumb_url'   => $thumb_url,
			'children'    => $children,
			'is_active'   => ( 0 === $index ),
		);
	}

	return $tree;
}

/**
 * Render the Desktop Mega Menu "Spice Atlas" HTML.
 */
function oasi_render_desktop_megamenu(): void {
	$families = oasi_get_megamenu_tree();
	if ( empty( $families ) ) {
		return;
	}
	?>
	<div class="oasi-megamenu-dropdown" id="oasi-megamenu-panel" role="region" aria-label="<?php esc_attr_e( 'Spice Atlas Mega Menu', 'oasidellespezie-child-theme' ); ?>">
		<div class="oasi-container oasi-megamenu-container">
			<!-- LEFT: Category Families -->
			<div class="oasi-megamenu__families" role="tablist" aria-orientation="vertical" aria-label="<?php esc_attr_e( 'Famiglie di spezie e specialità', 'oasidellespezie-child-theme' ); ?>">
				<div class="oasi-megamenu__header-label">
					<span class="oasi-megamenu__eyebrow"><?php esc_html_e( 'Catalogo Oasi', 'oasidellespezie-child-theme' ); ?></span>
					<h3 class="oasi-megamenu__heading"><?php esc_html_e( 'Spice Atlas', 'oasidellespezie-child-theme' ); ?></h3>
				</div>
				<ul class="oasi-megamenu__family-list">
					<?php foreach ( $families as $index => $family ) : ?>
						<li class="oasi-megamenu__family-item">
							<?php if ( ! empty( $family['children'] ) ) : ?>
								<button type="button"
								   class="oasi-megamenu__family-link<?php echo $family['is_active'] ? ' is-active' : ''; ?>"
								   id="oasi-family-tab-<?php echo esc_attr( (string) $family['id'] ); ?>"
								   role="tab"
								   aria-selected="<?php echo $family['is_active'] ? 'true' : 'false'; ?>"
								   aria-controls="oasi-subpanel-<?php echo esc_attr( (string) $family['id'] ); ?>"
								   data-family-id="<?php echo esc_attr( (string) $family['id'] ); ?>"
								   data-thumb="<?php echo esc_url( $family['thumb_url'] ); ?>"
								   data-title="<?php echo esc_attr( $family['title'] ); ?>"
								   data-count="<?php echo esc_attr( (string) $family['count'] ); ?>">
									<span class="oasi-megamenu__family-bullet" aria-hidden="true"></span>
									<span class="oasi-megamenu__family-name"><?php echo esc_html( $family['title'] ); ?></span>
									<svg class="oasi-megamenu__family-arrow" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="9 18 15 12 9 6"></polyline></svg>
								</button>
							<?php else : ?>
								<a href="<?php echo esc_url( $family['url'] ); ?>" class="oasi-megamenu__leaf-link">
									<span class="oasi-megamenu__family-bullet" aria-hidden="true"></span>
									<span class="oasi-megamenu__family-name"><?php echo esc_html( $family['title'] ); ?></span>
								</a>
							<?php endif; ?>
						</li>
					<?php endforeach; ?>
				</ul>
				<div class="oasi-megamenu__all-link-wrap">
					<?php
					$shop_page_id = function_exists( 'wc_get_page_id' ) ? wc_get_page_id( 'shop' ) : 0;
					$all_shop_url = $shop_page_id > 0 ? get_permalink( $shop_page_id ) : home_url( '/shop-online-oasi-delle-spezie/' );
					?>
					<a href="<?php echo esc_url( $all_shop_url ); ?>" class="oasi-megamenu__all-shop-link">
						<span><?php esc_html_e( 'Esplora tutti i prodotti', 'oasidellespezie-child-theme' ); ?></span>
						<span aria-hidden="true">&rarr;</span>
					</a>
				</div>
			</div>

			<!-- CENTER: Subcategories Panels -->
			<div class="oasi-megamenu__center">
				<?php foreach ( $families as $index => $family ) : ?>
					<div class="oasi-megamenu__subpanel<?php echo $family['is_active'] ? ' is-active' : ''; ?>"
						 id="oasi-subpanel-<?php echo esc_attr( (string) $family['id'] ); ?>"
						 role="tabpanel"
						 aria-labelledby="oasi-family-tab-<?php echo esc_attr( (string) $family['id'] ); ?>">
						<div class="oasi-megamenu__subpanel-header">
							<span class="oasi-megamenu__subpanel-title"><?php echo esc_html( $family['title'] ); ?></span>
							<span class="oasi-megamenu__parent-note"><?php esc_html_e( 'Scegli una sottocategoria', 'oasidellespezie-child-theme' ); ?></span>
						</div>
						<?php if ( ! empty( $family['children'] ) ) : ?>
							<ul class="oasi-megamenu__sub-list">
								<?php foreach ( $family['children'] as $child ) : ?>
									<li class="oasi-megamenu__sub-item">
										<a href="<?php echo esc_url( $child['url'] ); ?>" class="oasi-megamenu__sub-link">
											<span class="oasi-megamenu__sub-name"><?php echo esc_html( $child['title'] ); ?></span>
											<?php if ( $child['count'] > 0 ) : ?>
												<span class="oasi-megamenu__sub-count"><?php echo esc_html( (string) $child['count'] ); ?></span>
											<?php endif; ?>
										</a>
									</li>
								<?php endforeach; ?>
							</ul>
						<?php else : ?>
							<p class="oasi-megamenu__empty-notice"><?php esc_html_e( 'Nessuna sottocategoria disponibile.', 'oasidellespezie-child-theme' ); ?></p>
						<?php endif; ?>
					</div>
				<?php endforeach; ?>
			</div>

			<!-- RIGHT: Dynamic Visual Feature Card -->
			<div class="oasi-megamenu__visual" id="oasi-megamenu-visual-card">
				<?php
				$initial_family = $families[0] ?? array();
				$initial_img    = $initial_family['thumb_url'] ?? '';
				$initial_title  = $initial_family['title'] ?? '';
				$initial_count  = $initial_family['count'] ?? 0;
				?>
				<div class="oasi-megamenu__card">
					<div class="oasi-megamenu__card-media">
						<img src="<?php echo esc_url( $initial_img ); ?>"
							 alt="<?php echo esc_attr( $initial_title ); ?>"
							 class="oasi-megamenu__card-img"
							 id="oasi-megamenu-preview-img"
							 width="340"
							 height="220"
							 loading="lazy">
						<div class="oasi-megamenu__card-overlay"></div>
						<div class="oasi-megamenu__card-badge" id="oasi-megamenu-preview-badge">
							<?php esc_html_e( 'Artigianale Svizzero', 'oasidellespezie-child-theme' ); ?>
						</div>
					</div>
					<div class="oasi-megamenu__card-body">
						<h4 class="oasi-megamenu__card-title" id="oasi-megamenu-preview-title">
							<?php echo esc_html( $initial_title ); ?>
						</h4>
						<p class="oasi-megamenu__card-meta" id="oasi-megamenu-preview-meta">
							<?php
							if ( $initial_count > 0 ) {
								printf(
									/* translators: %d: number of products */
									esc_html( _n( '%d prodotto disponibile', '%d prodotti disponibili', $initial_count, 'oasidellespezie-child-theme' ) ),
									$initial_count
								);
							} else {
								esc_html_e( 'Selezione d’eccellenza', 'oasidellespezie-child-theme' );
							}
							?>
						</p>
						<p class="oasi-megamenu__card-hint"><?php esc_html_e( 'Apri una sottocategoria per esplorare i prodotti.', 'oasidellespezie-child-theme' ); ?></p>
					</div>
				</div>
			</div>
		</div>
	</div>
	<?php
}

/**
 * Render the language switcher (tw-translate-plus) in the header actions.
 *
 * The plugin only supplies the data: published languages, emoji flag and the
 * URL of the current page in each language (twtr_get_languages()). Only the
 * flag is shown; the full name stays in the title and in screen-reader text.
 * On Windows flag emoji do not exist and the browser shows the two-letter
 * country code (IT / DE / FR), so the switcher stays readable.
 * With a single published language nothing is printed.
 *
 * Printed twice: in the header actions ('header') and in the mobile drawer
 * header ('drawer'). Below 480px the header copy is hidden and the drawer one
 * shown: measured 2026-09-25, three flags + account + cart + toggle need
 * ~420px and at 390px the toggle ended at 394px (horizontal overflow).
 *
 * @param string $context 'header' or 'drawer'.
 */
function oasi_render_language_switcher( string $context = 'header' ): void {
	$languages = function_exists( 'twtr_get_languages' ) ? twtr_get_languages() : array();
	if ( count( $languages ) < 2 ) {
		return;
	}
	$context = 'drawer' === $context ? 'drawer' : 'header';
	?>
	<nav class="oasi-header__lang oasi-header__lang--<?php echo esc_attr( $context ); ?>" aria-label="<?php esc_attr_e( 'Lingua', 'oasidellespezie-child-theme' ); ?>">
		<?php foreach ( $languages as $language ) : ?>
			<?php $hreflang = str_replace( '_', '-', (string) $language['locale'] ); ?>
			<a
				href="<?php echo esc_url( $language['url'] ); ?>"
				hreflang="<?php echo esc_attr( $hreflang ); ?>"
				lang="<?php echo esc_attr( $hreflang ); ?>"
				class="oasi-header__lang-link<?php echo ! empty( $language['is_current'] ) ? ' is-current' : ''; ?>"
				title="<?php echo esc_attr( $language['label'] ); ?>"
				<?php echo ! empty( $language['is_current'] ) ? 'aria-current="page"' : ''; ?>
			>
				<span class="oasi-header__lang-flag" aria-hidden="true"><?php echo esc_html( $language['flag'] ); ?></span>
				<span class="screen-reader-text"><?php echo esc_html( $language['label'] ); ?></span>
			</a>
		<?php endforeach; ?>
	</nav>
	<?php
}

/**
 * Render the Multi-Level Sliding Drawer for Mobile & Tablet.
 */
function oasi_render_mobile_drawer(): void {
	$families    = oasi_get_megamenu_tree();
	$cart_count  = ( function_exists( 'WC' ) && WC()->cart ) ? WC()->cart->get_cart_contents_count() : 0;
	$cart_url    = function_exists( 'wc_get_cart_url' ) ? wc_get_cart_url() : home_url( '/carrello/' );
	$account_url = function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'myaccount' ) : home_url( '/mio-account/' );
	$shop_url    = function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'shop' ) : home_url( '/shop-online-oasi-delle-spezie/' );

	$contact_top = function_exists( 'oasi_get_contact_data' ) ? oasi_get_contact_data() : array();
	$top_phone   = $contact_top['phone'] ?? '+41 91 859 05 32';
	$top_tel     = $contact_top['phone_tel'] ?? '+41918590532';
	?>
	<div class="oasi-drawer" id="oasi-mobile-drawer" aria-hidden="true" role="dialog" aria-modal="true" aria-label="<?php esc_attr_e( 'Menu mobile', 'oasidellespezie-child-theme' ); ?>">
		<div class="oasi-drawer__backdrop" id="oasi-drawer-backdrop"></div>
		<div class="oasi-drawer__panel">
			<!-- Top bar of drawer -->
			<div class="oasi-drawer__header">
				<div class="oasi-drawer__brand">
					<img src="<?php echo esc_url( oasi_get_master_logo_url() ); ?>" alt="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>" class="oasi-drawer__logo" width="130" height="57">
				</div>
				<?php oasi_render_language_switcher( 'drawer' ); ?>
				<button type="button" class="oasi-drawer__close" id="oasi-drawer-close" aria-label="<?php esc_attr_e( 'Chiudi menu', 'oasidellespezie-child-theme' ); ?>">
					<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
				</button>
			</div>

			<!-- Sliding Viewport: holds tracks of 3 levels -->
			<div class="oasi-drawer__viewport">
				<div class="oasi-drawer__slider" id="oasi-drawer-slider" data-active-level="1">
					<!-- LEVEL 1: Main Menu -->
					<div class="oasi-drawer__pane oasi-drawer__pane--level1" data-level="1">
						<form class="oasi-drawer-search" role="search" method="get" action="<?php echo esc_url( $shop_url ); ?>">
							<label class="screen-reader-text" for="oasi-drawer-product-search"><?php esc_html_e( 'Cerca prodotti', 'oasidellespezie-child-theme' ); ?></label>
							<svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><circle cx="11" cy="11" r="7"></circle><path d="m20 20-4-4"></path></svg>
							<input id="oasi-drawer-product-search" type="search" name="oasi_q" placeholder="<?php esc_attr_e( 'Cerca prodotti…', 'oasidellespezie-child-theme' ); ?>" required>
							<button type="submit" aria-label="<?php esc_attr_e( 'Avvia la ricerca', 'oasidellespezie-child-theme' ); ?>">&rarr;</button>
						</form>
						<nav class="oasi-drawer__nav" aria-label="<?php esc_attr_e( 'Navigazione Principale Mobile', 'oasidellespezie-child-theme' ); ?>">
							<ul class="oasi-drawer__list">
								<!-- Trigger for Level 2 (Shop Mega Menu) -->
								<li class="oasi-drawer__item oasi-drawer__item--has-children">
									<button type="button" class="oasi-drawer__drilldown-btn" id="oasi-mobile-shop-trigger" data-target-level="2" aria-expanded="false">
										<span class="oasi-drawer__drilldown-label">
											<span class="oasi-drawer__icon-badge">🌿</span>
											<strong><?php esc_html_e( 'Shop Categorie', 'oasidellespezie-child-theme' ); ?></strong>
										</span>
										<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="9 18 15 12 9 6"></polyline></svg>
									</button>
								</li>
								<?php
								// Primary menu items for mobile
								$primary_locations = get_nav_menu_locations();
								$primary_menu_id   = $primary_locations['primary'] ?? 0;
								$primary_items     = $primary_menu_id ? wp_get_nav_menu_items( $primary_menu_id ) : array();

								if ( ! empty( $primary_items ) && ! is_wp_error( $primary_items ) ) {
									foreach ( $primary_items as $p_item ) {
										// Skip Shop from flat list since it has the drilldown trigger above
										if ( 'shop' === strtolower( trim( $p_item->title ) ) ) {
											continue;
										}
										?>
										<li class="oasi-drawer__item">
											<a href="<?php echo esc_url( $p_item->url ); ?>" class="oasi-drawer__link">
												<?php echo esc_html( $p_item->title ); ?>
											</a>
										</li>
										<?php
									}
								} else {
									?>
									<li class="oasi-drawer__item"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="oasi-drawer__link"><?php esc_html_e( 'Home', 'oasidellespezie-child-theme' ); ?></a></li>
									<li class="oasi-drawer__item"><a href="<?php echo esc_url( home_url( '/chi-siamo/' ) ); ?>" class="oasi-drawer__link"><?php esc_html_e( 'Chi siamo', 'oasidellespezie-child-theme' ); ?></a></li>
									<li class="oasi-drawer__item"><a href="<?php echo esc_url( home_url( '/scoprite-le-nostre-novita/' ) ); ?>" class="oasi-drawer__link"><?php esc_html_e( 'Novità', 'oasidellespezie-child-theme' ); ?></a></li>
									<li class="oasi-drawer__item"><a href="<?php echo esc_url( home_url( '/contatto/' ) ); ?>" class="oasi-drawer__link"><?php esc_html_e( 'Contatto', 'oasidellespezie-child-theme' ); ?></a></li>
									<li class="oasi-drawer__item"><a href="<?php echo esc_url( home_url( '/catalogo-professionista/' ) ); ?>" class="oasi-drawer__link"><?php esc_html_e( 'Professionista', 'oasidellespezie-child-theme' ); ?></a></li>
									<li class="oasi-drawer__item"><a href="<?php echo esc_url( $account_url ); ?>" class="oasi-drawer__link"><?php esc_html_e( 'Account', 'oasidellespezie-child-theme' ); ?></a></li>
									<?php
								}
								?>
							</ul>
						</nav>
					</div>

					<!-- LEVEL 2: Shop Category Families -->
					<div class="oasi-drawer__pane oasi-drawer__pane--level2" data-level="2">
						<div class="oasi-drawer__pane-header">
							<button type="button" class="oasi-drawer__back-btn" data-back-level="1" aria-label="<?php esc_attr_e( 'Torna al menu principale', 'oasidellespezie-child-theme' ); ?>">
								<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="15 18 9 12 15 6"></polyline></svg>
								<span><?php esc_html_e( 'Menu Principale', 'oasidellespezie-child-theme' ); ?></span>
							</button>
							<span class="oasi-drawer__pane-title"><?php esc_html_e( 'Categorie Shop', 'oasidellespezie-child-theme' ); ?></span>
						</div>

						<ul class="oasi-drawer__list">
							<?php
							$shop_id   = function_exists( 'wc_get_page_id' ) ? wc_get_page_id( 'shop' ) : 0;
							$shop_link = $shop_id > 0 ? get_permalink( $shop_id ) : home_url( '/shop-online-oasi-delle-spezie/' );
							?>
							<li class="oasi-drawer__item oasi-drawer__item--shop-all">
								<a href="<?php echo esc_url( $shop_link ); ?>" class="oasi-drawer__link--shop-all">
									<span class="oasi-drawer__shop-all-left">
										<span class="oasi-drawer__shop-all-badge" aria-hidden="true">
											<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
												<rect x="3" y="3" width="7" height="7"></rect>
												<rect x="14" y="3" width="7" height="7"></rect>
												<rect x="14" y="14" width="7" height="7"></rect>
												<rect x="3" y="14" width="7" height="7"></rect>
											</svg>
										</span>
										<span class="oasi-drawer__shop-all-title"><?php esc_html_e( 'Tutti i Prodotti dello Shop', 'oasidellespezie-child-theme' ); ?></span>
									</span>
									<span class="oasi-drawer__shop-all-arrow" aria-hidden="true">
										<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
											<line x1="5" y1="12" x2="19" y2="12"></line>
											<polyline points="12 5 19 12 12 19"></polyline>
										</svg>
									</span>
								</a>
							</li>

							<?php foreach ( $families as $fam ) : ?>
								<li class="oasi-drawer__item oasi-drawer__item--has-children">
									<?php if ( ! empty( $fam['children'] ) ) : ?>
										<button type="button"
												class="oasi-drawer__drilldown-btn oasi-drawer__drilldown-sub"
												data-target-level="3"
												data-target-subpanel="oasi-mob-sub-<?php echo esc_attr( (string) $fam['id'] ); ?>"
												data-parent-title="<?php echo esc_attr( $fam['title'] ); ?>">
											<span class="oasi-drawer__drilldown-label"><?php echo esc_html( $fam['title'] ); ?></span>
											<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="9 18 15 12 9 6"></polyline></svg>
										</button>
									<?php else : ?>
										<a href="<?php echo esc_url( $fam['url'] ); ?>" class="oasi-drawer__link">
											<?php echo esc_html( $fam['title'] ); ?>
										</a>
									<?php endif; ?>
								</li>
							<?php endforeach; ?>
						</ul>
					</div>

					<!-- LEVEL 3: Subcategories View -->
					<div class="oasi-drawer__pane oasi-drawer__pane--level3" data-level="3">
						<div class="oasi-drawer__pane-header">
							<button type="button" class="oasi-drawer__back-btn" data-back-level="2" id="oasi-mob-back-to-level2" aria-label="<?php esc_attr_e( 'Torna alle categorie', 'oasidellespezie-child-theme' ); ?>">
								<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="15 18 9 12 15 6"></polyline></svg>
								<span id="oasi-mob-level3-back-label"><?php esc_html_e( 'Categorie', 'oasidellespezie-child-theme' ); ?></span>
							</button>
							<span class="oasi-drawer__pane-title" id="oasi-mob-level3-title"><?php esc_html_e( 'Sottocategorie', 'oasidellespezie-child-theme' ); ?></span>
						</div>

						<div class="oasi-drawer__subpanels-wrap">
							<?php foreach ( $families as $fam ) : ?>
								<div class="oasi-drawer__subgroup" id="oasi-mob-sub-<?php echo esc_attr( (string) $fam['id'] ); ?>" style="display: none;">
									<ul class="oasi-drawer__list">
										<?php if ( ! empty( $fam['children'] ) ) : ?>
											<?php foreach ( $fam['children'] as $ch ) : ?>
												<li class="oasi-drawer__item">
													<a href="<?php echo esc_url( $ch['url'] ); ?>" class="oasi-drawer__link">
														<span><?php echo esc_html( $ch['title'] ); ?></span>
														<?php if ( $ch['count'] > 0 ) : ?>
															<span class="oasi-drawer__count-badge"><?php echo esc_html( (string) $ch['count'] ); ?></span>
														<?php endif; ?>
													</a>
												</li>
											<?php endforeach; ?>
										<?php endif; ?>
									</ul>
								</div>
							<?php endforeach; ?>
						</div>
					</div>
				</div>
			</div>

			<!-- Quick Bottom Shortcuts (Account, Cart, Phone) -->
			<div class="oasi-drawer__footer">
				<div class="oasi-drawer__actions">
					<a href="<?php echo esc_url( $account_url ); ?>" class="oasi-drawer__action-btn">
						<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>
						<span><?php esc_html_e( 'Account', 'oasidellespezie-child-theme' ); ?></span>
					</a>
					<a href="<?php echo esc_url( $cart_url ); ?>" class="oasi-drawer__action-btn oasi-drawer__action-btn--cart">
						<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="9" cy="21" r="1"></circle><circle cx="20" cy="21" r="1"></circle><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"></path></svg>
						<span><?php esc_html_e( 'Carrello', 'oasidellespezie-child-theme' ); ?> (<span class="oasi-mob-cart-count"><?php echo esc_html( (string) $cart_count ); ?></span>)</span>
					</a>
				</div>
				<div class="oasi-drawer__contact">
					<a href="tel:<?php echo esc_attr( $top_tel ); ?>" class="oasi-drawer__phone-link">
						<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path></svg>
						<span><?php echo esc_html( $top_phone ); ?></span>
					</a>
				</div>
			</div>
		</div>
	</div>
	<?php
}

/**
 * Programmatic bootstrap for the two dedicated menus:
 * 1. "Oasi delle Spezie — Menu Principale" (assigned to 'primary')
 * 2. "Oasi delle Spezie — Mega Menu Shop" (assigned to 'shop_megamenu')
 *
 * Idempotent: Does NOT touch or delete existing old menus!
 */
function oasi_setup_default_menus(): void {
	// 1. SETUP MENU PRINCIPALE
	$main_menu_name = 'Oasi delle Spezie — Menu Principale';
	$main_menu_obj  = wp_get_nav_menu_object( $main_menu_name );

	if ( ! $main_menu_obj ) {
		$main_menu_id = wp_create_nav_menu( $main_menu_name );
		if ( ! is_wp_error( $main_menu_id ) ) {
			// Find actual pages by path/ID
			$pages_map = array(
				array( 'title' => 'Home', 'path' => '/', 'id' => 31657 ),
				array( 'title' => 'Shop', 'path' => 'shop-online-oasi-delle-spezie', 'id' => 29 ),
				array( 'title' => 'Chi siamo', 'path' => 'chi-siamo', 'id' => 2 ),
				array( 'title' => 'Novità', 'path' => 'scoprite-le-nostre-novita', 'id' => 16465 ),
				array( 'title' => 'Contatto', 'path' => 'contatto', 'id' => 117 ),
				array( 'title' => 'Professionista', 'path' => 'catalogo-professionista', 'id' => 14401 ),
				array( 'title' => 'Account', 'path' => 'mio-account', 'id' => 7 ),
			);

			$menu_order = 1;
			foreach ( $pages_map as $p_info ) {
				$page = get_post( $p_info['id'] );
				if ( ! $page || 'page' !== $page->post_type ) {
					$page = get_page_by_path( $p_info['path'] );
				}

				if ( $page ) {
					wp_update_nav_menu_item(
						$main_menu_id,
						0,
						array(
							'menu-item-title'     => $p_info['title'],
							'menu-item-object-id' => $page->ID,
							'menu-item-object'    => 'page',
							'menu-item-type'      => 'post_type',
							'menu-item-status'    => 'publish',
							'menu-item-position'  => $menu_order++,
						)
					);
				}
			}

			// Assign to 'primary' location
			$locations = get_nav_menu_locations();
			$locations['primary'] = (int) $main_menu_id;
			set_theme_mod( 'nav_menu_locations', $locations );
		}
	} else {
		// Ensure location is assigned
		$locations = get_nav_menu_locations();
		if ( ! isset( $locations['primary'] ) || (int) $locations['primary'] !== (int) $main_menu_obj->term_id ) {
			$locations['primary'] = (int) $main_menu_obj->term_id;
			set_theme_mod( 'nav_menu_locations', $locations );
		}
	}

	// 2. SETUP MEGA MENU SHOP
	$mega_menu_name  = 'Oasi delle Spezie — Mega Menu Shop';
	$mega_menu_obj   = wp_get_nav_menu_object( $mega_menu_name );
	$mega_menu_items = $mega_menu_obj ? wp_get_nav_menu_items( (int) $mega_menu_obj->term_id ) : array();

	if ( ! $mega_menu_obj || empty( $mega_menu_items ) || count( $mega_menu_items ) < 10 ) {
		$mega_menu_id = $mega_menu_obj ? (int) $mega_menu_obj->term_id : wp_create_nav_menu( $mega_menu_name );
		if ( ! is_wp_error( $mega_menu_id ) && $mega_menu_id > 0 ) {
			// Clear any sparse items to prevent duplication
			if ( ! empty( $mega_menu_items ) ) {
				foreach ( $mega_menu_items as $old_it ) {
					wp_delete_post( (int) $old_it->ID, true );
				}
			}

			// Define structured real taxonomy hierarchy
			$families_data = array(
				array(
					'title'      => 'Spezie, Erbe & Botaniche',
					'main_slug'  => 'spezie-bio',
					'children'   => array(
						'spezie-bio'              => 'Spezie Pure Bio',
						'erbe-aromatiche-bio'     => 'Erbe Aromatiche Bio',
						'mix-erbe-aromatiche-bio' => 'Mix Erbe Aromatiche Bio',
						'semi-aromatici-bio'      => 'Semi Aromatici Bio',
						'chili-paprika-bio'       => 'Chili & Paprika Bio',
						'vaniglie'                => 'Vaniglie Pregiate',
						'fiori-bio'               => 'Fiori Eduli Bio',
						'aglio-nero'              => 'Aglio Nero Fermentato',
					),
				),
				array(
					'title'      => 'Miscele Artigianali Oasi',
					'main_slug'  => 'miscele-di-spezie-bio',
					'children'   => array(
						'miscele-di-spezie-bio'   => 'Miscele di Spezie Bio',
						'rub-bio'                 => 'Rub per Barbecue Bio',
					),
				),
				array(
					'title'      => 'Pepi Rari & Sali dal Mondo',
					'main_slug'  => 'pepi-e-bacche-bio',
					'children'   => array(
						'pepi-e-bacche-bio'       => 'Pepi & Bacche Nobili',
						'pepi-aromatizzati-bio'   => 'Pepi Aromatizzati Bio',
						'sali-del-mondo'          => 'Sali dal Mondo',
						'fior-di-sali'            => 'Fior di Sale Naturale',
						'sali-aromatizzati-bio'   => 'Sali Aromatizzati Bio',
					),
				),
				array(
					'title'      => 'Tè, Tisane & Botaniche',
					'main_slug'  => 'te-bio',
					'children'   => array(
						'te-bio'                  => 'Tè Pregiati Biologici',
						'alghe'                   => 'Alghe Alimentari Bio',
					),
				),
				array(
					'title'      => 'Dispensa Gourmet & Benessere',
					'main_slug'  => 'condimenti-bio',
					'children'   => array(
						'cioccolato-bio'          => 'Cioccolato Artigianale Bio',
						'condimenti-bio'          => 'Condimenti & Speziature Bio',
						'zuccheri-dorigine-bio'   => 'Zuccheri d’Origine & Panela',
						'frutta-secca-bio'        => 'Frutta Secca Bio',
						'superfood-bio'           => 'Superfood & Superpolveri Bio',
						'aceto-balsamico-dop'     => 'Aceto Balsamico Tradizionale DOP',
						'mieli-e-marmellate-bio'  => 'Mieli & Marmellate Bio',
						'sciroppi-bio'            => 'Sciroppi Naturali Bio',
						'prodotti-svizzeri-bio'   => 'Prodotti del Terroir Svizzero',
					),
				),
				array(
					'title'      => 'Idee Regalo & Accessori',
					'main_slug'  => 'idee-regalo',
					'children'   => array(
						'idee-regalo'             => 'Idee Regalo & Confezioni',
						'box'                     => 'Box Degustazione',
						'accessori'               => 'Accessori & Macinini',
						'date-corte'              => 'Offerte a Data Corta',
					),
				),
			);

			$order = 1;
			foreach ( $families_data as $fam ) {
				$parent_term = get_term_by( 'slug', $fam['main_slug'], 'product_cat' );
				$parent_term_id = ( $parent_term && ! is_wp_error( $parent_term ) ) ? (int) $parent_term->term_id : 0;

				$parent_item_args = array(
					'menu-item-title'    => $fam['title'],
					'menu-item-status'   => 'publish',
					'menu-item-position' => $order++,
				);

				if ( $parent_term_id > 0 ) {
					$parent_item_args['menu-item-object-id'] = $parent_term_id;
					$parent_item_args['menu-item-object']    = 'product_cat';
					$parent_item_args['menu-item-type']      = 'taxonomy';
				} else {
					$parent_item_args['menu-item-url']  = home_url( '/shop-online-oasi-delle-spezie/' );
					$parent_item_args['menu-item-type'] = 'custom';
				}

				$parent_item_id = wp_update_nav_menu_item( $mega_menu_id, 0, $parent_item_args );

				if ( ! is_wp_error( $parent_item_id ) && $parent_item_id > 0 ) {
					foreach ( $fam['children'] as $ch_slug => $ch_title ) {
						$ch_term = get_term_by( 'slug', $ch_slug, 'product_cat' );
						if ( $ch_term && ! is_wp_error( $ch_term ) ) {
							wp_update_nav_menu_item(
								$mega_menu_id,
								0,
								array(
									'menu-item-title'     => $ch_title,
									'menu-item-object-id' => (int) $ch_term->term_id,
									'menu-item-object'    => 'product_cat',
									'menu-item-type'      => 'taxonomy',
									'menu-item-parent-id' => (int) $parent_item_id,
									'menu-item-status'    => 'publish',
									'menu-item-position'  => $order++,
								)
							);
						}
					}
				}
			}

			// Assign to 'shop_megamenu' location
			$locations = get_nav_menu_locations();
			$locations['shop_megamenu'] = (int) $mega_menu_id;
			set_theme_mod( 'nav_menu_locations', $locations );
		}
	} else {
		// Ensure location is assigned
		$locations = get_nav_menu_locations();
		if ( ! isset( $locations['shop_megamenu'] ) || (int) $locations['shop_megamenu'] !== (int) $mega_menu_obj->term_id ) {
			$locations['shop_megamenu'] = (int) $mega_menu_obj->term_id;
			set_theme_mod( 'nav_menu_locations', $locations );
		}
	}
}
/**
 * Seed the menus once, instead of re-checking them on every request.
 *
 * The check used to run on `init` for every page, cart fragment and REST call
 * (two menu lookups plus a full read of ~40 mega-menu items). Worse, if an editor
 * left fewer than 10 items, the next visitor's request deleted and rebuilt the
 * menu. Now it runs only from wp-admin until it has succeeded once, and again
 * when the theme is (re)activated.
 */
function oasi_maybe_setup_default_menus(): void {
	if ( '1' === get_option( 'oasi_menus_seed_version' ) ) {
		return;
	}

	oasi_setup_default_menus();
	update_option( 'oasi_menus_seed_version', '1', false );
}
add_action( 'admin_init', 'oasi_maybe_setup_default_menus' );
add_action( 'after_switch_theme', 'oasi_setup_default_menus' );
