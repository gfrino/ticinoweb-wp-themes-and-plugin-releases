<?php
/**
 * Template Name: Collezione / Gallery
 * Description: Pagina immersiva e lookbook per la collezione Monvél.
 */

get_header();

// Hero Data
$hero_title    = get_option('ticinoweb_collezione_title', 'COLLEZIONE');
$hero_subtitle = get_option('ticinoweb_collezione_subtitle', 'Immagini, dettagli e mood dal mondo Monvél.');
$eyebrow       = 'MONVÉL GALLERY';

// Fetch Gallery Images
$gallery_images = array();
$gallery_id = get_option('ticinoweb_collezione_gallery', 32); // Fallback to 32 come richiesto

if ($gallery_id) {
    $images = new WP_Query(array(
        'post_type'      => 'attachment',
        'post_status'    => 'inherit',
        'posts_per_page' => 500,
        'tax_query' => array(
            array(
                'taxonomy' => 'ticinoweb_media_gallery',
                'field'    => 'term_id',
                'terms'    => $gallery_id,
            )
        )
    ));

    $saved_order = get_term_meta($gallery_id, '_ticinoweb_gallery_order', true);
    if (!is_array($saved_order)) {
        $saved_order = array();
    }

    if (!empty($saved_order) && $images->have_posts()) {
        usort($images->posts, function ($a, $b) use ($saved_order) {
            $posA = array_search($a->ID, $saved_order);
            $posB = array_search($b->ID, $saved_order);
            if ($posA === false) $posA = 999999;
            if ($posB === false) $posB = 999999;
            return $posA - $posB;
        });
    }

    if ($images->have_posts()) {
        foreach ($images->posts as $attachment) {
            $gallery_images[] = array(
                'url' => wp_get_attachment_image_url($attachment->ID, 'full'),
                'caption' => wp_get_attachment_caption($attachment->ID) ?: 'Monvél in detail.'
            );
        }
    }
}

// Fallback: try attached media se la galleria è vuota
if (empty($gallery_images)) {
    $attached = get_attached_media('image', get_the_ID());
    if(!empty($attached)) {
        foreach($attached as $attachment) {
            $gallery_images[] = array(
                'url' => wp_get_attachment_image_url($attachment->ID, 'full'),
                'caption' => wp_get_attachment_caption($attachment->ID) ?: 'Monvél in detail.'
            );
        }
    }
}

// Fallback Premium
if (empty($gallery_images)) {
    $gallery_images = array(
        array('url' => 'https://images.unsplash.com/photo-1556228578-0d85b1a4d571?q=80&w=2000&auto=format&fit=crop', 'caption' => 'Essential Form.'),
        array('url' => 'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?q=80&w=1400&auto=format&fit=crop', 'caption' => 'Urban mood.'),
        array('url' => 'https://images.unsplash.com/photo-1512413914565-eb7df1264c84?q=80&w=1400&auto=format&fit=crop', 'caption' => 'Streetwear codes.'),
        array('url' => 'https://images.unsplash.com/photo-1622470953794-aa9c70b0fb9d?q=80&w=1400&auto=format&fit=crop', 'caption' => 'The Stitching.'),
        array('url' => 'https://images.unsplash.com/photo-1533827432537-70133748f5c8?q=80&w=1400&auto=format&fit=crop', 'caption' => 'Curve detail.'),
        array('url' => 'https://images.unsplash.com/photo-1520975954732-35dd5dd29c5e?q=80&w=1400&auto=format&fit=crop', 'caption' => 'Snap attitude.'),
        array('url' => 'https://images.unsplash.com/photo-1542340916-24da6e94e773?q=80&w=1400&auto=format&fit=crop', 'caption' => 'Fabric texture.'),
        array('url' => 'https://images.unsplash.com/photo-1558507652-2d9626c4e67a?q=80&w=1400&auto=format&fit=crop', 'caption' => 'Monvél Archive.'),
        array('url' => 'https://images.unsplash.com/photo-1523381210434-271e8be1f52b?q=80&w=1400&auto=format&fit=crop', 'caption' => 'Streetwear Essentials.')
    );
}

$shop_url = function_exists('wc_get_page_permalink') ? wc_get_page_permalink('shop') : home_url('/shop/');

$total_images = count($gallery_images);
?>

<main id="primary" class="site-main mv-coll-page">

    <!-- 1. HERO (uguale a Shop/Brands) -->
    <div class="mv-shop-hero">
        <div class="mv-shop-hero-bg-text">MONVÉL</div>
        <span class="mv-shop-eyebrow"><?php echo esc_html($eyebrow); ?></span>
        <h1 class="mv-shop-title"><?php echo wp_kses_post($hero_title); ?></h1>
        <p class="mv-shop-subtitle"><?php echo wp_kses_post($hero_subtitle); ?></p>
    </div>

    <!-- 2. MARQUEE BACKGROUND LOOP -->
    <div class="mv-coll-bg-marquee">
        <div class="mv-coll-bg-marquee-track">
            <span>MONVÉL — CURVE — SNAP — STREETWEAR ESSENTIALS — </span>
            <span>MONVÉL — CURVE — SNAP — STREETWEAR ESSENTIALS — </span>
        </div>
    </div>

    <!-- 3. GALLERY EDITORIAL FLOW -->
    <section class="mv-coll-flow monvel-container">
        
        <?php 
        $count = 1;
        $half_point = ceil($total_images / 2);

        foreach($gallery_images as $index => $img): 
            $pos = $index + 1;
            
            // Logica Layout Asimmetrico
            $layout_class = 'mv-coll-item-standard';
            if ($pos == 1 || $pos == 5 || $pos == 9 || $pos == 12) {
                $layout_class = 'mv-coll-item-featured'; // Immersiva, grande
            } elseif ($pos == 2 || $pos == 3 || $pos == 10 || $pos == 11 || $pos == 13 || $pos == 14) {
                $layout_class = 'mv-coll-item-split'; // Affiancate
            } elseif ($pos == 4 || $pos == 8) {
                $layout_class = 'mv-coll-item-offset'; // Verticale decentrata
            } elseif ($pos == 6 || $pos == 7) {
                $layout_class = 'mv-coll-item-compact'; // Griglia dettagli
            }
            
            $num_str = str_pad($pos, 2, '0', STR_PAD_LEFT);

            // Regola Focal Point (Cappello protagonista)
            $focus_class = '';
            if (in_array($pos, [1, 12])) {
                $focus_class = 'mv-focus-extreme-top'; // Visual 01 e 012 devono mostrare ancora più cappello
            } elseif (in_array($pos, [5, 7, 9])) {
                $focus_class = 'mv-focus-top'; // Assicura che il crop non tagli il cappello
            }
        ?>

            <div class="mv-coll-item <?php echo esc_attr($layout_class); ?> fade-up-el">
                <div class="mv-coll-img-wrap mv-lightbox-trigger" data-index="<?php echo esc_attr($index); ?>">
                    <img src="<?php echo esc_url($img['url']); ?>" alt="<?php echo esc_attr($img['caption']); ?>" class="mv-coll-img <?php echo esc_attr($focus_class); ?>" loading="lazy">
                    <div class="mv-coll-overlay">
                        <span class="mv-coll-expand-icon">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 3 21 3 21 9"></polyline><polyline points="9 21 3 21 3 15"></polyline><line x1="21" y1="3" x2="14" y2="10"></line><line x1="3" y1="21" x2="10" y2="14"></line></svg>
                        </span>
                    </div>
                </div>
                <div class="mv-coll-meta">
                    <span class="mv-coll-label">VISUAL <?php echo $num_str; ?></span>
                    <span class="mv-coll-caption"><?php echo esc_html($img['caption']); ?></span>
                </div>
            </div>

            <?php 
            // Pausa Editoriale a metà
            if ($pos == $half_point): 
            ?>
            <div class="mv-coll-editorial-break fade-up-el">
                <h2>NON SOLO CAPPELLI.<br>UN MODO DI STARE NEL LOOK.</h2>
            </div>
            <?php endif; ?>

        <?php 
        $count++;
        endforeach; 
        ?>
    </section>

    <!-- 4. CTA FINALE -->
    <section class="mv-str-closing" style="margin-top: 100px;">
        <div class="mv-str-closing-bg">MONVÉL</div>
        <div class="monvel-container">
            <h2 class="mv-str-closing-title">SCOPRI I MODELLI MONVÉL</h2>
            <p class="mv-str-closing-subtitle">Curve o Snap, scegli il modello che completa il tuo stile.</p>
            <a href="<?php echo esc_url($shop_url); ?>" class="mv-btn mv-btn-primary mv-str-btn"><span>VAI ALLO SHOP</span></a>
        </div>
    </section>

</main>

<!-- VANILLA JS LIGHTBOX -->
<div class="mv-lightbox" id="mv-lightbox">
    <div class="mv-lightbox-bg"></div>
    <div class="mv-lightbox-close" id="mv-lightbox-close">
        <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
    </div>
    
    <div class="mv-lightbox-content">
        <img src="" alt="" id="mv-lightbox-img">
        <div class="mv-lightbox-caption" id="mv-lightbox-caption"></div>
    </div>

    <div class="mv-lightbox-nav mv-lightbox-prev" id="mv-lightbox-prev">
        <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 18 9 12 15 6"></polyline></svg>
    </div>
    <div class="mv-lightbox-nav mv-lightbox-next" id="mv-lightbox-next">
        <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 18 15 12 9 6"></polyline></svg>
    </div>

    <div class="mv-lightbox-counter">
        <span id="mv-lightbox-current">1</span> / <span id="mv-lightbox-total"><?php echo $total_images; ?></span>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // 1. Observer Globale per le animazioni (Fade-Up e Reveal Immagini)
    const fadeObserver = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('visible');
                observer.unobserve(entry.target);
            }
        });
    }, { threshold: 0.1 });

    document.querySelectorAll('.fade-up-el').forEach((el, index) => {
        // Applica un leggero ritardo sequenziale se sono affiancate
        if (el.classList.contains('mv-coll-item-split') || el.classList.contains('mv-coll-item-compact')) {
            el.style.transitionDelay = (index % 2) * 0.15 + 's';
        }
        fadeObserver.observe(el);
    });

    // 2. Vanilla Lightbox Logic
    const galleryData = <?php echo json_encode($gallery_images); ?>;
    const lightbox = document.getElementById('mv-lightbox');
    const lbImg = document.getElementById('mv-lightbox-img');
    const lbCaption = document.getElementById('mv-lightbox-caption');
    const lbCurrent = document.getElementById('mv-lightbox-current');
    let currentIndex = 0;

    const openLightbox = (index) => {
        currentIndex = parseInt(index);
        updateLightbox();
        lightbox.classList.add('active');
        document.body.style.overflow = 'hidden'; // prevent scrolling
    };

    const closeLightbox = () => {
        lightbox.classList.remove('active');
        document.body.style.overflow = '';
        setTimeout(() => { lbImg.src = ''; }, 400); // clear img after fade out
    };

    const updateLightbox = () => {
        const item = galleryData[currentIndex];
        // fade out slightly
        lbImg.style.opacity = 0;
        setTimeout(() => {
            lbImg.src = item.url;
            lbImg.alt = item.caption;
            lbCaption.innerText = item.caption;
            lbCurrent.innerText = currentIndex + 1;
            lbImg.style.opacity = 1;
        }, 150);
    };

    const nextImage = () => {
        currentIndex = (currentIndex + 1) % galleryData.length;
        updateLightbox();
    };

    const prevImage = () => {
        currentIndex = (currentIndex - 1 + galleryData.length) % galleryData.length;
        updateLightbox();
    };

    // Event Listeners Lightbox
    document.querySelectorAll('.mv-lightbox-trigger').forEach(trigger => {
        trigger.addEventListener('click', (e) => {
            e.preventDefault();
            openLightbox(trigger.getAttribute('data-index'));
        });
    });

    document.getElementById('mv-lightbox-close').addEventListener('click', closeLightbox);
    document.getElementById('mv-lightbox-next').addEventListener('click', nextImage);
    document.getElementById('mv-lightbox-prev').addEventListener('click', prevImage);

    // Keyboard support
    document.addEventListener('keydown', (e) => {
        if (!lightbox.classList.contains('active')) return;
        if (e.key === 'Escape') closeLightbox();
        if (e.key === 'ArrowRight') nextImage();
        if (e.key === 'ArrowLeft') prevImage();
    });

    // Parallax Soft sulle immagini featured
    const featuredItems = document.querySelectorAll('.mv-coll-item-featured .mv-coll-img');
    window.addEventListener('scroll', () => {
        let scrolled = window.pageYOffset;
        featuredItems.forEach(img => {
            let offset = img.getBoundingClientRect().top;
            if(offset < window.innerHeight && offset > -window.innerHeight) {
                img.style.transform = `translateY(${offset * 0.05}px) scale(1.03)`;
            }
        });
    });
});
</script>

<?php
get_footer();
