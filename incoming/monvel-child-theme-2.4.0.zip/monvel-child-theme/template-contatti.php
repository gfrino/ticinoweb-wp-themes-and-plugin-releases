<?php
/**
 * Template Name: Contatti
 *
 * Pagina contatti premium immersiva per Monvél.
 * Concept: "TALK TO THE DROP". Senza form.
 *
 * @package Monvel
 */

get_header();

// ==========================================
// 1. FETCH MEDIA GALLERY (ID 35)
// ==========================================
$gallery_images = array();
$target_gallery_id = 35; // Come richiesto esplicitamente dal prompt

$images_query = new WP_Query(array(
    'post_type'      => 'attachment',
    'post_status'    => 'inherit',
    'posts_per_page' => 10,
    'tax_query' => array(
        array(
            'taxonomy' => 'ticinoweb_media_gallery',
            'field'    => 'term_id',
            'terms'    => $target_gallery_id,
        )
    )
));

// Recupero l'ordine salvato se disponibile
$saved_order = get_term_meta($target_gallery_id, '_ticinoweb_gallery_order', true);
if (!is_array($saved_order)) $saved_order = array();

if (!empty($saved_order) && $images_query->have_posts()) {
    usort($images_query->posts, function ($a, $b) use ($saved_order) {
        $posA = array_search($a->ID, $saved_order);
        $posB = array_search($b->ID, $saved_order);
        if ($posA === false) $posA = 999999;
        if ($posB === false) $posB = 999999;
        return $posA - $posB;
    });
}

if ($images_query->have_posts()) {
    foreach ($images_query->posts as $attachment) {
        $gallery_images[] = wp_get_attachment_image_url($attachment->ID, 'full');
    }
}

// ==========================================
// 2. CONTACT DATA (TicinoWEB CMS)
// ==========================================
$email         = get_option('ticinoweb_contact_email');
$email_2       = get_option('ticinoweb_contact_email_2');
$email_3       = get_option('ticinoweb_contact_email_3');
$phone         = get_option('ticinoweb_contact_phone');
$phone_land    = get_option('ticinoweb_contact_phone_landline');
$phone_mob     = get_option('ticinoweb_contact_phone_mobile');
$address       = get_option('ticinoweb_contact_address');

// Helper arrays
$emails = array_filter(array($email, $email_2, $email_3));
$phones = array_filter(array($phone, $phone_mob, $phone_land));

// Social
$socials = array();
$instagram = get_option('ticinoweb_contact_instagram');
if ($instagram) $socials['INSTAGRAM'] = $instagram;
$tiktok    = get_option('ticinoweb_contact_tiktok');
if ($tiktok) $socials['TIKTOK'] = $tiktok;
$facebook  = get_option('ticinoweb_contact_facebook');
if ($facebook) $socials['FACEBOOK'] = $facebook;
$youtube   = get_option('ticinoweb_contact_youtube');
if ($youtube) $socials['YOUTUBE'] = $youtube;
$linkedin  = get_option('ticinoweb_contact_linkedin');
if ($linkedin) $socials['LINKEDIN'] = $linkedin;
$x_twitter = get_option('ticinoweb_contact_x');
if ($x_twitter) $socials['X'] = $x_twitter;

$shop_url = class_exists('WooCommerce') && function_exists('wc_get_page_permalink') ? wc_get_page_permalink( 'shop' ) : home_url('/shop/');

// Setup immagini galleria
$hero_img = isset($gallery_images[0]) ? $gallery_images[0] : '';
$cta_img  = isset($gallery_images[1]) ? $gallery_images[1] : '';
?>

<main id="primary" class="site-main mv-contact-immersive-page">

    <!-- 1. EDITORIAL HERO -->
    <section class="mv-editorial-hero">
        <!-- Giant Background Text -->
        <div class="mv-hero-bg-outline" data-gsap="parallax" data-speed="0.2">CONTACT</div>
        
        <div class="monvel-container">
            <div class="mv-ed-hero-grid">
                
                <!-- Left: Text -->
                <div class="mv-ed-hero-content">
                    <span class="mv-ed-eyebrow" data-gsap="fade-up">MONVÉL CONTACT</span>
                    <h1 class="mv-ed-title" data-gsap="fade-up" data-delay="0.1">CONTATTI</h1>
                    <p class="mv-ed-subtitle" data-gsap="fade-up" data-delay="0.2">
                        Per ordini, prodotti, disponibilità o collaborazioni, scrivici attraverso i nostri canali ufficiali.
                    </p>
                    <div class="mv-hero-cta-wrapper" data-gsap="fade-up" data-delay="0.3">
                        <a href="#contact-directory" class="mv-btn mv-btn-primary">SCRIVICI</a>
                    </div>
                </div>

                <!-- Right: Visual -->
                <?php if ($hero_img): ?>
                <div class="mv-ed-hero-visual" data-gsap="fade-up" data-delay="0.2">
                    <div class="mv-ed-img-wrapper" data-gsap="parallax" data-speed="-0.1">
                        <img src="<?php echo esc_url($hero_img); ?>" alt="" class="mv-ed-cover-img" />
                    </div>
                </div>
                <?php endif; ?>
                
            </div>
        </div>
    </section>

    <!-- 2. MARQUEE STRIP -->
    <div class="mv-contact-marquee-strip">
        <div class="mv-marquee-track">
            <?php for($i=0; $i<4; $i++): ?>
                <span>MONVÉL CONTACT</span> <span class="dot">•</span>
                <span>DROP INFO</span> <span class="dot">•</span>
                <span>ORDERS</span> <span class="dot">•</span>
                <span>COLLABS</span> <span class="dot">•</span>
                <span>STREETWEAR ESSENTIALS</span> <span class="dot">•</span>
            <?php endfor; ?>
        </div>
    </div>

    <!-- 3. INTRO SENZA RUMORE -->
    <section class="mv-intro-noiseless monvel-container">
        <div class="mv-intro-inner" data-gsap="fade-up">
            <div class="mv-intro-line"></div>
            <span class="mv-intro-number">01</span>
            <h2 class="mv-intro-title">UN CANALE DIRETTO.<br>SENZA RUMORE.</h2>
            <p class="mv-intro-text">
                Per informazioni sui prodotti, ordini, disponibilità o collaborazioni, Monvél mantiene il contatto semplice: pochi canali, risposte chiare, identità diretta. Nessun form inutile.
            </p>
        </div>
    </section>

    <!-- 4. CONTACT DIRECTORY -->
    <section id="contact-directory" class="mv-directory-section monvel-container">
        <div class="mv-directory-grid">
            
            <!-- Context Left -->
            <div class="mv-dir-context" data-gsap="fade-up">
                <h3 class="mv-section-label">CONTATTO DIRETTO</h3>
                <p class="mv-dir-desc">Per modelli, colori, ordini o collaborazioni, usa i canali ufficiali Monvél.</p>
                <?php if($cta_img): ?>
                    <img src="<?php echo esc_url($cta_img); ?>" alt="" class="mv-dir-small-img" data-gsap="parallax" data-speed="0.05" />
                <?php endif; ?>
            </div>

            <!-- Directory Right -->
            <div class="mv-dir-list" data-gsap="fade-up" data-delay="0.2">
                
                <?php if (!empty($emails)): ?>
                <div class="mv-dir-item">
                    <span class="mv-dir-label">EMAIL</span>
                    <?php foreach($emails as $mail): ?>
                        <a href="mailto:<?php echo esc_attr($mail); ?>" class="mv-dir-value">
                            <?php echo esc_html($mail); ?>
                            <svg class="mv-dir-arrow" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
                        </a>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>

                <?php if (!empty($phones)): ?>
                <div class="mv-dir-item">
                    <span class="mv-dir-label">TELEFONO</span>
                    <?php foreach($phones as $tel): ?>
                        <a href="tel:<?php echo esc_attr(preg_replace('/[^0-9\+]/', '', $tel)); ?>" class="mv-dir-value">
                            <?php echo esc_html($tel); ?>
                            <svg class="mv-dir-arrow" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
                        </a>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>

                <?php if (!empty($address)): ?>
                <div class="mv-dir-item">
                    <span class="mv-dir-label">INDIRIZZO</span>
                    <div class="mv-dir-value mv-dir-address">
                        <?php echo nl2br(esc_html($address)); ?>
                    </div>
                </div>
                <?php endif; ?>

            </div>

        </div>
    </section>

    <!-- 5. MICRO-CARDS EDITORIALI -->
    <section class="mv-ed-microcards monvel-container">
        <div class="mv-ed-mc-grid">
            
            <div class="mv-ed-mc" data-gsap="fade-up" data-delay="0.1">
                <div class="mv-mc-bg-number">01</div>
                <h4 class="mv-mc-title">ORDINI</h4>
                <p class="mv-mc-desc">Acquisti, disponibilità e stato del tuo drop.</p>
                <div class="mv-mc-hover-line"></div>
            </div>

            <div class="mv-ed-mc" data-gsap="fade-up" data-delay="0.2">
                <div class="mv-mc-bg-number">02</div>
                <h4 class="mv-mc-title">PRODOTTI</h4>
                <p class="mv-mc-desc">Modelli, colori, vestibilità e dettagli Monvél.</p>
                <div class="mv-mc-hover-line"></div>
            </div>

            <div class="mv-ed-mc" data-gsap="fade-up" data-delay="0.3">
                <div class="mv-mc-bg-number">03</div>
                <h4 class="mv-mc-title">COLLAB</h4>
                <p class="mv-mc-desc">Progetti, partnership e richieste editoriali.</p>
                <div class="mv-mc-hover-line"></div>
            </div>

        </div>
    </section>

    <!-- 6. SOCIAL GIANTS -->
    <?php if (!empty($socials)): ?>
    <section class="mv-giant-socials monvel-container">
        <div class="mv-soc-header" data-gsap="fade-up">
            <h3 class="mv-section-label">SEGUI IL MONDO MONVÉL</h3>
            <p class="mv-soc-text">Drop, dettagli e nuove varianti passano anche da qui.</p>
        </div>
        <div class="mv-soc-links-container" data-gsap="fade-up" data-delay="0.1">
            <?php foreach($socials as $name => $link): ?>
                <a href="<?php echo esc_url($link); ?>" target="_blank" rel="noopener noreferrer" class="mv-soc-giant-link">
                    <span class="mv-soc-name"><?php echo esc_html($name); ?></span>
                    <svg class="mv-soc-arrow" width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M7 17L17 7M17 7H7M17 7V17"/></svg>
                </a>
            <?php endforeach; ?>
        </div>
    </section>
    <?php endif; ?>

    <!-- 7. IMMERSIVE CTA -->
    <section class="mv-immersive-cta">
        <div class="mv-cta-bg-text" data-gsap="parallax" data-speed="0.1">MONVÉL</div>
        
        <!-- Swatches in breathing animation -->
        <div class="mv-cta-swatches" aria-hidden="true">
            <div class="mv-cta-swatch sw-black"></div>
            <div class="mv-cta-swatch sw-beige"></div>
            <div class="mv-cta-swatch sw-grey"></div>
        </div>

        <div class="mv-cta-content" data-gsap="fade-up">
            <h2>HAI GIÀ SCELTO IL TUO FIT?</h2>
            <p>Curve o Snap, colore chiaro o deciso: trova il modello che completa il tuo stile.</p>
            <a href="<?php echo esc_url($shop_url); ?>" class="mv-btn mv-btn-primary">VAI ALLO SHOP</a>
        </div>
    </section>

</main>

<?php
get_footer();
