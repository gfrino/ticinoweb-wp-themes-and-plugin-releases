<?php
/**
 * The template for displaying the footer for Monvél Cappelli (Streetwear Edition)
 *
 * A premium, dark-themed closing brand section.
 */
?>
    <footer id="colophon" class="mv-footer-premium">
        
        <!-- Marquee Line -->
        <div class="mv-footer-marquee-wrapper">
            <div class="mv-footer-marquee">
                <div class="mv-marquee-content">
                    <span>MONVÉL</span>
                    <span class="mv-marquee-dot">•</span>
                    <span>STREETWEAR ESSENTIALS</span>
                    <span class="mv-marquee-dot">•</span>
                    <span>NEW DROPS</span>
                    <span class="mv-marquee-dot">•</span>
                    <span>CURVE</span>
                    <span class="mv-marquee-dot">•</span>
                    <span>SNAP</span>
                    <span class="mv-marquee-dot">•</span>
                    <span>MONVÉL</span>
                    <span class="mv-marquee-dot">•</span>
                    <span>STREETWEAR ESSENTIALS</span>
                    <span class="mv-marquee-dot">•</span>
                    <span>NEW DROPS</span>
                    <span class="mv-marquee-dot">•</span>
                    <span>CURVE</span>
                    <span class="mv-marquee-dot">•</span>
                    <span>SNAP</span>
                    <span class="mv-marquee-dot">•</span>
                </div>
                <!-- Duplicate for seamless loop -->
                <div class="mv-marquee-content" aria-hidden="true">
                    <span>MONVÉL</span>
                    <span class="mv-marquee-dot">•</span>
                    <span>STILE STREETWEAR</span>
                    <span class="mv-marquee-dot">•</span>
                    <span>NUOVI DROPS</span>
                    <span class="mv-marquee-dot">•</span>
                    <span>CURVE</span>
                    <span class="mv-marquee-dot">•</span>
                    <span>SNAP</span>
                    <span class="mv-marquee-dot">•</span>
                    <span>MONVÉL</span>
                    <span class="mv-marquee-dot">•</span>
                    <span>STILE STREETWEAR</span>
                    <span class="mv-marquee-dot">•</span>
                    <span>NUOVI DROPS</span>
                    <span class="mv-marquee-dot">•</span>
                    <span>CURVE</span>
                    <span class="mv-marquee-dot">•</span>
                    <span>SNAP</span>
                    <span class="mv-marquee-dot">•</span>
                </div>
            </div>
        </div>

        <!-- Giant Brand Claim -->
        <div class="mv-footer-claim-section">
            <div class="mv-footer-bg-text">MONVÉL</div>
            <h2 class="mv-footer-claim">MONVÉL SI SPOSTA CON TE</h2>
        </div>

        <div class="monvel-container">
            <div class="mv-footer-grid">
                
                <!-- Brand Info -->
                <div class="mv-footer-col brand-col">
                    <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="mv-footer-logo-link">
                        <?php echo esc_html( get_bloginfo( 'name' ) ); ?>
                    </a>
                    <p class="mv-footer-desc">
                        <?php 
                        $desc = get_bloginfo( 'description' );
                        if ( !empty($desc) ) {
                            echo esc_html( $desc );
                        } else {
                            echo "Cappelli essenziali, dettagli ricamati e identità streetwear contemporanea.";
                        }
                        ?>
                    </p>
                </div>

                <!-- Shop Menu -->
                <div class="mv-footer-col links-col">
                    <h3 class="mv-footer-col-title">SHOP</h3>
                    <?php 
                    if ( has_nav_menu( 'footer_shop' ) ) {
                        wp_nav_menu( array(
                            'theme_location' => 'footer_shop',
                            'container'      => false,
                            'menu_class'     => 'mv-footer-menu',
                            'depth'          => 1,
                        ) );
                    } else {
                        // Fallback Shop links
                        echo '<ul class="mv-footer-menu">';
                        if ( class_exists('WooCommerce') ) {
                            $shop_url = function_exists('wc_get_page_permalink') ? wc_get_page_permalink( 'shop' ) : '#';
                            $cart_url = function_exists('wc_get_page_permalink') ? wc_get_page_permalink( 'cart' ) : '#';
                            $account_url = function_exists('wc_get_page_permalink') ? wc_get_page_permalink( 'myaccount' ) : '#';
                            echo '<li><a href="'.esc_url($shop_url).'">Shop All</a></li>';
                            echo '<li><a href="'.esc_url($cart_url).'">Carrello</a></li>';
                            echo '<li><a href="'.esc_url($account_url).'">Il mio account</a></li>';
                        } else {
                            echo '<li><a href="'.esc_url(home_url('/shop/')).'">Shop</a></li>';
                            echo '<li><a href="'.esc_url(home_url('/collezione/')).'">Collezione</a></li>';
                        }
                        echo '</ul>';
                    }
                    ?>
                </div>

                <!-- Explore Menu -->
                <div class="mv-footer-col links-col">
                    <h3 class="mv-footer-col-title">ESPLORA</h3>
                    <?php 
                    if ( has_nav_menu( 'footer_primary' ) ) {
                        wp_nav_menu( array(
                            'theme_location' => 'footer_primary',
                            'container'      => false,
                            'menu_class'     => 'mv-footer-menu',
                            'depth'          => 1,
                        ) );
                    } else {
                        // Fallback Explore links
                        echo '<ul class="mv-footer-menu">';
                        echo '<li><a href="'.esc_url(home_url('/')).'">Home</a></li>';
                        echo '<li><a href="'.esc_url(home_url('/#brand')).'">Brand</a></li>';
                        echo '<li><a href="'.esc_url(home_url('/contatti/')).'">Contatti</a></li>';
                        echo '</ul>';
                    }
                    ?>
                </div>

                <!-- Custom CTA & Socials -->
                <div class="mv-footer-col newsletter-col">
                    <h3 class="mv-footer-col-title">ESPLORA MONVÉL</h3>
                    <p class="mv-newsletter-desc">Scopri i modelli, le varianti colore e il mondo streetwear essenziale di Monvél.</p>
                    
                    <ul class="mv-footer-menu mv-explore-ctas">
                        <?php 
                        $shop_url = class_exists('WooCommerce') && function_exists('wc_get_page_permalink') ? wc_get_page_permalink( 'shop' ) : home_url('/shop/');
                        $brand_url = home_url('/#brand'); // Fallback to anchor if no specific page exists
                        ?>
                        <li><a href="<?php echo esc_url($shop_url); ?>">Vai allo shop</a></li>
                        <li><a href="<?php echo esc_url($brand_url); ?>">Scopri il brand</a></li>
                    </ul>

                    <div class="mv-footer-socials" style="margin-top: 30px;">
                        <a href="#" aria-label="Instagram">Instagram</a>
                        <a href="#" aria-label="TikTok">TikTok</a>
                    </div>
                </div>

            </div>
            
            <!-- Bottom Legal Bar -->
            <div class="mv-footer-bottom">
                <div class="mv-footer-copyright">
                    &copy; <?php echo esc_html( date('Y') ); ?> <?php echo esc_html( get_bloginfo('name') ); ?>. Tutti i diritti riservati.
                </div>
                <div class="mv-footer-legal-links">
                    <?php 
                    if ( has_nav_menu( 'footer_legal' ) ) {
                        wp_nav_menu( array(
                            'theme_location' => 'footer_legal',
                            'container'      => false,
                            'menu_class'     => 'mv-legal-menu',
                            'depth'          => 1,
                        ) );
                    } else {
                        echo '<ul class="mv-legal-menu">';
                        $privacy_url = function_exists('get_privacy_policy_url') ? get_privacy_policy_url() : '';
                        if ( !empty($privacy_url) ) {
                            echo '<li><a href="'.esc_url($privacy_url).'">Privacy Policy</a></li>';
                        }
                        
                        $terms_url = '';
                        if ( function_exists('wc_get_page_id') ) {
                            $terms_page_id = wc_get_page_id('terms');
                            if ( $terms_page_id > 0 ) {
                                $terms_url = get_permalink($terms_page_id);
                            }
                        }
                        
                        if ( !empty($terms_url) ) {
                            echo '<li><a href="'.esc_url($terms_url).'">Termini e Condizioni</a></li>';
                        } else {
                            echo '<li><a href="' . esc_url(home_url('/termini-e-condizioni/')) . '">Termini e Condizioni</a></li>';
                        }
                        echo '</ul>';
                    }
                    ?>
                </div>
            </div>
        </div>
    </footer>

    <?php
    // Fetch WooCommerce products for CAP FIT
    $cap_fit_data = array(
        'clean' => array('url' => '', 'img' => '', 'name' => 'Curve'),
        'urban' => array('url' => '', 'img' => '', 'name' => 'Snap'),
    );

    if ( class_exists( 'WooCommerce' ) ) {
        $shop_url = function_exists('wc_get_page_permalink') ? wc_get_page_permalink('shop') : home_url('/shop/');
        
        // Initialize defaults
        $cap_fit_data['clean']['url'] = $shop_url;
        $cap_fit_data['urban']['url'] = $shop_url;

        // Fetch the first 2 available products dynamically to ensure images exist
        $args = array(
            'status' => 'publish',
            'limit' => 2,
        );
        $products = wc_get_products($args);

        if ( !empty($products) && isset($products[0]) ) {
            $p1 = $products[0];
            $cap_fit_data['clean']['url'] = $p1->get_permalink();
            $img_id = $p1->get_image_id();
            if ($img_id) {
                $cap_fit_data['clean']['img'] = wp_get_attachment_image_url($img_id, 'large');
            }
            // Use short name if possible
            $name = $p1->get_name();
            $cap_fit_data['clean']['name'] = str_replace('Monvél ', '', $name);
        }

        if ( !empty($products) && isset($products[1]) ) {
            $p2 = $products[1];
            $cap_fit_data['urban']['url'] = $p2->get_permalink();
            $img_id = $p2->get_image_id();
            if ($img_id) {
                $cap_fit_data['urban']['img'] = wp_get_attachment_image_url($img_id, 'large');
            }
            $name = $p2->get_name();
            $cap_fit_data['urban']['name'] = str_replace('Monvél ', '', $name);
        }
    }
    ?>

    <!-- LOGO DROP EASTER EGG PANEL -->
    <div class="mv-logo-drop-overlay" id="logoDropOverlay" aria-hidden="true" data-drop-data='<?php echo esc_attr(wp_json_encode($cap_fit_data)); ?>'>
        <div class="mv-logo-drop-panel" role="dialog" aria-modal="true" aria-labelledby="logoDropTitle">
            
            <button class="mv-logo-drop-close" aria-label="Chiudi Logo Drop" id="logoDropClose">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
                    <line x1="18" y1="6" x2="6" y2="18"></line>
                    <line x1="6" y1="6" x2="18" y2="18"></line>
                </svg>
            </button>

            <div class="mv-logo-drop-header">
                <h2 id="logoDropTitle">LOGO DROP</h2>
                <p>Il dettaglio Monvél si sblocca solo se lo cerchi.</p>
            </div>

            <!-- Interactive Canvas -->
            <div class="mv-logo-drop-canvas" id="logoDropCanvas">
                <div class="mv-logo-wrapper">
                    <!-- Progress Ring (Embroidery Hoop Style) -->
                    <svg class="mv-progress-ring" width="160" height="160" viewBox="0 0 160 160">
                        <circle class="mv-progress-ring-bg" cx="80" cy="80" r="76" stroke-width="1" fill="transparent" stroke="rgba(255,255,255,0.05)"></circle>
                        <circle class="mv-progress-ring-track" cx="80" cy="80" r="68" stroke-width="1" stroke-dasharray="2 6" fill="transparent" stroke="rgba(255,255,255,0.1)"></circle>
                        <circle class="mv-progress-ring-fill" cx="80" cy="80" r="76" stroke-width="3" fill="transparent" stroke="#ffffff" stroke-dasharray="478" stroke-dashoffset="478" stroke-linecap="round"></circle>
                    </svg>
                    
                    <!-- Main Logo (Premium Monogram Patch) -->
                    <div class="mv-interactive-logo" id="interactiveLogo">
                        <svg width="80" height="80" viewBox="0 0 60 60" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <!-- Thick underlying patch (perfectly centered) -->
                            <path d="M10 48L20 12L30 32L40 12L50 48" stroke="rgba(255,255,255,0.05)" stroke-width="8" stroke-linejoin="round" stroke-linecap="round"/>
                            <!-- Stitched thread -->
                            <path class="mv-stitch-path" d="M10 48L20 12L30 32L40 12L50 48" stroke="currentColor" stroke-width="2.5" stroke-linejoin="round" stroke-linecap="round"/>
                        </svg>
                    </div>
                </div>
                
                <div class="mv-hold-instruction" id="holdInstruction">
                    <span class="mv-instruction-text">Tieni premuta la M</span>
                    <span class="mv-loading-text" style="display: none;">Ricamo in corso<span class="mv-dots">...</span></span>
                </div>
            </div>

            <!-- Result Area (Hidden initially) -->
            <div class="mv-logo-drop-result" id="logoDropResult" style="display: none;">
                <div class="mv-result-eyebrow">DROP SBLOCCATO <span class="mv-check-icon">✓</span></div>
                <h3 class="mv-result-title">Hai trovato il dettaglio nascosto Monvél.</h3>
                
                <!-- Product Previews -->
                <div class="mv-drop-products">
                    <div class="mv-drop-product-card">
                        <div class="mv-card-image-wrapper">
                            <?php if (!empty($cap_fit_data['clean']['img'])) : ?>
                                <img src="<?php echo esc_url($cap_fit_data['clean']['img']); ?>" alt="<?php echo esc_attr($cap_fit_data['clean']['name']); ?>" />
                            <?php endif; ?>
                            <div class="mv-pedestal"></div>
                        </div>
                        <span class="mv-product-name"><?php echo esc_html($cap_fit_data['clean']['name']); ?></span>
                    </div>
                    <div class="mv-drop-product-card">
                        <div class="mv-card-image-wrapper">
                            <?php if (!empty($cap_fit_data['urban']['img'])) : ?>
                                <img src="<?php echo esc_url($cap_fit_data['urban']['img']); ?>" alt="<?php echo esc_attr($cap_fit_data['urban']['name']); ?>" />
                            <?php endif; ?>
                            <div class="mv-pedestal"></div>
                        </div>
                        <span class="mv-product-name"><?php echo esc_html($cap_fit_data['urban']['name']); ?></span>
                    </div>
                </div>

                <div class="mv-reward-label">Dettaglio sbloccato: Ricamo Monvél</div>
                
                <a href="<?php echo class_exists('WooCommerce') && function_exists('wc_get_page_permalink') ? esc_url(wc_get_page_permalink('shop')) : home_url('/shop/'); ?>" class="mv-drop-cta" id="logoDropCta">Entra nel Drop</a>
            </div>

        </div>
    </div>

    <?php wp_footer(); ?>
</body>
</html>
