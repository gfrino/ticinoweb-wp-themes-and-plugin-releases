jQuery(function($) {
    'use strict';

    // Funzione per aggiornare l'input nascosto con gli ID
    function updateGalleryIds(wrapper) {
        var ids = [];
        wrapper.find('.monvel-variation-gallery-list li.image').each(function() {
            ids.push($(this).data('attachment_id'));
        });
        wrapper.find('.monvel-variation-gallery-ids').val(ids.join(',')).trigger('change');
    }

    // Inizializza Sortable su ogni contenitore (anche in variazioni caricate via Ajax)
    function initSortable() {
        $('.monvel-variation-gallery-list').not('.ui-sortable').sortable({
            items: 'li.image',
            cursor: 'move',
            scrollSensitivity: 40,
            forcePlaceholderSize: true,
            forceHelperSize: false,
            helper: 'clone',
            opacity: 0.65,
            placeholder: 'ui-sortable-placeholder',
            start: function(event, ui) {
                ui.item.css('background-color', '#f6f6f6');
            },
            stop: function(event, ui) {
                ui.item.removeAttr('style');
            },
            update: function(event, ui) {
                var wrapper = $(this).closest('.monvel-variation-gallery-wrapper');
                updateGalleryIds(wrapper);
            }
        });
    }

    // Init onload
    initSortable();

    // Re-init quando WooCommerce carica il form variazioni
    $('#woocommerce-product-data').on('woocommerce_variations_loaded', function() {
        initSortable();
    });
    
    // WooCommerce ricarica una variazione specifica dopo salvataggio/aggiornamento
    $(document).ajaxComplete(function(event, xhr, settings) {
        if (settings.data && typeof settings.data === 'string' && settings.data.indexOf('action=woocommerce_load_variations') !== -1) {
            initSortable();
        }
    });

    // Aggiungi immagini (apre media uploader)
    $(document).on('click', '.add-monvel-variation-gallery-image a', function(e) {
        e.preventDefault();
        
        var $el = $(this);
        var wrapper = $el.closest('.monvel-variation-gallery-wrapper');
        var list = wrapper.find('.monvel-variation-gallery-list');
        var input = wrapper.find('.monvel-variation-gallery-ids');

        // Crea o riusa l'istanza wp.media
        var file_frame = wp.media.frames.file_frame = wp.media({
            title: 'Scegli Immagini per Galleria Variazione',
            button: {
                text: 'Aggiungi alla galleria'
            },
            multiple: true
        });

        file_frame.on('select', function() {
            var attachments = file_frame.state().get('selection').toJSON();

            $.each(attachments, function(index, attachment) {
                // Prendi thumbnail se disponibile, altrimenti full
                var img_url = attachment.sizes && attachment.sizes.thumbnail ? attachment.sizes.thumbnail.url : attachment.url;
                
                var html = '<li class="image" data-attachment_id="' + attachment.id + '">' +
                           '<img src="' + img_url + '" alt="" />' +
                           '<a href="#" class="delete" title="Rimuovi immagine">&times;</a>' +
                           '</li>';
                list.append(html);
            });

            updateGalleryIds(wrapper);
            initSortable(); // Ri-applica se necessario
            
            // Trigger change per attivare il pulsante "Salva modifiche" di WooCommerce
            $('.woocommerce_variations input[name^="variable_sku"]').first().trigger('change');
        });

        file_frame.open();
    });

    // Rimuovi immagine
    $(document).on('click', '.monvel-variation-gallery-list a.delete', function(e) {
        e.preventDefault();
        var $el = $(this);
        var wrapper = $el.closest('.monvel-variation-gallery-wrapper');
        
        $el.closest('li.image').remove();
        updateGalleryIds(wrapper);
        
        // Trigger change
        $('.woocommerce_variations input[name^="variable_sku"]').first().trigger('change');
    });

});
