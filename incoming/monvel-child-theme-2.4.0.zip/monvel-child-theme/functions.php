<?php
/**
 * Monvél Cappelli Child Theme functions and definitions
 */

// 1. Enqueue Styles and Scripts
function monvel_child_enqueue_styles() {
    $parent_style = 'ticinoweb-ai-theme-style';

    // Parent Style
    wp_enqueue_style( $parent_style, get_template_directory_uri() . '/style.css' );
    
    // Child Style
    wp_enqueue_style( 'monvel-child-style',
        get_stylesheet_directory_uri() . '/style.css',
        array( $parent_style ),
        wp_get_theme()->get( 'Version' )
    );

    // Swiper.js (CSS & JS)
    wp_enqueue_style('swiper-css', 'https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css', array(), null);
    wp_enqueue_script('swiper-js', 'https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js', array(), null, true);

    // Custom GSAP for Animations (CDN)
    wp_enqueue_script('gsap', 'https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/gsap.min.js', array(), null, true);
    wp_enqueue_script('gsap-scrolltrigger', 'https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/ScrollTrigger.min.js', array('gsap'), null, true);

    // Custom Animations JS
    wp_enqueue_script('monvel-animations', 
        get_stylesheet_directory_uri() . '/assets/js/monvel-animations.js', 
        array('gsap', 'gsap-scrolltrigger', 'swiper-js'), 
        wp_get_theme()->get( 'Version' ),
        true
    );
}
add_action( 'wp_enqueue_scripts', 'monvel_child_enqueue_styles', 99 );

require_once get_stylesheet_directory() . '/inc/home-color-cards.php';
require_once get_stylesheet_directory() . '/inc/home-preloader.php';
add_action( 'after_setup_theme', function () {
    load_child_theme_textdomain( 'monvel-child-theme', get_stylesheet_directory() . '/languages' );
} );
add_action( 'wp_enqueue_scripts', function () {
    if ( ! is_front_page() ) {
        return;
    }
    $version = wp_get_theme()->get( 'Version' );
    wp_enqueue_style( 'monvel-home-colors', get_stylesheet_directory_uri() . '/assets/css/home-color-cards.css', array( 'monvel-child-style' ), $version );
    wp_enqueue_script( 'monvel-home-colors', get_stylesheet_directory_uri() . '/assets/js/home-color-cards.js', array(), $version, true );
}, 100 );

// 2. Add Theme Supports
function monvel_theme_setup() {
    // WooCommerce Support
    add_theme_support( 'woocommerce', array(
        'thumbnail_image_width' => 800,
        'single_image_width'    => 1200,
        'product_grid'          => array(
            'default_rows'    => 3,
            'min_rows'        => 2,
            'max_rows'        => 8,
            'default_columns' => 3,
            'min_columns'     => 1,
            'max_columns'     => 4,
        ),
    ) );
    add_theme_support( 'wc-product-gallery-zoom' );
    add_theme_support( 'wc-product-gallery-lightbox' );
    add_theme_support( 'wc-product-gallery-slider' );

    // Register Footer Menus
    register_nav_menus( array(
        'primary'        => esc_html__( 'Primary Menu', 'monvel' ),
        'footer_primary' => esc_html__( 'Footer Primary', 'monvel' ),
        'footer_shop'    => esc_html__( 'Footer Shop', 'monvel' ),
        'footer_legal'   => esc_html__( 'Footer Legal', 'monvel' ),
    ) );
}
add_action( 'after_setup_theme', 'monvel_theme_setup' );

// 3. Remove WooCommerce default wrappers to avoid layout breaks (if needed)
remove_action( 'woocommerce_before_main_content', 'woocommerce_output_content_wrapper', 10);
remove_action( 'woocommerce_after_main_content', 'woocommerce_output_content_wrapper_end', 10);

add_action('woocommerce_before_main_content', 'monvel_wrapper_start', 10);
add_action('woocommerce_after_main_content', 'monvel_wrapper_end', 10);

function monvel_wrapper_start() {
    echo '<main id="primary" class="site-main monvel-wc-main"><div class="monvel-container">';
}
function monvel_wrapper_end() {
    echo '</div></main>';
}

// 4. Shop Archive Cleanups
remove_action( 'woocommerce_before_shop_loop', 'woocommerce_result_count', 20 );
remove_action( 'woocommerce_before_shop_loop', 'woocommerce_catalog_ordering', 30 );
remove_action( 'woocommerce_before_main_content', 'woocommerce_breadcrumb', 20, 0 );

// 5. AJAX Cart Fragments for Dynamic Badge
add_filter( 'woocommerce_add_to_cart_fragments', 'monvel_cart_count_fragments', 10, 1 );
function monvel_cart_count_fragments( $fragments ) {
    if ( ! class_exists( 'WooCommerce' ) ) return $fragments;
    
    ob_start();
    ?>
    <span class="mv-cart-count"><?php echo esc_html( WC()->cart->get_cart_contents_count() ); ?></span>
    <?php
    $fragments['span.mv-cart-count'] = ob_get_clean();
    
    return $fragments;
}


// Remove default WooCommerce sidebar
remove_action( 'woocommerce_sidebar', 'woocommerce_get_sidebar', 10 );



// Monvél Variation Image Gallery
require_once get_stylesheet_directory() . '/inc/class-monvel-variation-gallery.php';



// Monvél Colors Logic (Dual Color Swatches)
require_once get_stylesheet_directory() . '/inc/class-monvel-colors.php';

// Monvél Product Addons
require_once get_stylesheet_directory() . '/inc/class-monvel-product-addons.php';

// Force shop to sort by ID DESC to enforce Monvél Snap (32) first, then Curve (14)
add_filter( 'woocommerce_get_catalog_ordering_args', 'monvel_custom_shop_ordering' );
function monvel_custom_shop_ordering( $args ) {
    $args['orderby'] = 'ID';
    $args['order'] = 'DESC';
    return $args;
}

// -----------------------------------------------------------------------------
// GLOBAL TEXT REPLACEMENT: Monvèl -> Monvél (Fixing Database strings)
// -----------------------------------------------------------------------------
function monvel_global_text_replacement($text) {
    if (is_string($text)) {
        $text = str_replace(
            ['Monvèl', 'MONVÈL', 'monvèl', 'Monv&egrave;l', 'MONV&Egrave;L'], 
            ['Monvél', 'MONVÉL', 'monvél', 'Monv&eacute;l', 'MONV&Eacute;L'], 
            $text
        );
    }
    return $text;
}

// Titles
add_filter('the_title', 'monvel_global_text_replacement', 999);
add_filter('single_post_title', 'monvel_global_text_replacement', 999);
add_filter('wp_title', 'monvel_global_text_replacement', 999);
add_filter('document_title_parts', function($title_parts) {
    if (is_array($title_parts)) {
        foreach ($title_parts as &$part) {
            $part = monvel_global_text_replacement($part);
        }
    }
    return $title_parts;
}, 999);

// Content
add_filter('the_content', 'monvel_global_text_replacement', 999);
add_filter('the_excerpt', 'monvel_global_text_replacement', 999);

// WooCommerce
add_filter('woocommerce_product_get_name', 'monvel_global_text_replacement', 999);
add_filter('woocommerce_product_title', 'monvel_global_text_replacement', 999);
add_filter('woocommerce_cart_item_name', 'monvel_global_text_replacement', 999);

// Options (Site Title)
add_filter('option_blogname', 'monvel_global_text_replacement', 999);
add_filter('option_blogdescription', 'monvel_global_text_replacement', 999);

// Menus
add_filter('nav_menu_item_title', 'monvel_global_text_replacement', 999);
add_filter('widget_title', 'monvel_global_text_replacement', 999);
add_filter('widget_text', 'monvel_global_text_replacement', 999);

