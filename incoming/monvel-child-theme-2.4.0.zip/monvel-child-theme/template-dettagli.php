<?php
/**
 * Template Name: Dettagli
 * Description: Pagina immersiva e product story per i cappelli Monvél.
 */

get_header();

// ==========================================
// 1. ROUTING E SWITCHER MODELLO
// ==========================================
$page_slug = get_post_field( 'post_name', get_post() );
$requested_model = isset($_GET['model']) ? sanitize_text_field($_GET['model']) : '';

// Determina il modello corrente (il parametro URL ha la priorità)
$active_model = 'snap'; // fallback

if ( $requested_model === 'curve' ) {
    $active_model = 'curve';
} elseif ( $requested_model === 'snap' ) {
    $active_model = 'snap';
} else {
    // Se non c'è parametro, controlliamo lo slug della pagina
    if ( strpos($page_slug, 'curve') !== false ) {
        $active_model = 'curve';
    } elseif ( strpos($page_slug, 'snap') !== false ) {
        $active_model = 'snap';
    }
}

// ==========================================
// 2. CONFIGURAZIONE HOTSPOT (COORDINATE)
// ==========================================
$config_hotspots_snap = array(
    'ricamo' => array(
        'anchor_top'  => '42%',
        'anchor_left' => '50%',
        'svg_path'    => 'M0,0 L40,-40 L110,-40',
        'label_bottom'=> '24px', 
        'label_left'  => '120px', 
        'label_text'  => 'M RICAMATA'
    ),
    'visiera' => array(
        'anchor_bottom' => '28%',
        'anchor_left'   => '30%', 
        'svg_path'      => 'M0,0 L40,40 L110,40',
        'label_top'     => '24px',  
        'label_left'    => '120px', 
        'label_text'    => 'PROFILO PIATTO'
    ),
    'chiusura_snap' => array(
        'anchor_bottom' => '24%',
        'anchor_left'   => '50%',
        'svg_path'      => 'M0,0 L-30,50 L-110,50',
        'label_top'     => '34px',  
        'label_right'   => '120px', 
        'label_text'    => 'CHIUSURA SNAPBACK'
    ),
    'chiusura_logo' => array(
        'anchor_top'  => '47%',
        'anchor_left' => '50%',
        'svg_path'    => 'M0,0 L50,-80 L110,-80',
        'label_bottom'=> '64px', 
        'label_left'  => '120px', 
        'label_text'  => 'LOGO POSTERIORE'
    )
);

$config_hotspots_curve = array(
    'ricamo' => array(
        'anchor_top'  => '42%',
        'anchor_left' => '50%',
        'svg_path'    => 'M0,0 L40,-40 L110,-40',
        'label_bottom'=> '24px', 
        'label_left'  => '120px', 
        'label_text'  => 'RICAMO FRONTALE'
    ),
    'visiera' => array(
        'anchor_bottom' => '32%',
        'anchor_left'   => '30%', 
        'svg_path'      => 'M0,0 L40,40 L110,40',
        'label_top'     => '24px',  
        'label_left'    => '120px', 
        'label_text'    => 'VISIERA CURVA'
    ),
    'chiusura_snap' => array( 
        'anchor_bottom' => '20%',
        'anchor_left'   => '50%',
        'svg_path'      => 'M0,0 L-30,50 L-110,50',
        'label_top'     => '34px',  
        'label_right'   => '120px', 
        'label_text'    => 'CINTURINO REGOLABILE'
    ),
    'chiusura_logo' => array( 
        'anchor_top'  => '52%',
        'anchor_left' => '50%',
        'svg_path'    => 'M0,0 L50,-80 L110,-80',
        'label_bottom'=> '64px', 
        'label_left'  => '120px', 
        'label_text'  => 'LOGO POSTERIORE'
    )
);

$config_hotspots = ($active_model === 'curve') ? $config_hotspots_curve : $config_hotspots_snap;

// ==========================================
// 3. VARIABILI TESTUALI DINAMICHE
// ==========================================
$hero_title    = get_option('ticinoweb_dettagli_title', 'DETTAGLI');
$hero_subtitle = get_option('ticinoweb_dettagli_subtitle', 'Ogni linea, ogni ricamo, ogni colore nasce per completare il look.');
$eyebrow       = 'MONVÉL DETAILS';

if ($active_model === 'curve') {
    // TEXT: CURVE
    $mod_name        = 'MONVÉL CURVE';
    $mod_intro       = 'Linee pulite, visiera curva e una presenza quotidiana pensata per completare ogni look.';
    
    $s1_title = 'LOGO FRONTALE RICAMATO';
    $s1_desc  = 'Il logo Monvél prende forma sul frontale con un ricamo pulito, essenziale e riconoscibile.';
    
    $s2_title = 'FORMA PULITA';
    $s2_desc  = 'Una struttura più morbida e versatile, pensata per un fit quotidiano e naturale.';
    
    $s3_title = 'VISIERA CURVA';
    $s3_desc  = 'La visiera curva accompagna il profilo del cappello con una linea più fluida e immediata.';
    
    $s4_title = 'CHIUSURA REGOLABILE';
    $s4_desc  = 'Il cinturino regolabile rende il fit pratico, comodo e adattabile all’uso di ogni giorno.';
    
    $s5_title = 'TEXTURE ESSENZIALE';
    $s5_desc  = 'Una superficie pulita che valorizza colore, ricamo e forma senza bisogno di eccessi.';
    
    $cta_title = 'SCEGLI IL DETTAGLIO CHE COMPLETA IL LOOK';
    $cta_desc  = 'Monvél Curve unisce linee pulite, visiera curva e identità Monvél in un cappello quotidiano.';
    $cta_btn   = 'SCOPRI MONVÉL CURVE';
    
    $gallery_search_term = 'CURVE';
    $product_search_title = 'Monvél Curve';
} else {
    // TEXT: SNAP
    $mod_name        = 'MONVÉL SNAP';
    $mod_intro       = 'Forma decisa, ricamo frontale e presenza streetwear immediata.';
    
    $s1_title = 'LOGO FRONTALE RICAMATO';
    $s1_desc  = 'Un segno netto, riconoscibile, pensato per restare.';
    
    $s2_title = 'FORMA DECISA';
    $s2_desc  = 'Una silhouette più strutturata, pensata per dare carattere al look.';
    
    $s3_title = 'VISIERA E PROFILO';
    $s3_desc  = 'La visiera piatta definisce l’attitudine del modello e dà al cappello una geometria urbana pura.';
    
    $s4_title = 'CHIUSURA REGOLABILE';
    $s4_desc  = 'Un fit pratico e versatile, pensato per accompagnare l’uso quotidiano.';
    
    $s5_title = 'TEXTURE PULITA';
    $s5_desc  = 'Una superficie essenziale che lascia spazio a forma, colore e ricamo.';
    
    $cta_title = 'SCEGLI IL DETTAGLIO CHE COMPLETA IL LOOK';
    $cta_desc  = 'Monvél Snap porta forma, ricamo e identità in un unico cappello.';
    $cta_btn   = 'SCOPRI MONVÉL SNAP';
    
    $gallery_search_term = 'Snap';
    $product_search_title = 'Monvél Snap';
}

$config_immagini = array(
    'intro'   => 0,
    'logo'    => 1,
    'forma'   => 2,
    'visiera' => 3,
    'retro'   => 4,
    'texture' => 5
);

// ==========================================
// 4. FETCH MEDIA GALLERY
// ==========================================
$gallery_images = array();
$target_gallery_id = 0;

$terms = get_terms(array(
    'taxonomy'   => 'ticinoweb_media_gallery',
    'hide_empty' => false,
    'search'     => $gallery_search_term
));

if (!empty($terms) && !is_wp_error($terms)) {
    $target_gallery_id = $terms[0]->term_id;
}

if ($target_gallery_id) {
    $images = new WP_Query(array(
        'post_type'      => 'attachment',
        'post_status'    => 'inherit',
        'posts_per_page' => 500,
        'tax_query' => array(
            array(
                'taxonomy' => 'ticinoweb_media_gallery',
                'field'    => 'term_id',
                'terms'    => $target_gallery_id,
            )
        )
    ));

    $saved_order = get_term_meta($target_gallery_id, '_ticinoweb_gallery_order', true);
    if (!is_array($saved_order)) $saved_order = array();

    if (!empty($saved_order) && $images->have_posts()) {
        usort($images->posts, function ($a, $b) use ($saved_order) {
            $posA = array_search($a->ID, $saved_order);
            $posB = array_search($b->ID, $saved_order);
            if ($posA === false) $posA = 999999;
            if ($posB === false) $posB = 999999;
            return $posA - $posB;
        });
    }

    if ($images->have_posts()) {
        foreach ($images->posts as $attachment) {
            $gallery_images[] = wp_get_attachment_image_url($attachment->ID, 'full');
        }
    }
}

$placeholders = array(
    'https://images.unsplash.com/photo-1556228578-0d85b1a4d571?q=80&w=1200&auto=format&fit=crop',
    'https://images.unsplash.com/photo-1512413914565-eb7df1264c84?q=80&w=1200&auto=format&fit=crop',
    'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?q=80&w=1200&auto=format&fit=crop',
    'https://images.unsplash.com/photo-1520975954732-35dd5dd29c5e?q=80&w=1200&auto=format&fit=crop',
    'https://images.unsplash.com/photo-1558507652-2d9626c4e67a?q=80&w=1200&auto=format&fit=crop',
    'https://images.unsplash.com/photo-1533827432537-70133748f5c8?q=80&w=1200&auto=format&fit=crop'
);

while(count($gallery_images) < 6) {
    $gallery_images[] = $placeholders[count($gallery_images) % count($placeholders)];
}

$img_intro   = $gallery_images[$config_immagini['intro']]; 
$img_logo    = $gallery_images[$config_immagini['logo']]; 
$img_forma   = $gallery_images[$config_immagini['forma']]; 
$img_visiera = $gallery_images[$config_immagini['visiera']]; 
$img_retro   = $gallery_images[$config_immagini['retro']]; 
$img_texture = $gallery_images[$config_immagini['texture']]; 

// ==========================================
// 5. WOOCOMMERCE PRODUCT DATA
// ==========================================
$dynamic_attributes = array();
$dynamic_product = get_page_by_title($product_search_title, OBJECT, 'product');

if (!$dynamic_product && $active_model === 'snap') {
    $dynamic_product = get_page_by_title('Snap', OBJECT, 'product');
}

if ($dynamic_product && function_exists('wc_get_product')) {
    $product = wc_get_product($dynamic_product->ID);
    if ($product) {
        $attributes = $product->get_attributes();
        foreach ($attributes as $attr) {
            $name = wc_attribute_label($attr->get_name());
            $options = $attr->get_options();
            if(!empty($options)) {
                if ($attr->get_name() === 'pa_colore' && $product->is_type('variable')) {
                    $ordered_colors = array();
                    $variation_ids = $product->get_children();
                    foreach ($variation_ids as $vid) {
                        $v = wc_get_product($vid);
                        if ($v && $v->get_status() === 'publish') {
                            $c = $v->get_attribute('pa_colore');
                            if ($c && !in_array($c, $ordered_colors)) {
                                $ordered_colors[] = $c;
                            }
                        }
                    }
                    $val = implode(', ', $ordered_colors);
                } elseif ($attr->is_taxonomy()) {
                    $terms = wc_get_product_terms($product->get_id(), $attr->get_name(), array('fields' => 'names'));
                    $val = implode(', ', $terms);
                } else {
                    $val = implode(', ', $options);
                }
                
                if($val) {
                    $dynamic_attributes[$name] = $val;
                }
            }
        }
    }
} else {
    // Fallback in caso di assenza
    $dynamic_attributes = array(
        'Modello' => $product_search_title,
        'Stile' => 'Streetwear'
    );
}

$shop_url = function_exists('wc_get_page_permalink') ? wc_get_page_permalink('shop') : home_url('/shop/');
$cta_url = $dynamic_product ? get_permalink($dynamic_product->ID) : $shop_url;

$current_url = get_permalink();
$snap_switch_url = add_query_arg('model', 'snap', $current_url);
$curve_switch_url = add_query_arg('model', 'curve', $current_url);
?>

<main id="primary" class="site-main mv-det-page">

    <!-- 1. HERO CON SWITCHER -->
    <div class="mv-shop-hero">
        <div class="mv-shop-hero-bg-text">MONVÉL</div>
        <span class="mv-shop-eyebrow"><?php echo esc_html($eyebrow); ?></span>
        <h1 class="mv-shop-title"><?php echo wp_kses_post($hero_title); ?></h1>
        <p class="mv-shop-subtitle"><?php echo wp_kses_post($hero_subtitle); ?></p>
        
        <div class="mv-model-switcher fade-up-el" style="margin-top: 30px; display: inline-flex; background: #f0f0f0; border-radius: 40px; padding: 5px;">
            <a href="<?php echo esc_url($snap_switch_url); ?>" class="mv-switcher-btn <?php echo ($active_model === 'snap') ? 'active' : ''; ?>" style="padding: 10px 24px; border-radius: 30px; font-weight: 700; font-size: 0.8rem; text-decoration: none; color: <?php echo ($active_model === 'snap') ? '#fff' : '#666'; ?>; background: <?php echo ($active_model === 'snap') ? '#000' : 'transparent'; ?>; transition: all 0.3s ease;">SNAP</a>
            <a href="<?php echo esc_url($curve_switch_url); ?>" class="mv-switcher-btn <?php echo ($active_model === 'curve') ? 'active' : ''; ?>" style="padding: 10px 24px; border-radius: 30px; font-weight: 700; font-size: 0.8rem; text-decoration: none; color: <?php echo ($active_model === 'curve') ? '#fff' : '#666'; ?>; background: <?php echo ($active_model === 'curve') ? '#000' : 'transparent'; ?>; transition: all 0.3s ease;">CURVE</a>
        </div>
    </div>

    <!-- 2. INTRO CINEMATIC -->
    <section class="mv-det-cinematic monvel-container">
        <div class="mv-det-cinematic-bg-text"><?php echo esc_html(strtoupper($active_model)); ?></div>
        <div class="mv-det-cinematic-visual fade-up-el">
            <div class="mv-det-cinematic-glow"></div>
            <img src="<?php echo esc_url($img_intro); ?>" alt="<?php echo esc_attr($mod_name); ?>" class="mv-det-cinematic-img mv-breathing-img">
            <div class="mv-det-cinematic-shadow"></div>
        </div>
        <div class="mv-det-cinematic-content">
            <h2 class="fade-up-el"><?php echo esc_html($mod_name); ?></h2>
            <p class="fade-up-el"><?php echo esc_html($mod_intro); ?></p>
        </div>
    </section>

    <!-- 3. STICKY DETAIL JOURNEY (5 Steps) -->
    <section class="mv-journey-wrapper desktop-only" id="sticky-journey">
        <div class="mv-journey-inner">
            
            <!-- Sidebar Progress -->
            <div class="mv-journey-progress">
                <span class="mv-jp-num" id="jp-num">01 / 05</span>
                <div class="mv-jp-line-wrap">
                    <div class="mv-jp-line-fill" id="jp-fill"></div>
                </div>
                <ul class="mv-jp-list">
                    <li class="jp-item active" data-step="0">RICAMO</li>
                    <li class="jp-item" data-step="1">FORMA</li>
                    <li class="jp-item" data-step="2">VISIERA</li>
                    <li class="jp-item" data-step="3">CHIUSURA</li>
                    <li class="jp-item" data-step="4">TEXTURE</li>
                </ul>
            </div>

            <div class="monvel-container mv-journey-grid">
                <!-- A: Visuals -->
                <div class="mv-journey-visuals">
                    
                    <!-- Step 1: Ricamo -->
                    <div class="mv-step-visual active" data-step="0">
                        <div class="mv-breathing-img">
                            <img src="<?php echo esc_url($img_logo); ?>" alt="<?php echo esc_attr($s1_title); ?>" class="mv-step-img mv-lerp-scale">
                            <div class="mv-light-sweep"></div>
                        </div>
                        <?php $h = $config_hotspots['ricamo']; ?>
                        <div class="mv-hotspot-container" style="top: <?php echo esc_attr($h['anchor_top']); ?>; left: <?php echo esc_attr($h['anchor_left']); ?>;">
                            <div class="mv-callout-dot">
                                <div class="mv-callout-dot-core"></div>
                                <div class="mv-callout-dot-ring"></div>
                            </div>
                            <svg class="mv-callout-line" style="position: absolute; overflow: visible;">
                                <path d="<?php echo esc_attr($h['svg_path']); ?>" fill="none" stroke="#dc2626" stroke-width="2" />
                            </svg>
                            <span class="mv-callout-label" style="bottom: <?php echo esc_attr($h['label_bottom']); ?>; left: <?php echo esc_attr($h['label_left']); ?>;">
                                <?php echo esc_html($h['label_text']); ?>
                            </span>
                        </div>
                    </div>

                    <!-- Step 2: Forma -->
                    <div class="mv-step-visual" data-step="1">
                        <svg class="mv-forma-bg" viewBox="0 0 400 300" preserveAspectRatio="xMidYMid meet">
                            <path class="mv-forma-path" d="M 50 250 C 50 150, 100 50, 200 50 C 300 50, 350 150, 350 250 Z" fill="none" stroke="rgba(0,0,0,0.05)" stroke-width="4" />
                        </svg>
                        <div class="mv-breathing-img">
                            <img src="<?php echo esc_url($img_forma); ?>" alt="<?php echo esc_attr($s2_title); ?>" class="mv-step-img mv-lerp-scale">
                        </div>
                    </div>

                    <!-- Step 3: Visiera -->
                    <div class="mv-step-visual" data-step="2">
                        <div class="mv-breathing-img">
                            <img src="<?php echo esc_url($img_visiera); ?>" alt="<?php echo esc_attr($s3_title); ?>" class="mv-step-img mv-lerp-scale">
                        </div>
                        <?php $h = $config_hotspots['visiera']; ?>
                        <div class="mv-hotspot-container" style="bottom: <?php echo esc_attr($h['anchor_bottom']); ?>; left: <?php echo esc_attr($h['anchor_left']); ?>;">
                            <div class="mv-callout-dot">
                                <div class="mv-callout-dot-core"></div>
                                <div class="mv-callout-dot-ring"></div>
                            </div>
                            <svg class="mv-callout-line" style="position: absolute; overflow: visible;">
                                <path d="<?php echo esc_attr($h['svg_path']); ?>" fill="none" stroke="#dc2626" stroke-width="2"/>
                            </svg>
                            <span class="mv-callout-label" style="top: <?php echo esc_attr($h['label_top']); ?>; left: <?php echo esc_attr($h['label_left']); ?>;">
                                <?php echo esc_html($h['label_text']); ?>
                            </span>
                        </div>
                    </div>

                    <!-- Step 4: Chiusura -->
                    <div class="mv-step-visual" data-step="3">
                        <div class="mv-breathing-img">
                            <img src="<?php echo esc_url($img_retro); ?>" alt="<?php echo esc_attr($s4_title); ?>" class="mv-step-img mv-lerp-scale">
                        </div>
                        <!-- Hotspot Logo Retro -->
                        <?php $h = $config_hotspots['chiusura_logo']; ?>
                        <div class="mv-hotspot-container" style="top: <?php echo esc_attr($h['anchor_top']); ?>; left: <?php echo esc_attr($h['anchor_left']); ?>;">
                            <div class="mv-callout-dot"><div class="mv-callout-dot-core"></div><div class="mv-callout-dot-ring"></div></div>
                            <svg class="mv-callout-line" style="position: absolute; overflow: visible;">
                                <path d="<?php echo esc_attr($h['svg_path']); ?>" fill="none" stroke="#dc2626" stroke-width="2"/>
                            </svg>
                            <span class="mv-callout-label" style="bottom: <?php echo esc_attr($h['label_bottom']); ?>; left: <?php echo esc_attr($h['label_left']); ?>;">
                                <?php echo esc_html($h['label_text']); ?>
                            </span>
                        </div>
                        <!-- Hotspot Chiusura -->
                        <?php $h = $config_hotspots['chiusura_snap']; ?>
                        <div class="mv-hotspot-container" style="bottom: <?php echo esc_attr($h['anchor_bottom']); ?>; left: <?php echo esc_attr($h['anchor_left']); ?>;">
                            <div class="mv-callout-dot"><div class="mv-callout-dot-core"></div><div class="mv-callout-dot-ring"></div></div>
                            <svg class="mv-callout-line" style="position: absolute; overflow: visible;">
                                <path d="<?php echo esc_attr($h['svg_path']); ?>" fill="none" stroke="#dc2626" stroke-width="2"/>
                            </svg>
                            <span class="mv-callout-label" style="top: <?php echo esc_attr($h['label_top']); ?>; right: <?php echo esc_attr($h['label_right']); ?>;">
                                <?php echo esc_html($h['label_text']); ?>
                            </span>
                        </div>
                    </div>

                    <!-- Step 5: Texture -->
                    <div class="mv-step-visual" data-step="4">
                        <div class="mv-texture-lense-container">
                            <div class="mv-texture-bg" style="background-image: url('<?php echo esc_url($img_texture); ?>');"></div>
                        </div>
                    </div>

                </div>

                <!-- B: Testi -->
                <div class="mv-journey-content">
                    <div class="mv-step-text active" data-step="0">
                        <span class="mv-step-eyebrow">01</span>
                        <h3><?php echo esc_html($s1_title); ?></h3>
                        <p><?php echo esc_html($s1_desc); ?></p>
                    </div>
                    <div class="mv-step-text" data-step="1">
                        <span class="mv-step-eyebrow">02</span>
                        <h3><?php echo esc_html($s2_title); ?></h3>
                        <p><?php echo esc_html($s2_desc); ?></p>
                    </div>
                    <div class="mv-step-text" data-step="2">
                        <span class="mv-step-eyebrow">03</span>
                        <h3><?php echo esc_html($s3_title); ?></h3>
                        <p><?php echo esc_html($s3_desc); ?></p>
                    </div>
                    <div class="mv-step-text" data-step="3">
                        <span class="mv-step-eyebrow">04</span>
                        <h3><?php echo esc_html($s4_title); ?></h3>
                        <p><?php echo esc_html($s4_desc); ?></p>
                    </div>
                    <div class="mv-step-text" data-step="4">
                        <span class="mv-step-eyebrow">05</span>
                        <h3 class="text-black"><?php echo esc_html($s5_title); ?></h3>
                        <p class="text-black-50"><?php echo esc_html($s5_desc); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- 3B. MOBILE VERTICAL JOURNEY (5 Steps) -->
    <section class="mv-journey-mobile mobile-only monvel-container">
        <!-- Step 1 -->
        <div class="mv-mob-step fade-up-el">
            <span class="mv-mob-eyebrow">01 / 05</span>
            <h3 class="mv-mob-title"><?php echo esc_html($s1_title); ?></h3>
            <p class="mv-mob-desc"><?php echo esc_html($s1_desc); ?></p>
            <img src="<?php echo esc_url($img_logo); ?>" alt="<?php echo esc_attr($s1_title); ?>" class="mv-mob-img">
            <div class="mv-mob-badge"><?php echo esc_html($config_hotspots['ricamo']['label_text']); ?></div>
        </div>
        <!-- Step 2 -->
        <div class="mv-mob-step fade-up-el">
            <span class="mv-mob-eyebrow">02 / 05</span>
            <h3 class="mv-mob-title"><?php echo esc_html($s2_title); ?></h3>
            <p class="mv-mob-desc"><?php echo esc_html($s2_desc); ?></p>
            <img src="<?php echo esc_url($img_forma); ?>" alt="<?php echo esc_attr($s2_title); ?>" class="mv-mob-img">
        </div>
        <!-- Step 3 -->
        <div class="mv-mob-step fade-up-el">
            <span class="mv-mob-eyebrow">03 / 05</span>
            <h3 class="mv-mob-title"><?php echo esc_html($s3_title); ?></h3>
            <p class="mv-mob-desc"><?php echo esc_html($s3_desc); ?></p>
            <img src="<?php echo esc_url($img_visiera); ?>" alt="<?php echo esc_attr($s3_title); ?>" class="mv-mob-img">
            <div class="mv-mob-badge"><?php echo esc_html($config_hotspots['visiera']['label_text']); ?></div>
        </div>
        <!-- Step 4 -->
        <div class="mv-mob-step fade-up-el">
            <span class="mv-mob-eyebrow">04 / 05</span>
            <h3 class="mv-mob-title"><?php echo esc_html($s4_title); ?></h3>
            <p class="mv-mob-desc"><?php echo esc_html($s4_desc); ?></p>
            <img src="<?php echo esc_url($img_retro); ?>" alt="<?php echo esc_attr($s4_title); ?>" class="mv-mob-img">
            <div class="mv-mob-badge"><?php echo esc_html($config_hotspots['chiusura_snap']['label_text']); ?></div>
        </div>
        <!-- Step 5 -->
        <div class="mv-mob-step fade-up-el">
            <span class="mv-mob-eyebrow">05 / 05</span>
            <h3 class="mv-mob-title text-black"><?php echo esc_html($s5_title); ?></h3>
            <p class="mv-mob-desc text-black-50"><?php echo esc_html($s5_desc); ?></p>
            <div class="mv-mob-texture-wrap">
                <div class="mv-mob-texture-bg" style="background-image: url('<?php echo esc_url($img_texture); ?>');"></div>
            </div>
        </div>
    </section>

    <!-- 4. DETTAGLI TECNICI ESSENZIALI -->
    <section class="mv-det-specs">
        <div class="monvel-container">
            <h3 class="mv-det-specs-title fade-up-el">DETTAGLI ESSENZIALI</h3>
            <div class="mv-det-specs-list">
                <?php 
                $i = 1;
                foreach ($dynamic_attributes as $key => $val): 
                    $num = str_pad($i, 2, '0', STR_PAD_LEFT);
                ?>
                <div class="mv-spec-row fade-up-el">
                    <div class="mv-spec-num"><?php echo $num; ?></div>
                    <div class="mv-spec-key"><?php echo esc_html($key); ?></div>
                    <div class="mv-spec-val"><?php echo esc_html($val); ?></div>
                    <div class="mv-spec-line"></div>
                </div>
                <?php 
                $i++;
                endforeach; 
                ?>
            </div>
        </div>
    </section>

    <!-- 6. CTA FINALE -->
    <section class="mv-det-closing">
        <div class="mv-det-closing-outline">MONVÉL</div>
        <div class="monvel-container mv-det-closing-content">
            <h2 class="fade-up-el"><?php echo esc_html($cta_title); ?></h2>
            <p class="fade-up-el"><?php echo esc_html($cta_desc); ?></p>
            <div class="mv-det-closing-actions fade-up-el">
                <a href="<?php echo esc_url($cta_url); ?>" class="mv-btn mv-btn-primary mv-str-btn"><span><?php echo esc_html($cta_btn); ?></span></a>
            </div>
        </div>
    </section>

</main>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const fadeObserver = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('visible');
                observer.unobserve(entry.target);
            }
        });
    }, { threshold: 0.15 });

    document.querySelectorAll('.fade-up-el').forEach((el) => {
        fadeObserver.observe(el);
    });

    const journeyWrap = document.getElementById('sticky-journey');
    const visuals = document.querySelectorAll('.mv-step-visual');
    const texts = document.querySelectorAll('.mv-step-text');
    const navItems = document.querySelectorAll('.jp-item');
    const navNum = document.getElementById('jp-num');
    const navFill = document.getElementById('jp-fill');
    
    let targetProgress = 0;
    let currentProgress = 0;
    const totalSteps = 5;

    function lerp(start, end, amt) {
        return (1 - amt) * start + amt * end;
    }

    if (journeyWrap && window.innerWidth >= 768) {
        window.addEventListener('scroll', () => {
            const rect = journeyWrap.getBoundingClientRect();
            const wrapTop = rect.top;
            const wrapHeight = rect.height - window.innerHeight;
            
            if (wrapTop > 0) {
                targetProgress = 0;
            } else if (wrapTop < -wrapHeight) {
                targetProgress = 1;
            } else {
                targetProgress = Math.abs(wrapTop) / wrapHeight;
            }
        }, { passive: true });

        function updateJourney() {
            currentProgress = lerp(currentProgress, targetProgress, 0.08);

            if(navFill) {
                navFill.style.height = `${currentProgress * 100}%`;
            }

            let step = Math.floor(currentProgress * totalSteps);
            if (step >= totalSteps) step = totalSteps - 1;

            let localProgress = (currentProgress * totalSteps) - step;
            let scaleVal = 0.96 + (0.08 * localProgress);

            updateDOM(step, scaleVal);

            requestAnimationFrame(updateJourney);
        }
        requestAnimationFrame(updateJourney);
    }

    let activeStep = -1;
    function updateDOM(step, scaleVal) {
        visuals.forEach((v, index) => {
            const img = v.querySelector('.mv-lerp-scale');
            const textureBg = v.querySelector('.mv-texture-bg');
            if (img && index === step) {
                img.style.transform = `scale(${scaleVal})`;
            }
            if (textureBg && index === step) {
                textureBg.style.transform = `scale(${scaleVal})`;
            }
        });

        if (step === activeStep) return;
        activeStep = step;

        visuals.forEach((v, index) => {
            if (index === step) {
                v.classList.add('active');
                v.classList.remove('past', 'future');
            } else if (index < step) {
                v.classList.remove('active', 'future');
                v.classList.add('past');
            } else {
                v.classList.remove('active', 'past');
                v.classList.add('future');
            }
        });

        texts.forEach((t, index) => {
            if (index === step) {
                t.classList.add('active');
            } else {
                t.classList.remove('active');
            }
        });

        navItems.forEach((n, index) => {
            if (index === step) n.classList.add('active');
            else n.classList.remove('active');
        });
        
        if(navNum) {
            navNum.innerText = `0${step + 1} / 05`;
        }
    }
});
</script>

<?php
get_footer();
