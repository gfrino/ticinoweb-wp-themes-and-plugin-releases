<?php
/**
 * Template Name: Brand Identity
 * Description: Pagina "Chi siamo / Brand" con stile editoriale streetwear luminoso e americano.
 */

get_header();

// 1. DATI DINAMICI DAL CMS
$hero_title    = get_option('ticinoweb_chi_siamo_title', 'BRAND');
$hero_subtitle = get_option('ticinoweb_chi_siamo_subtitle', 'Un brand giovane, costruito attorno a cappelli essenziali, dettagli ricamati e uno stile streetwear pulito.');
$eyebrow       = 'MONVÉL IDENTITY';

$ed_title      = get_option('ticinoweb_chi_siamo_editorial_title', 'IL DETTAGLIO CHE DEFINISCE IL LOOK'); // If this doesn't exist, it will fallback
$ed_text       = get_option('ticinoweb_chi_siamo_text', 'Monvél nasce come brand di cappelli essenziale, moderno e riconoscibile. Un progetto giovane, costruito attorno a un’idea semplice: creare cappelli capaci di completare il look con carattere, senza bisogno di esagerare.');
$ed_image      = get_option('ticinoweb_chi_siamo_image', '');

// Dati Immersive Section
$immers_img    = get_option('ticinoweb_chi_siamo_immersive_image', !empty($ed_image) ? $ed_image : 'https://images.unsplash.com/photo-1556228578-0d85b1a4d571?q=80&w=2000&auto=format&fit=crop');
$immers_title  = get_option('ticinoweb_chi_siamo_immersive_title', 'ESSENZIALE NELLA FORMA.<br>DECISO NELLO STILE.');
$immers_text   = get_option('ticinoweb_chi_siamo_immersive_text', 'Un brand giovane, costruito attorno a cappelli essenziali, dettagli ricamati e un’estetica streetwear pulita.');

// Query WooCommerce Products & Attributes
$products_data = array();
$color_terms = array(); 
$embroidery_term = '';

if ( class_exists( 'WooCommerce' ) ) {
    $args = array( 'status' => 'publish', 'limit' => 2, 'orderby' => 'ID', 'order' => 'DESC' );
    $products = wc_get_products($args);
    foreach($products as $p) {
        $img_id = $p->get_image_id();
        
        $c_list = array();
        if ($p->is_type('variable')) {
            $variation_ids = $p->get_children();
            foreach ($variation_ids as $vid) {
                $v = wc_get_product($vid);
                if ($v && $v->get_status() === 'publish') {
                    $c = $v->get_attribute('pa_colore');
                    if ($c && !in_array($c, $c_list)) {
                        $c_list[] = $c;
                    }
                }
            }
        }
        if (empty($c_list)) {
            $prod_colors = wc_get_product_terms($p->get_id(), 'pa_colore', array('fields' => 'names'));
            $c_list = is_array($prod_colors) ? $prod_colors : array();
        }
        
        $products_data[] = array(
            'id'   => $p->get_id(),
            'url'  => $p->get_permalink(),
            'img'  => $img_id ? wp_get_attachment_image_url($img_id, 'full') : '',
            'name' => str_replace('Monvél ', '', $p->get_name()),
            'desc' => $p->get_short_description(),
            'colors' => $c_list
        );
        
        $color_terms = array_merge($color_terms, $c_list);
    }
    
    $color_terms = array_unique($color_terms);
    
    // Get embroidery (ricamo)
    $ricami = get_terms( array( 'taxonomy' => 'pa_ricamo', 'hide_empty' => true ) );
    if ( ! is_wp_error( $ricami ) && ! empty( $ricami ) ) {
        $embroidery_term = $ricami[0]->name;
    }
}
$shop_url = function_exists('wc_get_page_permalink') ? wc_get_page_permalink('shop') : home_url('/shop/');

// Descrizioni fisse per l'impatto editoriale basate sul nome
foreach ($products_data as &$pd) {
    if (strpos(strtolower($pd['name']), 'curve') !== false) {
        $pd['desc'] = 'Linee pulite. Presenza immediata.';
    } elseif (strpos(strtolower($pd['name']), 'snap') !== false) {
        $pd['desc'] = 'Forma decisa. Carattere urbano.';
    }
}
unset($pd);

if (empty($products_data[0])) {
    $products_data[0] = array('url' => $shop_url, 'img' => '', 'name' => 'Snap', 'desc' => 'Forma decisa. Carattere urbano.', 'colors' => array('Nero', 'Verde', 'Blu Navy'));
}
if (empty($products_data[1])) {
    $products_data[1] = array('url' => $shop_url, 'img' => '', 'name' => 'Curve', 'desc' => 'Linee pulite. Presenza immediata.', 'colors' => array('Beige', 'Nero', 'Rosa', 'Verde'));
}

// Fallbacks per la sezione Drop Dinamica
$total_models = count($products_data) > 0 ? count($products_data) : 2;
$models_names = count($products_data) > 0 ? implode(' / ', array_column($products_data, 'name')) : 'Curve / Snap';

$total_colors = count($color_terms) > 0 ? count($color_terms) : 6;
$color_names = count($color_terms) > 0 ? $color_terms : array('Beige', 'Nero', 'Rosa', 'Verde', 'Bianco', 'Grigio');

$ricamo_text = !empty($embroidery_term) ? $embroidery_term : 'Logo frontale ricamato';
?>

<main id="primary" class="site-main mv-str-page">

    <!-- 1. HERO STREETWEAR (uguale a Shop) -->
    <div class="mv-shop-hero">
        <div class="mv-shop-hero-bg-text">MONVÉL</div>
        <span class="mv-shop-eyebrow"><?php echo esc_html($eyebrow); ?></span>
        <h1 class="mv-shop-title"><?php echo wp_kses_post($hero_title); ?></h1>
        <p class="mv-shop-subtitle"><?php echo wp_kses_post($hero_subtitle); ?></p>
    </div>

    <!-- 3. IL DETTAGLIO CHE DEFINISCE IL LOOK (Editoriale) -->
    <section class="mv-str-editorial">
        <div class="monvel-container">
            <div class="mv-str-ed-grid">
                <div class="mv-str-ed-text-col">
                    <div class="mv-str-ed-label">ESSENTIALS</div>
                    <h2 class="mv-str-ed-title"><?php echo wp_kses_post($ed_title); ?></h2>
                    <div class="mv-str-ed-text">
                        <p><?php echo wp_kses_post($ed_text); ?></p>
                    </div>
                </div>
                <div class="mv-str-ed-image-col">
                    <div class="mv-str-ed-img-wrap">
                        <?php if(!empty($ed_image)): ?>
                            <img src="<?php echo esc_url($ed_image); ?>" alt="Editorial Monvel" class="mv-str-ed-img">
                        <?php else: ?>
                            <div class="mv-str-ed-placeholder">
                                <span>No Image Available</span>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- IMMERSIVE REVEAL SECTION -->
    <section class="mv-str-immersive-wrapper">
        <div class="mv-str-immersive-sticky">
            <div class="mv-str-immersive-bg" style="background-image: url('<?php echo esc_url($immers_img); ?>');"></div>
            <div class="mv-str-immersive-overlay"></div>
            <div class="mv-str-immersive-content monvel-container">
                <span class="mv-str-immersive-eyebrow fade-up-el">MONVÉL IDENTITY</span>
                <h2 class="mv-str-immersive-title fade-up-el"><?php echo wp_kses_post($immers_title); ?></h2>
                <p class="mv-str-immersive-text fade-up-el"><?php echo wp_kses_post($immers_text); ?></p>
                <!-- CTA opzionale -->
                <div class="fade-up-el" style="margin-top: 30px;">
                    <a href="<?php echo esc_url($shop_url); ?>" class="mv-btn mv-btn-primary mv-str-btn" style="background: white; color: black; border: none;"><span>SCOPRI I MODELLI</span></a>
                </div>
            </div>
        </div>
    </section>


    <!-- 4. MODELLI SPLIT SCREEN (Luminoso con Multiply) -->
    <section class="mv-str-models">
        <div class="mv-str-models-header">
            <h2>DUE MODELLI.<br>UNA SOLA IDENTITÀ.</h2>
        </div>
        <div class="mv-str-models-split">
            <?php foreach($products_data as $index => $prod): ?>
                <?php $mod_num = '0' . ($index + 1); ?>
                <a href="<?php echo esc_url($prod['url']); ?>" class="mv-str-model-panel panel-<?php echo strtolower($prod['name']); ?>">
                    <div class="mv-str-model-content">
                        <span class="mv-str-model-label">MODELLO <?php echo $mod_num; ?></span>
                        <h3 class="mv-str-model-name">Monvél <?php echo esc_html($prod['name']); ?></h3>
                        <p class="mv-str-model-desc"><?php echo wp_kses_post($prod['desc']); ?></p>
                    </div>
                    <div class="mv-str-model-visual">
                        <?php if(!empty($prod['img'])): ?>
                            <img src="<?php echo esc_url($prod['img']); ?>" alt="<?php echo esc_attr($prod['name']); ?>" class="mv-str-model-img multiply-blend">
                        <?php endif; ?>
                    </div>
                    <div class="mv-str-model-cta-wrap">
                        <span class="mv-str-model-cta">Scopri il modello &rarr;</span>
                    </div>
                </a>
            <?php endforeach; ?>
        </div>
    </section>

    <!-- 5. I NOSTRI CODICI (Fasce Orizzontali - Luminoso) -->
    <section class="mv-str-codes">
        <div class="monvel-container">
            <h2 class="mv-str-codes-title">I NOSTRI CODICI</h2>
            <div class="mv-str-codes-list">
                <div class="mv-str-code-row">
                    <span class="mv-str-code-num">01</span>
                    <h3 class="mv-str-code-name">ESSENZIALE</h3>
                    <p class="mv-str-code-desc">Design pulito, senza eccessi.</p>
                </div>
                <div class="mv-str-code-row">
                    <span class="mv-str-code-num">02</span>
                    <h3 class="mv-str-code-name">RICONOSCIBILE</h3>
                    <p class="mv-str-code-desc">Un logo ricamato, una presenza chiara.</p>
                </div>
                <div class="mv-str-code-row">
                    <span class="mv-str-code-num">03</span>
                    <h3 class="mv-str-code-name">QUOTIDIANO</h3>
                    <p class="mv-str-code-desc">Cappelli pensati per accompagnare ogni look.</p>
                </div>
                <div class="mv-str-code-row">
                    <span class="mv-str-code-num">04</span>
                    <h3 class="mv-str-code-name">STREETWEAR</h3>
                    <p class="mv-str-code-desc">Linee moderne, attitudine urbana.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- 6. DAL PRIMO DROP (Dinamico e Luminous) -->
    <section class="mv-str-drop" id="mv-str-drop-section">
        <div class="mv-str-drop-bg-num" id="mv-parallax-num">01</div>
        <div class="monvel-container">
            <div class="mv-str-drop-content">
                <h2 class="mv-str-drop-title">DAL PRIMO DROP</h2>
                <p class="mv-str-drop-text">La collezione Monvél parte da pochi elementi, scelti con intenzione: due forme, varianti colore essenziali e un logo ricamato che diventa segno distintivo.</p>
                
                <div class="mv-str-dyn-grid" id="mv-drop-grid">
                    <!-- Modelli -->
                    <div class="mv-str-dyn-block fade-up-el">
                        <div class="mv-str-dyn-line"></div>
                        <div class="mv-str-dyn-val" data-target="<?php echo esc_attr($total_models); ?>">00</div>
                        <h4 class="mv-str-dyn-label">MODELLI</h4>
                        <div class="mv-str-dyn-hover">
                            <span class="mv-str-dyn-models"><?php echo esc_html($models_names); ?></span>
                        </div>
                    </div>
                    
                    <!-- Colori -->
                    <div class="mv-str-dyn-block fade-up-el">
                        <div class="mv-str-dyn-line"></div>
                        <div class="mv-str-dyn-val" data-target="<?php echo esc_attr($total_colors); ?>">00</div>
                        <h4 class="mv-str-dyn-label">VARIANTI COLORE</h4>
                        <div class="mv-str-dyn-hover">
                            <div class="mv-str-swatches-grouped">
                                <?php foreach($products_data as $prod): ?>
                                    <?php if(!empty($prod['colors'])): ?>
                                        <div class="mv-str-swatches-group">
                                            <span class="mv-str-swatches-group-name"><?php echo esc_html($prod['name']); ?></span>
                                            <div class="mv-str-swatches-list">
                                            <?php foreach($prod['colors'] as $cn): 
                                                $color_data = function_exists('monvel_get_color_data') ? monvel_get_color_data($cn) : array('is_dual' => false, 'color1' => '#cccccc', 'color2' => '#cccccc');
                                                $inline_style = $color_data['is_dual'] ? 'style="--monvel-swatch-color-1: ' . esc_attr($color_data['color1']) . '; --monvel-swatch-color-2: ' . esc_attr($color_data['color2']) . ';"' : 'style="background-color: ' . esc_attr($color_data['color1']) . ';"';
                                                $extra_class = $color_data['is_dual'] ? ' is-dual-color' : '';
                                            ?>
                                                <span class="mv-str-swatch<?php echo $extra_class; ?>" <?php echo $inline_style; ?> title="<?php echo esc_attr($cn); ?>"></span>
                                            <?php endforeach; ?>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Ricamo -->
                    <div class="mv-str-dyn-block fade-up-el">
                        <div class="mv-str-dyn-line"></div>
                        <div class="mv-str-dyn-val" data-target="1">00</div>
                        <h4 class="mv-str-dyn-label">DETTAGLIO</h4>
                        <div class="mv-str-dyn-hover">
                            <span class="mv-str-dyn-ricamo">
                                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="mv-icon-stitch"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"></polyline></svg>
                                <?php echo esc_html($ricamo_text); ?>
                            </span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- 7. CTA FINALE (Luminoso) -->
    <section class="mv-str-closing">
        <div class="mv-str-closing-bg">MONVÉL</div>
        <div class="monvel-container">
            <h2 class="mv-str-closing-title">SCOPRI IL MONDO MONVÉL</h2>
            <p class="mv-str-closing-subtitle">Curve o Snap, scegli il modello che completa il tuo stile.</p>
            <a href="<?php echo esc_url($shop_url); ?>" class="mv-btn mv-btn-primary mv-str-btn"><span>VAI ALLO SHOP</span></a>
        </div>
    </section>

</main>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // 1. Parallax Effect per lo "01" gigante
    const parallaxNum = document.getElementById('mv-parallax-num');
    if (parallaxNum) {
        window.addEventListener('scroll', function() {
            let scrolled = window.pageYOffset;
            let sectionTop = document.getElementById('mv-str-drop-section').offsetTop;
            let val = (scrolled - sectionTop) * 0.15;
            parallaxNum.style.transform = `translate(-50%, calc(-50% + ${val}px))`;
        });
    }

    // 2. Observer Globale per le animazioni (Fade-Up)
    const fadeObserver = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('visible');
                observer.unobserve(entry.target);
            }
        });
    }, { threshold: 0.15 });

    // Osserva tutti gli elementi generici fade-up (inclusa la sezione Immersive)
    document.querySelectorAll('.fade-up-el').forEach((el, index) => {
        // Applica un leggero ritardo sequenziale se sono vicini nel DOM
        el.style.transitionDelay = (index % 4) * 0.15 + 's';
        fadeObserver.observe(el);
    });

    // 3. Observer Specifico per la griglia Drop (Fade-Up scaglionato + Count-Up)
    const dropGrid = document.getElementById('mv-drop-grid');
    if (dropGrid) {
        let animatedDrop = false;
        const dropObserver = new IntersectionObserver((entries) => {
            if (entries[0].isIntersecting && !animatedDrop) {
                animatedDrop = true;
                
                const counters = document.querySelectorAll('.mv-str-dyn-val');
                counters.forEach(counter => {
                    const target = +counter.getAttribute('data-target');
                    const duration = 1500; // ms
                    const increment = target / (duration / 16); // 60fps
                    let current = 0;

                    const updateCounter = () => {
                        current += increment;
                        if (current < target) {
                            counter.innerText = Math.ceil(current).toString().padStart(2, '0');
                            requestAnimationFrame(updateCounter);
                        } else {
                            counter.innerText = target.toString().padStart(2, '0');
                        }
                    };
                    setTimeout(() => {
                        updateCounter();
                    }, 300); // Ritardo leggero
                });
            }
        }, { threshold: 0.3 });
        
        dropObserver.observe(dropGrid);
    }
});
</script>

<?php
get_footer();
