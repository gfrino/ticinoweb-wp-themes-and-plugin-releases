<?php
/** A short, home-only brand entrance using the original CMS logo. */
defined( 'ABSPATH' ) || exit;

function monvel_home_preloader_logo() {
    if ( ! is_front_page() || ! function_exists( 'ticinoweb_get_site_logo' ) ) {
        return '';
    }
    return ticinoweb_get_site_logo();
}

add_action( 'wp_enqueue_scripts', function () {
    if ( ! monvel_home_preloader_logo() ) {
        return;
    }
    $version = wp_get_theme()->get( 'Version' );
    wp_enqueue_style( 'monvel-home-preloader', get_stylesheet_directory_uri() . '/assets/css/home-preloader.css', array( 'monvel-child-style' ), $version );
    // Runs in the head so the decorative overlay is enabled before first paint.
    wp_enqueue_script( 'monvel-home-preloader', get_stylesheet_directory_uri() . '/assets/js/home-preloader.js', array(), $version, false );
}, 101 );

function monvel_home_preloader_critical_tag( $tag, $handle ) {
    if ( 'monvel-home-preloader' !== $handle ) {
        return $tag;
    }
    // LiteSpeed recognizes these attributes; delaying this small entry point causes a flash.
    return str_replace( array( '<script ', '<link ' ), array( '<script data-no-optimize="1" data-no-defer="1" ', '<link data-no-optimize="1" data-no-defer="1" ' ), $tag );
}
add_filter( 'script_loader_tag', 'monvel_home_preloader_critical_tag', 10, 2 );
add_filter( 'style_loader_tag', 'monvel_home_preloader_critical_tag', 10, 2 );

add_action( 'wp_body_open', function () {
    $logo = monvel_home_preloader_logo();
    if ( ! $logo ) {
        return;
    }
    ?>
    <div id="mv-home-preloader" class="mv-preloader" aria-hidden="true" hidden>
        <div class="mv-preloader__panel mv-preloader__panel--left"></div>
        <div class="mv-preloader__panel mv-preloader__panel--right"></div>
        <div class="mv-preloader__seam"></div>
        <div class="mv-preloader__brand"><img class="mv-preloader__logo" src="<?php echo esc_url( $logo ); ?>" alt="" loading="eager" decoding="async" fetchpriority="high"></div>
    </div>
    <?php
}, 5 );
