<?php
/**
 * Monvél Colors Logic
 * Handles color mapping and dual-color split logic for variation swatches.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! function_exists( 'monvel_get_color_data' ) ) {
    function monvel_get_color_data( $color_string ) {
        // Mappatura colori base
        $color_map = array(
            'nero'          => '#111111',
            'bianco'        => '#F7F7F2',
            'rosso'         => '#B5161B',
            'beige'         => '#D8C8B4',
            'rosa'          => '#F4B8C4',
            'albicocca'     => '#FADFD4',
            'verde'         => '#4E5F23',
            'verde-oliva'   => '#4E5F23',
            'blu-navy'      => '#07145C',
            'grigio-chiaro' => '#B8B8B2',
            'panna'         => '#EFE8D8',
            // Nuovi colori generici
            'marrone'       => '#5C4033',
            'oro'           => '#D4AF37',
            'giallo'        => '#FFD700',
            'arancione'     => '#FF8C00',
            'viola'         => '#800080',
            'azzurro'       => '#87CEEB',
            'celeste'       => '#87CEEB',
            'bordeaux'      => '#800020',
            'argento'       => '#C0C0C0',
            'bronzo'        => '#CD7F32',
            'rame'          => '#B87333',
            'crema'         => '#FFFDD0',
            'ocra'          => '#CC7722',
            'fucsia'        => '#FF00FF',
            'magenta'       => '#FF00FF',
            'turchese'      => '#40E0D0',
            'senape'        => '#FFDB58',
            'corallo'       => '#FF7F50',
            'pesca'         => '#FFE5B4',
            'lilla'         => '#C8A2C8',
            'verde-chiaro'  => '#90EE90',
            'verde-scuro'   => '#006400',
            'blu-chiaro'    => '#ADD8E6',
            'grigio-scuro'  => '#A9A9A9',
            'grigio'        => '#808080',
            'giallo-senape' => '#FFDB58',
            'blu'           => '#0000FF',
            // Varianti in inglese (fallback)
            'black'         => '#111111',
            'white'         => '#F7F7F2',
            'red'           => '#B5161B',
            'khaki'         => '#D8C8B4',
            'sabbia'        => '#D8C8B4',
            'pink'          => '#F4B8C4',
            'green'         => '#4E5F23',
            'navy'          => '#07145C',
            'blue'          => '#07145C',
            'grey'          => '#B8B8B2',
            'gray'          => '#B8B8B2',
            'brown'         => '#5C4033',
            'gold'          => '#D4AF37',
            'yellow'        => '#FFD700',
            'orange'        => '#FF8C00',
            'purple'        => '#800080',
            'silver'        => '#C0C0C0'
        );

        $normalized = strtolower( trim( $color_string ) );
        
        // Sostituisci gli spazi nei nomi composti noti con trattino
        $normalized = str_replace( 
            array('blu navy', 'verde oliva', 'grigio chiaro', 'grigio scuro', 'blu chiaro', 'verde chiaro', 'verde scuro', 'giallo senape'), 
            array('blu-navy', 'verde-oliva', 'grigio-chiaro', 'grigio-scuro', 'blu-chiaro', 'verde-chiaro', 'verde-scuro', 'giallo-senape'), 
            $normalized 
        );

        $is_dual = false;
        $color1 = '#111111'; // Fallback
        $color2 = '#111111'; // Fallback
        
        // Controlla per slash (es. Nero/Rosso)
        if ( strpos( $normalized, '/' ) !== false ) {
            $parts = explode( '/', $normalized );
            $is_dual = true;
            $c1 = trim( $parts[0] );
            $c2 = trim( $parts[1] );
            
            $c1_key = str_replace(' ', '-', $c1);
            $c2_key = str_replace(' ', '-', $c2);
            
            if ( isset( $color_map[$c1_key] ) ) { $color1 = $color_map[$c1_key]; }
            if ( isset( $color_map[$c2_key] ) ) { $color2 = $color_map[$c2_key]; }
        } 
        // Controlla per trattino se non è un colore composto noto (es. nero-rosso)
        elseif ( strpos( $normalized, '-' ) !== false && ! isset( $color_map[$normalized] ) ) {
            $parts = explode( '-', $normalized );
            if ( count($parts) === 2 ) {
                $is_dual = true;
                $c1_key = trim( $parts[0] );
                $c2_key = trim( $parts[1] );
                
                if ( isset( $color_map[$c1_key] ) ) { $color1 = $color_map[$c1_key]; }
                if ( isset( $color_map[$c2_key] ) ) { $color2 = $color_map[$c2_key]; }
            } else {
                // Se ha più di due trattini o un solo colore, usa solo il primo come principale o fallback globale
                $key = str_replace(' ', '-', $normalized);
                if ( isset( $color_map[$key] ) ) {
                    $color1 = $color_map[$key];
                }
            }
        } 
        else {
            // Colore singolo
            $key = str_replace(' ', '-', $normalized);
            if ( isset( $color_map[$key] ) ) {
                $color1 = $color_map[$key];
            } else {
                // Fallback di ricerca parziale
                foreach ( $color_map as $map_key => $hex ) {
                    if ( strpos( $key, $map_key ) !== false ) {
                        $color1 = $hex;
                        break;
                    }
                }
            }
        }

        // Se sono identici (es. Nero/Nero), potremmo trattarlo come non-dual visivamente, 
        // ma tecnicamente possiamo lasciarlo dual con due colori identici.
        // Lascio $is_dual a true così l'HTML è corretto semanticamente.
        
        return array(
            'is_dual' => $is_dual,
            'color1'  => $color1,
            'color2'  => $color2
        );
    }
}
