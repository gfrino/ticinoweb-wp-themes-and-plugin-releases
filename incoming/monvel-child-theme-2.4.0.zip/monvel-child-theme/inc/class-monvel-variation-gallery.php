<?php
/**
 * Monvél Variation Image Gallery
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Monvel_Variation_Gallery {

    public function __construct() {
        add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_scripts' ) );
        add_action( 'woocommerce_product_after_variable_attributes', array( $this, 'add_gallery_fields' ), 10, 3 );
        add_action( 'woocommerce_save_product_variation', array( $this, 'save_gallery_fields' ), 10, 2 );
        add_filter( 'woocommerce_available_variation', array( $this, 'add_gallery_data_to_variation' ), 10, 3 );
    }

    public function enqueue_admin_scripts( $hook ) {
        global $post_type;
        if ( 'product' !== $post_type ) {
            return;
        }

        wp_enqueue_media();
        
        wp_enqueue_style(
            'monvel-variation-gallery-admin',
            get_stylesheet_directory_uri() . '/assets/css/monvel-variation-gallery-admin.css',
            array(),
            '1.0.0'
        );

        wp_enqueue_script(
            'monvel-variation-gallery-admin',
            get_stylesheet_directory_uri() . '/assets/js/monvel-variation-gallery-admin.js',
            array( 'jquery', 'jquery-ui-sortable' ),
            '1.0.0',
            true
        );
    }

    public function add_gallery_fields( $loop, $variation_data, $variation ) {
        $gallery_ids = get_post_meta( $variation->ID, '_monvel_variation_gallery_images', true );
        ?>
        <div class="form-row form-row-full monvel-variation-gallery-wrapper">
            <h4>Galleria Immagini Variazione (Monvél)</h4>
            <div class="monvel-variation-gallery-images">
                <ul class="monvel-variation-gallery-list">
                    <?php
                    if ( ! empty( $gallery_ids ) ) {
                        $attachment_ids = explode( ',', $gallery_ids );
                        foreach ( $attachment_ids as $attachment_id ) {
                            $image = wp_get_attachment_image_src( $attachment_id, 'thumbnail' );
                            if ( $image ) {
                                echo '<li class="image" data-attachment_id="' . esc_attr( $attachment_id ) . '">';
                                echo '<img src="' . esc_url( $image[0] ) . '" alt="" />';
                                echo '<a href="#" class="delete" title="Rimuovi immagine">&times;</a>';
                                echo '</li>';
                            }
                        }
                    }
                    ?>
                </ul>
                <input type="hidden" class="monvel-variation-gallery-ids" name="monvel_variation_gallery_images[<?php echo esc_attr( $loop ); ?>]" value="<?php echo esc_attr( $gallery_ids ); ?>">
            </div>
            <p class="add-monvel-variation-gallery-image hide-if-no-js">
                <a href="#" class="button">Aggiungi Immagini Galleria</a>
            </p>
        </div>
        <?php
    }

    public function save_gallery_fields( $variation_id, $i ) {
        if ( isset( $_POST['monvel_variation_gallery_images'][$i] ) ) {
            $gallery_ids = sanitize_text_field( $_POST['monvel_variation_gallery_images'][$i] );
            update_post_meta( $variation_id, '_monvel_variation_gallery_images', $gallery_ids );
        }
    }

    public function add_gallery_data_to_variation( $data, $product, $variation ) {
        $gallery_ids = get_post_meta( $variation->get_id(), '_monvel_variation_gallery_images', true );
        
        $gallery_images = array();
        
        if ( ! empty( $gallery_ids ) ) {
            $attachment_ids = explode( ',', $gallery_ids );
            foreach ( $attachment_ids as $attachment_id ) {
                $full_src  = wp_get_attachment_image_src( $attachment_id, 'full' );
                $thumb_src = wp_get_attachment_image_src( $attachment_id, 'thumbnail' );
                $alt_text  = get_post_meta( $attachment_id, '_wp_attachment_image_alt', true );
                $title     = get_the_title( $attachment_id );
                
                if ( $full_src && $thumb_src ) {
                    $gallery_images[] = array(
                        'id'        => $attachment_id,
                        'full_src'  => $full_src[0],
                        'thumb_src' => $thumb_src[0],
                        'alt'       => $alt_text,
                        'title'     => $title,
                    );
                }
            }
        }
        
        $data['variation_gallery_images'] = $gallery_images;
        
        return $data;
    }
}

new Monvel_Variation_Gallery();
