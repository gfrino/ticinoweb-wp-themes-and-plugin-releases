<?php
/**
 * Monvél Product Add-ons System
 * Handles backend UI, saving meta, frontend rendering, and cart calculations.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

class Monvel_Product_Addons {

    public function __construct() {
        // Backend UI
        add_filter( 'woocommerce_product_data_tabs', [ $this, 'add_product_data_tab' ] );
        add_action( 'woocommerce_product_data_panels', [ $this, 'add_product_data_panel' ] );
        add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_admin_scripts' ] );

        // Save Meta
        add_action( 'woocommerce_process_product_meta', [ $this, 'save_product_meta' ] );

        // Add to Cart Logic
        add_filter( 'woocommerce_add_cart_item_data', [ $this, 'add_cart_item_data' ], 10, 3 );
        
        // Cart Data Display
        add_filter( 'woocommerce_get_item_data', [ $this, 'get_item_data' ], 10, 2 );
        
        // Price Calculation
        add_action( 'woocommerce_before_calculate_totals', [ $this, 'calculate_totals' ], 10, 1 );

        // Save to Order
        add_action( 'woocommerce_checkout_create_order_line_item', [ $this, 'add_order_line_item_meta' ], 10, 4 );
    }

    /**
     * Add "Add-ons" tab to Product Data
     */
    public function add_product_data_tab( $tabs ) {
        $tabs['monvel_addons'] = [
            'label'  => __( 'Add-ons', 'monvel-child-theme' ),
            'target' => 'monvel_product_addons_data',
            'class'  => [ 'show_if_simple', 'show_if_variable' ],
            'priority' => 60,
        ];
        return $tabs;
    }

    /**
     * Add-ons panel content
     */
    public function add_product_data_panel() {
        global $post;
        $addons = get_post_meta( $post->ID, '_monvel_product_addons', true );
        if ( ! is_array( $addons ) ) {
            $addons = [];
        }
        
        ?>
        <div id="monvel_product_addons_data" class="panel woocommerce_options_panel hidden">
            <?php wp_nonce_field( 'save_monvel_addons', 'monvel_addons_nonce' ); ?>
            <div class="options_group">
                <p class="form-field">
                    <label><?php _e('Gestione Add-ons Monvél', 'monvel-child-theme'); ?></label>
                    <span class="description"><?php _e('Aggiungi opzioni extra come confezione regalo, ecc.', 'monvel-child-theme'); ?></span>
                </p>
                <div id="monvel-addons-wrapper">
                    <?php 
                    $index = 0;
                    foreach ( $addons as $addon ) : ?>
                        <div class="monvel-addon-row" data-index="<?php echo esc_attr( $index ); ?>">
                            <div class="addon-header">
                                <strong>Add-on #<span class="addon-number"><?php echo $index + 1; ?></span></strong>
                                <button type="button" class="button remove-addon">Rimuovi</button>
                            </div>
                            <div class="addon-fields">
                                <p class="form-field">
                                    <label>Immagine</label>
                                    <span class="mv-addon-img-preview" style="display:inline-block; margin-bottom:5px;">
                                        <?php 
                                        if ( ! empty( $addon['image_url'] ) ) : 
                                            $urls = explode(',', $addon['image_url']);
                                            foreach ( $urls as $url ) : ?>
                                                <img src="<?php echo esc_url( trim($url) ); ?>" style="max-width:60px; height:auto; margin-right:5px; border:1px solid #ddd;">
                                            <?php endforeach;
                                        endif; ?>
                                    </span><br>
                                    <input type="hidden" class="mv-addon-img-input" name="_monvel_addons[<?php echo $index; ?>][image_url]" value="<?php echo esc_attr( isset($addon['image_url']) ? $addon['image_url'] : '' ); ?>">
                                    <button type="button" class="button mv-upload-addon-img">Scegli Immagine</button>
                                    <button type="button" class="button mv-remove-addon-img" style="<?php echo empty($addon['image_url']) ? 'display:none;' : ''; ?>">Rimuovi Immagine</button>
                                </p>
                                <p class="form-field">
                                    <label>Nome Add-on</label>
                                    <input type="text" name="_monvel_addons[<?php echo $index; ?>][name]" value="<?php echo esc_attr( $addon['name'] ); ?>" placeholder="Es: Confezione regalo">
                                </p>
                                <p class="form-field">
                                    <label>Descrizione Breve</label>
                                    <input type="text" name="_monvel_addons[<?php echo $index; ?>][desc]" value="<?php echo esc_attr( $addon['desc'] ); ?>" placeholder="Descrizione opzionale">
                                </p>
                                <p class="form-field">
                                    <label>Prezzo (CHF)</label>
                                    <input type="number" step="0.01" min="0" name="_monvel_addons[<?php echo $index; ?>][price]" value="<?php echo esc_attr( $addon['price'] ); ?>" placeholder="0.00">
                                </p>
                                <p class="form-field">
                                    <label>Stato</label>
                                    <select name="_monvel_addons[<?php echo $index; ?>][status]">
                                        <option value="active" <?php selected( $addon['status'], 'active' ); ?>>Attivo</option>
                                        <option value="inactive" <?php selected( $addon['status'], 'inactive' ); ?>>Disattivo</option>
                                    </select>
                                </p>
                            </div>
                        </div>
                    <?php 
                        $index++;
                    endforeach; ?>
                </div>
                <p class="form-field">
                    <button type="button" class="button button-primary" id="add-monvel-addon">Aggiungi nuovo Add-on</button>
                </p>
            </div>
        </div>
        
        <!-- Template for new addon via JS -->
        <script type="text/template" id="tmpl-monvel-addon-row">
            <div class="monvel-addon-row" data-index="{{index}}">
                <div class="addon-header">
                    <strong>Add-on #<span class="addon-number">{{number}}</span></strong>
                    <button type="button" class="button remove-addon">Rimuovi</button>
                </div>
                <div class="addon-fields">
                    <p class="form-field">
                        <label>Immagine</label>
                        <span class="mv-addon-img-preview" style="display:inline-block; margin-bottom:5px;"></span><br>
                        <input type="hidden" class="mv-addon-img-input" name="_monvel_addons[{{index}}][image_url]" value="">
                        <button type="button" class="button mv-upload-addon-img">Scegli Immagine</button>
                        <button type="button" class="button mv-remove-addon-img" style="display:none;">Rimuovi Immagine</button>
                    </p>
                    <p class="form-field">
                        <label>Nome Add-on</label>
                        <input type="text" name="_monvel_addons[{{index}}][name]" value="" placeholder="Es: Confezione regalo">
                    </p>
                    <p class="form-field">
                        <label>Descrizione Breve</label>
                        <input type="text" name="_monvel_addons[{{index}}][desc]" value="" placeholder="Descrizione opzionale">
                    </p>
                    <p class="form-field">
                        <label>Prezzo (CHF)</label>
                        <input type="number" step="0.01" min="0" name="_monvel_addons[{{index}}][price]" value="0.00" placeholder="0.00">
                    </p>
                    <p class="form-field">
                        <label>Stato</label>
                        <select name="_monvel_addons[{{index}}][status]">
                            <option value="active">Attivo</option>
                            <option value="inactive">Disattivo</option>
                        </select>
                    </p>
                </div>
            </div>
        </script>
        <?php
    }

    /**
     * Enqueue Admin Scripts for Repeater
     */
    public function enqueue_admin_scripts( $hook ) {
        global $post;
        if ( ! in_array( $hook, array( 'post.php', 'post-new.php' ) ) ) return;
        if ( 'product' !== $post->post_type ) return;

        wp_enqueue_media();

        wp_add_inline_script( 'jquery', '
            jQuery(document).ready(function($) {
                var wrapper = $("#monvel-addons-wrapper");
                var tmpl = $("#tmpl-monvel-addon-row").html();
                
                $("#add-monvel-addon").on("click", function(e) {
                    e.preventDefault();
                    var count = wrapper.children(".monvel-addon-row").length;
                    var newRow = tmpl.replace(/{{index}}/g, count).replace(/{{number}}/g, count + 1);
                    wrapper.append(newRow);
                });
                
                // Upload Image
                wrapper.on("click", ".mv-upload-addon-img", function(e) {
                    e.preventDefault();
                    var button = $(this);
                    var row = button.closest(".monvel-addon-row");
                    var custom_uploader = wp.media({
                        title: "Scegli Immagini Add-on",
                        button: { text: "Usa queste immagini" },
                        multiple: true
                    }).on("select", function() {
                        var attachments = custom_uploader.state().get("selection").toJSON();
                        var urls = [];
                        var html = "";
                        for (var i = 0; i < attachments.length; i++) {
                            urls.push(attachments[i].url);
                            html += "<img src=\""+attachments[i].url+"\" style=\"max-width:60px; height:auto; margin-right:5px; border:1px solid #ddd;\">";
                        }
                        row.find(".mv-addon-img-input").val(urls.join(","));
                        row.find(".mv-addon-img-preview").html(html);
                        row.find(".mv-remove-addon-img").show();
                    }).open();
                });

                // Remove Image
                wrapper.on("click", ".mv-remove-addon-img", function(e) {
                    e.preventDefault();
                    var button = $(this);
                    var row = button.closest(".monvel-addon-row");
                    row.find(".mv-addon-img-input").val("");
                    row.find(".mv-addon-img-preview").html("");
                    button.hide();
                });
                
                wrapper.on("click", ".remove-addon", function(e) {
                    e.preventDefault();
                    $(this).closest(".monvel-addon-row").remove();
                    // Reindex
                    wrapper.children(".monvel-addon-row").each(function(i) {
                        $(this).attr("data-index", i);
                        $(this).find(".addon-number").text(i + 1);
                        $(this).find("input, select").each(function() {
                            var name = $(this).attr("name");
                            if (name) {
                                $(this).attr("name", name.replace(/\[\d+\]/, "[" + i + "]"));
                            }
                        });
                    });
                });
            });
        ' );

        wp_add_inline_style( 'woocommerce_admin_styles', '
            #monvel_product_addons_data .monvel-addon-row {
                background: #f9f9f9;
                border: 1px solid #dfdfdf;
                padding: 10px 15px;
                margin: 0 10px 15px 10px;
            }
            #monvel_product_addons_data .addon-header {
                display: flex;
                justify-content: space-between;
                align-items: center;
                margin-bottom: 10px;
                padding-bottom: 10px;
                border-bottom: 1px solid #eee;
            }
            #monvel_product_addons_data .addon-fields .form-field {
                padding: 5px 0 !important;
                margin: 0 !important;
            }
        ' );
    }

    /**
     * Save Product Meta
     */
    public function save_product_meta( $post_id ) {
        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
            return;
        }

        if ( ! isset( $_POST['monvel_addons_nonce'] ) || ! wp_verify_nonce( $_POST['monvel_addons_nonce'], 'save_monvel_addons' ) ) {
            return;
        }

        if ( isset( $_POST['_monvel_addons'] ) && is_array( $_POST['_monvel_addons'] ) ) {
            $addons = [];
            foreach ( $_POST['_monvel_addons'] as $addon ) {
                if ( ! empty( $addon['name'] ) ) {
                    $addons[] = [
                        'name'      => sanitize_text_field( $addon['name'] ),
                        'desc'      => sanitize_text_field( $addon['desc'] ),
                        'price'     => wc_format_decimal( sanitize_text_field( $addon['price'] ) ),
                        'status'    => sanitize_text_field( $addon['status'] ),
                        'image_url' => isset( $addon['image_url'] ) ? esc_url_raw( $addon['image_url'] ) : '',
                    ];
                }
            }
            update_post_meta( $post_id, '_monvel_product_addons', $addons );
        } else {
            delete_post_meta( $post_id, '_monvel_product_addons' );
        }
    }

    /**
     * Add item data to the cart
     */
    public function add_cart_item_data( $cart_item_data, $product_id, $variation_id ) {
        // Find if any addon fields were submitted
        $submitted_addons = [];
        $product_addons = get_post_meta( $product_id, '_monvel_product_addons', true );
        
        if ( ! empty( $product_addons ) && is_array( $product_addons ) ) {
            foreach ( $product_addons as $index => $addon ) {
                if ( $addon['status'] !== 'active' ) continue;
                
                // Form field name generated in frontend: monvel_addon_{index}
                if ( isset( $_POST['monvel_addon_' . $index] ) ) {
                    $submitted_addons[] = [
                        'name'  => $addon['name'],
                        'price' => (float) $addon['price'],
                    ];
                }
            }
        }

        if ( ! empty( $submitted_addons ) ) {
            $cart_item_data['monvel_addons'] = $submitted_addons;
            
            // To make sure each addon combination is a unique cart item
            $cart_item_data['unique_key'] = md5( microtime() . rand() );
        }

        return $cart_item_data;
    }

    /**
     * Calculate extra price
     */
    public function calculate_totals( $cart ) {
        if ( is_admin() && ! defined( 'DOING_AJAX' ) ) {
            return;
        }

        // To prevent infinite loop if price changes
        if ( did_action( 'woocommerce_before_calculate_totals' ) >= 2 ) {
            return;
        }

        foreach ( $cart->get_cart() as $cart_item_key => $cart_item ) {
            if ( isset( $cart_item['monvel_addons'] ) && ! empty( $cart_item['monvel_addons'] ) ) {
                $extra_price = 0;
                foreach ( $cart_item['monvel_addons'] as $addon ) {
                    $extra_price += (float) $addon['price'];
                }
                
                if ( $extra_price > 0 ) {
                    // Get base price from the product
                    $base_price = (float) $cart_item['data']->get_price();
                    // Add extra price
                    $cart_item['data']->set_price( $base_price + $extra_price );
                }
            }
        }
    }

    /**
     * Display addons in cart and checkout
     */
    public function get_item_data( $item_data, $cart_item ) {
        if ( isset( $cart_item['monvel_addons'] ) && ! empty( $cart_item['monvel_addons'] ) ) {
            foreach ( $cart_item['monvel_addons'] as $addon ) {
                $price_display = '';
                if ( $addon['price'] > 0 ) {
                    $price_display = ' (' . wc_price( $addon['price'] ) . ')';
                }
                
                $item_data[] = [
                    'key'     => __( 'Add-on', 'monvel-child-theme' ),
                    'value'   => $addon['name'] . $price_display,
                    'display' => '',
                ];
            }
        }
        return $item_data;
    }

    /**
     * Save to order
     */
    public function add_order_line_item_meta( $item, $cart_item_key, $values, $order ) {
        if ( isset( $values['monvel_addons'] ) && ! empty( $values['monvel_addons'] ) ) {
            foreach ( $values['monvel_addons'] as $addon ) {
                $price_display = '';
                if ( $addon['price'] > 0 ) {
                    $price_display = ' (' . wc_price( $addon['price'] ) . ')';
                }
                // Save meta data to order item
                $item->add_meta_data( __( 'Add-on', 'monvel-child-theme' ), $addon['name'] . $price_display );
            }
        }
    }

    /**
     * Frontend display function (called from template)
     */
    public static function display_frontend_addons( $product_id ) {
        $addons = get_post_meta( $product_id, '_monvel_product_addons', true );
        if ( empty( $addons ) || ! is_array( $addons ) ) return;
        
        $active_addons = array_filter( $addons, function($addon) {
            return isset($addon['status']) && $addon['status'] === 'active';
        });

        if ( empty( $active_addons ) ) return;

        ?>
        <div class="mv-product-addons-wrapper">
            <h4 class="mv-addons-title"><?php _e('Personalizza il tuo Monvél', 'monvel-child-theme'); ?></h4>
            <div class="mv-addons-list">
                <?php foreach ( $addons as $index => $addon ) : 
                    if ( $addon['status'] !== 'active' ) continue;
                    $price_text = $addon['price'] > 0 ? '+ ' . wc_price( $addon['price'] ) : __('Gratuito', 'monvel-child-theme');
                ?>
                    <div class="mv-addon-row-compact">
                        <label class="mv-addon-label-wrap">
                            <div class="mv-addon-checkbox">
                                <input type="checkbox" class="mv-addon-input" data-index="<?php echo esc_attr( $index ); ?>" data-price="<?php echo esc_attr( $addon['price'] ); ?>" data-name="<?php echo esc_attr( $addon['name'] ); ?>">
                                <span class="mv-addon-custom-check">
                                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg>
                                </span>
                            </div>
                            <div class="mv-addon-name-wrap">
                                <span class="mv-addon-name"><?php echo esc_html( $addon['name'] ); ?></span>
                            </div>
                            <div class="mv-addon-price">
                                <?php echo wp_kses_post( $price_text ); ?>
                            </div>
                        </label>
                        <button type="button" class="mv-addon-info-btn" aria-label="Informazioni Add-on">
                            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="16" x2="12" y2="12"></line><line x1="12" y1="8" x2="12.01" y2="8"></line></svg>
                        </button>
                        
                        <div class="mv-addon-tooltip">
                            <?php if ( ! empty( $addon['image_url'] ) ) : 
                                $urls = explode(',', $addon['image_url']);
                            ?>
                                <div class="mv-addon-tooltip-gallery">
                                    <?php foreach ( $urls as $url ) : ?>
                                        <img src="<?php echo esc_url( trim($url) ); ?>" alt="<?php echo esc_attr( $addon['name'] ); ?>">
                                    <?php endforeach; ?>
                                </div>
                            <?php endif; ?>
                            <?php if ( ! empty( $addon['desc'] ) ) : ?>
                                <p class="mv-addon-tooltip-desc"><?php echo esc_html( $addon['desc'] ); ?></p>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php
    }
}

new Monvel_Product_Addons();
