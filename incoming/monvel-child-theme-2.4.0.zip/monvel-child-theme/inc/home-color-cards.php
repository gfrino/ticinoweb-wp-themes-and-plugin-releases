<?php
/** Color-specific home cards, using the existing WooCommerce variation galleries. */
defined( 'ABSPATH' ) || exit;

function monvel_home_color_card( $product, $variation ) {
    if ( ! $variation instanceof WC_Product_Variation || 'publish' !== $variation->get_status() ) {
        return null;
    }

    $attributes = $variation->get_attributes();
    $color_slug = $attributes['pa_colore'] ?? '';
    if ( '' === $color_slug ) {
        return null;
    }

    // Read the variation's own image: inheriting the parent can show the wrong color.
    $images = array_merge(
        array( $variation->get_image_id( 'edit' ) ),
        wp_parse_id_list( $variation->get_meta( '_monvel_variation_gallery_images' ) )
    );
    $images = array_values( array_filter( array_unique( array_map( 'absint', $images ) ), function ( $id ) {
        return $id && wp_attachment_is_image( $id ) && wp_get_attachment_image_url( $id, 'large' );
    } ) );
    if ( ! $images ) {
        return null;
    }

    return array(
        'variation_id' => $variation->get_id(),
        'color_slug'   => $color_slug,
        'color'        => $variation->get_attribute( 'pa_colore' ),
        'images'       => $images,
        'url'          => add_query_arg( 'attribute_pa_colore', $color_slug, $product->get_permalink() ),
        'price'        => $variation->get_price_html(),
        'in_stock'     => $variation->is_in_stock(),
    );
}

function monvel_get_home_color_cards( $product ) {
    $cards = array();
    foreach ( $product->get_children() as $id ) {
        $card = monvel_home_color_card( $product, wc_get_product( $id ) );
        if ( ! $card ) {
            continue;
        }
        $key = $card['color_slug'];
        if ( ! isset( $cards[ $key ] ) || ( ! $cards[ $key ]['in_stock'] && $card['in_stock'] ) ) {
            $cards[ $key ] = $card;
        }
    }
    return array_values( $cards );
}
