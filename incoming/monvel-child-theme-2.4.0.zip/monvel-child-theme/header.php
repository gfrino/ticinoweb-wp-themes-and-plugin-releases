<?php
/**
 * The header for Monvél Cappelli (Streetwear / E-commerce Edition)
 */
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="profile" href="https://gmpg.org/xfn/11">
    <?php wp_head(); ?>
</head>

<body <?php body_class('monvel-ecommerce'); ?>>
<?php wp_body_open(); ?>

<div id="page" class="site">
    <a class="skip-link screen-reader-text" href="#primary"><?php esc_html_e( 'Skip to content', 'monvel-child-theme' ); ?></a>

    <!-- Minimal Streetwear Header -->
    <header id="masthead" class="monvel-header">
        <div class="monvel-container">
            <div class="monvel-header-inner">
                <div class="mv-mobile-toggle-wrapper">
                    <button class="mv-mobile-toggle" aria-label="Apri Menu" type="button">
                        <span class="hamburger-box">
                            <span class="hamburger-inner"></span>
                        </span>
                    </button>
                </div>

                <div class="site-branding">
                    <?php
                    $logo_url = function_exists( 'ticinoweb_get_site_logo' ) ? ticinoweb_get_site_logo() : '';
                    if ( !empty( $logo_url ) ) : ?>
                        <a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
                            <img src="<?php echo esc_url( $logo_url ); ?>" alt="MONVÉL" class="monvel-logo-img">
                        </a>
                    <?php else : ?>
                        <h1 class="monvel-logo-text"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">MONVÉL</a></h1>
                    <?php endif; ?>
                </div>

                <nav id="site-navigation" class="main-navigation">
                    <?php
                    wp_nav_menu( array(
                        'theme_location' => 'primary', // Default location in Ticinoweb AI theme
                        'menu_id'        => 'primary-menu',
                        'container'      => false,
                        'fallback_cb'    => '__return_false',
                    ) );
                    // If no menu is assigned to 'primary', try a generic output
                    if ( ! has_nav_menu( 'primary' ) ) {
                        wp_nav_menu( array(
                            'menu_class'     => 'fallback-menu',
                            'container'      => false,
                            'depth'          => 1,
                        ) );
                    }
                    ?>
                    
                    <!-- Mobile Language Switcher (Inside Menu) -->
                    <div class="mv-mobile-lang-wrapper hide-on-desktop">
                        <?php echo do_shortcode('[gtranslate]'); ?>
                    </div>
                </nav>

                <div class="header-actions">
                    

                    <!-- Account Button -->
                    <?php if ( class_exists( 'WooCommerce' ) ) : ?>
                        <a class="account-icon mv-account-btn" href="<?php echo esc_url( get_permalink( get_option('woocommerce_myaccount_page_id') ) ); ?>" aria-label="Mio Account">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
                                <circle cx="12" cy="7" r="4"></circle>
                            </svg>
                        </a>
                    <?php endif; ?>

                    <!-- Cart Button -->
                    <?php if ( class_exists( 'WooCommerce' ) ) : ?>
                        <a class="cart-icon mv-cart-btn" href="<?php echo esc_url( wc_get_cart_url() ); ?>" aria-label="Apri carrello">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"></path>
                                <line x1="3" y1="6" x2="21" y2="6"></line>
                                <path d="M16 10a4 4 0 0 1-8 0"></path>
                            </svg>
                            <span class="mv-cart-count"><?php echo esc_html( WC()->cart->get_cart_contents_count() ); ?></span>
                        </a>
                    <?php else : ?>
                        <a class="cart-icon mv-cart-btn" href="#" aria-label="Apri carrello">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"></path>
                                <line x1="3" y1="6" x2="21" y2="6"></line>
                                <path d="M16 10a4 4 0 0 1-8 0"></path>
                            </svg>
                            <span class="mv-cart-count">0</span>
                        </a>
                    <?php endif; ?>

                    <!-- GTranslate -->
                    <div class="gtranslate_wrapper">
                        <?php echo do_shortcode('[gtranslate]'); ?>
                    </div>
                </div>
                
            </div>
        </div>
    </header>
