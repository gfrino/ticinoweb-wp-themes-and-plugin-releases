<?php
/**
 * The template for displaying product content in the single-product.php template
 *
 * This overrides the standard WooCommerce layout for Monvél to create a premium, immersive experience.
 */

defined( 'ABSPATH' ) || exit;

global $product;

do_action( 'woocommerce_before_single_product' );

if ( post_password_required() ) {
	echo get_the_password_form(); // WPCS: XSS ok.
	return;
}
?>

<div id="product-<?php the_ID(); ?>" <?php wc_product_class( 'mv-custom-single-product', $product ); ?>>

    <?php
    $attributes = $product->is_type('variable') ? $product->get_variation_attributes() : array();
    $color_attribute_name = '';
    
    foreach ($attributes as $key => $val) {
        if (strpos(strtolower($key), 'color') !== false || strpos(strtolower($key), 'colore') !== false) {
            $color_attribute_name = $key;
            break;
        }
    }
    ?>

    <div class="mv-single-product-layout">
        <!-- LEFT: Visual Area -->
        <div class="mv-single-left">
            <div class="mv-single-glow" id="mv-single-glow"></div>
            <div class="mv-single-image-wrapper">
                <?php
                $main_img_id = $product->get_image_id();
                $main_img_url = wp_get_attachment_image_url($main_img_id, 'full');
                if ($main_img_url) {
                    echo '<img src="' . esc_url($main_img_url) . '" alt="' . esc_attr($product->get_name()) . '" class="mv-single-main-img" id="mv-single-main-img">';
                }
                ?>
            </div>
            
            <div class="mv-single-gallery">
                <?php
                $attachment_ids = $product->get_gallery_image_ids();
                if ( $attachment_ids ) {
                    foreach ( $attachment_ids as $attachment_id ) {
                        $thumb_url = wp_get_attachment_image_url($attachment_id, 'thumbnail');
                        $full_url = wp_get_attachment_image_url($attachment_id, 'full');
                        echo '<div class="mv-gallery-thumb" data-full="' . esc_url($full_url) . '"><img src="' . esc_url($thumb_url) . '"></div>';
                    }
                }
                ?>
            </div>
        </div>

        <!-- RIGHT: Info Area -->
        <div class="mv-single-right">
            
            <div class="mv-single-badges">
                <span class="mv-badge">NEW DROP</span>
                <span class="mv-badge mv-badge-light">STREETWEAR ESSENTIAL</span>
                <?php if ( $product->is_in_stock() ) : ?>
                    <span class="mv-badge" style="background-color: #e6f4ea; color: #1e8e3e; border: 1px solid rgba(30, 142, 62, 0.3);">DISPONIBILE</span>
                <?php else : ?>
                    <span class="mv-badge" style="background-color: #fce8e6; color: #d93025; border: 1px solid rgba(217, 48, 37, 0.3);">ESAURITO</span>
                <?php endif; ?>
            </div>
            
            <?php
            // Title
            $clean_name = preg_replace('/(?i)\s*\((copia|bozza|test)\).*/', '', $product->get_name());
            echo '<h1 class="mv-single-title">' . esc_html($clean_name) . '</h1>';
            
            // Price
            echo '<div class="mv-single-price" id="mv-single-price">' . $product->get_price_html() . '</div>';
            
            // Short Desc
            if ( $product->get_short_description() ) {
                echo '<div class="mv-single-desc">' . wp_strip_all_tags($product->get_short_description()) . '</div>';
            }
            
            // Custom Swatches UI
            if ($product->is_type('variable') && !empty($color_attribute_name)) {
                $color_options = $attributes[$color_attribute_name];
                
                // Reorder color options to match the backend variations order
                $ordered_options = array();
                $availability_map = array();
                $variation_ids = $product->get_children(); // Get all variations, even without prices
                foreach ($variation_ids as $var_id) {
                    $variation = wc_get_product($var_id);
                    if ($variation) {
                        $var_attrs = $variation->get_attributes();
                        $attr_key = strtolower('pa_colore'); // WooCommerce stores them as lowercase slugs
                        // But wait, $color_attribute_name might be pa_color or pa_colore
                        $attr_key = strtolower($color_attribute_name);
                        
                        if (isset($var_attrs[$attr_key])) {
                            $val = $var_attrs[$attr_key];
                            if ($val && !in_array($val, $ordered_options)) {
                                $ordered_options[] = $val;
                                
                                // Check availability
                                $thumb_id = get_post_meta($var_id, '_thumbnail_id', true);
                                $gallery_ids = get_post_meta($var_id, '_monvel_variation_gallery_images', true);
                                $availability_map[$val] = (!empty($thumb_id) && !empty($gallery_ids));
                            }
                        }
                    }
                }
                // Add any missing colors that weren't in variations
                foreach ($color_options as $opt) {
                    if (!in_array($opt, $ordered_options)) {
                        $ordered_options[] = $opt;
                        $availability_map[$opt] = false;
                    }
                }
                $color_options = $ordered_options;
                
                echo '<div class="mv-single-swatches-container">';
                echo '<div class="mv-single-color-label-top">Scegli la tua variante</div>';
                echo '<div class="mv-single-swatches">';
                
                foreach ($color_options as $option) {
                    $term = get_term_by('slug', $option, $color_attribute_name);
                    $name = $term ? $term->name : ucfirst($option);
                    // Use centralized color mapping logic
                    $color_data = function_exists('monvel_get_color_data') ? monvel_get_color_data($name) : array('is_dual' => false, 'color1' => '#111111', 'color2' => '#111111');
                    
                    $extra_class = $color_data['is_dual'] ? ' is-dual-color' : '';
                    
                    // Check availability
                    $is_available = isset($availability_map[$option]) ? $availability_map[$option] : false;
                    if (!$is_available) {
                        $extra_class .= ' disabled';
                    }
                    
                    $tooltip_attr = !$is_available ? ' data-tooltip="Colore presto disponibile"' : '';
                    
                    $inline_style = $color_data['is_dual'] ? 'style="--monvel-swatch-color-1: ' . esc_attr($color_data['color1']) . '; --monvel-swatch-color-2: ' . esc_attr($color_data['color2']) . ';"' : 'style="background-color: ' . esc_attr($color_data['color1']) . ';"';
                    $glow_bg = $color_data['is_dual'] ? 'linear-gradient(90deg, ' . $color_data['color1'] . ' 0%, ' . $color_data['color2'] . ' 100%)' : $color_data['color1'];

                    echo '<button type="button" class="mv-swatch mv-swatch-single' . esc_attr($extra_class) . '" data-value="' . esc_attr($option) . '" data-attribute="' . esc_attr('attribute_' . $color_attribute_name) . '" data-name="' . esc_attr($name) . '" data-glow-bg="' . esc_attr($glow_bg) . '" ' . $tooltip_attr . ' ' . $inline_style . ' aria-label="Colore ' . esc_attr($name) . '">';
                    echo '<span class="mv-swatch-ring" style="border-color: ' . esc_attr($color_data['color1']) . ';"></span>';
                    echo '</button>';
                }
                
                echo '</div>';
                echo '<div class="mv-single-color-label-bottom">Variante selezionata: <span id="mv-active-color-text">Nessuna</span></div>';
                echo '</div>';
            }
            
            // Standard WooCommerce Form (Hidden)
            echo '<div class="mv-hidden-wc-form" style="display:none;">';
            woocommerce_template_single_add_to_cart();
            echo '</div>';
            // Custom Add To Cart Block
            if ( class_exists('Monvel_Product_Addons') ) {
                Monvel_Product_Addons::display_frontend_addons( $product->get_id() );
            }
            
            echo '<div class="mv-single-cta-wrapper">';
            $btn_text = $product->is_type('variable') ? 'Seleziona un colore' : 'Aggiungi al carrello';
            $btn_class = $product->is_type('variable') ? 'mv-btn-add-to-cart disabled' : 'mv-btn-add-to-cart';
            echo '<button type="button" class="' . esc_attr($btn_class) . '" id="mv-custom-add-to-cart">';
            echo '<span class="mv-cta-text">' . esc_html($btn_text) . '</span>';
            echo '</button>';
            echo '<div class="mv-cta-microtext"><span>✓ Disponibile</span><span>✓ Spedizione rapida</span><span>✓ Taglia unica regolabile</span></div>';
            echo '</div>';
            
            // Attributes list (Static text)
            echo '<div class="mv-single-attributes-list">';
            $all_attrs = $product->get_attributes();
            foreach ($all_attrs as $attr_slug => $attr) {
                if ($attr_slug === $color_attribute_name) continue; // Skip color as it's handled above
                
                $name = wc_attribute_label($attr_slug);
                $val_text = '';
                
                if ($attr->is_taxonomy()) {
                    $terms = wc_get_product_terms($product->get_id(), $attr->get_name(), array('fields' => 'names'));
                    $val_text = $terms ? implode(', ', $terms) : '';
                } else {
                    $val_text = implode(', ', $attr->get_options());
                }
                
                if (!empty($val_text)) {
                    echo '<div class="mv-attr-row"><span class="mv-attr-name">' . esc_html($name) . '</span><span class="mv-attr-val">' . esc_html($val_text) . '</span></div>';
                }
            }
            echo '</div>';
            ?>
        </div>
    </div>
</div>

<?php
// ============================================================================
// PREMIUM RELATED PRODUCT SECTION ("Scopri anche")
// ============================================================================
$related_args = array(
    'post_type' => 'product',
    'post_status' => 'publish',
    'post__not_in' => array($product->get_id()),
    'posts_per_page' => 1
);
$related_query = new WP_Query($related_args);

if ($related_query->have_posts()) {
    $related_query->the_post();
    $related_product = wc_get_product(get_the_ID());
    $related_name = preg_replace('/(?i)\s*\((copia|bozza|test)\).*/', '', $related_product->get_name());
    $related_desc = $related_product->get_short_description() ? wp_strip_all_tags($related_product->get_short_description()) : 'Un\'altra forma, lo stesso carattere.';
    $related_img_id = $related_product->get_image_id();
    $related_img_url = wp_get_attachment_image_url($related_img_id, 'full');
    $related_link = get_permalink();
    ?>
    <div class="mv-related-section">
        <!-- Looping Background Element -->
        <div class="mv-related-bg-loop">
            <span>MONVÉL ESSENTIALS &nbsp;&nbsp;&nbsp; MONVÉL ESSENTIALS &nbsp;&nbsp;&nbsp; MONVÉL ESSENTIALS &nbsp;&nbsp;&nbsp; MONVÉL ESSENTIALS &nbsp;&nbsp;&nbsp; MONVÉL ESSENTIALS &nbsp;&nbsp;&nbsp; MONVÉL ESSENTIALS &nbsp;&nbsp;&nbsp; MONVÉL ESSENTIALS &nbsp;&nbsp;&nbsp; MONVÉL ESSENTIALS</span>
        </div>
        
        <div class="mv-related-container">
            <div class="mv-related-left">
                <div class="mv-related-eyebrow">Scopri anche</div>
                <h2 class="mv-related-title"><?php echo esc_html($related_name); ?></h2>
                <div class="mv-related-desc"><?php echo esc_html($related_desc); ?></div>
                <a href="<?php echo esc_url($related_link); ?>" class="mv-related-btn">Scopri il prodotto</a>
            </div>
            <div class="mv-related-right">
                <div class="mv-related-glow"></div>
                <div class="mv-related-image-wrapper">
                    <?php if ($related_img_url) : ?>
                        <img src="<?php echo esc_url($related_img_url); ?>" alt="<?php echo esc_attr($related_name); ?>" class="mv-related-img">
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    <?php
    wp_reset_postdata();
    // Restore global product
    global $post;
    $product = wc_get_product($post->ID);
}
?>

<?php do_action( 'woocommerce_after_single_product' ); ?>
