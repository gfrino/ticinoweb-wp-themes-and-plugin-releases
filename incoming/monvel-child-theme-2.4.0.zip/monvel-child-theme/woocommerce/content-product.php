<?php
/**
 * The template for displaying product content within loops
 */

defined( 'ABSPATH' ) || exit;

global $product;

// Ensure visibility.
if ( empty( $product ) || ! $product->is_visible() ) {
    return;
}

// 1. Get Product Name & Set Microcopy
$product_name = esc_html( $product->get_name() );
$microcopy = "Dettagli iconici. Stile assoluto.";
$panel_class = '';
if ( stripos($product_name, 'Curve') !== false ) {
    $microcopy = "Linee pulite. Presenza immediata.";
    $panel_class = 'mv-panel-curve';
} elseif ( stripos($product_name, 'Snap') !== false ) {
    $microcopy = "Forma decisa. Carattere urbano.";
    $panel_class = 'mv-panel-snap';
}

// 2. Fetch Default Image
$default_img_id = $product->get_image_id();
$default_img_url = wp_get_attachment_image_url($default_img_id, 'full');

// Get current loop index for Modello 01 / 02
global $woocommerce_loop;
$loop_index = isset($woocommerce_loop['loop']) ? $woocommerce_loop['loop'] + 1 : 1;
$modello_num = str_pad($loop_index, 2, '0', STR_PAD_LEFT);

// 3. Handle Variations (Colors)
$swatches_html = '';
$has_swatches = false;

// Simple color map to Hex for Monvél
$color_map = [
    'nero' => '#222222',
    'black' => '#222222',
    'navy' => '#1a233a',
    'blu' => '#1a233a',
    'verde' => '#4a5d43',
    'green' => '#4a5d43',
    'beige' => '#d8d3c9',
    'panna' => '#f2efe9',
    'rosa' => '#e2c5c5',
    'pink' => '#e2c5c5',
    'bianco' => '#ffffff',
    'white' => '#ffffff'
];

if ( $product->is_type( 'variable' ) ) {
        $variation_ids = $product->get_children();
        $variations_data = array();
        foreach ($variation_ids as $vid) {
            $var_obj = wc_get_product($vid);
            if ($var_obj) {
                $thumb_id = get_post_meta($vid, '_thumbnail_id', true);
                $gallery_ids = get_post_meta($vid, '_monvel_variation_gallery_images', true);
                $is_available = (!empty($thumb_id) && !empty($gallery_ids));
                
                $variations_data[] = array(
                    'attributes' => $var_obj->get_attributes(),
                    'image_url' => $thumb_id ? wp_get_attachment_image_url($thumb_id, 'full') : '',
                    'is_available' => $is_available
                );
            }
        }
        
        if ( ! empty( $variations_data ) ) {
            $has_swatches = true;
            
            $active_index = 0;
            
            // 1. Try to find the variation whose image matches the parent featured image
            $found_match = false;
            foreach ( $variations_data as $idx => $variation ) {
                if ($variation['is_available'] && $variation['image_url'] === $default_img_url) {
                    $active_index = $idx;
                    $found_match = true;
                    break;
                }
            }
            
            // 2. If no match, find the first available variation
            if (!$found_match) {
                foreach ( $variations_data as $idx => $variation ) {
                    if ($variation['is_available']) {
                        $active_index = $idx;
                        break;
                    }
                }
            }

            foreach ( $variations_data as $index => $variation ) {
                // Find color attribute
                $color_val = '';
                foreach($variation['attributes'] as $key => $val) {
                    if (strpos($key, 'color') !== false || strpos($key, 'colore') !== false) {
                        $color_val = $val;
                        break;
                    }
                }
                if(empty($color_val)) {
                    $color_val = reset($variation['attributes']);
                }
                
                $clean_color_name = ucfirst(str_replace('-', ' ', $color_val));
                $color_data = function_exists('monvel_get_color_data') ? monvel_get_color_data($color_val) : array('is_dual' => false, 'color1' => '#cccccc', 'color2' => '#cccccc');
                $hex = $color_data['color1'];

                // Get image for this variation
                $var_img_url = !empty($variation['image_url']) ? $variation['image_url'] : $default_img_url;
                
                $active_class = ($index === $active_index) ? 'active' : '';
                if($index === $active_index) {
                    $default_img_url = $var_img_url; // Set default loaded image
                }

                $extra_class = $color_data['is_dual'] ? ' is-dual-color' : '';
                if (!$variation['is_available']) {
                    $extra_class .= ' disabled';
                }
                
                $tooltip_attr = !$variation['is_available'] ? ' data-tooltip="Colore presto disponibile"' : '';
                
                $inline_style = $color_data['is_dual'] ? 'style="--monvel-swatch-color-1: ' . esc_attr($color_data['color1']) . '; --monvel-swatch-color-2: ' . esc_attr($color_data['color2']) . ';"' : 'style="background-color: ' . esc_attr($hex) . ';"';

                $swatches_html .= sprintf(
                    '<button type="button" class="mv-swatch %s" data-img-url="%s" data-color-hex="%s" data-color-name="%s" %s %s aria-label="%s"></button>',
                    $active_class . $extra_class,
                    esc_url($var_img_url),
                    esc_attr($hex),
                    esc_attr($clean_color_name),
                    $tooltip_attr,
                    $inline_style,
                    esc_attr($clean_color_name)
                );
            }
    }
}
?>

<li id="product-<?php echo esc_attr(sanitize_title($product_name)); ?>" <?php wc_product_class( 'mv-collection-panel ' . $panel_class, $product ); ?>>
    
    <a href="<?php echo esc_url( $product->get_permalink() ); ?>" class="mv-panel-link">
        
        <!-- Top Image Area -->
        <div class="mv-panel-image-area">
            <!-- Animated Glow Orb behind the product -->
            <div class="mv-panel-glow" style="background: radial-gradient(circle, rgba(200,200,200,0.15) 0%, rgba(255,255,255,0) 70%);"></div>
            
            <!-- Background overlay (noise/soft gradient) -->
            <div class="mv-panel-bg-overlay"></div>

            <div class="mv-panel-eyebrow-wrapper">
                <span class="mv-panel-eyebrow">MODELLO <?php echo $modello_num; ?></span>
            </div>

            <!-- Main Product Image -->
            <div class="mv-panel-image-wrapper">
                <img src="<?php echo esc_url($default_img_url); ?>" alt="<?php echo esc_attr($product_name); ?>" class="mv-panel-main-img">
            </div>
        </div>

        <!-- Bottom Info Area -->
        <div class="mv-panel-info-area">
            <div class="mv-panel-text-block">
                <h2 class="mv-panel-title"><?php echo $product_name; ?></h2>
                <p class="mv-panel-microcopy"><?php echo $microcopy; ?></p>
            </div>
            
            <div class="mv-panel-action-block">
                <?php if($has_swatches): ?>
                <div class="mv-panel-swatches-wrapper" onclick="event.preventDefault();">
                    <span class="mv-panel-color-label">Varianti colore</span>
                    <div class="mv-panel-swatches">
                        <?php echo $swatches_html; ?>
                    </div>
                </div>
                <?php endif; ?>

                <div class="mv-panel-cta-wrapper">
                    <span class="mv-panel-cta">Scopri il prodotto <span class="mv-panel-cta-arrow">&rarr;</span></span>
                </div>
            </div>
        </div>

    </a>
</li>
