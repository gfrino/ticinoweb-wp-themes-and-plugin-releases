<?php
/**
 * My Account Dashboard
 *
 * Shows the first intro screen on the account dashboard.
 *
 * @see     https://woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 4.4.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

$current_user = wp_get_current_user();
?>

<div class="mv-account-dashboard">
    <div class="mv-dashboard-header">
        <h2 class="mv-dashboard-title"><?php echo esc_html( sprintf( __( 'Ciao, %s', 'monvel-child-theme' ), $current_user->display_name ) ); ?></h2>
        <p class="mv-dashboard-subtitle"><?php _e( 'Da qui puoi gestire ordini, indirizzi e dettagli del tuo account Monvél.', 'monvel-child-theme' ); ?></p>
    </div>

    <div class="mv-dashboard-cards">
        <a href="<?php echo esc_url( wc_get_endpoint_url( 'orders' ) ); ?>" class="mv-dashboard-card">
            <div class="mv-card-icon">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M20 16.58A5 5 0 0 0 18 7h-1.26A8 8 0 1 0 4 15.25"></path><path d="m7 21 5-5 5 5"></path><path d="m12 16v6"></path></svg>
            </div>
            <h3><?php _e( 'I miei ordini', 'monvel-child-theme' ); ?></h3>
            <p><?php _e( 'Visualizza e traccia i tuoi ordini recenti.', 'monvel-child-theme' ); ?></p>
        </a>

        <a href="<?php echo esc_url( wc_get_endpoint_url( 'edit-address' ) ); ?>" class="mv-dashboard-card">
            <div class="mv-card-icon">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path><circle cx="12" cy="10" r="3"></circle></svg>
            </div>
            <h3><?php _e( 'Indirizzi', 'monvel-child-theme' ); ?></h3>
            <p><?php _e( 'Gestisci indirizzi di fatturazione e spedizione.', 'monvel-child-theme' ); ?></p>
        </a>

        <a href="<?php echo esc_url( wc_get_endpoint_url( 'edit-account' ) ); ?>" class="mv-dashboard-card">
            <div class="mv-card-icon">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>
            </div>
            <h3><?php _e( 'Dettagli account', 'monvel-child-theme' ); ?></h3>
            <p><?php _e( 'Modifica password e dati personali.', 'monvel-child-theme' ); ?></p>
        </a>

        <a href="<?php echo esc_url( home_url( '/contatti' ) ); ?>" class="mv-dashboard-card">
            <div class="mv-card-icon">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path></svg>
            </div>
            <h3><?php _e( 'Assistenza', 'monvel-child-theme' ); ?></h3>
            <p><?php _e( 'Hai bisogno di aiuto? Contattaci.', 'monvel-child-theme' ); ?></p>
        </a>
    </div>
</div>

<?php
	/**
	 * My Account dashboard.
	 *
	 * @since 2.6.0
	 */
	do_action( 'woocommerce_account_dashboard' );

	/**
	 * Deprecated woocommerce_before_my_account action.
	 *
	 * @deprecated 2.6.0
	 */
	do_action( 'woocommerce_before_my_account' );

	/**
	 * Deprecated woocommerce_after_my_account action.
	 *
	 * @deprecated 2.6.0
	 */
	do_action( 'woocommerce_after_my_account' );
