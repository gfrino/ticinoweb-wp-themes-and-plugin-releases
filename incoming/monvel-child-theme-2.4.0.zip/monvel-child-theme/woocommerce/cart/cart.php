<?php
/**
 * Cart Page Override
 *
 * @package WooCommerce\Templates
 * @version 10.8.0
 */

defined( 'ABSPATH' ) || exit;

// Intestazione Minimal Monvél
?>
<div class="mv-cart-experience">
    
    <div class="mv-cart-header">
        <div class="mv-cart-header-left">
            <h1 class="mv-cart-title">CARRELLO</h1>
            <p class="mv-cart-subtitle">Il tuo drop Monvél è quasi pronto.</p>
        </div>
    </div>

    <?php do_action( 'woocommerce_before_cart' ); ?>

    <form class="woocommerce-cart-form" action="<?php echo esc_url( wc_get_cart_url() ); ?>" method="post">
        <?php do_action( 'woocommerce_before_cart_table' ); ?>

        <div class="mv-cart-layout">
            
            <!-- Colonna Sinistra: Prodotti -->
            <div class="mv-cart-items">
                <?php do_action( 'woocommerce_before_cart_contents' ); ?>

                <?php
                foreach ( WC()->cart->get_cart() as $cart_item_key => $cart_item ) {
                    $_product   = apply_filters( 'woocommerce_cart_item_product', $cart_item['data'], $cart_item, $cart_item_key );
                    $product_id = apply_filters( 'woocommerce_cart_item_product_id', $cart_item['product_id'], $cart_item, $cart_item_key );

                    if ( $_product && $_product->exists() && $cart_item['quantity'] > 0 && apply_filters( 'woocommerce_cart_item_visible', true, $cart_item, $cart_item_key ) ) {
                        $product_permalink = apply_filters( 'woocommerce_cart_item_permalink', $_product->is_visible() ? $_product->get_permalink( $cart_item ) : '', $cart_item, $cart_item_key );
                        ?>
                        <div class="woocommerce-cart-form__cart-item <?php echo esc_attr( apply_filters( 'woocommerce_cart_item_class', 'cart_item', $cart_item, $cart_item_key ) ); ?>">
                            
                            <div class="mv-cart-item">
                                <!-- Immagine -->
                                <div class="mv-ci-image">
                                    <?php
                                    $thumbnail = apply_filters( 'woocommerce_cart_item_thumbnail', $_product->get_image('woocommerce_thumbnail'), $cart_item, $cart_item_key );
                                    if ( ! $product_permalink ) {
                                        echo $thumbnail;
                                    } else {
                                        printf( '<a href="%s">%s</a>', esc_url( $product_permalink ), $thumbnail );
                                    }
                                    ?>
                                </div>

                                <!-- Dettagli -->
                                <div class="mv-ci-details">
                                    
                                    <div class="mv-ci-header">
                                        <div class="mv-ci-title-price">
                                            <h3 class="mv-ci-name">
                                                <?php
                                                if ( ! $product_permalink ) {
                                                    echo wp_kses_post( apply_filters( 'woocommerce_cart_item_name', $_product->get_name(), $cart_item, $cart_item_key ) . '&nbsp;' );
                                                } else {
                                                    echo wp_kses_post( apply_filters( 'woocommerce_cart_item_name', sprintf( '<a href="%s">%s</a>', esc_url( $product_permalink ), $_product->get_name() ), $cart_item, $cart_item_key ) );
                                                }
                                                ?>
                                            </h3>
                                        </div>

                                        <!-- Meta (Attributi limitati via CSS) -->
                                        <div class="mv-ci-meta">
                                            <?php echo wc_get_formatted_cart_item_data( $cart_item ); ?>
                                        </div>

                                        <div class="mv-ci-price">
                                            <?php echo apply_filters( 'woocommerce_cart_item_price', WC()->cart->get_product_price( $_product ), $cart_item, $cart_item_key ); ?>
                                        </div>
                                    </div>

                                    <!-- Azioni (QTY + Rimuovi + Subtotale) -->
                                    <div class="mv-ci-actions">
                                        
                                        <!-- Quantità -->
                                        <div class="mv-qty-wrapper">
                                            <button type="button" class="mv-qty-btn mv-qty-minus">-</button>
                                            <?php
                                            if ( $_product->is_sold_individually() ) {
                                                $min_quantity = 1;
                                                $max_quantity = 1;
                                            } else {
                                                $min_quantity = 0;
                                                $max_quantity = $_product->get_max_purchase_quantity();
                                            }

                                            $product_quantity = woocommerce_quantity_input(
                                                array(
                                                    'input_name'   => "cart[{$cart_item_key}][qty]",
                                                    'input_value'  => $cart_item['quantity'],
                                                    'max_value'    => $max_quantity,
                                                    'min_value'    => $min_quantity,
                                                    'product_name' => $_product->get_name(),
                                                    'classes'      => apply_filters( 'woocommerce_quantity_input_classes', array( 'input-text', 'qty', 'text', 'mv-qty-input' ), $_product ),
                                                ),
                                                $_product,
                                                false
                                            );
                                            echo apply_filters( 'woocommerce_cart_item_quantity', $product_quantity, $cart_item_key, $cart_item );
                                            ?>
                                            <button type="button" class="mv-qty-btn mv-qty-plus">+</button>
                                        </div>

                                        <!-- Rimuovi -->
                                        <div class="mv-ci-remove">
                                            <?php
                                            echo apply_filters( 
                                                'woocommerce_cart_item_remove_link',
                                                sprintf(
                                                    '<a href="%s" class="remove" aria-label="%s" data-product_id="%s" data-product_sku="%s">Rimuovi</a>',
                                                    esc_url( wc_get_cart_remove_url( $cart_item_key ) ),
                                                    esc_html__( 'Remove this item', 'woocommerce' ),
                                                    esc_attr( $product_id ),
                                                    esc_attr( $_product->get_sku() )
                                                ),
                                                $cart_item_key
                                            );
                                            ?>
                                        </div>

                                        <!-- Subtotale Prodotto -->
                                        <div class="mv-ci-subtotal">
                                            <?php echo apply_filters( 'woocommerce_cart_item_subtotal', WC()->cart->get_product_subtotal( $_product, $cart_item['quantity'] ), $cart_item, $cart_item_key ); ?>
                                        </div>

                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                        <?php
                    }
                }
                ?>

                <?php do_action( 'woocommerce_cart_contents' ); ?>
                
                <!-- Azioni Nascoste (Aggiorna carrello di default) -->
                <div class="mv-cart-update-actions" style="display:none;">
                    <button type="submit" class="button" name="update_cart" value="<?php esc_attr_e( 'Update cart', 'woocommerce' ); ?>"><?php esc_html_e( 'Update cart', 'woocommerce' ); ?></button>
                    <?php do_action( 'woocommerce_cart_actions' ); ?>
                    <?php wp_nonce_field( 'woocommerce-cart', 'woocommerce-cart-nonce' ); ?>
                </div>

                <?php do_action( 'woocommerce_after_cart_contents' ); ?>
            </div>

            <!-- Colonna Destra: Sticky Sidebar -->
            <div class="mv-cart-sticky-box">
                <h3 class="mv-summary-title">RIEPILOGO</h3>

                <!-- Coupon (se abilitato) -->
                <?php if ( wc_coupons_enabled() ) { ?>
                    <div class="mv-cart-coupon-box">
                        <button type="button" class="mv-coupon-toggle">
                            Hai un codice?
                        </button>
                        <div class="mv-coupon-content">
                            <div class="mv-coupon-input-group">
                                <input type="text" name="coupon_code" class="input-text mv-coupon-input" id="coupon_code" value="" placeholder="<?php esc_attr_e( 'Codice promozionale', 'woocommerce' ); ?>" />
                                <button type="submit" class="button mv-coupon-btn" name="apply_coupon" value="<?php esc_attr_e( 'Applica', 'woocommerce' ); ?>"><?php esc_attr_e( 'Applica', 'woocommerce' ); ?></button>
                            </div>
                            <?php do_action( 'woocommerce_cart_coupon' ); ?>
                        </div>
                    </div>
                <?php } ?>

                <!-- Totali WooCommerce (Customizzati in cart-totals.php) -->
                <?php do_action( 'woocommerce_cart_collaterals' ); ?>

                <div class="mv-cart-secure-msg">
                    Checkout sicuro &middot; Pagamento protetto
                </div>
            </div>

        </div>

        <?php do_action( 'woocommerce_after_cart_table' ); ?>
    </form>

    <?php do_action( 'woocommerce_after_cart' ); ?>
</div>

<script>
// Micro-gestione Quantità (+/-) per scatenare l'aggiornamento
document.addEventListener('DOMContentLoaded', function() {
    const cartForm = document.querySelector('.woocommerce-cart-form');
    if (!cartForm) return;

    cartForm.addEventListener('click', function(e) {
        if (e.target.classList.contains('mv-qty-plus') || e.target.classList.contains('mv-qty-minus')) {
            e.preventDefault();
            const wrapper = e.target.closest('.mv-qty-wrapper');
            const input = wrapper.querySelector('.mv-qty-input');
            let val = parseFloat(input.value) || 0;
            const max = parseFloat(input.getAttribute('max'));
            const min = parseFloat(input.getAttribute('min')) || 0;
            const step = parseFloat(input.getAttribute('step')) || 1;

            if (e.target.classList.contains('mv-qty-plus')) {
                if (max && val >= max) return;
                input.value = val + step;
            } else {
                if (val <= min) return;
                input.value = val - step;
            }

            // Attiva l'evento change e abilita il pulsante di update nascosto
            const event = new Event('change', { bubbles: true });
            input.dispatchEvent(event);
            
            const updateBtn = document.querySelector('[name="update_cart"]');
            if (updateBtn) {
                updateBtn.removeAttribute('disabled');
                updateBtn.click(); // Autoupdate
            }
        }
    });

    // Accordion Coupon
    const couponToggle = document.querySelector('.mv-coupon-toggle');
    if (couponToggle) {
        couponToggle.addEventListener('click', function(e) {
            e.preventDefault();
            const box = this.closest('.mv-cart-coupon-box');
            box.classList.toggle('is-open');
        });
    }
});
</script>
