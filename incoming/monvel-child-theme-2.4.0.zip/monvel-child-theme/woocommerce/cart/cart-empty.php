<?php
/**
 * Empty cart page override
 *
 * @package WooCommerce\Templates
 * @version 7.0.1
 */

defined( 'ABSPATH' ) || exit;

// Remove the standard wc_empty_cart_message
remove_action( 'woocommerce_cart_is_empty', 'wc_empty_cart_message', 10 );
?>

<div class="mv-cart-empty-wrapper">
    <div class="mv-cart-empty-content">
        <h2 class="mv-cart-empty-title">IL TUO CARRELLO È VUOTO</h2>
        
        <p class="mv-cart-empty-text">
            Scegli il tuo cappello Monvél e completa il tuo drop.
        </p>

        <?php
        if ( wc_get_page_id( 'shop' ) > 0 ) :
            ?>
            <div class="mv-cart-empty-actions">
                <a class="mv-btn mv-btn-primary mv-str-btn" href="<?php echo esc_url( apply_filters( 'woocommerce_return_to_shop_redirect', wc_get_page_permalink( 'shop' ) ) ); ?>">
                    <span><?php esc_html_e( 'VAI ALLO SHOP', 'woocommerce' ); ?></span>
                </a>
            </div>
        <?php endif; ?>
    </div>
</div>
