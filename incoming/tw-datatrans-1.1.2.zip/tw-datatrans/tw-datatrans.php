<?php
/**
 * Plugin Name: Datatrans by ticinoWEB
 * Plugin URI: https://ticinoweb.com/
 * Description: Accetta TWINT, carte di credito e debito, Apple Pay e Google Pay sul tuo negozio WooCommerce con il tuo account Datatrans. Il cliente paga sulla pagina sicura di Datatrans e torna al sito con l'ordine confermato; i rimborsi si fanno dalla pagina dell'ordine.
 * Version: 1.1.2
 * Author: ticinoWEB
 * Author URI: https://ticinoweb.com/
 * Text Domain: tw-datatrans
 * Domain Path: /languages
 * Requires at least: 6.0
 * Requires PHP: 8.0
 * WC requires at least: 8.0
 * Update URI: https://github.com/gfrino/ticinoweb-wp-themes-and-plugin-releases
 */

defined( 'ABSPATH' ) || exit;

define( 'TW_DATATRANS_VERSION', '1.1.2' );
define( 'TW_DATATRANS_FILE', __FILE__ );
define( 'TW_DATATRANS_PATH', plugin_dir_path( __FILE__ ) );
define( 'TW_DATATRANS_URL', plugin_dir_url( __FILE__ ) );
// Version of the bundled includes/tw-release-updater.php (keep in sync with its header).
define( 'TW_DATATRANS_RELEASE_UPDATER_VERSION', '1.2.0' );

// Updates from the ticinoWEB releases repo (see the Update URI header).
require_once TW_DATATRANS_PATH . 'includes/tw-release-updater.php';

function tw_datatrans_install_release_updater() {
	if ( ! class_exists( 'TW_Release_Updater' ) || TW_Release_Updater::mu_is_current( TW_DATATRANS_RELEASE_UPDATER_VERSION ) ) {
		return;
	}
	if ( get_site_transient( 'tw_datatrans_release_updater_failed' ) ) {
		return;
	}
	$result = TW_Release_Updater::install_mu( TW_DATATRANS_PATH . 'includes/tw-release-updater.php' );
	if ( is_wp_error( $result ) ) {
		set_site_transient( 'tw_datatrans_release_updater_failed', $result->get_error_message(), 12 * HOUR_IN_SECONDS );
	}
}
add_action( 'admin_init', function () {
	if ( current_user_can( is_multisite() ? 'manage_network_plugins' : 'activate_plugins' ) ) {
		tw_datatrans_install_release_updater();
	}
}, 20 );

add_action( 'init', function () {
	load_plugin_textdomain( 'tw-datatrans', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
} );

// WooCommerce features: HPOS and the block checkout.
add_action( 'before_woocommerce_init', function () {
	if ( class_exists( \Automattic\WooCommerce\Utilities\FeaturesUtil::class ) ) {
		\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', __FILE__, true );
		\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'cart_checkout_blocks', __FILE__, true );
	}
} );

add_action( 'plugins_loaded', 'tw_datatrans_boot', 11 );
function tw_datatrans_boot() {
	if ( ! class_exists( 'WC_Payment_Gateway' ) ) {
		add_action( 'admin_notices', function () {
			echo '<div class="notice notice-error"><p>' . esc_html__( 'Datatrans by ticinoWEB needs WooCommerce to be active.', 'tw-datatrans' ) . '</p></div>';
		} );
		return;
	}
	require_once TW_DATATRANS_PATH . 'includes/class-tw-datatrans-settings.php';
	require_once TW_DATATRANS_PATH . 'includes/class-tw-datatrans-api.php';
	require_once TW_DATATRANS_PATH . 'includes/class-tw-datatrans-gateway.php';
	require_once TW_DATATRANS_PATH . 'includes/class-tw-datatrans-handlers.php';

	TW_Datatrans_Settings::init();
	TW_Datatrans_Handlers::init();

	add_filter( 'woocommerce_payment_gateways', function ( $gateways ) {
		foreach ( TW_Datatrans_Gateway::methods() as $class ) {
			$gateways[] = $class;
		}
		return $gateways;
	} );

	// Block checkout (WooCommerce Blocks).
	add_action( 'woocommerce_blocks_loaded', function () {
		if ( class_exists( \Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType::class ) ) {
			require_once TW_DATATRANS_PATH . 'includes/class-tw-datatrans-blocks.php';
			add_action( 'woocommerce_blocks_payment_method_type_registration', function ( $registry ) {
				foreach ( TW_Datatrans_Gateway::methods() as $id => $class ) {
					$registry->register( new TW_Datatrans_Blocks( $id ) );
				}
			} );
		}
	} );

	// "Impostazioni" link in the plugin list.
	add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), function ( $links ) {
		array_unshift( $links, '<a href="' . esc_url( admin_url( 'admin.php?page=tw-datatrans' ) ) . '">' . esc_html__( 'Settings', 'tw-datatrans' ) . '</a>' );
		return $links;
	} );
}

/** Logger shared by the plugin (WooCommerce → Stato → Log, source "tw-datatrans"). */
function tw_datatrans_log( $message, $level = 'info' ) {
	if ( ! function_exists( 'wc_get_logger' ) ) {
		return;
	}
	if ( 'yes' !== TW_Datatrans_Settings::get( 'log' ) && 'error' !== $level ) {
		return;
	}
	wc_get_logger()->log( $level, is_string( $message ) ? $message : wp_json_encode( $message ), array( 'source' => 'tw-datatrans' ) );
}
