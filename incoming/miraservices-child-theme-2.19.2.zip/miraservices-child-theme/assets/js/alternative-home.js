(() => {
 'use strict';
 const reduced=matchMedia('(prefers-reduced-motion: reduce)');
 const wide=matchMedia('(min-width: 900px)');
 const loader=document.querySelector('.alt-preload');
 const reveal=()=>{loader?.remove();document.body.classList.remove('alt-loading');document.body.classList.add('alt-ready');};
 if(reduced.matches||!loader)reveal();else{
  document.body.classList.add('alt-loading');
  const enter=()=>{
   if(!loader.isConnected)return;
   const word=loader.querySelector('.alt-preload__word'),target=document.querySelector('.alt-portal__ink');
   const from=word?.getBoundingClientRect(),to=target?.getBoundingClientRect();
   loader.querySelector('.alt-preload__name')?.animate([{opacity:1},{opacity:0}],{duration:180,fill:'forwards'});
   if(from&&to&&to.top>=0&&scrollY<100){
    const dx=to.left+to.width/2-from.left-from.width/2,dy=to.top+to.height/2-from.top-from.height/2;
    word.animate([{transform:'none',color:'#f1f3df'},{transform:`translate(${dx}px,${dy}px) scale(${to.width/from.width},${to.height/from.height})`,color:'#080bd2'}],{duration:750,easing:'cubic-bezier(.22,1,.36,1)',fill:'forwards'});
    loader.animate([{backgroundColor:'#080bd2'},{backgroundColor:'#f1f3df'}],{duration:500,fill:'forwards'});
   }
   loader.animate([{clipPath:'inset(0 0 0% 0)'},{clipPath:'inset(0 0 100% 0)'}],{duration:550,delay:400,easing:'cubic-bezier(.76,0,.24,1)',fill:'forwards'}).finished.then(reveal,reveal);
  };
  Promise.all([document.fonts?.ready||Promise.resolve(),new Promise(resolve=>setTimeout(resolve,750))]).then(enter);
  setTimeout(reveal,3000);
 }
 document.body.classList.add('alt-ui');
 document.body.classList.remove('alt-motion');
 document.querySelectorAll('.mira-header a[href],.mira-mobile-menu a[href],.mira-footer a[href]').forEach((link)=>{
  const url=new URL(link.href,location.href);
  if(url.origin===location.origin&&url.hash&&document.getElementById(url.hash.slice(1)))link.href=url.hash;
 });
 const story=document.querySelector('[data-alt-story]');
 const process=document.querySelector('[data-alt-process]');
 const portal=document.querySelector('[data-alt-portal]');
 const heroPhoto=document.querySelector('.alt-portal__landscape img');
 const storyCopy=document.querySelector('.alt-story__copy');
 const storyPhotos=[...document.querySelectorAll('.alt-story__photo')];
 const chapters=[...document.querySelectorAll('[data-alt-chapter]')];
 const chapterPhotos=chapters.map((el)=>el.querySelector('.alt-chapter__photo img'));
 const chapterCopies=chapters.map((el)=>el.querySelector('.alt-chapter__copy'));
 const galleryCount=document.querySelector('[data-alt-gallery-current]');
 const phases=[...document.querySelectorAll('[data-alt-process-step]')];
 const phasePhotos=[...document.querySelectorAll('[data-alt-process-photo]')];
 const phaseButtons=[...document.querySelectorAll('[data-alt-process-jump]')];
 const reading=document.querySelector('[data-alt-reading]');
 const words=[];
 if(reading){const text=reading.textContent.trim().split(/\s+/);reading.replaceChildren();text.forEach((word,index)=>{const span=document.createElement('span');span.textContent=word;words.push(span);reading.append(span);if(index<text.length-1)reading.append(document.createTextNode(' '));});}
 const reveals=[
  ['.alt-gallery__heading',-80,30,1],['.alt-directory__heading',-100,40,.98],['.alt-directory__body',85,60,.97],
  ['.alt-process__visual',-100,0,1.06],['.alt-process__copy',70,20,1],
  ['.alt-urgent__photo',-130,50,1.1],['.alt-urgent__copy',130,60,.97],
  ['.alt-connect__intro',-65,30,1],['.alt-connect__channels',65,30,1],
 ].map(([selector,x,y,scale])=>({element:document.querySelector(selector),x,y,scale,top:0})).filter((item)=>item.element);
 chapters.forEach((element,i)=>reveals.push({element,x:i%2?110:-110,y:55,scale:.98,top:0}));
 let cinematic=false,lenis=null,bounds={},chapterBounds=[],phaseCenters=[];
 let frameId=null,lastTime=0,dirty=true,cameraY=scrollY,chapterIndex=-1,phaseIndex=-1,menuOpen=false;
 const clamp=(value)=>Math.max(0,Math.min(1,value));
 const ease=(value)=>1-(1-value)**3;
 const headerHeight=()=>document.querySelector('[data-mira-header]')?.getBoundingClientRect().bottom||(innerWidth<1100?70:88);
 const entrance=(top)=>ease(clamp((cameraY+innerHeight-top)/(innerHeight*.9)));
 const setChapter=(index)=>{
  if(index===chapterIndex)return;chapterIndex=index;
  if(galleryCount)galleryCount.textContent=String(index+1).padStart(2,'0');
 };
 const setPhase=(index)=>{
  if(index===phaseIndex)return;phaseIndex=index;
  phases.forEach((el,i)=>el.classList.toggle('is-current',i===index));
  phaseButtons.forEach((button,i)=>{if(i===index)button.setAttribute('aria-current','step');else button.removeAttribute('aria-current');});
 };
 const paint=()=>{
  const center=cameraY+innerHeight*.55;
  if(chapterBounds.length){let closest=0;chapterBounds.forEach((item,i)=>{if(Math.abs(center-item.center)<Math.abs(center-chapterBounds[closest].center))closest=i;});setChapter(closest);}
  if(!cinematic)return;
  const amplitude=wide.matches?1:.35;
  reveals.forEach(({element,x,y,scale,top})=>{const rest=1-entrance(top);element.style.transform=`translate3d(${x*rest*amplitude}px,${y*rest*amplitude}px,0) scale(${1+(scale-1)*rest})`;});
  // The photographic aperture opens as the real hero leaves the viewport. No pin or spacer.
  if(portal&&cameraY<(bounds.portal?.height||1000)+innerHeight){
   const p=clamp(cameraY/Math.max(280,(bounds.portal?.height||800)*.9));
   const opening=clamp((p-.18)/.62),aperture=opening*opening*(3-2*opening);
   const tone=ease(clamp((p-.27)/.14));
   portal.style.setProperty('--portal-ink',String(1-ease(clamp(p/.18))));
   portal.style.setProperty('--portal-zoom',String(1+aperture*aperture*9));
   portal.style.setProperty('--portal-veil',String(1-ease(clamp((p-.28)/.32))));
   portal.style.setProperty('--portal-outline',String(ease(clamp(p/.035))*(1-ease(clamp((p-.55)/.2)))));
   portal.style.setProperty('--portal-trace',String(1600*(1-clamp(p/.28))));
   portal.style.setProperty('--portal-dash',p>=.28?'none':'1600');
   portal.style.setProperty('--portal-shade',String(tone));
   const start=[8,11,210],end=[241,243,223];
   portal.style.setProperty('--portal-color',`rgb(${start.map((v,i)=>Math.round(v+(end[i]-v)*tone)).join(',')})`);
   if(heroPhoto)heroPhoto.style.transform=`scale(${1.1-.1*aperture})`;
  }
  if(bounds.story){
   const sp=clamp((cameraY+innerHeight*.75-bounds.story.top)/(bounds.story.height+innerHeight*.15));
   const entry=entrance(bounds.story.top);
   if(storyCopy)storyCopy.style.transform=`translate3d(${-55*(1-entry)*amplitude}px,${20*(1-entry)}px,0)`;
   storyPhotos.forEach((el,i)=>{const rest=1-ease(sp);el.style.transform=`translate3d(${([130,-150,145][i]||0)*rest*amplitude}px,${([45,90,-65][i]||0)*rest*amplitude}px,0) rotate(${[2,-4,3][i]*rest*amplitude}deg) scale(${.92+.08*ease(sp)})`;});
   words.forEach((word,i)=>{word.style.opacity=String(.65+.35*clamp((entry*.8+sp*.4)*words.length-i));});
  }
  chapterBounds.forEach((item,i)=>{
   const relative=Math.max(-1,Math.min(1,(center-item.center)/item.height));
   if(chapterPhotos[i])chapterPhotos[i].style.transform=`translate3d(0,${-relative*55*amplitude}px,0) scale(${wide.matches?1.17:1.08})`;
   if(chapterCopies[i])chapterCopies[i].style.transform=`translate3d(${(i%2?1:-1)*50*(1-entrance(item.top))*amplitude}px,${relative*14}px,0)`;
  });
  if(phaseCenters.length&&process){
   const pp=clamp((center-phaseCenters[0])/Math.max(1,phaseCenters[phaseCenters.length-1]-phaseCenters[0]));
   const position=pp*(phases.length-1);setPhase(Math.round(position));
   process.style.setProperty('--process-progress',String(.1+.9*pp));
   phasePhotos.forEach((el,i)=>{const relative=i-position,distance=Math.abs(relative);el.style.opacity=String(clamp(1-distance));el.style.transform=`translate3d(${Math.max(-1,Math.min(1,relative))*25}px,0,0) scale(1.12)`;});
  }
 };
 const frame=(time)=>{
  frameId=null;if(document.hidden)return;lenis?.raf(time);
  const dt=lastTime?Math.min(64,time-lastTime):16;lastTime=time;
  const difference=scrollY-cameraY;
  cameraY=Math.abs(difference)<.08?scrollY:cameraY+difference*(1-Math.exp(-dt/65));
  if(dirty||Math.abs(difference)>.03){paint();dirty=false;}
  if(lenis||Math.abs(scrollY-cameraY)>.08)requestFrame();
 };
 function requestFrame(){if(frameId===null&&!document.hidden)frameId=requestAnimationFrame(frame);}
 const requestPaint=()=>{dirty=true;requestFrame();};
 const measure=()=>{
  cinematic=!reduced.matches;
  document.body.classList.remove('alt-motion');
  document.body.classList.toggle('alt-cinematic',cinematic);
  portal?.querySelectorAll('.alt-portal__type').forEach(el=>el.setAttribute('y',cinematic?String(innerWidth*.23+(innerWidth<900?25:30)):'85%'));
  const wantsSmooth=wide.matches&&cinematic&&typeof window.Lenis==='function';
  if(wantsSmooth&&!lenis)lenis=new window.Lenis({autoRaf:false,lerp:.12,wheelMultiplier:1,syncTouch:false,smoothWheel:true,prevent:(node)=>!!node.closest?.('.mira-mobile-menu,.mira-mega,textarea,select,[data-lenis-prevent]')});
  if(!wantsSmooth&&lenis){lenis.destroy();lenis=null;}
  reveals.forEach(({element})=>{element.style.transform='';});
  bounds={};
  [['story',story],['process',process],['portal',portal]].forEach(([key,element])=>{if(element)bounds[key]={top:element.getBoundingClientRect().top+scrollY,height:element.offsetHeight};});
  reveals.forEach((item)=>{item.top=item.element.getBoundingClientRect().top+scrollY;});
  chapterBounds=chapters.map((el)=>{const top=el.getBoundingClientRect().top+scrollY,height=el.offsetHeight;return{top,height,center:top+height*.5};});
  phaseCenters=phases.map((el)=>el.getBoundingClientRect().top+scrollY+el.offsetHeight*.5);
  if(!cinematic){
   ['--portal-ink','--portal-zoom','--portal-veil','--portal-shade','--portal-color','--portal-outline','--portal-trace','--portal-dash'].forEach(key=>portal?.style.removeProperty(key));
   [storyCopy,heroPhoto,...storyPhotos,...words,...chapterPhotos,...chapterCopies,...phasePhotos].filter(Boolean).forEach((el)=>{el.style.transform='';el.style.opacity='';});
   reveals.forEach(({element})=>{element.style.transform='';});
   phasePhotos.forEach((el,i)=>el.classList.toggle('is-current',i===0));
  }
  lenis?.resize();cameraY=scrollY;requestPaint();
 };
 const scrollTo=(top,immediate=false)=>{
  if(lenis)lenis.scrollTo(top,{duration:1.05,lerp:0,easing:(t)=>1-(1-t)**4,immediate});
  else window.scrollTo({top,behavior:reduced.matches||immediate?'instant':'smooth'});
  if(immediate){cameraY=top;requestPaint();}
 };
 window.miraAlternativeScrollTo=(target)=>scrollTo(target.getBoundingClientRect().top+scrollY-headerHeight());
 phaseButtons.forEach((button,i)=>button.addEventListener('click',()=>{
  const row=phases[i];if(row)scrollTo(row.getBoundingClientRect().top+scrollY-headerHeight()-25);setPhase(i);
 }));
 const directoryItems=[...document.querySelectorAll('[data-alt-directory-item]')],directoryPhotos=[...document.querySelectorAll('[data-alt-directory-preview]')];
 directoryItems.forEach((item,index)=>{const select=()=>{directoryItems.forEach((el,i)=>el.classList.toggle('is-current',i===index));directoryPhotos.forEach((el,i)=>el.classList.toggle('is-current',i===index));};item.addEventListener('pointerenter',select);item.addEventListener('focus',select);});
 new MutationObserver(()=>{const open=document.body.classList.contains('mira-menu-open')||document.body.classList.contains('mira-showroom-open');if(open!==menuOpen){menuOpen=open;if(menuOpen)lenis?.stop();else lenis?.start();}}).observe(document.body,{attributes:true,attributeFilter:['class']});
 window.addEventListener('scroll',requestPaint,{passive:true});window.addEventListener('resize',measure,{passive:true});
 reduced.addEventListener('change',measure);wide.addEventListener('change',measure);
 document.addEventListener('visibilitychange',()=>{lastTime=0;requestPaint();});window.addEventListener('pageshow',measure);
 window.addEventListener('pagehide',()=>{if(frameId!==null)cancelAnimationFrame(frameId);frameId=null;});
 if(document.fonts)document.fonts.ready.then(measure);measure();
})();
