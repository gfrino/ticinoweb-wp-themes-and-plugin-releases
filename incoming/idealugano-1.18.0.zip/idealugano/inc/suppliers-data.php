<?php
/**
 * Seme degli elenchi di fornitori: sistemi per tende, editori tessili,
 * passamanerie. Elenchi forniti dal cliente (Monica, ottobre 2026).
 *
 * ATTENZIONE: questo file e' GENERATO da tools/gen-suppliers.py. Non va
 * modificato a mano: le modifiche si perdono alla prima rigenerazione.
 *
 * Serve solo come punto di partenza. Dopo la prima apertura di
 * Marchi -> Fornitori gli elenchi vivono nel database e si gestiscono da li':
 * cambiare questo file non cambia piu' il sito.
 *
 * I loghi qui dentro sono file del tema in assets/images/brands/. Quelli
 * scelti dalla libreria media hanno invece un ID di allegato.
 *
 * @package Idealugano
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * @return array<string, array{label: string, items: array<int, array>}>
 */
function idealugano_get_supplier_seed()
{
    return array(
        'sistemi' => array(
            'label' => 'Sistemi per tende',
            'items' => array(
                array('name' => 'Silent Gliss', 'file' => 'silent-gliss.svg', 'w' => 663, 'h' => 163),
                array('name' => 'Kadeco', 'file' => 'kadeco.png', 'w' => 260, 'h' => 48),
                array('name' => 'MHZ', 'file' => 'mhz.svg', 'w' => 350, 'h' => 97),
                array('name' => 'Casa Valentina', 'file' => 'casa-valentina.png', 'w' => 190, 'h' => 160),
                array('name' => 'Scaglioni', 'file' => 'scaglioni.png', 'w' => 290, 'h' => 80),
                array('name' => 'Interstil', 'file' => 'interstil.svg', 'w' => 125, 'h' => 43),
            ),
        ),
        'tessuti' => array(
            'label' => 'Editori tessili',
            'items' => array(
                array('name' => 'Antico Setificio Fiorentino', 'file' => 'antico-setificio-fiorentino.svg', 'w' => 372, 'h' => 538),
                array('name' => 'Création Baumann', 'file' => 'baumann.svg', 'w' => 159, 'h' => 68),
                array('name' => 'Boussac'),
                array('name' => 'Braquenié'),
                array('name' => 'Brochier', 'file' => 'brochier.png', 'w' => 440, 'h' => 91),
                array('name' => 'C&C Milano', 'file' => 'c-c-milano.png', 'w' => 157, 'h' => 100),
                array('name' => 'Camengo', 'file' => 'camengo.svg', 'w' => 258, 'h' => 45),
                array('name' => 'Casal', 'file' => 'casal.svg', 'w' => 204, 'h' => 129),
                array('name' => 'Casamance', 'file' => 'casamance.svg', 'w' => 266, 'h' => 31),
                array('name' => 'Colefax & Fowler', 'file' => 'colefax-fowler.svg', 'w' => 475, 'h' => 39),
                array('name' => 'Créations Métaphores'),
                array('name' => 'de Le Cuona', 'file' => 'de-le-cuona.png', 'w' => 401, 'h' => 62),
                array('name' => 'Decortex Firenze', 'file' => 'decortex.png', 'w' => 440, 'h' => 84),
                array('name' => 'Dedar', 'file' => 'dedar.svg', 'w' => 128, 'h' => 47),
                array('name' => 'Elitis', 'file' => 'elitis.svg', 'w' => 184, 'h' => 72),
                array('name' => 'Etro Home', 'file' => 'etro.svg', 'w' => 136, 'h' => 18),
                array('name' => 'Christian Fischbacher'),
                array('name' => 'Fortuny', 'file' => 'fortuny.png', 'w' => 181, 'h' => 160),
                array('name' => 'Gaston y Daniela', 'file' => 'gaston-y-daniela.png', 'w' => 440, 'h' => 57),
                array('name' => 'G P & J Baker', 'file' => 'gp-j-baker.png', 'w' => 440, 'h' => 85),
                array('name' => 'Holland & Sherry', 'file' => 'holland-sherry.svg', 'w' => 271, 'h' => 49),
                array('name' => 'Houlès', 'file' => 'houles.png', 'w' => 179, 'h' => 154),
                array('name' => 'JAB Anstoetz'),
                array('name' => 'Jane Churchill', 'file' => 'jane-churchill.svg', 'w' => 62, 'h' => 7),
                array('name' => 'Jim Thompson', 'file' => 'jim-thompson.svg', 'w' => 185, 'h' => 27),
                array('name' => 'Kohro', 'file' => 'kohro.png', 'w' => 440, 'h' => 83),
                array('name' => 'Landenberg', 'file' => 'landenberg.png', 'w' => 440, 'h' => 81),
                array('name' => 'Larsen', 'file' => 'larsen.svg', 'w' => 233, 'h' => 49),
                array('name' => 'Le Manach'),
                array('name' => 'Lelièvre Paris', 'file' => 'lelievre.svg', 'w' => 213, 'h' => 56),
                array('name' => 'L\'Opificio'),
                array('name' => 'Luciano Marcato'),
                array('name' => 'Manuel Canovas', 'file' => 'manuel-canovas.svg', 'w' => 359, 'h' => 66),
                array('name' => 'Mastro Raphael', 'file' => 'mastro-raphael.png', 'w' => 440, 'h' => 85),
                array('name' => 'Mulberry Home'),
                array('name' => 'Nina Campbell', 'file' => 'nina-campbell.png', 'w' => 437, 'h' => 63),
                array('name' => 'Nobilis', 'file' => 'nobilis.svg', 'w' => 100, 'h' => 26),
                array('name' => 'Nya Nordiska', 'file' => 'nya-nordiska.png', 'w' => 440, 'h' => 54),
                array('name' => 'Osborne & Little'),
                array('name' => 'Pierre Frey'),
                array('name' => 'Romo', 'file' => 'romo.svg', 'w' => 208, 'h' => 46),
                array('name' => 'Rubelli', 'file' => 'rubelli.png', 'w' => 314, 'h' => 160),
                array('name' => 'Sanderson', 'file' => 'sanderson.png', 'w' => 216, 'h' => 25),
                array('name' => 'Simta'),
                array('name' => 'Tassinari & Chatel', 'file' => 'tassinari-chatel.svg', 'w' => 427, 'h' => 208),
                array('name' => 'Verel de Belval / Le Crin'),
                array('name' => 'Villa Nova', 'file' => 'villa-nova.svg', 'w' => 252, 'h' => 37),
                array('name' => 'Voghi'),
                array('name' => 'Zimmer + Rohde', 'file' => 'zimmer-rohde.svg', 'w' => 508, 'h' => 576),
            ),
        ),
        'passamanerie' => array(
            'label' => 'Passamanerie',
            'items' => array(
                array('name' => 'Houlès', 'file' => 'houles.png', 'w' => 179, 'h' => 154),
                array('name' => 'Samuel & Sons'),
                array('name' => 'Les Passementeries de l\'Île de France', 'file' => 'passementeries-ile-de-france.png', 'w' => 440, 'h' => 116),
                array('name' => 'tts inova', 'file' => 'tts-inova.png', 'w' => 288, 'h' => 43),
                array('name' => 'Herma Partner', 'file' => 'herma-partner.svg', 'w' => 313, 'h' => 105),
            ),
        ),
    );
}
