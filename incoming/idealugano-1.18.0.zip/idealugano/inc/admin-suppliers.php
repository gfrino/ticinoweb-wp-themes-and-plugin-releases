<?php
/**
 * Bacheca -> Marchi -> Fornitori: gestione dei tre elenchi che compaiono
 * nella pagina Marchi (sistemi per tende, editori tessili, passamanerie).
 *
 * Una scheda per gruppo, una riga per fornitore: nome, logo, e si trascina
 * per cambiare ordine. Niente ID, niente codice: il cliente lavora per nome.
 *
 * Il salvataggio passa da AJAX con nonce e controllo dei permessi
 * (`edit_pages`, come la pagina Marchi). I dati finiscono nell'opzione
 * gestita da inc/suppliers.php.
 *
 * @package Idealugano
 */

if (!defined('ABSPATH')) {
    exit;
}

/** Il menu: una voce sotto Marchi, e la prima voce prende un nome suo. */
add_action('admin_menu', 'idealugano_register_suppliers_menu', 11);
function idealugano_register_suppliers_menu()
{
    add_submenu_page(
        'idealugano-brands',
        __('Fornitori', 'idealugano'),
        __('Fornitori', 'idealugano'),
        'edit_pages',
        'idealugano-suppliers',
        'idealugano_render_suppliers_page'
    );

    // Il primo sottomenu lo crea WordPress dentro add_submenu_page, copiando il
    // nome del menu: va rinominato dopo, se no "Marchi" compare due volte.
    global $submenu;
    if (isset($submenu['idealugano-brands'][0][0])) {
        $submenu['idealugano-brands'][0][0] = __('Partner in evidenza', 'idealugano');
    }
}

/** Salvataggio di tutti e tre gli elenchi in un colpo solo. */
add_action('wp_ajax_idealugano_save_suppliers', 'idealugano_ajax_save_suppliers');
function idealugano_ajax_save_suppliers()
{
    check_ajax_referer('idealugano_suppliers_nonce', 'nonce');

    if (!current_user_can('edit_pages')) {
        wp_send_json_error(array('message' => __('Non hai i permessi per salvare i fornitori.', 'idealugano')));
    }

    $raw = isset($_POST['groups']) ? json_decode(wp_unslash($_POST['groups']), true) : null;
    if (!is_array($raw)) {
        wp_send_json_error(array('message' => __('Dati non validi: ricarica la pagina e riprova.', 'idealugano')));
    }

    $seed  = idealugano_get_supplier_seed();
    $clean = array();
    $count = 0;

    foreach (idealugano_supplier_group_keys() as $key) {
        $items = array();
        $in    = isset($raw[$key]) && is_array($raw[$key]) ? $raw[$key] : array();
        foreach ($in as $item) {
            if (!is_array($item)) {
                continue;
            }
            $name = isset($item['name']) ? sanitize_text_field($item['name']) : '';
            if ($name === '') {
                continue;
            }
            $logo_id = isset($item['logo_id']) ? absint($item['logo_id']) : 0;
            $items[] = array(
                'name'    => $name,
                // Il file del tema resta solo finche' non si sceglie un logo dalla libreria.
                'file'    => $logo_id ? '' : sanitize_file_name(isset($item['file']) ? $item['file'] : ''),
                'logo_id' => $logo_id,
                'logo'    => $logo_id ? esc_url_raw(isset($item['logo']) ? $item['logo'] : '') : '',
                'w'       => isset($item['w']) ? absint($item['w']) : 0,
                'h'       => isset($item['h']) ? absint($item['h']) : 0,
            );
            $count++;
        }
        $clean[$key] = array(
            'label' => isset($seed[$key]['label']) ? $seed[$key]['label'] : $key,
            'items' => $items,
        );
    }

    update_option(IDEALUGANO_SUPPLIERS_OPTION, $clean, false);

    wp_send_json_success(array(
        /* translators: %d: numero di fornitori salvati. */
        'message' => sprintf(_n('%d fornitore salvato.', '%d fornitori salvati.', $count, 'idealugano'), $count),
        'count'   => $count,
    ));
}

/** Rimette gli elenchi come sono stati consegnati. */
add_action('wp_ajax_idealugano_reset_suppliers', 'idealugano_ajax_reset_suppliers');
function idealugano_ajax_reset_suppliers()
{
    check_ajax_referer('idealugano_suppliers_nonce', 'nonce');

    if (!current_user_can('edit_pages')) {
        wp_send_json_error(array('message' => __('Non hai i permessi per ripristinare i fornitori.', 'idealugano')));
    }

    update_option(IDEALUGANO_SUPPLIERS_OPTION, idealugano_get_supplier_seed(), false);
    wp_send_json_success(array('message' => __('Elenchi riportati a come erano alla consegna.', 'idealugano')));
}

/**
 * Una riga della tabella.
 *
 * @param array $item Voce del fornitore (vuota per il modello).
 */
function idealugano_render_supplier_row($item = array())
{
    $item = wp_parse_args($item, array('name' => '', 'file' => '', 'logo_id' => 0, 'logo' => '', 'w' => 0, 'h' => 0));
    $logo = idealugano_supplier_logo($item);
    ?>
    <li class="idealugano-sup-row"
        data-file="<?php echo esc_attr($item['file']); ?>"
        data-logo-id="<?php echo (int) $item['logo_id']; ?>"
        data-logo="<?php echo esc_attr($item['logo']); ?>"
        data-w="<?php echo (int) $item['w']; ?>"
        data-h="<?php echo (int) $item['h']; ?>">
        <button type="button" class="idealugano-sup-handle" aria-label="<?php esc_attr_e('Trascina per spostare. Con la tastiera: frecce su e giù.', 'idealugano'); ?>">
            <span class="dashicons dashicons-menu" aria-hidden="true"></span>
        </button>

        <span class="idealugano-sup-thumb">
            <?php if ($logo) : ?>
                <img src="<?php echo esc_url($logo['url']); ?>" alt="">
            <?php else : ?>
                <span class="idealugano-sup-thumb__empty"><?php esc_html_e('solo nome', 'idealugano'); ?></span>
            <?php endif; ?>
        </span>

        <label class="idealugano-sup-name">
            <span class="screen-reader-text"><?php esc_html_e('Nome del fornitore', 'idealugano'); ?></span>
            <input type="text" value="<?php echo esc_attr($item['name']); ?>"
                   placeholder="<?php esc_attr_e('Es. Dedar', 'idealugano'); ?>">
        </label>

        <span class="idealugano-sup-actions">
            <button type="button" class="button button-small idealugano-sup-pick">
                <?php echo $logo ? esc_html__('Cambia logo', 'idealugano') : esc_html__('Scegli logo', 'idealugano'); ?>
            </button>
            <button type="button" class="button-link idealugano-sup-clear" <?php echo $logo ? '' : 'hidden'; ?>>
                <?php esc_html_e('Togli logo', 'idealugano'); ?>
            </button>
            <button type="button" class="button-link button-link-delete idealugano-sup-del"
                    aria-label="<?php esc_attr_e('Elimina questo fornitore', 'idealugano'); ?>">
                <span class="dashicons dashicons-trash" aria-hidden="true"></span>
            </button>
        </span>
    </li>
    <?php
}

/** La pagina. */
function idealugano_render_suppliers_page()
{
    if (!current_user_can('edit_pages')) {
        wp_die(esc_html__('Non hai i permessi per accedere a questa pagina.', 'idealugano'));
    }

    wp_enqueue_media();
    wp_enqueue_script('jquery-ui-sortable');

    $groups = idealugano_get_supplier_groups();
    $nonce  = wp_create_nonce('idealugano_suppliers_nonce');
    $keys   = idealugano_supplier_group_keys();
    $first  = $keys[0];
    ?>
    <div class="wrap idealugano-sup-admin">
        <h1><?php esc_html_e('Fornitori', 'idealugano'); ?></h1>
        <p class="idealugano-sup-intro">
            <?php esc_html_e('Questi tre elenchi compaiono nella pagina Marchi del sito, sotto i partner in evidenza. Un fornitore senza logo non è un errore: il suo nome viene scritto nel carattere del sito, nella stessa casella degli altri.', 'idealugano'); ?>
            <a href="<?php echo esc_url(home_url('/marchi/')); ?>" target="_blank" rel="noopener">
                <?php esc_html_e('Guarda la pagina', 'idealugano'); ?>
            </a>
        </p>

        <h2 class="nav-tab-wrapper idealugano-sup-tabs">
            <?php foreach ($keys as $key) : ?>
                <a href="#<?php echo esc_attr($key); ?>"
                   class="nav-tab <?php echo $key === $first ? 'nav-tab-active' : ''; ?>"
                   data-group="<?php echo esc_attr($key); ?>">
                    <?php echo esc_html($groups[$key]['label']); ?>
                    <span class="idealugano-sup-badge"><?php echo count($groups[$key]['items']); ?></span>
                </a>
            <?php endforeach; ?>
        </h2>

        <?php foreach ($keys as $key) : ?>
            <section class="idealugano-sup-panel" data-group="<?php echo esc_attr($key); ?>"
                     <?php echo $key === $first ? '' : 'hidden'; ?>>
                <div class="idealugano-sup-toolbar">
                    <button type="button" class="button button-primary idealugano-sup-add">
                        <?php esc_html_e('Aggiungi fornitore', 'idealugano'); ?>
                    </button>
                    <button type="button" class="button idealugano-sup-sort">
                        <?php esc_html_e('Ordina dalla A alla Z', 'idealugano'); ?>
                    </button>
                </div>

                <ul class="idealugano-sup-list">
                    <?php foreach ($groups[$key]['items'] as $item) : ?>
                        <?php idealugano_render_supplier_row($item); ?>
                    <?php endforeach; ?>
                </ul>

                <p class="idealugano-sup-empty" <?php echo $groups[$key]['items'] ? 'hidden' : ''; ?>>
                    <?php esc_html_e('Nessun fornitore in questo gruppo. Con "Aggiungi fornitore" ne metti uno nuovo in fondo all\'elenco.', 'idealugano'); ?>
                </p>
            </section>
        <?php endforeach; ?>

        <div class="idealugano-sup-bar">
            <span class="idealugano-sup-state" id="sup-state"><?php esc_html_e('Tutte le modifiche salvate', 'idealugano'); ?></span>
            <button type="button" class="button button-primary button-large" id="sup-save">
                <?php esc_html_e('Salva modifiche', 'idealugano'); ?>
            </button>
        </div>

        <p class="idealugano-sup-reset">
            <button type="button" class="button-link" id="sup-reset">
                <?php esc_html_e('Riporta i tre elenchi a come erano alla consegna', 'idealugano'); ?>
            </button>
        </p>
    </div>

    <template id="idealugano-sup-template"><?php idealugano_render_supplier_row(); ?></template>

    <style>
    .idealugano-sup-admin { max-width: 980px; margin-bottom: 120px; }
    .idealugano-sup-intro { max-width: 70ch; color: #50575e; }
    .idealugano-sup-tabs { margin-top: 20px; }
    .idealugano-sup-badge {
        display: inline-block; min-width: 20px; margin-left: 6px; padding: 0 6px;
        border-radius: 10px; background: #dcdcde; color: #1d2327;
        font-size: 11px; line-height: 18px; text-align: center;
    }
    .nav-tab-active .idealugano-sup-badge { background: #052d3a; color: #fff; }
    .idealugano-sup-toolbar { display: flex; gap: 8px; margin: 16px 0; }
    .idealugano-sup-list { margin: 0; border: 1px solid #c3c4c7; border-bottom: 0; background: #fff; }
    .idealugano-sup-list:empty { border: 0; }
    .idealugano-sup-row {
        display: flex; align-items: center; gap: 12px; margin: 0;
        padding: 8px 12px; border-bottom: 1px solid #e0e0e1; background: #fff;
    }
    .idealugano-sup-row:nth-child(even) { background: #fcfcfc; }
    .idealugano-sup-row.is-dragging { opacity: .6; }
    .idealugano-sup-placeholder { height: 60px; background: #f0f6fc; border-bottom: 1px solid #e0e0e1; }
    .idealugano-sup-handle {
        flex: 0 0 auto; width: 28px; height: 28px; padding: 0; cursor: grab;
        border: 1px solid transparent; border-radius: 3px; background: none; color: #787c82;
    }
    .idealugano-sup-handle:hover { background: #f0f0f1; color: #1d2327; }
    .idealugano-sup-handle:focus { border-color: #2271b1; box-shadow: 0 0 0 1px #2271b1; outline: 2px solid transparent; }
    .idealugano-sup-thumb {
        flex: 0 0 auto; display: flex; align-items: center; justify-content: center;
        width: 96px; height: 44px; padding: 4px; background: #f6f7f7; border: 1px solid #e0e0e1;
    }
    .idealugano-sup-thumb img { max-width: 100%; max-height: 100%; object-fit: contain; }
    .idealugano-sup-thumb__empty { font-size: 10px; color: #8c8f94; text-transform: uppercase; letter-spacing: .04em; }
    .idealugano-sup-name { flex: 1 1 auto; }
    .idealugano-sup-name input { width: 100%; }
    .idealugano-sup-actions { flex: 0 0 auto; display: flex; align-items: center; gap: 10px; }
    .idealugano-sup-del { color: #b32d2e; }
    .idealugano-sup-empty { padding: 16px; background: #fff; border: 1px solid #c3c4c7; color: #50575e; }
    .idealugano-sup-bar {
        position: sticky; bottom: 0; z-index: 10; display: flex; align-items: center;
        justify-content: flex-end; gap: 16px; margin-top: 20px; padding: 12px 16px;
        background: #fff; border: 1px solid #c3c4c7; box-shadow: 0 -2px 6px rgba(0,0,0,.05);
    }
    .idealugano-sup-state { color: #50575e; }
    .idealugano-sup-state.is-dirty { color: #996800; font-weight: 600; }
    .idealugano-sup-state.is-error { color: #b32d2e; font-weight: 600; }
    .idealugano-sup-reset { margin-top: 24px; }
    .idealugano-sup-reset .button-link { color: #b32d2e; }
    </style>

    <script>
    // jQuery(fn): il nostro codice gira a pagina pronta, cioe' dopo che il
    // footer ha caricato jquery-ui-sortable. Lanciato subito, $().sortable non
    // esiste ancora e l'errore zittisce tutto il resto dello script.
    jQuery(function ($) {
        'use strict';

        var nonce = <?php echo wp_json_encode($nonce); ?>;
        var dirty = false;
        var $state = $('#sup-state');

        function setDirty(on) {
            dirty = on;
            $state.toggleClass('is-dirty', on).removeClass('is-error')
                  .text(on ? <?php echo wp_json_encode(__('Modifiche non salvate', 'idealugano')); ?>
                           : <?php echo wp_json_encode(__('Tutte le modifiche salvate', 'idealugano')); ?>);
        }

        function refreshCounts() {
            $('.idealugano-sup-panel').each(function () {
                var key = $(this).data('group');
                var n   = $(this).find('.idealugano-sup-row').length;
                $('.nav-tab[data-group="' + key + '"] .idealugano-sup-badge').text(n);
                $(this).find('.idealugano-sup-empty').prop('hidden', n > 0);
            });
        }

        // ---- schede ----
        $('.idealugano-sup-tabs .nav-tab').on('click', function (e) {
            e.preventDefault();
            var key = $(this).data('group');
            $('.idealugano-sup-tabs .nav-tab').removeClass('nav-tab-active');
            $(this).addClass('nav-tab-active');
            $('.idealugano-sup-panel').each(function () {
                $(this).prop('hidden', $(this).data('group') !== key);
            });
        });

        // ---- righe ----
        $(document).on('input', '.idealugano-sup-name input', function () { setDirty(true); });

        $(document).on('click', '.idealugano-sup-add', function () {
            var $list = $(this).closest('.idealugano-sup-panel').find('.idealugano-sup-list');
            var html  = $('#idealugano-sup-template').html();
            $list.append(html);
            $list.find('.idealugano-sup-row').last().find('.idealugano-sup-name input').trigger('focus');
            refreshCounts();
            setDirty(true);
        });

        $(document).on('click', '.idealugano-sup-del', function () {
            var $row = $(this).closest('.idealugano-sup-row');
            var name = $.trim($row.find('.idealugano-sup-name input').val());
            var msg  = name
                ? <?php echo wp_json_encode(__('Togliere %s dall\'elenco?', 'idealugano')); ?>.replace('%s', name)
                : <?php echo wp_json_encode(__('Togliere questa riga?', 'idealugano')); ?>;
            if (!window.confirm(msg)) { return; }
            $row.remove();
            refreshCounts();
            setDirty(true);
        });

        $(document).on('click', '.idealugano-sup-sort', function () {
            var $list = $(this).closest('.idealugano-sup-panel').find('.idealugano-sup-list');
            var rows  = $list.find('.idealugano-sup-row').get();
            rows.sort(function (a, b) {
                var na = $(a).find('input').val() || '';
                var nb = $(b).find('input').val() || '';
                return na.localeCompare(nb, 'it', { sensitivity: 'base' });
            });
            $list.append(rows);
            setDirty(true);
        });

        // ---- logo dalla libreria ----
        var frame = null;
        $(document).on('click', '.idealugano-sup-pick', function () {
            var $row = $(this).closest('.idealugano-sup-row');
            if (frame) { frame.off('select'); }
            frame = wp.media({
                title: <?php echo wp_json_encode(__('Scegli il logo del fornitore', 'idealugano')); ?>,
                button: { text: <?php echo wp_json_encode(__('Usa questo logo', 'idealugano')); ?> },
                library: { type: 'image' },
                multiple: false
            });
            frame.on('select', function () {
                var a = frame.state().get('selection').first().toJSON();
                $row.attr('data-logo-id', a.id).attr('data-logo', a.url)
                    .attr('data-w', a.width || 0).attr('data-h', a.height || 0)
                    .attr('data-file', '');
                $row.find('.idealugano-sup-thumb').html($('<img>', { src: a.url, alt: '' }));
                $row.find('.idealugano-sup-pick').text(<?php echo wp_json_encode(__('Cambia logo', 'idealugano')); ?>);
                $row.find('.idealugano-sup-clear').prop('hidden', false);
                setDirty(true);
            });
            frame.open();
        });

        $(document).on('click', '.idealugano-sup-clear', function () {
            var $row = $(this).closest('.idealugano-sup-row');
            $row.attr('data-logo-id', 0).attr('data-logo', '').attr('data-file', '')
                .attr('data-w', 0).attr('data-h', 0);
            $row.find('.idealugano-sup-thumb').html(
                $('<span class="idealugano-sup-thumb__empty"></span>')
                    .text(<?php echo wp_json_encode(__('solo nome', 'idealugano')); ?>)
            );
            $row.find('.idealugano-sup-pick').text(<?php echo wp_json_encode(__('Scegli logo', 'idealugano')); ?>);
            $(this).prop('hidden', true);
            setDirty(true);
        });

        // ---- ordine: trascinamento, e frecce per chi usa la tastiera ----
        // Se per qualsiasi motivo manca, restano le frecce da tastiera qui sotto:
        // meglio senza trascinamento che con la pagina ferma.
        if ($.fn.sortable) {
            $('.idealugano-sup-list').sortable({
                handle: '.idealugano-sup-handle',
                placeholder: 'idealugano-sup-placeholder',
                forcePlaceholderSize: true,
                axis: 'y',
                start: function (e, ui) { ui.item.addClass('is-dragging'); },
                stop: function (e, ui) { ui.item.removeClass('is-dragging'); setDirty(true); }
            });
        }

        $(document).on('keydown', '.idealugano-sup-handle', function (e) {
            if (e.key !== 'ArrowUp' && e.key !== 'ArrowDown') { return; }
            e.preventDefault();
            var $row = $(this).closest('.idealugano-sup-row');
            if (e.key === 'ArrowUp') { $row.prev('.idealugano-sup-row').before($row); }
            else { $row.next('.idealugano-sup-row').after($row); }
            $row.find('.idealugano-sup-handle').trigger('focus');
            setDirty(true);
        });

        // ---- salvataggio ----
        function collect() {
            var out = {};
            $('.idealugano-sup-panel').each(function () {
                var key = $(this).data('group');
                out[key] = $(this).find('.idealugano-sup-row').map(function () {
                    var $r = $(this);
                    return {
                        name: $.trim($r.find('.idealugano-sup-name input').val()),
                        file: $r.attr('data-file') || '',
                        logo_id: parseInt($r.attr('data-logo-id'), 10) || 0,
                        logo: $r.attr('data-logo') || '',
                        w: parseInt($r.attr('data-w'), 10) || 0,
                        h: parseInt($r.attr('data-h'), 10) || 0
                    };
                }).get();
            });
            return out;
        }

        $('#sup-save').on('click', function () {
            var $btn = $(this);
            var senzaNome = $('.idealugano-sup-row').filter(function () {
                return !$.trim($(this).find('.idealugano-sup-name input').val());
            });
            if (senzaNome.length) {
                $state.addClass('is-error').text(
                    <?php echo wp_json_encode(__('C\'è una riga senza nome: scrivilo o togli la riga.', 'idealugano')); ?>
                );
                senzaNome.first().find('input').trigger('focus');
                return;
            }
            $btn.prop('disabled', true);
            $state.removeClass('is-error').text(<?php echo wp_json_encode(__('Salvataggio…', 'idealugano')); ?>);
            $.post(ajaxurl, {
                action: 'idealugano_save_suppliers',
                nonce: nonce,
                groups: JSON.stringify(collect())
            }).done(function (res) {
                if (res && res.success) {
                    setDirty(false);
                    $state.text(res.data.message);
                } else {
                    $state.addClass('is-error').text((res && res.data && res.data.message) || 'Errore');
                }
            }).fail(function () {
                $state.addClass('is-error').text(
                    <?php echo wp_json_encode(__('Salvataggio non riuscito: controlla la connessione e riprova.', 'idealugano')); ?>
                );
            }).always(function () {
                $btn.prop('disabled', false);
            });
        });

        $('#sup-reset').on('click', function () {
            if (!window.confirm(<?php echo wp_json_encode(__('Questo cancella le modifiche fatte e rimette i tre elenchi come erano alla consegna. Procedere?', 'idealugano')); ?>)) {
                return;
            }
            $.post(ajaxurl, { action: 'idealugano_reset_suppliers', nonce: nonce })
                .done(function (res) {
                    if (res && res.success) { window.location.reload(); }
                    else { $state.addClass('is-error').text((res && res.data && res.data.message) || 'Errore'); }
                });
        });

        $(window).on('beforeunload', function () {
            if (dirty) { return <?php echo wp_json_encode(__('Ci sono modifiche non salvate.', 'idealugano')); ?>; }
        });

        refreshCounts();
    });
    </script>
    <?php
}
