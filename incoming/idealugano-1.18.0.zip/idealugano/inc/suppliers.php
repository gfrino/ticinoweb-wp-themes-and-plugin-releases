<?php
/**
 * Fornitori dell'atelier: sistemi per tende, editori tessili, passamanerie.
 *
 * Gli elenchi vivono nel database (opzione `idealugano_suppliers`) e si
 * gestiscono in Bacheca -> Marchi -> Fornitori. Alla prima lettura, se
 * l'opzione non c'e' ancora, viene seminata da `inc/suppliers-data.php`, che
 * contiene gli elenchi consegnati dal cliente: da quel momento in poi fa fede
 * il database, e il file dei dati non viene piu' guardato.
 *
 * Un fornitore ha un nome e, se ce l'ha, un logo. Il logo puo' arrivare da due
 * posti: un file del tema in `assets/images/brands/` (i 45 recuperati dai siti
 * ufficiali) oppure la libreria media, se qualcuno ne ha caricato uno dalla
 * bacheca. Chi non ha logo viene reso con il nome composto tipograficamente.
 *
 * @package Idealugano
 */

if (!defined('ABSPATH')) {
    exit;
}

/** Opzione che contiene gli elenchi. Non in autoload: sessanta voci. */
define('IDEALUGANO_SUPPLIERS_OPTION', 'idealugano_suppliers');

/** Le chiavi dei gruppi, nell'ordine in cui compaiono sulla pagina Marchi. */
function idealugano_supplier_group_keys()
{
    return array('sistemi', 'tessuti', 'passamanerie');
}

/**
 * Tutti i gruppi di fornitori, dal database.
 *
 * @return array<string, array{label: string, items: array<int, array>}>
 */
function idealugano_get_supplier_groups()
{
    static $groups = null;
    if ($groups !== null) {
        return $groups;
    }

    $stored = get_option(IDEALUGANO_SUPPLIERS_OPTION);
    if (!is_array($stored) || empty($stored)) {
        $stored = idealugano_get_supplier_seed();
        // false: sessanta voci non servono a ogni richiesta del sito.
        add_option(IDEALUGANO_SUPPLIERS_OPTION, $stored, '', false);
    }

    $groups = idealugano_normalize_supplier_groups($stored);

    /**
     * Permette a un plugin di aggiungere o togliere fornitori.
     *
     * @param array $groups Gruppi di fornitori.
     */
    $groups = apply_filters('idealugano_supplier_groups', $groups);

    return $groups;
}

/**
 * Rimette in riga quello che arriva dal database: gruppi attesi, etichette
 * dal seme se mancano, voci senza nome scartate.
 *
 * @param array $raw Dati grezzi.
 * @return array<string, array{label: string, items: array<int, array>}>
 */
function idealugano_normalize_supplier_groups($raw)
{
    $seed  = idealugano_get_supplier_seed();
    $clean = array();

    foreach (idealugano_supplier_group_keys() as $key) {
        $label = isset($raw[$key]['label']) ? (string) $raw[$key]['label'] : '';
        if ($label === '') {
            $label = isset($seed[$key]['label']) ? $seed[$key]['label'] : $key;
        }
        $items = array();
        $in    = isset($raw[$key]['items']) && is_array($raw[$key]['items']) ? $raw[$key]['items'] : array();
        foreach ($in as $item) {
            if (!is_array($item)) {
                continue;
            }
            $name = isset($item['name']) ? trim((string) $item['name']) : '';
            if ($name === '') {
                continue;
            }
            $items[] = array(
                'name'    => $name,
                'file'    => isset($item['file']) ? (string) $item['file'] : '',
                'logo_id' => isset($item['logo_id']) ? (int) $item['logo_id'] : 0,
                'logo'    => isset($item['logo']) ? (string) $item['logo'] : '',
                'w'       => isset($item['w']) ? (int) $item['w'] : 0,
                'h'       => isset($item['h']) ? (int) $item['h'] : 0,
            );
        }
        $clean[$key] = array('label' => $label, 'items' => $items);
    }

    return $clean;
}

/**
 * Un solo gruppo di fornitori.
 *
 * @param string $key sistemi | tessuti | passamanerie
 * @return array{label: string, items: array<int, array>}|null
 */
function idealugano_get_supplier_group($key)
{
    $groups = idealugano_get_supplier_groups();
    return isset($groups[$key]) ? $groups[$key] : null;
}

/**
 * Dove sta il logo di un fornitore, e quanto e' grande.
 *
 * La libreria media ha la precedenza sul file del tema: se qualcuno ha
 * caricato un logo dalla bacheca, e' quello che vuole vedere.
 *
 * @param array $item Voce del fornitore.
 * @return array{url: string, w: int, h: int}|null Null se non ha logo.
 */
function idealugano_supplier_logo($item)
{
    if (!empty($item['logo_id'])) {
        $url = wp_get_attachment_url((int) $item['logo_id']);
        if ($url) {
            $w = (int) (isset($item['w']) ? $item['w'] : 0);
            $h = (int) (isset($item['h']) ? $item['h'] : 0);
            if ($w <= 0 || $h <= 0) {
                $meta = wp_get_attachment_metadata((int) $item['logo_id']);
                $w = !empty($meta['width']) ? (int) $meta['width'] : 200;
                $h = !empty($meta['height']) ? (int) $meta['height'] : 80;
            }
            return array('url' => $url, 'w' => $w, 'h' => $h);
        }
    }

    if (!empty($item['logo']) && strpos($item['logo'], '//') !== false) {
        return array(
            'url' => $item['logo'],
            'w'   => !empty($item['w']) ? (int) $item['w'] : 200,
            'h'   => !empty($item['h']) ? (int) $item['h'] : 80,
        );
    }

    if (!empty($item['file'])) {
        $file = basename((string) $item['file']);
        $path = get_stylesheet_directory() . '/assets/images/brands/' . $file;
        if (file_exists($path)) {
            return array(
                'url' => get_stylesheet_directory_uri() . '/assets/images/brands/' . $file,
                'w'   => !empty($item['w']) ? (int) $item['w'] : 200,
                'h'   => !empty($item['h']) ? (int) $item['h'] : 80,
            );
        }
    }

    return null;
}

/**
 * Stampa il muro dei marchi di un gruppo.
 *
 * Chi ha un logo lo mostra, gli altri il nome composto: entrambi dentro la
 * stessa casella, cosi' la griglia resta regolare.
 *
 * @param string $key      Chiave del gruppo.
 * @param string $modifier Modificatore BEM opzionale, es. 'idea-logo-wall--lg'.
 */
function idealugano_render_logo_wall($key, $modifier = '')
{
    $group = idealugano_get_supplier_group($key);
    if (empty($group['items'])) {
        return;
    }

    $classes = 'idea-logo-wall' . ($modifier ? ' ' . $modifier : '');
    ?>
    <ul class="<?php echo esc_attr($classes); ?>" role="list">
        <?php foreach ($group['items'] as $item) : ?>
            <?php $logo = idealugano_supplier_logo($item); ?>
            <li class="idea-logo-wall__item">
                <?php if ($logo) : ?>
                    <img class="idea-logo-wall__img"
                         src="<?php echo esc_url($logo['url']); ?>"
                         width="<?php echo (int) $logo['w']; ?>"
                         height="<?php echo (int) $logo['h']; ?>"
                         alt="<?php echo esc_attr($item['name']); ?>"
                         loading="lazy" decoding="async">
                <?php else : ?>
                    <span class="idea-logo-wall__name"><?php echo esc_html($item['name']); ?></span>
                <?php endif; ?>
            </li>
        <?php endforeach; ?>
    </ul>
    <?php
}
