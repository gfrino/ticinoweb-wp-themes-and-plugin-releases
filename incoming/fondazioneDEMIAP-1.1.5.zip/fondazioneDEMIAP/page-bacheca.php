<?php
/**
 * Pagina «Archivio della bacheca» (slug bacheca): tutte le comunicazioni che non sono
 * tra le 5 in evidenza, dalle più recenti, 10 per pagina.
 */

get_header();

$paged = max(1, (int) get_query_var('paged'), (int) get_query_var('page'));
$query = new WP_Query(array(
    'post_type'           => 'post',
    'post_status'         => 'publish',
    'posts_per_page'      => 10,
    'paged'               => $paged,
    'ignore_sticky_posts' => true,
    'post__not_in'        => demiap_bacheca_featured_ids(),
));
?>
<section class="demiap-page-band" id="bacheca">
    <div class="demiap-archive">
        <?php while (have_posts()) : the_post(); ?>
            <h1 class="demiap-section-title"><?php the_title(); ?></h1>
            <?php if (trim(get_the_content())) : ?>
                <div class="demiap-archive__intro"><?php the_content(); ?></div>
            <?php endif; ?>
        <?php endwhile; ?>

        <p class="demiap-archive__back">
            <a href="<?php echo esc_url(home_url('/agenda/')); ?>"><span aria-hidden="true">&larr;</span> Comunicazioni in evidenza</a>
        </p>

        <?php if ($query->have_posts()) : ?>
            <ul class="demiap-bacheca__list demiap-bacheca__list--archive">
                <?php while ($query->have_posts()) : $query->the_post();
                    demiap_bacheca_render_card(get_the_ID());
                endwhile; ?>
            </ul>

            <?php
            $links = paginate_links(array(
                'total'     => $query->max_num_pages,
                'current'   => $paged,
                'prev_text' => '&larr; Più recenti',
                'next_text' => 'Più vecchie &rarr;',
            ));
            if ($links) {
                echo '<nav class="demiap-pagination" aria-label="Pagine dell\'archivio">' . wp_kses_post($links) . '</nav>';
            }
            ?>
        <?php else : ?>
            <p class="demiap-bacheca__empty">Nell'archivio non ci sono ancora comunicazioni: quelle attuali sono in evidenza nella pagina Agenda.</p>
        <?php endif; ?>
        <?php wp_reset_postdata(); ?>
    </div>
</section>

<?php get_footer(); ?>
