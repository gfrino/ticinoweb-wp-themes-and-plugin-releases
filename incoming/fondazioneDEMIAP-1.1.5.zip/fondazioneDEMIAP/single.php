<?php
/**
 * Singola comunicazione della Bacheca Info Point: titolo, sottotitolo, immagine e contenuto
 * (testo, immagini, PDF e gallerie inseriti con l'editor).
 */

get_header();
?>
<section class="demiap-page-band" id="bacheca">
    <?php while (have_posts()) : the_post();
        $subtitle    = (string) get_post_meta(get_the_ID(), '_demiap_sottotitolo', true);
        $archive_url = demiap_bacheca_archive_url();
        ?>
        <article <?php post_class('demiap-notice'); ?>>
            <header class="demiap-notice__header">
                <p class="demiap-notice__kicker">Bacheca Info Point &middot; <time datetime="<?php echo esc_attr(get_the_date('c')); ?>"><?php echo esc_html(get_the_date('j F Y')); ?></time></p>
                <h1 class="demiap-notice__title"><?php the_title(); ?></h1>
                <?php if ('' !== $subtitle) : ?>
                    <p class="demiap-notice__subtitle"><?php echo esc_html($subtitle); ?></p>
                <?php endif; ?>
            </header>

            <?php if (has_post_thumbnail()) : ?>
                <figure class="demiap-notice__image">
                    <?php the_post_thumbnail('large', array('sizes' => '(min-width: 900px) 820px, 100vw')); ?>
                </figure>
            <?php endif; ?>

            <div class="demiap-notice__content page-content">
                <?php the_content(); ?>
            </div>

            <footer class="demiap-notice__footer">
                <a href="<?php echo esc_url(home_url('/agenda/')); ?>"><span aria-hidden="true">&larr;</span> Torna alla bacheca</a>
                <?php if ($archive_url) : ?>
                    <a href="<?php echo esc_url($archive_url); ?>">Vedi archivio <span aria-hidden="true">&rarr;</span></a>
                <?php endif; ?>
            </footer>
        </article>
    <?php endwhile; ?>
</section>

<?php get_footer(); ?>
