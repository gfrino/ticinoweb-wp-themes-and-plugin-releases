<?php
/**
 * Riquadro IBAN e codice QR (home e pagina Sostienici).
 * Il QR sta nella libreria Media come immagine «qr-sostienici-demiap»: se manca, il riquadro mostra solo l'IBAN.
 */

$demiap_iban  = 'CH42 8080 8005 3020 6649 0';
$demiap_qr_id = fondazionedemiap_media_id_by_name('qr-sostienici-demiap', 'image');
?>
<div class="demiap-bank">
    <div class="demiap-bank__text">
        <h3 class="demiap-bank__title">Coordinate bancarie</h3>
        <p class="demiap-bank__holder">Fondazione DEMIAP<br>Via Boscioredo 34, 6516 Cugnasco</p>
        <p class="demiap-bank__label">IBAN</p>
        <p class="demiap-bank__iban"><?php echo esc_html($demiap_iban); ?></p>
        <p class="demiap-bank__note">Motivo del versamento: <strong>Sostegno MOSI</strong></p>
    </div>
    <?php if ($demiap_qr_id) : ?>
        <figure class="demiap-bank__qr">
            <?php echo wp_get_attachment_image($demiap_qr_id, 'full', false, array(
                'alt'     => 'Codice QR per il versamento alla Fondazione DEMIAP',
                'loading' => 'lazy',
                'sizes'   => '180px',
            )); ?>
            <figcaption>Inquadra con l'app della tua banca</figcaption>
        </figure>
    <?php endif; ?>
</div>
