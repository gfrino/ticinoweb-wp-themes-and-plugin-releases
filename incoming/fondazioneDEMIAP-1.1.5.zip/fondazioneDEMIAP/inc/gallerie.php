<?php
/**
 * Gallerie: il child legge le «Gallerie media» del parent (tassonomia ticinoweb_media_gallery,
 * Media → Gestisci Gallerie) e non ha un sistema suo.
 *
 * - Pagina «Gallerie» (slug «gallerie», template page-gallerie.php): tutte le gallerie con foto;
 *   ?galleria=<slug> apre le foto di una galleria.
 * - Home: carosello con la galleria «Home» (slug «home»); se non esiste, le foto più recenti di tutte le gallerie.
 */

if (!defined('ABSPATH')) {
    exit;
}

const DEMIAP_GALLERY_TAX = 'ticinoweb_media_gallery';

/**
 * Gallerie con almeno una foto, nell'ordine scelto in Gestisci Gallerie.
 *
 * @return WP_Term[]
 */
function demiap_galleries()
{
    if (!taxonomy_exists(DEMIAP_GALLERY_TAX)) {
        return array();
    }
    $terms = get_terms(array(
        'taxonomy'   => DEMIAP_GALLERY_TAX,
        'hide_empty' => true,
    ));
    return is_wp_error($terms) ? array() : $terms;
}

/**
 * ID delle immagini di una galleria nell'ordine salvato dal parent.
 *
 * @param int $term_id
 * @param int $limit   -1 per tutte (con un tetto di sicurezza).
 * @return int[]
 */
function demiap_gallery_image_ids($term_id, $limit = -1)
{
    $ids = get_posts(array(
        'post_type'      => 'attachment',
        'post_status'    => 'inherit',
        'post_mime_type' => 'image',
        'posts_per_page' => 300,
        'fields'         => 'ids',
        'no_found_rows'  => true,
        'tax_query'      => array(
            array('taxonomy' => DEMIAP_GALLERY_TAX, 'field' => 'term_id', 'terms' => (int) $term_id),
        ),
    ));
    $ids   = array_map('intval', $ids);
    $order = get_term_meta($term_id, '_ticinoweb_gallery_order', true);
    if (is_array($order) && $order) {
        $order = array_map('intval', $order);
        usort($ids, function ($a, $b) use ($order) {
            $pa = array_search($a, $order, true);
            $pb = array_search($b, $order, true);
            $pa = false === $pa ? PHP_INT_MAX : $pa;
            $pb = false === $pb ? PHP_INT_MAX : $pb;
            return $pa <=> $pb;
        });
    }
    return $limit > 0 ? array_slice($ids, 0, $limit) : $ids;
}

/**
 * Foto del carosello in home.
 *
 * @return int[]
 */
function demiap_home_gallery_image_ids()
{
    if (!taxonomy_exists(DEMIAP_GALLERY_TAX)) {
        return array();
    }
    $home = get_term_by('slug', 'home', DEMIAP_GALLERY_TAX);
    if ($home && $home->count > 0) {
        return demiap_gallery_image_ids($home->term_id, 24);
    }
    $ids = get_posts(array(
        'post_type'      => 'attachment',
        'post_status'    => 'inherit',
        'post_mime_type' => 'image',
        'posts_per_page' => 24,
        'fields'         => 'ids',
        'no_found_rows'  => true,
        'tax_query'      => array(
            array('taxonomy' => DEMIAP_GALLERY_TAX, 'operator' => 'EXISTS'),
        ),
    ));
    return array_map('intval', $ids);
}

/**
 * Indirizzo della pagina Gallerie (slug «gallerie»), eventualmente aperta su una galleria.
 */
function demiap_gallery_page_url($term = null)
{
    $page = get_page_by_path('gallerie');
    if (!$page || 'publish' !== $page->post_status) {
        return '';
    }
    $url = get_permalink($page);
    return $term ? add_query_arg('galleria', $term->slug, $url) : $url;
}

/**
 * Testo alternativo di una foto: quello della libreria Media, altrimenti il titolo della galleria.
 */
function demiap_gallery_alt($id, $fallback)
{
    $alt = trim((string) get_post_meta($id, '_wp_attachment_image_alt', true));
    return '' !== $alt ? $alt : $fallback;
}

// Lightbox delle gallerie: solo dove serve.
add_action('wp_enqueue_scripts', function () {
    if (is_front_page() || is_page('gallerie')) {
        wp_enqueue_script('fondazionedemiap-gallery', get_stylesheet_directory_uri() . '/js/gallery.js', array(), wp_get_theme()->get('Version'), true);
    }
}, 30);

// Nella vista di una galleria il titolo della scheda porta il nome della galleria.
add_filter('document_title_parts', function ($parts) {
    if (!is_page('gallerie') || empty($_GET['galleria']) || !taxonomy_exists(DEMIAP_GALLERY_TAX)) {
        return $parts;
    }
    $term = get_term_by('slug', sanitize_title(wp_unslash($_GET['galleria'])), DEMIAP_GALLERY_TAX);
    if ($term && $term->count > 0) {
        $parts['title'] = $term->name . ' – ' . $parts['title'];
    }
    return $parts;
}, 20);
