<?php
/**
 * Bacheca Info Point: usa gli articoli standard di WordPress (rinominati dal ticinoWEB CMS).
 *
 * - Le 5 comunicazioni più recenti non archiviate compaiono come anteprime (home e Agenda).
 * - Tutte le altre stanno nella pagina «Archivio della bacheca» (pagina con slug «bacheca»).
 * - Nell'editor un riquadro «Bacheca Info Point» ha il sottotitolo e la casella «Sposta in archivio».
 */

if (!defined('ABSPATH')) {
    exit;
}

const DEMIAP_BACHECA_ANTEPRIME = 5;

/* --------------------------------------------------------------------------
 * Editor: sottotitolo e archivio
 * ----------------------------------------------------------------------- */

add_action('add_meta_boxes_post', 'demiap_bacheca_add_meta_box');
function demiap_bacheca_add_meta_box()
{
    add_meta_box('demiap-bacheca', 'Bacheca Info Point', 'demiap_bacheca_meta_box', 'post', 'side', 'high');
}

function demiap_bacheca_meta_box($post)
{
    wp_nonce_field('demiap_bacheca_save', 'demiap_bacheca_nonce');
    $sottotitolo = get_post_meta($post->ID, '_demiap_sottotitolo', true);
    $archiviato  = (bool) get_post_meta($post->ID, '_demiap_archiviato', true);
    ?>
    <p>
        <label for="demiap-sottotitolo"><strong>Sottotitolo</strong></label><br>
        <input type="text" id="demiap-sottotitolo" name="demiap_sottotitolo" class="widefat" maxlength="200" value="<?php echo esc_attr($sottotitolo); ?>">
        <span class="description">Una frase sotto il titolo, visibile anche nell'anteprima.</span>
    </p>
    <p>
        <label>
            <input type="checkbox" name="demiap_archiviato" value="1" <?php checked($archiviato); ?>>
            Sposta in archivio
        </label><br>
        <span class="description">Non compare più tra le 5 anteprime, resta nell'archivio della bacheca.</span>
    </p>
    <?php
}

add_action('save_post_post', 'demiap_bacheca_save_meta', 10, 2);
function demiap_bacheca_save_meta($post_id, $post)
{
    if (!isset($_POST['demiap_bacheca_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['demiap_bacheca_nonce'])), 'demiap_bacheca_save')) {
        return;
    }
    if ((defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) || wp_is_post_revision($post_id) || !current_user_can('edit_post', $post_id)) {
        return;
    }

    $sottotitolo = isset($_POST['demiap_sottotitolo']) ? sanitize_text_field(wp_unslash($_POST['demiap_sottotitolo'])) : '';
    if ($sottotitolo !== '') {
        update_post_meta($post_id, '_demiap_sottotitolo', $sottotitolo);
    } else {
        delete_post_meta($post_id, '_demiap_sottotitolo');
    }

    if (!empty($_POST['demiap_archiviato'])) {
        update_post_meta($post_id, '_demiap_archiviato', 1);
    } else {
        delete_post_meta($post_id, '_demiap_archiviato');
    }
}

/* --------------------------------------------------------------------------
 * Elenco articoli: colonna e azioni di gruppo
 * ----------------------------------------------------------------------- */

add_filter('manage_post_posts_columns', function ($columns) {
    $columns['demiap_bacheca'] = 'Bacheca';
    return $columns;
});

add_action('manage_post_posts_custom_column', function ($column, $post_id) {
    if ('demiap_bacheca' !== $column) {
        return;
    }
    if (get_post_meta($post_id, '_demiap_archiviato', true)) {
        echo 'In archivio';
    } elseif (in_array((int) $post_id, demiap_bacheca_featured_ids(), true)) {
        echo '<strong>In evidenza</strong>';
    } else {
        echo 'In archivio (più vecchia)';
    }
}, 10, 2);

add_filter('bulk_actions-edit-post', function ($actions) {
    $actions['demiap_archivia']  = 'Sposta in archivio';
    $actions['demiap_ripristina'] = 'Togli dall\'archivio';
    return $actions;
});

add_filter('handle_bulk_actions-edit-post', function ($redirect, $action, $post_ids) {
    if (!in_array($action, array('demiap_archivia', 'demiap_ripristina'), true)) {
        return $redirect;
    }
    $count = 0;
    foreach ($post_ids as $post_id) {
        if (!current_user_can('edit_post', $post_id)) {
            continue;
        }
        if ('demiap_archivia' === $action) {
            update_post_meta($post_id, '_demiap_archiviato', 1);
        } else {
            delete_post_meta($post_id, '_demiap_archiviato');
        }
        $count++;
    }
    return add_query_arg(array('demiap_bacheca_done' => $count, 'demiap_bacheca_action' => $action), $redirect);
}, 10, 3);

add_action('admin_notices', function () {
    if (empty($_GET['demiap_bacheca_action']) || !isset($_GET['demiap_bacheca_done'])) {
        return;
    }
    $count  = absint($_GET['demiap_bacheca_done']);
    $action = sanitize_key(wp_unslash($_GET['demiap_bacheca_action']));
    $text   = 'demiap_archivia' === $action ? 'spostate in archivio' : 'tolte dall\'archivio';
    printf('<div class="notice notice-success is-dismissible"><p>%s</p></div>', esc_html(sprintf('%d comunicazioni %s.', $count, $text)));
});

/* --------------------------------------------------------------------------
 * Dati per i template
 * ----------------------------------------------------------------------- */

/**
 * ID delle comunicazioni in evidenza: le 5 più recenti pubblicate e non archiviate.
 */
function demiap_bacheca_featured_ids()
{
    static $ids = null;
    if (null === $ids) {
        $ids = array_map('intval', get_posts(array(
            'post_type'           => 'post',
            'post_status'         => 'publish',
            'posts_per_page'      => DEMIAP_BACHECA_ANTEPRIME,
            'ignore_sticky_posts' => true,
            'no_found_rows'       => true,
            'fields'              => 'ids',
            'meta_query'          => array(
                array('key' => '_demiap_archiviato', 'compare' => 'NOT EXISTS'),
            ),
        )));
    }
    return $ids;
}

/**
 * Indirizzo della pagina d'archivio (slug «bacheca»). Stringa vuota se la pagina non c'è.
 */
function demiap_bacheca_archive_url()
{
    $page = get_page_by_path('bacheca');
    return ($page && 'publish' === $page->post_status) ? (string) get_permalink($page) : '';
}

/**
 * Sottotitolo di una comunicazione: il campo dedicato, altrimenti il riassunto.
 */
function demiap_bacheca_subtitle($post = null)
{
    $post = get_post($post);
    if (!$post) {
        return '';
    }
    $sottotitolo = (string) get_post_meta($post->ID, '_demiap_sottotitolo', true);
    if ('' !== $sottotitolo) {
        return $sottotitolo;
    }
    return has_excerpt($post) ? wp_strip_all_tags(get_the_excerpt($post)) : wp_trim_words(wp_strip_all_tags(strip_shortcodes($post->post_content)), 22);
}

/**
 * Stampa le anteprime in evidenza con il link «Vedi archivio».
 *
 * @param string $context 'home' (sezione larga) o 'agenda' (colonna stretta).
 */
function demiap_bacheca_render_previews($context = 'home')
{
    $ids         = demiap_bacheca_featured_ids();
    $archive_url = demiap_bacheca_archive_url();
    $classes     = 'demiap-bacheca demiap-bacheca--' . sanitize_html_class($context);

    echo '<div class="' . esc_attr($classes) . '">';
    if (empty($ids)) {
        echo '<p class="demiap-bacheca__empty">Al momento non ci sono comunicazioni.</p>';
    } else {
        echo '<ul class="demiap-bacheca__list">';
        foreach ($ids as $id) {
            demiap_bacheca_render_card($id, 'home' === $context);
        }
        echo '</ul>';
    }
    if ($archive_url) {
        printf(
            '<p class="demiap-bacheca__more"><a class="demiap-bacheca__archive-link" href="%s">Vedi archivio <span aria-hidden="true">&rarr;</span></a></p>',
            esc_url($archive_url)
        );
    }
    echo '</div>';
}

/**
 * Una scheda d'anteprima (elemento <li>). Con $placeholder, senza immagine in evidenza mostra il logo su blu.
 */
function demiap_bacheca_render_card($post_id, $placeholder = false)
{
    $subtitle = demiap_bacheca_subtitle($post_id);
    ?>
    <li class="demiap-bacheca__item">
        <a class="demiap-bacheca__card" href="<?php echo esc_url(get_permalink($post_id)); ?>">
            <?php if (has_post_thumbnail($post_id)) : ?>
                <span class="demiap-bacheca__thumb">
                    <?php echo get_the_post_thumbnail($post_id, 'medium', array('loading' => 'lazy', 'alt' => '', 'sizes' => '(min-width: 768px) 160px, 96px')); ?>
                </span>
            <?php elseif ($placeholder) : ?>
                <span class="demiap-bacheca__thumb demiap-bacheca__thumb--logo" aria-hidden="true">
                    <img src="<?php echo esc_url(get_stylesheet_directory_uri() . '/assets/media/logo-square-trasparent.png'); ?>" alt="" loading="lazy" width="96" height="96">
                </span>
            <?php endif; ?>
            <span class="demiap-bacheca__body">
                <time class="demiap-bacheca__date" datetime="<?php echo esc_attr(get_the_date('c', $post_id)); ?>"><?php echo esc_html(get_the_date('j F Y', $post_id)); ?></time>
                <span class="demiap-bacheca__title"><?php echo esc_html(get_the_title($post_id)); ?></span>
                <?php if ('' !== $subtitle) : ?>
                    <span class="demiap-bacheca__subtitle"><?php echo esc_html($subtitle); ?></span>
                <?php endif; ?>
            </span>
        </a>
    </li>
    <?php
}
