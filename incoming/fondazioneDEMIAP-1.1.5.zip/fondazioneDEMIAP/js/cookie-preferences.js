/**
 * Link «Preferenze cookie» del footer.
 *
 * Il banner del parent toglie la sua interfaccia dopo la scelta: per riaprirla
 * si cancella la scelta salvata e si ricarica la pagina.
 */
(function () {
    'use strict';

    document.querySelectorAll('[data-demiap-cookie-preferences]').forEach(function (button) {
        button.addEventListener('click', function () {
            ['tw_cookie_consent', 'tw_cookie_preferences'].forEach(function (name) {
                document.cookie = name + '=; Max-Age=0; path=/; SameSite=Lax';
            });
            window.location.reload();
        });
    });
})();
