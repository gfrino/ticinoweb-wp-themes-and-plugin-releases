/**
 * Gallerie DEMIAP: frecce del carosello in home e lightbox delle foto.
 * Senza JavaScript il carosello scorre comunque e i link aprono la foto grande.
 */
(function () {
    'use strict';

    // Carosello: le frecce scorrono di circa una schermata.
    document.querySelectorAll('[data-demiap-carousel]').forEach(function (root) {
        var track = root.querySelector('.demiap-carousel__track');
        var prev = root.querySelector('[data-demiap-prev]');
        var next = root.querySelector('[data-demiap-next]');
        if (!track || !prev || !next) {
            return;
        }
        var step = function () { return Math.max(track.clientWidth * 0.8, 240); };
        var update = function () {
            var max = track.scrollWidth - track.clientWidth - 2;
            prev.disabled = track.scrollLeft <= 2;
            next.disabled = track.scrollLeft >= max;
        };
        prev.addEventListener('click', function () { track.scrollBy({ left: -step(), behavior: 'smooth' }); });
        next.addEventListener('click', function () { track.scrollBy({ left: step(), behavior: 'smooth' }); });
        track.addEventListener('scroll', update, { passive: true });
        window.addEventListener('resize', update);
        update();
    });

    // Lightbox con <dialog>: frecce, tastiera, chiusura con Esc o clic fuori.
    var links = Array.prototype.slice.call(document.querySelectorAll('[data-demiap-lightbox]'));
    if (!links.length || typeof HTMLDialogElement === 'undefined') {
        return;
    }

    var dialog = document.createElement('dialog');
    dialog.className = 'demiap-lightbox';
    dialog.setAttribute('aria-label', 'Foto della galleria');
    dialog.innerHTML =
        '<figure class="demiap-lightbox__figure"><img class="demiap-lightbox__img" alt=""><figcaption class="demiap-lightbox__caption"></figcaption></figure>' +
        '<button type="button" class="demiap-lightbox__btn demiap-lightbox__close" aria-label="Chiudi">&times;</button>' +
        '<button type="button" class="demiap-lightbox__btn demiap-lightbox__prev" aria-label="Foto precedente"><svg class="demiap-chevron" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M15 5l-7 7 7 7"/></svg></button>' +
        '<button type="button" class="demiap-lightbox__btn demiap-lightbox__next" aria-label="Foto successiva"><svg class="demiap-chevron" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M9 5l7 7-7 7"/></svg></button>';
    document.body.appendChild(dialog);

    var img = dialog.querySelector('.demiap-lightbox__img');
    var caption = dialog.querySelector('.demiap-lightbox__caption');
    var group = [];
    var index = 0;

    var show = function (i) {
        index = (i + group.length) % group.length;
        var link = group[index];
        var thumb = link.querySelector('img');
        img.src = link.getAttribute('href');
        img.alt = thumb ? thumb.getAttribute('alt') : '';
        caption.textContent = group.length > 1 ? (index + 1) + ' / ' + group.length : '';
    };

    links.forEach(function (link) {
        link.addEventListener('click', function (event) {
            event.preventDefault();
            var name = link.getAttribute('data-demiap-lightbox');
            group = links.filter(function (l) { return l.getAttribute('data-demiap-lightbox') === name; });
            dialog.classList.toggle('demiap-lightbox--single', group.length < 2);
            show(group.indexOf(link));
            dialog.showModal();
        });
    });

    dialog.querySelector('.demiap-lightbox__close').addEventListener('click', function () { dialog.close(); });
    dialog.querySelector('.demiap-lightbox__prev').addEventListener('click', function () { show(index - 1); });
    dialog.querySelector('.demiap-lightbox__next').addEventListener('click', function () { show(index + 1); });
    dialog.addEventListener('click', function (event) {
        if (event.target === dialog) {
            dialog.close();
        }
    });
    dialog.addEventListener('keydown', function (event) {
        if (event.key === 'ArrowLeft') { show(index - 1); }
        if (event.key === 'ArrowRight') { show(index + 1); }
    });
    dialog.addEventListener('close', function () { img.removeAttribute('src'); });
})();
