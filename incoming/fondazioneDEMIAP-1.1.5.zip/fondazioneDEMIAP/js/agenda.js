/**
 * Agenda DEMIAP: pulsanti «Elenco» / «Calendario» e griglia mensile.
 * I dati arrivano dal server (inc/agenda.php) già filtrati: la descrizione è HTML sicuro.
 */
(function () {
    'use strict';

    var MONTHS = ['gennaio', 'febbraio', 'marzo', 'aprile', 'maggio', 'giugno', 'luglio', 'agosto', 'settembre', 'ottobre', 'novembre', 'dicembre'];
    var DAYS = ['Lu', 'Ma', 'Me', 'Gi', 'Ve', 'Sa', 'Do'];
    var STORAGE = 'demiapAgendaView';

    function pad(n) { return (n < 10 ? '0' : '') + n; }
    function key(y, m, d) { return y + '-' + pad(m + 1) + '-' + pad(d); }
    function escapeText(s) {
        var div = document.createElement('div');
        div.textContent = s;
        return div.innerHTML;
    }

    document.querySelectorAll('[data-demiap-agenda]').forEach(function (root) {
        var dataNode = root.querySelector('.demiap-cal__data');
        var cal = root.querySelector('[data-demiap-cal]');
        var switcher = root.querySelector('.demiap-agenda-views__switch');
        var buttons = root.querySelectorAll('.demiap-agenda-views__btn');
        var panels = root.querySelectorAll('[data-view-panel]');
        if (!dataNode || !cal || !switcher) {
            return;
        }

        var events = [];
        try { events = JSON.parse(dataNode.textContent) || []; } catch (e) { return; }

        // Eventi per giorno (anche quelli di più giorni compaiono in ogni giorno che occupano).
        var byDay = {};
        events.forEach(function (ev) {
            var d = new Date(ev.d + 'T12:00:00');
            var last = new Date(ev.e + 'T12:00:00');
            for (var guard = 0; d <= last && guard < 60; guard++) {
                var k = key(d.getFullYear(), d.getMonth(), d.getDate());
                (byDay[k] = byDay[k] || []).push(ev);
                d.setDate(d.getDate() + 1);
            }
        });

        var today = new Date();
        var todayKey = key(today.getFullYear(), today.getMonth(), today.getDate());
        var firstMonth = new Date(today.getFullYear(), today.getMonth(), 1);
        var lastEvent = events.length ? new Date(events[events.length - 1].e + 'T12:00:00') : today;
        events.forEach(function (ev) {
            var e = new Date(ev.e + 'T12:00:00');
            if (e > lastEvent) { lastEvent = e; }
        });
        var lastMonth = new Date(lastEvent.getFullYear(), lastEvent.getMonth(), 1);
        var current = new Date(firstMonth);
        var selected = byDay[todayKey] ? todayKey : null;

        function dayEventsHtml(k) {
            var list = byDay[k] || [];
            if (!list.length) {
                return '<p class="demiap-cal__hint">Nessun evento in questo giorno.</p>';
            }
            var html = '<h4 class="demiap-cal__day-title">' + escapeText(list[0].d === k ? list[0].g : formatDay(k)) + '</h4><ul class="demiap-events">';
            list.forEach(function (ev) {
                var meta = escapeText(ev.w) + (ev.l ? ' <span class="demiap-event__place"><span class="material-symbols-outlined" aria-hidden="true">location_on</span>' + escapeText(ev.l) + '</span>' : '');
                var summary = '<span class="demiap-event__info"><span class="demiap-event__title">' + escapeText(ev.t) + '</span><span class="demiap-event__meta">' + meta + '</span></span>';
                if (ev.h) {
                    html += '<li class="demiap-events__item"><details class="demiap-event" open><summary class="demiap-event__summary">' + summary +
                        '<span class="demiap-event__toggle" aria-hidden="true"></span></summary><div class="demiap-event__description demiap-event__description--cal">' + ev.h + '</div></details></li>';
                } else {
                    html += '<li class="demiap-events__item"><div class="demiap-event"><div class="demiap-event__summary">' + summary + '</div></div></li>';
                }
            });
            return html + '</ul>';
        }

        function formatDay(k) {
            var p = k.split('-');
            var d = new Date(+p[0], +p[1] - 1, +p[2]);
            var name = d.toLocaleDateString('it-CH', { weekday: 'long', day: 'numeric', month: 'long' });
            return name.charAt(0).toUpperCase() + name.slice(1);
        }

        function render() {
            var y = current.getFullYear();
            var m = current.getMonth();
            var offset = (new Date(y, m, 1).getDay() + 6) % 7; // lunedì = 0
            var daysInMonth = new Date(y, m + 1, 0).getDate();

            var html = '<div class="demiap-cal__head">' +
                '<button type="button" class="demiap-cal__nav" data-step="-1" aria-label="Mese precedente"' + (current <= firstMonth ? ' disabled' : '') + '><svg class="demiap-chevron" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M15 5l-7 7 7 7"/></svg></button>' +
                '<h4 class="demiap-cal__month" aria-live="polite">' + MONTHS[m] + ' ' + y + '</h4>' +
                '<button type="button" class="demiap-cal__nav" data-step="1" aria-label="Mese successivo"' + (current >= lastMonth ? ' disabled' : '') + '><svg class="demiap-chevron" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M9 5l7 7-7 7"/></svg></button>' +
                '</div><div class="demiap-cal__grid" role="grid">';
            DAYS.forEach(function (d) { html += '<span class="demiap-cal__dow" role="columnheader">' + d + '</span>'; });
            for (var i = 0; i < offset; i++) { html += '<span class="demiap-cal__cell demiap-cal__cell--empty"></span>'; }
            for (var day = 1; day <= daysInMonth; day++) {
                var k = key(y, m, day);
                var list = byDay[k] || [];
                var cls = 'demiap-cal__cell' + (k === todayKey ? ' is-today' : '') + (k < todayKey ? ' is-past' : '') + (list.length ? ' has-events' : '') + (k === selected ? ' is-selected' : '');
                if (list.length) {
                    var chips = '';
                    list.slice(0, 2).forEach(function (ev) { chips += '<span class="demiap-cal__chip">' + escapeText(ev.t) + '</span>'; });
                    if (list.length > 2) { chips += '<span class="demiap-cal__more">+' + (list.length - 2) + '</span>'; }
                    html += '<button type="button" class="' + cls + '" data-day="' + k + '" aria-pressed="' + (k === selected) + '" aria-label="' + escapeText(formatDay(k)) + ', ' + list.length + (list.length === 1 ? ' evento' : ' eventi') + '">' +
                        '<span class="demiap-cal__num">' + day + '</span><span class="demiap-cal__dot" aria-hidden="true"></span><span class="demiap-cal__chips" aria-hidden="true">' + chips + '</span></button>';
                } else {
                    html += '<span class="' + cls + '"><span class="demiap-cal__num">' + day + '</span></span>';
                }
            }
            html += '</div><div class="demiap-cal__details">' +
                (!events.length ? '<p class="demiap-cal__hint">Al momento non ci sono eventi in programma.</p>' : (selected && selected.slice(0, 7) === key(y, m, 1).slice(0, 7) ? dayEventsHtml(selected) : '<p class="demiap-cal__hint">Clicca un giorno evidenziato per vedere gli eventi.</p>')) +
                '</div>';
            cal.innerHTML = html;
        }

        cal.addEventListener('click', function (e) {
            var nav = e.target.closest('.demiap-cal__nav');
            if (nav && !nav.disabled) {
                current.setMonth(current.getMonth() + parseInt(nav.getAttribute('data-step'), 10));
                render();
                return;
            }
            var cell = e.target.closest('[data-day]');
            if (cell) {
                selected = cell.getAttribute('data-day');
                render();
                var focusCell = cal.querySelector('[data-day="' + selected + '"]');
                if (focusCell) { focusCell.focus(); }
            }
        });

        function show(view) {
            buttons.forEach(function (b) { b.setAttribute('aria-pressed', String(b.getAttribute('data-view') === view)); });
            panels.forEach(function (p) { p.hidden = p.getAttribute('data-view-panel') !== view; });
            if (view === 'calendar') { render(); }
            try { localStorage.setItem(STORAGE, view); } catch (e) { /* storage non disponibile */ }
        }

        buttons.forEach(function (b) {
            b.addEventListener('click', function () { show(b.getAttribute('data-view')); });
        });

        switcher.hidden = false;
        var saved = null;
        try { saved = localStorage.getItem(STORAGE); } catch (e) { saved = null; }
        show(saved === 'calendar' ? 'calendar' : 'list');
    });
})();
