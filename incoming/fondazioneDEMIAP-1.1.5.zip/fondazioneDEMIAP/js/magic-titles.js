document.addEventListener('DOMContentLoaded', function () {
    // --- Text Animate Script (Blur In Up by Character) ---
    const titles = document.querySelectorAll('.magic-title');
    const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('is-visible');
                observer.unobserve(entry.target); // esegue solo una volta ("once")
            }
        });
    }, { threshold: 0.1 });

    titles.forEach(title => {
        const childNodes = Array.from(title.childNodes);
        const fullText = childNodes.map(n => n.nodeName === 'BR' ? ' ' : n.textContent).join('').replace(/\s+/g, ' ').trim();
        title.innerHTML = '';

        // Il testo completo resta leggibile da screen reader e motori di ricerca;
        // i caratteri animati sono solo decorativi.
        const sr = document.createElement('span');
        sr.className = 'magic-sr';
        sr.textContent = fullText;
        title.appendChild(sr);

        let charIndex = 0;

        childNodes.forEach(node => {
            if (node.nodeType === Node.TEXT_NODE) {
                // Ogni parola è un blocco che non si spezza: a capo solo tra una parola e l'altra
                node.textContent.split(/(\s+)/).forEach(part => {
                    if (part === '') return;
                    if (/^\s+$/.test(part)) {
                        title.appendChild(document.createTextNode(' '));
                        return;
                    }
                    const word = document.createElement('span');
                    word.className = 'magic-word';
                    word.setAttribute('aria-hidden', 'true');
                    Array.from(part).forEach(char => {
                        const span = document.createElement('span');
                        span.textContent = char;
                        span.className = 'magic-char';
                        span.style.transitionDelay = `${charIndex * 0.03}s`;
                        word.appendChild(span);
                        charIndex++;
                    });
                    title.appendChild(word);
                });
            } else {
                // Mantieni eventuali tag <br> o <strong>
                title.appendChild(node.cloneNode(true));
            }
        });

        if (reduceMotion) {
            title.classList.add('is-visible');
        } else {
            observer.observe(title);
        }
    });

    // --- Hero Highlight Script (Mouse Tracking) ---
    const highlights = document.querySelectorAll('.hero-highlight');
    if (highlights.length && window.matchMedia('(hover: hover)').matches) {
        document.addEventListener('mousemove', (e) => {
            highlights.forEach((container) => {
                const rect = container.getBoundingClientRect();
                container.style.setProperty('--mouse-x', `${e.clientX - rect.left}px`);
                container.style.setProperty('--mouse-y', `${e.clientY - rect.top}px`);
            });
        }, { passive: true });
    }
});
