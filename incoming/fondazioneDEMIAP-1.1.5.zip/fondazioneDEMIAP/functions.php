<?php
/**
 * Fondazione DEMIAP child theme functions
 */

add_action('wp_enqueue_scripts', 'fondazionedemiap_enqueue_styles', 20);
function fondazionedemiap_enqueue_styles()
{
    // Enqueue parent theme stylesheet
    wp_enqueue_style('ticinoweb-parent-style', get_template_directory_uri() . '/style.css', array(), '1.0.0');

    // Google Font in una sola richiesta: Playfair Display (titoli), Plus Jakarta Sans (testo), Material Symbols (icone)
    wp_enqueue_style('fondazionedemiap-google-fonts', 'https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,600;0,700;1,400&family=Plus+Jakarta+Sans:ital,wght@0,200..800;1,200..800&family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&display=swap', array(), null);

    // Carica libreria AOS per animazioni su scroll
    wp_enqueue_style('aos-css', 'https://unpkg.com/aos@2.3.1/dist/aos.css', array(), '2.3.1');
    wp_enqueue_script('aos-js', 'https://unpkg.com/aos@2.3.1/dist/aos.js', array(), '2.3.1', true);

    // Enqueue Tailwind stylesheet
    wp_enqueue_style('fondazionedemiap-tailwind-style', get_stylesheet_directory_uri() . '/assets/css/tailwind.css', array(), filemtime(get_stylesheet_directory() . '/assets/css/tailwind.css'));

    // Enqueue child theme stylesheet (loads after parent and fonts)
    wp_enqueue_style('fondazionedemiap-child-style', get_stylesheet_directory_uri() . '/style.css', array('ticinoweb-parent-style', 'fondazionedemiap-google-fonts', 'aos-css', 'fondazionedemiap-tailwind-style'), wp_get_theme()->get('Version'));

    // Enqueue magic titles script
    wp_enqueue_script('fondazionedemiap-magic-titles', get_stylesheet_directory_uri() . '/js/magic-titles.js', array(), wp_get_theme()->get('Version'), true);

    // Modulo contatti: invia al gestore del parent (Invii Ricevuti, antispam, reCAPTCHA). Dipende da ticinoweb-ai-main, che riceve ajax_url e chiavi.
    wp_enqueue_script('fondazionedemiap-contact-form', get_stylesheet_directory_uri() . '/js/contact-form.js', array('ticinoweb-ai-main'), wp_get_theme()->get('Version'), true);

    // Link «Preferenze cookie» del footer: solo se il banner del parent è attivo
    if (get_option('tw_cookie_banner_enable')) {
        wp_enqueue_script('fondazionedemiap-cookie-preferences', get_stylesheet_directory_uri() . '/js/cookie-preferences.js', array(), wp_get_theme()->get('Version'), true);
    }
}

// Il parent carica get_stylesheet_uri() (cioè il style.css del child) come «ticinoweb-ai-style»:
// lo teniamo come alias senza file, così il child non viene scaricato due volte.
add_action('wp_enqueue_scripts', 'fondazionedemiap_single_child_stylesheet', 100);
function fondazionedemiap_single_child_stylesheet()
{
    wp_dequeue_style('ticinoweb-ai-style');
    wp_deregister_style('ticinoweb-ai-style');
    wp_register_style('ticinoweb-ai-style', false, array('poppins-font', 'fondazionedemiap-child-style'));
    wp_enqueue_style('ticinoweb-ai-style');
}

if (file_exists(get_stylesheet_directory() . '/inc/admin-attivita.php')) {
    require_once get_stylesheet_directory() . '/inc/admin-attivita.php';
}

// Bacheca Info Point (articoli standard) e Gallerie (Gallerie media del parent)
require_once get_stylesheet_directory() . '/inc/bacheca.php';
require_once get_stylesheet_directory() . '/inc/gallerie.php';
require_once get_stylesheet_directory() . '/inc/agenda.php';

// Genera automaticamente il menu One Page la prima volta se non esiste
function fondazionedemiap_setup_default_menu() {
    $menu_name = 'Menu DEMIAP';
    $menu_exists = wp_get_nav_menu_object( $menu_name );

    if( ! $menu_exists ){
        $menu_id = wp_create_nav_menu($menu_name);

        $items = [
            ['Home', '#home'],
            ['La Fondazione', '#fondazionetesto'],
            ['Chi Siamo', '#chisiamo'],
            ['Attività', '#attivitasociali'],
            ['Agenda', '#agenda'],
            ['Contatti', '#contatti'],
            ['Dona', '#donazioni']
        ];

        foreach ($items as $item) {
            wp_update_nav_menu_item($menu_id, 0, array(
                'menu-item-title' => $item[0],
                'menu-item-url' => home_url( '/' ) . $item[1], 
                'menu-item-status' => 'publish'
            ));
        }

        // Assegna il menu creato alla location "primary" se il tema genitore la espone
        $locations = get_theme_mod('nav_menu_locations');
        if (!is_array($locations)) {
            $locations = array();
        }
        $locations['primary'] = $menu_id;
        set_theme_mod('nav_menu_locations', $locations);
    }
}
add_action('init', 'fondazionedemiap_setup_default_menu');

 

/**
 * ID di un file della libreria Media cercato per slug (es. «sfondo-animato-hero-demiap-loop»).
 * 0 se il file non c'è.
 */
function fondazionedemiap_media_id_by_name($name, $mime)
{
    $key = 'media_id_' . $name;
    $id = wp_cache_get($key, 'fondazionedemiap');
    if (false === $id) {
        $ids = get_posts(array(
            'post_type'      => 'attachment',
            'post_status'    => 'inherit',
            'name'           => $name,
            'post_mime_type' => $mime,
            'posts_per_page' => 1,
            'fields'         => 'ids',
        ));
        $id = $ids ? (int) $ids[0] : 0;
        wp_cache_set($key, $id, 'fondazionedemiap', HOUR_IN_SECONDS);
    }
    return (int) $id;
}

/**
 * URL di un file della libreria Media cercato per slug. Stringa vuota se il file non c'è.
 */
function fondazionedemiap_media_url_by_name($name, $mime)
{
    $id = fondazionedemiap_media_id_by_name($name, $mime);
    return $id ? (string) wp_get_attachment_url($id) : '';
}

/**
 * Foto di un responsabile nella pagina Chi siamo, dalla libreria Media
 * (immagine con slug «milco-margaroli» / «daniela-margaroli»). Se manca non stampa nulla.
 */
function fondazionedemiap_team_photo($name, $alt)
{
    $id = fondazionedemiap_media_id_by_name($name, 'image');
    if ($id) {
        echo wp_get_attachment_image($id, 'medium_large', false, array(
            'class'   => 'demiap-team-photo',
            'alt'     => $alt,
            'sizes'   => '160px',
            'loading' => 'lazy',
        ));
    }
}

/**
 * Video della hero e sua immagine di copertina (poster): stanno nella libreria Media (non nel tema,
 * che l'aggiornamento sostituisce). Per cambiarli basta caricare in Media un video
 * «sfondo-animato-hero-demiap-loop» e un'immagine «sfondo-animato-hero-demiap-poster».
 * Filtri: demiap_hero_video_url, demiap_hero_poster_url.
 */
function fondazionedemiap_hero_video_url()
{
    return (string) apply_filters('demiap_hero_video_url', fondazionedemiap_media_url_by_name('sfondo-animato-hero-demiap-loop', 'video'));
}

function fondazionedemiap_hero_poster_url()
{
    return (string) apply_filters('demiap_hero_poster_url', fondazionedemiap_media_url_by_name('sfondo-animato-hero-demiap-poster', 'image'));
}

/**
 * Profili social da mostrare nel footer: quelli compilati in ticinoWEB CMS → Contatti
 * (ticinoweb_contact_facebook, _instagram, _linkedin, _youtube, _x, _tiktok), nell'ordine qui sotto.
 * Un campo vuoto non mostra il pulsante. Icone: Simple Icons (CC0).
 *
 * @return array<int, array{label:string, url:string, color:string, path:string}>
 */
function fondazionedemiap_social_links()
{
    $networks = array(
        'facebook'  => array('Facebook', '#1877F2', 'M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.469h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.469h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z'),
        'instagram' => array('Instagram', '#E1306C', 'M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zM12 0C8.741 0 8.333.014 7.053.072 2.695.272.273 2.69.073 7.052.014 8.333 0 8.741 0 12c0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98C8.333 23.986 8.741 24 12 24c3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98C15.668.014 15.259 0 12 0zm0 5.838a6.162 6.162 0 100 12.324 6.162 6.162 0 000-12.324zM12 16a4 4 0 110-8 4 4 0 010 8zm6.406-11.845a1.44 1.44 0 100 2.881 1.44 1.44 0 000-2.881z'),
        'youtube'   => array('YouTube', '#FF0000', 'M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z'),
        'linkedin'  => array('LinkedIn', '#0A66C2', 'M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433a2.062 2.062 0 01-2.063-2.065 2.064 2.064 0 112.063 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z'),
        'tiktok'    => array('TikTok', '#000000', 'M12.525.02c1.31-.02 2.61-.01 3.91-.02.08 1.53.63 3.09 1.75 4.17 1.12 1.11 2.7 1.62 4.24 1.79v4.03c-1.44-.05-2.89-.35-4.2-.97-.57-.26-1.1-.59-1.62-.93-.01 2.92.01 5.84-.02 8.75-.08 1.4-.54 2.79-1.35 3.94-1.31 1.92-3.58 3.17-5.91 3.21-1.43.08-2.86-.31-4.08-1.03-2.02-1.19-3.44-3.37-3.65-5.71-.02-.5-.03-1-.01-1.49.18-1.9 1.12-3.72 2.58-4.96 1.66-1.44 3.98-2.13 6.15-1.72.02 1.48-.04 2.96-.04 4.44-.99-.32-2.15-.23-3.02.37-.63.41-1.11 1.04-1.36 1.75-.21.51-.15 1.07-.14 1.61.24 1.64 1.82 3.02 3.5 2.87 1.12-.01 2.19-.66 2.77-1.61.19-.33.4-.67.41-1.06.1-1.79.06-3.57.07-5.36.01-4.03-.01-8.05.02-12.07z'),
        'x'         => array('X', '#000000', 'M18.901 1.153h3.68l-8.04 9.19L24 22.846h-7.406l-5.8-7.584-6.638 7.584H.474l8.6-9.83L0 1.154h7.594l5.243 6.932ZM17.61 20.644h2.039L6.486 3.24H4.298Z'),
    );

    $links = array();
    foreach ($networks as $key => $network) {
        $url = trim((string) get_option('ticinoweb_contact_' . $key));
        if ('' === $url || !wp_http_validate_url($url)) {
            continue;
        }
        $links[] = array('label' => $network[0], 'url' => $url, 'color' => $network[1], 'path' => $network[2]);
    }
    return $links;
}
