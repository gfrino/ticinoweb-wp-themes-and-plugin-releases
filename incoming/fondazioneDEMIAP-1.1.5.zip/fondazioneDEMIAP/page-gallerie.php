<?php
/**
 * Pagina «Gallerie» (slug gallerie): elenco delle Gallerie media del parent;
 * con ?galleria=<slug> mostra le foto di una galleria.
 */

get_header();

$galleries = demiap_galleries();
$current   = null;
if (isset($_GET['galleria'])) {
    $slug = sanitize_title(wp_unslash($_GET['galleria']));
    foreach ($galleries as $term) {
        if ($term->slug === $slug) {
            $current = $term;
            break;
        }
    }
}
?>
<section class="demiap-page-band" id="gallerie">
    <div class="demiap-gallery-page">
        <?php if ($current) : ?>
            <p class="demiap-gallery-page__back">
                <a href="<?php echo esc_url(get_permalink()); ?>"><span aria-hidden="true">&larr;</span> Tutte le gallerie</a>
            </p>
            <h1 class="demiap-section-title"><?php echo esc_html($current->name); ?></h1>
            <?php if ($current->description) : ?>
                <div class="demiap-gallery-page__intro"><?php echo wpautop(wp_kses_post($current->description)); ?></div>
            <?php endif; ?>

            <ul class="demiap-photo-grid">
                <?php foreach (demiap_gallery_image_ids($current->term_id) as $id) :
                    $full = wp_get_attachment_image_url($id, 'large');
                    if (!$full) {
                        continue;
                    }
                    ?>
                    <li class="demiap-photo-grid__item">
                        <a href="<?php echo esc_url($full); ?>" data-demiap-lightbox="galleria-<?php echo esc_attr($current->term_id); ?>">
                            <?php echo wp_get_attachment_image($id, 'medium_large', false, array(
                                'loading' => 'lazy',
                                'alt'     => demiap_gallery_alt($id, $current->name),
                                'sizes'   => '(min-width: 1024px) 300px, (min-width: 640px) 33vw, 50vw',
                            )); ?>
                        </a>
                    </li>
                <?php endforeach; ?>
            </ul>
        <?php else : ?>
            <?php while (have_posts()) : the_post(); ?>
                <h1 class="demiap-section-title"><?php the_title(); ?></h1>
                <?php if (trim(get_the_content())) : ?>
                    <div class="demiap-gallery-page__intro"><?php the_content(); ?></div>
                <?php endif; ?>
            <?php endwhile; ?>

            <?php if (empty($galleries)) : ?>
                <p class="demiap-gallery-page__empty">Le gallerie fotografiche saranno pubblicate presto.</p>
            <?php else : ?>
                <ul class="demiap-gallery-cards">
                    <?php foreach ($galleries as $term) :
                        $cover = demiap_gallery_image_ids($term->term_id, 1);
                        ?>
                        <li>
                            <a class="demiap-gallery-card" href="<?php echo esc_url(add_query_arg('galleria', $term->slug, get_permalink())); ?>">
                                <span class="demiap-gallery-card__cover">
                                    <?php if ($cover) {
                                        echo wp_get_attachment_image($cover[0], 'medium_large', false, array(
                                            'loading' => 'lazy',
                                            'alt'     => '',
                                            'sizes'   => '(min-width: 1024px) 380px, (min-width: 640px) 50vw, 100vw',
                                        ));
                                    } ?>
                                </span>
                                <span class="demiap-gallery-card__name"><?php echo esc_html($term->name); ?></span>
                                <span class="demiap-gallery-card__count"><?php echo esc_html(sprintf(_n('%d foto', '%d foto', $term->count, 'fondazionedemiap'), $term->count)); ?></span>
                            </a>
                        </li>
                    <?php endforeach; ?>
                </ul>
            <?php endif; ?>
        <?php endif; ?>
    </div>
</section>

<?php get_footer(); ?>
