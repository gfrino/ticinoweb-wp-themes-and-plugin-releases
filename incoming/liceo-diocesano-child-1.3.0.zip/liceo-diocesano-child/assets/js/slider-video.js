( function () {
    var videos = ( window.liceoSliderVideo || {} ).videos || {};
    var slides = document.querySelectorAll( '.hero-slider .slide' );
    var still = window.matchMedia && window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches;
    if ( still ) {
        return; // con movimento ridotto resta la foto
    }
    Object.keys( videos ).forEach( function ( k ) {
        var slide = slides[ parseInt( k, 10 ) ];
        var img = slide && slide.querySelector( '.slide-image' );
        if ( ! img ) {
            return;
        }
        var v = document.createElement( 'video' );
        v.className = 'slide-image slide-video';
        v.muted = true;
        v.loop = true;
        v.autoplay = true;
        v.playsInline = true;
        v.setAttribute( 'playsinline', '' );
        v.setAttribute( 'muted', '' );
        v.setAttribute( 'aria-hidden', 'true' );
        v.preload = 'metadata';
        v.poster = img.currentSrc || img.src;
        v.src = videos[ k ];
        img.parentNode.insertBefore( v, img.nextSibling );
        v.addEventListener( 'playing', function () { img.style.visibility = 'hidden'; } );
        var p = v.play();
        if ( p && p.catch ) {
            p.catch( function () {} ); // se il browser blocca l'avvio resta la foto
        }
    } );
} )();
