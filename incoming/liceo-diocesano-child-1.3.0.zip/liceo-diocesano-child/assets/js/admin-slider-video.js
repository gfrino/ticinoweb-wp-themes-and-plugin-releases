( function ( $ ) {
    var cfg = window.liceoSliderVideo || { values: {}, i18n: {} };
    var t = cfg.i18n;

    function addRow( $item, num ) {
        if ( $item.find( '.ld-video-row' ).length ) {
            return;
        }
        var val = cfg.values[ num ] || '';
        var $row = $(
            '<tr class="ld-video-row"><th scope="row"><label></label></th><td>' +
            '<input type="text" class="regular-text ld-video-url" readonly>' +
            ' <button type="button" class="button button-secondary ld-video-choose"></button>' +
            ' <button type="button" class="button-link-delete ld-video-remove"></button>' +
            '<p class="description ld-video-status"></p>' +
            '<p class="description"></p></td></tr>'
        );
        $row.find( 'label' ).text( t.label );
        $row.find( '.ld-video-choose' ).text( t.choose );
        $row.find( '.ld-video-remove' ).text( t.remove );
        $row.find( 'p.description' ).last().text( t.hint );
        $row.find( '.ld-video-url' ).attr( 'name', 'ld_slider_video_' + num ).val( val );
        $item.find( 'table.form-table tr' ).first().after( $row );
        refresh( $row );
    }

    function refresh( $row ) {
        var v = $row.find( '.ld-video-url' ).val();
        $row.find( '.ld-video-remove' ).toggle( !! v );
        $row.find( '.ld-video-status' ).text( v ? v.split( '/' ).pop() : t.none );
    }

    $( function () {
        $( '#slider-items-container .slider-item' ).each( function () {
            addRow( $( this ), parseInt( $( this ).attr( 'data-slide' ), 10 ) );
        } );

        $( document ).on( 'click', '.ld-video-choose', function () {
            var $row = $( this ).closest( '.ld-video-row' );
            var frame = wp.media( { title: t.title, library: { type: 'video' }, multiple: false } );
            frame.on( 'select', function () {
                $row.find( '.ld-video-url' ).val( frame.state().get( 'selection' ).first().toJSON().url );
                refresh( $row );
            } );
            frame.open();
        } );

        $( document ).on( 'click', '.ld-video-remove', function () {
            var $row = $( this ).closest( '.ld-video-row' );
            $row.find( '.ld-video-url' ).val( '' );
            refresh( $row );
        } );

        // Il CMS rinumera le slide quando si spostano: i nomi dei campi video seguono la posizione.
        $( 'form' ).on( 'submit', function () {
            $( '#slider-items-container .slider-item' ).each( function ( idx ) {
                $( this ).find( '.ld-video-url' ).attr( 'name', 'ld_slider_video_' + ( idx + 1 ) );
            } );
        } );
    } );
} )( jQuery );
