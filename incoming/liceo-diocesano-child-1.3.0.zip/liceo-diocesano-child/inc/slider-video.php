<?php
/**
 * Video al posto della foto nelle slide della home.
 *
 * Il parent (ticinoWEB CMS → Slider & Partner) gestisce solo la foto. Qui si aggiunge, per ogni slide, un campo
 * «Video» (mp4/webm dalla Libreria media) salvato con lo stesso pulsante «Salva» del CMS. La foto della slide
 * resta obbligatoria: è l'immagine mostrata mentre il video si carica e per chi ha il movimento ridotto.
 *
 * @package liceo-diocesano-child
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

const LICEO_DIOCESANO_SLIDES = 5;

function liceo_diocesano_register_video_settings() {
    for ( $i = 1; $i <= LICEO_DIOCESANO_SLIDES; $i++ ) {
        register_setting( 'ticinoweb_settings_group', "ld_slider_video_$i", array(
            'type'              => 'string',
            'sanitize_callback' => 'liceo_diocesano_sanitize_video_url',
            'default'           => '',
        ) );
    }
}
add_action( 'admin_init', 'liceo_diocesano_register_video_settings' );

function liceo_diocesano_sanitize_video_url( $value ) {
    $url = esc_url_raw( (string) $value );
    if ( '' === $url ) {
        return '';
    }
    $type = wp_check_filetype( wp_parse_url( $url, PHP_URL_PATH ) );
    return in_array( $type['ext'], array( 'mp4', 'webm' ), true ) ? $url : '';
}

function liceo_diocesano_admin_slider_video( $hook ) {
    if ( false === strpos( (string) $hook, 'ticinoweb-cms' ) ) {
        return;
    }
    wp_enqueue_media();
    $file   = get_stylesheet_directory() . '/assets/js/admin-slider-video.js';
    $values = array();
    for ( $i = 1; $i <= LICEO_DIOCESANO_SLIDES; $i++ ) {
        $values[ $i ] = (string) get_option( "ld_slider_video_$i", '' );
    }
    wp_enqueue_script( 'liceo-slider-video-admin', get_stylesheet_directory_uri() . '/assets/js/admin-slider-video.js', array( 'jquery' ), filemtime( $file ), true );
    wp_localize_script( 'liceo-slider-video-admin', 'liceoSliderVideo', array(
        'values' => $values,
        'i18n'   => array(
            'label'  => __( 'Video (al posto della foto)', 'liceo-diocesano-child' ),
            'choose' => __( 'Scegli video', 'liceo-diocesano-child' ),
            'remove' => __( 'Rimuovi video', 'liceo-diocesano-child' ),
            'title'  => __( 'Scegli un video MP4 o WebM', 'liceo-diocesano-child' ),
            'hint'   => __( 'Facoltativo. Parte da solo, senza audio e in loop. Meglio MP4 (H.264) sotto i 10 MB, senza audio. La foto qui sopra resta come immagine di attesa.', 'liceo-diocesano-child' ),
            'none'   => __( 'Nessun video: si vede la foto.', 'liceo-diocesano-child' ),
        ),
    ) );
}
add_action( 'admin_enqueue_scripts', 'liceo_diocesano_admin_slider_video' );

/**
 * Front-end: elenco dei video, nello stesso ordine delle slide che il parent stampa
 * (il parent salta le slide senza foto).
 */
function liceo_diocesano_front_slider_video() {
    if ( ! is_front_page() ) {
        return;
    }
    $count = max( 1, min( LICEO_DIOCESANO_SLIDES, (int) get_option( 'ticinoweb_slider_count', 3 ) ) );
    $map   = array();
    $pos   = 0;
    for ( $i = 1; $i <= $count; $i++ ) {
        if ( ! get_option( "ticinoweb_slider_image_$i" ) ) {
            continue;
        }
        $video = (string) get_option( "ld_slider_video_$i", '' );
        if ( $video ) {
            $map[ $pos ] = esc_url_raw( $video );
        }
        $pos++;
    }
    if ( ! $map ) {
        return;
    }
    $file = get_stylesheet_directory() . '/assets/js/slider-video.js';
    wp_enqueue_script( 'liceo-slider-video', get_stylesheet_directory_uri() . '/assets/js/slider-video.js', array(), filemtime( $file ), true );
    wp_localize_script( 'liceo-slider-video', 'liceoSliderVideo', array( 'videos' => (object) $map ) );
}
add_action( 'wp_enqueue_scripts', 'liceo_diocesano_front_slider_video', 30 );
