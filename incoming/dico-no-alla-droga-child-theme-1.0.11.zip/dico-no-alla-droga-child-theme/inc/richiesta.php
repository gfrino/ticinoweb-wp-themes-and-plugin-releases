<?php
/**
 * Modulo «Richiedi materiale / conferenziere»: [dnd_richiesta_materiale].
 *
 * Usa il gestore del parent (inc/form-handler.php): token fresco via AJAX (le pagine sono in cache),
 * honeypot, limite per IP, reCAPTCHA v3 con le chiavi del CMS, salvataggio in «Invii Ricevuti» e
 * e-mail all'indirizzo di contatto del sito. Il child aggiunge solo i campi della richiesta con i filtri
 * del parent: i dati extra confluiscono nel messaggio (così restano nello storico e nell'e-mail).
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Le richieste di questo modulo si riconoscono dal campo nascosto dnd_form.
 */
function dnd_is_richiesta_request($post) {
    return isset($post['dnd_form']) && $post['dnd_form'] === 'richiesta';
}

function dnd_post_text($post, $key) {
    return isset($post[$key]) ? sanitize_text_field(wp_unslash($post[$key])) : '';
}

/**
 * Opuscoli scelti: solo ID che esistono davvero tra gli opuscoli pubblicati.
 *
 * @return string[] Titoli.
 */
function dnd_requested_booklets($post) {
    $ids = isset($post['opuscoli']) ? array_map('absint', (array) wp_unslash($post['opuscoli'])) : array();
    $titles = array();
    foreach (dnd_get_opuscoli() as $p) {
        if (in_array((int) $p->ID, $ids, true)) {
            $titles[] = get_the_title($p);
        }
    }
    return $titles;
}

function dnd_requested_types($post) {
    $allowed = array('materiale', 'conferenziere');
    $types   = isset($post['tipo']) ? array_map('sanitize_key', (array) wp_unslash($post['tipo'])) : array();
    return array_values(array_intersect($allowed, $types));
}

add_filter('ticinoweb_form_fields', function ($fields, $post) {
    if (!dnd_is_richiesta_request($post)) {
        return $fields;
    }
    $types    = dnd_requested_types($post);
    $ente     = dnd_post_text($post, 'ente_nome');
    $ente_tipo = dnd_post_text($post, 'ente_tipo');
    $booklets = dnd_requested_booklets($post);

    $fields['nome'] = dnd_post_text($post, 'nome');

    $what = array();
    if (in_array('materiale', $types, true)) {
        $what[] = __('materiale', 'dico-no-alla-droga-child-theme');
    }
    if (in_array('conferenziere', $types, true)) {
        $what[] = __('conferenziere', 'dico-no-alla-droga-child-theme');
    }
    $fields['oggetto'] = sprintf(
        /* translators: 1: what is requested, 2: school/association name */
        __('Richiesta di %1$s – %2$s', 'dico-no-alla-droga-child-theme'),
        implode(' + ', $what),
        $ente
    );

    $lines = array();
    $lines[] = __('Cosa richiede', 'dico-no-alla-droga-child-theme') . ': ' . implode(', ', $what);
    $lines[] = ($ente_tipo !== '' ? $ente_tipo : __('Scuola / associazione', 'dico-no-alla-droga-child-theme')) . ': ' . $ente;
    if (in_array('materiale', $types, true)) {
        $lines[] = '';
        $lines[] = __('OPUSCOLI RICHIESTI', 'dico-no-alla-droga-child-theme');
        foreach ($booklets as $t) {
            $lines[] = '- ' . $t;
        }
        $lines[] = __('Copie per opuscolo', 'dico-no-alla-droga-child-theme') . ': ' . dnd_post_text($post, 'copie');
        $lines[] = __('Indirizzo di spedizione', 'dico-no-alla-droga-child-theme') . ': ' . dnd_post_text($post, 'indirizzo') . ', ' . dnd_post_text($post, 'cap') . ' ' . dnd_post_text($post, 'localita');
    }
    if (in_array('conferenziere', $types, true)) {
        $lines[] = '';
        $lines[] = __('CONFERENZA', 'dico-no-alla-droga-child-theme');
        $lines[] = __('Data o periodo desiderato', 'dico-no-alla-droga-child-theme') . ': ' . dnd_post_text($post, 'data_conf');
        $lines[] = __('Luogo', 'dico-no-alla-droga-child-theme') . ': ' . dnd_post_text($post, 'luogo');
        $lines[] = __('Numero di partecipanti', 'dico-no-alla-droga-child-theme') . ': ' . dnd_post_text($post, 'partecipanti');
        $lines[] = __('A chi è rivolta (classi, età)', 'dico-no-alla-droga-child-theme') . ': ' . dnd_post_text($post, 'destinatari');
    }
    $note = isset($post['note']) ? sanitize_textarea_field(wp_unslash($post['note'])) : '';
    if ($note !== '') {
        $lines[] = '';
        $lines[] = __('NOTE', 'dico-no-alla-droga-child-theme');
        $lines[] = $note;
    }
    $fields['messaggio'] = implode("\n", $lines);
    return $fields;
}, 10, 2);

add_filter('ticinoweb_form_errors', function ($errors, $fields, $post) {
    if (!dnd_is_richiesta_request($post)) {
        return $errors;
    }
    // Il parent controlla nome, e-mail e messaggio; qui i campi del modulo di richiesta.
    $types = dnd_requested_types($post);
    if (!$types) {
        $errors['tipo'] = __('Scegli almeno una cosa: materiale o conferenziere.', 'dico-no-alla-droga-child-theme');
    }
    if (dnd_post_text($post, 'ente_nome') === '') {
        $errors['ente_nome'] = __('Indica il nome della scuola o dell’associazione.', 'dico-no-alla-droga-child-theme');
    }
    if (empty($post['privacy'])) {
        $errors['privacy'] = __('Per inviare la richiesta devi accettare l’informativa sulla privacy.', 'dico-no-alla-droga-child-theme');
    }
    if (in_array('materiale', $types, true)) {
        if (!dnd_requested_booklets($post)) {
            $errors['opuscoli'] = __('Scegli almeno un opuscolo.', 'dico-no-alla-droga-child-theme');
        }
        if ((int) dnd_post_text($post, 'copie') < 1) {
            $errors['copie'] = __('Indica quante copie ti servono.', 'dico-no-alla-droga-child-theme');
        }
        foreach (array('indirizzo' => __('Indica l’indirizzo di spedizione.', 'dico-no-alla-droga-child-theme'), 'cap' => __('Indica il CAP.', 'dico-no-alla-droga-child-theme'), 'localita' => __('Indica la località.', 'dico-no-alla-droga-child-theme')) as $k => $msg) {
            if (dnd_post_text($post, $k) === '') {
                $errors[$k] = $msg;
            }
        }
    }
    if (in_array('conferenziere', $types, true)) {
        if (dnd_post_text($post, 'luogo') === '') {
            $errors['luogo'] = __('Indica dove si terrebbe la conferenza.', 'dico-no-alla-droga-child-theme');
        }
        if ((int) dnd_post_text($post, 'partecipanti') < 1) {
            $errors['partecipanti'] = __('Indica quante persone parteciperanno.', 'dico-no-alla-droga-child-theme');
        }
    }
    return $errors;
}, 10, 3);

add_filter('ticinoweb_form_success_message', function ($message, $fields) {
    // Il messaggio standard del parent va bene per i contatti; per la richiesta è più preciso.
    if (isset($fields['oggetto']) && strpos((string) $fields['oggetto'], __('Richiesta di', 'dico-no-alla-droga-child-theme')) === 0) {
        return __('Grazie! Abbiamo ricevuto la tua richiesta e ti risponderemo per e-mail il prima possibile.', 'dico-no-alla-droga-child-theme');
    }
    return $message;
}, 10, 2);

/**
 * Script del modulo: caricato solo dove lo shortcode è presente.
 */
function dnd_enqueue_richiesta_assets() {
    static $done = false;
    if ($done) {
        return;
    }
    $done = true;
    $key  = (string) get_option('ticinoweb_recaptcha_site_key', '');
    $deps = array();
    if ($key !== '') {
        wp_enqueue_script('google-recaptcha-v3', 'https://www.google.com/recaptcha/api.js?render=' . rawurlencode($key), array(), null, true);
        $deps[] = 'google-recaptcha-v3';
    }
    $path = get_stylesheet_directory() . '/assets/js/richiesta.js';
    wp_enqueue_script('dnd-richiesta', get_stylesheet_directory_uri() . '/assets/js/richiesta.js', $deps, file_exists($path) ? filemtime($path) : DND_THEME_VERSION, true);
    wp_localize_script('dnd-richiesta', 'dndRichiesta', array(
        'ajax_url'           => admin_url('admin-ajax.php'),
        'token_action'       => 'ticinoweb_form_token',
        'submit_action'      => 'ticinoweb_submit_form',
        'recaptcha_site_key' => $key,
        'i18n'               => array(
            'sending' => __('Invio in corso…', 'dico-no-alla-droga-child-theme'),
            'error'   => __('Non siamo riusciti a inviare la richiesta. Riprova tra poco o scrivici per e-mail.', 'dico-no-alla-droga-child-theme'),
            'check'   => __('Controlla i campi evidenziati.', 'dico-no-alla-droga-child-theme'),
        ),
    ));
}

add_shortcode('dnd_richiesta_materiale', function () {
    dnd_enqueue_richiesta_assets();
    $booklets = dnd_get_opuscoli();
    $privacy  = function_exists('get_privacy_policy_url') ? get_privacy_policy_url() : '';
    ob_start();
    ?>
    <form class="dnd-form" id="dnd-richiesta-form" method="post" novalidate data-dnd-form>
        <input type="hidden" name="dnd_form" value="richiesta">
        <div class="dnd-hp" aria-hidden="true"><label>Non compilare<input type="text" name="tw_hp" tabindex="-1" autocomplete="off"></label></div>

        <fieldset class="dnd-fieldset">
            <legend><span class="dnd-step">1</span> <?php esc_html_e('Cosa ti serve?', 'dico-no-alla-droga-child-theme'); ?></legend>
            <div class="dnd-choice-cards" data-field="tipo">
                <label class="dnd-choice">
                    <input type="checkbox" name="tipo[]" value="materiale" checked>
                    <span class="dnd-choice__body">
                        <strong><?php esc_html_e('Materiale informativo', 'dico-no-alla-droga-child-theme'); ?></strong>
                        <span><?php esc_html_e('Copie stampate degli opuscoli «La verità sulla droga».', 'dico-no-alla-droga-child-theme'); ?></span>
                    </span>
                </label>
                <label class="dnd-choice">
                    <input type="checkbox" name="tipo[]" value="conferenziere">
                    <span class="dnd-choice__body">
                        <strong><?php esc_html_e('Un conferenziere', 'dico-no-alla-droga-child-theme'); ?></strong>
                        <span><?php esc_html_e('Un incontro di prevenzione nella tua scuola o associazione.', 'dico-no-alla-droga-child-theme'); ?></span>
                    </span>
                </label>
            </div>
            <p class="dnd-error" data-error-for="tipo" role="alert"></p>
        </fieldset>

        <fieldset class="dnd-fieldset">
            <legend><span class="dnd-step">2</span> <?php esc_html_e('Chi sei?', 'dico-no-alla-droga-child-theme'); ?></legend>
            <div class="dnd-grid-2">
                <div class="dnd-field">
                    <label for="dnd-ente-tipo"><?php esc_html_e('Tipo di ente', 'dico-no-alla-droga-child-theme'); ?></label>
                    <select id="dnd-ente-tipo" name="ente_tipo">
                        <option><?php esc_html_e('Scuola', 'dico-no-alla-droga-child-theme'); ?></option>
                        <option><?php esc_html_e('Associazione', 'dico-no-alla-droga-child-theme'); ?></option>
                        <option><?php esc_html_e('Altro', 'dico-no-alla-droga-child-theme'); ?></option>
                    </select>
                </div>
                <div class="dnd-field">
                    <label for="dnd-ente-nome"><?php esc_html_e('Nome della scuola o associazione', 'dico-no-alla-droga-child-theme'); ?> *</label>
                    <input id="dnd-ente-nome" name="ente_nome" type="text" required autocomplete="organization">
                    <p class="dnd-error" data-error-for="ente_nome" role="alert"></p>
                </div>
                <div class="dnd-field">
                    <label for="dnd-nome"><?php esc_html_e('Il tuo nome e cognome', 'dico-no-alla-droga-child-theme'); ?> *</label>
                    <input id="dnd-nome" name="nome" type="text" required autocomplete="name">
                    <p class="dnd-error" data-error-for="nome" role="alert"></p>
                </div>
                <div class="dnd-field">
                    <label for="dnd-email"><?php esc_html_e('E-mail', 'dico-no-alla-droga-child-theme'); ?> *</label>
                    <input id="dnd-email" name="email" type="email" required autocomplete="email">
                    <p class="dnd-error" data-error-for="email" role="alert"></p>
                </div>
                <div class="dnd-field">
                    <label for="dnd-telefono"><?php esc_html_e('Telefono (facoltativo)', 'dico-no-alla-droga-child-theme'); ?></label>
                    <input id="dnd-telefono" name="telefono" type="tel" autocomplete="tel">
                </div>
            </div>
        </fieldset>

        <fieldset class="dnd-fieldset" data-dnd-when="materiale">
            <legend><span class="dnd-step">3</span> <?php esc_html_e('Il materiale', 'dico-no-alla-droga-child-theme'); ?></legend>
            <?php if ($booklets) : ?>
                <p class="dnd-hint"><?php esc_html_e('Scegli gli opuscoli che vuoi ricevere:', 'dico-no-alla-droga-child-theme'); ?></p>
                <div class="dnd-booklet-picker" data-field="opuscoli">
                    <?php foreach ($booklets as $p) : ?>
                        <label class="dnd-pick">
                            <input type="checkbox" name="opuscoli[]" value="<?php echo esc_attr($p->ID); ?>">
                            <span>
                                <?php if (has_post_thumbnail($p)) { echo get_the_post_thumbnail($p, 'full', array('loading' => 'lazy', 'alt' => '')); } ?>
                                <em><?php echo esc_html(get_the_title($p)); ?></em>
                            </span>
                        </label>
                    <?php endforeach; ?>
                </div>
                <p class="dnd-error" data-error-for="opuscoli" role="alert"></p>
            <?php endif; ?>
            <div class="dnd-grid-2">
                <div class="dnd-field">
                    <label for="dnd-copie"><?php esc_html_e('Quante copie per ogni opuscolo?', 'dico-no-alla-droga-child-theme'); ?> *</label>
                    <input id="dnd-copie" name="copie" type="number" min="1" max="1000" inputmode="numeric">
                    <p class="dnd-error" data-error-for="copie" role="alert"></p>
                </div>
                <div class="dnd-field">
                    <label for="dnd-indirizzo"><?php esc_html_e('Indirizzo di spedizione', 'dico-no-alla-droga-child-theme'); ?> *</label>
                    <input id="dnd-indirizzo" name="indirizzo" type="text" autocomplete="street-address">
                    <p class="dnd-error" data-error-for="indirizzo" role="alert"></p>
                </div>
                <div class="dnd-field">
                    <label for="dnd-cap"><?php esc_html_e('CAP', 'dico-no-alla-droga-child-theme'); ?> *</label>
                    <input id="dnd-cap" name="cap" type="text" inputmode="numeric" autocomplete="postal-code">
                    <p class="dnd-error" data-error-for="cap" role="alert"></p>
                </div>
                <div class="dnd-field">
                    <label for="dnd-localita"><?php esc_html_e('Località', 'dico-no-alla-droga-child-theme'); ?> *</label>
                    <input id="dnd-localita" name="localita" type="text" autocomplete="address-level2">
                    <p class="dnd-error" data-error-for="localita" role="alert"></p>
                </div>
            </div>
        </fieldset>

        <fieldset class="dnd-fieldset" data-dnd-when="conferenziere" hidden>
            <legend><span class="dnd-step">3</span> <?php esc_html_e('La conferenza', 'dico-no-alla-droga-child-theme'); ?></legend>
            <div class="dnd-grid-2">
                <div class="dnd-field">
                    <label for="dnd-data"><?php esc_html_e('Data o periodo desiderato', 'dico-no-alla-droga-child-theme'); ?></label>
                    <input id="dnd-data" name="data_conf" type="text" placeholder="<?php esc_attr_e('Es. marzo, un mercoledì mattina', 'dico-no-alla-droga-child-theme'); ?>">
                </div>
                <div class="dnd-field">
                    <label for="dnd-luogo"><?php esc_html_e('Dove si terrebbe', 'dico-no-alla-droga-child-theme'); ?> *</label>
                    <input id="dnd-luogo" name="luogo" type="text" placeholder="<?php esc_attr_e('Sede e località', 'dico-no-alla-droga-child-theme'); ?>">
                    <p class="dnd-error" data-error-for="luogo" role="alert"></p>
                </div>
                <div class="dnd-field">
                    <label for="dnd-partecipanti"><?php esc_html_e('Quante persone parteciperanno?', 'dico-no-alla-droga-child-theme'); ?> *</label>
                    <input id="dnd-partecipanti" name="partecipanti" type="number" min="1" inputmode="numeric">
                    <p class="dnd-error" data-error-for="partecipanti" role="alert"></p>
                </div>
                <div class="dnd-field">
                    <label for="dnd-destinatari"><?php esc_html_e('A chi è rivolta?', 'dico-no-alla-droga-child-theme'); ?></label>
                    <input id="dnd-destinatari" name="destinatari" type="text" placeholder="<?php esc_attr_e('Es. classi quarte, genitori, giovani', 'dico-no-alla-droga-child-theme'); ?>">
                </div>
            </div>
        </fieldset>

        <fieldset class="dnd-fieldset">
            <legend><span class="dnd-step">4</span> <?php esc_html_e('Vuoi aggiungere qualcosa?', 'dico-no-alla-droga-child-theme'); ?></legend>
            <div class="dnd-field">
                <label for="dnd-note"><?php esc_html_e('Note (facoltativo)', 'dico-no-alla-droga-child-theme'); ?></label>
                <textarea id="dnd-note" name="note" rows="4" maxlength="2000"></textarea>
            </div>
            <label class="dnd-consent">
                <input type="checkbox" name="privacy" value="1" required>
                <span>
                    <?php
                    if ($privacy) {
                        printf(
                            /* translators: %s: link to the privacy policy */
                            esc_html__('Ho letto l’%s e accetto che i miei dati siano usati per rispondere a questa richiesta.', 'dico-no-alla-droga-child-theme'),
                            '<a href="' . esc_url($privacy) . '" target="_blank" rel="noopener">' . esc_html__('informativa sulla privacy', 'dico-no-alla-droga-child-theme') . '</a>'
                        );
                    } else {
                        esc_html_e('Accetto che i miei dati siano usati per rispondere a questa richiesta.', 'dico-no-alla-droga-child-theme');
                    }
                    ?> *
                </span>
            </label>
            <p class="dnd-error" data-error-for="privacy" role="alert"></p>
        </fieldset>

        <div class="dnd-form__submit">
            <button type="submit" class="dnd-btn dnd-btn--sun dnd-btn--xl"><?php esc_html_e('Invia la richiesta', 'dico-no-alla-droga-child-theme'); ?></button>
            <p class="dnd-hint"><?php esc_html_e('Ti rispondiamo per e-mail. I campi con * sono obbligatori.', 'dico-no-alla-droga-child-theme'); ?></p>
        </div>
        <div class="dnd-notice" role="status" aria-live="polite" hidden></div>
    </form>
    <?php
    return ob_get_clean();
});
