/* Modulo «Richiedi materiale / conferenziere»: invio AJAX al gestore del parent. */
(function () {
    'use strict';
    var cfg = window.dndRichiesta || {};
    var form = document.querySelector('[data-dnd-form]');
    if (!form || !cfg.ajax_url) { return; }

    var notice = form.querySelector('.dnd-notice');
    var panels = form.querySelectorAll('[data-dnd-when]');

    function checkedTypes() {
        var out = [];
        Array.prototype.forEach.call(form.querySelectorAll('input[name="tipo[]"]:checked'), function (i) { out.push(i.value); });
        return out;
    }

    function syncPanels() {
        var types = checkedTypes();
        Array.prototype.forEach.call(panels, function (p) {
            var show = types.indexOf(p.getAttribute('data-dnd-when')) !== -1;
            p.hidden = !show;
        });
        // Il numero del passo segue i pannelli visibili.
        var n = 3;
        Array.prototype.forEach.call(panels, function (p) {
            var s = p.querySelector('.dnd-step');
            if (s && !p.hidden) { s.textContent = String(n); n++; }
        });
        var last = form.querySelector('.dnd-fieldset:last-of-type .dnd-step');
        if (last) { last.textContent = String(n); }
    }

    function clearErrors() {
        Array.prototype.forEach.call(form.querySelectorAll('.dnd-error'), function (e) { e.textContent = ''; });
        Array.prototype.forEach.call(form.querySelectorAll('[aria-invalid]'), function (e) { e.removeAttribute('aria-invalid'); });
    }

    function showErrors(map) {
        var first = null;
        Object.keys(map || {}).forEach(function (name) {
            var slot = form.querySelector('[data-error-for="' + name + '"]');
            if (slot) { slot.textContent = map[name]; }
            var field = form.querySelector('[name="' + name + '"]');
            if (field) { field.setAttribute('aria-invalid', 'true'); }
            if (!first) { first = slot || field; }
        });
        if (first && first.scrollIntoView) { first.scrollIntoView({ behavior: 'smooth', block: 'center' }); }
    }

    function say(text, ok) {
        notice.hidden = false;
        notice.className = 'dnd-notice ' + (ok ? 'is-ok' : 'is-error');
        notice.textContent = text;
        if (notice.scrollIntoView) { notice.scrollIntoView({ behavior: 'smooth', block: 'center' }); }
    }

    function getToken() {
        return fetch(cfg.ajax_url + '?action=' + encodeURIComponent(cfg.token_action), { credentials: 'same-origin', cache: 'no-store' })
            .then(function (r) { return r.json(); })
            .then(function (j) { return j && j.success && j.data ? j.data.token : ''; });
    }

    function recaptcha() {
        if (!cfg.recaptcha_site_key || !window.grecaptcha) { return Promise.resolve(''); }
        return new Promise(function (resolve) {
            window.grecaptcha.ready(function () {
                window.grecaptcha.execute(cfg.recaptcha_site_key, { action: 'richiesta' }).then(resolve, function () { resolve(''); });
            });
        });
    }

    form.addEventListener('change', function (e) {
        if (e.target && e.target.name === 'tipo[]') { syncPanels(); }
    });

    // Anche con JS lento: i pannelli partono coerenti con la scelta iniziale.
    syncPanels();

    // «Richiedi copie» dagli opuscoli: ?opuscolo=ID preseleziona il materiale e quell'opuscolo.
    (function preselect() {
        var m = /[?&]opuscolo=(\d+)/.exec(window.location.search);
        if (m) { selectBooklet(m[1]); }
    })();

    function selectBooklet(id) {
        var box = form.querySelector('input[name="opuscoli[]"][value="' + id + '"]');
        var type = form.querySelector('input[name="tipo[]"][value="materiale"]');
        if (type) { type.checked = true; }
        if (box) { box.checked = true; }
        syncPanels();
    }

    // I pulsanti «Richiedi copie» presenti nella stessa pagina non ricaricano: scelgono e scorrono al modulo.
    document.addEventListener('click', function (e) {
        var a = e.target.closest ? e.target.closest('[data-dnd-add]') : null;
        if (!a) { return; }
        var target = document.getElementById('dnd-richiesta-form');
        if (!target) { return; }
        e.preventDefault();
        selectBooklet(a.getAttribute('data-dnd-add'));
        target.scrollIntoView({ behavior: 'smooth', block: 'start' });
    });

    form.addEventListener('submit', function (e) {
        e.preventDefault();
        clearErrors();
        notice.hidden = true;

        var btn = form.querySelector('[type="submit"]');
        var label = btn.textContent;
        btn.disabled = true;
        btn.textContent = cfg.i18n.sending;

        Promise.all([getToken(), recaptcha()]).then(function (res) {
            var fd = new FormData(form);
            fd.append('action', cfg.submit_action);
            fd.append('token', res[0]);
            if (res[1]) { fd.append('recaptcha_token', res[1]); }
            // I campi dei pannelli nascosti non vengono inviati.
            Array.prototype.forEach.call(panels, function (p) {
                if (p.hidden) {
                    Array.prototype.forEach.call(p.querySelectorAll('input,select,textarea'), function (i) { fd.delete(i.name); });
                }
            });
            return fetch(cfg.ajax_url, { method: 'POST', body: fd, credentials: 'same-origin' });
        }).then(function (r) { return r.json(); }).then(function (j) {
            if (j && j.success) {
                form.reset();
                syncPanels();
                say(j.data.message, true);
            } else {
                var d = (j && j.data) || {};
                if (d.fields) { showErrors(d.fields); }
                say(d.message || cfg.i18n.error, false);
            }
        }).catch(function () {
            say(cfg.i18n.error, false);
        }).then(function () {
            btn.disabled = false;
            btn.textContent = label;
        });
    });
})();
