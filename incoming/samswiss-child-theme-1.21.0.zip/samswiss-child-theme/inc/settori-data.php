<?php
/**
 * Commercial data and structured layout definitions for the three industrial sectors:
 * 1. Ortofrutta (ortofrutta)
 * 2. Gastronomia, Panetteria e IV Gamma (gastronomia-e-ristorazione, etc.)
 * 3. Carne, Pesce e Caseario (carne-pesce, caseario)
 *
 * @package samswiss-child
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Return commercial sector configuration if the category slug belongs to one of the 3 macro-sectors.
 *
 * @param string $slug Category slug.
 * @return array|null
 */
function samswiss_get_sector_data( $slug ) {
	// Normalize aliases
	if ( in_array( $slug, array( 'gastronomia-e-ristorazione', 'pane-pasticceria-gelateria', 'quarta-gamma-gdo' ), true ) ) {
		$key = 'gastronomia-panetteria-iv-gamma';
	} elseif ( in_array( $slug, array( 'carne-pesce', 'caseario' ), true ) ) {
		$key = 'carne-pesce-caseario';
	} elseif ( 'ortofrutta' === $slug ) {
		$key = 'ortofrutta';
	} else {
		return null;
	}

	$sectors = array(
		'ortofrutta' => array(
			'title'       => __( 'Soluzioni per il settore ortofrutticolo', 'samswiss-child' ),
			'subtitle'    => __( 'Dalla pesatura al confezionamento, fino al pallet pronto per la spedizione.', 'samswiss-child' ),
			'intro'       => __( 'SAM sviluppa soluzioni per la lavorazione e il confezionamento di frutta e verdura fresca, studiando ogni progetto in funzione del prodotto, del formato, della produttività richiesta e degli spazi disponibili. Dalla singola macchina alla linea completa, integriamo pesatura, confezionamento, movimentazione, etichettatura, fine linea e pallettizzazione, con assistenza tecnica su tutto il territorio svizzero.', 'samswiss-child' ),
			'theme_img'   => 'assets/img/settori/ortofrutta.jpeg',
			'alt'         => __( 'Soluzioni per ortofrutta', 'samswiss-child' ),
			'pills_label' => __( 'Prodotti e applicazioni:', 'samswiss-child' ),
			'pills'       => array(
				__( 'Mele', 'samswiss-child' ),
				__( 'Agrumi', 'samswiss-child' ),
				__( 'Patate', 'samswiss-child' ),
				__( 'Cipolle', 'samswiss-child' ),
				__( 'Pomodori', 'samswiss-child' ),
				__( 'Zucchine', 'samswiss-child' ),
				__( 'Peperoni', 'samswiss-child' ),
				__( 'Frutta e verdura fresca', 'samswiss-child' ),
			),
			'tech_title'  => __( 'Le tecnologie per l\'ortofrutta', 'samswiss-child' ),
			'tech_intro'  => __( 'Scopri le tecnologie specifiche per il confezionamento e la lavorazione ortofrutticola:', 'samswiss-child' ),
			'tech_cards'  => array(
				array(
					'title' => __( 'Pesatura e dosaggio', 'samswiss-child' ),
					'icon'  => 'fa-scale-balanced',
					'url'   => home_url( '/tecnologie/peso-combinato/' ),
					'tag'   => __( 'Peso combinato / Sorma', 'samswiss-child' ),
				),
				array(
					'title' => __( 'Confezionamento in rete', 'samswiss-child' ),
					'icon'  => 'fa-circle-nodes',
					'url'   => home_url( '/tecnologie/confezionamento-in-rete/' ),
					'tag'   => __( 'Retinatrici Sorma', 'samswiss-child' ),
				),
				array(
					'title' => __( 'Flow-Pack', 'samswiss-child' ),
					'icon'  => 'fa-layer-group',
					'url'   => home_url( '/tecnologie/flow-pack/' ),
					'tag'   => __( 'Orizzontale flessibile', 'samswiss-child' ),
				),
				array(
					'title' => __( 'Confezionamento Stretch', 'samswiss-child' ),
					'icon'  => 'fa-cubes-stacked',
					'url'   => home_url( '/tecnologie/confezionamento-stretch/' ),
					'tag'   => __( 'Avvolgitrici film estensibile', 'samswiss-child' ),
				),
				array(
					'title' => __( 'Pesatura ed etichettatura', 'samswiss-child' ),
					'icon'  => 'fa-barcode',
					'url'   => home_url( '/tecnologie/pesatura-ed-etichettatura/' ),
					'tag'   => __( 'Dinamica & tracciabilità', 'samswiss-child' ),
				),
				array(
					'title' => __( 'Movimentazione e automazione', 'samswiss-child' ),
					'icon'  => 'fa-gears',
					'url'   => home_url( '/macchine-confezionatrici/#soluzioni' ),
					'tag'   => __( 'Nastri & smistamento', 'samswiss-child' ),
				),
				array(
					'title' => __( 'Fine linea e pallettizzazione', 'samswiss-child' ),
					'icon'  => 'fa-boxes-packing',
					'url'   => home_url( '/tecnologie/fine-linea-pallettizzazione/' ),
					'tag'   => __( 'Reggiatura & pallet', 'samswiss-child' ),
				),
			),
		),

		'gastronomia-panetteria-iv-gamma' => array(
			'title'          => __( 'Soluzioni per Gastronomia, Panetteria e IV Gamma', 'samswiss-child' ),
			'subtitle'       => __( 'Tecnologie di confezionamento per prodotti freschi, piatti pronti e prodotti da forno.', 'samswiss-child' ),
			'intro'          => __( 'Dalla produzione artigianale alle linee automatiche, SAM propone sistemi di confezionamento flessibili per gastronomia, panetteria e prodotti freschi di IV Gamma. Studiamo la tecnologia più adatta in funzione del prodotto, della shelf life desiderata, del formato della confezione e della capacità produttiva.', 'samswiss-child' ),
			'theme_img'      => 'assets/img/settori/gastronomia-4-gamma.jpeg',
			'alt'            => __( 'Gastronomia, Panetteria e IV Gamma', 'samswiss-child' ),
			'flyer'          => array(
				'name'  => 'gastro',
				'label' => __( 'LINEA GASTRO', 'samswiss-child' ),
				'title' => __( 'Dalla vaschetta all’etichetta, un unico partner', 'samswiss-child' ),
				'text'  => __( 'Le termosigillatrici LARI/3 pn-VG, YPSILON, MAGIC 2.0 e FG40 e la peso-prezzatrice GWX PLUS: tutto il necessario per confezionare ed etichettare carne, pesce, latticini, gastronomia e piatti pronti.', 'samswiss-child' ),
				'alt'   => __( 'Volantino SAM linea Gastro: termosigillatrici LARI/3 pn-VG, YPSILON, MAGIC 2.0, FG40 e peso-prezzatrice GWX PLUS', 'samswiss-child' ),
			),
			'blocks_title'   => __( 'Settori e tecnologie predominanti', 'samswiss-child' ),
			'blocks'         => array(
				array(
					'name'  => __( 'Gastronomia', 'samswiss-child' ),
					'desc'  => __( 'Piatti pronti, pasta fresca, primi e secondi piatti, preparazioni alimentari, take-away.', 'samswiss-child' ),
					'techs' => array(
						array( 'name' => __( 'Sigillatura', 'samswiss-child' ), 'url' => home_url( '/tecnologie/sigillatura/' ) ),
						array( 'name' => __( 'MAP', 'samswiss-child' ), 'url' => home_url( '/tecnologie/map/' ) ),
						array( 'name' => __( 'Stretch', 'samswiss-child' ), 'url' => home_url( '/tecnologie/confezionamento-stretch/' ) ),
						array( 'name' => __( 'Pesatura ed Etichettatura', 'samswiss-child' ), 'url' => home_url( '/tecnologie/pesatura-ed-etichettatura/' ) ),
					),
				),
				array(
					'name'  => __( 'Panetteria', 'samswiss-child' ),
					'desc'  => __( 'Pane, focacce, prodotti da forno, pasticceria fresca e prodotti confezionati.', 'samswiss-child' ),
					'techs' => array(
						array( 'name' => __( 'Flow-Pack', 'samswiss-child' ), 'url' => home_url( '/tecnologie/flow-pack/' ) ),
						array( 'name' => __( 'MAP', 'samswiss-child' ), 'url' => home_url( '/tecnologie/map/' ) ),
						array( 'name' => __( 'Sigillatura', 'samswiss-child' ), 'url' => home_url( '/tecnologie/sigillatura/' ) ),
						array( 'name' => __( 'Etichettatura', 'samswiss-child' ), 'url' => home_url( '/tecnologie/pesatura-ed-etichettatura/' ) ),
					),
				),
				array(
					'name'  => __( 'IV Gamma', 'samswiss-child' ),
					'desc'  => __( 'Insalate, verdure lavorate, frutta tagliata e prodotti freschi pronti al consumo.', 'samswiss-child' ),
					'techs' => array(
						array( 'name' => __( 'MAP', 'samswiss-child' ), 'url' => home_url( '/tecnologie/map/' ) ),
						array( 'name' => __( 'Sigillatura / Top Seal', 'samswiss-child' ), 'url' => home_url( '/tecnologie/sigillatura/' ) ),
						array( 'name' => __( 'Flow-Pack', 'samswiss-child' ), 'url' => home_url( '/tecnologie/flow-pack/' ) ),
						array( 'name' => __( 'Pesatura ed Etichettatura', 'samswiss-child' ), 'url' => home_url( '/tecnologie/pesatura-ed-etichettatura/' ) ),
					),
				),
			),
			'materials_box'  => array(
				'title' => __( 'Imballaggio e sostenibilità', 'samswiss-child' ),
				'text'  => __( 'Vaschette tradizionali ed ecosostenibili · Soluzioni in cartone · Film termosaldanti · Film barriera · Film micro e macroforati · Materiali di consumo.', 'samswiss-child' ),
				'claim' => __( 'Non vendiamo solo macchine, ma continuiamo a seguirti anche con tutto ciò che serve per confezionare.', 'samswiss-child' ),
				'btn'   => __( 'Scopri i materiali di consumo', 'samswiss-child' ),
				'url'   => home_url( '/imballaggi-e-consumabili/' ),
			),
		),

		'carne-pesce-caseario' => array(
			'title'        => __( 'Soluzioni per Carne, Pesce e Prodotti Caseari', 'samswiss-child' ),
			'subtitle'     => __( 'Protezione, conservazione e valorizzazione del prodotto attraverso il confezionamento più adatto.', 'samswiss-child' ),
			'intro'        => __( 'SAM propone tecnologie professionali per il confezionamento di carne, pesce, formaggi e prodotti freschi, dalla singola macchina fino alla linea integrata. Analizziamo prodotto, confezione, materiali, produttività e necessità di conservazione per individuare la soluzione più adatta, completandola con pesatura, etichettatura, movimentazione e assistenza tecnica.', 'samswiss-child' ),
			'theme_img'    => 'assets/img/settori/carne-pesce-caseario.jpeg',
			'alt'          => __( 'Carne, Pesce e Caseario', 'samswiss-child' ),
			'blocks_title' => __( 'Applicazioni specializzate', 'samswiss-child' ),
			'blocks'       => array(
				array(
					'name' => __( 'Carne', 'samswiss-child' ),
					'desc' => __( 'Carne fresca · pollame · preparati · porzionati', 'samswiss-child' ),
					'icon' => 'fa-drumstick-bite',
				),
				array(
					'name' => __( 'Pesce', 'samswiss-child' ),
					'desc' => __( 'Pesce fresco · filetti · prodotti ittici · preparazioni', 'samswiss-child' ),
					'icon' => 'fa-fish',
				),
				array(
					'name' => __( 'Caseario', 'samswiss-child' ),
					'desc' => __( 'Formaggi · porzioni · latticini · prodotti freschi', 'samswiss-child' ),
					'icon' => 'fa-cheese',
				),
			),
			'tech_title'   => __( 'Tecnologie consigliate', 'samswiss-child' ),
			'tech_intro'   => __( 'L\'ordine tecnologico per la massima protezione e resa a banco:', 'samswiss-child' ),
			'tech_cards'   => array(
				array(
					'title' => __( 'SKIN', 'samswiss-child' ),
					'icon'  => 'fa-layer-group',
					'url'   => home_url( '/tecnologie/skin/' ),
					'tag'   => __( 'Massima shelf life & appeal', 'samswiss-child' ),
				),
				array(
					'title' => __( 'MAP', 'samswiss-child' ),
					'icon'  => 'fa-wind',
					'url'   => home_url( '/tecnologie/map/' ),
					'tag'   => __( 'Atmosfera protettiva', 'samswiss-child' ),
				),
				array(
					'title' => __( 'STRETCH', 'samswiss-child' ),
					'icon'  => 'fa-cubes-stacked',
					'url'   => home_url( '/tecnologie/confezionamento-stretch/' ),
					'tag'   => __( 'Vaschette freschissimi', 'samswiss-child' ),
				),
				array(
					'title' => __( 'SIGILLATURA', 'samswiss-child' ),
					'icon'  => 'fa-box-tissue',
					'url'   => home_url( '/tecnologie/sigillatura/' ),
					'tag'   => __( 'Termosaldatura vaschette', 'samswiss-child' ),
				),
				array(
					'title' => __( 'PESATURA ED ETICHETTATURA', 'samswiss-child' ),
					'icon'  => 'fa-barcode',
					'url'   => home_url( '/tecnologie/pesatura-ed-etichettatura/' ),
					'tag'   => __( 'Peso/prezzo & tracciabilità', 'samswiss-child' ),
				),
				array(
					'title' => __( 'FINE LINEA', 'samswiss-child' ),
					'icon'  => 'fa-boxes-packing',
					'url'   => home_url( '/tecnologie/fine-linea-pallettizzazione/' ),
					'tag'   => __( 'Movimentazione & imballo', 'samswiss-child' ),
				),
			),
			'assistenza'   => array(
				'title' => __( 'ASSISTENZA IN SVIZZERA', 'samswiss-child' ),
				'sub'   => __( 'Un partner vicino alla tua produzione', 'samswiss-child' ),
				'text'  => __( 'Dalla consulenza iniziale all\'installazione, fino all\'assistenza tecnica e alla fornitura dei materiali di consumo, SAM segue il cliente nel tempo con un riferimento diretto sul territorio svizzero.', 'samswiss-child' ),
			),
		),
	);

	return isset( $sectors[ $key ] ) ? $sectors[ $key ] : null;
}

/**
 * Slug italiano di una categoria, anche quando la si visita tradotta.
 *
 * @param WP_Term $term Categoria.
 * @return string
 */
function samswiss_original_category_slug( $term ) {
	if ( ! $term instanceof WP_Term ) {
		return '';
	}
	$orig_id = (int) apply_filters( 'wpml_object_id', $term->term_id, 'category', true, apply_filters( 'wpml_default_language', null ) );
	if ( ! $orig_id || $orig_id === (int) $term->term_id ) {
		return $term->slug;
	}
	global $wpdb;
	return (string) $wpdb->get_var( $wpdb->prepare( "SELECT slug FROM {$wpdb->terms} WHERE term_id = %d", $orig_id ) );
}

/**
 * Ortofrutta: le macchine con un "Ordine" (menu_order > 0) vengono per prime,
 * nell'ordine dato; poi tutte le altre, dalla più recente. SAM le vuole ben
 * visibili a inizio pagina. Vale solo per l'archivio Ortofrutta.
 *
 * @param string   $orderby Clausola ORDER BY.
 * @param WP_Query $query   Query.
 * @return string
 */
function samswiss_ortofrutta_priority_orderby( $orderby, $query ) {
	if ( is_admin() || ! $query->is_main_query() || ! $query->is_category() ) {
		return $orderby;
	}
	if ( 'ortofrutta' !== samswiss_original_category_slug( $query->get_queried_object() ) ) {
		return $orderby;
	}
	global $wpdb;
	return "({$wpdb->posts}.menu_order = 0) ASC, {$wpdb->posts}.menu_order ASC, {$wpdb->posts}.post_date DESC";
}
add_filter( 'posts_orderby', 'samswiss_ortofrutta_priority_orderby', 10, 2 );
