<?php
/**
 * Aspetto → Personalizza → «Fashion Shoes»: i testi e le foto della pagina iniziale che non stanno già nel CMS
 * del parent. Contatti, orari, logo, collezioni (= Servizi del CMS), «Chi siamo», gallerie, FAQ e SEO restano in
 * ticinoWEB CMS. I valori si leggono con fashionshoes_setting('<chiave>') (theme_mod «fashionshoes_<chiave>»).
 *
 * @package fashionshoes-child-theme
 */

defined('ABSPATH') || exit;

/** Slug di una galleria del parent: solo una di quelle esistenti, altrimenti vuoto. */
function fashionshoes_sanitize_gallery($value)
{
    $value = sanitize_title((string) $value);
    if ($value === '' || !taxonomy_exists('ticinoweb_media_gallery')) {
        return $value;
    }
    return term_exists($value, 'ticinoweb_media_gallery') ? $value : '';
}

/** Le gallerie del parent per i menu a tendina: [slug => nome]. */
function fashionshoes_gallery_choices()
{
    $choices = array('' => __('— nessuna —', 'fashionshoes-child-theme'));
    if (!taxonomy_exists('ticinoweb_media_gallery')) {
        return $choices;
    }
    $terms = get_terms(array('taxonomy' => 'ticinoweb_media_gallery', 'hide_empty' => false));
    foreach (is_array($terms) ? $terms : array() as $term) {
        $choices[$term->slug] = $term->name;
    }
    return $choices;
}

add_action('customize_register', function ($wp_customize) {
    $wp_customize->add_panel('fashionshoes', array(
        'title'       => __('Fashion Shoes', 'fashionshoes-child-theme'),
        'priority'    => 30,
        'description' => __('I testi e le foto della pagina iniziale. Indirizzo, telefono, email, orari, social e logo si cambiano in ticinoWEB CMS → Contatti; le collezioni in ticinoWEB CMS → Servizi; il testo del negozio in ticinoWEB CMS → Chi siamo; le foto in Media → Gallerie.', 'fashionshoes-child-theme'),
    ));

    $text = function ($section, $key, $label, $description = '', $type = 'text') use ($wp_customize) {
        $wp_customize->add_setting('fashionshoes_' . $key, array(
            'default'           => '',
            'sanitize_callback' => $type === 'textarea' ? 'sanitize_textarea_field' : 'sanitize_text_field',
        ));
        $wp_customize->add_control('fashionshoes_' . $key, array(
            'section'     => 'fashionshoes_' . $section,
            'type'        => $type,
            'label'       => $label,
            'description' => $description,
        ));
    };
    $image = function ($section, $key, $label, $description) use ($wp_customize) {
        $wp_customize->add_setting('fashionshoes_' . $key, array('default' => 0, 'sanitize_callback' => 'absint'));
        $wp_customize->add_control(new WP_Customize_Media_Control($wp_customize, 'fashionshoes_' . $key, array(
            'section'     => 'fashionshoes_' . $section,
            'mime_type'   => 'image',
            'label'       => $label,
            'description' => $description,
        )));
    };
    $gallery = function ($section, $key, $label, $description) use ($wp_customize) {
        $wp_customize->add_setting('fashionshoes_' . $key, array('default' => '', 'sanitize_callback' => 'fashionshoes_sanitize_gallery'));
        $wp_customize->add_control('fashionshoes_' . $key, array(
            'section'     => 'fashionshoes_' . $section,
            'type'        => 'select',
            'choices'     => fashionshoes_gallery_choices(),
            'label'       => $label,
            'description' => $description,
        ));
    };
    $section = function ($id, $title, $description) use ($wp_customize) {
        $wp_customize->add_section('fashionshoes_' . $id, array('title' => $title, 'panel' => 'fashionshoes', 'description' => $description));
    };

    // 1. In cima alla pagina.
    $section('hero', __('In cima alla pagina', 'fashionshoes-child-theme'), __('Il titolo dice cosa vendete e dove. Sotto: il motto, una frase e una riga con un fatto vero (per esempio l’orario).', 'fashionshoes-child-theme'));
    $text('hero', 'hero_title', __('Titolo', 'fashionshoes-child-theme'), __('Vuoto: il nome del sito.', 'fashionshoes-child-theme'));
    $text('hero', 'hero_motto', __('Motto', 'fashionshoes-child-theme'), __('Titolo della sezione «Il negozio» (sopra il testo di Chi siamo). Vuoto: il titolo di Chi siamo.', 'fashionshoes-child-theme'));
    $text('hero', 'hero_text', __('Testo sotto il titolo', 'fashionshoes-child-theme'), __('Una o due frasi, al massimo 30 parole.', 'fashionshoes-child-theme'), 'textarea');
    $text('hero', 'hero_note', __('Riga sotto i bottoni', 'fashionshoes-child-theme'), __('Un fatto vero, per esempio l’orario della settimana. Vuoto: la riga non compare.', 'fashionshoes-child-theme'));
    $image('hero', 'hero_image', __('Prima foto', 'fashionshoes-child-theme'), __('Le due foto sotto il titolo si vedono in formato 4:5. Se ne scegli una sola, o nessuna, compaiono i due post Instagram più recenti.', 'fashionshoes-child-theme'));
    $image('hero', 'hero_image_2', __('Seconda foto', 'fashionshoes-child-theme'), __('Va con la prima: una foto di prodotto o del negozio, senza scritte di altri.', 'fashionshoes-child-theme'));

    // 2. Collezioni.
    $section('collections', __('Collezioni', 'fashionshoes-child-theme'), __('Le collezioni (nome, descrizione, foto) si cambiano in ticinoWEB CMS → Servizi: ogni servizio è una collezione.', 'fashionshoes-child-theme'));
    $text('collections', 'collections_title', __('Titolo della sezione', 'fashionshoes-child-theme'));
    $text('collections', 'collections_text', __('Frase sotto il titolo', 'fashionshoes-child-theme'), '', 'textarea');

    // 3. Instagram.
    $section('instagram', __('Instagram', 'fashionshoes-child-theme'), __('Le prime sei foto della galleria scelta. Il bottone porta al profilo Instagram di ticinoWEB CMS → Contatti.', 'fashionshoes-child-theme'));
    $text('instagram', 'instagram_title', __('Titolo della sezione', 'fashionshoes-child-theme'));
    $text('instagram', 'instagram_text', __('Frase sotto il titolo', 'fashionshoes-child-theme'), '', 'textarea');
    $gallery('instagram', 'instagram_gallery', __('Galleria', 'fashionshoes-child-theme'), __('Senza galleria la sezione non compare.', 'fashionshoes-child-theme'));
    $wp_customize->add_setting('fashionshoes_instagram_embed', array('default' => true, 'sanitize_callback' => 'wp_validate_boolean'));
    $wp_customize->add_control('fashionshoes_instagram_embed', array(
        'section'     => 'fashionshoes_instagram',
        'type'        => 'checkbox',
        'label'       => __('Mostra gli ultimi post in diretta', 'fashionshoes-child-theme'),
        'description' => __('Incorpora il profilo Instagram pubblico (nome da ticinoWEB CMS → Contatti): si aggiorna da solo, senza collegare l’account. Togli la spunta per usare le foto della galleria qui sotto. Instagram vede la visita appena la sezione si carica: citarlo nell’informativa sulla privacy.', 'fashionshoes-child-theme'),
    ));
    $wp_customize->add_setting('fashionshoes_instagram_sync', array('default' => false, 'sanitize_callback' => 'wp_validate_boolean'));
    $wp_customize->add_control('fashionshoes_instagram_sync', array(
        'section'     => 'fashionshoes_instagram',
        'type'        => 'checkbox',
        'label'       => __('Aggiorna la galleria da Instagram', 'fashionshoes-child-theme'),
        'description' => __('Ogni ora la galleria si allinea alle 6 foto più recenti del vostro Instagram. Serve l’account collegato in Instagram Feed → Impostazioni (account Instagram professionale).', 'fashionshoes-child-theme') . ' ' . (function_exists('fashionshoes_ig_stato_testo') ? fashionshoes_ig_stato_testo() : ''),
    ));

    // 4. Il negozio.
    $section('shop', __('Il negozio', 'fashionshoes-child-theme'), __('Titolo e testo vengono da ticinoWEB CMS → Chi siamo (una riga vuota separa i paragrafi). Qui le foto.', 'fashionshoes-child-theme'));
    $gallery('shop', 'shop_gallery', __('Galleria del negozio', 'fashionshoes-child-theme'), __('Le prime tre foto: la prima è la grande. Un clic le apre a tutto schermo.', 'fashionshoes-child-theme'));

    // 4b. Galleria.
    $section('gallery', __('Galleria', 'fashionshoes-child-theme'), __('Tutte le foto della galleria scelta, a muratura. Un clic le apre a tutto schermo.', 'fashionshoes-child-theme'));
    $text('gallery', 'gallery_title', __('Titolo della sezione', 'fashionshoes-child-theme'));
    $text('gallery', 'gallery_text', __('Frase sotto il titolo', 'fashionshoes-child-theme'), '', 'textarea');
    $gallery('gallery', 'gallery_gallery', __('Galleria', 'fashionshoes-child-theme'), __('Senza galleria la sezione non compare.', 'fashionshoes-child-theme'));

    // 5. Orari e contatti.
    $section('contact', __('Orari e contatti', 'fashionshoes-child-theme'), __('Orari, indirizzo, telefono ed email vengono da ticinoWEB CMS → Contatti. La nota degli orari compare come secondo orario (per esempio quello estivo). Il modulo invia all’email del CMS e salva ogni messaggio in Invii Ricevuti.', 'fashionshoes-child-theme'));
    $text('contact', 'contact_title', __('Titolo', 'fashionshoes-child-theme'));
    $text('contact', 'hours_title', __('Titolo degli orari', 'fashionshoes-child-theme'), __('Per esempio «Orario invernale».', 'fashionshoes-child-theme'));
    $text('contact', 'hours_note_title', __('Titolo della nota degli orari', 'fashionshoes-child-theme'), __('Per esempio «Orario estivo». Le righe della nota (ticinoWEB CMS → Contatti) si scrivono «Giorni: orario», una per riga.', 'fashionshoes-child-theme'));
    $image('contact', 'contact_image', __('Foto dell’entrata', 'fashionshoes-child-theme'), __('La vetrina vista dalla strada, per riconoscerla arrivando.', 'fashionshoes-child-theme'));
    $text('contact', 'contact_caption', __('Didascalia della foto', 'fashionshoes-child-theme'), __('Come si riconosce il negozio. Accanto compare il link a Google Maps.', 'fashionshoes-child-theme'));
    $text('contact', 'form_title', __('Titolo del modulo', 'fashionshoes-child-theme'));
    // 6. Testi di pulsanti ed etichette (prima scritti nel tema): ogni campo vuoto usa il testo predefinito.
    $section('labels', __('Testi di pulsanti ed etichette', 'fashionshoes-child-theme'), __('Tutti i testi fissi del sito che non stanno altrove: pulsanti, modulo, stato aperto/chiuso e piè di pagina. Un campo vuoto usa il testo scritto sotto il nome del campo. Dove vedi %s lascialo: il sito ci mette il valore giusto.', 'fashionshoes-child-theme'));
    $text('labels', 'btn_call', __('Pulsante «Chiama»', 'fashionshoes-child-theme'), __('Predefinito: «Chiama». Nella barra in alto e nei contatti.', 'fashionshoes-child-theme'));
    $text('labels', 'btn_directions', __('Pulsante «Come arrivare»', 'fashionshoes-child-theme'), __('Predefinito: «Come arrivare». Nella testata e in «Orari e contatti».', 'fashionshoes-child-theme'));
    $text('labels', 'where_title', __('Titolo «Dove siamo»', 'fashionshoes-child-theme'), __('Predefinito: «Dove siamo». Sopra indirizzo, telefono ed email in «Orari e contatti».', 'fashionshoes-child-theme'));
    $text('labels', 'follow_instagram', __('Pulsante «Segui @profilo»', 'fashionshoes-child-theme'), __('Predefinito: «Segui @%s». Sotto gli ultimi post di Instagram. Lascia %s: al suo posto va il nome del profilo.', 'fashionshoes-child-theme'));
    $text('labels', 'status_open', __('Negozio aperto', 'fashionshoes-child-theme'), __('Predefinito: «Aperto ora · fino alle %s». Sotto il titolo della testata. Lascia %s: al suo posto va l’ora di chiusura.', 'fashionshoes-child-theme'));
    $text('labels', 'status_closed', __('Negozio chiuso (senza prossima apertura)', 'fashionshoes-child-theme'), __('Predefinito: «Chiuso».', 'fashionshoes-child-theme'));
    $text('labels', 'status_reopens', __('Negozio chiuso, quando riapre', 'fashionshoes-child-theme'), __('Predefinito: «Chiuso · riapre %1$s alle %2$s». Lascia %1$s (il giorno: oggi, domani, lunedì…) e %2$s (l’ora).', 'fashionshoes-child-theme'));
    $text('labels', 'form_name', __('Modulo: campo Nome', 'fashionshoes-child-theme'), __('Predefinito: «Nome».', 'fashionshoes-child-theme'));
    $text('labels', 'form_phone', __('Modulo: campo Telefono', 'fashionshoes-child-theme'), __('Predefinito: «Telefono».', 'fashionshoes-child-theme'));
    $text('labels', 'form_email', __('Modulo: campo Email', 'fashionshoes-child-theme'), __('Predefinito: «Email».', 'fashionshoes-child-theme'));
    $text('labels', 'form_message', __('Modulo: campo Messaggio', 'fashionshoes-child-theme'), __('Predefinito: «Messaggio».', 'fashionshoes-child-theme'));
    $text('labels', 'form_consent', __('Modulo: frase del consenso', 'fashionshoes-child-theme'), __('Predefinito: «Ho letto l’%s e accetto che i miei dati siano usati per rispondere al messaggio.». Lascia %s: al suo posto va il collegamento alla privacy.', 'fashionshoes-child-theme'));
    $text('labels', 'form_privacy_link', __('Modulo: parole del collegamento alla privacy', 'fashionshoes-child-theme'), __('Predefinito: «informativa sulla privacy». Le parole che nel consenso aprono la pagina privacy.', 'fashionshoes-child-theme'));
    $text('labels', 'form_send', __('Modulo: pulsante di invio', 'fashionshoes-child-theme'), __('Predefinito: «Invia il messaggio».', 'fashionshoes-child-theme'));
    $text('labels', 'footer_shop', __('Piè di pagina: titolo della colonna del negozio', 'fashionshoes-child-theme'), __('Predefinito: «Negozio».', 'fashionshoes-child-theme'));
    $text('labels', 'footer_follow', __('Piè di pagina: titolo dei social', 'fashionshoes-child-theme'), __('Predefinito: «Seguici».', 'fashionshoes-child-theme'));
    $text('labels', 'footer_privacy', __('Piè di pagina: collegamento alla privacy', 'fashionshoes-child-theme'), __('Predefinito: «Privacy».', 'fashionshoes-child-theme'));
    $text('labels', 'footer_cookies', __('Piè di pagina: impostazioni cookie', 'fashionshoes-child-theme'), __('Predefinito: «Impostazioni cookie».', 'fashionshoes-child-theme'));
});
