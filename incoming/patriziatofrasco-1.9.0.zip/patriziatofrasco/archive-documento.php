<?php
/**
 * Elenco dei Documenti dell'Albo patriziale (/documenti/).
 *
 * I documenti si caricano da Documenti → Aggiungi nuovo (inc/cpt-documenti.php).
 *
 * @package Patriziato Frasco
 */

get_header();

$documenti = function_exists( 'ptf_documenti_elenco' ) ? ptf_documenti_elenco() : array();
?>

<style>
.ptf-documenti { max-width: 900px; margin: var(--space-xl) auto; padding: 0 var(--space-md); }
.ptf-documenti-intro { text-align: center; max-width: 700px; margin: 0 auto var(--space-xl) auto; font-size: 1.1rem; line-height: 1.7; color: var(--color-text-main); }
.ptf-documenti-lista { list-style: none; margin: 0; padding: 0; display: grid; gap: var(--space-md); }
.ptf-documento {
	display: flex;
	align-items: center;
	gap: var(--space-md);
	padding: var(--space-md);
	background: var(--color-bg-pure-white);
	border: 1px solid rgba(0, 0, 0, 0.06);
	border-radius: var(--radius);
	box-shadow: 0 4px 15px rgba(0, 0, 0, 0.04);
	text-decoration: none;
	color: inherit;
	transition: transform 0.3s ease, box-shadow 0.3s ease;
}
.ptf-documento:hover,
.ptf-documento:focus-visible { transform: translateY(-3px); box-shadow: 0 10px 25px rgba(22, 58, 138, 0.1); }
.ptf-documento-icona {
	flex: 0 0 56px;
	height: 56px;
	display: flex;
	align-items: center;
	justify-content: center;
	border-radius: calc(var(--radius) - 4px);
	background: rgba(60, 105, 231, 0.07);
	color: var(--color-primary);
}
.ptf-documento-icona svg { width: 28px; height: 28px; }
.ptf-documento-testo { flex: 1 1 auto; min-width: 0; }
.ptf-documento-titolo { margin: 0; font-family: var(--font-heading); font-size: 1.2rem; line-height: 1.3; color: var(--color-primary-dark); }
.ptf-documento-data { display: block; margin-top: 4px; font-size: 0.85rem; font-weight: 600; color: var(--color-text-light); }
.ptf-documento-descrizione { margin: 6px 0 0; font-size: 0.95rem; line-height: 1.55; color: var(--color-text-main); }
.ptf-documento-azione { flex: 0 0 auto; font-weight: 700; font-size: 0.9rem; color: var(--color-primary); white-space: nowrap; }
.ptf-documenti-vuoto { text-align: center; padding: var(--space-xxl) var(--space-md); background: var(--color-bg-pure-white); border-radius: var(--radius); color: var(--color-primary-light); font-size: 1.1rem; }
.ptf-documenti-indietro { display: inline-block; margin-top: var(--space-xl); font-weight: 600; color: var(--color-primary); text-decoration: none; }
html[data-theme="dark"] .ptf-documento-titolo { color: var(--color-accent); }
@media (max-width: 600px) {
	.ptf-documento { flex-wrap: wrap; }
	.ptf-documento-icona { flex-basis: 44px; height: 44px; }
	.ptf-documento-testo { flex-basis: calc(100% - 44px - var(--space-md)); }
	.ptf-documento-azione { flex-basis: 100%; text-align: right; }
}
</style>

<div class="page-header-cinematic no-bg" style="background-color: var(--color-primary-dark);">
	<div class="page-header-overlay"></div>
	<div class="container page-header-inner animate-on-scroll">
		<h1 class="page-title">Documenti</h1>
		<h2 style="color: var(--color-accent); font-size: 1.5rem; font-weight: 500; font-family: var(--font-heading); margin-top: var(--space-sm);">Verbali, conti e altri documenti del Patriziato.</h2>
	</div>
</div>

<main id="primary" class="site-main">
	<div class="ptf-documenti">
		<?php if ( $documenti ) : ?>
			<p class="ptf-documenti-intro">Ogni documento si apre in formato PDF: si può leggere online o scaricare.</p>
			<ul class="ptf-documenti-lista">
				<?php
				foreach ( $documenti as $documento ) :
					$pdf_url     = wp_get_attachment_url( (int) get_post_meta( $documento->ID, '_documento_pdf_id', true ) );
					$descrizione = get_post_meta( $documento->ID, '_documento_descrizione', true );
					if ( ! $pdf_url ) {
						continue;
					}
					?>
					<li>
						<a class="ptf-documento" href="<?php echo esc_url( $pdf_url ); ?>" target="_blank" rel="noopener">
							<span class="ptf-documento-icona" aria-hidden="true">
								<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M19.5 14.25v-2.625a3.375 3.375 0 0 0-3.375-3.375h-1.5A1.125 1.125 0 0 1 13.5 7.125v-1.5a3.375 3.375 0 0 0-3.375-3.375H8.25m2.25 0H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 0 0-9-9Z" /></svg>
							</span>
							<span class="ptf-documento-testo">
								<h3 class="ptf-documento-titolo"><?php echo esc_html( get_the_title( $documento ) ); ?></h3>
								<span class="ptf-documento-data"><?php echo esc_html( ptf_documento_data_mostrata( $documento->ID ) ); ?></span>
								<?php if ( $descrizione ) : ?>
									<p class="ptf-documento-descrizione"><?php echo esc_html( $descrizione ); ?></p>
								<?php endif; ?>
							</span>
							<span class="ptf-documento-azione">Apri PDF<span class="screen-reader-text"> (si apre in una nuova scheda)</span> &rarr;</span>
						</a>
					</li>
				<?php endforeach; ?>
			</ul>
		<?php else : ?>
			<p class="ptf-documenti-vuoto">Nessun documento pubblicato al momento.</p>
		<?php endif; ?>

		<a class="ptf-documenti-indietro" href="<?php echo esc_url( home_url( '/albo-patriziale/' ) ); ?>">&larr; Torna all'Albo patriziale</a>
	</div>
</main>

<?php
get_footer();
