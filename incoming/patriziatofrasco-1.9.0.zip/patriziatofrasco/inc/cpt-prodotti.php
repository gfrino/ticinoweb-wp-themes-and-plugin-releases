<?php
/**
 * Registrazione Custom Post Type per i Prodotti
 */

// 1. Registra il Custom Post Type
function patriziatofrasco_register_prodotti_cpt() {
    $labels = array(
        'name'                  => _x( 'Prodotti', 'Post type general name', 'patriziatofrasco' ),
        'singular_name'         => _x( 'Prodotto', 'Post type singular name', 'patriziatofrasco' ),
        'menu_name'             => _x( 'Prodotti', 'Admin Menu text', 'patriziatofrasco' ),
        'name_admin_bar'        => _x( 'Prodotto', 'Add New on Toolbar', 'patriziatofrasco' ),
        'add_new'               => __( 'Aggiungi Nuovo', 'patriziatofrasco' ),
        'add_new_item'          => __( 'Aggiungi Nuovo Prodotto', 'patriziatofrasco' ),
        'new_item'              => __( 'Nuovo Prodotto', 'patriziatofrasco' ),
        'edit_item'             => __( 'Modifica Prodotto', 'patriziatofrasco' ),
        'view_item'             => __( 'Visualizza Prodotto', 'patriziatofrasco' ),
        'all_items'             => __( 'Tutti i Prodotti', 'patriziatofrasco' ),
        'search_items'          => __( 'Cerca Prodotti', 'patriziatofrasco' ),
        'not_found'             => __( 'Nessun prodotto trovato.', 'patriziatofrasco' ),
        'not_found_in_trash'    => __( 'Nessun prodotto trovato nel cestino.', 'patriziatofrasco' ),
    );

    $args = array(
        'labels'             => $labels,
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array( 'slug' => 'prodotto' ),
        'capability_type'    => 'post',
        'has_archive'        => false,
        'hierarchical'       => false,
        'menu_position'      => 5.45, // Spostato per scavalcare ticinoWEB CMS
        'menu_icon'          => 'dashicons-cart', // Icona carrello
        'supports'           => array( 'title', 'thumbnail', 'page-attributes' ), // Attiva campo Ordine
        'show_in_rest'       => false, // Disabilita Gutenberg per avere un'interfaccia classica ultra-pulita
    );

    register_post_type( 'prodotto', $args );
}
add_action( 'init', 'patriziatofrasco_register_prodotti_cpt' );

// 2. Aggiunge i Meta Box personalizzati
function patriziatofrasco_add_prodotti_metaboxes() {
    add_meta_box(
        'prodotti_meta_box', // ID
        'Dettagli Prodotto', // Titolo
        'patriziatofrasco_prodotti_metabox_callback', // Callback
        'prodotto', // Post Type
        'normal', // Contesto
        'high' // Priorità
    );
}
add_action( 'add_meta_boxes', 'patriziatofrasco_add_prodotti_metaboxes' );

// 3. Costruisce l'HTML per il Meta Box
function patriziatofrasco_prodotti_metabox_callback( $post ) {
    wp_nonce_field( 'prodotti_save_meta_box_data', 'prodotti_meta_box_nonce' );

    // Recupera i valori attuali
    $descrizione = get_post_meta( $post->ID, '_prodotto_descrizione', true );
    $prezzo      = get_post_meta( $post->ID, '_prodotto_prezzo', true );

    echo '<style>
        .prod-metabox-wrapper { padding: 10px 5px; }
        .prod-field-row { margin-bottom: 25px; }
        .prod-field-row label { display: block; font-weight: 600; margin-bottom: 8px; font-size: 14px; color: #23282d; }
        .prod-field-row input[type=text] { width: 100%; max-width: 320px; padding: 8px 10px; font-size: 14px; border-radius: 4px; border: 1px solid #ccc; }
        .prod-field-row .prod-field-note { margin: 6px 0 0; color: #646970; font-size: 13px; }
        .prod-field-row textarea { width: 100%; height: 120px; padding: 10px; font-size: 14px; border-radius: 4px; border: 1px solid #ccc; font-family: inherit; }
        .prod-help-text { background: #f0f6fc; border-left: 4px solid #72aee6; padding: 10px 15px; margin-bottom: 20px; color: #1d2327; font-size: 14px; }
    </style>';

    echo '<div class="prod-metabox-wrapper">';
    
    echo '<div class="prod-help-text">💡 <strong>Suggerimento:</strong> Inserisci il nome del prodotto nel campo in alto (sotto "Aggiungi Nuovo Prodotto"), carica l\'immagine cliccando su "Imposta immagine in evidenza" nella colonna di destra, e compila i campi sottostanti.</div>';

    // Prezzo: testo libero, così si può scrivere "CHF 25.–" o "da CHF 10.– a CHF 15.–".
    echo '<div class="prod-field-row">';
    echo '<label for="prodotto_prezzo">Prezzo</label>';
    echo '<input type="text" id="prodotto_prezzo" name="prodotto_prezzo" value="' . esc_attr( $prezzo ) . '" placeholder="es. CHF 25.–" />';
    echo '<p class="prod-field-note">Scrivi il prezzo come deve apparire sul sito. Se lo lasci vuoto, il prezzo non viene mostrato.</p>';
    echo '</div>';

    // Descrizione
    echo '<div class="prod-field-row">';
    echo '<label for="prodotto_descrizione">Descrizione del Prodotto</label>';
    echo '<textarea id="prodotto_descrizione" name="prodotto_descrizione" placeholder="Scrivi qui i dettagli dell\'articolo...">' . esc_textarea( $descrizione ) . '</textarea>';
    echo '</div>';

    echo '</div>'; // chiude wrapper
}

// 4. Salva i dati
function patriziatofrasco_save_prodotti_meta_box_data( $post_id ) {
    if ( ! isset( $_POST['prodotti_meta_box_nonce'] ) ) return;
    if ( ! wp_verify_nonce( $_POST['prodotti_meta_box_nonce'], 'prodotti_save_meta_box_data' ) ) return;
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
    if ( isset( $_POST['post_type'] ) && 'prodotto' == $_POST['post_type'] ) {
        if ( ! current_user_can( 'edit_post', $post_id ) ) return;
    }

    if ( isset( $_POST['prodotto_descrizione'] ) ) {
        // Usiamo wp_kses_post per permettere a capo e HTML di base
        update_post_meta( $post_id, '_prodotto_descrizione', wp_kses_post( $_POST['prodotto_descrizione'] ) );
    }

    if ( isset( $_POST['prodotto_prezzo'] ) ) {
        $prezzo = sanitize_text_field( wp_unslash( $_POST['prodotto_prezzo'] ) );
        if ( '' === $prezzo ) {
            delete_post_meta( $post_id, '_prodotto_prezzo' );
        } else {
            update_post_meta( $post_id, '_prodotto_prezzo', $prezzo );
        }
    }
}
add_action( 'save_post', 'patriziatofrasco_save_prodotti_meta_box_data' );

// 5. Aggiunge le colonne personalizzate nella lista dei prodotti nel backend
function patriziatofrasco_set_custom_edit_prodotto_columns($columns) {
    $new_columns = array();
    $new_columns['cb'] = $columns['cb']; // Checkbox
    $new_columns['immagine'] = __( 'Immagine', 'patriziatofrasco' );
    $new_columns['title'] = __( 'Titolo', 'patriziatofrasco' );
    $new_columns['prezzo'] = __( 'Prezzo', 'patriziatofrasco' );
    $new_columns['date'] = $columns['date'];
    return $new_columns;
}
add_filter('manage_prodotto_posts_columns', 'patriziatofrasco_set_custom_edit_prodotto_columns');

// 6. Mostra il contenuto delle colonne personalizzate
function patriziatofrasco_custom_prodotto_column( $column, $post_id ) {
    switch ( $column ) {
        case 'immagine':
            if ( has_post_thumbnail( $post_id ) ) {
                echo get_the_post_thumbnail( $post_id, array( 60, 60 ), array( 'style' => 'border-radius: 4px; object-fit: cover; box-shadow: 0 2px 5px rgba(0,0,0,0.1);' ) );
            } else {
                echo '<div style="width: 60px; height: 60px; background: #f0f0f1; border-radius: 4px; display: flex; align-items: center; justify-content: center; color: #a7aaad; border: 1px dashed #c3c4c7;"><span class="dashicons dashicons-format-image"></span></div>';
            }
            break;
        case 'prezzo':
            $prezzo = get_post_meta( $post_id, '_prodotto_prezzo', true );
            echo $prezzo ? esc_html( $prezzo ) : '<span style="color:#a7aaad;">—</span>';
            break;
    }
}
add_action( 'manage_prodotto_posts_custom_column' , 'patriziatofrasco_custom_prodotto_column', 10, 2 );

// 7. Fissa la larghezza della colonna immagine per non sprecare spazio
function patriziatofrasco_prodotti_admin_css() {
    global $typenow;
    if ( $typenow == 'prodotto' ) {
        echo '<style>
            .wp-list-table .column-immagine { width: 80px !important; text-align: center; }
        </style>';
    }
}
add_action( 'admin_head', 'patriziatofrasco_prodotti_admin_css' );

// 8. Abilita il Drag & Drop per ordinare i prodotti nel backend
function patriziatofrasco_prodotti_enqueue_sortable() {
    global $typenow;
    if ( $typenow == 'prodotto' ) {
        wp_enqueue_script('jquery-ui-sortable');
        wp_add_inline_script('jquery-ui-sortable', "
            jQuery(document).ready(function($) {
                $('.wp-list-table tbody').sortable({
                    items: 'tr',
                    cursor: 'move',
                    axis: 'y',
                    update: function(e, ui) {
                        var postIDs = [];
                        $('.wp-list-table tbody tr').each(function() {
                            var id = $(this).attr('id').replace('post-', '');
                            postIDs.push(id);
                        });
                        
                        $.ajax({
                            url: ajaxurl,
                            type: 'POST',
                            data: {
                                action: 'update_prodotto_order',
                                order: postIDs,
                                security: '" . wp_create_nonce('update_prodotto_order_nonce') . "'
                            }
                        });
                    }
                });
            });
        ");
        
        echo '<style>.wp-list-table tbody tr { cursor: move; } .wp-list-table tbody tr:hover { background-color: #f6f7f7; }</style>';
    }
}
add_action( 'admin_enqueue_scripts', 'patriziatofrasco_prodotti_enqueue_sortable' );

// 9. Salva l'ordine Drag & Drop via AJAX
function patriziatofrasco_save_prodotto_order() {
    check_ajax_referer('update_prodotto_order_nonce', 'security');
    
    if ( ! current_user_can('edit_posts') ) {
        wp_die();
    }
    
    $order = isset($_POST['order']) ? $_POST['order'] : array();
    
    if ( !empty($order) && is_array($order) ) {
        global $wpdb;
        foreach ( $order as $menu_order => $post_id ) {
            $post_id = intval($post_id);
            $menu_order = intval($menu_order);
            
            $wpdb->update( 
                $wpdb->posts, 
                array( 'menu_order' => $menu_order ), 
                array( 'ID' => $post_id ), 
                array( '%d' ), 
                array( '%d' ) 
            );
        }
    }
    
    wp_send_json_success();
}
add_action('wp_ajax_update_prodotto_order', 'patriziatofrasco_save_prodotto_order');

// Chiude il tag PHP
?>
