<?php
/**
 * Feste e attività divise per evento.
 *
 * Usa le gallerie del parent (tassonomia gerarchica `ticinoweb_media_gallery`):
 * ogni evento è una sottogalleria di «Feste e attività», per esempio
 * «Pranzo dei patrizi 23.08.2026». Il cliente la crea da Media → Gallerie
 * scegliendo «Feste e attività» come galleria padre, poi ci aggiunge le foto.
 *
 * @package Patriziato Frasco
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Trova una galleria per nome (gli ID cambiano fra locale e produzione).
 *
 * @param string $nome Nome della galleria.
 * @return WP_Term|null
 */
function ptf_galleria_per_nome( $nome ) {
	$term = get_term_by( 'name', $nome, 'ticinoweb_media_gallery' );
	return ( $term instanceof WP_Term ) ? $term : null;
}

/**
 * Data contenuta nel nome dell'evento (23.08.2026, 23/8/2026, 23-08-2026 o solo 2026).
 *
 * @param string $nome Nome della sottogalleria.
 * @return int Timestamp, 0 se il nome non contiene una data.
 */
function ptf_evento_data_dal_nome( $nome ) {
	if ( preg_match( '/(\d{1,2})[.\/-](\d{1,2})[.\/-](\d{4})/', $nome, $m ) && checkdate( (int) $m[2], (int) $m[1], (int) $m[3] ) ) {
		return (int) mktime( 0, 0, 0, (int) $m[2], (int) $m[1], (int) $m[3] );
	}
	if ( preg_match( '/\b(19|20)\d{2}\b/', $nome, $m ) ) {
		return (int) mktime( 0, 0, 0, 1, 1, (int) $m[0] );
	}
	return 0;
}

/**
 * Sottogallerie (eventi) di una galleria, dal più recente al più vecchio.
 *
 * Ordine: data scritta nel nome; a parità (o senza data) la galleria creata per ultima.
 *
 * @param int $parent_id ID della galleria madre.
 * @return WP_Term[]
 */
function ptf_eventi_galleria( $parent_id ) {
	$eventi = get_terms(
		array(
			'taxonomy'   => 'ticinoweb_media_gallery',
			'parent'     => (int) $parent_id,
			'hide_empty' => false,
		)
	);
	if ( empty( $eventi ) || is_wp_error( $eventi ) ) {
		return array();
	}

	usort(
		$eventi,
		static function ( $a, $b ) {
			$da = ptf_evento_data_dal_nome( $a->name );
			$db = ptf_evento_data_dal_nome( $b->name );
			if ( $da !== $db ) {
				return $db <=> $da;
			}
			return $b->term_id <=> $a->term_id;
		}
	);

	return $eventi;
}

/**
 * Foto di una galleria, senza quelle delle sue sottogallerie.
 *
 * @param int $term_id ID della galleria.
 * @return WP_Query
 */
function ptf_query_foto_galleria( $term_id ) {
	return new WP_Query(
		array(
			'post_type'      => 'attachment',
			'post_status'    => 'inherit',
			'post_mime_type' => 'image',
			'posts_per_page' => -1,
			'no_found_rows'  => true,
			'tax_query'      => array(
				array(
					'taxonomy'         => 'ticinoweb_media_gallery',
					'field'            => 'term_id',
					'terms'            => (int) $term_id,
					'include_children' => false,
				),
			),
		)
	);
}

/**
 * Stampa la griglia di foto (stesso markup e stessa lightbox di Galleria).
 *
 * @param WP_Query $query Foto da mostrare.
 * @return bool True se ha stampato almeno una foto.
 */
function ptf_stampa_griglia_foto( WP_Query $query ) {
	if ( ! $query->have_posts() ) {
		return false;
	}

	$stampate = 0;
	echo '<div class="gallery-grid-images">';
	while ( $query->have_posts() ) {
		$query->the_post();
		$full  = wp_get_attachment_image_src( get_the_ID(), 'full' );
		$thumb = wp_get_attachment_image_src( get_the_ID(), 'medium_large' );
		$full_url  = $full ? $full[0] : '';
		$thumb_url = $thumb ? $thumb[0] : $full_url;
		if ( empty( $full_url ) ) {
			continue;
		}

		// Riquadro sulla miniatura: "Luogo, Data". All'apertura: il campo "Didascalia".
		$didascalia     = function_exists( 'ptf_media_caption' ) ? ptf_media_caption( get_the_ID() ) : '';
		$testo_apertura = function_exists( 'ptf_media_didascalia' ) ? ptf_media_didascalia( get_the_ID() ) : '';
		?>
		<div class="gallery-image-item" data-full-url="<?php echo esc_url( $full_url ); ?>" data-caption="<?php echo esc_attr( $didascalia ); ?>" data-didascalia="<?php echo esc_attr( $testo_apertura ); ?>">
			<img src="<?php echo esc_url( $thumb_url ); ?>" loading="lazy" alt="<?php the_title_attribute(); ?>">
			<?php
			if ( function_exists( 'ptf_media_caption_badge' ) ) {
				ptf_media_caption_badge( $didascalia );
			}
			?>
		</div>
		<?php
		$stampate++;
	}
	echo '</div>';
	wp_reset_postdata();

	return $stampate > 0;
}
