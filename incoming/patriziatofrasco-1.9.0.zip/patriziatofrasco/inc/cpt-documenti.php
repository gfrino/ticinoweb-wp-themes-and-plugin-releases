<?php
/**
 * Documenti dell'Albo patriziale: un elenco di PDF che il Patriziato carica da solo.
 *
 * Ogni documento ha un titolo, un PDF, una data (facoltativa) e una breve descrizione
 * (facoltativa). L'elenco è all'indirizzo /documenti/ (archive-documento.php) e si
 * raggiunge dal riquadro «Documenti» della pagina Albo patriziale.
 * La pagina del singolo documento non serve: porta direttamente al PDF.
 *
 * @package Patriziato Frasco
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Registra il tipo di contenuto «Documento».
 */
function ptf_register_documenti_cpt() {
	register_post_type(
		'documento',
		array(
			'labels'       => array(
				'name'               => 'Documenti',
				'singular_name'      => 'Documento',
				'menu_name'          => 'Documenti',
				'name_admin_bar'     => 'Documento',
				'add_new'            => 'Aggiungi nuovo',
				'add_new_item'       => 'Aggiungi nuovo documento',
				'new_item'           => 'Nuovo documento',
				'edit_item'          => 'Modifica documento',
				'view_item'          => 'Visualizza documento',
				'all_items'          => 'Tutti i documenti',
				'search_items'       => 'Cerca documenti',
				'not_found'          => 'Nessun documento trovato.',
				'not_found_in_trash' => 'Nessun documento nel cestino.',
			),
			'public'       => true,
			'has_archive'  => 'documenti',
			'rewrite'      => array( 'slug' => 'documenti', 'with_front' => false ),
			'menu_position' => 5.46,
			'menu_icon'    => 'dashicons-media-document',
			'supports'     => array( 'title' ),
			'show_in_rest' => false,
		)
	);
}
add_action( 'init', 'ptf_register_documenti_cpt' );

/**
 * Rigenera gli indirizzi una sola volta, quando arriva questa versione del tema,
 * così /documenti/ funziona subito anche sul server senza passare dai Permalink.
 */
function ptf_documenti_flush_rewrite_once() {
	if ( 'documenti-1' !== get_option( 'ptf_rewrite_version' ) ) {
		flush_rewrite_rules( false );
		update_option( 'ptf_rewrite_version', 'documenti-1' );
	}
}
add_action( 'init', 'ptf_documenti_flush_rewrite_once', 20 );

/**
 * Metabox con PDF, data e descrizione.
 */
function ptf_documenti_add_metabox() {
	add_meta_box( 'ptf_documento_dettagli', 'Dettagli del documento', 'ptf_documenti_metabox', 'documento', 'normal', 'high' );
}
add_action( 'add_meta_boxes', 'ptf_documenti_add_metabox' );

/**
 * HTML del metabox.
 *
 * @param WP_Post $post Documento.
 */
function ptf_documenti_metabox( $post ) {
	wp_nonce_field( 'ptf_documento_salva', 'ptf_documento_nonce' );

	$pdf_id      = (int) get_post_meta( $post->ID, '_documento_pdf_id', true );
	$pdf_url     = $pdf_id ? wp_get_attachment_url( $pdf_id ) : '';
	$data        = get_post_meta( $post->ID, '_documento_data', true );
	$descrizione = get_post_meta( $post->ID, '_documento_descrizione', true );
	?>
	<style>
		.ptf-doc-box { padding: 6px 2px; }
		.ptf-doc-aiuto { background: #f0f6fc; border-radius: 4px; padding: 10px 15px; margin-bottom: 20px; font-size: 14px; }
		.ptf-doc-riga { margin-bottom: 22px; }
		.ptf-doc-riga > label { display: block; font-weight: 600; margin-bottom: 8px; font-size: 14px; }
		.ptf-doc-riga textarea { width: 100%; height: 90px; padding: 8px 10px; font-size: 14px; }
		.ptf-doc-nota { margin: 6px 0 0; color: #646970; font-size: 13px; }
		#ptf_documento_pdf_preview { display: block; margin-top: 8px; word-break: break-all; }
	</style>
	<div class="ptf-doc-box">
		<p class="ptf-doc-aiuto">💡 Scrivi il nome del documento nel campo in alto, carica il PDF qui sotto e premi <strong>Pubblica</strong>. Il documento compare nella pagina <strong>Albo patriziale → Documenti</strong>.</p>

		<div class="ptf-doc-riga">
			<label>File PDF</label>
			<input type="hidden" id="ptf_documento_pdf_id" name="ptf_documento_pdf_id" value="<?php echo esc_attr( $pdf_id ? $pdf_id : '' ); ?>" />
			<button type="button" class="button button-primary" id="ptf_documento_pdf_btn">Seleziona o carica PDF</button>
			<button type="button" class="button button-link-delete" id="ptf_documento_pdf_remove" <?php echo $pdf_id ? '' : 'style="display:none;"'; ?>>Rimuovi PDF</button>
			<span id="ptf_documento_pdf_preview">
				<?php if ( $pdf_url ) : ?>
					<a href="<?php echo esc_url( $pdf_url ); ?>" target="_blank" rel="noopener">Apri il PDF attuale (<?php echo esc_html( wp_basename( $pdf_url ) ); ?>)</a>
				<?php endif; ?>
			</span>
		</div>

		<div class="ptf-doc-riga">
			<label for="ptf_documento_data">Data del documento (facoltativa)</label>
			<input type="date" id="ptf_documento_data" name="ptf_documento_data" value="<?php echo esc_attr( $data ); ?>" />
			<p class="ptf-doc-nota">Serve a mettere in ordine l'elenco: i documenti più recenti stanno in alto. Se la lasci vuota vale la data di pubblicazione.</p>
		</div>

		<div class="ptf-doc-riga">
			<label for="ptf_documento_descrizione">Breve descrizione (facoltativa)</label>
			<textarea id="ptf_documento_descrizione" name="ptf_documento_descrizione" placeholder="es. Verbale dell'assemblea ordinaria di primavera"><?php echo esc_textarea( $descrizione ); ?></textarea>
		</div>
	</div>
	<script>
	jQuery( function ( $ ) {
		var frame;
		$( '#ptf_documento_pdf_btn' ).on( 'click', function ( e ) {
			e.preventDefault();
			if ( frame ) { frame.open(); return; }
			frame = wp.media( {
				title: 'Seleziona il PDF',
				button: { text: 'Usa questo file' },
				multiple: false,
				library: { type: 'application/pdf' }
			} );
			frame.on( 'select', function () {
				var file = frame.state().get( 'selection' ).first().toJSON();
				$( '#ptf_documento_pdf_id' ).val( file.id );
				$( '#ptf_documento_pdf_preview' ).empty().append(
					$( '<a target="_blank" rel="noopener">' ).attr( 'href', file.url ).text( 'Apri il PDF attuale (' + file.filename + ')' )
				);
				$( '#ptf_documento_pdf_remove' ).show();
			} );
			frame.open();
		} );
		$( '#ptf_documento_pdf_remove' ).on( 'click', function ( e ) {
			e.preventDefault();
			$( '#ptf_documento_pdf_id' ).val( '' );
			$( '#ptf_documento_pdf_preview' ).empty();
			$( this ).hide();
		} );
	} );
	</script>
	<?php
}

/**
 * Salvataggio dei campi.
 *
 * @param int $post_id ID del documento.
 */
function ptf_documenti_salva( $post_id ) {
	if ( ! isset( $_POST['ptf_documento_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['ptf_documento_nonce'] ) ), 'ptf_documento_salva' ) ) {
		return;
	}
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}
	if ( 'documento' !== get_post_type( $post_id ) || ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}

	$pdf_id = isset( $_POST['ptf_documento_pdf_id'] ) ? absint( $_POST['ptf_documento_pdf_id'] ) : 0;
	if ( $pdf_id && 'application/pdf' === get_post_mime_type( $pdf_id ) ) {
		update_post_meta( $post_id, '_documento_pdf_id', $pdf_id );
	} else {
		delete_post_meta( $post_id, '_documento_pdf_id' );
	}

	$data = isset( $_POST['ptf_documento_data'] ) ? sanitize_text_field( wp_unslash( $_POST['ptf_documento_data'] ) ) : '';
	if ( preg_match( '/^\d{4}-\d{2}-\d{2}$/', $data ) ) {
		update_post_meta( $post_id, '_documento_data', $data );
	} else {
		delete_post_meta( $post_id, '_documento_data' );
	}

	$descrizione = isset( $_POST['ptf_documento_descrizione'] ) ? sanitize_textarea_field( wp_unslash( $_POST['ptf_documento_descrizione'] ) ) : '';
	if ( '' !== $descrizione ) {
		update_post_meta( $post_id, '_documento_descrizione', $descrizione );
	} else {
		delete_post_meta( $post_id, '_documento_descrizione' );
	}
}
add_action( 'save_post', 'ptf_documenti_salva' );

/**
 * Libreria media per il pulsante «Seleziona o carica PDF».
 *
 * @param string $hook Schermata corrente.
 */
function ptf_documenti_admin_scripts( $hook ) {
	if ( in_array( $hook, array( 'post.php', 'post-new.php' ), true ) && 'documento' === get_current_screen()->post_type ) {
		wp_enqueue_media();
	}
}
add_action( 'admin_enqueue_scripts', 'ptf_documenti_admin_scripts' );

/**
 * Avviso nell'editor se il documento è pubblicato senza PDF.
 */
function ptf_documenti_avviso_senza_pdf() {
	$screen = get_current_screen();
	if ( ! $screen || 'documento' !== $screen->post_type || 'post' !== $screen->base ) {
		return;
	}
	$post = get_post();
	if ( $post && 'publish' === $post->post_status && ! get_post_meta( $post->ID, '_documento_pdf_id', true ) ) {
		echo '<div class="notice notice-warning"><p>Questo documento non ha ancora un PDF: sul sito non viene mostrato finché non ne carichi uno.</p></div>';
	}
}
add_action( 'admin_notices', 'ptf_documenti_avviso_senza_pdf' );

/**
 * Colonne dell'elenco nel pannello.
 *
 * @param array $columns Colonne.
 * @return array
 */
function ptf_documenti_colonne( $columns ) {
	return array(
		'cb'        => $columns['cb'],
		'title'     => 'Titolo',
		'ptf_pdf'   => 'PDF',
		'ptf_data'  => 'Data del documento',
		'date'      => $columns['date'],
	);
}
add_filter( 'manage_documento_posts_columns', 'ptf_documenti_colonne' );

/**
 * Contenuto delle colonne.
 *
 * @param string $column  Colonna.
 * @param int    $post_id Documento.
 */
function ptf_documenti_colonna( $column, $post_id ) {
	if ( 'ptf_pdf' === $column ) {
		$pdf_id = (int) get_post_meta( $post_id, '_documento_pdf_id', true );
		echo $pdf_id ? esc_html( wp_basename( (string) wp_get_attachment_url( $pdf_id ) ) ) : '<span style="color:#b32d2e;">manca il PDF</span>';
	}
	if ( 'ptf_data' === $column ) {
		$data = get_post_meta( $post_id, '_documento_data', true );
		echo $data ? esc_html( wp_date( 'd.m.Y', strtotime( $data ) ) ) : '—';
	}
}
add_action( 'manage_documento_posts_custom_column', 'ptf_documenti_colonna', 10, 2 );

/**
 * Data mostrata per un documento: quella del documento o, se manca, quella di pubblicazione.
 *
 * @param int $post_id Documento.
 * @return string Data nel formato 23.08.2026.
 */
function ptf_documento_data_mostrata( $post_id ) {
	$data = get_post_meta( $post_id, '_documento_data', true );
	return $data ? wp_date( 'd.m.Y', strtotime( $data ) ) : get_the_date( 'd.m.Y', $post_id );
}

/**
 * Documenti da mostrare: solo quelli con un PDF, dal più recente al più vecchio.
 * Vale la data del documento; se manca, quella di pubblicazione.
 *
 * @return WP_Post[]
 */
function ptf_documenti_elenco() {
	$documenti = get_posts(
		array(
			'post_type'      => 'documento',
			'post_status'    => 'publish',
			'posts_per_page' => -1,
			'meta_key'       => '_documento_pdf_id', // phpcs:ignore WordPress.DB.SlowDBQuery
			'meta_compare'   => 'EXISTS',
		)
	);

	$chiave = static function ( $post ) {
		$data = get_post_meta( $post->ID, '_documento_data', true );
		return $data ? $data . ' 00:00:00' : $post->post_date;
	};
	usort(
		$documenti,
		static function ( $a, $b ) use ( $chiave ) {
			return strcmp( $chiave( $b ), $chiave( $a ) );
		}
	);

	return $documenti;
}

/**
 * La pagina del singolo documento porta direttamente al PDF.
 */
function ptf_documento_singolo_al_pdf() {
	if ( ! is_singular( 'documento' ) ) {
		return;
	}
	$pdf_id  = (int) get_post_meta( get_queried_object_id(), '_documento_pdf_id', true );
	$pdf_url = $pdf_id ? wp_get_attachment_url( $pdf_id ) : '';
	wp_safe_redirect( $pdf_url ? $pdf_url : get_post_type_archive_link( 'documento' ), 302 );
	exit;
}
add_action( 'template_redirect', 'ptf_documento_singolo_al_pdf' );

/**
 * Le pagine dei singoli documenti sono solo un rimando al PDF: fuori dalla sitemap.
 * Resta l'elenco /documenti/. Si somma alle esclusioni impostate in tW SEO.
 *
 * @param array $post_types Tipi di contenuto nella sitemap.
 * @return array
 */
function ptf_documenti_fuori_sitemap( $post_types ) {
	unset( $post_types['documento'] );
	return $post_types;
}
add_filter( 'wp_sitemaps_post_types', 'ptf_documenti_fuori_sitemap', 20 );
