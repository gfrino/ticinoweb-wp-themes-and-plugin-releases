(function () {
	'use strict';

	function isValidClosureDate(value) {
		if (!/^\d{4}-\d{2}-\d{2}$/.test(value || '')) return false;
		var parts = value.split('-').map(Number);
		var parsed = new Date(Date.UTC(parts[0], parts[1] - 1, parts[2]));
		return parsed.getUTCFullYear() === parts[0] && parsed.getUTCMonth() === parts[1] - 1 && parsed.getUTCDate() === parts[2];
	}

	function addClosureDate(dates, value) {
		var cleanDates = Array.isArray(dates) ? dates.filter(isValidClosureDate) : [];
		cleanDates = cleanDates.filter(function (date, index) { return cleanDates.indexOf(date) === index; });
		var added = isValidClosureDate(value) && cleanDates.indexOf(value) === -1;
		if (added) cleanDates.push(value);
		cleanDates.sort();
		return { dates: cleanDates, added: added };
	}

	if (typeof module !== 'undefined' && module.exports) {
		module.exports = { addClosureDate: addClosureDate, isValidClosureDate: isValidClosureDate };
	}
	if (typeof document === 'undefined') return;
	if (document.documentElement) document.documentElement.classList.add('gl-app-operations-js-ready');

	var tabNavigation = document.querySelector('.gl-app-admin .nav-tab-wrapper');
	var activeTab = tabNavigation ? tabNavigation.querySelector('.nav-tab-active') : null;
	function keepActiveTabVisible() {
		if (!activeTab || !window.matchMedia('(max-width: 782px)').matches || tabNavigation.scrollWidth <= tabNavigation.clientWidth) return;
		window.requestAnimationFrame(function () {
			var navigationBox = tabNavigation.getBoundingClientRect();
			var activeBox = activeTab.getBoundingClientRect();
			var target = tabNavigation.scrollLeft + (activeBox.left - navigationBox.left) - ((tabNavigation.clientWidth - activeBox.width) / 2);
			tabNavigation.scrollLeft = Math.max(0, target);
		});
	}
	function scheduleActiveTabVisibility() {
		keepActiveTabVisible();
		window.setTimeout(keepActiveTabVisible, 200);
	}
	scheduleActiveTabVisibility();
	if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', scheduleActiveTabVisibility, { once: true });
	window.addEventListener('load', scheduleActiveTabVisibility, { once: true });
	window.addEventListener('resize', keepActiveTabVisible);

	document.querySelectorAll('[data-gl-stripe-settings]').forEach(function (root) {
		var controls = Array.prototype.slice.call(root.querySelectorAll('[data-gl-stripe-mode]'));
		var panels = Array.prototype.slice.call(root.querySelectorAll('[data-gl-stripe-panel]'));
		var current = root.querySelector('[data-gl-stripe-current]');
		if (!controls.length || !panels.length) return;

		root.classList.add('is-enhanced');

		function syncMode() {
			var selected = controls.find(function (control) { return control.checked; });
			var mode = selected ? selected.value : 'test';
			panels.forEach(function (panel) {
				var active = panel.getAttribute('data-gl-stripe-panel') === mode;
				panel.hidden = !active;
				panel.classList.toggle('is-active', active);
			});
			if (current) {
				var template = current.getAttribute('data-gl-stripe-current-template') || '%s';
				var label = selected ? selected.getAttribute('data-gl-stripe-label') : 'Test';
				current.textContent = template.replace('%s', label);
			}
		}

		controls.forEach(function (control) { control.addEventListener('change', syncMode); });
		syncMode();
	});

	document.querySelectorAll('[data-gl-schedule-week]').forEach(function (week) {
		var pattern = week.getAttribute('data-gl-schedule-week');

		week.querySelectorAll('[data-gl-schedule-day]').forEach(function (dayRow) {
			var day = dayRow.getAttribute('data-gl-schedule-day');
			var openControl = dayRow.querySelector('[data-gl-day-open]');
			var rangeList = dayRow.querySelector('[data-gl-time-ranges]');
			var addButton = dayRow.querySelector('[data-gl-add-range]');
			if (!openControl || !rangeList || !addButton) return;

			function nextIndex() {
				var indexes = Array.prototype.map.call(rangeList.querySelectorAll('[data-gl-range-index]'), function (range) {
					return parseInt(range.getAttribute('data-gl-range-index'), 10) || 0;
				});
				return indexes.length ? Math.max.apply(Math, indexes) + 1 : 0;
			}

			function makeTimeField(index, key, label) {
				var wrapper = document.createElement('label');
				var text = document.createElement('span');
				var input = document.createElement('input');
				text.textContent = label;
				input.type = 'time';
				input.name = 'settings[weekly_patterns][' + pattern + '][' + day + '][ranges][' + index + '][' + key + ']';
				input.setAttribute('aria-label', dayRow.querySelector('.gl-app-schedule__day-name').textContent + ': ' + (key === 'open' ? 'dalle' : 'alle'));
				wrapper.appendChild(text);
				wrapper.appendChild(input);
				return wrapper;
			}

			function addRange() {
				var index = nextIndex();
				var range = document.createElement('div');
				var remove = document.createElement('button');
				range.className = 'gl-app-time-range';
				range.setAttribute('data-gl-time-range', '');
				range.setAttribute('data-gl-range-index', String(index));
				range.appendChild(makeTimeField(index, 'open', 'Da'));
				range.appendChild(makeTimeField(index, 'close', 'A'));
				remove.type = 'button';
				remove.className = 'button-link-delete gl-app-time-range__remove';
				remove.setAttribute('data-gl-remove-range', '');
				remove.setAttribute('aria-label', 'Rimuovi questo orario');
				remove.textContent = '\u00d7';
				range.appendChild(remove);
				rangeList.appendChild(range);
				openControl.checked = true;
				syncDay();
				range.querySelector('input').focus();
			}

			function syncDay() {
				var isOpen = openControl.checked;
				dayRow.classList.toggle('is-open', isOpen);
				dayRow.classList.toggle('is-closed', !isOpen);
				var state = dayRow.querySelector('[data-gl-open-label]');
				if (state) state.textContent = isOpen ? 'Aperto' : 'Chiuso';
				rangeList.querySelectorAll('input').forEach(function (input) { input.disabled = !isOpen; });
			}

			openControl.addEventListener('change', function () {
				if (openControl.checked && !rangeList.querySelector('[data-gl-time-range]')) addRange();
				else syncDay();
			});
			addButton.addEventListener('click', addRange);
			rangeList.addEventListener('click', function (event) {
				var remove = event.target.closest('[data-gl-remove-range]');
				if (!remove) return;
				remove.closest('[data-gl-time-range]').remove();
				if (!rangeList.querySelector('[data-gl-time-range]')) openControl.checked = false;
				syncDay();
			});
			syncDay();
		});
	});

	document.querySelectorAll('[data-gl-closure-dates]').forEach(function (root) {
		var picker = root.querySelector('[data-gl-closure-date-picker]');
		var addButton = root.querySelector('[data-gl-add-closure-date]');
		var list = root.querySelector('[data-gl-closure-date-list]');
		var empty = root.querySelector('[data-gl-closure-date-empty]');
		var status = root.querySelector('[data-gl-closure-date-status]');
		if (!picker || !addButton || !list) return;

		function message(key) {
			if (status) status.textContent = root.getAttribute('data-gl-' + key + '-message') || '';
		}

		function currentDates() {
			return Array.prototype.map.call(list.querySelectorAll('[data-gl-closure-date-input]'), function (input) {
				return input.value;
			}).filter(isValidClosureDate);
		}

		function syncEmptyState() {
			if (empty) empty.hidden = Boolean(list.querySelector('[data-gl-closure-date-item]'));
		}

		function sortItems() {
			Array.prototype.slice.call(list.querySelectorAll('[data-gl-closure-date-item]')).sort(function (first, second) {
				return first.querySelector('[data-gl-closure-date-input]').value.localeCompare(second.querySelector('[data-gl-closure-date-input]').value);
			}).forEach(function (item) { list.appendChild(item); });
		}

		function makeItem(value) {
			var item = document.createElement('li');
			var label = document.createElement('label');
			var screenReaderText = document.createElement('span');
			var input = document.createElement('input');
			var remove = document.createElement('button');
			item.className = 'gl-app-closure-dates__item';
			item.setAttribute('data-gl-closure-date-item', '');
			screenReaderText.className = 'screen-reader-text';
			screenReaderText.textContent = root.getAttribute('data-gl-input-label') || 'Giorno chiuso';
			input.type = 'date';
			input.name = 'settings[closure_dates][]';
			input.value = value;
			input.setAttribute('data-gl-closure-date-input', '');
			remove.type = 'button';
			remove.className = 'button-link-delete';
			remove.setAttribute('data-gl-remove-closure-date', '');
			remove.textContent = root.getAttribute('data-gl-remove-label') || 'Rimuovi';
			label.appendChild(screenReaderText);
			label.appendChild(input);
			item.appendChild(label);
			item.appendChild(remove);
			return item;
		}

		addButton.addEventListener('click', function () {
			var result = addClosureDate(currentDates(), picker.value);
			if (!isValidClosureDate(picker.value)) {
				message('invalid');
				picker.focus();
				return;
			}
			if (!result.added) {
				message('duplicate');
				var duplicate = Array.prototype.find.call(list.querySelectorAll('[data-gl-closure-date-input]'), function (input) { return input.value === picker.value; });
				if (duplicate) duplicate.focus();
				return;
			}
			list.appendChild(makeItem(picker.value));
			picker.value = '';
			sortItems();
			syncEmptyState();
			message('added');
			picker.focus();
		});

		list.addEventListener('click', function (event) {
			var remove = event.target.closest('[data-gl-remove-closure-date]');
			if (!remove) return;
			remove.closest('[data-gl-closure-date-item]').remove();
			syncEmptyState();
			message('removed');
			picker.focus();
		});

		list.addEventListener('change', function (event) {
			if (!event.target.matches('[data-gl-closure-date-input]')) return;
			sortItems();
			message('');
		});
		syncEmptyState();
	});
}());
