(function () {
  'use strict';

  var initialized = false;

  function init() {
    if (initialized) return;
    initialized = true;
    document.documentElement.classList.add('gl-admin-js-ready');
    var hasUnsavedChanges = false;
	var operationsNavigation = document.querySelector('.gl-app-admin .nav-tab-wrapper');
	var operationsActiveTab = operationsNavigation ? operationsNavigation.querySelector('.nav-tab-active') : null;
	if (operationsNavigation && operationsActiveTab && window.matchMedia('(max-width: 782px)').matches && operationsNavigation.scrollWidth > operationsNavigation.clientWidth) {
		window.requestAnimationFrame(function () {
			var navigationBox = operationsNavigation.getBoundingClientRect();
			var activeBox = operationsActiveTab.getBoundingClientRect();
			var target = operationsNavigation.scrollLeft + (activeBox.left - navigationBox.left) - ((operationsNavigation.clientWidth - activeBox.width) / 2);
			operationsNavigation.scrollLeft = Math.max(0, target);
		});
	}

    function markUnsaved(form, message) {
      hasUnsavedChanges = true;
      if (!form) return;
      form.dataset.glDirty = 'true';
      var bar = form.querySelector('[data-gl-save-bar]');
      var state = form.querySelector('[data-gl-save-state]');
      if (bar) bar.classList.add('is-dirty');
      if (state) state.textContent = message || 'Modifiche non salvate';
    }

    function clearUnsaved() {
      hasUnsavedChanges = false;
    }

    window.addEventListener('beforeunload', function (event) {
      if (!hasUnsavedChanges) return;
      event.preventDefault();
      event.returnValue = '';
    });

    document.querySelectorAll('[data-gl-form]').forEach(function (form) {
      form.addEventListener('input', function () { markUnsaved(form); });
      form.addEventListener('change', function () { markUnsaved(form); });
      form.addEventListener('submit', clearUnsaved);

      form.addEventListener('invalid', function (event) {
        var field = event.target.closest('.gl-admin-field');
        var error = field ? field.querySelector('.gl-admin-field__error') : null;
        if (error) {
          error.textContent = event.target.validationMessage || 'Controlla questo campo.';
          error.hidden = false;
        }
        var state = form.querySelector('[data-gl-save-state]');
        if (state) state.textContent = 'Errore di validazione';
      }, true);

      form.querySelectorAll('input, select, textarea').forEach(function (control) {
        control.addEventListener('input', function () {
          var error = control.closest('.gl-admin-field') ? control.closest('.gl-admin-field').querySelector('.gl-admin-field__error') : null;
          if (error && control.checkValidity()) {
            error.hidden = true;
            error.textContent = '';
          }
        });
      });
    });

    function setParticipantState(mode, wrapper) {
      if (!wrapper) return;
      var input = wrapper.querySelector('input');
      var relevant = mode === 'individual' || mode === 'group';
      wrapper.hidden = !relevant;
      if (!input || !relevant) return;

      if (mode === 'individual') {
        if (!input.dataset.glIndividualLock) input.dataset.glPreviousValue = input.value;
        input.dataset.glIndividualLock = 'true';
        input.value = '1';
        input.readOnly = true;
        input.setAttribute('aria-readonly', 'true');
      } else {
        if (input.dataset.glIndividualLock && input.dataset.glPreviousValue && input.dataset.glPreviousValue !== '1') {
          input.value = input.dataset.glPreviousValue;
        }
        delete input.dataset.glIndividualLock;
        input.readOnly = false;
        input.removeAttribute('aria-readonly');
      }
    }

    var groupForm = document.querySelector('[data-gl-group-form]');
    if (groupForm) {
      var groupMode = groupForm.querySelector('[data-gl-field="mode"]');
      var groupParticipants = groupForm.querySelector('[data-gl-group-participants]');
      var syncGroupMode = function () {
        if (groupMode) setParticipantState(groupMode.value, groupParticipants);
      };
      if (groupMode) groupMode.addEventListener('change', syncGroupMode);
      syncGroupMode();
    }

    var packageForm = document.querySelector('[data-gl-package-form]');
    if (packageForm) {
      var course = packageForm.querySelector('[data-gl-field="group_id"]');
      var training = packageForm.querySelector('[data-gl-section="training"]');
      var priceModel = packageForm.querySelector('[data-gl-field="price_model"]');
      var price = packageForm.querySelector('[data-gl-field="price"]');
      var title = packageForm.querySelector('[data-gl-field="title"]');
      var pricePreview = packageForm.querySelector('[data-gl-price-preview]');
      var titlePreview = packageForm.querySelector('[data-gl-title-preview]');

      var syncPackageMode = function () {
        if (!course) return;
        var selected = course.options[course.selectedIndex];
        if (training) training.hidden = selected && selected.dataset.glMode === 'digital';
      };

      var syncPreview = function () {
        if (titlePreview && title) titlePreview.textContent = title.value.trim() || 'Senza titolo';
        if (!pricePreview || !price) return;
        var number = Number(price.value.replace(',', '.'));
        var formatted = Number.isFinite(number) ? (Number.isInteger(number) ? number.toFixed(0) + '.–' : number.toFixed(2)) : '0.–';
        var suffixText = priceModel && priceModel.value === 'display_monthly' ? '/mese' : '';
        pricePreview.textContent = 'CHF ' + formatted + (suffixText ? ' ' + suffixText : '');
      };

      if (course) course.addEventListener('change', syncPackageMode);
      if (priceModel) priceModel.addEventListener('change', syncPreview);
      if (price) price.addEventListener('input', syncPreview);
      if (title) title.addEventListener('input', syncPreview);
      syncPackageMode();
      syncPreview();
    }

    document.querySelectorAll('[data-gl-media]').forEach(function (mediaField) {
      var selectButton = mediaField.querySelector('[data-gl-media-select]');
      var removeButton = mediaField.querySelector('[data-gl-media-remove]');
      var preview = mediaField.querySelector('[data-gl-media-preview]');
      var input = mediaField.querySelector('[data-gl-media-id]');
      var form = mediaField.closest('[data-gl-form]');
      var frame = null;

      if (selectButton) {
        selectButton.addEventListener('click', function () {
          if (!window.wp || !wp.media) return;
          if (!frame) {
            frame = wp.media({ title: 'Scegli immagine del percorso', button: { text: 'Usa questa immagine' }, multiple: false, library: { type: 'image' } });
            frame.on('select', function () {
              var attachment = frame.state().get('selection').first().toJSON();
              var source = attachment.sizes && attachment.sizes.medium ? attachment.sizes.medium.url : attachment.url;
              var image = document.createElement('img');
              image.src = source;
              image.alt = attachment.alt || '';
              image.className = 'gl-admin__media-image';
              preview.replaceChildren(image);
              preview.classList.remove('is-empty');
              input.value = attachment.id;
              removeButton.hidden = false;
              markUnsaved(form);
            });
          }
          frame.open();
        });
      }

      if (removeButton) {
        removeButton.addEventListener('click', function () {
          var empty = document.createElement('span');
          empty.textContent = 'Nessuna immagine selezionata';
          preview.replaceChildren(empty);
          preview.classList.add('is-empty');
          input.value = '';
          removeButton.hidden = true;
          markUnsaved(form);
        });
      }
    });

  }

  function boot() {
    if (document.querySelector('[data-gl-admin-dom-ready]')) {
      init();
      return;
    }
    if (document.readyState !== 'complete') window.setTimeout(boot, 50);
  }

  boot();
}());
