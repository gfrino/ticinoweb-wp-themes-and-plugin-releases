<?php
/** Compact operations administration. @package GluteLabChildTheme */
if ( ! defined( 'ABSPATH' ) ) exit;

$GLOBALS['glutelab_app_admin_hook'] = '';
function glutelab_app_admin_menu() {
	$capability = glutelab_app_management_capability();
	if ( glutelab_access_is_restricted_context() ) {
		$GLOBALS['glutelab_app_admin_hook'] = add_menu_page( __( 'Gestione Glute Lab', 'glutelab-child-theme' ), __( 'Gestione Glute Lab', 'glutelab-child-theme' ), $capability, 'glutelab-operations', 'glutelab_app_admin_page', 'dashicons-calendar-alt', 2 );
		return;
	}
	$GLOBALS['glutelab_app_admin_hook'] = add_submenu_page( 'ticinoweb-cms', __( 'Gestione Glute Lab', 'glutelab-child-theme' ), __( 'Gestione Glute Lab', 'glutelab-child-theme' ), $capability, 'glutelab-operations', 'glutelab_app_admin_page' );
}
add_action( 'admin_menu', 'glutelab_app_admin_menu', 30 );

function glutelab_app_admin_assets( $hook ) {
	if ( $hook !== ( $GLOBALS['glutelab_app_admin_hook'] ?? '' ) ) return;
	$file = get_stylesheet_directory() . '/assets/css/admin-app.css'; wp_enqueue_style( 'glutelab-admin-app', get_stylesheet_directory_uri() . '/assets/css/admin-app.css', array(), is_file( $file ) ? filemtime( $file ) : GLUTELAB_THEME_VERSION );
	$script = get_stylesheet_directory() . '/assets/js/admin-app.js'; wp_enqueue_script( 'glutelab-admin-app', get_stylesheet_directory_uri() . '/assets/js/admin-app.js', array(), is_file( $script ) ? filemtime( $script ) : GLUTELAB_THEME_VERSION, true );
}
add_action( 'admin_enqueue_scripts', 'glutelab_app_admin_assets' );

function glutelab_app_admin_url( $view ) { return add_query_arg( array( 'page' => 'glutelab-operations', 'view' => sanitize_key( $view ) ), admin_url( 'admin.php' ) ); }
function glutelab_app_admin_page() {
	if ( ! current_user_can( glutelab_app_management_capability() ) ) return;
	$view = sanitize_key( $_GET['view'] ?? 'overview' ); $allowed = array( 'overview', 'bookings', 'customers', 'availability', 'packages', 'payments', 'settings', 'durations' ); if ( ! in_array( $view, $allowed, true ) ) $view = 'overview';
	$nav_view = 'durations' === $view ? 'availability' : $view;
	?><div class="wrap gl-app-admin"><header class="gl-app-admin__header"><div class="gl-app-admin__brand"><span class="gl-app-admin__brand-mark" aria-hidden="true"><img src="<?php echo esc_url( get_stylesheet_directory_uri() . '/assets/images/glutelab-logo.png' ); ?>" alt=""></span><div class="gl-app-admin__header-copy"><p class="gl-app-admin__eyebrow">GLUTE LAB</p><h1><?php esc_html_e( 'Gestione operativa', 'glutelab-child-theme' ); ?></h1><p><?php esc_html_e( 'Calendario, clienti, pacchetti e pagamenti online in un solo posto.', 'glutelab-child-theme' ); ?></p></div></div><div class="gl-app-admin__status"><span class="gl-app-admin__state <?php echo glutelab_app_is_enabled() ? 'is-on' : ''; ?>"><i aria-hidden="true"></i><?php echo glutelab_app_is_enabled() ? esc_html__( 'Sistema attivo', 'glutelab-child-theme' ) : esc_html__( 'Sistema disattivato', 'glutelab-child-theme' ); ?></span><small><?php echo esc_html( sprintf( __( 'Oggi, %s', 'glutelab-child-theme' ), wp_date( 'j F Y' ) ) ); ?></small></div></header>
	<nav class="nav-tab-wrapper" aria-label="<?php esc_attr_e( 'Sezioni gestione', 'glutelab-child-theme' ); ?>"><?php foreach ( array( 'overview' => __( 'Panoramica', 'glutelab-child-theme' ), 'bookings' => __( 'Calendario', 'glutelab-child-theme' ), 'customers' => __( 'Clienti', 'glutelab-child-theme' ), 'availability' => __( 'Orari', 'glutelab-child-theme' ), 'packages' => __( 'Pacchetti', 'glutelab-child-theme' ), 'payments' => __( 'Pagamenti', 'glutelab-child-theme' ), 'settings' => __( 'Impostazioni', 'glutelab-child-theme' ) ) as $key => $label ) : ?><a class="nav-tab <?php echo $nav_view === $key ? 'nav-tab-active' : ''; ?>" href="<?php echo esc_url( glutelab_app_admin_url( $key ) ); ?>"><?php echo esc_html( $label ); ?></a><?php endforeach; ?></nav>
	<?php if ( ! empty( $_GET['gl_notice'] ) ) :
		$notice = sanitize_key( $_GET['gl_notice'] );
		$error = in_array( $notice, array( 'error', 'insufficient_credits', 'booking_not_found', 'invalid_status_transition', 'payment_required', 'stripe_credentials_invalid', 'order_not_found', 'payment_not_remindable', 'payment_data_missing', 'stripe_not_configured', 'stripe_checkout_failed', 'payment_reminder_mail_failed' ), true );
		$message = 'stripe_credentials_invalid' === $notice
			? __( 'Credenziali Stripe non salvate: verifica che le chiavi Test inizino con pk_test_ e sk_test_, e quelle Live con pk_live_ e sk_live_.', 'glutelab-child-theme' )
			: ( 'payment_reminder_sent' === $notice ? __( 'Promemoria di pagamento inviato.', 'glutelab-child-theme' ) : ( $error ? __( 'Operazione non completata. Controlla i dati e la configurazione Stripe.', 'glutelab-child-theme' ) : __( 'Operazione completata.', 'glutelab-child-theme' ) ) );
		?><div class="notice <?php echo $error ? 'notice-error' : 'notice-success'; ?> is-dismissible"><p><?php echo esc_html( $message ); ?></p></div><?php endif; ?>
	<main class="gl-app-admin__content"><?php call_user_func( 'glutelab_app_admin_' . $view ); ?></main></div><?php
}

function glutelab_app_admin_count( $metric ) {
	global $wpdb;
	if ( 'open_orders' === $metric ) { $name = glutelab_app_table( 'orders' ); return (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$name} WHERE status IN ('pending','awaiting_payment')" ); } // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	if ( 'future_bookings' === $metric ) { $name = glutelab_app_table( 'bookings' ); return (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$name} WHERE (start_at_utc >= UTC_TIMESTAMP() OR preferred_date >= CURDATE()) AND status IN ('requested','pending','confirmed','paid')" ); } // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	if ( 'customers' === $metric ) { $name = glutelab_app_table( 'customers' ); return (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$name}" ); } // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	return 0;
}
function glutelab_app_admin_overview() {
	$open_orders     = glutelab_app_admin_count( 'open_orders' );
	$future_bookings = glutelab_app_admin_count( 'future_bookings' );
	$customers       = glutelab_app_admin_count( 'customers' );
	glutelab_app_admin_view_header( __( 'Panoramica', 'glutelab-child-theme' ), __( 'Le informazioni essenziali per gestire le richieste di Glute Lab.', 'glutelab-child-theme' ) );
	?><section class="gl-app-overview-grid gl-app-cards" aria-label="<?php esc_attr_e( 'Riepilogo attività', 'glutelab-child-theme' ); ?>">
		<article class="gl-app-metric-card<?php echo $open_orders > 0 ? ' has-attention' : ''; ?>"><div class="gl-app-metric-card__top"><span><?php esc_html_e( 'Richieste aperte', 'glutelab-child-theme' ); ?></span><i class="dashicons dashicons-clipboard" aria-hidden="true"></i></div><strong><?php echo esc_html( $open_orders ); ?></strong><small><?php echo $open_orders > 0 ? esc_html__( 'Da verificare o confermare', 'glutelab-child-theme' ) : esc_html__( 'Nessuna richiesta in attesa', 'glutelab-child-theme' ); ?></small><a href="<?php echo esc_url( glutelab_app_admin_url( 'bookings' ) ); ?>"><?php esc_html_e( 'Apri richieste', 'glutelab-child-theme' ); ?><span aria-hidden="true">→</span></a></article>
		<article class="gl-app-metric-card"><div class="gl-app-metric-card__top"><span><?php esc_html_e( 'Prenotazioni future', 'glutelab-child-theme' ); ?></span><i class="dashicons dashicons-calendar-alt" aria-hidden="true"></i></div><strong><?php echo esc_html( $future_bookings ); ?></strong><small><?php esc_html_e( 'Con giorno o orario scelto', 'glutelab-child-theme' ); ?></small><a href="<?php echo esc_url( glutelab_app_admin_url( 'bookings' ) ); ?>"><?php esc_html_e( 'Vedi calendario', 'glutelab-child-theme' ); ?><span aria-hidden="true">→</span></a></article>
		<article class="gl-app-metric-card"><div class="gl-app-metric-card__top"><span><?php esc_html_e( 'Clienti', 'glutelab-child-theme' ); ?></span><i class="dashicons dashicons-groups" aria-hidden="true"></i></div><strong><?php echo esc_html( $customers ); ?></strong><small><?php esc_html_e( 'Persone registrate', 'glutelab-child-theme' ); ?></small><a href="<?php echo esc_url( glutelab_app_admin_url( 'customers' ) ); ?>"><?php esc_html_e( 'Apri clienti', 'glutelab-child-theme' ); ?><span aria-hidden="true">→</span></a></article>
	</section>
	<section class="gl-app-panel gl-app-quick-actions"><div class="gl-app-quick-actions__heading"><p class="gl-app-admin__eyebrow"><?php esc_html_e( 'SCORCIATOIE', 'glutelab-child-theme' ); ?></p><h2><?php esc_html_e( 'Cosa vuoi fare?', 'glutelab-child-theme' ); ?></h2><p><?php esc_html_e( 'Apri direttamente l’area che ti serve.', 'glutelab-child-theme' ); ?></p></div><div class="gl-app-quick-actions__buttons"><a class="gl-app-action-card is-primary" href="<?php echo esc_url( glutelab_app_admin_url( 'bookings' ) ); ?>"><i class="dashicons dashicons-calendar-alt" aria-hidden="true"></i><span><strong><?php esc_html_e( 'Apri il calendario', 'glutelab-child-theme' ); ?></strong><small><?php esc_html_e( 'Controlla gli impegni', 'glutelab-child-theme' ); ?></small></span><b aria-hidden="true">→</b></a><a class="gl-app-action-card" href="<?php echo esc_url( glutelab_app_admin_url( 'availability' ) ); ?>"><i class="dashicons dashicons-clock" aria-hidden="true"></i><span><strong><?php esc_html_e( 'Imposta gli orari', 'glutelab-child-theme' ); ?></strong><small><?php esc_html_e( 'Settimane e disponibilità', 'glutelab-child-theme' ); ?></small></span><b aria-hidden="true">→</b></a><a class="gl-app-action-card" href="<?php echo esc_url( glutelab_app_admin_url( 'payments' ) ); ?>"><i class="dashicons dashicons-money-alt" aria-hidden="true"></i><span><strong><?php esc_html_e( 'Controlla i pagamenti', 'glutelab-child-theme' ); ?></strong><small><?php esc_html_e( 'Incassi e promemoria', 'glutelab-child-theme' ); ?></small></span><b aria-hidden="true">→</b></a></div></section><?php
}

/** Shared heading for the operational tabs. */
function glutelab_app_admin_view_header( $title, $description, $meta = '' ) {
	?>
	<header class="gl-app-view-header">
		<div class="gl-app-view-header__copy"><h2><?php echo esc_html( $title ); ?></h2><p><?php echo esc_html( $description ); ?></p></div>
		<?php if ( '' !== (string) $meta ) : ?><strong class="gl-app-view-header__meta"><?php echo esc_html( $meta ); ?></strong><?php endif; ?>
	</header>
	<?php
}

/** Convert internal states to labels a client can understand. */
function glutelab_app_admin_status_label( $status ) {
	$labels = array(
		'pending'          => __( 'Da pagare', 'glutelab-child-theme' ),
		'awaiting_payment' => __( 'Da pagare', 'glutelab-child-theme' ),
		'requested'        => __( 'Richiesta ricevuta', 'glutelab-child-theme' ),
		'confirmed'        => __( 'Confermata', 'glutelab-child-theme' ),
		'paid'             => __( 'Pagato', 'glutelab-child-theme' ),
		'completed'        => __( 'Completata', 'glutelab-child-theme' ),
		'cancelled'        => __( 'Annullata', 'glutelab-child-theme' ),
		'no_show'          => __( 'Assente', 'glutelab-child-theme' ),
		'failed'           => __( 'Non riuscito', 'glutelab-child-theme' ),
		'payment_failed'   => __( 'Pagamento non riuscito', 'glutelab-child-theme' ),
		'refunded'         => __( 'Rimborsato', 'glutelab-child-theme' ),
	);
	return $labels[ $status ] ?? ucfirst( str_replace( '_', ' ', (string) $status ) );
}

/** Convert stored payment keys to plain-language labels. */
function glutelab_app_admin_payment_method_label( $method ) {
	$labels = array(
		'inquiry'   => __( 'Nessun pagamento ora', 'glutelab-child-theme' ),
		'in_person' => __( 'Pagamento in sede', 'glutelab-child-theme' ),
		'stripe'    => __( 'Pagamento online', 'glutelab-child-theme' ),
	);
	return $labels[ $method ] ?? __( 'Non indicato', 'glutelab-child-theme' );
}

/** Keep the catalogue editor inside the main Glute Lab administration. */
function glutelab_app_admin_packages() {
	glutelab_packages_admin_content();
}

function glutelab_app_admin_empty( $text ) { echo '<div class="gl-app-empty"><p>' . esc_html( $text ) . '</p></div>'; }

/** Resolve a safe first-of-month value for the calendar. */
function glutelab_app_calendar_month( $value = '' ) {
	$timezone = glutelab_app_timezone();
	$value    = preg_match( '/^\d{4}-\d{2}$/', (string) $value ) ? $value . '-01' : 'now';
	try { return ( new DateTimeImmutable( $value, $timezone ) )->modify( 'first day of this month' )->setTime( 0, 0 ); }
	catch ( Throwable $error ) { return ( new DateTimeImmutable( 'now', $timezone ) )->modify( 'first day of this month' )->setTime( 0, 0 ); }
}

/** Group joined booking rows by their local calendar day. */
function glutelab_app_calendar_group_rows( array $rows ) {
	$grouped  = array();
	$timezone = glutelab_app_timezone();
	foreach ( $rows as $row ) {
		$date = sanitize_text_field( $row['preferred_date'] ?? '' );
		if ( ! empty( $row['start_at_utc'] ) ) {
			try { $date = ( new DateTimeImmutable( $row['start_at_utc'], new DateTimeZone( 'UTC' ) ) )->setTimezone( $timezone )->format( 'Y-m-d' ); }
			catch ( Throwable $error ) { $date = ''; }
		}
		if ( $date ) $grouped[ $date ][] = $row;
	}
	return $grouped;
}

function glutelab_app_admin_bookings() {
	$month   = glutelab_app_calendar_month( sanitize_text_field( wp_unslash( $_GET['month'] ?? '' ) ) );
	$rows    = glutelab_app_calendar_bookings( $month );
	$grouped = glutelab_app_calendar_group_rows( $rows );
	$prev    = add_query_arg( 'month', $month->modify( '-1 month' )->format( 'Y-m' ), glutelab_app_admin_url( 'bookings' ) );
	$next    = add_query_arg( 'month', $month->modify( '+1 month' )->format( 'Y-m' ), glutelab_app_admin_url( 'bookings' ) );
	$today   = add_query_arg( 'month', wp_date( 'Y-m' ), glutelab_app_admin_url( 'bookings' ) );
	glutelab_app_admin_view_header( __( 'Calendario', 'glutelab-child-theme' ), __( 'Vedi gli appuntamenti nel giorno e nell’orario scelti.', 'glutelab-child-theme' ), sprintf( _n( '%d impegno', '%d impegni', count( $rows ), 'glutelab-child-theme' ), count( $rows ) ) );
	$grid_start = $month->modify( '-' . ( (int) $month->format( 'N' ) - 1 ) . ' days' );
	$grid_end   = $month->modify( 'last day of this month' )->modify( '+' . ( 7 - (int) $month->modify( 'last day of this month' )->format( 'N' ) ) . ' days' );
	?>
	<section class="gl-app-calendar" aria-labelledby="gl-app-calendar-title">
		<header class="gl-app-calendar__toolbar"><div><p class="gl-app-admin__eyebrow"><?php esc_html_e( 'AGENDA MENSILE', 'glutelab-child-theme' ); ?></p><h3 id="gl-app-calendar-title"><?php echo esc_html( wp_date( 'F Y', $month->getTimestamp(), glutelab_app_timezone() ) ); ?></h3></div><nav aria-label="<?php esc_attr_e( 'Navigazione calendario', 'glutelab-child-theme' ); ?>"><a class="button" href="<?php echo esc_url( $prev ); ?>" aria-label="<?php esc_attr_e( 'Mese precedente', 'glutelab-child-theme' ); ?>">←</a><a class="button" href="<?php echo esc_url( $today ); ?>"><?php esc_html_e( 'Oggi', 'glutelab-child-theme' ); ?></a><a class="button" href="<?php echo esc_url( $next ); ?>" aria-label="<?php esc_attr_e( 'Mese successivo', 'glutelab-child-theme' ); ?>">→</a></nav></header>
		<div class="gl-app-calendar__weekdays" aria-hidden="true"><?php foreach ( array( 'Lun', 'Mar', 'Mer', 'Gio', 'Ven', 'Sab', 'Dom' ) as $day ) : ?><span><?php echo esc_html( $day ); ?></span><?php endforeach; ?></div>
		<div class="gl-app-calendar__grid">
		<?php for ( $date = $grid_start; $date <= $grid_end; $date = $date->modify( '+1 day' ) ) : $key = $date->format( 'Y-m-d' ); $events = $grouped[ $key ] ?? array(); $is_other = $date->format( 'm' ) !== $month->format( 'm' ); $is_today = $key === wp_date( 'Y-m-d' ); ?>
			<article class="gl-app-calendar__day<?php echo $is_other ? ' is-other-month' : ''; ?><?php echo $is_today ? ' is-today' : ''; ?>" aria-label="<?php echo esc_attr( wp_date( 'l j F Y', $date->getTimestamp(), glutelab_app_timezone() ) ); ?>">
				<header><span><?php echo esc_html( $date->format( 'j' ) ); ?></span><?php if ( $events ) : ?><small><?php echo esc_html( count( $events ) ); ?></small><?php endif; ?></header>
				<div class="gl-app-calendar__events"><?php foreach ( $events as $row ) : $package = glutelab_get_package( $row['package_id'] ); $terminal = in_array( $row['status'], array( 'completed', 'cancelled', 'no_show' ), true ); $waiting_payment = 'stripe' === ( $row['payment_method'] ?? '' ) && 'paid' !== ( $row['payment_status'] ?? '' ); $time = ! empty( $row['start_at_utc'] ) ? ( new DateTimeImmutable( $row['start_at_utc'], new DateTimeZone( 'UTC' ) ) )->setTimezone( glutelab_app_timezone() )->format( 'H:i' ) : __( 'Orario da concordare', 'glutelab-child-theme' ); ?>
					<details class="gl-app-calendar-event is-<?php echo esc_attr( sanitize_html_class( $row['status'] ) ); ?>"><summary><time><?php echo esc_html( $time ); ?></time><strong><?php echo esc_html( trim( $row['first_name'] . ' ' . $row['last_name'] ) ); ?></strong><span><?php echo esc_html( $package ? $package['title'] : $row['package_id'] ); ?></span></summary><div><span class="gl-app-status is-<?php echo esc_attr( sanitize_html_class( $row['status'] ) ); ?>"><?php echo esc_html( glutelab_app_admin_status_label( $row['status'] ) ); ?></span><?php if ( $waiting_payment ) : ?><span class="gl-app-status is-awaiting_payment"><?php esc_html_e( 'Pagamento da completare', 'glutelab-child-theme' ); ?></span><?php endif; ?><small><?php echo esc_html( $row['reference'] ); ?></small><?php if ( ! $terminal ) : ?><form class="gl-app-calendar-event__action" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" method="post"><input type="hidden" name="action" value="glutelab_app_booking_status"><input type="hidden" name="booking_id" value="<?php echo esc_attr( $row['id'] ); ?>"><?php wp_nonce_field( 'glutelab_app_booking_status' ); ?><label class="screen-reader-text" for="gl-booking-status-<?php echo esc_attr( $row['id'] ); ?>"><?php esc_html_e( 'Nuovo stato', 'glutelab-child-theme' ); ?></label><select id="gl-booking-status-<?php echo esc_attr( $row['id'] ); ?>" name="status"><?php if ( ! $waiting_payment ) : ?><option value="confirmed"><?php esc_html_e( 'Conferma', 'glutelab-child-theme' ); ?></option><option value="completed"><?php esc_html_e( 'Completata', 'glutelab-child-theme' ); ?></option><option value="no_show"><?php esc_html_e( 'Assente', 'glutelab-child-theme' ); ?></option><?php endif; ?><option value="cancelled"><?php esc_html_e( 'Annulla', 'glutelab-child-theme' ); ?></option></select><button class="button"><?php esc_html_e( 'Salva', 'glutelab-child-theme' ); ?></button></form><?php endif; ?></div></details>
				<?php endforeach; ?></div>
			</article>
		<?php endfor; ?>
		</div>
	</section><?php
}

function glutelab_app_admin_customers() {
	$rows = glutelab_app_admin_rows( 'customers' );
	glutelab_app_admin_view_header( __( 'Clienti', 'glutelab-child-theme' ), __( 'Consulta contatti, data di registrazione e richieste inviate.', 'glutelab-child-theme' ), sprintf( _n( '%d cliente', '%d clienti', count( $rows ), 'glutelab-child-theme' ), count( $rows ) ) );
	if ( ! $rows ) return glutelab_app_admin_empty( __( 'Non ci sono ancora clienti registrati.', 'glutelab-child-theme' ) );
	$requests_by_customer = glutelab_app_customer_requests_by_customer( array_column( $rows, 'id' ) );
	?><div class="gl-app-table-wrap"><table class="widefat gl-app-data-table gl-app-customer-table"><thead><tr><th><?php esc_html_e( 'Cliente', 'glutelab-child-theme' ); ?></th><th><?php esc_html_e( 'Contatti', 'glutelab-child-theme' ); ?></th><th><?php esc_html_e( 'Ultima richiesta', 'glutelab-child-theme' ); ?></th></tr></thead><tbody><?php foreach ( $rows as $row ) :
		$requests = $requests_by_customer[ (int) $row['id'] ] ?? array();
		$latest   = $requests ? glutelab_app_customer_request_view( array_shift( $requests ) ) : null;
		?><tr><td><div class="gl-app-customer-name"><strong><?php echo esc_html( trim( $row['first_name'] . ' ' . $row['last_name'] ) ); ?></strong><?php if ( glutelab_app_customer_is_new( $row['created_at'] ?? '' ) ) : ?><span><?php esc_html_e( 'Nuovo', 'glutelab-child-theme' ); ?></span><?php endif; ?></div><small><?php echo esc_html( sprintf( __( 'Registrato il %s', 'glutelab-child-theme' ), glutelab_app_admin_datetime( $row['created_at'] ?? '' ) ) ); ?></small></td><td><a href="mailto:<?php echo esc_attr( $row['email'] ); ?>"><?php echo esc_html( $row['email'] ); ?></a><br><?php echo esc_html( $row['phone'] ); ?></td><td class="gl-app-customer-choice-cell"><?php if ( $latest ) : glutelab_app_admin_customer_choice( $latest ); ?><?php if ( $requests ) : ?><details class="gl-app-customer-history"><summary><?php echo esc_html( sprintf( _n( 'Mostra 1 richiesta precedente', 'Mostra %d richieste precedenti', count( $requests ), 'glutelab-child-theme' ), count( $requests ) ) ); ?></summary><div class="gl-app-customer-history__list"><?php foreach ( $requests as $request ) glutelab_app_admin_customer_choice( glutelab_app_customer_request_view( $request ), true ); ?></div></details><?php endif; ?><?php else : ?><span class="gl-app-muted"><?php esc_html_e( 'Nessuna richiesta inviata', 'glutelab-child-theme' ); ?></span><?php endif; ?></td></tr><?php endforeach; ?></tbody></table></div><?php
}

/** Format UTC storage values using the site timezone. */
function glutelab_app_admin_datetime( $value ) {
	if ( ! $value ) return '—';
	try { return wp_date( 'd.m.Y · H:i', ( new DateTimeImmutable( $value, new DateTimeZone( 'UTC' ) ) )->getTimestamp(), glutelab_app_timezone() ); }
	catch ( Throwable $error ) { return '—'; }
}

/** Customers registered in the last seven days receive a concise visual marker. */
function glutelab_app_customer_is_new( $created_at, $now = null ) {
	if ( ! $created_at ) return false;
	try {
		$created = new DateTimeImmutable( $created_at, new DateTimeZone( 'UTC' ) );
		$current = $now ? new DateTimeImmutable( $now, new DateTimeZone( 'UTC' ) ) : new DateTimeImmutable( 'now', new DateTimeZone( 'UTC' ) );
		return $created <= $current && $created >= $current->modify( '-7 days' );
	} catch ( Throwable $error ) { return false; }
}

/** Convert stored request data to the labels used in the customer table. */
function glutelab_app_customer_request_view( array $request ) {
	$package  = glutelab_get_package( $request['package_id'] ?? '' );
	$interval = glutelab_app_booking_interval_label( $request['start_at_utc'] ?? '', $request['end_at_utc'] ?? '' );
	$day      = glutelab_app_preferred_date_label( $request['preferred_date'] ?? '' );
	$methods  = array(
		'inquiry'   => __( 'Richiesta storica', 'glutelab-child-theme' ),
		'in_person' => __( 'Pagamento storico in sede', 'glutelab-child-theme' ),
		'stripe'    => __( 'Pagamento online', 'glutelab-child-theme' ),
	);
	return array(
		'package'  => $package ? $package['title'] : __( 'Offerta non più disponibile', 'glutelab-child-theme' ),
		'schedule' => $interval ?: ( $day ? sprintf( __( '%s · Orario da concordare', 'glutelab-child-theme' ), $day ) : __( 'Giorno e orario non indicati', 'glutelab-child-theme' ) ),
		'payment'  => $methods[ $request['payment_method'] ?? '' ] ?? __( 'Metodo non disponibile', 'glutelab-child-theme' ),
		'created'  => glutelab_app_admin_datetime( $request['created_at'] ?? '' ),
	);
}

/** Render one concise request summary inside the customer table. */
function glutelab_app_admin_customer_choice( array $choice, $compact = false ) {
	?>
	<div class="gl-app-customer-choice<?php echo $compact ? ' is-compact' : ''; ?>">
		<span class="gl-app-customer-choice__label"><?php esc_html_e( 'Pacchetto scelto', 'glutelab-child-theme' ); ?></span>
		<strong><?php echo esc_html( $choice['package'] ); ?></strong>
		<small><?php echo esc_html( sprintf( __( 'Richiesta del %s', 'glutelab-child-theme' ), $choice['created'] ) ); ?></small>
		<dl>
			<div><dt><?php esc_html_e( 'Giorno e orario', 'glutelab-child-theme' ); ?></dt><dd><?php echo esc_html( $choice['schedule'] ); ?></dd></div>
			<div><dt><?php esc_html_e( 'Metodo di pagamento', 'glutelab-child-theme' ); ?></dt><dd><?php echo esc_html( $choice['payment'] ); ?></dd></div>
		</dl>
	</div>
	<?php
}

function glutelab_app_admin_payments() {
	$rows = glutelab_app_payment_rows();
	glutelab_app_admin_view_header( __( 'Pagamenti', 'glutelab-child-theme' ), __( 'Controlla chi ha pagato, cosa ha acquistato e gli importi ancora da saldare online.', 'glutelab-child-theme' ), sprintf( _n( '%d pagamento', '%d pagamenti', count( $rows ), 'glutelab-child-theme' ), count( $rows ) ) );
	if ( ! $rows ) return glutelab_app_admin_empty( __( 'Non ci sono ancora richieste o pagamenti.', 'glutelab-child-theme' ) );
	?><div class="gl-app-table-wrap"><table class="widefat gl-app-data-table gl-app-payment-table"><thead><tr><th><?php esc_html_e( 'Nome pagatore', 'glutelab-child-theme' ); ?></th><th><?php esc_html_e( 'Cosa ha acquistato', 'glutelab-child-theme' ); ?></th><th><?php esc_html_e( 'Importo', 'glutelab-child-theme' ); ?></th><th><?php esc_html_e( 'Stato', 'glutelab-child-theme' ); ?></th><th><?php esc_html_e( 'Data', 'glutelab-child-theme' ); ?></th><th><?php esc_html_e( 'Azioni', 'glutelab-child-theme' ); ?></th></tr></thead><tbody><?php foreach ( $rows as $row ) : $package = glutelab_get_package( $row['package_id'] ); $unpaid = in_array( $row['status'], array( 'pending', 'awaiting_payment', 'payment_failed' ), true ); ?><tr><td><strong><?php echo esc_html( trim( $row['first_name'] . ' ' . $row['last_name'] ) ); ?></strong><br><a href="mailto:<?php echo esc_attr( $row['email'] ); ?>"><?php echo esc_html( $row['email'] ); ?></a></td><td><strong><?php echo esc_html( $package ? $package['title'] : $row['package_id'] ); ?></strong><br><small><?php echo esc_html( $row['reference'] ); ?></small></td><td><strong><?php echo esc_html( glutelab_format_chf( $row['amount_cents'] / 100 ) ); ?></strong><br><small><?php esc_html_e( 'Online', 'glutelab-child-theme' ); ?></small></td><td><span class="gl-app-status is-<?php echo esc_attr( sanitize_html_class( $row['status'] ) ); ?>"><?php echo esc_html( glutelab_app_admin_status_label( $row['status'] ) ); ?></span><?php if ( ! empty( $row['payment_reminder_sent_at'] ) ) : ?><br><small><?php echo esc_html( sprintf( __( 'Ultimo promemoria: %s', 'glutelab-child-theme' ), glutelab_app_admin_datetime( $row['payment_reminder_sent_at'] ) ) ); ?></small><?php endif; ?></td><td><?php echo esc_html( glutelab_app_admin_datetime( $row['created_at'] ) ); ?><?php if ( ! empty( $row['paid_at'] ) ) : ?><br><small><?php echo esc_html( sprintf( __( 'Pagato il %s', 'glutelab-child-theme' ), glutelab_app_admin_datetime( $row['paid_at'] ) ) ); ?></small><?php endif; ?></td><td><?php if ( $unpaid ) : ?><form action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" method="post"><input type="hidden" name="action" value="glutelab_app_payment_reminder"><input type="hidden" name="order_id" value="<?php echo esc_attr( $row['id'] ); ?>"><?php wp_nonce_field( 'glutelab_app_payment_reminder' ); ?><button class="button button-primary"><?php esc_html_e( 'Invia promemoria', 'glutelab-child-theme' ); ?></button></form><?php else : ?><span class="gl-app-muted"><?php esc_html_e( 'Nessuna azione', 'glutelab-child-theme' ); ?></span><?php endif; ?></td></tr><?php endforeach; ?></tbody></table></div><?php
}

function glutelab_app_admin_time_range( $pattern, $day, $index, $interval, $day_label ) {
	$open  = $interval['open'] ?? '';
	$close = $interval['close'] ?? '';
	?>
	<div class="gl-app-time-range" data-gl-time-range data-gl-range-index="<?php echo esc_attr( $index ); ?>">
		<label><span><?php esc_html_e( 'Da', 'glutelab-child-theme' ); ?></span><input type="time" aria-label="<?php echo esc_attr( sprintf( __( '%s: dalle', 'glutelab-child-theme' ), $day_label ) ); ?>" name="settings[weekly_patterns][<?php echo esc_attr( $pattern ); ?>][<?php echo esc_attr( $day ); ?>][ranges][<?php echo esc_attr( $index ); ?>][open]" value="<?php echo esc_attr( $open ); ?>"></label>
		<label><span><?php esc_html_e( 'A', 'glutelab-child-theme' ); ?></span><input type="time" aria-label="<?php echo esc_attr( sprintf( __( '%s: alle', 'glutelab-child-theme' ), $day_label ) ); ?>" name="settings[weekly_patterns][<?php echo esc_attr( $pattern ); ?>][<?php echo esc_attr( $day ); ?>][ranges][<?php echo esc_attr( $index ); ?>][close]" value="<?php echo esc_attr( $close ); ?>"></label>
		<button type="button" class="button-link-delete gl-app-time-range__remove" data-gl-remove-range aria-label="<?php echo esc_attr( sprintf( __( 'Rimuovi questo orario di %s', 'glutelab-child-theme' ), $day_label ) ); ?>">&times;</button>
	</div>
	<?php
}

function glutelab_app_admin_week_pattern( $pattern, $label, $description, $settings, $days, $context = array() ) {
	$status       = in_array( $context['status'] ?? '', array( 'current', 'next' ), true ) ? $context['status'] : '';
	$status_label = (string) ( $context['status_label'] ?? '' );
	?>
	<fieldset class="gl-app-week-pattern<?php echo $status ? ' is-' . esc_attr( $status ) : ''; ?>" data-gl-schedule-week="<?php echo esc_attr( $pattern ); ?>"<?php echo $status ? ' data-gl-week-status="' . esc_attr( $status ) . '"' : ''; ?>>
		<legend>
			<span class="gl-app-week-pattern__title"><span><?php echo esc_html( $label ); ?></span><?php if ( $status_label ) : ?><em class="gl-app-week-pattern__status"><?php echo esc_html( $status_label ); ?></em><?php endif; ?></span>
			<small><?php echo esc_html( $description ); ?></small>
		</legend>
		<div class="gl-app-schedule">
			<div class="gl-app-schedule__heading" aria-hidden="true">
				<span><?php esc_html_e( 'Giorno', 'glutelab-child-theme' ); ?></span>
				<span><?php esc_html_e( 'Aperto', 'glutelab-child-theme' ); ?></span>
				<span><?php esc_html_e( 'Orari disponibili', 'glutelab-child-theme' ); ?></span>
			</div>
			<?php foreach ( $days as $key => $day_label ) :
				$intervals = array_values( $settings['weekly_patterns'][ $pattern ][ $key ] ?? array() );
				$is_open   = ! empty( $intervals );
				?>
				<div class="gl-app-schedule__day <?php echo $is_open ? 'is-open' : 'is-closed'; ?>" data-gl-schedule-day="<?php echo esc_attr( $key ); ?>">
					<strong class="gl-app-schedule__day-name"><?php echo esc_html( $day_label ); ?></strong>
					<label class="gl-app-schedule__open"><input type="checkbox" name="settings[weekly_patterns][<?php echo esc_attr( $pattern ); ?>][<?php echo esc_attr( $key ); ?>][enabled]" value="1" data-gl-day-open <?php checked( $is_open ); ?>><span data-gl-open-label><?php echo $is_open ? esc_html__( 'Aperto', 'glutelab-child-theme' ) : esc_html__( 'Chiuso', 'glutelab-child-theme' ); ?></span></label>
					<div class="gl-app-schedule__times">
						<div class="gl-app-time-ranges" data-gl-time-ranges><?php foreach ( $intervals as $index => $interval ) glutelab_app_admin_time_range( $pattern, $key, $index, $interval, $day_label ); ?></div>
						<button type="button" class="button gl-app-add-range" data-gl-add-range><?php esc_html_e( '+ Aggiungi orario', 'glutelab-child-theme' ); ?></button>
					</div>
				</div>
			<?php endforeach; ?>
		</div>
	</fieldset>
	<?php
}

/** Render the environment switch and the two independent Stripe credential sets. */
function glutelab_app_admin_stripe_settings( $settings ) {
	$active_mode = glutelab_app_stripe_mode( $settings );
	$modes = array(
		'test' => array(
			'label'       => __( 'Test', 'glutelab-child-theme' ),
			'description' => __( 'Pagamenti di prova, senza addebiti reali', 'glutelab-child-theme' ),
			'public_hint' => 'pk_test_…',
			'secret_hint' => 'sk_test_…',
		),
		'live' => array(
			'label'       => __( 'Live', 'glutelab-child-theme' ),
			'description' => __( 'Pagamenti reali sul conto Stripe', 'glutelab-child-theme' ),
			'public_hint' => 'pk_live_…',
			'secret_hint' => 'sk_live_…',
		),
	);
	?>
	<details class="gl-app-panel gl-app-advanced gl-app-stripe" data-gl-stripe-settings open>
		<summary><span><strong><?php esc_html_e( 'Pagamento online con Stripe', 'glutelab-child-theme' ); ?></strong><small><?php esc_html_e( 'Chiavi e modalità Test o Live', 'glutelab-child-theme' ); ?></small></span><span class="gl-app-stripe__current" data-gl-stripe-current data-gl-stripe-current-template="<?php echo esc_attr( __( 'Modalità %s attiva', 'glutelab-child-theme' ) ); ?>"><?php echo esc_html( sprintf( __( 'Modalità %s attiva', 'glutelab-child-theme' ), $modes[ $active_mode ]['label'] ) ); ?></span></summary>
		<div class="gl-app-advanced__body">
			<p class="description"><?php esc_html_e( 'Conserva separatamente le chiavi di prova e quelle ufficiali. La modalità scelta stabilisce quale ambiente usa il sito.', 'glutelab-child-theme' ); ?></p>

		<fieldset class="gl-app-stripe-mode">
			<legend><?php esc_html_e( 'Modalità Stripe', 'glutelab-child-theme' ); ?></legend>
			<div class="gl-app-stripe-mode__options">
				<?php foreach ( $modes as $mode => $copy ) : ?>
					<label>
						<input type="radio" name="settings[stripe_mode]" value="<?php echo esc_attr( $mode ); ?>" data-gl-stripe-mode data-gl-stripe-label="<?php echo esc_attr( $copy['label'] ); ?>" aria-controls="gl-stripe-panel-<?php echo esc_attr( $mode ); ?>" <?php checked( $active_mode, $mode ); ?>>
						<span><strong><?php echo esc_html( $copy['label'] ); ?></strong><small><?php echo esc_html( $copy['description'] ); ?></small></span>
					</label>
				<?php endforeach; ?>
			</div>
		</fieldset>

		<div class="gl-app-stripe-panels">
			<?php foreach ( $modes as $mode => $copy ) :
				$public_key = glutelab_app_get_stripe_credential( 'publishable_key', $mode );
				$secret_saved = '' !== glutelab_app_get_stripe_credential( 'secret_key', $mode );
				$webhook_saved = '' !== glutelab_app_get_stripe_credential( 'webhook_secret', $mode );
				$complete = glutelab_app_stripe_is_configured( $mode );
				?>
				<section id="gl-stripe-panel-<?php echo esc_attr( $mode ); ?>" class="gl-app-stripe-panel<?php echo $active_mode === $mode ? ' is-active' : ''; ?>" data-gl-stripe-panel="<?php echo esc_attr( $mode ); ?>" aria-labelledby="gl-stripe-title-<?php echo esc_attr( $mode ); ?>">
					<header>
						<div><h3 id="gl-stripe-title-<?php echo esc_attr( $mode ); ?>"><?php echo esc_html( sprintf( __( 'Credenziali %s', 'glutelab-child-theme' ), $copy['label'] ) ); ?></h3><p><?php echo esc_html( $copy['description'] ); ?></p></div>
						<span class="gl-app-stripe-panel__status<?php echo $complete ? ' is-ready' : ''; ?>"><?php echo $complete ? esc_html__( 'Completo', 'glutelab-child-theme' ) : esc_html__( 'Da completare', 'glutelab-child-theme' ); ?></span>
					</header>
					<?php if ( 'live' === $mode ) : ?><p class="gl-app-stripe-panel__warning"><strong><?php esc_html_e( 'Attenzione:', 'glutelab-child-theme' ); ?></strong> <?php esc_html_e( 'usa questa modalità soltanto quando le credenziali ufficiali e il webhook Live sono stati verificati.', 'glutelab-child-theme' ); ?></p><?php endif; ?>
					<div class="gl-app-stripe-fields">
						<label><span><?php esc_html_e( 'Chiave pubblica', 'glutelab-child-theme' ); ?></span><input type="text" name="stripe_credentials[<?php echo esc_attr( $mode ); ?>][publishable_key]" value="<?php echo esc_attr( $public_key ); ?>" placeholder="<?php echo esc_attr( $copy['public_hint'] ); ?>" autocomplete="off" autocapitalize="off" spellcheck="false"><small><?php esc_html_e( 'Può essere mostrata nel browser e resta visibile qui.', 'glutelab-child-theme' ); ?></small></label>
						<label><span><?php esc_html_e( 'Chiave segreta', 'glutelab-child-theme' ); ?> <em><?php echo $secret_saved ? esc_html__( 'Salvata', 'glutelab-child-theme' ) : esc_html__( 'Mancante', 'glutelab-child-theme' ); ?></em></span><input type="password" name="stripe_credentials[<?php echo esc_attr( $mode ); ?>][secret_key]" autocomplete="new-password" autocapitalize="off" spellcheck="false" placeholder="<?php echo esc_attr( $secret_saved ? __( 'Lascia vuoto per conservarla', 'glutelab-child-theme' ) : $copy['secret_hint'] ); ?>"><small><?php esc_html_e( 'Non viene mai mostrata dopo il salvataggio.', 'glutelab-child-theme' ); ?></small></label>
						<label><span><?php esc_html_e( 'Segreto webhook', 'glutelab-child-theme' ); ?> <em><?php echo $webhook_saved ? esc_html__( 'Salvato', 'glutelab-child-theme' ) : esc_html__( 'Mancante', 'glutelab-child-theme' ); ?></em></span><input type="password" name="stripe_credentials[<?php echo esc_attr( $mode ); ?>][webhook_secret]" autocomplete="new-password" autocapitalize="off" spellcheck="false" placeholder="<?php echo esc_attr( $webhook_saved ? __( 'Lascia vuoto per conservarlo', 'glutelab-child-theme' ) : 'whsec_…' ); ?>"><small><?php esc_html_e( 'Copia il Signing secret del webhook del relativo ambiente.', 'glutelab-child-theme' ); ?></small></label>
					</div>
				</section>
			<?php endforeach; ?>
		</div>

			<label class="gl-app-field gl-app-stripe-webhook"><span><?php esc_html_e( 'URL webhook da inserire in Stripe', 'glutelab-child-theme' ); ?></span><input readonly value="<?php echo esc_attr( rest_url( 'glutelab/v1/stripe/webhook' ) ); ?>" data-gl-stripe-webhook-url><small><?php esc_html_e( 'Usa lo stesso URL negli endpoint Test e Live di Stripe; ciascuno avrà il proprio segreto.', 'glutelab-child-theme' ); ?></small></label>
		</div>
	</details>
	<?php
}

function glutelab_app_admin_availability() {
	$s = glutelab_app_get_settings();
	$days = array( 'monday' => __( 'Lunedì', 'glutelab-child-theme' ), 'tuesday' => __( 'Martedì', 'glutelab-child-theme' ), 'wednesday' => __( 'Mercoledì', 'glutelab-child-theme' ), 'thursday' => __( 'Giovedì', 'glutelab-child-theme' ), 'friday' => __( 'Venerdì', 'glutelab-child-theme' ), 'saturday' => __( 'Sabato', 'glutelab-child-theme' ), 'sunday' => __( 'Domenica', 'glutelab-child-theme' ) );
	$timezone = glutelab_app_timezone();
	$week_contexts = glutelab_app_week_contexts( new DateTimeImmutable( 'now', $timezone ) );
	glutelab_app_admin_view_header( __( 'Orari', 'glutelab-child-theme' ), __( 'Definisci giorni e fasce disponibili; il calendario prepara automaticamente gli orari selezionabili.', 'glutelab-child-theme' ) );
	?><form class="gl-app-settings" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" method="post"><input type="hidden" name="action" value="glutelab_app_save_settings"><input type="hidden" name="settings_scope" value="availability"><?php wp_nonce_field( 'glutelab_app_save_settings' ); ?>
	<section class="gl-app-panel gl-app-availability" aria-describedby="gl-app-availability-help">
			<div class="gl-app-section-heading"><div><h2><?php esc_html_e( 'Quando sei disponibile', 'glutelab-child-theme' ); ?></h2><p id="gl-app-availability-help" class="description"><?php esc_html_e( 'Imposta due settimane tipo. Il calendario le alterna automaticamente.', 'glutelab-child-theme' ); ?></p></div></div>
		<div class="gl-app-availability-note"><div><strong><?php esc_html_e( 'Le fasce indicano quando sei disponibile.', 'glutelab-child-theme' ); ?></strong><span><?php esc_html_e( 'Per trasformarle in orari selezionabili serve anche la durata della singola lezione in ogni offerta.', 'glutelab-child-theme' ); ?></span></div><a class="button" href="<?php echo esc_url( glutelab_app_admin_url( 'durations' ) ); ?>"><?php esc_html_e( 'Configura le durate', 'glutelab-child-theme' ); ?></a></div>
		<div class="gl-app-week-patterns">
			<?php foreach ( $week_contexts as $context ) :
				$range = sprintf(
					__( 'Dal %1$s al %2$s', 'glutelab-child-theme' ),
					wp_date( 'j F', $context['start']->getTimestamp(), $timezone ),
					wp_date( 'j F Y', $context['end']->getTimestamp(), $timezone )
				);
				glutelab_app_admin_week_pattern(
					$context['pattern'],
					sprintf( __( 'Settimana %s', 'glutelab-child-theme' ), strtoupper( $context['pattern'] ) ),
					$range,
					$s,
					$days,
					array(
						'status'       => $context['status'],
						'status_label' => 'current' === $context['status'] ? __( 'In corso', 'glutelab-child-theme' ) : __( 'Prossima', 'glutelab-child-theme' ),
					)
				);
			endforeach; ?>
		</div>
			<p class="description gl-app-schedule-help"><?php esc_html_e( 'Segna i giorni aperti e aggiungi gli orari. Puoi inserire più fasce nello stesso giorno per lasciare una pausa.', 'glutelab-child-theme' ); ?></p>
		<?php glutelab_app_admin_closure_dates( $s['closure_dates'] ); ?>
	</section>
	<p class="submit"><button class="button button-primary button-hero"><?php esc_html_e( 'Salva orari', 'glutelab-child-theme' ); ?></button></p></form><?php
}

/** Payment and booking rules live in one focused settings tab. */
function glutelab_app_admin_settings() {
	$s = glutelab_app_get_settings();
	glutelab_app_admin_view_header( __( 'Impostazioni', 'glutelab-child-theme' ), __( 'Attiva il servizio, configura Stripe e scegli le regole di prenotazione.', 'glutelab-child-theme' ) );
	?>
	<form class="gl-app-settings gl-app-settings--general" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" method="post">
		<input type="hidden" name="action" value="glutelab_app_save_settings"><input type="hidden" name="settings_scope" value="general"><?php wp_nonce_field( 'glutelab_app_save_settings' ); ?>
		<section class="gl-app-panel gl-app-settings-card"><div class="gl-app-section-heading"><div><p class="gl-app-admin__eyebrow"><?php esc_html_e( 'ATTIVAZIONE', 'glutelab-child-theme' ); ?></p><h2><?php esc_html_e( 'Funzioni disponibili sul sito', 'glutelab-child-theme' ); ?></h2><p class="description"><?php esc_html_e( 'Attiva soltanto ciò che è pronto per i clienti.', 'glutelab-child-theme' ); ?></p></div></div><div class="gl-app-toggles"><label><input type="checkbox" name="settings[enabled]" value="1" <?php checked( $s['enabled'] ); ?>><span><strong><?php esc_html_e( 'Modulo richieste', 'glutelab-child-theme' ); ?></strong><small><?php esc_html_e( 'Mostra il formulario pubblico.', 'glutelab-child-theme' ); ?></small></span></label><label><input type="checkbox" name="settings[booking_enabled]" value="1" <?php checked( $s['booking_enabled'] ); ?>><span><strong><?php esc_html_e( 'Scelta giorno e orario', 'glutelab-child-theme' ); ?></strong><small><?php esc_html_e( 'Usa le disponibilità della tab Orari.', 'glutelab-child-theme' ); ?></small></span></label><label><input type="checkbox" name="settings[stripe_enabled]" value="1" <?php checked( $s['stripe_enabled'] ); ?>><span><strong><?php esc_html_e( 'Pagamenti online', 'glutelab-child-theme' ); ?></strong><small><?php esc_html_e( 'Abilita Stripe come unico metodo.', 'glutelab-child-theme' ); ?></small></span></label></div></section>
		<section class="gl-app-panel gl-app-settings-card"><div class="gl-app-section-heading"><div><p class="gl-app-admin__eyebrow"><?php esc_html_e( 'PRENOTAZIONI', 'glutelab-child-theme' ); ?></p><h2><?php esc_html_e( 'Regole semplici', 'glutelab-child-theme' ); ?></h2><p class="description"><?php esc_html_e( 'Definisci quanto prima si può prenotare e fino a quando mostrare gli orari.', 'glutelab-child-theme' ); ?></p></div></div><div class="gl-app-fields"><label><span><?php esc_html_e( 'Preavviso minimo (ore)', 'glutelab-child-theme' ); ?></span><input type="number" min="0" max="168" name="settings[min_notice_hours]" value="<?php echo esc_attr( $s['min_notice_hours'] ); ?>"><small><?php esc_html_e( 'Esempio: 24 impedisce prenotazioni nelle prossime 24 ore.', 'glutelab-child-theme' ); ?></small></label><label><span><?php esc_html_e( 'Periodo visibile (giorni)', 'glutelab-child-theme' ); ?></span><input type="number" min="1" max="365" name="settings[booking_horizon_days]" value="<?php echo esc_attr( $s['booking_horizon_days'] ); ?>"><small><?php esc_html_e( 'Quanti giorni futuri può consultare il cliente.', 'glutelab-child-theme' ); ?></small></label><label><span><?php esc_html_e( 'Promemoria lezione (ore prima)', 'glutelab-child-theme' ); ?></span><input type="number" min="0" max="168" name="settings[reminder_hours]" value="<?php echo esc_attr( $s['reminder_hours'] ); ?>"><small><?php esc_html_e( 'Usa 0 per non inviare il promemoria automatico.', 'glutelab-child-theme' ); ?></small></label></div></section>
		<?php glutelab_app_admin_stripe_settings( $s ); ?>
		<p class="submit"><button class="button button-primary button-hero"><?php esc_html_e( 'Salva impostazioni', 'glutelab-child-theme' ); ?></button></p>
	</form><?php
}

/** Render the extraordinary closure dates as native calendar controls. */
function glutelab_app_admin_closure_dates( $dates ) {
	$dates = is_array( $dates ) ? array_values( array_filter( $dates ) ) : array();
	?>
	<div
		class="gl-app-closure-dates"
		data-gl-closure-dates
		data-gl-remove-label="<?php esc_attr_e( 'Rimuovi', 'glutelab-child-theme' ); ?>"
		data-gl-input-label="<?php esc_attr_e( 'Giorno chiuso', 'glutelab-child-theme' ); ?>"
		data-gl-empty-message="<?php esc_attr_e( 'Non hai ancora aggiunto giorni di chiusura.', 'glutelab-child-theme' ); ?>"
		data-gl-invalid-message="<?php esc_attr_e( 'Scegli prima una data dal calendario.', 'glutelab-child-theme' ); ?>"
		data-gl-duplicate-message="<?php esc_attr_e( 'Questa data è già presente.', 'glutelab-child-theme' ); ?>"
		data-gl-added-message="<?php esc_attr_e( 'Giorno di chiusura aggiunto.', 'glutelab-child-theme' ); ?>"
		data-gl-removed-message="<?php esc_attr_e( 'Giorno di chiusura rimosso.', 'glutelab-child-theme' ); ?>"
	>
		<div class="gl-app-closure-dates__heading">
			<div>
				<h3><?php esc_html_e( 'Giorni chiusi straordinari', 'glutelab-child-theme' ); ?></h3>
				<p class="description"><?php esc_html_e( 'Seleziona la data dal calendario e aggiungila all’elenco.', 'glutelab-child-theme' ); ?></p>
			</div>
			<div class="gl-app-closure-dates__picker">
				<label for="gl-app-closure-date-picker"><?php esc_html_e( 'Nuovo giorno chiuso', 'glutelab-child-theme' ); ?></label>
				<div>
					<input id="gl-app-closure-date-picker" type="date" name="settings[closure_dates][]" data-gl-closure-date-picker>
					<button type="button" class="button" data-gl-add-closure-date><?php esc_html_e( 'Aggiungi data', 'glutelab-child-theme' ); ?></button>
				</div>
			</div>
		</div>
		<ul class="gl-app-closure-dates__list" data-gl-closure-date-list>
			<?php foreach ( $dates as $date ) : ?>
				<li class="gl-app-closure-dates__item" data-gl-closure-date-item>
					<label>
						<span class="screen-reader-text"><?php esc_html_e( 'Giorno chiuso', 'glutelab-child-theme' ); ?></span>
						<input type="date" name="settings[closure_dates][]" value="<?php echo esc_attr( $date ); ?>" data-gl-closure-date-input>
					</label>
					<button type="button" class="button-link-delete" data-gl-remove-closure-date><?php esc_html_e( 'Rimuovi', 'glutelab-child-theme' ); ?></button>
				</li>
			<?php endforeach; ?>
		</ul>
		<p class="gl-app-closure-dates__empty" data-gl-closure-date-empty<?php echo $dates ? ' hidden' : ''; ?>><?php esc_html_e( 'Non hai ancora aggiunto giorni di chiusura.', 'glutelab-child-theme' ); ?></p>
		<p class="gl-app-closure-dates__status" data-gl-closure-date-status role="status" aria-live="polite"></p>
	</div>
	<?php
}

/** Focused editor for the duration used by public scheduling. */
function glutelab_app_admin_durations() {
	$groups       = glutelab_get_package_groups( true );
	$packages     = glutelab_get_packages( array( 'include_inactive' => true ) );
	$visible_rows = 0;
	?>
	<form class="gl-app-durations" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" method="post">
		<input type="hidden" name="action" value="glutelab_app_save_durations">
		<?php wp_nonce_field( 'glutelab_app_save_durations' ); ?>
		<section class="gl-app-panel gl-app-duration-panel" aria-labelledby="gl-app-duration-title">
			<header class="gl-app-duration-toolbar">
				<div>
					<p class="gl-app-admin__eyebrow"><?php esc_html_e( 'Configurazione rapida', 'glutelab-child-theme' ); ?></p>
					<h2 id="gl-app-duration-title"><?php esc_html_e( 'Durata delle lezioni', 'glutelab-child-theme' ); ?></h2>
					<p class="description"><?php esc_html_e( 'La durata stabilisce ogni quanto compare un nuovo orario selezionabile. Le modifiche sono sincronizzate con la scheda completa di ogni offerta.', 'glutelab-child-theme' ); ?></p>
				</div>
				<a class="button" href="<?php echo esc_url( glutelab_app_admin_url( 'availability' ) ); ?>"><?php esc_html_e( 'Torna alle disponibilità', 'glutelab-child-theme' ); ?></a>
			</header>
			<div class="gl-app-duration-list">
				<?php foreach ( $groups as $group ) : ?>
					<?php foreach ( $packages as $package ) : ?>
						<?php if ( $group['id'] !== $package['group_id'] ) continue; ?>
						<?php if ( 'digital' === $package['mode'] ) continue; $visible_rows++; ?>
						<?php
						$total_lessons = glutelab_calculate_total_lessons( $package['lessons_purchased'], $package['bonus_lessons'] );
						$lesson_label  = null === $total_lessons ? __( 'Lezioni da definire', 'glutelab-child-theme' ) : sprintf( _n( '%d lezione', '%d lezioni', $total_lessons, 'glutelab-child-theme' ), $total_lessons );
						$input_id      = 'gl-duration-' . sanitize_html_class( $package['id'] );
						$help_id       = $input_id . '-help';
						?>
						<div class="gl-app-duration-row">
							<div class="gl-app-duration-row__main">
								<span class="gl-app-duration-row__course"><?php echo esc_html( $group['title'] ); ?></span>
								<h3><?php echo esc_html( $package['title'] ); ?></h3>
								<div class="gl-app-duration-row__facts">
									<span><?php echo esc_html( glutelab_package_price_text( $package ) ); ?></span>
									<span><?php echo esc_html( $lesson_label ); ?></span>
									<span class="gl-app-duration-status <?php echo 'active' === $package['status'] ? 'is-active' : ''; ?>"><?php echo 'active' === $package['status'] ? esc_html__( 'Attiva', 'glutelab-child-theme' ) : esc_html__( 'Non attiva', 'glutelab-child-theme' ); ?></span>
								</div>
							</div>
							<label class="gl-app-duration-field" for="<?php echo esc_attr( $input_id ); ?>">
								<span><?php esc_html_e( 'Durata della lezione', 'glutelab-child-theme' ); ?></span>
								<span class="gl-app-duration-field__control"><input id="<?php echo esc_attr( $input_id ); ?>" type="number" name="durations[<?php echo esc_attr( $package['id'] ); ?>]" min="5" max="240" step="5" inputmode="numeric" value="<?php echo esc_attr( $package['session_minutes'] ?? '' ); ?>" placeholder="<?php esc_attr_e( 'es. 60', 'glutelab-child-theme' ); ?>" aria-describedby="<?php echo esc_attr( $help_id ); ?>"><span><?php esc_html_e( 'minuti', 'glutelab-child-theme' ); ?></span></span>
								<small id="<?php echo esc_attr( $help_id ); ?>"><?php echo ! empty( $package['session_minutes'] ) ? esc_html( glutelab_app_duration_label( $package['session_minutes'] ) ) : esc_html__( 'Da configurare', 'glutelab-child-theme' ); ?></small>
							</label>
						</div>
					<?php endforeach; ?>
				<?php endforeach; ?>
				<?php if ( ! $visible_rows ) : ?><p class="gl-app-muted"><?php esc_html_e( 'Non ci sono offerte con lezioni da configurare.', 'glutelab-child-theme' ); ?></p><?php endif; ?>
			</div>
			<footer class="gl-app-duration-actions">
				<p><?php esc_html_e( 'Lascia vuoto solo se non vuoi rendere selezionabili gli orari di quell’offerta.', 'glutelab-child-theme' ); ?></p>
				<button class="button button-primary button-hero"<?php disabled( 0 === $visible_rows ); ?>><?php esc_html_e( 'Salva tutte le durate', 'glutelab-child-theme' ); ?></button>
			</footer>
		</section>
	</form>
	<?php
}

