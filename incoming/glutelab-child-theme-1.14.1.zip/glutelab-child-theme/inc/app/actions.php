<?php
/** Form and administration actions. @package GluteLabChildTheme */
if ( ! defined( 'ABSPATH' ) ) exit;

function glutelab_app_redirect_result( $result, $reference = '', $package_id = '' ) {
	$url = add_query_arg( array_filter( array( 'gl_result' => sanitize_key( $result ), 'reference' => sanitize_text_field( $reference ), 'package' => sanitize_key( $package_id ) ) ), glutelab_page_url( 'acquista-o-prenota' ) );
	wp_safe_redirect( $url . '#gl-booking-result' ); exit;
}

function glutelab_app_handle_request() {
	if ( 'POST' !== strtoupper( $_SERVER['REQUEST_METHOD'] ?? '' ) ) glutelab_app_redirect_result( 'invalid' );
	check_admin_referer( 'glutelab_app_request', 'glutelab_nonce' );
	if ( ! empty( $_POST['website'] ) || empty( $_POST['privacy'] ) ) glutelab_app_redirect_result( 'invalid' );
	$email = sanitize_email( wp_unslash( $_POST['email'] ?? '' ) ); $rate_key = 'gl_req_' . md5( strtolower( $email ) . '|' . ( $_SERVER['REMOTE_ADDR'] ?? '' ) );
	if ( get_transient( $rate_key ) ) glutelab_app_redirect_result( 'too-fast' );
	set_transient( $rate_key, 1, MINUTE_IN_SECONDS );
	$settings = glutelab_app_get_settings(); if ( empty( $settings['enabled'] ) ) glutelab_app_redirect_result( 'disabled' );
	$package_id = sanitize_key( wp_unslash( $_POST['package_id'] ?? '' ) ); $package = glutelab_get_package( $package_id );
	if ( ! $package ) glutelab_app_redirect_result( 'invalid-package' );
	$first_name = sanitize_text_field( wp_unslash( $_POST['first_name'] ?? '' ) ); $last_name = sanitize_text_field( wp_unslash( $_POST['last_name'] ?? '' ) ); $phone = sanitize_text_field( wp_unslash( $_POST['phone'] ?? '' ) );
	if ( '' === $first_name || '' === $last_name || '' === $phone || ! is_email( $email ) ) glutelab_app_redirect_result( 'invalid', '', $package_id );
	$method = 'stripe';
	$start = ''; $end = ''; $slot = sanitize_text_field( wp_unslash( $_POST['slot'] ?? '' ) );
	$preferred_date = sanitize_text_field( wp_unslash( $_POST['booking_date'] ?? '' ) );
	if ( $preferred_date && ! empty( $settings['booking_enabled'] ) ) {
		$dates = ! empty( $package['session_minutes'] ) ? glutelab_app_upcoming_schedule_dates( $package ) : glutelab_app_upcoming_open_dates();
		if ( ! in_array( $preferred_date, array_column( $dates, 'value' ), true ) ) glutelab_app_redirect_result( 'slot-unavailable', '', $package_id );
	}
	if ( $slot && ! empty( $settings['booking_enabled'] ) ) {
		$date = $preferred_date; $available = glutelab_app_slots_for_date( $date, $package );
		foreach ( $available as $candidate ) if ( hash_equals( $candidate['utc'] . '|' . $candidate['end_utc'], $slot ) ) { $start = $candidate['utc']; $end = $candidate['end_utc']; break; }
		if ( ! $start ) glutelab_app_redirect_result( 'slot-unavailable', '', $package_id );
	}
	$result = glutelab_app_create_request( array( 'package_id' => $package_id, 'first_name' => $first_name, 'last_name' => $last_name, 'email' => $email, 'phone' => $phone, 'notes' => sanitize_textarea_field( wp_unslash( $_POST['notes'] ?? '' ) ), 'payment_method' => $method, 'preferred_date' => $preferred_date, 'start_at_utc' => $start, 'end_at_utc' => $end ) );
	if ( is_wp_error( $result ) ) glutelab_app_redirect_result( $result->get_error_code(), '', $package_id );
	$order = $result['order']; glutelab_app_dispatch_request_emails( $result );
	$checkout_ready = ! empty( $settings['stripe_enabled'] ) && ! empty( $package['online_purchase_available'] ) && (float) $package['price'] > 0 && glutelab_app_stripe_is_configured();
	if ( ! $checkout_ready ) glutelab_app_redirect_result( 'payment-pending', $order['reference'], $package_id );
	$checkout = glutelab_app_stripe_create_checkout( $result );
	if ( ! is_wp_error( $checkout ) ) { wp_redirect( esc_url_raw( $checkout ) ); exit; }
	glutelab_app_redirect_result( 'payment-error', $order['reference'], $package_id );
}
add_action( 'admin_post_nopriv_glutelab_app_request', 'glutelab_app_handle_request' );
add_action( 'admin_post_glutelab_app_request', 'glutelab_app_handle_request' );

function glutelab_app_send_request_emails( array $result ) {
	$customer = glutelab_app_get_customer( $result['customer_id'] ); $order = $result['order']; $package = $result['package'];
	$admin = sanitize_email( get_option( 'ticinoweb_contact_email', get_option( 'admin_email' ) ) );
	$subject = sprintf( __( 'Nuova richiesta Glute Lab %s', 'glutelab-child-theme' ), $order['reference'] );
	$message = sprintf( "Offerta: %s\nCliente: %s %s\nEmail: %s\nTelefono: %s\nMetodo: %s\nRiferimento: %s", $package['title'], $customer['first_name'], $customer['last_name'], $customer['email'], $customer['phone'], $order['payment_method'], $order['reference'] );
	$appointment = ! empty( $result['booking'] ) ? glutelab_app_booking_interval_label( $result['booking']['start_at_utc'] ?? '', $result['booking']['end_at_utc'] ?? '' ) : '';
	$preferred_date = ! empty( $result['booking'] ) ? glutelab_app_preferred_date_label( $result['booking']['preferred_date'] ?? '' ) : '';
	if ( $appointment ) $message .= "\nOrario richiesto: " . $appointment;
	elseif ( $preferred_date ) $message .= "\nGiorno preferito: " . $preferred_date;
	$admin_sent = $admin ? wp_mail( $admin, $subject, $message ) : true;
	$customer_parts = array(
		sprintf( __( 'Ciao %s,', 'glutelab-child-theme' ), $customer['first_name'] ),
		sprintf( __( 'Abbiamo ricevuto la tua richiesta per %1$s. Il riferimento è %2$s.', 'glutelab-child-theme' ), $package['title'], $order['reference'] ),
	);
	if ( $appointment ) $customer_parts[] = sprintf( __( 'Orario richiesto: %s.', 'glutelab-child-theme' ), $appointment );
	elseif ( $preferred_date ) $customer_parts[] = sprintf( __( 'Giorno preferito: %s.', 'glutelab-child-theme' ), $preferred_date );
	$customer_parts[] = __( 'Ti contatteremo per la conferma.', 'glutelab-child-theme' );
	$customer_message = implode( "\n\n", $customer_parts );
	$customer_sent = wp_mail( $customer['email'], __( 'Richiesta Glute Lab ricevuta', 'glutelab-child-theme' ), $customer_message );
	return (bool) $admin_sent && (bool) $customer_sent;
}

function glutelab_app_dispatch_request_emails( array $result ) {
	try {
		return glutelab_app_send_request_emails( $result );
	} catch ( Throwable $error ) {
		do_action( 'glutelab_app_request_email_failed', $error, $result['order']['reference'] ?? '' );
		return false;
	}
}

function glutelab_app_require_admin() { if ( ! current_user_can( glutelab_app_management_capability() ) ) wp_die( esc_html__( 'Non hai i permessi necessari.', 'glutelab-child-theme' ) ); }
function glutelab_app_admin_redirect( $view = 'overview', $notice = 'saved' ) { wp_safe_redirect( add_query_arg( array( 'page' => 'glutelab-operations', 'view' => sanitize_key( $view ), 'gl_notice' => sanitize_key( $notice ) ), admin_url( 'admin.php' ) ) ); exit; }

function glutelab_app_save_settings_action() {
	glutelab_app_require_admin(); check_admin_referer( 'glutelab_app_save_settings' );
	if ( ! glutelab_app_save_stripe_credentials( $_POST['stripe_credentials'] ?? array() ) ) glutelab_app_admin_redirect( 'settings', 'stripe_credentials_invalid' );
	$scope    = 'availability' === sanitize_key( $_POST['settings_scope'] ?? '' ) ? 'availability' : 'general';
	$settings = glutelab_app_sanitize_settings_scope( $_POST['settings'] ?? array(), $scope );
	update_option( GLUTELAB_APP_SETTINGS_OPTION, $settings, false );
	glutelab_app_purge_public_cache();
	glutelab_app_admin_redirect( 'availability' === $scope ? 'availability' : 'settings' );
}
add_action( 'admin_post_glutelab_app_save_settings', 'glutelab_app_save_settings_action' );

function glutelab_app_save_durations_action() {
	glutelab_app_require_admin();
	check_admin_referer( 'glutelab_app_save_durations' );
	$durations = isset( $_POST['durations'] ) && is_array( $_POST['durations'] ) ? $_POST['durations'] : array();
	$catalog   = glutelab_apply_package_durations( glutelab_get_catalog(), $durations );
	update_option( 'glutelab_catalog', $catalog, false );
	glutelab_app_purge_public_cache();
	glutelab_app_admin_redirect( 'durations', 'durations_saved' );
}
add_action( 'admin_post_glutelab_app_save_durations', 'glutelab_app_save_durations_action' );

function glutelab_app_payment_reminder_action() {
	glutelab_app_require_admin();
	check_admin_referer( 'glutelab_app_payment_reminder' );
	$result = glutelab_app_send_payment_reminder( absint( $_POST['order_id'] ?? 0 ) );
	glutelab_app_admin_redirect( 'payments', is_wp_error( $result ) ? $result->get_error_code() : 'payment_reminder_sent' );
}
add_action( 'admin_post_glutelab_app_payment_reminder', 'glutelab_app_payment_reminder_action' );

function glutelab_app_booking_status_action() {
	glutelab_app_require_admin(); check_admin_referer( 'glutelab_app_booking_status' ); global $wpdb; $status = sanitize_key( $_POST['status'] ?? '' );
	$booking_id = absint( $_POST['booking_id'] ?? 0 ); $result = true; $booking = glutelab_app_get_booking( $booking_id );
	if ( ! $booking ) $result = new WP_Error( 'booking_not_found', __( 'Prenotazione non trovata.', 'glutelab-child-theme' ) );
	elseif ( ! glutelab_app_booking_status_transition_allowed( $booking['status'], $status ) ) $result = new WP_Error( 'invalid_status_transition', __( 'Lo stato finale della prenotazione non può essere modificato.', 'glutelab-child-theme' ) );
	elseif ( in_array( $status, array( 'confirmed', 'completed' ), true ) && ! empty( $booking['order_id'] ) ) {
		$order = glutelab_app_get_order( $booking['order_id'] );
		if ( $order && 'stripe' === $order['payment_method'] && 'paid' !== $order['status'] ) $result = new WP_Error( 'payment_required', __( 'La prenotazione può essere confermata soltanto dopo il pagamento online.', 'glutelab-child-theme' ) );
	}
	if ( in_array( $status, array( 'confirmed', 'cancelled', 'completed', 'no_show' ), true ) ) {
		if ( ! is_wp_error( $result ) && 'completed' === $status ) $result = glutelab_app_use_booking_credit( $booking_id );
		if ( ! is_wp_error( $result ) && 'cancelled' === $status ) $result = glutelab_app_restore_booking_credit( $booking_id );
		if ( ! is_wp_error( $result ) ) $wpdb->update( glutelab_app_table( 'bookings' ), array( 'status' => $status, 'updated_at' => glutelab_app_now_utc() ), array( 'id' => $booking_id ) );
	}
	glutelab_app_admin_redirect( 'bookings', is_wp_error( $result ) ? $result->get_error_code() : 'updated' );
}
add_action( 'admin_post_glutelab_app_booking_status', 'glutelab_app_booking_status_action' );

