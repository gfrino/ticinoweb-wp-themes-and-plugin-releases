<?php
/** Operational settings for Glute Lab. @package GluteLabChildTheme */
if ( ! defined( 'ABSPATH' ) ) exit;

define( 'GLUTELAB_APP_SETTINGS_OPTION', 'glutelab_app_settings' );

function glutelab_app_empty_week() {
	$days = array( 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday' );
	return array_fill_keys( $days, array() );
}

function glutelab_app_default_settings() {
	return array(
		'enabled' => 0, 'booking_enabled' => 0, 'payment_in_person_enabled' => 0, 'stripe_enabled' => 0,
		'stripe_mode' => 'test',
		'min_notice_hours' => 24, 'booking_horizon_days' => 60, 'reminder_hours' => 24,
		'weekly_patterns' => array( 'a' => glutelab_app_empty_week(), 'b' => glutelab_app_empty_week() ), 'closure_dates' => array(),
	);
}

function glutelab_app_sanitize_time( $value ) {
	$value = sanitize_text_field( $value );
	return preg_match( '/^(?:[01]\d|2[0-3]):[0-5]\d$/', $value ) ? $value : '';
}

function glutelab_app_sanitize_settings( $input ) {
	$input = is_array( $input ) ? wp_unslash( $input ) : array();
	$out = glutelab_app_default_settings();
	foreach ( array( 'enabled', 'booking_enabled', 'stripe_enabled' ) as $flag ) $out[ $flag ] = empty( $input[ $flag ] ) ? 0 : 1;
	$out['payment_in_person_enabled'] = 0;
	$out['stripe_mode'] = isset( $input['stripe_mode'] ) && 'live' === sanitize_key( $input['stripe_mode'] ) ? 'live' : 'test';
	$limits = array( 'min_notice_hours' => array( 0, 168 ), 'booking_horizon_days' => array( 1, 365 ), 'reminder_hours' => array( 0, 168 ) );
	foreach ( $limits as $key => $range ) {
		$value = isset( $input[ $key ] ) ? (int) $input[ $key ] : $out[ $key ];
		$out[ $key ] = min( $range[1], max( $range[0], $value ) );
	}
	$dates = $input['closure_dates'] ?? array();
	if ( is_string( $dates ) ) $dates = preg_split( '/[\r\n,]+/', $dates );
	$dates = array_filter( array_map( 'sanitize_text_field', is_array( $dates ) ? $dates : array() ), static function ( $date ) {
		$parsed = DateTimeImmutable::createFromFormat( '!Y-m-d', $date );
		return $parsed && $parsed->format( 'Y-m-d' ) === $date;
	} );
	$out['closure_dates'] = array_values( array_unique( $dates ) );
	foreach ( array_keys( $out['weekly_patterns'] ) as $pattern ) {
		foreach ( $out['weekly_patterns'][ $pattern ] as $day => $empty ) {
			$day_input = is_array( $input['weekly_patterns'][ $pattern ][ $day ] ?? null ) ? $input['weekly_patterns'][ $pattern ][ $day ] : array();
			$is_dynamic = array_key_exists( 'ranges', $day_input ) || array_key_exists( 'enabled', $day_input );
			if ( $is_dynamic && empty( $day_input['enabled'] ) ) continue;
			$intervals = $is_dynamic && is_array( $day_input['ranges'] ?? null ) ? $day_input['ranges'] : $day_input;
			$clean = array();
			foreach ( array_slice( array_values( $intervals ), 0, 8 ) as $interval ) {
				$interval = is_array( $interval ) ? $interval : array();
				$open = glutelab_app_sanitize_time( $interval['open'] ?? '' );
				$close = glutelab_app_sanitize_time( $interval['close'] ?? '' );
				if ( $open && $close && $open < $close ) $clean[ $open . '-' . $close ] = array( 'open' => $open, 'close' => $close );
			}
			usort( $clean, static function ( $a, $b ) { return strcmp( $a['open'], $b['open'] ); } );
			$out['weekly_patterns'][ $pattern ][ $day ] = array_values( $clean );
		}
	}
	return $out;
}

/** Sanitize one settings tab without erasing values owned by the other tab. */
function glutelab_app_sanitize_settings_scope( $input, $scope, $stored = null ) {
	$current = is_array( $stored ) ? $stored : glutelab_app_get_settings();
	$input   = is_array( $input ) ? wp_unslash( $input ) : array();
	if ( 'availability' === $scope ) {
		$current['weekly_patterns'] = $input['weekly_patterns'] ?? array();
		$current['closure_dates']   = $input['closure_dates'] ?? array();
	} else {
		foreach ( array( 'enabled', 'booking_enabled', 'stripe_enabled', 'stripe_mode', 'min_notice_hours', 'booking_horizon_days', 'reminder_hours' ) as $key ) {
			if ( array_key_exists( $key, $input ) ) $current[ $key ] = $input[ $key ];
			elseif ( in_array( $key, array( 'enabled', 'booking_enabled', 'stripe_enabled' ), true ) ) $current[ $key ] = 0;
		}
	}
	$current['payment_in_person_enabled'] = 0;
	return glutelab_app_sanitize_settings( $current );
}

function glutelab_app_get_settings() {
	$stored = get_option( GLUTELAB_APP_SETTINGS_OPTION, array() );
	if ( is_array( $stored ) && ! array_key_exists( 'stripe_mode', $stored ) ) {
		$legacy_key = (string) get_option( 'glutelab_app_stripe_key', '' );
		$stored['stripe_mode'] = 0 === strpos( $legacy_key, 'sk_live_' ) ? 'live' : 'test';
	}
	if ( is_array( $stored ) && ! array_key_exists( 'weekly_patterns', $stored ) && isset( $stored['weekly_schedule'] ) && is_array( $stored['weekly_schedule'] ) ) {
		$stored['weekly_patterns'] = array( 'a' => $stored['weekly_schedule'], 'b' => $stored['weekly_schedule'] );
	}
	$settings = glutelab_app_sanitize_settings( is_array( $stored ) ? array_merge( glutelab_app_default_settings(), $stored ) : array() );
	return apply_filters( 'glutelab_app_settings', $settings );
}

function glutelab_app_has_weekly_availability( $settings = null ) {
	$settings = is_array( $settings ) ? $settings : glutelab_app_get_settings();
	foreach ( array( 'a', 'b' ) as $pattern ) {
		if ( ! empty( array_filter( $settings['weekly_patterns'][ $pattern ] ?? array() ) ) ) return true;
	}
	return false;
}

function glutelab_app_is_enabled() { $settings = glutelab_app_get_settings(); return ! empty( $settings['enabled'] ); }

/** Return the selected Stripe environment, defaulting to the non-billable Test mode. */
function glutelab_app_stripe_mode( $settings = null ) {
	$settings = is_array( $settings ) ? $settings : glutelab_app_get_settings();
	return isset( $settings['stripe_mode'] ) && 'live' === $settings['stripe_mode'] ? 'live' : 'test';
}

/**
 * Read one environment-specific Stripe credential without exposing it in admin HTML.
 *
 * Legacy secret options and constants remain available only in the matching mode.
 */
function glutelab_app_get_stripe_credential( $credential, $mode = null ) {
	$allowed = array( 'publishable_key', 'secret_key', 'webhook_secret' );
	if ( ! in_array( $credential, $allowed, true ) ) return '';
	$mode = 'live' === $mode ? 'live' : ( 'test' === $mode ? 'test' : glutelab_app_stripe_mode() );
	$constants = array(
		'test' => array(
			'publishable_key' => 'GLUTELAB_STRIPE_TEST_PUBLISHABLE_KEY',
			'secret_key'      => 'GLUTELAB_STRIPE_TEST_SECRET_KEY',
			'webhook_secret'  => 'GLUTELAB_STRIPE_TEST_WEBHOOK_SECRET',
		),
		'live' => array(
			'publishable_key' => 'GLUTELAB_STRIPE_LIVE_PUBLISHABLE_KEY',
			'secret_key'      => 'GLUTELAB_STRIPE_LIVE_SECRET_KEY',
			'webhook_secret'  => 'GLUTELAB_STRIPE_LIVE_WEBHOOK_SECRET',
		),
	);
	$constant = $constants[ $mode ][ $credential ];
	if ( defined( $constant ) ) return (string) constant( $constant );

	$value = (string) get_option( 'glutelab_app_stripe_' . $mode . '_' . $credential, '' );
	if ( '' !== $value || 'publishable_key' === $credential ) return $value;

	$legacy_type = 'secret_key' === $credential ? 'stripe_key' : 'webhook_secret';
	if ( 'secret_key' === $credential && defined( 'GLUTELAB_STRIPE_SECRET_KEY' ) ) $legacy = (string) GLUTELAB_STRIPE_SECRET_KEY;
	elseif ( 'webhook_secret' === $credential && defined( 'GLUTELAB_STRIPE_WEBHOOK_SECRET' ) ) $legacy = (string) GLUTELAB_STRIPE_WEBHOOK_SECRET;
	else $legacy = (string) get_option( 'glutelab_app_' . $legacy_type, '' );
	if ( '' === $legacy ) return '';
	if ( 'secret_key' === $credential ) {
		if ( 0 === strpos( $legacy, 'sk_live_' ) ) return 'live' === $mode ? $legacy : '';
		if ( 0 === strpos( $legacy, 'sk_test_' ) ) return 'test' === $mode ? $legacy : '';
	}
	return $mode === glutelab_app_stripe_mode() ? $legacy : '';
}

/** True only when the selected environment has all credentials required by the UI. */
function glutelab_app_stripe_is_configured( $mode = null ) {
	$mode = 'live' === $mode ? 'live' : ( 'test' === $mode ? 'test' : glutelab_app_stripe_mode() );
	foreach ( array( 'publishable_key', 'secret_key', 'webhook_secret' ) as $credential ) {
		if ( '' === glutelab_app_get_stripe_credential( $credential, $mode ) ) return false;
	}
	return true;
}

/** Validate and save independent Test and Live credentials; blank protected fields preserve current values. */
function glutelab_app_save_stripe_credentials( $input ) {
	$input = is_array( $input ) ? wp_unslash( $input ) : array();
	$updates = array();
	$prefixes = array(
		'test' => array( 'publishable_key' => 'pk_test_', 'secret_key' => 'sk_test_', 'webhook_secret' => 'whsec_' ),
		'live' => array( 'publishable_key' => 'pk_live_', 'secret_key' => 'sk_live_', 'webhook_secret' => 'whsec_' ),
	);
	foreach ( $prefixes as $mode => $credentials ) {
		$values = isset( $input[ $mode ] ) && is_array( $input[ $mode ] ) ? $input[ $mode ] : array();
		foreach ( $credentials as $credential => $prefix ) {
			$value = isset( $values[ $credential ] ) ? trim( sanitize_text_field( $values[ $credential ] ) ) : '';
			if ( '' === $value ) continue;
			if ( 0 !== strpos( $value, $prefix ) ) return false;
			$updates[ 'glutelab_app_stripe_' . $mode . '_' . $credential ] = $value;
		}
	}
	foreach ( $updates as $option => $value ) update_option( $option, $value, false );
	return true;
}

function glutelab_app_get_secret( $type ) {
	if ( 'stripe_key' === $type ) return glutelab_app_get_stripe_credential( 'secret_key' );
	if ( 'webhook_secret' === $type ) return glutelab_app_get_stripe_credential( 'webhook_secret' );
	if ( 'publishable_key' === $type ) return glutelab_app_get_stripe_credential( 'publishable_key' );
	return (string) get_option( 'glutelab_app_' . sanitize_key( $type ), '' );
}
