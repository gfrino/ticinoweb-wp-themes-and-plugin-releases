<?php
/**
 * Confirmation page opened after the contact form has been sent.
 *
 * Title and text are the page's own WordPress content (editable, translated
 * by tW Translate Plus); phone and home link come from the CMS data.
 *
 * @package TelecomSecurityChild
 */

defined( 'ABSPATH' ) || exit;

$contact = telecomsecurity_contact_data();
?>
<main id="primary-content" class="ts-contact ts-thank-you">
	<section class="ts-contact-hero" aria-labelledby="ts-thank-you-title">
		<div class="ts-container ts-contact-hero__inner">
			<p class="ts-contact-hero__label"><?php esc_html_e( 'INVIO COMPLETATO', 'telecomsecurity-child-theme' ); ?></p>
			<h1 id="ts-thank-you-title"><?php the_title(); ?></h1>
			<div class="ts-contact-hero__intro ts-thank-you__text"><?php the_content(); ?></div>
			<span class="ts-contact-hero__signal" aria-hidden="true"></span>
			<div class="ts-contact-success__actions ts-thank-you__actions">
				<a class="is-primary" href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Torna alla Home', 'telecomsecurity-child-theme' ); ?></a>
				<?php if ( '' !== $contact['phone'] && '' !== $contact['phone_href'] ) : ?>
					<a href="<?php echo esc_url( 'tel:' . $contact['phone_href'] ); ?>"><?php echo esc_html( sprintf( __( 'Chiamaci: %s', 'telecomsecurity-child-theme' ), $contact['phone'] ) ); ?></a>
				<?php endif; ?>
			</div>
		</div>
	</section>
</main>
