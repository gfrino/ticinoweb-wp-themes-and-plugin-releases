<?php
/**
 * Settings access: per-site language configuration, per-site translation
 * engine (credentials, limit, usage) and the few network-level values.
 * All reads are memoized per request.
 *
 * @package tw-translate-plus
 */

if (!defined('ABSPATH')) {
    exit;
}

class Twtr_Settings {

    /** Default engine: gpt-oss-20b through OpenRouter. */
    const COMPAT_DEFAULT_URL   = 'https://openrouter.ai/api/v1';
    const COMPAT_DEFAULT_MODEL = 'openai/gpt-oss-20b';

    const SITE_OPTION    = 'twtr_settings';
    const ENGINE_OPTION  = 'twtr_engine';
    const USAGE_OPTION   = 'twtr_usage';
    const NETWORK_OPTION = 'twtr_network_settings';

    /** @var array|null */
    private static $site = null;

    /** @var array|null */
    private static $network = null;

    /** @var array<int,array> Engine settings memoized per blog id. */
    private static $engine = array();

    /**
     * Curated language catalog: slug => [label, WP locale, Google language
     * code, English name, flag]. The English name is what the OpenAI prompt
     * uses: model instructions are written in English, so naming the target
     * language in English is what they respond to most reliably.
     *
     * @return array<string,array{label:string,wp_locale:string,google:string,name:string,flag:string}>
     */
    public static function catalog() {
        return array(
            'it' => array('label' => 'Italiano',   'wp_locale' => 'it_IT', 'google' => 'it', 'name' => 'Italian', 'flag' => '🇮🇹'),
            'en' => array('label' => 'English',    'wp_locale' => 'en_US', 'google' => 'en', 'name' => 'English', 'flag' => '🇬🇧'),
            'de' => array('label' => 'Deutsch',    'wp_locale' => 'de_DE', 'google' => 'de', 'name' => 'German', 'flag' => '🇩🇪'),
            'fr' => array('label' => 'Français',   'wp_locale' => 'fr_FR', 'google' => 'fr', 'name' => 'French', 'flag' => '🇫🇷'),
            'es' => array('label' => 'Español',    'wp_locale' => 'es_ES', 'google' => 'es', 'name' => 'Spanish', 'flag' => '🇪🇸'),
            'pt' => array('label' => 'Português',  'wp_locale' => 'pt_PT', 'google' => 'pt', 'name' => 'Portuguese', 'flag' => '🇵🇹'),
            'nl' => array('label' => 'Nederlands', 'wp_locale' => 'nl_NL', 'google' => 'nl', 'name' => 'Dutch', 'flag' => '🇳🇱'),
            'pl' => array('label' => 'Polski',     'wp_locale' => 'pl_PL', 'google' => 'pl', 'name' => 'Polish', 'flag' => '🇵🇱'),
            'ru' => array('label' => 'Русский',    'wp_locale' => 'ru_RU', 'google' => 'ru', 'name' => 'Russian', 'flag' => '🇷🇺'),
            'uk' => array('label' => 'Українська', 'wp_locale' => 'uk',    'google' => 'uk', 'name' => 'Ukrainian', 'flag' => '🇺🇦'),
            'cs' => array('label' => 'Čeština',    'wp_locale' => 'cs_CZ', 'google' => 'cs', 'name' => 'Czech', 'flag' => '🇨🇿'),
            'ro' => array('label' => 'Română',     'wp_locale' => 'ro_RO', 'google' => 'ro', 'name' => 'Romanian', 'flag' => '🇷🇴'),
            'hu' => array('label' => 'Magyar',     'wp_locale' => 'hu_HU', 'google' => 'hu', 'name' => 'Hungarian', 'flag' => '🇭🇺'),
            'el' => array('label' => 'Ελληνικά',   'wp_locale' => 'el',    'google' => 'el', 'name' => 'Greek', 'flag' => '🇬🇷'),
            'hr' => array('label' => 'Hrvatski',   'wp_locale' => 'hr',    'google' => 'hr', 'name' => 'Croatian', 'flag' => '🇭🇷'),
            'sq' => array('label' => 'Shqip',      'wp_locale' => 'sq',    'google' => 'sq', 'name' => 'Albanian', 'flag' => '🇦🇱'),
            'sv' => array('label' => 'Svenska',    'wp_locale' => 'sv_SE', 'google' => 'sv', 'name' => 'Swedish', 'flag' => '🇸🇪'),
            'da' => array('label' => 'Dansk',      'wp_locale' => 'da_DK', 'google' => 'da', 'name' => 'Danish', 'flag' => '🇩🇰'),
            'tr' => array('label' => 'Türkçe',     'wp_locale' => 'tr_TR', 'google' => 'tr', 'name' => 'Turkish', 'flag' => '🇹🇷'),
            'zh' => array('label' => '中文 (简体)', 'wp_locale' => 'zh_CN', 'google' => 'zh-CN', 'name' => 'Chinese (Simplified)', 'flag' => '🇨🇳'),
            'ja' => array('label' => '日本語',      'wp_locale' => 'ja',    'google' => 'ja', 'name' => 'Japanese', 'flag' => '🇯🇵'),
            'ar' => array('label' => 'العربية',    'wp_locale' => 'ar',    'google' => 'ar', 'name' => 'Arabic', 'flag' => '🇸🇦'),
        );
    }

    /**
     * Per-site settings with defaults.
     *
     * @return array{default_lang:string,languages:array<string,array{published:bool}>}
     */
    public static function site() {
        if (self::$site === null) {
            $saved = get_option(self::SITE_OPTION, array());
            self::$site = wp_parse_args(is_array($saved) ? $saved : array(), array(
                'default_lang'    => self::guess_default_lang(),
                'languages'       => array(),
                /*
                 * Acceso di default: i siti gia' in produzione contano sulla
                 * traduzione automatica esistente, e un default spento
                 * cambierebbe il loro comportamento senza che nessuno lo abbia
                 * chiesto. Chi vuole attivare una lingua senza tradurla lo
                 * decide esplicitamente dal tab Lingue.
                 */
                'auto_translate'  => true,
            ));
        }
        return self::$site;
    }

    /**
     * @param array $settings New site settings (already validated by the caller).
     */
    public static function update_site($settings) {
        $catalog = self::catalog();
        $clean   = array(
            'default_lang'   => isset($catalog[$settings['default_lang']]) ? $settings['default_lang'] : 'it',
            'languages'      => array(),
            'auto_translate' => !empty($settings['auto_translate']),
        );
        if (!empty($settings['languages']) && is_array($settings['languages'])) {
            foreach ($settings['languages'] as $slug => $cfg) {
                if ($slug === $clean['default_lang'] || !isset($catalog[$slug])) {
                    continue;
                }
                $clean['languages'][$slug] = array('published' => !empty($cfg['published']));
            }
        }
        update_option(self::SITE_OPTION, $clean, true);
        self::$site = null;
    }

    /**
     * Default language slug for this site.
     *
     * @return string
     */
    public static function default_lang() {
        $s = self::site();
        return $s['default_lang'];
    }

    /**
     * Whether missing translations are queued and processed automatically.
     *
     * Quando falso: le lingue attive restano visitabili (per configurazione,
     * anteprima o traduzione manuale), ma ne' il salvataggio di un contenuto
     * ne' la prima visita frontend mettono in coda nulla ne' avviano il cron.
     * L'elaborazione resta disponibile su richiesta esplicita, dal tab
     * Traduzioni ("Processa ora") o da WP-CLI (`wp twtr queue`), che chiamano
     * Twtr_Queue::process() direttamente e non passano da questo interruttore.
     *
     * @return bool
     */
    public static function auto_translate() {
        $s = self::site();
        return !empty($s['auto_translate']);
    }

    /**
     * Additional (non-default) languages enabled on this site.
     *
     * @param bool $published_only Only languages published to visitors.
     * @return string[] Language slugs.
     */
    public static function extra_languages($published_only = false) {
        $s    = self::site();
        $slugs = array();
        foreach ($s['languages'] as $slug => $cfg) {
            if ($published_only && empty($cfg['published'])) {
                continue;
            }
            $slugs[] = $slug;
        }
        return $slugs;
    }

    /**
     * Map a language slug to its WordPress locale.
     *
     * @param string $slug
     * @return string
     */
    public static function wp_locale($slug) {
        $catalog = self::catalog();
        return isset($catalog[$slug]) ? $catalog[$slug]['wp_locale'] : $slug;
    }

    /**
     * Flag emoji of a language.
     *
     * @param string $slug
     * @return string
     */
    public static function flag($slug) {
        $catalog = self::catalog();
        return isset($catalog[$slug]['flag']) ? $catalog[$slug]['flag'] : '🏳️';
    }

    /**
     * Map a language slug to its Google Translation language code.
     *
     * @param string $slug
     * @return string
     */
    public static function google_code($slug) {
        $catalog = self::catalog();
        return isset($catalog[$slug]) ? $catalog[$slug]['google'] : $slug;
    }

    /**
     * English name of a language, used when instructing an LLM.
     *
     * @param string $slug
     * @return string
     */
    public static function language_name($slug) {
        $catalog = self::catalog();
        return isset($catalog[$slug]['name']) ? $catalog[$slug]['name'] : $slug;
    }

    /**
     * Network-level settings: only what is genuinely shared by every site
     * (queue batch size, uninstall policy).
     *
     * glossary_version is no longer read: since 1.9.0 every site has its own
     * glossary and its own version (see engine()).
     *
     * Engine, credentials, daily limit and usage are per site since 1.7.0
     * (see engine()): a key belongs to one site and translates only that
     * site. Keys still present in this option from older versions are never
     * read — there is deliberately no network fallback.
     *
     * @return array
     */
    public static function network() {
        if (self::$network === null) {
            $saved = get_site_option(self::NETWORK_OPTION, array());
            self::$network = wp_parse_args(is_array($saved) ? $saved : array(), array(
                'batch_size'          => 25,
                'glossary_version'    => 1,
                'delete_on_uninstall' => false,
            ));
        }
        return self::$network;
    }

    /**
     * @param array $partial Keys to merge into the network settings.
     */
    public static function update_network($partial) {
        $current = self::network();
        $merged  = array_merge($current, $partial);
        update_site_option(self::NETWORK_OPTION, $merged);
        self::$network = $merged;
    }

    /**
     * Translation engine of the CURRENT site: engine choice, its credentials,
     * daily character limit, glossary version and Google glossary sync state.
     *
     * Stored per site (not autoloaded: it holds secrets and is only needed
     * by the queue and the admin). Memoized per blog id so a
     * switch_to_blog() loop never reads another site's key.
     *
     * A site without credentials for its engine does not translate at all:
     * nothing falls back to a network or wp-config key.
     *
     * @return array
     */
    public static function engine() {
        $blog_id = get_current_blog_id();
        if (!isset(self::$engine[$blog_id])) {
            $saved = get_option(self::ENGINE_OPTION, array());
            self::$engine[$blog_id] = wp_parse_args(is_array($saved) ? $saved : array(), array(
                // Default engine for sites never configured: gpt-oss-20b, the
                // cheapest model that translates well, via OpenRouter. Sites
                // that saved an engine keep theirs (stored in the option).
                'provider'                => 'compat',
                'openai_api_key'          => '',
                'openai_model'            => 'gpt-4o-mini',
                'openai_models'           => array(),
                'openai_models_at'        => '',
                'compat_base_url'         => self::COMPAT_DEFAULT_URL,
                'compat_api_key'          => '',
                'compat_model'            => self::COMPAT_DEFAULT_MODEL,
                'project_id'              => '',
                'location'                => 'us-central1',
                'credentials_path'        => '',
                'credentials_json'        => '',
                'gcs_bucket'              => '',
                'daily_char_limit'        => 500000,
                // Starts at 0 on purpose: a site synced before 1.9.0 has
                // glossary_synced_version >= 1, so the mismatch makes it
                // rebuild its Google resources from its own terms.
                'glossary_version'        => 0,
                'glossary_state'          => array(),
                'glossary_synced_version' => 0,
            ));
        }
        return self::$engine[$blog_id];
    }

    /**
     * @param array $partial Keys to merge into the current site's engine settings.
     */
    public static function update_engine($partial) {
        $merged = array_merge(self::engine(), $partial);
        update_option(self::ENGINE_OPTION, $merged, false);
        self::$engine[get_current_blog_id()] = $merged;
    }

    /**
     * Whether the current site has what its engine needs to translate.
     *
     * @return bool
     */
    public static function engine_ready() {
        if (self::provider() === 'openai') {
            return self::openai_api_key() !== '';
        }
        if (self::provider() === 'compat') {
            // The key is optional only for a self-hosted server (Ollama,
            // vLLM); the public services always require one, and without it
            // every request would just fail with 401.
            $c = self::compat_config();
            return $c['base_url'] !== '' && $c['model'] !== ''
                && ($c['api_key'] !== '' || !self::compat_needs_key($c['base_url']));
        }
        $cfg = self::google_config();
        return $cfg['project_id'] !== '' && ($cfg['credentials_path'] !== '' || self::credentials_json() !== '');
    }

    /**
     * Human-readable reason why the current site does not translate, for
     * the queue message, the admin and WP-CLI.
     *
     * @return string Empty when the engine is ready.
     */
    public static function engine_missing_reason() {
        if (self::engine_ready()) {
            return '';
        }
        if (self::provider() === 'compat') {
            return __('Motore gpt-oss / compatibile OpenAI senza chiave API (o senza indirizzo e modello) per questo sito: la traduzione automatica è ferma. Inserisci la chiave in tW Translate ▸ API traduzione.', 'tw-translate-plus');
        }
        return self::provider() === 'openai'
            ? __('Nessuna chiave OpenAI configurata per questo sito: la traduzione automatica è ferma. Inseriscila in tW Translate ▸ API traduzione.', 'tw-translate-plus')
            : __('Credenziali Google non configurate per questo sito (Project ID e service account): la traduzione automatica è ferma. Inseriscile in tW Translate ▸ API traduzione.', 'tw-translate-plus');
    }

    /**
     * Translation engines the plugin can drive.
     *
     * @return array<string,string> slug => label.
     */
    public static function providers() {
        return array(
            'compat' => __('gpt-oss-20b e altri modelli aperti (consigliato: il più economico)', 'tw-translate-plus'),
            'openai' => __('OpenAI', 'tw-translate-plus'),
            'google' => __('Google Cloud Translation', 'tw-translate-plus'),
        );
    }

    /**
     * Whether the active engine is a language model reached through the
     * OpenAI chat API (OpenAI itself or a compatible server). Those share
     * the client, the inline glossary and the smaller batch budget.
     *
     * @return bool
     */
    public static function is_llm() {
        return in_array(self::provider(), array('openai', 'compat'), true);
    }

    /**
     * Translation engine chosen for the current site.
     *
     * @return string 'google' | 'openai' | 'compat'
     */
    public static function provider() {
        $value = strtolower((string) self::engine()['provider']);
        return isset(self::providers()[$value]) ? $value : 'compat';
    }

    /**
     * @param string|null $slug Engine slug, null = the active one.
     * @return string Human-readable engine name.
     */
    public static function provider_label($slug = null) {
        $slug      = $slug === null ? self::provider() : $slug;
        $providers = self::providers();
        return isset($providers[$slug]) ? $providers[$slug] : $slug;
    }

    /**
     * Short engine name, for badges and inline buttons where the full
     * product name would not fit.
     *
     * @param string|null $slug Engine slug, null = the active one.
     * @return string
     */
    public static function provider_short_label($slug = null) {
        $slug  = $slug === null ? self::provider() : $slug;
        $short = array('google' => 'Google', 'openai' => 'OpenAI', 'compat' => 'gpt-oss');
        return isset($short[$slug]) ? $short[$slug] : self::provider_label($slug);
    }

    /**
     * Origins that mean "produced by a translation engine", as opposed to a
     * manual override. Entries keep the slug of the engine that wrote them,
     * so a site that switched engine still shows where each text came
     * from and both remain requeueable.
     *
     * @return string[]
     */
    public static function machine_origins() {
        return array_keys(self::providers());
    }

    /**
     * Resolved configuration of the OpenAI client for the current site:
     * OpenAI itself, or the compatible server when that engine is active
     * (same chat API, different address, key and model).
     *
     * @return array{api_key:string,model:string,base_url:string}
     */
    public static function openai_config() {
        if (self::provider() === 'compat') {
            return self::compat_config();
        }
        $e = self::engine();
        return array(
            'api_key'  => self::openai_api_key(),
            'model'    => $e['openai_model'] !== '' ? $e['openai_model'] : 'gpt-4o-mini',
            'base_url' => defined('TWTR_OPENAI_BASE_URL') ? TWTR_OPENAI_BASE_URL : 'https://api.openai.com/v1',
        );
    }

    /**
     * Whether a compatible server is a public service that requires a key.
     *
     * @param string $base_url
     * @return bool
     */
    public static function compat_needs_key($base_url) {
        $host = strtolower((string) wp_parse_url($base_url, PHP_URL_HOST));
        foreach (array('openrouter.ai', 'groq.com', 'together.xyz', 'together.ai', 'openai.com', 'fireworks.ai', 'deepinfra.com') as $public) {
            if ($host === $public || substr($host, -strlen('.' . $public)) === '.' . $public) {
                return true;
            }
        }
        return false;
    }

    /**
     * Configuration of the OpenAI-compatible engine of the current site.
     *
     * @return array{api_key:string,model:string,base_url:string}
     */
    public static function compat_config() {
        $e = self::engine();
        return array(
            'api_key'  => (string) $e['compat_api_key'],
            'model'    => (string) $e['compat_model'],
            'base_url' => untrailingslashit((string) $e['compat_base_url']),
        );
    }

    /**
     * @return string Last 4 characters of the compatible engine's key, '' when none.
     */
    public static function compat_key_hint() {
        $key = (string) self::engine()['compat_api_key'];
        return $key === '' ? '' : substr($key, -4);
    }

    /**
     * OpenAI API key of the current site. Only the site's own setting:
     * constants, environment variables and network values are ignored on
     * purpose, because each of them would translate every site with the
     * same key.
     *
     * @return string Empty string when not configured.
     */
    public static function openai_api_key() {
        return (string) self::engine()['openai_api_key'];
    }

    /**
     * Models offered in the settings dropdown when the list has never been
     * fetched from the API. Small on purpose: the "Aggiorna elenco" button
     * replaces it with whatever the account can actually reach.
     *
     * @return string[]
     */
    public static function default_openai_models() {
        return array('gpt-4o-mini', 'gpt-4o', 'gpt-4.1-mini', 'gpt-4.1');
    }

    /**
     * Choices for the model dropdown: the list last fetched from OpenAI, or
     * the built-in defaults. The configured model is always included even if
     * it is absent from the list, so opening the page can never silently
     * change which model is in use.
     *
     * @return string[]
     */
    public static function openai_model_choices() {
        $e      = self::engine();
        $stored = is_array($e['openai_models']) ? array_filter(array_map('strval', $e['openai_models'])) : array();
        $models = $stored ? $stored : self::default_openai_models();

        $current = self::openai_config()['model'];
        if ($current !== '' && !in_array($current, $models, true)) {
            array_unshift($models, $current);
        }
        return array_values(array_unique($models));
    }

    /**
     * When the model list was last fetched, for UI display.
     *
     * @return string Empty string when never fetched.
     */
    public static function openai_models_fetched_at() {
        return (string) self::engine()['openai_models_at'];
    }

    /**
     * Store a freshly fetched model list.
     *
     * @param string[] $models
     */
    public static function update_openai_models($models) {
        $clean = array();
        foreach ((array) $models as $model) {
            $model = sanitize_text_field((string) $model);
            if ($model !== '') {
                $clean[] = $model;
            }
        }
        // Capped: a handful of accounts can see hundreds of fine-tuned models.
        $clean = array_slice(array_values(array_unique($clean)), 0, 200);
        self::update_engine(array(
            'openai_models'    => $clean,
            'openai_models_at' => current_time('mysql', true),
        ));
    }

    /**
     * Where the OpenAI key comes from, for UI display.
     *
     * @return string 'db' | ''
     */
    public static function openai_key_source() {
        return self::openai_api_key() !== '' ? 'db' : '';
    }

    /**
     * Last 4 characters of the stored key, so the UI can confirm which key
     * is in use without ever printing it back in full.
     *
     * @return string
     */
    public static function openai_key_hint() {
        $key = self::openai_api_key();
        return $key === '' ? '' : substr($key, -4);
    }

    /**
     * Resolved Google configuration of the current site.
     *
     * @return array{project_id:string,location:string,credentials_path:string,gcs_bucket:string}
     */
    public static function google_config() {
        $e = self::engine();
        return array(
            'project_id'       => (string) $e['project_id'],
            'location'         => (string) $e['location'] !== '' ? (string) $e['location'] : 'us-central1',
            'credentials_path' => self::credentials_path(),
            'gcs_bucket'       => (string) $e['gcs_bucket'],
        );
    }

    /**
     * Path of the site's service-account JSON file.
     *
     * @return string Empty string when not configured.
     */
    public static function credentials_path() {
        return (string) self::engine()['credentials_path'];
    }

    /**
     * Service-account JSON pasted in the site's admin. Never printed back.
     *
     * @return string Raw JSON, '' when not set.
     */
    public static function credentials_json() {
        return (string) self::engine()['credentials_json'];
    }

    /**
     * Where the Google credentials come from, for UI display.
     *
     * @return string 'path' | 'db' | ''
     */
    public static function credentials_source() {
        if (self::credentials_path() !== '') {
            return 'path';
        }
        if (self::credentials_json() !== '') {
            return 'db';
        }
        return '';
    }

    /**
     * Daily character limit of the current site (0 = no limit).
     *
     * @return int
     */
    public static function daily_char_limit() {
        return max(0, (int) self::engine()['daily_char_limit']);
    }

    /**
     * Characters the current site sent to its engine today (UTC day).
     *
     * @return int
     */
    public static function usage_today() {
        $usage = get_option(self::USAGE_OPTION, array());
        $key   = gmdate('Y-m-d');
        return is_array($usage) && isset($usage[$key]) ? (int) $usage[$key] : 0;
    }

    /**
     * @param int $chars Characters to add to the current site's usage today.
     */
    public static function add_usage($chars) {
        $usage = get_option(self::USAGE_OPTION, array());
        $usage = is_array($usage) ? $usage : array();
        $key   = gmdate('Y-m-d');
        $usage[$key] = (isset($usage[$key]) ? (int) $usage[$key] : 0) + (int) $chars;
        // Keep only the last 7 days.
        krsort($usage);
        $usage = array_slice($usage, 0, 7, true);
        update_option(self::USAGE_OPTION, $usage, false);
    }

    /**
     * Best-effort default language guess from the site locale.
     *
     * @return string
     */
    private static function guess_default_lang() {
        $locale = function_exists('get_locale') ? get_locale() : 'it_IT';
        $slug   = strtolower(substr($locale, 0, 2));
        $catalog = self::catalog();
        return isset($catalog[$slug]) ? $slug : 'it';
    }
}
