<?php
// Register CPT and Taxonomies
add_action('init', 'tt_register_cpts');
function tt_register_cpts()
{
    // Categoria Azienda Taxonomy
    register_taxonomy('categoria_azienda', 'azienda', [
        'labels' => [
            'name' => 'Categorie Aziende',
            'singular_name' => 'Categoria Azienda',
            'search_items' => 'Cerca Categorie',
            'all_items' => 'Tutte le Categorie',
            'edit_item' => 'Modifica Categoria',
            'update_item' => 'Aggiorna Categoria',
            'add_new_item' => 'Aggiungi Nuova Categoria',
            'new_item_name' => 'Nuovo Nome Categoria',
            'menu_name' => 'Categorie',
        ],
        'hierarchical' => true,
        'show_admin_column' => true,
        'show_in_rest' => true,
        'rewrite' => ['slug' => 'categoria-azienda'],
    ]);

    // Azienda CPT
    register_post_type('azienda', [
        'labels' => [
            'name' => 'Aziende',
            'singular_name' => 'Azienda',
            'menu_name' => 'Aziende',
            'name_admin_bar' => 'Azienda',
            'add_new' => 'Aggiungi Nuova',
            'add_new_item' => 'Aggiungi Nuova Azienda',
            'new_item' => 'Nuova Azienda',
            'edit_item' => 'Modifica Azienda',
            'view_item' => 'Visualizza Azienda',
            'all_items' => 'Tutte le Aziende',
            'search_items' => 'Cerca Aziende',
            'not_found' => 'Nessuna azienda trovata.',
        ],
        'public' => true,
        'has_archive' => true,
        'menu_icon' => 'dashicons-store',
        'menu_position' => 5,
        'supports' => ['title', 'editor', 'thumbnail'],
        'show_in_rest' => true,
        'rewrite' => ['slug' => 'azienda'],
    ]);

    // Classifica CPT
    register_post_type('classifica', [
        'labels' => [
            'name' => 'Classifiche',
            'singular_name' => 'Classifica',
            'menu_name' => 'Classifiche',
            'add_new' => 'Aggiungi Nuova',
            'add_new_item' => 'Aggiungi Nuova Classifica',
        ],
        'public' => true,
        'has_archive' => true,
        'menu_icon' => 'dashicons-awards',
        'menu_position' => 6,
        'supports' => ['title', 'editor', 'thumbnail'],
        'show_in_rest' => true,
        'rewrite' => ['slug' => 'classifica'],
    ]);

    // Candidatura CPT (Privato per salvataggio form)
    register_post_type('candidatura', [
        'labels' => [
            'name' => 'Candidature',
            'singular_name' => 'Candidatura',
            'menu_name' => 'Candidature',
            'all_items' => 'Tutte le Candidature',
            'view_item' => 'Visualizza Candidatura',
        ],
        'public' => false,
        'show_ui' => true,
        'show_in_menu' => true,
        'menu_icon' => 'dashicons-portfolio',
        'menu_position' => 7,
        'supports' => ['title', 'editor', 'custom-fields'],
        'capabilities' => array(
            'create_posts' => 'do_not_allow', // Only created via frontend form
        ),
        'map_meta_cap' => true, // Allows editing but not creating from backend
    ]);
}

// Add Meta Boxes
add_action('add_meta_boxes', 'tt_add_azienda_metaboxes');
function tt_add_azienda_metaboxes()
{
    add_meta_box('tt_azienda_dati', 'Dati Reputazionali Azienda', 'tt_azienda_metabox_callback', 'azienda', 'normal', 'high');
    add_meta_box('tt_classifica_dati', 'Impostazioni Classifica', 'tt_classifica_metabox_callback', 'classifica', 'normal', 'high');
    add_meta_box('tt_chisiamo_dati', 'Contenuto Pagina "Chi Siamo"', 'tt_chisiamo_metabox_callback', 'page', 'normal', 'high');
    add_meta_box('tt_post_evidenza', 'Impostazioni Articolo', 'tt_post_evidenza_metabox_callback', 'post', 'side', 'high');
}

function tt_classifica_metabox_callback($post)
{
    wp_nonce_field('tt_classifica_save_meta', 'tt_classifica_nonce');

    $linked_cat = get_post_meta($post->ID, '_tt_classifica_categoria', true);
    $limit = get_post_meta($post->ID, '_tt_classifica_limit', true) ?: 10;
    $affidabilita = get_post_meta($post->ID, '_tt_classifica_affidabilita', true) ?: '95%';
    $valutate = get_post_meta($post->ID, '_tt_classifica_valutate', true) ?: '48';
    $badge = get_post_meta($post->ID, '_tt_classifica_badge', true) ?: 'Top Classifica';
    $methodology = get_post_meta($post->ID, '_tt_classifica_methodology', true) ?: "L'AI di Ticino Top ha analizzato le recensioni verificando la coerenza temporale e l'affidabilità di ciascuna attività.";
    $in_evidenza = get_post_meta($post->ID, '_tt_classifica_evidenza', true);

    $categories = get_terms([
        'taxonomy' => 'categoria_azienda',
        'hide_empty' => false,
    ]);

    echo '<style>
        .tt-meta-row { margin-bottom: 20px; } 
        .tt-meta-row label { display: block; font-weight: bold; margin-bottom: 8px; font-size: 14px; } 
        .tt-meta-row input[type="text"], .tt-meta-row select { width: 100%; max-width: 400px; padding: 6px 10px; }
        .tt-meta-row textarea { width: 100%; max-width: 800px; padding: 10px; }
        .tt-meta-desc { font-size: 12px; color: #666; margin-top: 4px; display: block; }
    </style>';

    echo '<div class="tt-meta-row">';
    echo '<label>Categoria Collegata</label>';
    echo '<select name="tt_classifica_categoria">';
    echo '<option value="">-- Seleziona una categoria --</option>';
    if (!empty($categories) && !is_wp_error($categories)) {
        foreach ($categories as $cat) {
            $selected = ($linked_cat == $cat->term_id) ? 'selected' : '';
            echo '<option value="' . esc_attr($cat->term_id) . '" ' . $selected . '>' . esc_html($cat->name) . '</option>';
        }
    }
    echo '</select>';
    echo '<span class="tt-meta-desc">L\'elenco delle aziende di questa categoria verrà mostrato dinamicamente nella classifica.</span>';
    echo '</div>';

    echo '<div class="tt-meta-row">';
    echo '<label>Badge Superiore (AI Label)</label>';
    echo '<input type="text" name="tt_classifica_badge" value="' . esc_attr($badge) . '" placeholder="es. Food & Dining">';
    echo '</div>';

    echo '<div class="tt-meta-row">';
    echo '<label>Numero Massimo di Risultati</label>';
    echo '<input type="text" name="tt_classifica_limit" value="' . esc_attr($limit) . '" placeholder="es. 10">';
    echo '</div>';

    echo '<div class="tt-meta-row">';
    echo '<label>Affidabilità Dati %</label>';
    echo '<input type="text" name="tt_classifica_affidabilita" value="' . esc_attr($affidabilita) . '" placeholder="es. 94%">';
    echo '</div>';

    echo '<div class="tt-meta-row">';
    echo '<label>Numero di Aziende Valutate</label>';
    echo '<input type="text" name="tt_classifica_valutate" value="' . esc_attr($valutate) . '" placeholder="es. 45">';
    echo '</div>';

    echo '<div class="tt-meta-row">';
    echo '<label>Metodologia AI (Descrizione del processo di analisi)</label>';
    echo '<textarea name="tt_classifica_methodology" rows="4" placeholder="Come l\'AI ha analizzato i dati...">' . esc_textarea($methodology) . '</textarea>';
    echo '</div>';

    echo '<div class="tt-meta-row" style="background: #fff8e5; padding: 15px; border-radius: 6px; border: 1px solid #ffe8cc; max-width: 400px; margin-top: 10px;">';
    echo '<label style="display: flex; align-items: center; cursor: pointer; font-weight: bold; color: #b27a00; margin: 0;">';
    echo '<input type="checkbox" name="tt_classifica_evidenza" value="1" ' . checked($in_evidenza, '1', false) . ' style="margin-right: 10px; width: 18px; height: 18px;">';
    echo '⭐️ Metti in Evidenza nella Home Page';
    echo '</label>';
    echo '<span class="tt-meta-desc" style="margin-left: 28px; color: #856404;">Se selezionata, questa classifica apparirà nella sezione "Classifiche in Evidenza" della Home Page.</span>';
    echo '</div>';

    $status = get_post_meta($post->ID, '_tt_classifica_status', true);
    if ($status === '') {
        $status = '1'; // Default attivo
    }

    echo '<div class="tt-meta-row" style="background: #e6fffa; padding: 15px; border-radius: 6px; border: 1px solid #b2f5ea; max-width: 400px; margin-top: 10px;">';
    echo '<label style="display: flex; align-items: center; cursor: pointer; font-weight: bold; color: #008080; margin: 0;">';
    echo '<input type="checkbox" name="tt_classifica_status" value="1" ' . checked($status, '1', false) . ' style="margin-right: 10px; width: 18px; height: 18px;">';
    echo '🟢 Mostra nel sito (Visibile)';
    echo '</label>';
    echo '<span class="tt-meta-desc" style="margin-left: 28px; color: #004d4d;">Se deselezionata, la classifica verrà nascosta da tutte le pagine pubbliche del sito (Home Page, Archivi, Ricerche).</span>';
    echo '</div>';
}

function tt_azienda_metabox_callback($post)
{
    wp_nonce_field('tt_azienda_save_meta', 'tt_azienda_nonce');

    $voto = get_post_meta($post->ID, '_tt_voto', true);
    $recensioni = get_post_meta($post->ID, '_tt_recensioni', true);
    $ai_match = get_post_meta($post->ID, '_tt_ai_match', true);
    $ai_text = get_post_meta($post->ID, '_tt_ai_text', true);
    $image_url = get_post_meta($post->ID, '_tt_image', true);
    $keywords = get_post_meta($post->ID, '_tt_keywords', true);

    // Awards fields
    $award_year = get_post_meta($post->ID, '_tt_award_year', true);
    $award_category = get_post_meta($post->ID, '_tt_award_category', true);
    $award_motivation = get_post_meta($post->ID, '_tt_award_motivation', true);

    echo '<style>
        .tt-meta-row { margin-bottom: 20px; } 
        .tt-meta-row label { display: block; font-weight: bold; margin-bottom: 8px; font-size: 14px; } 
        .tt-meta-row input[type="text"], .tt-meta-row select { width: 100%; max-width: 400px; padding: 6px 10px; }
        .tt-meta-row textarea { width: 100%; max-width: 800px; padding: 10px; }
        .tt-meta-desc { font-size: 12px; color: #666; margin-top: 4px; display: block; }
        .tt-section-title { font-size: 16px; font-weight: bold; margin: 30px 0 15px 0; border-bottom: 1px solid #ccc; padding-bottom: 8px; color: #1a2942; }
    </style>';

    echo '<div class="tt-meta-row">';
    echo '<label>Voto Medio</label>';
    echo '<input type="text" name="tt_voto" value="' . esc_attr($voto) . '" placeholder="es. 4.8">';
    echo '<span class="tt-meta-desc">Il punteggio da stampare nel badge (es. 4.8)</span>';
    echo '</div>';

    echo '<div class="tt-meta-row">';
    echo '<label>Numero di Recensioni Analizzate</label>';
    echo '<input type="text" name="tt_recensioni" value="' . esc_attr($recensioni) . '" placeholder="es. 1.248">';
    echo '</div>';

    echo '<div class="tt-meta-row">';
    echo '<label>AI Match / Consistency Score %</label>';
    echo '<input type="text" name="tt_ai_match" value="' . esc_attr($ai_match) . '" placeholder="es. 96">';
    echo '</div>';

    echo '<div class="tt-meta-row">';
    echo '<label>URL Immagine Esterna (Opzionale, utile per i test)</label>';
    echo '<input type="text" name="tt_image" value="' . esc_attr($image_url) . '" placeholder="https://images.unsplash.com/...">';
    echo '<span class="tt-meta-desc">Se compilato, ha la precedenza sull\'immagine in evidenza standard.</span>';
    echo '</div>';

    echo '<div class="tt-meta-row">';
    echo '<label>Testo Analisi AI</label>';
    echo '<textarea name="tt_ai_text" rows="5" placeholder="Scrivi il riassunto algoritmico qui...">' . esc_textarea($ai_text) . '</textarea>';
    echo '</div>';

    echo '<div class="tt-meta-row">';
    echo '<label>Keywords / Parole Chiave (Ricerca Smart)</label>';
    echo '<input type="text" name="tt_keywords" value="' . esc_attr($keywords) . '" placeholder="es. dentista, pizza, romantico, idraulico">';
    echo '<span class="tt-meta-desc">Aiuta il motore di ricerca a trovare questa azienda anche se la parola non è nel titolo (separate da virgola).</span>';
    echo '</div>';

    // Contatti (compilati anche dallo Scanner AI)
    echo '<div class="tt-section-title">📍 Contatti & Sito Web</div>';
    $contact_fields = [
        'tt_website'   => ['_tt_website', 'Sito Web', 'https://...'],
        'tt_localita'  => ['_tt_localita', 'Località', 'es. Lugano, Ticino'],
        'tt_indirizzo' => ['_tt_indirizzo', 'Indirizzo', 'es. Via Nassa 1, 6900 Lugano'],
        'tt_telefono'  => ['_tt_telefono', 'Telefono', 'es. +41 91 000 00 00'],
        'tt_email'     => ['_tt_email', 'Email', 'info@...'],
    ];
    foreach ($contact_fields as $name => $field) {
        echo '<div class="tt-meta-row">';
        echo '<label>' . esc_html($field[1]) . '</label>';
        echo '<input type="text" name="' . esc_attr($name) . '" value="' . esc_attr(get_post_meta($post->ID, $field[0], true)) . '" placeholder="' . esc_attr($field[2]) . '">';
        echo '</div>';
    }

    // Awards settings
    echo '<div class="tt-section-title">🏆 Ticino Top Awards</div>';

    echo '<div class="tt-meta-row">';
    echo '<label>Anno dell\'Award</label>';
    echo '<input type="text" name="tt_award_year" value="' . esc_attr($award_year) . '" placeholder="es. 2026 (lascia vuoto se non vincitore)">';
    echo '</div>';

    echo '<div class="tt-meta-row">';
    echo '<label>Categoria dell\'Award</label>';
    echo '<select name="tt_award_category">';
    echo '<option value="">-- Nessun Award --</option>';
    echo '<option value="food" ' . selected($award_category, 'food', false) . '>Food Excellence (🍽️)</option>';
    echo '<option value="health" ' . selected($award_category, 'health', false) . '>Health Trust (🏥)</option>';
    echo '<option value="business" ' . selected($award_category, 'business', false) . '>Business Reputation (💼)</option>';
    echo '</select>';
    echo '</div>';

    echo '<div class="tt-meta-row">';
    echo '<label>Motivazione Speciale dell\'AI (Per la pagina Awards)</label>';
    echo '<textarea name="tt_award_motivation" rows="3" placeholder="Scrivi la motivazione del premio...">' . esc_textarea($award_motivation) . '</textarea>';
    echo '</div>';
}

function tt_post_evidenza_metabox_callback($post)
{
    wp_nonce_field('tt_post_save_meta', 'tt_post_nonce');
    $in_evidenza = get_post_meta($post->ID, '_tt_post_evidenza', true);
    
    echo '<style>
        .tt-meta-row-side { margin: 10px 0; }
        .tt-meta-row-side label { font-weight: bold; display: block; margin-bottom: 5px; }
    </style>';
    
    echo '<div class="tt-meta-row-side">';
    echo '<label><input type="checkbox" name="tt_post_evidenza" value="1" ' . checked($in_evidenza, '1', false) . '> ⭐️ In Evidenza nel Magazine</label>';
    echo '<span style="font-size: 11px; color: #666; display: block; margin-top: 4px; line-height: 1.4;">Se selezionato, questo articolo verrà visualizzato come eroe principale in cima al Magazine, superando l\'ordine cronologico standard.</span>';
    echo '</div>';
}

add_action('save_post', 'tt_post_save_meta');
function tt_post_save_meta($post_id)
{
    if (!isset($_POST['tt_post_nonce']) || !wp_verify_nonce($_POST['tt_post_nonce'], 'tt_post_save_meta'))
        return;
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE)
        return;
    if (!current_user_can('edit_post', $post_id))
        return;

    $evidenza_val = isset($_POST['tt_post_evidenza']) ? '1' : '0';
    update_post_meta($post_id, '_tt_post_evidenza', $evidenza_val);
}

add_action('save_post', 'tt_azienda_save_meta');
function tt_azienda_save_meta($post_id)
{
    if (!isset($_POST['tt_azienda_nonce']) || !wp_verify_nonce($_POST['tt_azienda_nonce'], 'tt_azienda_save_meta'))
        return;
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE)
        return;
    if (!current_user_can('edit_post', $post_id))
        return;

    if (isset($_POST['tt_voto']))
        update_post_meta($post_id, '_tt_voto', sanitize_text_field($_POST['tt_voto']));
    if (isset($_POST['tt_recensioni']))
        update_post_meta($post_id, '_tt_recensioni', sanitize_text_field($_POST['tt_recensioni']));
    if (isset($_POST['tt_ai_match']))
        update_post_meta($post_id, '_tt_ai_match', sanitize_text_field($_POST['tt_ai_match']));
    if (isset($_POST['tt_ai_text']))
        update_post_meta($post_id, '_tt_ai_text', sanitize_textarea_field($_POST['tt_ai_text']));
    if (isset($_POST['tt_image']))
        update_post_meta($post_id, '_tt_image', sanitize_text_field($_POST['tt_image']));
    if (isset($_POST['tt_keywords']))
        update_post_meta($post_id, '_tt_keywords', sanitize_text_field($_POST['tt_keywords']));

    // Contatti
    if (isset($_POST['tt_website'])) {
        $website = esc_url_raw(wp_unslash($_POST['tt_website']));
        update_post_meta($post_id, '_tt_website', $website);
        $host = wp_parse_url($website, PHP_URL_HOST);
        update_post_meta($post_id, '_tt_website_host', $host ? preg_replace('/^www\./', '', strtolower($host)) : '');
    }
    if (isset($_POST['tt_localita']))
        update_post_meta($post_id, '_tt_localita', sanitize_text_field($_POST['tt_localita']));
    if (isset($_POST['tt_indirizzo']))
        update_post_meta($post_id, '_tt_indirizzo', sanitize_text_field($_POST['tt_indirizzo']));
    if (isset($_POST['tt_telefono']))
        update_post_meta($post_id, '_tt_telefono', sanitize_text_field($_POST['tt_telefono']));
    if (isset($_POST['tt_email']))
        update_post_meta($post_id, '_tt_email', sanitize_email($_POST['tt_email']));

    // Awards fields saving
    if (isset($_POST['tt_award_year']))
        update_post_meta($post_id, '_tt_award_year', sanitize_text_field($_POST['tt_award_year']));
    if (isset($_POST['tt_award_category']))
        update_post_meta($post_id, '_tt_award_category', sanitize_text_field($_POST['tt_award_category']));
    if (isset($_POST['tt_award_motivation']))
        update_post_meta($post_id, '_tt_award_motivation', sanitize_textarea_field($_POST['tt_award_motivation']));
}

add_action('save_post', 'tt_classifica_save_meta');
function tt_classifica_save_meta($post_id)
{
    if (!isset($_POST['tt_classifica_nonce']) || !wp_verify_nonce($_POST['tt_classifica_nonce'], 'tt_classifica_save_meta'))
        return;
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE)
        return;
    if (!current_user_can('edit_post', $post_id))
        return;

    if (isset($_POST['tt_classifica_categoria']))
        update_post_meta($post_id, '_tt_classifica_categoria', sanitize_text_field($_POST['tt_classifica_categoria']));
    if (isset($_POST['tt_classifica_badge']))
        update_post_meta($post_id, '_tt_classifica_badge', sanitize_text_field($_POST['tt_classifica_badge']));
    if (isset($_POST['tt_classifica_limit']))
        update_post_meta($post_id, '_tt_classifica_limit', sanitize_text_field($_POST['tt_classifica_limit']));
    if (isset($_POST['tt_classifica_affidabilita']))
        update_post_meta($post_id, '_tt_classifica_affidabilita', sanitize_text_field($_POST['tt_classifica_affidabilita']));
    if (isset($_POST['tt_classifica_valutate']))
        update_post_meta($post_id, '_tt_classifica_valutate', sanitize_text_field($_POST['tt_classifica_valutate']));
    if (isset($_POST['tt_classifica_methodology']))
        update_post_meta($post_id, '_tt_classifica_methodology', sanitize_textarea_field($_POST['tt_classifica_methodology']));

    $evidenza_val = isset($_POST['tt_classifica_evidenza']) ? '1' : '0';
    update_post_meta($post_id, '_tt_classifica_evidenza', $evidenza_val);

    $status_val = isset($_POST['tt_classifica_status']) ? '1' : '0';
    update_post_meta($post_id, '_tt_classifica_status', $status_val);
}

// Save Page Metaboxes
add_action('save_post', 'tt_page_save_meta');
function tt_page_save_meta($post_id)
{
    if (!isset($_POST['tt_chisiamo_nonce']) || !wp_verify_nonce($_POST['tt_chisiamo_nonce'], 'tt_page_save_meta')) {
        // Double check standard post/page saving compatibility
        if (!isset($_POST['tt_chisiamo_nonce']) || !wp_verify_nonce($_POST['tt_chisiamo_nonce'], 'tt_chisiamo_save_meta'))
            return;
    }
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE)
        return;
    if (!current_user_can('edit_page', $post_id))
        return;

    $fields = [
        '_tt_chisiamo_hero_title',
        '_tt_chisiamo_hero_subtitle',
        '_tt_chisiamo_manifesto_title',
        '_tt_chisiamo_manifesto_1',
        '_tt_chisiamo_manifesto_2',
        '_tt_chisiamo_manifesto_3',
        '_tt_chisiamo_manifesto_4',
        '_tt_chisiamo_side_title',
        '_tt_chisiamo_side_p1',
        '_tt_chisiamo_side_p2',
    ];

    foreach ($fields as $field) {
        if (isset($_POST[$field])) {
            update_post_meta($post_id, $field, sanitize_textarea_field($_POST[$field]));
        }
    }
}

// Metabox Callback for Chi Siamo Page
function tt_chisiamo_metabox_callback($post)
{
    $template = get_post_meta($post->ID, '_wp_page_template', true);
    if ($template !== 'template-chi-siamo.php') {
        echo '<p style="padding: 10px; margin: 0; color: #666;">Questo pannello è attivo solo per la pagina con template <strong>TT Chi Siamo</strong>.</p>';
        return;
    }

    wp_nonce_field('tt_chisiamo_save_meta', 'tt_chisiamo_nonce');

    $hero_title = get_post_meta($post->ID, '_tt_chisiamo_hero_title', true) ?: "Siamo l'osservatorio che dà voce alla qualità oggettiva.";
    $hero_subtitle = get_post_meta($post->ID, '_tt_chisiamo_hero_subtitle', true) ?: "Ticino Top nasce per risolvere un problema di fiducia. Sul web tutti dicono di essere i migliori. Noi usiamo i dati e l'intelligenza artificiale per scoprire chi lo è davvero.";
    $manifesto_title = get_post_meta($post->ID, '_tt_chisiamo_manifesto_title', true) ?: "Il Nostro Manifesto";
    $manifesto_1 = get_post_meta($post->ID, '_tt_chisiamo_manifesto_1', true) ?: "L'autorevolezza non è in vendita. I posizionamenti in classifica non possono essere sponsorizzati.";
    $manifesto_2 = get_post_meta($post->ID, '_tt_chisiamo_manifesto_2', true) ?: "Crediamo nella voce delle persone, ma esigiamo la verifica matematica dell'AI per scartare manipolazioni e bias.";
    $manifesto_3 = get_post_meta($post->ID, '_tt_chisiamo_manifesto_3', true) ?: "Trasparenza assoluta: ogni classifica deve avere una metodologia spiegata e chiara.";
    $manifesto_4 = get_post_meta($post->ID, '_tt_chisiamo_manifesto_4', true) ?: "Celebriamo le eccellenze del Ticino per incentivare l'innalzamento della qualità globale dei servizi.";
    $side_title = get_post_meta($post->ID, '_tt_chisiamo_side_title', true) ?: "Il Modello Persone + AI";
    $side_p1 = get_post_meta($post->ID, '_tt_chisiamo_side_p1', true) ?: "L'essere umano valuta l'emozione, l'atmosfera e la cortesia. L'AI analizza la frequenza di queste valutazioni su migliaia di campioni nel tempo.";
    $side_p2 = get_post_meta($post->ID, '_tt_chisiamo_side_p2', true) ?: "Questa sinergia elimina il \"giudizio di pancia\" del singolo recensore arrabbiato e le \"recensioni perfette\" sospette, lasciando emergere la vera identità reputazionale di un brand.";

    echo '<style>
        .tt-meta-row { margin-bottom: 20px; } 
        .tt-meta-row label { display: block; font-weight: bold; margin-bottom: 8px; font-size: 14px; } 
        .tt-meta-row input[type="text"], .tt-meta-row select { width: 100%; max-width: 600px; padding: 6px 10px; }
        .tt-meta-row textarea { width: 100%; max-width: 800px; padding: 10px; }
        .tt-meta-desc { font-size: 12px; color: #666; margin-top: 4px; display: block; }
        .tt-section-title { font-size: 16px; font-weight: bold; margin: 30px 0 15px 0; border-bottom: 1px solid #ccc; padding-bottom: 8px; color: #1a2942; }
    </style>';

    echo '<div class="tt-section-title">✨ Sezione Hero (Intestazione)</div>';
    echo '<div class="tt-meta-row">';
    echo '<label>Titolo Principale (Hero Title)</label>';
    echo '<input type="text" name="_tt_chisiamo_hero_title" value="' . esc_attr($hero_title) . '" style="width: 100%; max-width: 600px;">';
    echo '</div>';

    echo '<div class="tt-meta-row">';
    echo '<label>Sottotitolo Hero (Hero Subtitle)</label>';
    echo '<textarea name="_tt_chisiamo_hero_subtitle" rows="3" style="width: 100%; max-width: 800px;">' . esc_textarea($hero_subtitle) . '</textarea>';
    echo '</div>';

    echo '<div class="tt-section-title">📜 Sezione Manifesto</div>';
    echo '<div class="tt-meta-row">';
    echo '<label>Titolo Sezione Manifesto</label>';
    echo '<input type="text" name="_tt_chisiamo_manifesto_title" value="' . esc_attr($manifesto_title) . '" style="width: 100%; max-width: 600px;">';
    echo '</div>';

    echo '<div class="tt-meta-row">';
    echo '<label>Punto 1 del Manifesto</label>';
    echo '<textarea name="_tt_chisiamo_manifesto_1" rows="2" style="width: 100%; max-width: 800px;">' . esc_textarea($manifesto_1) . '</textarea>';
    echo '</div>';

    echo '<div class="tt-meta-row">';
    echo '<label>Punto 2 del Manifesto</label>';
    echo '<textarea name="_tt_chisiamo_manifesto_2" rows="2" style="width: 100%; max-width: 800px;">' . esc_textarea($manifesto_2) . '</textarea>';
    echo '</div>';

    echo '<div class="tt-meta-row">';
    echo '<label>Punto 3 del Manifesto</label>';
    echo '<textarea name="_tt_chisiamo_manifesto_3" rows="2" style="width: 100%; max-width: 800px;">' . esc_textarea($manifesto_3) . '</textarea>';
    echo '</div>';

    echo '<div class="tt-meta-row">';
    echo '<label>Punto 4 del Manifesto</label>';
    echo '<textarea name="_tt_chisiamo_manifesto_4" rows="2" style="width: 100%; max-width: 800px;">' . esc_textarea($manifesto_4) . '</textarea>';
    echo '</div>';

    echo '<div class="tt-section-title">⚙️ Box Laterale "Modello Persone + AI"</div>';
    echo '<div class="tt-meta-row">';
    echo '<label>Titolo Box</label>';
    echo '<input type="text" name="_tt_chisiamo_side_title" value="' . esc_attr($side_title) . '" style="width: 100%; max-width: 600px;">';
    echo '</div>';

    echo '<div class="tt-meta-row">';
    echo '<label>Paragrafo 1</label>';
    echo '<textarea name="_tt_chisiamo_side_p1" rows="3" style="width: 100%; max-width: 800px;">' . esc_textarea($side_p1) . '</textarea>';
    echo '</div>';

    echo '<div class="tt-meta-row">';
    echo '<label>Paragrafo 2</label>';
    echo '<textarea name="_tt_chisiamo_side_p2" rows="3" style="width: 100%; max-width: 800px;">' . esc_textarea($side_p2) . '</textarea>';
    echo '</div>';
}

// Temporary Mock Data Importer
add_action('admin_init', 'tt_import_mock_data_once', 10);
function tt_import_mock_data_once()
{
    // Aziende dimostrative con voti e recensioni inventati: solo in sviluppo, mai in produzione.
    // Per importarle in locale: define('TT_DEMO_DATA', true); in wp-config.php
    if (!defined('TT_DEMO_DATA') || !TT_DEMO_DATA)
        return;
    if (get_option('tt_mock_imported') == '6')
        return;

    $mocks = [
        [
            'title' => 'Ristorante LagoBlu',
            'cat' => 'Ristorazione & Locali',
            'voto' => '4.9',
            'recensioni' => '1.248',
            'match' => '96',
            'testo' => "L'analisi delle recensioni evidenzia una forte costanza nella soddisfazione clienti. Il ristorante viene frequentemente menzionato per l'eccellente rapporto qualità-prezzo e l'atmosfera romantica.",
            'image' => tt_get_brand_image_url('placeholder-restaurant.jpg'),
            'keywords' => 'ristorante, lago, romantico, pesce, cena',
            'award_year' => '2026',
            'award_cat' => 'food',
            'award_motivation' => "Eletto per la straordinaria costanza nella qualità culinaria, le recensioni impeccabili e l'atmosfera romantica classica sul lago."
        ],
        [
            'title' => 'Grotto Antico',
            'cat' => 'Ristorazione & Locali',
            'voto' => '4.8',
            'recensioni' => '654',
            'match' => '94',
            'testo' => "Grotto storico del Ticino, noto per l'atmosfera rustica ma elegante e il calore del camino. Altamente raccomandato per cene intime.",
            'image' => tt_get_brand_image_url('placeholder-cafe.jpg'),
            'keywords' => 'grotto, camino, rustico, locale, cena',
            'award_year' => '',
            'award_cat' => '',
            'award_motivation' => ''
        ],
        [
            'title' => 'Osteria del Ponte',
            'cat' => 'Ristorazione & Locali',
            'voto' => '4.7',
            'recensioni' => '320',
            'match' => '91',
            'testo' => "Cucina tradicional ticinese rivisitata in chiave moderna. Piatti curati nei minimi dettagli e servizio impeccabile.",
            'image' => tt_get_brand_image_url('placeholder-restaurant.jpg'),
            'keywords' => 'osteria, ponte, carne, risotto, pranzo',
            'award_year' => '',
            'award_cat' => '',
            'award_motivation' => ''
        ],
        [
            'title' => 'Clinica Sorriso Lugano',
            'cat' => 'Salute & Medicina',
            'voto' => '4.9',
            'recensioni' => '856',
            'match' => '99',
            'testo' => "Elevata affidabilità percepita e macchinari all'avanguardia. Nessuna recensione sospetta o incoerente nel tempo.",
            'image' => tt_get_brand_image_url('placeholder-clinic.jpg'),
            'keywords' => 'clinica, dentista, dentisti, igiene dentale, salute, cura',
            'award_year' => '2026',
            'award_cat' => 'health',
            'award_motivation' => "Massima affidabilità clinica riscontrata nel territorio, eccellente livello di igiene e costanza nella soddisfazione dei pazienti."
        ],
        [
            'title' => 'Medical Beauty Ticino',
            'cat' => 'Salute & Medicina',
            'voto' => '4.8',
            'recensioni' => '412',
            'match' => '95',
            'testo' => "Centro d'eccellenza per la medicina estetica e la cura della persona. Staff altamente qualificato e trattamenti personalizzati.",
            'image' => tt_get_brand_image_url('placeholder-clinic.jpg'),
            'keywords' => 'medicina, estetica, bellezza, trattamenti, cura',
            'award_year' => '',
            'award_cat' => '',
            'award_motivation' => ''
        ],
        [
            'title' => 'Dental Center Locarno',
            'cat' => 'Salute & Medicina',
            'voto' => '4.6',
            'recensioni' => '289',
            'match' => '89',
            'testo' => "Studio dentistico all'avanguardia a Locarno. Massima attenzione all'igiene e al comfort del paziente.",
            'image' => tt_get_brand_image_url('placeholder-clinic.jpg'),
            'keywords' => 'studio, dentistico, locarno, denti, ortodonzia',
            'award_year' => '',
            'award_cat' => '',
            'award_motivation' => ''
        ],
        [
            'title' => 'Hotel Vista Lago',
            'cat' => 'Hotel & Alloggi',
            'voto' => '4.7',
            'recensioni' => '2.104',
            'match' => '92',
            'testo' => "Viste mozzafiato e colazione eccellente citata frequentemente. Le poche critiche riguardano dettagli minimi di logistica.",
            'image' => tt_get_brand_image_url('placeholder-scenic.jpg'),
            'keywords' => 'hotel, albergo, lago, vacanze, vista, b&b',
            'award_year' => '',
            'award_cat' => '',
            'award_motivation' => ''
        ],
        [
            'title' => 'Boutique Hotel Splendide',
            'cat' => 'Hotel & Alloggi',
            'voto' => '4.9',
            'recensioni' => '1.480',
            'match' => '97',
            'testo' => "Soggiorno da sogno nel cuore del Ticino. Servizio impeccabile, interiors dal design raffinato e comfort senza compromessi.",
            'image' => tt_get_brand_image_url('placeholder-boutique.jpg'),
            'keywords' => 'boutique, splendide, lusso, suite, centro',
            'award_year' => '2026',
            'award_cat' => 'business',
            'award_motivation' => "Riconoscimento premium per l'eccezionale ospitalità, design iconico e le recensioni dei clienti con costanza e affidabilità insuperabili."
        ],
        [
            'title' => 'Albergo Bellavista',
            'cat' => 'Hotel & Alloggi',
            'voto' => '4.5',
            'recensioni' => '540',
            'match' => '88',
            'testo' => "Immerso nel verde delle colline ticinesi. Un'oasi di pace per rilassarsi, con terrazza panoramica eccezionale.",
            'image' => tt_get_brand_image_url('placeholder-office.jpg'),
            'keywords' => 'albergo, bellavista, verde, colline, relax',
            'award_year' => '',
            'award_cat' => '',
            'award_motivation' => ''
        ]
    ];

    foreach ($mocks as $mock) {
        $existing = get_page_by_title($mock['title'], OBJECT, 'azienda');
        if ($existing) {
            $post_id = $existing->ID;
            update_post_meta($post_id, '_tt_voto', $mock['voto']);
            update_post_meta($post_id, '_tt_recensioni', $mock['recensioni']);
            update_post_meta($post_id, '_tt_ai_match', $mock['match']);
            update_post_meta($post_id, '_tt_ai_text', $mock['testo']);
            update_post_meta($post_id, '_tt_image', $mock['image']);
            update_post_meta($post_id, '_tt_keywords', $mock['keywords']);

            // Awards details
            update_post_meta($post_id, '_tt_award_year', $mock['award_year']);
            update_post_meta($post_id, '_tt_award_category', $mock['award_cat']);
            update_post_meta($post_id, '_tt_award_motivation', $mock['award_motivation']);
        } else {
            $post_id = wp_insert_post([
                'post_title' => $mock['title'],
                'post_type' => 'azienda',
                'post_status' => 'publish',
                'meta_input' => [
                    '_tt_voto' => $mock['voto'],
                    '_tt_recensioni' => $mock['recensioni'],
                    '_tt_ai_match' => $mock['match'],
                    '_tt_ai_text' => $mock['testo'],
                    '_tt_image' => $mock['image'],
                    '_tt_keywords' => $mock['keywords'],
                    '_tt_award_year' => $mock['award_year'],
                    '_tt_award_category' => $mock['award_cat'],
                    '_tt_award_motivation' => $mock['award_motivation'],
                ]
            ]);

            if ($post_id) {
                wp_insert_term($mock['cat'], 'categoria_azienda');
                wp_set_object_terms($post_id, $mock['cat'], 'categoria_azienda');
            }
        }
    }

    update_option('tt_mock_imported', '6');
}

// Temporary Content Generator for testing
add_action('admin_init', 'tt_generate_all_content_once', 20);
function tt_generate_all_content_once()
{
    if (get_option('tt_all_content_generated') == '6')
        return;

    $pages = [
        'TopScan' => 'template-topscan.php',
        'Awards' => 'template-awards.php',
        'Magazine' => 'template-blog.php',
        'Candidati' => 'template-candidati.php',
        'Chi Siamo' => 'template-chi-siamo.php',
        'Categorie' => 'template-categorie-hub.php',
    ];

    foreach ($pages as $title => $template) {
        $existing = get_page_by_title($title, OBJECT, 'page');
        if (!$existing) {
            $page_id = wp_insert_post([
                'post_title' => $title,
                'post_type' => 'page',
                'post_status' => 'publish',
            ]);
            if ($page_id && !is_wp_error($page_id)) {
                update_post_meta($page_id, '_wp_page_template', $template);
            }
        } else {
            update_post_meta($existing->ID, '_wp_page_template', $template);
        }
    }

    $classifiche = [
        [
            'title' => 'I 10 Migliori Ristoranti Romantici del Ticino',
            'desc' => 'Scopri le location più intime e suggestive per una cena indimenticabile sul lago. Classifica aggiornata in tempo reale.',
            'image' => tt_get_brand_image_url('category-food.jpg'),
            'badge' => 'Food & Dining',
            'cat_name' => 'Ristorazione & Locali',
            'methodology' => "L'AI di Ticino Top ha analizzato le menzioni legate a 'atmosfera', 'coppia', 'luci soffuse' e 'servizio intimo' scartando le recensioni incoerenti o non verificabili. Il risultato è una classifica focalizzata sull'esperienza reale."
        ],
        [
            'title' => 'Locarno Film Festival: Guida ai Boutique Hotel',
            'desc' => 'Dove alloggiare durante il festival: eleganza, servizio impeccabile e design senza compromessi.',
            'image' => tt_get_brand_image_url('category-experience.jpg'),
            'badge' => 'Hotel & Alloggi',
            'cat_name' => 'Hotel & Alloggi',
            'methodology' => "Abbiamo valutato i boutique hotel del locarnese analizzando i punteggi di accoglienza, la vicinanza alla Piazza Grande e la qualità del design interno recensito dai viaggiatori."
        ]
    ];

    foreach ($classifiche as $mock) {
        $existing = get_page_by_title($mock['title'], OBJECT, 'classifica');
        if (!$existing) {
            $post_id = wp_insert_post([
                'post_title' => $mock['title'],
                'post_content' => $mock['desc'],
                'post_excerpt' => $mock['desc'],
                'post_type' => 'classifica',
                'post_status' => 'publish',
            ]);
        } else {
            $post_id = $existing->ID;
            wp_update_post([
                'ID' => $post_id,
                'post_content' => $mock['desc'],
                'post_excerpt' => $mock['desc'],
            ]);
        }

        if ($post_id) {
            update_post_meta($post_id, '_tt_image', $mock['image']);
            update_post_meta($post_id, '_tt_classifica_badge', $mock['badge']);
            update_post_meta($post_id, '_tt_classifica_methodology', $mock['methodology']);
            update_post_meta($post_id, '_tt_classifica_affidabilita', '96%');
            update_post_meta($post_id, '_tt_classifica_valutate', '45');
            update_post_meta($post_id, '_tt_classifica_limit', '10');

            update_post_meta($post_id, '_tt_classifica_evidenza', '1');

            // Link to category
            $term = get_term_by('name', $mock['cat_name'], 'categoria_azienda');
            if (!$term || is_wp_error($term)) {
                $inserted = wp_insert_term($mock['cat_name'], 'categoria_azienda');
                if (!is_wp_error($inserted)) {
                    $term_id = $inserted['term_id'];
                } else {
                    $term_id = 0;
                }
            } else {
                $term_id = $term->term_id;
            }
            if ($term_id) {
                update_post_meta($post_id, '_tt_classifica_categoria', $term_id);
            }
        }
    }

    // Pre-populate Chi Siamo Page custom fields
    $chi_siamo_page = get_page_by_title('Chi Siamo', OBJECT, 'page');
    if ($chi_siamo_page) {
        $chi_siamo_id = $chi_siamo_page->ID;
        update_post_meta($chi_siamo_id, '_tt_chisiamo_hero_title', "Siamo l'osservatorio che dà voce alla qualità oggettiva.");
        update_post_meta($chi_siamo_id, '_tt_chisiamo_hero_subtitle', "Ticino Top nasce per risolvere un problema di fiducia. Sul web tutti dicono di essere i migliori. Noi usiamo i dati e l'intelligenza artificiale per scoprire chi lo è davvero.");
        update_post_meta($chi_siamo_id, '_tt_chisiamo_manifesto_title', "Il Nostro Manifesto");
        update_post_meta($chi_siamo_id, '_tt_chisiamo_manifesto_1', "L'autorevolezza non è in vendita. I posizionamenti in classifica non possono essere sponsorizzati.");
        update_post_meta($chi_siamo_id, '_tt_chisiamo_manifesto_2', "Crediamo nella voce delle persone, ma esigiamo la verifica matematica dell'AI per scartare manipolazioni e bias.");
        update_post_meta($chi_siamo_id, '_tt_chisiamo_manifesto_3', "Trasparenza assoluta: ogni classifica deve avere una metodologia spiegata e chiara.");
        update_post_meta($chi_siamo_id, '_tt_chisiamo_manifesto_4', "Celebriamo le eccellenze del Ticino per incentivare l'innalzamento della qualità globale dei servizi.");
        update_post_meta($chi_siamo_id, '_tt_chisiamo_side_title', "Il Modello Persone + AI");
        update_post_meta($chi_siamo_id, '_tt_chisiamo_side_p1', "L'essere umano valuta l'emozione, l'atmosfera e la cortesia. L'AI analizza la frequenza di queste valutazioni su migliaia di campioni nel tempo.");
        update_post_meta($chi_siamo_id, '_tt_chisiamo_side_p2', "Questa sinergia elimina il \"giudizio di pancia\" del singolo recensore arrabbiato e le \"recensioni perfette\" sospette, lasciando emergere la vera identità reputazionale di un brand.");
    }

    $posts = [
        'Perché le recensioni online non bastano più (e come l\'AI cambia le regole)',
        'Come riconoscere una recensione falsa nel 2026',
    ];

    foreach ($posts as $title) {
        if (!get_page_by_title($title, OBJECT, 'post')) {
            wp_insert_post([
                'post_title' => $title,
                'post_type' => 'post',
                'post_status' => 'publish',
                'post_content' => 'Questo è un articolo di prova generato automaticamente. Presto pubblicheremo i veri contenuti editoriali della piattaforma Ticino Top.',
            ]);
        }
    }

    update_option('tt_all_content_generated', '6');
}

// -----------------------------------------------------------------------------
// Visualizzazione e Gestione dello Stato Visibile (Mostra/Nascondi) in edit.php
// -----------------------------------------------------------------------------

// Aggiunge la colonna "Visibile" nella lista delle Classifiche nel Backend
add_filter('manage_classifica_posts_columns', 'tt_set_classifica_columns');
function tt_set_classifica_columns($columns) {
    $new_columns = [];
    foreach ($columns as $key => $title) {
        if ($key === 'date') {
            $new_columns['tt_classifica_status'] = 'Visibile';
        }
        $new_columns[$key] = $title;
    }
    return $new_columns;
}

// Renderizza lo switch/interruttore AJAX per la colonna "Visibile"
add_action('manage_classifica_posts_custom_column', 'tt_render_classifica_custom_column', 10, 2);
function tt_render_classifica_custom_column($column, $post_id) {
    if ($column === 'tt_classifica_status') {
        $status = get_post_meta($post_id, '_tt_classifica_status', true);
        if ($status === '') {
            $status = '1'; // Default visibile
        }
        
        ?>
        <label class="tt-switch-ajax" style="position: relative; display: inline-block; width: 44px; height: 24px; vertical-align: middle;">
            <input type="checkbox" class="tt-status-toggle" data-post-id="<?php echo $post_id; ?>" <?php checked($status, '1'); ?> style="opacity: 0; width: 0; height: 0; margin: 0;">
            <span class="tt-slider-ajax" style="position: absolute; cursor: pointer; top: 0; left: 0; right: 0; bottom: 0; background-color: #cbd5e1; transition: .3s; border-radius: 24px; border: 1px solid #cbd5e1;"></span>
        </label>
        <?php
    }
}

// Aggiunge stili personalizzati per l'interruttore iOS-style nell'Admin Head
add_action('admin_head', 'tt_classifica_admin_css');
function tt_classifica_admin_css() {
    ?>
    <style>
        .column-tt_classifica_status { width: 100px; text-align: center; vertical-align: middle !important; }
        .tt-switch-ajax {
            position: relative;
            display: inline-block;
            width: 44px;
            height: 24px;
            vertical-align: middle;
        }
        .tt-switch-ajax input {
            opacity: 0;
            width: 0;
            height: 0;
        }
        .tt-slider-ajax {
            position: absolute;
            cursor: pointer;
            top: 0; left: 0; right: 0; bottom: 0;
            background-color: #cbd5e1;
            transition: .3s;
            border-radius: 24px;
            border: 1px solid #cbd5e1;
        }
        .tt-slider-ajax:before {
            position: absolute;
            content: "";
            height: 16px;
            width: 16px;
            left: 3px;
            bottom: 3px;
            background-color: white;
            transition: .3s;
            border-radius: 50%;
            box-shadow: 0 1px 3px rgba(0,0,0,0.15);
        }
        .tt-switch-ajax input:checked + .tt-slider-ajax {
            background-color: #10b981;
            border-color: #059669;
        }
        .tt-switch-ajax input:checked + .tt-slider-ajax:before {
            transform: translateX(20px);
        }
        .tt-switch-ajax input:disabled + .tt-slider-ajax {
            opacity: 0.6;
            cursor: not-allowed;
        }
    </style>
    <?php
}

// Codice JavaScript per gestire il toggle via AJAX con animazione visiva premium
add_action('admin_footer', 'tt_classifica_admin_js');
function tt_classifica_admin_js() {
    global $pagenow, $post_type;
    if ($pagenow === 'edit.php' && $post_type === 'classifica') {
        ?>
        <script>
        jQuery(document).ready(function($) {
            $('.tt-status-toggle').on('change', function() {
                var $checkbox = $(this);
                var postId = $checkbox.data('post-id');
                var status = $checkbox.is(':checked') ? '1' : '0';
                
                $checkbox.prop('disabled', true);
                
                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'tt_toggle_classifica_status',
                        post_id: postId,
                        status: status,
                        nonce: '<?php echo wp_create_nonce("tt_classifica_status_nonce"); ?>'
                    },
                    success: function(response) {
                        $checkbox.prop('disabled', false);
                        if (response.success) {
                            var $row = $checkbox.closest('tr');
                            var originalBg = $row.css('background-color');
                            $row.css('background-color', status === '1' ? '#ecfdf5' : '#fff5f5');
                            setTimeout(function() {
                                $row.css('background-color', originalBg);
                            }, 600);
                        } else {
                            alert('Errore: ' + (response.data || 'Impossibile aggiornare lo stato.'));
                            $checkbox.prop('checked', status === '0');
                        }
                    },
                    error: function() {
                        $checkbox.prop('disabled', false);
                        alert('Errore di connessione al server.');
                        $checkbox.prop('checked', status === '0');
                    }
                });
            });
        });
        </script>
        <?php
    }
}

// Ricevitore AJAX dell'azione per salvare lo stato
add_action('wp_ajax_tt_toggle_classifica_status', 'tt_toggle_classifica_status_handler');
function tt_toggle_classifica_status_handler() {
    check_ajax_referer('tt_classifica_status_nonce', 'nonce');
    
    if (!current_user_can('edit_posts')) {
        wp_send_json_error('Permessi insufficienti.');
    }
    
    $post_id = isset($_POST['post_id']) ? intval($_POST['post_id']) : 0;
    $status = isset($_POST['status']) ? sanitize_text_field($_POST['status']) : '0';
    
    if (!$post_id || get_post_type($post_id) !== 'classifica') {
        wp_send_json_error('ID classifica non valido.');
    }
    
    update_post_meta($post_id, '_tt_classifica_status', $status);
    wp_send_json_success('Stato aggiornato con successo.');
}

// -----------------------------------------------------------------------------
// Filtro Query per nascondere le Classifiche disattivate sul Frontend
// -----------------------------------------------------------------------------
add_action('pre_get_posts', 'tt_filter_classifiche_query');
function tt_filter_classifiche_query($query) {
    if (is_admin()) {
        return;
    }
    
    $post_types = $query->get('post_type');
    $is_classifica_query = false;
    
    if ($post_types === 'classifica') {
        $is_classifica_query = true;
    } elseif (is_array($post_types) && in_array('classifica', $post_types)) {
        $is_classifica_query = true;
    }
    
    if ($is_classifica_query) {
        $meta_query = $query->get('meta_query') ?: [];
        $meta_query[] = [
            'relation' => 'OR',
            [
                'key' => '_tt_classifica_status',
                'compare' => 'NOT EXISTS',
            ],
            [
                'key' => '_tt_classifica_status',
                'value' => '0',
                'compare' => '!=',
            ]
        ];
        $query->set('meta_query', $meta_query);
    }
}

/**
 * Posizione reale dell'azienda nella sua categoria principale, ordinata per _tt_voto.
 * Ritorna array('position' => int, 'category' => string) oppure null se manca il voto.
 */
function tt_azienda_rank($post_id)
{
    $voto = get_post_meta($post_id, '_tt_voto', true);
    $terms = get_the_terms($post_id, 'categoria_azienda');
    if ($voto === '' || !is_numeric(str_replace(',', '.', $voto)) || !$terms || is_wp_error($terms)) {
        return null;
    }

    $cache_key = 'tt_rank_' . $post_id . '_' . md5($voto . '|' . $terms[0]->term_id);
    $cached = wp_cache_get($cache_key, 'ticinotop');
    if ($cached !== false) {
        return $cached;
    }

    $better = get_posts([
        'post_type'      => 'azienda',
        'post_status'    => 'publish',
        'posts_per_page' => -1,
        'fields'         => 'ids',
        'no_found_rows'  => true,
        'tax_query'      => [['taxonomy' => 'categoria_azienda', 'terms' => $terms[0]->term_id]],
        'meta_query'     => [['key' => '_tt_voto', 'value' => (float) str_replace(',', '.', $voto), 'compare' => '>', 'type' => 'DECIMAL(4,2)']],
    ]);

    $rank = ['position' => count($better) + 1, 'category' => $terms[0]->name];
    wp_cache_set($cache_key, $rank, 'ticinotop', HOUR_IN_SECONDS);
    return $rank;
}

function tt_score_label($value)
{
    $value = intval($value);
    if ($value >= 85) return 'Eccellente';
    if ($value >= 70) return 'Buona';
    if ($value >= 55) return 'Discreta';
    return 'Da migliorare';
}

