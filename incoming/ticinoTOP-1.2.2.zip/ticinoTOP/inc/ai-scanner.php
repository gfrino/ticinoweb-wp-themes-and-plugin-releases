<?php
/**
 * Ticino Top - Motore di Scansione AI
 * Gestisce l'interfaccia di backend per simulare/eseguire lo scraping e l'analisi AI delle aziende.
 */

require_once __DIR__ . '/ai-company-scanner.php';

// 1. Aggiungiamo la pagina nel menu di amministrazione
add_action('admin_menu', 'tt_ai_scanner_menu');
function tt_ai_scanner_menu() {
    // Menu Principale
    add_menu_page(
        'Scanner AI',          
        'Scanner AI',          
        'manage_options',      
        'tt-ai-scanner',       
        'tt_ai_scanner_page',  
        'dashicons-superhero', 
        7                     
    );

    // Sottomenu: Esegui Scansione (uguale al principale)
    add_submenu_page(
        'tt-ai-scanner',
        'Esegui Scansione',
        'Esegui Scansione',
        'manage_options',
        'tt-ai-scanner',
        'tt_ai_scanner_page'
    );

    // Sottomenu: Logs
    add_submenu_page(
        'tt-ai-scanner',
        'Registro Logs',
        'Registro Logs',
        'manage_options',
        'tt-ai-scanner-logs',
        'tt_ai_scanner_logs_page'
    );

    // Sottomenu: Impostazioni
    add_submenu_page(
        'tt-ai-scanner',
        'Impostazioni',
        'Impostazioni',
        'manage_options',
        'tt-theme-settings',
        'tt_theme_settings_page'
    );
}

// 2. Creiamo l'interfaccia della pagina admin principale (Solo Form)
function tt_ai_scanner_page() {
    ?>
    <div class="wrap">
        <h1 style="display: flex; align-items: center; gap: 10px;">
            <span class="dashicons dashicons-superhero" style="font-size: 28px; width: 28px; height: 28px; color: #D4AF37;"></span> 
            Motore di Scansione Reputazionale AI
        </h1>
        <p>Scansiona il sito web di un'azienda e pubblicala nella sezione Aziende con tutti i campi compilati, oppure analizza una pagina elenco per alimentare il benchmark di una categoria.</p>

        <?php tt_company_render_published_notice(); ?>

        <?php if (!empty($_GET['company_scan'])) : ?>
            <?php tt_company_render_preview(sanitize_text_field(wp_unslash($_GET['company_scan']))); ?>
        </div>
        <?php return; endif; ?>
        
        <?php if (isset($_GET['scan']) && $_GET['scan'] == 'success') : ?>
            <div class="notice notice-success is-dismissible" style="border-left-color: #D4AF37;">
                <p><strong>Scansione completata con successo!</strong> L'Intelligenza Artificiale ha elaborato i dati estratti dal sito e ha aggiornato il Benchmark della Categoria selezionata.</p>
            </div>
        <?php endif; ?>

        <div style="background: #fff; padding: 24px; border: 1px solid #ccd0d4; border-radius: 8px; max-width: 600px; margin-top: 20px; box-shadow: 0 4px 12px rgba(0,0,0,0.05);">
            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                <input type="hidden" name="action" value="tt_run_ai_scan">
                <?php wp_nonce_field('tt_ai_scan_nonce', 'tt_nonce'); ?>
                
                <h3 style="margin-top: 0;">1. Tipo di Scansione</h3>
                <p style="margin-bottom: 24px;">
                    <label style="display:block; margin-bottom:6px;"><input type="radio" name="scan_mode" value="sito" checked> <strong>Sito web di un'azienda</strong> &rarr; anteprima della scheda e pubblicazione in Aziende</label>
                    <label style="display:block;"><input type="radio" name="scan_mode" value="elenco"> Pagina elenco con più aziende &rarr; solo benchmark della categoria</label>
                </p>

                <h3>2. Seleziona la Categoria (Benchmark)</h3>
                <p class="description">Per il sito aziendale puoi lasciarla scegliere all'AI e correggerla nell'anteprima. Per la pagina elenco è obbligatoria.</p>
                <select name="category_id" style="width: 100%; padding: 8px; margin-bottom: 24px;">
                    <option value="">-- Lascia scegliere all'AI --</option>
                    <?php
                    $terms = get_terms(array('taxonomy' => 'categoria_azienda', 'hide_empty' => false));
                    if (!is_wp_error($terms)) {
                        foreach ($terms as $term) {
                            echo '<option value="' . esc_attr($term->term_id) . '">' . esc_html($term->name) . '</option>';
                        }
                    }
                    ?>
                </select>

                <h3>3. Link Sorgente (URL)</h3>
                <p class="description">L'indirizzo del sito aziendale (es. https://ticinoweb.com): vengono lette la home e le pagine contatti, chi siamo e servizi. <strong style="color:#d63638;">Attenzione:</strong> siti grossi come TripAdvisor o Google spesso bloccano lo scraping.</p>
                <input type="url" name="target_url" placeholder="https://..." style="width: 100%; padding: 8px; margin-bottom: 24px;">

                <h3 style="border-top: 1px dashed #ccd0d4; padding-top: 24px;">Testo Manuale (Bypass Anti-Bot)</h3>
                <p class="description">Se lo scraping automatico fallisce, fai "Seleziona Tutto" (CTRL+A) sulla pagina web e incolla il testo qui. <strong style="color:#0073aa;">Consiglio:</strong> Compila comunque il campo "Link Sorgente" qui sopra così l'URL rimarrà salvato nello storico dei tuoi Log!</p>
                <textarea name="manual_text" rows="5" placeholder="Incolla qui tutto il testo del sito..." style="width: 100%; padding: 8px; margin-bottom: 24px;"></textarea>

                <h3>4. Avvia Scraping & AI</h3>
                <?php if (tt_ai_get_openai_key()) : ?>
                    <p class="description" style="color:#008a20;"><span class="dashicons dashicons-yes"></span> Chiave API OpenAI configurata (<a href="<?php echo esc_url(admin_url('admin.php?page=tt-theme-settings')); ?>">Impostazioni</a>).</p>
                <?php else : ?>
                    <p class="description" style="color:#d63638;"><span class="dashicons dashicons-warning"></span> Chiave API OpenAI mancante: inseriscila in <a href="<?php echo esc_url(admin_url('admin.php?page=tt-theme-settings')); ?>">Impostazioni</a>.</p>
                <?php endif; ?>
                <button type="submit" class="button button-primary" style="background: #D4AF37; border-color: #b5952f; color: #fff; padding: 8px 24px; font-size: 16px; border-radius: 4px; display: flex; align-items: center; gap: 8px;">
                    <span class="dashicons dashicons-update"></span> Inizia Elaborazione AI
                </button>
            </form>
        </div>

        <div style="max-width: 600px; margin-top: 40px; padding: 20px; background: #f0f0f1; border-left: 4px solid #0073aa;">
            <h4>Come funziona dietro le quinte?</h4>
            <ol>
                <li><strong>Scansione del sito:</strong> il bot legge la home e fino a 4 pagine chiave (contatti, chi siamo, servizi) e raccoglie dati strutturati, telefoni, email, social e immagini.</li>
                <li><strong>Analisi AI (OpenAI):</strong> GPT compila la scheda (descrizione, analisi, località, contatti, keywords, categoria, punteggi) senza inventare dati mancanti.</li>
                <li><strong>Anteprima:</strong> controlli e correggi i campi, scegli l'immagine.</li>
                <li><strong>Pubblicazione:</strong> la scheda viene creata (o aggiornata, se il sito è già presente) nella sezione Aziende e i punteggi alimentano il benchmark della categoria.</li>
            </ol>
        </div>
    </div>
    <?php
}

// 2.5 Pagina dei Logs
function tt_ai_scanner_logs_page() {
    // GESTIONE ELIMINAZIONE LOG
    if (isset($_GET['delete_log']) && current_user_can('manage_options') && check_admin_referer('tt_delete_log_' . intval($_GET['delete_log']))) {
        $index = intval($_GET['delete_log']);
        $logs = get_option('tt_ai_scan_logs', array());
        if (isset($logs[$index])) {
            unset($logs[$index]);
            update_option('tt_ai_scan_logs', array_values($logs), false);
            echo '<div class="notice notice-success is-dismissible" style="border-left-color: #d63638;"><p>Dati di scraping eliminati dal server.</p></div>';
        }
    }
    ?>
    <div class="wrap tt-logs-container">
        <h1 style="display: flex; align-items: center; gap: 10px; margin-bottom: 24px; font-size: 28px; font-weight: 600; color: #1e293b;">
            <span class="dashicons dashicons-analytics" style="font-size: 32px; width: 32px; height: 32px; color: #D4AF37;"></span> 
            Log Scansioni AI
        </h1>
        
        <style>
            .tt-logs-container { max-width: 1200px; margin-top: 20px; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; }
            .tt-log-card { background: #fff; border: 1px solid #e2e8f0; border-radius: 12px; margin-bottom: 16px; display: flex; align-items: center; justify-content: space-between; padding: 20px 24px; box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05); transition: all 0.2s ease; }
            .tt-log-card:hover { box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1); border-color: #cbd5e1; transform: translateY(-2px); }
            .tt-log-meta { display: flex; align-items: center; gap: 24px; flex: 1; min-width: 0; padding-right: 20px; }
            .tt-log-date { font-size: 13px; color: #64748b; width: 130px; flex-shrink: 0; font-weight: 500; }
            .tt-log-cat { display: inline-flex; align-items: center; gap: 6px; background: #f8fafc; border: 1px solid #e2e8f0; color: #334155; padding: 6px 14px; border-radius: 20px; font-size: 13px; font-weight: 600; width: max-content; white-space: nowrap; flex-shrink: 0; }
            .tt-log-url { font-size: 14px; color: #3b82f6; text-decoration: none; display: flex; align-items: center; gap: 6px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
            .tt-log-url:hover { color: #2563eb; text-decoration: underline; }
            .tt-log-scores { display: flex; gap: 12px; }
            .tt-score-badge { display: flex; flex-direction: column; align-items: center; justify-content: center; background: #fff8e6; border: 1px solid #fde68a; color: #92400e; width: 56px; height: 56px; border-radius: 12px; }
            .tt-score-badge span { font-size: 9px; text-transform: uppercase; letter-spacing: 0.5px; font-weight: 600; opacity: 0.8; }
            .tt-score-badge strong { font-size: 18px; line-height: 1.1; margin-top: 4px; font-weight: 700; }
            .tt-log-actions { margin-left: 32px; display: flex; flex-direction: column; gap: 8px; }
            .tt-btn-delete { background: #fff; color: #ef4444; border: 1px solid #fecaca; padding: 8px 16px; border-radius: 8px; font-size: 13px; font-weight: 600; text-decoration: none; transition: all 0.2s; cursor: pointer; text-align: center; }
            .tt-btn-delete:hover { background: #fee2e2; border-color: #f87171; color: #b91c1c; }
            .tt-btn-expand { background: #f8fafc; color: #475569; border: 1px solid #cbd5e1; padding: 8px 16px; border-radius: 8px; font-size: 13px; font-weight: 600; cursor: pointer; transition: all 0.2s; text-align: center; }
            .tt-btn-expand:hover { background: #f1f5f9; color: #0f172a; }
            .tt-empty-state { text-align: center; padding: 60px 20px; background: #fff; border: 1px dashed #cbd5e1; border-radius: 12px; color: #64748b; }
            .tt-log-details { display: none; padding: 20px 24px; border-top: 1px solid #e2e8f0; background: #fafafa; border-radius: 0 0 12px 12px; }
            .tt-log-card-wrapper.is-open .tt-log-details { display: block; }
            .tt-log-card-wrapper { background: #fff; border: 1px solid #e2e8f0; border-radius: 12px; margin-bottom: 16px; box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05); transition: all 0.2s ease; }
            .tt-log-card-wrapper .tt-log-card { border: none; margin-bottom: 0; box-shadow: none; border-radius: 12px 12px 0 0; }
        </style>

        <script>
            function toggleLogDetails(btn) {
                const wrapper = btn.closest('.tt-log-card-wrapper');
                wrapper.classList.toggle('is-open');
                btn.textContent = wrapper.classList.contains('is-open') ? 'Chiudi Dettagli' : 'Vedi Dettagli';
            }
        </script>

        <div class="tt-logs-list">
            <?php 
            $logs = get_option('tt_ai_scan_logs', array()); 
            if (!empty($logs)) :
                for ($i = count($logs) - 1; $i >= 0; $i--) :
                    $log = $logs[$i];
                    $term = get_term($log['category_id'], 'categoria_azienda');
                    $cat_name = !is_wp_error($term) && $term ? $term->name : 'Sconosciuta';
                    
                    // Format data nicer
                    $date = date_create($log['date']);
                    $formatted_date = date_format($date, 'd M Y, H:i');
                    $nome_azienda = isset($log['nome_azienda']) ? $log['nome_azienda'] : 'Sconosciuta (Log Vecchio)';
                    $sintesi = isset($log['sintesi']) ? $log['sintesi'] : 'Nessuna sintesi disponibile per questo log storico.';
            ?>
            
            <div class="tt-log-card-wrapper">
                <div class="tt-log-card">
                    <div class="tt-log-meta">
                        <div class="tt-log-date"><?php echo esc_html($formatted_date); ?></div>
                        <div class="tt-log-cat">
                            <span class="dashicons dashicons-category"></span>
                            <?php echo esc_html($cat_name); ?>
                        </div>
                        <a href="<?php echo esc_url($log['url']); ?>" target="_blank" class="tt-log-url" title="<?php echo esc_url($log['url']); ?>">
                            <span class="dashicons dashicons-admin-links" style="font-size:16px; width:16px; height:16px;"></span>
                            <?php echo esc_html($log['url']); ?>
                        </a>
                    </div>
                    
                    <div class="tt-log-scores">
                        <div class="tt-score-badge" title="Qualità">
                            <span>Qual</span>
                            <strong><?php echo isset($log['scores']['qualita']) ? $log['scores']['qualita'] : '-'; ?></strong>
                        </div>
                        <div class="tt-score-badge" title="Fiducia">
                            <span>Fid</span>
                            <strong><?php echo isset($log['scores']['fiducia']) ? $log['scores']['fiducia'] : '-'; ?></strong>
                        </div>
                        <div class="tt-score-badge" title="Servizio">
                            <span>Serv</span>
                            <strong><?php echo isset($log['scores']['servizio']) ? $log['scores']['servizio'] : '-'; ?></strong>
                        </div>
                        <div class="tt-score-badge" title="Prezzo">
                            <span>Prez</span>
                            <strong><?php echo isset($log['scores']['prezzo']) ? $log['scores']['prezzo'] : '-'; ?></strong>
                        </div>
                        <div class="tt-score-badge" title="Innovazione">
                            <span>Inn</span>
                            <strong><?php echo isset($log['scores']['innovazione']) ? $log['scores']['innovazione'] : '-'; ?></strong>
                        </div>
                        <div class="tt-score-badge" title="Coerenza">
                            <span>Coer</span>
                            <strong><?php echo isset($log['scores']['coerenza']) ? $log['scores']['coerenza'] : '-'; ?></strong>
                        </div>
                    </div>
                    
                    <div class="tt-log-actions">
                        <button type="button" class="tt-btn-expand" onclick="toggleLogDetails(this)">Vedi Dettagli</button>
                        <?php if (!empty($log['post_id']) && get_post_type($log['post_id']) === 'azienda') : ?>
                            <a href="<?php echo esc_url(get_edit_post_link($log['post_id'])); ?>" class="tt-btn-expand" style="text-decoration:none;">Apri Scheda</a>
                        <?php endif; ?>
                        <a href="<?php echo esc_url(wp_nonce_url(admin_url('admin.php?page=tt-ai-scanner-logs&delete_log=' . $i), 'tt_delete_log_' . $i)); ?>" class="tt-btn-delete" onclick="return confirm('Vuoi davvero eliminare questo record? I dati del benchmark verranno mantenuti, ma il log sarà rimosso.');">
                            Elimina Log
                        </a>
                    </div>
                </div>
                <div class="tt-log-details">
                    <?php 
                    $aziende_list = isset($log['aziende_list']) ? $log['aziende_list'] : array();
                    
                    // Fallback for old logs
                    if (empty($aziende_list) && isset($log['nome_azienda'])) {
                        $aziende_list[] = array(
                            'nome' => $log['nome_azienda'],
                            'sintesi' => isset($log['sintesi']) ? $log['sintesi'] : '',
                            'qualita' => $log['scores']['qualita'],
                            'fiducia' => $log['scores']['fiducia'],
                            'servizio' => $log['scores']['servizio'],
                            'prezzo' => $log['scores']['prezzo'],
                            'innovazione' => $log['scores']['innovazione'],
                            'coerenza' => $log['scores']['coerenza']
                        );
                    }
                    ?>
                    
                    <h5 style="margin-bottom:12px; color:#64748b; font-size:13px; text-transform:uppercase; letter-spacing:0.5px;">Aziende Scansionate (<?php echo count($aziende_list); ?>)</h5>
                    
                    <div style="display:flex; flex-direction:column; gap:16px;">
                        <?php foreach ($aziende_list as $az) : ?>
                            <div style="background:#fff; border:1px solid #e2e8f0; border-radius:8px; padding:16px;">
                                <h4 style="margin-top:0; margin-bottom:8px; color:#1e293b; font-size:16px;">🏢 <?php echo esc_html(isset($az['nome']) ? $az['nome'] : 'Sconosciuta'); ?></h4>
                                <?php if (!empty($az['sintesi'])) : ?>
                                    <p style="color:#475569; margin-bottom:12px; font-size:14px; line-height:1.5;"><em>"<?php echo esc_html($az['sintesi']); ?>"</em></p>
                                <?php endif; ?>
                                
                                <div style="display: flex; gap: 8px; flex-wrap: wrap;">
                                    <span style="background:#f8fafc; border:1px solid #cbd5e1; padding:2px 8px; border-radius:12px; font-size:12px;"><strong>Qualità:</strong> <?php echo isset($az['qualita']) ? $az['qualita'] : '-'; ?></span>
                                    <span style="background:#f8fafc; border:1px solid #cbd5e1; padding:2px 8px; border-radius:12px; font-size:12px;"><strong>Fiducia:</strong> <?php echo isset($az['fiducia']) ? $az['fiducia'] : '-'; ?></span>
                                    <span style="background:#f8fafc; border:1px solid #cbd5e1; padding:2px 8px; border-radius:12px; font-size:12px;"><strong>Servizio:</strong> <?php echo isset($az['servizio']) ? $az['servizio'] : '-'; ?></span>
                                    <span style="background:#f8fafc; border:1px solid #cbd5e1; padding:2px 8px; border-radius:12px; font-size:12px;"><strong>Prezzo:</strong> <?php echo isset($az['prezzo']) ? $az['prezzo'] : '-'; ?></span>
                                    <span style="background:#f8fafc; border:1px solid #cbd5e1; padding:2px 8px; border-radius:12px; font-size:12px;"><strong>Innovazione:</strong> <?php echo isset($az['innovazione']) ? $az['innovazione'] : '-'; ?></span>
                                    <span style="background:#f8fafc; border:1px solid #cbd5e1; padding:2px 8px; border-radius:12px; font-size:12px;"><strong>Coerenza:</strong> <?php echo isset($az['coerenza']) ? $az['coerenza'] : '-'; ?></span>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>

            <?php 
                endfor; 
            else : 
            ?>
            
            <div class="tt-empty-state">
                <span class="dashicons dashicons-database" style="font-size: 48px; width: 48px; height: 48px; color: #cbd5e1; margin-bottom: 16px;"></span>
                <h3>Nessun dato analizzato</h3>
                <p>Esegui la tua prima scansione AI per iniziare ad alimentare il database.</p>
            </div>
            
            <?php endif; ?>
        </div>
    </div>
    <?php
}

// 2.7 Pagina delle Impostazioni Tema
function tt_theme_settings_page() {
    // Gestione salvataggio opzioni
    if (isset($_POST['tt_save_settings']) && current_user_can('manage_options')) {
        check_admin_referer('tt_save_settings_action', 'tt_settings_nonce');
        
        $test_mail_active = isset($_POST['tt_test_mail_active']) ? '1' : '0';
        update_option('tt_test_mail_active', $test_mail_active);

        // Chiave OpenAI: campo vuoto = mantieni quella salvata
        $new_key = isset($_POST['tt_openai_api_key']) ? trim(sanitize_text_field(wp_unslash($_POST['tt_openai_api_key']))) : '';
        if ($new_key !== '') {
            update_option('tt_openai_api_key', $new_key, false);
        }
        
        echo '<div class="notice notice-success is-dismissible" style="border-left-color: #D4AF37; margin: 15px 0 0 0;"><p><strong>Impostazioni salvate con successo!</strong> Le modifiche sono state applicate all\'invio del form Candidati.</p></div>';
    }
    
    $test_mail_active = get_option('tt_test_mail_active', '0');
    ?>
    <div class="wrap" style="max-width: 800px; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;">
        <h1 style="display: flex; align-items: center; gap: 10px; margin-bottom: 24px; font-size: 28px; font-weight: 600; color: #1e293b;">
            <span class="dashicons dashicons-admin-generic" style="font-size: 32px; width: 32px; height: 32px; color: #D4AF37;"></span> 
            Impostazioni TicinoTOP
        </h1>
        
        <div style="background: #fff; padding: 32px; border: 1px solid #e2e8f0; border-radius: 12px; box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05); margin-top: 20px;">
            <form method="post" action="">
                <?php wp_nonce_field('tt_save_settings_action', 'tt_settings_nonce'); ?>
                
                <div style="display: flex; align-items: center; justify-content: space-between; border-bottom: 1px solid #e2e8f0; padding-bottom: 24px; margin-bottom: 24px;">
                    <div style="max-width: 70%;">
                        <h3 style="margin: 0 0 8px 0; font-size: 18px; font-weight: 600; color: #0f172a;">Modalità Test Invio Mail</h3>
                        <p style="margin: 0; color: #64748b; font-size: 14px; line-height: 1.5;">
                            Se attivo, aggiunge un pulsante blu <strong>"Test Invio Mail"</strong> nel form della pagina Candidati. Il pulsante sarà visibile <strong>solo agli amministratori loggati</strong> per effettuare test di invio e-mail istantanei direttamente dal frontend.
                        </p>
                    </div>
                    <div>
                        <!-- Switch Toggle Gold Style -->
                        <style>
                            .tt-switch {
                                position: relative;
                                display: inline-block;
                                width: 56px;
                                height: 30px;
                            }
                            .tt-switch input {
                                opacity: 0;
                                width: 0;
                                height: 0;
                            }
                            .tt-slider {
                                position: absolute;
                                cursor: pointer;
                                top: 0;
                                left: 0;
                                right: 0;
                                bottom: 0;
                                background-color: #cbd5e1;
                                transition: .3s;
                                border-radius: 34px;
                            }
                            .tt-slider:before {
                                position: absolute;
                                content: "";
                                height: 22px;
                                width: 22px;
                                left: 4px;
                                bottom: 4px;
                                background-color: white;
                                transition: .3s;
                                border-radius: 50%;
                                box-shadow: 0 2px 4px rgba(0,0,0,0.15);
                            }
                            .tt-switch input:checked + .tt-slider {
                                background-color: #D4AF37;
                            }
                            .tt-switch input:focus + .tt-slider {
                                box-shadow: 0 0 1px #D4AF37;
                            }
                            .tt-switch input:checked + .tt-slider:before {
                                transform: translateX(26px);
                            }
                        </style>
                        <label class="tt-switch">
                            <input type="checkbox" name="tt_test_mail_active" value="1" <?php checked('1', $test_mail_active); ?>>
                            <span class="tt-slider"></span>
                        </label>
                    </div>
                </div>
                
                <div style="border-bottom: 1px solid #e2e8f0; padding-bottom: 24px; margin-bottom: 24px;">
                    <h3 style="margin: 0 0 8px 0; font-size: 18px; font-weight: 600; color: #0f172a;">API Key OpenAI (Scanner AI)</h3>
                    <?php $current_key = tt_ai_get_openai_key(); ?>
                    <?php if (defined('TT_OPENAI_API_KEY') && TT_OPENAI_API_KEY) : ?>
                        <p style="margin: 0; color: #64748b; font-size: 14px;">Definita in <code>wp-config.php</code> (costante <code>TT_OPENAI_API_KEY</code>): ha la precedenza su questo campo.</p>
                    <?php else : ?>
                        <p style="margin: 0 0 12px 0; color: #64748b; font-size: 14px;">
                            <?php echo $current_key ? 'Chiave salvata: <code>…' . esc_html(substr($current_key, -4)) . '</code>. Lascia vuoto per mantenerla.' : 'Nessuna chiave salvata.'; ?>
                        </p>
                        <input type="password" name="tt_openai_api_key" value="" placeholder="sk-..." autocomplete="new-password" style="width: 100%; padding: 8px;">
                    <?php endif; ?>
                </div>

                <div style="display: flex; gap: 12px; align-items: center; background: #faf8f0; border-left: 4px solid #D4AF37; padding: 16px 20px; border-radius: 4px; margin-bottom: 32px;">
                    <span class="dashicons dashicons-shield-alt" style="color: #D4AF37; font-size: 20px; width: 20px; height: 20px;"></span>
                    <span style="font-size: 13px; color: #856404; line-height: 1.5;">
                        <strong>Nota di Sicurezza:</strong> Questa opzione è concepita esclusivamente per testare la funzionalità SMTP del server durante la manutenzione. Si consiglia di disattivarlo quando il sito è in produzione stabile. In ogni caso, i visitatori generici non vedranno mai il tasto.
                    </span>
                </div>
                
                <button type="submit" name="tt_save_settings" class="button button-primary" style="background: #D4AF37; border-color: #b5952f; color: #fff; padding: 6px 20px; font-size: 14px; font-weight: 600; border-radius: 6px; box-shadow: 0 2px 4px rgba(212, 175, 55, 0.2); cursor: pointer; transition: all 0.2s;">
                    Salva Impostazioni
                </button>
            </form>
        </div>
    </div>
    <?php
}

// 3. Gestiamo la logica di analisi al submit del form
add_action('admin_post_tt_run_ai_scan', 'tt_handle_ai_scan');
function tt_handle_ai_scan() {
    if (!isset($_POST['tt_nonce']) || !wp_verify_nonce($_POST['tt_nonce'], 'tt_ai_scan_nonce')) {
        wp_die('Sicurezza fallita.');
    }
    
    if (!current_user_can('manage_options')) {
        wp_die('Non hai i permessi.');
    }

    // Modalita sito aziendale: anteprima scheda + pubblicazione in Aziende
    if (!isset($_POST['scan_mode']) || $_POST['scan_mode'] !== 'elenco') {
        tt_company_handle_scan();
        return;
    }

    $category_id = intval($_POST['category_id']);
    if (!$category_id) {
        wp_die('Per la pagina elenco devi scegliere una categoria.', '', array('back_link' => true));
    }

    $openai_key = tt_ai_get_openai_key();
    $target_url = esc_url_raw($_POST['target_url']);
    $manual_text = sanitize_textarea_field($_POST['manual_text']);

    if (empty($openai_key) || (empty($target_url) && empty($manual_text))) {
        wp_die('Devi configurare la chiave API (Impostazioni) e inserire un URL (oppure incollare il testo manualmente).', '', array('back_link' => true));
    }

    $clean_text = '';

    // 1. FASE DI ESTRAZIONE DATI
    if (!empty($manual_text)) {
        // Uso testo manuale per bypassare anti-bot
        $clean_text = $manual_text;
        if (empty($target_url)) $target_url = 'Testo Incollato Manualmente';
    } else {
        // Lettura diretta con wp_safe_remote_get (rifiuta host interni). Niente proxy di terze parti:
        // inoltravano l'URL a servizi esterni e uno usava una chiave ScraperAPI scritta nel codice.
        $html_content = '';
        $resp = wp_safe_remote_get($target_url, array(
            'timeout'             => 15,
            'limit_response_size' => 3 * MB_IN_BYTES,
            'user-agent'          => 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36',
            'headers'             => array('Accept' => 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'),
        ));
        if (!is_wp_error($resp) && wp_remote_retrieve_response_code($resp) === 200) {
            $body = wp_remote_retrieve_body($resp);
            if (strlen($body) > 1000 && stripos($body, 'datadome') === false && stripos($body, 'captcha') === false) {
                $html_content = $body;
            }
        }

        if (empty($html_content)) {
            wp_die('<h2>Il sito non ha restituito la pagina.</h2>
            <p>Siti come TripAdvisor o Google bloccano la lettura automatica.</p>
            <p><strong>Come risolvere:</strong><br>apri la pagina nel browser, seleziona tutto il testo (CMD+A), copialo e incollalo nel campo <strong>"Testo Manuale"</strong>.</p>', '', array('back_link' => true));
        }

        $clean_text = wp_strip_all_tags($html_content);
    }
    
    // Rimuovo gli spazi multipli e le righe vuote per ridurre il "rumore" che confonde l'AI
    $clean_text = preg_replace('/\s+/', ' ', $clean_text);
    
    // Limite ottimizzato: troppo testo (es. 300k) causa l'effetto "Lost in the Middle" dove l'AI si stanca e salta i dati. 150k è il compromesso ideale.
    $clean_text = substr($clean_text, 0, 150000);

    // 2. CONNESSIONE REALE A OPENAI
    $prompt = "Sei un analista di mercato svizzero ed estrattore di dati implacabile. 
Il nostro bot ha estratto il testo grezzo da questo sito web: " . $target_url . "
Il testo contiene una lista di aziende (es. ristoranti, cliniche, hotel). Esegui questi compiti con la massima precisione:
1. Identifica e memorizza ASSOLUTAMENTE TUTTE LE AZIENDE presenti nel testo. Non tralasciarne nessuna. È un errore critico se ti fermi prima della fine della lista.
2. Per OGNI azienda trovata, scrivi una breve sintesi e valuta il suo livello (da 10 a 100) sui parametri: qualita, fiducia, servizio, prezzo, innovazione, coerenza.

ATTENZIONE: Se il testo elenca 50 ristoranti, il tuo JSON DEVE contenere 50 elementi. Non fare riassunti, non estrarre solo i primi. Estraili TUTTI.

Devi rispondere ESATTAMENTE e SOLO con un oggetto JSON valido in questo formato:
{
  \"aziende\": [
    {\"nome\": \"Nome Prima Azienda\", \"sintesi\": \"Motivazione dei voti.\", \"qualita\": 80, \"fiducia\": 75, \"servizio\": 90, \"prezzo\": 60, \"innovazione\": 50, \"coerenza\": 85},
    {\"nome\": \"Nome Seconda Azienda\", \"sintesi\": \"Motivazione dei voti.\", \"qualita\": 85, \"fiducia\": 80, \"servizio\": 85, \"prezzo\": 70, \"innovazione\": 60, \"coerenza\": 90}
  ]
}
Se trovi una sola azienda, restituisci l'array con un solo elemento. NON AGGIUNGERE TESTO PRIMA O DOPO, SOLO IL JSON.

TESTO ESTRATTO DAL SITO:
" . $clean_text;

    $api_url = 'https://api.openai.com/v1/chat/completions';
    $args = array(
        'method'      => 'POST',
        'timeout'     => 120,
        'headers'     => array(
            'Authorization' => 'Bearer ' . $openai_key,
            'Content-Type'  => 'application/json',
        ),
        'body'        => wp_json_encode(array(
            'model'       => 'gpt-4o-mini',
            'messages'    => array(
                array(
                    'role'    => 'user',
                    'content' => $prompt
                )
            ),
            'temperature' => 0.2, 
        )),
    );

    $response = wp_remote_post($api_url, $args);

    if (is_wp_error($response)) {
        wp_die('Errore di connessione API: ' . $response->get_error_message());
    }

    $body = wp_remote_retrieve_body($response);
    $data = json_decode($body, true);

    if (isset($data['error'])) {
        wp_die('Errore da OpenAI: ' . $data['error']['message']);
    }

    $ai_response = $data['choices'][0]['message']['content'];
    $ai_response = str_replace(array('```json', '```'), '', $ai_response);
    $parsed_data = json_decode(trim($ai_response), true);

    if (!$parsed_data || !isset($parsed_data['aziende']) || !is_array($parsed_data['aziende']) || empty($parsed_data['aziende'])) {
        wp_die('<h2>L\'AI non ha trovato aziende nel testo estratto.</h2>
        <p><strong>Perché è successo?</strong><br>Siti grossi come TripAdvisor o Google usano sistemi "Anti-Bot" militari (come Cloudflare). Quando il nostro server cerca di leggere il link, TripAdvisor non restituisce la lista dei ristoranti, ma restituisce una pagina bianca con scritto "Verifica che sei umano". L\'AI legge quella pagina, non trova ristoranti, e restituisce un array vuoto.</p>
        <p><strong>Come risolvere (Metodo infallibile):</strong><br>Torna indietro. Vai sul sito di TripAdvisor dal tuo computer, premi <code>CTRL + A</code> (o CMD+A) per selezionare tutto il testo della pagina, fai Copia, e Incollalo nel nuovo campo <strong>"OPPURE: Incolla Testo"</strong>. L\'AI divorerà quel testo senza problemi!</p>');
    }

    $aziende_list = $parsed_data['aziende'];
    $num_aziende = count($aziende_list);

    // Calcoliamo la media di QUESTA specifica scansione tra tutte le aziende trovate
    $scan_avg = ['qualita' => 0, 'fiducia' => 0, 'servizio' => 0, 'prezzo' => 0, 'innovazione' => 0, 'coerenza' => 0];
    
    foreach ($aziende_list as $az) {
        foreach (array_keys($scan_avg) as $key) {
            $scan_avg[$key] += intval(isset($az[$key]) ? $az[$key] : 0);
        }
    }
    
    foreach (array_keys($scan_avg) as $key) {
        $scan_avg[$key] = round($scan_avg[$key] / $num_aziende);
    }

    // 3. MEDIA CUMULATIVA STORICA DELLA CATEGORIA
    $scan_count = get_term_meta($category_id, '_tt_benchmark_scan_count', true);
    $scan_count = $scan_count ? intval($scan_count) : 0;
    
    if ($scan_count > 0) {
        foreach (['qualita', 'fiducia', 'servizio', 'prezzo', 'innovazione', 'coerenza'] as $param) {
            $current_val = get_term_meta($category_id, '_tt_benchmark_' . $param, true);
            $new_avg = round((($current_val * $scan_count) + $scan_avg[$param]) / ($scan_count + 1));
            $scan_avg[$param] = $new_avg; 
        }
    }
    
    $scan_count++;
    update_term_meta($category_id, '_tt_benchmark_scan_count', $scan_count);

    // 4. SALVATAGGIO LOGS E DATI
    // Salviamo la nuova media calcolata nel database per questa Categoria
    update_term_meta($category_id, '_tt_benchmark_qualita', $scan_avg['qualita']);
    update_term_meta($category_id, '_tt_benchmark_fiducia', $scan_avg['fiducia']);
    update_term_meta($category_id, '_tt_benchmark_servizio', $scan_avg['servizio']);
    update_term_meta($category_id, '_tt_benchmark_prezzo', $scan_avg['prezzo']);
    update_term_meta($category_id, '_tt_benchmark_innovazione', $scan_avg['innovazione']);
    update_term_meta($category_id, '_tt_benchmark_coerenza', $scan_avg['coerenza']);
    
    // Registriamo il Log nella history
    $logs = get_option('tt_ai_scan_logs', array());
    $new_log = array(
        'date' => current_time('mysql'),
        'category_id' => $category_id,
        'url' => $target_url,
        'scores' => $scan_avg,
        'aziende_list' => $aziende_list
    );
    $logs[] = $new_log;
    
    // Teniamo solo gli ultimi 100 log per evitare di appesantire il DB
    if (count($logs) > 100) {
        $logs = array_slice($logs, -100);
    }
    update_option('tt_ai_scan_logs', $logs, false);

    // Redirect alla pagina con messaggio di successo
    wp_redirect(admin_url('admin.php?page=tt-ai-scanner&scan=success'));
    exit;
}

// -----------------------------------------------------------------------------
// Ripristino Automatico e Auto-Healing del Registro dei Log e Benchmark AI
// Riassegna dinamicamente i vecchi ID dimostrativi (es. 2) agli ID reali delle categorie 
// cercando per slug di tassonomia, ricalcolando poi le medie dei benchmark.
// -----------------------------------------------------------------------------
function tt_repair_ai_scan_logs() {
    // Riparazione una tantum dei vecchi ID categoria: prima girava a ogni pagina admin
    if (get_option('tt_ai_scan_logs_repaired') === '1') {
        return;
    }
    update_option('tt_ai_scan_logs_repaired', '1');

    $logs = get_option('tt_ai_scan_logs', array());
    if (empty($logs)) {
        return;
    }
    
    $modified = false;
    
    // Associazione dei vecchi ID dimostrativi delle categorie ai loro slug WordPress
    $old_id_to_slug = [
        2 => 'ristorazione-locali',
        3 => 'hotel-alloggi',
        4 => 'salute-medicina',
    ];
    
    foreach ($logs as $index => $log) {
        $cat_id = intval($log['category_id']);
        
        // Controlla se il termine esiste ed appartiene alla tassonomia corretta
        $term = get_term($cat_id, 'categoria_azienda');
        if (is_wp_error($term) || !$term) {
            // Se non esiste, prova a ripristinarlo mappando il vecchio ID allo slug reale
            if (isset($old_id_to_slug[$cat_id])) {
                $slug = $old_id_to_slug[$cat_id];
                $active_term = get_term_by('slug', $slug, 'categoria_azienda');
                if ($active_term && !is_wp_error($active_term)) {
                    $logs[$index]['category_id'] = intval($active_term->term_id);
                    $modified = true;
                }
            }
        }
    }
    
    if ($modified) {
        update_option('tt_ai_scan_logs', $logs, false);
        
        // Ricalcola immediatamente tutti i benchmark term meta per le categorie coinvolte
        tt_recalculate_benchmarks_from_logs();
    }
}
add_action('admin_init', 'tt_repair_ai_scan_logs');

// Ricalcola matematicamente le medie storiche dei benchmark di tutte le categorie presenti nei log
function tt_recalculate_benchmarks_from_logs() {
    $logs = get_option('tt_ai_scan_logs', array());
    if (empty($logs)) {
        return;
    }
    
    // Raggruppa i log storici per ID di categoria attiva
    $logs_by_cat = [];
    foreach ($logs as $log) {
        $cat_id = intval($log['category_id']);
        if ($cat_id > 0) {
            $logs_by_cat[$cat_id][] = $log;
        }
    }
    
    // Ricalcola le medie cumulative per ciascuna categoria attiva
    foreach ($logs_by_cat as $cat_id => $cat_logs) {
        $term = get_term($cat_id, 'categoria_azienda');
        if (is_wp_error($term) || !$term) {
            continue;
        }
        
        $cumulative_avg = [
            'qualita' => 0,
            'fiducia' => 0,
            'servizio' => 0,
            'prezzo' => 0,
            'innovazione' => 0,
            'coerenza' => 0
        ];
        $total_scans = count($cat_logs);
        
        foreach ($cat_logs as $log) {
            $scores = $log['scores'];
            foreach (array_keys($cumulative_avg) as $param) {
                $cumulative_avg[$param] += intval(isset($scores[$param]) ? $scores[$param] : 0);
            }
        }
        
        // Calcola e salva la media esatta per ciascun parametro reputazionale
        foreach (array_keys($cumulative_avg) as $param) {
            $cumulative_avg[$param] = round($cumulative_avg[$param] / $total_scans);
            update_term_meta($cat_id, '_tt_benchmark_' . $param, $cumulative_avg[$param]);
        }
        
        update_term_meta($cat_id, '_tt_benchmark_scan_count', $total_scans);
    }
}

