<?php
/**
 * Template Name: TT Magazine
 */
get_header(); 

// 1. Query for the latest post to be featured in the hero section
$featured_args = [
    'post_type' => 'post',
    'post_status' => 'publish',
    'posts_per_page' => 1,
    'orderby' => 'date',
    'order' => 'DESC'
];
$featured_query = new WP_Query($featured_args);

$featured_id = 0;
$featured_post = null;

if ($featured_query->have_posts()) {
    $featured_query->the_post();
    $featured_id = get_the_ID();
    
    $p_id = $featured_id;
    $p_title = get_the_title();
    $p_excerpt = get_the_excerpt() ?: wp_trim_words(get_the_content(), 25);
    $p_img = get_the_post_thumbnail_url($p_id, 'full') ?: get_stylesheet_directory_uri() . '/images/category-default.jpg';
    $p_url = get_permalink();
    
    $categories = get_the_category();
    $p_category = ($categories) ? $categories[0]->name : 'Trend & Insight';
    $p_date = get_the_date('j F Y');
    
    $featured_post = [
        'id' => $p_id,
        'title' => $p_title,
        'excerpt' => $p_excerpt,
        'img' => $p_img,
        'url' => $p_url,
        'category' => $p_category,
        'date' => $p_date,
    ];
    wp_reset_postdata();
}

// 3. Now query the remaining posts (grid posts) excluding the featured post
$grid_posts = [];
$args = [
    'post_type' => 'post',
    'post_status' => 'publish',
    'posts_per_page' => 9,
];
if ($featured_id > 0) {
    $args['post__not_in'] = [$featured_id];
}

$blog_query = new WP_Query($args);
if ($blog_query->have_posts()) {
    while ($blog_query->have_posts()) {
        $blog_query->the_post();
        
        $p_id = get_the_ID();
        $p_title = get_the_title();
        $p_excerpt = get_the_excerpt() ?: wp_trim_words(get_the_content(), 25);
        $p_img = get_the_post_thumbnail_url($p_id, 'full') ?: get_stylesheet_directory_uri() . '/images/category-default.jpg';
        $p_url = get_permalink();
        
        $categories = get_the_category();
        $p_category = ($categories) ? $categories[0]->name : 'Trend & Insight';
        $p_date = get_the_date('j F Y');
        
        $grid_posts[] = [
            'id' => $p_id,
            'title' => $p_title,
            'excerpt' => $p_excerpt,
            'img' => $p_img,
            'url' => $p_url,
            'category' => $p_category,
            'date' => $p_date,
        ];
    }
    wp_reset_postdata();
}
?>

<main class="tt-main" style="background: var(--tt-gray-light); min-height: 100vh; padding-bottom: 80px;">
    <section class="tt-section" style="padding-top: 80px;">
        <div class="tt-container">
            <div style="text-align: center; margin-bottom: 60px;">
                <span class="tt-badge" style="background: rgba(10,25,47,0.05); border-color: rgba(10,25,47,0.1); color: var(--tt-blue-notte); margin-bottom: 16px;">News</span>
                <h1 class="animate-hero-title" style="font-family: var(--tt-font-serif); font-size: 56px; margin-bottom: 16px; color: var(--tt-black);">Storie & Insight</h1>
                <p class="animate-hero-subtitle" style="font-size: 20px; color: var(--tt-gray-text); max-width: 600px; margin: 0 auto; line-height: 1.6;">Letture di approfondimento sul mondo della reputazione digitale, dell'intelligenza artificiale e delle eccellenze del Ticino.</p>
            </div>

            <?php if ($featured_post) : ?>
                <!-- Featured Article -->
                <div class="tt-card reveal-on-scroll tt-featured-hero" style="display: flex; flex-direction: row; margin-bottom: 60px; min-height: 450px; overflow: hidden; border-radius: var(--tt-radius-lg); box-shadow: var(--tt-shadow-premium); border: 1px solid var(--tt-gray-border); padding: 0;">
                    <div class="tt-featured-hero-img" style="width: 55%; background: url('<?php echo esc_url($featured_post['img']); ?>') center/cover; position: relative; min-height: 350px;">
                        <div style="position: absolute; inset: 0; background: linear-gradient(to right, transparent 50%, rgba(255,255,255,0.05));"></div>
                    </div>
                    <div class="tt-featured-hero-body" style="width: 45%; padding: 48px; display: flex; flex-direction: column; justify-content: center; background: var(--tt-white);">
                        <div class="tt-badge tt-badge-dark" style="margin-bottom: 24px; align-self: flex-start; background: var(--tt-blue-notte); border-color: var(--tt-blue-notte); color: var(--tt-white);"><?php echo esc_html($featured_post['category']); ?></div>
                        <span style="font-size: 13px; color: var(--tt-gray-text); margin-bottom: 12px; font-weight: 500;"><?php echo esc_html($featured_post['date']); ?></span>
                        <h2 style="font-family: var(--tt-font-serif); font-size: 36px; margin: 0 0 16px 0; line-height: 1.2; color: var(--tt-black);">
                            <a class="tt-featured-title-link" href="<?php echo esc_url($featured_post['url']); ?>" style="color: inherit; text-decoration: none; transition: color 0.3s ease;"><?php echo esc_html($featured_post['title']); ?></a>
                        </h2>
                        <p style="font-size: 16px; color: var(--tt-gray-text); margin-bottom: 32px; line-height: 1.6;"><?php echo esc_html($featured_post['excerpt']); ?></p>
                        <a href="<?php echo esc_url($featured_post['url']); ?>" class="tt-btn tt-btn-primary" style="align-self: flex-start;">Leggi l'Articolo</a>
                    </div>
                </div>
            <?php endif; ?>

            <?php if (!empty($grid_posts)) : ?>
                <!-- Grid Articles -->
                <div class="tt-grid-3 reveal-grid">
                    <?php foreach ($grid_posts as $post) : ?>
                        <a href="<?php echo esc_url($post['url']); ?>" class="tt-card tt-blog-card" style="display: flex; flex-direction: column; text-decoration: none; border-radius: var(--tt-radius-md); overflow: hidden; background: var(--tt-white); box-shadow: var(--tt-shadow-sm); border: 1px solid var(--tt-gray-border); height: 100%; transition: all 0.3s ease; padding: 0; box-shadow: none;">
                            <div style="height: 240px; background: url('<?php echo esc_url($post['img']); ?>') center/cover; position: relative;">
                                <div style="position: absolute; top: 16px; left: 16px;">
                                    <span class="tt-badge" style="background: rgba(255,255,255,0.95); backdrop-filter: blur(4px); -webkit-backdrop-filter: blur(4px); color: var(--tt-black); border-color: rgba(255,255,255,0.5); font-weight: 600;"><?php echo esc_html($post['category']); ?></span>
                                </div>
                            </div>
                            <div style="padding: 28px; flex-grow: 1; display: flex; flex-direction: column; justify-content: space-between; background: var(--tt-white);">
                                <div>
                                    <span style="color: var(--tt-gray-text); font-size: 12px; display: block; margin-bottom: 12px; font-weight: 500;"><?php echo esc_html($post['date']); ?></span>
                                    <h3 style="font-size: 22px; margin: 0 0 12px 0; font-family: var(--tt-font-serif); color: var(--tt-black); line-height: 1.3; transition: color 0.3s ease;"><?php echo esc_html($post['title']); ?></h3>
                                    <p style="font-size: 14.5px; color: var(--tt-gray-text); margin: 0; line-height: 1.6; display: -webkit-box; -webkit-line-clamp: 3; -webkit-box-orient: vertical; overflow: hidden;"><?php echo esc_html($post['excerpt']); ?></p>
                                </div>
                                <div style="margin-top: 24px; font-weight: 600; font-size: 14px; color: var(--tt-gold-champagne); display: flex; align-items: center; gap: 4px;">
                                    Leggi Articolo →
                                </div>
                            </div>
                        </a>
                    <?php endforeach; ?>
                </div>

                <!-- Load More Button -->
                <?php if ( $blog_query->max_num_pages > 1 ) : ?>
                    <div style="text-align: center; margin-top: 50px;">
                        <button id="tt-load-more-blog" class="tt-btn tt-btn-primary" data-page="1" data-featured="<?php echo esc_attr($featured_id); ?>" data-ajaxurl="<?php echo admin_url('admin-ajax.php'); ?>" data-max="<?php echo esc_attr($blog_query->max_num_pages); ?>">
                            CARICA ALTRI ARTICOLI
                        </button>
                    </div>
                <?php endif; ?>

            <?php elseif (!$featured_post) : ?>
                <div class="tt-card" style="text-align: center; padding: 60px; background: var(--tt-white);">
                    <p style="color: var(--tt-gray-text); font-size: 18px; margin: 0;">Nessun articolo pubblicato nel blog al momento. Torna presto per i prossimi aggiornamenti!</p>
                </div>
            <?php endif; ?>
        </div>
    </section>
</main>

<style>
.tt-blog-card:hover {
    transform: translateY(-6px);
    border-color: rgba(212, 175, 55, 0.4) !important;
    box-shadow: var(--tt-shadow-premium) !important;
}
.tt-blog-card:hover h3, .tt-featured-title-link:hover {
    color: var(--tt-gold-champagne) !important;
}
#tt-load-more-blog {
    cursor: pointer;
    transition: opacity 0.3s ease;
}
#tt-load-more-blog.loading {
    opacity: 0.7;
    pointer-events: none;
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const loadMoreBtn = document.getElementById('tt-load-more-blog');
    if (loadMoreBtn) {
        loadMoreBtn.addEventListener('click', function() {
            const btn = this;
            const ajaxurl = btn.getAttribute('data-ajaxurl');
            let page = parseInt(btn.getAttribute('data-page'));
            const maxPage = parseInt(btn.getAttribute('data-max'));
            const featuredId = btn.getAttribute('data-featured');
            
            page++; // Increment page number for the request
            
            btn.classList.add('loading');
            btn.innerText = 'CARICAMENTO...';
            
            const formData = new FormData();
            formData.append('action', 'tt_load_more_posts');
            formData.append('page', page);
            formData.append('featured', featuredId);
            
            fetch(ajaxurl, {
                method: 'POST',
                body: formData
            })
            .then(response => response.text())
            .then(data => {
                btn.classList.remove('loading');
                btn.innerText = 'CARICA ALTRI ARTICOLI';
                
                if (data.trim() !== '') {
                    const grid = document.querySelector('.tt-grid-3');
                    if (grid) {
                        grid.insertAdjacentHTML('beforeend', data);
                        btn.setAttribute('data-page', page);
                        
                        if (page >= maxPage) {
                            btn.style.display = 'none';
                        }
                    }
                } else {
                    btn.style.display = 'none';
                }
            })
            .catch(error => {
                console.error('Error loading more posts:', error);
                btn.classList.remove('loading');
                btn.innerText = 'CARICA ALTRI ARTICOLI';
            });
        });
    }
});
</script>

<?php get_footer(); ?>
