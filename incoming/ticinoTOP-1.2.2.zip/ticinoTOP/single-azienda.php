<?php
/**
 * Template Name: TT Scheda Azienda
 */
get_header(); 

// Fetch meta values
$post_id = get_the_ID();
// Nessun valore di ripiego inventato: se un dato manca, il relativo elemento non viene mostrato
$voto = get_post_meta($post_id, '_tt_voto', true);
$recensioni = get_post_meta($post_id, '_tt_recensioni', true);
$ai_match = get_post_meta($post_id, '_tt_ai_match', true);
$scores = get_post_meta($post_id, '_tt_ai_scores', true);
$scores = is_array($scores) ? $scores : array();
$rank = tt_azienda_rank($post_id);
$ai_text = get_post_meta($post_id, '_tt_ai_text', true) ?: 'Testo analisi non ancora generato per questa azienda.';
$img_meta = get_post_meta($post_id, '_tt_image', true);
$img = $img_meta ?: (get_the_post_thumbnail_url($post_id, 'full') ?: get_stylesheet_directory_uri() . '/images/placeholder-restaurant.jpg');
$localita = get_post_meta($post_id, '_tt_localita', true) ?: 'Lugano, Ticino';
$website = get_post_meta($post_id, '_tt_website', true);
$email = get_post_meta($post_id, '_tt_email', true);
$telefono = get_post_meta($post_id, '_tt_telefono', true);
$indirizzo = get_post_meta($post_id, '_tt_indirizzo', true);
?>

<main class="tt-main">
    <!-- Hero Azienda -->
    <section class="tt-section" style="padding: 0 0 80px 0; background: var(--tt-gray-light);">
        <div style="height: 400px; background-image: url('<?php echo esc_url($img); ?>'); background-size: cover; background-position: center; position: relative;">
            <div style="position: absolute; inset: 0; background: linear-gradient(to top, rgba(10,25,47,0.9), transparent);"></div>
            
            <div class="tt-container tt-company-hero-inner" style="position: absolute; bottom: 0; left: 0; right: 0; padding-bottom: 40px; display: flex; align-items: flex-end; justify-content: space-between;">
                <div>
                    <div style="display: flex; gap: 8px; margin-bottom: 16px;">
                        <span class="tt-badge tt-badge-gold">Ticino Top Recommended</span>
                    </div>
                    <h1 class="tt-company-hero-title" style="color: var(--tt-white); font-family: var(--tt-font-serif); font-size: 56px; margin-bottom: 8px;"><?php the_title(); ?></h1>
                    <div style="display: flex; align-items: center; gap: 24px; flex-wrap: wrap;">
                        <p style="color: #cbd5e1; font-size: 18px; margin: 0;"><?php echo esc_html($localita); ?></p>
                        <?php if (function_exists('tt_render_assigned_badges')) : ?>
                            <?php tt_the_assigned_badges(); ?>
                        <?php endif; ?>
                    </div>
                </div>
                <?php if ($rank) : ?>
                <div class="tt-company-hero-rank" style="background: var(--tt-white); padding: 24px; border-radius: var(--tt-radius-lg); text-align: center; box-shadow: var(--tt-shadow-premium); min-width: 150px;">
                    <div style="font-size: 12px; color: var(--tt-gray-text); text-transform: uppercase; letter-spacing: 0.1em; margin-bottom: 8px;">Ranking <?php echo esc_html($rank['category']); ?></div>
                    <div style="font-size: 48px; font-weight: 700; font-family: var(--tt-font-serif); color: var(--tt-gold-champagne); line-height: 1;">#<?php echo esc_html($rank['position']); ?></div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </section>

    <!-- Content -->
    <section class="tt-section" style="padding-top: 40px;">
        <div class="tt-container tt-company-grid" style="display: grid; grid-template-columns: 2fr 1fr; gap: 48px;">
            
            <!-- Left Column -->
            <div>
                <h2 style="font-family: var(--tt-font-serif); font-size: 32px; margin-bottom: 24px;">Perché è consigliato</h2>
                <div class="tt-ai-box" style="padding: 24px; font-size: 16px; margin-bottom: 40px;">
                    <div class="tt-ai-box-title" style="font-size: 18px; margin-bottom: 12px;">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="color: var(--tt-gold-champagne);"><path d="M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>
                        Analisi AI Reputazionale
                    </div>
                    <p style="margin: 0; color: var(--tt-black); line-height: 1.8;">
                        <?php echo nl2br(esc_html($ai_text)); ?>
                    </p>
                </div>

                <?php if (trim(get_post_field('post_content', $post_id))) : ?>
                    <h2 style="font-family: var(--tt-font-serif); font-size: 24px; margin-bottom: 24px;">L'azienda</h2>
                    <div class="tt-company-description" style="line-height: 1.8; margin-bottom: 40px;">
                        <?php the_content(); ?>
                    </div>
                <?php endif; ?>

                <?php
                $indicators = array();
                if (isset($scores['qualita'])) {
                    $indicators[] = array('Qualità percepita', intval($scores['qualita']), 'var(--tt-success)');
                }
                if ($ai_match !== '') {
                    $indicators[] = array('Coerenza Recensioni', intval($ai_match), 'var(--tt-gold-champagne)');
                }
                if (isset($scores['fiducia'])) {
                    $indicators[] = array('Affidabilità', intval($scores['fiducia']), 'var(--tt-trust)');
                }
                ?>
                <?php if ($indicators) : ?>
                <h2 style="font-family: var(--tt-font-serif); font-size: 24px; margin-bottom: 24px;">Indicatori di Fiducia</h2>
                <div class="tt-indicators-grid" style="display: grid; grid-template-columns: 1fr 1fr; gap: 24px; margin-bottom: 40px;">
                    <?php foreach ($indicators as $ind) : $val = max(0, min(100, $ind[1])); ?>
                    <div style="border: 1px solid var(--tt-gray-border); padding: 16px; border-radius: var(--tt-radius-sm);">
                        <div style="display: flex; justify-content: space-between; margin-bottom: 8px;">
                            <span style="font-weight: 600;"><?php echo esc_html($ind[0]); ?></span>
                            <span style="color: <?php echo esc_attr($ind[2]); ?>; font-weight: 700;"><?php echo esc_html(tt_score_label($val) . ' · ' . $val . '%'); ?></span>
                        </div>
                        <div style="background: var(--tt-gray-light); height: 6px; border-radius: 3px; overflow: hidden;">
                            <div style="background: <?php echo esc_attr($ind[2]); ?>; width: <?php echo esc_attr($val); ?>%; height: 100%;"></div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>
            </div>

            <!-- Right Column -->
            <div>
                <div class="tt-card" style="padding: 32px; position: sticky; top: 100px;">
                    <h3 style="font-size: 18px; margin-bottom: 24px; border-bottom: 1px solid var(--tt-gray-border); padding-bottom: 16px;">Sintesi Reputazionale</h3>
                    
                    <?php if (function_exists('tt_render_assigned_badges')) : ?>
                        <div class="tt-sidebar-badges" style="margin-bottom: 24px; border-bottom: 1px dashed var(--tt-gray-border); padding-bottom: 20px;">
                            <?php tt_the_assigned_badges(); ?>
                        </div>
                    <?php endif; ?>
                    
                    <?php if ($voto !== '') : ?>
                    <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 16px;">
                        <span style="color: var(--tt-gray-text);">Voto Medio</span>
                        <span style="font-size: 24px; font-weight: 700;">★ <?php echo esc_html($voto); ?></span>
                    </div>
                    <?php endif; ?>
                    <?php if ($recensioni !== '' && $recensioni !== '0') : ?>
                    <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 16px;">
                        <span style="color: var(--tt-gray-text);">Dati Analizzati</span>
                        <span style="font-weight: 600;"><?php echo esc_html($recensioni); ?> recensioni</span>
                    </div>
                    <?php endif; ?>
                    <?php if ($ai_match !== '') : ?>
                    <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 24px;">
                        <span style="color: var(--tt-gray-text);">AI Match</span>
                        <span style="font-weight: 600; color: var(--tt-success);"><?php echo esc_html($ai_match); ?>%</span>
                    </div>
                    <?php endif; ?>

                    <?php if ($indirizzo || $telefono) : ?>
                        <div style="font-size: 14px; color: var(--tt-gray-text); margin-bottom: 24px; line-height: 1.6;">
                            <?php if ($indirizzo) : ?><div><?php echo esc_html($indirizzo); ?></div><?php endif; ?>
                            <?php if ($telefono) : ?><div><a href="tel:<?php echo esc_attr(preg_replace('/[^0-9+]/', '', $telefono)); ?>"><?php echo esc_html($telefono); ?></a></div><?php endif; ?>
                        </div>
                    <?php endif; ?>

                    <?php if ($website || $email) : ?>
                    <div style="display: flex; flex-direction: column; gap: 12px; margin-bottom: 24px;">
                        <?php if ($website) : ?>
                            <a href="<?php echo esc_url($website); ?>" class="tt-btn tt-btn-primary" style="width: 100%;" target="_blank" rel="noopener nofollow">Visita il Sito Web</a>
                        <?php endif; ?>
                        <?php if ($email) : ?>
                            <a href="<?php echo esc_url('mailto:' . $email); ?>" class="tt-btn tt-btn-outline" style="width: 100%;">Richiedi Informazioni</a>
                        <?php endif; ?>
                    </div>
                    <?php endif; ?>
                    
                    <div style="text-align: center; font-size: 12px; color: var(--tt-gray-text);">
                        Scheda generata algoritmicamente<?php $scan_date = get_post_meta($post_id, '_tt_ai_scan_date', true); echo $scan_date ? ' (analisi del ' . esc_html(mysql2date('d.m.Y', $scan_date)) . ')' : ''; ?>.<br>Nessun pagamento ha influenzato questa posizione.
                    </div>
                </div>
            </div>
            
        </div>
    </section>
</main>
<?php get_footer(); ?>
