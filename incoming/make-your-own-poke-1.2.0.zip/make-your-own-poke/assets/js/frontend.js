/**
 * Make your own Pokè: configuratore lato browser.
 *
 * Il browser mostra il totale e invia le scelte; il prezzo vero lo calcola il server (src/helper.php),
 * con la stessa regola: i primi N ingredienti di ogni gruppo sono inclusi, nell'ordine in cui il cliente
 * li ha scelti, gli altri si pagano. Nessuna dipendenza da jQuery (se c'è, si avvisa WooCommerce
 * dell'aggiunta al carrello con l'evento «added_to_cart», così i frammenti del carrello si aggiornano).
 */
(function () {
	'use strict';

	var settings = window.brtwConfigurator || {};
	var i18n = settings.i18n || {};
	var currency = settings.currency || {};

	function text(key, fallback) {
		return typeof i18n[key] === 'string' ? i18n[key] : fallback;
	}

	function sprintf(format) {
		var args = Array.prototype.slice.call(arguments, 1);
		var i = 0;
		return String(format).replace(/%(\d+\$)?s/g, function (match, pos) {
			var index = pos ? parseInt(pos, 10) - 1 : i++;
			return typeof args[index] === 'undefined' ? '' : args[index];
		});
	}

	function formatPrice(amount) {
		var decimals = typeof currency.decimals === 'number' ? currency.decimals : 2;
		var fixed = (Math.round(amount * Math.pow(10, decimals)) / Math.pow(10, decimals)).toFixed(decimals);
		var parts = fixed.split('.');
		parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, currency.thousand || '\'');
		var number = parts.join(currency.decimal || '.');
		var symbol = currency.symbol || 'CHF';
		switch (currency.position) {
			case 'left': return symbol + number;
			case 'right': return number + symbol;
			case 'right_space': return number + ' ' + symbol;
			default: return symbol + ' ' + number;
		}
	}

	function toNumber(value) {
		var n = parseFloat(String(value || '0').replace(',', '.'));
		return isNaN(n) ? 0 : n;
	}

	function Configurator(root) {
		this.root = root;
		this.form = root.querySelector('[data-brtw-form]');
		this.qty = root.querySelector('[data-brtw-qty]');
		this.total = root.querySelector('[data-brtw-total]');
		this.submit = root.querySelector('[data-brtw-submit]');
		this.notice = root.querySelector('[data-brtw-notice]');
		this.addToCart = root.querySelector('[data-brtw-add-to-cart]');
		this.seq = 0;
		this.busy = false;
		if (!this.form) {
			return;
		}
		this.bind();
		this.setActiveBlock(this.selectedSize(), false);
		this.recalc();
	}

	Configurator.prototype.bind = function () {
		var self = this;
		this.form.addEventListener('change', function (event) {
			var target = event.target;
			if (!(target instanceof HTMLInputElement)) {
				return;
			}
			if (target.name === 'brtw_product') {
				self.setActiveBlock(target, true);
				self.recalc();
			} else if (target.classList.contains('brtw-option__input')) {
				self.onOptionChange(target);
			} else if (target === self.qty) {
				if (toNumber(self.qty.value) < 1) {
					self.qty.value = 1;
				}
				self.recalc();
			}
		});
		this.form.addEventListener('submit', function (event) {
			self.onSubmit(event);
		});
	};

	Configurator.prototype.selectedSize = function () {
		return this.form.querySelector('input[name="brtw_product"]:checked') || this.form.querySelector('input[name="brtw_product"]');
	};

	Configurator.prototype.blocks = function () {
		return Array.prototype.slice.call(this.form.querySelectorAll('.brtw-product-addons'));
	};

	Configurator.prototype.activeBlock = function () {
		return this.form.querySelector('.brtw-product-addons:not([hidden])');
	};

	/** Mostra il blocco di add-on della misura scelta; le scelte già fatte passano alla nuova misura quando l'opzione esiste. */
	Configurator.prototype.setActiveBlock = function (sizeInput, carryOver) {
		if (!sizeInput) {
			return;
		}
		var productId = sizeInput.value;
		var previous = this.activeBlock();
		var chosen = [];
		if (carryOver && previous) {
			Array.prototype.forEach.call(previous.querySelectorAll('.brtw-option__input:checked'), function (input) {
				var group = input.closest('[data-brtw-group]');
				chosen.push({ group: group ? group.getAttribute('data-name') : '', value: input.value, seq: parseInt(input.getAttribute('data-seq') || '0', 10) });
			});
		}
		this.blocks().forEach(function (block) {
			var active = block.getAttribute('data-product') === productId;
			block.hidden = !active;
			Array.prototype.forEach.call(block.querySelectorAll('input'), function (input) {
				input.disabled = !active;
				if (!active) {
					input.checked = false;
					input.removeAttribute('data-seq');
				}
			});
		});
		var current = this.activeBlock();
		if (current && chosen.length) {
			chosen.forEach(function (item) {
				var group = current.querySelector('[data-brtw-group][data-name="' + item.group.replace(/"/g, '\\"') + '"]');
				if (!group) {
					return;
				}
				var input = Array.prototype.filter.call(group.querySelectorAll('.brtw-option__input'), function (candidate) {
					return candidate.value === item.value || candidate.value.indexOf(item.value.replace(/-\d+$/, '') + '-') === 0;
				})[0];
				if (input) {
					input.checked = true;
					input.setAttribute('data-seq', String(item.seq));
				}
			});
		}
		Array.prototype.forEach.call(this.form.querySelectorAll('[data-brtw-size]'), function (label) {
			label.classList.toggle('is-selected', label.getAttribute('data-brtw-size') === productId);
		});
		if (this.addToCart) {
			this.addToCart.value = productId;
		}
		var permalink = sizeInput.getAttribute('data-permalink');
		if (permalink) {
			this.form.setAttribute('action', permalink);
		}
		this.hideNotice();
	};

	Configurator.prototype.onOptionChange = function (input) {
		var group = input.closest('[data-brtw-group]');
		if (input.type === 'radio' && group) {
			Array.prototype.forEach.call(group.querySelectorAll('.brtw-option__input'), function (other) {
				if (other !== input) {
					other.removeAttribute('data-seq');
				}
			});
		}
		if (input.checked) {
			this.seq += 1;
			input.setAttribute('data-seq', String(this.seq));
		} else {
			input.removeAttribute('data-seq');
		}
		if (group) {
			group.classList.remove('is-invalid');
		}
		this.hideNotice();
		this.recalc();
	};

	/** Le opzioni scelte di un gruppo, nell'ordine in cui il cliente le ha cliccate. */
	Configurator.prototype.chosenInGroup = function (group) {
		return Array.prototype.slice.call(group.querySelectorAll('.brtw-option__input:checked')).sort(function (a, b) {
			return parseInt(a.getAttribute('data-seq') || '0', 10) - parseInt(b.getAttribute('data-seq') || '0', 10);
		});
	};

	Configurator.prototype.recalc = function () {
		var size = this.selectedSize();
		var block = this.activeBlock();
		var base = size ? toNumber(size.getAttribute('data-price')) : 0;
		var qty = this.qty ? Math.max(1, Math.floor(toNumber(this.qty.value))) : 1;
		var perUnit = base;
		var flat = 0;

		if (block) {
			Array.prototype.forEach.call(block.querySelectorAll('[data-brtw-group]'), function (group) {
				var included = parseInt(group.getAttribute('data-included') || '0', 10);
				var max = parseInt(group.getAttribute('data-max') || '0', 10);
				var chosen = this.chosenInGroup(group);
				var extras = 0;

				Array.prototype.forEach.call(group.querySelectorAll('.brtw-option'), function (li) {
					li.classList.remove('is-included', 'is-extra');
				});
				chosen.forEach(function (input, index) {
					var li = input.closest('.brtw-option');
					var free = index < included;
					if (li) {
						li.classList.add(free ? 'is-included' : 'is-extra');
					}
					if (free) {
						return;
					}
					extras += 1;
					var price = toNumber(input.getAttribute('data-price'));
					switch (input.getAttribute('data-price-type')) {
						case 'flat_fee': flat += price; break;
						case 'percentage_based': perUnit += base * price / 100; break;
						default: perUnit += price;
					}
				});

				group.classList.toggle('has-free-slots', chosen.length < included);
				group.classList.toggle('has-extras', extras > 0);
				var maxed = max > 0 && chosen.length >= max;
				Array.prototype.forEach.call(group.querySelectorAll('.brtw-option__input'), function (input) {
					if (!input.checked && input.type === 'checkbox') {
						input.disabled = maxed;
						var li = input.closest('.brtw-option');
						if (li) {
							li.classList.toggle('is-maxed', maxed);
						}
					}
				});

				var counter = group.querySelector('[data-brtw-count]');
				var countText = group.getAttribute('data-count-text');
				if (counter && countText) {
					var label = sprintf(countText, Math.min(chosen.length, included));
					if (extras > 0) {
						label += ', ' + extras + ' ' + text('extra', 'extra');
					}
					counter.textContent = label;
				}
			}, this);
		}

		if (this.total) {
			this.total.textContent = formatPrice(perUnit * qty + flat);
		}
	};

	Configurator.prototype.validate = function () {
		var block = this.activeBlock();
		if (!block) {
			return true;
		}
		var groups = Array.prototype.slice.call(block.querySelectorAll('[data-brtw-group]'));
		for (var i = 0; i < groups.length; i++) {
			var group = groups[i];
			var min = parseInt(group.getAttribute('data-min') || '0', 10);
			var count = group.querySelectorAll('.brtw-option__input:checked').length;
			group.classList.remove('is-invalid');
			if (min > 0 && count < min) {
				group.classList.add('is-invalid');
				this.showNotice(sprintf(text('chooseAtLeast', 'Scegli almeno %1$s in «%2$s».'), min, group.getAttribute('data-name') || ''), 'error');
				group.scrollIntoView({ behavior: 'smooth', block: 'center' });
				var first = group.querySelector('.brtw-option__input');
				if (first) {
					first.focus({ preventScroll: true });
				}
				return false;
			}
		}
		return true;
	};

	Configurator.prototype.showNotice = function (message, type, link) {
		if (!this.notice) {
			return;
		}
		this.notice.textContent = '';
		this.notice.appendChild(document.createTextNode(message));
		if (link && link.href) {
			this.notice.appendChild(document.createTextNode(' '));
			var a = document.createElement('a');
			a.href = link.href;
			a.className = 'brtw-notice__link';
			a.textContent = link.label;
			this.notice.appendChild(a);
		}
		this.notice.className = 'brtw-notice brtw-notice--' + (type || 'info');
		this.notice.hidden = false;
	};

	Configurator.prototype.hideNotice = function () {
		if (this.notice) {
			this.notice.hidden = true;
			this.notice.textContent = '';
		}
	};

	Configurator.prototype.setBusy = function (busy) {
		this.busy = busy;
		if (this.submit) {
			this.submit.disabled = busy;
			this.submit.classList.toggle('is-busy', busy);
		}
		this.root.classList.toggle('is-busy', busy);
	};

	/** Invio: lo stesso endpoint di WooCommerce (wc-ajax add_to_cart), con i campi addon-* di Product Add-ons. */
	Configurator.prototype.onSubmit = function (event) {
		if (this.busy) {
			event.preventDefault();
			return;
		}
		if (!this.validate()) {
			event.preventDefault();
			return;
		}
		if (!settings.ajaxUrl || typeof window.fetch !== 'function' || typeof window.FormData !== 'function') {
			return; // invio classico del modulo al permalink del prodotto
		}
		event.preventDefault();

		var self = this;
		var size = this.selectedSize();
		var block = this.activeBlock();
		var body = new FormData();
		body.append('product_id', size ? size.value : '');
		body.append('quantity', this.qty ? String(Math.max(1, Math.floor(toNumber(this.qty.value)))) : '1');
		if (block) {
			Array.prototype.forEach.call(block.querySelectorAll('[data-brtw-group]'), function (group) {
				self.chosenInGroup(group).forEach(function (input) {
					body.append(input.name, input.value);
				});
			});
		}

		this.setBusy(true);
		this.showNotice(text('adding', 'Aggiungo al carrello…'), 'info');

		window.fetch(settings.ajaxUrl, { method: 'POST', body: body, credentials: 'same-origin' })
			.then(function (response) { return response.json(); })
			.then(function (data) {
				self.setBusy(false);
				if (!data || data.error) {
					self.showNotice(text('error', 'Non è stato possibile aggiungere il piatto al carrello.'), 'error', data && data.product_url ? { href: data.product_url, label: text('openProduct', 'Apri la scheda del prodotto') } : null);
					return;
				}
				if (data.fragments) {
					Object.keys(data.fragments).forEach(function (selector) {
						Array.prototype.forEach.call(document.querySelectorAll(selector), function (el) {
							el.outerHTML = data.fragments[selector];
						});
					});
				}
				if (window.jQuery) {
					window.jQuery(document.body).trigger('added_to_cart', [data.fragments, data.cart_hash, window.jQuery(self.submit)]);
				}
				document.dispatchEvent(new CustomEvent('brtw:added_to_cart', { detail: data }));
				if (settings.redirect && settings.cartUrl) {
					window.location.href = settings.cartUrl;
					return;
				}
				self.showNotice(text('added', 'Aggiunto al carrello.'), 'success', settings.cartUrl ? { href: settings.cartUrl, label: text('viewCart', 'Vai al carrello') } : null);
			})
			.catch(function () {
				self.setBusy(false);
				self.showNotice(text('error', 'Non è stato possibile aggiungere il piatto al carrello.'), 'error');
			});
	};

	function init() {
		Array.prototype.forEach.call(document.querySelectorAll('[data-brtw-configurator]'), function (root) {
			if (!root.brtwConfigurator) {
				root.brtwConfigurator = new Configurator(root);
			}
		});
	}

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', init);
	} else {
		init();
	}
	// Elementor: dopo il render nell'editor o nei contenuti caricati dopo.
	if (window.jQuery) {
		window.jQuery(window).on('elementor/frontend/init', function () {
			if (window.elementorFrontend && window.elementorFrontend.hooks) {
				window.elementorFrontend.hooks.addAction('frontend/element_ready/brtw-personalized.default', init);
			}
		});
	}
})();
