<?php
/**
 * Make your own Pokè: il configuratore (markup) e lo shortcode [make_your_own_poke].
 *
 * Il render stampa le misure (prodotti della categoria) e, per OGNI misura, il blocco dei suoi gruppi
 * di add-on (data-product): lo script mostra solo il blocco della misura scelta, senza ricaricare la
 * pagina e senza chiamate al server. Il modulo è un normale modulo «cart» di WooCommerce: i campi
 * addon-<prodotto>-<gruppo> sono quelli di Product Add-ons, che li legge e li salva nel carrello;
 * il prezzo lo fa il server (src/helper.php), il browser lo mostra soltanto.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/** Accoda CSS e JS del configuratore (una volta sola). */
function brtw_enqueue_assets() {
    if ( ! wp_style_is( 'brtw-utilities-base', 'registered' ) ) {
        wp_register_style( 'brtw-utilities-base', BRTW_URI . 'assets/css/base.css', array(), BRTW_VERSION );
    }
    if ( ! wp_script_is( 'brtw-frontend', 'registered' ) ) {
        wp_register_script( 'brtw-frontend', BRTW_URI . 'assets/js/frontend.js', array(), BRTW_VERSION, true );
        wp_localize_script( 'brtw-frontend', 'brtwConfigurator', brtw_frontend_settings() );
    }
    wp_enqueue_style( 'brtw-utilities-base' );
    wp_enqueue_script( 'brtw-frontend' );
}

/** Argomenti di default del configuratore (gli stessi dello shortcode). */
function brtw_configurator_default_args() {
    $categories = brtw_configurator_categories();
    return array(
        'categoria'  => $categories ? $categories[0] : 'crea-la-tua-poke',
        'per_pagina' => 4,
        'orderby'    => 'price',
        'order'      => 'ASC',
    );
}

/**
 * I prodotti (misure) del configuratore.
 *
 * @param array $args categoria, per_pagina, orderby (price|title|menu_order|date|id), order (ASC|DESC).
 * @return WC_Product[]
 */
function brtw_configurator_products( $args = array() ) {
    $args    = wp_parse_args( $args, brtw_configurator_default_args() );
    $orderby = in_array( $args['orderby'], array( 'price', 'title', 'menu_order', 'date', 'id' ), true ) ? $args['orderby'] : 'price';
    $order   = strtoupper( (string) $args['order'] ) === 'DESC' ? 'DESC' : 'ASC';
    $limit   = max( 1, min( 20, (int) $args['per_pagina'] ) );

    $query = array(
        'status'     => 'publish',
        'limit'      => $limit,
        'category'   => array( sanitize_title( $args['categoria'] ) ),
        'order'      => $order,
    );
    if ( 'price' === $orderby ) {
        $query['orderby']  = 'meta_value_num';
        $query['meta_key'] = '_price'; // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
    } else {
        $query['orderby'] = $orderby;
    }
    $products = wc_get_products( $query );
    return array_values( array_filter( (array) $products, function ( $product ) {
        return $product instanceof WC_Product && $product->is_purchasable();
    } ) );
}

/**
 * Il configuratore completo: misure, gruppi di add-on di ogni misura, totale e «Aggiungi al carrello».
 *
 * @param array $args categoria (slug, default crea-la-tua-poke), per_pagina (4), orderby (price), order (ASC).
 * @return string HTML (escapato), vuoto senza WooCommerce.
 */
function brtw_render_configurator( $args = array() ) {
    if ( ! function_exists( 'wc_get_products' ) ) {
        return '<!-- Make your own Pokè: WooCommerce non è attivo -->';
    }
    $args     = wp_parse_args( $args, brtw_configurator_default_args() );
    $products = brtw_configurator_products( $args );
    if ( ! $products ) {
        return '<!-- Make your own Pokè: nessun prodotto nella categoria «' . esc_html( $args['categoria'] ) . '» -->';
    }
    brtw_enqueue_assets();

    $has_addons = class_exists( 'WC_Product_Addons_Helper' );
    $first      = $products[0];
    $uid        = 'brtw-' . wp_unique_id();

    ob_start();
    ?>
    <div class="brtw-configurator" id="<?php echo esc_attr( $uid ); ?>" data-brtw-configurator>
        <form class="brtw-form cart" method="post" action="<?php echo esc_url( $first->get_permalink() ); ?>" enctype="multipart/form-data" data-brtw-form>
            <fieldset class="brtw-sizes">
                <legend class="brtw-sizes__title"><?php esc_html_e( 'Scegli la misura', 'ticinoweb' ); ?></legend>
                <div class="brtw-sizes__list">
                    <?php foreach ( $products as $index => $product ) : ?>
                        <?php echo brtw_render_size( $product, $uid, 0 === $index ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escapato nella funzione ?>
                    <?php endforeach; ?>
                </div>
            </fieldset>

            <div class="brtw-addons-wrapper" data-brtw-addons>
                <?php if ( $has_addons ) : ?>
                    <?php foreach ( $products as $index => $product ) : ?>
                        <?php echo brtw_render_product_addons( $product, 0 === $index ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escapato nella funzione ?>
                    <?php endforeach; ?>
                <?php else : ?>
                    <!-- Make your own Pokè: WooCommerce Product Add-ons non è attivo, gli ingredienti non si possono mostrare -->
                <?php endif; ?>
            </div>

            <div class="brtw-summary" data-brtw-summary>
                <div class="brtw-summary__row">
                    <label class="brtw-summary__qty">
                        <span class="brtw-summary__qty-label"><?php esc_html_e( 'Quantità', 'ticinoweb' ); ?></span>
                        <input class="brtw-summary__qty-input qty" type="number" name="quantity" value="1" min="1" step="1" inputmode="numeric" autocomplete="off" data-brtw-qty>
                    </label>
                    <div class="brtw-summary__total">
                        <span class="brtw-summary__total-label"><?php esc_html_e( 'Totale', 'ticinoweb' ); ?></span>
                        <span class="brtw-summary__total-price" data-brtw-total><?php echo wp_kses_post( wc_price( (float) $first->get_price() ) ); ?></span>
                    </div>
                </div>
                <button type="submit" class="<?php echo esc_attr( apply_filters( 'brtw_submit_button_class', 'brtw-submit button alt' ) ); ?>" data-brtw-submit><?php esc_html_e( 'Aggiungi al carrello', 'ticinoweb' ); ?></button>
                <p class="brtw-notice" role="status" aria-live="polite" data-brtw-notice hidden></p>
            </div>

            <input type="hidden" name="add-to-cart" value="<?php echo esc_attr( $first->get_id() ); ?>" data-brtw-add-to-cart>
        </form>
    </div>
    <?php
    // Via l'indentazione del template: con 4 misure × 5 gruppi × 15 opzioni pesa più del contenuto.
    return (string) preg_replace( '/\n[ \t]+/', "\n", (string) ob_get_clean() );
}

/**
 * Una misura (prodotto) come scheda selezionabile.
 *
 * @param WC_Product $product
 * @param string     $uid     id del configuratore (per gli id dei campi).
 * @param bool       $checked misura scelta all'avvio.
 */
function brtw_render_size( $product, $uid, $checked = false ) {
    $id     = (int) $product->get_id();
    $price  = (float) $product->get_price();
    $thumb  = $product->get_image( 'woocommerce_thumbnail', array( 'class' => 'brtw-size__img', 'loading' => 'lazy' ), false );
    $short  = trim( wp_strip_all_tags( (string) $product->get_short_description() ) );
    ob_start();
    ?>
    <label class="brtw-size<?php echo $checked ? ' is-selected' : ''; ?>" for="<?php echo esc_attr( $uid . '-size-' . $id ); ?>" data-brtw-size="<?php echo esc_attr( $id ); ?>">
        <input class="brtw-size__input" type="radio" id="<?php echo esc_attr( $uid . '-size-' . $id ); ?>" name="brtw_product" value="<?php echo esc_attr( $id ); ?>" data-price="<?php echo esc_attr( wc_format_decimal( $price, wc_get_price_decimals() ) ); ?>" data-permalink="<?php echo esc_url( $product->get_permalink() ); ?>"<?php checked( $checked ); ?>>
        <?php if ( $thumb ) : ?>
            <span class="brtw-size__media"><?php echo wp_kses_post( $thumb ); ?></span>
        <?php endif; ?>
        <span class="brtw-size__body">
            <span class="brtw-size__name"><?php echo esc_html( $product->get_name() ); ?></span>
            <?php if ( $short !== '' ) : ?>
                <span class="brtw-size__desc"><?php echo esc_html( $short ); ?></span>
            <?php endif; ?>
        </span>
        <span class="brtw-size__price"><?php echo wp_kses_post( wc_price( $price ) ); ?></span>
        <span class="brtw-size__check" aria-hidden="true"></span>
    </label>
    <?php
    return (string) ob_get_clean();
}

/**
 * Il blocco dei gruppi di add-on di una misura (nascosto e disattivato finché la misura non è scelta).
 *
 * @param WC_Product $product
 * @param bool       $active  true per la misura scelta all'avvio.
 */
function brtw_render_product_addons( $product, $active = false ) {
    $product_id = (int) $product->get_id();
    $groups     = brtw_product_addon_groups( $product_id );
    ob_start();
    ?>
    <div class="brtw-product-addons" data-product="<?php echo esc_attr( $product_id ); ?>"<?php echo $active ? '' : ' hidden'; ?>>
        <?php if ( ! $groups ) : ?>
            <p class="brtw-empty"><?php esc_html_e( 'Questa misura non ha ingredienti da scegliere.', 'ticinoweb' ); ?></p>
        <?php endif; ?>
        <?php foreach ( $groups as $field_name => $group ) : ?>
            <?php echo brtw_render_addon_group( $group, $product_id, $active ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escapato nella funzione ?>
        <?php endforeach; ?>
    </div>
    <?php
    return (string) ob_get_clean();
}

/** Riga «2 incluse, poi + CHF 4.00» di un gruppo. */
function brtw_group_rule_text( $group ) {
    $included = (int) $group['brtw_included'];
    $extra    = (float) $group['brtw_extra'];
    $name     = isset( $group['name'] ) ? $group['name'] : '';
    if ( $extra <= 0 ) {
        return __( 'Quante ne vuoi, incluse nel prezzo', 'ticinoweb' );
    }
    $price = html_entity_decode( wp_strip_all_tags( wc_price( $extra ) ), ENT_QUOTES, 'UTF-8' );
    if ( $included <= 0 ) {
        /* translators: %s: prezzo di ogni ingrediente */
        return sprintf( __( '+ %s l\'uno', 'ticinoweb' ), $price );
    }
    /* translators: 1: «2 incluse», 2: prezzo dell'extra */
    return sprintf( __( '%1$s, poi + %2$s', 'ticinoweb' ), brtw_included_label( $included, $name ), $price );
}

/**
 * Un gruppo di add-on: titolo, regola, contatore e opzioni (caselle o scelta singola).
 *
 * @param array $group      Gruppo da brtw_product_addon_groups().
 * @param int   $product_id Misura.
 * @param bool  $active     Se false i campi sono disattivati (non si inviano).
 */
function brtw_render_addon_group( $group, $product_id, $active = false ) {
    $name       = isset( $group['name'] ) ? (string) $group['name'] : '';
    $desc       = isset( $group['description'] ) ? trim( wp_strip_all_tags( (string) $group['description'] ) ) : '';
    $included   = (int) $group['brtw_included'];
    $extra      = (float) $group['brtw_extra'];
    $multiple   = ! empty( $group['brtw_multiple'] );
    $input_type = $multiple ? 'checkbox' : 'radio';
    $field_id   = 'brtw-' . sanitize_title( $group['field_name'] );
    $count_text = $included > 0
        /* translators: %s: segnaposto del numero scelto (lo riempie lo script), poi «di 2 incluse» */
        ? brtw_text( sprintf( __( '%1$s di %2$s', 'ticinoweb' ), '%s', brtw_included_label( $included, $name ) ), 'count:' . sanitize_title( $name ) )
        : '';
    ob_start();
    ?>
    <section class="brtw-addons" data-brtw-group data-field="<?php echo esc_attr( $group['field_name'] ); ?>" data-name="<?php echo esc_attr( brtw_text( $name, 'group:' . sanitize_title( $name ) ) ); ?>" data-included="<?php echo esc_attr( $included ); ?>" data-min="<?php echo esc_attr( (int) $group['brtw_min'] ); ?>" data-max="<?php echo esc_attr( (int) $group['brtw_max'] ); ?>" data-multiple="<?php echo $multiple ? '1' : '0'; ?>" data-count-text="<?php echo esc_attr( $count_text ); ?>" aria-labelledby="<?php echo esc_attr( $field_id . '-title' ); ?>">
        <header class="brtw-addons__head">
            <h3 class="brtw-addons__title" id="<?php echo esc_attr( $field_id . '-title' ); ?>">
                <?php echo esc_html( $name ); ?>
                <?php if ( (int) $group['brtw_min'] > 0 ) : ?>
                    <span class="brtw-addons__required" title="<?php esc_attr_e( 'Scelta obbligatoria', 'ticinoweb' ); ?>">*</span>
                <?php endif; ?>
            </h3>
            <p class="brtw-addons__rule"><?php echo esc_html( brtw_group_rule_text( $group ) ); ?></p>
            <?php if ( $desc !== '' ) : ?>
                <p class="brtw-addons__desc"><?php echo esc_html( $desc ); ?></p>
            <?php endif; ?>
            <?php if ( $count_text !== '' ) : ?>
                <span class="brtw-addons__count" data-brtw-count><?php echo esc_html( sprintf( $count_text, 0 ) ); ?></span>
            <?php endif; ?>
        </header>
        <ul class="brtw-options">
            <?php foreach ( $group['options'] as $index => $option ) : ?>
                <?php
                $label      = isset( $option['label'] ) ? (string) $option['label'] : '';
                $price      = isset( $option['price'] ) && $option['price'] !== '' ? (float) $option['price'] : 0.0;
                $price_type = ! empty( $option['price_type'] ) ? $option['price_type'] : 'quantity_based';
                $value      = brtw_option_value( $group, $index, $option );
                $input_id   = $field_id . '-' . (int) $index;
                ?>
                <li class="brtw-option">
                    <label class="brtw-option__label" for="<?php echo esc_attr( $input_id ); ?>">
                        <input class="brtw-option__input" type="<?php echo esc_attr( $input_type ); ?>" id="<?php echo esc_attr( $input_id ); ?>" name="<?php echo esc_attr( $group['brtw_input_name'] ); ?>" value="<?php echo esc_attr( $value ); ?>" data-price="<?php echo esc_attr( wc_format_decimal( $price, wc_get_price_decimals() ) ); ?>" data-price-type="<?php echo esc_attr( $price_type ); ?>"<?php disabled( ! $active ); ?>>
                        <span class="brtw-option__check" aria-hidden="true"></span>
                        <span class="brtw-option__name"><?php echo esc_html( $label ); ?></span>
                        <?php if ( $price > 0 ) : ?>
                            <span class="brtw-option__price" data-brtw-option-price>+ <?php echo wp_kses_post( wc_price( $price ) ); ?></span>
                        <?php endif; ?>
                    </label>
                </li>
            <?php endforeach; ?>
        </ul>
    </section>
    <?php
    return (string) ob_get_clean();
}

/**
 * Shortcode [make_your_own_poke categoria="crea-la-tua-poke" per_pagina="4" ordine="ASC" orderby="price"].
 */
function brtw_shortcode_make_your_own_poke( $atts ) {
    $defaults = brtw_configurator_default_args();
    $atts     = shortcode_atts( array(
        'categoria'  => $defaults['categoria'],
        'per_pagina' => $defaults['per_pagina'],
        'ordine'     => $defaults['order'],
        'orderby'    => $defaults['orderby'],
    ), $atts, 'make_your_own_poke' );

    return brtw_render_configurator( array(
        'categoria'  => sanitize_title( $atts['categoria'] ),
        'per_pagina' => (int) $atts['per_pagina'],
        'orderby'    => sanitize_key( $atts['orderby'] ),
        'order'      => strtoupper( sanitize_key( $atts['ordine'] ) ),
    ) );
}
add_shortcode( 'make_your_own_poke', 'brtw_shortcode_make_your_own_poke' );
