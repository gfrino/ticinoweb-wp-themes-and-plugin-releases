<?php
/**
 * OpenAI Chat Completions client, alternative translation engine.
 *
 * Same contract as Twtr_Google (translate_batch / test_connection /
 * last_error) so the queue can use either one interchangeably. Pure REST via
 * wp_remote_*: no SDK. Never called during a normal frontend visit — only
 * from the background queue, WP-CLI or explicit admin actions.
 *
 * Batches travel as JSON in and JSON out: the model receives an array of
 * segments and must return exactly as many translations, in order. The
 * site's glossary cannot be a Google resource here, so the terms that
 * actually appear in the batch are injected into the system prompt.
 *
 * @package tw-translate-plus
 */

if (!defined('ABSPATH')) {
    exit;
}

class Twtr_Openai {

    const TIMEOUT = 90;

    /** @var Twtr_Openai|null */
    private static $instance = null;

    /** @var string|null */
    private $last_error = null;

    /**
     * @return Twtr_Openai
     */
    public static function instance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * @return string|null Last human-readable error (no secrets, no content).
     */
    public function last_error() {
        return $this->last_error;
    }

    /**
     * Translate a batch of HTML strings.
     *
     * @param string[] $texts       Source strings (HTML allowed).
     * @param string   $source_lang Language slug of the source.
     * @param string   $target_lang Language slug of the target.
     * @return string[]|WP_Error Translations in the same order.
     */
    public function translate_batch($texts, $source_lang, $target_lang) {
        $cfg = Twtr_Settings::openai_config();
        if (!Twtr_Settings::engine_ready()) {
            return new WP_Error('twtr_config', Twtr_Settings::engine_missing_reason());
        }
        $texts = array_values($texts);
        $count = count($texts);
        if ($count === 0) {
            return array();
        }

        $payload = $this->build_payload($texts, $source_lang, $target_lang);
        $resp    = $this->request('POST', '/chat/completions', $payload);

        // Reasoning models reject a custom temperature: retry once with the
        // model default rather than failing the whole batch.
        if (is_wp_error($resp) && $resp->get_error_code() === 'twtr_http_400'
            && stripos($resp->get_error_message(), 'temperature') !== false) {
            unset($payload['temperature']);
            $resp = $this->request('POST', '/chat/completions', $payload);
        }
        // Some compatible servers do not implement JSON mode: the prompt
        // already demands a JSON object, so ask again without it.
        if (is_wp_error($resp) && $resp->get_error_code() === 'twtr_http_400'
            && stripos($resp->get_error_message(), 'response_format') !== false
            && Twtr_Settings::provider() === 'compat') {
            unset($payload['response_format']);
            $resp = $this->request('POST', '/chat/completions', $payload);
        }
        if (is_wp_error($resp)) {
            return $resp;
        }
        return $this->parse_completion($resp, $count);
    }

    /**
     * Chat payload for one batch.
     *
     * @param string[] $texts
     * @param string   $source_lang
     * @param string   $target_lang
     * @return array
     */
    private function build_payload($texts, $source_lang, $target_lang) {
        $cfg     = Twtr_Settings::openai_config();
        $payload = array(
            'model'           => $cfg['model'],
            'temperature'     => 0,
            'response_format' => array('type' => 'json_object'),
            'messages'        => array(
                array('role' => 'system', 'content' => $this->system_prompt($source_lang, $target_lang, $texts)),
                array('role' => 'user',   'content' => self::json(array('segments' => array_values($texts)))),
            ),
        );

        // gpt-oss and other reasoning models think before answering: for a
        // translation little reasoning is needed, and less is faster and
        // cheaper. Sent only where the parameter is known to be accepted.
        if (Twtr_Settings::provider() === 'compat') {
            $host = (string) wp_parse_url($cfg['base_url'], PHP_URL_HOST);
            if (substr($host, -strlen('openrouter.ai')) === 'openrouter.ai') {
                $payload['reasoning'] = array('effort' => 'low', 'exclude' => true);
                $payload['provider']  = (array) apply_filters('twtr_openrouter_provider', array('sort' => 'throughput'));
            } elseif (substr($host, -strlen('groq.com')) === 'groq.com') {
                $payload['reasoning_effort'] = 'low';
            }
        }
        return $payload;
    }

    /**
     * Extract the translated segments from a chat completion.
     *
     * @param array $resp  Decoded response.
     * @param int   $count Expected segments.
     * @return string[]|WP_Error
     */
    private function parse_completion($resp, $count) {
        if (isset($resp['choices'][0]['finish_reason']) && $resp['choices'][0]['finish_reason'] === 'length') {
            $this->last_error = __('Risposta OpenAI troncata: il testo supera la lunghezza massima che il modello può restituire in una volta. Prova un modello con output più ampio, oppure spezza il contenuto troppo lungo.', 'tw-translate-plus');
            return new WP_Error('twtr_response', $this->last_error);
        }

        $content = isset($resp['choices'][0]['message']['content']) ? (string) $resp['choices'][0]['message']['content'] : '';
        $decoded = json_decode($content, true);
        if (!is_array($decoded) && preg_match('/\{.*\}/s', $content, $m)) {
            // Open models sometimes wrap the JSON in prose or code fences.
            $decoded = json_decode($m[0], true);
        }
        $list    = isset($decoded['segments']) && is_array($decoded['segments']) ? array_values($decoded['segments']) : null;

        if ($list === null || count($list) !== $count) {
            $this->last_error = sprintf(
                /* translators: 1: expected segment count, 2: received segment count. */
                __('Risposta OpenAI non allineata: attesi %1$d segmenti, ricevuti %2$d. La coda riproverà.', 'tw-translate-plus'),
                $count,
                is_array($list) ? count($list) : 0
            );
            return new WP_Error('twtr_misaligned', $this->last_error);
        }

        $out = array();
        foreach ($list as $i => $value) {
            $out[$i] = is_scalar($value) ? (string) $value : '';
        }
        return $out;
    }

    /**
     * Translate several batches at once: the requests travel in parallel
     * (one round trip instead of one per batch), which is what makes
     * «Traduci adesso» take seconds instead of a minute. A batch that fails
     * here with anything but a plain answer (misaligned, a 400 to adapt to,
     * network) is returned as an error; the caller retries it alone through
     * translate_batch(), which knows how to adapt and split.
     *
     * @param array $jobs Each: array(texts[], source, target).
     * @return array<int,string[]|WP_Error> Same keys as $jobs.
     */
    public function translate_many($jobs) {
        $cfg = Twtr_Settings::openai_config();
        $out = array();
        if (!Twtr_Settings::engine_ready()) {
            foreach (array_keys($jobs) as $k) {
                $out[$k] = new WP_Error('twtr_config', Twtr_Settings::engine_missing_reason());
            }
            return $out;
        }
        $url = rtrim($cfg['base_url'], '/') . '/chat/completions';
        if (Twtr_Settings::provider() === 'compat' && !wp_http_validate_url($url)) {
            foreach (array_keys($jobs) as $k) {
                $out[$k] = new WP_Error('twtr_network', __('Indirizzo del motore non consentito (rete interna).', 'tw-translate-plus'));
            }
            return $out;
        }
        $left    = class_exists('Twtr_Queue') ? Twtr_Queue::time_left() - 3 : self::TIMEOUT;
        $timeout = (int) max(5, min(self::TIMEOUT, $left));
        $headers = array('Content-Type' => 'application/json; charset=utf-8');
        if ($cfg['api_key'] !== '') {
            $headers['Authorization'] = 'Bearer ' . $cfg['api_key'];
        }
        $requests = array();
        foreach ($jobs as $k => $job) {
            $requests[$k] = array(
                'url'     => $url,
                'type'    => 'POST',
                'headers' => $headers,
                'data'    => self::json($this->build_payload($job[0], $job[1], $job[2])),
                'options' => array('timeout' => $timeout, 'connect_timeout' => 10),
            );
        }
        $responses = \WpOrg\Requests\Requests::request_multiple($requests, array('timeout' => $timeout, 'connect_timeout' => 10));
        foreach ($jobs as $k => $job) {
            $r = isset($responses[$k]) ? $responses[$k] : null;
            if (!($r instanceof \WpOrg\Requests\Response)) {
                $out[$k] = new WP_Error('twtr_network', __('Errore di rete verso il motore di traduzione (timeout).', 'tw-translate-plus'));
                continue;
            }
            $decoded = json_decode($r->body, true);
            if ($r->status_code < 200 || $r->status_code >= 300) {
                $msg     = Twtr_Settings::provider() === 'compat' ? $this->compat_error($r->status_code, $decoded) : self::friendly_error($r->status_code, $decoded);
                $out[$k] = new WP_Error('twtr_http_' . $r->status_code, $msg);
                continue;
            }
            $out[$k] = $this->parse_completion(is_array($decoded) ? $decoded : array(), count($job[0]));
        }
        return $out;
    }

    /**
     * Lightweight connectivity/permission test.
     *
     * @return true|WP_Error
     */
    public function test_connection() {
        $result = $this->translate_batch(array('Buongiorno'), 'it', 'en');
        if (is_wp_error($result)) {
            return $result;
        }
        return true;
    }

    /**
     * Model ids available to this API key, filtered to the ones that can
     * plausibly hold a chat conversation.
     *
     * The filter is a deny-list, not an allow-list: OpenAI keeps publishing
     * new chat models and an allow-list would hide them until someone
     * updated the plugin — exactly the problem this feature exists to solve.
     * So anything that is not recognisably an embedding, audio, image or
     * moderation model stays in.
     *
     * @return string[]|WP_Error Sorted model ids.
     */
    public function list_models() {
        if (!Twtr_Settings::engine_ready()) {
            return new WP_Error('twtr_config', __('Chiave API OpenAI non configurata: salvala prima di aggiornare l\'elenco dei modelli.', 'tw-translate-plus'));
        }
        $resp = $this->request('GET', '/models');
        if (is_wp_error($resp)) {
            return $resp;
        }
        if (empty($resp['data']) || !is_array($resp['data'])) {
            $this->last_error = __('Risposta OpenAI inattesa: elenco dei modelli vuoto.', 'tw-translate-plus');
            return new WP_Error('twtr_response', $this->last_error);
        }

        $models = array();
        foreach ($resp['data'] as $item) {
            $id = isset($item['id']) ? (string) $item['id'] : '';
            if ($id !== '' && !self::is_non_chat_model($id)) {
                $models[] = $id;
            }
        }
        $models = array_values(array_unique($models));
        sort($models, SORT_NATURAL);
        return $models;
    }

    /**
     * @param string $id Model id.
     * @return bool Whether the id is clearly not a chat model.
     */
    private static function is_non_chat_model($id) {
        $id = strtolower($id);
        $excluded = array(
            'embedding', 'moderation', 'tts', 'whisper', 'audio', 'realtime',
            'transcribe', 'dall-e', 'image', 'sora', 'guard',
            'davinci', 'babbage', 'curie', 'ada',
        );
        foreach ($excluded as $needle) {
            if (strpos($id, $needle) !== false) {
                return true;
            }
        }
        return false;
    }

    /**
     * Instructions for the model. Deliberately explicit about structure:
     * a lost or merged segment would silently shift every translation in the
     * batch onto the wrong row.
     *
     * @param string   $source_lang
     * @param string   $target_lang
     * @param string[] $texts
     * @return string
     */
    private function system_prompt($source_lang, $target_lang, $texts) {
        $source = Twtr_Settings::language_name($source_lang);
        $target = Twtr_Settings::language_name($target_lang);
        $count  = count($texts);

        $lines = array(
            sprintf('You are a professional translator working on a WordPress website. Translate from %1$s to %2$s.', $source, $target),
            '',
            'Output format (strict):',
            sprintf('- Reply with a JSON object {"segments": [...]} containing exactly %d strings, in the same order as the input.', $count),
            '- Never merge, split, drop, reorder or add segments. An empty input segment stays an empty output segment.',
            '- No explanations, no markdown fences, no comments.',
            '',
            'Translation rules:',
            '- Segments may contain HTML. Reproduce every tag, attribute, HTML entity, shortcode ([...]) and placeholder (%s, %1$s, {{...}}) exactly as received; translate only the human-readable text.',
            '- Preserve leading and trailing whitespace of each segment.',
            '- Do not translate URLs, file paths, e-mail addresses, CSS classes, brand and product names.',
            '- Keep the register and tone of the original; use the wording conventional for the target language on commercial websites.',
            '- Translate the text even when a segment is a single word or looks like a UI label.',
        );

        $glossary = $this->glossary_lines($target_lang, $texts);
        if ($glossary) {
            $lines[] = '';
            $lines[] = 'Glossary — these terms MUST be rendered exactly as specified (match is case-insensitive, keep the original capitalisation style of the sentence):';
            foreach ($glossary as $line) {
                $lines[] = $line;
            }
        }
        return implode("\n", $lines);
    }

    /**
     * Glossary entries worth spending prompt tokens on: only the terms that
     * actually occur in this batch, capped so a large glossary cannot
     * outgrow the content being translated.
     *
     * @param string   $target_lang
     * @param string[] $texts
     * @return string[]
     */
    private function glossary_lines($target_lang, $texts) {
        twtr_glossary();
        $terms = Twtr_Glossary::terms_for($target_lang);
        if (!$terms) {
            return array();
        }
        $haystack = implode("\n", $texts);
        $lines    = array();
        foreach ($terms as $source => $translation) {
            if (mb_stripos($haystack, (string) $source) === false) {
                continue;
            }
            $lines[] = sprintf('- "%s" -> "%s"', $source, $translation);
            if (count($lines) >= 60) {
                break;
            }
        }
        return $lines;
    }

    /**
     * Authenticated request with limited retry (backoff on 429/5xx/network).
     *
     * @param string     $method  HTTP method.
     * @param string     $path    Path under the API base, e.g. /chat/completions.
     * @param array|null $payload JSON body, null for a bodyless request.
     * @return array|WP_Error Decoded JSON response.
     */
    private function request($method, $path, $payload = null) {
        $cfg  = Twtr_Settings::openai_config();
        $url  = rtrim($cfg['base_url'], '/') . $path;
        $compat = Twtr_Settings::provider() === 'compat';
        $args   = array(
            'method'  => $method,
            'timeout' => self::TIMEOUT,
            'headers' => array(),
        );
        if ($cfg['api_key'] !== '') {
            $args['headers']['Authorization'] = 'Bearer ' . $cfg['api_key'];
        }
        if ($payload !== null) {
            $args['headers']['Content-Type'] = 'application/json; charset=utf-8';
            $args['body'] = self::json($payload);
        }

        $attempts = 0;
        do {
            if ($attempts > 0) {
                usleep((int) (1000000 * pow(2, $attempts - 1))); // 1s, 2s backoff.
            }
            // Fit the request inside the queue run's deadline (the web
            // server kills requests that run too long).
            $left = class_exists('Twtr_Queue') ? Twtr_Queue::time_left() - 3 : self::TIMEOUT;
            if ($attempts > 0 && $left < 10) {
                break;
            }
            $args['timeout'] = (int) max(5, min(self::TIMEOUT, $left));
            $attempts++;
            // The compatible engine's address is typed in the admin: refuse
            // internal hosts (wp_safe_*), unless allowed through the core
            // filter http_request_host_is_external (e.g. a LAN Ollama).
            $resp = $compat ? wp_safe_remote_request($url, $args) : wp_remote_request($url, $args);
            $code = is_wp_error($resp) ? 0 : (int) wp_remote_retrieve_response_code($resp);
            $retryable = is_wp_error($resp) || $code === 429 || $code >= 500;
        } while ($retryable && $attempts < 3);

        if (is_wp_error($resp)) {
            $this->last_error = sprintf(
                /* translators: %s: engine name (OpenAI or the compatible server). */
                __('Errore di rete verso %s (timeout, DNS o indirizzo non raggiungibile).', 'tw-translate-plus'),
                Twtr_Settings::provider() === 'compat' ? Twtr_Settings::compat_config()['base_url'] : 'OpenAI'
            );
            return new WP_Error('twtr_network', $this->last_error);
        }
        $decoded = json_decode(wp_remote_retrieve_body($resp), true);
        if ($code >= 200 && $code < 300) {
            $this->last_error = null;
            return is_array($decoded) ? $decoded : array();
        }

        $this->last_error = $compat ? $this->compat_error($code, $decoded) : self::friendly_error($code, $decoded);
        return new WP_Error('twtr_http_' . $code, $this->last_error);
    }

    /**
     * Errors of the compatible engine, in plain words and naming the
     * service actually used (never "OpenAI" for an OpenRouter key).
     *
     * @param int        $code
     * @param array|null $decoded
     * @return string
     */
    private function compat_error($code, $decoded) {
        $cfg     = Twtr_Settings::compat_config();
        $host    = (string) wp_parse_url($cfg['base_url'], PHP_URL_HOST);
        $api_msg = isset($decoded['error']['message']) ? mb_substr((string) $decoded['error']['message'], 0, 200) : '';
        $is_or   = substr($host, -strlen('openrouter.ai')) === 'openrouter.ai';

        switch ($code) {
            case 401:
            case 403:
                if ($is_or && $cfg['api_key'] !== '' && self::openrouter_is_management_key($cfg['api_key'])) {
                    return __('Hai incollato una chiave di GESTIONE di OpenRouter: serve a creare altre chiavi, non a tradurre. Su openrouter.ai/settings/keys premi «Create API Key» (non «Management/Provisioning key») e incolla quella.', 'tw-translate-plus');
                }
                return sprintf(
                    /* translators: 1: service host, 2: API detail. */
                    __('%1$s non accetta la chiave: controlla di averla copiata intera o creane una nuova. Dettaglio: %2$s', 'tw-translate-plus'),
                    $host, $api_msg
                );
            case 402:
                return sprintf(
                    /* translators: %s: service host. */
                    __('Credito esaurito su %s: aggiungi credito al tuo account e la traduzione riparte da sola.', 'tw-translate-plus'),
                    $host
                );
            case 404:
                return sprintf(
                    /* translators: 1: model, 2: service host, 3: API detail. */
                    __('Il modello «%1$s» non esiste su %2$s: controlla il nome nelle impostazioni avanzate. Dettaglio: %3$s', 'tw-translate-plus'),
                    $cfg['model'], $host, $api_msg
                );
            case 429:
                return sprintf(
                    /* translators: %s: service host. */
                    __('%s sta limitando le richieste (troppe richieste o limite del piano gratuito): la coda riprova da sola.', 'tw-translate-plus'),
                    $host
                );
            default:
                return sprintf(
                    /* translators: 1: service host, 2: HTTP code, 3: API detail. */
                    __('Errore da %1$s (%2$d): %3$s', 'tw-translate-plus'),
                    $host, $code, $api_msg
                );
        }
    }

    /**
     * Whether an OpenRouter key is a management (provisioning) key, which
     * can manage keys but cannot call models.
     *
     * @param string $key
     * @return bool
     */
    public static function openrouter_is_management_key($key) {
        $resp = wp_remote_get('https://openrouter.ai/api/v1/key', array(
            'timeout' => 10,
            'headers' => array('Authorization' => 'Bearer ' . $key),
        ));
        if (is_wp_error($resp) || (int) wp_remote_retrieve_response_code($resp) !== 200) {
            return false;
        }
        $data = json_decode(wp_remote_retrieve_body($resp), true);
        return !empty($data['data']['is_management_key']) || !empty($data['data']['is_provisioning_key']);
    }

    /**
     * Map API errors to actionable Italian messages, without echoing content.
     *
     * @param int        $code
     * @param array|null $decoded
     * @return string
     */
    public static function friendly_error($code, $decoded) {
        $api_msg  = isset($decoded['error']['message']) ? (string) $decoded['error']['message'] : '';
        $api_msg  = mb_substr($api_msg, 0, 200);
        $api_type = isset($decoded['error']['type']) ? (string) $decoded['error']['type'] : '';

        switch ($code) {
            case 400:
                if (stripos($api_msg, 'response_format') !== false) {
                    return sprintf(__('Il modello scelto non supporta le risposte in formato JSON: scegline uno più recente (es. gpt-4o-mini). Dettaglio: %s', 'tw-translate-plus'), $api_msg);
                }
                return sprintf(__('Richiesta non valida (verifica il nome del modello): %s', 'tw-translate-plus'), $api_msg);
            case 401:
                return __('Chiave API OpenAI non valida o revocata: generane una nuova dalla dashboard OpenAI.', 'tw-translate-plus');
            case 403:
                return sprintf(__('Accesso negato: la chiave non è abilitata a questo modello o al tuo paese. Dettaglio: %s', 'tw-translate-plus'), $api_msg);
            case 404:
                return sprintf(__('Modello non trovato: verifica il nome esatto e che il tuo account vi abbia accesso. Dettaglio: %s', 'tw-translate-plus'), $api_msg);
            case 429:
                if ($api_type === 'insufficient_quota' || stripos($api_msg, 'quota') !== false) {
                    return __('Credito OpenAI esaurito: aggiungi fondi al progetto (Billing) e riprova.', 'tw-translate-plus');
                }
                return __('Troppe richieste a OpenAI (rate limit): la coda riproverà automaticamente.', 'tw-translate-plus');
            default:
                return sprintf(__('Errore OpenAI (%1$d): %2$s', 'tw-translate-plus'), $code, $api_msg);
        }
    }

    /**
     * @param mixed $data
     * @return string JSON with readable unicode (smaller payload than \uXXXX).
     */
    private static function json($data) {
        return (string) wp_json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    }
}
