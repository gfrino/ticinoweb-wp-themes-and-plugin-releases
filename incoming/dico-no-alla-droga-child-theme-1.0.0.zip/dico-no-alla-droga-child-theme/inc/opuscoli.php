<?php
/**
 * Opuscoli: i contenuti «Opuscoli» (tipo di contenuto configurato nel parent, ticinoWEB CMS → Tipi di
 * contenuto, slug «opuscolo») con copertina = immagine in evidenza e PDF = campo qui sotto.
 *
 * Il child non crea il tipo di contenuto (lo fa il parent da un'opzione): aggiunge solo il campo «File PDF»
 * con un selettore della Libreria media e lo shortcode [dnd_opuscoli] per mostrarli.
 */

if (!defined('ABSPATH')) {
    exit;
}

const DND_OPUSCOLO_TYPE = 'opuscolo';
const DND_OPUSCOLO_PDF  = '_dnd_pdf_id';

add_action('add_meta_boxes', function () {
    add_meta_box('dnd-opuscolo-pdf', __('File PDF dell’opuscolo', 'dico-no-alla-droga-child-theme'), 'dnd_opuscolo_metabox', DND_OPUSCOLO_TYPE, 'side', 'high');
});

function dnd_opuscolo_metabox($post) {
    $id  = (int) get_post_meta($post->ID, DND_OPUSCOLO_PDF, true);
    $url = $id ? wp_get_attachment_url($id) : '';
    wp_nonce_field('dnd_opuscolo_pdf', 'dnd_opuscolo_pdf_nonce');
    wp_enqueue_media();
    ?>
    <p class="description"><?php esc_html_e('Il PDF che i visitatori possono scaricare. La copertina è l’«Immagine in evidenza».', 'dico-no-alla-droga-child-theme'); ?></p>
    <input type="hidden" name="dnd_pdf_id" id="dnd_pdf_id" value="<?php echo esc_attr($id); ?>">
    <p id="dnd_pdf_name"><?php echo $url ? esc_html(wp_basename($url)) : esc_html__('Nessun PDF scelto.', 'dico-no-alla-droga-child-theme'); ?></p>
    <p>
        <button type="button" class="button button-primary" id="dnd_pdf_pick"><?php esc_html_e('Scegli o carica il PDF', 'dico-no-alla-droga-child-theme'); ?></button>
        <button type="button" class="button" id="dnd_pdf_clear" <?php echo $id ? '' : 'style="display:none"'; ?>><?php esc_html_e('Togli', 'dico-no-alla-droga-child-theme'); ?></button>
    </p>
    <script>
    (function () {
        var pick = document.getElementById('dnd_pdf_pick'), clear = document.getElementById('dnd_pdf_clear'),
            input = document.getElementById('dnd_pdf_id'), name = document.getElementById('dnd_pdf_name'), frame;
        var none = <?php echo wp_json_encode(__('Nessun PDF scelto.', 'dico-no-alla-droga-child-theme')); ?>;
        pick.addEventListener('click', function () {
            if (!frame) {
                frame = wp.media({ title: <?php echo wp_json_encode(__('Scegli il PDF', 'dico-no-alla-droga-child-theme')); ?>, library: { type: 'application/pdf' }, multiple: false });
                frame.on('select', function () {
                    var a = frame.state().get('selection').first().toJSON();
                    input.value = a.id; name.textContent = a.filename || a.url; clear.style.display = '';
                });
            }
            frame.open();
        });
        clear.addEventListener('click', function () { input.value = ''; name.textContent = none; clear.style.display = 'none'; });
    })();
    </script>
    <?php
}

add_action('save_post_' . DND_OPUSCOLO_TYPE, function ($post_id) {
    if (!isset($_POST['dnd_opuscolo_pdf_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['dnd_opuscolo_pdf_nonce'])), 'dnd_opuscolo_pdf')) {
        return;
    }
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }
    if (!current_user_can('edit_post', $post_id)) {
        return;
    }
    $id = isset($_POST['dnd_pdf_id']) ? absint($_POST['dnd_pdf_id']) : 0;
    if ($id && get_post_mime_type($id) === 'application/pdf') {
        update_post_meta($post_id, DND_OPUSCOLO_PDF, $id);
    } else {
        delete_post_meta($post_id, DND_OPUSCOLO_PDF);
    }
});

/**
 * Elenco degli opuscoli pubblicati (usato dallo shortcode e dal modulo di richiesta).
 *
 * @return WP_Post[]
 */
function dnd_get_opuscoli($limit = -1) {
    if (!post_type_exists(DND_OPUSCOLO_TYPE)) {
        return array();
    }
    $key = 'dnd_opuscoli_' . (int) $limit;
    $cached = wp_cache_get($key, 'dnd');
    if (is_array($cached)) {
        return $cached;
    }
    $posts = get_posts(array(
        'post_type'              => DND_OPUSCOLO_TYPE,
        'post_status'            => 'publish',
        'posts_per_page'         => (int) $limit,
        'orderby'                => array('menu_order' => 'ASC', 'title' => 'ASC'),
        'no_found_rows'          => true,
        'update_post_term_cache' => false,
    ));
    wp_cache_set($key, $posts, 'dnd', 300);
    return $posts;
}

/**
 * [dnd_opuscoli limit="6" richiedi="1"] – griglia delle copertine con «Scarica PDF» e «Aggiungi alla richiesta».
 */
add_shortcode('dnd_opuscoli', function ($atts) {
    $atts  = shortcode_atts(array('limit' => '-1', 'richiedi' => '1'), $atts, 'dnd_opuscoli');
    $posts = dnd_get_opuscoli((int) $atts['limit']);
    if (!$posts) {
        return current_user_can('edit_pages')
            ? '<p class="dnd-empty">' . esc_html__('Nessun opuscolo pubblicato: aggiungili dal menu «Opuscoli» della Bacheca.', 'dico-no-alla-droga-child-theme') . '</p>'
            : '';
    }
    ob_start();
    echo '<ul class="dnd-booklets">';
    foreach ($posts as $p) {
        $pdf_id = (int) get_post_meta($p->ID, DND_OPUSCOLO_PDF, true);
        $pdf    = $pdf_id ? wp_get_attachment_url($pdf_id) : '';
        $title  = get_the_title($p);
        echo '<li class="dnd-booklet">';
        echo '<div class="dnd-booklet__cover">';
        if (has_post_thumbnail($p)) {
            echo get_the_post_thumbnail($p, 'dnd-cover', array('loading' => 'lazy', 'alt' => sprintf(/* translators: %s: booklet title */ __('Copertina: %s', 'dico-no-alla-droga-child-theme'), $title)));
        }
        echo '</div>';
        echo '<h3 class="dnd-booklet__title">' . esc_html($title) . '</h3>';
        echo '<div class="dnd-booklet__actions">';
        if ($pdf) {
            printf('<a class="dnd-link" href="%s" target="_blank" rel="noopener">%s</a>', esc_url($pdf), esc_html__('Scarica il PDF', 'dico-no-alla-droga-child-theme'));
        }
        if ($atts['richiedi'] === '1') {
            printf(
                '<a class="dnd-chip" href="%s" data-dnd-add="%d">%s</a>',
                esc_url(add_query_arg('opuscolo', $p->ID, home_url('/')) . '#richiedi'),
                (int) $p->ID,
                esc_html__('Richiedi copie', 'dico-no-alla-droga-child-theme')
            );
        }
        echo '</div></li>';
    }
    echo '</ul>';
    return ob_get_clean();
});
