<?php
/**
 * Contractor license number in the footer.
 *
 * Per-site, like the hero video: the value lives in the `ecopro_license_number`
 * option, which in a multisite install is stored per blog. ecoproplumbing.com
 * (Florida, license CFC1434434) sets it; ecoproplumbing.ca leaves it empty and
 * its footer is rendered exactly as before. Nothing is hardcoded in the theme.
 *
 * Edited from ticinoWEB CMS (wp-admin → ticinoWEB CMS), where the field joins the
 * parent theme's settings form the same way the hero video field does, so the
 * parent's own Save button stores it.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * This site's license number, or '' when none is set.
 *
 * @return string
 */
function ecoproplumbing_get_license_number() {
    return trim( (string) get_option( 'ecopro_license_number', '' ) );
}

/**
 * Render the license line in the footer. Prints nothing when the option is empty,
 * so a site without a license keeps the previous markup byte for byte.
 *
 * @return void
 */
function ecoproplumbing_footer_license_number() {
    $license = ecoproplumbing_get_license_number();
    if ( $license === '' ) {
        return;
    }
    ?>
    <div class="footer-content-wrapper footer-license">
        <p class="mb-0 footer-license-number"><?php echo esc_html( $license ); ?></p>
    </div>
    <?php
}

/* -------------------------------------------------------------------------
 * Admin — field inside the ticinoWEB CMS form (same group as the hero video)
 * ---------------------------------------------------------------------- */

add_action( 'admin_init', 'ecoproplumbing_register_license_number_field' );
function ecoproplumbing_register_license_number_field() {
    register_setting( 'ticinoweb_settings_group', 'ecopro_license_number', array(
        'type'              => 'string',
        'sanitize_callback' => 'sanitize_text_field',
        'default'           => '',
    ) );

    add_settings_section(
        'ecopro_license_number_section',
        __( 'Footer — Numero di licenza', 'ecoproplumbing' ),
        'ecoproplumbing_license_number_section_intro',
        'ticinoweb_settings_group'
    );

    add_settings_field(
        'ecopro_license_number',
        __( 'Numero di licenza', 'ecoproplumbing' ),
        'ecoproplumbing_license_number_field',
        'ticinoweb_settings_group',
        'ecopro_license_number_section'
    );
}

function ecoproplumbing_license_number_section_intro() {
    echo '<p>' . esc_html__( 'Numero di licenza professionale mostrato nel footer, sotto il copyright. Vale solo per questo sito: lascia vuoto per non mostrare nulla.', 'ecoproplumbing' ) . '</p>';
}

function ecoproplumbing_license_number_field() {
    $value = ecoproplumbing_get_license_number();
    ?>
    <input type="text" id="ecopro_license_number" name="ecopro_license_number"
           value="<?php echo esc_attr( $value ); ?>" class="regular-text"
           placeholder="CFC1434434" style="max-width: 320px;">
    <p class="description">
        <?php esc_html_e( 'Inserisci solo il numero (es. CFC1434434), senza la dicitura "License #".', 'ecoproplumbing' ); ?>
    </p>
    <?php
}
