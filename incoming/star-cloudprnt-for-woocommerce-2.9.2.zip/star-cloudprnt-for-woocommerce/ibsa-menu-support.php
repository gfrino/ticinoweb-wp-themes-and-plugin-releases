<?php
/*
 * Support for the IBSA Menu plugin (ticinoWEB).
 *
 * IBSA Menu stores hidden meta on every order line of a configured menu
 * (_ibsa_menu_group, _ibsa_menu_title, _ibsa_component, _ibsa_dish, ...).
 * Only lines carrying that meta are printed here; every other line, and every
 * order of a site without IBSA Menu, goes through the standard code unchanged.
 */

if (!defined('ABSPATH')) exit;

// Order item ids that belong to an IBSA menu, grouped by menu group, in order
// line sequence. Empty array when the order has no IBSA line.
function star_cloudprnt_ibsa_groups($order_items)
{
    $groups = array();
    foreach ($order_items as $item_id => $item) {
        if (!is_object($item) || !method_exists($item, 'get_meta')) continue;
        $group = (string) $item->get_meta('_ibsa_menu_group', true);
        if ($group === '') continue;
        $groups[$group][] = $item_id;
    }
    return $groups;
}

// Print one IBSA menu: its title with the menu price, one line per course
// with the dish to deliver, then the cutlery choice.
function star_cloudprnt_ibsa_print_group(&$printer, &$selectedPrinter, $order_items, $item_ids)
{
    $max_chars = $selectedPrinter['columns'];
    $title = '';
    $price = 0.0;
    $cutlery = '';
    $rows = array();

    foreach ($item_ids as $item_id) {
        $item = $order_items[$item_id];
        if ($title === '') $title = (string) $item->get_meta('_ibsa_menu_title', true);
        $price += (float) $item->get_total() + (float) $item->get_total_tax();
        $posate = (string) $item->get_meta('Posate', true);
        if ($posate !== '') $cutlery = $posate;

        $dish = (string) $item->get_meta('_ibsa_dish', true);
        if ($dish === '') $dish = $item->get_name();
        $qty = (int) $item->get_quantity();
        if ($qty > 1) $dish = $qty . 'x ' . $dish;
        $rows[] = array((string) $item->get_meta('_ibsa_component', true), $dish);
    }

    // Menu title (+ price), same style as a standard product headline
    $printer->set_text_emphasized();
    $printer->set_font_magnification(2, 2);
    $printer->add_text_line(wordwrap(star_cloudprnt_filter_html($title), $max_chars, "\n", true));
    $printer->cancel_text_emphasized();
    $printer->set_font_magnification(1, 1);
    $printer->add_vertical_spacing_mm(0.5);

    // What has to be delivered: course label in bold, dish below it
    foreach ($rows as $row) {
        list($course, $dish) = $row;
        if ($course !== '') {
            $printer->set_text_emphasized();
            $printer->add_text_line(star_cloudprnt_filter_html(' ' . $course . ':'));
            $printer->cancel_text_emphasized();
        }
        $printer->set_text_emphasized();
        $printer->set_font_magnification(1, 2);
        foreach (explode("\n", wordwrap(star_cloudprnt_filter_html($dish), $max_chars - 3, "\n", true)) as $dish_line) {
            $printer->add_text_line('   ' . $dish_line);
        }
        $printer->cancel_text_emphasized();
        $printer->set_font_magnification(1, 1);
        $printer->add_vertical_spacing_mm(0.5);
    }

    if ($cutlery !== '') {
        $printer->set_text_emphasized();
        $printer->add_text_line(star_cloudprnt_filter_html(' Posate: ' . $cutlery));
        $printer->cancel_text_emphasized();
        $printer->add_vertical_spacing_mm(0.5);
    }

    $printer->set_font_magnification(1, 2);
    $printer->add_text_line(
        star_cloudprnt_get_column_separated_data(array(' Menu', star_cloudprnt_format_currency($price)), $max_chars)
    );
    $printer->set_font_magnification(1, 1);
    $printer->add_vertical_spacing_mm(0.5);
}
