import React, { useState, useEffect, useRef } from 'react';
import { createRoot } from 'react-dom/client';
import './style.css';

// Helper fetch che aggiunge automaticamente il nonce e gestisce risposta JSON o errori HTTP
function fetchJSON(relativePath, opts = {}) {
  const cfg = window.FD_POS_CFG || {};
  const base = cfg.restBase || '/wp-json/fd-pos/v1/';
  const url = relativePath.startsWith('http') ? relativePath : base + relativePath.replace(/^\//,'');
  const headers = Object.assign({}, opts.headers || {}, {
    'X-WP-Nonce': cfg.nonce || '',
    'Accept': 'application/json'
  });
  return fetch(url, { ...opts, headers }).then(async r => {
    if(!r.ok) {
      const text = await r.text();
      throw new Error('HTTP '+r.status+' '+text.substring(0,120));
    }
    return r.json();
  });
}

// Debounce hook
function useDebounce(value, delay) {
  const [debounced, setDebounced] = useState(value);
  useEffect(() => {
    const handler = setTimeout(() => setDebounced(value), delay);
    return () => clearTimeout(handler);
  }, [value, delay]);
  return debounced;
}

function CustomerPanel({ data, setData }) {
  const [nameInput, setNameInput] = useState(data.name || '');
  const [phoneInput, setPhoneInput] = useState(data.phone || '');
  const [emailInput, setEmailInput] = useState(data.email || '');
  const [nameSuggestions, setNameSuggestions] = useState([]);
  const [phoneSuggestions, setPhoneSuggestions] = useState([]);
  const [emailSuggestions, setEmailSuggestions] = useState([]);
  const [activeField, setActiveField] = useState(null);
  const [selectedIndex, setSelectedIndex] = useState(-1);
  const nameDebounced = useDebounce(nameInput, 300);
  const phoneDebounced = useDebounce(phoneInput, 300);
  const emailDebounced = useDebounce(emailInput, 300);

  useEffect(() => {
    if (nameDebounced.length >= 2) {
      fetchJSON(`customers?search=${encodeURIComponent(nameDebounced)}&mode=name`)
        .then(res => setNameSuggestions(res))
        .catch(() => setNameSuggestions([]));
    } else {
      setNameSuggestions([]);
    }
  }, [nameDebounced]);

  useEffect(() => {
    if (phoneDebounced.length >= 2) {
      fetchJSON(`customers?search=${encodeURIComponent(phoneDebounced)}&mode=phone`)
        .then(res => setPhoneSuggestions(res))
        .catch(() => setPhoneSuggestions([]));
    } else {
      setPhoneSuggestions([]);
    }
  }, [phoneDebounced]);

  useEffect(() => {
    if (emailDebounced.length >= 2) {
      fetchJSON(`customers?search=${encodeURIComponent(emailDebounced)}&mode=email`)
        .then(res => setEmailSuggestions(res))
        .catch(() => setEmailSuggestions([]));
    } else {
      setEmailSuggestions([]);
    }
  }, [emailDebounced]);

  const selectCustomer = (customer) => {
    setNameInput(customer.name || '');
    setPhoneInput(customer.phone || '');
    setEmailInput(customer.email || '');
    setData({
      ...data,
      name: customer.name || '',
      phone: customer.phone || '',
      email: customer.email || '',
      address_1: customer.address_1 || '',
      city: customer.city || '',
      postcode: customer.postcode || ''
    });
    setNameSuggestions([]);
    setPhoneSuggestions([]);
    setEmailSuggestions([]);
    setActiveField(null);
  };

  const handleKeyDown = (e, suggestions, field) => {
    if (suggestions.length === 0) return;
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      setSelectedIndex(prev => (prev < suggestions.length - 1 ? prev + 1 : 0));
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setSelectedIndex(prev => (prev > 0 ? prev - 1 : suggestions.length - 1));
    } else if (e.key === 'Enter' && selectedIndex >= 0) {
      e.preventDefault();
      selectCustomer(suggestions[selectedIndex]);
      setSelectedIndex(-1);
    } else if (e.key === 'Escape') {
      setActiveField(null);
      setSelectedIndex(-1);
    }
  };

  return <div className="fd-panel fd-customer-panel">
    <h3>👤 Cliente</h3>
    <div className="fd-autocomplete-wrapper">
      <label>Nome</label>
      <input
        value={nameInput}
        onChange={e => { setNameInput(e.target.value); setData({...data, name: e.target.value}); }}
        onFocus={() => { setActiveField('name'); setSelectedIndex(-1); }}
        onBlur={() => setTimeout(() => setActiveField(null), 200)}
        onKeyDown={e => handleKeyDown(e, nameSuggestions, 'name')}
        placeholder="Nome cliente"
      />
      {activeField === 'name' && nameSuggestions.length > 0 && (
        <ul className="fd-suggestions">
          {nameSuggestions.map((c, idx) => (
            <li
              key={c.id}
              className={idx === selectedIndex ? 'fd-selected' : ''}
              onMouseDown={() => selectCustomer(c)}
            >
              <strong>{c.name}</strong>
              {c.secondary && <span className="fd-secondary">{c.secondary}</span>}
            </li>
          ))}
        </ul>
      )}
    </div>
    <div className="fd-autocomplete-wrapper">
      <label>Telefono</label>
      <input
        value={phoneInput}
        onChange={e => { setPhoneInput(e.target.value); setData({...data, phone: e.target.value}); }}
        onFocus={() => { setActiveField('phone'); setSelectedIndex(-1); }}
        onBlur={() => setTimeout(() => setActiveField(null), 200)}
        onKeyDown={e => handleKeyDown(e, phoneSuggestions, 'phone')}
        placeholder="Telefono"
      />
      {activeField === 'phone' && phoneSuggestions.length > 0 && (
        <ul className="fd-suggestions">
          {phoneSuggestions.map((c, idx) => (
            <li
              key={c.id}
              className={idx === selectedIndex ? 'fd-selected' : ''}
              onMouseDown={() => selectCustomer(c)}
            >
              <strong>{c.phone}</strong>
              <span className="fd-secondary">{c.name}</span>
            </li>
          ))}
        </ul>
      )}
    </div>
    <div className="fd-autocomplete-wrapper">
      <label>Email</label>
      <input
        value={emailInput}
        onChange={e => { setEmailInput(e.target.value); setData({...data, email: e.target.value}); }}
        onFocus={() => { setActiveField('email'); setSelectedIndex(-1); }}
        onBlur={() => setTimeout(() => setActiveField(null), 200)}
        onKeyDown={e => handleKeyDown(e, emailSuggestions, 'email')}
        placeholder="Email"
      />
      {activeField === 'email' && emailSuggestions.length > 0 && (
        <ul className="fd-suggestions">
          {emailSuggestions.map((c, idx) => (
            <li
              key={c.id}
              className={idx === selectedIndex ? 'fd-selected' : ''}
              onMouseDown={() => selectCustomer(c)}
            >
              <strong>{c.email}</strong>
              <span className="fd-secondary">{c.name}</span>
            </li>
          ))}
        </ul>
      )}
    </div>
    <label>Indirizzo</label>
    <input placeholder="Via, numero" value={data.address_1 || ''} onChange={e => setData({...data, address_1: e.target.value})} />
    <div className="fd-row-inline">
      <input placeholder="Città" value={data.city || ''} onChange={e => setData({...data, city: e.target.value})} />
      <input placeholder="CAP" value={data.postcode || ''} onChange={e => setData({...data, postcode: e.target.value})} />
    </div>
    <label>Note</label>
    <textarea placeholder="Note cliente" value={data.note || ''} onChange={e => setData({...data, note: e.target.value})} rows="3" />
  </div>;
}

function ProductSearch({ onSelect }) {
  const [term, setTerm] = useState('');
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);
  const search = () => {
    if (!term.trim()) return;
    setLoading(true);
    fetchJSON(`products?search=${encodeURIComponent(term)}`)
      .then(data => setResults(data))
      .catch(() => setResults([]))
      .finally(() => setLoading(false));
  };
  return <div className="fd-panel">
    <h3>🔍 Prodotti</h3>
    <div className="fd-search-bar">
      <input value={term} onChange={e => setTerm(e.target.value)} placeholder="Cerca prodotto o SKU..." onKeyDown={e => e.key === 'Enter' && search()} />
      <button onClick={search} disabled={loading} className="fd-btn-search">{loading ? '⏳' : 'Cerca'}</button>
    </div>
    {results.length > 0 && (
      <ul className="fd-product-list">
        {results.map(p => (
          <li key={p.id}>
            <button onClick={() => onSelect(p)} className="fd-product-item">
              <span className="fd-product-name">{p.name}</span>
              <span className="fd-product-price">€{p.price}</span>
            </button>
          </li>
        ))}
      </ul>
    )}
  </div>;
}

function Cart({ items, updateQty, removeItem }) {
  return <div className="fd-panel fd-cart-panel">
    <h3>🛒 Carrello</h3>
    {items.length === 0 && <p className="fd-empty-cart">Nessun prodotto</p>}
    {items.map(it => <div key={it.id} className="fd-cart-item">
      <div className="fd-cart-item-name">{it.name}</div>
      <div className="fd-cart-item-controls">
        <input type="number" min="1" value={it.qty} onChange={e => updateQty(it.id, parseInt(e.target.value || '1', 10))} className="fd-qty-input" />
        <span className="fd-cart-item-price">€{(it.price * it.qty).toFixed(2)}</span>
        <button onClick={() => removeItem(it.id)} className="fd-btn-remove">✕</button>
      </div>
    </div>)}
  </div>;
}

function FlowPanel({ flow, setFlow }) {
  return <div className="fd-panel">
    <h3>🚚 Consegna & Pagamento</h3>
    <label>Tipo consegna</label>
    <select value={flow.shipping} onChange={e => setFlow({...flow, shipping: e.target.value})} className="fd-select">
      <option value="">Seleziona...</option>
      <option value="delivery">🏠 Consegna a domicilio</option>
      <option value="pickup">🏪 Ritiro in sede</option>
    </select>
    <label>Metodo pagamento</label>
    <select value={flow.payment} onChange={e => setFlow({...flow, payment: e.target.value})} className="fd-select">
      <option value="">Seleziona...</option>
      <option value="cod">💵 Contanti</option>
      <option value="card">💳 Carta</option>
      <option value="online">🌐 Online</option>
    </select>
  </div>;
}

function App() {
  const rootDiv = document.getElementById('fd-pos-root');
  const nonce = rootDiv.dataset.nonce;
  const [cart, setCart] = useState([]);
  const [customer, setCustomer] = useState({name: '', phone: '', email: '', address_1: '', city: '', postcode: '', note: ''});
  const [flow, setFlow] = useState({shipping: '', payment: ''});
  const [status, setStatus] = useState(null);
  const [loading, setLoading] = useState(false);

  const grandTotal = cart.reduce((sum, item) => sum + item.price * item.qty, 0);

  const addProduct = (p) => {
    setCart(old => {
      const ex = old.find(i => i.id === p.id);
      if (ex) return old.map(i => i.id === p.id ? {...i, qty: i.qty + 1} : i);
      return [...old, {id: p.id, name: p.name, price: parseFloat(p.price), qty: 1}];
    });
  };

  const resetAll = () => {
    if (!confirm('Resettare tutto (carrello, cliente, selezioni)?')) return;
    setCart([]);
    setCustomer({name: '', phone: '', email: '', address_1: '', city: '', postcode: '', note: ''});
    setFlow({shipping: '', payment: ''});
    setStatus(null);
  };

  const createOrder = () => {
    if (!cart.length) { setStatus({type: 'error', msg: 'Carrello vuoto'}); return; }
    if (!flow.shipping || !flow.payment) { setStatus({type: 'error', msg: 'Seleziona spedizione e pagamento'}); return; }
    setLoading(true);
    setStatus({type: 'info', msg: 'Creazione ordine...'});
    fetch('/wp-json/fd-pos/v1/create-order', {
      method: 'POST',
      headers: {'Content-Type': 'application/json', 'X-WP-Nonce': nonce},
      body: JSON.stringify({cart, customer, flow})
    }).then(r => r.json()).then(res => {
      if (res.success) {
        setStatus({type: 'success', msg: 'Ordine #' + res.order_id + ' creato e stampato'});
        setCart([]);
        setCustomer({name: '', phone: '', email: '', address_1: '', city: '', postcode: '', note: ''});
        setFlow({shipping: '', payment: ''});
      } else {
        setStatus({type: 'error', msg: res.message || 'Errore'});
      }
    }).catch(() => setStatus({type: 'error', msg: 'Errore rete'}))
      .finally(() => setLoading(false));
  };

  return <>
    <div className="fd-topbar">
      <button onClick={resetAll} className="fd-btn-reset" title="Reset tutto">🔄 Reset</button>
      <div className="fd-topbar-total">
        <span className="fd-total-label">Totale Ordine:</span>
        <span className="fd-total-amount">€{grandTotal.toFixed(2)}</span>
      </div>
    </div>
    <div className="fd-grid">
      <CustomerPanel data={customer} setData={setCustomer} />
      <ProductSearch onSelect={addProduct} />
      <Cart items={cart} updateQty={(id, qty) => setCart(old => old.map(i => i.id === id ? {...i, qty} : i))} removeItem={id => setCart(old => old.filter(i => i.id !== id))} />
      <FlowPanel flow={flow} setFlow={setFlow} />
      <div className="fd-panel fd-actions-panel">
        <h3>✅ Azioni</h3>
        <button disabled={loading || cart.length === 0} onClick={createOrder} className="fd-btn-create">
          {loading ? '⏳ Elaborazione...' : '🖨️ Crea & Stampa Ordine'}
        </button>
        {status && <div className={'fd-status fd-status-' + status.type}>{status.msg}</div>}
      </div>
    </div>
  </>;
}

createRoot(document.getElementById('fd-pos-root')).render(<App />);
