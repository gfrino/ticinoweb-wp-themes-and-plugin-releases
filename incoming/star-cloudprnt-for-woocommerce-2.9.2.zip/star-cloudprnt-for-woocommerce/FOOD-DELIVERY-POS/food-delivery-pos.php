<?php
// POS module included by the main Star CloudPRNT plugin when enabled.
// Not a standalone WordPress plugin; no plugin header here to avoid separate activation.

if (!defined('ABSPATH')) exit;

// Define POS specific constants
define('FD_POS_VERSION', '0.1.1');
define('FD_POS_MIN_PHP', '8.0.0');

// Reuse WooCommerce requirement checks (simplified)
$php_ok = version_compare(PHP_VERSION, FD_POS_MIN_PHP, '>=');
if (!$php_ok) {
  add_action('admin_notices', function(){
    echo '<div class="notice notice-error"><p>Food Delivery Call Center richiede PHP '.FD_POS_MIN_PHP.'+</p></div>';
  });
  return;
}

// Locate main plugin directory (one level above this POS module)
$module_dir = plugin_dir_path(__FILE__);
$plugin_root = trailingslashit(dirname($module_dir));

// Ensure helper function is available for OS-aware paths
if (!function_exists('star_cloudprnt_get_os_path')) {
  include_once($plugin_root . 'cloudprnt/cloudprnt_conf.inc.php');
}

// Include printer core from main plugin stack
include_once($plugin_root . star_cloudprnt_get_os_path('cloudprnt/printer.inc.php'));
include_once($plugin_root . star_cloudprnt_get_os_path('cloudprnt/printer_star_line.inc.php'));
include_once($plugin_root . star_cloudprnt_get_os_path('cloudprnt/printer_text_plain.inc.php'));
include_once($plugin_root . star_cloudprnt_get_os_path('cloudprnt/printer_star_prnt.inc.php'));
include_once($plugin_root . 'cloudprnt/internal_log_fallback.php');

// Legacy order printing handlers (shared with main plugin)
include_once($plugin_root . 'order-handler.php');
include_once($plugin_root . 'order-handler.inc.php');
include_once($plugin_root . 'z-report.php');

// POS React app enqueue + admin page
function fd_pos_register_admin_page(){
  add_menu_page(
    'Call Center',
    'Call Center',
    'manage_woocommerce',
    'fd-pos',
    'fd_pos_render_app',
    'dashicons-store',
    56
  );
}
add_action('admin_menu', 'fd_pos_register_admin_page');

function fd_pos_render_app(){
  if (!current_user_can('manage_woocommerce')) {
    echo '<div class="notice notice-error"><p>Permessi insufficienti.</p></div>';
    return;
  }
  if (function_exists('star_cloudprnt_pos_page') && star_cloudprnt_pos_page()) {
    return;
  }
  $nonce = wp_create_nonce('wp_rest');
  echo '<div class="wrap"><h1>Food Delivery Call Center</h1><div id="fd-pos-root" data-nonce="'.esc_attr($nonce).'"></div></div>';
}

function fd_pos_enqueue_assets($hook){
  if ($hook !== 'toplevel_page_fd-pos') return;
  $ver = FD_POS_VERSION;
  // Placeholder paths – will be created by build step
  wp_enqueue_script('fd-pos-app', plugins_url('admin-pos/dist/app.js', __FILE__), array(), $ver, true);
  wp_enqueue_style('fd-pos-style', plugins_url('admin-pos/dist/app.css', __FILE__), array(), $ver);
}
add_action('admin_enqueue_scripts', 'fd_pos_enqueue_assets');

// REST endpoints for POS (minimal MVP)
add_action('rest_api_init', function(){
  register_rest_route('fd-pos/v1','/products', array(
    'methods' => 'GET',
    'callback' => 'fd_pos_rest_products',
    'permission_callback' => function(){ return current_user_can('manage_woocommerce'); }
  ));
  register_rest_route('fd-pos/v1','/create-order', array(
    'methods' => 'POST',
    'callback' => 'fd_pos_rest_create_order',
    'permission_callback' => function(){ return current_user_can('manage_woocommerce'); }
  ));
});

function fd_pos_rest_products(WP_REST_Request $req){
  $search = sanitize_text_field($req->get_param('search'));
  if (!function_exists('wc_get_products')) return new WP_REST_Response(array());
  $args = array('limit'=>15,'status'=>'publish','return'=>'ids');
  if ($search) $args['search'] = $search;
  $ids = wc_get_products($args);
  $out = array();
  foreach ($ids as $id){
    $p = wc_get_product($id); if(!$p) continue;
    $out[] = array('id'=>$id,'name'=>$p->get_name(),'price'=>wc_get_price_to_display($p));
  }
  return $out;
}

function fd_pos_rest_create_order(WP_REST_Request $req){
  if (!function_exists('wc_create_order')) return new WP_REST_Response(array('success'=>false,'message'=>'WooCommerce non disponibile'),400);
  $data = $req->get_json_params();
  $cart = isset($data['cart']) ? (array)$data['cart'] : array();
  if (empty($cart)) return new WP_REST_Response(array('success'=>false,'message'=>'Carrello vuoto'),400);
  $order = wc_create_order();
  foreach ($cart as $line){
    $pid = intval($line['id']); $qty = max(1,intval($line['qty']));
    $product = wc_get_product($pid); if(!$product) continue;
    $order->add_product($product,$qty);
  }
  // Customer email
  if (!empty($data['customer']['email']) && is_email($data['customer']['email']))
    $order->set_billing_email(sanitize_email($data['customer']['email']));
  // Note
  if (!empty($data['customer']['note']))
    $order->add_order_note(sanitize_textarea_field($data['customer']['note']));
  // Payment mapping
  $payment_map = array('cod'=>'cod','card'=>'cheque','online'=>'stripe');
  $sel = isset($payment_map[$data['flow']['payment']]) ? $payment_map[$data['flow']['payment']] : 'cod';
  $order->set_payment_method($sel);
  // Shipping
  $ship = isset($data['flow']['shipping']) ? $data['flow']['shipping'] : '';
  if (in_array($ship,array('delivery','pickup'))){
    $item = new WC_Order_Item_Shipping();
    $item->set_method_title($ship === 'delivery' ? 'Consegna a domicilio' : 'Ritiro in sede');
    $item->set_total(0);
    $order->add_item($item);
  }
  $order->calculate_totals();
  $order->set_status('processing');
  $order->save();
  // Trigger printing using existing function if available
  if (function_exists('star_cloudprnt_trigger_print')) {
    try { star_cloudprnt_trigger_print($order->get_id()); } catch(Exception $e){ error_log('FD POS print error: '.$e->getMessage()); }
  }
  return array('success'=>true,'order_id'=>$order->get_id());
}

// Basic React app bootstrap (will be overwritten by build output)
// Provide fallback if assets missing
add_action('admin_print_footer_scripts', function(){
  if (!did_action('admin_enqueue_scripts')) return;
  if (!wp_script_is('fd-pos-app','enqueued')){
    echo '<script>console.warn("FD POS: build mancante. Esegui npm run build in admin-pos.");</script>';
  }
});

?>