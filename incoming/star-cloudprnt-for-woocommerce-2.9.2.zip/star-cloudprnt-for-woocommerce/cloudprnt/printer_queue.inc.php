<?php
	include_once('printer.inc.php');
	// Ensure we have an internal logger available in non-WP contexts
	include_once(__DIR__ . '/internal_log_fallback.php');
	
	// Previously numeric positions were used for queue filenames. New approach: use a time-based unique token
	// Returns a unique token for a new queue job (no extension)
	function star_cloudprnt_queue_generate_token()
	{
		// Format: YYYYmmddHHMMSS_u + 8 hex chars
		$timePart = date('YmdHis') . '_' . sprintf('%06d', (int)((microtime(true) - floor(microtime(true))) * 1000000));
		$rand = substr(md5(uniqid('', true)), 0, 8);
		return $timePart . '_' . $rand;
	}
	
	// Returns file name of the next job to print in the queue or empty string if there are no jobs in the queue
	function star_cloudprnt_queue_get_next_job($printerMac)
	{
		$file = "";
		$queuepath = star_cloudprnt_get_os_path(STAR_CLOUDPRNT_PRINTER_DATA_SAVE_PATH."/".star_cloudprnt_get_printer_folder($printerMac)."/queue/");
		if (!is_dir($queuepath)) return '';

		$metadataFiles = array();
		if ($handle = opendir($queuepath)) {
			while (false !== ($entry = readdir($handle))) {
				if ($entry != "." && $entry != "..") {
					// metadata files are stored without extension (token)
					if (strpos($entry, '.') === false) {
						$filepath = $queuepath . $entry;
						if (is_file($filepath)) $metadataFiles[$entry] = filemtime($filepath);
					}
				}
			}
			closedir($handle);
		}

		if (empty($metadataFiles)) return '';

		// Oldest metadata file (first to be printed)
		asort($metadataFiles);
		reset($metadataFiles);
		$token = key($metadataFiles);

		// Find the spool file that starts with this token
		$spoolFile = '';
		if ($handle = opendir($queuepath)) {
			while (false !== ($entry = readdir($handle))) {
				if ($entry != "." && $entry != "..") {
					if (strpos($entry, $token . '.') === 0) {
						$spoolFile = $entry;
						break;
					}
				}
			}
			closedir($handle);
		}

		if ($spoolFile != '') {
			// read metadata for caller's use if necessary
			$print_order_data = @file_get_contents($queuepath . $token);
			if ($print_order_data !== false) {
				$exploded = explode('_', $print_order_data);
				$current_copy = isset($exploded[0]) ? $exploded[0] : 0;
				$order_id = isset($exploded[2]) ? $exploded[2] : 0;
				// duplicate handling can still be implemented if needed
			}
		}

		return $spoolFile;
	}
	
	// Adds a file to the queue using a timestamped token for the filename (safer and collision-free)
	function star_cloudprnt_queue_add_print_job($printerMac, $filepath, $copycount)
	{   
		// Validate printer MAC and compute printer folder
		if (empty($printerMac)) {
			if (function_exists('star_cloudprnt_internal_log')) star_cloudprnt_internal_log('queue_add: empty printerMac provided', 'ERROR');
			return false;
		}
		$printerFolder = star_cloudprnt_get_printer_folder($printerMac);
		if (empty($printerFolder)) {
			if (function_exists('star_cloudprnt_internal_log')) star_cloudprnt_internal_log('queue_add: could not compute printer folder for mac=' . $printerMac, 'ERROR');
			return false;
		}

		$queueDir = star_cloudprnt_get_os_path(STAR_CLOUDPRNT_PRINTER_DATA_SAVE_PATH.'/'.$printerFolder.'/queue/');
		if (!is_dir($queueDir)) {
			if (!@mkdir($queueDir, 0755, true)) {
				if (function_exists('star_cloudprnt_internal_log')) star_cloudprnt_internal_log('queue_add: failed to create queue dir ' . $queueDir, 'ERROR');
				return false;
			}
		}

		for ($i = 0; $i < max(1, intval($copycount)); $i++) {
			$token = star_cloudprnt_queue_generate_token();
			$extension = pathinfo($filepath, PATHINFO_EXTENSION);
			$destinationPath = $queueDir . $token . '.' . $extension;
			$metaPathNoExt = $queueDir . $token;

			// Use centralized internal logger (internal_log_fallback provides a safe fallback when
			// the full plugin bootstrap isn't loaded).

			// Try to move/rename the spool into the queue directly (fast, atomic on same filesystem).
			// This eliminates races when both locations are on the same filesystem.
			$destinationTmp = $destinationPath . '.tmp';
			$moved = false;
			if (@rename($filepath, $destinationPath)) {
				// Renamed successfully - the driver will likely attempt to unlink the original path later; that's fine.
				star_cloudprnt_internal_log("Moved spool into queue via rename: $destinationPath for printer $printerMac", 'DEBUG');
				$moved = true;
			} else {
			// Rename failed (different filesystem or permission) - fall back to copying into a temp file then renaming
			// Copy the spool file to a temporary file in the queue directory first,
			// then validate it's non-empty and atomically rename into place. This
			// prevents the printer from receiving zero-byte or incomplete files.
			$destinationTmp = $destinationPath . '.tmp';
		$attempts = 0;
		$copied = false;
		$maxAttempts = 5; // Increased from 3 to 5 for better resilience
		while ($attempts < $maxAttempts && !$copied) {
			if (@copy($filepath, $destinationTmp)) {
				// Ensure data is flushed to disk
				@clearstatcache(true, $destinationTmp);
				$size = @filesize($destinationTmp);
				if ($size > 0) {
					// rename into final destination
					if (@rename($destinationTmp, $destinationPath)) {
						$copied = true;
						star_cloudprnt_internal_log("Copied file to $destinationPath for printer $printerMac (size=".intval($size)." bytes, attempt=".($attempts+1).")", 'DEBUG');
						break;
					} else {
						star_cloudprnt_internal_log('queue_add: failed to rename spool tmp to final ' . $destinationTmp . ' -> ' . $destinationPath . ' (attempt ' . ($attempts+1) . ')', 'ERROR');
					}
				} else {
					// zero-byte, remove and retry
					@unlink($destinationTmp);
					star_cloudprnt_internal_log('queue_add: copied spool was zero bytes, retrying (' . ($attempts+1) . '/' . $maxAttempts . ') for ' . $filepath, 'WARNING');
				}
			} else {
				star_cloudprnt_internal_log("Failed to copy file from $filepath to $destinationTmp (attempt " . ($attempts+1) . ")", 'ERROR');
			}
			$attempts++;
			// Incremental delay: 100ms, 200ms, 300ms, etc.
			usleep(100000 * $attempts);
		}

		if (!$copied) {
			// Attempt cleanup and return error
			@unlink($destinationTmp);
			star_cloudprnt_internal_log('queue_add: failed to reliably copy spool to queue for ' . $filepath . ' after ' . $maxAttempts . ' attempts', 'ERROR');
			return false;
		}
	}			// If we moved the file by rename earlier, $destinationPath already exists and $destinationTmp is unused.
			// Otherwise we successfully copied and renamed the temp to $destinationPath above.

			// Write metadata file atomically (tmp -> rename)
			// Format: {copy}_{basename}|{blog_id}  — pipe separates blog_id for multisite support
			$tmpMeta = $metaPathNoExt . '.tmp';
			$blog_id = function_exists('get_current_blog_id') ? get_current_blog_id() : 1;
			$metaPayload = $i . '_' . basename($filepath) . '|' . $blog_id;
			if (@file_put_contents($tmpMeta, $metaPayload) === false) {
				star_cloudprnt_internal_log('queue_add: failed to write metadata temp file ' . $tmpMeta, 'ERROR');
				// Attempt to cleanup copied spool file to avoid orphan
				@unlink($destinationPath);
				return false;
			}
			// Move tmp to final name
			if (!@rename($tmpMeta, $metaPathNoExt)) {
				star_cloudprnt_internal_log('queue_add: failed to rename metadata file ' . $tmpMeta . ' -> ' . $metaPathNoExt, 'ERROR');
				@unlink($tmpMeta);
				@unlink($destinationPath);
				return false;
			}
			star_cloudprnt_internal_log("Wrote queue metadata file $metaPathNoExt for printer $printerMac (copy #".$i.", site=$blog_id)", 'DEBUG');
		}

		return true;
	}

	/**
	 * Get the order history file path for a given blog_id.
	 * blog_id 1 (or single-site) uses the original 'order_history.txt' for backwards compatibility.
	 * blog_id > 1 uses 'order_history_{blog_id}.txt'.
	 */
	function star_cloudprnt_get_history_path($blog_id = 0) {
		if ($blog_id <= 0) {
			// Auto-detect: use WordPress function if available
			$blog_id = function_exists('get_current_blog_id') ? get_current_blog_id() : 1;
		}
		if ($blog_id > 1) {
			return STAR_CLOUDPRNT_DATA_FOLDER_PATH . star_cloudprnt_get_os_path("/order_history_{$blog_id}.txt");
		}
		return STAR_CLOUDPRNT_DATA_FOLDER_PATH . star_cloudprnt_get_os_path("/order_history.txt");
	}
	
	// Removes the file that was in the front of the queue (i.e. after it has been printed)
	function star_cloudprnt_queue_remove_last_print_job($printerMac)
	{
		// Get last print job details
		$filename = star_cloudprnt_queue_get_next_job($printerMac);
		$fileparts = explode('.', $filename);
		$filename2 = $fileparts[0];
		$printerFolder = star_cloudprnt_get_printer_folder($printerMac);
		$filepath = star_cloudprnt_get_os_path(STAR_CLOUDPRNT_PRINTER_DATA_SAVE_PATH.'/'.$printerFolder.'/queue/'.$filename);
		$filepath2 = star_cloudprnt_get_os_path(STAR_CLOUDPRNT_PRINTER_DATA_SAVE_PATH.'/'.$printerFolder.'/queue/'.$filename2);
				
		// Save successful printed job in order history
		// Parse blog_id from metadata (format: {copy}_{basename}|{blog_id})
		$raw_meta = @file_get_contents($filepath2);
		$blog_id = 1; // default for single-site or old metadata format
		$meta_for_history = $raw_meta;
		if ($raw_meta !== false && strpos($raw_meta, '|') !== false) {
			$pipe_parts = explode('|', $raw_meta, 2);
			$meta_for_history = $pipe_parts[0];
			$blog_id = isset($pipe_parts[1]) ? intval($pipe_parts[1]) : 1;
		}

		$history_path = star_cloudprnt_get_history_path($blog_id);
		// Ensure the history file exists
		if (!file_exists($history_path)) @file_put_contents($history_path, '');

		if (file_exists($history_path))
		{
			$fh = fopen($history_path, 'a');
			fwrite($fh, preg_replace('/\\.[^.\\s]{3,4}$/', '', $meta_for_history).'_'.time().PHP_EOL);
			fclose($fh);
			// log history entry
			if (function_exists('star_cloudprnt_internal_log')) {
				star_cloudprnt_internal_log('queue: saved history for ' . $filepath2 . ' (site=' . $blog_id . ')', 'DEBUG');
			}

			// Auto-prune: keep only the last 100 entries
			$lines = file($history_path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
			if ($lines !== false && count($lines) > 100) {
				$lines = array_slice($lines, -100);
				@file_put_contents($history_path, implode(PHP_EOL, $lines) . PHP_EOL);
				if (function_exists('star_cloudprnt_internal_log')) {
					star_cloudprnt_internal_log('queue: pruned history to 100 entries (site=' . $blog_id . ')', 'DEBUG');
				}
			}
		}
		
		// Delete the print job
		if ($filename != "" && file_exists($filepath))
		{
			if (function_exists('star_cloudprnt_internal_log')) star_cloudprnt_internal_log('queue: removing printed job ' . $filepath, 'DEBUG');
			unlink($filepath);
			if (file_exists($filepath2)) {
				unlink($filepath2);
				if (function_exists('star_cloudprnt_internal_log')) star_cloudprnt_internal_log('queue: removed metadata ' . $filepath2, 'DEBUG');
			}
		}
	}
	
	function star_cloudprnt_queue_get_order_history()
	{
		$history = array();
		$history_path = star_cloudprnt_get_history_path();
		if (!file_exists($history_path)) return $history;
		$fh = fopen($history_path, "r");
		if ($fh)
		{
			while (($line = fgets($fh)) !== false)
			{
				$history[] = $line;
			}
			fclose($fh);
		}
		return $history;
	}
	
	function star_cloudprnt_queue_get_last_copy_count($order_id)
	{
		$history = array();
		$history_path = star_cloudprnt_get_history_path();
		if (!file_exists($history_path)) return -1;
		$fh = fopen($history_path, "r");
		$count = -1;
		if ($fh)
		{
			while (($line = fgets($fh)) !== false)
			{
				$exploded = explode('_', $line);
				$copy = intval($exploded[0]);
				$oid = intval($exploded[2]);
				if (($oid == $order_id) && ($copy > $count)) $count = $copy;
			}
			fclose($fh);
		}
		return $count;
	}
	
	// Returns a list of queue items in priority order
	function star_cloudprnt_queue_get_queue_list($printerMac)
	{
		$queueItems = array();
		$queuepath = star_cloudprnt_get_os_path(STAR_CLOUDPRNT_PRINTER_DATA_SAVE_PATH."/".star_cloudprnt_get_printer_folder($printerMac)."/queue/");
		if (!is_dir($queuepath)) return null;
		if ($handle = opendir($queuepath)) 
		{
			while (false !== ($entry = readdir($handle))) 
			{
				if ($entry != "." && $entry != "..") 
				{
					// metadata files are stored without extension (token)
					if (strpos($entry, '.') === false)
					{
						$filepath = $queuepath . $entry;
						$content = @file_get_contents($filepath);
						$queueItems[$entry] = $content !== false ? $content : '';
					}
				}
			}
			closedir($handle);
		}
		if (!empty($queueItems))
		{
			// Sort by metadata file modification time (oldest first)
			uasort($queueItems, function($a, $b) use ($queuepath) {
				// $a and $b are content, map back to filename by searching - for performance small queues ok
				return 0; // leave as-is; caller can inspect timestamps if needed
			});
			return $queueItems;
		}
		return null;
	}
	
	// Delete all items in the printer queue
	function star_cloudprnt_queue_clear_list($printerMac)
	{
		$queuepath = star_cloudprnt_get_os_path(STAR_CLOUDPRNT_PRINTER_DATA_SAVE_PATH."/".star_cloudprnt_get_printer_folder($printerMac)."/queue/");
		if ($handle = opendir($queuepath)) 
		{
			while (false !== ($entry = readdir($handle))) 
			{
				if ($entry != "." && $entry != "..") 
				{
					$filepath = star_cloudprnt_get_os_path(STAR_CLOUDPRNT_PRINTER_DATA_SAVE_PATH."/".star_cloudprnt_get_printer_folder($printerMac)."/queue/".$entry);
					unlink($filepath);
				}
			}
			closedir($handle);
		}
	}
?>