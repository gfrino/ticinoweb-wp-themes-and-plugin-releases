<?php
	include_once('cloudprnt_conf.inc.php');
	include_once('printer.inc.php');
	include_once('printer_queue.inc.php');
	// Ensure a minimal internal logger is available when this endpoint is executed
	// outside the full WordPress/plugin bootstrap (e.g. direct endpoint access).
	include_once(__DIR__ . '/internal_log_fallback.php');

	class Star_CloudPRNT_Printer_Handler
	{
		// Return empty string if invalid UTF8 string
		private function check_invalid_utf8($string) 
		{
			$string = (string) $string;
			if (0 === strlen( $string )) return '';
			// Check for support for utf8 in the installed PCRE library once and store the result in a static
			static $utf8_pcre = null;
			if (!isset( $utf8_pcre )) $utf8_pcre = @preg_match('/^./u', 'a');
			// We can't demand utf8 in the PCRE installation, so just return the string in those cases
			if (!$utf8_pcre) return $string;
			// preg_match fails when it encounters invalid UTF8 in $string
			if (1 === @preg_match('/^./us', $string)) return $string;
			return '';
		}
		
		// Remove whitespace
		private function strip_all_tags($string)
		{
			$string = preg_replace('@<(script|style)[^>]*?>.*?</\\1>@si', '', $string);
			$string = strip_tags($string);
			if ($remove_breaks) $string = preg_replace('/[\r\n\t ]+/', ' ', $string);
			return trim($string);
		}
		
		private function sanitize_parameter($str, $keep_newlines = false)
		{
			$filtered = self::check_invalid_utf8($str);
			if ( strpos($filtered, '<') !== false )
			{
				$filtered = preg_replace_callback('%<[^>]*?((?=<)|>|$)%', 'wp_pre_kses_less_than_callback', $filtered);
				$filtered = self::strip_all_tags($filtered);
				$filtered = str_replace("<\n", "&lt;\n", $filtered);
			}
			if (!$keep_newlines) $filtered = preg_replace('/[\r\n\t ]+/', ' ', $filtered);
			$filtered = trim($filtered);
			$found = false;
			while (preg_match('/%[a-f0-9]{2}/i', $filtered, $match))
			{
				$filtered = str_replace($match[0], '', $filtered);
				$found = true;
			}
			// Strip out the whitespace that may now exist after removing the octets.
			if ($found) $filtered = trim( preg_replace('/ +/', ' ', $filtered) );
			return $filtered;
		}
			
		private function is_valid_mac($mac)
		{
			if (strlen($mac) != 17) return false;
			if ($mac[2] != ':' || $mac[5] != ':' || $mac[8] != ':'||
				$mac[11] != ':' || $mac[14] != ':') return false;
			if (substr($mac, 0, 5) != '00:11') return false;
			return true;
		}
		
		/**
		 * Log a connection event (connected/disconnected) to the session file.
		 * Keeps the last 50 events to avoid unbounded file growth.
		 */
		private static function log_connection_event($sessFile, $mac, $event, $ip = '', $timestamp = null) {
			$sessions = file_exists($sessFile) ? @json_decode(@file_get_contents($sessFile), true) : array();
			if (!is_array($sessions)) $sessions = array();

			$ts = $timestamp ? $timestamp : time();
			$sessions[] = array(
				'event'     => $event,
				'timestamp' => $ts,
				'datetime'  => date('Y-m-d H:i:s', $ts),
				'mac'       => $mac,
				'ip'        => $ip,
			);

			// Keep last 50 events
			if (count($sessions) > 50) {
				$sessions = array_slice($sessions, -50);
			}

			@file_put_contents($sessFile, json_encode($sessions, JSON_PRETTY_PRINT));
		}
		
		public function handle_post()
		{
			// Check is valid POST request type
			if (strtolower($_SERVER['CONTENT_TYPE']) != 'application/json') return;
			// The response to a POST request is always a JSON document
			header('Content-Type: application/json');
			$arr;
			// Get JSON payload recieved from the request and parse it
			$receivedJson = file_get_contents("php://input");
			$parsedJson = json_decode($receivedJson, true);
			// Sanitize JSON params
			foreach ($parsedJson as $key=>$parameter)
			{
				if (!is_array($parsedJson[$key])) $parsedJson[$key] = self::sanitize_parameter($parameter);
			}
			// Validate JSON params
			if (!isset($parsedJson['printerMAC']) || !isset($parsedJson['statusCode']) || !isset($parsedJson['status'])) return;
			if (!self::is_valid_mac($parsedJson['printerMAC'])) return;
			// Setup printer storage directories
			$printerDir = STAR_CLOUDPRNT_PRINTER_DATA_SAVE_PATH."/".star_cloudprnt_get_printer_folder($parsedJson['printerMAC']);
			$queueDir = $printerDir."/queue";
			// Create any local directories for storing printer data if they do not exist already (i.e. the first time the printer polls to the server)
			if (!is_dir($printerDir)) mkdir($printerDir, 0755);
			if (!is_dir($queueDir)) mkdir($queueDir, 0755);
			
			// The $path variable is used to deicde which printer data file needs to be updated depending on 
			// the request type.  Initially, we assume the request is a general communication request (occurs after each poll interval)
			// So the $path variable is set to communication.json
			$path = $printerDir."/communication.json";

			// ── Connection Session Tracking ──────────────────────────────
			// Detect reconnection by checking if the previous communication
			// timestamp is older than pollInterval + tolerance.
			$isRegularPoll = true; // assume regular until proven otherwise
			// If the JSON request contains a request object in the clientAction then the printer is responding to a additional information
			// request (i.e. to get variables like the poll interval from the printer), so in this case the $path variable is set to
			// additional_communication.json to save this additional data
			if (isset($parsedJson["clientAction"][0]["request"]))
			{
				$arr = array("jobReady" => false);
				$path = $printerDir."/additional_communication.json";
				$isRegularPoll = false;
			}
			// Else if we have a general communication request and we still don't have additional data about the printer (like the poll interval)
			// then we need to make sure our response contains a request for the additional information immediately
			else if (!file_exists($printerDir."/additional_communication.json"))
			{
				$arr = array("jobReady" => false,
				"clientAction" => [array("request" => "GetPollInterval"),
								   array("request" => "Encodings"),
								   array("request" => "ClientType"),
								   array("request" => "ClientVersion")]
				);
			}
			// Else if we have a general communication request and we already have additional data about the printer (like the poll interval) then
			// we will only request the same additioanl data again after a specified interval (to reduce load on the server and printer), this is usually
			// set to 60 seconds (stored in the STAR_CLOUDPRNT_ADDITIONAL_DATA_INTERVAL variable).  So if the poll interval was changed, we will always know within 60 seconds
			else if ((time()-filemtime($printerDir."/additional_communication.json")) > STAR_CLOUDPRNT_ADDITIONAL_DATA_INTERVAL)
			{
				$arr = array("jobReady" => false,
				"clientAction" => [array("request" => "GetPollInterval"),
								   array("request" => "Encodings"),
								   array("request" => "ClientType"),
								   array("request" => "ClientVersion")]
				);
			}
			// Else if we have a general communication request and no additional data requests are required, then we can check if a new print job
			// is ready, the star_cloudprnt_queue_get_next_job function checks this and returns the job name to print
			else if (star_cloudprnt_queue_get_next_job($parsedJson['printerMAC']) != "")
			{
				$arr = array("jobReady" => true,
				"mediaTypes" => array('text/plain', 'application/vnd.star.line', 'application/vnd.star.starprnt', 'application/vnd.star.linematrix'),
				"deleteMethod" => "GET");	
			}
			else $arr = array("jobReady" => false);

			// Track connection sessions (only on regular polls, not additional data)
			if ($isRegularPoll) {
				$commFile = $printerDir . "/communication.json";
				$sessFile = $printerDir . "/connection_sessions.json";
				$remoteIp = isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : 'unknown';
				$mac = $parsedJson['printerMAC'];

				if (file_exists($commFile)) {
					$lastMtime = filemtime($commFile);
					$pollRate = 5; // default
					$addCommFile = $printerDir . "/additional_communication.json";
					if (file_exists($addCommFile)) {
						$addData = @json_decode(@file_get_contents($addCommFile), true);
						if (isset($addData['clientAction'])) {
							foreach ($addData['clientAction'] as $d) {
								if (isset($d['request']) && $d['request'] === 'GetPollInterval' && isset($d['result'])) {
									$pollRate = intval($d['result']);
									break;
								}
							}
						}
					}
					$tolerance = defined('STAR_CLOUDPRNT_PRINTER_ONLINE_TOLERANCE') ? STAR_CLOUDPRNT_PRINTER_ONLINE_TOLERANCE : 10;
					$gap = time() - $lastMtime;

					if ($gap > ($pollRate + $tolerance)) {
						// Printer was offline and just reconnected
						self::log_connection_event($sessFile, $mac, 'disconnected', '', $lastMtime);
						self::log_connection_event($sessFile, $mac, 'connected', $remoteIp);
						star_cloudprnt_internal_log('CONNECTION: mac=' . $mac . ' reconnected after ' . $gap . 's gap, ip=' . $remoteIp, 'INFO');
					}
				} else {
					// First ever poll from this printer
					$sessFile = $printerDir . "/connection_sessions.json";
					self::log_connection_event($sessFile, $mac, 'connected', $remoteIp);
					star_cloudprnt_internal_log('CONNECTION: mac=' . $mac . ' first connection, ip=' . $remoteIp, 'INFO');
				}
			}
			// ── End Connection Session Tracking ──────────────────────────
			
			$file = fopen($path, "w");
			fwrite($file, $receivedJson);
			fclose($file);
			$printer = new Star_CloudPRNT_Printer($parsedJson['printerMAC']);
			$printer->createPrinterData($_SERVER['REMOTE_ADDR']);

			// Record WHICH endpoint this printer polls. This is configured on the
			// device itself, so it is the only trustworthy statement of which site a
			// printer belongs to - unlike the admin dropdown, it cannot be set wrong
			// from a browser. The settings page uses it to show a site only its own
			// printers instead of every printer on the network.
			// Written only when it changes: at ~13 printers polling every 5s an
			// unconditional write here would be ~2.7 file writes per second for
			// a value that changes approximately never.
			$endpointUrl = star_cloudprnt_current_endpoint_url();
			if ($endpointUrl !== '') {
				$dataPath = STAR_CLOUDPRNT_PRINTER_DATA_SAVE_PATH . "/"
					. star_cloudprnt_get_printer_folder($parsedJson['printerMAC']) . "/data.json";
				$existing = file_exists($dataPath)
					? json_decode(file_get_contents($dataPath), true) : null;
				$storedUrl = is_array($existing) && isset($existing['serverUrl'])
					? $existing['serverUrl'] : '';
				if (star_cloudprnt_normalize_endpoint($storedUrl)
					!== star_cloudprnt_normalize_endpoint($endpointUrl))
				{
					$printer->updatePrinterData('serverUrl', $endpointUrl);
					star_cloudprnt_internal_log(
						'endpoint recorded for mac=' . $parsedJson['printerMAC']
						. ' url=' . $endpointUrl
						. ($storedUrl !== '' ? ' (was ' . $storedUrl . ')' : ' (first time)'),
						'INFO'
					);
				}
			}

			// ── Printer Health Monitoring ──────────────────────────────────
			// Decode CloudPRNT statusCode and log only on state changes
			$statusCode = isset($parsedJson['statusCode']) ? $parsedJson['statusCode'] : '';
			$rawStatus  = isset($parsedJson['status']) ? $parsedJson['status'] : '';
			$mac        = $parsedJson['printerMAC'];

			// Map CloudPRNT status codes to human-readable descriptions
			$statusMap = array(
				'200' => 'Online / Ready',
				'201' => 'Paper taken (presenter)',
				'211' => 'Paper low',
				'220' => 'Printing in progress',
				'410' => 'Paper out',
				'411' => 'Paper jam',
				'420' => 'Cover open',
				'430' => 'Cutter error',
				'500' => 'Client error',
				'510' => 'Media incompatible',
				'520' => 'Download timeout',
			);

			// Extract numeric code from statusCode (e.g. "200%20OK" → "200")
			$numericCode = preg_replace('/[^0-9]/', '', substr($statusCode, 0, 3));
			$statusLabel = isset($statusMap[$numericCode]) ? $statusMap[$numericCode] : ('Unknown (' . $numericCode . ')');
			$isHealthy   = ($numericCode === '200' || $numericCode === '220');

			// Build health snapshot
			$healthFile = $printerDir . '/health.json';
			$prevHealth = file_exists($healthFile) ? json_decode(file_get_contents($healthFile), true) : null;
			$prevCode   = $prevHealth ? (isset($prevHealth['statusCode']) ? $prevHealth['statusCode'] : '') : '';

			// Every poll hits this endpoint (every few seconds per printer); only write
			// health.json on a status change or once a minute otherwise, so "last seen"
			// stays reasonably fresh without a disk write on every single poll.
			$healthAge = file_exists($healthFile) ? (time() - filemtime($healthFile)) : PHP_INT_MAX;
			if ($numericCode !== $prevCode || $healthAge > 60) {
				$health = array(
					'printerMAC'  => $mac,
					'statusCode'  => $numericCode,
					'statusLabel' => $statusLabel,
					'isHealthy'   => $isHealthy,
					'rawStatus'   => $rawStatus,
					'lastPollUTC' => gmdate('Y-m-d H:i:s'),
					'lastPollLocal' => date('Y-m-d H:i:s'),
					'remoteIP'    => isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : 'unknown',
				);
				@file_put_contents($healthFile, json_encode($health, JSON_PRETTY_PRINT));
			}

			// Log only when status changes (avoid flooding on every 5s poll)
			if ($numericCode !== $prevCode) {
				$logLevel = $isHealthy ? 'INFO' : 'WARNING';
				star_cloudprnt_internal_log(
					'PRINTER_HEALTH: mac=' . $mac .
					' status=' . $numericCode . ' (' . $statusLabel . ')' .
					' previous=' . ($prevCode ?: 'none') .
					' ip=' . (isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : 'unknown'),
					$logLevel
				);
			}
			// ── End Health Monitoring ──────────────────────────────────────
			
			echo json_encode($arr);
		}
		
	public function handle_get()
	{	
		// Add Keep-Alive header to maintain persistent connections
		header('Connection: keep-alive');
		header('Keep-Alive: timeout=120, max=100');
		
		// Sanitize
		$sanitized_mac = self::sanitize_parameter($_GET['mac']);
		if ($sanitized_mac === '') return;
		// Validate
		if (!self::is_valid_mac($sanitized_mac)) return;			$nextPrintJob = star_cloudprnt_queue_get_next_job($sanitized_mac);
			if ($nextPrintJob == "") return;

			// Use centralized/fallback internal logger
			star_cloudprnt_internal_log('printer GET: mac=' . $sanitized_mac . ' nextJob=' . $nextPrintJob, 'DEBUG');
            
			$printerDir = STAR_CLOUDPRNT_PRINTER_DATA_SAVE_PATH."/".star_cloudprnt_get_printer_folder($sanitized_mac);
			$queueDir = $printerDir."/queue";
			$file = $queueDir."/".$nextPrintJob;
			
			if (file_exists($file))
			{
				$remoteIp = isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : 'unknown';
				$filesize = @filesize($file);
				star_cloudprnt_internal_log('serving file to printer (prep): file=' . $file . ' size=' . intval($filesize) . ' bytes remote=' . $remoteIp, 'DEBUG');
                
				$ext = pathinfo($file, PATHINFO_EXTENSION);
				if (strtolower($ext) == "txt")
				{
						ini_set('default_charset', '');
						header('Content-Type: text/plain');
						star_cloudprnt_internal_log('serving file to printer: ' . $file . ' for mac=' . $sanitized_mac . ' ext=txt', 'DEBUG');
						echo file_get_contents($file);
						star_cloudprnt_internal_log('served file (txt) bytes=' . intval($filesize) . ' to ' . $remoteIp, 'DEBUG');
				}
				else if (strtolower($ext) == "png")
				{
					header('Content-Type: image/png');
					// Get image size
					list($width, $height) = getimagesize($file);
					$fh = fopen($file, 'rb');
					fpassthru($fh);
					star_cloudprnt_internal_log('served file (png) bytes=' . intval($filesize) . ' to ' . $remoteIp, 'DEBUG');
				}
				else if (strtolower($ext) == "jpg")
				{
					header('Content-Type: image/jpeg');
					// Get image size
					list($width, $height) = getimagesize($file);
					$fh = fopen($file, 'rb');
					fpassthru($fh);
					star_cloudprnt_internal_log('served file (jpg) bytes=' . intval($filesize) . ' to ' . $remoteIp, 'DEBUG');
				}
				else if (strtolower($ext) == "slt")
				{
					header('Content-Type: application/vnd.star.line');
					echo file_get_contents($file);
					star_cloudprnt_internal_log('served file (slt) bytes=' . intval($filesize) . ' to ' . $remoteIp, 'DEBUG');
				}
				else if (strtolower($ext) == "slm")
				{
					header('Content-Type: application/vnd.star.linematrix');
					echo file_get_contents($file);
					star_cloudprnt_internal_log('served file (slm) bytes=' . intval($filesize) . ' to ' . $remoteIp, 'DEBUG');
				}
				else if (strtolower($ext) == "spt")
				{
					header('Content-Type: application/vnd.star.starprnt');
					echo file_get_contents($file);
					star_cloudprnt_internal_log('served file (spt) bytes=' . intval($filesize) . ' to ' . $remoteIp, 'DEBUG');
				}
			}
			exit;
		}
		
		// Return a blank text file, then proceed with deleteing the print job
		public function handle_delete()
		{
			ini_set('default_charset', '');
			// Sanitize
			$sanitized_mac = self::sanitize_parameter($_GET['mac']);
			if ($sanitized_mac === '') return;
			// Validate
			if (!self::is_valid_mac($sanitized_mac)) return;
			$code = isset($_GET['code']) ? $_GET['code'] : '';
			star_cloudprnt_internal_log('printer DELETE: mac=' . $sanitized_mac . ' code=' . $code, 'DEBUG');
			// Log which job appears to be next (for traceability)
			$nextJobBeforeRemove = star_cloudprnt_queue_get_next_job($sanitized_mac);
			star_cloudprnt_internal_log('printer DELETE: nextJobBeforeRemove=' . $nextJobBeforeRemove . ' for mac=' . $sanitized_mac, 'DEBUG');
			if ($code !== '' && ($code[0] === '2')) {
				// Printer indicates success (2xx) - remove the printed job from the queue
				star_cloudprnt_queue_remove_last_print_job($sanitized_mac);
				star_cloudprnt_internal_log('printer DELETE: removed last print job for mac=' . $sanitized_mac, 'DEBUG');
			} else {
				star_cloudprnt_internal_log('printer DELETE: did not remove job (non-2xx code) for mac=' . $sanitized_mac, 'DEBUG');
			}
		}
	}
	
	// Setup document headers, these headers apply for all requests.
	header("Cache-Control: max-age=0, no-cache, no-store, must-revalidate");
	header("Pragma: no-cache");
	header("Expires: Thu, 01 Jan 1970 00:00:00 GMT");
	// Set connection timeout to prevent hanging connections
	@ini_set('default_socket_timeout', 30);
	@ini_set('max_execution_time', 60);
	
	if (!is_dir(STAR_CLOUDPRNT_DATA_FOLDER_PATH)) mkdir(STAR_CLOUDPRNT_DATA_FOLDER_PATH, 0755);
	if (!is_dir(STAR_CLOUDPRNT_PRINTER_PENDING_SAVE_PATH)) mkdir(STAR_CLOUDPRNT_PRINTER_PENDING_SAVE_PATH, 0755);
	if (!is_dir(STAR_CLOUDPRNT_PRINTER_DATA_SAVE_PATH)) mkdir(STAR_CLOUDPRNT_PRINTER_DATA_SAVE_PATH, 0755);
	if (!file_exists(STAR_CLOUDPRNT_DATA_FOLDER_PATH.'/order_history.txt')) file_put_contents(STAR_CLOUDPRNT_DATA_FOLDER_PATH.'/order_history.txt', '');
	
	$printer_handler = new Star_CloudPRNT_Printer_Handler();
	// POST requests from the printer come with a JSON payload
	// The below code reads the payload and parses it into an array
	// The parsed data can then be used, although this is not mandatory
	if ($_SERVER['REQUEST_METHOD'] == 'POST') $printer_handler->handle_post();
	// By default a GET request usually means the printer is requesting
	// data that it can print.  When printing is done the printer sends a
	// HTTP DELETE request to indicate the job has been printed, however some
	// servers only support HTTP POST and HTTP GET so if you specify the deleteMethod
	// as GET in your HTTP POST JSON response, then the printer will send a HTTP GET
	// request and add "delete" into the parameters, e.g. http://<ip>/index.php?mac=<mac>&delete.
	// So in this case if the delete parameter exists we count the job as printed, otherwise we
	// handle it as a standard GET request and provide data for printing
	else if ($_SERVER['REQUEST_METHOD'] == 'GET')
	{
			if (isset($_GET['delete'])) {
				// Log delete request from printer
				star_cloudprnt_internal_log('printer requested delete for mac=' . $_GET['mac'], 'DEBUG');
				$printer_handler->handle_delete();
			} else {
				$printer_handler->handle_get();
			}
	}
	// A delete request indicates printing has finished and the current job can be marked as complete / deleted
	else if ($_SERVER['REQUEST_METHOD'] == 'DELETE') $printer_handler->handle_delete();
?>