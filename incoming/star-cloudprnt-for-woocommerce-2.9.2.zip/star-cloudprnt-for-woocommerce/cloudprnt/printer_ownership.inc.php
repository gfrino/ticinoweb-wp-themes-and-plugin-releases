<?php
/**
 * Network-wide printer ownership registry.
 *
 * INVARIANT: one physical printer belongs to exactly ONE site.
 * A site may own MANY printers - bellinzona.littleinka.ch drives a primary and a
 * secondary - so the registry is keyed on MAC (unique) and holds the owning
 * blog_id. Keying it the other way round would break multi-printer shops.
 *
 * WHY THIS EXISTS
 * All printer data lives in one network-wide directory keyed only by MAC
 * (wp-content/star-cloudprnt/printerdata/<mac>/queue/). Nothing in that layout
 * ties a printer to a subsite, so before v2.6.0 two restaurants could be
 * configured with the same printer and their orders printed on one device.
 * v2.6.0 removed the silent "print on the first printer of the whole network"
 * fallback; this module closes the remaining hole by refusing the misconfiguration
 * at the point it is made, and refusing to print if it somehow exists anyway.
 *
 * SINGLE-SITE INSTALLS are unaffected: is_multisite() is false, there is only one
 * owner possible, and every check short-circuits to "yes, you own it".
 */

if (!defined('STAR_CLOUDPRNT_OWNERS_OPTION')) {
	define('STAR_CLOUDPRNT_OWNERS_OPTION', 'star_cloudprnt_printer_owners');
}

if (!function_exists('star_cloudprnt_is_network')) {
	function star_cloudprnt_is_network()
	{
		return function_exists('is_multisite') && is_multisite();
	}
}

if (!function_exists('star_cloudprnt_this_blog_id')) {
	function star_cloudprnt_this_blog_id()
	{
		return function_exists('get_current_blog_id') ? (int) get_current_blog_id() : 1;
	}
}

/** Registry as array( normalised-mac => blog_id ). Network-wide on multisite. */
if (!function_exists('star_cloudprnt_get_printer_owners')) {
	function star_cloudprnt_get_printer_owners()
	{
		$owners = star_cloudprnt_is_network() && function_exists('get_site_option')
			? get_site_option(STAR_CLOUDPRNT_OWNERS_OPTION, array())
			: get_option(STAR_CLOUDPRNT_OWNERS_OPTION, array());
		return is_array($owners) ? $owners : array();
	}
}

if (!function_exists('star_cloudprnt_save_printer_owners')) {
	function star_cloudprnt_save_printer_owners($owners)
	{
		if (star_cloudprnt_is_network() && function_exists('update_site_option')) {
			return update_site_option(STAR_CLOUDPRNT_OWNERS_OPTION, $owners);
		}
		return update_option(STAR_CLOUDPRNT_OWNERS_OPTION, $owners, false);
	}
}

/** blog_id that owns this printer, or 0 if unclaimed. */
if (!function_exists('star_cloudprnt_get_printer_owner')) {
	function star_cloudprnt_get_printer_owner($mac)
	{
		$mac = star_cloudprnt_normalize_mac($mac);
		if ($mac === '') {
			return 0;
		}
		$owners = star_cloudprnt_get_printer_owners();
		return isset($owners[$mac]) ? (int) $owners[$mac] : 0;
	}
}

/**
 * Claim a printer for the current site.
 * Returns true if this site owns it afterwards, false if another site already does.
 * An unclaimed printer is claimed on first use, so existing installs keep working
 * and the registry fills itself in without a migration step.
 */
if (!function_exists('star_cloudprnt_claim_printer')) {
	function star_cloudprnt_claim_printer($mac, $blog_id = null)
	{
		if (!star_cloudprnt_is_network()) {
			return true;
		}
		$mac = star_cloudprnt_normalize_mac($mac);
		if ($mac === '') {
			return false;
		}
		if ($blog_id === null) {
			$blog_id = star_cloudprnt_this_blog_id();
		}
		$blog_id = (int) $blog_id;

		$owners = star_cloudprnt_get_printer_owners();
		$current = isset($owners[$mac]) ? (int) $owners[$mac] : 0;

		if ($current === $blog_id) {
			return true;
		}
		if ($current !== 0) {
			return false; // owned by a different site - caller must refuse
		}
		$owners[$mac] = $blog_id;
		star_cloudprnt_save_printer_owners($owners);
		return true;
	}
}

/**
 * Re-sync the registry for one site from its own printer settings.
 * Adds the MACs it now uses and drops the ones it no longer uses, touching only
 * rows owned by this site - another site's claims are never modified here.
 */
if (!function_exists('star_cloudprnt_sync_site_printers')) {
	function star_cloudprnt_sync_site_printers($macs, $blog_id = null)
	{
		if (!star_cloudprnt_is_network()) {
			return;
		}
		if ($blog_id === null) {
			$blog_id = star_cloudprnt_this_blog_id();
		}
		$blog_id = (int) $blog_id;

		$wanted = array();
		foreach ((array) $macs as $m) {
			$m = star_cloudprnt_normalize_mac($m);
			if ($m !== '') {
				$wanted[$m] = true;
			}
		}

		$owners = star_cloudprnt_get_printer_owners();
		$changed = false;

		foreach ($owners as $mac => $owner) {
			if ((int) $owner === $blog_id && !isset($wanted[$mac])) {
				unset($owners[$mac]);
				$changed = true;
			}
		}
		foreach (array_keys($wanted) as $mac) {
			$existing = isset($owners[$mac]) ? (int) $owners[$mac] : 0;
			if ($existing === 0) {
				$owners[$mac] = $blog_id;
				$changed = true;
			}
		}
		if ($changed) {
			star_cloudprnt_save_printer_owners($owners);
		}
	}
}

/** Human-readable site name for an owning blog_id, for error messages. */
if (!function_exists('star_cloudprnt_owner_label')) {
	function star_cloudprnt_owner_label($blog_id)
	{
		$blog_id = (int) $blog_id;
		if ($blog_id && function_exists('get_blog_details')) {
			$d = get_blog_details($blog_id);
			if ($d && !empty($d->domain)) {
				return $d->domain . ' (blog ' . $blog_id . ')';
			}
		}
		return 'blog ' . $blog_id;
	}
}
