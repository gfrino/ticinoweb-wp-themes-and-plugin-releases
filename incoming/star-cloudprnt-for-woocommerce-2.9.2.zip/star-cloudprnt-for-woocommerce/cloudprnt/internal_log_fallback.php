<?php
// Fallback internal logger for non-WP contexts (cloudprnt endpoint, CLI, etc.)
// This provides a minimal implementation of star_cloudprnt_internal_log when the
// full plugin bootstrap isn't loaded. If the plugin-level star_cloudprnt_log exists
// it will be preferred.
if (!function_exists('star_cloudprnt_internal_log')) {
    function star_cloudprnt_internal_log($message, $level = 'INFO') {
        if (function_exists('star_cloudprnt_log')) {
            star_cloudprnt_log($message, $level);
            return;
        }
        if (function_exists('star_cloudprnt_get_plugin_root')) {
            $logDir = rtrim(star_cloudprnt_get_plugin_root(), '/\\') . DIRECTORY_SEPARATOR . 'logs' . DIRECTORY_SEPARATOR;
            if (!is_dir($logDir)) @mkdir($logDir, 0755, true);
            $logFile = $logDir . 'star-cloudprnt.log';
            $time = date('Y-m-d H:i:s');
            @file_put_contents($logFile, sprintf("[%s] [%s] %s\n", $time, strtoupper($level), $message), FILE_APPEND | LOCK_EX);
            return;
        }
        // Last resort: PHP error log
        error_log(sprintf("[%s] %s", strtoupper($level), $message));
    }
}
