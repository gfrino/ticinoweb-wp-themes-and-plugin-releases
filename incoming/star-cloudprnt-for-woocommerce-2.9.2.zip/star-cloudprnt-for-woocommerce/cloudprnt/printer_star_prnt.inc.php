<?php
	include_once('printer_queue.inc.php');

	class Star_CloudPRNT_Star_Prnt_Job
	{
		const SLM_NEW_LINE_HEX = "0A";
		const SLM_SET_EMPHASIZED_HEX = "1B45";
		const SLM_CANCEL_EMPHASIZED_HEX = "1B46";
		const SLM_SET_LEFT_ALIGNMENT_HEX = "1B1D6100";
		const SLM_SET_CENTER_ALIGNMENT_HEX = "1B1D6101";
		const SLM_SET_RIGHT_ALIGNMENT_HEX = "1B1D6102";
		const SLM_FEED_FULL_CUT_HEX = "1B6402";
		const SLM_FEED_PARTIAL_CUT_HEX = "1B6403";
		const SLM_CODEPAGE_HEX = "1B1D74";
		
		private $printerMac;
		private $printerMeta;
		private $tempFilePath;
		private $printJobBuilder = "";
		
		public function __construct($printer, $tempFilePath)
		{
			$this->printerMeta = $printer;
			$this->printerMac = $printer['printerMAC'];
			$this->tempFilePath = $tempFilePath;
			// Ensure instance property is initialized (avoid accidental local var)
			$this->printJobBuilder = "";
		}
		
		private function str_to_hex($string)
		{
			$hex = '';
			for ($i = 0; $i < strlen($string); $i++)
			{
				$ord = ord($string[$i]);
				$hexCode = dechex($ord);
				$hex .= substr('0'.$hexCode, -2);
			}
			return strToUpper($hex);
		}
		
		public function set_text_emphasized()
		{
			$this->printJobBuilder .= self::SLM_SET_EMPHASIZED_HEX;
		}
		
		public function cancel_text_emphasized()
		{
			$this->printJobBuilder .= self::SLM_CANCEL_EMPHASIZED_HEX;
		}
		
		public function set_text_left_align()
		{
			$this->printJobBuilder .= self::SLM_SET_LEFT_ALIGNMENT_HEX;
		}
		
		public function set_text_center_align()
		{
			$this->printJobBuilder .= self::SLM_SET_CENTER_ALIGNMENT_HEX;
		}
		
		public function set_text_right_align()
		{
			$this->printJobBuilder .= self::SLM_SET_RIGHT_ALIGNMENT_HEX;
		}
		
		public function set_codepage($codepage)
		{
			if($codepage == "UTF-8") {
				$this->printJobBuilder .= "1b1d295502003001"."1b1d295502004000";
			} elseif ($codepage == "1252") {
				$this->printJobBuilder .= self::SLM_CODEPAGE_HEX."20";
			} else {
				$this->printJobBuilder .= self::SLM_CODEPAGE_HEX.$codepage;
			}
		}
		
		public function add_nv_logo($keycode)
		{
			//$this->printJobBuilder .= "1B1C70".$keycode."00".self::SLM_NEW_LINE_HEX
			$this->printJobBuilder .="1B1D284C06003045".$this->str_to_hex($keycode)."0101";
		}
		
		public function set_font_magnification($width, $height)
		{
			$w = 0;
			$h = 0;

			if($width <= 1) {
				$w = 0;
			} elseif ($width >= 6) {
				$w = 5;
			} else {
				$w = $width - 1;
			}
			
			if($height <= 1) {
				$h = 0;
			} elseif ($height >= 6) {
				$h = 5;
			} else {
				$h = $height - 1;
			}
			
			$this->printJobBuilder .= "1B69"."0".$h."0".$w;
		}		
		
		public function add_hex($hex)
		{
			$this->printJobBuilder .= $hex;
		}
		
		public function add_text($text)
		{
			$this->printJobBuilder .= $this->str_to_hex($text);
		}
		
		public function add_text_line($text)
		{
			$this->printJobBuilder .= $this->str_to_hex($text).self::SLM_NEW_LINE_HEX;
		}
		
		public function add_new_line($quantity)
		{
			for ($i = 0; $i < $quantity; $i++)
			{
				$this->printJobBuilder .= self::SLM_NEW_LINE_HEX;
			}
		}

		public function add_vertical_spacing_mm($mm)
		{
			$dots = intval($mm * 8); // 8 dots ≈ 1mm at 203dpi
			$this->printJobBuilder .= "1B" . "4A" . sprintf("%02X", $dots);
		}
		
		public function sound_buzzer($circuit, $pulse_ms, $delay_ms)
		{
			$circuit = intval($circuit);
			if($circuit < 1) $circuit = 1;
			if($circuit > 2) $circuit = 2;
			
			$pulse_param = $pulse_ms / 20;
			$delay_param = $delay_ms / 20;
			
			if($pulse_param <= 0) $pulse_param = 0;
			if($pulse_param >= 255) $pulse_param = 255;
			
			if($delay_param <= 0) $delay_param = 0;
			if($delay_param >= 255) $pulse_param = 255;
			
			//$command = sprintf("1B1D07%02X%02X%02X", $circuit, $pulse_param, $delay_param);

			$command = sprintf("1B1D1911%02X%02X%02X", $circuit, $pulse_param, $delay_param)
			 						. sprintf("1B1D1912%02X0100", $circuit);

			//error_log("Command -> " . $command);

			$this->printJobBuilder .= $command;
		}
		
		public function set_text_highlight()
		{
			$this->printJobBuilder .= "1B34";
		}
		
		public function cancel_text_highlight()
		{
			$this->printJobBuilder .= "1B35";
		}

		public function add_qr_code($error_correction, $cell_size, $data)
		{
			$model = 2;
			if($error_correction < 0) $error_correction = 0;
			if($error_correction > 3) $error_correction = 3;
      if($cell_size < 1) $cell_size = 1;
			if($cell_size > 8) $cell_size = 8;
			$data_length = strlen($data);

			$set_model = sprintf("1B1D795330%02X", $model);
			$set_error_level = sprintf("1B1D795331%02X", $error_correction);
			$set_cell_size = sprintf("1B1D795332%02X", $cell_size);
			$set_data_prefix = sprintf("1B1D79443100%02X%02X", fmod($data_length, 256), intval($data_length / 256));
			$print = "1B1D7950";

			$this->printJobBuilder .= $set_model
															. $set_error_level
															. $set_cell_size
															. $set_data_prefix
															. $this->str_to_hex($data)
															. $print;
		}

		public function add_barcode($type, $module, $hri, $height, $data)
		{
			$n2 = 1; 
			$n3 = 1;

			if($type < 0 || $type > 13)	return;							// Invalid barcode type
			if($hri) $n2 = 2;																// Print human-readable characters under the bacrode
			
			if($type == 0 || $type == 1 || $type == 3 || $type == 4 || $type == 6 || $type == 7)		// UPC-E, UPC-A, JAN/EAN8, JAN/EAN13, Code128, Code 93
			{
				$n3 = $module - 1;
				if($n3 < 1) $n3 = 1;
				if($n3 > 3) $n3 = 3;
			}
			elseif ($type == 4 || $type == 5 || $type == 8)		// Code 93, ITF, NW-7
			{
				$n3 = $module;
				if($n3 < 1) $n3 = 1;
				if($n3 > 9) $n3 = 9;
			}
			elseif ($type >= 9 && $type <= 13)		// GS1-128, GS1 DataBar
			{
				$n3 = $module;
				if($n3 < 1) $n3 = 1;
				if($n3 > 6) $n3 = 6;
			}

			if($height < 8) $height = 8;					// Minimum 1mm height
			if($height > 255) $height = 255;			// Max 32mm height

			$print_bc = sprintf("1B62%02X%02X%02X%02X", $type, $n2, $n3, $height)
									. $this->str_to_hex($data)
									. "1E";

			$this->printJobBuilder .= $print_bc;
		}

		public function add_raster_image($raster_data, $width, $height)
		{
			// Star printers: Use GS v 0 command (print raster bit image)
			// Format: GS v 0 m xL xH yL yH [data]
			// m = mode (0=normal, 1=double width, 2=double height, 3=double both)
			// xL xH = width in bytes (little endian)
			// yL yH = height in dots (little endian)
			
			$bytes_per_line = (int)ceil($width / 8);
			
			$xL = $bytes_per_line & 0xFF;
			$xH = ($bytes_per_line >> 8) & 0xFF;
			$yL = $height & 0xFF;
			$yH = ($height >> 8) & 0xFF;
			
			// GS v 0 m xL xH yL yH [data]
			$cmd = "1D7630"; // GS v 0
			$cmd .= "00"; // mode 0 (normal)
			$cmd .= sprintf("%02X%02X", $xL, $xH);
			$cmd .= sprintf("%02X%02X", $yL, $yH);
			$cmd .= $this->str_to_hex($raster_data);
			
			$this->printJobBuilder .= $cmd;
		}

		public function cut()
		{
			$this->printJobBuilder .= self::SLM_FEED_PARTIAL_CUT_HEX;
		}

		public function printjob($copies)
		{
			// Build binary data to write
			// Try to convert hex string into binary robustly. Some environments or plugins
			// may accidentally inject non-hex characters; sanitize and fall back to a
			// manual decoder if hex2bin fails.
			$rawHex = $this->printJobBuilder;
			$hex = preg_replace('/[^0-9A-Fa-f]/', '', $rawHex);
			if (strlen($hex) % 2 == 1) {
				$hex = '0' . $hex; // pad odd length
			}
			$data = @hex2bin($hex);
			if ($data === false) {
				// Manual decode fallback (guarantees bytes when hex is valid)
				$data = '';
				$len = strlen($hex);
				for ($i = 0; $i < $len; $i += 2) {
					$byte = substr($hex, $i, 2);
					$data .= chr(hexdec($byte));
				}
			}
			if ($data === false || strlen($data) === 0) {
				if (function_exists('star_cloudprnt_internal_log')) {
					star_cloudprnt_internal_log('printjob: aborted - produced empty binary payload, hex_len=' . strlen($rawHex) . ' sample=' . substr($rawHex, 0, 200), 'ERROR');
				}
				return; // still nothing, abort to avoid zero-byte spools
			}

		// Attempt direct write into the printer's queue directory (atomic tmp->rename)
		if (function_exists('star_cloudprnt_internal_log')) star_cloudprnt_internal_log('printjob: binary_payload_size=' . strlen($data) . ' bytes for printer ' . $this->printerMac . ' copies=' . $copies, 'DEBUG');
		$printerFolder = star_cloudprnt_get_printer_folder($this->printerMac);
		$queueDir = star_cloudprnt_get_os_path(STAR_CLOUDPRNT_PRINTER_DATA_SAVE_PATH . '/' . $printerFolder . '/queue/');
		$wroteDirect = false;
		if (is_dir($queueDir) && is_writable($queueDir)) {
			// Write multiple copies to the queue
			$copiesWritten = 0;
			for ($copyNum = 0; $copyNum < $copies; $copyNum++) {
				$token = star_cloudprnt_queue_generate_token();
				$destinationPath = $queueDir . $token . '.spt';
				$destinationTmp = $destinationPath . '.tmp';
				// Try write to tmp file inside queue
				$fh = @fopen($destinationTmp, 'wb');
				if ($fh !== false) {
					fwrite($fh, $data);
					fflush($fh);
					fclose($fh);
					@clearstatcache(true, $destinationTmp);
					$size = @filesize($destinationTmp);
					if ($size > 0 && @rename($destinationTmp, $destinationPath)) {
						// Write metadata atomically
						$metaTmp = $queueDir . $token . '.tmp';
						$metaPayload = '0_' . basename($destinationPath);
						if (@file_put_contents($metaTmp, $metaPayload) !== false && @rename($metaTmp, $queueDir . $token)) {
							$copiesWritten++;
							if (function_exists('star_cloudprnt_internal_log')) star_cloudprnt_internal_log('queue: wrote direct spool ' . $destinationPath . ' for printer ' . $this->printerMac . ' size=' . intval($size) . ' copy=' . ($copyNum + 1) . '/' . $copies, 'DEBUG');
						}
						else {
							@unlink($destinationPath);
							@unlink($metaTmp);
							if (function_exists('star_cloudprnt_internal_log')) star_cloudprnt_internal_log('queue: failed to write metadata after direct spool for ' . $destinationPath, 'ERROR');
						}
					} else {
						@unlink($destinationTmp);
						if (function_exists('star_cloudprnt_internal_log')) star_cloudprnt_internal_log('queue: direct write produced zero bytes or failed rename for ' . $destinationTmp, 'WARNING');
					}
				}
				// Small delay between copies to ensure unique tokens
				if ($copyNum < $copies - 1) usleep(10000); // 10ms between copies
			}
			if ($copiesWritten > 0) {
				$wroteDirect = true;
				if (function_exists('star_cloudprnt_internal_log')) star_cloudprnt_internal_log('queue: wrote ' . $copiesWritten . ' copies directly to queue for printer ' . $this->printerMac, 'INFO');
			}
		}			if (! $wroteDirect) {
				// Fallback: write to temp path and use queue_add which already handles rename/copy fallback
				$fh = fopen($this->tempFilePath, 'w');
				fwrite($fh, $data);
				fclose($fh);

				// Log spool file stats immediately after writing
				if (function_exists('star_cloudprnt_internal_log')) {
					$size = @filesize($this->tempFilePath);
					star_cloudprnt_internal_log('spool_written: file=' . $this->tempFilePath . ' size=' . intval($size) . ' bytes', 'DEBUG');
				}

				// Give the filesystem a short moment to stabilize on some environments (NFS, slow IO)
				usleep(50000); // 50ms

				// Preserve a human-readable copy of the spool file for debugging
				if (function_exists('star_cloudprnt_get_plugin_root')) {
					$root = rtrim(star_cloudprnt_get_plugin_root(), '/\\');
					$copyDir = $root . DIRECTORY_SEPARATOR . 'logs' . DIRECTORY_SEPARATOR . 'spool_copies' . DIRECTORY_SEPARATOR;
					if (!is_dir($copyDir)) @mkdir($copyDir, 0755, true);
					$copyName = 'spool_' . basename($this->tempFilePath) . '_' . time() . '.spt.txt';
					@copy($this->tempFilePath, $copyDir . $copyName);
					if (function_exists('star_cloudprnt_internal_log')) star_cloudprnt_internal_log('spool_copy: ' . $copyDir . $copyName, 'DEBUG');
				}

				star_cloudprnt_queue_add_print_job($this->printerMac, $this->tempFilePath, $copies);
				@unlink($this->tempFilePath);
			} else {
				// Direct write succeeded, nothing to cleanup of temp
			}
		}
	}
?>