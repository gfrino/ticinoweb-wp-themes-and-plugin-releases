<?php
	include_once('printer_queue.inc.php');

	class Star_CloudPRNT_Text_Plain_Job
	{
		const SLM_NEW_LINE_HEX = "0A";
		const SLM_SET_EMPHASIZED_HEX = "1B45";
		const SLM_CANCEL_EMPHASIZED_HEX = "1B46";
		const SLM_SET_LEFT_ALIGNMENT_HEX = "1B1D6100";
		const SLM_SET_CENTER_ALIGNMENT_HEX = "1B1D6101";
		const SLM_SET_RIGHT_ALIGNMENT_HEX = "1B1D6102";
		const SLM_FEED_FULL_CUT_HEX = "1B6402";
		const SLM_FEED_PARTIAL_CUT_HEX = "1B6403";
		const SLM_CODEPAGE_HEX = "1B1D74";
		
		private $printerMac;
		private $printerMeta;
		private $tempFilePath;
		private $printJobBuilder = "";
		
		public function __construct($printer, $tempFilePath)
		{
			$this->printerMeta = $printer;
			$this->printerMac = $printer["printerMAC"];
			$this->tempFilePath = $tempFilePath;
			// Ensure instance property is initialized (avoid accidental local var)
			$this->printJobBuilder = "";
			
		}
		
		private function str_to_hex($string)
		{
			$hex = '';
			for ($i = 0; $i < strlen($string); $i++)
			{
				$ord = ord($string[$i]);
				$hexCode = dechex($ord);
				$hex .= substr('0'.$hexCode, -2);
			}
			return strToUpper($hex);
		}
		
		public function set_text_emphasized()
		{
		}
		
		public function cancel_text_emphasized()
		{
		}
		
		public function set_text_left_align()
		{
		}
		
		public function set_text_center_align()
		{
		}
		
		public function set_text_right_align()
		{
		}
		
		public function set_codepage($codepage)
		{
		}
		
		public function add_nv_logo($keycode)
		{
		}
		
		public function set_font_magnification($width, $height)
		{
		}
		
		public function add_hex($hex)
		{
			$this->printJobBuilder .= $hex;
		}
		
		public function add_text($text)
		{
			$this->printJobBuilder .= $this->str_to_hex($text);
		}
		
		public function add_text_line($text)
		{
			$this->printJobBuilder .= $this->str_to_hex($text).self::SLM_NEW_LINE_HEX;
		}
		
		public function add_new_line($quantity)
		{
			for ($i = 0; $i < $quantity; $i++)
			{
				$this->printJobBuilder .= self::SLM_NEW_LINE_HEX;
			}
		}

		public function add_vertical_spacing_mm($mm)
		{
			$dots = intval($mm * 8); // 8 dots ≈ 1mm at 203dpi
			$this->printJobBuilder .= "1B" . "4A" . sprintf("%02X", $dots);
		}

		public function sound_buzzer($circuit, $pulse_ms, $delay_ms)
		{
		}
		
		public function set_text_highlight()
		{
		}
		
		public function cancel_text_highlight()
		{
		}

		public function add_qr_code($error_correction, $cell_size, $data)
		{
		}

		public function add_barcode($type, $module, $hri, $height, $data)
		{
		}

		public function add_raster_image($raster_data, $width, $height)
		{
			// Text plain mode: skip raster images (not supported in plain text)
		}

		public function cut()
		{
		}
		
		public function printjob($copies)
		{
			// Robust hex -> binary conversion
			$rawHex = $this->printJobBuilder . self::SLM_NEW_LINE_HEX;
			$hex = preg_replace('/[^0-9A-Fa-f]/', '', $rawHex);
			if (strlen($hex) % 2 == 1) $hex = '0' . $hex;
			$data = @hex2bin($hex);
			if ($data === false) {
				$data = '';
				$len = strlen($hex);
				for ($i = 0; $i < $len; $i += 2) {
					$byte = substr($hex, $i, 2);
					$data .= chr(hexdec($byte));
				}
			}
			if ($data === false || strlen($data) === 0) {
				if (function_exists('star_cloudprnt_internal_log')) star_cloudprnt_internal_log('printjob: aborted - produced empty binary payload, hex_len=' . strlen($rawHex) . ' sample=' . substr($rawHex, 0, 200), 'ERROR');
				return;
			}

		// Attempt direct write into the printer's queue directory (atomic tmp->rename)
		if (function_exists('star_cloudprnt_internal_log')) star_cloudprnt_internal_log('printjob: binary_payload_size=' . strlen($data) . ' bytes for printer ' . $this->printerMac . ' copies=' . $copies, 'DEBUG');
		$printerFolder = star_cloudprnt_get_printer_folder($this->printerMac);
		$queueDir = star_cloudprnt_get_os_path(STAR_CLOUDPRNT_PRINTER_DATA_SAVE_PATH . '/' . $printerFolder . '/queue/');
		$wroteDirect = false;
		if (is_dir($queueDir) && is_writable($queueDir)) {
			// Write multiple copies to the queue
			$copiesWritten = 0;
			for ($copyNum = 0; $copyNum < $copies; $copyNum++) {
				$token = star_cloudprnt_queue_generate_token();
				$destinationPath = $queueDir . $token . '.txt';
				$destinationTmp = $destinationPath . '.tmp';
				// Try write to tmp file inside queue
				$fh = @fopen($destinationTmp, 'wb');
				if ($fh !== false) {
					fwrite($fh, $data);
					fflush($fh);
					fclose($fh);
					@clearstatcache(true, $destinationTmp);
					$size = @filesize($destinationTmp);
					if ($size > 0 && @rename($destinationTmp, $destinationPath)) {
						// Write metadata atomically
						$metaTmp = $queueDir . $token . '.tmp';
						$metaPayload = '0_' . basename($destinationPath);
						if (@file_put_contents($metaTmp, $metaPayload) !== false && @rename($metaTmp, $queueDir . $token)) {
							$copiesWritten++;
							if (function_exists('star_cloudprnt_internal_log')) star_cloudprnt_internal_log('queue: wrote direct spool ' . $destinationPath . ' for printer ' . $this->printerMac . ' size=' . intval($size) . ' copy=' . ($copyNum + 1) . '/' . $copies, 'DEBUG');
						}
						else {
							@unlink($destinationPath);
							@unlink($metaTmp);
							if (function_exists('star_cloudprnt_internal_log')) star_cloudprnt_internal_log('queue: failed to write metadata after direct spool for ' . $destinationPath, 'ERROR');
						}
					} else {
						@unlink($destinationTmp);
						if (function_exists('star_cloudprnt_internal_log')) star_cloudprnt_internal_log('queue: direct write produced zero bytes or failed rename for ' . $destinationTmp, 'WARNING');
					}
				}
				// Small delay between copies to ensure unique tokens
				if ($copyNum < $copies - 1) usleep(10000); // 10ms between copies
			}
			if ($copiesWritten > 0) {
				$wroteDirect = true;
				if (function_exists('star_cloudprnt_internal_log')) star_cloudprnt_internal_log('queue: wrote ' . $copiesWritten . ' copies directly to queue for printer ' . $this->printerMac, 'INFO');
			}
		}			if (! $wroteDirect) {
				// Fallback: write to temp path and use queue_add which already handles rename/copy fallback
				$fh = fopen($this->tempFilePath, 'w');
				fwrite($fh, $data);
				fclose($fh);

				// Log spool file stats immediately after writing
				if (function_exists('star_cloudprnt_internal_log')) {
					$size = @filesize($this->tempFilePath);
					star_cloudprnt_internal_log('spool_written: file=' . $this->tempFilePath . ' size=' . intval($size) . ' bytes', 'DEBUG');
				}

				// Give the filesystem a short moment to stabilize on some environments (NFS, slow IO)
				usleep(50000); // 50ms

				// Preserve a human-readable copy of the spool file for debugging
				if (function_exists('star_cloudprnt_get_plugin_root')) {
					$root = rtrim(star_cloudprnt_get_plugin_root(), '/\\');
					$copyDir = $root . DIRECTORY_SEPARATOR . 'logs' . DIRECTORY_SEPARATOR . 'spool_copies' . DIRECTORY_SEPARATOR;
					if (!is_dir($copyDir)) @mkdir($copyDir, 0755, true);
					$copyName = 'spool_' . basename($this->tempFilePath) . '_' . time() . '.spt.txt';
					@copy($this->tempFilePath, $copyDir . $copyName);
					if (function_exists('star_cloudprnt_internal_log')) star_cloudprnt_internal_log('spool_copy: ' . $copyDir . $copyName, 'DEBUG');
				}

				star_cloudprnt_queue_add_print_job($this->printerMac, $this->tempFilePath, $copies);
				@unlink($this->tempFilePath);
			} else {
				// Direct write succeeded, nothing to cleanup of temp
			}
		}
	}
?>