<?php
	include_once('cloudprnt_conf.inc.php');
	
	// Generate the correct printer dcommand driver class for the specified job format
	function star_cloudprnt_command_generator(&$selectedPrinter, &$file)
	{
		$printer = NULL;
		$format = $selectedPrinter['format'];
		
		if ($format == "txt") {	
			$printer = new Star_CloudPRNT_Text_Plain_Job($selectedPrinter, $file);					// Plain text output only
		} else if ($format == "slt") {
			$printer = new Star_CloudPRNT_Star_Line_Mode_Job($selectedPrinter, $file);			// Star Line Mode for Thermal Printers
		} else if ($format == "slm") {
			$printer = new Star_CloudPRNT_Star_Line_Mode_Job($selectedPrinter, $file);			// Star Line Mode for Dot-Matrix printers
		} else if ($format == "spt") {
			$printer = new Star_CloudPRNT_Star_Prnt_Job($selectedPrinter, $file);						// StarPRNT
			
		} else {
			$printer = new Star_CloudPRNT_Text_Plain_Job($selectedPrinter, $file);					// Fall back to plain text
		}

		return $printer;
	}	

	// Returns file friendly name for the printer mac address
	// Canonical form of a printer MAC. ALWAYS compare/store MACs through this.
	// Printers and admin pages have been observed reporting the same MAC in
	// different letter case (e.g. 00:11:62:41:8C:94 vs ...8c:94). Because the
	// folder name is derived straight from the MAC and PHP string compare is
	// case-sensitive, that produced TWO directories for one physical printer and
	// silently unbound the subsite that pointed at the other spelling.
	function star_cloudprnt_normalize_mac($printerMac)
	{
		return strtolower(trim((string) $printerMac));
	}

	function star_cloudprnt_get_printer_folder($printerMac)
	{
		return str_replace(":", ".", star_cloudprnt_normalize_mac($printerMac));
	}

	// Comparable form of a CloudPRNT endpoint URL: host + path, lowercased, no
	// scheme, no query, no trailing slash. Scheme is dropped deliberately - a
	// printer may be configured with http:// while the site reports https://,
	// and behind a proxy the server's own view of the scheme is unreliable.
	function star_cloudprnt_normalize_endpoint($url)
	{
		$url = trim((string) $url);
		if ($url === '') {
			return '';
		}
		$url = preg_replace('#^[a-z][a-z0-9+.\-]*://#i', '', $url); // strip scheme
		$url = explode('?', $url, 2)[0];                            // strip query
		$url = explode('#', $url, 2)[0];
		return rtrim(strtolower($url), '/');
	}

	// The endpoint URL this request came in on. Used by cloudprnt.php to record
	// WHERE a printer actually polls, which is the only trustworthy statement of
	// which site a printer belongs to - it is configured on the device itself and
	// cannot be changed from the admin UI.
	function star_cloudprnt_current_endpoint_url()
	{
		$https = (!empty($_SERVER['HTTPS']) && strtolower($_SERVER['HTTPS']) !== 'off')
			|| (isset($_SERVER['HTTP_X_FORWARDED_PROTO'])
				&& strtolower($_SERVER['HTTP_X_FORWARDED_PROTO']) === 'https');
		$host = isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : '';
		$path = isset($_SERVER['REQUEST_URI']) ? explode('?', $_SERVER['REQUEST_URI'], 2)[0] : '';
		if ($host === '') {
			return '';
		}
		return ($https ? 'https://' : 'http://') . $host . $path;
	}

	// Does a stored setting refer to this printer? Accepts the printer's MAC, the
	// list key, or its display name, all case-insensitively.
	//
	// Use this ANYWHERE a saved option is compared to a printer. The stored options
	// hold a MAC while the admin dropdown is keyed on the display name, so a plain
	// == between the two silently stops matching the moment a printer is renamed -
	// and an unmatched <select> just shows its FIRST entry, i.e. some other
	// restaurant's printer, as though it were the chosen one. That happened on
	// 2026-08-21 and looked exactly like a misrouted printer.
	function star_cloudprnt_option_matches_printer($optionValue, $printerData, $listMac = '')
	{
		$want = star_cloudprnt_normalize_mac($optionValue);
		if ($want === '') {
			return false;
		}
		$candidates = array(
			star_cloudprnt_normalize_mac($listMac),
			star_cloudprnt_normalize_mac(isset($printerData['name']) ? $printerData['name'] : ''),
			star_cloudprnt_normalize_mac(isset($printerData['printerMAC']) ? $printerData['printerMAC'] : ''),
			star_cloudprnt_normalize_mac(isset($printerData['macAddress']) ? $printerData['macAddress'] : ''),
		);
		return in_array($want, $candidates, true);
	}
	
	// Converts file friednly printer mac address to proper printer mac address
	function star_cloudprnt_get_printer_mac($printerFolder)
	{
		return str_replace(".", ":", $printerFolder);
	}
	
	// Returns a list of all printers and their data, that are currently or has in the past polled the server
	function star_cloudprnt_get_printer_list()
	{
		$list = array();
		foreach (glob(STAR_CLOUDPRNT_PRINTER_DATA_SAVE_PATH."/*", GLOB_ONLYDIR) as $printerpath)
		{
			$printerMac = star_cloudprnt_get_printer_mac(basename($printerpath));
			
			$jsonpath = $printerpath."/communication.json";
			$printerdata = json_decode(file_get_contents($jsonpath), true);
			$printerdata['lastActive'] = filemtime($jsonpath);
			
			$jsonpath = $printerpath."/data.json";
			$printerdata2 = json_decode(file_get_contents($jsonpath), true);
			$printerdata['name'] = $printerdata2['name'];
			$printerdata['ipAddress'] = $printerdata2['ipAddress'];
			
			$jsonpath = $printerpath."/additional_communication.json";
			$printerdata3 = json_decode(file_get_contents($jsonpath), true);
			foreach ($printerdata3['clientAction'] as $data)
			{
				$printerdata[$data['request']] = $data['result'];
			}
			
			$printerdata['printerOnline'] = star_cloudprnt_is_printer_online($printerdata['GetPollInterval'], filemtime($printerpath."/communication.json"));
			
			$list[$printerMac] = $printerdata;
		}
		return $list;
	}
	
	// Returns printer connectivity status, note this does not factor in real printer status (such as offline due to cover open)
	function star_cloudprnt_is_printer_online($pollRate, $lastCommunicationTime)
	{
		// Use configurable tolerance (default 10 seconds) to be more forgiving of network delays
		$tolerance = defined('STAR_CLOUDPRNT_PRINTER_ONLINE_TOLERANCE') ? STAR_CLOUDPRNT_PRINTER_ONLINE_TOLERANCE : 10;
		if ((time()-$lastCommunicationTime) > ($pollRate + $tolerance)) return false;
		return true;
	}
	
	class Star_CloudPRNT_Printer
	{
		private $printer_mac;
		
		public function __construct($printer_mac)
		{
			$this->printer_mac = $printer_mac;
		}
		
		// Returns all the data of a specific printer that is or has in the past polled the server
		function getPrinterData()
		{
			$printerpath = STAR_CLOUDPRNT_PRINTER_DATA_SAVE_PATH."/".star_cloudprnt_get_printer_folder($this->printer_mac);

			$printerdata = array();
			$jsonpath = $printerpath."/communication.json";
			if (file_exists($jsonpath)) $printerdata = json_decode(file_get_contents($jsonpath), true);
			
			$jsonpath = $printerpath."/data.json";
			if (file_exists($jsonpath))
			{
				$printerdata2 = json_decode(file_get_contents($jsonpath), true);
				$printerdata['name'] = $printerdata2['name'];
				$printerdata['ipAddress'] = $printerdata2['ipAddress'];
				$printerdata['lastActive'] = filemtime($jsonpath);
			}
			
			$jsonpath = $printerpath."/additional_communication.json";
			if (file_exists($jsonpath))
			{
				$printerdata3 = json_decode(file_get_contents($jsonpath), true);
				foreach ($printerdata3['clientAction'] as $data)
				{
					$printerdata[$data['request']] = $data['result'];
				}
				$printerdata['printerOnline'] = star_cloudprnt_is_printer_online($printerdata['GetPollInterval'], filemtime($printerpath."/data.json"));
			}

			return $printerdata;
		}
		
		// Creates printer data file for a newly joined printer
		function createPrinterData($ip)
		{
			$jsonpath = STAR_CLOUDPRNT_PRINTER_DATA_SAVE_PATH."/".star_cloudprnt_get_printer_folder($this->printer_mac)."/data.json";
			
			if (!file_exists($jsonpath))
			{
				$printerdata = array("name" => $this->printer_mac,
								"macAddress" => $this->printer_mac,
								"ipAddress" => $ip,
								"isOnline" => true);
				$fp = fopen($jsonpath, 'w');
				fwrite($fp, json_encode($printerdata));
				fclose($fp);
			}
			else
			{
				// Only write when the IP actually changed. This runs on EVERY poll, so
				// at 13 printers polling every 5s it was rewriting data.json about 2.7
				// times a second forever, to store a value that essentially never moves.
				$current = json_decode(@file_get_contents($jsonpath), true);
				$knownIp = is_array($current) && isset($current['ipAddress']) ? $current['ipAddress'] : null;
				if ($knownIp !== $ip) {
					$this->updatePrinterData("ipAddress", $ip);
				}
			}

			return true;
		}
		
		// Updates existing data for existing printers that are polling the server
		function updatePrinterData($variable, $value)
		{
			$jsonpath = STAR_CLOUDPRNT_PRINTER_DATA_SAVE_PATH."/".star_cloudprnt_get_printer_folder($this->printer_mac)."/data.json";
			if (file_exists($jsonpath))
			{
				$printerdata = json_decode(file_get_contents($jsonpath), true);
				$printerdata[$variable] = $value;
				$fp = fopen($jsonpath, 'w');
				fwrite($fp, json_encode($printerdata));
				fclose($fp);
			}
		}
		
		// Generic function to delete a directory, regardless if it is empty or not
		function deleteDirectory($dir)
		{
			if (!file_exists($dir)) return true;

			if (!is_dir($dir)) return unlink($dir);

			foreach (scandir($dir) as $item) 
			{
				if ($item == '.' || $item == '..') continue;

				if (!$this->deleteDirectory($dir . DIRECTORY_SEPARATOR . $item)) return false;
			}
			return rmdir($dir);
		}
		
		// Used to delete all data on printers that have previously polled the server
		function deletePrinter()
		{
			$printerdata = $this->getPrinterData($this->printer_mac);
			if (!$printerdata['printerOnline'])
			{
				$dirpath = STAR_CLOUDPRNT_PRINTER_DATA_SAVE_PATH."/".star_cloudprnt_get_printer_folder($this->printer_mac);
				$this->deleteDirectory($dirpath);
			}
		}
	}
?>