=== Food Delivery Call Center for WooCommerce ===
Contributors: lawrenceowen, athompson1, gcubero, fmahmood, ticinoweb
Tags: star, printing, printers, automated, e-commerce, store, sales, downloadable, downloads, woocommerce, restaurant, order, receipt
Requires at least: 5.9
Tested up to: 6.4
Requires PHP: 8.0
Stable tag: 2.5.3
License: MIT

Food Delivery Call Center for WooCommerce enables CloudPRNT automation with Star receipt printers while adding streamlined call-center and POS workflows for WooCommerce stores.

== Admin Menu Structure (Definitivo) ==
La struttura del menu amministrativo è ora fissata e non subirà ulteriori modifiche strutturali. Questo garantisce stabilità operativa per gli operatori del call center e per la formazione.

**Quando Call Center è abilitato** (top-level menu):
* Call Center (POS React + inserimento ordini manuali)
  - StarMicronics Printer (Impostazioni & Stato CloudPRNT)
  - Logs (Visibile solo se logging attivato / diagnostica)
  - Z Report (Stampa rapporto fine giornata)

**Quando Call Center è disabilitato** (default):
* Impostazioni → Star CloudPRNT
  - CloudPRNT Logs (se logging attivo)
  - Z Report

= Attivazione Call Center =
Per abilitare il menu Call Center:
1. Andare in **Impostazioni → Star CloudPRNT** (o **StarMicronics Printer** se già attivo)
2. Nella sezione "CloudPRNT Setup", spuntare il checkbox **"Enable POS Tab"**
3. Salvare le modifiche
4. Il menu top-level "Call Center" apparirà nella barra laterale amministrativa

Nota: Per impostazione predefinita il Call Center è **disattivato**. L'opzione si trova nella pagina impostazioni (`star-cloudprnt-enable-pos`).

= Note Tecniche =
* Il punto di ingresso POS utilizza un'interfaccia React moderna caricata via bundle `dist/app.js`.
* Gli endpoint REST dedicati (`/wp-json/fd-pos/v1/...`) alimentano ricerche prodotti, clienti e add-ons.
* La voce "Call Center" rimane separata dalle impostazioni generiche di WordPress per ridurre i clic dell'operatore.
* La gerarchia sopra è da considerarsi "set in stone" per documentazione e procedure interne.

== Description ==
Food Delivery Call Center will enable you to print automated receipts each time a customer places an order on your WooCommerce based eCommerce website.
This can be used to quickly create a remote order/receipt printing solution for restaurants, take-aways, bakeries and similar sites, with minimal set-up time or cost.

This plugin can only be used alongside the WooCommerce WordPress plugin.  For more information on the WooCommerce plugin please visit www.woocommerce.com

== Installation ==
1. Install and activate the plugin.
2. Go to your WordPress admin control panel and you should notice a new link for "Food Delivery Call Center" under your WordPress "Settings" category.
3. Once you have opened up the Star CloudPRNT settings page, you will be given a unique Server URL which you need to copy.
4. Next setup your compatible Star printer onto your network and run a self-test on the printer to get its IP address.
5. Type the printer IP address into a web browser to access its web interface and then login (default username "root" and password "public").
6. Navigate to the "Star CloudPRNT" section and enable the CloudPRNT service, then paste the URL you copied earlier into the "Server URL" field.
7. Press "Submit" then navigate to the "Save" section.
8. Choose "Save --> Configuration printing --> Restart device" and the printer will reboot (this can take up to 2 minutes).
9. Once the printer has rebooted, go back to your Star CloudPRNT settings page and refresh it, you will notice your printer will be populated in the printer list which means your printer is now setup and ready to use.
10. Finally, you can now enable the CloudPRNT service within the Star CloudPRNT settings page, once enabled all orders placed through WooCommerce will also be printed out on your Star printer.

For help and support please e-mail support@star-emea.com

= Video Installation Guide =
https://www.youtube.com/watch?v=2O3pZJ-kfqk

= Minimum Requirements =
* PHP 7.2 or greater.
* WordPress 5.0, 5.1, 5.3, 5.4, 5.5, 5.6, 5.7
* WooCommerce plugin 4.0, 4.1, 4.2, 4.3, 4.4, 4.5, 4.6, 4.7, 4.8, 4.9, 5.0, 5.1
* Star TSP650II, TSP700II, TSP800II or SP700 series printer with a IFBD-HI01X/HI02X interface. Printer interface firmware 1.6 or later recommended.
* Star mC-Print3 or mC-Print2 series printer, firmware version 3.0 or later recommended.


== Frequently Asked Questions ==
 
= Which printer models are supported? =
 
Supported printer models are:

* Star TSP650II with HIX interface
* Star mC-Print3 (required plugin version 1.1.0 or later)
* Star mC-Print2 (required plugin version 1.1.0 or later)
* Star TSP700II with HIX interface
* Star TSP800II with HIX interface (currently limited to 80mm paper width support)
* Star SP700 with HIX interface

Version 3.0 firmware or later is recommended for mC-Print printer models.

= Can I print my local language characters? =

Yes, you can enable UTF-8 text encoding if you have a compatible printer model to resolve typical language specific character issues.
Please use the plugin settings page to enable UTB-8 mode.

Models with UTF-8 support are the TSP650II, mC-Print3 and mC-Print2. 
These printers cover most Latin, Cyrilic, Greek and CJK characters, although not all characters can be supported by all device models and for TSP654II a firmware update may be required. Please talk with Star for advice if necessary.
Support for full-width CJK characters is partial. They are supported but there may be page formatting and word wrapping errors.

There is currently no support for printing right-to-left languages in this plugin. If this is required, please talkw with Star about alternative integration options.

= Can I modify the print job design/layout? =

At this time, modifying the print job layout is possible only by directly editing the plugin PHP source code. This is entirely permitted by the license terms.
Your local Star Micronics support contact may be able to offer some assistance.

= How can I add an image to the top or end of my print? =

Images must be pre-stored inside the printer FlashROM memory in order to be printed bu this plugin. Once stored, they will have logo number/id, which can be input into the "Printer Logo Settings" settings area to enable top and/or bottom logo printing.
Storing images inside the Print FlashROM is possible with a software utility provided by Star Micronics, included with the standard indows driver package. These can be downloaded from the Star Micronics web site.

= Sometimes orders do not print, or print later than expected =

Please make sure that you update your plugin version to 2.0.0 or later, and ensure that your printing trigger is not set to "Thank You", this method of detecting new orders is not considered to be reliable, and included only for compatibility with existing sites using older versions of the plugin.
If issues continue, then please check the quality of your printers internet connection so that it can communicatw with your site. Star printers have a disconection message print option that can sometimes help to diagnose network connectivity issues. Please talk with your local Star Micronics support office if assistance is needed.

= My printer does not appear on the "Selected Printer" dropdown list =

This means that you printer is unable to connect with your server, and can have many potential causes:

  As a first step, if you are using an mC-Print2 or mC-Print3 model printer, the please update your printer firmware to version 3.0 or later to ensure compatibility with web hosts that have stronger TLS encryption.
  Firmware can be updated using the Star "mC-Print Utility" app, available via Google Play, or Apple App stores.

  Check that the printer has a working outgoing internet connection. Star tech support may be able to help with this if needed.

  Ensure that your your hosting does not have a traffic filter that may be blocking the printer from connecting to your web site or aggressively caching responses to your sites CloudPRNT URL. It may be necessary to ask your hosting provided to set up a rule to allow your printer to connect to your sites CloudPRNT URL. They must allow at least GET and POST requests without caching responses.


== Screenshots ==
1. Star CloudPRNT settings page.
2. Printer management page.

== Upgrade Notice ==

= 2.0.0 =
* Make printing trigger method user configurable - can improve reliability
* Support order and item metadata/custom field printing (Add-ons, delivery times etc.)
* Extended receipt configuration
* Print button on the edit order page

= 1.1.0 = 
* Add Support for Star mC-Print3 and mC-Print2 printer ranges

== Changelog ==

= 2.5.3 =
* fix: Print negative fee lines (e.g. loyalty-points checkout discounts like "Sconto punti fedeltà") in the item totals section. These were already correctly included in the order's TOTAL, but never shown as their own line, making printed receipts look like the numbers didn't add up.

= 2.5.2 =
* feat: Add "Buzzer repeat count" setting to let the buzzer sound multiple times (1 to 10) on print jobs.

= 2.5.1 =
* Refactor: Remove all hardcoded subsite ID constraints (`95`, `102`) and enable 100% dynamic custom secondary printing for any subsite configured with a secondary printer.

= 2.5.0 =
* feat: Add Google Maps QR code to delivery receipts for easy driver navigation

= 2.4.14 =
* feat: Add "Reset & Risincronizza Stampanti" button to plugin settings page
* The button resets all printer display names to their MAC address (canonical identifier), clears all lock/selection WP options, then auto-reloads the page so printers can be cleanly reassigned per site — useful when printers reconnect with different IPs or after server restarts
* Implementation: secure AJAX handler with nonce, iterates data.json per printer folder under STAR_CLOUDPRNT_PRINTER_DATA_SAVE_PATH
* Bumped version to 2.4.14

= 2.4.13 =
* feat: Add support for `orario_richiesto` custom checkout field (Lungolago.ch delivery time window) — printed as "Orario Consegna" on receipt
* feat: Add generic ThemeHigh / WooCommerce custom checkout field fallback — any field in `wc_fields_billing`, `wc_fields_shipping`, or `wc_fields_additional` is now printed automatically with its label, without code changes

= 2.4.12 =
* Fix: Print actual shipping method from WooCommerce instead of fallback text on receipt header.

= 2.4.11 =
* Fixed fallback printer selection bug that caused empty MAC addresses when no printer was selected.
* Bumped version to 2.4.11

= 2.4.10 =
* Fixed undefined array key 'id' warning in order-handler.inc.php.
* Bumped version to 2.4.10

= 2.4.9 =
* Fixed HTTP 500 error on Apache servers caused by .htaccess with restrictive AllowOverride settings
* Rewrote cloudprnt/.htaccess: removed `RewriteEngine Off` and fixed `<IfModule LiteSpeed>` syntax
* Added ModSecurity Bypass checkbox in Settings (default: enabled, auto-test on toggle)
* Plugin auto-removes .htaccess if it causes HTTP 500, with persistent option across updates
* Added inline printer info cards on main Settings page (connectivity, poll interval, MAC, IP, status)
* Added connection session monitoring: tracks connect/disconnect events per printer
* Connection history displayed as collapsible timeline in printer info card (last 10 events)
* Added multisite support for order history: per-site files (order_history_{blog_id}.txt)
* Blog ID embedded in queue metadata for correct per-site history in non-WordPress endpoint context
* Auto-prune order history to last 100 entries (was: unlimited growth)
* Bumped version to 2.4.9

= 2.4.8 =
* Added bulk print feature: select multiple orders in the WooCommerce orders list and print them all via Star CloudPRNT
* Green "Print Selected" button added next to the bulk actions dropdown for one-click printing
* Also available as a standard bulk action in the dropdown ("Print via Star CloudPRNT")
* AJAX-based printing with confirmation dialog, progress feedback, and success notification
* Supports both HPOS and legacy order list screens
* Includes nonce verification and capability checks for security
* Bumped version to 2.4.8

= 2.4.7 =
* Added real-time printer health monitoring to the CloudPRNT endpoint
* Each printer poll now decodes CloudPRNT status codes (200=OK, 410=Paper Out, 420=Cover Open, etc.)
* Health snapshot saved to `health.json` per printer for quick remote status checks
* Status changes are logged automatically (only on state transitions to avoid log flooding)
* Bumped version to 2.4.7

= 2.4.4 =
* React POS: ripristinato e verificato l'autocomplete cliente su Nome, Telefono e Email (debounce, suggerimenti, tastiera).
* Layout Call Center migliorato: topbar con Totale ordine e pulsante Reset, pannelli riordinati (Cliente → Prodotti → Carrello → Consegna & Pagamento → Azioni).
* Fix REST 401: tutte le chiamate POS usano `restBase` e l'header `X-WP-Nonce` per l'autenticazione.
* CSS estratto correttamente con `app.css` e caricato in WP admin.
* Documentazione aggiornata: attivazione menu Call Center tramite impostazione (default disattivato).

= 2.4.0 =
* Introduced real-time customer autocomplete that prefills address and contact fields inside the Call Center form.
* Added product search with live add-on selectors, SKU matching, and cart preview for faster manual order entry.
* Extended POS order creation to price WooCommerce Product Add-ons correctly, record metadata, and trigger CloudPRNT.
* Exposed secured REST endpoints (`/wp-json/fd-pos/v1/...`) to power autocomplete workflows for customers, products, and add-ons.

= 2.3.2 =
* Added dedicated Call Center top-level menu with streamlined manual order workflow and modern layout.
* Refined StarMicronics submenu structure: Printer, conditional Logs, and Z Report tabs now align with user expectations.
* Fixed duplicate submenu entries and ensured Call Center access remains available when POS mode is active.

= 2.3.1 =
* Rebranded plugin UI to Food Delivery Call Center across admin pages and documentation.
* Grouped CloudPRNT settings, logs, and Z Report tabs under the Food Delivery Call Center menu for a streamlined workflow.

= 2.3.0 =
* NEW: Z Report (Rapporto Fine Giornata) - daily sales report printing feature
* Added new "Z Report" tab in settings to print end-of-day sales summaries
* Z Report includes: total orders, sales, taxes, shipping, payment methods breakdown, shipping methods, and products sold
* Report date selection with printer chooser
* Changed add-ons/supplements font size from 1x1 to 2x1 (wider text) while keeping bold formatting
* Completely separate system from order printing - no interference with existing functionality

= 2.2.1 =
* Improved printer connectivity and connection stability:
  - Reduced polling interval from 120 to 60 seconds for more frequent printer communication
  - Increased printer online detection tolerance from 5 to 10 seconds to handle network delays
  - Added HTTP Keep-Alive headers to maintain persistent connections with printer
  - Implemented connection timeout configuration (30s socket, 60s execution)
  - Enhanced JSON payload validation and error handling in POST requests
  - Increased retry attempts from 3 to 5 with incremental delay for queue file operations
* Enhanced receipt formatting:
  - TOTAL line now displays in bold with 2x1 font magnification (double width, normal height)
  - Optimized TOTAL padding to prevent line wrapping on thermal printers

= 2.2.1 =
* Fixed "Undefined array key 'id'" warning in admin panel by adding proper isset() check for $_REQUEST parameters
* Improved error handling for non-order admin pages

= 2.2.0 =
* Enhanced receipt text formatting: supplements and variations now display in bold at 1x1 size for improved readability
* Improved contact details and customer notes visibility with 2x1 font magnification (double width)
* Timestamp format streamlined to 24-hour format only (H:i) removing duplicate AM/PM display
* Delivery method (Spedizione: Consegna a domicilio / Ritiro in sede) now prints in bold with extra spacing for better visibility
* Overall receipt layout improvements for thermal printer output clarity

= 2.1.37 =
* Add printer lock mechanism for multisite environments to prevent printer reassignment after server restarts
* Lock/unlock buttons with visual indicators (🔒/🔓) for both primary and secondary printers
* Lock state persists across server restarts and maintains printer assignments per subsite
* Locked printers are disabled from modification until explicitly unlocked
* Print WooCommerce add-on labels and values on a single line (e.g., "Condimenti: Avocado") for improved readability
* Separate product variations from product title - print title at 2x2 size, variations at 1x1 size on separate lines
* Always print add-ons/supplements at 1x1 size for consistency and readability

= 2.1.36 =
* Fix multiple copies printing issue - now correctly prints specified number of copies when using direct queue write
* Add Swiss phone number formatting (e.g., 0797287413 displays as 079 728 74 13)
* Increase phone number text size to 2x2 magnification for better visibility
* Increase order date/time text size to 1x2 magnification
* Increase quantity line text size to 1x2 magnification
* Implement dynamic supplement text sizing - uses 1x1 magnification when more than 4 supplements, 1x2 for 4 or fewer
* Improve logging for copy operations with detailed debug information

= 2.0.3 =
* Improve buzzer compatibility with mC-Print models.
* Add option to print ID and or SKU on item lines
* Add option to trigger printing when and order is assigned on-hold status
* Enable word-wrapping when printing items, in case of very long item names
* Enable Word-wrapping when printing header section fields, in case of long information on 58mm/2" paper
* Format the sub-heading order number and print timestamp on tow lines, in case they can not fit side by side
* Add printer control class methods for text highlighting, Qr Code, and Barcode printing methods to the printer command generation classes.
  Not currently exposed as features but may be useful to anyone forking/modifying the plugin.

= 2.0.2 =
* Fix missing "Shipping Method" from the receipt header.

= 2.0.1 =
* Do not print any blank lines when the title, or item footer text is empty
* Add some mailchimp metadata key names to the defailt exclusions list
* Change the timing for registering settings, to avoid reported issue with accessing settings with their default value.
* Remove all settings when uninstalled

= 2.0.0 =
* Make printing trigger method user configurable
* Clean-up settings page design
* Add a setting to list custom fields that should be excluded from printing
* Add a "Print with Star CloudPRNT" button to the Edit Order page sidebar
* Add a settings link to the plugins WordPress plugins page
* Add support for printing order item metadata - compatible with many Add-Ons plugins
* Add support for printing order metadata - compatible with many delivery scheduling plugins and others that append fields to an order
* Add a setting to support multiple copies
* Add support for setting an alternative print name for products by adding a "star_cp_print_name" attribute
* Display a warning when WooCommerce can not be detected, instead of refusing to work completely, because the detection can fail in case of some custom WooCommerce installs.
* Improve Timestamp display to match the site formatting local and site timezone - instead of server timezone
* Refactor the source, to make it more approachable to developers who fork the project
* Drop support for WordPress versions earlier than 5.x.x
* Drop support for WooCommerce versions earlier than 4.x.x
* Drop support for PHP versions earlier than 7.2

