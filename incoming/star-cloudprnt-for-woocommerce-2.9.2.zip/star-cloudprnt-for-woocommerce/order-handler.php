<?php

	/*
	 *	Receipt/ticket rendering functions
	 *
	 *  All functions here are responsible for generating the printed receipt, by analysing a WC_Order
	 *  object to obtain information about the order, and calling printer functions on the $printer object.
	 * 
	*/

	// Always include this - it is responsible for registering the necessary hooks to trigger print jobs
	include_once('order-handler.inc.php');
	include_once('maps-address-qr.php');



    // Return the text data used as a separator/horizontal line on the page
    function star_cloudprnt_get_seperator($max_chars)
    {
        return str_repeat('_', $max_chars);
    }

    // Format phone number to Swiss standard (e.g., 0797287413 -> 079 728 74 13)
    function star_cloudprnt_format_swiss_phone($phone)
    {
        // Remove all spaces, dashes, and other non-digit characters
        $cleaned = preg_replace('/[^0-9]/', '', $phone);
        
        // Check if it's a Swiss mobile number (10 digits starting with 07)
        if (strlen($cleaned) == 10 && substr($cleaned, 0, 2) == '07') {
            return substr($cleaned, 0, 3) . ' ' . substr($cleaned, 3, 3) . ' ' . substr($cleaned, 6, 2) . ' ' . substr($cleaned, 8, 2);
        }
        // Check if it's a Swiss landline (9 digits starting with 0)
        elseif (strlen($cleaned) == 9 && substr($cleaned, 0, 1) == '0') {
            return substr($cleaned, 0, 3) . ' ' . substr($cleaned, 3, 3) . ' ' . substr($cleaned, 6, 2) . ' ' . substr($cleaned, 8, 1);
        }
        // Return as-is if doesn't match expected format
        return $phone;
    }

    // iterate through the order line items, rendering each one
    function star_cloudprnt_print_items(&$printer, &$selectedPrinter, &$order, &$order_meta)
    {
        $max_chars = $selectedPrinter['columns'];
        $order_items = $order->get_items();

        // IBSA Menu lines (hidden _ibsa_* meta) are printed as one block per menu;
        // without them $ibsa_groups is empty and the loop below is unchanged.
        $ibsa_groups = function_exists('star_cloudprnt_ibsa_groups') ? star_cloudprnt_ibsa_groups($order_items) : array();
        $ibsa_line_group = array();
        foreach ($ibsa_groups as $ibsa_group => $ibsa_ids) {
            foreach ($ibsa_ids as $ibsa_id) $ibsa_line_group[$ibsa_id] = $ibsa_group;
        }

        foreach ($order_items as $item_id => $item_data) {
            if (isset($ibsa_line_group[$item_id])) {
                $ibsa_group = $ibsa_line_group[$item_id];
                if (isset($ibsa_groups[$ibsa_group])) {
                    star_cloudprnt_ibsa_print_group($printer, $selectedPrinter, $order_items, $ibsa_groups[$ibsa_group]);
                    unset($ibsa_groups[$ibsa_group]);
                }
                continue;
            }
            // Resolve product info safely
            $product = null;
            if (is_object($item_data) && method_exists($item_data, 'get_product')) {
                $product = $item_data->get_product();
            }

            // Retrieve ids from the order item (method or array access)
            $product_id = 0;
            $variation_id = 0;
            if (is_array($item_data) || $item_data instanceof ArrayAccess) {
                if (isset($item_data['product_id'])) $product_id = (int)$item_data['product_id'];
                if (isset($item_data['variation_id'])) $variation_id = (int)$item_data['variation_id'];
            }
            if (empty($product_id) && is_object($item_data) && method_exists($item_data, 'get_product_id')) $product_id = (int)$item_data->get_product_id();
            if (empty($variation_id) && is_object($item_data) && method_exists($item_data, 'get_variation_id')) $variation_id = (int)$item_data->get_variation_id();

            // Fallback load product by variation or parent
            if (empty($product) && !empty($variation_id) && function_exists('wc_get_product')) {
                $product = wc_get_product($variation_id);
                if (function_exists('error_log')) error_log('star_cloudprnt: loaded variation fallback for item_id=' . $item_id . ' variation_id=' . $variation_id);
            }
            if (empty($product) && !empty($product_id) && function_exists('wc_get_product')) {
                $product = wc_get_product($product_id);
            }

            // Store variation attributes separately - extract BEFORE getting full name
            $variation_attributes = array();
            $product_name = '';
            
            // Get the base product name from item data
            $product_name = is_object($item_data) && method_exists($item_data, 'get_name') ? $item_data->get_name() : (isset($item_data['name']) ? $item_data['name'] : '');
            
            // If this is a variation, extract parent name and variation attributes from meta
            if ($product && method_exists($product, 'is_type') && $product->is_type('variation')) {
                // Remove variation text from product name (everything after " - " including parentheses)
                $product_name = preg_replace('/ - .*$/', '', $product_name);
                
                // Get variation attributes from product
                if (method_exists($product, 'get_attributes')) {
                    $variation_attributes = $product->get_attributes();
                }
                
                // Debug log
                if (function_exists('star_cloudprnt_internal_log')) {
                    star_cloudprnt_internal_log('VARIATION_DEBUG: product_name="' . $product_name . '" variation_attrs=' . print_r($variation_attributes, true), 'DEBUG');
                }
            }

            // Get SKU if available
            $sku = '';
            if ($product && method_exists($product, 'get_sku')) $sku = $product->get_sku();

            // Quantity and totals from order item
            if (is_object($item_data) && method_exists($item_data, 'get_quantity')) {
                $item_qty = (int)$item_data->get_quantity();
            } else {
                $item_qty = intval(wc_get_order_item_meta($item_id, '_qty', true));
                if ($item_qty <= 0) $item_qty = 1;
            }

            if (is_object($item_data) && method_exists($item_data, 'get_total')) {
                $item_total_price = (float)$item_data->get_total();
                $item_total_price += (float)(method_exists($item_data, 'get_total_tax') ? $item_data->get_total_tax() : 0);
            } else {
                $item_total_price = floatval(wc_get_order_item_meta($item_id, '_line_total', true)) + floatval(wc_get_order_item_meta($item_id, '_line_tax', true));
            }

            $item_price = !empty($item_qty) ? ($item_total_price / $item_qty) : 0;

            // Allow product-specific override for printed name
            $alt_name = '';
            if ($product && method_exists($product, 'get_attribute')) $alt_name = $product->get_attribute('star_cp_print_name');
            if ($alt_name !== '') $product_name = $alt_name;

            // Debug log
            if (function_exists('star_cloudprnt_internal_log')) {
                $log_parts = array(
                    'item_id=' . $item_id,
                    'product_id=' . $product_id,
                    'variation_id=' . $variation_id,
                    'loaded_product=' . ($product ? 'yes' : 'no'),
                    'name="' . str_replace("\n", ' ', $product_name) . '"',
                    'qty=' . $item_qty,
                    'line_total=' . number_format($item_total_price, 2, '.', ''),
                    'unit_price=' . number_format($item_price, 2, '.', ''),
                );
                if (!empty($sku)) $log_parts[] = 'sku=' . $sku;
                star_cloudprnt_internal_log('print_item: ' . implode(' ', $log_parts), 'DEBUG');
            }

            $formatted_item_price = star_cloudprnt_format_currency($item_price);
            $formatted_total_price = star_cloudprnt_format_currency($item_total_price);

            $product_info = '';
            if (get_option('star-cloudprnt-print-items-print-id') == 'on' && $product_id) $product_info .= ' - ID: ' . $product_id;
            if (get_option('star-cloudprnt-print-items-print-sku') == 'on' && (!empty($sku))) $product_info .= ' - SKU: ' . $sku;

            $product_line = star_cloudprnt_filter_html($product_name . $product_info);

            // Product headline
            $printer->set_text_emphasized();
            $printer->set_font_magnification(2, 2);
            $printer->add_text_line(wordwrap($product_line, $selectedPrinter['columns'], "\n", true));
            $printer->cancel_text_emphasized();
            $printer->set_font_magnification(1, 1);
            $printer->add_vertical_spacing_mm(0.5);

            // Print variation attributes with 1x1 size in bold
            if (!empty($variation_attributes)) {
                $printer->set_text_emphasized();
                $printer->set_font_magnification(1, 1);
                foreach ($variation_attributes as $attr_key => $attr_value) {
                    // Format attribute name (remove 'pa_' prefix if present and capitalize)
                    $attr_label = str_replace('pa_', '', $attr_key);
                    $attr_label = ucfirst(str_replace('-', ' ', $attr_label));
                    
                    $variation_line = ' ' . $attr_label . ': ' . $attr_value;
                    $printer->add_text_line(star_cloudprnt_filter_html($variation_line));
                }
                $printer->cancel_text_emphasized();
                $printer->add_vertical_spacing_mm(0.5);
            }

            // Variation/meta details (add-ons/supplements)
            if (is_object($item_data) && method_exists($item_data, 'get_formatted_meta_data')) {
                $meta = $item_data->get_formatted_meta_data('_', true);
                if (!empty($meta) && function_exists('star_cloudprnt_internal_log')) {
                    $meta_lines = array();
                    foreach ($meta as $mitem) $meta_lines[] = $mitem->display_key . ':' . $mitem->display_value;
                    if (!empty($meta_lines)) star_cloudprnt_internal_log('print_item_meta: item_id=' . $item_id . ' meta=' . implode(' | ', $meta_lines), 'DEBUG');
                }

                // Print add-ons/supplements with 1x1 size in bold, one per line
                $printer->set_text_emphasized();
                $printer->set_font_magnification(1, 1);
                foreach ($meta as $meta_item) {
                    $label = trim($meta_item->display_key);
                    $value = trim(strip_tags($meta_item->display_value));
                    $combined = ' ' . $label . ': ' . $value;
                    // Print on a single line with 1x1 size in bold
                    $printer->add_text_line(star_cloudprnt_filter_html($combined));
                }
                $printer->cancel_text_emphasized();
                $printer->set_font_magnification(1, 1);
                $printer->add_vertical_spacing_mm(0.5);
            }

            // Qty x price -> total
            $printer->set_font_magnification(1, 2);
            $printer->add_text_line(
                star_cloudprnt_get_column_separated_data(
                    array(' Qty: ' . $item_qty . ' x  ' . $formatted_item_price, $formatted_total_price),
                    $max_chars
                )
            );
            $printer->set_font_magnification(1, 1);
            $printer->add_vertical_spacing_mm(0.5);
        }
    }

    // Print information about any used coupons
    function star_cloudprnt_print_coupon_info(&$printer, &$selectedPrinter, &$order, &$order_meta)
    {
        $max_chars = $selectedPrinter['columns'];
        $coupons = $order->get_coupon_codes();

        if (empty($coupons)) return;

        $printer->add_text_line('');
        foreach ($coupons as $coupon_code) {
            $coupon = new WC_Coupon($coupon_code);
            $coupon_type = $coupon->get_discount_type();
            $coupon_value = '';
            if ($coupon_type == 'fixed_cart')
                $coupon_value = star_cloudprnt_get_codepage_currency_symbol() . number_format(-$coupon->get_amount(), 2, '.', '');
            elseif ($coupon_type == 'percent')
                $coupon_value = '-' . $coupon->get_amount() . '%';

            $line = sprintf(__('Coupon: %s (%s)', 'star-cloudprnt'), $coupon_code, $coupon_value);
            $printer->add_text_line(wordwrap($line, $max_chars, "\n", true));
        }
    }

    // Print the address/contact section (no box, left aligned with indent)
    function star_cloudprnt_print_address(&$printer, &$selectedPrinter, &$order, &$order_meta)
    {
        $fname = $order->get_shipping_first_name() ? $order->get_shipping_first_name() : $order->get_billing_first_name();
        $lname = $order->get_shipping_last_name() ? $order->get_shipping_last_name() : $order->get_billing_last_name();
        $a1 = $order->get_shipping_address_1() ? $order->get_shipping_address_1() : $order->get_billing_address_1();
        $a2 = $order->get_shipping_address_2() ? $order->get_shipping_address_2() : $order->get_billing_address_2();
        $city = $order->get_shipping_city() ? $order->get_shipping_city() : $order->get_billing_city();
        $state = $order->get_shipping_state() ? $order->get_shipping_state() : $order->get_billing_state();
        $postcode = $order->get_shipping_postcode() ? $order->get_shipping_postcode() : $order->get_billing_postcode();
        $tel = $order->get_billing_phone();

        $indent = '   '; // approx mezzo centimetro (~3 spazi su carta termica)
        $lines = array();
        $customer_name = trim(($fname ?: '') . ' ' . ($lname ?: ''));
        if ($customer_name !== '') $lines[] = $customer_name;
        if ($a1 !== '') $lines[] = $a1;
        if ($a2 !== '') $lines[] = $a2;
        if ($city !== '') $lines[] = $city;
        if ($state !== '') $lines[] = $state;
        if ($postcode !== '') $lines[] = $postcode;

        $printer->add_new_line(1);
        $printer->add_text_line(star_cloudprnt_get_seperator($selectedPrinter['columns']));
        $printer->set_font_magnification(2, 1);
        // Add blank line for padding above name
        $printer->add_new_line(1);
        // Print customer name in bold
        if ($customer_name !== '') {
            $printer->set_text_emphasized();
            $printer->add_text_line($indent . star_cloudprnt_filter_html($customer_name));
            $printer->cancel_text_emphasized();
        }
        // Print remaining address lines (not bold)
        for ($i = 1; $i < count($lines); $i++) {
            $printer->add_text_line($indent . star_cloudprnt_filter_html($lines[$i]));
        }
        $printer->set_font_magnification(1, 1);
        
        // Print phone number separately with bigger size and formatting
        if ($tel !== '') {
            $formatted_tel = star_cloudprnt_format_swiss_phone($tel);
            $printer->set_font_magnification(2, 2);
            $printer->set_text_emphasized();
            $printer->add_text_line($indent . 'Tel: ' . $formatted_tel);
            $printer->cancel_text_emphasized();
            $printer->set_font_magnification(1, 1);
        }
        
        $printer->add_text_line(star_cloudprnt_get_seperator($selectedPrinter['columns']));
    }

    // Generate the receipt header
    function star_cloudprnt_print_receipt_header(&$printer, &$selectedPrinter, &$order, &$order_meta)
    {
        $order_number = $order->get_order_number();
        $date_format = get_option('date_format');
        // Force 24H format
        $time_format = 'H:i';

        $pw = function ($text) use ($printer, $selectedPrinter) {
            $printer->add_text_line(wordwrap($text, $selectedPrinter['columns'], "\n", true));
        };

        // Top logo from keycode (FlashROM only)
        if (get_option('star-cloudprnt-print-logo-top-cb') === 'on' && get_option('star-cloudprnt-print-logo-top-input')) {
            $printer->add_nv_logo(esc_attr(get_option('star-cloudprnt-print-logo-top-input')));
        }

        // Title (bigger and centered)
        $title_text = get_option('star-cloudprnt-print-header-title');
        if (!empty($title_text)) {
            if (method_exists($printer, 'set_text_center_align')) $printer->set_text_center_align();
            $printer->set_text_emphasized();
            $printer->set_font_magnification(2, 2);
            $pw($title_text);
            $printer->cancel_text_emphasized();
            $printer->set_font_magnification(1, 1);
            if (method_exists($printer, 'set_text_left_align')) $printer->set_text_left_align();
            $printer->add_new_line(1);
        }

        // Order number and time
        $o_num = __('Ordine #', 'star-cloudprnt') . $order_number;
        $order_date = $order->get_date_created();
        $p_time = $order_date ? $order_date->date("{$date_format} {$time_format}") : '';
        if ($o_num) $pw($o_num);
        if ($p_time) {
            $printer->set_font_magnification(1, 2);
            $pw($p_time);
            $printer->set_font_magnification(1, 1);
        }

        // Status
        $printer->add_new_line(1);
        $pw(__('Stato Ordine: ', 'star-cloudprnt') . $order->get_status());

        // Shipping method label (Delivery vs Pickup) - bold and 1x2
        $printer->add_new_line(1);
        $printer->set_text_emphasized();
        $printer->set_font_magnification(1, 2);
        
        $shipping_method_title = $order->get_shipping_method();
        $pickup_date = $order->get_meta('pickup_date');
        
        if (!empty($pickup_date)) {
            $printer->add_text('<< ' . __('Ritiro in sede', 'star-cloudprnt'));
        } elseif (!empty($shipping_method_title)) {
            $printer->add_text('>> ' . $shipping_method_title);
        } else {
            $printer->add_text('>> ' . __('Consegna a Domicilio', 'star-cloudprnt'));
        }
        
        $printer->cancel_text_emphasized();
        $printer->set_font_magnification(1, 1);
        $printer->add_new_line(2);

        // Payment method
        $payment_method_title = $order->get_payment_method_title();
        if (!empty($payment_method_title)) {
            $printer->set_text_emphasized();
            $printer->set_font_magnification(1, 2);
            $printer->add_text('$ ');
            $printer->add_text_line($payment_method_title);
            $printer->cancel_text_emphasized();
            $printer->set_font_magnification(1, 1);
            $printer->add_new_line(1);
        }
    }

    // Print heading above the items list (kept for completeness)
    function star_cloudprnt_print_items_header(&$printer, &$selectedPrinter, &$order, &$order_meta)
    {
        $printer->add_new_line(1);
        $printer->add_text_line(star_cloudprnt_get_column_separated_data(array('ITEM', 'TOTAL'), $selectedPrinter['columns']));
    }

    // Print totals
    function star_cloudprnt_print_item_totals(&$printer, &$selectedPrinter, &$order, &$order_meta)
    {
        $ft = function ($text, $value) use ($printer) {
            $formatted_value = star_cloudprnt_format_currency($value);
            $printer->add_text_line(
                star_mb_str_pad($text, 15) .
                star_mb_str_pad($formatted_value, 10, ' ', STR_PAD_LEFT)
            );
        };

        $printer->add_new_line(1);
        $printer->set_text_right_align();

            $discount_total = $order->get_discount_total();
            if ($discount_total && $discount_total > 0) $ft('DISCOUNT', -$discount_total);

            // Coupon-based discounts are covered above via get_discount_total(),
            // but fee lines with a negative total (e.g. the app's loyalty-points
            // checkout discount, "Sconto punti fedeltà") are a separate
            // WooCommerce concept and were never printed here. get_total()
            // below already accounts for them correctly, so the printed TOTAL
            // was always right -- only this breakdown line was missing, making
            // the receipt look like the numbers didn't add up.
            foreach ($order->get_items('fee') as $fee_item) {
                $fee_total = (float) $fee_item->get_total();
                if ($fee_total < 0) {
                    $ft(strtoupper($fee_item->get_name()), $fee_total);
                }
            }

            $tip = $order->get_meta('_wpslash_tip');
            if ($tip !== '') $ft('TIP', $tip);
            
            $shipping_total = $order->get_shipping_total();
            if ($shipping_total !== '') $ft(__('Costo di Consegna', 'star-cloudprnt'), $shipping_total);
            
            // TOTAL with bold and font magnification 2,1
            $order_total = $order->get_total();
            if ($order_total !== '') {
                $formatted_total = star_cloudprnt_format_currency($order_total);
                $printer->set_text_emphasized();
                $printer->set_font_magnification(2, 1);
                // Reduced padding to fit on one line with 2x width magnification
                $printer->add_text_line(
                    star_mb_str_pad('TOTAL', 8) .
                    star_mb_str_pad($formatted_total, 5, ' ', STR_PAD_LEFT)
                );
                $printer->cancel_text_emphasized();
                $printer->set_font_magnification(1, 1);
            }

            $printer->set_text_left_align();
            // Single separator line below TOTAL (removed extra two lines)
            $printer->add_text_line(star_cloudprnt_get_seperator($selectedPrinter['columns']));
    }

    // Print optional footer message below items
    function star_cloudprnt_print_items_footer(&$printer, &$selectedPrinter, &$order, &$order_meta)
    {
        $item_footer_message = trim(get_option('star-cloudprnt-print-items-footer-message'));
        if ($item_footer_message === '') return;
        $printer->add_new_line(1);
        $printer->set_text_emphasized();
        $wrapped = wordwrap(star_cloudprnt_filter_html($item_footer_message), $selectedPrinter['columns'], "\n", true);
        $printer->add_text_line($wrapped);
        $printer->cancel_text_emphasized();
        // Add line below footer message
        $printer->add_text_line(star_cloudprnt_get_seperator($selectedPrinter['columns']));
    }

    // Print customer notes
    function star_cloudprnt_print_customer_notes(&$printer, &$selectedPrinter, &$order, &$order_meta)
    {
        $notes = star_cloudprnt_get_wc_order_notes($order->get_id());
    $printer->add_new_line(1);
    // Make notes same size as client name
    $printer->set_text_emphasized();
    $printer->set_font_magnification(2, 1);
    $printer->add_text_line(__('Note Cliente:', 'star-cloudprnt'));
    $printer->add_new_line(0.8);
    if (empty($notes)) $printer->add_text_line('None');
    else $printer->add_text_line(wordwrap($notes, $selectedPrinter['columns'], "\n", true));
    $printer->cancel_text_emphasized();
    $printer->set_font_magnification(1, 1);
    }

    // Additional order meta information (selected keys + generic custom checkout field fallback)
    function star_cloudprnt_print_additional_order_info(&$printer, &$selectedPrinter, &$order, &$order_meta)
    {
        $meta_data = $order->get_meta_data();
        if (empty($meta_data)) return;

        // Build a map of keys handled by the known-key switch below,
        // so the generic fallback can skip them to avoid duplicate printing.
        $known_keys = array(
            '_billing_address_index', '_wcpdf_invoice_date', '_wcpdf_invoice_number',
            'delivery_date', 'pickup_date', 'delivery_time', 'pickup_time',
            'additional_orario', 'orario_richiesto', 'sconto_bollini_chf',
        );

        foreach ($meta_data as $m) {
            $data = $m->get_data();
            if (!isset($data['key'])) continue;
            $key = $data['key'];
            $value = isset($data['value']) ? $data['value'] : '';

            switch ($key) {
                case '_billing_address_index':
                    // suppressed per user request
                    break;
                case '_wcpdf_invoice_date':
                    $printer->add_text('Indirizzo : ');
                    $printer->add_new_line(1);
                    $printer->add_text_line(star_cloudprnt_filter_html($value));
                    break;
                case '_wcpdf_invoice_number':
                    $printer->add_text('Ricevuta Numero : ');
                    $printer->add_text_line(star_cloudprnt_filter_html($value));
                    break;
                case 'delivery_date':
                case 'pickup_date':
                    $printer->add_new_line(1);
                    $printer->set_text_emphasized();
                    $printer->set_font_magnification(2, 1);
                    $printer->add_text('Data : ');
                    $printer->add_text_line(star_cloudprnt_filter_html($value));
                    $printer->cancel_text_emphasized();
                    $printer->set_font_magnification(1, 1);
                    break;
                case 'delivery_time':
                case 'pickup_time':
                    $printer->set_text_emphasized();
                    $printer->set_font_magnification(2, 1);
                    $printer->add_text('Orario : ');
                    $printer->add_text_line(star_cloudprnt_filter_html($value));
                    $printer->cancel_text_emphasized();
                    $printer->set_font_magnification(1, 1);
                    break;
                case 'additional_orario':
                    $printer->set_text_emphasized();
                    $printer->set_font_magnification(2, 1);
                    $printer->add_text('Consegna : ');
                    $printer->add_text_line(star_cloudprnt_filter_html($value));
                    $printer->cancel_text_emphasized();
                    $printer->set_font_magnification(1, 1);
                    break;
                case 'orario_richiesto':
                    // Custom checkout field used by Lungolago.ch for delivery time window
                    if (empty($value)) break;
                    $printer->add_new_line(1);
                    $printer->set_text_emphasized();
                    $printer->set_font_magnification(2, 1);
                    $printer->add_text('Orario Consegna: ');
                    $printer->add_text_line(star_cloudprnt_filter_html($value));
                    $printer->cancel_text_emphasized();
                    $printer->set_font_magnification(1, 1);
                    break;
                case 'sconto_bollini_chf':
                    $printer->add_text('Bollini : ');
                    $printer->add_text_line(star_cloudprnt_filter_html($value));
                    break;
                default:
                    break;
            }
        }

        // Generic fallback: print any custom checkout fields registered via
        // ThemeHigh Checkout Field Editor Pro or native WooCommerce custom fields.
        // Reads wc_fields_billing / wc_fields_shipping / wc_fields_additional and
        // prints the label + order meta value for each field not already handled above.
        // This ensures compatibility with any site-specific custom checkout field
        // without requiring code changes (e.g. Lungolago orario_richiesto).
        $field_groups = array(
            get_option('wc_fields_billing',    array()),
            get_option('wc_fields_shipping',   array()),
            get_option('wc_fields_additional', array()),
        );

        foreach ($field_groups as $fields) {
            if (empty($fields) || !is_array($fields)) continue;
            foreach ($fields as $field_key => $field_def) {
                // Skip already-handled keys and internal / non-printable fields
                if (in_array($field_key, $known_keys, true)) continue;
                if (substr($field_key, 0, 1) === '_') continue;
                if (isset($field_def['enabled']) && !$field_def['enabled']) continue;
                // Skip order comments — printed separately elsewhere
                if ($field_key === 'order_comments') continue;

                $field_value = $order->get_meta($field_key);
                if (empty($field_value) || !is_scalar($field_value)) continue;

                // Resolve a human-readable label
                $field_label = isset($field_def['label']) && !empty($field_def['label'])
                    ? $field_def['label']
                    : ucwords(str_replace(array('_', '-'), ' ', $field_key));

                if (function_exists('star_cloudprnt_internal_log')) {
                    star_cloudprnt_internal_log(
                        'custom_field_fallback: key=' . $field_key . ' label="' . $field_label . '" value="' . $field_value . '"',
                        'DEBUG'
                    );
                }

                $printer->add_new_line(1);
                $printer->set_text_emphasized();
                $printer->set_font_magnification(2, 1);
                $printer->add_text(star_cloudprnt_filter_html($field_label) . ': ');
                $printer->add_text_line(star_cloudprnt_filter_html((string)$field_value));
                $printer->cancel_text_emphasized();
                $printer->set_font_magnification(1, 1);

                // Add this key to known_keys so it isn't printed twice if it appears
                // in multiple field groups
                $known_keys[] = $field_key;
            }
        }
    }

    // Receipt footer (logo only if configured)
    function star_cloudprnt_print_receipt_footer(&$printer, &$selectedPrinter, &$order, &$order_meta)
    {
        if (get_option('star-cloudprnt-print-logo-bottom-input'))
            $printer->add_nv_logo(esc_attr(get_option('star-cloudprnt-print-logo-bottom-input')));
    }

    function star_cloudprnt_print_order_summary($selectedPrinter, $file, $order_id)
    {
        $order = wc_get_order($order_id);
        if (!$order) return;

        $order_meta = get_post_meta($order_id);

        // Get the correct object for building commands for the selected printer
        $printer = star_cloudprnt_command_generator($selectedPrinter, $file);
        // Ask the printer to use the correct text encoding
        $printer->set_codepage(get_option('star-cloudprnt-printer-encoding-select'));

        // Buzzer start
        if (get_option('star-cloudprnt-buzzer-start') == 'on') {
            $buzzer_repeat = intval(get_option('star-cloudprnt-buzzer-repeat', 1));
            if ($buzzer_repeat < 1) $buzzer_repeat = 1;
            for ($i = 0; $i < $buzzer_repeat; $i++) {
                $printer->sound_buzzer(1, 500, 100);
            }
        }

        // Print sections
        star_cloudprnt_print_receipt_header($printer, $selectedPrinter, $order, $order_meta);
        star_cloudprnt_print_items($printer, $selectedPrinter, $order, $order_meta);
        star_cloudprnt_print_coupon_info($printer, $selectedPrinter, $order, $order_meta);
        star_cloudprnt_print_item_totals($printer, $selectedPrinter, $order, $order_meta);
        star_cloudprnt_print_items_footer($printer, $selectedPrinter, $order, $order_meta);
        star_cloudprnt_print_additional_order_info($printer, $selectedPrinter, $order, $order_meta);
        star_cloudprnt_print_address($printer, $selectedPrinter, $order, $order_meta);
        star_cloudprnt_print_customer_notes($printer, $selectedPrinter, $order, $order_meta);
        star_cloudprnt_print_maps_qr($printer, $selectedPrinter, $order, $order_meta);
        star_cloudprnt_print_receipt_footer($printer, $selectedPrinter, $order, $order_meta);

        $printer->cut();

        // Buzzer end
        if (get_option('star-cloudprnt-buzzer-end') == 'on') {
            $buzzer_repeat = intval(get_option('star-cloudprnt-buzzer-repeat', 1));
            if ($buzzer_repeat < 1) $buzzer_repeat = 1;
            for ($i = 0; $i < $buzzer_repeat; $i++) {
                $printer->sound_buzzer(1, 500, 100);
            }
        }

        // Number of copies
        $copies = intval(get_option('star-cloudprnt-print-copies-input'));
        if ($copies < 1) $copies = 1;

        // Log and print
        star_cloudprnt_internal_log('print_order_summary: order_id=' . $order_id . ' file=' . $file . ' copies=' . $copies, 'INFO');
        try {
            $item_names = array();
            foreach ($order->get_items() as $iid => $idata) {
                if (is_object($idata) && method_exists($idata, 'get_name')) $item_names[] = $idata->get_name();
                else if (is_array($idata) && isset($idata['name'])) $item_names[] = $idata['name'];
            }
            if (!empty($item_names)) star_cloudprnt_internal_log('print_order_summary_items: order_id=' . $order_id . ' items=' . implode(' | ', $item_names), 'DEBUG');
        } catch (Exception $e) {
            star_cloudprnt_internal_log('print_order_summary_items: error enumerating items: ' . $e->getMessage(), 'ERROR');
        }

        // Submit print job with specified number of copies
        star_cloudprnt_internal_log('print_order_summary: submitting print job with ' . $copies . ' copies for order_id=' . $order_id, 'DEBUG');
        $printer->printjob($copies);
        star_cloudprnt_internal_log('print_order_summary: completed print job for order_id=' . $order_id, 'INFO');
    }