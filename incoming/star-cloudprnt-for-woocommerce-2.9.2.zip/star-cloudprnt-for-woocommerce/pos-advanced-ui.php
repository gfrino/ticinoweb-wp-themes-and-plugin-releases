<?php
// Advanced POS UI for Food Delivery Call Center
// Included by create-settings.php when rendering the POS page

if (!defined('ABSPATH')) exit;

function star_cloudprnt_pos_page_advanced() {
	if (!current_user_can('manage_woocommerce')) {
		wp_die('Unauthorized');
	}

	// Check if WooCommerce is active
	if (!class_exists('WC_Product')) {
		echo '<div class="wrap"><h1>Call Center</h1><div class="notice notice-error"><p>WooCommerce non attivo.</p></div></div>';
		return;
	}

	// Count available products
	$product_count = wp_count_posts('product');
	$has_products = ($product_count && isset($product_count->publish) && $product_count->publish > 0);

	$nonce = wp_create_nonce('star_cloudprnt_pos_create_order');
	
	// Build config for JS
	$config = array(
		'restUrl' => trailingslashit(rest_url('fd-pos/v1')),
		'nonce' => wp_create_nonce('wp_rest'),
		'currency' => get_woocommerce_currency(),
		'currencySymbol' => get_woocommerce_currency_symbol(),
		'locale' => str_replace('_', '-', get_user_locale()),
		'strings' => array(
			'emptyCart' => 'Carrello vuoto',
			'itemSingular' => 'articolo',
			'itemPlural' => 'articoli',
			'loadingAddons' => 'Caricamento add-on...',
			'noAddons' => 'Nessun add-on disponibile per questo prodotto.',
			'unsupportedAddon' => 'Add-on non supportato.',
			'noMatches' => 'Nessun risultato',
			'searchingProducts' => 'Ricerca in corso...',
			'productHint' => 'Digita almeno due caratteri per cercare un prodotto',
			'customerHint' => 'Suggerimenti da rubriche clienti',
			'productSelectFirst' => 'Seleziona un prodotto dalla lista prima di aggiungerlo.'
		)
	);
	$config_json = wp_json_encode($config);

	ob_start();
	?>
	<div class="wrap fdcc-wrap">
		<div class="fdcc-topbar">
			<div class="fdcc-left">
				<h1 style="margin:0;">Call Center</h1>
				<button type="button" id="fdcc-reset-page" class="fdcc-btn-reset" title="Resetta e ricomincia">↺ Reset</button>
			</div>
			<div class="fdcc-right">
				<div id="fdcc-grand-total" class="fdcc-grand-total fdcc-zero" aria-label="Totale ordine">Totale: 0.00</div>
			</div>
		</div>
		<style>
		.fdcc-wrap{max-width:1180px;}
		.fdcc-topbar{display:flex;align-items:center;justify-content:space-between;margin-bottom:12px;gap:20px;}
		.fdcc-topbar .fdcc-left{display:flex;align-items:center;gap:14px;}
		.fdcc-grand-total{font-size:20px;font-weight:700;color:#111827;background:#fff;border:2px solid #2563eb;padding:8px 18px;border-radius:6px;min-width:180px;text-align:right;box-shadow:0 2px 6px -2px rgba(37,99,235,0.35);}
		.fdcc-grand-total.fdcc-zero{color:#6b7280;border-color:#d1d5db;box-shadow:none;}
		.fdcc-btn-reset{background:#f3f4f6;border:1px solid #d1d5db;color:#374151;font-weight:600;padding:8px 16px;font-size:13px;border-radius:6px;cursor:pointer;display:inline-flex;align-items:center;gap:6px;transition:background .18s,border-color .18s,color .18s;}
		.fdcc-btn-reset:hover{background:#e5e7eb;border-color:#9ca3af;color:#111827;}
		.fdcc-btn-reset:active{background:#d1d5db;}
		.fdcc-form{margin-top:24px;}
		.fdcc-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:20px;}
		.fdcc-card{background:#fff;border-radius:0;padding:18px 20px;box-shadow:none;border:1px solid #e5e7eb;margin-bottom:20px;}
		.fdcc-card h2{font-size:18px;margin:0 0 16px;font-weight:600;color:#111827;}
		.fdcc-field{display:flex;flex-direction:column;margin-bottom:16px;}
		.fdcc-field label{font-weight:600;font-size:13px;letter-spacing:.01em;color:#374151;margin-bottom:6px;}
		.fdcc-field input,.fdcc-field select,.fdcc-field textarea{border:1px solid #d1d5db;border-radius:6px;padding:10px 12px;font-size:14px;color:#111827;background:#f9fafb;transition:border-color .2s,background .2s,box-shadow .2s;}
		.fdcc-field input:focus,.fdcc-field select:focus,.fdcc-field textarea:focus{outline:none;border-color:#2563eb;background:#fff;box-shadow:0 0 0 3px rgba(37,99,235,0.15);}
		.fdcc-inline{display:flex;gap:14px;align-items:flex-end;flex-wrap:wrap;}
		.fdcc-inline .fdcc-field{flex:1;min-width:180px;margin-bottom:0;}
		.fdcc-products-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:18px;}
		.fdcc-products-header h2{margin:0;}
		.fdcc-product-actions{display:flex;gap:14px;align-items:flex-end;flex-wrap:wrap;margin-bottom:18px;}
		.fdcc-table{width:100%;border-collapse:collapse;}
		.fdcc-table thead th{font-size:12px;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:#6b7280;padding:0 0 12px;text-align:left;border-bottom:2px solid #e5e7eb;}
		.fdcc-table tbody tr{border-bottom:1px solid #f3f4f6;}
		.fdcc-table tbody tr.fdcc-row-active td{background:#eef2ff;}
		.fdcc-table tbody td{padding:14px 8px;vertical-align:top;}
		.fdcc-remove{color:#ef4444;font-weight:600;text-decoration:none;font-size:13px;}
		.fdcc-remove:hover{color:#b91c1c;text-decoration:underline;}
		.fdcc-primary{margin-top:20px;background:#2563eb;border:none;color:#fff;box-shadow:none;padding:12px 24px;height:auto;font-size:15px;border-radius:6px;font-weight:600;cursor:pointer;}
		.fdcc-primary:hover{background:#1d4ed8;}
		.fdcc-empty{padding:22px;border:1px dashed #d1d5db;text-align:center;color:#6b7280;font-size:14px;background:#f9fafb;}
		.fdcc-autocomplete{position:relative;}
		.fdcc-autocomplete input{background:#fff;}
		.fdcc-suggestions{position:absolute;top:100%;left:0;right:0;background:#fff;border:1px solid #d1d5db;box-shadow:0 4px 10px -4px rgba(15,23,42,0.25);margin-top:4px;z-index:40;max-height:260px;overflow:auto;display:none;}
		.fdcc-suggestions ul{list-style:none;margin:0;padding:6px 0;}
		.fdcc-suggestions li{padding:10px 14px;cursor:pointer;font-size:14px;font-weight:500;color:#111827;display:flex;flex-direction:column;gap:4px;}
		.fdcc-suggestions li:hover,.fdcc-suggestions li.fdcc-active{background:#f3f4f6;}
		.fdcc-suggestions .fdcc-secondary{font-size:12px;color:#6b7280;font-weight:400;}
		.fdcc-addons{margin-top:18px;border-top:1px solid #e5e7eb;padding-top:18px;display:none;}
		.fdcc-addons.active{display:block;}
		.fdcc-addon-section{margin-bottom:20px;}
		.fdcc-addon-section h3{font-size:15px;margin:0 0 12px;font-weight:600;color:#111827;}
		.fdcc-addon-options{display:flex;flex-direction:column;gap:10px;}
		.fdcc-addon-options label{display:flex;align-items:center;gap:10px;font-size:14px;color:#1f2937;font-weight:500;}
		.fdcc-addon-options .fdcc-addon-price{font-size:12px;color:#6b7280;font-weight:400;}
		.fdcc-addon-hint{margin-bottom:16px;font-size:12px;color:#6b7280;}
		.fdcc-addon-list{margin:8px 0 0;padding:0 0 0 18px;color:#4b5563;font-size:13px;}
		.fdcc-product-meta{font-size:12px;color:#6b7280;font-weight:500;margin-top:6px;}
		@media (max-width:782px){
			.fdcc-card{padding:16px;}
			.fdcc-inline{flex-direction:column;align-items:stretch;}
			.fdcc-topbar{flex-direction:column;align-items:stretch;}
			.fdcc-grand-total{text-align:center;}
		}
		</style>
		<form id="star-cp-pos-form" class="fdcc-form" method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
			<input type="hidden" name="action" value="star_cloudprnt_pos_create_order" />
			<input type="hidden" name="_wpnonce" value="<?php echo esc_attr($nonce); ?>" />
			<input type="hidden" name="items_json" id="pos-items-json" value="[]" />
			<input type="hidden" id="fdcc-product-id" value="" />
			<input type="hidden" id="fdcc-selected-user-id" name="fdcc_selected_user_id" value="" />

			<div class="fdcc-grid">
				<div class="fdcc-card">
					<h2>Dati cliente</h2>
					<div class="fdcc-field">
						<label for="fdcc-customer-name">Nome</label>
						<div class="fdcc-autocomplete">
							<input type="text" id="fdcc-customer-name" name="customer_name" required placeholder="Mario Rossi" autocomplete="off" />
							<div class="fdcc-suggestions" data-target="fdcc-customer-name"></div>
						</div>
					</div>
					<div class="fdcc-inline">
						<div class="fdcc-field">
							<label for="fdcc-customer-phone">Telefono</label>
							<div class="fdcc-autocomplete">
								<input type="text" id="fdcc-customer-phone" name="customer_phone" required placeholder="079 000 00 00" autocomplete="off" />
								<div class="fdcc-suggestions" data-target="fdcc-customer-phone"></div>
							</div>
						</div>
						<div class="fdcc-field">
							<label for="fdcc-customer-email">Email</label>
							<div class="fdcc-autocomplete">
								<input type="email" id="fdcc-customer-email" name="customer_email" placeholder="cliente@email.ch" autocomplete="off" />
								<div class="fdcc-suggestions" data-target="fdcc-customer-email"></div>
							</div>
						</div>
					</div>
					<div class="fdcc-field">
						<label for="fdcc-customer-note">Note</label>
						<textarea id="fdcc-customer-note" name="customer_note" rows="2"></textarea>
					</div>
				</div>

				<div class="fdcc-card">
					<h2>Consegna</h2>
					<div class="fdcc-field">
						<label for="fdcc-delivery-method">Metodo</label>
						<select id="fdcc-delivery-method" name="delivery_method">
							<option value="pickup">Ritiro</option>
							<option value="delivery">Consegna</option>
						</select>
					</div>
					<div class="fdcc-field">
						<label for="fdcc-address">Indirizzo</label>
						<input type="text" id="fdcc-address" name="address_1" />
					</div>
					<div class="fdcc-inline">
						<div class="fdcc-field">
							<label for="fdcc-city">Città</label>
							<input type="text" id="fdcc-city" name="city" />
						</div>
						<div class="fdcc-field">
							<label for="fdcc-postcode">CAP</label>
							<input type="text" id="fdcc-postcode" name="postcode" />
						</div>
					</div>
					<div class="fdcc-field">
						<label for="fdcc-payment-method">Pagamento</label>
						<select id="fdcc-payment-method" name="payment_method">
							<option value="cod">Contanti alla consegna</option>
							<option value="bacs">Bonifico</option>
							<option value="cheque">Assegno</option>
							<option value="stripe">Carta (Stripe)</option>
						</select>
					</div>
				</div>
			</div>

			<div class="fdcc-card">
				<div class="fdcc-products-header">
					<h2>Prodotti <span id="fdcc-product-counter" style="font-weight:400;font-size:14px;color:#6b7280;">Carrello vuoto</span></h2>
				</div>
				<?php if ($has_products) : ?>
				<div class="fdcc-product-actions">
					<div class="fdcc-field" style="flex:2;min-width:240px;margin-bottom:0;">
						<label for="fdcc-product-search">Cerca prodotto</label>
						<div class="fdcc-autocomplete">
							<input type="text" id="fdcc-product-search" placeholder="Digita nome prodotto..." autocomplete="off" />
							<div class="fdcc-suggestions" data-target="fdcc-product-search"></div>
						</div>
						<small id="fdcc-product-hint" style="color:#6b7280;margin-top:4px;display:block;">Digita almeno due caratteri</small>
					</div>
					<div class="fdcc-field" style="max-width:120px;margin-bottom:0;">
						<label for="pos-product-qty">Quantità</label>
						<input type="number" id="pos-product-qty" min="1" value="1" />
					</div>
				</div>
				<div id="fdcc-addons" class="fdcc-addons"></div>
				<div class="fdcc-table-wrapper">
					<table class="fdcc-table">
						<thead>
							<tr><th>Prodotto</th><th style="width:120px;">Quantità</th><th style="width:120px;">Azioni</th></tr>
						</thead>
						<tbody id="pos-items-body"></tbody>
					</table>
				</div>
				<div id="fdcc-empty-cart" class="fdcc-empty">Nessun prodotto in carrello. Aggiungi almeno un articolo per procedere.</div>
				<?php else : ?>
				<div class="fdcc-empty">Nessun prodotto pubblicato trovato. Aggiungi prodotti in WooCommerce per usare il Call Center.</div>
				<?php endif; ?>
			</div>

			<button type="submit" class="button button-primary fdcc-primary">Crea ordine e stampa</button>
		</form>
		<script>
		const FDCC_POS = <?php echo $config_json; ?>;
		(function(){
			'use strict';
			const state = {
				items: [],
				customerCache: {},
				productCache: {},
				selectedProduct: null,
				activeItemKey: null,
				activeAddonsProductId: null
			};
			const itemsField = document.getElementById('pos-items-json');
			const counterEl = document.getElementById('fdcc-product-counter');
			const emptyState = document.getElementById('fdcc-empty-cart');
			const itemsBody = document.getElementById('pos-items-body');
			const productSearch = document.getElementById('fdcc-product-search');
			const productIdField = document.getElementById('fdcc-product-id');
			const qtyField = document.getElementById('pos-product-qty');
			const addonsWrapper = document.getElementById('fdcc-addons');
			const hintEl = document.getElementById('fdcc-product-hint');
			const currencyFormatter = (typeof Intl !== 'undefined') ? new Intl.NumberFormat(FDCC_POS.locale || 'it-CH', {style: 'currency', currency: FDCC_POS.currency || 'CHF'}) : null;

			const formatCurrency = (value) => {
				const num = parseFloat(value);
				if (!num || Number.isNaN(num)) return '';
				if (currencyFormatter) return currencyFormatter.format(num);
				return num.toFixed(2) + ' ' + (FDCC_POS.currencySymbol || FDCC_POS.currency || '');
			};

			const debounce = (fn, delay = 220) => {
				let timer = null;
				return (...args) => {
					if (timer) window.clearTimeout(timer);
					timer = window.setTimeout(() => fn.apply(null, args), delay);
				};
			};

			const fetchJson = (path, params = '') => {
				const url = FDCC_POS.restUrl + path + params;
				return fetch(url, {
					headers: { 'X-WP-Nonce': FDCC_POS.nonce },
					credentials: 'same-origin'
				}).then(response => {
					if (!response.ok) throw new Error('HTTP ' + response.status);
					return response.json();
				}).catch(() => []);
			};

			const hideSuggestions = (container) => {
				if (!container) return;
				container.style.display = 'none';
				container.innerHTML = '';
			};

			const renderSuggestions = (container, items, onSelect) => {
				if (!container || !items.length) {
					if (container) hideSuggestions(container);
					return;
				}
				container.innerHTML = '<ul>' + items.map((item, index) => {
					const secondary = item.secondary ? '<span class="fdcc-secondary">' + item.secondary + '</span>' : '';
					return '<li data-index="' + index + '"><span>' + item.label + '</span>' + secondary + '</li>';
				}).join('') + '</ul>';
				container.style.display = 'block';
				container.dataset.count = items.length;
				container.onmousedown = (event) => {
					const li = event.target.closest('li');
					if (!li) return;
					event.preventDefault();
					const idx = parseInt(li.getAttribute('data-index'), 10);
					if (items[idx]) onSelect(items[idx]);
					hideSuggestions(container);
				};
			};

			const fillCustomer = (data) => {
				if (data.isNew) {
					document.getElementById('fdcc-selected-user-id').value = '';
					return;
				}
				document.getElementById('fdcc-customer-name').value = data.name || '';
				document.getElementById('fdcc-customer-phone').value = data.phone || '';
				document.getElementById('fdcc-customer-email').value = data.email || '';
				document.getElementById('fdcc-address').value = data.address_1 || '';
				document.getElementById('fdcc-city').value = data.city || '';
				document.getElementById('fdcc-postcode').value = data.postcode || '';
				document.getElementById('fdcc-selected-user-id').value = data.id || '';
			};

			const setupCustomerAutocomplete = () => {
				const configs = [
					{ id: 'fdcc-customer-name', mode: 'name' },
					{ id: 'fdcc-customer-phone', mode: 'phone' },
					{ id: 'fdcc-customer-email', mode: 'email' }
				];
				configs.forEach((cfg) => {
					const input = document.getElementById(cfg.id);
					const container = document.querySelector('.fdcc-suggestions[data-target="' + cfg.id + '"]');
					if (!input || !container) return;
					let lastResults = [];
					const request = debounce((term) => {
						if (term.length < 2) {
							hideSuggestions(container);
							return;
						}
						const cacheKey = cfg.mode + ':' + term.toLowerCase();
						if (state.customerCache[cacheKey]) {
							lastResults = state.customerCache[cacheKey];
							const withCreate = [...lastResults, { id: 0, label: '➕ Crea nuovo cliente', secondary: '', isNew: true }];
							renderSuggestions(container, withCreate, fillCustomer);
							return;
						}
						fetchJson('customers', '?mode=' + cfg.mode + '&search=' + encodeURIComponent(term)).then((data) => {
							if (!Array.isArray(data)) data = [];
							lastResults = data;
							state.customerCache[cacheKey] = data;
							const withCreate = [...data, { id: 0, label: '➕ Crea nuovo cliente', secondary: '', isNew: true }];
							renderSuggestions(container, withCreate, fillCustomer);
						});
					}, 230);
					input.addEventListener('input', (e) => request(e.target.value.trim()));
					input.addEventListener('focus', () => {
						if (input.value.trim().length >= 2) request(input.value.trim());
					});
					document.addEventListener('click', (evt) => {
						if (evt.target !== input && !container.contains(evt.target)) hideSuggestions(container);
					});
				});
			};

			const computeAddonAmount = (basePrice, addon, qty) => {
				const price = parseFloat(addon.price || 0);
				const type = addon.price_type || 'per_item';
				if (type === 'percentage' || type === 'percentage_based') {
					return (basePrice * (price / 100)) * qty;
				}
				if (type === 'flat_fee') return price;
				return price * qty;
			};

			const computeItemSubtotal = (item) => {
				const base = typeof item.base_price === 'number' ? item.base_price : 0;
				const qty = parseInt(item.quantity, 10) || 1;
				let total = base * qty;
				if (Array.isArray(item.addons)) {
					item.addons.forEach(a => { total += computeAddonAmount(base, a, qty); });
				}
				return total;
			};

			const updateGrandTotal = () => {
				const el = document.getElementById('fdcc-grand-total');
				if (!el) return;
				let grand = 0;
				state.items.forEach(item => { grand += computeItemSubtotal(item); });
				el.textContent = 'Totale: ' + formatCurrency(grand);
				if (grand === 0) el.classList.add('fdcc-zero'); else el.classList.remove('fdcc-zero');
			};

			const updateCounter = () => {
				const totalQty = state.items.reduce((sum, item) => sum + (parseInt(item.quantity, 10) || 0), 0);
				if (counterEl) {
					counterEl.textContent = totalQty > 0 ? totalQty + ' ' + (totalQty === 1 ? FDCC_POS.strings.itemSingular : FDCC_POS.strings.itemPlural) : FDCC_POS.strings.emptyCart;
				}
				if (emptyState) {
					emptyState.style.display = totalQty > 0 ? 'none' : 'block';
				}
			};

			const syncItems = () => {
				if (itemsField) itemsField.value = JSON.stringify(state.items);
				updateCounter();
				updateGrandTotal();
			};

			const renderItemRow = (item) => {
				let addonsHtml = '';
				if (Array.isArray(item.addons) && item.addons.length) {
					addonsHtml = '<ul class="fdcc-addon-list">' + item.addons.map((addon) => {
						const isPercentage = addon.price_type === 'percentage' || addon.price_type === 'percentage_based';
						const priceInfo = addon.price ? ' (+' + (isPercentage ? addon.price + '%' : formatCurrency(addon.price)) + ')' : '';
						return '<li>' + addon.group + ': ' + addon.option + priceInfo + '</li>';
					}).join('') + '</ul>';
				}
				const meta = item.display_price ? '<div class="fdcc-product-meta">' + item.display_price + '</div>' : '';
				return '<td><strong>' + item.name + '</strong>' + meta + addonsHtml + '</td><td>' + item.quantity + '</td><td><a href="#" class="fdcc-remove" data-item-key="' + item.key + '">Rimuovi</a></td>';
			};

			const appendItemRow = (item) => {
				if (!itemsBody) return;
				const row = document.createElement('tr');
				row.dataset.itemKey = item.key;
				row.innerHTML = renderItemRow(item);
				itemsBody.appendChild(row);
			};

			const addProductToCart = ({ product, quantity }) => {
				if (!product) return null;
				const qty = Math.max(1, parseInt(quantity || 1, 10));
				const key = 'item_' + Date.now() + '_' + Math.random().toString(16).slice(2);
				const item = {
					key,
					product_id: product.id,
					name: product.name,
					quantity: qty,
					addons: [],
					display_price: product.formatted_price || '',
					base_price: typeof product.price === 'number' ? product.price : 0,
					subtotal: 0
				};
				item.subtotal = computeItemSubtotal(item);
				state.items.push(item);
				appendItemRow(item);
				syncItems();
				return key;
			};

			const removeItem = (key) => {
				const index = state.items.findIndex((item) => item.key === key);
				if (index === -1) return;
				state.items.splice(index, 1);
				const row = itemsBody ? itemsBody.querySelector('tr[data-item-key="' + key + '"]') : null;
				if (row) row.remove();
				syncItems();
			};

			const handleProductSelect = (product) => {
				const container = document.querySelector('.fdcc-suggestions[data-target="fdcc-product-search"]');
				if (container) hideSuggestions(container);
				const quantity = Math.max(1, parseInt(qtyField ? qtyField.value : '1', 10));
				addProductToCart({ product, quantity });
				if (productSearch) productSearch.value = '';
				if (qtyField) qtyField.value = 1;
			};

			const setupProductSearch = () => {
				if (!productSearch) return;
				const container = document.querySelector('.fdcc-suggestions[data-target="fdcc-product-search"]');
				if (!container) return;
				let lastResults = [];
				const request = debounce((term) => {
					if (term.length < 2) {
						hideSuggestions(container);
						return;
					}
					const cacheKey = term.toLowerCase();
					if (state.productCache[cacheKey]) {
						lastResults = state.productCache[cacheKey];
						renderSuggestions(container, lastResults, handleProductSelect);
						return;
					}
					fetchJson('products', '?search=' + encodeURIComponent(term)).then((data) => {
						if (!Array.isArray(data)) data = [];
						lastResults = data.map((product) => ({
							id: product.id,
							name: product.name,
							label: product.name,
							secondary: product.formatted_price || '',
							formatted_price: product.formatted_price || '',
							price: typeof product.price === 'number' ? product.price : 0
						}));
						state.productCache[cacheKey] = lastResults;
						renderSuggestions(container, lastResults, handleProductSelect);
					});
				}, 250);
				productSearch.addEventListener('input', (e) => request(e.target.value.trim()));
				productSearch.addEventListener('focus', () => {
					if (productSearch.value.trim().length >= 2) request(productSearch.value.trim());
				});
				document.addEventListener('click', (evt) => {
					if (evt.target !== productSearch && !container.contains(evt.target)) hideSuggestions(container);
				});
			};

			if (itemsBody) {
				itemsBody.addEventListener('click', (event) => {
					const removeLink = event.target.closest('.fdcc-remove');
					if (removeLink) {
						event.preventDefault();
						removeItem(removeLink.getAttribute('data-item-key'));
					}
				});
			}

			const resetBtn = document.getElementById('fdcc-reset-page');
			if (resetBtn) {
				resetBtn.addEventListener('click', () => {
					if (confirm('Sei sicuro di voler resettare la pagina e ricominciare?')) {
						const fields = ['fdcc-customer-name','fdcc-customer-phone','fdcc-customer-email','fdcc-customer-note','fdcc-address','fdcc-city','fdcc-postcode'];
						fields.forEach(id => {
							const el = document.getElementById(id);
							if (el) el.value = '';
						});
						document.getElementById('fdcc-selected-user-id').value = '';
						document.getElementById('fdcc-delivery-method').value = 'pickup';
						const paySel = document.getElementById('fdcc-payment-method');
						if (paySel && paySel.options.length) paySel.value = paySel.options[0].value;
						state.items = [];
						if (itemsBody) itemsBody.innerHTML = '';
						syncItems();
						state.customerCache = {};
						state.productCache = {};
						if (productSearch) productSearch.value = '';
						if (qtyField) qtyField.value = 1;
					}
				});
			}

			document.getElementById('star-cp-pos-form').addEventListener('submit', () => {
				syncItems();
			});

			syncItems();
			setupCustomerAutocomplete();
			setupProductSearch();
		})();
		</script>
	</div>
	<?php
	echo ob_get_clean();
	return true;
}
