<?php
	include_once('printer-settings-page.php');

	// --- New: Scheduler and email-enabled printer-checking for main + custom printers ---

	// Register Cron schedule (5 minutes)
	add_filter('cron_schedules', 'star_cloudprnt_cron_schedules');
	function star_cloudprnt_cron_schedules($schedules) {
		if (!isset($schedules['star_cloudprnt_thirty_minutes'])) {
			$schedules['star_cloudprnt_thirty_minutes'] = array(
				'interval' => 30 * 60,
				'display' => __('Every 30 Minutes')
			);
		}
		return $schedules;
	}

	// Schedule event on plugin init
	add_action('init', 'star_cloudprnt_maybe_schedule_cron');
	function star_cloudprnt_maybe_schedule_cron() {
		if (!wp_next_scheduled('star_cloudprnt_check_printers')) {
			wp_schedule_event(time(), 'star_cloudprnt_thirty_minutes', 'star_cloudprnt_check_printers');
		}
	}

	// Clear scheduled event on plugin deactivation
	register_deactivation_hook(__FILE__, 'star_cloudprnt_clear_cron');
	function star_cloudprnt_clear_cron() {
		$timestamp = wp_next_scheduled('star_cloudprnt_check_printers');
		if ($timestamp) wp_unschedule_event($timestamp, 'star_cloudprnt_check_printers');
	}

	// Hook the cron event
	add_action('star_cloudprnt_check_printers', 'star_cloudprnt_cron_check_printers');


	function star_cloudprnt_is_woo_activated()
	{
		return in_array('woocommerce/woocommerce.php', apply_filters('active_plugins', get_option('active_plugins')));
	}
    

	function star_cloudprnt_settings()
	{
		
		add_settings_section("star_cloudprnt_setup_section", "CloudPRNT Setup", "star_cloudprnt_setup_section_info", "star_cloudprnt_setup");
		add_settings_field("star-cloudprnt-select", "CloudPRNT", "star_cloudprnt_select_display", "star_cloudprnt_setup", "star_cloudprnt_setup_section");  
		add_settings_field("star-cloudprnt-printer-select", "Selected Printer", "star_cloudprnt_printer_select_display", "star_cloudprnt_setup", "star_cloudprnt_setup_section"); 
		// Debug logging toggle
		add_settings_field("star-cloudprnt-logging", "Enable Debug Logging", "star_cloudprnt_logging_display", "star_cloudprnt_setup", "star_cloudprnt_setup_section");
		// POS toggle
		add_settings_field("star-cloudprnt-enable-pos", "Enable POS Tab", "star_cloudprnt_enable_pos_display", "star_cloudprnt_setup", "star_cloudprnt_setup_section");
		
		add_settings_field("star-cloudprnt-printer-encoding-select", "Text Encoding", "star_cloudprnt_printer_encoding_select_display", "star_cloudprnt_setup", "star_cloudprnt_setup_section");

		add_settings_field("star-cloudprnt-trigger", "Printing Trigger", "star_cloudprnt_trigger_display", "star_cloudprnt_setup", "star_cloudprnt_setup_section");

		// Location Notes Field
		add_settings_field("star-cloudprnt-location-notes", "Notes", "star_cloudprnt_location_notes_display", "star_cloudprnt_setup", "star_cloudprnt_setup_section");

		
		add_settings_field("star-cloudprnt-print-copies-input", "Copies", "star_cloudprnt_print_copies_input_display", "star_cloudprnt_setup", "star_cloudprnt_setup_section");  
		add_settings_field("star-cloudprnt-buzzer", "Buzzer", "star_cloudprnt_buzzer_display", "star_cloudprnt_setup", "star_cloudprnt_setup_section");

		// New notification email field
		add_settings_field("star-cloudprnt-notification-email", "Notification Email", "star_cloudprnt_notification_email_display", "star_cloudprnt_setup", "star_cloudprnt_setup_section");

		// ModSecurity bypass field
		add_settings_field("star-cloudprnt-modsec-bypass", "ModSecurity Bypass", "star_cloudprnt_modsec_bypass_display", "star_cloudprnt_setup", "star_cloudprnt_setup_section");

		add_settings_section("star_cloudprnt_design_section", "Print Job Design Options", "star_cloudprnt_design_header", "star_cloudprnt_setup");
		add_settings_field("star-cloudprnt-header", "Header", "star_cloudPRNT_header_settings_display", "star_cloudprnt_setup", "star_cloudprnt_design_section");
		add_settings_field("star-cloudprnt-items", "Item List", "star_cloudPRNT_item_settings_display", "star_cloudprnt_setup", "star_cloudprnt_design_section");
		add_settings_field("star-cloudprnt-order-fields", "Additional Order Fields", "star_cloudPRNT_order_fields_display", "star_cloudprnt_setup", "star_cloudprnt_design_section");
		add_settings_field("star-cloudprnt-logo", "Logo", "star_cloudPRNT_print_logo_display", "star_cloudprnt_setup", "star_cloudprnt_design_section");

		
	}
	
	function star_cloudprnt_register_settings()
	{
		/* Attempt to set the default print job trigger to "status_processing" for new installs, but "thankyou" for sites that have
		   already been running with the plugin - to avoid potentially breaking thos sites after upgrading the plugin, since some sites use
			 other plugins to change the default order status.
			 */
			$trigger_default = "status_processing";						// Recommended default for new sites, at which time users can choose another option if preferred
			if(get_option('star-cloudprnt-select') != false)
				$trigger_default = "thankyou";

	register_setting("star_cloudprnt_setup_section", "star-cloudprnt-select");
	register_setting("star_cloudprnt_setup_section", "star-cloudprnt-printer-select");
	register_setting("star_cloudprnt_setup_section", "star-cloudprnt-printer-select_cus1");
	register_setting("star_cloudprnt_setup_section", "star-cloudprnt-current_site_id");
	// Lock mechanism for printer assignments
	register_setting("star_cloudprnt_setup_section", "star-cloudprnt-printer-locked");
	register_setting("star_cloudprnt_setup_section", "star-cloudprnt-printer-locked_cus1");
	// Locked printer names
	register_setting("star_cloudprnt_setup_section", "star-cloudprnt-printer-locked-name");
	register_setting("star_cloudprnt_setup_section", "star-cloudprnt-printer-locked-name_cus1");		
		register_setting("star_cloudprnt_setup_section", "star-cloudprnt-printer-encoding-select");
		register_setting("star_cloudprnt_setup_section", "star-cloudprnt-print-copies-input");
		// Register POS toggle option (yes/no)
		register_setting("star_cloudprnt_setup_section", "star-cloudprnt-enable-pos", array('default' => 'no'));

		// Register debug logging option (yes/no)
		register_setting("star_cloudprnt_setup_section", "star_cloudprnt_enable_log", array('default' => 'no'));

		register_setting("star_cloudprnt_setup_section", "star-cloudprnt-trigger", array("default" => $trigger_default));

		register_setting("star_cloudprnt_setup_section", "star-cloudprnt-print-header-title", array("default" => "ORDER NOTIFICATION"));

		register_setting("star_cloudprnt_setup_section", "star-cloudprnt-print-items-print-id", array("default" => "on"));
		register_setting("star_cloudprnt_setup_section", "star-cloudprnt-print-items-print-sku", array("default" => "off"));

		register_setting("star_cloudprnt_setup_section", "star-cloudprnt-print-items-footer-message", array("default" => "All prices are inclusive of tax (if applicable)."));

		register_setting("star_cloudprnt_setup_section", "star-cloudprnt-print-order-meta-cb");
		register_setting("star_cloudprnt_setup_section", "star-cloudprnt-print-order-meta-reformat-keys", array("default" => "on"));
		register_setting("star_cloudprnt_setup_section", "star-cloudprnt-print-order-meta-hidden", array("default" => "off"));
		register_setting("star_cloudprnt_setup_section", "star-cloudprnt-print-order-meta-exclusions", array("default" => "is_vat_exempt, mailchimp_woocommerce_campaign_id, mailchimp_woocommerce_landing_site"));

		register_setting("star_cloudprnt_setup_section", "star-cloudprnt-print-logo-top-cb");
		register_setting("star_cloudprnt_setup_section", "star-cloudprnt-print-logo-top-input");
		register_setting("star_cloudprnt_setup_section", "star-cloudprnt-print-logo-bottom-cb");
		register_setting("star_cloudprnt_setup_section", "star-cloudprnt-print-logo-bottom-input");

		register_setting("star_cloudprnt_setup_section", "star-cloudprnt-buzzer-start", array("default" => ""));
		register_setting("star_cloudprnt_setup_section", "star-cloudprnt-buzzer-end", array("default" => ""));
		register_setting("star_cloudprnt_setup_section", "star-cloudprnt-buzzer-repeat", array("default" => "1"));


		// Register all settings
    	register_setting("star_cloudprnt_setup_section", "star_cloudprnt_location_notes");


		// --- New registration for notification + internal tracking ---
		register_setting("star_cloudprnt_setup_section", "star_cloudprnt_notification_email");
		// Internal fields (not exposed on settings page for editing, used by plugin only)
		register_setting("star_cloudprnt_setup_section", "star_cloudprnt_last_main_printer_mac_add");
		register_setting("star_cloudprnt_setup_section", "star_cloudprnt_last_cus_printer_mac_add");
		register_setting("star_cloudprnt_setup_section", "star_cloudprnt_notified_main");
		register_setting("star_cloudprnt_setup_section", "star_cloudprnt_notified_cus");

		// --- Register settings for last connected MAC addresses ---
		register_setting("star_cloudprnt_setup_section", "star_cloudprnt_last_main_printer_mac_add", array(
			'sanitize_callback' => 'star_cloudprnt_save_main_printer_mac'
		));

		register_setting("star_cloudprnt_setup_section", "star_cloudprnt_last_cus_printer_mac_add", array(
			'sanitize_callback' => 'star_cloudprnt_save_cus_printer_mac'
		));
	}


	// --- Sanitize callback to save main printer MAC ---
	function star_cloudprnt_save_main_printer_mac($value) {
		$selected_name = isset($_POST['star-cloudprnt-printer-select']) ? sanitize_text_field($_POST['star-cloudprnt-printer-select']) : '';
		$printerList = function_exists('star_cloudprnt_get_printer_list') ? star_cloudprnt_get_printer_list() : array();
		// Resolve by MAC-or-name so a renamed printer still saves correctly.
		foreach ($printerList as $listMac => $p) {
			if (star_cloudprnt_option_matches_printer($selected_name, $p, $listMac)) {
				return $p['printerMAC'];
			}
		}
		return '';
	}

	// --- Sanitize callback to save custom printer MAC ---
	function star_cloudprnt_save_cus_printer_mac($value) {
		$selected_name = isset($_POST['star-cloudprnt-printer-select_cus1']) ? sanitize_text_field($_POST['star-cloudprnt-printer-select_cus1']) : '';
		$printerList = function_exists('star_cloudprnt_get_printer_list') ? star_cloudprnt_get_printer_list() : array();
		// Resolve by MAC-or-name so a renamed printer still saves correctly.
		foreach ($printerList as $listMac => $p) {
			if (star_cloudprnt_option_matches_printer($selected_name, $p, $listMac)) {
				return $p['printerMAC'];
			}
		}
		return '';
	}

	// Prevent locked printer from being changed
	add_filter('pre_update_option_star-cloudprnt-printer-select', function($new_value, $old_value) {
		$is_locked = get_option('star-cloudprnt-printer-locked') === 'yes';
		if ($is_locked) {
			// Return old value to prevent change
			return $old_value;
		}
		return $new_value;
	}, 10, 2);

	// Prevent locked secondary printer from being changed
	add_filter('pre_update_option_star-cloudprnt-printer-select_cus1', function($new_value, $old_value) {
		$is_locked = get_option('star-cloudprnt-printer-locked_cus1') === 'yes';
		if ($is_locked) {
			// Return old value to prevent change
			return $old_value;
		}
		return $new_value;
	}, 10, 2);


	// -----------------------------------------------------------------------
	// Reset & Resync Printers — AJAX handler
	// Resets every printer's display name to its MAC address (so the
	// dropdown always shows the correct hardware identifier), then clears
	// all WP lock/selection options so the UI repopulates from scratch.
	// -----------------------------------------------------------------------
	add_action('wp_ajax_star_cloudprnt_reset_printers', 'star_cloudprnt_ajax_reset_printers');
	function star_cloudprnt_ajax_reset_printers() {
		if (!current_user_can('manage_options')) {
			wp_send_json_error(array('message' => 'Permessi insufficienti'), 403);
		}
		check_ajax_referer('star_cloudprnt_reset_printers_nonce', 'nonce');

		$reset_count = 0;
		$errors      = array();

		// 1. Reset each printer's name to its MAC address in data.json
		$printerDataPath = defined('STAR_CLOUDPRNT_PRINTER_DATA_SAVE_PATH')
			? STAR_CLOUDPRNT_PRINTER_DATA_SAVE_PATH
			: '';

		if (!empty($printerDataPath) && is_dir($printerDataPath)) {
			foreach (glob($printerDataPath . '/*', GLOB_ONLYDIR) as $printerDir) {
				$folder  = basename($printerDir);
				$mac     = str_replace('.', ':', $folder); // convert folder name back to MAC
				$dataFile = $printerDir . '/data.json';

				// Only ever touch printers belonging to THIS site. The printer data
				// directory is network-wide, so before this guard a reset performed by
				// one restaurant rewrote the data.json of EVERY printer on the server -
				// all 12 shops - while clearing only its own selections. Observed
				// 2026-08-21: a reset on one subsite wiped every printer's name.
				// On single-site installs star_cloudprnt_claim_printer() is always true,
				// so behaviour there is unchanged.
				if (function_exists('star_cloudprnt_get_printer_owner')
					&& function_exists('star_cloudprnt_is_network')
					&& star_cloudprnt_is_network())
				{
					$owner = star_cloudprnt_get_printer_owner($mac);
					$me    = star_cloudprnt_this_blog_id();
					if ($owner && $owner !== $me) {
						continue; // another restaurant's printer - leave it alone
					}
				}

				if (file_exists($dataFile)) {
					$data = json_decode(file_get_contents($dataFile), true);
					if (!is_array($data)) $data = array();
					// Force name = MAC address (the canonical "reset" state)
					$data['name']       = $mac;
					$data['macAddress'] = $mac;
					$written = @file_put_contents($dataFile, json_encode($data));
					if ($written !== false) {
						$reset_count++;
						if (function_exists('star_cloudprnt_internal_log')) {
							star_cloudprnt_internal_log('reset_printers: reset name for mac=' . $mac, 'INFO');
						}
					} else {
						$errors[] = 'Failed to write data.json for ' . $mac;
					}
				}
			}
		}

		// 2. Clear WP options: lock state + printer selections + last-known MACs
		$options_to_clear = array(
			'star-cloudprnt-printer-locked',
			'star-cloudprnt-printer-locked_cus1',
			'star-cloudprnt-printer-locked-name',
			'star-cloudprnt-printer-locked-name_cus1',
			'star-cloudprnt-printer-select',
			'star-cloudprnt-printer-select_cus1',
			'star_cloudprnt_last_main_printer_mac_add',
			'star_cloudprnt_last_cus_printer_mac_add',
			'star_cloudprnt_notified_main',
			'star_cloudprnt_notified_cus',
		);
		foreach ($options_to_clear as $opt) {
			delete_option($opt);
		}

		// This site has just given up its printers, so release its ownership claims
		// too - otherwise the registry keeps holding them and no one (including this
		// site) can re-assign them cleanly. Only rows owned by this site are touched.
		if (function_exists('star_cloudprnt_sync_site_printers')) {
			star_cloudprnt_sync_site_printers(array());
		}

		if (!empty($errors)) {
			wp_send_json_error(array(
				'message' => 'Reset parziale: ' . $reset_count . ' stampante(e) reimpostate. Errori: ' . implode('; ', $errors),
			));
		}

		wp_send_json_success(array(
			'message' => $reset_count . ' stampante(e) reimpostate con nome = MAC address. Selezioni e lock cancellati. Ricarica la pagina per riassegnare.',
		));
	}

	// --- New: Display field for Notification Email ---
	function star_cloudprnt_notification_email_display() {
		$value = esc_attr(get_option('star_cloudprnt_notification_email', ''));
		?>
			<input type="email" name="star_cloudprnt_notification_email" size="60" value="<?php echo $value; ?>">
			<p class="description">Email to receive printer disconnect/reconnect notifications. If blank, the site admin email will be used.</p>
		<?php
	}

	// -----------------------------------------------------------------------
	// ModSecurity Bypass – checkbox toggle with auto-test
	// -----------------------------------------------------------------------

	/**
	 * Display the ModSecurity bypass checkbox in settings.
	 * Default: checked (file present). Unchecking removes the .htaccess.
	 */
	function star_cloudprnt_modsec_bypass_display() {
		$htaccess_path = plugin_dir_path(__FILE__) . 'cloudprnt/.htaccess';
		$is_active = file_exists($htaccess_path);
		?>
		<div id="star-cloudprnt-modsec-wrapper">
			<label>
				<input type="checkbox" id="star-cloudprnt-modsec-cb" <?php checked($is_active); ?>>
				Enable ModSecurity / WAF bypass for CloudPRNT endpoint
			</label>
			<span id="star-cloudprnt-modsec-status" style="margin-left: 10px;">
				<?php if ($is_active): ?>
					<span style="color: green;">✅ Active</span>
				<?php else: ?>
					<span style="color: #888;">Inactive</span>
				<?php endif; ?>
			</span>
			<p class="description">
				Creates a <code>.htaccess</code> in the <code>cloudprnt/</code> folder that disables ModSecurity and configures LiteSpeed cache bypass.<br>
				Required on servers with ModSecurity (e.g. Jelastic, cPanel). The plugin will <strong>auto-test</strong> compatibility when enabling.
				If it causes HTTP 500 errors, it will be removed automatically.
			</p>
		</div>
		<script type="text/javascript">
		jQuery(document).ready(function($) {
			$('#star-cloudprnt-modsec-cb').on('change', function(e) {
				var $cb = $(this);
				var $status = $('#star-cloudprnt-modsec-status');
				var enable = $cb.is(':checked');
				$cb.prop('disabled', true);
				$status.html('<span style="color:#888;">Testing...</span>');

				$.post(ajaxurl, {
					action: 'star_cloudprnt_toggle_modsec',
					nonce: '<?php echo wp_create_nonce('star_cloudprnt_modsec_nonce'); ?>',
					enable: enable ? '1' : '0'
				}, function(response) {
					if (response.success) {
						var color = response.data.active ? 'green' : '#888';
						$status.html('<span style="color:' + color + ';">' + response.data.message + '</span>');
						$cb.prop('checked', response.data.active);
					} else {
						$status.html('<span style="color:red;">⚠️ ' + (response.data ? response.data.message : 'Error') + '</span>');
						$cb.prop('checked', false);
					}
					$cb.prop('disabled', false);
				}).fail(function() {
					$status.html('<span style="color:red;">Request failed</span>');
					$cb.prop('disabled', false);
				});
			});
		});
		</script>
		<?php
	}

	/**
	 * AJAX handler: toggle ModSecurity bypass .htaccess with auto-test.
	 */
	add_action('wp_ajax_star_cloudprnt_toggle_modsec', 'star_cloudprnt_handle_modsec_toggle');
	function star_cloudprnt_handle_modsec_toggle() {
		check_ajax_referer('star_cloudprnt_modsec_nonce', 'nonce');
		if (!current_user_can('manage_options')) {
			wp_send_json_error(array('message' => 'Unauthorized'), 403);
		}

		$htaccess_path = plugin_dir_path(__FILE__) . 'cloudprnt/.htaccess';
		$endpoint_url  = plugins_url('cloudprnt/cloudprnt.php', __FILE__);
		$enable = isset($_POST['enable']) && $_POST['enable'] === '1';

		if (!$enable) {
			// Disable: remove the file and save option
			@unlink($htaccess_path);
			update_option('star_cloudprnt_modsec_bypass', 'no');
			wp_send_json_success(array(
				'active'  => false,
				'message' => 'Inactive — .htaccess removed',
			));
		}

		// Enable: create the full .htaccess
		$htaccess_content = "# Star CloudPRNT – ModSecurity bypass for printer polling\n"
			. "# Auto-generated by plugin settings. To remove: uncheck ModSecurity Bypass.\n\n"
			. "<IfModule mod_security.c>\n"
			. "    SecRuleEngine Off\n"
			. "</IfModule>\n\n"
			. "<IfModule mod_security2.c>\n"
			. "    SecRuleEngine Off\n"
			. "</IfModule>\n\n"
			. "<IfModule mod_litespeed.c>\n"
			. "    CacheLookup off\n"
			. "</IfModule>\n\n"
			. "<Files \"cloudprnt.php\">\n"
			. "    <IfModule mod_authz_core.c>\n"
			. "        Require all granted\n"
			. "    </IfModule>\n"
			. "    <IfModule !mod_authz_core.c>\n"
			. "        Order allow,deny\n"
			. "        Allow from all\n"
			. "    </IfModule>\n"
			. "</Files>\n";

		$written = @file_put_contents($htaccess_path, $htaccess_content);
		if ($written === false) {
			wp_send_json_error(array('message' => 'Cannot write .htaccess — check folder permissions.'));
		}

		// Auto-test: verify the endpoint still works
		$test = wp_remote_get($endpoint_url, array('timeout' => 10, 'sslverify' => false));

		if (is_wp_error($test)) {
			update_option('star_cloudprnt_modsec_bypass', 'yes');
			wp_send_json_success(array(
				'active'  => true,
				'message' => '✅ Active — could not auto-test, verify manually',
			));
		}

		$status_code = wp_remote_retrieve_response_code($test);

		if ($status_code === 500) {
			// Incompatible server — rollback
			@unlink($htaccess_path);
			update_option('star_cloudprnt_modsec_bypass', 'no');
			wp_send_json_error(array(
				'message' => 'Your server does not support these .htaccess directives (HTTP 500). File removed. Contact your hosting provider to whitelist the CloudPRNT endpoint.',
			));
		}

		update_option('star_cloudprnt_modsec_bypass', 'yes');
		wp_send_json_success(array(
			'active'  => true,
			'message' => '✅ Active — verified (HTTP ' . $status_code . ')',
		));
	}

	/**
	 * On init: enforce the ModSecurity bypass option.
	 * Handles plugin updates that re-create the .htaccess file when the user had disabled it.
	 */
	add_action('init', 'star_cloudprnt_enforce_modsec_option');
	function star_cloudprnt_enforce_modsec_option() {
		if (get_option('star_cloudprnt_modsec_bypass', 'yes') === 'no') {
			$htaccess_path = dirname(__FILE__) . '/cloudprnt/.htaccess';
			if (file_exists($htaccess_path)) {
				@unlink($htaccess_path);
			}
		}
	}

	// -----------------------------------------------------------------------
	// Inline Printer Info — show printer details on the main settings page
	// -----------------------------------------------------------------------

	/**
	 * Render inline printer information card.
	 *
	 * @param array  $printerdata   Printer data array from star_cloudprnt_get_printer_list().
	 * @param string $printerMac    The printer MAC address.
	 * @param string $prefix        CSS ID prefix for uniqueness (e.g. 'main', 'cus1').
	 */
	function star_cloudprnt_render_printer_info_inline($printerdata, $printerMac, $prefix = 'main') {
		if (empty($printerdata) || !is_array($printerdata)) return;

		$onlineString = '<span style="color: orange">Unknown</span>';
		if (isset($printerdata['printerOnline'])) {
			$onlineString = $printerdata['printerOnline']
				? '<span style="color: green">Connected</span>'
				: '<span style="color: red">Not Connected</span>';
		}

		$httpStatus = isset($printerdata['statusCode']) ? $printerdata['statusCode'] : '—';
		$httpStatus = str_replace("%", " ", $httpStatus);
		$httpStatus = str_replace(" 20", " ", $httpStatus);

		$lastActive = isset($printerdata['lastActive']) ? date("D j M y - H:i:s", $printerdata['lastActive']) : '—';
		$pollInterval = isset($printerdata['GetPollInterval']) ? $printerdata['GetPollInterval'] : '—';
		$asbStatus = isset($printerdata['status']) ? $printerdata['status'] : '—';
		$ipAddress = isset($printerdata['ipAddress']) ? $printerdata['ipAddress'] : '—';
		?>
		<div id="star-cloudprnt-info-<?php echo esc_attr($prefix); ?>" style="margin-top: 10px; padding: 10px 15px; background: #f9f9f9; border-left: 4px solid #0073aa; border-radius: 3px; font-size: 13px; line-height: 1.8;">
			<strong>Connectivity:</strong> <?php echo $onlineString; ?> &nbsp;|&nbsp;
			<strong>Poll Interval:</strong> <?php echo esc_html($pollInterval); ?>s &nbsp;|&nbsp;
			<strong>Last Communication:</strong> <?php echo esc_html($lastActive); ?><br>
			<strong>MAC:</strong> <?php echo esc_html(strtoupper($printerMac)); ?> &nbsp;|&nbsp;
			<strong>IP:</strong> <?php echo esc_html($ipAddress); ?> &nbsp;|&nbsp;
			<strong>HTTP Status:</strong> <?php echo esc_html($httpStatus); ?> &nbsp;|&nbsp;
			<strong>ASB:</strong> <?php echo esc_html($asbStatus); ?>
			<?php
			// Connection sessions history
			$printerDir = STAR_CLOUDPRNT_PRINTER_DATA_SAVE_PATH . '/' . star_cloudprnt_get_printer_folder($printerMac);
			$sessFile = $printerDir . '/connection_sessions.json';
			if (file_exists($sessFile)) {
				$sessions = @json_decode(@file_get_contents($sessFile), true);
				if (is_array($sessions) && !empty($sessions)) {
					$recent = array_slice($sessions, -10);
					$recent = array_reverse($recent);
					?>
					<details style="margin-top: 6px;">
						<summary style="cursor: pointer; color: #0073aa; font-weight: 600;">📋 Connection History (last <?php echo count($recent); ?> events)</summary>
						<table style="margin-top: 4px; width: 100%; border-collapse: collapse; font-size: 12px;">
							<tr style="background: #e9e9e9;">
								<th style="padding: 3px 8px; text-align: left;">Event</th>
								<th style="padding: 3px 8px; text-align: left;">Time</th>
								<th style="padding: 3px 8px; text-align: left;">IP</th>
							</tr>
							<?php foreach ($recent as $sess): 
								$icon = $sess['event'] === 'connected' ? '🟢' : '🔴';
								$label = ucfirst($sess['event']);
							?>
							<tr style="border-bottom: 1px solid #ddd;">
								<td style="padding: 3px 8px;"><?php echo $icon . ' ' . esc_html($label); ?></td>
								<td style="padding: 3px 8px;"><?php echo esc_html($sess['datetime']); ?></td>
								<td style="padding: 3px 8px;"><?php echo esc_html($sess['ip'] ?: '—'); ?></td>
							</tr>
							<?php endforeach; ?>
						</table>
					</details>
					<?php
				}
			}
			?>
		</div>
		<?php
	}

	// --- Main cron check function ---
	function star_cloudprnt_cron_check_printers() {
		// Get printer list
		if (!function_exists('star_cloudprnt_get_printer_list')) return; // safety
		$printerList = star_cloudprnt_get_printer_list();

		// Get notification target
		$notify_to = get_option('star_cloudprnt_notification_email', '');
		if (empty($notify_to)) $notify_to = get_option('admin_email');

		// --- Fetch WordPress, PHP, and Plugin Info ---
		$wp_version  = get_bloginfo('version');
		$php_version = phpversion();

		if (!function_exists('get_plugin_data')) {
			require_once(ABSPATH . 'wp-admin/includes/plugin.php');
		}

		// Path to plugin main file
		$plugin_file = WP_PLUGIN_DIR . '/star-cloudprnt-for-woocommerce/star-cloudprnt-for-woocommerce.php';
		$plugin_data = get_plugin_data($plugin_file);
		$plugin_version = isset($plugin_data['Version']) ? $plugin_data['Version'] : 'Unknown';

		$next_cron_run = date('Y-m-d H:i:s', wp_next_scheduled('star_cloudprnt_check_printers'));

		// --- Check MAIN printer ---
		$current_selected = get_option('star-cloudprnt-printer-select', '');
		$current_mac = '';
		foreach ($printerList as $p) {
			if (star_cloudprnt_option_matches_printer($current_selected, $p)) { $current_mac = $p['printerMAC']; break; }
		}

		// $current_selected = "ABCD";
		// $last_main_mac = "ABCD";
		// $current_mac = "ABCD";
		$last_main_mac = get_option('star_cloudprnt_last_main_printer_mac_add', '');
		$was_notified_main = get_option('star_cloudprnt_notified_main', '0');


		// If no current_mac but we have a last_main_mac, then the main printer is not reachable -> notify (if not recently admin-changed)
		if (empty($current_mac) && !empty($last_main_mac) && $current_selected === $last_main_mac ) {
			if ($was_notified_main !== '1') {
				$subject = sprintf('Main printer disconnected on %s', parse_url(get_home_url(), PHP_URL_HOST));
				$message = "Your main printer has been disconnected or is not reachable.\n\n";
				$message .= sprintf("Site: %s\n", get_home_url());
				$message .= sprintf("Printer MAC: %s\n", $last_main_mac);
				$message .= "\nPlease reconnect your main printer or check network connectivity.\n\n";

				// --- Append additional log info ---
				$message .= "--- Additional Log Info ---\n";
				$message .= "Event: Main Printer Disconnected\n";
				$message .= "Time: " . date('Y-m-d H:i:s') . " (Server)\n";
				$message .= "Site: " . get_home_url() . "\n\n";
				$message .= "--- Printer Status ---\n";
				$message .= "Last Main MAC: " . $last_main_mac . "\n\n";
				$message .= "--- WordPress Info ---\n";
				$message .= "WP Version: " . $wp_version . "\n";
				$message .= "PHP Version: " . $php_version . "\n";
				$message .= "Plugin Version: " . $plugin_version . "\n";
				$message .= "Next Cron Run: " . $next_cron_run . "\n";

				wp_mail($notify_to, $subject, $message);
				update_option('star_cloudprnt_notified_main', '1');
			}
		}
		// If we had previously notified and now the printer is back (current_mac equals last_main_mac) -> recover
		else if (!empty($current_mac) && !empty($last_main_mac) && $current_selected === $last_main_mac && $was_notified_main === '1') {
			if ($current_mac === $last_main_mac) {
				// Printer returned to previous MAC - clear notification flag and optionally send recovery
				update_option('star_cloudprnt_notified_main', '0');
				$subject = sprintf('Main printer reconnected on %s', parse_url(get_home_url(), PHP_URL_HOST));
				$message = "Your main printer has reconnected successfully.\n\n";
				$message .= sprintf("Site: %s\n", get_home_url());
				$message .= sprintf("Printer MAC: %s\n\n", $current_mac);

				// Append detailed log
				$message .= "--- Additional Log Info ---\n";
				$message .= "Event: Main Printer Reconnected\n";
				$message .= "Time: " . date('Y-m-d H:i:s') . " (Server)\n";
				$message .= "Site: " . get_home_url() . "\n\n";
				$message .= "--- Printer Status ---\n";
				$message .= "Current Main MAC: " . $current_mac . "\n\n";
				$message .= "--- WordPress Info ---\n";
				$message .= "WP Version: " . $wp_version . "\n";
				$message .= "PHP Version: " . $php_version . "\n";
				$message .= "Plugin Version: " . $plugin_version . "\n";
				$message .= "Next Cron Run: " . $next_cron_run . "\n";

				wp_mail($notify_to, $subject, $message);
			}
		}

		// --- CUSTOM (secondary) printer check ---
		$current_selected_cus = get_option('star-cloudprnt-printer-select_cus1', '');
		$current_cus_mac = '';
		foreach ($printerList as $p) {
			if (star_cloudprnt_option_matches_printer($current_selected_cus, $p)) { $current_cus_mac = $p['printerMAC']; break; }
		}

		$last_cus_mac = get_option('star_cloudprnt_last_cus_printer_mac_add', '');
		$was_notified_cus = get_option('star_cloudprnt_notified_cus', '0');

		if (empty($current_cus_mac) && !empty($last_cus_mac) && $current_selected_cus === $last_cus_mac) {
			if ($was_notified_cus !== '1') {
				$subject = sprintf('Custom printer disconnected on %s', parse_url(get_home_url(), PHP_URL_HOST));
				$message = "Your custom/configured printer has been disconnected or is not reachable.\n\n";
				$message .= sprintf("Site: %s\n", get_home_url());
				$message .= sprintf("Printer MAC: %s\n", $last_cus_mac);
				$message .= "\nPlease reconnect your custom printer or check network connectivity.\n\n";

				// --- Append additional log info ---
				$message .= "--- Additional Log Info ---\n";
				$message .= "Event: Custom Printer Disconnected\n";
				$message .= "Time: " . date('Y-m-d H:i:s') . " (Server)\n";
				$message .= "Site: " . get_home_url() . "\n\n";
				$message .= "--- Printer Status ---\n";
				$message .= "Last Custom MAC: " . $last_cus_mac . "\n\n";
				$message .= "--- WordPress Info ---\n";
				$message .= "WP Version: " . $wp_version . "\n";
				$message .= "PHP Version: " . $php_version . "\n";
				$message .= "Plugin Version: " . $plugin_version . "\n";
				$message .= "Next Cron Run: " . $next_cron_run . "\n";
				
				wp_mail($notify_to, $subject, $message);
				update_option('star_cloudprnt_notified_cus', '1');
			}
		}
		else if (!empty($current_cus_mac) && !empty($last_cus_mac) && $current_selected_cus === $last_cus_mac && $was_notified_cus === '1') {
			if ($current_cus_mac === $last_cus_mac) {
				update_option('star_cloudprnt_notified_cus', '0');
				$subject = sprintf('Custom printer reconnected on %s', parse_url(get_home_url(), PHP_URL_HOST));
				$message = "Your custom printer has reconnected successfully.\n\n";
				$message .= sprintf("Site: %s\n", get_home_url());
				$message .= sprintf("Printer MAC: %s\n\n", $current_cus_mac);

				$message .= "--- Additional Log Info ---\n";
				$message .= "Event: Custom Printer Reconnected\n";
				$message .= "Time: " . date('Y-m-d H:i:s') . " (Server)\n";
				$message .= "Site: " . get_home_url() . "\n\n";
				$message .= "--- Printer Status ---\n";
				$message .= "Current Custom MAC: " . $current_cus_mac . "\n\n";
				$message .= "--- WordPress Info ---\n";
				$message .= "WP Version: " . $wp_version . "\n";
				$message .= "PHP Version: " . $php_version . "\n";
				$message .= "Plugin Version: " . $plugin_version . "\n";
				$message .= "Next Cron Run: " . $next_cron_run . "\n";

				wp_mail($notify_to, $subject, $message);
			}
		}
	}


	function star_cloudprnt_menu_item()
	{
		// Top level menu for Call Center / POS (always visible if enabled)
		$pos_enabled = get_option('star-cloudprnt-enable-pos', 'no') === 'yes';
		if ($pos_enabled) {
			add_menu_page(
				'Call Center',
				'Call Center',
				'edit_shop_orders',
				'fd-pos',
				'star_cloudprnt_pos_page',
				'dashicons-phone',
				56
			);
			// Submenu: Printer settings
			add_submenu_page('fd-pos','StarMicronics Printer','StarMicronics Printer','manage_options','star-cloudprnt-settings-admin','star_cloudprnt_page');
			// Logs (conditional)
			if (get_option('star_cloudprnt_enable_log','no') === 'yes') {
				add_submenu_page('fd-pos','Logs','Logs','manage_options','star-cloudprnt-logs','star_cloudprnt_view_logs_page');
			}
			// Z Report
			add_submenu_page('fd-pos','Z Report','Z Report','manage_options','star-cloudprnt-z-report','star_cloudprnt_z_report_page');
		} else {
			// Original placement under Settings if POS disabled
			add_submenu_page('options-general.php', 'Star CloudPRNT for WooCommerce', 'Star CloudPRNT', 'manage_options', 'star-cloudprnt-settings-admin', 'star_cloudprnt_page');
			if (get_option('star_cloudprnt_enable_log','no') === 'yes') {
				add_submenu_page('options-general.php','CloudPRNT Logs','CloudPRNT Logs','manage_options','star-cloudprnt-logs','star_cloudprnt_view_logs_page');
			}
			add_submenu_page('options-general.php','Z Report','Z Report','manage_options','star-cloudprnt-z-report','star_cloudprnt_z_report_page');
		}
	}
	
	function star_cloudprnt_setup_section_info()
	{
		print '<strong>Set your printer "Server URL" to:</strong><br>';
		print plugins_url('cloudprnt/cloudprnt.php', __FILE__);
        
        $main_printer = get_option('star-cloudprnt-printer-select');
		$new_printer = isset($_POST['star-cloudprnt-printer-select_cus1']) && $_POST['star-cloudprnt-printer-select_cus1'] !='' ? $_POST['star-cloudprnt-printer-select_cus1'] : '';

		if (!empty($main_printer) && !empty($new_printer ) && $main_printer === $new_printer ) {
			add_settings_error(
				'star-cloudprnt-printer-select_cus1',
				'star_cloudprnt_duplicate_error',
				'Please configure different address. Selected printer already used as main printer.',
				'error'
			);
			
		}
	}

	function star_cloudprnt_select_display()
	{
	   ?>
			<select name="star-cloudprnt-select">
				<option value="disable" <?php selected(get_option('star-cloudprnt-select'), "disable"); ?>>DISABLE</option>
				<option value="enable" <?php selected(get_option('star-cloudprnt-select'), "enable"); ?>>ENABLE</option>
			</select>
	   <?php
	}

	// --- Display field: Enable debug logging ---
	function star_cloudprnt_logging_display()
	{
		$enabled = get_option('star_cloudprnt_enable_log', 'no');
		?>
			<label>
				<input type="checkbox" name="star_cloudprnt_enable_log" value="yes" <?php checked($enabled, 'yes'); ?> /> Enable debug logging (writes to plugin logs/star-cloudprnt.log)
			</label>
			<p class="description">Use this to collect plugin-local debug logs for troubleshooting. Logging may include order data and printer identifiers.</p>
		<?php
	}

	// --- Display field: Enable POS tab ---
	function star_cloudprnt_enable_pos_display()
	{
		$enabled = get_option('star-cloudprnt-enable-pos', 'no');
		?>
			<label>
				<input type="checkbox" name="star-cloudprnt-enable-pos" value="yes" <?php checked($enabled, 'yes'); ?> /> Show "Sistema di Cassa (POS)" tab in Settings
			</label>
			<p class="description">Enable the in-plugin POS tab. When enabled, the POS admin page appears under Settings and loads the POS UI.</p>
		<?php
	}
	
	
	function star_cloudprnt_printer_encoding_select_display()
	{
	   ?>
			<select name="star-cloudprnt-printer-encoding-select">
				<option value="UTF-8" <?php selected(get_option('star-cloudprnt-printer-encoding-select'), "utf-8"); ?>>UTF-8</option>
				<option value="1252" <?php selected(get_option('star-cloudprnt-printer-encoding-select'), "1252"); ?>>1252</option>
			</select>
			<label>UTF-8 mode is recommended for mC-Print or TSP650II printer models.</label>
	   <?php
	}
	
	function star_cloudprnt_print_copies_input_display()
	{
		$copies=get_option("star-cloudprnt-print-copies-input");
		$copies = intval($copies);
		if($copies < 1) $copies = 1;
		
		?>
			<input type="number" name="star-cloudprnt-print-copies-input" value="<?php echo $copies; ?>" min=1 max=10>
		<?php
	}

	function star_cloudprnt_printer_select_display()
{
	$printerList = star_cloudprnt_get_printer_list();

	// Show this site ONLY the printers that actually poll this site's endpoint.
	//
	// A printer is configured on the device with the URL it posts to, so that URL -
	// recorded as serverUrl on each poll by cloudprnt.php - is the authoritative
	// statement of which site the printer belongs to. It cannot be set wrongly from
	// a browser, unlike the dropdown.
	//
	// The previous implementation searched the printer data for this URL, but no
	// printer file ever contained it, so the filter matched nothing on every site
	// and the old "?: $printerList" fallback silently listed EVERY printer on the
	// network - all 13 across 12 restaurants - inviting an admin to pick another
	// shop's device. There is deliberately no fallback now: no match means no
	// printers, and the empty state below tells the user exactly what to configure.
	$expectedServerUrl = plugins_url('cloudprnt/cloudprnt.php', __FILE__);
	$expectedEndpoint  = star_cloudprnt_normalize_endpoint($expectedServerUrl);

	$printerListToShow = array();
	foreach ($printerList as $mac => $pdata) {
		$seen = isset($pdata['serverUrl']) ? star_cloudprnt_normalize_endpoint($pdata['serverUrl']) : '';
		if ($seen !== '' && $seen === $expectedEndpoint) {
			$printerListToShow[$mac] = $pdata;
		}
	}

	// Printers that have not polled since the upgrade have no serverUrl yet. Rather
	// than hide a printer this site is legitimately using, keep showing the ones it
	// already has selected until they next poll (which takes a few seconds).
	foreach (array('star-cloudprnt-printer-select', 'star-cloudprnt-printer-select_cus1') as $slot) {
		$chosen = get_option($slot, '');
		if ($chosen === '') { continue; }
		foreach ($printerList as $mac => $pdata) {
			if (isset($printerListToShow[$mac])) { continue; }
			$seen = isset($pdata['serverUrl']) ? star_cloudprnt_normalize_endpoint($pdata['serverUrl']) : '';
			if ($seen === '' && star_cloudprnt_option_matches_printer($chosen, $pdata, $mac)) {
				$printerListToShow[$mac] = $pdata;
			}
		}
	}
	if (empty($printerListToShow)) {
        // Tell the user what to do instead of leaving them guessing - and never
        // fall back to listing other restaurants' printers just to look populated.
        echo '<select name="star-cloudprnt-printer-select" disabled><option value="none">No printer found for this site</option></select>';
        echo '<p style="margin-top:8px"><strong>No printer is sending to this site yet.</strong><br>'
           . 'On the printer, set the CloudPRNT <em>Server URL</em> to:<br>'
           . '<code style="user-select:all">' . esc_html($expectedServerUrl) . '</code><br>'
           . 'The printer appears here automatically within a few seconds of its next poll. '
           . 'Printers belonging to other sites are intentionally not listed.</p>';
        if (!empty($printerList)) {
            echo '<p class="description">' . sprintf(
                /* translators: %d: number of printers registered elsewhere on the network */
                esc_html__('%d printer(s) are registered on this server but send to a different site.', 'star-cloudprnt'),
                count($printerList)
            ) . '</p>';
        }
    } else {
        $selectedPrinter = "";
        $isLocked = get_option('star-cloudprnt-printer-locked') === 'yes';
        $lockedClass = $isLocked ? ' class="locked-select"' : '';
        echo '<select id="star-cloudprnt-printer-select-id" name="star-cloudprnt-printer-select"' . $lockedClass . '>';
	foreach ($printerListToShow as $printer) {
            ?>
            <script type="text/javascript">
                function star_cloudprnt_load_printer_settings()
                {
                    var selected_printer_cb = document.getElementById("star-cloudprnt-printer-select-id");
                    var selected_printer = selected_printer_cb.options[selected_printer_cb.selectedIndex].value;
                    window.location.href = '?page=<?php echo $_GET['page']; ?>&printersettings='+btoa(selected_printer);
                }
                function star_cloudprnt_load_printer_settings_custom(){
						var selected_printer_cb = document.getElementById("star-cloudprnt-printer-select-cus1");
						var selected_printer = selected_printer_cb.options[selected_printer_cb.selectedIndex].value;
						window.location.href = '?page=<?php echo $_GET['page']; ?>&printersettings='+btoa(selected_printer);
					}
                    
            </script>
            <option value="<?php echo esc_attr($printer['name']); ?>" <?php selected(true, star_cloudprnt_option_matches_printer(get_option('star-cloudprnt-printer-select'), $printer)); ?>><?php echo esc_html($printer['name']); ?></option>
            <?php
            if (get_option('star-cloudprnt-printer-select') == $printer['name']) $selectedPrinter = $printer['printerMAC'];

        }
        echo '</select>';
        $isLocked = get_option('star-cloudprnt-printer-locked') === 'yes';
        $lockIcon = $isLocked ? '🔒' : '🔓';
        $lockText = $isLocked ? 'Locked' : 'Unlocked';
        echo '<a href="javascript: void(0);" onclick="star_cloudprnt_load_printer_settings()" style="margin-left: 10px">Edit</a>';
        echo '<button type="button" id="star-cloudprnt-lock-btn" class="button" style="margin-left: 10px;">' . $lockIcon . ' ' . $lockText . '</button>';
        echo '<input type="hidden" id="star-cloudprnt-printer-locked" name="star-cloudprnt-printer-locked" value="' . ($isLocked ? 'yes' : 'no') . '">';
        $lockedName = get_option('star-cloudprnt-printer-locked-name', '');
        echo '<input type="hidden" id="star-cloudprnt-printer-locked-name" name="star-cloudprnt-printer-locked-name" value="' . esc_attr($lockedName) . '">';
        echo '<style>.locked-select{pointer-events:none;opacity:0.6;background:#f0f0f0;}</style>';

        // Show inline printer info for main printer
        $mainPrinterName = get_option('star-cloudprnt-printer-select', '');
        $mainPrinterData = null;
        $mainPrinterMac  = '';
        foreach ($printerListToShow as $mac => $pdata) {
            if (star_cloudprnt_option_matches_printer($mainPrinterName, $pdata, $mac)) {
                $mainPrinterData = $pdata;
                $mainPrinterMac  = isset($pdata['printerMAC']) ? $pdata['printerMAC'] : $mac;
                break;
            }
        }
        if ($mainPrinterData) {
            star_cloudprnt_render_printer_info_inline($mainPrinterData, $mainPrinterMac, 'main');
        }


        // =========================
        // EXTRA: Configure New Printer Checkbox + Dropdown
        // =========================
        $extra_saved = get_option("star-cloudprnt-printer-select_cus1");

		// if(!empty($extra_saved)) {
		// 	print_r($extra_saved);
		// }
		// else {
		// 	echo "null";
		// }

		$site_id = get_current_blog_id();
        $isLocked2 = get_option('star-cloudprnt-printer-locked_cus1') === 'yes';
        ?>
        <br><br>
        <label>
			<input type="hidden" name="star-cloudprnt-current_site_id" value="<?php echo $site_id;?>">
            <input type="checkbox" id="star-cloudprnt-add-printer" <?php checked(!empty($extra_saved)); ?>> Configure New Printer
        </label>
        <div id="star-cloudprnt-extra-printer" style="margin-top:10px; <?php echo empty($extra_saved) ? 'display:none;' : ''; ?>">
            <select name="star-cloudprnt-printer-select_cus1" id="star-cloudprnt-printer-select-cus1" <?php echo $isLocked2 ? 'class="locked-select"' : ''; ?>>
                <option value="">-- Select Printer --</option>
				<?php 
				foreach ($printerListToShow as $printer) {
					echo '<option value="'.esc_attr($printer['name']).'" '.selected(true, star_cloudprnt_option_matches_printer($extra_saved, $printer), false).'>'.esc_html($printer['name']).'</option>';
				}
                ?>
            </select>
            <?php
            $lockIcon2 = $isLocked2 ? '🔒' : '🔓';
            $lockText2 = $isLocked2 ? 'Locked' : 'Unlocked';
            ?>
            <a href="javascript: void(0);" onclick="star_cloudprnt_load_printer_settings_custom()" style="margin-left: 10px">Edit</a>
            <button type="button" id="star-cloudprnt-lock-btn-cus1" class="button" style="margin-left: 10px;"><?php echo $lockIcon2 . ' ' . $lockText2; ?></button>
            <input type="hidden" id="star-cloudprnt-printer-locked_cus1" name="star-cloudprnt-printer-locked_cus1" value="<?php echo $isLocked2 ? 'yes' : 'no'; ?>">
            <?php
            $lockedName2 = get_option('star-cloudprnt-printer-locked-name_cus1', '');
            ?>
            <input type="hidden" id="star-cloudprnt-printer-locked-name_cus1" name="star-cloudprnt-printer-locked-name_cus1" value="<?php echo esc_attr($lockedName2); ?>">
            <span class="error" style="color:red;display:none;">Please configure different address.</span>
            <?php
            // Show inline printer info for secondary printer
            if (!empty($extra_saved)) {
                $cusPrinterData = null;
                $cusPrinterMac  = '';
                foreach ($printerListToShow as $mac => $pdata) {
                    if (star_cloudprnt_option_matches_printer($extra_saved, $pdata, $mac)) {
                        $cusPrinterData = $pdata;
                        $cusPrinterMac  = isset($pdata['printerMAC']) ? $pdata['printerMAC'] : $mac;
                        break;
                    }
                }
                if ($cusPrinterData) {
                    star_cloudprnt_render_printer_info_inline($cusPrinterData, $cusPrinterMac, 'cus1');
                }
            }
            ?>
        </div>

        <script type="text/javascript">
        (function($){
            // Toggle dropdown on checkbox
            $("#star-cloudprnt-add-printer").on("change", function(){
                if($(this).is(":checked")){
                    $("#star-cloudprnt-extra-printer").show();
                } else {
                    $("#star-cloudprnt-extra-printer").hide();
                    $("#star-cloudprnt-printer-select-cus1").val("");
                }
            });

            // Validate duplicates
            $(document).on("change", "#star-cloudprnt-printer-select-id, #star-cloudprnt-printer-select-cus1", function(){
                let mainPrinter = $("#star-cloudprnt-printer-select-id").val();
                let extraPrinter = $("#star-cloudprnt-printer-select-cus1").val();
                if(mainPrinter && extraPrinter && mainPrinter === extraPrinter){
                    $("#star-cloudprnt-extra-printer .error").show();
                    alert("Please configure different address.");
                } else {
                    $("#star-cloudprnt-extra-printer .error").hide();
                }
            });
            
            // Lock/Unlock functionality for main printer
            $("#star-cloudprnt-lock-btn").on("click", function(e){
                e.preventDefault();
                var $btn = $(this);
                var $select = $("#star-cloudprnt-printer-select-id");
                var $hidden = $("#star-cloudprnt-printer-locked");
                var $hiddenName = $("#star-cloudprnt-printer-locked-name");
                var isLocked = $hidden.val() === 'yes';
                
                if(isLocked) {
                    // Unlock
                    $hidden.val('no');
                    $hiddenName.val('');
                    $select.removeClass('locked-select');
                    $btn.html('🔓 Unlocked');
                } else {
                    // Lock - save current printer name
                    var currentPrinterName = $select.val();
                    $hidden.val('yes');
                    $hiddenName.val(currentPrinterName);
                    $select.addClass('locked-select');
                    $btn.html('🔒 Locked');
                }
            });
            
            // Lock/Unlock functionality for secondary printer
            $("#star-cloudprnt-lock-btn-cus1").on("click", function(e){
                e.preventDefault();
                var $btn = $(this);
                var $select = $("#star-cloudprnt-printer-select-cus1");
                var $hidden = $("#star-cloudprnt-printer-locked_cus1");
                var $hiddenName = $("#star-cloudprnt-printer-locked-name_cus1");
                var isLocked = $hidden.val() === 'yes';
                
                if(isLocked) {
                    // Unlock
                    $hidden.val('no');
                    $hiddenName.val('');
                    $select.removeClass('locked-select');
                    $btn.html('🔓 Unlocked');
                } else {
                    // Lock - save current printer name
                    var currentPrinterName = $select.val();
                    $hidden.val('yes');
                    $hiddenName.val(currentPrinterName);
                    $select.addClass('locked-select');
                    $btn.html('🔒 Locked');
                }
            });
        })(jQuery);
        </script>
        <?php
    }
}
	
	function star_cloudprnt_trigger_display()  
	{
		?>
			<input type="radio" name="star-cloudprnt-trigger" value="status_processing" <?php checked(get_option('star-cloudprnt-trigger'), 'status_processing', true) ?>>
			<label>When an order is assigned the "processing" status (recommended for most sites)</label><br>
			<input type="radio" name="star-cloudprnt-trigger" value="status_completed" <?php checked(get_option('star-cloudprnt-trigger'), 'status_completed', true) ?>>
			<label>When an order is assigned the "completed" status</label><br>
			<input type="radio" name="star-cloudprnt-trigger" value="status_on-hold" <?php checked(get_option('star-cloudprnt-trigger'), 'status_on-hold', true) ?>>
			<label>When an order is assigned the "on hold" status</label><br>
			<input type="radio" name="star-cloudprnt-trigger" value="thankyou" <?php checked(get_option('star-cloudprnt-trigger'), 'thankyou', true) ?>>
			<label>When WooCommerce "Thank You" message is displayed (<span class="star_cp_caution">&#x26a0;</span> legacy option, not recommended)</label><br>
			<input type="radio" name="star-cloudprnt-trigger" value="none" <?php checked(get_option('star-cloudprnt-trigger'), 'none', true) ?>>
			<label>Disable automatic printing</label><br>
		<?php
	}

	
	function star_cloudprnt_design_header()
	{
		?>
		<?php
	}

	function star_cloudPRNT_header_settings_display()
	{
		?>
			<label>Receipt Title</label><br/>
			<input type="text" name="star-cloudprnt-print-header-title" size=60 value="<?php echo get_option('star-cloudprnt-print-header-title') ?>">
		<?php
	}

	function star_cloudPRNT_item_settings_display()
	{
		?>
			<input type="checkbox" name="star-cloudprnt-print-items-print-id" value="on" <?php checked(get_option('star-cloudprnt-print-items-print-id'), 'on', true) ?> >
			<label>Include Item ID</label><br/>

			<input type="checkbox" name="star-cloudprnt-print-items-print-sku" value="on" <?php checked(get_option('star-cloudprnt-print-items-print-sku'), 'on', true) ?> >
			<label>Include Item SKU</label><br/>

			<br/>
			<label>Item list footer message</label><br/>
			<textarea type="text" name="star-cloudprnt-print-items-footer-message" cols=60 rows=4><?php echo get_option('star-cloudprnt-print-items-footer-message') ?></textarea>
		<?php
	}


	function star_cloudPRNT_order_fields_display()
	{
		?>
			<input type="checkbox" name="star-cloudprnt-print-order-meta-cb" value="on" <?php checked(get_option('star-cloudprnt-print-order-meta-cb'), 'on', true) ?> >
			<label>Print additional order meta-data, such as custom fields.</label>
			<div style="padding-left: 7mm">
				<input type="checkbox" name="star-cloudprnt-print-order-meta-reformat-keys" value="on" <?php checked(get_option('star-cloudprnt-print-order-meta-reformat-keys'), 'on', true) ?> >
				<label>Re-format key names (e.g. print "delivery_time" as "Delivery Time")</label><br/>
				<input type="checkbox" name="star-cloudprnt-print-order-meta-hidden" value="on" <?php checked(get_option('star-cloudprnt-print-order-meta-hidden'), 'on', true) ?> >
				<label>Include hidden fields</label><br/>
				<br/><label>Exclude items with these key names (',' separated)</label><br/>
				<input type="text" name="star-cloudprnt-print-order-meta-exclusions" size=60 value="<?php echo get_option('star-cloudprnt-print-order-meta-exclusions') ?>">
				
			</div>
		<?php
	}

	function star_cloudPRNT_print_logo_display()
	{
		$top_option_value = '01';
		$top_disabled = (get_option('star-cloudprnt-print-logo-top-cb') === 'on') ? "" : " disabled";
		if (get_option('star-cloudprnt-print-logo-top-input')) $top_option_value = esc_attr(get_option('star-cloudprnt-print-logo-top-input'));
		
		$end_option_value = '01';
		$end_disabled = (get_option('star-cloudprnt-print-logo-bottom-cb') === 'on') ? "" : " disabled";
		if (get_option('star-cloudprnt-print-logo-bottom-input')) $end_option_value = esc_attr(get_option('star-cloudprnt-print-logo-bottom-input'));
		
		?>
			<!--<label>Top of page:</label> -->
			<input type="checkbox" name="star-cloudprnt-print-logo-top-cb" <?= checked(get_option('star-cloudprnt-print-logo-top-cb'), 'on', false); ?> onclick='document.getElementById("star-cloudprnt-top-logo-input").disabled = !this.checked;'>
			<label>Print at top of page</label>
			<input type="text" style="width: 15mm;" id="star-cloudprnt-top-logo-input" name="star-cloudprnt-print-logo-top-input" value="<?= $top_option_value ?>" <?= $top_disabled ?> >
			<label>Keycode</label><br/>
			
			<!--<label>End of page:</label> -->
			<input type="checkbox" name="star-cloudprnt-print-logo-bottom-cb" <?= checked(get_option('star-cloudprnt-print-logo-bottom-cb'), 'on', false); ?> onclick='document.getElementById("star-cloudprnt-bottom-logo-input").disabled = !this.checked;'>
			<label>Print at end of page</label>
			<input type="text" style="width: 15mm;" id="star-cloudprnt-bottom-logo-input" name="star-cloudprnt-print-logo-bottom-input" value="<?= $end_option_value ?>" <?= $end_disabled ?> >
			<label>Keycode</label><br/>
			<p><strong>Note:</strong> logos should be written to printer FlashROM memory, using a suitable tool, such as the
		   StarPRNT Software for Windows, which can be downloaded from the <a href="http://starmicronics.com/support/Default.aspx">Star global downlad site</p>
			
		<?php
	}

	function star_cloudprnt_buzzer_display()
	{
		$repeat = get_option('star-cloudprnt-buzzer-repeat');
		$repeat = intval($repeat);
		if($repeat < 1) $repeat = 1;
		?>
			<input type="checkbox" name="star-cloudprnt-buzzer-start" value="on" <?php checked(get_option('star-cloudprnt-buzzer-start'), 'on', true) ?> >
			<label>Sound  external buzzer before printing</label><br/>
			<input type="checkbox" name="star-cloudprnt-buzzer-end" value="on" <?php checked(get_option('star-cloudprnt-buzzer-end'), 'on', true) ?> >
			<label>Sound  external buzzer after printing</label><br/>
			<label style="margin-top: 5px; display: inline-block;">Buzzer repeat count: </label>
			<input type="number" name="star-cloudprnt-buzzer-repeat" value="<?php echo $repeat; ?>" min="1" max="10" style="width: 60px;"><br/>
		<?php
	}

	function star_cloudprnt_show_settings_page()
	{

		// if (isset($_REQUEST['cron']) && $_REQUEST['cron'] == 1 )  {
		// 	star_cloudprnt_cron_check_printers();
		// }

		echo '<form method="post" action="options.php">';
        settings_errors();
		settings_fields("star_cloudprnt_setup_section");
		
		// Save button at the top
		submit_button('Save Changes', 'primary', 'submit', false);
		echo '<hr style="margin: 20px 0;">';
		
		do_settings_sections("star_cloudprnt_setup");
		
		// Save button at the bottom
		submit_button();
		echo '</form>';

		// ── Reset & Resync Printers button ────────────────────────────────
		// Outside the <form> so it does not interfere with settings saving.
		$reset_nonce = wp_create_nonce('star_cloudprnt_reset_printers_nonce');
		?>
		<hr style="margin: 30px 0 10px;">
		<div id="star-cloudprnt-reset-section" style="background:#fff8e1;border:1px solid #ffe082;border-radius:6px;padding:16px 20px;max-width:700px;">
			<h3 style="margin-top:0;color:#b45309;">🔄 Reset &amp; Risincronizza Stampanti</h3>
			<p style="margin:0 0 12px;color:#374151;">
				Usa questo bottone se le stampanti si sono disconnesse o riconnesse con nomi errati.<br>
				<strong>Cosa fa:</strong> ripristina il nome di ogni stampante al suo indirizzo MAC, rimuove i lock e azzera le selezioni, così puoi riassegnare ogni stampante al sito corretto dal menu a tendina.
			</p>
			<p style="margin:0 0 12px;color:#92400e;font-size:12px;">
				⚠️ Le code di stampa <strong>non</strong> vengono cancellate. Dopo il reset ricarica la pagina e riseleziona le stampanti dai dropdown.
			</p>
			<button type="button" id="star-cloudprnt-reset-btn" class="button button-secondary" style="background:#f59e0b;border-color:#d97706;color:#fff;font-weight:700;padding:8px 18px;font-size:13px;">
				🔄 Reset &amp; Risincronizza
			</button>
			<span id="star-cloudprnt-reset-status" style="margin-left:14px;font-size:13px;"></span>
		</div>
		<script type="text/javascript">
		(function($){
			$('#star-cloudprnt-reset-btn').on('click', function(){
				if (!confirm('Sei sicuro? Questa operazione:\n\n• Reimposta il nome di tutte le stampanti al MAC address\n• Cancella lock e selezioni salvate\n\nDovrai riselezionare le stampanti dopo il reset.')) return;

				var $btn    = $(this);
				var $status = $('#star-cloudprnt-reset-status');
				$btn.prop('disabled', true).text('⏳ Attendere...');
				$status.css('color','#6b7280').text('Elaborazione in corso...');

				$.post(ajaxurl, {
					action: 'star_cloudprnt_reset_printers',
					nonce:  '<?php echo $reset_nonce; ?>'
				}, function(response) {
					if (response.success) {
						$status.css('color','#16a34a').text('✅ ' + response.data.message);
						setTimeout(function(){ location.reload(); }, 2000);
					} else {
						var msg = response.data && response.data.message ? response.data.message : 'Errore sconosciuto';
						$status.css('color','#dc2626').text('❌ ' + msg);
						$btn.prop('disabled', false).text('🔄 Riprova');
					}
				}).fail(function(){
					$status.css('color','#dc2626').text('❌ Errore di rete. Riprova.');
					$btn.prop('disabled', false).text('🔄 Riprova');
				});
			});
		})(jQuery);
		</script>
		<?php
		// ── End Reset & Resync ─────────────────────────────────────────────
	}


	function star_cloudprnt_page()
	{
		?>
			<style>
				.star_cp_caution {
					color: orange;
					font-size: larger;
					font-weight: bolder;
				}, 
			</style>
		<?php

		$plugin_data = get_plugin_data(plugin_dir_path(__FILE__).star_cloudprnt_get_os_path('star-cloudprnt-for-woocommerce.php'));

		echo '<div class="wrap">';
			echo '<img src="'.plugins_url('images/logo.png', __FILE__).'">';
				echo '<h1>Star CloudPRNT for WooCommerce Settings</h1>';
				echo '<h2>Version ' . $plugin_data['Version'] . '</h2>';
				
				if (!star_cloudprnt_is_woo_activated())
				{
					echo '<br><span style="color: red"><span class="dashicons dashicons-no"></span>Warning: Unable to detect WooCommerce plugin.<br/>This can sometimes occur, if the plugin has been installed to a custom folder. If you are certain that WooCommerce is installed and functioning, then you can safely ignore this warning</span>';
				}
		
				if (isset($_GET['printersettings'])) 
				{
					if (isset($_GET['npn'])) star_cloudprnt_change_printer_name();
					else if (isset($_GET['cq'])) star_cloudprnt_clear_printer_queue();
					else if (isset($_GET['coh'])) star_cloudprnt_clear_order_history();
					else if (isset($_GET['dp'])) star_cloudprnt_delete_printer();
					else star_cloudprnt_show_printer_settings_page();
				}
				else star_cloudprnt_show_settings_page();
					
					
		echo '</div>';
	}
	
	function star_cloudprnt_create_settings_page()
	{
		add_action("admin_init", "star_cloudprnt_settings");
		add_action("admin_menu", "star_cloudprnt_menu_item");
	}

	// Handle POS order creation
	add_action('admin_post_star_cloudprnt_pos_create_order', 'star_cloudprnt_pos_create_order');
	function star_cloudprnt_pos_create_order(){
		if (!current_user_can('manage_options')) wp_die('Unauthorized');
		check_admin_referer('star_cloudprnt_pos_create_order');

		$customer_name = isset($_POST['customer_name']) ? sanitize_text_field($_POST['customer_name']) : '';
		$customer_phone = isset($_POST['customer_phone']) ? sanitize_text_field($_POST['customer_phone']) : '';
		$customer_email = isset($_POST['customer_email']) ? sanitize_email($_POST['customer_email']) : '';
		$customer_note = isset($_POST['customer_note']) ? sanitize_textarea_field($_POST['customer_note']) : '';
		$delivery_method = isset($_POST['delivery_method']) ? sanitize_text_field($_POST['delivery_method']) : 'pickup';
		$payment_method = isset($_POST['payment_method']) ? sanitize_text_field($_POST['payment_method']) : 'cod';
		$address_1 = isset($_POST['address_1']) ? sanitize_text_field($_POST['address_1']) : '';
		$city = isset($_POST['city']) ? sanitize_text_field($_POST['city']) : '';
		$postcode = isset($_POST['postcode']) ? sanitize_text_field($_POST['postcode']) : '';
		$items_json = isset($_POST['items_json']) ? wp_unslash($_POST['items_json']) : '[]';

		$items = json_decode($items_json, true);
		if (!is_array($items) || empty($items)) {
			wp_redirect(add_query_arg(array('page' => 'star-cloudprnt-pos', 'error' => 'no_items'), admin_url('options-general.php')));
			exit;
		}

		// Create order
		if (!class_exists('WC_Order')) wp_die('WooCommerce non attivo');
		$order = wc_create_order();

		foreach ($items as $item) {
			$pid = intval($item['product_id']);
			$qty = max(1, intval($item['quantity']));
			if ($pid > 0) {
				$product = wc_get_product($pid);
				if ($product) {
					$order->add_product($product, $qty);
				}
			}
		}

		// Customer data
		$billing = array(
			'first_name' => $customer_name,
			'phone' => $customer_phone,
			'email' => $customer_email,
			'address_1' => $address_1,
			'city' => $city,
			'postcode' => $postcode,
		);
		$shipping = array(
			'first_name' => $customer_name,
			'address_1' => $address_1,
			'city' => $city,
			'postcode' => $postcode,
		);
		$order->set_address($billing, 'billing');
		$order->set_address($shipping, 'shipping');

		// Delivery method: add shipping if delivery
		if ($delivery_method === 'delivery') {
			// Add flat shipping item (0 cost by default)
			$item = new WC_Order_Item_Shipping();
			$item->set_method_title('Consegna');
			$item->set_total(0);
			$order->add_item($item);
		}

		// Payment method
		$order->set_payment_method($payment_method);

		// Order note
		if (!empty($customer_note)) {
			$order->add_order_note($customer_note);
		}

		$order->calculate_totals();
		$order->update_status('processing', 'Ordine creato dal POS');

		// Trigger CloudPRNT printing
		$order_id = $order->get_id();
		if (function_exists('star_cloudprnt_trigger_print')) {
			star_cloudprnt_trigger_print($order_id);
			if (function_exists('star_cloudprnt_second_printer_trigger_print')) {
				star_cloudprnt_second_printer_trigger_print($order_id);
			}
		}

		wp_redirect(add_query_arg(array('page' => 'star-cloudprnt-pos', 'created' => $order_id), admin_url('options-general.php')));
		exit;
	}

	// POS page container for React application
	function star_cloudprnt_pos_page() {
		if (!current_user_can('edit_shop_orders')) { wp_die('Permessi insufficienti'); }
		echo '<div class="wrap"><h1>Call Center</h1>';
		// Root div consumed by React (nonce for REST auth)
		$nonce = wp_create_nonce('wp_rest');
		echo '<div id="fd-pos-root" data-nonce="' . esc_attr($nonce) . '"></div>';
		echo '</div>';
	}

	// Enqueue React build assets on POS page
	add_action('admin_enqueue_scripts', function($hook){
		if (!isset($_GET['page'])) return;
		if ($_GET['page'] !== 'fd-pos') return; // only POS page
		$dist = plugin_dir_path(__FILE__) . 'FOOD-DELIVERY-POS/admin-pos/dist/';
		if (!is_dir($dist)) {
			add_action('admin_notices', function(){ echo '<div class="notice notice-error"><p><strong>Food Delivery POS:</strong> build mancante. Esegui <code>npm install && npm run build</code> in admin-pos.</p></div>'; });
			return;
		}
		$jsFile = $dist . 'app.js';
		$cssFile = $dist . 'app.css';
		if (file_exists($jsFile)) {
			wp_enqueue_script('fd-pos-react', plugins_url('FOOD-DELIVERY-POS/admin-pos/dist/app.js', __FILE__), array(), filemtime($jsFile), true);
			$cfg = array(
				'restBase' => esc_url_raw(rest_url('fd-pos/v1/')),
				'currency' => get_woocommerce_currency(),
				'locale' => get_locale(),
				'nonce' => wp_create_nonce('wp_rest')
			);
			wp_add_inline_script('fd-pos-react', 'window.FD_POS_CFG=' . wp_json_encode($cfg) . ';', 'before');
		} else {
			add_action('admin_notices', function(){ echo '<div class="notice notice-warning"><p>File JS non trovato in dist (app.js). Esegui build.</p></div>'; });
		}
		if (file_exists($cssFile)) {
			wp_enqueue_style('fd-pos-react', plugins_url('FOOD-DELIVERY-POS/admin-pos/dist/app.css', __FILE__), array(), filemtime($cssFile));
		}
	});


	function star_cloudprnt_location_notes_display() {
		$value = get_option('star_cloudprnt_location_notes', '');
		?>
			<textarea name="star_cloudprnt_location_notes" rows="4" cols="50"><?php echo esc_textarea($value); ?></textarea>
			<p class="description">Add notes related to this location. This is for admin use only.</p>
		<?php
	}

	// Admin viewer for plugin logs and preserved spool copies
	function star_cloudprnt_view_logs_page()
	{
		if (!current_user_can('manage_options')) return;

		$logFile = rtrim(plugin_dir_path(__FILE__), '/\\') . DIRECTORY_SEPARATOR . 'logs' . DIRECTORY_SEPARATOR . 'star-cloudprnt.log';
		$spoolDir = rtrim(plugin_dir_path(__FILE__), '/\\') . DIRECTORY_SEPARATOR . 'logs' . DIRECTORY_SEPARATOR . 'spool_copies' . DIRECTORY_SEPARATOR;

		// Handle cache flush and log clear actions
		if (isset($_POST['star_cloudprnt_flush_cache'])) {
			check_admin_referer('star_cloudprnt_flush_cache');
			if (function_exists('opcache_reset')) {
				opcache_reset();
				echo '<div class="notice notice-success"><p>OPcache flushed successfully!</p></div>';
			} else {
				echo '<div class="notice notice-warning"><p>OPcache is not enabled on this server.</p></div>';
			}
		}

		if (isset($_POST['star_cloudprnt_clear_logs'])) {
			check_admin_referer('star_cloudprnt_clear_logs');
			$cleared = array();
			// Clear main log file
			if (file_exists($logFile)) {
				file_put_contents($logFile, '');
				$cleared[] = 'main log';
			}
			// Clear spool copies
			if (is_dir($spoolDir)) {
				$files = array_values(array_diff(scandir($spoolDir), array('.', '..')));
				foreach ($files as $f) {
					$path = $spoolDir . $f;
					if (is_file($path)) {
						unlink($path);
					}
				}
				if (!empty($files)) $cleared[] = count($files) . ' spool file(s)';
			}
			if (!empty($cleared)) {
				echo '<div class="notice notice-success"><p>Cleared: ' . implode(', ', $cleared) . '</p></div>';
			} else {
				echo '<div class="notice notice-info"><p>No logs to clear.</p></div>';
			}
		}

		echo '<div class="wrap">';
		echo '<h1>CloudPRNT Logs & Spool Copies</h1>';
		
		// Action buttons
		echo '<div style="margin: 20px 0;">';
		echo '<form method="post" style="display:inline-block;margin-right:10px;">';
		wp_nonce_field('star_cloudprnt_flush_cache');
		echo '<button type="submit" name="star_cloudprnt_flush_cache" class="button button-secondary">🔄 Flush OPcache</button>';
		echo '</form>';
		echo '<form method="post" style="display:inline-block;" onsubmit="return confirm(\'Are you sure you want to clear all logs and spool files? This cannot be undone.\');">';
		wp_nonce_field('star_cloudprnt_clear_logs');
		echo '<button type="submit" name="star_cloudprnt_clear_logs" class="button button-secondary">🗑️ Clear All Logs</button>';
		echo '</form>';
		echo '</div>';

		// Show spool files
		echo '<h2>Preserved spool copies</h2>';
		if (is_dir($spoolDir)) {
			$files = array_values(array_diff(scandir($spoolDir), array('.', '..')));
			if (empty($files)) {
				echo '<p>No preserved spool copies found.</p>';
			} else {
				echo '<ul>';
				foreach (array_reverse($files) as $f) {
					$safe = esc_html($f);
					$url = add_query_arg(array('page' => 'star-cloudprnt-logs', 'spool' => rawurlencode($f)));
					echo '<li><a href="' . esc_url($url) . '">' . $safe . '</a></li>';
				}
				echo '</ul>';
			}
		} else {
			echo '<p>No spool directory found.</p>';
		}

		// If a spool file was requested, show first 400 lines
		if (!empty($_GET['spool'])) {
			$requested = basename($_GET['spool']);
			$path = $spoolDir . $requested;
			echo '<h3>Spool: ' . esc_html($requested) . '</h3>';
			if (file_exists($path) && is_readable($path)) {
				echo '<pre style="background:#fff;padding:10px;border:1px solid #ccc;max-height:480px;overflow:auto;">';
				$lines = file($path);
				$lines = array_slice($lines, 0, 400);
				foreach ($lines as $line) echo esc_html($line);
				echo '</pre>';
			} else {
				echo '<p>Unable to read the spool file.</p>';
			}
		}

		echo '<h2>Plugin log (last 200 lines)</h2>';
		if (file_exists($logFile) && is_readable($logFile)) {
			$lines = file($logFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
			$tail = array_slice($lines, -200);
			echo '<pre style="background:#000;color:#0f0;padding:10px;border-radius:3px;max-height:480px;overflow:auto;">';
			foreach ($tail as $l) echo esc_html($l) . "\n";
			echo '</pre>';
		} else {
			echo '<p>No plugin log found. Enable debug logging on the plugin settings page to create logs.</p>';
		}

		echo '</div>';
	}

// ===== REST API endpoints for Call Center POS =====
add_action('rest_api_init', function () {
	// Customer search endpoint
	register_rest_route('fd-pos/v1', '/customers', array(
		'methods' => 'GET',
		'callback' => 'star_cloudprnt_pos_api_customers',
		'permission_callback' => function () { return current_user_can('manage_woocommerce'); },
		'args' => array(
			'search' => array('required' => true, 'type' => 'string'),
			'mode' => array('default' => 'name', 'enum' => array('name', 'phone', 'email'))
		)
	));
	// Product search endpoint
	register_rest_route('fd-pos/v1', '/products', array(
		'methods' => 'GET',
		'callback' => 'star_cloudprnt_pos_api_products',
		'permission_callback' => function () { return current_user_can('manage_woocommerce'); },
		'args' => array('search' => array('required' => true, 'type' => 'string'))
	));
	// Product add-ons endpoint
	register_rest_route('fd-pos/v1', '/product/(?P<id>\d+)/addons', array(
		'methods' => 'GET',
		'callback' => 'star_cloudprnt_pos_api_product_addons',
		'permission_callback' => function () { return current_user_can('manage_woocommerce'); }
	));
	// Create order endpoint for React POS
	register_rest_route('fd-pos/v1', '/create-order', array(
		'methods' => 'POST',
		'callback' => 'star_cloudprnt_fd_pos_rest_create_order',
		'permission_callback' => function(){ return current_user_can('edit_shop_orders'); }
	));
});

function star_cloudprnt_pos_api_customers($request) {
	$search = sanitize_text_field($request->get_param('search'));
	$mode = $request->get_param('mode');
	if (strlen($search) < 2) return new WP_REST_Response(array(), 200);

	$results = array();
	$args = array('role__in' => array('customer', 'subscriber', 'administrator'), 'number' => 15);

	if ($mode === 'phone') {
		$args['meta_query'] = array(
			'relation' => 'OR',
			array('key' => 'billing_phone', 'value' => $search, 'compare' => 'LIKE'),
			array('key' => 'shipping_phone', 'value' => $search, 'compare' => 'LIKE')
		);
	} elseif ($mode === 'email') {
		$args['search'] = '*' . esc_attr($search) . '*';
		$args['search_columns'] = array('user_email');
	} else {
		$args['search'] = '*' . esc_attr($search) . '*';
		$args['search_columns'] = array('display_name', 'user_login');
	}

	$users = get_users($args);
	foreach ($users as $user) {
		$billing_phone = get_user_meta($user->ID, 'billing_phone', true);
		$billing_email = !empty($user->user_email) ? $user->user_email : get_user_meta($user->ID, 'billing_email', true);
		$secondary = array_filter(array($billing_phone, $billing_email));
		$results[] = array(
			'id' => $user->ID,
			'name' => !empty($user->display_name) ? $user->display_name : $user->user_login,
			'label' => !empty($user->display_name) ? $user->display_name : $user->user_login,
			'phone' => $billing_phone,
			'email' => $billing_email,
			'address_1' => get_user_meta($user->ID, 'billing_address_1', true),
			'city' => get_user_meta($user->ID, 'billing_city', true),
			'postcode' => get_user_meta($user->ID, 'billing_postcode', true),
			'secondary' => implode(' • ', $secondary)
		);
	}
	return new WP_REST_Response($results, 200);
}

function star_cloudprnt_pos_api_products($request) {
	$search = sanitize_text_field($request->get_param('search'));
	if (strlen($search) < 2) return new WP_REST_Response(array(), 200);

	$args = array(
		'post_type' => 'product',
		'post_status' => 'publish',
		'posts_per_page' => 20,
		's' => $search
	);
	$query = new WP_Query($args);
	$results = array();

	if ($query->have_posts()) {
		while ($query->have_posts()) {
			$query->the_post();
			$product = wc_get_product(get_the_ID());
			if (!$product) continue;
			$price = (float) $product->get_price();
			$results[] = array(
				'id' => $product->get_id(),
				'name' => $product->get_name(),
				'price' => $price,
				'formatted_price' => wc_price($price),
				'type' => $product->get_type()
			);
		}
		wp_reset_postdata();
	}
	return new WP_REST_Response($results, 200);
}

function star_cloudprnt_pos_api_product_addons($request) {
	$product_id = (int) $request->get_param('id');
	$product = wc_get_product($product_id);
	if (!$product) return new WP_Error('not_found', 'Product not found', array('status' => 404));

	$addons = array();
	$product_addons = get_post_meta($product_id, '_product_addons', true);
	if (is_array($product_addons) && !empty($product_addons)) {
		foreach ($product_addons as $addon_group) {
			if (empty($addon_group['name']) || empty($addon_group['options'])) continue;
			$group = array(
				'name' => $addon_group['name'],
				'type' => isset($addon_group['type']) ? $addon_group['type'] : 'multiple_choice',
				'required' => !empty($addon_group['required']),
				'options' => array()
			);
			foreach ($addon_group['options'] as $option) {
				if (empty($option['label'])) continue;
				$price = isset($option['price']) ? (float) $option['price'] : 0;
				$group['options'][] = array(
					'label' => $option['label'],
					'price' => $price,
					'price_type' => isset($option['price_type']) ? $option['price_type'] : 'flat_fee'
				);
			}
			if (!empty($group['options'])) $addons[] = $group;
		}
	}
	return new WP_REST_Response($addons, 200);
}

// React POS create order handler
function star_cloudprnt_fd_pos_rest_create_order(WP_REST_Request $req) {
	$data = $req->get_json_params();
	$cart = isset($data['cart']) && is_array($data['cart']) ? $data['cart'] : array();
	if (empty($cart)) return new WP_REST_Response(array('success'=>false,'message'=>'Carrello vuoto'),400);
	if (!class_exists('WC_Order')) return new WP_REST_Response(array('success'=>false,'message'=>'WooCommerce non disponibile'),500);

	$order = wc_create_order();
	if (is_wp_error($order)) return new WP_REST_Response(array('success'=>false,'message'=>$order->get_error_message()),500);

	foreach ($cart as $line) {
		$pid = isset($line['id']) ? absint($line['id']) : 0;
		$qty = isset($line['qty']) ? max(1, absint($line['qty'])) : 1;
		if (!$pid) continue;
		$product = wc_get_product($pid);
		if ($product) $order->add_product($product, $qty);
	}

	$customer = isset($data['customer']) && is_array($data['customer']) ? $data['customer'] : array();
	$email = isset($customer['email']) ? sanitize_email($customer['email']) : '';
	$note = isset($customer['note']) ? sanitize_textarea_field($customer['note']) : '';
	if ($email) $order->set_billing_email($email);
	if ($note) $order->add_order_note('Nota POS: ' . $note);

	$flow = isset($data['flow']) && is_array($data['flow']) ? $data['flow'] : array();
	$shipping_mode = isset($flow['shipping']) ? sanitize_text_field($flow['shipping']) : '';
	$payment_mode = isset($flow['payment']) ? sanitize_text_field($flow['payment']) : '';

	if ($shipping_mode === 'delivery') {
		$item = new WC_Order_Item_Shipping();
		$item->set_method_title('Consegna');
		$item->set_total(0);
		$order->add_item($item);
	}

	$available = WC()->payment_gateways ? WC()->payment_gateways->get_available_payment_gateways() : array();
	$chosen = 'cod';
	if ($payment_mode === 'card' && isset($available['stripe'])) $chosen = 'stripe';
	if ($payment_mode === 'online' && isset($available['paypal'])) $chosen = 'paypal';
	if (!isset($available[$chosen]) && isset($available['cod'])) $chosen = 'cod';
	$order->set_payment_method($chosen);

	$order->calculate_totals();
	$order->set_status('processing','Creato da React POS');
	$order_id = $order->save();

	if (function_exists('star_cloudprnt_trigger_print')) {
		star_cloudprnt_trigger_print($order_id);
		if (function_exists('star_cloudprnt_second_printer_trigger_print')) {
			star_cloudprnt_second_printer_trigger_print($order_id);
		}
	}
	if (function_exists('star_cloudprnt_fd_pos_should_log') && star_cloudprnt_fd_pos_should_log()) {
		star_cloudprnt_log('[FDCC] Ordine POS #' . $order_id . ' creato via React endpoint');
	}

	return new WP_REST_Response(array('success'=>true,'order_id'=>$order_id),200);
}
