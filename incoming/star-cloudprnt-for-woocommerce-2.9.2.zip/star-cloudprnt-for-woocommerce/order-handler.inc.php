<?php
  /*
   * Support functions for order-handler.php, anything not related to actually rendering a print job is here
   *
   */

  mb_internal_encoding('utf-8');
	mb_regex_encoding("UTF-8");
	
  function star_mb_str_pad($str, $pad_len, $pad_str = ' ', $dir = STR_PAD_RIGHT) {
    $str_len = mb_strlen($str);
    $pad_str_len = mb_strlen($pad_str);
    if (!$str_len && ($dir == STR_PAD_RIGHT || $dir == STR_PAD_LEFT)) {
        $str_len = 1; // @debug
    }
    if (!$pad_len || !$pad_str_len || $pad_len <= $str_len) {
        return $str;
    }
   
    $result = null;
    $repeat = ceil($str_len - $pad_str_len + $pad_len);
    if ($dir == STR_PAD_RIGHT) {
        $result = $str . str_repeat($pad_str, $repeat);
        $result = mb_substr($result, 0, $pad_len);
    } else if ($dir == STR_PAD_LEFT) {
        $result = str_repeat($pad_str, $repeat) . $str;
        $result = mb_substr($result, -$pad_len);
    } else if ($dir == STR_PAD_BOTH) {
        $length = ($pad_len - $str_len) / 2;
        $repeat = ceil($length / $pad_str_len);
        $result = mb_substr(str_repeat($pad_str, $repeat), 0, floor($length))
                  	. $str
                    . mb_substr(str_repeat($pad_str, $repeat), 0, ceil($length));
    }
   
    return $result;
	}


  // Pad strings with spaces so that they column align across the indicated $max_chars characters
  // Note: recommended for 2 column layout only, since column padding is recalculated per line.
  // Note1: This uses mb_strwidth to attampt to handle both full and half width characters, but
  //        results are not always consistent, so printing full-width (Japanese, Chinese etc.)
  //        is probably better done without column layouts for now - to be investigated.
  function star_cloudprnt_get_column_separated_data($columns, $max_chars)
	{
		$total_columns = count($columns);
		
		if ($total_columns == 0) return "";
		if ($total_columns == 1) return $columns[0];
		if ($total_columns == 2)
		{
			//$total_characters = strlen($columns[0])+strlen($columns[1]);
			$total_characters = mb_strwidth($columns[0]) + mb_strwidth($columns[1]);
			$total_whitespace = $max_chars - $total_characters;
			if ($total_whitespace < 0) return "";
			return $columns[0].str_repeat(" ", $total_whitespace).$columns[1];
		}
		
		$total_characters = 0;
		foreach ($columns as $column)
		{
			$total_characters += strlen($column);
		}
		$total_whitespace = $max_chars - $total_characters;
		if ($total_whitespace < 0) return "";
		$total_spaces = $total_columns-1;
		$space_width = floor($total_whitespace / $total_spaces);
		$result = $columns[0].str_repeat(" ", $space_width);
		for ($i = 1; $i < ($total_columns-1); $i++)
		{
			$result .= $columns[$i].str_repeat(" ", $space_width);
		}
		$result .= $columns[$total_columns-1];
		
		return $result;
  }
  
  // Retrieve order notes text
  function star_cloudprnt_get_wc_order_notes($order_id){
		//make sure it's a number
		$order_id = intval($order_id);
		//get the post 
		$post = get_post($order_id);
		//if there's no post, return as error
		if (!$post) return false;

		return $post->post_excerpt;
	}

  // Return the site currency symbol, converted to the printers target encoding
	function star_cloudprnt_get_codepage_currency_symbol()
	{
		$encoding = get_option('star-cloudprnt-printer-encoding-select');
		$symbol = get_woocommerce_currency_symbol();

		return star_cloudprnt_filter_html($symbol);
	}
	
	// Format a float value as a currency string
	function star_cloudprnt_format_currency($value)
	{
		if(!empty($value)){
			return star_cloudprnt_get_codepage_currency_symbol() . number_format(floatval($value), 2, '.', '');
		}else{
			return star_cloudprnt_get_codepage_currency_symbol() .'0.00';
		}
		
	}

  // Convert html data to printer ready text. Note that this preserves no formatting, all tags are stripped
  // and newlines removed, it is intended for printing field names/values.
	function star_cloudprnt_filter_html($data)
	{
		/* Filter known html key words, convert to printer appropriate commands and encoding */
		if(!empty($data) && !is_array($data)){
	
			$encoding = get_option('star-cloudprnt-printer-encoding-select');
			$phpenc = "UTF-8";
			if($encoding === "1252")
				$phpenc = "cp1252";

			$data = html_entity_decode($data, ENT_QUOTES, "UTF-8");

			if($phpenc !== "UFT-8")
				$data = mb_convert_encoding($data, $phpenc, "UTF-8");

			$data = str_replace(array("\r", "\n"), '', $data);
		}	
		// Strip newlines

		return strip_tags($data);
	}

  // Get printer compatibility information and generate a print job
	function star_cloudprnt_trigger_print($order_id)
	{
		$extension = STAR_CLOUDPRNT_SPOOL_FILE_FORMAT;	
		
		$selectedPrinterMac = "";
		$selectedPrinter = array();
		$printerList = star_cloudprnt_get_printer_list();

		if (!empty($printerList))
		{
			// Match case-insensitively, and against the printer's MAC as well as its
			// display name. The stored option holds a MAC on every site here, while
			// $printer['name'] is a MUTABLE display name - when those names were reset
			// to the MAC, every site still holding a friendly name stopped matching.
			$wantedPrinter = star_cloudprnt_normalize_mac(get_option('star-cloudprnt-printer-select'));
			if ($wantedPrinter !== '')
			{
				foreach ($printerList as $listMac => $printer)
				{
					$candidates = array(
						star_cloudprnt_normalize_mac($listMac),
						star_cloudprnt_normalize_mac(isset($printer['name']) ? $printer['name'] : ''),
						star_cloudprnt_normalize_mac(isset($printer['printerMAC']) ? $printer['printerMAC'] : ''),
					);
					if (in_array($wantedPrinter, $candidates, true))
					{
						$selectedPrinter = $printer;
						$selectedPrinterMac = $printer['printerMAC'];
						break;
					}
				}
			}

			// NEVER fall back to another printer. This used to be
			//     if (sizeof($selectedPrinter) == 0) $selectedPrinter = reset($printerList);
			// and star_cloudprnt_get_printer_list() globs the NETWORK-WIDE printer
			// directory, so any subsite whose binding failed to match silently printed
			// on the first printer of the whole network - i.e. another restaurant's
			// counter. Failing loudly is always correct here: a missing receipt is
			// recoverable, a receipt printed at the wrong shop is not.
			if (sizeof($selectedPrinter) == 0)
			{
				if (function_exists('star_cloudprnt_internal_log')) {
					star_cloudprnt_internal_log(
						"ABORT print for order $order_id: no printer matches this site's setting "
						. "('" . get_option('star-cloudprnt-printer-select') . "'). Refusing to print "
						. "rather than sending it to another restaurant's printer. Check "
						. "WooCommerce > CloudPRNT printer selection for blog "
						. (function_exists('get_current_blog_id') ? get_current_blog_id() : '?') . ".",
						'ERROR'
					);
				}
				return;
			}

			// LAYER 3 enforcement. Even with a matching binding, never write into a
			// printer's queue unless this site owns that printer. The queue directory
			// is network-wide and keyed only by MAC, so without this a mis-set option
			// is enough to drop one restaurant's receipt on another's counter.
			// Unclaimed printers are claimed here on first use, so existing installs
			// keep working and the registry fills itself in with no migration.
			if (function_exists('star_cloudprnt_claim_printer')
				&& !star_cloudprnt_claim_printer($selectedPrinterMac))
			{
				if (function_exists('star_cloudprnt_internal_log')) {
					star_cloudprnt_internal_log(
						"ABORT print for order $order_id: printer $selectedPrinterMac belongs to "
						. star_cloudprnt_owner_label(star_cloudprnt_get_printer_owner($selectedPrinterMac))
						. ", not to blog " . star_cloudprnt_this_blog_id()
						. ". Refusing to print on another site's printer.",
						'ERROR'
					);
				}
				return;
			}

			/* Decide best printer emulation and print width as far as possible
			   NOTE: this is not the ideal way, but suits the existing
			   code structure. Will be reviewed.
			   */
			
			$encodings = $selectedPrinter['Encodings'];
			$columns = STAR_CLOUDPRNT_MAX_CHARACTERS_THREE_INCH;
			if (strpos($encodings, "application/vnd.star.line;") !== false) {
				/* There is no guarantee that printers will always return zero spacing between
				   the encoding name and separating semi-colon. But, definitely the HIX does, socket_accept
				   this is enough to ensure that thermal print mode is always used on HIX printers
				   with pre 1.5 firmware. This matches older plugin behaviour and therefore
				   avoids breaking customer sites.
				*/
				$extension = "slt";
			} else if (strpos($encodings, "application/vnd.star.linematrix") !== false) {
				$extension = "slm";
				$columns = STAR_CLOUDPRNT_MAX_CHARACTERS_DOT_THREE_INCH;
			} else if (strpos($encodings, "application/vnd.star.line") !== false) {
				// a second check for Line mode - just in case the above one didn't catch item
				// and after the "linemodematrix" check, to avoid a false match.
				$extension = "slt";
			} else if (strpos($encodings, 'application/vnd.star.starprnt') !== false) {
				$extension = "spt";
			} else if (strpos($encodings, "text/plain") !== false) {
				$extension = "txt";
			} 
			
			if ($selectedPrinter['ClientType'] == "Star mC-Print2") {
				$columns = STAR_CLOUDPRNT_MAX_CHARACTERS_TWO_INCH;
			}
			
			$selectedPrinter['format'] = $extension;
			$selectedPrinter['columns'] = $columns;
			
			$file = STAR_CLOUDPRNT_PRINTER_PENDING_SAVE_PATH.star_cloudprnt_get_os_path("/order_".$order_id."_".time().".".$extension);
			// echo "<pre>".print_r($selectedPrinter, true)."</pre>";
			// die;
			if ($selectedPrinter !== "") star_cloudprnt_print_order_summary($selectedPrinter, $file, $order_id);
		}
	}
    
    function star_cloudprnt_second_printer_trigger_print($order_id)
	{
		$extension = STAR_CLOUDPRNT_SPOOL_FILE_FORMAT;	
		
		$selectedPrinterMac = "";
		$selectedPrinter = array();
		$printerList = star_cloudprnt_get_printer_list();
		if (!empty($printerList)){
			$select_custom_printer = get_option('star-cloudprnt-printer-select_cus1');
			
			// Same case-insensitive MAC-or-name matching as the primary printer above.
			// This path already fails safe (returns without printing when nothing
			// matches), so it only needed the matching fixed, not the fallback removed.
			$wantedSecondary = star_cloudprnt_normalize_mac($select_custom_printer);
			if ($wantedSecondary !== '') {
				foreach ($printerList as $listMac => $printer){
					$candidates = array(
						star_cloudprnt_normalize_mac($listMac),
						star_cloudprnt_normalize_mac(isset($printer['name']) ? $printer['name'] : ''),
						star_cloudprnt_normalize_mac(isset($printer['printerMAC']) ? $printer['printerMAC'] : ''),
					);
					if (in_array($wantedSecondary, $candidates, true)){
						$selectedPrinter = $printer;
						$selectedPrinterMac = $printer['printerMAC'];
						break;
					}
				}
			}

			if ($selectedPrinter == '' ) {
				return;
			}

			// LAYER 3 enforcement for the secondary printer, same rule as the primary.
			if (function_exists('star_cloudprnt_claim_printer')
				&& !star_cloudprnt_claim_printer($selectedPrinterMac))
			{
				if (function_exists('star_cloudprnt_internal_log')) {
					star_cloudprnt_internal_log(
						"ABORT secondary print for order $order_id: printer $selectedPrinterMac belongs to "
						. star_cloudprnt_owner_label(star_cloudprnt_get_printer_owner($selectedPrinterMac))
						. ", not to blog " . star_cloudprnt_this_blog_id() . ".",
						'ERROR'
					);
				}
				return;
			}
      
			/* Decide best printer emulation and print width as far as possible
			   NOTE: this is not the ideal way, but suits the existing
			   code structure. Will be reviewed.
			   */
			
			$encodings = $selectedPrinter['Encodings'];
			$columns = STAR_CLOUDPRNT_MAX_CHARACTERS_THREE_INCH;
			if (strpos($encodings, "application/vnd.star.line;") !== false) {
				/* There is no guarantee that printers will always return zero spacing between
				   the encoding name and separating semi-colon. But, definitely the HIX does, socket_accept
				   this is enough to ensure that thermal print mode is always used on HIX printers
				   with pre 1.5 firmware. This matches older plugin behaviour and therefore
				   avoids breaking customer sites.
				*/
				$extension = "slt";
			} else if (strpos($encodings, "application/vnd.star.linematrix") !== false) {
				$extension = "slm";
				$columns = STAR_CLOUDPRNT_MAX_CHARACTERS_DOT_THREE_INCH;
			} else if (strpos($encodings, "application/vnd.star.line") !== false) {
				// a second check for Line mode - just in case the above one didn't catch item
				// and after the "linemodematrix" check, to avoid a false match.
				$extension = "slt";
			} else if (strpos($encodings, 'application/vnd.star.starprnt') !== false) {
				$extension = "spt";
			} else if (strpos($encodings, "text/plain") !== false) {
				$extension = "txt";
			} 
			
			if ($selectedPrinter['ClientType'] == "Star mC-Print2") {
				$columns = STAR_CLOUDPRNT_MAX_CHARACTERS_TWO_INCH;
			}
			
			$selectedPrinter['format'] = $extension;
			$selectedPrinter['columns'] = $columns;
			
			$file = STAR_CLOUDPRNT_PRINTER_PENDING_SAVE_PATH.star_cloudprnt_get_os_path("/order_".$order_id."_".time().".".$extension);
			// echo "<pre>".print_r($selectedPrinter, true)."</pre>";
			// die;
			if ($selectedPrinter !== "") star_cloudprnt_print_order_summary($selectedPrinter, $file, $order_id);
		}
	}
	
	
	// Insert the "Reprint vis Star CloudPRNT" order action to the list
	function star_cloudprnt_order_reprint_action( $actions ) {
		global $theorder;

		$actions['star_cloudprnt_reprint_action'] = __( 'Print via Star CloudPRNT', 'my-textdomain' );

		return $actions;
	}

	// Handle print requests issues with WC_Order object (used for the reprinting order action)
	function star_cloudprnt_reprint($order)
	{
		star_cloudprnt_trigger_print($order->get_id());
	}

	

	function add_star_cloudprnt_panel() {

		// $site_id = get_current_blog_id();
		// $allow_array = array(7 );
		// $process = false;
		// if( in_array( $site_id, $allow_array) ){
		// 	$process = true;
		// }
		
		// if($process === false )
		// 	return;

		if (selected( get_option('star-cloudprnt-select'), "enable", false) !== ""){

			$post_id = $_REQUEST["post"] ?? $_REQUEST["id"] ?? 0;
			?>
			<script type="text/javascript">
				function star_cloudprnt_trigger($) {
						var data = {
							'action': 'star_cloudprnt_reprint_action',
							'order_id': '<?php echo $post_id; ?>'
						};

						jQuery.post(ajaxurl, data, function(response) {
							//alert('Got this from the server: ' + response);
							jQuery("#star_cp_job_sent").show();
							setTimeout(() => {
								jQuery("#star_cp_job_sent").hide();
							}, 2000);
						});
					} 
				jQuery(document).ready(function($) {
					var starCloudPrntDiv = `
						<div id="woocommerce-order-star-cloudprnt" class="postbox">
							<div class="postbox-header">
								<h2 class="hndle ui-sortable-handle">Star CloudPRNT</h2>
								<div class="handle-actions hide-if-no-js">
									<button type="button" class="handle-order-higher" aria-disabled="false" aria-describedby="woocommerce-order-star-cloudprnt-handle-order-higher-description">
										<span class="screen-reader-text">Sposta in alto</span>
										<span class="order-higher-indicator" aria-hidden="true"></span>
									</button>
									<span class="hidden" id="woocommerce-order-star-cloudprnt-handle-order-higher-description">Sposta in su il riquadro Star CloudPRNT</span>
									<button type="button" class="handle-order-lower" aria-disabled="false" aria-describedby="woocommerce-order-star-cloudprnt-handle-order-lower-description">
										<span class="screen-reader-text">Sposta in basso</span>
										<span class="order-lower-indicator" aria-hidden="true"></span>
									</button>
									<span class="hidden" id="woocommerce-order-star-cloudprnt-handle-order-lower-description">Sposta in giù il riquadro Star CloudPRNT</span>
									<button type="button" class="handlediv" aria-expanded="true">
										<span class="screen-reader-text">Attiva/disattiva il pannello: Star CloudPRNT</span>
										<span class="toggle-indicator" aria-hidden="true"></span>
									</button>
								</div>
							</div>
							<div class="inside cus">
								<a href="javascript: star_cloudprnt_trigger();">
									<span><span class="dashicons dashicons-printer"></span> Print with Star CloudPRNT</span>
								</a>
								<span id="star_cp_job_sent" style="display:none">
									<span class="dashicons dashicons-yes"></span>
								</span>
							</div>
						</div>
					`;
		
					// Append after WooCommerce Order Actions
					$('#woocommerce-order-actions').after(starCloudPrntDiv);
				});
			</script>
			<?php
		}
		
	}
	add_action('admin_footer', 'add_star_cloudprnt_panel');

	

	

	// Register a meta box on the edit order sidebar
	function star_cloudprnt_order_meta_boxes()
	{ 
       
            add_meta_box(
                'woocommerce-order-star-cloudprnt',
                __( 'Star CloudPRNT' ),
                'star_cloudprnt_order_meta_box_content',
                'shop_order',
                'side',
                'default'
            );
			 

	}

	 


	// Render the sidebar metabox on the Edit Order page
	function star_cloudprnt_order_meta_box_content() {?>

			<a href="javascript: star_cloudprnt_trigger();"><span><span class="dashicons dashicons-printer"></span> Print with Star CloudPRNT</span></a>
      <span id="star_cp_job_sent" style="display:none"><span class="dashicons dashicons-yes"></span></span>

		<?php
	}

	// Handle the ajax reprint action
	function star_cloudprnt_reprint_button_callback()
	{
		star_cloudprnt_trigger_print($_POST["order_id"]);
		wp_die();
	}

	// -----------------------------------------------------------------------
	// Bulk Print – WooCommerce Orders List
	// -----------------------------------------------------------------------

	/**
	 * Register the "Print via Star CloudPRNT" bulk action in the orders list dropdown.
	 * Supports both HPOS (woocommerce_page_wc-orders) and legacy (edit-shop_order).
	 */
	function star_cloudprnt_register_bulk_action( $actions ) {
		$actions['star_cloudprnt_bulk_print'] = __( 'Print via Star CloudPRNT', 'star-cloudprnt' );
		return $actions;
	}

	/**
	 * Handle the bulk print action when submitted from the orders list.
	 *
	 * @param string $redirect_to The redirect URL after processing.
	 * @param string $action      The action being taken.
	 * @param array  $order_ids   The IDs of the selected orders.
	 * @return string Modified redirect URL with result query args.
	 */
	function star_cloudprnt_handle_bulk_print( $redirect_to, $action, $order_ids ) {
		if ( $action !== 'star_cloudprnt_bulk_print' ) {
			return $redirect_to;
		}

		// Capability check
		if ( ! current_user_can( 'edit_shop_orders' ) ) {
			return $redirect_to;
		}

		$printed = 0;
		foreach ( $order_ids as $order_id ) {
			$order_id = absint( $order_id );
			if ( ! $order_id ) continue;

			// Primary printer
			do_action( 'star_cloudprnt_primary_trigger_note', $order_id );
			star_cloudprnt_trigger_print( $order_id );

			// Secondary printer
			do_action( 'star_cloudprnt_secondary_trigger_note', $order_id );
			star_cloudprnt_second_printer_trigger_print( $order_id );

			$printed++;
		}

		if ( function_exists( 'star_cloudprnt_log' ) ) {
			star_cloudprnt_log( 'Bulk print: ' . $printed . ' orders sent to printer.', 'INFO' );
		}

		return add_query_arg( 'star_cloudprnt_bulk_printed', $printed, $redirect_to );
	}

	/**
	 * Display an admin notice after bulk printing completes.
	 */
	function star_cloudprnt_bulk_print_admin_notice() {
		if ( empty( $_REQUEST['star_cloudprnt_bulk_printed'] ) ) return;

		$count = absint( $_REQUEST['star_cloudprnt_bulk_printed'] );
		printf(
			'<div class="notice notice-success is-dismissible"><p>' .
			/* translators: %d = number of orders printed */
			esc_html( _n(
				'%d order sent to Star CloudPRNT printer.',
				'%d orders sent to Star CloudPRNT printer.',
				$count,
				'star-cloudprnt'
			) ) . '</p></div>',
			$count
		);
	}

	/**
	 * AJAX handler for bulk printing from the orders list.
	 * Accepts a JSON body with { order_ids: [1,2,3] }.
	 */
	function star_cloudprnt_ajax_bulk_print() {
		// Verify nonce
		check_ajax_referer( 'star_cloudprnt_bulk_print_nonce', 'nonce' );

		if ( ! current_user_can( 'edit_shop_orders' ) ) {
			wp_send_json_error( array( 'message' => 'Unauthorized' ), 403 );
		}

		$order_ids = isset( $_POST['order_ids'] ) ? array_map( 'absint', (array) $_POST['order_ids'] ) : array();
		$order_ids = array_filter( $order_ids );

		if ( empty( $order_ids ) ) {
			wp_send_json_error( array( 'message' => 'No orders selected.' ), 400 );
		}

		$printed = 0;
		foreach ( $order_ids as $order_id ) {
			do_action( 'star_cloudprnt_primary_trigger_note', $order_id );
			star_cloudprnt_trigger_print( $order_id );

			do_action( 'star_cloudprnt_secondary_trigger_note', $order_id );
			star_cloudprnt_second_printer_trigger_print( $order_id );

			$printed++;
		}

		if ( function_exists( 'star_cloudprnt_log' ) ) {
			star_cloudprnt_log( 'AJAX bulk print: ' . $printed . ' orders sent to printer.', 'INFO' );
		}

		wp_send_json_success( array(
			'printed' => $printed,
			'message' => sprintf( _n( '%d order sent to printer.', '%d orders sent to printer.', $printed, 'star-cloudprnt' ), $printed ),
		) );
	}

	/**
	 * Enqueue inline JS on the WooCommerce orders list page that adds a
	 * "🖨️ Print Selected" button next to the bulk actions dropdown.
	 */
	function star_cloudprnt_bulk_print_button_script() {
		$screen = get_current_screen();
		if ( ! $screen ) return;

		// Match both HPOS and legacy order list screens
		$valid_screens = array(
			'edit-shop_order',
			'woocommerce_page_wc-orders',
		);
		if ( ! in_array( $screen->id, $valid_screens, true ) ) return;

		$nonce = wp_create_nonce( 'star_cloudprnt_bulk_print_nonce' );
		?>
		<style>
			#star-cloudprnt-bulk-print-btn {
				margin-left: 8px;
				background: #2e7d32;
				color: #fff;
				border-color: #1b5e20;
				box-shadow: 0 1px 0 #1b5e20;
				text-shadow: 0 -1px 1px #1b5e20, 1px 0 1px #1b5e20, 0 1px 1px #1b5e20, -1px 0 1px #1b5e20;
				cursor: pointer;
				transition: background 0.2s ease;
			}
			#star-cloudprnt-bulk-print-btn:hover {
				background: #388e3c;
				border-color: #2e7d32;
			}
			#star-cloudprnt-bulk-print-btn .dashicons {
				font-size: 16px;
				width: 16px;
				height: 16px;
				vertical-align: text-bottom;
				margin-right: 4px;
			}
			#star-cloudprnt-bulk-print-btn:disabled {
				opacity: 0.6;
				cursor: not-allowed;
			}
		</style>
		<script type="text/javascript">
		jQuery(document).ready(function($) {
			// Insert the print button after the main "Apply" button
			var $applyBtn = $('.bulkactions input[type="submit"]').first();
			if ($applyBtn.length) {
				$applyBtn.after(
					'<button type="button" id="star-cloudprnt-bulk-print-btn" class="button">' +
					'<span class="dashicons dashicons-printer"></span> Print Selected' +
					'</button>'
				);
			}

			$('#star-cloudprnt-bulk-print-btn').on('click', function(e) {
				e.preventDefault();
				var $btn = $(this);

				// Collect checked order IDs (both HPOS and legacy selectors)
				var ids = [];
				$('input[name="id[]"]:checked, input[name="post[]"]:checked').each(function() {
					ids.push( parseInt($(this).val(), 10) );
				});

				if (ids.length === 0) {
					alert('<?php echo esc_js( __( 'Please select at least one order to print.', 'star-cloudprnt' ) ); ?>');
					return;
				}

				if (!confirm('<?php echo esc_js( __( 'Send the selected orders to Star CloudPRNT printer?', 'star-cloudprnt' ) ); ?> (' + ids.length + ')')) {
					return;
				}

				$btn.prop('disabled', true).text('Printing…');

				$.post(ajaxurl, {
					action: 'star_cloudprnt_ajax_bulk_print',
					nonce:  '<?php echo esc_js( $nonce ); ?>',
					order_ids: ids
				}, function(response) {
					if (response.success) {
						$btn.html('<span class="dashicons dashicons-yes"></span> ' + response.data.message);
						setTimeout(function() {
							$btn.prop('disabled', false)
							    .html('<span class="dashicons dashicons-printer"></span> Print Selected');
						}, 3000);
					} else {
						alert(response.data && response.data.message ? response.data.message : 'Error');
						$btn.prop('disabled', false)
						    .html('<span class="dashicons dashicons-printer"></span> Print Selected');
					}
				}).fail(function() {
					alert('Request failed. Please try again.');
					$btn.prop('disabled', false)
					    .html('<span class="dashicons dashicons-printer"></span> Print Selected');
				});
			});
		});
		</script>
		<?php
	}

  // Register necessary actions for triggering an order print
	function star_cloudprnt_setup_order_handler(){
		
		if (selected(get_option('star-cloudprnt-select'), "enable", false) !== "") {

			// Add reprint order action
			add_action( 'woocommerce_order_actions', 'star_cloudprnt_order_reprint_action' );

			// Register handler for ajax reprint request action (used by the "Print with Star CloudPRNT" button in the sidebar metabox)
			add_action( 'wp_ajax_star_cloudprnt_reprint_action', 'star_cloudprnt_reprint_button_callback' );

			// Register a sidebar metabox to be displayed on the Edit Order page, used to host a "print" button.
			//add_action( 'add_meta_boxes_shop_order', 'star_cloudprnt_order_meta_boxes' );


			// Register handler for the order action reprint request
			add_action('woocommerce_order_action_star_cloudprnt_reprint_action', 'star_cloudprnt_reprint', 1, 1 );

			// ---- Bulk Print: register action in both HPOS and legacy order list dropdowns ----
			add_filter( 'bulk_actions-woocommerce_page_wc-orders', 'star_cloudprnt_register_bulk_action' );
			add_filter( 'bulk_actions-edit-shop_order', 'star_cloudprnt_register_bulk_action' );

			// Handle the bulk action
			add_filter( 'handle_bulk_actions-woocommerce_page_wc-orders', 'star_cloudprnt_handle_bulk_print', 10, 3 );
			add_filter( 'handle_bulk_actions-edit-shop_order', 'star_cloudprnt_handle_bulk_print', 10, 3 );

			// Admin notice after bulk print
			add_action( 'admin_notices', 'star_cloudprnt_bulk_print_admin_notice' );

			// AJAX endpoint for the "Print Selected" button
			add_action( 'wp_ajax_star_cloudprnt_ajax_bulk_print', 'star_cloudprnt_ajax_bulk_print' );

			// Enqueue the inline script/button on orders list page
			add_action( 'admin_footer', 'star_cloudprnt_bulk_print_button_script' );
			
			
			// Wrapper for primary printer
			add_action('star_cloudprnt_primary_trigger_note', function($order_id) {
				if ($order = wc_get_order($order_id)) {
					$current_selected = get_option('star-cloudprnt-printer-select', '');
					$order->add_order_note('Star CloudPRNT: Primary print trigger executed. MAC Address: '.$current_selected);
				}
			}, 1, 1);

			// Wrapper for secondary printer
			add_action('star_cloudprnt_secondary_trigger_note', function($order_id) {
				if ($order = wc_get_order($order_id)) {
					$current_selected_cus = get_option('star-cloudprnt-printer-select_cus1', '');
					$order->add_order_note('Star CloudPRNT: Secondary print trigger executed. MAC Address: '.$current_selected_cus);
				}
			}, 1, 1);


			// Register the automatic order printing trigger, depending on config
			$trigger = get_option('star-cloudprnt-trigger');
			// if($trigger === 'thankyou') {
			// 	add_action('woocommerce_thankyou', 'star_cloudprnt_trigger_print', 1, 1);
			// 	add_action('woocommerce_thankyou', 'star_cloudprnt_second_printer_trigger_print', 1, 1);
			// } elseif ($trigger === 'status_processing') {
			// 	add_action('woocommerce_order_status_processing', 'star_cloudprnt_trigger_print', 1, 1);
			// 	add_action('woocommerce_order_status_processing', 'star_cloudprnt_second_printer_trigger_print', 1, 1);
			// } elseif ($trigger === 'status_completed') {
			// 	add_action('woocommerce_order_status_completed', 'star_cloudprnt_trigger_print', 1, 1);
			// 	add_action('woocommerce_order_status_completed', 'star_cloudprnt_second_printer_trigger_print', 1, 1);
			// } elseif ($trigger == "status_on-hold") {
			// 	add_action('woocommerce_order_status_on-hold', 'star_cloudprnt_trigger_print', 1, 1);
			// 	add_action('woocommerce_order_status_on-hold', 'star_cloudprnt_second_printer_trigger_print', 1, 1);
			// }

			if ($trigger === 'thankyou') {

				add_action('woocommerce_thankyou', function($order_id){
					do_action('star_cloudprnt_primary_trigger_note', $order_id);
					star_cloudprnt_trigger_print($order_id);
				}, 1, 1);

				add_action('woocommerce_thankyou', function($order_id){
					do_action('star_cloudprnt_secondary_trigger_note', $order_id);
					star_cloudprnt_second_printer_trigger_print($order_id);
				}, 1, 1);

			} elseif ($trigger === 'status_processing') {

				add_action('woocommerce_order_status_processing', function($order_id){
					do_action('star_cloudprnt_primary_trigger_note', $order_id);
					star_cloudprnt_trigger_print($order_id);
				}, 1, 1);

				add_action('woocommerce_order_status_processing', function($order_id){
					do_action('star_cloudprnt_secondary_trigger_note', $order_id);
					star_cloudprnt_second_printer_trigger_print($order_id);
				}, 1, 1);

			} elseif ($trigger === 'status_completed') {

				add_action('woocommerce_order_status_completed', function($order_id){
					do_action('star_cloudprnt_primary_trigger_note', $order_id);
					star_cloudprnt_trigger_print($order_id);
				}, 1, 1);

				add_action('woocommerce_order_status_completed', function($order_id){
					do_action('star_cloudprnt_secondary_trigger_note', $order_id);
					star_cloudprnt_second_printer_trigger_print($order_id);
				}, 1, 1);

			} elseif ($trigger == "status_on-hold") {

				add_action('woocommerce_order_status_on-hold', function($order_id){
					do_action('star_cloudprnt_primary_trigger_note', $order_id);
					star_cloudprnt_trigger_print($order_id);
				}, 1, 1);

				add_action('woocommerce_order_status_on-hold', function($order_id){
					do_action('star_cloudprnt_secondary_trigger_note', $order_id);
					star_cloudprnt_second_printer_trigger_print($order_id);
				}, 1, 1);
			}

		}
	}