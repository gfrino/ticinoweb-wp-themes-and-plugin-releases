<?php
/**
 * Z Report - Daily Sales Report for Star CloudPRNT
 * 
 * Generates and prints end-of-day sales reports on Star thermal printers
 */

// Prevent direct access
if (!defined('ABSPATH')) exit;

/**
 * Generate and print Z Report for a specific date
 */
function star_cloudprnt_generate_z_report($date, $printer_mac = null)
{
    try {
        // Check if WooCommerce is available
        if (!function_exists('wc_get_orders')) {
            return array('success' => false, 'message' => 'WooCommerce non disponibile');
        }
        
        // Get orders for the specified date
        $start_date = date('Y-m-d 00:00:00', strtotime($date));
        $end_date = date('Y-m-d 23:59:59', strtotime($date));
        
        $args = array(
            'limit' => -1,
            'date_created' => $start_date . '...' . $end_date,
            'status' => array('processing', 'completed', 'on-hold'),
            'orderby' => 'date',
            'order' => 'ASC'
        );
        
        $orders = wc_get_orders($args);
        
        // Calculate totals
        $total_orders = count($orders);
        $total_sales = 0;
        $total_tax = 0;
        $total_shipping = 0;
        $payment_methods = array();
        $shipping_methods = array();
        $products_sold = array();
        
        foreach ($orders as $order) {
            $total_sales += $order->get_total();
            $total_tax += $order->get_total_tax();
            $total_shipping += $order->get_shipping_total();
            
            // Payment methods
            $payment_method = $order->get_payment_method_title();
            if (!isset($payment_methods[$payment_method])) {
                $payment_methods[$payment_method] = array('count' => 0, 'total' => 0);
            }
            $payment_methods[$payment_method]['count']++;
            $payment_methods[$payment_method]['total'] += $order->get_total();
            
            // Shipping methods
            $shipping_method = $order->get_shipping_method();
            if (!empty($shipping_method)) {
                if (!isset($shipping_methods[$shipping_method])) {
                    $shipping_methods[$shipping_method] = array('count' => 0);
                }
                $shipping_methods[$shipping_method]['count']++;
            }
            
            // Products
            foreach ($order->get_items() as $item) {
                $product_name = $item->get_name();
                $quantity = $item->get_quantity();
                $total = $item->get_total();
                
                if (!isset($products_sold[$product_name])) {
                    $products_sold[$product_name] = array('quantity' => 0, 'total' => 0);
                }
                $products_sold[$product_name]['quantity'] += $quantity;
                $products_sold[$product_name]['total'] += $total;
            }
        }
        
        // Get printer information
        $selectedPrinter = star_cloudprnt_get_selected_printer($printer_mac);
        if (empty($selectedPrinter)) {
            return array('success' => false, 'message' => 'Nessuna stampante selezionata');
        }
        
        // Check if printer functions are available
        if (!function_exists('star_cloudprnt_create_printer')) {
            return array('success' => false, 'message' => 'Funzioni stampante non disponibili');
        }
        
        // Generate print file
        $extension = $selectedPrinter['format'];
        $file = STAR_CLOUDPRNT_PRINTER_PENDING_SAVE_PATH . star_cloudprnt_get_os_path("/z_report_" . date('Ymd', strtotime($date)) . "_" . time() . "." . $extension);
        
        // Create printer object
        $printer = star_cloudprnt_create_printer($selectedPrinter['format']);
        
        if (!$printer) {
            return array('success' => false, 'message' => 'Impossibile creare oggetto stampante');
        }
        
        // Generate report content
        star_cloudprnt_print_z_report_content($printer, $selectedPrinter, $date, $total_orders, $total_sales, $total_tax, $total_shipping, $payment_methods, $shipping_methods, $products_sold);
        
        // Save to file
        $printer->save_file($file);
        
        return array('success' => true, 'message' => 'Z Report in coda per la stampa', 'file' => $file);
        
    } catch (Exception $e) {
        return array('success' => false, 'message' => 'Errore: ' . $e->getMessage());
    }
}

/**
 * Get selected printer information
 */
function star_cloudprnt_get_selected_printer($printer_mac = null)
{
    $printerList = star_cloudprnt_get_printer_list();
    $selectedPrinter = array();
    
    if (empty($printerList)) {
        return $selectedPrinter;
    }
    
    // If no specific MAC provided, use the default printer
    if (empty($printer_mac)) {
        $printer_mac = get_option('star-cloudprnt-printer-select');
    }
    
    foreach ($printerList as $printer) {
        if ($printer['name'] == $printer_mac || $printer['printerMAC'] == $printer_mac) {
            $selectedPrinter = $printer;
            break;
        }
    }
    
    // If still no printer found, use first available
    if (empty($selectedPrinter) && !empty($printerList)) {
        $selectedPrinter = $printerList[0];
    }
    
    // Set format and columns
    if (!empty($selectedPrinter)) {
        $encodings = $selectedPrinter['Encodings'];
        $extension = "spt";
        $columns = STAR_CLOUDPRNT_MAX_CHARACTERS_THREE_INCH;
        
        if (strpos($encodings, "application/vnd.star.line;") !== false) {
            $extension = "slt";
        } elseif (strpos($encodings, "application/vnd.star.linematrix") !== false) {
            $extension = "slm";
            $columns = STAR_CLOUDPRNT_MAX_CHARACTERS_DOT_THREE_INCH;
        } elseif (strpos($encodings, "application/vnd.star.line") !== false) {
            $extension = "slt";
        } elseif (strpos($encodings, 'application/vnd.star.starprnt') !== false) {
            $extension = "spt";
        } elseif (strpos($encodings, "text/plain") !== false) {
            $extension = "txt";
        }
        
        if ($selectedPrinter['ClientType'] == "Star mC-Print2") {
            $columns = STAR_CLOUDPRNT_MAX_CHARACTERS_TWO_INCH;
        }
        
        $selectedPrinter['format'] = $extension;
        $selectedPrinter['columns'] = $columns;
    }
    
    return $selectedPrinter;
}

/**
 * Print Z Report content
 */
function star_cloudprnt_print_z_report_content($printer, $selectedPrinter, $date, $total_orders, $total_sales, $total_tax, $total_shipping, $payment_methods, $shipping_methods, $products_sold)
{
    $max_chars = $selectedPrinter['columns'];
    $currency = get_woocommerce_currency_symbol();
    
    // Header
    $printer->set_font_magnification(2, 2);
    $printer->set_align_center();
    $printer->add_text_line("RAPPORTO DI");
    $printer->add_text_line("FINE GIORNATA");
    $printer->set_align_left();
    $printer->set_font_magnification(1, 1);
    $printer->add_new_line(1);
    
    // Date
    $printer->set_text_emphasized();
    $printer->set_font_magnification(1, 2);
    $printer->add_text_line("Data: " . date('d/m/Y', strtotime($date)));
    $printer->cancel_text_emphasized();
    $printer->set_font_magnification(1, 1);
    $printer->add_text_line("Orario stampa: " . date('d/m/Y H:i'));
    $printer->add_new_line(1);
    
    // Separator
    $printer->add_text_line(str_repeat("-", $max_chars));
    
    // Summary
    $printer->set_text_emphasized();
    $printer->add_text_line("RIEPILOGO VENDITE");
    $printer->cancel_text_emphasized();
    $printer->add_new_line(1);
    
    $printer->add_text_line("Numero ordini: " . $total_orders);
    $printer->add_new_line(1);
    
    $printer->set_font_magnification(1, 2);
    $printer->set_text_emphasized();
    $printer->add_text_line("TOTALE: " . $currency . number_format($total_sales, 2, ',', '.'));
    $printer->cancel_text_emphasized();
    $printer->set_font_magnification(1, 1);
    $printer->add_new_line(1);
    
    $printer->add_text_line("di cui:");
    $printer->add_text_line("  Tasse: " . $currency . number_format($total_tax, 2, ',', '.'));
    $printer->add_text_line("  Spedizione: " . $currency . number_format($total_shipping, 2, ',', '.'));
    $printer->add_new_line(1);
    
    // Payment methods
    if (!empty($payment_methods)) {
        $printer->add_text_line(str_repeat("-", $max_chars));
        $printer->set_text_emphasized();
        $printer->add_text_line("METODI DI PAGAMENTO");
        $printer->cancel_text_emphasized();
        $printer->add_new_line(1);
        
        foreach ($payment_methods as $method => $data) {
            $printer->add_text_line($method);
            $printer->add_text_line("  Ordini: " . $data['count'] . " | Totale: " . $currency . number_format($data['total'], 2, ',', '.'));
        }
        $printer->add_new_line(1);
    }
    
    // Shipping methods
    if (!empty($shipping_methods)) {
        $printer->add_text_line(str_repeat("-", $max_chars));
        $printer->set_text_emphasized();
        $printer->add_text_line("METODI DI SPEDIZIONE");
        $printer->cancel_text_emphasized();
        $printer->add_new_line(1);
        
        foreach ($shipping_methods as $method => $data) {
            $printer->add_text_line($method . ": " . $data['count'] . " ordini");
        }
        $printer->add_new_line(1);
    }
    
    // Products sold
    if (!empty($products_sold)) {
        $printer->add_text_line(str_repeat("-", $max_chars));
        $printer->set_text_emphasized();
        $printer->add_text_line("PRODOTTI VENDUTI");
        $printer->cancel_text_emphasized();
        $printer->add_new_line(1);
        
        // Sort by quantity
        uasort($products_sold, function($a, $b) {
            return $b['quantity'] - $a['quantity'];
        });
        
        foreach ($products_sold as $product => $data) {
            $printer->add_text_line($product);
            $printer->add_text_line("  Qta: " . $data['quantity'] . " | Totale: " . $currency . number_format($data['total'], 2, ',', '.'));
        }
        $printer->add_new_line(1);
    }
    
    // Footer
    $printer->add_text_line(str_repeat("=", $max_chars));
    $printer->set_align_center();
    $printer->add_text_line("*** FINE RAPPORTO ***");
    $printer->set_align_left();
    $printer->add_new_line(3);
    
    // Cut paper
    $printer->add_cut();
}

/**
 * Ajax handler for printing Z Report
 */
function star_cloudprnt_ajax_print_z_report()
{
    // Log the request
    error_log('Z Report Ajax Request - Started');
    
    check_ajax_referer('star_cloudprnt_z_report', 'nonce');
    
    if (!current_user_can('manage_options')) {
        error_log('Z Report Ajax Request - Permission denied');
        wp_send_json_error('Permesso negato');
        return;
    }
    
    $date = isset($_POST['date']) ? sanitize_text_field($_POST['date']) : date('Y-m-d');
    error_log('Z Report Ajax Request - Date: ' . $date);
    
    // Use saved printer from settings
    $printer = get_option('star-cloudprnt-z-report-printer');
    error_log('Z Report Ajax Request - Printer: ' . $printer);
    
    if (empty($printer)) {
        error_log('Z Report Ajax Request - No printer configured');
        wp_send_json_error('Nessuna stampante configurata. Salva prima una stampante nelle impostazioni.');
        return;
    }
    
    $result = star_cloudprnt_generate_z_report($date, $printer);
    
    error_log('Z Report Ajax Request - Result: ' . print_r($result, true));
    
    if ($result['success']) {
        wp_send_json_success($result['message']);
    } else {
        wp_send_json_error($result['message']);
    }
}
add_action('wp_ajax_star_cloudprnt_print_z_report', 'star_cloudprnt_ajax_print_z_report');

/**
 * Ajax handler for saving Z Report printer setting
 */
function star_cloudprnt_ajax_save_z_report_printer()
{
    check_ajax_referer('star_cloudprnt_z_report_settings', 'nonce');
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error('Permission denied');
        return;
    }
    
    $printer = isset($_POST['printer']) ? sanitize_text_field($_POST['printer']) : '';
    
    update_option('star-cloudprnt-z-report-printer', $printer);
    
    wp_send_json_success('Stampante salvata con successo');
}
add_action('wp_ajax_star_cloudprnt_save_z_report_printer', 'star_cloudprnt_ajax_save_z_report_printer');

/**
 * Z Report settings page
 */
function star_cloudprnt_z_report_page()
{
    if (!current_user_can('manage_options')) {
        return;
    }
    
    // Get printer list
    $printerList = star_cloudprnt_get_printer_list();
    $saved_z_printer = get_option('star-cloudprnt-z-report-printer');
    
    ?>
    <div class="wrap">
        <h1><?php echo esc_html__('Z Report - Rapporto Fine Giornata', 'star-cloudprnt'); ?></h1>
        
        <!-- Printer Settings Section -->
        <div class="card" style="max-width: 600px; margin-top: 20px;">
            <h2>Impostazioni Stampante</h2>
            <p>Seleziona la stampante da utilizzare per i rapporti Z.</p>
            
            <form id="z-report-settings-form" method="post">
                <?php wp_nonce_field('star_cloudprnt_z_report_settings', 'settings_nonce'); ?>
                
                <table class="form-table">
                    <tr>
                        <th scope="row">
                            <label for="z_report_printer_setting">Stampante Z Report</label>
                        </th>
                        <td>
                            <select id="z_report_printer_setting" name="printer" style="width: 300px;">
                                <?php if (empty($printerList)): ?>
                                    <option value="">Nessuna stampante disponibile</option>
                                <?php else: ?>
                                    <?php foreach ($printerList as $printer): ?>
                                        <option value="<?php echo esc_attr($printer['name']); ?>" 
                                                <?php selected($saved_z_printer, $printer['name']); ?>>
                                            <?php echo esc_html($printer['name'] . ' (' . $printer['ClientType'] . ')'); ?>
                                        </option>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </select>
                            <p class="description">Questa stampante verrà usata per tutti i rapporti Z.</p>
                        </td>
                    </tr>
                </table>
                
                <p class="submit">
                    <button type="submit" class="button button-primary" id="save-z-printer">
                        Salva Stampante
                    </button>
                    <span id="z-printer-status" style="margin-left: 15px; display: none;"></span>
                </p>
            </form>
        </div>
        
        <!-- Print Report Section -->
        <div class="card" style="max-width: 600px; margin-top: 20px;">
            <h2>Stampa Rapporto Vendite</h2>
            <p>Seleziona la data per generare il rapporto di fine giornata.</p>
            
            <form id="z-report-form" method="post">
                <?php wp_nonce_field('star_cloudprnt_z_report', 'nonce'); ?>
                
                <table class="form-table">
                    <tr>
                        <th scope="row">
                            <label for="z_report_date">Data</label>
                        </th>
                        <td>
                            <input type="date" 
                                   id="z_report_date" 
                                   name="date" 
                                   value="<?php echo date('Y-m-d'); ?>" 
                                   max="<?php echo date('Y-m-d'); ?>"
                                   required
                                   style="width: 200px;" />
                            <p class="description">Seleziona la data per il rapporto vendite.</p>
                        </td>
                    </tr>
                    
                    <?php if (!empty($saved_z_printer)): ?>
                    <tr>
                        <th scope="row">Stampante selezionata:</th>
                        <td>
                            <strong><?php echo esc_html($saved_z_printer); ?></strong>
                        </td>
                    </tr>
                    <?php endif; ?>
                </table>
                
                <p class="submit">
                    <button type="submit" class="button button-primary" id="print-z-report">
                        <span class="dashicons dashicons-printer" style="margin-top: 3px;"></span>
                        Stampa Z Report
                    </button>
                    <span id="z-report-status" style="margin-left: 15px; display: none;"></span>
                </p>
            </form>
            
            <div id="z-report-preview" style="margin-top: 30px; padding: 15px; background: #f5f5f5; border-radius: 5px; display: none;">
                <h3>Anteprima contenuto rapporto:</h3>
                <ul style="list-style: disc; margin-left: 20px;">
                    <li>Numero totale ordini</li>
                    <li>Vendite totali (con tasse e spese di spedizione)</li>
                    <li>Riepilogo metodi di pagamento</li>
                    <li>Riepilogo metodi di spedizione</li>
                    <li>Lista prodotti venduti con quantità</li>
                </ul>
            </div>
        </div>
    </div>
    
    <script type="text/javascript">
    jQuery(document).ready(function($) {
        // Save printer settings
        $('#z-report-settings-form').on('submit', function(e) {
            e.preventDefault();
            
            var $button = $('#save-z-printer');
            var $status = $('#z-printer-status');
            
            $button.prop('disabled', true);
            $status.html('<span class="dashicons dashicons-update spin"></span> Salvataggio...').show();
            
            $.ajax({
                url: ajaxurl,
                type: 'POST',
                data: {
                    action: 'star_cloudprnt_save_z_report_printer',
                    nonce: $('#settings_nonce').val(),
                    printer: $('#z_report_printer_setting').val()
                },
                success: function(response) {
                    if (response.success) {
                        $status.html('<span class="dashicons dashicons-yes" style="color: green;"></span> ' + response.data).css('color', 'green');
                        // Reload page to update the display
                        setTimeout(function() {
                            location.reload();
                        }, 1000);
                    } else {
                        $status.html('<span class="dashicons dashicons-no" style="color: red;"></span> Errore: ' + response.data).css('color', 'red');
                        $button.prop('disabled', false);
                    }
                },
                error: function() {
                    $status.html('<span class="dashicons dashicons-no" style="color: red;"></span> Errore di connessione').css('color', 'red');
                    $button.prop('disabled', false);
                }
            });
        });
        
        // Print Z Report
        $('#z-report-form').on('submit', function(e) {
            e.preventDefault();
            
            var $button = $('#print-z-report');
            var $status = $('#z-report-status');
            
            $button.prop('disabled', true);
            $status.html('<span class="dashicons dashicons-update spin"></span> Generazione in corso...').show();
            
            $.ajax({
                url: ajaxurl,
                type: 'POST',
                data: {
                    action: 'star_cloudprnt_print_z_report',
                    nonce: $('#nonce').val(),
                    date: $('#z_report_date').val()
                },
                success: function(response) {
                    if (response.success) {
                        $status.html('<span class="dashicons dashicons-yes" style="color: green;"></span> ' + response.data).css('color', 'green');
                    } else {
                        $status.html('<span class="dashicons dashicons-no" style="color: red;"></span> Errore: ' + response.data).css('color', 'red');
                    }
                    $button.prop('disabled', false);
                    
                    setTimeout(function() {
                        $status.fadeOut();
                    }, 5000);
                },
                error: function() {
                    $status.html('<span class="dashicons dashicons-no" style="color: red;"></span> Errore di connessione').css('color', 'red');
                    $button.prop('disabled', false);
                }
            });
        });
        
        // Show preview on hover
        $('#print-z-report').hover(
            function() { $('#z-report-preview').slideDown(); },
            function() { }
        );
    });
    </script>
    
    <style>
        .dashicons.spin {
            animation: spin 1s linear infinite;
        }
        @keyframes spin {
            from { transform: rotate(0deg); }
            to { transform: rotate(360deg); }
        }
    </style>
    <?php
}
