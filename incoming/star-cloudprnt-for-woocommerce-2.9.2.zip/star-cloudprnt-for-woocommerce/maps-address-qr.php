<?php

// Exit if accessed directly
if (!defined('ABSPATH')) exit;

/**
 * Print a QR code with a Google Maps link to the customer's address
 */
function star_cloudprnt_print_maps_qr(&$printer, &$selectedPrinter, &$order, &$order_meta) {
    if (!is_object($order)) return;

    $a1 = $order->get_shipping_address_1() ? $order->get_shipping_address_1() : $order->get_billing_address_1();
    $city = $order->get_shipping_city() ? $order->get_shipping_city() : $order->get_billing_city();
    $postcode = $order->get_shipping_postcode() ? $order->get_shipping_postcode() : $order->get_billing_postcode();
    
    // Check if pickup order
    $pickup_date = $order->get_meta('pickup_date');
    if (!empty($pickup_date)) {
        return; // Don't print maps QR for pickup orders
    }

    $full_address = trim($a1 . ' ' . $postcode . ' ' . $city);
    
    if (empty($full_address)) {
        return;
    }

    // Google Maps Search URL
    $maps_url = 'https://www.google.com/maps/search/?api=1&query=' . urlencode($full_address);

    $printer->add_new_line(2);
    
    // Center align for QR code
    if (method_exists($printer, 'set_text_center_align')) {
        $printer->set_text_center_align();
    }
    
    $printer->add_text_line('Scansiona per Navigare:');
    $printer->add_new_line(1);
    
    // Add QR Code (error correction 0=L, 1=M, 2=Q, 3=H; cell size 8 is readable and prominent)
    if (method_exists($printer, 'add_qr_code')) {
        $printer->add_qr_code(1, 8, $maps_url);
    }
    
    $printer->add_new_line(1);
    
    // Reset alignment
    if (method_exists($printer, 'set_text_left_align')) {
        $printer->set_text_left_align();
    }
}
