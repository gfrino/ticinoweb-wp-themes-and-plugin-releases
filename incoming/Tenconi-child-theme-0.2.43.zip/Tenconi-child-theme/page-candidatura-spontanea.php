<?php
/**
 * CANDIDATURA SPONTANEA — pagina propria con il modulo di candidatura.
 *
 * URL: /candidatura-spontanea/ (pagina WordPress con questo slug: WordPress
 * sceglie questo file da solo, gerarchia page-{slug}.php).
 *
 * Prima il modulo stava in fondo a /jobs/, e le due voci del menu Jobs
 * portavano alla stessa pagina. Ora Jobs elenca le posizioni aperte e questa
 * pagina raccoglie le candidature: per una posizione precisa (?posizione=ID,
 * dal pulsante "Candidati" in Jobs) o spontanee.
 *
 * Il testo introduttivo e' il contenuto della pagina, modificabile in
 * WordPress. Il modulo e' in inc/job-application.php: dopo l'invio torna qui
 * (redirect sul referer).
 *
 * @package tenconi-child-theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$GLOBALS['tenconi_interne'] = true;

/*
 * Il modulo porta un nonce che scade: una copia in cache della pagina,
 * servita giorni dopo, farebbe fallire ogni candidatura con "sessione scaduta".
 */
do_action( 'litespeed_control_set_nocache', 'Tenconi: modulo di candidatura con nonce' );

get_header();

$tl_post   = get_queried_object();
$tl_voce   = tenconi_int_voce( 'candidature-spontanee' );
$tl_scelta = '';
if ( isset( $_GET['posizione'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification -- solo un valore iniziale del modulo.
	$tl_p = get_post( absint( $_GET['posizione'] ) ); // phpcs:ignore WordPress.Security.NonceVerification
	if ( $tl_p && 'job' === $tl_p->post_type && 'publish' === $tl_p->post_status ) {
		$tl_scelta = get_the_title( $tl_p );
	}
}
$tl_testo = $tl_post ? trim( (string) $tl_post->post_content ) : '';
?>
<main id="main" class="tl-main tl-int" tabindex="-1">
	<?php
	tenconi_int_testa(
		array(
			'gruppo' => '' !== $tl_voce['gruppo'] ? $tl_voce['gruppo'] : 'Jobs',
			'titolo' => $tl_post ? get_the_title( $tl_post ) : '',
			'intro'  => '' !== $tl_scelta
				? sprintf(
					/* translators: %s: nome della posizione. */
					tenconi_int_t( 'Candidatura per: %s', 'tenconi:jobs:candidatura-per' ),
					$tl_scelta
				)
				: '',
			'hero'   => tenconi_mega_immagine( 'candidature-spontanee', $tl_post ? get_permalink( $tl_post ) : '' )['img'],
		)
	);
	?>
	<section class="tl-int__sez">
		<div class="tl-wrap tl-int__testo">
			<div class="tl-int__doc">
				<?php if ( '' !== $tl_testo ) : ?>
					<div class="tl-int__corpo tl-int__corpo--intro">
						<?php echo wp_kses_post( apply_filters( 'the_content', $tl_testo ) ); ?>
					</div>
				<?php endif; ?>

				<?php tenconi_cand_modulo( $tl_scelta ); ?>

				<?php $tl_jobs_url = (string) get_post_type_archive_link( 'job' ); ?>
				<?php if ( '' !== $tl_jobs_url ) : ?>
					<p class="tl-int__doc-p">
						<a class="tl-link" href="<?php echo esc_url( $tl_jobs_url ); ?>"><?php echo esc_html( tenconi_int_t( 'Vedi le posizioni aperte', 'tenconi:jobs:vedi-posizioni' ) ); ?></a>
					</p>
				<?php endif; ?>
			</div>
		</div>
	</section>
</main>
<?php
get_footer();
