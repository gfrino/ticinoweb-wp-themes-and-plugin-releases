<?php
/**
 * I 7 CPT della Content Foundation.
 *
 * Slug di archivio dalle decisioni approvate (NUOVA-20, opzione A1): prefisso, con
 * gli slug storici `referenze` e `jobs` preservati. Il titolo VISIBILE degli archivi
 * puo' essere diverso dallo slug: `referenze` si intitola "Progetti e referenze",
 * `jobs` si intitola "Lavora con noi".
 *
 * MULTISITE: nessun prefisso di tabella qui. La registrazione avviene per subsite
 * perche' il tema e' attivo solo sul blog 20.
 *
 * NESSUN FLUSH DEI REWRITE A OGNI RICHIESTA. Il flush si esegue una sola volta da
 * WP-CLI dopo la sincronizzazione del codice.
 *
 * Nessuna dipendenza da ACF: il supporto 'custom-fields' basta perche' ACF, quando
 * verra' attivato, si agganci alle stesse chiavi meta.
 *
 * @package tenconi-child-theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Argomenti comuni dei CPT.
 *
 * @param string $singolare Etichetta singolare.
 * @param string $plurale   Etichetta plurale, usata nel menu di amministrazione.
 * @param string $archivio  Slug dell'archivio e base di rewrite.
 * @param array  $extra     Sovrascritture.
 * @return array
 */
function tenconi_cpt_args( $singolare, $plurale, $archivio, array $extra = array() ) {
	$labels = array(
		'name'                  => $plurale,
		'singular_name'         => $singolare,
		'menu_name'             => $plurale,
		'all_items'             => $plurale,
		'add_new'               => 'Aggiungi',
		/* translators: %s: nome singolare del tipo di contenuto. */
		'add_new_item'          => sprintf( 'Aggiungi %s', $singolare ),
		'edit_item'             => sprintf( 'Modifica %s', $singolare ),
		'new_item'              => sprintf( 'Nuovo: %s', $singolare ),
		'view_item'             => sprintf( 'Vedi %s', $singolare ),
		'view_items'            => sprintf( 'Vedi %s', $plurale ),
		'search_items'          => sprintf( 'Cerca in %s', $plurale ),
		'not_found'             => 'Nessun elemento trovato.',
		'not_found_in_trash'    => 'Nessun elemento nel cestino.',
		'archives'              => sprintf( 'Archivio %s', $plurale ),
		'insert_into_item'      => 'Inserisci nel contenuto',
		'uploaded_to_this_item' => 'Caricato su questo contenuto',
		'featured_image'        => 'Immagine in evidenza',
		'set_featured_image'    => 'Imposta immagine in evidenza',
		'remove_featured_image' => 'Rimuovi immagine in evidenza',
		'use_featured_image'    => 'Usa come immagine in evidenza',
		'item_published'        => sprintf( '%s pubblicato.', $singolare ),
		'item_updated'          => sprintf( '%s aggiornato.', $singolare ),
		'item_link'             => sprintf( 'Link a %s', $singolare ),
	);

	return array_merge(
		array(
			'labels'          => $labels,
			'public'          => true,
			'show_ui'         => true,
			'show_in_menu'    => true,
			'show_in_nav_menus' => true,
			'show_in_rest'    => true, // compatibilita Gutenberg
			'has_archive'     => $archivio,
			'rewrite'         => array(
				'slug'       => $archivio,
				'with_front' => false,
			),
			'hierarchical'    => false,
			'menu_position'   => 20,
			'supports'        => array(
				'title',
				'editor',
				'excerpt',
				'thumbnail',
				'revisions',
				'custom-fields',
				'page-attributes',
			),
			'capability_type' => 'post',
			'map_meta_cap'    => true,
			'can_export'       => true,
			'delete_with_user' => false,
		),
		$extra
	);
}

/**
 * Registra i 7 CPT.
 *
 * @return void
 */
function tenconi_register_post_types() {

	register_post_type( 'product', tenconi_cpt_args( 'Prodotto', 'Prodotti', 'prodotti', array(
		'menu_icon'   => 'dashicons-screenoptions',
		'description' => 'I prodotti proprietari Tenconi per la ferrovia e l’industria, nati dalla meccanica di precisione.',
	) ) );

	register_post_type( 'capability', tenconi_cpt_args( 'Lavorazione', 'Lavorazioni', 'lavorazioni', array(
		'menu_icon'   => 'dashicons-admin-tools',
		'description' => 'Lavorazioni meccaniche di precisione su disegno del cliente: le competenze e i servizi di Tenconi.',
	) ) );

	register_post_type( 'machine', tenconi_cpt_args( 'Macchina', 'Parco macchine', 'parco-macchine', array(
		'menu_icon'   => 'dashicons-performance',
		'description' => 'Il parco macchine Tenconi: gli impianti con cui realizziamo le lavorazioni meccaniche di precisione.',
	) ) );

	// Slug storico `referenze` preservato; titolo visibile "Progetti e referenze".
	register_post_type( 'project', tenconi_cpt_args( 'Progetto', 'Progetti e referenze', 'referenze', array(
		'menu_icon'   => 'dashicons-portfolio',
		'description' => 'Progetti realizzati e referenze di Tenconi nella meccanica di precisione per la ferrovia e l’industria.',
	) ) );

	register_post_type( 'certification', tenconi_cpt_args( 'Certificazione', 'Certificazioni', 'certificazioni', array(
		'menu_icon'   => 'dashicons-awards',
		'description' => 'Certificazioni e omologazioni di Tenconi, con i certificati da scaricare in PDF.',
	) ) );

	register_post_type( 'document', tenconi_cpt_args( 'Documento', 'Documenti', 'documenti', array(
		'menu_icon'   => 'dashicons-media-document',
		'description' => 'Documenti Tenconi da consultare e scaricare.',
	) ) );

	// Slug storico `jobs` preservato; titolo visibile "Lavora con noi".
	register_post_type( 'job', tenconi_cpt_args( 'Posizione', 'Lavora con noi', 'jobs', array(
		'menu_icon'   => 'dashicons-groups',
		'description' => 'Lavora con noi: le posizioni aperte in Tenconi e la candidatura spontanea.',
	) ) );
}
add_action( 'init', 'tenconi_register_post_types', 5 );

/**
 * Titolo visibile degli archivi.
 *
 * WordPress restituisce "Archivi: <span>Nome</span>": il prefisso e il markup non
 * servono, e passati a esc_html() nel template comparivano come entita' escapate.
 * Qui si restituisce il nome pulito. `referenze` e `jobs` mantengono lo slug
 * storico ma mostrano il titolo approvato.
 *
 * @param string $titolo Titolo generato da WordPress.
 * @return string
 */
function tenconi_archive_title( $titolo ) {
	if ( ! is_post_type_archive() ) {
		return $titolo;
	}
	$pt = get_query_var( 'post_type' );
	if ( is_array( $pt ) ) {
		$pt = reset( $pt );
	}
	$mappa = array(
		'project' => 'Progetti e referenze',
		'job'     => 'Lavora con noi',
	);
	if ( isset( $mappa[ $pt ] ) ) {
		return $mappa[ $pt ];
	}
	$obj = $pt ? get_post_type_object( $pt ) : null;
	if ( $obj ) {
		return (string) $obj->labels->name;
	}
	// Ultima risorsa: si toglie il prefisso e il markup.
	return trim( wp_strip_all_tags( preg_replace( '/^[^:]+:\s*/u', '', $titolo ) ) );
}
add_filter( 'get_the_archive_title', 'tenconi_archive_title' );

/**
 * Titolo pulito anche per le viste di tassonomia.
 *
 * @param string $titolo Titolo generato da WordPress.
 * @return string
 */
function tenconi_tax_archive_title( $titolo ) {
	if ( ! is_tax() ) {
		return $titolo;
	}
	$t = get_queried_object();
	return ( $t && ! is_wp_error( $t ) && isset( $t->name ) ) ? (string) $t->name : $titolo;
}
add_filter( 'get_the_archive_title', 'tenconi_tax_archive_title' );
