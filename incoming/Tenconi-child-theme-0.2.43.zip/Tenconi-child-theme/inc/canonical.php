<?php
/**
 * Canonical e meta description degli archivi, sopra il SEO del parent.
 *
 * IL CANONICAL LO SCRIVE IL PARENT. Dalla 3.3.0 tw_seo_get_canonical_url() del
 * parent e' consapevole del contesto (home, singoli, archivi di post type,
 * tassonomie) e il parent toglie rel_canonical() del core per non averne due.
 *
 * Fino alla 0.2.40 questo file toglieva il canonical del parent dall'output e
 * contava su rel_canonical() del core per le pagine: con il core spento dal
 * parent, home, pagine e singoli restavano SENZA canonical. Ora il child non
 * toglie piu' nulla e passa soltanto dai filtri del parent.
 *
 * COSA AGGIUNGE IL CHILD
 *   - il numero di pagina sul canonical degli archivi Tenconi e di market: una
 *     pagina 2 dichiara se stessa, non la pagina 1;
 *   - la meta description degli archivi, che il parent lascerebbe vuota.
 *
 * @package tenconi-child-theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * I post type i cui archivi sono gestiti dal child.
 *
 * @return array
 */
function tenconi_canonical_archive_types() {
	return array( 'product', 'capability', 'machine', 'project', 'certification', 'document', 'job' );
}

/**
 * Aggiunge il numero di pagina a un URL di archivio, con le API di WordPress.
 *
 * @param string $url   URL base dell'archivio.
 * @param int    $paged Numero di pagina.
 * @return string
 */
function tenconi_canonical_paged( $url, $paged ) {
	$paged = (int) $paged;
	if ( $paged < 2 ) {
		return $url;
	}
	global $wp_rewrite;
	if ( $wp_rewrite instanceof WP_Rewrite && $wp_rewrite->using_permalinks() && $wp_rewrite->pagination_base ) {
		return user_trailingslashit(
			trailingslashit( $url ) . $wp_rewrite->pagination_base . '/' . $paged,
			'paged'
		);
	}
	return add_query_arg( 'paged', $paged, $url );
}

/**
 * Il canonical del parent, con il numero di pagina sugli archivi Tenconi.
 *
 * @param string $canonical URL calcolato dal parent (gia' nella lingua corrente).
 * @return string
 */
function tenconi_canonical_filtro( $canonical ) {
	if ( '' === (string) $canonical ) {
		return $canonical;
	}
	if ( is_post_type_archive( tenconi_canonical_archive_types() ) || is_tax( 'market' ) ) {
		return tenconi_canonical_paged( $canonical, max( 1, (int) get_query_var( 'paged' ) ) );
	}
	return $canonical;
}
add_filter( 'ticinoweb_seo_canonical_url', 'tenconi_canonical_filtro' );

/**
 * La meta description degli archivi Tenconi.
 *
 * Fonte, in ordine:
 *   1. la pagina con lo stesso slug dell'archivio, se esiste (es. "certificazioni"):
 *      la sua descrizione SEO, o il suo riassunto. Si modifica da WordPress;
 *   2. la descrizione del post type (inc/post-types.php).
 *
 * @param string $desc Descrizione calcolata dal parent.
 * @return string
 */
function tenconi_archivio_descrizione( $desc ) {
	if ( '' !== trim( (string) $desc ) || ! is_post_type_archive( tenconi_canonical_archive_types() ) ) {
		return $desc;
	}
	$o = get_queried_object();
	if ( ! $o instanceof WP_Post_Type ) {
		return $desc;
	}

	$testo  = '';
	$slug   = is_string( $o->has_archive ) ? $o->has_archive : $o->name;
	$pagina = get_page_by_path( $slug );
	if ( $pagina && 'publish' === $pagina->post_status ) {
		$testo = (string) get_post_meta( $pagina->ID, '_tw_seo_description', true );
		if ( '' === $testo ) {
			$testo = (string) $pagina->post_excerpt;
		}
	}
	if ( '' === $testo ) {
		$testo = (string) $o->description;
	}

	$testo = trim( wp_strip_all_tags( $testo ) );
	if ( '' === $testo ) {
		return $desc;
	}
	if ( mb_strlen( $testo ) > 160 ) {
		$testo = mb_substr( $testo, 0, 157 ) . '...';
	}
	return function_exists( 'ticinoweb_frontend_text' ) ? ticinoweb_frontend_text( $testo, 'tenconi:seo:archivio:' . $o->name ) : $testo;
}
add_filter( 'ticinoweb_seo_meta_description', 'tenconi_archivio_descrizione' );
