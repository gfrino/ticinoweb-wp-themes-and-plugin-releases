<?php
/**
 * PAGINA INTERNA, NUOVO SISTEMA — Jobs: le posizioni aperte pubblicate in
 * bacheca (inc/jobs.php). Il modulo di candidatura ha una pagina sua,
 * /candidatura-spontanea/ (page-candidatura-spontanea.php): "Candidati" ci
 * porta con la posizione gia' scelta.
 *
 * @package tenconi-child-theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$tl_voce  = tenconi_int_voce( 'jobs' );
$tl_url   = (string) get_post_type_archive_link( 'job' );
$tl_jobs  = tenconi_jobs_aperte();
$tl_cpag  = get_page_by_path( 'candidatura-spontanea' );
$tl_curl  = $tl_cpag ? (string) get_permalink( $tl_cpag ) : '';
?>
<main id="main" class="tl-main tl-int" tabindex="-1">
	<?php
	tenconi_int_testa(
		array(
			'gruppo' => $tl_voce['gruppo'],
			'titolo' => '' !== $tl_voce['titolo'] ? $tl_voce['titolo'] : tenconi_int_t( 'Lavora con noi', 'tenconi:jobs:titolo' ),
			'hero'   => tenconi_mega_immagine( 'jobs', $tl_url )['img'],
		)
	);
	?>
	<section class="tl-int__sez">
		<div class="tl-wrap tl-int__testo">
			<div class="tl-int__doc">
				<h2 class="tl-int__doc-t" id="posizioni-aperte"><?php echo esc_html( tenconi_int_t( 'Posizioni aperte', 'tenconi:jobs:posizioni' ) ); ?></h2>

				<?php if ( ! $tl_jobs ) : ?>
					<p class="tl-int__doc-p"><?php echo esc_html( tenconi_int_t( 'Al momento non ci sono posizioni aperte.', 'tenconi:jobs:nessuna' ) ); ?></p>
				<?php endif; ?>

				<?php
				foreach ( $tl_jobs as $tl_j ) :
					$tl_pdf   = tenconi_job_pdf_url( $tl_j->ID );
					$tl_testo = trim( (string) $tl_j->post_content );
					$tl_cand  = '' !== $tl_curl ? add_query_arg( 'posizione', $tl_j->ID, $tl_curl ) . '#tl-candidatura' : '';
					?>
					<div class="tl-int__doc-r tl-job">
						<p class="tl-int__doc-n"><?php echo esc_html( get_the_title( $tl_j ) ); ?></p>
						<p class="tl-int__doc-l">
							<?php if ( '' !== $tl_pdf ) : ?>
								<a class="tl-int__pdf" href="<?php echo esc_url( $tl_pdf ); ?>" rel="noopener" aria-label="<?php echo esc_attr( get_the_title( $tl_j ) . ' — PDF' ); ?>">
									<span class="tl-int__pdf-ico" aria-hidden="true">PDF</span>
									<span><?php echo esc_html( tenconi_int_t( 'Scarica il PDF', 'tenconi:interne:scarica-pdf' ) ); ?></span>
								</a>
							<?php endif; ?>
							<?php if ( '' !== $tl_cand ) : ?>
								<a class="tl-int__pdf" href="<?php echo esc_url( $tl_cand ); ?>"><?php echo esc_html( tenconi_int_t( 'Candidati', 'tenconi:jobs:candidati' ) ); ?></a>
							<?php endif; ?>
						</p>
						<?php if ( '' !== $tl_testo ) : ?>
							<details class="tl-job__annuncio">
								<summary><?php echo esc_html( tenconi_int_t( 'Leggi l’annuncio', 'tenconi:jobs:leggi' ) ); ?></summary>
								<div class="tl-job__testo"><?php echo apply_filters( 'the_content', $tl_testo ); // phpcs:ignore WordPress.Security.EscapeOutput -- contenuto del post, filtrato da WordPress. ?></div>
							</details>
						<?php endif; ?>
					</div>
				<?php endforeach; ?>

				<?php if ( '' !== $tl_curl ) : ?>
					<h2 class="tl-int__doc-t" id="candidatura-spontanea"><?php echo esc_html( tenconi_int_t( 'Candidatura spontanea', 'tenconi:jobs:spontanea' ) ); ?></h2>
					<p class="tl-int__doc-p"><?php echo esc_html( tenconi_int_t( 'Se al momento non ci sono posizioni aperte idonee al tuo profilo, inviaci una tua candidatura spontanea completa di CV.', 'tenconi:jobs:spontanea-testo' ) ); ?></p>
					<p class="tl-int__doc-p"><a class="tl-int__btn tl-int__btn--pieno" href="<?php echo esc_url( $tl_curl ); ?>"><?php echo esc_html( tenconi_int_t( 'Invia una candidatura spontanea', 'tenconi:jobs:vai-spontanea' ) ); ?></a></p>
				<?php endif; ?>
			</div>
		</div>
	</section>
</main>
