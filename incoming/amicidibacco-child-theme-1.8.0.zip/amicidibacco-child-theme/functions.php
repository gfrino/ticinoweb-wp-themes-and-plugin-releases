<?php
defined('ABSPATH') || exit;
define('ADB_VERSION', wp_get_theme()->get('Version'));
require_once __DIR__ . '/inc/catalog.php';
require_once __DIR__ . '/inc/shop-filters.php';
require_once __DIR__ . '/inc/tasting.php';
require_once __DIR__ . '/inc/product-page.php';
require_once __DIR__ . '/inc/hero-selection.php';
require_once __DIR__ . '/inc/cms.php';
require_once __DIR__ . '/inc/presentation.php';
require_once __DIR__ . '/inc/collections.php';
require_once __DIR__ . '/inc/territories.php';

add_action('after_setup_theme', function () {
    load_child_theme_textdomain('amicidibacco', get_stylesheet_directory() . '/languages');
    register_nav_menus(['adb_footer' => __('Menu del piè di pagina', 'amicidibacco')]);
    add_post_type_support('page', 'excerpt');
    remove_action('wp_enqueue_scripts', 'ticinoweb_ai_assets');
}, 100);

add_action('wp_enqueue_scripts', function () {
    $uri = get_stylesheet_directory_uri();
    wp_enqueue_style('adb-site', $uri . '/assets/css/site.css', [], ADB_VERSION);
    wp_enqueue_style('adb-page-transition', $uri . '/assets/css/page-transition.css', ['adb-site'], ADB_VERSION);
    // The pagereveal listener must be registered in the classic head script before first paint.
    wp_enqueue_script('adb-page-transition', $uri . '/assets/js/page-transition.js', [], ADB_VERSION, false);
    wp_enqueue_script('adb-navigation', $uri . '/assets/js/navigation.js', [], ADB_VERSION, true);
    if (adb_is_selection_page()) {
        wp_enqueue_style('adb-collections', $uri . '/assets/css/collections.css', ['adb-site'], ADB_VERSION);
    }
    if (function_exists('is_shop') && (is_shop() || is_product_taxonomy() || (is_search() && get_query_var('post_type') === 'product'))) {
        wp_enqueue_style('adb-shop-filters', $uri . '/assets/css/shop-filters.css', ['adb-site'], ADB_VERSION);
        wp_enqueue_script('adb-shop-filters', $uri . '/assets/js/shop-filters.js', [], ADB_VERSION, true);
    }
    if (function_exists('is_product') && is_product()) {
        wp_enqueue_style('adb-product', $uri . '/assets/css/product.css', ['adb-site'], ADB_VERSION);
        wp_enqueue_script('adb-product', $uri . '/assets/js/product.js', [], ADB_VERSION, true);
    }
    if (is_singular('produttore')) {
        wp_enqueue_style('adb-winery', $uri . '/assets/css/winery.css', ['adb-site'], ADB_VERSION);
    }
    if (is_front_page()) {
        wp_enqueue_style('adb-home', $uri . '/assets/css/home.css', ['adb-site'], ADB_VERSION);
        wp_enqueue_style('adb-territories', $uri . '/assets/css/territories.css', ['adb-home'], ADB_VERSION);
        wp_enqueue_script('adb-lenis', $uri . '/assets/vendor/lenis.min.js', [], ADB_VERSION, true);
        wp_enqueue_script('adb-motion-math', $uri . '/assets/js/motion-math.js', [], ADB_VERSION, true);
        wp_enqueue_script('adb-wine-selection', $uri . '/assets/js/wine-selection.js', [], ADB_VERSION, true);
        wp_enqueue_script('adb-calligraphy', $uri . '/assets/js/calligraphy.js', [], ADB_VERSION, true);
        wp_enqueue_script('adb-home', $uri . '/assets/js/home.js', ['adb-lenis', 'adb-motion-math', 'adb-calligraphy', 'adb-wine-selection'], ADB_VERSION, true);
        wp_enqueue_script('adb-territories', $uri . '/assets/js/territories.js', ['adb-home'], ADB_VERSION, true);
    }
    if (function_exists('WC')) {
        wp_enqueue_script('wc-cart-fragments');
    }
    if (is_page_template('page-contatti.php') || is_page('contatti')) {
        wp_enqueue_script('adb-contact', $uri . '/assets/js/contact.js', [], ADB_VERSION, true);
        wp_localize_script('adb-contact', 'adbContact', ['ajaxUrl' => admin_url('admin-ajax.php'), 'recaptchaKey' => (string) get_option('ticinoweb_recaptcha_site_key', ''), 'error' => __('Invio non riuscito. Riprova o contattaci via email.', 'amicidibacco'), 'loading' => __('Invio in corso…', 'amicidibacco')]);
    }
}, 30);

add_action('wp_head', function () {
    $uri = get_stylesheet_directory_uri();
    echo '<link rel="preload" href="' . esc_url($uri . '/assets/fonts/cormorant-regular.ttf') . '" as="font" type="font/ttf" crossorigin>' . "\n";
    echo '<link rel="preload" href="' . esc_url($uri . '/assets/fonts/manrope-latin.woff2') . '" as="font" type="font/woff2" crossorigin>' . "\n";
    if (is_front_page()) { echo '<link rel="preload" href="' . esc_url($uri . '/assets/fonts/TheNautigal-Regular.ttf') . '" as="font" type="font/ttf" crossorigin>' . "\n"; }
}, 2);

add_filter('woocommerce_add_to_cart_fragments', function ($fragments) {
    ob_start(); adb_cart_link(); $fragments['a.adb-cart'] = ob_get_clean();
    return $fragments;
});
add_filter('body_class', function ($classes) { $classes[] = 'adb-site'; return $classes; });
add_filter('woocommerce_show_page_title', '__return_false');
add_filter('wp_sitemaps_posts_query_args', function ($args, $post_type) {
    if (in_array($post_type, ['product', 'produttore'], true)) { $args['adb_language'] = 'it'; $args['suppress_filters'] = false; }
    return $args;
}, 20, 2);
add_filter('wp_sitemaps_taxonomies_query_args', function ($args, $taxonomy) {
    if (in_array($taxonomy, ['product_cat', 'product_tag'], true) || strpos($taxonomy, 'pa_') === 0) { $args['adb_language'] = 'it'; }
    return $args;
}, 20, 2);
add_filter('ticinoweb_seo_canonical_url', function ($url) {
    $page = max((int) get_query_var('paged'), (int) get_query_var('page'));
    if ($page > 1 && !is_front_page()) {
        return remove_query_arg(array_merge(['orderby', 'min_price', 'max_price', 'adb_min_price', 'adb_max_price', 'adb_stock'], array_column(adb_catalog_filter_definitions(), 'param')), get_pagenum_link($page, false));
    }
    return $url;
});
// Local development must never send messages to real customers or the merchant.
add_filter('pre_wp_mail', function ($result) { return wp_get_environment_type() === 'local' ? false : $result; });
add_filter('ticinoweb_form_errors', function ($errors, $fields, $raw) {
    if (isset($raw['adb_contact']) && empty($raw['privacy'])) { $errors['privacy'] = __('Conferma di aver letto l’informativa sulla privacy.', 'amicidibacco'); }
    return $errors;
}, 10, 3);
add_action('woocommerce_review_order_before_submit', function () {
    woocommerce_form_field('adb_age', ['type' => 'checkbox', 'required' => true, 'label' => __('Confermo di avere almeno 18 anni.', 'amicidibacco')]);
});
add_action('woocommerce_checkout_process', function () {
    if (empty($_POST['adb_age'])) { wc_add_notice(__('Per acquistare devi confermare di avere almeno 18 anni.', 'amicidibacco'), 'error'); }
});
