<?php
/** Selection presentation reads the existing page, categories and WooCommerce products. */
defined( 'ABSPATH' ) || exit;

function adb_is_selection_page() {
    if ( ! is_page() ) { return false; }
    $page = get_queried_object();
    if ( ! $page instanceof WP_Post || ! has_shortcode( $page->post_content, 'adb_collection' ) ) { return false; }
    if ( preg_match( '/\[adb_collection\b([^\]]*)\]/', $page->post_content, $match ) ) {
        $atts = shortcode_parse_atts( $match[1] );
        return 'selections' === ( $atts['kind'] ?? 'selections' );
    }
    return false;
}

function adb_render_selections() {
    $page = max( 1, (int) get_query_var( 'paged' ), (int) get_query_var( 'page' ) );
    $tax = array( array( 'taxonomy' => 'product_cat', 'field' => 'slug', 'terms' => array( 'le-selezioni', 'le-selezioni-grappa' ) ) );
    $visibility = wc_get_product_visibility_term_ids();
    $excluded = array_filter( array( $visibility['exclude-from-catalog'] ?? 0, 'yes' === get_option( 'woocommerce_hide_out_of_stock_items' ) ? ( $visibility['outofstock'] ?? 0 ) : 0 ) );
    if ( $excluded ) { $tax[] = array( 'taxonomy' => 'product_visibility', 'field' => 'term_taxonomy_id', 'terms' => $excluded, 'operator' => 'NOT IN' ); }
    $query = new WP_Query( array( 'post_type' => 'product', 'post_status' => 'publish', 'posts_per_page' => 24, 'paged' => $page, 'adb_language' => 'it', 'tax_query' => $tax, 'orderby' => 'date', 'order' => 'DESC', 'ignore_sticky_posts' => true ) );
    $products = adb_products( array( 'ids' => wp_list_pluck( $query->posts, 'ID' ), 'limit' => 24 ) );
    $featured = 1 === $page && $products ? array_shift( $products ) : null;
    $terms = get_terms( array( 'taxonomy' => 'product_cat', 'slug' => array( 'le-selezioni', 'le-selezioni-grappa' ), 'hide_empty' => true, 'adb_language' => 'it' ) );
    $intro = get_the_excerpt( get_queried_object_id() );
    ob_start();
    ?>
    <div class="adb-collections">
        <header class="adb-collections__heading"><h1><?php echo esc_html( get_the_title( get_queried_object_id() ) ); ?></h1><div><p><?php echo esc_html( $intro ?: __( 'Scopri cosa racchiude ogni selezione e trova quella che fa per te.', 'amicidibacco' ) ); ?></p><nav aria-label="<?php esc_attr_e( 'Esplora le selezioni', 'amicidibacco' ); ?>"><?php foreach ( is_wp_error( $terms ) ? array() : $terms as $term ) : $url = get_term_link( $term ); if ( is_wp_error( $url ) ) { continue; } ?><a href="<?php echo esc_url( $url ); ?>"><?php echo esc_html( $term->name ); ?><?php echo adb_icon(); ?></a><?php endforeach; ?></nav></div></header>
        <?php if ( $featured ) : ?>
        <article class="adb-collection-feature" aria-labelledby="adb-collection-feature-title">
            <a class="adb-collection-feature__photo" href="<?php echo esc_url( $featured->get_permalink() ); ?>" aria-label="<?php echo esc_attr( $featured->get_name() ); ?>"><?php echo $featured->get_image( 'large', array( 'loading' => 'eager', 'fetchpriority' => 'high', 'decoding' => 'async' ) ); ?><?php if ( $featured->is_on_sale() ) : ?><span class="adb-product__badge"><?php esc_html_e( 'In offerta', 'amicidibacco' ); ?></span><?php endif; ?></a>
            <div class="adb-collection-feature__body">
                <?php if ( $featured->get_attribute( 'pa_cantina' ) ) : ?><p class="adb-collection-feature__producer"><?php echo esc_html( $featured->get_attribute( 'pa_cantina' ) ); ?></p><?php endif; ?>
                <h2 id="adb-collection-feature-title"><a href="<?php echo esc_url( $featured->get_permalink() ); ?>"><?php echo esc_html( $featured->get_name() ); ?></a></h2>
                <?php if ( trim( $featured->get_short_description() ) ) : ?><p class="adb-collection-feature__intro"><?php echo esc_html( wp_trim_words( wp_strip_all_tags( $featured->get_short_description() ), 45 ) ); ?></p><?php endif; ?>
                <p class="adb-collection-feature__price"><?php echo wp_kses_post( $featured->get_price_html() ); ?></p>
                <a class="adb-button" href="<?php echo esc_url( $featured->get_permalink() ); ?>"><?php esc_html_e( 'Scopri la selezione', 'amicidibacco' ); ?><?php echo adb_icon(); ?></a>
            </div>
        </article>
        <?php endif; ?>
        <section class="adb-collections__catalog" aria-labelledby="adb-collections-title"><div class="adb-collections__catalog-heading"><h2 id="adb-collections-title"><?php echo esc_html( $featured ? __( 'Le altre selezioni', 'amicidibacco' ) : __( 'Esplora le selezioni', 'amicidibacco' ) ); ?></h2><p><?php echo esc_html( sprintf( _n( '%d selezione disponibile', '%d selezioni disponibili', (int) $query->found_posts, 'amicidibacco' ), $query->found_posts ) ); ?></p></div>
            <?php if ( $products ) : ?><div class="adb-product-grid"><?php foreach ( $products as $product ) { adb_product_card( $product, 'adb-product--collection' ); } ?></div><?php elseif ( ! $featured ) : ?><p><?php esc_html_e( 'Al momento non ci sono selezioni disponibili.', 'amicidibacco' ); ?></p><a class="adb-link" href="<?php echo esc_url( adb_catalog_url() ); ?>"><?php esc_html_e( 'Esplora l’enoteca', 'amicidibacco' ); ?><?php echo adb_icon(); ?></a><?php endif; ?>
        </section>
        <?php if ( $query->max_num_pages > 1 ) : ?><nav class="adb-collection-pagination" aria-label="<?php esc_attr_e( 'Pagine delle selezioni', 'amicidibacco' ); ?>"><?php echo wp_kses_post( paginate_links( array( 'total' => $query->max_num_pages, 'current' => $page, 'prev_text' => __( 'Precedente', 'amicidibacco' ), 'next_text' => __( 'Successiva', 'amicidibacco' ), 'type' => 'list' ) ) ); ?></nav><?php endif; ?>
    </div>
    <?php
    return ob_get_clean();
}
