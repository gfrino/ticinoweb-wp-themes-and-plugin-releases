(() => {
	'use strict';

	const page = document.querySelector('[data-mira-service-page]');
	if (!page) return;

	const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
	const hero = page.querySelector('[data-mira-service-hero]');
	const visual = page.querySelector('[data-mira-service-visual]');
	const reveals = [...page.querySelectorAll('[data-mira-service-reveal]')];

	const showAll = () => {
		page.classList.remove('is-motion-ready');
		hero?.classList.add('is-cinema-ready');
		reveals.forEach((item) => item.classList.add('is-visible'));
		visual?.style.removeProperty('--mira-service-tilt-x');
		visual?.style.removeProperty('--mira-service-tilt-y');
		visual?.style.removeProperty('--mira-service-scroll-shift');
	};

	if (reducedMotion.matches) {
		showAll();
		return;
	}

	page.classList.add('is-motion-ready');
	window.requestAnimationFrame(() => {
		window.requestAnimationFrame(() => hero?.classList.add('is-cinema-ready'));
	});

	if ('IntersectionObserver' in window) {
		const revealObserver = new IntersectionObserver((entries, observer) => {
			entries.forEach((entry) => {
				if (!entry.isIntersecting) return;
				entry.target.classList.add('is-visible');
				observer.unobserve(entry.target);
			});
		}, { rootMargin: '0px 0px -10%', threshold: 0.12 });

		reveals.forEach((item) => revealObserver.observe(item));
	} else {
		reveals.forEach((item) => item.classList.add('is-visible'));
	}

	const finePointer = window.matchMedia('(hover: hover) and (pointer: fine)').matches;
	if (hero && visual && finePointer) {
		let heroRect;
		const updateHeroRect = () => {
			heroRect = hero.getBoundingClientRect();
		};

		hero.addEventListener('pointerenter', updateHeroRect);
		window.addEventListener('resize', updateHeroRect, { passive: true });

		hero.addEventListener('pointermove', (event) => {
			const rect = heroRect || hero.getBoundingClientRect();
			const relativeX = (event.clientX - rect.left) / rect.width;
			const relativeY = (event.clientY - rect.top) / rect.height;

			hero.style.setProperty('--mira-service-light-x', `${event.clientX - rect.left}px`);
			hero.style.setProperty('--mira-service-light-y', `${event.clientY - rect.top}px`);
			visual.style.setProperty('--mira-service-tilt-x', `${((relativeX - 0.5) * 10).toFixed(2)}px`);
			visual.style.setProperty('--mira-service-tilt-y', `${((relativeY - 0.5) * 8).toFixed(2)}px`);
			hero.classList.add('is-pointer-active');
		});

		hero.addEventListener('pointerleave', () => {
			hero.classList.remove('is-pointer-active');
			visual.style.setProperty('--mira-service-tilt-x', '0px');
			visual.style.setProperty('--mira-service-tilt-y', '0px');
		});
	}

	let scrollTicking = false;
	const updateDepth = () => {
		if (!hero || !visual) return;
		const rect = hero.getBoundingClientRect();
		if (rect.bottom > 0 && rect.top < window.innerHeight) {
			const progress = Math.max(0, Math.min(1, -rect.top / Math.max(rect.height, 1)));
			visual.style.setProperty('--mira-service-scroll-shift', `${(progress * 22).toFixed(2)}px`);
		}
	};

	window.addEventListener('scroll', () => {
		if (scrollTicking) return;
		scrollTicking = true;
		window.requestAnimationFrame(() => {
			updateDepth();
			scrollTicking = false;
		});
	}, { passive: true });
	updateDepth();

	reducedMotion.addEventListener?.('change', (event) => {
		if (event.matches) showAll();
	});
})();
