<?php
/**
 * Shared editorial template for Mira service pages.
 *
 * @package MiraServicesChildTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mira_service = isset( $args['service'] ) && is_array( $args['service'] ) ? $args['service'] : array();
if ( empty( $mira_service ) ) {
	return;
}

$mira_intro       = array_values( array_filter( (array) $mira_service['intro'] ) );
$mira_intro_title = array_shift( $mira_intro );
$mira_final_title = $mira_service['final_title'] ?: $mira_service['operation']['title'];
$mira_final_text  = $mira_service['final_text'] ?: $mira_service['operation']['text'];
$mira_has_visual  = has_post_thumbnail( $mira_service['id'] );
$mira_article_classes = 'mira-service-page';
if ( $mira_service['is_emergency'] ) {
	$mira_article_classes .= ' mira-service-page--emergency';
}
?>
<article <?php post_class( $mira_article_classes ); ?> data-mira-service-page>
	<header class="mira-service-hero<?php echo $mira_has_visual ? '' : ' mira-service-hero--without-visual'; ?>" data-mira-service-hero>
		<div class="mira-service-hero__ambient" aria-hidden="true"></div>
		<nav class="mira-service-breadcrumbs mira-service-shell" aria-label="<?php esc_attr_e( 'Percorso di navigazione', 'miraservices' ); ?>">
			<ol>
				<li><a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Home', 'miraservices' ); ?></a></li>
				<li><a href="<?php echo esc_url( home_url( '/#servizi' ) ); ?>"><?php esc_html_e( 'Servizi', 'miraservices' ); ?></a></li>
				<li aria-current="page"><?php echo esc_html( $mira_service['title'] ); ?></li>
			</ol>
		</nav>

		<div class="mira-service-hero__stage mira-service-shell">
			<div class="mira-service-hero__copy">
				<h1><?php echo esc_html( $mira_service['title'] ); ?></h1>
				<?php if ( $mira_service['lead'] ) : ?>
					<p class="mira-service-hero__lead"><?php echo esc_html( $mira_service['lead'] ); ?></p>
				<?php endif; ?>
				<?php if ( ! empty( $mira_service['hero_cta']['url'] ) && ! empty( $mira_service['hero_cta']['label'] ) ) : ?>
					<a class="mira-service-button" href="<?php echo esc_url( $mira_service['hero_cta']['url'] ); ?>"><?php echo esc_html( $mira_service['hero_cta']['label'] ); ?></a>
				<?php endif; ?>
			</div>
			<?php if ( $mira_has_visual ) : ?>
				<figure class="mira-service-hero__visual" data-mira-service-visual>
					<?php
					echo get_the_post_thumbnail(
						$mira_service['id'],
						'full',
						array(
							'loading'       => 'eager',
							'fetchpriority' => 'high',
							'decoding'      => 'async',
							'sizes'         => '(min-width: 1100px) 46vw, 100vw',
						)
					); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
					?>
					<?php if ( $mira_service['eyebrow'] ) : ?>
						<figcaption><?php echo esc_html( $mira_service['eyebrow'] ); ?></figcaption>
					<?php endif; ?>
				</figure>
			<?php endif; ?>
		</div>
	</header>

	<?php if ( $mira_intro_title ) : ?>
		<section class="mira-service-intro mira-service-shell" aria-labelledby="mira-service-intro-title" data-mira-service-reveal>
			<h2 id="mira-service-intro-title"><?php echo esc_html( $mira_intro_title ); ?></h2>
			<div class="mira-service-intro__copy">
				<?php foreach ( $mira_intro as $mira_paragraph ) : ?>
					<p><?php echo esc_html( $mira_paragraph ); ?></p>
				<?php endforeach; ?>
			</div>
		</section>
	<?php endif; ?>

	<section class="mira-service-scope" aria-labelledby="mira-service-scope-title" data-mira-service-reveal>
		<div class="mira-service-shell">
			<h2 id="mira-service-scope-title"><?php echo esc_html( $mira_service['scope']['title'] ); ?></h2>
			<ol class="mira-service-scope__list" data-mira-service-stagger>
				<?php foreach ( $mira_service['scope']['items'] as $mira_item ) : ?>
					<li><span><?php echo esc_html( $mira_item ); ?></span></li>
				<?php endforeach; ?>
			</ol>
		</div>
	</section>

	<?php if ( $mira_service['audience']['title'] && $mira_service['audience']['text'] ) : ?>
		<section class="mira-service-audience mira-service-shell" aria-labelledby="mira-service-audience-title" data-mira-service-reveal>
			<h2 id="mira-service-audience-title"><?php echo esc_html( $mira_service['audience']['title'] ); ?></h2>
			<div class="mira-service-audience__copy">
				<p><?php echo esc_html( $mira_service['audience']['text'] ); ?></p>
			</div>
		</section>
	<?php endif; ?>

	<?php if ( $mira_service['operation']['title'] && $mira_service['operation']['text'] ) : ?>
		<aside class="mira-service-operation mira-service-shell" aria-labelledby="mira-service-operation-title" data-mira-service-reveal>
			<div>
				<h2 id="mira-service-operation-title"><?php echo esc_html( $mira_service['operation']['title'] ); ?></h2>
				<p><?php echo esc_html( $mira_service['operation']['text'] ); ?></p>
			</div>
			<?php if ( ! empty( $mira_service['operation']['action']['url'] ) && ! empty( $mira_service['operation']['action']['label'] ) ) : ?>
				<a class="mira-service-button" href="<?php echo esc_url( $mira_service['operation']['action']['url'] ); ?>"><?php echo esc_html( $mira_service['operation']['action']['label'] ); ?></a>
			<?php endif; ?>
		</aside>
	<?php endif; ?>

	<?php if ( ! empty( $mira_service['related'] ) ) : ?>
		<section class="mira-service-related mira-service-shell" aria-labelledby="mira-service-related-title" data-mira-service-reveal>
			<h2 id="mira-service-related-title"><?php esc_html_e( 'Servizi che lavorano insieme', 'miraservices' ); ?></h2>
			<ul>
				<?php foreach ( $mira_service['related'] as $mira_related ) : ?>
					<li>
						<a href="<?php echo esc_url( $mira_related['url'] ); ?>">
							<span class="mira-service-related__index"><?php echo esc_html( str_pad( (string) $mira_related['index'], 2, '0', STR_PAD_LEFT ) ); ?></span>
							<strong><?php echo esc_html( $mira_related['title'] ); ?></strong>
							<span class="mira-service-related__action"><?php esc_html_e( 'Scopri il servizio', 'miraservices' ); ?></span>
						</a>
					</li>
				<?php endforeach; ?>
			</ul>
		</section>
	<?php endif; ?>

	<?php if ( $mira_final_title && ! empty( $mira_service['final_cta']['url'] ) && ! empty( $mira_service['final_cta']['label'] ) ) : ?>
		<section class="mira-service-contact" aria-labelledby="mira-service-contact-title" data-mira-service-reveal>
			<div class="mira-service-contact__ambient" aria-hidden="true"></div>
			<div class="mira-service-contact__inner mira-service-shell">
				<div>
					<h2 id="mira-service-contact-title"><?php echo esc_html( $mira_final_title ); ?></h2>
					<?php if ( $mira_final_text ) : ?><p><?php echo esc_html( $mira_final_text ); ?></p><?php endif; ?>
				</div>
				<a class="mira-service-button mira-service-button--light" href="<?php echo esc_url( $mira_service['final_cta']['url'] ); ?>"><?php echo esc_html( $mira_service['final_cta']['label'] ); ?></a>
			</div>
		</section>
	<?php endif; ?>
</article>
