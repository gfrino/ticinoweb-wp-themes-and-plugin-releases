<?php
/**
 * Wire the theme's two forms (contact page + "Schedule service" modal) to the
 * parent theme's AJAX handler (ticinoweb-ai-theme/inc/form-handler.php).
 *
 * Until 1.9.3 both forms had no name attributes and no submit handler: pressing
 * "Send" simply reloaded the page and nothing was stored or emailed. Submissions
 * now go to admin-ajax.php?action=ticinoweb_submit_form, are saved in the site's
 * {prefix}ticinoweb_form_submissions table (ticinoWEB CMS → "Invii Ricevuti") and
 * emailed to the site's contact email (ticinoWEB CMS → contact info; falls back to
 * the WordPress admin email). Per-site, nothing hardcoded.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

add_action( 'wp_enqueue_scripts', 'ecoproplumbing_forms_script', 30 );
function ecoproplumbing_forms_script() {
    // Config normally comes from the parent's localize on 'ticinoweb-ai-main';
    // print our own so this works even if that handle is missing on a request.
    $cfg = array(
        'ajax_url'      => admin_url( 'admin-ajax.php' ),
        'token_action'  => 'ticinoweb_form_token',
        'submit_action' => 'ticinoweb_submit_form',
        'recaptcha_site_key' => (string) get_option( 'ticinoweb_recaptcha_site_key', '' ),
        'i18n'          => array(
            'sending' => __( 'Sending…', 'ecoproplumbing-child-theme' ),
            'success' => __( 'Thank you! Your message has been sent. We will get back to you shortly.', 'ecoproplumbing-child-theme' ),
            'error'   => __( 'Something went wrong, please try again or call us.', 'ecoproplumbing-child-theme' ),
            'rate'    => __( 'Too many messages in a short time. Please try again in a few minutes or call us.', 'ecoproplumbing-child-theme' ),
            'fields'  => array(
                'nome'      => __( 'Please enter your name.', 'ecoproplumbing-child-theme' ),
                'email'     => __( 'Please enter a valid email address.', 'ecoproplumbing-child-theme' ),
                'messaggio' => __( 'Please write a message of at least 5 characters.', 'ecoproplumbing-child-theme' ),
            ),
        ),
    );
    // reCAPTCHA v3: the parent verifies the token server-side when a secret is
    // configured, but nothing loads the Google script. Load it only when the site
    // has a site key, so sites without reCAPTCHA pay nothing.
    $deps = array();
    if ( $cfg['recaptcha_site_key'] !== '' ) {
        wp_enqueue_script( 'google-recaptcha-v3', 'https://www.google.com/recaptcha/api.js?render=' . rawurlencode( $cfg['recaptcha_site_key'] ), array(), null, true );
        $deps[] = 'google-recaptcha-v3';
    }
    wp_register_script( 'ecoproplumbing-forms', false, $deps, null, true );
    wp_enqueue_script( 'ecoproplumbing-forms' );
    wp_add_inline_script( 'ecoproplumbing-forms', 'window.ecoFormsCfg = ' . wp_json_encode( $cfg ) . ';' . ecoproplumbing_forms_js() );
}

function ecoproplumbing_forms_js() {
    return <<<'JS'
(function () {
    var cfg = window.ecoFormsCfg || {};
    var forms = document.querySelectorAll('form.eco-html-form, form.booking-modal-form');
    if (!forms.length || !cfg.ajax_url) { return; }

    function val(form, name) {
        var el = form.querySelector('[name="' + name + '"]');
        return el ? String(el.value || '').trim() : '';
    }

    function notice(form, text, ok) {
        var box = form.querySelector('.eco-form-notice');
        if (!box) {
            box = document.createElement('div');
            box.className = 'eco-form-notice';
            box.setAttribute('role', 'status');
            form.appendChild(box);
        }
        box.textContent = text;
        box.style.marginTop = '1rem';
        box.style.padding = '.75rem 1rem';
        box.style.borderRadius = '8px';
        box.style.fontWeight = '600';
        box.style.background = ok ? '#e6f7ee' : '#fdecea';
        box.style.color = ok ? '#1b7f4b' : '#b3261e';
    }

    function getToken() {
        return fetch(cfg.ajax_url + '?action=' + encodeURIComponent(cfg.token_action), { credentials: 'same-origin', cache: 'no-store' })
            .then(function (r) { return r.json(); })
            .then(function (j) { return j && j.success && j.data ? j.data.token : ''; });
    }

    function recaptcha() {
        if (!cfg.recaptcha_site_key || !window.grecaptcha) { return Promise.resolve(''); }
        return new Promise(function (resolve) {
            window.grecaptcha.ready(function () {
                window.grecaptcha.execute(cfg.recaptcha_site_key, { action: 'contact' }).then(resolve, function () { resolve(''); });
            });
        });
    }

    Array.prototype.forEach.call(forms, function (form) {
        form.addEventListener('submit', function (e) {
            e.preventDefault();
            if (!form.checkValidity()) { form.reportValidity(); return; }

            var btn = form.querySelector('[type="submit"]');
            var label = btn ? btn.textContent : '';
            if (btn) { btn.disabled = true; btn.textContent = cfg.i18n.sending; }

            var nome = val(form, 'nome');
            var cognome = val(form, 'cognome');
            if (cognome) { nome = (nome + ' ' + cognome).trim(); }

            Promise.all([getToken(), recaptcha()]).then(function (res) {
                var fd = new FormData();
                fd.append('action', cfg.submit_action);
                fd.append('token', res[0]);
                fd.append('nome', nome);
                fd.append('email', val(form, 'email'));
                fd.append('telefono', val(form, 'telefono'));
                fd.append('oggetto', val(form, 'oggetto'));
                fd.append('messaggio', val(form, 'messaggio'));
                fd.append('tw_hp', val(form, 'tw_hp'));
                if (res[1]) { fd.append('recaptcha_token', res[1]); }
                return fetch(cfg.ajax_url, { method: 'POST', body: fd, credentials: 'same-origin' });
            }).then(function (r) { return r.json(); }).then(function (j) {
                if (j && j.success) {
                    notice(form, cfg.i18n.success, true);
                    form.reset();
                } else {
                    var d = (j && j.data) || {}, msg = d.message || cfg.i18n.error;
                    if (d.code === 'rate') { msg = cfg.i18n.rate; }
                    if (d.fields) {
                        // The parent's messages are Italian: show ours, one per wrong field.
                        msg = Object.keys(d.fields).map(function (k) { return cfg.i18n.fields[k] || d.fields[k]; }).join(' ');
                    }
                    notice(form, msg, false);
                }
            }).catch(function () {
                notice(form, cfg.i18n.error, false);
            }).then(function () {
                if (btn) { btn.disabled = false; btn.textContent = label; }
            });
        });
    });
})();
JS;
}
