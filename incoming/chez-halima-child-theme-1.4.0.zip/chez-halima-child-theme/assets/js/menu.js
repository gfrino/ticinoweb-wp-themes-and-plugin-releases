/* Header e pagina di Chez Halima.
 * - Telefono e tablet: il pulsante apre e chiude la navigazione del parent.
 * - Home: l'header sta trasparente sopra la foto e diventa bianco e fisso quando si scorre.
 * - Ricerca a tendina, finestra della newsletter, «torna su», riapertura delle preferenze cookie.
 * Senza questo script il menu resta visibile come lo stampa il parent. */
(function () {
    var header = document.querySelector('.site-header');
    var nav = header && header.querySelector('.main-navigation');
    var button = header && header.querySelector('.ch-menu-toggle');
    if (!nav || !button) {
        return;
    }
    var label = button.querySelector('.ch-menu-toggle__label');
    var compact = window.matchMedia('(max-width: 849px)');

    // Il pulsante va prima del logo, a sinistra come su chezhalima.ch, e prima del menu per il tasto Tab.
    header.insertBefore(button, header.firstChild);
    nav.id = nav.id || 'ch-primary-nav';
    button.setAttribute('aria-controls', nav.id);
    header.classList.add('ch-nav-ready');

    // Ricerca e newsletter in fondo al pannello del menu da telefono.
    var extra = header.querySelector('.ch-mobile-extra');
    if (extra) {
        nav.appendChild(extra);
    }

    function setOpen(open) {
        header.classList.toggle('is-menu-open', open);
        button.setAttribute('aria-expanded', open ? 'true' : 'false');
        label.textContent = open ? button.dataset.labelClose : button.dataset.labelOpen;
    }

    button.addEventListener('click', function () {
        setOpen(button.getAttribute('aria-expanded') !== 'true');
    });

    document.addEventListener('keydown', function (event) {
        if (event.key === 'Escape' && header.classList.contains('is-menu-open')) {
            setOpen(false);
            button.focus();
        }
    });

    nav.addEventListener('click', function (event) {
        if (event.target.closest('a')) {
            setOpen(false);
        }
    });

    compact.addEventListener('change', function () {
        setOpen(false);
    });

    if (document.body.classList.contains('home')) {
        var ticking = false;
        var update = function () {
            header.classList.toggle('is-stuck', window.scrollY > 160);
            ticking = false;
        };
        window.addEventListener('scroll', function () {
            if (!ticking) {
                ticking = true;
                window.requestAnimationFrame(update);
            }
        }, { passive: true });
        update();
    }
})();

(function () {
    // Ricerca a tendina dell'header: si chiude cliccando fuori o con Esc, e il campo prende il fuoco.
    var search = document.querySelector('.ch-hsearch');
    if (search) {
        search.addEventListener('toggle', function () {
            if (search.open) {
                var field = search.querySelector('input[type="search"]');
                if (field) {
                    field.focus();
                }
            }
        });
        document.addEventListener('click', function (event) {
            if (search.open && !search.contains(event.target)) {
                search.open = false;
            }
        });
        document.addEventListener('keydown', function (event) {
            if (event.key === 'Escape' && search.open) {
                search.open = false;
                search.querySelector('summary').focus();
            }
        });
    }

    // Finestra della newsletter.
    var dialog = document.getElementById('ch-newsletter');
    if (dialog && typeof dialog.showModal === 'function') {
        document.querySelectorAll('.ch-newsletter-open').forEach(function (opener) {
            opener.addEventListener('click', function () {
                dialog.showModal();
            });
        });
        dialog.addEventListener('click', function (event) {
            if (event.target === dialog) {
                dialog.close();
            }
        });
    } else {
        document.querySelectorAll('.ch-newsletter-open').forEach(function (opener) {
            opener.hidden = true;
        });
    }

    // «Torna su»: compare dopo un po' di scorrimento.
    var top = document.querySelector('.ch-totop');
    if (top) {
        var ticking = false;
        var update = function () {
            top.hidden = window.scrollY < 400;
            ticking = false;
        };
        window.addEventListener('scroll', function () {
            if (!ticking) {
                ticking = true;
                window.requestAnimationFrame(update);
            }
        }, { passive: true });
        top.addEventListener('click', function () {
            var reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
            window.scrollTo({ top: 0, behavior: reduce ? 'auto' : 'smooth' });
        });
        update();
    }

    // Preferenze cookie: il banner del parent ricompare se si toglie la scelta già fatta e si ricarica.
    var hasConsent = /(?:^|; )tw_cookie_consent=/.test(document.cookie);
    function reopenCookies(event) {
        if (event) {
            event.preventDefault();
        }
        document.cookie = 'tw_cookie_consent=; Max-Age=0; path=/; SameSite=Lax';
        window.location.reload();
    }
    var revisit = document.querySelector('.ch-cookie-revisit');
    if (revisit) {
        revisit.hidden = !hasConsent;
        revisit.addEventListener('click', reopenCookies);
    }
    document.querySelectorAll('a[href$="#ch-cookie-preferences"]').forEach(function (link) {
        link.addEventListener('click', reopenCookies);
    });
})();
