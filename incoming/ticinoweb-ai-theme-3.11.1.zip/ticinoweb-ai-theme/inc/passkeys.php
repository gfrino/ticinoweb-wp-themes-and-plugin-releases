<?php
/**
 * Passkey (WebAuthn) per ticinoweb-ai-theme
 *
 * Aggiunge il login con passkey ACCANTO alla password, non al suo posto: la
 * password continua a funzionare esattamente come prima e resta la via di
 * accesso garantita se un sito cambia tema.
 *
 * Perche' senza librerie esterne: il tema si deploya con un rsync di file
 * semplici, senza `composer install` sul server. Una dipendenza Composer
 * avrebbe portato una vendor/ dentro un tema condiviso. E' sostenibile perche'
 * le passkey usano attestation "none": non dovendo validare catene di
 * certificati serve solo un decoder CBOR ridotto, la conversione della chiave
 * COSE in PEM e openssl_verify(). Qui NON si implementa crittografia a mano:
 * la verifica della firma la fa OpenSSL.
 *
 * Ambito multisite: wp_usermeta e' CONDIVISA fra tutti i siti del network,
 * mentre una passkey e' legata al dominio (Relying Party ID). Ogni credenziale
 * viene quindi salvata con il suo rp_id e filtrata per dominio, altrimenti la
 * passkey di un sito verrebbe proposta su un altro dove non puo' funzionare.
 *
 * @package ticinoweb-ai-theme
 * @since   3.7.0
 */

if (!defined('ABSPATH')) {
    exit;
}

define('TW_PK_META',        '_tw_passkeys');       // array completo delle credenziali
define('TW_PK_CRED_META',   '_tw_passkey_cred');   // una riga per credenziale, per la ricerca
define('TW_PK_HANDLE_META', '_tw_passkey_handle'); // user handle opaco (niente PII)
define('TW_PK_TTL',         300);                  // validita' della challenge, secondi

/* -------------------------------------------------------------------------
 * base64url
 * ---------------------------------------------------------------------- */

function tw_pk_b64url_encode($bin) {
    return rtrim(strtr(base64_encode($bin), '+/', '-_'), '=');
}

function tw_pk_b64url_decode($str) {
    $str = strtr((string) $str, '-_', '+/');
    $pad = strlen($str) % 4;
    if ($pad) {
        $str .= str_repeat('=', 4 - $pad);
    }
    $out = base64_decode($str, true);
    return ($out === false) ? '' : $out;
}

/* -------------------------------------------------------------------------
 * CBOR: sottoinsieme sufficiente per attestationObject e chiavi COSE
 * ---------------------------------------------------------------------- */

function tw_pk_cbor_decode($data, &$off) {
    $len = strlen($data);
    if ($off >= $len) {
        throw new Exception('CBOR: dati troncati');
    }

    $ib    = ord($data[$off++]);
    $major = $ib >> 5;
    $ai    = $ib & 0x1f;
    $val   = 0;

    if ($ai < 24) {
        $val = $ai;
    } elseif ($ai === 24) {
        if ($off + 1 > $len) throw new Exception('CBOR: dati troncati');
        $val = ord($data[$off++]);
    } elseif ($ai === 25) {
        if ($off + 2 > $len) throw new Exception('CBOR: dati troncati');
        $val = unpack('n', substr($data, $off, 2))[1];
        $off += 2;
    } elseif ($ai === 26) {
        if ($off + 4 > $len) throw new Exception('CBOR: dati troncati');
        $val = unpack('N', substr($data, $off, 4))[1];
        $off += 4;
    } else {
        // Interi a 64 bit e lunghezze indefinite non compaiono nei messaggi
        // WebAuthn che trattiamo: rifiutiamo invece di indovinare.
        throw new Exception('CBOR: forma non supportata');
    }

    switch ($major) {
        case 0: // intero senza segno
            return $val;
        case 1: // intero negativo
            return -1 - $val;
        case 2: // byte string
        case 3: // testo
            if ($off + $val > $len) throw new Exception('CBOR: dati troncati');
            $s = substr($data, $off, $val);
            $off += $val;
            return $s;
        case 4: // array
            $arr = array();
            for ($i = 0; $i < $val; $i++) {
                $arr[] = tw_pk_cbor_decode($data, $off);
            }
            return $arr;
        case 5: // mappa
            $map = array();
            for ($i = 0; $i < $val; $i++) {
                $k = tw_pk_cbor_decode($data, $off);
                $v = tw_pk_cbor_decode($data, $off);
                $map[is_int($k) ? $k : (string) $k] = $v;
            }
            return $map;
        case 7: // valori semplici
            if ($ai === 20) return false;
            if ($ai === 21) return true;
            if ($ai === 22) return null;
            return $val;
    }

    throw new Exception('CBOR: major type non supportato');
}

/* -------------------------------------------------------------------------
 * DER / conversione della chiave pubblica COSE in PEM
 * ---------------------------------------------------------------------- */

function tw_pk_der_len($n) {
    if ($n < 128) {
        return chr($n);
    }
    $b = '';
    while ($n > 0) {
        $b = chr($n & 0xff) . $b;
        $n >>= 8;
    }
    return chr(0x80 | strlen($b)) . $b;
}

function tw_pk_der_tlv($tag, $content) {
    return chr($tag) . tw_pk_der_len(strlen($content)) . $content;
}

function tw_pk_der_int($bytes) {
    $bytes = ltrim($bytes, "\x00");
    if ($bytes === '') {
        $bytes = "\x00";
    }
    if (ord($bytes[0]) & 0x80) {
        $bytes = "\x00" . $bytes; // INTEGER DER e' con segno
    }
    return tw_pk_der_tlv(0x02, $bytes);
}

function tw_pk_pem($der) {
    return "-----BEGIN PUBLIC KEY-----\n"
         . chunk_split(base64_encode($der), 64, "\n")
         . "-----END PUBLIC KEY-----\n";
}

/**
 * Chiave COSE -> PEM. Supporta ES256 (P-256, quasi tutte le passkey) e RS256
 * (alcuni autenticatori Windows Hello di vecchia data).
 */
function tw_pk_cose_to_pem($cose) {
    if (!is_array($cose) || !isset($cose[1])) {
        return null;
    }
    $kty = $cose[1];
    $alg = isset($cose[3]) ? (int) $cose[3] : 0;

    if ($kty === 2) { // EC2
        if (!isset($cose[-1]) || (int) $cose[-1] !== 1) {
            return null; // solo curva P-256
        }
        if (!isset($cose[-2], $cose[-3])) {
            return null;
        }
        $x = $cose[-2];
        $y = $cose[-3];
        if (strlen($x) !== 32 || strlen($y) !== 32) {
            return null;
        }
        // SubjectPublicKeyInfo per id-ecPublicKey + prime256v1, punto non compresso
        $der = hex2bin('3059301306072a8648ce3d020106082a8648ce3d03010703420004') . $x . $y;
        return array('pem' => tw_pk_pem($der), 'alg' => $alg ?: -7);
    }

    if ($kty === 3) { // RSA
        if (!isset($cose[-1], $cose[-2])) {
            return null;
        }
        $rsa   = tw_pk_der_tlv(0x30, tw_pk_der_int($cose[-1]) . tw_pk_der_int($cose[-2]));
        $algid = tw_pk_der_tlv(0x30, hex2bin('06092a864886f70d010101') . "\x05\x00");
        $bits  = tw_pk_der_tlv(0x03, "\x00" . $rsa);
        $der   = tw_pk_der_tlv(0x30, $algid . $bits);
        return array('pem' => tw_pk_pem($der), 'alg' => $alg ?: -257);
    }

    return null;
}

/* -------------------------------------------------------------------------
 * authenticatorData
 * ---------------------------------------------------------------------- */

function tw_pk_parse_auth_data($ad) {
    if (strlen($ad) < 37) {
        return null;
    }
    $out = array(
        'rp_id_hash' => substr($ad, 0, 32),
        'flags'      => ord($ad[32]),
        'sign_count' => unpack('N', substr($ad, 33, 4))[1],
        'cred_id'    => null,
        'cose'       => null,
    );

    if ($out['flags'] & 0x40) { // AT: dati della credenziale presenti
        $off = 37;
        if (strlen($ad) < $off + 18) {
            return null;
        }
        $off += 16; // AAGUID, non usato con attestation "none"
        $clen = unpack('n', substr($ad, $off, 2))[1];
        $off += 2;
        if ($clen < 1 || $clen > 1023 || strlen($ad) < $off + $clen) {
            return null;
        }
        $out['cred_id'] = substr($ad, $off, $clen);
        $off += $clen;
        $out['cose'] = tw_pk_cbor_decode($ad, $off);
    }

    return $out;
}

/* -------------------------------------------------------------------------
 * Identita' del sito (Relying Party)
 * ---------------------------------------------------------------------- */

/**
 * Il Relying Party ID e' l'HOST, senza schema ne' percorso: per un multisite a
 * sottocartelle tutti i sottositi dello stesso dominio condividono quindi lo
 * stesso rp_id, ed e' corretto cosi' secondo lo standard.
 */
function tw_pk_rp_id() {
    $host = wp_parse_url(home_url(), PHP_URL_HOST);
    return $host ? strtolower($host) : '';
}

function tw_pk_origin() {
    $u      = wp_parse_url(home_url());
    $scheme = isset($u['scheme']) ? $u['scheme'] : 'https';
    $host   = isset($u['host']) ? $u['host'] : '';
    $port   = isset($u['port']) ? ':' . $u['port'] : '';
    return $scheme . '://' . $host . $port;
}

/**
 * WebAuthn e' disponibile solo in contesto sicuro. Senza HTTPS il browser
 * rifiuta la chiamata, quindi non mostriamo nemmeno l'interfaccia.
 *
 * Non ci si affida al solo is_ssl(): legge $_SERVER['HTTPS'] e la porta, che
 * dietro un proxy o un terminatore TLS possono non essere valorizzati, e in
 * quel caso l'interfaccia non comparirebbe mai su un sito perfettamente in
 * HTTPS. Lo schema di home_url() e' la configurazione autorevole del sito.
 */
function tw_pk_available() {
    if (tw_pk_rp_id() === '') {
        return false;
    }
    return is_ssl() || wp_parse_url(home_url(), PHP_URL_SCHEME) === 'https';
}

/* -------------------------------------------------------------------------
 * Archiviazione delle credenziali
 * ---------------------------------------------------------------------- */

function tw_pk_get_user_passkeys($user_id) {
    $list = get_user_meta((int) $user_id, TW_PK_META, true);
    return is_array($list) ? $list : array();
}

/** Solo le passkey utilizzabili sul dominio corrente. */
function tw_pk_get_user_passkeys_for_site($user_id) {
    $rp  = tw_pk_rp_id();
    $out = array();
    foreach (tw_pk_get_user_passkeys($user_id) as $pk) {
        if (isset($pk['rp_id']) && $pk['rp_id'] === $rp) {
            $out[] = $pk;
        }
    }
    return $out;
}

function tw_pk_save_user_passkeys($user_id, $list) {
    update_user_meta((int) $user_id, TW_PK_META, array_values($list));
}

/**
 * Restituisce i descrittori delle credenziali attive registrate per questo dominio (RP ID).
 * Se viene specificato un utente (username o email), restringe alle sole credenziali di quell'utente.
 */
function tw_pk_get_allowed_credentials_for_site($username = '') {
    $rp = tw_pk_rp_id();
    if ($rp === '') {
        return array();
    }

    $username = trim((string) $username);
    if ($username !== '') {
        $user = get_user_by('login', $username);
        if (!$user && is_email($username)) {
            $user = get_user_by('email', $username);
        }
        if (!$user) {
            return array();
        }
        $out = array();
        foreach (tw_pk_get_user_passkeys_for_site($user->ID) as $pk) {
            if (!empty($pk['id'])) {
                $out[] = array(
                    'type' => 'public-key',
                    'id'   => $pk['id'],
                );
            }
        }
        return $out;
    }

    // Nessun utente specificato: recupera tutte le credenziali valide per questo RP ID
    global $wpdb;
    $rows = $wpdb->get_col($wpdb->prepare(
        "SELECT meta_value FROM {$wpdb->usermeta} WHERE meta_key = %s",
        TW_PK_META
    ));

    $out  = array();
    $seen = array();
    if (is_array($rows)) {
        foreach ($rows as $row) {
            $list = maybe_unserialize($row);
            if (is_array($list)) {
                foreach ($list as $pk) {
                    if (isset($pk['rp_id'], $pk['id']) && $pk['rp_id'] === $rp && !isset($seen[$pk['id']])) {
                        $seen[$pk['id']] = true;
                        $out[] = array(
                            'type' => 'public-key',
                            'id'   => $pk['id'],
                        );
                    }
                }
            }
        }
    }

    return $out;
}

/**
 * Ricerca dell'utente a partire dall'ID della credenziale.
 *
 * La riga TW_PK_CRED_META esiste come indice interrogabile: cercare dentro
 * l'array serializzato di TW_PK_META non sarebbe affidabile. blog_id => 0
 * estende la ricerca a tutta la rete, perche' wp_usermeta e' globale; il
 * vincolo per dominio lo impone comunque il confronto sull'rp_id piu' avanti.
 */
function tw_pk_find_user_by_cred($cred_b64) {
    if ($cred_b64 === '') {
        return 0;
    }
    $q = new WP_User_Query(array(
        'blog_id'    => 0,
        'meta_key'   => TW_PK_CRED_META,
        'meta_value' => $cred_b64,
        'number'     => 2,
        'fields'     => 'ID',
        'count_total'=> false,
    ));
    $res = $q->get_results();
    // Un ID credenziale e' unico: se due utenti lo rivendicano, qualcosa non
    // torna e rifiutiamo invece di scegliere arbitrariamente.
    return (is_array($res) && count($res) === 1) ? (int) $res[0] : 0;
}

/* -------------------------------------------------------------------------
 * Challenge: casuale, monouso, con scadenza
 * ---------------------------------------------------------------------- */

function tw_pk_new_challenge($purpose) {
    $challenge = random_bytes(32);
    $token     = wp_generate_password(32, false, false);
    set_transient('tw_pk_' . $purpose . '_' . $token, base64_encode($challenge), TW_PK_TTL);
    return array($challenge, $token);
}

function tw_pk_take_challenge($purpose, $token) {
    $token = preg_replace('/[^A-Za-z0-9]/', '', (string) $token);
    if ($token === '') {
        return null;
    }
    $key = 'tw_pk_' . $purpose . '_' . $token;
    $val = get_transient($key);
    if ($val === false) {
        return null;
    }
    delete_transient($key); // monouso: niente replay
    return base64_decode($val);
}

/* -------------------------------------------------------------------------
 * Verifiche
 * ---------------------------------------------------------------------- */

/** Restituisce '' se tutto e' valido, altrimenti il motivo del rifiuto. */
function tw_pk_verify_client_data($json, $expected_type, $challenge) {
    $d = json_decode($json, true);
    if (!is_array($d)) {
        return 'clientDataJSON illeggibile';
    }
    if (!isset($d['type']) || !hash_equals($expected_type, (string) $d['type'])) {
        return 'tipo di operazione non valido';
    }
    if (!isset($d['challenge']) || !hash_equals(tw_pk_b64url_encode($challenge), (string) $d['challenge'])) {
        return 'challenge non corrispondente';
    }
    // L'origin va confrontato per intero: un sottodominio omografo non deve passare.
    if (!isset($d['origin']) || !hash_equals(tw_pk_origin(), (string) $d['origin'])) {
        return 'origin non corrispondente';
    }
    return '';
}

/**
 * Freno agli endpoint AJAX: tw-login-throttle.php sorveglia i POST su
 * wp-login.php e non coprirebbe queste rotte.
 */
function tw_pk_rate_ok($bucket, $max = 20, $window = 600) {
    $ip  = isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '';
    $key = 'tw_pk_rl_' . $bucket . '_' . md5($ip);
    $n   = (int) get_transient($key);
    if ($n >= $max) {
        return false;
    }
    set_transient($key, $n + 1, $window);
    return true;
}

function tw_pk_post($key) {
    return isset($_POST[$key]) ? (string) wp_unslash($_POST[$key]) : '';
}

/* -------------------------------------------------------------------------
 * REGISTRAZIONE (utente gia' autenticato, dal proprio profilo)
 * ---------------------------------------------------------------------- */

add_action('wp_ajax_tw_passkey_register_options', 'tw_pk_ajax_register_options');
function tw_pk_ajax_register_options() {
    check_ajax_referer('tw_passkey_reg', 'nonce');

    $user = wp_get_current_user();
    if (!$user || !$user->ID) {
        wp_send_json_error(array('message' => 'Non autenticato.'));
    }
    if (!tw_pk_available()) {
        wp_send_json_error(array('message' => 'Le passkey richiedono una connessione HTTPS.'));
    }

    // Handle opaco e stabile: lo standard sconsiglia di esporre dati personali
    // (username, email, ID numerico) nello user handle, che resta memorizzato
    // nell'autenticatore.
    $handle = get_user_meta($user->ID, TW_PK_HANDLE_META, true);
    if (!$handle) {
        $handle = tw_pk_b64url_encode(random_bytes(32));
        update_user_meta($user->ID, TW_PK_HANDLE_META, $handle);
    }

    // Evita di registrare due volte lo stesso autenticatore.
    $exclude = array();
    foreach (tw_pk_get_user_passkeys_for_site($user->ID) as $pk) {
        $exclude[] = array('type' => 'public-key', 'id' => $pk['id']);
    }

    list($challenge, $token) = tw_pk_new_challenge('reg');

    wp_send_json_success(array(
        'token'              => $token,
        'challenge'          => tw_pk_b64url_encode($challenge),
        'rp'                 => array('id' => tw_pk_rp_id(), 'name' => get_bloginfo('name')),
        'user'               => array(
            'id'          => $handle,
            'name'        => $user->user_login,
            'displayName' => $user->display_name ? $user->display_name : $user->user_login,
        ),
        'excludeCredentials' => $exclude,
        'timeout'            => TW_PK_TTL * 1000,
    ));
}

add_action('wp_ajax_tw_passkey_register_verify', 'tw_pk_ajax_register_verify');
function tw_pk_ajax_register_verify() {
    check_ajax_referer('tw_passkey_reg', 'nonce');

    $user_id = get_current_user_id();
    if (!$user_id) {
        wp_send_json_error(array('message' => 'Non autenticato.'));
    }

    $challenge = tw_pk_take_challenge('reg', tw_pk_post('token'));
    if ($challenge === null) {
        wp_send_json_error(array('message' => 'Richiesta scaduta, riprova.'));
    }

    $client_data = tw_pk_b64url_decode(tw_pk_post('clientDataJSON'));
    $att_raw     = tw_pk_b64url_decode(tw_pk_post('attestationObject'));
    if ($client_data === '' || $att_raw === '') {
        wp_send_json_error(array('message' => 'Dati della credenziale mancanti.'));
    }

    $err = tw_pk_verify_client_data($client_data, 'webauthn.create', $challenge);
    if ($err !== '') {
        wp_send_json_error(array('message' => 'Verifica fallita: ' . $err));
    }

    try {
        $off = 0;
        $att = tw_pk_cbor_decode($att_raw, $off);
        if (!is_array($att) || !isset($att['authData'])) {
            throw new Exception('attestationObject incompleto');
        }
        $ad = tw_pk_parse_auth_data($att['authData']);
    } catch (Exception $e) {
        wp_send_json_error(array('message' => 'Credenziale illeggibile.'));
    }

    if (!$ad || !$ad['cred_id'] || !$ad['cose']) {
        wp_send_json_error(array('message' => 'Credenziale incompleta.'));
    }
    if (!hash_equals(hash('sha256', tw_pk_rp_id(), true), $ad['rp_id_hash'])) {
        wp_send_json_error(array('message' => 'Dominio non corrispondente.'));
    }
    if (!($ad['flags'] & 0x01)) { // UP: presenza dell'utente
        wp_send_json_error(array('message' => 'Presenza dell\'utente non confermata.'));
    }

    $key = tw_pk_cose_to_pem($ad['cose']);
    if (!$key || openssl_pkey_get_public($key['pem']) === false) {
        wp_send_json_error(array('message' => 'Tipo di chiave non supportato.'));
    }

    $cred_b64 = tw_pk_b64url_encode($ad['cred_id']);

    // L'ID credenziale deve essere unico su tutta la rete.
    $owner = tw_pk_find_user_by_cred($cred_b64);
    if ($owner && $owner !== $user_id) {
        wp_send_json_error(array('message' => 'Credenziale gia' . chr(39) . ' registrata da un altro utente.'));
    }

    $list = tw_pk_get_user_passkeys($user_id);
    foreach ($list as $pk) {
        if (isset($pk['id']) && hash_equals($pk['id'], $cred_b64)) {
            wp_send_json_error(array('message' => 'Questa passkey e' . chr(39) . ' gia' . chr(39) . ' registrata.'));
        }
    }

    $label = sanitize_text_field(tw_pk_post('label'));
    if ($label === '') {
        $label = 'Passkey';
    }

    $list[] = array(
        'id'         => $cred_b64,
        'pem'        => $key['pem'],
        'alg'        => (int) $key['alg'],
        'sign_count' => (int) $ad['sign_count'],
        'rp_id'      => tw_pk_rp_id(),
        'label'      => mb_substr($label, 0, 60),
        'created'    => time(),
        'last_used'  => 0,
    );
    tw_pk_save_user_passkeys($user_id, $list);
    add_user_meta($user_id, TW_PK_CRED_META, $cred_b64); // indice, non unico

    wp_send_json_success(array(
        'message' => 'Passkey registrata.',
        'rows'    => tw_pk_render_rows($user_id),
    ));
}

/* -------------------------------------------------------------------------
 * LOGIN con passkey (utente non autenticato)
 * ---------------------------------------------------------------------- */

add_action('wp_ajax_nopriv_tw_passkey_auth_options', 'tw_pk_ajax_auth_options');
add_action('wp_ajax_tw_passkey_auth_options', 'tw_pk_ajax_auth_options');
function tw_pk_ajax_auth_options() {
    if (!tw_pk_rate_ok('auth_opt', 30)) {
        wp_send_json_error(array('message' => 'Troppi tentativi, riprova fra qualche minuto.'));
    }
    if (!tw_pk_available()) {
        wp_send_json_error(array('message' => 'Le passkey richiedono una connessione HTTPS.'));
    }

    $username = tw_pk_post('username');
    $allowed  = tw_pk_get_allowed_credentials_for_site($username);

    if (empty($allowed)) {
        if ($username !== '') {
            wp_send_json_error(array('message' => 'Nessuna passkey registrata per questo account su questo sito.'));
        } else {
            wp_send_json_error(array('message' => 'Nessuna passkey registrata per questo sito.'));
        }
    }

    list($challenge, $token) = tw_pk_new_challenge('auth');

    // allowCredentials popolato: il browser propone solo ed esclusivamente
    // le passkey attive registrate per questo dominio, ignorando passkey
    // revocate o appartenenti ad altri contesti salvate nel portachiavi.
    wp_send_json_success(array(
        'token'            => $token,
        'challenge'        => tw_pk_b64url_encode($challenge),
        'rpId'             => tw_pk_rp_id(),
        'allowCredentials' => $allowed,
        'timeout'          => TW_PK_TTL * 1000,
    ));
}

add_action('wp_ajax_nopriv_tw_passkey_auth_verify', 'tw_pk_ajax_auth_verify');
add_action('wp_ajax_tw_passkey_auth_verify', 'tw_pk_ajax_auth_verify');
function tw_pk_ajax_auth_verify() {
    if (!tw_pk_rate_ok('auth_ver', 20)) {
        wp_send_json_error(array('message' => 'Troppi tentativi, riprova fra qualche minuto.'));
    }

    $challenge = tw_pk_take_challenge('auth', tw_pk_post('token'));
    if ($challenge === null) {
        wp_send_json_error(array('message' => 'Richiesta scaduta, riprova.'));
    }

    $cred_b64    = tw_pk_post('id');
    $client_data = tw_pk_b64url_decode(tw_pk_post('clientDataJSON'));
    $auth_data   = tw_pk_b64url_decode(tw_pk_post('authenticatorData'));
    $signature   = tw_pk_b64url_decode(tw_pk_post('signature'));

    if ($cred_b64 === '' || $client_data === '' || $auth_data === '' || $signature === '') {
        wp_send_json_error(array('message' => 'Dati di autenticazione mancanti.'));
    }
    // Normalizza: l'ID arriva in base64url, ma non fidiamoci della forma.
    $cred_b64 = tw_pk_b64url_encode(tw_pk_b64url_decode($cred_b64));

    $err = tw_pk_verify_client_data($client_data, 'webauthn.get', $challenge);
    if ($err !== '') {
        wp_send_json_error(array('message' => 'Verifica fallita: ' . $err));
    }

    $user_id = tw_pk_find_user_by_cred($cred_b64);
    if (!$user_id) {
        wp_send_json_error(array('message' => 'Passkey non riconosciuta.'));
    }

    // Individua la credenziale e verifica che appartenga a QUESTO dominio.
    $list  = tw_pk_get_user_passkeys($user_id);
    $idx   = -1;
    foreach ($list as $i => $pk) {
        if (isset($pk['id']) && hash_equals($pk['id'], $cred_b64)) {
            $idx = $i;
            break;
        }
    }
    if ($idx < 0) {
        wp_send_json_error(array('message' => 'Passkey non riconosciuta.'));
    }
    $pk = $list[$idx];
    if (!isset($pk['rp_id']) || $pk['rp_id'] !== tw_pk_rp_id()) {
        wp_send_json_error(array('message' => 'Questa passkey appartiene a un altro sito.'));
    }

    $ad = tw_pk_parse_auth_data($auth_data);
    if (!$ad) {
        wp_send_json_error(array('message' => 'Dati dell' . chr(39) . 'autenticatore illeggibili.'));
    }
    if (!hash_equals(hash('sha256', tw_pk_rp_id(), true), $ad['rp_id_hash'])) {
        wp_send_json_error(array('message' => 'Dominio non corrispondente.'));
    }
    if (!($ad['flags'] & 0x01)) {
        wp_send_json_error(array('message' => 'Presenza dell' . chr(39) . 'utente non confermata.'));
    }

    // La firma copre authenticatorData concatenato all'hash del clientDataJSON.
    $signed = $auth_data . hash('sha256', $client_data, true);
    $ok     = openssl_verify($signed, $signature, $pk['pem'], OPENSSL_ALGO_SHA256);
    if ($ok !== 1) {
        wp_send_json_error(array('message' => 'Firma non valida.'));
    }

    // Contatore anti-clonazione. Molte passkey sincronizzate riportano sempre 0:
    // in quel caso il controllo non e' applicabile e va saltato, non forzato.
    $stored = isset($pk['sign_count']) ? (int) $pk['sign_count'] : 0;
    $fresh  = (int) $ad['sign_count'];
    if ($fresh > 0 && $stored > 0 && $fresh <= $stored) {
        wp_send_json_error(array('message' => 'Contatore della passkey incoerente: credenziale possibilmente clonata.'));
    }

    $user = get_user_by('id', $user_id);
    if (!$user) {
        wp_send_json_error(array('message' => 'Utente non trovato.'));
    }

    $list[$idx]['sign_count'] = $fresh;
    $list[$idx]['last_used']  = time();
    tw_pk_save_user_passkeys($user_id, $list);

    // Da qui in poi e' un login WordPress a tutti gli effetti: stessi cookie,
    // stessi hook, stessa sessione della via con password.
    $remember = (tw_pk_post('remember') === '1');
    wp_set_current_user($user_id);
    wp_set_auth_cookie($user_id, $remember);
    do_action('wp_login', $user->user_login, $user);

    $redirect = tw_pk_post('redirect_to');
    $redirect = $redirect ? $redirect : admin_url();
    $redirect = wp_validate_redirect($redirect, admin_url()); // niente redirect aperti

    wp_send_json_success(array('redirect' => $redirect));
}

/* -------------------------------------------------------------------------
 * Revoca
 * ---------------------------------------------------------------------- */

add_action('wp_ajax_tw_passkey_delete', 'tw_pk_ajax_delete');
function tw_pk_ajax_delete() {
    check_ajax_referer('tw_passkey_reg', 'nonce');

    $user_id = (int) tw_pk_post('user_id');
    if (!$user_id) {
        $user_id = get_current_user_id();
    }
    if (!current_user_can('edit_user', $user_id)) {
        wp_send_json_error(array('message' => 'Permessi insufficienti.'));
    }

    $cred = tw_pk_post('id');
    $list = tw_pk_get_user_passkeys($user_id);
    $kept = array();
    $hit  = false;
    foreach ($list as $pk) {
        if (isset($pk['id']) && hash_equals($pk['id'], $cred)) {
            $hit = true;
            continue;
        }
        $kept[] = $pk;
    }
    if (!$hit) {
        wp_send_json_error(array('message' => 'Passkey non trovata.'));
    }

    tw_pk_save_user_passkeys($user_id, $kept);
    delete_user_meta($user_id, TW_PK_CRED_META, $cred);

    wp_send_json_success(array(
        'message' => 'Passkey revocata.',
        'rows'    => tw_pk_render_rows($user_id),
    ));
}

/* -------------------------------------------------------------------------
 * Interfaccia: profilo utente
 * ---------------------------------------------------------------------- */

function tw_pk_render_rows($user_id) {
    $list = tw_pk_get_user_passkeys_for_site($user_id);
    if (empty($list)) {
        return '<p class="tw-pk-empty">Nessuna passkey registrata per questo sito.</p>';
    }

    $html = '<table class="widefat striped tw-pk-table"><thead><tr>'
          . '<th>Nome</th><th>Registrata</th><th>Ultimo utilizzo</th><th></th>'
          . '</tr></thead><tbody>';

    foreach ($list as $pk) {
        $created = !empty($pk['created'])
            ? date_i18n(get_option('date_format'), (int) $pk['created']) : '&mdash;';
        $used = !empty($pk['last_used'])
            ? date_i18n(get_option('date_format') . ' H:i', (int) $pk['last_used']) : 'mai';

        $html .= '<tr>'
              . '<td><strong>' . esc_html($pk['label']) . '</strong></td>'
              . '<td>' . esc_html($created) . '</td>'
              . '<td>' . esc_html($used) . '</td>'
              . '<td><button type="button" class="button button-link-delete tw-pk-del" data-id="'
              . esc_attr($pk['id']) . '">Revoca</button></td>'
              . '</tr>';
    }

    return $html . '</tbody></table>';
}

add_action('show_user_profile', 'tw_pk_profile_section');
add_action('edit_user_profile', 'tw_pk_profile_section');
function tw_pk_profile_section($user) {
    if (!tw_pk_available() || !current_user_can('edit_user', $user->ID)) {
        return;
    }
    $own = ((int) $user->ID === get_current_user_id());
    ?>
    <h2 id="tw-passkeys">Passkey</h2>
    <p class="description" style="max-width:46em">
        Una passkey permette di accedere con l'impronta, il volto o il PIN del
        dispositivo, senza digitare la password. <strong>La password continua a
        funzionare normalmente</strong>: la passkey e' un'alternativa, non una
        sostituzione. Ogni passkey vale solo per
        <code><?php echo esc_html(tw_pk_rp_id()); ?></code>.
    </p>
    <div id="tw-pk-rows"><?php echo tw_pk_render_rows($user->ID); ?></div>
    <?php if ($own) : ?>
        <p>
            <input type="text" id="tw-pk-label" class="regular-text"
                   placeholder="Nome del dispositivo (es. iPhone di Giovanni)" />
            <button type="button" class="button button-secondary" id="tw-pk-add">Aggiungi una passkey</button>
        </p>
    <?php else : ?>
        <p class="description">Solo l'intestatario dell'account puo' registrare una nuova passkey.</p>
    <?php endif; ?>
    <p id="tw-pk-msg" class="tw-pk-msg" role="status" aria-live="polite"></p>
    <?php
}

add_action('admin_enqueue_scripts', 'tw_pk_admin_assets');
function tw_pk_admin_assets($hook) {
    if (!in_array($hook, array('profile.php', 'user-edit.php'), true) || !tw_pk_available()) {
        return;
    }
    $rel = '/assets/js/tw-passkeys.js';
    wp_enqueue_script(
        'tw-passkeys',
        get_template_directory_uri() . $rel,
        array(),
        (string) @filemtime(get_template_directory() . $rel),
        true
    );
    wp_localize_script('tw-passkeys', 'twPasskeys', array(
        'ajaxUrl' => admin_url('admin-ajax.php'),
        'nonce'   => wp_create_nonce('tw_passkey_reg'),
        'userId'  => isset($_GET['user_id']) ? (int) $_GET['user_id'] : get_current_user_id(),
        'mode'    => 'manage',
    ));
}

/* -------------------------------------------------------------------------
 * Interfaccia: pagina di login
 * ---------------------------------------------------------------------- */

add_action('login_enqueue_scripts', 'tw_pk_login_assets');
function tw_pk_login_assets() {
    if (!tw_pk_available()) {
        return;
    }
    $rel = '/assets/js/tw-passkeys.js';
    wp_enqueue_script(
        'tw-passkeys',
        get_template_directory_uri() . $rel,
        array(),
        (string) @filemtime(get_template_directory() . $rel),
        true
    );
    wp_localize_script('tw-passkeys', 'twPasskeys', array(
        'ajaxUrl'    => admin_url('admin-ajax.php'),
        'redirectTo' => isset($_GET['redirect_to']) ? esc_url_raw(wp_unslash($_GET['redirect_to'])) : '',
        'mode'       => 'login',
    ));
    ?>
    <style>
        /* OGNI selettore va prefissato con .login, e non e' cosmesi: il CSS
           di core contiene `.login * { margin:0; padding:0 }`, che ha la
           stessa specificita' di una singola classe (0,1,0) ed e' caricato
           DOPO questo blocco (inline in login_enqueue_scripts, core via
           load-styles.php). A parita' di specificita' vince l'ultimo, quindi
           `.tw-pk-login {margin:...}` veniva azzerato. `.login .tw-pk-login`
           vale (0,2,0) e passa a prescindere dall'ordine.
           Sintomo tipico: le regole su ID funzionavano (width del pulsante),
           quelle su classe no. */
        .login .tw-pk-login { margin: 16px 0 24px; text-align: center; }
        .login .tw-pk-sep { display:flex; align-items:center; gap:10px; margin:18px 0 12px; color:#646970; font-size:12px; text-transform:uppercase; letter-spacing:.4px; }
        .login .tw-pk-sep::before, .login .tw-pk-sep::after { content:""; flex:1; height:1px; background:#dcdcde; }
        .login #tw-pk-login-btn { width:100%; }
        .login .tw-pk-msg { margin-top:10px; font-size:13px; }
        /* Da vuoto non deve occupare spazio, altrimenti lo stacco cambia a
           seconda che ci sia o meno un messaggio. */
        .login .tw-pk-msg:empty { display:none; margin:0; }
        .login .tw-pk-msg.error { color:#b32d2e; }
        .login .tw-pk-msg.ok { color:#008a20; }
    </style>
    <?php
}

/**
 * Il bottone sta DOPO il form standard e non lo altera in alcun modo: se il
 * browser non supporta WebAuthn il blocco si nasconde da solo via JS e la
 * pagina di login resta identica a prima.
 */
add_action('login_form', 'tw_pk_login_button');
function tw_pk_login_button() {
    if (!tw_pk_available()) {
        return;
    }
    ?>
    <div class="tw-pk-login" id="tw-pk-login" hidden>
        <div class="tw-pk-sep">oppure</div>
        <button type="button" class="button button-secondary" id="tw-pk-login-btn">
            Accedi con una passkey
        </button>
        <p id="tw-pk-msg" class="tw-pk-msg" role="status" aria-live="polite"></p>
    </div>
    <?php
}
