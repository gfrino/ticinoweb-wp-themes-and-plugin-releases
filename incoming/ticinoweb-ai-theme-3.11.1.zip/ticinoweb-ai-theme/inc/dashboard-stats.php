<?php
/**
 * Dashboard Widget: Visitor statistics (weekly, monthly, yearly)
 * Tracks unique daily visits and displays aggregated totals.
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Conteggio visite uniche giornaliere.
 *
 * Fino alla 3.9.0 il conteggio avveniva su `template_redirect`, con un
 * `setcookie()` alla prima visita del giorno: una risposta HTML con Set-Cookie
 * non e' cacheabile, quindi LiteSpeed non serviva MAI la pagina dalla cache e
 * ogni visita eseguiva PHP. Dalla 3.9.1 la pagina stampa solo uno script
 * statico (cacheabile) che, una volta al giorno per browser, invia un beacon a
 * admin-ajax.php; e' il gestore AJAX a incrementare il contatore e a impostare
 * il cookie. Effetto collaterale voluto: i bot senza JavaScript non vengono
 * piu' contati.
 */
add_action('wp_footer', 'ticinoweb_print_visit_beacon', 99);
function ticinoweb_print_visit_beacon() {
    if (is_admin() || is_feed() || is_embed() || is_robots()) {
        return;
    }
    if (function_exists('is_customize_preview') && is_customize_preview()) {
        return;
    }

    $ajax_url = wp_json_encode(admin_url('admin-ajax.php'));
    $js = "(function(){try{"
        . "var k='ticinoweb_visit',d=new Date(),t=d.getFullYear()+'-'+(d.getMonth()+1)+'-'+d.getDate();"
        . "if(window.localStorage&&localStorage.getItem(k)===t){return;}"
        . "if(window.localStorage){localStorage.setItem(k,t);}"
        . "var u={$ajax_url},b=new FormData();b.append('action','ticinoweb_track_visit');"
        . "if(navigator.sendBeacon){navigator.sendBeacon(u,b);}"
        . "else if(window.fetch){fetch(u,{method:'POST',body:b,credentials:'same-origin',keepalive:true});}"
        . "}catch(e){}})();";

    if (function_exists('wp_print_inline_script_tag')) {
        wp_print_inline_script_tag($js, array('id' => 'ticinoweb-visit-beacon'));
    } else {
        echo '<script id="ticinoweb-visit-beacon">' . $js . '</script>' . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput
    }
}

add_action('wp_ajax_nopriv_ticinoweb_track_visit', 'ticinoweb_track_visit');
add_action('wp_ajax_ticinoweb_track_visit', 'ticinoweb_track_visit');
function ticinoweb_track_visit() {
    if (defined('WP_CLI') && WP_CLI) {
        return;
    }
    if (defined('DOING_CRON') && DOING_CRON) {
        return;
    }
    if (!wp_doing_ajax()) {
        // Chiamata diretta fuori da admin-ajax (retrocompatibilita'): nessun effetto.
        return;
    }
    if (!isset($_SERVER['REQUEST_METHOD']) || strtoupper($_SERVER['REQUEST_METHOD']) !== 'POST') {
        wp_send_json_error('method', 405);
    }

    $today_key = wp_date('Ymd', current_time('timestamp'));
    $cookie_name = 'ticinoweb_visit_' . $today_key;

    // Seconda barriera oltre al localStorage del browser: un cookie HttpOnly per il giorno.
    if (!empty($_COOKIE[$cookie_name])) {
        wp_send_json_success(array('counted' => false));
    }

    $visits = get_option('ticinoweb_daily_visits', []);
    if (!is_array($visits)) {
        $visits = [];
    }

    $visits[$today_key] = isset($visits[$today_key]) ? (int) $visits[$today_key] + 1 : 1;

    ksort($visits);
    if (count($visits) > 400) {
        $visits = array_slice($visits, -400, null, true);
    }

    update_option('ticinoweb_daily_visits', $visits, false);

    $cookie_args = [
        'expires'  => time() + DAY_IN_SECONDS,
        'path'     => COOKIEPATH,
        'domain'   => COOKIE_DOMAIN,
        'secure'   => is_ssl(),
        'httponly' => true,
        'samesite' => 'Lax',
    ];
    setcookie($cookie_name, '1', $cookie_args);
    $_COOKIE[$cookie_name] = '1';

    wp_send_json_success(array('counted' => true));
}

add_action('wp_dashboard_setup', 'ticinoweb_register_dashboard_widget');
function ticinoweb_register_dashboard_widget() {
    wp_add_dashboard_widget(
        'ticinoweb_visits_widget',
        __('Statistiche Visitatori', 'ticinoweb-ai-theme'),
        'ticinoweb_render_dashboard_widget'
    );
}

function ticinoweb_get_visit_sum($days) {
    $days = max(1, (int) $days);
    $visits = get_option('ticinoweb_daily_visits', []);
    if (!is_array($visits)) {
        return 0;
    }

    $total = 0;
    $now = current_time('timestamp');
    for ($i = 0; $i < $days; $i++) {
        $key = wp_date('Ymd', $now - ($i * DAY_IN_SECONDS));
        if (isset($visits[$key])) {
            $total += (int) $visits[$key];
        }
    }

    return $total;
}

function ticinoweb_get_daily_chart_data($days = 7) {
    $visits = get_option('ticinoweb_daily_visits', []);
    if (!is_array($visits)) {
        $visits = [];
    }
    
    $data = [];
    $now = current_time('timestamp');
    for ($i = $days - 1; $i >= 0; $i--) {
        $key = wp_date('Ymd', $now - ($i * DAY_IN_SECONDS));
        $data[] = [
            'label' => wp_date('d/m', $now - ($i * DAY_IN_SECONDS)),
            'value' => isset($visits[$key]) ? (int) $visits[$key] : 0,
        ];
    }
    return $data;
}

function ticinoweb_get_weekly_chart_data($weeks = 8) {
    $visits = get_option('ticinoweb_daily_visits', []);
    if (!is_array($visits)) {
        $visits = [];
    }
    
    $data = [];
    $now = current_time('timestamp');
    for ($i = $weeks - 1; $i >= 0; $i--) {
        $week_start = $now - (($i + 1) * 7 * DAY_IN_SECONDS);
        $week_end = $now - ($i * 7 * DAY_IN_SECONDS);
        $total = 0;
        
        for ($day = $week_start; $day <= $week_end; $day += DAY_IN_SECONDS) {
            $key = wp_date('Ymd', $day);
            if (isset($visits[$key])) {
                $total += (int) $visits[$key];
            }
        }
        
        $data[] = [
            'label' => 'S' . ($weeks - $i),
            'value' => $total,
        ];
    }
    return $data;
}

function ticinoweb_get_monthly_chart_data($months = 6) {
    $visits = get_option('ticinoweb_daily_visits', []);
    if (!is_array($visits)) {
        $visits = [];
    }
    
    $data = [];
    for ($i = $months - 1; $i >= 0; $i--) {
        $month_timestamp = strtotime("-$i months", current_time('timestamp'));
        $year = wp_date('Y', $month_timestamp);
        $month = wp_date('m', $month_timestamp);
        $total = 0;
        
        foreach ($visits as $key => $value) {
            if (substr($key, 0, 6) === $year . $month) {
                $total += (int) $value;
            }
        }
        
        $data[] = [
            'label' => wp_date('M', $month_timestamp),
            'value' => $total,
        ];
    }
    return $data;
}

function ticinoweb_get_yearly_chart_data($years = 5) {
    $visits = get_option('ticinoweb_daily_visits', []);
    if (!is_array($visits)) {
        $visits = [];
    }
    
    $data = [];
    $current_year = (int) wp_date('Y', current_time('timestamp'));
    
    for ($i = $years - 1; $i >= 0; $i--) {
        $year = $current_year - $i;
        $total = 0;
        
        foreach ($visits as $key => $value) {
            if (substr($key, 0, 4) === (string) $year) {
                $total += (int) $value;
            }
        }
        
        $data[] = [
            'label' => (string) $year,
            'value' => $total,
        ];
    }
    return $data;
}

function ticinoweb_render_dashboard_widget() {
    $daily_data = ticinoweb_get_daily_chart_data(7);
    $weekly_data = ticinoweb_get_weekly_chart_data(8);
    $monthly_data = ticinoweb_get_monthly_chart_data(6);
    $yearly_data = ticinoweb_get_yearly_chart_data(5);

    $logo_url = get_template_directory_uri() . '/assets/images/logo-ticinoweb-2025.png';

    $all_data = [
        'daily' => $daily_data,
        'weekly' => $weekly_data,
        'monthly' => $monthly_data,
        'yearly' => $yearly_data,
    ];
    ?>
    <style>
        .ticinoweb-widget-wrap {
            padding: 10px 8px 8px;
        }
        .ticinoweb-widget-glass {
            background: rgba(255, 255, 255, 0.72);
            border-radius: 0;
            border: 1px solid rgba(255, 255, 255, 0.45);
            box-shadow: none;
            backdrop-filter: blur(12px) saturate(140%);
            -webkit-backdrop-filter: blur(12px) saturate(140%);
            padding: 14px 14px 12px;
        }
        .ticinoweb-widget-head {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 12px;
            margin-bottom: 10px;
        }
        .ticinoweb-widget-logo {
            max-width: 100px;
            height: auto;
            display: block;
            filter: drop-shadow(0 6px 12px rgba(15, 23, 42, 0.1));
        }
        .ticinoweb-widget-select {
            display: flex;
            flex-direction: column;
            gap: 4px;
            align-items: flex-end;
        }
        .ticinoweb-widget-select select {
            border-radius: 999px;
            padding: 4px 12px 5px;
            border: 1px solid rgba(148, 163, 184, 0.6);
            background: rgba(255, 255, 255, 0.9);
            font-size: 12px;
            color: #1f2937;
            box-shadow: inset 0 0 0 1px rgba(255, 255, 255, 0.4);
        }
        .ticinoweb-widget-chart {
            display: flex;
            justify-content: center;
            margin-bottom: 12px;
        }
        .ticinoweb-bar {
            background: #f3f4f6;
            border-radius: 0;
            padding: 6px 4px 8px;
            text-align: center;
            box-shadow: inset 0 0 0 1px rgba(15, 23, 42, 0.06);
            flex: 1;
            min-width: 0;
        }
        .ticinoweb-bar-graph {
            height: 100px;
            display: flex;
            align-items: flex-end;
            justify-content: center;
            margin-bottom: 6px;
        }
        .ticinoweb-bar-fill {
            width: 100%;
            border-radius: 0;
            transition: height 0.3s ease;
            position: relative;
            overflow: hidden;
        }
        .ticinoweb-bar-fill::after {
            content: '';
            position: absolute;
            inset: 0;
            background: linear-gradient(120deg, rgba(255, 255, 255, 0.45) 0%, rgba(255, 255, 255, 0.12) 35%, rgba(255, 255, 255, 0.5) 70%, rgba(255, 255, 255, 0.18) 100%);
            opacity: 0.6;
            mix-blend-mode: screen;
        }
        .ticinoweb-bar-value {
            font-size: 13px;
            font-weight: 700;
            color: #111827;
        }
        .ticinoweb-bar-label {
            display: block;
            font-size: 10px;
            color: #6b7280;
            margin-top: 2px;
        }
        .ticinoweb-widget-chart-container {
            display: none;
        }
        .ticinoweb-widget-chart-container.active {
            display: flex;
            gap: 4px;
        }
        .ticinoweb-widget-footnote {
            font-size: 11px;
            color: #6b7280;
        }
    </style>
    <div class="ticinoweb-widget-wrap" id="ticinoweb-visits-widget">
        <div class="ticinoweb-widget-glass">
            <div class="ticinoweb-widget-head">
                <img class="ticinoweb-widget-logo" src="<?php echo esc_url($logo_url); ?>" alt="ticinoWEB">
                <div class="ticinoweb-widget-select">
                    <select id="ticinoweb-period-select" class="ticinoweb-period-select" aria-label="<?php esc_attr_e('Seleziona periodo', 'ticinoweb-ai-theme'); ?>">
                        <option value="daily"><?php esc_html_e('Giornaliero', 'ticinoweb-ai-theme'); ?></option>
                        <option value="weekly" selected><?php esc_html_e('Settimanale', 'ticinoweb-ai-theme'); ?></option>
                        <option value="monthly"><?php esc_html_e('Mensile', 'ticinoweb-ai-theme'); ?></option>
                        <option value="yearly"><?php esc_html_e('Annuale', 'ticinoweb-ai-theme'); ?></option>
                    </select>
                </div>
            </div>
            
            <?php foreach ($all_data as $period => $data) :
                $max_value = max(1, ...array_column($data, 'value'));
                ?>
                <div class="ticinoweb-widget-chart-container" data-period="<?php echo esc_attr($period); ?>">
                    <?php foreach ($data as $bar) :
                        $height = (int) round(($bar['value'] / $max_value) * 100);
                        $height = max(10, min(100, $height));
                        ?>
                        <div class="ticinoweb-bar">
                            <div class="ticinoweb-bar-graph" aria-hidden="true">
                                <div class="ticinoweb-bar-fill" style="height: <?php echo esc_attr($height); ?>px; background: #2563eb;"></div>
                            </div>
                            <div class="ticinoweb-bar-value"><?php echo esc_html(number_format_i18n($bar['value'])); ?></div>
                            <span class="ticinoweb-bar-label"><?php echo esc_html($bar['label']); ?></span>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endforeach; ?>
            <div class="ticinoweb-widget-footnote">
                <?php esc_html_e('Dati basati su visite uniche giornaliere registrate dal tema.', 'ticinoweb-ai-theme'); ?>
            </div>
        </div>
    </div>
    <script>
        (function() {
            var widget = document.getElementById('ticinoweb-visits-widget');
            if (!widget) {
                return;
            }
            var select = widget.querySelector('.ticinoweb-period-select');
            var containers = widget.querySelectorAll('.ticinoweb-widget-chart-container');
            
            var updateCharts = function() {
                var value = select.value;
                containers.forEach(function(container) {
                    if (container.getAttribute('data-period') === value) {
                        container.classList.add('active');
                    } else {
                        container.classList.remove('active');
                    }
                });
            };
            
            select.addEventListener('change', updateCharts);
            updateCharts();
        })();
    </script>
    <?php
}
