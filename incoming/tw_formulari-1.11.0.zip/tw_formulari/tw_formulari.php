<?php
/**
 * Plugin Name:       TW Formulari
 * Plugin URI:        https://ticinoweb.ch
 * Description:       Trasforma ogni invio del tuo modulo di contatto in un PDF ordinato e lo spedisce via email a te e a chi l'ha compilato. Funziona con Elementor, Contact Form 7, WPForms, Gravity Forms e Fluent Forms.
 * Update URI:        https://github.com/gfrino/ticinoweb-wp-themes-and-plugin-releases
 * Version:           1.11.0
 * Author:            ticinoWEB
 * Author URI:        https://ticinoweb.ch
 * Text Domain:       tw-formulari
 * Domain Path:       /languages
 * Requires at least: 5.8
 * Requires PHP:      8.2
 *
 * @package           TicinoWeb\TWFormulari
 */

namespace TicinoWeb\TWFormulari;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Define Plugin Constants
define( 'TW_FORMULARI_VERSION', '1.11.0' );
define( 'TW_FORMULARI_FILE', __FILE__ );
define( 'TW_FORMULARI_PATH', plugin_dir_path( __FILE__ ) );
define( 'TW_FORMULARI_URL', plugin_dir_url( __FILE__ ) );

if ( ! function_exists( __NAMESPACE__ . '\\twf_asset_ver' ) ) {
	/**
	 * Version string for a script or style of the plugin: the plugin version plus the date of the file.
	 * The browsers and the hosting keep these files for a long time under the same address, so a file changed
	 * without a version bump (a hot fix, a manual copy) would otherwise keep being served in its old form.
	 *
	 * @param string $relative Path inside the plugin, e.g. assets/builder/frontend.js.
	 */
	function twf_asset_ver( string $relative ): string {
		$file = TW_FORMULARI_PATH . ltrim( $relative, '/' );
		$time = is_file( $file ) ? (int) filemtime( $file ) : 0;
		return TW_FORMULARI_VERSION . ( $time > 0 ? '.' . $time : '' );
	}
}
// Version of the bundled includes/tw-release-updater.php (keep in sync with its header).
define( 'TW_FORMULARI_RELEASE_UPDATER_VERSION', '1.2.0' );

// Updates from the ticinoWEB releases repo (see the Update URI header).
require_once TW_FORMULARI_PATH . 'includes/tw-release-updater.php';

// Require Plugin Core Files
require_once TW_FORMULARI_PATH . 'includes/helpers.php';
require_once TW_FORMULARI_PATH . 'includes/class-logger.php';
require_once TW_FORMULARI_PATH . 'includes/class-settings.php';
require_once TW_FORMULARI_PATH . 'includes/class-features.php';
require_once TW_FORMULARI_PATH . 'includes/class-data-normalizer.php';
require_once TW_FORMULARI_PATH . 'includes/class-pdf-generator.php';
require_once TW_FORMULARI_PATH . 'includes/class-email-service.php';

// Require Form Adapters
require_once TW_FORMULARI_PATH . 'includes/adapters/interface-form-adapter.php';
require_once TW_FORMULARI_PATH . 'includes/adapters/interface-form-discovery.php';
require_once TW_FORMULARI_PATH . 'includes/adapters/class-adapter-elementor.php';
require_once TW_FORMULARI_PATH . 'includes/adapters/class-adapter-cf7.php';
require_once TW_FORMULARI_PATH . 'includes/adapters/class-adapter-wpforms.php';
require_once TW_FORMULARI_PATH . 'includes/adapters/class-adapter-gravityforms.php';
require_once TW_FORMULARI_PATH . 'includes/adapters/class-adapter-fluentforms.php';
require_once TW_FORMULARI_PATH . 'includes/adapters/class-adapter-generic.php';

require_once TW_FORMULARI_PATH . 'includes/class-form-manager.php';
require_once TW_FORMULARI_PATH . 'includes/class-plugin.php';

// Built-in form builder (forms, entries, notifications, shortcode [tw_form]).
foreach ( [ 'field-types', 'conditions', 'calculator', 'definition', 'processor', 'entries', 'uploads', 'notifications', 'payment-methods', 'captcha', 'stripe', 'submission', 'renderer', 'templates', 'builder', 'admin-rest', 'forminator-importer' ] as $twf_builder_file ) {
	require_once TW_FORMULARI_PATH . 'includes/builder/class-' . $twf_builder_file . '.php';
}
unset( $twf_builder_file );
\TicinoWeb\TWFormulari\Builder\Builder::init();
\TicinoWeb\TWFormulari\Builder\AdminRest::init();

if ( is_admin() ) {
	require_once TW_FORMULARI_PATH . 'admin/class-admin.php';
	require_once TW_FORMULARI_PATH . 'includes/builder/class-builder-admin.php';
	require_once TW_FORMULARI_PATH . 'includes/builder/class-entries-admin.php';
	require_once TW_FORMULARI_PATH . 'includes/builder/class-payments-admin.php';
	require_once TW_FORMULARI_PATH . 'includes/builder/class-forminator-admin.php';
	\TicinoWeb\TWFormulari\Builder\ForminatorAdmin::init();
	// A switched-off function adds nothing to the menu (see TW Formulari → Impostazioni).
	if ( \TicinoWeb\TWFormulari\Features::enabled( 'builder' ) ) {
		\TicinoWeb\TWFormulari\Builder\BuilderAdmin::init();
		\TicinoWeb\TWFormulari\Builder\EntriesAdmin::init();
	}
	if ( \TicinoWeb\TWFormulari\Features::enabled( 'payments' ) ) {
		\TicinoWeb\TWFormulari\Builder\PaymentsAdmin::init();
	}
}

// Register Activation and Deactivation Hooks
register_activation_hook( __FILE__, [ Plugin::class, 'activate' ] );
register_deactivation_hook( __FILE__, [ Plugin::class, 'deactivate' ] );

// Bootstrap Plugin
add_action( 'plugins_loaded', function() {
	Plugin::get_instance();
} );

/**
 * Installs the release updater as a mu-plugin so updates also work in Network Admin.
 */
function tw_formulari_install_release_updater() {
	if ( ! class_exists( 'TW_Release_Updater' ) || \TW_Release_Updater::mu_is_current( TW_FORMULARI_RELEASE_UPDATER_VERSION ) ) {
		return;
	}
	if ( get_site_transient( 'tw_formulari_release_updater_failed' ) ) {
		return;
	}
	$result = \TW_Release_Updater::install_mu( TW_FORMULARI_PATH . 'includes/tw-release-updater.php' );
	if ( is_wp_error( $result ) ) {
		set_site_transient( 'tw_formulari_release_updater_failed', $result->get_error_message(), 12 * HOUR_IN_SECONDS );
	}
}

add_action( 'admin_init', function () {
	if ( current_user_can( is_multisite() ? 'manage_network_plugins' : 'activate_plugins' ) ) {
		tw_formulari_install_release_updater();
	}
}, 20 );
