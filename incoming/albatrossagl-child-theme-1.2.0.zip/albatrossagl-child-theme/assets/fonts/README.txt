Manrope and Source Sans 3, SIL Open Font License 1.1.
Official Google Fonts WOFF2 distributions downloaded 2026-11-03.
Latin variable fonts, unchanged from the vendor. OFL licenses retained.
Sources: https://fonts.google.com/specimen/Manrope
https://fonts.google.com/specimen/Source+Sans+3
No third-party font requests are required by this child theme.
