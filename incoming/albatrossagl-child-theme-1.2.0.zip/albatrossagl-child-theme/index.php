<?php defined('ABSPATH') || exit; get_header(); ?>
<div class="alb-wrap alb-document">
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<article><h1><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h1><?php the_content(); ?></article>
<?php endwhile; the_posts_navigation(); else : ?>
<h1><?php esc_html_e('Contenuto non disponibile', 'albatrossagl-child-theme'); ?></h1>
<a href="<?php echo esc_url(albatros_url()); ?>"><?php esc_html_e('Torna alla home', 'albatrossagl-child-theme'); ?></a>
<?php endif; ?>
</div>
<?php get_footer(); ?>
