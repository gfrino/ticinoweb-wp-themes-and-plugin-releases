<?php defined('ABSPATH') || exit; $contact = albatros_contact(); $privacy = get_privacy_policy_url(); ?>
</main>
<footer class="alb-footer">
    <div class="alb-wrap alb-footer-top">
        <a class="alb-logo" href="<?php echo esc_url(albatros_url()); ?>"><?php $logo = albatros_image(get_option('ticinoweb_site_logo'), 'medium', array('alt' => get_bloginfo('name'))); echo $logo ?: esc_html(get_bloginfo('name')); ?></a>
        <p><?php echo esc_html(get_bloginfo('description')); ?></p>
        <?php if (!empty($contact['email'])) : ?><a href="<?php echo esc_url('mailto:' . sanitize_email($contact['email'])); ?>"><?php echo esc_html($contact['email']); ?> <span aria-hidden="true">↗</span></a><?php endif; ?>
    </div>
    <div class="alb-wrap alb-footer-bottom">
        <span>© <?php echo esc_html(wp_date('Y') . ' ' . get_bloginfo('name')); ?><?php if (!empty($contact['vat'])) { echo ' · ' . esc_html($contact['vat']); } ?></span>
        <div><?php if ($privacy) : ?><a href="<?php echo esc_url($privacy); ?>"><?php esc_html_e('Privacy', 'albatrossagl-child-theme'); ?></a><?php endif; ?>
        <?php if (get_option('tw_cookie_banner_enable')) : ?><button type="button" class="alb-cookie-settings"><?php esc_html_e('Preferenze cookie', 'albatrossagl-child-theme'); ?></button><?php endif; ?>
        <a href="https://ticinoweb.com/" rel="noopener"><?php esc_html_e('Sito web ticinoWEB', 'albatrossagl-child-theme'); ?></a></div>
    </div>
</footer>
<?php if (!empty($contact['phone'])) : ?>
<div class="alb-mobile-actions"><a href="<?php echo esc_url('tel:' . preg_replace('/[^+0-9]/', '', $contact['phone'])); ?>"><?php esc_html_e('Chiama', 'albatrossagl-child-theme'); ?></a><a href="<?php echo esc_url(albatros_url('contatti')); ?>"><?php esc_html_e('Richiedi un preventivo', 'albatrossagl-child-theme'); ?> ↗</a></div>
<?php endif; ?>
<?php wp_footer(); ?>
</body>
</html>
