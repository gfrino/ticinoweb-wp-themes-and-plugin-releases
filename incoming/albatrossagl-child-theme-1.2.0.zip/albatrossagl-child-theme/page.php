<?php defined('ABSPATH') || exit; get_header(); ?>
<article class="alb-wrap alb-document">
<?php while (have_posts()) : the_post(); ?>
<h1><?php the_title(); ?></h1>
<?php the_content(); endwhile; ?>
</article>
<?php get_footer(); ?>
