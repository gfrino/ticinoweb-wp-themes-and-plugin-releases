<?php
/** Homepage built in the native editor; the child owns presentation only. */
defined('ABSPATH') || exit;
get_header();
while (have_posts()) {
    the_post();
    the_content();
}
get_footer();
