<?php
defined('ABSPATH') || exit;
$services = function_exists('ticinoweb_get_services') ? ticinoweb_get_services() : array();
if (!$services) { return; }
?>
<div class="alb-services">
<?php foreach ($services as $index => $service) :
    $key = !empty($service['id']) ? $service['id'] : (string) $index;
    $title = function_exists('ticinoweb_frontend_text') ? ticinoweb_frontend_text($service['title'], 'theme:service:' . $key . ':title') : $service['title'];
    $description = function_exists('ticinoweb_frontend_text') ? ticinoweb_frontend_text($service['description'], 'theme:service:' . $key . ':description') : $service['description'];
?>
<article class="alb-service">
    <div class="alb-service-photo"><?php echo albatros_image($service['image'] ?? '', 'large', array('sizes' => '(max-width: 760px) 100vw, 45vw')); ?></div>
    <div class="alb-service-body">
        <h3><?php echo esc_html($title); ?></h3>
        <div class="alb-service-description"><?php echo wp_kses_post(wpautop($description)); ?></div>
        <a class="alb-text-link" href="<?php echo esc_url(albatros_url('contatti')); ?>" data-service="<?php echo esc_attr(wp_strip_all_tags($title)); ?>"><?php esc_html_e('Parliamone', 'albatrossagl-child-theme'); ?><span aria-hidden="true">↗</span></a>
    </div>
</article>
<?php endforeach; ?>
</div>
