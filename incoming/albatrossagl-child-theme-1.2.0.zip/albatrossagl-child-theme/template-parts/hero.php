<?php
defined('ABSPATH') || exit;
$title = get_option('ticinoweb_slider_title_1', '');
if (!$title) { return; }
$contact = albatros_contact();
$cta = get_option('ticinoweb_slider_btn_link_1') ?: albatros_url('contatti');
$cta = function_exists('ticinoweb_frontend_url') ? ticinoweb_frontend_url($cta, 'theme:slider:1:btn_link') : $cta;
?>
<section class="alb-hero alb-wrap" aria-labelledby="alb-title">
    <div class="alb-hero-copy">
        <?php if (!empty($contact['address_label'])) : ?><p class="alb-kicker"><span class="alb-mark" aria-hidden="true"></span><?php echo esc_html(albatros_text($contact['address_label'], 'territory')); ?></p><?php endif; ?>
        <h1 id="alb-title"><?php echo esc_html(albatros_text($title, 'hero:title')); ?></h1>
        <?php if ($description = get_option('ticinoweb_slider_desc_1')) : ?><p class="alb-lead"><?php echo esc_html(albatros_text($description, 'hero:description')); ?></p><?php endif; ?>
        <div class="alb-actions">
            <?php if ($button = get_option('ticinoweb_slider_btn_text_1')) : ?><a class="alb-button" href="<?php echo esc_url($cta); ?>"><?php echo esc_html(albatros_text($button, 'hero:button')); ?><span aria-hidden="true">↗</span></a><?php endif; ?>
            <a class="alb-text-link" href="<?php echo esc_url(albatros_url('servizi')); ?>"><?php esc_html_e('Esplora i servizi', 'albatrossagl-child-theme'); ?><span aria-hidden="true">↓</span></a>
        </div>
    </div>
    <div class="alb-hero-media">
        <?php echo albatros_image(get_option('ticinoweb_slider_image_1'), 'full', array('loading' => 'eager', 'fetchpriority' => 'high', 'sizes' => '(max-width: 760px) 100vw, 52vw')); ?>
        <span class="alb-window" aria-hidden="true"></span>
        <a class="alb-image-label" href="<?php echo esc_url(albatros_url('chi-siamo')); ?>"><span><?php echo esc_html(get_bloginfo('name')); ?></span><span aria-hidden="true">↗</span></a>
    </div>
</section>
