(() => {
  'use strict';
  const opening=document.querySelector('[data-opening]');
  if(!opening)return;
  const reduced=matchMedia('(prefers-reduced-motion:reduce)');
  const desktop=matchMedia('(min-width:1101px) and (min-height:800px)');
  const clamp=v=>Math.max(0,Math.min(1,v));
  const range=(a,b,v)=>clamp((v-a)/(b-a));
  const smooth=(a,b,v)=>{const n=range(a,b,v);return n*n*(3-2*n);};
  const round=v=>Number(v.toFixed(3));

  // An explicit, native horizontal shop window. No timer and no scroll-linked fading.
  const feature=document.querySelector('[data-feature]');
  if(feature){
    const track=feature.querySelector('[data-feature-track]');
    const slides=[...feature.querySelectorAll('[data-feature-slide]')];
    const controls=feature.querySelector('[data-feature-controls]');
    const previous=feature.querySelector('[data-feature-prev]');
    const next=feature.querySelector('[data-feature-next]');
    const counter=feature.querySelector('[data-feature-count]');
    let index=0,width=track.clientWidth;
    function showState(){
      const currentWidth=track.clientWidth;
      if(currentWidth!==width){width=currentWidth;track.scrollTo({left:index*width,behavior:'instant'});return;}
      index=Math.max(0,Math.min(slides.length-1,Math.round(track.scrollLeft/Math.max(1,width))));
      previous.disabled=index===0;next.disabled=index===slides.length-1;
      counter.textContent=`${index+1} / ${slides.length}`;
      slides.forEach((slide,i)=>{slide.inert=i!==index;});
    }
    function go(i){track.scrollTo({left:Math.max(0,Math.min(slides.length-1,i))*width,behavior:reduced.matches?'instant':'smooth'});}
    previous.addEventListener('click',()=>go(index-1));next.addEventListener('click',()=>go(index+1));
    track.addEventListener('scroll',showState,{passive:true});
    track.addEventListener('keydown',event=>{if(event.target===track&&['ArrowLeft','ArrowRight'].includes(event.key)){event.preventDefault();go(index+(event.key==='ArrowLeft'?-1:1));}});
    if(typeof ResizeObserver==='function')new ResizeObserver(()=>{width=track.clientWidth;track.scrollTo({left:index*width,behavior:'instant'});showState();}).observe(track);
    controls.hidden=false;feature.setAttribute('data-ready','');showState();
  }

  const departments=document.querySelector('[data-worlds]');
  const worldsStage=document.querySelector('[data-worlds-stage]');
  const animalLandscape=departments?.querySelector('.qz-animals');
  const animals=[...document.querySelectorAll('[data-animal]')].map(link=>({link,image:link.querySelector('.qz-animal__image'),label:link.querySelector('.qz-animal__label'),story:link.querySelector('.qz-animal__story')}));
  const controls=departments?.querySelector('[data-world-controls]');
  const previous=departments?.querySelector('[data-world-prev]');
  const next=departments?.querySelector('[data-world-next]');
  const counter=departments?.querySelector('[data-world-count]');
  const cuddle=document.querySelector('[data-cuddle]');
  const story=document.querySelector('[data-chapter="story"]');
  let lenis=null,frame=0,dirty=true,immersive=false,lastY=-1,geometry=null,animalIndex=0;
  const placed=el=>{const r=el.getBoundingClientRect();return {top:r.top+scrollY,height:r.height};};
  function measure(){
    const header=document.querySelector('[data-header]')?.offsetHeight||0;
    const marker=document.querySelector('[data-flow-marker="story"]');
    geometry={header,viewport:innerHeight,departments:departments?placed(departments):null,
      worldWidth:animalLandscape?.offsetWidth||1,animalWidth:animals[0]?.link.offsetWidth||1,worldStageHeight:worldsStage?.offsetHeight||1,
      cuddle:cuddle?placed(cuddle):null,story:story?{top:marker?marker.getBoundingClientRect().top+scrollY:placed(story).top,height:story.offsetHeight}:null};
    const storyFits=story&&story.offsetHeight<=innerHeight-header;
    story?.toggleAttribute('data-stack-fit',!!storyFits);
    dirty=false;
  }
  function reset(){
    [departments,cuddle,story].forEach(el=>el?.removeAttribute('style'));
    story?.removeAttribute('data-stack-fit');
    animals.forEach(a=>{[a.link,a.image,a.label,a.story].forEach(el=>el?.removeAttribute('style'));a.link.inert=false;});
    if(controls)controls.hidden=!immersive;
  }
  function configure(){
    lenis?.destroy();lenis=null;
    immersive=desktop.matches&&!reduced.matches;
    document.documentElement.toggleAttribute('data-qz-motion',immersive);
    reset();dirty=true;lastY=-1;
    if(immersive&&typeof Lenis==='function')lenis=new Lenis({lerp:.105,smoothWheel:true,syncTouch:false,autoRaf:false,anchors:false});
    wake();
  }
  function goAnimal(i){
    if(!immersive||!geometry||!animals.length)return;
    const target=Math.max(0,Math.min(animals.length-1,i));
    const travel=Math.max(1,geometry.departments.height-geometry.worldStageHeight);
    const progress=(target/(animals.length-1))*.82;
    const y=geometry.departments.top-geometry.header+travel*progress;
    if(lenis)lenis.scrollTo(y);else window.scrollTo({top:y,behavior:reduced.matches?'instant':'smooth'});
    wake();
  }
  previous?.addEventListener('click',()=>goAnimal(animalIndex-1));
  next?.addEventListener('click',()=>goAnimal(animalIndex+1));
  function paint(y){
    const g=geometry;
    if(g.departments&&animals.length){
      const wp=clamp((y+g.header-g.departments.top)/Math.max(1,g.departments.height-g.worldStageHeight));
      const raw=range(0,.82,wp)*(animals.length-1);
      const base=Math.floor(raw),fraction=raw-base;
      // Each portrait holds for 65% of its chapter before a short, continuous handover.
      const tour=base+smooth(.65,1,fraction),resolve=smooth(.86,.98,wp);
      const mainX=g.worldWidth*.22-g.animalWidth/2;
      const gap=(g.worldWidth-animals.length*g.animalWidth)/Math.max(1,animals.length-1);
      const portraitScale=2.3;
      const readingGap=g.worldWidth<1200?80:100;
      const textLeft=g.animalWidth+(portraitScale-1)*g.animalWidth/2+readingGap;
      animalIndex=Math.min(animals.length-1,Math.round(tour));
      if(previous){previous.disabled=animalIndex===0;next.disabled=animalIndex===animals.length-1;counter.textContent=`${animalIndex+1} / ${animals.length}`;}
      if(controls){controls.style.opacity=1-resolve;controls.inert=resolve>.7;}
      animals.forEach((animal,i)=>{
        const delta=i-tour,weight=1-smooth(0,1,Math.abs(delta));
        const sceneX=resolve>0?mainX+(i-(animals.length-1))*24:mainX+delta*80;
        const x=sceneX*(1-resolve)+i*(g.animalWidth+gap)*resolve;
        const opacity=weight+(1-weight)*resolve;
        animal.link.style.transform=`translate3d(${round(x)}px,${round(160*(1-resolve)+125*resolve)}px,0)`;
        animal.link.style.opacity=round(opacity);animal.link.style.zIndex=String(Math.round(weight*10));animal.link.inert=opacity<.15;
        animal.image.style.transform=`scale(${round((1+(portraitScale-1)*weight)*(1-resolve)+resolve)})`;
        animal.label.style.opacity=resolve;
        animal.story.style.left=`${round(textLeft)}px`;
        animal.story.style.opacity=round(weight*(1-resolve));
        animal.story.style.transform=`translate3d(${round(20*(1-weight))}px,0,0)`;
        animal.story.style.visibility=weight*(1-resolve)<.02?'hidden':'visible';
      });
    }
    if(g.cuddle){const c=clamp((y+g.viewport-g.cuddle.top)/(g.cuddle.height+g.viewport));cuddle.style.setProperty('--cuddle-y',`${round(45*(.5-c))}px`);cuddle.style.setProperty('--cuddle-scale',round(1.035+.025*c));cuddle.style.setProperty('--cuddle-x',`${round(35*(1-smooth(.08,.45,c)))}px`);}
    if(g.story){const s=smooth(0,1,(y+g.viewport-g.story.top)/(g.story.height+g.viewport*.4));story.style.setProperty('--story-photo-y',`${round(25*(1-s))}px`);story.style.setProperty('--story-copy-y',`${round(-15*(1-s))}px`);}
  }
  function render(time){
    frame=0;if(document.hidden)return;
    lenis?.raf(time);
    if(immersive){if(dirty)measure();const y=window.scrollY;if(y!==lastY){paint(y);lastY=y;}}
    if(lenis?.isScrolling)wake();
  }
  function wake(){if(!frame&&!document.hidden)frame=requestAnimationFrame(render);}
  addEventListener('scroll',wake,{passive:true});addEventListener('wheel',wake,{passive:true});
  document.addEventListener('click',event=>{
    if(!lenis||event.defaultPrevented||event.button!==0||event.metaKey||event.ctrlKey||event.shiftKey||event.altKey)return;
    const link=event.target.closest('a[href]');if(!link||link.target==='_blank')return;
    const url=new URL(link.href,location.href);if(url.origin!==location.origin||url.pathname!==location.pathname||url.search!==location.search||!url.hash)return;
    let target;try{target=document.getElementById(decodeURIComponent(url.hash.slice(1)));}catch{return;}if(!target)return;
    event.preventDefault();const padding=parseFloat(getComputedStyle(document.documentElement).scrollPaddingTop)||0;
    history.pushState(history.state,'',url.hash);lenis.scrollTo(target.getBoundingClientRect().top+window.scrollY-padding);wake();
  });
  document.addEventListener('keydown',event=>{if(event.key==='Tab'){document.documentElement.setAttribute('data-qz-keyboard','');dirty=true;lastY=-1;wake();}});
  document.addEventListener('pointerdown',()=>{document.documentElement.removeAttribute('data-qz-keyboard');dirty=true;lastY=-1;wake();},{passive:true});
  addEventListener('resize',()=>{dirty=true;lastY=-1;wake();},{passive:true});
  reduced.addEventListener('change',configure);desktop.addEventListener('change',configure);
  document.addEventListener('visibilitychange',()=>{if(document.hidden){cancelAnimationFrame(frame);frame=0;}else{dirty=true;lastY=-1;wake();}});
  if(typeof ResizeObserver==='function'){const observer=new ResizeObserver(()=>{dirty=true;lastY=-1;wake();});[opening,document.querySelector('[data-header]'),departments,cuddle,story].filter(Boolean).forEach(el=>observer.observe(el));}
  document.fonts?.ready.then(()=>{dirty=true;lastY=-1;wake();});
  configure();
})();
