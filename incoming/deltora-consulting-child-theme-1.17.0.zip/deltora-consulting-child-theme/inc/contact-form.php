<?php
/**
 * Validation and delivery for the public contact form.
 *
 * @package DeltoraConsultingChildTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Validate a contact request.
 *
 * @param array<string,mixed> $payload Raw request data.
 * @return array<string,string>|WP_Error
 */
function deltora_consulting_validate_contact_request( $payload ) {
	if ( ! is_array( $payload ) || ! empty( $payload['honeypot'] ) ) {
		return new WP_Error( 'invalid_request', 'La richiesta non è valida.' );
	}

	$name    = sanitize_text_field( wp_unslash( $payload['name'] ?? '' ) );
	$company = sanitize_text_field( wp_unslash( $payload['company'] ?? '' ) );
	$email   = sanitize_email( wp_unslash( $payload['email'] ?? '' ) );
	$phone   = sanitize_text_field( wp_unslash( $payload['phone'] ?? '' ) );
	$subject = sanitize_text_field( wp_unslash( $payload['subject'] ?? '' ) );
	$message = sanitize_textarea_field( wp_unslash( $payload['message'] ?? '' ) );

	if ( '' === $name ) {
		return new WP_Error( 'name_required', 'Inserisci il tuo nome e cognome.' );
	}
	if ( '' === $company ) {
		return new WP_Error( 'company_required', 'Inserisci il nome dell’azienda.' );
	}
	if ( ! is_email( $email ) ) {
		return new WP_Error( 'invalid_email', 'Inserisci un indirizzo email valido.' );
	}
	if ( '' === $subject ) {
		return new WP_Error( 'subject_required', 'Seleziona l’argomento della richiesta.' );
	}
	if ( mb_strlen( $message ) < 20 ) {
		return new WP_Error( 'message_required', 'Descrivi la tua richiesta in almeno 20 caratteri.' );
	}
	if ( empty( $payload['privacy'] ) ) {
		return new WP_Error( 'privacy_required', 'È necessario accettare l’informativa privacy.' );
	}

	return array(
		'name'    => mb_substr( $name, 0, 100 ),
		'company' => mb_substr( $company, 0, 150 ),
		'email'   => $email,
		'phone'   => mb_substr( $phone, 0, 50 ),
		'subject' => mb_substr( $subject, 0, 150 ),
		'message' => mb_substr( $message, 0, 3000 ),
		'session_key' => deltora_consulting_sanitize_session_key( $payload['configurator_session'] ?? '' ),
	);
}

/**
 * Build a plain-text email for Deltora.
 *
 * @param array<string,string> $data Validated request.
 * @return array{to:string,subject:string,message:string,headers:array<int,string>}
 */
function deltora_consulting_build_contact_email( $data ) {
	$contact = deltora_consulting_get_contact_details();
	$lines   = array(
		'Nuova richiesta ricevuta dal sito Deltora Consulting.',
		'',
		'Nome e cognome: ' . $data['name'],
		'Azienda: ' . $data['company'],
		'Email: ' . $data['email'],
		'Telefono: ' . ( $data['phone'] ?: 'Non indicato' ),
		'Argomento: ' . $data['subject'],
		'',
		'Messaggio:',
		$data['message'],
	);

	return array(
		'to'      => $contact['email'],
		'subject' => 'Nuova richiesta dal sito — ' . $data['subject'],
		'message' => implode( "\n", $lines ),
		'headers' => array(
			'Content-Type: text/plain; charset=UTF-8',
			'Reply-To: ' . $data['name'] . ' <' . $data['email'] . '>',
		),
	);
}

/**
 * Deliver one contact request through WordPress mail.
 *
 * @return void
 */
function deltora_consulting_ajax_send_contact_request() {
	check_ajax_referer( 'deltora_contact', 'nonce' );

	$data = deltora_consulting_validate_contact_request( $_POST ); // phpcs:ignore WordPress.Security.NonceVerification.Missing
	if ( is_wp_error( $data ) ) {
		wp_send_json_error( array( 'message' => $data->get_error_message() ), 422 );
	}

	$remote_address = sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ?? 'unknown' ) );
	$rate_key       = 'deltora_contact_' . md5( $remote_address );
	$attempts       = (int) get_transient( $rate_key );
	if ( $attempts >= 5 ) {
		wp_send_json_error( array( 'message' => 'Troppi tentativi ravvicinati. Riprova tra qualche minuto.' ), 429 );
	}
	set_transient( $rate_key, $attempts + 1, 10 * MINUTE_IN_SECONDS );

	// Keep subject and message in the CMS even if the email delivery fails.
	if ( '' !== $data['session_key'] ) {
		deltora_consulting_record_configurator_contact( $data['session_key'], 'contact_request', $data );
	}

	$mail = deltora_consulting_build_contact_email( $data );
	if ( ! wp_mail( $mail['to'], $mail['subject'], $mail['message'], $mail['headers'] ) ) {
		wp_send_json_error( array( 'message' => 'Non è stato possibile inviare la richiesta. Riprova oppure contattaci direttamente via email.' ), 500 );
	}

	wp_send_json_success( array( 'message' => 'La richiesta è stata inviata. Ti ricontatteremo appena possibile.' ) );
}
add_action( 'wp_ajax_deltora_send_contact_request', 'deltora_consulting_ajax_send_contact_request' );
add_action( 'wp_ajax_nopriv_deltora_send_contact_request', 'deltora_consulting_ajax_send_contact_request' );
