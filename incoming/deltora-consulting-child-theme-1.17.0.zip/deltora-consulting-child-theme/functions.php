<?php
/**
 * Deltora Consulting Child Theme functions and definitions.
 *
 * @package DeltoraConsultingChildTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once get_stylesheet_directory() . '/inc/services.php';
require_once get_stylesheet_directory() . '/inc/content-maintenance.php';
require_once get_stylesheet_directory() . '/inc/configurator-config.php';
require_once get_stylesheet_directory() . '/inc/configurator-i18n.php';
require_once get_stylesheet_directory() . '/inc/integrations/zefix-client.php';
require_once get_stylesheet_directory() . '/inc/configurator-company-lookup.php';
require_once get_stylesheet_directory() . '/inc/configurator-company-endpoints.php';
require_once get_stylesheet_directory() . '/inc/configurator-analytics.php';
require_once get_stylesheet_directory() . '/inc/zefix-admin.php';
require_once get_stylesheet_directory() . '/inc/configurator-admin.php';
require_once get_stylesheet_directory() . '/inc/configurator-email.php';
require_once get_stylesheet_directory() . '/inc/contact-form.php';
require_once get_stylesheet_directory() . '/inc/privacy-policy.php';
require_once get_stylesheet_directory() . '/inc/cookie-consent.php';
require_once get_stylesheet_directory() . '/inc/about-page.php';

/**
 * Load the parent and child theme stylesheets.
 *
 * @return void
 */
function deltora_consulting_child_enqueue_styles() {
	$parent_theme = wp_get_theme( get_template() );
	$child_theme  = wp_get_theme();

	wp_dequeue_style( 'ticinoweb-ai-style' );
	wp_deregister_style( 'ticinoweb-ai-style' );
	wp_dequeue_style( 'poppins-font' );
	wp_deregister_style( 'poppins-font' );

	wp_enqueue_style(
		'ticinoweb-ai-parent-style',
		get_template_directory_uri() . '/style.css',
		array(),
		$parent_theme->get( 'Version' )
	);

	wp_enqueue_style(
		'deltora-consulting-child-style',
		get_stylesheet_uri(),
		array( 'ticinoweb-ai-parent-style' ),
		$child_theme->get( 'Version' )
	);

	if ( deltora_consulting_cookie_consent_is_enabled() ) {
		wp_enqueue_style(
			'deltora-consulting-cookie-consent',
			get_stylesheet_directory_uri() . '/assets/css/cookie-consent.css',
			array( 'deltora-consulting-child-style' ),
			$child_theme->get( 'Version' )
		);
	}

	if ( is_front_page() ) {
		wp_enqueue_style( 'dashicons' );
		wp_enqueue_style(
			'deltora-consulting-home-style',
			get_stylesheet_directory_uri() . '/assets/css/home.css',
			array( 'deltora-consulting-child-style' ),
			$child_theme->get( 'Version' )
		);
	}

	if ( is_page( 'servizi' ) ) {
		wp_enqueue_style(
			'deltora-consulting-services-style',
			get_stylesheet_directory_uri() . '/assets/css/services.css',
			array( 'deltora-consulting-child-style' ),
			$child_theme->get( 'Version' )
		);
	}

	if ( is_page( 'chi-siamo' ) ) {
		wp_enqueue_style(
			'deltora-consulting-about-style',
			get_stylesheet_directory_uri() . '/assets/css/about.css',
			array( 'deltora-consulting-child-style' ),
			$child_theme->get( 'Version' )
		);
	}

	if ( is_page( 'configuratore' ) ) {
		wp_enqueue_style(
			'deltora-consulting-configurator-style',
			get_stylesheet_directory_uri() . '/assets/css/configurator.css',
			array( 'deltora-consulting-child-style' ),
			$child_theme->get( 'Version' )
		);
	}

	if ( is_page( 'contatti' ) ) {
		wp_enqueue_style(
			'deltora-consulting-contact-style',
			get_stylesheet_directory_uri() . '/assets/css/contact.css',
			array( 'deltora-consulting-child-style' ),
			$child_theme->get( 'Version' )
		);
	}

	if ( is_privacy_policy() ) {
		wp_enqueue_style(
			'deltora-consulting-privacy-style',
			get_stylesheet_directory_uri() . '/assets/css/privacy.css',
			array( 'deltora-consulting-child-style' ),
			$child_theme->get( 'Version' )
		);
	}

	wp_dequeue_script( 'ticinoweb-ai-main' );
	wp_deregister_script( 'ticinoweb-ai-main' );

	wp_enqueue_script(
		'deltora-consulting-navigation',
		get_stylesheet_directory_uri() . '/assets/js/navigation.js',
		array(),
		$child_theme->get( 'Version' ),
		true
	);
	wp_script_add_data( 'deltora-consulting-navigation', 'strategy', 'defer' );

	if ( deltora_consulting_cookie_consent_is_enabled() ) {
		$cookie_path = wp_parse_url( home_url( '/' ), PHP_URL_PATH );
		$cookie_path = is_string( $cookie_path ) && '' !== $cookie_path ? trailingslashit( $cookie_path ) : '/';

		wp_enqueue_script(
			'deltora-consulting-cookie-consent',
			get_stylesheet_directory_uri() . '/assets/js/cookie-consent.js',
			array(),
			$child_theme->get( 'Version' ),
			true
		);
		wp_localize_script(
			'deltora-consulting-cookie-consent',
			'deltoraConsentConfig',
			array(
				'consentCookie'     => 'deltora_cookie_consent',
				'preferencesCookie' => 'deltora_cookie_preferences',
				'cookiePath'        => $cookie_path,
				'cookieLifetime'    => YEAR_IN_SECONDS,
				'secure'            => is_ssl(),
			)
		);
		wp_script_add_data( 'deltora-consulting-cookie-consent', 'strategy', 'defer' );
	}

	if ( is_front_page() || is_page( array( 'servizi', 'configuratore', 'contatti' ) ) ) {
		wp_enqueue_script(
			'deltora-consulting-gsap',
			get_stylesheet_directory_uri() . '/assets/vendor/gsap/gsap.min.js',
			array(),
			'3.13.0',
			true
		);
		wp_enqueue_script(
			'deltora-consulting-scroll-trigger',
			get_stylesheet_directory_uri() . '/assets/vendor/gsap/ScrollTrigger.min.js',
			array( 'deltora-consulting-gsap' ),
			'3.13.0',
			true
		);
		wp_enqueue_script(
			'deltora-consulting-motion',
			get_stylesheet_directory_uri() . '/assets/js/motion.js',
			array( 'deltora-consulting-scroll-trigger' ),
			$child_theme->get( 'Version' ),
			true
		);
		wp_script_add_data( 'deltora-consulting-gsap', 'strategy', 'defer' );
		wp_script_add_data( 'deltora-consulting-scroll-trigger', 'strategy', 'defer' );
		wp_script_add_data( 'deltora-consulting-motion', 'strategy', 'defer' );
	}

	if ( is_front_page() ) {
		wp_enqueue_script(
			'deltora-consulting-home-motion',
			get_stylesheet_directory_uri() . '/assets/js/home.js',
			array(),
			$child_theme->get( 'Version' ),
			true
		);
		wp_script_add_data( 'deltora-consulting-home-motion', 'strategy', 'defer' );
	}

	if ( is_page( 'configuratore' ) ) {
		wp_enqueue_script(
			'deltora-consulting-configurator-engine',
			get_stylesheet_directory_uri() . '/assets/js/configurator-engine.js',
			array(),
			$child_theme->get( 'Version' ),
			true
		);
		wp_enqueue_script(
			'deltora-consulting-configurator',
			get_stylesheet_directory_uri() . '/assets/js/configurator.js',
			array( 'deltora-consulting-configurator-engine', 'deltora-consulting-gsap' ),
			$child_theme->get( 'Version' ),
			true
		);
		wp_localize_script(
			'deltora-consulting-configurator',
			'deltoraConfiguratorConfig',
			deltora_consulting_localize_configurator_config(
				array_merge(
					deltora_consulting_get_configurator_config(),
					array(
						'ajaxUrl'       => admin_url( 'admin-ajax.php' ),
						'contactUrl'    => add_query_arg( 'argomento', 'valore-impresa', deltora_consulting_get_page_url( 'contatti' ) ),
						'privacyUrl'    => get_privacy_policy_url(),
						'nonce'         => wp_create_nonce( 'deltora_configurator' ),
						'companyLookup' => deltora_consulting_get_company_lookup_capabilities(),
					)
				)
			)
		);
		wp_script_add_data( 'deltora-consulting-configurator-engine', 'strategy', 'defer' );
		wp_script_add_data( 'deltora-consulting-configurator', 'strategy', 'defer' );
	}

	if ( is_page( 'contatti' ) ) {
		wp_enqueue_script(
			'deltora-consulting-contact',
			get_stylesheet_directory_uri() . '/assets/js/contact.js',
			array(),
			$child_theme->get( 'Version' ),
			true
		);
		wp_localize_script(
			'deltora-consulting-contact',
			'deltoraContactConfig',
			array(
				'ajaxUrl' => admin_url( 'admin-ajax.php' ),
				'nonce'   => wp_create_nonce( 'deltora_contact' ),
			)
		);
		wp_script_add_data( 'deltora-consulting-contact', 'strategy', 'defer' );
	}
}
add_action( 'wp_enqueue_scripts', 'deltora_consulting_child_enqueue_styles', 20 );

/**
 * Return the URL for a Deltora page, falling back to the site Home.
 *
 * @param string $slug Page slug.
 * @return string
 */
function deltora_consulting_get_page_url( $slug ) {
	$page = get_page_by_path( sanitize_title( $slug ) );

	if ( $page instanceof WP_Post ) {
		return get_permalink( $page );
	}

	return home_url( '/' );
}

/**
 * Present the EBITDA destination with a benefit-led label in the primary menu.
 *
 * The page slug remains stable so existing links and the calculator logic keep
 * working, while older database-backed menus no longer expose technical copy.
 *
 * @param WP_Post[] $items Menu items.
 * @param stdClass  $args  Menu arguments.
 * @return WP_Post[]
 */
function deltora_consulting_label_value_journey( $items, $args ) {
	if ( empty( $args->theme_location ) || 'primary' !== $args->theme_location ) {
		return $items;
	}

	$journey_url = untrailingslashit( deltora_consulting_get_page_url( 'configuratore' ) );

	foreach ( $items as $item ) {
		if ( $journey_url === untrailingslashit( $item->url ) ) {
			$item->title = __( 'Valore d’impresa', 'deltora-consulting-child-theme' );
		}
	}

	return $items;
}
add_filter( 'wp_nav_menu_objects', 'deltora_consulting_label_value_journey', 10, 2 );

/**
 * Return contact data, using verified Deltora details when CMS fields are empty.
 *
 * @return array{phone:string,email:string,address:string}
 */
function deltora_consulting_get_contact_details() {
	$stored = function_exists( 'ticinoweb_get_contact_info' ) ? ticinoweb_get_contact_info() : array();
	$stored = is_array( $stored ) ? $stored : array();

	$verified = array(
		'phone'   => '+41 (0) 91 826 23 36',
		'email'   => 'info@deltora.ch',
		'address' => 'Via Ferruccio Pelli 2, 6900 Lugano, Svizzera',
	);

	foreach ( $verified as $key => $value ) {
		if ( empty( $stored[ $key ] ) ) {
			$stored[ $key ] = $value;
		}
	}

	if ( empty( $stored['company'] ) ) {
		$stored['company'] = get_theme_mod( 'deltora_company_name', DELTORA_CONSULTING_DEFAULT_COMPANY_NAME );
	}

	return $stored;
}

if ( ! defined( 'DELTORA_CONSULTING_DEFAULT_COMPANY_NAME' ) ) {
	define( 'DELTORA_CONSULTING_DEFAULT_COMPANY_NAME', 'Deltora Legal & Tax SA' );
}

/**
 * Expose the legal company name (footer copyright) in Customizer > Site Identity.
 *
 * @param WP_Customize_Manager $wp_customize Customizer manager.
 */
function deltora_consulting_customize_company_name( $wp_customize ) {
	$wp_customize->add_setting(
		'deltora_company_name',
		array(
			'default'           => DELTORA_CONSULTING_DEFAULT_COMPANY_NAME,
			'sanitize_callback' => 'sanitize_text_field',
			'capability'        => 'edit_theme_options',
		)
	);
	$wp_customize->add_control(
		'deltora_company_name',
		array(
			'label'       => __( 'Ragione sociale', 'deltora-consulting-child-theme' ),
			'description' => __( 'Mostrata nel copyright a fondo pagina.', 'deltora-consulting-child-theme' ),
			'section'     => 'title_tagline',
			'type'        => 'text',
		)
	);
}
add_action( 'customize_register', 'deltora_consulting_customize_company_name' );

/**
 * Never let LiteSpeed cache a page rendered without the language switcher.
 *
 * During a tW Translate Plus update the shortcode can be briefly missing: a
 * page cached in that window would hide the English version until a purge.
 */
function deltora_consulting_nocache_without_language_switcher() {
	if ( ! shortcode_exists( 'tw_language_switcher' ) ) {
		do_action( 'litespeed_control_set_nocache', 'tW Translate language switcher unavailable' );
	}
}
add_action( 'template_redirect', 'deltora_consulting_nocache_without_language_switcher' );

/**
 * Add a stable body class for child-theme selectors.
 *
 * @param string[] $classes Existing body classes.
 * @return string[]
 */
function deltora_consulting_body_classes( $classes ) {
	$classes[] = 'deltora-site';

	return $classes;
}
add_filter( 'body_class', 'deltora_consulting_body_classes' );

/**
 * Let site administrators manage the Privacy policy without granting access
 * to the entire multisite network.
 *
 * WordPress normally maps `manage_privacy_options` to `manage_network` on a
 * multisite installation. Deltora is managed by a site administrator, so the
 * assigned policy page would otherwise appear in the Pages list without an
 * edit link. Mapping it to the existing site-level `manage_options`
 * capability mirrors the standard single-site behaviour.
 *
 * @param string[] $caps    Primitive capabilities required by WordPress.
 * @param string   $cap     Requested meta capability.
 * @param int      $user_id Current user ID.
 * @param mixed[]  $args    Additional capability arguments.
 * @return string[]
 */
function deltora_consulting_map_privacy_capability( $caps, $cap, $user_id, $args ) {
	unset( $user_id, $args );

	if ( 'manage_privacy_options' !== $cap || ! is_multisite() ) {
		return $caps;
	}

	return array( 'manage_options' );
}
add_filter( 'map_meta_cap', 'deltora_consulting_map_privacy_capability', 10, 4 );

/**
 * Add conservative security headers to public responses.
 *
 * A restrictive Content-Security-Policy belongs at hosting level after the
 * production domain and all approved third-party resources are known.
 *
 * @return void
 */
function deltora_consulting_send_security_headers() {
	if ( is_admin() || headers_sent() ) {
		return;
	}

	header_remove( 'X-Powered-By' );
	header( 'X-Content-Type-Options: nosniff' );
	header( 'Referrer-Policy: strict-origin-when-cross-origin' );
	header( 'X-Frame-Options: SAMEORIGIN' );
	header( 'Permissions-Policy: camera=(), microphone=(), geolocation=()' );
}
add_action( 'send_headers', 'deltora_consulting_send_security_headers' );

// The public site has no remote-publishing integration that requires XML-RPC.
add_filter( 'xmlrpc_enabled', '__return_false' );

/**
 * Keep WordPress user records out of the anonymous REST API.
 *
 * Authenticated CMS users retain the standard endpoints.
 *
 * @param array<string,mixed> $endpoints Registered REST endpoints.
 * @return array<string,mixed>
 */
function deltora_consulting_restrict_public_user_endpoints( $endpoints ) {
	if ( is_user_logged_in() ) {
		return $endpoints;
	}

	unset( $endpoints['/wp/v2/users'] );
	unset( $endpoints['/wp/v2/users/(?P<id>[\d]+)'] );

	return $endpoints;
}
add_filter( 'rest_endpoints', 'deltora_consulting_restrict_public_user_endpoints' );
