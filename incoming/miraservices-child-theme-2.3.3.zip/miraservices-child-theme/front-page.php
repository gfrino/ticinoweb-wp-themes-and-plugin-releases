<?php
/**
 * Template Name: Home One-Page
 * Description: Template unificato della Home One-Page di Mira Services SA (Swiss Property Care & Facility Management).
 *
 * @package MiraServicesChildTheme
 */

get_header();

// Dati dinamici da WordPress e ticinoWEB CMS
$mira_sections    = miraservices_get_home_sections();
$mira_services    = miraservices_get_frontend_services();
$mira_slides      = function_exists( 'ticinoweb_get_slider_data' ) ? ticinoweb_get_slider_data() : array();
$mira_contact     = function_exists( 'ticinoweb_get_contact_info' ) ? ticinoweb_get_contact_info() : array();
$mira_phone       = isset( $mira_contact['phone'] ) ? $mira_contact['phone'] : '+41766036214';
$mira_phone_clean = miraservices_phone_uri( $mira_phone );
$mira_phone_disp  = miraservices_format_phone( $mira_phone );
$mira_partners    = miraservices_get_partners();
$mira_reviews     = miraservices_get_reviews();

// Sotto-sezioni Home
$mira_intro     = $mira_sections['intro'];
$mira_srv_sec   = $mira_sections['services'];
$mira_advantage = $mira_sections['advantage'];
$mira_emergency = $mira_sections['emergency'];
$mira_method    = $mira_sections['method'];
$mira_contact_s = $mira_sections['contact'];

$mira_domains = array(
	array(
		'id'     => 'esterni',
		'label'  => __( 'Esterni & Facciate', 'miraservices' ),
		'kicker' => __( 'Involucro & Coperture', 'miraservices' ),
		'desc'   => __( 'Controllo gronde, tetti, intonaci e protezione continua contro umidità e intemperie.', 'miraservices' ),
		'svg'    => '<svg viewBox="0 0 24 24" width="22" height="22" stroke="currentColor" stroke-width="1.8" fill="none" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18M9 21V9M15 21V9"/></svg>',
	),
	array(
		'id'     => 'verde',
		'label'  => __( 'Aree Verdi & Giardini', 'miraservices' ),
		'kicker' => __( 'Paesaggio & Giardini', 'miraservices' ),
		'desc'   => __( 'Sfalcio manti erbosi, potature stagionali, gestione impianti d’irrigazione e trattamenti mirati.', 'miraservices' ),
		'svg'    => '<svg viewBox="0 0 24 24" width="22" height="22" stroke="currentColor" stroke-width="1.8" fill="none" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M11 20A7 7 0 0 1 4 13C4 7 11 3 11 3s7 4 7 10a7 7 0 0 1-7 7Z"/><path d="M11 3v17"/></svg>',
	),
	array(
		'id'     => 'interni',
		'label'  => __( 'Interni & Abitazioni', 'miraservices' ),
		'kicker' => __( 'Residenze & Comfort', 'miraservices' ),
		'desc'   => __( 'Presidio e custodia di residenze secondarie, verifica serramenti, allestimenti e controlli periodici.', 'miraservices' ),
		'svg'    => '<svg viewBox="0 0 24 24" width="22" height="22" stroke="currentColor" stroke-width="1.8" fill="none" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>',
	),
	array(
		'id'     => 'pulizia',
		'label'  => __( 'Pulizia & Igiene', 'miraservices' ),
		'kicker' => __( 'Sanificazione & Cura', 'miraservices' ),
		'desc'   => __( 'Pulizie civili, sanificazione profonda, lavaggio vetrate continue e trattamenti per superfici nobili.', 'miraservices' ),
		'svg'    => '<svg viewBox="0 0 24 24" width="22" height="22" stroke="currentColor" stroke-width="1.8" fill="none" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m12 3-1.9 5.8a2 2 0 0 1-1.3 1.3L3 12l5.8 1.9a2 2 0 0 1 1.3 1.3L12 21l1.9-5.8a2 2 0 0 1 1.3-1.3L21 12l-5.8-1.9a2 2 0 0 1-1.3-1.3Z"/></svg>',
	),
	array(
		'id'     => 'manutenzione',
		'label'  => __( 'Manutenzione & Impianti', 'miraservices' ),
		'kicker' => __( 'Efficienza & Tecnica', 'miraservices' ),
		'desc'   => __( 'Manutenzione preventiva di impianti idraulici, quadri elettrici, riscaldamento e piccoli ripristini.', 'miraservices' ),
		'svg'    => '<svg viewBox="0 0 24 24" width="22" height="22" stroke="currentColor" stroke-width="1.8" fill="none" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"/></svg>',
	),
	array(
		'id'     => 'picchetto',
		'label'  => __( 'Pronto Intervento 24h', 'miraservices' ),
		'kicker' => __( 'Reperibilità 24/7', 'miraservices' ),
		'desc'   => __( 'Squadra di picchetto attiva 24 ore su 24 per allagamenti, perdite idriche e ripristini d’urgenza.', 'miraservices' ),
		'svg'    => '<svg viewBox="0 0 24 24" width="22" height="22" stroke="currentColor" stroke-width="1.8" fill="none" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>',
	),
);
?>
<main id="mira-main" class="mira-home-main">

	<?php /* ============================================================
	   01 — HERO SCENES
	   ============================================================ */ ?>
	<?php if ( ! empty( $mira_slides ) ) : ?>
		<section class="mira-hero" id="home" aria-label="<?php esc_attr_e( 'Introduzione', 'miraservices' ); ?>" data-mira-hero>
			<div class="mira-hero__spotlight" aria-hidden="true"></div>
			<div class="mira-hero__cursor" aria-hidden="true" data-mira-hero-cursor>
				<span class="mira-hero__cursor-lens"></span>
				<span class="mira-hero__cursor-crosshair" aria-hidden="true"></span>
				<span class="mira-hero__cursor-dot"></span>
				<span class="mira-hero__cursor-label">MIRA</span>
			</div>
			<div class="mira-hero__scenes">
				<?php foreach ( $mira_slides as $mira_index => $mira_slide ) : ?>
					<article class="mira-hero__scene<?php echo 0 === $mira_index ? ' is-active' : ''; ?>" data-mira-hero-scene aria-hidden="<?php echo 0 === $mira_index ? 'false' : 'true'; ?>">
						<div class="mira-hero__media" data-mira-hero-media>
							<?php
							echo miraservices_image(
								$mira_slide['image'],
								array(
									'class'         => 'mira-hero__image',
									'alt'           => '',
									'loading'       => 0 === $mira_index ? 'eager' : 'lazy',
									'fetchpriority' => 0 === $mira_index ? 'high' : 'auto',
									'sizes'         => '100vw',
								)
							); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
							?>
						</div>
						<div class="mira-hero__shade" aria-hidden="true"></div>
						<div class="mira-shell mira-hero__content">
							<div class="mira-hero__top-bar">
								<p class="mira-hero__eyebrow">
									<span>MIRA SERVICES SA</span> · <?php esc_html_e( 'Ascona · Ticino', 'miraservices' ); ?>
								</p>
								<?php if ( $mira_phone ) : ?>
									<a class="mira-hero__emergency-badge" href="tel:<?php echo esc_attr( $mira_phone_clean ); ?>">
										<span class="mira-hero__beacon"></span>
										<span>24/7 <?php esc_html_e( 'Picchetto attivo', 'miraservices' ); ?></span>
									</a>
								<?php endif; ?>
							</div>

							<?php if ( 0 === $mira_index ) : ?>
								<h1><?php echo esc_html( ! empty( $mira_slide['title'] ) ? $mira_slide['title'] : __( 'Un solo riferimento per tutto il tuo immobile.', 'miraservices' ) ); ?></h1>
							<?php else : ?>
								<h2><?php echo esc_html( $mira_slide['title'] ); ?></h2>
							<?php endif; ?>

							<p class="mira-hero__copy">
								<?php echo esc_html( ! empty( $mira_slide['desc'] ) ? $mira_slide['desc'] : __( 'Manutenzione, pulizie, verde, ristrutturazioni e interventi coordinati attraverso un unico interlocutore professionale ad Ascona e in tutto il Ticino.', 'miraservices' ) ); ?>
							</p>

							<div class="mira-hero__actions">
								<a class="mira-button mira-button--primary" href="#servizi">
									<span><?php esc_html_e( 'Scopri i servizi', 'miraservices' ); ?></span><i aria-hidden="true">↓</i>
								</a>
								<a class="mira-button mira-button--light" href="<?php echo esc_url( home_url( '/#contatti' ) ); ?>">
									<span><?php esc_html_e( 'Richiedi un preventivo', 'miraservices' ); ?></span><i aria-hidden="true">↗</i>
								</a>
							</div>
						</div>
					</article>
				<?php endforeach; ?>
			</div>

			<div class="mira-hero__status">
				<span data-mira-hero-current>01</span><i></i><span><?php echo esc_html( str_pad( (string) count( $mira_slides ), 2, '0', STR_PAD_LEFT ) ); ?></span>
				<?php if ( count( $mira_slides ) > 1 ) : ?>
					<button class="mira-hero__pause" type="button" data-mira-hero-pause aria-pressed="false" aria-label="<?php esc_attr_e( 'Metti in pausa le scene', 'miraservices' ); ?>" title="<?php esc_attr_e( 'Pausa / Avvia scene', 'miraservices' ); ?>">
						<span class="mira-hero__pause-icon" aria-hidden="true">⏸</span>
					</button>
				<?php endif; ?>
			</div>
			<a class="mira-hero__scroll" href="#chi-siamo" aria-label="<?php esc_attr_e( 'Scorri la pagina', 'miraservices' ); ?>">
				<span><?php esc_html_e( 'Scorri', 'miraservices' ); ?></span><i aria-hidden="true">↓</i>
			</a>
		</section>
	<?php endif; ?>

	<?php /* ============================================================
	   02 — CHI SIAMO / MANIFESTO (Sezione Subito Sotto l'Header)
	   ============================================================ */ ?>
	<section class="mira-manifesto mira-section" id="chi-siamo">
		<span id="manifesto" class="mira-anchor" aria-hidden="true"></span>
		<span id="mira" class="mira-anchor" aria-hidden="true"></span>
		<div class="mira-shell mira-manifesto__layout mira-reveal">
			<div class="mira-manifesto__visual">
				<div class="mira-manifesto__img-frame">
					<img src="<?php echo esc_url( get_stylesheet_directory_uri() . '/assets/images/swiss-residence-portineria.webp' ); ?>" alt="<?php esc_attr_e( 'Residenza contemporanea in Ticino curata da Mira Services', 'miraservices' ); ?>" loading="lazy" width="800" height="600">
				</div>
				<div class="mira-manifesto__caption">
					<span><?php esc_html_e( 'Property Care ad Ascona e nel Locarnese', 'miraservices' ); ?></span>
					<strong><?php esc_html_e( 'Presidio costante sul territorio', 'miraservices' ); ?></strong>
				</div>
			</div>

			<div class="mira-manifesto__content">
				<p class="mira-kicker"><?php esc_html_e( 'Chi Siamo · Mira Services SA · Ticino', 'miraservices' ); ?></p>
				<h2 class="mira-manifesto__title">
					<?php esc_html_e( 'Un immobile ha esigenze diverse. La gestione non deve essere complicata.', 'miraservices' ); ?>
				</h2>
				<p class="mira-manifesto__lead">
					<?php esc_html_e( 'Dalla manutenzione ordinaria alla cura del verde, dalle pulizie periodiche agli interventi urgenti di ripristino: seguire un’abitazione, una villa o un condominio richiede presenza regolare, competenza e metodo svizzero.', 'miraservices' ); ?>
				</p>
				<p class="mira-manifesto__text">
					<?php esc_html_e( 'Mira Services riunisce tutte le competenze operative sotto una regia unica, eliminando continue dispersioni di tempo e garantendo interventi puntuali con un solo referente di fiducia.', 'miraservices' ); ?>
				</p>

				<?php
				$mira_srv_urls = array();
				if ( ! empty( $mira_services ) ) {
					foreach ( $mira_services as $s ) {
						if ( ! empty( $s['id'] ) && ! empty( $s['url'] ) ) {
							$mira_srv_urls[ $s['id'] ] = $s['url'];
						}
					}
				}

				$mira_manifesto_accordions = array(
					array(
						'slug'        => 'manutenzione',
						'chip'        => __( 'Manutenzione', 'miraservices' ),
						'title'       => __( 'Manutenzione ordinaria e gestione tecnica continua', 'miraservices' ),
						'lead'        => __( 'Prevenzione attiva, controlli regolari e interventi tempestivi per mantenere ogni immobile efficiente, sicuro e valorizzato nel tempo.', 'miraservices' ),
						'text'        => __( 'La manutenzione non deve essere una rincorsa ai guasti improvvisi, ma una strategia programmata. Con Mira Services coordiniamo controlli periodici su impianti idraulici ed elettrici, serramenti, sistemi di scolo e coperture per residenze private, ville di vacanza e stabili a reddito. Interveniamo con personale proprio e artigiani fidelizzati ad Ascona e in tutto il Ticino, documentando ogni intervento e azzerando le preoccupazioni del proprietario.', 'miraservices' ),
						'points'      => array(
							__( 'Ispezioni periodiche programmate degli impianti', 'miraservices' ),
							__( 'Piccole riparazioni e manutenzioni correttive immediate', 'miraservices' ),
							__( 'Verifica stagionale serramenti, grondaie e sigillature', 'miraservices' ),
							__( 'Report d’intervento per la proprietà o l’amministrazione', 'miraservices' ),
						),
						'service_url' => isset( $mira_srv_urls['manutenzione-immobili'] ) ? $mira_srv_urls['manutenzione-immobili'] : home_url( '/#servizi' ),
						'link_label'  => __( 'Scheda manutenzione immobili', 'miraservices' ),
					),
					array(
						'slug'        => 'pulizie',
						'chip'        => __( 'Pulizie', 'miraservices' ),
						'title'       => __( 'Pulizie civili, sanificazione e cura meticolosa delle superfici', 'miraservices' ),
						'lead'        => __( 'Interventi professionali con standard svizzeri, prodotti ecologici e metodologie specifiche per pavimenti, ampie vetrate e spazi comuni.', 'miraservices' ),
						'text'        => __( 'Garantiamo igiene profonda e valorizzazione estetica di ogni ambiente. Dai cicli settimanali in appartamenti e complessi condominiali alle pulizie di fino post-cantiere o prima del cambio inquilino: operiamo con macchinari professionali all’avanguardia e detergenti eco-certificati. Ci prendiamo cura di materiali nobili come marmo, parquet oliato, gres e pietre naturali ticinesi con protocolli dedicati e personale selezionato, assunto e assicurato.', 'miraservices' ),
						'points'      => array(
							__( 'Pulizie continuative per condomini, uffici e residenze private', 'miraservices' ),
							__( 'Trattamenti protettivi per marmo, parquet e pietre naturali', 'miraservices' ),
							__( 'Lavaggio vetrate e facciate continue con sistemi ad acqua pura', 'miraservices' ),
							__( 'Interventi intensivi di sgrosso e pulizia fine cantiere', 'miraservices' ),
						),
						'service_url' => isset( $mira_srv_urls['pulizie'] ) ? $mira_srv_urls['pulizie'] : home_url( '/#servizi' ),
						'link_label'  => __( 'Scheda servizi pulizia', 'miraservices' ),
					),
					array(
						'slug'        => 'verde',
						'chip'        => __( 'Verde', 'miraservices' ),
						'title'       => __( 'Cura paesaggistica, giardinaggio stagionale e aree verdi', 'miraservices' ),
						'lead'        => __( 'Gestione agronomica completa per valorizzare il verde privato e condominiale in ogni stagione del clima ticinese.', 'miraservices' ),
						'text'        => __( 'I giardini ad Ascona e sulle sponde del Verbano richiedono attenzioni agronomiche calibrate: sfalcio e rigenerazione dei manti erbosi, arieggiatura, concimazioni organiche, potature di contenimento per siepi e piante da frutto, e cura di alberature ad alto fusto. Controlliamo e programmiamo gli impianti di irrigazione automatica per ridurre gli sprechi idrici e assicuriamo ripristini rapidi dopo temporali o eventi atmosferici intensi.', 'miraservices' ),
						'points'      => array(
							__( 'Manutenzione programmata prati, bordure e aiuole fiorite', 'miraservices' ),
							__( 'Potature stagionali, sagomatura siepi e sfalcio erba', 'miraservices' ),
							__( 'Taratura, manutenzione e svuotamento invernale irrigazione', 'miraservices' ),
							__( 'Smaltimento verde e interventi rapidi post-maltempo', 'miraservices' ),
						),
						'service_url' => isset( $mira_srv_urls['giardinaggio'] ) ? $mira_srv_urls['giardinaggio'] : home_url( '/#servizi' ),
						'link_label'  => __( 'Scheda cura del verde', 'miraservices' ),
					),
					array(
						'slug'        => 'custodia',
						'chip'        => __( 'Custodia', 'miraservices' ),
						'title'       => __( 'Portineria, custodia fiduciaria e presidio dell’immobile', 'miraservices' ),
						'lead'        => __( 'Un punto di riferimento presente e discreto sul posto per vigilare sullo stabile, assistere i residenti e gestire gli accessi.', 'miraservices' ),
						'text'        => __( 'Seguire un condominio o una seconda casa disabitata per mesi richiede presenza fiduciaria costante. Mira Services offre servizi di portineria e custodia dedicati: supervisione degli accessi, gestione delle consegne postali, controllo del funzionamento degli impianti comuni, accoglienza di periti e fornitori esterni. Per le case di vacanza effettuiamo controlli regolari con aerazione dei locali, verifica allacciamenti e preparazione dell’immobile prima dell’arrivo dei proprietari.', 'miraservices' ),
						'points'      => array(
							__( 'Presidio e sorveglianza fiduciaria degli accessi e spazi comuni', 'miraservices' ),
							__( 'Custodia sicura chiavi e accoglienza tecnici o corrieri', 'miraservices' ),
							__( 'Ispezioni regolari e report fotografici per seconde case', 'miraservices' ),
							__( 'Accoglienza residenti e gestione tempestiva delle segnalazioni', 'miraservices' ),
						),
						'service_url' => isset( $mira_srv_urls['portineria-custodia'] ) ? $mira_srv_urls['portineria-custodia'] : home_url( '/#servizi' ),
						'link_label'  => __( 'Scheda portineria e custodia', 'miraservices' ),
					),
					array(
						'slug'        => 'ristrutturazioni',
						'chip'        => __( 'Ristrutturazioni', 'miraservices' ),
						'title'       => __( 'Ristrutturazioni chiavi in mano, piccola muratura e tinteggiature', 'miraservices' ),
						'lead'        => __( 'Rinnoviamo gli ambienti con un unico referente di cantiere, tempi certi e preventivi chiari a corpo.', 'miraservices' ),
						'text'        => __( 'Dalla tinteggiatura interna ed esterna al rifacimento completo di bagni, cucine e pavimentazioni: coordiniamo muratori, idraulici, elettricisti e posatori sotto una direzione lavori integrata. Eliminiamo i frequenti problemi di ritardi e sovrapposizioni tra artigiani diversi: con Mira Services hai un unico cronoprogramma, capitolati trasparenti e la garanzia di finiture a regola d’arte, pulizia finale e collaudo certificato.', 'miraservices' ),
						'points'      => array(
							__( 'Tinteggiature di pregio e risanamento intonaci/umidità', 'miraservices' ),
							__( 'Ristrutturazione completa bagni, cucine e ambienti abitativi', 'miraservices' ),
							__( 'Opere di muratura, cartongesso, isolamenti e pavimentazioni', 'miraservices' ),
							__( 'Direzione lavori unica con rispetto rigoroso di tempi e budget', 'miraservices' ),
						),
						'service_url' => isset( $mira_srv_urls['ristrutturazioni'] ) ? $mira_srv_urls['ristrutturazioni'] : home_url( '/#servizi' ),
						'link_label'  => __( 'Scheda ristrutturazioni', 'miraservices' ),
					),
					array(
						'slug'        => '24h',
						'chip'        => __( '24H Picchetto', 'miraservices' ),
						'title'       => __( 'Picchetto attivo 24 ore su 24 per emergenze e guasti critici', 'miraservices' ),
						'lead'        => __( 'Reperibilità costante giorno e notte per risolvere allagamenti, guasti elettrici, aperture porte e danni urgenti.', 'miraservices' ),
						'text'        => __( 'Quando si verifica una perdita d’acqua improvvisa nella notte o si blocca il cancello d’ingresso durante il weekend, serve un intervento immediato sul posto. Il servizio picchetto di Mira Services è operativo 24 ore su 24, 7 giorni su 7 per tutto il territorio di Ascona, Locarno e del Cantone Ticino. I nostri tecnici intervengono con veicoli attrezzati per contenere il danno, ripristinare i servizi essenziali e programmare le eventuali riparazioni definitive.', 'miraservices' ),
						'points'      => array(
							__( 'Disponibilità continuativa 24/7/365 senza interruzioni', 'miraservices' ),
							__( 'Messa in sicurezza immediata di impianti idraulici ed elettrici', 'miraservices' ),
							__( 'Risoluzione serrature bloccate e danni improvvisi da maltempo', 'miraservices' ),
							__( 'Chiamata diretta con reperibilità operativa locale sul territorio', 'miraservices' ),
						),
						'service_url' => isset( $mira_srv_urls['picchetto-24h'] ) ? $mira_srv_urls['picchetto-24h'] : home_url( '/#servizi' ),
						'link_label'  => __( 'Scheda picchetto 24h', 'miraservices' ),
					),
				);
				?>

				<div class="mira-manifesto__strip-wrap" data-mira-strip-accordion>
					<div class="mira-manifesto__strip" role="tablist" aria-label="<?php esc_attr_e( 'Ambiti di intervento Mira Services', 'miraservices' ); ?>">
						<?php foreach ( $mira_manifesto_accordions as $mira_acc_idx => $mira_acc ) : ?>
							<button class="mira-manifesto__chip"
									type="button"
									id="mira-chip-<?php echo esc_attr( $mira_acc['slug'] ); ?>"
									role="tab"
									aria-selected="false"
									aria-expanded="false"
									aria-controls="mira-panel-<?php echo esc_attr( $mira_acc['slug'] ); ?>"
									data-target="<?php echo esc_attr( $mira_acc['slug'] ); ?>">
								<span class="mira-manifesto__chip-text"><?php echo esc_html( $mira_acc['chip'] ); ?></span>
								<span class="mira-manifesto__chip-icon" aria-hidden="true">+</span>
							</button>
							<?php if ( $mira_acc_idx < count( $mira_manifesto_accordions ) - 1 ) : ?>
								<i class="mira-manifesto__strip-sep" aria-hidden="true">·</i>
							<?php endif; ?>
						<?php endforeach; ?>
					</div>

					<div class="mira-manifesto__drawer" id="mira-manifesto-drawer" aria-live="polite">
						<?php foreach ( $mira_manifesto_accordions as $mira_acc_idx => $mira_acc ) : ?>
							<div class="mira-manifesto__panel"
								 id="mira-panel-<?php echo esc_attr( $mira_acc['slug'] ); ?>"
								 role="tabpanel"
								 aria-labelledby="mira-chip-<?php echo esc_attr( $mira_acc['slug'] ); ?>"
								 data-slug="<?php echo esc_attr( $mira_acc['slug'] ); ?>"
								 hidden>
								<div class="mira-manifesto__card">
									<div class="mira-manifesto__card-header">
										<div class="mira-manifesto__card-head-left">
											<span class="mira-manifesto__card-chip"><?php echo esc_html( $mira_acc['chip'] ); ?></span>
											<h3 class="mira-manifesto__card-title"><?php echo esc_html( $mira_acc['title'] ); ?></h3>
										</div>
										<button type="button" class="mira-manifesto__card-close" aria-label="<?php esc_attr_e( 'Chiudi dettaglio', 'miraservices' ); ?>" data-mira-strip-close>
											<span aria-hidden="true">✕</span>
										</button>
									</div>

									<p class="mira-manifesto__card-lead"><?php echo esc_html( $mira_acc['lead'] ); ?></p>
									<p class="mira-manifesto__card-text"><?php echo esc_html( $mira_acc['text'] ); ?></p>

									<ul class="mira-manifesto__card-points">
										<?php foreach ( $mira_acc['points'] as $mira_point ) : ?>
											<li>
												<span class="mira-manifesto__card-check" aria-hidden="true">✓</span>
												<span><?php echo esc_html( $mira_point ); ?></span>
											</li>
										<?php endforeach; ?>
									</ul>

									<div class="mira-manifesto__card-footer">
										<a class="mira-arrow-link" href="<?php echo esc_url( $mira_acc['service_url'] ); ?>">
											<span><?php echo esc_html( $mira_acc['link_label'] ); ?></span><i aria-hidden="true">↗</i>
										</a>
									</div>
								</div>
							</div>
						<?php endforeach; ?>
					</div>
				</div>
			</div>
		</div>
		<div class="mira-continuity-line" aria-hidden="true"><span></span></div>
	</section>

	<?php /* ============================================================
	   03 — SERVIZI (Layout Sticky a 2 Colonne Compatto)
	   ============================================================ */ ?>
	<?php if ( ! empty( $mira_services ) ) : ?>
		<section class="mira-services mira-section" id="servizi" data-mira-services>
			<div class="mira-shell">
				<header class="mira-services__header mira-reveal">
					<p class="mira-kicker"><?php esc_html_e( 'I nostri servizi', 'miraservices' ); ?></p>
					<div class="mira-services__header-grid">
						<h2><?php echo esc_html( ! empty( $mira_srv_sec['title'] ) ? $mira_srv_sec['title'] : __( 'Dall’interno all’esterno, seguiamo ogni spazio.', 'miraservices' ) ); ?></h2>
						<p><?php echo esc_html( ! empty( $mira_srv_sec['text'] ) ? $mira_srv_sec['text'] : __( 'Servizi complementari pensati per lavorare insieme: un’esigenza specifica può essere risolta con un singolo intervento puntuale oppure trasformarsi in una gestione continuativa e programmata.', 'miraservices' ) ); ?></p>
					</div>
				</header>

				<!-- Master-Detail Interactive Showcase (Smooth, Zero Scroll-Lock) -->
				<div class="mira-showcase" data-mira-showcase>
					<!-- Left: Visual Stage -->
					<div class="mira-showcase__stage">
						<?php foreach ( $mira_services as $mira_index => $mira_service ) : ?>
							<figure class="mira-showcase__panel<?php echo 0 === $mira_index ? ' is-active' : ''; ?>" id="mira-panel-<?php echo esc_attr( $mira_index ); ?>" data-mira-panel="<?php echo esc_attr( $mira_index ); ?>" aria-hidden="<?php echo 0 === $mira_index ? 'false' : 'true'; ?>">
								<?php
								echo miraservices_image(
									$mira_service['image'],
									array(
										'class' => 'mira-showcase__img',
										'alt'   => $mira_service['title'],
										'sizes' => '(min-width: 1100px) 52vw, 100vw',
									)
								); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
								?>
								<div class="mira-showcase__shade" aria-hidden="true"></div>
								<figcaption class="mira-showcase__caption">
									<span class="mira-showcase__badge">
										<?php echo esc_html( str_pad( (string) $mira_service['index'], 2, '0', STR_PAD_LEFT ) ); ?> / <?php echo esc_html( str_pad( (string) count( $mira_services ), 2, '0', STR_PAD_LEFT ) ); ?>
										<?php if ( $mira_service['is_emergency'] ) : ?> · 24/7 PICCHETTO<?php endif; ?>
									</span>
									<h3><?php echo esc_html( $mira_service['title'] ); ?></h3>
									<p><?php echo esc_html( $mira_service['description'] ); ?></p>
									<a class="mira-button mira-button--light" href="<?php echo esc_url( $mira_service['url'] ); ?>">
										<span><?php echo esc_html( sprintf( __( 'Scopri %s', 'miraservices' ), $mira_service['title'] ) ); ?></span>
										<i aria-hidden="true">↗</i>
									</a>
								</figcaption>
							</figure>
						<?php endforeach; ?>
					</div>

					<!-- Right: Interactive Service Selector -->
					<div class="mira-showcase__nav" role="tablist" aria-label="<?php esc_attr_e( 'Elenco servizi Mira Services', 'miraservices' ); ?>">
						<?php foreach ( $mira_services as $mira_index => $mira_service ) : ?>
							<button class="mira-showcase__tab<?php echo 0 === $mira_index ? ' is-active' : ''; ?>"
									type="button"
									role="tab"
									aria-selected="<?php echo 0 === $mira_index ? 'true' : 'false'; ?>"
									aria-controls="mira-panel-<?php echo esc_attr( $mira_index ); ?>"
									data-mira-tab="<?php echo esc_attr( $mira_index ); ?>">
								<span class="mira-showcase__tab-num"><?php echo esc_html( str_pad( (string) $mira_service['index'], 2, '0', STR_PAD_LEFT ) ); ?></span>
								<div class="mira-showcase__tab-text">
									<strong><?php echo esc_html( $mira_service['title'] ); ?></strong>
									<small><?php echo esc_html( wp_trim_words( $mira_service['description'], 9, '...' ) ); ?></small>
								</div>
								<i class="mira-showcase__tab-arrow" aria-hidden="true">↗</i>
							</button>
						<?php endforeach; ?>
					</div>
				</div>
			</div>
		</section>
	<?php endif; ?>

	<?php /* ============================================================
	   04 — UN UNICO REFERENTE (Ecosistema Operativo a Regia Unica)
	   ============================================================ */ ?>
	<section class="mira-reference mira-section" id="perche-mira">
		<div class="mira-shell">
			<div class="mira-reference__intro mira-reveal">
				<p class="mira-kicker"><?php esc_html_e( 'Coordinamento integrato', 'miraservices' ); ?></p>
				<h2><?php echo esc_html( ! empty( $mira_advantage['title'] ) ? $mira_advantage['title'] : __( 'Meno interlocutori. Più controllo.', 'miraservices' ) ); ?></h2>
				<p class="mira-reference__lead">
					<?php echo esc_html( ! empty( $mira_advantage['text'] ) ? $mira_advantage['text'] : __( 'Coordinare idraulici, giardinieri, imprese di pulizia e artigiani diversi comporta continue dispersioni di tempo, costi duplicati e responsabilità frammentate. Con Mira Services hai un unico punto di contatto che conosce l’immobile nella sua totalità, programma gli interventi e verifica la qualità di ogni lavorazione.', 'miraservices' ) ); ?>
				</p>
			</div>

			<div class="mira-reference__ecosystem mira-reveal" aria-label="<?php esc_attr_e( 'Ecosistema operativo Mira Services', 'miraservices' ); ?>">
				
				<!-- Colonna Hub: Centro di Regia Unica -->
				<div class="mira-reference__hub">
					<div class="mira-reference__hub-card">
						<div class="mira-reference__hub-header">
							<span class="mira-reference__hub-badge">
								<span class="mira-reference__hub-pulse" aria-hidden="true"></span>
								<?php esc_html_e( 'Regia Operativa Unica', 'miraservices' ); ?>
							</span>
							<span class="mira-reference__hub-origin"><?php esc_html_e( 'Ascona · Ticino', 'miraservices' ); ?></span>
						</div>

						<div class="mira-reference__hub-body">
							<h3 class="mira-reference__hub-title">
								<?php esc_html_e( 'Un solo referente di fiducia. Tutta la gestione sotto controllo.', 'miraservices' ); ?>
							</h3>
							<p class="mira-reference__hub-text">
								<?php esc_html_e( 'Eliminiamo la dispersione tra ditte diverse. Centralizziamo le comunicazioni, verifichiamo la qualità di ogni lavoro e rispondiamo in prima persona.', 'miraservices' ); ?>
							</p>

							<ul class="mira-reference__hub-points" role="list">
								<li>
									<span class="mira-reference__hub-check" aria-hidden="true">✓</span>
									<span><strong><?php esc_html_e( 'Interlocutore dedicato:', 'miraservices' ); ?></strong> <?php esc_html_e( 'un solo numero da chiamare per qualsiasi esigenza ordinaria o urgente.', 'miraservices' ); ?></span>
								</li>
								<li>
									<span class="mira-reference__hub-check" aria-hidden="true">✓</span>
									<span><strong><?php esc_html_e( 'Storico centralizzato:', 'miraservices' ); ?></strong> <?php esc_html_e( 'conosciamo ogni impianto, chiave e particolarità tecnica del vostro stabile.', 'miraservices' ); ?></span>
								</li>
								<li>
									<span class="mira-reference__hub-check" aria-hidden="true">✓</span>
									<span><strong><?php esc_html_e( 'Zero spese duplicate:', 'miraservices' ); ?></strong> <?php esc_html_e( 'sinergia reale tra le squadre, nessun costo di uscita frammentato.', 'miraservices' ); ?></span>
								</li>
							</ul>
						</div>

						<div class="mira-reference__hub-footer">
							<div class="mira-reference__hub-status">
								<span class="mira-live-dot" aria-hidden="true"></span>
								<span><?php esc_html_e( 'Presidio attivo nel Locarnese', 'miraservices' ); ?></span>
							</div>
							<a class="mira-reference__hub-cta" href="<?php echo esc_url( home_url( '/#contatti' ) ); ?>">
								<span><?php esc_html_e( 'Parla con noi', 'miraservices' ); ?></span>
								<i aria-hidden="true">→</i>
							</a>
						</div>
					</div>
				</div>

				<!-- Colonna Griglia: I 6 Ambiti Operativi Connessi -->
				<div class="mira-reference__grid">
					<?php foreach ( $mira_domains as $mira_i => $mira_domain ) : ?>
						<article class="mira-reference__pillar">
							<div class="mira-reference__pillar-top">
								<span class="mira-reference__pillar-icon" aria-hidden="true">
									<?php echo $mira_domain['svg']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
								</span>
								<span class="mira-reference__pillar-num"><?php echo esc_html( str_pad( (string) ( $mira_i + 1 ), 2, '0', STR_PAD_LEFT ) ); ?></span>
							</div>
							<div class="mira-reference__pillar-content">
								<span class="mira-reference__pillar-kicker"><?php echo esc_html( $mira_domain['kicker'] ); ?></span>
								<h4 class="mira-reference__pillar-title"><?php echo esc_html( $mira_domain['label'] ); ?></h4>
								<p class="mira-reference__pillar-desc"><?php echo esc_html( $mira_domain['desc'] ); ?></p>
							</div>
						</article>
					<?php endforeach; ?>
				</div>

				<!-- Ribbon di Sintesi Operativa -->
				<div class="mira-reference__ribbon">
					<div class="mira-reference__ribbon-item">
						<span class="mira-reference__ribbon-val">1</span>
						<div class="mira-reference__ribbon-text">
							<strong><?php esc_html_e( 'Contratto Quadro', 'miraservices' ); ?></strong>
							<span><?php esc_html_e( 'Fatturazione unica, chiara e trasparente', 'miraservices' ); ?></span>
						</div>
					</div>
					<div class="mira-reference__ribbon-item">
						<span class="mira-reference__ribbon-val">6+</span>
						<div class="mira-reference__ribbon-text">
							<strong><?php esc_html_e( 'Ambiti Coordinati', 'miraservices' ); ?></strong>
							<span><?php esc_html_e( 'Dalla manutenzione ordinaria al picchetto 24h', 'miraservices' ); ?></span>
						</div>
					</div>
					<div class="mira-reference__ribbon-item">
						<span class="mira-reference__ribbon-val">100%</span>
						<div class="mira-reference__ribbon-text">
							<strong><?php esc_html_e( 'Precisione Svizzera', 'miraservices' ); ?></strong>
							<span><?php esc_html_e( 'Standard qualitativi elevati e report costanti', 'miraservices' ); ?></span>
						</div>
					</div>
				</div>

			</div>
		</div>
	</section>

	<?php /* ============================================================
	   05 — PROPERTY CARE / COSA GESTIAMO (Nuova Sezione Asimmetrica)
	   ============================================================ */ ?>
	<section class="mira-property-care mira-section" id="property-care">
		<div class="mira-shell">
			<header class="mira-property-care__header mira-reveal">
				<p class="mira-kicker"><?php esc_html_e( 'Ambiti di gestione', 'miraservices' ); ?></p>
				<div class="mira-property-care__title-block">
					<h2><?php esc_html_e( 'Seguiamo l’immobile, non solo il singolo intervento.', 'miraservices' ); ?></h2>
					<p><?php esc_html_e( 'Dalla villa privata che necessita di cura e sorveglianza stagionale, allo stabile a reddito con inquilini, fino agli uffici operativi: strutturiamo soluzioni flessibili e su misura per ogni committente.', 'miraservices' ); ?></p>
				</div>
			</header>

			<div class="mira-property-care__scenarios">
				<!-- Scenario 1: Abitazioni & Ville (Formato Grande) -->
				<article class="mira-care-card mira-care-card--feature mira-reveal">
					<div class="mira-care-card__media">
						<img src="<?php echo esc_url( get_stylesheet_directory_uri() . '/assets/images/swiss-residence-portineria.webp' ); ?>" alt="<?php esc_attr_e( 'Abitazioni e ville moderne in Ticino', 'miraservices' ); ?>" loading="lazy" width="800" height="520">
					</div>
					<div class="mira-care-card__body">
						<span class="mira-kicker"><?php esc_html_e( 'Residenziale privato', 'miraservices' ); ?></span>
						<h3><?php esc_html_e( 'Abitazioni & Ville', 'miraservices' ); ?></h3>
						<p><?php esc_html_e( 'Cura meticolosa per residenze primarie e seconde case nel Locarnese: manutenzione programmata, verde sempre perfetto, ripristini tempestivi e controlli regolari anche durante i periodi di assenza dei proprietari.', 'miraservices' ); ?></p>
						<ul class="mira-care-card__list">
							<li><?php esc_html_e( 'Custodia e verifica impianti', 'miraservices' ); ?></li>
							<li><?php esc_html_e( 'Manutenzione giardini e terrazze', 'miraservices' ); ?></li>
							<li><?php esc_html_e( 'Pulizie di apertura e sanificazione', 'miraservices' ); ?></li>
						</ul>
					</div>
				</article>

				<div class="mira-property-care__subgrid">
					<!-- Scenario 2: Condomini & Amministrazioni -->
					<article class="mira-care-card mira-care-card--split mira-reveal">
						<div class="mira-care-card__media">
							<img src="<?php echo esc_url( get_stylesheet_directory_uri() . '/assets/images/mira-picchetto-night.webp' ); ?>" alt="<?php esc_attr_e( 'Condomini e stabili amministrati in Svizzera', 'miraservices' ); ?>" loading="lazy" width="600" height="400">
						</div>
						<div class="mira-care-card__body">
							<span class="mira-kicker"><?php esc_html_e( 'Gestione condominiale', 'miraservices' ); ?></span>
							<h3><?php esc_html_e( 'Condomini & Amministrazioni', 'miraservices' ); ?></h3>
							<p><?php esc_html_e( 'Il braccio operativo fidato per gli amministratori immobiliari: pulizia scale, cura degli spazi comuni, portineria attiva e gestione tempestiva delle segnalazioni dei condòmini.', 'miraservices' ); ?></p>
							<a class="mira-arrow-link" href="<?php echo esc_url( home_url( '/#contatti' ) ); ?>">
								<span><?php esc_html_e( 'Piani per amministrazioni', 'miraservices' ); ?></span><i aria-hidden="true">↗</i>
							</a>
						</div>
					</article>

					<!-- Scenario 3: Aziende & Spazi Professionali -->
					<article class="mira-care-card mira-care-card--split mira-reveal">
						<div class="mira-care-card__media">
							<img src="<?php echo esc_url( get_stylesheet_directory_uri() . '/assets/images/swiss-commercial-office.webp' ); ?>" alt="<?php esc_attr_e( 'Aziende e spazi professionali curati da Mira', 'miraservices' ); ?>" loading="lazy" width="600" height="400">
						</div>
						<div class="mira-care-card__body">
							<span class="mira-kicker"><?php esc_html_e( 'Spazi professionali', 'miraservices' ); ?></span>
							<h3><?php esc_html_e( 'Aziende & Spazi Professionali', 'miraservices' ); ?></h3>
							<p><?php esc_html_e( 'Interventi pianificati e riservati per uffici, negozi e sedi operative, organizzati negli orari più comodi per non interferire con il lavoro quotidiano e garantire sempre ambienti decorosi.', 'miraservices' ); ?></p>
							<a class="mira-arrow-link" href="<?php echo esc_url( home_url( '/#contatti' ) ); ?>">
								<span><?php esc_html_e( 'Piani per aziende', 'miraservices' ); ?></span><i aria-hidden="true">↗</i>
							</a>
						</div>
					</article>
				</div>
			</div>
		</div>
	</section>

	<?php /* ============================================================
	   06 — PICCHETTO 24H (Command Center Bilanciato & Autorevole)
	   ============================================================ */ ?>
	<section class="mira-emergency mira-section" id="picchetto" data-mira-emergency>
		<div class="mira-shell">
			<div class="mira-emergency__grid mira-reveal">

				<!-- Colonna Sinistra: Visual Stage & Presidio Live -->
				<div class="mira-emergency__visual-card">
					<div class="mira-emergency__media">
						<img src="<?php echo esc_url( get_stylesheet_directory_uri() . '/assets/images/mira-picchetto-night.webp' ); ?>" alt="<?php esc_attr_e( 'Residenza contemporanea protetta dal servizio picchetto Mira Services ad Ascona', 'miraservices' ); ?>" loading="lazy" width="800" height="600">
						<div class="mira-emergency__media-overlay"></div>
					</div>

					<div class="mira-emergency__stage-content">
						<div class="mira-emergency__live-badge">
							<span class="mira-emergency__dot" aria-hidden="true"></span>
							<strong>24/7 <?php esc_html_e( 'ATTIVO ORA', 'miraservices' ); ?></strong>
							<span class="mira-emergency__live-sep" aria-hidden="true">·</span>
							<span><?php esc_html_e( 'Notturni & Festivi', 'miraservices' ); ?></span>
						</div>

						<div class="mira-emergency__stage-middle">
							<div class="mira-emergency__territory-pill">
								<svg viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>
								<div>
									<strong><?php esc_html_e( 'Locarnese, Ascona & Bellinzonese', 'miraservices' ); ?></strong>
									<span><?php esc_html_e( 'Mezzi d’intervento rapido sul territorio', 'miraservices' ); ?></span>
								</div>
							</div>
						</div>

						<div class="mira-emergency__stage-foot">
							<p class="mira-emergency__chips-label"><?php esc_html_e( 'Interventi prioritari per:', 'miraservices' ); ?></p>
							<div class="mira-emergency__chips">
								<span class="mira-emergency__chip">
									<svg viewBox="0 0 24 24" width="14" height="14" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 2.69l5.66 5.66a8 8 0 1 1-11.31 0z"/></svg>
									<?php esc_html_e( 'Perdite & Scarichi', 'miraservices' ); ?>
								</span>
								<span class="mira-emergency__chip">
									<svg viewBox="0 0 24 24" width="14" height="14" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>
									<?php esc_html_e( 'Guasti Elettrici', 'miraservices' ); ?>
								</span>
								<span class="mira-emergency__chip">
									<svg viewBox="0 0 24 24" width="14" height="14" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m21 2-2 2m-6 6 7 7-2 2-7-7m0 0a5 5 0 1 1-7-7 5 5 0 0 1 7 7zm-5 1 2 2"/></svg>
									<?php esc_html_e( 'Accessi & Porte', 'miraservices' ); ?>
								</span>
								<span class="mira-emergency__chip">
									<svg viewBox="0 0 24 24" width="14" height="14" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M17.5 19H9a7 7 0 1 1 6.71-9h1.79a4.5 4.5 0 1 1 0 9Z"/><path d="m11 13-2 4h4l-2 4"/></svg>
									<?php esc_html_e( 'Danni da Maltempo', 'miraservices' ); ?>
								</span>
							</div>
						</div>
					</div>
				</div>

				<!-- Colonna Destra: Informazioni Operative, Garanzie e Chiamata Diretta -->
				<div class="mira-emergency__content-card">
					<div class="mira-emergency__content-head">
						<p class="mira-kicker mira-kicker--light">
							<span class="mira-emergency__dot" aria-hidden="true"></span>
							<?php echo esc_html( ! empty( $mira_emergency['eyebrow'] ) ? $mira_emergency['eyebrow'] : __( 'Pronto intervento 24 ore su 24', 'miraservices' ) ); ?>
						</p>
						<h2 class="mira-emergency__title">
							<?php echo esc_html( ! empty( $mira_emergency['title'] ) ? $mira_emergency['title'] : __( 'Ci sono problemi che non possono aspettare.', 'miraservices' ) ); ?>
						</h2>
						<p class="mira-emergency__lead">
							<?php
							$mira_em_text = ! empty( $mira_emergency['text'] ) ? $mira_emergency['text'] : '';
							if ( mb_strlen( $mira_em_text ) < 100 ) {
								$mira_em_text = __( 'Per le necessità urgenti è attivo il presidio continuo Mira Services: allagamenti, guasti tecnici, porte bloccate o danni da intemperie gestiti con tempestività e metodo svizzero.', 'miraservices' );
							}
							echo esc_html( $mira_em_text );
							?>
						</p>
					</div>

					<div class="mira-emergency__commitments">
						<div class="mira-emergency__commitment-item">
							<div class="mira-emergency__commitment-icon" aria-hidden="true">
								<svg viewBox="0 0 24 24" width="18" height="18" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/></svg>
							</div>
							<div class="mira-emergency__commitment-text">
								<strong><?php esc_html_e( 'Risposta Diretta Senza Centralini', 'miraservices' ); ?></strong>
								<p><?php esc_html_e( 'Nessuna segreteria: risponde subito il coordinatore che invia la squadra sul posto.', 'miraservices' ); ?></p>
							</div>
						</div>

						<div class="mira-emergency__commitment-item">
							<div class="mira-emergency__commitment-icon" aria-hidden="true">
								<svg viewBox="0 0 24 24" width="18" height="18" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
							</div>
							<div class="mira-emergency__commitment-text">
								<strong><?php esc_html_e( 'Messa in Sicurezza Tempestiva', 'miraservices' ); ?></strong>
								<p><?php esc_html_e( 'Priorità al blocco immediato del danno e alla protezione della struttura immobiliare.', 'miraservices' ); ?></p>
							</div>
						</div>

						<div class="mira-emergency__commitment-item">
							<div class="mira-emergency__commitment-icon" aria-hidden="true">
								<svg viewBox="0 0 24 24" width="18" height="18" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
							</div>
							<div class="mira-emergency__commitment-text">
								<strong><?php esc_html_e( 'Personale Proprio & Mezzi Attrezzati', 'miraservices' ); ?></strong>
								<p><?php esc_html_e( 'Operatori fidelizzati e assicurati, equipaggiati con strumentazione tecnica completa.', 'miraservices' ); ?></p>
							</div>
						</div>
					</div>

					<?php if ( $mira_phone ) : ?>
						<div class="mira-emergency__dispatch-card">
							<div class="mira-emergency__dispatch-info">
								<span class="mira-emergency__dispatch-kicker"><?php esc_html_e( 'Linea Diretta Emergenze', 'miraservices' ); ?></span>
								<a class="mira-emergency__phone-anchor" href="tel:<?php echo esc_attr( $mira_phone_clean ); ?>" aria-label="<?php echo esc_attr( sprintf( __( 'Chiama il picchetto al numero %s', 'miraservices' ), $mira_phone_disp ) ); ?>">
									<span class="mira-emergency__phone-symbol" aria-hidden="true">
										<svg viewBox="0 0 24 24" width="18" height="18" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/></svg>
									</span>
									<strong class="mira-emergency__phone-num"><?php echo esc_html( $mira_phone_disp ); ?></strong>
								</a>
							</div>
							<a class="mira-button mira-button--primary mira-emergency__call-btn" href="tel:<?php echo esc_attr( $mira_phone_clean ); ?>">
								<span><?php esc_html_e( 'Chiama adesso 24H', 'miraservices' ); ?></span>
								<i aria-hidden="true">↗</i>
							</a>
						</div>
					<?php endif; ?>

				</div>

			</div>
		</div>
	</section>

	<?php if ( $mira_phone ) : ?>
		<a class="mira-emergency-dock" href="tel:<?php echo esc_attr( $mira_phone_clean ); ?>" data-mira-emergency-dock aria-label="<?php esc_attr_e( 'Chiama il Picchetto 24 ore', 'miraservices' ); ?>">
			<span class="mira-emergency-dock__dot" aria-hidden="true"></span>
			<span><?php esc_html_e( 'Picchetto', 'miraservices' ); ?></span><strong>24H</strong>
		</a>
	<?php endif; ?>

	<?php /* ============================================================
	   07 — METODO (Orizzontale Compatto a 4 Step)
	   ============================================================ */ ?>
	<?php if ( ! empty( $mira_method['steps'] ) ) : ?>
		<?php
		$mira_method_details = array(
			0 => array(
				'kicker' => __( 'Fase 01', 'miraservices' ),
				'bullet' => __( 'Sopralluogo rapido ad Ascona e nel Locarnese', 'miraservices' ),
				'svg'    => '<svg viewBox="0 0 24 24" width="20" height="20" stroke="currentColor" stroke-width="1.8" fill="none" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>',
			),
			1 => array(
				'kicker' => __( 'Fase 02', 'miraservices' ),
				'bullet' => __( 'Preventivo trasparente e stima tempi precisa', 'miraservices' ),
				'svg'    => '<svg viewBox="0 0 24 24" width="20" height="20" stroke="currentColor" stroke-width="1.8" fill="none" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"/><rect x="8" y="2" width="8" height="4" rx="1" ry="1"/><path d="m9 14 2 2 4-4"/></svg>',
			),
			2 => array(
				'kicker' => __( 'Fase 03', 'miraservices' ),
				'bullet' => __( 'Esecuzione coordinata da un unico referente', 'miraservices' ),
				'svg'    => '<svg viewBox="0 0 24 24" width="20" height="20" stroke="currentColor" stroke-width="1.8" fill="none" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"/></svg>',
			),
			3 => array(
				'kicker' => __( 'Fase 04', 'miraservices' ),
				'bullet' => __( 'Report d’intervento e piani di cura programmabili', 'miraservices' ),
				'svg'    => '<svg viewBox="0 0 24 24" width="20" height="20" stroke="currentColor" stroke-width="1.8" fill="none" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><path d="m9 12 2 2 4-4"/></svg>',
			),
		);
		?>
		<section class="mira-method mira-section" id="metodo" data-mira-method>
			<div class="mira-shell">
				<header class="mira-method__header mira-reveal">
					<div class="mira-method__header-top">
						<div>
							<p class="mira-kicker"><?php esc_html_e( 'Procedura chiara', 'miraservices' ); ?></p>
							<h2><?php echo esc_html( ! empty( $mira_method['title'] ) ? $mira_method['title'] : __( 'Un modo semplice di lavorare insieme.', 'miraservices' ) ); ?></h2>
						</div>
						<p class="mira-method__header-lead">
							<?php esc_html_e( 'Dalla prima richiesta alla verifica finale: 4 passaggi lineari per garantirti trasparenza, puntualità e zero imprevisti.', 'miraservices' ); ?>
						</p>
					</div>

					<div class="mira-method__progress-bar" aria-hidden="true">
						<div class="mira-method__progress-rail">
							<span class="mira-method__progress-fill" data-mira-method-progress></span>
						</div>
					</div>
				</header>

				<div class="mira-method__steps-grid">
					<?php foreach ( $mira_method['steps'] as $mira_index => $mira_step ) : ?>
						<?php
						$mira_step_title = preg_replace( '/^\s*\d+\s*[—–-]\s*/u', '', $mira_step['title'] );
						$mira_detail     = isset( $mira_method_details[ $mira_index ] ) ? $mira_method_details[ $mira_index ] : null;
						$mira_is_last    = ( $mira_index === count( $mira_method['steps'] ) - 1 );
						?>
						<article class="mira-method__card mira-reveal">
							<div class="mira-method__card-head">
								<span class="mira-method__card-badge"><?php echo esc_html( str_pad( (string) ( $mira_index + 1 ), 2, '0', STR_PAD_LEFT ) ); ?></span>
								<div class="mira-method__card-actions">
									<?php if ( $mira_detail && ! empty( $mira_detail['svg'] ) ) : ?>
										<span class="mira-method__card-icon" aria-hidden="true">
											<?php echo $mira_detail['svg']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
										</span>
									<?php endif; ?>
									<?php if ( ! $mira_is_last ) : ?>
										<span class="mira-method__card-arrow" aria-hidden="true">→</span>
									<?php endif; ?>
								</div>
							</div>

							<div class="mira-method__card-body">
								<span class="mira-method__card-kicker"><?php echo esc_html( $mira_detail ? $mira_detail['kicker'] : sprintf( __( 'Fase %02d', 'miraservices' ), $mira_index + 1 ) ); ?></span>
								<h3 class="mira-method__card-title"><?php echo esc_html( $mira_step_title ); ?></h3>
								<p class="mira-method__card-text"><?php echo esc_html( $mira_step['text'] ); ?></p>
							</div>

							<?php if ( $mira_detail && ! empty( $mira_detail['bullet'] ) ) : ?>
								<div class="mira-method__card-foot">
									<span class="mira-method__card-check" aria-hidden="true">✓</span>
									<span><?php echo esc_html( $mira_detail['bullet'] ); ?></span>
								</div>
							<?php endif; ?>
						</article>
					<?php endforeach; ?>
				</div>
			</div>
		</section>
	<?php endif; ?>


	<?php /* ============================================================
	   09 — PARTNER E RECENSIONI (Condizionale)
	   ============================================================ */ ?>
	<?php if ( ! empty( $mira_partners ) || ! empty( $mira_reviews ) ) : ?>
		<section class="mira-trust mira-section" aria-label="<?php esc_attr_e( 'Partner e recensioni', 'miraservices' ); ?>">
			<div class="mira-shell">
				<?php if ( $mira_partners ) : ?>
					<div class="mira-trust__partners">
						<button class="mira-trust__toggle" type="button" data-mira-partner-toggle aria-pressed="false"><?php esc_html_e( 'Pausa movimento', 'miraservices' ); ?></button>
						<div class="mira-trust__track">
							<div class="mira-trust__partner-set">
								<?php foreach ( $mira_partners as $mira_partner ) : ?>
									<?php if ( $mira_partner['url'] ) : ?><a href="<?php echo esc_url( $mira_partner['url'] ); ?>" target="_blank" rel="noopener noreferrer"><?php endif; ?>
									<?php echo miraservices_image( $mira_partner['logo'], array( 'alt' => '', 'sizes' => '180px' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
									<?php if ( $mira_partner['url'] ) : ?></a><?php endif; ?>
								<?php endforeach; ?>
							</div>
							<div class="mira-trust__partner-set" aria-hidden="true">
								<?php foreach ( $mira_partners as $mira_partner ) : ?><?php echo miraservices_image( $mira_partner['logo'], array( 'alt' => '', 'sizes' => '180px' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?><?php endforeach; ?>
							</div>
						</div>
					</div>
				<?php endif; ?>
				<?php if ( $mira_reviews ) : ?>
					<div class="mira-trust__reviews">
						<?php foreach ( $mira_reviews as $mira_review ) : ?>
							<blockquote><p><?php echo esc_html( isset( $mira_review['text'] ) ? $mira_review['text'] : '' ); ?></p><?php if ( ! empty( $mira_review['author_name'] ) ) : ?><cite><?php echo esc_html( $mira_review['author_name'] ); ?></cite><?php endif; ?></blockquote>
						<?php endforeach; ?>
					</div>
				<?php endif; ?>
			</div>
		</section>
	<?php endif; ?>

	<?php /* ============================================================
	   10 — CONTATTI & FORM AJAX
	   ============================================================ */ ?>
	<section class="mira-contact mira-section" id="contatti">
		<div class="mira-shell">
			<div class="mira-contact__layout">
				<div class="mira-contact__info mira-reveal">
					<p class="mira-kicker"><?php esc_html_e( 'Contatti diretti', 'miraservices' ); ?></p>
					<h2><?php echo esc_html( ! empty( $mira_contact_s['title'] ) ? $mira_contact_s['title'] : __( 'C’è qualcosa da sistemare? Parliamone.', 'miraservices' ) ); ?></h2>
					<p class="mira-contact__lead">
						<?php echo esc_html( ! empty( $mira_contact_s['text'] ) ? $mira_contact_s['text'] : __( 'Raccontaci cosa richiede il tuo immobile. Eseguiamo sopralluoghi gratuiti e senza impegno ad Ascona, Locarno e in tutto il Cantone Ticino.', 'miraservices' ) ); ?>
					</p>

					<div class="mira-contact__cards">
						<?php if ( $mira_phone ) : ?>
							<div class="mira-contact__card">
								<span><?php esc_html_e( 'Telefono & WhatsApp', 'miraservices' ); ?></span>
								<a class="mira-contact__highlight" href="tel:<?php echo esc_attr( $mira_phone_clean ); ?>"><?php echo esc_html( $mira_phone_disp ); ?></a>
								<small><a href="https://wa.me/<?php echo esc_attr( ltrim( $mira_phone_clean, '+' ) ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Invia messaggio WhatsApp ↗', 'miraservices' ); ?></a></small>
							</div>
						<?php endif; ?>
						<?php if ( ! empty( $mira_contact['email'] ) ) : ?>
							<div class="mira-contact__card">
								<span>Email</span>
								<a href="mailto:<?php echo esc_attr( $mira_contact['email'] ); ?>"><?php echo esc_html( $mira_contact['email'] ); ?></a>
							</div>
						<?php endif; ?>
						<?php if ( ! empty( $mira_contact['address'] ) ) : ?>
							<div class="mira-contact__card">
								<span><?php esc_html_e( 'Sede Operativa', 'miraservices' ); ?></span>
								<p><?php echo esc_html( $mira_contact['address'] ); ?></p>
							</div>
						<?php endif; ?>
						<div class="mira-contact__card">
							<span><?php esc_html_e( 'Orari Ufficio', 'miraservices' ); ?></span>
							<p><?php echo esc_html( ! empty( $mira_contact['opening_hours_note'] ) ? $mira_contact['opening_hours_note'] : __( 'Lunedì – Venerdì: 07:30 – 17:00 (Picchetto attivo 24/7)', 'miraservices' ) ); ?></p>
						</div>
					</div>
				</div>

				<div class="mira-contact__form-wrapper mira-reveal">
					<form class="mira-contact-form" id="mira-contact-form" data-mira-contact-form novalidate>
						<div class="mira-field">
							<label for="mira-nome"><?php esc_html_e( 'Nome e cognome', 'miraservices' ); ?> *</label>
							<input id="mira-nome" name="nome" type="text" autocomplete="name" placeholder="<?php esc_attr_e( 'Mario Rossi', 'miraservices' ); ?>" required minlength="2" aria-describedby="mira-nome-error">
							<small id="mira-nome-error" data-error-for="nome"></small>
						</div>
						<div class="mira-field">
							<label for="mira-email">Email *</label>
							<input id="mira-email" name="email" type="email" autocomplete="email" placeholder="mario.rossi@email.ch" required aria-describedby="mira-email-error">
							<small id="mira-email-error" data-error-for="email"></small>
						</div>
						<div class="mira-field">
							<label for="mira-telefono"><?php esc_html_e( 'Telefono', 'miraservices' ); ?></label>
							<input id="mira-telefono" name="telefono" type="tel" autocomplete="tel" placeholder="+41 79 000 00 00" aria-describedby="mira-telefono-error">
							<small id="mira-telefono-error" data-error-for="telefono"></small>
						</div>
						<div class="mira-field">
							<label for="mira-oggetto"><?php esc_html_e( 'Di cosa ha bisogno l’immobile?', 'miraservices' ); ?></label>
							<input id="mira-oggetto" name="oggetto" type="text" placeholder="<?php esc_attr_e( 'Es. Cura del verde, Manutenzione ordinaria, Picchetto...', 'miraservices' ); ?>" aria-describedby="mira-oggetto-error">
							<small id="mira-oggetto-error" data-error-for="oggetto"></small>
						</div>
						<div class="mira-field mira-field--full">
							<label for="mira-messaggio"><?php esc_html_e( 'Descrivi la richiesta', 'miraservices' ); ?> *</label>
							<textarea id="mira-messaggio" name="messaggio" rows="4" placeholder="<?php esc_attr_e( 'Indicaci la tipologia dell’immobile (villa, appartamento, condominio) e gli interventi desiderati...', 'miraservices' ); ?>" required minlength="5" maxlength="5000" aria-describedby="mira-messaggio-error"></textarea>
							<small id="mira-messaggio-error" data-error-for="messaggio"></small>
						</div>

						<div class="mira-honeypot" aria-hidden="true">
							<label for="mira-company">Company</label>
							<input id="mira-company" name="tw_hp" type="text" tabindex="-1" autocomplete="off">
						</div>

						<div class="mira-contact-form__footer">
							<p><?php esc_html_e( 'I tuoi dati verranno trattati con riservatezza esclusivamente per rispondere alla richiesta.', 'miraservices' ); ?></p>
							<button class="mira-button mira-button--primary" type="submit">
								<span data-submit-label><?php esc_html_e( 'Invia la richiesta', 'miraservices' ); ?></span><i aria-hidden="true">↗</i>
							</button>
						</div>

						<div class="mira-form-status" role="status" aria-live="polite" data-mira-form-status></div>
					</form>
				</div>
			</div>
		</div>
	</section>

</main>
<?php
get_footer();
