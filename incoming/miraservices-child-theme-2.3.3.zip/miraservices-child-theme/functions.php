<?php
/**
 * Mira Services SA child theme bootstrap.
 *
 * @package MiraServicesChildTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once get_stylesheet_directory() . '/inc/frontend-data.php';

/**
 * Return a Google Fonts URL matching the CMS typography choices.
 *
 * @return string
 */
function miraservices_fonts_url() {
	$headings = preg_replace( '/[^A-Za-z0-9 ]/', '', (string) get_option( 'ticinoweb_font_headings', 'Poppins' ) );
	$body     = preg_replace( '/[^A-Za-z0-9 ]/', '', (string) get_option( 'ticinoweb_font_body', 'Lato' ) );
	$families = array_unique( array_filter( array( $headings, $body ) ) );
	$query    = array();
	foreach ( $families as $family ) {
		$query[] = 'family=' . str_replace( '%20', '+', rawurlencode( $family ) ) . ':wght@300;400;500;600;700';
	}
	return 'https://fonts.googleapis.com/css2?' . implode( '&', $query ) . '&display=swap';
}

/**
 * Publish sanitized CMS Look & Feel settings as frontend design tokens.
 *
 * @return string
 */
function miraservices_frontend_tokens() {
	$colors = array(
		'primary' => sanitize_hex_color( get_option( 'ticinoweb_palette_primary', '#0100d6' ) ) ?: '#0100d6',
		'accent'  => sanitize_hex_color( get_option( 'ticinoweb_palette_suggested_1', '#00e83f' ) ) ?: '#00e83f',
		'ink'     => sanitize_hex_color( get_option( 'ticinoweb_palette_suggested_2', '#111827' ) ) ?: '#111827',
		'paper'   => sanitize_hex_color( get_option( 'ticinoweb_palette_suggested_3', '#f4f7f5' ) ) ?: '#f4f7f5',
	);
	$heading_font = preg_replace( '/[^A-Za-z0-9 ,\-]/', '', (string) get_option( 'ticinoweb_font_headings', 'Poppins' ) );
	$body_font    = preg_replace( '/[^A-Za-z0-9 ,\-]/', '', (string) get_option( 'ticinoweb_font_body', 'Lato' ) );

	return sprintf(
		':root{--mira-primary:%1$s;--mira-accent:%2$s;--mira-ink:%3$s;--mira-paper:%4$s;--mira-heading:"%5$s",sans-serif;--mira-body:"%6$s",sans-serif;}',
		$colors['primary'],
		$colors['accent'],
		$colors['ink'],
		$colors['paper'],
		$heading_font,
		$body_font
	);
}

/**
 * Load the parent and child theme stylesheets in the correct order.
 *
 * The parent currently registers the active stylesheet with its own handle.
 * Replace that registration so both the real parent stylesheet and this
 * child stylesheet are loaded exactly once.
 *
 * @return void
 */
function miraservices_child_enqueue_styles() {
	$parent_theme = wp_get_theme( get_template() );
	$child_theme  = wp_get_theme();

	wp_dequeue_style( 'ticinoweb-ai-style' );
	wp_deregister_style( 'ticinoweb-ai-style' );

	wp_enqueue_style(
		'ticinoweb-ai-parent-style',
		get_template_directory_uri() . '/style.css',
		array( 'poppins-font' ),
		$parent_theme->get( 'Version' )
	);

	wp_enqueue_style(
		'miraservices-child-style',
		get_stylesheet_uri(),
		array( 'ticinoweb-ai-parent-style' ),
		$child_theme->get( 'Version' )
	);

	wp_enqueue_style(
		'miraservices-fonts',
		miraservices_fonts_url(),
		array(),
		null
	);

	wp_enqueue_style(
		'miraservices-site',
		get_stylesheet_directory_uri() . '/assets/css/site.css',
		array( 'miraservices-child-style', 'miraservices-fonts' ),
		$child_theme->get( 'Version' )
	);
	wp_add_inline_style( 'miraservices-site', miraservices_frontend_tokens() );

	wp_dequeue_script( 'ticinoweb-ai-main' );
	wp_deregister_script( 'ticinoweb-ai-main' );

	wp_enqueue_script(
		'miraservices-navigation',
		get_stylesheet_directory_uri() . '/assets/js/navigation.js',
		array(),
		$child_theme->get( 'Version' ),
		array( 'strategy' => 'defer', 'in_footer' => true )
	);

	if ( is_front_page() ) {
		wp_enqueue_style(
			'miraservices-home',
			get_stylesheet_directory_uri() . '/assets/css/home.css',
			array( 'miraservices-site' ),
			$child_theme->get( 'Version' )
		);
		wp_enqueue_script(
			'miraservices-home-motion',
			get_stylesheet_directory_uri() . '/assets/js/home.js',
			array(),
			$child_theme->get( 'Version' ),
			array( 'strategy' => 'defer', 'in_footer' => true )
		);
		wp_enqueue_script(
			'miraservices-contact',
			get_stylesheet_directory_uri() . '/assets/js/contact.js',
			array(),
			$child_theme->get( 'Version' ),
			array( 'strategy' => 'defer', 'in_footer' => true )
		);
		wp_localize_script(
			'miraservices-contact',
			'miraFrontend',
			array(
				'ajaxUrl'     => admin_url( 'admin-ajax.php' ),
				'tokenAction' => 'ticinoweb_form_token',
				'submitAction' => 'ticinoweb_submit_form',
				'homeUrl'     => home_url( '/' ),
			)
		);
	}

	if ( function_exists( 'is_page' ) && is_page() && miraservices_is_service_page() ) {
		wp_enqueue_style(
			'miraservices-services',
			get_stylesheet_directory_uri() . '/assets/css/services.css',
			array( 'miraservices-site' ),
			$child_theme->get( 'Version' )
		);
	}
}
add_action( 'wp_enqueue_scripts', 'miraservices_child_enqueue_styles', 20 );

/**
 * Link each native CMS service card to its published WordPress detail page.
 *
 * The parent CMS stores service cards without a URL field, but exposes a
 * semantic URL filter for every card. The content importer maintains the
 * service-to-page mapping in one child-owned option.
 *
 * @param string $url     Parent fallback URL.
 * @param string $context Semantic URL context supplied by the parent.
 * @return string
 */
function miraservices_service_link_url( $url, $context ) {
	if ( ! is_string( $context ) || ! preg_match( '/^theme:service:([a-z0-9-]+):link_url$/', $context, $matches ) ) {
		return $url;
	}

	$mapping = get_option( 'miraservices_service_page_mapping', array() );
	$page_id = isset( $mapping[ $matches[1] ] ) ? (int) $mapping[ $matches[1] ] : 0;

	if ( $page_id > 0 && 'publish' === get_post_status( $page_id ) ) {
		$permalink = get_permalink( $page_id );
		if ( is_string( $permalink ) && '' !== $permalink ) {
			return $permalink;
		}
	}

	return $url;
}
add_filter( 'ticinoweb_frontend_url', 'miraservices_service_link_url', 20, 2 );
