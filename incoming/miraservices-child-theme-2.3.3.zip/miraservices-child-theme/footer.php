<?php
/**
 * Global site footer.
 *
 * @package MiraServicesChildTheme
 */

$mira_contact = function_exists( 'ticinoweb_get_contact_info' ) ? ticinoweb_get_contact_info() : array();
$mira_logo    = function_exists( 'ticinoweb_get_site_logo' ) ? ticinoweb_get_site_logo() : '';
$mira_menu    = miraservices_get_primary_menu_tree();
$mira_privacy = function_exists( 'get_privacy_policy_url' ) ? get_privacy_policy_url() : '';
$mira_tagline = get_bloginfo( 'description' );
?>
<footer class="mira-footer">
	<div class="mira-footer__top">
		<a class="mira-footer__brand" href="<?php echo esc_url( home_url( '/' ) ); ?>">
			<?php if ( $mira_logo ) : ?><img src="<?php echo esc_url( $mira_logo ); ?>" alt="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>" width="220" height="76"><?php else : ?><span><?php bloginfo( 'name' ); ?></span><?php endif; ?>
		</a>
		<?php if ( $mira_tagline ) : ?><p><?php echo esc_html( $mira_tagline ); ?></p><?php endif; ?>
		<a class="mira-arrow-link" href="<?php echo esc_url( home_url( '/#home' ) ); ?>"><?php esc_html_e( 'Torna all’inizio', 'miraservices' ); ?> <span aria-hidden="true">↑</span></a>
	</div>
	<div class="mira-footer__meta">
		<div>
			<?php if ( ! empty( $mira_contact['address'] ) ) : ?><span><?php echo esc_html( $mira_contact['address'] ); ?></span><?php endif; ?>
			<?php if ( ! empty( $mira_contact['phone'] ) ) : ?><a href="tel:<?php echo esc_attr( miraservices_phone_uri( $mira_contact['phone'] ) ); ?>"><?php echo esc_html( miraservices_format_phone( $mira_contact['phone'] ) ); ?></a><?php endif; ?>
			<?php if ( ! empty( $mira_contact['email'] ) ) : ?><a href="mailto:<?php echo esc_attr( $mira_contact['email'] ); ?>"><?php echo esc_html( $mira_contact['email'] ); ?></a><?php endif; ?>
		</div>
		<div class="mira-footer__socials">
			<?php foreach ( array( 'instagram' => 'Instagram', 'facebook' => 'Facebook', 'linkedin' => 'LinkedIn' ) as $mira_network => $mira_label ) : ?>
				<?php if ( ! empty( $mira_contact[ $mira_network ] ) ) : ?><a href="<?php echo esc_url( $mira_contact[ $mira_network ] ); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html( $mira_label ); ?></a><?php endif; ?>
			<?php endforeach; ?>
		</div>
		<nav class="mira-footer__links" aria-label="<?php esc_attr_e( 'Link nel footer', 'miraservices' ); ?>">
			<?php foreach ( $mira_menu as $mira_item ) : ?><a href="<?php echo esc_url( $mira_item['url'] ); ?>"><?php echo esc_html( $mira_item['title'] ); ?></a><?php endforeach; ?>
			<?php if ( $mira_privacy ) : ?><a href="<?php echo esc_url( $mira_privacy ); ?>"><?php esc_html_e( 'Privacy & Cookie', 'miraservices' ); ?></a><?php endif; ?>
		</nav>
		<p>© <?php echo esc_html( gmdate( 'Y' ) ); ?> <?php bloginfo( 'name' ); ?></p>
	</div>
	<div class="mira-footer__wordmark" aria-hidden="true">MIRA</div>
</footer>
<?php wp_footer(); ?>
</body>
</html>
