<?php
/**
 * Global site header.
 *
 * @package MiraServicesChildTheme
 */

$mira_menu_tree = miraservices_get_primary_menu_tree();
$mira_logo       = function_exists( 'ticinoweb_get_site_logo' ) ? ticinoweb_get_site_logo() : '';
$mira_home_link  = home_url( '/' );
?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="mira-skip-link" href="#mira-main"><?php esc_html_e( 'Vai al contenuto', 'miraservices' ); ?></a>
<header class="mira-header" data-mira-header>
	<div class="mira-header__inner">
		<a class="mira-brand" href="<?php echo esc_url( $mira_home_link ); ?>" aria-label="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?> — <?php esc_attr_e( 'Home', 'miraservices' ); ?>">
			<?php if ( $mira_logo ) : ?>
				<img src="<?php echo esc_url( $mira_logo ); ?>" alt="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>" width="208" height="72">
			<?php else : ?>
				<span><?php bloginfo( 'name' ); ?></span>
			<?php endif; ?>
		</a>

		<nav class="mira-nav" aria-label="<?php esc_attr_e( 'Navigazione principale', 'miraservices' ); ?>">
			<?php foreach ( $mira_menu_tree as $mira_item ) : ?>
				<?php $mira_has_children = ! empty( $mira_item['children'] ); ?>
				<?php if ( $mira_has_children ) : ?>
					<button class="mira-nav__link mira-nav__service-trigger" type="button" aria-expanded="false" aria-controls="mira-mega-menu" data-mira-mega-trigger data-mira-nav-target="servizi">
						<?php echo esc_html( $mira_item['title'] ); ?>
						<span aria-hidden="true">+</span>
					</button>
				<?php else : ?>
					<a class="mira-nav__link" href="<?php echo esc_url( $mira_item['url'] ); ?>"<?php echo $mira_item['target'] ? ' target="' . esc_attr( $mira_item['target'] ) . '" rel="noopener noreferrer"' : ''; ?>><?php echo esc_html( $mira_item['title'] ); ?></a>
				<?php endif; ?>
			<?php endforeach; ?>
		</nav>

		<a class="mira-header__cta" href="<?php echo esc_url( home_url( '/#contatti' ) ); ?>">
			<span><?php esc_html_e( 'Richiedi un preventivo', 'miraservices' ); ?></span><span aria-hidden="true">↗</span>
		</a>
		<button class="mira-menu-toggle" type="button" aria-expanded="false" aria-controls="mira-mobile-menu" data-mira-menu-toggle>
			<span class="mira-menu-toggle__label"><?php esc_html_e( 'Menu', 'miraservices' ); ?></span>
			<span class="mira-menu-toggle__icon" aria-hidden="true"><i></i><i></i></span>
		</button>
	</div>
	<?php
	// Editorial services mega menu inline.
	$mira_services = miraservices_get_frontend_services();
	$mira_sections = miraservices_get_home_sections();
	if ( ! empty( $mira_services ) ) :
	?>
		<div class="mira-mega" id="mira-mega-menu" data-mira-mega hidden>
			<div class="mira-mega__inner">
				<div class="mira-mega__heading">
					<p class="mira-kicker"><?php esc_html_e( 'Servizi per gli immobili', 'miraservices' ); ?></p>
					<?php if ( ! empty( $mira_sections['services']['text'] ) ) : ?><p><?php echo esc_html( $mira_sections['services']['text'] ); ?></p><?php endif; ?>
				</div>
				<ol class="mira-mega__list">
					<?php foreach ( $mira_services as $mira_index => $mira_service ) : ?>
						<li<?php echo $mira_service['is_emergency'] ? ' class="is-emergency"' : ''; ?>>
							<a href="<?php echo esc_url( $mira_service['url'] ); ?>" data-mira-mega-item="<?php echo esc_attr( $mira_index ); ?>"<?php echo 0 === $mira_index ? ' aria-current="true"' : ''; ?>>
								<span><?php echo esc_html( str_pad( (string) $mira_service['index'], 2, '0', STR_PAD_LEFT ) ); ?></span>
								<strong><?php echo esc_html( $mira_service['title'] ); ?></strong>
								<i aria-hidden="true">↗</i>
							</a>
						</li>
					<?php endforeach; ?>
				</ol>
				<div class="mira-mega__visual" data-mira-mega-visual>
					<?php foreach ( $mira_services as $mira_index => $mira_service ) : ?>
						<figure class="<?php echo 0 === $mira_index ? 'is-active' : ''; ?>" data-mira-mega-panel="<?php echo esc_attr( $mira_index ); ?>" aria-hidden="<?php echo 0 === $mira_index ? 'false' : 'true'; ?>">
							<?php echo miraservices_image( $mira_service['image'], array( 'class' => 'mira-mega__image', 'alt' => $mira_service['title'], 'sizes' => '(min-width: 1100px) 30vw, 1px' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
							<figcaption>
								<span class="mira-mega__desc"><?php echo esc_html( $mira_service['description'] ); ?></span>
								<a class="mira-mega__cta" href="<?php echo esc_url( $mira_service['url'] ); ?>"<?php echo 0 === $mira_index ? '' : ' tabindex="-1"'; ?>>
									<span><?php echo esc_html( sprintf( __( 'Scopri %s', 'miraservices' ), $mira_service['title'] ) ); ?></span>
									<i aria-hidden="true">↗</i>
								</a>
							</figcaption>
						</figure>
					<?php endforeach; ?>
				</div>
			</div>
		</div>
	<?php endif; ?>
</header>
<?php
// Mobile navigation drawer inline.
$mira_contact = function_exists( 'ticinoweb_get_contact_info' ) ? ticinoweb_get_contact_info() : array();
?>
<aside class="mira-mobile-menu" id="mira-mobile-menu" aria-hidden="true" data-mira-mobile-menu>
	<div class="mira-mobile-menu__scroll">
		<nav aria-label="<?php esc_attr_e( 'Navigazione mobile', 'miraservices' ); ?>">
			<ul class="mira-mobile-menu__primary">
				<?php foreach ( $mira_menu_tree as $mira_item ) : ?>
					<li>
						<?php if ( ! empty( $mira_item['children'] ) ) : ?>
							<button type="button" aria-expanded="false" aria-controls="mira-mobile-services" data-mira-mobile-services-toggle>
								<span><?php echo esc_html( $mira_item['title'] ); ?></span><i aria-hidden="true">+</i>
							</button>
							<ol id="mira-mobile-services" hidden>
								<?php foreach ( $mira_item['children'] as $mira_child ) : ?>
									<li><a href="<?php echo esc_url( $mira_child['url'] ); ?>"><?php echo esc_html( $mira_child['title'] ); ?><span aria-hidden="true">↗</span></a></li>
								<?php endforeach; ?>
							</ol>
						<?php else : ?>
							<a href="<?php echo esc_url( $mira_item['url'] ); ?>"><?php echo esc_html( $mira_item['title'] ); ?><span aria-hidden="true">↗</span></a>
						<?php endif; ?>
					</li>
				<?php endforeach; ?>
			</ul>
		</nav>
		<a class="mira-mobile-menu__cta" href="<?php echo esc_url( home_url( '/#contatti' ) ); ?>"><?php esc_html_e( 'Richiedi un preventivo', 'miraservices' ); ?><span aria-hidden="true">↗</span></a>
		<div class="mira-mobile-menu__contact">
			<?php if ( ! empty( $mira_contact['phone'] ) ) : ?>
				<a href="tel:<?php echo esc_attr( miraservices_phone_uri( $mira_contact['phone'] ) ); ?>"><?php echo esc_html( miraservices_format_phone( $mira_contact['phone'] ) ); ?></a>
			<?php endif; ?>
			<?php if ( ! empty( $mira_contact['email'] ) ) : ?>
				<a href="mailto:<?php echo esc_attr( $mira_contact['email'] ); ?>"><?php echo esc_html( $mira_contact['email'] ); ?></a>
			<?php endif; ?>
		</div>
	</div>
</aside>
<div class="mira-page-progress" aria-hidden="true"><span></span></div>

