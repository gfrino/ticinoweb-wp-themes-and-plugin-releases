<?php
/**
 * Default page template with child-owned header offset and skip-link target.
 *
 * @package MiraServicesChildTheme
 */

get_header();
?>
<main id="mira-main" class="mira-page-main">
	<?php while ( have_posts() ) : ?>
		<?php the_post(); ?>
		<?php $mira_service_page = miraservices_get_service_page_data( get_the_ID() ); ?>
		<?php if ( ! empty( $mira_service_page ) ) : ?>
			<?php get_template_part( 'template-parts/content', 'service', array( 'service' => $mira_service_page ) ); ?>
		<?php else : ?>
			<article <?php post_class( 'mira-page-article' ); ?>>
				<header class="mira-page-article__header">
					<p class="mira-kicker"><?php echo esc_html( get_bloginfo( 'name' ) ); ?></p>
					<h1><?php the_title(); ?></h1>
				</header>
				<?php if ( has_post_thumbnail() ) : ?>
					<figure class="mira-page-article__visual"><?php the_post_thumbnail( 'full', array( 'sizes' => '(min-width: 1000px) 84vw, 100vw' ) ); ?></figure>
				<?php endif; ?>
				<div class="entry-content"><?php the_content(); ?></div>
			</article>
		<?php endif; ?>
	<?php endwhile; ?>
</main>
<?php
get_footer();
