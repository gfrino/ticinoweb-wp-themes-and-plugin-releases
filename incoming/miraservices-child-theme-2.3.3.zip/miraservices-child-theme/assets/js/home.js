(() => {
	'use strict';

	const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
	const hero = document.querySelector('[data-mira-hero]');
	const scenes = hero ? [...hero.querySelectorAll('[data-mira-hero-scene]')] : [];
	const counter = hero?.querySelector('[data-mira-hero-current]');
	const pauseBtn = hero?.querySelector('[data-mira-hero-pause]');
	const pauseIcon = pauseBtn?.querySelector('.mira-hero__pause-icon');
	let heroIndex = 0;
	let heroTimer = null;
	let isHeroPaused = false;

	const setScene = (index) => {
		heroIndex = index;
		scenes.forEach((scene, sceneIndex) => {
			const active = sceneIndex === heroIndex;
			scene.classList.toggle('is-active', active);
			scene.setAttribute('aria-hidden', String(!active));
		});
		if (counter) counter.textContent = String(heroIndex + 1).padStart(2, '0');
	};
	const stopHero = () => { window.clearInterval(heroTimer); heroTimer = null; };
	const startHero = () => {
		stopHero();
		if (isHeroPaused || scenes.length < 2 || reducedMotion.matches || document.hidden) return;
		heroTimer = window.setInterval(() => setScene((heroIndex + 1) % scenes.length), 7000);
	};

	if (pauseBtn) {
		pauseBtn.addEventListener('click', () => {
			isHeroPaused = !isHeroPaused;
			pauseBtn.setAttribute('aria-pressed', String(isHeroPaused));
			if (pauseIcon) pauseIcon.textContent = isHeroPaused ? '▶' : '⏸';
			if (isHeroPaused) {
				stopHero();
			} else {
				startHero();
			}
		});
	}

	document.addEventListener('visibilitychange', startHero);
	reducedMotion.addEventListener?.('change', startHero);
	startHero();

	// Hero Interactive Cursor & Spotlight
	const heroCursor = hero?.querySelector('[data-mira-hero-cursor]');
	const heroCursorLabel = heroCursor?.querySelector('.mira-hero__cursor-label');
	const isFinePointer = window.matchMedia('(hover: hover) and (pointer: fine)').matches;

	if (hero && isFinePointer && !reducedMotion.matches) {
		let mouseX = -100;
		let mouseY = -100;
		let cursorX = -100;
		let cursorY = -100;
		let isTracking = false;
		let animFrameId = null;

		const updateCursorPos = () => {
			if (!isTracking) return;
			cursorX += (mouseX - cursorX) * 0.18;
			cursorY += (mouseY - cursorY) * 0.18;

			if (heroCursor) {
				heroCursor.style.transform = `translate3d(${cursorX}px, ${cursorY}px, 0)`;
			}
			animFrameId = requestAnimationFrame(updateCursorPos);
		};

		hero.addEventListener('pointerenter', (e) => {
			isTracking = true;
			const rect = hero.getBoundingClientRect();
			mouseX = e.clientX - rect.left;
			mouseY = e.clientY - rect.top;
			cursorX = mouseX;
			cursorY = mouseY;
			hero.classList.add('is-mouse-inside');
			if (animFrameId) cancelAnimationFrame(animFrameId);
			animFrameId = requestAnimationFrame(updateCursorPos);
		});

		hero.addEventListener('pointerleave', () => {
			isTracking = false;
			hero.classList.remove('is-mouse-inside', 'is-hovering-interactive');
			hero.style.removeProperty('--hero-tilt-x');
			hero.style.removeProperty('--hero-tilt-y');
			if (animFrameId) {
				cancelAnimationFrame(animFrameId);
				animFrameId = null;
			}
		});

		hero.addEventListener('pointermove', (e) => {
			const rect = hero.getBoundingClientRect();
			mouseX = e.clientX - rect.left;
			mouseY = e.clientY - rect.top;

			hero.style.setProperty('--hero-mouse-x', `${mouseX}px`);
			hero.style.setProperty('--hero-mouse-y', `${mouseY}px`);

			const tiltX = ((mouseX / rect.width) - 0.5) * -1;
			const tiltY = ((mouseY / rect.height) - 0.5) * -1;
			hero.style.setProperty('--hero-tilt-x', tiltX.toFixed(3));
			hero.style.setProperty('--hero-tilt-y', tiltY.toFixed(3));

			const interactive = e.target.closest('a, button, [role="button"]');
			if (interactive) {
				hero.classList.add('is-hovering-interactive');
				const actionText = interactive.getAttribute('aria-label') || interactive.textContent || '';
				if (/servizi/i.test(actionText)) {
					if (heroCursorLabel) heroCursorLabel.textContent = 'SCOPRI';
				} else if (/preventivo|contatt/i.test(actionText)) {
					if (heroCursorLabel) heroCursorLabel.textContent = 'CONTATTA';
				} else if (/picchetto|chiama/i.test(actionText)) {
					if (heroCursorLabel) heroCursorLabel.textContent = '24/7 CALL';
				} else if (/pausa|scene/i.test(actionText)) {
					if (heroCursorLabel) heroCursorLabel.textContent = 'PAUSA';
				} else {
					if (heroCursorLabel) heroCursorLabel.textContent = 'APRI';
				}
			} else {
				hero.classList.remove('is-hovering-interactive');
				if (heroCursorLabel) heroCursorLabel.textContent = 'MIRA';
			}
		});
	}

	// Smooth Reveal Observer
	const reveals = document.querySelectorAll('.mira-reveal');
	if (reducedMotion.matches || !('IntersectionObserver' in window)) {
		reveals.forEach((item) => item.classList.add('is-visible'));
	} else {
		const revealObserver = new IntersectionObserver((entries, observer) => {
			entries.forEach((entry) => {
				if (!entry.isIntersecting) return;
				entry.target.classList.add('is-visible');
				observer.unobserve(entry.target);
			});
		}, { rootMargin: '0px 0px -8%', threshold: .1 });
		reveals.forEach((item) => revealObserver.observe(item));
	}

	// Manifesto Strip Accordion Interaction ("Tutte su una fila, si apre sotto")
	const stripAccordion = document.querySelector('[data-mira-strip-accordion]');
	if (stripAccordion) {
		const chips = [...stripAccordion.querySelectorAll('.mira-manifesto__chip')];
		const drawer = stripAccordion.querySelector('.mira-manifesto__drawer');
		const panels = [...stripAccordion.querySelectorAll('.mira-manifesto__panel')];
		const closeButtons = [...stripAccordion.querySelectorAll('[data-mira-strip-close]')];

		const closeDrawer = () => {
			chips.forEach((c) => {
				c.classList.remove('is-active');
				c.setAttribute('aria-expanded', 'false');
				c.setAttribute('aria-selected', 'false');
			});
			if (drawer) {
				drawer.classList.remove('is-open');
			}
			panels.forEach((p) => {
				p.classList.remove('is-active');
				p.setAttribute('hidden', '');
			});
		};

		const openPanel = (targetSlug, activeChip) => {
			const targetPanel = panels.find((p) => p.dataset.slug === targetSlug);
			if (!targetPanel) return;

			chips.forEach((c) => {
				const isCurrent = c === activeChip;
				c.classList.toggle('is-active', isCurrent);
				c.setAttribute('aria-expanded', String(isCurrent));
				c.setAttribute('aria-selected', String(isCurrent));
			});

			panels.forEach((p) => {
				if (p === targetPanel) {
					p.removeAttribute('hidden');
					void p.offsetHeight; // trigger reflow for smooth animation
					p.classList.add('is-active');
				} else {
					p.classList.remove('is-active');
					p.setAttribute('hidden', '');
				}
			});

			if (drawer) {
				drawer.classList.add('is-open');
			}
		};

		chips.forEach((chip) => {
			chip.addEventListener('click', () => {
				const slug = chip.dataset.target;
				const isOpen = chip.classList.contains('is-active') && drawer && drawer.classList.contains('is-open');

				if (isOpen) {
					closeDrawer();
				} else {
					openPanel(slug, chip);
				}
			});
		});

		closeButtons.forEach((btn) => {
			btn.addEventListener('click', (e) => {
				e.stopPropagation();
				closeDrawer();
			});
		});
	}

	// Master-Detail Showcase Interaction (Smooth, Zero Scroll-Lock)
	const showcase = document.querySelector('[data-mira-showcase]');
	if (showcase) {
		const tabs = [...showcase.querySelectorAll('[data-mira-tab]')];
		const panels = [...showcase.querySelectorAll('[data-mira-panel]')];
		let activeIndex = 0;
		let showcaseTimer = null;
		let isShowcaseHovered = false;

		const setActiveTab = (index) => {
			const targetIndex = Number(index);
			if (isNaN(targetIndex) || targetIndex < 0 || targetIndex >= tabs.length) return;
			activeIndex = targetIndex;

			tabs.forEach((tab, tabIdx) => {
				const active = tabIdx === activeIndex;
				tab.classList.toggle('is-active', active);
				tab.setAttribute('aria-selected', String(active));
			});

			panels.forEach((panel, panelIdx) => {
				const active = panelIdx === activeIndex;
				panel.classList.toggle('is-active', active);
				panel.setAttribute('aria-hidden', String(!active));
			});
		};

		const stopShowcaseAutoplay = () => {
			if (showcaseTimer) {
				window.clearInterval(showcaseTimer);
				showcaseTimer = null;
			}
		};

		const startShowcaseAutoplay = () => {
			stopShowcaseAutoplay();
			if (isShowcaseHovered || reducedMotion.matches || document.hidden || tabs.length < 2) return;
			showcaseTimer = window.setInterval(() => {
				setActiveTab((activeIndex + 1) % tabs.length);
			}, 5000);
		};

		let hoverTimeout = null;
		tabs.forEach((tab, index) => {
			tab.addEventListener('mouseenter', () => {
				window.clearTimeout(hoverTimeout);
				hoverTimeout = window.setTimeout(() => setActiveTab(index), 60);
			});
			tab.addEventListener('mouseleave', () => {
				window.clearTimeout(hoverTimeout);
			});
			tab.addEventListener('click', () => {
				window.clearTimeout(hoverTimeout);
				setActiveTab(index);
			});
			tab.addEventListener('focus', () => {
				window.clearTimeout(hoverTimeout);
				setActiveTab(index);
			});
		});

		showcase.addEventListener('mouseenter', () => {
			isShowcaseHovered = true;
			stopShowcaseAutoplay();
		});

		showcase.addEventListener('mouseleave', () => {
			isShowcaseHovered = false;
			startShowcaseAutoplay();
		});

		// Autoplay only when showcase is visible in viewport
		if ('IntersectionObserver' in window) {
			const showcaseObserver = new IntersectionObserver((entries) => {
				entries.forEach((entry) => {
					if (entry.isIntersecting) {
						startShowcaseAutoplay();
					} else {
						stopShowcaseAutoplay();
					}
				});
			}, { threshold: 0.2 });
			showcaseObserver.observe(showcase);
		} else {
			startShowcaseAutoplay();
		}
	}

	// Partner Marquee Pause Toggle
	const partnerToggle = document.querySelector('[data-mira-partner-toggle]');
	const partnerTrack = document.querySelector('.mira-trust__track');
	if (partnerToggle && partnerTrack) {
		let isPartnerPaused = false;
		partnerToggle.addEventListener('click', () => {
			isPartnerPaused = !isPartnerPaused;
			partnerToggle.setAttribute('aria-pressed', String(isPartnerPaused));
			partnerTrack.classList.toggle('is-paused', isPartnerPaused);
			partnerToggle.textContent = isPartnerPaused ? 'Riprendi movimento' : 'Pausa movimento';
		});
	}

	// Method Progress & Emergency Dock Visibility
	const method = document.querySelector('[data-mira-method]');
	const emergencyDock = document.querySelector('[data-mira-emergency-dock]');
	let motionTicking = false;

	const updateMotion = () => {
		if (method) {
			const rect = method.getBoundingClientRect();
			const windowH = window.innerHeight;
			const totalTravel = rect.height + windowH * .5;
			const currentProgress = (windowH * .8 - rect.top) / totalTravel;
			const progressPct = Math.max(0, Math.min(100, currentProgress * 100));
			method.style.setProperty('--mira-method-progress', `${progressPct}%`);
		}
		if (emergencyDock && hero) {
			emergencyDock.classList.toggle('is-visible', window.scrollY > hero.offsetHeight * .65);
		}
	};

	window.addEventListener('scroll', () => {
		if (motionTicking) return;
		motionTicking = true;
		requestAnimationFrame(() => { updateMotion(); motionTicking = false; });
	}, { passive: true });
	updateMotion();
})();
