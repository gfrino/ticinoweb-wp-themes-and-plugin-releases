(() => {
	'use strict';

	const form = document.querySelector('[data-mira-contact-form]');
	if (!form || typeof window.miraFrontend === 'undefined') return;
	const status = form.querySelector('[data-mira-form-status]');
	const submit = form.querySelector('button[type="submit"]');
	const submitLabel = form.querySelector('[data-submit-label]');
	const initialLabel = submitLabel?.textContent || '';
	let token = '';

	const setStatus = (message, type = '') => {
		status.textContent = message || '';
		status.className = `mira-form-status${type ? ` is-${type}` : ''}`;
	};
	const clearErrors = () => {
		form.querySelectorAll('.mira-field').forEach((field) => {
			field.classList.remove('is-invalid');
			const input = field.querySelector('input, textarea');
			if (input) input.removeAttribute('aria-invalid');
		});
		form.querySelectorAll('[data-error-for]').forEach((error) => { error.textContent = ''; });
	};
	const showErrors = (errors = {}) => {
		Object.entries(errors).forEach(([name, message]) => {
			const input = form.elements[name];
			const error = form.querySelector(`[data-error-for="${CSS.escape(name)}"]`);
			input?.closest('.mira-field')?.classList.add('is-invalid');
			input?.setAttribute('aria-invalid', 'true');
			if (error) error.textContent = message;
		});
		const firstInvalid = form.querySelector('.is-invalid input, .is-invalid textarea');
		firstInvalid?.focus();
	};
	const setLoading = (loading) => {
		submit.disabled = loading;
		form.setAttribute('aria-busy', String(loading));
		if (submitLabel) submitLabel.textContent = loading ? 'Invio in corso…' : initialLabel;
	};
	const getToken = async () => {
		const url = new URL(window.miraFrontend.ajaxUrl, window.location.href);
		url.searchParams.set('action', window.miraFrontend.tokenAction);
		const response = await fetch(url.toString(), { credentials: 'same-origin', cache: 'no-store' });
		const payload = await response.json();
		if (!response.ok || !payload.success || !payload.data?.token) throw new Error('token');
		token = payload.data.token;
		return token;
	};

	form.addEventListener('submit', async (event) => {
		event.preventDefault();
		clearErrors();
		setStatus('');
		if (!form.checkValidity()) {
			form.reportValidity();
			return;
		}
		setLoading(true);
		try {
			if (!token) await getToken();
			const data = new FormData(form);
			data.set('action', window.miraFrontend.submitAction);
			data.set('token', token);
			const response = await fetch(window.miraFrontend.ajaxUrl, { method: 'POST', body: data, credentials: 'same-origin' });
			const payload = await response.json();
			if (!response.ok || !payload.success) {
				if (payload.data?.fields) showErrors(payload.data.fields);
				if (payload.data?.code === 'token') token = '';
				throw new Error(payload.data?.message || 'Invio non riuscito. Riprova.');
			}
			form.reset();
			token = '';
			setStatus(payload.data?.message || 'Grazie, messaggio ricevuto.', 'success');
		} catch (error) {
			setStatus(error.message === 'token' ? 'Impossibile avviare la sessione. Ricarica la pagina e riprova.' : error.message, 'error');
		} finally {
			setLoading(false);
		}
	});

	form.addEventListener('input', (event) => {
		const field = event.target.closest('.mira-field');
		if (!field) return;
		field.classList.remove('is-invalid');
		event.target.removeAttribute('aria-invalid');
		const error = field.querySelector('[data-error-for]');
		if (error) error.textContent = '';
	});

	getToken().catch(() => { token = ''; });
})();
