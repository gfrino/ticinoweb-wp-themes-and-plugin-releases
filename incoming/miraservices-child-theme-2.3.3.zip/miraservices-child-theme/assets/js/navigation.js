(() => {
	'use strict';

	const header = document.querySelector('[data-mira-header]');
	const mega = document.querySelector('[data-mira-mega]');
	const megaTrigger = document.querySelector('[data-mira-mega-trigger]');
	const mobile = document.querySelector('[data-mira-mobile-menu]');
	const mobileToggle = document.querySelector('[data-mira-menu-toggle]');
	const serviceToggle = document.querySelector('[data-mira-mobile-services-toggle]');
	let megaTimer;
	let lastFocus = null;

	const setHeaderState = () => {
		if (header) header.classList.toggle('is-scrolled', window.scrollY > 24);
		const documentHeight = document.documentElement.scrollHeight - window.innerHeight;
		const progress = documentHeight > 0 ? Math.min(100, (window.scrollY / documentHeight) * 100) : 0;
		document.documentElement.style.setProperty('--mira-page-progress', `${progress}%`);
	};
	let scrollTicking = false;
	window.addEventListener('scroll', () => {
		if (scrollTicking) return;
		scrollTicking = true;
		requestAnimationFrame(() => { setHeaderState(); scrollTicking = false; });
	}, { passive: true });
	setHeaderState();

	const setMegaPanel = (index) => {
		if (!mega) return;
		mega.querySelectorAll('[data-mira-mega-item]').forEach((item) => {
			const active = item.dataset.miraMegaItem === index;
			if (active) item.setAttribute('aria-current', 'true');
			else item.removeAttribute('aria-current');
		});
		mega.querySelectorAll('[data-mira-mega-panel]').forEach((panel) => {
			const active = panel.dataset.miraMegaPanel === index;
			panel.classList.toggle('is-active', active);
			panel.setAttribute('aria-hidden', String(!active));
			const link = panel.querySelector('a');
			if (link) link.tabIndex = active ? 0 : -1;
		});
	};

	const openMega = () => {
		if (!mega || !megaTrigger || window.innerWidth < 1100) return;
		window.clearTimeout(megaTimer);
		mega.hidden = false;
		megaTrigger.setAttribute('aria-expanded', 'true');
		header?.classList.add('is-menu-open');
		const activePanel = mega.querySelector('[data-mira-mega-panel].is-active');
		if (!activePanel) setMegaPanel('0');
	};
	const closeMega = (focusTrigger = false) => {
		if (!mega || !megaTrigger) return;
		mega.hidden = true;
		megaTrigger.setAttribute('aria-expanded', 'false');
		header?.classList.remove('is-menu-open');
		if (focusTrigger) megaTrigger.focus();
	};
	const queueMegaClose = () => { megaTimer = window.setTimeout(() => closeMega(), 150); };

	if (mega && megaTrigger) {
		megaTrigger.addEventListener('click', () => mega.hidden ? openMega() : closeMega());
		megaTrigger.addEventListener('mouseenter', openMega);
		megaTrigger.addEventListener('mouseleave', queueMegaClose);
		mega.addEventListener('mouseenter', () => window.clearTimeout(megaTimer));
		mega.addEventListener('mouseleave', queueMegaClose);
		mega.querySelectorAll('[data-mira-mega-item]').forEach((item) => {
			const activate = () => setMegaPanel(item.dataset.miraMegaItem);
			item.addEventListener('mouseenter', activate);
			item.addEventListener('focus', activate);
		});
		document.addEventListener('pointerdown', (event) => {
			if (!mega.hidden && !mega.contains(event.target) && !megaTrigger.contains(event.target)) closeMega();
		});
	}

	const getFocusable = (root) => [...root.querySelectorAll('a[href], button:not([disabled]), input:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])')].filter((node) => !node.hidden);
	const closeMobile = (restoreFocus = false) => {
		if (!mobile || !mobileToggle) return;
		mobile.classList.remove('is-open');
		mobile.setAttribute('aria-hidden', 'true');
		mobileToggle.setAttribute('aria-expanded', 'false');
		header?.classList.remove('is-menu-open');
		document.body.classList.remove('mira-menu-open');
		if (restoreFocus && lastFocus) lastFocus.focus();
	};
	const openMobile = () => {
		if (!mobile || !mobileToggle) return;
		lastFocus = document.activeElement;
		mobile.classList.add('is-open');
		mobile.setAttribute('aria-hidden', 'false');
		mobileToggle.setAttribute('aria-expanded', 'true');
		header?.classList.add('is-menu-open');
		document.body.classList.add('mira-menu-open');
		window.setTimeout(() => getFocusable(mobile)[0]?.focus(), 120);
	};
	if (mobile && mobileToggle) {
		mobileToggle.addEventListener('click', () => mobile.classList.contains('is-open') ? closeMobile() : openMobile());
		mobile.querySelectorAll('a').forEach((link) => link.addEventListener('click', () => closeMobile()));
		mobile.addEventListener('keydown', (event) => {
			if (event.key !== 'Tab') return;
			const focusable = getFocusable(mobile);
			if (!focusable.length) return;
			const first = focusable[0];
			const last = focusable[focusable.length - 1];
			if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
			else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
		});
	}
	if (serviceToggle) {
		const list = document.getElementById(serviceToggle.getAttribute('aria-controls'));
		serviceToggle.addEventListener('click', () => {
			const expanded = serviceToggle.getAttribute('aria-expanded') === 'true';
			serviceToggle.setAttribute('aria-expanded', String(!expanded));
			if (list) list.hidden = expanded;
		});
	}

	document.addEventListener('keydown', (event) => {
		if (event.key !== 'Escape') return;
		if (mobile?.classList.contains('is-open')) closeMobile(true);
		else if (mega && !mega.hidden) closeMega(true);
	});
	window.addEventListener('resize', () => {
		if (window.innerWidth >= 1100) closeMobile();
		else closeMega();
	});

	const samePageAnchor = (link) => {
		try {
			const url = new URL(link.href, window.location.href);
			return url.origin === window.location.origin && url.pathname.replace(/\/$/, '') === window.location.pathname.replace(/\/$/, '') && url.hash;
		} catch (error) { return false; }
	};
	document.querySelectorAll('a[href*="#"]').forEach((link) => {
		link.addEventListener('click', (event) => {
			const hash = samePageAnchor(link);
			if (!hash) return;
			const target = document.querySelector(hash);
			if (!target) return;
			event.preventDefault();
			target.scrollIntoView({ behavior: window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth', block: 'start' });
			history.replaceState(null, '', hash);
		});
	});

	const sections = [...document.querySelectorAll('main section[id]')];
	const navItems = [...document.querySelectorAll('.mira-nav .mira-nav__link')];
	if ('IntersectionObserver' in window && sections.length) {
		const spy = new IntersectionObserver((entries) => {
			const active = entries.filter((entry) => entry.isIntersecting).sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];
			if (!active) return;
			const activeId = active.target.id;
			navItems.forEach((item) => {
				const target = item.dataset.miraNavTarget || (samePageAnchor(item) || '').replace(/^#/, '');
				item.classList.toggle('is-active', target === activeId);
			});
		}, { rootMargin: '-30% 0px -60%', threshold: [0, .1] });
		sections.forEach((section) => spy.observe(section));
	}
})();
