<?php
/**
 * Template Name: Servizi
 */

get_header();
?>

<main id="primary" class="site-main page-servizi">
    <?php while (have_posts()):
        the_post(); ?>

        <!-- Hero Section -->
        <section class="page-hero">
            <div class="container text-center">
                <h1 class="page-title"><?php the_title(); ?></h1>
                <p class="page-hero-subtitle">Scopri tutte le soluzioni di trasporto e logistica pensate su misura per te,
                    con la garanzia di un servizio impeccabile e veloce.</p>
            </div>
        </section>

        <!-- Services Detailed Layout -->
        <section class="services-detailed section-padding" style="background-color: #fafafa;">
            <div class="container">

                <!-- Service 1: Traslochi -->
                <div class="service-row"
                    style="display: flex; align-items: center; gap: 50px; margin-bottom: 80px; flex-wrap: wrap;">
                    <div class="service-image" style="flex: 1; min-width: 300px;">
                        <img src="<?php echo wp_make_link_relative(wp_upload_dir()['baseurl']) . '/2026/03/Gemini_Generated_Image_3bqdgx3bqdgx3bqd.jpeg'; ?>"
                            alt="Traslochi e Trasporti"
                            style="width: 100%; border-radius: 12px; box-shadow: 0 20px 40px rgba(0,0,0,0.1); object-fit: cover; aspect-ratio: 4/3;">
                    </div>
                    <div class="service-text" style="flex: 1; min-width: 300px;">
                        <div class="icon-wrap"
                            style="width: 60px; height: 60px; background: rgba(255, 94, 20, 0.1); border-radius: 50%; display: flex; align-items: center; justify-content: center; margin-bottom: 20px; color: var(--color-primary);">
                            <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <rect x="1" y="3" width="15" height="13"></rect>
                                <polygon points="16 8 20 8 23 11 23 16 16 16 16 8"></polygon>
                                <circle cx="5.5" cy="18.5" r="2.5"></circle>
                                <circle cx="18.5" cy="18.5" r="2.5"></circle>
                            </svg>
                        </div>
                        <h2 style="font-size: 2.2rem; margin-bottom: 20px; color: var(--color-secondary);">Traslochi
                            Completi</h2>
                        <p style="font-size: 1.1rem; line-height: 1.7; color: #666; margin-bottom: 25px;">Gestiamo il tuo
                            trasloco in ogni dettaglio: dallo smontaggio dei mobili all'imballaggio accurato dei tuoi
                            oggetti fragili, fino al montaggio nella nuova destinazione. Usiamo materiali protettivi
                            d'eccellenza per garantire che tutto arrivi perfetto come è partito.</p>
                        <ul style="list-style: none; padding: 0; margin-bottom: 30px;">
                            <li
                                style="margin-bottom: 10px; display: flex; align-items: center; gap: 10px; color: #444; font-weight: 500;">
                                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="var(--color-primary)"
                                    stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                    <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
                                    <polyline points="22 4 12 14.01 9 11.01"></polyline>
                                </svg> Smontaggio e Montaggio Mobili
                            </li>
                            <li
                                style="margin-bottom: 10px; display: flex; align-items: center; gap: 10px; color: #444; font-weight: 500;">
                                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="var(--color-primary)"
                                    stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                    <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
                                    <polyline points="22 4 12 14.01 9 11.01"></polyline>
                                </svg> Imballaggio super protettivo
                            </li>
                            <li
                                style="margin-bottom: 10px; display: flex; align-items: center; gap: 10px; color: #444; font-weight: 500;">
                                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="var(--color-primary)"
                                    stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                    <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
                                    <polyline points="22 4 12 14.01 9 11.01"></polyline>
                                </svg> Smaltimento materiale in discariche autorizzate
                            </li>
                        </ul>
                        <a href="<?php echo home_url('/richiedi-il-tuo-preventivo'); ?>" class="btn btn-primary"
                            style="padding: 12px 28px; border-radius: 8px; text-decoration: none; font-weight: bold; display: inline-block;">Richiedi
                            Sopralluogo</a>
                    </div>
                </div>

                <!-- Service 3: Noleggio -->
                <div class="service-row" style="display: flex; align-items: center; gap: 50px; flex-wrap: wrap;">
                    <div class="service-image" style="flex: 1; min-width: 300px;">
                        <div
                            style="width: 100%; border-radius: 12px; box-shadow: 0 20px 40px rgba(0,0,0,0.1); background: #fff; aspect-ratio: 4/3; overflow: hidden; position: relative;">
                            <img src="<?php echo wp_make_link_relative(wp_upload_dir()['baseurl']) . '/2026/03/Gemini_Generated_Image_tq7ur9tq7ur9tq7u.jpeg'; ?>"
                                alt="Noleggio Autoscala"
                                style="width: 100%; height: 100%; object-fit: cover; display: block;">
                        </div>
                    </div>
                    <div class="service-text" style="flex: 1; min-width: 300px;">
                        <div class="icon-wrap"
                            style="width: 60px; height: 60px; background: rgba(255, 94, 20, 0.1); border-radius: 50%; display: flex; align-items: center; justify-content: center; margin-bottom: 20px; color: var(--color-primary);">
                            <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <rect x="4" y="4" width="16" height="16" rx="2" ry="2"></rect>
                                <rect x="9" y="9" width="6" height="6"></rect>
                                <line x1="9" y1="1" x2="9" y2="4"></line>
                                <line x1="15" y1="1" x2="15" y2="4"></line>
                                <line x1="9" y1="20" x2="9" y2="23"></line>
                                <line x1="15" y1="20" x2="15" y2="23"></line>
                                <line x1="20" y1="9" x2="23" y2="9"></line>
                                <line x1="20" y1="14" x2="23" y2="14"></line>
                                <line x1="1" y1="9" x2="4" y2="9"></line>
                                <line x1="1" y1="14" x2="4" y2="14"></line>
                            </svg>
                        </div>
                        <h2 style="font-size: 2.2rem; margin-bottom: 20px; color: var(--color-secondary);">Noleggio
                            Autoscala e Mezzi</h2>
                        <p style="font-size: 1.1rem; line-height: 1.7; color: #666; margin-bottom: 25px;">Devi spostare
                            mobili pesanti ai piani alti? Oppure ti serve un furgone attrezzato? Mettiamo a disposizione il
                            nostro moderno parco mezzi, incluse potenti autoscale affidate al nostro personale tecnico, per
                            garantirti un supporto logistico all'avanguardia.</p>
                        <ul style="list-style: none; padding: 0; margin-bottom: 30px;">
                            <li
                                style="margin-bottom: 10px; display: flex; align-items: center; gap: 10px; color: #444; font-weight: 500;">
                                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="var(--color-primary)"
                                    stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                    <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
                                    <polyline points="22 4 12 14.01 9 11.01"></polyline>
                                </svg> Noleggio macchinari con nostro operatore tutelato
                            </li>
                            <li
                                style="margin-bottom: 10px; display: flex; align-items: center; gap: 10px; color: #444; font-weight: 500;">
                                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="var(--color-primary)"
                                    stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                    <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
                                    <polyline points="22 4 12 14.01 9 11.01"></polyline>
                                </svg> Trasporti voluminosi o materiali speciali
                            </li>
                            <li
                                style="margin-bottom: 10px; display: flex; align-items: center; gap: 10px; color: #444; font-weight: 500;">
                                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="var(--color-primary)"
                                    stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                    <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
                                    <polyline points="22 4 12 14.01 9 11.01"></polyline>
                                </svg> Ideale per centri storici o rampe a stretto raggio
                            </li>
                        </ul>
                        <a href="<?php echo home_url('/richiedi-il-tuo-preventivo'); ?>" class="btn btn-primary"
                            style="padding: 12px 28px; border-radius: 8px; text-decoration: none; font-weight: bold; display: inline-block;">Richiedi
                            Supporto</a>
                    </div>
                </div>

            </div>
        </section>

        <!-- Additional Features / Micro-Banner -->
        <section class="services-banner section-padding"
            style="background: url('<?php echo wp_make_link_relative(wp_upload_dir()['baseurl']) . '/2026/03/stacks-of-cardboard-boxes-in-new-home-2026-01-08-08-22-09-utc-scaled.jpg'; ?>') center/cover fixed; position: relative; padding: 120px 0; text-align: center;">
            <div
                style="position: absolute; top:0; left:0; right:0; bottom:0; background: linear-gradient(135deg, rgba(17,17,17,0.9), rgba(26,29,31,0.8));">
            </div>
            <div class="container" style="position: relative; z-index: 2;">
                <svg style="margin-bottom: 20px; color: var(--color-primary);" xmlns="http://www.w3.org/2000/svg" width="60"
                    height="60" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
                    stroke-linecap="round" stroke-linejoin="round">
                    <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
                    <polyline points="22 4 12 14.01 9 11.01"></polyline>
                </svg>
                <h2 style="color: white; font-size: 3rem; margin-bottom: 20px; font-weight: 700;">Pronto per il tuo
                    trasloco?</h2>
                <p style="color: #ddd; font-size: 1.25rem; max-width: 700px; margin: 0 auto 40px; line-height: 1.6;">Che si
                    tratti di un piccolo spostamento o di un intero ufficio da smantellare, siamo equipaggiati per
                    soddisfare ogni tipo di richiesta con tempistiche certe.</p>
                <a href="<?php echo home_url('/richiedi-il-tuo-preventivo'); ?>" class="btn btn-primary"
                    style="font-size: 1.15rem; font-weight: 600; padding: 16px 45px; border-radius: 50px; text-decoration: none; transition: transform 0.3s; box-shadow: 0 10px 20px rgba(255,94,20,0.3);">Contattaci
                    Subito</a>
            </div>
        </section>

        <!-- Inline Styles for this specific Template -->
        <style>
            .page-servizi .service-row {
                transition: transform 0.3s ease;
            }

            .page-servizi .service-row:hover .service-image img {
                transform: scale(1.02);
                transition: transform 0.6s cubic-bezier(0.25, 1, 0.5, 1);
            }

            .page-servizi .service-image {
                overflow: hidden;
                border-radius: 12px;
            }

            .page-servizi .service-image img {
                transition: transform 0.6s cubic-bezier(0.25, 1, 0.5, 1);
            }

            @media (max-width: 991px) {

                .page-servizi .service-row,
                .page-servizi .service-row.reversed {
                    flex-direction: column !important;
                    gap: 40px !important;
                    margin-bottom: 70px !important;
                }

                .page-servizi .page-title {
                    font-size: 2.5rem !important;
                }
            }

            @media (max-width: 768px) {
                .page-servizi .services-banner h2 {
                    font-size: 2rem !important;
                }
            }
        </style>

    <?php endwhile; ?>
</main>

<?php get_footer(); ?>