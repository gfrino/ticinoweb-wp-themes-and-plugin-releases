<?php
/**
 * Template Name: Front Page
 *
 * @package TicinoTransporter
 */

get_header();
?>
<main id="primary" class="site-main">

    <!-- SECTION 1 — HERO -->
    <section class="hero-slider-wrapper">
        <div class="hero-slider">
            <div class="slider-track">
                <?php
                // Preleva dati slider dal CMS parent theme via custom function
                $slides = ticinoweb_get_slider_data();
                if (!empty($slides)):
                    foreach ($slides as $index => $slide):
                        if (empty($slide['image']))
                            continue;
                        ?>
                        <div class="slide">
                            <!-- Base BW Layer -->
                            <div class="slide-bg-bw" style="position: absolute; top:0; left:0; width:100%; height:100%; z-index: 1;">
                                <img src="<?php echo esc_url($slide['image']); ?>" alt="<?php echo esc_attr($slide['title']); ?>"
                                    class="slide-image" style="filter: grayscale(100%);">
                                <div class="slide-overlay" style="background: linear-gradient(to right, rgba(0,0,0,0.8), rgba(0,0,0,0.4)) !important;"></div>
                            </div>
                            
                            <!-- Colored + Text Layer (Masked) -->
                            <div class="slide-layer-color full-screen-mask" style="position: absolute; top:0; left:0; width:100%; height:100%; z-index: 2; display: flex; align-items: center; justify-content: center; flex-direction: column;">
                                <img src="<?php echo esc_url($slide['image']); ?>" alt="<?php echo esc_attr($slide['title']); ?>"
                                    class="slide-image">
                                <div class="slide-overlay"></div>
                                <div class="slide-content" style="position: relative; z-index: 10;">
                                    <!-- Reveal Text -->
                                    <div class="slider-text-mask" style="clip-path: none; animation: none; opacity: 1;">
                                        <h1><?php echo esc_html($slide['title']); ?></h1>
                                        <p><?php echo esc_html($slide['desc']); ?></p>
                                        <?php
                                        // Il parent theme non recupera il btn2, quindi creiamo un hack/modifica nel child.
                                        if (!empty($slide['btn1_text']) || !empty($slide['btn1_link'])): ?>
                                            <div class="slider-buttons">
                                                <a href="<?php echo home_url('/richiedi-il-tuo-preventivo/'); ?>"
                                                    class="btn btn-primary">Richiedi Preventivo Gratuito</a>

                                                <?php
                                                $btn2_text = get_option('ticinoweb_slider_btn_text2_' . ($index + 1), 'Scopri i Servizi');
                                                if (!empty($btn2_text)):
                                                    ?>
                                                    <a href="<?php echo home_url('/servizi/'); ?>" class="btn btn-outline"
                                                        style="color: white; border-color: white;"><?php echo esc_html($btn2_text); ?></a>
                                                <?php endif; ?>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Truck Animation Layer -->
                            <div class="slider-truck-anim fullscreen-truck" style="z-index: 3;">
                                <svg class="huge-truck-svg" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 75" fill="none" style="overflow: visible;">
                                    <!-- Speed Lines (Dietro il camion) -->
                                    <g class="speed-lines" stroke="#ffffff" stroke-linecap="round" opacity="0.6">
                                        <line x1="-5" y1="10" x2="-25" y2="10" stroke-width="1.5" />
                                        <line x1="-2" y1="22" x2="-15" y2="22" stroke-width="1" />
                                        <line x1="-12" y1="35" x2="-35" y2="35" stroke-width="2" />
                                        <line x1="-6"  y1="45" x2="-20" y2="45" stroke-width="1.2" />
                                        <line x1="-10" y1="58" x2="-30" y2="58" stroke-width="1.5" />
                                    </g>

                                    <!-- Floor Shadow -->
                                    <ellipse cx="45" cy="65" rx="50" ry="2.5" fill="rgba(0,0,0,0.25)"></ellipse>
                                    
                                    <!-- Chassis / Underbody -->
                                    <rect x="0" y="50" width="70" height="5" fill="#334155"></rect>
                                    <rect x="5" y="48" width="8" height="2" fill="#e2e8f0"></rect> <!-- Tail light -->
                                    <rect x="0" y="55" width="4" height="6" fill="#1e293b"></rect> <!-- Flap -->
                                    
                                    <!-- Main Cargo Box -->
                                    <rect x="0" y="0" width="70" height="50" rx="1.5" fill="var(--color-primary, #FF5E14)"></rect>
                                    <!-- Highlights / Trim -->
                                    <path d="M 0,0 L 70,0 L 70,3 L 0,3 Z" fill="rgba(255,255,255,0.15)"></path>
                                    <rect x="65" y="0" width="5" height="50" fill="rgba(0,0,0,0.1)"></rect>
                                    <line x1="2" y1="46" x2="68" y2="46" stroke="rgba(0,0,0,0.15)" stroke-width="1.5"></line>

                                    <!-- Aerodynamic Roof Deflector -->
                                    <path d="M 70,0 C 85,2 90,15 90,25 L 70,25 Z" fill="#cbd5e1"></path>
                                    <path d="M 75,5 C 82,7 86,15 86,23" fill="none" stroke="#e2e8f0" stroke-width="1.5"></path>

                                    <!-- Modern Cabin -->
                                    <path d="M 70,18 L 88,18 C 96,18 97,25 99,35 L 100,45 L 100,55 L 70,55 Z" fill="#f8fafc"></path>
                                    
                                    <!-- Window / Reflection -->
                                    <path d="M 72,21 L 88,21 C 92,21 93,25 95,35 L 72,35 Z" fill="#1e293b"></path>
                                    <path d="M 74,23 L 86,23 L 88,28 L 74,28 Z" fill="rgba(255,255,255,0.08)"></path> 
                                    
                                    <!-- Door Details -->
                                    <path d="M 75,35 L 75,55 M 88,35 L 88,55" stroke="#94a3b8" stroke-width="0.75"></path>
                                    <rect x="78" y="38" width="6" height="2" rx="1" fill="#475569"></rect>

                                    <!-- Mirror -->
                                    <path d="M 72,20 L 69,20 L 69,32 L 71,32 L 71,22 L 72,22 Z" fill="#1e293b"></path>

                                    <!-- Front Elements (Grill, Bumper, Lights) -->
                                    <path d="M 97,42 L 100,42 L 100,53 L 97,53 Z" fill="#334155"></path>
                                    <line x1="97" y1="45" x2="100" y2="45" stroke="#0f172a" stroke-width="1"></line>
                                    <line x1="97" y1="48" x2="100" y2="48" stroke="#0f172a" stroke-width="1"></line>
                                    <line x1="97" y1="51" x2="100" y2="51" stroke="#0f172a" stroke-width="1"></line>
                                    <polygon points="95,39 98,39 99,41 95,41" fill="#fef08a"></polygon>
                                    <path d="M 90,55 L 100,55 L 100,58 L 90,58 Z" fill="#475569"></path>
                                    <path d="M 70,55 L 75,55 L 75,58 L 70,58 Z" fill="#475569"></path>
                                    <circle cx="72.5" cy="56.5" r="0.5" fill="#f8fafc"></circle>

                                    <!-- Fenders (Thinner and perfectly circular) -->
                                    <path d="M 8.5,50 A 10.5 10.5 0 0 1 27.5,50 L 28.5,50 A 10.5 10.5 0 0 1 47.5,50" fill="none" stroke="#111827" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                                    <path d="M 70,55 A 10.5 10.5 0 0 1 91,55" fill="none" stroke="#111827" stroke-width="2" stroke-linecap="round"></path>

                                    <!-- Multiple Wheels with Rotating Spokes -->
                                    <!-- Rear back -->
                                    <g class="spinning-wheel" style="transform-origin: 18px 55px;">
                                        <circle cx="18" cy="55" r="9" fill="#0f172a"></circle>
                                        <circle cx="18" cy="55" r="5.5" fill="#e2e8f0"></circle>
                                        <path d="M 18,50 L 18,60 M 13,55 L 23,55 M 14.5,51.5 L 21.5,58.5 M 14.5,58.5 L 21.5,51.5" stroke="#94a3b8" stroke-width="1.5"></path>
                                        <circle cx="18" cy="55" r="2.5" fill="#334155"></circle>
                                        <circle cx="18" cy="55" r="1" fill="#0f172a"></circle>
                                    </g>
                                    <!-- Rear mid -->
                                    <g class="spinning-wheel" style="transform-origin: 38px 55px;">
                                        <circle cx="38" cy="55" r="9" fill="#0f172a"></circle>
                                        <circle cx="38" cy="55" r="5.5" fill="#e2e8f0"></circle>
                                        <path d="M 38,50 L 38,60 M 33,55 L 43,55 M 34.5,51.5 L 41.5,58.5 M 34.5,58.5 L 41.5,51.5" stroke="#94a3b8" stroke-width="1.5"></path>
                                        <circle cx="38" cy="55" r="2.5" fill="#334155"></circle>
                                        <circle cx="38" cy="55" r="1" fill="#0f172a"></circle>
                                    </g>
                                    <!-- Front cabin -->
                                    <g class="spinning-wheel" style="transform-origin: 80.5px 55px;">
                                        <circle cx="80.5" cy="55" r="9" fill="#0f172a"></circle>
                                        <circle cx="80.5" cy="55" r="5.5" fill="#e2e8f0"></circle>
                                        <path d="M 80.5,50 L 80.5,60 M 75.5,55 L 85.5,55 M 77,51.5 L 84,58.5 M 77,58.5 L 84,51.5" stroke="#94a3b8" stroke-width="1.5"></path>
                                        <circle cx="80.5" cy="55" r="2.5" fill="#334155"></circle>
                                        <circle cx="80.5" cy="55" r="1" fill="#0f172a"></circle>
                                    </g>
                                </svg>

                                <?php
                                $slider_logo = function_exists('ticinoweb_get_site_logo') ? ticinoweb_get_site_logo() : '';
                                if ($slider_logo): ?>
                                    <img src="<?php echo esc_url($slider_logo); ?>" alt="Morabito" class="truck-logo">
                                <?php else: ?>
                                    <span class="truck-logo"
                                        style="font-weight:900; font-size:2rem; color:#fff;">MORABITO</span>
                                <?php endif; ?>

                            </div>
                        </div>
                    <?php
                    endforeach;
                endif;
                ?>
            </div>
            <button class="slider-arrow prev" aria-label="Slide precedente">
                <svg width="30" height="30" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"
                    stroke-linecap="round" stroke-linejoin="round">
                    <path d="M15 18l-6-6 6-6" />
                </svg>
            </button>
            <button class="slider-arrow next" aria-label="Slide successiva">
                <svg width="30" height="30" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"
                    stroke-linecap="round" stroke-linejoin="round">
                    <path d="M9 18l6-6-6-6" />
                </svg>
            </button>
            <div class="slider-dots"></div>
        </div>
    </section>

    <!-- SECTION 2 — INTRODUCTION -->
    <section id="intro" class="intro-section text-center bg-white" style="padding: 80px 0 20px;">
        <div class="container">
            <h1 class="section-title no-anim" style="opacity: 1 !important; transform: none !important; transition: none !important;">Traslochi e Trasporti Professionali in Ticino</h1>
            <div class="intro-content">
                <p>Ticino Transporter Sagl esegue traslochi, sgomberi e trasporti per privati e aziende in tutto il
                    Ticino.</p>
                <p>Il nostro team lavora con professionalità, precisione e attenzione per garantire un servizio rapido e
                    affidabile.</p>
                <p>Offriamo anche noleggio scale per traslochi e supporto per ogni tipo di spostamento.</p>
            </div>
        </div>
    </section>

    <!-- SECTION 3 — I NOSTRI SERVIZI -->
    <section id="servizi" class="services-section bg-light" style="padding: 60px 0 40px;">
        <div class="container">
            <h2 class="section-title text-center">I Nostri Servizi</h2>
            <div class="services-grid">
                <!-- Card 1 -->
                <div class="service-card">
                    <div class="service-img"
                        style="background-image: url('<?php echo wp_make_link_relative(wp_upload_dir()['baseurl']) . '/2026/03/Gemini_Generated_Image_3bqdgx3bqdgx3bqd.jpeg'; ?>');">
                    </div>
                    <div class="service-body">
                        <h3>Traslochi e Trasporti</h3>
                        <p>Servizi professionali di trasloco per appartamenti, case e uffici.</p>
                        <a href="<?php echo home_url('/servizi'); ?>" class="btn btn-primary">Scopri di più</a>
                    </div>
                </div>

                <!-- Card 2 -->
                <div class="service-card">
                    <div class="service-img"
                        style="background-image: url('<?php echo wp_make_link_relative(wp_upload_dir()['baseurl']) . '/2026/03/Gemini_Generated_Image_tq7ur9tq7ur9tq7u.jpeg'; ?>');">
                    </div>
                    <div class="service-body">
                        <h3>Noleggio Autoscala</h3>
                        <p>Noleggio di mezzi professionali e autoscale per privati o aziende.</p>
                        <a href="<?php echo home_url('/servizi'); ?>" class="btn btn-primary">Scopri di più</a>
                    </div>
                </div>

                <!-- Card 3 -->
                <div class="service-card">
                    <div class="service-img"
                        style="background-image: url('<?php echo wp_make_link_relative(wp_upload_dir()['baseurl']) . '/2026/03/morabito-logo.svg'; ?>');">
                    </div>
                    <div class="service-body">
                        <h3>Richiedi Preventivo</h3>
                        <p>Contattaci per ricevere una valutazione gratuita del tuo trasloco.</p>
                        <a href="<?php echo home_url('/richiedi-il-tuo-preventivo'); ?>"
                            class="btn btn-primary">Richiedi Preventivo</a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- SECTION 4 — PERCHÉ SCEGLIERCI -->
    <section id="features" class="features-section bg-white" style="padding: 60px 0 96px;">
        <div class="container">
            <h2 class="section-title text-center">Perché Sceglierci</h2>
            <div class="features-grid">
                <?php
                $features = array(
                    array(
                        'title' => 'Esperienza nel settore',
                        'icon' => '<svg xmlns="http://www.w3.org/2000/svg" width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="var(--color-primary)" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="8" r="7"></circle><polyline points="8.21 13.89 7 23 12 20 17 23 15.79 13.88"></polyline></svg>'
                    ),
                    array(
                        'title' => 'Servizio rapido e affidabile',
                        'icon' => '<svg xmlns="http://www.w3.org/2000/svg" width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="var(--color-primary)" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 16 14"></polyline></svg>'
                    ),
                    array(
                        'title' => 'Attrezzature professionali',
                        'icon' => '<svg xmlns="http://www.w3.org/2000/svg" width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="var(--color-primary)" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><line x1="16.5" y1="9.4" x2="7.5" y2="4.21"></line><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"></path><polyline points="3.27 6.96 12 12.01 20.73 6.96"></polyline><line x1="12" y1="22.08" x2="12" y2="12"></line></svg>'
                    ),
                    array(
                        'title' => 'Preventivo gratuito e senza impegno',
                        'icon' => '<svg xmlns="http://www.w3.org/2000/svg" width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="var(--color-primary)" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line><polyline points="10 9 9 9 8 9"></polyline></svg>'
                    )
                );

                foreach ($features as $feature): ?>
                    <div class="feature-item">
                        <div class="feature-icon">
                            <?php echo $feature['icon']; ?>
                        </div>
                        <h4><?php echo esc_html($feature['title']); ?></h4>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- SECTION 5 — GALLERIA -->
    <section id="galleria" class="gallery-section section-padding bg-dark">
        <div class="container">
            <h2 class="section-title text-center color-white">Galleria</h2>
            <div class="gallery-grid">
                <?php
                // Fetch dynamic moving and transport images from specific CMS media library galleries (IDs 2, 3, 4)
                $gallery_query = new WP_Query(array(
                    'post_type' => 'attachment',
                    'post_mime_type' => 'image',
                    'post_status' => 'inherit',
                    'posts_per_page' => -1, // Mostra tutte le foto della galleria
                    'tax_query' => array(
                        array(
                            'taxonomy' => 'ticinoweb_media_gallery',
                            'field' => 'term_id',
                            'terms' => array(6),
                            'operator' => 'IN'
                        )
                    )
                ));
                if ($gallery_query->have_posts()) {

                    // Applica l'ordinamento custom salvato dal manager trascinamento del parent theme
                    $saved_order = get_term_meta(6, '_ticinoweb_gallery_order', true);
                    if (!is_array($saved_order)) {
                        $saved_order = array();
                    }
                    if (!empty($saved_order)) {
                        usort($gallery_query->posts, function ($a, $b) use ($saved_order) {
                            $posA = array_search($a->ID, $saved_order);
                            $posB = array_search($b->ID, $saved_order);
                            if ($posA === false && $posB === false)
                                return 0;
                            if ($posA === false)
                                return 1;
                            if ($posB === false)
                                return -1;
                            return $posA - $posB;
                        });
                    }

                    foreach ($gallery_query->posts as $attachment) {
                        $img_src = wp_get_attachment_image_url($attachment->ID, 'large');
                        $full_src = wp_get_attachment_image_url($attachment->ID, 'full');
                        echo '<div class="gallery-item" data-full-img="' . esc_url($full_src) . '">';
                        echo '<img src="' . esc_url($img_src) . '" alt="Lavoro Morabito Traslochi" loading="lazy">';
                        echo '<div class="gallery-overlay"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 3h6v6M9 21H3v-6M21 3l-7 7M3 21l7-7"/></svg></div>';
                        echo '</div>';
                    }
                } else {
                    echo '<p class="text-center color-white text-large">Carica le foto dei tuoi traslochi nella libreria media per farle apparire in questa galleria dinamica.</p>';
                }
                ?>
            </div>
        </div>
    </section>

    <!-- SECTION 6 — CALL TO ACTION -->
    <!-- SECTION 6 — CALL TO ACTION -->
    <section id="cta" class="cta-section section-padding text-center">
        <div class="container">
            <h2 class="cta-title">Hai bisogno di un trasloco?</h2>
            <p class="cta-subtitle">Contattaci per ricevere tutte le informazioni e un preventivo gratuito senza
                impegno.</p>
            <div class="cta-buttons">
                <a href="<?php echo home_url('/richiedi-il-tuo-preventivo'); ?>"
                    class="btn btn-primary btn-large">Richiedi Preventivo</a>
            </div>
        </div>
    </section>

</main>



<?php get_footer(); ?>