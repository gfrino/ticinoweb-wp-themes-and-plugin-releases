<?php
/**
 * Header template for Morabito Traslochi child theme
 */
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?> id="home">
<?php wp_body_open(); ?>

<?php 
// Recupero info dal CMS (tramite opzioni del parent theme)
$contact_info = function_exists('ticinoweb_get_contact_info') ? ticinoweb_get_contact_info() : array();
$phone = isset($contact_info['phone']) ? $contact_info['phone'] : '+41 79 000 00 00';
$email = isset($contact_info['email']) ? $contact_info['email'] : 'info@morabitotraslochi.ch';
?>

<!-- Header Topbar (Opzionale: molto usato per siti di servizi/traslochi) -->
<div class="tt-topbar">
    <div class="container tt-topbar-inner">
        <div class="tt-topbar-contact">
            <a href="tel:<?php echo esc_attr(str_replace(' ', '', $phone)); ?>">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path></svg>
                <?php echo esc_html($phone); ?>
            </a>
            <a href="mailto:<?php echo esc_attr($email); ?>">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path><polyline points="22,6 12,13 2,6"></polyline></svg>
                <?php echo esc_html($email); ?>
            </a>
        </div>
    </div>
</div>

<header class="tt-site-header">
    <div class="container tt-header-inner">
        <!-- Brand / Logo -->
        <div class="tt-site-branding">
            <a href="<?php echo esc_url(home_url('/')); ?>" rel="home">
                <?php 
                $logo = function_exists('ticinoweb_get_site_logo') ? ticinoweb_get_site_logo() : '';
                if ($logo): 
                ?>
                    <img src="<?php echo esc_url($logo); ?>" alt="<?php bloginfo('name'); ?>" class="tt-site-logo tt-logo-mobile">
                    <img src="<?php echo esc_url(wp_make_link_relative(wp_upload_dir()['baseurl']) . '/2026/03/morabito-logo-wide-2.svg'); ?>" alt="<?php bloginfo('name'); ?>" class="tt-site-logo tt-logo-desktop">
                <?php else: ?>
                    <span class="tt-site-title"><?php bloginfo('name'); ?></span>
                <?php endif; ?>
            </a>
        </div>

        <!-- Mobile Toggle -->
        <button class="tt-menu-toggle" aria-controls="primary-menu" aria-expanded="false">
            <span class="tt-hamburger"></span>
        </button>

        <!-- Navigation and CTA -->
        <div class="tt-nav-wrapper">
            <nav class="tt-main-navigation">
                <?php
                wp_nav_menu(array(
                    'theme_location' => 'primary',
                    'menu_class'     => 'tt-primary-menu',
                    'container'      => false,
                    'fallback_cb'    => false,
                ));
                ?>
            </nav>
        </div>
    </div>
</header>
