<?php
add_action('init', function() {
    if (!isset($_GET['replace_hardcoded_links'])) return;

    global $wpdb;
    
    // Imposta il Site ID 5 (Morabito Trasporti)
    $blog_id = 5;
    $prefix = $wpdb->get_blog_prefix($blog_id);
    
    $old_url = 'http://localhost:8000/morabitotrasporti';
    $new_url = 'http://localhost:8000/morabitotraslochi';
    
    // 1. Array di Query SQL semplici (ideali per i menu, i contenuti e GUID)
    $queries = [
        "UPDATE {$prefix}posts SET post_content = REPLACE(post_content, '{$old_url}', '{$new_url}')",
        "UPDATE {$prefix}posts SET guid = REPLACE(guid, '{$old_url}', '{$new_url}')",
        "UPDATE {$prefix}postmeta SET meta_value = REPLACE(meta_value, '{$old_url}', '{$new_url}')"
    ];
    
    foreach ($queries as $q) {
        $wpdb->query($q);
    }
    
    // 2. Nav Menu Items specifici (_menu_item_url)
    $wpdb->query("UPDATE {$prefix}postmeta SET meta_value = REPLACE(meta_value, '{$old_url}', '{$new_url}') WHERE meta_key = '_menu_item_url'");

    $wpdb->query("UPDATE {$prefix}options SET option_value = 'morabitotraslochi' WHERE option_name = 'stylesheet' AND option_value = 'morabitotrasporti'");
    // (If current_theme is Morabito Traslochi Child, wait, no, just the text representation. We'll brutally update it later if needed, but stylesheet is the key one that dictates the directory!)
    // "morabitotraslochi" = 17 caratteri.
    // La lunghezza è identica! Questo significa che una REPLACE SQL nuda sui campi serializzati non romperà *assolutamente nulla*. WOW!
    
    // CRITICAL: Update multisite root router path for blog 5 so the WP network recognizes the new URL natively!
    $wpdb->query("UPDATE {$wpdb->base_prefix}blogs SET path = REPLACE(path, '/morabitotrasporti/', '/morabitotraslochi/') WHERE blog_id = {$blog_id}");

    // SUPER CRITICAL MULTISITE FIX: Network Enable the newly renamed theme so it appears in Appearance > Themes!
    $allowed = get_site_option('allowedthemes', array());
    $allowed['morabitotraslochi'] = true;
    update_site_option('allowedthemes', $allowed);

    // Also force-activate it directly so the user doesn't even need to click!
    switch_to_blog($blog_id);
    update_option('stylesheet', 'morabitotraslochi');
    update_option('template', 'ticinoweb-ai-theme');

    // CRUCIAL: Rename the theme_mods option to import all Menu Locations and Customizer settings 
    // from the old theme ID to the newly named child theme instantly!
    $wpdb->query("DELETE FROM {$prefix}options WHERE option_name = 'theme_mods_morabitotraslochi'");
    $wpdb->query("UPDATE {$prefix}options SET option_name = 'theme_mods_morabitotraslochi' WHERE option_name = 'theme_mods_morabitotrasporti'");

    restore_current_blog();

    echo "Tutti i link, i percorsi e i permessi Multisite sono stati brutalmente aggiornati su Morabito Traslochi! Tema riattivato automaticamente e MENU RIPRISTINATI!";
    exit;
});
