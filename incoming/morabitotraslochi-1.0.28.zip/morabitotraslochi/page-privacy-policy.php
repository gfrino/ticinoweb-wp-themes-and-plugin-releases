<?php
/**
 * Template Name: Privacy Policy Page
 *
 * @package TicinoTransporter
 */

get_header();
?>

<main id="primary" class="site-main page-privacy">
    
    <!-- Hero Section -->
    <section class="page-hero" style="background: linear-gradient(135deg, #111827 0%, #1F2937 100%); padding: 100px 0 60px; border-bottom: 5px solid var(--color-primary, #FF5E14); position: relative; overflow: hidden; text-align: center; color: white;">
        <div style="position: absolute; top: 0; right: 0; bottom: 0; left: 0; background: radial-gradient(circle at top right, rgba(255, 94, 20, 0.15), transparent 50%); z-index: 0;"></div>
        <div class="container" style="position: relative; z-index: 1;">
            <h1 class="page-title" style="font-size: 3rem; font-weight: 800; text-transform: uppercase; margin: 0 0 10px; letter-spacing: -0.02em;"><?php the_title(); ?></h1>
            <p class="page-hero-subtitle" style="color: rgba(255, 255, 255, 0.8); font-size: 1.15rem; margin: 0;">Ultimo aggiornamento: Maggio 2026</p>
        </div>
    </section>

    <!-- Main Content -->
    <section class="privacy-content section-padding" style="padding: 80px 0; background-color: #ffffff;">
        <div class="container" style="max-width: 850px; margin: 0 auto; font-size: 1.05rem; line-height: 1.85; color: #374151;">
            
            <div class="privacy-intro-card" style="background: #f9fafb; border-left: 4px solid var(--color-primary, #FF5E14); padding: 25px; border-radius: 0 8px 8px 0; margin-bottom: 40px; box-shadow: 0 4px 15px rgba(0,0,0,0.02);">
                <p style="margin: 0; font-weight: 500;">La presente Privacy Policy descrive le modalità con cui <strong>Morabito Trasporti</strong> raccoglie, utilizza e protegge i dati personali degli utenti che visitano il sito web <strong>morabitotrasporti.com</strong>.</p>
                <p style="margin: 15px 0 0; font-size: 0.95rem; color: #6b7280;">La presente informativa è redatta in conformità alla normativa applicabile in materia di protezione dei dati personali, inclusi il Regolamento UE 2016/679 — GDPR, ove applicabile, e la Legge federale svizzera sulla protezione dei dati — LPD.</p>
            </div>

            <div class="privacy-sections" style="display: flex; flex-direction: column; gap: 35px;">
                
                <!-- Section 1 -->
                <div class="privacy-section">
                    <h2 style="font-size: 1.5rem; color: #111827; margin-top: 0; margin-bottom: 15px; font-weight: 700; border-bottom: 1px solid #e5e7eb; padding-bottom: 8px;">1. Titolare del trattamento</h2>
                    <p>Il titolare del trattamento dei dati personali è:</p>
                    <div style="background: #f3f4f6; padding: 20px; border-radius: 8px; margin: 15px 0; border: 1px solid #e5e7eb;">
                        <strong style="color: #111827; font-size: 1.1rem; display: block; margin-bottom: 10px;">Morabito Trasporti</strong>
                        <ul style="list-style: none; padding: 0; margin: 0; display: flex; flex-direction: column; gap: 6px;">
                            <li><strong>Indirizzo:</strong> Via Galbisio 23 6500 Bellinzona</li>
                            <li><strong>E-mail:</strong> <a href="mailto:ticino.transporter@live.com" style="color: var(--color-primary, #FF5E14); text-decoration: none; font-weight: 500;">ticino.transporter@live.com</a></li>
                            <li><strong>Telefono:</strong> <a href="tel:+41798522553" style="color: var(--color-primary, #FF5E14); text-decoration: none; font-weight: 500;">+41 79 852 25 53</a></li>
                            <li><strong>Sito web:</strong> <a href="https://morabitotrasporti.com" target="_blank" rel="noopener" style="color: var(--color-primary, #FF5E14); text-decoration: none; font-weight: 500;">morabitotrasporti.com</a></li>
                        </ul>
                    </div>
                    <p>Per qualsiasi richiesta relativa al trattamento dei dati personali, è possibile contattare il titolare tramite i recapiti sopra indicati.</p>
                </div>

                <!-- Section 2 -->
                <div class="privacy-section">
                    <h2 style="font-size: 1.5rem; color: #111827; margin-top: 0; margin-bottom: 15px; font-weight: 700; border-bottom: 1px solid #e5e7eb; padding-bottom: 8px;">2. Dati personali raccolti</h2>
                    <p>Attraverso il sito web possono essere raccolti i seguenti dati personali:</p>
                    <p style="margin-bottom: 8px;"><strong>Dati forniti volontariamente dall’utente</strong>, ad esempio tramite modulo di contatto o richiesta preventivo:</p>
                    <ul style="padding-left: 20px; margin-bottom: 20px;">
                        <li>Nome e cognome</li>
                        <li>Indirizzo e-mail</li>
                        <li>Numero di telefono</li>
                        <li>Indirizzo o località del servizio richiesto</li>
                        <li>Informazioni inserite nel messaggio</li>
                        <li>Eventuali dettagli relativi a trasporti, traslochi, consegne o richieste specifiche</li>
                    </ul>
                    <p style="margin-bottom: 8px;"><strong>Dati raccolti automaticamente</strong> durante la navigazione, come:</p>
                    <ul style="padding-left: 20px;">
                        <li>Indirizzo IP</li>
                        <li>Tipo di browser e dispositivo utilizzato</li>
                        <li>Sistema operativo</li>
                        <li>Pagine visitate</li>
                        <li>Data e ora di accesso</li>
                        <li>Dati tecnici necessari al corretto funzionamento del sito</li>
                    </ul>
                </div>

                <!-- Section 3 -->
                <div class="privacy-section">
                    <h2 style="font-size: 1.5rem; color: #111827; margin-top: 0; margin-bottom: 15px; font-weight: 700; border-bottom: 1px solid #e5e7eb; padding-bottom: 8px;">3. Finalità del trattamento</h2>
                    <p>I dati personali raccolti vengono trattati per le seguenti finalità:</p>
                    <ul style="padding-left: 20px; margin-bottom: 15px;">
                        <li>Rispondere a richieste inviate tramite il sito</li>
                        <li>Fornire informazioni sui servizi offerti</li>
                        <li>Preparare preventivi o ricontattare l’utente</li>
                        <li>Gestire comunicazioni commerciali richieste dall’utente</li>
                        <li>Migliorare il funzionamento e la sicurezza del sito</li>
                        <li>Adempiere a obblighi legali, fiscali o amministrativi</li>
                        <li>Prevenire abusi, spam o attività fraudolente</li>
                    </ul>
                    <p>I dati non saranno utilizzati per finalità diverse da quelle indicate senza il consenso dell’utente, ove richiesto dalla legge.</p>
                </div>

                <!-- Section 4 -->
                <div class="privacy-section">
                    <h2 style="font-size: 1.5rem; color: #111827; margin-top: 0; margin-bottom: 15px; font-weight: 700; border-bottom: 1px solid #e5e7eb; padding-bottom: 8px;">4. Base giuridica del trattamento</h2>
                    <p>Il trattamento dei dati personali si basa su una o più delle seguenti basi giuridiche:</p>
                    <ul style="padding-left: 20px;">
                        <li><strong>Consenso dell’utente</strong>, quando invia volontariamente una richiesta tramite il sito</li>
                        <li><strong>Esecuzione di misure precontrattuali o contrattuali</strong>, ad esempio per la preparazione di un preventivo</li>
                        <li><strong>Legittimo interesse del titolare</strong>, per garantire sicurezza, manutenzione e miglioramento del sito</li>
                        <li><strong>Obblighi di legge</strong>, quando il trattamento è necessario per adempiere a disposizioni normative</li>
                    </ul>
                </div>

                <!-- Section 5 -->
                <div class="privacy-section">
                    <h2 style="font-size: 1.5rem; color: #111827; margin-top: 0; margin-bottom: 15px; font-weight: 700; border-bottom: 1px solid #e5e7eb; padding-bottom: 8px;">5. Modalità di trattamento</h2>
                    <p>I dati personali sono trattati con strumenti informatici, telematici e, se necessario, cartacei.</p>
                    <p>Il titolare adotta misure tecniche e organizzative adeguate per proteggere i dati da accessi non autorizzati, perdita, uso improprio, divulgazione o modifica non autorizzata.</p>
                </div>

                <!-- Section 6 -->
                <div class="privacy-section">
                    <h2 style="font-size: 1.5rem; color: #111827; margin-top: 0; margin-bottom: 15px; font-weight: 700; border-bottom: 1px solid #e5e7eb; padding-bottom: 8px;">6. Conservazione dei dati</h2>
                    <p>I dati personali vengono conservati per il tempo necessario a raggiungere le finalità per cui sono stati raccolti.</p>
                    <p>In particolare:</p>
                    <ul style="padding-left: 20px; margin-bottom: 15px;">
                        <li>I dati inviati tramite modulo di contatto o richiesta preventivo possono essere conservati per il tempo necessario alla gestione della richiesta.</li>
                        <li>I dati relativi a rapporti commerciali possono essere conservati per obblighi amministrativi, fiscali o legali.</li>
                        <li>I dati tecnici di navigazione possono essere conservati per il tempo necessario alla sicurezza e al corretto funzionamento del sito.</li>
                    </ul>
                    <p>Al termine del periodo di conservazione, i dati saranno cancellati o anonimizzati.</p>
                </div>

                <!-- Section 7 -->
                <div class="privacy-section">
                    <h2 style="font-size: 1.5rem; color: #111827; margin-top: 0; margin-bottom: 15px; font-weight: 700; border-bottom: 1px solid #e5e7eb; padding-bottom: 8px;">7. Comunicazione dei dati a terzi</h2>
                    <p>I dati personali non vengono venduti, ceduti o diffusi a terzi.</p>
                    <p>Potranno essere comunicati esclusivamente a soggetti che collaborano con il titolare per finalità strettamente connesse alla gestione del sito o dei servizi richiesti, come:</p>
                    <ul style="padding-left: 20px; margin-bottom: 15px;">
                        <li>Fornitori di hosting e manutenzione del sito</li>
                        <li>Fornitori di servizi e-mail</li>
                        <li>Consulenti amministrativi, fiscali o legali</li>
                        <li>Collaboratori o partner coinvolti nell’erogazione del servizio richiesto</li>
                    </ul>
                    <p>Tali soggetti tratteranno i dati nel rispetto della normativa applicabile e solo per le finalità autorizzate.</p>
                </div>

                <!-- Section 8 -->
                <div class="privacy-section">
                    <h2 style="font-size: 1.5rem; color: #111827; margin-top: 0; margin-bottom: 15px; font-weight: 700; border-bottom: 1px solid #e5e7eb; padding-bottom: 8px;">8. Trasferimento dei dati all’estero</h2>
                    <p>Alcuni servizi tecnici utilizzati dal sito, come hosting, strumenti di sicurezza, sistemi e-mail o servizi statistici, potrebbero comportare il trasferimento di dati verso Paesi diversi da quello dell’utente.</p>
                    <p>In questi casi, il titolare si impegna ad adottare garanzie adeguate affinché il trattamento avvenga nel rispetto della normativa applicabile in materia di protezione dei dati.</p>
                </div>

                <!-- Section 9 -->
                <div class="privacy-section">
                    <h2 style="font-size: 1.5rem; color: #111827; margin-top: 0; margin-bottom: 15px; font-weight: 700; border-bottom: 1px solid #e5e7eb; padding-bottom: 8px;">9. Cookie</h2>
                    <p>Il sito può utilizzare cookie tecnici necessari al suo corretto funzionamento.</p>
                    <p>Inoltre, previo consenso dell’utente ove richiesto, il sito può utilizzare cookie analitici o di terze parti per raccogliere statistiche anonime o migliorare l’esperienza di navigazione.</p>
                    <p>L’utente può gestire o disattivare i cookie tramite le impostazioni del proprio browser.</p>
                    <p>Per maggiori informazioni, si consiglia di predisporre una pagina separata dedicata alla Cookie Policy.</p>
                </div>

                <!-- Section 10 -->
                <div class="privacy-section">
                    <h2 style="font-size: 1.5rem; color: #111827; margin-top: 0; margin-bottom: 15px; font-weight: 700; border-bottom: 1px solid #e5e7eb; padding-bottom: 8px;">10. Moduli di contatto</h2>
                    <p>Quando l’utente invia una richiesta tramite un modulo presente sul sito, i dati inseriti vengono utilizzati esclusivamente per rispondere alla richiesta, fornire informazioni o preparare un preventivo.</p>
                    <p>L’invio del modulo comporta la presa visione della presente Privacy Policy.</p>
                </div>

                <!-- Section 11 -->
                <div class="privacy-section">
                    <h2 style="font-size: 1.5rem; color: #111827; margin-top: 0; margin-bottom: 15px; font-weight: 700; border-bottom: 1px solid #e5e7eb; padding-bottom: 8px;">11. Diritti dell’utente</h2>
                    <p>L’utente ha il diritto di:</p>
                    <ul style="padding-left: 20px; margin-bottom: 15px;">
                        <li>Richiedere l’accesso ai propri dati personali</li>
                        <li>Chiedere la rettifica di dati inesatti o incompleti</li>
                        <li>Richiedere la cancellazione dei dati, nei casi previsti dalla legge</li>
                        <li>Richiedere la limitazione del trattamento</li>
                        <li>Opporsi al trattamento dei dati</li>
                        <li>Richiedere la portabilità dei dati, ove applicabile</li>
                        <li>Revocare il consenso prestato, senza pregiudicare la liceità del trattamento effettuato prima della revoca</li>
                        <li>Presentare reclamo all’autorità competente in materia di protezione dei dati</li>
                    </ul>
                    <p>Per esercitare i propri diritti, l’utente può contattare il titolare ai recapiti indicati nella sezione “Titolare del trattamento”.</p>
                </div>

                <!-- Section 12 -->
                <div class="privacy-section">
                    <h2 style="font-size: 1.5rem; color: #111827; margin-top: 0; margin-bottom: 15px; font-weight: 700; border-bottom: 1px solid #e5e7eb; padding-bottom: 8px;">12. Sicurezza dei dati</h2>
                    <p>Il titolare adotta misure di sicurezza adeguate per proteggere i dati personali degli utenti.</p>
                    <p>Tuttavia, nessun sistema informatico o trasmissione via Internet può essere considerato completamente sicuro. Per questo motivo, pur adottando misure adeguate, non è possibile garantire una sicurezza assoluta.</p>
                </div>

                <!-- Section 13 -->
                <div class="privacy-section">
                    <h2 style="font-size: 1.5rem; color: #111827; margin-top: 0; margin-bottom: 15px; font-weight: 700; border-bottom: 1px solid #e5e7eb; padding-bottom: 8px;">13. Link a siti esterni</h2>
                    <p>Il sito potrebbe contenere link verso siti web di terzi.</p>
                    <p>Il titolare non è responsabile dei contenuti, della sicurezza o delle pratiche privacy adottate da tali siti esterni. Si invita l’utente a consultare le rispettive informative privacy.</p>
                </div>

                <!-- Section 14 -->
                <div class="privacy-section">
                    <h2 style="font-size: 1.5rem; color: #111827; margin-top: 0; margin-bottom: 15px; font-weight: 700; border-bottom: 1px solid #e5e7eb; padding-bottom: 8px;">14. Modifiche alla presente Privacy Policy</h2>
                    <p>Il titolare si riserva il diritto di modificare o aggiornare la presente Privacy Policy in qualsiasi momento.</p>
                    <p>Le modifiche saranno pubblicate su questa pagina con indicazione della data di ultimo aggiornamento.</p>
                </div>

                <!-- Section 15 -->
                <div class="privacy-section" style="background: #f9fafb; padding: 25px; border-radius: 8px; border: 1px dashed #d1d5db;">
                    <h2 style="font-size: 1.5rem; color: #111827; margin-top: 0; margin-bottom: 15px; font-weight: 700; border-bottom: 1px solid #e5e7eb; padding-bottom: 8px;">15. Contatti</h2>
                    <p>Per domande, richieste o chiarimenti relativi alla presente Privacy Policy, è possibile contattare:</p>
                    <ul style="list-style: none; padding: 0; margin: 0; display: flex; flex-direction: column; gap: 6px;">
                        <li><strong>Morabito Trasporti</strong></li>
                        <li><strong>E-mail:</strong> <a href="mailto:ticino.transporter@live.com" style="color: var(--color-primary, #FF5E14); text-decoration: none; font-weight: 500;">ticino.transporter@live.com</a></li>
                        <li><strong>Telefono:</strong> <a href="tel:+41798522553" style="color: var(--color-primary, #FF5E14); text-decoration: none; font-weight: 500;">+41 79 852 25 53</a></li>
                        <li><strong>Indirizzo:</strong> Via Galbisio 23 6500 Bellinzona</li>
                    </ul>
                </div>

            </div>

        </div>
    </section>

</main>

<?php
get_footer();
?>
