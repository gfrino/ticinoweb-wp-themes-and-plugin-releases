<?php
/**
 * Footer template for Morabito Traslochi child theme
 */

// Recupero info dal CMS (tramite opzioni del parent theme)
$contact_info = function_exists('ticinoweb_get_contact_info') ? ticinoweb_get_contact_info() : array();
$phone = isset($contact_info['phone']) && !empty($contact_info['phone']) ? $contact_info['phone'] : '+41 79 000 00 00';
$email = isset($contact_info['email']) && !empty($contact_info['email']) ? $contact_info['email'] : 'info@morabitotraslochi.ch';
$address = isset($contact_info['address']) && !empty($contact_info['address']) ? $contact_info['address'] : 'Inserisci Indirizzo';
?>

<footer class="tt-site-footer" id="contatti">
    <div class="container tt-footer-inner">
        <div class="tt-footer-main">
            <!-- Brand / Logo Footer -->
            <div class="tt-footer-brand">
                <a href="<?php echo esc_url(home_url('/')); ?>" rel="home">
                    <?php 
                    $logo = function_exists('ticinoweb_get_site_logo') ? ticinoweb_get_site_logo() : '';
                    if ($logo): 
                    ?>
                        <img src="<?php echo esc_url($logo); ?>" alt="<?php bloginfo('name'); ?>" class="tt-footer-logo">
                    <?php else: ?>
                        <h2 class="tt-footer-brand-name"><?php bloginfo('name'); ?></h2>
                    <?php endif; ?>
                </a>
                <p class="tt-footer-tagline">
                    <?php 
                    $desc = get_bloginfo('description'); 
                    echo $desc ? esc_html($desc) : 'La tua ditta fidata di traslochi e trasporti in Ticino.'; 
                    ?>
                </p>
                <div class="tt-footer-contact-details">
                    <a href="tel:<?php echo esc_attr(str_replace(' ', '', $phone)); ?>">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path></svg>
                        <?php echo esc_html($phone); ?>
                    </a>
                    <a href="mailto:<?php echo esc_attr($email); ?>">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path><polyline points="22,6 12,13 2,6"></polyline></svg>
                        <?php echo esc_html($email); ?>
                    </a>
                    <span class="tt-address" style="display:flex; align-items:center; gap:6px;">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path><circle cx="12" cy="10" r="3"></circle></svg>
                        <?php echo esc_html($address); ?>
                    </span>
                </div>
            </div>

            <!-- Footer Menu -->
            <div class="tt-footer-links">
                <h3>Esplora</h3>
                <nav class="tt-footer-navigation">
                    <?php
                    // Fallback to 'primary' menu if 'footer' is not set
                    $theme_loc = has_nav_menu('footer') ? 'footer' : (has_nav_menu('primary') ? 'primary' : '');
                    if ($theme_loc) {
                        wp_nav_menu(array(
                            'theme_location' => $theme_loc,
                            'menu_class'     => 'tt-footer-menu',
                            'container'      => false,
                            'fallback_cb'    => false,
                        ));
                    }
                    ?>
                </nav>
            </div>
            
            <!-- CTA Footer -->
            <div class="tt-footer-cta-area">
                <h3>Richiedi un Preventivo</h3>
                <p>Siamo a disposizione per sopralluoghi gratuiti in tutto il Ticino.</p>
                <a href="<?php echo home_url('/richiedi-il-tuo-preventivo/'); ?>" class="btn btn-primary" style="margin-top: 15px;">Preventivo Gratuito</a>
            </div>
        </div>
        
        <!-- Footer Bottom -->
        <div class="tt-footer-bottom">
            <div class="tt-footer-bottom-inner">
                <span class="tt-footer-copyright">&copy; <?php echo date('Y'); ?> <?php bloginfo('name'); ?>. Tutti i diritti riservati. - <a href="<?php echo esc_url(admin_url()); ?>" style="text-decoration: underline; opacity: 0.8; margin-left: 5px;">Area riservata</a> - <a href="<?php echo esc_url(home_url('/privacy-policy/')); ?>" style="text-decoration: underline; opacity: 0.8; margin-left: 5px;">Privacy Policy</a></span>
                <span class="tt-footer-credits">Design by <a href="https://ticinoweb.com" target="_blank" rel="noopener">ticinoWEB</a></span>
            </div>
        </div>
    </div>
</footer>

<?php wp_footer(); ?>
<script>
document.addEventListener("DOMContentLoaded", function() {
    const observer = new IntersectionObserver((entries) => {
        entries.forEach((entry) => {
            if (entry.isIntersecting) {
                entry.target.classList.add('is-visible');
                // Optional: to animate only once, stop observing after it becomes visible
                observer.unobserve(entry.target);
            }
        });
    }, { threshold: 0.1, rootMargin: '0px 0px -50px 0px' });
    
    // Selected elements for entrance animations
    const animElements = document.querySelectorAll('.page-title, .page-hero-subtitle, .section-title, .service-card, .gallery-item, .about-image, .entry-content p, .intro-content p, .features-grid > div, .contact-info-wrap, .contact-form-wrap, .service-image, .service-text, .feature-box, .deposito-features h2, .cta-title, .cta-subtitle, .about-text, .showcase-content, .showcase-images');
    
    animElements.forEach((el, index) => {
        el.classList.add('fade-in-up');
        // staggering slightly if they appear together
        el.style.transitionDelay = (index % 5) * 0.1 + 's';
        observer.observe(el);
    });
});
</script>
</body>
</html>
