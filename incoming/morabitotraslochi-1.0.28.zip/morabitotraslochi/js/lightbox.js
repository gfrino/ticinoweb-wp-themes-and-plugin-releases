document.addEventListener('DOMContentLoaded', function() {
    const galleryItems = document.querySelectorAll('.gallery-item');
    if (galleryItems.length === 0) return;

    // Create Lightbox DOM
    const lightbox = document.createElement('div');
    lightbox.className = 'tt-lightbox';
    lightbox.innerHTML = `
        <div class="tt-lightbox-overlay"></div>
        <button class="tt-lightbox-close">&times;</button>
        <button class="tt-lightbox-prev">
            <svg width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 18l-6-6 6-6"/></svg>
        </button>
        <button class="tt-lightbox-next">
            <svg width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 18l6-6-6-6"/></svg>
        </button>
        <div class="tt-lightbox-content">
            <img class="tt-lightbox-img" src="" alt="Galleria Lavori">
        </div>
    `;
    document.body.appendChild(lightbox);

    const overlay = lightbox.querySelector('.tt-lightbox-overlay');
    const imgEl = lightbox.querySelector('.tt-lightbox-img');
    const closeBtn = lightbox.querySelector('.tt-lightbox-close');
    const prevBtn = lightbox.querySelector('.tt-lightbox-prev');
    const nextBtn = lightbox.querySelector('.tt-lightbox-next');

    let currentIndex = 0;
    
    // Store image URLs
    const images = Array.from(galleryItems).map(item => item.getAttribute('data-full-img'));

    function openLightbox(index) {
        currentIndex = index;
        imgEl.style.opacity = '0'; // assicura opacità iniziale per la dissolvenza in fade-in
        imgEl.src = images[currentIndex];
        imgEl.onload = () => { imgEl.style.opacity = '1'; }; // dissolvenza in entrata
        lightbox.classList.add('active');
        document.body.style.overflow = 'hidden'; // Prevent scrolling background
    }

    function closeLightbox() {
        lightbox.classList.remove('active');
        document.body.style.overflow = '';
        setTimeout(() => { imgEl.src = ''; }, 300); // Clear after fade out
    }

    let isAnimating = false;

    function changeImageWithFade(newIndex) {
        if (isAnimating) return;
        isAnimating = true;

        // 1. dissolvenza in uscita
        imgEl.style.opacity = '0';
        
        // 2. aspetta che finisca l'animazione css (0.3s)
        setTimeout(() => {
            currentIndex = newIndex;
            imgEl.src = images[currentIndex];
            
            // 3. dissolvenza in entrata non appena caricata la nuova src
            imgEl.onload = () => {
                imgEl.style.opacity = '1';
                setTimeout(() => { isAnimating = false; }, 300);
            };
            
            // Fallback per cache veloce (se onload non trigghera visivamente)
            setTimeout(() => { 
                imgEl.style.opacity = '1'; 
                isAnimating = false; 
            }, 50);

        }, 300);
    }

    function showPrev() {
        changeImageWithFade((currentIndex - 1 + images.length) % images.length);
    }

    function showNext() {
        changeImageWithFade((currentIndex + 1) % images.length);
    }

    // Attach events to gallery items
    galleryItems.forEach((item, index) => {
        item.addEventListener('click', () => {
            openLightbox(index);
        });
    });

    closeBtn.addEventListener('click', closeLightbox);
    overlay.addEventListener('click', closeLightbox);
    prevBtn.addEventListener('click', showPrev);
    nextBtn.addEventListener('click', showNext);

    // Keyboard navigation
    document.addEventListener('keydown', (e) => {
        if (!lightbox.classList.contains('active')) return;
        if (e.key === 'Escape') closeLightbox();
        if (e.key === 'ArrowLeft') showPrev();
        if (e.key === 'ArrowRight') showNext();
    });
});
