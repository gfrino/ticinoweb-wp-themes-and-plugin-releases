<?php
/**
 * Template Name: Deposito Mobili
 */

get_header();
?>

<main id="primary" class="site-main page-deposito">
    <?php while ( have_posts() ) : the_post(); ?>
    
    <!-- Hero Section -->
    <section class="page-hero">
        <div class="container text-center">
            <h1 class="page-title"><?php the_title(); ?></h1>
            <p class="page-hero-subtitle">Spazi sicuri, asciutti e videosorvegliati 24 ore su 24 per custodire i tuoi mobili e oggetti personali con la massima cura.</p>
        </div>
    </section>

    <!-- Intro Content (From CMS) -->
    <section class="deposito-intro section-padding" style="padding: 70px 0 40px;">
        <div class="container text-center">
            <div class="entry-content" style="font-size: 1.2rem; line-height: 1.8; color: #444; max-width: 850px; margin: 0 auto;">
                <?php the_content(); ?>
            </div>
        </div>
    </section>

    <!-- Deposito Features Grid -->
    <section class="deposito-features section-padding" style="padding: 40px 0 80px; background-color: #f8f9fa;">
        <div class="container">
            <div style="text-align: center; margin-bottom: 60px;">
                <h2 style="font-size: 2.5rem; color: var(--color-secondary); margin-bottom: 15px;">I Vantaggi del Nostro Deposito</h2>
                <div style="width: 80px; height: 4px; background: var(--color-primary); margin: 0 auto;"></div>
            </div>
            
            <div class="features-grid" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 30px;">
                
                <!-- Feature 1 -->
                <div class="feature-box" style="background: #fff; padding: 40px 30px; border-radius: 12px; box-shadow: 0 10px 30px rgba(0,0,0,0.05); text-align: center;">
                    <div style="width: 70px; height: 70px; background: rgba(255, 94, 20, 0.1); border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 20px; color: var(--color-primary);">
                        <svg width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path></svg>
                    </div>
                    <h3 style="font-size: 1.5rem; color: var(--color-secondary); margin-bottom: 15px;">Sicurezza Totale</h3>
                    <p style="color: #666; font-size: 1.05rem; line-height: 1.6;">Impianto di allarme all'avanguardia e videosorveglianza continua H24 per la massima tranquillità.</p>
                </div>

                <!-- Feature 2 -->
                <div class="feature-box" style="background: #fff; padding: 40px 30px; border-radius: 12px; box-shadow: 0 10px 30px rgba(0,0,0,0.05); text-align: center;">
                    <div style="width: 70px; height: 70px; background: rgba(255, 94, 20, 0.1); border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 20px; color: var(--color-primary);">
                        <svg width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 14.76V3.5a2.5 2.5 0 0 0-5 0v11.26a4.5 4.5 0 1 0 5 0z"></path></svg>
                    </div>
                    <h3 style="font-size: 1.5rem; color: var(--color-secondary); margin-bottom: 15px;">Ambienti Climatizzati</h3>
                    <p style="color: #666; font-size: 1.05rem; line-height: 1.6;">Spazi asciutti, privi di muffe o umidità e a temperatura controllata per preservare arredi e documenti.</p>
                </div>

                <!-- Feature 3 -->
                <div class="feature-box" style="background: #fff; padding: 40px 30px; border-radius: 12px; box-shadow: 0 10px 30px rgba(0,0,0,0.05); text-align: center;">
                    <div style="width: 70px; height: 70px; background: rgba(255, 94, 20, 0.1); border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 20px; color: var(--color-primary);">
                        <svg width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line></svg>
                    </div>
                    <h3 style="font-size: 1.5rem; color: var(--color-secondary); margin-bottom: 15px;">Affitti Flessibili</h3>
                    <p style="color: #666; font-size: 1.05rem; line-height: 1.6;">Nessun vincolo a lungo termine. Scegli tu la durata del deposito: settimanale, mensile o annuale.</p>
                </div>

            </div>
        </div>
    </section>

    <!-- Deposito Image Showcase & Text -->
    <section class="deposito-showcase section-padding" style="padding: 80px 0;">
        <div class="container">
            <div style="display: flex; align-items: center; gap: 60px; flex-wrap: wrap;">
                
                <div class="showcase-content" style="flex: 1; min-width: 300px;">
                    <span style="display: inline-block; padding: 5px 15px; background: rgba(255,94,20,0.1); color: var(--color-primary); border-radius: 20px; font-weight: 600; font-size: 0.9rem; margin-bottom: 15px; text-transform: uppercase;">La tua roba al sicuro</span>
                    <h2 style="font-size: 2.8rem; color: var(--color-secondary); margin-bottom: 25px; line-height: 1.2;">Come funziona il nostro servizio di custodia?</h2>
                    <p style="font-size: 1.15rem; color: #555; margin-bottom: 20px; line-height: 1.7;">È semplicissimo. Il nostro team di professionisti può occuparsi dell'imballaggio accurato dei tuoi mobili direttamente a casa tua, garantendo protezione totale contro urti e polvere.</p>
                    <p style="font-size: 1.15rem; color: #555; margin-bottom: 30px; line-height: 1.7;">Successivamente ritiriamo tutto e lo stiviamo in appositi moduli riservati all'interno dei nostri capannoni strutturati appositamente per ospitare arredi di qualsiasi tipo per tutto il tempo necessario.</p>
                    
                    <ul style="list-style: none; padding: 0; margin-bottom: 40px;">
                        <li style="margin-bottom: 12px; font-size: 1.1rem; color: #444; display: flex; align-items: center; gap: 12px;">
                            <span style="color: var(--color-primary);"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6L9 17l-5-5"></path></svg></span> Scatole resistenti fornite su richiesta
                        </li>
                        <li style="margin-bottom: 12px; font-size: 1.1rem; color: #444; display: flex; align-items: center; gap: 12px;">
                            <span style="color: var(--color-primary);"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6L9 17l-5-5"></path></svg></span> Assicurazione completa sui beni depositati
                        </li>
                        <li style="margin-bottom: 12px; font-size: 1.1rem; color: #444; display: flex; align-items: center; gap: 12px;">
                            <span style="color: var(--color-primary);"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6L9 17l-5-5"></path></svg></span> Riconsegna a domicilio quando preferisci
                        </li>
                    </ul>
                    
                    <a href="<?php echo home_url('/richiedi-il-tuo-preventivo'); ?>" class="btn btn-primary" style="padding: 14px 32px; font-size: 1.1rem; border-radius: 8px;">Prenota uno Spazio</a>
                </div>

                <div class="showcase-images" style="flex: 1; min-width: 300px; position: relative;">
                    <!-- Main Image -->
                    <img src="<?php echo wp_make_link_relative(wp_upload_dir()['baseurl']) . '/2026/03/imgi_17_deposito.jpg'; ?>" alt="Magazzino Deposito Mobili Morabito Trasporti" style="width: 100%; border-radius: 12px; box-shadow: 0 15px 35px rgba(0,0,0,0.15); display: block;">
                    
                    <!-- Decorative Element -->
                    <div class="secure-space-box" style="position: absolute; bottom: -20px; right: -20px; background: var(--color-primary); color: white; padding: 25px 30px; border-radius: 12px; box-shadow: 0 10px 25px rgba(255,94,20,0.3); z-index: 2; transform: scale(1); transition: transform 0.3s ease;">
                        <div style="font-size: 2.5rem; font-weight: 800; line-height: 1;"><span id="secure-counter">0</span>%</div>
                        <div style="font-size: 1rem; font-weight: 600; text-transform: uppercase; letter-spacing: 1px;">Spazio Sicuro</div>
                    </div>
                </div>

            </div>
        </div>
    </section>

    <!-- Call to Action Finale -->
    <section class="deposito-cta section-padding text-center" style="background: url('<?php echo wp_make_link_relative(wp_upload_dir()['baseurl']) . '/2026/03/imgi_17_deposito.jpg'; ?>') center/cover fixed; position: relative; padding: 120px 0; text-align: center;">
        <div style="position: absolute; top:0; left:0; right:0; bottom:0; background: linear-gradient(135deg, rgba(17,17,17,0.9), rgba(26,29,31,0.8));"></div>
        <div class="container" style="position: relative; z-index: 2;">
            <svg style="margin-bottom: 20px; color: var(--color-primary);" xmlns="http://www.w3.org/2000/svg" width="60" height="60" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>
            <h2 style="color: white; font-size: 3rem; margin-bottom: 20px; font-weight: 700;">Hai bisogno di spazio extra ora?</h2>
            <p style="color: #ddd; font-size: 1.25rem; max-width: 700px; margin: 0 auto 40px; line-height: 1.6;">Contattaci per scoprire i nostri prezzi vantaggiosi e riservare subito i metri cubi necessari per le tue esigenze di deposito a breve o lungo termine.</p>
            <a href="<?php echo home_url('/richiedi-il-tuo-preventivo'); ?>" class="btn btn-primary" style="font-size: 1.15rem; font-weight: 600; padding: 16px 45px; border-radius: 50px; text-decoration: none; transition: transform 0.3s; box-shadow: 0 10px 20px rgba(255,94,20,0.3);">Richiedi Tariffe Deposito</a>
        </div>
    </section>

    <style>
        .page-deposito .feature-box:hover {
            transform: translateY(-10px);
            box-shadow: 0 15px 40px rgba(0,0,0,0.1) !important;
        }
        @keyframes pulse-box-shadow {
            0% { transform: scale(1); box-shadow: 0 0 0 0 rgba(255,94,20,0.7); }
            50% { transform: scale(1.05); box-shadow: 0 0 0 15px rgba(255,94,20,0); }
            100% { transform: scale(1); box-shadow: 0 0 0 0 rgba(255,94,20,0); }
        }
        .pulse-active {
            animation: pulse-box-shadow 1.2s cubic-bezier(0.2, 0.8, 0.2, 1) 1;
        }
        
        @media(max-width: 991px) {
            .page-deposito .page-title {
                font-size: 2.8rem !important;
            }
            .page-deposito .showcase-content h2 {
                font-size: 2.2rem !important;
            }
        }
        @media(max-width: 768px) {
            .page-deposito .page-hero {
                padding: 100px 0 60px !important;
            }
            .page-deposito .page-title {
                font-size: 2.2rem !important;
            }
            .page-deposito .deposito-cta h2 {
                font-size: 2rem !important;
            }
        }
    </style>

    <script>
    document.addEventListener("DOMContentLoaded", function() {
        const box = document.querySelector('.secure-space-box');
        const counter = document.getElementById('secure-counter');
        if(!box || !counter) return;

        let hasRun = false;
        const observer = new IntersectionObserver((entries) => {
            if(entries[0].isIntersecting && !hasRun) {
                hasRun = true;
                let current = 0;
                const target = 100;
                const duration = 1500; // 1.5 seconds
                const increment = target / (duration / 16);

                const updateCounter = () => {
                    current += increment;
                    if(current < target) {
                        counter.innerText = Math.floor(current);
                        requestAnimationFrame(updateCounter);
                    } else {
                        counter.innerText = target;
                        box.classList.add('pulse-active');
                    }
                };
                
                // delay slightly to let fade-in-up finish
                setTimeout(updateCounter, 500);
            }
        }, { threshold: 0.5 });
        
        observer.observe(box);
    });
    </script>

    <?php endwhile; ?>
</main>

<?php get_footer(); ?>
