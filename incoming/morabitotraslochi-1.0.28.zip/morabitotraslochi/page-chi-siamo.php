<?php
/**
 * Template Name: Chi Siamo
 */

get_header();
?>

<main id="primary" class="site-main page-chi-siamo">
    <?php while ( have_posts() ) : the_post(); ?>
    
    <!-- Hero Section -->
    <section class="page-hero">
        <div class="container text-center">
            <h1 class="page-title"><?php the_title(); ?></h1>
            <p class="page-hero-subtitle">Scopri chi siamo, la nostra storia e l'impegno quotidiano per far viaggiare in sicurezza i tuoi beni, in Ticino e oltre.</p>
        </div>
    </section>

    <!-- Main Content -->
    <section class="about-content section-padding" style="padding: 60px 0;">
        <div class="container" style="max-width: 900px;">
            <div class="about-vertical-layout" style="display: flex; flex-direction: column; gap: 40px;">
                
                <div class="about-image" style="text-align: center;">
                    <img src="<?php echo wp_make_link_relative(wp_upload_dir()['baseurl']) . '/2026/03/morabito-logo.svg'; ?>" alt="Morabito Traslochi" style="max-width: 350px; height: auto; display: block; margin: 0 auto;">
                </div>

                <div class="about-wrapper">
                    <h2 class="static-title" style="margin-bottom: 25px; color: var(--color-primary); font-size: 2.8rem; font-weight: 800; line-height: 1.2;">Chi è Morabito Traslochi</h2>
                    <div class="entry-content about-text" style="font-size: 1.15rem; line-height: 1.85; color: #444;">
                        <?php 
                        // Raw text exactly as provided by the user
                        $raw_text = "Ticino Transporter Sagl è un’azienda specializzata in traslochi, sgomberi e trasporti in tutto il Ticino. Da anni aiutiamo privati e aziende a spostare mobili, oggetti e attrezzature con un servizio organizzato, rapido e affidabile.

Ogni trasloco è diverso: per questo valutiamo sempre con attenzione le esigenze del cliente prima di iniziare il lavoro. Il nostro obiettivo è offrire un servizio semplice, efficiente e senza stress, curando ogni fase del trasporto con la massima attenzione.

Mettiamo a disposizione mezzi adeguati, personale esperto e attrezzature professionali, come il noleggio di scale per traslochi, per rendere anche le operazioni più complesse rapide e sicure.

Che si tratti di un appartamento, di un ufficio o di uno sgombero di locali, lavoriamo con serietà e precisione per garantire sempre un risultato impeccabile.

Per qualsiasi informazione o per richiedere un preventivo gratuito e senza impegno, non esitare a contattarci. Saremo felici di aiutarti a organizzare il tuo prossimo trasloco.";

                        // Output the exact text without modifying the legal company name
                        echo wp_kses_post(wpautop($raw_text));
                        ?>
                    </div>
                </div>

            </div>
        </div>
    </section>

    <!-- Values / Stats -->
    <section class="about-stats section-padding" style="background-color: #f9f9f9; padding: 60px 0;">
        <div class="container">
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 30px; text-align: center;">
                <div class="stat-box" style="background: #fff; padding: 40px 20px; border-radius: 10px; box-shadow: 0 5px 20px rgba(0,0,0,0.05);">
                    <h3 class="slot-counter" data-target="10" data-suffix="+" style="font-size: 3.5rem; color: var(--color-primary); margin-bottom: 10px; font-weight: 700; transition: filter 0.3s ease;">0+</h3>
                    <p style="font-size: 1.1rem; font-weight: 600; color: var(--color-secondary); margin: 0;">Anni di Esperienza</p>
                </div>
                <div class="stat-box" style="background: #fff; padding: 40px 20px; border-radius: 10px; box-shadow: 0 5px 20px rgba(0,0,0,0.05);">
                    <h3 class="slot-counter" data-target="1000" data-suffix="+" style="font-size: 3.5rem; color: var(--color-primary); margin-bottom: 10px; font-weight: 700; transition: filter 0.3s ease;">0+</h3>
                    <p style="font-size: 1.1rem; font-weight: 600; color: var(--color-secondary); margin: 0;">Traslochi Completati</p>
                </div>
                <div class="stat-box" style="background: #fff; padding: 40px 20px; border-radius: 10px; box-shadow: 0 5px 20px rgba(0,0,0,0.05);">
                    <h3 class="slot-counter" data-target="100" data-suffix="%" style="font-size: 3.5rem; color: var(--color-primary); margin-bottom: 10px; font-weight: 700; transition: filter 0.3s ease;">0%</h3>
                    <p style="font-size: 1.1rem; font-weight: 600; color: var(--color-secondary); margin: 0;">Clienti Soddisfatti</p>
                </div>
            </div>
        </div>
    </section>

    <script>
    document.addEventListener("DOMContentLoaded", function() {
        const counters = document.querySelectorAll('.slot-counter');
        const observerOptions = { threshold: 0.5 };
        
        const observer = new IntersectionObserver((entries, observer) => {
            entries.forEach(entry => {
                if(entry.isIntersecting) {
                    startSlotAnimation(entry.target);
                    observer.unobserve(entry.target);
                }
            });
        }, observerOptions);
        
        counters.forEach(counter => observer.observe(counter));
        
        function startSlotAnimation(el) {
            const target = parseInt(el.getAttribute('data-target'), 10);
            const suffix = el.getAttribute('data-suffix');
            const duration = 2000; // 2 seconds
            const frameRate = 1000 / 60;
            const totalFrames = duration / frameRate;
            let frame = 0;
            
            const counterInterval = setInterval(() => {
                frame++;
                // Curva ease-out per rallentare verso la fine
                const progress = easeOutCubic(frame / totalFrames);
                const currentVal = Math.floor(target * progress);
                
                el.innerText = currentVal + suffix;
                
                if(frame >= totalFrames) {
                    clearInterval(counterInterval);
                    el.innerText = target + suffix;
                }
            }, frameRate);
        }
        
        function easeOutCubic(x) {
            return 1 - Math.pow(1 - x, 3);
        }
    });
    </script>

    <!-- Call to Action -->
    <section class="about-cta section-padding text-center" style="background: url('<?php echo wp_make_link_relative(wp_upload_dir()['baseurl']) . '/2026/03/asian-couple-check-while-unloading-boxes-and-furni-2026-01-07-23-33-15-utc-scaled.jpg'; ?>') center/cover fixed; position: relative; padding: 120px 0; text-align: center;">
        <div style="position: absolute; top:0; left:0; right:0; bottom:0; background: linear-gradient(135deg, rgba(17,17,17,0.9), rgba(26,29,31,0.8));"></div>
        <div class="container" style="position: relative; z-index: 2;">
            <svg style="margin-bottom: 20px; color: var(--color-primary);" xmlns="http://www.w3.org/2000/svg" width="60" height="60" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>
            <h2 style="color: white; font-size: 3rem; margin-bottom: 20px; font-weight: 700;">Affidati a dei veri professionisti</h2>
            <p style="color: #ddd; font-size: 1.25rem; max-width: 700px; margin: 0 auto 40px; line-height: 1.6;">Siamo pronti ad assisterti nel tuo prossimo passo, con tutta l'energia e i mezzi necessari.</p>
            <a href="<?php echo home_url('/richiedi-il-tuo-preventivo'); ?>" class="btn btn-primary" style="font-size: 1.15rem; font-weight: 600; padding: 16px 45px; border-radius: 50px; text-decoration: none; transition: transform 0.3s; box-shadow: 0 10px 20px rgba(255,94,20,0.3);">Richiedi Preventivo Gratuito</a>
        </div>
    </section>

    <style>
        /* Aggiunte responsive base in-file class per page-chi-siamo */
        @media(max-width: 768px) {
            .page-chi-siamo .about-grid {
                grid-template-columns: 1fr !important;
                gap: 30px !important;
            }
            .page-chi-siamo .page-title {
                font-size: 2.2rem !important;
            }
            .page-chi-siamo .about-cta h2 {
                font-size: 2rem !important;
            }
        }
    </style>

    <?php endwhile; ?>
</main>

<?php
get_footer();
?>
