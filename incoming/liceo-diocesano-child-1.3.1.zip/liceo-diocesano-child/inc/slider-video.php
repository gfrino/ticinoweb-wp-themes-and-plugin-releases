<?php
/**
 * Modalità della testata della home: slider di foto oppure un video.
 *
 * Il parent (ticinoWEB CMS → Slider & Partner) gestisce solo lo slider di foto. Qui si aggiunge un interruttore
 * «Slider di foto / Video» e, per il video, il file MP4 o WebM scelto dalla Libreria media. In modalità video la
 * testata mostra il video con titolo, descrizione e pulsante della Slide 1; la foto della Slide 1 resta come
 * immagine di attesa. I campi si salvano con il solito pulsante «Salva» del CMS.
 *
 * @package liceo-diocesano-child
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

function liceo_diocesano_hero_video_url() {
    return 'video' === get_option( 'ld_hero_mode', 'slider' ) ? (string) get_option( 'ld_hero_video', '' ) : '';
}

function liceo_diocesano_register_hero_settings() {
    register_setting( 'ticinoweb_settings_group', 'ld_hero_mode', array(
        'type'              => 'string',
        'sanitize_callback' => function ( $v ) {
            return 'video' === $v ? 'video' : 'slider';
        },
        'default'           => 'slider',
    ) );
    register_setting( 'ticinoweb_settings_group', 'ld_hero_video', array(
        'type'              => 'string',
        'sanitize_callback' => 'liceo_diocesano_sanitize_video_url',
        'default'           => '',
    ) );
}
add_action( 'admin_init', 'liceo_diocesano_register_hero_settings' );

function liceo_diocesano_sanitize_video_url( $value ) {
    $url = esc_url_raw( (string) $value );
    if ( '' === $url ) {
        return '';
    }
    $type = wp_check_filetype( wp_parse_url( $url, PHP_URL_PATH ) );
    return in_array( $type['ext'], array( 'mp4', 'webm' ), true ) ? $url : '';
}

function liceo_diocesano_admin_hero_mode( $hook ) {
    if ( false === strpos( (string) $hook, 'ticinoweb-cms' ) ) {
        return;
    }
    wp_enqueue_media();
    $file = get_stylesheet_directory() . '/assets/js/admin-slider-video.js';
    wp_enqueue_script( 'liceo-slider-video-admin', get_stylesheet_directory_uri() . '/assets/js/admin-slider-video.js', array( 'jquery' ), filemtime( $file ), true );
    wp_localize_script( 'liceo-slider-video-admin', 'liceoHero', array(
        'mode'  => get_option( 'ld_hero_mode', 'slider' ),
        'video' => (string) get_option( 'ld_hero_video', '' ),
        'i18n'  => array(
            'modeLabel' => __( 'Testata della home', 'liceo-diocesano-child' ),
            'slider'    => __( 'Slider di foto', 'liceo-diocesano-child' ),
            'video'     => __( 'Video', 'liceo-diocesano-child' ),
            'file'      => __( 'File video', 'liceo-diocesano-child' ),
            'choose'    => __( 'Scegli video', 'liceo-diocesano-child' ),
            'remove'    => __( 'Rimuovi video', 'liceo-diocesano-child' ),
            'title'     => __( 'Scegli un video MP4 o WebM', 'liceo-diocesano-child' ),
            'none'      => __( 'Nessun video scelto: finché manca, si vede la foto della Slide 1.', 'liceo-diocesano-child' ),
            'hint'      => __( 'Parte da solo, senza audio e in loop. Meglio MP4 (H.264) sotto i 10 MB. Titolo, descrizione e pulsante sono quelli della Slide 1, la cui foto resta come immagine di attesa.', 'liceo-diocesano-child' ),
        ),
    ) );
}
add_action( 'admin_enqueue_scripts', 'liceo_diocesano_admin_hero_mode' );

// Sul sito, in modalità video il parent deve stampare una sola slide (la prima).
function liceo_diocesano_single_slide( $pre ) {
    if ( is_admin() || ! liceo_diocesano_hero_video_url() ) {
        return $pre;
    }
    return 1;
}
add_filter( 'pre_option_ticinoweb_slider_count', 'liceo_diocesano_single_slide' );

function liceo_diocesano_hero_body_class( $classes ) {
    if ( is_front_page() && liceo_diocesano_hero_video_url() ) {
        $classes[] = 'ld-hero-video';
    }
    return $classes;
}
add_filter( 'body_class', 'liceo_diocesano_hero_body_class' );

function liceo_diocesano_front_hero_video() {
    $video = liceo_diocesano_hero_video_url();
    if ( ! is_front_page() || ! $video ) {
        return;
    }
    $file = get_stylesheet_directory() . '/assets/js/slider-video.js';
    wp_enqueue_script( 'liceo-slider-video', get_stylesheet_directory_uri() . '/assets/js/slider-video.js', array(), filemtime( $file ), true );
    wp_localize_script( 'liceo-slider-video', 'liceoHero', array( 'video' => esc_url_raw( $video ) ) );
}
add_action( 'wp_enqueue_scripts', 'liceo_diocesano_front_hero_video', 30 );
