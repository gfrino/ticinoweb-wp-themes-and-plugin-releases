( function ( $ ) {
    var cfg = window.liceoHero || { i18n: {} };
    var t = cfg.i18n;

    $( function () {
        var $count = $( '#ticinoweb_slider_count' );
        if ( ! $count.length ) {
            return;
        }
        var $table = $count.closest( 'table' );
        var $box = $(
            '<tr class="ld-hero-mode-row"><th scope="row"><label></label></th><td>' +
            '<label style="margin-right:1.5rem"><input type="radio" name="ld_hero_mode" value="slider"> <span class="ld-m-slider"></span></label>' +
            '<label><input type="radio" name="ld_hero_mode" value="video"> <span class="ld-m-video"></span></label>' +
            '<div class="ld-video-panel" style="margin-top:12px">' +
            '<strong class="ld-m-file"></strong><br>' +
            '<input type="text" class="regular-text ld-video-url" name="ld_hero_video" readonly> ' +
            '<button type="button" class="button button-secondary ld-video-choose"></button> ' +
            '<button type="button" class="button-link-delete ld-video-remove"></button>' +
            '<p class="description ld-video-status"></p><p class="description ld-video-hint"></p>' +
            '</div></td></tr>'
        );
        $box.find( 'th label' ).text( t.modeLabel );
        $box.find( '.ld-m-slider' ).text( t.slider );
        $box.find( '.ld-m-video' ).text( t.video );
        $box.find( '.ld-m-file' ).text( t.file );
        $box.find( '.ld-video-choose' ).text( t.choose );
        $box.find( '.ld-video-remove' ).text( t.remove );
        $box.find( '.ld-video-hint' ).text( t.hint );
        $box.find( '.ld-video-url' ).val( cfg.video || '' );
        $box.find( 'input[name="ld_hero_mode"][value="' + ( cfg.mode === 'video' ? 'video' : 'slider' ) + '"]' ).prop( 'checked', true );
        $table.find( 'tr' ).first().before( $box );

        function refresh() {
            var video = $box.find( 'input[name="ld_hero_mode"]:checked' ).val() === 'video';
            var v = $box.find( '.ld-video-url' ).val();
            $box.find( '.ld-video-panel' ).toggle( video );
            $box.find( '.ld-video-remove' ).toggle( !! v );
            $box.find( '.ld-video-status' ).text( v ? v.split( '/' ).pop() : t.none );
            // In modalità video conta solo la Slide 1: le altre e il numero di slide si nascondono.
            $count.closest( 'tr' ).toggle( ! video );
            $( '#slider-items-container .slider-item' ).each( function ( i ) {
                $( this ).toggle( ! video || i === 0 );
            } );
        }

        $box.on( 'change', 'input[name="ld_hero_mode"]', refresh );
        $box.on( 'click', '.ld-video-choose', function () {
            var frame = wp.media( { title: t.title, library: { type: 'video' }, multiple: false } );
            frame.on( 'select', function () {
                $box.find( '.ld-video-url' ).val( frame.state().get( 'selection' ).first().toJSON().url );
                refresh();
            } );
            frame.open();
        } );
        $box.on( 'click', '.ld-video-remove', function () {
            $box.find( '.ld-video-url' ).val( '' );
            refresh();
        } );
        refresh();
    } );
} )( jQuery );
