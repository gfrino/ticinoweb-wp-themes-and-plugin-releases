<?php
/**
 * Menù combinati dell'app (v2.13.0, menù e componenti configurabili dalla 2.14.0)
 *
 * When the cart holds a poké and no drink/dessert, the app offers a menu
 * before checkout ("Crea Menù": poké + acqua / + dessert / + acqua e dessert,
 * each a fixed surcharge) and, if the customer skips it, a quick "Aggiungi una
 * bibita" page. Everything shown there is managed here:
 *
 *  - Admin page  Gestione App → Menù combinati (brand hub only, like Metodi di
 *                Pagamento). One configuration for every sede: products are
 *                chosen BY NAME, so each sede shows the ones it actually sells.
 *  - Storage     NETWORK option `ard_app_combo_menu`.
 *  - REST        GET mobile-admin/v1/combo-menu?site=<sede host>: the config
 *                with the products resolved in that sede (id, price, image),
 *                plus the category ids the app needs to recognise a poké and
 *                a drink/dessert already in the cart.
 *  - Base        The menus are offered next to the products of the "base"
 *                categories (2.16.0, `base_categories`, chosen by name like the
 *                products). Empty = automatic: the categories whose name
 *                mentions poké, exactly as before 2.16.0. The REST field keeps
 *                the name `poke_category_ids` because the apps read it.
 */

defined( 'ABSPATH' ) || exit;

const ARD_COMBO_OPTION = 'ard_app_combo_menu';

/** Icons the admin can give a component (shown in the app next to the menu name). */
function ARD_combo_emojis() {
	return array( '💧', '🥤', '🧃', '🍵', '☕', '🍺', '🍷', '🍡', '🍰', '🧁', '🍨', '🍦', '🍩', '🍪', '🍫', '🥟', '🍤', '🍟', '🥗', '🍙', '🥢', '🍕', '🍔', '🍽️' );
}

/** Category name as customers see it: without the ordering number some shops put in front («15. Bibite» → «Bibite»). */
function ARD_combo_section_label( $name ) {
	$label = trim( preg_replace( '/^\s*\d+\s*[.)\-:]\s+/u', '', (string) $name ) );
	return '' !== $label ? $label : trim( (string) $name );
}

/** Icon of an Upsell section when the admin has not chosen one (from the category name). */
function ARD_combo_default_section_emoji( $name ) {
	$n = ARD_combo_name_key( $name );
	$map = array(
		'/birr|beer/'                                   => '🍺',
		'/vin[io]|wine/'                                => '🍷',
		'/caff|coffee/'                                 => '☕',
		'/bibit|bevand|drink|bere|soda|acqua|succh|the |te /' => '🥤',
		'/gelat|ice cream/'                             => '🍦',
		'/dess|dolc|torta|cheesecake|mochi|sweet/'      => '🍰',
		'/antipast|starter|snack|fritt/'                => '🍟',
	);
	foreach ( $map as $re => $emoji ) {
		if ( preg_match( $re, $n . ' ' ) ) {
			return $emoji;
		}
	}
	return '🍽️';
}

/**
 * Defaults = the first version of the feature: components "Acqua" and
 * "Dessert", menus Pokè + Acqua / + Dessert / + Acqua + Dessert.
 * Keys `water` and `dessert` are kept: the app 3.2.0 OTA reads them.
 */
function ARD_combo_defaults() {
	return array(
		'enabled'         => false,
		'base_categories' => array(), // category name keys; empty = automatic (poké)
		'groups'         => array(
			array( 'key' => 'water', 'label' => 'Acqua', 'emoji' => '💧', 'products' => array() ),
			array( 'key' => 'dessert', 'label' => 'Dessert', 'emoji' => '🍡', 'products' => array() ),
		),
		'menus'          => array(
			array( 'key' => 'water', 'label' => 'Pokè + Acqua', 'price' => 1.0, 'enabled' => true, 'groups' => array( 'water' ) ),
			array( 'key' => 'dessert', 'label' => 'Pokè + Dessert', 'price' => 3.0, 'enabled' => true, 'groups' => array( 'dessert' ) ),
			array( 'key' => 'water_dessert', 'label' => 'Pokè + Acqua + Dessert', 'price' => 4.0, 'enabled' => true, 'groups' => array( 'water', 'dessert' ) ),
		),
		'drinks_enabled' => false,
		'drinks'         => array(),
		// Title/subtitle of the "Aggiungi una bibita" page, per app language (2.17.0).
		// Empty = the app's and site's standard text, as before.
		'drinks_texts'   => array(),
		// Icon of each Upsell section, by category name key (2.18.0). Missing = ARD_combo_default_section_emoji().
		'drinks_icons'   => array(),
	);
}

/** Languages of the apps, with the standard texts of the drinks page (the app's own translations). */
function ARD_combo_text_langs() {
	return array(
		'it' => array( 'label' => 'Italiano', 'title' => 'Aggiungi una bibita?', 'subtitle' => 'Un tocco ed è nel tuo ordine' ),
		'en' => array( 'label' => 'English', 'title' => 'Add a drink?', 'subtitle' => 'One tap and it is in your order' ),
		'de' => array( 'label' => 'Deutsch', 'title' => 'Ein Getränk dazu?', 'subtitle' => 'Ein Tipp und es ist in deiner Bestellung' ),
		'fr' => array( 'label' => 'Français', 'title' => 'Ajouter une boisson ?', 'subtitle' => "Un geste et c'est dans ta commande" ),
	);
}

/** [ category name key => emoji ], only known emojis. */
function ARD_combo_clean_icons( $icons ) {
	$out = array();
	foreach ( array_slice( (array) $icons, 0, 40, true ) as $key => $emoji ) {
		$key = ARD_combo_name_key( sanitize_text_field( (string) $key ) );
		if ( '' !== $key && in_array( $emoji, ARD_combo_emojis(), true ) ) {
			$out[ $key ] = $emoji;
		}
	}
	return $out;
}

/** [ 'title' => [lang => text], 'subtitle' => [lang => text] ], only filled languages. */
function ARD_combo_clean_texts( $texts ) {
	$out = array( 'title' => array(), 'subtitle' => array() );
	foreach ( array( 'title' => 60, 'subtitle' => 90 ) as $field => $max ) {
		foreach ( array_keys( ARD_combo_text_langs() ) as $lang ) {
			$value = trim( sanitize_text_field( (string) ( $texts[ $field ][ $lang ] ?? '' ) ) );
			if ( '' !== $value ) {
				$out[ $field ][ $lang ] = mb_substr( $value, 0, $max );
			}
		}
	}
	return $out;
}

function ARD_combo_clean_names( $names ) {
	return array_values( array_unique( array_filter( array_map( 'strval', (array) $names ) ) ) );
}

/** Saved settings in the current shape (2.13.x settings are migrated on read). */
function ARD_combo_settings() {
	$saved    = (array) get_site_option( ARD_COMBO_OPTION, array() );
	$defaults = ARD_combo_defaults();

	if ( ! isset( $saved['groups'] ) && ( isset( $saved['waters'] ) || isset( $saved['offers'] ) ) ) {
		// 2.13.x: fixed offers + waters/desserts lists.
		$groups = $defaults['groups'];
		$groups[0]['products'] = ARD_combo_clean_names( $saved['waters'] ?? array() );
		$groups[1]['products'] = ARD_combo_clean_names( $saved['desserts'] ?? array() );
		$menus = $defaults['menus'];
		foreach ( $menus as $i => $menu ) {
			$old = (array) ( $saved['offers'][ $menu['key'] ] ?? array() );
			if ( isset( $old['price'] ) ) {
				$menus[ $i ]['price'] = (float) $old['price'];
			}
			if ( isset( $old['enabled'] ) ) {
				$menus[ $i ]['enabled'] = (bool) $old['enabled'];
			}
		}
		$saved['groups'] = $groups;
		$saved['menus']  = $menus;
	}

	$settings = array_merge( $defaults, array_intersect_key( $saved, $defaults ) );
	$settings['enabled']        = (bool) $settings['enabled'];
	$settings['drinks_enabled'] = (bool) $settings['drinks_enabled'];
	$settings['drinks']         = ARD_combo_clean_names( $settings['drinks'] );
	$settings['base_categories'] = ARD_combo_clean_names( $settings['base_categories'] );
	$settings['drinks_texts']    = ARD_combo_clean_texts( $settings['drinks_texts'] );
	$settings['drinks_icons']    = ARD_combo_clean_icons( $settings['drinks_icons'] );
	$settings['groups']         = array_values( array_filter( (array) $settings['groups'], 'is_array' ) );
	$settings['menus']          = array_values( array_filter( (array) $settings['menus'], 'is_array' ) );
	return $settings;
}

/**
 * Validates the editor state posted by the admin page. Unknown products,
 * components and empty names are dropped; keys are stable so carts already
 * holding a menu keep working.
 */
function ARD_combo_sanitize_state( array $state, array $catalog, array $categories = array() ) {
	$out = array(
		'enabled'         => ! empty( $state['enabled'] ),
		'base_categories' => array(),
		'drinks_enabled' => ! empty( $state['drinks_enabled'] ),
		'groups'         => array(),
		'menus'          => array(),
		'drinks'         => array(),
		'drinks_texts'   => ARD_combo_clean_texts( (array) ( $state['drinks_texts'] ?? array() ) ),
		'drinks_icons'   => ARD_combo_clean_icons( (array) ( $state['drinks_icons'] ?? array() ) ),
	);
	$keep_products = static function ( $names ) use ( $catalog ) {
		$keep = array();
		foreach ( (array) $names as $name ) {
			$name = sanitize_text_field( (string) $name );
			if ( isset( $catalog[ $name ] ) ) {
				$keep[] = $name;
			}
		}
		return array_values( array_unique( $keep ) );
	};

	$emojis = ARD_combo_emojis();
	$used   = array();
	foreach ( array_slice( (array) ( $state['groups'] ?? array() ), 0, 8 ) as $group ) {
		$label = trim( sanitize_text_field( (string) ( $group['label'] ?? '' ) ) );
		if ( '' === $label ) {
			continue;
		}
		$key = sanitize_key( (string) ( $group['key'] ?? '' ) );
		if ( '' === $key || isset( $used[ $key ] ) ) {
			$key = 'g' . substr( md5( $label . wp_rand() ), 0, 8 );
		}
		$used[ $key ]    = true;
		$out['groups'][] = array(
			'key'      => $key,
			'label'    => mb_substr( $label, 0, 40 ),
			'emoji'    => in_array( $group['emoji'] ?? '', $emojis, true ) ? $group['emoji'] : '',
			'products' => $keep_products( $group['products'] ?? array() ),
		);
	}

	$group_keys = wp_list_pluck( $out['groups'], 'key' );
	$used       = array();
	foreach ( array_slice( (array) ( $state['menus'] ?? array() ), 0, 10 ) as $menu ) {
		$label  = trim( sanitize_text_field( (string) ( $menu['label'] ?? '' ) ) );
		$groups = array_values( array_intersect( $group_keys, array_map( 'strval', (array) ( $menu['groups'] ?? array() ) ) ) );
		if ( '' === $label || ! $groups ) {
			continue;
		}
		$key = sanitize_key( (string) ( $menu['key'] ?? '' ) );
		if ( '' === $key || isset( $used[ $key ] ) ) {
			$key = 'm' . substr( md5( $label . wp_rand() ), 0, 8 );
		}
		$used[ $key ]   = true;
		$out['menus'][] = array(
			'key'     => $key,
			'label'   => mb_substr( $label, 0, 60 ),
			'price'   => max( 0, round( (float) str_replace( ',', '.', (string) ( $menu['price'] ?? 0 ) ), 2 ) ),
			'enabled' => ! empty( $menu['enabled'] ),
			'groups'  => $groups,
		);
	}

	$out['drinks'] = $keep_products( $state['drinks'] ?? array() );
	foreach ( array_slice( (array) ( $state['base_categories'] ?? array() ), 0, 30 ) as $cat ) {
		$cat = sanitize_text_field( (string) $cat );
		if ( isset( $categories[ $cat ] ) ) {
			$out['base_categories'][] = $cat;
		}
	}
	$out['base_categories'] = array_values( array_unique( $out['base_categories'] ) );
	return $out;
}

/** Product names are matched case- and accent-insensitively across sedi. */
function ARD_combo_name_key( $name ) {
	$name = wp_strip_all_tags( html_entity_decode( (string) $name, ENT_QUOTES, 'UTF-8' ) );
	return strtolower( remove_accents( trim( preg_replace( '/\s+/', ' ', $name ) ) ) );
}

/** blog_id for a sede host, 0 if unknown. */
function ARD_combo_blog_id( $host ) {
	if ( ! is_multisite() ) {
		return get_current_blog_id();
	}
	$site = get_site_by_path( ARD_payment_methods_normalize_host( $host ), '/' );
	return (int) apply_filters( 'ard_site_blog_id', $site ? (int) $site->blog_id : 0, ARD_payment_methods_normalize_host( $host ) );
}

/**
 * Published products of the current blog: [ name_key => data ].
 * Must run inside switch_to_blog() for a sede. Reads the tables directly: the
 * brand hub (where this runs) has no WooCommerce, so `product` and
 * `product_cat` are not registered there and the WP query API returns nothing.
 */
function ARD_combo_blog_products() {
	global $wpdb;
	$rows = $wpdb->get_results(
		"SELECT p.ID, p.post_title,
			MAX(CASE WHEN m.meta_key = '_price' THEN m.meta_value END) AS price,
			MAX(CASE WHEN m.meta_key = '_stock_status' THEN m.meta_value END) AS stock,
			MAX(CASE WHEN m.meta_key = '_thumbnail_id' THEN m.meta_value END) AS thumb
		FROM {$wpdb->posts} p
		LEFT JOIN {$wpdb->postmeta} m ON m.post_id = p.ID AND m.meta_key IN ('_price','_stock_status','_thumbnail_id')
		WHERE p.post_type = 'product' AND p.post_status = 'publish'
		GROUP BY p.ID
		ORDER BY p.menu_order, p.ID"
	);
	if ( ! $rows ) {
		return array();
	}

	$cats = array();
	foreach ( (array) $wpdb->get_results(
		"SELECT tr.object_id, t.term_id, t.name
		FROM {$wpdb->term_relationships} tr
		JOIN {$wpdb->term_taxonomy} tt ON tt.term_taxonomy_id = tr.term_taxonomy_id AND tt.taxonomy = 'product_cat'
		JOIN {$wpdb->terms} t ON t.term_id = tt.term_id"
	) as $c ) {
		$cats[ (int) $c->object_id ][] = array( 'id' => (int) $c->term_id, 'name' => html_entity_decode( $c->name, ENT_QUOTES, 'UTF-8' ) );
	}

	$products = array();
	foreach ( $rows as $row ) {
		$key = ARD_combo_name_key( $row->post_title );
		if ( '' === $key || isset( $products[ $key ] ) ) {
			continue;
		}
		$thumb = (int) $row->thumb;
		$products[ $key ] = array(
			'id'         => (int) $row->ID,
			'name'       => html_entity_decode( $row->post_title, ENT_QUOTES, 'UTF-8' ),
			'price'      => ( null === $row->price || '' === $row->price ) ? null : (float) $row->price,
			'image'      => $thumb ? (string) wp_get_attachment_image_url( $thumb, 'thumbnail' ) : '',
			'in_stock'   => 'outofstock' !== $row->stock,
			'categories' => $cats[ (int) $row->ID ] ?? array(),
		);
	}
	return $products;
}

/** product_cat terms of the current blog: [ { id, name, slug, count } ]. Runs inside switch_to_blog(), see ARD_combo_blog_products(). */
function ARD_combo_blog_categories() {
	global $wpdb;
	$out = array();
	foreach ( (array) $wpdb->get_results(
		"SELECT t.term_id, t.name, t.slug, tt.count FROM {$wpdb->terms} t
		JOIN {$wpdb->term_taxonomy} tt ON tt.term_id = t.term_id AND tt.taxonomy = 'product_cat'"
	) as $t ) {
		$out[] = array( 'id' => (int) $t->term_id, 'name' => html_entity_decode( $t->name, ENT_QUOTES, 'UTF-8' ), 'slug' => (string) $t->slug, 'count' => (int) $t->count );
	}
	return $out;
}

/** Automatic choice (and the only one before 2.16.0): the category name or slug mentions poké. */
function ARD_combo_is_auto_base_category( $name, $slug = '' ) {
	return false !== strpos( ARD_combo_name_key( $name . ' ' . $slug ), 'pok' );
}

/**
 * Ids of the base categories in the current blog: those chosen by name in
 * Menù combinati, or the poké ones when none is chosen.
 */
function ARD_combo_blog_base_categories( array $names = array() ) {
	$ids = array();
	foreach ( ARD_combo_blog_categories() as $cat ) {
		$hit = $names
			? in_array( ARD_combo_name_key( $cat['name'] ), $names, true )
			: ARD_combo_is_auto_base_category( $cat['name'], $cat['slug'] );
		if ( $hit ) {
			$ids[] = $cat['id'];
		}
	}
	return $ids;
}

/** @deprecated 2.16.0 kept for callers outside this file. */
function ARD_combo_blog_poke_categories() {
	return ARD_combo_blog_base_categories();
}

/**
 * Category catalog for the base picker: every product category of the sedi,
 * by name, with how many products and which sedi have it. Cached like the products.
 */
function ARD_combo_category_catalog() {
	$cached = get_site_transient( 'ard_combo_categories' );
	if ( is_array( $cached ) ) {
		return $cached;
	}
	$catalog = array();
	foreach ( ARD_payment_methods_sites() as $host => $label ) {
		$blog_id = ARD_combo_blog_id( $host );
		if ( ! $blog_id ) {
			continue;
		}
		switch_to_blog( $blog_id );
		foreach ( ARD_combo_blog_categories() as $cat ) {
			$key = ARD_combo_name_key( $cat['name'] );
			if ( '' === $key || 'uncategorized' === $cat['slug'] ) {
				continue;
			}
			if ( ! isset( $catalog[ $key ] ) ) {
				$catalog[ $key ] = array( 'name' => $cat['name'], 'count' => 0, 'auto' => false, 'sedi' => array() );
			}
			$catalog[ $key ]['count'] = max( $catalog[ $key ]['count'], $cat['count'] );
			$catalog[ $key ]['auto']  = $catalog[ $key ]['auto'] || ARD_combo_is_auto_base_category( $cat['name'], $cat['slug'] );
			if ( ! in_array( $label, $catalog[ $key ]['sedi'], true ) ) {
				$catalog[ $key ]['sedi'][] = $label;
			}
		}
		restore_current_blog();
	}
	uasort( $catalog, static function ( $a, $b ) {
		return strcasecmp( $a['name'], $b['name'] );
	} );
	set_site_transient( 'ard_combo_categories', $catalog, 30 * MINUTE_IN_SECONDS );
	return $catalog;
}

/**
 * Catalog for the admin pickers: every product name sold in at least one sede,
 * with the sedi that sell it. Cached for 30 minutes, flushed on save.
 */
function ARD_combo_catalog() {
	$cached = get_site_transient( 'ard_combo_catalog' );
	if ( is_array( $cached ) ) {
		return $cached;
	}
	$catalog = array();
	foreach ( ARD_payment_methods_sites() as $host => $label ) {
		$blog_id = ARD_combo_blog_id( $host );
		if ( ! $blog_id ) {
			continue;
		}
		switch_to_blog( $blog_id );
		foreach ( ARD_combo_blog_products() as $key => $product ) {
			if ( ! isset( $catalog[ $key ] ) ) {
				$catalog[ $key ] = array(
					'name'     => $product['name'],
					'image'    => $product['image'],
					'price'    => $product['price'],
					'category' => $product['categories'][0]['name'] ?? '',
					'sedi'     => array(),
				);
			}
			$catalog[ $key ]['sedi'][] = $label;
		}
		restore_current_blog();
	}
	uasort( $catalog, static function ( $a, $b ) {
		return strcasecmp( $a['category'] . ' ' . $a['name'], $b['category'] . ' ' . $b['name'] );
	} );
	set_site_transient( 'ard_combo_catalog', $catalog, 30 * MINUTE_IN_SECONDS );
	return $catalog;
}

function ARD_combo_flush_cache() {
	delete_site_transient( 'ard_combo_catalog' );
	delete_site_transient( 'ard_combo_categories' );
	foreach ( array_keys( ARD_payment_methods_sites() ) as $host ) {
		delete_site_transient( 'ard_combo_' . md5( $host ) );
		delete_site_transient( 'ard_combo_web_' . ARD_combo_blog_id( $host ) );
	}
	do_action( 'litespeed_purge_all' );
}

/* ------------------------------------------------------------------ admin */

add_action( 'admin_menu', 'ARD_combo_menu', 21 );
function ARD_combo_menu() {
	if ( ! ARD_payment_methods_is_hub() ) {
		return;
	}
	add_submenu_page( 'ard_stato_app', 'Menù combinati', 'Menù combinati', 'manage_options', 'ard_combo_menu', 'ARD_combo_render_page' );
}

function ARD_combo_handle_save() {
	if ( ! isset( $_POST['ard_combo_nonce'], $_POST['ard_combo_state'] )
		|| ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['ard_combo_nonce'] ) ), 'ard_save_combo_menu' ) ) {
		return null;
	}
	$state = json_decode( wp_unslash( $_POST['ard_combo_state'] ), true ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- sanitized field by field below
	if ( ! is_array( $state ) ) {
		return array( 'i dati inviati non sono validi, riprova' );
	}
	$categories = ARD_combo_category_catalog();
	$settings   = ARD_combo_sanitize_state( $state, ARD_combo_catalog(), $categories );

	$problems = array();
	if ( $settings['enabled'] ) {
		if ( ! $settings['base_categories'] && ! array_filter( wp_list_pluck( $categories, 'auto' ) ) ) {
			$problems[] = 'scegli almeno una categoria di prodotti a cui proporre i menù';
		}
		$active = array_filter( $settings['menus'], static function ( $m ) { return $m['enabled']; } );
		if ( ! $active ) {
			$problems[] = 'accendi almeno un menù';
		}
		$by_key = array_column( $settings['groups'], null, 'key' );
		foreach ( $active as $menu ) {
			foreach ( $menu['groups'] as $g ) {
				if ( empty( $by_key[ $g ]['products'] ) ) {
					$problems[] = 'aggiungi almeno un prodotto a «' . $by_key[ $g ]['label'] . '» (usato da «' . $menu['label'] . '»)';
				}
			}
		}
	}
	if ( $settings['drinks_enabled'] && ! $settings['drinks'] ) {
		$problems[] = 'scegli almeno una bibita da proporre';
	}

	update_site_option( ARD_COMBO_OPTION, $settings );
	ARD_combo_flush_cache();
	return array_values( array_unique( $problems ) );
}

function ARD_combo_render_page() {
	if ( ! ARD_payment_methods_is_hub() || ! current_user_can( 'manage_options' ) ) {
		wp_die( 'Pagina disponibile solo sul sito principale del brand.' );
	}
	if ( isset( $_GET['ard_combo_refresh'] ) && check_admin_referer( 'ard_combo_refresh' ) ) {
		delete_site_transient( 'ard_combo_catalog' );
		delete_site_transient( 'ard_combo_categories' );
	}
	$problems = ARD_combo_handle_save();
	$settings = ARD_combo_settings();
	$catalog  = ARD_combo_catalog();
	$n_sites  = count( ARD_payment_methods_sites() );
	$cats     = ARD_combo_category_catalog();
	$langs    = ARD_combo_text_langs();
	$js_cats  = array();
	foreach ( $cats as $key => $c ) {
		$js_cats[ $key ] = array(
			'n' => $c['name'],
			'c' => $c['count'],
			'a' => $c['auto'],
			's' => count( $c['sedi'] ) === $n_sites ? '' : implode( ', ', $c['sedi'] ),
		);
	}

	$js_catalog = array();
	foreach ( $catalog as $key => $p ) {
		$js_catalog[ $key ] = array(
			'n' => $p['name'],
			'i' => $p['image'],
			'p' => $p['price'],
			'c' => $p['category'],
			's' => count( $p['sedi'] ) === $n_sites ? '' : implode( ', ', $p['sedi'] ),
		);
	}

	if ( is_array( $problems ) ) {
		if ( $problems ) {
			echo '<div class="notice notice-warning"><p><strong>Salvato.</strong> Per far funzionare tutto: ' . esc_html( implode( '; ', $problems ) ) . '.</p></div>';
		} else {
			echo '<div class="notice notice-success"><p>Menù combinati salvati. L\'app li usa dal prossimo carrello.</p></div>';
		}
	}
	$refresh_url = wp_nonce_url( add_query_arg( 'ard_combo_refresh', 1 ), 'ard_combo_refresh' );
	?>
	<style>
		.ard-cm { max-width: 1200px; margin-top: 10px; }
		.ard-cm * { box-sizing: border-box; }
		.ard-cm-top { display: flex; align-items: flex-end; justify-content: space-between; gap: 16px; margin-bottom: 16px; }
		.ard-cm-top h1 { margin: 0 0 4px; }
		.ard-cm-top p { margin: 0; color: #50575e; max-width: 660px; }
		.ard-cm-grid { display: grid; grid-template-columns: minmax(0, 1fr) 320px; gap: 24px; align-items: start; }
		.ard-cm-main { min-width: 0; display: flex; flex-direction: column; gap: 16px; }
		.ard-cm-card { background: #fff; border: 1px solid #dcdcde; border-radius: 14px; padding: 20px 22px; }
		.ard-cm-card.is-off .ard-cm-body { opacity: .45; }
		.ard-cm-head { display: flex; align-items: center; justify-content: space-between; gap: 12px; }
		.ard-cm-head h2 { margin: 0; font-size: 17px; }
		.ard-cm-head p { margin: 4px 0 0; color: #646970; font-size: 13px; }
		.ard-cm-body { margin-top: 18px; }
		.ard-cm-sw { position: relative; display: inline-flex; align-items: center; gap: 8px; cursor: pointer; font-weight: 600; font-size: 13px; color: #1d2327; white-space: nowrap; margin: 0; }
		.ard-cm-sw input { position: absolute; opacity: 0; width: 0; height: 0; }
		.ard-cm-sw .knob { width: 38px; height: 22px; border-radius: 999px; background: #c3c4c7; position: relative; transition: background .15s; flex: none; }
		.ard-cm-sw .knob::after { content: ""; position: absolute; top: 3px; left: 3px; width: 16px; height: 16px; border-radius: 50%; background: #fff; box-shadow: 0 1px 2px rgba(0,0,0,.25); transition: left .15s; }
		.ard-cm-sw input:checked + .knob { background: #1ca5a8; }
		.ard-cm-sw input:checked + .knob::after { left: 19px; }
		.ard-cm-sw input:focus-visible + .knob { outline: 2px solid #1ca5a8; outline-offset: 2px; }
		.ard-cm-tiles { display: grid; grid-template-columns: repeat(auto-fill, minmax(230px, 1fr)); gap: 12px; }
		.ard-cm-tile { border: 1.5px solid #dcdcde; border-radius: 12px; padding: 14px; display: flex; flex-direction: column; gap: 10px; background: #fff; }
		.ard-cm-tile.is-on { border-color: #1ca5a8; background: #f4fbfb; }
		.ard-cm-tile-top { display: flex; align-items: center; gap: 8px; }
		.ard-cm-name { flex: 1; min-width: 0; font-weight: 700; font-size: 14px; border: 1px solid transparent !important; background: transparent !important; box-shadow: none !important; padding: 4px 6px !important; border-radius: 6px !important; }
		.ard-cm-name:hover { border-color: #dcdcde !important; background: #fff !important; }
		.ard-cm-name:focus { border-color: #1ca5a8 !important; background: #fff !important; }
		.ard-cm-icon-btn { border: 0; background: transparent; color: #8c8f94; cursor: pointer; width: 28px; height: 28px; border-radius: 6px; display: inline-flex; align-items: center; justify-content: center; flex: none; }
		.ard-cm-icon-btn:hover { background: #fcf0f1; color: #d63638; }
		.ard-cm-price { display: flex; align-items: center; border: 1px solid #8c8f94; border-radius: 8px; overflow: hidden; background: #fff; margin: 0; }
		.ard-cm-price span { display: flex; align-items: center; flex: none; white-space: nowrap; height: 36px; padding: 0 10px; color: #50575e; font-size: 13px; background: #f6f7f7; border-right: 1px solid #dcdcde; }
		.ard-cm-price input { border: 0 !important; box-shadow: none !important; width: 100%; min-width: 0; text-align: right; font-size: 16px; font-weight: 700; padding: 0 10px; height: 36px; }
		.ard-cm-lbl { font-size: 11px; text-transform: uppercase; letter-spacing: .04em; color: #646970; }
		.ard-cm-pills { display: flex; flex-wrap: wrap; gap: 6px; }
		.ard-cm-pill { border: 1.5px solid #dcdcde; background: #fff; border-radius: 999px; padding: 4px 10px; font-size: 12px; font-weight: 600; cursor: pointer; color: #50575e; }
		.ard-cm-pill.is-on { border-color: #1ca5a8; background: #1ca5a8; color: #fff; }
		.ard-cm-new { border: 1.5px dashed #a7aaad; border-radius: 12px; background: transparent; color: #2271b1; font-weight: 600; cursor: pointer; min-height: 120px; font-size: 14px; }
		.ard-cm-new:hover { border-color: #2271b1; background: #f0f6fc; }
		.ard-cm-comps { display: flex; flex-direction: column; gap: 12px; }
		.ard-cm-comp { border: 1px solid #dcdcde; border-radius: 12px; padding: 14px; }
		.ard-cm-comp-top { display: flex; align-items: center; gap: 8px; margin-bottom: 8px; }
		.ard-cm-emoji { position: relative; }
		.ard-cm-emoji > button { width: 38px; height: 38px; border: 1px solid #dcdcde; border-radius: 8px; background: #fff; font-size: 20px; cursor: pointer; }
		.ard-cm-emoji-pop { display: none; position: absolute; z-index: 25; top: 42px; left: 0; background: #fff; border: 1px solid #dcdcde; border-radius: 10px; box-shadow: 0 8px 24px rgba(0,0,0,.12); padding: 6px; width: 196px; flex-wrap: wrap; gap: 2px; }
		.ard-cm-emoji.is-open .ard-cm-emoji-pop { display: flex; }
		.ard-cm-emoji-pop button { width: 30px; height: 30px; border: 0; background: transparent; font-size: 18px; border-radius: 6px; cursor: pointer; }
		.ard-cm-emoji-pop button:hover { background: #f0f6fc; }
		.ard-cm-used { font-size: 12px; color: #646970; white-space: nowrap; }
		.ard-cm-chips { display: flex; flex-wrap: wrap; gap: 6px; margin-bottom: 8px; }
		.ard-cm-chip { display: inline-flex; align-items: center; gap: 6px; max-width: 100%; background: #e7f6f6; border: 1px solid #a6dcdd; border-radius: 999px; padding: 3px 4px; font-size: 12px; font-weight: 600; color: #1d2327; }
		.ard-cm-chip img, .ard-cm-chip .ph { width: 22px; height: 22px; border-radius: 50%; object-fit: cover; background: #dcdcde; flex: none; }
		.ard-cm-chip .t { white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
		.ard-cm-chip button { border: 0; background: transparent; cursor: pointer; color: #50575e; width: 20px; height: 20px; border-radius: 50%; font-size: 14px; line-height: 1; flex: none; }
		.ard-cm-chip button:hover { background: #c5e9ea; }
		.ard-cm-empty { color: #8c8f94; font-size: 12px; padding: 4px 0; }
		.ard-cm-texts { display: grid; grid-template-columns: 1fr 1.4fr; gap: 12px; margin-bottom: 16px; }
		.ard-cm-field { display: flex; flex-direction: column; gap: 4px; margin: 0; }
		.ard-cm-field input, .ard-cm-langrow input { height: 38px; border-radius: 8px; width: 100%; min-width: 0; }
		.ard-cm-langs { grid-column: 1 / -1; border: 1px solid #dcdcde; border-radius: 10px; padding: 8px 12px; }
		.ard-cm-langs summary { cursor: pointer; font-weight: 600; font-size: 13px; color: #2271b1; }
		.ard-cm-langs p { margin: 6px 0 8px; color: #646970; font-size: 12px; }
		.ard-cm-langrow { display: grid; grid-template-columns: 80px 1fr 1.4fr; gap: 8px; align-items: center; margin-bottom: 8px; }
		.ard-cm-langname { font-size: 12px; font-weight: 600; color: #50575e; }
		@media (max-width: 782px) { .ard-cm-texts, .ard-cm-langrow { grid-template-columns: 1fr; } }
		.ard-cm-chip.is-cat { padding: 3px 4px 3px 10px; }
		.ard-cm-chip .n { color: #646970; font-weight: 500; }
		.ard-cm-auto { display: inline-flex; align-items: center; gap: 6px; font-size: 12px; color: #1d6b6d; background: #e7f6f6; border-radius: 6px; padding: 4px 8px; margin-bottom: 8px; }
		.ard-cm-opt .ic { width: 32px; height: 32px; border-radius: 6px; background: #f0f0f1; flex: none; display: inline-flex; align-items: center; justify-content: center; color: #8c8f94; }
		.ard-cm-add { position: relative; }
		.ard-cm-add input[type=search] { width: 100%; height: 38px; border-radius: 8px; padding-left: 34px; }
		.ard-cm-add .dashicons { position: absolute; left: 9px; top: 9px; color: #8c8f94; }
		.ard-cm-drop { display: none; position: absolute; z-index: 20; left: 0; right: 0; top: 42px; background: #fff; border: 1px solid #dcdcde; border-radius: 10px; box-shadow: 0 8px 24px rgba(0,0,0,.12); max-height: 280px; overflow: auto; }
		.ard-cm-add.is-open { z-index: 40; }
		.ard-cm-add.is-open .ard-cm-drop { display: block; }
		.ard-cm-add.is-up .ard-cm-drop { top: auto; bottom: 42px; box-shadow: 0 -8px 24px rgba(0,0,0,.12); }
		.ard-cm-opt { display: flex; align-items: center; gap: 10px; padding: 7px 10px; cursor: pointer; }
		.ard-cm-opt:hover { background: #f0f6fc; }
		.ard-cm-opt img, .ard-cm-opt .ph { width: 32px; height: 32px; border-radius: 6px; object-fit: cover; background: #f0f0f1; flex: none; }
		.ard-cm-opt .t { flex: 1; min-width: 0; }
		.ard-cm-opt .t b { display: block; font-size: 13px; font-weight: 600; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
		.ard-cm-opt .t span { display: block; font-size: 11px; color: #646970; }
		.ard-cm-opt .pr { font-size: 12px; font-weight: 600; white-space: nowrap; }
		.ard-cm-opt .badge { font-size: 10px; background: #fcf0e3; color: #8a4b00; border-radius: 4px; padding: 1px 5px; margin-left: 4px; }
		.ard-cm-none { padding: 12px; color: #8c8f94; font-size: 12px; }
		.ard-cm-addcomp { margin-top: 12px; }
		.ard-cm-aside { position: sticky; top: 46px; }
		.ard-cm-phone { background: #1d2327; border-radius: 34px; padding: 10px; box-shadow: 0 10px 30px rgba(0,0,0,.18); }
		.ard-cm-screen { background: #f7f7f7; border-radius: 26px; padding: 16px 14px; min-height: 440px; }
		.ard-cm-tabs { display: flex; background: #e9ecef; border-radius: 999px; padding: 3px; margin-bottom: 14px; }
		.ard-cm-tabs button { flex: 1; border: 0; background: transparent; border-radius: 999px; padding: 6px; font-size: 12px; font-weight: 600; color: #50575e; cursor: pointer; }
		.ard-cm-tabs button.is-on { background: #fff; color: #1ca5a8; box-shadow: 0 1px 2px rgba(0,0,0,.1); }
		.ard-cm-screen h4 { margin: 0; color: #1ca5a8; font-size: 18px; font-weight: 800; }
		.ard-cm-screen .sub { color: #646970; font-size: 12px; margin: 2px 0 12px; }
		.ard-cm-prow { background: #fff; border-radius: 12px; padding: 11px 12px; margin-bottom: 8px; display: flex; align-items: center; gap: 10px; box-shadow: 0 1px 3px rgba(0,0,0,.06); font-size: 13px; font-weight: 600; }
		.ard-cm-prow .em { font-size: 15px; white-space: nowrap; }
		.ard-cm-prow .nm { flex: 1; min-width: 0; }
		.ard-cm-prow .pc { background: #e7f6f6; color: #1ca5a8; border-radius: 999px; padding: 3px 8px; font-weight: 800; font-size: 12px; white-space: nowrap; }
		.ard-cm-prow img, .ard-cm-prow .ph { width: 34px; height: 34px; border-radius: 8px; object-fit: cover; background: #e9ecef; }
		.ard-cm-prow .plus { width: 26px; height: 26px; border-radius: 50%; background: #1ca5a8; color: #fff; display: inline-flex; align-items: center; justify-content: center; font-weight: 700; }
		.ard-cm-secs { display: flex; flex-wrap: wrap; gap: 8px; }
		.ard-cm-emoji.is-open { z-index: 40; }
		.ard-cm-sec .ard-cm-emoji-pop { top: auto; bottom: 42px; }
		.ard-cm-sec { display: flex; align-items: center; gap: 8px; border: 1px solid #dcdcde; border-radius: 10px; padding: 6px 12px 6px 6px; }
		.ard-cm-sec .nm { font-weight: 600; font-size: 13px; }
		.ard-cm-sec .ct { font-size: 12px; color: #646970; white-space: nowrap; }
		.ard-cm-acc { background: #fff; border-radius: 12px; margin-bottom: 8px; box-shadow: 0 1px 3px rgba(0,0,0,.06); overflow: hidden; }
		.ard-cm-acc-h { width: 100%; border: 0; background: transparent; display: flex; align-items: center; gap: 10px; padding: 12px; cursor: pointer; font: inherit; text-align: left; }
		.ard-cm-acc-h .ic { width: 34px; height: 34px; border-radius: 8px; background: #e7f6f6; display: inline-flex; align-items: center; justify-content: center; font-size: 18px; flex: none; }
		.ard-cm-acc-h .nm { flex: 1; min-width: 0; font-weight: 700; font-size: 14px; color: #1d2327; }
		.ard-cm-acc-h .ct { background: #e7f6f6; color: #1ca5a8; border-radius: 999px; padding: 2px 8px; font-size: 12px; font-weight: 700; }
		.ard-cm-acc-h .chev { color: #646970; font-size: 16px; line-height: 1; transition: transform .15s; }
		.ard-cm-acc.is-open .chev { transform: rotate(180deg); }
		.ard-cm-acc .ard-cm-prow { box-shadow: none; border-top: 1px solid #f0f0f1; border-radius: 0; margin: 0; }
		.ard-cm-pbtn { margin-top: 12px; border: 1.5px solid #c3c4c7; border-radius: 999px; text-align: center; padding: 9px; font-weight: 700; font-size: 13px; color: #3c434a; background: #fff; }
		.ard-cm-pnote { color: #8c8f94; font-size: 12px; text-align: center; padding: 30px 10px; }
		.ard-cm-asidenote { color: #646970; font-size: 12px; text-align: center; margin-top: 10px; }
		.ard-cm-bar { position: sticky; bottom: 0; z-index: 30; display: flex; align-items: center; gap: 14px; background: rgba(255,255,255,.96); border: 1px solid #dcdcde; border-radius: 14px; padding: 12px 18px; box-shadow: 0 -4px 16px rgba(0,0,0,.06); }
		.ard-cm-bar .button-primary { background: #1ca5a8; border-color: #1ca5a8; padding: 4px 24px; font-size: 14px; }
		.ard-cm-bar .button-primary:hover { background: #178a8d; border-color: #178a8d; }
		.ard-cm-dirty { color: #996800; font-size: 13px; font-weight: 600; visibility: hidden; }
		.ard-cm-dirty.is-on { visibility: visible; }
		@media (max-width: 1100px) { .ard-cm-grid { grid-template-columns: minmax(0, 1fr); } .ard-cm-aside { position: static; max-width: 340px; } }
		@media (max-width: 782px) { .ard-cm-top { flex-direction: column; align-items: flex-start; } }
	</style>

	<div class="wrap ard-cm">
		<div class="ard-cm-top">
			<div>
				<h1>Menù combinati</h1>
				<p>Quando nel carrello c'è un prodotto delle categorie scelte qui sotto (di solito le poké) senza bibite né dessert, prima del pagamento l'app propone i menù; se il cliente li salta, propone una bibita. Valgono per tutte le sedi: ognuna mostra solo i prodotti che vende.</p>
			</div>
			<a class="button" href="<?php echo esc_url( $refresh_url ); ?>"><span class="dashicons dashicons-update" style="margin-top:4px"></span> Aggiorna elenco prodotti</a>
		</div>

		<form method="post" id="ard-cm-form">
			<?php wp_nonce_field( 'ard_save_combo_menu', 'ard_combo_nonce' ); ?>
			<input type="hidden" name="ard_combo_state" id="ard-cm-state" value="">
			<div class="ard-cm-grid">
				<div class="ard-cm-main">
					<section class="ard-cm-card">
						<div class="ard-cm-head">
							<div>
								<h2>A quali prodotti proporre i menù</h2>
								<p>Il menù si aggiunge a un prodotto di queste categorie: ogni prodotto nel carrello dà diritto a un menù.</p>
							</div>
						</div>
						<div class="ard-cm-body" id="ard-cm-base"></div>
					</section>

					<section class="ard-cm-card" id="ard-cm-menus-card">
						<div class="ard-cm-head">
							<div>
								<h2>Menù proposti</h2>
								<p>Clicca il nome per cambiarlo. Il prezzo è quanto si aggiunge al prodotto scelto sopra.</p>
							</div>
							<label class="ard-cm-sw"><input type="checkbox" id="ard-cm-enabled"><span class="knob"></span><span class="lbl"></span></label>
						</div>
						<div class="ard-cm-body"><div class="ard-cm-tiles" id="ard-cm-menus"></div></div>
					</section>

					<section class="ard-cm-card">
						<div class="ard-cm-head">
							<div>
								<h2>Componenti dei menù</h2>
								<p>Cosa sceglie il cliente in ogni menù (es. Acqua, Dessert, Bibita, Antipasto) e tra quali prodotti.</p>
							</div>
						</div>
						<div class="ard-cm-body">
							<div class="ard-cm-comps" id="ard-cm-groups"></div>
							<button type="button" class="button ard-cm-addcomp" id="ard-cm-addgroup"><span class="dashicons dashicons-plus-alt2" style="margin-top:4px"></span> Aggiungi componente</button>
						</div>
					</section>

					<section class="ard-cm-card" id="ard-cm-drinks-card">
						<div class="ard-cm-head">
							<div>
								<h2>Pagina Upsell <span style="font-weight:400;color:#646970">«<span id="ard-cm-dtitle"><?php echo esc_html( rtrim( $settings['drinks_texts']['title']['it'] ?? $langs['it']['title'], ' ?' ) ); ?></span>»</span></h2>
								<p>Solo se il cliente salta i menù. Le bibite e i dessert proposti qui costano il loro prezzo normale.</p>
							</div>
							<label class="ard-cm-sw"><input type="checkbox" id="ard-cm-drinks-enabled"><span class="knob"></span><span class="lbl"></span></label>
						</div>
						<div class="ard-cm-body">
							<div class="ard-cm-texts">
								<label class="ard-cm-field"><span class="ard-cm-lbl">Titolo della pagina</span>
									<input type="text" maxlength="60" data-dtext="title|it" value="<?php echo esc_attr( $settings['drinks_texts']['title']['it'] ?? '' ); ?>" placeholder="<?php echo esc_attr( $langs['it']['title'] ); ?>"></label>
								<label class="ard-cm-field"><span class="ard-cm-lbl">Sottotitolo</span>
									<input type="text" maxlength="90" data-dtext="subtitle|it" value="<?php echo esc_attr( $settings['drinks_texts']['subtitle']['it'] ?? '' ); ?>" placeholder="<?php echo esc_attr( $langs['it']['subtitle'] ); ?>"></label>
								<details class="ard-cm-langs"<?php echo array_diff_key( $settings['drinks_texts']['title'] + $settings['drinks_texts']['subtitle'], array( 'it' => 1 ) ) ? ' open' : ''; ?>>
									<summary>Testo nelle altre lingue dell'app</summary>
									<p>Se lasci vuota una lingua, l'app mostra il testo standard (quello in grigio).</p>
									<?php foreach ( $langs as $lang => $info ) : if ( 'it' === $lang ) { continue; } ?>
										<div class="ard-cm-langrow"><span class="ard-cm-langname"><?php echo esc_html( $info['label'] ); ?></span>
											<input type="text" maxlength="60" data-dtext="title|<?php echo esc_attr( $lang ); ?>" value="<?php echo esc_attr( $settings['drinks_texts']['title'][ $lang ] ?? '' ); ?>" placeholder="<?php echo esc_attr( $info['title'] ); ?>" aria-label="Titolo <?php echo esc_attr( $info['label'] ); ?>">
											<input type="text" maxlength="90" data-dtext="subtitle|<?php echo esc_attr( $lang ); ?>" value="<?php echo esc_attr( $settings['drinks_texts']['subtitle'][ $lang ] ?? '' ); ?>" placeholder="<?php echo esc_attr( $info['subtitle'] ); ?>" aria-label="Sottotitolo <?php echo esc_attr( $info['label'] ); ?>"></div>
									<?php endforeach; ?>
								</details>
							</div>
							<div id="ard-cm-drinks"></div>
						</div>
					</section>

					<div class="ard-cm-bar">
						<?php submit_button( 'Salva', 'primary', 'submit', false ); ?>
						<span class="ard-cm-dirty" id="ard-cm-dirty">● Modifiche non salvate</span>
					</div>
				</div>

				<aside class="ard-cm-aside" aria-label="Anteprima nell'app">
					<div class="ard-cm-phone">
						<div class="ard-cm-screen">
							<div class="ard-cm-tabs" role="tablist">
								<button type="button" class="is-on" data-tab="combo">Menù</button>
								<button type="button" data-tab="drinks">Upsell</button>
							</div>
							<div id="ard-cm-pv"></div>
						</div>
					</div>
					<p class="ard-cm-asidenote">Anteprima di come appare nell'app</p>
				</aside>
			</div>
		</form>
	</div>

	<script>
	(function () {
		var form = document.getElementById('ard-cm-form');
		var catalog = <?php echo wp_json_encode( $js_catalog ); ?>;
		var cats = <?php echo wp_json_encode( (object) $js_cats ); ?>;
		var autoBase = Object.keys(cats).filter(function (k) { return cats[k].a; });
		var emojis = <?php echo wp_json_encode( ARD_combo_emojis() ); ?>;
		var state = <?php echo wp_json_encode( array(
			'enabled'         => $settings['enabled'],
			'base_categories' => $settings['base_categories'],
			'drinks_enabled'  => $settings['drinks_enabled'],
			'drinks_texts'    => array( 'title' => (object) $settings['drinks_texts']['title'], 'subtitle' => (object) $settings['drinks_texts']['subtitle'] ),
			'drinks_icons'    => (object) $settings['drinks_icons'],
			'groups'         => $settings['groups'],
			'menus'          => $settings['menus'],
			'drinks'         => $settings['drinks'],
		) ); ?>;
		var tab = 'combo';
		var openSearch = null; // keeps focus in the product search across re-renders

		function esc(s) { var d = document.createElement('div'); d.textContent = s == null ? '' : String(s); return d.innerHTML; }
		function money(v) { return 'CHF ' + Number(v || 0).toFixed(2); }
		function norm(s) { return String(s || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, ''); }
		function img(p) { return p && p.i ? '<img src="' + esc(p.i) + '" alt="" loading="lazy">' : '<span class="ph"></span>'; }
		function uid(prefix) { return prefix + Math.random().toString(36).slice(2, 10); }
		function dirty() { document.getElementById('ard-cm-dirty').classList.add('is-on'); }
		function groupByKey(k) { for (var i = 0; i < state.groups.length; i++) { if (state.groups[i].key === k) return state.groups[i]; } return null; }
		function preferFor(label) {
			var l = norm(label);
			if (/dess|dolc|mochi|torta|gelat/.test(l)) return /dessert|dolc|mochi/i;
			if (/acqua|bibit|bevand|drink|soda|the|te /.test(l)) return /bibit|bevand|acqua|drink/i;
			return null;
		}

		/* ---------- product picker (used by components and drinks) ---------- */
		function pickerHtml(id, list, title, hint) {
			var chips = list.length ? list.map(function (k) {
				var p = catalog[k] || { n: k };
				return '<span class="ard-cm-chip">' + img(p) + '<span class="t">' + esc(p.n) + '</span><button type="button" data-remove="' + esc(k) + '" aria-label="Togli ' + esc(p.n) + '">×</button></span>';
			}).join('') : '<span class="ard-cm-empty">Nessun prodotto: cercalo qui sotto e aggiungilo</span>';
			return (title ? '<div class="ard-cm-lbl" style="margin-bottom:6px">' + esc(title) + (hint ? ' · <span style="text-transform:none;letter-spacing:0">' + esc(hint) + '</span>' : '') + '</div>' : '') +
				'<div class="ard-cm-chips">' + chips + '</div>' +
				'<div class="ard-cm-add" data-picker="' + esc(id) + '"><span class="dashicons dashicons-plus-alt2" aria-hidden="true"></span>' +
				'<input type="search" placeholder="Aggiungi un prodotto…" autocomplete="off"><div class="ard-cm-drop" role="listbox"></div></div>';
		}
		function dropHtml(list, q, prefer) {
			q = norm(q).trim();
			var pref = [], rest = [];
			Object.keys(catalog).forEach(function (k) {
				if (list.indexOf(k) !== -1) return;
				var p = catalog[k];
				if (q && norm(p.n + ' ' + p.c).indexOf(q) === -1) return;
				(prefer && (prefer.test(p.c) || prefer.test(p.n)) ? pref : rest).push(k);
			});
			function opt(k) { var p = catalog[k]; return '<div class="ard-cm-opt" role="option" data-key="' + esc(k) + '">' + img(p) + '<span class="t"><b>' + esc(p.n) + (p.s ? '<span class="badge">solo ' + esc(p.s) + '</span>' : '') + '</b><span>' + esc(p.c) + '</span></span><span class="pr">' + (p.p != null ? money(p.p) : '') + '</span></div>'; }
			var html = '';
			if (pref.length) html += '<div class="ard-cm-lbl" style="padding:8px 10px 4px">Suggeriti</div>' + pref.slice(0, 40).map(opt).join('');
			if (rest.length && (q || !pref.length)) html += (pref.length ? '<div class="ard-cm-lbl" style="padding:8px 10px 4px">Altri prodotti</div>' : '') + rest.slice(0, 40).map(opt).join('');
			return html || '<div class="ard-cm-none">Nessun prodotto trovato</div>';
		}
		/* ---------- base categories: empty list = automatic (the poké categories) ---------- */
		function nProd(n) { return n === 1 ? '1 prodotto' : n + ' prodotti'; }
		function baseList() { return state.base_categories.length ? state.base_categories : autoBase; }
		function baseEditable() { if (!state.base_categories.length) state.base_categories = autoBase.slice(); return state.base_categories; }
		function baseName() {
			var names = baseList().map(function (k) { return cats[k] ? cats[k].n : k; });
			if (!names.length) return 'il prodotto';
			return names.length > 2 ? names.slice(0, 2).join(', ') + '…' : names.join(' o ');
		}
		function catChip(k) {
			var c = cats[k] || { n: k, c: 0 };
			return '<span class="ard-cm-chip is-cat"><span class="t">' + esc(c.n) + ' <span class="n">· ' + nProd(c.c) + '</span></span><button type="button" data-remove="' + esc(k) + '" aria-label="Togli ' + esc(c.n) + '">×</button></span>';
		}
		function renderBase() {
			var list = baseList(), auto = !state.base_categories.length;
			var html = auto
				? (list.length ? '<div class="ard-cm-auto">✓ Scelte in automatico: le categorie con «Poké» nel nome</div>' : '<div class="ard-cm-empty" style="color:#b32d2e">Nessuna categoria: aggiungine almeno una, altrimenti i menù non compaiono</div>')
				: '';
			html += '<div class="ard-cm-chips">' + list.map(catChip).join('') + '</div>' +
				'<div class="ard-cm-add" data-picker="base"><span class="dashicons dashicons-plus-alt2" aria-hidden="true"></span>' +
				'<input type="search" placeholder="Aggiungi una categoria (es. Pizze, Burger)…" autocomplete="off"><div class="ard-cm-drop" role="listbox"></div></div>';
			document.getElementById('ard-cm-base').innerHTML = html;
		}
		function catDropHtml(list, q) {
			q = norm(q).trim();
			var keys = Object.keys(cats).filter(function (k) { return list.indexOf(k) === -1 && (!q || norm(cats[k].n).indexOf(q) !== -1); });
			return keys.slice(0, 60).map(function (k) {
				var c = cats[k];
				return '<div class="ard-cm-opt" role="option" data-key="' + esc(k) + '"><span class="ic dashicons dashicons-category"></span><span class="t"><b>' + esc(c.n) + (c.s ? '<span class="badge">solo ' + esc(c.s) + '</span>' : '') + '</b><span>' + nProd(c.c) + '</span></span></div>';
			}).join('') || '<div class="ard-cm-none">Nessuna categoria trovata</div>';
		}
		function pickerList(id) {
			if (id === 'base') return { list: baseList(), cats: true };
			if (id === 'drinks') return { list: state.drinks, prefer: /bibit|bevand|acqua|drink/i };
			var g = groupByKey(id.slice(2));
			return g ? { list: g.products, prefer: preferFor(g.label) } : null;
		}

		/* ---------- rendering ---------- */
		function renderMenus() {
			var box = document.getElementById('ard-cm-menus');
			box.innerHTML = state.menus.map(function (m, i) {
				var pills = state.groups.map(function (g) {
					var on = m.groups.indexOf(g.key) !== -1;
					return '<button type="button" class="ard-cm-pill' + (on ? ' is-on' : '') + '" data-menu-group="' + i + '|' + esc(g.key) + '">' + esc((g.emoji ? g.emoji + ' ' : '') + g.label) + '</button>';
				}).join('');
				return '<div class="ard-cm-tile' + (m.enabled ? ' is-on' : '') + '">' +
					'<div class="ard-cm-tile-top"><input class="ard-cm-name" type="text" maxlength="60" value="' + esc(m.label) + '" data-menu-label="' + i + '" aria-label="Nome del menù">' +
					'<label class="ard-cm-sw" title="Mostra questo menù"><input type="checkbox" data-menu-enabled="' + i + '"' + (m.enabled ? ' checked' : '') + '><span class="knob"></span></label>' +
					'<button type="button" class="ard-cm-icon-btn" data-menu-delete="' + i + '" title="Elimina menù" aria-label="Elimina menù"><span class="dashicons dashicons-trash"></span></button></div>' +
					'<label class="ard-cm-price"><span>+ CHF</span><input type="number" min="0" step="0.05" inputmode="decimal" value="' + Number(m.price || 0).toFixed(2) + '" data-menu-price="' + i + '" aria-label="Supplemento"></label>' +
					'<div><div class="ard-cm-lbl" style="margin-bottom:6px">Contiene, oltre a ' + esc(baseName()) + '</div><div class="ard-cm-pills">' + (pills || '<span class="ard-cm-empty">Crea prima un componente</span>') + '</div></div>' +
					'</div>';
			}).join('') + (state.menus.length < 10 ? '<button type="button" class="ard-cm-new" id="ard-cm-addmenu">+ Nuovo menù</button>' : '');
		}
		function renderGroups() {
			var box = document.getElementById('ard-cm-groups');
			box.innerHTML = state.groups.map(function (g, i) {
				var used = state.menus.filter(function (m) { return m.groups.indexOf(g.key) !== -1; }).length;
				return '<div class="ard-cm-comp">' +
					'<div class="ard-cm-comp-top">' +
					'<div class="ard-cm-emoji"><button type="button" data-emoji-open="' + i + '" aria-label="Icona">' + (g.emoji || '＋') + '</button><div class="ard-cm-emoji-pop">' +
					emojis.map(function (e) { return '<button type="button" data-emoji="' + i + '|' + e + '">' + e + '</button>'; }).join('') + '<button type="button" data-emoji="' + i + '|" title="Nessuna">∅</button></div></div>' +
					'<input class="ard-cm-name" type="text" maxlength="40" value="' + esc(g.label) + '" data-group-label="' + i + '" aria-label="Nome del componente" placeholder="Nome (es. Bibita)">' +
					'<span class="ard-cm-used">' + (used ? 'in ' + used + (used === 1 ? ' menù' : ' menù') : 'non usato') + '</span>' +
					'<button type="button" class="ard-cm-icon-btn" data-group-delete="' + i + '" title="Elimina componente" aria-label="Elimina componente"><span class="dashicons dashicons-trash"></span></button></div>' +
					pickerHtml('g:' + g.key, g.products, '', 'il cliente sceglie uno di questi') +
					'</div>';
			}).join('') || '<p class="ard-cm-empty">Nessun componente.</p>';
		}
		/* ---------- Upsell sections: the chosen products grouped by their category ---------- */
		var pvOpen = {};
		function secLabel(name) { var l = String(name || '').replace(/^\s*\d+\s*[.)\-:]\s+/, '').trim(); return l || String(name || '').trim(); }
		function catKey(name) { return norm(name).replace(/\s+/g, ' ').trim(); }
		function defaultSecEmoji(name) {
			var n = catKey(name) + ' ';
			var map = [[/birr|beer/, '🍺'], [/vin[io]|wine/, '🍷'], [/caff|coffee/, '☕'], [/bibit|bevand|drink|bere|soda|acqua|succh|the |te /, '🥤'], [/gelat|ice cream/, '🍦'], [/dess|dolc|torta|cheesecake|mochi|sweet/, '🍰'], [/antipast|starter|snack|fritt/, '🍟']];
			for (var i = 0; i < map.length; i++) { if (map[i][0].test(n)) return map[i][1]; }
			return '🍽️';
		}
		function drinkSections() {
			var out = [], byKey = {};
			state.drinks.forEach(function (k) {
				var p = catalog[k]; if (!p) return;
				var label = secLabel(p.c) || 'Altro', key = catKey(label);
				if (!byKey[key]) { byKey[key] = { key: key, label: label, emoji: state.drinks_icons[key] || defaultSecEmoji(label), items: [] }; out.push(byKey[key]); }
				byKey[key].items.push(k);
			});
			return out;
		}
		function renderDrinks() {
			var secs = drinkSections();
			document.getElementById('ard-cm-drinks').innerHTML = pickerHtml('drinks', state.drinks, 'Prodotti proposti', 'nell\'app sono raggruppati per categoria') +
				(secs.length ? '<div class="ard-cm-lbl" style="margin:16px 0 6px">Sezioni nell\'app · <span style="text-transform:none;letter-spacing:0">si aprono con un tocco; clicca l\'icona per cambiarla</span></div><div class="ard-cm-secs">' +
				secs.map(function (sec) {
					return '<div class="ard-cm-sec"><div class="ard-cm-emoji"><button type="button" data-semoji-open aria-label="Icona di ' + esc(sec.label) + '">' + sec.emoji + '</button><div class="ard-cm-emoji-pop">' +
						emojis.map(function (e) { return '<button type="button" data-semoji="' + esc(sec.key) + '|' + e + '">' + e + '</button>'; }).join('') + '</div></div>' +
						'<span class="nm">' + esc(sec.label) + '</span><span class="ct">' + nProd(sec.items.length) + '</span></div>';
				}).join('') + '</div>' : '');
		}
		function renderSwitches() {
			[['ard-cm-enabled', 'enabled', 'ard-cm-menus-card'], ['ard-cm-drinks-enabled', 'drinks_enabled', 'ard-cm-drinks-card']].forEach(function (s) {
				var el = document.getElementById(s[0]);
				el.checked = !!state[s[1]];
				el.parentNode.querySelector('.lbl').textContent = el.checked ? 'Attiva' : 'Spenta';
				document.getElementById(s[2]).classList.toggle('is-off', !el.checked);
			});
		}
		function renderPreview() {
			document.querySelectorAll('.ard-cm-tabs button').forEach(function (b) { b.classList.toggle('is-on', b.dataset.tab === tab); });
			var html = '';
			if (tab === 'combo') {
				html += '<h4>Crea il tuo Menù</h4><div class="sub">Completa la tua poké a un prezzo speciale</div>';
				var rows = state.menus.filter(function (m) { return m.enabled && m.groups.length; }).map(function (m) {
					var em = '🥗' + m.groups.map(function (k) { var g = groupByKey(k); return g && g.emoji ? g.emoji : ''; }).join('');
					return '<div class="ard-cm-prow"><span class="em">' + esc(em) + '</span><span class="nm">' + esc(m.label) + '</span><span class="pc">+ ' + money(m.price) + '</span></div>';
				}).join('');
				html += state.enabled ? (rows || '<div class="ard-cm-pnote">Nessun menù acceso</div>') : '<div class="ard-cm-pnote">Pagina spenta: l\'app va diretta al pagamento</div>';
				html += '<div class="ard-cm-pbtn">Salta</div>';
			} else {
				html += '<h4>' + esc(state.drinks_texts.title.it || <?php echo wp_json_encode( $langs['it']['title'] ); ?>) + '</h4><div class="sub">' + esc(state.drinks_texts.subtitle.it || <?php echo wp_json_encode( $langs['it']['subtitle'] ); ?>) + '</div>';
				if (!state.drinks_enabled) html += '<div class="ard-cm-pnote">Pagina spenta</div>';
				else if (!state.drinks.length) html += '<div class="ard-cm-pnote">Nessun prodotto scelto</div>';
				else drinkSections().forEach(function (sec) {
					var open = !!pvOpen[sec.key];
					html += '<div class="ard-cm-acc' + (open ? ' is-open' : '') + '"><button type="button" class="ard-cm-acc-h" data-pv-sec="' + esc(sec.key) + '" aria-expanded="' + open + '">' +
						'<span class="ic">' + sec.emoji + '</span><span class="nm">' + esc(sec.label) + '</span><span class="ct">' + sec.items.length + '</span><span class="chev" aria-hidden="true">⌄</span></button>';
					if (open) sec.items.forEach(function (k) { var p = catalog[k] || { n: k }; html += '<div class="ard-cm-prow">' + img(p) + '<span class="nm">' + esc(p.n) + '<br><span style="color:#1ca5a8;font-size:12px">' + (p.p != null ? money(p.p) : '') + '</span></span><span class="plus">+</span></div>'; });
					html += '</div>';
				});
				html += '<div class="ard-cm-pbtn">No grazie</div>';
			}
			document.getElementById('ard-cm-pv').innerHTML = html;
		}
		function renderAll() {
			renderSwitches(); renderBase(); renderMenus(); renderGroups(); renderDrinks(); renderPreview();
			if (openSearch) {
				var add = form.querySelector('[data-picker="' + CSS.escape(openSearch.id) + '"]');
				if (add) { var input = add.querySelector('input'); input.value = openSearch.q; input.focus(); showDrop(add); }
			}
		}
		function showDrop(add) {
			var info = pickerList(add.dataset.picker); if (!info) return;
			var drop = add.querySelector('.ard-cm-drop');
			drop.innerHTML = info.cats ? catDropHtml(info.list, add.querySelector('input').value) : dropHtml(info.list, add.querySelector('input').value, info.prefer);
			add.classList.add('is-open');
			placeDrop(add, drop);
		}
		// The list must never end up under the sticky Save bar: below the field if
		// there is room above the bar, otherwise above it, and never taller than the space.
		function placeDrop(add, drop) {
			var r = add.querySelector('input').getBoundingClientRect();
			var bar = document.querySelector('.ard-cm-bar').getBoundingClientRect();
			var limit = Math.min(window.innerHeight, bar.top) - 12;
			var below = limit - r.bottom - 4, above = r.top - 46 - 12;
			var up = below < 200 && above > below;
			add.classList.toggle('is-up', up);
			drop.style.maxHeight = Math.max(120, Math.min(280, up ? above : below)) + 'px';
		}
		window.addEventListener('scroll', function () { var a = form.querySelector('.ard-cm-add.is-open'); if (a) placeDrop(a, a.querySelector('.ard-cm-drop')); }, { passive: true });
		window.addEventListener('resize', function () { var a = form.querySelector('.ard-cm-add.is-open'); if (a) placeDrop(a, a.querySelector('.ard-cm-drop')); });

		/* ---------- events ---------- */
		form.addEventListener('click', function (e) {
			var t = e.target, el;
			if ((el = t.closest('#ard-cm-addmenu'))) {
				state.menus.push({ key: uid('m'), label: 'Nuovo menù', price: 0, enabled: true, groups: state.groups.length ? [state.groups[0].key] : [] });
				dirty(); renderAll();
				var inputs = form.querySelectorAll('[data-menu-label]'); var last = inputs[inputs.length - 1]; if (last) { last.focus(); last.select(); }
				return;
			}
			if ((el = t.closest('#ard-cm-addgroup'))) {
				if (state.groups.length >= 8) return;
				state.groups.push({ key: uid('g'), label: '', emoji: '', products: [] });
				dirty(); renderAll();
				var gl = form.querySelectorAll('[data-group-label]'); if (gl.length) gl[gl.length - 1].focus();
				return;
			}
			if ((el = t.closest('[data-menu-delete]'))) {
				var m = state.menus[+el.dataset.menuDelete];
				if (m && confirm('Eliminare il menù «' + m.label + '»?')) { state.menus.splice(+el.dataset.menuDelete, 1); dirty(); renderAll(); }
				return;
			}
			if ((el = t.closest('[data-group-delete]'))) {
				var g = state.groups[+el.dataset.groupDelete];
				var users = state.menus.filter(function (mm) { return mm.groups.indexOf(g.key) !== -1; });
				if (confirm('Eliminare il componente «' + (g.label || 'senza nome') + '»?' + (users.length ? ' Verrà tolto anche da: ' + users.map(function (u) { return u.label; }).join(', ') + '.' : ''))) {
					state.groups.splice(+el.dataset.groupDelete, 1);
					state.menus.forEach(function (mm) { mm.groups = mm.groups.filter(function (k) { return k !== g.key; }); });
					dirty(); renderAll();
				}
				return;
			}
			if ((el = t.closest('[data-menu-group]'))) {
				var parts = el.dataset.menuGroup.split('|'), menu = state.menus[+parts[0]], idx = menu.groups.indexOf(parts[1]);
				if (idx === -1) menu.groups.push(parts[1]); else menu.groups.splice(idx, 1);
				// keep the order of the components list
				menu.groups = state.groups.map(function (gg) { return gg.key; }).filter(function (k) { return menu.groups.indexOf(k) !== -1; });
				dirty(); renderAll(); return;
			}
			if ((el = t.closest('[data-emoji-open], [data-semoji-open]'))) { el.parentNode.classList.toggle('is-open'); return; }
			if ((el = t.closest('[data-semoji]'))) {
				var se = el.dataset.semoji.split('|'); state.drinks_icons[se[0]] = se[1]; tab = 'drinks'; dirty(); renderAll(); return;
			}
			if ((el = t.closest('[data-pv-sec]'))) { pvOpen[el.dataset.pvSec] = !pvOpen[el.dataset.pvSec]; tab = 'drinks'; renderPreview(); return; }
			if ((el = t.closest('[data-emoji]'))) {
				var ep = el.dataset.emoji.split('|'); state.groups[+ep[0]].emoji = ep[1]; dirty(); renderAll(); return;
			}
			var add = t.closest('.ard-cm-add');
			if ((el = t.closest('[data-remove]')) && t.closest('#ard-cm-base')) {
				var bl = baseEditable(), bp = bl.indexOf(el.dataset.remove);
				if (bp !== -1) bl.splice(bp, 1);
				openSearch = null; dirty(); renderAll(); return;
			}
			if ((el = t.closest('.ard-cm-opt')) && add && add.dataset.picker === 'base') {
				baseEditable().push(el.dataset.key);
				openSearch = { id: 'base', q: '' };
				dirty(); renderAll(); return;
			}
			if ((el = t.closest('[data-remove]'))) {
				var picker = t.closest('.ard-cm-comp, #ard-cm-drinks').querySelector('.ard-cm-add');
				var info = pickerList(picker.dataset.picker); var pos = info.list.indexOf(el.dataset.remove);
				if (pos !== -1) info.list.splice(pos, 1);
				openSearch = null; dirty(); renderAll(); return;
			}
			if ((el = t.closest('.ard-cm-opt')) && add) {
				pickerList(add.dataset.picker).list.push(el.dataset.key);
				openSearch = { id: add.dataset.picker, q: add.querySelector('input').value };
				dirty(); renderAll(); return;
			}
		});
		document.addEventListener('click', function (e) {
			if (!e.target.closest('.ard-cm-add')) { form.querySelectorAll('.ard-cm-add.is-open').forEach(function (a) { a.classList.remove('is-open'); }); openSearch = null; }
			if (!e.target.closest('.ard-cm-emoji')) { form.querySelectorAll('.ard-cm-emoji.is-open').forEach(function (a) { a.classList.remove('is-open'); }); }
		});
		form.addEventListener('focusin', function (e) {
			var add = e.target.closest('.ard-cm-add'); if (add && e.target.type === 'search') showDrop(add);
			var inDrinks = !!e.target.closest('#ard-cm-drinks-card'); var want = inDrinks ? 'drinks' : 'combo';
			if (want !== tab) { tab = want; renderPreview(); }
		});
		form.addEventListener('input', function (e) {
			var t = e.target, d = t.dataset;
			if (t.type === 'search') { var add = t.closest('.ard-cm-add'); openSearch = { id: add.dataset.picker, q: t.value }; showDrop(add); return; }
			if (d.dtext !== undefined) {
				var dt = d.dtext.split('|'), v = t.value.trim();
				if (v) state.drinks_texts[dt[0]][dt[1]] = t.value; else delete state.drinks_texts[dt[0]][dt[1]];
				if (d.dtext === 'title|it') document.getElementById('ard-cm-dtitle').textContent = (v || <?php echo wp_json_encode( $langs['it']['title'] ); ?>).replace(/[\s?]+$/, '');
				tab = 'drinks'; dirty(); renderPreview(); return;
			}
			if (d.menuLabel !== undefined) state.menus[+d.menuLabel].label = t.value;
			else if (d.menuPrice !== undefined) state.menus[+d.menuPrice].price = parseFloat(t.value.replace(',', '.')) || 0;
			else if (d.groupLabel !== undefined) { state.groups[+d.groupLabel].label = t.value; renderMenusKeepFocus(); }
			dirty(); renderPreview();
		});
		function renderMenusKeepFocus() { renderMenus(); }
		form.addEventListener('change', function (e) {
			var t = e.target, d = t.dataset;
			if (t.id === 'ard-cm-enabled') state.enabled = t.checked;
			else if (t.id === 'ard-cm-drinks-enabled') state.drinks_enabled = t.checked;
			else if (d.menuEnabled !== undefined) state.menus[+d.menuEnabled].enabled = t.checked;
			else if (d.groupLabel !== undefined) { renderGroups(); }
			else return;
			dirty(); renderSwitches(); renderMenus(); renderPreview();
		});
		form.addEventListener('keydown', function (e) {
			if (e.key !== 'Enter') return;
			var t = e.target;
			if (t.type === 'search') { e.preventDefault(); var add = t.closest('.ard-cm-add'); var first = add.querySelector('.ard-cm-opt'); if (first) first.click(); }
			else if (t.classList.contains('ard-cm-name') || t.type === 'number') { e.preventDefault(); t.blur(); }
		});
		document.querySelectorAll('.ard-cm-tabs button').forEach(function (b) { b.addEventListener('click', function () { tab = b.dataset.tab; renderPreview(); }); });
		form.addEventListener('submit', function () {
			document.getElementById('ard-cm-state').value = JSON.stringify(state);
			document.getElementById('ard-cm-dirty').classList.remove('is-on');
		});
		window.addEventListener('beforeunload', function (e) { if (document.getElementById('ard-cm-dirty').classList.contains('is-on')) { e.preventDefault(); e.returnValue = ''; } });
		renderAll();
	})();
	</script>
	<?php
}

/* ------------------------------------------------------------------- REST */

add_action( 'rest_api_init', function () {
	register_rest_route( 'mobile-admin/v1', '/combo-menu', array(
		'methods'             => 'GET',
		'callback'            => 'ARD_rest_get_combo_menu',
		'permission_callback' => '__return_true',
		'args'                => array(
			'site' => array( 'required' => true, 'sanitize_callback' => 'sanitize_text_field' ),
		),
	) );
} );

/**
 * GET /wp-json/mobile-admin/v1/combo-menu?site=biasca.littleinka.ch
 *   → { enabled, offers: [ { key, label, price, parts: [water|dessert] } ],
 *       waters: [product], desserts: [product], drinks_enabled, drinks: [product],
 *       poke_category_ids: [int], skip_category_ids: [int], skip_product_ids: [int] }
 * product = { id, name, price, image }. Only products this sede sells and has
 * in stock. "enabled" is false when the sede could not show a usable page.
 */
function ARD_rest_get_combo_menu( WP_REST_Request $request ) {
	$host = ARD_payment_methods_normalize_host( $request->get_param( 'site' ) );
	if ( ! array_key_exists( $host, ARD_payment_methods_sites() ) ) {
		return new WP_Error( 'ard_unknown_site', 'Sede sconosciuta', array( 'status' => 404 ) );
	}

	$cache_key = 'ard_combo_' . md5( $host );
	$data      = get_site_transient( $cache_key );
	if ( ! is_array( $data ) ) {
		$data = ARD_combo_build_for_host( $host );
		set_site_transient( $cache_key, $data, 5 * MINUTE_IN_SECONDS );
	}

	$response = rest_ensure_response( $data );
	$response->header( 'Cache-Control', 'no-cache, no-store, must-revalidate' );
	$response->header( 'X-LiteSpeed-Cache-Control', 'no-cache' );
	return $response;
}

/**
 * Upsell page in sections (2.18.0): the chosen products, in their order, grouped
 * by their category in this sede (the first one that is not a base category).
 * [ { key, label, emoji, products: [product] } ]. Apps before this read the flat `drinks`.
 */
function ARD_combo_drink_sections( array $settings, array $products, array $base_ids ) {
	$sections = array();
	foreach ( $settings['drinks'] as $key ) {
		$p = $products[ $key ] ?? null;
		if ( ! $p || ! $p['in_stock'] || null === $p['price'] ) {
			continue;
		}
		$label = '';
		foreach ( $p['categories'] as $cat ) {
			if ( ! in_array( $cat['id'], $base_ids, true ) ) {
				$label = $cat['name'];
				break;
			}
		}
		$label = '' !== $label ? ARD_combo_section_label( $label ) : 'Altro';
		$skey  = ARD_combo_name_key( $label );
		if ( ! isset( $sections[ $skey ] ) ) {
			$sections[ $skey ] = array(
				'key'      => $skey,
				'label'    => $label,
				'emoji'    => $settings['drinks_icons'][ $skey ] ?? ARD_combo_default_section_emoji( $label ),
				'products' => array(),
			);
		}
		$sections[ $skey ]['products'][] = array( 'id' => $p['id'], 'name' => $p['name'], 'price' => $p['price'], 'image' => $p['image'] );
	}
	return array_values( $sections );
}

function ARD_combo_build_for_host( $host ) {
	return ARD_combo_build_for_blog( ARD_combo_blog_id( $host ) );
}

/** Same data as the REST combo-menu, for one sede blog (also used by the web popup, see combo-menu-web.php). */
function ARD_combo_build_for_blog( $blog_id ) {
	$blog_id  = (int) $blog_id;
	$settings = ARD_combo_settings();
	$empty    = array(
		'enabled'           => false,
		'menus'             => array(),
		'groups'            => new stdClass(),
		'offers'            => array(),
		'waters'            => array(),
		'desserts'          => array(),
		'drinks_enabled'    => false,
		'drinks'            => array(),
		'drinks_sections'   => array(),
		'drinks_title'      => new stdClass(),
		'drinks_subtitle'   => new stdClass(),
		'poke_category_ids' => array(),
		'skip_category_ids' => array(),
		'skip_product_ids'  => array(),
	);
	if ( ! $blog_id ) {
		return $empty;
	}

	$switched = get_current_blog_id() !== $blog_id;
	if ( $switched ) {
		switch_to_blog( $blog_id );
	}
	$products = ARD_combo_blog_products();
	$poke_ids = ARD_combo_blog_base_categories( $settings['base_categories'] );
	if ( $switched ) {
		restore_current_blog();
	}

	$skip_categories = array();
	$skip_products   = array();
	$resolve         = static function ( array $keys ) use ( $products, &$skip_categories, &$skip_products ) {
		$out = array();
		foreach ( $keys as $key ) {
			if ( ! isset( $products[ $key ] ) ) {
				continue;
			}
			$p = $products[ $key ];
			// Already in the cart (even if out of stock now) means no offer.
			$skip_products[] = $p['id'];
			foreach ( $p['categories'] as $cat ) {
				$skip_categories[] = $cat['id'];
			}
			if ( ! $p['in_stock'] || null === $p['price'] ) {
				continue;
			}
			$out[] = array( 'id' => $p['id'], 'name' => $p['name'], 'price' => $p['price'], 'image' => $p['image'] );
		}
		return $out;
	};

	$data   = $empty;
	$groups = array();
	foreach ( $settings['groups'] as $group ) {
		$list = $resolve( (array) $group['products'] );
		if ( $list ) {
			$groups[ $group['key'] ] = array( 'label' => $group['label'], 'emoji' => $group['emoji'], 'products' => $list );
		}
	}
	$data['groups'] = $groups ? $groups : new stdClass();
	$data['drinks'] = $resolve( $settings['drinks'] );
	$data['drinks_sections'] = ARD_combo_drink_sections( $settings, $products, $poke_ids );

	foreach ( $settings['menus'] as $menu ) {
		if ( empty( $menu['enabled'] ) ) {
			continue;
		}
		// Shown only if this sede has something for every component.
		foreach ( $menu['groups'] as $g ) {
			if ( empty( $groups[ $g ] ) ) {
				continue 2;
			}
		}
		$data['menus'][] = array( 'key' => $menu['key'], 'label' => $menu['label'], 'price' => (float) $menu['price'], 'groups' => array_values( $menu['groups'] ) );
	}

	// Shape read by the app 3.2.0 OTA (only "water"/"dessert" components).
	$data['waters']   = $groups['water']['products'] ?? array();
	$data['desserts'] = $groups['dessert']['products'] ?? array();
	foreach ( $data['menus'] as $menu ) {
		if ( ! array_diff( $menu['groups'], array( 'water', 'dessert' ) ) ) {
			$data['offers'][] = array( 'key' => $menu['key'], 'label' => $menu['label'], 'price' => $menu['price'], 'parts' => $menu['groups'] );
		}
	}

	$data['enabled']           = $settings['enabled'] && ! empty( $data['menus'] );
	$data['drinks_enabled']    = $settings['drinks_enabled'] && ! empty( $data['drinks'] );
	// { lang: text } only for the languages written in Menù combinati; the app falls back to its own text.
	$data['drinks_title']      = $settings['drinks_texts']['title'] ? $settings['drinks_texts']['title'] : new stdClass();
	$data['drinks_subtitle']   = $settings['drinks_texts']['subtitle'] ? $settings['drinks_texts']['subtitle'] : new stdClass();
	$data['poke_category_ids'] = array_values( array_unique( $poke_ids ) );
	$data['base_auto']         = ! $settings['base_categories'];
	// Poké categories never count as "drink/dessert" even if a chosen product sits in one.
	$data['skip_category_ids'] = array_values( array_diff( array_unique( $skip_categories ), $data['poke_category_ids'] ) );
	$data['skip_product_ids']  = array_values( array_unique( $skip_products ) );
	return $data;
}
