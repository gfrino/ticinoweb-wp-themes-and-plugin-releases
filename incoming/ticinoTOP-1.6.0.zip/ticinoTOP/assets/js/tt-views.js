/**
 * Conta una lettura quando l'articolo resta aperto qualche secondo.
 * Nessun cookie e nessun dato personale: si invia solo l'ID dell'articolo.
 * Una lettura per articolo e per sessione del browser.
 */
(function () {
    var cfg = window.ttViews;
    if (!cfg || !cfg.id || !cfg.url || document.body.classList.contains('logged-in')) {
        return;
    }
    var key = 'ttv' + cfg.id;
    try {
        if (window.sessionStorage.getItem(key)) {
            return;
        }
    } catch (e) {}

    window.setTimeout(function () {
        if (document.visibilityState === 'hidden') {
            return;
        }
        try {
            window.sessionStorage.setItem(key, '1');
        } catch (e) {}
        window.fetch(cfg.url, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id: cfg.id }),
            credentials: 'omit',
            keepalive: true
        }).catch(function () {});
    }, 5000);
})();
