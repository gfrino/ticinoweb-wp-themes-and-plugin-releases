<?php
/**
 * Template Name: TT Magazine
 */
get_header(); 

$filters = tt_blog_filters();

// 1. Articolo in evidenza: il primo del risultato (con filtri attivi è il primo dei filtrati)
$featured_query = new WP_Query( tt_blog_query_args( $filters, 1, 1 ) );
$total_found    = (int) $featured_query->found_posts;

$featured_id   = 0;
$featured_post = null;

if ($featured_query->have_posts()) {
    $featured_query->the_post();
    $featured_id = get_the_ID();

    $categories = get_the_category();

    $featured_post = [
        'id' => $featured_id,
        'title' => get_the_title(),
        'excerpt' => get_the_excerpt() ?: wp_trim_words(get_the_content(), 25),
        'img' => get_the_post_thumbnail_url($featured_id, 'full') ?: get_stylesheet_directory_uri() . '/images/category-default.jpg',
        'url' => get_permalink(),
        'category' => ($categories) ? $categories[0]->name : 'Trend & Insight',
        'date' => get_the_date('j F Y'),
        'views' => ( 'letti' === $filters['order'] ) ? tt_get_post_views( $featured_id ) : 0,
    ];
    wp_reset_postdata();
}

// 2. Griglia: gli altri articoli, stessi filtri e stesso ordine
$blog_query = new WP_Query( tt_blog_query_args( $filters, 1, 9, $featured_id ) );
?>

<main class="tt-main" style="background: var(--tt-gray-light); min-height: 100vh; padding-bottom: 80px;">
    <section class="tt-section" style="padding-top: 80px;">
        <div class="tt-container">
            <div style="text-align: center; margin-bottom: 60px;">
                <span class="tt-badge" style="background: rgba(10,25,47,0.05); border-color: rgba(10,25,47,0.1); color: var(--tt-blue-notte); margin-bottom: 16px;">News</span>
                <h1 class="animate-hero-title" style="font-family: var(--tt-font-serif); font-size: 56px; margin-bottom: 16px; color: var(--tt-black);">Storie & Insight</h1>
                <p class="animate-hero-subtitle" style="font-size: 20px; color: var(--tt-gray-text); max-width: 600px; margin: 0 auto; line-height: 1.6;">Letture di approfondimento sul mondo della reputazione digitale, dell'intelligenza artificiale e delle eccellenze del Ticino.</p>
            </div>

            <?php tt_render_blog_filters( $filters ); ?>
            <?php if ( $filters['active'] && $total_found > 0 ) : ?>
                <p class="tt-filters-count" role="status"><?php echo esc_html( sprintf( _n( '%d articolo', '%d articoli', $total_found, 'ticinotop' ), $total_found ) ); ?></p>
            <?php endif; ?>

            <?php if ($featured_post) : ?>
                <!-- Featured Article -->
                <div class="tt-card reveal-on-scroll tt-featured-hero" style="display: flex; flex-direction: row; margin-bottom: 60px; min-height: 450px; overflow: hidden; border-radius: var(--tt-radius-lg); box-shadow: var(--tt-shadow-premium); border: 1px solid var(--tt-gray-border); padding: 0;">
                    <div class="tt-featured-hero-img" style="width: 55%; background: url('<?php echo esc_url($featured_post['img']); ?>') center/cover; position: relative; min-height: 350px;">
                        <div style="position: absolute; inset: 0; background: linear-gradient(to right, transparent 50%, rgba(255,255,255,0.05));"></div>
                    </div>
                    <div class="tt-featured-hero-body" style="width: 45%; padding: 48px; display: flex; flex-direction: column; justify-content: center; background: var(--tt-white);">
                        <div class="tt-badge tt-badge-dark" style="margin-bottom: 24px; align-self: flex-start; background: var(--tt-blue-notte); border-color: var(--tt-blue-notte); color: var(--tt-white);"><?php echo esc_html($featured_post['category']); ?></div>
                        <?php if (tt_show_post_dates()) : ?><span style="font-size: 13px; color: var(--tt-gray-text); margin-bottom: 12px; font-weight: 500;"><?php echo esc_html($featured_post['date']); ?></span><?php endif; ?>
                        <h2 style="font-family: var(--tt-font-serif); font-size: 36px; margin: 0 0 16px 0; line-height: 1.2; color: var(--tt-black);">
                            <a class="tt-featured-title-link" href="<?php echo esc_url($featured_post['url']); ?>" style="color: inherit; text-decoration: none; transition: color 0.3s ease;"><?php echo esc_html($featured_post['title']); ?></a>
                        </h2>
                        <p style="font-size: 16px; color: var(--tt-gray-text); margin-bottom: 32px; line-height: 1.6;"><?php echo esc_html($featured_post['excerpt']); ?></p>
                        <?php if ( $featured_post['views'] > 0 ) : ?><p class="tt-views-badge" style="margin: -16px 0 24px;"><?php echo esc_html( number_format_i18n( $featured_post['views'] ) ); ?> <?php echo esc_html( _n( 'lettura', 'letture', $featured_post['views'], 'ticinotop' ) ); ?></p><?php endif; ?>
                        <a href="<?php echo esc_url($featured_post['url']); ?>" class="tt-btn tt-btn-primary" style="align-self: flex-start;">Leggi l'Articolo</a>
                    </div>
                </div>
            <?php endif; ?>

            <?php if ( $blog_query->have_posts() ) : ?>
                <!-- Grid Articles -->
                <div class="tt-grid-3 reveal-grid">
                    <?php while ( $blog_query->have_posts() ) : $blog_query->the_post(); tt_render_blog_card( get_the_ID(), $filters ); endwhile; wp_reset_postdata(); ?>
                </div>

                <!-- Load More Button -->
                <?php if ( $blog_query->max_num_pages > 1 ) : ?>
                    <div style="text-align: center; margin-top: 50px;">
                        <button id="tt-load-more-blog" class="tt-btn tt-btn-primary" data-page="1" data-featured="<?php echo esc_attr($featured_id); ?>" data-cat="<?php echo esc_attr($filters['cat']); ?>" data-tag="<?php echo esc_attr($filters['tag']); ?>" data-order="<?php echo esc_attr($filters['order']); ?>" data-ajaxurl="<?php echo admin_url('admin-ajax.php'); ?>" data-max="<?php echo esc_attr($blog_query->max_num_pages); ?>">
                            CARICA ALTRI ARTICOLI
                        </button>
                    </div>
                <?php endif; ?>

            <?php elseif (!$featured_post) : ?>
                <div class="tt-card" style="text-align: center; padding: 60px; background: var(--tt-white);">
                    <?php if ( $filters['active'] ) : ?>
                        <p style="color: var(--tt-gray-text); font-size: 18px; margin: 0 0 20px;">Nessun articolo corrisponde a questi filtri.</p>
                        <a class="tt-btn tt-btn-primary" href="<?php echo esc_url( tt_blog_page_url() ); ?>">Azzera i filtri</a>
                    <?php else : ?>
                        <p style="color: var(--tt-gray-text); font-size: 18px; margin: 0;">Nessun articolo pubblicato nel blog al momento. Torna presto per i prossimi aggiornamenti!</p>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
    </section>
</main>

<style>
.tt-blog-card:hover {
    transform: translateY(-6px);
    border-color: rgba(212, 175, 55, 0.4) !important;
    box-shadow: var(--tt-shadow-premium) !important;
}
.tt-blog-card:hover h3, .tt-featured-title-link:hover {
    color: var(--tt-gold-champagne) !important;
}
#tt-load-more-blog {
    cursor: pointer;
    transition: opacity 0.3s ease;
}
#tt-load-more-blog.loading {
    opacity: 0.7;
    pointer-events: none;
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('.tt-filters select').forEach(function(sel) {
        sel.addEventListener('change', function() { sel.form.submit(); });
    });
    const loadMoreBtn = document.getElementById('tt-load-more-blog');
    if (loadMoreBtn) {
        loadMoreBtn.addEventListener('click', function() {
            const btn = this;
            const ajaxurl = btn.getAttribute('data-ajaxurl');
            let page = parseInt(btn.getAttribute('data-page'));
            const maxPage = parseInt(btn.getAttribute('data-max'));
            const featuredId = btn.getAttribute('data-featured');
            
            page++; // Increment page number for the request
            
            btn.classList.add('loading');
            btn.innerText = 'CARICAMENTO...';
            
            const formData = new FormData();
            formData.append('action', 'tt_load_more_posts');
            formData.append('page', page);
            formData.append('featured', featuredId);
            formData.append('categoria', btn.getAttribute('data-cat') || '');
            formData.append('argomento', btn.getAttribute('data-tag') || '');
            formData.append('ordine', btn.getAttribute('data-order') || '');
            
            fetch(ajaxurl, {
                method: 'POST',
                body: formData
            })
            .then(response => response.text())
            .then(data => {
                btn.classList.remove('loading');
                btn.innerText = 'CARICA ALTRI ARTICOLI';
                
                if (data.trim() !== '') {
                    const grid = document.querySelector('.tt-grid-3');
                    if (grid) {
                        grid.insertAdjacentHTML('beforeend', data);
                        btn.setAttribute('data-page', page);
                        
                        if (page >= maxPage) {
                            btn.style.display = 'none';
                        }
                    }
                } else {
                    btn.style.display = 'none';
                }
            })
            .catch(error => {
                console.error('Error loading more posts:', error);
                btn.classList.remove('loading');
                btn.innerText = 'CARICA ALTRI ARTICOLI';
            });
        });
    }
});
</script>

<?php get_footer(); ?>
