<?php
/**
 * Letture degli articoli (per il filtro "Più letti" della pagina News).
 *
 * Un piccolo script conta una lettura quando l'articolo resta aperto qualche secondo
 * (la pagina può essere servita dalla cache, quindi il conteggio non passa da PHP).
 * Nessun cookie e nessun dato personale: nel database finisce solo il totale in
 * `_tt_views`; l'IP serve solo a calcolare per 30 minuti un codice anti-doppioni.
 *
 * @package Ticino Top
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/** Totale letture di un articolo. */
function tt_get_post_views( $post_id ) {
    return (int) get_post_meta( (int) $post_id, '_tt_views', true );
}

/** Script di conteggio, solo sugli articoli. */
function tt_views_enqueue() {
    if ( ! is_singular( 'post' ) ) {
        return;
    }
    $file = get_stylesheet_directory() . '/assets/js/tt-views.js';
    wp_enqueue_script( 'tt-views', get_stylesheet_directory_uri() . '/assets/js/tt-views.js', array(), file_exists( $file ) ? filemtime( $file ) : null, true );
    wp_localize_script( 'tt-views', 'ttViews', array(
        'id'  => get_queried_object_id(),
        'url' => esc_url_raw( rest_url( 'tt/v1/view' ) ),
    ) );
}
add_action( 'wp_enqueue_scripts', 'tt_views_enqueue', 30 );

add_action( 'rest_api_init', function () {
    register_rest_route( 'tt/v1', '/view', array(
        'methods'             => 'POST',
        'permission_callback' => '__return_true',
        'callback'            => 'tt_views_rest_count',
        'args'                => array(
            'id' => array( 'type' => 'integer', 'required' => true, 'sanitize_callback' => 'absint' ),
        ),
    ) );
} );

function tt_views_rest_count( WP_REST_Request $request ) {
    $id   = absint( $request->get_param( 'id' ) );
    $post = $id ? get_post( $id ) : null;
    $none = new WP_REST_Response( array( 'counted' => false ), 200 );

    if ( ! $post || 'post' !== $post->post_type || 'publish' !== $post->post_status ) {
        return $none;
    }

    $ua = isset( $_SERVER['HTTP_USER_AGENT'] ) ? (string) wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) : '';
    if ( '' === $ua || preg_match( '/bot|crawl|spider|slurp|headless|lighthouse|gtmetrix|pingdom|monitor|preview|curl|wget|python|facebookexternalhit/i', $ua ) ) {
        return $none;
    }

    $ip  = isset( $_SERVER['REMOTE_ADDR'] ) ? (string) $_SERVER['REMOTE_ADDR'] : '';
    $key = 'tt_v_' . md5( $id . '|' . $ip . '|' . $ua );
    if ( get_transient( $key ) ) {
        return $none;
    }
    set_transient( $key, 1, 30 * MINUTE_IN_SECONDS );

    global $wpdb;
    $updated = $wpdb->query( $wpdb->prepare(
        "UPDATE {$wpdb->postmeta} SET meta_value = meta_value + 1 WHERE post_id = %d AND meta_key = '_tt_views'",
        $id
    ) );
    if ( ! $updated && ! add_post_meta( $id, '_tt_views', 1, true ) ) {
        $wpdb->query( $wpdb->prepare(
            "UPDATE {$wpdb->postmeta} SET meta_value = meta_value + 1 WHERE post_id = %d AND meta_key = '_tt_views'",
            $id
        ) );
    }
    wp_cache_delete( $id, 'post_meta' );

    return new WP_REST_Response( array( 'counted' => true ), 200 );
}

// Colonna "Letture" nell'elenco articoli della bacheca.
add_filter( 'manage_post_posts_columns', function ( $columns ) {
    $columns['tt_views'] = 'Letture';
    return $columns;
} );
add_action( 'manage_post_posts_custom_column', function ( $column, $post_id ) {
    if ( 'tt_views' === $column ) {
        echo esc_html( number_format_i18n( tt_get_post_views( $post_id ) ) );
    }
}, 10, 2 );
