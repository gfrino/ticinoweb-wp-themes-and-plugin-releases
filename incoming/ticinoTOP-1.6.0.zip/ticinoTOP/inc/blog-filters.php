<?php
/**
 * Filtri della pagina News: ordine (più recenti / più letti), categoria e tag.
 *
 * I filtri stanno nell'indirizzo (?categoria=…&argomento=…&ordine=letti): la pagina funziona anche
 * senza JavaScript e si può condividere. "argomento" e non "tag" perché `tag` è una variabile
 * riservata di WordPress e trasformerebbe la pagina in un archivio.
 *
 * @package Ticino Top
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/** Indirizzo della pagina con il modello "TT Magazine" (fallback /news/). */
function tt_blog_page_url() {
    static $url = null;
    if ( null !== $url ) {
        return $url;
    }
    $pages = get_posts( array(
        'post_type'        => 'page',
        'post_status'      => 'publish',
        'meta_key'         => '_wp_page_template',
        'meta_value'       => 'template-blog.php',
        'posts_per_page'   => 1,
        'fields'           => 'ids',
        'no_found_rows'    => true,
        'suppress_filters' => true,
    ) );
    $url = $pages ? get_permalink( $pages[0] ) : home_url( '/news/' );
    return $url;
}

/**
 * Filtri validi presi da $_GET o da un array (richiesta AJAX).
 *
 * @param array|null $src Sorgente (default $_GET).
 * @return array{cat:string,tag:string,order:string,active:bool}
 */
function tt_blog_filters( $src = null ) {
    $src = is_array( $src ) ? $src : $_GET; // phpcs:ignore WordPress.Security.NonceVerification -- filtri di sola lettura.
    $cat = isset( $src['categoria'] ) ? sanitize_title( wp_unslash( $src['categoria'] ) ) : '';
    $tag = isset( $src['argomento'] ) ? sanitize_title( wp_unslash( $src['argomento'] ) ) : '';
    if ( '' !== $cat && ! get_term_by( 'slug', $cat, 'category' ) ) {
        $cat = '';
    }
    if ( '' !== $tag && ! get_term_by( 'slug', $tag, 'post_tag' ) ) {
        $tag = '';
    }
    $order = ( isset( $src['ordine'] ) && 'letti' === sanitize_key( wp_unslash( $src['ordine'] ) ) ) ? 'letti' : 'recenti';

    return array(
        'cat'    => $cat,
        'tag'    => $tag,
        'order'  => $order,
        'active' => ( '' !== $cat || '' !== $tag || 'letti' === $order ),
    );
}

/** Argomenti di WP_Query per i filtri. */
function tt_blog_query_args( array $filters, $paged = 1, $per_page = 9, $exclude_id = 0 ) {
    $args = array(
        'post_type'           => 'post',
        'post_status'         => 'publish',
        'posts_per_page'      => (int) $per_page,
        'paged'               => max( 1, (int) $paged ),
        'ignore_sticky_posts' => true,
    );
    if ( $exclude_id > 0 ) {
        $args['post__not_in'] = array( (int) $exclude_id );
    }

    $tax = array();
    if ( '' !== $filters['cat'] ) {
        $tax[] = array( 'taxonomy' => 'category', 'field' => 'slug', 'terms' => $filters['cat'] );
    }
    if ( '' !== $filters['tag'] ) {
        $tax[] = array( 'taxonomy' => 'post_tag', 'field' => 'slug', 'terms' => $filters['tag'] );
    }
    if ( $tax ) {
        $args['tax_query'] = array_merge( array( 'relation' => 'AND' ), $tax );
    }

    if ( 'letti' === $filters['order'] ) {
        // Gli articoli senza letture restano in coda, dal più recente.
        $args['meta_query'] = array(
            'relation'     => 'OR',
            'tt_views'     => array( 'key' => '_tt_views', 'type' => 'NUMERIC', 'compare' => 'EXISTS' ),
            'tt_no_views'  => array( 'key' => '_tt_views', 'compare' => 'NOT EXISTS' ),
        );
        $args['orderby'] = array( 'tt_views' => 'DESC', 'date' => 'DESC' );
    } else {
        $args['orderby'] = 'date';
        $args['order']   = 'DESC';
    }

    return $args;
}

/** Scheda articolo della griglia (usata dalla pagina e da "Carica altri"). */
function tt_render_blog_card( $post_id, array $filters = array() ) {
    $title      = get_the_title( $post_id );
    $excerpt    = get_the_excerpt( $post_id ) ?: wp_trim_words( get_post_field( 'post_content', $post_id ), 25 );
    $img        = get_the_post_thumbnail_url( $post_id, 'full' ) ?: get_stylesheet_directory_uri() . '/images/category-default.jpg';
    $categories = get_the_category( $post_id );
    $category   = $categories ? $categories[0]->name : 'Trend & Insight';
    $views      = ( ! empty( $filters['order'] ) && 'letti' === $filters['order'] ) ? tt_get_post_views( $post_id ) : 0;
    ?>
    <a href="<?php echo esc_url( get_permalink( $post_id ) ); ?>" class="tt-card tt-blog-card" style="display: flex; flex-direction: column; text-decoration: none; border-radius: var(--tt-radius-md); overflow: hidden; background: var(--tt-white); box-shadow: var(--tt-shadow-sm); border: 1px solid var(--tt-gray-border); height: 100%; transition: all 0.3s ease; padding: 0; box-shadow: none;">
        <div style="height: 240px; background: url('<?php echo esc_url( $img ); ?>') center/cover; position: relative;">
            <div style="position: absolute; top: 16px; left: 16px;">
                <span class="tt-badge" style="background: rgba(255,255,255,0.95); backdrop-filter: blur(4px); -webkit-backdrop-filter: blur(4px); color: var(--tt-black); border-color: rgba(255,255,255,0.5); font-weight: 600;"><?php echo esc_html( $category ); ?></span>
            </div>
        </div>
        <div style="padding: 28px; flex-grow: 1; display: flex; flex-direction: column; justify-content: space-between; background: var(--tt-white);">
            <div>
                <?php if ( tt_show_post_dates() ) : ?><span style="color: var(--tt-gray-text); font-size: 12px; display: block; margin-bottom: 12px; font-weight: 500;"><?php echo esc_html( get_the_date( 'j F Y', $post_id ) ); ?></span><?php endif; ?>
                <h3 style="font-size: 22px; margin: 0 0 12px 0; font-family: var(--tt-font-serif); color: var(--tt-black); line-height: 1.3; transition: color 0.3s ease;"><?php echo esc_html( $title ); ?></h3>
                <p style="font-size: 14.5px; color: var(--tt-gray-text); margin: 0; line-height: 1.6; display: -webkit-box; -webkit-line-clamp: 3; -webkit-box-orient: vertical; overflow: hidden;"><?php echo esc_html( $excerpt ); ?></p>
            </div>
            <div style="margin-top: 24px; font-weight: 600; font-size: 14px; color: var(--tt-gold-champagne); display: flex; align-items: center; justify-content: space-between; gap: 4px;">
                <span>Leggi Articolo →</span>
                <?php if ( $views > 0 ) : ?><span class="tt-views-badge"><?php echo esc_html( number_format_i18n( $views ) ); ?> <?php echo esc_html( _n( 'lettura', 'letture', $views, 'ticinotop' ) ); ?></span><?php endif; ?>
            </div>
        </div>
    </a>
    <?php
}

/** Barra dei filtri. */
function tt_render_blog_filters( array $filters ) {
    $base = tt_blog_page_url();
    $cats = get_terms( array( 'taxonomy' => 'category', 'hide_empty' => true, 'orderby' => 'count', 'order' => 'DESC', 'number' => 100 ) );
    $tags = get_terms( array( 'taxonomy' => 'post_tag', 'hide_empty' => true, 'orderby' => 'count', 'order' => 'DESC', 'number' => 100 ) );
    // Nei menu solo categorie e tag con almeno 2 articoli (più il filtro attivo): tanti tag da un solo articolo
    // renderebbero il menu ingestibile; quelli specifici si raggiungono dai tag sotto l'articolo.
    $keep = static function ( $terms, $selected ) {
        if ( is_wp_error( $terms ) ) {
            return array();
        }
        return array_values( array_filter( $terms, static function ( $term ) use ( $selected ) {
            return $term->count >= 2 || $term->slug === $selected;
        } ) );
    };
    $cats = $keep( $cats, $filters['cat'] );
    $tags = $keep( $tags, $filters['tag'] );

    $link = static function ( $order ) use ( $base, $filters ) {
        $args = array_filter( array(
            'categoria' => $filters['cat'],
            'argomento' => $filters['tag'],
            'ordine'    => 'letti' === $order ? 'letti' : '',
        ) );
        return $args ? add_query_arg( $args, $base ) : $base;
    };
    ?>
    <form class="tt-filters" method="get" action="<?php echo esc_url( $base ); ?>" aria-label="Filtra gli articoli">
        <div class="tt-filters-order" role="group" aria-label="Ordine degli articoli">
            <a class="tt-chip<?php echo 'recenti' === $filters['order'] ? ' is-active' : ''; ?>" href="<?php echo esc_url( $link( 'recenti' ) ); ?>"<?php echo 'recenti' === $filters['order'] ? ' aria-current="true"' : ''; ?>>Più recenti</a>
            <a class="tt-chip<?php echo 'letti' === $filters['order'] ? ' is-active' : ''; ?>" href="<?php echo esc_url( $link( 'letti' ) ); ?>"<?php echo 'letti' === $filters['order'] ? ' aria-current="true"' : ''; ?>>Più letti</a>
        </div>
        <?php if ( 'letti' === $filters['order'] ) : ?><input type="hidden" name="ordine" value="letti"><?php endif; ?>

        <?php if ( $cats ) : ?>
            <label class="tt-filter-field">
                <span>Categoria</span>
                <select name="categoria">
                    <option value="">Tutte le categorie</option>
                    <?php foreach ( $cats as $term ) : ?>
                        <option value="<?php echo esc_attr( $term->slug ); ?>"<?php selected( $filters['cat'], $term->slug ); ?>><?php echo esc_html( html_entity_decode( $term->name, ENT_QUOTES, 'UTF-8' ) ); ?> (<?php echo (int) $term->count; ?>)</option>
                    <?php endforeach; ?>
                </select>
            </label>
        <?php endif; ?>
        <?php if ( $tags ) : ?>
            <label class="tt-filter-field">
                <span>Tag</span>
                <select name="argomento">
                    <option value="">Tutti i tag</option>
                    <?php foreach ( $tags as $term ) : ?>
                        <option value="<?php echo esc_attr( $term->slug ); ?>"<?php selected( $filters['tag'], $term->slug ); ?>><?php echo esc_html( html_entity_decode( $term->name, ENT_QUOTES, 'UTF-8' ) ); ?> (<?php echo (int) $term->count; ?>)</option>
                    <?php endforeach; ?>
                </select>
            </label>
        <?php endif; ?>
        <button type="submit" class="tt-btn tt-btn-primary tt-filters-apply">Filtra</button>
        <?php if ( $filters['active'] ) : ?><a class="tt-filters-reset" href="<?php echo esc_url( $base ); ?>">Azzera filtri</a><?php endif; ?>
    </form>
    <?php
}

// Le viste filtrate non vanno indicizzate: la pagina base resta l'unica da posizionare.
add_filter( 'wp_robots', function ( $robots ) {
    if ( is_page_template( 'template-blog.php' ) && tt_blog_filters()['active'] ) {
        $robots['noindex'] = true;
        $robots['follow']  = true;
        unset( $robots['index'] );
    }
    return $robots;
} );
