/* Albatros: progressive navigation and direct contact links. */
(() => {
  'use strict';
  document.documentElement.classList.add('alb-js');
  const root = document.documentElement;
  const header = document.querySelector('.alb-header');
  const toggle = document.querySelector('.alb-menu-toggle');
  const label = toggle?.querySelector('.alb-menu-label');
  const navigation = document.querySelector('.alb-nav');
  const compact = window.matchMedia('(max-width: 760px)');
  const positionMenu = () => {
    root.style.setProperty('--alb-menu-top', `${Math.ceil(header?.getBoundingClientRect().bottom || 83)}px`);
  };
  const setMenu = (open) => {
    if (!toggle || !navigation) return;
    positionMenu();
    toggle.setAttribute('aria-expanded', String(open));
    if (label) label.textContent = open ? toggle.dataset.closeLabel : toggle.dataset.openLabel;
    navigation.classList.toggle('is-open', open);
    navigation.inert = compact.matches && !open;
    root.classList.toggle('alb-menu-open', compact.matches && open);
  };
  const closeMenu = (restoreFocus = false) => {
    setMenu(false);
    if (restoreFocus) toggle?.focus();
  };
  setMenu(false);
  toggle?.addEventListener('click', () => setMenu(toggle.getAttribute('aria-expanded') !== 'true'));
  navigation?.addEventListener('click', (event) => {
    const link = event.target.closest('a');
    if (!link) return;
    const wasOpen = toggle?.getAttribute('aria-expanded') === 'true';
    closeMenu();
    // Keep native anchor navigation, then leave keyboard focus at its destination.
    const url = new URL(link.href, window.location.href);
    const sameTabClick = !event.defaultPrevented && event.button === 0 && !event.metaKey && !event.ctrlKey && !event.shiftKey && !event.altKey && (!link.target || link.target === '_self') && !link.hasAttribute('download');
    if (wasOpen && sameTabClick && url.origin === location.origin && url.pathname === location.pathname && url.hash) {
      let fragment = url.hash.slice(1);
      try { fragment = decodeURIComponent(fragment); } catch (_) { /* Keep malformed CMS fragments literal. */ }
      const section = document.getElementById(fragment);
      const destination = section?.querySelector('h1,h2') || section;
      if (destination) requestAnimationFrame(() => {
        const previous = destination.getAttribute('tabindex');
        destination.setAttribute('tabindex', '-1');
        destination.focus({preventScroll:true});
        destination.addEventListener('blur', () => {
          if (previous === null) destination.removeAttribute('tabindex');
          else destination.setAttribute('tabindex', previous);
        }, {once:true});
      });
    }
  });
  header?.addEventListener('focusout', (event) => {
    if (event.relatedTarget && !header.contains(event.relatedTarget)) closeMenu();
  });
  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape' && toggle?.getAttribute('aria-expanded') === 'true') closeMenu(true);
  });
  compact.addEventListener('change', () => closeMenu());
  window.addEventListener('resize', positionMenu, {passive:true});
  document.querySelector('.alb-cookie-settings')?.addEventListener('click', () => {
    // The parent removes its consent UI after a choice. Reload it after clearing only its cookies.
    ['tw_cookie_consent', 'tw_cookie_preferences'].forEach((key) => {
      document.cookie = `${key}=; max-age=0; path=/; SameSite=Lax`;
    });
    window.location.reload();
  });
  // Native page buttons keep #servizi as their no-JS fallback. The editor's route
  // class references a CMS service key, never a hardcoded title or generated ID.
  document.querySelectorAll('.alb-audience .wp-block-button').forEach((button) => {
    const route = [...button.classList].find((name) => name.startsWith('alb-route-'))?.slice(10);
    const card = route && [...document.querySelectorAll('.alb-service[data-service-key]')].find((item) => item.dataset.serviceKey === route);
    const point = card?.previousElementSibling;
    const link = button.querySelector('a');
    if (link && point?.classList.contains('alb-service-waypoint') && point.id) link.setAttribute('href', `#${encodeURIComponent(point.id)}`);
  });
  const contacts = document.querySelector('.alb-contact-direct');
  // Direct contacts replace the fixed shortcuts while they are actually in view.
  if (contacts && 'IntersectionObserver' in window) {
    new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        document.documentElement.classList.toggle('alb-contact-visible', entry.isIntersecting);
      });
    }, {rootMargin:'-100px 0px -80px 0px'}).observe(contacts);
  }
})();
