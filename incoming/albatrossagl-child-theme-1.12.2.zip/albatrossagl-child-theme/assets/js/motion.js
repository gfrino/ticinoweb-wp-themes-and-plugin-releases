/* Albatros — native scroll and continuous, preference-aware light loops. */
(() => {
  'use strict';
  const root = document.documentElement;
  const heroStage = document.querySelector('.alb-hero-stage');
  const hero = document.querySelector('.alb-hero-media') || heroStage;
  if (!hero || !('IntersectionObserver' in window)) return;
  const heroScene = heroStage || hero;

  const reduced = window.matchMedia('(prefers-reduced-motion: reduce)');
  const desktop = window.matchMedia('(min-width: 1024px) and (min-height: 650px)');
  const sideIndex = window.matchMedia('(min-width: 1280px) and (min-height: 650px)');
  const finePointer = window.matchMedia('(hover: hover) and (pointer: fine)');
  const cards = [...document.querySelectorAll('.alb-service')];
  const waypoints = [...document.querySelectorAll('.alb-service-waypoint')];
  const deck = document.querySelector('.alb-service-index');
  const deckLinks = [...document.querySelectorAll('.alb-deck-links a')];
  const about = document.querySelector('.alb-about-photo');
  const header = document.querySelector('.alb-header');
  const progress = document.querySelector('.alb-scroll-progress');
  const atmosphere = document.querySelector('.alb-atmosphere');
  const main = document.querySelector('main');
  const subscription = document.querySelector('.alb-subscription');
  const serviceSection = document.getElementById('servizi');
  const pathPhotos = [...document.querySelectorAll('.alb-path-photo')];
  const panels = [subscription, document.querySelector('.alb-contact-section')].filter(Boolean);
  const journeyNodes = [...pathPhotos, about, ...panels].filter(Boolean);
  const journeyVisible = new Set();
  const effects = new Set();
  const activePhotos = new Set();
  const seen = new WeakSet();
  try { localStorage.removeItem('albatros_motion'); } catch (_) { /* Obsolete UI preference is optional. */ }
  let frame = 0;
  let heroVisible = true;
  let aboutVisible = false;
  let atmosphereVisible = true;
  let lightStart = 0;
  let lightHeight = 1;
  let sceneStart = 0;
  let sceneRange = 1;
  let pointerBounds;
  let pointerX = 0;
  let pointerY = 0;
  let photoPointer = null;
  let stickyTop = 124;
  let viewportHeight = window.innerHeight;
  let scrollRange = 1;
  let followedScroll = window.scrollY;
  let previousTick = 0;
  const enabled = () => !reduced.matches;
  const clamp = (value, min = 0, max = 1) => Math.max(min, Math.min(max, value));

  const links = [...document.querySelectorAll('.alb-menu a')].map((link) => {
    const url = new URL(link.href, window.location.href);
    return {link, section: url.hash ? document.getElementById(decodeURIComponent(url.hash.slice(1))) : null};
  }).filter((item) => item.section);

  const animate = (element, keyframes, options = {}) => {
    if (!element || !enabled() || document.hidden || typeof element.animate !== 'function') return;
    const effect = element.animate(keyframes, {duration:700, easing:'cubic-bezier(.16,1,.3,1)', ...options});
    effects.add(effect);
    effect.finished.then(() => effects.delete(effect), () => effects.delete(effect));
  };
  const schedule = () => {
    if (!frame && !document.hidden) frame = requestAnimationFrame(render);
  };
  const measure = () => {
    viewportHeight = window.innerHeight;
    const headerEdge = Math.ceil(header?.getBoundingClientRect().bottom || 104);
    // The index sits beside the folios, never above their sticky position.
    stickyTop = headerEdge + 24;
    const scrollPadding = parseFloat(getComputedStyle(root).scrollPaddingTop) || 0;
    scrollRange = Math.max(1, document.documentElement.scrollHeight - viewportHeight);
    sceneStart = window.scrollY + heroScene.getBoundingClientRect().top - headerEdge;
    sceneRange = Math.max(1, heroScene.offsetHeight * .8);
    if (atmosphere && main) {
      const mainTop = main.getBoundingClientRect().top;
      lightStart = window.scrollY + mainTop;
      const boundary = subscription ? subscription.getBoundingClientRect().top : serviceSection ? serviceSection.getBoundingClientRect().bottom : mainTop + viewportHeight;
      lightHeight = Math.max(1, boundary - mainTop);
    }
    root.style.setProperty('--alb-sticky-top', `${stickyTop}px`);
    root.style.setProperty('--alb-deck-top', `${stickyTop}px`);
    root.style.setProperty('--alb-service-anchor-offset', `${Math.max(0, stickyTop - scrollPadding + 8)}px`);
    atmosphere?.style.setProperty('--alb-light-height', `${Math.ceil(lightHeight)}px`);
    pointerBounds = undefined;
    schedule();
  };

  function render(now) {
    frame = 0;
    if (document.hidden) return;
    const running = enabled();
    const positions = cards.map((card) => card.getBoundingClientRect());
    // Static waypoints keep the hand-off independent of the transformed sticky planes.
    const stops = waypoints.map((point) => point.getBoundingClientRect().top);
    const heights = cards.map((card) => card.offsetHeight);
    const photoRect = photoPointer?.photo ? photoPointer.photo.getBoundingClientRect() : null;
    const photoX = photoRect ? clamp((photoPointer.clientX - photoRect.left) / photoRect.width * 2 - 1, -1, 1) * 6 : 0;
    const photoY = photoRect ? clamp((photoPointer.clientY - photoRect.top) / photoRect.height * 2 - 1, -1, 1) * 4 : 0;
    const aboutRect = aboutVisible && about ? about.getBoundingClientRect() : null;
    const sections = links.map(({section}) => section.getBoundingClientRect().top);
    const journeyRunning = running && desktop.matches;
    const journeyRects = journeyRunning ? [...journeyVisible].map((node) => ({node, rect:node.getBoundingClientRect()})) : [];
    // Only decoration follows with a short, bounded tail. The document and
    // chapter navigation always use the actual native scroll position.
    const distance = window.scrollY - followedScroll;
    const dt = previousTick ? Math.min(50, now - previousTick) : 16.7;
    previousTick = now;
    if (!journeyRunning || Math.abs(distance) > viewportHeight * .9) followedScroll = window.scrollY;
    else followedScroll += distance * (1 - Math.exp(-dt / 85));
    if (journeyRunning && Math.abs(window.scrollY - followedScroll) > .25) schedule();
    else followedScroll = window.scrollY;
    const lag = window.scrollY - followedScroll;
    // Read layout first; all writes follow so scrolling does not alternate layout reads/writes.
    progress?.style.setProperty('--alb-scroll-progress', String(clamp(window.scrollY / scrollRange)));
    let active = -1;
    sections.forEach((top, index) => { if (top <= stickyTop + 100) active = index; });
    links.forEach(({link}, index) => {
      if (index === active) link.setAttribute('aria-current', 'location');
      else link.removeAttribute('aria-current');
    });
    let chapter = 0;
    stops.forEach((top, index) => { if (top <= stickyTop + 100) chapter = index; });
    deckLinks.forEach((link, index) => {
      if (index === chapter) link.setAttribute('aria-current', 'step');
      else link.removeAttribute('aria-current');
    });
    cards.forEach((card, index) => {
      card.classList.toggle('alb-service-current', index === chapter);
      const tooTall = desktop.matches && !reduced.matches && heights[index] > viewportHeight - stickyTop - 12;
      if (card.classList.contains('alb-service-tall') !== tooTall) {
        card.classList.toggle('alb-service-tall', tooTall);
        schedule();
      }
    });
    if (!running) return;
    if (journeyRunning) {
      heroStage?.style.setProperty('--alb-journey-exit', clamp((followedScroll - sceneStart) / sceneRange).toFixed(3));
      journeyRects.forEach(({node, rect}) => {
        const top = rect.top + lag;
        const bottom = rect.bottom + lag;
        const phase = clamp((viewportHeight - top) / (viewportHeight + rect.height));
        node.style.setProperty('--alb-journey-phase', phase.toFixed(3));
        if (panels.includes(node)) {
          const aperture = clamp(Math.min((viewportHeight - top) / (viewportHeight * .75), bottom / (viewportHeight * .35)));
          const eased = aperture * aperture * (3 - 2 * aperture);
          node.style.setProperty('--alb-journey-inset', `${((1 - eased) * 24).toFixed(2)}px`);
        } else {
          node.style.setProperty('--alb-journey-pan', `${((phase - .5) * -16).toFixed(2)}px`);
          node.style.setProperty('--alb-journey-sheen', (Math.sin(phase * Math.PI) * .16).toFixed(3));
        }
      });
    }
    if (atmosphere && atmosphereVisible && desktop.matches) {
      atmosphere.style.setProperty('--alb-light-scroll', `${(clamp((window.scrollY - lightStart) / Math.max(1, lightHeight - viewportHeight)) * -38).toFixed(2)}px`);
      atmosphere.style.setProperty('--alb-light-x', `${(heroVisible ? pointerX * 10 : 0).toFixed(2)}px`);
    }
    if (heroVisible) {
      if (heroStage) {
        heroStage.style.setProperty('--alb-scene-progress', clamp((window.scrollY - sceneStart) / sceneRange).toFixed(3));
        heroStage.style.setProperty('--alb-scene-x', `${(pointerX * 8).toFixed(2)}px`);
      } else {
        hero.style.setProperty('--alb-hero-pan', `${clamp(window.scrollY * .065, 0, 42).toFixed(2)}px`);
        hero.style.setProperty('--alb-tilt-x', `${pointerX * 2.1}deg`);
        hero.style.setProperty('--alb-tilt-y', `${pointerY * -1.8}deg`);
      }
    }
    cards.forEach((card, index) => {
      const tooTall = card.classList.contains('alb-service-tall');
      const span = Math.max(1, viewportHeight - stickyTop);
      const next = stops[index + 1];
      const handoff = desktop.matches && next !== undefined && !tooTall ? clamp((viewportHeight - next) / span) : 0;
      const arrival = desktop.matches ? clamp((viewportHeight - (stops[index] ?? positions[index].top)) / span) : 1;
      const depth = handoff * handoff * (3 - 2 * handoff);
      card.style.setProperty('--alb-card-depth', depth.toFixed(3));
      card.style.setProperty('--alb-card-arrival', arrival.toFixed(3));
      card.style.setProperty('--alb-card-glint', Math.sin(arrival * Math.PI).toFixed(3));
      if (desktop.matches && activePhotos.has(card)) {
        const pan = clamp((positions[index].top + positions[index].height / 2 - viewportHeight / 2) / viewportHeight, -1, 1) * -20;
        card.style.setProperty('--alb-photo-pan', `${pan.toFixed(2)}px`);
      }
      if (photoPointer?.card === card) {
        card.style.setProperty('--alb-photo-x', `${photoX.toFixed(2)}px`);
        card.style.setProperty('--alb-photo-y', `${photoY.toFixed(2)}px`);
      }
    });
    if (aboutRect && desktop.matches) {
      const pan = clamp((aboutRect.top + aboutRect.height / 2 - viewportHeight / 2) / viewportHeight, -1, 1) * -22;
      about.style.setProperty('--alb-about-pan', `${pan.toFixed(2)}px`);
    }
  }

  const applyState = () => {
    const running = enabled();
    const journeyRunning = running && desktop.matches;
    root.classList.toggle('alb-journey-ready', journeyRunning);
    if (!journeyRunning) {
      followedScroll = window.scrollY;
      heroStage?.style.removeProperty('--alb-journey-exit');
      journeyNodes.forEach((node) => {
        ['--alb-journey-phase', '--alb-journey-inset', '--alb-journey-pan', '--alb-journey-sheen'].forEach((property) => node.style.removeProperty(property));
      });
    }
    root.classList.toggle('alb-motion-paused', !running);
    root.dataset.albMotion = running ? 'running' : 'paused';
    if (!running) {
      effects.forEach((effect) => effect.cancel());
      hero.removeAttribute('style');
      heroStage?.style.removeProperty('--alb-scene-progress');
      heroStage?.style.removeProperty('--alb-scene-x');
      about?.removeAttribute('style');
      cards.forEach((card) => {
        card.style.setProperty('--alb-card-depth', '0');
        card.style.removeProperty('--alb-photo-pan');
        card.style.removeProperty('--alb-photo-x');
        card.style.removeProperty('--alb-photo-y');
        card.style.setProperty('--alb-card-arrival', '1');
        card.style.setProperty('--alb-card-glint', '0');
      });
      photoPointer = null;
      atmosphere?.style.removeProperty('--alb-light-scroll');
      atmosphere?.style.removeProperty('--alb-light-x');
    }
    measure();
  };

  cards.forEach((card, index) => card.style.setProperty('--alb-card-index', String(index + 1)));
  root.classList.add('alb-motion-ready');
  const arrangeIndex = () => {
    if (deck) deck.open = sideIndex.matches;
  };
  arrangeIndex();
  sideIndex.addEventListener('change', arrangeIndex);
  root.classList.toggle('alb-page-hidden', document.hidden);
  applyState();
  reduced.addEventListener('change', applyState);
  desktop.addEventListener('change', applyState);

  const zoneObserver = new IntersectionObserver((entries) => {
    entries.forEach(({target, isIntersecting}) => {
      target.classList.toggle('alb-loop-visible', isIntersecting);
      if (target === heroScene) heroVisible = isIntersecting;
      if (target === about) aboutVisible = isIntersecting;
      if (target === atmosphere) atmosphereVisible = isIntersecting;
      if (journeyNodes.includes(target)) {
        if (isIntersecting) journeyVisible.add(target); else journeyVisible.delete(target);
      }
      if (target.classList.contains('alb-service')) {
        if (isIntersecting) activePhotos.add(target); else activePhotos.delete(target);
      }
    });
    schedule();
  });
  [...new Set([hero, heroScene, about, atmosphere, subscription, ...cards, ...journeyNodes])].filter(Boolean).forEach((element) => zoneObserver.observe(element));

  const entrances = new IntersectionObserver((entries) => {
    entries.forEach(({target, isIntersecting}) => {
      if (!isIntersecting || seen.has(target)) return;
      seen.add(target);
      entrances.unobserve(target);
      if (target.classList.contains('alb-service')) {
        if (!desktop.matches) animate(target.querySelector('.alb-service-photo'), [{clipPath:'inset(0 8% 0 0)', transform:'translateX(-12px)'}, {clipPath:'inset(0)', transform:'translateX(0)'}], {duration:650});
      } else if (target.classList.contains('alb-about-photo')) {
        animate(target, [{clipPath:'inset(8% 0 0 0)'}, {clipPath:'inset(0)'}], {duration:850});
      }
    });
  }, {threshold:.12});
  document.querySelectorAll('.alb-service, .alb-about-photo').forEach((element) => entrances.observe(element));

  // Keep the padded mask and the final compositing state identical before/after
  // the effect. Animating clip-path on glyphs cut off descenders until it ended.
  // With slow fonts, show the settled heading rather than replaying an entrance
  // after a visitor has already started reading it.
  if (desktop.matches) {
    animate(document.querySelector('.alb-hero-lens'), [{transform:'translate3d(0,0,0) scale(1.075)'}, {transform:'translate3d(0,0,0)'}], {duration:1600, fill:'backwards'});
  }
  if (!document.fonts || document.fonts.check('500 1em Manrope')) {
    document.querySelectorAll('.alb-hero-ink').forEach((line, index) => {
      animate(line, [{transform:'translate3d(0, 112%, 0)'}, {transform:'translate3d(0, 0, 0)'}], {duration:1100, delay:index * 100, fill:'backwards'});
    });
  }

  heroScene.addEventListener('pointerenter', () => { pointerBounds = heroScene.getBoundingClientRect(); });
  heroScene.addEventListener('pointermove', (event) => {
    if (!enabled() || !desktop.matches || !finePointer.matches) return;
    if (!pointerBounds) pointerBounds = heroScene.getBoundingClientRect();
    pointerX = clamp((event.clientX - pointerBounds.left) / pointerBounds.width * 2 - 1, -1, 1);
    pointerY = clamp((event.clientY - pointerBounds.top) / pointerBounds.height * 2 - 1, -1, 1);
    schedule();
  }, {passive:true});
  heroScene.addEventListener('pointerleave', () => { pointerX = pointerY = 0; schedule(); });
  cards.forEach((card) => {
    const photo = card.querySelector('.alb-service-photo');
    photo?.addEventListener('pointermove', (event) => {
      if (!enabled() || !desktop.matches || !finePointer.matches) return;
      photoPointer = {card, photo, clientX:event.clientX, clientY:event.clientY};
      schedule();
    }, {passive:true});
    photo?.addEventListener('pointerleave', () => { photoPointer = {card}; schedule(); });
  });
  window.addEventListener('scroll', schedule, {passive:true});
  window.addEventListener('resize', measure, {passive:true});
  document.addEventListener('toggle', measure, true);
  document.addEventListener('visibilitychange', () => {
    root.classList.toggle('alb-page-hidden', document.hidden);
    if (document.hidden) {
      cancelAnimationFrame(frame);
      frame = 0;
      effects.forEach((effect) => effect.cancel());
    } else measure();
  });
  window.addEventListener('load', measure, {once:true});
  document.fonts?.ready.then(measure);
  // Native details, images and CMS edits can change the page height without a viewport resize.
  if ('ResizeObserver' in window) {
    const sizeObserver = new ResizeObserver(measure);
    if (main) sizeObserver.observe(main);
  }
})();
