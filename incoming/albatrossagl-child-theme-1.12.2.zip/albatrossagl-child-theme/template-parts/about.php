<?php
defined('ABSPATH') || exit;
$title = get_option('ticinoweb_chi_siamo_title');
$text = get_option('ticinoweb_chi_siamo_text');
$image = get_option('ticinoweb_chi_siamo_image');
$caption = $image ? wp_get_attachment_caption(attachment_url_to_postid($image)) : '';
$cta = get_option('ticinoweb_chi_siamo_link') ?: albatros_url('contatti');
$cta = function_exists('ticinoweb_frontend_url') ? ticinoweb_frontend_url($cta, 'theme:about:link') : $cta;
if (!$title && !$text) { return; }
?>
<div class="alb-about">
    <figure class="alb-about-figure">
        <div class="alb-about-photo"><?php echo albatros_image($image, 'large', array('sizes' => '(max-width: 760px) 100vw, 50vw')); ?></div>
        <?php if ($caption) : ?><figcaption class="alb-photo-caption"><?php echo esc_html(albatros_text($caption, 'about:caption')); ?></figcaption><?php endif; ?>
    </figure>
    <div class="alb-about-copy">
        <?php if ($title) : ?><h2><?php echo esc_html(albatros_text($title, 'about:title')); ?></h2><?php endif; ?>
        <div><?php echo wp_kses_post(wpautop(albatros_text($text, 'about:text'))); ?></div>
        <a class="alb-text-link" href="<?php echo esc_url($cta); ?>"><?php esc_html_e('Contattaci', 'albatrossagl-child-theme'); ?> <span aria-hidden="true">↗</span></a>
    </div>
</div>
