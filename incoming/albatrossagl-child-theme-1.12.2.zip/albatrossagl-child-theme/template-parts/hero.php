<?php
defined('ABSPATH') || exit;
$title = get_option('ticinoweb_slider_title_1', '');
if (!$title) { return; }
$contact = albatros_contact();
$image = get_option('ticinoweb_slider_image_1');
$image_id = $image ? attachment_url_to_postid($image) : 0;
$portrait = $image_id ? wp_get_attachment_image_src($image_id, 'albatros-hero-mobile') : false;
$portrait_hd = $image_id ? wp_get_attachment_image_src($image_id, 'albatros-hero-mobile-hd') : false;
// Older library entries remain valid until their native derivatives are generated.
$portrait_sources = array();
foreach (array($portrait, $portrait_hd) as $source) {
    if ($source && $source[3]) { $portrait_sources[$source[1]] = $source[0] . ' ' . $source[1] . 'w'; }
}
$caption = $image ? wp_get_attachment_caption(attachment_url_to_postid($image)) : '';
$lines = preg_split('/\R+|(?<=,)\h+/u', albatros_text($title, 'hero:title'), 2);
$cta = get_option('ticinoweb_slider_btn_link_1') ?: albatros_url('contatti');
$cta = function_exists('ticinoweb_frontend_url') ? ticinoweb_frontend_url($cta, 'theme:slider:1:btn_link') : $cta;
?>
<section class="alb-hero alb-hero-stage<?php echo $image ? '' : ' alb-hero-no-image'; ?>" aria-labelledby="alb-title">
    <?php if ($image) : ?>
    <figure class="alb-hero-figure">
        <div class="alb-hero-media">
            <div class="alb-hero-lens"><picture>
                <?php if ($portrait_sources) : ?><source media="(max-width: 760px)" srcset="<?php echo esc_attr(implode(', ', $portrait_sources)); ?>" sizes="(max-width: 540px) 115vw, 160vw"><?php endif; ?>
                <?php echo albatros_image($image, 'full', array('loading' => 'eager', 'fetchpriority' => 'high', 'sizes' => '(max-width: 760px) 170vh, 108vw')); ?>
            </picture></div>
        </div>
        <?php if ($caption) : ?><figcaption class="alb-photo-caption"><?php echo esc_html(albatros_text($caption, 'hero:caption')); ?></figcaption><?php endif; ?>
    </figure>
    <?php endif; ?>
    <div class="alb-hero-copy">
        <?php if (!empty($contact['address_label'])) : ?><p class="alb-kicker"><?php echo esc_html(albatros_text($contact['address_label'], 'territory')); ?></p><?php endif; ?>
        <h1 id="alb-title"><?php foreach ($lines as $line) : ?><span class="alb-hero-line"><span class="alb-hero-ink"><?php echo esc_html($line); ?></span></span> <?php endforeach; ?></h1>
        <div class="alb-hero-bottom">
            <?php if ($description = get_option('ticinoweb_slider_desc_1')) : ?><p class="alb-lead"><?php echo esc_html(albatros_text($description, 'hero:description')); ?></p><?php endif; ?>
            <div class="alb-actions">
                <?php if ($button = get_option('ticinoweb_slider_btn_text_1')) : ?><a class="alb-button" href="<?php echo esc_url($cta); ?>"><?php echo esc_html(albatros_text($button, 'hero:button')); ?><span aria-hidden="true">↗</span></a><?php endif; ?>
                <a class="alb-text-link" href="<?php echo esc_url(albatros_url('servizi')); ?>"><?php esc_html_e('Esplora i servizi', 'albatrossagl-child-theme'); ?><span aria-hidden="true">↓</span></a>
            </div>
        </div>
    </div>
</section>
