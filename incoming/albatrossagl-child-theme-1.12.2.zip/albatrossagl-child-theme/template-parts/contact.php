<?php defined('ABSPATH') || exit; $contact = albatros_contact(); ?>
<div class="alb-contact-direct">
    <?php if (!empty($contact['phone'])) : ?>
    <a class="alb-contact-channel" href="<?php echo esc_url('tel:' . preg_replace('/[^+0-9]/', '', $contact['phone'])); ?>">
        <span class="alb-contact-label"><?php esc_html_e('Chiamaci', 'albatrossagl-child-theme'); ?></span>
        <span class="alb-contact-value"><?php echo esc_html($contact['phone_display'] ?: $contact['phone']); ?></span>
        <span class="alb-contact-arrow" aria-hidden="true">&#8599;</span>
    </a>
    <?php endif; ?>
    <?php if (!empty($contact['email'])) : ?>
    <a class="alb-contact-channel" href="<?php echo esc_url('mailto:' . sanitize_email($contact['email'])); ?>">
        <span class="alb-contact-label"><?php esc_html_e('Scrivici', 'albatrossagl-child-theme'); ?></span>
        <span class="alb-contact-value"><?php echo esc_html($contact['email']); ?></span>
        <span class="alb-contact-arrow" aria-hidden="true">&#8599;</span>
    </a>
    <?php endif; ?>
    <div class="alb-contact-details">
        <?php if (!empty($contact['address']) || !empty($contact['map_url'])) : ?>
        <div class="alb-contact-location">
            <h3><?php esc_html_e('Dove siamo', 'albatrossagl-child-theme'); ?></h3>
            <?php if (!empty($contact['address'])) : ?><address><?php echo esc_html($contact['address']); ?></address><?php endif; ?>
            <?php if (!empty($contact['map_url'])) : ?><a class="alb-text-link" href="<?php echo esc_url($contact['map_url']); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e('Apri le indicazioni', 'albatrossagl-child-theme'); ?><span aria-hidden="true">&#8599;</span><span class="alb-visually-hidden"><?php esc_html_e('(si apre in una nuova scheda)', 'albatrossagl-child-theme'); ?></span></a><?php endif; ?>
        </div>
        <?php endif; ?>
        <?php if (!empty($contact['opening_hours_note'])) : ?>
        <div class="alb-contact-hours">
            <h3><?php esc_html_e('Orari e interventi', 'albatrossagl-child-theme'); ?></h3>
            <p><?php echo nl2br(esc_html(albatros_text($contact['opening_hours_note'], 'contact:opening-hours'))); ?></p>
        </div>
        <?php endif; ?>
    </div>
</div>
