<?php
/**
 * Template Name: Terms and Conditions Page
 *
 * The template for displaying the Terms & Conditions page.
 *
 * @package EcoProPlumbing
 */

get_header(); ?>

<main id="primary" class="site-main" style="padding-top: 180px; padding-bottom: 80px; min-height: 60vh; position: relative; z-index: 10;">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-10">
                <div class="terms-content" style="background-color: #ffffff; padding: 40px; border-radius: 15px; box-shadow: 0 10px 30px rgba(0,0,0,0.08); margin-bottom: 40px;">
                    <h1 class="entry-title mb-4" style="text-align: center; color: var(--eco-primary-dark); font-weight: 700;"><?php the_title(); ?></h1>
                    
                    <div class="entry-content" style="color: #444; line-height: 1.8; font-size: 1.05rem;">
                        <?php
                        if ( have_posts() ) :
                            while ( have_posts() ) :
                                the_post();
                                the_content();
                            endwhile;
                        else: ?>
                            <p style="text-align: center;">I termini e le condizioni verranno inseriti qui dal pannello di amministrazione di WordPress.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>

<?php get_footer(); ?>
