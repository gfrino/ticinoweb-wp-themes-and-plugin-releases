<?php
/**
 * Ecoproplumbing child theme functions
 */

// Service-area data (city list, hub town, maps) lives per-site in custom fields on
// the front page rather than hardcoded here — this theme is shared by more than one
// subsite. See inc/service-areas.php.
require_once get_stylesheet_directory() . '/inc/service-areas.php';

// Secondary header image, also per-site via a field on the front page.
require_once get_stylesheet_directory() . '/inc/header-image.php';

// CTA configuration & settings (Floating button modal vs iframe switch)
require_once get_stylesheet_directory() . '/inc/cta-settings.php';

/**
 * Which template file is WordPress actually rendering for this request?
 *
 * Set by template-loader.php before the template is included, so it is already
 * available by the time wp_enqueue_scripts fires. Using this rather than
 * is_page('slug') keeps the asset rules correct even if a page is renamed,
 * because the templates here are matched by the page-{slug}.php convention.
 */
function ecoproplumbing_current_template()
{
    return isset($GLOBALS['template']) ? basename((string) $GLOBALS['template']) : '';
}

/**
 * Does this request need Swiper? (hero / gallery / service sliders)
 */
function ecoproplumbing_needs_swiper()
{
    $templates = array(
        'front-page.php',
        'page-service.php',
        'page-emergency-plumbing.php',
    );

    return (bool) apply_filters(
        'ecoproplumbing_needs_swiper',
        in_array(ecoproplumbing_current_template(), $templates, true)
    );
}

/**
 * Does this request need Leaflet? (service areas map)
 */
function ecoproplumbing_needs_leaflet()
{
    $templates = array(
        'front-page.php',
        'page-contact.php',
    );

    return (bool) apply_filters(
        'ecoproplumbing_needs_leaflet',
        in_array(ecoproplumbing_current_template(), $templates, true)
    );
}

/**
 * Label of the callout that pops out of the floating booking button.
 * One source for both the markup (footer.php) and the font subset request.
 */
function ecoproplumbing_cta_callout_text()
{
    return __('Click here!', 'ecoproplumbing-child-theme');
}

function ecoproplumbing_enqueue_styles()
{
    // Site-wide: Bootstrap grid classes are used in the header, footer and every
    // template; Font Awesome icons are in the header nav and footer contacts.
    wp_enqueue_style('bootstrap-grid', 'https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap-grid.min.css', array(), '5.3.2');
    wp_enqueue_style('eco-font-awesome6', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css', array(), '6.5.1');

    // Site-wide: the floating booking button and its modal live in footer.php.
    wp_enqueue_script('bootstrap-bundle', 'https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js', array(), '5.3.2', true);

    // The child stylesheet must load after any library CSS it overrides, so the
    // dependency list is built from the handles actually enqueued this request.
    // Listing a handle that was never enqueued would silently suppress our
    // stylesheet entirely, so only add a handle once it is queued.
    $child_style_deps = array('bootstrap-grid', 'eco-font-awesome6');

    // Swiper: only on templates that actually render a slider.
    if (ecoproplumbing_needs_swiper()) {
        wp_enqueue_style('swiper-css', 'https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css', array(), '11.0.0');
        wp_enqueue_script('swiper-js', 'https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js', array(), '11.0.0', true);
        $child_style_deps[] = 'swiper-css';
    }

    // Leaflet: only on templates that actually render a map.
    if (ecoproplumbing_needs_leaflet()) {
        wp_enqueue_style('leaflet-css', 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css', array(), '1.9.4');
        wp_enqueue_script('leaflet-js', 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js', array(), '1.9.4', true);
        $child_style_deps[] = 'leaflet-css';
    }

    // The parent theme registers 'ticinoweb-ai-style' against get_stylesheet_uri(),
    // which inside a child theme resolves to THIS theme's style.css. That is the
    // same file we enqueue below, so the stylesheet was being requested and parsed
    // twice per page. Drop the parent's copy and keep ours, because ours is the one
    // that loads after the library CSS and therefore wins the cascade.
    // Safe to dequeue: no other handle declares it as a dependency, and the
    // 'poppins-font' handle it depended on is enqueued directly by the parent.
    wp_dequeue_style('ticinoweb-ai-style');

    // filemtime() busts the cache exactly when the file changes. The previous
    // time() value would have defeated caching on every single request; it only
    // appeared harmless because the stack currently strips version query strings.
    $child_style_path = get_stylesheet_directory() . '/style.css';
    $child_style_ver  = file_exists($child_style_path) ? filemtime($child_style_path) : null;

    // Script font for the "Click here!" callout next to the floating button (footer.php).
    // `text=` makes Google serve only the glyphs of that one label (a couple of KB
    // instead of the whole family), and it follows the translated string.
    wp_enqueue_style(
        'eco-callout-font',
        'https://fonts.googleapis.com/css2?family=Caveat:wght@700&display=swap&text=' . rawurlencode(ecoproplumbing_cta_callout_text()),
        array(),
        null
    );

    wp_enqueue_style('ecoproplumbing-child-style', get_stylesheet_uri(), $child_style_deps, $child_style_ver);

    // Dashicons is only reachable through the parent's [ticinoweb_google_reviews]
    // shortcode, which renders its stars with dashicons classes. Loading it
    // unconditionally cost every page ~34KB for nothing. (WordPress enqueues it
    // itself when the admin bar is showing, so logged-in views are unaffected.)
    if (is_singular()) {
        $content = (string) get_post_field('post_content', get_queried_object_id());
        if (has_shortcode($content, 'ticinoweb_google_reviews')) {
            wp_enqueue_style('dashicons');
        }
    }
}
add_action('wp_enqueue_scripts', 'ecoproplumbing_enqueue_styles', 20);

/**
 * Fetch Google Reviews dynamically via Places API (with fallback)
 */
if (!function_exists('ticinoweb_get_google_reviews')) {
    function ticinoweb_get_google_reviews()
    {
    $api_key = get_option('ticinoweb_google_api_key', '');
    $place_id = get_option('ticinoweb_google_place_id', 'ChIJh_M82-nQ1osRc_pBteq1_1o'); // Use provided Place ID as fallback

    // Check transient cache for performance
    $cached_reviews = get_transient('ticinoweb_google_reviews_cache');
    if ($cached_reviews !== false) {
        return $cached_reviews;
    }

    // If no API key is set, return beautiful fallback data so the design is visible
    if (empty($api_key) || empty($place_id)) {
        return array(
            array(
                'author_name' => 'Michael T. (Fallback Data - Waiting for API Key)',
                'profile_photo_url' => 'https://ui-avatars.com/api/?name=Michael+T&background=0D8ABC&color=fff',
                'rating' => 5,
                'text' => 'Fast, professional, and affordable! The Eco Pro team arrived within 30 minutes of my emergency call and fixed the burst pipe flawlessly. Highly recommended!'
            ),
            array(
                'author_name' => 'Sarah J. (Fallback Data)',
                'profile_photo_url' => 'https://ui-avatars.com/api/?name=Sarah+J&background=0096C7&color=fff',
                'rating' => 5,
                'text' => 'Excellent service. They installed a new water heater and left the place spotless. The technicians were polite and explained everything clearly.'
            ),
            array(
                'author_name' => 'David W.',
                'profile_photo_url' => 'https://ui-avatars.com/api/?name=David+W&background=48CAE4&color=fff',
                'rating' => 5,
                'text' => sprintf(
                    // Demo copy, shown only when no API key is configured. Kept free of a
                    // hardcoded town so it does not name Florida on a Canadian site.
                    'Best plumbing company in %s! Transparent pricing, no hidden fees, and the quality of work is outstanding. Will definitely use them again.',
                    function_exists('eco_sa_hub') && eco_sa_hub() !== '' ? eco_sa_hub() : 'town'
                )
            ),
            array(
                'author_name' => 'Jessica L.',
                'profile_photo_url' => 'https://ui-avatars.com/api/?name=Jessica+L&background=03045E&color=fff',
                'rating' => 4,
                'text' => 'Very reliable and prompt service. We had a tough drain clog and they handled it effortlessly. Great experience from start to finish.'
            )
        );
    }

    // Live API call
    $url = "https://maps.googleapis.com/maps/api/place/details/json?place_id={$place_id}&fields=reviews&key={$api_key}&language=en";
    $response = wp_remote_get($url);
    if (is_wp_error($response)) {
        return array();
    }
    $body = wp_remote_retrieve_body($response);
    $data = json_decode($body, true);

    if (isset($data['result']['reviews'])) {
        $reviews = $data['result']['reviews'];
        // Cache for 24 hours to prevent API quota limits
        set_transient('ticinoweb_google_reviews_cache', $reviews, 24 * HOUR_IN_SECONDS);
        return $reviews;
    }

        return array();
    }
}

/**
 * Ultimate Dynamic Breadcrumb Engine
 * 1. Checks Navigation Menu Hierarchy (Primary Menu)
 * 2. Fallbacks to WordPress Page Hierarchy
 * 3. Fallbacks to URL Path parsing (ignoring subdirectory)
 */
if (!function_exists('ticinoweb_get_advanced_breadcrumb')) {
    function ticinoweb_get_advanced_breadcrumb()
    {
    global $post;

    $breadcrumbs = array();

    // Attempt 1: Check Primary Menu
    $locations = get_nav_menu_locations();
    if (isset($locations['primary'])) {
        $menu = wp_get_nav_menu_object($locations['primary']);
        if ($menu) {
            $menu_items = wp_get_nav_menu_items($menu->term_id);
            $current_item = null;

            // Find current post in menu
            if ($menu_items) {
                foreach ($menu_items as $item) {
                    if ($item->object_id == get_the_ID()) {
                        $current_item = $item;
                        break;
                    }
                }
            }

            // Reconstruct path
            if ($current_item) {
                $parent_id = $current_item->menu_item_parent;
                while ($parent_id) {
                    foreach ($menu_items as $item) {
                        if ($item->ID == $parent_id) {
                            $breadcrumbs[] = array(
                                'title' => $item->title,
                                'url' => $item->url
                            );
                            $parent_id = $item->menu_item_parent;
                            break;
                        }
                    }
                }
                $breadcrumbs = array_reverse($breadcrumbs);
                return $breadcrumbs;
            }
        }
    }

    // Attempt 2: Check WordPress Page Parent Hierarchy
    $ancestors = get_post_ancestors(get_the_ID());
    if (!empty($ancestors)) {
        $ancestors = array_reverse($ancestors);
        foreach ($ancestors as $ancestor) {
            $breadcrumbs[] = array(
                'title' => get_the_title($ancestor),
                'url' => get_permalink($ancestor)
            );
        }
        return $breadcrumbs;
    }

    // Attempt 3: URL Path Fallback (Stripping WP install subdirectory)
    $home_path = parse_url(home_url(), PHP_URL_PATH);
    $current_path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);

    // Strip home_path from current_path if it exists
    if ($home_path && $home_path !== '/') {
        if (strpos($current_path, $home_path) === 0) {
            $current_path = substr($current_path, strlen($home_path));
        }
    }

    $path = trim($current_path, '/');
    $segments = explode('/', $path);

    // Remove the current page segment
    if (count($segments) > 0) {
        array_pop($segments);
    }

    $accumulated_path = $home_path ? rtrim($home_path, '/') : '';
    foreach ($segments as $segment) {
        if (empty($segment))
            continue;
        $accumulated_path .= '/' . $segment;
        $breadcrumbs[] = array(
            'title' => ucwords(str_replace(array('-', '_'), ' ', $segment)),
            'url' => home_url(str_replace($home_path, '', $accumulated_path) . '/')
        );
    }

    // If absolutely nothing was found, provide a generic fallback
    if (empty($breadcrumbs)) {
        $breadcrumbs[] = array(
            'title' => 'Services',
            'url' => home_url('/services/')
        );
    }

        return $breadcrumbs;
    }
}

/**
 * Hide Terms and Conditions page from the fallback menu
 */
function ecoproplumbing_exclude_terms_page_from_menu( $args ) {
    $exclude_ids = array();
    
    // Get by template
    $pages = get_pages(array(
        'meta_key' => '_wp_page_template',
        'meta_value' => 'page-terms-and-conditions.php'
    ));
    foreach($pages as $page) {
        $exclude_ids[] = $page->ID;
    }
    
    // Also try to find by slug just in case
    $page_by_slug = get_page_by_path('terms-conditions');
    if ($page_by_slug) {
        $exclude_ids[] = $page_by_slug->ID;
    }
    
    // Also try to find by slug 'terms-and-conditions'
    $page_by_slug2 = get_page_by_path('terms-and-conditions');
    if ($page_by_slug2) {
        $exclude_ids[] = $page_by_slug2->ID;
    }

    if(!empty($exclude_ids)) {
        $existing_exclude = isset($args['exclude']) ? explode(',', $args['exclude']) : array();
        $merged = array_unique(array_merge($existing_exclude, $exclude_ids));
        $args['exclude'] = implode(',', $merged);
    }
    return $args;
}
add_filter( 'wp_page_menu_args', 'ecoproplumbing_exclude_terms_page_from_menu' );

/**
 * Force flush rewrite rules once after theme update to fix 404s
 */
add_action( 'init', function() {
    if ( get_option( 'ecopro_flush_rewrite_rules_116' ) !== 'done' ) {
        flush_rewrite_rules( false );
        update_option( 'ecopro_flush_rewrite_rules_116', 'done' );
    }
} );

/**
 * Hero background video
 * ---------------------
 * The URL lives in the `ecopro_hero_video` option and is edited from
 * ticinoWEB CMS → "Slider & Partner", with a real Media Library picker.
 *
 * It used to be a Customizer theme_mod holding a URL you had to paste by hand.
 * That control is gone, but the value is not: ecoproplumbing_migrate_hero_video()
 * copies it into the option once, and the getter still falls back to it, so a site
 * that never visits wp-admin keeps playing the video it already had.
 */
function ecoproplumbing_get_hero_video() {
    $url = get_option( 'ecopro_hero_video', '' );

    if ( empty( $url ) ) {
        // Pre-1.3.0 sites stored this as a Customizer theme_mod.
        $url = get_theme_mod( 'ecopro_hero_video', '' );
    }

    return $url;
}

/**
 * One-time copy of the legacy Customizer value into the option.
 *
 * Runs before the settings are registered so the CMS field shows the current
 * video the first time the page is opened rather than an empty box.
 */
add_action( 'admin_init', 'ecoproplumbing_migrate_hero_video', 5 );
function ecoproplumbing_migrate_hero_video() {
    // A null default distinguishes "never set" from "deliberately emptied".
    if ( null !== get_option( 'ecopro_hero_video', null ) ) {
        return;
    }

    $legacy = get_theme_mod( 'ecopro_hero_video', '' );
    add_option( 'ecopro_hero_video', $legacy ? esc_url_raw( $legacy ) : '' );
}

/**
 * Register the field inside the existing ticinoWEB CMS form.
 *
 * The parent theme's CMS page opens a form posting to options.php with
 * settings_fields('ticinoweb_settings_group') and then calls
 * do_settings_sections('ticinoweb_settings_group'). It registers no sections of
 * its own, so a section added here renders inside that form and is saved by the
 * parent's own Save button — no parent-theme changes required.
 *
 * Saving is available to Editors too: the parent already filters
 * option_page_capability_ticinoweb_settings_group down to 'edit_pages', and this
 * setting joins the same group.
 */
add_action( 'admin_init', 'ecoproplumbing_register_hero_video_field' );
function ecoproplumbing_register_hero_video_field() {
    register_setting( 'ticinoweb_settings_group', 'ecopro_hero_video', array(
        'type'              => 'string',
        'sanitize_callback' => 'esc_url_raw',
        'default'           => '',
    ) );

    add_settings_section(
        'ecopro_hero_video_section',
        __( 'Hero — Video di sfondo', 'ecoproplumbing' ),
        'ecoproplumbing_hero_video_section_intro',
        'ticinoweb_settings_group'
    );

    add_settings_field(
        'ecopro_hero_video',
        __( 'Video di sfondo', 'ecoproplumbing' ),
        'ecoproplumbing_hero_video_field',
        'ticinoweb_settings_group',
        'ecopro_hero_video_section'
    );
}

function ecoproplumbing_hero_video_section_intro() {
    echo '<p>' . esc_html__( 'Carica un video MP4 dalla Libreria Media. Se impostato sostituisce le immagini di sfondo dello slider con il video in loop. Lascia il campo vuoto per tornare alle immagini.', 'ecoproplumbing' ) . '</p>';
}

function ecoproplumbing_hero_video_field() {
    $url = get_option( 'ecopro_hero_video', '' );
    ?>
    <div id="ecopro-hero-video-control">
        <input type="url" id="ecopro_hero_video" name="ecopro_hero_video"
               value="<?php echo esc_attr( $url ); ?>" class="regular-text"
               placeholder="https://..." style="max-width: 520px;">
        <button type="button" class="button" id="ecopro-hero-video-upload">
            <?php esc_html_e( 'Carica / Scegli video', 'ecoproplumbing' ); ?>
        </button>
        <button type="button" class="button" id="ecopro-hero-video-remove" <?php disabled( empty( $url ) ); ?>>
            <?php esc_html_e( 'Rimuovi', 'ecoproplumbing' ); ?>
        </button>
        <p class="description">
            <?php esc_html_e( 'Formato consigliato: MP4 (H.264). Il video parte in automatico, muto e in loop.', 'ecoproplumbing' ); ?>
        </p>
        <video id="ecopro-hero-video-preview" src="<?php echo esc_url( $url ); ?>" controls muted playsinline
               preload="metadata"
               style="margin-top: 10px; max-width: 420px; width: 100%; border-radius: 8px;<?php echo empty( $url ) ? ' display: none;' : ''; ?>"></video>
    </div>
    <?php
}

/**
 * Media picker for the field above. Only loaded on the CMS page itself.
 */
add_action( 'admin_enqueue_scripts', 'ecoproplumbing_hero_video_admin_assets' );
function ecoproplumbing_hero_video_admin_assets( $hook ) {
    if ( 'toplevel_page_ticinoweb-cms' !== $hook ) {
        return;
    }

    wp_enqueue_media();
    wp_add_inline_script( 'jquery-core', ecoproplumbing_hero_video_admin_js() );
}

function ecoproplumbing_hero_video_admin_js() {
    $strings = array(
        'title'  => esc_js( __( 'Scegli il video di sfondo', 'ecoproplumbing' ) ),
        'button' => esc_js( __( 'Usa questo video', 'ecoproplumbing' ) ),
    );

    return <<<JS
jQuery(function ($) {
    var \$control = \$('#ecopro-hero-video-control');
    if (!\$control.length) {
        return;
    }

    var \$input   = \$('#ecopro_hero_video');
    var \$preview = \$('#ecopro-hero-video-preview');
    var \$remove  = \$('#ecopro-hero-video-remove');

    // do_settings_sections() renders this block above the tab strip, because that is
    // where the parent calls it. Move it into the "Slider & Partner" panel so it sits
    // with the other slider settings. Cosmetic only: if the panel is ever renamed or
    // removed the field simply stays at the top of the page and still saves.
    var \$panel = \$('#slider');
    var \$table = \$control.closest('table.form-table');
    if (\$panel.length && \$table.length) {
        var \$intro = \$table.prevAll('p').first();
        var \$title = \$table.prevAll('h2').first();
        \$panel.prepend(\$table).prepend(\$intro).prepend(\$title);
    }

    function setVideo(url) {
        \$input.val(url);
        \$preview.attr('src', url);
        if (url) {
            \$preview.show();
        } else {
            \$preview.hide();
        }
        \$remove.prop('disabled', !url);
    }

    var frame;
    \$('#ecopro-hero-video-upload').on('click', function (e) {
        e.preventDefault();

        if (!frame) {
            frame = wp.media({
                title: '{$strings['title']}',
                library: { type: 'video' },
                button: { text: '{$strings['button']}' },
                multiple: false
            });

            frame.on('select', function () {
                setVideo(frame.state().get('selection').first().toJSON().url);
            });
        }

        frame.open();
    });

    \$remove.on('click', function (e) {
        e.preventDefault();
        setVideo('');
    });

    // Keep the preview honest when the URL is typed or pasted by hand.
    \$input.on('change', function () {
        setVideo(\$.trim(\$(this).val()));
    });
});
JS;
}

/**
 * Open the TLS connections to the CDNs this theme enqueues from, before the browser
 * reaches the tags themselves. Saves a DNS lookup + TLS handshake per origin.
 *
 * Only the origins actually used on the current request are hinted — a preconnect
 * the page never uses just holds a socket open for nothing.
 */
add_filter( 'wp_resource_hints', 'ecoproplumbing_resource_hints', 10, 2 );
function ecoproplumbing_resource_hints( $hints, $relation ) {
    if ( 'preconnect' !== $relation ) {
        return $hints;
    }

    // Bootstrap grid + bundle, and Swiper when the template needs it.
    $hints[] = 'https://cdn.jsdelivr.net';

    // Font Awesome, which also pulls its webfonts from the same origin.
    $hints[] = 'https://cdnjs.cloudflare.com';

    if ( function_exists( 'ecoproplumbing_needs_leaflet' ) && ecoproplumbing_needs_leaflet() ) {
        $hints[] = 'https://unpkg.com';
    }

    return $hints;
}

/**
 * Arm the scroll-reveal CSS.
 *
 * This runs early in wp_head so the sections are already hidden at first paint and
 * never flash in before the observer attaches. The fallback timer is the safety
 * net: if the footer script never runs — a JS error earlier on the page, a blocked
 * asset — the class is dropped and every section becomes visible anyway.
 */
add_action( 'wp_head', 'ecoproplumbing_reveal_bootstrap', 1 );
function ecoproplumbing_reveal_bootstrap() {
    if ( ! is_front_page() ) {
        return;
    }
    ?>
    <script>
        (function (d) {
            var root = d.documentElement;
            root.classList.add('eco-js');
            window.ecoRevealFallback = window.setTimeout(function () {
                root.classList.remove('eco-js');
            }, 2500);
        })(document);
    </script>
    <?php
}

/**
 * Reveal each front-page section as it scrolls into view.
 */
add_action( 'wp_footer', 'ecoproplumbing_reveal_script', 20 );
function ecoproplumbing_reveal_script() {
    if ( ! is_front_page() ) {
        return;
    }
    ?>
    <script>
        (function () {
            var root    = document.documentElement;
            var targets = document.querySelectorAll('#content > section:not(#hero)');

            function showEverything() {
                window.clearTimeout(window.ecoRevealFallback);
                root.classList.remove('eco-js');
            }

            var reduced = window.matchMedia
                && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

            if (!targets.length || reduced || !('IntersectionObserver' in window)) {
                showEverything();
                return;
            }

            // The observer is live from here on, so the safety timer is no longer wanted.
            window.clearTimeout(window.ecoRevealFallback);

            var observer = new IntersectionObserver(function (entries) {
                entries.forEach(function (entry) {
                    if (entry.isIntersecting) {
                        entry.target.classList.add('is-visible');
                        observer.unobserve(entry.target);
                    }
                });
            }, { rootMargin: '0px 0px -10% 0px', threshold: 0.05 });

            Array.prototype.forEach.call(targets, function (section) {
                observer.observe(section);
            });
        })();
    </script>
    <?php
}
