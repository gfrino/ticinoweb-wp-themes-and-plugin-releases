<?php
/**
 * Template Name: Service Page
 * Template Post Type: post, page, service, services, servizi, ticinoweb_servizi
 *
 * The template for displaying all service and sub-service pages.
 *
 * @package EcoProPlumbing
 */

get_header(); ?>

<main id="primary" class="site-main service-page">

    <!-- BLUE HERO BANNER -->
    <section class="about-hero position-relative">
        <div class="about-hero-overlay"></div>
        <!-- Animated Waves Container -->
        <div class="ocean">
            <div class="wave"></div>
            <div class="wave"></div>
            <div class="wave"></div>
            <div class="wave"></div>
        </div>
        <div class="container about-hero-content position-relative z-1 text-center">

            <!-- Dynamic Breadcrumbs (No List) -->
            <div class="eco-breadcrumb-custom mb-0"
                style="font-size: 0.95rem; font-weight: 500; letter-spacing: 0.5px; text-shadow: 0 1px 2px rgba(0,0,0,0.2);">
                <a href="<?php echo esc_url(home_url('/')); ?>"
                    class="text-white text-decoration-none transition-opacity">Home</a>

                <?php
                // Use the ultimate dynamic breadcrumb engine from functions.php
                $breadcrumbs = ticinoweb_get_advanced_breadcrumb();
                
                if (!empty($breadcrumbs)) {
                    foreach ($breadcrumbs as $crumb) {
                        echo '<span class="mx-2 fw-light" style="color: rgba(255,255,255,0.6);">/</span>';
                        echo '<a href="' . esc_url($crumb['url']) . '" class="text-white text-decoration-none transition-opacity">' . esc_html($crumb['title']) . '</a>';
                    }
                }
                ?>

                <span class="mx-2 fw-light" style="color: rgba(255,255,255,0.6);">/</span>
                <span class="text-white fw-bold"><?php the_title(); ?></span>
            </div>

            <h1 class="about-title entry-title text-white fw-bold display-4 mb-3">
                <?php the_title(); ?>
            </h1>

            <!-- Short Description (Excerpt) -->
            <?php if (has_excerpt()): ?>
                <div class="hero-short-desc text-white-50 lead mx-auto" style="max-width: 800px; font-size: 1.15rem;">
                    <?php echo get_the_excerpt(); ?>
                </div>
            <?php else: ?>
                <div class="hero-short-desc text-white-50 lead mx-auto" style="max-width: 800px; font-size: 1.15rem;">
                    <p>Professional, reliable, and available 24/7. Discover how our expert plumbers can resolve your issues
                        quickly and efficiently.</p>
                </div>
            <?php endif; ?>

        </div>
    </section>

    <!-- CONTENT SECTION (50/50 Split) -->
    <section id="service-content" class="section-about py-5">
        <div class="container eco-container-1300">
            <div class="about-main-box">
                <div class="row align-items-center">

                    <!-- Text Column (Left) -->
                    <div class="col-md-6 mb-4 mb-md-0">
                        <div class="about-text-content section-text text-muted">
                            <?php
                            while (have_posts()):
                                the_post();
                                // Mostriamo il contenuto dell'editor di WordPress in questa colonna sinistra
                                the_content();
                            endwhile;
                            ?>
                        </div>
                    </div>

                    <!-- Image Column (Right) -->
                    <div class="col-md-6">
                        <div class="about-image-wrapper">
                            <?php if (has_post_thumbnail()): ?>
                                <?php
                                $thumb_id = get_post_thumbnail_id();
                                $thumb_url_array = wp_get_attachment_image_src($thumb_id, 'full', true);
                                $thumb_url = $thumb_url_array[0];
                                ?>
                                <img src="<?php echo esc_url($thumb_url); ?>" alt="<?php the_title_attribute(); ?>"
                                    class="img-fluid rounded shadow-sm water-theme-img w-100">
                            <?php else: ?>
                                <div class="bg-light d-flex align-items-center justify-content-center rounded shadow-sm water-theme-img w-100"
                                    style="height: 400px; border: 2px dashed #ddd;">
                                    <p class="text-muted">Featured Image not set</p>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- 24/7 EMERGENCY PLUMBING (Global CTA) -->
    <section id="emergency" class="section-emergency py-5">
        <div class="emergency-box">
            <!-- Top Row: Text and Features -->
            <div class="row align-items-stretch mb-5">
                <!-- Left Column: Text Content -->
                <div class="col-lg-6 mb-5 mb-lg-0">
                    <span class="emergency-badge"><i class="fas fa-phone-alt"></i> Available Now</span>
                    <h2 class="emergency-title">
                        <span class="emergency-accent">24/7</span>
                        Emergency Plumbing Service
                    </h2>
                    <p class="emergency-desc">
                        Burst pipes, flooding, or gas leaks don't wait — and neither do we. Our certified emergency
                        plumbing team is on standby around the clock, ready to respond within <strong>30
                            minutes</strong> anywhere in the area. No hidden fees, no surprises — just fast,
                        reliable service when you need it most.
                    </p>

                    <div class="emergency-stats d-flex mb-4">
                        <div class="stat-item text-center me-4">
                            <span class="stat-number">30</span>
                            <span class="stat-label">MIN RESPONSE</span>
                        </div>
                        <div class="stat-item text-center me-4">
                            <span class="stat-number">24/7</span>
                            <span class="stat-label">AVAILABILITY</span>
                        </div>
                        <div class="stat-item text-center">
                            <span class="stat-number">100%</span>
                            <span class="stat-label">SATISFACTION</span>
                        </div>
                    </div>

                    <a href="tel:<?php echo esc_attr(str_replace(' ', '', get_option('ticinoweb_contact_phone', ''))); ?>"
                        class="btn btn-primary btn-lg mt-3">
                        <i class="fas fa-phone-alt me-2"></i> Call Emergency Now
                    </a>
                </div>

                <!-- Right Column: Features -->
                <div class="col-lg-6">
                    <div class="emergency-features h-100 d-flex flex-column justify-content-center">

                        <div class="emergency-feature-card mb-4">
                            <div class="feature-icon-circle">
                                <i class="fas fa-bolt"></i>
                            </div>
                            <div class="feature-info">
                                <h4>Lightning-Fast Response</h4>
                                <p>Our dispatch team ensures a certified plumber is at your door within 30
                                    minutes.</p>
                            </div>
                        </div>

                        <div class="emergency-feature-card mb-4">
                            <div class="feature-icon-circle">
                                <i class="fas fa-shield-alt"></i>
                            </div>
                            <div class="feature-info">
                                <h4>Licensed &amp; Insured Team</h4>
                                <p>Every technician is fully licensed, insured and background-checked.</p>
                            </div>
                        </div>

                        <div class="emergency-feature-card">
                            <div class="feature-icon-circle">
                                <i class="fas fa-hand-holding-dollar"></i>
                            </div>
                            <div class="feature-info">
                                <h4>Transparent Pricing</h4>
                                <p>You'll receive a clear, upfront quote before any work begins.</p>
                            </div>
                        </div>

                    </div>
                </div>
            </div> <!-- End Top Row -->

            <!-- Bottom Row: Simple Photo Gallery -->
            <div class="row">
                <div class="col-12">
                    <?php
                    // Fetch 'gallery home' images
                    $gallery_term = get_term_by('name', 'gallery home', 'ticinoweb_media_gallery');
                    $gallery_images = array();

                    if ($gallery_term && !is_wp_error($gallery_term)) {
                        $gallery_images = get_posts(array(
                            'post_type' => 'attachment',
                            'post_status' => 'inherit',
                            'posts_per_page' => -1,
                            'tax_query' => array(
                                array(
                                    'taxonomy' => 'ticinoweb_media_gallery',
                                    'field' => 'term_id',
                                    'terms' => $gallery_term->term_id,
                                ),
                            ),
                            'orderby' => 'menu_order',
                            'order' => 'ASC',
                        ));
                    }
                    ?>

                    <div class="emergency-gallery-wrapper">
                        <?php if (!empty($gallery_images)): ?>
                            <div class="swiper emergencySwiper">
                                <div class="swiper-wrapper">
                                    <?php foreach ($gallery_images as $image):
                                        $img_url_full = wp_get_attachment_image_url($image->ID, 'large');
                                        ?>
                                        <div class="swiper-slide">
                                            <div class="gallery-slide-inner"
                                                style="background-image: url('<?php echo esc_url($img_url_full); ?>');">
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                                <div class="swiper-pagination"></div>
                            </div>
                        <?php else: ?>
                            <!-- Placeholder if empty -->
                            <div class="d-flex align-items-center justify-content-center h-100 text-white-50">
                                <p>No images in 'gallery home'</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- CONTACTS SECTION (Global CTA) -->
    <?php
    $contact_phone = get_option('ticinoweb_contact_phone', '');
    $contact_email = get_option('ticinoweb_contact_email', '');
    $contact_address = get_option('ticinoweb_contact_address', '');
    ?>
    <section id="contatti" class="section-contacts py-5">
        <div class="container eco-container-1300">
            <div class="contact-boxed-wrapper">
                <h2 class="section-heading text-center mb-5">Contact Us</h2>
                <div class="contact-row">

                    <!-- Phone -->
                    <?php if ($contact_phone): ?>
                        <div class="contact-card" id="card-phone">
                            <div class="card-inner">
                                <i class="fas fa-phone"></i>
                                <h4>Phone</h4>
                                <p>
                                    <a href="tel:<?php echo esc_attr(str_replace(' ', '', $contact_phone)); ?>">
                                        <?php echo esc_html($contact_phone); ?>
                                    </a>
                                </p>
                            </div>
                        </div>
                    <?php endif; ?>

                    <!-- Email -->
                    <?php if ($contact_email): ?>
                        <div class="contact-card" id="card-email">
                            <div class="card-inner">
                                <i class="fas fa-envelope"></i>
                                <h4>Email</h4>
                                <p>
                                    <a href="mailto:<?php echo esc_attr($contact_email); ?>">
                                        <?php echo esc_html($contact_email); ?>
                                    </a>
                                </p>
                            </div>
                        </div>
                    <?php endif; ?>

                    <!-- Address -->
                    <?php if ($contact_address): ?>
                        <div class="contact-card" id="card-address">
                            <div class="card-inner">
                                <i class="fas fa-location-dot"></i>
                                <h4>Address</h4>
                                <p>
                                    <?php echo wp_kses_post($contact_address); ?>
                                </p>
                            </div>
                        </div>
                    <?php endif; ?>

                </div>
            </div>
        </div>
    </section>

</main>

<script>
    // We need to initialize the Swiper for the Emergency gallery section on these pages too!
    document.addEventListener('DOMContentLoaded', function () {
        if (typeof Swiper !== 'undefined' && document.querySelector('.emergencySwiper')) {
            var emergencySwiper = new Swiper(".emergencySwiper", {
                loop: true,
                effect: "slide",
                speed: 1000,
                autoplay: {
                    delay: 4000,
                    disableOnInteraction: false,
                    pauseOnMouseEnter: true
                },
                pagination: {
                    el: ".swiper-pagination",
                    clickable: true,
                },
            });
        }
    });
</script>

<?php get_footer(); ?>