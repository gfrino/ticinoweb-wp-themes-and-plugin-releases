<?php
/**
 * Ecoproplumbing Child Theme - Footer
 */

// Get contact info from Customizer
$contact = function_exists('ticinoweb_get_contact_info') ? ticinoweb_get_contact_info() : array();
$logo_url = get_option('ticinoweb_site_logo');
if (empty($logo_url) && function_exists('ticinoweb_get_site_logo')) {
    $logo_url = ticinoweb_get_site_logo();
}
?>

<footer class="site-footer-modern" id="footer">
    <div class="footer-content-wrapper">
        <div class="footer-centered-stack">

            <!-- 1. LOGO -->
            <div class="footer-item brand mb-3">
                <?php if ($logo_url): ?>
                    <img src="<?php echo esc_url($logo_url); ?>" alt="<?php bloginfo('name'); ?>" class="footer-logo"
                        loading="lazy" decoding="async">
                <?php else: ?>
                    <h2 class="footer-title text-dark"><?php bloginfo('name'); ?></h2>
                <?php endif; ?>
            </div>

            <!-- 2. MENU (Icon List Style - Horizontal) -->
            <div class="footer-item nav-section mb-3">
                <!-- <h4 class="footer-mini-title">Menu</h4> -->
                <nav class="footer-nav-inline">
                    <?php
                    wp_nav_menu(array(
                        'theme_location' => 'primary',
                        'menu_class' => 'menu-flex-list justify-content-center',
                        'container' => false,
                        'depth' => 1,
                    ));
                    ?>
                </nav>
            </div>

            <!-- 3. CONTACTS (Horizontal) -->
            <div class="footer-item contact-section mb-3">
                <!-- <h4 class="footer-mini-title">Contatti</h4> -->
                <ul class="contact-flex-list justify-content-center">
                    <?php if (!empty($contact['phone'])): ?>
                        <li>
                            <i class="fas fa-phone-alt"></i>
                            <a
                                href="tel:<?php echo esc_attr(str_replace(' ', '', $contact['phone'])); ?>"><?php echo esc_html($contact['phone']); ?></a>
                        </li>
                    <?php endif; ?>
                    <?php if (!empty($contact['email'])): ?>
                        <li>
                            <i class="fas fa-envelope"></i>
                            <a
                                href="mailto:<?php echo esc_attr($contact['email']); ?>"><?php echo esc_html($contact['email']); ?></a>
                        </li>
                    <?php endif; ?>
                    <?php if (!empty($contact['address'])): ?>
                        <li>
                            <i class="fas fa-map-marker-alt"></i>
                            <span><?php echo esc_html($contact['address']); ?></span>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>

        </div>
    </div>

    <!-- Copyright -->
    <div class="footer-bottom">
        <div class="footer-content-wrapper copyright-flex justify-content-center">
            <p class="mb-0">&copy; <?php echo date('Y'); ?> <?php bloginfo('name'); ?>. Design by <a
                    href="https://ticinoweb.com" target="_blank">ticinoWEB</a></p>
        </div>
        <?php
        // Prefer WordPress core's configured privacy page; fall back to the tW SEO setting the
        // parent theme's cookie banner already uses, so the two never point at different pages.
        $privacy_url = get_privacy_policy_url();
        if (empty($privacy_url)) {
            $privacy_url = get_option('tw_privacy_policy_url');
        }
        if (!empty($privacy_url)): ?>
            <div class="footer-content-wrapper footer-legal-links">
                <a href="<?php echo esc_url($privacy_url); ?>">Privacy Policy</a>
            </div>
        <?php endif; ?>
    </div>
</footer>

<?php
$eco_cta = function_exists('ecoproplumbing_get_cta_config') ? ecoproplumbing_get_cta_config() : array('type' => 'modal', 'target_modal' => '#bookingModal');
get_template_part('template-parts/modal', 'booking');
if ($eco_cta['type'] === 'iframe') {
    get_template_part('template-parts/modal', 'iframe');
}
?>

<!-- Floating Booking Button -->
<button type="button" class="floating-booking-btn shadow-lg" data-bs-toggle="modal" data-bs-target="<?php echo esc_attr($eco_cta['target_modal']); ?>"
    aria-label="Request Service">
    <?php // Not lazy-loaded: the button is position:fixed and visible from first paint,
          // so deferring it would only make it pop in late.
          //
          // Resolved against the current site's upload directory rather than hardcoded:
          // this child theme is shared by more than one subsite, and an absolute URL made
          // every one of them load the mark from ecoproplumbing.com/sites/151. Deliberately
          // NOT the ticinoweb_site_logo chain used by header.php and the booking modal —
          // that resolves to the wide banner logo, which would be squeezed into this round
          // button. This is the square mark. ?>
    <img src="<?php echo esc_url( wp_get_upload_dir()['baseurl'] . '/2026/02/cropped-logo-eco-plumber-scaled-1.jpg' ); ?>"
        alt="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>" decoding="async">
</button>
<?php // Sibling, not child, of the button: the button clips with overflow:hidden to stay
      // round, so anything inside it could never stick out. aria-hidden because the
      // button already has its own accessible name; this is only a visual nudge. ?>
<span class="eco-cta-callout" aria-hidden="true">
    <span class="eco-cta-callout__inner">
        <span class="eco-cta-callout__text"><?php echo esc_html( ecoproplumbing_cta_callout_text() ); ?></span>
        <svg class="eco-cta-callout__arrow" viewBox="0 0 60 50" width="60" height="50" focusable="false">
            <path d="M6 6 C 10 30, 28 40, 50 42" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round"/>
            <path d="M40 33 L 51 42 L 39 48" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>
    </span>
</span>

<!-- BACKGROUND WAVE ANIMATION -->
<canvas id="eco-wave-canvas"></canvas>
<script>
    document.addEventListener("DOMContentLoaded", function () {
        const canvas = document.getElementById('eco-wave-canvas');
        if (!canvas) return;

        const ctx = canvas.getContext('2d');
        let width, height;

        // Configurazione delle grandi onde fluide piene (stile 3D cloth)
        const numBands = 5; // Fasce enormi e sovrapposte
        const waveSpeed = 0.0002; // Movimento lentissimo ed elegante

        let time = 0;
        let rafId = null;

        // Users who ask for less motion get a single static frame instead of a
        // permanently animating full-viewport canvas.
        const animate = !(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);

        function resize() {
            width = window.innerWidth;
            height = window.innerHeight;

            // Performance Optimization: Downscale the internal rendering resolution
            // Since this is a soft background, rendering at 50% resolution internally
            // massively reduces GPU/CPU load, making the animation buttery smooth.
            const dpr = 0.5; // Render at half physical resolution
            canvas.width = width * dpr;
            canvas.height = height * dpr;
            ctx.scale(dpr, dpr);
        }

        window.addEventListener('resize', resize);
        resize();

        function draw() {
            ctx.clearRect(0, 0, width, height);
            ctx.globalCompositeOperation = 'source-over';

            for (let i = 0; i < numBands; i++) {
                ctx.beginPath();

                // Variabili di altezza per ogni fascia
                const p1 = i / numBands;
                const p2 = (i + 1) / numBands;

                const phase1 = p1 * Math.PI * 1.5;
                const phase2 = p2 * Math.PI * 1.5;

                // Tracciato superiore della fascia
                for (let x = -150; x <= width + 150; x += 60) {
                    const nx = x / width;
                    const tPhase = time * waveSpeed;

                    const w1 = Math.sin(nx * 2.5 + tPhase + phase1) * (height * 0.25);
                    const w2 = Math.cos(nx * 4.0 - tPhase * 0.8 + phase1 * 1.2) * (height * 0.1);

                    const yTop = height * 0.1 + (p1 * height * 0.8) + w1 + w2;

                    if (x === -150) ctx.moveTo(x, yTop);
                    else ctx.lineTo(x, yTop);
                }

                // Tracciato inferiore della fascia (al contrario per chiudere il poligono)
                for (let x = width + 150; x >= -150; x -= 60) {
                    const nx = x / width;
                    const tPhase = time * waveSpeed;

                    const w1 = Math.sin(nx * 2.5 + tPhase + phase2) * (height * 0.25);
                    const w2 = Math.cos(nx * 4.0 - tPhase * 0.8 + phase2 * 1.2) * (height * 0.1);

                    // La curva finale chiude molto in basso per nascondere il fondo del canvas
                    let yBottom = height * 0.1 + (p2 * height * 0.8) + w1 + w2;
                    if (i === numBands - 1) yBottom = height + 200;

                    ctx.lineTo(x, yBottom);
                }

                ctx.closePath();

                // Sfumature ricche e vibranti da Blu Elettrico a Verde Smeraldo / Acqua
                let hue1 = 210 - (i * 15); // Da Blu 210 a Verde 135
                let hue2 = 210 - ((i + 1) * 15);

                // Per rendere i colori simili all'immagine (blu, azzurro, verde)
                const gradient = ctx.createLinearGradient(0, height * p1 - 100, 0, height * p2 + 200);

                // Il top della fascia è più chiaro e luminoso (simula la luce)
                gradient.addColorStop(0, `hsla(${hue1}, 80%, 75%, 0.85)`);
                // Il bottom della fascia è più scuro e saturo (simula l'ombra del 3D)
                gradient.addColorStop(1, `hsla(${hue2}, 90%, 45%, 0.95)`);

                ctx.fillStyle = gradient;
                ctx.fill();

                // Aggiungiamo un delicato riflesso di luce sul bordo superiore della fascia
                ctx.beginPath();
                for (let x = -150; x <= width + 150; x += 60) {
                    const nx = x / width;
                    const tPhase = time * waveSpeed;
                    const w1 = Math.sin(nx * 2.5 + tPhase + phase1) * (height * 0.25);
                    const w2 = Math.cos(nx * 4.0 - tPhase * 0.8 + phase1 * 1.2) * (height * 0.1);
                    const yTop = height * 0.1 + (p1 * height * 0.8) + w1 + w2;
                    if (x === -150) ctx.moveTo(x, yTop);
                    else ctx.lineTo(x, yTop);
                }
                // Highlight color (sottile e molto chiaro)
                ctx.strokeStyle = `hsla(${hue1}, 90%, 90%, 0.7)`;
                ctx.lineWidth = 2;
                ctx.stroke();
            }

            time += 16;
            rafId = animate ? requestAnimationFrame(draw) : null;
        }

        function start() {
            // The guard is the point: without it a second caller would spawn a
            // second requestAnimationFrame chain and the canvas would render
            // twice per frame for the life of the page.
            if (rafId === null && animate) {
                rafId = requestAnimationFrame(draw);
            }
        }

        function stop() {
            if (rafId !== null) {
                cancelAnimationFrame(rafId);
                rafId = null;
            }
        }

        // No point burning CPU on a background canvas in a background tab.
        document.addEventListener('visibilitychange', function () {
            if (document.hidden) {
                stop();
            } else {
                start();
            }
        });

        if (animate) {
            start();
        } else {
            draw(); // one static frame, no loop
        }
    });
</script>

<?php wp_footer(); ?>
</body>

</html>