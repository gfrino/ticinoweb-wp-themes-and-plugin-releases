<?php
/**
 * Template Name: Contact
 *
 * The template for displaying the Contact page.
 *
 * @package EcoProPlumbing
 */

get_header(); ?>

<main id="primary" class="site-main contact-page">

    <!-- HERO SECTION -->
    <section class="about-hero">
        <div class="about-hero-overlay"></div>
        <!-- Animated Waves Container -->
        <div class="ocean">
            <div class="wave"></div>
            <div class="wave"></div>
            <div class="wave"></div>
            <div class="wave"></div>
        </div>
        <div class="container about-hero-content position-relative z-1 text-center">
            <h1 class="about-title entry-title" style="text-shadow: 0 2px 4px rgba(0,0,0,0.5);"><?php the_title(); ?>
            </h1>
            <p class="about-subtitle">We're Here to Help with All Your Plumbing Needs</p>
        </div>
    </section>

    <!-- CONTACT CARDS SECTION -->
    <?php
    $contact_phone = get_option('ticinoweb_contact_phone', '');
    $contact_email = get_option('ticinoweb_contact_email', '');
    $contact_address = get_option('ticinoweb_contact_address', '');
    ?>
    <section class="section-contacts py-3 mt-4">
        <div class="container">
            <!-- Boxed wrapper styling removed locally to allow cards to float free like row -->
            <div class="contact-row"
                style="padding: 0; box-shadow: none; background: transparent; max-width: 1100px; margin: 0 auto;">

                <!-- Phone -->
                <?php if ($contact_phone): ?>
                    <div class="contact-card" id="card-phone">
                        <div class="card-inner">
                            <i class="fas fa-phone"></i>
                            <h4>Phone</h4>
                            <p>
                                <a href="tel:<?php echo esc_attr(str_replace(' ', '', $contact_phone)); ?>">
                                    <?php echo esc_html($contact_phone); ?>
                                </a>
                            </p>
                        </div>
                    </div>
                <?php endif; ?>

                <!-- Email -->
                <?php if ($contact_email): ?>
                    <div class="contact-card" id="card-email">
                        <div class="card-inner">
                            <i class="fas fa-envelope"></i>
                            <h4>Email</h4>
                            <p>
                                <a href="mailto:<?php echo esc_attr($contact_email); ?>">
                                    <?php echo esc_html($contact_email); ?>
                                </a>
                            </p>
                        </div>
                    </div>
                <?php endif; ?>

                <!-- Address -->
                <?php if ($contact_address): ?>
                    <div class="contact-card" id="card-address">
                        <div class="card-inner">
                            <i class="fas fa-location-dot"></i>
                            <h4>Address</h4>
                            <p><?php echo wp_kses_post($contact_address); ?></p>
                        </div>
                    </div>
                <?php endif; ?>

            </div>
        </div>
    </section>

    <!-- FORM & MAP SECTION -->
    <section class="section-contact-form py-5 mb-5" style="background-color: #f8fafc; border-top: 1px solid #e2e8f0;">
        <div class="container">
            <div class="contact-form-box p-4 p-md-5">
                <div class="row align-items-stretch gx-lg-5">

                    <!-- Text & Form (Left) -->
                    <div class="col-lg-6 mb-5 mb-lg-0 pe-lg-5">
                        <h4 class="text-primary text-uppercase mb-1" style="font-weight: 600; letter-spacing: 1px;">Get
                            in
                            Touch</h4>
                        <h2 class="section-heading mb-4">Send Us a Message</h2>
                        <p class="text-muted mb-4">Fill out the form below and our team will get back to you as soon as
                            possible. For emergencies, please call us directly.</p>

                        <div class="contact-form-wrapper">
                            <?php
                            // Check if there's content in the WordPress editor (maybe a shortcode for Contact Form 7)
                            $show_default_form = true;
                            if (have_posts()) {
                                while (have_posts()) {
                                    the_post();
                                    $content = get_the_content();
                                    // If content is not empty, display it (good for shortcodes)
                                    if (trim(strip_tags($content, '<img><iframe><script><style><form><input><textarea><select><button>')) !== '' || strpos($content, '[') !== false) {
                                        the_content();
                                        $show_default_form = false;
                                    }
                                }
                            }

                            // fallback HTML form if no shortcode is placed
                            if ($show_default_form) {
                                ?>
                                <form class="eco-html-form">
                                    <div class="row g-4 mb-4">
                                        <!-- Rows -->
                                        <div class="col-12">
                                            <input type="text" class="form-control form-control-lg px-4"
                                                placeholder="First Name *" required>
                                        </div>
                                        <div class="col-12">
                                            <input type="text" class="form-control form-control-lg px-4"
                                                placeholder="Last Name *" required>
                                        </div>

                                        <div class="col-12">
                                            <input type="email" class="form-control form-control-lg px-4"
                                                placeholder="Email Address *" required>
                                        </div>
                                        <div class="col-12">
                                            <input type="tel" class="form-control form-control-lg px-4"
                                                placeholder="Phone Number *" required>
                                        </div>

                                        <!-- Row 3: Full Width -->
                                        <div class="col-12">
                                            <select class="form-control form-control-lg px-4 eco-form-select" required>
                                                <option value="" disabled selected>Service Required *</option>
                                                <option value="General Plumbing">General Plumbing Repair</option>
                                                <option value="Drain Cleaning">Drain & Sewer Cleaning</option>
                                                <option value="Water Heaters">Water Heater Service</option>
                                                <option value="Leaks">Leak Detection & Repair</option>
                                                <option value="Emergency">24/7 Emergency Service</option>
                                                <option value="Other">Other / Estimate Request</option>
                                            </select>
                                        </div>

                                        <!-- Row 4: Textarea Full Width -->
                                        <div class="col-12">
                                            <textarea class="form-control px-4 py-3" rows="5"
                                                placeholder="How can we help you? *" required></textarea>
                                        </div>
                                    </div>

                                    <!-- Submit Button -->
                                    <button type="submit"
                                        class="btn btn-primary btn-lg px-5 w-100 shadow-sm form-submit-btn"
                                        style="padding: 1.25rem 2.5rem; font-size: 1.1rem;">Send Message
                                    </button>
                                </form>
                                <?php
                            }
                            ?>
                        </div>
                    </div>

                    <!-- Map / Location (Right) -->
                    <div class="col-lg-6 ps-lg-5">
                        <div class="contact-map-wrapper h-100 rounded overflow-hidden shadow-sm"
                            style="min-height: 550px;">
                            <div id="contactPageMap"
                                style="width: 100%; height: 100%; min-height: 550px; z-index: 1; background: transparent;">
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </section>

</main>

<!-- Leaflet Map JS for Contact Page -->
<script>
    document.addEventListener('DOMContentLoaded', function () {
        if (document.getElementById('contactPageMap') && typeof L !== 'undefined') {
            // Same source as the front page: the service-area fields on the home
            // page. This file used to carry its own duplicate of the city list, so
            // the two maps could drift apart.
            var cities = <?php echo wp_json_encode( eco_sa_mappable_areas() ); ?>;

            if (!cities.length) {
                return;
            }

            var meanLat = cities.reduce(function (t, c) { return t + c.lat; }, 0) / cities.length;
            var meanLng = cities.reduce(function (t, c) { return t + c.lng; }, 0) / cities.length;

            var map = L.map('contactPageMap', {
                scrollWheelZoom: false
            }).setView([meanLat, meanLng], 11);

            L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Street_Map/MapServer/tile/{z}/{y}/{x}', {
                attribution: '© Esri',
                maxZoom: 18
            }).addTo(map);

            var liquidIcon = L.divIcon({
                className: 'custom-div-icon',
                html: "<div class='water-drop-marker'></div>",
                iconSize: [30, 30],
                iconAnchor: [15, 30],
                popupAnchor: [0, -32]
            });

            cities.forEach(function (city) {
                L.marker([city.lat, city.lng], { icon: liquidIcon })
                    .addTo(map)
                    .bindPopup('<strong>' + city.name + '</strong><br>Eco Pro Service Area');
            });

            // Fit map
            var group = L.featureGroup(cities.map(function (c) {
                return L.marker([c.lat, c.lng]);
            }));

            // Wait slightly for container to size correctly
            setTimeout(function () {
                map.invalidateSize();
                map.fitBounds(group.getBounds().pad(0.1));
            }, 500);
        }
    });
</script>

<?php
get_footer();
?>