<?php
/**
 * Call to Action (Floating Button) Settings for Eco Pro Plumbing
 *
 * Adds "LINK CTA" configuration to the ticinoWEB Settings screen,
 * allowing switching between the native booking modal and an external iframe link.
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Get current CTA configuration
 *
 * @return array
 */
function ecoproplumbing_get_cta_config() {
    $type = get_option('ecopro_cta_type', 'modal');
    $default_link = 'https://clienthub.getjobber.com/hubs/60eed09e-b967-4fce-93e9-d964f89d8cff/public/requests/4655275/new';
    $link = get_option('ecopro_cta_link', $default_link);
    if (empty($link)) {
        $link = $default_link;
    }

    $is_iframe = ($type === 'iframe' && !empty($link));

    return array(
        'type'         => $is_iframe ? 'iframe' : 'modal',
        'link'         => esc_url($link),
        'target_modal' => $is_iframe ? '#bookingIframeModal' : '#bookingModal',
    );
}

/**
 * Register settings in the existing ticinoweb_settings_group
 */
add_action('admin_init', 'ecoproplumbing_register_cta_settings');
function ecoproplumbing_register_cta_settings() {
    register_setting('ticinoweb_settings_group', 'ecopro_cta_type', array(
        'type'              => 'string',
        'sanitize_callback' => function ($val) {
            return in_array($val, array('modal', 'iframe'), true) ? $val : 'modal';
        },
        'default'           => 'modal',
    ));

    register_setting('ticinoweb_settings_group', 'ecopro_cta_link', array(
        'type'              => 'string',
        'sanitize_callback' => 'esc_url_raw',
        'default'           => 'https://clienthub.getjobber.com/hubs/60eed09e-b967-4fce-93e9-d964f89d8cff/public/requests/4655275/new',
    ));
}

/**
 * Render and inject the LINK CTA setting row in the ticinoWEB Settings page
 */
add_action('admin_footer', 'ecoproplumbing_inject_cta_settings_field');
function ecoproplumbing_inject_cta_settings_field() {
    $screen = get_current_screen();
    if (!$screen || ($screen->id !== 'toplevel_page_ticinoweb-settings' && $screen->id !== 'toplevel_page_ticinoweb-cms')) {
        return;
    }

    $cta_type = get_option('ecopro_cta_type', 'modal');
    $default_link = 'https://clienthub.getjobber.com/hubs/60eed09e-b967-4fce-93e9-d964f89d8cff/public/requests/4655275/new';
    $cta_link = get_option('ecopro_cta_link', $default_link);
    ?>
    <table id="ecopro-cta-setting-template" style="display: none;">
        <tbody>
            <tr id="ecopro-cta-setting-row">
                <th scope="row">
                    <label for="ecopro_cta_type"><?php esc_html_e('LINK CTA', 'ecoproplumbing'); ?></label>
                </th>
                <td>
                    <div style="background: #ffffff; border: 1px solid #c3c4c7; border-radius: 6px; padding: 16px 20px; max-width: 720px; box-shadow: 0 1px 3px rgba(0,0,0,0.04);">
                        <p style="margin: 0 0 12px; font-weight: 600; font-size: 13.5px; color: #1d2327;">
                            <?php esc_html_e('Call to Action del Logo Fluttuante (pulsante che rimbalza)', 'ecoproplumbing'); ?>
                        </p>

                        <div style="display: flex; gap: 24px; margin-bottom: 14px; flex-wrap: wrap;">
                            <label style="display: inline-flex; align-items: center; gap: 8px; cursor: pointer; font-size: 13px; font-weight: 500;">
                                <input type="radio" name="ecopro_cta_type" value="modal" <?php checked($cta_type, 'modal'); ?>>
                                <span><strong><?php esc_html_e('Popup Modulo Standard', 'ecoproplumbing'); ?></strong> (<?php esc_html_e('modulo di prenotazione nativo', 'ecoproplumbing'); ?>)</span>
                            </label>

                            <label style="display: inline-flex; align-items: center; gap: 8px; cursor: pointer; font-size: 13px; font-weight: 500;">
                                <input type="radio" name="ecopro_cta_type" value="iframe" <?php checked($cta_type, 'iframe'); ?>>
                                <span><strong><?php esc_html_e('Custom Link in Iframe', 'ecoproplumbing'); ?></strong></span>
                            </label>
                        </div>

                        <div id="ecopro-cta-link-container" style="<?php echo ($cta_type === 'iframe') ? '' : 'display: none;'; ?> margin-top: 14px; padding-top: 14px; border-top: 1px dashed #dcdcde;">
                            <label for="ecopro_cta_link" style="display: block; font-weight: 600; font-size: 13px; margin-bottom: 6px; color: #1d2327;">
                                <?php esc_html_e('URL Custom Link (Iframe):', 'ecoproplumbing'); ?>
                            </label>
                            <input type="url" id="ecopro_cta_link" name="ecopro_cta_link"
                                   value="<?php echo esc_attr($cta_link); ?>"
                                   class="large-text" style="font-size: 13px; padding: 7px 10px; width: 100%; border-radius: 4px;"
                                   placeholder="https://clienthub.getjobber.com/...">
                            <p class="description" style="margin-top: 6px; font-size: 12px; color: #646970; line-height: 1.5;">
                                <?php esc_html_e('Quando è selezionato "Custom Link in Iframe", cliccando sul logo fluttuante (e sul pulsante di richiesta in hero) si aprirà una finestra modale a schermo intero contenente questo URL all\'interno di un iframe.', 'ecoproplumbing'); ?>
                            </p>
                        </div>
                    </div>
                </td>
            </tr>
        </tbody>
    </table>

    <script>
    jQuery(document).ready(function($) {
        var $row = $('#ecopro-cta-setting-row');
        if (!$row.length) return;

        // Inserimento prioritario nella tab "Generale" di Settings (toplevel_page_ticinoweb-settings)
        var $generalTable = $('#general table.form-table');
        if ($generalTable.length) {
            var $commentsRow = $generalTable.find('tr:has(#ticinoweb_disable_comments)').first();
            if ($commentsRow.length) {
                $commentsRow.after($row);
            } else {
                $generalTable.prepend($row);
            }
        } else {
            // Fallback per ticinoweb-cms se visualizzato lì
            var $cmsTable = $('.ticinoweb-settings-tabs table.form-table').first();
            if ($cmsTable.length) {
                $cmsTable.prepend($row);
            }
        }

        // Toggle visibilità campo link
        $('input[name="ecopro_cta_type"]').on('change', function() {
            if ($(this).val() === 'iframe') {
                $('#ecopro-cta-link-container').slideDown(180);
            } else {
                $('#ecopro-cta-link-container').slideUp(180);
            }
        });
    });
    </script>
    <?php
}
