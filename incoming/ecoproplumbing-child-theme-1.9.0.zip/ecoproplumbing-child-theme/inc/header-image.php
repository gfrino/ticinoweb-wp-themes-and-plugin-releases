<?php
/**
 * Secondary image in the header, to the right of the menu.
 *
 * Per-site, like the service areas: the field lives on the page set as the front
 * page, so ecoproplumbing.ca and ecoproplumbing.com each carry their own badge
 * while sharing this theme.
 *
 * The attachment ID is stored, not the URL. A stored URL would be rewritten by any
 * `wp search-replace` of the domain — and silently broken by one that gets the new
 * host wrong — whereas an ID resolves through wp_get_attachment_image() against
 * whatever the site URL happens to be at render time.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

const ECO_HDR_IMG_META = '_eco_header_secondary_image_id';

/**
 * Attachment ID of this site's secondary header image.
 *
 * @return int 0 when unset or when the attachment no longer exists.
 */
function eco_header_secondary_image_id() {
    $page_id = (int) get_option( 'page_on_front' );
    if ( ! $page_id ) {
        return 0;
    }

    $id = (int) get_post_meta( $page_id, ECO_HDR_IMG_META, true );

    // A deleted attachment would otherwise render an empty <img>.
    if ( $id && get_post_type( $id ) !== 'attachment' ) {
        return 0;
    }

    return $id;
}

/**
 * Render the secondary header image, or nothing when none is set.
 *
 * @return void
 */
function eco_header_secondary_image() {
    $id = eco_header_secondary_image_id();
    if ( ! $id ) {
        return;
    }

    $alt = trim( (string) get_post_meta( $id, '_wp_attachment_image_alt', true ) );
    if ( $alt === '' ) {
        $alt = get_bloginfo( 'name' );
    }

    // Above the fold, so it is not lazy-loaded — but the theme does not claim
    // fetchpriority="high" for a secondary badge; the logo in header.php is the LCP
    // candidate. Note that passing 'fetchpriority' => 'auto' in $attr below would be
    // useless: wp_get_loading_optimization_attributes() runs after $attr and
    // overrides it, so the attribute has to be dropped by the filter below, which
    // runs later still.
    //
    // LiteSpeed Cache re-adds fetchpriority="high" to viewport images on cached
    // pages (its VPI feature, see media.cls.php) — that is the plugin's own call and
    // is not fought here. This keeps the markup correct everywhere LiteSpeed is not
    // rewriting it: logged-in requests, cache disabled, other environments.
    $drop_fetchpriority = static function ( $attr ) {
        unset( $attr['fetchpriority'] );

        return $attr;
    };

    add_filter( 'wp_get_attachment_image_attributes', $drop_fetchpriority, 99 );

    echo '<div class="header-secondary-image d-none d-xl-flex">';
    echo wp_get_attachment_image(
        $id,
        'full',
        false,
        array(
            'alt'      => $alt,
            'class'    => 'header-secondary-img',
            'loading'  => 'eager',
            'decoding' => 'async',
        )
    );
    echo '</div>';

    remove_filter( 'wp_get_attachment_image_attributes', $drop_fetchpriority, 99 );
}

add_filter( 'body_class', 'eco_header_img_body_class' );
/**
 * Flag the presence of a secondary image on <body>.
 *
 * The header nav breakpoint depends on it: with the image there is no room for the
 * menu on one line between 992 and 1199px, so it collapses to the hamburger; with
 * no image the menu takes that space and stays expanded down to 992px as before.
 *
 * @param string[] $classes
 * @return string[]
 */
function eco_header_img_body_class( $classes ) {
    if ( eco_header_secondary_image_id() ) {
        $classes[] = 'eco-has-header-image';
    }

    return $classes;
}

/**
 * Bootstrap breakpoint suffix for the header, matching the CSS above.
 *
 * @return string 'xl' when a secondary image is set, otherwise 'lg'.
 */
function eco_header_breakpoint() {
    return eco_header_secondary_image_id() ? 'xl' : 'lg';
}

/* -------------------------------------------------------------------------
 * Admin
 * ---------------------------------------------------------------------- */

add_action( 'admin_enqueue_scripts', 'eco_header_img_admin_assets' );
/**
 * @param string $hook
 */
function eco_header_img_admin_assets( $hook ) {
    if ( $hook !== 'post.php' && $hook !== 'post-new.php' ) {
        return;
    }

    // Needed for the media modal below.
    wp_enqueue_media();
}

add_action( 'add_meta_boxes', 'eco_header_img_add_meta_box' );
function eco_header_img_add_meta_box() {
    if ( ! get_option( 'page_on_front' ) ) {
        return;
    }

    add_meta_box(
        'eco-header-secondary-image',
        __( 'Secondary Image in Header', 'ecoproplumbing-child-theme' ),
        'eco_header_img_render_meta_box',
        'page',
        'side',
        'default'
    );
}

/**
 * @param WP_Post $post
 */
function eco_header_img_render_meta_box( $post ) {
    if ( (int) $post->ID !== (int) get_option( 'page_on_front' ) ) {
        echo '<p>' . esc_html__( 'Questa immagine si gestisce sulla pagina impostata come home del sito.', 'ecoproplumbing-child-theme' ) . '</p>';

        return;
    }

    wp_nonce_field( 'eco_header_img_save', 'eco_header_img_nonce' );

    $id  = (int) get_post_meta( $post->ID, ECO_HDR_IMG_META, true );
    $src = $id ? wp_get_attachment_image_url( $id, 'medium' ) : '';
    ?>
    <div id="eco-hdr-img-wrap">
        <input type="hidden" id="eco_header_secondary_image_id" name="eco_header_secondary_image_id" value="<?php echo esc_attr( $id ); ?>">

        <div id="eco-hdr-img-preview" style="<?php echo $src ? '' : 'display:none;'; ?> margin-bottom:10px;">
            <img src="<?php echo esc_url( $src ); ?>" alt="" style="max-width:100%; height:auto; display:block; border:1px solid #dcdcde; border-radius:4px; background:#fff;">
        </div>

        <p id="eco-hdr-img-empty" style="<?php echo $src ? 'display:none;' : ''; ?> color:#646970;">
            <?php esc_html_e( 'Nessuna immagine impostata.', 'ecoproplumbing-child-theme' ); ?>
        </p>

        <p>
            <button type="button" class="button" id="eco-hdr-img-choose"><?php esc_html_e( 'Scegli immagine', 'ecoproplumbing-child-theme' ); ?></button>
            <button type="button" class="button-link-delete" id="eco-hdr-img-remove" style="<?php echo $src ? '' : 'display:none;'; ?> margin-left:8px;"><?php esc_html_e( 'Rimuovi', 'ecoproplumbing-child-theme' ); ?></button>
        </p>

        <p class="description">
            <?php esc_html_e( 'Mostrata nell\'header a destra del menu. Nascosta sotto i 1200px, dove il menu diventa a comparsa e non ci sarebbe spazio. Vale solo per questo sito: gli altri siti che usano lo stesso tema hanno il proprio campo.', 'ecoproplumbing-child-theme' ); ?>
        </p>
    </div>

    <script>
        jQuery(function ($) {
            var frame;
            var $id      = $('#eco_header_secondary_image_id');
            var $preview = $('#eco-hdr-img-preview');
            var $empty   = $('#eco-hdr-img-empty');
            var $remove  = $('#eco-hdr-img-remove');

            $('#eco-hdr-img-choose').on('click', function (e) {
                e.preventDefault();

                if (frame) {
                    frame.open();
                    return;
                }

                frame = wp.media({
                    title: <?php echo wp_json_encode( __( 'Immagine secondaria header', 'ecoproplumbing-child-theme' ) ); ?>,
                    button: { text: <?php echo wp_json_encode( __( 'Usa questa immagine', 'ecoproplumbing-child-theme' ) ); ?> },
                    library: { type: 'image' },
                    multiple: false
                });

                frame.on('select', function () {
                    var att = frame.state().get('selection').first().toJSON();
                    // Fall back to the full size: SVGs and small images have no
                    // 'medium' derivative, and picking one would give an empty src.
                    var url = (att.sizes && att.sizes.medium) ? att.sizes.medium.url : att.url;

                    $id.val(att.id);
                    $preview.find('img').attr('src', url);
                    $preview.show();
                    $empty.hide();
                    $remove.show();
                });

                frame.open();
            });

            $remove.on('click', function (e) {
                e.preventDefault();
                $id.val('');
                $preview.hide();
                $preview.find('img').attr('src', '');
                $empty.show();
                $remove.hide();
            });
        });
    </script>
    <?php
}

add_action( 'save_post_page', 'eco_header_img_save', 10, 2 );
/**
 * @param int     $post_id
 * @param WP_Post $post
 */
function eco_header_img_save( $post_id, $post ) {
    if ( ! isset( $_POST['eco_header_img_nonce'] ) || ! wp_verify_nonce( sanitize_key( $_POST['eco_header_img_nonce'] ), 'eco_header_img_save' ) ) {
        return;
    }

    if ( wp_is_post_revision( $post_id ) || wp_is_post_autosave( $post_id ) ) {
        return;
    }

    if ( ! current_user_can( 'edit_post', $post_id ) ) {
        return;
    }

    if ( (int) $post_id !== (int) get_option( 'page_on_front' ) ) {
        return;
    }

    $id = isset( $_POST['eco_header_secondary_image_id'] ) ? absint( $_POST['eco_header_secondary_image_id'] ) : 0;

    if ( ! $id || get_post_type( $id ) !== 'attachment' ) {
        delete_post_meta( $post_id, ECO_HDR_IMG_META );

        return;
    }

    update_post_meta( $post_id, ECO_HDR_IMG_META, $id );
}
