<?php
/**
 * Service areas: per-site data instead of hardcoded city lists.
 *
 * The service-area copy, the tag grid and both Leaflet maps used to carry a
 * hardcoded list of eight Florida towns and a hardcoded map centre. That was fine
 * while this theme served one site; it is not, now that ecoproplumbing.ca shares
 * it. Everything is driven from custom fields on the page set as the front page,
 * so each subsite carries its own areas and neither can break the other.
 *
 * Coordinates are geocoded once when the fields are saved and cached in post meta.
 * Nothing here calls Google on a front-end request.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

const ECO_SA_META_AREAS  = '_eco_sa_areas';
const ECO_SA_META_HUB    = '_eco_sa_hub';
const ECO_SA_META_REGION = '_eco_sa_region';
const ECO_SA_META_SUFFIX = '_eco_sa_geo_suffix';
const ECO_SA_META_INTRO  = '_eco_sa_intro';
const ECO_SA_META_CACHE  = '_eco_sa_geocache';

/**
 * The page whose custom fields hold this site's service areas.
 *
 * @return int Post ID, or 0 when the site has no static front page.
 */
function eco_sa_source_page_id() {
    return (int) get_option( 'page_on_front' );
}

/**
 * Raw field value from the front page.
 *
 * @param string $key     One of the ECO_SA_META_* constants.
 * @param string $default Returned when the field is empty.
 * @return string
 */
function eco_sa_field( $key, $default = '' ) {
    $page_id = eco_sa_source_page_id();
    if ( ! $page_id ) {
        return $default;
    }

    $value = get_post_meta( $page_id, $key, true );

    return ( is_string( $value ) && $value !== '' ) ? $value : $default;
}

/**
 * The hub town, used wherever the copy names a single place.
 *
 * @return string
 */
function eco_sa_hub() {
    $hub = eco_sa_field( ECO_SA_META_HUB );
    if ( $hub !== '' ) {
        return $hub;
    }

    // Fall back to the first listed area rather than a hardcoded town, so a site
    // that fills in only the list still gets sensible headings.
    $areas = eco_sa_areas();

    return $areas ? $areas[0]['name'] : '';
}

/**
 * The wider region, e.g. "Cambridge, Ontario". Falls back to the hub.
 *
 * @return string
 */
function eco_sa_region() {
    $region = eco_sa_field( ECO_SA_META_REGION );

    return $region !== '' ? $region : eco_sa_hub();
}

/**
 * Parse one line of the areas field.
 *
 * Accepted forms, so a town the geocoder gets wrong can be pinned by hand:
 *   Cambridge
 *   Cambridge | 43.4017 | -80.3259
 *
 * @param string $line
 * @return array|null {name, lat, lng} with lat/lng null when not given.
 */
function eco_sa_parse_line( $line ) {
    $parts = array_map( 'trim', explode( '|', $line ) );
    $name  = $parts[0] ?? '';

    if ( $name === '' ) {
        return null;
    }

    $has_coords = isset( $parts[1], $parts[2] ) && is_numeric( $parts[1] ) && is_numeric( $parts[2] );

    return array(
        'name' => $name,
        'lat'  => $has_coords ? (float) $parts[1] : null,
        'lng'  => $has_coords ? (float) $parts[2] : null,
    );
}

/**
 * This site's service areas, with coordinates resolved.
 *
 * Areas whose coordinates could not be resolved are still returned — they belong
 * in the tag list either way — but they carry null lat/lng and the map skips them.
 *
 * @return array List of {name, lat, lng}.
 */
function eco_sa_areas() {
    static $cache = null;

    if ( $cache !== null ) {
        return $cache;
    }

    $raw = eco_sa_field( ECO_SA_META_AREAS );
    if ( $raw === '' ) {
        $cache = array();

        return $cache;
    }

    $geocache = eco_sa_geocache();
    $suffix   = eco_sa_field( ECO_SA_META_SUFFIX );
    $areas    = array();

    foreach ( preg_split( '/\r\n|\r|\n/', $raw ) as $line ) {
        $area = eco_sa_parse_line( $line );
        if ( ! $area ) {
            continue;
        }

        if ( $area['lat'] === null ) {
            $key = eco_sa_cache_key( $area['name'], $suffix );
            if ( isset( $geocache[ $key ]['lat'], $geocache[ $key ]['lng'] ) ) {
                $area['lat'] = (float) $geocache[ $key ]['lat'];
                $area['lng'] = (float) $geocache[ $key ]['lng'];
            }
        }

        $areas[] = $area;
    }

    $cache = $areas;

    return $cache;
}

/**
 * Only the areas that can actually be put on a map.
 *
 * @return array
 */
function eco_sa_mappable_areas() {
    return array_values(
        array_filter(
            eco_sa_areas(),
            static function ( $a ) {
                return $a['lat'] !== null && $a['lng'] !== null;
            }
        )
    );
}

/**
 * Cache key for one geocoded town. Includes the suffix, so changing the suffix
 * re-resolves rather than reusing coordinates from the wrong country.
 *
 * @param string $name
 * @param string $suffix
 * @return string
 */
function eco_sa_cache_key( $name, $suffix ) {
    return md5( strtolower( trim( $name ) ) . '|' . strtolower( trim( $suffix ) ) );
}

/**
 * @return array
 */
function eco_sa_geocache() {
    $page_id = eco_sa_source_page_id();
    if ( ! $page_id ) {
        return array();
    }

    $cache = get_post_meta( $page_id, ECO_SA_META_CACHE, true );

    return is_array( $cache ) ? $cache : array();
}

/**
 * Geocode any listed town we do not have coordinates for, and store them.
 *
 * Runs on save only. Towns already in the cache are not looked up again, so
 * re-saving the page costs no API calls.
 *
 * @param int $page_id
 * @return array {resolved:int, failed:array} for the admin notice.
 */
function eco_sa_resolve_coordinates( $page_id ) {
    $raw = (string) get_post_meta( $page_id, ECO_SA_META_AREAS, true );
    if ( trim( $raw ) === '' ) {
        return array( 'resolved' => 0, 'failed' => array() );
    }

    $api_key = get_option( 'ticinoweb_google_api_key' );
    if ( empty( $api_key ) ) {
        return array( 'resolved' => 0, 'failed' => array( __( 'chiave API Google non configurata', 'ecoproplumbing-child-theme' ) ) );
    }

    $suffix   = (string) get_post_meta( $page_id, ECO_SA_META_SUFFIX, true );
    $existing = get_post_meta( $page_id, ECO_SA_META_CACHE, true );
    $cache    = is_array( $existing ) ? $existing : array();

    $resolved = 0;
    $failed   = array();

    foreach ( preg_split( '/\r\n|\r|\n/', $raw ) as $line ) {
        $area = eco_sa_parse_line( $line );

        // Hand-pinned coordinates need no lookup.
        if ( ! $area || $area['lat'] !== null ) {
            continue;
        }

        $key = eco_sa_cache_key( $area['name'], $suffix );
        if ( isset( $cache[ $key ] ) ) {
            continue;
        }

        $address = $suffix !== '' ? $area['name'] . ', ' . $suffix : $area['name'];
        $url     = add_query_arg(
            array(
                'address' => rawurlencode( $address ),
                'key'     => rawurlencode( $api_key ),
            ),
            'https://maps.googleapis.com/maps/api/geocode/json'
        );

        $response = wp_remote_get( $url, array( 'timeout' => 15 ) );
        if ( is_wp_error( $response ) ) {
            $failed[] = $area['name'];
            continue;
        }

        $data     = json_decode( wp_remote_retrieve_body( $response ), true );
        $location = $data['results'][0]['geometry']['location'] ?? null;

        if ( ( $data['status'] ?? '' ) !== 'OK' || ! isset( $location['lat'], $location['lng'] ) ) {
            $failed[] = $area['name'];
            continue;
        }

        $cache[ $key ] = array(
            'lat'   => (float) $location['lat'],
            'lng'   => (float) $location['lng'],
            'query' => $address,
        );
        $resolved++;
    }

    update_post_meta( $page_id, ECO_SA_META_CACHE, $cache );

    return array( 'resolved' => $resolved, 'failed' => $failed );
}

/* -------------------------------------------------------------------------
 * Admin: the fields themselves
 * ---------------------------------------------------------------------- */

add_action( 'add_meta_boxes', 'eco_sa_add_meta_box' );
function eco_sa_add_meta_box() {
    $page_id = eco_sa_source_page_id();
    if ( ! $page_id ) {
        return;
    }

    add_meta_box(
        'eco-service-areas',
        __( 'Service Areas', 'ecoproplumbing-child-theme' ),
        'eco_sa_render_meta_box',
        'page',
        'normal',
        'high'
    );
}

/**
 * @param WP_Post $post
 */
function eco_sa_render_meta_box( $post ) {
    // One page owns this data — the front page. Showing the box on every page
    // would invite editors to fill in fields that are never read.
    if ( (int) $post->ID !== eco_sa_source_page_id() ) {
        echo '<p>' . esc_html__( 'Le service areas si gestiscono sulla pagina impostata come home del sito.', 'ecoproplumbing-child-theme' ) . '</p>';

        return;
    }

    wp_nonce_field( 'eco_sa_save', 'eco_sa_nonce' );

    $areas  = (string) get_post_meta( $post->ID, ECO_SA_META_AREAS, true );
    $hub    = (string) get_post_meta( $post->ID, ECO_SA_META_HUB, true );
    $region = (string) get_post_meta( $post->ID, ECO_SA_META_REGION, true );
    $suffix = (string) get_post_meta( $post->ID, ECO_SA_META_SUFFIX, true );
    $intro  = (string) get_post_meta( $post->ID, ECO_SA_META_INTRO, true );
    $cached = count( eco_sa_geocache() );
    ?>
    <style>
        .eco-sa-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 18px; }
        .eco-sa-grid .eco-sa-full { grid-column: 1 / -1; }
        .eco-sa-grid label { display: block; font-weight: 600; margin-bottom: 4px; }
        .eco-sa-grid input[type="text"], .eco-sa-grid textarea { width: 100%; }
        .eco-sa-grid .description { margin-top: 4px; }
    </style>
    <div class="eco-sa-grid">
        <p class="eco-sa-full">
            <label for="eco_sa_areas"><?php esc_html_e( 'Località servite — una per riga', 'ecoproplumbing-child-theme' ); ?></label>
            <textarea id="eco_sa_areas" name="eco_sa_areas" rows="10" class="large-text code"><?php echo esc_textarea( $areas ); ?></textarea>
            <span class="description">
                <?php esc_html_e( 'Le coordinate vengono ricavate da Google al salvataggio e memorizzate, quindi il sito non interroga l\'API a ogni visita. Per forzare una posizione: Nome | latitudine | longitudine', 'ecoproplumbing-child-theme' ); ?>
                <?php if ( $cached ) : ?>
                    <br><em><?php printf( esc_html__( '%d località già geolocalizzate in cache.', 'ecoproplumbing-child-theme' ), (int) $cached ); ?></em>
                <?php endif; ?>
            </span>
        </p>
        <p>
            <label for="eco_sa_geo_suffix"><?php esc_html_e( 'Contesto per la geolocalizzazione', 'ecoproplumbing-child-theme' ); ?></label>
            <input type="text" id="eco_sa_geo_suffix" name="eco_sa_geo_suffix" value="<?php echo esc_attr( $suffix ); ?>" placeholder="Ontario, Canada">
            <span class="description"><?php esc_html_e( 'Aggiunto a ogni nome durante la ricerca. Senza questo, nomi come Paris, Cambridge o Waterloo finiscono nel Paese sbagliato.', 'ecoproplumbing-child-theme' ); ?></span>
        </p>
        <p>
            <label for="eco_sa_hub"><?php esc_html_e( 'Località principale', 'ecoproplumbing-child-theme' ); ?></label>
            <input type="text" id="eco_sa_hub" name="eco_sa_hub" value="<?php echo esc_attr( $hub ); ?>" placeholder="Cambridge">
            <span class="description"><?php esc_html_e( 'Usata nei titoli. Se vuota, viene usata la prima della lista.', 'ecoproplumbing-child-theme' ); ?></span>
        </p>
        <p>
            <label for="eco_sa_region"><?php esc_html_e( 'Regione', 'ecoproplumbing-child-theme' ); ?></label>
            <input type="text" id="eco_sa_region" name="eco_sa_region" value="<?php echo esc_attr( $region ); ?>" placeholder="Cambridge, Ontario">
            <span class="description"><?php esc_html_e( 'Compare nel testo introduttivo. Se vuota, viene usata la località principale.', 'ecoproplumbing-child-theme' ); ?></span>
        </p>
        <p>
            <label for="eco_sa_intro"><?php esc_html_e( 'Testo introduttivo (opzionale)', 'ecoproplumbing-child-theme' ); ?></label>
            <textarea id="eco_sa_intro" name="eco_sa_intro" rows="4" class="large-text"><?php echo esc_textarea( $intro ); ?></textarea>
            <span class="description"><?php esc_html_e( 'Se vuoto viene generato dai campi sopra. Un paragrafo per riga.', 'ecoproplumbing-child-theme' ); ?></span>
        </p>
    </div>
    <?php
}

add_action( 'save_post_page', 'eco_sa_save_meta_box', 10, 2 );
/**
 * @param int     $post_id
 * @param WP_Post $post
 */
function eco_sa_save_meta_box( $post_id, $post ) {
    if ( ! isset( $_POST['eco_sa_nonce'] ) || ! wp_verify_nonce( sanitize_key( $_POST['eco_sa_nonce'] ), 'eco_sa_save' ) ) {
        return;
    }

    if ( wp_is_post_revision( $post_id ) || wp_is_post_autosave( $post_id ) ) {
        return;
    }

    if ( ! current_user_can( 'edit_post', $post_id ) ) {
        return;
    }

    if ( (int) $post_id !== eco_sa_source_page_id() ) {
        return;
    }

    $text_fields = array(
        ECO_SA_META_HUB    => 'eco_sa_hub',
        ECO_SA_META_REGION => 'eco_sa_region',
        ECO_SA_META_SUFFIX => 'eco_sa_geo_suffix',
    );

    foreach ( $text_fields as $meta_key => $input ) {
        $value = isset( $_POST[ $input ] ) ? sanitize_text_field( wp_unslash( $_POST[ $input ] ) ) : '';
        update_post_meta( $post_id, $meta_key, $value );
    }

    $areas_value = isset( $_POST['eco_sa_areas'] ) ? sanitize_textarea_field( wp_unslash( $_POST['eco_sa_areas'] ) ) : '';
    update_post_meta( $post_id, ECO_SA_META_AREAS, $areas_value );

    // The intro keeps inline markup — the existing copy uses <strong> to pick out
    // town names — so it is filtered rather than stripped.
    $intro_value = isset( $_POST['eco_sa_intro'] ) ? wp_kses_post( wp_unslash( $_POST['eco_sa_intro'] ) ) : '';
    update_post_meta( $post_id, ECO_SA_META_INTRO, $intro_value );

    $result = eco_sa_resolve_coordinates( $post_id );

    if ( ! empty( $result['failed'] ) ) {
        set_transient(
            'eco_sa_notice_' . get_current_user_id(),
            sprintf(
                /* translators: %s: comma-separated list of place names */
                __( 'Service areas: non è stato possibile geolocalizzare %s. Controlla il nome, oppure indica le coordinate a mano con Nome | lat | lng.', 'ecoproplumbing-child-theme' ),
                implode( ', ', $result['failed'] )
            ),
            60
        );
    }
}

add_action( 'admin_notices', 'eco_sa_admin_notice' );
function eco_sa_admin_notice() {
    $key     = 'eco_sa_notice_' . get_current_user_id();
    $message = get_transient( $key );

    if ( ! $message ) {
        return;
    }

    delete_transient( $key );
    printf( '<div class="notice notice-warning is-dismissible"><p>%s</p></div>', esc_html( $message ) );
}
