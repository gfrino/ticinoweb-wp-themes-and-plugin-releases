<?php
/**
 * Ecoproplumbing Child Theme - Front Page
 */
get_header();

// 1. Get Hero Slider Data
$hero_slides = function_exists('ticinoweb_get_slider_data') ? ticinoweb_get_slider_data() : array();
?>

<main id="content" class="site-content">

    <!-- HERO SECTION -->
    <?php $hero_video = ecoproplumbing_get_hero_video(); ?>
    <section id="hero" class="hero-section<?php echo !empty($hero_video) ? ' hero-section--video' : ''; ?>">

        <?php if (!empty($hero_video)): ?>
            <?php // The source is attached by JS after the load event, so several megabytes of
                  // video never compete with above-the-fold rendering. A brand gradient on the
                  // section stands in until the first frame is decodable, then the video fades
                  // over it. The old poster pointed at a file that does not exist (404), so it
                  // is gone: the gradient is the placeholder now. ?>
            <video id="hero-bg-video" class="hero-bg-video" autoplay loop muted playsinline
                preload="none" data-src="<?php echo esc_url($hero_video); ?>"></video>

            <noscript>
                <video class="hero-bg-video is-ready" autoplay loop muted playsinline preload="metadata">
                    <source src="<?php echo esc_url($hero_video); ?>" type="video/mp4">
                </video>
            </noscript>

            <?php // Despite the name this is not a readability overlay: it is transparent during
                  // playback and fades in only over the last moment, to hide the loop seam. ?>
            <div id="hero-video-fade"></div>

            <script>
                (function () {
                    var video = document.getElementById('hero-bg-video');
                    if (!video) { return; }

                    var fader = document.getElementById('hero-video-fade');

                    video.addEventListener('canplay', function () {
                        video.classList.add('is-ready');
                    }, { once: true });

                    if (fader) {
                        video.addEventListener('timeupdate', function () {
                            var remaining = video.duration - video.currentTime;
                            fader.style.opacity = (remaining > 0 && remaining <= 0.8) ? '1' : '0';
                        });
                    }

                    function startVideo() {
                        var src = video.getAttribute('data-src');
                        if (!src) { return; }

                        video.src = src;

                        var playing = video.play();
                        if (playing && typeof playing.catch === 'function') {
                            // Autoplay can still be refused; the gradient simply stays put.
                            playing.catch(function () {});
                        }
                    }

                    if (document.readyState === 'complete') {
                        startVideo();
                    } else {
                        window.addEventListener('load', startVideo, { once: true });
                    }
                })();
            </script>
        <?php endif; ?>

        <?php
        // Without a video the slider is still what carries the background imagery, so it stays.
        // With one, its only visible job was rotating the slogan panel that has now been removed
        // — empty rotating slides would just leave pagination dots that change nothing on screen.
        // With neither, the section's gradient is the background.
        $hero_slides = array_values(array_filter($hero_slides, function ($slide) {
            return !empty($slide['image']);
        }));
        ?>
        <?php if (empty($hero_video) && !empty($hero_slides)): ?>
            <div class="swiper eco-hero-slider">
                <div class="swiper-wrapper">
                    <?php foreach ($hero_slides as $slide):
                        $image = isset($slide['image']) ? $slide['image'] : '';
                        ?>
                        <div class="swiper-slide hero-slide"
                            style="background-image: url('<?php echo esc_url($image); ?>'); background-size: cover; background-position: center;"></div>
                    <?php endforeach; ?>
                </div>

                <div class="swiper-pagination"></div>
            </div>
        <?php endif; ?>

        <?php // Single call to action, in place of the rotating slogan panel. The wrapper keeps
              // the 'hero-actions' class because template-parts/modal-booking.php looks for
              // '.hero-actions .btn' to wire this button to the booking modal; the href is the
              // no-JS fallback. ?>
        <div class="hero-actions hero-cta">
            <a href="#contatti" class="btn btn-primary btn-lg">Get a free estimate</a>
        </div>

    </section>

    <!-- DYNAMIC GOOGLE REVIEWS -->
    <section id="google-reviews" class="section-reviews py-5">
        <div class="container eco-container-1300">
            <div class="reviews-main-box">
                <!-- Titles Removed -->

                <div class="row g-4 align-items-stretch pb-5">
                    <?php
                    $reviews = function_exists('ticinoweb_get_google_reviews') ? ticinoweb_get_google_reviews() : array();
                    $count = 0;
                    if (!empty($reviews)):
                        foreach ($reviews as $review):
                            // Only show 4 and 5 star reviews, limit to 4 cards total
                            if (isset($review['rating']) && $review['rating'] >= 4 && $count < 4):
                                $count++;
                                ?>
                                <div class="col-md-6 col-lg-3">
                                    <div class="review-card glass-panel h-100" style="position: relative;">
                                        <div class="review-header d-flex flex-column justify-content-center mb-3">

                                            <!-- Google Logo Absolutely Positioned -->
                                            <div class="google-icon-wrapper shadow-sm"
                                                style="position: absolute; top: 15px; right: 15px; background: white; border-radius: 50%; padding: 5px; display:flex; align-items:center; justify-content:center; z-index: 5;">
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48" width="22px"
                                                    height="22px">
                                                    <path fill="#FFC107"
                                                        d="M43.611,20.083H42V20H24v8h11.303c-1.649,4.657-6.08,8-11.303,8c-6.627,0-12-5.373-12-12c0-6.627,5.373-12,12-12c3.059,0,5.842,1.154,7.961,3.039l5.657-5.657C34.046,6.053,29.268,4,24,4C12.955,4,4,12.955,4,24c0,11.045,8.955,20,20,20c11.045,0,20-8.955,20-20C44,22.659,43.862,21.35,43.611,20.083z" />
                                                    <path fill="#FF3D00"
                                                        d="M6.306,14.691l6.571,4.819C14.655,15.108,18.961,12,24,12c3.059,0,5.842,1.154,7.961,3.039l5.657-5.657C34.046,6.053,29.268,4,24,4C16.318,4,9.656,8.337,6.306,14.691z" />
                                                    <path fill="#4CAF50"
                                                        d="M24,44c5.166,0,9.86-1.977,13.409-5.192l-6.19-5.238C29.211,35.091,26.715,36,24,36c-5.202,0-9.619-3.317-11.283-7.946l-6.522,5.025C9.505,39.556,16.227,44,24,44z" />
                                                    <path fill="#1976D2"
                                                        d="M43.611,20.083H42V20H24v8h11.303c-0.792,2.237-2.231,4.166-4.087,5.571c0.001-0.001,0.002-0.001,0.003-0.002l6.19,5.238C36.971,39.205,44,34,44,24C44,22.659,43.862,21.35,43.611,20.083z" />
                                                </svg>
                                            </div>

                                            <div class="d-flex align-items-center mb-1">
                                                <div class="reviewer-img-wrapper flex-shrink-0" style="margin-right: 15px;">
                                                    <!-- Increased gap -->
                                                    <?php
                                                        $initials_url = 'https://ui-avatars.com/api/?name=' . urlencode($review['author_name']) . '&background=0096C7&color=fff&size=100';
                                                    ?>
                                                    <img src="<?php echo esc_url($review['profile_photo_url']); ?>"
                                                        alt="<?php echo esc_attr($review['author_name']); ?>"
                                                        class="reviewer-img rounded-circle"
                                                        loading="lazy" decoding="async"
                                                        style="width: 50px; height: 50px; border: 2px solid #fff; box-shadow: 0 4px 10px rgba(0,0,0,0.1);"
                                                        onerror="this.onerror=null;this.src='<?php echo esc_js($initials_url); ?>';">
                                                </div>
                                                <div class="reviewer-info flex-grow-1" style="min-width: 0; padding-right: 30px;">
                                                    <h5 class="mb-0 fw-bold text-truncate"
                                                        style="font-size: 0.88rem; color: #1a1e29; line-height: 1.2;">
                                                        <?php echo esc_html($review['author_name']); ?>
                                                    </h5>
                                                </div>
                                            </div>

                                            <!-- Stars below name/image -->
                                            <div class="stars w-100 mt-2" style="color: #FBBC05; padding-left: 2px;">
                                                <?php for ($i = 1; $i <= 5; $i++): ?>
                                                    <i class="fas fa-star<?php echo ($i <= $review['rating']) ? '' : ' text-muted opacity-50'; ?>"
                                                        style="font-size: 0.95rem; margin-right: 2px;"></i>
                                                <?php endfor; ?>
                                            </div>
                                        </div>
                                        <div class="review-body" style="font-size: 0.95rem; font-style: italic; margin-top: 10px;">
                                            <p class="review-text text-muted mb-0">"<?php echo esc_html($review['text']); ?>"</p>
                                        </div>
                                    </div>
                                </div>
                                <?php
                            endif;
                        endforeach;
                    else:
                        ?>
                        <div class="col-12 text-center">
                            <p class="text-muted">No reviews found.</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>

    <!-- CHI SIAMO -->
    <?php
    $chi_siamo_text = get_option('ticinoweb_chi_siamo_text', '');
    $chi_siamo_image = get_option('ticinoweb_chi_siamo_image', '');
    $chi_siamo_link = get_option('ticinoweb_chi_siamo_link', '');
    ?>
    <section id="chi-siamo" class="section-about py-5">
        <div class="container eco-container-1300">
            <div class="about-main-box">
                <div class="row align-items-center">
                    <div class="col-md-6 mb-4 mb-md-0">
                        <div class="about-text-content">
                            <h4 class="text-primary text-uppercase mb-1">About Us</h4>
                            <h2 class="section-heading mb-3">Our Company</h2>
                            <div class="section-text text-muted">
                                <?php
                                if ($chi_siamo_text) {
                                    echo wpautop($chi_siamo_text);
                                } else {
                                    echo '<p>We specialize in innovative plumbing solutions, focusing on energy efficiency and environmental respect.</p>';
                                }
                                ?>
                            </div>
                            <?php if ($chi_siamo_link): ?>
                                <a href="<?php echo esc_url($chi_siamo_link); ?>" class="btn btn-outline-primary mt-3">Learn
                                    More</a>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="about-image-wrapper">
                            <?php if ($chi_siamo_image): ?>
                                <img src="<?php echo esc_url($chi_siamo_image); ?>" alt="About Us"
                                    class="img-fluid rounded shadow-sm" loading="lazy" decoding="async">
                            <?php else: ?>
                                <div class="bg-light d-flex align-items-center justify-content-center rounded"
                                    style="height: 400px; border: 2px dashed #ddd;">
                                    <p class="text-muted">About Us image not set</p>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>



    <!-- SERVICE AREAS SECTION -->
    <?php
    // No areas configured for this site: render nothing rather than an empty map
    // and a heading with a blank town in it.
    $eco_areas    = eco_sa_areas();
    $eco_map_pins = eco_sa_mappable_areas();
    ?>
    <?php if ( $eco_areas ) : ?>
    <section id="service-areas" class="section-service-areas pt-5">
        <div class="container eco-container-1300">
            <div class="about-main-box">
                <div class="service-areas-row">
                    <div class="mb-4 mb-md-0">
                        <div id="serviceAreasMap" class="service-areas-map"></div>
                    </div>
                    <div>
                        <?php
                        $eco_hub    = eco_sa_hub();
                        $eco_region = eco_sa_region();
                        $eco_names  = wp_list_pluck( $eco_areas, 'name' );

                        // Split into two columns, the taller one first so an odd count
                        // leaves the ragged edge on the right.
                        $eco_split   = (int) ceil( count( $eco_names ) / 2 );
                        $eco_columns = array( array_slice( $eco_names, 0, $eco_split ), array_slice( $eco_names, $eco_split ) );

                        $eco_intro = trim( (string) eco_sa_field( ECO_SA_META_INTRO ) );
                        ?>
                        <h4 class="text-primary text-uppercase mb-1" style="font-weight: 600; letter-spacing: 1px;">
                            Service Areas</h4>
                        <h2 class="section-heading mb-3">
                            <?php
                            printf(
                                /* translators: %s: main town served */
                                esc_html__( 'Proudly Serving %s &amp; Surrounding Communities', 'ecoproplumbing-child-theme' ),
                                esc_html( $eco_hub )
                            );
                            ?>
                        </h2>
                        <div class="section-text text-muted">
                            <?php if ( $eco_intro !== '' ) : ?>
                                <?php foreach ( preg_split( '/\r\n|\r|\n/', $eco_intro ) as $eco_paragraph ) : ?>
                                    <?php if ( trim( $eco_paragraph ) !== '' ) : ?>
                                        <p><?php echo wp_kses_post( trim( $eco_paragraph ) ); ?></p>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            <?php else : ?>
                                <p><?php printf(
                                    esc_html__( 'Eco Pro Plumbing is the trusted name in plumbing throughout the greater %1$s area. Our certified technicians serve homeowners and businesses across %2$s communities — delivering fast, reliable, and eco-friendly plumbing solutions right to your door.', 'ecoproplumbing-child-theme' ),
                                    esc_html( $eco_region ),
                                    '<strong>' . esc_html( number_format_i18n( count( $eco_names ) ) ) . '</strong>'
                                ); ?></p>
                                <?php
                                // Name a handful rather than the whole list; the tag grid
                                // right below already carries every town.
                                $eco_featured = array_slice( $eco_names, 0, 4 );
                                if ( $eco_featured ) :
                                    $eco_featured_markup = array_map(
                                        static function ( $n ) {
                                            return '<strong>' . esc_html( $n ) . '</strong>';
                                        },
                                        $eco_featured
                                    );
                                    ?>
                                    <p><?php printf(
                                        esc_html__( 'Whether you\'re in %s — we guarantee %s across all service zones.', 'ecoproplumbing-child-theme' ),
                                        wp_kses_post( implode( ', ', $eco_featured_markup ) ),
                                        '<strong>' . esc_html__( '30-minute response times', 'ecoproplumbing-child-theme' ) . '</strong>'
                                    ); ?></p>
                                <?php endif; ?>
                            <?php endif; ?>
                        </div>
                        <div class="service-areas-tags-container mt-4">
                            <div class="areas-tags-grid">
                                <?php foreach ( $eco_columns as $eco_column ) : ?>
                                    <div class="areas-column">
                                        <?php foreach ( $eco_column as $eco_name ) : ?>
                                            <span class="area-tag"><i class="fas fa-map-marker-alt"></i><?php echo esc_html( $eco_name ); ?></span>
                                        <?php endforeach; ?>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            // Bail out rather than throw if Leaflet is absent or the container is
            // missing, so a failed CDN request cannot take the rest of the page down.
            if (typeof L === 'undefined' || !document.getElementById('serviceAreasMap')) {
                return;
            }

            var cities = <?php echo wp_json_encode( $eco_map_pins ); ?>;

            if (!cities.length) {
                return;
            }

            // Provisional centre = mean of the pins. fitBounds below supersedes it;
            // this only stops the map flashing a hardcoded location first.
            var meanLat = cities.reduce(function (t, c) { return t + c.lat; }, 0) / cities.length;
            var meanLng = cities.reduce(function (t, c) { return t + c.lng; }, 0) / cities.length;

            var map = L.map('serviceAreasMap', {
                scrollWheelZoom: false
            }).setView([meanLat, meanLng], 13);

            L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Street_Map/MapServer/tile/{z}/{y}/{x}', {
                attribution: '© Esri',
                maxZoom: 18
            }).addTo(map);

            // Custom Liquid Glass Marker Icon
            var liquidIcon = L.divIcon({
                className: 'custom-div-icon',
                html: "<div class='water-drop-marker'></div>",
                iconSize: [30, 30],
                iconAnchor: [15, 30],
                popupAnchor: [0, -32]
            });

            // Perimeter = convex hull of the pins (monotone chain), NOT the pins in
            // list order. The old hardcoded array happened to be ordered so that
            // joining it produced a sensible ring; an editable list in any order
            // would otherwise draw a self-intersecting star.
            function convexHull(points) {
                if (points.length < 3) {
                    return points.map(function (p) { return [p.lat, p.lng]; });
                }

                var pts = points.map(function (p) { return [p.lng, p.lat]; }).sort(function (a, b) {
                    return a[0] - b[0] || a[1] - b[1];
                });

                var cross = function (o, a, b) {
                    return (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0]);
                };

                var build = function (sorted) {
                    var stack = [];
                    sorted.forEach(function (p) {
                        while (stack.length >= 2 && cross(stack[stack.length - 2], stack[stack.length - 1], p) <= 0) {
                            stack.pop();
                        }
                        stack.push(p);
                    });
                    return stack;
                };

                var lower = build(pts);
                var upper = build(pts.slice().reverse());

                // Drop each run's last point: it is the other run's first.
                return lower.slice(0, -1).concat(upper.slice(0, -1)).map(function (p) { return [p[1], p[0]]; });
            }

            var latlngs = convexHull(cities);
            var perimeter = L.polygon(latlngs, {
                color: '#0077b6',
                weight: 3,
                opacity: 0, // Start invisible to prevent FOUC (flash of solid line)
                fillColor: '#0096c7',
                fillOpacity: 0, // Start invisible
                className: 'animated-service-perimeter' // Class for CSS animation
            }).addTo(map);

            // Function to update path length for animation
            function updatePathLength() {
                // Fix map size if container resized
                map.invalidateSize();

                var path = document.querySelector('.animated-service-perimeter');
                if (path) {
                    var len = path.getTotalLength();
                    // Generate dashed drawing pattern
                    var dashSize = 12;
                    var gapSize = 8;
                    var patternLength = 0;
                    var dashArray = [];

                    // Fill the length with dashes
                    while (patternLength < len) {
                        dashArray.push(dashSize);
                        dashArray.push(gapSize);
                        patternLength += (dashSize + gapSize);
                    }

                    // Add a huge gap at the end to hide the line initially via offset
                    // The gap must be at least the length of the path
                    var hugeGap = len * 2;
                    dashArray.push(hugeGap);

                    // Apply to style
                    path.style.strokeDasharray = dashArray.join(' ');

                    // Set CSS variable for the offset animation
                    // We want to start with offset = patternLength (dashes hidden, showing gap)
                    // And animate to offset = 0 (dashes visible)
                    path.style.setProperty('--draw-offset', patternLength);

                    // Reveal the path now that it is ready
                    path.classList.add('is-ready');
                }
            }

            // Update on load (with delay for render) and on zoom
            // Increased delay to ensure map is ready
            setTimeout(updatePathLength, 800);
            setTimeout(updatePathLength, 2000); // Fail-safe
            map.on('zoomend', updatePathLength);
            map.on('moveend', updatePathLength);

            cities.forEach(function (city) {
                L.marker([city.lat, city.lng], { icon: liquidIcon })
                    .addTo(map)
                    .bindPopup('<strong>' + city.name + '</strong><br>Eco Pro Service Area');
            });

            // Fit map to show all markers
            var group = L.featureGroup(cities.map(function (c) {
                return L.marker([c.lat, c.lng]);
            }));
            map.fitBounds(group.getBounds().pad(0.15));
        });
    </script>
    <?php endif; ?>

    <!-- SERVIZI (Placeholder) -->
    <section id="servizi" class="section-services py-5">
        <div class="container eco-container-1300">
            <div class="services-main-box">
                <div class="text-center mb-5">
                    <h4 class="text-primary text-uppercase">What We Do</h4>
                    <h2 class="section-heading text-dark">Our Services</h2>
                </div>
                <div class="row">
                    <?php
                    $services = get_option('ticinoweb_services', array());

                    // Unique icon mapping per service title
                    $icon_map = array(
                        'Plumbing' => 'fas fa-wrench',
                        'Sewer and Drain Cleaning' => 'fas fa-shower',
                        'Well Pump' => 'fas fa-droplet',
                        'Heating and AC' => 'fas fa-temperature-arrow-up',
                        'Water Filter and Softener' => 'fas fa-filter',
                        'Remodeling Services' => 'fas fa-paint-roller',
                        'Septic System' => 'fas fa-gears',
                        'Gas Line' => 'fas fa-fire-flame-simple',
                        'Water Heater' => 'fas fa-fire-burner',
                        'Emergency Plumbing' => 'fas fa-truck-medical',
                        'Pipe Installation' => 'fas fa-faucet-drip',
                    );

                    // Fallback icons for unmapped services
                    $fallback_icons = array(
                        'fas fa-water',
                        'fas fa-toolbox',
                        'fas fa-screwdriver-wrench',
                        'fas fa-house-chimney',
                        'fas fa-bolt',
                        'fas fa-plug',
                    );
                    $fallback_idx = 0;

                    if (!empty($services) && is_array($services)):
                        foreach ($services as $service):
                            $title = isset($service['title']) ? $service['title'] : '';
                            $desc = isset($service['description']) ? $service['description'] : '';

                            // Pick icon: mapped > fallback > default
                            if (isset($icon_map[$title])) {
                                $icon_class = $icon_map[$title];
                            } else {
                                $icon_class = $fallback_icons[$fallback_idx % count($fallback_icons)];
                                $fallback_idx++;
                            }
                            $icon_html = '<i class="' . esc_attr($icon_class) . '"></i>';

                            // Skip empty services
                            if (!$title)
                                continue;
                            ?>
                            <div class="col-md-4 mb-4">
                                <div class="service-card">
                                    <div class="service-icon-wrapper mb-3">
                                        <?php echo $icon_html; ?>
                                    </div>
                                    <h3 class="service-title h5 mb-2"><?php echo esc_html($title); ?></h3>
                                    <p class="service-desc text-muted mb-0"><?php echo esc_html($desc); ?></p>
                                </div>
                            </div>
                        <?php endforeach;
                    else: ?>
                        <div class="col-12 text-center">
                            <p class="text-white">No services configured yet.</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>

    <!-- 24/7 EMERGENCY PLUMBING -->
    <section id="emergency" class="section-emergency py-5">
        <div class="emergency-box">
            <!-- Top Row: Text and Features -->
            <div class="row align-items-stretch mb-5">
                <!-- Left Column: Text Content -->
                <div class="col-lg-6 mb-5 mb-lg-0">
                    <span class="emergency-badge"><i class="fas fa-phone-alt"></i> Available Now</span>
                    <h2 class="emergency-title">
                        <span class="emergency-accent">24/7</span>
                        Emergency Plumbing Service
                    </h2>
                    <p class="emergency-desc">
                        Burst pipes, flooding, or gas leaks don't wait — and neither do we. Our certified emergency
                        plumbing team is on standby around the clock, ready to respond within <strong>30
                            minutes</strong> anywhere in the area. No hidden fees, no surprises — just fast,
                        reliable service when you need it most.
                    </p>

                    <div class="emergency-stats">
                        <div class="stat-item">
                            <span class="stat-number">30</span>
                            <span class="stat-label">Min Response</span>
                        </div>
                        <div class="stat-item">
                            <span class="stat-number">24/7</span>
                            <span class="stat-label">Availability</span>
                        </div>
                        <div class="stat-item">
                            <span class="stat-number">100%</span>
                            <span class="stat-label">Satisfaction</span>
                        </div>
                    </div>

                    <a href="tel:<?php echo esc_attr(get_option('ticinoweb_contact_phone')); ?>"
                        class="btn btn-primary btn-lg emergency-cta">
                        <i class="fas fa-phone-alt" style="margin-right: 12px;"></i> Call Emergency Now
                    </a>
                </div>

                <!-- Right Column: Features -->
                <div class="col-lg-6">
                    <div class="emergency-features">
                        <div class="emergency-feature-card">
                            <div class="feature-icon-circle"><i class="fas fa-bolt"></i></div>
                            <div class="feature-info">
                                <h4>Lightning-Fast Response</h4>
                                <p>Our dispatch team ensures a certified plumber is at your door within 30
                                    minutes.</p>
                            </div>
                        </div>
                        <div class="emergency-feature-card">
                            <div class="feature-icon-circle"><i class="fas fa-shield-halved"></i></div>
                            <div class="feature-info">
                                <h4>Licensed & Insured Team</h4>
                                <p>Every technician is fully licensed, insured and background-checked.</p>
                            </div>
                        </div>
                        <div class="emergency-feature-card">
                            <div class="feature-icon-circle"><i class="fas fa-hand-holding-dollar"></i>
                            </div>
                            <div class="feature-info">
                                <h4>Transparent Pricing</h4>
                                <p>You'll receive a clear, upfront quote before any work begins.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Bottom Row: Gallery Carousel -->
            <div class="row">
                <div class="col-12">
                    <?php
                    // Fetch 'gallery home' images
                    $gallery_term = get_term_by('name', 'gallery home', 'ticinoweb_media_gallery');
                    $gallery_images = array();

                    if ($gallery_term && !is_wp_error($gallery_term)) {
                        $gallery_images = get_posts(array(
                            'post_type' => 'attachment',
                            'post_status' => 'inherit',
                            'posts_per_page' => -1,
                            'tax_query' => array(
                                array(
                                    'taxonomy' => 'ticinoweb_media_gallery',
                                    'field' => 'term_id',
                                    'terms' => $gallery_term->term_id,
                                ),
                            ),
                            'orderby' => 'menu_order',
                            'order' => 'ASC',
                        ));
                    }
                    ?>

                    <div class="emergency-gallery-wrapper">
                        <?php if (!empty($gallery_images)): ?>
                            <div class="swiper emergencySwiper">
                                <div class="swiper-wrapper">
                                    <?php foreach ($gallery_images as $image):
                                        $img_url_full = wp_get_attachment_image_url($image->ID, 'large');
                                        $img_alt = get_post_meta($image->ID, '_wp_attachment_image_alt', true);
                                        ?>
                                        <div class="swiper-slide">
                                            <div class="gallery-slide-inner"
                                                style="background-image: url('<?php echo esc_url($img_url_full); ?>');">
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                                <div class="swiper-pagination"></div>
                            </div>
                        <?php else: ?>
                            <!-- Placeholder if empty -->
                            <div class="d-flex align-items-center justify-content-center h-100 text-white-50">
                                <p>No images in 'gallery home'</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
        </div>
    </section>

    <!-- CONTACTS SECTION -->
    <?php
    $contact_phone = get_option('ticinoweb_contact_phone', '');
    $contact_email = get_option('ticinoweb_contact_email', '');
    $contact_address = get_option('ticinoweb_contact_address', '');
    ?>
    <section id="contatti" class="section-contacts py-5">
        <div class="container eco-container-1300">
            <div class="contact-boxed-wrapper">
                <h2 class="section-heading text-center mb-5">Contact Us</h2>
                <div class="contact-row">

                    <!-- Phone -->
                    <?php if ($contact_phone): ?>
                        <div class="contact-card" id="card-phone">
                            <div class="card-inner">
                                <i class="fas fa-phone"></i>
                                <h4>Phone</h4>
                                <p>
                                    <a href="tel:<?php echo esc_attr(str_replace(' ', '', $contact_phone)); ?>">
                                        <?php echo esc_html($contact_phone); ?>
                                    </a>
                                </p>
                            </div>
                        </div>
                    <?php endif; ?>

                    <!-- Email -->
                    <?php if ($contact_email): ?>
                        <div class="contact-card" id="card-email">
                            <div class="card-inner">
                                <i class="fas fa-envelope"></i>
                                <h4>Email</h4>
                                <p>
                                    <a href="mailto:<?php echo esc_attr($contact_email); ?>">
                                        <?php echo esc_html($contact_email); ?>
                                    </a>
                                </p>
                            </div>
                        </div>
                    <?php endif; ?>

                    <!-- Address -->
                    <?php if ($contact_address): ?>
                        <div class="contact-card" id="card-address">
                            <div class="card-inner">
                                <i class="fas fa-location-dot"></i>
                                <h4>Address</h4>
                                <p><?php echo wp_kses_post($contact_address); ?></p>
                            </div>
                        </div>
                    <?php endif; ?>

                </div>
            </div>
    </section>


</main>

<script>
    document.addEventListener('DOMContentLoaded', function () {
        var heroSwiper = null;

        // Init Swiper. The hero slider is only rendered when there is no background
        // video, so check the element is actually on the page before initialising it.
        if (typeof Swiper !== 'undefined' && document.querySelector('.eco-hero-slider')) {
            heroSwiper = new Swiper('.eco-hero-slider', {
                loop: true,
                autoplay: {
                    delay: 5000,
                    disableOnInteraction: false
                },
                speed: 1000,
                pagination: {
                    el: '.swiper-pagination',
                    clickable: true,
                },
            });
        }

        // Google Reviews are now a static grid. No Swiper required here.

        if (typeof Swiper !== 'undefined' && document.querySelector('.emergencySwiper')) {
            var emergencySwiper = new Swiper(".emergencySwiper", {
                loop: true,
                effect: "slide",
                speed: 1000,
                autoplay: {
                    delay: 4000,
                    disableOnInteraction: false,
                    pauseOnMouseEnter: true
                },
                pagination: {
                    el: ".swiper-pagination",
                    clickable: true,
                },
            });
        }

        // Animation Logic
        const waterWave = document.getElementById('water-wave-overlay');
        const plumberComposition = document.getElementById('plumber-composition');

        if (waterWave && plumberComposition) {
            // Loop settings
            const slideInterval = 6000; // 6 seconds per slide
            const waveDuration = 1500; // Time for wave to fill screen

            function startAnimationLoop() {
                // 1. Start Pumping (Visual only, CSS handles it)
                plumberComposition.classList.add('pumping-active');

                // 2. Trigger Wave after delay
                setTimeout(() => {
                    waterWave.classList.add('wave-filling');

                    // 3. Change Slide when screen full
                    setTimeout(() => {
                        if (heroSwiper) heroSwiper.slideNext();

                        // 4. Reset Wave (it recedes or fades out)
                        // Wait a bit for slide transition to start invisible behind wave
                        setTimeout(() => {
                            waterWave.classList.remove('wave-filling');
                            waterWave.classList.add('wave-receding');

                            // Clean up receding class
                            setTimeout(() => {
                                waterWave.classList.remove('wave-receding');
                            }, 1000);

                        }, 500);

                    }, waveDuration);

                }, slideInterval - waveDuration);
            }

            // Start loop
            setInterval(startAnimationLoop, slideInterval);
            startAnimationLoop(); // Start first cycle
        }
    });
</script>

<?php get_footer(); ?>