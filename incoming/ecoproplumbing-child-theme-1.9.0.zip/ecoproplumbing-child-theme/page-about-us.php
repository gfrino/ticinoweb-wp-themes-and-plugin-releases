<?php
/**
 * Template Name: About Us
 *
 * The template for displaying the About Us page.
 *
 * @package EcoProPlumbing
 */

get_header(); ?>

<main id="primary" class="site-main about-us-page">

    <!-- HERO SECTION -->
    <section class="about-hero">
        <div class="about-hero-overlay"></div>
        <!-- Animated Waves Container -->
        <div class="ocean">
            <div class="wave"></div>
            <div class="wave"></div>
            <div class="wave"></div>
            <div class="wave"></div>
        </div>
        <div class="container about-hero-content position-relative z-1">
            <h1 class="about-title entry-title"><?php the_title(); ?></h1>
            <p class="about-subtitle"><?php printf(
                /* translators: %s: main town served, from the home page's service-area fields */
                esc_html__( 'Your Trusted Plumbing Partner in %s & Beyond', 'ecoproplumbing-child-theme' ),
                esc_html( eco_sa_hub() )
            ); ?></p>
        </div>
    </section>

    <!-- INTRO / STORY SECTION -->
    <section class="section-about py-5">
        <div class="container">
            <div class="about-main-box">
                <div class="row align-items-center">
                    <!-- Text Column (Left) -->
                    <div class="col-md-6 mb-4 mb-md-0">
                        <div class="about-text-content">
                            <h4 class="text-primary text-uppercase mb-1">Who We Are</h4>
                            <h2 class="section-heading mb-3">Dedicated to Excellence</h2>
                            <div class="section-text text-muted">
                                <?php
                                // Dynamic Text Logic
                                $intro_text = get_option('ticinoweb_chi_siamo_text');
                                if (!empty($intro_text)) {
                                    echo wpautop(wp_kses_post($intro_text));
                                } elseif (have_posts()) {
                                    while (have_posts()) {
                                        the_post();
                                        the_content();
                                    }
                                } else {
                                    echo "<p>Eco Pro Plumbing has been serving the community with top-tier plumbing solutions. We believe in transparency, quality, and speed.</p>";
                                }
                                ?>
                            </div>
                            <a href="<?php echo home_url('/contact'); ?>" class="btn btn-primary mt-3">Contact Us
                                Today</a>
                        </div>
                    </div>

                    <!-- Image Column (Right) -->
                    <div class="col-md-6">
                        <div class="about-image-wrapper">
                            <?php
                            // Dynamic Image Logic
                            $intro_image = get_option('ticinoweb_chi_siamo_image');
                            if (empty($intro_image)) {
                                if (has_post_thumbnail()) {
                                    $intro_image = get_the_post_thumbnail_url(get_the_ID(), 'large');
                                } else {
                                    $intro_image = get_stylesheet_directory_uri() . '/images/about-placeholder.jpg';
                                }
                            }
                            ?>
                            <img src="<?php echo esc_url($intro_image); ?>" alt="About Eco Pro"
                                class="img-fluid rounded shadow-sm">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- CORE VALUES SECTION -->
    <section class="section-padding about-values about-values-banner text-white"
        style="background-color: var(--eco-primary);">
        <div class="container">
            <div class="about-main-box" style="margin: 0 auto;">
                <div class="row mb-5">
                    <div class="col-12 text-start">
                        <h4 class="sub-heading">Our Values</h4>
                        <h2 class="section-heading">Built on Trust & Integrity</h2>
                        <p style="max-width: 800px;">We don't just fix pipes; we build relationships. Our core values
                            drive everything we do.</p>
                    </div>
                </div>

                <!-- Cards Row with Extensive Gap -->
                <div class="row row-extensive-gap">

                    <!-- Card 1: Integrity -->
                    <div class="col-md-4 d-flex">
                        <div class="values-card w-100">
                            <div class="values-card-inner">
                                <div class="feature-icon-circle"><i class="fas fa-user-shield"></i></div>
                                <div class="feature-info text-start">
                                    <h4>Integrity</h4>
                                    <p>We assume full responsibility for our work and always offer honest, transparent
                                        advice.</p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Card 2: Quality -->
                    <div class="col-md-4 d-flex">
                        <div class="values-card w-100">
                            <div class="values-card-inner">
                                <div class="feature-icon-circle"><i class="fas fa-tools"></i></div>
                                <div class="feature-info text-start">
                                    <h4>Quality</h4>
                                    <p>We use only the best materials and latest techniques to ensure long-lasting
                                        repairs.</p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Card 3: Reliability -->
                    <div class="col-md-4 d-flex">
                        <div class="values-card w-100">
                            <div class="values-card-inner">
                                <div class="feature-icon-circle"><i class="fas fa-clock"></i></div>
                                <div class="feature-info text-start">
                                    <h4>Reliability</h4>
                                    <p>When you have a plumbing emergency, you can count on us to be there on time,
                                        every time.</p>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </section>

    <!-- STATS SECTION -->
    <section class="section-padding about-stats">
        <div class="container">
            <div class="about-main-box" style="margin: 0 auto;">
                <div class="row row-extensive-gap gy-4 justify-content-center">
                    <div class="col-md-3 col-6 d-flex">
                        <div class="stats-card w-100">
                            <div class="water-drops">
                                <span></span><span></span><span></span>
                            </div>
                            <h2 class="display-4">15+</h2>
                            <p>Years in Business</p>
                        </div>
                    </div>
                    <div class="col-md-3 col-6 d-flex">
                        <div class="stats-card w-100">
                            <div class="water-drops">
                                <span></span><span></span><span></span>
                            </div>
                            <h2 class="display-4">500+</h2>
                            <p>Projects Completed</p>
                        </div>
                    </div>
                    <div class="col-md-3 col-6 d-flex">
                        <div class="stats-card w-100">
                            <div class="water-drops">
                                <span></span><span></span><span></span>
                            </div>
                            <h2 class="display-4">24/7</h2>
                            <p>Emergency Service</p>
                        </div>
                    </div>
                    <div class="col-md-3 col-6 d-flex">
                        <div class="stats-card w-100">
                            <div class="water-drops">
                                <span></span><span></span><span></span>
                            </div>
                            <h2 class="display-4">100%</h2>
                            <p>Satisfaction</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- CTA SECTION -->
    <section class="section-padding about-cta text-start">
        <div class="container">
            <div class="about-main-box" style="margin: 0 auto;">
                <h2 class="mb-4">Ready to Experience the Eco Pro Difference?</h2>
                <p class="lead text-muted mb-4">Don't let plumbing issues disrupt your day. Call the experts who care.
                </p>
                <div class="d-flex justify-content-start gap-4">
                    <a href="tel:<?php echo get_option('ticinoweb_contact_phone'); ?>"
                        class="btn btn-primary btn-lg mr-3">
                        <i class="fas fa-phone-alt mr-2"></i> Call Now
                    </a>
                    <a href="<?php echo home_url('/book-online'); ?>" class="btn btn-outline-primary btn-lg">Book
                        Online</a>
                </div>
            </div>
        </div>
    </section>

</main>

<?php get_footer(); ?>