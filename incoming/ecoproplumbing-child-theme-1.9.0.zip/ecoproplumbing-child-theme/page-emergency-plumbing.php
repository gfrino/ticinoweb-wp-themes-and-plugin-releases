<?php
/**
 * Template Name: Emergency Plumbing
 *
 * The template for displaying the Emergency Plumbing page.
 *
 * @package EcoProPlumbing
 */

get_header(); ?>

<main id="primary" class="site-main emergency-plumbing-page">

    <!-- HERO SECTION -->
    <section class="about-hero">
        <div class="about-hero-overlay"></div>
        <!-- Animated Waves Container -->
        <div class="ocean">
            <div class="wave"></div>
            <div class="wave"></div>
            <div class="wave"></div>
            <div class="wave"></div>
        </div>
        <div class="container about-hero-content position-relative z-1">
            <h1 class="about-title entry-title">
                <?php the_title(); ?>
            </h1>
            <p class="about-subtitle">24/7 Fast & Reliable Emergency Service</p>
        </div>
    </section>

    <!-- CONTENT SECTION (from WP Editor) -->
    <?php if (have_posts()):
        while (have_posts()):
            the_post(); ?>
            <?php if (get_the_content()): ?>
                <section class="page-content py-5">
                    <div class="container">
                        <div class="row justify-content-center">
                            <div class="col-lg-10">
                                <?php the_content(); ?>
                            </div>
                        </div>
                    </div>
                </section>
            <?php endif; ?>
        <?php endwhile; endif; ?>

    <!-- 24/7 EMERGENCY PLUMBING -->
    <section id="emergency" class="section-emergency py-5 mb-5">
        <div class="container">
            <div class="emergency-box">
                <!-- Top Row: Text and Features -->
                <div class="row align-items-stretch mb-5">
                    <!-- Left Column: Text Content -->
                    <div class="col-lg-6 mb-5 mb-lg-0">
                        <span class="emergency-badge"><i class="fas fa-phone-alt"></i> Available Now</span>
                        <h2 class="emergency-title">
                            <span class="emergency-accent">24/7</span>
                            Emergency Plumbing Service
                        </h2>
                        <p class="emergency-desc">
                            Burst pipes, flooding, or gas leaks don't wait — and neither do we. Our certified emergency
                            plumbing team is on standby around the clock, ready to respond within <strong>45
                                minutes</strong> anywhere in the area. No hidden fees, no surprises — just fast,
                            reliable service when you need it most.
                        </p>

                        <div class="emergency-stats">
                            <div class="stat-item">
                                <span class="stat-number">45</span>
                                <span class="stat-label">Min Response</span>
                            </div>
                            <div class="stat-item">
                                <span class="stat-number">24/7</span>
                                <span class="stat-label">Availability</span>
                            </div>
                            <div class="stat-item">
                                <span class="stat-number">100%</span>
                                <span class="stat-label">Satisfaction</span>
                            </div>
                        </div>

                        <a href="tel:<?php echo esc_attr(get_option('ticinoweb_contact_phone')); ?>"
                            class="btn btn-primary btn-lg emergency-cta">
                            <i class="fas fa-phone-alt" style="margin-right: 12px;"></i> Call Emergency Now
                        </a>
                    </div>

                    <!-- Right Column: Features -->
                    <div class="col-lg-6">
                        <div class="emergency-features">
                            <div class="emergency-feature-card">
                                <div class="feature-icon-circle"><i class="fas fa-bolt"></i></div>
                                <div class="feature-info">
                                    <h4>Lightning-Fast Response</h4>
                                    <p>Our dispatch team ensures a certified plumber is at your door within 45
                                        minutes.</p>
                                </div>
                            </div>
                            <div class="emergency-feature-card">
                                <div class="feature-icon-circle"><i class="fas fa-shield-halved"></i></div>
                                <div class="feature-info">
                                    <h4>Licensed & Insured Team</h4>
                                    <p>Every technician is fully licensed, insured and background-checked.</p>
                                </div>
                            </div>
                            <div class="emergency-feature-card">
                                <div class="feature-icon-circle"><i class="fas fa-hand-holding-dollar"></i>
                                </div>
                                <div class="feature-info">
                                    <h4>Transparent Pricing</h4>
                                    <p>You'll receive a clear, upfront quote before any work begins.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Bottom Row: Gallery Carousel -->
                <div class="row">
                    <div class="col-12">
                        <?php
                        // Fetch 'gallery home' images
                        $gallery_term = get_term_by('name', 'gallery home', 'ticinoweb_media_gallery');
                        $gallery_images = array();

                        if ($gallery_term && !is_wp_error($gallery_term)) {
                            $gallery_images = get_posts(array(
                                'post_type' => 'attachment',
                                'post_status' => 'inherit',
                                'posts_per_page' => -1,
                                'tax_query' => array(
                                    array(
                                        'taxonomy' => 'ticinoweb_media_gallery',
                                        'field' => 'term_id',
                                        'terms' => $gallery_term->term_id,
                                    ),
                                ),
                                'orderby' => 'menu_order',
                                'order' => 'ASC',
                            ));
                        }
                        ?>

                        <div class="emergency-gallery-wrapper">
                            <?php if (!empty($gallery_images)): ?>
                                <div class="swiper emergencySwiper">
                                    <div class="swiper-wrapper">
                                        <?php foreach ($gallery_images as $image):
                                            $img_url_full = wp_get_attachment_image_url($image->ID, 'large');
                                            $img_alt = get_post_meta($image->ID, '_wp_attachment_image_alt', true);
                                            ?>
                                            <div class="swiper-slide">
                                                <div class="gallery-slide-inner"
                                                    style="background-image: url('<?php echo esc_url($img_url_full); ?>');">
                                                </div>
                                            </div>
                                        <?php endforeach; ?>
                                    </div>
                                    <div class="swiper-pagination"></div>
                                </div>
                            <?php else: ?>
                                <!-- Placeholder if empty -->
                                <div class="d-flex align-items-center justify-content-center h-100 text-white-50">
                                    <p>No images in 'gallery home'</p>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

</main>

<script>
    document.addEventListener('DOMContentLoaded', function () {
        if (document.querySelector('.emergencySwiper') && typeof Swiper !== 'undefined') {
            var emergencySwiper = new Swiper(".emergencySwiper", {
                loop: true,
                effect: "slide",
                speed: 1000,
                autoplay: {
                    delay: 4000,
                    disableOnInteraction: false,
                    pauseOnMouseEnter: true
                },
                pagination: {
                    el: ".swiper-pagination",
                    clickable: true,
                },
            });
        }
    });
</script>

<?php get_footer(); ?>