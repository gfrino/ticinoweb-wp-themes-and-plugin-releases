<!DOCTYPE html>
<html <?php language_attributes(); ?>>

<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php wp_head(); ?>
</head>

<body <?php body_class(); ?> id="home">
    <?php wp_body_open(); ?>

    <style>
        /* Smooth Page Fade-in Effect for Premium Feel */
        body {
            animation: pageFadeIn 0.8s ease-out forwards;
            opacity: 0; /* Starts hidden, animation makes it visible */
        }
        /* Opacity only — deliberately NO transform anywhere in these keyframes.
           <body> holds the floating booking button, the wave canvas and the booking
           modal + backdrop, all position: fixed. Ending the animation at
           `transform: none` (as this did before) is not enough: with
           animation-fill-mode forwards the animation keeps filling, and Chrome
           still treats an element with a filling transform animation as a
           containing block, so those four elements stayed anchored to the document
           instead of the viewport. The button scrolled away with the page and the
           modal opened somewhere far down it, which read as "clicking does
           nothing". Animating a transform on <body> is simply not safe here; the
           slide-up is not worth those four regressions. */
        @keyframes pageFadeIn {
            0% { opacity: 0; }
            100% { opacity: 1; }
        }
        /* Disable animation if user prefers reduced motion */
        @media (prefers-reduced-motion: reduce) {
            body { animation: none; opacity: 1; }
        }
    </style>

    <header class="site-header custom-header">
        <!-- Add navbar and navbar-expand-lg to trigger collapse logic -->
        <div class="header-boxed-wrapper navbar navbar-expand-<?php echo esc_attr( eco_header_breakpoint() ); ?>">

            <!-- Logo (Left) -->
            <div class="site-branding">
                <a href="<?php echo esc_url(home_url('/')); ?>" rel="home"
                    style="text-decoration: none; display: inline-block;">
                    <?php
                    // 1. Try to get logo from TicinoWeb CMS Option (Priority)
                    $logo_url = get_option('ticinoweb_site_logo');

                    // 2. Fallback to Parent Theme Helper if available
                    if (empty($logo_url) && function_exists('ticinoweb_get_site_logo')) {
                        $logo_url = ticinoweb_get_site_logo();
                    }

                    // 3. Fallback to Customizer Logo
                    if (empty($logo_url)) {
                        $custom_logo_id = get_theme_mod('custom_logo');
                        $image = wp_get_attachment_image_src($custom_logo_id, 'full');
                        $logo_url = $image[0] ?? '';
                    }

                    if ($logo_url) {
                        // Above the fold and a Largest Contentful Paint candidate while the hero
                        // video is still deferred, so it is fetched eagerly and at high priority.
                        echo '<img src="' . esc_url($logo_url) . '" alt="' . esc_attr(get_bloginfo('name')) . '" class="site-logo" decoding="async" fetchpriority="high">';
                    } else {
                        // Text Fallback if no image found
                        echo '<span class="site-title" style="font-weight:bold; font-size:1.5rem; color:#0077b6;">' . get_bloginfo('name') . '</span>';
                    }
                    ?>
                </a>
            </div>

            <!-- Hamburger Button for Mobile -->
            <button class="navbar-toggler border-0 shadow-none d-<?php echo esc_attr( eco_header_breakpoint() ); ?>-none" type="button" id="ecoMobileMenuBtn"
                aria-label="Toggle navigation">
                <i class="fas fa-bars" style="color: #0077b6; font-size: 1.8rem;"></i>
            </button>

            <!-- Navigation (Right) Custom Mobile Wrap -->
            <div class="eco-mobile-nav-container" id="ecoMobileNav">
                <nav class="main-navigation ms-auto" id="child-header-nav" style="width: 100%;">
                    <?php
                    wp_nav_menu(array(
                        'theme_location' => 'primary',
                        'menu_id' => 'primary-menu',
                        'container' => false,
                        'fallback_cb' => 'wp_page_menu',
                        'title_li' => '', /* Removes "Pages" title from fallback */
                        'echo' => true,
                    ));
                    ?>
                </nav>
            </div>

            <?php
            // Secondary image, to the right of the menu. Renders nothing when the
            // front page has no image set, so the flex layout is unaffected.
            eco_header_secondary_image();
            ?>

            <!-- Script for Clickable Submenu Arrows -->
            <script>
                document.addEventListener('DOMContentLoaded', function () {
                    var parentItems = document.querySelectorAll('#child-header-nav .menu-item-has-children');

                    // Set index for cascade animation delays (0 to N)
                    // We also set a reverse index for the closing animation
                    document.querySelectorAll('#child-header-nav .sub-menu').forEach(function (menu) {
                        var items = menu.querySelectorAll(':scope > li');
                        var total = items.length;
                        items.forEach(function (li, index) {
                            li.style.setProperty('--item-index', index);
                            li.style.setProperty('--item-reverse-index', total - 1 - index);
                        });
                    });

                    function closeMenu(item) {
                        if (!item.classList.contains('submenu-open')) return;
                        item.classList.remove('submenu-open');
                        var icon = item.querySelector(':scope > .submenu-toggle i');
                        if (icon) {
                            icon.classList.remove('fa-chevron-up');
                            icon.classList.add('fa-chevron-down');
                        }
                    }

                    function openMenu(item) {
                        item.classList.add('submenu-open');
                        var icon = item.querySelector(':scope > .submenu-toggle i');
                        if (icon) {
                            icon.classList.remove('fa-chevron-down');
                            icon.classList.add('fa-chevron-up');
                        }
                    }

                    parentItems.forEach(function (item) {
                        var link = item.querySelector('a');
                        if (!link) return;

                        var toggleBtn = document.createElement('span');
                        toggleBtn.className = 'submenu-toggle';
                        toggleBtn.innerHTML = '<i class="fas fa-chevron-down"></i>';
                        item.insertBefore(toggleBtn, link.nextSibling);

                        function toggleAction(e) {
                            e.preventDefault();
                            e.stopPropagation();
                            var isCurrentlyOpen = item.classList.contains('submenu-open');

                            // Close menus that are NOT ancestors of the clicked item
                            parentItems.forEach(function (otherItem) {
                                if (otherItem !== item && !otherItem.contains(item)) {
                                    closeMenu(otherItem);
                                }
                            });

                            // Toggle the clicked item
                            if (isCurrentlyOpen) {
                                closeMenu(item);
                            } else {
                                openMenu(item);
                            }
                        }

                        toggleBtn.addEventListener('click', toggleAction);

                        // Add click event for the link as well, if it's a structural link (#) or on Mobile
                        link.addEventListener('click', function (e) {
                            if (link.getAttribute('href') === '#' || link.getAttribute('href') === '' || window.innerWidth < 992) {
                                toggleAction(e);
                            }
                        });

                        // Add hover events for desktop ONLY for top-level items
                        var isTopLevel = !item.parentElement.classList.contains('sub-menu');
                        if (isTopLevel) {
                            item.addEventListener('mouseenter', function () {
                                if (window.innerWidth >= 992) {
                                    parentItems.forEach(function (otherItem) {
                                        if (otherItem !== item && !otherItem.contains(item)) {
                                            closeMenu(otherItem);
                                        }
                                    });
                                    openMenu(item);
                                }
                            });

                            item.addEventListener('mouseleave', function () {
                                if (window.innerWidth >= 992) {
                                    closeMenu(item);
                                }
                            });
                        }
                    });

                    // Close all when clicking outside
                    document.addEventListener('click', function (e) {
                        if (!e.target.closest('#child-header-nav')) {
                            var openItems = document.querySelectorAll('#child-header-nav .submenu-open');
                            openItems.forEach(function (item) {
                                closeMenu(item);
                            });
                        }
                    });

                    // Scroll effect for shrinking header. Also flags the root
                    // element, which is what makes the floating booking button start
                    // bouncing once the page has been scrolled — piggybacking on this
                    // listener rather than adding a second one.
                    window.addEventListener('scroll', function () {
                        // Non solo window.scrollY: a seconda della configurazione
                        // dell'overflow lo scroller puo essere l'elemento radice o
                        // body, e in quei casi scrollY resta 0.
                        var y = window.scrollY
                            || document.documentElement.scrollTop
                            || document.body.scrollTop
                            || 0;
                        var scrolled = y > 50;
                        var header = document.querySelector('.custom-header');

                        if (header) {
                            header.classList.toggle('header-scrolled', scrolled);
                        }

                        document.documentElement.classList.toggle('eco-scrolled', scrolled);
                    }, { passive: true });

                    // Custom Vanilla JS Mobile Menu Toggle
                    var mobileBtn = document.getElementById('ecoMobileMenuBtn');
                    var mobileNav = document.getElementById('ecoMobileNav');
                    if (mobileBtn && mobileNav) {
                        mobileBtn.addEventListener('click', function (e) {
                            e.preventDefault();
                            mobileNav.classList.toggle('show');

                            // Toggle Hamburger to X
                            var icon = mobileBtn.querySelector('i');
                            if (icon) {
                                if (mobileNav.classList.contains('show')) {
                                    icon.classList.remove('fa-bars');
                                    icon.classList.add('fa-times');
                                } else {
                                    icon.classList.remove('fa-times');
                                    icon.classList.add('fa-bars');
                                }
                            }
                        });
                    }
                });
            </script>

        </div>
    </header>