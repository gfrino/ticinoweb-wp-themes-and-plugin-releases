<?php
/**
 * Booking / Free Quote Modal Template
 */

$logo_url = get_option('ticinoweb_site_logo');

if (empty($logo_url) && function_exists('ticinoweb_get_site_logo')) {
    $logo_url = ticinoweb_get_site_logo();
}

if (empty($logo_url)) {
    $custom_logo_id = get_theme_mod('custom_logo');
    $image = wp_get_attachment_image_src($custom_logo_id, 'full');
    $logo_url = $image[0] ?? '';
}
?>

<!-- =========================================
     BOOKING / FREE QUOTE MODAL 
     ========================================= -->
<div class="modal fade eco-booking-modal" id="bookingModal" tabindex="-1" aria-labelledby="bookingModalLabel"
    aria-hidden="true">
    <?php // modal-dialog-centered: il popup si centra nel viewport. Prima un
          // margin-top di 150px lo inchiodava in cima al documento, quindi su una
          // pagina scrollata si apriva fuori dalla vista. ?>
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content shadow-lg eco-modal-content">
            <div class="modal-header eco-modal-header border-0 text-center">
                <button type="button" class="eco-modal-close" data-bs-dismiss="modal" aria-label="Close">✕</button>
                <div class="eco-modal-logo">
                    <?php if ($logo_url): ?>
                        <?php // The modal is hidden until opened, so this never needs to load with the page. ?>
                        <img src="<?php echo esc_url($logo_url); ?>" alt="<?php bloginfo('name'); ?>"
                            loading="lazy" decoding="async">
                    <?php else: ?>
                        <h2><?php bloginfo('name'); ?></h2>
                    <?php endif; ?>
                </div>
                <h2 class="eco-modal-title">SCHEDULE SERVICE</h2>
            </div>
            <div class="modal-body eco-modal-body">
                <form class="booking-modal-form">
                    <div class="eco-form-group">
                        <label class="eco-form-label">Full Name *</label>
                        <input type="text" class="eco-form-control" placeholder="John Smith" required>
                    </div>
                    
                    <div class="eco-form-group">
                        <label class="eco-form-label">Phone</label>
                        <div class="eco-input-group">
                            <span class="eco-input-group-text">
                                <span class="flag">🇨🇭</span> <span class="arrow">▼</span>
                            </span>
                            <input type="tel" class="eco-form-control" placeholder="Example: (808) 555-1234">
                        </div>
                    </div>
                    
                    <div class="eco-form-group" style="margin-bottom: 2rem;">
                        <label class="eco-form-label">Short message about your needs *</label>
                        <textarea class="eco-form-control" rows="3" placeholder="**Your message goes straight to my phone, I'll get back to you as soon as I'm available**" required></textarea>
                    </div>
                    
                    <div class="eco-form-check">
                        <input class="eco-form-check-input" type="checkbox" id="termsCheck" required>
                        <label class="eco-form-check-label" for="termsCheck">
                            I agree to <a href="<?php echo esc_url(site_url('/terms-conditions/')); ?>" class="modal-link">terms & conditions</a> provided by the company. By providing my phone number, I agree to receive text messages from the business.
                        </label>
                    </div>
                    
                    <button type="submit" class="eco-submit-quote-btn">SEND</button>
                </form>
            </div>
        </div>
    </div>
</div>

<?php
$target_modal_id = function_exists('ecoproplumbing_get_cta_config') ? ecoproplumbing_get_cta_config()['target_modal'] : '#bookingModal';
?>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        // Attach modal to the first button in the hero slider specifically
        var firstHeroBtn = document.querySelector('.hero-actions .btn');
        if (firstHeroBtn) {
            firstHeroBtn.setAttribute('data-bs-toggle', 'modal');
            firstHeroBtn.setAttribute('data-bs-target', '<?php echo esc_js($target_modal_id); ?>');
            firstHeroBtn.addEventListener('click', function (e) {
                e.preventDefault();
            });
        }
    });
</script>