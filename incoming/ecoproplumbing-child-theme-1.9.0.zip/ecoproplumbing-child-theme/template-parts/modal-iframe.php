<?php
/**
 * Modal Iframe Template for Custom CTA Link
 *
 * Rendered when LINK CTA is set to "iframe".
 */

if (!defined('ABSPATH')) {
    exit;
}

$eco_cta = ecoproplumbing_get_cta_config();
if ($eco_cta['type'] !== 'iframe' || empty($eco_cta['link'])) {
    return;
}

$logo_url = get_option('ticinoweb_site_logo');
if (empty($logo_url) && function_exists('ticinoweb_get_site_logo')) {
    $logo_url = ticinoweb_get_site_logo();
}
if (empty($logo_url)) {
    $custom_logo_id = get_theme_mod('custom_logo');
    $image = wp_get_attachment_image_src($custom_logo_id, 'full');
    $logo_url = $image[0] ?? '';
}
?>

<!-- =========================================
     CUSTOM LINK IFRAME MODAL
     ========================================= -->
<div class="modal fade eco-booking-modal eco-iframe-modal" id="bookingIframeModal" tabindex="-1" aria-labelledby="bookingIframeModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-xl">
        <div class="modal-content shadow-lg eco-modal-content">
            <div class="modal-header eco-modal-header" style="padding: 0.85rem 1.25rem; display: flex; flex-direction: row; justify-content: space-between; align-items: center; border-bottom: 1px solid rgba(255, 255, 255, 0.15);">
                <div class="eco-modal-logo" style="margin: 0; display: flex; align-items: center;">
                    <?php if ($logo_url): ?>
                        <img src="<?php echo esc_url($logo_url); ?>" alt="<?php bloginfo('name'); ?>" style="height: 42px; width: auto; max-width: 220px; object-fit: contain;" loading="lazy" decoding="async">
                    <?php else: ?>
                        <h3 style="margin: 0; color: #fff; font-size: 1.15rem; font-weight: 700;"><?php bloginfo('name'); ?></h3>
                    <?php endif; ?>
                </div>

                <div style="display: flex; align-items: center; gap: 10px;">
                    <a href="<?php echo esc_url($eco_cta['link']); ?>" target="_blank" rel="noopener noreferrer" class="eco-iframe-new-tab-btn" title="<?php esc_attr_e('Open in new tab', 'ecoproplumbing'); ?>">
                        <span><?php esc_html_e('Open in new window', 'ecoproplumbing'); ?></span>
                        <i class="fas fa-external-link-alt" style="font-size: 0.75rem; margin-left: 4px;"></i>
                    </a>
                    <button type="button" class="eco-modal-close" data-bs-dismiss="modal" aria-label="Close" style="position: static; padding: 4px 10px; font-size: 1.3rem;">✕</button>
                </div>
            </div>

            <div class="modal-body eco-modal-body" style="padding: 0; position: relative; height: 78vh; min-height: 520px; background: #ffffff; border-bottom-left-radius: 12px; border-bottom-right-radius: 12px; overflow: hidden;">
                <!-- Loading Spinner -->
                <div id="eco-iframe-spinner" style="position: absolute; inset: 0; display: flex; flex-direction: column; align-items: center; justify-content: center; background: #f8fafc; z-index: 2;">
                    <div style="width: 38px; height: 38px; border: 3px solid rgba(13, 148, 136, 0.2); border-top-color: #0d9488; border-radius: 50%; animation: ecoIframeSpinner 0.8s linear infinite;"></div>
                    <p style="margin-top: 12px; font-size: 13px; color: #64748b; font-weight: 500; font-family: sans-serif;"><?php esc_html_e('Loading form...', 'ecoproplumbing'); ?></p>
                </div>

                <iframe id="ecoBookingIframe"
                        src=""
                        data-src="<?php echo esc_url($eco_cta['link']); ?>"
                        title="<?php esc_attr_e('Service Request Form', 'ecoproplumbing'); ?>"
                        style="width: 100%; height: 100%; border: none; display: block;"
                        allow="clipboard-write; payment; geolocation"
                        loading="lazy"></iframe>
            </div>

            <!-- Fallback bar for cross-origin / browser security restrictions -->
            <div style="padding: 8px 16px; background: rgba(0, 0, 0, 0.25); text-align: center; font-size: 12px; color: rgba(255, 255, 255, 0.85); display: flex; align-items: center; justify-content: center; gap: 8px; flex-wrap: wrap;">
                <span><?php esc_html_e('Having trouble viewing the embedded form?', 'ecoproplumbing'); ?></span>
                <a href="<?php echo esc_url($eco_cta['link']); ?>" target="_blank" rel="noopener noreferrer" style="color: #6ee7b7; font-weight: 600; text-decoration: underline;">
                    <?php esc_html_e('Click here to open the request form directly', 'ecoproplumbing'); ?> &rarr;
                </a>
            </div>
        </div>
    </div>
</div>

<style>
.modal-backdrop {
    z-index: 100040 !important;
}
.eco-booking-modal.eco-iframe-modal,
.modal.eco-iframe-modal {
    z-index: 100050 !important;
}
@keyframes ecoIframeSpinner {
    to { transform: rotate(360deg); }
}
.eco-iframe-modal .modal-dialog {
    max-width: 1100px;
    width: 94%;
    margin-top: max(1.5rem, 40px);
    margin-bottom: 1.5rem;
}
.eco-iframe-new-tab-btn {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 6px 12px;
    background: rgba(255, 255, 255, 0.14);
    border: 1px solid rgba(255, 255, 255, 0.25);
    color: #ffffff !important;
    text-decoration: none !important;
    border-radius: 6px;
    font-size: 12px;
    font-weight: 600;
    transition: all 0.2s ease;
}
.eco-iframe-new-tab-btn:hover {
    background: rgba(255, 255, 255, 0.25);
    color: #ffffff !important;
    transform: translateY(-1px);
}
@media (max-width: 576px) {
    .eco-iframe-modal .modal-dialog {
        margin: 0.5rem;
        width: calc(100% - 1rem);
    }
    .eco-iframe-modal .modal-body {
        height: 80vh !important;
        min-height: 400px !important;
    }
    .eco-iframe-new-tab-btn span {
        display: none;
    }
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function () {
    var modalEl = document.getElementById('bookingIframeModal');
    if (!modalEl) return;

    var iframe = document.getElementById('ecoBookingIframe');
    var spinner = document.getElementById('eco-iframe-spinner');

    if (iframe) {
        iframe.addEventListener('load', function () {
            if (spinner) {
                spinner.style.display = 'none';
            }
        });
    }

    modalEl.addEventListener('show.bs.modal', function () {
        if (iframe && !iframe.getAttribute('src') && iframe.getAttribute('data-src')) {
            iframe.setAttribute('src', iframe.getAttribute('data-src'));
        }
    });
});
</script>
