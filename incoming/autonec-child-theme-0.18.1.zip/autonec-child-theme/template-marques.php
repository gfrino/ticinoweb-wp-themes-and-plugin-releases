<?php
/** Template Name: Marchi Autonec
 * @package AutonecChildTheme */
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header(); ?>
<main id="main-content" class="an-marques-page" tabindex="-1">
 <?php autonec_brand_navigation(); ?>
 <header class="an-directory-intro an-wrap">
  <h1><?php the_title(); ?></h1>
  <div><?php while ( have_posts() ) : the_post(); the_content(); endwhile; ?></div>
 </header>
 <div class="an-directory">
 <?php foreach ( autonec_brand_pages() as $brand_index => $brand ) : ?>
  <a class="an-directory-row an-wrap" href="<?php echo esc_url( $brand['button_url'] ); ?>">
   <?php if ( $brand['image'] ) : ?><div class="an-directory-row__photo"><?php autonec_image( $brand, '', 0 === $brand_index ); ?></div><?php endif; ?>
   <div class="an-directory-row__copy">
    <?php if ( $brand['logo_id'] ) { echo wp_get_attachment_image( $brand['logo_id'], 'medium', false, array( 'alt'=>'', 'aria-hidden'=>'true', 'class'=>'an-directory-row__logo' ) ); } ?>
    <h2><?php echo esc_html( rtrim( $brand['title'], '. ' ) ); ?></h2>
    <?php $lead = preg_split( '/\R/', trim( $brand['description'] ), 2 )[0]; if ( $lead ) : ?><p><?php echo esc_html( $lead ); ?></p><?php endif; ?>
    <?php if ( $brand['button_text'] ) : ?><span class="an-link"><?php echo esc_html( $brand['button_text'] ); ?></span><?php endif; ?>
   </div>
  </a>
 <?php endforeach; ?>
 </div>
</main>
<?php get_footer(); ?>
