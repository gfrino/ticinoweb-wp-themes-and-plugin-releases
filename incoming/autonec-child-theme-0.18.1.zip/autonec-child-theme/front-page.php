<?php
/**
 * THESIS: A cinematic showroom that changes direction through the four marques.
 * OWN-WORLD: Soft charcoal, original marque identities, Autonec red, motoring typography.
 * STORY: Change viewpoint, explore four marques, discover 365, meet the team.
 * FIRST VIEWPORT: Large live heading over the official Opel/Hyundai/Leapmotor montage;
 * CMS action and copy remain clear beneath it.
 * FORM: Automotive photographic campaign, grounded direction 5, shared-viewpoint
 * staging; seed a2df8ec6, refined by explicit user direction. All content uses the CMS.
 * @package AutonecChildTheme
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
$all_slides = autonec_home_slides();
$hero = null;
$slides = array();
foreach ( $all_slides as $slide ) {
 if ( 1 === $slide['slot'] ) { $hero = $slide; } else { $slides[] = $slide; }
}
$about = autonec_home_about();
$promo = autonec_home_promo();
$services = autonec_home_services();
$hero_video = $hero ? autonec_hero_video_url( $hero['image_id'] ) : '';
$faq_ref = get_post_meta( get_queried_object_id(), '_tw_faq_page_set', true );
$faq = $faq_ref ? ticinoweb_faq_get_set( $faq_ref ) : null;
ob_start();
while ( have_posts() ) : the_post();
 $append_faq = has_filter( 'the_content', 'ticinoweb_faq_append_to_content' );
 if ( false !== $append_faq ) { remove_filter( 'the_content', 'ticinoweb_faq_append_to_content', $append_faq ); }
 the_content();
 if ( false !== $append_faq ) { add_filter( 'the_content', 'ticinoweb_faq_append_to_content', $append_faq ); }
endwhile;
$intro_html = ob_get_clean();
get_header();
?>
<main id="main-content" class="an-home" tabindex="-1">
<?php if ( $slides ) : ?>
<nav class="an-brand-nav" data-brand-nav aria-label="<?php esc_attr_e( 'Esplora i marchi', 'autonec-child-theme' ); ?>">
 <?php foreach ( $slides as $slide ) : if ( ! $slide['image'] || ! $slide['title'] ) { continue; } ?>
 <a href="#marchio-<?php echo esc_attr( $slide['slot'] ); ?>" data-brand-link="<?php echo esc_attr( $slide['slot'] ); ?>">
  <?php if ( $slide['logo_id'] ) { echo wp_get_attachment_image( $slide['logo_id'], 'medium', false, array( 'class'=>'an-brand-nav__logo', 'alt'=>'', 'aria-hidden'=>'true' ) ); } ?>
  <span><?php echo esc_html( rtrim( $slide['title'], '. ' ) ); ?></span>
 </a>
 <?php endforeach; ?>
</nav>
<?php endif; ?>
<?php if ( $hero && $hero['title'] ) : ?>
<section class="an-hero" data-hero aria-labelledby="an-hero-title">
 <div class="an-hero__stage" data-hero-stage>
  <div class="an-hero__word" data-scene-word aria-hidden="true"><span data-word="<?php echo esc_attr( autonec_site_name() ); ?>"><?php echo esc_html( autonec_site_name() ); ?></span></div>
  <?php if ( $hero['image'] ) : ?>
  <div class="an-hero__media" data-hero-media>
   <?php autonec_image( $hero, 'an-hero__poster', true ); ?>
   <?php if ( $hero_video ) : ?><video class="an-hero__video" data-hero-video data-src="<?php echo esc_url( $hero_video ); ?>" muted loop playsinline preload="none" aria-hidden="true" tabindex="-1"></video><?php endif; ?>
  </div>
  <?php endif; ?>
  <div class="an-hero__heading" data-hero-heading>
   <h1 id="an-hero-title"><?php
    $title_words = preg_split( '/\s+/u', trim( $hero['title'] ) );
    foreach ( $title_words as $word_index => $title_word ) {
     if ( $word_index ) { echo ' '; }
     echo '<span class="an-hero__title-word">' . esc_html( $title_word ) . '</span>';
    }
   ?></h1>
  </div>
  <div class="an-hero__copy" data-hero-copy>
   <?php if ( $hero['description'] ) : ?><p><?php echo nl2br( esc_html( $hero['description'] ) ); ?></p><?php endif; ?>
   <?php if ( $hero['button_text'] && $hero['button_url'] ) : ?><a class="an-link an-link--light" href="<?php echo esc_url( $hero['button_url'] ); ?>"><?php echo esc_html( $hero['button_text'] ); ?></a><?php endif; ?>
  </div>
 </div>
 <section id="prospettive" class="an-hero__arrival an-wrap" data-arrival>
  <?php echo $intro_html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- native the_content output. ?>
  <?php if ( $hero['button_text'] && $hero['button_url'] ) : ?><a class="an-link" href="<?php echo esc_url( $hero['button_url'] ); ?>"><?php echo esc_html( $hero['button_text'] ); ?></a><?php endif; ?>
 </section>
</section>
<?php else : ?><section class="an-wrap an-hero__arrival"><h1><?php the_title(); ?></h1><?php echo $intro_html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></section><?php endif; ?>

<?php if ( $slides ) : ?>
<section id="marchi" class="an-marques" data-journey aria-label="<?php esc_attr_e( 'I nostri marchi', 'autonec-child-theme' ); ?>">
 <div class="an-journey__stage" data-journey-stage><div class="an-journey__track" data-journey-track>
 <?php foreach ( $slides as $index=>$slide ) : if ( ! $slide['image'] || ! $slide['title'] ) { continue; } $copy = preg_split( '/\R/', trim( $slide['description'] ), 2 ); ?>
 <article id="marchio-<?php echo esc_attr( $slide['slot'] ); ?>" class="an-marque<?php echo strlen( $slide['title'] ) > 14 ? ' an-marque--long' : ''; ?>" data-marque tabindex="-1">
  <div class="an-marque__content">
   <?php if ( $slide['logo_id'] ) { echo wp_get_attachment_image( $slide['logo_id'], 'medium', false, array( 'class'=>'an-marque__logo', 'alt'=>'', 'aria-hidden'=>'true' ) ); } ?>
   <h2><?php echo esc_html( $slide['title'] ); ?></h2>
   <?php if ( ! empty( $copy[0] ) ) : ?><p class="an-marque__lead"><?php echo esc_html( $copy[0] ); ?></p><?php endif; ?>
   <?php if ( ! empty( $copy[1] ) ) : ?><div class="an-marque__body"><?php echo wp_kses_post( wpautop( $copy[1] ) ); ?></div><?php endif; ?>
   <?php if ( $slide['button_text'] && $slide['button_url'] ) : ?><a class="an-link" href="<?php echo esc_url( $slide['button_url'] ); ?>"><?php echo esc_html( $slide['button_text'] ); ?></a><?php endif; ?>
  </div>
  <div class="an-marque__photo"><?php autonec_image( $slide ); ?></div>
 </article>
 <?php endforeach; ?>
 </div></div>
</section>
<?php endif; ?>

<?php if ( ! empty( $promo['title'] ) && ! empty( $promo['image'] ) ) : ?>
<section class="an-365" id="autonec-365" data-showroom>
 <div class="an-365__heading an-wrap"><h2><?php echo esc_html( $promo['title'] ); ?></h2></div>
 <div class="an-365__layout">
  <div class="an-365__photo" data-showroom-photo><?php autonec_image( $promo ); ?>
   <?php $showroom_video = autonec_hero_video_url( $promo['image_id'] ); if ( $showroom_video ) : ?><video class="an-365__video" data-showroom-video data-src="<?php echo esc_url( $showroom_video ); ?>" muted loop playsinline preload="none" aria-hidden="true" tabindex="-1"></video><?php endif; ?>
  </div>
  <div class="an-365__content">
   <?php echo wp_kses_post( wpautop( $promo['text'] ) ); ?>
   <?php if ( $promo['link'] ) : ?><a class="an-link an-link--light" href="<?php echo esc_url( $promo['link'] ); ?>"><?php esc_html_e( 'Scopri come funziona', 'autonec-child-theme' ); ?></a><?php endif; ?>
  </div>
 </div>
</section>
<?php endif; ?>

<?php if ( $about['title'] || $about['text'] ) : ?>
<section class="an-about an-wrap" id="autonec" data-reveal>
 <div class="an-about__heading"><p class="an-overline"><?php echo esc_html( autonec_site_name() ); ?></p><h2><?php echo nl2br( esc_html( $about['title'] ) ); ?></h2></div>
 <div class="an-about__body"><?php echo wp_kses_post( wpautop( $about['text'] ) ); ?><?php if ( $about['link'] ) : ?><a class="an-link" href="<?php echo esc_url( $about['link'] ); ?>"><?php echo esc_html(autonec_about_page() ? __('Chi siamo','autonec-child-theme') : __('Parliamone','autonec-child-theme')); ?></a><?php endif; ?></div>
 <?php if ( $about['image'] ) : ?><figure class="an-about__photo"><?php autonec_image( $about ); ?></figure><?php endif; ?>
</section>
<?php endif; ?>

<?php if ( $services ) : ?>
<section class="an-services an-wrap" id="servizi" aria-labelledby="an-services-title">
 <div class="an-services__heading"><h2 id="an-services-title"><?php esc_html_e( 'Servizi', 'autonec-child-theme' ); ?></h2>
 <?php $services_url = autonec_section_url( 'services' ); if ( $services_url ) : ?><a class="an-link" href="<?php echo esc_url( $services_url ); ?>"><?php esc_html_e( 'Tutti i servizi', 'autonec-child-theme' ); ?></a><?php endif; ?></div>
 <div class="an-services__list">
  <?php foreach ( $services as $service ) : if ( empty( $service['title'] ) ) { continue; } ?>
  <article class="an-service-row" data-service-row><h3><?php echo esc_html( $service['title'] ); ?></h3><div><?php echo wp_kses_post( wpautop( autonec_service_summary( $service['description'] ?? '' ) ) ); ?></div></article>
  <?php endforeach; ?>
 </div>
</section>
<?php endif; ?>

<?php if ( $faq && $faq['items'] ) : ticinoweb_faq_schema_add( $faq['items'] ); ?>
<section class="an-faq an-wrap" aria-labelledby="an-faq-title">
 <h2 id="an-faq-title"><?php echo esc_html( $faq['title'] ); ?></h2>
 <div><?php foreach ( $faq['items'] as $item ) : ?><details class="an-service"><summary><?php echo esc_html( $item['question'] ); ?><span aria-hidden="true">+</span></summary><div><?php echo wp_kses_post( wpautop( $item['answer'] ) ); ?></div></details><?php endforeach; ?></div>
</section>
<?php endif; ?>
</main>
<?php get_footer(); ?>
