<?php
/** Template Name: Informazioni legali Autonec
 * @package AutonecChildTheme */
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header(); ?>
<main id="main-content" class="an-legal-page an-wrap" tabindex="-1">
 <?php while ( have_posts() ) : the_post(); ?>
 <header class="an-legal-page__heading">
  <h1><?php the_title(); ?></h1>
  <?php if ( has_excerpt() ) : ?><div class="an-legal-page__lead"><?php the_excerpt(); ?></div><?php endif; ?>
 </header>
 <div class="an-legal-page__layout">
  <aside class="an-legal-page__navigation">
   <?php autonec_footer_navigation( 'footer_legal', __( 'Informazioni legali', 'autonec-child-theme' ), 2 ); ?>
   <p><?php echo esc_html( sprintf( __( 'Aggiornato il %s', 'autonec-child-theme' ), get_the_modified_date( 'j F Y' ) ) ); ?></p>
  </aside>
  <article class="an-legal-page__content entry-content"><?php the_content(); ?></article>
 </div>
 <?php endwhile; ?>
</main>
<?php get_footer(); ?>
