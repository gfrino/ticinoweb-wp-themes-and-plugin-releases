<?php
/**
 * Template Name: Gamma nuova Autonec
 * THESIS: four photographic marque chapters lead directly to their complete model ranges.
 * OWN-WORLD: approved charcoal, Barlow, white marque logos, open photographic model grids.
 * STORY: choose a marque or body type, discover a model, ask Autonec or inspect actual stock.
 * FIRST VIEWPORT: shared logo rail and native title, then the first large marque photograph.
 * Each alternating chapter is an independent entry; filtered views retain every model.
 * FORM: extension of the approved Autonec world, Operate mode, natural vertical brand chapters.
 * @package AutonecChildTheme
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
$filters = autonec_gamma_filters();
$brands = autonec_gamma_presentation_brands();
$all_models = autonec_gamma_query( array( 'posts_per_page'=>-1, 'no_found_rows'=>true ) );
$range_counts = autonec_gamma_brand_counts( $all_models->posts );
$selected_brand = $brands[$filters['marca']] ?? null;
$categories = array();
foreach ( $all_models->posts as $model ) {
 $data = autonec_gamma_data( $model->ID );
 if ( $filters['marca'] && $filters['marca'] !== $data['brand_slug'] ) { continue; }
 $category = (string) ( $data['category'] ?? '' );
 if ( $category ) { $categories[sanitize_title( $category )] = $category; }
}
$groups = array(); $visible_count = 0; $models = null;
if ( $filters['marca'] ) {
 $models = autonec_gamma_query( autonec_gamma_listing_args( $filters ) );
 $models = autonec_listing_resolve_page( $models, $filters, static fn($values) => autonec_gamma_query( autonec_gamma_listing_args( $values ) ) );
 update_post_thumbnail_cache( $models );
 $visible_count = (int) $models->found_posts;
 $groups[$filters['marca']] = $models->posts;
}
$lead_id = $selected_brand ? absint( $selected_brand['image_id'] ?? 0 ) : 0;

autonec_listing_seo_context( $models, $filters );
get_header(); ?>
<main id="main-content" class="an-gamma-page" tabindex="-1">
 <?php autonec_gamma_navigation( $filters['marca'] ); ?>
 <div class="an-wrap">
  <?php while ( have_posts() ) : the_post(); ?>
  <header class="an-gamma-opening<?php echo $lead_id ? '' : ' an-gamma-opening--text'; ?>">
   <div class="an-gamma-opening__copy"><?php if ( $selected_brand && ! empty( $selected_brand['logo_id'] ) ) { echo wp_get_attachment_image( $selected_brand['logo_id'], 'medium', false, array( 'alt'=>'', 'class'=>'an-gamma-selected-logo' ) ); } ?><h1><?php echo $selected_brand ? esc_html( $selected_brand['name'] ) : esc_html( get_the_title() ); ?></h1><?php if($selected_brand && !empty($selected_brand['description'])): $lead=preg_split('/\R/u',trim($selected_brand['description']),2);?><div class="an-gamma-opening__lead"><p><?php echo esc_html($lead[0]);?></p></div><?php elseif(has_excerpt()):?><div class="an-gamma-opening__lead"><?php the_excerpt();?></div><?php endif;?><p class="an-gamma-opening__note"><?php esc_html_e( 'La gamma dei costruttori, da conoscere e scegliere. La disponibilità delle singole auto è nel nostro catalogo.', 'autonec-child-theme' ); ?></p><?php if ( autonec_catalogue_page_url() ) : ?><a class="an-model-card__link" href="<?php echo esc_url( $selected_brand ? add_query_arg('marca',$filters['marca'],autonec_catalogue_page_url()) : autonec_catalogue_page_url() ); ?>"><?php esc_html_e( 'Cerchi un’auto disponibile?', 'autonec-child-theme' ); ?></a><?php endif; ?></div>
   <?php if ( $lead_id ) : ?><figure class="an-gamma-opening__photo"><?php echo wp_get_attachment_image( $lead_id, 'full', false, array( 'loading'=>'eager', 'fetchpriority'=>'high', 'decoding'=>'async', 'sizes'=>'(max-width: 800px) 92vw, 58vw' ) ); ?></figure><?php endif; ?>
  </header>
  <?php if ( trim( get_the_content() ) ) : ?><div class="an-gamma-editorial entry-content"><?php the_content(); ?></div><?php endif; ?>
  <?php endwhile; ?>
  <?php if ( ! $filters['marca'] ) : ?>
 </div>
 <div class="an-gamma-journey"><?php autonec_gamma_brand_journey( $range_counts ); ?></div>
 <div class="an-wrap">
  <?php else : ?>
  <div id="an-gamma-results" class="an-gamma-explorer" data-an-gamma data-category="<?php echo esc_attr( $filters['categoria'] ); ?>">
   <div class="an-gamma-toolbar">
    <div class="an-gamma-scope"><?php if ( $filters['marca'] ) : ?><a href="<?php echo esc_url( autonec_gamma_page_url() ); ?>"><?php esc_html_e( 'Tutti i marchi', 'autonec-child-theme' ); ?></a><?php else : ?><span><?php esc_html_e( 'Tutti i marchi', 'autonec-child-theme' ); ?></span><?php endif; ?><p><?php if ( $visible_count ) { printf( esc_html__( 'Modelli %1$s–%2$s di %3$s', 'autonec-child-theme' ), esc_html( number_format_i18n( ( $filters['pagina'] - 1 ) * (int) $models->query_vars['posts_per_page'] + 1 ) ), esc_html( number_format_i18n( min( $filters['pagina'] * (int) $models->query_vars['posts_per_page'], $visible_count ) ) ), esc_html( number_format_i18n( $visible_count ) ) ); } else { esc_html_e( 'Nessun modello', 'autonec-child-theme' ); } ?></p></div>
    <?php if ( $categories ) : ?>
    <form class="an-gamma-filter" action="<?php echo esc_url( autonec_gamma_page_url() . '#an-gamma-results' ); ?>" method="get" data-an-gamma-form>
     <?php if ( $filters['marca'] ) : ?><input type="hidden" name="marca" value="<?php echo esc_attr( $filters['marca'] ); ?>"><?php endif; ?>
     <label for="an-gamma-category"><?php esc_html_e( 'Tipo di veicolo', 'autonec-child-theme' ); ?></label>
     <select id="an-gamma-category" name="categoria"><option value=""><?php esc_html_e( 'Tutti i tipi', 'autonec-child-theme' ); ?></option><?php foreach ( $categories as $value=>$label ) : ?><option value="<?php echo esc_attr( $value ); ?>" <?php selected( $filters['categoria'], $value ); ?>><?php echo esc_html( autonec_gamma_category_label( $label ) ); ?></option><?php endforeach; ?></select>
     <button class="an-link" type="submit"><?php esc_html_e( 'Filtra', 'autonec-child-theme' ); ?></button>
    </form>
    <?php endif; ?>
   </div>
   <?php foreach ( $groups as $slug=>$group ) : $brand = $brands[$slug] ?? array(); $name = $brand['name'] ?? ''; if ( ! $name ) { $term = get_term_by( 'slug', $slug, 'an_marca' ); $name = $term ? $term->name : ''; } $group_visible = false; foreach ( $group as $model ) { if ( ! $filters['categoria'] || sanitize_title( (string) ( autonec_gamma_data( $model->ID )['category'] ?? '' ) ) === $filters['categoria'] ) { $group_visible = true; break; } } ?>
   <section class="an-gamma-chapter" data-an-gamma-group<?php echo $group_visible ? '' : ' hidden'; ?> aria-labelledby="an-gamma-title-<?php echo esc_attr( $slug ?: 'models' ); ?>">
    <header class="an-gamma-section-heading"><h2 id="an-gamma-title-<?php echo esc_attr( $slug ?: 'models' ); ?>"><?php echo esc_html( $name ?: __( 'I modelli', 'autonec-child-theme' ) ); ?></h2><?php if ( ! empty( $brand['button_url'] ) ) : ?><a class="an-model-card__link" href="<?php echo esc_url( $brand['button_url'] ); ?>"><?php esc_html_e( 'Il mondo del marchio', 'autonec-child-theme' ); ?></a><?php endif; ?></header>
    <div class="an-gamma-grid"><?php foreach ( $group as $model ) { autonec_gamma_card( $model->ID, false, $filters['categoria'] ); } ?></div>
   </section>
   <?php endforeach; ?>
   <div class="an-gamma-empty" data-an-gamma-empty<?php echo $visible_count ? ' hidden' : ''; ?>><h2><?php esc_html_e( 'Nessun modello con questi filtri', 'autonec-child-theme' ); ?></h2><p><?php esc_html_e( 'Scegli un altro tipo di veicolo o esplora tutti i marchi.', 'autonec-child-theme' ); ?></p><a class="an-link" href="<?php echo esc_url( autonec_gamma_page_url() ); ?>"><?php esc_html_e( 'Tutta la gamma', 'autonec-child-theme' ); ?></a></div>
   <?php autonec_gamma_pagination( $models, $filters ); ?>
  </div>
  <?php endif; ?>
 </div>
</main>
<?php get_footer(); ?>
