<?php
/** Local vehicle detail with a native, progressively enhanced Media gallery. @package AutonecChildTheme */
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header(); ?>
<main id="main-content" class="an-vehicle-page" tabindex="-1">
 <?php autonec_brand_navigation(); ?>
 <?php while ( have_posts() ) : the_post(); $vehicle_id = get_the_ID(); $data = autonec_catalogue_data( $vehicle_id ); $gallery = autonec_catalogue_gallery_ids( $vehicle_id, $data ); $price = autonec_catalogue_price( $data ); $unavailable = 'available' !== ( $data['availability'] ?? '' ); ?>
 <article class="an-wrap an-vehicle-detail">
  <?php if ( autonec_catalogue_page_url() ) : ?><a class="an-vehicle-back" href="<?php echo esc_url( autonec_catalogue_page_url() ); ?>"><?php esc_html_e( 'Torna al catalogo', 'autonec-child-theme' ); ?></a><?php endif; ?>

  <div class="an-vehicle-layout">
   <div class="an-vehicle-gallery" data-an-gallery role="region" aria-label="<?php esc_attr_e( 'Fotografie del veicolo', 'autonec-child-theme' ); ?>">
    <?php if ( $gallery ) : ?>
     <div class="an-vehicle-gallery__frames">
      <?php foreach ( $gallery as $index=>$attachment_id ) : ?><figure id="an-vehicle-photo-<?php echo absint( $index + 1 ); ?>" class="an-vehicle-gallery__frame" data-an-gallery-frame>
       <?php echo wp_get_attachment_image( $attachment_id, 'full', false, array( 'alt'=>sprintf( __( '%1$s — foto %2$d', 'autonec-child-theme' ), get_the_title(), $index + 1 ), 'loading'=>0 === $index ? 'eager' : 'lazy', 'fetchpriority'=>0 === $index ? 'high' : 'auto', 'decoding'=>'async', 'sizes'=>'(max-width: 900px) 92vw, 65vw' ) ); ?>
      </figure><?php endforeach; ?>
     </div>
     <?php if ( count( $gallery ) > 1 ) : ?>
      <div class="an-vehicle-gallery__controls" data-an-gallery-controls hidden>
       <p class="an-vehicle-gallery__count" data-an-gallery-count aria-live="polite" aria-atomic="true" data-format="<?php esc_attr_e( 'Foto %1$d di %2$d', 'autonec-child-theme' ); ?>"><?php printf( esc_html__( 'Foto %1$d di %2$d', 'autonec-child-theme' ), 1, count( $gallery ) ); ?></p>
       <div class="an-vehicle-gallery__thumbnails"><?php foreach ( $gallery as $index=>$attachment_id ) : ?><button type="button" data-an-gallery-button="<?php echo absint( $index ); ?>" aria-controls="an-vehicle-photo-<?php echo absint( $index + 1 ); ?>" aria-label="<?php echo esc_attr( sprintf( __( 'Mostra foto %1$d di %2$d', 'autonec-child-theme' ), $index + 1, count( $gallery ) ) ); ?>" aria-pressed="<?php echo 0 === $index ? 'true' : 'false'; ?>"><?php echo wp_get_attachment_image( $attachment_id, 'thumbnail', false, array( 'alt'=>'', 'loading'=>'lazy', 'decoding'=>'async', 'sizes'=>'112px' ) ); ?></button><?php endforeach; ?></div>
      </div>
     <?php endif; ?>
    <?php else : ?><p class="an-vehicle-gallery__empty"><?php esc_html_e( 'Le fotografie di questa auto non sono disponibili.', 'autonec-child-theme' ); ?></p><?php endif; ?>
   </div>
   <div class="an-vehicle-facts">
  <header class="an-vehicle-heading"><div><h1><?php the_title(); ?></h1><?php if ( $unavailable ) : ?><p class="an-vehicle-status" role="status"><?php echo esc_html(($data['availability']??'')==='sold'?__('Questa auto è stata venduta','autonec-child-theme'):__('Questa auto non è più disponibile','autonec-child-theme')); ?></p><?php elseif ( ! empty( $data['reserved'] ) ) : ?><p class="an-vehicle-status"><?php esc_html_e( 'Questa auto è riservata', 'autonec-child-theme' ); ?></p><?php endif; ?></div><?php if ( $price ) : ?><p class="an-vehicle-price"><?php echo esc_html( $price ); ?></p><?php endif; ?></header>
    <?php $specs = autonec_catalogue_specs( $data, true ); if ( $specs ) : ?><section aria-labelledby="an-vehicle-facts-title"><h2 id="an-vehicle-facts-title"><?php esc_html_e( 'I punti essenziali', 'autonec-child-theme' ); ?></h2><dl class="an-vehicle-specs"><?php foreach ( $specs as $label=>$value ) : ?><div><dt><?php echo esc_html( $label ); ?></dt><dd><?php echo esc_html( $value ); ?></dd></div><?php endforeach; ?></dl></section><?php endif; ?>
    <?php autonec_catalogue_contact_actions( $vehicle_id ); ?>
    <?php
    $vehicle_brands = wp_get_post_terms( $vehicle_id, 'an_marca', array( 'fields'=>'slugs' ) );
    $range_brands = is_wp_error( $vehicle_brands ) ? array() : array_values( array_intersect( $vehicle_brands, autonec_catalogue_main_brand_slugs() ) );
    $range_url = $range_brands ? autonec_gamma_page_url( $range_brands[0] ) : '';
    if ( $range_url ) : ?>
     <section class="an-vehicle-range" aria-labelledby="an-vehicle-range-title"><h2 id="an-vehicle-range-title"><?php esc_html_e( 'La gamma nuova del marchio', 'autonec-child-theme' ); ?></h2><p><?php esc_html_e( 'Esplora i modelli attuali del costruttore.', 'autonec-child-theme' ); ?></p><a class="an-link" href="<?php echo esc_url( $range_url ); ?>"><?php esc_html_e( 'Scopri la gamma nuova', 'autonec-child-theme' ); ?></a></section>
    <?php endif; ?>
   </div>
  </div>
  <?php $technical=array_diff_key(autonec_catalogue_specs($data),$specs);if($technical): ?>
  <section class="an-vehicle-technical" aria-labelledby="an-vehicle-technical-title"><h2 id="an-vehicle-technical-title"><?php esc_html_e('Caratteristiche','autonec-child-theme'); ?></h2><dl class="an-vehicle-technical__list"><?php foreach($technical as $label=>$value): ?><div><dt><?php echo esc_html($label); ?></dt><dd><?php echo esc_html($value); ?></dd></div><?php endforeach; ?></dl></section>
  <?php endif; ?>
  <?php if ( ! empty( $data['description'] ) || trim( get_the_content() ) ) : $copy=autonec_catalogue_description_sections($data['description']??'', $vehicle_id); ?>
   <section class="an-vehicle-description <?php echo $copy['features']?'has-equipment':''; ?>" aria-labelledby="an-vehicle-description-title">
    <div class="an-vehicle-description__intro">
     <h2 id="an-vehicle-description-title"><?php esc_html_e( 'Dotazioni e dettagli', 'autonec-child-theme' ); ?></h2>
     <?php if (trim(wp_strip_all_tags($copy['intro']))) : ?><div class="an-vehicle-description__prose"><?php echo $copy['intro']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- parsed strict allowlist. ?></div><?php endif; ?>
    </div>
    <?php if ($copy['features']) : ?><ul class="an-vehicle-equipment"><?php foreach($copy['features'] as $feature): ?><li><?php echo $feature; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- parsed strict allowlist. ?></li><?php endforeach; ?></ul><?php endif; ?>
    <?php if ( trim( get_the_content() ) ) : ?><div class="entry-content an-vehicle-editorial"><?php the_content(); ?></div><?php endif; ?>
   </section>
  <?php endif; ?>
 </article>
 <?php endwhile; ?>
</main>
<?php get_footer(); ?>
