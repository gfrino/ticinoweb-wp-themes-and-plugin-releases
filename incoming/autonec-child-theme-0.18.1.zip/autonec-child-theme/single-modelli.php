<?php
/** Official model family, without implied availability or national price. @package AutonecChildTheme */
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header(); ?>
<main id="main-content" class="an-model-page" tabindex="-1">
 <?php autonec_brand_navigation(); ?>
 <?php while ( have_posts() ) : the_post(); $model_id = get_the_ID(); $data = autonec_gamma_data( $model_id ); $brand = sanitize_title( (string) ( $data['brand_slug'] ?? '' ) ); ?>
 <article class="an-wrap an-model-detail">
  <a class="an-model-back" href="<?php echo esc_url( autonec_gamma_page_url( $brand ) ); ?>"><?php esc_html_e( 'Torna alla gamma', 'autonec-child-theme' ); ?></a>
  <div class="an-model-opening">
   <figure class="an-model-opening__photo<?php echo has_post_thumbnail() ? '' : ' an-model-opening__photo--text'; ?>"><?php if ( has_post_thumbnail() ) { the_post_thumbnail( 'full', array( 'loading'=>'eager', 'fetchpriority'=>'high', 'decoding'=>'async', 'sizes'=>'(max-width: 900px) 92vw, 59vw' ) ); } else { ?><p aria-hidden="true"><?php the_title(); ?></p><?php } ?></figure>
   <div class="an-model-opening__copy">
    <p class="an-model-range-label"><?php echo esc_html($data['status']==='archived'?__('Fuori gamma','autonec-child-theme'):__('Gamma nuova','autonec-child-theme')); ?></p>
    <h1><?php the_title(); ?></h1>
    <?php if ('archived'===($data['status']??'')):?><p class="an-model-status"><?php esc_html_e('Questo modello non compare più nella gamma ufficiale attuale. Contattaci per conoscere le alternative.','autonec-child-theme');?></p><?php endif;?>
    <?php if ( 'coming_soon' === ( $data['status'] ?? '' ) ) : ?><p class="an-model-status"><?php esc_html_e( 'In arrivo', 'autonec-child-theme' ); ?></p><?php endif; ?>
    <?php if ( has_excerpt() ) : ?><div class="an-model-lead"><?php the_excerpt(); ?></div><?php endif; ?>
    <?php $powertrains = array_filter( (array) ( $data['powertrains'] ?? array() ), 'is_scalar' ); if ( ! empty( $data['category'] ) || $powertrains ) : ?>
    <dl class="an-model-specs">
     <?php if ( ! empty( $data['category'] ) ) : ?><div><dt><?php esc_html_e( 'Tipo di veicolo', 'autonec-child-theme' ); ?></dt><dd><?php echo esc_html( autonec_gamma_category_label( $data['category'] ) ); ?></dd></div><?php endif; ?>
     <?php if ( $powertrains ) : ?><div><dt><?php esc_html_e( 'Alimentazioni nella gamma', 'autonec-child-theme' ); ?></dt><dd><?php echo esc_html( implode( ' / ', array_map( static function( $value ) { return autonec_gamma_label( $value, 'powertrain:' . sanitize_title( $value ) ); }, $powertrains ) ) ); ?></dd></div><?php endif; ?>
    </dl>
    <?php endif; ?>
    <?php if($data['status']!=='archived'):?><p class="an-model-availability-note"><?php esc_html_e( 'Questa scheda presenta il modello del costruttore. Versioni, tempi di consegna e possibilità di ordinazione sono da verificare con il nostro team.', 'autonec-child-theme' ); ?></p><?php endif;?>
    <?php autonec_catalogue_contact_actions( $model_id ); ?>
   </div>
  </div>
  <?php if ( autonec_gamma_copy_is_current($model_id) && trim( get_the_content() ) ) : ?><div class="an-model-content entry-content"><?php the_content(); ?></div><?php endif; ?>
  <?php autonec_gamma_model_stock( $model_id ); ?>
 </article>
 <?php endwhile; ?>
</main>
<?php get_footer(); ?>
