<?php
/**
 * Template Name: Catalogo Autonec
 * THESIS: actual local stock is immediately comparable; every car leads to its own page.
 * OWN-WORLD: established charcoal, Barlow, red hover and quiet open 16:10 photo cards.
 * STORY: narrow the stock, inspect the car, contact Autonec directly.
 * FIRST VIEWPORT: shared brand rail, native page title and introduction, labeled filters, stock.
 * FORM: approved catalogue specification, Operate mode; no new visual world or scroll staging.
 * @package AutonecChildTheme
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
$filters = autonec_catalogue_filters();
$vehicles = autonec_catalogue_query( autonec_catalogue_filter_query_args( $filters ) );
$vehicles = autonec_listing_resolve_page( $vehicles, $filters, static fn($values) => autonec_catalogue_query( autonec_catalogue_filter_query_args( $values ) ) );
update_post_thumbnail_cache( $vehicles );
autonec_listing_seo_context( $vehicles, $filters );
get_header(); ?>
<main id="main-content" class="an-catalogue-page" tabindex="-1">
 <?php autonec_brand_navigation(); ?>
 <div class="an-wrap">
  <?php while ( have_posts() ) : the_post(); ?>
  <header class="an-catalogue-heading"><h1><?php the_title(); ?></h1><?php if ( has_excerpt() ) : ?><div class="an-catalogue-heading__lead"><?php the_excerpt(); ?></div><?php endif; ?></header>
  <?php if ( trim( get_the_content() ) ) : ?><div class="an-catalogue-intro entry-content"><?php the_content(); ?></div><?php endif; ?>
  <?php endwhile; ?>
  <?php autonec_catalogue_condition_links( $filters ); ?>
  <?php autonec_catalogue_filter_form( $filters ); ?>
  <section class="an-catalogue-results" aria-labelledby="an-catalogue-results-title">
   <div class="an-catalogue-results__meta"><h2 id="an-catalogue-results-title" class="an-catalogue-count"><?php printf( esc_html( _n( '%s auto trovata', '%s auto trovate', (int) $vehicles->found_posts, 'autonec-child-theme' ) ), esc_html( number_format_i18n( $vehicles->found_posts ) ) ); ?></h2><?php $updated = autonec_catalogue_state()['last_success'] ?? 0; if ( $updated ) : ?><p class="an-catalogue-updated"><?php esc_html_e( 'Aggiornato', 'autonec-child-theme' ); ?> <time datetime="<?php echo esc_attr( gmdate('c', $updated) ); ?>"><?php echo esc_html( wp_date( get_option('date_format'), $updated ) ); ?></time></p><?php endif; ?></div>
   <?php if ( $vehicles->have_posts() ) : ?>
    <div class="an-catalogue-grid"><?php foreach ( $vehicles->posts as $index=>$vehicle ) { autonec_catalogue_card( $vehicle->ID, 0 === $index ); } ?></div>
   <?php else : ?>
    <div class="an-catalogue-empty">
     <?php if ( $filters['marca'] || $filters['modello'] || $filters['alimentazione'] || $filters['condizione'] || $filters['prezzo_max'] ) : ?>
      <h3><?php esc_html_e( 'Nessuna auto corrisponde alla ricerca', 'autonec-child-theme' ); ?></h3><p><?php esc_html_e( 'Prova a cambiare i filtri per esplorare le altre auto del catalogo.', 'autonec-child-theme' ); ?></p><a class="an-link" href="<?php echo esc_url( autonec_catalogue_page_url() ); ?>"><?php esc_html_e( 'Mostra tutto il catalogo', 'autonec-child-theme' ); ?></a>
     <?php else : ?>
      <h3><?php esc_html_e( 'Al momento non ci sono auto nel catalogo', 'autonec-child-theme' ); ?></h3>
      <?php if ( autonec_section_url( 'contact' ) ) : ?><a class="an-link" href="<?php echo esc_url( autonec_section_url( 'contact' ) ); ?>"><?php esc_html_e( 'Contattaci', 'autonec-child-theme' ); ?></a><?php endif; ?>
     <?php endif; ?>
    </div>
   <?php endif; ?>
  </section>
  <?php autonec_catalogue_pagination( $vehicles, $filters ); ?>
 </div>
</main>
<?php get_footer(); ?>
