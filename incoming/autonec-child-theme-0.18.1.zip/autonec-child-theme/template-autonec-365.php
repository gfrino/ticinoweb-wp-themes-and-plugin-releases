<?php
/** Template Name: Autonec 365
 * @package AutonecChildTheme */
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header(); ?>
<main id="main-content" class="an-365-page" tabindex="-1">
 <?php while ( have_posts() ) : the_post(); ob_start(); the_content(); $editorial = ob_get_clean(); ?>
 <article <?php post_class( 'an-365-editorial' ); ?>>
  <?php if ( ! preg_match( '/<h1\b/i', $editorial ) ) : ?><h1 class="an-wrap"><?php the_title(); ?></h1><?php endif; ?>
  <?php echo $editorial; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- native the_content output, rendered once. ?>
 </article>
 <?php endwhile; ?>
</main>
<?php get_footer(); ?>
