/* Shared geometry keeps direct links and the scroll scene on the same scale. */
var AutonecJourney=Object.freeze({
 progress:(y,start,distance)=>Math.min(1,Math.max(0,(y-start)/Math.max(1,distance))),
 offset:(index,count,start,distance)=>start+Math.min(Math.max(0,index),Math.max(0,count-1))/Math.max(1,count-1)*Math.max(0,distance)
});
