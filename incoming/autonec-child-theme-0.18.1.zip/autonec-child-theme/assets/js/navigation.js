(() => {
 'use strict';
 document.documentElement.classList.add('an-js');
 const toggle=document.querySelector('.an-menu-toggle'),nav=document.querySelector('#an-navigation');
 if(!toggle||!nav)return;
 toggle.hidden=false;
 const desktop=matchMedia('(min-width: 900px)'),hover=matchMedia('(hover: hover) and (pointer: fine)');
 const reducedMotion=matchMedia('(prefers-reduced-motion: reduce)');
 const disclosures=[...nav.querySelectorAll('.an-catalogue-toggle')].map(button=>({button,panel:document.getElementById(button.getAttribute('aria-controls')),item:button.closest('li'),timer:0,motion:null,open:false})).filter(entry=>entry.panel&&entry.item);
 // Reveal the directory from its header edge. Read current frames before interruption.
 const reveal=(entry,opening,immediate=false)=>{
  const panel=entry.panel,wasHidden=panel.hidden;
  const running=entry.motion;
  const current=!wasHidden?getComputedStyle(panel):null;
  const fromClip=running&&current?current.clipPath:(opening?'inset(0px 0px 100% 0px)':'inset(0px 0px 0% 0px)');
  const fromOpacity=running&&current?current.opacity:(opening ? 0.84 : 1);
  const fromHeight=wasHidden?0:panel.getBoundingClientRect().height;
  const boxProperties=['paddingTop','paddingBottom','marginBottom','borderTopWidth','borderBottomWidth'];
  const fromBox=Object.fromEntries(boxProperties.map(key=>[key,current?current[key]:'0px']));
  if(running){running.cancel();entry.motion=null;}
  entry.open=opening;
  panel.inert=!opening;
  panel.style.overflow='';
  if(immediate||reducedMotion.matches||!panel.animate){panel.hidden=!opening;return;}
  if(wasHidden&&!opening)return;
  panel.hidden=false;
  const mobile=!desktop.matches;
  const naturalHeight=panel.getBoundingClientRect().height;
  const first={clipPath:fromClip,opacity:fromOpacity};
  const last={clipPath:opening?'inset(0px 0px 0% 0px)':'inset(0px 0px 100% 0px)',opacity:opening?1:.84};
  // A nested mobile directory also expands its occupied space, without leaving a gap.
  if(mobile){
   first.height=(opening?fromHeight:fromHeight||naturalHeight)+'px';last.height=(opening?naturalHeight:0)+'px';
   const natural=getComputedStyle(panel);
   boxProperties.forEach(key=>{first[key]=running?fromBox[key]:(opening?'0px':natural[key]);last[key]=opening?natural[key]:'0px';});
   panel.style.overflow='hidden';
  }
  const animation=panel.animate([first,last],{duration:opening?420:220,easing:opening?'cubic-bezier(.16,1,.3,1)':'cubic-bezier(.4,0,1,1)',fill:'both'});
  entry.motion=animation;
  animation.onfinish=()=>{if(entry.motion!==animation)return;if(!entry.open)panel.hidden=true;panel.style.overflow='';entry.motion=null;animation.cancel();};
 };
 const closeDisclosure=(entry,focus=false,immediate=false)=>{
  clearTimeout(entry.timer);
  if(focus)entry.button.focus();
  entry.button.setAttribute('aria-expanded','false');entry.item.classList.remove('is-catalogue-open');
  if(entry.open||immediate)reveal(entry,false,immediate);
 };
 const closeDisclosures=(immediate=false)=>disclosures.forEach(entry=>closeDisclosure(entry,false,immediate));
 const openDisclosure=entry=>{
  disclosures.forEach(other=>{if(other!==entry)closeDisclosure(other);});clearTimeout(entry.timer);
  if(entry.open)return;
  entry.button.setAttribute('aria-expanded','true');entry.item.classList.add('is-catalogue-open');reveal(entry,true);
 };
 const close=(focus=false,immediate=false)=>{closeDisclosures(immediate||!desktop.matches);toggle.setAttribute('aria-expanded','false');document.body.classList.remove('an-menu-open');if(focus)toggle.focus();};
 disclosures.forEach(entry=>{
  entry.button.hidden=false;
  closeDisclosure(entry,false,true);
  entry.panel.setAttribute('data-an-ready','');
  entry.button.addEventListener('click',()=>{if(entry.button.getAttribute('aria-expanded')==='true')closeDisclosure(entry);else openDisclosure(entry);});
  entry.button.addEventListener('keydown',event=>{if(event.key==='ArrowDown'){event.preventDefault();openDisclosure(entry);entry.panel.querySelector('a')?.focus();}});
  entry.item.addEventListener('pointerenter',()=>{if(desktop.matches&&hover.matches){clearTimeout(entry.timer);entry.timer=setTimeout(()=>openDisclosure(entry),100);}});
  entry.item.addEventListener('pointerleave',()=>{if(desktop.matches&&hover.matches){clearTimeout(entry.timer);entry.timer=setTimeout(()=>{if(!entry.item.contains(document.activeElement))closeDisclosure(entry);},180);}});
  entry.item.addEventListener('focusout',()=>{setTimeout(()=>{if(!entry.item.contains(document.activeElement))closeDisclosure(entry);},0);});
 });
 toggle.addEventListener('click',()=>{const open=toggle.getAttribute('aria-expanded')!=='true';if(open){toggle.setAttribute('aria-expanded','true');document.body.classList.add('an-menu-open');}else close();});
 nav.addEventListener('click',event=>{if(event.target.closest('a'))close();});
 document.addEventListener('keydown',event=>{
  if(event.key!=='Escape')return;
  const opened=disclosures.find(entry=>entry.button.getAttribute('aria-expanded')==='true');
  if(opened){event.preventDefault();closeDisclosure(opened,true);return;}
  if(document.body.classList.contains('an-menu-open'))close(true);
 });
 document.addEventListener('click',event=>{if(!event.target.closest('.an-header'))close();else disclosures.forEach(entry=>{if(!entry.item.contains(event.target))closeDisclosure(entry);});});
 document.addEventListener('focusin',event=>{if(!event.target.closest('.an-header'))close();});
 desktop.addEventListener('change',()=>close(false,true));
 reducedMotion.addEventListener('change',()=>{if(reducedMotion.matches)disclosures.forEach(entry=>{if(entry.motion)entry.motion.finish();});});
 document.documentElement.setAttribute('data-an-navigation-ready','');
})();
