/** A rising history sheet and a scroll-linked date reel, reading the native CMS chronology. */
(() => {
 'use strict';
 const page=document.querySelector('.an-company-page'),intro=page?.querySelector('.an-company-intro'),chapters=page?.querySelector('.an-company-chapters'),history=page?.querySelector('.an-company-history'),heading=history?.querySelector('.an-company-history-heading'),timeline=history?.querySelector('.an-company-timeline'),header=document.querySelector('.an-header');
 if(!page||!intro||!chapters)return;
 const reduced=matchMedia('(prefers-reduced-motion: reduce)'),wide=matchMedia('(min-width: 1000px)'),fine=matchMedia('(pointer: fine)'),connection=navigator.connection,moments=[...page.querySelectorAll('.an-company-moment')];
 const dates=moments.map(item=>item.querySelector('.an-company-year')?.textContent.trim()||'');
 const clamp=(value,min=0,max=1)=>Math.max(min,Math.min(max,value));
 const letteringMeasure=document.createElement('canvas').getContext('2d');
 let frame=null,coverEnabled=false,historyEnabled=false,top=0,reel=null,reelWindow=null,progress=null,years=[];
 // Decoration only: no cloned headings, IDs, editable fields or second source of historical data.
 if(heading&&timeline&&dates.length>1&&dates.every(date=>date.length>0&&date.length<=8)){
  reel=document.createElement('div');reel.className='an-company-history-reel';reel.setAttribute('aria-hidden','true');
  reelWindow=document.createElement('div');reelWindow.className='an-company-history-reel__window';
  years=dates.map((date,index)=>{const year=document.createElement('span');year.className='an-company-history-reel__year';year.textContent=date;year.dataset.year=date;year.style.transform=`translate3d(0,${index*112}%,0)`;reelWindow.append(year);return year;});
  progress=document.createElement('span');progress.className='an-company-history-reel__progress';reel.append(reelWindow,progress);heading.append(reel);
 }
 function request(){if(frame===null&&!document.hidden)frame=requestAnimationFrame(paint);}
 function measure(){
  top=(header?.offsetHeight||0)+(parseFloat(header?getComputedStyle(header).top:0)||0)+24;
  const motion=wide.matches&&fine.matches&&!reduced.matches&&!connection?.saveData;
  coverEnabled=motion&&intro.offsetHeight<innerHeight-top-32;
  page.classList.toggle('an-company-page--cinema',coverEnabled);
  page.style.setProperty('--an-company-top',`${top}px`);
  page.style.setProperty('--an-company-history-top',`${top+22}px`);
  historyEnabled=false;
  if(motion&&reel){
   // Measure the original copy independently of the decorative reel, avoiding resize oscillation.
   const copy=[...heading.children].filter(child=>child!==reel).map(child=>child.getBoundingClientRect());
   const copyHeight=copy.length?Math.max(...copy.map(rect=>rect.bottom))-Math.min(...copy.map(rect=>rect.top)):0;
   const type=getComputedStyle(reelWindow),reelHeight=parseFloat(type.fontSize)*.92+40;
   if(letteringMeasure)letteringMeasure.font=`${type.fontWeight} ${type.fontSize} ${type.fontFamily}`;
   const datesFit=letteringMeasure&&dates.every(date=>letteringMeasure.measureText(date).width<=heading.clientWidth-4);
   historyEnabled=!!datesFit&&copyHeight+reelHeight<innerHeight-top-48&&timeline.offsetHeight>copyHeight+reelHeight+60;
  }
  history?.classList.toggle('an-company-history--immersive',historyEnabled);
  if(!coverEnabled)intro.style.removeProperty('--an-company-scale');
  if(!historyEnabled)moments.forEach(item=>item.classList.remove('is-current'));
  window.AutonecScroll?.resize();request();
 }
 function paint(){
  frame=null;
  if(coverEnabled){const edge=chapters.getBoundingClientRect().top,p=clamp((innerHeight-edge)/(innerHeight-top));intro.style.setProperty('--an-company-scale',String(1-.035*p));}
  if(!historyEnabled)return;
  const bounds=history.getBoundingClientRect();if(bounds.top>=innerHeight||bounds.bottom<=top)return;
  // Read the four row positions once, before writing any visual state.
  const centres=moments.map(item=>{const rect=item.getBoundingClientRect();return rect.top+rect.height/2;});
  const readingLine=top+(innerHeight-top)*.48;
  let position=0;
  if(readingLine>=centres[centres.length-1])position=centres.length-1;
  else for(let i=0;i<centres.length-1;i++)if(readingLine>=centres[i])position=i+clamp((readingLine-centres[i])/Math.max(1,centres[i+1]-centres[i]));
  const current=Math.round(position);
  moments.forEach((item,index)=>{
   const focus=1-clamp(Math.abs(index-position));
   item.classList.toggle('is-current',index===current);
   const offset=index-current;
   years[index].style.transform=`translate3d(0,${(offset*112).toFixed(3)}%,0) rotateX(${clamp(offset*16,-20,20).toFixed(2)}deg)`;
   years[index].style.opacity=String(1-clamp(Math.abs(offset)*.35,0,.65));
   years[index].style.setProperty('--an-reel-fill',`${(focus*100).toFixed(3)}%`);
  });
  progress.style.transform=`scaleX(${(position/(moments.length-1)).toFixed(4)})`;
 }
 window.addEventListener('scroll',request,{passive:true});window.addEventListener('resize',measure,{passive:true});
 window.addEventListener('pageshow',measure);window.addEventListener('load',measure);window.addEventListener('an:scroll-ready',measure);
 [reduced,wide,fine].forEach(query=>query.addEventListener('change',measure));connection?.addEventListener?.('change',measure);
 document.fonts?.ready.then(measure);
 if('ResizeObserver'in window){const observer=new ResizeObserver(measure);observer.observe(intro);if(heading)observer.observe(heading);if(timeline)observer.observe(timeline);}
 document.addEventListener('visibilitychange',()=>{if(document.hidden){if(frame!==null)cancelAnimationFrame(frame);frame=null;}else request();});
 measure();
})();
