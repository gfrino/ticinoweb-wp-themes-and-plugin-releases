/** Native model editor: only the chosen marque can submit stock-family checkboxes. */
(() => {
 'use strict';
 const brand = document.getElementById('an-model-brand');
 const families = document.querySelector('[data-an-gamma-families]');
 if (!brand || !families) return;
 const groups = [...families.querySelectorAll('[data-an-gamma-family-group]')];
 const prompt = families.querySelector('[data-an-gamma-family-prompt]');
 const update = (clearOtherSelections) => {
  const selected = brand.value;
  groups.forEach((group) => {
   const active = Boolean(selected && group.dataset.anGammaFamilyGroup === selected);
   group.hidden = !active;
   group.disabled = !active;
   group.querySelectorAll('input[type="checkbox"]').forEach((checkbox) => {
    checkbox.disabled = !active;
    if (!active && clearOtherSelections) checkbox.checked = false;
   });
  });
  if (prompt) prompt.hidden = Boolean(selected);
 };
 brand.addEventListener('change', () => update(true));
 update(false);
})();
