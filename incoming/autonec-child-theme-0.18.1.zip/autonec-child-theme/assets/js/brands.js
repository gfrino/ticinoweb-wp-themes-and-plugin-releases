(() => {
 'use strict';
 const root=document.documentElement,header=document.querySelector('.an-header'),rail=document.querySelector('.an-marque-nav'),cover=document.querySelector('.an-brand-cover'),caption=cover?.querySelector('.wp-block-cover__inner-container'),primary=cover?.querySelector('.wp-block-cover__image-background'),intro=document.querySelector('.an-brand-intro');
 const chapters=[...document.querySelectorAll('.an-brand-chapter')],reduced=matchMedia('(prefers-reduced-motion: reduce)'),wide=matchMedia('(min-width: 1000px)'),connection=navigator.connection,saveData=()=>!!connection?.saveData;
 const alternateSource=intro?.querySelector('.an-brand-intro__photo img');
 let lenis=null,raf=null,dirty=true,offset=164,opening=null,openingStart=0,openingRange=1,introMarker=null;
 const clamp=v=>Math.min(1,Math.max(0,v)),phase=(p,a,b)=>clamp((p-a)/(b-a));
 function request(){dirty=true;if(raf===null&&!document.hidden)raf=requestAnimationFrame(tick);}
 function restoreOpening(){
  if(!opening)return;
  const {scene,copy,visual,alternate}=opening;
  alternate.onload=null;
  scene.replaceWith(cover);
  cover.insertBefore(primary,copy);cover.insertBefore(caption,copy);
  if(introMarker?.isConnected)introMarker.after(intro);else cover.after(intro);
  copy.remove();visual.remove();
  [caption,intro].forEach(el=>{el.style.transform='';el.style.opacity='';el.style.clipPath='';el.inert=false;});
  opening=null;
 }
 function buildOpening(){
  if(opening||!cover||!caption||!primary||!intro)return;
  if(!introMarker){introMarker=document.createComment('Native brand introduction');intro.before(introMarker);}
  const scene=document.createElement('div'),copy=document.createElement('div'),visual=document.createElement('div'),alternate=document.createElement('img');
  scene.className='an-brand-opening an-brand-opening--active';scene.dataset.brandOpening='';
  copy.className='an-brand-opening__copy';visual.className='an-brand-opening__visual';alternate.className='an-brand-opening__alternate';alternate.alt='';alternate.setAttribute('aria-hidden','true');alternate.decoding='async';
  cover.before(scene);scene.append(cover);cover.insertBefore(copy,caption);copy.append(caption,intro);cover.append(visual);visual.append(primary,alternate);
  intro.style.opacity='0';intro.inert=true;
  opening={scene,copy,visual,alternate,ready:false,requested:false};
 }
 function measureOpening(motion){
  if(!motion||innerWidth<1200||innerHeight<800||!cover||!caption||!primary||!intro){restoreOpening();return;}
  buildOpening();if(!opening)return;
  const top=offset-12,height=innerHeight-top;
  opening.scene.style.setProperty('--an-opening-top',`${top}px`);opening.scene.style.setProperty('--an-opening-height',`${height}px`);
  const padding=parseFloat(getComputedStyle(opening.copy).paddingTop)+parseFloat(getComputedStyle(opening.copy).paddingBottom);
  const room=height-padding;
  if(Math.max(caption.scrollHeight,intro.scrollHeight)>room-8){restoreOpening();return;}
  const range=Math.min(900,Math.max(560,height*.95));
  opening.scene.style.setProperty('--an-opening-range',`${range}px`);
  opening.scene.style.height=`${height*2+range}px`;
  openingStart=opening.scene.getBoundingClientRect().top+scrollY-top;openingRange=range;
 }
 function measure(){
  offset=(header?.offsetHeight||0)+(rail?.offsetHeight||0)+parseFloat(header?getComputedStyle(header).top||0:0)+12;
  const motion=!reduced.matches&&!saveData();
  measureOpening(motion);
  root.classList.remove('an-brand-motion');
  chapters.forEach(el=>{el.style.transform='';el.style.opacity='';});
  lenis=window.AutonecScroll?.instance||null;
  lenis?.resize();request();
 }
 function requestAlternate(){
  if(!opening||opening.requested||!alternateSource)return;
  const state=opening;state.requested=true;
  state.alternate.onload=()=>{if(opening===state){state.ready=true;request();}};
  state.alternate.style.objectPosition=getComputedStyle(alternateSource).objectPosition;
  const sizes=alternateSource.getAttribute('sizes'),srcset=alternateSource.getAttribute('srcset');
  if(sizes)state.alternate.sizes=sizes;if(srcset)state.alternate.srcset=srcset;
  state.alternate.src=alternateSource.getAttribute('src');
 }
 function paint(){
  if(opening){
   const p=clamp((scrollY-openingStart)/openingRange),exit=phase(p,0,.28),enter=phase(p,.34,.72),wipe=phase(p,.18,.88);
   caption.style.opacity=String(1-exit);caption.style.transform=`translate3d(0,${-exit*55}px,0)`;caption.inert=exit>.98;
   intro.style.opacity=String(enter);intro.style.transform=`translate3d(0,${(1-enter)*45}px,0)`;intro.style.clipPath=`inset(0 0 ${(1-enter)*100}% 0)`;intro.inert=enter<.02;
   if(p>.08)requestAlternate();
   opening.alternate.style.clipPath=`inset(${(1-wipe)*100}% 0 0)`;opening.alternate.style.opacity=opening.ready?'1':'0';
  }
 }
 function tick(){raf=null;if(document.hidden)return;if(dirty){paint();dirty=false;}}
 window.addEventListener('scroll',request,{passive:true});window.addEventListener('resize',measure,{passive:true});window.addEventListener('load',measure);window.addEventListener('pageshow',measure);reduced.addEventListener('change',measure);wide.addEventListener('change',measure);document.fonts?.ready.then(measure);
 if('ResizeObserver'in window){const observer=new ResizeObserver(measure);chapters.forEach(el=>observer.observe(el));}
 window.addEventListener('an:scroll-ready',measure);connection?.addEventListener?.('change',measure);
 document.addEventListener('visibilitychange',()=>{if(document.hidden){if(raf!==null)cancelAnimationFrame(raf);raf=null;}else request();});
 measure();
})();
