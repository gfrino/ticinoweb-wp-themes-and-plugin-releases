(() => {
 'use strict';
 const root=document.documentElement,arrival=document.querySelector('.an-365-arrival'),copy=arrival?.querySelector('.an-365-arrival__copy'),film=arrival?.querySelector('.an-365-film'),video=film?.querySelector('video'),header=document.querySelector('.an-header'),audioButton=film?.querySelector('[data-sound-toggle]');
 const reduced=matchMedia('(prefers-reduced-motion: reduce)'),wide=matchMedia('(min-width: 1101px)'),connection=navigator.connection;
 let stage=null,lenis=null,raf=null,dirty=true,start=0,range=420,filmTop=300,initialWidth=960,finalWidth=1280,finalTop=0,inView=false,playRequest=0,soundEnabled=false,manualPlayback=false;
 const clamp=n=>Math.min(1,Math.max(0,n)),motion=()=>!reduced.matches&&!connection?.saveData;
 function request(){dirty=true;if(raf===null&&!document.hidden)raf=requestAnimationFrame(tick);}
 function restore(){if(stage){stage.replaceWith(...stage.childNodes);stage=null;}root.classList.remove('an-365-cinema');if(copy)copy.inert=false;}
 function measure(){
  const top=(header?.offsetHeight||80)+parseFloat(header?getComputedStyle(header).top||0:0),height=innerHeight-top;
  if(arrival&&copy&&film&&motion()&&wide.matches&&height>=560){
   if(!stage){stage=document.createElement('div');stage.className='an-365-arrival__stage';arrival.append(stage);stage.append(copy,film);}
   root.classList.add('an-365-cinema');arrival.style.setProperty('--an-365-top',`${top}px`);arrival.style.setProperty('--an-365-height',`${height}px`);arrival.style.setProperty('--an-365-range',`${range}px`);
   filmTop=52+copy.offsetHeight;
   const gutter=parseFloat(getComputedStyle(stage).paddingLeft),aspect=16/9;
   const audioRoom=audioButton&&!audioButton.hidden?66:0;
   initialWidth=Math.min(stage.clientWidth-gutter*2,(height-filmTop-audioRoom)*aspect,1440);
   finalWidth=Math.min(stage.clientWidth-48,(height-32-audioRoom)*aspect,1440);finalTop=(height-finalWidth/aspect-audioRoom)/2;
   start=arrival.getBoundingClientRect().top+scrollY-top;
   if(filmTop>height*.6)restore();
  }else restore();
  lenis=window.AutonecScroll?.instance||null;
  lenis?.resize();updateVideo();request();
 }
 function updateVideo(){
  if(!video)return;
  const token=++playRequest;
  if((!motion()&&!manualPlayback)||!inView||document.hidden){video.pause();film.classList.remove('is-playing');return;}
  if(!video.src){video.src=video.dataset.src;video.load();}
  video.muted=!soundEnabled;
  const promise=video.play();if(promise)promise.then(()=>{if(token===playRequest&&(motion()||manualPlayback)&&inView&&!document.hidden)film.classList.add('is-playing');}).catch(()=>{if(token!==playRequest)return;film.classList.remove('is-playing');soundEnabled=false;video.muted=true;syncSound();});
 }
 function paint(){if(!stage)return;const p=clamp((scrollY-start)/range),ease=1-(1-p)**3;
  const width=initialWidth+(finalWidth-initialWidth)*ease;
  arrival.style.setProperty('--an-365-film-top',`${filmTop+(finalTop-filmTop)*ease}px`);arrival.style.setProperty('--an-365-film-width',`${width}px`);arrival.style.setProperty('--an-365-film-height',`${width*9/16}px`);arrival.style.setProperty('--an-365-copy-y',`${-p*100}px`);arrival.style.setProperty('--an-365-copy-opacity',String(1-clamp(p*1.7)));copy.inert=p>.59;
 }
 function tick(){raf=null;if(document.hidden)return;if(dirty){paint();dirty=false;}}
 function syncSound(){if(!audioButton)return;audioButton.setAttribute('aria-pressed',String(soundEnabled));audioButton.querySelector('span').textContent=soundEnabled?audioButton.dataset.labelOn:audioButton.dataset.labelOff;}
 if(video&&audioButton){audioButton.hidden=false;audioButton.addEventListener('click',()=>{soundEnabled=!soundEnabled;manualPlayback=true;film.classList.add('is-user-playing');syncSound();updateVideo();});syncSound();}
 video?.addEventListener('error',()=>{++playRequest;video.pause();film.classList.remove('is-playing','is-user-playing','has-audio');soundEnabled=false;if(audioButton)audioButton.hidden=true;syncSound();measure();});
 if(film&&'IntersectionObserver'in window)new IntersectionObserver(entries=>{inView=entries[0].isIntersecting;updateVideo();},{threshold:.05}).observe(film);else{inView=true;updateVideo();}
 document.addEventListener('visibilitychange',()=>{if(document.hidden){if(raf!==null)cancelAnimationFrame(raf);raf=null;}else request();updateVideo();});
 document.addEventListener('click',event=>{const link=event.target.closest('a[href^="#"]');if(event.defaultPrevented||!link||!lenis||event.metaKey||event.ctrlKey||event.shiftKey||event.altKey)return;const target=document.getElementById(link.hash.slice(1));if(!target)return;event.preventDefault();lenis.scrollTo(target,{onComplete:()=>{history.replaceState(null,'',link.hash);target.setAttribute('tabindex','-1');target.focus({preventScroll:true});}});});
 window.addEventListener('an:scroll-ready',measure);
 window.addEventListener('scroll',request,{passive:true});window.addEventListener('resize',measure,{passive:true});window.addEventListener('pageshow',measure);window.addEventListener('load',measure);reduced.addEventListener('change',measure);wide.addEventListener('change',measure);connection?.addEventListener?.('change',measure);document.fonts?.ready.then(measure);measure();
})();
