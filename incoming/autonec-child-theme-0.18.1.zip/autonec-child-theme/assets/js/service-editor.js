(() => {
 'use strict';
 function start(){
  const section=document.getElementById('services'),container=document.getElementById('services-container');
  if(!section||!container||!window.wp?.editor?.initialize)return;
  let count=0,queued=false;
  function initialize(){
   queued=false;if(!section.getClientRects().length)return;
   section.querySelectorAll('textarea[name^="ticinoweb_services"][name$="[description]"]').forEach(input=>{
    if(input.dataset.autonecEditor||!input.getClientRects().length)return;
    input.dataset.autonecEditor='ready';if(!input.id)input.id=`autonec-service-description-${++count}`;
    try{wp.editor.initialize(input.id,{tinymce:{toolbar1:'bold,italic,bullist,numlist,link,unlink,undo,redo',toolbar2:'',height:220,setup:editor=>editor.on('change input keyup undo redo',()=>editor.save())},quicktags:true});}
    catch{delete input.dataset.autonecEditor;}
   });
  }
  function request(){if(!queued){queued=true;requestAnimationFrame(initialize);}}
  new MutationObserver(request).observe(section,{attributes:true,attributeFilter:['class','style']});
  new MutationObserver(records=>{records.forEach(record=>record.removedNodes.forEach(node=>{if(node.nodeType!==1)return;const fields=node.matches?.('textarea[data-autonec-editor]')?[node]:[...node.querySelectorAll('textarea[data-autonec-editor]')];fields.forEach(input=>{if(!input.isConnected){try{wp.editor.remove(input.id);}catch{}}});}));request();}).observe(container,{childList:true,subtree:true,attributes:true,attributeFilter:['class','style']});
  window.addEventListener('hashchange',request);
  section.closest('form')?.addEventListener('submit',()=>window.tinymce?.triggerSave(),true);
  request();
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start,{once:true});else start();
})();
