(() => {
 'use strict';
 const page=document.querySelector('.an-contact-page'),summary=page?.querySelector('.an-contact-page__summary'),header=document.querySelector('.an-header');
 if(!page||!summary)return;
 const reduced=matchMedia('(prefers-reduced-motion:reduce)'),wide=matchMedia('(min-width:1101px)'),connection=navigator.connection;
 function measure(){
  const motion=!reduced.matches&&!connection?.saveData,top=(header?.offsetHeight||80)+parseFloat(header?getComputedStyle(header).top||0:0)+42;
  page.style.setProperty('--an-contact-top',`${top}px`);
  page.classList.toggle('an-contact-sticky',!!(motion&&wide.matches&&summary.offsetHeight+top+30<innerHeight));
  window.AutonecScroll?.resize();
 }
 window.addEventListener('an:scroll-ready',measure);
 if('ResizeObserver'in window)new ResizeObserver(measure).observe(summary);
 window.addEventListener('resize',measure,{passive:true});window.addEventListener('pageshow',measure);window.addEventListener('load',measure);reduced.addEventListener('change',measure);wide.addEventListener('change',measure);connection?.addEventListener?.('change',measure);document.fonts?.ready.then(measure);
 measure();
})();
