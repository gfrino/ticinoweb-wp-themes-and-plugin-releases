/* global jQuery, wp, AutonecVehicleEditor */
(() => {
 'use strict';
 const root = document.querySelector('.an-vehicle-editor');
 if (!root) return;
 const labels = AutonecVehicleEditor;
 const gallery = root.querySelector('[data-vehicle-gallery]');
 const value = root.querySelector('[data-gallery-value]');
 const ids = () => [...gallery.children].map(item => Number(item.dataset.photoId));
 const announce = () => {
  value.value = ids().join(',');
  root.querySelector('[data-gallery-status]').textContent = labels.count.replace('%d', gallery.children.length);
  gallery.querySelectorAll('[data-photo-back]').forEach((button, index) => { button.disabled = index === 0; });
  gallery.querySelectorAll('[data-photo-next]').forEach((button, index) => { button.disabled = index === gallery.children.length - 1; });
 };
 const markLocal = element => {
  const section = element.closest('[data-editor-field]');
  const state = section && section.querySelector('[data-origin-label]');
  if (state) state.textContent = labels.changed;
  if (section) section.classList.add('is-local');
 };
 gallery.addEventListener('click', event => {
  const button = event.target.closest('button');
  const item = button && button.closest('[data-photo-id]');
  if (!item) return;
  if (button.hasAttribute('data-photo-remove')) {
   const next = item.nextElementSibling || item.previousElementSibling;
   item.remove();
   if (next) next.querySelector('button:not(:disabled)')?.focus();
   else root.querySelector('[data-add-photos]').focus();
  }
  if (button.hasAttribute('data-photo-back') && item.previousElementSibling) gallery.insertBefore(item, item.previousElementSibling);
  if (button.hasAttribute('data-photo-next') && item.nextElementSibling) gallery.insertBefore(item.nextElementSibling, item);
  markLocal(gallery); announce();
 });
 jQuery(gallery).sortable({ items: '> li', cancel: 'button', tolerance: 'pointer', update: () => { markLocal(gallery); announce(); } });
 const createPhoto = photo => {
  const item = document.createElement('li');
  item.dataset.photoId = photo.id;
  const picture = document.createElement('div'); picture.className = 'an-editor-photo';
  const img = document.createElement('img'); img.src = photo.sizes?.thumbnail?.url || photo.url; img.alt = photo.alt || ''; picture.append(img);
  const actions = document.createElement('div'); actions.className = 'an-editor-photo-actions';
  [['back', '‹'], ['next', '›'], ['remove', labels.remove]].forEach(([action, text]) => {
   const button = document.createElement('button'); button.type = 'button'; button.textContent = text;
   button.className = action === 'remove' ? 'button-link-delete' : 'button';
   button.dataset[`photo${action[0].toUpperCase()}${action.slice(1)}`] = '';
   button.setAttribute('aria-label', labels[action]); actions.append(button);
  });
  item.append(picture, actions); return item;
 };
 let picker;
 root.querySelector('[data-add-photos]').addEventListener('click', () => {
  if (!picker) {
   picker = wp.media({ title: labels.title, button: { text: labels.select }, library: { type: 'image' }, multiple: true });
   picker.on('select', () => {
    const existing = new Set(ids());
    picker.state().get('selection').each(attachment => {
     const photo = attachment.toJSON();
     if (!existing.has(photo.id) && gallery.children.length < 60) { gallery.append(createPhoto(photo)); existing.add(photo.id); }
    });
    markLocal(gallery); announce();
   });
  }
  picker.open();
 });
 root.addEventListener('input', event => {
  if (event.target.matches('[data-restore-source], [type="hidden"]')) return;
  markLocal(event.target);
 });
 root.addEventListener('change', event => {
  if (!event.target.matches('[data-restore-source]')) return;
  const field = event.target.closest('[data-editor-field]');
  field.classList.toggle('will-restore', event.target.checked);
  field.querySelector('[data-origin-label]').textContent = event.target.checked ? labels.reset : labels.changed;
  field.querySelectorAll('[name^="an_vehicle_fields["]').forEach(input => { input.disabled = event.target.checked; });
 });
 announce();
})();
