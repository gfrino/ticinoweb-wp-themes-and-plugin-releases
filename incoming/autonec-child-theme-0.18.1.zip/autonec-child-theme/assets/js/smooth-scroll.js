(() => {
 'use strict';
 // Every page consumes this owner; page controllers only render their own scenes.
 if(window.AutonecScroll)return;
 const reduced=matchMedia('(prefers-reduced-motion: reduce)'),desktop=matchMedia('(min-width: 1000px)'),fine=matchMedia('(pointer: fine)'),connection=navigator.connection;
 let instance=null,raf=null,suspended=false;
 const nativeOnly=()=>reduced.matches||!!connection?.saveData;
 const paused=()=>suspended||document.hidden||document.body.classList.contains('an-menu-open');
 function cancelFrame(){if(raf!==null)cancelAnimationFrame(raf);raf=null;}
 function tick(time){raf=null;if(!instance||paused())return;instance.raf(time);raf=requestAnimationFrame(tick);}
 function syncPlayback(){
  if(!instance){cancelFrame();return;}
  if(paused()){instance.stop();cancelFrame();}
  else{instance.start();if(raf===null)raf=requestAnimationFrame(tick);}
 }
 function resize(){instance?.resize();}
 function scrollTo(top,options={}){
  if(!Number.isFinite(top))return false;
  if(instance){resize();instance.scrollTo(top,options);}
  else{window.scrollTo({top,behavior:options.immediate||nativeOnly()?'instant':'smooth'});options.onComplete?.();}
  return true;
 }
 function reconcile(){
  const smooth=!suspended&&!nativeOnly()&&desktop.matches&&fine.matches&&typeof window.Lenis==='function';
  let changed=false;
  if(!smooth&&instance){cancelFrame();instance.destroy();instance=null;changed=true;}
  if(smooth&&!instance){
   instance=new window.Lenis({lerp:.1,smoothWheel:true,syncTouch:false,autoRaf:false,
    prevent:node=>!!node.closest?.('[data-lenis-prevent],.an-navigation,input,textarea,select,[contenteditable="true"]')});
   changed=true;
  }
  resize();syncPlayback();
  if(changed)window.dispatchEvent(new CustomEvent('an:scroll-ready',{detail:{instance}}));
 }
 window.AutonecScroll=Object.freeze({get instance(){return instance;},resize,scrollTo});
 window.addEventListener('an:scroll-to',event=>{
  if(event.defaultPrevented||!instance||!Number.isFinite(event.detail?.top))return;
  scrollTo(event.detail.top,{immediate:!!event.detail.immediate});event.preventDefault();
 });
 // Let native keyboard scrolling take over from any in-flight wheel animation.
 document.addEventListener('keydown',event=>{
  if(!instance||event.defaultPrevented||event.ctrlKey||event.metaKey||event.altKey||paused())return;
  if(!['ArrowUp','ArrowDown','PageUp','PageDown','Home','End',' '].includes(event.key))return;
  if(event.target.closest?.('input,textarea,select,button,[contenteditable="true"],[data-lenis-prevent],.an-navigation'))return;
  instance.scrollTo(window.scrollY,{immediate:true});
 });
 // The shared skip link moves focus immediately, including during wheel inertia.
 document.addEventListener('click',event=>{
  if(event.defaultPrevented||event.button!==0||event.ctrlKey||event.metaKey||event.shiftKey||event.altKey)return;
  const link=event.target.closest?.('a.an-skip[href^="#"]');if(!link)return;
  let id;try{id=decodeURIComponent(link.hash.slice(1));}catch{return;}
  const target=document.getElementById(id);if(!target)return;
  const padding=parseFloat(getComputedStyle(document.documentElement).scrollPaddingTop)||0,margin=parseFloat(getComputedStyle(target).scrollMarginTop)||0;
  event.preventDefault();scrollTo(target.getBoundingClientRect().top+window.scrollY-padding-margin,{immediate:true});
  if(!target.hasAttribute('tabindex'))target.tabIndex=-1;target.focus({preventScroll:true});
 });
 new MutationObserver(syncPlayback).observe(document.body,{attributes:true,attributeFilter:['class']});
 document.addEventListener('visibilitychange',()=>{if(!document.hidden)resize();syncPlayback();});
 [reduced,desktop,fine].forEach(query=>query.addEventListener('change',reconcile));
 connection?.addEventListener?.('change',reconcile);
 window.addEventListener('resize',reconcile,{passive:true});window.addEventListener('load',resize);
 window.addEventListener('pagehide',()=>{suspended=true;reconcile();});
 window.addEventListener('pageshow',()=>{suspended=false;reconcile();});
 reconcile();
})();
