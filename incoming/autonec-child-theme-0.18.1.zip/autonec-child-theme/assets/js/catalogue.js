/* Native buttons enhance the local Media gallery; all photos remain visible without JS. */
(() => {
 'use strict';
 const filterPanel=document.querySelector('[data-an-filter-panel]');
 if(filterPanel){const compact=matchMedia('(max-width:700px)');const adapt=()=>{filterPanel.open=!compact.matches;};adapt();compact.addEventListener('change',adapt);}

 // A real GET select remains the source of truth; this listbox is progressive enhancement.
 const selects=[];
 document.querySelectorAll('.an-catalogue-filters select, .an-gamma-filter select').forEach(select=>{
  const wrapper=document.createElement('div');wrapper.className='an-choice';
  const button=document.createElement('button');button.type='button';button.className='an-choice__control';button.id=select.id+'-control';button.setAttribute('role','combobox');button.setAttribute('aria-haspopup','listbox');button.setAttribute('aria-expanded','false');
  const value=document.createElement('span');value.className='an-choice__value';button.append(value);
  const mark=document.createElement('span');mark.className='an-choice__mark';mark.setAttribute('aria-hidden','true');button.append(mark);
  const list=document.createElement('div');list.className='an-choice__list';list.id=select.id+'-options';list.setAttribute('role','listbox');list.setAttribute('data-lenis-prevent','');list.hidden=true;button.setAttribute('aria-controls',list.id);
  const label=document.querySelector('label[for="'+select.id+'"]');
  if(label){label.id=label.id||select.id+'-label';label.htmlFor=button.id;button.setAttribute('aria-labelledby',label.id+' '+button.id+'-value');value.id=button.id+'-value';list.setAttribute('aria-labelledby',label.id);}
  let options=[];const buildOptions=()=>{list.replaceChildren();options=Array.from(select.options).map((option,index)=>{const el=document.createElement('div');el.className='an-choice__option';el.id=list.id+'-'+index;el.setAttribute('role','option');el.textContent=option.textContent;el.dataset.index=String(index);list.append(el);return el;});};buildOptions();
  let active=select.selectedIndex,buffer='',typedAt=0;
  const render=()=>{value.textContent=select.options[select.selectedIndex]?.textContent||'';options.forEach((option,index)=>{option.setAttribute('aria-selected',String(index===select.selectedIndex));option.classList.toggle('is-active',index===active);});if(!list.hidden)button.setAttribute('aria-activedescendant',options[active]?.id||'');};
  const close=()=>{list.hidden=true;button.setAttribute('aria-expanded','false');button.removeAttribute('aria-activedescendant');wrapper.classList.remove('is-open');};
  const move=index=>{active=Math.max(0,Math.min(options.length-1,index));render();options[active]?.scrollIntoView({block:'nearest'});};
  const open=()=>{selects.forEach(control=>control.close());active=select.selectedIndex;list.hidden=false;button.setAttribute('aria-expanded','true');wrapper.classList.add('is-open');const bounds=button.getBoundingClientRect();wrapper.classList.toggle('opens-up',window.innerHeight-bounds.bottom<240&&bounds.top>300);render();options[active]?.scrollIntoView({block:'nearest'});};
  const choose=index=>{select.selectedIndex=index;select.dispatchEvent(new Event('change',{bubbles:true}));render();close();button.focus({preventScroll:true});};
  button.addEventListener('click',()=>list.hidden?open():close());
  button.addEventListener('keydown',event=>{
   const key=event.key;
   if(key==='Escape'){if(!list.hidden){event.preventDefault();close();}return;}
   if(key==='Tab'){close();return;}
   if(key==='ArrowDown'||key==='ArrowUp'){event.preventDefault();if(list.hidden)open();else move(active+(key==='ArrowDown'?1:-1));return;}
   if((key==='Home'||key==='End')&&!list.hidden){event.preventDefault();move(key==='Home'?0:options.length-1);return;}
   if((key==='Enter'||key===' ')&&!list.hidden){event.preventDefault();choose(active);return;}
   if(key.length===1&&!event.ctrlKey&&!event.metaKey&&!event.altKey){event.preventDefault();if(list.hidden)open();const now=Date.now();buffer=now-typedAt>800?key:buffer+key;typedAt=now;const found=Array.from(select.options).findIndex(option=>option.textContent.toLocaleLowerCase().startsWith(buffer.toLocaleLowerCase()));if(found>=0)move(found);}
  });
  // Keep combobox focus while pressing an option, so focusout cannot remove it before click.
  list.addEventListener('pointerdown',event=>{if(event.target.closest('[data-index]'))event.preventDefault();});
  list.addEventListener('click',event=>{const option=event.target.closest('[data-index]');if(option)choose(Number(option.dataset.index));});
  select.addEventListener('change',()=>{active=select.selectedIndex;render();});
  select.before(wrapper);wrapper.append(select,button,list);select.hidden=true;select.tabIndex=-1;render();selects.push({select,wrapper,close,setOptions:(items,reset=false)=>{const previous=reset?'':select.value;const first=select.options[0].textContent;select.replaceChildren(new Option(first,''),...items.map(item=>new Option(item.label,item.value)));select.value=items.some(item=>item.value===previous)?previous:'';active=select.selectedIndex;buildOptions();render();close();}});
 });
 const brand=document.querySelector('#an-filter-brand');
 let facets={};try{facets=JSON.parse(document.querySelector('#an-catalogue-facet-map')?.textContent||'{}');}catch{ /* Native filters remain usable if the map is unavailable. */ }
 brand?.addEventListener('change',()=>{const group=facets[brand.value]||{};selects.forEach(control=>{if(control.select===brand)return;control.setOptions(group[control.select.name]||[],control.select.name==='modello');});});
 document.addEventListener('pointerdown',event=>selects.forEach(control=>{if(!control.wrapper.contains(event.target))control.close();}));
 document.addEventListener('focusin',event=>selects.forEach(control=>{if(!control.wrapper.contains(event.target))control.close();}));
 window.addEventListener('resize',()=>selects.forEach(control=>control.close()),{passive:true});

 // Two native range thumbs share one quiet budget track; no amount needs typing.
 const budget=document.querySelector('[data-an-budget]');
 if(budget){
  const min=budget.querySelector('[name="prezzo_min"]'),max=budget.querySelector('[name="prezzo_max"]');
  const lower=Number(budget.dataset.min),upper=Number(budget.dataset.max),step=Number(min.dataset.budgetStep)||500;
  const formatter=new Intl.NumberFormat(document.documentElement.lang||'it-CH',{maximumFractionDigits:0,useGrouping:'always'});
  const price=value=>'CHF '+formatter.format(Number(value));
  const paint=()=>{budget.querySelector('[data-budget-min]').textContent=price(min.value);budget.querySelector('[data-budget-max]').textContent=price(max.value);min.setAttribute('aria-valuetext',price(min.value));max.setAttribute('aria-valuetext',price(max.value));const fill=budget.querySelector('[data-budget-fill]');fill.style.left=((Number(min.value)-lower)/(upper-lower)*100)+'%';fill.style.right=(100-(Number(max.value)-lower)/(upper-lower)*100)+'%';};
  min.addEventListener('input',()=>{if(Number(min.value)>Number(max.value))min.value=max.value;paint();});
  max.addEventListener('input',()=>{if(Number(max.value)<Number(min.value))max.value=min.value;paint();});
  [min,max].forEach(input=>input.addEventListener('keydown',event=>{if(event.key!=='ArrowLeft'&&event.key!=='ArrowRight'&&event.key!=='ArrowUp'&&event.key!=='ArrowDown')return;event.preventDefault();const direction=event.key==='ArrowRight'||event.key==='ArrowUp'?1:-1;input.value=String(Math.max(lower,Math.min(upper,Number(input.value)+direction*step)));input.dispatchEvent(new Event('input',{bubbles:true}));}));
  [min,max].forEach(input=>input.addEventListener('focus',()=>{min.style.zIndex=input===min?'3':'2';max.style.zIndex=input===max?'3':'2';}));
  budget.querySelector('.an-budget__track').addEventListener('pointerdown',event=>{
   if(event.target.matches('input'))return;
   event.preventDefault();const rect=event.currentTarget.getBoundingClientRect();const value=Math.max(lower,Math.min(upper,Math.round((lower+(event.clientX-rect.left)/rect.width*(upper-lower))/step)*step));
   const input=Math.abs(value-Number(min.value))<Math.abs(value-Number(max.value))?min:max;input.focus({preventScroll:true});input.value=String(value);input.dispatchEvent(new Event('input',{bubbles:true}));
  });
  budget.closest('form').addEventListener('submit',()=>{min.disabled=Number(min.value)<=lower;max.disabled=Number(max.value)>=upper;});
  window.addEventListener('pageshow',()=>{min.disabled=false;max.disabled=false;paint();});paint();
 }

 document.querySelectorAll('[data-an-gallery]').forEach(gallery => {
  const frames = [...gallery.querySelectorAll('[data-an-gallery-frame]')];
  const buttons = [...gallery.querySelectorAll('[data-an-gallery-button]')];
  const controls = gallery.querySelector('[data-an-gallery-controls]');
  const status = gallery.querySelector('[data-an-gallery-count]');
  if (frames.length < 2 || buttons.length !== frames.length || !controls || !status) return;
  const show = (index, focus = false) => {
   if (index < 0 || index >= frames.length) return;
   frames.forEach((frame, current) => { frame.hidden = current !== index; });
   buttons.forEach((button, current) => { button.setAttribute('aria-pressed', String(current === index)); });
   gallery.classList.toggle('is-changing',false);
   status.textContent = status.dataset.format.replace('%1$d', String(index + 1)).replace('%2$d', String(frames.length));
   if (focus) buttons[index].focus();
  };
  buttons.forEach((button, index) => {
   button.addEventListener('click', () => show(index));
   button.addEventListener('keydown', event => {
    let next;
    if (event.key === 'ArrowRight') next = (index + 1) % buttons.length;
    if (event.key === 'ArrowLeft') next = (index - 1 + buttons.length) % buttons.length;
    if (event.key === 'Home') next = 0;
    if (event.key === 'End') next = buttons.length - 1;
    if (next === undefined) return;
    event.preventDefault();
    show(next, true);
   });
  });
  show(0);
  controls.hidden = false;
  gallery.classList.add('is-enhanced');
 });
 // A single quiet reveal; content is always visible without motion support.
 const motion=matchMedia('(prefers-reduced-motion: reduce)');
 if(!motion.matches&&'IntersectionObserver' in window){
  const observer=new IntersectionObserver(entries=>entries.forEach(entry=>{if(entry.isIntersecting){entry.target.classList.add('is-in-view');observer.unobserve(entry.target);}}),{threshold:.08});
  document.querySelectorAll('.an-vehicle-description').forEach(section=>{section.classList.add('an-content-reveal');observer.observe(section);});
 }
 const facts=document.querySelector('.an-vehicle-facts');
 if(facts&&'ResizeObserver' in window){const fit=()=>facts.classList.toggle('can-follow',window.innerWidth>1100&&facts.offsetHeight<window.innerHeight-210);new ResizeObserver(fit).observe(facts);window.addEventListener('resize',fit,{passive:true});fit();}
})();
