/** Native GET filters, optional editorial reveals, and a scroll-linked six-model preview. */
(() => {
 'use strict';
 const reduced = window.matchMedia('(prefers-reduced-motion: reduce)');
 const stories = [...document.querySelectorAll('[data-an-gamma-story]')];
 if (stories.length && !reduced.matches && 'IntersectionObserver' in window && !navigator.connection?.saveData) {
  const observer = new IntersectionObserver((entries) => {
   entries.forEach((entry) => {
    if (!entry.isIntersecting) return;
    entry.target.classList.add('is-revealing');
    observer.unobserve(entry.target);
   });
  }, { threshold: 0.16 });
  stories.forEach((story) => observer.observe(story));
  reduced.addEventListener('change', (event) => {
   if (!event.matches) return;
   observer.disconnect();
   stories.forEach((story) => story.classList.remove('is-revealing'));
  });
 }

 // Every category is queried against the entire model archive, then paginated by WordPress.
 document.querySelectorAll('[data-an-gamma-form]').forEach((form) => {
  const select = form.querySelector('select[name="categoria"]');
  if (!select) return;
  select.addEventListener('change', () => {
   form.querySelector('[name="pagina"]')?.remove();
   if (typeof form.requestSubmit === 'function') form.requestSubmit();
   else form.submit();
  });
 });

 // One short horizontal passage follows native vertical scrolling; no wheel interception.
 document.querySelectorAll('[data-an-gamma-showcase]').forEach((section) => {
  const rail = section.querySelector('[data-an-gamma-rail]');
  const stage = section.querySelector('[data-an-gamma-stage]');
  const heading = section.querySelector('.an-gamma-section-heading');
  const controls = section.querySelector('[data-an-gamma-rail-controls]');
  const previous = section.querySelector('[data-an-gamma-previous]');
  const next = section.querySelector('[data-an-gamma-next]');
  const progress = section.querySelector('[data-an-gamma-progress]');
  if (!rail || !stage || !heading || !controls || !previous || !next || !progress) return;
  const desktop = matchMedia('(min-width: 1000px) and (hover: hover) and (pointer: fine)');
  const cards = [...rail.querySelectorAll('[data-an-model-card]')];
  let frame = 0, measuring = false, driven = false, offset = 0, distance = 0, maximum = 0;
  const clamp = (value, max = 1) => Math.max(0, Math.min(max, value));
  const beginning = () => heading.getBoundingClientRect().bottom + scrollY + parseFloat(getComputedStyle(heading).marginBottom) - offset;
  const update = () => {
   frame = 0;
   if (driven) rail.scrollLeft = clamp((scrollY - beginning()) / distance) * maximum;
   const position = clamp(rail.scrollLeft, maximum);
   controls.hidden = maximum < 2;
   previous.disabled = position < 2;
   next.disabled = position >= maximum - 2;
   progress.value = maximum ? position / maximum * 100 : 100;
   rail.classList.toggle('is-enhanced', !reduced.matches);
   const bounds = rail.getBoundingClientRect();
   cards.forEach((card) => {
    const rect = card.getBoundingClientRect();
    const visible = Math.max(0, Math.min(bounds.right, rect.right) - Math.max(bounds.left, rect.left));
    const opacity = reduced.matches || !rect.width ? 1 : Math.min(1, .65 + visible / rect.width * .35);
    card.style.setProperty('--an-rail-visibility', opacity.toFixed(3));
   });
  };
  const schedule = () => { if (!frame && !document.hidden) frame = requestAnimationFrame(update); };
  const measure = () => {
   if (measuring) return;
   measuring = true;
   const header = document.querySelector('.an-header');
   const brands = document.querySelector('.an-marque-nav');
   offset = (header?.offsetHeight || 0) + (brands?.offsetHeight || 0) + (parseFloat(header ? getComputedStyle(header).top : 0) || 0) + 18;
   maximum = Math.max(0, rail.scrollWidth - rail.clientWidth);
   const eligible = desktop.matches && !reduced.matches && !navigator.connection?.saveData && maximum > 2;
   controls.hidden = maximum < 2;
   section.classList.toggle('is-scroll-driven', eligible);
   // Measure after hiding manual buttons, then reject any stage that cannot fit in full.
   driven = eligible && stage.offsetHeight <= innerHeight - offset - 22;
   section.classList.toggle('is-scroll-driven', driven);
   if (driven) {
    // Centre the complete gallery (photos, copy and progress) below the fixed navigation.
    const navigationBottom = offset - 18;
    offset = navigationBottom + Math.max(18, (innerHeight - navigationBottom - stage.offsetHeight) / 2);
    distance = Math.min(1200, Math.max(650, maximum * .72));
    const style = getComputedStyle(section);
    const natural = parseFloat(style.paddingTop) + heading.offsetHeight + parseFloat(getComputedStyle(heading).marginBottom) + stage.offsetHeight + parseFloat(style.paddingBottom);
    section.style.setProperty('--an-showcase-height', `${Math.ceil(natural + distance)}px`);
    section.style.setProperty('--an-showcase-top', `${offset}px`);
   } else {
    section.style.removeProperty('--an-showcase-height');
    section.style.removeProperty('--an-showcase-top');
   }
   measuring = false;
   schedule();
  };
  const scrollPage = (top, immediate = false) => {
   const request = new CustomEvent('an:scroll-to', { cancelable: true, detail: { top, immediate } });
   if (window.dispatchEvent(request)) window.scrollTo({ top, behavior: immediate ? 'instant' : 'smooth' });
  };
  const move = (position) => {
   const left = clamp(position, maximum);
   if (driven) scrollPage(beginning() + left / maximum * distance);
   else rail.scrollTo({ left, behavior: reduced.matches ? 'auto' : 'smooth' });
  };
  previous.addEventListener('click', () => move(rail.scrollLeft - rail.clientWidth * .85));
  next.addEventListener('click', () => move(rail.scrollLeft + rail.clientWidth * .85));
  rail.addEventListener('keydown', (event) => {
   if (!driven || event.altKey || event.ctrlKey || event.metaKey || event.shiftKey) return;
   const positions = { ArrowLeft: rail.scrollLeft - rail.clientWidth / 3, ArrowRight: rail.scrollLeft + rail.clientWidth / 3, Home: 0, End: maximum };
   if (!(event.key in positions)) return;
   event.preventDefault();
   move(positions[event.key]);
  });
  rail.addEventListener('focusin', (event) => {
   if (!driven) return;
   const card = event.target.closest('[data-an-model-card]');
   if (!card) return;
   const rect = card.getBoundingClientRect(), bounds = rail.getBoundingClientRect();
   const expected = clamp((scrollY - beginning()) / distance) * maximum;
   // Native focus can pan hidden overflow before this event reaches the rail.
   if (Math.abs(expected - rail.scrollLeft) > 2) {
    scrollPage(beginning() + rail.scrollLeft / maximum * distance, true);
   } else if (rect.left < bounds.left - 1 || rect.right > bounds.right + 1) {
    const left = clamp(rail.scrollLeft + rect.left - bounds.left, maximum);
    scrollPage(beginning() + left / maximum * distance, true);
   }
  });
  rail.addEventListener('scroll', schedule, { passive: true });
  window.addEventListener('scroll', schedule, { passive: true });
  window.addEventListener('resize', measure, { passive: true });
  window.addEventListener('pageshow', measure);
  document.addEventListener('visibilitychange', schedule);
  reduced.addEventListener('change', measure);
  desktop.addEventListener('change', measure);
  if ('ResizeObserver' in window) {
   const observer = new ResizeObserver(measure);
   observer.observe(stage); observer.observe(heading);
  }
  document.fonts?.ready.then(measure);
  measure();
 });
})();
