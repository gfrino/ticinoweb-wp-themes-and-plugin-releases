(() => {
 'use strict';
 const $=s=>document.querySelector(s),hero=$('[data-hero]'),stage=$('[data-hero-stage]'),media=$('[data-hero-media]'),heading=$('[data-hero-heading]'),copy=$('[data-hero-copy]'),arrival=$('[data-arrival]');
 const word=$('[data-scene-word]'),video=$('[data-hero-video]'),rail=$('[data-brand-nav]'),journey=$('[data-journey]'),journeyStage=$('[data-journey-stage]'),track=$('[data-journey-track]');
 const panels=[...document.querySelectorAll('[data-marque]')],brandLinks=[...document.querySelectorAll('[data-brand-link]')],showroom=$('[data-showroom]'),door=$('[data-showroom-photo]');
 const reduced=matchMedia('(prefers-reduced-motion: reduce)'),wide=matchMedia('(min-width: 1000px)'),connection=navigator.connection,saveData=()=>!!connection?.saveData,J=AutonecJourney;
 const clamp=(v,min=0,max=1)=>Math.min(max,Math.max(min,v));
 // Animate children: their parents remain available to the scroll choreography.
 const entrance=[];
 function cancelEntrance(){entrance.forEach(animation=>animation.cancel());entrance.length=0;}
 if(stage&&!reduced.matches&&!saveData()&&scrollY<40&&!location.hash){
  const reveal=(element,delay,distance)=>{
   if(!element?.animate)return;
   entrance.push(element.animate([
    {opacity:0,transform:`translate3d(0,${distance}px,0)`},
    {opacity:1,transform:'translate3d(0,0,0)'}
   ],{duration:860,delay,easing:'cubic-bezier(.16,1,.3,1)',fill:'backwards'}));
  };
  heading?.querySelectorAll('.an-hero__title-word').forEach((element,index)=>reveal(element,Math.min(index,4)*90,32));
  if(copy)[...copy.children].forEach((element,index)=>reveal(element,280+index*110,18));
 }
 let lenis=null,raf=null,last=0,camera=scrollY,dirty=true,inView=true,cinema=false,horizontal=false,offset=158,heroStart=0,heroRange=1,journeyStart=0,journeyRange=0,travel=0,doorTop=0,active=-2,initialHash=false,sceneLift=90,mediaLift=90;
 function request(){dirty=true;if(raf===null&&!document.hidden)raf=requestAnimationFrame(tick);}
 async function playFilm(){
  if(!video||document.hidden||!inView||reduced.matches||saveData())return;
  if(!video.getAttribute('src')){video.src=video.dataset.src;video.load();}video.muted=true;
  try{await video.play();}catch{}
 }
 if(video){
  video.addEventListener('playing',()=>{if(reduced.matches||saveData()){video.pause();media?.classList.remove('is-playing');}else media?.classList.add('is-playing');});
  video.addEventListener('error',()=>{media?.classList.remove('is-playing');});
  if('IntersectionObserver' in window)new IntersectionObserver(entries=>{inView=entries[0].isIntersecting;if(inView)playFilm();else video.pause();},{threshold:.02}).observe(stage);
  playFilm();
 }
 const showroomVideo=$('[data-showroom-video]');let showroomVisible=false;
 async function playShowroom(){
  if(!showroomVideo||!showroomVisible||document.hidden||reduced.matches||saveData())return;
  if(!showroomVideo.getAttribute('src')){showroomVideo.src=showroomVideo.dataset.src;showroomVideo.load();}showroomVideo.muted=true;
  try{await showroomVideo.play();}catch{}
 }
 if(showroomVideo&&door){
  showroomVideo.addEventListener('playing',()=>{if(reduced.matches||saveData()){showroomVideo.pause();door.classList.remove('is-playing');}else door.classList.add('is-playing');});
  showroomVideo.addEventListener('error',()=>door.classList.remove('is-playing'));
  if('IntersectionObserver' in window)new IntersectionObserver(entries=>{showroomVisible=entries[0].isIntersecting;if(showroomVisible)playShowroom();else showroomVideo.pause();},{rootMargin:'220px 0px',threshold:0}).observe(door);
 }
 function mark(index){if(active===index)return;active=index;brandLinks.forEach(link=>{const current=panels[index]?.id===link.hash.slice(1);if(current)link.setAttribute('aria-current','location');else link.removeAttribute('aria-current');});}
 // Fit painted glyphs, rather than their advance box, to the shared header gutters.
 // Measurement runs on layout/font changes only; the scroll frame only transforms.
 const wordMeasure=document.createElement('canvas').getContext('2d');
 function fitWord(){
  const text=word?.firstElementChild;if(!cinema||!text||!wordMeasure||!word.clientWidth)return;
  const style=getComputedStyle(text);wordMeasure.font=`${style.fontWeight} 1000px ${style.fontFamily}`;
  const metrics=wordMeasure.measureText(text.textContent.toLocaleUpperCase(document.documentElement.lang||undefined));
  const ink=metrics.actualBoundingBoxLeft+metrics.actualBoundingBoxRight;
  if(!(ink>0))return;
  const size=word.clientWidth*1000/ink;
  text.style.fontSize=`${size}px`;text.style.left=`${metrics.actualBoundingBoxLeft*size/1000}px`;
  const available=stage.clientHeight-word.offsetHeight-parseFloat(getComputedStyle(word).bottom)-28;
  const arrivalStyle=getComputedStyle(arrival),children=[...arrival.children];
  const content=children.reduce((height,el)=>{const css=getComputedStyle(el);return height+el.offsetHeight+parseFloat(css.marginTop)+parseFloat(css.marginBottom);},0)+parseFloat(arrivalStyle.gap)*Math.max(0,children.length-1);
  // Preserve readable CMS content on exceptionally wide/short viewports or short names.
  // Fall back to the existing vertical composition when both scenes cannot fit.
  if(available<content+16){cinema=false;document.documentElement.classList.remove('an-cinema');hero.append(arrival);}
  else{sceneLift=(stage.clientHeight-available)/2;mediaLift=Math.min(sceneLift,Math.max(0,stage.clientHeight*.3-55));}
 }
 function measure(){
  const motion=!reduced.matches&&!saveData();
  cinema=!!(motion&&wide.matches&&innerHeight>=750&&hero&&arrival&&media);
  horizontal=!!(motion&&wide.matches&&innerHeight>=750&&panels.length>1&&track);
  document.documentElement.classList.toggle('an-cinema',cinema);document.documentElement.classList.toggle('an-horizontal',horizontal);
  if(arrival&&hero&&stage){if(cinema&&arrival.parentNode!==stage)stage.append(arrival);else if(!cinema&&arrival.parentNode!==hero)hero.append(arrival);}
  fitWord();
  lenis=window.AutonecScroll?.instance||null;
  offset=($('.an-header')?.offsetHeight||0)+(rail?.offsetHeight||0)+parseFloat(getComputedStyle($('.an-header')).top||0);
  if(!Number.isFinite(offset))offset=158;
  if(journey){journey.style.height=horizontal?`${(journeyStage.offsetHeight||innerHeight)*panels.length}px`:'';}
  heroStart=hero?hero.getBoundingClientRect().top+scrollY-offset:0;
  heroRange=cinema?Math.max(1,hero.offsetHeight-stage.offsetHeight):1;
  journeyStart=journey?journey.getBoundingClientRect().top+scrollY-offset:0;
  journeyRange=horizontal?Math.max(1,journey.offsetHeight-journeyStage.offsetHeight):0;travel=horizontal?Math.max(0,track.scrollWidth-innerWidth):0;
  doorTop=door?door.getBoundingClientRect().top+scrollY:0;
  if(!cinema){[media,heading,copy,arrival].forEach(el=>{if(el){el.style.transform='';el.style.opacity='';el.inert=false;}});media?.style.removeProperty('--an-veil');}
  if(!horizontal&&track)track.style.transform='';if(!motion&&door){door.style.clipPath='';door.style.transform='';}
  lenis?.resize();camera=scrollY;active=-2;request();
  if(!initialHash){initialHash=true;const target=document.getElementById(location.hash.slice(1));if(target&&panels.includes(target))moveTo(target,true);}
 }
 function paint(){
  if(cinema){
   const p=J.progress(camera,heroStart,heroRange),t=clamp((p-.2)/.65);
   if(word){
    const w=clamp((p-.35)/.4),fill=clamp((p-.46)/.47),reflection=clamp((p-.51)/.47);
    word.style.clipPath=`inset(${(1-w)*100}% 0 0)`;word.style.transform=`translate3d(0,${(1-w)*65}px,0)`;
    word.style.setProperty('--an-word-fill',`${fill*112-6}%`);word.style.setProperty('--an-word-scan',`${reflection*125-10}%`);word.style.setProperty('--an-word-reflection',String(Math.sin(Math.PI*reflection)*.68));
   }
   media.style.transform=`translate3d(${p*4}vw,${-p*mediaLift}px,0) rotateY(${-p*11}deg) rotateZ(${-p*1.5}deg) scale(${1-p*.60})`;
   media.style.setProperty('--an-veil',String(1-p));
   heading.style.transform=`translate3d(${-p*85}vw,${-p*45}px,0)`;heading.style.opacity=String(1-clamp(p/.65));
   if(copy){copy.style.opacity=String(1-clamp(p/.2));copy.inert=p>.2;}
   arrival.inert=t<.04;arrival.style.opacity=String(t);arrival.style.transform=`translate3d(${Math.max((1-t)*70,innerWidth*(.5-.56*p)+17)}px,${-p*sceneLift}px,0)`;
  }
  if(horizontal){const p=J.progress(camera,journeyStart,journeyRange);track.style.transform=`translate3d(${-p*travel}px,0,0)`;mark(camera>=journeyStart-50&&camera<=journeyStart+journeyRange+journeyStage.offsetHeight?Math.round(p*(panels.length-1)):-1);}
  else{let index=-1;panels.forEach((panel,i)=>{const r=panel.getBoundingClientRect();if(r.top<offset+innerHeight*.4&&r.bottom>offset)index=i;});mark(index);}
  if(door&&!reduced.matches&&!saveData()){const p=clamp((camera+innerHeight*1.3-doorTop)/(innerHeight*.55));door.style.clipPath=`inset(0 ${(1-p)*47}% 0 ${(1-p)*47}%)`;door.style.transform=`translate3d(0,${(1-p)*35}px,0)`;}
 }
 function tick(time){raf=null;if(document.hidden)return;const dt=last?Math.min(64,time-last):16;last=time;const d=scrollY-camera;camera=reduced.matches?scrollY:camera+d*(1-Math.exp(-dt/55));if(Math.abs(d)<.08)camera=scrollY;if(dirty||Math.abs(d)>.03){paint();dirty=false;}if(Math.abs(scrollY-camera)>.08)raf=requestAnimationFrame(tick);}
 function destination(target){const index=panels.indexOf(target);if(horizontal&&index>=0)return J.offset(index,panels.length,journeyStart,journeyRange);if(horizontal&&target===journey)return journeyStart;if(cinema&&target===arrival)return heroStart+heroRange;return target.getBoundingClientRect().top+scrollY-offset-16;}
 function moveTo(target,instant=false,focus=false){const top=destination(target),done=()=>{if(focus){if(!target.hasAttribute('tabindex'))target.tabIndex=-1;target.focus({preventScroll:true});}};if(lenis)lenis.scrollTo(top,{immediate:instant,duration:.85,lerp:0,easing:t=>1-(1-t)**4,onComplete:done});else{scrollTo({top,behavior:instant||reduced.matches?'instant':'smooth'});done();}}
 document.addEventListener('click',event=>{
  const link=event.target.closest('a[href]');if(!link||link.classList.contains('an-skip')||event.button!==0||event.ctrlKey||event.metaKey||event.shiftKey||event.altKey)return;
  let url;try{url=new URL(link.href,location.href);}catch{return;}if(url.origin!==location.origin||url.pathname!==location.pathname||!url.hash)return;
  let id;try{id=decodeURIComponent(url.hash.slice(1));}catch{return;}const target=document.getElementById(id);if(!target)return;
  event.preventDefault();history.pushState(null,'',url.hash);moveTo(target,false,true);
 });
 track?.addEventListener('focusin',event=>{const panel=event.target.closest('[data-marque]');if(horizontal&&panel&&Math.abs(destination(panel)-scrollY)>3)moveTo(panel,true);});
 window.addEventListener('popstate',()=>{const target=document.getElementById(location.hash.slice(1));if(target)moveTo(target,true);});
 if(journey&&'IntersectionObserver' in window&&!saveData()){const imageObserver=new IntersectionObserver(entries=>{if(!saveData()&&entries.some(e=>e.isIntersecting)){journey.querySelectorAll('.an-marque__photo img').forEach(img=>{img.loading='eager';});imageObserver.disconnect();}},{rootMargin:'1000px 0px'});imageObserver.observe(journey);}
 const serviceRows=[...document.querySelectorAll('[data-service-row]')];
 if('IntersectionObserver' in window){const serviceObserver=new IntersectionObserver(entries=>{entries.forEach(e=>e.target.classList.toggle('is-current',e.isIntersecting));},{rootMargin:'-49% 0px -49% 0px',threshold:0});serviceRows.forEach(row=>serviceObserver.observe(row));}
 window.addEventListener('scroll',request,{passive:true});window.addEventListener('resize',measure,{passive:true});
 function syncMotion(){if(reduced.matches||saveData()){cancelEntrance();video?.pause();media?.classList.remove('is-playing');showroomVideo?.pause();door?.classList.remove('is-playing');}else{playFilm();playShowroom();}measure();}
 reduced.addEventListener('change',syncMotion);connection?.addEventListener?.('change',syncMotion);wide.addEventListener('change',measure);
 document.addEventListener('visibilitychange',()=>{last=0;if(document.hidden){video?.pause();showroomVideo?.pause();if(raf!==null)cancelAnimationFrame(raf);raf=null;}else{request();playFilm();playShowroom();}});
 window.addEventListener('an:scroll-ready',measure);
 document.fonts?.ready.then(measure);window.addEventListener('pageshow',measure);window.addEventListener('load',measure);measure();
})();
