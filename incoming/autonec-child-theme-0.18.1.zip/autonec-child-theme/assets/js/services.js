(() => {
 'use strict';
 const page=document.querySelector('.an-services-page'),hero=page?.querySelector('.an-services-hero'),stage=hero?.querySelector('.an-services-hero__stage'),photo=hero?.querySelector('.an-services-hero__photo'),copy=hero?.querySelector('.an-services-hero__copy'),index=page?.querySelector('.an-services-index'),header=document.querySelector('.an-header');
 if(!page)return;
 const chapters=[...page.querySelectorAll('.an-service-chapter')],links=[...index?.querySelectorAll('a')||[]],reduced=matchMedia('(prefers-reduced-motion: reduce)'),wide=matchMedia('(min-width:1101px)'),connection=navigator.connection;
 let lenis=null,raf=null,dirty=true,opening=false,start=0,range=480,offset=176,tops=[],active=-2;
 const clamp=n=>Math.min(1,Math.max(0,n)),motion=()=>!reduced.matches&&!connection?.saveData;
 function request(){dirty=true;if(raf===null&&!document.hidden)raf=requestAnimationFrame(tick);}
 function measure(){
  const headerTop=parseFloat(header?getComputedStyle(header).top||0:0),headerHeight=(header?.offsetHeight||80)+headerTop,height=innerHeight-headerHeight,indexHeight=index?.offsetHeight||0;
  page.style.setProperty('--an-service-index-height',`${indexHeight}px`);offset=headerHeight+indexHeight+20;
  opening=!!(motion()&&wide.matches&&height>=620&&photo&&copy);
  page.classList.toggle('an-services-motion',opening);
  if(opening){
   range=Math.min(640,Math.max(420,height*.65));page.style.setProperty('--an-services-height',`${height}px`);page.style.setProperty('--an-services-range',`${range}px`);page.style.setProperty('--an-services-top',`${headerHeight}px`);
   if(copy.offsetHeight>height-24){opening=false;page.classList.remove('an-services-motion');}
  }
  if(!opening&&copy){copy.inert=false;page.style.removeProperty('--an-services-edge');page.style.removeProperty('--an-services-copy-x');page.style.removeProperty('--an-services-copy-opacity');page.style.removeProperty('--an-services-photo-pan');}
  start=hero?hero.getBoundingClientRect().top+scrollY-headerHeight:0;
  tops=chapters.map(el=>el.getBoundingClientRect().top+scrollY);
  lenis=window.AutonecScroll?.instance||null;
  lenis?.resize();active=-2;request();
 }
 function paint(){
  if(opening){const p=clamp((scrollY-start)/range),ease=1-(1-p)**3;page.style.setProperty('--an-services-edge',`${55*(1-ease)}%`);page.style.setProperty('--an-services-photo-pan',`${-25*(1-ease)}%`);page.style.setProperty('--an-services-copy-x',`${innerWidth*.55*ease}px`);page.style.setProperty('--an-services-copy-opacity',String(1-clamp(p*2)));copy.inert=p>.5;}
  let selected=-1;tops.forEach((top,i)=>{if(scrollY+offset+70>=top)selected=i;});
  if(selected!==active){active=selected;links.forEach((link,i)=>{if(i===active)link.setAttribute('aria-current','location');else link.removeAttribute('aria-current');});}
 }
 function tick(){raf=null;if(document.hidden)return;if(dirty){paint();dirty=false;}}
 function move(target){
  if(target.classList.contains('an-services-collection'))target=chapters[0]||target;
  const padding=target.classList.contains('an-service-chapter')?parseFloat(getComputedStyle(target).paddingTop):0,top=target.getBoundingClientRect().top+scrollY+padding-offset;
  const done=()=>{target.tabIndex=-1;target.focus({preventScroll:true});};
  if(lenis)lenis.scrollTo(top,{onComplete:done});else{window.scrollTo({top,behavior:motion()?'smooth':'instant'});done();}
 }
 page.addEventListener('click',event=>{const link=event.target.closest('a[href^="#"]');if(!link||event.metaKey||event.ctrlKey||event.shiftKey||event.altKey)return;const target=document.getElementById(link.hash.slice(1));if(!target)return;event.preventDefault();history.replaceState(null,'',link.hash);move(target);});
 window.addEventListener('scroll',request,{passive:true});window.addEventListener('resize',measure,{passive:true});window.addEventListener('pageshow',measure);window.addEventListener('load',measure);reduced.addEventListener('change',measure);wide.addEventListener('change',measure);connection?.addEventListener?.('change',measure);document.fonts?.ready.then(measure);
 if('ResizeObserver'in window){const observer=new ResizeObserver(measure);if(copy)observer.observe(copy);if(index)observer.observe(index);chapters.forEach(el=>observer.observe(el));}
 window.addEventListener('an:scroll-ready',measure);
 document.addEventListener('visibilitychange',()=>{if(document.hidden){if(raf!==null)cancelAnimationFrame(raf);raf=null;}else request();});measure();
})();
