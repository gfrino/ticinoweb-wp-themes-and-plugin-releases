/* Bounded worker ticks, text-only progress and native capability/nonce enforcement. */
(() => {
 const start = document.querySelector('[data-gamma-start]');
 const progress = document.querySelector('[data-gamma-progress]');
 if (!start || !progress || !window.anGammaSync) return;
 let working = false, stopped = false, dirty = false;
 const form = document.querySelector('.wrap form');
 form?.addEventListener('input', () => { dirty = true; });
 window.addEventListener('beforeunload', event => { if (dirty) { event.preventDefault(); event.returnValue = ''; } });
 form?.addEventListener('submit', () => { dirty = false; });
 async function request(command) {
  const body = new URLSearchParams({action: 'an_gamma_sync', nonce: anGammaSync.nonce, command});
  const response = await fetch(anGammaSync.url, {method: 'POST', credentials: 'same-origin', body});
  const data = await response.json();
  if (!data.success) { const error = new Error(data.data?.message || anGammaSync.error); error.userFacing = true; throw error; }
  return data.data;
 }
 function render(data) {
  const state = data.state || {};
  progress.textContent = `${state.message || ''}${data.busy ? ` (${state.done || 0}/${state.total || 0})` : ''}`;
  if (!data.busy && state.errors?.length) {
   const list = document.createElement('ul');
   state.errors.forEach(message => { const row = document.createElement('li'); row.textContent = message; list.append(row); });
   progress.append(list);
  }
  Object.entries(data.sources || {}).forEach(([slug, value]) => {
   const cell = document.querySelector(`[data-gamma-status="${CSS.escape(slug)}"]`);
   if (cell) cell.textContent = [value.date, value.message].filter(Boolean).join(' · ');
  });
  start.disabled = data.busy;
 }
 async function loop(command = 'status') {
  if (working || stopped) return;
  working = true;
  try { const data = await request(command); render(data); if (data.busy) setTimeout(() => loop('tick'), 1500); }
  catch (error) { progress.textContent = error.userFacing ? error.message : anGammaSync.error; if (command !== 'start') setTimeout(() => loop('status'), 12000); else start.disabled = false; }
  finally { working = false; }
 }
 start.addEventListener('click', () => { start.disabled = true; loop('start'); });
 window.addEventListener('pagehide', () => { stopped = true; });
 loop();
})();
