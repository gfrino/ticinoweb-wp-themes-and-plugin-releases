<?php
/** Shared native page layout. @package AutonecChildTheme */
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header(); ?>
<main id="main-content" class="an-wrap an-native-page" tabindex="-1">
 <?php while ( have_posts() ) : the_post(); ?>
 <article <?php post_class( 'default-article entry-content' ); ?>>
  <h1><?php the_title(); ?></h1>
  <?php the_content(); ?>
 </article>
 <?php endwhile; ?>
</main>
<?php get_footer(); ?>
