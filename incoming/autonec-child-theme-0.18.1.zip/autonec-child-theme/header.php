<?php
/** Shared Autonec header. @package AutonecChildTheme */
if ( ! defined( 'ABSPATH' ) ) { exit; }
$logo = ticinoweb_get_site_logo();
?><!doctype html>
<html <?php language_attributes(); ?>>
<head><meta charset="<?php bloginfo( 'charset' ); ?>"><meta name="viewport" content="width=device-width, initial-scale=1"><?php
// Establish the enhanced layout before paint; retain native navigation if its script fails.
wp_print_inline_script_tag( "document.documentElement.classList.add('an-js');document.addEventListener('DOMContentLoaded',function(){if(document.documentElement.hasAttribute('data-an-navigation-ready'))return;document.documentElement.classList.remove('an-js');document.querySelectorAll('.an-menu-toggle,.an-catalogue-toggle').forEach(function(button){button.hidden=true;});document.querySelectorAll('.an-catalogue-menu').forEach(function(panel){panel.hidden=false;panel.inert=false;});});", array( 'id' => 'autonec-layout-bootstrap' ) );
wp_head(); ?></head>
<body <?php body_class( 'an-site' ); ?>>
<?php wp_body_open(); ?>
<a class="an-skip" href="#main-content"><?php esc_html_e( 'Vai al contenuto', 'autonec-child-theme' ); ?></a>
<header class="an-header">
 <a class="an-logo" href="<?php echo esc_url( home_url( '/' ) ); ?>" aria-label="<?php echo esc_attr( autonec_site_name() ); ?>">
  <?php if ( $logo ) : ?><img src="<?php echo esc_url( $logo ); ?>" alt="<?php echo esc_attr( autonec_site_name() ); ?>" width="150" height="41"><?php else : echo esc_html( autonec_site_name() ); endif; ?>
 </a>
 <button class="an-menu-toggle" type="button" aria-controls="an-navigation" aria-expanded="false" hidden><span><?php esc_html_e( 'Menu', 'autonec-child-theme' ); ?></span><i aria-hidden="true"></i></button>
 <nav id="an-navigation" class="an-navigation" aria-label="<?php esc_attr_e( 'Navigazione principale', 'autonec-child-theme' ); ?>"><?php wp_nav_menu( array( 'theme_location' => 'primary', 'container' => false, 'menu_class' => 'an-menu', 'fallback_cb' => false ) ); ?></nav>
 <a class="an-header__contact" href="<?php echo esc_url( autonec_section_url( 'contact' ) ?: home_url( '/#contatti' ) ); ?>"><?php esc_html_e( 'Parliamone', 'autonec-child-theme' ); ?></a>
</header>
