<?php
/** Shared Autonec footer. @package AutonecChildTheme */
if ( ! defined( 'ABSPATH' ) ) { exit; }
$contact = ticinoweb_get_contact_info();
$closing = ticinoweb_frontend_text( (string) get_post_field( 'post_excerpt', (int) get_option( 'page_on_front' ) ), 'autonec:closing:title' );
$phone = $contact['phone_display'] ?: $contact['phone'];
$contact_url = autonec_section_url( 'contact' );
$logo = ticinoweb_get_site_logo();
?>
<footer class="an-footer" id="contatti">
 <div class="an-wrap">
  <div class="an-footer__top">
   <div class="an-footer__invitation">
    <h2><?php echo $closing ? nl2br( esc_html( $closing ) ) : esc_html__( 'Contatti', 'autonec-child-theme' ); ?></h2>
    <?php if ( $contact_url ) : ?><a class="an-link" href="<?php echo esc_url( $contact_url ); ?>"><?php esc_html_e( 'Contattaci', 'autonec-child-theme' ); ?></a><?php endif; ?>
   </div>
   <div class="an-footer__contacts">
    <?php if ( $phone ) : ?><a class="an-footer__phone" href="tel:<?php echo esc_attr( preg_replace( '/[^+0-9]/', '', $contact['phone'] ?: $phone ) ); ?>"><?php echo esc_html( $phone ); ?></a><?php endif; ?>
    <?php if ( $contact['email'] ) : ?><a href="mailto:<?php echo esc_attr( sanitize_email( $contact['email'] ) ); ?>"><?php echo esc_html( $contact['email'] ); ?></a><?php endif; ?>
   </div>
  </div>
  <div class="an-footer__directory">
   <?php if ( $contact['address'] || $contact['address_2'] ) : ?>
   <section class="an-footer__locations" aria-labelledby="an-footer-locations">
    <h3 id="an-footer-locations"><?php esc_html_e( 'Dove trovarci', 'autonec-child-theme' ); ?></h3>
    <?php foreach ( array( '', '_2' ) as $suffix ) : $address = $contact['address' . $suffix]; if ( $suffix ) { $address = ticinoweb_frontend_text( $address, 'theme:contact:address' . $suffix ); } $label = $contact[ 'address' . $suffix . '_label' ]; if ( ! $address ) { continue; } ?>
    <address>
     <?php if ( $label ) : ?><p class="an-footer__location-name"><?php echo esc_html( ticinoweb_frontend_text( $label, 'theme:contact:address' . $suffix . '_label' ) ); ?></p><?php endif; ?>
     <a href="<?php echo esc_url( 'https://www.google.com/maps/search/?api=1&query=' . rawurlencode( $address ) ); ?>" target="_blank" rel="noopener noreferrer"><?php echo nl2br( esc_html( $address ) ); ?></a>
    </address>
    <?php endforeach; ?>
   </section>
   <?php endif; ?>
   <?php autonec_footer_navigation( 'footer', __( 'Esplora', 'autonec-child-theme' ) ); ?>
   <?php autonec_footer_navigation( 'footer_brands', __( 'Marchi', 'autonec-child-theme' ) ); ?>
   <?php autonec_footer_navigation( 'footer_legal', __( 'Informazioni legali', 'autonec-child-theme' ) ); ?>
  </div>
  <div class="an-footer__bottom">
   <div class="an-footer__signature">
    <a class="an-footer__logo" href="<?php echo esc_url( home_url( '/' ) ); ?>" aria-label="<?php echo esc_attr( autonec_site_name() ); ?>"><?php if ( $logo ) : ?><img src="<?php echo esc_url( $logo ); ?>" alt="<?php echo esc_attr( autonec_site_name() ); ?>" width="150" height="41" loading="lazy"><?php else : echo esc_html( autonec_site_name() ); endif; ?></a>
    <p>© <?php echo esc_html( wp_date( 'Y' ) . ' ' . autonec_site_name() ); ?><?php if ( $contact['vat'] ) : ?><span><?php echo esc_html( $contact['vat'] ); ?></span><?php endif; ?></p>
   </div>
   <div class="an-footer__utility">
    <a href="<?php echo esc_url( wp_login_url( admin_url() ) ); ?>"><?php esc_html_e( 'Area riservata', 'autonec-child-theme' ); ?></a>
    <a href="https://ticinoweb.com" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Sito realizzato da', 'autonec-child-theme' ); ?> <span>ticinoWEB</span></a>
   </div>
  </div>
 </div>
</footer>
<?php wp_footer(); ?>
</body></html>
