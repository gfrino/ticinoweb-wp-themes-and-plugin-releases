<?php
/** Template Name: Chi siamo Autonec
 * THESIS: The real place, verified history and people explain the relationship behind Autonec.
 * OWN-WORLD: Approved charcoal, Barlow, white constructor marks and restrained red actions.
 * STORY: Meet the place, travel through its history, meet its people, then choose a visit or service.
 * FIRST VIEWPORT: Native page label, a large editorial statement, actual building and introduction.
 * FORM: Sede prima, candidate3 / 96800e75. A rising history sheet covers the real place; dates follow native scroll, then open chapters.
 * @package AutonecChildTheme */
defined('ABSPATH') || exit;
get_header(); ?>
<main id="main-content" class="an-company-page" tabindex="-1">
 <?php while(have_posts()):the_post(); ?>
 <header class="an-company-heading an-wrap">
  <h1><?php the_title(); ?></h1>
  <?php if(has_excerpt()):?><p class="an-company-statement"><?php echo nl2br(esc_html(get_the_excerpt()));?></p><?php endif;?>
 </header>
 <div class="an-company-content entry-content"><?php the_content();?></div>
 <?php endwhile;?>
</main>
<?php get_footer(); ?>
