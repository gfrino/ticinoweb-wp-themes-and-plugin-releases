<?php
/** Template Name: Contatti Autonec
 * Agenda a vista: direct contacts stay in view while the two CMS locations unfold.
 * Established charcoal/Barlow/red; native page copy and CMS addresses, no form.
 * First view: title/phone/email left, arrival information right. Candidate6,104eded5.
 * @package AutonecChildTheme */
if ( ! defined( 'ABSPATH' ) ) { exit; }
$contact = ticinoweb_get_contact_info();
$phone = $contact['phone_display'] ?: $contact['phone'];
get_header(); ?>
<main id="main-content" class="an-contact-page an-wrap" tabindex="-1">
 <?php while ( have_posts() ) : the_post(); ?>
 <div class="an-contact-page__layout">
  <div class="an-contact-page__summary">
   <header>
    <h1><?php the_title(); ?></h1>
    <?php if ( has_excerpt() ) : ?><div class="an-contact-page__lead"><?php the_excerpt(); ?></div><?php endif; ?>
   </header>
   <div class="an-contact-page__direct">
    <?php if ( $phone ) : ?><div><p class="an-contact-page__label"><?php esc_html_e( 'Chiamaci', 'autonec-child-theme' ); ?></p><a class="an-contact-page__phone" href="tel:<?php echo esc_attr( preg_replace( '/[^+0-9]/', '', $contact['phone'] ?: $phone ) ); ?>"><?php echo esc_html( $phone ); ?></a></div><?php endif; ?>
    <?php if ( $contact['email'] ) : ?><div><p class="an-contact-page__label"><?php esc_html_e( 'Scrivici', 'autonec-child-theme' ); ?></p><a class="an-contact-page__email" href="<?php echo esc_url( 'mailto:' . sanitize_email( $contact['email'] ) ); ?>"><?php echo esc_html( $contact['email'] ); ?></a></div><?php endif; ?>
    <?php foreach ( array( 'phone_landline'=>__( 'Telefono fisso', 'autonec-child-theme' ), 'phone_mobile'=>__( 'Cellulare', 'autonec-child-theme' ) ) as $key=>$label ) : if ( empty( $contact[$key] ) || preg_replace('/\D/','',$contact[$key]) === preg_replace('/\D/','',$phone) ) { continue; } ?>
    <div class="an-contact-page__additional"><p class="an-contact-page__label"><?php echo esc_html( $label ); ?></p><a href="tel:<?php echo esc_attr( preg_replace( '/[^+0-9]/', '', $contact[$key] ) ); ?>"><?php echo esc_html( $contact[$key] ); ?></a></div>
    <?php endforeach; ?>
    <?php foreach ( array( 'email_2', 'email_3' ) as $key ) : if ( empty( $contact[$key] ) || $contact[$key] === $contact['email'] ) { continue; } ?><a class="an-contact-page__email" href="<?php echo esc_url( 'mailto:' . sanitize_email( $contact[$key] ) ); ?>"><?php echo esc_html( $contact[$key] ); ?></a><?php endforeach; ?>
   </div>
   <?php $hours = autonec_contact_hours( $contact['opening_hours'] ); if ( $hours || $contact['opening_hours_note'] ) : ?>
   <section class="an-contact-page__hours" aria-labelledby="an-contact-hours"><h2 id="an-contact-hours"><?php esc_html_e( 'Orari', 'autonec-child-theme' ); ?></h2>
    <?php if ( $hours ) : ?><dl class="an-hours"><?php foreach ( $hours as $day=>$value ) : ?><div><dt><?php echo esc_html( $day ); ?></dt><dd><?php echo esc_html( $value ); ?></dd></div><?php endforeach; ?></dl><?php endif; ?>
    <?php if ( $contact['opening_hours_note'] ) : ?><p><?php echo esc_html( $contact['opening_hours_note'] ); ?></p><?php endif; ?>
   </section>
   <?php endif; ?>
   <?php $socials = autonec_contact_socials( $contact ); if ( $socials ) : ?><nav class="an-contact-page__social" aria-label="<?php esc_attr_e( 'Social', 'autonec-child-theme' ); ?>"><?php foreach ( $socials as $social ) : ?><a href="<?php echo esc_url( $social['url'] ); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html( $social['label'] ); ?></a><?php endforeach; ?></nav><?php endif; ?>
  </div>
  <div class="an-contact-page__places entry-content"><?php the_content(); ?></div>
 </div>
 <?php endwhile; ?>
</main>
<?php get_footer(); ?>
