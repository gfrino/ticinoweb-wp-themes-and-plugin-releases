<?php
/**
 * Autonec child theme presentation and native CMS integration.
 *
 * @package AutonecChildTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once get_stylesheet_directory() . '/inc/media-presentation.php';
require_once get_stylesheet_directory() . '/inc/home-data.php';
require_once get_stylesheet_directory() . '/inc/about-presentation.php';
require_once get_stylesheet_directory() . '/inc/brand-presentation.php';
require_once get_stylesheet_directory() . '/inc/showroom-presentation.php';
require_once get_stylesheet_directory() . '/inc/services-presentation.php';
require_once get_stylesheet_directory() . '/inc/footer-presentation.php';
require_once get_stylesheet_directory() . '/inc/contact-presentation.php';
require_once get_stylesheet_directory() . '/inc/catalogue.php';
require_once get_stylesheet_directory() . '/inc/catalogue-carmarket.php';
require_once get_stylesheet_directory() . '/inc/catalogue-sync.php';
require_once get_stylesheet_directory() . '/inc/catalogue-admin.php';
require_once get_stylesheet_directory() . '/inc/catalogue-presentation.php';
require_once get_stylesheet_directory() . '/inc/catalogue-navigation.php';
require_once get_stylesheet_directory() . '/inc/catalogue-editor.php';
require_once get_stylesheet_directory() . '/inc/gamma.php';
require_once get_stylesheet_directory() . '/inc/gamma-admin.php';
require_once get_stylesheet_directory() . '/inc/gamma-presentation.php';
require_once get_stylesheet_directory() . '/inc/gamma-http.php';
require_once get_stylesheet_directory() . '/inc/gamma-media.php';
require_once get_stylesheet_directory() . '/inc/gamma-providers/opel.php';
require_once get_stylesheet_directory() . '/inc/gamma-providers/hyundai.php';
require_once get_stylesheet_directory() . '/inc/gamma-providers/leapmotor.php';
require_once get_stylesheet_directory() . '/inc/gamma-providers/piaggio.php';
require_once get_stylesheet_directory() . '/inc/gamma-sync-data.php';
require_once get_stylesheet_directory() . '/inc/gamma-sync.php';
require_once get_stylesheet_directory() . '/inc/gamma-sync-admin.php';
require_once get_stylesheet_directory() . '/inc/seo-presentation.php';

/** Local full-glyph WOFF2 fonts: preload only the three faces used above the fold. */
add_action( 'wp_head', static function() {
 foreach ( array( 'barlow-400', 'barlow-600', 'barlow-condensed-700' ) as $face ) {
  printf( '<link rel="preload" href="%s" as="font" type="font/woff2" crossorigin>', esc_url( get_stylesheet_directory_uri() . '/assets/fonts/' . $face . '.woff2' ) );
 }
}, 1 );

/**
 * Load the child text domain without replacing the parent setup.
 *
 * @return void
 */
function autonec_child_setup() {
	load_child_theme_textdomain( 'autonec-child-theme', get_stylesheet_directory() . '/languages' );
	add_post_type_support( 'page', 'excerpt' );
	add_post_type_support( 'page', 'thumbnail' );
	register_nav_menu( 'footer', __( 'Collegamenti footer', 'autonec-child-theme' ) );
}
add_action( 'after_setup_theme', 'autonec_child_setup' );

/**
 * Load the real parent stylesheet once, followed by the versioned child CSS.
 *
 * The parent registers get_stylesheet_uri(), which points at the child when
 * a child is active. Replace that registration without changing parent files.
 * The child uses local fonts and its own Home choreography.
 *
 * @return void
 */
function autonec_child_assets() {
	wp_dequeue_style( 'ticinoweb-ai-style' );
	wp_deregister_style( 'ticinoweb-ai-style' );
	wp_dequeue_style( 'poppins-font' );
	wp_dequeue_script( 'ticinoweb-ai-main' );

	wp_enqueue_style(
		'autonec-parent-style',
		get_template_directory_uri() . '/style.css',
		array(),
		wp_get_theme( get_template() )->get( 'Version' )
	);

	wp_enqueue_style(
		'autonec-child-style',
		get_stylesheet_uri(),
		array( 'autonec-parent-style' ),
		wp_get_theme()->get( 'Version' )
	);
	$primary = sanitize_hex_color( get_option( 'ticinoweb_palette_primary', '#ba1721' ) ) ?: '#ba1721';
	wp_add_inline_style( 'autonec-child-style', ':root{--an-red:' . $primary . ';--tw-cookie-primary:' . $primary . ';}' );
	wp_enqueue_style( 'autonec-site', get_stylesheet_directory_uri() . '/assets/css/site.css', array( 'autonec-child-style' ), wp_get_theme()->get( 'Version' ) );
 wp_enqueue_style( 'autonec-catalogue-navigation', get_stylesheet_directory_uri() . '/assets/css/catalogue-navigation.css', array('autonec-site'), wp_get_theme()->get('Version') . '.' . filemtime( get_stylesheet_directory() . '/assets/css/catalogue-navigation.css' ) );
 wp_enqueue_script( 'autonec-lenis', get_stylesheet_directory_uri() . '/assets/vendor/lenis/lenis.min.js', array(), '1.3.27', true );
 wp_enqueue_script( 'autonec-scroll', get_stylesheet_directory_uri() . '/assets/js/smooth-scroll.js', array('autonec-lenis'), wp_get_theme()->get('Version') . '.' . filemtime(get_stylesheet_directory() . '/assets/js/smooth-scroll.js'), true );
	wp_enqueue_script( 'autonec-navigation', get_stylesheet_directory_uri() . '/assets/js/navigation.js', array(), wp_get_theme()->get( 'Version' ), true );
	if ( is_front_page() ) {
		wp_enqueue_style( 'autonec-home', get_stylesheet_directory_uri() . '/assets/css/home.css', array( 'autonec-site' ), wp_get_theme()->get( 'Version' ) );
			wp_enqueue_script( 'autonec-journey', get_stylesheet_directory_uri() . '/assets/js/journey.js', array(), wp_get_theme()->get( 'Version' ), true );
		wp_enqueue_script( 'autonec-home', get_stylesheet_directory_uri() . '/assets/js/home.js', array( 'autonec-scroll', 'autonec-journey' ), wp_get_theme()->get( 'Version' ) . '.' . filemtime( get_stylesheet_directory() . '/assets/js/home.js' ), true );
	}
 if ( is_page_template( array( 'template-marque.php', 'template-marques.php' ) ) ) {
  wp_enqueue_style( 'autonec-brands', get_stylesheet_directory_uri() . '/assets/css/brands.css', array( 'autonec-site' ), wp_get_theme()->get( 'Version' ) );
  wp_enqueue_script( 'autonec-brands', get_stylesheet_directory_uri() . '/assets/js/brands.js', array( 'autonec-scroll' ), wp_get_theme()->get( 'Version' ) . '.' . filemtime( get_stylesheet_directory() . '/assets/js/brands.js' ), true );
 }

 if ( is_front_page() || is_page_template( array( 'template-marque.php', 'template-marques.php' ) ) ) {
  wp_enqueue_style( 'autonec-brand-navigation', get_stylesheet_directory_uri() . '/assets/css/brand-navigation.css', array( is_front_page() ? 'autonec-home' : 'autonec-brands' ), wp_get_theme()->get( 'Version' ) );
 }

 if ( is_page_template( 'template-about.php' ) ) {
  wp_enqueue_style( 'autonec-about', get_stylesheet_directory_uri() . '/assets/css/about.css', array('autonec-site'), wp_get_theme()->get('Version') . '.' . filemtime(get_stylesheet_directory() . '/assets/css/about.css') );
  wp_enqueue_script( 'autonec-about', get_stylesheet_directory_uri() . '/assets/js/about.js', array('autonec-scroll'), wp_get_theme()->get('Version') . '.' . filemtime(get_stylesheet_directory() . '/assets/js/about.js'), true );
 }

 if ( is_page_template( 'template-contact.php' ) ) {
  wp_enqueue_style( 'autonec-contact', get_stylesheet_directory_uri() . '/assets/css/contact.css', array( 'autonec-site' ), wp_get_theme()->get( 'Version' ) );
  wp_enqueue_script( 'autonec-contact', get_stylesheet_directory_uri() . '/assets/js/contact.js', array( 'autonec-scroll' ), wp_get_theme()->get( 'Version' ) . '.' . filemtime( get_stylesheet_directory() . '/assets/js/contact.js' ), true );
 }

 if ( is_page_template( 'template-legal.php' ) ) {
  wp_enqueue_style( 'autonec-legal', get_stylesheet_directory_uri() . '/assets/css/legal.css', array( 'autonec-site' ), wp_get_theme()->get( 'Version' ) );
 }

 if ( is_page_template( 'template-services.php' ) ) {
  wp_enqueue_style( 'autonec-services', get_stylesheet_directory_uri() . '/assets/css/services.css', array( 'autonec-site' ), wp_get_theme()->get( 'Version' ) );
  wp_enqueue_script( 'autonec-services', get_stylesheet_directory_uri() . '/assets/js/services.js', array( 'autonec-scroll' ), wp_get_theme()->get( 'Version' ) . '.' . filemtime( get_stylesheet_directory() . '/assets/js/services.js' ), true );
 }

 if ( is_page_template( 'template-autonec-365.php' ) ) {
  wp_enqueue_style( 'autonec-showroom', get_stylesheet_directory_uri() . '/assets/css/showroom.css', array( 'autonec-site' ), wp_get_theme()->get( 'Version' ) );
  wp_enqueue_script( 'autonec-showroom', get_stylesheet_directory_uri() . '/assets/js/showroom.js', array( 'autonec-scroll' ), wp_get_theme()->get( 'Version' ) . '.' . filemtime( get_stylesheet_directory() . '/assets/js/showroom.js' ), true );
 }
}
add_action( 'wp_enqueue_scripts', 'autonec_child_assets', 20 );

/** Render an existing CMS image with Media Library responsive sizes and alt. */
function autonec_image( $data, $class = '', $eager = false ) {
	$attributes = array( 'class' => $class, 'loading' => $eager ? 'eager' : 'lazy', 'decoding' => 'async' );
	if ( $eager ) { $attributes['fetchpriority'] = 'high'; }
	if ( ! empty( $data['image_id'] ) ) {
		echo wp_get_attachment_image( $data['image_id'], 'full', false, $attributes ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	} elseif ( ! empty( $data['image'] ) ) {
		printf( '<img src="%s" alt="%s" class="%s" loading="%s" decoding="async">', esc_url( $data['image'] ), esc_attr( $data['title'] ?? '' ), esc_attr( $class ), $eager ? 'eager' : 'lazy' );
	}
}

/** Find native section pages by their assigned template, never a fixed slug/ID. */
function autonec_section_url( $section ) {
 static $urls = null;
 if ( null === $urls ) {
  $urls = array();
  foreach ( array( 'marques', 'services', 'contact' ) as $key ) {
   $pages = get_posts( array( 'post_type'=>'page', 'post_status'=>'publish', 'posts_per_page'=>1, 'no_found_rows'=>true, 'suppress_filters'=>false, 'orderby'=>'ID', 'order'=>'ASC', 'meta_key'=>'_wp_page_template', 'meta_value'=>'template-' . $key . '.php' ) );
   if ( $pages ) { $urls[$key] = get_permalink( $pages[0] ); }
  }
 }
 return $urls[$section] ?? '';
}
