<?php
/** Template Name: Servizi Autonec
 * @package AutonecChildTheme */
if ( ! defined( 'ABSPATH' ) ) { exit; }
$services = autonec_services_presentation();
$contact = autonec_section_url( 'contact' );
get_header(); ?>
<main id="main-content" class="an-services-page" tabindex="-1">
 <?php while ( have_posts() ) : the_post(); ?>
 <section class="an-services-hero<?php if ( ! has_post_thumbnail() ) { echo ' has-no-photo'; } ?>" aria-labelledby="an-services-title">
  <div class="an-services-hero__stage">
   <?php if ( has_post_thumbnail() ) : ?><figure class="an-services-hero__photo"><?php the_post_thumbnail( 'full', array( 'loading'=>'eager', 'fetchpriority'=>'high', 'decoding'=>'async' ) ); ?></figure><?php endif; ?>
   <div class="an-services-hero__copy">
    <h1 id="an-services-title"><?php the_title(); ?></h1>
    <?php if ( has_excerpt() ) : ?><div class="an-services-hero__lead"><?php the_excerpt(); ?></div><?php endif; ?>
    <div class="an-services-hero__intro"><?php the_content(); ?></div>
   </div>
  </div>
 </section>
 <?php endwhile; ?>
 <?php if ( $services ) : ?>
 <nav class="an-services-index an-wrap" aria-label="<?php esc_attr_e( 'Navigazione servizi', 'autonec-child-theme' ); ?>">
  <?php foreach ( $services as $service ) : ?><a href="#<?php echo esc_attr( $service['anchor'] ); ?>"><?php echo esc_html( $service['title'] ); ?></a><?php endforeach; ?>
 </nav>
 <?php endif; ?>
 <div id="servizi" class="an-services-collection">
 <?php foreach ( $services as $service ) : ?>
  <section id="<?php echo esc_attr( $service['anchor'] ); ?>" class="an-service-chapter an-wrap<?php if ( empty( $service['image'] ) ) { echo ' is-text-only'; } ?>" aria-labelledby="<?php echo esc_attr( $service['anchor'] . '-title' ); ?>">
   <h2 id="<?php echo esc_attr( $service['anchor'] . '-title' ); ?>"><?php echo esc_html( $service['title'] ); ?></h2>
   <?php if ( ! empty( $service['image'] ) ) : ?><figure class="an-service-chapter__photo"><?php autonec_image( $service ); ?></figure><?php endif; ?>
   <div class="an-service-chapter__body">
    <?php echo wp_kses_post( wpautop( $service['description'] ?? '' ) ); ?>
    <?php if ( $contact ) : ?><a class="an-link" href="<?php echo esc_url( $contact ); ?>" aria-label="<?php echo esc_attr( sprintf( __( 'Parliamo di %s', 'autonec-child-theme' ), $service['title'] ) ); ?>"><?php esc_html_e( 'Parliamone', 'autonec-child-theme' ); ?></a><?php endif; ?>
   </div>
  </section>
 <?php endforeach; ?>
 <?php if ( ! $services ) : ?><section class="an-services-empty an-wrap"><p><?php esc_html_e( 'Per informazioni sui servizi, contatta il nostro team.', 'autonec-child-theme' ); ?></p><?php if ( $contact ) : ?><a class="an-link" href="<?php echo esc_url( $contact ); ?>"><?php esc_html_e( 'Parliamone', 'autonec-child-theme' ); ?></a><?php endif; ?></section><?php endif; ?>
 </div>
</main>
<?php get_footer(); ?>
