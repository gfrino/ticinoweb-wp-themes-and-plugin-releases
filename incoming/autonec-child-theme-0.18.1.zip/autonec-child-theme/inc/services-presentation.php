<?php
/** Native CMS service presentation. @package AutonecChildTheme */
if ( ! defined( 'ABSPATH' ) ) { exit; }

/** Rich descriptions have one source; Home shows their first paragraph. */
function autonec_service_summary( $description ) {
 $html = wpautop( (string) $description );
 if ( preg_match( '/<p\b[^>]*>(.*?)<\/p>/is', $html, $paragraph ) ) { $html = $paragraph[1]; }
 return wp_trim_words( wp_strip_all_tags( $html ), 42 );
}

/** Keep stable native service IDs for anchors and existing Media image inputs. */
function autonec_services_presentation() {
 $result = array(); $used = array();
 foreach ( autonec_home_services() as $key => $service ) {
  if ( empty( $service['title'] ) ) { continue; }
  $anchor = 'servizio-' . ( sanitize_key( $service['id'] ?? '' ) ?: 'voce-' . ( count( $result ) + 1 ) );
  if ( isset( $used[$anchor] ) ) { $anchor .= '-' . ( count( $result ) + 1 ); }
  $used[$anchor] = true;
  $service['anchor'] = $anchor;
  $service['image_id'] = autonec_home_image_id( $service['image'] ?? '' );
  $result[] = $service;
 }
 return $result;
}

/** Enhance the parent's existing description input, keeping its storage/save flow. */
function autonec_service_editor_assets() {
 if ( ! current_user_can( 'manage_options' ) || ! isset( $_GET['page'] ) || 'ticinoweb-cms' !== sanitize_key( wp_unslash( $_GET['page'] ) ) ) { return; } // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only screen selection.
 wp_enqueue_editor();
 wp_enqueue_script( 'autonec-service-editor', get_stylesheet_directory_uri() . '/assets/js/service-editor.js', array( 'editor' ), wp_get_theme()->get( 'Version' ), true );
}
add_action( 'admin_enqueue_scripts', 'autonec_service_editor_assets' );
