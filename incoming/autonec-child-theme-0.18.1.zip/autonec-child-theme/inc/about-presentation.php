<?php
/** Native company page and one shared introduction, using existing parent integration hooks. */
defined('ABSPATH') || exit;

/** The published native page owns its contents; no duplicated about settings are introduced. */
function autonec_about_page() {
 static $id = null;
 if (null === $id) {
  $ids=get_posts(array('post_type'=>'page','post_status'=>'publish','fields'=>'ids','posts_per_page'=>1,'no_found_rows'=>true,'suppress_filters'=>false,'orderby'=>'ID','order'=>'ASC','meta_key'=>'_wp_page_template','meta_value'=>'template-about.php'));
  $id=$ids ? (int)$ids[0] : 0;
 }
 return $id ? get_post($id) : null;
}

/** Only the labelled introduction feeds Home, never another chapter or a hidden fallback. */
function autonec_about_summary($content) {
 $find=function($blocks)use(&$find){
  foreach($blocks as$block){
   $classes=preg_split('/\s+/', $block['attrs']['className']??'');
   if(in_array('an-company-summary',$classes,true)){
    $paragraph=function($children)use(&$paragraph){foreach($children as$child){if('core/paragraph'===($child['blockName']??''))return html_entity_decode(wp_strip_all_tags($child['innerHTML']),ENT_QUOTES|ENT_HTML5,'UTF-8');if(!empty($child['innerBlocks'])){$value=$paragraph($child['innerBlocks']);if($value!=='')return$value;}}return '';};
    return $paragraph($block['innerBlocks']??array());
   }
   if(!empty($block['innerBlocks'])){$value=$find($block['innerBlocks']);if($value!==null)return$value;}
  }
  return null;
 };
 return trim((string)$find(parse_blocks((string)$content)));
}

/** Existing parent CMS has a dedicated hook for pages managed through native Core blocks. */
function autonec_about_managed_notice($notice) {
 $page=autonec_about_page();
 if(!$page)return$notice;
 $link='<a href="'.esc_url(get_edit_post_link($page->ID,'raw')).'">'.esc_html(get_the_title($page)).'</a>';
 return sprintf(__('Modifica %s per aggiornare testi, immagini e pulsanti. Il riassunto e il primo paragrafo dell’introduzione alimentano anche la Home.','autonec-child-theme'),$link);
}
add_filter('ticinoweb_chi_siamo_managed_notice','autonec_about_managed_notice');

/** Add live constructor links to the named native group; edit the source in the existing CMS Slider. */
function autonec_about_brands($html,$block) {
 if(!is_page_template('template-about.php')||!in_array('an-company-marques',preg_split('/\s+/', $block['attrs']['className']??''),true))return$html;
 $brands=autonec_brand_pages();if(!$brands)return$html;
 ob_start();?><nav class="an-company-brands" aria-label="<?php esc_attr_e('Navigazione marchi','autonec-child-theme');?>">
 <?php foreach($brands as$brand):?><a href="<?php echo esc_url($brand['button_url']);?>"><span class="an-company-brand-photo"><?php if($brand['image_id'])echo wp_get_attachment_image($brand['image_id'],'large',false,array('alt'=>'','aria-hidden'=>'true','loading'=>'lazy','sizes'=>'(max-width: 599px) 90vw, (max-width: 999px) 45vw, 23vw'));?></span><span class="an-company-brand-identity"><?php if($brand['logo_id'])echo wp_get_attachment_image($brand['logo_id'],'medium',false,array('alt'=>'','aria-hidden'=>'true','loading'=>'lazy','sizes'=>'140px'));?><span><?php echo esc_html(rtrim($brand['title'],'. '));?></span></span></a><?php endforeach;?>
 </nav><?php $links=ob_get_clean();
 return preg_replace_callback('/(<\/(?:div|section|article)>\s*)$/',static fn($match)=>$links.$match[0],$html,1);
}
add_filter('render_block_core/group','autonec_about_brands',20,2);

/** Keep the main real photograph responsive and fetch it promptly. */
function autonec_about_images($html,$block) {
 if(!is_page_template('template-about.php'))return$html;
 $processor=new WP_HTML_Tag_Processor($html);
 if($processor->next_tag('IMG')){
  $portrait=in_array('an-company-portrait',preg_split('/\s+/', $block['attrs']['className']??''),true);
  $processor->set_attribute('sizes',$portrait?'160px':'(max-width: 899px) 100vw, 54vw');
  if(in_array('an-company-photo',preg_split('/\s+/', $block['attrs']['className']??''),true)){
   $processor->set_attribute('loading','eager');$processor->set_attribute('fetchpriority','high');
  }
 }
 return$processor->get_updated_html();
}
add_filter('render_block_core/image','autonec_about_images',20,2);
