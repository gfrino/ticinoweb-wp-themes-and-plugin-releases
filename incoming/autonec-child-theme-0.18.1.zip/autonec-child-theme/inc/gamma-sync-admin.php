<?php
/** Native range sources. Credentials, routes and inventory are not duplicated. */
defined('ABSPATH') || exit;
function autonec_gamma_can_manage(){return current_user_can('manage_options');}
add_action('admin_menu',static function(){add_submenu_page('edit.php?post_type=modelli',__('Fonti e aggiornamenti','autonec-child-theme'),__('Fonti e aggiornamenti','autonec-child-theme'),'manage_options','an-gamma-sources','autonec_gamma_sources_page');});
function autonec_gamma_sources_page(){
 if(!autonec_gamma_can_manage())return;
 $error='';$saved=false;
 if(isset($_POST['an_gamma_sources_nonce'])){
  check_admin_referer('an_gamma_sources','an_gamma_sources_nonce');
  if(get_option('an_gamma_job'))$error=__('Attendi la fine dell’aggiornamento prima di cambiare le fonti.','autonec-child-theme');
  else{$sources=autonec_gamma_clean_sources(wp_unslash($_POST['an_gamma_sources']??array()));if(is_wp_error($sources))$error=$sources->get_error_message();else{update_option('an_gamma_sources',$sources,false);$saved=true;}}
 }
 $sources=array_column(autonec_gamma_sources(),null,'provider');$statuses=(array)get_option('an_gamma_source_status',array());$state=autonec_gamma_state();
 ?>
 <div class="wrap"><h1><?php esc_html_e('Gamma nuova: fonti e aggiornamenti','autonec-child-theme');?></h1>
 <p><?php esc_html_e('Le gamme vengono controllate ogni giorno sui siti ufficiali svizzeri. Testi e foto modificati dal CMS sono conservati. Le occasioni seguono le proprie fonti nel menu Veicoli.','autonec-child-theme');?></p>
 <?php if($error):?><div class="notice notice-error"><p><?php echo esc_html($error);?></p></div><?php endif;?>
 <?php if($saved):?><div class="notice notice-success"><p><?php esc_html_e('Fonti salvate.','autonec-child-theme');?></p></div><?php endif;?>
 <form method="post"><?php wp_nonce_field('an_gamma_sources','an_gamma_sources_nonce');?>
 <table class="widefat striped"><thead><tr><th><?php esc_html_e('Marchio','autonec-child-theme');?></th><th><?php esc_html_e('Pagina ufficiale della gamma','autonec-child-theme');?></th><th><?php esc_html_e('Aggiornamento giornaliero','autonec-child-theme');?></th><th><?php esc_html_e('Ultimo controllo','autonec-child-theme');?></th></tr></thead><tbody>
 <?php $i=0;foreach(autonec_brand_pages() as $brand):$slug=sanitize_title(get_post_meta($brand['page_id'],'_an_catalogue_brand',true));if(!isset(autonec_gamma_providers()[$slug]))continue;$row=$sources[$slug]??array();$status=$statuses[$slug]??array();$name=rtrim(wp_strip_all_tags($brand['title']),'. ');?>
 <tr><th scope="row"><?php echo esc_html($name);?><input type="hidden" name="an_gamma_sources[<?php echo (int)$i;?>][provider]" value="<?php echo esc_attr($slug);?>"><input type="hidden" name="an_gamma_sources[<?php echo (int)$i;?>][brand_slug]" value="<?php echo esc_attr($slug);?>"></th>
 <td><label class="screen-reader-text" for="an-gamma-url-<?php echo esc_attr($slug);?>"><?php echo esc_html($name);?></label><input id="an-gamma-url-<?php echo esc_attr($slug);?>" type="url" name="an_gamma_sources[<?php echo (int)$i;?>][url]" class="large-text" required value="<?php echo esc_attr($row['url']??'');?>"></td>
 <td><label><input type="checkbox" name="an_gamma_sources[<?php echo (int)$i;?>][enabled]" value="1" <?php checked(!empty($row['enabled']));?>><?php esc_html_e('Attivo','autonec-child-theme');?></label></td>
 <td data-gamma-status="<?php echo esc_attr($slug);?>"><?php echo esc_html(!empty($status['success'])?wp_date(get_option('date_format').' H:i',$status['success']):__('Da verificare','autonec-child-theme'));?><br><span><?php echo esc_html($status['message']??'');?></span></td></tr>
 <?php $i++;endforeach;?></tbody></table><?php submit_button();?></form>
 <hr><h2><?php esc_html_e('Aggiorna ora','autonec-child-theme');?></h2>
 <p><?php esc_html_e('Puoi lasciare questa pagina: il lavoro continua in background. Se una fonte non risponde, i modelli esistenti vengono mantenuti. Un modello scomparso dalla gamma viene archiviato solo dopo due controlli completi in giorni diversi.','autonec-child-theme');?></p>
 <p><button class="button button-primary" data-gamma-start <?php disabled((bool)get_option('an_gamma_job'));?>><?php esc_html_e('Sincronizza le gamme','autonec-child-theme');?></button></p>
 <div aria-live="polite" data-gamma-progress><p><?php echo esc_html($state['message']??'');?></p></div>
 <noscript><p><?php esc_html_e('Attiva JavaScript per avviare e seguire un aggiornamento manuale. Il controllo giornaliero resta attivo.','autonec-child-theme');?></p></noscript>
 <p><?php esc_html_e('Le fotografie del costruttore illustrano il modello. La gamma non indica una giacenza né un prezzo del singolo veicolo.','autonec-child-theme');?></p>
 </div><?php
}
add_action('admin_enqueue_scripts',static function($hook){if(strpos($hook,'an-gamma-sources')===false)return;wp_enqueue_script('autonec-gamma-sync-admin',get_stylesheet_directory_uri().'/assets/js/gamma-sync-admin.js',array(),wp_get_theme()->get('Version'),true);wp_localize_script('autonec-gamma-sync-admin','anGammaSync',array('url'=>admin_url('admin-ajax.php'),'nonce'=>wp_create_nonce('an_gamma_sync'),'error'=>__('Aggiornamento non raggiungibile. Riprovo tra poco.','autonec-child-theme')));});
add_action('wp_ajax_an_gamma_sync',static function(){
 if(!autonec_gamma_can_manage())wp_send_json_error(array('message'=>__('Permessi insufficienti.','autonec-child-theme')),403);
 check_ajax_referer('an_gamma_sync','nonce');$command=isset($_POST['command'])&&is_string($_POST['command'])?sanitize_key(wp_unslash($_POST['command'])):'status';
 if($command==='start'){$result=autonec_gamma_start();if(is_wp_error($result))wp_send_json_error(array('message'=>$result->get_error_message()),409);}
 elseif($command==='tick')autonec_gamma_worker();
 elseif($command!=='status')wp_send_json_error(array('message'=>__('Comando non valido.','autonec-child-theme')),400);
 $statuses=(array)get_option('an_gamma_source_status',array());foreach($statuses as &$s){$s['date']=!empty($s['success'])?wp_date(get_option('date_format').' H:i',$s['success']):'';}unset($s);
 wp_send_json_success(array('busy'=>(bool)get_option('an_gamma_job'),'state'=>autonec_gamma_state(),'sources'=>$statuses));
});
