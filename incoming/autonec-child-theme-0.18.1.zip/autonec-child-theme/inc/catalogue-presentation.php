<?php
/** Local vehicle presentation; imported data is read, never fetched here. @package AutonecChildTheme */
if ( ! defined( 'ABSPATH' ) ) { exit; }

/** Load this surface only, retaining the exact shared brand rail. */
function autonec_catalogue_assets() {
 $catalogue = is_page_template( 'template-inventory.php' ) || is_singular( 'veicoli' );
 if ( ! $catalogue && ! is_page_template( 'template-marque.php' ) ) { return; }
 $version = wp_get_theme()->get( 'Version' );
 wp_enqueue_style( 'autonec-catalogue', get_stylesheet_directory_uri() . '/assets/css/catalogue.css', array( 'autonec-site' ), $version );
 if ( $catalogue ) {
  wp_enqueue_style( 'autonec-brand-navigation', get_stylesheet_directory_uri() . '/assets/css/brand-navigation.css', array( 'autonec-catalogue' ), $version );
 }
 if ( $catalogue ) {
  wp_enqueue_script( 'autonec-catalogue', get_stylesheet_directory_uri() . '/assets/js/catalogue.js', array(), $version, true );
 }
}
add_action( 'wp_enqueue_scripts', 'autonec_catalogue_assets', 25 );

/** Sanitize the small public filter vocabulary; no arbitrary query arguments. */
function autonec_catalogue_filters() {
 $filters = array( 'marca'=>'', 'modello'=>'', 'alimentazione'=>'', 'condizione'=>'', 'prezzo_min'=>'', 'prezzo_max'=>'', 'pagina'=>1 );
 foreach ( array( 'marca', 'modello', 'alimentazione', 'condizione' ) as $key ) {
  if ( isset( $_GET[$key] ) && is_string( $_GET[$key] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- public read-only filters.
   $value = sanitize_text_field( wp_unslash( $_GET[$key] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
   $filters[$key] = 'marca' === $key ? sanitize_title( $value ) : mb_substr( $value, 0, 100 );
  }
 }
 foreach(array('prezzo_min','prezzo_max') as $price_key){
  if(isset($_GET[$price_key])&&is_string($_GET[$price_key])){ // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- public read-only filters.
   $value=wp_unslash($_GET[$price_key]); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
   if(preg_match('/^\d{1,9}(?:\.\d{1,2})?$/D',$value)&&(float)$value>0)$filters[$price_key]=$value;
  }
 }
 if ( isset( $_GET['pagina'] ) && is_scalar( $_GET['pagina'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
  $filters['pagina'] = max( 1, min( 100000, absint( $_GET['pagina'] ) ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
 }
 return $filters;
}

/** Translate imported strings through the parent without changing stored query values. */
function autonec_catalogue_text( $value, $context ) {
 return ticinoweb_frontend_text( (string) $value, 'theme:catalogue:' . $context );
}

/** Imported copy keeps readable formatting, without embeds, linked sources, or extra H1s. */
function autonec_catalogue_description( $description, $post_id ) {
 $allowed = array_fill_keys( array( 'p', 'br', 'strong', 'b', 'em', 'i', 'u', 'ul', 'ol', 'li', 'dl', 'dt', 'dd', 'h3', 'h4', 'table', 'thead', 'tbody', 'tr', 'th', 'td', 'span' ), array() );
 return wp_kses( wpautop( autonec_catalogue_text( $description, 'vehicle:' . $post_id . ':description' ) ), $allowed );
}

/** Split real source copy into prose and equipment without creating new claims. */
function autonec_catalogue_description_sections( $description, $post_id ) {
 $html = autonec_catalogue_description( $description, $post_id );
 $result = array( 'intro'=>$html, 'features'=>array() );
 if ( ! class_exists( 'DOMDocument' ) || ! trim( $html ) ) { return $result; }
 $doc = new DOMDocument();
 $previous = libxml_use_internal_errors( true );
 $doc->loadHTML( '<?xml encoding="utf-8" ?><div id="an-source-copy">' . $html . '</div>', LIBXML_NONET | LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD );
 libxml_clear_errors(); libxml_use_internal_errors( $previous );
 $xpath = new DOMXPath( $doc );
 $root = $xpath->query( '//*[@id="an-source-copy"]' )->item(0);
 if ( ! $root ) { return $result; }
 $key = static function( $text ) { return mb_strtolower( trim( preg_replace( '/\s+/u', ' ', html_entity_decode( $text, ENT_QUOTES | ENT_HTML5, 'UTF-8' ) ) ) ); };
 $inner = static function( $node ) use ($doc) { $out=''; foreach($node->childNodes as $child){$out.=$doc->saveHTML($child);} return $out; };
 $seen = array();
 // Top-level list items retain any nested list as part of their own equipment entry.
 foreach ( iterator_to_array( $xpath->query( './/ul[not(ancestor::li)] | .//ol[not(ancestor::li)]', $root ) ) as $list ) {
  foreach ( $list->childNodes as $item ) {
   if ( ! $item instanceof DOMElement || 'li' !== strtolower($item->tagName) ) { continue; }
   $identity = $key($item->textContent);
   if($identity && !isset($seen[$identity])){$result['features'][]=$inner($item);$seen[$identity]=true;}
  }
  $list->parentNode->removeChild($list);
 }
 $seen = array();
 foreach(iterator_to_array($xpath->query('.//p | .//h3 | .//h4',$root)) as $paragraph){
  $identity=$key($paragraph->textContent);
  if(!$identity || isset($seen[$identity])){$paragraph->parentNode->removeChild($paragraph);}else{$seen[$identity]=true;}
 }
 $result['intro']=$inner($root);
 return $result;
}

/** Four CMS-mapped main marques, never a second fixed list. */
function autonec_catalogue_main_brand_slugs() {
 $slugs=array();foreach(autonec_brand_pages() as $page){$slug=sanitize_title((string)get_post_meta($page['page_id'],'_an_catalogue_brand',true));if($slug)$slugs[]=$slug;}
 return array_values(array_unique($slugs));
}

/** Query only local indexed fields; engine supplies available-stock restriction. */
function autonec_catalogue_filter_query_args( $filters ) {
 $args = array( 'posts_per_page'=>12, 'paged'=>$filters['pagina'] );
 if ( $filters['marca'] ) {
  $args['tax_query'] = array( array( 'taxonomy'=>'an_marca', 'field'=>'slug', 'terms'=>'altri' === $filters['marca'] ? autonec_catalogue_main_brand_slugs() : $filters['marca'], 'operator'=>'altri' === $filters['marca'] ? 'NOT IN' : 'IN' ) );
 }
 $meta = array();
 foreach ( array( 'modello'=>'_an_model', 'alimentazione'=>'_an_fuel', 'condizione'=>'_an_condition' ) as $key=>$index ) {
  if ( $filters[$key] ) { $meta[] = array( 'key'=>$index, 'value'=>$filters[$key], 'compare'=>'=' ); }
 }
 if ( '' !== ($filters['prezzo_min']??'') || '' !== $filters['prezzo_max'] ) {
  $meta[] = array('key'=>'_an_currency','value'=>'CHF','compare'=>'=');
  if(''!==($filters['prezzo_min']??''))$meta[]=array('key'=>'_an_price','value'=>(float)$filters['prezzo_min'],'compare'=>'>=','type'=>'DECIMAL(15,2)');
  if(''!==$filters['prezzo_max'])$meta[]=array('key'=>'_an_price','value'=>(float)$filters['prezzo_max'],'compare'=>'<=','type'=>'DECIMAL(15,2)');
 }
 if ( $meta ) { $args['meta_query'] = $meta; }
 return $args;
}

/** Obtain actual stock values in one local bounded query, not a post-by-post scan. */
function autonec_catalogue_facets( $brand = '' ) {
 global $wpdb;
 $join = '';
 $values = array( '_an_model', '_an_fuel', '_an_condition', 'veicoli', 'publish', '_an_availability', 'available' );
 $where = '';
 if ( 'altri' === $brand ) {
  $main = autonec_catalogue_main_brand_slugs();
  if($main){$where=" AND NOT EXISTS (SELECT 1 FROM {$wpdb->term_relationships} tr INNER JOIN {$wpdb->term_taxonomy} tt ON tt.term_taxonomy_id=tr.term_taxonomy_id INNER JOIN {$wpdb->terms} t ON t.term_id=tt.term_id WHERE tr.object_id=p.ID AND tt.taxonomy=%s AND t.slug IN (".implode(',',array_fill(0,count($main),'%s'))."))";$values=array_merge($values,array('an_marca'),$main);}
 } elseif ( $brand ) {
  $join = " INNER JOIN {$wpdb->term_relationships} tr ON tr.object_id=p.ID INNER JOIN {$wpdb->term_taxonomy} tt ON tt.term_taxonomy_id=tr.term_taxonomy_id INNER JOIN {$wpdb->terms} t ON t.term_id=tt.term_id";
  $where = ' AND tt.taxonomy=%s AND t.slug=%s';
  $values[] = 'an_marca';
  $values[] = $brand;
 }
 $sql = "SELECT DISTINCT facts.meta_key, facts.meta_value FROM {$wpdb->postmeta} facts INNER JOIN {$wpdb->posts} p ON p.ID=facts.post_id INNER JOIN {$wpdb->postmeta} stock ON stock.post_id=p.ID{$join} WHERE facts.meta_key IN (%s,%s,%s) AND p.post_type=%s AND p.post_status=%s AND stock.meta_key=%s AND stock.meta_value=%s AND facts.meta_value<>''{$where} ORDER BY facts.meta_value ASC LIMIT 500";
 $rows = $wpdb->get_results( $wpdb->prepare( $sql, $values ), ARRAY_A ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery -- bounded distinct facets, no writes or external calls.
 $facets = array( 'modello'=>array(), 'alimentazione'=>array(), 'condizione'=>array() );
 $keys = array( '_an_model'=>'modello', '_an_fuel'=>'alimentazione', '_an_condition'=>'condizione' );
 foreach ( $rows as $row ) { $facets[ $keys[$row['meta_key']] ][] = $row['meta_value']; }
 return $facets;
}

/** One local facet map lets changing make immediately offer the correct models. */
function autonec_catalogue_facet_map() {
 global $wpdb;
 $sql="SELECT DISTINCT t.slug, f.meta_key, f.meta_value FROM {$wpdb->posts} p INNER JOIN {$wpdb->postmeta} stock ON stock.post_id=p.ID INNER JOIN {$wpdb->postmeta} f ON f.post_id=p.ID INNER JOIN {$wpdb->term_relationships} tr ON tr.object_id=p.ID INNER JOIN {$wpdb->term_taxonomy} tt ON tt.term_taxonomy_id=tr.term_taxonomy_id INNER JOIN {$wpdb->terms} t ON t.term_id=tt.term_id WHERE p.post_type=%s AND p.post_status=%s AND stock.meta_key=%s AND stock.meta_value=%s AND tt.taxonomy=%s AND f.meta_key IN (%s,%s,%s) AND f.meta_value<>'' ORDER BY f.meta_value ASC LIMIT 5000";
 $rows=$wpdb->get_results($wpdb->prepare($sql,'veicoli','publish','_an_availability','available','an_marca','_an_model','_an_fuel','_an_condition'),ARRAY_A);
 $map=array();$main=autonec_catalogue_main_brand_slugs();$keys=array('_an_model'=>'modello','_an_fuel'=>'alimentazione','_an_condition'=>'condizione');$contexts=array('modello'=>'model','alimentazione'=>'fuel','condizione'=>'condition');
 foreach($rows as $row){$key=$keys[$row['meta_key']];$value=$row['meta_value'];$entry=array('value'=>$value,'label'=>autonec_catalogue_text($value,$contexts[$key].':'.sanitize_title($value)));$groups=array('', $row['slug']);if(!in_array($row['slug'],$main,true))$groups[]='altri';foreach($groups as $group){$map[$group][$key][$value]=$entry;}}
 foreach($map as &$groups){foreach($groups as &$options){$options=array_values($options);}unset($options);}unset($groups);return $map;
}

/** Present only provided facts, in a consistent reading order. */
function autonec_catalogue_specs( $data, $compact = false ) {
 $specs = array();
 if ( ! empty( $data['year'] ) ) { $specs[ __( 'Anno', 'autonec-child-theme' ) ] = (string) absint( $data['year'] ); }
 if ( isset( $data['mileage'] ) && is_numeric( $data['mileage'] ) && (float) $data['mileage'] >= 0 ) {
  $specs[ __( 'Chilometraggio', 'autonec-child-theme' ) ] = sprintf( __( '%s km', 'autonec-child-theme' ), number_format_i18n( (float) $data['mileage'], 0 ) );
 }
 foreach ( array( 'fuel'=>__( 'Alimentazione', 'autonec-child-theme' ), 'transmission'=>__( 'Cambio', 'autonec-child-theme' ), 'power'=>__( 'Potenza', 'autonec-child-theme' ), 'body'=>__( 'Carrozzeria', 'autonec-child-theme' ), 'condition'=>__( 'Condizione', 'autonec-child-theme' ), 'first_registration'=>__('Prima immatricolazione','autonec-child-theme'), 'color'=>__('Colore esterno','autonec-child-theme'), 'drive'=>__('Trazione','autonec-child-theme'), 'doors'=>__('Porte','autonec-child-theme'), 'seats'=>__('Posti','autonec-child-theme') ) as $key=>$label ) {
  if ( ! empty( $data[$key] ) ) { $specs[$label] = autonec_catalogue_text( $data[$key], $key . ':' . sanitize_title( $data[$key] ) ); }
 }
 if(!empty($data['displacement'])){$specs[__('Cilindrata','autonec-child-theme')]=number_format_i18n((float)$data['displacement'],0).' cm³';}
 return $compact ? array_slice( $specs, 0, 4, true ) : $specs;
}

/** Local Media IDs only; source image URLs are deliberately never rendered. */
function autonec_catalogue_gallery_ids( $post_id, $data ) {
 $ids = array_merge( array( get_post_thumbnail_id( $post_id ) ), (array) ( $data['gallery'] ?? array() ) );
 $ids = array_values( array_filter( array_unique( array_map( 'absint', $ids ) ) ) );
 if ( ! $ids ) { return array(); }
 // Prime only this vehicle's attachments and their responsive-image metadata in a batch.
 get_posts( array( 'post_type'=>'attachment', 'post_status'=>'inherit', 'post__in'=>$ids, 'posts_per_page'=>count( $ids ), 'no_found_rows'=>true, 'update_post_meta_cache'=>true, 'update_post_term_cache'=>false, 'suppress_filters'=>false ) );
 return array_values( array_filter( $ids, 'wp_attachment_is_image' ) );
}

/** Shared card in the catalogue and actual brand stock. */
function autonec_catalogue_card( $post_id, $priority = false ) {
 $data = autonec_catalogue_data( $post_id );
 $image_id = absint( get_post_thumbnail_id( $post_id ) );
 if ( ! $image_id ) {
  foreach ( (array) ( $data['gallery'] ?? array() ) as $candidate ) {
   if ( wp_attachment_is_image( absint( $candidate ) ) ) { $image_id = absint( $candidate ); break; }
  }
 }
 $price = autonec_catalogue_price( $data );
 $title = get_the_title( $post_id );
 ?>
 <article class="an-vehicle-card">
  <a class="an-vehicle-card__photo" href="<?php echo esc_url( get_permalink( $post_id ) ); ?>" tabindex="-1" aria-hidden="true">
   <?php if ( $image_id ) : ?>
    <?php echo wp_get_attachment_image( $image_id, 'large', false, array( 'alt'=>'', 'loading'=>$priority ? 'eager' : 'lazy', 'fetchpriority'=>$priority ? 'high' : 'auto', 'decoding'=>'async', 'sizes'=>'(max-width: 700px) 92vw, (max-width: 1100px) 46vw, 30vw' ) ); ?>
   <?php else : ?><span><?php esc_html_e( 'Fotografie non disponibili', 'autonec-child-theme' ); ?></span><?php endif; ?>
  </a>
  <div class="an-vehicle-card__body">
   <?php if ( ! empty( $data['reserved'] ) ) : ?><p class="an-vehicle-card__status"><?php esc_html_e( 'Riservata', 'autonec-child-theme' ); ?></p><?php endif; ?>
   <h3><a href="<?php echo esc_url( get_permalink( $post_id ) ); ?>"><?php echo esc_html( $title ); ?></a></h3>
   <?php if ( $price ) : ?><p class="an-vehicle-card__price"><?php echo esc_html( $price ); ?></p><?php endif; ?>
   <?php $specs = autonec_catalogue_specs( $data, true ); if ( $specs ) : ?>
    <dl class="an-vehicle-card__specs"><?php foreach ( $specs as $label=>$value ) : ?><div><dt><?php echo esc_html( $label ); ?></dt><dd><?php echo esc_html( $value ); ?></dd></div><?php endforeach; ?></dl>
   <?php endif; ?>
  </div>
 </article>
 <?php
}

/** The four CMS marques lead the filter; other stock marques retain alphabetic order. */
function autonec_catalogue_filter_brands() {
 $ordered=array();
 foreach(autonec_brand_pages() as $page){
  $slug=sanitize_title((string)get_post_meta($page['page_id'],'_an_catalogue_brand',true));
  if(!$slug||isset($ordered[$slug])||!get_term_by('slug',$slug,'an_marca'))continue;
  $ordered[$slug]=array('slug'=>$slug,'label'=>rtrim(wp_strip_all_tags($page['title']),'. '),'main'=>true);
 }
 $terms=get_terms(array('taxonomy'=>'an_marca','hide_empty'=>true,'orderby'=>'name','order'=>'ASC'));
 foreach(is_wp_error($terms)?array():$terms as $term){if(!isset($ordered[$term->slug]))$ordered[$term->slug]=array('slug'=>$term->slug,'label'=>$term->name,'main'=>false);}
 return array_values($ordered);
}

/** The budget scale follows actual available CHF stock, not a fixed promotional amount. */
function autonec_catalogue_price_scale($filters) {
 global $wpdb;
 $max=(float)$wpdb->get_var($wpdb->prepare("SELECT MAX(CAST(price.meta_value AS DECIMAL(15,2))) FROM {$wpdb->posts} p INNER JOIN {$wpdb->postmeta} price ON price.post_id=p.ID AND price.meta_key=%s INNER JOIN {$wpdb->postmeta} currency ON currency.post_id=p.ID AND currency.meta_key=%s AND currency.meta_value=%s INNER JOIN {$wpdb->postmeta} stock ON stock.post_id=p.ID AND stock.meta_key=%s AND stock.meta_value=%s WHERE p.post_type=%s AND p.post_status=%s",'_an_price','_an_currency','CHF','_an_availability','available','veicoli','publish'));
 $max=max($max,(float)($filters['prezzo_max']??0),(float)($filters['prezzo_min']??0));
 $step=$max>250000?1000:500;
 return array('min'=>0,'max'=>max($step,(int)(ceil($max/$step)*$step)),'step'=>$step);
}

/** Native filter form, also fully functional with JavaScript disabled. */
function autonec_catalogue_filter_form( $filters ) {
 $facets = autonec_catalogue_facets( $filters['marca'] );
 $brands = autonec_catalogue_filter_brands();
 $scale=autonec_catalogue_price_scale($filters);$budget_min=($filters['prezzo_min']??'')!==''?(float)$filters['prezzo_min']:$scale['min'];$budget_max=$filters['prezzo_max']!==''?(float)$filters['prezzo_max']:$scale['max'];
 ?>
 <details class="an-catalogue-filter-panel" data-an-filter-panel open><summary><?php esc_html_e( 'Filtra il catalogo', 'autonec-child-theme' ); ?></summary>
 <form class="an-catalogue-filters" method="get" action="<?php echo esc_url( autonec_catalogue_page_url() . '#an-catalogue-results-title' ); ?>" aria-label="<?php esc_attr_e( 'Filtra il catalogo', 'autonec-child-theme' ); ?>">
  <div><label for="an-filter-brand"><?php esc_html_e( 'Marchio', 'autonec-child-theme' ); ?></label><select id="an-filter-brand" name="marca">
   <option value=""><?php esc_html_e( 'Tutti i marchi', 'autonec-child-theme' ); ?></option>
   <?php foreach ($brands as $brand):if(!$brand['main'])continue; ?><option value="<?php echo esc_attr($brand['slug']); ?>" <?php selected($filters['marca'],$brand['slug']); ?>><?php echo esc_html(autonec_catalogue_text($brand['label'],'brand:'.$brand['slug'])); ?></option><?php endforeach; ?>
   <option value="altri" <?php selected($filters['marca'],'altri'); ?>><?php esc_html_e('Altri veicoli','autonec-child-theme'); ?></option>
   <?php foreach ($brands as $brand):if($brand['main'])continue; ?><option value="<?php echo esc_attr($brand['slug']); ?>" <?php selected($filters['marca'],$brand['slug']); ?>><?php echo esc_html(autonec_catalogue_text($brand['label'],'brand:'.$brand['slug'])); ?></option><?php endforeach; ?>
  </select></div>
  <?php foreach ( array( 'modello'=>array( __( 'Modello', 'autonec-child-theme' ), __( 'Tutti i modelli', 'autonec-child-theme' ) ), 'alimentazione'=>array( __( 'Alimentazione', 'autonec-child-theme' ), __( 'Tutte le alimentazioni', 'autonec-child-theme' ) ), 'condizione'=>array( __( 'Condizione', 'autonec-child-theme' ), __( 'Tutte le condizioni', 'autonec-child-theme' ) ) ) as $key=>$labels ) : ?>
  <div><label for="an-filter-<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $labels[0] ); ?></label><select id="an-filter-<?php echo esc_attr( $key ); ?>" name="<?php echo esc_attr( $key ); ?>">
   <option value=""><?php echo esc_html( $labels[1] ); ?></option>
   <?php $options = $facets[$key]; if ( $filters[$key] && ! in_array( $filters[$key], $options, true ) ) { $options[] = $filters[$key]; } ?>
   <?php foreach ( $options as $value ) : ?><option value="<?php echo esc_attr( $value ); ?>" <?php selected( $filters[$key], $value ); ?>><?php echo esc_html( autonec_catalogue_text( $value, array('modello'=>'model','alimentazione'=>'fuel','condizione'=>'condition')[$key] . ':' . sanitize_title( $value ) ) ); ?></option><?php endforeach; ?>
  </select></div>
  <?php endforeach; ?>
  <div class="an-budget-field"><label id="an-budget-label" for="an-filter-price-min"><?php esc_html_e('Fascia di prezzo (CHF)','autonec-child-theme'); ?></label>
   <div class="an-budget" data-an-budget data-min="<?php echo esc_attr($scale['min']); ?>" data-max="<?php echo esc_attr($scale['max']); ?>">
    <div class="an-budget__values" aria-live="off"><output for="an-filter-price-min" data-budget-min><?php echo esc_html('CHF '.number_format_i18n($budget_min,0)); ?></output><span aria-hidden="true">–</span><output for="an-filter-price-max" data-budget-max><?php echo esc_html('CHF '.number_format_i18n($budget_max,0)); ?></output></div>
    <div class="an-budget__track"><span class="an-budget__fill" data-budget-fill></span>
     <input id="an-filter-price-min" type="range" name="prezzo_min" min="<?php echo esc_attr($scale['min']); ?>" max="<?php echo esc_attr($scale['max']); ?>" step="1" data-budget-step="<?php echo esc_attr($scale['step']); ?>" value="<?php echo esc_attr($budget_min); ?>" aria-label="<?php esc_attr_e('Prezzo minimo','autonec-child-theme'); ?>">
     <input id="an-filter-price-max" type="range" name="prezzo_max" min="<?php echo esc_attr($scale['min']); ?>" max="<?php echo esc_attr($scale['max']); ?>" step="1" data-budget-step="<?php echo esc_attr($scale['step']); ?>" value="<?php echo esc_attr($budget_max); ?>" aria-label="<?php esc_attr_e('Prezzo massimo','autonec-child-theme'); ?>">
    </div>
   </div>
  </div>
  <button class="an-link" type="submit"><?php esc_html_e( 'Mostra le auto', 'autonec-child-theme' ); ?></button>
  <?php if ( $filters['marca'] || $filters['modello'] || $filters['alimentazione'] || $filters['condizione'] || ($filters['prezzo_min']??'') || $filters['prezzo_max'] ) : ?><a class="an-catalogue-filters__reset" href="<?php echo esc_url( autonec_catalogue_page_url() ); ?>"><?php esc_html_e( 'Azzera filtri', 'autonec-child-theme' ); ?></a><?php endif; ?>
 </form>
 <script type="application/json" id="an-catalogue-facet-map"><?php echo wp_json_encode(autonec_catalogue_facet_map(),JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- inert encoded JSON. ?></script></details>
 <?php
}

/** Numbered internal links preserve sanitized filters and native page URL. */
function autonec_catalogue_pagination( $query, $filters ) {
 if ( $query->max_num_pages < 2 ) { return; }
 $args = array_filter( array_diff_key( $filters, array( 'pagina'=>1 ) ), static function( $value ) { return '' !== $value; } );
 $base = add_query_arg( array_merge( $args, array( 'pagina'=>'%#%' ) ), autonec_catalogue_page_url() );
 $links = paginate_links( array( 'base'=>str_replace( '%25%23%25', '%#%', $base ), 'format'=>'', 'current'=>$filters['pagina'], 'total'=>(int) $query->max_num_pages, 'prev_text'=>__( 'Precedente', 'autonec-child-theme' ), 'next_text'=>__( 'Successiva', 'autonec-child-theme' ), 'type'=>'list', 'add_args'=>false, 'add_fragment'=>'#an-catalogue-results-title' ) );
 if ( $links ) { echo '<nav class="an-catalogue-pagination" aria-label="' . esc_attr__( 'Pagine del catalogo', 'autonec-child-theme' ) . '">' . wp_kses_post( $links ) . '</nav>'; }
}

/** The stock belongs to a CMS-selected term; empty brand pages get no sales block. */
function autonec_catalogue_brand_stock( $page_id ) {
 $slug = sanitize_title( (string) get_post_meta( $page_id, '_an_catalogue_brand', true ) );
 if ( ! $slug || ! autonec_catalogue_page_url() ) { return; }
 $term = get_term_by( 'slug', $slug, 'an_marca' );
 if ( ! $term ) { return; }
 $stock = autonec_catalogue_query( array( 'posts_per_page'=>6, 'tax_query'=>array( array( 'taxonomy'=>'an_marca', 'field'=>'slug', 'terms'=>$slug ) ) ) );
 if ( ! $stock->have_posts() ) { return; }
 update_post_thumbnail_cache( $stock );
 ?>
 <section class="an-brand-stock an-wrap" aria-labelledby="an-brand-stock-title">
  <div class="an-brand-stock__heading"><h2 id="an-brand-stock-title"><?php printf( esc_html__( 'Le nostre %s', 'autonec-child-theme' ), esc_html( autonec_catalogue_text( $term->name, 'brand:' . $slug ) ) ); ?></h2><a class="an-link" href="<?php echo esc_url( add_query_arg( 'marca', $slug, autonec_catalogue_page_url() ) ); ?>"><?php esc_html_e( 'Tutte le auto del marchio', 'autonec-child-theme' ); ?></a></div>
  <div class="an-catalogue-grid"><?php foreach ( $stock->posts as $vehicle ) { autonec_catalogue_card( $vehicle->ID ); } ?></div>
 </section>
 <?php
}

/** Contextual direct actions use the one existing source for company contacts. */
function autonec_catalogue_contact_actions( $post_id ) {
 $contact = ticinoweb_get_contact_info();
 $phone = $contact['phone_display'] ?: $contact['phone'];
 $number = preg_replace( '/[^+0-9]/', '', $contact['phone'] ?: $phone );
 $email = sanitize_email( $contact['email'] );
 if ( ! preg_match( '/^\+?[0-9]{5,16}$/D', $number ) && ! $email ) { return; }
 $subject = sprintf( __( 'Informazioni su %s', 'autonec-child-theme' ), wp_strip_all_tags( get_the_title( $post_id ) ) );
 ?>
 <section class="an-vehicle-contact" aria-labelledby="an-vehicle-contact-title"><h2 id="an-vehicle-contact-title"><?php esc_html_e( 'Parliamone insieme', 'autonec-child-theme' ); ?></h2>
  <div class="an-vehicle-contact__actions">
   <?php if ( preg_match( '/^\+?[0-9]{5,16}$/D', $number ) ) : ?><a class="an-link" href="tel:<?php echo esc_attr( $number ); ?>"><?php printf( esc_html__( 'Chiama %s', 'autonec-child-theme' ), esc_html( $phone ) ); ?></a><?php endif; ?>
   <?php if ( $email ) : ?><a class="an-link" href="<?php echo esc_url( 'mailto:' . $email . '?subject=' . rawurlencode( $subject ) . '&body=' . rawurlencode( get_permalink( $post_id ) ) ); ?>"><?php esc_html_e( 'Richiedi informazioni', 'autonec-child-theme' ); ?></a><?php endif; ?>
  </div>
 </section>
 <?php
}

/** Reuse the parent's schema slot instead of publishing an Article for a car. */
add_filter('ticinoweb_seo_jsonld_article_schema',static function($schema,$post){
 if($post->post_type!=='veicoli')return $schema;$r=autonec_catalogue_data($post->ID);if(!$r)return $schema;
 $vehicle=array('@context'=>'https://schema.org','@type'=>'Vehicle','@id'=>get_permalink($post).'#vehicle','url'=>get_permalink($post),'name'=>get_the_title($post),'brand'=>array('@type'=>'Brand','name'=>$r['brand']),'model'=>$r['model']);
 $gallery=autonec_catalogue_gallery_ids($post->ID,$r);if($gallery)$vehicle['image']=array_values(array_filter(array_map(static fn($id)=>wp_get_attachment_image_url($id,'full'),$gallery)));
 if($r['description'])$vehicle['description']=mb_substr(wp_strip_all_tags(autonec_catalogue_text($r['description'],'vehicle:'.$post->ID.':description')),0,1600);
 foreach(array('fuel'=>'fuelType','transmission'=>'vehicleTransmission','body'=>'bodyType') as $field=>$property)if(!empty($r[$field]))$vehicle[$property]=autonec_catalogue_text($r[$field],$field.':'.sanitize_title($r[$field]));
 if(!empty($r['year']))$vehicle['productionDate']=(string)$r['year'];if(isset($r['mileage']))$vehicle['mileageFromOdometer']=array('@type'=>'QuantitativeValue','value'=>$r['mileage'],'unitCode'=>'KMT');
 if(isset($r['price'])&&!empty($r['currency'])){$offer=array('@type'=>'Offer','url'=>get_permalink($post),'price'=>$r['price'],'priceCurrency'=>$r['currency']);if(($r['availability']??'')!=='available')$offer['availability']='https://schema.org/OutOfStock';elseif(empty($r['reserved']))$offer['availability']='https://schema.org/InStock';$vehicle['offers']=$offer;}
 return $vehicle;
},10,2);

/** Keep manual SEO/excerpts authoritative; otherwise describe the actual imported car. */
add_filter('ticinoweb_seo_meta_description',static function($description){
 if(!is_singular('veicoli')||get_post_meta(get_queried_object_id(),'_tw_seo_description',true)||has_excerpt()||trim(get_post_field('post_content',get_queried_object_id())))return $description;
 $r=autonec_catalogue_data(get_queried_object_id());if(!$r)return $description;$facts=autonec_catalogue_specs($r,true);$parts=array_filter(array_merge(array(get_the_title(),autonec_catalogue_price($r)),array_values($facts)));$text=wp_strip_all_tags(implode(' · ',$parts));return mb_strlen($text)>160?mb_substr($text,0,157).'…':$text;
});
