<?php
/** Bounded public manufacturer transport. Called by the background job only. */
defined('ABSPATH') || exit;

/** Exact hosts; a public API exception is restricted to its one observed read endpoint. */
function autonec_gamma_remote_url($url, $media = false) {
    if (!is_string($url) || $url === '' || preg_match('/[\x00-\x20\\\\]/', $url)) {
        return new WP_Error('an_gamma_url', __('Il collegamento ufficiale non è valido.', 'autonec-child-theme'));
    }
    $parts = wp_parse_url($url);
    if (!$parts || ($parts['scheme'] ?? '') !== 'https' || isset($parts['user']) || isset($parts['pass']) || isset($parts['port'])) {
        return new WP_Error('an_gamma_https', __('Usa un collegamento ufficiale HTTPS.', 'autonec-child-theme'));
    }
    $host = strtolower($parts['host'] ?? '');
    $hosts = array('opel.ch', 'www.opel.ch', 'hyundai.com', 'www.hyundai.com', 'leapmotor.net', 'www.leapmotor.net', 'piaggio-commercial.ch', 'www.piaggio-commercial.ch');
    if ($media) {
        $hosts = array_merge($hosts, array('stellantis3.dam-broadcast.com', 'dmassets.hyundai.com', 'lpwebsite-prod-s3cdn.leapmotor-international.com', 'van-up.com', 'www.van-up.com', 'cucini.it', 'www.cucini.it'));
    }
    $api = !$media && $host === 'website-adminapi.leapmotor-international.com' && ($parts['path'] ?? '') === '/api/web/qryTemplateDetailByWeb';
    if ((!in_array($host, $hosts, true) && !$api) || !wp_http_validate_url($url)) {
        return new WP_Error('an_gamma_host', __('La fonte non appartiene ai siti ufficiali consentiti o non è raggiungibile in sicurezza.', 'autonec-child-theme'));
    }
    return $url;
}

/**
 * Validated GET, safe DNS/TLS, explicit redirects and one bounded403 compatibility retry.
 * Streaming preserves the caller's filename; ownership/cleanup remain with the media job.
 * Byte/MIME/decoded image checks remain the responsibility of that job after this byte cap.
 */
function autonec_gamma_remote($url, $args = array(), $media = false) {
    if (!is_array($args)) {
        return new WP_Error('an_gamma_args', __('La richiesta alla fonte non è valida.', 'autonec-child-theme'));
    }
    $limit = ($media ? 16 : 6) * MB_IN_BYTES;
    if (isset($args['limit_response_size']) && is_numeric($args['limit_response_size']) && (int)$args['limit_response_size'] > 0) { $limit = min($limit, (int)$args['limit_response_size']); }
    $max_timeout = $media ? 15 : 10;
    $stream = !empty($args['stream']);
    $filename = $stream && isset($args['filename']) && is_string($args['filename']) ? $args['filename'] : '';
    if ($stream && ($filename === '' || str_contains($filename, "\0"))) {
        return new WP_Error('an_gamma_stream', __('Manca il file temporaneo per l’immagine.', 'autonec-child-theme'));
    }
    // Only public content negotiation and partial reads are needed. Never forward credentials.
    $headers = array();
    foreach ((array)($args['headers'] ?? array()) as $name => $value) {
        if (in_array(strtolower((string)$name), array('accept', 'range'), true) && is_scalar($value) && !preg_match('/[\r\n]/', (string)$value)) {
            $headers[$name] = (string)$value;
        }
    }
    $timeout = isset($args['timeout']) && is_numeric($args['timeout']) ? max(1, min($max_timeout, (float)$args['timeout'])) : $max_timeout;
    $request = array(
        'method' => 'GET', 'timeout' => $timeout, 'redirection' => 0,
        'sslverify' => true, 'reject_unsafe_urls' => true,
        'limit_response_size' => $limit + 1, 'headers' => $headers,
        'user-agent' => 'Python-urllib/3.9', 'stream' => $stream,
    );
    if ($stream) { $request['filename'] = $filename; }
    $redirects = 0;
    $fallback_used = false;
    while (true) {
        $allowed = autonec_gamma_remote_url($url, $media);
        if (is_wp_error($allowed)) { return $allowed; }
        $response = wp_safe_remote_get($allowed, $request);
        if (is_wp_error($response)) { return $response; }
        $code = (int)wp_remote_retrieve_response_code($response);
        if ($code === 403 && !$fallback_used) {
            $fallback_used = true;
            // Verified public DAM compatibility; no credentials, cookies or access tokens.
            $request['user-agent'] = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36';
            continue;
        }
        if (in_array($code, array(301, 302, 303, 307, 308), true)) {
            $location = wp_remote_retrieve_header($response, 'location');
            if ($redirects >= 3 || !is_string($location) || $location === '' || preg_match('/[\r\n]/', $location)) {
                return new WP_Error('an_gamma_redirect', __('La fonte contiene troppi reindirizzamenti o un collegamento non valido.', 'autonec-child-theme'));
            }
            $url = WP_Http::make_absolute_url($location, $url);
            ++$redirects;
            // The next iteration validates the new host and DNS before any request is made.
            continue;
        }
        if ($code < 200 || $code >= 300) {
            return new WP_Error('an_gamma_http', sprintf(__('La fonte ufficiale ha risposto con un errore (%s). La lettura precedente resta conservata.', 'autonec-child-theme'), $code));
        }
        $declared = wp_remote_retrieve_header($response, 'content-length');
        if (is_scalar($declared) && is_numeric($declared) && (float)$declared > $limit) {
            return new WP_Error('an_gamma_size', __('Il contenuto della fonte supera il limite consentito.', 'autonec-child-theme'));
        }
        if ($stream) {
            clearstatcache(true, $filename);
            $size = is_file($filename) ? filesize($filename) : false;
            if ($size === false || $size > $limit) {
                return new WP_Error('an_gamma_size', __('Il file ricevuto non è valido o supera il limite consentito.', 'autonec-child-theme'));
            }
        } elseif (strlen((string)wp_remote_retrieve_body($response)) > $limit) {
            return new WP_Error('an_gamma_size', __('Il contenuto della fonte supera il limite consentito.', 'autonec-child-theme'));
        }
        return $response;
    }
}

/** Manufacturer text/JSON only; an empty or partial HTTP result never becomes a snapshot. */
function autonec_gamma_fetch($url) {
    $response = autonec_gamma_remote($url);
    if (is_wp_error($response)) { return $response; }
    $body = wp_remote_retrieve_body($response);
    if ((int)wp_remote_retrieve_response_code($response) !== 200 || !is_string($body) || trim($body) === '') {
        return new WP_Error('an_gamma_empty', __('La fonte ufficiale è vuota o incompleta. La lettura precedente resta conservata.', 'autonec-child-theme'));
    }
    return $body;
}
