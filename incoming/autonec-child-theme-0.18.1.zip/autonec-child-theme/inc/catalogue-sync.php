<?php
/** Recoverable, source-scoped background catalogue synchronization. @package AutonecChildTheme */
defined('ABSPATH') || exit;

function autonec_catalogue_state() {return (array)get_option('an_catalogue_state',array('status'=>'idle','message'=>__('Nessuna sincronizzazione eseguita.','autonec-child-theme')));}
function autonec_catalogue_busy() {return (bool)get_option('an_catalogue_job');}
function autonec_catalogue_queue() {if(!wp_next_scheduled('an_catalogue_worker'))wp_schedule_single_event(time()+2,'an_catalogue_worker');}
/** Native add_option can upsert: claim ownership with an insert-only statement. */
function autonec_catalogue_claim($name,$value){
 global $wpdb;$won=$wpdb->query($wpdb->prepare("INSERT IGNORE INTO {$wpdb->options} (option_name,option_value,autoload) VALUES (%s,%s,'no')",$name,maybe_serialize($value)));
 wp_cache_delete($name,'options');wp_cache_delete('notoptions','options');return $won===1;
}
function autonec_catalogue_refresh_options(){foreach(array('an_catalogue_job','an_catalogue_state','an_catalogue_snapshots','an_catalogue_source_status') as $name)wp_cache_delete($name,'options');wp_cache_delete('notoptions','options');}
function autonec_catalogue_start() {
 $lock=autonec_catalogue_lock();if(!$lock)return new WP_Error('busy',__('Una sincronizzazione è già in corso.','autonec-child-theme'));
 try{
  autonec_catalogue_refresh_options();if(autonec_catalogue_busy())return new WP_Error('busy',__('Una sincronizzazione è già in corso.','autonec-child-theme'));
  $sources=array_values(array_filter((array)get_option('an_catalogue_sources',array()),static fn($s)=>!empty($s['enabled'])));
  if(!$sources&&!get_posts(array('post_type'=>'veicoli','posts_per_page'=>1,'fields'=>'ids','meta_key'=>'_an_external_key')))return new WP_Error('no_sources',__('Aggiungi e attiva una fonte prima di sincronizzare.','autonec-child-theme'));
  $job=array('token'=>wp_generate_uuid4(),'phase'=>$sources?'fetch':'records','records'=>array(),'media'=>array(),'sources'=>$sources,'source_cursor'=>0,'errors'=>array(),'warnings'=>0,'cursor'=>0,'done'=>0,'total'=>count($sources),'started'=>time(),'seen'=>array(),'image_map'=>array());
  if(!autonec_catalogue_claim('an_catalogue_job',$job))return new WP_Error('busy',__('Una sincronizzazione è già in corso.','autonec-child-theme'));
  $state=autonec_catalogue_state();$state=array_merge($state,array('status'=>'running','phase'=>$job['phase'],'message'=>__('Lettura delle fonti in corso.','autonec-child-theme'),'done'=>0,'total'=>count($sources),'started'=>time(),'last_attempt'=>time(),'warnings'=>0));update_option('an_catalogue_state',$state,false);autonec_catalogue_queue();return true;
 }finally{autonec_catalogue_unlock($lock);}
}

/** Lease recovery and release both compare the exact persisted ownership value. */
function autonec_catalogue_lock() {
 $token=wp_generate_uuid4();$lock=array('token'=>$token,'expires'=>time()+600);
 if(autonec_catalogue_claim('an_catalogue_lock',$lock))return $token;
 $old=get_option('an_catalogue_lock');
 if(is_array($old)&&($old['expires']??0)<time()){
  global $wpdb;$removed=$wpdb->query($wpdb->prepare("DELETE FROM {$wpdb->options} WHERE option_name=%s AND option_value=%s",'an_catalogue_lock',maybe_serialize($old)));wp_cache_delete('an_catalogue_lock','options');wp_cache_delete('notoptions','options');
  if($removed&&autonec_catalogue_claim('an_catalogue_lock',$lock))return $token;
 }
 return false;
}
function autonec_catalogue_unlock($token){
 wp_cache_delete('an_catalogue_lock','options');$lock=get_option('an_catalogue_lock');
 if(is_array($lock)&&($lock['token']??'')===$token){global $wpdb;$wpdb->query($wpdb->prepare("DELETE FROM {$wpdb->options} WHERE option_name=%s AND option_value=%s",'an_catalogue_lock',maybe_serialize($lock)));wp_cache_delete('an_catalogue_lock','options');wp_cache_delete('notoptions','options');}
}

function autonec_catalogue_image_key($url){$p=wp_parse_url($url);return hash('sha256',strtolower($p['host']??'').($p['path']??''));}
function autonec_catalogue_import_image($url,$post_id){
 if(!autonec_catalogue_allowed_url($url,true))return new WP_Error('image_host',__('Indirizzo foto non supportato.','autonec-child-theme'));
 $key=autonec_catalogue_image_key($url);$found=get_posts(array('post_type'=>'attachment','post_status'=>'inherit','posts_per_page'=>1,'fields'=>'ids','meta_key'=>'_an_image_key','meta_value'=>$key,'suppress_filters'=>true));
 if($found&&wp_attachment_is_image($found[0])&&is_file(get_attached_file($found[0])))return (int)$found[0];
 require_once ABSPATH.'wp-admin/includes/file.php';require_once ABSPATH.'wp-admin/includes/media.php';require_once ABSPATH.'wp-admin/includes/image.php';
 $tmp=wp_tempnam('autonec-photo');if(!$tmp)return new WP_Error('tempfile',__('Impossibile preparare una foto.','autonec-child-theme'));
 try{
  $download=add_query_arg(array('w'=>1600,'fit'=>'max','q'=>86,'fm'=>'webp'),$url);
  $response=wp_safe_remote_get($download,array('stream'=>true,'filename'=>$tmp,'timeout'=>12,'redirection'=>0,'limit_response_size'=>8*MB_IN_BYTES,'sslverify'=>true));
  if(is_wp_error($response))return $response;
  if(wp_remote_retrieve_response_code($response)!==200||!is_file($tmp)||filesize($tmp)>=8*MB_IN_BYTES||filesize($tmp)<100)return new WP_Error('image_download',__('Una foto non è stata scaricata correttamente. Verrà riprovata al prossimo aggiornamento.','autonec-child-theme'));
  $mime=wp_get_image_mime($tmp);$ext=array('image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp');$size=wp_getimagesize($tmp);
  if(!isset($ext[$mime])||!$size||$size[0]*$size[1]>16000000)return new WP_Error('image_type',__('La fonte ha restituito un file immagine non valido.','autonec-child-theme'));
  $id=media_handle_sideload(array('name'=>'veicolo-'.substr($key,0,20).'.'.$ext[$mime],'tmp_name'=>$tmp),$post_id,get_the_title($post_id));
  if(is_wp_error($id))return $id;
  update_post_meta($id,'_an_image_key',$key);update_post_meta($id,'_an_image_source',esc_url_raw($url));update_post_meta($id,'_wp_attachment_image_alt',sanitize_text_field(get_the_title($post_id)));return (int)$id;
 }finally{if(is_file($tmp))wp_delete_file($tmp);}
}

/** Only replace an imported cover; preserve an explicit native featured-image choice. */
function autonec_catalogue_source_thumbnail($id, $photo) {
 $previous = (int)get_post_meta($id, '_an_source_thumbnail', true);
 $current = (int)get_post_thumbnail_id($id);
 $raw = autonec_catalogue_raw_data($id);
 if ((!$previous && (!$current || $current === (int)($raw['gallery'][0] ?? 0))) || ($previous && $current === $previous)) {
  set_post_thumbnail($id, $photo);
  update_post_meta($id, '_an_source_thumbnail', (int)$photo);
 }
}

/** Each call performs one bounded batch; no import HTTP is used by public views. */
function autonec_catalogue_work(){
 $lock=autonec_catalogue_lock();if(!$lock)return;
 try{
  autonec_catalogue_refresh_options();$job=get_option('an_catalogue_job');if(!$job)return;
  $state=autonec_catalogue_state();$snapshots=(array)get_option('an_catalogue_snapshots',array());
  switch($job['phase']){
   case 'fetch':
    $source=$job['sources'][$job['source_cursor']];$status=(array)get_option('an_catalogue_source_status',array());$step=autonec_catalogue_carmarket_step($source,(array)($job['fetch_cursor']??array()));if(!is_wp_error($step)&&empty($step['done'])){$job['fetch_cursor']=$step['cursor'];break;}$result=is_wp_error($step)?$step:$step['result'];unset($job['fetch_cursor']);$items=autonec_catalogue_snapshot($result);$source_status=$status[$source['id']]??array();$source_status['last_attempt']=time();
    if(is_wp_error($items)){$message=sanitize_text_field($items->get_error_message());$job['errors'][]=$source['label'].': '.$message;$source_status['message']=$message;$source_status['status']='error';}
    else{$snapshots[$source['id']]=array('url'=>$source['url'],'brand'=>$source['brand']??'','items'=>$items,'updated'=>time());update_option('an_catalogue_snapshots',$snapshots,false);$source_status=array_merge($source_status,array('status'=>'success','message'=>__('Lettura completa.','autonec-child-theme'),'count'=>count($items),'last_success'=>time()));}
    $status[$source['id']]=$source_status;update_option('an_catalogue_source_status',$status,false);$job['source_cursor']++;
    if($job['source_cursor']>=count($job['sources'])){
     $job['records']=array_values(autonec_catalogue_merge($job['sources'],$snapshots));$job['phase']='records';$job['cursor']=0;$job['seen']=array();$job['media']=array();$job['total']=count($job['records']);$job['done']=0;if(!$job['records']&&$job['errors'])$job['phase']='finish';
    }else{$job['done']=$job['source_cursor'];}
    break;
   case 'records':
    for($batch=0;$batch<20&&$job['cursor']<count($job['records']);$batch++,$job['cursor']++){
     $record=$job['records'][$job['cursor']];$id=autonec_catalogue_store_record($record);if(is_wp_error($id)){throw new RuntimeException($id->get_error_message());}$job['seen'][]=$id;$job['media'][]=array('id'=>$id,'images'=>$record['images']);
    }
    $job['done']=$job['cursor'];
    if($job['cursor']>=count($job['records'])){
     // Missing processing follows validated/upserted snapshots only. Failed sources retain their prior snapshot.
     $managed=get_posts(array('post_type'=>'veicoli','post_status'=>array('publish','draft','private','pending'),'fields'=>'ids','posts_per_page'=>-1,'meta_key'=>'_an_external_key','suppress_filters'=>true));autonec_catalogue_mark_missing($managed,$job['seen']);
     $queue=array();$max=0;foreach($job['media'] as $vehicle){$max=max($max,count($vehicle['images']));}
     for($photo=0;$photo<$max;$photo++){foreach($job['media'] as $vehicle){if(isset($vehicle['images'][$photo]))$queue[]=array('id'=>$vehicle['id'],'url'=>$vehicle['images'][$photo]);}}
     $job['queue']=$queue;$job['phase']='media';$job['cursor']=0;$job['done']=0;$job['total']=count($queue);$job['image_map']=array();unset($job['records']);
    }
    break;
   case 'media':
    $started=microtime(true);
    for($batch=0;$batch<100&&$job['cursor']<count($job['queue'])&&microtime(true)-$started<16;$batch++,$job['cursor']++){
     $photo=$job['queue'][$job['cursor']];$key=autonec_catalogue_image_key($photo['url']);$id=$job['image_map'][$key]??autonec_catalogue_import_image($photo['url'],$photo['id']);
     if(is_wp_error($id)){$job['warnings']++;}else{
      $job['image_map'][$key]=(int)$id;$record=autonec_catalogue_raw_data($photo['id']);$gallery=array();foreach($record['images'] as $url){$image_key=autonec_catalogue_image_key($url);if(isset($job['image_map'][$image_key]))$gallery[]=$job['image_map'][$image_key];}
      if($gallery){$record['gallery']=array_values(array_unique(array_merge($gallery,(array)($record['gallery']??array()))));autonec_catalogue_source_thumbnail($photo['id'],$gallery[0]);update_post_meta($photo['id'],'_an_vehicle',wp_slash($record));}
     }
    }
    $job['done']=$job['cursor'];if($job['cursor']>=count($job['queue']))$job['phase']='finish';
    break;
   case 'finish':
    foreach($job['seen'] as $id){$record=autonec_catalogue_raw_data($id);$gallery=array();foreach($record['images'] as $url){$key=autonec_catalogue_image_key($url);if(isset($job['image_map'][$key]))$gallery[]=$job['image_map'][$key];}if($record['images']&&count($gallery)===count($record['images'])){$record['gallery']=array_values(array_unique($gallery));update_post_meta($id,'_an_vehicle',wp_slash($record));}}
    $state['status']=$job['errors']?'partial':($job['warnings']?'warning':'success');$state['message']=$job['errors']?implode(' ',array_slice($job['errors'],0,5)):($job['warnings']?__('Veicoli aggiornati. Alcune foto verranno riprovate al prossimo aggiornamento.','autonec-child-theme'):__('Catalogo e fotografie aggiornati.','autonec-child-theme'));
    if(!$job['errors'])$state['last_success']=time();$state['last_completed']=time();$state['warnings']=$job['warnings'];$state['count']=(int)autonec_catalogue_query(array('posts_per_page'=>1,'fields'=>'ids'))->found_posts;$state['done']=$job['total'];$state['total']=$job['total'];$state['phase']='finish';update_option('an_catalogue_state',$state,false);delete_option('an_catalogue_job');wp_clear_scheduled_hook('an_catalogue_worker');return;
  }
  $state['status']='running';$state['phase']=$job['phase'];$state['done']=$job['done'];$state['total']=$job['total'];$state['warnings']=$job['warnings'];$state['heartbeat']=time();
  $messages=array('fetch'=>__('Lettura delle fonti in corso.','autonec-child-theme'),'records'=>__('Aggiornamento delle schede veicolo.','autonec-child-theme'),'media'=>__('Importazione delle fotografie nella Libreria Media.','autonec-child-theme'),'finish'=>__('Completamento della sincronizzazione.','autonec-child-theme'));$state['message']=$messages[$job['phase']];
  update_option('an_catalogue_job',$job,false);update_option('an_catalogue_state',$state,false);autonec_catalogue_queue();
 }catch(Throwable $error){$state=autonec_catalogue_state();$state['status']='error';$state['message']=__('Aggiornamento interrotto. Le schede già disponibili sono state conservate. Riprova la sincronizzazione.','autonec-child-theme');$state['last_completed']=time();update_option('an_catalogue_state',$state,false);delete_option('an_catalogue_job');wp_clear_scheduled_hook('an_catalogue_worker');error_log('Autonec catalogue: '.sanitize_text_field($error->getMessage()));}
 finally{autonec_catalogue_unlock($lock);}
}

add_action('an_catalogue_worker','autonec_catalogue_work');
add_action('an_catalogue_daily','autonec_catalogue_start');
add_action('init',static function(){if(get_option('an_catalogue_sources')&&!wp_next_scheduled('an_catalogue_daily'))wp_schedule_event(time()+DAY_IN_SECONDS,'daily','an_catalogue_daily');if(autonec_catalogue_busy()&&!wp_next_scheduled('an_catalogue_worker'))autonec_catalogue_queue();});
add_action('switch_theme',static function(){wp_clear_scheduled_hook('an_catalogue_daily');wp_clear_scheduled_hook('an_catalogue_worker');delete_option('an_catalogue_lock');delete_option('an_catalogue_job');});

/** Docker exposes a different host port; keep local WP-Cron on its own HTTP listener. */
function autonec_catalogue_local_cron_request($request){
 $p=wp_parse_url($request['url']??'');$port=isset($_SERVER['SERVER_PORT'])?(int)$_SERVER['SERVER_PORT']:0;
 if(!$p||($p['scheme']??'')!=='http'||strtolower($p['host']??'')!=='localhost'||!isset($p['port'])||!$port||$port===$p['port'])return $request;
 $request['args']['headers']['Host']='localhost:'.$p['port'];
 $request['url']='http://127.0.0.1:'.$port.($p['path']??'/').(isset($p['query'])?'?'.$p['query']:'');return $request;
}
add_filter('cron_request','autonec_catalogue_local_cron_request');
