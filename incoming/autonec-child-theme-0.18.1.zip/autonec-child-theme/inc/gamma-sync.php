<?php
/** Bounded, resumable official-range queue. All public pages read native posts only. */
defined('ABSPATH') || exit;
function autonec_gamma_providers(){return array('opel'=>'autonec_gamma_provider_opel','hyundai'=>'autonec_gamma_provider_hyundai','leapmotor'=>'autonec_gamma_provider_leapmotor','piaggio'=>'autonec_gamma_provider_piaggio');}
function autonec_gamma_clean_sources($rows){
 if(!is_array($rows)||count($rows)>4)return new WP_Error('gamma_sources',__('Controlla le quattro fonti ufficiali.','autonec-child-theme'));
 $out=array();$hosts=array('opel'=>'opel.ch','hyundai'=>'hyundai.com','leapmotor'=>'leapmotor.net','piaggio'=>'piaggio-commercial.ch');
 foreach($rows as $row){if(!is_array($row))return new WP_Error('gamma_source',__('Fonte non valida.','autonec-child-theme'));
  $provider=is_string($row['provider']??null)?sanitize_key($row['provider']):'';$brand=is_string($row['brand_slug']??null)?sanitize_key($row['brand_slug']):'';
  if(!isset($hosts[$provider])||isset($out[$provider])||$brand!==$provider||!in_array($brand,autonec_catalogue_main_brand_slugs(),true))return new WP_Error('gamma_provider',__('Scegli un marchio ufficiale configurato nel CMS.','autonec-child-theme'));
  $url=autonec_gamma_source_url($row['url']??'');if(is_wp_error($url)||!$url||preg_replace('/^www\./','',strtolower(wp_parse_url($url,PHP_URL_HOST)))!==$hosts[$provider])return new WP_Error('gamma_source',__('Il collegamento deve appartenere al sito ufficiale del marchio.','autonec-child-theme'));
  $out[$provider]=array('provider'=>$provider,'brand_slug'=>$brand,'url'=>$url,'enabled'=>!empty($row['enabled']));
 }
 return array_values($out);
}
function autonec_gamma_sources(){ $v=autonec_gamma_clean_sources(get_option('an_gamma_sources',array()));return is_wp_error($v)?array():$v; }
function autonec_gamma_state(){return (array)get_option('an_gamma_state',array('status'=>'idle','message'=>__('Nessun aggiornamento eseguito.','autonec-child-theme')));}
function autonec_gamma_queue(){if(!wp_next_scheduled('an_gamma_worker'))wp_schedule_single_event(time()+5,'an_gamma_worker');}
function autonec_gamma_lock(){
 $value=array('token'=>wp_generate_uuid4(),'expires'=>time()+300);
 if(autonec_catalogue_claim('an_gamma_lock',$value))return $value['token'];
 wp_cache_delete('an_gamma_lock','options');$old=get_option('an_gamma_lock');
 if(is_array($old)&&($old['expires']??0)<time()){global $wpdb;$deleted=$wpdb->query($wpdb->prepare("DELETE FROM {$wpdb->options} WHERE option_name=%s AND option_value=%s",'an_gamma_lock',maybe_serialize($old)));wp_cache_delete('an_gamma_lock','options');wp_cache_delete('notoptions','options');if($deleted&&autonec_catalogue_claim('an_gamma_lock',$value))return $value['token'];}
 return false;
}
function autonec_gamma_unlock($token){wp_cache_delete('an_gamma_lock','options');$value=get_option('an_gamma_lock');if(is_array($value)&&($value['token']??'')===$token){global $wpdb;$wpdb->query($wpdb->prepare("DELETE FROM {$wpdb->options} WHERE option_name=%s AND option_value=%s",'an_gamma_lock',maybe_serialize($value)));wp_cache_delete('an_gamma_lock','options');wp_cache_delete('notoptions','options');}}
function autonec_gamma_start(){
 $lock=autonec_gamma_lock();if(!$lock)return new WP_Error('gamma_busy',__('Un aggiornamento è già in corso.','autonec-child-theme'));
 try{wp_cache_delete('an_gamma_job','options');if(get_option('an_gamma_job'))return new WP_Error('gamma_busy',__('Un aggiornamento è già in corso.','autonec-child-theme'));
  $sources=array_values(array_filter(autonec_gamma_sources(),static fn($r)=>$r['enabled']));if(!$sources)return new WP_Error('gamma_empty',__('Salva e attiva almeno una fonte ufficiale.','autonec-child-theme'));
  $job=array('sources'=>$sources,'source_cursor'=>0,'phase'=>'discover','cursor'=>0,'records'=>array(),'seen'=>array(),'errors'=>array(),'done'=>0,'total'=>count($sources),'started'=>time(),'source_failed'=>false,'retry'=>0,'warnings'=>0);
  if(!autonec_catalogue_claim('an_gamma_job',$job))return new WP_Error('gamma_busy',__('Un aggiornamento è già in corso.','autonec-child-theme'));
  update_option('an_gamma_state',array_merge(autonec_gamma_state(),array('status'=>'running','message'=>__('Lettura delle gamme ufficiali.','autonec-child-theme'),'started'=>time(),'last_attempt'=>time(),'done'=>0,'total'=>count($sources),'errors'=>array())),false);autonec_gamma_queue();return true;
 }finally{autonec_gamma_unlock($lock);}
}
/** A source that failed even one detail never reconciles absent models. */
function autonec_gamma_advance_source(&$job){$job['source_cursor']++;$job['phase']='discover';$job['records']=array();$job['seen']=array();$job['cursor']=0;$job['retry']=0;$job['source_failed']=false;unset($job['photo'],$job['photo_cursor'],$job['post_id']);}
function autonec_gamma_worker(){
 $lock=autonec_gamma_lock();if(!$lock)return false;
 try{
  foreach(array('an_gamma_job','an_gamma_state','an_gamma_source_status') as $key)wp_cache_delete($key,'options');
  $job=get_option('an_gamma_job');if(!is_array($job))return false;
  if(!isset($job['sources'][$job['source_cursor']])){
   $state=array_merge(autonec_gamma_state(),array('status'=>($job['errors']||$job['warnings'])?'warning':'complete','message'=>($job['errors']||$job['warnings'])?__('Aggiornamento concluso con segnalazioni. Controlla le fonti e le foto da verificare nel CMS.','autonec-child-theme'):__('Gamma aggiornata dai siti ufficiali.','autonec-child-theme'),'finished'=>time(),'done'=>$job['done'],'total'=>$job['total'],'errors'=>$job['errors'],'warnings'=>$job['warnings']));if(!$job['errors']&&!$job['warnings'])$state['last_success']=time();update_option('an_gamma_state',$state,false);delete_option('an_gamma_job');wp_clear_scheduled_hook('an_gamma_worker');return true;
  }
  $source=$job['sources'][$job['source_cursor']];$provider=autonec_gamma_providers()[$source['provider']]??'';$brand=$source['brand_slug'];$statuses=(array)get_option('an_gamma_source_status',array());$status=$statuses[$brand]??array();$error=null;
  try{
   if($job['phase']==='discover'){
    $feed=$provider?call_user_func($provider,$source['url']):new WP_Error('gamma_provider',__('Fonte non valida.','autonec-child-theme'));
    $records=is_wp_error($feed)?$feed:autonec_gamma_validate_feed($feed,$brand,(int)($status['count']??0));
    if(is_wp_error($records)){$error=$records;}else{$job['records']=$records;$job['phase']='details';$job['cursor']=0;$job['total']+=count($records);$job['done']++;$job['retry']=0;$status['attempt']=time();$status['message']=__('Lettura dei modelli.','autonec-child-theme');}
   }elseif($job['phase']==='details'){
    if(!isset($job['records'][$job['cursor']])){
     if(!$job['source_failed']){autonec_gamma_reconcile_missing($brand,$job['seen'],gmdate('Y-m-d'));$status=array('attempt'=>time(),'success'=>time(),'count'=>count($job['seen']),'message'=>__('Gamma verificata.','autonec-child-theme'));}else{$status['message']=__('Verifica parziale: nessuna scheda rimossa.','autonec-child-theme');}
     autonec_gamma_advance_source($job);
    }else{
     $record=$job['records'][$job['cursor']];$detail=call_user_func($provider,$source['url'],$record);
     if(is_wp_error($detail))$error=$detail;else{
      $validated=autonec_gamma_validate_feed(array('complete'=>true,'models'=>array($detail)),$brand,0);
      if(is_wp_error($validated))$error=$validated;elseif($validated[0]['key']!==$record['key'])$error=new WP_Error('gamma_identity',__('La fonte ha cambiato identità del modello.','autonec-child-theme'));else{
       $id=autonec_gamma_sync_model($brand,$validated[0]);if(is_wp_error($id))$error=$id;else{
        $job['seen'][]=$validated[0]['key'];$job['retry']=0;$job['post_id']=$id;
        $photo=get_post_thumbnail_id($id);$auto=(int)get_post_meta($id,'_an_gamma_photo_auto_id',true);$manual=get_post_meta($id,'_an_gamma_photo_manual',true)||($photo&&$photo!==$auto);
        $candidates=array_slice($validated[0]['image_candidates']??array(),0,6);
        if(!$manual&&$validated[0]['status']!=='coming_soon'&&$candidates){$job['photo']=$candidates;$job['photo_cursor']=0;$job['photo_before']=$photo;$job['phase']='photo';}else{$job['cursor']++;$job['done']++;}
       }
      }
     }
    }
   }elseif($job['phase']==='photo'){
    $candidate=$job['photo'][$job['photo_cursor']]??null;$id=$job['post_id'];
    if(!$candidate||get_post_thumbnail_id($id)!==$job['photo_before']){$job['phase']='details';$job['cursor']++;$job['done']++;if(!$candidate){$job['warnings']++;update_post_meta($id,'_an_gamma_review',1);}}
    else{
     $image=autonec_gamma_import_photo($candidate['url'],$id,array('focal'=>$candidate['focal']??array(.5,.5)));
     if(is_wp_error($image)){$job['photo_cursor']++;}else{
      wp_cache_delete($id,'post_meta');
      if(get_post_thumbnail_id($id)===$job['photo_before']&&!get_post_meta($id,'_an_gamma_photo_manual',true)){
       $assigned=$job['photo_before']?update_post_meta($id,'_thumbnail_id',$image,$job['photo_before']):add_post_meta($id,'_thumbnail_id',$image,true);
       if($assigned||get_post_thumbnail_id($id)===$image)update_post_meta($id,'_an_gamma_photo_auto_id',$image);
      }
      $job['phase']='details';$job['cursor']++;$job['done']++;}
    }
   }
  }catch(Throwable $e){$error=new WP_Error('gamma_exception',__('La fonte non può essere verificata ora. Verrà riprovata.','autonec-child-theme'));}
  if($error){$job['retry']++;$status['attempt']=time();$status['message']=$error->get_error_message();if($job['retry']>=2){$job['errors'][]=$brand.': '.$error->get_error_message();if($job['phase']==='discover'){$job['done']++;autonec_gamma_advance_source($job);}else{$job['source_failed']=true;$job['cursor']++;$job['done']++;$job['retry']=0;}}}
  $statuses[$brand]=$status;update_option('an_gamma_source_status',$statuses,false);update_option('an_gamma_job',$job,false);
  update_option('an_gamma_state',array_merge(autonec_gamma_state(),array('status'=>'running','message'=>sprintf(__('Aggiornamento %s.','autonec-child-theme'),ucfirst($brand)),'done'=>$job['done'],'total'=>$job['total'],'errors'=>$job['errors'],'warnings'=>$job['warnings'])),false);autonec_gamma_queue();return true;
 }finally{autonec_gamma_unlock($lock);}
}
add_action('an_gamma_daily','autonec_gamma_start');add_action('an_gamma_worker','autonec_gamma_worker');
add_action('init',static function(){if(!autonec_gamma_sources())return;if(!wp_next_scheduled('an_gamma_daily'))wp_schedule_event(time()+DAY_IN_SECONDS,'daily','an_gamma_daily');if(get_option('an_gamma_job')&&!wp_next_scheduled('an_gamma_worker'))autonec_gamma_queue();},50);

add_action('switch_theme',static function(){wp_clear_scheduled_hook('an_gamma_daily');wp_clear_scheduled_hook('an_gamma_worker');delete_option('an_gamma_job');delete_option('an_gamma_lock');});
