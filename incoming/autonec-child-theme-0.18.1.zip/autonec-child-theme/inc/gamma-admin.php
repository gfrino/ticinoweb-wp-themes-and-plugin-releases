<?php
/** A small native model editor and source provenance. */
defined('ABSPATH') || exit;
add_filter('use_block_editor_for_post_type',static fn($enabled,$type)=>$type==='modelli'?false:$enabled,10,2);
add_action('add_meta_boxes',static function($type){if($type==='modelli'){remove_meta_box('postcustom','modelli','normal');add_meta_box('an-model-data',__('Informazioni del modello','autonec-child-theme'),'autonec_gamma_editor_box','modelli','normal','high');}},100);
/** Group current local families under the four CMS marques; retain saved aliases in their own group. */
function autonec_gamma_editor_family_groups( $data ) {
 $groups = array();
 foreach ( autonec_brand_pages() as $page ) {
  $slug = sanitize_title( (string) get_post_meta( $page['page_id'], '_an_catalogue_brand', true ) );
  if ( ! $slug ) { continue; }
  $families = (array) ( autonec_catalogue_facets( $slug )['modello'] ?? array() );
  if ( $slug === $data['brand_slug'] ) { $families = array_merge( $families, (array) $data['stock_models'] ); }
  $families = array_values( array_unique( array_filter( $families, 'is_string' ) ) );
  natcasesort( $families );
  $groups[$slug] = array( 'name'=>rtrim( wp_strip_all_tags( $page['title'] ), '. ' ), 'families'=>array_values( $families ) );
 }
 return $groups;
}

add_action( 'admin_enqueue_scripts', static function( $hook ) {
 $screen = get_current_screen();
 if ( ! $screen || 'modelli' !== $screen->post_type || ! in_array( $hook, array( 'post.php', 'post-new.php' ), true ) ) { return; }
 wp_enqueue_script( 'autonec-gamma-admin', get_stylesheet_directory_uri() . '/assets/js/gamma-admin.js', array(), wp_get_theme()->get( 'Version' ), true );
} );

add_action( 'admin_menu', static function() {
 foreach ( autonec_brand_pages() as $brand ) {
  $slug = sanitize_title( (string) get_post_meta( $brand['page_id'], '_an_catalogue_brand', true ) );
  if ( ! $slug ) { continue; }
  $name = rtrim( wp_strip_all_tags( $brand['title'] ), '. ' );
  add_submenu_page( 'edit.php?post_type=modelli', $name, $name, 'edit_posts', 'edit.php?post_type=modelli&an_gamma_brand=' . rawurlencode( $slug ) );
 }
} );

/** Hash normalized editable values; list order is presentation, not a changed fact. */
function autonec_gamma_editor_hashes($data){
 $hashes=array();
 foreach(array('brand_slug','category','status','powertrains','source_url','stock_models') as $field){
  $value=$data[$field];
  if(is_array($value)){$value=array_values(array_unique($value));sort($value,SORT_STRING);}
  $hashes[$field]=hash('sha256',wp_json_encode($value));
 }
 return $hashes;
}

/** Keep fresh facts when the editor left their original normalized value untouched. */
function autonec_gamma_editor_merge($input,$initial,$fresh){
 $clean=autonec_gamma_sanitize_data($input);if(is_wp_error($clean))return $clean;
 $result=array('data'=>$clean,'can_verify'=>true);
 // Older open forms have no hashes: retain their existing explicit-save contract.
 if($initial===null)return $result;
 $submitted=autonec_gamma_editor_hashes($clean);$current=autonec_gamma_editor_hashes($fresh);
 if(!is_array($initial)||count($initial)!==count($submitted)||array_diff(array_keys($initial),array_keys($submitted)))return new WP_Error('model_data',__('I dati del modello non sono validi.','autonec-child-theme'));
 foreach($submitted as $field=>$hash){
  if(!is_string($initial[$field]??null)||!preg_match('/^[a-f0-9]{64}$/D',$initial[$field]))return new WP_Error('model_data',__('I dati del modello non sono validi.','autonec-child-theme'));
  if(hash_equals($initial[$field],$hash)){
   $result['data'][$field]=$fresh[$field];
   // A checked box cannot attest source facts which changed after the form opened.
   if($field!=='stock_models'&&!hash_equals($hash,$current[$field]))$result['can_verify']=false;
  }
 }
 return $result;
}

function autonec_gamma_editor_box($post){$r=autonec_gamma_data($post->ID);wp_nonce_field('an_gamma_model','an_gamma_nonce');
 foreach(autonec_gamma_editor_hashes($r) as $field=>$hash){?><input type="hidden" name="an_model_initial[<?php echo esc_attr($field);?>]" value="<?php echo esc_attr($hash);?>"><?php }?>
 <p><?php esc_html_e('Questa scheda presenta un modello della gamma nuova. Foto, titolo, riassunto e descrizione si modificano nei riquadri WordPress. Le singole vetture disponibili restano nel catalogo Veicoli.','autonec-child-theme'); ?></p>
 <?php if(get_post_meta($post->ID,'_an_gamma_review',true)):?><div class="notice notice-warning inline"><p><?php esc_html_e('La fonte ufficiale è cambiata. Le tue modifiche sono conservate: verifica testo e fotografia, quindi conferma la scheda qui sotto.','autonec-child-theme');?></p></div><?php endif;?>
 <table class="form-table"><tbody>
 <tr><th><label for="an-model-brand"><?php esc_html_e('Marchio','autonec-child-theme'); ?></label></th><td><select id="an-model-brand" name="an_model[brand_slug]" required><option value=""><?php esc_html_e('Scegli il marchio','autonec-child-theme'); ?></option><?php foreach(autonec_brand_pages() as $page):$slug=get_post_meta($page['page_id'],'_an_catalogue_brand',true);if(!$slug)continue;?><option value="<?php echo esc_attr($slug); ?>" <?php selected($r['brand_slug'],$slug); ?>><?php echo esc_html(rtrim(wp_strip_all_tags($page['title']),'. ')); ?></option><?php endforeach; ?></select></td></tr>
 <tr><th><label for="an-model-category"><?php esc_html_e('Categoria','autonec-child-theme'); ?></label></th><td><select id="an-model-category" name="an_model[category]"><option value=""><?php esc_html_e('Non specificata','autonec-child-theme'); ?></option><?php foreach(autonec_gamma_categories() as $key=>$label):?><option value="<?php echo esc_attr($key); ?>" <?php selected($r['category'],$key); ?>><?php echo esc_html($label); ?></option><?php endforeach; ?></select></td></tr>
 <tr><th><label for="an-model-status"><?php esc_html_e('Stato nella gamma','autonec-child-theme'); ?></label></th><td><select id="an-model-status" name="an_model[status]"><option value="current" <?php selected($r['status'],'current'); ?>><?php esc_html_e('Gamma attuale','autonec-child-theme'); ?></option><option value="coming_soon" <?php selected($r['status'],'coming_soon'); ?>><?php esc_html_e('In arrivo','autonec-child-theme'); ?></option><option value="archived" <?php selected($r['status'],'archived'); ?>><?php esc_html_e('Fuori gamma','autonec-child-theme'); ?></option></select></td></tr>
 <tr><th><label for="an-model-energy"><?php esc_html_e('Motorizzazioni','autonec-child-theme'); ?></label></th><td><input id="an-model-energy" class="large-text" name="an_model[powertrains]" value="<?php echo esc_attr(implode(', ',$r['powertrains'])); ?>"><p class="description"><?php esc_html_e('Separa le alimentazioni con una virgola. Inserisci solo quelle confermate dal costruttore.','autonec-child-theme'); ?></p></td></tr>
 <tr><th><label for="an-model-source"><?php esc_html_e('Pagina ufficiale','autonec-child-theme'); ?></label></th><td><input id="an-model-source" type="url" class="large-text" name="an_model[source_url]" value="<?php echo esc_attr($r['source_url']); ?>"><p class="description"><?php echo esc_html($r['source_checked']?sprintf(__('Ultima verifica: %s','autonec-child-theme'),wp_date(get_option('date_format'),$r['source_checked'])):__('Fonte da verificare','autonec-child-theme')); ?></p><label><input type="checkbox" name="an_model_verified" value="1"> <?php esc_html_e('Ho verificato questa scheda sulla fonte ufficiale','autonec-child-theme'); ?></label></td></tr>
 <tr><th><?php esc_html_e('Vetture della stessa famiglia','autonec-child-theme'); ?></th><td>
 <div data-an-gamma-families>
  <p data-an-gamma-family-prompt hidden><?php esc_html_e('Scegli prima il marchio per vedere le famiglie disponibili.','autonec-child-theme'); ?></p>
  <noscript><p class="description"><?php esc_html_e('Seleziona le famiglie solo nel gruppo del marchio scelto.','autonec-child-theme'); ?></p></noscript>
  <?php foreach ( autonec_gamma_editor_family_groups( $r ) as $slug=>$group ) : ?>
   <fieldset data-an-gamma-family-group="<?php echo esc_attr( $slug ); ?>" style="margin:0 0 18px">
    <legend style="font-weight:600;margin-bottom:10px"><?php echo esc_html( $group['name'] ); ?></legend>
    <?php foreach ( $group['families'] as $family ) : ?>
     <label style="display:inline-flex;align-items:center;margin:0 22px 12px 0"><input type="checkbox" name="an_model[stock_models][]" value="<?php echo esc_attr( $family ); ?>" <?php checked( $slug === $r['brand_slug'] && in_array( $family, $r['stock_models'], true ) ); ?>> <?php echo esc_html( $family ); ?></label>
    <?php endforeach; ?>
    <?php if ( ! $group['families'] ) : ?><p><?php esc_html_e('Non ci sono famiglie di vetture da collegare per questo marchio.','autonec-child-theme'); ?></p><?php endif; ?>
   </fieldset>
  <?php endforeach; ?>
  <p class="description"><?php esc_html_e('Seleziona solo le famiglie corrispondenti. Gli annunci possono appartenere a versioni o generazioni precedenti: il collegamento non indica che questa specifica versione nuova sia in stock.','autonec-child-theme'); ?></p>
 </div></td></tr>
 </tbody></table><?php
}
/** A new editor model with invalid classification/source must not enter the public range. */
add_filter('wp_insert_post_data',static function($data,$postarr){
 if(($data['post_type']??'')!=='modelli'||($data['post_status']??'')!=='publish'||get_post_status(absint($postarr['ID']??0))==='publish'||!current_user_can('edit_posts'))return $data;
 if(empty($_POST['an_gamma_nonce'])||!is_string($_POST['an_gamma_nonce'])||!wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['an_gamma_nonce'])),'an_gamma_model'))return $data;
 $values=wp_unslash($_POST['an_model']??array());
 if(is_wp_error(autonec_gamma_sanitize_data($values)))$data['post_status']='draft';
 return $data;
},10,2);

add_action('save_post_modelli',static function($id){
 if(wp_is_post_autosave($id)||wp_is_post_revision($id)||!current_user_can('edit_post',$id)||empty($_POST['an_gamma_nonce'])||!is_string($_POST['an_gamma_nonce'])||!wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['an_gamma_nonce'])),'an_gamma_model'))return;
 $input=wp_unslash($_POST['an_model']??array());if(!is_array($input))return;$old=autonec_gamma_data($id);
 $has_initial=array_key_exists('an_model_initial',$_POST);$initial=$has_initial?wp_unslash($_POST['an_model_initial']):null;
 $merged=$has_initial&&!is_array($initial)?new WP_Error('model_data',__('I dati del modello non sono validi.','autonec-child-theme')):autonec_gamma_editor_merge($input,$initial,$old);
 if(is_wp_error($merged)){set_transient('an_gamma_error_'.get_current_user_id(),$merged->get_error_message(),60);return;}
 $input=$merged['data'];$verified=!empty($_POST['an_model_verified'])&&$merged['can_verify'];
 // The same brand boundary applies without JavaScript; unknown/manual POST values are never linked.
 $groups = autonec_gamma_editor_family_groups( $old );
 $brand = isset( $input['brand_slug'] ) && is_scalar( $input['brand_slug'] ) ? sanitize_title( $input['brand_slug'] ) : '';
 $submitted = isset( $input['stock_models'] ) && is_array( $input['stock_models'] ) ? array_map( 'strval', array_filter( $input['stock_models'], 'is_scalar' ) ) : array();
 $input['stock_models'] = array_values( array_intersect( $submitted, $groups[$brand]['families'] ?? array() ) );
 $input['source_checked']=$verified?time():$old['source_checked'];$result=autonec_gamma_save_data($id,$input);if(!is_wp_error($result)&&$verified){delete_post_meta($id,'_an_gamma_review');delete_post_meta($id,'_an_gamma_review_fields');delete_post_meta($id,'_an_gamma_photo_review');}
 if(is_wp_error($result))set_transient('an_gamma_error_'.get_current_user_id(),$result->get_error_message(),60);
});
add_action('admin_notices',static function(){$error=get_transient('an_gamma_error_'.get_current_user_id());if($error){delete_transient('an_gamma_error_'.get_current_user_id());echo '<div class="notice notice-error"><p>'.esc_html($error).'</p></div>';}});
add_filter('manage_modelli_posts_columns',static function($columns){return array('cb'=>$columns['cb'],'title'=>__('Modello','autonec-child-theme'),'taxonomy-an_marca'=>__('Marchio','autonec-child-theme'),'an_gamma_status'=>__('Gamma','autonec-child-theme'),'an_gamma_checked'=>__('Fonte verificata','autonec-child-theme'),'date'=>$columns['date']);});
add_action('manage_modelli_posts_custom_column',static function($column,$id){$r=autonec_gamma_data($id);if($column==='an_gamma_status')echo esc_html($r['status']==='archived'?__('Fuori gamma','autonec-child-theme'):($r['status']==='coming_soon'?__('In arrivo','autonec-child-theme'):__('Attuale','autonec-child-theme')));if($column==='an_gamma_checked'){echo esc_html($r['source_checked']?wp_date(get_option('date_format'),$r['source_checked']):'—');if(get_post_meta($id,'_an_gamma_review',true))echo '<br><strong>'.esc_html__('Da verificare','autonec-child-theme').'</strong>';}},10,2);
add_action('restrict_manage_posts',static function($type){if($type!=='modelli')return;$slugs=autonec_catalogue_main_brand_slugs();$ids=$slugs?get_terms(array('taxonomy'=>'an_marca','slug'=>$slugs,'fields'=>'ids','hide_empty'=>false)):array();$ids=is_wp_error($ids)?array():$ids;wp_dropdown_categories(array('include'=>$ids?:array(0),'taxonomy'=>'an_marca','name'=>'an_gamma_brand','value_field'=>'slug','selected'=>isset($_GET['an_gamma_brand'])&&is_string($_GET['an_gamma_brand'])?sanitize_title(wp_unslash($_GET['an_gamma_brand'])):'','show_option_all'=>__('Tutti i marchi','autonec-child-theme'),'hide_empty'=>false));});
add_action('pre_get_posts',static function($query){if(is_admin()&&$query->is_main_query()&&$query->get('post_type')==='modelli'&&!empty($_GET['an_gamma_brand'])&&is_string($_GET['an_gamma_brand']))$query->set('meta_query',array(array('key'=>'_an_model_brand','value'=>sanitize_title(wp_unslash($_GET['an_gamma_brand'])))));});

add_filter('post_type_labels_modelli',static function($labels){$labels->all_items=__('Tutti i modelli','autonec-child-theme');$labels->search_items=__('Cerca modelli','autonec-child-theme');$labels->not_found=__('Nessun modello trovato','autonec-child-theme');return $labels;});
