<?php
/** Native contact-page locations, hours and optional social links. @package AutonecChildTheme */
if ( ! defined( 'ABSPATH' ) ) { exit; }

function autonec_contact_hours( $hours ) {
 $result = array(); if ( ! is_array( $hours ) ) { return $result; }
 global $wp_locale;
 foreach ( array( 'monday'=>1,'tuesday'=>2,'wednesday'=>3,'thursday'=>4,'friday'=>5,'saturday'=>6,'sunday'=>0 ) as $day=>$number ) {
  if ( ! array_key_exists( $day, $hours ) ) { continue; }
  $formatted = ticinoweb_format_day_hours( $hours[$day] );
  if ( $formatted ) { $result[$wp_locale->get_weekday($number)] = $formatted; }
 }
 return $result;
}

function autonec_contact_socials( $contact ) {
 $result = array();
 foreach ( array('facebook'=>'Facebook','instagram'=>'Instagram','linkedin'=>'LinkedIn','youtube'=>'YouTube','x'=>'X','tiktok'=>'TikTok','behance'=>'Behance','github'=>'GitHub') as $key=>$label ) {
  if ( ! empty($contact[$key]) && esc_url($contact[$key]) ) { $result[] = array('url'=>$contact[$key],'label'=>$label); }
 }
 return $result;
}

/** Enhance named Core groups using existing CMS addresses, never duplicated copy. */
function autonec_contact_location( $html, $block ) {
 if ( ! is_page_template( 'template-contact.php' ) ) { return $html; }
 $classes = preg_split('/\s+/', $block['attrs']['className'] ?? '');
 if ( in_array('an-contact-place--main',$classes,true) ) { $suffix = ''; }
 elseif ( in_array('an-contact-place--showroom',$classes,true) ) { $suffix = '_2'; }
 else { return $html; }
 $contact = ticinoweb_get_contact_info();
 $address = $contact['address'.$suffix];
 if ( ! $address ) { return ''; }
 if ( $suffix ) { $address = ticinoweb_frontend_text( $address, 'theme:contact:address'.$suffix ); }
 $label = ticinoweb_frontend_text( $contact['address'.$suffix.'_label'], 'theme:contact:address'.$suffix.'_label' );
 $url = ! $suffix && $contact['map_url'] ? $contact['map_url'] : 'https://www.google.com/maps/search/?api=1&query='.rawurlencode($address);
 $details = '<header class="an-contact-place__heading"><h2>'.esc_html($label ?: __('Indirizzo','autonec-child-theme')).'</h2><address>'.nl2br(esc_html($address)).'</address><a class="an-link" aria-label="'.esc_attr(sprintf(__('Indicazioni stradali: %s','autonec-child-theme'),$label ?: $address)).'" href="'.esc_url($url).'" target="_blank" rel="noopener noreferrer">'.esc_html__('Indicazioni stradali','autonec-child-theme').'</a></header>';
 return preg_replace_callback('/^\s*<(?:div|section|article)\b[^>]*>/',static fn($match)=>$match[0].$details,$html,1);
}
add_filter('render_block_core/group','autonec_contact_location',20,2);

/** Match native responsive-image selection to the two-column contact layout. */
function autonec_contact_image_sizes( $html ) {
 if ( ! is_page_template( 'template-contact.php' ) ) { return $html; }
 $image = new WP_HTML_Tag_Processor( $html );
 if ( $image->next_tag( 'IMG' ) ) {
  $image->set_attribute( 'sizes', '(max-width: 899px) 100vw, 46vw' );
 }
 return $image->get_updated_html();
}
add_filter('render_block_core/image','autonec_contact_image_sizes');
