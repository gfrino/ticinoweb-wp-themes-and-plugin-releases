<?php
/** Native vehicle editing. Imported snapshots and local editorial choices remain separate. */
defined('ABSPATH') || exit;

function autonec_catalogue_editor_fields() {
 return array(
  'brand'=>array('label'=>__('Marchio','autonec-child-theme'),'type'=>'text'),
  'model'=>array('label'=>__('Modello e versione','autonec-child-theme'),'type'=>'text'),
  'price'=>array('label'=>__('Prezzo','autonec-child-theme'),'type'=>'number'),
  'currency'=>array('label'=>__('Valuta','autonec-child-theme'),'type'=>'text'),
  'availability'=>array('label'=>__('Disponibilità','autonec-child-theme'),'type'=>'select'),
  'reserved'=>array('label'=>__('Riservata','autonec-child-theme'),'type'=>'checkbox'),
  'condition'=>array('label'=>__('Condizione','autonec-child-theme'),'type'=>'text'),
  'year'=>array('label'=>__('Anno','autonec-child-theme'),'type'=>'number'),
  'mileage'=>array('label'=>__('Chilometraggio','autonec-child-theme'),'type'=>'number'),
  'fuel'=>array('label'=>__('Alimentazione','autonec-child-theme'),'type'=>'text'),
  'transmission'=>array('label'=>__('Cambio','autonec-child-theme'),'type'=>'text'),
  'power'=>array('label'=>__('Potenza','autonec-child-theme'),'type'=>'text'),
  'body'=>array('label'=>__('Carrozzeria','autonec-child-theme'),'type'=>'text'),
  'color'=>array('label'=>__('Colore','autonec-child-theme'),'type'=>'text'),
  'first_registration'=>array('label'=>__('Prima immatricolazione','autonec-child-theme'),'type'=>'text'),
  'doors'=>array('label'=>__('Porte','autonec-child-theme'),'type'=>'number','min'=>1,'max'=>10),
  'seats'=>array('label'=>__('Posti','autonec-child-theme'),'type'=>'number','min'=>1,'max'=>100),
  'drive'=>array('label'=>__('Trazione','autonec-child-theme'),'type'=>'text'),
  'displacement'=>array('label'=>__('Cilindrata (cc)','autonec-child-theme'),'type'=>'number','min'=>1,'max'=>30000),
  'description'=>array('label'=>__('Descrizione del veicolo','autonec-child-theme'),'type'=>'editor'),
  'gallery'=>array('label'=>__('Fotografie del veicolo','autonec-child-theme'),'type'=>'gallery'),
 );
}

function autonec_catalogue_editor_groups() {
 return array(
  array('label'=>__('Identità del veicolo','autonec-child-theme'),'fields'=>array('brand','model','condition','color','year','first_registration')),
  array('label'=>__('Prezzo e disponibilità','autonec-child-theme'),'fields'=>array('price','currency','availability','reserved')),
  array('label'=>__('Dati tecnici','autonec-child-theme'),'fields'=>array('mileage','fuel','transmission','power','body','drive','displacement','doors','seats')),
 );
}

/** Reject malformed choices as one unit; never partially overwrite an existing selection. */
function autonec_catalogue_sanitize_local($input) {
 if (!is_array($input) || array_diff(array_keys($input), array_keys(autonec_catalogue_editor_fields()))) return new WP_Error('vehicle_fields', __('I dati del veicolo non sono validi.','autonec-child-theme'));
 $clean = array();
 foreach ($input as $field=>$value) {
  if ($field === 'gallery') {
   if (is_string($value)) $value = $value === '' ? array() : explode(',', $value);
   if (!is_array($value) || count($value)>60) return new WP_Error('vehicle_gallery', __('Seleziona al massimo 60 fotografie dalla Libreria Media.','autonec-child-theme'));
   $photos=array();
   foreach ($value as $photo) {
    if (!is_scalar($photo) || !preg_match('/^[1-9][0-9]*$/D',(string)$photo) || !wp_attachment_is_image((int)$photo) || get_post_status((int)$photo)==='trash' || !current_user_can('read_post',(int)$photo)) return new WP_Error('vehicle_photo', __('La galleria può contenere soltanto immagini accessibili della Libreria Media.','autonec-child-theme'));
    $photos[]=(int)$photo;
   }
   $clean[$field]=array_values(array_unique($photos));continue;
  }
  if (!is_scalar($value) && $value!==null) return new WP_Error('vehicle_value', __('Un campo contiene un valore non valido.','autonec-child-theme'));
  if (in_array($field,array('doors','seats','displacement'),true)) {
   if($value===''||$value===null){$clean[$field]=null;continue;}
   $bounds=autonec_catalogue_editor_fields()[$field];
   if(!is_numeric($value)||(float)$value!==(float)(int)$value||(int)$value<$bounds['min']||(int)$value>$bounds['max'])return new WP_Error('vehicle_technical_number',__('Controlla il numero di porte, i posti e la cilindrata.','autonec-child-theme'));
   $clean[$field]=(int)$value;continue;
  }
  if (in_array($field,array('price','mileage','year'),true)) {
   if ($value==='' || $value===null) {$clean[$field]=null;continue;}
   if (!is_numeric($value) || !is_finite((float)$value) || (float)$value<0 || (float)$value>1e12 || ($field==='year' && ((float)$value!==(float)(int)$value || (int)$value<1900 || (int)$value>((int)gmdate('Y')+2)))) return new WP_Error('vehicle_number', __('Controlla prezzo, chilometraggio e anno: usa numeri validi, senza separatori delle migliaia.','autonec-child-theme'));
   $clean[$field]=$field==='year'?(int)$value:(float)$value;continue;
  }
  if ($field==='reserved') {$clean[$field]=in_array($value,array(true,1,'1'),true);continue;}
  if ($field==='availability') {
   if (!in_array($value,array('available','unavailable','sold'),true)) return new WP_Error('vehicle_status', __('Scegli una disponibilità valida.','autonec-child-theme'));
   $clean[$field]=$value;continue;
  }
  $clean[$field]=$field==='description'?wp_kses_post((string)$value):sanitize_text_field((string)$value);
  if ($field==='currency') {
   $clean[$field]=strtoupper($clean[$field]);
   if ($clean[$field]!==''&&!preg_match('/^[A-Z]{3}$/D',$clean[$field]))return new WP_Error('vehicle_currency', __('Inserisci una valuta di tre lettere, per esempio CHF.','autonec-child-theme'));
  }
  if ($field==='brand' && $clean[$field]==='') return new WP_Error('vehicle_brand', __('Inserisci il marchio del veicolo.','autonec-child-theme'));
 }
 return $clean;
}

/** Omitted fields preserve existing choices. Reset keys explicitly restore the latest source. */
function autonec_catalogue_save_local($id, $input, $reset=array()) {
 if (get_post_type($id)!=='veicoli' || !current_user_can('edit_post',$id)) return new WP_Error('vehicle_access', __('Non hai i permessi per modificare questo veicolo.','autonec-child-theme'));
 $clean=autonec_catalogue_sanitize_local($input);if(is_wp_error($clean))return $clean;
 $allowed=array_keys(autonec_catalogue_editor_fields());
 if (!is_array($reset) || array_filter($reset,static fn($key)=>!is_string($key)||!in_array($key,$allowed,true))) return new WP_Error('vehicle_reset', __('I campi da ripristinare non sono validi.','autonec-child-theme'));
 $raw=autonec_catalogue_raw_data($id);$local=get_post_meta($id,'_an_vehicle_overrides',true);$local=is_array($local)?array_intersect_key($local,autonec_catalogue_editor_fields()):array();
 foreach ($clean as $key=>$value) {
  if (array_key_exists($key,$raw) && $value===$raw[$key]) unset($local[$key]);
  else $local[$key]=$value;
 }
 foreach($reset as $key)unset($local[$key]);
 if ($local) update_post_meta($id,'_an_vehicle_overrides',wp_slash($local));else delete_post_meta($id,'_an_vehicle_overrides');
 if (!get_post_meta($id,'_an_external_key',true)) update_post_meta($id,'_an_vehicle_manual',1);
 if (!metadata_exists('post',$id,'_an_vehicle_featured'))update_post_meta($id,'_an_vehicle_featured',0);
 return autonec_catalogue_index($id);
}

function autonec_catalogue_editor_hash($value) { return hash('sha256',wp_json_encode($value)); }

/** Native save hook; no public mutation route. Initial hashes avoid freezing untouched stale source data. */
function autonec_catalogue_editor_save($id) {
 if(wp_is_post_autosave($id)||wp_is_post_revision($id)||!current_user_can('edit_post',$id)||!isset($_POST['an_vehicle_nonce'])||!is_string($_POST['an_vehicle_nonce'])||!wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['an_vehicle_nonce'])),'an_vehicle_editor'))return;
 $input=wp_unslash($_POST['an_vehicle_fields']??array());$initial=wp_unslash($_POST['an_vehicle_initial']??array());$reset=wp_unslash($_POST['an_vehicle_reset']??array());
 if(!is_array($input)||!is_array($initial)||!is_array($reset))return;
 $clean=autonec_catalogue_sanitize_local($input);
 if(!is_wp_error($clean)) {
  foreach($clean as $key=>$value)if(isset($initial[$key])&&is_string($initial[$key])&&hash_equals(autonec_catalogue_editor_hash($value),$initial[$key]))unset($clean[$key]);
  $result=autonec_catalogue_save_local($id,$clean,array_keys($reset));
 } else $result=$clean;
 if(is_wp_error($result)) {set_transient('an_vehicle_editor_error_'.get_current_user_id(),$result->get_error_message(),60);return;}
 update_post_meta($id,'_an_vehicle_featured',empty($_POST['an_vehicle_featured'])?0:1);
}
add_action('save_post_veicoli','autonec_catalogue_editor_save');
add_action('admin_notices',static function(){ $error=get_transient('an_vehicle_editor_error_'.get_current_user_id());if(!$error)return;delete_transient('an_vehicle_editor_error_'.get_current_user_id());echo '<div class="notice notice-error"><p>'.esc_html($error).'</p></div>'; });

// A single coherent form instead of an empty block canvas and a second imported-data panel.
add_filter('use_block_editor_for_post_type',static fn($enabled,$type)=>$type==='veicoli'?false:$enabled,10,2);
add_action('add_meta_boxes_veicoli',static function(){
 remove_meta_box('postcustom','veicoli','normal');

});

// Keep the structured vehicle form immediately after its title; the native body remains optional.
add_action('edit_form_after_title',static function($post){
 if($post->post_type!=='veicoli')return;
 echo '<div id="an-vehicle-editor" class="postbox"><div class="postbox-header"><h2>'.esc_html__('Scheda del veicolo','autonec-child-theme').'</h2></div><div class="inside">';
 autonec_catalogue_editor_box($post);
 echo '</div></div><h2 class="an-editor-notes-heading">'.esc_html__('Note editoriali aggiuntive (facoltative)','autonec-child-theme').'</h2>';
});

function autonec_catalogue_editor_origin($key,$raw,$local) {
 if (!$raw) return;
 $overridden=array_key_exists($key,$local);
 $source_label=!array_key_exists($key,$raw)||$raw[$key]===null||$raw[$key]===''||$raw[$key]===array()?__('Non indicato dalla fonte','autonec-child-theme'):__('Aggiornato dalla fonte','autonec-child-theme');
 ?><div class="an-editor-origin"><span data-origin-label><?php echo esc_html($overridden?__('Modifica locale','autonec-child-theme'):$source_label); ?></span><label><input type="checkbox" name="an_vehicle_reset[<?php echo esc_attr($key); ?>]" value="1" data-restore-source> <?php esc_html_e('Ripristina dalla fonte','autonec-child-theme'); ?></label></div><?php
}

function autonec_catalogue_editor_box($post) {
 $id=$post->ID;$raw=autonec_catalogue_raw_data($id);$data=autonec_catalogue_data($id);$local=get_post_meta($id,'_an_vehicle_overrides',true);$local=is_array($local)?$local:array();
 $data=wp_parse_args($data,array('availability'=>'available','reserved'=>false,'gallery'=>array(),'currency'=>'CHF'));
 wp_nonce_field('an_vehicle_editor','an_vehicle_nonce');
 ?>
 <div class="an-vehicle-editor">
 <div class="an-editor-intro"><div><span class="an-editor-eyebrow"><?php echo esc_html($raw?__('Veicolo sincronizzato','autonec-child-theme'):__('Veicolo manuale','autonec-child-theme')); ?></span><p><?php echo esc_html($raw?__('Modifica i dati, la descrizione e le fotografie. Le tue scelte locali restano anche dopo gli aggiornamenti automatici.','autonec-child-theme'):__('Compila la scheda e aggiungi le fotografie. Questo veicolo viene gestito qui e non viene modificato dalla sincronizzazione.','autonec-child-theme')); ?></p></div><label class="an-editor-featured"><input type="checkbox" name="an_vehicle_featured" value="1" <?php checked(get_post_meta($id,'_an_vehicle_featured',true)); ?>> <?php esc_html_e('In evidenza','autonec-child-theme'); ?></label></div>
 <?php $fields=autonec_catalogue_editor_fields();foreach(autonec_catalogue_editor_groups() as $group): ?>
 <section class="an-editor-group"><h3><?php echo esc_html($group['label']); ?></h3><div class="an-editor-fields">
 <?php foreach($group['fields'] as $key):$field=$fields[$key];$value=$data[$key]??''; ?>
 <div class="an-editor-field" data-editor-field><label for="an-field-<?php echo esc_attr($key); ?>"><?php echo esc_html($field['label']); ?></label>
 <?php if($field['type']==='select'): ?><select id="an-field-<?php echo esc_attr($key); ?>" name="an_vehicle_fields[<?php echo esc_attr($key); ?>]"><?php foreach(array('available'=>__('Disponibile','autonec-child-theme'),'unavailable'=>__('Non disponibile','autonec-child-theme'),'sold'=>__('Venduta','autonec-child-theme')) as $option=>$label): ?><option value="<?php echo esc_attr($option); ?>" <?php selected($value,$option); ?>><?php echo esc_html($label); ?></option><?php endforeach; ?></select>
 <?php elseif($field['type']==='checkbox'): ?><input type="hidden" name="an_vehicle_fields[<?php echo esc_attr($key); ?>]" value="0"><label class="an-editor-check"><input type="checkbox" id="an-field-<?php echo esc_attr($key); ?>" name="an_vehicle_fields[<?php echo esc_attr($key); ?>]" value="1" <?php checked(!empty($value)); ?>> <?php esc_html_e('Veicolo riservato','autonec-child-theme'); ?></label>
 <?php else: ?><input id="an-field-<?php echo esc_attr($key); ?>" type="<?php echo esc_attr($field['type']); ?>" name="an_vehicle_fields[<?php echo esc_attr($key); ?>]" value="<?php echo esc_attr($value); ?>" <?php if($field['type']==='number')echo 'min="'.esc_attr($field['min']??($key==='year'?1900:0)).'" step="'.esc_attr(in_array($key,array('year','doors','seats','displacement'),true)?'1':'any').'"';if(isset($field['max']))echo ' max="'.esc_attr($field['max']).'"'; ?> <?php if($key==='year')echo 'max="'.esc_attr((int)gmdate('Y')+2).'"'; ?> <?php if($key==='brand')echo 'required'; ?> <?php if($key==='currency')echo 'maxlength="3" placeholder="CHF"'; ?>><?php endif; ?>
 <?php $normalized=autonec_catalogue_sanitize_local(array($key=>$value));$initial=is_wp_error($normalized)?$value:$normalized[$key]; ?><input type="hidden" name="an_vehicle_initial[<?php echo esc_attr($key); ?>]" value="<?php echo esc_attr(autonec_catalogue_editor_hash($initial)); ?>">
 <?php autonec_catalogue_editor_origin($key,$raw,$local); ?></div><?php endforeach; ?>
 </div></section><?php endforeach; ?>
 <section class="an-editor-section" data-editor-field><h3><?php esc_html_e('Descrizione del veicolo','autonec-child-theme'); ?></h3>
 <?php wp_editor($data['description']??'','an_vehicle_description',array('textarea_name'=>'an_vehicle_fields[description]','textarea_rows'=>10,'media_buttons'=>false,'teeny'=>true)); ?>
 <input type="hidden" name="an_vehicle_initial[description]" value="<?php echo esc_attr(autonec_catalogue_editor_hash(wp_kses_post($data['description']??''))); ?>">
 <?php autonec_catalogue_editor_origin('description',$raw,$local); ?></section>
 <section class="an-editor-section" data-editor-field><h3><?php esc_html_e('Fotografie del veicolo','autonec-child-theme'); ?></h3><p class="description"><?php esc_html_e('Aggiungi immagini dalla Libreria Media. Trascina le foto oppure usa i pulsanti per cambiare ordine. Rimuovere una foto dalla scheda non elimina il file dalla libreria.','autonec-child-theme'); ?></p>
 <input type="hidden" name="an_vehicle_fields[gallery]" data-gallery-value value="<?php echo esc_attr(implode(',',array_map('intval',(array)$data['gallery']))); ?>"><input type="hidden" name="an_vehicle_initial[gallery]" value="<?php echo esc_attr(autonec_catalogue_editor_hash(array_values(array_map('intval',(array)$data['gallery'])))); ?>">
 <ul class="an-editor-gallery" data-vehicle-gallery><?php foreach((array)$data['gallery'] as $photo)autonec_catalogue_editor_photo($photo); ?></ul>
 <button type="button" class="button button-secondary" data-add-photos><?php esc_html_e('Aggiungi fotografie','autonec-child-theme'); ?></button><span class="screen-reader-text" role="status" data-gallery-status></span><noscript><p><?php esc_html_e('Attiva JavaScript per aggiungere o riordinare le fotografie. Gli altri campi si possono salvare normalmente.','autonec-child-theme'); ?></p></noscript>
 <?php autonec_catalogue_editor_origin('gallery',$raw,$local); ?></section>
 <p class="an-editor-save-note"><?php esc_html_e('Usa Aggiorna o Pubblica per salvare tutte le modifiche. L’immagine in evidenza si gestisce nel riquadro WordPress dedicato. Il testo libero sotto il titolo può contenere note editoriali aggiuntive.','autonec-child-theme'); ?></p>
 </div><?php
}

function autonec_catalogue_editor_photo($photo) {
 ?><li data-photo-id="<?php echo esc_attr($photo); ?>"><div class="an-editor-photo"><?php echo wp_get_attachment_image($photo,'thumbnail',false,array('loading'=>'lazy')); ?></div><div class="an-editor-photo-actions"><button type="button" class="button" data-photo-back aria-label="<?php esc_attr_e('Sposta foto prima','autonec-child-theme'); ?>">‹</button><button type="button" class="button" data-photo-next aria-label="<?php esc_attr_e('Sposta foto dopo','autonec-child-theme'); ?>">›</button><button type="button" class="button-link-delete" data-photo-remove><?php esc_html_e('Rimuovi','autonec-child-theme'); ?></button></div></li><?php
}

add_action('admin_enqueue_scripts',static function(){
 $screen=get_current_screen();if(!$screen||$screen->post_type!=='veicoli'||$screen->base!=='post')return;
 wp_enqueue_media();wp_enqueue_script('autonec-catalogue-editor',get_stylesheet_directory_uri().'/assets/js/catalogue-editor.js',array('jquery','jquery-ui-sortable','media-views'),wp_get_theme()->get('Version'),true);
 wp_enqueue_style('autonec-catalogue-editor',get_stylesheet_directory_uri().'/assets/css/catalogue-editor.css',array(),wp_get_theme()->get('Version'));
 wp_localize_script('autonec-catalogue-editor','AutonecVehicleEditor',array('title'=>__('Fotografie del veicolo','autonec-child-theme'),'select'=>__('Aggiungi alla scheda','autonec-child-theme'),'remove'=>__('Rimuovi','autonec-child-theme'),'back'=>__('Sposta foto prima','autonec-child-theme'),'next'=>__('Sposta foto dopo','autonec-child-theme'),'changed'=>__('Modifica locale','autonec-child-theme'),'reset'=>__('Ripristino al salvataggio','autonec-child-theme'),'count'=>__('%d fotografie nella scheda','autonec-child-theme')));
});
