<?php
/** Official model range, separate from physical stock. @package AutonecChildTheme */
defined('ABSPATH') || exit;

function autonec_gamma_categories(){return array('city'=>__('City car','autonec-child-theme'),'compact'=>__('Compatte','autonec-child-theme'),'saloon'=>__('Berline','autonec-child-theme'),'suv'=>__('SUV','autonec-child-theme'),'estate'=>__('Station wagon','autonec-child-theme'),'mpv'=>__('Spazio e famiglia','autonec-child-theme'),'commercial'=>__('Veicoli commerciali','autonec-child-theme'),'sport'=>__('Performance','autonec-child-theme'));}
function autonec_gamma_data($id){$v=get_post_meta($id,'_an_model_data',true);return wp_parse_args(is_array($v)?$v:array(),array('brand_slug'=>'','category'=>'','powertrains'=>array(),'status'=>'current','source_url'=>'','source_checked'=>0,'stock_models'=>array()));}
function autonec_gamma_source_url($url){
 if(!is_string($url))return new WP_Error('model_source',__('Inserisci una pagina ufficiale svizzera del costruttore, con https.','autonec-child-theme'));
 if(!$url)return '';$p=wp_parse_url($url);
 if(!$p||($p['scheme']??'')!=='https'||isset($p['user'])||isset($p['pass'])||isset($p['port'])||!in_array(strtolower($p['host']??''),array('opel.ch','www.opel.ch','hyundai.com','www.hyundai.com','leapmotor.net','www.leapmotor.net','piaggio-commercial.ch','www.piaggio-commercial.ch'),true))return new WP_Error('model_source',__('Inserisci una pagina ufficiale svizzera del costruttore, con https.','autonec-child-theme'));
 return esc_url_raw($url,array('https'));
}
function autonec_gamma_sanitize_data($input){
 $defaults=autonec_gamma_data(0);if(!is_array($input)||array_diff(array_keys($input),array_keys($defaults)))return new WP_Error('model_data',__('I dati del modello non sono validi.','autonec-child-theme'));
 $input=wp_parse_args($input,$defaults);$data=array();
 foreach(array('brand_slug','category','status') as $key){if(!is_scalar($input[$key]))return new WP_Error('model_data',__('I dati del modello non sono validi.','autonec-child-theme'));$data[$key]=sanitize_key($input[$key]);}
 if(!in_array($data['brand_slug'],autonec_catalogue_main_brand_slugs(),true)||!in_array($data['status'],array('current','coming_soon','archived'),true)||($data['category']&&!isset(autonec_gamma_categories()[$data['category']])))return new WP_Error('model_class',__('Controlla marchio, categoria e stato del modello.','autonec-child-theme'));
 $source=autonec_gamma_source_url($input['source_url']);if(is_wp_error($source))return $source;$data['source_url']=$source;
 $data['source_checked']=is_numeric($input['source_checked'])?max(0,min(time(),(int)$input['source_checked'])):0;
 foreach(array('powertrains','stock_models') as $key){$values=$input[$key];if(is_string($values))$values=preg_split('/[\r\n,]+/',$values);if(!is_array($values)||count($values)>30)return new WP_Error('model_list',__('Inserisci un elenco valido di valori.','autonec-child-theme'));$clean=array();foreach($values as $value){if(!is_scalar($value))return new WP_Error('model_list',__('Inserisci un elenco valido di valori.','autonec-child-theme'));$value=mb_substr(sanitize_text_field($value),0,120);if($value!=='')$clean[]=$value;}$data[$key]=array_values(array_unique($clean));}
 return $data;
}
function autonec_gamma_save_data($id,$input){
 if(get_post_type($id)!=='modelli'||!current_user_can('edit_post',$id))return new WP_Error('model_access',__('Non hai i permessi per modificare questo modello.','autonec-child-theme'));
 $old=autonec_gamma_data($id);
 if(is_array($input)&&isset($input['source_url'],$input['source_checked'])&&$old['source_url']&&$old['source_url']!==$input['source_url']&&$old['source_checked']===$input['source_checked'])$input['source_checked']=0;
 return autonec_gamma_store_data($id,$input);
}
/** Internal trusted writer, shared by the authenticated editor and background importer. */
function autonec_gamma_store_data($id,$input){
 if(get_post_type($id)!=='modelli')return new WP_Error('model_type',__('Il contenuto non è un modello.','autonec-child-theme'));
 $data=autonec_gamma_sanitize_data($input);if(is_wp_error($data))return $data;
 $old=autonec_gamma_data($id);
 if($data['status']==='archived'&&!metadata_exists('post',$id,'_an_gamma_robots_before')){update_post_meta($id,'_an_gamma_robots_before',get_post_meta($id,'_tw_seo_robots',true));update_post_meta($id,'_tw_seo_robots','noindex, follow');}
 elseif($data['status']!=='archived'&&metadata_exists('post',$id,'_an_gamma_robots_before')){if(get_post_meta($id,'_tw_seo_robots',true)==='noindex, follow'){ $before=get_post_meta($id,'_an_gamma_robots_before',true);if($before)update_post_meta($id,'_tw_seo_robots',$before);else delete_post_meta($id,'_tw_seo_robots');}delete_post_meta($id,'_an_gamma_robots_before');}
 update_post_meta($id,'_an_model_data',wp_slash($data));foreach(array('brand_slug'=>'brand','category'=>'category','status'=>'status') as $key=>$index)update_post_meta($id,'_an_model_'.$index,$data[$key]);
 update_post_meta($id,'_an_model_source_url',$data['source_url']);
 $term=get_term_by('slug',$data['brand_slug'],'an_marca');if($term)wp_set_object_terms($id,array((int)$term->term_id),'an_marca',false);
 return true;
}
function autonec_gamma_query($args=array()){$args=wp_parse_args($args,array('posts_per_page'=>-1,'orderby'=>array('menu_order'=>'ASC','title'=>'ASC')));$include_archived=!empty($args['include_archived']);unset($args['include_archived']);if(!$include_archived){$args['meta_query']=array('relation'=>'AND',array('key'=>'_an_model_status','value'=>array('current','coming_soon'),'compare'=>'IN'),array('key'=>'_an_model_brand','value'=>autonec_catalogue_main_brand_slugs()?:array('__none__'),'compare'=>'IN'),$args['meta_query']??array());}$args['post_type']='modelli';$args['post_status']='publish';return new WP_Query($args);}
function autonec_gamma_page_url($brand=''){
 static $urls=array();
 $language=determine_locale().'|'.(string)apply_filters('wpml_current_language',null).'|'.home_url('/');
 if(!array_key_exists($language,$urls)){
  $ids=get_posts(array('post_type'=>'page','post_status'=>'publish','fields'=>'ids','posts_per_page'=>1,'meta_key'=>'_wp_page_template','meta_value'=>'template-range.php','suppress_filters'=>false));
  $urls[$language]=$ids?ticinoweb_frontend_url(get_permalink($ids[0]),'page:gamma'):'';
 }
 $url=$urls[$language];
 return $url&&$brand?add_query_arg('marca',sanitize_title($brand),$url):$url;
}
function autonec_gamma_stock($model_id){
 $data=autonec_gamma_data($model_id);$args=array('posts_per_page'=>6,'no_found_rows'=>false);
 if(!$data['brand_slug']||!$data['stock_models']||$data['status']==='coming_soon')$args['post__in']=array(0);
 else{$args['tax_query']=array(array('taxonomy'=>'an_marca','field'=>'slug','terms'=>$data['brand_slug']));$args['meta_query']=array(array('key'=>'_an_model','value'=>$data['stock_models'],'compare'=>'IN'));}
 return autonec_catalogue_query($args);
}
function autonec_gamma_brand_pages(){return autonec_brand_pages();}
add_action('init',static function(){if(post_type_exists('modelli'))register_taxonomy_for_object_type('an_marca','modelli');},30);

// Reuse the parent's one schema slot, without inventing a price or physical availability.
add_filter('ticinoweb_seo_jsonld_article_schema',static function($schema,$post){
 if($post->post_type!=='modelli')return $schema;$r=autonec_gamma_data($post->ID);$term=get_term_by('slug',$r['brand_slug'],'an_marca');
 $model=array('@context'=>'https://schema.org','@type'=>'Vehicle','@id'=>get_permalink($post).'#model','url'=>get_permalink($post),'name'=>get_the_title($post),'model'=>get_the_title($post));if($term)$model['brand']=array('@type'=>'Brand','name'=>$term->name);
 $image=get_the_post_thumbnail_url($post,'full');if($image)$model['image']=$image;if($post->post_excerpt&&autonec_gamma_copy_is_current($post->ID))$model['description']=wp_strip_all_tags(get_the_excerpt($post));return $model;
},20,2);

/** Do not continue publishing technical prose after its official facts changed, until reviewed. */
function autonec_gamma_copy_is_current($id){return !get_post_meta($id,'_an_gamma_review_fields',true);}
add_filter('get_the_excerpt',static function($excerpt,$post){return $post&&$post->post_type==='modelli'&&!autonec_gamma_copy_is_current($post->ID)?'':$excerpt;},30,2);

add_filter('wp_sitemaps_posts_query_args',static function($args,$type){if($type==='modelli'){$args['meta_query']=array('relation'=>'AND',$args['meta_query']??array(),array('relation'=>'OR',array('key'=>'_an_model_status','value'=>'archived','compare'=>'!='),array('key'=>'_an_model_status','compare'=>'NOT EXISTS')));}return $args;},20,2);
