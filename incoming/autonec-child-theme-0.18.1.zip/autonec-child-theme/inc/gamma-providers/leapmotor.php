<?php
/** Public Swiss Leapmotor model hub. No model inventory or editorial content is stored in PHP. */
if (!defined('ABSPATH')) { exit; }

function autonec_gamma_leap_text($value) {
    return trim(preg_replace('/\s+/u', ' ', html_entity_decode(strip_tags((string) $value), ENT_QUOTES | ENT_HTML5, 'UTF-8')));
}

function autonec_gamma_leap_url($url) {
    $p = wp_parse_url((string) $url);
    return is_array($p) && ($p['scheme'] ?? '') === 'https' && strtolower($p['host'] ?? '') === 'www.leapmotor.net'
        && !isset($p['user']) && !isset($p['pass']) && !isset($p['port'])
        && preg_match('~^/ch-it(?:/|$)~', $p['path'] ?? '') && !isset($p['query']) && !isset($p['fragment']);
}

/** Read the devalue reference table shipped by the actual Swiss frontend, not a fixed set of IDs. */
function autonec_gamma_leap_registry($html) {
    if (!is_string($html) || !preg_match('~<script\b[^>]*\bid=["\']__NUXT_DATA__["\'][^>]*>(.*?)</script>~s', $html, $m)) {
        return new WP_Error('gamma_leap_registry', __('Il sito Leapmotor non espone una gamma leggibile.', 'autonec-child-theme'));
    }
    $flat = json_decode($m[1], true, 256);
    if (!is_array($flat)) { return new WP_Error('gamma_leap_registry', __('Configurazione Leapmotor non valida.', 'autonec-child-theme')); }
    $templates = array();
    foreach ($flat as $item) {
        if (!is_array($item) || !array_key_exists('templateName', $item)) { continue; }
        $row = array();
        foreach ($item as $key => $ref) { $row[$key] = is_int($ref) && $ref >= 0 ? ($flat[$ref] ?? null) : $ref; }
        if (($row['status'] ?? 0) != 1 || empty($row['route']) || !is_numeric($row['id'] ?? null)) { continue; }
        $route = trim((string) $row['route'], '/');
        if (!preg_match('/^[a-zA-Z0-9_-]+$/D', $route)) { continue; }
        $templates[$route] = array('id' => (int) $row['id'], 'name' => (string) $row['templateName'], 'route' => $route);
    }
    return $templates ? $templates : new WP_Error('gamma_leap_registry', __('Registro modelli Leapmotor vuoto.', 'autonec-child-theme'));
}

function autonec_gamma_leap_config($id) {
    $body = autonec_gamma_fetch('https://website-adminapi.leapmotor-international.com/api/web/qryTemplateDetailByWeb?id=' . (int) $id);
    if (is_wp_error($body)) { return $body; }
    $data = json_decode($body, true, 256);
    if (!is_array($data) || ($data['code'] ?? 0) != 200 || empty($data['data']['extra'])) {
        return new WP_Error('gamma_leap_config', __('Risposta della pagina Leapmotor non valida.', 'autonec-child-theme'));
    }
    $config = is_array($data['data']['extra']) ? $data['data']['extra'] : json_decode($data['data']['extra'], true, 256);
    if (empty($config['config']) || !is_array($config['config'])) {
        return new WP_Error('gamma_leap_empty', __('La pagina Leapmotor è vuota o incompleta.', 'autonec-child-theme'));
    }
    return $config['config'];
}

function autonec_gamma_leap_name($name) {
    return trim(preg_replace('/^(?:(?:NEW|NUOV[AOE]|LEAPMOTOR)\s+)+/iu', '', autonec_gamma_leap_text($name)));
}

function autonec_gamma_leap_key($route, $name) {
    // The Swiss frontend uses a technology URL for this name; keep the established editorial identity.
    return sanitize_title(preg_match('/^(?:reev|hybrid)$/i', $route) ? $name : strtolower($route));
}

function autonec_gamma_leap_status($text, $fallback = 'current') {
    // Metadata can lag behind the visible page. "New" alone never means coming soon.
    if (preg_match('/(?:CHF|richiesta di prova|prenota(?:re)? (?:un |una )?(?:test|prova))/iu', $text)) { return 'current'; }
    return preg_match('/(?:in arrivo|presto (?:disponibile|ordinabile)|coming soon|disponibil[ei] dal|tienimi informato)/iu', $text) ? 'coming_soon' : $fallback;
}

function autonec_gamma_leap_category($text, $fallback = '') {
    if (preg_match('/\b(?:cargo|commercial[ei]|furgon\w*)\b/iu', $text)) { return 'commercial'; }
    if (preg_match('/\b(?:SUV|crossover)\b/iu', $text)) { return 'suv'; }
    if (preg_match('/\b(?:city car|segmento A)\b/iu', $text)) { return 'city'; }
    if (preg_match('/\b(?:compatta|coupé|hatchback|berlina)\b/iu', $text)) { return 'compact'; }
    return $fallback;
}

/** Candidates are suggestions: the worker validates bytes/dimensions and preserves manual Media overrides. */
function autonec_gamma_leap_images($blocks) {
    $found = array();
    $visit = static function ($node, $context = '') use (&$visit, &$found) {
        if (!is_array($node) || (isset($node['visible']) && !$node['visible'])) { return; }
        $context .= ' ' . autonec_gamma_leap_text(($node['title'] ?? '') . ' ' . ($node['subTitle'] ?? ''));
        if (preg_match('/(?:altri propulsori|altre motorizzazioni|modelli leapmotor|panoramica modelli|personalizza|interni|cockpit|abitacolo|tecnologi|motore|ricarica|sicurezza|leapmotor app)/iu', $context)) { return; }
        foreach ($node as $key => $value) {
            if (is_array($value)) { $visit($value, $context); continue; }
            if (!is_string($value) || !in_array($key, array('poster', 'src', 'image', 'imageUrl', 'url'), true)) { continue; }
            $value = str_replace('https://leapmotor-website-prod.s3.eu-central-1.amazonaws.com', 'https://lpwebsite-prod-s3cdn.leapmotor-international.com', $value);
            $host = strtolower((string) wp_parse_url($value, PHP_URL_HOST));
            if (!in_array($host, array('lpwebsite-prod-s3cdn.leapmotor-international.com', 'www.leapmotor.net'), true) || !preg_match('~^https://.+\.(?:jpe?g|png|webp)(?:\?.*)?$~i', $value)) { continue; }
            if (preg_match('/(?:logo|intern|interior|engine|battery|wltp|NCAP|EE[-_]|[-_]EE[-_]|range_1920|hbmob|mobile)/i', basename((string) wp_parse_url($value, PHP_URL_PATH)))) { continue; }
            $width = 0; $height = 0;
            if (preg_match('/(?:_|-)(\d{3,5})x(\d{3,5})(?:_|\.|-)/i', $value, $size)) { $width = (int) $size[1]; $height = (int) $size[2]; }
            if ($width && ($width < 1000 || $height > $width)) { continue; }
            $found[$value] = array('url' => $value, 'width' => $width, 'height' => $height, 'role' => 'exterior', 'focal' => array(0.5, 0.5));
        }
    };
    foreach ($blocks as $block) { $visit($block); }
    return array_slice(array_values($found), 0, 24);
}

/** Read only assets from a canonical official presentation of the same family; Swiss facts never come from here. */
function autonec_gamma_leap_asset_fallback($name) {
    if (!preg_match('/^([a-z]\d+[a-z]*)\b/i', $name, $family)) { return array(); }
    $family = strtolower($family[1]);
    $url = 'https://www.leapmotor.net/it-it/modelli/' . $family;
    $html = autonec_gamma_fetch($url);
    if (is_wp_error($html) || !is_string($html)) { return array(); }
    $old = libxml_use_internal_errors(true); $dom = new DOMDocument();
    $ok = $dom->loadHTML('<?xml encoding="UTF-8">' . $html, LIBXML_NONET | LIBXML_NOERROR | LIBXML_NOWARNING);
    libxml_clear_errors(); libxml_use_internal_errors($old);
    if (!$ok) { return array(); }
    $xp = new DOMXPath($dom); $canonical = $xp->query('//link[@rel="canonical"]')->item(0); $heading = $xp->query('//h1')->item(0);
    if (!$canonical || rtrim($canonical->getAttribute('href'), '/') !== $url || !$heading || !preg_match('/\b' . preg_quote($family, '/') . '\b/i', $heading->textContent)) { return array(); }
    $found = array();
    foreach ($xp->query('//main//img[@data-original-src]') as $img) {
        $image = html_entity_decode($img->getAttribute('data-original-src'), ENT_QUOTES | ENT_HTML5, 'UTF-8');
        $path = (string) wp_parse_url($image, PHP_URL_PATH);
        if (strtolower((string) wp_parse_url($image, PHP_URL_HOST)) !== 'www.leapmotor.net' || strpos($image, 'https://') !== 0 || !preg_match('~\.(?:jpe?g|png|webp)$~i', $path)) { continue; }
        if (!preg_match('~/(?:' . preg_quote($family, '~') . '(?:-[a-z-]+)?/|[^/]*' . preg_quote($family, '~') . '[_-])~i', $path)) { continue; }
        $label = autonec_gamma_leap_text($img->getAttribute('alt')) . ' ' . basename($path);
        if (preg_match('/logo|icon|1080x1350|detail|engine|battery|wltp|rating|ncap|air-vent|nfc|speaker|sunroof|frunk|trunk|wheel|luce|eurncap|\.tmb-|zero-emission|safety|assisted|hidden-door|storage|main-screen/i', $label)) { continue; }
        if (!preg_match('/exterior|interior|intern|cockpit|leapmotor|showroom|lifestyle|hero|hires|side|front|rear|lm_|dsc|msa|msb|rgb|forest|left|right/i', $label)) { continue; }
        $role = preg_match('/interior|intern|cockpit|dashboard/i', $label) ? 'interior' : 'exterior';
        $found[$image] = array('url' => $image, 'width' => 0, 'height' => 0, 'role' => $role, 'focal' => array(0.5, 0.5));
    }
    return array_slice(array_values($found), 0, 32);
}

function autonec_gamma_provider_leapmotor($source_url, $model = null) {
    if (!is_string($source_url) || ($model !== null && (!is_array($model) || !isset($model['source_url']) || !is_string($model['source_url'])))) { return new WP_Error('gamma_provider_input', __('Fonte modello non valida.', 'autonec-child-theme')); }
    $page_url = $model === null ? $source_url : ($model['source_url'] ?? '');
    if (!autonec_gamma_leap_url($page_url)) { return new WP_Error('gamma_leap_url', __('Usare una fonte ufficiale Leapmotor della Svizzera italiana.', 'autonec-child-theme')); }
    $html = autonec_gamma_fetch($page_url);
    if (is_wp_error($html)) { return $html; }
    $registry = autonec_gamma_leap_registry($html);
    if (is_wp_error($registry)) { return $registry; }
    $route = trim(substr((string) wp_parse_url($page_url, PHP_URL_PATH), strlen('/ch-it')), '/');
    if ($model !== null) {
        $template = $registry[$route] ?? null;
        if (!$template) { return new WP_Error('gamma_leap_missing', __('Il modello non è più identificabile nella fonte Leapmotor.', 'autonec-child-theme')); }
        $blocks = autonec_gamma_leap_config($template['id']);
        if (is_wp_error($blocks)) { return $blocks; }
        $text = ''; $excerpt = ''; $own_blocks = array();
        foreach ($blocks as $block) {
            if (isset($block['visible']) && !$block['visible']) { continue; }
            $linked = $block['buttonLink'] ?? '';
            if (autonec_gamma_leap_url($linked) && rtrim($linked, '/') !== rtrim($page_url, '/')) { continue; }
            $own_blocks[] = $block;
            $title = autonec_gamma_leap_text(($block['title'] ?? '') . ' ' . ($block['subTitle'] ?? ''));
            if (preg_match('/(?:altri propulsori|altre motorizzazioni|modelli leapmotor|panoramica modelli)/iu', $title)) { continue; }
            $description = autonec_gamma_leap_text($block['description'] ?? '');
            $text .= ' ' . $title . ' ' . $description;
            if (!$excerpt && strlen($description) > 70 && !preg_match('/(?:CHF|leasing|prezzo|offert|acconto|rata|assicurazion)/iu', $description)) { $excerpt = $description; }
        }
        if (strlen(trim($text)) < 20) { return new WP_Error('gamma_leap_detail', __('Dettagli Leapmotor incompleti.', 'autonec-child-theme')); }
        $name = autonec_gamma_leap_name($model['name'] ?? $template['name']);
        $model['name'] = $name;
        $model['category'] = autonec_gamma_leap_category($name . ' ' . $text, $model['category'] ?? '');
        $model['status'] = autonec_gamma_leap_status($text, $model['status'] ?? 'current');
        if (preg_match('/hybrid|REEV/iu', $name)) { $model['powertrains'] = array('Ibrido plug-in con range extender'); }
        elseif (preg_match('/BEV|elettric/iu', $name . ' ' . $text)) { $model['powertrains'] = array('Elettrico'); }
        $model['image_candidates'] = array_slice(array_merge(autonec_gamma_leap_asset_fallback($name), autonec_gamma_leap_images($own_blocks)), 0, 32);
        if ($excerpt) { $model['excerpt'] = mb_substr($excerpt, 0, 240); }
        return $model;
    }
    $hubs = array_filter($registry, static function ($item) { return preg_match('/panoramica.*modell|model.*(?:overview|range)|gamma.*modell/iu', $item['name'] . ' ' . $item['route']); });
    if (isset($registry[$route]) && isset($hubs[$route])) { $hub = $hubs[$route]; }
    elseif (count($hubs) === 1) { $hub = reset($hubs); }
    else { return new WP_Error('gamma_leap_hub', __('Panoramica ufficiale Leapmotor non identificabile senza ambiguità.', 'autonec-child-theme')); }
    $blocks = autonec_gamma_leap_config($hub['id']);
    if (is_wp_error($blocks)) { return $blocks; }
    $models = array();
    foreach ($blocks as $block) {
        if (isset($block['visible']) && !$block['visible']) { continue; }
        foreach (($block['columns'] ?? array()) as $card) {
            if (isset($card['visible']) && !$card['visible']) { continue; }
            $link = $card['buttonLink'] ?? ($card['imageLink'] ?? '');
            if (!$link) { continue; }
            if (!autonec_gamma_leap_url($link)) { return new WP_Error('gamma_leap_card', __('La panoramica contiene un collegamento modello non supportato.', 'autonec-child-theme')); }
            $name = autonec_gamma_leap_name($card['title'] ?? '');
            if (!$name) { return new WP_Error('gamma_leap_card', __('Scheda modello Leapmotor senza nome.', 'autonec-child-theme')); }
            $target = trim(substr((string) wp_parse_url($link, PHP_URL_PATH), strlen('/ch-it')), '/');
            // C10 BEV currently links a family page. Resolve the exact registry name dynamically.
            foreach ($registry as $candidate) {
                if (strcasecmp(autonec_gamma_leap_name($candidate['name']), $name) === 0) { $target = $candidate['route']; break; }
            }
            if (!$target || $target === $hub['route']) { return new WP_Error('gamma_leap_card', __('Percorso modello Leapmotor incompleto.', 'autonec-child-theme')); }
            $key = autonec_gamma_leap_key($target, $name);
            if (isset($models[$key])) { return new WP_Error('gamma_leap_duplicate', __('Identità modello Leapmotor duplicata.', 'autonec-child-theme')); }
            $card_text = $name . ' ' . autonec_gamma_leap_text($card['description'] ?? '');
            $models[$key] = array('key' => $key, 'name' => $name, 'source_url' => 'https://www.leapmotor.net/ch-it/' . $target, 'category' => autonec_gamma_leap_category($card_text), 'powertrains' => array(), 'status' => autonec_gamma_leap_status($card_text), 'image_candidates' => autonec_gamma_leap_images(array($card)));
        }
    }
    if (!$models || count($models) > 60) { return new WP_Error('gamma_leap_empty', __('La panoramica Leapmotor è vuota o non riconoscibile.', 'autonec-child-theme')); }
    return array('models' => array_values($models), 'complete' => true, 'evidence' => array($page_url, 'https://www.leapmotor.net/ch-it/' . $hub['route']));
}
