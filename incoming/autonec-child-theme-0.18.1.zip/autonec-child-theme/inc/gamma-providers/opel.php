<?php
/** Opel Switzerland: live editorial-carousel discovery, not stock or a frozen model list. */
defined('ABSPATH') || exit;
function autonec_gamma_opel_dom($html){
 if(!is_string($html)||!trim($html)||!class_exists('DOMDocument'))return new WP_Error('opel_html',__('La pagina ufficiale Opel non è leggibile.','autonec-child-theme'));
 $doc=new DOMDocument();$old=libxml_use_internal_errors(true);$ok=$doc->loadHTML('<?xml encoding="utf-8" ?>'.$html,LIBXML_NONET|LIBXML_NOERROR|LIBXML_NOWARNING);libxml_clear_errors();libxml_use_internal_errors($old);
 return $ok?new DOMXPath($doc):new WP_Error('opel_html',__('HTML Opel non valido.','autonec-child-theme'));
}
function autonec_gamma_opel_url($url){
 $url=html_entity_decode(trim((string)$url),ENT_QUOTES|ENT_HTML5,'UTF-8');if(str_starts_with($url,'/'))$url='https://www.opel.ch'.$url;
 $p=parse_url($url);if(!$p||($p['scheme']??'')!=='https'||!in_array(strtolower($p['host']??''),array('www.opel.ch','opel.ch'),true)||isset($p['user'])||isset($p['pass'])||isset($p['port'])||!str_starts_with($p['path']??'','/it/'))return '';
 // These two exact obsolete Swiss menu paths return404. Their official replacements were verified.
 $aliases=array('/it/vans/combo-models/cargo/model-overview.html'=>'/it/veicoli-commerciali/modelli-combo/cargo/panoramica.html','/it/vans/combo-models/combo-e-cargo/overview.html'=>'/it/veicoli-commerciali/modelli-combo/combo-e-cargo/panoramica.html');
 if(isset($aliases[$p['path']]))$url='https://www.opel.ch'.$aliases[$p['path']];return $url;
}
function autonec_gamma_opel_parse_discovery($html,$source_url){
 if(!is_string($html)||!preg_match('~</html>\s*$~i',$html))return new WP_Error('opel_truncated',__('Risposta Opel incompleta.','autonec-child-theme'));$xp=autonec_gamma_opel_dom($html);if(is_wp_error($xp))return $xp;$models=array();$seen=0;
 $sliders=$xp->query('//div[contains(concat(" ",normalize-space(@class)," ")," q-slider ")][.//div[contains(concat(" ",normalize-space(@class)," ")," q-slider-item ")]][.//a[starts-with(@href,"/it/veicoli/")]]');if(!$sliders->length)return new WP_Error('opel_carousel',__('Carosello gamma Opel assente.','autonec-child-theme'));foreach($xp->query('./div[contains(concat(" ",normalize-space(@class)," ")," q-slider-item ")]',$sliders->item(0)) as $card){
  $labels=$xp->query('.//*[contains(concat(" ",normalize-space(@class)," ")," q-headline ")]',$card);$links=$xp->query('.//a[@href]',$card);$url='';
  foreach($links as $a){$href=$a->getAttribute('href');if(preg_match('~^/(?:it/veicoli/|it/veicoli-commerciali/|it/vans/)~',$href)&&preg_match('~/(?:panoramica|model-overview|overview)\.html$~',$href)){$url=autonec_gamma_opel_url($href);break;}}
  if(!$url||!$labels->length)return new WP_Error('opel_incomplete',__('Una voce del carosello Opel non è interpretabile: lettura parziale.','autonec-child-theme'));$name=trim(preg_replace('/\s+/u',' ',$labels->item(0)->textContent));if(!$name) return new WP_Error('opel_label',__('Una scheda della gamma Opel è senza nome.','autonec-child-theme'));
  ++$seen;$key=sanitize_title(preg_replace('/^(?:Nuova?|Opel)\s+/iu','',$name));if(!$key||isset($models[$key]))return new WP_Error('opel_duplicate',__('Identità Opel ambigua nella gamma ufficiale.','autonec-child-theme'));
  $category=preg_match('/\bGSE$/i',$name)?'sport':(str_contains($url,'/veicoli-commerciali/')?'commercial':(preg_match('/Sports Tourer/i',$name)?'estate':''));
  $models[$key]=array('key'=>$key,'name'=>$name,'source_url'=>$url,'category'=>$category,'powertrains'=>preg_match('/\bElectric$/i',$name)?array('Elettrica'):array(),'status'=>'current','image_candidates'=>array());
 }
 if($seen<2||!str_contains(wp_strip_all_tags($html),'Scopri la gamma Opel'))return new WP_Error('opel_discovery',__('La gamma Opel completa non è riconoscibile: conservare l’ultima lettura valida.','autonec-child-theme'));
 return array('models'=>array_values($models),'complete'=>true,'evidence'=>array($source_url),'discovery'=>'Official Swiss model carousel; each published model label is retained even when URLs coincide.');
}
function autonec_gamma_opel_parse_detail($html,$model){
 $xp=autonec_gamma_opel_dom($html);if(is_wp_error($xp))return $xp;
 if(empty($model['name'])||empty($model['key'])||!autonec_gamma_opel_url($model['source_url']??''))return new WP_Error('opel_model',__('Scheda Opel senza identità ufficiale.','autonec-child-theme'));
 $texts=array();foreach($xp->query('//title|//h1|//h2|//h3|//p|//li') as $node){if($xp->query('ancestor::nav|ancestor::header|ancestor::footer|ancestor::script',$node)->length)continue;$value=trim(preg_replace('/\s+/u',' ',$node->textContent));if($value)$texts[]=$value;}
 $text=implode(' ',$texts);if(strlen($text)<80||preg_match('/404|page not found|pagina non trovata/i',substr($text,0,250)))return new WP_Error('opel_detail',__('La scheda Opel non contiene dati verificabili.','autonec-child-theme'));
 // Extract propulsion facts before warranty/cross-sell copy, and strip fuel-equivalent units.
 $fact=substr($text,0,2200);$fact=preg_split('/8 ans|8 anni|Servizi connessi|Il futuro è elettrico|Hai bisogno di più spazio/iu',$fact)[0];
 $fact=preg_replace('/(?:ibrid[aoe]|hybrid)\s+(?:a\s+)?benzina/iu','ibrida',$fact);$fact=preg_replace('/equivalente\s+benzina/iu','',$fact);
 foreach($xp->query('//*[@data-app-wl="TeaserFullscreen"][@data-props]') as $block){$props=json_decode($block->getAttribute('data-props'),true);if(is_array($props)&&preg_match('/^100\s*%\s*elettric/iu',trim(wp_strip_all_tags($props['headlineText']??''))))$fact.=' '.wp_strip_all_tags($props['headlineText']);}
 $power=array();if(preg_match('/\bElectric$/i',$model['name']))$power=array('Elettrica');else{foreach(array('Benzina'=>'/benzina/iu','Diesel'=>'/diesel/iu','Ibrida'=>'/\b(?:ibrid[aoe]|hybrid)\b(?!\s*plug)/iu','Ibrida plug-in'=>'/(?:plug[ -]?in)/iu','Elettrica'=>'/(?:100\s*%\s*elettric|completamente elettric|fully electric)/iu') as $label=>$pattern)if(preg_match($pattern,$fact))$power[]=$label;}
 if(preg_match('/'.preg_quote($model['name'],'/').'\b.{0,60}\bDiesel/iu',$text)&&!in_array('Diesel',$power,true)&&!preg_match('/Electric$/i',$model['name']))$power[]='Diesel';if($power)$model['powertrains']=$power;
 if(empty($model['category'])){$identity='';foreach($xp->query('//title|//meta[@name="description"]') as $meta)$identity.=' '.($meta->getAttribute('content')?:$meta->textContent);$identity.=' '.substr($text,0,400);foreach(array('estate'=>'/station wagon|sports tourer/iu','mpv'=>'/monovolume|ludospace|furgone passeggeri/iu','suv'=>'/\bSUV\b|crossover/iu','city'=>'/utilitaria|city car/iu','compact'=>'/compatta|berlina/iu') as $cat=>$pattern)if(preg_match($pattern,$identity)){$model['category']=$cat;break;}}
 $decoded=html_entity_decode($html,ENT_QUOTES|ENT_HTML5,'UTF-8');preg_match_all('~/content/dam/opel/[^"\s<>\\\\]+?\.(?:jpg|jpeg|png|webp)~i',$decoded,$matches);foreach($xp->query('//img[@src or @srcset]') as $image){$src=$image->getAttribute('src')?:$image->getAttribute('srcset');$src=preg_replace('/\?.*$/','',$src);if(str_contains($src,'/_jcr_content/')&&!preg_match('/interior|intern[io]|interieur|cockpit|seat|foldable|navigation|caricamento/iu',$image->getAttribute('alt').$src))$matches[0][]=$src;} $candidates=array();
 foreach(array_unique($matches[0]) as $path){
  if(!preg_match('~/vehicles/|/vehicles-[^/]+/|/_jcr_content/~',$path)||preg_match('~header|footer|energy-label|warrant|logo|bottom|sideshot|side-shot|noBG|cockpit|interior|interieur|seat|battery|technology|dimensions|wheel|badge|placeholder|thumb|424x|576x|654x~i',$path))continue;
  $w=0;$h=0;if(preg_match('/(\d{3,4})x(\d{3,4})/i',$path,$dim)){$w=(int)$dim[1];$h=(int)$dim[2];}if($w&&($w<1600||$h<800))continue;
  $candidates[]=array('url'=>'https://www.opel.ch'.$path,'width'=>$w,'height'=>$h,'role'=>'exterior','focal'=>array(.5,.5));
 }
 $model['image_candidates']=array_slice($candidates,0,8);$model['evidence']=array($model['source_url']);return $model;
}
function autonec_gamma_provider_opel($source_url,$model=null){
 $url=autonec_gamma_opel_url($model['source_url']??$source_url);if(!$url)return new WP_Error('opel_source',__('Usare la fonte Opel svizzera italiana.','autonec-child-theme'));
 $body=autonec_gamma_fetch($url);if(is_wp_error($body))return $body;if($model===null)return autonec_gamma_opel_parse_discovery($body,$url);$record=autonec_gamma_opel_parse_detail($body,$model);if(is_wp_error($record))return $record;
 // Some official detail pages describe a whole family while the live range splits Electric.
 // Verify that split against current published labels instead of freezing model names here.
 $extra_budget=2;
 if(!preg_match('/\bElectric$/i',$record['name'])&&in_array('Elettrica',$record['powertrains']??array(),true)){
  $range_url=autonec_gamma_opel_url($source_url);if(!$range_url)return new WP_Error('opel_variant_source',__('Fonte gamma Opel necessaria per distinguere le varianti.','autonec-child-theme'));
  $range_body=autonec_gamma_fetch($range_url);if(is_wp_error($range_body))return $range_body;$range=autonec_gamma_opel_parse_discovery($range_body,$range_url);if(is_wp_error($range))return $range;
  $sibling_key=$record['key'].'-electric';foreach($range['models'] as $sibling){if($sibling['key']!==$sibling_key)continue;$record['powertrains']=array_values(array_diff($record['powertrains'],array('Elettrica')));break;}
  $record['evidence'][]=$range_url;--$extra_budget;
 }
 // Gallery endpoints default to1280px even when their published native asset is2720px.
 // A family/sibling check consumes one of the two optional detail requests.
 $requests=0;foreach($record['image_candidates'] as $i=>$image){if($requests>=$extra_budget)break;if(!str_contains($image['url'],'/_jcr_content/')||!str_contains($image['url'],'.coreimg'))continue;++$requests;$component=explode('.coreimg',$image['url'])[0].'.model.json';$export=autonec_gamma_fetch($component);if(is_wp_error($export))continue;$meta=json_decode($export,true);$path=$meta['componentData']['image']['repo:path']??'';if(!is_string($path)||!preg_match('~^/content/dam/opel/[^?#]+\.(?:jpe?g|png|webp)$~i',$path))continue;$record['image_candidates'][$i]['url']='https://www.opel.ch'.$path;$record['image_candidates'][$i]['width']=max(0,(int)($meta['width']??0));$record['image_candidates'][$i]['height']=max(0,(int)($meta['height']??0));}
 return $record;
}
