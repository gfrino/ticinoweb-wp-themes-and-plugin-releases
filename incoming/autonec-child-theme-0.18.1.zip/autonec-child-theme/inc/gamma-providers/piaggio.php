<?php
/** Public Swiss Piaggio commercial navigation + model pages. No fixed business inventory. */
if (!defined('ABSPATH')) { exit; }

function autonec_gamma_piaggio_text($value) {
    return trim(preg_replace('/\s+/u', ' ', html_entity_decode(strip_tags((string) $value), ENT_QUOTES | ENT_HTML5, 'UTF-8')));
}
function autonec_gamma_piaggio_url($url) {
    $p = wp_parse_url((string) $url);
    return is_array($p) && ($p['scheme'] ?? '') === 'https' && strtolower($p['host'] ?? '') === 'piaggio-commercial.ch'
        && !isset($p['user']) && !isset($p['pass']) && !isset($p['port']) && !isset($p['query']) && !isset($p['fragment'])
        && preg_match('~^/it(?:/|$)~', $p['path'] ?? '');
}
function autonec_gamma_piaggio_absolute($url) {
    $url = html_entity_decode((string) $url, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    return strpos($url, '/') === 0 && strpos($url, '//') !== 0 ? 'https://piaggio-commercial.ch' . $url : $url;
}
function autonec_gamma_piaggio_dom($html) {
    if (!is_string($html) || strlen($html) < 100) { return new WP_Error('gamma_piaggio_html', __('Pagina Piaggio non leggibile.', 'autonec-child-theme')); }
    $previous = libxml_use_internal_errors(true);
    $dom = new DOMDocument();
    $loaded = $dom->loadHTML('<?xml encoding="UTF-8">' . $html, LIBXML_NONET | LIBXML_NOERROR | LIBXML_NOWARNING);
    libxml_clear_errors(); libxml_use_internal_errors($previous);
    return $loaded ? new DOMXPath($dom) : new WP_Error('gamma_piaggio_html', __('Pagina Piaggio non valida.', 'autonec-child-theme'));
}
function autonec_gamma_piaggio_identity($url, $label, $family = '') {
    $slug = trim(basename(rtrim((string) wp_parse_url($url, PHP_URL_PATH), '/')));
    $label = autonec_gamma_piaggio_text(preg_replace('/\b(?:Piaggio|Hybrid|Elektro)\b/iu', '', $label));
    // URL/translation aliases are structural adapters; the model list is always read from the site.
    $body = $slug === 'kipper' ? 'ribaltabile' : (preg_match('/^pick-up(?:-|$)/', $slug) ? 'pick-up' : $slug);
    if (preg_match('/\b(Porter\s+[A-Z]+\d*)\b/i', $label, $m)) { $name = trim($label); }
    elseif ($family) { $name = $family . ' ' . ($body === '4x4' ? '4x4' : ucwords(str_replace('-', ' ', $body))); }
    else { $name = $label; }
    if (preg_match('/^Porter\s+([A-Z]+\d*)\b/i', $name, $m)) {
        $prefix = sanitize_title('Porter ' . $m[1]);
        $key = strtolower($slug) === strtolower($m[1]) ? $prefix : $prefix . '-' . $body;
    } else { $key = sanitize_title($slug); }
    return array('key' => $key, 'name' => $name, 'source_url' => 'https://piaggio-commercial.ch/it/veicoli-commerciali/' . $slug . '/', 'category' => 'commercial', 'powertrains' => array(), 'status' => preg_match('/in arrivo|coming soon|presto disponibile/iu', $label) ? 'coming_soon' : 'current', 'image_candidates' => array());
}

/** Inspect the live menu hierarchy. Archive markers apply to every alias of the same page. */
function autonec_gamma_piaggio_index($html) {
    $xp = autonec_gamma_piaggio_dom($html);
    if (is_wp_error($xp)) { return $xp; }
    $anchors = $xp->query('//*[contains(concat(" ",normalize-space(@class)," ")," menu-desktop ")]//a[@href]');
    if (!$anchors || !$anchors->length) { return new WP_Error('gamma_piaggio_menu', __('La navigazione dei modelli Piaggio non è riconoscibile.', 'autonec-child-theme')); }
    $rows = array(); $archives = array(); $families = array(); $hub = '';
    foreach ($anchors as $a) {
        $url = autonec_gamma_piaggio_absolute($a->getAttribute('href'));
        if (!autonec_gamma_piaggio_url($url)) { continue; }
        $path = rtrim((string) wp_parse_url($url, PHP_URL_PATH), '/');
        if ($path === '/it/veicoli-commerciali') { $hub = $url; continue; }
        if (!preg_match('~^/it/veicoli-commerciali/[^/]+$~D', $path)) { continue; }
        $li = $xp->query('ancestor::li[1]', $a)->item(0);
        if (!$li) { continue; }
        $label = autonec_gamma_piaggio_text($a->textContent); $historical = false; $container = false;
        foreach ($xp->query('.//li//a[@href]', $li) as $child) {
            if (preg_match('/^(?:Storia|History|Historie|Archivio)$/iu', autonec_gamma_piaggio_text($child->textContent))) { $historical = true; }
            $child_url = autonec_gamma_piaggio_absolute($child->getAttribute('href'));
            if (autonec_gamma_piaggio_url($child_url) && strpos((string) wp_parse_url($child_url, PHP_URL_PATH), '/it/veicoli-commerciali/') === 0) { $container = true; }
        }
        $slug = basename($path);
        if ($historical) { $archives[$slug] = true; continue; }
        if ($container) {
            if (preg_match('/\b(Porter\s+[A-Z]+\d+)\b/i', $label, $m)) { $families[$m[1]] = $m[1]; }
            continue;
        }
        $family = '';
        foreach ($xp->query('ancestor::li[position()>1]', $a) as $parent) {
            $parent_a = $xp->query('./div/a[1]|./a[1]', $parent)->item(0);
            if ($parent_a && preg_match('/\b(Porter\s+[A-Z]+\d+)\b/i', autonec_gamma_piaggio_text($parent_a->textContent), $m)) { $family = $m[1]; break; }
        }
        $rows[$slug] = autonec_gamma_piaggio_identity($url, $label, $family);
    }
    if (!$hub || !$rows) { return new WP_Error('gamma_piaggio_menu', __('Indice della gamma Piaggio incompleto.', 'autonec-child-theme')); }
    $nav_keys = array_column($rows, 'key'); sort($nav_keys);
    foreach ($xp->query('//a[contains(concat(" ",normalize-space(@class)," ")," swiper-slide-inner ")][@href]') as $a) {
        $parts = array();
        foreach ($xp->query('.//*[contains(@class,"elementor-slide-heading") or contains(@class,"elementor-slide-description")]', $a) as $text) { $parts[] = autonec_gamma_piaggio_text($text->textContent); }
        $label = implode(' ', $parts);
        $url = autonec_gamma_piaggio_absolute($a->getAttribute('href'));
        if (!autonec_gamma_piaggio_url($url)) { continue; }
        $slug = basename(rtrim((string) wp_parse_url($url, PHP_URL_PATH), '/'));
        if (isset($archives[$slug]) || preg_match('/\b(?:History|Storia|Historie|Archivio)\b/iu', $label)) { continue; }
        if (isset($rows[$slug]) || !preg_match('/\bPiaggio\b/iu', $label)) { continue; }
        // A model promoted only in the homepage slider can be absent from the menu (e.g. a Van body).
        $family = '';
        if (count($families) === 1 && !preg_match('/Porter\s+[A-Z]+\d+/i', $label)) { $family = reset($families); }
        $clean = autonec_gamma_piaggio_text(preg_replace('/\b(?:Piaggio|Porter)\b/iu', '', $label));
        $record = autonec_gamma_piaggio_identity($url, $family ? $clean : $label, $family);
        if (in_array($record['key'], array_column($rows, 'key'), true)) { continue; } // Slider aliases resolve to the canonical menu identity.
        $rows[$slug] = $record;
    }
    foreach ($archives as $slug => $_) { unset($rows[$slug]); }
    return array('models' => $rows, 'hub' => $hub, 'archives' => $archives, 'nav_keys' => $nav_keys);
}

function autonec_gamma_piaggio_candidate($url, $width = 0, $height = 0) {
    $url = autonec_gamma_piaggio_absolute($url);
    if (strtolower((string) wp_parse_url($url, PHP_URL_HOST)) !== 'piaggio-commercial.ch' || strpos($url, 'https://') !== 0
        || !preg_match('~\.(?:jpe?g|png|webp)(?:\?.*)?$~i', $url)
        || preg_match('~(?:logo|favicon|icon|motor\.png|tank|tabelle|technische|interni|interior|radio|warranty|service|range|radstand|[/-]EE[-_]|table-o\d)~i', $url)) { return null; }
    if (!$width && preg_match('/-(\d{3,5})x(\d{3,5})\./', $url, $m)) { $width = (int) $m[1]; $height = (int) $m[2]; }
    if ($width && ($width < 1000 || $height > $width)) { return null; }
    return array('url' => $url, 'width' => (int) $width, 'height' => (int) $height, 'role' => 'exterior', 'focal' => array(0.5, 0.5));
}

function autonec_gamma_piaggio_images($xp, $css = '') {
    $found = array();
    foreach ($xp->query('//main//img[@src] | //*[@id="content"]//img[@src]') as $img) {
        if ($xp->query('ancestor::*[contains(@class,"location-footer") or contains(@class,"location-header")]', $img)->length) { continue; }
        $url = $img->getAttribute('src'); $width = (int) $img->getAttribute('width'); $height = (int) $img->getAttribute('height');
        $ratio = $width ? $height / $width : 0;
        if (preg_match_all('/([^\s,]+)\s+(\d+)w(?:,|$)/', $img->getAttribute('srcset'), $matches, PREG_SET_ORDER)) {
            foreach ($matches as $match) { if ((int) $match[2] >= $width) { $url = $match[1]; $width = (int) $match[2]; } }
            if ($ratio) { $height = (int) round($width * $ratio); }
        }
        $candidate = autonec_gamma_piaggio_candidate($url, $width, $height);
        if ($candidate) { $found[$candidate['url']] = $candidate; }
    }
    if (preg_match_all('~url\(["\']?(https://piaggio-commercial\.ch/[^\s)"\']+)["\']?\)~i', $css, $urls)) {
        foreach ($urls[1] as $url) { $candidate = autonec_gamma_piaggio_candidate($url); if ($candidate) { $found[$candidate['url']] = $candidate; } }
    }
    return array_slice(array_values($found), 0, 24);
}

function autonec_gamma_provider_piaggio($source_url, $model = null) {
    if (!is_string($source_url) || ($model !== null && (!is_array($model) || !isset($model['source_url']) || !is_string($model['source_url'])))) { return new WP_Error('gamma_provider_input', __('Fonte modello non valida.', 'autonec-child-theme')); }
    $page_url = $model === null ? $source_url : ($model['source_url'] ?? '');
    if (!autonec_gamma_piaggio_url($page_url)) { return new WP_Error('gamma_piaggio_url', __('Usare una fonte ufficiale Piaggio Commercial della Svizzera italiana.', 'autonec-child-theme')); }
    $html = autonec_gamma_fetch($page_url);
    if (is_wp_error($html)) { return $html; }
    if ($model === null) {
        $first = autonec_gamma_piaggio_index($html);
        if (is_wp_error($first)) { return $first; }
        $other_url = rtrim((string) wp_parse_url($page_url, PHP_URL_PATH), '/') === '/it' ? $first['hub'] : 'https://piaggio-commercial.ch/it/';
        $other_html = autonec_gamma_fetch($other_url);
        if (is_wp_error($other_html)) { return $other_html; }
        $second = autonec_gamma_piaggio_index($other_html);
        if (is_wp_error($second)) { return $second; }
        if ($first['nav_keys'] !== $second['nav_keys']) { return new WP_Error('gamma_piaggio_incomplete', __('La navigazione della gamma Piaggio è cambiata durante la lettura.', 'autonec-child-theme')); }
        $models = $first['models'];
        foreach ($second['models'] as $slug => $row) {
            if (isset($models[$slug]) && $models[$slug]['key'] !== $row['key']) { return new WP_Error('gamma_piaggio_identity', __('Identità della gamma Piaggio incoerenti.', 'autonec-child-theme')); }
            $models[$slug] = $row;
        }
        foreach (array_merge($first['archives'], $second['archives']) as $slug => $_) { unset($models[$slug]); }
        $keys = array_column($models, 'key');
        if (!$models || count($models) > 60 || count(array_unique($keys)) !== count($keys)) { return new WP_Error('gamma_piaggio_empty', __('La gamma Piaggio è vuota o ambigua.', 'autonec-child-theme')); }
        return array('models' => array_values($models), 'complete' => true, 'evidence' => array($page_url, $other_url));
    }
    $xp = autonec_gamma_piaggio_dom($html);
    if (is_wp_error($xp)) { return $xp; }
    $main = $xp->query('//main | //*[@id="content"]')->item(0);
    if (!$main) { return new WP_Error('gamma_piaggio_detail', __('Contenuto del modello Piaggio non identificabile.', 'autonec-child-theme')); }
    $text = autonec_gamma_piaggio_text($main->textContent);
    if (preg_match('/(?:la Piaggio Ape ci saluta|lascia il palcoscenico|fuori produzione|non (?:è più|più) (?:disponibile|ordinabile)|modello storico)/iu', $text)) {
        return new WP_Error('gamma_piaggio_archive', __('La fonte presenta un modello d’archivio, non una gamma attuale.', 'autonec-child-theme'));
    }
    if (strlen($text) < 120 || !$xp->query('//main//h1|//*[@id="content"]//h1')->length) { return new WP_Error('gamma_piaggio_detail', __('Dettagli del modello Piaggio incompleti.', 'autonec-child-theme')); }
    $model['category'] = 'commercial';
    // "Hybrid" is the importer's bifuel label. It is not an electric-hybrid powertrain.
    if (preg_match('/(?:completamente|100\s*%)\s*elettric|Electric Drive Unit/iu', $text)) { $model['powertrains'] = array('Elettrico'); }
    elseif (preg_match('/benzina.{0,35}(?:metano|CNG)|bifuel/iu', $text)) { $model['powertrains'] = array('Benzina / metano (CNG)'); }
    $model['status'] = preg_match('/in arrivo|presto ordinabile/iu', $text) ? 'coming_soon' : 'current';
    $css = '';
    if (preg_match('/\bpage-id-(\d+)\b/', $html, $id)) {
        foreach ($xp->query('//link[@href]') as $link) {
            $url = html_entity_decode($link->getAttribute('href'), ENT_QUOTES | ENT_HTML5, 'UTF-8');
            if (preg_match('~^https://piaggio-commercial\.ch/wp-content/uploads/elementor/css/post-' . preg_quote($id[1], '~') . '\.css(?:\?[^\s]*)?$~D', $url)) {
                $response = autonec_gamma_fetch($url);
                if (!is_wp_error($response)) { $css = $response; }
                break;
            }
        }
    }
    $model['image_candidates'] = autonec_gamma_piaggio_images($xp, $css);
    // Existing original editorial body remains authoritative; no prices or boilerplate are copied.
    return $model;
}
