<?php
/** Native showroom photography and its existing Media video association.
 * @package AutonecChildTheme */
if ( ! defined( 'ABSPATH' ) ) { exit; }

/** A core image remains editable and usable even with JavaScript disabled. */
function autonec_showroom_film( $html, $block ) {
 if ( ! is_page_template( 'template-autonec-365.php' ) || ! in_array( 'an-365-film', preg_split( '/\s+/', $block['attrs']['className'] ?? '' ), true ) ) { return $html; }
 $processor = new WP_HTML_Tag_Processor( $html );
 if ( $processor->next_tag( 'IMG' ) ) {
  $processor->set_attribute( 'loading', 'eager' );
  $processor->set_attribute( 'fetchpriority', 'high' );
 }
 $html = $processor->get_updated_html();
 $image_id = absint( $block['attrs']['id'] ?? 0 );
 $url = $image_id ? autonec_hero_video_url( $image_id ) : '';
 if ( ! $url ) { return $html; }
 $video_id = autonec_local_video_id( get_post_meta( $image_id, '_autonec_hero_video_id', true ) );
 $metadata = $video_id ? wp_get_attachment_metadata( $video_id ) : array();
 $has_audio = ! empty( $metadata['audio'] );
 $id = wp_unique_id( 'an-365-video-' );
 $video = sprintf( '<video id="%s" class="an-365-film__video" data-src="%s" muted loop playsinline preload="none" aria-hidden="true" tabindex="-1"></video>', esc_attr( $id ), esc_url( $url ) );
 if ( $has_audio ) {
  $tags = new WP_HTML_Tag_Processor( $html );
  if ( $tags->next_tag( 'FIGURE' ) ) { $tags->add_class( 'has-audio' ); }
  $html = $tags->get_updated_html();
  $off = __( 'Attiva audio', 'autonec-child-theme' );
  $on = __( 'Disattiva audio', 'autonec-child-theme' );
  $video .= sprintf( '<button type="button" class="an-365-film__sound" data-sound-toggle data-label-off="%s" data-label-on="%s" aria-controls="%s" aria-pressed="false" hidden><svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M11 5 6 9H3v6h3l5 4V5Z"/><path class="an-sound-off" d="m16 9 5 6m0-6-5 6"/><path class="an-sound-on" d="M15 8a6 6 0 0 1 0 8m3-11a10 10 0 0 1 0 14"/></svg><span>%s</span></button>', esc_attr( $off ), esc_attr( $on ), esc_attr( $id ), esc_html( $off ) );
 }
 return preg_replace( '/<\/figure>\s*$/', $video . '</figure>', $html, 1 );
}
add_filter( 'render_block_core/image', 'autonec_showroom_film', 20, 2 );

/** Existing CMS contact data, inserted into the native location group. */
function autonec_showroom_address( $html, $block ) {
 if ( ! is_page_template( 'template-autonec-365.php' ) || ! in_array( 'an-365-location__copy', preg_split( '/\s+/', $block['attrs']['className'] ?? '' ), true ) ) { return $html; }
 $address = get_option( 'ticinoweb_contact_address_2', '' );
 if ( ! $address ) { return $html; }
 $label = get_option( 'ticinoweb_contact_address_2_label', '' );
 $details = $label ? '<p class="an-365-location__label">' . esc_html( $label ) . '</p>' : '';
 $details .= '<p class="an-365-location__address">' . nl2br( esc_html( $address ) ) . '</p>';
 $details .= sprintf( '<a class="an-link" href="%s" target="_blank" rel="noopener noreferrer">%s</a>', esc_url( 'https://www.google.com/maps/search/?api=1&query=' . rawurlencode( $address ) ), esc_html__( 'Indicazioni stradali', 'autonec-child-theme' ) );
 $contact = autonec_section_url( 'contact' );
 if ( $contact ) { $details .= sprintf( '<a class="an-365-location__contact" href="%s">%s</a>', esc_url( $contact ), esc_html__( 'Contatta il team Autonec', 'autonec-child-theme' ) ); }
 $end = strrpos( $html, '</div>' );
 return false === $end ? $html : substr_replace( $html, $details, $end, 0 );
}
add_filter( 'render_block_core/group', 'autonec_showroom_address', 20, 2 );
