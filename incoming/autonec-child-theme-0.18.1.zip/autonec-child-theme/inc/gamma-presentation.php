<?php
/** Official range presentation. All model content and imagery come from native posts/Media. @package AutonecChildTheme */
if ( ! defined( 'ABSPATH' ) ) { exit; }

/** Assets stay on the range, model and existing marque surfaces. */
function autonec_gamma_assets() {
 $range = is_page_template( 'template-range.php' );
 $detail = is_singular( 'modelli' );
 if ( ! $range && ! $detail && ! is_page_template( 'template-marque.php' ) ) { return; }
 $version = wp_get_theme()->get( 'Version' );
 if ( $detail || $range ) {
  wp_enqueue_style( 'autonec-catalogue', get_stylesheet_directory_uri() . '/assets/css/catalogue.css', array( 'autonec-site' ), $version );
 }
 wp_enqueue_style( 'autonec-gamma', get_stylesheet_directory_uri() . '/assets/css/gamma.css', array( 'autonec-site' ), $version );
 // The exact shared rail remains last, preserving the approved sizes on every surface.
 if ( $range || $detail ) {
  wp_enqueue_style( 'autonec-brand-navigation', get_stylesheet_directory_uri() . '/assets/css/brand-navigation.css', array( 'autonec-gamma' ), $version );
 }
 if ( $range ) { wp_enqueue_script( 'autonec-catalogue', get_stylesheet_directory_uri() . '/assets/js/catalogue.js', array(), $version, true ); }
 if ( $range || is_page_template( 'template-marque.php' ) ) { wp_enqueue_script( 'autonec-gamma', get_stylesheet_directory_uri() . '/assets/js/gamma.js', $range ? array( 'autonec-catalogue', 'autonec-scroll' ) : array('autonec-scroll'), $version . '.' . filemtime( get_stylesheet_directory() . '/assets/js/gamma.js' ), true ); }
}
add_action( 'wp_enqueue_scripts', 'autonec_gamma_assets', 26 );

/** Curated attachment focus applies to model photos without changing brand banner inputs. */
add_filter( 'wp_get_attachment_image_attributes', static function( $attributes, $attachment ) {
 if ( is_admin() || ! ( is_singular( 'modelli' ) || is_page_template( array( 'template-range.php', 'template-marque.php' ) ) ) ) { return $attributes; }
 $focus = get_post_meta( $attachment->ID, '_an_gamma_focus', true );
 if ( ! is_array( $focus ) || ! isset( $focus[0], $focus[1] ) || ! is_numeric( $focus[0] ) || ! is_numeric( $focus[1] ) ) { return $attributes; }
 $x = round( max( 0, min( 1, (float) $focus[0] ) ) * 100, 3 );
 $y = round( max( 0, min( 1, (float) $focus[1] ) ) * 100, 3 );
 $attributes['style'] = rtrim( $attributes['style'] ?? '', '; ' ) . ';object-position:' . $x . '% ' . $y . '%;';
 return $attributes;
}, 20, 2 );

/** Contextual labels use the existing translation adapter, without changing stored facets. */
function autonec_gamma_label( $value, $context ) {
 return ticinoweb_frontend_text( (string) $value, 'theme:gamma:' . $context );
}

/** Category keys stay stable for filters while the public label follows the current language. */
function autonec_gamma_category_label( $category ) {
 $labels = function_exists( 'autonec_gamma_categories' ) ? autonec_gamma_categories() : array();
 return isset( $labels[$category] ) ? $labels[$category] : autonec_gamma_label( $category, 'category:' . sanitize_title( $category ) );
}

/** Read the one existing marque-to-stock mapping. No hardcoded brand list. */
function autonec_gamma_presentation_brands() {
 static $brands = null;
 if ( null !== $brands ) { return $brands; }
 $brands = array();
 foreach ( autonec_brand_pages() as $brand ) {
  $slug = sanitize_title( (string) get_post_meta( $brand['page_id'], '_an_catalogue_brand', true ) );
  if ( ! $slug ) { continue; }
  $brand['slug'] = $slug;
  $brand['name'] = rtrim( $brand['title'], '. ' );
  $brands[$slug] = $brand;
 }
 return $brands;
}

/** Request-cached counts describe the editorial range, never stock availability. */
function autonec_gamma_brand_counts( $posts = null ) {
 static $counts = null;
 if ( null !== $counts ) { return $counts; }
 $counts = array();
 if ( null === $posts ) { $posts = autonec_gamma_query( array( 'posts_per_page'=>-1, 'no_found_rows'=>true ) )->posts; }
 foreach ( $posts as $post ) {
  $data = autonec_gamma_data( $post->ID );
  $slug = (string) $data['brand_slug'];
  if ( ! isset( $counts[$slug] ) ) { $counts[$slug] = array( 'current'=>0, 'coming_soon'=>0 ); }
  ++$counts[$slug][ 'coming_soon' === $data['status'] ? 'coming_soon' : 'current' ];
 }
 return $counts;
}

/** Plain-language range count, with forthcoming models explicitly separated. */
function autonec_gamma_count_label( $count ) {
 $current = (int) ( $count['current'] ?? 0 );
 $future = (int) ( $count['coming_soon'] ?? 0 );
 $label = sprintf( _n( '%s modello nella gamma', '%s modelli nella gamma', $current, 'autonec-child-theme' ), number_format_i18n( $current ) );
 if ( $future ) { $label .= ' · ' . sprintf( __( '%s in arrivo', 'autonec-child-theme' ), number_format_i18n( $future ) ); }
 return $label;
}

/** Four CMS editorial chapters provide immediate, independent entry to each range. */
function autonec_gamma_brand_journey( $counts ) {
 foreach ( autonec_gamma_presentation_brands() as $slug=>$brand ) {
  $copy = preg_split( '/\R/u', trim( (string) $brand['description'] ), 2 );
  ?>
  <section class="an-gamma-story" data-an-gamma-story aria-labelledby="an-gamma-story-<?php echo esc_attr( $slug ); ?>">
   <?php if ( ! empty( $brand['image_id'] ) ) : ?><figure class="an-gamma-story__photo"><?php echo wp_get_attachment_image( $brand['image_id'], 'full', false, array( 'loading'=>'lazy', 'decoding'=>'async', 'sizes'=>'(max-width: 800px) 100vw, 60vw' ) ); ?></figure><?php endif; ?>
   <div class="an-gamma-story__copy">
    <?php if ( ! empty( $brand['logo_id'] ) ) { echo wp_get_attachment_image( $brand['logo_id'], 'medium', false, array( 'alt'=>'', 'aria-hidden'=>'true', 'class'=>'an-gamma-story__logo', 'loading'=>'lazy' ) ); } ?>
    <h2 id="an-gamma-story-<?php echo esc_attr( $slug ); ?>"><?php echo esc_html( $brand['name'] ); ?></h2>
    <?php if ( ! empty( $copy[0] ) ) : ?><p class="an-gamma-story__lead"><?php echo esc_html( $copy[0] ); ?></p><?php endif; ?>
    <?php if ( ! empty( $copy[1] ) ) : ?><div class="an-gamma-story__description"><?php echo wp_kses_post( wpautop( $copy[1] ) ); ?></div><?php endif; ?>
    <p class="an-gamma-story__count"><?php echo esc_html( autonec_gamma_count_label( $counts[$slug] ?? array() ) ); ?></p>
    <a class="an-link" href="<?php echo esc_url( autonec_gamma_page_url( $slug ) ); ?>"><?php esc_html_e( 'Esplora la gamma', 'autonec-child-theme' ); ?></a>
   </div>
  </section>
  <?php
 }
}

/** Only the small public read-only filter vocabulary is accepted. */
function autonec_gamma_filters() {
 $filters = array( 'marca'=>'', 'categoria'=>'' );
 foreach ( $filters as $key=>$unused ) {
  if ( isset( $_GET[$key] ) && is_string( $_GET[$key] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only range filters.
   $filters[$key] = sanitize_title( wp_unslash( $_GET[$key] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
  }
 }
 $filters['pagina'] = isset( $_GET['pagina'] ) && is_scalar( $_GET['pagina'] ) ? max( 1, min( 100000, absint( $_GET['pagina'] ) ) ) : 1; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only pagination.
 return $filters;
}

/** Shared rail with the same four logos and measurements, scoped to the range. */
function autonec_gamma_navigation( $selected = '' ) {
 $brands = autonec_gamma_presentation_brands();
 if ( ! $brands ) { return; }
 ?>
 <nav class="an-marque-nav an-wrap" aria-label="<?php esc_attr_e( 'Gamma per marchio', 'autonec-child-theme' ); ?>">
 <?php foreach ( $brands as $slug=>$brand ) : ?>
  <a href="<?php echo esc_url( autonec_gamma_page_url( $slug ) ); ?>"<?php if ( $selected === $slug ) { echo ' aria-current="page"'; } ?>>
   <?php if ( ! empty( $brand['logo_id'] ) ) { echo wp_get_attachment_image( $brand['logo_id'], 'medium', false, array( 'alt'=>'', 'aria-hidden'=>'true', 'class'=>'an-marque-nav__logo', 'loading'=>'eager', 'fetchpriority'=>'auto' ) ); } ?>
   <span><?php echo esc_html( $brand['name'] ); ?></span>
  </a>
 <?php endforeach; ?>
 </nav>
 <?php
}

/** Cards are model families, never a stock listing, price, or offer. */
function autonec_gamma_card( $post_id, $priority = false, $filter_category = '' ) {
 $data = autonec_gamma_data( $post_id );
 $category = (string) ( $data['category'] ?? '' );
 $excerpt = get_the_excerpt( $post_id );
 ?>
 <article class="an-model-card<?php echo has_post_thumbnail( $post_id ) ? '' : ' an-model-card--text'; ?>" data-an-model-card data-category="<?php echo esc_attr( sanitize_title( $category ) ); ?>"<?php echo $filter_category && $filter_category !== sanitize_title( $category ) ? ' hidden' : ''; ?>>
  <a class="an-model-card__photo" href="<?php echo esc_url( get_permalink( $post_id ) ); ?>" tabindex="-1" aria-hidden="true">
   <?php if ( has_post_thumbnail( $post_id ) ) : ?>
    <?php echo get_the_post_thumbnail( $post_id, 'large', array( 'alt'=>'', 'loading'=>$priority ? 'eager' : 'lazy', 'fetchpriority'=>$priority ? 'high' : 'auto', 'decoding'=>'async', 'sizes'=>'(max-width: 700px) 92vw, (max-width: 1100px) 44vw, 29vw' ) ); ?>
   <?php else : ?><span><?php echo esc_html( get_the_title( $post_id ) ); ?></span><?php endif; ?>
  </a>
  <div class="an-model-card__body">
   <div class="an-model-card__meta">
    <?php if ( $category ) : ?><span><?php echo esc_html( autonec_gamma_category_label( $category ) ); ?></span><?php endif; ?>
    <?php if ( 'coming_soon' === ( $data['status'] ?? '' ) ) : ?><span class="an-model-status"><?php esc_html_e( 'In arrivo', 'autonec-child-theme' ); ?></span><?php endif; ?>
   </div>
   <h3><a href="<?php echo esc_url( get_permalink( $post_id ) ); ?>"><?php echo esc_html( get_the_title( $post_id ) ); ?></a></h3>
   <?php if ( $excerpt ) : ?><p class="an-model-card__excerpt"><?php echo esc_html( wp_strip_all_tags( $excerpt ) ); ?></p><?php endif; ?>
   <?php $powertrains = array_filter( (array) ( $data['powertrains'] ?? array() ), 'is_scalar' ); if ( $powertrains ) : ?>
    <p class="an-model-card__powertrains"><?php echo esc_html( implode( ' / ', array_map( static function( $value ) { return autonec_gamma_label( $value, 'powertrain:' . sanitize_title( $value ) ); }, $powertrains ) ) ); ?></p>
   <?php endif; ?>
   <a class="an-model-card__link" href="<?php echo esc_url( get_permalink( $post_id ) ); ?>" aria-label="<?php echo esc_attr( sprintf( __( 'Scopri %s', 'autonec-child-theme' ), get_the_title( $post_id ) ) ); ?>"><?php esc_html_e( 'Scopri il modello', 'autonec-child-theme' ); ?></a>
  </div>
 </article>
 <?php
}

/** Six-model preview after the approved marque editorial sequence; the full range has its own pages. */
function autonec_gamma_brand_section( $page_id ) {
 $slug = sanitize_title( (string) get_post_meta( $page_id, '_an_catalogue_brand', true ) );
 if ( ! $slug ) { return; }
 $models = autonec_gamma_query( array( 'posts_per_page'=>6, 'no_found_rows'=>true, 'meta_query'=>array( array( 'key'=>'_an_model_brand', 'value'=>$slug ) ) ) );
 if ( ! $models->have_posts() ) { return; }
 update_post_thumbnail_cache( $models );
 $heading = 'an-gamma-brand-' . absint( $page_id );
 ?>
 <section class="an-gamma-brand an-wrap" data-an-gamma-showcase aria-labelledby="<?php echo esc_attr( $heading ); ?>">
  <header class="an-gamma-section-heading">
   <div><h2 id="<?php echo esc_attr( $heading ); ?>"><?php esc_html_e( 'La gamma nuova', 'autonec-child-theme' ); ?></h2><p><?php esc_html_e( 'Una selezione dalla gamma del marchio. Tutti i modelli sono nella gamma completa.', 'autonec-child-theme' ); ?></p></div>
   <a class="an-link" href="<?php echo esc_url( autonec_gamma_page_url( $slug ) ); ?>"><?php esc_html_e( 'Gamma completa', 'autonec-child-theme' ); ?></a>
  </header>
  <div class="an-gamma-showcase-stage" data-an-gamma-stage>
  <div class="an-gamma-grid an-gamma-rail" data-an-gamma-rail tabindex="0" role="group" aria-label="<?php esc_attr_e( 'Anteprima dei modelli', 'autonec-child-theme' ); ?>"><?php foreach ( $models->posts as $model ) { autonec_gamma_card( $model->ID ); } ?></div>
  <div class="an-gamma-rail-controls" data-an-gamma-rail-controls hidden><button class="an-link" type="button" data-an-gamma-previous><?php esc_html_e( 'Precedenti', 'autonec-child-theme' ); ?></button><progress max="100" value="0" data-an-gamma-progress aria-label="<?php esc_attr_e( 'Avanzamento dei modelli', 'autonec-child-theme' ); ?>"></progress><button class="an-link" type="button" data-an-gamma-next><?php esc_html_e( 'Successivi', 'autonec-child-theme' ); ?></button></div>
  </div>
 </section>
 <?php
}

/** The complete listing uses server facets, so pagination never hides matching models. */
function autonec_gamma_listing_args( $filters ) {
 $meta = array();
 foreach ( array( 'marca'=>'_an_model_brand', 'categoria'=>'_an_model_category' ) as $key=>$index ) {
  if ( ! empty( $filters[$key] ) ) { $meta[] = array( 'key'=>$index, 'value'=>$filters[$key], 'compare'=>'=' ); }
 }
 $args = array( 'posts_per_page'=>9, 'paged'=>max( 1, (int) ( $filters['pagina'] ?? 1 ) ) );
 if ( $meta ) { $args['meta_query'] = $meta; }
 return $args;
}

/** Native GET pagination preserves the selected marque/category and translated native page. */
function autonec_gamma_pagination( $query, $filters ) {
 if ( $query->max_num_pages < 2 ) { return; }
 $args = array_filter( array( 'marca'=>$filters['marca'], 'categoria'=>$filters['categoria'] ), static function( $value ) { return '' !== $value; } );
 $base = add_query_arg( array_merge( $args, array( 'pagina'=>'%#%' ) ), autonec_gamma_page_url() );
 $links = paginate_links( array( 'base'=>str_replace( '%25%23%25', '%#%', $base ), 'format'=>'', 'current'=>$filters['pagina'], 'total'=>(int) $query->max_num_pages, 'prev_text'=>__( 'Precedente', 'autonec-child-theme' ), 'next_text'=>__( 'Successiva', 'autonec-child-theme' ), 'type'=>'list', 'add_args'=>false, 'add_fragment'=>'#an-gamma-results' ) );
 if ( $links ) { echo '<nav class="an-catalogue-pagination" aria-label="' . esc_attr__( 'Pagine della gamma', 'autonec-child-theme' ) . '">' . wp_kses_post( $links ) . '</nav>'; }
}

/** Only the exact matching, available Carmarket stock may appear under a model. */
function autonec_gamma_model_stock( $post_id ) {
 $data = autonec_gamma_data( $post_id );
 $brand = sanitize_title( (string) ( $data['brand_slug'] ?? '' ) );
 $stock_url = autonec_catalogue_page_url();
 if ( $brand && $stock_url ) { $stock_url = add_query_arg( 'marca', $brand, $stock_url ); }
 $stock = autonec_gamma_stock( $post_id );
 if ( $stock->have_posts() ) { update_post_thumbnail_cache( $stock ); }
 ?>
 <section class="an-model-stock" aria-labelledby="an-model-stock-title">
  <header class="an-gamma-section-heading"><div><h2 id="an-model-stock-title"><?php esc_html_e( 'Nuove e occasioni della famiglia', 'autonec-child-theme' ); ?></h2><p><?php esc_html_e( 'Annunci disponibili della stessa famiglia di modelli. Versioni e generazioni possono essere diverse dalla gamma nuova.', 'autonec-child-theme' ); ?></p></div><?php if ( $stock_url ) : ?><a class="an-link" href="<?php echo esc_url( $stock_url ); ?>"><?php esc_html_e( 'Auto del marchio', 'autonec-child-theme' ); ?></a><?php endif; ?></header>
  <?php if ( $stock->have_posts() ) : ?>
   <div class="an-catalogue-grid"><?php foreach ( $stock->posts as $vehicle ) { autonec_catalogue_card( $vehicle->ID ); } ?></div>
  <?php else : ?>
   <p class="an-model-stock__empty"><?php esc_html_e( 'Al momento non ci sono annunci abbinati a questa famiglia nel catalogo. Contattaci per conoscere le possibilità di ordinazione.', 'autonec-child-theme' ); ?></p>
  <?php endif; ?>
 </section>
 <?php
}
