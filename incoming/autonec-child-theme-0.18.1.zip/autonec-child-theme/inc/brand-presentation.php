<?php
/** Native brand pages and shared wayfinding. @package AutonecChildTheme */
if ( ! defined( 'ABSPATH' ) ) { exit; }

/** Only published internal pages configured in the existing CMS Slider. */
function autonec_brand_pages() {
 static $pages = null;
 if ( null !== $pages ) { return $pages; }
 $pages = array();
 foreach ( autonec_home_slides() as $slide ) {
  if ( 1 === $slide['slot'] || ! $slide['button_url'] ) { continue; }
  $id = autonec_home_media_owner( $slide['button_url'] );
  if ( ! $id || isset( $pages[$id] ) ) { continue; }
  $slide['page_id'] = $id;
  $pages[$id] = $slide;
 }
 $pages = array_values( $pages );
 return $pages;
}

/** Keep the current page recognizable without duplicating menu settings. */
function autonec_brand_navigation() {
 $pages = autonec_brand_pages();
 if ( ! $pages ) { return; }
 ?>
 <nav class="an-marque-nav an-wrap" aria-label="<?php esc_attr_e( 'Navigazione marchi', 'autonec-child-theme' ); ?>">
 <?php foreach ( $pages as $brand ) : ?>
  <a href="<?php echo esc_url( $brand['button_url'] ); ?>"<?php if ( $brand['page_id'] === get_queried_object_id() || untrailingslashit( $brand['button_url'] ) === untrailingslashit( get_permalink() ) ) { echo ' aria-current="page"'; } ?>>
   <?php if ( $brand['logo_id'] ) { echo wp_get_attachment_image( $brand['logo_id'], 'medium', false, array( 'alt'=>'', 'aria-hidden'=>'true', 'class'=>'an-marque-nav__logo', 'loading'=>'eager', 'fetchpriority'=>'auto' ) ); } ?>
   <span><?php echo esc_html( rtrim( $brand['title'], '. ' ) ); ?></span>
  </a>
 <?php endforeach; ?>
 </nav>
 <?php
}

/** Prioritize the native photographic cover, keeping the CMS-selected image. */
function autonec_brand_cover_priority( $html, $block ) {
 if ( ! is_page_template( 'template-marque.php' ) || ! in_array( 'an-brand-cover', preg_split( '/\s+/', $block['attrs']['className'] ?? '' ), true ) ) { return $html; }
 $processor = new WP_HTML_Tag_Processor( $html );
 if ( $processor->next_tag( array( 'tag_name'=>'IMG', 'class_name'=>'wp-block-cover__image-background' ) ) ) {
  $processor->set_attribute( 'loading', 'eager' );
  $processor->set_attribute( 'fetchpriority', 'high' );
 }
 return $processor->get_updated_html();
}
add_filter( 'render_block_core/cover', 'autonec_brand_cover_priority', 20, 2 );
