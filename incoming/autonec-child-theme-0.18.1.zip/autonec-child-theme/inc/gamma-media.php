<?php
/** Verified official model photographs, stored only through native WordPress Media APIs. @package AutonecChildTheme */
defined( 'ABSPATH' ) || exit;

/** Canonical source identity retains image/transform arguments and normalizes their order. */
function autonec_gamma_photo_url_key( $url ) {
 $url = html_entity_decode( trim( (string) $url ), ENT_QUOTES | ENT_HTML5, 'UTF-8' );
 $parts = wp_parse_url( $url );
 if ( ! $parts || empty( $parts['host'] ) ) { return hash( 'sha256', $url ); }
 $canonical = strtolower( $parts['scheme'] ?? 'https' ) . '://' . strtolower( $parts['host'] );
 if ( isset( $parts['port'] ) ) { $canonical .= ':' . $parts['port']; }
 $canonical .= $parts['path'] ?? '/';
 if ( ! empty( $parts['query'] ) ) {
  $arguments = explode( '&', $parts['query'] );
  sort( $arguments, SORT_STRING );
  $canonical .= '?' . implode( '&', $arguments );
 }
 return hash( 'sha256', $canonical );
}

/** Validate actual file bytes before decoding; all limits apply to originals, never upscaled copies. */
function autonec_gamma_photo_file_info( $file, $options = array() ) {
 $requested_width = (int) ( $options['min_width'] ?? 1280 );
 $min_width = 1024 === $requested_width ? 1024 : max( 1280, $requested_width );
 $pixel_limit = min( 32000000, max( 16000000, (int) ( $options['max_pixels'] ?? 16000000 ) ) );
 if ( ! is_file( $file ) || ! is_readable( $file ) || filesize( $file ) < 1 || filesize( $file ) > 14 * 1024 * 1024 ) { return new WP_Error( 'gamma_photo_size', __( 'La foto non è leggibile o supera il limite di 14 MB.', 'autonec-child-theme' ) ); }
 $size = @getimagesize( $file );
 $actual = function_exists( 'wp_get_image_mime' ) ? wp_get_image_mime( $file ) : ( $size['mime'] ?? '' );
 if ( ! $size || ! in_array( $actual, array( 'image/jpeg', 'image/png', 'image/webp' ), true ) || ( $size['mime'] ?? '' ) !== $actual ) { return new WP_Error( 'gamma_photo_mime', __( 'La foto deve essere un file JPEG, PNG o WebP valido.', 'autonec-child-theme' ) ); }
 $width = (int) $size[0]; $height = (int) $size[1];
 if ( $width < $min_width || $height < 1 || $width * $height > $pixel_limit ) { return new WP_Error( 'gamma_photo_resolution', sprintf( __( 'La foto originale deve avere almeno %1$s pixel di larghezza e non superare %2$s megapixel.', 'autonec-child-theme' ), number_format_i18n( $min_width ), number_format_i18n( $pixel_limit / 1000000 ) ) ); }
 $ratio = $width / $height;
 if ( $ratio < 1.3 || $ratio > 2.6 ) { return new WP_Error( 'gamma_photo_aspect', __( 'Scegli una fotografia orizzontale con la vettura interamente visibile.', 'autonec-child-theme' ) ); }
 return array( 'width'=>$width, 'height'=>$height, 'mime'=>$actual, 'extension'=>array( 'image/jpeg'=>'jpg', 'image/png'=>'png', 'image/webp'=>'webp' )[$actual] );
}

/** Detect an actual PNG alpha channel/transparency chunk without decoding its full raster twice. */
function autonec_gamma_png_has_alpha( $file ) {
 $handle = fopen( $file, 'rb' );
 if ( ! $handle ) { return false; }
 try {
  $header = fread( $handle, 26 );
  if ( strlen( $header ) < 26 || substr( $header, 0, 8 ) !== "\x89PNG\r\n\x1a\n" ) { return false; }
  $type = ord( $header[25] );
  if ( in_array( $type, array( 4, 6 ), true ) ) { return true; }
  rewind( $handle ); fseek( $handle, 8 );
  while ( ! feof( $handle ) && ftell( $handle ) < 1048576 ) {
   $chunk = fread( $handle, 8 ); if ( strlen( $chunk ) !== 8 ) { break; }
   $length = unpack( 'Nlength', substr( $chunk, 0, 4 ) )['length']; $name = substr( $chunk, 4, 4 );
   if ( 'tRNS' === $name ) { return true; }
   if ( in_array( $name, array( 'IDAT', 'IEND' ), true ) || $length > 1048576 ) { break; }
   fseek( $handle, $length + 4, SEEK_CUR );
  }
  return false;
 } finally { fclose( $handle ); }
}

/** Composite a bounded, already resized transparent PNG on white; the untouched original remains native Media. */
function autonec_gamma_flatten_png( $file ) {
 $size = @getimagesize( $file );
 if ( ! $size || $size[0] > 1920 || $size[0] * $size[1] > 3000000 ) { return new WP_Error( 'gamma_photo_composite', __( 'La foto trasparente deve essere ridotta prima della preparazione.', 'autonec-child-theme' ) ); }
 $source = @imagecreatefrompng( $file );
 if ( ! $source ) { return new WP_Error( 'gamma_photo_composite', __( 'La foto trasparente non può essere preparata.', 'autonec-child-theme' ) ); }
 $canvas = imagecreatetruecolor( $size[0], $size[1] );
 try {
  imagefill( $canvas, 0, 0, imagecolorallocate( $canvas, 255, 255, 255 ) );
  imagealphablending( $canvas, true );
  imagecopy( $canvas, $source, 0, 0, 0, 0, $size[0], $size[1] );
  return imagepng( $canvas, $file, 6 ) ? true : new WP_Error( 'gamma_photo_composite', __( 'La foto trasparente non può essere preparata.', 'autonec-child-theme' ) );
 } finally {
  if ( PHP_VERSION_ID < 80000 ) { imagedestroy( $source ); imagedestroy( $canvas ); }
  unset( $source, $canvas );
 }
}

/** Detect transparency in both downloaded PNGs and legacy cached WebP covers. */
function autonec_gamma_photo_has_alpha( $file ) {
 $header = @file_get_contents( $file, false, null, 0, 32 );
 if ( ! is_string( $header ) ) { return false; }
 if ( substr( $header, 0, 8 ) === "\x89PNG\r\n\x1a\n" ) { return autonec_gamma_png_has_alpha( $file ); }
 if ( strlen( $header ) < 25 || substr( $header, 0, 4 ) !== 'RIFF' || substr( $header, 8, 4 ) !== 'WEBP' ) { return false; }
 $chunk = substr( $header, 12, 4 );
 return ( $chunk === 'VP8X' && ( ord( $header[20] ) & 16 ) !== 0 ) || ( $chunk === 'VP8L' && ( ord( $header[24] ) & 16 ) !== 0 );
}

/** 64-bit difference hash as hexadecimal, avoiding platform-dependent signed integers. */
function autonec_gamma_file_dhash( $file ) {
 if ( ! function_exists( 'imagecreatetruecolor' ) ) { return new WP_Error( 'gamma_photo_decoder', __( 'Il server non può confrontare le fotografie.', 'autonec-child-theme' ) ); }
 $size = @getimagesize( $file );
 if ( ! $size || $size[0] * $size[1] > 16000000 ) { return new WP_Error( 'gamma_photo_decode', __( 'La fotografia non può essere confrontata.', 'autonec-child-theme' ) ); }
 $loaders = array( 'image/jpeg'=>'imagecreatefromjpeg', 'image/png'=>'imagecreatefrompng', 'image/webp'=>'imagecreatefromwebp' );
 $loader = $loaders[$size['mime'] ?? ''] ?? '';
 if ( ! $loader || ! function_exists( $loader ) ) { return new WP_Error( 'gamma_photo_decode', __( 'La fotografia non può essere confrontata.', 'autonec-child-theme' ) ); }
 $memory_limit = ini_get( 'memory_limit' );
 wp_raise_memory_limit( 'image' );
 $source = null; $small = null;
 try {
  $source = @$loader( $file );
  if ( ! $source ) { return new WP_Error( 'gamma_photo_decode', __( 'La fotografia non può essere confrontata.', 'autonec-child-theme' ) ); }
  $small = imagecreatetruecolor( 9, 8 );
  imagefill( $small, 0, 0, imagecolorallocate( $small, 255, 255, 255 ) );
  imagealphablending( $small, true );
  imagecopyresampled( $small, $source, 0, 0, 0, 0, 9, 8, $size[0], $size[1] );
  $hash = ''; $nibble = 0; $bits = 0;
  $luma = static function( $pixel ) { return ( ( $pixel >> 16 ) & 255 ) * 299 + ( ( $pixel >> 8 ) & 255 ) * 587 + ( $pixel & 255 ) * 114; };
  for ( $y = 0; $y < 8; ++$y ) {
   for ( $x = 0; $x < 8; ++$x ) {
    $left = imagecolorat( $small, $x, $y ); $right = imagecolorat( $small, $x + 1, $y );
    $nibble = ( $nibble << 1 ) | ( $luma( $left ) > $luma( $right ) ? 1 : 0 );
    if ( 4 === ++$bits ) { $hash .= dechex( $nibble ); $nibble = 0; $bits = 0; }
   }
  }
  return $hash;
 } finally {
  if ( PHP_VERSION_ID < 80000 ) { if ( $source ) { imagedestroy( $source ); } if ( $small ) { imagedestroy( $small ); } }
  unset( $source, $small );
  if ( ini_get( 'memory_limit' ) !== $memory_limit ) { @ini_set( 'memory_limit', $memory_limit ); }
 }
}

/** Return the Hamming distance between two valid 64-bit hashes. */
function autonec_gamma_dhash_hamming( $left, $right ) {
 if ( ! is_string( $left ) || ! is_string( $right ) || ! preg_match( '/^[a-f0-9]{16}$/iD', $left ) || ! preg_match( '/^[a-f0-9]{16}$/iD', $right ) ) { return 65; }
 $weights = array( 0, 1, 1, 2, 1, 2, 2, 3, 1, 2, 2, 3, 2, 3, 3, 4 ); $distance = 0;
 for ( $i = 0; $i < 16; ++$i ) { $distance += $weights[hexdec( $left[$i] ) ^ hexdec( $right[$i] )]; }
 return $distance;
}

/** Check only other model posts' current covers; unused historical Media do not block curation. */
function autonec_gamma_photo_duplicate( $sha, $dhash, $post_id ) {
 $models = get_posts( array( 'post_type'=>'modelli', 'post_status'=>'any', 'posts_per_page'=>-1, 'post__not_in'=>array( $post_id ), 'meta_key'=>'_thumbnail_id', 'no_found_rows'=>true, 'update_post_meta_cache'=>true, 'update_post_term_cache'=>false, 'suppress_filters'=>true ) );
 foreach ( $models as $model ) {
  $attachment = get_post_thumbnail_id( $model->ID );
  if ( ! $attachment ) { continue; }
  $other_sha = (string) get_post_meta( $attachment, '_an_gamma_photo_sha', true );
  if ( ! $other_sha ) {
   $original = wp_get_original_image_path( $attachment );
   if ( $original && is_file( $original ) ) { $other_sha = hash_file( 'sha256', $original ); if ( $other_sha ) { update_post_meta( $attachment, '_an_gamma_photo_sha', $other_sha ); } }
  }
  if ( $sha && $other_sha && hash_equals( $sha, $other_sha ) ) { return new WP_Error( 'gamma_photo_duplicate', sprintf( __( 'Questa fotografia è già usata per il modello %s. Scegli una foto specifica diversa.', 'autonec-child-theme' ), get_the_title( $model->ID ) ) ); }
  $other_hash = (string) get_post_meta( $attachment, '_an_gamma_dhash', true );
  if ( ! preg_match( '/^[a-f0-9]{16}$/iD', $other_hash ) ) {
   $file = get_attached_file( $attachment );
   $computed = $file && is_file( $file ) ? autonec_gamma_file_dhash( $file ) : false;
   if ( is_string( $computed ) ) { $other_hash = $computed; update_post_meta( $attachment, '_an_gamma_dhash', $computed ); }
  }
  if ( autonec_gamma_dhash_hamming( $dhash, $other_hash ) <= 2 ) { return new WP_Error( 'gamma_photo_duplicate', sprintf( __( 'Una fotografia uguale o quasi identica è già usata per il modello %s.', 'autonec-child-theme' ), get_the_title( $model->ID ) ) ); }
 }
 return false;
}

/** Optional normalized focal coordinates are attachment presentation data, not a parallel CMS. */
function autonec_gamma_photo_focus( $attachment, $options ) {
 if ( ! isset( $options['focal'] ) || ! is_array( $options['focal'] ) || count( $options['focal'] ) !== 2 || ! isset( $options['focal'][0], $options['focal'][1] ) || ! is_numeric( $options['focal'][0] ) || ! is_numeric( $options['focal'][1] ) ) { return; }
 update_post_meta( $attachment, '_an_gamma_focus', array( max( 0, min( 1, (float) $options['focal'][0] ) ), max( 0, min( 1, (float) $options['focal'][1] ) ) ) );
}

/**
 * Import one official source photo. Called only by the authorized model engine/admin workflow.
 * New imports keep the untouched source through native original_image metadata; valid existing Media may be reused. Never changes featured selection.
 *
 * @return int|WP_Error Native attachment ID, or an actionable validation/duplicate error.
 */
function autonec_gamma_import_photo( $url, $post_id, $options = array() ) {
 $post_id = absint( $post_id );
 if ( ! $post_id || 'modelli' !== get_post_type( $post_id ) || ! is_string( $url ) || ! is_array( $options ) ) { return new WP_Error( 'gamma_photo_target', __( 'Scegli un modello valido per importare la fotografia.', 'autonec-child-theme' ) ); }
 require_once ABSPATH . 'wp-admin/includes/file.php';
 require_once ABSPATH . 'wp-admin/includes/image.php';
 require_once ABSPATH . 'wp-admin/includes/media.php';
 $source_parts = wp_parse_url( $url );
 if ( ! $source_parts || 'https' !== strtolower( $source_parts['scheme'] ?? '' ) || empty( $source_parts['host'] ) || isset( $source_parts['user'] ) || isset( $source_parts['pass'] ) ) { return new WP_Error( 'gamma_photo_url', __( 'La foto deve provenire da un collegamento ufficiale HTTPS.', 'autonec-child-theme' ) ); }
 $key = autonec_gamma_photo_url_key( $url );
 $legacy = hash( 'sha256', $url );
 $existing = get_posts( array( 'post_type'=>'attachment', 'post_status'=>'inherit', 'posts_per_page'=>20, 'meta_query'=>array( array( 'key'=>'_an_gamma_image_source', 'value'=>array_values( array_unique( array( $key, $legacy ) ) ), 'compare'=>'IN' ) ), 'no_found_rows'=>true ) );
 foreach ( $existing as $asset ) {
  if ( $asset->post_parent && (int) $asset->post_parent !== $post_id ) { continue; }
  $original = wp_get_original_image_path( $asset->ID ); $file = get_attached_file( $asset->ID );
  if ( ! $original || ! $file || is_wp_error( autonec_gamma_photo_file_info( $original, $options ) ) || is_wp_error( autonec_gamma_photo_file_info( $file, $options ) ) ) { continue; }
  if ( autonec_gamma_photo_has_alpha( $file ) || ( autonec_gamma_photo_has_alpha( $original ) && ! get_post_meta( $asset->ID, '_an_gamma_photo_composited', true ) ) ) { continue; }
  $sha = hash_file( 'sha256', $original ); $dhash = autonec_gamma_file_dhash( $file );
  if ( is_wp_error( $dhash ) ) { return $dhash; }
  $duplicate = autonec_gamma_photo_duplicate( $sha, $dhash, $post_id ); if ( $duplicate ) { return $duplicate; }
  update_post_meta( $asset->ID, '_an_gamma_photo_sha', $sha ); update_post_meta( $asset->ID, '_an_gamma_dhash', $dhash );
  autonec_gamma_photo_focus( $asset->ID, $options );
  return (int) $asset->ID;
 }
 $temporary = wp_tempnam( 'autonec-official-photo' );
 if ( ! $temporary ) { return new WP_Error( 'gamma_photo_temporary', __( 'Non è possibile preparare il file temporaneo della foto.', 'autonec-child-theme' ) ); }
 $created_files = array(); $temporary_files = array(); $attachment = 0; $complete = false; $composited = false; $memory_limit = ini_get( 'memory_limit' );
 try {
  $response = autonec_gamma_remote( $url, array( 'stream'=>true, 'filename'=>$temporary, 'timeout'=>12, 'limit_response_size'=>14 * 1024 * 1024 + 1 ), true );
  if ( is_wp_error( $response ) ) { return $response; }
  if ( 200 !== wp_remote_retrieve_response_code( $response ) ) { return new WP_Error( 'gamma_photo_http', __( 'Il sito ufficiale non ha restituito una fotografia disponibile.', 'autonec-child-theme' ) ); }
  $info = autonec_gamma_photo_file_info( $temporary, $options ); if ( is_wp_error( $info ) ) { return $info; }
  $sha = hash_file( 'sha256', $temporary );
  $slug = sanitize_title( get_the_title( $post_id ) ) ?: 'modello';
  $upload_file = array( 'name'=>$slug . '-source.' . $info['extension'], 'type'=>$info['mime'], 'tmp_name'=>$temporary, 'size'=>filesize( $temporary ), 'error'=>0 );
  $upload = wp_handle_sideload( $upload_file, array( 'test_form'=>false, 'mimes'=>array( 'jpg|jpeg|jpe'=>'image/jpeg', 'png'=>'image/png', 'webp'=>'image/webp' ) ) );
  if ( isset( $upload['error'] ) ) { return new WP_Error( 'gamma_photo_upload', $upload['error'] ); }
  $original = $upload['file']; $created_files[] = $original;
  wp_raise_memory_limit( 'image' );
  $available_memory = function_exists( 'wp_convert_hr_to_bytes' ) ? wp_convert_hr_to_bytes( ini_get( 'memory_limit' ) ) : -1;
  if ( $available_memory > 0 && memory_get_usage( true ) + $info['width'] * $info['height'] * 5 + 16777216 > $available_memory ) { return new WP_Error( 'gamma_photo_memory', __( 'Questa foto originale richiede troppa memoria. Scegli una versione ufficiale più piccola.', 'autonec-child-theme' ) ); }
  $editor = wp_get_image_editor( $original ); if ( is_wp_error( $editor ) ) { return $editor; }
  $quality = $editor->set_quality( 88 ); if ( is_wp_error( $quality ) ) { return $quality; }
  if ( $info['width'] > 1920 ) { $resized = $editor->resize( 1920, null, false ); if ( is_wp_error( $resized ) ) { return $resized; } }
  if ( autonec_gamma_photo_has_alpha( $original ) ) {
   $working_base = wp_tempnam( 'autonec-alpha-photo' );
   if ( ! $working_base ) { return new WP_Error( 'gamma_photo_temporary', __( 'Non è possibile preparare il file temporaneo della foto.', 'autonec-child-theme' ) ); }
   $temporary_files[] = $working_base; $working = $working_base . '.png'; $temporary_files[] = $working;
   $prepared = $editor->save( $working, 'image/png' ); if ( is_wp_error( $prepared ) ) { return $prepared; }
   $temporary_files[] = $prepared['path'];
   $flattened = autonec_gamma_flatten_png( $prepared['path'] ); if ( is_wp_error( $flattened ) ) { return $flattened; }
   $composited = true;
   unset( $editor ); $editor = wp_get_image_editor( $prepared['path'] ); if ( is_wp_error( $editor ) ) { return $editor; }
   $quality = $editor->set_quality( 88 ); if ( is_wp_error( $quality ) ) { return $quality; }
  }
  $target = trailingslashit( dirname( $original ) ) . wp_unique_filename( dirname( $original ), $slug . '.webp' );
  $created_files[] = $target;
  $saved = $editor->save( $target, 'image/webp' ); if ( is_wp_error( $saved ) ) { return $saved; }
  $optimized = $saved['path']; $created_files[] = $optimized;
  $output_info = autonec_gamma_photo_file_info( $optimized, $options );
  if ( is_wp_error( $output_info ) ) { return $output_info; }
  if ( 'image/webp' !== $output_info['mime'] || $output_info['width'] > min( 1920, $info['width'] ) || $output_info['height'] > $info['height'] ) { return new WP_Error( 'gamma_photo_output', __( 'La fotografia elaborata non rispetta formato e dimensioni originali.', 'autonec-child-theme' ) ); }
  $dhash = autonec_gamma_file_dhash( $optimized ); if ( is_wp_error( $dhash ) ) { return $dhash; }
  $duplicate = autonec_gamma_photo_duplicate( $sha, $dhash, $post_id ); if ( $duplicate ) { return $duplicate; }
  // Same byte content previously imported for this post/unassigned may be reused across source URLs.
  $same = get_posts( array( 'post_type'=>'attachment', 'post_status'=>'inherit', 'posts_per_page'=>20, 'meta_key'=>'_an_gamma_photo_sha', 'meta_value'=>$sha, 'no_found_rows'=>true ) );
  foreach ( $same as $asset ) {
   if ( $composited && ! get_post_meta( $asset->ID, '_an_gamma_photo_composited', true ) ) { continue; }
   if ( ( ! $asset->post_parent || (int) $asset->post_parent === $post_id ) && ! is_wp_error( autonec_gamma_photo_file_info( get_attached_file( $asset->ID ) ?: '', $options ) ) && ! autonec_gamma_photo_has_alpha( get_attached_file( $asset->ID ) ) ) { add_post_meta( $asset->ID, '_an_gamma_image_source', $key ); autonec_gamma_photo_focus( $asset->ID, $options ); return (int) $asset->ID; }
  }
  $attachment = wp_insert_attachment( array( 'post_mime_type'=>'image/webp', 'post_title'=>get_the_title( $post_id ), 'post_content'=>sprintf( __( 'Fotografia ufficiale del modello. Origine: %s', 'autonec-child-theme' ), esc_url_raw( $url ) ), 'post_status'=>'inherit', 'post_parent'=>$post_id ), $optimized, $post_id, true );
  if ( is_wp_error( $attachment ) ) { $error = $attachment; $attachment = 0; return $error; }
  $metadata = wp_generate_attachment_metadata( $attachment, $optimized );
  if ( ! is_array( $metadata ) || empty( $metadata['width'] ) ) { return new WP_Error( 'gamma_photo_metadata', __( 'WordPress non ha potuto preparare le dimensioni della foto.', 'autonec-child-theme' ) ); }
  $metadata['original_image'] = wp_basename( $original );
  wp_update_attachment_metadata( $attachment, $metadata );
  update_post_meta( $attachment, '_wp_attachment_image_alt', wp_strip_all_tags( get_the_title( $post_id ) ) );
  update_post_meta( $attachment, '_an_gamma_image_origin', esc_url_raw( $url ) );
  update_post_meta( $attachment, '_an_gamma_image_source', $key );
  update_post_meta( $attachment, '_an_gamma_photo_sha', $sha );
  update_post_meta( $attachment, '_an_gamma_dhash', $dhash );
  if ( $composited ) { update_post_meta( $attachment, '_an_gamma_photo_composited', 1 ); }
  autonec_gamma_photo_focus( $attachment, $options );
  $complete = true;
  return (int) $attachment;
 } catch ( Throwable $exception ) {
  return new WP_Error( 'gamma_photo_processing', __( 'La fotografia non può essere elaborata. Verifica il file ufficiale e riprova.', 'autonec-child-theme' ), array('exception'=>get_class($exception),'detail'=>$exception->getMessage(),'line'=>$exception->getLine()) );
 } finally {
  unset( $editor );
  if ( ini_get( 'memory_limit' ) !== $memory_limit ) { @ini_set( 'memory_limit', $memory_limit ); }
  if ( is_file( $temporary ) ) { wp_delete_file( $temporary ); }
  foreach ( $temporary_files as $file ) { if ( is_file( $file ) ) { wp_delete_file( $file ); } }
  if ( ! $complete ) {
   if ( $attachment ) { wp_delete_attachment( $attachment, true ); }
   foreach ( $created_files as $file ) { if ( is_file( $file ) ) { wp_delete_file( $file ); } }
  }
 }
}
