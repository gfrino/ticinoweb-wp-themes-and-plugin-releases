<?php
/**
 * Presentation adapters for the existing ticinoWEB CMS.
 *
 * No content defaults, parallel options or persistence on frontend requests.
 *
 * @package AutonecChildTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** The CMS organization names the business; a preview may have its own administrative site title. */
function autonec_site_name() {
 $name=trim((string)get_option('tw_seo_org_name',''));
 return $name?ticinoweb_frontend_text($name,'theme:seo:schema_org_name'):get_bloginfo('name');
}

/**
 * Resolve a CMS image URL to a local Media Library image, if possible.
 *
 * @param string $url Existing CMS media URL.
 * @return int
 */
function autonec_home_image_id( $url ) {
	if ( ! is_string( $url ) || '' === $url ) {
		return 0;
	}
	$uploads = wp_upload_dir();
	if ( empty( $uploads['baseurl'] ) || 0 !== strpos( $url, trailingslashit( $uploads['baseurl'] ) ) ) {
		return 0;
	}
	$image_id = attachment_url_to_postid( $url );
	return $image_id && wp_attachment_is_image( $image_id ) ? (int) $image_id : 0;
}

/** Resolve a native CMS page before presentation URLs get translated. */
function autonec_home_media_owner( $url ) {
 if ( ! is_string( $url ) || ! $url ) { return 0; }
 if ( class_exists( 'Twtr_Router' ) && is_callable( array( 'Twtr_Router', 'language_url' ) ) ) { $url = Twtr_Router::language_url( '', $url ); }
 $home = wp_parse_url( get_option( 'home' ) ); $target = wp_parse_url( $url );
 if ( ! $home || ! $target || ( ! empty( $target['host'] ) && strtolower( $target['host'] ) !== strtolower( $home['host'] ?? '' ) ) ) { return 0; }
 $base = trailingslashit( $home['path'] ?? '/' ); $path = $target['path'] ?? '';
 if ( 0 !== strpos( $path, $base ) ) { return 0; }
 $page = get_page_by_path( trim( substr( $path, strlen( $base ) ), '/' ), OBJECT, 'page' );
 return $page && 'publish' === $page->post_status ? (int) $page->ID : 0;
}

/**
 * Read the native slider without generating generic fallback text or buttons.
 *
 * @return array[] Rows with original slot, image, image_id, title, description,
 *                 button_text and button_url.
 */
function autonec_home_slides() {
	$count  = max( 1, min( 5, (int) get_option( 'ticinoweb_slider_count', 3 ) ) );
	$slides = array();
	for ( $slot = 1; $slot <= $count; $slot++ ) {
		$image = (string) get_option( "ticinoweb_slider_image_{$slot}", '' );
		$title = (string) get_option( "ticinoweb_slider_title_{$slot}", '' );
		if ( '' === trim( $image ) && '' === trim( $title ) ) {
			continue;
		}
		$native_link = (string) get_option( "ticinoweb_slider_btn_link_{$slot}", '' );
		$page_id = $slot > 1 ? autonec_home_media_owner( $native_link ) : 0;
		$slides[] = array(
			'logo_id' => $page_id ? get_post_thumbnail_id( $page_id ) : 0,
			'slot'        => $slot,
			'image'       => $image,
			'image_id'    => autonec_home_image_id( $image ),
			'title'       => ticinoweb_frontend_text( $title, "theme:slider:{$slot}:title" ),
			'description' => ticinoweb_frontend_text( (string) get_option( "ticinoweb_slider_desc_{$slot}", '' ), "theme:slider:{$slot}:description" ),
			'button_text' => ticinoweb_frontend_text( (string) get_option( "ticinoweb_slider_btn_text_{$slot}", '' ), "theme:slider:{$slot}:btn_text" ),
			'button_url'  => ticinoweb_frontend_url( (string) get_option( "ticinoweb_slider_btn_link_{$slot}", '' ), "theme:slider:{$slot}:btn_link" ),
		);
	}
	return $slides;
}

/**
 * Read one existing CMS editorial block.
 *
 * @param string $section Native section suffix: chi_siamo or promozioni.
 * @return array
 */
function autonec_home_editorial_block( $section ) {
	$image = (string) get_option( 'ticinoweb_' . $section . '_image', '' );
	return array(
		'title'    => ticinoweb_frontend_text( (string) get_option( 'ticinoweb_' . $section . '_title', '' ), 'theme:' . $section . ':title' ),
		'text'     => ticinoweb_frontend_text( (string) get_option( 'ticinoweb_' . $section . '_text', '' ), 'theme:' . $section . ':text' ),
		'image'    => $image,
		'image_id' => autonec_home_image_id( $image ),
		'link'     => ticinoweb_frontend_url( (string) get_option( 'ticinoweb_' . $section . '_link', '' ), 'theme:' . $section . ':link' ),
	);
}

/** @return array Native CMS about fields. */
function autonec_home_about() {
 if(function_exists('autonec_about_page')&&($page=autonec_about_page())){
  return array(
   'title'=>ticinoweb_frontend_text($page->post_excerpt,'post:'.$page->ID.':excerpt'),
   'text'=>ticinoweb_frontend_text(autonec_about_summary($page->post_content),'post:'.$page->ID.':summary'),
   'image'=>'','image_id'=>0,
   'link'=>ticinoweb_frontend_url(get_permalink($page),'page:about'),
  );
 }
 return autonec_home_editorial_block( 'chi_siamo' );
}

/**
 * Read the native promotion, respecting its existing disable/date behavior.
 *
 * @return array Empty when disabled, otherwise native editorial fields.
 */
function autonec_home_promo() {
	if ( get_option( 'ticinoweb_disable_promozioni', 0 ) ) {
		return array();
	}
	// Normal option reads preserve the parent's active-period frontend filters.
	return autonec_home_editorial_block( 'promozioni' );
}

/** @return array[] Existing parent services, including parent translation. */
function autonec_home_services() {
	$services = ticinoweb_get_services();
	return is_array( $services ) ? $services : array();
}

