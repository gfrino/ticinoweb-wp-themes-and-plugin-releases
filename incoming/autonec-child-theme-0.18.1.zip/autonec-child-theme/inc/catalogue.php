<?php
/** Local vehicle records, identity and source validation. @package AutonecChildTheme */
if ( ! defined( 'ABSPATH' ) ) { exit; }

function autonec_catalogue_validate_source_url( $url ) {
 $p = wp_parse_url( trim( (string) $url ) );
 if ( ! $p || ( $p['scheme'] ?? '' ) !== 'https' || ! in_array( strtolower( $p['host'] ?? '' ), array('carmarket.ch','www.carmarket.ch'), true ) || isset($p['user']) || isset($p['pass']) || isset($p['port']) || ! preg_match('~^/(it)/concessionaria/[a-z0-9-]+-([1-9][0-9]*)/?$~D',$p['path']??'') ) {
  return new WP_Error('source_url',__('Inserisci il collegamento della concessionaria su Carmarket, completo di https://.','autonec-child-theme'));
 }
 return esc_url_raw( $url, array('https') );
}

function autonec_catalogue_allowed_url( $url, $image = false ) {
 $p = wp_parse_url( (string) $url );
 if ( ! $p || ($p['scheme']??'')!=='https' || isset($p['user']) || isset($p['pass']) || (isset($p['port'])&&443!==$p['port']) ) { return false; }
 $host=strtolower($p['host']??'');
 if($image){return in_array($host,array('vehicle.imgix.net','ppimg.imgix.net'),true);}
 return in_array($host,array('carmarket.ch','www.carmarket.ch','ppimg.imgix.net','vehicle.imgix.net'),true) || (bool)preg_match('/^[a-z0-9]+-dsn\.algolia\.net$/D',$host);
}

function autonec_catalogue_http( $url, $args = array() ) {
 if(!autonec_catalogue_allowed_url($url)){return new WP_Error('http_host',__('Fonte non supportata.','autonec-child-theme'));}
 $args=wp_parse_args($args,array('timeout'=>18,'redirection'=>0,'limit_response_size'=>4*MB_IN_BYTES,'user-agent'=>'Autonec catalogue/1.0; '.home_url('/')));
 $args['redirection']=0;$args['reject_unsafe_urls']=true;$args['sslverify']=true;$args['timeout']=min(20,(int)$args['timeout']);$args['limit_response_size']=min(4*MB_IN_BYTES,(int)$args['limit_response_size']);
 $response=wp_safe_remote_request($url,$args);
 if(is_wp_error($response)){return $response;}
 if(wp_remote_retrieve_response_code($response)!==200){return new WP_Error('http_status',sprintf(__('La fonte ha risposto con stato %d. Riprova più tardi.','autonec-child-theme'),wp_remote_retrieve_response_code($response)));}
 if(strlen(wp_remote_retrieve_body($response)) >= $args['limit_response_size']){return new WP_Error('http_size',__('Risposta incompleta: il catalogo precedente è stato conservato.','autonec-child-theme'));}
 return $response;
}

function autonec_catalogue_normalize( $r ) {
 if(!is_array($r)||($r['provider']??'')!=='carmarket'||!preg_match('/^[0-9]{1,30}$/D',(string)($r['external_id']??''))||empty($r['title'])||empty($r['brand'])){return new WP_Error('invalid_vehicle',__('Una scheda della fonte è incompleta. Nessun annuncio precedente è stato rimosso.','autonec-child-theme'));}
 $n=array('provider'=>'carmarket','external_id'=>(string)$r['external_id']);
 foreach(array('title','brand','model','currency','fuel','transmission','power','body','condition') as $field){$n[$field]=sanitize_text_field((string)($r[$field]??''));}
 $n['currency']=preg_match('/^[A-Z]{3}$/D',$n['currency'])?$n['currency']:'';
 $n['description']=wp_kses_post((string)($r['description']??''));
 foreach(array('price','mileage') as $field){$n[$field]=isset($r[$field])&&is_numeric($r[$field])&&$r[$field]>=0?(float)$r[$field]:null;}
 $n['year']=!empty($r['year'])&&is_numeric($r['year'])&&(int)$r['year']>=1900&&(int)$r['year']<=((int)gmdate('Y')+2)?(int)$r['year']:null;
 $n['reserved']=!empty($r['reserved']);$n['source_url']=autonec_catalogue_allowed_url($r['source_url']??'')?esc_url_raw($r['source_url']):'';
 $n['images']=array_values(array_unique(array_filter((array)($r['images']??array()),static fn($url)=>is_string($url)&&autonec_catalogue_allowed_url($url,true))));
 if(count($n['images'])>60){return new WP_Error('too_many_images',__('La galleria della fonte richiede una verifica.','autonec-child-theme'));}
 return $n;
}

function autonec_catalogue_snapshot( $result ) {
 if(is_wp_error($result)){return $result;}
 if(!is_array($result)||empty($result['complete'])||!isset($result['items'],$result['total'])||!is_array($result['items'])||!$result['items']||count($result['items'])!==(int)$result['total']||count($result['items'])>1000){return new WP_Error('incomplete_inventory',__('Lettura vuota o incompleta: manteniamo il catalogo precedente. Verifica il collegamento e riprova.','autonec-child-theme'));}
 $items=array();foreach($result['items'] as $r){$n=autonec_catalogue_normalize($r);if(is_wp_error($n)){return $n;}$key=$n['provider'].':'.$n['external_id'];if(isset($items[$key])){return new WP_Error('duplicate_identity',__('La fonte contiene identità duplicate. Catalogo precedente conservato.','autonec-child-theme'));}$items[$key]=$n;}
 return array_values($items);
}

/** First configured enabled source wins; memberships stay separate from identity. */
function autonec_catalogue_merge( $sources, $snapshots ) {
 $merged=array();foreach($sources as $source){if(empty($source['enabled'])){continue;}foreach($snapshots[$source['id']]['items']??array() as $r){$key=$r['provider'].':'.$r['external_id'];if(!isset($merged[$key])){$merged[$key]=$r;$merged[$key]['source_ids']=array();}$merged[$key]['source_ids'][]=$source['id'];}}
 return $merged;
}

/** Source-owned snapshot. Synchronization must never read editorial overrides. */
function autonec_catalogue_raw_data( $id ) {
 $value = get_post_meta($id, '_an_vehicle', true);
 return is_array($value) ? $value : array();
}

/** Public/editorial view: explicit local choices overlay the current source. */
function autonec_catalogue_data( $id ) {
 $raw = autonec_catalogue_raw_data($id);
 $local = get_post_meta($id, '_an_vehicle_overrides', true);
 if (!$raw && !get_post_meta($id, '_an_vehicle_manual', true)) return array();
 $defaults = array('brand'=>'','model'=>'','price'=>null,'currency'=>'','year'=>null,'mileage'=>null,'fuel'=>'','transmission'=>'','power'=>'','body'=>'','condition'=>'','description'=>'','gallery'=>array(),'reserved'=>false,'availability'=>'available','color'=>'','first_registration'=>'','doors'=>null,'seats'=>null,'drive'=>'','displacement'=>null);
 if (!$raw) $defaults['currency']='CHF';
 return array_replace($defaults, $raw, is_array($local) ? array_intersect_key($local, $defaults) : array());
}

/** The shared catalogue query always indexes effective, not imported, facts. */
function autonec_catalogue_index( $id ) {
 $data = autonec_catalogue_data($id);
 foreach (array('model','fuel','condition','price','currency','availability') as $field) {
  if (!isset($data[$field]) || $data[$field] === '') delete_post_meta($id, '_an_'.$field);
  else update_post_meta($id, '_an_'.$field, $data[$field]);
 }
 if (empty($data['brand'])) return wp_set_object_terms($id, array(), 'an_marca', false);
 $term = term_exists($data['brand'], 'an_marca');
 if (!$term) $term = wp_insert_term($data['brand'], 'an_marca');
 if (is_wp_error($term)) return $term;
 return wp_set_object_terms($id, array((int)$term['term_id']), 'an_marca', false);
}

function autonec_catalogue_store_record( $record ) {
 $normalized=autonec_catalogue_normalize($record);if(is_wp_error($normalized)){return $normalized;}
 $key=$normalized['provider'].':'.$normalized['external_id'];
 $ids=get_posts(array('post_type'=>'veicoli','post_status'=>array('publish','draft','pending','private','trash'),'fields'=>'ids','posts_per_page'=>2,'meta_key'=>'_an_external_key','meta_value'=>$key,'suppress_filters'=>true));
 if(count($ids)>1){return new WP_Error('duplicate_local',__('Due schede locali hanno la stessa identità. Verifica i veicoli prima di riprovare.','autonec-child-theme'));}
 $id=$ids?(int)$ids[0]:0;$old=$id?autonec_catalogue_raw_data($id):array();
 $post=array('post_type'=>'veicoli','post_status'=>$id?get_post_status($id):'publish');
 if(!$id||get_the_title($id)===($old['title']??'')){$post['post_title']=$normalized['title'];}
 if($id){$post['ID']=$id;}
 $id=$id?wp_update_post(wp_slash($post),true):wp_insert_post(wp_slash($post),true);if(is_wp_error($id)){return $id;}
 $normalized['source_ids']=array_values((array)($record['source_ids']??array()));$normalized['gallery']=(array)($old['gallery']??array());$normalized['availability']='available';$normalized['last_seen']=time();
 update_post_meta($id,'_an_vehicle',wp_slash($normalized));update_post_meta($id,'_an_external_key',$key);if(!metadata_exists('post',$id,'_an_vehicle_featured'))update_post_meta($id,'_an_vehicle_featured',0);
 $indexed=autonec_catalogue_index($id);if(is_wp_error($indexed))return $indexed;
 return (int)$id;
}

function autonec_catalogue_mark_missing( $managed_ids, $seen_ids ) {
 foreach(array_diff(array_map('intval',$managed_ids),array_map('intval',$seen_ids)) as $id){$r=autonec_catalogue_raw_data($id);if(!$r||!get_post_meta($id,'_an_external_key',true)){continue;}$r['availability']='unavailable';update_post_meta($id,'_an_vehicle',wp_slash($r));autonec_catalogue_index($id);}
}

function autonec_catalogue_query( $args = array() ) {
 $args=wp_parse_args($args,array('posts_per_page'=>12,'meta_key'=>'_an_vehicle_featured','orderby'=>array('meta_value_num'=>'DESC','menu_order'=>'ASC','date'=>'DESC')));$args['post_type']='veicoli';$args['post_status']='publish';
 $args['meta_query']=array('relation'=>'AND',array('key'=>'_an_availability','value'=>'available'),$args['meta_query']??array());return new WP_Query($args);
}

function autonec_catalogue_page_url() {
 static $urls=array();
 $language=determine_locale().'|'.(string)apply_filters('wpml_current_language',null).'|'.home_url('/');
 if(!array_key_exists($language,$urls)){
  $pages=get_posts(array('post_type'=>'page','post_status'=>'publish','posts_per_page'=>1,'meta_key'=>'_wp_page_template','meta_value'=>'template-inventory.php','fields'=>'ids','suppress_filters'=>false));
  $urls[$language]=$pages?ticinoweb_frontend_url(get_permalink($pages[0]),'page:catalogue'):'';
 }
 return $urls[$language];
}

function autonec_catalogue_price( $data ) {
 return isset($data['price'])&&$data['price']!==''?trim(($data['currency']??'').' '.number_format_i18n((float)$data['price'],0)):'';
}

add_action('init',static function(){register_taxonomy('an_marca',array('veicoli'),array('labels'=>array('name'=>__('Marchi','autonec-child-theme'),'singular_name'=>__('Marchio','autonec-child-theme')),'public'=>false,'show_ui'=>true,'show_in_rest'=>false,'meta_box_cb'=>false,'show_admin_column'=>true,'hierarchical'=>false,'rewrite'=>false));},25);

