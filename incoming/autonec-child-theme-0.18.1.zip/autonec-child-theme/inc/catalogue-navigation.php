<?php
/** Native menu expansion using the existing CMS brands and local inventory. @package AutonecChildTheme */
if ( ! defined( 'ABSPATH' ) ) { exit; }

/** Resolve the native catalogue page once while WordPress walks the whole menu. */
function autonec_catalogue_navigation_url() {
 static $url = null;
 if ( null === $url ) { $url = autonec_catalogue_page_url(); }
 return $url;
}

/** One aggregate over indexed available stock; no record scan or remote calls. */
function autonec_catalogue_navigation_stock( $condition = '' ) {
 static $cache = array();
 if ( isset( $cache[$condition] ) ) { return $cache[$condition]; }
 global $wpdb;
 $values = array( 'an_marca', 'veicoli', 'publish', '_an_availability', 'available' );
 $condition_sql = '';
 if ( $condition ) {
  $condition_sql = " AND EXISTS (SELECT 1 FROM {$wpdb->postmeta} condition_fact WHERE condition_fact.post_id=p.ID AND condition_fact.meta_key=%s AND condition_fact.meta_value=%s)";
  $values[] = '_an_condition'; $values[] = $condition;
 }
 $sql = "SELECT t.term_id, t.name, t.slug, COUNT(DISTINCT p.ID) AS quantity, MIN(p.ID) AS vehicle_id
  FROM {$wpdb->terms} t
  INNER JOIN {$wpdb->term_taxonomy} tt ON tt.term_id=t.term_id
  INNER JOIN {$wpdb->term_relationships} tr ON tr.term_taxonomy_id=tt.term_taxonomy_id
  INNER JOIN {$wpdb->posts} p ON p.ID=tr.object_id
  WHERE tt.taxonomy=%s AND p.post_type=%s AND p.post_status=%s
  AND EXISTS (SELECT 1 FROM {$wpdb->postmeta} available WHERE available.post_id=p.ID AND available.meta_key=%s AND available.meta_value=%s)
  {$condition_sql} GROUP BY t.term_id, t.name, t.slug ORDER BY t.name ASC";
 $rows = $wpdb->get_results( $wpdb->prepare( $sql, $values ), ARRAY_A ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery -- request-cached available/published condition aggregate.
 $cache[$condition] = array();
 foreach ( $rows as $row ) { $cache[$condition][$row['slug']] = $row; }
 return $cache[$condition];
}

/** CMS marques describe the range; the secondary directory includes all available stock. */
function autonec_catalogue_navigation_data() {
 static $data = null;
 if ( null !== $data ) { return $data; }
 $stock = autonec_catalogue_navigation_stock();
 $counts = autonec_gamma_brand_counts();
 $data = array( 'brands'=>array(), 'stock'=>$stock, 'stock_total'=>0 );
 foreach ( $stock as $row ) { $data['stock_total'] += (int) $row['quantity']; }
 $images = array();
 foreach ( autonec_brand_pages() as $page ) {
  $slug = sanitize_title( (string) get_post_meta( $page['page_id'], '_an_catalogue_brand', true ) );
  if ( ! $slug ) { continue; }
  $brand = array( 'slug'=>$slug, 'name'=>rtrim( wp_strip_all_tags( $page['title'] ), '. ' ), 'logo_id'=>get_post_thumbnail_id( $page['page_id'] ), 'range_image_id'=>absint( $page['image_id'] ?? 0 ), 'range_count'=>$counts[$slug] ?? array() );
  $data['brands'][] = $brand;
  $images = array_merge( $images, array( $brand['logo_id'], $brand['range_image_id'] ) );
 }
 $images = array_values( array_unique( array_filter( array_map( 'absint', $images ) ) ) );
 if ( $images ) { get_posts( array( 'post_type'=>'attachment', 'post_status'=>'inherit', 'post__in'=>$images, 'posts_per_page'=>count( $images ), 'no_found_rows'=>true, 'update_post_meta_cache'=>true, 'update_post_term_cache'=>false, 'suppress_filters'=>false ) ); }
 return $data;
}

/** Human-readable availability is derived from the same local stock as the filters. */
function autonec_catalogue_navigation_quantity( $quantity ) {
 return sprintf( _n( '%s veicolo disponibile', '%s veicoli disponibili', $quantity, 'autonec-child-theme' ), number_format_i18n( $quantity ) );
}

/** The native item owns the catalogue link; this adds a separate disclosure control. */
function autonec_catalogue_navigation_item( $output, $item, $depth, $args ) {
 if ( 0 !== $depth || 'primary' !== ( $args->theme_location ?? '' ) ) { return $output; }
 $url = autonec_catalogue_navigation_url();
 if ( ! $url ) { return $output; }
 $linked_catalogue = 'page' === $item->object && 'template-inventory.php' === get_page_template_slug( (int) $item->object_id );
 if ( ! $linked_catalogue && untrailingslashit( $item->url ) !== untrailingslashit( $url ) ) { return $output; }
 $data = autonec_catalogue_navigation_data();
 $id = wp_unique_id( 'an-vehicle-navigation-' );
 $title_id = $id . '-title';
 ob_start();
 ?>
 <button class="an-catalogue-toggle" type="button" aria-expanded="false" aria-controls="<?php echo esc_attr( $id ); ?>" aria-label="<?php echo esc_attr( sprintf( __( 'Esplora %s', 'autonec-child-theme' ), wp_strip_all_tags( $item->title ) ) ); ?>" hidden><span aria-hidden="true"></span></button>
 <div class="an-catalogue-menu" id="<?php echo esc_attr( $id ); ?>" role="group" aria-labelledby="<?php echo esc_attr( $title_id ); ?>" data-lenis-prevent>
  <div class="an-catalogue-menu__heading"><div><p class="an-catalogue-menu__title" id="<?php echo esc_attr( $title_id ); ?>"><?php esc_html_e( 'Gamma nuova', 'autonec-child-theme' ); ?></p><p class="an-catalogue-menu__total"><?php esc_html_e( 'Esplora la gamma dei nostri marchi.', 'autonec-child-theme' ); ?></p></div><a class="an-catalogue-menu__all" href="<?php echo esc_url( autonec_gamma_page_url() ); ?>"><?php esc_html_e( 'Gamma completa', 'autonec-child-theme' ); ?></a></div>
  <div class="an-catalogue-menu__collections">
   <section class="an-catalogue-menu__new" aria-labelledby="<?php echo esc_attr( $title_id ); ?>">
    <ul class="an-catalogue-menu__brands">
     <?php foreach ( $data['brands'] as $brand ) : ?>
     <li><a class="an-catalogue-menu__brand" href="<?php echo esc_url( autonec_gamma_page_url( $brand['slug'] ) ); ?>">
      <span class="an-catalogue-menu__logo"><?php if ( $brand['logo_id'] ) { echo wp_get_attachment_image( $brand['logo_id'], 'medium', false, array( 'alt'=>'', 'aria-hidden'=>'true', 'loading'=>'lazy', 'decoding'=>'async', 'sizes'=>'140px' ) ); } ?></span>
      <?php if ( $brand['range_image_id'] ) : ?><span class="an-catalogue-menu__photo"><?php echo wp_get_attachment_image( $brand['range_image_id'], 'medium_large', false, array( 'alt'=>'', 'aria-hidden'=>'true', 'loading'=>'lazy', 'decoding'=>'async', 'sizes'=>'(max-width: 899px) 42vw, 23vw' ) ); ?></span><?php endif; ?>
      <span class="an-catalogue-menu__brand-name"><?php echo esc_html( $brand['name'] ); ?></span>
      <span class="an-catalogue-menu__quantity"><?php echo esc_html( autonec_gamma_count_label( $brand['range_count'] ) ); ?></span>
     </a></li>
     <?php endforeach; ?>
    </ul>
   </section>
   <section class="an-catalogue-menu__used" aria-labelledby="<?php echo esc_attr( $id . '-used' ); ?>">
    <header class="an-catalogue-menu__section-heading"><div><h2 id="<?php echo esc_attr( $id . '-used' ); ?>"><?php esc_html_e( 'Occasioni', 'autonec-child-theme' ); ?></h2><p><?php echo esc_html( autonec_catalogue_navigation_quantity( $data['stock_total'] ) ); ?></p></div></header>
    <div class="an-catalogue-menu__used-actions">
     <a class="an-catalogue-menu__used-all an-link" href="<?php echo esc_url( $url ); ?>"><?php esc_html_e( 'Tutte le occasioni', 'autonec-child-theme' ); ?></a>
    <?php if ( $data['stock'] ) : ?><ul class="an-catalogue-menu__used-brands">
     <?php foreach ( $data['stock'] as $row ) : ?><li><a href="<?php echo esc_url( add_query_arg( array( 'marca'=>$row['slug'] ), $url ) ); ?>"><span><?php echo esc_html( autonec_catalogue_text( $row['name'], 'brand:' . $row['slug'] ) ); ?></span><span><?php echo esc_html( number_format_i18n( $row['quantity'] ) ); ?></span></a></li><?php endforeach; ?>
    </ul><?php endif; ?>
    </div>
   </section>
  </div>
 </div>
 <?php
 return $output . ob_get_clean();
}
add_filter( 'walker_nav_menu_start_el', 'autonec_catalogue_navigation_item', 20, 4 );

/** Class the existing menu record without creating or editing menu content. */
add_filter( 'nav_menu_css_class', static function( $classes, $item, $args, $depth ) {
 if ( 0 !== $depth || 'primary' !== ( $args->theme_location ?? '' ) ) { return $classes; }
 $url = autonec_catalogue_navigation_url();
 if ( $url && ( ( 'page' === $item->object && 'template-inventory.php' === get_page_template_slug( (int) $item->object_id ) ) || untrailingslashit( $item->url ) === untrailingslashit( $url ) ) ) { $classes[] = 'an-menu-catalogue'; }
 return $classes;
}, 20, 4 );


/** Shortcuts use actual source condition values and preserve the sanitized active filters. */
function autonec_catalogue_condition_links( $filters ) {
 $facets = autonec_catalogue_facets( $filters['marca'] );
 $conditions = array( ''=>__( 'Tutte', 'autonec-child-theme' ) );
 foreach ( array( 'Nuovi'=>__( 'Nuove', 'autonec-child-theme' ), 'Occasioni'=>__( 'Occasioni', 'autonec-child-theme' ) ) as $value=>$label ) {
  if ( in_array( $value, $facets['condizione'], true ) ) { $conditions[$value] = $label; }
 }
 $args = array_filter( array_diff_key( $filters, array( 'pagina'=>true, 'condizione'=>true ) ), static function( $value ) { return '' !== $value; } );
 ?>
 <nav class="an-catalogue-condition-links" aria-label="<?php esc_attr_e( 'Vetture disponibili per condizione', 'autonec-child-theme' ); ?>">
  <?php foreach ( $conditions as $value=>$label ) : $link_args = $args; if ( '' !== $value ) { $link_args['condizione'] = $value; } ?>
   <a href="<?php echo esc_url( add_query_arg( $link_args, autonec_catalogue_page_url() ) . '#an-catalogue-results-title' ); ?>"<?php if ( $filters['condizione'] === $value ) { echo ' aria-current="page"'; } ?>><?php echo esc_html( $label ); ?></a>
  <?php endforeach; ?>
 </nav>
 <?php
}
