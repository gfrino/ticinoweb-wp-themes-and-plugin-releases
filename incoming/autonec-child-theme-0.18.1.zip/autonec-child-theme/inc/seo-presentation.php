<?php
/** Extend the parent canonical with the listing that was actually rendered. */
defined('ABSPATH') || exit;

/** Complete the parent's existing organization, using the same CMS contacts as the footer. */
add_filter('ticinoweb_seo_jsonld_org_schema',static function($schema){
 if(!is_array($schema)||!function_exists('ticinoweb_get_contact_info'))return $schema;
 $contact=ticinoweb_get_contact_info();
 foreach(array('phone'=>'telephone','email'=>'email','address'=>'address') as $field=>$property){
  if(empty($schema[$property])&&!empty($contact[$field]))$schema[$property]=wp_strip_all_tags($contact[$field]);
 }
 return $schema;
});

/** An outdated numbered URL returns the last real page, without extra work on valid pages. */
function autonec_listing_resolve_page($query,&$filters,$run){
 if((int)$filters['pagina']<=1||!empty($query->posts))return $query;
 $max=(int)$query->max_num_pages;
 // WP_Query reports zero found rows when an OFFSET is beyond the final record.
 if($max<=0){
  $first=$filters;$first['pagina']=1;$probe=$run($first);$max=(int)$probe->max_num_pages;
  if($max<=1){$filters['pagina']=1;return $probe;}
 }
 $filters['pagina']=max(1,min((int)$filters['pagina'],$max));
 return $run($filters);
}

/**
 * Register the resolved listing before wp_head, reusing its existing query.
 * Filters come from the listing's sanitized query contract, never the raw URL.
 * The parent still owns the native page URL, language, robots and schema.
 */
function autonec_listing_seo_context($query,$filters) {
 if(is_page_template('template-inventory.php')){
  $keys=array('marca','modello','alimentazione','condizione','prezzo_min','prezzo_max');
 }elseif(is_page_template('template-range.php')){
  $keys=array('marca','categoria');
 }else{return;}
 if(!$query){return;}
 $args=array();
 foreach($keys as $key){
  if(isset($filters[$key])&&is_scalar($filters[$key])&&''!==(string)$filters[$key]){
   $args[$key]=(string)$filters[$key];
  }
 }
 $page=(int)$query->get('paged');
 if($page>1&&$page<=(int)$query->max_num_pages){$args['pagina']=$page;}
 if(!$args){return;}
 add_filter('ticinoweb_seo_canonical_url',static function($canonical)use($args){
  return $canonical?add_query_arg($args,$canonical):$canonical;
 },30);
}
