<?php
/** Optional local video for the native CMS hero image. @package AutonecChildTheme */
if ( ! defined( 'ABSPATH' ) ) { exit; }

/** A video must be an MP4 attachment served by this blog's Media Library. */
function autonec_local_video_id( $id ) {
 if ( ! is_scalar( $id ) || ! ctype_digit( (string) $id ) || (int) $id < 1 || 'inherit' !== get_post_field( 'post_status', (int) $id, 'raw' ) || 'video/mp4' !== get_post_mime_type( (int) $id ) ) { return 0; }
 $uploads = wp_upload_dir();
 $url = wp_get_attachment_url( (int) $id );
 return is_string( $url ) && ! empty( $uploads['baseurl'] ) && 0 === strpos( $url, trailingslashit( $uploads['baseurl'] ) ) ? (int) $id : 0;
}

/** Missing, foreign, deleted or unsupported video retains the native poster. */
function autonec_hero_video_url( $image_id ) {
 if ( ! is_scalar( $image_id ) || ! ctype_digit( (string) $image_id ) || ! wp_attachment_is_image( (int) $image_id ) ) { return ''; }
 $id = autonec_local_video_id( get_post_meta( (int) $image_id, '_autonec_hero_video_id', true ) );
 return $id ? (string) wp_get_attachment_url( $id ) : '';
}

function autonec_video_attachment_fields( $fields, $post ) {
 if ( ! wp_attachment_is_image( $post->ID ) || ! current_user_can( 'upload_files' ) || ! current_user_can( 'edit_post', $post->ID ) ) { return $fields; }
 $videos = get_posts( array( 'post_type'=>'attachment', 'post_status'=>'inherit', 'post_mime_type'=>'video/mp4', 'posts_per_page'=>100, 'orderby'=>'date', 'order'=>'DESC', 'no_found_rows'=>true ) );
 $selected = autonec_local_video_id( get_post_meta( $post->ID, '_autonec_hero_video_id', true ) );
 // Keep the current choice available even beyond the 100 most recent videos.
 if ( $selected && ! in_array( $selected, wp_list_pluck( $videos, 'ID' ), true ) ) { $videos[] = get_post( $selected ); }
 $html = '<select name="attachments[' . esc_attr( $post->ID ) . '][autonec_hero_video_id]">';
 $html .= '<option value="0">' . esc_html__( 'Solo fotografia', 'autonec-child-theme' ) . '</option>';
 foreach ( $videos as $video ) {
  if ( ! autonec_local_video_id( $video->ID ) ) { continue; }
  $html .= '<option value="' . esc_attr( $video->ID ) . '" ' . selected( $selected, $video->ID, false ) . '>' . esc_html( $video->post_title ) . '</option>';
 }
 $html .= '</select>';
 $fields['autonec_hero_video_id'] = array( 'label'=>__( 'Video associato Autonec', 'autonec-child-theme' ), 'input'=>'html', 'html'=>$html, 'helps'=>__( 'Facoltativo. Per questa foto nello Slider 1 o in Autonec 365, scegli un video MP4 della Libreria Media. La foto resta visibile durante il caricamento e con movimento ridotto.', 'autonec-child-theme' ) );
 return $fields;
}
add_filter( 'attachment_fields_to_edit', 'autonec_video_attachment_fields', 20, 2 );

/** WordPress verifies its native media nonce before applying this filter. */
function autonec_video_save_attachment_fields( $post, $attachment ) {
 $image_id = isset( $post['ID'] ) ? absint( $post['ID'] ) : 0;
 if ( ! $image_id || ! wp_attachment_is_image( $image_id ) || ! current_user_can( 'upload_files' ) || ! current_user_can( 'edit_post', $image_id ) || ! array_key_exists( 'autonec_hero_video_id', $attachment ) ) { return $post; }
 $id = autonec_local_video_id( $attachment['autonec_hero_video_id'] );
 if ( $id ) { update_post_meta( $image_id, '_autonec_hero_video_id', $id ); } else { delete_post_meta( $image_id, '_autonec_hero_video_id' ); }
 return $post;
}
add_filter( 'attachment_fields_to_save', 'autonec_video_save_attachment_fields', 20, 2 );
