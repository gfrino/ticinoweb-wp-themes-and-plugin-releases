<?php
/** A small native admin for sources and imported facts. @package AutonecChildTheme */
defined('ABSPATH') || exit;

function autonec_catalogue_admin_url(){return admin_url('edit.php?post_type=veicoli&page=autonec-sources');}
function autonec_catalogue_admin_access(){if(!current_user_can('manage_options'))wp_die(esc_html__('Non hai i permessi per gestire la sincronizzazione.','autonec-child-theme'),'',array('response'=>403));}
function autonec_catalogue_date($time){return $time?wp_date(get_option('date_format').' H:i',(int)$time):__('Non ancora eseguita','autonec-child-theme');}

add_action('admin_menu',static function(){
 add_submenu_page('edit.php?post_type=veicoli',__('Fonti e sincronizzazione','autonec-child-theme'),__('Fonti e sincronizzazione','autonec-child-theme'),'manage_options','autonec-sources','autonec_catalogue_sources_screen');
 foreach(autonec_brand_pages() as $brand){$slug=get_post_meta($brand['page_id'],'_an_catalogue_brand',true);if($slug)add_submenu_page('edit.php?post_type=veicoli',wp_strip_all_tags($brand['title']),rtrim(wp_strip_all_tags($brand['title']),'. '),'edit_posts','edit.php?post_type=veicoli&an_marca_filter='.rawurlencode($slug));}
});
function autonec_catalogue_source_row($source,$index,$status=array()){
 $prefix='sources['.$index.']';?>
 <tr data-source-row data-source-id="<?php echo esc_attr($source['id']??''); ?>">
  <td><input type="hidden" name="<?php echo esc_attr($prefix); ?>[id]" value="<?php echo esc_attr($source['id']??''); ?>"><label class="screen-reader-text"><?php esc_html_e('Nome della fonte','autonec-child-theme'); ?></label><input class="regular-text" aria-label="<?php esc_attr_e('Nome della fonte','autonec-child-theme'); ?>" name="<?php echo esc_attr($prefix); ?>[label]" value="<?php echo esc_attr($source['label']??''); ?>" maxlength="100"></td>
  <td><input type="url" class="large-text" aria-label="<?php esc_attr_e('Collegamento Carmarket','autonec-child-theme'); ?>" name="<?php echo esc_attr($prefix); ?>[url]" value="<?php echo esc_attr($source['url']??''); ?>" placeholder="https://carmarket.ch/it/concessionaria/…" style="min-width:280px"><p class="description" data-source-status><?php echo esc_html($status['message']??''); ?><?php if(!empty($status['last_success'])){echo ' '.esc_html(autonec_catalogue_date($status['last_success']));} ?><?php if(isset($status['count']))echo ' · '.esc_html(sprintf(__('%d veicoli','autonec-child-theme'),$status['count'])); ?></p></td>
  <td><select name="<?php echo esc_attr($prefix); ?>[brand]" aria-label="<?php esc_attr_e('Marchio della fonte','autonec-child-theme'); ?>"><option value=""><?php esc_html_e('Tutti i marchi','autonec-child-theme'); ?></option><?php $terms=get_terms(array('taxonomy'=>'an_marca','hide_empty'=>false));foreach(is_wp_error($terms)?array():$terms as $term): ?><option value="<?php echo esc_attr($term->name); ?>" <?php selected($source['brand']??'',$term->name); ?>><?php echo esc_html($term->name); ?></option><?php endforeach; ?></select></td>
  <td><label><input type="checkbox" name="<?php echo esc_attr($prefix); ?>[enabled]" value="1" <?php checked(!empty($source['enabled'])); ?>><?php esc_html_e('Attiva','autonec-child-theme'); ?></label></td>
  <td><button class="button-link-delete" type="button" data-remove-source><?php esc_html_e('Rimuovi','autonec-child-theme'); ?></button></td>
 </tr><?php
}
function autonec_catalogue_sources_screen(){
 autonec_catalogue_admin_access();$sources=(array)get_option('an_catalogue_sources',array());$state=autonec_catalogue_state();$busy=autonec_catalogue_busy();$statuses=(array)get_option('an_catalogue_source_status',array());?>
 <div class="wrap" id="an-catalogue-admin"><h1><?php esc_html_e('Fonti e sincronizzazione','autonec-child-theme'); ?></h1>
 <p><?php esc_html_e('Inserisci il collegamento della concessionaria su Carmarket. Una sola fonte può aggiornare tutti i marchi.','autonec-child-theme'); ?></p>
 <?php if(isset($_GET['saved'])):?><div class="notice notice-success is-dismissible"><p><?php esc_html_e('Fonti salvate. Avvia la sincronizzazione per applicarle al catalogo.','autonec-child-theme'); ?></p></div><?php endif; ?>
 <div class="notice notice-info inline" style="border:1px solid #c3c4c7;padding:12px 16px;margin:20px 0">
  <p><strong data-sync-message aria-live="polite"><?php echo esc_html($state['message']??''); ?></strong> <span data-sync-progress><?php if($busy)echo esc_html(($state['done']??0).' / '.($state['total']??0)); ?></span></p>
  <p><?php esc_html_e('Ultimo aggiornamento riuscito:','autonec-child-theme'); ?> <span data-sync-success><?php echo esc_html(autonec_catalogue_date($state['last_success']??0)); ?></span></p>
  <p><?php esc_html_e('Frequenza: ogni giorno.','autonec-child-theme'); ?> <?php esc_html_e('Prossimo avvio:','autonec-child-theme'); ?> <?php echo esc_html(autonec_catalogue_date(wp_next_scheduled('an_catalogue_daily'))); ?></p>
  <button type="button" class="button button-primary" data-sync-start <?php disabled($busy); ?>><?php esc_html_e('Sincronizza ora','autonec-child-theme'); ?></button> <span data-sync-result role="status"></span>
 </div>
 <form action="<?php echo esc_url(admin_url('admin-post.php')); ?>" method="post"><input type="hidden" name="action" value="an_catalogue_save_sources"><?php wp_nonce_field('an_catalogue_sources'); ?>
 <fieldset data-source-settings <?php disabled($busy); ?>><div style="overflow-x:auto"><table class="widefat striped"><thead><tr><th><?php esc_html_e('Nome','autonec-child-theme'); ?></th><th><?php esc_html_e('Collegamento e ultimo esito','autonec-child-theme'); ?></th><th><?php esc_html_e('Marchio','autonec-child-theme'); ?></th><th><?php esc_html_e('Stato','autonec-child-theme'); ?></th><th></th></tr></thead><tbody data-source-rows><?php foreach($sources as $i=>$source)autonec_catalogue_source_row($source,$i,$statuses[$source['id']]??array()); ?></tbody></table></div>
 <p><button type="button" class="button" data-add-source><?php esc_html_e('Aggiungi fonte','autonec-child-theme'); ?></button></p>
 <p class="description"><?php esc_html_e('La prima fonte ha priorità in caso di annunci coincidenti. Disattivare o rimuovere una fonte esclude i suoi annunci al prossimo aggiornamento, se non presenti in altre fonti.','autonec-child-theme'); ?></p>
 <?php submit_button(__('Salva fonti','autonec-child-theme')); ?></fieldset></form>
 <template id="an-source-template"><?php autonec_catalogue_source_row(array('enabled'=>true),'__INDEX__'); ?></template>
 <p><?php esc_html_e('I testi e le selezioni editoriali delle schede restano indipendenti dai dati importati. Se una fonte non risponde o restituisce un elenco incompleto, conserviamo la lettura precedente.','autonec-child-theme'); ?></p>
 </div><?php
}
add_action('admin_post_an_catalogue_save_sources',static function(){
 autonec_catalogue_admin_access();check_admin_referer('an_catalogue_sources');if(autonec_catalogue_busy())wp_die(esc_html__('Attendi il completamento della sincronizzazione prima di cambiare le fonti.','autonec-child-theme'),'',array('response'=>409));
 $input=wp_unslash($_POST['sources']??array());if(!is_array($input)||count($input)>20)wp_die(esc_html__('Sono consentite al massimo venti fonti.','autonec-child-theme'));
 $sources=array();$ids=array();foreach($input as $row){if(!is_array($row)||empty($row['url']))continue;if(!is_scalar($row['url']))wp_die(esc_html__('Collegamento non valido.','autonec-child-theme'));$url=autonec_catalogue_validate_source_url($row['url']);if(is_wp_error($url))wp_die(esc_html($url->get_error_message()));
  $id=isset($row['id'])&&is_scalar($row['id'])?sanitize_key($row['id']):'';if(!$id||isset($ids[$id]))$id=wp_generate_uuid4();$ids[$id]=true;
  $label=isset($row['label'])&&is_scalar($row['label'])?sanitize_text_field($row['label']):'';$brand=isset($row['brand'])&&is_scalar($row['brand'])?sanitize_text_field($row['brand']):'';
  $sources[]=array('id'=>$id,'label'=>$label?:__('Catalogo Carmarket','autonec-child-theme'),'url'=>$url,'brand'=>$brand,'enabled'=>!empty($row['enabled']));
 }
 update_option('an_catalogue_sources',$sources,false);if(!wp_next_scheduled('an_catalogue_daily'))wp_schedule_event(time()+DAY_IN_SECONDS,'daily','an_catalogue_daily');wp_safe_redirect(add_query_arg('saved','1',autonec_catalogue_admin_url()));exit;
});
add_action('wp_ajax_an_catalogue_sync',static function(){
 autonec_catalogue_admin_access();check_ajax_referer('an_catalogue_sync');
 if(($_POST['command']??'')==='start'){$result=autonec_catalogue_start();if(is_wp_error($result))wp_send_json_error(array('message'=>$result->get_error_message()),409);}
 // Authenticated progress calls also advance one bounded batch when loopback cron is unavailable locally.
 if(($_POST['command']??'')!=='start'&&autonec_catalogue_busy())autonec_catalogue_work();
 $state=autonec_catalogue_state();$state['busy']=autonec_catalogue_busy();$state['last_success_label']=autonec_catalogue_date($state['last_success']??0);$state['source_summaries']=array();foreach((array)get_option('an_catalogue_source_status',array()) as $id=>$status){$state['source_summaries'][$id]=trim(($status['message']??'').' '.(!empty($status['last_success'])?autonec_catalogue_date($status['last_success']):'').(isset($status['count'])?' · '.sprintf(__('%d veicoli','autonec-child-theme'),$status['count']):''));}wp_send_json_success($state);
});
add_action('admin_enqueue_scripts',static function(){if(($_GET['page']??'')!=='autonec-sources')return;wp_enqueue_script('autonec-catalogue-admin',get_stylesheet_directory_uri().'/assets/js/catalogue-admin.js',array(),wp_get_theme()->get('Version'),true);wp_localize_script('autonec-catalogue-admin','AutonecCatalogueAdmin',array('url'=>admin_url('admin-ajax.php'),'nonce'=>wp_create_nonce('an_catalogue_sync'),'busy'=>autonec_catalogue_busy(),'error'=>__('Connessione interrotta. La sincronizzazione riprenderà automaticamente; puoi ricaricare questa pagina.','autonec-child-theme')));});

add_filter('manage_veicoli_posts_columns',static function($columns){return array('cb'=>$columns['cb'],'an_photo'=>__('Foto','autonec-child-theme'),'title'=>__('Veicolo','autonec-child-theme'),'taxonomy-an_marca'=>__('Marchio','autonec-child-theme'),'an_price'=>__('Prezzo','autonec-child-theme'),'an_state'=>__('Disponibilità','autonec-child-theme'),'an_updated'=>__('Aggiornato','autonec-child-theme'),'date'=>$columns['date']);});
add_action('manage_veicoli_posts_custom_column',static function($column,$id){$r=autonec_catalogue_data($id);if($column==='an_photo')echo get_the_post_thumbnail($id,array(90,60));if($column==='an_price')echo esc_html(autonec_catalogue_price($r));if($column==='an_state')echo esc_html(($r['availability']??'')==='sold'?__('Venduta','autonec-child-theme'):(($r['availability']??'')==='unavailable'?__('Non più disponibile','autonec-child-theme'):(!empty($r['reserved'])?__('Riservata','autonec-child-theme'):__('Disponibile','autonec-child-theme'))));if($column==='an_updated')echo esc_html(get_post_meta($id,'_an_vehicle_manual',true)?__('Gestione manuale','autonec-child-theme'):autonec_catalogue_date($r['last_seen']??0));},10,2);
add_action('restrict_manage_posts',static function($type){if($type!=='veicoli')return;wp_dropdown_categories(array('taxonomy'=>'an_marca','name'=>'an_marca_filter','value_field'=>'slug','selected'=>sanitize_title(wp_unslash($_GET['an_marca_filter']??'')),'show_option_all'=>__('Tutti i marchi','autonec-child-theme'),'hide_empty'=>false,'hierarchical'=>false));});
add_action('pre_get_posts',static function($query){if(is_admin()&&$query->is_main_query()&&$query->get('post_type')==='veicoli'&&!empty($_GET['an_marca_filter']))$query->set('tax_query',array(array('taxonomy'=>'an_marca','field'=>'slug','terms'=>sanitize_title(wp_unslash($_GET['an_marca_filter'])))));});
add_action('add_meta_boxes_page',static function($post){if(get_page_template_slug($post->ID)!=='template-marque.php')return;add_meta_box('an-page-stock',__('Veicoli del marchio','autonec-child-theme'),static function($post){wp_nonce_field('an_page_brand','an_page_brand_nonce');$selected=get_post_meta($post->ID,'_an_catalogue_brand',true);$terms=get_terms(array('taxonomy'=>'an_marca','hide_empty'=>false));?><label for="an-page-brand"><?php esc_html_e('Marchio da mostrare in questa pagina','autonec-child-theme'); ?></label><select name="an_page_brand" id="an-page-brand" class="widefat"><option value=""><?php esc_html_e('Nessun collegamento','autonec-child-theme'); ?></option><?php foreach(is_wp_error($terms)?array():$terms as $term):?><option value="<?php echo esc_attr($term->slug); ?>" <?php selected($selected,$term->slug); ?>><?php echo esc_html($term->name); ?></option><?php endforeach; ?></select><?php },'page','side');});
add_action('save_post_page',static function($id){if(wp_is_post_autosave($id)||wp_is_post_revision($id)||!current_user_can('edit_post',$id)||empty($_POST['an_page_brand_nonce'])||!wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['an_page_brand_nonce'])),'an_page_brand'))return;$slug=isset($_POST['an_page_brand'])&&is_string($_POST['an_page_brand'])?sanitize_title(wp_unslash($_POST['an_page_brand'])):'';if(!$slug||get_term_by('slug',$slug,'an_marca'))update_post_meta($id,'_an_catalogue_brand',$slug);});
