<?php
/** Public Carmarket inventory reader. No requests run during frontend rendering. */
defined( 'ABSPATH' ) || exit;

/** Compatibility reader for explicit synchronous callers; background jobs use the step reader. */
function autonec_catalogue_carmarket( array $source ) {
	$cursor = array();
	for ( $attempt = 0; $attempt < 35; ++$attempt ) {
		$step = autonec_catalogue_carmarket_step( $source, $cursor );
		if ( is_wp_error( $step ) ) { return $step; }
		if ( $step['done'] ) { return $step['result']; }
		$cursor = $step['cursor'];
	}
	return new WP_Error( 'autonec_carmarket_steps', __( 'La lettura della fonte ha superato il limite previsto.', 'autonec-child-theme' ) );
}

/** One resumable read step: at most one HTTP request, never a partial importable result. */
function autonec_catalogue_carmarket_step( array $source, array $cursor = array() ) {
	$url = wp_parse_url( (string) ( $source['url'] ?? '' ) );
	if ( ! is_array( $url ) || 'https' !== ( $url['scheme'] ?? '' ) || ! in_array( strtolower( $url['host'] ?? '' ), array( 'carmarket.ch', 'www.carmarket.ch' ), true ) || isset( $url['user'] ) || isset( $url['port'] ) || ! preg_match( '~^/(it)/concessionaria/[a-z0-9-]+-([1-9][0-9]*)/?$~D', $url['path'] ?? '', $match ) ) {
		return new WP_Error( 'autonec_carmarket_url', __( 'Usa il link italiano della concessionaria Carmarket: al momento è supportata la sezione /it/concessionaria/.', 'autonec-child-theme' ) );
	}
	$fingerprint = hash( 'sha256', wp_json_encode( array( $source['id'] ?? '', $source['url'], $source['brand'] ?? '' ) ) );
	if ( ! $cursor ) {
		$cursor = array( 'version' => 1, 'source_hash' => $fingerprint, 'stage' => 'document', 'dealer' => (int) $match[2], 'language' => $match[1], 'document_url' => 'https://carmarket.ch' . $url['path'], 'page' => 0, 'total' => null, 'pages' => 1, 'page_size' => null, 'seen' => array(), 'items' => array() );
		$config = wp_cache_get( 'carmarket_public_search', 'autonec_catalogue' );
		if ( autonec_catalogue_carmarket_valid_config( $config ) ) {
			$cursor['config'] = $config;
			$cursor['stage'] = 'stock';
		}
	} elseif ( 1 !== ( $cursor['version'] ?? null ) || ! hash_equals( $fingerprint, (string) ( $cursor['source_hash'] ?? '' ) ) ) {
		return new WP_Error( 'autonec_carmarket_cursor', __( 'La fonte è cambiata durante la lettura. Avvia un nuovo aggiornamento.', 'autonec-child-theme' ) );
	}

	if ( 'document' === $cursor['stage'] ) {
		$response = autonec_catalogue_http( $cursor['document_url'] );
		if ( is_wp_error( $response ) ) { return $response; }
		if ( ! preg_match( '~<script\b[^>]*\bsrc=["\'](/assets/main-[A-Za-z0-9_-]+\.js)["\']~', wp_remote_retrieve_body( $response ), $script ) ) {
			return autonec_catalogue_carmarket_discovery_error();
		}
		$cursor['main_asset'] = $script[1];
		$cursor['stage'] = 'main';
		return array( 'done' => false, 'cursor' => $cursor );
	}
	if ( in_array( $cursor['stage'], array( 'main', 'script' ), true ) ) {
		$is_main = 'main' === $cursor['stage'];
		$asset = $is_main ? $cursor['main_asset'] : ( $cursor['assets'][ $cursor['asset_index'] ] ?? '' );
		if ( ! is_string( $asset ) || ! preg_match( '~^/assets/(?:main|customStyles)-[A-Za-z0-9_-]+\.js$~D', $asset ) ) {
			return autonec_catalogue_carmarket_discovery_error();
		}
		$response = autonec_catalogue_http( 'https://carmarket.ch' . $asset );
		if ( is_wp_error( $response ) ) { return $response; }
		$javascript = wp_remote_retrieve_body( $response );
		$config = autonec_catalogue_carmarket_parse_config( $javascript );
		if ( $config ) {
			$cursor['config'] = $config;
			$cursor['stage'] = 'stock';
			unset( $cursor['assets'], $cursor['asset_index'], $cursor['main_asset'] );
			wp_cache_set( 'carmarket_public_search', $config, 'autonec_catalogue', 6 * 3600 );
		} elseif ( $is_main ) {
			preg_match_all( '~from\s*["\']\./(customStyles-[A-Za-z0-9_-]+\.js)["\']~', $javascript, $imports );
			$cursor['assets'] = array_map( static fn( $name ) => '/assets/' . $name, array_slice( array_values( array_unique( $imports[1] ) ), 0, 4 ) );
			$cursor['asset_index'] = 0;
			$cursor['stage'] = 'script';
			if ( ! $cursor['assets'] ) { return autonec_catalogue_carmarket_discovery_error(); }
		} else {
			++$cursor['asset_index'];
			if ( $cursor['asset_index'] >= count( $cursor['assets'] ) ) { return autonec_catalogue_carmarket_discovery_error(); }
		}
		return array( 'done' => false, 'cursor' => $cursor );
	}
	if ( 'stock' !== $cursor['stage'] || ! autonec_catalogue_carmarket_valid_config( $cursor['config'] ?? null ) ) {
		return autonec_catalogue_carmarket_discovery_error();
	}
	$config = $cursor['config'];
	$endpoint = 'https://' . strtolower( $config['app'] ) . '-dsn.algolia.net/1/indexes/production_vehicle_' . $cursor['language'] . '/query';
	$response = autonec_catalogue_http( $endpoint, array(
		'method' => 'POST',
		'headers' => array( 'Content-Type' => 'application/json', 'x-algolia-application-id' => $config['app'], 'x-algolia-api-key' => $config['key'] ),
		'body' => wp_json_encode( array( 'query' => '', 'filters' => 'dealerId:' . $cursor['dealer'], 'hitsPerPage' => 100, 'page' => $cursor['page'] ) ),
		'limit_response_size' => 6 * 1024 * 1024,
	) );
	if ( is_wp_error( $response ) ) { return $response; }
	$data = json_decode( wp_remote_retrieve_body( $response ), true );
	if ( ! is_array( $data ) || ! isset( $data['hits'], $data['nbHits'], $data['nbPages'], $data['page'], $data['hitsPerPage'] ) || ! is_array( $data['hits'] ) || ! is_int( $data['nbHits'] ) || ! is_int( $data['nbPages'] ) || ! is_int( $data['page'] ) || ! is_int( $data['hitsPerPage'] ) || $cursor['page'] !== $data['page'] || $data['nbHits'] < 0 || $data['nbHits'] > 2500 || $data['nbPages'] < 0 || $data['nbPages'] > 25 || $data['hitsPerPage'] < 1 || true !== ( $data['exhaustiveNbHits'] ?? false ) ) {
		return new WP_Error( 'autonec_carmarket_response', __( 'La fonte non ha restituito un elenco completo verificabile.', 'autonec-child-theme' ) );
	}
	if ( null === $cursor['total'] ) {
		$cursor['total'] = $data['nbHits'];
		$cursor['pages'] = $data['nbPages'];
		$cursor['page_size'] = $data['hitsPerPage'];
	}
	$total = $cursor['total'];
	$page_size = $cursor['page_size'];
	$expected_pages = (int) ceil( $total / $page_size );
	if ( $total !== $data['nbHits'] || $cursor['pages'] !== $data['nbPages'] || $page_size !== $data['hitsPerPage'] || $cursor['pages'] !== $expected_pages || count( $data['hits'] ) !== min( $page_size, max( 0, $total - $cursor['page'] * $page_size ) ) ) {
		return new WP_Error( 'autonec_carmarket_partial', __( 'La lettura della fonte è parziale o lo stock è cambiato durante la lettura. Riprova.', 'autonec-child-theme' ) );
	}
	foreach ( $data['hits'] as $hit ) {
		if ( ! is_array( $hit ) || ! preg_match( '/^[1-9][0-9]*$/D', (string) ( $hit['vehicleId'] ?? '' ) ) || (string) ( $hit['dealerId'] ?? '' ) !== (string) $cursor['dealer'] || (string) ( $hit['objectID'] ?? '' ) !== (string) $hit['vehicleId'] || isset( $cursor['seen'][ $hit['vehicleId'] ] ) ) {
			return new WP_Error( 'autonec_carmarket_identity', __( 'La fonte contiene identità duplicate o veicoli di un’altra concessionaria.', 'autonec-child-theme' ) );
		}
		$item = autonec_catalogue_carmarket_item( $hit, $cursor['language'] );
		if ( is_wp_error( $item ) ) { return $item; }
		$cursor['seen'][ $hit['vehicleId'] ] = true;
		$cursor['items'][] = $item;
	}
	++$cursor['page'];
	if ( $cursor['page'] < $cursor['pages'] ) { return array( 'done' => false, 'cursor' => $cursor ); }
	if ( count( $cursor['seen'] ) !== $total || count( $cursor['items'] ) !== $total ) {
		return new WP_Error( 'autonec_carmarket_count', __( 'Non è stato possibile verificare tutti i veicoli della fonte.', 'autonec-child-theme' ) );
	}
	$items = $cursor['items'];
	if ( ! empty( $source['brand'] ) ) {
		$items = array_values( array_filter( $items, static fn( $item ) => 0 === strcasecmp( $source['brand'], $item['brand'] ) ) );
	}
	$result = array( 'items' => $items, 'complete' => true, 'total' => count( $items ), 'source_total' => $total );
	return array( 'done' => true, 'cursor' => array(), 'result' => $result );
}

/** Validate only the public application's search configuration shape. */
function autonec_catalogue_carmarket_valid_config( $config ) {
	return is_array( $config ) && is_string( $config['app'] ?? null ) && is_string( $config['key'] ?? null ) && 1 === preg_match( '/^[A-Z0-9]{10}$/D', $config['app'] ) && 1 === preg_match( '/^[A-Za-z0-9_-]{16,128}$/D', $config['key'] );
}

/** Extract the public app's adjacent search client configuration, without evaluating scripts. */
function autonec_catalogue_carmarket_parse_config( $javascript ) {
	if ( preg_match( '~\b([A-Za-z_$][\w$]*)=`([A-Z0-9]{10})`,\s*([A-Za-z_$][\w$]*)=`([A-Za-z0-9_-]{16,128})`,\s*[A-Za-z_$][\w$]*=[A-Za-z_$][\w$]*\(\1,\3\)~', $javascript, $public ) ) {
		return array( 'app' => $public[2], 'key' => $public[4] );
	}
	return false;
}

/** A public source structure change requires a connector review, not a speculative parser. */
function autonec_catalogue_carmarket_discovery_error() {
	return new WP_Error( 'autonec_carmarket_discovery', __( 'Non è stato possibile leggere la configurazione pubblica di Carmarket. Occorre verificare il collegamento.', 'autonec-child-theme' ) );
}

/** Normalize only fields represented in a source listing. */
function autonec_catalogue_carmarket_item( array $hit, $language ) {
	$id = (string) $hit['vehicleId'];
	if ( empty( $hit['title'] ) || empty( $hit['brandName'] ) || empty( $hit['modelName'] ) || ! is_string( $hit['slug'] ?? null ) || ! preg_match( '~^[a-z0-9-]+-' . preg_quote( $id, '~' ) . '$~D', $hit['slug'] ) || ! is_array( $hit['images'] ?? null ) || count( $hit['images'] ) > 40 ) {
		return new WP_Error( 'autonec_carmarket_item', __( 'Una scheda della fonte non contiene i dati principali necessari.', 'autonec-child-theme' ) );
	}
	$images = array();
	foreach ( $hit['images'] as $image ) {
		$parts = is_string( $image ) ? wp_parse_url( $image ) : false;
		if ( ! is_array( $parts ) || 'https' !== ( $parts['scheme'] ?? '' ) || 'vehicle.imgix.net' !== ( $parts['host'] ?? '' ) || isset( $parts['user'] ) || isset( $parts['port'] ) ) {
			return new WP_Error( 'autonec_carmarket_image', __( 'La fonte contiene un indirizzo immagine non supportato.', 'autonec-child-theme' ) );
		}
		$images[] = esc_url_raw( $image );
	}
	$description = array();
	foreach ( array( 'teaser', 'description' ) as $field ) {
		if ( ! empty( $hit[ $field ] ) && is_string( $hit[ $field ] ) ) { $description[] = wp_kses_post( $hit[ $field ] ); }
	}
	if ( ! empty( $hit['options'] ) && is_array( $hit['options'] ) ) {
		$options = array();
		foreach ( $hit['options'] as $option ) {
			if ( is_string( $option ) && '' !== $option ) { $options[] = '<li>' . esc_html( $option ) . '</li>'; }
		}
		if ( $options ) { $description[] = '<ul>' . implode( '', $options ) . '</ul>'; }
	}
	$year = isset( $hit['buildYear'] ) && is_numeric( $hit['buildYear'] ) && $hit['buildYear'] >= 1900 && $hit['buildYear'] <= 2200 ? (int) $hit['buildYear'] : null;
	return array(
		'external_id' => $id, 'provider' => 'carmarket', 'source_url' => 'https://carmarket.ch/' . $language . '/veicolo/' . $hit['slug'],
		'title' => sanitize_text_field( $hit['brandName'] . ' ' . $hit['title'] ), 'brand' => sanitize_text_field( $hit['brandName'] ), 'model' => sanitize_text_field( $hit['modelName'] ),
		'description' => implode( "\n\n", $description ),
		'price' => isset( $hit['priceB2CGross'] ) && is_numeric( $hit['priceB2CGross'] ) && $hit['priceB2CGross'] >= 0 ? (float) $hit['priceB2CGross'] : null,
		// Carmarket's public formatter defaults a null source currency to CHF.
		'currency' => empty( $hit['currency'] ) ? 'CHF' : sanitize_text_field( $hit['currency'] ),
		'mileage' => isset( $hit['km'] ) && is_numeric( $hit['km'] ) && $hit['km'] >= 0 ? (float) $hit['km'] : null, 'year' => $year,
		'fuel' => sanitize_text_field( $hit['fuelTypeGroup'] ?? $hit['fuelType'] ?? '' ), 'transmission' => sanitize_text_field( $hit['transmission'] ?? '' ),
		'power' => isset( $hit['ps'] ) && is_numeric( $hit['ps'] ) ? sanitize_text_field( $hit['ps'] . ' CV' ) : '',
		'body' => sanitize_text_field( $hit['bodyType'] ?? '' ), 'condition' => sanitize_text_field( $hit['vehicleCondition'] ?? '' ),
		'reserved' => ! empty( $hit['reserved'] ), 'images' => array_values( array_unique( $images ) ),
	);
}
