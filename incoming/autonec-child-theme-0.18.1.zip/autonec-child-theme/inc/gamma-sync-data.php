<?php
/** Validated source data and conservative catalogue reconciliation. */
defined('ABSPATH') || exit;

/** Compare propulsion facts independently of Italian gender and list order. */
function autonec_gamma_fact_equal($field, $left, $right) {
    if ($field !== 'powertrains' || !is_array($left) || !is_array($right)) return $left === $right;
    $normalize = static function ($values) {
        $result = array();
        foreach ($values as $value) {
            $value = trim(preg_replace('/\s+/u', ' ', (string) $value));
            $value = function_exists('mb_strtolower') ? mb_strtolower($value, 'UTF-8') : strtolower($value);
            $result[] = preg_replace(array('/^elettric[ao]\b/u', '/^ibrid[ao]\b/u'), array('elettrico', 'ibrido'), $value);
        }
        $result = array_values(array_unique($result));
        sort($result, SORT_STRING);
        return $result;
    };
    return $normalize($left) === $normalize($right);
}

/** Validate the complete discovery response before any model is written. */
function autonec_gamma_validate_feed($feed, $brand, $previous_count = 0) {
    $hosts = array(
        'opel' => array('opel.ch', 'www.opel.ch'),
        'hyundai' => array('hyundai.com', 'www.hyundai.com'),
        'leapmotor' => array('leapmotor.net', 'www.leapmotor.net'),
        'piaggio' => array('piaggio-commercial.ch', 'www.piaggio-commercial.ch'),
    );
    if (!is_string($brand) || !isset($hosts[$brand]) || !is_array($feed) || ($feed['complete'] ?? false) !== true || !isset($feed['models']) || !is_array($feed['models']) || !$feed['models'] || count($feed['models']) > 200) {
        return new WP_Error('gamma_incomplete', __('La fonte non conferma una gamma completa e valida.', 'autonec-child-theme'));
    }
    if ((int) $previous_count > 0 && count($feed['models']) * 2 < (int) $previous_count) {
        return new WP_Error('gamma_range_drop', __('La gamma ufficiale richiede una verifica prima di essere aggiornata.', 'autonec-child-theme'));
    }
    $records = $keys = $names = array();
    foreach ($feed['models'] as $item) {
        if (!is_array($item) || !is_string($item['key'] ?? null) || !preg_match('/^[a-z0-9]+(?:[-_][a-z0-9]+)*$/D', $item['key']) || strlen($item['key']) > 120 || !is_string($item['name'] ?? null) || !is_string($item['source_url'] ?? null)) {
            return new WP_Error('gamma_record', __('Un modello ufficiale contiene dati incompleti.', 'autonec-child-theme'));
        }
        $name = sanitize_text_field($item['name']);
        $url = wp_parse_url($item['source_url']);
        $name_key = function_exists('mb_strtolower') ? mb_strtolower($name, 'UTF-8') : strtolower($name);
        if ($name === '' || strlen($name) > 240 || isset($keys[$item['key']]) || isset($names[$name_key]) || !$url || ($url['scheme'] ?? '') !== 'https' || !in_array(strtolower($url['host'] ?? ''), $hosts[$brand], true) || isset($url['user']) || isset($url['pass']) || isset($url['port']) || !in_array($item['status'] ?? null, array('current', 'coming_soon'), true)) {
            return new WP_Error('gamma_identity', __('Identità, stato o pagina ufficiale del modello non validi.', 'autonec-child-theme'));
        }
        $record = array('key' => $item['key'], 'name' => $name, 'source_url' => esc_url_raw($item['source_url'], array('https')), 'status' => $item['status'], 'category' => '', 'powertrains' => array(), 'image_candidates' => array());
        if (isset($item['category']) && $item['category'] !== '') {
            if (!is_string($item['category']) || !isset(autonec_gamma_categories()[$item['category']])) return new WP_Error('gamma_category', __('Categoria ufficiale non valida.', 'autonec-child-theme'));
            $record['category'] = $item['category'];
        }
        if (isset($item['powertrains'])) {
            if (!is_array($item['powertrains']) || count($item['powertrains']) > 30) return new WP_Error('gamma_powertrains', __('Alimentazioni ufficiali non valide.', 'autonec-child-theme'));
            foreach ($item['powertrains'] as $value) {
                if (!is_string($value) || strlen($value) > 240) return new WP_Error('gamma_powertrains', __('Alimentazioni ufficiali non valide.', 'autonec-child-theme'));
                $value = sanitize_text_field($value);
                if ($value !== '') $record['powertrains'][] = $value;
            }
            $record['powertrains'] = array_values(array_unique($record['powertrains']));
        }
        foreach (array('excerpt', 'description', 'body', 'generation', 'model_year') as $field) {
            if (!isset($item[$field])) continue;
            if (!is_string($item[$field]) || strlen($item[$field]) > 20000) return new WP_Error('gamma_text', __('Testo ufficiale non valido.', 'autonec-child-theme'));
            $record[$field] = in_array($field, array('description', 'body'), true) ? wp_kses_post($item[$field]) : sanitize_text_field($item[$field]);
        }
        if (isset($item['image_candidates'])) {
            if (!is_array($item['image_candidates']) || count($item['image_candidates']) > 100) return new WP_Error('gamma_images', __('Immagini ufficiali non valide.', 'autonec-child-theme'));
            foreach ($item['image_candidates'] as $candidate) {
                if (!is_array($candidate) || !is_string($candidate['url'] ?? null)) continue;
                $parts = wp_parse_url($candidate['url']);
                if (!$parts || ($parts['scheme'] ?? '') !== 'https' || empty($parts['host']) || isset($parts['user']) || isset($parts['pass']) || isset($parts['port']) || !in_array($candidate['role'] ?? '', array('exterior', 'interior'), true)) continue;
                $focal = $candidate['focal'] ?? array(0.5, 0.5);
                if (!is_array($focal) || count($focal) !== 2 || !is_numeric($focal[0] ?? null) || !is_numeric($focal[1] ?? null)) $focal = array(0.5, 0.5);
                $record['image_candidates'][] = array('url' => esc_url_raw($candidate['url'], array('https')), 'width' => max(0, min(50000, (int) ($candidate['width'] ?? 0))), 'height' => max(0, min(50000, (int) ($candidate['height'] ?? 0))), 'role' => $candidate['role'], 'focal' => array(max(0, min(1, (float) $focal[0])), max(0, min(1, (float) $focal[1]))));
            }
        }
        $keys[$record['key']] = $names[$name_key] = true;
        $records[] = $record;
    }
    return $records;
}

/** Upsert facts only while they are still owned by the previous source snapshot. */
function autonec_gamma_sync_model($brand, $record) {
    $validated = autonec_gamma_validate_feed(array('complete' => true, 'models' => array($record)), $brand);
    if (is_wp_error($validated)) return $validated;
    $record = $validated[0];
    $identity = $brand . ':' . $record['key'];
    // Include trash: an editorial removal must not become a fresh published duplicate.
    $ids = get_posts(array('post_type' => 'modelli', 'post_status' => array_keys(get_post_stati()), 'fields' => 'ids', 'posts_per_page' => 2, 'meta_key' => '_an_model_key', 'meta_value' => $identity));
    if (count($ids) > 1) return new WP_Error('gamma_duplicate', __('Più modelli condividono la stessa identità ufficiale.', 'autonec-child-theme'));
    $new = !$ids;
    if ($new) {
        // Fresh catalogue copy is deliberately limited to confirmed facts.
        $text = $record['name'];
        if ($record['powertrains']) $text .= ' — ' . implode(', ', $record['powertrains']);
        $id = wp_insert_post(wp_slash(array('post_type' => 'modelli', 'post_status' => 'publish', 'post_title' => $record['name'], 'post_content' => '<p>' . esc_html($text) . '.</p>', 'post_excerpt' => $text . '.')), true);
        if (is_wp_error($id)) return $id;
        if (!$id) return new WP_Error('gamma_insert', __('Impossibile creare il modello.', 'autonec-child-theme'));
        update_post_meta($id, '_an_model_key', $identity);
    } else $id = (int) $ids[0];
    $post = get_post($id);
    if (!$post || $post->post_type !== 'modelli') return new WP_Error('gamma_post', __('Modello non disponibile.', 'autonec-child-theme'));
    $data = autonec_gamma_data($id);
    $previous = get_post_meta($id, '_an_gamma_source', true);
    $has_previous = is_array($previous) && isset($previous['name']);
    // A protected editorial cover still needs attention when the manufacturer's asset set changes.
    if ($has_previous && isset($previous['image_candidates'])) {
        $photo_keys = static function($items) { $keys=array(); foreach((array)$items as $item) { if(!is_array($item)||empty($item['url']))continue; $parts=wp_parse_url($item['url']);$keys[]=strtolower($parts['host']??'').($parts['path']??''); } sort($keys,SORT_STRING);return array_values(array_unique($keys)); };
        if ($photo_keys($previous['image_candidates']) !== $photo_keys($record['image_candidates'])) { update_post_meta($id,'_an_gamma_review',1);update_post_meta($id,'_an_gamma_photo_review',1); }
    }
    $base = $has_previous ? array_merge($previous, is_array($previous['_merge_base'] ?? null) ? $previous['_merge_base'] : array()) : array();
    $next_base = $base;
    $changed = array();
    foreach (array('name', 'category', 'powertrains', 'status', 'source_url', 'generation', 'model_year') as $field) {
        if (!array_key_exists($field, $record)) continue;
        $value = $record[$field];
        $blank = $value === '' || $value === array();
        if ($has_previous && !$blank && (!array_key_exists($field, $base) || !autonec_gamma_fact_equal($field, $base[$field], $value))) $changed[] = $field;
        if ($blank) continue;
        if ($field === 'name') {
            if (!$new && $has_previous && $post->post_title === ($base['name'] ?? null) && $post->post_title !== $value) {
                $updated = wp_update_post(wp_slash(array('ID' => $id, 'post_title' => $value)), true);
                if (is_wp_error($updated)) return $updated;
            }
        } elseif (in_array($field, array('category', 'powertrains', 'status', 'source_url'), true)) {
            $owned = $has_previous && array_key_exists($field, $base) && autonec_gamma_fact_equal($field, $data[$field] ?? null, $base[$field]);
            if ($field === 'status' && get_post_meta($id, '_an_gamma_auto_archived', true)) $owned = true;
            if ($new || $owned) $data[$field] = $value;
        }
        $next_base[$field] = $value;
    }
    // Local stock associations and the featured image never come from a feed.
    $data['brand_slug'] = $brand;
    // The fetched source can verify only its own URL, never an editor's different reference.
    if ($data['source_url'] === $record['source_url']) $data['source_checked'] = time();
    $stored = autonec_gamma_store_data($id, $data);
    if (is_wp_error($stored)) return $stored;
    $record['_merge_base'] = array_intersect_key($next_base, array_flip(array('name', 'category', 'powertrains', 'status', 'source_url', 'generation', 'model_year')));
    update_post_meta($id, '_an_gamma_source', wp_slash($record));
    if ($changed) {
        update_post_meta($id, '_an_gamma_review', 1);
        $copy_fields = array_values(array_diff($changed, array('source_url')));
        if ($copy_fields) {
            $pending = get_post_meta($id, '_an_gamma_review_fields', true);
            update_post_meta($id, '_an_gamma_review_fields', array_values(array_unique(array_merge(is_array($pending) ? $pending : array(), $copy_fields))));
        }
    }
    delete_post_meta($id, '_an_gamma_missing');
    delete_post_meta($id, '_an_gamma_auto_archived');
    return (int) $id;
}

/** Called only after a complete successful brand run; never deletes native posts. */
function autonec_gamma_reconcile_missing($brand, $seenkeys, $date) {
    if (!in_array($brand, array('opel', 'hyundai', 'leapmotor', 'piaggio'), true) || !is_array($seenkeys) || !$seenkeys || !is_string($date) || !preg_match('/^\d{4}-\d{2}-\d{2}$/D', $date) || !checkdate((int) substr($date, 5, 2), (int) substr($date, 8, 2), (int) substr($date, 0, 4))) return new WP_Error('gamma_reconcile', __('La verifica della gamma non è valida.', 'autonec-child-theme'));
    $seen = array();
    foreach ($seenkeys as $key) {
        if (!is_string($key) || !preg_match('/^[a-z0-9]+(?:[-_][a-z0-9]+)*$/D', $key)) return new WP_Error('gamma_reconcile', __('Identità della gamma non valida.', 'autonec-child-theme'));
        $seen[$key] = true;
    }
    $prefix = $brand . ':';
    $ids = get_posts(array('post_type' => 'modelli', 'post_status' => 'any', 'fields' => 'ids', 'posts_per_page' => -1, 'meta_query' => array(array('key' => '_an_model_key', 'value' => $prefix, 'compare' => 'LIKE'))));
    $archived = array();
    foreach ($ids as $id) {
        $identity = get_post_meta($id, '_an_model_key', true);
        if (!is_string($identity) || strpos($identity, $prefix) !== 0) continue;
        $data = autonec_gamma_data($id);
        if (isset($seen[substr($identity, strlen($prefix))])) {
            if (get_post_meta($id, '_an_gamma_auto_archived', true) && $data['status'] === 'archived') {
                $source = get_post_meta($id, '_an_gamma_source', true);
                if (in_array($source['status'] ?? null, array('current', 'coming_soon'), true)) {
                    $data['status'] = $source['status'];
                    $result = autonec_gamma_store_data($id, $data);
                    if (is_wp_error($result)) return $result;
                }
            }
            delete_post_meta($id, '_an_gamma_missing');
            delete_post_meta($id, '_an_gamma_auto_archived');
            continue;
        }
        $missing = get_post_meta($id, '_an_gamma_missing', true);
        if (!is_array($missing) || empty($missing['first']) || empty($missing['last'])) $missing = array('first' => $date, 'last' => $date, 'checks' => 1);
        elseif ($date > $missing['last']) { $missing['last'] = $date; $missing['checks'] = (int) $missing['checks'] + 1; }
        update_post_meta($id, '_an_gamma_missing', $missing);
        if ((int) $missing['checks'] >= 2 && $missing['first'] !== $missing['last'] && $data['status'] !== 'archived') {
            $data['status'] = 'archived';
            $result = autonec_gamma_store_data($id, $data);
            if (is_wp_error($result)) return $result;
            update_post_meta($id, '_an_gamma_auto_archived', 1);
            $archived[] = (int) $id;
        }
    }
    return $archived;
}
