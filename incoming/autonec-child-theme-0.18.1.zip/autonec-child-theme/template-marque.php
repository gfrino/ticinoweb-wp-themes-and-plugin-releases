<?php
/** Template Name: Marchio Autonec
 * @package AutonecChildTheme */
if ( ! defined( 'ABSPATH' ) ) { exit; }
get_header(); ?>
<main id="main-content" class="an-marque-page" tabindex="-1">
 <?php autonec_brand_navigation(); ?>
 <?php while ( have_posts() ) : the_post(); ob_start(); the_content(); $editorial = ob_get_clean(); ?>
 <article <?php post_class( 'an-marque-editorial' ); ?>>
  <?php if ( ! preg_match( '/<h1\b/i', $editorial ) ) : ?>
   <h1 class="an-wrap an-marque-fallback-title"><?php the_title(); ?></h1>
  <?php endif; ?>
  <?php echo $editorial; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- native the_content filters, rendered once. ?>
 </article>
 <?php endwhile; ?>
 <?php autonec_gamma_brand_section( get_queried_object_id() ); ?>
 <?php $others = array_filter( autonec_brand_pages(), static function( $brand ) { return $brand['page_id'] !== get_queried_object_id() && untrailingslashit( $brand['button_url'] ) !== untrailingslashit( get_permalink() ); } ); ?>
 <?php if ( $others ) : ?>
 <section class="an-brand-next an-wrap" aria-labelledby="an-brand-next-title">
  <h2 id="an-brand-next-title"><?php esc_html_e( 'Altri marchi da esplorare', 'autonec-child-theme' ); ?></h2>
  <div class="an-brand-next__links">
   <?php foreach ( $others as $brand ) : ?>
    <a href="<?php echo esc_url( $brand['button_url'] ); ?>">
     <?php if ( $brand['image'] ) { autonec_image( $brand ); } ?>
     <span><?php echo esc_html( rtrim( $brand['title'], '. ' ) ); ?></span>
    </a>
   <?php endforeach; ?>
  </div>
 </section>
 <?php endif; ?>
</main>
<?php get_footer(); ?>
