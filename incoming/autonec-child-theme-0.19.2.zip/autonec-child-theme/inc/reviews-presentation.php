<?php
/** Home presentation of the existing parent Google Reviews integration. */
defined('ABSPATH') || exit;

/** Decorative stars with an accessible numeric value, without another icon font. */
function autonec_review_stars($rating){
 $rating=max(0,min(5,(float)$rating));
 return '<span class="an-review-stars" role="img" aria-label="'.esc_attr(sprintf(__('%s su 5','autonec-child-theme'),number_format_i18n($rating,1))).'"><span aria-hidden="true">★★★★★</span><span aria-hidden="true" style="width:'.esc_attr((string)($rating*20)).'%">★★★★★</span></span>';
}

/** No API request, second archive, custom settings, or invented fallback content. */
function autonec_home_reviews(){
 if(!function_exists('ticinoweb_get_google_reviews'))return '';
 $minimum=max(0,min(5,(int)get_option('ticinoweb_google_reviews_min_rating',4)));
 $reviews=ticinoweb_get_google_reviews(3,$minimum);
 $reviews=array_filter((array)$reviews,static fn($r)=>is_array($r)&&!empty($r['author_name'])&&is_string($r['author_name'])&&isset($r['text'])&&is_string($r['text'])&&is_numeric($r['rating']??null)&&$r['rating']>=0&&$r['rating']<=5);
 if(!$reviews)return '';
 $rating=(float)get_option('ticinoweb_google_reviews_rating',0);$count=max(0,(int)get_option('ticinoweb_google_reviews_count',0));
 $link=esc_url((string)get_option('ticinoweb_google_business_link',''),['https']);
 ob_start();?>
 <section class="an-reviews an-wrap" id="recensioni" aria-labelledby="an-reviews-title" data-reveal>
  <div class="an-reviews__heading"><div><h2 id="an-reviews-title"><?php esc_html_e('Recensioni','autonec-child-theme');?></h2><p><?php esc_html_e('Una selezione delle esperienze condivise dai nostri clienti.','autonec-child-theme');?></p></div>
   <div class="an-reviews__summary">
   <?php if($rating>=1&&$rating<=5):?><div class="an-reviews__rating"><strong><?php echo esc_html(number_format_i18n($rating,1));?></strong><div><?php echo autonec_review_stars($rating);?><?php if($count):?><p><?php echo esc_html(sprintf(_n('%s recensione','%s recensioni',$count,'autonec-child-theme'),number_format_i18n($count)));?></p><?php endif;?></div></div><?php endif;?>
   <span class="an-reviews__source" translate="no">Google Maps</span>
   <?php if($link):?><a class="an-link" href="<?php echo $link;?>" target="_blank" rel="noopener noreferrer nofollow"><?php esc_html_e('Leggi su Google','autonec-child-theme');?></a><?php endif;?>
   </div>
  </div>
  <div class="an-reviews__list">
  <?php foreach($reviews as $review):$profile=esc_url((string)($review['author_url']??''),['https']);$photo=esc_url((string)($review['profile_photo_url']??''),['https']);?>
   <article class="an-review">
    <div class="an-review__author"><?php if($photo):?><img src="<?php echo $photo;?>" alt="" width="44" height="44" loading="lazy" decoding="async" referrerpolicy="no-referrer"><?php endif;?><div>
     <?php if($profile):?><a href="<?php echo $profile;?>" target="_blank" rel="noopener noreferrer nofollow"><?php echo esc_html($review['author_name']);?></a><?php else:?><span><?php echo esc_html($review['author_name']);?></span><?php endif;?>
     <?php if(!empty($review['time'])&&is_numeric($review['time'])&&$review['time']>0):?><time datetime="<?php echo esc_attr(gmdate('Y-m-d',(int)$review['time']));?>"><?php echo esc_html(wp_date(get_option('date_format'),(int)$review['time']));?></time><?php endif;?></div></div>
    <?php echo autonec_review_stars($review['rating']);?>
    <?php if(trim($review['text'])!==''):?><blockquote><p><?php echo nl2br(esc_html($review['text']));?></p></blockquote><?php endif;?>
   </article>
  <?php endforeach;?></div>
 </section>
 <?php return ob_get_clean();
}
