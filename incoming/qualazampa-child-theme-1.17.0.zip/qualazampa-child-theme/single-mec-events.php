<?php
defined('ABSPATH') || exit;
get_header();
?>
<main id="main-content" class="qz-container qz-section qz-event-page">
<?php while (have_posts()): the_post(); $id = get_the_ID(); $image = get_post_thumbnail_id(); if (post_password_required()) { the_title('<h1>', '</h1>'); echo get_the_password_form(); continue; } ?>
    <a class="qz-event-page__back" href="<?php echo esc_url(home_url('/').'#qz-events-title'); ?>"><?php esc_html_e('Torna alla home', 'qualazampa'); ?></a>
    <div class="qz-event-page__layout<?php if (!$image) echo ' qz-event-page__layout--no-image'; ?>">
        <div class="qz-event-page__story">
            <?php qz_event_demo_note($id); ?><h1><?php the_title(); ?></h1>
            <dl class="qz-event-page__details">
                <?php if (qz_event_date_label($id)): ?><div><dt><?php esc_html_e('Quando', 'qualazampa'); ?></dt><dd><?php echo esc_html(qz_event_date_label($id)); ?><?php if (qz_event_time_label($id)) echo '<br>'.esc_html(qz_event_time_label($id)); ?></dd></div><?php endif; ?>
                <?php if (qz_event_place($id)): ?><div><dt><?php esc_html_e('Dove', 'qualazampa'); ?></dt><dd><?php echo esc_html(qz_event_place($id)); ?></dd></div><?php endif; ?>
                <?php $organizer = qz_event_text($id, 'organizer'); if ($organizer): ?><div><dt><?php esc_html_e('Con', 'qualazampa'); ?></dt><dd><?php echo esc_html($organizer); ?></dd></div><?php endif; ?>
            </dl>
            <div class="qz-event-page__description"><?php the_content(); ?></div>
            <?php $link = get_post_meta($id, 'mec_more_info', true); if ($link): ?><a class="qz-button" href="<?php echo esc_url($link); ?>"><?php esc_html_e('Maggiori informazioni', 'qualazampa'); ?></a><?php endif; ?>
        </div>
        <?php if ($image): ?><div class="qz-event-page__photo"><?php qz_photo($image, 'full', ['loading' => 'eager', 'alt' => get_the_title(), 'sizes' => '(max-width:760px) 90vw, 45vw']); ?></div><?php endif; ?>
    </div>
<?php endwhile; ?>
</main>
<?php get_footer(); ?>
