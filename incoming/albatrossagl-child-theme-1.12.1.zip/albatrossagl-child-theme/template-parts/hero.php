<?php
defined('ABSPATH') || exit;
$title = get_option('ticinoweb_slider_title_1', '');
if (!$title) { return; }
$contact = albatros_contact();
$image = get_option('ticinoweb_slider_image_1');
$caption = $image ? wp_get_attachment_caption(attachment_url_to_postid($image)) : '';
$lines = preg_split('/\R+|(?<=,)\h+/u', albatros_text($title, 'hero:title'), 2);
$cta = get_option('ticinoweb_slider_btn_link_1') ?: albatros_url('contatti');
$cta = function_exists('ticinoweb_frontend_url') ? ticinoweb_frontend_url($cta, 'theme:slider:1:btn_link') : $cta;
?>
<section class="alb-hero alb-hero-stage<?php echo $image ? '' : ' alb-hero-no-image'; ?>" aria-labelledby="alb-title">
    <?php if ($image) : ?>
    <figure class="alb-hero-figure">
        <div class="alb-hero-media">
            <?php // Cover enlarges landscape photos on portrait screens; request enough pixels for the crop and the slow zoom. ?>
            <div class="alb-hero-lens"><?php echo albatros_image($image, 'full', array('loading' => 'eager', 'fetchpriority' => 'high', 'sizes' => '(max-width: 760px) 170vh, 115vw')); ?></div>
        </div>
        <?php if ($caption) : ?><figcaption class="alb-photo-caption"><?php echo esc_html(albatros_text($caption, 'hero:caption')); ?></figcaption><?php endif; ?>
    </figure>
    <?php endif; ?>
    <div class="alb-hero-copy">
        <?php if (!empty($contact['address_label'])) : ?><p class="alb-kicker"><?php echo esc_html(albatros_text($contact['address_label'], 'territory')); ?></p><?php endif; ?>
        <h1 id="alb-title"><?php foreach ($lines as $line) : ?><span class="alb-hero-line"><span class="alb-hero-ink"><?php echo esc_html($line); ?></span></span> <?php endforeach; ?></h1>
        <div class="alb-hero-bottom">
            <?php if ($description = get_option('ticinoweb_slider_desc_1')) : ?><p class="alb-lead"><?php echo esc_html(albatros_text($description, 'hero:description')); ?></p><?php endif; ?>
            <div class="alb-actions">
                <?php if ($button = get_option('ticinoweb_slider_btn_text_1')) : ?><a class="alb-button" href="<?php echo esc_url($cta); ?>"><?php echo esc_html(albatros_text($button, 'hero:button')); ?><span aria-hidden="true">↗</span></a><?php endif; ?>
                <a class="alb-text-link" href="<?php echo esc_url(albatros_url('servizi')); ?>"><?php esc_html_e('Esplora i servizi', 'albatrossagl-child-theme'); ?><span aria-hidden="true">↓</span></a>
            </div>
        </div>
    </div>
</section>
