<?php
defined('ABSPATH') || exit;
$services = function_exists('ticinoweb_get_services') ? ticinoweb_get_services() : array();
if (!$services) { return; }
$services = array_values($services);
$total = count($services);
$deck_id = wp_unique_id('alb-deck-');
$titles = array();
foreach ($services as $index => $service) {
    $key = !empty($service['id']) ? $service['id'] : (string) $index;
    $titles[$index] = function_exists('ticinoweb_frontend_text') ? ticinoweb_frontend_text($service['title'], 'theme:service:' . $key . ':title') : $service['title'];
}
?>
<div class="alb-services">
<details class="alb-service-index">
    <summary><?php esc_html_e('Esplora i servizi', 'albatrossagl-child-theme'); ?><span aria-hidden="true">↗</span></summary>
    <nav class="alb-deck-links" aria-label="<?php esc_attr_e('Esplora i servizi', 'albatrossagl-child-theme'); ?>">
    <?php foreach ($titles as $index => $title) : ?>
        <a href="#<?php echo esc_attr($deck_id . '-' . ($index + 1)); ?>"><?php echo esc_html($title); ?></a>
    <?php endforeach; ?>
    </nav>
</details>
<div class="alb-service-cards">
<?php foreach ($services as $index => $service) :
    $key = !empty($service['id']) ? $service['id'] : (string) $index;
    $title = $titles[$index];
    $heading_id = $deck_id . '-title-' . ($index + 1);
    $description = function_exists('ticinoweb_frontend_text') ? ticinoweb_frontend_text($service['description'], 'theme:service:' . $key . ':description') : $service['description'];
?>
<span class="alb-service-waypoint" id="<?php echo esc_attr($deck_id . '-' . ($index + 1)); ?>" aria-hidden="true"></span>
<article class="alb-service" data-service-key="<?php echo esc_attr($key); ?>" aria-labelledby="<?php echo esc_attr($heading_id); ?>">
    <div class="alb-service-caption" aria-hidden="true"><span><?php echo esc_html(sprintf('%02d / %02d', $index + 1, $total)); ?></span><span class="alb-card-track"><span></span></span></div>
    <div class="alb-service-layout">
    <div class="alb-service-photo"><?php echo albatros_image($service['image'] ?? '', 'large', array('sizes' => '(max-width: 760px) 100vw, 45vw')); ?></div>
    <div class="alb-service-body">
        <h3 id="<?php echo esc_attr($heading_id); ?>"><?php echo esc_html($title); ?></h3>
        <div class="alb-service-description"><?php echo wp_kses_post(wpautop($description)); ?></div>
        <a class="alb-text-link" href="<?php echo esc_url(albatros_url('contatti')); ?>"><?php esc_html_e('Parliamone', 'albatrossagl-child-theme'); ?><span aria-hidden="true">↗</span></a>
    </div>
    </div>
</article>
<?php endforeach; ?>
</div>
</div>
