<?php
/**
 * Privacy-conscious usage statistics for the EBITDA configurator.
 *
 * @package DeltoraConsultingChildTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'DELTORA_CONFIGURATOR_ANALYTICS_DB_VERSION', '1.0.0' );
define( 'DELTORA_CONFIGURATOR_RETENTION_MONTHS', 12 );

/** Return the current site's analytics table. */
function deltora_consulting_get_analytics_table() {
	global $wpdb;
	return $wpdb->prefix . 'deltora_configurator_sessions';
}

/** Create or update the site-scoped table when its schema changes. */
function deltora_consulting_install_analytics_table() {
	if ( DELTORA_CONFIGURATOR_ANALYTICS_DB_VERSION === get_option( 'deltora_configurator_analytics_db_version' ) ) {
		return;
	}

	global $wpdb;
	require_once ABSPATH . 'wp-admin/includes/upgrade.php';
	$table   = deltora_consulting_get_analytics_table();
	$charset = $wpdb->get_charset_collate();
	$sql     = "CREATE TABLE {$table} (
		id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
		session_key varchar(64) NOT NULL,
		started_at datetime NOT NULL,
		completed_at datetime NULL,
		last_activity_at datetime NOT NULL,
		status varchar(24) NOT NULL DEFAULT 'started',
		mode varchar(16) NOT NULL DEFAULT '',
		selected_company_name varchar(190) NOT NULL DEFAULT '',
		selected_company_uid varchar(32) NOT NULL DEFAULT '',
		sector_label varchar(190) NOT NULL DEFAULT '',
		contact_type varchar(32) NOT NULL DEFAULT '',
		contact_name varchar(190) NOT NULL DEFAULT '',
		contact_company varchar(190) NOT NULL DEFAULT '',
		contact_email varchar(254) NOT NULL DEFAULT '',
		contact_phone varchar(64) NOT NULL DEFAULT '',
		PRIMARY KEY  (id),
		UNIQUE KEY session_key (session_key),
		KEY started_at (started_at),
		KEY last_activity_at (last_activity_at),
		KEY status (status)
	) {$charset};";

	dbDelta( $sql );
	update_option( 'deltora_configurator_analytics_db_version', DELTORA_CONFIGURATOR_ANALYTICS_DB_VERSION, false );
}
add_action( 'after_switch_theme', 'deltora_consulting_install_analytics_table' );
add_action( 'admin_init', 'deltora_consulting_install_analytics_table', 5 );

/** Validate the short-lived, random identifier created by the configurator. */
function deltora_consulting_sanitize_session_key( $value ) {
	$value = sanitize_text_field( wp_unslash( (string) $value ) );
	return preg_match( '/^[a-zA-Z0-9-]{20,64}$/', $value ) ? $value : '';
}

/** Insert or update the non-financial metadata for one configurator run. */
function deltora_consulting_record_configurator_event( $session_key, $event, $metadata = array() ) {
	global $wpdb;
	$session_key = deltora_consulting_sanitize_session_key( $session_key );
	$event       = sanitize_key( $event );
	if ( '' === $session_key || ! in_array( $event, array( 'started', 'completed' ), true ) ) {
		return false;
	}

	deltora_consulting_install_analytics_table();
	$table = deltora_consulting_get_analytics_table();
	$now   = current_time( 'mysql', true );
	$id    = (int) $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$table} WHERE session_key = %s", $session_key ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table name is generated internally from $wpdb->prefix.

	if ( ! $id ) {
		$wpdb->insert(
			$table,
			array(
				'session_key'     => $session_key,
				'started_at'      => $now,
				'last_activity_at' => $now,
				'status'          => 'started',
			),
			array( '%s', '%s', '%s', '%s' )
		);
		$id = (int) $wpdb->insert_id;
	}

	if ( 'completed' === $event && $id ) {
		$company = isset( $metadata['company'] ) && is_array( $metadata['company'] ) ? $metadata['company'] : array();
		$wpdb->update(
			$table,
			array(
				'completed_at'         => $now,
				'last_activity_at'     => $now,
				'status'               => 'completed',
				'mode'                 => in_array( $metadata['mode'] ?? '', array( 'guided', 'direct' ), true ) ? $metadata['mode'] : '',
				'selected_company_name' => mb_substr( sanitize_text_field( $company['name'] ?? '' ), 0, 190 ),
				'selected_company_uid' => mb_substr( sanitize_text_field( $company['uid'] ?? '' ), 0, 32 ),
				'sector_label'         => mb_substr( sanitize_text_field( $metadata['sector_label'] ?? '' ), 0, 190 ),
			),
			array( 'id' => $id ),
			array( '%s', '%s', '%s', '%s', '%s', '%s', '%s' ),
			array( '%d' )
		);
	}

	return (bool) $id;
}

/** Attach an identified contact only after the related email was delivered. */
function deltora_consulting_record_configurator_contact( $session_key, $contact_type, $contact ) {
	global $wpdb;
	$session_key  = deltora_consulting_sanitize_session_key( $session_key );
	$contact_type = sanitize_key( $contact_type );
	if ( '' === $session_key || ! in_array( $contact_type, array( 'result_email', 'contact_request' ), true ) ) {
		return false;
	}

	deltora_consulting_record_configurator_event( $session_key, 'started' );
	$table       = deltora_consulting_get_analytics_table();
	$now         = current_time( 'mysql', true );
	$stored_type = (string) $wpdb->get_var( $wpdb->prepare( "SELECT contact_type FROM {$table} WHERE session_key = %s", $session_key ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table name is generated internally.
	if ( $stored_type && $stored_type !== $contact_type ) {
		$contact_type = 'both';
	}
	return false !== $wpdb->update(
		$table,
		array(
			'last_activity_at' => $now,
			'status'           => $contact_type,
			'contact_type'     => $contact_type,
			'contact_name'     => mb_substr( sanitize_text_field( $contact['name'] ?? '' ), 0, 190 ),
			'contact_company'  => mb_substr( sanitize_text_field( $contact['company'] ?? '' ), 0, 190 ),
			'contact_email'    => mb_substr( sanitize_email( $contact['email'] ?? '' ), 0, 254 ),
			'contact_phone'    => mb_substr( sanitize_text_field( $contact['phone'] ?? '' ), 0, 64 ),
		),
		array( 'session_key' => $session_key ),
		array( '%s', '%s', '%s', '%s', '%s', '%s', '%s' ),
		array( '%s' )
	);
}

/** Public endpoint for the two allowlisted, non-financial usage events. */
function deltora_consulting_ajax_record_configurator_event() {
	check_ajax_referer( 'deltora_configurator', 'nonce' );
	$rate_key = 'deltora_cfg_event_' . md5( sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ?? 'unknown' ) ) );
	$attempts = (int) get_transient( $rate_key );
	if ( 60 <= $attempts ) {
		wp_send_json_error( array( 'message' => __( 'Troppi eventi ravvicinati.', 'deltora-consulting-child-theme' ) ), 429 );
	}
	set_transient( $rate_key, $attempts + 1, HOUR_IN_SECONDS );
	$payload = deltora_consulting_read_ajax_payload();
	$event   = sanitize_key( $payload['event'] ?? '' );
	$key     = deltora_consulting_sanitize_session_key( $payload['session_key'] ?? '' );
	if ( ! $key || ! in_array( $event, array( 'started', 'completed' ), true ) ) {
		wp_send_json_error( array( 'message' => __( 'Evento non valido.', 'deltora-consulting-child-theme' ) ), 422 );
	}

	$metadata = array(
		'mode'         => sanitize_key( $payload['mode'] ?? '' ),
		'sector_label' => sanitize_text_field( $payload['sector_label'] ?? '' ),
		'company'      => array(
			'name' => sanitize_text_field( $payload['company']['name'] ?? '' ),
			'uid'  => sanitize_text_field( $payload['company']['uid'] ?? '' ),
		),
	);
	deltora_consulting_record_configurator_event( $key, $event, $metadata );
	wp_send_json_success();
}
add_action( 'wp_ajax_deltora_record_configurator_event', 'deltora_consulting_ajax_record_configurator_event' );
add_action( 'wp_ajax_nopriv_deltora_record_configurator_event', 'deltora_consulting_ajax_record_configurator_event' );

/** Delete expired rows. No raw calculation data or IP address is stored. */
function deltora_consulting_cleanup_configurator_analytics() {
	global $wpdb;
	$table  = deltora_consulting_get_analytics_table();
	$cutoff = gmdate( 'Y-m-d H:i:s', strtotime( '-' . DELTORA_CONFIGURATOR_RETENTION_MONTHS . ' months' ) );
	return $wpdb->query( $wpdb->prepare( "DELETE FROM {$table} WHERE last_activity_at < %s", $cutoff ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table name is generated internally from $wpdb->prefix.
}
add_action( 'deltora_cleanup_configurator_analytics', 'deltora_consulting_cleanup_configurator_analytics' );

/** Schedule the daily retention cleanup once for this installation. */
function deltora_consulting_schedule_analytics_cleanup() {
	if ( ! wp_next_scheduled( 'deltora_cleanup_configurator_analytics' ) ) {
		wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', 'deltora_cleanup_configurator_analytics' );
	}
}
add_action( 'init', 'deltora_consulting_schedule_analytics_cleanup' );

/** Return dashboard metrics and recent sessions for the requested period. */
function deltora_consulting_get_analytics_dashboard( $days = 30 ) {
	global $wpdb;
	$days   = in_array( (int) $days, array( 7, 30, 90 ), true ) ? (int) $days : 30;
	$table  = deltora_consulting_get_analytics_table();
	$cutoff = gmdate( 'Y-m-d H:i:s', time() - ( $days * DAY_IN_SECONDS ) );
	$totals = $wpdb->get_row(
		$wpdb->prepare(
			"SELECT COUNT(*) AS started, SUM(completed_at IS NOT NULL) AS completed, SUM(contact_type <> '') AS contacts FROM {$table} WHERE started_at >= %s", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table name is generated internally.
			$cutoff
		),
		ARRAY_A
	);
	$rows = $wpdb->get_results(
		$wpdb->prepare(
			"SELECT id, started_at, completed_at, status, selected_company_name, selected_company_uid, sector_label, contact_type, contact_name, contact_company, contact_email, contact_phone FROM {$table} WHERE started_at >= %s ORDER BY started_at DESC LIMIT 50", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table name is generated internally.
			$cutoff
		),
		ARRAY_A
	);

	return array(
		'days'      => $days,
		'started'   => (int) ( $totals['started'] ?? 0 ),
		'completed' => (int) ( $totals['completed'] ?? 0 ),
		'contacts'  => (int) ( $totals['contacts'] ?? 0 ),
		'rows'      => is_array( $rows ) ? $rows : array(),
	);
}

/** Delete one retained dashboard record. */
function deltora_consulting_handle_delete_analytics_record() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'Permessi insufficienti.', 'deltora-consulting-child-theme' ) );
	}
	$id = absint( $_POST['record_id'] ?? 0 );
	check_admin_referer( 'deltora_delete_analytics_record_' . $id );
	if ( $id ) {
		global $wpdb;
		$wpdb->delete( deltora_consulting_get_analytics_table(), array( 'id' => $id ), array( '%d' ) );
	}
	wp_safe_redirect( deltora_consulting_get_zefix_admin_url( array( 'deltora_status' => 'record-deleted' ) ) );
	exit;
}
add_action( 'admin_post_deltora_delete_analytics_record', 'deltora_consulting_handle_delete_analytics_record' );
