<?php
/**
 * Multilingual support for the EBITDA configurator.
 *
 * Every visible text of the configurator goes through deltora_consulting_t(),
 * which routes it to ticinoweb_frontend_text() (parent theme compat layer):
 * tW Translate Plus resolves it for the current language and queues new
 * strings for translation. The plugin does not hook gettext, so __() alone
 * would leave Italian on /en/.
 *
 * The JavaScript interface receives its texts in deltoraConfiguratorConfig.strings,
 * keyed by the Italian source: configurator.js calls t('…') / th('…') with the
 * same source text and falls back to Italian when a translation is missing.
 * tests/configurator-i18n.test.js keeps the two lists in sync.
 *
 * @package DeltoraConsultingChildTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Translate a Deltora theme text for the current language.
 *
 * Returns plain text: escaping stays with whoever prints it.
 *
 * @param string $text    Italian source text.
 * @param string $context Area of the site (without the deltora: prefix).
 * @return string
 */
function deltora_consulting_t( $text, $context = 'ui' ) {
	if ( function_exists( 'ticinoweb_frontend_text' ) ) {
		return (string) ticinoweb_frontend_text( (string) $text, 'deltora:' . $context );
	}
	return (string) $text;
}

/**
 * Italian source texts used by assets/js/configurator.js.
 *
 * Keep in sync with the t('…') / th('…') calls of the script
 * (enforced by tests/configurator-i18n.test.js).
 *
 * @return string[]
 */
function deltora_consulting_get_configurator_ui_sources() {
	return array(
		'Hai indicato che uno o più esercizi includono ricavi o costi eccezionali. Questi elementi possono influire sull’EBITDA medio. Contatta Deltora per verificarli e ottenere una stima più precisa.',
		'Non sei sicuro che gli EBITDA inseriti includano ricavi o costi eccezionali. Questi elementi possono influire sull’EBITDA medio. Contatta Deltora per verificarli e ottenere una stima più precisa.',
		'no',
		'sì',
		'non sono sicuro',
		'da identificare',
		'Settore',
		'EBITDA medio',
		'Componenti straordinarie',
		'da verificare',
		'Buongiorno,',
		'ho utilizzato il configuratore, ma non ho trovato un settore che rappresenti correttamente la mia azienda.',
		'ATTIVITÀ PRINCIPALE DELL’AZIENDA',
		'[Descrivi brevemente cosa fa l’azienda]',
		'DATI INSERITI NEL CONFIGURATORE',
		'Vorrei essere ricontattato/a per identificare il settore corretto e completare la stima del valore della mia azienda.',
		'Richiedo un approfondimento sulla stima del valore della mia azienda.',
		'Vorrei essere ricontattato/a da Deltora per approfondire questi dati.',
		'La ricerca automatica non è disponibile in questo browser.',
		'Il registro non ha restituito una risposta valida. Scegli il settore manualmente.',
		'Il registro non è al momento disponibile. Scegli il settore manualmente.',
		'Continua',
		'Indietro',
		'Dove trovo questa voce?',
		'Come vuoi procedere?',
		'Scegli in base ai dati che hai già a disposizione.',
		'Aiutami a calcolare l’EBITDA',
		'Ho i bilanci o i dati contabili, ma non conosco ancora i tre EBITDA.',
		'Inserisco gli EBITDA già calcolati',
		'Conosco già i valori di tre esercizi completi e calcolati con lo stesso criterio.',
		'Esercizio {number} di {total}',
		'Inserisci le voci del conto economico. Usa valori positivi, tranne l’utile o la perdita che può essere negativo.',
		'Anno o etichetta dell’esercizio',
		'Esempio: {value}',
		'EBITDA calcolato',
		'Inserisci i tre EBITDA',
		'Usa tre esercizi completi e valori calcolati con lo stesso criterio.',
		'Esercizio {number}',
		'Anno o etichetta',
		'Ci sono ricavi o costi eccezionali?',
		'Pensa a eventi che normalmente non si ripetono: vendita straordinaria di un bene, indennizzi, costi legali irripetibili o ristrutturazioni una tantum.',
		'No',
		'I tre esercizi rappresentano l’attività ordinaria.',
		'Sì',
		'Uno o più esercizi includono componenti non ricorrenti.',
		'Non lo so',
		'Deltora potrà verificare e normalizzare i valori.',
		'Ricerca nel registro in corso…',
		'Risultati della ricerca',
		'Seleziona',
		'Analisi dell’attività in corso…',
		'Settore confermato',
		'Settore individuato',
		'La stima userà questo settore. Puoi ancora modificarlo dall’elenco manuale.',
		'Abbiamo individuato questo settore dall’attività registrata su Zefix. È corretto?',
		'Sì, usa questo settore',
		'No, scegli un altro settore',
		'Non abbiamo individuato un settore con sufficiente certezza. Sceglilo dall’elenco qui sotto.',
		'Azienda selezionata',
		'Cerca un’altra azienda',
		'Ricerca dell’azienda',
		'Ragione sociale o UID',
		'Deltora oppure CHE-…',
		'Ricerca…',
		'Cerca',
		'Dati dal registro Zefix. Le informazioni pubbliche mostrate non hanno effetto legale.',
		'Nascondi l’elenco dei settori',
		'Preferisco scegliere il settore manualmente',
		'Qual è l’attività principale dell’azienda?',
		'La scelta del settore determina l’intervallo di multipli utilizzato per elaborare la stima indicativa.',
		'Scegli il settore',
		'Controlla i dati prima del calcolo',
		'Modalità',
		'Calcolo guidato',
		'Inserimento diretto',
		'Attività',
		'Eventi eccezionali',
		'Intervallo di multipli',
		'Disponibile dopo l’identificazione del settore',
		'Calcola la stima',
		'Ho letto {privacyLink} e acconsento al trattamento dei dati indicati per ricevere il risultato e alla loro conservazione per 12 mesi.',
		'l’informativa privacy',
		'Acconsento al trattamento dei dati indicati per ricevere il risultato e alla loro conservazione per 12 mesi.',
		'Abbiamo comunque calcolato l’EBITDA medio dei tre esercizi. Per completare la stima è necessario identificare il settore e il relativo intervallo di multipli.',
		'La stima deriva dall’EBITDA medio degli ultimi tre esercizi e dall’intervallo di multipli associato all’attività selezionata.',
		'Valore operativo indicativo',
		'Non siamo riusciti ad associare con certezza la tua attività a un settore.',
		'Contatta Deltora per identificare il settore corretto e completare la stima.',
		'Il metodo dei multipli EBITDA non produce una stima significativa.',
		'Questo non significa necessariamente che l’azienda non abbia valore: possono essere necessari altri metodi e un’analisi professionale.',
		'Stima indicativa della tua azienda',
		'Il risultato rappresenta una prima indicazione del valore operativo dell’azienda (Enterprise Value). Non include automaticamente debiti finanziari o liquidità e non costituisce una perizia, un’offerta di acquisto o una valutazione professionale definitiva. L’intervallo applicato ha finalità orientativa.',
		'Rivedi i dati',
		'Invia il risultato via email',
		'Ricevi il riepilogo via email',
		'La stima resta visibile qui anche se l’invio non dovesse riuscire.',
		'Indirizzo email',
		'Nome e cognome',
		'Azienda',
		'Telefono (facoltativo)',
		'Sito web',
		'Invia il risultato',
		'Vuoi approfondire la stima?',
		'Il contatto con Deltora è facoltativo e separato dall’invio del risultato.',
		'Contatta Deltora',
		'Passaggio {step} di {total}',
		'Scegli il percorso',
		'Inserisci almeno tre caratteri oppure un UID completo.',
		'Nessuna azienda trovata. Controlla il nome oppure scegli il settore manualmente.',
		'Scegli una modalità per continuare.',
		'Completa tutte le voci dell’esercizio prima di continuare.',
		'Ogni esercizio deve avere un anno o un’etichetta diversa.',
		'Inserisci anno ed EBITDA per tutti e tre gli esercizi.',
		'Indica se sono presenti eventi eccezionali.',
		'Cerca la tua azienda oppure scegli il settore manualmente.',
		'Seleziona l’attività principale.',
		'Invio non riuscito. Riprova.',
		'Completa i campi evidenziati prima di inviare il risultato.',
		'Invio in corso…',
		'Completa i campi evidenziati prima di continuare.',
	);
}

/**
 * Source => translation map for the configurator script.
 *
 * Only translations that differ from the source are sent, so the Italian
 * page carries no extra payload.
 *
 * @return array<string,string>
 */
function deltora_consulting_get_configurator_strings() {
	$strings = array();
	foreach ( deltora_consulting_get_configurator_ui_sources() as $source ) {
		$translated = deltora_consulting_t( $source, 'configurator' );
		if ( $translated !== $source ) {
			$strings[ $source ] = $translated;
		}
	}
	return $strings;
}

/**
 * Translate the visible texts of the public configurator configuration.
 *
 * Only labels, help texts and descriptions change: ids, keywords (used by
 * the sector classifier) and multiples stay untouched.
 *
 * @param array<string,mixed> $config Configuration passed to wp_localize_script().
 * @return array<string,mixed>
 */
function deltora_consulting_localize_configurator_config( $config ) {
	if ( ! empty( $config['guidedFields'] ) && is_array( $config['guidedFields'] ) ) {
		foreach ( $config['guidedFields'] as $index => $field ) {
			foreach ( array( 'label', 'help' ) as $key ) {
				if ( isset( $field[ $key ] ) && is_string( $field[ $key ] ) ) {
					$config['guidedFields'][ $index ][ $key ] = deltora_consulting_t( $field[ $key ], 'configurator-fields' );
				}
			}
		}
	}
	if ( ! empty( $config['sectors'] ) && is_array( $config['sectors'] ) ) {
		foreach ( $config['sectors'] as $index => $sector ) {
			$config['sectors'][ $index ] = deltora_consulting_localize_sector( $sector );
		}
	}
	$config['strings'] = deltora_consulting_get_configurator_strings();
	return $config;
}

/**
 * Translate the visible label and description of one sector.
 *
 * @param array<string,mixed> $sector Sector definition.
 * @return array<string,mixed>
 */
function deltora_consulting_localize_sector( $sector ) {
	foreach ( array( 'label', 'description' ) as $key ) {
		if ( isset( $sector[ $key ] ) && is_string( $sector[ $key ] ) && '' !== $sector[ $key ] ) {
			$sector[ $key ] = deltora_consulting_t( $sector[ $key ], 'configurator-sectors' );
		}
	}
	return $sector;
}

/**
 * URL of a Deltora page in the language of the current request.
 *
 * AJAX requests (result e-mail) run without the language prefix: the
 * plugin knows the language from the referring page, so the link is
 * rebuilt for it.
 *
 * @param string $url URL in the default language.
 * @return string
 */
function deltora_consulting_localized_url( $url ) {
	if ( function_exists( 'twtr_get_current_language' ) && function_exists( 'twtr_get_language_url' ) ) {
		$localized = twtr_get_language_url( twtr_get_current_language(), $url );
		if ( is_string( $localized ) && '' !== $localized ) {
			return $localized;
		}
	}
	return $url;
}
