(function initDeltoraConfigurator(root, factory) {
  const api = factory(root && root.DeltoraConfiguratorEngine);

  if (typeof module === 'object' && module.exports) {
    module.exports = api;
  }

  if (root) {
    root.DeltoraConfigurator = api;
  }

  if (root && root.document) {
    root.document.addEventListener('DOMContentLoaded', () => {
      const container = root.document.querySelector('[data-configurator-root]');
      if (container) api.mount(container, root.deltoraConfiguratorConfig || {});
    });
  }
}(typeof window !== 'undefined' ? window : globalThis, function createConfigurator(engine) {
  'use strict';

  // Testi dell'interfaccia. La chiave è il testo italiano; la traduzione
  // arriva da PHP in config.strings (deltora_consulting_t → tW Translate Plus).
  // Senza traduzione resta l'italiano. t() restituisce testo semplice,
  // th() testo escapato per HTML; i segnaposto {nome} ricevono valori già sicuri.
  let dictionary = {};
  const setStrings = (strings) => {
    dictionary = strings && typeof strings === 'object' ? strings : {};
  };
  const fill = (text, vars) => (vars
    ? text.replace(/\{(\w+)\}/g, (match, key) => (Object.prototype.hasOwnProperty.call(vars, key) ? String(vars[key]) : match))
    : text);
  const lookupString = (text) => (typeof dictionary[text] === 'string' && dictionary[text] !== '' ? dictionary[text] : text);
  const t = (text, vars) => fill(lookupString(text), vars);
  const htmlEscape = (value) => String(value ?? '').replace(/[&<>'"]/g, (character) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;',
  }[character]));
  const th = (text, vars) => fill(htmlEscape(lookupString(text)), vars);

  const stepsForMode = (mode) => (
    mode === 'guided'
      ? ['mode', 'guided-year-1', 'guided-year-2', 'guided-year-3', 'exceptional', 'sector', 'review', 'result']
      : ['mode', 'direct-values', 'exceptional', 'sector', 'review', 'result']
  );

  const createEmptyYear = () => ({
    label: '',
    ebitda: null,
    netIncome: null,
    taxes: null,
    financialCosts: null,
    financialIncome: null,
    tangibleDepreciation: null,
    intangibleAmortization: null,
    impairments: null,
  });

  const createEmptyCompanyLookup = () => ({
    query: '',
    results: [],
    resultsQuery: '',
    resultsPresentation: 'suggestions',
    selected: null,
    suggestion: null,
    status: 'idle',
    message: '',
    manual: false,
    confirmed: false,
  });

  const createInitialState = (mode = '') => ({
    mode: mode === 'guided' || mode === 'direct' ? mode : '',
    years: [createEmptyYear(), createEmptyYear(), createEmptyYear()],
    exceptional: '',
    sectorId: '',
    companyLookup: createEmptyCompanyLookup(),
    currentStep: 0,
    result: null,
  });

  const deriveEbitdas = (state) => state.years.map((year) => (
    state.mode === 'guided'
      ? engine.calculateAnnualEbitda(year)
      : Number(year.ebitda)
  ));

  const validateExercises = (state) => {
    const labels = state.years.map((year) => String(year.label || '').trim());
    const incompleteIndexes = [];

    state.years.forEach((year, index) => {
      const valueIsMissing = state.mode === 'direct'
        ? !Number.isFinite(Number(year.ebitda))
        : ['netIncome', 'taxes', 'financialCosts', 'financialIncome', 'tangibleDepreciation', 'intangibleAmortization', 'impairments']
          .some((key) => !Number.isFinite(Number(year[key])));

      if (!labels[index] || valueIsMissing) incompleteIndexes.push(index);
    });

    const duplicateYears = labels.filter((label, index) => (
      label && labels.indexOf(label) !== index
    ));

    return {
      valid: incompleteIndexes.length === 0 && duplicateYears.length === 0,
      duplicateYears: [...new Set(duplicateYears)],
      incompleteIndexes,
    };
  };

  const buildResult = (state, sector) => {
    const min = sector && typeof sector.min === 'number' ? sector.min : NaN;
    const max = sector && typeof sector.max === 'number' ? sector.max : NaN;
    return engine.calculateEstimate(deriveEbitdas(state), min, max);
  };

  const buildResultPayload = (state, contact, privacy, honeypot) => ({
    name: contact.name,
    company: contact.company,
    email: contact.email,
    phone: contact.phone,
    session_key: state.sessionKey,
    privacy: Boolean(privacy),
    honeypot: honeypot || '',
    mode: state.mode,
    ebitdas: deriveEbitdas(state),
    year_labels: state.years.map((year) => String(year.label)),
    exceptional: state.exceptional,
    sector_id: state.sectorId,
  });

  const getContactUrl = (config) => String(config && config.contactUrl ? config.contactUrl : '#');
  const getPrivacyUrl = (config) => String(config && config.privacyUrl ? config.privacyUrl : '');

  const createSessionKey = () => {
    if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') return crypto.randomUUID();
    return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}-${Math.random().toString(36).slice(2)}`;
  };

  const buildExceptionalWarning = (exceptional) => {
    if (exceptional === 'yes') {
      return t('Hai indicato che uno o più esercizi includono ricavi o costi eccezionali. Questi elementi possono influire sull’EBITDA medio. Contatta Deltora per verificarli e ottenere una stima più precisa.');
    }
    if (exceptional === 'unknown') {
      return t('Non sei sicuro che gli EBITDA inseriti includano ricavi o costi eccezionali. Questi elementi possono influire sull’EBITDA medio. Contatta Deltora per verificarli e ottenere una stima più precisa.');
    }
    return '';
  };

  const composeResultIntroduction = (main, alerts, explanation) => {
    const visibleAlerts = alerts.filter(Boolean);
    const alertGroup = visibleAlerts.length
      ? `<div class="deltora-result-alerts">${visibleAlerts.join('')}</div>`
      : '';
    return `${main}${alertGroup}<p>${explanation}</p>`;
  };

  const buildContactDraft = (state, sector, result, formatCurrency = (value) => engine.formatCHF(value)) => {
    const exceptionalLabels = {
      no: t('no'),
      yes: t('sì'),
      unknown: t('non sono sicuro'),
    };
    const ebitdas = deriveEbitdas(state);
    const isUnclassified = !sector || sector.id === 'other';
    const sectorLabel = isUnclassified ? t('da identificare') : sector.label;
    const calculationLines = [
      `${t('Settore')}: ${sectorLabel}`,
      ...ebitdas.map((value, index) => `EBITDA ${state.years[index].label}: ${formatCurrency(value)}`),
      `${t('EBITDA medio')}: ${formatCurrency(result.average)}`,
      `${t('Componenti straordinarie')}: ${exceptionalLabels[state.exceptional] || t('da verificare')}`,
    ];

    if (isUnclassified) {
      return [
        t('Buongiorno,'),
        t('ho utilizzato il configuratore, ma non ho trovato un settore che rappresenti correttamente la mia azienda.'),
        '',
        t('ATTIVITÀ PRINCIPALE DELL’AZIENDA'),
        t('[Descrivi brevemente cosa fa l’azienda]'),
        '',
        t('DATI INSERITI NEL CONFIGURATORE'),
        ...calculationLines,
        '',
        t('Vorrei essere ricontattato/a per identificare il settore corretto e completare la stima del valore della mia azienda.'),
      ].join('\n');
    }

    const lines = [
      t('Richiedo un approfondimento sulla stima del valore della mia azienda.'),
      '',
      ...calculationLines,
      '',
      t('Vorrei essere ricontattato/a da Deltora per approfondire questi dati.'),
    ];

    return lines.join('\n');
  };

  const getCompanyLookupStatus = (config) => ({
    enabled: Boolean(config && config.companyLookup && config.companyLookup.enabled),
    localClassifier: Boolean(config && config.companyLookup && config.companyLookup.local_classifier),
    aiEnabled: Boolean(config && config.companyLookup && config.companyLookup.ai_enabled),
  });

  const postCompanyLookup = async (config, action, fields = {}, fetcher = null, signal = null) => {
    const request = fetcher || (typeof window !== 'undefined' && window.fetch
      ? window.fetch.bind(window)
      : null);
    if (!request) throw new Error(t('La ricerca automatica non è disponibile in questo browser.'));

    const body = new URLSearchParams({
      action,
      nonce: config && config.nonce ? config.nonce : '',
      ...fields,
    });
    const requestOptions = {
      method: 'POST',
      credentials: 'same-origin',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
      body: body.toString(),
    };
    if (signal) requestOptions.signal = signal;

    const response = await request(config && config.ajaxUrl ? config.ajaxUrl : '', requestOptions);

    let json;
    try {
      json = await response.json();
    } catch (error) {
      throw new Error(t('Il registro non ha restituito una risposta valida. Scegli il settore manualmente.'));
    }
    if (!response.ok || !json.success) {
      throw new Error(json && json.data && json.data.message
        ? json.data.message
        : t('Il registro non è al momento disponibile. Scegli il settore manualmente.'));
    }
    return json.data || {};
  };

  const playViewTransition = (view, gsap, reducedMotion = false) => {
    if (!view || reducedMotion || !gsap || typeof gsap.fromTo !== 'function') return;

    gsap.fromTo(view, { autoAlpha: 0.72 }, {
      autoAlpha: 1,
      duration: 0.18,
      ease: 'power1.out',
      overwrite: true,
      clearProps: 'opacity,visibility',
    });
  };

  const validationControls = (form) => Array.from(form.querySelectorAll(
    'input[required], textarea[required], select[required], input[type="radio"]',
  ));

  const controlIsInvalid = (control, controls) => {
    if (!control || control.disabled) return false;
    if (control.closest?.('[hidden]')) return false;
    if (control.type === 'radio') {
      return !controls.some((candidate) => candidate.type === 'radio' && candidate.name === control.name && candidate.checked);
    }
    if (control.type === 'checkbox') return !control.checked;
    if (control.validity && !control.validity.valid) return true;
    if (control.getAttribute?.('inputmode') === 'decimal') return engine.parseMoney(control.value) === null;
    return !String(control.value || '').trim();
  };

  const findInvalidControls = (form) => {
    const controls = validationControls(form);
    return controls.filter((control) => controlIsInvalid(control, controls));
  };

  const setControlInvalid = (control, invalid) => {
    if (!control) return;
    if (invalid) control.setAttribute?.('aria-invalid', 'true');
    else control.removeAttribute?.('aria-invalid');
    const container = control.closest?.('.deltora-money-field__control, .deltora-wizard-option, .deltora-consent') || control;
    container.classList?.toggle('is-invalid', Boolean(invalid));
  };

  const enableInlineValidation = (form) => {
    if (!form) return;
    form.noValidate = true;
    const refresh = (event) => {
      const target = event.target;
      const controls = validationControls(form);
      if (!target || !controls.includes(target)) return;
      const group = target.type === 'radio'
        ? controls.filter((control) => control.type === 'radio' && control.name === target.name)
        : [target];
      group.forEach((control) => setControlInvalid(control, controlIsInvalid(control, controls)));
    };
    form.addEventListener('input', refresh);
    form.addEventListener('change', refresh);
  };

  const escapeHTML = htmlEscape;

  const option = (name, value, title, description, checked = false) => `
    <label class="deltora-wizard-option">
      <input type="radio" name="${name}" value="${value}" ${checked ? 'checked' : ''}>
      <span><strong>${title}</strong><small>${description}</small></span>
    </label>`;

  const actions = (showBack = true, nextLabel = th('Continua')) => `
    <div class="deltora-wizard-actions">
      ${showBack ? `<button class="deltora-button deltora-button--secondary" type="button" data-wizard-back>${th('Indietro')}</button>` : ''}
      <button class="deltora-button deltora-button--primary" type="submit">${nextLabel}</button>
    </div>`;

  const restoreConfiguratorPosition = (container, options = {}) => {
    const schedule = options.requestAnimationFrame || ((callback) => callback());
    schedule(() => {
      container.scrollIntoView?.({
        behavior: options.reducedMotion ? 'auto' : 'smooth',
        block: 'start',
      });
    });
  };

  const moneyField = (field, yearIndex, value) => `
    <div class="deltora-money-field">
      <label for="year-${yearIndex}-${field.id}">${escapeHTML(field.label)}</label>
      <div class="deltora-money-field__control"><span>CHF</span><input id="year-${yearIndex}-${field.id}" name="${field.id}" inputmode="decimal" autocomplete="off" maxlength="30" value="${escapeHTML(value ?? '')}" required></div>
      <details><summary>${th('Dove trovo questa voce?')}</summary><p>${escapeHTML(field.help)}</p></details>
    </div>`;

  const formatCompanyUid = (uid) => {
    const compact = String(uid || '').replace(/[^A-Z0-9]/gi, '').toUpperCase();
    const match = compact.match(/^CHE(\d{3})(\d{3})(\d{3})$/);
    return match ? `CHE-${match[1]}.${match[2]}.${match[3]}` : compact;
  };

  const mount = (container, config) => {
    setStrings(config && config.strings);
    const initialMode = container.dataset.initialMode || '';
    const state = createInitialState(initialMode);
    state.sessionKey = createSessionKey();
    state.startedRecorded = false;
    state.completedRecorded = false;
    if (initialMode) state.currentStep = 1;

    const view = container.querySelector('[data-configurator-view]');
    const messages = container.querySelector('[data-configurator-messages]');
    const progress = container.querySelector('[data-configurator-progress]');
    const stepLabel = container.querySelector('[data-configurator-step]');
    const changeMode = container.querySelector('[data-change-mode]');
    const reducedMotion = typeof window !== 'undefined'
      && window.matchMedia
      && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const motionEngine = typeof window !== 'undefined' ? window.gsap : null;
    const lookupStatus = getCompanyLookupStatus(config);
    let companySearchTimer = null;
    let companySearchController = null;
    let companySearchSequence = 0;
    let activeCompanyResult = -1;

    const postUsageEvent = (event) => {
      if (!config.ajaxUrl || !config.nonce || !state.sessionKey) return;
      const sector = sectorById(state.sectorId);
      const selected = state.companyLookup.selected || {};
      const body = new URLSearchParams({
        action: 'deltora_record_configurator_event',
        nonce: config.nonce,
        payload: JSON.stringify({
          event,
          session_key: state.sessionKey,
          mode: state.mode,
          sector_label: sector ? sector.label : '',
          company: { name: selected.name || '', uid: selected.uid || '' },
        }),
      });
      fetch(config.ajaxUrl, {
        method: 'POST',
        credentials: 'same-origin',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
        body: body.toString(),
      }).catch(() => {});
    };

    const sectorById = (id) => (config.sectors || []).find((sector) => sector.id === id);
    if (initialMode) {
      state.startedRecorded = true;
      postUsageEvent('started');
    }
    const showError = (message) => {
      messages.innerHTML = message ? `<p role="alert">${escapeHTML(message)}</p>` : '';
      if (message) messages.focus?.();
    };

    const currentSteps = () => (state.mode ? stepsForMode(state.mode) : ['mode']);
    const currentStepId = () => currentSteps()[Math.min(state.currentStep, currentSteps().length - 1)];

    const renderMode = () => `
      <form data-wizard-form>
        <fieldset class="deltora-wizard-fieldset">
          <legend>${th('Come vuoi procedere?')}</legend>
          <p class="deltora-wizard-intro">${th('Scegli in base ai dati che hai già a disposizione.')}</p>
          <div class="deltora-wizard-options">
            ${option('mode', 'guided', th('Aiutami a calcolare l’EBITDA'), th('Ho i bilanci o i dati contabili, ma non conosco ancora i tre EBITDA.'), state.mode === 'guided')}
            ${option('mode', 'direct', th('Inserisco gli EBITDA già calcolati'), th('Conosco già i valori di tre esercizi completi e calcolati con lo stesso criterio.'), state.mode === 'direct')}
          </div>
        </fieldset>
        ${actions(false)}
      </form>`;

    const renderGuidedYear = (yearIndex) => {
      const year = state.years[yearIndex];
      return `
        <form data-wizard-form data-year-index="${yearIndex}">
          <fieldset class="deltora-wizard-fieldset">
            <legend>${th('Esercizio {number} di {total}', { number: yearIndex + 1, total: 3 })}</legend>
            <p class="deltora-wizard-intro">${th('Inserisci le voci del conto economico. Usa valori positivi, tranne l’utile o la perdita che può essere negativo.')}</p>
            <div class="deltora-year-label"><label for="year-${yearIndex}-label">${th('Anno o etichetta dell’esercizio')}</label><input id="year-${yearIndex}-label" name="label" maxlength="40" value="${escapeHTML(year.label)}" placeholder="${th('Esempio: {value}', { value: '2025' })}" required></div>
            <div class="deltora-guided-fields">${(config.guidedFields || []).map((field) => moneyField(field, yearIndex, year[field.id])).join('')}</div>
            <div class="deltora-ebitda-live" aria-live="polite"><span>${th('EBITDA calcolato')}</span><strong data-live-ebitda>${engine.formatCHF(engine.calculateAnnualEbitda(year))}</strong></div>
          </fieldset>
          ${actions(true)}
        </form>`;
    };

    const renderDirect = () => `
      <form data-wizard-form>
        <fieldset class="deltora-wizard-fieldset">
          <legend>${th('Inserisci i tre EBITDA')}</legend>
          <p class="deltora-wizard-intro">${th('Usa tre esercizi completi e valori calcolati con lo stesso criterio.')}</p>
          <div class="deltora-direct-years">
            ${state.years.map((year, index) => `<div class="deltora-direct-year"><h3>${th('Esercizio {number}', { number: index + 1 })}</h3><label for="direct-label-${index}">${th('Anno o etichetta')}</label><input id="direct-label-${index}" name="label-${index}" maxlength="40" value="${escapeHTML(year.label)}" placeholder="202${index + 3}" required><label for="direct-value-${index}">EBITDA</label><div class="deltora-money-field__control"><span>CHF</span><input id="direct-value-${index}" name="ebitda-${index}" inputmode="decimal" maxlength="30" value="${escapeHTML(year.ebitda ?? '')}" required></div></div>`).join('')}
          </div>
        </fieldset>
        ${actions(true)}
      </form>`;

    const renderExceptional = () => `
      <form data-wizard-form>
        <fieldset class="deltora-wizard-fieldset">
          <legend>${th('Ci sono ricavi o costi eccezionali?')}</legend>
          <p class="deltora-wizard-intro">${th('Pensa a eventi che normalmente non si ripetono: vendita straordinaria di un bene, indennizzi, costi legali irripetibili o ristrutturazioni una tantum.')}</p>
          <div class="deltora-wizard-options deltora-wizard-options--compact">
            ${option('exceptional', 'no', th('No'), th('I tre esercizi rappresentano l’attività ordinaria.'), state.exceptional === 'no')}
            ${option('exceptional', 'yes', th('Sì'), th('Uno o più esercizi includono componenti non ricorrenti.'), state.exceptional === 'yes')}
            ${option('exceptional', 'unknown', th('Non lo so'), th('Deltora potrà verificare e normalizzare i valori.'), state.exceptional === 'unknown')}
          </div>
        </fieldset>
        ${actions(true)}
      </form>`;

    const renderSectorOptions = () => `
      <div class="deltora-wizard-options">
        ${(config.sectors || []).map((sector) => option('sector', sector.id, escapeHTML(sector.label), escapeHTML(sector.description), state.sectorId === sector.id)).join('')}
      </div>`;

    const companyMeta = (company) => [
      company.legal_seat,
      formatCompanyUid(company.uid),
    ].filter(Boolean).map(escapeHTML).join(' · ');

    const renderCompanyResults = () => {
      const lookup = state.companyLookup;
      if (lookup.status === 'searching') {
        return `<p class="deltora-company-lookup__status" role="status">${th('Ricerca nel registro in corso…')}</p>`;
      }
      if (lookup.status === 'error' || lookup.status === 'empty') {
        return `<p class="deltora-company-lookup__status is-error" role="status">${escapeHTML(lookup.message)}</p>`;
      }
      if (!lookup.results.length || lookup.selected) return '';

      const presentationClass = lookup.resultsPresentation === 'list' ? ' deltora-company-results--list' : '';
      return `<div class="deltora-company-results${presentationClass}" id="deltora-company-results" data-company-results role="listbox" aria-label="${th('Risultati della ricerca')}">
        ${lookup.results.map((company, index) => {
          const identifier = company.uid || company.ehraid;
          const type = company.uid ? 'uid' : 'ehraid';
          return `<button type="button" class="deltora-company-result" id="deltora-company-result-${index}" data-company-select data-company-result-index="${index}" data-identifier="${escapeHTML(identifier)}" data-type="${type}" role="option" aria-selected="false" tabindex="-1">
            <span><strong>${escapeHTML(company.name)}</strong><small>${companyMeta(company)}</small></span>
            <span class="deltora-company-result__action">${th('Seleziona')}</span>
          </button>`;
        }).join('')}
      </div>`;
    };

    const renderCompanySelection = () => {
      const lookup = state.companyLookup;
      if (lookup.status === 'selecting') {
        return `<p class="deltora-company-lookup__status" role="status">${th('Analisi dell’attività in corso…')}</p>`;
      }
      if (!lookup.selected) return '';

      const suggestion = lookup.suggestion || {};
      const proposed = !suggestion.requires_manual && suggestion.sector_label
        ? `<div class="deltora-company-selection__sector${lookup.confirmed ? ' is-confirmed' : ''}"><span>${lookup.confirmed ? th('Settore confermato') : th('Settore individuato')}</span><strong>${escapeHTML(suggestion.sector_label)}</strong>${lookup.confirmed
          ? `<p>${th('La stima userà questo settore. Puoi ancora modificarlo dall’elenco manuale.')}</p>`
          : `<p class="deltora-company-selection__question">${th('Abbiamo individuato questo settore dall’attività registrata su Zefix. È corretto?')}</p><div class="deltora-company-selection__confirmation-actions"><button class="deltora-button deltora-button--primary" type="button" data-company-confirm>${th('Sì, usa questo settore')}</button><button class="deltora-company-lookup__text-action" type="button" data-company-reject>${th('No, scegli un altro settore')}</button></div>`}</div>`
        : `<p class="deltora-company-lookup__status is-notice">${th('Non abbiamo individuato un settore con sufficiente certezza. Sceglilo dall’elenco qui sotto.')}</p>`;

      return `<div class="deltora-company-selection" data-company-selection>
        <div class="deltora-company-selection__company"><span>${th('Azienda selezionata')}</span><strong>${escapeHTML(lookup.selected.name)}</strong><small>${companyMeta(lookup.selected)}</small></div>
        ${proposed}
        <button type="button" class="deltora-company-lookup__text-action" data-company-reset>${th('Cerca un’altra azienda')}</button>
      </div>`;
    };

    const renderCompanyLookup = () => {
      const lookup = state.companyLookup;
      const inputDisabled = lookup.status === 'selecting';
      const searchDisabled = lookup.status === 'searching' || inputDisabled;
      const resultsOpen = lookup.status === 'results' && lookup.results.length > 0 && !lookup.selected;
      return `<section class="deltora-company-lookup" data-company-search aria-label="${th('Ricerca dell’azienda')}">
        <div class="deltora-company-search__controls">
          <label for="deltora-company-query">${th('Ragione sociale o UID')}</label>
          <div class="deltora-company-search__row"><div class="deltora-company-search__field"><input id="deltora-company-query" name="company_query" type="search" role="combobox" aria-autocomplete="list" aria-controls="deltora-company-results" aria-expanded="${resultsOpen ? 'true' : 'false'}" maxlength="120" autocomplete="off" spellcheck="false" value="${escapeHTML(lookup.query)}" placeholder="${th('Esempio: {value}', { value: th('Deltora oppure CHE-…') })}" ${inputDisabled ? 'disabled' : ''}><div data-company-feedback aria-live="polite">${renderCompanyResults()}</div></div><button class="deltora-button deltora-button--primary" type="button" data-company-search-submit ${searchDisabled ? 'disabled' : ''}>${lookup.status === 'searching' ? th('Ricerca…') : th('Cerca')}</button></div>
        </div>
        <p class="deltora-company-lookup__source">${th('Dati dal registro Zefix. Le informazioni pubbliche mostrate non hanno effetto legale.')}</p>
        ${renderCompanySelection()}
      </section>`;
    };

    const renderSector = () => {
      const lookup = state.companyLookup;
      const manualLabel = lookup.manual ? th('Nascondi l’elenco dei settori') : th('Preferisco scegliere il settore manualmente');
      return `<form data-wizard-form>
        <fieldset class="deltora-wizard-fieldset">
          <legend>${th('Qual è l’attività principale dell’azienda?')}</legend>
          <p class="deltora-wizard-intro">${th('La scelta del settore determina l’intervallo di multipli utilizzato per elaborare la stima indicativa.')}</p>
          ${lookupStatus.enabled ? `${renderCompanyLookup()}<button class="deltora-company-lookup__manual-toggle" type="button" data-company-manual-toggle>${manualLabel}</button><div class="deltora-company-manual" data-company-manual ${lookup.manual ? '' : 'hidden'}><h3>${th('Scegli il settore')}</h3>${renderSectorOptions()}</div>` : renderSectorOptions()}
        </fieldset>
        ${actions(true)}
      </form>`;
    };

    const resultRows = () => deriveEbitdas(state).map((value, index) => `<tr><th scope="row">EBITDA ${escapeHTML(state.years[index].label)}</th><td>${engine.formatCHF(value)}</td></tr>`).join('');

    const renderReview = () => {
      const sector = sectorById(state.sectorId);
      const preliminary = sector ? buildResult(state, sector) : null;
      return `
        <form data-wizard-form>
          <div class="deltora-wizard-fieldset">
            <h3>${th('Controlla i dati prima del calcolo')}</h3>
            <div class="deltora-review-grid">
              <table><tbody>${resultRows()}<tr><th scope="row">${th('EBITDA medio')}</th><td>${engine.formatCHF(preliminary ? preliminary.average : 0)}</td></tr></tbody></table>
              <dl><div><dt>${th('Modalità')}</dt><dd>${state.mode === 'guided' ? th('Calcolo guidato') : th('Inserimento diretto')}</dd></div><div><dt>${th('Attività')}</dt><dd>${escapeHTML(sector ? sector.label : '')}</dd></div><div><dt>${th('Eventi eccezionali')}</dt><dd>${state.exceptional === 'no' ? th('No') : (state.exceptional === 'yes' ? th('Sì') : th('Non lo so'))}</dd></div><div><dt>${th('Intervallo di multipli')}</dt><dd>${sector && sector.min !== null ? `${sector.min.toFixed(1)}x–${sector.max.toFixed(1)}x` : th('Disponibile dopo l’identificazione del settore')}</dd></div></dl>
            </div>
          </div>
          ${actions(true, th('Calcola la stima'))}
        </form>`;
    };

    const renderResult = () => {
      const sector = sectorById(state.sectorId);
      const result = state.result || buildResult(state, sector);
      const exceptionalWarning = buildExceptionalWarning(state.exceptional);
      const warning = exceptionalWarning ? `<p class="deltora-result-warning">${escapeHTML(exceptionalWarning)}</p>` : '';
      const isUnclassified = sector && sector.id === 'other';
	  const privacyUrl = getPrivacyUrl(config);
	  const privacyConsent = privacyUrl
	    ? th('Ho letto {privacyLink} e acconsento al trattamento dei dati indicati per ricevere il risultato e alla loro conservazione per 12 mesi.', { privacyLink: `<a href="${escapeHTML(privacyUrl)}">${th('l’informativa privacy')}</a>` })
	    : th('Acconsento al trattamento dei dati indicati per ricevere il risultato e alla loro conservazione per 12 mesi.');
      const resultExplanation = isUnclassified
        ? th('Abbiamo comunque calcolato l’EBITDA medio dei tre esercizi. Per completare la stima è necessario identificare il settore e il relativo intervallo di multipli.')
        : th('La stima deriva dall’EBITDA medio degli ultimi tre esercizi e dall’intervallo di multipli associato all’attività selezionata.');
      const main = result.estimable
        ? `<p class="deltora-result-range"><span>${th('Valore operativo indicativo')}</span><strong>${engine.formatCHF(result.minimum)} – ${engine.formatCHF(result.maximum)}</strong></p>`
        : '';
      const unavailableWarning = result.estimable
        ? ''
        : (isUnclassified
          ? `<p class="deltora-result-unavailable"><strong>${th('Non siamo riusciti ad associare con certezza la tua attività a un settore.')}</strong> ${th('Contatta Deltora per identificare il settore corretto e completare la stima.')}</p>`
          : `<p class="deltora-result-unavailable"><strong>${th('Il metodo dei multipli EBITDA non produce una stima significativa.')}</strong> ${th('Questo non significa necessariamente che l’azienda non abbia valore: possono essere necessari altri metodi e un’analisi professionale.')}</p>`);
      const introduction = composeResultIntroduction(main, [unavailableWarning, warning], resultExplanation);

      return `<div class="deltora-result"><h3>${th('Stima indicativa della tua azienda')}</h3>${introduction}<table><tbody>${resultRows()}<tr><th scope="row">${th('EBITDA medio')}</th><td>${engine.formatCHF(result.average)}</td></tr><tr><th scope="row">${th('Attività')}</th><td>${escapeHTML(sector ? sector.label : '')}</td></tr></tbody></table><p class="deltora-result-disclaimer">${th('Il risultato rappresenta una prima indicazione del valore operativo dell’azienda (Enterprise Value). Non include automaticamente debiti finanziari o liquidità e non costituisce una perizia, un’offerta di acquisto o una valutazione professionale definitiva. L’intervallo applicato ha finalità orientativa.')}</p><div class="deltora-wizard-actions"><button class="deltora-button deltora-button--secondary" type="button" data-wizard-back>${th('Rivedi i dati')}</button><a class="deltora-button deltora-button--primary" href="#deltora-result-email">${th('Invia il risultato via email')}</a></div>
		<section class="deltora-result-action" id="deltora-result-email"><h4>${th('Ricevi il riepilogo via email')}</h4><p>${th('La stima resta visibile qui anche se l’invio non dovesse riuscire.')}</p><form data-result-email-form><label for="result-name">${th('Nome e cognome')}</label><input id="result-name" type="text" name="name" autocomplete="name" maxlength="190" required><label for="result-company">${th('Azienda')}</label><input id="result-company" type="text" name="company" autocomplete="organization" maxlength="190" value="${escapeHTML(state.companyLookup.selected?.name || '')}" required><label for="result-email">${th('Indirizzo email')}</label><input id="result-email" type="email" name="email" autocomplete="email" spellcheck="false" maxlength="254" required><label for="result-phone">${th('Telefono (facoltativo)')}</label><input id="result-phone" type="tel" name="phone" autocomplete="tel" maxlength="64"><label class="deltora-consent"><input type="checkbox" name="privacy" required><span>${privacyConsent}</span></label><label class="deltora-honeypot" aria-hidden="true">${th('Sito web')}<input name="website" tabindex="-1" autocomplete="off"></label><button class="deltora-button deltora-button--primary" type="submit">${th('Invia il risultato')}</button><p class="deltora-form-status" data-email-status aria-live="polite"></p></form></section>
        <section class="deltora-result-action deltora-result-action--contact"><h4>${th('Vuoi approfondire la stima?')}</h4><p>${th('Il contatto con Deltora è facoltativo e separato dall’invio del risultato.')}</p><a class="deltora-button deltora-button--secondary" href="${escapeHTML(getContactUrl(config))}" data-configurator-contact>${th('Contatta Deltora')}</a></section></div>`;
    };

    const render = (restorePosition = false) => {
      showError('');
      const steps = currentSteps();
      const step = currentStepId();
      const displayStep = state.mode ? Math.max(1, state.currentStep) : 0;
      const total = state.mode ? steps.length - 1 : 1;
      stepLabel.textContent = state.mode ? t('Passaggio {step} di {total}', { step: displayStep, total }) : t('Scegli il percorso');
      progress.style.transform = `scaleX(${state.mode ? Math.max(0.08, displayStep / total) : 0.08})`;
      changeMode.hidden = !state.mode || step === 'mode' || step === 'result';

      if (step === 'mode') view.innerHTML = renderMode();
      else if (step.startsWith('guided-year-')) view.innerHTML = renderGuidedYear(Number(step.at(-1)) - 1);
      else if (step === 'direct-values') view.innerHTML = renderDirect();
      else if (step === 'exceptional') view.innerHTML = renderExceptional();
      else if (step === 'sector') view.innerHTML = renderSector();
      else if (step === 'review') view.innerHTML = renderReview();
      else view.innerHTML = renderResult();

      playViewTransition(view, motionEngine, reducedMotion);
      bindCurrentView(step);
      view.querySelector('legend, h3, input')?.focus?.({ preventScroll: true });
      if (restorePosition) {
        restoreConfiguratorPosition(container, {
          reducedMotion,
          requestAnimationFrame: typeof window !== 'undefined' && window.requestAnimationFrame
            ? window.requestAnimationFrame.bind(window)
            : undefined,
        });
      }
    };

    const readMoney = (input) => engine.parseMoney(input.value);

    const refreshSectorView = (focusSelector = '') => {
      view.innerHTML = renderSector();
      bindCurrentView('sector');
      if (focusSelector) view.querySelector(focusSelector)?.focus?.({ preventScroll: true });
    };

    const cancelPendingCompanySearch = () => {
      if (companySearchTimer) {
        clearTimeout(companySearchTimer);
        companySearchTimer = null;
      }
      if (companySearchController) {
        companySearchController.abort();
        companySearchController = null;
      }
      companySearchSequence += 1;
    };

    const bindCompanyResultButtons = () => {
      view.querySelectorAll('[data-company-select]').forEach((button) => {
        button.addEventListener('click', () => performCompanySelection(button));
        button.addEventListener('mouseenter', () => setActiveCompanyResult(Number(button.dataset.companyResultIndex)));
      });
    };

    const setActiveCompanyResult = (index) => {
      const input = view.querySelector('#deltora-company-query');
      const results = Array.from(view.querySelectorAll('[data-company-select]'));
      if (!input || !results.length) return;

      activeCompanyResult = ((index % results.length) + results.length) % results.length;
      results.forEach((result, resultIndex) => {
        result.setAttribute('aria-selected', resultIndex === activeCompanyResult ? 'true' : 'false');
      });
      input.setAttribute('aria-activedescendant', results[activeCompanyResult].id);
      results[activeCompanyResult].scrollIntoView?.({ block: 'nearest' });
    };

    const updateCompanyLookupFeedback = () => {
      const feedback = view.querySelector('[data-company-feedback]');
      const input = view.querySelector('#deltora-company-query');
      const submit = view.querySelector('[data-company-search-submit]');
      if (!feedback || !input || !submit) return;

      feedback.innerHTML = renderCompanyResults();
      activeCompanyResult = -1;
      input.removeAttribute('aria-activedescendant');
      input.setAttribute('aria-expanded', state.companyLookup.status === 'results' && state.companyLookup.results.length ? 'true' : 'false');
      submit.disabled = state.companyLookup.status === 'searching';
      submit.textContent = state.companyLookup.status === 'searching' ? t('Ricerca…') : t('Cerca');
      bindCompanyResultButtons();
    };

    const performCompanySearch = async (options = {}) => {
      const input = view.querySelector('#deltora-company-query');
      const query = String(input && input.value ? input.value : '').trim();
      cancelPendingCompanySearch();
      state.companyLookup.query = query;

      if (
        !options.automatic
        && state.companyLookup.status === 'results'
        && state.companyLookup.results.length
        && state.companyLookup.resultsQuery === query
      ) {
        state.companyLookup.resultsPresentation = 'list';
        updateCompanyLookupFeedback();
        return;
      }

      state.companyLookup.selected = null;
      state.companyLookup.suggestion = null;
      state.companyLookup.results = [];
      state.companyLookup.resultsQuery = '';
      state.companyLookup.resultsPresentation = options.automatic ? 'suggestions' : 'list';
      state.companyLookup.confirmed = false;
      state.sectorId = '';

      if (query.length < 3) {
        state.companyLookup.status = options.silentShortQuery ? 'idle' : 'error';
        state.companyLookup.message = options.silentShortQuery ? '' : t('Inserisci almeno tre caratteri oppure un UID completo.');
        updateCompanyLookupFeedback();
        return;
      }

      state.companyLookup.status = 'searching';
      state.companyLookup.message = '';
      updateCompanyLookupFeedback();
      const requestSequence = companySearchSequence;
      companySearchController = typeof AbortController === 'function' ? new AbortController() : null;
      try {
        const data = await postCompanyLookup(
          config,
          'deltora_search_companies',
          { query },
          null,
          companySearchController ? companySearchController.signal : null,
        );
        if (requestSequence !== companySearchSequence) return;
        state.companyLookup.results = Array.isArray(data.results) ? data.results : [];
        state.companyLookup.resultsQuery = query;
        state.companyLookup.status = state.companyLookup.results.length ? 'results' : 'empty';
        state.companyLookup.message = state.companyLookup.results.length
          ? ''
          : t('Nessuna azienda trovata. Controlla il nome oppure scegli il settore manualmente.');
      } catch (error) {
        if (error && error.name === 'AbortError') return;
        if (requestSequence !== companySearchSequence) return;
        state.companyLookup.status = 'error';
        state.companyLookup.message = error.message;
        if (!options.automatic) state.companyLookup.manual = true;
      }
      if (requestSequence === companySearchSequence) {
        companySearchController = null;
        updateCompanyLookupFeedback();
      }
    };

    const scheduleCompanySearch = (input) => {
      cancelPendingCompanySearch();
      const query = String(input.value || '').trim();
      state.companyLookup.query = query;
      state.companyLookup.selected = null;
      state.companyLookup.suggestion = null;
      state.companyLookup.results = [];
      state.companyLookup.resultsQuery = '';
      state.companyLookup.resultsPresentation = 'suggestions';
      state.companyLookup.confirmed = false;
      state.companyLookup.status = 'idle';
      state.companyLookup.message = '';
      state.sectorId = '';
      updateCompanyLookupFeedback();
      if (query.length < 3) return;

      companySearchTimer = setTimeout(() => {
        companySearchTimer = null;
        performCompanySearch({ automatic: true, silentShortQuery: true });
      }, 400);
    };

    const performCompanySelection = async (button) => {
      const identifier = button.dataset.identifier || '';
      const type = button.dataset.type === 'uid' ? 'uid' : 'ehraid';
      state.companyLookup.status = 'selecting';
      state.companyLookup.message = '';
      refreshSectorView();
      try {
        const data = await postCompanyLookup(config, 'deltora_select_company', { identifier, type });
        state.companyLookup.selected = data.company || null;
        state.companyLookup.suggestion = data.suggestion || null;
        state.companyLookup.status = 'selected';
        if (data.suggestion && !data.suggestion.requires_manual && data.suggestion.sector_id) {
          state.sectorId = '';
          state.companyLookup.manual = false;
          state.companyLookup.confirmed = false;
        } else {
          state.sectorId = '';
          state.companyLookup.manual = true;
          state.companyLookup.confirmed = false;
        }
      } catch (error) {
        state.companyLookup.status = 'error';
        state.companyLookup.message = error.message;
        state.companyLookup.manual = true;
      }
      refreshSectorView(state.companyLookup.selected ? '[data-company-selection]' : '#deltora-company-query');
    };

    const collectStep = (step, form) => {
      if (step === 'mode') {
        const selected = form.querySelector('input[name="mode"]:checked');
        if (!selected) return t('Scegli una modalità per continuare.');
        state.mode = selected.value;
        state.currentStep = 0;
      } else if (step.startsWith('guided-year-')) {
        const index = Number(step.at(-1)) - 1;
        const nextYear = { ...state.years[index], label: form.elements.label.value.trim() };
        let missing = !nextYear.label;
        (config.guidedFields || []).forEach((field) => {
          const value = readMoney(form.elements[field.id]);
          if (value === null) missing = true;
          nextYear[field.id] = value;
        });
        if (missing) return t('Completa tutte le voci dell’esercizio prima di continuare.');
        if (state.years.some((year, yearIndex) => yearIndex !== index && year.label && year.label === nextYear.label)) return t('Ogni esercizio deve avere un anno o un’etichetta diversa.');
        state.years[index] = nextYear;
      } else if (step === 'direct-values') {
        const years = state.years.map((year, index) => ({ label: form.elements[`label-${index}`].value.trim(), ebitda: readMoney(form.elements[`ebitda-${index}`]) }));
        state.years = years;
        const validation = validateExercises(state);
        if (!validation.valid) return validation.duplicateYears.length ? t('Ogni esercizio deve avere un anno o un’etichetta diversa.') : t('Inserisci anno ed EBITDA per tutti e tre gli esercizi.');
      } else if (step === 'exceptional') {
        const selected = form.querySelector('input[name="exceptional"]:checked');
        if (!selected) return t('Indica se sono presenti eventi eccezionali.');
        state.exceptional = selected.value;
      } else if (step === 'sector') {
        const selected = form.querySelector('input[name="sector"]:checked');
        if (!selected) return lookupStatus.enabled ? t('Cerca la tua azienda oppure scegli il settore manualmente.') : t('Seleziona l’attività principale.');
        state.sectorId = selected.value;
      } else if (step === 'review') {
        state.result = buildResult(state, sectorById(state.sectorId));
      }
      return '';
    };

    const postResultEmail = async (payload) => {
      const body = new URLSearchParams({
        action: 'deltora_send_configurator_result',
        nonce: config.nonce || '',
        payload: JSON.stringify(payload),
      });
      const response = await fetch(config.ajaxUrl, {
        method: 'POST',
        credentials: 'same-origin',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
        body: body.toString(),
      });
      const json = await response.json();
      if (!response.ok || !json.success) throw new Error(json.data?.message || t('Invio non riuscito. Riprova.'));
      return json.data.message;
    };

    const bindResultEmail = () => {
      const emailForm = view.querySelector('[data-result-email-form]');
      const status = view.querySelector('[data-email-status]');
      enableInlineValidation(emailForm);
      emailForm?.addEventListener('submit', async (event) => {
        event.preventDefault();
        const invalidControls = findInvalidControls(emailForm);
        validationControls(emailForm).forEach((control) => setControlInvalid(control, invalidControls.includes(control)));
        if (invalidControls.length) {
          status.textContent = t('Completa i campi evidenziati prima di inviare il risultato.');
          status.className = 'deltora-form-status is-error';
          invalidControls[0].focus?.();
          return;
        }
        const submit = emailForm.querySelector('button[type="submit"]');
        submit.disabled = true;
        submit.textContent = t('Invio in corso…');
        status.className = 'deltora-form-status';
        try {
          const payload = buildResultPayload(
            state,
            {
              name: emailForm.elements.name.value.trim(),
              company: emailForm.elements.company.value.trim(),
              email: emailForm.elements.email.value.trim(),
              phone: emailForm.elements.phone.value.trim(),
            },
            emailForm.elements.privacy.checked,
            emailForm.elements.website.value,
          );
          status.textContent = await postResultEmail(payload);
          status.classList.add('is-success');
        } catch (error) {
          status.textContent = error.message;
          status.classList.add('is-error');
        } finally {
          submit.disabled = false;
          submit.textContent = t('Invia il risultato');
        }
      });
    };

    const bindCurrentView = (step) => {
      const form = view.querySelector('[data-wizard-form]');
      enableInlineValidation(form);
      form?.addEventListener('submit', (event) => {
        event.preventDefault();
        const invalidControls = findInvalidControls(form);
        validationControls(form).forEach((control) => setControlInvalid(control, invalidControls.includes(control)));
        if (invalidControls.length) {
          showError(t('Completa i campi evidenziati prima di continuare.'));
          invalidControls[0].focus?.();
          return;
        }
        const error = collectStep(step, form);
        if (error) { showError(error); return; }
        state.currentStep += 1;
        if (!state.startedRecorded && state.mode) {
          state.startedRecorded = true;
          postUsageEvent('started');
        }
        render(true);
      });

      view.querySelector('[data-wizard-back]')?.addEventListener('click', () => {
        state.currentStep = Math.max(0, state.currentStep - 1);
        render(true);
      });

      if (step.startsWith('guided-year-') && form) {
        const yearIndex = Number(step.at(-1)) - 1;
        form.addEventListener('input', () => {
          const values = {};
          (config.guidedFields || []).forEach((field) => { values[field.id] = readMoney(form.elements[field.id]) || 0; });
          form.querySelector('[data-live-ebitda]').textContent = engine.formatCHF(engine.calculateAnnualEbitda(values));
          state.years[yearIndex] = { ...state.years[yearIndex], ...values, label: form.elements.label.value.trim() };
        });
      }

      if (step === 'sector' && lookupStatus.enabled) {
        const searchInput = view.querySelector('#deltora-company-query');
        view.querySelector('[data-company-search-submit]')?.addEventListener('click', performCompanySearch);
        searchInput?.addEventListener('input', () => scheduleCompanySearch(searchInput));
        searchInput?.addEventListener('keydown', (event) => {
          const results = Array.from(view.querySelectorAll('[data-company-select]'));
          if ((event.key === 'ArrowDown' || event.key === 'ArrowUp') && results.length) {
            event.preventDefault();
            setActiveCompanyResult(activeCompanyResult + (event.key === 'ArrowDown' ? 1 : -1));
            return;
          }
          if (event.key === 'Escape' && results.length && state.companyLookup.resultsPresentation === 'suggestions') {
            event.preventDefault();
            state.companyLookup.results = [];
            state.companyLookup.status = 'idle';
            updateCompanyLookupFeedback();
            return;
          }
          if (event.key !== 'Enter') return;
          event.preventDefault();
          if (activeCompanyResult >= 0 && results[activeCompanyResult]) {
            performCompanySelection(results[activeCompanyResult]);
          } else {
            performCompanySearch();
          }
        });
        bindCompanyResultButtons();
        view.querySelector('[data-company-confirm]')?.addEventListener('click', () => {
          const suggestion = state.companyLookup.suggestion || {};
          if (!suggestion.sector_id || suggestion.requires_manual) return;
          state.sectorId = suggestion.sector_id;
          state.companyLookup.confirmed = true;
          state.companyLookup.manual = false;
          refreshSectorView('[data-company-selection]');
        });
        view.querySelector('[data-company-reject]')?.addEventListener('click', () => {
          state.sectorId = '';
          state.companyLookup.confirmed = false;
          state.companyLookup.manual = true;
          refreshSectorView('input[name="sector"]');
        });
        view.querySelector('[data-company-manual-toggle]')?.addEventListener('click', () => {
          state.companyLookup.manual = !state.companyLookup.manual;
          if (state.companyLookup.manual && state.companyLookup.suggestion && state.sectorId === state.companyLookup.suggestion.sector_id) {
            state.sectorId = '';
            state.companyLookup.confirmed = false;
          }
          refreshSectorView('[data-company-manual-toggle]');
        });
        view.querySelector('[data-company-reset]')?.addEventListener('click', () => {
          state.companyLookup = { ...createEmptyCompanyLookup(), query: state.companyLookup.query };
          state.sectorId = '';
          refreshSectorView('#deltora-company-query');
        });
        form?.querySelectorAll('input[name="sector"]').forEach((control) => {
          control.addEventListener('change', () => {
            if (control.checked) {
              state.sectorId = control.value;
              state.companyLookup.confirmed = false;
            }
          });
        });
      }

      if (step === 'result') {
        if (!state.completedRecorded) {
          state.completedRecorded = true;
          postUsageEvent('completed');
        }
        bindResultEmail();
        view.querySelector('[data-configurator-contact]')?.addEventListener('click', () => {
          const sector = sectorById(state.sectorId);
          const result = state.result || buildResult(state, sector);
          const serializedDraft = JSON.stringify({
            createdAt: Date.now(),
            message: buildContactDraft(state, sector, result),
            sessionKey: state.sessionKey,
          });
          let stored = false;
          try {
            window.sessionStorage.setItem('deltoraConfiguratorContactDraft', serializedDraft);
            stored = true;
          } catch (error) {
            // Use a navigation-scoped fallback when browser storage is unavailable.
          }
          if (!stored) {
            window.name = `deltoraConfiguratorContactDraft:${serializedDraft}`;
          }
        });
      }
    };

    changeMode.addEventListener('click', () => {
      state.currentStep = 0;
      render(true);
    });

    render();
    return state;
  };

  return {
    setStrings,
    translate: t,
    translateHTML: th,
    stepsForMode,
    createInitialState,
    deriveEbitdas,
    validateExercises,
    buildResult,
    buildResultPayload,
    createSessionKey,
    getContactUrl,
    buildExceptionalWarning,
    composeResultIntroduction,
    buildContactDraft,
    getCompanyLookupStatus,
    postCompanyLookup,
    formatCompanyUid,
    playViewTransition,
    findInvalidControls,
    setControlInvalid,
    enableInlineValidation,
    restoreConfiguratorPosition,
    mount,
  };
}));
