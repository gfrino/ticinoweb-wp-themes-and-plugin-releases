<?php
/**
 * Contact page template.
 *
 * @package DeltoraConsultingChildTheme
 */

$deltora_contact   = deltora_consulting_get_contact_details();
$deltora_phone_uri = preg_replace( '/[^0-9+]/', '', $deltora_contact['phone'] );
$deltora_privacy   = get_privacy_policy_url();
$deltora_services  = deltora_consulting_get_services();
$deltora_subjects  = array();

foreach ( $deltora_services as $deltora_service ) {
	$deltora_subjects[ $deltora_service['slug'] ] = $deltora_service['title'];
}

$deltora_subjects['valore-impresa'] = __( 'Valore d’impresa', 'deltora-consulting-child-theme' );
$deltora_subjects['altra']          = __( 'Altra richiesta', 'deltora-consulting-child-theme' );
$deltora_requested_subject = isset( $_GET['argomento'] ) ? sanitize_key( wp_unslash( $_GET['argomento'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended

get_header();
?>

<main id="main-content" class="site-main deltora-contact-page">
	<section class="deltora-contact-page__intro" aria-labelledby="deltora-contact-title">
		<div class="deltora-container deltora-contact-page__grid">
			<div class="deltora-contact-page__content">
				<header class="deltora-contact-page__heading">
					<h1 id="deltora-contact-title">
						<span><?php esc_html_e( 'Parliamo della tua impresa', 'deltora-consulting-child-theme' ); ?></span>
						<em><?php esc_html_e( 'Un confronto diretto, fin dal primo contatto', 'deltora-consulting-child-theme' ); ?></em>
					</h1>
					<p><?php esc_html_e( 'Indica l’area di interesse e descrivi brevemente il contesto: le informazioni serviranno a preparare il primo riscontro.', 'deltora-consulting-child-theme' ); ?></p>
				</header>

				<div class="deltora-contact-page__details" aria-label="<?php esc_attr_e( 'Recapiti Deltora Consulting', 'deltora-consulting-child-theme' ); ?>">
					<address class="deltora-contact-page__detail">
						<span><?php esc_html_e( 'Sede principale', 'deltora-consulting-child-theme' ); ?></span>
						<strong><?php echo esc_html( $deltora_contact['address'] ); ?></strong>
					</address>
					<div class="deltora-contact-page__detail">
						<span><?php esc_html_e( 'Telefono', 'deltora-consulting-child-theme' ); ?></span>
						<a href="tel:<?php echo esc_attr( $deltora_phone_uri ); ?>"><?php echo esc_html( $deltora_contact['phone'] ); ?></a>
					</div>
					<div class="deltora-contact-page__detail">
						<span><?php esc_html_e( 'Email', 'deltora-consulting-child-theme' ); ?></span>
						<a href="mailto:<?php echo esc_attr( antispambot( $deltora_contact['email'] ) ); ?>"><?php echo esc_html( antispambot( $deltora_contact['email'] ) ); ?></a>
					</div>
				</div>
			</div>

			<form class="deltora-contact-form" data-contact-form novalidate>
				<div class="deltora-contact-form__field">
					<label for="deltora-contact-name"><?php esc_html_e( 'Nome e cognome', 'deltora-consulting-child-theme' ); ?></label>
					<input id="deltora-contact-name" name="name" type="text" autocomplete="name" maxlength="100" required>
				</div>
				<div class="deltora-contact-form__field">
					<label for="deltora-contact-company"><?php esc_html_e( 'Azienda', 'deltora-consulting-child-theme' ); ?></label>
					<input id="deltora-contact-company" name="company" type="text" autocomplete="organization" maxlength="150" required>
				</div>
				<div class="deltora-contact-form__row">
					<div class="deltora-contact-form__field">
						<label for="deltora-contact-email"><?php esc_html_e( 'Email', 'deltora-consulting-child-theme' ); ?></label>
						<input id="deltora-contact-email" name="email" type="email" autocomplete="email" maxlength="254" required>
					</div>
					<div class="deltora-contact-form__field">
						<label for="deltora-contact-phone"><?php esc_html_e( 'Telefono (facoltativo)', 'deltora-consulting-child-theme' ); ?></label>
						<input id="deltora-contact-phone" name="phone" type="tel" autocomplete="tel" maxlength="50">
					</div>
				</div>
				<div class="deltora-contact-form__field">
					<label for="deltora-contact-subject"><?php esc_html_e( 'Argomento', 'deltora-consulting-child-theme' ); ?></label>
					<select id="deltora-contact-subject" name="subject" required>
						<option value=""><?php esc_html_e( 'Seleziona un argomento', 'deltora-consulting-child-theme' ); ?></option>
						<?php foreach ( $deltora_subjects as $deltora_subject_key => $deltora_subject ) : ?>
							<option value="<?php echo esc_attr( $deltora_subject ); ?>" <?php selected( $deltora_requested_subject, $deltora_subject_key ); ?>><?php echo esc_html( $deltora_subject ); ?></option>
						<?php endforeach; ?>
					</select>
				</div>
				<div class="deltora-contact-form__field">
					<label for="deltora-contact-message"><?php esc_html_e( 'Messaggio', 'deltora-consulting-child-theme' ); ?></label>
					<textarea id="deltora-contact-message" name="message" rows="4" minlength="20" maxlength="3000" required></textarea>
				</div>

				<div class="deltora-contact-form__trap" aria-hidden="true">
					<label for="deltora-contact-website">Website</label>
					<input id="deltora-contact-website" name="honeypot" type="text" tabindex="-1" autocomplete="off">
				</div>

				<label class="deltora-contact-form__privacy">
					<input name="privacy" type="checkbox" value="1" required>
					<span>
						<?php esc_html_e( 'Ho letto l’informativa privacy e acconsento al trattamento dei dati necessari per rispondere alla richiesta e, se provengo dal configuratore, alla loro conservazione per 12 mesi.', 'deltora-consulting-child-theme' ); ?>
						<?php if ( $deltora_privacy ) : ?>
							<a href="<?php echo esc_url( $deltora_privacy ); ?>"><?php esc_html_e( 'Leggi l’informativa', 'deltora-consulting-child-theme' ); ?></a>
						<?php endif; ?>
					</span>
				</label>

				<div class="deltora-contact-form__actions">
					<button class="deltora-button deltora-contact-form__submit" type="submit">
						<span data-submit-label><?php esc_html_e( 'Invia la richiesta', 'deltora-consulting-child-theme' ); ?></span>
					</button>
					<p class="deltora-contact-form__feedback" data-contact-feedback aria-live="polite"></p>
				</div>
			</form>
		</div>
	</section>

</main>

<?php
get_footer();
