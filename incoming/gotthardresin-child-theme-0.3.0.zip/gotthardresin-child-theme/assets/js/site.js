/**
 * Gotthard Resin: menu sotto i 1024 px, visore dei lavori, barra d'azione sul telefono, preferenze dei cookie,
 * modulo «Richiedi un preventivo». Testi e indirizzi arrivano da functions.php (window.gotthardResin).
 * Nessuna libreria, nessun movimento allo scroll.
 */
(function () {
  'use strict';
  var cfg = window.gotthardResin || {};

  /* ---------- Menu sotto i 1024 px: pannello sotto la barra, si chiude con una voce, con Esc o allargando ---------- */
  var menuBtn = document.querySelector('.gtr-testata__menu');
  var menu = document.getElementById('gtr-menu');
  function setMenu(open) {
    if (!menuBtn || !menu) return;
    menu.classList.toggle('aperto', open);
    menuBtn.setAttribute('aria-expanded', open ? 'true' : 'false');
    menuBtn.setAttribute('aria-label', open ? (cfg.menuClose || 'Chiudi il menu') : (cfg.menuOpen || 'Apri il menu'));
  }
  if (menuBtn && menu) {
    menuBtn.addEventListener('click', function () { setMenu(!menu.classList.contains('aperto')); });
    menu.addEventListener('click', function (e) { if (e.target.closest('a')) setMenu(false); });
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && menu.classList.contains('aperto')) { setMenu(false); menuBtn.focus(); } });
    window.matchMedia('(min-width: 1024px)').addEventListener('change', function (m) { if (m.matches) setMenu(false); });
  }

  /* ---------- Titolo del primo schermo sempre su due righe: si parte dalla misura massima del CSS e si riduce finché
     le righe sono al massimo due (a ogni larghezza, con qualunque testo scelto nel Personalizza) ---------- */
  var titoloHero = document.querySelector('.gtr-hero__titolo');
  if (titoloHero) {
    var righeTitolo = function () {
      var cs = window.getComputedStyle(titoloHero);
      return Math.round(titoloHero.getBoundingClientRect().height / parseFloat(cs.lineHeight));
    };
    var adattaTitolo = function () {
      // Si cerca la misura più grande che tiene il titolo su due righe, tra 26 px e una volta e mezza la misura del CSS:
      // così il titolo riempie la sua colonna allo stesso modo a ogni larghezza.
      titoloHero.style.fontSize = '';
      var base = parseFloat(window.getComputedStyle(titoloHero).fontSize);
      var min = 26, max = base * 1.5, px;
      titoloHero.style.fontSize = max + 'px';
      if (righeTitolo() <= 2) return;
      while (max - min > 1) {
        px = (max + min) / 2;
        titoloHero.style.fontSize = px + 'px';
        if (righeTitolo() <= 2) min = px; else max = px;
      }
      titoloHero.style.fontSize = Math.floor(min) + 'px';
    };
    adattaTitolo();
    if (document.fonts && document.fonts.ready) document.fonts.ready.then(adattaTitolo);
    window.addEventListener('resize', adattaTitolo);
    window.gtrAdattaTitolo = adattaTitolo;
  }

  /* ---------- Mappa di Google: si carica con il consenso ai cookie di marketing del banner del parent, oppure con un
     clic sul suo bottone (consenso solo per quel contenuto). Prima resta il disegno della valle. ---------- */
  document.querySelectorAll('[data-gtr-gmappa]').forEach(function (box) {
    var carica = function () {
      if (box.querySelector('iframe')) return;
      var f = document.createElement('iframe');
      f.src = box.getAttribute('data-gtr-gmappa');
      f.title = box.getAttribute('data-gtr-titolo') || '';
      f.loading = 'lazy';
      f.referrerPolicy = 'no-referrer-when-downgrade';
      f.setAttribute('allowfullscreen', '');
      box.appendChild(f);
      box.classList.add('caricata');
    };
    var pref = {};
    try { pref = JSON.parse(decodeURIComponent((document.cookie.match(/(?:^|; )tw_cookie_preferences=([^;]*)/) || [])[1] || '%7B%7D')); } catch (e) { pref = {}; }
    if (pref.marketing) carica();
    var btn = box.querySelector('.gtr-mappa__carica');
    if (btn) btn.addEventListener('click', carica);
    var accetta = document.getElementById('tw-cookie-accept');
    if (accetta) accetta.addEventListener('click', function () { window.setTimeout(carica, 50); });
  });

  /* ---------- Testata sulla pagina iniziale: trasparente sopra la foto, piena quando arriva la sezione seguente ---------- */
  var testata = document.querySelector('.gtr-testata');
  var scena = document.querySelector('.gtr-scena');
  if (testata && scena && document.body.classList.contains('gtr-home')) {
    var dopo = scena.nextElementSibling;
    var tinta = function () {
      // Con la scena in movimento la foto si stringe subito in una cornice su fondo chiaro: la testata diventa piena presto.
      var moto = document.documentElement.classList.contains('gtr-moto');
      var sotto = (moto && window.scrollY > window.innerHeight * 0.12) || (dopo ? dopo.getBoundingClientRect().top <= testata.offsetHeight : false);
      testata.classList.toggle('gtr-testata--solida', sotto || !!(menu && menu.classList.contains('aperto')));
    };
    window.addEventListener('scroll', tinta, { passive: true });
    window.addEventListener('resize', tinta);
    if (menuBtn) menuBtn.addEventListener('click', function () { window.setTimeout(tinta, 0); });
    if (menu) menu.addEventListener('click', function () { window.setTimeout(tinta, 0); });
    tinta();
  }

  /* ---------- Visore dei lavori: la foto intera con frecce e tastiera; l'immagine nasce qui (nessun <img> vuoto) ---------- */
  var visore = document.querySelector('.gtr-visore');
  var apri = Array.prototype.slice.call(document.querySelectorAll('[data-gtr-apri]'));
  if (visore && apri.length && typeof visore.showModal === 'function') {
    var fig = visore.querySelector('figure');
    var cap = visore.querySelector('figcaption');
    var img = document.createElement('img');
    fig.insertBefore(img, cap);
    var ora = 0, daDove = null;
    var mostra = function (i) {
      ora = (i + apri.length) % apri.length;
      var src = apri[ora].querySelector('img');
      img.src = apri[ora].getAttribute('data-gtr-full') || (src && (src.currentSrc || src.src)) || '';
      img.alt = src ? src.alt : '';
      cap.textContent = src ? src.alt : '';
    };
    apri.forEach(function (b, i) { b.addEventListener('click', function () { daDove = b; mostra(i); visore.showModal(); }); });
    visore.querySelector('.gtr-visore__prec').addEventListener('click', function () { mostra(ora - 1); });
    visore.querySelector('.gtr-visore__succ').addEventListener('click', function () { mostra(ora + 1); });
    visore.querySelector('.gtr-visore__chiudi').addEventListener('click', function () { visore.close(); });
    visore.addEventListener('click', function (e) { if (e.target === visore || e.target === fig) visore.close(); });
    visore.addEventListener('keydown', function (e) { if (e.key === 'ArrowLeft') mostra(ora - 1); if (e.key === 'ArrowRight') mostra(ora + 1); });
    visore.addEventListener('close', function () { if (daDove) daDove.focus(); });
  }

  /* ---------- Barra del telefono: compare quando i bottoni del primo schermo escono dalla vista, sparisce davanti al
     modulo. Calcolo allo scorrimento (gli IntersectionObserver non scattano nelle schede in secondo piano). ---------- */
  var barra = document.querySelector('.gtr-barra');
  var azioni = document.getElementById('gtr-azioni-hero');
  var contatto = document.getElementById('contatto');
  if (barra && azioni && contatto) {
    var aggiorna = function () {
      var nascondi = azioni.getBoundingClientRect().bottom > 0 || contatto.getBoundingClientRect().top < window.innerHeight;
      barra.classList.toggle('nascosta', nascondi);
      if (nascondi) barra.setAttribute('inert', ''); else barra.removeAttribute('inert');
    };
    window.addEventListener('scroll', aggiorna, { passive: true });
    window.addEventListener('resize', aggiorna);
    aggiorna();
  }

  /* ---------- Preferenze dei cookie: il banner del parent sparisce dopo la scelta; si riapre togliendo la scelta ---------- */
  document.querySelectorAll('[data-gtr-cookies]').forEach(function (btn) {
    btn.addEventListener('click', function () {
      var expired = '=; expires=Thu, 01 Jan 1970 00:00:00 GMT; SameSite=Lax; path=';
      var path = window.location.pathname.split('/').slice(0, 2).join('/') || '/';
      document.cookie = 'tw_cookie_consent' + expired + '/';
      if (path !== '/') document.cookie = 'tw_cookie_consent' + expired + path;
      window.location.reload();
    });
  });

  /* ---------- Modulo «Richiedi un preventivo» (gestore del parent: Invii Ricevuti, reCAPTCHA, SMTP) ---------- */
  var recaptchaLoading = null;
  function loadRecaptcha() {
    if (!cfg.recaptchaKey) return Promise.resolve(null);
    if (window.grecaptcha && window.grecaptcha.execute) return Promise.resolve(window.grecaptcha);
    if (!recaptchaLoading) {
      recaptchaLoading = new Promise(function (resolve, reject) {
        var s = document.createElement('script');
        s.src = 'https://www.google.com/recaptcha/api.js?render=' + encodeURIComponent(cfg.recaptchaKey);
        s.async = true;
        s.onload = function () { window.grecaptcha.ready(function () { resolve(window.grecaptcha); }); };
        s.onerror = function () { recaptchaLoading = null; reject(new Error('recaptcha')); };
        document.head.appendChild(s);
      });
    }
    return recaptchaLoading;
  }

  document.querySelectorAll('[data-gtr-form]').forEach(function (form) {
    var status = form.querySelector('.gtr-modulo__stato');
    form.querySelectorAll('.gtr-scelta').forEach(function (p) {
      p.addEventListener('click', function () { p.setAttribute('aria-pressed', p.getAttribute('aria-pressed') === 'true' ? 'false' : 'true'); });
    });
    var button = form.querySelector('button[type="submit"]');
    // reCAPTCHA si carica solo quando il visitatore inizia a compilare, non con la pagina.
    form.addEventListener('focusin', function () { loadRecaptcha().catch(function () {}); }, { once: true });

    function say(text, kind) {
      status.textContent = text || '';
      status.className = 'gtr-modulo__stato' + (kind ? ' is-' + kind : '');
    }
    function clearErrors() {
      form.querySelectorAll('.gtr-campo.non-valido').forEach(function (f) {
        f.classList.remove('non-valido');
        var msg = f.querySelector('.gtr-errore');
        if (msg) msg.remove();
        var input = f.querySelector('input, textarea');
        if (input) { input.removeAttribute('aria-invalid'); input.removeAttribute('aria-describedby'); }
      });
    }
    function markErrors(fields) {
      var first = null;
      Object.keys(fields || {}).forEach(function (name) {
        var field = form.querySelector('[data-field="' + name + '"]');
        if (!field) return;
        field.classList.add('non-valido');
        var input = field.querySelector('input, textarea');
        var msg = document.createElement('span');
        msg.className = 'gtr-errore';
        msg.id = 'gtr-errore-' + name;
        msg.textContent = fields[name];
        field.appendChild(msg);
        if (input) { input.setAttribute('aria-invalid', 'true'); input.setAttribute('aria-describedby', msg.id); first = first || input; }
      });
      if (first) first.focus();
    }
    function localErrors() {
      var out = {};
      form.querySelectorAll('[data-field] input, [data-field] textarea').forEach(function (input) {
        if (!input.checkValidity()) out[input.closest('[data-field]').getAttribute('data-field')] = input.validationMessage;
      });
      return out;
    }

    form.addEventListener('submit', function (e) {
      e.preventDefault();
      clearErrors();
      var local = localErrors();
      if (Object.keys(local).length) { markErrors(local); say(''); return; }
      if (!navigator.onLine) { say(cfg.offline, 'error'); return; }

      button.disabled = true;
      say(cfg.sending, 'wait');
      var data = new FormData(form);
      data.set('oggetto', cfg.subject || '');
      // Le pillole scelte vanno in testa al messaggio: nel gestore del parent arrivano come testo, nessun campo nuovo.
      var scelte = Array.prototype.slice.call(form.querySelectorAll('.gtr-scelta[aria-pressed="true"]')).map(function (p) { return p.getAttribute('data-valore'); });
      if (scelte.length) data.set('messaggio', (cfg.interesse || 'Interessato a') + ': ' + scelte.join(', ') + '\n\n' + (data.get('messaggio') || ''));

      fetch(cfg.ajaxUrl + '?action=ticinoweb_form_token', { credentials: 'same-origin', cache: 'no-store' })
        .then(function (r) { return r.json(); })
        .then(function (t) {
          if (!t || !t.success) throw new Error('token');
          data.set('token', t.data.token);
          return loadRecaptcha().then(function (g) {
            return g ? g.execute(cfg.recaptchaKey, { action: 'contact' }) : '';
          }, function () { return ''; });
        })
        .then(function (rc) {
          if (rc) data.set('recaptcha_token', rc);
          return fetch(cfg.ajaxUrl, { method: 'POST', body: data, credentials: 'same-origin' });
        })
        .then(function (r) { return r.json().catch(function () { return { success: false }; }); })
        .then(function (res) {
          if (res && res.success) {
            form.reset();
            form.querySelectorAll('.gtr-scelta').forEach(function (p) { p.setAttribute('aria-pressed', 'false'); });
            say((res.data && res.data.message) || cfg.sent, 'ok');
            return;
          }
          var d = (res && res.data) || {};
          if (d.fields) markErrors(d.fields);
          say(d.message || cfg.failed, 'error');
        })
        .catch(function () { say(cfg.failed, 'error'); })
        .finally(function () { button.disabled = false; });
    });
  });

  document.documentElement.classList.add('gtr-js');
})();
