<?php
/**
 * SendGrid API integration.
 *
 * @package WPNews
 */

/**
 * SendGrid class for email sending.
 */
class WPNews_SendGrid {

	/**
	 * SendGrid API key.
	 *
	 * @var string
	 */
	private $api_key;

	/**
	 * From email address.
	 *
	 * @var string
	 */
	private $from_email;

	/**
	 * From name.
	 *
	 * @var string
	 */
	private $from_name;

	/**
	 * Constructor.
	 */
	public function __construct() {
		$options          = get_option( 'wpnews_options', array() );
		$this->api_key    = isset( $options['sendgrid_api_key'] ) ? $options['sendgrid_api_key'] : '';
		$this->from_email = isset( $options['from_email'] ) ? $options['from_email'] : get_option( 'admin_email' );
		$this->from_name  = isset( $options['from_name'] ) ? $options['from_name'] : get_option( 'blogname' );
	}

	/**
	 * Send email via SendGrid.
	 *
	 * Blacklist filtering is NOT performed here: campaign recipients are already
	 * excluded at query level by WPNews_Campaign_Manager::get_pending_recipients().
	 *
	 * @param string $to            Recipient email address.
	 * @param string $subject       Email subject.
	 * @param string $html_content  Email HTML content.
	 * @param array  $extra_headers Extra headers (name => value), e.g. List-Unsubscribe.
	 * @param array  $attachments   Attachments: array of ['path', 'filename', 'type'].
	 * @return array Result array with success status and message.
	 */
	public function send_email( $to, $subject, $html_content, $extra_headers = array(), $attachments = array() ) {
		if ( empty( $this->api_key ) ) {
			return array(
				'success' => false,
				'message' => __( 'SendGrid API key not configured.', 'wp-news' ),
			);
		}

		if ( ! WPNews_Security::is_valid_email( $to ) ) {
			return array(
				'success' => false,
				'message' => __( 'Invalid email address.', 'wp-news' ),
			);
		}

		// Prepare email data
		$email_data = array(
			'personalizations' => array(
				array(
					'to'      => array(
						array(
							'email' => $to,
						),
					),
					'subject' => $subject,
				),
			),
			'from'             => array(
				'email' => $this->from_email,
				'name'  => $this->from_name,
			),
			'content'          => array(),
		);

		// Plain-text part first (SendGrid requires text/plain before text/html).
		// Spam filters penalize HTML-only emails; a text/plain part improves inbox placement.
		$plain_text = self::html_to_plain_text( $html_content );
		if ( '' !== $plain_text ) {
			$email_data['content'][] = array(
				'type'  => 'text/plain',
				'value' => $plain_text,
			);
		}
		$email_data['content'][] = array(
			'type'  => 'text/html',
			'value' => $html_content,
		);

		// Custom headers (RFC 8058 List-Unsubscribe etc.)
		$sg_headers = array();
		if ( is_array( $extra_headers ) ) {
			foreach ( $extra_headers as $name => $value ) {
				if ( is_string( $name ) && '' !== $name && is_scalar( $value ) ) {
					$sg_headers[ $name ] = (string) $value;
				}
			}
		}
		if ( ! empty( $sg_headers ) ) {
			$email_data['headers'] = $sg_headers;
		}

		if ( ! empty( $attachments ) && is_array( $attachments ) ) {
			$email_data['attachments'] = array();
			foreach ( $attachments as $attachment ) {
				$file_path = isset( $attachment['path'] ) ? $attachment['path'] : '';
				if ( $file_path && file_exists( $file_path ) && is_readable( $file_path ) ) {
					$content = file_get_contents( $file_path );
					if ( $content !== false ) {
						$email_data['attachments'][] = array(
							'content'     => base64_encode( $content ),
							'type'        => isset( $attachment['type'] ) ? $attachment['type'] : 'application/octet-stream',
							'filename'    => isset( $attachment['filename'] ) ? $attachment['filename'] : basename( $file_path ),
							'disposition' => 'attachment',
						);
					}
				}
			}
			if ( empty( $email_data['attachments'] ) ) {
				unset( $email_data['attachments'] );
			}
		}

		// Disable SendGrid's own open/click tracking — we use our own pixel and redirect
		// Having both creates double-rewritten URLs which hurts deliverability and looks spammy
		$email_data['tracking_settings'] = array(
			'click_tracking'        => array( 'enable' => false, 'enable_text' => false ),
			'open_tracking'         => array( 'enable' => false ),
			'subscription_tracking' => array( 'enable' => false ),
			// Account-level "Google Analytics" tracking appends utm_* to every
			// link and mangles HTML-encoded query strings: off for our mail.
			'ganalytics'            => array( 'enable' => false ),
		);

		// Send request to SendGrid API (DNS + connection shared across sends, see attach_curl_share)
		self::enable_curl_share();
		$response = wp_remote_post(
			'https://api.sendgrid.com/v3/mail/send',
			array(
				'headers' => array(
					'Authorization' => 'Bearer ' . $this->api_key,
					'Content-Type'  => 'application/json',
				),
				'body'    => wp_json_encode( $email_data ),
				'timeout' => 30,
			)
		);

		if ( is_wp_error( $response ) ) {
			// Network-level failure (DNS, TLS, timeout): the transport is at fault,
			// not the recipient. The sending engine ends the batch and retries later.
			return array(
				'success'   => false,
				'message'   => $response->get_error_message(),
				'transient' => true,
			);
		}

		$status_code = wp_remote_retrieve_response_code( $response );

		if ( $status_code >= 200 && $status_code < 300 ) {
			return array(
				'success' => true,
				'message' => __( 'Email sent successfully.', 'wp-news' ),
			);
		}

		$body = wp_remote_retrieve_body( $response );
		return array(
			'success'   => false,
			/* translators: %s: raw error body returned by the SendGrid API */
			'message'   => sprintf( __( 'SendGrid API error: %s', 'wp-news' ), $body ),
			// 429 (rate limit) and 5xx are provider-side and worth a later retry.
			'transient' => ( 429 === (int) $status_code || (int) $status_code >= 500 ),
		);
	}

	/**
	 * Shared cURL handle (DNS cache + connection pool) reused by every SendGrid request
	 * of this PHP process.
	 *
	 * @var \CurlShareHandle|resource|null
	 */
	private static $curl_share = null;

	/**
	 * Whether the http_api_curl hook has been registered.
	 *
	 * @var bool
	 */
	private static $curl_share_hooked = false;

	/**
	 * Register the http_api_curl hook once per process.
	 *
	 * WordPress opens a new cURL handle for every wp_remote_post(): during a campaign
	 * batch that means one DNS lookup (a resolver thread) and one TLS handshake per
	 * email. Sharing DNS and connections between handles removes both, which is what
	 * caused "cURL error 6: getaddrinfo() thread failed to start" after ~900 sends.
	 */
	private static function enable_curl_share() {
		if ( self::$curl_share_hooked ) {
			return;
		}
		self::$curl_share_hooked = true;

		if ( ! function_exists( 'curl_share_init' ) || ! defined( 'CURL_LOCK_DATA_DNS' ) ) {
			return;
		}

		$share = curl_share_init();
		if ( ! $share ) {
			return;
		}
		curl_share_setopt( $share, CURLSHOPT_SHARE, CURL_LOCK_DATA_DNS );
		if ( defined( 'CURL_LOCK_DATA_SSL_SESSION' ) ) {
			curl_share_setopt( $share, CURLSHOPT_SHARE, CURL_LOCK_DATA_SSL_SESSION );
		}
		if ( defined( 'CURL_LOCK_DATA_CONNECT' ) ) {
			curl_share_setopt( $share, CURLSHOPT_SHARE, CURL_LOCK_DATA_CONNECT );
		}
		self::$curl_share = $share;

		add_action( 'http_api_curl', array( __CLASS__, 'attach_curl_share' ), 10, 3 );
	}

	/**
	 * Attach the shared handle to cURL requests aimed at the SendGrid API.
	 *
	 * @param resource|\CurlHandle $handle      cURL handle (by reference in core).
	 * @param array                $parsed_args Request arguments.
	 * @param string               $url         Request URL.
	 */
	public static function attach_curl_share( $handle, $parsed_args, $url ) {
		if ( ! self::$curl_share || ! is_string( $url ) ) {
			return;
		}
		$host = wp_parse_url( $url, PHP_URL_HOST );
		if ( 'api.sendgrid.com' !== $host ) {
			return;
		}
		// @codingStandardsIgnoreLine WordPress.WP.AlternativeFunctions.curl_curl_setopt
		curl_setopt( $handle, CURLOPT_SHARE, self::$curl_share );
	}

	/**
	 * Test SendGrid connection.
	 *
	 * @return array Result array with success status.
	 */
	public function test_connection() {
		if ( empty( $this->api_key ) ) {
			return array(
				'success' => false,
				'message' => __( 'SendGrid API key not configured.', 'wp-news' ),
			);
		}

		// Test with a simple API call to verify the key
		$response = wp_remote_get(
			'https://api.sendgrid.com/v3/scopes',
			array(
				'headers' => array(
					'Authorization' => 'Bearer ' . $this->api_key,
				),
				'timeout' => 15,
			)
		);

		if ( is_wp_error( $response ) ) {
			return array(
				'success' => false,
				'message' => $response->get_error_message(),
			);
		}

		$status_code = wp_remote_retrieve_response_code( $response );

		if ( 200 === $status_code ) {
			return array(
				'success' => true,
				'message' => __( 'SendGrid connection successful!', 'wp-news' ),
			);
		}

		return array(
			'success' => false,
			'message' => __( 'Invalid SendGrid API key.', 'wp-news' ),
		);
	}

	/**
	 * Convert HTML email content to a readable plain-text version.
	 *
	 * Used to generate the text/plain multipart body. Spam filters heavily
	 * penalize emails that are HTML-only.
	 *
	 * @param string $html HTML content.
	 * @return string Plain-text version.
	 */
	public static function html_to_plain_text( $html ) {
		// Remove head/style/script blocks entirely
		$text = preg_replace( '/<head[^>]*>.*?<\/head>/is', '', (string) $html );
		$text = preg_replace( '/<style[^>]*>.*?<\/style>/is', '', $text );
		$text = preg_replace( '/<script[^>]*>.*?<\/script>/is', '', $text );

		// Convert <br> and block-level elements to newlines
		$text = preg_replace( '/<br\s*\/?>/i', "\n", $text );
		$text = preg_replace( '/<\/(p|div|tr|li|h[1-6])>/i', "\n", $text );
		$text = preg_replace( '/<(p|div|tr|li|h[1-6])[^>]*>/i', "\n", $text );

		// Convert links to "text (URL)" format
		$text = preg_replace_callback( '/<a[^>]+href=["\']([^"\']+)["\'][^>]*>(.*?)<\/a>/is', function ( $m ) {
			$url   = trim( $m[1] );
			$label = trim( wp_strip_all_tags( $m[2] ) );
			if ( '' === $label || $label === $url ) {
				return $url;
			}
			return $label . ' (' . $url . ')';
		}, $text );

		// Remove remaining HTML tags
		$text = wp_strip_all_tags( $text );

		// Decode HTML entities
		$text = html_entity_decode( $text, ENT_QUOTES, 'UTF-8' );

		// Normalise whitespace: collapse multiple spaces on a line
		$text = preg_replace( '/[ \t]+/', ' ', $text );

		// Collapse 3+ consecutive newlines into 2
		$text = preg_replace( '/\n{3,}/', "\n\n", $text );

		return trim( (string) $text );
	}
}
