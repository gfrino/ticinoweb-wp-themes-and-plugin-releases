<?php
/**
 * Define the internationalization functionality.
 *
 * @package WPNews
 */

/**
 * Define the internationalization functionality.
 */
class WPNews_I18n {

	/**
	 * Load the plugin text domain for translation.
	 */
	public function load_plugin_textdomain() {
		load_plugin_textdomain(
			'wp-news',
			false,
			dirname( dirname( plugin_basename( __FILE__ ) ) ) . '/languages/'
		);
	}
}
