<?php
/**
 * Language bridge: WPML, tW Translate Plus, or plain WordPress.
 *
 * The visitor's language is captured where it is known (the page with the
 * signup form, the checkout), stored with the subscriber and restored for
 * everything that happens later outside that page: the AJAX reply, the
 * confirmation email, its link and the confirmation / unsubscribe pages.
 *
 * @package WPNews
 */

if (!defined('ABSPATH')) {
	exit;
}

/**
 * Language helpers.
 */
class WPNews_Language
{

	/** @var array Stack of states saved by switch_to(). */
	private static $stack = array();

	/** @var string Locale forced while switched ('' = none). */
	private static $forced = '';

	/**
	 * Filter callback: while switched, our locale wins over the language
	 * plugin's own `locale` / `determine_locale` filters (tW Translate forces
	 * the URL language there, which would keep the AJAX language).
	 *
	 * @param string $locale Locale.
	 * @return string
	 */
	public static function force_locale($locale)
	{
		return '' !== self::$forced ? self::$forced : $locale;
	}

	/**
	 * Which multilingual plugin drives the site.
	 *
	 * @return string wpml|twtr|none
	 */
	public static function provider()
	{
		if (defined('ICL_SITEPRESS_VERSION') && has_filter('wpml_current_language')) {
			return 'wpml';
		}
		if (function_exists('twtr_get_current_language') && function_exists('twtr_get_languages')) {
			return 'twtr';
		}
		return 'none';
	}

	/**
	 * Current language code ('' when the site is not multilingual).
	 *
	 * @return string
	 */
	public static function current()
	{
		switch (self::provider()) {
			case 'wpml':
				return sanitize_key((string) apply_filters('wpml_current_language', null));
			case 'twtr':
				return sanitize_key((string) twtr_get_current_language());
		}
		return '';
	}

	/**
	 * Active languages: code => locale.
	 *
	 * @return array
	 */
	public static function languages()
	{
		$out = array();
		switch (self::provider()) {
			case 'wpml':
				foreach ((array) apply_filters('wpml_active_languages', null, array('skip_missing' => 0)) as $code => $l) {
					$out[sanitize_key((string) $code)] = (string) ($l['default_locale'] ?? '');
				}
				break;
			case 'twtr':
				foreach ((array) twtr_get_languages(false) as $slug => $l) {
					$out[sanitize_key((string) ($l['slug'] ?? $slug))] = (string) ($l['locale'] ?? '');
				}
				break;
		}
		return $out;
	}

	/**
	 * A language code coming from a request, kept only if active.
	 *
	 * @param mixed $code Raw value.
	 * @return string
	 */
	public static function sanitize($code)
	{
		$code = sanitize_key((string) $code);
		return ('' !== $code && array_key_exists($code, self::languages())) ? $code : '';
	}

	/**
	 * Switch the request (gettext and, with WPML, its language) to $code.
	 * Always pair with restore().
	 *
	 * @param string $code Language code ('' = no change).
	 */
	public static function switch_to($code)
	{
		$code      = self::sanitize($code);
		$languages = self::languages();
		$state     = array('code' => '', 'locale' => false, 'forced' => self::$forced);
		if ('' !== $code) {
			if ('wpml' === self::provider()) {
				$state['code'] = self::current();
				do_action('wpml_switch_language', $code);
			}
			$locale = $languages[$code] ?? '';
			if ('' !== $locale) {
				self::$forced = $locale;
				add_filter('locale', array(__CLASS__, 'force_locale'), PHP_INT_MAX);
				add_filter('determine_locale', array(__CLASS__, 'force_locale'), PHP_INT_MAX);
				if (function_exists('switch_to_locale')) {
					$state['locale'] = switch_to_locale($locale);
				}
				// Reload our strings in the new language.
				unload_textdomain('wp-news', true);
				load_plugin_textdomain('wp-news', false, dirname(plugin_basename(WPNEWS_PLUGIN_FILE)) . '/languages');
				$state['reload'] = true;
			}
		}
		self::$stack[] = $state;
	}

	/**
	 * Undo the last switch_to().
	 */
	public static function restore()
	{
		$state = array_pop(self::$stack);
		if (!$state) {
			return;
		}
		if (!empty($state['locale']) && function_exists('restore_previous_locale')) {
			restore_previous_locale();
		}
		self::$forced = $state['forced'];
		if ('' === self::$forced) {
			remove_filter('locale', array(__CLASS__, 'force_locale'), PHP_INT_MAX);
			remove_filter('determine_locale', array(__CLASS__, 'force_locale'), PHP_INT_MAX);
		}
		if (!empty($state['reload'])) {
			unload_textdomain('wp-news', true);
			load_plugin_textdomain('wp-news', false, dirname(plugin_basename(WPNEWS_PLUGIN_FILE)) . '/languages');
		}
		if ('' !== $state['code']) {
			do_action('wpml_switch_language', $state['code']);
		}
	}

	/**
	 * Home URL in a given language (for confirm / unsubscribe links).
	 *
	 * @param string $code Language code.
	 * @return string
	 */
	public static function home_url($code)
	{
		$home = home_url('/');
		$code = self::sanitize($code);
		if ('' === $code) {
			return $home;
		}
		switch (self::provider()) {
			case 'wpml':
				return (string) apply_filters('wpml_permalink', $home, $code, true);
			case 'twtr':
				return function_exists('twtr_get_language_url') ? (string) twtr_get_language_url($code, $home) : $home;
		}
		return $home;
	}

	/**
	 * Translate a text saved in the settings (e.g. the checkout checkbox).
	 * Registered for translation in WPML → String Translation by
	 * register_string(); tW Translate translates it with its own engine.
	 *
	 * @param string $text Original (default language).
	 * @param string $name Unique string name.
	 * @return string
	 */
	public static function translate_option($text, $name)
	{
		if ('' === trim((string) $text)) {
			return (string) $text;
		}
		switch (self::provider()) {
			case 'wpml':
				return (string) apply_filters('wpml_translate_single_string', $text, 'wp-news', $name, self::current());
			case 'twtr':
				return function_exists('twtr_translate') ? (string) twtr_translate($text, 'wp-news ' . $name) : $text;
		}
		return (string) $text;
	}

	/**
	 * Register a settings text for WPML String Translation.
	 *
	 * @param string $name  Unique string name.
	 * @param string $value Text.
	 */
	public static function register_string($name, $value)
	{
		if ('' !== trim((string) $value)) {
			do_action('wpml_register_single_string', 'wp-news', $name, (string) $value);
		}
	}
}
