<?php
/**
 * Campaign scheduler functionality.
 *
 * @package WPNews
 */

/**
 * Scheduler class for handling scheduled campaigns.
 *
 * Runs on the `wpnews_send_scheduled_campaigns` cron hook. It never sends
 * inline: due campaigns are marked `sending` and the actual work is delegated
 * to the `wpnews_send_campaign_async` single event processed by WP-Cron.
 */
class WPNews_Scheduler {

	/**
	 * Minutes after which a `sending` campaign without progress is considered stuck.
	 */
	const STUCK_AFTER_MINUTES = 10;

	/**
	 * Process scheduled campaigns.
	 *
	 * - Every due campaign (status `scheduled`, schedule_at <= now) is marked `sending`
	 *   with counters reset; only ONE new campaign per run gets a worker scheduled
	 *   immediately, the others are picked up by the recovery step on later runs.
	 * - Recovery: `sending` parents not updated for STUCK_AFTER_MINUTES (DB-side
	 *   comparison), without an active lock and without a pending async event,
	 *   get a new async event.
	 */
	public function process_scheduled_campaigns() {
		global $wpdb;

		$table = $wpdb->prefix . 'wpnews_campaigns';

		// 1. Due campaigns -> 'sending'
		$due_ids = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT id FROM $table
				 WHERE status = 'scheduled'
				   AND schedule_at IS NOT NULL
				   AND schedule_at <= %s
				   AND (parent_id IS NULL OR parent_id = 0)
				 ORDER BY schedule_at ASC
				 LIMIT 20",
				current_time( 'mysql' )
			)
		);

		if ( ! empty( $due_ids ) ) {
			$due_ids  = array_map( 'intval', $due_ids );
			$ids_list = implode( ',', $due_ids );

			$wpdb->query(
				"UPDATE $table
				 SET status = 'sending', total_recipients = 0, sent_count = 0
				 WHERE id IN ($ids_list) AND status = 'scheduled'"
			);

			// Max one new campaign per run
			WPNews_Campaign_Manager::schedule_next_batch( $due_ids[0] );
		}

		// 2. Recovery of stuck campaigns
		$stuck_ids = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT id FROM $table
				 WHERE status = 'sending'
				   AND (parent_id IS NULL OR parent_id = 0)
				   AND updated_at < NOW() - INTERVAL %d MINUTE
				 ORDER BY updated_at ASC
				 LIMIT 5",
				self::STUCK_AFTER_MINUTES
			)
		);

		foreach ( (array) $stuck_ids as $stuck_id ) {
			$stuck_id = (int) $stuck_id;

			if ( WPNews_Campaign_Manager::is_locked( $stuck_id ) ) {
				continue; // a worker is active
			}
			if ( wp_next_scheduled( 'wpnews_send_campaign_async', array( $stuck_id ) ) ) {
				continue; // already queued, waiting for cron
			}

			error_log( sprintf( 'WPNEWS: campaign #%d looks stuck in "sending", re-scheduling a worker.', $stuck_id ) );
			WPNews_Campaign_Manager::schedule_next_batch( $stuck_id );
		}
	}
}
