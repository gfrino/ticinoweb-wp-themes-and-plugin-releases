<?php
/**
 * Amazon SES API integration.
 *
 * @package WPNews
 */

/**
 * Amazon SES class for email sending.
 */
class WPNews_SES
{

    private $region;
    private $access_key;
    private $secret_key;
    private $from_email;
    private $from_name;

    /**
     * Constructor.
     */
    public function __construct($region = null, $access_key = null, $secret_key = null)
    {
        $options = get_option('wpnews_options', array());
        $this->region = $region !== null ? $region : (isset($options['ses_region']) ? $options['ses_region'] : 'eu-central-1');
        $this->access_key = $access_key !== null ? $access_key : (isset($options['ses_access_key']) ? $options['ses_access_key'] : '');
        $this->secret_key = $secret_key !== null ? $secret_key : (isset($options['ses_secret_key']) ? $options['ses_secret_key'] : '');
        $this->from_email = isset($options['from_email']) ? $options['from_email'] : get_option('admin_email');
        $this->from_name = isset($options['from_name']) ? $options['from_name'] : get_option('blogname');
    }

    /**
     * Generate AWS Signature Version 4
     *
     * @param string $host         Host header value.
     * @param string $uri          Request URI path.
     * @param string $method       HTTP method.
     * @param string $payload      Request body.
     * @param string $service      AWS service name.
     * @param string $content_type Optional Content-Type to include in signed headers.
     */
    private function create_signature($host, $uri, $method, $payload, $service = 'ses', $content_type = '')
    {
        $algorithm = 'AWS4-HMAC-SHA256';
        $amzdate = gmdate('Ymd\THis\Z');
        $datestamp = gmdate('Ymd');

        // Step 1: Create canonical request
        $canonical_uri = $uri;
        $canonical_querystring = '';

        if ($content_type) {
            $canonical_headers = "content-type:" . $content_type . "\nhost:" . $host . "\nx-amz-date:" . $amzdate . "\n";
            $signed_headers = 'content-type;host;x-amz-date';
        } else {
            $canonical_headers = "host:" . $host . "\nx-amz-date:" . $amzdate . "\n";
            $signed_headers = 'host;x-amz-date';
        }

        $payload_hash = hash('sha256', $payload);
        $canonical_request = $method . "\n" . $canonical_uri . "\n" . $canonical_querystring . "\n" . $canonical_headers . "\n" . $signed_headers . "\n" . $payload_hash;

        // Step 2: Create string to sign
        $credential_scope = $datestamp . '/' . $this->region . '/' . $service . '/aws4_request';
        $string_to_sign = $algorithm . "\n" . $amzdate . "\n" . $credential_scope . "\n" . hash('sha256', $canonical_request);

        // Step 3: Calculate signature
        $k_secret = 'AWS4' . $this->secret_key;
        $k_date = hash_hmac('sha256', $datestamp, $k_secret, true);
        $k_region = hash_hmac('sha256', $this->region, $k_date, true);
        $k_service = hash_hmac('sha256', $service, $k_region, true);
        $k_signing = hash_hmac('sha256', 'aws4_request', $k_service, true);
        $signature = hash_hmac('sha256', $string_to_sign, $k_signing);

        // Step 4: Add signature to authorization header
        $authorization_header = $algorithm . ' Credential=' . $this->access_key . '/' . $credential_scope . ', SignedHeaders=' . $signed_headers . ', Signature=' . $signature;

        return array(
            'Authorization' => $authorization_header,
            'X-Amz-Date' => $amzdate,
        );
    }

    /**
     * Send email via AWS SES API v2.
     *
     * When extra headers (List-Unsubscribe) or attachments are present the message is
     * built as a raw MIME document (multipart/mixed > multipart/alternative) and sent
     * through Content.Raw. Otherwise the Simple content type (Text + Html parts) is used.
     *
     * Blacklist filtering is NOT performed here: campaign recipients are already
     * excluded at query level by WPNews_Campaign_Manager::get_pending_recipients().
     *
     * @param string $to            Recipient email address.
     * @param string $subject       Email subject.
     * @param string $html_content  Email HTML content.
     * @param array  $extra_headers Extra headers (name => value).
     * @param array  $attachments   Attachments: array of ['path', 'filename', 'type'].
     * @return array Result array with success status and message.
     */
    public function send_email($to, $subject, $html_content, $extra_headers = array(), $attachments = array())
    {
        if (empty($this->access_key) || empty($this->secret_key)) {
            return array(
                'success' => false,
                'message' => __('Amazon SES credentials not configured.', 'wp-news'),
            );
        }

        if (!WPNews_Security::is_valid_email($to)) {
            return array(
                'success' => false,
                'message' => __('Invalid email address.', 'wp-news'),
            );
        }

        $host = 'email.' . $this->region . '.amazonaws.com';
        $uri = '/v2/email/outbound-emails';

        $from_formatted = $this->format_from_header();
        $text_content = class_exists('WPNews_SendGrid')
            ? WPNews_SendGrid::html_to_plain_text($html_content)
            : trim(wp_strip_all_tags($html_content));

        $extra_headers = is_array($extra_headers) ? $extra_headers : array();
        $attachments = is_array($attachments) ? $attachments : array();

        if (!empty($extra_headers) || !empty($attachments)) {
            $raw = $this->build_raw_message($from_formatted, $to, $subject, $text_content, $html_content, $extra_headers, $attachments);
            if (is_wp_error($raw)) {
                return array(
                    'success' => false,
                    'message' => $raw->get_error_message(),
                );
            }
            $payload_array = array(
                'FromEmailAddress' => $from_formatted,
                'Destination' => array(
                    'ToAddresses' => array($to),
                ),
                'Content' => array(
                    'Raw' => array(
                        'Data' => base64_encode($raw),
                    ),
                ),
            );
        } else {
            $body = array(
                'Html' => array(
                    'Data' => $html_content,
                    'Charset' => 'UTF-8',
                ),
            );
            if ('' !== $text_content) {
                $body['Text'] = array(
                    'Data' => $text_content,
                    'Charset' => 'UTF-8',
                );
            }
            $payload_array = array(
                'FromEmailAddress' => $from_formatted,
                'Destination' => array(
                    'ToAddresses' => array($to),
                ),
                'Content' => array(
                    'Simple' => array(
                        'Subject' => array(
                            'Data' => $subject,
                            'Charset' => 'UTF-8',
                        ),
                        'Body' => $body,
                    ),
                ),
            );
        }

        $payload = wp_json_encode($payload_array);
        $auth_headers = $this->create_signature($host, $uri, 'POST', $payload);

        $response = wp_remote_post(
            'https://' . $host . $uri,
            array(
                'headers' => array(
                    'Authorization' => $auth_headers['Authorization'],
                    'X-Amz-Date' => $auth_headers['X-Amz-Date'],
                    'Content-Type' => 'application/json',
                ),
                'body' => $payload,
                'timeout' => 30,
            )
        );

        if (is_wp_error($response)) {
            return array(
                'success' => false,
                'message' => $response->get_error_message(),
            );
        }

        $status_code = wp_remote_retrieve_response_code($response);

        if ($status_code >= 200 && $status_code < 300) {
            return array(
                'success' => true,
                'message' => __('Email sent successfully via Amazon SES.', 'wp-news'),
            );
        }

        $body = wp_remote_retrieve_body($response);
        $err = json_decode($body, true);
        $error_msg = (is_array($err) && isset($err['message'])) ? $err['message'] : $body;
        return array(
            'success' => false,
            /* translators: %s: error message returned by the Amazon SES API */
            'message' => sprintf(__('Amazon SES API error: %s', 'wp-news'), $error_msg),
        );
    }

    /**
     * Build the From header, RFC 2047-encoding the display name when needed.
     *
     * @return string
     */
    private function format_from_header()
    {
        $name = trim((string) $this->from_name);
        if ('' === $name) {
            return $this->from_email;
        }
        $name = self::sanitize_header_value($name);
        if (preg_match('/[^\x20-\x7E]/', $name)) {
            $name = '=?UTF-8?B?' . base64_encode($name) . '?=';
        } else {
            $name = '"' . addcslashes($name, '"\\') . '"';
        }
        return $name . ' <' . $this->from_email . '>';
    }

    /**
     * Strip CR/LF (header injection) from a header value.
     *
     * @param string $value
     * @return string
     */
    private static function sanitize_header_value($value)
    {
        return trim(str_replace(array("\r", "\n", "\0"), '', (string) $value));
    }

    /**
     * Build a raw MIME message (multipart/mixed > multipart/alternative).
     *
     * @param string $from          Formatted From header value.
     * @param string $to            Recipient address.
     * @param string $subject       Subject.
     * @param string $text          Plain-text part.
     * @param string $html          HTML part.
     * @param array  $extra_headers Additional headers (name => value).
     * @param array  $attachments   Attachments: array of ['path', 'filename', 'type'].
     * @return string|WP_Error Raw MIME string.
     */
    private function build_raw_message($from, $to, $subject, $text, $html, $extra_headers, $attachments)
    {
        $eol = "\r\n";
        $mixed_boundary = 'wpnews-mixed-' . bin2hex(random_bytes(12));
        $alt_boundary = 'wpnews-alt-' . bin2hex(random_bytes(12));

        $reserved = array('from', 'to', 'subject', 'mime-version', 'content-type', 'content-transfer-encoding', 'date', 'message-id');

        $headers = array();
        $headers[] = 'From: ' . $from;
        $headers[] = 'To: ' . $to;
        $headers[] = 'Subject: =?UTF-8?B?' . base64_encode(self::sanitize_header_value($subject)) . '?=';
        $headers[] = 'MIME-Version: 1.0';
        foreach ($extra_headers as $name => $value) {
            if (!is_string($name) || !is_scalar($value)) {
                continue;
            }
            $name = preg_replace('/[^A-Za-z0-9\-]/', '', $name);
            if ('' === $name || in_array(strtolower($name), $reserved, true)) {
                continue;
            }
            $headers[] = $name . ': ' . self::sanitize_header_value((string) $value);
        }

        // Prepare attachment parts first so we can fail early on unreadable files.
        $attachment_parts = array();
        foreach ($attachments as $attachment) {
            $path = isset($attachment['path']) ? $attachment['path'] : '';
            if ('' === $path || !file_exists($path) || !is_readable($path)) {
                return new WP_Error('wpnews_attachment_unreadable', __('An attachment could not be read.', 'wp-news'));
            }
            $data = file_get_contents($path);
            if (false === $data) {
                return new WP_Error('wpnews_attachment_unreadable', __('An attachment could not be read.', 'wp-news'));
            }
            $filename = isset($attachment['filename']) && '' !== $attachment['filename'] ? $attachment['filename'] : basename($path);
            $filename = str_replace(array('"', "\r", "\n", "\\"), '', $filename);
            $type = isset($attachment['type']) && preg_match('#^[a-z0-9.+\-]+/[a-z0-9.+\-]+$#i', $attachment['type'])
                ? $attachment['type']
                : 'application/octet-stream';

            $attachment_parts[] = 'Content-Type: ' . $type . '; name="' . $filename . '"' . $eol
                . 'Content-Disposition: attachment; filename="' . $filename . '"' . $eol
                . 'Content-Transfer-Encoding: base64' . $eol . $eol
                . chunk_split(base64_encode($data), 76, $eol);
        }

        $headers[] = 'Content-Type: multipart/mixed; boundary="' . $mixed_boundary . '"';

        $message = implode($eol, $headers) . $eol . $eol;

        // Body: multipart/alternative (text + html)
        $message .= '--' . $mixed_boundary . $eol;
        $message .= 'Content-Type: multipart/alternative; boundary="' . $alt_boundary . '"' . $eol . $eol;

        if ('' !== trim((string) $text)) {
            $message .= '--' . $alt_boundary . $eol;
            $message .= 'Content-Type: text/plain; charset=UTF-8' . $eol;
            $message .= 'Content-Transfer-Encoding: base64' . $eol . $eol;
            $message .= chunk_split(base64_encode($text), 76, $eol);
        }

        $message .= '--' . $alt_boundary . $eol;
        $message .= 'Content-Type: text/html; charset=UTF-8' . $eol;
        $message .= 'Content-Transfer-Encoding: base64' . $eol . $eol;
        $message .= chunk_split(base64_encode($html), 76, $eol);
        $message .= '--' . $alt_boundary . '--' . $eol;

        foreach ($attachment_parts as $part) {
            $message .= $eol . '--' . $mixed_boundary . $eol . $part;
        }

        $message .= $eol . '--' . $mixed_boundary . '--' . $eol;

        return $message;
    }

    /**
     * Test AWS SES connection.
     *
     * @return array Result array with success status.
     */
    public function test_connection()
    {
        if (empty($this->access_key) || empty($this->secret_key)) {
            return array(
                'success' => false,
                'message' => __('Amazon SES credentials not configured.', 'wp-news'),
            );
        }

        $host = 'email.' . $this->region . '.amazonaws.com';
        $uri = '/v2/email/identities';
        $payload = '';
        $auth_headers = $this->create_signature($host, $uri, 'GET', $payload);

        $response = wp_remote_get(
            'https://' . $host . $uri,
            array(
                'headers' => array(
                    'Authorization' => $auth_headers['Authorization'],
                    'X-Amz-Date' => $auth_headers['X-Amz-Date'],
                ),
                'timeout' => 15,
            )
        );

        if (is_wp_error($response)) {
            return array(
                'success' => false,
                'message' => $response->get_error_message(),
            );
        }

        $status_code = wp_remote_retrieve_response_code($response);

        if (200 === $status_code) {
            return array(
                'success' => true,
                'message' => __('Amazon SES connection successful!', 'wp-news'),
            );
        }

        $body = wp_remote_retrieve_body($response);
        $err = json_decode($body, true);
        $error_msg = (is_array($err) && isset($err['message'])) ? $err['message'] : $body;
        return array(
            'success' => false,
            /* translators: %s: error message returned by the Amazon SES API */
            'message' => sprintf(__('Amazon SES validation failed: %s', 'wp-news'), $error_msg),
        );
    }

    /**
     * Check the SNS notification configuration status for verified SES identities.
     * Uses SES v1 API exclusively (form-encoded POST) to avoid URI encoding signature issues.
     *
     * @return array Result with identity notification statuses.
     */
    public function get_notification_status()
    {
        if (empty($this->access_key) || empty($this->secret_key)) {
            return array(
                'success' => false,
                'message' => __('Amazon SES credentials not configured.', 'wp-news'),
            );
        }

        $options = get_option('wpnews_options', array());
        $from_email = isset($options['from_email']) ? $options['from_email'] : '';

        if (empty($from_email)) {
            return array(
                'success' => false,
                'message' => __('From Email not configured in Settings.', 'wp-news'),
            );
        }

        $host = 'email.' . $this->region . '.amazonaws.com';
        $uri = '/';
        $content_type = 'application/x-www-form-urlencoded';

        // Step 1: Get verification status via v1 API
        $payload_verify = 'Action=GetIdentityVerificationAttributes'
            . '&Identities.member.1=' . rawurlencode($from_email)
            . '&Version=2010-12-01';

        $auth_verify = $this->create_signature($host, $uri, 'POST', $payload_verify, 'ses', $content_type);

        $response_verify = wp_remote_post(
            'https://' . $host . $uri,
            array(
                'headers' => array(
                    'Authorization' => $auth_verify['Authorization'],
                    'X-Amz-Date' => $auth_verify['X-Amz-Date'],
                    'Content-Type' => $content_type,
                ),
                'body' => $payload_verify,
                'timeout' => 15,
            )
        );

        $verified = false;
        if (!is_wp_error($response_verify) && wp_remote_retrieve_response_code($response_verify) === 200) {
            $xml = @simplexml_load_string(wp_remote_retrieve_body($response_verify));
            if ($xml) {
                $ns = $xml->getNamespaces(true);
                $xml->registerXPathNamespace('ses', reset($ns) ?: 'http://ses.amazonaws.com/doc/2010-12-01/');
                $status_nodes = $xml->xpath('//ses:VerificationStatus');
                if (empty($status_nodes)) {
                    $status_nodes = $xml->xpath('//VerificationStatus');
                }
                if (!empty($status_nodes)) {
                    $verified = ((string) $status_nodes[0]) === 'Success';
                }
            }
        } else {
            $err_body = is_wp_error($response_verify) ? $response_verify->get_error_message() : wp_remote_retrieve_body($response_verify);
            return array(
                'success' => false,
                /* translators: %s: error message returned by the Amazon SES API */
                'message' => sprintf(__('SES API error: %s', 'wp-news'), $err_body),
            );
        }

        // Step 2: Get notification attributes via v1 API
        $notifications = array(
            'delivery' => array('enabled' => false, 'topic' => ''),
            'bounce' => array('enabled' => false, 'topic' => ''),
            'complaint' => array('enabled' => false, 'topic' => ''),
        );

        $payload_notif = 'Action=GetIdentityNotificationAttributes'
            . '&Identities.member.1=' . rawurlencode($from_email)
            . '&Version=2010-12-01';

        $auth_notif = $this->create_signature($host, $uri, 'POST', $payload_notif, 'ses', $content_type);

        $response_notif = wp_remote_post(
            'https://' . $host . $uri,
            array(
                'headers' => array(
                    'Authorization' => $auth_notif['Authorization'],
                    'X-Amz-Date' => $auth_notif['X-Amz-Date'],
                    'Content-Type' => $content_type,
                ),
                'body' => $payload_notif,
                'timeout' => 15,
            )
        );

        if (!is_wp_error($response_notif) && wp_remote_retrieve_response_code($response_notif) === 200) {
            $xml = @simplexml_load_string(wp_remote_retrieve_body($response_notif));
            if ($xml) {
                $ns = $xml->getNamespaces(true);
                $xml->registerXPathNamespace('ses', reset($ns) ?: 'http://ses.amazonaws.com/doc/2010-12-01/');

                $entries = $xml->xpath('//ses:entry');
                if (empty($entries)) {
                    $entries = $xml->xpath('//entry');
                }

                foreach ((array) $entries as $entry) {
                    $value = isset($entry->value) ? $entry->value : null;
                    if (!$value) {
                        continue;
                    }

                    $bounce_topic = (string) ($value->BounceTopic ?? '');
                    $complaint_topic = (string) ($value->ComplaintTopic ?? '');
                    $delivery_topic = (string) ($value->DeliveryTopic ?? '');

                    $notifications['bounce']['enabled'] = !empty($bounce_topic);
                    $notifications['bounce']['topic'] = $bounce_topic;
                    $notifications['complaint']['enabled'] = !empty($complaint_topic);
                    $notifications['complaint']['topic'] = $complaint_topic;
                    $notifications['delivery']['enabled'] = !empty($delivery_topic);
                    $notifications['delivery']['topic'] = $delivery_topic;
                }
            }
        }

        return array(
            'success' => true,
            'identity' => $from_email,
            'verified' => $verified,
            'notifications' => $notifications,
        );
    }
}
