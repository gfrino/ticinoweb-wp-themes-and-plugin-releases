<?php
/**
 * Fired during plugin activation.
 *
 * @package WPNews
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 */
class WPNews_Activator
{

	/**
	 * Activation hook.
	 *
	 * @since    1.0.0
	 * @param bool $network_wide True if plugin is network activated.
	 */
	public static function activate($network_wide = false)
	{
		if (is_multisite() && $network_wide) {
			// Network activation: set up every existing site
			$site_ids = get_sites(array('fields' => 'ids', 'number' => 0));
			foreach ($site_ids as $site_id) {
				switch_to_blog((int) $site_id);
				self::activate_site();
				restore_current_blog();
			}
		} else {
			self::activate_site();
		}
	}

	/**
	 * Set up the CURRENT site: tables, cron event, HMAC secret.
	 *
	 * Also used for DB upgrades (WPNews_Plugin::check_version) and for new
	 * sites created while the plugin is network-active (`wp_initialize_site`).
	 */
	public static function activate_site()
	{
		self::create_tables();

		// Schedule the campaign scheduler cron event (every minute; the real
		// system cron decides how often WP-Cron is actually executed).
		if (!wp_next_scheduled('wpnews_send_scheduled_campaigns')) {
			wp_schedule_event(time(), 'every_minute', 'wpnews_send_scheduled_campaigns');
		}

		// Generate a secret key for HMAC-signed tokens (once)
		if (!get_option('wpnews_unsubscribe_secret')) {
			add_option('wpnews_unsubscribe_secret', bin2hex(random_bytes(32)), '', false);
		}
	}

	/**
	 * Remove duplicate (campaign_id, subscriber_id) rows from campaign_stats,
	 * keeping the lowest id. Required before the UNIQUE KEY can be added.
	 */
	private static function dedupe_campaign_stats()
	{
		global $wpdb;
		$stats_table = $wpdb->prefix . 'wpnews_campaign_stats';

		if ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $stats_table)) !== $stats_table) {
			return;
		}

		// Skip when the unique key already exists (nothing to dedupe).
		$has_unique = $wpdb->get_var("SHOW INDEX FROM $stats_table WHERE Key_name = 'campaign_subscriber'");
		if ($has_unique) {
			return;
		}

		$deleted = $wpdb->query(
			"DELETE s1 FROM $stats_table s1
			 INNER JOIN $stats_table s2
			   ON s1.campaign_id = s2.campaign_id
			  AND s1.subscriber_id = s2.subscriber_id
			  AND s1.id > s2.id"
		);

		if ($deleted) {
			error_log(sprintf('WPNEWS: removed %d duplicate campaign_stats rows before adding the unique key.', (int) $deleted));
		}
	}

	/**
	 * Create/upgrade database tables for the current blog.
	 */
	private static function create_tables()
	{
		global $wpdb;

		$charset_collate = $wpdb->get_charset_collate();

		// Create subscribers table
		$subscribers_table = $wpdb->prefix . 'wpnews_subscribers';
		$sql_subscribers = "CREATE TABLE $subscribers_table (
			id bigint(20) NOT NULL AUTO_INCREMENT,
			email varchar(255) NOT NULL,
			first_name varchar(100) DEFAULT '',
			last_name varchar(100) DEFAULT '',
			status varchar(20) DEFAULT 'active',
			lang varchar(10) DEFAULT '',
			subscribed_at datetime DEFAULT CURRENT_TIMESTAMP,
			unsubscribed_at datetime DEFAULT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY email (email),
			KEY status (status)
		) $charset_collate;";

		// Create lists table
		$lists_table = $wpdb->prefix . 'wpnews_lists';
		$sql_lists = "CREATE TABLE $lists_table (
			id bigint(20) NOT NULL AUTO_INCREMENT,
			name varchar(255) NOT NULL,
			description text,
			created_at datetime DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY  (id)
		) $charset_collate;";

		// Create subscriber_lists table (many-to-many)
		$subscriber_lists_table = $wpdb->prefix . 'wpnews_subscriber_lists';
		$sql_subscriber_lists = "CREATE TABLE $subscriber_lists_table (
			id bigint(20) NOT NULL AUTO_INCREMENT,
			subscriber_id bigint(20) NOT NULL,
			list_id bigint(20) NOT NULL,
			subscribed_at datetime DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY  (id),
			UNIQUE KEY subscriber_list (subscriber_id, list_id),
			KEY subscriber_id (subscriber_id),
			KEY list_id (list_id)
		) $charset_collate;";

		// Create blacklist table
		$blacklist_table = $wpdb->prefix . 'wpnews_blacklist';
		$sql_blacklist = "CREATE TABLE $blacklist_table (
			id bigint(20) NOT NULL AUTO_INCREMENT,
			email varchar(255) NOT NULL,
			reason text,
			blacklisted_at datetime DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY  (id),
			UNIQUE KEY email (email)
		) $charset_collate;";

		// Create campaigns table
		$campaigns_table = $wpdb->prefix . 'wpnews_campaigns';
		$sql_campaigns = "CREATE TABLE $campaigns_table (
			id bigint(20) NOT NULL AUTO_INCREMENT,
			parent_id bigint(20) DEFAULT NULL,
			name varchar(255) NOT NULL,
			subject varchar(255) NOT NULL,
			content longtext NOT NULL,
			blocks_json longtext DEFAULT NULL,
			status varchar(20) DEFAULT 'draft',
			schedule_at datetime DEFAULT NULL,
			is_recurring tinyint(1) DEFAULT 0,
			recurring_interval varchar(20) DEFAULT NULL,
			recurring_day varchar(20) DEFAULT NULL,
			send_if_new tinyint(1) DEFAULT 0,
			total_recipients bigint(20) DEFAULT 0,
			sent_count bigint(20) DEFAULT 0,
			failed_count bigint(20) DEFAULT 0,
			sent_at datetime DEFAULT NULL,
			created_at datetime DEFAULT CURRENT_TIMESTAMP,
			updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
			PRIMARY KEY  (id),
			KEY parent_id (parent_id),
			KEY status (status),
			KEY schedule_at (schedule_at)
		) $charset_collate;";

		// Create campaign_lists table
		$campaign_lists_table = $wpdb->prefix . 'wpnews_campaign_lists';
		$sql_campaign_lists = "CREATE TABLE $campaign_lists_table (
			id bigint(20) NOT NULL AUTO_INCREMENT,
			campaign_id bigint(20) NOT NULL,
			list_id bigint(20) NOT NULL,
			PRIMARY KEY  (id),
			KEY campaign_id (campaign_id),
			KEY list_id (list_id)
		) $charset_collate;";

		// Create campaign_stats table
		$stats_table = $wpdb->prefix . 'wpnews_campaign_stats';
		$sql_stats = "CREATE TABLE $stats_table (
			id bigint(20) NOT NULL AUTO_INCREMENT,
			campaign_id bigint(20) NOT NULL,
			subscriber_id bigint(20) NOT NULL,
			sent_at datetime DEFAULT NULL,
			opened_at datetime DEFAULT NULL,
			clicked_at datetime DEFAULT NULL,
			delivered_at datetime DEFAULT NULL,
			bounced tinyint(1) DEFAULT 0,
			PRIMARY KEY  (id),
			UNIQUE KEY campaign_subscriber (campaign_id,subscriber_id),
			KEY campaign_id (campaign_id),
			KEY subscriber_id (subscriber_id),
			KEY subscriber_sent (subscriber_id,sent_at)
		) $charset_collate;";

		// Create campaign_clicks table (for tracking specific URLs clicked)
		$clicks_table = $wpdb->prefix . 'wpnews_campaign_clicks';
		$sql_clicks = "CREATE TABLE $clicks_table (
			id bigint(20) NOT NULL AUTO_INCREMENT,
			campaign_id bigint(20) NOT NULL,
			subscriber_id bigint(20) NOT NULL,
			url text NOT NULL,
			clicked_at datetime DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY  (id),
			KEY campaign_id (campaign_id),
			KEY subscriber_id (subscriber_id)
		) $charset_collate;";

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		// Upgrade routine: duplicates must go before the unique key is added
		self::dedupe_campaign_stats();

		dbDelta($sql_subscribers);
		dbDelta($sql_lists);
		dbDelta($sql_subscriber_lists);
		dbDelta($sql_blacklist);
		dbDelta($sql_campaigns);
		dbDelta($sql_campaign_lists);
		dbDelta($sql_stats);
		dbDelta($sql_clicks);

		// Create default options
		if (!get_option('wpnews_options')) {
			$default_options = array(
				'mailer_type' => 'sendgrid',
				'sendgrid_api_key' => '',
				'from_email' => get_option('admin_email'),
				'from_name' => get_option('blogname'),
				'double_optin' => true,
				'unsubscribe_page_id' => 0,
				'enable_auto_emails' => true,
				'sending_frequency' => 0,
				'webhook_secret' => '',
				'sns_topic_arn' => '',
			);
			add_option('wpnews_options', $default_options);
		}

		// Set transient for activation notice
		set_transient('wpnews_activation_notice', true, 5);
	}
}
