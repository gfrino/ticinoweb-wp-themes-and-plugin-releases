<?php
/**
 * Built-in anti-spam for the public signup form. No captcha and no external
 * service: nothing about the visitor leaves the site.
 *
 * Layers (on top of the honeypot, rate limits and signed list id):
 *  1. Proof of work: the browser fetches a signed challenge (uncached AJAX, so
 *     it works on cached pages) and searches a nonce whose SHA-256 has N
 *     leading zero bits. Scripts that post without running JavaScript fail;
 *     the ones that do run it pay CPU time for every signup.
 *  2. Timing + single use: a challenge is valid from MIN_AGE to MAX_AGE
 *     seconds after it was issued and can be used once.
 *  3. Email: the domain must accept mail (MX/A record) and must not be a
 *     known disposable-address provider.
 *  4. Content: names with links or markup are rejected.
 *
 * Bots get a fake "thank you" (they learn nothing); blocked attempts are
 * counted per reason and shown in Settings.
 *
 * @package WPNews
 */

if (!defined('ABSPATH')) {
	exit;
}

/**
 * Anti-spam checks.
 */
class WPNews_Antispam
{

	const MIN_AGE   = 2;            // Seconds: faster than any human fill-in.
	const MAX_AGE   = 7200;         // Seconds: challenge lifetime.
	const STATS_OPT = 'wpnews_antispam_stats';

	/**
	 * Proof-of-work difficulty (leading zero bits). 12 ≈ 4k hashes on
	 * average: a fraction of a second on a phone, invisible because it runs
	 * while the visitor types. Filter `wpnews_pow_bits` to tune (10-20).
	 *
	 * @return int
	 */
	public static function bits()
	{
		return max(8, min(22, (int) apply_filters('wpnews_pow_bits', 12)));
	}

	/**
	 * Whether proof of work is required (Settings, default on).
	 *
	 * @return bool
	 */
	public static function pow_enabled()
	{
		$o = get_option('wpnews_options', array());
		return !is_array($o) || !array_key_exists('antispam_pow', $o) || (bool) $o['antispam_pow'];
	}

	/**
	 * AJAX (public): issue a signed challenge.
	 */
	public static function ajax_challenge()
	{
		$ip_key = 'wpnews_rl_ch_' . md5(self::client_ip());
		$count  = (int) get_transient($ip_key);
		if ($count >= 40) {
			wp_send_json_error(array('message' => __('Too many requests. Please try again in a few minutes.', 'wp-news')), 429);
		}
		set_transient($ip_key, $count + 1, 10 * MINUTE_IN_SECONDS);

		nocache_headers();
		do_action('litespeed_control_set_nocache', 'wpnews challenge');

		$payload = base64_encode(wp_json_encode(array(
			't' => time(),
			's' => bin2hex(random_bytes(12)),
			'b' => self::bits(),
		)));

		wp_send_json_success(array(
			'c'   => $payload,
			'sig' => WPNews_Security::sign('pow:' . $payload),
		));
	}

	/**
	 * Verify the proof of work sent with the form.
	 *
	 * @param string $payload Challenge (base64 JSON).
	 * @param string $sig     HMAC of the challenge.
	 * @param string $nonce   Solution found by the browser.
	 * @return string '' when valid, otherwise the reason code.
	 */
	public static function verify_pow($payload, $sig, $nonce)
	{
		if ('' === $payload || '' === $sig || '' === $nonce) {
			return 'no_js';
		}
		if (!WPNews_Security::verify('pow:' . $payload, $sig)) {
			return 'bad_token';
		}
		$data = json_decode((string) base64_decode($payload, true), true);
		if (!is_array($data) || empty($data['t']) || empty($data['s']) || empty($data['b'])) {
			return 'bad_token';
		}
		$age = time() - (int) $data['t'];
		if ($age < self::MIN_AGE) {
			return 'too_fast';
		}
		if ($age > self::MAX_AGE) {
			return 'expired';
		}
		if (!preg_match('/^[0-9]{1,12}$/', $nonce) || !self::has_leading_zero_bits(hash('sha256', $data['s'] . ':' . $nonce, true), (int) $data['b'])) {
			return 'bad_pow';
		}
		$used_key = 'wpnews_pow_' . md5((string) $data['s']);
		if (get_transient($used_key)) {
			return 'replay';
		}
		set_transient($used_key, 1, self::MAX_AGE);
		return '';
	}

	/**
	 * @param string $raw  Binary hash.
	 * @param int    $bits Required leading zero bits.
	 * @return bool
	 */
	private static function has_leading_zero_bits($raw, $bits)
	{
		$full = intdiv($bits, 8);
		for ($i = 0; $i < $full; $i++) {
			if ("\0" !== $raw[$i]) {
				return false;
			}
		}
		$rest = $bits % 8;
		return 0 === $rest || 0 === (ord($raw[$full]) >> (8 - $rest));
	}

	/**
	 * Email checks that a human can fix: returns a message, or '' when OK.
	 *
	 * @param string $email Sanitised address.
	 * @return string
	 */
	public static function email_problem($email)
	{
		$domain = strtolower((string) substr(strrchr($email, '@'), 1));
		if ('' === $domain) {
			return __('Invalid email address.', 'wp-news');
		}
		if (in_array($domain, self::disposable_domains(), true)) {
			self::count('disposable');
			return __('Please use a permanent email address, not a temporary one.', 'wp-news');
		}
		if (!self::domain_accepts_mail($domain)) {
			self::count('no_mx');
			return __('This email domain does not seem to receive email. Please check the address.', 'wp-news');
		}
		return '';
	}

	/**
	 * MX (or A) record lookup, cached for a day per domain.
	 *
	 * @param string $domain Domain.
	 * @return bool
	 */
	private static function domain_accepts_mail($domain)
	{
		if (!function_exists('checkdnsrr')) {
			return true;
		}
		$key    = 'wpnews_mx_' . md5($domain);
		$cached = get_transient($key);
		if (false !== $cached) {
			return 'y' === $cached;
		}
		$ok = checkdnsrr($domain . '.', 'MX') || checkdnsrr($domain . '.', 'A');
		set_transient($key, $ok ? 'y' : 'n', DAY_IN_SECONDS);
		return $ok;
	}

	/**
	 * Names with links or markup are typical of spam bots.
	 *
	 * @param string ...$values Raw field values.
	 * @return bool
	 */
	public static function looks_like_spam(...$values)
	{
		foreach ($values as $v) {
			$v = (string) $v;
			if (strlen($v) > 80 || preg_match('~(https?:|www\.|://|<|>|\[url|\.(ru|cn|xyz|top)\b)~i', $v)) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Known disposable-address providers. Filter `wpnews_disposable_domains`.
	 *
	 * @return string[]
	 */
	public static function disposable_domains()
	{
		$list = array(
			'mailinator.com', 'guerrillamail.com', 'guerrillamail.net', 'guerrillamail.org', 'sharklasers.com', 'grr.la',
			'10minutemail.com', '10minutemail.net', 'temp-mail.org', 'tempmail.com', 'tempmail.net', 'tempmailo.com',
			'yopmail.com', 'yopmail.fr', 'yopmail.net', 'trashmail.com', 'trashmail.de', 'trashmail.net', 'getnada.com',
			'nada.email', 'dispostable.com', 'maildrop.cc', 'mintemail.com', 'mohmal.com', 'emailondeck.com',
			'throwawaymail.com', 'fakeinbox.com', 'mailnesia.com', 'mailcatch.com', 'mytemp.email', 'tempr.email',
			'discard.email', 'spamgourmet.com', 'spambox.us', 'mailpoof.com', 'burnermail.io', 'tempinbox.com',
			'emailfake.com', 'fakemail.net', 'moakt.com', 'tmail.ws', 'tmpmail.org', 'tmpmail.net', 'inboxkitten.com',
			'mail-temp.com', 'dropmail.me', 'temp-mail.io', 'luxusmail.org', 'mailsac.com', 'harakirimail.com',
			'33mail.com', 'jetable.org', 'mvrht.net', 'wegwerfmail.de', 'wegwerfemail.de', 'einrot.com', 'spam4.me',
			'0box.eu', 'cuvox.de', 'armyspy.com', 'dayrep.com', 'fleckens.hu', 'gustr.com', 'jourrapide.com',
			'rhyta.com', 'superrito.com', 'teleworm.us', 'mailforspam.com', 'kurzepost.de', 'objectmail.com',
		);
		return array_map('strtolower', (array) apply_filters('wpnews_disposable_domains', $list));
	}

	/**
	 * Count a blocked attempt (per reason, per day; last 60 days kept).
	 *
	 * @param string $reason Reason code.
	 */
	public static function count($reason)
	{
		$stats = get_option(self::STATS_OPT, array());
		$stats = is_array($stats) ? $stats : array();
		$day   = gmdate('Y-m-d');
		$stats[$day][$reason] = (int) ($stats[$day][$reason] ?? 0) + 1;
		ksort($stats);
		$stats = array_slice($stats, -60, null, true);
		update_option(self::STATS_OPT, $stats, false);
	}

	/**
	 * Blocked attempts in the last $days days, by reason.
	 *
	 * @param int $days Days.
	 * @return array reason => count
	 */
	public static function totals($days = 30)
	{
		$stats  = get_option(self::STATS_OPT, array());
		$since  = gmdate('Y-m-d', time() - $days * DAY_IN_SECONDS);
		$totals = array();
		foreach ((array) $stats as $day => $reasons) {
			if ($day < $since) {
				continue;
			}
			foreach ((array) $reasons as $r => $n) {
				$totals[$r] = ($totals[$r] ?? 0) + (int) $n;
			}
		}
		arsort($totals);
		return $totals;
	}

	/**
	 * Human label of a reason code.
	 *
	 * @param string $reason Code.
	 * @return string
	 */
	public static function reason_label($reason)
	{
		$labels = array(
			'honeypot'   => __('Hidden trap field filled in', 'wp-news'),
			'no_js'      => __('Sent without running the page (script)', 'wp-news'),
			'bad_token'  => __('Forged or altered security token', 'wp-news'),
			'bad_pow'    => __('Security check not solved', 'wp-news'),
			'too_fast'   => __('Sent faster than a human can type', 'wp-news'),
			'expired'    => __('Page left open too long (expired)', 'wp-news'),
			'replay'     => __('Security token reused', 'wp-news'),
			'content'    => __('Links or code in the name fields', 'wp-news'),
			'disposable' => __('Temporary (disposable) email address', 'wp-news'),
			'no_mx'      => __('Email domain does not receive mail', 'wp-news'),
			'rate_ip'    => __('Too many attempts from the same address', 'wp-news'),
		);
		return $labels[$reason] ?? $reason;
	}

	/**
	 * @return string
	 */
	private static function client_ip()
	{
		$ip = isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR'])) : '';
		return '' !== $ip ? $ip : 'unknown';
	}
}
