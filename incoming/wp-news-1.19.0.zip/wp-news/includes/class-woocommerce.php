<?php
/**
 * WooCommerce checkout opt-in: a "Subscribe to our newsletter" checkbox on the
 * checkout; customers who tick it join the default newsletter list.
 *
 * Classic checkout (shortcode / Elementor Pro Checkout widget) and the block
 * checkout (WooCommerce additional checkout fields, WC 8.9+) are supported.
 *
 * Settings (wpnews_options): woo_checkout_optin (default on),
 * woo_checkout_prechecked (default off), woo_checkout_label; the target list
 * is signup_list_id ("Default newsletter list").
 *
 * @package WPNews
 */

if (!defined('ABSPATH')) {
	exit;
}

/**
 * WooCommerce integration.
 */
class WPNews_WooCommerce
{

	const FIELD      = 'wpnews_newsletter_optin';
	const BLOCK_ID   = 'wp-news/newsletter';
	const DONE_META  = '_wpnews_optin_done';

	/**
	 * Hook everything when WooCommerce is active and the option is on.
	 */
	public static function init()
	{
		if (!class_exists('WooCommerce') || !self::enabled()) {
			return;
		}

		// Classic checkout.
		add_action('woocommerce_review_order_before_submit', array(__CLASS__, 'render_checkbox'));
		add_action('woocommerce_checkout_order_processed', array(__CLASS__, 'classic_order_processed'), 20, 3);

		// Block checkout.
		add_action('woocommerce_init', array(__CLASS__, 'register_block_field'));
		add_action('woocommerce_store_api_checkout_order_processed', array(__CLASS__, 'blocks_order_processed'));
	}

	/**
	 * @return array
	 */
	private static function options()
	{
		$o = get_option('wpnews_options', array());
		return is_array($o) ? $o : array();
	}

	/**
	 * Option is ON unless explicitly disabled.
	 *
	 * @return bool
	 */
	public static function enabled()
	{
		$o = self::options();
		return !array_key_exists('woo_checkout_optin', $o) || (bool) $o['woo_checkout_optin'];
	}

	/**
	 * Checkbox text shown at checkout.
	 *
	 * @return string
	 */
	public static function label()
	{
		$o     = self::options();
		$label = isset($o['woo_checkout_label']) ? trim((string) $o['woo_checkout_label']) : '';
		// Custom text: translatable in WPML → String Translation / by tW Translate.
		return '' !== $label ? WPNews_Language::translate_option($label, 'woo_checkout_label') : __('Subscribe to our newsletter', 'wp-news');
	}

	/**
	 * Target list: the default newsletter list.
	 *
	 * @return int
	 */
	public static function list_id()
	{
		$o  = self::options();
		$id = !empty($o['signup_list_id']) ? absint($o['signup_list_id']) : 0;
		return ($id && WPNews_List_Manager::get_list($id)) ? $id : 0;
	}

	/**
	 * Classic checkout: checkbox above the "Place order" button.
	 */
	public static function render_checkbox()
	{
		if (!self::list_id()) {
			return;
		}
		$o       = self::options();
		$checked = !empty($o['woo_checkout_prechecked']);
		if (isset($_POST[self::FIELD])) { // phpcs:ignore WordPress.Security.NonceVerification.Missing -- re-render after a failed validation
			$checked = true;
		}
		?>
		<p class="form-row wpnews-checkout-optin">
			<label class="woocommerce-form__label woocommerce-form__label-for-checkbox checkbox">
				<input type="checkbox" class="woocommerce-form__input woocommerce-form__input-checkbox input-checkbox" name="<?php echo esc_attr(self::FIELD); ?>" value="1" <?php checked($checked); ?>>
				<span><?php echo esc_html(self::label()); ?></span>
			</label>
		</p>
		<?php
	}

	/**
	 * Classic checkout: subscribe after the order is created.
	 * WooCommerce has already verified the checkout nonce at this point.
	 *
	 * @param int      $order_id    Order ID.
	 * @param array    $posted_data Posted checkout data.
	 * @param WC_Order $order       Order.
	 */
	public static function classic_order_processed($order_id, $posted_data, $order)
	{
		if (empty($_POST[self::FIELD])) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
			return;
		}
		if (!$order instanceof WC_Order) {
			$order = wc_get_order($order_id);
		}
		if ($order) {
			self::subscribe_from_order($order);
		}
	}

	/**
	 * Block checkout: register an optional checkbox in the order section.
	 */
	public static function register_block_field()
	{
		if (!function_exists('woocommerce_register_additional_checkout_field') || !self::list_id()) {
			return;
		}
		try {
			woocommerce_register_additional_checkout_field(array(
				'id'       => self::BLOCK_ID,
				'label'    => self::label(),
				'location' => 'order',
				'type'     => 'checkbox',
				'optional' => true,
			));
		} catch (Exception $e) {
			// Field already registered or API changed: the classic hook still works.
		}
	}

	/**
	 * Block checkout: read the checkbox stored with the order.
	 *
	 * @param WC_Order $order Order.
	 */
	public static function blocks_order_processed($order)
	{
		if (!$order instanceof WC_Order) {
			return;
		}
		$value = $order->get_meta('_wc_other/' . self::BLOCK_ID);
		if (!empty($value) && 'false' !== $value && '0' !== (string) $value) {
			self::subscribe_from_order($order);
		}
	}

	/**
	 * Add the customer to the default newsletter list.
	 *
	 * Ticking the box at checkout is explicit consent and the address comes
	 * from a real order, so the subscriber is active without a confirmation
	 * email. Blacklisted, unsubscribed or bounced addresses are never
	 * re-subscribed automatically.
	 *
	 * @param WC_Order $order Order.
	 * @return bool True when the customer was added.
	 */
	public static function subscribe_from_order($order)
	{
		if ($order->get_meta(self::DONE_META)) {
			return false;
		}
		$list_id = self::list_id();
		$email   = WPNews_Security::sanitize_email($order->get_billing_email());
		if (!$list_id || '' === $email || !WPNews_Security::is_valid_email($email) || WPNews_Blacklist_Manager::is_blacklisted($email)) {
			return false;
		}

		global $wpdb;
		$table      = $wpdb->prefix . 'wpnews_subscribers';
		$first_name = WPNews_Security::sanitize_text($order->get_billing_first_name());
		$last_name  = WPNews_Security::sanitize_text($order->get_billing_last_name());
		$subscriber = $wpdb->get_row($wpdb->prepare("SELECT id, status, first_name, last_name FROM $table WHERE email = %s", $email));

		if ($subscriber) {
			if (in_array((string) $subscriber->status, array('unsubscribed', 'bounced', 'complained', 'blacklisted'), true)) {
				return false;
			}
			$data = array('status' => 'active');
			if ('' === (string) $subscriber->first_name && '' !== $first_name) {
				$data['first_name'] = $first_name;
			}
			if ('' === (string) $subscriber->last_name && '' !== $last_name) {
				$data['last_name'] = $last_name;
			}
			$wpdb->update($table, $data, array('id' => (int) $subscriber->id));
			$subscriber_id = (int) $subscriber->id;
		} else {
			$lang = WPNews_Language::sanitize($order->get_meta('wpml_language') ?: WPNews_Language::current());
			$wpdb->insert(
				$table,
				array(
					'email'      => $email,
					'first_name' => $first_name,
					'last_name'  => $last_name,
					'status'     => 'active',
					'lang'       => $lang,
				),
				array('%s', '%s', '%s', '%s', '%s')
			);
			$subscriber_id = (int) $wpdb->insert_id;
		}

		if (!$subscriber_id) {
			return false;
		}

		WPNews_List_Manager::add_subscriber_to_list($subscriber_id, $list_id);
		$order->update_meta_data(self::DONE_META, current_time('mysql'));
		$order->add_order_note(__('Customer subscribed to the newsletter at checkout (WP News).', 'wp-news'));
		$order->save();
		return true;
	}
}
