<?php
/**
 * SendGrid Event Webhook Handler.
 *
 * Receives delivery, bounce, dropped, and spam-report notifications from
 * SendGrid's Event Webhook and updates campaign stats / blacklist accordingly.
 *
 * SendGrid sends a JSON **array** of event objects in each POST request.
 *
 * Authentication: at least one of the following MUST be configured in
 * `wpnews_options`, otherwise every request is rejected with 403:
 *  - `sendgrid_webhook_key`: SendGrid "Signed Event Webhook" public key (ECDSA,
 *    verified together with a +/-5 minute timestamp window);
 *  - `webhook_secret`: shared secret passed as `?key=` in the webhook URL.
 *
 * @package WPNews
 */

if (!defined('ABSPATH')) {
    exit;
}

class WPNews_SendGrid_Webhook
{

    /**
     * Accepted clock skew for the signed timestamp (seconds).
     */
    const MAX_TIMESTAMP_SKEW = 300;

    /**
     * Register public REST endpoint for SendGrid Event Webhook.
     */
    public static function register_routes()
    {
        register_rest_route('wp-news/v1', '/sendgrid-webhook', array(
            'methods'             => 'POST',
            'callback'            => array(__CLASS__, 'handle_events'),
            'permission_callback' => '__return_true', // Public endpoint — authenticated in handle_events()
        ));
    }

    /**
     * Handle incoming SendGrid Event Webhook payload.
     *
     * @param \WP_REST_Request $request
     * @return \WP_REST_Response
     */
    public static function handle_events(\WP_REST_Request $request)
    {
        $options = get_option('wpnews_options', array());
        if (!is_array($options)) {
            $options = array();
        }

        $public_key = isset($options['sendgrid_webhook_key']) ? trim((string) $options['sendgrid_webhook_key']) : '';
        $secret     = isset($options['webhook_secret']) ? trim((string) $options['webhook_secret']) : '';

        // Never accept unauthenticated webhooks.
        if ('' === $public_key && '' === $secret) {
            return new \WP_REST_Response(array('error' => __('Webhook verification is not configured.', 'wp-news')), 403);
        }

        if ('' !== $secret) {
            $key = $request->get_param('key');
            if (!is_string($key) || '' === $key || !hash_equals($secret, $key)) {
                return new \WP_REST_Response(array('error' => __('Forbidden.', 'wp-news')), 403);
            }
        }

        $raw_body = $request->get_body();

        if ('' !== $public_key && !self::verify_signature($request, $raw_body, $public_key)) {
            return new \WP_REST_Response(array('error' => __('Invalid signature.', 'wp-news')), 403);
        }

        $events = json_decode($raw_body, true);

        if (empty($events) || !is_array($events)) {
            return new \WP_REST_Response(array('error' => __('Invalid payload.', 'wp-news')), 400);
        }

        $processed = 0;

        foreach ($events as $event) {
            if (!is_array($event) || empty($event['event']) || !is_string($event['event']) || empty($event['email'])) {
                continue;
            }

            $email = self::clean_email($event['email']);
            if ('' === $email) {
                continue;
            }

            switch ($event['event']) {
                case 'delivered':
                    self::handle_delivery($event, $email);
                    $processed++;
                    break;

                case 'bounce':
                case 'dropped':
                    self::handle_bounce($event, $email);
                    $processed++;
                    break;

                case 'spamreport':
                    self::handle_complaint($email);
                    $processed++;
                    break;

                default:
                    // Ignore other event types (processed, deferred, open, click, etc.)
                    break;
            }
        }

        return new \WP_REST_Response(array('status' => 'ok', 'processed' => $processed), 200);
    }

    /**
     * Verify the SendGrid Signed Event Webhook (ECDSA P-256 / SHA256).
     *
     * @param \WP_REST_Request $request
     * @param string           $raw_body   Raw POST body.
     * @param string           $public_key Base64 public key from SendGrid.
     * @return bool
     */
    private static function verify_signature(\WP_REST_Request $request, $raw_body, $public_key)
    {
        $signature = $request->get_header('X-Twilio-Email-Event-Webhook-Signature');
        $timestamp = $request->get_header('X-Twilio-Email-Event-Webhook-Timestamp');

        if (empty($signature) || empty($timestamp) || !ctype_digit((string) $timestamp)) {
            return false;
        }

        // Replay protection: +/- 5 minutes.
        if (abs(time() - (int) $timestamp) > self::MAX_TIMESTAMP_SKEW) {
            return false;
        }

        // Build the signed payload: timestamp + raw body
        $signed_payload = $timestamp . $raw_body;

        // Decode the public key (SendGrid provides a base64-encoded ECDSA key)
        $pem = "-----BEGIN PUBLIC KEY-----\n" . wordwrap($public_key, 64, "\n", true) . "\n-----END PUBLIC KEY-----";
        $key_resource = openssl_pkey_get_public($pem);

        if (!$key_resource) {
            error_log('WPNEWS: SendGrid webhook - invalid public key format');
            return false;
        }

        $decoded_signature = base64_decode($signature, true);
        if (false === $decoded_signature) {
            return false;
        }

        $result = openssl_verify($signed_payload, $decoded_signature, $key_resource, OPENSSL_ALGO_SHA256);

        return ($result === 1);
    }

    /**
     * Normalise and validate an email coming from the payload.
     *
     * @param mixed $raw
     * @return string Empty string when invalid.
     */
    private static function clean_email($raw)
    {
        if (!is_string($raw)) {
            return '';
        }
        $email = sanitize_email(strtolower(trim($raw)));
        return ($email && is_email($email)) ? $email : '';
    }

    /**
     * Handle delivery event — mark email as delivered.
     *
     * @param array  $event SendGrid event data.
     * @param string $email Validated email.
     */
    private static function handle_delivery(array $event, $email)
    {
        $timestamp    = isset($event['timestamp']) && is_numeric($event['timestamp']) ? (int) $event['timestamp'] : time();
        $delivered_at = get_date_from_gmt(gmdate('Y-m-d H:i:s', $timestamp));

        $result = WPNews_Tracker::mark_delivered($email, $delivered_at);
        if (false === $result) {
            error_log('WPNEWS: SendGrid delivery update failed for ' . $email);
        }
    }

    /**
     * Handle bounce / dropped event — mark as bounced and auto-blacklist.
     *
     * @param array  $event SendGrid event data.
     * @param string $email Validated email.
     */
    private static function handle_bounce(array $event, $email)
    {
        $event_type  = isset($event['event']) ? sanitize_text_field((string) $event['event']) : 'bounce';
        $reason_text = isset($event['reason']) && is_string($event['reason']) ? sanitize_text_field($event['reason']) : '';
        $status_code = isset($event['status']) && is_scalar($event['status']) ? sanitize_text_field((string) $event['status']) : '';

        if (false === WPNews_Tracker::mark_bounced($email)) {
            error_log('WPNEWS: SendGrid bounce update failed for ' . $email);
        }

        // Build descriptive reason
        $reason = 'SendGrid ' . $event_type;
        if ('' !== $status_code) {
            $reason .= ' (' . $status_code . ')';
        }
        if ('' !== $reason_text) {
            $reason .= ': ' . mb_substr($reason_text, 0, 200);
        }

        // Auto-blacklist (add_to_blacklist() skips duplicates)
        WPNews_Blacklist_Manager::add_to_blacklist($email, $reason);
    }

    /**
     * Handle spam report event — blacklist the email.
     *
     * @param string $email Validated email.
     */
    private static function handle_complaint($email)
    {
        WPNews_Blacklist_Manager::add_to_blacklist($email, 'SendGrid spam complaint');
    }
}
