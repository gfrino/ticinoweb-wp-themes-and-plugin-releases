<?php
/**
 * Blacklist management functionality.
 *
 * @package WPNews
 */

/**
 * Blacklist Manager class.
 */
class WPNews_Blacklist_Manager {

	/**
	 * Add email to blacklist.
	 *
	 * @param string $email  Email address to blacklist.
	 * @param string $reason Reason for blacklisting.
	 * @return bool True on success, false on failure.
	 */
	public static function add_to_blacklist( $email, $reason = '' ) {
		global $wpdb;

		$email = WPNews_Security::sanitize_email( $email );

		if ( ! WPNews_Security::is_valid_email( $email ) ) {
			return false;
		}

		$table = $wpdb->prefix . 'wpnews_blacklist';

		$existing = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM $table WHERE email = %s",
				$email
			)
		);

		if ( $existing > 0 ) {
			return false; // Already blacklisted
		}

		$result = $wpdb->insert(
			$table,
			array(
				'email'  => $email,
				'reason' => WPNews_Security::sanitize_text( $reason ),
			),
			array( '%s', '%s' )
		);

		return false !== $result;
	}

	/**
	 * Remove email from blacklist.
	 *
	 * @param string $email Email address to remove from blacklist.
	 * @return bool True on success, false on failure.
	 */
	public static function remove_from_blacklist( $email ) {
		global $wpdb;

		$email = WPNews_Security::sanitize_email( $email );
		$table = $wpdb->prefix . 'wpnews_blacklist';

		$result = $wpdb->delete(
			$table,
			array( 'email' => $email ),
			array( '%s' )
		);

		return false !== $result;
	}

	/**
	 * Check if email is blacklisted.
	 *
	 * @param string $email Email address to check.
	 * @return bool True if blacklisted, false otherwise.
	 */
	public static function is_blacklisted( $email ) {
		global $wpdb;

		$email = WPNews_Security::sanitize_email( $email );
		$table = $wpdb->prefix . 'wpnews_blacklist';

		$count = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM $table WHERE email = %s",
				$email
			)
		);

		return $count > 0;
	}

	/**
	 * Import blacklist from CSV.
	 *
	 * @param string $file_path Path to file.
	 * @return array Results.
	 */
	public static function import_blacklist_from_csv( $file_path ) {
		$results = array(
			'success_count' => 0,
			'error_count'   => 0,
		);

		if ( ! file_exists( $file_path ) ) return $results;

		// Detect Delimiter
		$delimiter = ',';
		$handle = fopen( $file_path, 'r' );
		if ( $handle ) {
			$preview = fgets( $handle );
			if ( $preview && substr_count( $preview, ';' ) > substr_count( $preview, ',' ) ) $delimiter = ';';
			fclose( $handle );
		}

		$handle = fopen( $file_path, 'r' );
		if ( ! $handle ) return $results;

		// BOM
		$bom = fread($handle, 3);
		if ($bom !== "\xEF\xBB\xBF") rewind($handle);

		$row_index = 0;
		$email_idx = 0;

		while ( ( $data = fgetcsv( $handle, 1000, $delimiter ) ) !== false ) {
			$row_index++;
			
			if ( $row_index === 1 ) {
				// Try to find email column
				$lower = array_map(function($v){ return strtolower(trim($v));}, $data);
				$found = array_search('email', $lower);
				if ($found !== false) {
					$email_idx = $found;
					continue;
				}
				// If strictly header "email" not found, check if first col is email
				if ( WPNews_Security::is_valid_email( trim( $data[0] ) ) ) {
					// It's data
				} else {
					// It's a header we didn't recognize? Or maybe strictly column 0.
					// Let's assume its a header if not valid email
					continue;
				}
			}

			if ( ! isset( $data[$email_idx] ) ) continue;
			
			$email = trim( $data[$email_idx] );
			if ( self::add_to_blacklist( $email, 'Imported via CSV' ) ) {
				$results['success_count']++;
			} else {
				// Maybe already exists or invalid
				if (!WPNews_Security::is_valid_email($email)) $results['error_count']++;
			}
		}
		fclose( $handle );
		return $results;
	}
}
