<?php
/**
 * Mailer Wrapper class to abstract SendGrid vs SES.
 *
 * @package WPNews
 */

/**
 * Mailer class for email sending.
 */
class WPNews_Mailer
{

    /**
     * Concrete provider (WPNews_SES or WPNews_SendGrid).
     *
     * @var object
     */
    private $mailer;

    /**
     * Provider slug ('ses' or 'sendgrid').
     *
     * @var string
     */
    private $type;

    /**
     * Constructor.
     */
    public function __construct()
    {
        $options = get_option('wpnews_options', array());
        $type = isset($options['mailer_type']) ? $options['mailer_type'] : 'sendgrid';

        if ('ses' === $type && class_exists('WPNews_SES')) {
            $this->type = 'ses';
            $this->mailer = new WPNews_SES();
        } else {
            $this->type = 'sendgrid';
            $this->mailer = new WPNews_SendGrid();
        }
    }

    /**
     * Provider slug in use.
     *
     * @return string 'ses' or 'sendgrid'.
     */
    public function get_type()
    {
        return $this->type;
    }

    /**
     * Send email.
     *
     * @param string $to            Recipient email address.
     * @param string $subject       Email subject.
     * @param string $html_content  Email HTML content.
     * @param array  $extra_headers Extra headers (e.g. List-Unsubscribe) as name => value.
     * @param array  $attachments   Attachments: array of ['path' => ..., 'filename' => ..., 'type' => ...].
     * @return array Result array with success status and message.
     */
    public function send_email($to, $subject, $html_content, $extra_headers = array(), $attachments = array())
    {
        return $this->mailer->send_email($to, $subject, $html_content, $extra_headers, $attachments);
    }
}
