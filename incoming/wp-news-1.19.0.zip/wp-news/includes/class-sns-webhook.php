<?php
/**
 * Amazon SNS Webhook Handler for SES notifications.
 *
 * Receives delivery, bounce, and complaint notifications from SES via SNS.
 *
 * Every request MUST carry a valid SNS signature (SignatureVersion 1 = SHA1,
 * SignatureVersion 2 = SHA256) produced with a certificate hosted on
 * https://*.amazonaws.com. Optionally the request must also match the
 * configured Topic ARN (`sns_topic_arn`) and shared secret (`webhook_secret`,
 * passed as `?key=`) from the `wpnews_options` option.
 *
 * @package WPNews
 */

if (!defined('ABSPATH')) {
    exit;
}

class WPNews_SNS_Webhook
{

    /**
     * Maximum accepted age of an SNS message (seconds).
     */
    const MAX_MESSAGE_AGE = 900;

    /**
     * Register public REST endpoint for SNS notifications.
     */
    public static function register_routes()
    {
        register_rest_route('wp-news/v1', '/sns-webhook', array(
            'methods' => 'POST',
            'callback' => array(__CLASS__, 'handle_notification'),
            'permission_callback' => '__return_true', // Public endpoint — authenticated via SNS signature below
        ));
    }

    /**
     * Handle incoming SNS notification.
     *
     * @param \WP_REST_Request $request
     * @return \WP_REST_Response
     */
    public static function handle_notification(\WP_REST_Request $request)
    {
        $options = get_option('wpnews_options', array());
        if (!is_array($options)) {
            $options = array();
        }

        if (!self::check_shared_secret($request, $options)) {
            return new \WP_REST_Response(array('error' => __('Forbidden.', 'wp-news')), 403);
        }

        $body = $request->get_body();
        $data = json_decode($body, true);

        if (empty($data) || !is_array($data)) {
            return new \WP_REST_Response(array('error' => __('Invalid payload.', 'wp-news')), 400);
        }

        $type = isset($data['Type']) && is_string($data['Type']) ? $data['Type'] : '';
        if (!in_array($type, array('Notification', 'SubscriptionConfirmation', 'UnsubscribeConfirmation'), true)) {
            return new \WP_REST_Response(array('error' => __('Unsupported message type.', 'wp-news')), 400);
        }

        // Replay protection: reject messages older than 15 minutes.
        $ts = isset($data['Timestamp']) && is_string($data['Timestamp']) ? strtotime($data['Timestamp']) : false;
        if (false === $ts || $ts < (time() - self::MAX_MESSAGE_AGE)) {
            return new \WP_REST_Response(array('error' => __('Message timestamp is missing or expired.', 'wp-news')), 403);
        }

        // Optional Topic ARN pinning.
        $expected_arn = isset($options['sns_topic_arn']) ? trim((string) $options['sns_topic_arn']) : '';
        if ('' !== $expected_arn) {
            $topic_arn = isset($data['TopicArn']) && is_string($data['TopicArn']) ? $data['TopicArn'] : '';
            if ('' === $topic_arn || !hash_equals($expected_arn, $topic_arn)) {
                return new \WP_REST_Response(array('error' => __('Topic ARN mismatch.', 'wp-news')), 403);
            }
        }

        $verified = self::verify_signature($data);
        if (is_wp_error($verified)) {
            error_log('WPNEWS: SNS signature rejected - ' . $verified->get_error_message());
            return new \WP_REST_Response(array('error' => $verified->get_error_message()), 403);
        }

        if ('SubscriptionConfirmation' === $type) {
            return self::confirm_subscription($data);
        }

        if ('UnsubscribeConfirmation' === $type) {
            return new \WP_REST_Response(array('status' => 'ok'), 200);
        }

        $message = isset($data['Message']) && is_string($data['Message']) ? json_decode($data['Message'], true) : null;
        if (empty($message) || !is_array($message)) {
            return new \WP_REST_Response(array('error' => __('Invalid message.', 'wp-news')), 400);
        }

        $notification_type = isset($message['notificationType']) ? $message['notificationType'] : '';

        switch ($notification_type) {
            case 'Delivery':
                return self::handle_delivery($message);
            case 'Bounce':
                return self::handle_bounce($message);
            case 'Complaint':
                return self::handle_complaint($message);
            default:
                return new \WP_REST_Response(array('status' => 'ignored', 'type' => sanitize_text_field((string) $notification_type)), 200);
        }
    }

    /**
     * Validate the optional shared secret (`webhook_secret` option, `?key=` query arg).
     *
     * @param \WP_REST_Request $request
     * @param array            $options
     * @return bool
     */
    private static function check_shared_secret(\WP_REST_Request $request, array $options)
    {
        $secret = isset($options['webhook_secret']) ? trim((string) $options['webhook_secret']) : '';
        if ('' === $secret) {
            return true;
        }
        $key = $request->get_param('key');
        return is_string($key) && '' !== $key && hash_equals($secret, $key);
    }

    /**
     * Verify the SNS message signature according to the AWS specification.
     *
     * @param array $data Decoded SNS envelope.
     * @return true|\WP_Error
     */
    private static function verify_signature(array $data)
    {
        foreach (array('Signature', 'SigningCertURL', 'Timestamp', 'TopicArn', 'Type', 'MessageId') as $required) {
            if (!isset($data[$required]) || !is_string($data[$required]) || '' === $data[$required]) {
                return new \WP_Error('wpnews_sns_missing_field', __('Missing signature fields.', 'wp-news'));
            }
        }
        if (!array_key_exists('Message', $data) || !is_string($data['Message'])) {
            return new \WP_Error('wpnews_sns_missing_field', __('Missing signature fields.', 'wp-news'));
        }

        $version = isset($data['SignatureVersion']) ? (string) $data['SignatureVersion'] : '1';
        if ('1' === $version) {
            $algo = OPENSSL_ALGO_SHA1;
        } elseif ('2' === $version) {
            $algo = OPENSSL_ALGO_SHA256;
        } else {
            return new \WP_Error('wpnews_sns_bad_version', __('Unsupported signature version.', 'wp-news'));
        }

        if (!self::is_valid_aws_url($data['SigningCertURL'])) {
            return new \WP_Error('wpnews_sns_bad_cert_url', __('Invalid signing certificate URL.', 'wp-news'));
        }

        $cert = self::get_signing_cert($data['SigningCertURL']);
        if (is_wp_error($cert)) {
            return $cert;
        }

        $string_to_sign = self::build_string_to_sign($data);
        if (null === $string_to_sign) {
            return new \WP_Error('wpnews_sns_missing_field', __('Missing signature fields.', 'wp-news'));
        }

        $signature = base64_decode($data['Signature'], true);
        if (false === $signature) {
            return new \WP_Error('wpnews_sns_bad_signature', __('Malformed signature.', 'wp-news'));
        }

        $public_key = openssl_pkey_get_public($cert);
        if (false === $public_key) {
            return new \WP_Error('wpnews_sns_bad_cert', __('Invalid signing certificate.', 'wp-news'));
        }

        $result = openssl_verify($string_to_sign, $signature, $public_key, $algo);

        // -1 means OpenSSL refused the operation (e.g. SHA-1 disabled by the system
        // crypto policy on OpenSSL 3). For SignatureVersion 1 fall back to a manual
        // PKCS#1 v1.5 check that only needs the raw RSA public-key operation.
        if (-1 === $result && OPENSSL_ALGO_SHA1 === $algo) {
            $result = self::verify_rsa_sha1_pkcs1($string_to_sign, $signature, $public_key) ? 1 : 0;
        }

        if (1 !== $result) {
            return new \WP_Error('wpnews_sns_bad_signature', __('Signature verification failed.', 'wp-news'));
        }

        return true;
    }

    /**
     * Manual RSASSA-PKCS1-v1_5 / SHA-1 verification.
     *
     * Recovers the DigestInfo with the RSA public-key operation (PKCS#1 type-1
     * padding is validated by OpenSSL) and compares it, in constant time, with
     * the expected DER DigestInfo built from PHP's own sha1 implementation.
     *
     * @param string                    $data       Signed data.
     * @param string                    $signature  Raw signature bytes.
     * @param \OpenSSLAsymmetricKey|mixed $public_key Public key resource.
     * @return bool
     */
    private static function verify_rsa_sha1_pkcs1($data, $signature, $public_key)
    {
        $recovered = '';
        if (!openssl_public_decrypt($signature, $recovered, $public_key, OPENSSL_PKCS1_PADDING) || !is_string($recovered)) {
            return false;
        }

        // DigestInfo ::= SEQUENCE { AlgorithmIdentifier(sha1, NULL), OCTET STRING(20) }
        $expected = hex2bin('3021300906052b0e03021a05000414') . hash('sha1', $data, true);

        return hash_equals($expected, $recovered);
    }

    /**
     * Build the canonical string to sign for Notification / SubscriptionConfirmation.
     *
     * @param array $data
     * @return string|null Null when a required field is missing.
     */
    private static function build_string_to_sign(array $data)
    {
        if ('Notification' === $data['Type']) {
            $keys = array('Message', 'MessageId');
            if (isset($data['Subject']) && is_string($data['Subject'])) {
                $keys[] = 'Subject';
            }
            $keys = array_merge($keys, array('Timestamp', 'TopicArn', 'Type'));
        } else {
            // SubscriptionConfirmation and UnsubscribeConfirmation
            $keys = array('Message', 'MessageId', 'SubscribeURL', 'Timestamp', 'Token', 'TopicArn', 'Type');
        }

        $string = '';
        foreach ($keys as $key) {
            if (!isset($data[$key]) || !is_string($data[$key])) {
                return null;
            }
            $string .= $key . "\n" . $data[$key] . "\n";
        }
        return $string;
    }

    /**
     * Only https URLs whose host ends with `.amazonaws.com` are accepted.
     *
     * @param string $url
     * @return bool
     */
    private static function is_valid_aws_url($url)
    {
        if (!is_string($url) || '' === $url) {
            return false;
        }
        $parts = wp_parse_url($url);
        if (!is_array($parts) || empty($parts['scheme']) || empty($parts['host'])) {
            return false;
        }
        if ('https' !== strtolower($parts['scheme'])) {
            return false;
        }
        $host = strtolower($parts['host']);
        return (bool) preg_match('/^[a-z0-9.\-]+\.amazonaws\.com$/', $host);
    }

    /**
     * Fetch (and cache for 24h) the SNS signing certificate.
     *
     * @param string $url Validated certificate URL.
     * @return string|\WP_Error PEM certificate.
     */
    private static function get_signing_cert($url)
    {
        $transient = 'wpnews_sns_cert_' . md5($url);
        $cached = get_transient($transient);
        if (is_string($cached) && '' !== $cached) {
            return $cached;
        }

        $response = wp_safe_remote_get($url, array('timeout' => 10));
        if (is_wp_error($response)) {
            return new \WP_Error('wpnews_sns_cert_fetch', __('Could not download the signing certificate.', 'wp-news'));
        }
        if (200 !== (int) wp_remote_retrieve_response_code($response)) {
            return new \WP_Error('wpnews_sns_cert_fetch', __('Could not download the signing certificate.', 'wp-news'));
        }

        $cert = wp_remote_retrieve_body($response);
        if (!is_string($cert) || false === strpos($cert, '-----BEGIN CERTIFICATE-----')) {
            return new \WP_Error('wpnews_sns_bad_cert', __('Invalid signing certificate.', 'wp-news'));
        }

        set_transient($transient, $cert, DAY_IN_SECONDS);
        return $cert;
    }

    /**
     * Auto-confirm SNS subscription (signature already verified).
     *
     * @param array $data
     * @return \WP_REST_Response
     */
    private static function confirm_subscription(array $data)
    {
        $url = isset($data['SubscribeURL']) ? $data['SubscribeURL'] : '';
        if (!self::is_valid_aws_url($url)) {
            return new \WP_REST_Response(array('error' => __('Invalid SubscribeURL.', 'wp-news')), 400);
        }

        $response = wp_safe_remote_get($url, array('timeout' => 15));

        if (is_wp_error($response)) {
            return new \WP_REST_Response(array('error' => $response->get_error_message()), 500);
        }

        return new \WP_REST_Response(array('status' => 'subscription_confirmed'), 200);
    }

    /**
     * Normalise and validate an email coming from the SNS payload.
     *
     * @param mixed $raw
     * @return string Empty string when invalid.
     */
    private static function clean_email($raw)
    {
        if (!is_string($raw)) {
            return '';
        }
        $email = sanitize_email(strtolower(trim($raw)));
        return ($email && is_email($email)) ? $email : '';
    }

    /**
     * Convert an ISO-8601 UTC timestamp to a site-local MySQL datetime.
     *
     * @param mixed $iso
     * @return string
     */
    private static function to_local_mysql($iso)
    {
        $ts = is_string($iso) ? strtotime($iso) : false;
        if (false === $ts) {
            return current_time('mysql');
        }
        return get_date_from_gmt(gmdate('Y-m-d H:i:s', $ts));
    }

    /**
     * Handle delivery notification — mark email as delivered.
     */
    private static function handle_delivery(array $message)
    {
        $recipients = isset($message['delivery']['recipients']) && is_array($message['delivery']['recipients'])
            ? $message['delivery']['recipients']
            : array();

        if (empty($recipients)) {
            return new \WP_REST_Response(array('status' => 'no_recipients'), 200);
        }

        $delivered_at = self::to_local_mysql(isset($message['delivery']['timestamp']) ? $message['delivery']['timestamp'] : null);
        $count = 0;

        foreach ($recipients as $raw) {
            $email = self::clean_email($raw);
            if ('' === $email) {
                continue;
            }
            $result = WPNews_Tracker::mark_delivered($email, $delivered_at);
            if (false === $result) {
                error_log('WPNEWS: SNS delivery update failed for ' . $email);
                continue;
            }
            $count++;
        }

        return new \WP_REST_Response(array('status' => 'delivery_processed', 'count' => $count), 200);
    }

    /**
     * Handle bounce notification — mark as bounced and auto-blacklist.
     */
    private static function handle_bounce(array $message)
    {
        $bounced_recipients = isset($message['bounce']['bouncedRecipients']) && is_array($message['bounce']['bouncedRecipients'])
            ? $message['bounce']['bouncedRecipients']
            : array();
        $bounce_type = isset($message['bounce']['bounceType']) ? sanitize_text_field((string) $message['bounce']['bounceType']) : 'Unknown';
        $bounce_sub_type = isset($message['bounce']['bounceSubType']) ? sanitize_text_field((string) $message['bounce']['bounceSubType']) : '';

        if (empty($bounced_recipients)) {
            return new \WP_REST_Response(array('status' => 'no_recipients'), 200);
        }

        $reason = ($bounce_type === 'Permanent' ? 'SES permanent bounce' : 'SES transient bounce')
            . ($bounce_sub_type ? ' (' . $bounce_sub_type . ')' : '');

        $count = 0;
        foreach ($bounced_recipients as $recipient) {
            $email = (is_array($recipient) && isset($recipient['emailAddress'])) ? self::clean_email($recipient['emailAddress']) : '';
            if ('' === $email) {
                continue;
            }

            if (false === WPNews_Tracker::mark_bounced($email)) {
                error_log('WPNEWS: SNS bounce update failed for ' . $email);
            }

            // Auto-blacklist ALL bounces (permanent and transient); add_to_blacklist() skips duplicates.
            WPNews_Blacklist_Manager::add_to_blacklist($email, $reason);
            $count++;
        }

        return new \WP_REST_Response(array('status' => 'bounce_processed', 'count' => $count), 200);
    }

    /**
     * Handle complaint notification — blacklist the email.
     */
    private static function handle_complaint(array $message)
    {
        $complained_recipients = isset($message['complaint']['complainedRecipients']) && is_array($message['complaint']['complainedRecipients'])
            ? $message['complaint']['complainedRecipients']
            : array();

        if (empty($complained_recipients)) {
            return new \WP_REST_Response(array('status' => 'no_recipients'), 200);
        }

        $count = 0;
        foreach ($complained_recipients as $recipient) {
            $email = (is_array($recipient) && isset($recipient['emailAddress'])) ? self::clean_email($recipient['emailAddress']) : '';
            if ('' === $email) {
                continue;
            }
            WPNews_Blacklist_Manager::add_to_blacklist($email, 'SES spam complaint');
            $count++;
        }

        return new \WP_REST_Response(array('status' => 'complaint_processed', 'count' => $count), 200);
    }
}
