<?php
/**
 * Tracking functionality.
 *
 * @package WPNews
 */

class WPNews_Tracker {

	/**
	 * Track Open.
	 *
	 * @param int $campaign_id
	 * @param int $subscriber_id
	 */
	public static function track_open( $campaign_id, $subscriber_id ) {
		global $wpdb;
		$table = $wpdb->prefix . 'wpnews_campaign_stats';

		// Update opened_at only if not already set
		$wpdb->query(
			$wpdb->prepare(
				"UPDATE $table SET opened_at = NOW() WHERE campaign_id = %d AND subscriber_id = %d AND opened_at IS NULL",
				$campaign_id,
				$subscriber_id
			)
		);
	}

	/**
	 * Track Click.
	 *
	 * Single UPDATE: sets clicked_at and, if missing, opened_at (implicit open).
	 *
	 * @param int    $campaign_id
	 * @param int    $subscriber_id
	 * @param string $url
	 */
	public static function track_click( $campaign_id, $subscriber_id, $url = '' ) {
		global $wpdb;
		$stats_table  = $wpdb->prefix . 'wpnews_campaign_stats';
		$clicks_table = $wpdb->prefix . 'wpnews_campaign_clicks';

		$wpdb->query(
			$wpdb->prepare(
				"UPDATE $stats_table
				 SET clicked_at = NOW(), opened_at = COALESCE(opened_at, NOW())
				 WHERE campaign_id = %d AND subscriber_id = %d",
				$campaign_id,
				$subscriber_id
			)
		);

		// Record the specific URL clicked
		if ( ! empty( $url ) ) {
			$wpdb->insert(
				$clicks_table,
				array(
					'campaign_id'   => $campaign_id,
					'subscriber_id' => $subscriber_id,
					'url'           => esc_url_raw( $url ),
					'clicked_at'    => current_time( 'mysql' ),
				),
				array( '%d', '%d', '%s', '%s' )
			);
		}
	}

	/**
	 * Mark the most recent undelivered send for an email as delivered.
	 *
	 * Used by the SES/SNS and SendGrid webhooks.
	 *
	 * @param string $email        Recipient email (already validated).
	 * @param string $delivered_at MySQL datetime (site timezone).
	 * @return int|false Number of rows updated or false on error.
	 */
	public static function mark_delivered( $email, $delivered_at ) {
		global $wpdb;
		$stats_table       = $wpdb->prefix . 'wpnews_campaign_stats';
		$subscribers_table = $wpdb->prefix . 'wpnews_subscribers';

		return $wpdb->query(
			$wpdb->prepare(
				"UPDATE $stats_table SET delivered_at = %s
				 WHERE id = (
					SELECT id FROM (
						SELECT st.id FROM $stats_table st
						INNER JOIN $subscribers_table sub ON st.subscriber_id = sub.id
						WHERE sub.email = %s AND st.delivered_at IS NULL AND st.sent_at IS NOT NULL
						ORDER BY st.sent_at DESC
						LIMIT 1
					) t
				 )",
				$delivered_at,
				$email
			)
		);
	}

	/**
	 * Flag the most recent non-bounced send for an email as bounced.
	 *
	 * @param string $email Recipient email (already validated).
	 * @return int|false Number of rows updated or false on error.
	 */
	public static function mark_bounced( $email ) {
		global $wpdb;
		$stats_table       = $wpdb->prefix . 'wpnews_campaign_stats';
		$subscribers_table = $wpdb->prefix . 'wpnews_subscribers';

		return $wpdb->query(
			$wpdb->prepare(
				"UPDATE $stats_table SET bounced = 1
				 WHERE id = (
					SELECT id FROM (
						SELECT st.id FROM $stats_table st
						INNER JOIN $subscribers_table sub ON st.subscriber_id = sub.id
						WHERE sub.email = %s AND st.bounced = 0 AND st.sent_at IS NOT NULL
						ORDER BY st.sent_at DESC
						LIMIT 1
					) t
				 )",
				$email
			)
		);
	}
}
