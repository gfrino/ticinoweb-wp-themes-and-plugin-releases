<?php
/**
 * Fired during plugin deactivation.
 *
 * @package WPNews
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 */
class WPNews_Deactivator {

	/**
	 * Deactivation hook.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {
		// Clear scheduled events (all argument variants).
		wp_unschedule_hook( 'wpnews_send_scheduled_campaigns' );
		wp_unschedule_hook( 'wpnews_send_campaign_async' );

		// Delete transients
		delete_transient( 'wpnews_activation_notice' );

		// Note: We don't delete options or database tables on deactivation
		// This preserves user data in case they reactivate the plugin
	}
}
