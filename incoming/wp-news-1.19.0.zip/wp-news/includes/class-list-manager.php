<?php
/**
 * List management functionality.
 *
 * @package WPNews
 */

/**
 * List Manager class.
 */
class WPNews_List_Manager
{

	/**
	 * Create a new list.
	 *
	 * @param string $name        List name.
	 * @param string $description List description.
	 * @return int|false List ID on success, false on failure.
	 */
	public static function create_list($name, $description = '')
	{
		global $wpdb;

		$table = $wpdb->prefix . 'wpnews_lists';

		$result = $wpdb->insert(
			$table,
			array(
				'name' => WPNews_Security::sanitize_text($name),
				'description' => WPNews_Security::sanitize_textarea($description),
			),
			array('%s', '%s')
		);

		if (false !== $result) {
			return $wpdb->insert_id;
		}

		return false;
	}

	/**
	 * Get all lists.
	 *
	 * @return array Array of lists.
	 */
	public static function get_lists()
	{
		global $wpdb;

		$list_table = $wpdb->prefix . 'wpnews_lists';
		$sub_lists_table = $wpdb->prefix . 'wpnews_subscriber_lists';
		$sub_table = $wpdb->prefix . 'wpnews_subscribers';

		$results = $wpdb->get_results(
			"SELECT l.*, COALESCE(counts.cnt, 0) AS subscriber_count
			 FROM $list_table l
			 LEFT JOIN (
			     SELECT sl.list_id, COUNT(*) AS cnt
			     FROM $sub_lists_table sl
			     INNER JOIN $sub_table s ON sl.subscriber_id = s.id AND s.status = 'active'
			     GROUP BY sl.list_id
			 ) counts ON l.id = counts.list_id
			 ORDER BY l.created_at DESC",
			ARRAY_A
		);

		return $results ?: array();
	}

	/**
	 * Get list by ID.
	 *
	 * @param int $list_id List ID.
	 * @return array|null List data or null if not found.
	 */
	public static function get_list($list_id)
	{
		global $wpdb;

		$table = $wpdb->prefix . 'wpnews_lists';

		$result = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM $table WHERE id = %d",
				$list_id
			),
			ARRAY_A
		);

		return $result;
	}

	/**
	 * Delete a list.
	 *
	 * @param int $list_id List ID.
	 * @return bool True on success.
	 */
	public static function delete_list($list_id)
	{
		global $wpdb;

		$wpdb->delete($wpdb->prefix . 'wpnews_lists', array('id' => $list_id), array('%d'));

		// Remove relationships
		$wpdb->delete($wpdb->prefix . 'wpnews_subscriber_lists', array('list_id' => $list_id), array('%d'));
		$wpdb->delete($wpdb->prefix . 'wpnews_campaign_lists', array('list_id' => $list_id), array('%d'));

		return true;
	}


	/**
	 * Whether a subscriber already belongs to a list.
	 *
	 * @param int $subscriber_id Subscriber ID.
	 * @param int $list_id       List ID.
	 * @return bool
	 */
	public static function is_subscriber_in_list($subscriber_id, $list_id)
	{
		global $wpdb;

		$table = $wpdb->prefix . 'wpnews_subscriber_lists';

		return (bool) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT 1 FROM $table WHERE subscriber_id = %d AND list_id = %d LIMIT 1",
				$subscriber_id,
				$list_id
			)
		);
	}

	/**
	 * Add subscriber to list.
	 *
	 * @param int $subscriber_id Subscriber ID.
	 * @param int $list_id       List ID.
	 * @return bool True on success, false on failure.
	 */
	public static function add_subscriber_to_list($subscriber_id, $list_id)
	{
		global $wpdb;

		$table = $wpdb->prefix . 'wpnews_subscriber_lists';

		// Check if already subscribed
		$existing = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM $table WHERE subscriber_id = %d AND list_id = %d",
				$subscriber_id,
				$list_id
			)
		);

		if ($existing > 0) {
			return false; // Already subscribed
		}

		$result = $wpdb->insert(
			$table,
			array(
				'subscriber_id' => $subscriber_id,
				'list_id' => $list_id,
			),
			array('%d', '%d')
		);

		return false !== $result;
	}

	/**
	 * Remove subscriber from list.
	 *
	 * @param int $subscriber_id Subscriber ID.
	 * @param int $list_id       List ID.
	 * @return bool True on success, false on failure.
	 */
	public static function remove_subscriber_from_list($subscriber_id, $list_id)
	{
		global $wpdb;

		$table = $wpdb->prefix . 'wpnews_subscriber_lists';

		$result = $wpdb->delete(
			$table,
			array(
				'subscriber_id' => $subscriber_id,
				'list_id' => $list_id,
			),
			array('%d', '%d')
		);

		return false !== $result;
	}

	/**
	 * Get subscribers for a list.
	 *
	 * @param int    $list_id List ID.
	 * @param string $status  Subscriber status filter.
	 * @return array Array of subscribers.
	 */
	public static function get_list_subscribers($list_id, $status = 'active')
	{
		global $wpdb;

		$subscribers_table = $wpdb->prefix . 'wpnews_subscribers';
		$subscriber_lists_table = $wpdb->prefix . 'wpnews_subscriber_lists';
		$blacklist_table = $wpdb->prefix . 'wpnews_blacklist';

		$query = "SELECT s.id, s.email, s.first_name, s.last_name, s.status, s.subscribed_at, s.unsubscribed_at
		          FROM $subscribers_table s
		          INNER JOIN $subscriber_lists_table sl ON s.id = sl.subscriber_id
		          LEFT JOIN $blacklist_table bl ON s.email = bl.email
		          WHERE sl.list_id = %d 
		          AND s.status = %s
		          AND bl.email IS NULL
		          ORDER BY s.subscribed_at DESC";

		$results = $wpdb->get_results(
			$wpdb->prepare($query, $list_id, $status),
			ARRAY_A
		);

		return $results;
	}

	public static function get_all_subscribers($limit = 50, $offset = 0, $search = '', $status_filter = '', $list_filter = 0)
	{
		global $wpdb;
		$table = $wpdb->prefix . 'wpnews_subscribers';
		$sl_table = $wpdb->prefix . 'wpnews_subscriber_lists';

		$where = array();
		$join = '';
		$values = array();

		if (!empty($search)) {
			$like = '%' . $wpdb->esc_like($search) . '%';
			$where[] = "(s.email LIKE %s OR s.first_name LIKE %s OR s.last_name LIKE %s)";
			$values[] = $like;
			$values[] = $like;
			$values[] = $like;
		}

		if (!empty($status_filter)) {
			$where[] = "s.status = %s";
			$values[] = $status_filter;
		}

		if (!empty($list_filter)) {
			$join = "INNER JOIN $sl_table sl ON s.id = sl.subscriber_id";
			$where[] = "sl.list_id = %d";
			$values[] = $list_filter;
		}

		$where_sql = !empty($where) ? 'WHERE ' . implode(' AND ', $where) : '';

		$sql = "SELECT DISTINCT s.* FROM $table s $join $where_sql ORDER BY s.subscribed_at DESC LIMIT %d OFFSET %d";
		$values[] = $limit;
		$values[] = $offset;

		return $wpdb->get_results($wpdb->prepare($sql, $values), ARRAY_A);
	}

	public static function count_all_subscribers($search = '', $status_filter = '', $list_filter = 0)
	{
		global $wpdb;
		$table = $wpdb->prefix . 'wpnews_subscribers';
		$sl_table = $wpdb->prefix . 'wpnews_subscriber_lists';

		$where = array();
		$join = '';
		$values = array();

		if (!empty($search)) {
			$like = '%' . $wpdb->esc_like($search) . '%';
			$where[] = "(s.email LIKE %s OR s.first_name LIKE %s OR s.last_name LIKE %s)";
			$values[] = $like;
			$values[] = $like;
			$values[] = $like;
		}

		if (!empty($status_filter)) {
			$where[] = "s.status = %s";
			$values[] = $status_filter;
		}

		if (!empty($list_filter)) {
			$join = "INNER JOIN $sl_table sl ON s.id = sl.subscriber_id";
			$where[] = "sl.list_id = %d";
			$values[] = $list_filter;
		}

		$where_sql = !empty($where) ? 'WHERE ' . implode(' AND ', $where) : '';

		$sql = "SELECT COUNT(DISTINCT s.id) FROM $table s $join $where_sql";

		if (!empty($values)) {
			return (int) $wpdb->get_var($wpdb->prepare($sql, $values));
		}
		return (int) $wpdb->get_var($sql);
	}

	/**
	 * Batch-fetch list memberships for an array of subscriber IDs.
	 *
	 * @param array $subscriber_ids Array of subscriber IDs.
	 * @return array Keyed by subscriber_id => [ ['list_id' => X, 'name' => 'ListName'], ... ]
	 */
	public static function get_subscriber_list_memberships($subscriber_ids)
	{
		global $wpdb;
		if (empty($subscriber_ids)) return array();

		$sl_table = $wpdb->prefix . 'wpnews_subscriber_lists';
		$l_table  = $wpdb->prefix . 'wpnews_lists';

		$ids_placeholder = implode(',', array_map('intval', $subscriber_ids));

		$rows = $wpdb->get_results(
			"SELECT sl.subscriber_id, l.id AS list_id, l.name
			 FROM $sl_table sl
			 INNER JOIN $l_table l ON sl.list_id = l.id
			 WHERE sl.subscriber_id IN ($ids_placeholder)
			 ORDER BY l.name ASC",
			ARRAY_A
		);

		$result = array();
		foreach ($rows as $row) {
			$result[$row['subscriber_id']][] = array(
				'list_id' => $row['list_id'],
				'name'    => $row['name'],
			);
		}
		return $result;
	}

	/**
	 * Update an existing list.
	 *
	 * @param int   $list_id List ID.
	 * @param array $data    Data to update (e.g. array('name' => 'New Name')).
	 * @return bool True on success, false on failure.
	 */
	public static function update_list($list_id, $data)
	{
		global $wpdb;

		$table = $wpdb->prefix . 'wpnews_lists';
		$sanitized_data = array();

		if (isset($data['name'])) {
			$sanitized_data['name'] = sanitize_text_field($data['name']);
		}
		if (isset($data['description'])) {
			$sanitized_data['description'] = sanitize_textarea_field($data['description']);
		}

		if (empty($sanitized_data)) {
			return false;
		}

		$result = $wpdb->update(
			$table,
			$sanitized_data,
			array('id' => $list_id)
		);

		return false !== $result;
	}

	/**
	 * Blacklist a subscriber: add to blacklist table + set status to 'unsubscribed'.
	 *
	 * @param int $subscriber_id Subscriber ID.
	 * @return bool True on success.
	 */
	public static function blacklist_subscriber($subscriber_id)
	{
		global $wpdb;
		$sub_table = $wpdb->prefix . 'wpnews_subscribers';
		$bl_table  = $wpdb->prefix . 'wpnews_blacklist';

		$subscriber = $wpdb->get_row($wpdb->prepare("SELECT email FROM $sub_table WHERE id = %d", $subscriber_id), ARRAY_A);
		if (!$subscriber) return false;

		// Add to blacklist (ignore if already exists)
		$wpdb->query($wpdb->prepare(
			"INSERT IGNORE INTO $bl_table (email, reason) VALUES (%s, %s)",
			$subscriber['email'],
			'Manually blacklisted from subscribers page'
		));

		// Set subscriber status to unsubscribed
		$wpdb->update($sub_table, array('status' => 'unsubscribed'), array('id' => $subscriber_id), array('%s'), array('%d'));

		return true;
	}

	public static function delete_subscriber($subscriber_id)
	{
		global $wpdb;
		$wpdb->delete($wpdb->prefix . 'wpnews_subscribers', array('id' => $subscriber_id), array('%d'));
		$wpdb->delete($wpdb->prefix . 'wpnews_subscriber_lists', array('subscriber_id' => $subscriber_id), array('%d'));
		return true;
	}


	/**
	 * Create or get subscriber.
	 * 
	 * @param string $email
	 * @param string $first_name
	 * @param string $last_name
	 * @return int Subscriber ID
	 */
	public static function create_or_get_subscriber($email, $first_name = '', $last_name = '')
	{
		global $wpdb;
		$subscribers_table = $wpdb->prefix . 'wpnews_subscribers';

		$subscriber_id = $wpdb->get_var($wpdb->prepare("SELECT id FROM $subscribers_table WHERE email = %s", $email));

		if (!$subscriber_id) {
			$wpdb->insert(
				$subscribers_table,
				array(
					'email' => $email,
					'first_name' => $first_name,
					'last_name' => $last_name,
					'status' => 'active',
				),
				array('%s', '%s', '%s', '%s')
			);
			$subscriber_id = $wpdb->insert_id;
		}

		return $subscriber_id;
	}

	/**
	 * Import subscribers from CSV.
	 *
	 * @param string $file_path Path to CSV file.
	 * @param int    $list_id   List ID to add subscribers to.
	 * @param array  $mapping   Optional. Mapping of columns (email => index, etc).
	 * @return array Result array with success count and errors.
	 */
	public static function import_subscribers_from_csv($file_path, $list_id, $mapping = null)
	{
		$results = array(
			'success_count' => 0,
			'error_count' => 0,
			'errors' => array(),
		);

		if (!file_exists($file_path)) {
			$results['errors'][] = __('File not found.', 'wp-news');
			return $results;
		}

		// Detect Delimiter
		$delimiter = ',';
		$handle = fopen($file_path, 'r');
		if ($handle) {
			$preview = fgets($handle);
			if ($preview && substr_count($preview, ';') > substr_count($preview, ',')) {
				$delimiter = ';';
			}
			fclose($handle);
		}

		$handle = fopen($file_path, 'r');
		if (false === $handle) {
			$results['errors'][] = __('Could not open file.', 'wp-news');
			return $results;
		}

		global $wpdb;
		$subscribers_table = $wpdb->prefix . 'wpnews_subscribers';

		$row_index = 0;
		$header_map = null;

		// BOM Fix
		$bom = fread($handle, 3);
		if ($bom !== "\xEF\xBB\xBF") {
			rewind($handle);
		}

		while (($data = fgetcsv($handle, 1000, $delimiter)) !== false) {
			$row_index++;

			// If mapping is provided, use it
			if ($mapping && is_array($mapping)) {
				// We still need to skip header if it exists and we're on row 1?
				// Usually the mapping step happens AFTER showing headers, so row 1 is likely headers
				// But we need to know IF user said "First row is header".
				// For now, let's assume if mapping is provided, we skip row 1 if it looks like header or if user passed a flag.
				// Let's assume the wizard handles skipping row 1 by passing an offset or we check against headers.
				// Simplifying: If mapping is explicit, we still need to know if row 1 is header.
				// Let's blindly trust the mapping for indices.

				// BUT if we are in this loop, we are reading from line 1.
				// We should probably skip line 1 if it matches the column names we mapped?
				// Or better: Pass a start_row argument?
				// For now, let's assume row 1 is always header for CSVs unless specified otherwise.
				if ($row_index === 1) {
					// Check if row 1 values look like emails. If not, skip.
					if (!WPNews_Security::is_valid_email(trim($data[$mapping['email']] ?? ''))) {
						continue;
					}
				}

				$header_map = $mapping;

			} else {
				// Auto-detection logic (existing)
				if ($row_index === 1) {
					$cleaned_row = array_map(function ($h) {
						return strtolower(trim($h));
					}, $data);

					// Try to map columns
					$email_idx = array_search('email', $cleaned_row);
					if ($email_idx === false)
						$email_idx = array_search('e-mail', $cleaned_row);

					$fname_idx = array_search('first name', $cleaned_row);
					if ($fname_idx === false)
						$fname_idx = array_search('name', $cleaned_row);
					if ($fname_idx === false)
						$fname_idx = array_search('firstname', $cleaned_row);

					$lname_idx = array_search('last name', $cleaned_row);
					if ($lname_idx === false)
						$lname_idx = array_search('surname', $cleaned_row);
					if ($lname_idx === false)
						$lname_idx = array_search('lastname', $cleaned_row);

					if ($email_idx !== false) {
						// Found headers
						$header_map = array(
							'email' => $email_idx,
							'first_name' => $fname_idx,
							'last_name' => $lname_idx
						);
						continue; // Skip header
					} else {
						// No headers found? Is it a headerless file?
						// If the first column looks like an email, assume it's data
						if (WPNews_Security::is_valid_email(trim($data[0]))) {
							$header_map = array('email' => 0, 'first_name' => 1, 'last_name' => 2);
							// Process this row
						} else {
							// probably a header, skip
							$header_map = array('email' => 0, 'first_name' => 1, 'last_name' => 2);
							continue;
						}
					}
				}
			}

			if (!$header_map)
				$header_map = array('email' => 0, 'first_name' => 1, 'last_name' => 2);

			$email_idx = $header_map['email'];
			if (!isset($data[$email_idx]))
				continue;

			$email = trim($data[$email_idx]);

			// Sanitize
			$email = WPNews_Security::sanitize_email($email);

			if (empty($email) || !WPNews_Security::is_valid_email($email)) {
				$results['error_count']++;
				$results['errors'][] = sprintf(__('Row %d: Invalid email %s (Raw: %s)', 'wp-news'), $row_index, $email, isset($data[$email_idx]) ? $data[$email_idx] : 'N/A');
				continue;
			}

			// First Name
			$first_name = '';
			if (isset($header_map['first_name']) && $header_map['first_name'] !== false && isset($data[$header_map['first_name']])) {
				$first_name = WPNews_Security::sanitize_text(trim($data[$header_map['first_name']]));
			}

			// Last Name
			$last_name = '';
			if (isset($header_map['last_name']) && $header_map['last_name'] !== false && isset($data[$header_map['last_name']])) {
				$last_name = WPNews_Security::sanitize_text(trim($data[$header_map['last_name']]));
			}


			// Check if subscriber exists
			$subscriber_id = $wpdb->get_var(
				$wpdb->prepare(
					"SELECT id FROM $subscribers_table WHERE email = %s",
					$email
				)
			);

			// Create subscriber if doesn't exist
			if (!$subscriber_id) {
				$wpdb->insert(
					$subscribers_table,
					array(
						'email' => $email,
						'first_name' => $first_name,
						'last_name' => $last_name,
						'status' => 'active',
					),
					array('%s', '%s', '%s', '%s')
				);
				$subscriber_id = $wpdb->insert_id;
			}

			// Add to list
			if ($subscriber_id && self::add_subscriber_to_list($subscriber_id, $list_id)) {
				$results['success_count']++;
			} else {
				// Could fail if already in list, which counts as "success" effectively for import purposes usually?
				// Or maybe we treat duplicate as skipped.
				// Let's count it as success if we just ensured they are in the list.
				// But add_subscriber_to_list returns false if already exists.
				// Let's check existence first.
				$results['success_count']++;
			}
		}

		fclose($handle);

		return $results;
	}

	/**
	 * Import subscribers and lists from MailPoet (v3 tables).
	 *
	 * Runs a bounded number of queries regardless of the subscriber count:
	 * segments, subscribers, subscriber/segment memberships (ONE query), then
	 * batched INSERT IGNORE statements (500 rows) for blacklist, subscribers
	 * and list memberships.
	 *
	 * @return array Result of the import.
	 */
	public static function import_mailpoet_subscribers()
	{
		global $wpdb;

		$results = array(
			'lists_created' => 0,
			'subscribers_imported' => 0,
			'blacklisted' => 0,
			'errors' => array(),
		);

		// Table names (MailPoet v3)
		$mp_subscribers_table = $wpdb->prefix . 'mailpoet_subscribers';
		$mp_segments_table = $wpdb->prefix . 'mailpoet_segments';
		$mp_sub_seg_table = $wpdb->prefix . 'mailpoet_subscriber_segment';

		if ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $mp_subscribers_table)) !== $mp_subscribers_table) {
			// Try without core prefix just in case (some setups differ)
			$mp_subscribers_table = 'mailpoet_subscribers';
			if ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $mp_subscribers_table)) !== $mp_subscribers_table) {
				$results['errors'][] = __('MailPoet tables not found in database.', 'wp-news');
				return $results;
			}
			$mp_segments_table = 'mailpoet_segments';
			$mp_sub_seg_table = 'mailpoet_subscriber_segment';
		}

		$subscribers_table = $wpdb->prefix . 'wpnews_subscribers';
		$subscriber_lists_table = $wpdb->prefix . 'wpnews_subscriber_lists';
		$blacklist_table = $wpdb->prefix . 'wpnews_blacklist';

		// 1. Segments -> lists
		$segments = $wpdb->get_results("SELECT id, name, description FROM $mp_segments_table WHERE deleted_at IS NULL", ARRAY_A);
		$list_mapping = array(); // MailPoet segment ID => WP-News list ID

		// Re-running the import reuses the lists created the first time (same
		// name) instead of creating duplicates.
		$lists_table = $wpdb->prefix . 'wpnews_lists';
		foreach ((array) $segments as $segment) {
			$name     = WPNews_Security::sanitize_text($segment['name']);
			$existing = (int) $wpdb->get_var($wpdb->prepare("SELECT id FROM $lists_table WHERE name = %s ORDER BY id ASC LIMIT 1", $name));
			if ($existing) {
				$list_mapping[(int) $segment['id']] = $existing;
				continue;
			}
			$list_id = self::create_list($segment['name'], isset($segment['description']) ? $segment['description'] : '');
			if ($list_id) {
				$list_mapping[(int) $segment['id']] = (int) $list_id;
				$results['lists_created']++;
			}
		}

		// 2. Memberships: ONE query for all segments
		$membership = array(); // MailPoet subscriber ID => [list IDs]
		if (!empty($list_mapping)) {
			$seg_ids = implode(',', array_map('intval', array_keys($list_mapping)));
			$rows = $wpdb->get_results(
				"SELECT subscriber_id, segment_id FROM $mp_sub_seg_table WHERE status = 'subscribed' AND segment_id IN ($seg_ids)",
				ARRAY_A
			);
			foreach ((array) $rows as $row) {
				$membership[(int) $row['subscriber_id']][] = $list_mapping[(int) $row['segment_id']];
			}
		}

		// 3. Subscribers
		$mp_subscribers = $wpdb->get_results(
			"SELECT id, email, first_name, last_name, status FROM $mp_subscribers_table WHERE deleted_at IS NULL",
			ARRAY_A
		);

		$blacklist_rows = array(); // email => reason
		$active = array();         // email => info
		foreach ((array) $mp_subscribers as $mp_sub) {
			$email = sanitize_email(strtolower(trim((string) $mp_sub['email'])));
			if (!$email || !is_email($email)) {
				continue;
			}
			$status = isset($mp_sub['status']) ? $mp_sub['status'] : ''; // subscribed|unsubscribed|bounced|unconfirmed

			if (in_array($status, array('unsubscribed', 'bounced'), true)) {
				$blacklist_rows[$email] = ucfirst($status) . ' import from MailPoet';
				continue;
			}

			$active[$email] = array(
				'first_name' => sanitize_text_field((string) (isset($mp_sub['first_name']) ? $mp_sub['first_name'] : '')),
				'last_name' => sanitize_text_field((string) (isset($mp_sub['last_name']) ? $mp_sub['last_name'] : '')),
				'mp_id' => (int) $mp_sub['id'],
			);
		}

		// 4. Blacklist in batches
		foreach (array_chunk($blacklist_rows, 500, true) as $chunk) {
			$values = array();
			foreach ($chunk as $email => $reason) {
				$values[] = $wpdb->prepare('(%s, %s)', $email, $reason);
			}
			$inserted = $wpdb->query("INSERT IGNORE INTO $blacklist_table (email, reason) VALUES " . implode(',', $values));
			if (false !== $inserted) {
				$results['blacklisted'] += (int) $inserted;
			}
		}

		// 5. Subscribers in batches, then id lookup and list memberships
		foreach (array_chunk($active, 500, true) as $chunk) {
			$values = array();
			foreach ($chunk as $email => $info) {
				$values[] = $wpdb->prepare('(%s, %s, %s, %s)', $email, $info['first_name'], $info['last_name'], 'active');
			}
			$wpdb->query("INSERT IGNORE INTO $subscribers_table (email, first_name, last_name, status) VALUES " . implode(',', $values));

			$placeholders = implode(',', array_fill(0, count($chunk), '%s'));
			$id_rows = $wpdb->get_results(
				$wpdb->prepare("SELECT id, email FROM $subscribers_table WHERE email IN ($placeholders)", array_keys($chunk)),
				ARRAY_A
			);

			$sl_values = array();
			foreach ((array) $id_rows as $row) {
				$email = strtolower((string) $row['email']);
				if (!isset($chunk[$email])) {
					continue;
				}
				$results['subscribers_imported']++;

				$mp_id = $chunk[$email]['mp_id'];
				if (!empty($membership[$mp_id])) {
					foreach (array_unique($membership[$mp_id]) as $list_id) {
						$sl_values[] = $wpdb->prepare('(%d, %d)', (int) $row['id'], (int) $list_id);
					}
				}
			}

			foreach (array_chunk($sl_values, 1000) as $sl_chunk) {
				$wpdb->query("INSERT IGNORE INTO $subscriber_lists_table (subscriber_id, list_id) VALUES " . implode(',', $sl_chunk));
			}
		}

		return $results;
	}
}
