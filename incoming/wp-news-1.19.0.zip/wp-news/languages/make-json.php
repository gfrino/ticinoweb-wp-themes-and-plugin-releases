<?php
/**
 * Build the JED translation JSON consumed by wp_set_script_translations() for
 * the builder script from languages/wp-news-<locale>.po.
 *
 * Usage (from the plugin root): php languages/make-json.php it_IT
 *
 * Only entries referenced from src/ (JavaScript) are included. The output file
 * is named after the script handle (wp-news-builder), which WordPress accepts
 * when the md5-based filename is missing.
 */
if (PHP_SAPI !== 'cli') {
	exit(1);
}
$locale = $argv[1] ?? 'it_IT';
$handle = $argv[2] ?? 'wp-news-builder';
$domain = 'wp-news';
$dir    = __DIR__;
$po     = "$dir/$domain-$locale.po";
if (!is_file($po)) {
	fwrite(STDERR, "Missing $po\n");
	exit(1);
}
$root = null;
foreach ([dirname($dir, 4) . '/wp-includes/pomo', dirname($dir, 3) . '/wp-includes/pomo', '/var/www/webroot/ROOT/wp-includes/pomo'] as $candidate) {
	if (is_file("$candidate/po.php")) {
		$root = $candidate;
		break;
	}
}
if (!$root) {
	fwrite(STDERR, "WordPress pomo classes not found\n");
	exit(1);
}
require_once "$root/po.php";

$p = new PO();
$p->import_from_file($po);

$messages = ['' => ['domain' => 'messages', 'lang' => $locale, 'plural-forms' => $p->headers['Plural-Forms'] ?? 'nplurals=2; plural=(n != 1);']];
$count = 0;
foreach ($p->entries as $entry) {
	$js = false;
	foreach ($entry->references as $ref) {
		if (preg_match('#^src/.*\.js#', $ref)) {
			$js = true;
			break;
		}
	}
	if (!$js) {
		continue;
	}
	if (empty($entry->translations) || $entry->translations[0] === '') {
		continue;
	}
	$key = ($entry->context !== null && $entry->context !== '') ? $entry->context . "\u{4}" . $entry->singular : $entry->singular;
	$messages[$key] = $entry->translations;
	$count++;
}

$json = [
	'translation-revision-date' => gmdate('Y-m-d H:i+0000'),
	'generator' => 'wp-news/languages/make-json.php',
	'source' => 'build/index.js',
	'domain' => 'messages',
	'locale_data' => ['messages' => $messages],
];
$out = "$dir/$domain-$locale-$handle.json";
file_put_contents($out, json_encode($json, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
echo "Wrote $out ($count strings)\n";
