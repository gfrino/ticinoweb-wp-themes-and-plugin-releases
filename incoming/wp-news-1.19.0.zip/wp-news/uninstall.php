<?php
/**
 * Fired when the plugin is uninstalled.
 *
 * Removes options, transients, scheduled events and the CSV import folder for
 * every site (network-wide on multisite). Database tables are PRESERVED so
 * that subscribers, lists and statistics survive a reinstall. The tables are:
 *
 *   {prefix}wpnews_subscribers
 *   {prefix}wpnews_lists
 *   {prefix}wpnews_subscriber_lists
 *   {prefix}wpnews_blacklist
 *   {prefix}wpnews_campaigns
 *   {prefix}wpnews_campaign_lists
 *   {prefix}wpnews_campaign_stats
 *   {prefix}wpnews_campaign_clicks
 *
 * (Legacy installs may also have {prefix}wpnews_auto_emails, unused and no
 * longer created.) To drop them, run the corresponding DROP TABLE statements
 * manually or set WPNEWS_UNINSTALL_DROP_TABLES to true in wp-config.php.
 *
 * @package WPNews
 */

// If uninstall not called from WordPress, then exit.
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

/*
 * Release updater mu-plugin: remove it only if no other installed plugin
 * relies on it (same Update URI). It is infrastructure, not data.
 */
if ( ! function_exists( 'get_plugins' ) ) {
	require_once ABSPATH . 'wp-admin/includes/plugin.php';
}
$wpnews_mu_file = trailingslashit( WPMU_PLUGIN_DIR ) . 'tw-release-updater.php';
if ( file_exists( $wpnews_mu_file ) ) {
	$wpnews_mu_users = 0;
	foreach ( get_plugins() as $wpnews_file => $wpnews_data ) {
		if ( 'wp-news/wp-news.php' !== $wpnews_file
			&& ! empty( $wpnews_data['UpdateURI'] )
			&& 'https://github.com/gfrino/ticinoweb-wp-themes-and-plugin-releases' === untrailingslashit( strtolower( trim( $wpnews_data['UpdateURI'] ) ) ) ) {
			$wpnews_mu_users++;
		}
	}
	if ( 0 === $wpnews_mu_users ) {
		@unlink( $wpnews_mu_file ); // phpcs:ignore WordPress.PHP.NoSilencedErrors
	}
}

/**
 * Clean up the CURRENT site.
 */
function wpnews_uninstall_site() {
	global $wpdb;

	// Options
	delete_option( 'wpnews_options' );
	delete_option( 'wpnews_db_version' );
	delete_option( 'wpnews_unsubscribe_secret' );

	// Any remaining wpnews_* options (locks, per-campaign error logs) and transients
	$wpdb->query(
		"DELETE FROM {$wpdb->options}
		 WHERE option_name LIKE 'wpnews\\_%'
		    OR option_name LIKE '\\_transient\\_wpnews\\_%'
		    OR option_name LIKE '\\_transient\\_timeout\\_wpnews\\_%'"
	);

	// Scheduled events (every argument variant)
	foreach ( array( 'wpnews_send_scheduled_campaigns', 'wpnews_process_scheduled_campaigns', 'wpnews_send_campaign_async' ) as $hook ) {
		wp_unschedule_hook( $hook );
	}

	// CSV import folder
	$upload_dir = wp_upload_dir();
	if ( ! empty( $upload_dir['basedir'] ) ) {
		$import_dir = trailingslashit( $upload_dir['basedir'] ) . 'wpnews-imports';
		if ( is_dir( $import_dir ) ) {
			wpnews_uninstall_rmdir( $import_dir );
		}
	}

	// Optional table removal (opt-in via wp-config.php)
	if ( defined( 'WPNEWS_UNINSTALL_DROP_TABLES' ) && WPNEWS_UNINSTALL_DROP_TABLES ) {
		$tables = array(
			'wpnews_campaign_clicks',
			'wpnews_campaign_stats',
			'wpnews_campaign_lists',
			'wpnews_campaigns',
			'wpnews_blacklist',
			'wpnews_subscriber_lists',
			'wpnews_lists',
			'wpnews_subscribers',
			'wpnews_auto_emails',
		);
		foreach ( $tables as $table ) {
			$wpdb->query( 'DROP TABLE IF EXISTS `' . $wpdb->prefix . $table . '`' );
		}
	}
}

/**
 * Recursively delete a directory (files only expected: uploaded CSVs).
 *
 * @param string $dir Absolute path.
 */
function wpnews_uninstall_rmdir( $dir ) {
	$items = scandir( $dir );
	if ( false === $items ) {
		return;
	}
	foreach ( $items as $item ) {
		if ( '.' === $item || '..' === $item ) {
			continue;
		}
		$path = $dir . DIRECTORY_SEPARATOR . $item;
		if ( is_dir( $path ) && ! is_link( $path ) ) {
			wpnews_uninstall_rmdir( $path );
		} else {
			@unlink( $path );
		}
	}
	@rmdir( $dir );
}

if ( is_multisite() ) {
	$wpnews_site_ids = get_sites( array( 'fields' => 'ids', 'number' => 0 ) );
	foreach ( $wpnews_site_ids as $wpnews_site_id ) {
		switch_to_blog( (int) $wpnews_site_id );
		wpnews_uninstall_site();
		restore_current_blog();
	}
	unset( $wpnews_site_ids, $wpnews_site_id );
} else {
	wpnews_uninstall_site();
}
