<?php
/**
 * Dashboard admin page.
 *
 * @package WPNews
 */

if (!defined('ABSPATH')) {
	exit;
}

global $wpdb;

// Get stats
$subscribers_count = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}wpnews_subscribers WHERE status = 'active'");
$campaigns_count   = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}wpnews_campaigns WHERE parent_id IS NULL OR parent_id = 0");
$lists_count       = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}wpnews_lists");
$blacklist_count   = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}wpnews_blacklist");

// Recent campaigns: only the 5 most recent, without heavy content columns.
$recent_campaigns = WPNews_Campaign_Manager::get_campaigns(null, 'regular', array(
	'limit' => 5,
	'light' => true,
));
if (!is_array($recent_campaigns)) {
	$recent_campaigns = array();
}
if (count($recent_campaigns) > 5) {
	$recent_campaigns = array_slice($recent_campaigns, 0, 5);
}

$campaign_ids   = wp_list_pluck($recent_campaigns, 'id');
$stats_summary  = WPNews_Campaign_Manager::get_campaign_stats_summary($campaign_ids);
$detailed_stats = WPNews_Campaign_Manager::get_campaign_detailed_stats($campaign_ids);
if (!is_array($stats_summary)) {
	$stats_summary = array();
}
if (!is_array($detailed_stats)) {
	$detailed_stats = array();
}

$admin_base = admin_url('admin.php');
$logo_file  = 'assets/Logo ticinoWEB Ufficiale 2025.png';
?>

<div class="wpnews-admin-wrap">
	<div class="wpnews-header">
		<?php if (file_exists(WPNEWS_PLUGIN_DIR . $logo_file)) : ?>
			<div class="wpnews-logo-container">
				<img src="<?php echo esc_url(WPNEWS_PLUGIN_URL . $logo_file); ?>" alt="ticinoWEB" class="wpnews-logo">
				<div class="wpnews-logo-version">v<?php echo esc_html(WPNEWS_VERSION); ?></div>
			</div>
		<?php endif; ?>
		<h1><?php esc_html_e('Newsletter Dashboard', 'wp-news'); ?></h1>
		<p><?php esc_html_e('Welcome to WP-News Newsletter - your lightweight, powerful newsletter solution.', 'wp-news'); ?></p>
	</div>

	<div class="wpnews-stats">
		<div class="wpnews-stat-box">
			<h3><?php esc_html_e('Active Subscribers', 'wp-news'); ?></h3>
			<p class="number"><?php echo esc_html(number_format_i18n($subscribers_count)); ?></p>
		</div>

		<div class="wpnews-stat-box wpnews-stat-box--pink">
			<h3><?php esc_html_e('Total Campaigns', 'wp-news'); ?></h3>
			<p class="number"><?php echo esc_html(number_format_i18n($campaigns_count)); ?></p>
		</div>

		<div class="wpnews-stat-box wpnews-stat-box--cyan">
			<h3><?php esc_html_e('Lists', 'wp-news'); ?></h3>
			<p class="number"><?php echo esc_html(number_format_i18n($lists_count)); ?></p>
		</div>

		<div class="wpnews-stat-box wpnews-stat-box--orange">
			<h3><?php esc_html_e('Blacklisted', 'wp-news'); ?></h3>
			<p class="number"><?php echo esc_html(number_format_i18n($blacklist_count)); ?></p>
		</div>
	</div>

	<div class="wpnews-card wpnews-card--glass">
		<h2><?php esc_html_e('Recent Campaigns', 'wp-news'); ?></h2>
		<?php if (!empty($recent_campaigns)) : ?>
			<table class="wpnews-table">
				<thead>
					<tr>
						<th><?php esc_html_e('Campaign', 'wp-news'); ?></th>
						<th><?php esc_html_e('Status', 'wp-news'); ?></th>
						<th class="wpnews-col-center"><?php esc_html_e('Delivered', 'wp-news'); ?></th>
						<th class="wpnews-col-center"><?php esc_html_e('Opened', 'wp-news'); ?></th>
						<th class="wpnews-col-center"><?php esc_html_e('Clicked', 'wp-news'); ?></th>
						<th><?php esc_html_e('Created', 'wp-news'); ?></th>
						<th><?php esc_html_e('Actions', 'wp-news'); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ($recent_campaigns as $campaign) :
						$cid    = (int) ($campaign['id'] ?? 0);
						$status = strtolower((string) ($campaign['status'] ?? 'draft'));
						$total  = (int) ($campaign['total_recipients'] ?? 0);
						$sent   = (int) ($campaign['sent_count'] ?? 0);
						if (0 === $sent && isset($stats_summary[$cid])) {
							$sent = (int) $stats_summary[$cid];
						}
						$percent = $total > 0 ? min(100, (int) round(($sent / $total) * 100)) : 0;
						if ('sent' === $status && 0 === $total && $sent > 0) {
							$percent = 100;
							$total   = $sent;
						}

						$ds        = isset($detailed_stats[$cid]) && is_array($detailed_stats[$cid]) ? $detailed_stats[$cid] : array();
						$delivered = (int) ($ds['delivered'] ?? 0);
						$opened    = (int) ($ds['opened'] ?? 0);
						$clicked   = (int) ($ds['clicked'] ?? 0);

						$created_ts = !empty($campaign['created_at']) ? strtotime((string) $campaign['created_at']) : false;
						?>
						<tr>
							<td><?php echo esc_html((string) ($campaign['name'] ?? '')); ?></td>
							<td>
								<span class="wpnews-badge <?php echo esc_attr($status); ?> wpnews-badge--dot"><?php echo esc_html(ucfirst($status)); ?></span>
								<?php if (in_array($status, array('sending', 'sent', 'stopped'), true)) : ?>
									<div class="wpnews-progress wpnews-progress--wide">
										<div class="wpnews-progress-bar">
											<div class="wpnews-progress-fill" style="width:<?php echo (int) $percent; ?>%;"></div>
										</div>
										<div class="wpnews-progress-text">
											<span><?php echo esc_html(number_format_i18n($sent)); ?> / <?php echo esc_html(number_format_i18n($total)); ?></span>
											<span><?php echo (int) $percent; ?>%</span>
										</div>
									</div>
								<?php endif; ?>
							</td>
							<td class="wpnews-col-center"><span class="wpnews-num wpnews-num--delivered"><?php echo esc_html(number_format_i18n($delivered)); ?></span></td>
							<td class="wpnews-col-center"><span class="wpnews-num wpnews-num--opened"><?php echo esc_html(number_format_i18n($opened)); ?></span></td>
							<td class="wpnews-col-center"><span class="wpnews-num wpnews-num--clicked"><?php echo esc_html(number_format_i18n($clicked)); ?></span></td>
							<td><?php echo $created_ts ? esc_html(date_i18n('M d, Y', $created_ts)) : '—'; ?></td>
							<td>
								<div class="wpnews-actions-row">
									<?php if (in_array($status, array('sent', 'sending', 'stopped'), true)) : ?>
										<a href="<?php echo esc_url(add_query_arg(array('page' => 'wp-news-campaigns', 'view' => 'stats', 'id' => $cid), $admin_base)); ?>"
											class="button button-small wpnews-pill wpnews-btn-indigo"><?php esc_html_e('Stats', 'wp-news'); ?></a>
									<?php endif; ?>
									<?php if (in_array($status, array('draft', 'saved', 'scheduled', 'stopped'), true)) : ?>
										<a href="<?php echo esc_url(add_query_arg(array('page' => 'wp-news-create-campaign', 'id' => $cid), $admin_base)); ?>"
											class="button button-small wpnews-pill"><?php esc_html_e('Edit', 'wp-news'); ?></a>
									<?php endif; ?>
									<a href="<?php echo esc_url(wp_nonce_url(add_query_arg(array('action' => 'wpnews_delete_campaign', 'id' => $cid), admin_url('admin-post.php')), 'wpnews_delete_campaign_' . $cid)); ?>"
										class="button button-small button-link-delete wpnews-pill"
										data-wpnews-confirm="<?php esc_attr_e('Are you sure you want to delete this campaign?', 'wp-news'); ?>">
										<?php esc_html_e('Delete', 'wp-news'); ?>
									</a>
								</div>
							</td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		<?php else : ?>
			<p><?php esc_html_e('No campaigns yet. Create your first campaign to get started!', 'wp-news'); ?></p>
		<?php endif; ?>
	</div>
</div>
