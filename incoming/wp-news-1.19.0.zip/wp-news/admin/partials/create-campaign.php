<?php
/**
 * Create campaign admin page.
 * Authenticated React App Container.
 * 
 * @package WPNews
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<div class="wpnews-admin-wrap">
	<div id="wpnews-react-root"></div>
</div>

