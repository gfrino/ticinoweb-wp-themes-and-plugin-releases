<?php
/**
 * Subscribers admin page (CSV import wizard + subscriber list).
 *
 * @package WPNews
 */

if (!defined('ABSPATH')) {
	exit;
}

$admin_base = admin_url('admin.php');
$base_url   = add_query_arg(array('page' => 'wp-news-subscribers'), $admin_base);

// ------------------------------------------------------------------
// CSV import: protected upload directory + per-user transient token.
// The browser never sends a filesystem path.
// ------------------------------------------------------------------
$upload_dir    = wp_upload_dir();
$import_dir    = trailingslashit($upload_dir['basedir']) . 'wpnews-imports';
$transient_key = 'wpnews_import_' . get_current_user_id();

$wpnews_prepare_import_dir = static function () use ($import_dir) {
	if (!is_dir($import_dir)) {
		wp_mkdir_p($import_dir);
	}
	if (!is_dir($import_dir)) {
		return false;
	}
	if (!file_exists($import_dir . '/index.php')) {
		file_put_contents($import_dir . '/index.php', "<?php\n// Silence is golden.\n");
	}
	if (!file_exists($import_dir . '/.htaccess')) {
		file_put_contents(
			$import_dir . '/.htaccess',
			"# Deny direct access to uploaded import files\n<IfModule mod_authz_core.c>\n\tRequire all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\n\tDeny from all\n</IfModule>\n"
		);
	}
	return true;
};

$wpnews_path_in_import_dir = static function ($path) use ($import_dir) {
	if (!is_string($path) || '' === $path) {
		return false;
	}
	$real_file = realpath($path);
	$real_dir  = realpath($import_dir);
	if (false === $real_file || false === $real_dir) {
		return false;
	}
	return 0 === strpos($real_file, $real_dir . DIRECTORY_SEPARATOR) && is_file($real_file);
};

// Remove abandoned import files older than 24 hours.
if (is_dir($import_dir)) {
	$stale = glob($import_dir . '/*.csv');
	if (is_array($stale)) {
		$now = time();
		foreach ($stale as $stale_file) {
			$mtime = @filemtime($stale_file);
			if ($mtime && ($now - $mtime) > DAY_IN_SECONDS) {
				@unlink($stale_file);
			}
		}
	}
}

$step         = isset($_POST['step']) ? absint($_POST['step']) : 1;
$import_ready = false;
$import_token = '';
$list_id      = 0;
$headers      = array();
$first_row    = array();

// STEP 3: Run Import
if (3 === $step && check_admin_referer('wpnews_import_run', 'wpnews_nonce')) {
	$posted_token = isset($_POST['import_token']) ? sanitize_text_field(wp_unslash($_POST['import_token'])) : '';
	$pending      = get_transient($transient_key);

	$pending_file  = is_array($pending) && isset($pending['file']) ? (string) $pending['file'] : '';
	$pending_token = is_array($pending) && isset($pending['token']) ? (string) $pending['token'] : '';
	$list_id       = isset($_POST['list_id']) ? absint($_POST['list_id']) : (int) ($pending['list_id'] ?? 0);

	$file_valid = '' !== $posted_token && '' !== $pending_token
		&& hash_equals($pending_token, $posted_token)
		&& $wpnews_path_in_import_dir($pending_file);

	$mapping = array(
		'email'      => isset($_POST['col_email']) ? intval($_POST['col_email']) : -1,
		'first_name' => isset($_POST['col_first_name']) ? intval($_POST['col_first_name']) : -1,
		'last_name'  => isset($_POST['col_last_name']) ? intval($_POST['col_last_name']) : -1,
	);

	if ($file_valid && $mapping['email'] >= 0 && $list_id > 0) {
		$result = WPNews_List_Manager::import_subscribers_from_csv($pending_file, $list_id, $mapping);
		/* translators: 1: number of imported rows, 2: number of errors */
		echo '<div class="notice notice-success is-dismissible"><p>' . sprintf(esc_html__('Import completed. Success: %1$d, Errors: %2$d', 'wp-news'), (int) ($result['success_count'] ?? 0), (int) ($result['error_count'] ?? 0)) . '</p></div>';
		if (!empty($result['errors']) && is_array($result['errors'])) {
			echo '<div class="notice notice-error"><p>' . esc_html__('Errors:', 'wp-news') . '</p><ul>';
			foreach ($result['errors'] as $error) {
				if (is_array($error)) {
					echo '<li>' . esc_html((string) ($error['message'] ?? '') . ' (' . (string) ($error['email'] ?? '') . ')') . '</li>';
				} else {
					echo '<li>' . esc_html((string) $error) . '</li>';
				}
			}
			echo '</ul></div>';
		}
	} else {
		echo '<div class="notice notice-error"><p>' . esc_html__('Invalid or expired import session, file or mapping. Please upload the file again.', 'wp-news') . '</p></div>';
	}

	// Always clean up, whatever the outcome.
	if ($file_valid) {
		@unlink($pending_file);
	}
	delete_transient($transient_key);
	$step = 1;
}

// STEP 2: Upload, validate, store, show mapping
if (2 === $step && check_admin_referer('wpnews_import_upload', 'wpnews_nonce')) {
	$list_id      = isset($_POST['list_id']) ? absint($_POST['list_id']) : 0;
	$upload       = isset($_FILES['import_file']) && is_array($_FILES['import_file']) ? $_FILES['import_file'] : null;
	$upload_error = '';

	if ($list_id <= 0) {
		$upload_error = __('Please select a list.', 'wp-news');
	} elseif (
		!$upload
		|| empty($upload['tmp_name'])
		|| UPLOAD_ERR_OK !== (int) ($upload['error'] ?? UPLOAD_ERR_NO_FILE)
		|| !is_uploaded_file($upload['tmp_name'])
	) {
		$upload_error = __('Please select a valid CSV file.', 'wp-news');
	} else {
		$ext = strtolower(pathinfo((string) ($upload['name'] ?? ''), PATHINFO_EXTENSION));
		if ('csv' !== $ext) {
			$upload_error = __('Only .csv files are allowed.', 'wp-news');
		} elseif (class_exists('finfo')) {
			$finfo = new finfo(FILEINFO_MIME_TYPE);
			$mime  = (string) $finfo->file($upload['tmp_name']);
			if (!in_array($mime, array('text/plain', 'text/csv', 'application/csv'), true)) {
				/* translators: %s: detected MIME type */
				$upload_error = sprintf(__('The uploaded file is not a CSV text file (detected type: %s).', 'wp-news'), $mime);
			}
		}
	}

	if ('' === $upload_error) {
		if (!$wpnews_prepare_import_dir()) {
			$upload_error = __('Could not create the import directory.', 'wp-news');
		} else {
			$target_file = $import_dir . '/' . wp_generate_password(32, false, false) . '.csv';
			if (!move_uploaded_file($upload['tmp_name'], $target_file)) {
				$upload_error = __('Failed to store the uploaded file.', 'wp-news');
			} else {
				@chmod($target_file, 0600);
				$import_token = wp_generate_password(32, false, false);
				set_transient($transient_key, array(
					'file'    => $target_file,
					'token'   => $import_token,
					'list_id' => $list_id,
				), HOUR_IN_SECONDS);

				// Read header + first data row for the mapping preview.
				$handle = fopen($target_file, 'r');
				if ($handle) {
					$bom = fread($handle, 3);
					if ("\xEF\xBB\xBF" !== $bom) {
						rewind($handle);
					}
					$preview_line = fgets($handle);
					$delimiter    = ($preview_line && substr_count($preview_line, ';') > substr_count($preview_line, ',')) ? ';' : ',';
					rewind($handle);
					if ("\xEF\xBB\xBF" === $bom) {
						fread($handle, 3);
					}
					$headers   = fgetcsv($handle, 0, $delimiter, '"', '\\');
					$first_row = fgetcsv($handle, 0, $delimiter, '"', '\\');
					fclose($handle);
				}
				$headers   = is_array($headers) ? array_map('strval', $headers) : array();
				$first_row = is_array($first_row) ? array_map('strval', $first_row) : array();

				if (empty($headers)) {
					$upload_error = __('The CSV file appears to be empty.', 'wp-news');
					@unlink($target_file);
					delete_transient($transient_key);
				} else {
					$import_ready = true;
				}
			}
		}
	}

	if ('' !== $upload_error) {
		echo '<div class="notice notice-error"><p>' . esc_html($upload_error) . '</p></div>';
		$step = 1;
	}
}

// Result of a subscriber action (admin-post.php redirects back with wpnews_msg).
$wpnews_sub_msgs = array(
	'sub_deleted'        => array('success', __('Subscriber deleted.', 'wp-news')),
	'sub_blacklisted'    => array('success', __('Subscriber blacklisted.', 'wp-news')),
	'resend_ok'          => array('success', __('Confirmation email sent again.', 'wp-news')),
	'resend_recent'      => array('warning', __('A confirmation email was sent to this address less than 2 minutes ago.', 'wp-news')),
	'resend_not_pending' => array('warning', __('This subscriber is not waiting for confirmation.', 'wp-news')),
	'resend_failed'      => array('error', __('The confirmation email could not be sent. Check the sending method in Settings.', 'wp-news')),
	'error'              => array('error', __('The action could not be completed. Please try again.', 'wp-news')),
);
$wpnews_sub_msg = isset($_GET['wpnews_msg']) ? sanitize_key(wp_unslash($_GET['wpnews_msg'])) : '';
if (isset($wpnews_sub_msgs[$wpnews_sub_msg])) {
	printf('<div class="notice notice-%1$s is-dismissible"><p>%2$s</p></div>', esc_attr($wpnews_sub_msgs[$wpnews_sub_msg][0]), esc_html($wpnews_sub_msgs[$wpnews_sub_msg][1]));
}

// Handle Bulk Resend confirmation
if (isset($_POST['bulk_action']) && 'resend' === $_POST['bulk_action'] && !empty($_POST['subscriber_ids'])) {
	if (check_admin_referer('wpnews_bulk_action', 'wpnews_bulk_nonce')) {
		$wpnews_sent = 0;
		$wpnews_skipped = 0;
		foreach (array_slice(array_map('absint', (array) wp_unslash($_POST['subscriber_ids'])), 0, 100) as $sid) {
			if ($sid > 0 && 'resend_ok' === WPNews_Admin::resend_confirmation($sid)) {
				$wpnews_sent++;
			} else {
				$wpnews_skipped++;
			}
		}
		echo '<div class="notice notice-success is-dismissible"><p>' . esc_html(sprintf(
			/* translators: 1: emails sent, 2: subscribers skipped */
			__('Confirmation email sent again to %1$d subscribers (%2$d skipped: not pending or sent less than 2 minutes ago).', 'wp-news'),
			$wpnews_sent,
			$wpnews_skipped
		)) . '</p></div>';
	}
}

// Handle Bulk Blacklist
if (isset($_POST['bulk_action']) && 'blacklist' === $_POST['bulk_action'] && !empty($_POST['subscriber_ids'])) {
	if (check_admin_referer('wpnews_bulk_action', 'wpnews_bulk_nonce')) {
		$count = 0;
		foreach (array_map('absint', (array) wp_unslash($_POST['subscriber_ids'])) as $sid) {
			if ($sid > 0) {
				WPNews_List_Manager::blacklist_subscriber($sid);
				$count++;
			}
		}
		/* translators: %d: number of subscribers */
		echo '<div class="notice notice-success is-dismissible"><p>' . sprintf(esc_html__('%d subscribers blacklisted.', 'wp-news'), $count) . '</p></div>';
	}
}

// Filters
$search        = isset($_GET['s']) ? sanitize_text_field(wp_unslash($_GET['s'])) : '';
$status_filter = isset($_GET['status']) ? sanitize_key(wp_unslash($_GET['status'])) : '';
if (!in_array($status_filter, array('', 'active', 'unsubscribed', 'pending'), true)) {
	$status_filter = '';
}
$list_filter = isset($_GET['list']) ? absint($_GET['list']) : 0;

// Pagination
$page   = isset($_GET['paged']) ? max(1, absint($_GET['paged'])) : 1;
$limit  = 25;
$offset = ($page - 1) * $limit;

$subscribers       = WPNews_List_Manager::get_all_subscribers($limit, $offset, $search, $status_filter, $list_filter);
$total_subscribers = (int) WPNews_List_Manager::count_all_subscribers($search, $status_filter, $list_filter);
$total_pages       = (int) ceil($total_subscribers / $limit);
$lists             = WPNews_List_Manager::get_lists();
if (!is_array($subscribers)) {
	$subscribers = array();
}
if (!is_array($lists)) {
	$lists = array();
}

// Batch-fetch list memberships for current page
$subscriber_ids = wp_list_pluck($subscribers, 'id');
$memberships    = WPNews_List_Manager::get_subscriber_list_memberships($subscriber_ids);
if (!is_array($memberships)) {
	$memberships = array();
}

// Badge colors for lists (auto-assigned from palette)
$list_colors = array('#6366f1', '#ec4899', '#f59e0b', '#10b981', '#3b82f6', '#8b5cf6', '#ef4444', '#14b8a6', '#f97316', '#06b6d4');

// Filter URL helper
$filter_params = array();
if ('' !== $search) {
	$filter_params['s'] = rawurlencode($search);
}
if ('' !== $status_filter) {
	$filter_params['status'] = $status_filter;
}
if ($list_filter > 0) {
	$filter_params['list'] = $list_filter;
}
$has_filters = !empty($filter_params);
$filtered_url = add_query_arg($filter_params, $base_url);

$page_links = paginate_links(array(
	'base'      => add_query_arg('paged', '%#%', $filtered_url),
	'format'    => '',
	'prev_text' => '&laquo;',
	'next_text' => '&raquo;',
	'total'     => $total_pages,
	'current'   => $page,
));
?>
<div class="wpnews-admin-wrap">
	<div class="wpnews-header">
		<h1><?php esc_html_e('Subscribers', 'wp-news'); ?></h1>
	</div>

	<?php if (2 === $step && $import_ready) : ?>
		<!-- Import Step 2: Map Columns -->
		<div class="wpnews-card wpnews-mt-20">
			<h2><?php esc_html_e('Step 2: Map Columns', 'wp-news'); ?></h2>
			<p><?php esc_html_e('Please map the columns from your CSV file to the subscriber fields.', 'wp-news'); ?></p>

			<form method="post" action="<?php echo esc_url($base_url); ?>">
				<?php wp_nonce_field('wpnews_import_run', 'wpnews_nonce'); ?>
				<input type="hidden" name="step" value="3">
				<input type="hidden" name="list_id" value="<?php echo esc_attr($list_id); ?>">
				<input type="hidden" name="import_token" value="<?php echo esc_attr($import_token); ?>">

				<table class="wpnews-table wpnews-mb-20">
					<thead>
						<tr>
							<th><?php esc_html_e('CSV Column', 'wp-news'); ?></th>
							<th><?php esc_html_e('First Row Preview', 'wp-news'); ?></th>
						</tr>
					</thead>
					<tbody>
						<?php foreach ($headers as $index => $col_name) : ?>
							<tr>
								<td><strong><?php echo esc_html($col_name); ?></strong></td>
								<td><?php echo isset($first_row[$index]) ? esc_html($first_row[$index]) : '-'; ?></td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>

				<hr>
				<h3><?php esc_html_e('Start Mapping', 'wp-news'); ?></h3>
				<table class="form-table">
					<tr>
						<th><label for="col_email"><?php esc_html_e('Email Column', 'wp-news'); ?></label></th>
						<td>
							<select name="col_email" id="col_email">
								<?php foreach ($headers as $i => $h) : ?>
									<option value="<?php echo (int) $i; ?>" <?php selected(stripos($h, 'email') !== false || stripos($h, 'e-mail') !== false); ?>><?php echo esc_html($h); ?></option>
								<?php endforeach; ?>
							</select>
						</td>
					</tr>
					<tr>
						<th><label for="col_first_name"><?php esc_html_e('First Name Column', 'wp-news'); ?></label></th>
						<td>
							<select name="col_first_name" id="col_first_name">
								<option value="-1"><?php esc_html_e('-- Skip --', 'wp-news'); ?></option>
								<?php foreach ($headers as $i => $h) : ?>
									<option value="<?php echo (int) $i; ?>" <?php selected(stripos($h, 'first') !== false || (stripos($h, 'name') !== false && stripos($h, 'last') === false)); ?>><?php echo esc_html($h); ?></option>
								<?php endforeach; ?>
							</select>
						</td>
					</tr>
					<tr>
						<th><label for="col_last_name"><?php esc_html_e('Last Name Column', 'wp-news'); ?></label></th>
						<td>
							<select name="col_last_name" id="col_last_name">
								<option value="-1"><?php esc_html_e('-- Skip --', 'wp-news'); ?></option>
								<?php foreach ($headers as $i => $h) : ?>
									<option value="<?php echo (int) $i; ?>" <?php selected(stripos($h, 'last') !== false || stripos($h, 'surname') !== false); ?>><?php echo esc_html($h); ?></option>
								<?php endforeach; ?>
							</select>
						</td>
					</tr>
				</table>

				<p class="submit">
					<input type="submit" class="button button-primary" value="<?php esc_attr_e('Run Import', 'wp-news'); ?>">
					<a href="<?php echo esc_url($base_url); ?>" class="button"><?php esc_html_e('Cancel', 'wp-news'); ?></a>
				</p>
			</form>
		</div>

	<?php else : ?>

		<!-- Import Step 1 -->
		<div class="wpnews-card wpnews-import-compact">
			<div class="wpnews-card-title">
				<span class="dashicons dashicons-upload wpnews-text-indigo"></span>
				<h3><?php esc_html_e('Import Subscribers', 'wp-news'); ?></h3>
			</div>
			<form method="post" enctype="multipart/form-data" action="<?php echo esc_url($base_url); ?>">
				<?php wp_nonce_field('wpnews_import_upload', 'wpnews_nonce'); ?>
				<input type="hidden" name="step" value="2">
				<div class="wpnews-form-row">
					<div>
						<label class="wpnews-field-label" for="wpnews-import-list"><?php esc_html_e('List', 'wp-news'); ?></label>
						<select name="list_id" id="wpnews-import-list" required class="wpnews-input wpnews-input--select">
							<option value=""><?php esc_html_e('-- Select --', 'wp-news'); ?></option>
							<?php foreach ($lists as $l) : ?>
								<option value="<?php echo esc_attr((int) $l['id']); ?>"><?php echo esc_html((string) $l['name']); ?></option>
							<?php endforeach; ?>
						</select>
					</div>
					<div>
						<label class="wpnews-field-label"><?php esc_html_e('CSV File', 'wp-news'); ?></label>
						<input type="file" name="import_file" accept=".csv,text/csv,text/plain" id="wpnews-csv-file" class="wpnews-visually-hidden">
						<div class="wpnews-inline-field">
							<button type="button" id="wpnews-csv-choose" class="wpnews-btn wpnews-btn-outline">
								<span class="dashicons dashicons-media-spreadsheet"></span>
								<?php esc_html_e('Choose File', 'wp-news'); ?>
							</button>
							<span id="wpnews-csv-filename" class="wpnews-small-muted"><?php esc_html_e('No file chosen', 'wp-news'); ?></span>
						</div>
					</div>
					<div>
						<button type="submit" class="wpnews-btn wpnews-btn-primary">
							<span class="dashicons dashicons-database-import"></span>
							<?php esc_html_e('Map & Import', 'wp-news'); ?>
						</button>
					</div>
					<div class="wpnews-ml-auto">
						<button type="button" id="wpnews-import-mailpoet" class="wpnews-btn wpnews-btn-outline">
							<span class="dashicons dashicons-download"></span>
							<?php esc_html_e('Import from MailPoet', 'wp-news'); ?>
						</button>
					</div>
				</div>
			</form>
		</div>

	<?php endif; ?>

	<!-- Subscribers List -->
	<div class="wpnews-card wpnews-mt-0">
		<div class="wpnews-subscriber-toolbar">
			<form method="get" action="<?php echo esc_url($admin_base); ?>" class="wpnews-toolbar-form">
				<input type="hidden" name="page" value="wp-news-subscribers">

				<div class="wpnews-search-wrap">
					<span class="dashicons dashicons-search wpnews-search-icon"></span>
					<input type="search" name="s" value="<?php echo esc_attr($search); ?>" placeholder="<?php esc_attr_e('Search by email or name...', 'wp-news'); ?>" class="wpnews-search-input">
				</div>

				<div class="wpnews-filter-group">
					<select name="status" class="wpnews-filter-select">
						<option value=""><?php esc_html_e('All statuses', 'wp-news'); ?></option>
						<option value="active" <?php selected($status_filter, 'active'); ?>><?php esc_html_e('Active', 'wp-news'); ?></option>
						<option value="pending" <?php selected($status_filter, 'pending'); ?>><?php esc_html_e('Pending', 'wp-news'); ?></option>
						<option value="unsubscribed" <?php selected($status_filter, 'unsubscribed'); ?>><?php esc_html_e('Unsubscribed', 'wp-news'); ?></option>
					</select>

					<select name="list" class="wpnews-filter-select">
						<option value=""><?php esc_html_e('All lists', 'wp-news'); ?></option>
						<?php foreach ($lists as $l) : ?>
							<option value="<?php echo esc_attr((int) $l['id']); ?>" <?php selected($list_filter, (int) $l['id']); ?>><?php echo esc_html((string) $l['name']); ?> (<?php echo esc_html(number_format_i18n((int) ($l['subscriber_count'] ?? 0))); ?>)</option>
						<?php endforeach; ?>
					</select>

					<button type="submit" class="wpnews-btn wpnews-btn-primary">
						<span class="dashicons dashicons-filter"></span>
						<?php esc_html_e('Filter', 'wp-news'); ?>
					</button>

					<?php if ($has_filters) : ?>
						<a href="<?php echo esc_url($base_url); ?>" class="wpnews-btn wpnews-btn-ghost">
							<span class="dashicons dashicons-dismiss"></span>
							<?php esc_html_e('Clear', 'wp-news'); ?>
						</a>
					<?php endif; ?>
				</div>
			</form>
		</div>

		<?php if (!empty($subscribers)) : ?>
			<div class="wpnews-stats-bar">
				<span class="wpnews-stats-count">
					<strong><?php echo esc_html(number_format_i18n($total_subscribers)); ?></strong> <?php esc_html_e('subscribers', 'wp-news'); ?>
					<?php if ($has_filters) : ?>
						<span class="wpnews-small-muted">(<?php esc_html_e('filtered', 'wp-news'); ?>)</span>
					<?php endif; ?>
				</span>
				<div class="tablenav-pages">
					<?php if ($page_links) : ?><span class="pagination-links"><?php echo wp_kses_post($page_links); ?></span><?php endif; ?>
				</div>
			</div>

			<form method="post" id="wpnews-bulk-form" action="<?php echo esc_url($filtered_url); ?>">
				<?php wp_nonce_field('wpnews_bulk_action', 'wpnews_bulk_nonce'); ?>

				<div class="wpnews-bulk-bar" id="wpnews-sub-bulk-bar" style="display:none;">
					<span id="wpnews-selected-count">0</span>&nbsp;<?php esc_html_e('selected', 'wp-news'); ?>
					<button type="submit" name="bulk_action" value="resend" class="wpnews-btn wpnews-btn-primary wpnews-ml-12" data-wpnews-confirm="<?php esc_attr_e('Send the confirmation email again to the selected subscribers who are waiting for confirmation?', 'wp-news'); ?>">
						<span class="dashicons dashicons-email-alt"></span>
						<?php esc_html_e('Resend confirmation', 'wp-news'); ?>
					</button>
					<button type="submit" name="bulk_action" value="blacklist" class="wpnews-btn wpnews-btn-danger wpnews-ml-12" data-wpnews-confirm="<?php esc_attr_e('Blacklist all selected subscribers?', 'wp-news'); ?>">
						<span class="dashicons dashicons-shield"></span>
						<?php esc_html_e('Blacklist Selected', 'wp-news'); ?>
					</button>
				</div>

				<table class="wpnews-table wpnews-subscriber-table">
					<thead>
						<tr>
							<th class="wpnews-col-center" style="width:36px;"><input type="checkbox" id="wpnews-sub-select-all"></th>
							<th><?php esc_html_e('Email', 'wp-news'); ?></th>
							<th><?php esc_html_e('Name', 'wp-news'); ?></th>
							<th><?php esc_html_e('Lists', 'wp-news'); ?></th>
							<th style="width:90px;"><?php esc_html_e('Status', 'wp-news'); ?></th>
							<th style="width:100px;"><?php esc_html_e('Date', 'wp-news'); ?></th>
							<th style="width:140px;"><?php esc_html_e('Actions', 'wp-news'); ?></th>
						</tr>
					</thead>
					<tbody>
						<?php foreach ($subscribers as $s) :
							$sid          = (int) ($s['id'] ?? 0);
							$s_email      = (string) ($s['email'] ?? '');
							$s_status     = (string) ($s['status'] ?? '');
							$sub_lists    = isset($memberships[$sid]) && is_array($memberships[$sid]) ? $memberships[$sid] : array();
							$sub_list_ids = array_map(static function ($l) {
								return (int) ($l['list_id'] ?? 0);
							}, $sub_lists);
							$full_name    = trim((string) ($s['first_name'] ?? '') . ' ' . (string) ($s['last_name'] ?? ''));
							$sub_ts       = !empty($s['subscribed_at']) ? strtotime((string) $s['subscribed_at']) : false;

							$row_action_args = $filter_params;
							$back_args       = array_map('rawurldecode', $row_action_args) + (isset($_GET['paged']) ? array('paged' => absint($_GET['paged'])) : array());
							$blacklist_url   = WPNews_Admin::subscriber_action_url('blacklist', $sid, $back_args);
							$delete_url      = WPNews_Admin::subscriber_action_url('delete', $sid, $back_args);
							$resend_url      = WPNews_Admin::subscriber_action_url('resend', $sid, $back_args);
							?>
							<tr class="wpnews-row-main" id="wpnews-row-<?php echo esc_attr($sid); ?>">
								<td class="wpnews-col-center">
									<input type="checkbox" name="subscriber_ids[]" value="<?php echo esc_attr($sid); ?>" class="wpnews-sub-check">
								</td>
								<td><span class="wpnews-email"><?php echo esc_html($s_email); ?></span></td>
								<td>
									<?php if ('' !== $full_name) : ?>
										<span class="wpnews-name"><?php echo esc_html($full_name); ?></span>
									<?php else : ?>
										<span class="wpnews-dash">—</span>
									<?php endif; ?>
								</td>
								<td>
									<?php if (!empty($sub_lists)) : ?>
										<div class="wpnews-list-badges">
											<?php foreach ($sub_lists as $sl) :
												$color = $list_colors[((int) ($sl['list_id'] ?? 0)) % count($list_colors)];
												?>
												<span class="wpnews-list-badge" style="--list-color:<?php echo esc_attr($color); ?>;"><?php echo esc_html((string) ($sl['name'] ?? '')); ?></span>
											<?php endforeach; ?>
										</div>
									<?php else : ?>
										<span class="wpnews-small-muted"><?php esc_html_e('No lists', 'wp-news'); ?></span>
									<?php endif; ?>
								</td>
								<td>
									<span class="wpnews-badge <?php echo esc_attr($s_status); ?>"><?php echo esc_html(ucfirst($s_status)); ?></span>
									<?php if (!empty($s['lang'])) : ?>
										<span class="wpnews-lang-badge" title="<?php esc_attr_e('Language', 'wp-news'); ?>"><?php echo esc_html(strtoupper((string) $s['lang'])); ?></span>
									<?php endif; ?>
								</td>
								<td class="wpnews-cell-date"><?php echo $sub_ts ? esc_html(date_i18n('Y-m-d', $sub_ts)) : '—'; ?></td>
								<td>
									<div class="wpnews-action-btns">
										<button type="button" class="wpnews-btn wpnews-btn-sm wpnews-btn-edit" data-id="<?php echo esc_attr($sid); ?>" title="<?php esc_attr_e('Edit', 'wp-news'); ?>">
											<span class="dashicons dashicons-edit"></span>
										</button>
										<?php if ('pending' === $s_status) : ?>
											<a href="<?php echo esc_url($resend_url); ?>" class="wpnews-btn wpnews-btn-sm wpnews-btn-resend" title="<?php esc_attr_e('Resend confirmation email', 'wp-news'); ?>" aria-label="<?php esc_attr_e('Resend confirmation email', 'wp-news'); ?>">
												<span class="dashicons dashicons-email-alt"></span>
											</a>
										<?php endif; ?>
										<?php if ('active' === $s_status) : ?>
											<button type="button" class="wpnews-btn wpnews-btn-sm wpnews-btn-warning wpnews-blacklist-btn" data-email="<?php echo esc_attr($s_email); ?>" data-url="<?php echo esc_url($blacklist_url); ?>" title="<?php esc_attr_e('Blacklist', 'wp-news'); ?>">
												<span class="dashicons dashicons-shield"></span>
											</button>
										<?php endif; ?>
										<button type="button" class="wpnews-btn wpnews-btn-sm wpnews-btn-danger-outline wpnews-delete-btn" data-email="<?php echo esc_attr($s_email); ?>" data-url="<?php echo esc_url($delete_url); ?>" title="<?php esc_attr_e('Delete', 'wp-news'); ?>">
											<span class="dashicons dashicons-trash"></span>
										</button>
									</div>
								</td>
							</tr>
							<!-- Inline edit row (hidden by default) -->
							<tr class="wpnews-row-edit" id="wpnews-edit-<?php echo esc_attr($sid); ?>" style="display:none;">
								<td colspan="7">
									<div class="wpnews-edit-panel">
										<div class="wpnews-edit-grid">
											<div class="wpnews-edit-field">
												<label><?php esc_html_e('Email', 'wp-news'); ?></label>
												<input type="email" class="wpnews-edit-input" data-field="email" value="<?php echo esc_attr($s_email); ?>">
											</div>
											<div class="wpnews-edit-field">
												<label><?php esc_html_e('First Name', 'wp-news'); ?></label>
												<input type="text" class="wpnews-edit-input" data-field="first_name" value="<?php echo esc_attr((string) ($s['first_name'] ?? '')); ?>">
											</div>
											<div class="wpnews-edit-field">
												<label><?php esc_html_e('Last Name', 'wp-news'); ?></label>
												<input type="text" class="wpnews-edit-input" data-field="last_name" value="<?php echo esc_attr((string) ($s['last_name'] ?? '')); ?>">
											</div>
											<div class="wpnews-edit-field">
												<label><?php esc_html_e('Status', 'wp-news'); ?></label>
												<select class="wpnews-edit-input" data-field="status">
													<option value="active" <?php selected($s_status, 'active'); ?>><?php esc_html_e('Active', 'wp-news'); ?></option>
													<option value="unsubscribed" <?php selected($s_status, 'unsubscribed'); ?>><?php esc_html_e('Unsubscribed', 'wp-news'); ?></option>
												</select>
											</div>
										</div>
										<div class="wpnews-edit-lists">
											<label><?php esc_html_e('Mailing Lists', 'wp-news'); ?></label>
											<div class="wpnews-edit-list-grid">
												<?php foreach ($lists as $l) :
													$lid   = (int) $l['id'];
													$color = $list_colors[$lid % count($list_colors)];
													?>
													<label class="wpnews-edit-list-item" style="--list-color:<?php echo esc_attr($color); ?>;">
														<input type="checkbox" value="<?php echo esc_attr($lid); ?>" class="wpnews-edit-list-cb" <?php checked(in_array($lid, $sub_list_ids, true)); ?>>
														<span class="wpnews-edit-list-label"><?php echo esc_html((string) $l['name']); ?></span>
													</label>
												<?php endforeach; ?>
											</div>
										</div>
										<div class="wpnews-edit-actions">
											<button type="button" class="wpnews-btn wpnews-btn-primary wpnews-save-btn" data-id="<?php echo esc_attr($sid); ?>">
												<span class="dashicons dashicons-saved"></span>
												<?php esc_html_e('Save', 'wp-news'); ?>
											</button>
											<button type="button" class="wpnews-btn wpnews-btn-ghost wpnews-cancel-btn" data-id="<?php echo esc_attr($sid); ?>">
												<?php esc_html_e('Cancel', 'wp-news'); ?>
											</button>
											<span class="wpnews-save-status" id="wpnews-status-<?php echo esc_attr($sid); ?>"></span>
										</div>
									</div>
								</td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			</form>

			<div class="wpnews-stats-bar wpnews-stats-bar--bottom">
				<span></span>
				<div class="tablenav-pages">
					<?php if ($page_links) : ?><span class="pagination-links"><?php echo wp_kses_post($page_links); ?></span><?php endif; ?>
				</div>
			</div>

		<?php else : ?>
			<div class="wpnews-empty">
				<span class="dashicons dashicons-groups wpnews-empty__icon"></span>
				<p>
					<?php if ($has_filters) : ?>
						<?php esc_html_e('No subscribers match your filters.', 'wp-news'); ?>
						<a href="<?php echo esc_url($base_url); ?>"><?php esc_html_e('Clear filters', 'wp-news'); ?></a>
					<?php else : ?>
						<?php esc_html_e('No subscribers found. Import some using the form above.', 'wp-news'); ?>
					<?php endif; ?>
				</p>
			</div>
		<?php endif; ?>
	</div>
</div>
