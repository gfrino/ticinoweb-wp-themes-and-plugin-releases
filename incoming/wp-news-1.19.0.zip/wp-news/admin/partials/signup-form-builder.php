<?php
/**
 * Signup form builder: pick a list by name, set the options, see a live
 * preview and copy a ready-made [wpnews_subscribe_form] shortcode.
 *
 * Expects:
 *   $wpnews_builder_lists    array of lists (WPNews_List_Manager::get_lists()).
 *   $wpnews_builder_selected int   list preselected (0 = first list).
 *
 * The preview markup mirrors WPNews_Public::render_subscribe_form_shortcode()
 * styled with WPNEWS_STARTER_CSS; admin/js/admin.js keeps it in sync.
 *
 * @package WPNews
 */

if (!defined('ABSPATH')) {
	exit;
}

$wpnews_builder_lists    = isset($wpnews_builder_lists) && is_array($wpnews_builder_lists) ? $wpnews_builder_lists : array();
$wpnews_builder_selected = isset($wpnews_builder_selected) ? (int) $wpnews_builder_selected : 0;
$wpnews_privacy_url      = get_privacy_policy_url();
?>
<div class="wpnews-card wpnews-builder" id="wpnews-signup-builder">
	<div class="wpnews-card-title">
		<span class="dashicons dashicons-feedback wpnews-text-indigo"></span>
		<h3><?php esc_html_e('Signup form for your website', 'wp-news'); ?></h3>
		<span class="wpnews-builder__intro"><?php esc_html_e('Choose the list, adjust, copy the code and paste it into a Shortcode widget (Elementor) or block.', 'wp-news'); ?></span>
	</div>

	<?php if (empty($wpnews_builder_lists)) : ?>
		<p class="wpnews-muted-text"><?php esc_html_e('Create a mailing list first: the signup form adds new subscribers to it.', 'wp-news'); ?></p>
	<?php else : ?>
		<div class="wpnews-builder__grid">
			<div class="wpnews-builder__controls">
				<div class="wpnews-builder__row">
					<label class="wpnews-builder__field wpnews-builder__field--wide">
						<span class="wpnews-field-label"><?php esc_html_e('New subscribers join the list', 'wp-news'); ?></span>
						<select class="wpnews-input" data-b="list">
							<?php foreach ($wpnews_builder_lists as $wpnews_l) :
								$wpnews_lid = (int) ($wpnews_l['id'] ?? 0);
								$wpnews_cnt = (int) ($wpnews_l['subscriber_count'] ?? 0);
								?>
								<option value="<?php echo esc_attr($wpnews_lid); ?>" <?php selected($wpnews_builder_selected, $wpnews_lid); ?>>
									<?php
									echo esc_html(sprintf(
										/* translators: 1: list name, 2: number of subscribers */
										_n('%1$s (%2$s subscriber)', '%1$s (%2$s subscribers)', $wpnews_cnt, 'wp-news'),
										(string) ($wpnews_l['name'] ?? ''),
										number_format_i18n($wpnews_cnt)
									));
									?>
								</option>
							<?php endforeach; ?>
						</select>
					</label>
					<label class="wpnews-builder__field">
						<span class="wpnews-field-label"><?php esc_html_e('Button text', 'wp-news'); ?></span>
						<input type="text" class="wpnews-input" data-b="button" placeholder="<?php esc_attr_e('Subscribe', 'wp-news'); ?>">
					</label>
				</div>

				<div class="wpnews-builder__row">
					<label class="wpnews-builder__field wpnews-builder__field--wide">
						<span class="wpnews-field-label"><?php esc_html_e('CSS class (optional)', 'wp-news'); ?></span>
						<input type="text" class="wpnews-input" data-b="class" placeholder="<?php esc_attr_e('e.g. footer-newsletter', 'wp-news'); ?>">
					</label>
				</div>

				<div class="wpnews-builder__row">
					<label class="wpnews-builder__field">
						<span class="wpnews-field-label"><?php esc_html_e('Title (optional)', 'wp-news'); ?></span>
						<input type="text" class="wpnews-input" data-b="title" placeholder="<?php esc_attr_e('No title', 'wp-news'); ?>">
					</label>
					<label class="wpnews-builder__field">
						<span class="wpnews-field-label"><?php esc_html_e('Text under the title (optional)', 'wp-news'); ?></span>
						<input type="text" class="wpnews-input" data-b="description" placeholder="<?php esc_attr_e('e.g. One email a month, no spam.', 'wp-news'); ?>">
					</label>
				</div>

				<div class="wpnews-builder__checks">
					<label class="wpnews-check"><input type="checkbox" data-b="names" checked> <?php esc_html_e('First and last name', 'wp-news'); ?></label>
					<label class="wpnews-check"><input type="checkbox" data-b="labels" checked> <?php esc_html_e('Labels above the fields', 'wp-news'); ?></label>
					<label class="wpnews-check"><input type="checkbox" data-b="consent"> <?php esc_html_e('Privacy consent', 'wp-news'); ?></label>
				</div>
				<?php if (!$wpnews_privacy_url) : ?>
					<p class="wpnews-builder__hint" data-b-show="consent" hidden>
						<?php
						printf(
							/* translators: %s: link to Settings > Privacy */
							esc_html__('Tip: choose your privacy policy page in %s so the checkbox links to it.', 'wp-news'),
							'<a href="' . esc_url(admin_url('options-privacy.php')) . '">' . esc_html__('Settings → Privacy', 'wp-news') . '</a>'
						);
						?>
					</p>
				<?php endif; ?>
			</div>

			<div class="wpnews-builder__output">
				<div class="wpnews-shortcode-chip wpnews-shortcode-chip--big">
					<code data-b-out="code"></code>
					<button type="button" class="wpnews-copy-btn" data-copy="" title="<?php esc_attr_e('Copy shortcode', 'wp-news'); ?>">
						<span class="dashicons dashicons-admin-page" aria-hidden="true"></span>
						<span class="wpnews-copy-label"><?php esc_html_e('Copy', 'wp-news'); ?></span>
					</button>
				</div>

				<div class="wpnews-builder__preview" aria-hidden="true">
					<span class="wpnews-builder__preview-tag"><?php esc_html_e('Preview with the starter CSS below', 'wp-news'); ?></span>
					<div class="wpnews-subscribe-form wpnews-layout-stacked">
						<h3 class="wpnews-form-title" data-b-out="title" hidden></h3>
						<p class="wpnews-form-description" data-b-out="description" hidden></p>
						<div class="wpnews-form-fields">
							<div class="wpnews-form-group wpnews-field-first-name" data-b-show="names">
								<label class="wpnews-label" data-b-label><?php esc_html_e('First Name', 'wp-news'); ?></label>
								<input type="text" class="wpnews-form-input" placeholder="<?php esc_attr_e('Your first name', 'wp-news'); ?>" tabindex="-1" readonly>
							</div>
							<div class="wpnews-form-group wpnews-field-last-name" data-b-show="names">
								<label class="wpnews-label" data-b-label><?php esc_html_e('Last Name', 'wp-news'); ?></label>
								<input type="text" class="wpnews-form-input" placeholder="<?php esc_attr_e('Your last name', 'wp-news'); ?>" tabindex="-1" readonly>
							</div>
							<div class="wpnews-form-group wpnews-field-email">
								<label class="wpnews-label" data-b-label><?php esc_html_e('Email (required)', 'wp-news'); ?></label>
								<input type="email" class="wpnews-form-input" placeholder="<?php esc_attr_e('Your email', 'wp-news'); ?>" tabindex="-1" readonly>
							</div>
							<div class="wpnews-form-group wpnews-field-submit">
								<button type="button" class="wpnews-submit-btn" data-b-out="button" tabindex="-1"><?php esc_html_e('Subscribe', 'wp-news'); ?></button>
							</div>
						</div>
						<div class="wpnews-form-consent" data-b-show="consent" hidden>
							<label>
								<input type="checkbox" tabindex="-1" disabled>
								<span>
									<?php
									if ($wpnews_privacy_url) {
										printf(
											/* translators: %s: link to the privacy policy page */
											esc_html__('I agree to receive the newsletter and accept the %s.', 'wp-news'),
											'<a>' . esc_html__('privacy policy', 'wp-news') . '</a>'
										);
									} else {
										esc_html_e('I agree to receive the newsletter.', 'wp-news');
									}
									?>
								</span>
							</label>
						</div>
					</div>
				</div>

				<details class="wpnews-builder__css">
					<summary><?php esc_html_e('Style: starter CSS and classes', 'wp-news'); ?></summary>
					<p class="wpnews-builder__hint"><?php esc_html_e('On the website the form has no styling of its own: it only takes font and colours from your theme. Copy this starter CSS into Elementor → Site Settings → Custom CSS (or Appearance → Customise → Additional CSS) and change it as you like.', 'wp-news'); ?></p>
					<div class="wpnews-shortcode-chip wpnews-builder__css-copy">
						<code><?php esc_html_e('Starter CSS', 'wp-news'); ?></code>
						<button type="button" class="wpnews-copy-btn" data-copy="<?php echo esc_attr(WPNEWS_STARTER_CSS); ?>">
							<span class="dashicons dashicons-admin-page" aria-hidden="true"></span>
							<span class="wpnews-copy-label"><?php esc_html_e('Copy', 'wp-news'); ?></span>
						</button>
					</div>
					<pre class="wpnews-builder__pre"><?php echo esc_html(WPNEWS_STARTER_CSS); ?></pre>
					<p class="wpnews-builder__hint"><?php esc_html_e('Classes: .wpnews-subscribe-form (+ your class), .wpnews-form-title, .wpnews-form-description, .wpnews-form-fields, .wpnews-form-group, .wpnews-field-first-name, .wpnews-field-last-name, .wpnews-field-email, .wpnews-field-submit, .wpnews-label, .wpnews-form-input, .wpnews-submit-btn, .wpnews-form-consent, .wpnews-consent-checkbox, .wpnews-consent-text, .wpnews-message (.success / .error).', 'wp-news'); ?></p>
				</details>
				<style id="wpnews-builder-starter-css"><?php echo WPNEWS_STARTER_CSS; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static constant ?></style>
			</div>
		</div>
	<?php endif; ?>
</div>
