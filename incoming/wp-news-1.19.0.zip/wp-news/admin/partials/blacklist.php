<?php
/**
 * Blacklist admin page.
 *
 * @package WPNews
 */

if (!defined('ABSPATH')) {
	exit;
}

// Handle Import
if (isset($_POST['wpnews_import_blacklist']) && check_admin_referer('wpnews_import_blacklist', 'wpnews_nonce')) {
	if (isset($_FILES['import_file']) && !empty($_FILES['import_file']['tmp_name']) && is_uploaded_file($_FILES['import_file']['tmp_name'])) {
		$result = WPNews_Blacklist_Manager::import_blacklist_from_csv($_FILES['import_file']['tmp_name']);
		/* translators: %d: number of imported emails */
		echo '<div class="notice notice-success is-dismissible"><p>' . sprintf(esc_html__('Import completed. Added: %d', 'wp-news'), (int) ($result['success_count'] ?? 0)) . '</p></div>';
	} else {
		echo '<div class="notice notice-error is-dismissible"><p>' . esc_html__('Please select a valid CSV file.', 'wp-news') . '</p></div>';
	}
}

// Handle Add Single
if (isset($_POST['wpnews_add_blacklist']) && check_admin_referer('wpnews_add_blacklist', 'wpnews_nonce')) {
	$new_email = isset($_POST['email']) ? sanitize_email(wp_unslash($_POST['email'])) : '';
	if ('' !== $new_email && is_email($new_email)) {
		if (WPNews_Blacklist_Manager::add_to_blacklist($new_email, 'Manual block')) {
			echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__('Email added to blacklist.', 'wp-news') . '</p></div>';
		} else {
			echo '<div class="notice notice-error is-dismissible"><p>' . esc_html__('Could not add email (invalid or already exists).', 'wp-news') . '</p></div>';
		}
	} else {
		echo '<div class="notice notice-error is-dismissible"><p>' . esc_html__('Invalid email address.', 'wp-news') . '</p></div>';
	}
}

// Handle Remove
if (isset($_GET['action']) && 'remove' === $_GET['action'] && isset($_GET['email'])) {
	$remove_email = sanitize_email(wp_unslash($_GET['email']));
	if ('' !== $remove_email && check_admin_referer('wpnews_remove_blacklist_' . $remove_email, 'wpnews_nonce')) {
		if (WPNews_Blacklist_Manager::remove_from_blacklist($remove_email)) {
			echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__('Email removed from blacklist.', 'wp-news') . '</p></div>';
		} else {
			echo '<div class="notice notice-error is-dismissible"><p>' . esc_html__('Could not remove email.', 'wp-news') . '</p></div>';
		}
	}
}

global $wpdb;
$bl_table = $wpdb->prefix . 'wpnews_blacklist';
$page     = isset($_GET['paged']) ? max(1, absint($_GET['paged'])) : 1;
$per_page = 50;
$offset   = ($page - 1) * $per_page;

// Server-side filter & search
$allowed_filters = array('all', 'bounce', 'unsubscribed', 'spam', 'manual', 'import');
$reason_filter   = isset($_GET['reason_filter']) ? sanitize_key(wp_unslash($_GET['reason_filter'])) : 'all';
if (!in_array($reason_filter, $allowed_filters, true)) {
	$reason_filter = 'all';
}
$search_email = isset($_GET['search_email']) ? sanitize_text_field(wp_unslash($_GET['search_email'])) : '';

// Build WHERE clause
$where        = '1=1';
$where_params = array();

if ('bounce' === $reason_filter) {
	$where         .= ' AND reason LIKE %s';
	$where_params[] = '%bounce%';
} elseif ('unsubscribed' === $reason_filter) {
	$where         .= ' AND reason LIKE %s AND reason NOT LIKE %s AND reason NOT LIKE %s';
	$where_params[] = '%Unsubscribed%';
	$where_params[] = '%import%';
	$where_params[] = '%MailPoet%';
} elseif ('spam' === $reason_filter) {
	$where         .= ' AND (reason LIKE %s OR reason LIKE %s)';
	$where_params[] = '%spam%';
	$where_params[] = '%complaint%';
} elseif ('manual' === $reason_filter) {
	$where         .= ' AND reason LIKE %s';
	$where_params[] = '%Manual%';
} elseif ('import' === $reason_filter) {
	$where         .= ' AND (reason LIKE %s OR reason LIKE %s)';
	$where_params[] = '%import%';
	$where_params[] = '%MailPoet%';
}

if ('' !== $search_email) {
	$where         .= ' AND email LIKE %s';
	$where_params[] = '%' . $wpdb->esc_like($search_email) . '%';
}

// Counts by category in ONE query (always unfiltered, used by the pills).
$counts = $wpdb->get_row(
	"SELECT
		COUNT(*) AS total_all,
		SUM(CASE WHEN reason LIKE '%bounce%' THEN 1 ELSE 0 END) AS cnt_bounce,
		SUM(CASE WHEN reason LIKE '%Unsubscribed%' AND reason NOT LIKE '%import%' AND reason NOT LIKE '%MailPoet%' THEN 1 ELSE 0 END) AS cnt_unsub,
		SUM(CASE WHEN reason LIKE '%spam%' OR reason LIKE '%complaint%' THEN 1 ELSE 0 END) AS cnt_spam,
		SUM(CASE WHEN reason LIKE '%Manual%' THEN 1 ELSE 0 END) AS cnt_manual,
		SUM(CASE WHEN reason LIKE '%import%' OR reason LIKE '%MailPoet%' THEN 1 ELSE 0 END) AS cnt_import
	FROM $bl_table",
	ARRAY_A
);
if (!is_array($counts)) {
	$counts = array();
}
$total_all  = (int) ($counts['total_all'] ?? 0);
$cnt_bounce = (int) ($counts['cnt_bounce'] ?? 0);
$cnt_unsub  = (int) ($counts['cnt_unsub'] ?? 0);
$cnt_spam   = (int) ($counts['cnt_spam'] ?? 0);
$cnt_manual = (int) ($counts['cnt_manual'] ?? 0);
$cnt_import = (int) ($counts['cnt_import'] ?? 0);

// Fetch filtered list
if (!empty($where_params)) {
	$total_items        = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $bl_table WHERE $where", $where_params));
	$blacklisted_emails = $wpdb->get_results($wpdb->prepare("SELECT * FROM $bl_table WHERE $where ORDER BY blacklisted_at DESC LIMIT %d OFFSET %d", array_merge($where_params, array($per_page, $offset))), ARRAY_A);
} else {
	$total_items        = (int) $wpdb->get_var("SELECT COUNT(*) FROM $bl_table WHERE $where");
	$blacklisted_emails = $wpdb->get_results($wpdb->prepare("SELECT * FROM $bl_table WHERE $where ORDER BY blacklisted_at DESC LIMIT %d OFFSET %d", $per_page, $offset), ARRAY_A);
}
if (!is_array($blacklisted_emails)) {
	$blacklisted_emails = array();
}
$total_pages = (int) ceil($total_items / $per_page);

if (!function_exists('wpnews_reason_cat')) {
	/**
	 * Map a free-text blacklist reason to a category slug.
	 *
	 * @param string $reason Reason text.
	 * @return string
	 */
	function wpnews_reason_cat($reason)
	{
		$r = strtolower((string) $reason);
		if (strpos($r, 'bounce') !== false) {
			return 'bounce';
		}
		if (strpos($r, 'unsubscrib') !== false && strpos($r, 'import') === false && strpos($r, 'mailpoet') === false) {
			return 'unsubscribed';
		}
		if (strpos($r, 'spam') !== false || strpos($r, 'complaint') !== false) {
			return 'spam';
		}
		if (strpos($r, 'manual') !== false) {
			return 'manual';
		}
		if (strpos($r, 'import') !== false || strpos($r, 'mailpoet') !== false) {
			return 'import';
		}
		return 'other';
	}
}

$reason_labels = array(
	'bounce'       => __('Bounce', 'wp-news'),
	'unsubscribed' => __('Unsubscribed', 'wp-news'),
	'spam'         => __('Spam', 'wp-news'),
	'manual'       => __('Manual', 'wp-news'),
	'import'       => __('Imported', 'wp-news'),
	'other'        => __('Other', 'wp-news'),
);

// Build base URL for filter links
$base_url = admin_url('admin.php?page=wp-news-blacklist');
if ('' !== $search_email) {
	$base_url = add_query_arg('search_email', rawurlencode($search_email), $base_url);
}

$pills = array(
	'all'          => array(__('All', 'wp-news'), $total_all),
	'bounce'       => array(__('Bounced', 'wp-news'), $cnt_bounce),
	'unsubscribed' => array(__('Unsubscribed', 'wp-news'), $cnt_unsub),
	'spam'         => array(__('Spam', 'wp-news'), $cnt_spam),
	'manual'       => array(__('Manual', 'wp-news'), $cnt_manual),
	'import'       => array(__('Imported', 'wp-news'), $cnt_import),
);
?>

<div class="wpnews-admin-wrap">
	<div class="wpnews-header">
		<h1><?php esc_html_e('Blacklist Management', 'wp-news'); ?></h1>
	</div>

	<!-- How emails get blacklisted -->
	<div class="wpnews-card wpnews-info-box wpnews-info-box--blue">
		<h3 class="wpnews-mb-10"><?php esc_html_e('How emails get blacklisted', 'wp-news'); ?></h3>
		<div class="wpnews-help-grid">
			<div><strong><?php esc_html_e('Bounce', 'wp-news'); ?></strong> — <?php esc_html_e('Invalid address or full mailbox. Auto-blacklisted via the provider webhook.', 'wp-news'); ?></div>
			<div><strong><?php esc_html_e('Unsubscribed', 'wp-news'); ?></strong> — <?php esc_html_e('The user clicked the unsubscribe link.', 'wp-news'); ?></div>
			<div><strong><?php esc_html_e('Spam', 'wp-news'); ?></strong> — <?php esc_html_e('Marked as spam. Auto-blacklisted via the provider webhook.', 'wp-news'); ?></div>
			<div><strong><?php esc_html_e('Manual', 'wp-news'); ?></strong> — <?php esc_html_e('Blocked by an administrator.', 'wp-news'); ?></div>
			<div><strong><?php esc_html_e('Imported', 'wp-news'); ?></strong> — <?php esc_html_e('From a CSV file or the MailPoet migration.', 'wp-news'); ?></div>
		</div>
	</div>

	<!-- Add to Blacklist -->
	<div class="wpnews-card">
		<div class="wpnews-inline-forms">
			<form method="post" class="wpnews-inline-field wpnews-flex-1">
				<?php wp_nonce_field('wpnews_add_blacklist', 'wpnews_nonce'); ?>
				<input type="email" name="email" placeholder="email@example.com" required class="regular-text wpnews-flex-1">
				<button type="submit" name="wpnews_add_blacklist" value="1" class="button wpnews-pill wpnews-btn-dark">
					<?php esc_html_e('Block Email', 'wp-news'); ?>
				</button>
			</form>
			<form method="post" enctype="multipart/form-data" class="wpnews-inline-field wpnews-inline-forms__sep">
				<?php wp_nonce_field('wpnews_import_blacklist', 'wpnews_nonce'); ?>
				<input type="file" name="import_file" accept=".csv,text/csv,text/plain" required>
				<button type="submit" name="wpnews_import_blacklist" value="1" class="button wpnews-pill">
					<?php esc_html_e('Import CSV', 'wp-news'); ?>
				</button>
			</form>
		</div>
	</div>

	<!-- Blacklist table -->
	<div class="wpnews-card wpnews-card--rounded">
		<div class="wpnews-toolbar-row">
			<p class="wpnews-muted-text wpnews-m-0">
				<?php
				/* translators: %s: total number of blacklisted emails */
				printf(esc_html__('Total: %s blacklisted emails', 'wp-news'), '<strong>' . esc_html(number_format_i18n($total_all)) . '</strong>');
				?>
				<?php if ('all' !== $reason_filter || '' !== $search_email) : ?>
					— <strong><?php echo esc_html(number_format_i18n($total_items)); ?></strong> <?php esc_html_e('shown', 'wp-news'); ?>
				<?php endif; ?>
			</p>
			<form method="get" action="<?php echo esc_url(admin_url('admin.php')); ?>" class="wpnews-inline-field">
				<input type="hidden" name="page" value="wp-news-blacklist">
				<input type="hidden" name="reason_filter" value="<?php echo esc_attr($reason_filter); ?>">
				<div class="wpnews-search-emoji wpnews-search-emoji--sm">
					<input type="search" name="search_email" value="<?php echo esc_attr($search_email); ?>" placeholder="<?php esc_attr_e('Search email...', 'wp-news'); ?>">
				</div>
				<button type="submit" class="button wpnews-pill"><?php esc_html_e('Search', 'wp-news'); ?></button>
				<?php if ('' !== $search_email) : ?>
					<a href="<?php echo esc_url(add_query_arg(array('page' => 'wp-news-blacklist', 'reason_filter' => $reason_filter), admin_url('admin.php'))); ?>" class="button wpnews-pill"><?php esc_html_e('Clear', 'wp-news'); ?></a>
				<?php endif; ?>
			</form>
		</div>

		<!-- Filter Pills (server-side links) -->
		<div class="wpnews-pill-row">
			<?php foreach ($pills as $key => $pill) : ?>
				<a href="<?php echo esc_url(add_query_arg('reason_filter', $key, $base_url)); ?>"
					class="wpnews-bl-pill <?php echo $reason_filter === $key ? 'active' : ''; ?>" data-f="<?php echo esc_attr($key); ?>">
					<?php echo esc_html($pill[0]); ?> (<?php echo esc_html(number_format_i18n($pill[1])); ?>)
				</a>
			<?php endforeach; ?>
		</div>

		<table class="wp-list-table widefat fixed striped">
			<thead>
				<tr>
					<th><?php esc_html_e('Email', 'wp-news'); ?></th>
					<th style="width:200px;"><?php esc_html_e('Reason', 'wp-news'); ?></th>
					<th style="width:160px;"><?php esc_html_e('Date Added', 'wp-news'); ?></th>
					<th style="width:90px;"><?php esc_html_e('Actions', 'wp-news'); ?></th>
				</tr>
			</thead>
			<tbody>
				<?php if (empty($blacklisted_emails)) : ?>
					<tr>
						<td colspan="4" class="wpnews-empty"><?php esc_html_e('No emails found matching the filter.', 'wp-news'); ?></td>
					</tr>
				<?php else : ?>
					<?php foreach ($blacklisted_emails as $item) :
						$item_email = (string) ($item['email'] ?? '');
						$cat        = wpnews_reason_cat($item['reason'] ?? '');
						$added_ts   = !empty($item['blacklisted_at']) ? strtotime((string) $item['blacklisted_at']) : false;
						?>
						<tr>
							<td><strong><?php echo esc_html($item_email); ?></strong></td>
							<td>
								<span class="wpnews-reason-badge wpnews-reason-badge--<?php echo esc_attr($cat); ?>"><?php echo esc_html($reason_labels[$cat] ?? $reason_labels['other']); ?></span>
								<br><span class="wpnews-small-muted"><?php echo esc_html((string) ($item['reason'] ?? '')); ?></span>
							</td>
							<td class="wpnews-cell-date"><?php echo $added_ts ? esc_html(date_i18n('M j, Y g:i a', $added_ts)) : '—'; ?></td>
							<td>
								<a href="<?php echo esc_url(wp_nonce_url(admin_url('admin.php?page=wp-news-blacklist&action=remove&email=' . rawurlencode($item_email)), 'wpnews_remove_blacklist_' . $item_email, 'wpnews_nonce')); ?>"
									class="button button-small wpnews-pill wpnews-pill--sm wpnews-btn-red-outline"
									data-wpnews-confirm="<?php esc_attr_e('Remove this email from the blacklist?', 'wp-news'); ?>">
									<?php esc_html_e('Remove', 'wp-news'); ?>
								</a>
							</td>
						</tr>
					<?php endforeach; ?>
				<?php endif; ?>
			</tbody>
		</table>

		<?php if ($total_pages > 1) : ?>
			<div class="tablenav-pages wpnews-tablenav wpnews-tablenav--center">
				<span class="pagination-links">
					<?php
					$pagination_base = add_query_arg('reason_filter', $reason_filter, $base_url);
					echo wp_kses_post(paginate_links(array(
						'base'      => add_query_arg('paged', '%#%', $pagination_base),
						'format'    => '',
						'prev_text' => '&laquo;',
						'next_text' => '&raquo;',
						'total'     => $total_pages,
						'current'   => $page,
					)));
					?>
				</span>
			</div>
		<?php endif; ?>
	</div>
</div>
