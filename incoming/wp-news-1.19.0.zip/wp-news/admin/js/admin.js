/**
 * WP-News Admin JavaScript (vanilla, no jQuery).
 *
 * Strings and endpoints are provided by wp_localize_script('wp-news-admin', 'wpNewsAdmin', ...).
 */
(function () {
	'use strict';

	var cfg = window.wpNewsAdmin || {};
	var S = cfg.strings || {};

	function t(key, fallback) {
		return Object.prototype.hasOwnProperty.call(S, key) ? S[key] : (fallback || key);
	}

	/** sprintf-lite: replaces %s / %d sequentially. */
	function fmt(str) {
		var args = Array.prototype.slice.call(arguments, 1);
		var i = 0;
		return String(str).replace(/%[sd]/g, function () {
			return args.length > i ? String(args[i++]) : '';
		});
	}

	function qs(sel, root) {
		return (root || document).querySelector(sel);
	}

	function qsa(sel, root) {
		return Array.prototype.slice.call((root || document).querySelectorAll(sel));
	}

	function onReady(fn) {
		if (document.readyState === 'loading') {
			document.addEventListener('DOMContentLoaded', fn);
		} else {
			fn();
		}
	}

	function restFetch(path, options) {
		options = options || {};
		var headers = options.headers || {};
		headers['X-WP-Nonce'] = cfg.restNonce || '';
		if (options.body && !headers['Content-Type']) {
			headers['Content-Type'] = 'application/json';
		}
		options.headers = headers;
		options.credentials = 'same-origin';
		return fetch((cfg.restRoot || '') + path, options).then(function (r) {
			return r.json().catch(function () { return {}; }).then(function (data) {
				if (!r.ok) {
					var err = new Error((data && data.message) || t('unknownError'));
					err.data = data;
					throw err;
				}
				return data;
			});
		});
	}

	function redirectAfterConfirm(btn, message) {
		var url = btn.getAttribute('data-url');
		if (!url) {
			return;
		}
		if (window.confirm(message)) {
			btn.disabled = true;
			btn.style.opacity = '0.5';
			window.location.href = url;
		}
	}

	/* ------------------------------------------------------------------
	 * Generic: any element with data-wpnews-confirm asks before proceeding
	 * (links, submit buttons). Capture phase so it runs before form submit.
	 * ------------------------------------------------------------------ */
	document.addEventListener('click', function (e) {
		var el = e.target.closest ? e.target.closest('[data-wpnews-confirm]') : null;
		if (!el) {
			return;
		}
		if (!window.confirm(el.getAttribute('data-wpnews-confirm'))) {
			e.preventDefault();
			e.stopImmediatePropagation();
		}
	}, true);

	/* ------------------------------------------------------------------
	 * Delegated "confirm then redirect" buttons (subscribers, lists).
	 * ------------------------------------------------------------------ */
	document.addEventListener('click', function (e) {
		var target = e.target.closest ? e.target : null;
		if (!target) {
			return;
		}
		var btn;

		if ((btn = target.closest('.wpnews-blacklist-btn'))) {
			e.preventDefault();
			redirectAfterConfirm(btn, fmt(t('confirmBlacklist'), btn.getAttribute('data-email')));
		} else if ((btn = target.closest('.wpnews-delete-btn'))) {
			e.preventDefault();
			redirectAfterConfirm(btn, fmt(t('confirmDelete'), btn.getAttribute('data-email')));
		} else if ((btn = target.closest('.wpnews-btn-remove'))) {
			e.preventDefault();
			redirectAfterConfirm(btn, fmt(t('confirmRemoveFromList'), btn.getAttribute('data-email')));
		} else if ((btn = target.closest('.wpnews-bl-btn'))) {
			e.preventDefault();
			redirectAfterConfirm(btn, fmt(t('confirmBlacklistGlobal'), btn.getAttribute('data-email')));
		} else if ((btn = target.closest('.wpnews-delete-list-btn'))) {
			e.preventDefault();
			redirectAfterConfirm(btn, fmt(t('confirmDeleteList'), btn.getAttribute('data-name')));
		} else if ((btn = target.closest('.wpnews-edit-list-btn'))) {
			e.preventDefault();
			var currentName = btn.getAttribute('data-name') || '';
			var newName = window.prompt(t('promptListName'), currentName);
			if (newName !== null && newName.trim() !== '' && newName.trim() !== currentName) {
				window.location.href = btn.getAttribute('data-url') + '&new_name=' + encodeURIComponent(newName.trim());
			}
		}
	});

	/* ------------------------------------------------------------------
	 * Copy-to-clipboard buttons (signup form shortcodes).
	 * ------------------------------------------------------------------ */
	function copyWithSelection(text) {
		var ta = document.createElement('textarea');
		ta.value = text;
		ta.setAttribute('readonly', '');
		ta.style.position = 'fixed';
		ta.style.opacity = '0';
		document.body.appendChild(ta);
		ta.select();
		var ok = false;
		try {
			ok = document.execCommand('copy');
		} catch (err) {
			ok = false;
		}
		document.body.removeChild(ta);
		return ok ? Promise.resolve() : Promise.reject();
	}

	/** Clipboard API first, then the selection fallback (non-HTTPS admin, denied permission). */
	function copyText(text) {
		if (navigator.clipboard && window.isSecureContext) {
			return navigator.clipboard.writeText(text).catch(function () {
				return copyWithSelection(text);
			});
		}
		return copyWithSelection(text);
	}

	document.addEventListener('click', function (e) {
		var btn = e.target.closest ? e.target.closest('.wpnews-copy-btn') : null;
		if (!btn) {
			return;
		}
		e.preventDefault();
		var label = btn.querySelector('.wpnews-copy-label');
		var original = label ? label.textContent : '';
		copyText(btn.getAttribute('data-copy') || '').then(function () {
			btn.classList.add('is-copied');
			if (label) {
				label.textContent = t('copied', 'Copied!');
			}
			setTimeout(function () {
				btn.classList.remove('is-copied');
				if (label) {
					label.textContent = original;
				}
			}, 1800);
		}, function () {
			window.prompt(t('copyManually', 'Copy the shortcode:'), btn.getAttribute('data-copy') || '');
		});
	});

	/* ------------------------------------------------------------------
	 * Signup form builder (Lists page): live shortcode + preview.
	 * ------------------------------------------------------------------ */
	function initSignupBuilder() {
		var root = qs('#wpnews-signup-builder');
		if (!root || !qs('[data-b="list"]', root)) {
			return;
		}
		var field = function (name) {
			return qs('[data-b="' + name + '"]', root);
		};
		var out = function (name) {
			return qs('[data-b-out="' + name + '"]', root);
		};
		// Characters that would break a shortcode attribute.
		var clean = function (v) {
			return String(v || '').replace(/["\[\]]/g, '').trim();
		};
		var defaults = {
			button: out('button').textContent
		};
		var cleanClass = function (v) {
			return String(v || '').replace(/[^A-Za-z0-9_\- ]/g, '').replace(/\s+/g, ' ').trim();
		};

		function update() {
			var title = clean(field('title').value);
			var desc = clean(field('description').value);
			var button = clean(field('button').value);
			var cls = cleanClass(field('class').value);
			var names = field('names').checked;
			var labels = field('labels').checked;
			var consent = field('consent').checked;

			var code = '[wpnews_subscribe_form list="' + field('list').value + '"';
			if (title) {
				code += ' title="' + title + '"';
			}
			if (desc) {
				code += ' description="' + desc + '"';
			}
			if (button) {
				code += ' button="' + button + '"';
			}
			if (!names) {
				code += ' first_name="false" last_name="false"';
			}
			if (!labels) {
				code += ' labels="false"';
			}
			if (consent) {
				code += ' consent="true"';
			}
			if (cls) {
				code += ' class="' + cls + '"';
			}
			code += ']';

			out('code').textContent = code;
			qs('.wpnews-copy-btn', root).setAttribute('data-copy', code);

			out('title').hidden = !title;
			out('title').textContent = title;
			out('description').hidden = !desc;
			out('description').textContent = desc;
			out('button').textContent = button || defaults.button;
			qsa('[data-b-label]', root).forEach(function (el) { el.classList.toggle('wpnews-sr-only', !labels); });
			qsa('[data-b-show="names"]', root).forEach(function (el) { el.hidden = !names; });
			qsa('[data-b-show="consent"]', root).forEach(function (el) { el.hidden = !consent; });
		}

		root.addEventListener('input', update);
		root.addEventListener('change', update);

		// "Signup form" buttons on the list cards: preselect that list and jump here.
		document.addEventListener('click', function (e) {
			var btn = e.target.closest ? e.target.closest('[data-wpnews-builder-list]') : null;
			if (!btn) {
				return;
			}
			e.preventDefault();
			field('list').value = btn.getAttribute('data-wpnews-builder-list');
			update();
			root.scrollIntoView({ behavior: 'smooth', block: 'start' });
			root.classList.remove('is-flash');
			void root.offsetWidth;
			root.classList.add('is-flash');
		});

		// ?page=wp-news-lists&builder_list=ID (link from Settings and the single-list page).
		var m = /[?&]builder_list=(\d+)/.exec(window.location.search);
		if (m && qs('option[value="' + m[1] + '"]', field('list'))) {
			field('list').value = m[1];
		}
		update();
	}

	onReady(initSignupBuilder);

	/* ------------------------------------------------------------------
	 * Settings: media picker for the email logo.
	 * ------------------------------------------------------------------ */
	document.addEventListener('click', function (e) {
		var btn = e.target.closest ? e.target.closest('.wpnews-media-btn') : null;
		if (!btn || !window.wp || !window.wp.media) {
			return;
		}
		e.preventDefault();
		var input = document.getElementById(btn.getAttribute('data-target'));
		var frame = window.wp.media({
			title: t('chooseLogo', 'Logo'),
			button: { text: t('useImage', 'Use this image') },
			library: { type: 'image' },
			multiple: false
		});
		frame.on('select', function () {
			var att = frame.state().get('selection').first().toJSON();
			var url = (att.sizes && att.sizes.medium) ? att.sizes.medium.url : att.url;
			if (input) {
				input.value = url;
			}
			var prev = document.getElementById(btn.getAttribute('data-target') + '_preview');
			if (prev) {
				prev.src = url;
			}
		});
		frame.open();
	});

	/* ------------------------------------------------------------------
	 * Subscribers page
	 * ------------------------------------------------------------------ */
	function initSubscribers() {
		var fileInput = qs('#wpnews-csv-file');
		var chooseBtn = qs('#wpnews-csv-choose');
		var fileName = qs('#wpnews-csv-filename');
		if (fileInput && chooseBtn) {
			chooseBtn.addEventListener('click', function () { fileInput.click(); });
			fileInput.addEventListener('change', function () {
				if (!fileName) {
					return;
				}
				var has = fileInput.files && fileInput.files.length;
				fileName.textContent = has ? fileInput.files[0].name : t('noFileChosen');
				fileName.classList.toggle('wpnews-text-dark', !!has);
			});
		}

		var mailpoetBtn = qs('#wpnews-import-mailpoet');
		if (mailpoetBtn) {
			var originalHtml = mailpoetBtn.innerHTML;
			mailpoetBtn.addEventListener('click', function () {
				if (!window.confirm(t('confirmMailpoet'))) {
					return;
				}
				mailpoetBtn.disabled = true;
				mailpoetBtn.textContent = t('importing');
				restFetch('subscribers/import-mailpoet', { method: 'POST', body: '{}' })
					.then(function (data) {
						window.alert(data.message || t('saved'));
						window.location.reload();
					})
					.catch(function (err) {
						window.alert(fmt(t('errorPrefix'), err.message || t('unknownError')));
						mailpoetBtn.disabled = false;
						mailpoetBtn.innerHTML = originalHtml;
					});
			});
		}

		// Bulk selection
		var selectAll = qs('#wpnews-sub-select-all');
		var bulkBar = qs('#wpnews-sub-bulk-bar');
		var countEl = qs('#wpnews-selected-count');
		if (selectAll && bulkBar) {
			var updateBulkBar = function () {
				var checked = qsa('.wpnews-sub-check:checked').length;
				var total = qsa('.wpnews-sub-check').length;
				if (countEl) {
					countEl.textContent = String(checked);
				}
				bulkBar.style.display = checked > 0 ? 'flex' : 'none';
				selectAll.checked = total > 0 && checked === total;
				selectAll.indeterminate = checked > 0 && checked < total;
			};
			selectAll.addEventListener('change', function () {
				qsa('.wpnews-sub-check').forEach(function (cb) { cb.checked = selectAll.checked; });
				updateBulkBar();
			});
			document.addEventListener('change', function (e) {
				if (e.target.classList && e.target.classList.contains('wpnews-sub-check')) {
					updateBulkBar();
				}
			});
		}

		// Inline edit rows
		document.addEventListener('click', function (e) {
			var btn = e.target.closest ? e.target.closest('.wpnews-btn-edit, .wpnews-cancel-btn, .wpnews-save-btn') : null;
			if (!btn) {
				return;
			}
			var id = btn.getAttribute('data-id');
			var editRow = qs('#wpnews-edit-' + id);
			var mainRow = qs('#wpnews-row-' + id);
			if (!editRow) {
				return;
			}

			if (btn.classList.contains('wpnews-btn-edit')) {
				var isVisible = editRow.style.display !== 'none';
				qsa('.wpnews-row-edit').forEach(function (r) { r.style.display = 'none'; });
				qsa('.wpnews-row-main').forEach(function (r) { r.classList.remove('wpnews-row-editing'); });
				if (!isVisible) {
					editRow.style.display = '';
					if (mainRow) {
						mainRow.classList.add('wpnews-row-editing');
					}
				}
				return;
			}

			if (btn.classList.contains('wpnews-cancel-btn')) {
				editRow.style.display = 'none';
				if (mainRow) {
					mainRow.classList.remove('wpnews-row-editing');
				}
				return;
			}

			// Save
			var statusEl = qs('#wpnews-status-' + id);
			var data = { id: parseInt(id, 10) };
			qsa('.wpnews-edit-input', editRow).forEach(function (input) {
				data[input.getAttribute('data-field')] = input.value;
			});
			data.list_ids = qsa('.wpnews-edit-list-cb:checked', editRow).map(function (cb) {
				return parseInt(cb.value, 10);
			});

			btn.disabled = true;
			if (statusEl) {
				statusEl.textContent = t('saving');
				statusEl.className = 'wpnews-save-status is-saving';
			}

			restFetch('subscribers/update', { method: 'POST', body: JSON.stringify(data) })
				.then(function () {
					if (statusEl) {
						statusEl.textContent = t('saved');
						statusEl.className = 'wpnews-save-status is-saved';
					}
					setTimeout(function () { window.location.reload(); }, 600);
				})
				.catch(function (err) {
					if (statusEl) {
						statusEl.textContent = err.message || t('error');
						statusEl.className = 'wpnews-save-status is-error';
					}
					btn.disabled = false;
				});
		});
	}

	/* ------------------------------------------------------------------
	 * Campaigns list
	 * ------------------------------------------------------------------ */
	function initCampaignsList() {
		// Client-side search on the current page
		var searchInput = qs('#wpnews-campaign-search');
		var table = qs('#wpnews-campaigns-table');
		if (searchInput && table) {
			var rows = qsa('tbody tr[data-name]', table);
			var timer;
			searchInput.addEventListener('input', function () {
				clearTimeout(timer);
				timer = setTimeout(function () {
					var q = searchInput.value.toLowerCase().trim();
					rows.forEach(function (row) {
						row.style.display = (!q || (row.getAttribute('data-name') || '').indexOf(q) !== -1) ? '' : 'none';
					});
				}, 150);
			});
		}

		// Bulk delete + modal
		var selectAll = qs('#wpnews-select-all');
		var checkboxes = qsa('.wpnews-campaign-cb');
		var bulkBar = qs('#wpnews-bulk-bar');
		var bulkCount = qs('#wpnews-bulk-count');
		var bulkForm = qs('#wpnews-bulk-delete-form');
		var bulkCancelBtn = qs('#wpnews-bulk-cancel-btn');
		var bulkDeleteBtn = qs('#wpnews-bulk-delete-btn');
		var modal = qs('#wpnews-confirm-modal');
		var confirmYes = qs('#wpnews-confirm-yes');
		var confirmNo = qs('#wpnews-confirm-no');
		var confirmMsg = qs('#wpnews-confirm-msg');

		window.wpnewsBulkPending = false;

		if (selectAll && checkboxes.length && bulkBar && modal) {
			var updateBar = function () {
				var checked = qsa('.wpnews-campaign-cb:checked');
				bulkBar.style.display = checked.length > 0 ? 'flex' : 'none';
				if (bulkCount) {
					bulkCount.textContent = fmt(t('selected'), checked.length);
				}
				selectAll.checked = checkboxes.length > 0 && checkboxes.length === checked.length;
				selectAll.indeterminate = checked.length > 0 && checked.length < checkboxes.length;
			};

			selectAll.addEventListener('change', function () {
				checkboxes.forEach(function (cb) {
					var row = cb.closest('tr');
					if (row && row.style.display !== 'none') {
						cb.checked = selectAll.checked;
					}
				});
				updateBar();
			});
			checkboxes.forEach(function (cb) { cb.addEventListener('change', updateBar); });

			var closeModal = function () {
				modal.style.display = 'none';
				window.wpnewsBulkPending = false;
			};

			if (bulkDeleteBtn) {
				bulkDeleteBtn.addEventListener('click', function (e) {
					e.preventDefault();
					var checked = qsa('.wpnews-campaign-cb:checked');
					if (!checked.length) {
						return;
					}
					window.wpnewsBulkPending = true;
					if (confirmMsg) {
						confirmMsg.textContent = fmt(t('confirmBulkDelete'), checked.length);
					}
					modal.style.display = 'flex';
				});
			}
			if (confirmYes && bulkForm) {
				confirmYes.addEventListener('click', function () {
					modal.style.display = 'none';
					bulkForm.submit();
				});
			}
			if (confirmNo) {
				confirmNo.addEventListener('click', closeModal);
			}
			modal.addEventListener('click', function (e) {
				if (e.target === modal) {
					closeModal();
				}
			});
			if (bulkCancelBtn) {
				bulkCancelBtn.addEventListener('click', function () {
					checkboxes.forEach(function (cb) { cb.checked = false; });
					updateBar();
				});
			}
		}

		// Stop / Resume (REST: builder/stop, builder/resume)
		qsa('.wpnews-stop-btn').forEach(function (btn) {
			btn.addEventListener('click', function (e) {
				e.preventDefault();
				if (!window.confirm(t('confirmStop'))) {
					return;
				}
				btn.disabled = true;
				btn.textContent = t('stopping');
				restFetch('builder/stop', { method: 'POST', body: JSON.stringify({ id: parseInt(btn.getAttribute('data-campaign-id'), 10) }) })
					.catch(function () {})
					.then(function () { setTimeout(function () { window.location.reload(); }, 2000); });
			});
		});

		qsa('.wpnews-resume-btn').forEach(function (btn) {
			btn.addEventListener('click', function (e) {
				e.preventDefault();
				if (!window.confirm(t('confirmResume'))) {
					return;
				}
				btn.disabled = true;
				btn.textContent = t('resuming');
				restFetch('builder/resume', { method: 'POST', body: JSON.stringify({ id: parseInt(btn.getAttribute('data-campaign-id'), 10) }) })
					.catch(function () {})
					.then(function () { setTimeout(function () { window.location.reload(); }, 2000); });
			});
		});

		// Auto-poll progress for sending campaigns
		var sendingRows = qsa('[data-sending-id]');
		if (sendingRows.length) {
			setInterval(function () {
				sendingRows.forEach(function (row) {
					var cid = row.getAttribute('data-sending-id');
					restFetch('builder/progress?id=' + encodeURIComponent(cid))
						.then(function (data) {
							if (data.status && data.status !== 'sending') {
								if (!window.wpnewsBulkPending) {
									window.location.reload();
								}
								return;
							}
							var total = data.total_recipients || 0;
							var sent = data.sent_count || 0;
							var pct = total > 0 ? Math.min(100, Math.round((sent / total) * 100)) : 0;
							var bar = qs('.wpnews-progress-fill', row);
							var txt = qs('.wpnews-progress-text', row);
							if (bar) {
								bar.style.width = pct + '%';
							}
							if (txt) {
								txt.textContent = '';
								var a = document.createElement('span');
								a.textContent = sent + ' / ' + total;
								var b = document.createElement('span');
								b.textContent = pct + '%';
								txt.appendChild(a);
								txt.appendChild(b);
							}
						})
						.catch(function () {});
				});
			}, 3000);
		}
	}

	/* ------------------------------------------------------------------
	 * Campaign stats: blacklist a recipient (REST subscribers/blacklist)
	 * ------------------------------------------------------------------ */
	function initCampaignStats() {
		qsa('.wpnews-stats-blacklist-btn').forEach(function (btn) {
			btn.addEventListener('click', function (e) {
				e.preventDefault();
				var email = btn.getAttribute('data-email');
				if (!window.confirm(fmt(t('confirmBlacklist'), email))) {
					return;
				}
				var originalText = btn.textContent;
				btn.textContent = '...';
				btn.disabled = true;
				restFetch('subscribers/blacklist', { method: 'POST', body: JSON.stringify({ email: email }) })
					.then(function (resp) {
						if (resp && resp.success) {
							window.location.reload();
							return;
						}
						throw new Error((resp && resp.message) || t('unknownError'));
					})
					.catch(function (err) {
						window.alert(err.message || t('networkError'));
						btn.textContent = originalText;
						btn.disabled = false;
					});
			});
		});
	}

	/* ------------------------------------------------------------------
	 * Settings page
	 * ------------------------------------------------------------------ */
	function initSettings() {
		// Tabs
		var tabs = qsa('[data-wpnews-tab]');
		if (tabs.length) {
			tabs.forEach(function (tab) {
				tab.addEventListener('click', function (e) {
					e.preventDefault();
					var id = tab.getAttribute('data-wpnews-tab');
					tabs.forEach(function (tt) { tt.classList.remove('nav-tab-active'); });
					tab.classList.add('nav-tab-active');
					qsa('[data-wpnews-panel]').forEach(function (panel) {
						panel.style.display = panel.getAttribute('data-wpnews-panel') === id ? 'block' : 'none';
					});
				});
			});
			if (window.location.hash) {
				var hashTab = tabs.filter(function (tt) { return tt.getAttribute('data-wpnews-tab') === window.location.hash.substring(1); })[0];
				if (hashTab) {
					hashTab.click();
				}
			}
		}

		// Mailer block toggle
		var mailerSelect = qs('.wpnews-mailer-select');
		if (mailerSelect) {
			var toggleMailer = function () {
				qsa('.mailer-settings-block').forEach(function (block) {
					block.style.display = block.getAttribute('data-mailer') === mailerSelect.value ? 'block' : 'none';
				});
			};
			mailerSelect.addEventListener('change', toggleMailer);
			toggleMailer();
		}

		// Webhook secret generator (32 hex chars)
		var genBtn = qs('#wpnews-generate-secret');
		var secretInput = qs('#webhook_secret');
		if (genBtn && secretInput) {
			genBtn.addEventListener('click', function () {
				var bytes = new Uint8Array(16);
				if (window.crypto && window.crypto.getRandomValues) {
					window.crypto.getRandomValues(bytes);
				} else {
					for (var i = 0; i < bytes.length; i++) {
						bytes[i] = Math.floor(Math.random() * 256);
					}
				}
				var hex = Array.prototype.map.call(bytes, function (b) {
					return ('0' + b.toString(16)).slice(-2);
				}).join('');
				secretInput.value = hex;
				qsa('.wpnews-webhook-url').forEach(function (code) {
					var base = code.getAttribute('data-base') || '';
					code.textContent = base + (base.indexOf('?') === -1 ? '?' : '&') + 'key=' + hex;
				});
				window.alert(t('secretGenerated'));
			});
		}

		// SNS status check
		var snsBtn = qs('#wpnews-check-sns');
		if (snsBtn) {
			snsBtn.addEventListener('click', function () {
				var spinner = qs('#wpnews-sns-spinner');
				var results = qs('#wpnews-sns-results');
				snsBtn.disabled = true;
				if (spinner) {
					spinner.style.display = 'inline';
				}
				if (results) {
					results.style.display = 'none';
					results.textContent = '';
				}

				var finish = function () {
					if (spinner) {
						spinner.style.display = 'none';
					}
					snsBtn.disabled = false;
					if (results) {
						results.style.display = 'block';
					}
				};

				var el = function (tag, text, className) {
					var node = document.createElement(tag);
					if (text !== undefined && text !== null) {
						node.textContent = text;
					}
					if (className) {
						node.className = className;
					}
					return node;
				};

				restFetch('builder/sns-status')
					.then(function (data) {
						finish();
						if (!results) {
							return;
						}
						if (!data.success) {
							results.appendChild(el('div', data.message || t('unknownError'), 'wpnews-text-error'));
							return;
						}
						var n = data.notifications || {};
						var header = el('div', null, 'wpnews-mb-10');
						header.appendChild(el('strong', t('identity') + ': '));
						header.appendChild(document.createTextNode(data.identity || ''));
						header.appendChild(document.createTextNode(' — '));
						header.appendChild(el('strong', t('verified') + ': '));
						header.appendChild(document.createTextNode(data.verified ? t('yes') : t('no')));
						results.appendChild(header);

						var table = el('table', null, 'wpnews-sns-table');
						var thead = el('thead');
						var hr = el('tr');
						[t('type'), t('status'), t('snsTopic')].forEach(function (h) { hr.appendChild(el('th', h)); });
						thead.appendChild(hr);
						table.appendChild(thead);
						var tbody = el('tbody');
						[['delivery', t('delivery')], ['bounce', t('bounce')], ['complaint', t('complaint')]].forEach(function (pair) {
							var item = n[pair[0]] || {};
							var tr = el('tr');
							tr.appendChild(el('td', pair[1]));
							tr.appendChild(el('td', item.enabled ? t('active') : t('inactive'), item.enabled ? 'wpnews-text-success' : 'wpnews-text-error'));
							var topic = item.topic ? String(item.topic).split(':').pop() : t('notConfigured');
							tr.appendChild(el('td', topic, item.topic ? '' : 'wpnews-small-muted'));
							tbody.appendChild(tr);
						});
						table.appendChild(tbody);
						results.appendChild(table);
					})
					.catch(function (err) {
						finish();
						if (results) {
							results.appendChild(el('div', fmt(t('networkErrorDetail'), err.message || ''), 'wpnews-text-error'));
						}
					});
			});
		}
	}

	onReady(function () {
		initSubscribers();
		initCampaignsList();
		initCampaignStats();
		initSettings();
	});
})();
