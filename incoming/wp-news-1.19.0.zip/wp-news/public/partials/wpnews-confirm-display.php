<?php
/**
 * Standalone Subscription Confirmation Template.
 * Rendered by WPNews_Public::handle_confirm_page() after the signed token
 * has been verified. Strings use the site locale through gettext.
 *
 * @package WPNews
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$site_name = isset( $site_name ) ? (string) $site_name : get_bloginfo( 'name' );
$home_url  = isset( $home_url ) ? (string) $home_url : home_url( '/' );
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="robots" content="noindex,nofollow">
	<link rel="canonical" href="<?php echo esc_url( home_url( '/' ) ); ?>">
	<title><?php echo esc_html__( 'Confirm Subscription', 'wp-news' ); ?> - <?php echo esc_html( $site_name ); ?></title>
	<style>
		body {
			margin: 0;
			padding: 0;
			font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
			background-color: #f1f3f6;
			color: #334155;
			display: flex;
			align-items: center;
			justify-content: center;
			min-height: 100vh;
			line-height: 1.6;
		}
		.confirm-card {
			background: #ffffff;
			border-radius: 16px;
			box-shadow: 0 10px 40px rgba(15, 23, 42, 0.08);
			padding: 40px;
			max-width: 480px;
			width: 90%;
			text-align: center;
			border: 1px solid #e2e8f0;
		}
		.icon {
			width: 64px;
			height: 64px;
			margin: 0 auto 24px;
			display: flex;
			align-items: center;
			justify-content: center;
			border-radius: 50%;
		}
		.icon-success { background: #f0fdf4; color: #22c55e; }
		.icon svg { width: 32px; height: 32px; }
		h1 {
			margin: 0 0 16px;
			font-size: 24px;
			color: #0f172a;
			font-weight: 600;
		}
		p {
			margin: 0 0 32px;
			color: #64748b;
			font-size: 16px;
		}
		.btn {
			display: block;
			width: 100%;
			padding: 14px 24px;
			border-radius: 8px;
			font-size: 16px;
			font-weight: 500;
			text-decoration: none;
			border: none;
			cursor: pointer;
			transition: all 0.2s ease;
			box-sizing: border-box;
		}
		.btn-primary {
			background-color: #3b82f6;
			color: #ffffff;
			box-shadow: 0 4px 14px rgba(59, 130, 246, 0.2);
		}
		.btn-primary:hover { background-color: #2563eb; }
	</style>
</head>
<body>

<div class="confirm-card">
	<div class="icon icon-success">
		<svg fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path></svg>
	</div>
	<h1><?php esc_html_e( 'Subscription Confirmed!', 'wp-news' ); ?></h1>
	<p><?php esc_html_e( 'Your subscription has been successfully confirmed. Thank you for joining our newsletter!', 'wp-news' ); ?></p>
	<a href="<?php echo esc_url( $home_url ); ?>" class="btn btn-primary"><?php esc_html_e( 'Return to Home', 'wp-news' ); ?></a>
</div>

</body>
</html>
