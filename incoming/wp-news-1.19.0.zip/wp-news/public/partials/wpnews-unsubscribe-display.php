<?php
/**
 * Standalone Unsubscribe Template.
 * Rendered by WPNews_Public::handle_unsubscribe_page(), which provides:
 * $error, $is_success, $is_test, $email, $subscriber_id, $site_name, $home_url.
 * Strings use the site locale through gettext (no manual language switch).
 *
 * @package WPNews
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$error         = isset( $error ) ? (string) $error : '';
$is_success    = ! empty( $is_success );
$is_test       = ! empty( $is_test );
$email         = isset( $email ) ? (string) $email : '';
$subscriber_id = isset( $subscriber_id ) ? (int) $subscriber_id : 0;
$site_name     = isset( $site_name ) ? (string) $site_name : get_bloginfo( 'name' );
$home_url      = isset( $home_url ) ? (string) $home_url : home_url( '/' );
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="robots" content="noindex,nofollow">
	<link rel="canonical" href="<?php echo esc_url( home_url( '/' ) ); ?>">
	<title><?php echo esc_html__( 'Unsubscribe', 'wp-news' ); ?> - <?php echo esc_html( $site_name ); ?></title>
	<style>
		body {
			margin: 0;
			padding: 0;
			font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
			background-color: #f1f3f6;
			color: #334155;
			display: flex;
			align-items: center;
			justify-content: center;
			min-height: 100vh;
			line-height: 1.6;
		}
		.unsubscribe-card {
			background: #ffffff;
			border-radius: 16px;
			box-shadow: 0 10px 40px rgba(15, 23, 42, 0.08);
			padding: 40px;
			max-width: 480px;
			width: 90%;
			text-align: center;
			border: 1px solid #e2e8f0;
		}
		.icon {
			width: 64px;
			height: 64px;
			margin: 0 auto 24px;
			display: flex;
			align-items: center;
			justify-content: center;
			border-radius: 50%;
		}
		.icon-warning { background: #fef2f2; color: #ef4444; }
		.icon-success { background: #f0fdf4; color: #22c55e; }
		.icon svg { width: 32px; height: 32px; }
		h1 {
			margin: 0 0 16px;
			font-size: 24px;
			color: #0f172a;
			font-weight: 600;
		}
		p {
			margin: 0 0 32px;
			color: #64748b;
			font-size: 16px;
		}
		.subscriber-email {
			font-weight: 600;
			color: #0f172a;
			background: #f8fafc;
			padding: 4px 12px;
			border-radius: 6px;
			display: inline-block;
			margin-top: 8px;
			border: 1px solid #e2e8f0;
			word-break: break-all;
		}
		.btn {
			display: block;
			width: 100%;
			padding: 14px 24px;
			border-radius: 8px;
			font-size: 16px;
			font-weight: 500;
			text-decoration: none;
			border: none;
			cursor: pointer;
			transition: all 0.2s ease;
			box-sizing: border-box;
			font-family: inherit;
		}
		.btn-danger {
			background-color: #ef4444;
			color: #ffffff;
			margin-bottom: 12px;
			box-shadow: 0 4px 14px rgba(239, 68, 68, 0.2);
		}
		.btn-danger:hover { background-color: #dc2626; }
		.btn-secondary {
			background-color: #ffffff;
			color: #475569;
			border: 1px solid #cbd5e1;
		}
		.btn-secondary:hover { background-color: #f8fafc; color: #0f172a; }
		.btn-primary {
			background-color: #3b82f6;
			color: #ffffff;
			box-shadow: 0 4px 14px rgba(59, 130, 246, 0.2);
		}
		.btn-primary:hover { background-color: #2563eb; }
		.error-notice {
			background: #fef2f2;
			color: #991b1b;
			padding: 16px;
			border-radius: 8px;
			margin-bottom: 24px;
			border: 1px solid #fecaca;
		}
		.preview-note {
			font-size: 12px;
			color: #94a3b8;
			margin: 16px 0 0;
		}
	</style>
</head>
<body>

<div class="unsubscribe-card">
	<?php if ( '' !== $error ) : ?>

		<div class="icon icon-warning">
			<svg fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"></path></svg>
		</div>
		<h1><?php esc_html_e( 'Oops', 'wp-news' ); ?></h1>
		<div class="error-notice"><?php echo esc_html( $error ); ?></div>
		<a href="<?php echo esc_url( $home_url ); ?>" class="btn btn-secondary"><?php esc_html_e( 'Return to Home', 'wp-news' ); ?></a>

	<?php elseif ( $is_success ) : ?>

		<div class="icon icon-success">
			<svg fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path></svg>
		</div>
		<h1><?php esc_html_e( 'Unsubscribed', 'wp-news' ); ?></h1>
		<p><?php esc_html_e( 'You have been successfully removed from our mailing list and will no longer receive our newsletters.', 'wp-news' ); ?></p>
		<a href="<?php echo esc_url( $home_url ); ?>" class="btn btn-primary"><?php esc_html_e( 'Return to Home', 'wp-news' ); ?></a>

	<?php else : ?>

		<div class="icon icon-warning">
			<svg fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 19v-8.93a2 2 0 01.89-1.664l7-4.666a2 2 0 012.22 0l7 4.666A2 2 0 0121 10.07V19M3 19a2 2 0 002 2h14a2 2 0 002-2M3 19l6.75-4.5M21 19l-6.75-4.5M3 10l6.75 4.5M21 10l-6.75 4.5m0 0l-1.14.76a2 2 0 01-2.22 0l-1.14-.76"></path></svg>
		</div>
		<h1><?php esc_html_e( 'Are you sure?', 'wp-news' ); ?></h1>
		<p>
			<?php
			/* translators: %s: site name */
			printf( esc_html__( 'You are about to unsubscribe from all future communications sent by %s.', 'wp-news' ), '<strong>' . esc_html( $site_name ) . '</strong>' );
			?>
			<br>
			<span class="subscriber-email"><?php echo esc_html( $email ); ?></span>
		</p>

		<form method="post" action="">
			<?php wp_nonce_field( 'wpnews_unsubscribe_' . ( $is_test ? 'test' : $subscriber_id ), 'wpnews_unsub_nonce' ); ?>
			<input type="hidden" name="wpnews_action" value="unsubscribe">
			<button type="submit" class="btn btn-danger"><?php esc_html_e( 'Yes, unsubscribe me', 'wp-news' ); ?></button>
			<a href="<?php echo esc_url( $home_url ); ?>" class="btn btn-secondary"><?php esc_html_e( 'No, keep me subscribed', 'wp-news' ); ?></a>
		</form>

		<?php if ( $is_test ) : ?>
			<p class="preview-note"><?php esc_html_e( 'Preview mode: no changes will be made.', 'wp-news' ); ?></p>
		<?php endif; ?>

	<?php endif; ?>
</div>

</body>
</html>
