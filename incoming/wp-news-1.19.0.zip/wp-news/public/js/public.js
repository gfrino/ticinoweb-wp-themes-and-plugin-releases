/**
 * WP-News Public JavaScript (vanilla, no jQuery).
 * Handles the [wpnews_subscribe_form] shortcode submission via admin-ajax.
 *
 * Anti-spam proof of work: when a form becomes visible (or is focused) the
 * browser fetches a signed challenge and searches, in small async batches, a
 * nonce whose SHA-256(salt + ":" + nonce) starts with N zero bits. The answer
 * is sent with the form; a new challenge is prepared after every response
 * because each one can be used only once.
 */
(function () {
	'use strict';

	var cfg = window.wpNewsPublic || {};
	var S = cfg.strings || {};

	function t(key, fallback) {
		return Object.prototype.hasOwnProperty.call(S, key) ? S[key] : fallback;
	}

	function isValidEmail(email) {
		return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
	}

	function showMessage(form, message, type) {
		var slot = form.querySelector('.wpnews-message-slot') || form;
		var existing = form.querySelector('.wpnews-message');
		if (existing) {
			existing.parentNode.removeChild(existing);
		}
		var div = document.createElement('div');
		div.className = 'wpnews-message ' + type;
		div.setAttribute('role', type === 'error' ? 'alert' : 'status');
		div.textContent = message;
		slot.appendChild(div);
	}

	/* ------------------------------------------------------------------
	 * Proof of work
	 * ------------------------------------------------------------------ */

	var powSupported = !!(window.crypto && window.crypto.subtle && window.TextEncoder);

	function leadingZeroBits(buf, bits) {
		var bytes = new Uint8Array(buf);
		var full = Math.floor(bits / 8);
		for (var i = 0; i < full; i++) {
			if (bytes[i] !== 0) {
				return false;
			}
		}
		var rest = bits % 8;
		return rest === 0 || (bytes[full] >> (8 - rest)) === 0;
	}

	function solve(salt, bits) {
		var enc = new TextEncoder();
		var nonce = 0;
		return new Promise(function (resolve, reject) {
			function batch() {
				var pending = [];
				for (var i = 0; i < 256; i++) {
					(function (n) {
						pending.push(
							window.crypto.subtle.digest('SHA-256', enc.encode(salt + ':' + n)).then(function (h) {
								return leadingZeroBits(h, bits) ? n : -1;
							})
						);
					})(nonce++);
				}
				Promise.all(pending).then(function (res) {
					for (var j = 0; j < res.length; j++) {
						if (res[j] >= 0) {
							resolve(String(res[j]));
							return;
						}
					}
					if (nonce > 50000000) {
						reject(new Error('pow'));
						return;
					}
					setTimeout(batch, 0); // keep the page responsive
				}, reject);
			}
			batch();
		});
	}

	function prepare(form) {
		if (!cfg.pow || !powSupported || !cfg.ajaxUrl) {
			return Promise.resolve(null);
		}
		if (form._wpnewsPow) {
			return form._wpnewsPow;
		}
		var body = new FormData();
		body.append('action', 'wpnews_challenge');
		form._wpnewsPow = fetch(cfg.ajaxUrl, { method: 'POST', body: body, credentials: 'same-origin' })
			.then(function (r) { return r.json(); })
			.then(function (resp) {
				if (!resp || !resp.success || !resp.data) {
					throw new Error('challenge');
				}
				var data = JSON.parse(atob(resp.data.c));
				var issued = Date.now();
				return solve(data.s, data.b).then(function (n) {
					return { c: resp.data.c, s: resp.data.sig, n: n, issued: issued };
				});
			})
			['catch'](function () {
				form._wpnewsPow = null; // retry on submit
				return null;
			});
		return form._wpnewsPow;
	}

	function refresh(form) {
		form._wpnewsPow = null;
		prepare(form);
	}

	function initForms() {
		var forms = Array.prototype.slice.call(document.querySelectorAll('.wpnews-subscribe-form'));
		if (!forms.length || !cfg.pow) {
			return;
		}
		forms.forEach(function (form) {
			form.addEventListener('focusin', function () { prepare(form); }, { once: true });
		});
		if ('IntersectionObserver' in window) {
			var io = new IntersectionObserver(function (entries) {
				entries.forEach(function (en) {
					if (en.isIntersecting) {
						prepare(en.target);
						io.unobserve(en.target);
					}
				});
			}, { rootMargin: '200px' });
			forms.forEach(function (f) { io.observe(f); });
		} else {
			forms.forEach(prepare);
		}
	}

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', initForms);
	} else {
		initForms();
	}

	/* ------------------------------------------------------------------
	 * Submit
	 * ------------------------------------------------------------------ */

	document.addEventListener('submit', function (e) {
		var form = e.target && e.target.closest ? e.target.closest('.wpnews-subscribe-form') : null;
		if (!form) {
			return;
		}
		e.preventDefault();

		if (!cfg.ajaxUrl || form._wpnewsBusy) {
			return;
		}

		var emailInput = form.querySelector('input[name="email"]');
		var email = emailInput ? emailInput.value.trim() : '';
		if (!isValidEmail(email)) {
			showMessage(form, t('invalidEmail', 'Please enter a valid email address.'), 'error');
			if (emailInput) {
				emailInput.focus();
			}
			return;
		}

		var consent = form.querySelector('input[name="wpnews_consent"]');
		if (consent && !consent.checked) {
			showMessage(form, t('consentRequired', 'Please accept the privacy conditions to subscribe.'), 'error');
			consent.focus();
			return;
		}

		var submitBtn = form.querySelector('button[type="submit"]');
		var originalText = submitBtn ? submitBtn.textContent : '';
		form._wpnewsBusy = true;
		form.classList.add('is-loading');
		if (submitBtn) {
			submitBtn.disabled = true;
			submitBtn.textContent = cfg.pow ? t('verifying', 'Security check…') : t('subscribing', 'Subscribing...');
		}

		var restore = function () {
			form._wpnewsBusy = false;
			form.classList.remove('is-loading');
			if (submitBtn) {
				submitBtn.disabled = false;
				submitBtn.textContent = originalText;
			}
			refresh(form); // each challenge is single-use
		};

		prepare(form).then(function (pow) {
			// The server rejects answers sent less than 2 s after the challenge
			// was issued (faster than a human): wait out the remainder if needed.
			var wait = pow ? Math.max(0, 2300 - (Date.now() - pow.issued)) : 0;
			return new Promise(function (r) { setTimeout(function () { r(pow); }, wait); });
		}).then(function (pow) {
			if (submitBtn) {
				submitBtn.textContent = t('subscribing', 'Subscribing...');
			}
			var data = new FormData(form);
			data.append('action', 'wpnews_subscribe');
			data.append('nonce', cfg.nonce || '');
			if (pow) {
				data.append('wpnews_c', pow.c);
				data.append('wpnews_s', pow.s);
				data.append('wpnews_n', pow.n);
			}
			return fetch(cfg.ajaxUrl, { method: 'POST', body: data, credentials: 'same-origin' });
		})
			.then(function (r) { return r.json(); })
			.then(function (resp) {
				var message = resp && resp.data && resp.data.message ? resp.data.message : '';
				if (resp && resp.success) {
					showMessage(form, message, 'success');
					form.classList.add('is-success');
					form.reset();
				} else {
					showMessage(form, message || t('subscribeError', 'Error subscribing. Please try again.'), 'error');
				}
				restore();
			})
			['catch'](function () {
				showMessage(form, t('subscribeError', 'Error subscribing. Please try again.'), 'error');
				restore();
			});
	});
})();
