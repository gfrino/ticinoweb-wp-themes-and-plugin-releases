<?php
/** Albatros: presentazione e integrazione dei dati del parent. */
defined('ABSPATH') || exit;

define('ALBATROS_VERSION', '1.3.1');

add_action('after_setup_theme', function () {
    load_child_theme_textdomain('albatrossagl-child-theme', get_stylesheet_directory() . '/languages');
    register_nav_menus(array('albatros_primary' => __('Navigazione principale', 'albatrossagl-child-theme')));
    add_theme_support('editor-styles');
    add_editor_style('assets/css/editor.css');
});

add_action('wp_enqueue_scripts', function () {
    // Il parent usa get_stylesheet_uri(): il suo handle carica già style.css del child.
    wp_dequeue_style('poppins-font');
    wp_deregister_style('poppins-font');
    wp_deregister_style('ticinoweb-ai-style');
    wp_enqueue_style('ticinoweb-ai-style', get_stylesheet_uri(), array(), ALBATROS_VERSION);
    wp_enqueue_style('albatros-site', get_stylesheet_directory_uri() . '/assets/css/site.css', array('ticinoweb-ai-style'), ALBATROS_VERSION);
    wp_enqueue_script('albatros-site', get_stylesheet_directory_uri() . '/assets/js/site.js', array(), ALBATROS_VERSION, true);
    if (is_front_page()) {
        wp_enqueue_style('albatros-subscription', get_stylesheet_directory_uri() . '/assets/css/subscription.css', array('albatros-site'), ALBATROS_VERSION);
        wp_enqueue_style('albatros-motion', get_stylesheet_directory_uri() . '/assets/css/motion.css', array('albatros-site'), ALBATROS_VERSION);
        wp_enqueue_script('albatros-motion', get_stylesheet_directory_uri() . '/assets/js/motion.js', array('albatros-site'), ALBATROS_VERSION, true);
    }
    wp_enqueue_style('albatros-deck', get_stylesheet_directory_uri() . '/assets/css/service-deck.css', array(is_front_page() ? 'albatros-motion' : 'albatros-site'), ALBATROS_VERSION);
    wp_localize_script('albatros-site', 'albatrosConfig', array(
        'ajaxUrl' => admin_url('admin-ajax.php'),
        'recaptchaKey' => (string) get_option('ticinoweb_recaptcha_site_key', ''),
        'sending' => __('Invio in corso…', 'albatrossagl-child-theme'),
        'error' => __('Invio non riuscito. Riprova oppure contattaci per telefono.', 'albatrossagl-child-theme'),
        'fieldError' => __('Controlla questo campo.', 'albatrossagl-child-theme'),
    ));
}, 30);

/** Translation bridge for CMS data; escaping belongs at the output boundary. */
function albatros_text($text, $context) {
    return function_exists('ticinoweb_frontend_text') ? ticinoweb_frontend_text((string) $text, 'albatros:' . $context) : (string) $text;
}

function albatros_url($fragment = '') {
    $url = home_url('/') . ($fragment !== '' ? '#' . sanitize_title($fragment) : '');
    return function_exists('ticinoweb_frontend_url') ? ticinoweb_frontend_url($url, 'albatros:url:' . $fragment) : $url;
}

function albatros_contact() {
    $contact = function_exists('ticinoweb_get_contact_info') ? ticinoweb_get_contact_info() : array();
    // Older installed parents omit optional CMS fields from their helper.
    foreach (array('phone', 'phone_display', 'email', 'address', 'address_label', 'map_url', 'opening_hours_note', 'vat') as $key) {
        if (empty($contact[$key])) {
            $contact[$key] = get_option('ticinoweb_contact_' . $key, '');
        }
    }
    return $contact;
}

/** Render only Media Library attachments: responsive sizes and no remote hotlinks. */
function albatros_image($url, $size = 'large', $attributes = array()) {
    static $ids = array();
    if (!$url) {
        return '';
    }
    if (!isset($ids[$url])) {
        $ids[$url] = attachment_url_to_postid($url);
    }
    return $ids[$url] ? wp_get_attachment_image($ids[$url], $size, false, $attributes) : '';
}

// The parent CMS documents these tags but this version does not register all of them.
// Supply presentation adapters only when missing; data and form handling remain in the parent.
add_action('init', function () {
    foreach (array('ticinoweb_slider' => 'hero', 'ticinoweb_chi_siamo' => 'about', 'ticinoweb_contatti' => 'contact') as $tag => $template) {
        if (!shortcode_exists($tag)) {
            add_shortcode($tag, function () use ($template) {
                ob_start();
                get_template_part('template-parts/' . $template);
                return ob_get_clean();
            });
        }
    }
}, 20);

/** Expand the parent shortcodes with this child's presentation, preserving their inputs. */
add_filter('pre_do_shortcode_tag', function ($output, $tag, $attributes) {
    if ($output !== false) {
        return $output;
    }
    $templates = array(
        'ticinoweb_slider' => 'hero',
        'ticinoweb_services' => 'services',
        'ticinoweb_servizi' => 'services',
        'ticinoweb_chi_siamo' => 'about',
        'ticinoweb_contatti' => 'contact',
    );
    if (!isset($templates[$tag])) {
        return $output;
    }
    ob_start();
    get_template_part('template-parts/' . $templates[$tag]);
    return ob_get_clean();
}, 10, 3);

/** Extra request context uses the existing parent storage and mail delivery. */
add_filter('ticinoweb_form_fields', function ($fields, $input) {
    if (($input['albatros_request'] ?? '') !== 'quote') {
        return $fields;
    }
    $context = array();
    foreach (array('cliente' => __('Tipo di cliente', 'albatrossagl-child-theme'), 'localita' => __('Località', 'albatrossagl-child-theme')) as $key => $label) {
        $value = isset($input[$key]) && is_scalar($input[$key]) ? sanitize_text_field(wp_unslash((string) $input[$key])) : '';
        if ($value !== '') {
            $context[] = $label . ': ' . mb_substr($value, 0, 160);
        }
    }
    if ($context) {
        $fields['messaggio'] = implode("\n", $context) . "\n\n" . $fields['messaggio'];
    }
    return $fields;
}, 10, 2);

function albatros_request_errors($errors, $fields, $input) {
    if (($input['albatros_request'] ?? '') !== 'quote') {
        return $errors;
    }
    $message = isset($input['messaggio']) && is_scalar($input['messaggio']) ? trim(sanitize_textarea_field(wp_unslash((string) $input['messaggio']))) : '';
    if (mb_strlen($message) < 5) {
        $errors['messaggio'] = __('Descrivi brevemente il servizio di cui hai bisogno.', 'albatrossagl-child-theme');
    }
    if (($input['privacy'] ?? '') !== '1') {
        $errors['privacy'] = __('Conferma di aver letto l’informativa privacy.', 'albatrossagl-child-theme');
    }
    return $errors;
}
add_filter('ticinoweb_form_errors', 'albatros_request_errors', 10, 3);

/** Compatibility preflight: older installed parents do not expose form_errors yet. */
function albatros_form_preflight() {
    $token = isset($_POST['token']) && is_scalar($_POST['token']) ? sanitize_text_field(wp_unslash((string) $_POST['token'])) : '';
    if (!wp_verify_nonce($token, 'ticinoweb_submit_form')) {
        return; // The parent rejects invalid tokens; do not replace its handler.
    }
    $input = $_POST;
    $input['albatros_request'] = 'quote'; // Removing the browser's marker must not bypass validation.
    $errors = albatros_request_errors(array(), array(), $input);
    if ($errors) {
        wp_send_json_error(array('message' => __('Controlla i campi evidenziati.', 'albatrossagl-child-theme'), 'fields' => $errors), 422);
    }
}
add_action('wp_ajax_ticinoweb_submit_form', 'albatros_form_preflight', 1);
add_action('wp_ajax_nopriv_ticinoweb_submit_form', 'albatros_form_preflight', 1);
