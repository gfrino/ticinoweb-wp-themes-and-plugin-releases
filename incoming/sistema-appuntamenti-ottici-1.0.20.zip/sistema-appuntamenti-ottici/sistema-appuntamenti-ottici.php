<?php
/**
 * Plugin Name: Sistema di appuntamenti per Ottici
 * Plugin URI: https://ticinoweb.com
 * Description: Prenotazioni online per studi ottici: i clienti scelgono servizio, giorno e orario da un calendario sul sito, tu gestisci orari, chiusure ed email e tutto si sincronizza con Google Calendar.
 * Version: 1.0.20
 * Requires PHP: 7.4
 * Author: ticinoWEB
 * Author URI: https://ticinoweb.com
 * Text Domain: simple-booking-system
 * Update URI: https://github.com/gfrino/ticinoweb-wp-themes-and-plugin-releases
 */

// Se invocato direttamente, esci.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// Costanti globali
define( 'SBS_VERSION', '1.0.20' );
// Versione di includes/tw-release-updater.php incluso (tenere allineata al suo header).
define( 'SBS_RELEASE_UPDATER_VERSION', '1.2.0' );
define( 'SBS_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'SBS_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

/**
 * Logica di Attivazione (Creazione DB)
 */
function activate_simple_booking_system() {
    require_once plugin_dir_path( __FILE__ ) . 'includes/class-sbs-activator.php';
    SBS_Activator::activate();
    update_option( 'sbs_db_version', SBS_VERSION );
    sbs_install_release_updater();
}
register_activation_hook( __FILE__, 'activate_simple_booking_system' );

/*
 * Aggiornamenti dal repo release ticinoWEB (header Update URI). Il caricatore e' generico e viene
 * installato anche come mu-plugin; se e' gia' caricato questo include non fa nulla.
 */
require_once plugin_dir_path( __FILE__ ) . 'includes/tw-release-updater.php';

/**
 * Installa o aggiorna il mu-plugin dell'aggiornatore dalla copia inclusa.
 * Un errore (mu-plugins non scrivibile) viene ritentato al massimo ogni 12 ore.
 */
function sbs_install_release_updater() {
    if ( ! class_exists( 'TW_Release_Updater' ) || TW_Release_Updater::mu_is_current( SBS_RELEASE_UPDATER_VERSION ) ) {
        return;
    }
    if ( get_site_transient( 'sbs_release_updater_failed' ) ) {
        return;
    }
    $result = TW_Release_Updater::install_mu( plugin_dir_path( __FILE__ ) . 'includes/tw-release-updater.php' );
    if ( is_wp_error( $result ) ) {
        set_site_transient( 'sbs_release_updater_failed', $result->get_error_message(), 12 * HOUR_IN_SECONDS );
    }
}
add_action( 'admin_init', function () {
    if ( current_user_can( is_multisite() ? 'manage_network_plugins' : 'activate_plugins' ) ) {
        sbs_install_release_updater();
    }
}, 20 );

/**
 * Logica di Aggiornamento DB Automatico
 */
function sbs_update_db_check() {
    $db_version = get_option( 'sbs_db_version', '1.0.0' );
    if ( version_compare( $db_version, SBS_VERSION, '<' ) ) {
        require_once plugin_dir_path( __FILE__ ) . 'includes/class-sbs-activator.php';
        SBS_Activator::activate();
        update_option( 'sbs_db_version', SBS_VERSION );
    }
}
add_action( 'admin_init', 'sbs_update_db_check' );

/**
 * Logica di Disattivazione
 */
function deactivate_simple_booking_system() {
    // Per ora non facciamo nulla alla disattivazione per preservare i dati.
    // L'eliminazione dei dati va fatta nel file uninstall.php
}
register_deactivation_hook( __FILE__, 'deactivate_simple_booking_system' );

/**
 * Inizializzazione del Core
 */
function run_simple_booking_system() {
    // Carica la classe core principale
    require_once SBS_PLUGIN_DIR . 'includes/class-sbs-core.php';
    
    $plugin = new SBS_Core();
    $plugin->run();
}
run_simple_booking_system();
