document.addEventListener('DOMContentLoaded', function() {
    const wrapper = document.getElementById('sbs-booking-wrapper');
    if (!wrapper) return;

    // Elements
    const monthYearEl = document.getElementById('sbs-month-year');
    const daysGrid = document.getElementById('sbs-days-grid');
    const prevBtn = document.getElementById('sbs-prev-month');
    const nextBtn = document.getElementById('sbs-next-month');
    
    const slotsContainer = document.getElementById('sbs-slots-container');
    const slotsGrid = document.getElementById('sbs-slots-grid');
    const slotsLoader = document.getElementById('sbs-slots-loader');
    const selectedDateLabel = document.getElementById('sbs-selected-date-label');
    
    const formContainer = document.getElementById('sbs-booking-form-container');
    const bookingForm = document.getElementById('sbs-booking-form');
    const inputDate = document.getElementById('sbs_date');
    const inputTime = document.getElementById('sbs_time');
    const formMsg = document.getElementById('sbs-form-msg');
    const submitBtn = document.getElementById('sbs-submit-btn');
    
    // Service selection elements
    const serviceRadios = document.querySelectorAll('input[name="sbs_service"]');
    const recapServiceName = document.getElementById('sbs-recap-service-name');
    const recapServiceDuration = document.getElementById('sbs-recap-service-duration');
    const recapDatetime = document.getElementById('sbs-recap-datetime');
    
    let currentServiceDuration = 15; // default
    let currentServiceName = '';

    // Date Logic
    let currentDate = new Date();
    let currentMonth = currentDate.getMonth();
    let currentYear = currentDate.getFullYear();

    const maxMonthsAhead = 1; // Can only book 1 month in advance
    const maxDate = new Date();
    maxDate.setMonth(maxDate.getMonth() + maxMonthsAhead);

    function renderCalendar(month, year) {
        daysGrid.innerHTML = '';
        const firstDay = new Date(year, month, 1).getDay();
        const daysInMonth = new Date(year, month + 1, 0).getDate();
        
        // Adjust for Monday start (0=Sun, 1=Mon, ..., 6=Sat)
        let startDay = firstDay === 0 ? 6 : firstDay - 1;

        const monthNames = ["Gennaio", "Febbraio", "Marzo", "Aprile", "Maggio", "Giugno", "Luglio", "Agosto", "Settembre", "Ottobre", "Novembre", "Dicembre"];
        monthYearEl.textContent = `${monthNames[month]} ${year}`;

        // Empty slots before 1st day
        for (let i = 0; i < startDay; i++) {
            const emptyDiv = document.createElement('div');
            emptyDiv.className = 'sbs-day sbs-empty';
            daysGrid.appendChild(emptyDiv);
        }

        const today = new Date();
        today.setHours(0,0,0,0);

        for (let i = 1; i <= daysInMonth; i++) {
            const dayDiv = document.createElement('div');
            dayDiv.className = 'sbs-day';
            dayDiv.textContent = i;

            const thisDate = new Date(year, month, i);
            thisDate.setHours(0,0,0,0);
            
            // Format YYYY-MM-DD
            const formattedDate = `${year}-${String(month + 1).padStart(2, '0')}-${String(i).padStart(2, '0')}`;
            dayDiv.dataset.date = formattedDate;

            // Disable past dates and dates beyond maxDate
            if (thisDate < today) {
                dayDiv.classList.add('sbs-disabled');
                dayDiv.classList.add('sbs-disabled-past');
            } else if (thisDate > maxDate) {
                dayDiv.classList.add('sbs-disabled');
                dayDiv.classList.add('sbs-disabled-future');
            } else {
                // Check closed days first (holidays, vacations)
                let isHoliday = false;
                if (sbs_ajax && sbs_ajax.closed_days && Array.isArray(sbs_ajax.closed_days)) {
                    for (let i = 0; i < sbs_ajax.closed_days.length; i++) {
                        let c_date = sbs_ajax.closed_days[i];
                        let start = (typeof c_date === 'object') ? c_date.start : c_date;
                        let end = (typeof c_date === 'object') ? c_date.end : c_date;
                        if (formattedDate >= start && formattedDate <= end) {
                            isHoliday = true;
                            break;
                        }
                    }
                }
                
                if (isHoliday) {
                    dayDiv.classList.add('sbs-disabled');
                    dayDiv.classList.add('sbs-disabled-holiday');
                } 
                // Check if the shop is open on this specific day based on the alternating week schedule
                else if (isDayAvailable(thisDate)) {
                    dayDiv.classList.add('sbs-available');
                    dayDiv.addEventListener('click', () => selectDate(dayDiv, formattedDate));
                } else {
                    dayDiv.classList.add('sbs-disabled');
                    dayDiv.classList.add('sbs-disabled-unavailable');
                }
            }

            daysGrid.appendChild(dayDiv);
        }
        
        // Button states
        prevBtn.disabled = (month === today.getMonth() && year === today.getFullYear());
        nextBtn.disabled = (month === maxDate.getMonth() && year === maxDate.getFullYear());
    }

    function isDayAvailable(dateObj) {
        if (!sbs_ajax || !sbs_ajax.schedule) return true; // Fallback se non ci sono dati
        const schedule = sbs_ajax.schedule;
        if (!schedule.weeks || schedule.weeks.length === 0) return true;
        
        const targetDate = new Date(dateObj.getFullYear(), dateObj.getMonth(), dateObj.getDate());
        
        // Estrapola solo la data YYYY-MM-DD per evitare problemi di fuso orario
        const anchorStr = schedule.anchor_date || '2026-05-01';
        const anchorDate = new Date(anchorStr + 'T00:00:00'); 
        
        const totalWeeks = schedule.cycle_weeks || schedule.weeks.length;
        const daysInCycle = totalWeeks * 7;
        
        // Calcola differenza in giorni arrotondando in modo sicuro
        const diffTime = targetDate.getTime() - anchorDate.getTime();
        const diffDays = Math.round(diffTime / (1000 * 60 * 60 * 24));
        
        // Modulo sicuro per numeri negativi (se target è prima dell'anchor)
        let dayOffset = diffDays % daysInCycle;
        if (dayOffset < 0) dayOffset += daysInCycle;
        
        let weekIndex = Math.floor(dayOffset / 7);
        
        if (!schedule.weeks[weekIndex]) {
            weekIndex = 0;
        }
        
        const daysOfWeek = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
        const dayStr = daysOfWeek[targetDate.getDay()];
        
        const weekConfig = schedule.weeks[weekIndex];
        if (!weekConfig || !weekConfig[dayStr]) return false;
        
        // Considerato disponibile solo se è attivo E ha almeno uno slot inserito
        return parseInt(weekConfig[dayStr].active) === 1 && weekConfig[dayStr].slots && weekConfig[dayStr].slots.length > 0;
    }

    prevBtn.addEventListener('click', () => {
        if (currentMonth === 0) {
            currentMonth = 11;
            currentYear--;
        } else {
            currentMonth--;
        }
        renderCalendar(currentMonth, currentYear);
        hideSlots();
    });

    nextBtn.addEventListener('click', () => {
        if (currentMonth === 11) {
            currentMonth = 0;
            currentYear++;
        } else {
            currentMonth++;
        }
        renderCalendar(currentMonth, currentYear);
        hideSlots();
    });

    // Step Navigation Logic
    const step1 = document.getElementById('sbs-step-1');
    const step2 = document.getElementById('sbs-step-2');
    const step3 = document.getElementById('sbs-step-3');
    const step4 = document.getElementById('sbs-step-4');
    const step5 = document.getElementById('sbs-step-5');
    
    const nav1 = document.getElementById('nav-step-1');
    const nav2 = document.getElementById('nav-step-2');
    const nav3 = document.getElementById('nav-step-3');
    const nav4 = document.getElementById('nav-step-4');
    const nav5 = document.getElementById('nav-step-5');
    
    const serviceInput = document.getElementById('sbs_service_input');

    function goToStep(stepNum) {
        // Hide all steps
        step1.style.display = 'none';
        step2.style.display = 'none';
        step3.style.display = 'none';
        step4.style.display = 'none';
        step5.style.display = 'none';

        // Reset nav styles
        nav1.className = 'sbs-wizard-step';
        nav2.className = 'sbs-wizard-step';
        nav3.className = 'sbs-wizard-step';
        nav4.className = 'sbs-wizard-step';
        nav5.className = 'sbs-wizard-step';

        if (stepNum === 1) {
            step1.style.display = 'block';
            nav1.classList.add('sbs-wizard-active');
            if (currentServiceName) nav2.classList.add('sbs-wizard-completed');
            if (inputDate.value) nav3.classList.add('sbs-wizard-completed');
            if (inputTime.value) nav4.classList.add('sbs-wizard-completed');
        } 
        else if (stepNum === 2) {
            step2.style.display = 'block';
            nav1.classList.add('sbs-wizard-completed');
            nav2.classList.add('sbs-wizard-active');
            if (inputDate.value) nav3.classList.add('sbs-wizard-completed');
            if (inputTime.value) nav4.classList.add('sbs-wizard-completed');
            window.dispatchEvent(new Event('resize'));
        } 
        else if (stepNum === 3) {
            step3.style.display = 'block';
            nav1.classList.add('sbs-wizard-completed');
            nav2.classList.add('sbs-wizard-completed');
            nav3.classList.add('sbs-wizard-active');
            if (inputTime.value) nav4.classList.add('sbs-wizard-completed');
        }
        else if (stepNum === 4) {
            step4.style.display = 'block';
            nav1.classList.add('sbs-wizard-completed');
            nav2.classList.add('sbs-wizard-completed');
            nav3.classList.add('sbs-wizard-completed');
            nav4.classList.add('sbs-wizard-active');
        }
        else if (stepNum === 5) {
            step5.style.display = 'block';
            nav1.classList.add('sbs-wizard-completed');
            nav2.classList.add('sbs-wizard-completed');
            nav3.classList.add('sbs-wizard-completed');
            nav4.classList.add('sbs-wizard-completed');
            nav5.classList.add('sbs-wizard-active');
            
            // Update recap
            recapServiceName.textContent = currentServiceName;
            recapServiceDuration.textContent = currentServiceDuration;
            const dateObj = new Date(inputDate.value);
            recapDatetime.textContent = dateObj.toLocaleDateString('it-IT') + ' alle ' + inputTime.value;
            
            // Dati modulo
            document.getElementById('sbs-recap-name').textContent = document.getElementById('sbs_name').value || '-';
            document.getElementById('sbs-recap-email').textContent = document.getElementById('sbs_email').value || '-';
            document.getElementById('sbs-recap-phone').textContent = document.getElementById('sbs_phone').value || '-';
        }
    }

    // Attach events to radio buttons for Service Selection (Step 1 -> Step 2)
    serviceRadios.forEach(radio => {
        radio.addEventListener('change', function() {
            currentServiceName = this.value;
            currentServiceDuration = parseInt(this.getAttribute('data-duration')) || 15;
            
            // Popola l'input hidden per il form submission
            if (serviceInput) serviceInput.value = this.value;
            
            goToStep(2);
        });
    });

    // Attach events to nav buttons (breadcrumbs) if they are completed
    nav1.addEventListener('click', () => { if (nav1.classList.contains('sbs-wizard-completed')) goToStep(1); });
    nav2.addEventListener('click', () => { if (nav2.classList.contains('sbs-wizard-completed')) goToStep(2); });
    nav3.addEventListener('click', () => { if (nav3.classList.contains('sbs-wizard-completed')) goToStep(3); });
    nav4.addEventListener('click', () => { if (nav4.classList.contains('sbs-wizard-completed')) goToStep(4); });
    nav5.addEventListener('click', () => { if (nav5.classList.contains('sbs-wizard-completed')) goToStep(5); });

    // Attach events to back buttons
    document.querySelectorAll('.sbs-back-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            goToStep(parseInt(this.getAttribute('data-target')));
        });
    });

    function selectDate(dayElement, dateStr) {
        // Remove active class from all
        document.querySelectorAll('.sbs-day').forEach(el => el.classList.remove('sbs-selected'));
        dayElement.classList.add('sbs-selected');
        
        // Update Label
        const dateObj = new Date(dateStr);
        selectedDateLabel.textContent = dateObj.toLocaleDateString('it-IT', { weekday: 'long', day: 'numeric', month: 'long' });
        
        inputDate.value = dateStr;
        inputTime.value = ''; // Reset time when date changes
        nav4.classList.remove('sbs-wizard-completed'); // Reset step 4
        nav5.classList.remove('sbs-wizard-completed'); // Reset step 5

        showSlots(dateStr);
    }

    function hideSlots() {
        // Se cambio mese, resetto tutto
        inputDate.value = '';
        inputTime.value = '';
        goToStep(2); // Stay on calendar
    }

    function showSlots(dateStr) {
        goToStep(3); // Vai allo step orari
        slotsLoader.style.display = 'block';
        slotsGrid.style.display = 'none';

        // AJAX Call to get slots
        const formData = new FormData();
        formData.append('action', 'sbs_get_slots');
        formData.append('nonce', sbs_ajax.nonce);
        formData.append('date', dateStr);
        formData.append('duration', currentServiceDuration);

        fetch(sbs_ajax.ajax_url, {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            slotsLoader.style.display = 'none';
            slotsGrid.style.display = 'grid';
            slotsGrid.innerHTML = '';

            if (data.success && data.data.slots && data.data.slots.length > 0) {
                data.data.slots.forEach(slotData => {
                    const slotBtn = document.createElement('div');
                    slotBtn.className = 'sbs-slot';
                    slotBtn.textContent = slotData.time;
                    
                    if (slotData.available) {
                        slotBtn.addEventListener('click', () => selectSlot(slotBtn, slotData.time));
                    } else {
                        slotBtn.classList.add('sbs-slot-booked');
                    }
                    
                    slotsGrid.appendChild(slotBtn);
                });
            } else {
                slotsGrid.innerHTML = '<p style="grid-column: 1 / -1; color: #666; font-size:0.9rem; text-align:center;">Nessun orario disponibile per questa data. Il negozio potrebbe essere chiuso o al completo.</p>';
            }
        })
        .catch(error => {
            slotsLoader.style.display = 'none';
            slotsGrid.innerHTML = '<p style="color:red; text-align:center;">Errore nel caricamento degli orari.</p>';
            slotsGrid.style.display = 'block';
        });
    }

    function selectSlot(slotElement, timeStr) {
        document.querySelectorAll('.sbs-slot').forEach(el => el.classList.remove('sbs-selected'));
        slotElement.classList.add('sbs-selected');
        
        inputTime.value = timeStr;
        goToStep(4);
    }
    
    // Bottone Continua da Step 4 a Step 5
    document.getElementById('sbs-goto-step5-btn').addEventListener('click', function() {
        // Check HTML5 validation before continuing
        if (bookingForm.checkValidity()) {
            goToStep(5);
        } else {
            bookingForm.reportValidity();
        }
    });

    // Form Submission
    bookingForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        submitBtn.disabled = true;
        submitBtn.textContent = 'Invio in corso...';
        formMsg.style.display = 'none';
        formMsg.className = 'sbs-msg';

        const formData = new FormData(bookingForm);
        formData.append('action', 'sbs_submit_booking');
        formData.append('nonce', sbs_ajax.nonce);

        fetch(sbs_ajax.ajax_url, {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                step5.innerHTML = `<div class="sbs-msg sbs-success" style="display:block; text-align:center; padding: 40px 20px;">
                    <h3 style="margin-top:0;">Richiesta Inviata! 🎉</h3>
                    <p>${data.data.message}</p>
                </div>`;
                nav5.classList.add('sbs-wizard-completed');
                nav5.classList.remove('sbs-wizard-active');
            } else {
                formMsg.textContent = data.data.message || 'Si è verificato un errore.';
                formMsg.className = 'sbs-msg sbs-error';
                formMsg.style.display = 'block';
                submitBtn.disabled = false;
                submitBtn.textContent = 'Conferma Prenotazione Definitiva';
            }
        })
        .catch(error => {
            formMsg.textContent = 'Errore di rete. Riprova più tardi.';
            formMsg.className = 'sbs-msg sbs-error';
            formMsg.style.display = 'block';
            submitBtn.disabled = false;
            submitBtn.textContent = 'Conferma Prenotazione Definitiva';
        });
    });

    // Initialize Calendar
    renderCalendar(currentMonth, currentYear);
    goToStep(1); // Force init on step 1
});
