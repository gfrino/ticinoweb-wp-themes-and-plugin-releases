<?php
class SBS_Public {
    private $plugin_name;
    private $version;

    public function __construct( $plugin_name, $version ) {
        $this->plugin_name = $plugin_name;
        $this->version = $version;
    }

    public function enqueue_styles() {
        wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/sbs-public.css', array(), $this->version, 'all' );
    }

    public function enqueue_scripts() {
        wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/sbs-public.js', array(), $this->version, true );
        
        $hours = get_option( 'sbs_working_hours', [] );
        if ( !isset($hours['weeks']) ) {
            $hours = [
                'anchor_date' => date('Y-m-d'),
                'weeks' => [ 0 => [] ]
            ];
        }

        $closed_days = get_option( 'sbs_closed_days', [] );
        if ( !is_array($closed_days) ) {
            $closed_days = [];
        }

        wp_localize_script( $this->plugin_name, 'sbs_ajax', array(
            'ajax_url'    => admin_url( 'admin-ajax.php' ),
            'nonce'       => wp_create_nonce( 'sbs_public_nonce' ),
            'schedule'    => $hours,
            'closed_days' => $closed_days
        ) );
    }

    public function render_shortcode( $atts ) {
        $settings = get_option( 'sbs_settings', [] );
        $enable_booking = $settings['enable_booking'] ?? 'yes';

        ob_start();

        if ( $enable_booking === 'no' ) {
            $msg = $settings['booking_disabled_msg'] ?? "Le prenotazioni online sono momentaneamente disattivate.\n\nChiamaci al +41 91 745 80 80 per prenotare il tuo appuntamento.";
            ?>
            <div class="sbs-booking-disabled" style="background: #fff; padding: 40px; border-radius: 12px; box-shadow: 0 10px 30px rgba(0,0,0,0.08); text-align: center; max-width: 600px; margin: 40px auto; border-top: 4px solid #2271b1;">
                <svg viewBox="0 0 24 24" width="64" height="64" stroke="#2271b1" stroke-width="1.5" fill="none" stroke-linecap="round" stroke-linejoin="round" style="margin-bottom: 20px;"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path></svg>
                <h3 style="font-size: 22px; color: #1d2327; margin-bottom: 15px; font-weight: 600;">Prenotazioni Temporaneamente Sospese</h3>
                <div style="font-size: 16px; color: #50575e; line-height: 1.6; white-space: pre-wrap;"><?php echo nl2br($msg); ?></div>
            </div>
            <?php
            return ob_get_clean();
        }
        ?>
        <div class="sbs-booking-intro">
            <h2 class="sbs-intro-title">Prenota il tuo Appuntamento</h2>
            <p class="sbs-intro-desc">Seleziona il giorno e l'orario che preferisci per la tua visita. Ti guideremo in pochi e semplici passi.</p>
        </div>
        
        <div id="sbs-booking-wrapper" class="sbs-calendar-wrapper">
            
            <!-- Progress Bar / Wizard Header -->
            <div class="sbs-wizard-header">
                <div class="sbs-wizard-step sbs-wizard-active" data-step="1" id="nav-step-1">
                    <span class="step-num">1</span> <span class="step-label">Servizio</span>
                </div>
                <div class="sbs-wizard-divider"></div>
                <div class="sbs-wizard-step" data-step="2" id="nav-step-2">
                    <span class="step-num">2</span> <span class="step-label">Data</span>
                </div>
                <div class="sbs-wizard-divider"></div>
                <div class="sbs-wizard-step" data-step="3" id="nav-step-3">
                    <span class="step-num">3</span> <span class="step-label">Orario</span>
                </div>
                <div class="sbs-wizard-divider"></div>
                <div class="sbs-wizard-step" data-step="4" id="nav-step-4">
                    <span class="step-num">4</span> <span class="step-label">Modulo</span>
                </div>
                <div class="sbs-wizard-divider"></div>
                <div class="sbs-wizard-step" data-step="5" id="nav-step-5">
                    <span class="step-num">5</span> <span class="step-label">Conferma</span>
                </div>
            </div>

            <?php 
            $settings = get_option( 'sbs_settings', [] );
            $dur_vista = absint( $settings['duration_vista'] ?? 30 );
            $dur_lenti = absint( $settings['duration_lenti'] ?? 30 );
            $dur_patente = absint( $settings['duration_patente'] ?? 15 );
            ?>

            <!-- STEP 1: SCELTA SERVIZIO -->
            <div id="sbs-step-1" class="sbs-step sbs-step-active">
                <div class="sbs-form-group" style="margin-top: 10px; padding: 0 40px; margin-bottom: 40px;">
                    <div class="sbs-service-boxes">
                        <label class="sbs-service-box">
                            <input type="radio" name="sbs_service" value="Controllo Vista" data-duration="<?php echo $dur_vista; ?>">
                            <div class="sbs-service-box-content">
                                <div class="sbs-service-icon">
                                    <svg viewBox="0 0 24 24" width="32" height="32" stroke="currentColor" stroke-width="1.5" fill="none" stroke-linecap="round" stroke-linejoin="round"><path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z"></path><circle cx="12" cy="12" r="3"></circle></svg>
                                </div>
                                <div class="sbs-service-info">
                                    <span class="sbs-service-title">Controllo della Vista</span>
                                    <span class="sbs-service-desc">Esame visivo professionale e approfondito</span>
                                    <span style="display:inline-block; margin-top:5px; font-size:11px; font-weight:600; background:rgba(255,255,255,0.2); padding:2px 8px; border-radius:10px;">⏱ Durata: <?php echo $dur_vista; ?> min</span>
                                </div>
                            </div>
                        </label>
                        
                        <label class="sbs-service-box">
                            <input type="radio" name="sbs_service" value="Lenti a Contatto" data-duration="<?php echo $dur_lenti; ?>">
                            <div class="sbs-service-box-content">
                                <div class="sbs-service-icon">
                                    <svg viewBox="0 0 24 24" width="32" height="32" stroke="currentColor" stroke-width="1.5" fill="none" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"></path></svg>
                                </div>
                                <div class="sbs-service-info">
                                    <span class="sbs-service-title">Lenti a Contatto</span>
                                    <span class="sbs-service-desc">Applicazione e verifica parametri lenti</span>
                                    <span style="display:inline-block; margin-top:5px; font-size:11px; font-weight:600; background:rgba(255,255,255,0.2); padding:2px 8px; border-radius:10px;">⏱ Durata: <?php echo $dur_lenti; ?> min</span>
                                </div>
                            </div>
                        </label>

                        <label class="sbs-service-box">
                            <input type="radio" name="sbs_service" value="Test Patente" data-duration="<?php echo $dur_patente; ?>">
                            <div class="sbs-service-box-content">
                                <div class="sbs-service-icon">
                                    <svg viewBox="0 0 24 24" width="32" height="32" stroke="currentColor" stroke-width="1.5" fill="none" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path></svg>
                                </div>
                                <div class="sbs-service-info">
                                    <span class="sbs-service-title">Esame Patente</span>
                                    <span class="sbs-service-desc">Certificato ottico per licenza condurre</span>
                                    <span style="display:inline-block; margin-top:5px; font-size:11px; font-weight:600; background:rgba(255,255,255,0.2); padding:2px 8px; border-radius:10px;">⏱ Durata: <?php echo $dur_patente; ?> min</span>
                                </div>
                            </div>
                        </label>
                    </div>
                </div>
            </div>

            <!-- STEP 2: CALENDARIO E ORARI -->
            <div id="sbs-step-2" class="sbs-step" style="display:none; position: relative;">
                <div class="sbs-step-title" style="margin-bottom: 20px;">
                    <button type="button" class="sbs-back-btn" data-target="1">&larr; Indietro</button>
                    <h4 style="margin:0; text-align:center; flex:1;">Scegli la Data</h4>
                </div>
                <?php
                // Preleva il logo dinamicamente dal CMS (ticinoWEB logic)
                $logo_url = '';
                if (function_exists('ticinoweb_get_site_logo')) {
                    $logo_url = ticinoweb_get_site_logo();
                } else {
                    $custom_logo_id = get_theme_mod( 'custom_logo' );
                    $logo_url = wp_get_attachment_image_url( $custom_logo_id, 'full' );
                }
                
                if ( $logo_url ) {
                    echo '<div class="sbs-calendar-watermark" style="background-image: url(' . esc_url( $logo_url ) . ');"></div>';
                }
                ?>
                <div class="sbs-calendar-header" style="position: relative; z-index: 2;">
                    <button type="button" class="sbs-nav-btn" id="sbs-prev-month">&lsaquo;</button>
                    <h3 id="sbs-month-year">Caricamento...</h3>
                    <button type="button" class="sbs-nav-btn" id="sbs-next-month">&rsaquo;</button>
                </div>
                
                <div class="sbs-calendar-grid" style="position: relative; z-index: 2;">
                    <div class="sbs-weekdays">
                        <div>Lun</div><div>Mar</div><div>Mer</div><div>Gio</div><div>Ven</div><div>Sab</div><div>Dom</div>
                    </div>
                    <div id="sbs-days-grid" class="sbs-days"></div>
                </div>
            </div>

            <!-- STEP 3: ORARI -->
            <div id="sbs-step-3" class="sbs-step" style="display:none;">
                <div class="sbs-step-title" style="margin-bottom: 20px;">
                    <button type="button" class="sbs-back-btn" data-target="2">&larr; Indietro</button>
                    <h4 style="margin:0; text-align:center; flex:1;">Orari disponibili per il <span id="sbs-selected-date-label"></span></h4>
                </div>
                <div id="sbs-slots-container" class="sbs-slots-container" style="display:block; background:transparent;">
                    <div id="sbs-slots-loader" class="sbs-loader">Ricerca disponibilità...</div>
                    <div id="sbs-slots-grid" class="sbs-slots-grid"></div>
                </div>
            </div>

            <form id="sbs-booking-form">
                <input type="hidden" id="sbs_date" name="sbs_date">
                <input type="hidden" id="sbs_time" name="sbs_time">
                <input type="hidden" id="sbs_service_input" name="sbs_service">
                <!-- Honeypot -->
                <input type="text" name="sbs_honeypot" style="display:none !important;" tabindex="-1" autocomplete="off">

                <!-- STEP 4: MODULO PRENOTAZIONE -->
                <div id="sbs-step-4" class="sbs-step" style="display:none;">
                    <div class="sbs-step-title" style="margin-bottom: 25px;">
                        <button type="button" class="sbs-back-btn" data-target="3">&larr; Indietro</button>
                        <h4 style="margin:0; text-align:center; flex:1;">I Tuoi Dati</h4>
                    </div>
                    <div id="sbs-booking-form-container" class="sbs-booking-form" style="display:block; padding-top: 0; padding-bottom: 40px;">

                        <div class="sbs-form-group">
                            <label>Nome e Cognome</label>
                            <input type="text" id="sbs_name" name="sbs_name" required>
                        </div>

                        <div class="sbs-form-group">
                            <label>Email</label>
                            <input type="email" id="sbs_email" name="sbs_email" required>
                        </div>

                        <div class="sbs-form-group">
                            <label>Telefono</label>
                            <input type="tel" id="sbs_phone" name="sbs_phone" required>
                        </div>

                        <div class="sbs-form-group">
                            <label>Note (Opzionale)</label>
                            <textarea id="sbs_notes" name="sbs_notes" rows="2"></textarea>
                        </div>

                        <div class="sbs-form-group">
                            <label style="font-weight: normal;">
                                <input type="checkbox" required name="sbs_gdpr"> 
                                Accetto il trattamento dei dati personali (GDPR).
                            </label>
                        </div>

                        <p style="font-size:0.85rem; color:#666;">
                            Tutti gli appuntamenti base sono gratuiti. L'eventuale tassa cantonale per la patente (CHF 22) si paga in sede.
                        </p>

                        <button type="button" class="sbs-submit-btn" id="sbs-goto-step5-btn">Vai alla Conferma</button>
                    </div>
                </div>

                <!-- STEP 5: CONFERMA FINALE -->
                <div id="sbs-step-5" class="sbs-step" style="display:none;">
                    <div class="sbs-step-title" style="margin-bottom: 25px;">
                        <button type="button" class="sbs-back-btn" data-target="4">&larr; Indietro</button>
                        <h4 style="margin:0; text-align:center; flex:1;">Riepilogo della tua prenotazione</h4>
                    </div>
                    
                    <div id="sbs-final-recap" style="padding: 0 40px; margin-bottom: 30px;">
                        
                        <!-- Dettagli Appuntamento -->
                        <h5 style="margin: 0 0 20px 0; font-size: 18px; color: #1a202c; border-bottom: 2px solid rgba(0,0,0,0.05); padding-bottom: 10px;">Dettagli Appuntamento</h5>
                        
                        <div style="display: flex; flex-direction: column; gap: 20px; margin-bottom: 30px;">
                            <div style="display: flex; align-items: flex-start; gap: 15px;">
                                <div style="background: #e2e8f0; padding: 12px; border-radius: 10px; color: #4a5568;">
                                    <svg viewBox="0 0 24 24" width="22" height="22" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line></svg>
                                </div>
                                <div>
                                    <div style="font-size: 13px; text-transform: uppercase; letter-spacing: 0.5px; color: #718096; margin-bottom: 4px;">Servizio Richiesto</div>
                                    <div style="font-size: 18px; font-weight: 600; color: #2d3748;"><span id="sbs-recap-service-name"></span> <span style="font-size: 14px; font-weight: normal; color: #718096;">(<span id="sbs-recap-service-duration"></span> min)</span></div>
                                </div>
                            </div>
                            
                            <div style="display: flex; align-items: flex-start; gap: 15px;">
                                <div style="background: #ebf8ff; padding: 12px; border-radius: 10px; color: #3182ce;">
                                    <svg viewBox="0 0 24 24" width="22" height="22" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 16 14"></polyline></svg>
                                </div>
                                <div>
                                    <div style="font-size: 13px; text-transform: uppercase; letter-spacing: 0.5px; color: #718096; margin-bottom: 4px;">Data e Ora</div>
                                    <div style="font-size: 18px; font-weight: 600; color: #2d3748;" id="sbs-recap-datetime"></div>
                                </div>
                            </div>
                        </div>

                        <!-- I Tuoi Dati -->
                        <h5 style="margin: 0 0 20px 0; font-size: 18px; color: #1a202c; border-bottom: 2px solid rgba(0,0,0,0.05); padding-bottom: 10px;">I Tuoi Dati</h5>
                        
                        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px;">
                            <div style="display: flex; align-items: flex-start; gap: 12px;">
                                <div style="color: #a0aec0; margin-top:2px;">
                                    <svg viewBox="0 0 24 24" width="20" height="20" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>
                                </div>
                                <div>
                                    <div style="font-size: 13px; color: #718096; margin-bottom: 2px;">Nome</div>
                                    <div style="font-size: 16px; font-weight: 500; color: #2d3748;" id="sbs-recap-name"></div>
                                </div>
                            </div>
                            
                            <div style="display: flex; align-items: flex-start; gap: 12px;">
                                <div style="color: #a0aec0; margin-top:2px;">
                                    <svg viewBox="0 0 24 24" width="20" height="20" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path><polyline points="22,6 12,13 2,6"></polyline></svg>
                                </div>
                                <div>
                                    <div style="font-size: 13px; color: #718096; margin-bottom: 2px;">Email</div>
                                    <div style="font-size: 16px; font-weight: 500; color: #2d3748; word-break: break-all;" id="sbs-recap-email"></div>
                                </div>
                            </div>
                            
                            <div style="display: flex; align-items: flex-start; gap: 12px;">
                                <div style="color: #a0aec0; margin-top:2px;">
                                    <svg viewBox="0 0 24 24" width="20" height="20" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path></svg>
                                </div>
                                <div>
                                    <div style="font-size: 13px; color: #718096; margin-bottom: 2px;">Telefono</div>
                                    <div style="font-size: 16px; font-weight: 500; color: #2d3748;" id="sbs-recap-phone"></div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div id="sbs-form-msg" style="padding: 0 40px;"></div>
                    <div style="padding: 0 40px 40px 40px;">
                        <button type="submit" class="sbs-submit-btn" id="sbs-submit-btn" style="font-size: 18px; padding: 18px; border-radius: 12px; box-shadow: 0 6px 20px rgba(0, 115, 230, 0.3);">Conferma Prenotazione Definitiva</button>
                    </div>
                </div>
            </form>
        </div>
        <?php
        return ob_get_clean();
    }
}
