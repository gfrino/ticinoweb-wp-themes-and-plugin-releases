<?php
class SBS_Admin {
    private $plugin_name;
    private $version;

    public function __construct( $plugin_name, $version ) {
        $this->plugin_name = $plugin_name;
        $this->version = $version;
    }

    public function enqueue_styles() {
        // wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/sbs-admin.css', array(), $this->version, 'all' );
    }

    public function enqueue_scripts() {
        // wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/sbs-admin.js', array( 'jquery' ), $this->version, false );
    }

    public function add_plugin_admin_menu() {
        add_menu_page(
            'Prenotazioni', 
            'Prenotazioni', 
            'manage_options', 
            $this->plugin_name, 
            array( $this, 'display_plugin_setup_page' ), 
            'dashicons-calendar-alt', 
            26
        );

        add_submenu_page(
            $this->plugin_name,
            'Calendario',
            'Calendario',
            'manage_options',
            $this->plugin_name . '-calendar',
            array( $this, 'display_plugin_calendar_page' )
        );

        add_submenu_page(
            $this->plugin_name,
            'Orari e Chiusure',
            'Orari e Chiusure',
            'manage_options',
            $this->plugin_name . '-settings',
            array( $this, 'display_plugin_settings_page' )
        );

        add_submenu_page(
            $this->plugin_name,
            'Gestione Mail',
            'Gestione Mail',
            'manage_options',
            $this->plugin_name . '-emails',
            array( $this, 'display_plugin_emails_page' )
        );

        add_submenu_page(
            $this->plugin_name,
            'Google Calendar',
            'Google Calendar',
            'manage_options',
            $this->plugin_name . '-gcal',
            array( $this, 'display_plugin_gcal_page' )
        );
    }
    
    public function register_settings() {
        register_setting( 'sbs_settings_group', 'sbs_settings' );
        register_setting( 'sbs_settings_group', 'sbs_working_hours' );
    }

    public function display_plugin_setup_page() {
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }
        
        require_once plugin_dir_path( dirname( __FILE__ ) ) . 'admin/class-sbs-list-table.php';
        
        // Upgrade DB al volo se gcal_event_id non esiste
        global $wpdb;
        $table_name = $wpdb->prefix . 'sbs_bookings';
        $row = $wpdb->get_results( "SHOW COLUMNS FROM `$table_name` LIKE 'gcal_event_id'" );
        if ( empty( $row ) ) {
            $wpdb->query( "ALTER TABLE `$table_name` ADD `gcal_event_id` VARCHAR(255) DEFAULT NULL AFTER `token`" );
        }
        
        $list_table = new SBS_List_Table();
        $list_table->prepare_items();
        ?>
        <div class="wrap">
            <h1 class="wp-heading-inline">Gestione Prenotazioni</h1>
            <a href="#" id="sbs-btn-new-booking" class="page-title-action">Nuovo Appuntamento</a>
            <hr class="wp-header-end">
            
            <form id="bookings-filter" method="get">
                <input type="hidden" name="page" value="<?php echo esc_attr( $_REQUEST['page'] ); ?>" />
                <?php $list_table->display(); ?>
            </form>
        </div>
        <?php
        $this->render_manual_booking_modal();
    }

    public function display_plugin_calendar_page() {
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }
        ?>
        <div class="wrap">
            <h1 class="wp-heading-inline">Calendario Appuntamenti</h1>
            <a href="#" id="sbs-btn-new-booking-cal" class="page-title-action sbs-btn-new-booking-trigger">Nuovo Appuntamento</a>
            <hr class="wp-header-end">
            
            <div id="sbs-calendar-container" style="margin-top: 20px; background: #fff; padding: 20px; border-radius: 8px; box-shadow: 0 1px 3px rgba(0,0,0,0.1);">
                <div id='sbs-admin-calendar'></div>
            </div>

            <!-- Modale Custom per i Dettagli Appuntamento -->
            <div id="sbs-event-modal" class="sbs-modal-overlay">
                <div class="sbs-modal-content">
                    <span class="sbs-modal-close">&times;</span>
                    <div class="sbs-modal-header">
                        <h2 id="sbs-modal-title">Dettagli Appuntamento</h2>
                        <span id="sbs-modal-status" class="sbs-status-badge"></span>
                    </div>
                    <div class="sbs-modal-body">
                        <div class="sbs-info-group" style="animation-delay: 0.1s;">
                            <label><span class="dashicons dashicons-calendar-alt"></span> Data e Ora:</label>
                            <div id="sbs-modal-time"></div>
                        </div>
                        <div class="sbs-info-group" style="animation-delay: 0.2s;">
                            <label><span class="dashicons dashicons-phone"></span> Telefono:</label>
                            <div id="sbs-modal-phone"></div>
                        </div>
                        <div class="sbs-info-group" style="animation-delay: 0.3s;">
                            <label><span class="dashicons dashicons-edit"></span> Note del cliente:</label>
                            <div id="sbs-modal-notes" class="sbs-notes-box"></div>
                        </div>
                    </div>
                    <div class="sbs-modal-footer">
                        <button id="sbs-modal-btn-delete" class="button button-link-delete" style="color:#d63638; display:none; float:left; margin-top:5px; text-decoration:none;">Elimina</button>
                        <button id="sbs-modal-btn-close" class="button button-secondary">Chiudi</button>
                    </div>
                </div>
            </div>
        </div>

        <?php $this->render_manual_booking_modal(); ?>

        <!-- Stili personalizzati per il Calendario -->
        <style>



                padding: 25px 30px 20px;
                border-bottom: 1px solid #eee;
            }
            .sbs-modal-header h2 {
                margin: 0 0 12px 0;
                font-size: 24px;
                color: #1d2327;
                font-weight: 600;
                display: flex;
                align-items: center;
                gap: 10px;
            }
            .sbs-status-badge {
                display: inline-block;
                padding: 6px 14px;
                border-radius: 20px;
                font-size: 11px;
                font-weight: 700;
                text-transform: uppercase;
                letter-spacing: 1px;
                box-shadow: 0 3px 8px rgba(0,0,0,0.1);
            }
            .sbs-status-pending { background: #f0c33c; color: #fff; }
            .sbs-status-confirmed { background: #46b450; color: #fff; }
            .sbs-status-cancelled { background: #d63638; color: #fff; }
            
            .sbs-modal-body {
                padding: 25px 30px;
            }
            .sbs-info-group {
                margin-bottom: 20px;
                opacity: 0;
                transform: translateY(15px);
                animation: sbsSlideUp 0.5s cubic-bezier(0.16, 1, 0.3, 1) forwards;
            }
            @keyframes sbsSlideUp {
                to { opacity: 1; transform: translateY(0); }
            }
            .sbs-info-group label {
                display: flex;
                align-items: center;
                gap: 6px;
                font-weight: 600;
                color: #646970;
                margin-bottom: 8px;
                font-size: 12px;
                text-transform: uppercase;
                letter-spacing: 0.5px;
            }
            .sbs-info-group label .dashicons {
                font-size: 16px;
                width: 16px;
                height: 16px;
                color: #2271b1;
            }
            .sbs-info-group div {
                font-size: 17px;
                color: #1d2327;
                padding-left: 22px; /* Allinea con il testo saltando l'icona */
            }
            .sbs-notes-box {
                background: #f6f7f7;
                padding: 15px;
                border-radius: 6px;
                font-style: italic;
                color: #50575e !important;
                border-left: 3px solid #2271b1;
                min-height: 50px;
                white-space: pre-wrap;
            }
            .sbs-modal-footer {
                padding: 20px 30px;
                border-top: 1px solid #eee;
                text-align: right;
                background: #fcfcfc;
                border-radius: 0 0 12px 12px;
            }


            /* Eliminiamo gli sfondi per tutti i giorni, lasciamo bianco */
            
            /* Evidenziazione SOLO del giorno odierno (sostituisce il giallo di default con il colore del giorno) */
            .fc-day-today.fc-day-mon { background-color: rgba(55, 136, 216, 0.12) !important; }
            .fc-day-today.fc-day-tue { background-color: rgba(243, 156, 18, 0.12) !important; }
            .fc-day-today.fc-day-wed { background-color: rgba(46, 204, 113, 0.12) !important; }
            .fc-day-today.fc-day-thu { background-color: rgba(155, 89, 182, 0.12) !important; }
            .fc-day-today.fc-day-fri { background-color: rgba(231, 76, 60, 0.12) !important; }
            .fc-day-today.fc-day-sat { background-color: rgba(0, 188, 212, 0.12) !important; }
            .fc-day-today.fc-day-sun { background-color: rgba(52, 73, 94, 0.12) !important; }

            /* Rendi gli appuntamenti (Eventi) più grandi e chiari */
            .fc-timegrid-event {
                min-height: 45px !important; /* Forza un'altezza minima per leggere tutto il testo (utile per slot da 15min) */
            }
            .fc-event {
                border-radius: 4px !important;
                border: none !important;
                padding: 4px !important;
                box-shadow: 0 2px 4px rgba(0,0,0,0.2) !important;
                transition: transform 0.2s ease, box-shadow 0.2s ease, z-index 0.2s ease;
                cursor: pointer;
                overflow: hidden !important;
            }
            .fc-event:hover {
                transform: scale(1.05);
                box-shadow: 0 4px 12px rgba(0,0,0,0.3) !important;
                z-index: 99 !important; /* Porta in primo piano assoluto */
            }
            .fc-event-main {
                display: flex;
                flex-direction: column;
                gap: 2px;
                overflow: visible !important;
            }
            .fc-event-time {
                font-size: 11px !important;
                font-weight: 700 !important;
                opacity: 0.9 !important;
            }
            .fc-event-title {
                font-size: 12px !important;
                font-weight: 600 !important;
                line-height: 1.2 !important;
                white-space: normal !important; /* Permette al testo lungo di andare a capo */
                overflow: visible !important;
            }
        </style>

        <!-- Inclusione FullCalendar v6 CDN -->
        <script src='https://cdn.jsdelivr.net/npm/fullcalendar@6.1.15/index.global.min.js'></script>
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                var calendarEl = document.getElementById('sbs-admin-calendar');
                
                var calendar = new FullCalendar.Calendar(calendarEl, {
                    initialView: 'timeGridWeek',
                    locale: 'it',
                    headerToolbar: {
                        left: 'prev,next today',
                        center: 'title',
                        right: 'dayGridMonth,timeGridWeek,timeGridDay'
                    },
                    buttonText: {
                        today: 'Oggi',
                        month: 'Mese',
                        week: 'Settimana',
                        day: 'Giorno'
                    },
                    slotMinTime: '08:00:00',
                    slotMaxTime: '20:00:00',
                    slotLabelInterval: '01:00',
                    slotDuration: '00:15:00',
                    expandRows: true, /* Espande le righe per usare tutto lo spazio, rendendo gli slot da 15min più alti */
                    allDaySlot: true,
                    events: function(info, successCallback, failureCallback) {
                        var formData = new FormData();
                        formData.append('action', 'sbs_admin_get_events');
                        formData.append('nonce', '<?php echo wp_create_nonce("sbs_admin_nonce"); ?>');
                        formData.append('start', info.startStr);
                        formData.append('end', info.endStr);

                        fetch(ajaxurl, {
                            method: 'POST',
                            body: formData
                        })
                        .then(response => response.json())
                        .then(data => {
                            successCallback(data);
                        })
                        .catch(error => {
                            failureCallback(error);
                        });
                    },
                    eventClick: function(info) {
                        // Impedisce il comportamento di default se presente url
                        info.jsEvent.preventDefault();
                        
                        var modal = document.getElementById('sbs-event-modal');
                        var closeBtn = document.querySelector('.sbs-modal-close');
                        var footCloseBtn = document.getElementById('sbs-modal-btn-close');
                        
                        // Formatta dati
                        var props = info.event.extendedProps;
                        var title = info.event.title || 'Senza Nome';
                        var status = props.status || 'Sconosciuto';
                        var phone = props.phone || 'Non specificato';
                        var notes = props.notes || 'Nessuna nota dal cliente.';
                        
                        // Imposta la data formattata
                        var startOptions = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', hour: '2-digit', minute:'2-digit' };
                        var endOptions = { hour: '2-digit', minute:'2-digit' };
                        var dateStr = info.event.start.toLocaleDateString('it-IT', startOptions) + ' - ' + info.event.end.toLocaleTimeString('it-IT', endOptions);
                        
                        // Rimuove emoji iniziali dal titolo se presenti, per un look più pulito, visto che c'è già il badge (opzionale, ma utile)
                        title = title.replace(/^[✅❌⏳]\s*/, '');
                        document.getElementById('sbs-modal-title').innerHTML = '<span class="dashicons dashicons-id"></span> ' + title;
                        document.getElementById('sbs-modal-time').textContent = dateStr;
                        document.getElementById('sbs-modal-phone').innerHTML = phone !== 'Non specificato' ? '<a href="tel:' + phone + '" style="color:#2271b1; text-decoration:none; font-weight:600;">' + phone + '</a>' : phone;
                        document.getElementById('sbs-modal-notes').textContent = notes;
                        
                        // Gestione Badge Status
                        var badge = document.getElementById('sbs-modal-status');
                        badge.textContent = status;
                        badge.className = 'sbs-status-badge'; // reset
                        if (status.toLowerCase() === 'pending' || status.toLowerCase() === 'in attesa') {
                            badge.classList.add('sbs-status-pending');
                        } else if (status.toLowerCase() === 'confirmed' || status.toLowerCase() === 'confermato' || status.toLowerCase() === 'approved') {
                            badge.classList.add('sbs-status-confirmed');
                        } else if (status.toLowerCase() === 'cancelled' || status.toLowerCase() === 'rifiutato') {
                            badge.classList.add('sbs-status-cancelled');
                        }
                        
                        // Per far ripartire le animazioni CSS degli elementi interni ogni volta che si apre la modale
                        var groups = document.querySelectorAll('.sbs-info-group');
                        groups.forEach(function(el) {
                            el.style.animation = 'none';
                            el.offsetHeight; /* trigger reflow */
                            el.style.animation = null;
                        });
                        
                        // Mostra Modale
                        modal.classList.add('active');
                        
                        // Gestione pulsante Elimina
                        var delBtn = document.getElementById('sbs-modal-btn-delete');
                        delBtn.style.display = 'inline-block';
                        delBtn.onclick = function() {
                                if (confirm('Sei sicuro di voler eliminare questo appuntamento?')) {
                                    var data = {
                                        action: 'sbs_delete_booking',
                                        nonce: '<?php echo wp_create_nonce("sbs_admin_nonce"); ?>',
                                        id: info.event.id
                                    };
                                    jQuery.post(ajaxurl, data, function(response) {
                                        if (response.success) {
                                            info.event.remove();
                                            closeModal();
                                        } else {
                                            alert('Errore: ' + (response.data || 'Impossibile eliminare.'));
                                        }
                                    }).fail(function() {
                                        alert('Errore di connessione al server.');
                                    });
                                }
                            };
                        // Chiusura modale
                        var closeModal = function() {
                            modal.classList.remove('active');
                        };
                        
                        closeBtn.onclick = closeModal;
                        footCloseBtn.onclick = closeModal;
                        window.onclick = function(event) {
                            if (event.target === modal) {
                                closeModal();
                            }
                        };
                    }
                });
                
                calendar.render();
            });
        </script>
        <?php
    }

    public function render_manual_booking_modal() {
        ?>
        <style>
            /* Stili per la Modale Evento */
            .sbs-modal-overlay {
                display: none;
                position: fixed;
                z-index: 99999;
                left: 0;
                top: 0;
                width: 100%;
                height: 100%;
                background-color: rgba(0,0,0,0.6);
                backdrop-filter: blur(4px);
                align-items: center;
                justify-content: center;
            }
            .sbs-modal-overlay.active {
                display: flex;
                animation: sbsFadeIn 0.3s ease;
            }
            @keyframes sbsFadeIn {
                from { opacity: 0; }
                to { opacity: 1; }
            }
            .sbs-modal-content {
                background-color: #fff;
                animation: sbsPopUp 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275) forwards;
                border-radius: 12px;
                width: 100%;
                max-width: 500px;
                box-shadow: 0 15px 50px rgba(0,0,0,0.3);
                position: relative;
                transform: scale(0.95);
            }
            .fc-event {
                cursor: pointer;
                transition: all 0.2s ease;
                box-shadow: 0 2px 4px rgba(0,0,0,0.1);
                border: none !important;
                border-radius: 4px;
            }
            .fc-event-past {
                opacity: 0.5 !important;
            }
            @keyframes sbsPopUp {
                to { transform: scale(1); }
            }
            .sbs-modal-close {
                position: absolute;
                top: 15px;
                right: 20px;
                font-size: 28px;
                font-weight: bold;
                color: #aaa;
                cursor: pointer;
                line-height: 1;
                transition: color 0.2s;
            }
            .sbs-modal-close:hover {
                color: #333;
            }
            .sbs-modal-header {
                padding: 25px 30px 20px;
                border-bottom: 1px solid #eee;
            }
            .sbs-modal-header h2 {
                margin: 0 0 12px 0;
                font-size: 24px;
                color: #1d2327;
                font-weight: 600;
                display: flex;
                align-items: center;
                gap: 10px;
            }
            .sbs-status-badge {
                display: inline-block;
                padding: 6px 14px;
                border-radius: 20px;
                font-size: 11px;
                font-weight: 700;
                text-transform: uppercase;
                letter-spacing: 1px;
                box-shadow: 0 3px 8px rgba(0,0,0,0.1);
            }
            .sbs-status-pending { background: #f0c33c; color: #fff; }
            .sbs-status-confirmed { background: #46b450; color: #fff; }
            .sbs-status-cancelled { background: #d63638; color: #fff; }
            
            .sbs-modal-body {
                padding: 25px 30px;
            }
            .sbs-info-group {
                margin-bottom: 20px;
                opacity: 0;
                transform: translateY(15px);
                animation: sbsSlideUp 0.5s cubic-bezier(0.16, 1, 0.3, 1) forwards;
            }
            @keyframes sbsSlideUp {
                to { opacity: 1; transform: translateY(0); }
            }
            .sbs-info-group label {
                display: flex;
                align-items: center;
                gap: 6px;
                font-weight: 600;
                color: #646970;
                margin-bottom: 8px;
                font-size: 12px;
                text-transform: uppercase;
                letter-spacing: 0.5px;
            }
            .sbs-info-group label .dashicons {
                font-size: 16px;
                width: 16px;
                height: 16px;
                color: #2271b1;
            }
            #sbs-modal-time, #sbs-modal-phone {
                font-size: 15px;
                color: #1d2327;
            }
            .sbs-notes-box {
                background: #f6f7f7;
                border-left: 4px solid #2271b1;
                padding: 12px 15px;
                font-size: 14px;
                color: #3c434a;
                font-style: italic;
                margin-top: 5px;
                border-radius: 0 4px 4px 0;
            }
            .sbs-modal-footer {
                padding: 15px 30px;
                background: #f6f7f7;
                border-top: 1px solid #eee;
                text-align: right;
                border-radius: 0 0 12px 12px;
            }
        </style>
        <!-- Modale Creazione Manuale Appuntamento -->
        <div id="sbs-manual-booking-modal" class="sbs-modal-overlay">
            <div class="sbs-modal-content" style="max-width: 600px;">
                <span class="sbs-modal-close" id="sbs-manual-modal-close">&times;</span>
                <div class="sbs-modal-header">
                    <h2>Nuovo Appuntamento (Manuale)</h2>
                </div>
                <div class="sbs-modal-body">
                    <form id="sbs-manual-booking-form">
                        <table class="form-table" role="presentation">
                            <tbody>
                                <tr>
                                    <th scope="row"><label for="sbs_man_name">Nome e Cognome *</label></th>
                                    <td><input type="text" id="sbs_man_name" required class="regular-text"></td>
                                </tr>
                                <tr>
                                    <th scope="row"><label for="sbs_man_email">Email</label></th>
                                    <td><input type="email" id="sbs_man_email" class="regular-text"></td>
                                </tr>
                                <tr>
                                    <th scope="row"><label for="sbs_man_phone">Telefono</label></th>
                                    <td><input type="text" id="sbs_man_phone" class="regular-text"></td>
                                </tr>
                                <tr>
                                    <th scope="row"><label for="sbs_man_service">Servizio *</label></th>
                                    <td>
                                        <select id="sbs_man_service" required class="regular-text">
                                            <option value="">-- Seleziona --</option>
                                            <option value="Controllo della Vista">Controllo della Vista</option>
                                            <option value="Lenti a Contatto">Lenti a Contatto</option>
                                            <option value="Esame Patente">Esame Patente</option>
                                        </select>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row"><label for="sbs_man_date">Data *</label></th>
                                    <td><input type="date" id="sbs_man_date" required class="regular-text"></td>
                                </tr>
                                <tr>
                                    <th scope="row"><label for="sbs_man_time_start">Ora Inizio *</label></th>
                                    <td><input type="time" id="sbs_man_time_start" required></td>
                                </tr>
                                <tr>
                                    <th scope="row"><label for="sbs_man_time_end">Ora Fine / Durata</label></th>
                                    <td><input type="time" id="sbs_man_time_end"> <span class="description">Opzionale (se vuoto usa durata default)</span></td>
                                </tr>
                                <tr>
                                    <th scope="row"><label for="sbs_man_notes">Note interne</label></th>
                                    <td><textarea id="sbs_man_notes" rows="3" class="large-text"></textarea></td>
                                </tr>
                            </tbody>
                        </table>
                    </form>
                </div>
                <div class="sbs-modal-footer">
                    <button type="button" id="sbs-manual-btn-save" class="button button-primary">Salva Appuntamento</button>
                    <button type="button" id="sbs-manual-btn-cancel" class="button button-secondary">Annulla</button>
                </div>
            </div>
        </div>
        <script>
        jQuery(document).ready(function($) {
            var modal = $('#sbs-manual-booking-modal');
            
            $('#sbs-btn-new-booking, #sbs-btn-new-booking-cal, .sbs-btn-new-booking-trigger').on('click', function(e) {
                e.preventDefault();
                modal.addClass('active');
            });
            
            $('#sbs-manual-modal-close, #sbs-manual-btn-cancel').on('click', function() {
                modal.removeClass('active');
            });
            
            $('#sbs-manual-btn-save').on('click', function() {
                var btn = $(this);
                var form = $('#sbs-manual-booking-form')[0];
                
                if (!form.reportValidity()) {
                    return;
                }
                
                btn.prop('disabled', true).text('Salvataggio...');
                
                var data = {
                    action: 'sbs_create_manual_booking',
                    nonce: '<?php echo wp_create_nonce("sbs_admin_nonce"); ?>',
                    name: $('#sbs_man_name').val(),
                    email: $('#sbs_man_email').val(),
                    phone: $('#sbs_man_phone').val(),
                    service: $('#sbs_man_service').val(),
                    date: $('#sbs_man_date').val(),
                    time_start: $('#sbs_man_time_start').val(),
                    time_end: $('#sbs_man_time_end').val(),
                    notes: $('#sbs_man_notes').val()
                };
                
                $.post(ajaxurl, data, function(response) {
                    if (response.success) {
                        alert('Appuntamento salvato correttamente!');
                        window.location.reload();
                    } else {
                        alert('Errore: ' + (response.data || 'Impossibile salvare l\'appuntamento.'));
                        btn.prop('disabled', false).text('Salva Appuntamento');
                    }
                }).fail(function() {
                    alert('Errore di connessione al server.');
                    btn.prop('disabled', false).text('Salva Appuntamento');
                });
            });
        });
        </script>
        <?php
    }

    /**
     * Intervallo di date (HTML) della settimana $week_index del ciclo: l'occorrenza in corso
     * oppure, se è già passata, la prossima. Le settimane partono dal giorno di inizio ciclo.
     */
    private function get_cycle_week_range( $anchor_date, $total_weeks, $week_index ) {
        $total_weeks = max( 1, absint( $total_weeks ) );
        $tz     = wp_timezone();
        $anchor = date_create_immutable( $anchor_date . ' 00:00:00', $tz );
        if ( ! $anchor ) {
            return '';
        }
        $today      = current_datetime()->setTime( 0, 0, 0 );
        $start      = $anchor->modify( '+' . ( $week_index * 7 ) . ' days' );
        $cycle_days = $total_weeks * 7;
        if ( $start->modify( '+6 days' ) < $today ) {
            $cycles = (int) ceil( ( $today->getTimestamp() - $start->modify( '+6 days' )->getTimestamp() ) / ( $cycle_days * DAY_IN_SECONDS ) );
            $start  = $start->modify( '+' . ( $cycles * $cycle_days ) . ' days' );
            // Correzione per ore legali: ricalcola finché la settimana non è passata.
            while ( $start->modify( '+6 days' ) < $today ) {
                $start = $start->modify( '+' . $cycle_days . ' days' );
            }
        }
        $end   = $start->modify( '+6 days' );
        $label = sprintf(
            'valida dal <strong>%s</strong> al <strong>%s</strong>',
            esc_html( wp_date( 'D d/m/Y', $start->getTimestamp(), $tz ) ),
            esc_html( wp_date( 'D d/m/Y', $end->getTimestamp(), $tz ) )
        );
        if ( $start <= $today && $today <= $end ) {
            $label .= ' <span style="background:#00a32a; color:#fff; border-radius:3px; padding:2px 8px; font-size:11px; font-weight:600; text-transform:uppercase; vertical-align:middle;">In corso</span>';
        } elseif ( $start > $today ) {
            $label .= ' <span style="color:#646970;">(prossima)</span>';
        }
        return $label;
    }

    public function display_plugin_settings_page() {
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }

        // Recupera le opzioni salvate
        $settings = get_option( 'sbs_settings', [] );
        $hours = get_option( 'sbs_working_hours', [] );
        $closed_days = get_option( 'sbs_closed_days', [] );
        
        // Se è stato inviato il form di salvataggio
        if ( isset( $_POST['sbs_save_settings'] ) && check_admin_referer( 'sbs_settings_action', 'sbs_settings_nonce' ) ) {
            
            // Salvataggio Impostazioni Generali
            $settings['admin_email'] = sanitize_email( $_POST['sbs_admin_email'] );
            $settings['duration_vista'] = absint( $_POST['sbs_duration_vista'] );
            $settings['duration_lenti'] = absint( $_POST['sbs_duration_lenti'] );
            $settings['duration_patente'] = absint( $_POST['sbs_duration_patente'] );
            $settings['enable_booking'] = sanitize_text_field( $_POST['sbs_enable_booking'] ?? 'yes' );
            $settings['booking_disabled_msg'] = wp_kses_post( wp_unslash( $_POST['sbs_booking_disabled_msg'] ?? "Le prenotazioni online sono momentaneamente disattivate.\n\nChiamaci al +41 91 745 80 80 per prenotare il tuo appuntamento." ) );
            // Testi Email rimossi da qui e spostati in display_plugin_emails_page
            
            update_option( 'sbs_settings', $settings );

            // Salvataggio Orari (Ciclo Continuo)
            $new_hours = [];
            $new_hours['anchor_date'] = sanitize_text_field( wp_unslash( $_POST['sbs_anchor_date'] ?? '2026-05-01' ) );
            $new_hours['cycle_weeks'] = absint( $_POST['sbs_cycle_weeks'] ?? 4 );
            $new_hours['weeks'] = [];
            
            $days = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'];
            $total_weeks = $new_hours['cycle_weeks'];
            
            for ($w = 0; $w < $total_weeks; $w++) {
                $week_data = [];
                foreach ($days as $day) {
                    $is_active = isset( $_POST["sbs_w{$w}_day_{$day}_active"] ) ? 1 : 0;
                    $slots = [];
                    
                    if ( isset( $_POST["sbs_w{$w}_day_{$day}_start"] ) && is_array( $_POST["sbs_w{$w}_day_{$day}_start"] ) ) {
                        foreach ( $_POST["sbs_w{$w}_day_{$day}_start"] as $index => $start_time ) {
                            $end_time = $_POST["sbs_w{$w}_day_{$day}_end"][$index];
                            if ( !empty($start_time) && !empty($end_time) ) {
                                $slots[] = [
                                    'start' => sanitize_text_field( $start_time ),
                                    'end'   => sanitize_text_field( $end_time )
                                ];
                            }
                        }
                    }
                    
                    $week_data[$day] = [
                        'active' => $is_active,
                        'slots'  => $slots
                    ];
                }
                $new_hours['weeks'][$w] = $week_data;
            }
            
            update_option( 'sbs_working_hours', $new_hours );
            $hours = $new_hours; // Update local variable for rendering
            
            // Salvataggio Giorni di Chiusura
            $new_closed_days = [];
            if ( isset( $_POST['sbs_closed_start'] ) && is_array( $_POST['sbs_closed_start'] ) ) {
                foreach ( $_POST['sbs_closed_start'] as $index => $c_start ) {
                    $c_end = sanitize_text_field($_POST['sbs_closed_end'][$index] ?? '');
                    $c_start = sanitize_text_field($c_start);
                    
                    if ( !empty($c_start) ) {
                        if (empty($c_end)) {
                            $c_end = $c_start; // Se "Al" è vuoto, usa la stessa data
                        }
                        $new_closed_days[] = [
                            'start' => $c_start,
                            'end' => $c_end
                        ];
                    }
                }
            }
            update_option( 'sbs_closed_days', $new_closed_days );
            $closed_days = $new_closed_days; // Update local variable

            
            echo '<div class="notice notice-success is-dismissible"><p>Impostazioni salvate con successo!</p></div>';
        }

        ?>
        <div class="wrap">
            <h2>Impostazioni Orari e Chiusure</h2>
            <form method="post" action="">
                <?php wp_nonce_field( 'sbs_settings_action', 'sbs_settings_nonce' ); ?>
                
                <table class="form-table">
                    <tr>
                        <th scope="row"><label for="sbs_enable_booking" style="font-weight: bold; color: #2271b1;">Stato Prenotazioni Online</label></th>
                        <td>
                            <select id="sbs_enable_booking" name="sbs_enable_booking" style="font-weight: 600;">
                                <option value="yes" <?php selected(($settings['enable_booking'] ?? 'yes'), 'yes'); ?>>✅ Attive (ON)</option>
                                <option value="no" <?php selected(($settings['enable_booking'] ?? 'yes'), 'no'); ?>>🛑 Disattivate (OFF)</option>
                            </select>
                            <p class="description">Scegli se permettere ai clienti di prenotare dal sito o se bloccare temporaneamente il sistema.</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="sbs_booking_disabled_msg">Messaggio di Avviso (mostrato quando disattivate)</label></th>
                        <td>
                            <textarea id="sbs_booking_disabled_msg" name="sbs_booking_disabled_msg" rows="4" class="large-text"><?php echo esc_textarea( $settings['booking_disabled_msg'] ?? "Le prenotazioni online sono momentaneamente disattivate.\n\nChiamaci al +41 91 745 80 80 per prenotare il tuo appuntamento." ); ?></textarea>
                            <p class="description">Testo visibile al posto del calendario (formattabile). Invita gli utenti a chiamare.</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="sbs_admin_email">Email Amministratore (Riceve notifiche)</label></th>
                        <td>
                            <input type="email" id="sbs_admin_email" name="sbs_admin_email" value="<?php echo esc_attr( $settings['admin_email'] ?? '' ); ?>" class="regular-text" required>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="sbs_duration_vista">Durata "Controllo Vista" (minuti)</label></th>
                        <td>
                            <input type="number" id="sbs_duration_vista" name="sbs_duration_vista" value="<?php echo esc_attr( $settings['duration_vista'] ?? 30 ); ?>" min="5" step="5" required>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="sbs_duration_lenti">Durata "Lenti a Contatto" (minuti)</label></th>
                        <td>
                            <input type="number" id="sbs_duration_lenti" name="sbs_duration_lenti" value="<?php echo esc_attr( $settings['duration_lenti'] ?? 30 ); ?>" min="5" step="5" required>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="sbs_duration_patente">Durata "Test Patente" (minuti)</label></th>
                        <td>
                            <input type="number" id="sbs_duration_patente" name="sbs_duration_patente" value="<?php echo esc_attr( $settings['duration_patente'] ?? 15 ); ?>" min="5" step="5" required>
                        </td>
                    </tr>
                    <!-- Email settings moved to Gestione Mail tab -->
                </table>

                <p class="submit">
                    <input type="submit" name="sbs_save_settings" id="submit" class="button button-primary" value="Salva tutte le Impostazioni">
                </p>

                <hr>
                <h3>Orari di Apertura (Ciclo Continuo)</h3>
                <p class="description">Imposta il numero di settimane del tuo ciclo e la Data di Inizio. Il sistema alternerà automaticamente queste settimane all'infinito partendo dalla data indicata.</p>
                
                <table class="form-table">
                    <tr>
                        <th scope="row"><label for="sbs_cycle_weeks">Numero di Settimane nel Ciclo</label></th>
                        <td>
                            <select id="sbs_cycle_weeks" name="sbs_cycle_weeks">
                                <option value="2" <?php selected(($hours['cycle_weeks'] ?? 0), 2); ?>>2 Settimane</option>
                                <option value="3" <?php selected(($hours['cycle_weeks'] ?? 0), 3); ?>>3 Settimane</option>
                                <option value="4" <?php selected(($hours['cycle_weeks'] ?? 4), 4); ?>>4 Settimane</option>
                                <option value="5" <?php selected(($hours['cycle_weeks'] ?? 0), 5); ?>>5 Settimane</option>
                                <option value="6" <?php selected(($hours['cycle_weeks'] ?? 0), 6); ?>>6 Settimane</option>
                            </select>
                            <p class="description">Dopo aver cambiato il numero, clicca su "Salva Impostazioni" per aggiornare la visualizzazione delle tabelle qui sotto.</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="sbs_anchor_date">Data Inizio Ciclo (Giorno 1 della Settimana 1)</label></th>
                        <td>
                            <input type="date" id="sbs_anchor_date" name="sbs_anchor_date" value="<?php echo esc_attr( $hours['anchor_date'] ?? '2026-05-01' ); ?>" class="regular-text" required>
                        </td>
                    </tr>
                </table>

                <div class="notice notice-warning" style="display:block; padding:15px; margin-top: 15px; background: #fff;">
                    <p style="margin-top:0;"><strong>💡 Come funzionano le fasce orarie?</strong></p>
                    <ul style="list-style-type: disc; margin-left: 20px; margin-bottom:0;">
                        <li>Puoi creare <strong>più fasce orarie</strong> per ogni giorno (es. Mattina <code>08:30 - 12:00</code> e Pomeriggio <code>13:30 - 18:00</code>).</li>
                        <li>Seleziona la casella "Aperto" affinché il giorno risulti cliccabile nel calendario.</li>
                    </ul>
                </div>
                
                <?php 
                $days_labels = [
                    'monday' => 'Lunedì', 'tuesday' => 'Martedì', 'wednesday' => 'Mercoledì', 
                    'thursday' => 'Giovedì', 'friday' => 'Venerdì', 'saturday' => 'Sabato', 'sunday' => 'Domenica'
                ];
                $total_weeks = $hours['cycle_weeks'] ?? 4; 
                
                if ( !isset($hours['weeks']) || !is_array($hours['weeks']) ) {
                    $hours['weeks'] = [];
                }
                for ($i = 0; $i < $total_weeks; $i++) {
                    if (!isset($hours['weeks'][$i])) {
                        $hours['weeks'][$i] = $hours['weeks'][0] ?? [];
                    }
                }

                for ($w = 0; $w < $total_weeks; $w++) : 
                ?>
                <?php $week_range = $this->get_cycle_week_range( $hours['anchor_date'] ?? '2026-05-01', $total_weeks, $w ); ?>
                <h4 class="sbs-week-heading" data-week="<?php echo esc_attr( $w ); ?>" style="margin-top: 30px; border-bottom: 2px solid #ccc; padding-bottom: 10px; font-size: 1.2em;">Configurazione Settimana <?php echo $w + 1; ?><span class="sbs-week-range" style="font-weight: normal; font-size: 0.85em; color: #50575e;"><?php echo $week_range ? ' &mdash; ' . $week_range : ''; ?></span></h4>
                <table class="wp-list-table widefat fixed striped" style="margin-bottom: 20px;">
                    <thead>
                        <tr>
                            <th style="width: 15%;">Giorno</th>
                            <th style="width: 10%;">Aperto</th>
                            <th>Fasce Orarie (Start - End)</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        foreach ($days_labels as $day_key => $day_label) : 
                            $day_data = $hours['weeks'][$w][$day_key] ?? ['active' => 0, 'slots' => []];
                        ?>
                        <tr>
                            <td><strong><?php echo $day_label; ?></strong></td>
                            <td>
                                <input type="checkbox" name="sbs_w<?php echo $w; ?>_day_<?php echo $day_key; ?>_active" value="1" <?php checked( $day_data['active'], 1 ); ?>>
                            </td>
                            <td>
                                <?php 
                                echo '<div style="display: flex; flex-wrap: wrap; gap: 10px; align-items: center;">';
                                
                                // Show existing slots
                                if ( !empty($day_data['slots']) ) {
                                    foreach ($day_data['slots'] as $slot) {
                                        echo '<div class="sbs-timeslot-row" style="background: #f6f7f7; border: 1px solid #dcdcdc; padding: 6px 12px; border-radius: 6px; display: flex; align-items: center; gap: 8px; box-shadow: 0 1px 2px rgba(0,0,0,0.05);">';
                                        echo '<span style="font-size: 11px; text-transform: uppercase; color: #646970; font-weight:600;">Da</span>';
                                        echo '<input type="time" name="sbs_w' . $w . '_day_' . $day_key . '_start[]" value="' . esc_attr($slot['start']) . '" style="border: none; background: transparent; padding: 0; box-shadow: none; font-weight: bold; color: #1d2327; cursor: pointer; line-height:1;">';
                                        echo '<span style="font-size: 11px; text-transform: uppercase; color: #646970; font-weight:600;">A</span>';
                                        echo '<input type="time" name="sbs_w' . $w . '_day_' . $day_key . '_end[]" value="' . esc_attr($slot['end']) . '" style="border: none; background: transparent; padding: 0; box-shadow: none; font-weight: bold; color: #1d2327; cursor: pointer; line-height:1;">';
                                        echo '<button type="button" class="sbs-remove-timeslot-btn" style="background:none; border:none; color:#d63638; cursor:pointer; font-size:16px; padding:0 5px; line-height:1;" title="Rimuovi orario">&times;</button>';
                                        echo '</div>';
                                    }
                                }
                                
                                echo '<button type="button" class="button sbs-add-timeslot-btn" data-prefix="sbs_w' . $w . '_day_' . $day_key . '">+ Aggiungi Orario</button>';

                                echo '</div>';
                                ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <?php endfor; ?>
                
                <hr>
                <hr>
                <h3>Giorni di Chiusura / Vacanze (Singoli o Periodi)</h3>
                <p class="description">Aggiungi date specifiche o interi periodi in cui il negozio sarà chiuso (es. vacanze estive). Seleziona "Dal" e "Al" (se è un solo giorno, compila solo "Dal"). In questi giorni non sarà possibile prenotare appuntamenti, indipendentemente dal giorno della settimana.</p>
                
                <div id="sbs-closed-days-container" style="margin-top: 15px;">
                    <?php if ( !empty($closed_days) && is_array($closed_days) ) : ?>
                        <?php 
                        // Compatibilità retroattiva per chi aveva salvato singole date come stringhe
                        foreach ( $closed_days as $c_date ) : 
                            $start = is_array($c_date) ? $c_date['start'] : $c_date;
                            $end = is_array($c_date) ? $c_date['end'] : $c_date;
                        ?>
                            <div class="sbs-closed-day-row" style="margin-bottom: 10px; display: flex; align-items: center; gap: 10px;">
                                <span style="font-weight: 600;">Dal:</span>
                                <input type="date" name="sbs_closed_start[]" value="<?php echo esc_attr($start); ?>" class="regular-text" style="width: auto;">
                                <span style="font-weight: 600;">Al:</span>
                                <input type="date" name="sbs_closed_end[]" value="<?php echo esc_attr($end); ?>" class="regular-text" style="width: auto;">
                                <button type="button" class="button sbs-remove-date-btn" style="color: #d63638; border-color: #d63638;">Rimuovi</button>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <!-- Un campo vuoto di default -->
                        <div class="sbs-closed-day-row" style="margin-bottom: 10px; display: flex; align-items: center; gap: 10px;">
                            <span style="font-weight: 600;">Dal:</span>
                            <input type="date" name="sbs_closed_start[]" value="" class="regular-text" style="width: auto;">
                            <span style="font-weight: 600;">Al:</span>
                            <input type="date" name="sbs_closed_end[]" value="" class="regular-text" style="width: auto;">
                            <button type="button" class="button sbs-remove-date-btn" style="color: #d63638; border-color: #d63638; display: none;">Rimuovi</button>
                        </div>
                    <?php endif; ?>
                </div>
                <button type="button" id="sbs-add-date-btn" class="button" style="margin-bottom: 20px;">+ Aggiungi Periodo di Chiusura</button>
                
                <script>
                document.addEventListener('DOMContentLoaded', function() {
                    // Aggiorna le date delle settimane quando cambiano data di inizio ciclo o numero di settimane.
                    var anchorInput = document.getElementById('sbs_anchor_date');
                    var weeksSelect = document.getElementById('sbs_cycle_weeks');
                    var weekHeadings = document.querySelectorAll('.sbs-week-heading');
                    var fmtDate = function(d) {
                        var days = ['dom', 'lun', 'mar', 'mer', 'gio', 'ven', 'sab'];
                        var p2 = function(n) { return ('0' + n).slice(-2); };
                        return days[d.getDay()] + ' ' + p2(d.getDate()) + '/' + p2(d.getMonth() + 1) + '/' + d.getFullYear();
                    };
                    var refreshWeekRanges = function() {
                        if (!anchorInput || !anchorInput.value) { return; }
                        var parts = anchorInput.value.split('-');
                        var anchor = new Date(+parts[0], +parts[1] - 1, +parts[2], 12);
                        var cycleDays = 7 * parseInt(weeksSelect ? weeksSelect.value : weekHeadings.length, 10);
                        var now = new Date();
                        var today = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 12);
                        weekHeadings.forEach(function(h) {
                            var start = new Date(anchor.getTime());
                            start.setDate(start.getDate() + 7 * parseInt(h.getAttribute('data-week'), 10));
                            var end = new Date(start.getTime());
                            end.setDate(end.getDate() + 6);
                            if (end < today) {
                                var cycles = Math.ceil(Math.round((today - end) / 86400000) / cycleDays);
                                start.setDate(start.getDate() + cycles * cycleDays);
                                end = new Date(start.getTime());
                                end.setDate(end.getDate() + 6);
                            }
                            var badge = (start <= today && today <= end) ? ' <span style="background:#00a32a; color:#fff; border-radius:3px; padding:2px 8px; font-size:11px; font-weight:600; text-transform:uppercase; vertical-align:middle;">In corso</span>'
                                : (start > today ? ' <span style="color:#646970;">(prossima)</span>' : '');
                            h.querySelector('.sbs-week-range').innerHTML = ' \u2014 valida dal <strong>' + fmtDate(start) + '</strong> al <strong>' + fmtDate(end) + '</strong>' + badge;
                        });
                    };
                    if (anchorInput) { anchorInput.addEventListener('change', refreshWeekRanges); }
                    
                    // Rimuovi orari
                    document.addEventListener('click', function(e) {
                        if (e.target && e.target.classList.contains('sbs-remove-timeslot-btn')) {
                            e.preventDefault();
                            e.target.closest('.sbs-timeslot-row').remove();
                        }
                    });

                    // Aggiungi orari
                    document.addEventListener('click', function(e) {
                        if (e.target && e.target.classList.contains('sbs-add-timeslot-btn')) {
                            e.preventDefault();
                            var prefix = e.target.getAttribute('data-prefix');
                            var row = document.createElement('div');
                            row.className = 'sbs-timeslot-row';
                            row.style.cssText = 'background: #f0f6fc; border: 1px dashed #2271b1; padding: 6px 12px; border-radius: 6px; display: flex; align-items: center; gap: 8px;';
                            row.innerHTML = '<span style="font-size: 11px; text-transform: uppercase; color: #2271b1; font-weight:600;">Da</span>' +
                                            '<input type="time" name="' + prefix + '_start[]" value="" style="border: 1px solid #c3c4c7; border-radius:3px; padding: 0 4px;" required>' +
                                            '<span style="font-size: 11px; text-transform: uppercase; color: #2271b1; font-weight:600;">A</span>' +
                                            '<input type="time" name="' + prefix + '_end[]" value="" style="border: 1px solid #c3c4c7; border-radius:3px; padding: 0 4px;" required>' +
                                            '<button type="button" class="sbs-remove-timeslot-btn" style="background:none; border:none; color:#d63638; cursor:pointer; font-size:16px; padding:0 5px; line-height:1;" title="Rimuovi orario">&times;</button>';
                            e.target.parentNode.insertBefore(row, e.target);
                        }
                    });

                    var container = document.getElementById('sbs-closed-days-container');
                    var addBtn = document.getElementById('sbs-add-date-btn');
                    
                    addBtn.addEventListener('click', function() {
                        var row = document.createElement('div');
                        row.className = 'sbs-closed-day-row';
                        row.style.marginBottom = '10px';
                        row.style.display = 'flex';
                        row.style.alignItems = 'center';
                        row.style.gap = '10px';
                        
                        row.innerHTML = '<span style="font-weight: 600;">Dal:</span>' +
                                        '<input type="date" name="sbs_closed_start[]" value="" class="regular-text" style="width: auto;">' +
                                        '<span style="font-weight: 600;">Al:</span>' +
                                        '<input type="date" name="sbs_closed_end[]" value="" class="regular-text" style="width: auto;">' +
                                        '<button type="button" class="button sbs-remove-date-btn" style="color: #d63638; border-color: #d63638;">Rimuovi</button>';
                        container.appendChild(row);
                    });
                    
                    container.addEventListener('click', function(e) {
                        if (e.target && e.target.classList.contains('sbs-remove-date-btn')) {
                            // Se è l'ultimo, puliamo il valore invece di rimuovere per lasciare sempre un input vuoto disponibile
                            var rows = container.querySelectorAll('.sbs-closed-day-row');
                            if (rows.length === 1) {
                                var inputs = e.target.closest('.sbs-closed-day-row').querySelectorAll('input[type="date"]');
                                inputs.forEach(function(i) { i.value = ''; });
                                e.target.style.display = 'none';
                            } else {
                                e.target.closest('.sbs-closed-day-row').remove();
                            }
                        }
                    });
                    
                    // Mostra/Nascondi bottone rimuovi su singola riga
                    container.addEventListener('change', function(e) {
                        if (e.target && e.target.tagName === 'INPUT') {
                            var row = e.target.closest('.sbs-closed-day-row');
                            var removeBtn = row.querySelector('.sbs-remove-date-btn');
                            if (e.target.value !== '') {
                                removeBtn.style.display = 'inline-block';
                            }
                        }
                    });
                });
                </script>

                
                <p class="submit">
                    <input type="submit" name="sbs_save_settings" id="submit" class="button button-primary" value="Salva Impostazioni">
                </p>
            </form>
        </div>
        <?php
    }

    public function display_plugin_emails_page() {
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }

        // Recupera le opzioni salvate
        $settings = get_option( 'sbs_settings', [] );

        if ( isset( $_POST['sbs_save_emails'] ) && check_admin_referer( 'sbs_emails_action', 'sbs_emails_nonce' ) ) {
            
            $settings['email_admin_body'] = wp_kses_post( wp_unslash( $_POST['sbs_email_admin_body'] ?? '' ) );
            
            $settings['email_approve_subject'] = sanitize_text_field( wp_unslash( $_POST['sbs_email_approve_subject'] ?? '' ) );
            $settings['email_approve_body'] = wp_kses_post( wp_unslash( $_POST['sbs_email_approve_body'] ?? '' ) );
            
            $settings['email_reject_subject'] = sanitize_text_field( wp_unslash( $_POST['sbs_email_reject_subject'] ?? '' ) );
            $settings['email_reject_body'] = wp_kses_post( wp_unslash( $_POST['sbs_email_reject_body'] ?? '' ) );
            
            update_option( 'sbs_settings', $settings );

            echo '<div class="notice notice-success is-dismissible"><p>Impostazioni Email salvate con successo!</p></div>';
        }
        ?>
        <div class="wrap">
            <h2>Gestione Email Automatiche</h2>
            <style>
                .sbs-emails-table th, .sbs-emails-table td {
                    padding: 25px 30px !important;
                }
            </style>
            <form method="post" action="">
                <?php wp_nonce_field( 'sbs_emails_action', 'sbs_emails_nonce' ); ?>
                
                <table class="form-table sbs-emails-table">
                    <tr>
                        <th scope="row" colspan="2" style="padding-top: 10px;">
                            <p class="description">Puoi usare le seguenti variabili dinamiche all'interno dei testi (sia oggetto che corpo del testo):<br>
                                <code>{nome}</code>, <code>{email}</code>, <code>{telefono}</code>, <code>{servizio}</code>, <code>{data}</code>, <code>{ora}</code>, <code>{note}</code>
                            </p>
                        </th>
                    </tr>
                    
                    <!-- ADMIN NOTIFICATION -->
                    <tr style="background: #f9f9f9;">
                        <th scope="row"><label for="sbs_email_admin_body">Testo Email Admin<br><small>(Nuova Prenotazione)</small></label></th>
                        <td>
                            <p class="description">Testo inviato all'amministratore (solo informativo).</p>
                            <textarea id="sbs_email_admin_body" name="sbs_email_admin_body" rows="4" class="large-text"><?php echo esc_textarea( $settings['email_admin_body'] ?? "Hai ricevuto un nuovo appuntamento confermato.\n\nCliente: {nome}\nServizio: {servizio}\nData: {data} alle {ora}\nEmail: {email}\nTelefono: {telefono}\nNote: {note}" ); ?></textarea>
                        </td>
                    </tr>
                    

                    <!-- CUSTOMER APPROVED -->
                    <tr style="background: #eafbea;">
                        <th scope="row"><label for="sbs_email_approve_subject">Oggetto Email Cliente<br><small>(Conferma Appuntamento)</small></label></th>
                        <td>
                            <input type="text" id="sbs_email_approve_subject" name="sbs_email_approve_subject" value="<?php echo esc_attr( $settings['email_approve_subject'] ?? 'Prenotazione Confermata!' ); ?>" class="regular-text">
                        </td>
                    </tr>
                    <tr style="background: #eafbea;">
                        <th scope="row"><label for="sbs_email_approve_body">Testo Email Cliente<br><small>(Conferma Appuntamento)</small></label></th>
                        <td>
                            <p class="description">Email inviata quando l'admin clicca "APPROVA".</p>
                            <textarea id="sbs_email_approve_body" name="sbs_email_approve_body" rows="4" class="large-text"><?php echo esc_textarea( $settings['email_approve_body'] ?? "Ciao {nome},\n\nSiamo felici di confermarti che il tuo appuntamento per {servizio} è confermato!\n\nTi aspettiamo il giorno {data} alle {ora}." ); ?></textarea>
                        </td>
                    </tr>

                    <!-- CUSTOMER REJECTED -->
                    <tr style="background: #fdf2f2;">
                        <th scope="row"><label for="sbs_email_reject_subject">Oggetto Email Cliente<br><small>(Rifiuto Appuntamento)</small></label></th>
                        <td>
                            <input type="text" id="sbs_email_reject_subject" name="sbs_email_reject_subject" value="<?php echo esc_attr( $settings['email_reject_subject'] ?? 'Aggiornamento Prenotazione' ); ?>" class="regular-text">
                        </td>
                    </tr>
                    <tr style="background: #fdf2f2;">
                        <th scope="row"><label for="sbs_email_reject_body">Testo Email Cliente<br><small>(Rifiuto Appuntamento)</small></label></th>
                        <td>
                            <p class="description">Email inviata quando l'admin clicca "RIFIUTA".</p>
                            <textarea id="sbs_email_reject_body" name="sbs_email_reject_body" rows="4" class="large-text"><?php echo esc_textarea( $settings['email_reject_body'] ?? "Ciao {nome},\n\nCi dispiace informarti che non possiamo confermare il tuo appuntamento per {servizio} del {data} alle {ora}.\nPotrebbe esserci stato un accavallamento o il negozio è chiuso.\n\nTi invitiamo a contattarci o a effettuare una nuova richiesta." ); ?></textarea>
                        </td>
                    </tr>
                </table>

                <p class="submit">
                    <input type="submit" name="sbs_save_emails" id="submit" class="button button-primary" value="Salva Impostazioni Email">
                </p>
            </form>
        </div>
        <?php
    }

    public function display_plugin_gcal_page() {
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }

        require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-sbs-gcal.php';

        // Handling OAuth Callback
        if ( isset($_GET['code']) && isset($_GET['page']) && $_GET['page'] === 'simple-booking-system-gcal' ) {
            $code = sanitize_text_field( $_GET['code'] );
            $auth_success = SBS_Gcal::authenticate( $code );
            if ( $auth_success ) {
                $test = SBS_Gcal::test_connection();
                if ( $test ) {
                    echo '<div class="notice notice-success is-dismissible"><p>Autenticazione e Test di connessione con Google API completati con successo!</p></div>';
                } else {
                    echo '<div class="notice notice-error is-dismissible"><p>Autenticazione riuscita, ma il Test di connessione API è fallito. Controlla il log degli errori in basso.</p></div>';
                }
            } else {
                echo '<div class="notice notice-error is-dismissible"><p>Errore di autenticazione con Google.</p></div>';
            }
            // Remove code from URL to prevent refresh issues
            echo '<script>window.history.replaceState({}, document.title, "' . esc_url(admin_url('admin.php?page=simple-booking-system-gcal')) . '");</script>';
        }

        // Save Settings
        if ( isset( $_POST['sbs_save_gcal'] ) && check_admin_referer( 'sbs_gcal_action', 'sbs_gcal_nonce' ) ) {
            $settings = SBS_Gcal::get_settings();
            $settings['client_id'] = sanitize_text_field( $_POST['gcal_client_id'] );
            $settings['client_secret'] = sanitize_text_field( $_POST['gcal_client_secret'] );
            SBS_Gcal::save_settings( $settings );
            echo '<div class="notice notice-success is-dismissible"><p>Credenziali Google Calendar salvate.</p></div>';
        }

        // Save Selected Calendars
        if ( isset( $_POST['sbs_save_gcal_calendars'] ) && check_admin_referer( 'sbs_gcal_action', 'sbs_gcal_nonce' ) ) {
            $settings = SBS_Gcal::get_settings();
            $selected = $_POST['sbs_selected_calendars'] ?? [];
            if ( !is_array($selected) ) $selected = [];
            
            $settings['selected_calendars'] = array_map('sanitize_text_field', $selected);
            
            // Salvo anche i nomi per comodità
            $names = $_POST['sbs_calendar_names'] ?? [];
            if ( is_array($names) ) {
                $settings['calendar_names'] = array_map('sanitize_text_field', $names);
            }
            
            // Salvo i colori per mappare gli eventi
            $colors = $_POST['sbs_calendar_colors'] ?? [];
            if ( is_array($colors) ) {
                $settings['calendar_colors'] = array_map('sanitize_text_field', $colors);
            }

            SBS_Gcal::save_settings( $settings );
            echo '<div class="notice notice-success is-dismissible"><p>Calendari da sincronizzare aggiornati con successo.</p></div>';
        }

        // Disconnect
        if ( isset( $_POST['sbs_disconnect_gcal'] ) && check_admin_referer( 'sbs_gcal_action', 'sbs_gcal_nonce' ) ) {
            $settings = SBS_Gcal::get_settings();
            unset($settings['access_token']);
            unset($settings['refresh_token']);
            unset($settings['expires_at']);
            SBS_Gcal::save_settings( $settings );
            echo '<div class="notice notice-success is-dismissible"><p>Disconnesso da Google Calendar con successo.</p></div>';
        }

        // Manual Sync Action
        if ( isset( $_POST['sbs_manual_sync'] ) && check_admin_referer( 'sbs_gcal_action', 'sbs_gcal_nonce' ) ) {
            SBS_Gcal::sync_from_google(true);
            echo '<div class="notice notice-success is-dismissible"><p>Sincronizzazione manuale eseguita.</p></div>';
        }

        $settings = SBS_Gcal::get_settings();
        $is_connected = SBS_Gcal::test_connection();
        $auth_url = SBS_Gcal::get_auth_url();
        $redirect_uri = admin_url( 'admin.php?page=simple-booking-system-gcal' );

        ?>
        <div class="wrap">
            <h2>Sincronizzazione Google Calendar</h2>
            
            <div style="background:#fff; border-left:4px solid #4285f4; padding:15px; margin-bottom:20px; box-shadow:0 1px 3px rgba(0,0,0,0.1);">
                <h3>Guida Rapida: Come configurare le credenziali</h3>
                <ol style="margin-left:20px; list-style-type:decimal; line-height:1.6;">
                    <li>Vai alla <a href="https://console.cloud.google.com/" target="_blank">Google Cloud Console</a>.</li>
                    <li>Crea un nuovo progetto o selezionane uno esistente.</li>
                    <li>Vai su <strong>API e servizi > Libreria</strong>, cerca "Google Calendar API" e clicca su <strong>Abilita</strong>.</li>
                    <li>Vai su <strong>Schermata consenso OAuth</strong>, configura l'app come "Esterna" (se non hai Workspace) e aggiungi i tuoi dati base. Aggiungi il tuo dominio tra i domini autorizzati.</li>
                    <li>Vai su <strong>Credenziali > Crea Credenziali > ID client OAuth</strong>. Scegli "Applicazione Web".</li>
                    <li>Sotto "URI di reindirizzamento autorizzati", inserisci esattamente questo URL:<br>
                        <code style="background:#f0f0f1; padding:3px 6px; user-select:all;"><?php echo esc_html($redirect_uri); ?></code>
                    </li>
                    <li>Salva e copia il <strong>Client ID</strong> e il <strong>Client Secret</strong> qui sotto.</li>
                    <li>Il <strong>Calendar ID</strong> di solito è la tua email (es. <code>nome@gmail.com</code>) o "primary". Per usare un calendario specifico, trovi l'ID nelle impostazioni di quel calendario su Google.</li>
                </ol>
            </div>

            <form method="post" action="">
                <?php wp_nonce_field( 'sbs_gcal_action', 'sbs_gcal_nonce' ); ?>
                
                <table class="form-table">
                    <tr>
                        <th scope="row"><label for="gcal_client_id">Client ID</label></th>
                        <td>
                            <input type="text" id="gcal_client_id" name="gcal_client_id" value="<?php echo esc_attr( $settings['client_id'] ?? '' ); ?>" class="regular-text">
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="gcal_client_secret">Client Secret</label></th>
                        <td>
                            <input type="password" id="gcal_client_secret" name="gcal_client_secret" value="<?php echo esc_attr( $settings['client_secret'] ?? '' ); ?>" class="regular-text">
                        </td>
                    </tr>
                </table>

                <p class="submit">
                    <input type="submit" name="sbs_save_gcal" id="submit" class="button button-primary" value="Salva Credenziali">
                </p>
                
                <hr>

                <h3>Stato della Connessione</h3>
                <?php if ( $is_connected ) : ?>
                    <div style="padding:15px; background:#e6f4ea; border:1px solid #1e8e3e; border-radius:5px; color:#1e8e3e; display:inline-block; font-weight:bold; margin-bottom:15px;">
                        <span class="dashicons dashicons-yes-alt" style="margin-top:2px;"></span> Connesso a Google Calendar (Lettura Verificata!)
                    </div>
                    <p>La sincronizzazione in background sta funzionando.</p>
                    <input type="submit" name="sbs_manual_sync" class="button button-primary" value="Sincronizza Ora" style="margin-right: 10px;">
                    <input type="submit" name="sbs_disconnect_gcal" class="button button-secondary" value="Disconnetti Account" onclick="return confirm('Sei sicuro di voler disconnettere Google Calendar?');">
                    
                    <hr>

                    <h3>Calendari da Sincronizzare</h3>
                    <p class="description" style="margin-bottom:15px;">Seleziona i calendari di Google da cui importare gli appuntamenti. L'ultimo calendario aggiunto riceverà anche le nuove prenotazioni generate dal sito.</p>
                    
                    <?php 
                    $calendars = SBS_Gcal::get_available_calendars();
                    $selected_cals = $settings['selected_calendars'] ?? [];
                    
                    if ( empty($selected_cals) ) {
                        echo '<div class="notice notice-error inline" style="margin-left:0; margin-bottom:15px;"><p>Nessun calendario Google selezionato. Seleziona almeno un calendario da sincronizzare.</p></div>';
                    }
                    
                    if ( $calendars && is_array($calendars) ) :
                    ?>
                        <div style="background:#fff; border:1px solid #ccd0d4; padding:15px; border-radius:4px; max-width:600px; margin-bottom:15px; max-height: 400px; overflow-y: auto;">
                        <?php foreach ( $calendars as $cal ) : ?>
                            <div style="margin-bottom:10px; display:flex; align-items:center; padding-bottom:8px; border-bottom:1px solid #f0f0f1;">
                                <input type="checkbox" name="sbs_selected_calendars[]" value="<?php echo esc_attr($cal['id']); ?>" id="cal_<?php echo esc_attr(md5($cal['id'])); ?>" <?php checked(in_array($cal['id'], $selected_cals)); ?>>
                                <span style="display:inline-block; width:14px; height:14px; background-color:<?php echo esc_attr($cal['backgroundColor']); ?>; border-radius:50%; margin:0 10px; box-shadow:0 1px 2px rgba(0,0,0,0.2);"></span>
                                <label for="cal_<?php echo esc_attr(md5($cal['id'])); ?>" style="font-weight:600; font-size:14px; cursor:pointer;">
                                    <?php echo esc_html($cal['summary']); ?>
                                    <input type="hidden" name="sbs_calendar_names[<?php echo esc_attr($cal['id']); ?>]" value="<?php echo esc_attr($cal['summary']); ?>">
                                    <input type="hidden" name="sbs_calendar_colors[<?php echo esc_attr($cal['id']); ?>]" value="<?php echo esc_attr($cal['backgroundColor']); ?>">
                                </label>
                            </div>
                        <?php endforeach; ?>
                        </div>
                        <input type="submit" name="sbs_save_gcal_calendars" class="button button-primary" value="Salva Calendari Selezionati">
                    <?php else: ?>
                        <p style="color:#d63638; font-weight:bold;">Impossibile recuperare i calendari. Verifica i permessi dell'account.</p>
                    <?php endif; ?>

                    <hr>
                    <h3>Log di Sincronizzazione</h3>
                    <?php
                    $log = get_option('sbs_gcal_sync_log');
                    if ( $log && is_array($log) ) :
                        $is_new_format = isset($log['total_found']);
                    ?>
                        <div style="background:#f6f7f7; padding:15px; border-left:4px solid #2271b1; border-radius:3px; max-width: 800px;">
                            <p style="font-size:14px; font-weight:bold;">Ultima Sincronizzazione Globale: <?php echo esc_html($log['date'] ?? '-'); ?></p>
                            
                            <?php if ( !empty($log['error']) ) : ?>
                                <p style="color:#d63638; font-weight:bold; margin-top:10px; background:#fdf2f2; padding:10px; border:1px solid #d63638;"><strong>Errore API:</strong> <?php echo nl2br(esc_html($log['error'])); ?></p>
                            <?php endif; ?>

                            <?php if ($is_new_format): ?>
                                <div style="display:flex; gap:15px; margin-bottom:15px; margin-top:15px;">
                                    <div style="background:#fff; padding:10px; border:1px solid #ccd0d4; border-radius:4px; flex:1; text-align:center;"><strong>Trovati</strong><br><span style="font-size:18px;"><?php echo intval($log['total_found']); ?></span></div>
                                    <div style="background:#fff; padding:10px; border:1px solid #ccd0d4; border-radius:4px; flex:1; text-align:center;"><strong>Importati</strong><br><span style="font-size:18px; color:#1e8e3e; font-weight:bold;"><?php echo intval($log['total_imported']); ?></span></div>
                                    <div style="background:#fff; padding:10px; border:1px solid #ccd0d4; border-radius:4px; flex:1; text-align:center;"><strong>Aggiornati</strong><br><span style="font-size:18px; color:#2271b1; font-weight:bold;"><?php echo intval($log['total_updated']); ?></span></div>
                                    <div style="background:#fff; padding:10px; border:1px solid #ccd0d4; border-radius:4px; flex:1; text-align:center;"><strong>Saltati</strong><br><span style="font-size:18px; color:#d63638; font-weight:bold;"><?php echo intval($log['total_skipped']); ?></span></div>
                                </div>

                                <?php if (!empty($log['details']) && is_array($log['details'])): ?>
                                    <h4 style="margin-bottom:10px;">Dettagli per Calendario:</h4>
                                    <?php foreach ($log['details'] as $cal): ?>
                                        <div style="background:#fff; border:1px solid #e2e4e7; padding:10px; margin-bottom:10px; border-radius:3px;">
                                            <p style="margin:0 0 5px 0;"><strong><?php echo esc_html($cal['name']); ?></strong> <code>(<?php echo esc_html($cal['id']); ?>)</code></p>
                                            <p style="margin:0; font-size:13px; color:#50575e;">
                                                Trovati: <?php echo intval($cal['found']); ?> | 
                                                Importati: <strong style="color:#1e8e3e;"><?php echo intval($cal['imported']); ?></strong> | 
                                                Aggiornati: <strong style="color:#2271b1;"><?php echo intval($cal['updated']); ?></strong> | 
                                                Saltati: <strong style="color:#d63638;"><?php echo intval($cal['skipped']); ?></strong>
                                            </p>
                                            <?php if (!empty($cal['reasons']) && is_array($cal['reasons'])): ?>
                                                <div style="margin-top:5px; font-size:12px; color:#d63638;">
                                                    <strong>Motivi eventi saltati/errori:</strong>
                                                    <ul style="margin:2px 0 0 15px; list-style-type:circle;">
                                                        <?php foreach ($cal['reasons'] as $reason => $count): ?>
                                                            <li><?php echo esc_html($reason); ?>: <strong><?php echo intval($count); ?> eventi</strong></li>
                                                        <?php endforeach; ?>
                                                    </ul>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    <?php endforeach; ?>
                                <?php endif; ?>

                            <?php else: ?>
                                <p><strong>Eventi Trovati:</strong> <?php echo intval($log['found'] ?? 0); ?></p>
                                <p><strong>Nuovi Importati:</strong> <span style="color:#1e8e3e; font-weight:bold;"><?php echo intval($log['imported'] ?? 0); ?></span></p>
                                <p><strong>Aggiornati:</strong> <?php echo intval($log['updated'] ?? 0); ?></p>
                            <?php endif; ?>
                        </div>
                    <?php else: ?>
                        <p>Nessun log disponibile. Esegui la prima sincronizzazione cliccando su "Sincronizza Ora".</p>
                    <?php endif; ?>
                    
                <?php else : ?>
                    <div style="padding:15px; background:#fdf2f2; border:1px solid #d63638; border-radius:5px; color:#d63638; display:inline-block; font-weight:bold; margin-bottom:15px;">
                        Non Connesso o Credenziali Errate (Verifica Permessi)
                    </div>
                    <?php
                    $last_err = get_option('sbs_gcal_last_error');
                    if ( !empty($last_err) ) {
                        echo '<div style="background:#fff; border-left:4px solid #d63638; padding:15px; margin-bottom:15px;"><h4 style="margin-top:0;">Log Errore API:</h4><p style="color:#d63638; margin-bottom:0;"><code>' . esc_html($last_err) . '</code></p></div>';
                    }

                    $log = get_option('sbs_gcal_sync_log');
                    if ( !empty($log['error']) ) {
                        echo '<p style="color:#d63638; margin-bottom:15px;"><strong>Ultimo Errore Sync:</strong> ' . esc_html($log['error']) . '</p>';
                    }
                    ?>
                    <p>Dopo aver salvato le credenziali qui sopra, clicca sul pulsante qui sotto per autorizzare l'accesso.</p>
                    <?php if ( ! empty( $auth_url ) ) : ?>
                        <a href="<?php echo esc_url( $auth_url ); ?>" class="button button-primary" style="background:#4285f4; border-color:#4285f4; font-size:16px; padding:10px 20px; height:auto; line-height:normal;">
                            Autorizza con Google
                        </a>
                    <?php else: ?>
                        <p style="color:#d63638;">Salva prima il Client ID e il Client Secret per generare il bottone di Autorizzazione.</p>
                    <?php endif; ?>
                <?php endif; ?>
            </form>
        </div>
        <?php
    }
}
