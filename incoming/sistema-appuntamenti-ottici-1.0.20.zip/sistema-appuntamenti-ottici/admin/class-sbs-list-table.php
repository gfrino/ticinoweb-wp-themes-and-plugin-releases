<?php

if ( ! class_exists( 'WP_List_Table' ) ) {
    require_once( ABSPATH . 'wp-admin/includes/class-wp-list-table.php' );
}

class SBS_List_Table extends WP_List_Table {

    public function __construct() {
        parent::__construct( [
            'singular' => 'prenotazione',
            'plural'   => 'prenotazioni',
            'ajax'     => false
        ] );
    }

    public function get_columns() {
        return [
            'cb'           => '<input type="checkbox" />',
            'name'         => 'Nome',
            'email'        => 'Email',
            'phone'        => 'Telefono',
            'service'      => 'Servizio',
            'booking_date' => 'Data e Ora',
            'status'       => 'Stato',
            'created_at'   => 'Richiesto il'
        ];
    }

    public function get_sortable_columns() {
        return [
            'name'         => ['name', false],
            'booking_date' => ['booking_date', false],
            'status'       => ['status', false],
            'created_at'   => ['created_at', true]
        ];
    }

    protected function column_default( $item, $column_name ) {
        switch ( $column_name ) {
            case 'cb':
                return sprintf( '<input type="checkbox" name="booking_id[]" value="%s" />', $item['id'] );
            case 'name':
            case 'email':
            case 'phone':
            case 'service':
                return esc_html( $item[ $column_name ] );
            case 'booking_date':
                return date_i18n( get_option('date_format'), strtotime($item['booking_date']) ) . ' - ' . date_i18n( get_option('time_format'), strtotime($item['booking_time']) );
            case 'created_at':
                return date_i18n( get_option('date_format') . ' ' . get_option('time_format'), strtotime($item['created_at']) );
            case 'status':
                $status = $item['status'];
                $approve_url = wp_nonce_url( sprintf( '?page=%s&action=%s&booking=%s', sanitize_text_field($_REQUEST['page']), 'approve', $item['id'] ), 'sbs_booking_action' );
                $reject_url = wp_nonce_url( sprintf( '?page=%s&action=%s&booking=%s', sanitize_text_field($_REQUEST['page']), 'reject', $item['id'] ), 'sbs_booking_action' );
                
                $html = '<div style="display:flex; flex-direction:column; gap:8px;">';
                
                if ( $status == 'approved' ) {
                    $html .= '<span style="display:inline-block; padding:4px 10px; background:#e6f4ea; color:#1e8e3e; border-radius:12px; font-weight:600; font-size:12px; border:1px solid #1e8e3e; width:fit-content;">Confermato</span>';
                    // Mostro solo bottone rifiuta o annulla
                    $html .= '<a href="'.esc_url($reject_url).'" class="button button-small" style="color:#d63638; border-color:#d63638; text-align:center;">Annulla / Rifiuta</a>';
                } elseif ( $status == 'rejected' ) {
                    $html .= '<span style="display:inline-block; padding:4px 10px; background:#fce8e6; color:#d93025; border-radius:12px; font-weight:600; font-size:12px; border:1px solid #d93025; width:fit-content;">Rifiutato</span>';
                    // Mostro solo bottone approva
                    $html .= '<a href="'.esc_url($approve_url).'" class="button button-small" style="color:#2271b1; border-color:#2271b1; text-align:center;">Ripristina / Approva</a>';
                } else {
                    $html .= '<span style="display:inline-block; padding:4px 10px; background:#fef7e0; color:#b06000; border-radius:12px; font-weight:600; font-size:12px; border:1px solid #b06000; width:fit-content;">In Attesa</span>';
                    $html .= '<div style="display:flex; gap:5px;">';
                    $html .= '<a href="'.esc_url($approve_url).'" class="button button-small" style="background:#1e8e3e; color:#fff; border-color:#1e8e3e;">Approva</a>';
                    $html .= '<a href="'.esc_url($reject_url).'" class="button button-small" style="background:#d93025; color:#fff; border-color:#d93025;">Rifiuta</a>';
                    $html .= '</div>';
                }
                
                $html .= '</div>';
                return $html;
            default:
                return print_r( $item, true );
        }
    }

    protected function column_cb( $item ) {
        return sprintf(
            '<input type="checkbox" name="booking_id[]" value="%s" />', $item['id']
        );
    }

    protected function column_name( $item ) {
        $actions = [
            'approve' => sprintf( '<a href="%s">Approva</a>', wp_nonce_url( sprintf( '?page=%s&action=%s&booking=%s', $_REQUEST['page'], 'approve', $item['id'] ), 'sbs_booking_action' ) ),
            'reject'  => sprintf( '<a href="%s">Rifiuta</a>', wp_nonce_url( sprintf( '?page=%s&action=%s&booking=%s', $_REQUEST['page'], 'reject', $item['id'] ), 'sbs_booking_action' ) ),
            'delete'  => sprintf( '<a href="%s" onclick="return confirm(\'Sei sicuro?\');">Elimina</a>', wp_nonce_url( sprintf( '?page=%s&action=%s&booking=%s', $_REQUEST['page'], 'delete', $item['id'] ), 'sbs_booking_action' ) ),
        ];

        $html = '<strong>' . esc_html( $item['name'] ) . '</strong>';
        
        // Se l'utente ha lasciato delle note, le mostriamo elegantemente sotto il nome
        if ( !empty($item['notes']) ) {
            $html .= '<div style="margin-top: 8px; font-size: 12px; color: #50575e; background: #f0f0f1; padding: 6px 10px; border-left: 3px solid #2271b1; border-radius: 0 4px 4px 0; max-width: 300px;">';
            $html .= '<strong>📝 Note:</strong><br>' . nl2br(esc_html($item['notes']));
            $html .= '</div>';
        }

        return sprintf( '%1$s %2$s',
            $html,
            $this->row_actions( $actions )
        );
    }

    public function get_bulk_actions() {
        return [
            'bulk-approve' => 'Approva',
            'bulk-reject'  => 'Rifiuta',
            'bulk-delete'  => 'Elimina'
        ];
    }

    public function prepare_items() {
        global $wpdb;

        $table_name = $wpdb->prefix . 'sbs_bookings';
        $per_page = 20;
        
        $columns = $this->get_columns();
        $hidden = [];
        $sortable = $this->get_sortable_columns();

        $this->_column_headers = [$columns, $hidden, $sortable];

        $this->process_bulk_action();

        $current_page = $this->get_pagenum();

        $orderby = ( !empty($_REQUEST['orderby']) ) ? sanitize_sql_orderby($_REQUEST['orderby']) : 'created_at';
        $order = ( !empty($_REQUEST['order']) ) ? sanitize_text_field($_REQUEST['order']) : 'DESC';

        // Evita SQL Injection base
        $valid_columns = ['name', 'booking_date', 'status', 'created_at'];
        if ( !in_array($orderby, $valid_columns) ) {
            $orderby = 'created_at';
        }
        $order = strtoupper($order) === 'ASC' ? 'ASC' : 'DESC';

        $total_items = $wpdb->get_var("SELECT COUNT(id) FROM $table_name");

        $offset = ($current_page - 1) * $per_page;

        $this->items = $wpdb->get_results( 
            "SELECT * FROM $table_name ORDER BY $orderby $order LIMIT $per_page OFFSET $offset", 
            ARRAY_A 
        );

        $this->set_pagination_args([
            'total_items' => $total_items,
            'per_page'    => $per_page,
            'total_pages' => ceil( $total_items / $per_page )
        ]);
    }

    public function process_bulk_action() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'sbs_bookings';

        // Azioni singole dalla riga
        $action = isset( $_REQUEST['action'] ) ? sanitize_text_field( $_REQUEST['action'] ) : '';
        $booking_id = isset( $_REQUEST['booking'] ) ? absint( $_REQUEST['booking'] ) : 0;

        if ( $booking_id && in_array( $action, ['approve', 'reject', 'delete'] ) ) {
            check_admin_referer( 'sbs_booking_action' );
            
            $booking = $wpdb->get_row( $wpdb->prepare( "SELECT gcal_event_id FROM $table_name WHERE id = %d", $booking_id ) );
            $gcal_id = $booking ? $booking->gcal_event_id : '';

            if ( 'approve' === $action ) {
                $wpdb->update( $table_name, ['status' => 'approved'], ['id' => $booking_id], ['%s'], ['%d'] );
                if ( class_exists('SBS_Gcal') ) SBS_Gcal::create_event( $booking_id );
            } elseif ( 'reject' === $action ) {
                $wpdb->update( $table_name, ['status' => 'rejected'], ['id' => $booking_id], ['%s'], ['%d'] );
                if ( class_exists('SBS_Gcal') && $gcal_id ) SBS_Gcal::delete_event( $gcal_id );
            } elseif ( 'delete' === $action ) {
                $wpdb->delete( $table_name, ['id' => $booking_id], ['%d'] );
                if ( class_exists('SBS_Gcal') && $gcal_id ) SBS_Gcal::delete_event( $gcal_id );
            }
        }

        // Azioni massive dai checkbox
        $bulk_action = $this->current_action();
        $booking_ids = isset( $_REQUEST['booking_id'] ) ? $_REQUEST['booking_id'] : []; // wp-list-table usa 'booking_id' come name dei checkbox se configurati (ma noi usiamo cb in get_columns e non li abbiamo mappati, quindi bulk action nativo potrebbe non funzionare subito. Però almeno prepariamo la logica).
        
        if ( is_array( $booking_ids ) && !empty($booking_ids) && in_array( $bulk_action, ['bulk-approve', 'bulk-reject', 'bulk-delete'] ) ) {
            check_admin_referer( 'bulk-' . $this->_args['plural'] );
            $ids_csv = implode(',', array_map('absint', $booking_ids));
            $count = count($booking_ids);
            
            if ( 'bulk-reject' === $bulk_action || 'bulk-delete' === $bulk_action ) {
                $bookings = $wpdb->get_results("SELECT gcal_event_id FROM $table_name WHERE id IN ($ids_csv)");
                if ( class_exists('SBS_Gcal') ) {
                    foreach ( $bookings as $b ) {
                        if ( !empty($b->gcal_event_id) ) SBS_Gcal::delete_event( $b->gcal_event_id );
                    }
                }
            }

            if ( 'bulk-approve' === $bulk_action ) {
                $wpdb->query("UPDATE $table_name SET status = 'approved' WHERE id IN ($ids_csv)");
                if ( class_exists('SBS_Gcal') ) {
                    foreach ( $booking_ids as $b_id ) {
                        SBS_Gcal::create_event( absint($b_id) );
                    }
                }
                echo "<div class='notice notice-success is-dismissible'><p>$count appuntamenti approvati correttamente.</p></div>";
            } elseif ( 'bulk-reject' === $bulk_action ) {
                $wpdb->query("UPDATE $table_name SET status = 'rejected' WHERE id IN ($ids_csv)");
                echo "<div class='notice notice-success is-dismissible'><p>$count appuntamenti rifiutati correttamente.</p></div>";
            } elseif ( 'bulk-delete' === $bulk_action ) {
                $wpdb->query("DELETE FROM $table_name WHERE id IN ($ids_csv)");
                echo "<div class='notice notice-success is-dismissible'><p>$count appuntamenti eliminati correttamente.</p></div>";
            }
        }
    }
}
