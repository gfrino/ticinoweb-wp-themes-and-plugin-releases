<?php
/**
 * Fired during plugin activation.
 */

class SBS_Activator {

    /**
     * Esegue le azioni necessarie al momento dell'attivazione del plugin.
     * Crea la tabella custom nel DB.
     */
    public static function activate() {
        global $wpdb;

        $table_name = $wpdb->prefix . 'sbs_bookings';
        $charset_collate = $wpdb->get_charset_collate();

        // Schema della tabella per le prenotazioni
        $sql = "CREATE TABLE $table_name (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            name varchar(100) NOT NULL,
            email varchar(100) NOT NULL,
            phone varchar(50) NOT NULL,
            service varchar(100) NOT NULL,
            booking_date date NOT NULL,
            booking_time time NOT NULL,
            end_date date DEFAULT NULL,
            end_time time DEFAULT NULL,
            notes text,
            status varchar(20) DEFAULT 'pending' NOT NULL,
            token varchar(64) NOT NULL,
            gcal_event_id varchar(255) DEFAULT NULL,
            calendar_id varchar(255) DEFAULT NULL,
            source varchar(50) DEFAULT 'local' NOT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP NOT NULL,
            PRIMARY KEY  (id),
            KEY booking_date (booking_date),
            KEY status (status)
        ) $charset_collate;";

        // Richiede il file per poter eseguire dbDelta
        require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
        dbDelta( $sql );
        
        // Forziamo le colonne con ALTER TABLE se dbDelta fallisce (spesso capita con vecchie versioni)
        $row = $wpdb->get_results(  "SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE table_name = '$table_name' AND column_name = 'end_date'"  );
        if(empty($row)){
           $wpdb->query("ALTER TABLE $table_name ADD COLUMN end_date date DEFAULT NULL");
           $wpdb->query("ALTER TABLE $table_name ADD COLUMN end_time time DEFAULT NULL");
           $wpdb->query("ALTER TABLE $table_name ADD COLUMN calendar_id varchar(255) DEFAULT NULL");
           $wpdb->query("ALTER TABLE $table_name ADD COLUMN source varchar(50) DEFAULT 'local' NOT NULL");
        }
        
        // Setup delle opzioni di default (se non esistono già)
        if ( false === get_option( 'sbs_settings' ) ) {
            $default_settings = [
                'admin_email' => get_option( 'admin_email' ),
                'slot_duration' => 15,
                'email_approve_subject' => 'La tua prenotazione da ' . get_bloginfo( 'name' ) . ' è confermata',
                'email_reject_subject' => 'Aggiornamento sulla tua richiesta di prenotazione da ' . get_bloginfo( 'name' )
            ];
            add_option( 'sbs_settings', $default_settings );
        }
        
        // Setup degli orari di default con alternanza settimane
        if ( false === get_option( 'sbs_working_hours' ) ) {
            $default_hours = [
                'anchor_date' => date('Y-m-d'),
                'weeks' => [
                    0 => [ // Settimana 1: Martedì e Venerdì
                        'monday'    => [ 'active' => 0, 'slots' => [] ],
                        'tuesday'   => [ 'active' => 1, 'slots' => [ ['start' => '08:30', 'end' => '11:30'], ['start' => '13:30', 'end' => '18:00'] ] ],
                        'wednesday' => [ 'active' => 0, 'slots' => [] ],
                        'thursday'  => [ 'active' => 0, 'slots' => [] ],
                        'friday'    => [ 'active' => 1, 'slots' => [ ['start' => '08:30', 'end' => '11:30'], ['start' => '13:30', 'end' => '18:00'] ] ],
                        'saturday'  => [ 'active' => 0, 'slots' => [] ],
                        'sunday'    => [ 'active' => 0, 'slots' => [] ],
                    ],
                    1 => [ // Settimana 2: Martedì e Sabato
                        'monday'    => [ 'active' => 0, 'slots' => [] ],
                        'tuesday'   => [ 'active' => 1, 'slots' => [ ['start' => '08:30', 'end' => '11:30'], ['start' => '13:30', 'end' => '18:00'] ] ],
                        'wednesday' => [ 'active' => 0, 'slots' => [] ],
                        'thursday'  => [ 'active' => 0, 'slots' => [] ],
                        'friday'    => [ 'active' => 0, 'slots' => [] ],
                        'saturday'  => [ 'active' => 1, 'slots' => [ ['start' => '08:30', 'end' => '11:30'], ['start' => '13:30', 'end' => '18:00'] ] ],
                        'sunday'    => [ 'active' => 0, 'slots' => [] ],
                    ]
                ]
            ];
            add_option( 'sbs_working_hours', $default_hours );
        }
    }
}
