<?php
/**
 * Gestione Sincronizzazione Google Calendar
 */
class SBS_Gcal {

    const AUTH_URL = 'https://accounts.google.com/o/oauth2/auth';
    const TOKEN_URL = 'https://oauth2.googleapis.com/token';
    const API_BASE = 'https://www.googleapis.com/calendar/v3';

    public static function get_settings() {
        return get_option( 'sbs_gcal_settings', [] );
    }

    public static function save_settings( $settings ) {
        update_option( 'sbs_gcal_settings', $settings );
    }

    public static function get_auth_url() {
        $settings = self::get_settings();
        $client_id = $settings['client_id'] ?? '';
        if ( empty( $client_id ) ) return '';

        $redirect_uri = admin_url( 'admin.php?page=simple-booking-system-gcal' );
        
        $params = [
            'client_id'     => $client_id,
            'redirect_uri'  => $redirect_uri,
            'response_type' => 'code',
            'scope'         => 'https://www.googleapis.com/auth/calendar.readonly https://www.googleapis.com/auth/calendar.events',
            'access_type'   => 'offline',
            'prompt'        => 'consent'
        ];

        return self::AUTH_URL . '?' . http_build_query( $params );
    }

    public static function authenticate( $code ) {
        $settings = self::get_settings();
        $redirect_uri = admin_url( 'admin.php?page=simple-booking-system-gcal' );

        $response = wp_remote_post( self::TOKEN_URL, [
            'body' => [
                'code'          => $code,
                'client_id'     => $settings['client_id'],
                'client_secret' => $settings['client_secret'],
                'redirect_uri'  => $redirect_uri,
                'grant_type'    => 'authorization_code'
            ]
        ]);

        if ( is_wp_error( $response ) ) {
            return false;
        }

        $body = json_decode( wp_remote_retrieve_body( $response ), true );
        if ( isset( $body['access_token'] ) ) {
            $settings['access_token'] = $body['access_token'];
            if ( isset( $body['refresh_token'] ) ) {
                $settings['refresh_token'] = $body['refresh_token'];
            }
            $settings['expires_at'] = time() + $body['expires_in'];
            self::save_settings( $settings );
            
            // Log successful auth
            update_option('sbs_gcal_last_error', 'Autenticazione OAuth completata con successo. Esecuzione test...');
            return true;
        }

        update_option('sbs_gcal_last_error', 'OAuth Token Error: ' . wp_remote_retrieve_body( $response ));
        return false;
    }

    private static function refresh_token() {
        $settings = self::get_settings();
        if ( empty( $settings['refresh_token'] ) ) return false;

        $response = wp_remote_post( self::TOKEN_URL, [
            'body' => [
                'client_id'     => $settings['client_id'],
                'client_secret' => $settings['client_secret'],
                'refresh_token' => $settings['refresh_token'],
                'grant_type'    => 'refresh_token'
            ]
        ]);

        if ( is_wp_error( $response ) ) return false;

        $body = json_decode( wp_remote_retrieve_body( $response ), true );
        if ( isset( $body['access_token'] ) ) {
            $settings['access_token'] = $body['access_token'];
            $settings['expires_at'] = time() + $body['expires_in'];
            self::save_settings( $settings );
            return $body['access_token'];
        }

        return false;
    }

    private static function get_valid_token() {
        $settings = self::get_settings();
        if ( empty( $settings['access_token'] ) ) return false;

        if ( time() >= ( $settings['expires_at'] - 60 ) ) {
            return self::refresh_token();
        }

        return $settings['access_token'];
    }

    public static function api_request( $method, $endpoint, $data = null ) {
        $token = self::get_valid_token();
        if ( ! $token ) return false;

        $args = [
            'method'  => $method,
            'headers' => [
                'Authorization' => 'Bearer ' . $token,
                'Content-Type'  => 'application/json'
            ],
            'timeout' => 15
        ];

        if ( $data !== null ) {
            $args['body'] = wp_json_encode( $data );
        }

        $response = wp_remote_request( self::API_BASE . $endpoint, $args );
        if ( is_wp_error( $response ) ) return false;

        $body = json_decode( wp_remote_retrieve_body( $response ), true );
        $code = wp_remote_retrieve_response_code( $response );

        if ( $code >= 200 && $code < 300 ) {
            delete_option('sbs_gcal_last_error');
            return $body ?: true;
        }

        $error_msg = 'HTTP ' . $code . ': ' . wp_remote_retrieve_body( $response );
        update_option('sbs_gcal_last_error', $error_msg);
        return false;
    }

    public static function create_event( $booking_id ) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'sbs_bookings';
        $booking = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $table_name WHERE id = %d", $booking_id ) );
        if ( ! $booking ) return false;

        $settings = self::get_settings();
        // Spinge l'evento nel calendario principale di default, oppure nel primo selezionato
        $calendar_id = !empty($settings['selected_calendars']) ? $settings['selected_calendars'][0] : 'primary';
        if ( empty($settings['access_token']) ) return false;

        $base_settings = get_option('sbs_settings', []);
        $dur = 15;
        if ($booking->service === 'Controllo Vista') $dur = absint($base_settings['duration_vista'] ?? 30);
        if ($booking->service === 'Lenti a Contatto') $dur = absint($base_settings['duration_lenti'] ?? 30);
        if ($booking->service === 'Test Patente') $dur = absint($base_settings['duration_patente'] ?? 15);

        $start_time = strtotime( $booking->booking_date . ' ' . $booking->booking_time );
        $end_time = $start_time + ( $dur * 60 );

        $data = [
            'summary'     => $booking->name . ' - ' . $booking->service,
            'description' => "Telefono: {$booking->phone}\nEmail: {$booking->email}\nNote: {$booking->notes}",
            'start'       => [
                'dateTime' => date('Y-m-d\TH:i:s', $start_time),
                'timeZone' => wp_timezone_string()
            ],
            'end'         => [
                'dateTime' => date('Y-m-d\TH:i:s', $end_time),
                'timeZone' => wp_timezone_string()
            ]
        ];

        $response = self::api_request( 'POST', "/calendars/" . urlencode($calendar_id) . "/events", $data );
        if ( $response && isset( $response['id'] ) ) {
            $wpdb->update( $table_name, ['gcal_event_id' => $response['id']], ['id' => $booking_id] );
            return $response['id'];
        }
        return false;
    }

    public static function delete_event( $gcal_event_id ) {
        if ( empty( $gcal_event_id ) ) return false;
        $settings = self::get_settings();
        $calendar_id = !empty($settings['selected_calendars']) ? $settings['selected_calendars'][0] : 'primary';

        $response = self::api_request( 'DELETE', "/calendars/" . urlencode($calendar_id) . "/events/" . urlencode($gcal_event_id) );
        return $response !== false;
    }

    public static function get_available_calendars() {
        $settings = self::get_settings();
        if ( empty($settings['access_token']) ) return false;

        $endpoint = "/users/me/calendarList";
        $response = self::api_request( 'GET', $endpoint );
        
        if ( $response && isset($response['items']) ) {
            $calendars = [];
            foreach ($response['items'] as $item) {
                $calendars[] = [
                    'id' => $item['id'],
                    'summary' => $item['summary'],
                    'backgroundColor' => $item['backgroundColor'] ?? '#4285f4'
                ];
            }
            return $calendars;
        }
        return false;
    }

    public static function test_connection() {
        $settings = self::get_settings();
        if ( empty($settings['access_token']) ) {
            update_option('sbs_gcal_last_error', 'Token di accesso mancante. È necessario autorizzare l\'app.');
            return false;
        }

        // Se non abbiamo un refresh token, l'autorizzazione non è "offline" completa
        if ( empty($settings['refresh_token']) ) {
            update_option('sbs_gcal_last_error', 'Refresh Token mancante. La sincronizzazione in background fallirà tra un\'ora. Disconnetti e riautorizza assicurandoti di dare tutti i consensi.');
        }

        // Fetching calendarList to test read permissions
        $endpoint = "/users/me/calendarList";
        $response = self::api_request( 'GET', $endpoint );
        
        if ( $response && isset($response['items']) ) {
            // Se c'era un errore precedente (es. refresh_token mancante), lo teniamo, sennò puliamo
            if ( empty(get_option('sbs_gcal_last_error')) ) {
                update_option('sbs_gcal_last_error', 'Test API completato con successo. I permessi sono corretti.');
            }
            return true;
        }
        
        // Se $response è false, api_request ha già salvato l'errore reale in sbs_gcal_last_error
        return false;
    }

    public static function sync_from_google( $force_manual = false ) {
        $settings = self::get_settings();
        if ( empty($settings['access_token']) ) return;

        $selected_calendars = $settings['selected_calendars'] ?? [];
        if ( empty($selected_calendars) || !is_array($selected_calendars) ) return;

        $sync_tokens = $settings['sync_tokens'] ?? [];
        $calendar_names = $settings['calendar_names'] ?? [];

        $log = [
            'date' => wp_date('Y-m-d H:i:s'),
            'total_found' => 0,
            'total_imported' => 0,
            'total_updated' => 0,
            'total_skipped' => 0,
            'details' => [], // Dettagli per ogni calendario
            'error' => ''
        ];

        global $wpdb;
        $table_name = $wpdb->prefix . 'sbs_bookings';

        foreach ( $selected_calendars as $calendar_id ) {
            $cal_name = $calendar_names[$calendar_id] ?? 'Google Calendar';
            $cal_log = [
                'name' => $cal_name,
                'id' => $calendar_id,
                'found' => 0,
                'imported' => 0,
                'updated' => 0,
                'skipped' => 0,
                'reasons' => []
            ];

            $base_endpoint = "/calendars/" . urlencode($calendar_id) . "/events?singleEvents=true";
            
            $sync_token = $sync_tokens[$calendar_id] ?? '';
            
            if ( !empty($sync_token) && !$force_manual ) {
                $base_endpoint .= "&syncToken=" . urlencode($sync_token);
            } else {
                // First time sync or forced manual sync, fetch from today onwards
                $base_endpoint .= "&timeMin=" . urlencode(gmdate('Y-m-d\TH:i:s\Z'));
                $base_endpoint .= "&maxResults=2500";
            }

            $next_page_token = '';
            
            do {
                $endpoint = $base_endpoint;
                if (!empty($next_page_token)) {
                    $endpoint .= "&pageToken=" . urlencode($next_page_token);
                }

                $response = self::api_request( 'GET', $endpoint );
                if ( ! $response || isset($response['error']) ) {
                    $last_error = get_option('sbs_gcal_last_error', '');
                    if ( strpos($last_error, 'HTTP 410') !== false && !empty($sync_token) ) {
                        $log['error'] .= "Sync Token scaduto per {$calendar_id} (HTTP 410). Token rimosso, verrà eseguita una full sync al prossimo giro. ";
                        unset($sync_tokens[$calendar_id]);
                    } else {
                        $log['error'] .= "Errore su {$calendar_id}: " . esc_html($last_error) . ". ";
                    }
                    break; // Esci dal ciclo do-while per questo calendario
                }

                if ( isset( $response['items'] ) && is_array( $response['items'] ) ) {
                    $cal_log['found'] += count($response['items']);
                    $log['total_found'] += count($response['items']);
                    
                    $name_prefix = '[GCal] ' . $cal_name;

                    foreach ( $response['items'] as $item ) {
                        $event_id = $item['id'];
                        
                        if ( isset($item['status']) && $item['status'] === 'cancelled' ) {
                            $wpdb->update( $table_name, ['status' => 'rejected'], ['gcal_event_id' => $event_id] );
                            $cal_log['skipped']++;
                            $log['total_skipped']++;
                            $cal_log['reasons']['cancelled'] = ($cal_log['reasons']['cancelled'] ?? 0) + 1;
                            continue;
                        }

                        $existing = $wpdb->get_row( $wpdb->prepare( "SELECT id FROM $table_name WHERE gcal_event_id = %s", $event_id ) );
                        
                        $date = null;
                        $time = null;
                        $end_date = null;
                        $end_time = null;

                        if ( isset($item['start']['dateTime']) ) {
                            $dt = new DateTime($item['start']['dateTime']);
                            $dt->setTimezone(wp_timezone());
                            $date = $dt->format('Y-m-d');
                            $time = $dt->format('H:i');

                            if ( isset($item['end']['dateTime']) ) {
                                $dt_end = new DateTime($item['end']['dateTime']);
                                $dt_end->setTimezone(wp_timezone());
                                $end_date = $dt_end->format('Y-m-d');
                                $end_time = $dt_end->format('H:i');
                            }
                        } elseif ( isset($item['start']['date']) ) {
                            // Evento tutto il giorno
                            $dt = new DateTime($item['start']['date']);
                            $date = $dt->format('Y-m-d');
                            $time = '00:00'; // Fallback per eventi tutto il giorno

                            if ( isset($item['end']['date']) ) {
                                $dt_end = new DateTime($item['end']['date']);
                                // Google's end date for all-day events is exclusive (next day)
                                $dt_end->modify('-1 day');
                                $end_date = $dt_end->format('Y-m-d');
                                $end_time = '23:59';
                            }
                        } else {
                            $cal_log['skipped']++;
                            $log['total_skipped']++;
                            $cal_log['reasons']['missing_date'] = ($cal_log['reasons']['missing_date'] ?? 0) + 1;
                            continue;
                        }

                        if ( ! $existing ) {
                            $summary = $item['summary'] ?? 'Impegno Google Calendar';

                                $inserted = $wpdb->insert(
                                $table_name,
                                [
                                    'name'         => $name_prefix,
                                    'email'        => 'gcal@sync',
                                    'phone'        => '-',
                                    'service'      => substr($summary, 0, 100),
                                    'booking_date' => $date,
                                    'booking_time' => $time,
                                    'end_date'     => $end_date,
                                    'end_time'     => $end_time,
                                    'status'       => 'approved',
                                    'token'        => 'gcal_sync',
                                    'gcal_event_id'=> $event_id,
                                    'calendar_id'  => $calendar_id,
                                    'source'       => 'google'
                                ],
                                [ '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s' ]
                            );

                            if ( $inserted ) {
                                $cal_log['imported']++;
                                $log['total_imported']++;
                            } else {
                                $cal_log['skipped']++;
                                $log['total_skipped']++;
                                $err = $wpdb->last_error ?: 'Insert failed';
                                $cal_log['reasons']["db_error: $err"] = ($cal_log['reasons']["db_error: $err"] ?? 0) + 1;
                            }
                        } else {
                            $updated = $wpdb->update( 
                                $table_name, 
                                [ 
                                    'booking_date' => $date, 
                                    'booking_time' => $time,
                                    'end_date'     => $end_date,
                                    'end_time'     => $end_time,
                                    'calendar_id'  => $calendar_id,
                                    'source'       => 'google'
                                ], 
                                [ 'id' => $existing->id ] 
                            );

                            if ( $updated !== false ) {
                                $cal_log['updated']++;
                                $log['total_updated']++;
                            } else {
                                $cal_log['skipped']++;
                                $log['total_skipped']++;
                                $err = $wpdb->last_error ?: 'Update failed';
                                $cal_log['reasons']["db_error: $err"] = ($cal_log['reasons']["db_error: $err"] ?? 0) + 1;
                            }
                        }
                    }
                }

                $next_page_token = $response['nextPageToken'] ?? '';
                if ( isset($response['nextSyncToken']) ) {
                    $sync_tokens[$calendar_id] = $response['nextSyncToken'];
                }
                
            } while ( !empty($next_page_token) );

            $log['details'][] = $cal_log;

            // Save nextSyncToken for future cron runs
            if ( isset( $response['nextSyncToken'] ) ) {
                $sync_tokens[$calendar_id] = $response['nextSyncToken'];
            }
        }

        $settings['sync_tokens'] = $sync_tokens;
        self::save_settings( $settings );

        // Salva il log dell'ultima sincronizzazione
        update_option('sbs_gcal_sync_log', $log);
    }
}
