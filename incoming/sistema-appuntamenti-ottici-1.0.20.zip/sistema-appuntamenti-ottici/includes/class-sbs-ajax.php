<?php
class SBS_Ajax {
    
    public function get_slots() {
        check_ajax_referer( 'sbs_public_nonce', 'nonce' );
        
        $date_str = sanitize_text_field( wp_unslash( $_POST['date'] ?? '' ) );
        if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $date_str ) ) {
            wp_send_json_error( [ 'message' => 'Data non valida' ] );
        }

        $closed_days = get_option('sbs_closed_days', []);
        $is_closed = false;
        if (is_array($closed_days)) {
            foreach ($closed_days as $c_date) {
                $start = is_array($c_date) ? $c_date['start'] : $c_date;
                $end = is_array($c_date) ? $c_date['end'] : $c_date;
                if ($date_str >= $start && $date_str <= $end) {
                    $is_closed = true;
                    break;
                }
            }
        }
        
        if ( $is_closed ) {
            wp_send_json_success( [ 'slots' => [] ] );
        }

        // Assicurati che gli eventi di Google siano aggiornati prima di restituire gli slot (max 1 volta ogni 5 min)
        if ( class_exists('SBS_Gcal') ) {
            $last_sync = get_transient('sbs_last_frontend_sync');
            if ( false === $last_sync ) {
                SBS_Gcal::sync_from_google();
                set_transient('sbs_last_frontend_sync', time(), 5 * MINUTE_IN_SECONDS);
            }
        }

        $timestamp = strtotime( $date_str );
        // Recupera il giorno della settimana in minuscolo (monday, tuesday...)
        $day_of_week = strtolower( date( 'l', $timestamp ) );
        
        $hours = get_option( 'sbs_working_hours', [] );
        $settings = get_option( 'sbs_settings', [] );
        $requested_duration = isset($_POST['duration']) ? absint($_POST['duration']) : 15;
        $base_interval = 15; // Costante: griglia ogni 15 minuti
        
        // --- LOGICA CICLO CONTINUO ---
        if ( !isset($hours['weeks']) || !is_array($hours['weeks']) ) {
            wp_send_json_success( [ 'slots' => [] ] );
        }
        
        $total_weeks = absint($hours['cycle_weeks'] ?? count($hours['weeks']));
        if ($total_weeks === 0) {
            wp_send_json_success( [ 'slots' => [] ] );
        }
        
        $anchor_date_str = $hours['anchor_date'] ?? '2026-05-01';
        $anchor_timestamp = strtotime( $anchor_date_str );
        
        // Calcolo differenza in giorni
        $diff_time = $timestamp - $anchor_timestamp;
        $diff_days = (int) round($diff_time / (60 * 60 * 24));
        
        $days_in_cycle = $total_weeks * 7;
        $day_offset = $diff_days % $days_in_cycle;
        if ($day_offset < 0) $day_offset += $days_in_cycle;
        
        $week_index = (int) floor($day_offset / 7);
        
        // Fallback di sicurezza se la settimana calcolata non esiste nelle impostazioni salvate
        if (!isset($hours['weeks'][$week_index])) {
            $week_index = 0;
        }
        $day_config = $hours['weeks'][$week_index][$day_of_week] ?? [];
        
        if ( empty( $day_config['active'] ) ) {
            wp_send_json_success( [ 'slots' => [] ] );
        }

        $all_slots = []; // Griglia di 15 minuti per il controllo disponibilità
        $display_slots = []; // Slot da mostrare all'utente
        
        // Genera gli slot basati sugli orari di apertura
        if ( ! empty( $day_config['slots'] ) && is_array( $day_config['slots'] ) ) {
            foreach ( $day_config['slots'] as $time_range ) {
                if ( empty( $time_range['start'] ) || empty( $time_range['end'] ) ) continue;
                
                $start_time = strtotime( $date_str . ' ' . $time_range['start'] );
                $end_time = strtotime( $date_str . ' ' . $time_range['end'] );
                
                // Popola la griglia dei 15 minuti
                $curr = $start_time;
                while ( $curr < $end_time ) {
                    $all_slots[] = date( 'H:i', $curr );
                    $curr += ($base_interval * 60);
                }
                
                // Popola gli slot da mostrare
                $curr_display = $start_time;
                while ( $curr_display + ($requested_duration * 60) <= $end_time ) {
                    $display_slots[] = date( 'H:i', $curr_display );
                    $curr_display += ($requested_duration * 60);
                }
            }
        }

        // Recupera le prenotazioni esistenti per calcolare l'occupazione reale
        global $wpdb;
        $table_name = $wpdb->prefix . 'sbs_bookings';

        $existing_bookings = $wpdb->get_results( $wpdb->prepare(
            "SELECT booking_time, service FROM $table_name WHERE booking_date = %s AND status != 'rejected'",
            $date_str
        ) );
        
        $booked_intervals = [];
        foreach($existing_bookings as $b) {
            $start_time = strtotime($date_str . ' ' . $b->booking_time);
            
            // Determina la durata in base al servizio
            $dur = 15;
            if ($b->service === 'Controllo Vista') $dur = absint($settings['duration_vista'] ?? 30);
            if ($b->service === 'Lenti a Contatto') $dur = absint($settings['duration_lenti'] ?? 30);
            if ($b->service === 'Test Patente') $dur = absint($settings['duration_patente'] ?? 15);
            
            $end_time = $start_time + ($dur * 60);
            
            // Segna come occupati tutti i blocchi coperti
            $curr = $start_time;
            while($curr < $end_time) {
                $booked_intervals[] = date('H:i', $curr);
                $curr += ($base_interval * 60);
            }
        }

        $slots_data = [];
        foreach ( $display_slots as $slot_time ) {
            $is_available = true;
            $slot_timestamp = strtotime($date_str . ' ' . $slot_time);
            $req_end_time = $slot_timestamp + ($requested_duration * 60);
            
            // Controlla se tutti i blocchi richiesti sono liberi
            $curr = $slot_timestamp;
            while($curr < $req_end_time) {
                $curr_time_str = date('H:i', $curr);
                // Se lo slot cade fuori dall'orario di lavoro o è occupato
                if (in_array($curr_time_str, $booked_intervals) || !in_array($curr_time_str, $all_slots)) {
                    $is_available = false;
                    break;
                }
                $curr += ($base_interval * 60);
            }

            $slots_data[] = [
                'time'      => $slot_time,
                'available' => $is_available
            ];
        }

        wp_send_json_success( [ 'slots' => $slots_data ] );
    }

    public function submit_booking() {
        check_ajax_referer( 'sbs_public_nonce', 'nonce' );
        
        // Controllo Honeypot
        if ( ! empty( $_POST['sbs_honeypot'] ) ) {
            wp_send_json_error( [ 'message' => 'Rilevato traffico anomalo.' ] );
        }

        // Recupero e Validazione
        $date = sanitize_text_field( wp_unslash( $_POST['sbs_date'] ?? '' ) );
        $time = sanitize_text_field( wp_unslash( $_POST['sbs_time'] ?? '' ) );
        $service = sanitize_text_field( wp_unslash( $_POST['sbs_service'] ?? '' ) );
        $name = sanitize_text_field( wp_unslash( $_POST['sbs_name'] ?? '' ) );
        $email = sanitize_email( wp_unslash( $_POST['sbs_email'] ?? '' ) );
        $phone = sanitize_text_field( wp_unslash( $_POST['sbs_phone'] ?? '' ) );
        $notes = sanitize_textarea_field( wp_unslash( $_POST['sbs_notes'] ?? '' ) );
        $gdpr = ! empty( $_POST['sbs_gdpr'] );

        if ( ! $date || ! $time || ! $service || ! $name || ! is_email( $email ) || ! $phone || ! $gdpr ) {
            wp_send_json_error( [ 'message' => 'Compila tutti i campi obbligatori correttamente.' ] );
        }

        global $wpdb;
        $table_name = $wpdb->prefix . 'sbs_bookings';

        // Check disponibilità finale (evita doppie prenotazioni concorrenti)
        $exists = $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(id) FROM $table_name WHERE booking_date = %s AND booking_time = %s AND status != 'rejected'",
            $date,
            $time
        ) );

        if ( $exists > 0 ) {
            wp_send_json_error( [ 'message' => 'Ci dispiace, questo orario è appena stato prenotato da un altro utente. Ricarica e scegli un altro slot.' ] );
        }

        // Genera Token
        $token = bin2hex( random_bytes( 16 ) );

        // Inserimento
        $inserted = $wpdb->insert(
            $table_name,
            [
                'name'         => $name,
                'email'        => $email,
                'phone'        => $phone,
                'service'      => $service,
                'booking_date' => $date,
                'booking_time' => $time,
                'notes'        => $notes,
                'status'       => 'approved',
                'token'        => $token
            ],
            [ '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s' ]
        );

        if ( $inserted ) {
            require_once SBS_PLUGIN_DIR . 'includes/class-sbs-mailer.php';
            SBS_Mailer::send_admin_notification( $wpdb->insert_id );
            SBS_Mailer::send_customer_status( $wpdb->insert_id, 'approved' );
            
            // Push to Google Calendar
            if ( class_exists('SBS_Gcal') ) {
                SBS_Gcal::create_event( $wpdb->insert_id );
            }

            wp_send_json_success( [ 'message' => 'Prenotazione confermata con successo. Riceverai a breve una email con i dettagli.' ] );
        } else {
            wp_send_json_error( [ 'message' => 'Errore nel salvataggio. Riprova più tardi.' ] );
        }
    }

    public function create_manual_booking() {
        check_ajax_referer( 'sbs_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Non autorizzato' );

        $date       = sanitize_text_field( wp_unslash( $_POST['date'] ?? '' ) );
        $time_start = sanitize_text_field( wp_unslash( $_POST['time_start'] ?? '' ) );
        $time_end   = sanitize_text_field( wp_unslash( $_POST['time_end'] ?? '' ) );
        $service    = sanitize_text_field( wp_unslash( $_POST['service'] ?? '' ) );
        $name       = sanitize_text_field( wp_unslash( $_POST['name'] ?? '' ) );
        $email      = sanitize_email( wp_unslash( $_POST['email'] ?? '' ) );
        $phone      = sanitize_text_field( wp_unslash( $_POST['phone'] ?? '' ) );
        $notes      = sanitize_textarea_field( wp_unslash( $_POST['notes'] ?? '' ) );

        if ( ! $date || ! $time_start || ! $service || ! $name ) {
            wp_send_json_error( 'Compila tutti i campi obbligatori (Nome, Servizio, Data, Ora Inizio).' );
        }

        global $wpdb;
        $table_name = $wpdb->prefix . 'sbs_bookings';

        // Calcola end_time se non fornito (default 15 minuti o 30)
        if ( empty($time_end) ) {
            $settings = get_option('sbs_settings', []);
            $dur = isset($settings['default_duration']) ? absint($settings['default_duration']) : 15;
            $time_end = date('H:i', strtotime($time_start) + ($dur * 60));
        }

        $token = bin2hex( random_bytes( 16 ) );

        $inserted = $wpdb->insert(
            $table_name,
            [
                'name'         => $name,
                'email'        => $email,
                'phone'        => $phone,
                'service'      => $service,
                'booking_date' => $date,
                'booking_time' => $time_start,
                'end_date'     => $date,
                'end_time'     => $time_end,
                'notes'        => $notes,
                'status'       => 'approved',
                'token'        => $token,
                'source'       => 'manual'
            ],
            [ '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s' ]
        );

        if ( $inserted ) {
            $booking_id = $wpdb->insert_id;
            
            // Push to Google Calendar se attivo
            if ( class_exists('SBS_Gcal') ) {
                SBS_Gcal::create_event( $booking_id );
            }

            wp_send_json_success( 'Appuntamento creato con successo' );
        } else {
            wp_send_json_error( 'Errore nel salvataggio del database.' );
        }
    }
    public function get_admin_events() {
        check_ajax_referer( 'sbs_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error();

        // Assicurati che gli eventi di Google siano aggiornati prima di mostrare il calendario admin (limite 1 minuto)
        if ( class_exists('SBS_Gcal') ) {
            $last_sync_admin = get_transient('sbs_last_admin_sync');
            if ( false === $last_sync_admin ) {
                SBS_Gcal::sync_from_google();
                set_transient('sbs_last_admin_sync', time(), 1 * MINUTE_IN_SECONDS);
            }
        }

        global $wpdb;
        $table_name = $wpdb->prefix . 'sbs_bookings';

        // $start e $end sono passati in ISO8601 da FullCalendar
        $bookings = $wpdb->get_results( "SELECT * FROM $table_name WHERE status = 'approved'" );

        $events = [];
        $settings = get_option( 'sbs_settings', [] );

        foreach ( $bookings as $b ) {
            $start_datetime = $b->booking_date . 'T' . $b->booking_time;
            $is_allday = false;

            if ( isset($b->source) && $b->source === 'google' ) {
                $timestamp_start = strtotime($start_datetime); // <--- Aggiunto questo
                if ( !empty($b->end_date) && !empty($b->end_time) ) {
                    $end_datetime = $b->end_date . 'T' . $b->end_time;
                    if ( $b->booking_time === '00:00:00' && $b->end_time === '23:59:00' ) {
                        $is_allday = true;
                    }
                } else {
                    // Fallback se per qualche motivo mancano i nuovi campi o erano vecchi inserimenti
                    $timestamp_end = $timestamp_start + (15 * 60);
                    $end_datetime = date('Y-m-d\TH:i:s', $timestamp_end);
                    if ( $b->booking_time === '00:00:00' ) {
                        $is_allday = true;
                    }
                }
            } else {
                // Evento locale del plugin
                $dur = 15;
                if ($b->service === 'Controllo Vista') $dur = absint($settings['duration_vista'] ?? 30);
                if ($b->service === 'Lenti a Contatto') $dur = absint($settings['duration_lenti'] ?? 30);
                if ($b->service === 'Test Patente') $dur = absint($settings['duration_patente'] ?? 15);

                $timestamp_start = strtotime($start_datetime);
                $timestamp_end = $timestamp_start + ($dur * 60);
                $end_datetime = date('Y-m-d\TH:i:s', $timestamp_end);
            }

            // Determina il giorno della settimana (1 = Lunedì, 7 = Domenica)
            $day_of_week = date('N', $timestamp_start);
            
            // Colori per ogni giorno della settimana (per eventi LOCALI)
            $day_colors = [
                1 => '#3788d8', // Lunedì: Blu
                2 => '#f39c12', // Martedì: Arancione
                3 => '#2ecc71', // Mercoledì: Verde
                4 => '#9b59b6', // Giovedì: Viola
                5 => '#e74c3c', // Venerdì: Rosso
                6 => '#00bcd4', // Sabato: Azzurro
                7 => '#34495e'  // Domenica: Grigio scuro
            ];
            
            $color = $day_colors[$day_of_week] ?? '#3788d8';
            
            // Se è un evento di Google Calendar, proviamo a prendere il suo colore
            if ( isset($b->source) && $b->source === 'google' && !empty($b->calendar_id) ) {
                $gcal_settings = get_option('sbs_gcal_settings', []);
                if ( !empty($gcal_settings['calendar_colors'][$b->calendar_id]) ) {
                    $color = $gcal_settings['calendar_colors'][$b->calendar_id];
                } else {
                    $color = '#4285f4'; // Fallback a Google Blue se non salvato
                }
            }
            
            // Rendi gli eventi "In attesa" diversi visivamente
            if ($b->status !== 'approved') {
                $status_prefix = '⏳ [ATTESA] ';
                // Potremmo usare un opacity, ma Fullcalendar preferisce backgroundColor
                // Per semplicità aggiungiamo un prefisso chiaro e manteniamo il colore del giorno
            } else {
                $status_prefix = '✅ ';
            }

            $events[] = [
                'id' => $b->id,
                'title' => $status_prefix . esc_html($b->name) . ' - ' . esc_html($b->service),
                'start' => $start_datetime,
                'end' => $end_datetime,
                'allDay' => $is_allday,
                'backgroundColor' => $color,
                'borderColor' => $color,
                'textColor' => '#fff',
                'extendedProps' => [
                    'phone' => esc_html($b->phone),
                    'notes' => esc_html($b->notes),
                    'status' => $b->status,
                    'source' => isset($b->source) ? $b->source : 'local'
                ]
            ];
        }

        wp_send_json( $events );
    }

    public static function delete_booking() {
        check_ajax_referer( 'sbs_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( 'Non autorizzato' );
        }
        
        $id = isset($_POST['id']) ? intval($_POST['id']) : 0;
        if ( ! $id ) {
            wp_send_json_error( 'ID mancante' );
        }
        
        global $wpdb;
        $table_name = $wpdb->prefix . 'sbs_bookings';
        
        $booking = $wpdb->get_row( $wpdb->prepare("SELECT * FROM $table_name WHERE id = %d", $id) );
        if (!$booking) {
            wp_send_json_error( 'Appuntamento non trovato' );
        }
        
        if ( isset($booking->source) && $booking->source === 'google' ) {
            wp_send_json_error( 'Non puoi eliminare un evento di Google Calendar da qui. Eliminalo direttamente su Google Calendar e attendi la sincronizzazione.' );
        }
        
        $deleted = $wpdb->delete( $table_name, [ 'id' => $id ], [ '%d' ] );
        
        if ( $deleted ) {
            wp_send_json_success();
        } else {
            wp_send_json_error( 'Errore durante l\'eliminazione' );
        }
    }
}
