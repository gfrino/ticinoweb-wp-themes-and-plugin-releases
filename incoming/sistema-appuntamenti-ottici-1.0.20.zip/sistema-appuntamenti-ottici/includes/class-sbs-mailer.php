<?php
class SBS_Mailer {
    
    private static function replace_placeholders( $text, $booking ) {
        $date_f = date_i18n( get_option('date_format'), strtotime($booking->booking_date) );
        $time_f = date_i18n( get_option('time_format'), strtotime($booking->booking_time) );
        
        $replacements = [
            '{nome}'     => $booking->name,
            '{email}'    => $booking->email,
            '{telefono}' => $booking->phone,
            '{servizio}' => $booking->service,
            '{data}'     => $date_f,
            '{ora}'      => $time_f,
            '{note}'     => !empty($booking->notes) ? $booking->notes : 'Nessuna nota'
        ];
        
        return strtr( $text, $replacements );
    }

    private static function wrap_in_html_template( $title, $content ) {
        $logo_id = get_theme_mod( 'custom_logo' );
        $logo_html = '';
        if ( $logo_id ) {
            $logo_url = wp_get_attachment_image_url( $logo_id, 'full' );
            if ( $logo_url ) {
                $logo_html = '<div style="text-align: center; margin-bottom: 30px;"><img src="' . esc_url( $logo_url ) . '" alt="' . esc_attr( get_bloginfo('name') ) . '" style="max-height: 80px; width: auto;" /></div>';
            }
        }
        
        if ( empty($logo_html) ) {
            $logo_html = '<div style="text-align: center; margin-bottom: 30px;"><h1 style="color: #333; margin: 0; font-size: 24px;">' . esc_html( get_bloginfo('name') ) . '</h1></div>';
        }

        return '
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <title>' . esc_html( $title ) . '</title>
        </head>
        <body style="background-color: #f7f9fc; padding: 40px 20px; font-family: -apple-system, BlinkMacSystemFont, \'Segoe UI\', Roboto, Helvetica, Arial, sans-serif; margin: 0; color: #333333; line-height: 1.6;">
            <div style="max-width: 600px; margin: 0 auto; background-color: #ffffff; padding: 40px; border-radius: 8px; box-shadow: 0 4px 6px rgba(0,0,0,0.05);">
                ' . $logo_html . '
                <div style="font-size: 16px; color: #555;">
                    ' . $content . '
                </div>
                <div style="margin-top: 40px; padding-top: 20px; border-top: 1px solid #eee; font-size: 13px; color: #999; text-align: center;">
                    Questo è un messaggio automatico da <strong>' . esc_html( get_bloginfo('name') ) . '</strong>.<br>
                    Si prega di non rispondere direttamente a questa email.
                </div>
            </div>
        </body>
        </html>
        ';
    }

    public static function send_admin_notification( $booking_id ) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'sbs_bookings';
        
        $booking = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $table_name WHERE id = %d", $booking_id ) );
        if ( ! $booking ) return false;
        
        $settings = get_option( 'sbs_settings', [] );
        $to = !empty($settings['admin_email']) ? $settings['admin_email'] : get_option('admin_email');
        $subject = 'Nuova Richiesta di Prenotazione: ' . $booking->name;
        
        $raw_body = !empty($settings['email_admin_body']) ? $settings['email_admin_body'] : "Hai ricevuto un nuovo appuntamento confermato.\n\nCliente: {nome}\nServizio: {servizio}\nData: {data} alle {ora}\nEmail: {email}\nTelefono: {telefono}\nNote: {note}";
        $body = self::replace_placeholders( $raw_body, $booking );
        
        // Consenti HTML sicuro ma converti anche i newlines normali in <br>
        $content = nl2br( wp_kses_post( $body ) );
        $message = self::wrap_in_html_template( $subject, $content );
        
        $from_name = get_bloginfo('name');
        $from_email = get_option('admin_email');
        $headers = array(
            'Content-Type: text/html; charset=UTF-8',
            'From: ' . $from_name . ' <' . $from_email . '>'
        );
        
        $set_html_content_type = function() { return 'text/html'; };
        add_filter( 'wp_mail_content_type', $set_html_content_type );
        
        $result = wp_mail( $to, $subject, $message, $headers );
        
        remove_filter( 'wp_mail_content_type', $set_html_content_type );
        
        return $result;
    }

    public static function send_customer_status( $booking_id, $status ) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'sbs_bookings';
        
        $booking = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $table_name WHERE id = %d", $booking_id ) );
        if ( ! $booking ) return false;
        
        $settings = get_option( 'sbs_settings', [] );
        $to = $booking->email;
        
        if ( $status === 'approved' ) {
            $raw_subject = !empty($settings['email_approve_subject']) ? $settings['email_approve_subject'] : 'Prenotazione Confermata!';
            $raw_body = !empty($settings['email_approve_body']) ? $settings['email_approve_body'] : "Ciao {nome},\n\nSiamo felici di confermarti che il tuo appuntamento per {servizio} è confermato!\n\nTi aspettiamo il giorno {data} alle {ora}.";
        } else {
            $raw_subject = !empty($settings['email_reject_subject']) ? $settings['email_reject_subject'] : 'Aggiornamento Prenotazione';
            $raw_body = !empty($settings['email_reject_body']) ? $settings['email_reject_body'] : "Ciao {nome},\n\nCi dispiace informarti che non possiamo confermare il tuo appuntamento per {servizio} del {data} alle {ora}.\nPotrebbe esserci stato un accavallamento o il negozio è chiuso.\n\nTi invitiamo a contattarci o a effettuare una nuova richiesta.";
        }
        
        $subject = self::replace_placeholders( $raw_subject, $booking );
        $body = self::replace_placeholders( $raw_body, $booking );
        
        // Consenti HTML sicuro ma converti anche i newlines normali in <br>
        $content = nl2br( wp_kses_post( $body ) );
        $message = self::wrap_in_html_template( $subject, $content );
        
        $from_name = get_bloginfo('name');
        $from_email = get_option('admin_email');
        $headers = array(
            'Content-Type: text/html; charset=UTF-8',
            'From: ' . $from_name . ' <' . $from_email . '>'
        );
        
        $set_html_content_type = function() { return 'text/html'; };
        add_filter( 'wp_mail_content_type', $set_html_content_type );
        
        $result = wp_mail( $to, $subject, $message, $headers );
        
        remove_filter( 'wp_mail_content_type', $set_html_content_type );
        
        return $result;
    }
}
