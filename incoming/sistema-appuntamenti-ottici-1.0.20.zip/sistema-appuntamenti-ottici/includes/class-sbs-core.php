<?php
/**
 * La classe core del plugin. Carica le dipendenze e definisce gli hook.
 */

class SBS_Core {
    protected $plugin_name;
    protected $version;

    public function __construct() {
        if ( defined( 'SBS_VERSION' ) ) {
            $this->version = SBS_VERSION;
        } else {
            $this->version = '1.0.0';
        }
        $this->plugin_name = 'simple-booking-system';
        
        $this->load_dependencies();
        $this->define_admin_hooks();
        $this->define_public_hooks();
    }

    private function load_dependencies() {
        // Carica la classe Admin
        require_once SBS_PLUGIN_DIR . 'admin/class-sbs-admin.php';
        // Carica la classe Frontend (Public)
        require_once SBS_PLUGIN_DIR . 'public/class-sbs-public.php';
        // Carica la classe per la gestione AJAX
        require_once SBS_PLUGIN_DIR . 'includes/class-sbs-ajax.php';
        // Carica la classe GCal
        require_once SBS_PLUGIN_DIR . 'includes/class-sbs-gcal.php';
    }

    private function define_admin_hooks() {
        $plugin_admin = new SBS_Admin( $this->plugin_name, $this->version );
        
        add_action( 'admin_menu', array( $plugin_admin, 'add_plugin_admin_menu' ) );
        add_action( 'admin_enqueue_scripts', array( $plugin_admin, 'enqueue_styles' ) );
        add_action( 'admin_enqueue_scripts', array( $plugin_admin, 'enqueue_scripts' ) );
        
        // Registrazione dei settaggi Admin
        add_action( 'admin_init', array( $plugin_admin, 'register_settings' ) );

        // Cron schedules
        add_filter( 'cron_schedules', array( $this, 'add_cron_schedules' ) );
        
        // Setup Cron Job
        add_action( 'sbs_gcal_sync_event', array( 'SBS_Gcal', 'sync_from_google' ) );
        if ( ! wp_next_scheduled( 'sbs_gcal_sync_event' ) ) {
            wp_schedule_event( time(), 'sbs_fifteen_minutes', 'sbs_gcal_sync_event' );
        }
    }

    public function add_cron_schedules( $schedules ) {
        if ( ! isset( $schedules['sbs_fifteen_minutes'] ) ) {
            $schedules['sbs_fifteen_minutes'] = array(
                'interval' => 15 * 60,
                'display'  => 'Ogni 15 Minuti'
            );
        }
        return $schedules;
    }

    private function define_public_hooks() {
        $plugin_public = new SBS_Public( $this->plugin_name, $this->version );
        
        // Registra lo shortcode [booking_calendar]
        add_shortcode( 'booking_calendar', array( $plugin_public, 'render_shortcode' ) );
        
        add_action( 'wp_enqueue_scripts', array( $plugin_public, 'enqueue_styles' ) );
        add_action( 'wp_enqueue_scripts', array( $plugin_public, 'enqueue_scripts' ) );
        
        // Registra gli endpoints AJAX
        $plugin_ajax = new SBS_Ajax();
        add_action( 'wp_ajax_sbs_get_slots', array( $plugin_ajax, 'get_slots' ) );
        add_action( 'wp_ajax_nopriv_sbs_get_slots', array( $plugin_ajax, 'get_slots' ) );
        
        add_action( 'wp_ajax_sbs_submit_booking', array( $plugin_ajax, 'submit_booking' ) );
        add_action( 'wp_ajax_nopriv_sbs_submit_booking', array( $plugin_ajax, 'submit_booking' ) );
        
        // Admin Calendar AJAX
        add_action( 'wp_ajax_sbs_admin_get_events', array( $plugin_ajax, 'get_admin_events' ) );
        add_action( 'wp_ajax_sbs_create_manual_booking', array( $plugin_ajax, 'create_manual_booking' ) );
        add_action( 'wp_ajax_sbs_delete_booking', array( $plugin_ajax, 'delete_booking' ) );
        
        // Ascolta l'azione dai link email disabilitato per auto-conferma
        // add_action( 'init', array( $this, 'process_email_actions' ) );
    }

    public function process_email_actions() {
        // Funzione disabilitata: le prenotazioni ora sono auto-confermate.
    }

    public function run() {
        // L'inizializzazione degli hooks avviene già nel costruttore e tramite WP_Hook
    }
}
