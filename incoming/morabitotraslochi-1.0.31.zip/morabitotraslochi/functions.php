<?php
/**
 * Morabito Traslochi child theme functions
 */

// Inizializza il sistema di Autoupdate per il tema
require_once dirname(__FILE__) . '/updater.php';

add_action('wp_enqueue_scripts', 'morabitotraslochi_enqueue_styles', 20);
function morabitotraslochi_enqueue_styles()
{
    // Enqueue parent theme stylesheet
    wp_enqueue_style('ticinoweb-parent-style', get_template_directory_uri() . '/style.css', array(), '1.0.0');

    // Enqueue child theme stylesheet (loads after parent)
    wp_enqueue_style('morabitotraslochi-child-style', get_stylesheet_directory_uri() . '/style.css', array('ticinoweb-parent-style'), wp_get_theme()->get('Version'));
}

add_action('wp_enqueue_scripts', 'morabitotraslochi_custom_scripts', 100);
function morabitotraslochi_custom_scripts()
{
    // Rimuoviamo il js dello slider del parent theme perché lo riscriviamo nel child theme
    wp_dequeue_script('ticinoweb-ai-main');
    wp_deregister_script('ticinoweb-ai-main');

    // Carichiamo lo script modificato per Morabito Traslochi (gestisce l'hover)
    wp_enqueue_script('morabitotraslochi-main', get_stylesheet_directory_uri() . '/js/slider.js', array(), wp_get_theme()->get('Version'), true);

    // Carichiamo lo script per il lightbox della galleria
    wp_enqueue_script('morabitotraslochi-lightbox', get_stylesheet_directory_uri() . '/js/lightbox.js', array(), wp_get_theme()->get('Version'), true);
}

add_action('after_setup_theme', 'morabitotraslochi_setup');
function morabitotraslochi_setup()
{
    register_nav_menus(array(
        'footer' => __('Menu Footer', 'morabitotraslochi'),
    ));
}

/**
 * Aggiunge lo script in linea per il toggle del menu mobile di Morabito Traslochi
 */
add_action('wp_footer', 'morabitotraslochi_mobile_menu_script');
function morabitotraslochi_mobile_menu_script()
{
    ?>
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const toggleBtn = document.querySelector('.tt-menu-toggle');
            const navWrapper = document.querySelector('.tt-nav-wrapper');

            if (toggleBtn && navWrapper) {
                toggleBtn.addEventListener('click', function (e) {
                    e.preventDefault();
                    navWrapper.classList.toggle('active');
                    toggleBtn.classList.toggle('active');

                    const isExpanded = toggleBtn.getAttribute('aria-expanded') === 'true' || false;
                    toggleBtn.setAttribute('aria-expanded', !isExpanded);
                });

                // Chiudi il menu quando si clicca un link
                const navLinks = navWrapper.querySelectorAll('a');
                navLinks.forEach(link => {
                    link.addEventListener('click', () => {
                        navWrapper.classList.remove('active');
                        toggleBtn.classList.remove('active');
                        toggleBtn.setAttribute('aria-expanded', 'false');
                    });
                });

                // Chiudi il menu se si fa tap fuori dalla barra laterale sinistra (sullo sfondo)
                document.addEventListener('click', function (e) {
                    if (navWrapper.classList.contains('active')) {
                        if (!toggleBtn.contains(e.target) && !navWrapper.contains(e.target)) {
                            navWrapper.classList.remove('active');
                            toggleBtn.classList.remove('active');
                            toggleBtn.setAttribute('aria-expanded', 'false');
                        }
                    }
                });
            }
        });
    </script>
    <?php
}

/**
 * Auto-creates the Privacy Policy page and sets it as the official Privacy Policy in WP settings.
 */
add_action('init', 'morabitotraslochi_ensure_privacy_policy_page');
function morabitotraslochi_ensure_privacy_policy_page() {
    // Prevent running on every page load
    if (get_option('morabitotraslochi_privacy_page_created')) {
        return;
    }

    $page_title = 'Privacy Policy';
    $page_slug = 'privacy-policy';
    
    // Check if page already exists
    $page = get_page_by_path($page_slug);
    
    if (!$page) {
        $page_id = wp_insert_post(array(
            'post_title'     => $page_title,
            'post_name'      => $page_slug,
            'post_content'   => 'La presente informativa è redatta in conformità alla normativa applicabile...', // Real content is served by template file
            'post_status'    => 'publish',
            'post_type'      => 'page',
        ));
    } else {
        $page_id = $page->ID;
    }

    if ($page_id) {
        // Set it as the official WP Privacy Policy page
        update_option('wp_page_for_privacy_policy', $page_id);
        
        // Save flag to prevent running again
        update_option('morabitotraslochi_privacy_page_created', true);
    }
}

/**
 * Crea (una volta sola) la pagina della landing, in bozza, con indirizzo e testi SEO.
 */
add_action( 'init', 'morabitotraslochi_ensure_landing_bellinzona' );
function morabitotraslochi_ensure_landing_bellinzona() {
    if ( get_option( 'morabitotraslochi_landing_bellinzona_created' ) ) {
        return;
    }
    if ( ! get_page_by_path( 'traslochi-bellinzona' ) ) {
        $page_id = wp_insert_post( array(
            'post_title'  => 'Traslochi a Bellinzona',
            'post_name'   => 'traslochi-bellinzona',
            'post_status' => 'draft',
            'post_type'   => 'page',
        ) );
        if ( $page_id && ! is_wp_error( $page_id ) ) {
            update_post_meta( $page_id, '_wp_page_template', 'page-traslochi-bellinzona.php' );
            update_post_meta( $page_id, '_tw_seo_title', 'Traslochi Bellinzona | Preventivo Gratuito – Morabito' );
            update_post_meta( $page_id, '_tw_seo_description', 'Cerchi una ditta di traslochi a Bellinzona? Morabito Traslochi offre traslochi per privati e aziende, trasporti e sgomberi. Richiedi un preventivo gratuito' );
        }
    }
    update_option( 'morabitotraslochi_landing_bellinzona_created', true );
}
