<?php
/**
 * Template Name: Richiedi Preventivo
 */

// Handle Form Submission with wp_mail()
$form_status = '';
$submission_id = 0;

// Dopo un invio riuscito si arriva qui con ?inviato=<codice>: la conferma (e l'evento per GTM)
// compaiono una sola volta, e solo se il server ha davvero registrato la richiesta.
if (isset($_GET['inviato'])) {
    if (!defined('DONOTCACHEPAGE')) {
        define('DONOTCACHEPAGE', true);
    }
    do_action('litespeed_control_set_nocache', 'conferma richiesta preventivo');
    nocache_headers();

    $inviato = sanitize_text_field(wp_unslash($_GET['inviato']));
    if (preg_match('/^[a-f0-9-]{36}$/', $inviato)) {
        $shown = (int) get_transient('mt_show_' . $inviato);
        if ($shown > 0) {
            delete_transient('mt_show_' . $inviato);
            $form_status = 'success';
            $submission_id = $shown;
        }
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'richiedi_preventivo') {
    
    // Verify reCAPTCHA
    $recaptcha_secret = get_option('ticinoweb_recaptcha_secret_key');
    $recaptcha_site   = get_option('ticinoweb_recaptcha_site_key');
    $recaptcha_thresh = get_option('ticinoweb_recaptcha_threshold', 0.5);

    $is_human = true;
    if (!empty($recaptcha_secret) && !empty($recaptcha_site)) {
        $recaptcha_response = isset($_POST['g-recaptcha-response']) ? $_POST['g-recaptcha-response'] : '';
        
        if (empty($recaptcha_response)) {
            $is_human = false;
        } else {
            $verify_response = wp_remote_post('https://www.google.com/recaptcha/api/siteverify', array(
                'body' => array(
                    'secret' => $recaptcha_secret,
                    'response' => $recaptcha_response,
                    'remoteip' => $_SERVER['REMOTE_ADDR']
                )
            ));

            $verify_body = wp_remote_retrieve_body($verify_response);
            $response_data = json_decode($verify_body);

            if (!$response_data->success || $response_data->score < $recaptcha_thresh) {
                $is_human = false;
            }
        }
    }

    // Codice dell'invio, generato dal browser: serve a non registrare due volte la stessa richiesta
    $form_token = isset($_POST['form_token']) ? sanitize_text_field(wp_unslash($_POST['form_token'])) : '';
    if (!preg_match('/^[a-f0-9-]{36}$/', $form_token)) {
        $form_token = wp_generate_uuid4();
    }

    global $wpdb;
    $lock_name = 'mt_' . substr(md5($form_token), 0, 20);
    $wpdb->get_var($wpdb->prepare('SELECT GET_LOCK(%s, 10)', $lock_name));

    $already_saved = (int) get_transient('mt_sub_' . $form_token);

    $has_contact = !empty(trim((string) ($_POST['email'] ?? ''))) || !empty(trim((string) ($_POST['telefono'] ?? '')));

    if ($already_saved > 0) {
        // Doppio clic o invio ripetuto: la richiesta c'è già, si mostra la stessa conferma senza rifarla
        set_transient('mt_show_' . $form_token, $already_saved, HOUR_IN_SECONDS);
        $wpdb->get_var($wpdb->prepare('SELECT RELEASE_LOCK(%s)', $lock_name));
        wp_safe_redirect(add_query_arg('inviato', $form_token, get_permalink()));
        exit;
    } elseif (!$is_human) {
        $form_status = 'error_recaptcha';
    } elseif (!$has_contact) {
        $form_status = 'error_validation';
    } else {
        // Get basic details
        $admin_email = get_option('ticinoweb_contact_email');
        // Fallback info if CMS contact isn't set perfectly
        if (empty($admin_email)) {
            $admin_email = get_option('admin_email');
        }

        $user_email = isset($_POST['email']) ? sanitize_email($_POST['email']) : '';
        $user_name = isset($_POST['nome']) && !empty(trim($_POST['nome'])) ? sanitize_text_field($_POST['nome']) : 'Cliente';
        $tipo = isset($_POST['tipo_richiesta']) ? sanitize_text_field($_POST['tipo_richiesta']) : 'richiesta generica';
        $phone = isset($_POST['telefono']) ? sanitize_text_field($_POST['telefono']) : '';

        // Extract detailed fields dynamically
        $dettagli_completi = "\n--- DETTAGLI COMPLETI DELLA RICHIESTA ---\n\n";
        foreach ($_POST as $key => $value) {
            if (in_array($key, ['action', 'tipo_richiesta', 'nome', 'email', 'telefono', 'g-recaptcha-response', 'form_token']) || empty($value)) {
                continue;
            }
            
            $label = ucfirst(str_replace('_', ' ', $key));
            if (is_array($value)) {
                $value = implode(', ', array_map('sanitize_text_field', $value));
            } else {
                $value = sanitize_textarea_field($value);
            }
            $dettagli_completi .= "• {$label}: {$value}\n";
        }

        // ============================================
        // 0. SAVE TO DATABASE (CMS INVII RICEVUTI)
        // ============================================
        $db_messaggio = "Tipologia: " . strtoupper($tipo) . "\n";
        $db_messaggio .= "Mittente: " . $user_name . "\n";
        if($user_email) $db_messaggio .= "Email: " . $user_email . "\n";
        if($phone) $db_messaggio .= "Telefono: " . $phone . "\n";
        $db_messaggio .= $dettagli_completi;
                        
        $saved = $wpdb->insert(
            $wpdb->prefix . 'ticinoweb_form_submissions',
            array(
                'nome'       => $user_name,
                'email'      => $user_email,
                'telefono'   => $phone,
                'oggetto'    => 'Richiesta: ' . strtoupper($tipo),
                'messaggio'  => $db_messaggio,
                'data_invio' => current_time('mysql'),
                'letto'      => 0
            )
        );
        $new_submission_id = $saved ? (int) $wpdb->insert_id : 0;
        if (!$new_submission_id) {
            error_log('Morabito: richiesta preventivo non salvata nel database: ' . $wpdb->last_error);
        }

        // ============================================
        // 1. DRAFT EMAIL FOR ADMINISTRATOR
        // ============================================
        $admin_subject = "Nuova richiesta da sito: " . strtoupper($tipo) . " - " . $user_name;
        
        $admin_message = "Hai ricevuto una nuova richiesta dal form del sito Morabito Traslochi.\n\n";
        $admin_message .= "Tipologia: " . strtoupper($tipo) . "\n";
        $admin_message .= "Mittente: " . $user_name . "\n";
        if($user_email) $admin_message .= "Email: " . $user_email . "\n";
        if($phone) $admin_message .= "Telefono: " . $phone . "\n";
        $admin_message .= $dettagli_completi;
        
        $admin_message .= "\n-----------------------------------------\nEmail generata automaticamente dallo strumento multi-step del sito.";
        
        $admin_headers = array('Content-Type: text/plain; charset=UTF-8');
        if ($user_email) {
            $admin_headers[] = 'Reply-To: ' . $user_name . ' <' . $user_email . '>';
        }
        
        // Fire to Admin!
        if (!wp_mail($admin_email, $admin_subject, $admin_message, $admin_headers)) {
            error_log('Morabito: email di notifica della richiesta ' . $new_submission_id . ' non inviata');
        }
        
        // ============================================
        // 2. DRAFT AUTO-RESPONDER FOR THE USER
        // ============================================
        if (!empty($user_email) && is_email($user_email)) {
            $user_subject = "Conferma ricezione: Richiesta " . ucfirst($tipo) . " - Morabito Traslochi";
            
            $user_message = "Gentile $user_name,\n\n";
            $user_message .= "Questa email automatica ti conferma che abbiamo ricevuto correttamente la tua richiesta per un " . strtolower($tipo) . ".\n\n";
            $user_message .= "Il nostro team valuterà i dettagli forniti e ti contatterà al più presto per proseguire.\n\n";
            $user_message .= "Riepilogo dei tuoi contatti inseriti:\n";
            $user_message .= "- Telefono: $phone\n";
            $user_message .= "- Email: $user_email\n";
            $user_message .= $dettagli_completi . "\n";
            if(strtolower($tipo) == 'preventivo') {
                $user_message .= "In questa tipologia di operazione (preventivo), i nostri uffici processeranno l'inventario per farti avere la miglior stima.\n\n";
            } else {
                 $user_message .= "Trattandosi di un sopralluogo, ti richiameremo per fissare un breve appuntamento conoscitivo assolutamente senza alcun impegno.\n\n";
            }
            $user_message .= "A presto,\n";
            $user_message .= "Lo Staff di Morabito Traslochi\n";
            $user_message .= "https://www.morabitotraslochi.ch";
            
            $user_headers = array('Content-Type: text/plain; charset=UTF-8');
            // Impersonate the brand!
            $user_headers[] = 'From: Morabito Traslochi <' . $admin_email . '>';
            $user_headers[] = 'Reply-To: Morabito Traslochi <' . $admin_email . '>';
            
            // Fire to User!
            wp_mail($user_email, $user_subject, $user_message, $user_headers);
        }

        // Riuscita = richiesta registrata nel database (l'email parte comunque, anche se il salvataggio fallisce)
        if ($new_submission_id > 0) {
            set_transient('mt_sub_' . $form_token, $new_submission_id, HOUR_IN_SECONDS);
            set_transient('mt_show_' . $form_token, $new_submission_id, HOUR_IN_SECONDS);
            $wpdb->get_var($wpdb->prepare('SELECT RELEASE_LOCK(%s)', $lock_name));
            // Redirect: ricaricare la pagina non rimanda il modulo e non ripete la conferma
            wp_safe_redirect(add_query_arg('inviato', $form_token, get_permalink()));
            exit;
        }
        $form_status = 'error_save';
    }
    $wpdb->get_var($wpdb->prepare('SELECT RELEASE_LOCK(%s)', $lock_name));
}

get_header();

$contact_info = function_exists('ticinoweb_get_contact_info') ? ticinoweb_get_contact_info() : array();
$phone = isset($contact_info['phone']) && !empty($contact_info['phone']) ? $contact_info['phone'] : '+41 79 000 00 00';
$email = isset($contact_info['email']) && !empty($contact_info['email']) ? $contact_info['email'] : 'info@morabitotraslochi.ch';
$address = isset($contact_info['address']) && !empty($contact_info['address']) ? $contact_info['address'] : 'Inserisci Indirizzo';
?>

<main id="primary" class="site-main page-preventivo">

    <!-- Hero Section -->
    <section class="page-hero">
        <div class="container text-center">
            <h1 class="page-title">Richiedi un Preventivo</h1>
            <p class="page-hero-subtitle">Compila il modulo sottostante per ricevere una valutazione gratuita e senza impegno per il tuo trasloco o servizio, oppure richiedere un sopralluogo con un nostro consulente.</p>
        </div>
    </section>

    <!-- Main Content - Wizard -->
    <section class="wizard-section section-padding" style="padding: 60px 0; background-color: #f9f9f9;">
        <div class="container">
            <div class="contact-grid" style="display: grid; grid-template-columns: 1fr 1.5fr; gap: 60px;">
                
                <!-- Left Column (Info + Map) -->
                <div class="left-col-wrap" style="display: flex; flex-direction: column; gap: 30px; height: fit-content;">
                    <!-- Contact Info Column -->
                    <div class="contact-info-wrap" style="background: #fff; padding: 40px; border-radius: 12px; box-shadow: 0 10px 30px rgba(0,0,0,0.05);">
                        <h2 style="font-size: 1.8rem; font-weight: 700; color: #333; margin-bottom: 30px;">I Nostri Recapiti</h2>
                    
                    <div class="info-block" style="display: flex; gap: 15px; margin-bottom: 25px; align-items: flex-start;">
                        <div class="icon" style="background: rgba(255,94,20,0.1); width: 45px; height: 45px; display: flex; align-items: center; justify-content: center; border-radius: 50%; color: var(--color-primary); flex-shrink: 0;">
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path></svg>
                        </div>
                        <div>
                            <h4 style="margin: 0 0 5px; font-size: 1.1rem; color: #333;">Telefono</h4>
                            <p style="margin: 0; color: #666;"><a href="tel:<?php echo esc_attr(str_replace(' ', '', $phone)); ?>" style="color: inherit; text-decoration: none;"><?php echo esc_html($phone); ?></a></p>
                        </div>
                    </div>

                    <div class="info-block" style="display: flex; gap: 15px; margin-bottom: 25px; align-items: flex-start;">
                        <div class="icon" style="background: rgba(255,94,20,0.1); width: 45px; height: 45px; display: flex; align-items: center; justify-content: center; border-radius: 50%; color: var(--color-primary); flex-shrink: 0;">
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path><polyline points="22,6 12,13 2,6"></polyline></svg>
                        </div>
                        <div>
                            <h4 style="margin: 0 0 5px; font-size: 1.1rem; color: #333;">Email</h4>
                            <p style="margin: 0; color: #666;"><a href="mailto:<?php echo esc_attr($email); ?>" style="color: inherit; text-decoration: none;"><?php echo esc_html($email); ?></a></p>
                        </div>
                    </div>

                    <div class="info-block" style="display: flex; gap: 15px; align-items: flex-start;">
                        <div class="icon" style="background: rgba(255,94,20,0.1); width: 45px; height: 45px; display: flex; align-items: center; justify-content: center; border-radius: 50%; color: var(--color-primary); flex-shrink: 0;">
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path><circle cx="12" cy="10" r="3"></circle></svg>
                        </div>
                        <div>
                            <h4 style="margin: 0 0 5px; font-size: 1.1rem; color: #333;">Indirizzo Sede</h4>
                            <p style="margin: 0; color: #666;"><?php echo esc_html($address); ?></p>
                        </div>
                    </div>
                    </div>

                    <!-- Google Map Box -->
                    <div style="background: #fff; padding: 15px; border-radius: 12px; box-shadow: 0 10px 30px rgba(0,0,0,0.05);">
                         <iframe src="https://www.google.com/maps?q=Via+Galbisio+23,+6500+Bellinzona,+Switzerland&output=embed" width="100%" height="280" style="border:0; border-radius: 8px; display: block;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                    </div>
                </div>

            <div class="wizard-container" style="width: 100%; margin: 0; background: #fff; padding: 40px; border-radius: 12px; box-shadow: 0 10px 30px rgba(0,0,0,0.05);">

                <!-- Form -->
                <form id="multistep-form" action="" method="POST">
                    <input type="hidden" name="action" value="richiedi_preventivo">
                    <input type="hidden" name="form_token" id="form-token" value="">
                    <!-- Type Selector Toggle -->
                    <div style="display: flex; gap: 15px; margin-bottom: 40px; border-bottom: 2px solid #eee; padding-bottom: 30px;">
                        <label style="flex: 1; cursor: pointer;">
                            <input type="radio" name="tipo_richiesta" value="preventivo" checked style="display: none;" onchange="window.toggleFormType(this.value)">
                            <div id="btn-preventivo" style="padding: 15px; border: 2px solid var(--color-primary); border-radius: 8px; text-align: center; font-weight: bold; background: rgba(255,94,20,0.05); color: var(--color-primary); transition: all 0.3s;">Richiedi Preventivo</div>
                        </label>
                        <label style="flex: 1; cursor: pointer;">
                            <input type="radio" name="tipo_richiesta" value="sopralluogo" style="display: none;" onchange="window.toggleFormType(this.value)">
                            <div id="btn-sopralluogo" style="padding: 15px; border: 2px solid #ddd; border-radius: 8px; text-align: center; font-weight: bold; background: #fff; color: #555; transition: all 0.3s;">Richiedi Sopralluogo</div>
                        </label>
                    </div>

                    <?php if ($form_status === 'success') : ?>
                        <div style="background: #e8f5e9; color: #2e7d32; padding: 15px 20px; border-radius: 8px; margin-bottom: 30px; border: 1px solid #c8e6c9;">
                            Grazie! La tua richiesta è stata inviata con successo. Ti contatteremo al più presto.
                        </div>
                        <script>
                        (function () {
                            var id = <?php echo (int) $submission_id; ?>;
                            var key = 'mt_quote_sent_' + id;
                            try {
                                if (sessionStorage.getItem(key)) { return; }
                                sessionStorage.setItem(key, '1');
                            } catch (e) {}
                            window.dataLayer = window.dataLayer || [];
                            window.dataLayer.push({ event: 'quote_form_success', submission_id: String(id) });
                        })();
                        </script>
                    <?php elseif ($form_status !== '') : ?>
                        <div role="alert" style="background: #fdecea; color: #b71c1c; padding: 15px 20px; border-radius: 8px; margin-bottom: 30px; border: 1px solid #f5c6cb;">
                            Non siamo riusciti a registrare la richiesta. Riprova tra poco oppure chiamaci al telefono.
                        </div>
                    <?php endif; ?>

                    <!-- PREVENTIVO WRAPPER (Original Wizard) -->
                    <div id="preventivo-wrapper">
                        <!-- Progress Bar -->
                        <ul id="wizard-progressbar" style="list-style: none; padding: 0; margin-bottom: 50px; display: flex; justify-content: space-between; position: relative;">
                            <div class="progress-line" style="position: absolute; top: 20px; left: 0; width: 100%; height: 4px; background: #eee; z-index: 0;"></div>
                            <div class="progress-line-active" id="progress-line-active" style="position: absolute; top: 20px; left: 0; width: 0%; height: 4px; background: var(--color-primary); z-index: 1; transition: width 0.4s ease;"></div>
                            
                            <?php 
                            $steps = ['Dati Trasloco', 'Contatto', 'Servizio', 'Attuale', 'Futura', 'Inventario'];
                            foreach($steps as $index => $step): 
                            ?>
                                <li class="progress-step <?php echo $index === 0 ? 'active' : ''; ?>" data-step="<?php echo $index; ?>" style="position: relative; z-index: 2; text-align: center; width: 16%; font-size: 0.9rem; font-weight: 600; color: #aaa; transition: color 0.3s; cursor: pointer;">
                                    <div class="step-num" style="width: 40px; height: 40px; border-radius: 50%; background: #eee; color: #888; display: flex; align-items: center; justify-content: center; margin: 0 auto 10px; font-weight: bold; font-size: 1.1rem; transition: all 0.3s; border: 4px solid #fff; box-shadow: 0 0 0 2px #eee;">
                                        <?php echo $index + 1; ?>
                                    </div>
                                    <span class="step-label" style="display: block; line-height: 1.2;"><?php echo $step; ?></span>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                        
                    <!-- STEP 1: DATI DEL TRASLOCO -->
                    <fieldset class="wizard-step active-step" id="step-1">
                        <h2 style="font-size: 1.8rem; color: #333; margin-bottom: 25px; border-bottom: 2px solid #eee; padding-bottom: 10px;">Dati del Trasloco</h2>
                        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 20px;">
                            <div class="form-group">
                                <label>Trasloco da: indirizzo completo *</label>
                                <input type="text" name="trasloco_da" required class="form-control" placeholder="Via, CAP, Città, Nazione">
                            </div>
                            <div class="form-group">
                                <label>Trasloco a: indirizzo completo *</label>
                                <input type="text" name="trasloco_a" required class="form-control" placeholder="Via, CAP, Città, Nazione">
                            </div>
                            <div class="form-group">
                                <label>Data trasloco *</label>
                                <input type="date" name="data_trasloco" required class="form-control">
                            </div>
                            <div class="form-group">
                                <label>Grandezza appartamento (es. 3.5 locali) *</label>
                                <input type="text" name="grandezza" required class="form-control" placeholder="es. 3.5 locali, 100mq">
                            </div>
                        </div>
                        <div class="step-actions" style="display: flex; justify-content: flex-end; margin-top: 30px;">
                            <button type="button" class="btn btn-primary btn-next">Avanti &rarr;</button>
                        </div>
                    </fieldset>

                    <!-- STEP 2: CONTATTO -->
                    <fieldset class="wizard-step" id="step-2" style="display: none;">
                        <h2 style="font-size: 1.8rem; color: #333; margin-bottom: 25px; border-bottom: 2px solid #eee; padding-bottom: 10px;">Contatto</h2>
                        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 20px;">
                            <div class="form-group">
                                <label>Nome/Cognome *</label>
                                <input type="text" name="nome" required class="form-control" placeholder="Nome completo">
                            </div>
                            <div class="form-group">
                                <label>E-Mail *</label>
                                <input type="email" name="email" required class="form-control" placeholder="La tua email">
                            </div>
                            <div class="form-group">
                                <label>Cellulare *</label>
                                <input type="tel" name="telefono" required class="form-control" placeholder="Il tuo numero">
                            </div>
                            <div class="form-group">
                                <label>Indirizzo Attuale</label>
                                <input type="text" name="indirizzo_contatto" class="form-control" placeholder="(Se diverso da Trasloco da)">
                            </div>
                        </div>
                        <div class="step-actions" style="display: flex; justify-content: space-between; margin-top: 30px;">
                            <button type="button" class="btn btn-outline btn-prev">&larr; Indietro</button>
                            <button type="button" class="btn btn-primary btn-next">Avanti &rarr;</button>
                        </div>
                    </fieldset>

                    <!-- STEP 3: SERVIZIO -->
                    <fieldset class="wizard-step" id="step-3" style="display: none;">
                        <h2 style="font-size: 1.8rem; color: #333; margin-bottom: 25px; border-bottom: 2px solid #eee; padding-bottom: 10px;">Servizio di trasloco</h2>
                        <div class="form-group" style="margin-bottom: 20px;">
                            <label>Seleziona il servizio richiesto *</label>
                            <select name="servizio" class="form-control" required style="cursor: pointer; height: 50px;">
                                <option value="">-- Seleziona --</option>
                                <option value="Trasloco Privato">Trasloco Privato</option>
                                <option value="Trasloco Aziendale">Trasloco Aziendale</option>
                                <option value="Sgombero Locali">Sgombero Locali</option>
                                <option value="Noleggio Autoscala">Noleggio Autoscala</option>
                                <option value="Altro">Altro (specificare nel messaggio)</option>
                            </select>
                        </div>
                        <div class="step-actions" style="display: flex; justify-content: space-between; margin-top: 30px;">
                            <button type="button" class="btn btn-outline btn-prev">&larr; Indietro</button>
                            <button type="button" class="btn btn-primary btn-next">Avanti &rarr;</button>
                        </div>
                    </fieldset>

                    <!-- STEP 4: SITUAZIONE ABITAZIONE ATTUALE -->
                    <fieldset class="wizard-step" id="step-4" style="display: none;">
                        <h2 style="font-size: 1.8rem; color: #333; margin-bottom: 25px; border-bottom: 2px solid #eee; padding-bottom: 10px;">Situazione Abitazione Attuale</h2>
                        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 20px;">
                            <div class="form-group">
                                <label>Tipo di abitazione</label>
                                <select name="attuale_tipo" class="form-control" style="cursor: pointer;">
                                    <option value="Appartamento">Appartamento</option>
                                    <option value="Casa Indipendente">Casa Indipendente</option>
                                    <option value="Ufficio">Ufficio</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>Piano</label>
                                <input type="number" name="attuale_piano" class="form-control" placeholder="Es. 0 per PT, 1 per primo piano">
                            </div>
                            <div class="form-group">
                                <label>Presenza Ascensore</label>
                                <select name="attuale_ascensore" class="form-control" style="cursor: pointer;">
                                    <option value="Sì, capiente">Sì, molto capiente</option>
                                    <option value="Sì, ma piccolo">Sì, ma piccolo</option>
                                    <option value="No">No</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>Distanza parcheggio furgone</label>
                                <input type="text" name="attuale_parcheggio" class="form-control" placeholder="Es. Sotto casa, 50mt...">
                            </div>
                        </div>
                        <div class="step-actions" style="display: flex; justify-content: space-between; margin-top: 30px;">
                            <button type="button" class="btn btn-outline btn-prev">&larr; Indietro</button>
                            <button type="button" class="btn btn-primary btn-next">Avanti &rarr;</button>
                        </div>
                    </fieldset>

                    <!-- STEP 5: FUTURA ABITAZIONE -->
                    <fieldset class="wizard-step" id="step-5" style="display: none;">
                        <h2 style="font-size: 1.8rem; color: #333; margin-bottom: 25px; border-bottom: 2px solid #eee; padding-bottom: 10px;">Futura Abitazione</h2>
                        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 20px;">
                            <div class="form-group">
                                <label>Tipo di abitazione</label>
                                <select name="futura_tipo" class="form-control" style="cursor: pointer;">
                                    <option value="Appartamento">Appartamento</option>
                                    <option value="Casa Indipendente">Casa Indipendente</option>
                                    <option value="Ufficio">Ufficio</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>Piano</label>
                                <input type="number" name="futura_piano" class="form-control" placeholder="Es. 0 per PT, 1 per primo piano">
                            </div>
                            <div class="form-group">
                                <label>Presenza Ascensore</label>
                                <select name="futura_ascensore" class="form-control" style="cursor: pointer;">
                                    <option value="Sì, capiente">Sì, molto capiente</option>
                                    <option value="Sì, ma piccolo">Sì, ma piccolo</option>
                                    <option value="No">No</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>Distanza parcheggio furgone</label>
                                <input type="text" name="futura_parcheggio" class="form-control" placeholder="Es. Sotto casa, 50mt...">
                            </div>
                        </div>
                        <div class="step-actions" style="display: flex; justify-content: space-between; margin-top: 30px;">
                            <button type="button" class="btn btn-outline btn-prev">&larr; Indietro</button>
                            <button type="button" class="btn btn-primary btn-next">Avanti &rarr;</button>
                        </div>
                    </fieldset>

                    <!-- STEP 6: INVENTARIO PER CAMERA -->
                    <fieldset class="wizard-step" id="step-6" style="display: none;">
                        <h2 style="font-size: 1.8rem; color: #333; margin-bottom: 25px; border-bottom: 2px solid #eee; padding-bottom: 10px;">Inventario per Camera</h2>
                        <p style="margin-bottom: 30px; color: #666; font-size: 1.05rem;">Compila le quantità e descrizioni necessarie (compila liberamente solo le righe utili).</p>
                        
                        <div class="inventory-sections" style="display: flex; flex-direction: column; gap: 40px;">
                            <?php 
                            $rooms = ['Giardino/Balcone', 'Cantina', 'Camera dei bambini', 'Cucina', 'Soggiorno', 'Camera da letto'];
                            foreach($rooms as $r_idx => $room):
                            ?>
                            <div class="inventory-room" style="background: #fafafa; border: 1px solid #eee; border-radius: 8px; padding: 25px;">
                                <h3 style="margin-top: 0; margin-bottom: 20px; color: var(--color-primary); font-size: 1.3rem; border-left: 4px solid var(--color-primary); padding-left: 10px;"><?php echo $room; ?></h3>
                                <div style="overflow-x: auto;">
                                    <table style="width: 100%; border-collapse: collapse; min-width: 600px; background:#fff;">
                                        <thead>
                                            <tr style="background: #efefef; text-align: left; color: #444;">
                                                <th style="padding: 12px; border: 1px solid #ddd; width: 15%;">Quantità</th>
                                                <th style="padding: 12px; border: 1px solid #ddd; width: 30%;">Oggetto</th>
                                                <th style="padding: 12px; border: 1px solid #ddd; width: 30%;">Caratteristiche</th>
                                                <th style="padding: 12px; border: 1px solid #ddd; width: 25%;">Commento</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php for($i=0; $i<4; $i++): ?>
                                            <tr>
                                                <td style="padding: 8px; border: 1px solid #ddd;"><input type="number" name="inv_<?php echo $r_idx; ?>_q_<?php echo $i; ?>" class="form-control" style="padding: 10px; width: 100%; border:1px solid #ccc; font-size:0.95rem;"></td>
                                                <td style="padding: 8px; border: 1px solid #ddd;"><input type="text" name="inv_<?php echo $r_idx; ?>_obj_<?php echo $i; ?>" class="form-control" style="padding: 10px; width: 100%; border:1px solid #ccc; font-size:0.95rem;"></td>
                                                <td style="padding: 8px; border: 1px solid #ddd;"><input type="text" name="inv_<?php echo $r_idx; ?>_car_<?php echo $i; ?>" class="form-control" style="padding: 10px; width: 100%; border:1px solid #ccc; font-size:0.95rem;" placeholder="es. Smontare, Fragile"></td>
                                                <td style="padding: 8px; border: 1px solid #ddd;"><input type="text" name="inv_<?php echo $r_idx; ?>_com_<?php echo $i; ?>" class="form-control" style="padding: 10px; width: 100%; border:1px solid #ccc; font-size:0.95rem;"></td>
                                            </tr>
                                            <?php endfor; ?>
                                        </tbody>
                                    </table>
                                </div>
                                <div style="margin-top: 15px; text-align: right;">
                                    <button type="button" class="btn btn-outline btn-add-row" data-room-idx="<?php echo $r_idx; ?>" style="padding: 8px 15px; font-size: 0.9rem;">+ Aggiungi riga</button>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>

                        <div class="step-actions" style="display: flex; justify-content: space-between; margin-top: 40px;">
                            <button type="button" class="btn btn-outline btn-prev">&larr; Indietro</button>
                            <button type="submit" class="btn btn-primary btn-submit" style="font-size:1.2rem; padding:15px 40px; box-shadow: 0 10px 20px rgba(255,94,20,0.3);">Invia Richiesta Preventivo</button>
                        </div>
                    </fieldset>
                    </div> <!-- chiusura preventivo-wrapper -->

                    <!-- SOPRALLUOGO WRAPPER -->
                    <div id="sopralluogo-wrapper" style="display: none;">
                        <fieldset class="wizard-step" style="display: block;">
                            <h2 style="font-size: 1.8rem; color: #333; margin-bottom: 25px; border-bottom: 2px solid #eee; padding-bottom: 10px;">Prenota un Sopralluogo</h2>
                            <p style="margin-bottom: 25px; color: #666; font-size: 1.05rem;">Non hai tempo per compilare l'inventario? Lasciaci i tuoi contatti: verremo noi direttamente a fornire una valutazione e un preventivo gratuiti per il tuo trasloco!</p>
                            <div style="display: grid; grid-template-columns: 1fr; gap: 20px; margin-bottom: 20px;">
                                <div class="form-group">
                                    <label>Nome e Cognome</label>
                                    <input type="text" name="nome" disabled class="form-control" placeholder="Tuo nome (opzionale)">
                                </div>
                                <div class="form-group">
                                    <label>Cellulare *</label>
                                    <input type="tel" name="telefono" disabled class="form-control" placeholder="Il tuo numero">
                                </div>
                                <div class="form-group">
                                    <label>E-Mail *</label>
                                    <input type="email" name="email" disabled class="form-control" placeholder="La tua email">
                                </div>
                                <div class="form-group">
                                    <label>Messaggio</label>
                                    <textarea name="messaggio" disabled class="form-control" rows="4" placeholder="Eventuali note... (opzionale)"></textarea>
                                </div>
                            </div>
                            <div class="step-actions" style="display: flex; justify-content: flex-end; margin-top: 30px;">
                                <button type="button" id="btn-submit-sopralluogo" class="btn btn-primary" style="font-size:1.2rem; padding:15px 40px; box-shadow: 0 10px 20px rgba(255,94,20,0.3);">Richiedi Sopralluogo</button>
                            </div>
                        </fieldset>
                    </div>

                </form>

            </div>
            </div> <!-- Close Contact Grid -->
        </div>
    </section>

    <!-- Wizard Core CSS -->
    <style>
        .wizard-step {
            border: none;
            padding: 0;
            margin: 0;
            min-width: 0;
        }
        .form-control {
            width: 100%;
            padding: 14px 15px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 1.05rem;
            background: #fff;
            transition: border-color 0.3s, box-shadow 0.3s;
            resize: vertical;
        }
        .form-control:focus {
            outline: none;
            border-color: var(--color-primary);
            box-shadow: 0 0 0 3px rgba(255, 94, 20, 0.1);
        }
        .form-group label {
            display: block;
            font-weight: 600;
            color: #444;
            margin-bottom: 8px;
            font-size: 1rem;
        }
        .btn-outline {
            background: transparent;
            border: 2px solid #ccc;
            color: #555;
            padding: 14px 30px;
            border-radius: 8px;
            font-size: 1.1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
        }
        .btn-outline:hover {
            border-color: #999;
            color: #333;
        }
        .btn-next {
            padding: 14px 40px;
            font-size: 1.1rem;
            border-radius: 8px;
        }
        
        /* Progress logic */
        .progress-step.active .step-num {
            background: var(--color-primary) !important;
            color: #fff !important;
            box-shadow: 0 0 0 4px rgba(255, 94, 20, 0.2) !important;
            border-color: var(--color-primary) !important;
        }
        .progress-step.active .step-label {
            color: var(--color-primary) !important;
            font-weight: 700;
        }
        .progress-step.completed .step-num {
            background: #4caf50 !important;
            color: #fff !important;
            border-color: #4caf50 !important;
            box-shadow: none !important;
        }
        .progress-step.completed .step-label {
            color: #4caf50 !important;
        }
        
        @media (max-width: 768px) {
            .contact-grid { grid-template-columns: 1fr !important; gap: 40px !important; display: flex !important; flex-direction: column-reverse !important; }
            .wizard-container { padding: 25px 15px !important; width: 100% !important; margin: 0 !important; }
            .left-col-wrap { width: 100% !important; }
            .step-label { display: none !important; }
            .form-group { margin-bottom: 15px; }
            .wizard-step > div { grid-template-columns: 1fr !important; }
            .inventory-room { padding: 10px !important; margin-bottom: 20px; }
        }
    </style>

    <!-- Wizard Core JS -->
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const steps = document.querySelectorAll('#preventivo-wrapper .wizard-step');
            const progressSteps = document.querySelectorAll('.progress-step');
            const progressLineActive = document.getElementById('progress-line-active');
            let currentStep = 0;
            let maxStepReached = 0; // Track highest visited step for clickable logic

            function updateWizard() {
                steps.forEach((step, index) => {
                    step.style.display = index === currentStep ? 'block' : 'none';
                });

                progressSteps.forEach((step, index) => {
                    if (index < currentStep) {
                        step.classList.add('completed');
                        step.classList.add('active');
                    } else if (index === currentStep) {
                        step.classList.add('active');
                        step.classList.remove('completed');
                    } else {
                        step.classList.remove('active');
                        step.classList.remove('completed');
                    }
                });

                const percentage = (currentStep / (steps.length - 1)) * 100;
                progressLineActive.style.width = percentage + '%';
                
                // Keep track of maximum step reached
                if(currentStep > maxStepReached) {
                    maxStepReached = currentStep;
                }
            }
            
            // Allow clicking on progress steps to go back or forward to already visited steps
            progressSteps.forEach((stepBtn) => {
                stepBtn.addEventListener('click', function() {
                    const targetStep = parseInt(this.getAttribute('data-step'));
                    // Only allow navigating to steps we have already reached (to prevent skipping validation)
                    if (targetStep <= maxStepReached && targetStep !== currentStep) {
                        currentStep = targetStep;
                        updateWizard();
                    }
                });
            });

            function validateEmail(email) {
                const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                return re.test(email);
            }
            
            function validatePhone(phone) {
                const re = /^\+?[0-9\s]+$/;
                return re.test(phone);
            }

            // Global toggle Form UI and Input Enabling/Disabling logic
            window.toggleFormType = function(type) {
                const preventivoWrapper = document.getElementById('preventivo-wrapper');
                const sopralluogoWrapper = document.getElementById('sopralluogo-wrapper');
                const btnPrev = document.getElementById('btn-preventivo');
                const btnSopr = document.getElementById('btn-sopralluogo');

                if (type === 'preventivo') {
                    preventivoWrapper.style.display = 'block';
                    sopralluogoWrapper.style.display = 'none';

                    preventivoWrapper.querySelectorAll('input, select, textarea').forEach(el => el.disabled = false);
                    sopralluogoWrapper.querySelectorAll('input, select, textarea').forEach(el => el.disabled = true);

                    btnPrev.style.borderColor = 'var(--color-primary)';
                    btnPrev.style.background = 'rgba(255,94,20,0.05)';
                    btnPrev.style.color = 'var(--color-primary)';
                    
                    btnSopr.style.borderColor = '#ddd';
                    btnSopr.style.background = '#fff';
                    btnSopr.style.color = '#555';
                } else {
                    preventivoWrapper.style.display = 'none';
                    sopralluogoWrapper.style.display = 'block';

                    preventivoWrapper.querySelectorAll('input, select, textarea').forEach(el => el.disabled = true);
                    sopralluogoWrapper.querySelectorAll('input, select, textarea').forEach(el => el.disabled = false);

                    btnSopr.style.borderColor = 'var(--color-primary)';
                    btnSopr.style.background = 'rgba(255,94,20,0.05)';
                    btnSopr.style.color = 'var(--color-primary)';
                    
                    btnPrev.style.borderColor = '#ddd';
                    btnPrev.style.background = '#fff';
                    btnPrev.style.color = '#555';
                }
            };

            // Sopralluogo dedicated submission flow
            const btnSubmitSopralluogo = document.getElementById('btn-submit-sopralluogo');
            if (btnSubmitSopralluogo) {
                btnSubmitSopralluogo.addEventListener('click', function() {
                    const sopEmail = document.querySelector('#sopralluogo-wrapper input[name="email"]:not([disabled])');
                    const sopTel = document.querySelector('#sopralluogo-wrapper input[name="telefono"]:not([disabled])');
                    let valid = true;
                    let errorMsg = "Compila tutti i campi obbligatori con l'asterisco per procedere.";

                    if (sopEmail && (!sopEmail.value.trim() || !validateEmail(sopEmail.value))) {
                        valid = false;
                        sopEmail.style.borderColor = 'red';
                        errorMsg = "Inserisci un indirizzo email valido.";
                    } else if (sopEmail) { sopEmail.style.borderColor = '#ddd'; }

                    if (sopTel && (!sopTel.value.trim() || !validatePhone(sopTel.value))) {
                        valid = false;
                        sopTel.style.borderColor = 'red';
                        errorMsg = "Inserisci un numero di cellulare valido.";
                    } else if (sopTel) { sopTel.style.borderColor = '#ddd'; }

                    if (valid) {
                        if (typeof submitFormWithRecaptcha === 'function') {
                            submitFormWithRecaptcha('multistep-form');
                        } else {
                            document.getElementById('multistep-form').submit();
                        }
                    } else {
                        alert(errorMsg);
                    }
                });
            }

            document.querySelectorAll('.btn-next').forEach(btn => {
                btn.addEventListener('click', () => {
                    let valid = true;
                    let errorMsg = "Compila tutti i campi obbligatori con l'asterisco per procedere.";
                    
                    const inputs = steps[currentStep].querySelectorAll('[required]');
                    inputs.forEach(input => {
                        let isInputValid = true;
                        
                        if(!input.value.trim()) {
                            isInputValid = false;
                        } else {
                            // Specific validation rules based on type/name
                            if(input.type === 'email' && !validateEmail(input.value)) {
                                isInputValid = false;
                                errorMsg = "Inserisci un indirizzo email valido (es. nome@dominio.ch).";
                            }
                            if(input.type === 'tel' && !validatePhone(input.value)) {
                                isInputValid = false;
                                errorMsg = "Inserisci un numero di cellulare valido (solo numeri e/o '+').";
                            }
                        }
                        
                        if(!isInputValid) {
                            valid = false;
                            input.style.borderColor = 'red';
                        } else {
                            input.style.borderColor = '#ddd';
                        }
                    });

                    if (valid && currentStep < steps.length - 1) {
                        currentStep++;
                        updateWizard();
                        window.scrollTo({top: document.querySelector('.wizard-container').offsetTop - 30, behavior: 'smooth'});
                    } else if (!valid) {
                        alert(errorMsg);
                    }
                });
            });

            document.querySelectorAll('.btn-prev').forEach(btn => {
                btn.addEventListener('click', () => {
                    if (currentStep > 0) {
                        currentStep--;
                        updateWizard();
                        window.scrollTo({top: document.querySelector('.wizard-container').offsetTop - 30, behavior: 'smooth'});
                    }
                });
            });
            
            // Re-validate instantly on typing
            document.querySelectorAll('input, select').forEach(input => {
                input.addEventListener('input', function() {
                    if (this.style.borderColor === 'red') {
                         this.style.borderColor = '#ddd';
                    }
                });
            });
            
            // Add dynamic row to tables
            document.querySelectorAll('.btn-add-row').forEach(btn => {
                btn.addEventListener('click', function() {
                    const roomIdx = this.getAttribute('data-room-idx');
                    // Find the table within this section
                    const tbody = this.closest('.inventory-room').querySelector('tbody');
                    const rowCount = tbody.querySelectorAll('tr').length;
                    // Use rowCount as index for new inputs to prevent name collision
                    const i = rowCount;
                    
                    const newRow = document.createElement('tr');
                    newRow.innerHTML = `
                        <td style="padding: 8px; border: 1px solid #ddd;"><input type="number" name="inv_${roomIdx}_q_${i}" class="form-control" style="padding: 10px; width: 100%; border:1px solid #ccc; font-size:0.95rem;"></td>
                        <td style="padding: 8px; border: 1px solid #ddd;"><input type="text" name="inv_${roomIdx}_obj_${i}" class="form-control" style="padding: 10px; width: 100%; border:1px solid #ccc; font-size:0.95rem;"></td>
                        <td style="padding: 8px; border: 1px solid #ddd;"><input type="text" name="inv_${roomIdx}_car_${i}" class="form-control" style="padding: 10px; width: 100%; border:1px solid #ccc; font-size:0.95rem;" placeholder="es. Smontare, Fragile"></td>
                        <td style="padding: 8px; border: 1px solid #ddd;"><input type="text" name="inv_${roomIdx}_com_${i}" class="form-control" style="padding: 10px; width: 100%; border:1px solid #ccc; font-size:0.95rem;"></td>
                    `;
                    tbody.appendChild(newRow);
                });
            });

            updateWizard();
        });
    </script>
</main>

<script>
// Codice univoco per ogni invio (evita richieste doppie) e blocco del doppio clic
document.addEventListener('DOMContentLoaded', function () {
    const form = document.getElementById('multistep-form');
    if (!form) return;

    const tokenField = document.getElementById('form-token');
    if (tokenField) {
        let token = '';
        if (window.crypto && typeof window.crypto.randomUUID === 'function') {
            token = window.crypto.randomUUID();
        } else if (window.crypto && window.crypto.getRandomValues) {
            const b = window.crypto.getRandomValues(new Uint8Array(16));
            b[6] = (b[6] & 0x0f) | 0x40;
            b[8] = (b[8] & 0x3f) | 0x80;
            const h = Array.from(b, x => x.toString(16).padStart(2, '0')).join('');
            token = h.slice(0, 8) + '-' + h.slice(8, 12) + '-' + h.slice(12, 16) + '-' + h.slice(16, 20) + '-' + h.slice(20);
        }
        tokenField.value = token;
    }

    let sent = false;
    const lockButtons = function () {
        form.querySelectorAll('button[type="submit"], .btn-submit, #btn-submit-sopralluogo').forEach(function (b) {
            b.disabled = true;
            b.style.opacity = '0.6';
        });
    };

    // Invio da codice (sopralluogo, reCAPTCHA): una sola volta
    const nativeSubmit = HTMLFormElement.prototype.submit;
    form.submit = function () {
        if (sent) return;
        sent = true;
        lockButtons();
        nativeSubmit.call(form);
    };

    // Invio normale: se è già partito, il secondo clic viene ignorato
    form.addEventListener('submit', function (e) {
        if (sent) { e.preventDefault(); e.stopImmediatePropagation(); return; }
        setTimeout(function () {
            if (!e.defaultPrevented) { sent = true; lockButtons(); }
        }, 0);
    }, true);
});
</script>

<?php 
// Inject reCAPTCHA JS and logic if configured
$recaptcha_site = get_option('ticinoweb_recaptcha_site_key');
if (!empty($recaptcha_site)) :
?>
<script src="https://www.google.com/recaptcha/api.js?render=<?php echo esc_attr($recaptcha_site); ?>"></script>
<script>
    function submitFormWithRecaptcha(formId) {
        const form = document.getElementById(formId);
        if (!form) return;
        
        if (typeof grecaptcha !== 'undefined') {
            grecaptcha.ready(function() {
                grecaptcha.execute('<?php echo esc_js($recaptcha_site); ?>', {action: 'richiedi_preventivo'}).then(function(token) {
                    let recaptchaInput = form.querySelector('input[name="g-recaptcha-response"]');
                    if (!recaptchaInput) {
                        recaptchaInput = document.createElement('input');
                        recaptchaInput.type = 'hidden';
                        recaptchaInput.name = 'g-recaptcha-response';
                        form.appendChild(recaptchaInput);
                    }
                    recaptchaInput.value = token;
                    form.submit();
                });
            });
        } else {
            form.submit();
        }
    }

    document.addEventListener('DOMContentLoaded', function() {
        const form = document.getElementById('multistep-form');
        if (form) {
            form.addEventListener('submit', function(e) {
                // If it doesn't have the token yet, prevent submit and get token
                if (!form.querySelector('input[name="g-recaptcha-response"]')) {
                    e.preventDefault();
                    submitFormWithRecaptcha('multistep-form');
                }
            });
        }
    });
</script>
<?php endif; ?>

<?php get_footer(); ?>
