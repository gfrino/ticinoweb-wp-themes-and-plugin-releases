<?php
/**
 * Template Name: Landing Traslochi Bellinzona
 *
 * Landing page per la campagna Google Ads «traslochi Bellinzona».
 * I pulsanti portano al modulo di «Richiedi il tuo preventivo».
 */

get_header();

$contact_info = function_exists( 'ticinoweb_get_contact_info' ) ? ticinoweb_get_contact_info() : array();
$phone        = ! empty( $contact_info['phone'] ) ? $contact_info['phone'] : '+41 79 852 25 53';
$phone_href   = 'tel:' . preg_replace( '/[^+0-9]/', '', $phone );
$quote_url    = home_url( '/richiedi-il-tuo-preventivo/' );
$uploads      = wp_make_link_relative( wp_upload_dir()['baseurl'] ) . '/2026/03/';

$servizi = array(
    array( 'Traslochi per privati', 'Devi cambiare casa o appartamento? Ci occupiamo del trasporto dei tuoi mobili e dei tuoi effetti personali, prestando la massima attenzione durante ogni fase del trasloco.' ),
    array( 'Traslochi per aziende e uffici', 'Organizziamo traslochi di uffici e locali commerciali, con un servizio efficiente e attento alle necessità della tua attività.' ),
    array( 'Trasporto mobili e oggetti', 'Hai bisogno di trasportare uno o più mobili, oggetti voluminosi o attrezzature? Offriamo soluzioni anche per piccoli traslochi e trasporti individuali.' ),
    array( 'Sgomberi di appartamenti e locali', 'Ci occupiamo dello sgombero di appartamenti, cantine, uffici e locali commerciali, con il corretto smaltimento dei materiali.' ),
    array( 'Noleggio autoscala per traslochi', 'Per traslochi ai piani superiori o in edifici con accessi difficili, disponiamo di attrezzature professionali e autoscale che facilitano lo spostamento di mobili e oggetti ingombranti.' ),
);

$vantaggi = array(
    array( 'Sede a Bellinzona', 'Siamo un\'impresa del territorio, con sede in Via Galbisio 23, e operiamo in tutto il Ticino.' ),
    array( 'Esperienza e professionalità', 'Affrontiamo ogni trasloco con attenzione, precisione e cura dei beni trasportati.' ),
    array( 'Attrezzature adeguate', 'Disponiamo di mezzi e attrezzature professionali per gestire anche traslochi complessi.' ),
    array( 'Servizio personalizzato', 'Ogni trasloco è diverso. Valutiamo le tue necessità per proporti una soluzione adatta.' ),
    array( 'Preventivo gratuito e senza impegno', 'Contattaci per ricevere una valutazione del tuo trasloco, senza alcun impegno.' ),
);

$passi = array(
    array( 'Contattaci', 'Raccontaci dove devi traslocare, cosa devi trasportare e quando vorresti effettuare il trasloco.' ),
    array( 'Ricevi un preventivo gratuito', 'Valutiamo le tue esigenze e, se necessario, organizziamo un sopralluogo gratuito per definire il lavoro.' ),
    array( 'Affidaci il tuo trasloco', 'Il nostro team si occupa delle operazioni concordate, utilizzando mezzi e attrezzature adatti alle tue necessità.' ),
);

?>

<main id="primary" class="site-main page-landing-bellinzona">

    <section class="lp-hero" style="background-image: linear-gradient(135deg, rgba(17,24,39,.88), rgba(17,24,39,.68)), url('<?php echo esc_url( $uploads . 'primo-sfondo-home.jpg' ); ?>');">
        <div class="container lp-hero-grid">
            <div class="lp-hero-text">
                <h1>Traslochi a Bellinzona – Affidati a Morabito Traslochi</h1>
                <p class="lp-lead">La tua impresa di traslochi a Bellinzona per privati e aziende.</p>
                <p>Devi traslocare a Bellinzona o nei dintorni? Morabito Traslochi ti offre un servizio professionale, rapido e organizzato per trasportare mobili e oggetti con la massima attenzione.</p>
                <p>Con sede a Bellinzona, siamo il partner ideale per organizzare il tuo trasloco in tutta tranquillità, che si tratti di un appartamento, una casa o un ufficio.</p>
                <div class="lp-cta">
                    <a class="btn btn-primary btn-large" href="<?php echo esc_url( $quote_url ); ?>">Richiedi un preventivo gratuito</a>
                    <a class="btn btn-outline btn-large" href="<?php echo esc_attr( $phone_href ); ?>">Chiama <?php echo esc_html( $phone ); ?></a>
                </div>
            </div>
        </div>
    </section>

    <section class="lp-section">
        <div class="container lp-narrow">
            <h2>La tua ditta di traslochi a Bellinzona</h2>
            <p>Organizzare un trasloco richiede tempo, attenzione e una buona pianificazione. Con Morabito Traslochi puoi affidarti a professionisti esperti, pronti a gestire ogni spostamento con cura e precisione.</p>
            <p>Operiamo a Bellinzona e in tutto il Canton Ticino, offrendo soluzioni adatte alle esigenze di privati e aziende. Dai piccoli trasporti ai traslochi completi, mettiamo a disposizione personale qualificato e attrezzature professionali per rendere ogni operazione più semplice e sicura.</p>
        </div>
    </section>

    <section class="lp-section lp-section-alt">
        <div class="container">
            <h2>I nostri servizi di trasloco a Bellinzona</h2>
            <div class="lp-cards">
                <?php foreach ( $servizi as $s ) : ?>
                    <article class="lp-card">
                        <h3><?php echo esc_html( $s[0] ); ?></h3>
                        <p><?php echo esc_html( $s[1] ); ?></p>
                    </article>
                <?php endforeach; ?>
                <figure class="lp-card lp-card-photo">
                    <img src="<?php echo esc_url( $uploads . 'imgi_11_elevatore_4.jpg' ); ?>" alt="Autoscala di Morabito Traslochi montata davanti a una casa" loading="lazy" width="500" height="356">
                </figure>
            </div>
            <p class="lp-center"><a class="btn btn-primary btn-large" href="<?php echo esc_url( $quote_url ); ?>">Richiedi un preventivo senza impegno</a></p>
        </div>
    </section>

    <section class="lp-section">
        <div class="container">
            <h2>Perché scegliere Morabito Traslochi a Bellinzona?</h2>
            <ul class="lp-benefits">
                <?php foreach ( $vantaggi as $v ) : ?>
                    <li><strong><?php echo esc_html( $v[0] ); ?></strong> <?php echo esc_html( $v[1] ); ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    </section>

    <section class="lp-section lp-section-alt">
        <div class="container lp-narrow">
            <h2>Traslochi a Bellinzona e in tutto il Ticino</h2>
            <p>Morabito Traslochi ha sede a Bellinzona e offre servizi di trasloco e trasporto in tutto il Canton Ticino.</p>
            <p>Che tu debba trasferirti all'interno di Bellinzona, raggiungere un'altra località del cantone o organizzare un trasloco verso la nostra regione, puoi contare su un servizio professionale e organizzato.</p>
        </div>
    </section>

    <section class="lp-section">
        <div class="container">
            <h2>Come organizzare il tuo trasloco?</h2>
            <ol class="lp-steps">
                <?php foreach ( $passi as $p ) : ?>
                    <li><strong><?php echo esc_html( $p[0] ); ?></strong><span><?php echo esc_html( $p[1] ); ?></span></li>
                <?php endforeach; ?>
            </ol>
        </div>
    </section>

    <section class="lp-section lp-final">
        <div class="container lp-final-grid">
            <div>
                <h2>Richiedi un preventivo per il tuo trasloco a Bellinzona</h2>
                <p>Stai organizzando un trasloco e cerchi una ditta affidabile a Bellinzona?</p>
                <p>Contatta Morabito Traslochi per ricevere informazioni e un preventivo gratuito, personalizzato e senza impegno.</p>
                <address>
                    <strong>Morabito Traslochi – Ticino Transporter Sagl</strong><br>
                    Via Galbisio 23, 6500 Bellinzona<br>
                    Tel. <a href="<?php echo esc_attr( $phone_href ); ?>"><?php echo esc_html( $phone ); ?></a>
                </address>
                <p class="lp-cta"><a class="btn btn-primary btn-large" href="<?php echo esc_url( $quote_url ); ?>">Richiedi il tuo preventivo gratuito</a> <a class="btn btn-outline btn-large lp-call" href="<?php echo esc_attr( $phone_href ); ?>">Chiamaci ora</a></p>
            </div>
        </div>
    </section>

</main>

<?php get_footer(); ?>
