<?php
/** Page presentation; team registration and galleries are owned by the parent CMS. */
defined('ABSPATH') || exit;

function qz_about_id(){return absint(((array)get_option('ticinoweb_page_mapping',[]))['page_chi_siamo']??0);}
function qz_is_about(){
    $id=absint(apply_filters('wpml_object_id',qz_about_id(),'page',true));
    return $id&&is_page($id);
}
function qz_about_data(){return (array)get_post_meta(qz_about_id(),'_qz_about',true);}
function qz_about_text($key){
    $value=(string)(qz_about_data()[$key]??'');
    return function_exists('ticinoweb_frontend_text')?ticinoweb_frontend_text($value,'qz:about:'.$key):$value;
}
add_filter('template_include',static function($template){return qz_is_about()?get_stylesheet_directory().'/page-chi-siamo.php':$template;});

function qz_about_fields(){return [
    'team_title'=>__('Titolo del team','qualazampa'),
    'team_text'=>__('Introduzione del team','qualazampa'),
    'loyalty_title'=>__('Titolo tessera fedeltà','qualazampa'),
    'loyalty_text'=>__('Come funziona la tessera','qualazampa'),
    'gallery_title'=>__('Titolo galleria','qualazampa'),
    'gallery_text'=>__('Introduzione galleria','qualazampa'),
];}
function qz_about_gallery(){
    $term=absint(qz_about_data()['gallery_id']??0);
    if(!$term||!term_exists($term,'ticinoweb_media_gallery'))return [];
    $order=array_values(array_filter(array_map('absint',(array)get_term_meta($term,'_ticinoweb_gallery_order',true))));
    $ids=get_posts(['post_type'=>'attachment','post_status'=>'inherit','post_mime_type'=>'image','fields'=>'ids','posts_per_page'=>24,'orderby'=>'ID','order'=>'ASC','no_found_rows'=>true,'tax_query'=>[['taxonomy'=>'ticinoweb_media_gallery','field'=>'term_id','terms'=>$term]]]);
    $rank=array_flip($order);
    usort($ids,static fn($a,$b)=>($rank[$a]??100000+$a)<=>($rank[$b]??100000+$b));
    return $ids;
}
function qz_about_team(){return post_type_exists('qz_team')?get_posts(['post_type'=>'qz_team','posts_per_page'=>12,'post_status'=>'publish','orderby'=>['menu_order'=>'ASC','ID'=>'ASC'],'no_found_rows'=>true]):[];}

add_action('init',static function(){
    if(!post_type_exists('qz_team'))return;
    remove_post_type_support('qz_team','editor');
    remove_post_type_support('qz_team','custom-fields');
},20);
add_action('add_meta_boxes_qz_team',static function(){
    remove_meta_box('postexcerpt','qz_team','normal');
    add_meta_box('postexcerpt',__('Breve presentazione (facoltativa)','qualazampa'),'post_excerpt_meta_box','qz_team','normal','high');
    add_meta_box('qz-team-guide',__('La persona nella pagina Chi siamo','qualazampa'),static function(){
        echo '<p>'.esc_html__('Scegli la foto in evidenza e usa il titolo per riconoscere la persona. Compilando la breve presentazione, anche il titolo e il testo compariranno sotto la foto. Lasciandola vuota, viene mostrato soltanto il ritratto. Il campo Ordinamento stabilisce la posizione: prima i numeri più piccoli.','qualazampa').'</p>';
    },'qz_team','normal','high');
});

// Keep the parent's configurable CPT as the sole team owner; this only places its editor in the CMS.
add_action('admin_menu',static function(){
    if(post_type_exists('qz_team')){
        remove_menu_page('edit.php?post_type=qz_team');
        add_submenu_page('ticinoweb-cms',__('Il team','qualazampa'),__('Il team','qualazampa'),'edit_posts','edit.php?post_type=qz_team');
    }
    if(qz_about_id())add_submenu_page('ticinoweb-cms',__('Pagina Chi siamo','qualazampa'),__('Pagina Chi siamo','qualazampa'),'edit_pages','post.php?post='.qz_about_id().'&action=edit');
},100);
add_filter('parent_file',static function($parent){global $typenow;return $typenow==='qz_team'?'ticinoweb-cms':$parent;});
add_filter('manage_qz_team_posts_columns',static function($columns){$columns['qz_portrait']=__('Foto','qualazampa');return $columns;});
add_action('manage_qz_team_posts_custom_column',static function($column,$id){if($column==='qz_portrait')echo get_the_post_thumbnail($id,[64,80]);},10,2);
add_action('add_meta_boxes_page',static function($post){if((int)$post->ID===qz_about_id())add_meta_box('qz-about',__('La pagina Chi siamo','qualazampa'),'qz_about_metabox','page','normal','high');});
function qz_about_metabox($post){
    $data=qz_about_data();wp_nonce_field('qz_save_about','qz_about_nonce');
    echo '<p>'.esc_html__('Titolo, introduzione e fotografia iniziali: ticinoWEB CMS → Chi siamo. Il testo della pagina racconta la storia. Per le persone usa ticinoWEB CMS → Il team: foto in evidenza, nome, descrizione breve e ordinamento.','qualazampa').'</p>';
    foreach(qz_about_fields() as $key=>$label){
        echo '<p><label><strong>'.esc_html($label).'</strong><br><textarea name="qz_about['.esc_attr($key).']" class="large-text" rows="2">'.esc_textarea($data[$key]??'').'</textarea></label></p>';
    }
    foreach(['rate'=>[__('Sconto della tessera (%)','qualazampa'),100],'purchases'=>[__('Numero di acquisti','qualazampa'),1000]] as $key=>$field){
        echo '<p><label><strong>'.esc_html($field[0]).'</strong><br><input type="number" min="1" max="'.esc_attr($field[1]).'" name="qz_about['.esc_attr($key).']" value="'.esc_attr($data[$key]??'').'"></label></p>';
    }
    echo '<p><label><strong>'.esc_html__('Galleria fotografica del negozio','qualazampa').'</strong><br><select name="qz_about[gallery_id]"><option value="0">'.esc_html__('Nessuna galleria','qualazampa').'</option>';
    $terms=get_terms(['taxonomy'=>'ticinoweb_media_gallery','hide_empty'=>false]);
    if(!is_wp_error($terms))foreach($terms as $term)echo '<option value="'.esc_attr($term->term_id).'" '.selected(absint($data['gallery_id']??0),$term->term_id,false).'>'.esc_html($term->name).'</option>';
    echo '</select></label></p><p><a href="'.esc_url(admin_url('upload.php?page=ticinoweb-media-galleries-manager')).'">'.esc_html__('Gestisci foto e ordine nella galleria del CMS','qualazampa').'</a></p>';
}
function qz_sanitize_about($raw,$old){
    foreach(qz_about_fields() as $key=>$label)if(isset($raw[$key])&&is_scalar($raw[$key]))$old[$key]=sanitize_textarea_field($raw[$key]);
    foreach(['rate'=>100,'purchases'=>1000] as $key=>$max)if(isset($raw[$key])&&is_scalar($raw[$key]))$old[$key]=min($max,absint($raw[$key]));
    if(isset($raw['gallery_id'])&&is_scalar($raw['gallery_id'])){
        $id=absint($raw['gallery_id']);if(!$id||term_exists($id,'ticinoweb_media_gallery'))$old['gallery_id']=$id;
    }
    return $old;
}
add_action('save_post_page',static function($id){
    if((int)$id!==qz_about_id()||!isset($_POST['qz_about_nonce'])||!is_scalar($_POST['qz_about_nonce'])||!wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['qz_about_nonce'])),'qz_save_about')||!current_user_can('edit_post',$id)||wp_is_post_revision($id)||wp_is_post_autosave($id))return;
    if(isset($_POST['qz_about'])&&is_array($_POST['qz_about']))update_post_meta($id,'_qz_about',qz_sanitize_about(wp_unslash($_POST['qz_about']),qz_about_data()));
});
