<?php
defined('ABSPATH') || exit;
$commerce=function_exists('is_cart')&&(is_cart()||is_checkout());
$scope=$commerce?' qz-commerce '.(is_cart()?'qz-commerce--cart':'qz-commerce--checkout'):'';
get_header();
?>
<main id="main-content" class="qz-page qz-container qz-section<?php echo esc_attr($scope); ?>">
    <?php while(have_posts()):the_post(); ?>
    <h1><?php the_title(); ?></h1>
    <div class="<?php echo $commerce?'qz-commerce__content':'qz-prose'; ?>"><?php the_content(); ?></div>
    <?php endwhile; ?>
</main>
<?php get_footer(); ?>
