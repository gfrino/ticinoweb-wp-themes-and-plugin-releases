/**
 * Gotthard Resin: le finiture come materiali veri. Ogni campione è disegnato in WebGL con la sua foto e la sua mappa
 * (rilievo nei canali rosso e verde, lucentezza nel blu): la luce segue il puntatore, la card si inclina in 3D e i
 * riflessi nascono dal rilievo del materiale. Si disegna solo mentre qualcosa si muove.
 * Senza WebGL resta la foto con l'inclinazione e un riflesso in CSS; con «riduci movimento» la card non si inclina.
 */
(function () {
  'use strict';
  var carte = Array.prototype.slice.call(document.querySelectorAll('[data-gtr-materiale]'));
  if (!carte.length) return;
  var ridotto = window.matchMedia('(prefers-reduced-motion: reduce)');

  var VS = 'attribute vec2 p;varying vec2 uv;void main(){uv=vec2(p.x*.5+.5,.5-p.y*.5);gl_Position=vec4(p,0.,1.);}';
  var FS = [
    'precision mediump float;varying vec2 uv;',
    'uniform sampler2D colore,mappa;uniform float haMappa,metallo,lucido;uniform vec2 luce,incl;',
    // Ambiente di studio che segue la luce: una grande finestra luminosa nella direzione del puntatore, pareti scure.
    'vec3 ambiente(vec3 r,vec3 dirLuce){float t=r.y*.5+.5;vec3 c=mix(vec3(.10,.095,.09),vec3(.55,.54,.52),smoothstep(0.,1.,t));',
    'c+=vec3(1.15)*smoothstep(.80,.97,dot(r,dirLuce));c+=vec3(.4)*smoothstep(.5,.95,dot(r,dirLuce));return c;}',
    'void main(){',
    ' vec3 base=pow(texture2D(colore,uv).rgb,vec3(2.2));',
    ' vec3 m=haMappa>.5?texture2D(mappa,uv).rgb:vec3(.5,.5,.55);',
    ' vec3 n=vec3((m.r*2.-1.)*1.6,(m.g*2.-1.)*1.6,1.);n=normalize(n+vec3(incl,0.));',
    ' float rough=clamp(m.b*(1.-lucido),.10,1.);',
    // Ogni punto della card ha la sua posizione: luce puntiforme davanti alla card, sotto il puntatore; fotocamera vicina.
    ' vec3 P=vec3(uv.x*2.-1.,1.-uv.y*2.,0.);',
    ' vec3 Lp=vec3(luce*1.1,1.15);vec3 L=normalize(Lp-P);float dist=length(Lp-P);',
    ' vec3 V=normalize(vec3(0.,0.,3.2)-P);vec3 H=normalize(L+V);',
    ' float ndl=max(dot(n,L),0.),ndh=max(dot(n,H),0.),vdh=max(dot(V,H),0.),ndv=max(dot(n,V),.001);',
    ' float a=rough*rough,a2=a*a,d=ndh*ndh*(a2-1.)+1.,D=a2/(3.14159*d*d);',
    ' vec3 F0=mix(vec3(.04),base,metallo);vec3 F=F0+(1.-F0)*pow(1.-vdh,5.);',
    ' float atten=1.15/(.6+dist*dist);',
    ' vec3 R=reflect(-V,n);vec3 Fr=F0+(1.-F0)*pow(1.-ndv,5.);',
    ' vec3 env=ambiente(R,normalize(vec3(luce*.9,1.)))*Fr*mix(1.,.15,rough);',
    ' vec3 diff=(1.-metallo)*base*(.30+1.05*ndl*atten);',
    ' vec3 spec=D*F*ndl*atten*.32;',
    ' vec3 col=diff+spec+env*mix(.55,.9,metallo)+base*metallo*.16;',
    ' col=col/(col+vec3(.8))*1.38;col=pow(col,vec3(1./2.2));',
    ' gl_FragColor=vec4(col,1.);}'
  ].join('\n');

  function compila(gl, tipo, src) {
    var s = gl.createShader(tipo);
    gl.shaderSource(s, src);
    gl.compileShader(s);
    return gl.getShaderParameter(s, gl.COMPILE_STATUS) ? s : null;
  }
  function carica(url) {
    return new Promise(function (ok, no) {
      var im = new Image();
      im.decoding = 'async';
      im.onload = function () { ok(im); };
      im.onerror = no;
      im.src = url;
    });
  }

  function prepara(box) {
    var img = box.querySelector('img');
    var stato = { rx: 0, ry: 0, lx: -0.45, ly: 0.55, trx: 0, try_: 0, tlx: -0.45, tly: 0.55, alza: 0, talza: 0 };
    var disegna = null;
    var giro = 0;

    function passo() {
      var k = 0.14;
      stato.rx += (stato.trx - stato.rx) * k;
      stato.ry += (stato.try_ - stato.ry) * k;
      stato.lx += (stato.tlx - stato.lx) * k;
      stato.ly += (stato.tly - stato.ly) * k;
      stato.alza += (stato.talza - stato.alza) * k;
      box.style.setProperty('--gtr-rx', stato.rx.toFixed(2) + 'deg');
      box.style.setProperty('--gtr-ry', stato.ry.toFixed(2) + 'deg');
      box.style.setProperty('--gtr-alza', stato.alza.toFixed(3));
      box.style.setProperty('--gtr-mx', (50 + stato.lx * 45).toFixed(1) + '%');
      box.style.setProperty('--gtr-my', (50 - stato.ly * 45).toFixed(1) + '%');
      if (disegna) disegna();
      var fermo = Math.abs(stato.trx - stato.rx) + Math.abs(stato.try_ - stato.ry) + Math.abs(stato.tlx - stato.lx) + Math.abs(stato.tly - stato.ly) + Math.abs(stato.talza - stato.alza) < 0.002;
      giro = fermo ? 0 : window.requestAnimationFrame(passo);
    }
    function muovi() { if (!giro) giro = window.requestAnimationFrame(passo); }

    // La prima volta che la card compare, la luce le scorre sopra da sola: si capisce che il campione è vivo.
    box.gtrPassata = function (ritardo) {
      if (ridotto.matches || box.matches(':hover')) return;
      window.setTimeout(function () {
        var t0 = null, durata = 1400;
        function fase(t) {
          if (box.matches(':hover')) return;
          if (t0 === null) t0 = t;
          var k = Math.min(1, (t - t0) / durata), e = k < .5 ? 2 * k * k : 1 - Math.pow(-2 * k + 2, 2) / 2;
          stato.tlx = stato.lx = -1.1 + 2.2 * e;
          stato.tly = stato.ly = 0.75 - 0.6 * e;
          stato.trx = stato.rx = 0; stato.try_ = stato.ry = (e - 0.5) * 6;
          if (disegna) disegna();
          box.style.setProperty('--gtr-ry', stato.ry.toFixed(2) + 'deg');
          box.style.setProperty('--gtr-mx', (50 + stato.lx * 45).toFixed(1) + '%');
          box.style.setProperty('--gtr-my', (50 - stato.ly * 45).toFixed(1) + '%');
          if (k < 1) window.requestAnimationFrame(fase);
          else { stato.tlx = -0.45; stato.tly = 0.55; stato.try_ = 0; muovi(); }
        }
        window.requestAnimationFrame(fase);
      }, ritardo);
    };

    box.addEventListener('pointermove', function (e) {
      var r = box.getBoundingClientRect();
      var px = (e.clientX - r.left) / r.width, py = (e.clientY - r.top) / r.height;
      var inclina = ridotto.matches ? 0 : 1;
      stato.trx = (0.5 - py) * 14 * inclina;
      stato.try_ = (px - 0.5) * 16 * inclina;
      stato.tlx = (px * 2 - 1) * 1.15;
      stato.tly = (1 - py * 2) * 1.15;
      stato.talza = inclina;
      muovi();
    });
    box.addEventListener('pointerleave', function () {
      stato.trx = 0; stato.try_ = 0; stato.tlx = -0.45; stato.tly = 0.55; stato.talza = 0;
      muovi();
    });

    // WebGL: solo con la mappa del materiale; altrimenti restano inclinazione e riflesso CSS.
    var urlMappa = box.getAttribute('data-gtr-mappa');
    if (!urlMappa || !img) return;
    var canvas = document.createElement('canvas');
    canvas.setAttribute('aria-hidden', 'true');
    var gl = canvas.getContext('webgl', { antialias: false, premultipliedAlpha: false, preserveDrawingBuffer: false });
    if (!gl) return;
    var vs = compila(gl, gl.VERTEX_SHADER, VS), fs = compila(gl, gl.FRAGMENT_SHADER, FS);
    if (!vs || !fs) return;
    var prog = gl.createProgram();
    gl.attachShader(prog, vs);
    gl.attachShader(prog, fs);
    gl.linkProgram(prog);
    if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) return;
    gl.useProgram(prog);
    var buf = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, buf);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 1, -1, -1, 1, 1, 1]), gl.STATIC_DRAW);
    var pos = gl.getAttribLocation(prog, 'p');
    gl.enableVertexAttribArray(pos);
    gl.vertexAttribPointer(pos, 2, gl.FLOAT, false, 0, 0);
    var u = {};
    ['colore', 'mappa', 'haMappa', 'metallo', 'lucido', 'luce', 'incl'].forEach(function (n) { u[n] = gl.getUniformLocation(prog, n); });

    function texture(unita, sorgente) {
      var t = gl.createTexture();
      gl.activeTexture(gl.TEXTURE0 + unita);
      gl.bindTexture(gl.TEXTURE_2D, t);
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGB, gl.RGB, gl.UNSIGNED_BYTE, sorgente);
      var pot = (sorgente.width & (sorgente.width - 1)) === 0 && (sorgente.height & (sorgente.height - 1)) === 0;
      if (pot) { gl.generateMipmap(gl.TEXTURE_2D); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR_MIPMAP_LINEAR); }
      else gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    }
    function misura() {
      var r = box.getBoundingClientRect();
      var dpr = Math.min(window.devicePixelRatio || 1, 2);
      var w = Math.max(1, Math.round(r.width * dpr)), h = Math.max(1, Math.round(r.height * dpr));
      if (canvas.width !== w || canvas.height !== h) { canvas.width = w; canvas.height = h; gl.viewport(0, 0, w, h); }
    }

    Promise.all([carica(img.getAttribute('data-gtr-colore') || img.currentSrc || img.src), carica(urlMappa)]).then(function (im) {
      texture(0, im[0]);
      texture(1, im[1]);
      gl.uniform1i(u.colore, 0);
      gl.uniform1i(u.mappa, 1);
      gl.uniform1f(u.haMappa, 1);
      gl.uniform1f(u.metallo, parseFloat(box.getAttribute('data-gtr-metallo') || '0'));
      gl.uniform1f(u.lucido, parseFloat(box.getAttribute('data-gtr-lucido') || '0'));
      disegna = function () {
        misura();
        gl.uniform2f(u.luce, stato.lx, stato.ly);
        gl.uniform2f(u.incl, stato.ry * -0.006, stato.rx * 0.006);
        gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
      };
      box.appendChild(canvas);
      box.classList.add('ha-webgl');
      disegna();
      if (window.ResizeObserver) new ResizeObserver(function () { if (disegna) disegna(); }).observe(box);
    }).catch(function () { /* resta la foto */ });
  }

  // Si prepara quando la sezione si avvicina allo schermo (o al primo passaggio del puntatore);
  // la passata di luce parte quando le card sono davvero in vista, una dopo l'altra.
  function avvia(box) { if (!box.dataset.gtrPronto) { box.dataset.gtrPronto = '1'; prepara(box); } }
  if ('IntersectionObserver' in window) {
    var io = new IntersectionObserver(function (voci) {
      voci.forEach(function (v) { if (v.isIntersecting) { avvia(v.target); io.unobserve(v.target); } });
    }, { rootMargin: '400px 0px' });
    carte.forEach(function (c) { io.observe(c); });
    var vista = new IntersectionObserver(function (voci) {
      voci.forEach(function (v) {
        if (!v.isIntersecting) return;
        vista.unobserve(v.target);
        avvia(v.target);
        if (v.target.gtrPassata) v.target.gtrPassata(400 + carte.indexOf(v.target) * 180);
      });
    }, { threshold: 0.6 });
    carte.forEach(function (c) { vista.observe(c); });
  }
  carte.forEach(function (c) { c.addEventListener('pointerenter', function () { avvia(c); }, { once: true }); });
})();
