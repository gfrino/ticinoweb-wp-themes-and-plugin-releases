/**
 * Gotthard Resin: movimento della pagina.
 * - Lenis: scorrimento morbido su tutto il sito (anche i link alle sezioni, con lo spazio per la testata fissa).
 * - GSAP + ScrollTrigger (solo pagina iniziale): pochi movimenti con un motivo, legati allo scorrimento:
 *   intro con il logo che si apre nella hero (a ogni apertura), hero a tutto schermo che si trasforma con lo
 *   scorrimento e viene coperta dai lavori, parallasse nelle foto del cantiere, mosaico dei lavori in sequenza,
 *   campioni dei materiali che si posano.
 * Tutto è visibile senza JavaScript: gli elementi si nascondono solo qui, appena prima di animarsi.
 * Con «riduci movimento» non si attiva nulla: né scorrimento morbido né animazioni.
 */
(function () {
  'use strict';
  if (window.matchMedia('(prefers-reduced-motion: reduce)').matches || typeof window.Lenis !== 'function') return;

  var gsap = window.gsap, ST = window.ScrollTrigger;
  var testata = document.querySelector('.gtr-testata');
  var lenis = new window.Lenis({
    lerp: 0.1,
    anchors: { offset: -((testata ? testata.offsetHeight : 72) + 24) },
    autoRaf: !(gsap && ST)
  });
  window.gtrLenis = lenis;

  // Mentre il visore delle foto è aperto, la pagina sotto non scorre.
  var visore = document.querySelector('.gtr-visore');
  if (visore && window.MutationObserver) {
    new MutationObserver(function () { if (visore.open) lenis.stop(); else lenis.start(); })
      .observe(visore, { attributes: true, attributeFilter: ['open'] });
  }
  // Il pannello del menu sul telefono scorre da solo, non la pagina.
  var menu = document.getElementById('gtr-menu');
  if (menu) menu.setAttribute('data-lenis-prevent', '');

  if (!gsap || !ST) return;
  gsap.registerPlugin(ST);
  lenis.on('scroll', ST.update);
  gsap.ticker.add(function (t) { lenis.raf(t * 1000); });
  gsap.ticker.lagSmoothing(0);

  var mm = gsap.matchMedia();

  // 1. Intro con il logo (a ogni apertura della pagina iniziale, accesa dallo script nell'head) e scena della hero.
  var radice = document.documentElement;
  var hero = document.querySelector('.gtr-hero');
  var scena = document.querySelector('.gtr-scena');
  var cornice = hero && hero.querySelector('.gtr-hero__cornice');
  var foto = hero && hero.querySelector('.gtr-hero__img');
  var velo = hero && hero.querySelector('.gtr-hero__velo');
  var titolo = hero && hero.querySelector('.gtr-hero__titolo');
  var lato = hero && hero.querySelector('.gtr-hero__lato');
  var piede = hero && hero.querySelector('.gtr-hero__piede');

  // Il titolo si divide in parole, ognuna dentro la sua maschera: entrano dal basso, riga dopo riga.
  function dividi(el) {
    var testo = el.textContent.trim();
    el.setAttribute('aria-label', testo);
    el.textContent = '';
    return testo.split(/\s+/).map(function (parola, i, tutte) {
      var m = document.createElement('span'), dentro = document.createElement('span');
      m.className = 'gtr-parola'; m.setAttribute('aria-hidden', 'true');
      dentro.textContent = parola; m.appendChild(dentro); el.appendChild(m);
      if (i < tutte.length - 1) el.appendChild(document.createTextNode(' '));
      return dentro;
    });
  }

  // Scena guidata dallo scorrimento: nei primi 70svh (35 sul telefono) il titolo sale e svanisce, la foto si stringe
  // in una cornice e fa uno zoom lento; poi i lavori salgono a coprirla (CSS: hero sticky, sezione seguente sopra).
  function creaScena() {
    if (!scena || !hero || !radice.classList.contains('gtr-moto')) return;
    var corsa = function () { return Math.max(1, scena.offsetHeight - 2 * window.innerHeight); };
    var tl = gsap.timeline({ defaults: { ease: 'none' }, scrollTrigger: { trigger: scena, start: 'top top', end: function () { return '+=' + corsa(); }, scrub: true, invalidateOnRefresh: true } });
    if (titolo) tl.to(titolo, { yPercent: -22, scale: 0.92, transformOrigin: '0% 100%', autoAlpha: 0, duration: 0.8 }, 0);
    if (lato) tl.to(lato, { y: -28, autoAlpha: 0, duration: 0.45 }, 0);
    if (piede) tl.to(piede, { autoAlpha: 0, duration: 0.3 }, 0);
    // La maschera parte appena oltre i bordi (-1%): a filo esatto, sul bordo trasparirebbe il fondo chiaro come un filo bianco.
    if (cornice) tl.fromTo(cornice, { clipPath: 'inset(-1% -1% -1% -1% round 0px)' }, { clipPath: 'inset(9% 5% 9% 5% round 6px)', duration: 1 }, 0);
    if (velo) tl.to(velo, { opacity: 0.25, duration: 1 }, 0);
    // Lo zoom della foto continua per tutta la scena, anche mentre i lavori la coprono.
    if (foto) gsap.fromTo(foto, { scale: 1.02 }, { scale: 1.16, ease: 'none', immediateRender: false, scrollTrigger: { trigger: scena, start: 'top top', end: 'bottom bottom', scrub: true } });
  }

  function intro() {
    var logo = document.querySelector('.gtr-intro__logo');
    var luce = logo && logo.querySelector('.gtr-intro__luce');
    var testata = document.querySelector('.gtr-testata');
    window.gtrIntroPartita = true;
    lenis.stop();
    window.scrollTo(0, 0);
    var parole = titolo ? dividi(titolo) : [];
    if (window.gtrAdattaTitolo) window.gtrAdattaTitolo(); // due righe anche dopo la divisione in parole
    // Righe del titolo: le parole sulla stessa riga partono insieme, le righe una dopo l'altra.
    var righe = [], cima = null;
    parole.forEach(function (p) { var t = p.parentNode.offsetTop; if (t !== cima) { righe.push([]); cima = t; } righe[righe.length - 1].push(p); });

    var fine = function () {
      radice.classList.remove('gtr-con-intro');
      gsap.set([hero, testata, testata && testata.querySelector('.gtr-testata__in'), titolo, lato, piede].filter(Boolean), { clearProps: 'clipPath,opacity,visibility,transform' });
      if (testata) testata.style.removeProperty('--gtr-fascia');
      lenis.start();
      creaScena();
      ST.refresh();
      // Indirizzo con un'ancora (#lavori…): finita l'intro si scorre lì.
      if (window.location.hash.length > 1) {
        var meta = null;
        try { meta = document.querySelector(window.location.hash); } catch (e) { meta = null; }
        // Lo spazio per la testata fissa lo dà già scroll-padding-top (style.css): Lenis lo rispetta da solo.
        if (meta) lenis.scrollTo(meta);
      }
    };
    var tl = gsap.timeline({ onComplete: fine });
    var mano = document.querySelector('.gtr-intro__mano');
    if (foto) gsap.set(foto, { scale: 1.2, xPercent: -3 });
    gsap.set(parole, { yPercent: 118 });
    gsap.set([titolo], { opacity: 1 });

    if (logo) {
      // Il logo viene svelato da una maschera che scorre come una stesura; il riflesso passa solo sulla sua sagoma.
      tl.to(logo, { clipPath: 'inset(0 0% 0 0)', duration: 0.8, ease: 'power3.inOut' }, 0.15);
      if (luce) tl.to(luce, { backgroundPosition: '0% 0', duration: 1.0, ease: 'power2.inOut' }, 0.35);
      tl.fromTo(logo, { scale: 0.94 }, { scale: 1, duration: 1.1, ease: 'power2.out' }, 0.15);
    }

    // «La stesura»: lo stesso gesto da sinistra a destra attraversa lo schermo. Il bordo è inclinato (in alto è più avanti):
    // prima una mano di blu, subito dietro la foto. Il logo sparisce man mano che il bordo blu gli passa sopra.
    var INCL = 16; // quanto il bordo in alto precede quello in basso, in % della larghezza
    var bordo = function (t) { var alto = t * (100 + INCL), basso = alto - INCL; return 'polygon(0 0, ' + alto + '% 0, ' + basso + '% 100%, 0 100%)'; };
    var passata = { blu: 0, foto: 0 };
    var rettLogo = null;
    var aggiorna = function () {
      if (mano) mano.style.clipPath = bordo(passata.blu);
      hero.style.clipPath = bordo(passata.foto);
      if (logo) {
        rettLogo = rettLogo || logo.getBoundingClientRect();
        var w = window.innerWidth, h = window.innerHeight;
        var alto = passata.blu * (100 + INCL), yRel = (rettLogo.top + rettLogo.height / 2) / h;
        var xBordo = (alto - INCL * yRel) / 100 * w; // dove sta il bordo blu all'altezza del logo
        var coperto = Math.max(0, Math.min(1, (xBordo - rettLogo.left) / rettLogo.width));
        logo.style.clipPath = 'inset(0 0 0 ' + (coperto * 100).toFixed(2) + '%)';
      }
    };
    tl.to(passata, { blu: 1, duration: 0.95, ease: 'power3.inOut', onUpdate: aggiorna }, 1.15);
    tl.to(passata, { foto: 1, duration: 1.0, ease: 'power3.inOut', onUpdate: aggiorna }, 1.33);
    if (foto) tl.to(foto, { scale: 1.02, xPercent: 0, duration: 1.6, ease: 'power3.out' }, 1.33);
    // La testata scende e compare insieme alla prima riga del titolo.
    if (testata) {
      var dentro = testata.querySelector('.gtr-testata__in');
      if (dentro) tl.fromTo(dentro, { opacity: 0, y: -18 }, { opacity: 1, y: 0, duration: 0.9, ease: 'power3.out' }, 1.95);
      // La fascia scura sfocata cresce insieme, con la sua opacità (variabile letta dal CSS).
      tl.fromTo(testata, { '--gtr-fascia': 0 }, { '--gtr-fascia': 1, duration: 0.9, ease: 'power2.out' }, 1.95);
    }
    // Il titolo entra riga per riga, poi testo, azioni e piede.
    righe.forEach(function (riga, i) { tl.to(riga, { yPercent: 0, duration: 1.0, ease: 'power4.out' }, 1.95 + i * 0.12); });
    if (lato) tl.fromTo(lato, { opacity: 0, y: 18 }, { opacity: 1, y: 0, duration: 0.8, ease: 'power3.out' }, 2.3);
    if (piede) tl.fromTo(piede, { opacity: 0 }, { opacity: 1, duration: 0.8, ease: 'power2.out' }, 2.5);
  }

  if (hero) {
    if (radice.classList.contains('gtr-con-intro')) {
      // Si parte quando logo e foto sono pronti, ma senza aspettare più di 1,2 secondi.
      var attese = [foto, document.querySelector('.gtr-intro__logo img')].filter(Boolean).map(function (im) {
        return im.complete ? Promise.resolve() : new Promise(function (ok) { im.addEventListener('load', ok, { once: true }); im.addEventListener('error', ok, { once: true }); });
      });
      window.gtrIntroPartita = true;
      Promise.race([Promise.all(attese), new Promise(function (ok) { window.setTimeout(ok, 1200); })]).then(intro);
    } else {
      creaScena();
    }
  }

  // Parallasse della foto dietro la richiesta di preventivo: scorre più lenta della pagina.
  var sfondoContatto = document.querySelector('.gtr-contatto__sfondo');
  if (sfondoContatto) {
    gsap.fromTo(sfondoContatto, { yPercent: -8 }, { yPercent: 8, ease: 'none',
      scrollTrigger: { trigger: sfondoContatto.parentElement, start: 'top bottom', end: 'bottom top', scrub: true } });
  }

  // Parallasse leggera nelle foto del cantiere (da tablet in su).
  mm.add('(min-width: 600px)', function () {
    gsap.utils.toArray('.gtr-cantiere .gtr-foto > img').forEach(function (img) {
      gsap.fromTo(img, { yPercent: -5, scale: 1.12 }, {
        yPercent: 5, scale: 1.12, ease: 'none',
        scrollTrigger: { trigger: img.closest('.gtr-foto'), start: 'top bottom', end: 'bottom top', scrub: true }
      });
    });
  });

  // 2. Il mosaico dei lavori entra in sequenza quando arriva in vista (una volta sola).
  var lavori = gsap.utils.toArray('.gtr-lavori > li');
  if (lavori.length) {
    gsap.set(lavori, { opacity: 0, y: 32 });
    ST.batch(lavori, {
      start: 'top 90%',
      once: true,
      onEnter: function (gruppo) { gsap.to(gruppo, { opacity: 1, y: 0, duration: 0.9, ease: 'power3.out', stagger: 0.08, overwrite: true }); }
    });
  }

  // 3. I campioni dei materiali si posano: arrivano leggermente inclinati e si appoggiano (la card resta libera
  //    per l'inclinazione al passaggio del mouse, perché si anima il riquadro esterno).
  var campioni = gsap.utils.toArray('.gtr-finiture li');
  if (campioni.length) {
    gsap.set(campioni, { opacity: 0, y: 40, rotateX: 18, transformPerspective: 900, transformOrigin: '50% 100%' });
    ST.batch(campioni, {
      start: 'top 88%',
      once: true,
      onEnter: function (gruppo) { gsap.to(gruppo, { opacity: 1, y: 0, rotateX: 0, duration: 1.1, ease: 'power3.out', stagger: 0.1, overwrite: true }); }
    });
  }

  // Le immagini pigre cambiano l'altezza della pagina: si ricalcolano i punti di partenza quando tutto è caricato.
  window.addEventListener('load', function () { ST.refresh(); });
})();
