<?php
/**
 * Mappa della sede: la mappa di Google incorporata (senza chiave API), ricolorata nei toni del sito con un filtro CSS.
 * Si carica solo con il consenso ai cookie di marketing (cookie tw_cookie_preferences del parent) o con un clic sul
 * bottone; prima si vede il disegno SVG della valle del Ticino (posizioni da coordinate reali). Si mostra solo se nel
 * CMS c'è l'indirizzo.
 *
 * @package gotthardresin-child-theme
 */

defined('ABSPATH') || exit;

$gtr_url = gotthardresin_map_url();
if ($gtr_url === '') {
    return;
}
$gtr_zona   = gotthardresin_text('about_area');
$gtr_embed  = gotthardresin_map_embed_url();
$gtr_titolo = __('Mappa della zona di lavoro, dal San Gottardo al Lago Maggiore, con la sede a Giornico', 'gotthardresin-child-theme');
?>
<figure class="gtr-mappa">
    <?php // Mappa di Google: si carica da sola solo con il consenso ai cookie di marketing; prima si vede il disegno della valle. ?>
    <div class="gtr-mappa__cornice" data-gtr-gmappa="<?php echo esc_url($gtr_embed); ?>" data-gtr-titolo="<?php echo esc_attr__('Mappa di Google con la sede di Gotthard Resin', 'gotthardresin-child-theme'); ?>">
        <svg class="gtr-mappa__svg" viewBox="0 0 385 352" role="img" aria-labelledby="gtr-mappa-titolo">
<title id="gtr-mappa-titolo"><?php echo esc_html($gtr_titolo); ?></title>
<path class="gtr-mappa__lago" d="M174.0 275.2 C172.2 274.3 166.9 270.8 163.2 269.6 C159.5 268.4 155.1 267.4 151.6 267.9 C148.1 268.4 144.8 270.5 141.9 272.4 C139.0 274.3 138.1 275.4 134.2 279.1 C130.3 282.8 122.9 288.9 118.7 294.8 C114.5 300.7 110.0 308.8 109.0 314.4 C108.0 320.0 109.7 327.0 112.9 328.4 C116.1 329.8 122.6 327.5 128.4 322.8 C134.2 318.1 141.9 306.0 147.7 300.4 C153.5 294.8 158.7 292.0 163.2 289.2 C167.7 286.4 173.0 285.9 174.8 283.6 C176.6 281.3 174.1 276.6 174.0 275.2 Z"/>
<path class="gtr-mappa__zona" d="M78.5 66.3 C84.2 68.9 100.7 77.2 112.9 82.0 C125.1 86.8 142.6 88.4 151.9 94.9 C161.2 101.4 164.3 114.1 169.0 121.2 C173.7 128.3 174.4 132.3 180.2 137.4 C186.0 142.5 197.5 148.1 203.7 152.0 C209.9 155.9 213.8 153.1 217.3 161.0 C220.9 168.9 222.8 187.6 225.0 199.6 C227.2 211.6 229.1 224.0 230.8 233.2 C232.5 242.3 234.6 250.9 235.4 254.5"/>
<path class="gtr-mappa__fiume" d="M78.5 66.3 C84.2 68.9 100.7 77.2 112.9 82.0 C125.1 86.8 142.6 88.4 151.9 94.9 C161.2 101.4 164.3 114.1 169.0 121.2 C173.7 128.3 174.4 132.3 180.2 137.4 C186.0 142.5 197.5 148.1 203.7 152.0 C209.9 155.9 213.8 153.1 217.3 161.0 C220.9 168.9 222.8 187.6 225.0 199.6 C227.2 211.6 229.1 224.0 230.8 233.2 C232.5 242.3 240.2 248.4 235.4 254.5 C230.6 260.6 211.9 265.9 201.8 269.6 C191.7 273.3 179.3 275.7 174.8 276.9"/>
<path class="gtr-mappa__monti" d="M29.200000000000003 55.0 l12 -16 l8 9 l10 -14 l14 21"/><text class="gtr-mappa__nome gtr-mappa__nome--passo" x="75.2" y="45.0"><?php esc_html_e('Passo del San Gottardo', 'gotthardresin-child-theme'); ?></text>
<circle class="gtr-mappa__paese" cx="78.5" cy="66.3" r="3.5"/><text class="gtr-mappa__nome" x="90.5" y="71.3">Airolo</text><circle class="gtr-mappa__paese" cx="151.9" cy="94.9" r="3.5"/><text class="gtr-mappa__nome" x="163.9" y="99.9">Faido</text><circle class="gtr-mappa__paese" cx="217.3" cy="161.0" r="3.5"/><text class="gtr-mappa__nome" x="229.3" y="166.0">Biasca</text><circle class="gtr-mappa__paese" cx="235.4" cy="254.5" r="3.5"/><text class="gtr-mappa__nome" x="247.4" y="259.5">Bellinzona</text><circle class="gtr-mappa__paese" cx="149.6" cy="266.8" r="3.5"/><text class="gtr-mappa__nome" x="137.6" y="271.8" text-anchor="end">Locarno</text>
<circle class="gtr-mappa__onda" cx="180.2" cy="137.4" r="9"/>
<circle class="gtr-mappa__sede" cx="180.2" cy="137.4" r="6"/>
<text class="gtr-mappa__nome gtr-mappa__nome--sede" x="194.2" y="143.4">Giornico</text>
<text class="gtr-mappa__lago-nome" x="142" y="314"><?php esc_html_e('Lago Maggiore', 'gotthardresin-child-theme'); ?></text>
</svg>
        <div class="gtr-mappa__velo">
            <button class="gtr-mappa__carica" type="button"><?php esc_html_e('Mostra la mappa di Google', 'gotthardresin-child-theme'); ?></button>
            <p><?php esc_html_e('Caricandola, Google riceve il tuo indirizzo IP e può usare cookie.', 'gotthardresin-child-theme'); ?> <?php if (gotthardresin_privacy_url() !== '') : ?><a class="gtr-link" href="<?php echo esc_url(gotthardresin_url(gotthardresin_privacy_url(), 'url:privacy')); ?>"><?php esc_html_e('Privacy', 'gotthardresin-child-theme'); ?></a><?php endif; ?></p>
        </div>
    </div>
    <figcaption class="gtr-mappa__didascalia">
        <?php if ($gtr_zona !== '') : ?><span><?php echo esc_html($gtr_zona); ?></span><?php endif; ?>
        <a class="gtr-link" href="<?php echo esc_url($gtr_url); ?>" target="_blank" rel="noopener"><?php esc_html_e('Indicazioni stradali', 'gotthardresin-child-theme'); ?></a>
    </figcaption>
</figure>
