<?php
/**
 * Modulo «Richiedi un preventivo». Lo invia il gestore del parent (admin-ajax.php?action=ticinoweb_submit_form):
 * salvataggio in Invii Ricevuti, email all'indirizzo di ticinoWEB CMS → Contatti via SMTP, reCAPTCHA v3 se
 * configurato, honeypot e limite di invii. Lo script è assets/js/site.js; senza JavaScript il modulo non parte
 * e lo dice, con telefono ed email in alternativa.
 *
 * @package gotthardresin-child-theme
 */

defined('ABSPATH') || exit;

$gtr_contacts = gotthardresin_contacts();
$gtr_privacy  = gotthardresin_privacy_url();
?>
<form class="gtr-modulo" data-gtr-form style="--gtr-t:8; --gtr-d:6; --gtr-d-start:7" method="post" action="<?php echo esc_url(admin_url('admin-ajax.php')); ?>" novalidate>
    <input type="hidden" name="action" value="ticinoweb_submit_form">
    <input type="hidden" name="gtr_form" value="1">
    <label class="gtr-modulo__hp" aria-hidden="true"><?php esc_html_e('Non compilare questo campo', 'gotthardresin-child-theme'); ?><input type="text" name="tw_hp" tabindex="-1" autocomplete="off"></label>
    <?php $gtr_scelte = function_exists('gotthardresin_services') ? gotthardresin_services() : array(); ?>
    <?php if ($gtr_scelte) : ?>
        <?php // Pillole: cosa si vuole rifare. Non è un campo nuovo: la scelta va in testa al messaggio (assets/js/site.js). ?>
        <fieldset class="gtr-scelte">
            <legend><?php esc_html_e('Cosa vuoi rifare?', 'gotthardresin-child-theme'); ?></legend>
            <div class="gtr-scelte__lista">
                <?php foreach ($gtr_scelte as $gtr_s) :
                    $gtr_nome  = gotthardresin_t($gtr_s['title'], 'service:' . ($gtr_s['id'] ?? '') . ':title');
                    $gtr_icona = sanitize_key((string) ($gtr_s['icon'] ?? ''));
                    $gtr_icona = ($gtr_icona !== '' && function_exists('gotthardresin_icone_disponibili') && in_array($gtr_icona, gotthardresin_icone_disponibili(), true)) ? gotthardresin_icona($gtr_icona) : '';
                    ?>
                    <button class="gtr-scelta" type="button" aria-pressed="false" data-valore="<?php echo esc_attr($gtr_nome); ?>"><?php echo $gtr_icona; // phpcs:ignore WordPress.Security.EscapeOutput -- SVG del tema ?><span><?php echo esc_html($gtr_nome); ?></span></button>
                <?php endforeach; ?>
            </div>
        </fieldset>
    <?php endif; ?>
    <div class="gtr-modulo__riga">
        <div class="gtr-campo" data-field="nome"><label for="gtr-f-nome"><?php esc_html_e('Nome', 'gotthardresin-child-theme'); ?></label><input id="gtr-f-nome" name="nome" autocomplete="name" required minlength="2"></div>
        <div class="gtr-campo" data-field="telefono"><label for="gtr-f-tel"><?php esc_html_e('Telefono', 'gotthardresin-child-theme'); ?></label><input id="gtr-f-tel" name="telefono" type="tel" autocomplete="tel"></div>
    </div>
    <div class="gtr-campo" data-field="email"><label for="gtr-f-email"><?php esc_html_e('Email', 'gotthardresin-child-theme'); ?></label><input id="gtr-f-email" name="email" type="email" autocomplete="email" required></div>
    <div class="gtr-campo" data-field="messaggio"><label for="gtr-f-lavoro"><?php esc_html_e('Il lavoro e dove si trova', 'gotthardresin-child-theme'); ?></label><textarea id="gtr-f-lavoro" name="messaggio" required minlength="5" placeholder="<?php esc_attr_e('Per esempio: bagno di circa 6 m², doccia a filo pavimento, Biasca', 'gotthardresin-child-theme'); ?>"></textarea></div>
    <div><button class="gtr-bottone gtr-modulo__invia" type="submit"><span><?php esc_html_e('Invia la richiesta', 'gotthardresin-child-theme'); ?></span><svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M5 12h14M13 6l6 6-6 6"/></svg></button></div>
    <p class="gtr-nota">
        <?php esc_html_e('Ti rispondiamo per telefono o per email. I dati servono solo per il preventivo.', 'gotthardresin-child-theme'); ?>
        <?php if ($gtr_privacy !== '') : ?><a class="gtr-link" href="<?php echo esc_url(gotthardresin_url($gtr_privacy, 'url:privacy')); ?>"><?php esc_html_e('Privacy', 'gotthardresin-child-theme'); ?></a><?php endif; ?>
    </p>
    <p class="gtr-modulo__stato" role="status" aria-live="polite"></p>
    <noscript><p class="gtr-modulo__stato is-error"><?php
        echo esc_html(trim(sprintf(
            /* translators: 1: telefono, 2: email */
            __('Per inviare il modulo serve JavaScript. Puoi chiamarci al %1$s o scrivere a %2$s.', 'gotthardresin-child-theme'),
            $gtr_contacts['phone_display'],
            $gtr_contacts['email']
        )));
    ?></p></noscript>
</form>
