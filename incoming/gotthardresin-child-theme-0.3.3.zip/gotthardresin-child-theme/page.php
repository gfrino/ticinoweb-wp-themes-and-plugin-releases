<?php
/**
 * Pagina di testo (Privacy e altre): titolo e contenuto della pagina, poi la chiusura e il piè di pagina.
 *
 * @package gotthardresin-child-theme
 */

defined('ABSPATH') || exit;

get_header();
?>
<main id="gtr-main" class="gtr-pagina">
    <div class="gtr-contenitore">
        <?php while (have_posts()) : the_post(); ?>
            <article class="gtr-pagina__corpo">
                <h1><?php the_title(); ?></h1>
                <div class="gtr-prosa"><?php the_content(); ?></div>
            </article>
        <?php endwhile; ?>
    </div>
</main>
<?php
get_footer();
