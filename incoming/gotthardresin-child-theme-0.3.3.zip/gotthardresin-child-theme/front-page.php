<?php
/**
 * Pagina iniziale (skill design-con-carattere, direzione «Su misura», 16.11.2026):
 * intro con il logo e primo schermo a tutta foto, guidato dallo scorrimento · lavori (mosaico che si apre) · servizi e finiture
 * · azienda (Chi siamo del CMS, foto del cantiere, dati) · richiesta di preventivo (modulo del parent).
 * Ogni testo e foto viene dal database: una sezione senza contenuto non compare.
 *
 * @package gotthardresin-child-theme
 */

defined('ABSPATH') || exit;

get_header();

$gtr_contacts   = gotthardresin_contacts();
$gtr_cta        = __('Richiedi un preventivo', 'gotthardresin-child-theme');
$gtr_hero_title = gotthardresin_text('hero_title');
$gtr_hero_title = $gtr_hero_title !== '' ? $gtr_hero_title : get_bloginfo('name');
$gtr_hero_text  = gotthardresin_text('hero_text');
$gtr_hero_note  = gotthardresin_text('hero_note');
$gtr_hero_imgs  = array_values(array_filter(array(gotthardresin_image_id(gotthardresin_setting('hero_image', 0)))));
$gtr_works      = gotthardresin_gallery_images((string) gotthardresin_setting('works_gallery', ''), 9);
$gtr_services   = gotthardresin_services();
$gtr_finishes   = gotthardresin_gallery_images((string) gotthardresin_setting('finishes_gallery', ''), 4);
$gtr_about_title  = trim((string) get_option('ticinoweb_chi_siamo_title', ''));
$gtr_about_text   = trim((string) get_option('ticinoweb_chi_siamo_text', ''));
$gtr_about_images = gotthardresin_gallery_images((string) gotthardresin_setting('about_gallery', ''), 2);
$gtr_about_rows   = array();
if (gotthardresin_text('about_owner') !== '') {
    $gtr_about_rows[] = array(__('Titolare', 'gotthardresin-child-theme'), esc_html(gotthardresin_text('about_owner')));
}
if (gotthardresin_address_line() !== '') {
    $gtr_about_rows[] = array(__('Sede', 'gotthardresin-child-theme'), esc_html(gotthardresin_address_line()));
}
if (gotthardresin_text('about_area') !== '') {
    $gtr_about_rows[] = array(__('Zona', 'gotthardresin-child-theme'), esc_html(gotthardresin_text('about_area')));
}
if (gotthardresin_text('about_partner') !== '') {
    $gtr_partner_url  = esc_url((string) gotthardresin_setting('about_partner_url', ''));
    $gtr_partner      = esc_html(gotthardresin_text('about_partner'));
    $gtr_about_rows[] = array(__('Partner ufficiale', 'gotthardresin-child-theme'), $gtr_partner_url ? '<a class="gtr-link" href="' . $gtr_partner_url . '" target="_blank" rel="noopener">' . $gtr_partner . '</a>' : $gtr_partner);
}
$gtr_contact_title = gotthardresin_text('contact_title');
$gtr_contact_text  = gotthardresin_text('contact_text');
?>
<main id="gtr-main">

    <?php
    $gtr_hero_id   = $gtr_hero_imgs ? $gtr_hero_imgs[0] : 0;
    $gtr_intro_logo = function_exists('ticinoweb_get_site_logo') ? gotthardresin_image_id((string) ticinoweb_get_site_logo()) : 0;
    ?>
    <?php // Intro con il logo: visibile solo se lo script nell'head l'ha accesa (html.gtr-con-intro), a ogni apertura. ?>
    <?php if ($gtr_intro_logo) : ?>
        <div class="gtr-intro" aria-hidden="true">
            <span class="gtr-intro__mano"></span>
            <?php // Il riflesso è ritagliato sulla sagoma del logo (maschera = il logo stesso): la luce non tocca il rettangolo intorno. ?>
            <div class="gtr-intro__logo"><?php echo wp_get_attachment_image($gtr_intro_logo, 'medium', false, array('alt' => '', 'loading' => 'eager', 'decoding' => 'sync')); // phpcs:ignore WordPress.Security.EscapeOutput ?><span class="gtr-intro__luce" style="--gtr-sagoma: url('<?php echo esc_url((string) wp_get_attachment_image_url($gtr_intro_logo, 'medium')); ?>')"></span></div>
        </div>
    <?php endif; ?>
    <div class="gtr-scena">
        <section class="gtr-hero<?php echo $gtr_hero_id ? '' : ' gtr-hero--senza-foto'; ?>" aria-labelledby="gtr-h-hero">
            <?php if ($gtr_hero_id) : ?>
                <div class="gtr-hero__cornice">
                    <?php echo gotthardresin_image($gtr_hero_id, 'full', array('class' => 'gtr-hero__img', 'loading' => 'eager', 'fetchpriority' => 'high', 'sizes' => '100vw')); // phpcs:ignore WordPress.Security.EscapeOutput ?>
                    <div class="gtr-hero__velo"></div>
                </div>
            <?php endif; ?>
            <div class="gtr-hero__contenuto gtr-contenitore">
                <h1 class="gtr-hero__titolo" id="gtr-h-hero"><?php echo esc_html($gtr_hero_title); ?></h1>
                <div class="gtr-hero__lato">
                    <?php if ($gtr_hero_text !== '') : ?><p class="gtr-hero__testo"><?php echo esc_html($gtr_hero_text); ?></p><?php endif; ?>
                    <div class="gtr-azioni" id="gtr-azioni-hero">
                        <?php if ($gtr_works) : ?><a class="gtr-bottone gtr-bottone--chiaro" href="#lavori"><?php esc_html_e('Scopri i nostri lavori', 'gotthardresin-child-theme'); ?></a><?php endif; ?>
                        <a class="gtr-bottone gtr-bottone--vetro" href="#contatto"><?php echo esc_html($gtr_cta); ?></a>
                    </div>
                </div>
                <div class="gtr-hero__piede">
                    <?php if ($gtr_hero_note !== '') : ?><p class="gtr-hero__nota"><?php echo esc_html($gtr_hero_note); ?></p><?php endif; ?>
                    <a class="gtr-hero__scorri" href="<?php echo $gtr_works ? '#lavori' : '#contatto'; ?>"><span><?php esc_html_e('Scorri', 'gotthardresin-child-theme'); ?></span><i aria-hidden="true"></i></a>
                </div>
            </div>
        </section>
    </div>

    <?php if ($gtr_works) : ?>
        <section class="gtr-sezione gtr-sezione--alt" id="lavori" aria-labelledby="gtr-h-lavori">
            <div class="gtr-contenitore">
                <div class="gtr-sezione__testa">
                    <h2 id="gtr-h-lavori"><?php echo esc_html(gotthardresin_text('works_title') !== '' ? gotthardresin_text('works_title') : __('Lavori', 'gotthardresin-child-theme')); ?></h2>
                    <?php if (gotthardresin_text('works_text') !== '') : ?><p><?php echo esc_html(gotthardresin_text('works_text')); ?></p><?php endif; ?>
                </div>
                <ul class="gtr-lavori" role="list">
                    <?php foreach ($gtr_works as $gtr_i => $gtr_id) : ?>
                        <li><button class="gtr-foto" type="button" data-gtr-apri data-gtr-full="<?php echo esc_url((string) wp_get_attachment_image_url($gtr_id, 'large')); ?>"><?php echo gotthardresin_image($gtr_id, 'large', array('sizes' => $gtr_i === 0 ? '(max-width: 599px) 100vw, (max-width: 1023px) 66vw, 620px' : '(max-width: 599px) 50vw, (max-width: 1023px) 33vw, 300px')); // phpcs:ignore WordPress.Security.EscapeOutput ?></button></li>
                    <?php endforeach; ?>
                </ul>
                <?php if ($gtr_contacts['instagram'] !== '') : ?>
                    <p class="gtr-lavori__piede"><?php esc_html_e('Altri lavori sul nostro', 'gotthardresin-child-theme'); ?> <a class="gtr-link" href="<?php echo esc_url($gtr_contacts['instagram']); ?>" target="_blank" rel="noopener">Instagram</a>.</p>
                <?php endif; ?>
            </div>
        </section>
    <?php endif; ?>

    <?php if ($gtr_services) : ?>
        <section class="gtr-sezione" id="servizi" aria-labelledby="gtr-h-servizi">
            <div class="gtr-contenitore">
                <div class="gtr-sezione__testa">
                    <h2 id="gtr-h-servizi"><?php echo esc_html(gotthardresin_text('services_title') !== '' ? gotthardresin_text('services_title') : __('Servizi', 'gotthardresin-child-theme')); ?></h2>
                    <?php if (gotthardresin_text('services_text') !== '') : ?><p><?php echo esc_html(gotthardresin_text('services_text')); ?></p><?php endif; ?>
                </div>
                <ul class="gtr-servizi" role="list">
                    <?php foreach ($gtr_services as $gtr_service) : ?>
                        <li>
                            <?php
                            // L'icona del servizio: il campo «icona» del servizio (ticinoWEB CMS → Servizi) contiene il nome di
                            // un'icona del tema (assets/icons). Se non corrisponde a nessuna, il servizio resta senza icona.
                            $gtr_icona = sanitize_key((string) ($gtr_service['icon'] ?? ''));
                            if ($gtr_icona !== '' && in_array($gtr_icona, gotthardresin_icone_disponibili(), true)) {
                                echo '<span class="gtr-servizi__icona">' . gotthardresin_icona($gtr_icona) . '</span>'; // phpcs:ignore WordPress.Security.EscapeOutput -- SVG del tema
                            }
                            ?>
                            <h3><?php echo esc_html(gotthardresin_t($gtr_service['title'], 'service:' . ($gtr_service['id'] ?? '') . ':title')); ?></h3>
                            <?php if (!empty($gtr_service['description'])) : ?><p><?php echo esc_html(wp_strip_all_tags(gotthardresin_t($gtr_service['description'], 'service:' . ($gtr_service['id'] ?? '') . ':text'))); ?></p><?php endif; ?>
                        </li>
                    <?php endforeach; ?>
                </ul>
                <?php if ($gtr_finishes) : ?>
                    <div class="gtr-finiture">
                        <div class="gtr-finiture__testa">
                            <?php if (gotthardresin_text('finishes_title') !== '') : ?><h3 class="gtr-finiture__titolo"><?php echo esc_html(gotthardresin_text('finishes_title')); ?></h3><?php endif; ?>
                            <p class="gtr-finiture__invito"><span class="gtr-solo-mouse"><?php esc_html_e('Passa il mouse sui campioni: la luce si sposta e il materiale si inclina.', 'gotthardresin-child-theme'); ?></span><span class="gtr-solo-tocco"><?php esc_html_e('Tocca e trascina un campione: la luce si sposta e il materiale si inclina.', 'gotthardresin-child-theme'); ?></span></p>
                        </div>
                        <ul role="list">
                            <?php foreach ($gtr_finishes as $gtr_id) :
                                $gtr_name = gotthardresin_t(get_the_title($gtr_id), 'finish:' . $gtr_id . ':name');
                                $gtr_use  = (string) wp_get_attachment_caption($gtr_id);
                                ?>
                                <?php
                                $gtr_mat  = gotthardresin_material_map($gtr_id);
                                $gtr_full = (string) wp_get_attachment_image_url($gtr_id, 'full');
                                $gtr_data = ' data-gtr-materiale';
                                if ($gtr_mat) {
                                    $gtr_data .= ' data-gtr-mappa="' . esc_url($gtr_mat['mappa']) . '" data-gtr-metallo="' . esc_attr((string) $gtr_mat['metallo']) . '" data-gtr-lucido="' . esc_attr((string) $gtr_mat['lucido']) . '"';
                                }
                                ?>
                                <li><figure class="gtr-materiale">
                                    <div class="gtr-foto"<?php echo $gtr_data; // phpcs:ignore WordPress.Security.EscapeOutput -- escape sopra ?>><?php echo gotthardresin_image($gtr_id, 'large', array('sizes' => '(max-width: 599px) 50vw, (max-width: 1023px) 25vw, 300px', 'data-gtr-colore' => $gtr_full)); // phpcs:ignore WordPress.Security.EscapeOutput ?></div>
                                    <figcaption><?php echo esc_html($gtr_name); ?><?php if ($gtr_use !== '') : ?><span><?php echo esc_html(gotthardresin_t($gtr_use, 'finish:' . $gtr_id . ':use')); ?></span><?php endif; ?></figcaption>
                                </figure></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>
            </div>
        </section>
    <?php endif; ?>

    <?php if ($gtr_about_title !== '' || $gtr_about_text !== '') : ?>
        <section class="gtr-sezione" id="azienda" aria-labelledby="gtr-h-azienda">
            <div class="gtr-contenitore gtr-griglia">
                <?php if ($gtr_about_images) : ?>
                    <div class="gtr-cantiere" style="--gtr-t:8; --gtr-d:6">
                        <?php foreach ($gtr_about_images as $gtr_id) : $gtr_cap = (string) wp_get_attachment_caption($gtr_id); ?>
                            <figure>
                                <div class="gtr-foto"><?php echo gotthardresin_image($gtr_id, 'large', array('sizes' => '(max-width: 1023px) 50vw, 300px')); // phpcs:ignore WordPress.Security.EscapeOutput ?></div>
                                <?php if ($gtr_cap !== '') : ?><figcaption><?php echo esc_html(gotthardresin_t($gtr_cap, 'about:caption:' . $gtr_id)); ?></figcaption><?php endif; ?>
                            </figure>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
                <div class="gtr-azienda__testo" style="--gtr-t:8; --gtr-d:5; --gtr-d-start:<?php echo $gtr_about_images ? '8' : '1'; ?>">
                    <h2 id="gtr-h-azienda"><?php echo esc_html($gtr_about_title !== '' ? gotthardresin_t($gtr_about_title, 'about:title') : __('Azienda', 'gotthardresin-child-theme')); ?></h2>
                    <?php if ($gtr_about_text !== '') : ?><p><?php echo nl2br(esc_html(gotthardresin_t($gtr_about_text, 'about:text'))); // phpcs:ignore WordPress.Security.EscapeOutput ?></p><?php endif; ?>
                    <?php if ($gtr_about_rows) : ?>
                        <dl class="gtr-dati">
                            <?php foreach ($gtr_about_rows as $gtr_row) : ?><dt><?php echo esc_html($gtr_row[0]); ?></dt><dd><?php echo $gtr_row[1]; // phpcs:ignore WordPress.Security.EscapeOutput -- escape sopra ?></dd><?php endforeach; ?>
                        </dl>
                    <?php endif; ?>
                </div>
            </div>
        </section>
    <?php endif; ?>

    <?php
    // Sfondo della richiesta: una foto vera, appena sfocata e in parallasse (Personalizza; senza, la foto in cima).
    $gtr_sfondo = gotthardresin_image_id(gotthardresin_setting('contact_bg', 0));
    $gtr_sfondo = $gtr_sfondo ? $gtr_sfondo : ($gtr_hero_imgs ? $gtr_hero_imgs[0] : 0);
    ?>
    <section class="gtr-sezione gtr-sezione--alt gtr-contatto" id="contatto" aria-labelledby="gtr-h-contatto">
        <?php if ($gtr_sfondo) : ?><div class="gtr-contatto__sfondo" aria-hidden="true"><?php echo wp_get_attachment_image($gtr_sfondo, 'large', false, array('alt' => '', 'loading' => 'lazy', 'decoding' => 'async', 'sizes' => '100vw')); // phpcs:ignore WordPress.Security.EscapeOutput ?></div><?php endif; ?>
        <div class="gtr-contenitore gtr-griglia">
            <div class="gtr-contatto__testo" style="--gtr-t:8; --gtr-d:5">
                <h2 id="gtr-h-contatto"><?php echo esc_html($gtr_contact_title !== '' ? $gtr_contact_title : $gtr_cta); ?></h2>
                <?php if ($gtr_contact_text !== '') : ?><p><?php echo esc_html($gtr_contact_text); ?></p><?php endif; ?>
                <dl class="gtr-dati">
                    <?php if ($gtr_contacts['phone'] !== '') : ?><dt><?php esc_html_e('Telefono', 'gotthardresin-child-theme'); ?></dt><dd><a class="gtr-link" href="<?php echo esc_attr(gotthardresin_tel($gtr_contacts['phone'])); ?>"><?php echo esc_html($gtr_contacts['phone_display']); ?></a></dd><?php endif; ?>
                    <?php if ($gtr_contacts['email'] !== '') : ?><dt><?php esc_html_e('Email', 'gotthardresin-child-theme'); ?></dt><dd><a class="gtr-link" href="<?php echo esc_attr('mailto:' . $gtr_contacts['email']); ?>"><?php echo esc_html($gtr_contacts['email']); ?></a></dd><?php endif; ?>
                    <?php if (gotthardresin_address_line() !== '') : ?><dt><?php esc_html_e('Sede', 'gotthardresin-child-theme'); ?></dt><dd><a class="gtr-link" href="<?php echo esc_url(gotthardresin_map_url()); ?>" target="_blank" rel="noopener"><?php echo esc_html(gotthardresin_address_line()); ?></a></dd><?php endif; ?>
                </dl>
                <?php get_template_part('template-parts/mappa'); ?>
            </div>
            <?php get_template_part('template-parts/form'); ?>
        </div>
    </section>
</main>
<?php
get_footer();
