<?php
/**
 * Piè di pagina: logo, indirizzo e contatti dal CMS, social, privacy e preferenze dei cookie.
 * Sul telefono la barra fissa «Chiama / Richiedi un preventivo» (compare dopo il primo schermo, sparisce davanti al modulo).
 *
 * @package gotthardresin-child-theme
 */

defined('ABSPATH') || exit;

$gtr_contacts = gotthardresin_contacts();
$gtr_name     = get_bloginfo('name');
$gtr_logo     = function_exists('ticinoweb_get_site_logo') ? (string) ticinoweb_get_site_logo() : '';
$gtr_logo_id  = $gtr_logo !== '' ? gotthardresin_image_id($gtr_logo) : 0;
$gtr_address  = gotthardresin_address_line();
$gtr_privacy  = gotthardresin_privacy_url();
$gtr_networks = array('instagram' => 'Instagram', 'facebook' => 'Facebook', 'linkedin' => 'LinkedIn', 'youtube' => 'YouTube', 'tiktok' => 'TikTok');
$gtr_socials  = gotthardresin_socials();
?>
<footer class="gtr-piede">
    <div class="gtr-contenitore gtr-piede__in">
        <?php if ($gtr_logo_id) : ?>
            <?php echo wp_get_attachment_image($gtr_logo_id, 'medium', false, array('alt' => $gtr_name, 'loading' => 'lazy', 'decoding' => 'async', 'sizes' => '56px')); // phpcs:ignore WordPress.Security.EscapeOutput ?>
        <?php else : ?>
            <span class="gtr-testata__nome"><?php echo esc_html($gtr_name); ?></span>
        <?php endif; ?>
        <p>
            <?php
            $gtr_parts = array();
            if ($gtr_address !== '') {
                $gtr_parts[] = esc_html($gtr_address);
            }
            if ($gtr_contacts['phone'] !== '') {
                $gtr_parts[] = '<a class="gtr-link" href="' . esc_attr(gotthardresin_tel($gtr_contacts['phone'])) . '">' . esc_html($gtr_contacts['phone_display']) . '</a>';
            }
            // Niente antispambot(): cambia a ogni visita e tW Translate lascerebbe la pagina «in attesa» (noindex).
            if ($gtr_contacts['email'] !== '') {
                $gtr_parts[] = '<a class="gtr-link" href="' . esc_attr('mailto:' . $gtr_contacts['email']) . '">' . esc_html($gtr_contacts['email']) . '</a>';
            }
            echo implode(' · ', $gtr_parts); // phpcs:ignore WordPress.Security.EscapeOutput -- escape sopra
            ?>
        </p>
        <p class="gtr-piede__link">
            <?php foreach ($gtr_networks as $gtr_network => $gtr_label) : ?>
                <?php if (!empty($gtr_socials[$gtr_network])) : ?><a class="gtr-social" href="<?php echo esc_url($gtr_socials[$gtr_network]); ?>" target="_blank" rel="noopener" aria-label="<?php echo esc_attr($gtr_label); ?>"><?php echo gotthardresin_icon($gtr_network); // phpcs:ignore WordPress.Security.EscapeOutput -- SVG del tema ?></a><?php endif; ?>
            <?php endforeach; ?>
            <?php if ($gtr_privacy !== '') : ?><a href="<?php echo esc_url(gotthardresin_url($gtr_privacy, 'url:privacy')); ?>"><?php esc_html_e('Privacy', 'gotthardresin-child-theme'); ?></a><?php endif; ?>
            <?php if (get_option('tw_cookie_banner_enable')) : ?><button type="button" data-gtr-cookies><?php esc_html_e('Preferenze cookie', 'gotthardresin-child-theme'); ?></button><?php endif; ?>
        </p>
    </div>
</footer>
<nav class="gtr-barra" aria-label="<?php echo esc_attr(gotthardresin_t(__('Azioni rapide', 'gotthardresin-child-theme'), 'ui:actionbar')); ?>">
    <?php if ($gtr_contacts['phone'] !== '') : ?><a class="gtr-bottone gtr-bottone--linea" href="<?php echo esc_attr(gotthardresin_tel($gtr_contacts['phone'])); ?>"><?php esc_html_e('Chiama', 'gotthardresin-child-theme'); ?></a><?php endif; ?>
    <a class="gtr-bottone gtr-bottone--pieno" href="<?php echo esc_url(gotthardresin_section_url('contatto')); ?>"><?php esc_html_e('Richiedi un preventivo', 'gotthardresin-child-theme'); ?></a>
</nav>
<?php if (is_front_page()) : ?>
<dialog class="gtr-visore" aria-label="<?php echo esc_attr(gotthardresin_t(__('Foto del lavoro', 'gotthardresin-child-theme'), 'ui:viewer')); ?>">
    <figure><figcaption></figcaption></figure>
    <button class="gtr-visore__btn gtr-visore__chiudi" type="button" aria-label="<?php echo esc_attr(gotthardresin_t(__('Chiudi', 'gotthardresin-child-theme'), 'ui:close')); ?>"><svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M6 6l12 12M18 6L6 18"/></svg></button>
    <button class="gtr-visore__btn gtr-visore__prec" type="button" aria-label="<?php echo esc_attr(gotthardresin_t(__('Foto precedente', 'gotthardresin-child-theme'), 'ui:prev')); ?>"><svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M15 5l-7 7 7 7"/></svg></button>
    <button class="gtr-visore__btn gtr-visore__succ" type="button" aria-label="<?php echo esc_attr(gotthardresin_t(__('Foto successiva', 'gotthardresin-child-theme'), 'ui:next')); ?>"><svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M9 5l7 7-7 7"/></svg></button>
</dialog>
<?php endif; ?>
<?php wp_footer(); ?>
</body>
</html>
