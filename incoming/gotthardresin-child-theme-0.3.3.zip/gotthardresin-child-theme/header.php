<?php
/**
 * Testata: logo del CMS a sinistra, voci del menu «primary», bottone «Richiedi un preventivo».
 * Sotto i 1024 px le voci si aprono da un bottone menu (44 px) in un pannello sotto la barra.
 *
 * @package gotthardresin-child-theme
 */

defined('ABSPATH') || exit;

$gtr_name  = function_exists('ticinoweb_frontend_text') ? ticinoweb_frontend_text(get_bloginfo('name'), 'theme:branding:site_name') : get_bloginfo('name');
$gtr_home  = gotthardresin_url(home_url('/'), 'url:home');
$gtr_logo  = function_exists('ticinoweb_get_site_logo') ? (string) ticinoweb_get_site_logo() : '';
$gtr_items = array();
$gtr_locs  = get_nav_menu_locations();
if (!empty($gtr_locs['primary'])) {
    foreach ((array) wp_get_nav_menu_items($gtr_locs['primary']) as $gtr_item) {
        if ((int) $gtr_item->menu_item_parent === 0) {
            $gtr_items[] = array('title' => $gtr_item->title, 'url' => $gtr_item->url, 'target' => $gtr_item->target);
        }
    }
}
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="gtr-salta gtr-bottone gtr-bottone--pieno" href="#gtr-main"><?php esc_html_e('Vai al contenuto', 'gotthardresin-child-theme'); ?></a>
<header class="gtr-testata">
    <div class="gtr-contenitore gtr-testata__in">
        <a class="gtr-testata__logo" href="<?php echo esc_url($gtr_home); ?>" rel="home">
            <?php
            $gtr_logo_id = $gtr_logo !== '' ? gotthardresin_image_id($gtr_logo) : 0;
            if ($gtr_logo_id) {
                echo wp_get_attachment_image($gtr_logo_id, 'medium', false, array('alt' => $gtr_name, 'loading' => 'eager', 'decoding' => 'async', 'sizes' => '64px')); // phpcs:ignore WordPress.Security.EscapeOutput
            } elseif ($gtr_logo !== '') {
                echo '<img src="' . esc_url($gtr_logo) . '" alt="' . esc_attr($gtr_name) . '" height="44" decoding="async">';
            } else {
                echo '<span class="gtr-testata__nome">' . esc_html($gtr_name) . '</span>';
            }
            ?>
        </a>
        <?php if ($gtr_items) : ?>
            <nav class="gtr-testata__nav" id="gtr-menu" aria-label="<?php echo esc_attr(gotthardresin_t(__('Principale', 'gotthardresin-child-theme'), 'ui:nav')); ?>">
                <?php foreach ($gtr_items as $gtr_item) : ?>
                    <a href="<?php echo esc_url($gtr_item['url']); ?>"<?php echo $gtr_item['target'] ? ' target="' . esc_attr($gtr_item['target']) . '" rel="noopener"' : ''; ?>><?php echo esc_html($gtr_item['title']); ?></a>
                <?php endforeach; ?>
            </nav>
        <?php endif; ?>
        <div class="gtr-testata__azione"><a class="gtr-bottone gtr-bottone--pieno" href="<?php echo esc_url(gotthardresin_section_url('contatto')); ?>"><?php esc_html_e('Richiedi un preventivo', 'gotthardresin-child-theme'); ?></a></div>
        <?php if ($gtr_items) : ?>
            <button class="gtr-testata__menu" type="button" aria-expanded="false" aria-controls="gtr-menu" aria-label="<?php echo esc_attr(gotthardresin_t(__('Apri il menu', 'gotthardresin-child-theme'), 'ui:menu_open')); ?>"><svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M4 7h16M4 12h16M4 17h16"/></svg></button>
        <?php endif; ?>
    </div>
</header>
