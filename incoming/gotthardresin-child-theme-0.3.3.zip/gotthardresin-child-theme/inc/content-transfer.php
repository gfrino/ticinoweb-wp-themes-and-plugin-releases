<?php
/**
 * Gotthard Resin: «Porta sul sito» (Strumenti → Gotthard Resin: Porta sul sito).
 *
 * Porta i contenuti del sito dal sito locale (o di prova) al sito live senza toccare il database:
 * sul sito di partenza si scarica un file JSON leggero, su quello di destinazione lo si carica, si legge
 * l'anteprima e si conferma. Gli elementi si riconoscono per slug o chiave: quelli già presenti vengono
 * aggiornati, mai duplicati. Le immagini viaggiano come token per NOME FILE («grmedia:foto.jpg»):
 * sul sito di destinazione devono già stare nella Libreria media con lo stesso nome, così gli ID
 * (diversi da un sito all'altro) si riagganciano da soli. Il dominio diventa il segnaposto {{home}}.
 *
 * Porta: pagine (con meta SEO, immagine in evidenza, template, scheda FAQ collegata), opzioni del CMS
 * (contatti, logo, icona, colore, servizi, Chi siamo, SEO, cookie, privacy, Google, pagina iniziale, nome
 * del sito), impostazioni «Gotthard Resin» del Personalizza, menu di navigazione, schede FAQ, gallerie
 * del parent (quali foto e in che ordine).
 * NON porta: articoli, utenti, invii dei moduli, chiavi (reCAPTCHA, SMTP), licenze, plugin, file delle immagini.
 */
defined('ABSPATH') || exit;

const GOTTHARDRESIN_CT_TOKEN     = 'grmedia:';
const GOTTHARDRESIN_CT_FORMAT    = 'gotthardresin-content';
const GOTTHARDRESIN_CT_VERSION   = 1;
const GOTTHARDRESIN_CT_HOME      = '{{home}}';
const GOTTHARDRESIN_CT_MAX_BYTES = 5242880; // 5 MB
const GOTTHARDRESIN_CT_SLUG      = 'gotthardresin-transfer';

/* -------------------------------------------------------------------------
 * Liste bianche: cosa viaggia e con quale tipo di dato
 * ---------------------------------------------------------------------- */

/** Stati delle pagine e delle schede FAQ che viaggiano (il cestino no). */
function gotthardresin_ct_statuses()
{
    return array('publish', 'draft', 'private', 'pending');
}

/** Meta delle pagine che viaggiano, con il tipo di dato per la sanitizzazione in import. */
function gotthardresin_ct_page_meta_types()
{
    return array(
        '_thumbnail_id'       => 'image',
        '_tw_seo_title'       => 'text',
        '_tw_seo_description' => 'textarea',
        '_tw_seo_robots'      => 'text',
        '_wp_page_template'   => 'template',
        '_tw_faq_page_set'    => 'slug',
    );
}

/**
 * Tipo di dato di un'opzione ammessa, oppure '' se l'opzione NON va toccata.
 * Qui sta tutta la lista bianca: fuori da questa funzione nessuna opzione viene scritta.
 */
function gotthardresin_ct_option_type($name)
{
    $name = (string) $name;
    if ($name === '' || preg_match('/(key|secret|token|password|licen[sc]e|_transient_)/i', $name)) {
        return '';
    }
    $fixed = array(
        'ticinoweb_site_logo'      => 'url',
        'ticinoweb_site_icon'      => 'url',
        'ticinoweb_palette_primary' => 'color',
        'tw_cookie_banner_enable'  => 'text',
        'tw_privacy_policy_url'    => 'url',
        'tw_google_analytics_id'   => 'text',
        'tw_gtag_code'             => 'code',
        'tw_gtm_head_code'         => 'code',
        'tw_gtm_body_code'         => 'code',
        'show_on_front'            => 'enum_front',
        'page_on_front'            => 'page',
        'page_for_posts'           => 'page',
        'blogname'                 => 'text',
        'blogdescription'          => 'text',
        'ticinoweb_services'       => 'services',
        'ticinoweb_chi_siamo_title' => 'text',
        'ticinoweb_chi_siamo_text' => 'textarea',
        'ticinoweb_chi_siamo_image' => 'url',
        'ticinoweb_chi_siamo_link' => 'url',
    );
    if (isset($fixed[$name])) {
        return $fixed[$name];
    }
    if (strpos($name, 'ticinoweb_contact_') === 0) {
        $rest = substr($name, strlen('ticinoweb_contact_'));
        if (in_array($rest, array('map_url', 'facebook', 'instagram', 'tiktok', 'linkedin', 'youtube', 'x', 'github', 'behance'), true)) {
            return 'url';
        }
        if ($rest === 'opening_hours') {
            return 'array_text';
        }
        if (in_array($rest, array('address', 'address_2', 'opening_hours_note'), true)) {
            return 'textarea';
        }
        return 'text';
    }
    if (strpos($name, 'tw_seo_') === 0) {
        $rest = substr($name, strlen('tw_seo_'));
        if (in_array($rest, array('social_image', 'org_logo'), true)) {
            return 'url';
        }
        if (in_array($rest, array('org_social', 'description', 'business_address'), true)) {
            return 'textarea';
        }
        if (in_array($rest, array('exclude_sitemap', 'enable_metabox'), true)) {
            return 'array_key';
        }
        return 'text';
    }
    return '';
}

/** Nomi delle opzioni da esportare: quelle fisse più tutte le ticinoweb_contact_* e tw_seo_* presenti nel database. */
function gotthardresin_ct_option_names()
{
    global $wpdb;
    $names = array(
        'ticinoweb_site_logo', 'ticinoweb_site_icon', 'ticinoweb_palette_primary',
        'tw_cookie_banner_enable', 'tw_privacy_policy_url', 'tw_google_analytics_id',
        'tw_gtag_code', 'tw_gtm_head_code', 'tw_gtm_body_code',
        'show_on_front', 'page_on_front', 'page_for_posts', 'blogname', 'blogdescription',
        'ticinoweb_services', 'ticinoweb_chi_siamo_title', 'ticinoweb_chi_siamo_text', 'ticinoweb_chi_siamo_image', 'ticinoweb_chi_siamo_link',
    );
    $rows = $wpdb->get_col(
        "SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE 'ticinoweb\_contact\_%' OR option_name LIKE 'tw\_seo\_%' ORDER BY option_name ASC"
    );
    foreach ((array) $rows as $row) {
        $names[] = (string) $row;
    }
    $names = array_values(array_unique($names));
    return array_values(array_filter($names, function ($name) {
        return gotthardresin_ct_option_type($name) !== '';
    }));
}

/* -------------------------------------------------------------------------
 * Immagini: token per nome file
 * ---------------------------------------------------------------------- */

/** True se l'ID è un allegato di questo sito. */
function gotthardresin_ct_is_attachment($id)
{
    $id = absint($id);
    return $id > 0 && get_post_type($id) === 'attachment';
}

/** Nome file (basename) di un allegato, '' se assente. */
function gotthardresin_ct_attachment_basename($id)
{
    $file = get_post_meta(absint($id), '_wp_attached_file', true);
    return $file ? basename((string) $file) : '';
}

/**
 * Cerca un allegato per nome file. Prova il nome così com'è, poi senza il suffisso di
 * dimensione (-300x200), con e senza «-scaled». Ritorna ['id', 'url', 'file'] o null.
 */
function gotthardresin_ct_find_attachment($filename)
{
    global $wpdb;
    static $cache = array();

    $filename = sanitize_file_name(rawurldecode(basename((string) $filename)));
    if ($filename === '') {
        return null;
    }
    if (array_key_exists($filename, $cache)) {
        return $cache[$filename];
    }
    $ext   = pathinfo($filename, PATHINFO_EXTENSION);
    $stem  = pathinfo($filename, PATHINFO_FILENAME);
    $plain = preg_replace('/-scaled$/', '', preg_replace('/-\d+x\d+$/', '', $stem));
    $candidates = array_unique(array(
        $filename,
        $plain . '.' . $ext,
        $plain . '-scaled.' . $ext,
    ));
    $result = null;
    foreach ($candidates as $candidate) {
        $id = (int) $wpdb->get_var($wpdb->prepare(
            "SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = '_wp_attached_file' AND (meta_value = %s OR meta_value LIKE %s) ORDER BY post_id DESC LIMIT 1",
            $candidate,
            '%/' . $wpdb->esc_like($candidate)
        ));
        if ($id && gotthardresin_ct_is_attachment($id)) {
            $url = wp_get_attachment_url($id);
            if ($url) {
                $result = array('id' => $id, 'url' => $url, 'file' => gotthardresin_ct_attachment_basename($id));
                break;
            }
        }
    }
    $cache[$filename] = $result;
    return $result;
}

/**
 * URL di questo sito per un nome file richiesto (anche in una dimensione intermedia, es. foto-300x200.jpg).
 * '' se l'immagine non c'è.
 */
function gotthardresin_ct_token_url($filename)
{
    $found = gotthardresin_ct_find_attachment($filename);
    if (!$found) {
        return '';
    }
    $requested = sanitize_file_name(rawurldecode(basename((string) $filename)));
    if ($requested === $found['file']) {
        return $found['url'];
    }
    $dir = untrailingslashit(dirname($found['url']));
    $ext = pathinfo($requested, PATHINFO_EXTENSION);
    if (preg_match('/-(\d+x\d+)$/', pathinfo($requested, PATHINFO_FILENAME), $m)) {
        $plain = preg_replace('/-scaled$/', '', pathinfo($found['file'], PATHINFO_FILENAME));
        return $dir . '/' . $plain . '-' . $m[1] . '.' . $ext;
    }
    $attached = get_attached_file($found['id']);
    if ($attached && file_exists(dirname($attached) . '/' . $requested)) {
        return $dir . '/' . $requested;
    }
    return $found['url'];
}

/**
 * Testo in forma portabile: gli URL della cartella uploads diventano token per nome file,
 * il dominio del sito diventa {{home}}. Raccoglie in $files i nomi file incontrati.
 */
function gotthardresin_ct_encode_text($text, array &$files)
{
    if (!is_string($text) || $text === '') {
        return $text;
    }
    $text = preg_replace_callback(
        '~(?:https?:)?//[^\s"\'<>()]+?/wp-content/uploads/[^\s"\'<>(),?#]+(?:\?[^\s"\'<>()]*)?|(?<![\w:/])/(?:[\w.-]+/)?wp-content/uploads/[^\s"\'<>(),?#]+(?:\?[^\s"\'<>()]*)?~i',
        function ($m) use (&$files) {
            $path = (string) wp_parse_url(html_entity_decode($m[0], ENT_QUOTES, 'UTF-8'), PHP_URL_PATH);
            $name = sanitize_file_name(rawurldecode(basename($path)));
            if ($name === '' || !preg_match('/\.[a-z0-9]{2,5}$/i', $name)) {
                return $m[0];
            }
            $files[$name] = true;
            return GOTTHARDRESIN_CT_TOKEN . $name;
        },
        $text
    );
    $home = untrailingslashit(home_url());
    $variants = array_unique(array($home, set_url_scheme($home, 'http'), set_url_scheme($home, 'https')));
    $text = str_replace($variants, GOTTHARDRESIN_CT_HOME, $text);
    $path = trim((string) wp_parse_url($home, PHP_URL_PATH), '/');
    if ($path !== '') {
        // Link relativi alla radice in un multisito a sottocartelle: href="/sede/menu/" → {{home}}/menu/
        $text = preg_replace('~(["\'(=])/' . preg_quote($path, '~') . '(?=/|["\')])~', '$1' . GOTTHARDRESIN_CT_HOME, $text);
    }
    return $text;
}

/** ID allegato → token per nome file (il valore resta com'è se non è un allegato). */
function gotthardresin_ct_encode_id($value, array &$files)
{
    if (is_numeric($value) && gotthardresin_ct_is_attachment($value)) {
        $name = gotthardresin_ct_attachment_basename($value);
        if ($name !== '') {
            $files[$name] = true;
            return GOTTHARDRESIN_CT_TOKEN . $name;
        }
    }
    return $value;
}

/** Forma portabile di una struttura: ogni stringa passa da gotthardresin_ct_encode_text(). */
function gotthardresin_ct_encode_deep($value, array &$files)
{
    if (is_array($value)) {
        $out = array();
        foreach ($value as $k => $v) {
            $out[$k] = gotthardresin_ct_encode_deep($v, $files);
        }
        return $out;
    }
    return is_string($value) ? gotthardresin_ct_encode_text($value, $files) : $value;
}

/**
 * Da portabile a locale: i token diventano URL di questo sito (se l'immagine manca il token resta
 * e il nome finisce in $missing), {{home}} diventa home_url().
 */
function gotthardresin_ct_decode_text($text, array &$found, array &$missing)
{
    if (!is_string($text) || $text === '') {
        return $text;
    }
    $text = preg_replace_callback(
        '~' . preg_quote(GOTTHARDRESIN_CT_TOKEN, '~') . '([A-Za-z0-9._%+@-]+)~',
        function ($m) use (&$found, &$missing) {
            $url = gotthardresin_ct_token_url($m[1]);
            if ($url === '') {
                $missing[$m[1]] = true;
                return $m[0];
            }
            $found[$m[1]] = true;
            return $url;
        },
        $text
    );
    return str_replace(GOTTHARDRESIN_CT_HOME, untrailingslashit(home_url()), $text);
}

/**
 * Token → ID allegato di questo sito (0 se manca: il nome finisce in $missing).
 * Un ID numerico «nudo» vale 0: gli ID di un altro sito non si copiano mai così come sono.
 */
function gotthardresin_ct_decode_id($value, array &$found, array &$missing)
{
    if (is_string($value) && strpos($value, GOTTHARDRESIN_CT_TOKEN) === 0) {
        $name = substr($value, strlen(GOTTHARDRESIN_CT_TOKEN));
        $hit  = gotthardresin_ct_find_attachment($name);
        if ($hit) {
            $found[$name] = true;
            return (int) $hit['id'];
        }
        $missing[$name] = true;
    }
    return 0;
}

/** Struttura da portabile a locale: ogni stringa passa da gotthardresin_ct_decode_text(). */
function gotthardresin_ct_decode_deep($value, array &$found, array &$missing)
{
    if (is_array($value)) {
        $out = array();
        foreach ($value as $k => $v) {
            $out[$k] = gotthardresin_ct_decode_deep($v, $found, $missing);
        }
        return $out;
    }
    return is_string($value) ? gotthardresin_ct_decode_text($value, $found, $missing) : $value;
}

/* -------------------------------------------------------------------------
 * Sanitizzazione per tipo (niente valore arriva nel database così com'è)
 * ---------------------------------------------------------------------- */

/** Pulisce ricorsivamente una struttura: stringhe con $fn, numeri e booleani restano tali, il resto sparisce. */
function gotthardresin_ct_sanitize_deep($value, $fn)
{
    if (is_array($value)) {
        $out = array();
        foreach ($value as $k => $v) {
            $key = is_int($k) ? $k : sanitize_text_field((string) $k);
            $out[$key] = gotthardresin_ct_sanitize_deep($v, $fn);
        }
        return $out;
    }
    if (is_bool($value) || is_int($value) || is_float($value)) {
        return $value;
    }
    return is_string($value) ? call_user_func($fn, $value) : '';
}

/** Pulisce un valore secondo il tipo della lista bianca. */
function gotthardresin_ct_sanitize($value, $type)
{
    switch ($type) {
        case 'html':
            return wp_kses_post((string) (is_scalar($value) ? $value : ''));
        case 'textarea':
            return sanitize_textarea_field((string) (is_scalar($value) ? $value : ''));
        case 'url':
            return esc_url_raw(trim((string) (is_scalar($value) ? $value : '')));
        case 'color':
            $color = sanitize_hex_color(trim((string) (is_scalar($value) ? $value : '')));
            return $color ? $color : '';
        case 'template':
            // Un template di pagina esistente nel tema (anche in sottocartella), altrimenti «default».
            $template = preg_replace('~[^A-Za-z0-9_./-]~', '', (string) (is_scalar($value) ? $value : ''));
            if ($template === '' || $template === 'default' || strpos($template, '..') !== false) {
                return 'default';
            }
            $known = wp_get_theme()->get_page_templates(null, 'page');
            return isset($known[$template]) ? $template : 'default';
        case 'slug':
            return sanitize_title((string) (is_scalar($value) ? $value : ''));
        case 'int':
            return absint($value);
        case 'enum_front':
            return $value === 'posts' ? 'posts' : 'page';
        case 'code':
            // Snippet Google Tag / GTM: li pulisce lo stesso filtro della pagina SEO del parent.
            $code = (string) (is_scalar($value) ? $value : '');
            return function_exists('tw_seo_sanitize_tag_code') ? tw_seo_sanitize_tag_code($code) : $code;
        case 'services':
            // I servizi del CMS: li pulisce la stessa funzione della pagina Servizi del parent.
            return function_exists('ticinoweb_sanitize_services') ? ticinoweb_sanitize_services(is_array($value) ? $value : array()) : array();
        case 'array_text':
            return gotthardresin_ct_sanitize_deep(is_array($value) ? $value : array(), 'sanitize_text_field');
        case 'array_key':
            return array_values(array_filter(array_map('sanitize_key', array_filter((array) $value, 'is_scalar'))));
        case 'text':
        default:
            return sanitize_text_field((string) (is_scalar($value) ? $value : ''));
    }
}

/* -------------------------------------------------------------------------
 * Pagine e schede: ricerca per slug
 * ---------------------------------------------------------------------- */

/** Pagina per percorso (genitore/figlia) o per slug, in qualunque stato tranne il cestino. */
function gotthardresin_ct_find_post($path, $slug, $post_type = 'page')
{
    $post = $path !== '' ? get_page_by_path($path, OBJECT, $post_type) : null;
    if (!$post instanceof WP_Post && $slug !== '') {
        $found = get_posts(array(
            'post_type'        => $post_type,
            'name'             => $slug,
            'post_status'      => gotthardresin_ct_statuses(),
            'numberposts'      => 1,
            'suppress_filters' => true,
        ));
        $post = $found ? $found[0] : null;
    }
    return ($post instanceof WP_Post && $post->post_status !== 'trash') ? $post : null;
}

/** Elemento dell'indice immagini: nome del file originale e dimensioni (0 se l'immagine non è su questo sito). */
function gotthardresin_ct_media_entry($filename)
{
    $hit   = gotthardresin_ct_find_attachment($filename);
    $entry = array('file' => sanitize_file_name(rawurldecode(basename((string) $filename))), 'width' => 0, 'height' => 0, 'mime' => '');
    if (!$hit) {
        return $entry;
    }
    $meta = wp_get_attachment_metadata($hit['id']);
    $entry['file']   = !empty($meta['original_image']) ? basename((string) $meta['original_image']) : $hit['file'];
    $entry['width']  = isset($meta['width']) ? (int) $meta['width'] : 0;
    $entry['height'] = isset($meta['height']) ? (int) $meta['height'] : 0;
    $entry['mime']   = (string) get_post_mime_type($hit['id']);
    return $entry;
}

/* -------------------------------------------------------------------------
 * Esportazione
 * ---------------------------------------------------------------------- */

/** Costruisce il pacchetto dei contenuti di questo sito. */
function gotthardresin_ct_export_payload()
{
    $files = array();

    // 1) Pagine (mai i prodotti: solo post_type page).
    $pages = array();
    $posts = get_posts(array(
        'post_type'        => 'page',
        'post_status'      => gotthardresin_ct_statuses(),
        'numberposts'      => -1,
        'orderby'          => array('menu_order' => 'ASC', 'ID' => 'ASC'),
        'suppress_filters' => true,
    ));
    foreach ($posts as $post) {
        $meta = array();
        foreach (gotthardresin_ct_page_meta_types() as $key => $type) {
            $raw = get_post_meta($post->ID, $key, true);
            if ($raw === '' || $raw === false || $raw === null) {
                continue;
            }
            if ($type === 'image') {
                $token = gotthardresin_ct_encode_id($raw, $files);
                if ($token === $raw) {
                    continue; // ID che non è un allegato: non viaggia.
                }
                $meta[$key] = $token;
                continue;
            }
            $meta[$key] = gotthardresin_ct_encode_text((string) $raw, $files);
        }
        $pages[] = array(
            'slug'       => $post->post_name,
            'path'       => get_page_uri($post),
            'title'      => $post->post_title,
            'content'    => gotthardresin_ct_encode_text($post->post_content, $files),
            'excerpt'    => gotthardresin_ct_encode_text($post->post_excerpt, $files),
            'status'     => $post->post_status,
            'menu_order' => (int) $post->menu_order,
            'parent'     => $post->post_parent ? get_post_field('post_name', $post->post_parent) : '',
            'template'   => (string) get_post_meta($post->ID, '_wp_page_template', true),
            'meta'       => $meta,
        );
    }

    // 2) Opzioni del CMS (le pagine per slug, le immagini per nome file).
    $options = array();
    foreach (gotthardresin_ct_option_names() as $name) {
        $value = get_option($name, null);
        if ($value === null) {
            continue;
        }
        if (gotthardresin_ct_option_type($name) === 'page') {
            $value = absint($value) ? (string) get_page_uri(absint($value)) : '';
        }
        $options[$name] = gotthardresin_ct_encode_deep($value, $files);
    }

    // 3) Impostazioni del tema (Customizer → Gotthard Resin) e posizioni dei menu (per nome).
    $theme_mods = array();
    $locations  = array();
    foreach ((array) get_theme_mods() as $key => $value) {
        if ($key === 'nav_menu_locations' && is_array($value)) {
            foreach ($value as $location => $menu_id) {
                $menu = $menu_id ? wp_get_nav_menu_object((int) $menu_id) : false;
                $locations[sanitize_key($location)] = $menu ? $menu->name : '';
            }
            continue;
        }
        if (strpos((string) $key, 'gotthardresin_') !== 0) {
            continue;
        }
        if (is_numeric($value) && preg_match('/(image|logo|icon|img|foto|photo)/', (string) $key) && gotthardresin_ct_is_attachment($value)) {
            $theme_mods[$key] = gotthardresin_ct_encode_id($value, $files);
        } else {
            $theme_mods[$key] = gotthardresin_ct_encode_deep($value, $files);
        }
    }

    // 4) Menu di navigazione.
    $menus = array();
    foreach ((array) wp_get_nav_menus() as $menu) {
        $items = wp_get_nav_menu_items($menu->term_id, array('update_post_term_cache' => false));
        $list  = array();
        foreach ((array) $items as $item) {
            $entry = array(
                'ref'         => (int) $item->ID,
                'parent'      => (int) $item->menu_item_parent,
                'order'       => (int) $item->menu_order,
                'type'        => (string) $item->type,
                'object'      => (string) $item->object,
                'slug'        => '',
                'url'         => '',
                'title'       => (string) $item->post_title,
                'target'      => (string) $item->target,
                'classes'     => implode(' ', array_filter((array) $item->classes)),
                'xfn'         => (string) $item->xfn,
                'attr_title'  => (string) $item->attr_title,
                'description' => (string) $item->post_content,
            );
            if ($item->type === 'post_type') {
                $entry['slug'] = $item->object === 'page' ? (string) get_page_uri((int) $item->object_id) : (string) get_post_field('post_name', (int) $item->object_id);
            } elseif ($item->type === 'taxonomy') {
                $term = get_term((int) $item->object_id, $item->object);
                $entry['slug'] = ($term instanceof WP_Term) ? $term->slug : '';
            } else {
                $entry['url'] = gotthardresin_ct_encode_text((string) $item->url, $files);
            }
            $list[] = $entry;
        }
        $menus[] = array('name' => $menu->name, 'slug' => $menu->slug, 'items' => $list);
    }

    // 5) Schede FAQ del parent (tw_faq): le domande stanno nei meta _tw_faq_*.
    $faqs = array();
    if (post_type_exists('tw_faq')) {
        $cards = get_posts(array(
            'post_type'        => 'tw_faq',
            'post_status'      => gotthardresin_ct_statuses(),
            'numberposts'      => -1,
            'orderby'          => array('menu_order' => 'ASC', 'ID' => 'ASC'),
            'suppress_filters' => true,
        ));
        foreach ($cards as $card) {
            $meta = array();
            foreach ((array) get_post_meta($card->ID) as $key => $values) {
                if (!gotthardresin_ct_faq_meta_allowed($key) || !isset($values[0])) {
                    continue;
                }
                $meta[$key] = gotthardresin_ct_encode_deep(maybe_unserialize($values[0]), $files);
            }
            $faqs[] = array(
                'slug'       => $card->post_name,
                'title'      => $card->post_title,
                'status'     => $card->post_status,
                'menu_order' => (int) $card->menu_order,
                'meta'       => $meta,
            );
        }
    }

    // 6) Gallerie del parent: per ognuna le foto (per nome file) nell'ordine del gestore.
    $galleries = array();
    if (taxonomy_exists('ticinoweb_media_gallery')) {
        $terms = get_terms(array('taxonomy' => 'ticinoweb_media_gallery', 'hide_empty' => false));
        foreach (is_array($terms) ? $terms : array() as $term) {
            $files_in = array();
            foreach (gotthardresin_gallery_images($term->slug, 500) as $id) {
                $token = gotthardresin_ct_encode_id($id, $files);
                if ($token !== $id) {
                    $files_in[] = $token;
                }
            }
            $galleries[] = array('slug' => $term->slug, 'name' => $term->name, 'description' => $term->description, 'images' => $files_in);
        }
    }

    // 7) Indice delle immagini citate (nome file e dimensioni): serve al resoconto dei mancanti.
    $media = array();
    foreach (array_keys($files) as $name) {
        $entry = gotthardresin_ct_media_entry($name);
        $media[$entry['file']] = $entry;
    }
    ksort($media);

    return array(
        'format'      => GOTTHARDRESIN_CT_FORMAT,
        'version'     => GOTTHARDRESIN_CT_VERSION,
        'exported_at' => gmdate('c'),
        'source_url'  => home_url(),
        'site_name'   => get_bloginfo('name'),
        'theme'       => get_stylesheet(),
        'pages'       => $pages,
        'options'     => $options,
        'theme_mods'  => $theme_mods,
        'locations'   => $locations,
        'menus'       => $menus,
        'faqs'        => $faqs,
        'galleries'   => $galleries,
        'media'       => array_values($media),
    );
}

/** Meta di una scheda FAQ che viaggiano: _tw_faq*, _tw_seo* e quelli non protetti (mai _edit_lock e simili). */
function gotthardresin_ct_faq_meta_allowed($key)
{
    $key = (string) $key;
    if ($key === '') {
        return false;
    }
    if (strpos($key, '_tw_faq') === 0 || strpos($key, '_tw_seo') === 0) {
        return true;
    }
    return !is_protected_meta($key, 'post');
}

/** Slug del sito per il nome del file: il percorso del sottosito, altrimenti il dominio. */
function gotthardresin_ct_site_slug()
{
    $home = home_url();
    $slug = trim((string) wp_parse_url($home, PHP_URL_PATH), '/');
    if ($slug === '') {
        $slug = (string) wp_parse_url($home, PHP_URL_HOST);
    }
    $slug = sanitize_title($slug);
    return $slug !== '' ? $slug : 'sito';
}

/** admin-post: scarica il file JSON. */
function gotthardresin_ct_handle_export()
{
    if (!current_user_can('manage_options')) {
        wp_die(esc_html__('Non hai i permessi per questa operazione.', 'gotthardresin-child-theme'));
    }
    check_admin_referer('gotthardresin_ct_export');

    $payload  = gotthardresin_ct_export_payload();
    $filename = 'gotthardresin-' . gotthardresin_ct_site_slug() . '-' . wp_date('Y-m-d') . '.json';
    nocache_headers();
    header('Content-Type: application/json; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    echo wp_json_encode($payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE); // phpcs:ignore WordPress.Security.EscapeOutput
    exit;
}
add_action('admin_post_gotthardresin_ct_export', 'gotthardresin_ct_handle_export');

/* -------------------------------------------------------------------------
 * Importazione: caricamento, anteprima, conferma
 * ---------------------------------------------------------------------- */

/** Nome dell'opzione (non autoload) che tiene il file in attesa di conferma per l'utente corrente. */
function gotthardresin_ct_pending_key()
{
    return 'gotthardresin_ct_pending_' . get_current_user_id();
}

/** Nome dell'opzione (non autoload) con l'ultimo resoconto dell'utente corrente. */
function gotthardresin_ct_report_key()
{
    return 'gotthardresin_ct_report_' . get_current_user_id();
}

/** Il pacchetto in attesa di conferma: ['data' => array, 'token' => string, 'name' => string] o null (scaduto dopo 2 ore). */
function gotthardresin_ct_pending()
{
    $pending = get_option(gotthardresin_ct_pending_key());
    if (!is_array($pending) || empty($pending['json']) || empty($pending['token']) || empty($pending['time'])) {
        return null;
    }
    if ((int) $pending['time'] < time() - 2 * HOUR_IN_SECONDS) {
        delete_option(gotthardresin_ct_pending_key());
        return null;
    }
    $data = gotthardresin_ct_parse_json((string) $pending['json']);
    if (is_wp_error($data)) {
        delete_option(gotthardresin_ct_pending_key());
        return null;
    }
    return array('data' => $data, 'token' => (string) $pending['token'], 'name' => (string) ($pending['name'] ?? ''));
}

/** Decodifica e controlla il JSON del pacchetto (niente unserialize: il JSON basta). */
function gotthardresin_ct_parse_json($json)
{
    $data = json_decode($json, true, 64);
    if (!is_array($data) || json_last_error() !== JSON_ERROR_NONE) {
        return new WP_Error('json', __('Il file non è un JSON leggibile.', 'gotthardresin-child-theme'));
    }
    if (($data['format'] ?? '') !== GOTTHARDRESIN_CT_FORMAT) {
        return new WP_Error('format', __('Il file non è stato prodotto da «Gotthard Resin: Porta sul sito».', 'gotthardresin-child-theme'));
    }
    if ((int) ($data['version'] ?? 0) > GOTTHARDRESIN_CT_VERSION) {
        return new WP_Error('version', __('Il file viene da una versione più nuova del tema: aggiorna prima il tema su questo sito.', 'gotthardresin-child-theme'));
    }
    foreach (array('pages', 'options', 'theme_mods', 'locations', 'menus', 'faqs', 'media') as $key) {
        if (isset($data[$key]) && !is_array($data[$key])) {
            return new WP_Error('shape', __('Il file è danneggiato.', 'gotthardresin-child-theme'));
        }
    }
    return $data;
}

/** Legge il file caricato: ritorna il JSON come stringa o un WP_Error. */
function gotthardresin_ct_read_upload()
{
    $file = isset($_FILES['gotthardresin_ct_file']) && is_array($_FILES['gotthardresin_ct_file']) ? $_FILES['gotthardresin_ct_file'] : null; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
    if (!$file || (int) ($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK || empty($file['tmp_name'])) {
        return new WP_Error('upload', __('Nessun file ricevuto. Scegli il file .json scaricato dal sito di partenza.', 'gotthardresin-child-theme'));
    }
    if ((int) $file['size'] > GOTTHARDRESIN_CT_MAX_BYTES || (int) $file['size'] <= 0) {
        return new WP_Error('size', sprintf(
            /* translators: %s: dimensione massima */
            __('Il file supera il limite di %s.', 'gotthardresin-child-theme'),
            size_format(GOTTHARDRESIN_CT_MAX_BYTES)
        ));
    }
    $name = sanitize_file_name((string) ($file['name'] ?? ''));
    $type = wp_check_filetype($name, array('json' => 'application/json'));
    if (empty($type['ext']) || $type['ext'] !== 'json') {
        return new WP_Error('type', __('Il file deve essere un .json.', 'gotthardresin-child-theme'));
    }
    $tmp = (string) $file['tmp_name'];
    if (!is_uploaded_file($tmp)) {
        return new WP_Error('upload', __('Caricamento non valido.', 'gotthardresin-child-theme'));
    }
    $json = file_get_contents($tmp); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
    if (!is_string($json) || $json === '') {
        return new WP_Error('read', __('Il file è vuoto.', 'gotthardresin-child-theme'));
    }
    $data = gotthardresin_ct_parse_json($json);
    if (is_wp_error($data)) {
        return $data;
    }
    return array('json' => $json, 'name' => $name);
}

/** URL della pagina dello strumento, con eventuali parametri. */
function gotthardresin_ct_page_url(array $args = array())
{
    return add_query_arg($args, admin_url('tools.php?page=' . GOTTHARDRESIN_CT_SLUG));
}

/** admin-post: riceve il file, lo controlla e lo mette in attesa di conferma (anteprima). */
function gotthardresin_ct_handle_upload()
{
    if (!current_user_can('manage_options')) {
        wp_die(esc_html__('Non hai i permessi per questa operazione.', 'gotthardresin-child-theme'));
    }
    check_admin_referer('gotthardresin_ct_upload');

    $read = gotthardresin_ct_read_upload();
    if (is_wp_error($read)) {
        set_transient('gotthardresin_ct_error_' . get_current_user_id(), $read->get_error_message(), MINUTE_IN_SECONDS * 5);
        wp_safe_redirect(gotthardresin_ct_page_url(array('step' => 'error')));
        exit;
    }
    update_option(gotthardresin_ct_pending_key(), array(
        'json'  => $read['json'],
        'name'  => $read['name'],
        'token' => wp_generate_password(24, false, false),
        'time'  => time(),
    ), 'no');
    wp_safe_redirect(gotthardresin_ct_page_url(array('step' => 'preview')));
    exit;
}
add_action('admin_post_gotthardresin_ct_upload', 'gotthardresin_ct_handle_upload');

/** admin-post: annulla il file in attesa. */
function gotthardresin_ct_handle_cancel()
{
    if (!current_user_can('manage_options')) {
        wp_die(esc_html__('Non hai i permessi per questa operazione.', 'gotthardresin-child-theme'));
    }
    check_admin_referer('gotthardresin_ct_cancel');
    delete_option(gotthardresin_ct_pending_key());
    wp_safe_redirect(gotthardresin_ct_page_url());
    exit;
}
add_action('admin_post_gotthardresin_ct_cancel', 'gotthardresin_ct_handle_cancel');

/** admin-post: conferma e importa davvero. */
function gotthardresin_ct_handle_import()
{
    if (!current_user_can('manage_options')) {
        wp_die(esc_html__('Non hai i permessi per questa operazione.', 'gotthardresin-child-theme'));
    }
    check_admin_referer('gotthardresin_ct_import');

    $pending = gotthardresin_ct_pending();
    $token   = isset($_POST['gotthardresin_ct_token']) ? sanitize_text_field(wp_unslash($_POST['gotthardresin_ct_token'])) : '';
    if (!$pending || $token === '' || !hash_equals($pending['token'], $token)) {
        set_transient('gotthardresin_ct_error_' . get_current_user_id(), __('Il file da importare non c\'è più o è scaduto: ricaricalo.', 'gotthardresin-child-theme'), MINUTE_IN_SECONDS * 5);
        wp_safe_redirect(gotthardresin_ct_page_url(array('step' => 'error')));
        exit;
    }
    $report = gotthardresin_ct_run_import($pending['data']);
    $report['file'] = $pending['name'];
    $report['time'] = time();
    update_option(gotthardresin_ct_report_key(), $report, 'no');
    delete_option(gotthardresin_ct_pending_key());
    wp_safe_redirect(gotthardresin_ct_page_url(array('step' => 'done')));
    exit;
}
add_action('admin_post_gotthardresin_ct_import', 'gotthardresin_ct_handle_import');

/* -------------------------------------------------------------------------
 * Anteprima: cosa cambierà (non scrive nulla)
 * ---------------------------------------------------------------------- */

function gotthardresin_ct_preview(array $data)
{
    $preview = array('pages' => array(), 'options' => array(), 'theme_mods' => 0, 'locations' => array(), 'menus' => array(), 'faqs' => array(), 'galleries' => array(), 'images_found' => array(), 'images_missing' => array(), 'warnings' => array());
    foreach ((array) ($data['galleries'] ?? array()) as $gallery) {
        $name = sanitize_text_field((string) ($gallery['name'] ?? ''));
        if ($name !== '') {
            $preview['galleries'][] = sprintf('%s (%d)', $name, is_array($gallery['images'] ?? null) ? count($gallery['images']) : 0);
        }
    }

    $source = untrailingslashit((string) ($data['source_url'] ?? ''));
    if ($source !== '' && $source === untrailingslashit(home_url())) {
        $preview['warnings'][] = __('Il file è stato esportato da questo stesso sito: l\'importazione riscriverà i contenuti con quelli del file.', 'gotthardresin-child-theme');
    }
    if (!empty($data['theme']) && $data['theme'] !== get_stylesheet()) {
        $preview['warnings'][] = sprintf(
            /* translators: %s: nome del tema */
            __('Il file viene da un sito con un altro tema (%s): le impostazioni del Customizer potrebbero non corrispondere.', 'gotthardresin-child-theme'),
            (string) $data['theme']
        );
    }

    foreach ((array) ($data['pages'] ?? array()) as $item) {
        $slug = sanitize_title((string) ($item['slug'] ?? ''));
        if ($slug === '') {
            continue;
        }
        $existing = gotthardresin_ct_find_post(sanitize_text_field((string) ($item['path'] ?? '')), $slug, 'page');
        $preview['pages'][] = array(
            'slug'   => $slug,
            'title'  => sanitize_text_field((string) ($item['title'] ?? $slug)),
            'status' => in_array($item['status'] ?? '', gotthardresin_ct_statuses(), true) ? $item['status'] : 'publish',
            'action' => $existing ? 'update' : 'create',
        );
    }
    foreach ((array) ($data['options'] ?? array()) as $name => $value) {
        if (gotthardresin_ct_option_type($name) !== '') {
            $preview['options'][] = (string) $name;
        }
    }
    foreach ((array) ($data['theme_mods'] ?? array()) as $key => $value) {
        if (strpos((string) $key, 'gotthardresin_') === 0) {
            $preview['theme_mods']++;
        }
    }
    foreach ((array) ($data['locations'] ?? array()) as $location => $menu_name) {
        $preview['locations'][sanitize_key($location)] = sanitize_text_field((string) $menu_name);
    }
    foreach ((array) ($data['menus'] ?? array()) as $menu) {
        $name = sanitize_text_field((string) ($menu['name'] ?? ''));
        if ($name === '') {
            continue;
        }
        $preview['menus'][] = array(
            'name'   => $name,
            'items'  => is_array($menu['items'] ?? null) ? count($menu['items']) : 0,
            'exists' => (bool) wp_get_nav_menu_object($name),
        );
    }
    if (!post_type_exists('tw_faq') && !empty($data['faqs'])) {
        $preview['warnings'][] = __('Le schede FAQ non si possono importare: il tema parent su questo sito non le prevede.', 'gotthardresin-child-theme');
    }
    foreach ((array) ($data['faqs'] ?? array()) as $item) {
        $slug = sanitize_title((string) ($item['slug'] ?? ''));
        if ($slug === '') {
            continue;
        }
        $preview['faqs'][] = array(
            'slug'   => $slug,
            'title'  => sanitize_text_field((string) ($item['title'] ?? $slug)),
            'action' => gotthardresin_ct_find_post('', $slug, 'tw_faq') ? 'update' : 'create',
        );
    }
    foreach ((array) ($data['media'] ?? array()) as $entry) {
        $file = sanitize_file_name((string) ($entry['file'] ?? ''));
        if ($file === '') {
            continue;
        }
        $row = array('file' => $file, 'width' => absint($entry['width'] ?? 0), 'height' => absint($entry['height'] ?? 0));
        if (gotthardresin_ct_find_attachment($file)) {
            $preview['images_found'][] = $row;
        } else {
            $preview['images_missing'][] = $row;
        }
    }
    return $preview;
}

/* -------------------------------------------------------------------------
 * Importazione vera e propria (idempotente per slug/chiave)
 * ---------------------------------------------------------------------- */

function gotthardresin_ct_run_import(array $data)
{
    $report = array(
        'pages_created' => array(), 'pages_updated' => array(), 'pages_skipped' => array(),
        'options' => array(), 'theme_mods' => array(), 'locations' => array(),
        'menus' => array(), 'faq_created' => array(), 'faq_updated' => array(),
        'images_found' => array(), 'images_missing' => array(), 'warnings' => array(),
    );
    $found   = array();
    $missing = array();
    $ids     = array(); // percorso/slug della pagina → ID su questo sito

    // 1) Pagine: prima i genitori, poi le figlie.
    $pages = array_filter((array) ($data['pages'] ?? array()), 'is_array');
    usort($pages, function ($a, $b) {
        return substr_count((string) ($a['path'] ?? ''), '/') <=> substr_count((string) ($b['path'] ?? ''), '/');
    });
    foreach ($pages as $item) {
        $slug = sanitize_title((string) ($item['slug'] ?? ''));
        if ($slug === '') {
            continue;
        }
        $path     = sanitize_text_field((string) ($item['path'] ?? $slug));
        $existing = gotthardresin_ct_find_post($path, $slug, 'page');
        $parent   = sanitize_title((string) ($item['parent'] ?? ''));
        $parent_id = 0;
        if ($parent !== '') {
            $parent_post = isset($ids[$parent]) ? get_post($ids[$parent]) : gotthardresin_ct_find_post('', $parent, 'page');
            $parent_id   = $parent_post instanceof WP_Post ? (int) $parent_post->ID : 0;
        }
        $status  = in_array($item['status'] ?? '', gotthardresin_ct_statuses(), true) ? $item['status'] : 'publish';
        $postarr = array(
            'post_type'    => 'page',
            'post_name'    => $slug,
            'post_title'   => gotthardresin_ct_sanitize($item['title'] ?? $slug, 'text'),
            'post_content' => gotthardresin_ct_sanitize(gotthardresin_ct_decode_text((string) ($item['content'] ?? ''), $found, $missing), 'html'),
            'post_excerpt' => gotthardresin_ct_sanitize(gotthardresin_ct_decode_text((string) ($item['excerpt'] ?? ''), $found, $missing), 'html'),
            'post_status'  => $status,
            'menu_order'   => (int) ($item['menu_order'] ?? 0),
            'post_parent'  => $parent_id,
        );
        if ($existing) {
            $postarr['ID'] = $existing->ID;
            $result = wp_update_post(wp_slash($postarr), true);
        } else {
            $result = wp_insert_post(wp_slash($postarr), true);
        }
        if (is_wp_error($result) || !$result) {
            $report['pages_skipped'][] = $slug;
            continue;
        }
        $page_id = (int) $result;
        $ids[$slug] = $page_id;
        $ids[$path] = $page_id;

        // Meta della pagina (solo quelli della lista bianca).
        $meta = is_array($item['meta'] ?? null) ? $item['meta'] : array();
        if (!isset($meta['_wp_page_template']) && isset($item['template'])) {
            $meta['_wp_page_template'] = $item['template'];
        }
        foreach (gotthardresin_ct_page_meta_types() as $key => $type) {
            if (!array_key_exists($key, $meta)) {
                continue;
            }
            if ($type === 'image') {
                $thumb = gotthardresin_ct_decode_id($meta[$key], $found, $missing);
                if ($thumb > 0) {
                    update_post_meta($page_id, $key, $thumb);
                }
                continue;
            }
            $value = gotthardresin_ct_sanitize(gotthardresin_ct_decode_text((string) (is_scalar($meta[$key]) ? $meta[$key] : ''), $found, $missing), $type);
            if ($value === '' || ($type === 'template' && $value === 'default')) {
                delete_post_meta($page_id, $key);
            } else {
                update_post_meta($page_id, $key, $value);
            }
        }
        $report[$existing ? 'pages_updated' : 'pages_created'][] = $slug;
    }

    // 2) Schede FAQ (parent): per slug, con i loro meta.
    if (post_type_exists('tw_faq')) {
        foreach ((array) ($data['faqs'] ?? array()) as $item) {
            $slug = sanitize_title((string) ($item['slug'] ?? ''));
            if (!is_array($item) || $slug === '') {
                continue;
            }
            $existing = gotthardresin_ct_find_post('', $slug, 'tw_faq');
            $postarr  = array(
                'post_type'   => 'tw_faq',
                'post_name'   => $slug,
                'post_title'  => gotthardresin_ct_sanitize($item['title'] ?? $slug, 'text'),
                'post_status' => in_array($item['status'] ?? '', gotthardresin_ct_statuses(), true) ? $item['status'] : 'publish',
                'menu_order'  => (int) ($item['menu_order'] ?? 0),
            );
            if ($existing) {
                $postarr['ID'] = $existing->ID;
                $result = wp_update_post(wp_slash($postarr), true);
            } else {
                $result = wp_insert_post(wp_slash($postarr), true);
            }
            if (is_wp_error($result) || !$result) {
                $report['warnings'][] = sprintf(
                    /* translators: %s: slug della scheda */
                    __('Scheda FAQ «%s» non salvata.', 'gotthardresin-child-theme'),
                    $slug
                );
                continue;
            }
            foreach ((array) ($item['meta'] ?? array()) as $key => $value) {
                $key = sanitize_key($key);
                if (!gotthardresin_ct_faq_meta_allowed($key)) {
                    continue;
                }
                $value = gotthardresin_ct_decode_deep($value, $found, $missing);
                if ($key === '_tw_faq_items') {
                    $value = function_exists('ticinoweb_faq_sanitize_items')
                        ? ticinoweb_faq_sanitize_items(wp_slash(is_array($value) ? $value : array()))
                        : gotthardresin_ct_sanitize_deep(is_array($value) ? $value : array(), 'wp_kses_post');
                } elseif ($key === '_tw_faq_sections') {
                    $value = gotthardresin_ct_sanitize_deep(is_array($value) ? $value : array(), 'sanitize_textarea_field');
                } elseif (is_array($value)) {
                    $value = gotthardresin_ct_sanitize_deep($value, 'wp_kses_post');
                } else {
                    $value = gotthardresin_ct_sanitize($value, 'html');
                }
                update_post_meta((int) $result, $key, $value);
            }
            $report[$existing ? 'faq_updated' : 'faq_created'][] = $slug;
        }
    } elseif (!empty($data['faqs'])) {
        $report['warnings'][] = __('Schede FAQ non importate: il tema parent su questo sito non le prevede.', 'gotthardresin-child-theme');
    }

    // 3) Opzioni del CMS: solo la lista bianca, ognuna pulita secondo il suo tipo.
    foreach ((array) ($data['options'] ?? array()) as $name => $value) {
        $name = (string) $name;
        $type = gotthardresin_ct_option_type($name);
        if ($type === '') {
            continue;
        }
        if ($type === 'page') {
            $path = sanitize_text_field((string) (is_scalar($value) ? $value : ''));
            if ($path === '') {
                update_option($name, 0);
                $report['options'][] = $name;
                continue;
            }
            $page = isset($ids[$path]) ? get_post($ids[$path]) : gotthardresin_ct_find_post($path, sanitize_title(basename($path)), 'page');
            if (!$page instanceof WP_Post) {
                $report['warnings'][] = sprintf(
                    /* translators: 1: nome dell'opzione, 2: slug della pagina */
                    __('Opzione %1$s non scritta: la pagina «%2$s» non esiste su questo sito.', 'gotthardresin-child-theme'),
                    $name,
                    $path
                );
                continue;
            }
            update_option($name, (int) $page->ID);
            $report['options'][] = $name;
            continue;
        }
        $value = gotthardresin_ct_decode_deep($value, $found, $missing);
        update_option($name, gotthardresin_ct_sanitize($value, $type));
        $report['options'][] = $name;
    }

    // 4) Impostazioni del tema (Customizer → Gotthard Resin).
    foreach ((array) ($data['theme_mods'] ?? array()) as $key => $value) {
        $key = sanitize_key($key);
        if (strpos($key, 'gotthardresin_') !== 0) {
            continue;
        }
        if (is_string($value) && strpos($value, GOTTHARDRESIN_CT_TOKEN) === 0) {
            $id = gotthardresin_ct_decode_id($value, $found, $missing);
            if ($id > 0) {
                set_theme_mod($key, $id);
                $report['theme_mods'][] = $key;
            }
            continue;
        }
        if (is_bool($value) || is_int($value) || is_float($value)) {
            set_theme_mod($key, $value);
        } elseif (is_array($value)) {
            set_theme_mod($key, gotthardresin_ct_sanitize_deep(gotthardresin_ct_decode_deep($value, $found, $missing), 'sanitize_text_field'));
        } else {
            $string = gotthardresin_ct_decode_text((string) $value, $found, $missing);
            set_theme_mod($key, preg_match('~^https?://~i', $string) ? esc_url_raw($string) : sanitize_text_field($string));
        }
        $report['theme_mods'][] = $key;
    }

    // 5) Menu di navigazione: per nome; le voci vengono ricreate tali e quali (idempotente).
    foreach ((array) ($data['menus'] ?? array()) as $menu) {
        if (!is_array($menu)) {
            continue;
        }
        $name = gotthardresin_ct_sanitize($menu['name'] ?? '', 'text');
        if ($name === '') {
            continue;
        }
        $object  = wp_get_nav_menu_object($name);
        $menu_id = $object ? (int) $object->term_id : wp_create_nav_menu($name);
        if (is_wp_error($menu_id) || !$menu_id) {
            $report['warnings'][] = sprintf(
                /* translators: %s: nome del menu */
                __('Menu «%s» non creato.', 'gotthardresin-child-theme'),
                $name
            );
            continue;
        }
        foreach ((array) wp_get_nav_menu_items($menu_id, array('post_status' => 'any', 'update_post_term_cache' => false)) as $old) {
            wp_delete_post((int) $old->ID, true);
        }
        $created = 0;
        $skipped = 0;
        $args_by_ref = array();
        $new_by_ref  = array();
        $items = array_filter((array) ($menu['items'] ?? array()), 'is_array');
        usort($items, function ($a, $b) {
            return (int) ($a['order'] ?? 0) <=> (int) ($b['order'] ?? 0);
        });
        foreach ($items as $position => $item) {
            $args = gotthardresin_ct_menu_item_args($item, $position + 1, $ids, $found, $missing);
            if (!$args) {
                $skipped++;
                continue;
            }
            $new_id = wp_update_nav_menu_item($menu_id, 0, $args);
            if (is_wp_error($new_id) || !$new_id) {
                $skipped++;
                continue;
            }
            $ref = (int) ($item['ref'] ?? 0);
            if ($ref) {
                $args_by_ref[$ref] = array('id' => (int) $new_id, 'args' => $args, 'parent' => (int) ($item['parent'] ?? 0));
                $new_by_ref[$ref]  = (int) $new_id;
            }
            $created++;
        }
        foreach ($args_by_ref as $ref => $row) {
            if ($row['parent'] && isset($new_by_ref[$row['parent']])) {
                $row['args']['menu-item-parent-id'] = $new_by_ref[$row['parent']];
                wp_update_nav_menu_item($menu_id, $row['id'], $row['args']);
            }
        }
        $report['menus'][] = array('name' => $name, 'items' => $created, 'skipped' => $skipped, 'created' => !$object);
    }

    // 6) Posizioni dei menu (per nome del menu): solo quelle presenti nel file.
    if (!empty($data['locations']) && is_array($data['locations'])) {
        $locations  = (array) get_theme_mod('nav_menu_locations', array());
        $registered = get_registered_nav_menus();
        foreach ($data['locations'] as $location => $menu_name) {
            $location = sanitize_key($location);
            if ($location === '' || !isset($registered[$location])) {
                continue;
            }
            $menu_name = gotthardresin_ct_sanitize($menu_name, 'text');
            $object    = $menu_name !== '' ? wp_get_nav_menu_object($menu_name) : false;
            $locations[$location] = $object ? (int) $object->term_id : 0;
            $report['locations'][] = $location . ' → ' . ($object ? $menu_name : '—');
        }
        set_theme_mod('nav_menu_locations', $locations);
    }

    // 6b) Gallerie del parent: la galleria per slug (creata se manca), le foto trovate per nome file, l'ordine.
    $report['galleries'] = array();
    if (taxonomy_exists('ticinoweb_media_gallery')) {
        foreach ((array) ($data['galleries'] ?? array()) as $gallery) {
            $slug = sanitize_title((string) ($gallery['slug'] ?? ''));
            $name = sanitize_text_field((string) ($gallery['name'] ?? ''));
            if ($slug === '' || $name === '') {
                continue;
            }
            $term = get_term_by('slug', $slug, 'ticinoweb_media_gallery');
            if (!$term) {
                $made = wp_insert_term($name, 'ticinoweb_media_gallery', array('slug' => $slug, 'description' => sanitize_textarea_field((string) ($gallery['description'] ?? ''))));
                if (is_wp_error($made)) {
                    $report['warnings'][] = sprintf(__('Galleria «%s» non creata.', 'gotthardresin-child-theme'), $name);
                    continue;
                }
                $term = get_term((int) $made['term_id'], 'ticinoweb_media_gallery');
            }
            $order = array();
            foreach ((array) ($gallery['images'] ?? array()) as $token) {
                $id = gotthardresin_ct_decode_id($token, $found, $missing);
                if ($id) {
                    wp_set_object_terms($id, (int) $term->term_id, 'ticinoweb_media_gallery', true);
                    $order[] = $id;
                }
            }
            update_term_meta((int) $term->term_id, '_ticinoweb_gallery_order', $order);
            $report['galleries'][] = sprintf('%s (%d)', $name, count($order));
        }
    } elseif (!empty($data['galleries'])) {
        $report['warnings'][] = __('Gallerie non importate: il tema parent su questo sito non le prevede.', 'gotthardresin-child-theme');
    }

    // 7) Immagini: trovate e mancanti (con le dimensioni dall'indice del file).
    $dims = array();
    foreach ((array) ($data['media'] ?? array()) as $entry) {
        if (is_array($entry) && !empty($entry['file'])) {
            $dims[sanitize_file_name((string) $entry['file'])] = array('width' => absint($entry['width'] ?? 0), 'height' => absint($entry['height'] ?? 0));
        }
    }
    $report['images_found'] = array_values(array_unique(array_map('sanitize_file_name', array_keys($found))));
    foreach (array_keys($missing) as $file) {
        $file = sanitize_file_name($file);
        $plain = preg_replace('/-scaled(?=\.[a-z0-9]+$)/i', '', preg_replace('/-\d+x\d+(?=\.[a-z0-9]+$)/i', '', $file));
        $info = $dims[$file] ?? ($dims[$plain] ?? array('width' => 0, 'height' => 0));
        $report['images_missing'][$plain] = array('file' => $plain, 'width' => $info['width'], 'height' => $info['height']);
    }
    $report['images_missing'] = array_values($report['images_missing']);
    sort($report['images_found']);

    // 8) Cache del tema e di LiteSpeed.
    if (function_exists('gotthardresin_ct_flush_caches')) {
        gotthardresin_ct_flush_caches();
    }
    do_action('litespeed_purge_all');

    return $report;
}

/**
 * Argomenti per wp_update_nav_menu_item() da una voce esportata. Null se la voce non si può
 * ricreare su questo sito (pagina o categoria assente).
 */
function gotthardresin_ct_menu_item_args(array $item, $position, array $ids, array &$found, array &$missing)
{
    $type   = in_array($item['type'] ?? '', array('post_type', 'taxonomy', 'custom', 'post_type_archive'), true) ? $item['type'] : 'custom';
    $object = sanitize_key((string) ($item['object'] ?? ''));
    $args   = array(
        'menu-item-title'       => gotthardresin_ct_sanitize($item['title'] ?? '', 'text'),
        'menu-item-type'        => $type,
        'menu-item-object'      => $object,
        'menu-item-object-id'   => 0,
        'menu-item-url'         => '',
        'menu-item-target'      => ($item['target'] ?? '') === '_blank' ? '_blank' : '',
        'menu-item-classes'     => gotthardresin_ct_sanitize($item['classes'] ?? '', 'text'),
        'menu-item-xfn'         => gotthardresin_ct_sanitize($item['xfn'] ?? '', 'text'),
        'menu-item-attr-title'  => gotthardresin_ct_sanitize($item['attr_title'] ?? '', 'text'),
        'menu-item-description' => gotthardresin_ct_sanitize($item['description'] ?? '', 'textarea'),
        'menu-item-status'      => 'publish',
        'menu-item-position'    => (int) $position,
        'menu-item-parent-id'   => 0,
    );
    $slug = sanitize_text_field((string) ($item['slug'] ?? ''));
    if ($type === 'post_type') {
        if ($object === '' || !post_type_exists($object) || $slug === '') {
            return null;
        }
        if ($object === 'page' && isset($ids[$slug])) {
            $args['menu-item-object-id'] = (int) $ids[$slug];
        } else {
            $post = gotthardresin_ct_find_post($slug, sanitize_title(basename($slug)), $object);
            if (!$post) {
                return null;
            }
            $args['menu-item-object-id'] = (int) $post->ID;
        }
        return $args;
    }
    if ($type === 'taxonomy') {
        if ($object === '' || !taxonomy_exists($object) || $slug === '') {
            return null;
        }
        $term = get_term_by('slug', sanitize_title($slug), $object);
        if (!$term instanceof WP_Term) {
            return null;
        }
        $args['menu-item-object-id'] = (int) $term->term_id;
        return $args;
    }
    if ($type === 'post_type_archive') {
        return ($object !== '' && post_type_exists($object)) ? $args : null;
    }
    $url = gotthardresin_ct_decode_text((string) ($item['url'] ?? ''), $found, $missing);
    $url = ($url !== '' && $url[0] === '#') ? '#' . sanitize_text_field(substr($url, 1)) : esc_url_raw($url);
    $args['menu-item-url'] = $url !== '' ? $url : '#';
    return $args;
}

/* -------------------------------------------------------------------------
 * Pagina in bacheca: Strumenti → Gotthard Resin: Porta sul sito
 * ---------------------------------------------------------------------- */

add_action('admin_menu', function () {
    add_management_page(
        __('Gotthard Resin: Porta sul sito', 'gotthardresin-child-theme'),
        __('Gotthard Resin: Porta sul sito', 'gotthardresin-child-theme'),
        'manage_options',
        GOTTHARDRESIN_CT_SLUG,
        'gotthardresin_ct_render_page'
    );
});

function gotthardresin_ct_render_page()
{
    if (!current_user_can('manage_options')) {
        wp_die(esc_html__('Non hai i permessi per questa pagina.', 'gotthardresin-child-theme'));
    }
    $step    = isset($_GET['step']) ? sanitize_key(wp_unslash($_GET['step'])) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    $pending = gotthardresin_ct_pending();
    $error   = get_transient('gotthardresin_ct_error_' . get_current_user_id());
    if ($error) {
        delete_transient('gotthardresin_ct_error_' . get_current_user_id());
    }
    $report = $step === 'done' ? get_option(gotthardresin_ct_report_key()) : null;
    if ($report) {
        // Il resoconto si legge una volta sola: non resta nel database.
        delete_option(gotthardresin_ct_report_key());
    }
    ?>
    <div class="wrap">
        <h1><?php esc_html_e('Gotthard Resin: Porta sul sito', 'gotthardresin-child-theme'); ?></h1>

        <?php if ($error) : ?>
            <div class="notice notice-error"><p><?php echo esc_html((string) $error); ?></p></div>
        <?php endif; ?>

        <p><?php esc_html_e('Copia i contenuti di questo sito dal sito di prova al sito pubblico. Si fa in due passi: sul sito di partenza scarichi un file, sul sito di destinazione lo carichi, leggi l\'anteprima e confermi. Quello che esiste già con lo stesso nome viene aggiornato, non duplicato: puoi ripetere l\'operazione quante volte vuoi.', 'gotthardresin-child-theme'); ?></p>
        <p>
            <strong><?php esc_html_e('Porta:', 'gotthardresin-child-theme'); ?></strong>
            <?php esc_html_e('le pagine (testi, immagine in evidenza, titolo e descrizione per Google, scheda FAQ collegata), i contatti e gli orari, il logo, l\'icona e il colore del sito, le impostazioni SEO, cookie e privacy, i codici di Google, la pagina iniziale e il nome del sito, le impostazioni «Gotthard Resin» di Aspetto → Personalizza, i menu di navigazione e le schede FAQ.', 'gotthardresin-child-theme'); ?>
        </p>
        <p>
            <strong><?php esc_html_e('Non porta:', 'gotthardresin-child-theme'); ?></strong>
            <?php esc_html_e('articoli, utenti, invii dei moduli, chiavi (reCAPTCHA, SMTP) e licenze, plugin. E nemmeno i file delle immagini: le foto devono essere già caricate nella Libreria media del sito di destinazione con lo stesso nome di file, così lo strumento le riaggancia da solo. Quelle che mancano te le elenca.', 'gotthardresin-child-theme'); ?>
        </p>

        <?php if ($report && is_array($report)) : ?>
            <?php gotthardresin_ct_render_report($report); ?>
        <?php endif; ?>

        <?php if ($pending && $step === 'preview') : ?>
            <?php gotthardresin_ct_render_preview($pending); ?>
        <?php elseif ($pending) : ?>
            <div class="notice notice-info"><p>
                <?php esc_html_e('C\'è un file caricato in attesa di conferma.', 'gotthardresin-child-theme'); ?>
                <a href="<?php echo esc_url(gotthardresin_ct_page_url(array('step' => 'preview'))); ?>"><?php esc_html_e('Vedi l\'anteprima', 'gotthardresin-child-theme'); ?></a>
            </p></div>
        <?php endif; ?>

        <div class="card" style="max-width:760px;padding:20px;margin-top:24px;">
            <h2><?php esc_html_e('1. Esporta (sul sito di partenza)', 'gotthardresin-child-theme'); ?></h2>
            <p><?php esc_html_e('Scarica il file con i contenuti di questo sito. È un file di testo leggero: le immagini non sono incluse, viaggiano per nome.', 'gotthardresin-child-theme'); ?></p>
            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                <input type="hidden" name="action" value="gotthardresin_ct_export">
                <?php wp_nonce_field('gotthardresin_ct_export'); ?>
                <?php submit_button(__('Scarica i contenuti', 'gotthardresin-child-theme'), 'primary', 'submit', false); ?>
            </form>
        </div>

        <div class="card" style="max-width:760px;padding:20px;margin-top:24px;">
            <h2><?php esc_html_e('2. Importa (sul sito di destinazione)', 'gotthardresin-child-theme'); ?></h2>
            <p><?php echo esc_html(sprintf(
                /* translators: %s: dimensione massima */
                __('Scegli il file .json scaricato al passo 1 (massimo %s). Prima di scrivere qualcosa vedrai un\'anteprima di ciò che cambierà e potrai confermare o annullare.', 'gotthardresin-child-theme'),
                size_format(GOTTHARDRESIN_CT_MAX_BYTES)
            )); ?></p>
            <form method="post" enctype="multipart/form-data" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                <input type="hidden" name="action" value="gotthardresin_ct_upload">
                <input type="hidden" name="MAX_FILE_SIZE" value="<?php echo esc_attr((string) GOTTHARDRESIN_CT_MAX_BYTES); ?>">
                <?php wp_nonce_field('gotthardresin_ct_upload'); ?>
                <p><input type="file" name="gotthardresin_ct_file" accept="application/json,.json" required></p>
                <?php submit_button(__('Carica e mostra l\'anteprima', 'gotthardresin-child-theme'), 'secondary', 'submit', false); ?>
            </form>
        </div>

    </div>
    <?php
}

/** Anteprima del file in attesa, con i pulsanti Conferma e Annulla. */
function gotthardresin_ct_render_preview(array $pending)
{
    $preview = gotthardresin_ct_preview($pending['data']);
    $data    = $pending['data'];
    $create  = count(array_filter($preview['pages'], function ($p) { return $p['action'] === 'create'; }));
    $update  = count($preview['pages']) - $create;
    ?>
    <div class="card" style="max-width:760px;padding:20px;margin-top:24px;border-left:4px solid #2271b1;">
        <h2><?php esc_html_e('Anteprima: cosa cambierà su questo sito', 'gotthardresin-child-theme'); ?></h2>
        <p>
            <?php echo esc_html(sprintf(
                /* translators: 1: nome del file, 2: sito di partenza, 3: data */
                __('File «%1$s», esportato da %2$s il %3$s.', 'gotthardresin-child-theme'),
                $pending['name'],
                (string) ($data['site_name'] ?? $data['source_url'] ?? ''),
                !empty($data['exported_at']) ? wp_date(get_option('date_format') . ' ' . get_option('time_format'), strtotime((string) $data['exported_at'])) : ''
            )); ?>
        </p>
        <?php foreach ($preview['warnings'] as $warning) : ?>
            <div class="notice notice-warning inline"><p><?php echo esc_html($warning); ?></p></div>
        <?php endforeach; ?>

        <h3><?php echo esc_html(sprintf(
            /* translators: 1: pagine da creare, 2: pagine da aggiornare */
            __('Pagine: %1$d da creare, %2$d da aggiornare', 'gotthardresin-child-theme'),
            $create,
            $update
        )); ?></h3>
        <?php if ($preview['pages']) : ?>
            <table class="widefat striped" style="margin-bottom:16px;">
                <thead><tr><th><?php esc_html_e('Pagina', 'gotthardresin-child-theme'); ?></th><th><?php esc_html_e('Slug', 'gotthardresin-child-theme'); ?></th><th><?php esc_html_e('Stato', 'gotthardresin-child-theme'); ?></th><th><?php esc_html_e('Azione', 'gotthardresin-child-theme'); ?></th></tr></thead>
                <tbody>
                <?php foreach ($preview['pages'] as $page) : ?>
                    <tr>
                        <td><?php echo esc_html($page['title']); ?></td>
                        <td><code><?php echo esc_html($page['slug']); ?></code></td>
                        <td><?php echo esc_html(gotthardresin_ct_status_label($page['status'])); ?></td>
                        <td><?php echo $page['action'] === 'create' ? esc_html__('Crea', 'gotthardresin-child-theme') : esc_html__('Aggiorna', 'gotthardresin-child-theme'); ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>

        <h3><?php echo esc_html(sprintf(
            /* translators: %d: numero di opzioni */
            __('Impostazioni del sito: %d da scrivere', 'gotthardresin-child-theme'),
            count($preview['options'])
        )); ?></h3>
        <?php if ($preview['options']) : ?>
            <p class="description"><?php echo esc_html(implode(', ', $preview['options'])); ?></p>
        <?php endif; ?>

        <h3><?php echo esc_html(sprintf(
            /* translators: %d: numero di impostazioni */
            __('Impostazioni «Gotthard Resin» (Aspetto → Personalizza): %d', 'gotthardresin-child-theme'),
            $preview['theme_mods']
        )); ?></h3>

        <h3><?php esc_html_e('Menu di navigazione', 'gotthardresin-child-theme'); ?></h3>
        <?php if ($preview['menus']) : ?>
            <ul>
                <?php foreach ($preview['menus'] as $menu) : ?>
                    <li><?php echo esc_html(sprintf(
                        /* translators: 1: nome del menu, 2: numero di voci, 3: nuovo/esistente */
                        __('«%1$s»: %2$d voci (%3$s)', 'gotthardresin-child-theme'),
                        $menu['name'],
                        $menu['items'],
                        $menu['exists'] ? __('le voci attuali vengono sostituite', 'gotthardresin-child-theme') : __('nuovo menu', 'gotthardresin-child-theme')
                    )); ?></li>
                <?php endforeach; ?>
                <?php foreach ($preview['locations'] as $location => $menu_name) : ?>
                    <li><?php echo esc_html(sprintf(
                        /* translators: 1: posizione, 2: nome del menu */
                        __('Posizione «%1$s» → menu «%2$s»', 'gotthardresin-child-theme'),
                        $location,
                        $menu_name !== '' ? $menu_name : '—'
                    )); ?></li>
                <?php endforeach; ?>
            </ul>
        <?php else : ?>
            <p class="description"><?php esc_html_e('Nessun menu nel file.', 'gotthardresin-child-theme'); ?></p>
        <?php endif; ?>

        <h3><?php echo esc_html(sprintf(
            /* translators: %d: numero di schede */
            __('Schede FAQ: %d', 'gotthardresin-child-theme'),
            count($preview['faqs'])
        )); ?></h3>
        <?php if ($preview['faqs']) : ?>
            <ul>
                <?php foreach ($preview['faqs'] as $faq) : ?>
                    <li><?php echo esc_html($faq['title']); ?> (<code><?php echo esc_html($faq['slug']); ?></code>): <?php echo $faq['action'] === 'create' ? esc_html__('crea', 'gotthardresin-child-theme') : esc_html__('aggiorna', 'gotthardresin-child-theme'); ?></li>
                <?php endforeach; ?>
            </ul>
        <?php endif; ?>

        <?php if (!empty($preview['galleries'])) : ?>
            <h3><?php esc_html_e('Gallerie (foto e ordine)', 'gotthardresin-child-theme'); ?></h3>
            <p><?php echo esc_html(implode(', ', $preview['galleries'])); ?></p>
        <?php endif; ?>

        <h3><?php echo esc_html(sprintf(
            /* translators: 1: immagini trovate, 2: immagini mancanti */
            __('Immagini: %1$d trovate nella Libreria media, %2$d mancanti', 'gotthardresin-child-theme'),
            count($preview['images_found']),
            count($preview['images_missing'])
        )); ?></h3>
        <?php gotthardresin_ct_render_missing($preview['images_missing'], __('Puoi caricarle ora nella Libreria media (stesso nome di file) e poi confermare, oppure confermare lo stesso e rifare l\'importazione in seguito.', 'gotthardresin-child-theme')); ?>

        <div style="display:flex;gap:12px;align-items:center;margin-top:16px;">
            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                <input type="hidden" name="action" value="gotthardresin_ct_import">
                <input type="hidden" name="gotthardresin_ct_token" value="<?php echo esc_attr($pending['token']); ?>">
                <?php wp_nonce_field('gotthardresin_ct_import'); ?>
                <?php submit_button(__('Conferma e importa', 'gotthardresin-child-theme'), 'primary', 'submit', false); ?>
            </form>
            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                <input type="hidden" name="action" value="gotthardresin_ct_cancel">
                <?php wp_nonce_field('gotthardresin_ct_cancel'); ?>
                <?php submit_button(__('Annulla', 'gotthardresin-child-theme'), 'secondary', 'submit', false); ?>
            </form>
        </div>
    </div>
    <?php
}

/** Resoconto dell'ultima importazione. */
function gotthardresin_ct_render_report(array $report)
{
    ?>
    <div class="card" style="max-width:760px;padding:20px;margin-top:24px;border-left:4px solid #00a32a;">
        <h2><?php esc_html_e('Importazione completata', 'gotthardresin-child-theme'); ?></h2>
        <?php if (!empty($report['file'])) : ?>
            <p class="description"><?php echo esc_html(sprintf(
                /* translators: 1: nome del file, 2: data e ora */
                __('File «%1$s», importato il %2$s.', 'gotthardresin-child-theme'),
                (string) $report['file'],
                wp_date(get_option('date_format') . ' ' . get_option('time_format'), (int) ($report['time'] ?? time()))
            )); ?></p>
        <?php endif; ?>
        <ul>
            <li><?php echo esc_html(sprintf(
                /* translators: 1: create, 2: aggiornate */
                __('Pagine: %1$d create, %2$d aggiornate.', 'gotthardresin-child-theme'),
                count($report['pages_created']),
                count($report['pages_updated'])
            )); ?>
                <?php if ($report['pages_created']) : ?><br><span class="description"><?php esc_html_e('Create:', 'gotthardresin-child-theme'); ?> <?php echo esc_html(implode(', ', $report['pages_created'])); ?></span><?php endif; ?>
                <?php if ($report['pages_updated']) : ?><br><span class="description"><?php esc_html_e('Aggiornate:', 'gotthardresin-child-theme'); ?> <?php echo esc_html(implode(', ', $report['pages_updated'])); ?></span><?php endif; ?>
                <?php if ($report['pages_skipped']) : ?><br><span class="description"><?php esc_html_e('Non salvate:', 'gotthardresin-child-theme'); ?> <?php echo esc_html(implode(', ', $report['pages_skipped'])); ?></span><?php endif; ?>
            </li>
            <li><?php echo esc_html(sprintf(
                /* translators: %d: numero di opzioni */
                __('Impostazioni del sito scritte: %d.', 'gotthardresin-child-theme'),
                count($report['options'])
            )); ?>
                <?php if ($report['options']) : ?><br><span class="description"><?php echo esc_html(implode(', ', $report['options'])); ?></span><?php endif; ?>
            </li>
            <li><?php echo esc_html(sprintf(
                /* translators: %d: numero */
                __('Impostazioni «Gotthard Resin» scritte: %d.', 'gotthardresin-child-theme'),
                count($report['theme_mods'])
            )); ?></li>
            <li><?php esc_html_e('Menu:', 'gotthardresin-child-theme'); ?>
                <?php if ($report['menus']) : ?>
                    <?php foreach ($report['menus'] as $menu) : ?>
                        <br><span class="description"><?php echo esc_html(sprintf(
                            /* translators: 1: nome, 2: voci, 3: voci saltate */
                            __('«%1$s»: %2$d voci%3$s', 'gotthardresin-child-theme'),
                            $menu['name'],
                            $menu['items'],
                            $menu['skipped'] ? sprintf(
                                /* translators: %d: voci saltate */
                                __(', %d saltate perché la pagina o la categoria non esiste qui', 'gotthardresin-child-theme'),
                                $menu['skipped']
                            ) : ''
                        )); ?></span>
                    <?php endforeach; ?>
                    <?php foreach ($report['locations'] as $line) : ?>
                        <br><span class="description"><?php echo esc_html($line); ?></span>
                    <?php endforeach; ?>
                <?php else : ?>
                    <?php esc_html_e('nessuno.', 'gotthardresin-child-theme'); ?>
                <?php endif; ?>
            </li>
            <li><?php echo esc_html(sprintf(
                /* translators: 1: create, 2: aggiornate */
                __('Schede FAQ: %1$d create, %2$d aggiornate.', 'gotthardresin-child-theme'),
                count($report['faq_created']),
                count($report['faq_updated'])
            )); ?></li>
            <?php if (!empty($report['galleries'])) : ?>
                <li><?php echo esc_html(sprintf(
                    /* translators: %s: gallerie con il numero di foto */
                    __('Gallerie aggiornate: %s.', 'gotthardresin-child-theme'),
                    implode(', ', $report['galleries'])
                )); ?></li>
            <?php endif; ?>
            <li><?php echo esc_html(sprintf(
                /* translators: 1: riagganciate, 2: mancanti */
                __('Immagini: %1$d riagganciate, %2$d mancanti.', 'gotthardresin-child-theme'),
                count($report['images_found']),
                count($report['images_missing'])
            )); ?></li>
        </ul>
        <?php foreach ((array) $report['warnings'] as $warning) : ?>
            <div class="notice notice-warning inline"><p><?php echo esc_html($warning); ?></p></div>
        <?php endforeach; ?>
        <?php gotthardresin_ct_render_missing((array) $report['images_missing'], __('Caricale nella Libreria media con lo stesso nome di file e rifai l\'importazione dello stesso file: le pagine si riaggancieranno da sole.', 'gotthardresin-child-theme')); ?>
    </div>
    <?php
}

/** Elenco delle immagini mancanti con le dimensioni, copiabile. */
function gotthardresin_ct_render_missing(array $missing, $hint)
{
    if (!$missing) {
        return;
    }
    $lines = array();
    foreach ($missing as $row) {
        $size    = (!empty($row['width']) && !empty($row['height'])) ? sprintf(' (%d×%d px)', (int) $row['width'], (int) $row['height']) : '';
        $lines[] = $row['file'] . $size;
    }
    ?>
    <div style="border-left:4px solid #d63638;padding:8px 12px;margin:8px 0;background:#fcf0f1;">
        <p><strong><?php esc_html_e('Immagini mancanti su questo sito', 'gotthardresin-child-theme'); ?></strong><br><?php echo esc_html($hint); ?></p>
        <textarea rows="<?php echo esc_attr((string) min(12, max(3, count($lines)))); ?>" style="width:100%;font-family:monospace;font-size:12px;" onclick="this.select();" readonly><?php echo esc_textarea(implode("\n", $lines)); ?></textarea>
    </div>
    <?php
}

/** Etichetta in italiano di uno stato. */
function gotthardresin_ct_status_label($status)
{
    $labels = array(
        'publish' => __('Pubblicata', 'gotthardresin-child-theme'),
        'draft'   => __('Bozza', 'gotthardresin-child-theme'),
        'private' => __('Privata', 'gotthardresin-child-theme'),
        'pending' => __('In attesa di revisione', 'gotthardresin-child-theme'),
    );
    return $labels[$status] ?? (string) $status;
}
