<?php
/**
 * Funzioni di supporto del tema: testi traducibili dal database, icone in linea, impostazioni del
 * Personalizza, contatti del CMS del parent, gallerie del parent, servizi e immagini.
 * Nessun dato del cliente sta qui: tutto si legge dal database a runtime.
 *
 * @package gotthardresin-child-theme
 */

defined('ABSPATH') || exit;

/**
 * Testo che arriva dal database (impostazioni, CMS) o che non passa da __() come testo visibile:
 * attraversa il livello di traduzione del parent, così tW Translate e WPML lo traducono come gli altri.
 */
function gotthardresin_t($text, $key)
{
    return function_exists('ticinoweb_frontend_text') ? ticinoweb_frontend_text((string) $text, 'gotthardresin:' . $key) : (string) $text;
}

/** URL nella lingua corrente (tW Translate / WPML), tramite il livello del parent. */
function gotthardresin_url($url, $key)
{
    return function_exists('ticinoweb_frontend_url') ? ticinoweb_frontend_url($url, 'gotthardresin:' . $key) : $url;
}

/** Un'impostazione del Personalizza (theme_mod «gotthardresin_<chiave>»). */
function gotthardresin_setting($key, $default = '')
{
    return get_theme_mod('gotthardresin_' . $key, $default);
}

/** Testo di un'impostazione, già passato dal livello di traduzione ('' se vuoto). */
function gotthardresin_text($key)
{
    $value = trim((string) gotthardresin_setting($key, ''));
    return $value === '' ? '' : gotthardresin_t($value, 'setting:' . $key);
}

/** Icone in linea (niente font di icone, niente richieste esterne). */
function gotthardresin_icon($name, $class = '')
{
    $paths = array(
        'arrow'     => array('0 0 12 12', '<path d="M1 6h8M4.5 2.5 8 6l-3.5 3.5" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>'),
        'chev'      => array('0 0 12 12', '<path d="M3 4.5l3 3 3-3" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>'),
        'menu'      => array('0 0 18 18', '<path d="M2 5h14M2 13h14" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/>'),
        'close'     => array('0 0 18 18', '<path d="M4 4l10 10M14 4 4 14" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/>'),
        'facebook'  => array('0 0 24 24', '<path d="M9.1 23.7v-8H6.6V12h2.5v-1.6c0-4.1 1.8-6 5.9-6 .8 0 2.1.2 2.6.3v3.3l-1.4-.1c-1.9 0-2.6.7-2.6 2.6V12h3.9l-.7 3.7h-3.2v8.2c5.9-.7 10.4-5.7 10.4-11.9C24 5.4 18.6 0 12 0S0 5.4 0 12c0 5.6 3.9 10.4 9.1 11.7z" fill="currentColor"/>'),
        'instagram' => array('0 0 24 24', '<rect x="3" y="3" width="18" height="18" rx="5" fill="none" stroke="currentColor" stroke-width="1.8"/><circle cx="12" cy="12" r="4" fill="none" stroke="currentColor" stroke-width="1.8"/><circle cx="17.3" cy="6.7" r="1.2" fill="currentColor"/>'),
        'linkedin'  => array('0 0 24 24', '<path d="M4.98 3.5A2.5 2.5 0 1 1 5 8.5a2.5 2.5 0 0 1 0-5zM3 9.5h4V21H3zm6.5 0h3.8v1.6h.1c.5-1 1.8-2 3.8-2 4 0 4.8 2.6 4.8 6V21h-4v-5.2c0-1.2 0-2.8-1.7-2.8s-2 1.3-2 2.7V21h-4z" fill="currentColor"/>'),
        'youtube'   => array('0 0 24 24', '<path d="M23.5 6.2a3 3 0 0 0-2.1-2.1C19.5 3.6 12 3.6 12 3.6s-7.5 0-9.4.5A3 3 0 0 0 .5 6.2 31 31 0 0 0 0 12a31 31 0 0 0 .5 5.8 3 3 0 0 0 2.1 2.1c1.9.5 9.4.5 9.4.5s7.5 0 9.4-.5a3 3 0 0 0 2.1-2.1A31 31 0 0 0 24 12a31 31 0 0 0-.5-5.8zM9.6 15.6V8.4l6.2 3.6z" fill="currentColor"/>'),
        'tiktok'    => array('0 0 24 24', '<path d="M14 3v9.5a3.5 3.5 0 1 1-3-3.46" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/><path d="M14 3c.5 2.6 2.3 4.3 5 4.5" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>'),
    );
    if (!isset($paths[$name])) {
        return '';
    }
    return '<svg class="gtr-icon gtr-icon--' . esc_attr($name) . ($class ? ' ' . esc_attr($class) : '') . '" viewBox="' . $paths[$name][0] . '" aria-hidden="true" focusable="false">' . $paths[$name][1] . '</svg>';
}

/** La freccia dei bottoni e dei link. */
function gotthardresin_arrow()
{
    return gotthardresin_icon('arrow', 'gtr-arrow');
}

/** Numero di telefono per i link tel: (solo cifre e +). */
function gotthardresin_tel($number)
{
    return 'tel:' . preg_replace('/[^\d+]/', '', (string) $number);
}

/* -------------------------------------------------------------------------
 * Contatti: sempre dal CMS del parent (ticinoweb_contact_*), mai doppioni
 * ---------------------------------------------------------------------- */

/** I contatti del sito, già puliti e tradotti. Ogni voce può essere ''. */
function gotthardresin_contacts()
{
    static $contacts = null;
    if ($contacts !== null) {
        return $contacts;
    }
    $phone   = trim((string) get_option('ticinoweb_contact_phone_mobile', ''));
    $phone   = $phone !== '' ? $phone : trim((string) get_option('ticinoweb_contact_phone', ''));
    $display = trim((string) get_option('ticinoweb_contact_phone_display', ''));
    $address = trim((string) get_option('ticinoweb_contact_address', ''));
    $contacts = array(
        'phone'         => $phone,
        'phone_display' => $display !== '' ? $display : $phone,
        'email'         => sanitize_email((string) get_option('ticinoweb_contact_email', '')),
        'address'       => $address !== '' ? gotthardresin_t($address, 'contact:address') : '',
        'facebook'      => esc_url_raw((string) get_option('ticinoweb_contact_facebook', '')),
        'instagram'     => esc_url_raw((string) get_option('ticinoweb_contact_instagram', '')),
        'linkedin'      => esc_url_raw((string) get_option('ticinoweb_contact_linkedin', '')),
        'youtube'       => esc_url_raw((string) get_option('ticinoweb_contact_youtube', '')),
        'tiktok'        => esc_url_raw((string) get_option('ticinoweb_contact_tiktok', '')),
    );
    return $contacts;
}

/** L'indirizzo su una riga («Via Esempio 1, 6900 Lugano»), dalle righe del CMS. */
function gotthardresin_address_line()
{
    $lines = array_filter(array_map('trim', preg_split('/\r\n|\r|\n|,/', gotthardresin_contacts()['address'])));
    return implode(', ', $lines);
}

/** L'indirizzo breve per il piè di pagina: via e località, senza il numero postale. */
function gotthardresin_address_short()
{
    $line = gotthardresin_address_line();
    return trim((string) preg_replace('/\b\d{4}\s+/', '', $line));
}

/** Indicazioni stradali verso la sede su Google Maps (è un link: nessuna richiesta finché non lo si apre). */
function gotthardresin_map_url()
{
    $line = gotthardresin_address_line();
    return $line === '' ? '' : 'https://www.google.com/maps/dir/?api=1&destination=' . rawurlencode($line);
}

/** Indirizzo della mappa di Google incorporabile (senza chiave API), nella lingua del sito. */
function gotthardresin_map_embed_url()
{
    $line = gotthardresin_address_line();
    if ($line === '') {
        return '';
    }
    return 'https://maps.google.com/maps?q=' . rawurlencode($line) . '&z=11&hl=' . rawurlencode(substr(determine_locale(), 0, 2)) . '&output=embed';
}

/** I social compilati nel CMS, nell'ordine: [rete => url]. */
function gotthardresin_socials()
{
    $out = array();
    foreach (array('facebook', 'instagram', 'linkedin', 'youtube', 'tiktok') as $network) {
        $url = gotthardresin_contacts()[$network];
        if ($url !== '') {
            $out[$network] = $url;
        }
    }
    return $out;
}

/* -------------------------------------------------------------------------
 * Contenuti del CMS del parent
 * ---------------------------------------------------------------------- */

/** I servizi del CMS (titolo, descrizione, immagine), solo quelli con un titolo. */
function gotthardresin_services()
{
    $services = function_exists('ticinoweb_get_services') ? ticinoweb_get_services() : (array) get_option('ticinoweb_services', array());
    return array_values(array_filter((array) $services, function ($service) {
        return is_array($service) && trim((string) ($service['title'] ?? '')) !== '';
    }));
}

/** Le foto di una galleria del parent (Media → Gallerie), nell'ordine scelto nel gestore. */
function gotthardresin_gallery_images($slug, $max = 12)
{
    if (!taxonomy_exists('ticinoweb_media_gallery') || (string) $slug === '') {
        return array();
    }
    $term = get_term_by('slug', sanitize_title($slug), 'ticinoweb_media_gallery');
    if (!($term instanceof WP_Term)) {
        return array();
    }
    $ids = get_posts(array(
        'post_type'      => 'attachment',
        'post_status'    => 'inherit',
        'post_mime_type' => 'image',
        'posts_per_page' => 100,
        'fields'         => 'ids',
        'no_found_rows'  => true,
        'tax_query'      => array(array('taxonomy' => 'ticinoweb_media_gallery', 'field' => 'term_id', 'terms' => $term->term_id)),
    ));
    $order = get_term_meta($term->term_id, '_ticinoweb_gallery_order', true);
    if (is_array($order) && $order) {
        $order = array_map('intval', $order);
        usort($ids, function ($a, $b) use ($order) {
            $pa = array_search((int) $a, $order, true);
            $pb = array_search((int) $b, $order, true);
            return ($pa === false ? 99999 : $pa) <=> ($pb === false ? 99999 : $pb);
        });
    }
    return array_slice(array_map('intval', $ids), 0, (int) $max);
}

/** ID dell'immagine: accetta un ID o un URL della Libreria media (0 se non è un allegato). */
function gotthardresin_image_id($value)
{
    if (is_numeric($value)) {
        return wp_attachment_is_image((int) $value) ? (int) $value : 0;
    }
    $value = (string) $value;
    return $value === '' ? 0 : (int) attachment_url_to_postid($value);
}

/**
 * Un'immagine della Libreria media con srcset e sizes; testo alternativo dalla Libreria.
 * $attrs: classi, loading, sizes. Restituisce '' se l'immagine non c'è.
 */
function gotthardresin_image($value, $size, array $attrs = array())
{
    $id = gotthardresin_image_id($value);
    if (!$id) {
        return '';
    }
    $attrs = array_merge(array('loading' => 'lazy', 'decoding' => 'async'), $attrs);
    $alt   = trim((string) get_post_meta($id, '_wp_attachment_image_alt', true));
    $attrs['alt'] = $alt !== '' ? gotthardresin_t($alt, 'alt:' . $id) : '';
    return wp_get_attachment_image($id, $size, false, $attrs);
}

/** Link della pagina Privacy: l'impostazione del CMS, altrimenti la pagina privacy di WordPress. */
function gotthardresin_privacy_url()
{
    $url = trim((string) get_option('tw_privacy_policy_url', ''));
    if ($url === '' && function_exists('get_privacy_policy_url')) {
        $url = get_privacy_policy_url();
    }
    return $url;
}

/** URL di una sezione della home (#servizi …), anche dalle pagine interne. */
function gotthardresin_section_url($id)
{
    $home = gotthardresin_url(home_url('/'), 'url:home');
    return is_front_page() ? '#' . $id : $home . '#' . $id;
}

/**
 * Mappa 3D di una finitura: se nel tema c'è assets/materiali/<nome-del-file>.webp (rilievo e lucentezza), la card
 * si disegna in WebGL con riflessi veri. Il nome è quello del file originale caricato nella Libreria media.
 * Restituisce ['mappa' => url, 'metallo' => 0-1, 'lucido' => 0-1] oppure null.
 */
function gotthardresin_material_map($attachment_id)
{
    static $props = null;
    if ($props === null) {
        $json  = GOTTHARDRESIN_DIR . '/assets/materiali/materiali.json';
        $props = is_readable($json) ? (array) json_decode((string) file_get_contents($json), true) : array();
    }
    $meta = wp_get_attachment_metadata($attachment_id);
    $file = !empty($meta['original_image']) ? (string) $meta['original_image'] : basename((string) get_attached_file($attachment_id));
    $name = preg_replace('/(-scaled|-\d+)?\.[a-z0-9]+$/i', '', basename($file));
    $name = sanitize_file_name((string) $name);
    if ($name === '' || !is_readable(GOTTHARDRESIN_DIR . '/assets/materiali/' . $name . '.webp')) {
        return null;
    }
    $p = isset($props[$name]) && is_array($props[$name]) ? $props[$name] : array();
    return array(
        'mappa'   => GOTTHARDRESIN_URI . '/assets/materiali/' . rawurlencode($name) . '.webp?ver=' . rawurlencode(GOTTHARDRESIN_VERSION . '.' . (int) @filemtime(GOTTHARDRESIN_DIR . '/assets/materiali/' . $name . '.webp')),
        'metallo' => isset($p['metallo']) ? max(0, min(1, (float) $p['metallo'])) : 0,
        'lucido'  => isset($p['lucido']) ? max(0, min(1, (float) $p['lucido'])) : 0,
    );
}
