<?php
/**
 * Ripiego per ogni vista senza un template proprio (articoli, archivi, ricerca, 404): titolo e testo,
 * oppure il messaggio che la pagina non c'è con il ritorno alla pagina iniziale.
 *
 * @package gotthardresin-child-theme
 */

defined('ABSPATH') || exit;

get_header();
?>
<main id="gtr-main" class="gtr-pagina">
    <div class="gtr-contenitore">
        <div class="gtr-pagina__corpo">
            <?php if (have_posts() && !is_404()) : ?>
                <?php while (have_posts()) : the_post(); ?>
                    <article>
                        <h1><?php the_title(); ?></h1>
                        <div class="gtr-prosa"><?php the_content(); ?></div>
                    </article>
                <?php endwhile; ?>
            <?php else : ?>
                <h1><?php esc_html_e('Pagina non trovata', 'gotthardresin-child-theme'); ?></h1>
                <div class="gtr-prosa">
                    <p><?php esc_html_e('L’indirizzo non porta a nessuna pagina del sito: forse è cambiato.', 'gotthardresin-child-theme'); ?></p>
                    <p><a class="gtr-link" href="<?php echo esc_url(gotthardresin_url(home_url('/'), 'url:home')); ?>"><?php esc_html_e('Vai alla pagina iniziale', 'gotthardresin-child-theme'); ?></a></p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</main>
<?php
get_footer();
