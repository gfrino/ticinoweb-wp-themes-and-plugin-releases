<?php
/** Presentation for the specifically requested editor; native account handling stays in WordPress. */
if (!defined('ABSPATH')) { exit; }
function pons_is_client_editor($user = null) {
    $user = $user instanceof WP_User ? $user : wp_get_current_user();
    return $user->exists() && $user->user_login === 'pons'
        && in_array('editor', $user->roles, true)
        && !in_array('administrator', $user->roles, true)
        && !is_super_admin($user->ID) && !user_can($user, 'manage_options');
}
add_action('admin_menu', static function () {
    if (pons_is_client_editor()) { remove_menu_page('tools.php'); }
}, 999);
add_filter('admin_body_class', static function ($classes) {
    global $pagenow;
    return $pagenow === 'profile.php' && pons_is_client_editor() ? $classes . ' pons-client-profile' : $classes;
});
add_action('admin_enqueue_scripts', static function ($hook) {
    if ($hook !== 'profile.php' || !pons_is_client_editor()) { return; }
    $version = wp_get_theme()->get('Version');
    wp_enqueue_style('pons-client-profile', get_stylesheet_directory_uri() . '/assets/css/client-profile.css', array(), $version);
    wp_enqueue_script('pons-client-profile', get_stylesheet_directory_uri() . '/assets/js/client-profile.js', array('user-profile'), $version, true);
    wp_localize_script('pons-client-profile', 'ponsProfile', array(
        'title' => __('Il tuo profilo', 'ponsenergiasolare'),
        'intro' => __('Aggiorna i tuoi dati e gestisci la sicurezza del tuo accesso.', 'ponsenergiasolare'),
        'identity' => __('I tuoi dati', 'ponsenergiasolare'),
        'contact' => __('Email dell’account', 'ponsenergiasolare'),
        'security' => __('Sicurezza dell’account', 'ponsenergiasolare'),
        'passkeys' => __('Accesso con impronta, volto o PIN', 'ponsenergiasolare'),
        'applications' => __('Collegamenti alle applicazioni', 'ponsenergiasolare'),
        'save' => __('Salva profilo', 'ponsenergiasolare'),
    ));
});
