<?php
/** Field adapter over the existing native Incentivi page blocks. No parallel content storage. */
if (!defined('ABSPATH')) { exit; }
function pons_funding_has_class($block, $class) { return in_array($class, preg_split('/\s+/', $block['attrs']['className'] ?? ''), true); }
function pons_funding_plain($html) { return trim(html_entity_decode(wp_strip_all_tags(preg_replace('/<br\s*\/?\s*>/i', "\n", $html)), ENT_QUOTES | ENT_HTML5, 'UTF-8')); }
function pons_funding_link($block) {
    $tag = new WP_HTML_Tag_Processor($block['innerHTML']);
    return $tag->next_tag('A') ? array('link_label' => pons_funding_plain($block['innerHTML']), 'link_url' => (string) $tag->get_attribute('href')) : null;
}
function pons_funding_group_fields($group) {
    $out = array('title' => '', 'text' => '', 'link_label' => '', 'link_url' => '', 'level' => '', 'note' => '', '_paths' => array());
    foreach ($group['innerBlocks'] as $i => $block) {
        if ($block['blockName'] === 'core/heading' && !isset($out['_paths']['title'])) { $out['title'] = pons_funding_plain($block['innerHTML']); $out['_paths']['title'] = array($i); }
        if ($block['blockName'] === 'core/paragraph') {
            if (pons_funding_has_class($block, 'funding-level')) { $out['level'] = pons_funding_plain($block['innerHTML']); $out['_paths']['level'] = array($i); }
            elseif (pons_funding_has_class($block, 'premium-source-note')) { $out['note'] = pons_funding_plain($block['innerHTML']); $out['_paths']['note'] = array($i); }
            elseif ($link = pons_funding_link($block)) { $out = array_merge($out, $link); $out['_paths']['link'] = array($i); }
            elseif (!isset($out['_paths']['text'])) { $out['text'] = pons_funding_plain($block['innerHTML']); $out['_paths']['text'] = array($i); }
        }
        if ($block['blockName'] === 'core/buttons') {
            foreach ($block['innerBlocks'] as $j => $button) { if ($button['blockName'] === 'core/button' && ($link = pons_funding_link($button))) { $out = array_merge($out, $link); $out['_paths']['link'] = array($i, $j); break; } }
        }
    }
    return $out;
}
function pons_incentives_schema($content) {
    $blocks = parse_blocks($content); $paths = array();
    foreach ($blocks as $i => $block) {
        if (pons_funding_has_class($block, 'premium-editorial-intro')) { $paths['intro'] = $i; }
        elseif (pons_funding_has_class($block, 'funding-programs')) { $paths['programs'] = $i; }
        elseif (pons_funding_has_class($block, 'premium-cta-band')) { $paths['help'] = $i; }
        elseif (isset(pons_funding_group_fields($block)['_paths']['note'])) { $paths['contact'] = $i; }
    }
    if (count($paths) !== 4) { return new WP_Error('structure', __('La struttura della pagina è cambiata. Nessun contenuto è stato modificato: contatta chi gestisce il sito.', 'ponsenergiasolare')); }
    return array('blocks' => $blocks, 'paths' => $paths);
}
function pons_incentives_fingerprint($page) { return hash('sha256', wp_json_encode(array($page->post_title, $page->post_excerpt, $page->post_content, $page->post_modified_gmt, get_post_thumbnail_id($page->ID)))); }
function pons_incentives_fields($page) {
    $schema = pons_incentives_schema($page->post_content); if (is_wp_error($schema)) { return $schema; }
    $out = array('title' => $page->post_title, 'excerpt' => $page->post_excerpt, 'cover' => get_post_thumbnail_id($page->ID), 'fingerprint' => pons_incentives_fingerprint($page), 'programs' => array());
    foreach (array('intro', 'help', 'contact') as $key) { $out[$key] = pons_funding_group_fields($schema['blocks'][$schema['paths'][$key]]); unset($out[$key]['_paths']); }
    foreach ($schema['blocks'][$schema['paths']['programs']]['innerBlocks'] as $i => $block) {
        if (pons_funding_has_class($block, 'funding-program')) { $fields = pons_funding_group_fields($block); unset($fields['_paths']); $fields['source'] = (string) $i; $out['programs'][] = $fields; }
    }
    return $out;
}
function pons_funding_set_text(&$block, $text) {
    $text = sanitize_textarea_field($text);
    if (pons_funding_plain($block['innerHTML']) === $text) { return; }
    $html = preg_replace_callback('~^(\s*<(p|h[1-6])\b[^>]*>).*?(</\2>\s*)$~si', static function ($m) use ($text) { return $m[1] . nl2br(esc_html($text), false) . $m[3]; }, $block['innerHTML'], 1, $count);
    if (!$count) { $tag = $block['blockName'] === 'core/heading' ? 'h' . absint($block['attrs']['level'] ?? 2) : 'p'; $html = '<' . $tag . '>' . nl2br(esc_html($text), false) . '</' . $tag . '>'; }
    $block['innerHTML'] = $html; $block['innerContent'] = array($html);
}
function pons_funding_set_link(&$block, $label, $url) {
    $current = pons_funding_link($block);
    if ($current && $current['link_label'] === $label && $current['link_url'] === $url) { return; }
    $tag = new WP_HTML_Tag_Processor($block['innerHTML']);
    if (!$tag->next_tag('A')) { return; }
    $tag->set_attribute('href', $url);
    $html = preg_replace_callback('~(<a\b[^>]*>).*?(</a>)~si', static function ($m) use ($label) { return $m[1] . esc_html($label) . $m[2]; }, $tag->get_updated_html(), 1);
    $block['innerHTML'] = $html; $block['innerContent'] = array($html);
}
function pons_funding_apply_group(&$group, $input) {
    $fields = pons_funding_group_fields($group);
    foreach (array('title', 'text', 'level', 'note') as $key) {
        if (!isset($fields['_paths'][$key])) { continue; }
        $leaf =& $group; foreach ($fields['_paths'][$key] as $i) { $leaf =& $leaf['innerBlocks'][$i]; }
        pons_funding_set_text($leaf, $input[$key] ?? ''); unset($leaf);
    }
    if (isset($fields['_paths']['link'])) {
        $leaf =& $group; foreach ($fields['_paths']['link'] as $i) { $leaf =& $leaf['innerBlocks'][$i]; }
        pons_funding_set_link($leaf, sanitize_text_field($input['link_label'] ?? ''), esc_url_raw($input['link_url'] ?? '', array('http', 'https'))); unset($leaf);
    }
}
function pons_funding_program_template() {
    $blocks = parse_blocks('<!-- wp:group {"className":"funding-program"} --><div class="wp-block-group funding-program"><!-- wp:paragraph {"className":"funding-level"} --><p class="funding-level"></p><!-- /wp:paragraph --><!-- wp:heading --><h2 class="wp-block-heading"></h2><!-- /wp:heading --><!-- wp:paragraph --><p></p><!-- /wp:paragraph --><!-- wp:paragraph --><p><a href="" target="_blank" rel="noopener"></a></p><!-- /wp:paragraph --></div><!-- /wp:group -->');
    return $blocks[0];
}
function pons_funding_valid_link($input) { return is_string($input['link_url'] ?? null) && preg_match('~^https?://~i', trim($input['link_url'])) && esc_url_raw($input['link_url'], array('http', 'https')) && trim($input['link_label'] ?? '') !== ''; }
function pons_incentives_compile($content, $input) {
    $schema = pons_incentives_schema($content); if (is_wp_error($schema)) { return $schema; }
    if (empty($input['programs']) || count($input['programs']) > 30) { return new WP_Error('programs', __('Inserisci almeno un incentivo e non più di trenta.', 'ponsenergiasolare')); }
    $blocks = $schema['blocks']; $original = $blocks; $paths = $schema['paths'];
    foreach (array('intro', 'help', 'contact') as $key) {
        if (trim($input[$key]['title'] ?? '') === '') { return new WP_Error('title', __('Completa i titoli delle sezioni.', 'ponsenergiasolare')); }
        if ($key !== 'intro' && !pons_funding_valid_link($input[$key])) { return new WP_Error('link', __('Controlla il testo e l’indirizzo dei collegamenti.', 'ponsenergiasolare')); }
        pons_funding_apply_group($blocks[$paths[$key]], $input[$key]);
    }
    $group =& $blocks[$paths['programs']]; $old = $group['innerBlocks']; $new = array(); $sources = array();
    foreach ($input['programs'] as $program) {
        if (trim($program['title'] ?? '') === '' || !pons_funding_valid_link($program)) { return new WP_Error('program', __('Ogni incentivo deve avere un nome e un collegamento valido al sito ufficiale.', 'ponsenergiasolare')); }
        $source = (string) ($program['source'] ?? 'new');
        if ($source !== 'new' && (!ctype_digit($source) || !isset($old[(int) $source]) || !pons_funding_has_class($old[(int) $source], 'funding-program') || in_array($source, $sources, true))) { return new WP_Error('source', __('L’elenco degli incentivi è cambiato. Ricarica la pagina prima di salvare.', 'ponsenergiasolare')); }
        $block = $source === 'new' ? pons_funding_program_template() : $old[(int) $source]; $sources[] = $source;
        pons_funding_apply_group($block, $program); $new[] = $block;
    }
    $old_sources = array(); foreach ($old as $i => $block) { if (pons_funding_has_class($block, 'funding-program')) { $old_sources[] = (string) $i; } }
    if ($sources === $old_sources) { foreach ($sources as $n => $source) { $group['innerBlocks'][(int) $source] = $new[$n]; } }
    else {
        $pieces = $group['innerContent']; $first = array_shift($pieces); $last = array_pop($pieces);
        foreach ($pieces as $piece) { if ($piece !== null && trim($piece) !== '') { return new WP_Error('structure', __('La struttura della pagina è cambiata. Nessun contenuto è stato modificato: contatta chi gestisce il sito.', 'ponsenergiasolare')); } }
        $children = array(); $n = 0;
        foreach ($old as $block) { if (pons_funding_has_class($block, 'funding-program')) { if (isset($new[$n])) { $children[] = $new[$n++]; } } else { $children[] = $block; } }
        while (isset($new[$n])) { $children[] = $new[$n++]; }
        $group['innerBlocks'] = $children; $group['innerContent'] = array_merge(array($first), array_fill(0, count($children), null), array($last));
    }
    unset($group);
    return $blocks === $original ? $content : serialize_blocks($blocks);
}
function pons_incentives_save($id, $input) {
    if (!$id || $id !== pons_page_id('incentivi') || !current_user_can('edit_post', $id)) { return new WP_Error('permission', __('Non hai i permessi per modificare questa pagina.', 'ponsenergiasolare')); }
    $page = get_post($id);
    if (!isset($input['fingerprint']) || !hash_equals(pons_incentives_fingerprint($page), $input['fingerprint'])) { return new WP_Error('conflict', __('La pagina è stata aggiornata in un’altra finestra. Il tuo testo è ancora qui: copialo prima di ricaricare.', 'ponsenergiasolare')); }
    $title = sanitize_text_field($input['title'] ?? ''); if ($title === '') { return new WP_Error('title', __('Scrivi il titolo della pagina.', 'ponsenergiasolare')); }
    $content = pons_incentives_compile($page->post_content, $input); if (is_wp_error($content)) { return $content; }
    $cover = absint($input['cover'] ?? 0);
    if ($cover !== get_post_thumbnail_id($id) && !current_user_can('upload_files')) { return new WP_Error('permission', __('Non hai i permessi per modificare le immagini.', 'ponsenergiasolare')); }
    if ($cover && !wp_attachment_is_image($cover)) { return new WP_Error('image', __('Scegli un’immagine valida dalla Libreria Media.', 'ponsenergiasolare')); }
    $excerpt = sanitize_textarea_field($input['excerpt'] ?? '');
    if ($title === $page->post_title && $excerpt === $page->post_excerpt && $content === $page->post_content && $cover === get_post_thumbnail_id($id)) { return $id; }
    $saved = wp_update_post(wp_slash(array('ID' => $id, 'post_title' => $title, 'post_excerpt' => $excerpt, 'post_content' => $content)), true);
    if (is_wp_error($saved)) { return $saved; }
    if ($cover) { set_post_thumbnail($id, $cover); } else { delete_post_thumbnail($id); }
    return $id;
}
