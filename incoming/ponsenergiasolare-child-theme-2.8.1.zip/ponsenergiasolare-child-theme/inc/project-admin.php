<?php
/** A focused project workspace over native posts, featured images and parent galleries. */
if (!defined('ABSPATH')) { exit; }

function pons_project_admin_url($id = 0) {
    return add_query_arg($id ? array('project' => absint($id)) : array(), admin_url('admin.php?page=pons-projects'));
}
add_action('admin_menu', static function () {
    remove_menu_page('edit.php?post_type=pons_project');
    add_menu_page(__('Progetti referenze', 'ponsenergiasolare'), __('Progetti referenze', 'ponsenergiasolare'), 'edit_posts', 'pons-projects', 'pons_projects_admin_page', 'dashicons-format-gallery', 26);
}, 99);
add_filter('get_edit_post_link', static function ($link, $id) { return get_post_type($id) === 'pons_project' ? pons_project_admin_url($id) : $link; }, 10, 2);
add_action('load-edit.php', static function () {
    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'GET' && ($_GET['post_type'] ?? '') === 'pons_project' && empty($_GET['action'])) { wp_safe_redirect(pons_project_admin_url()); exit; }
});
add_action('load-post-new.php', static function () {
    if (($_GET['post_type'] ?? '') === 'pons_project') { wp_safe_redirect(add_query_arg('new', '1', pons_project_admin_url())); exit; }
});
add_action('load-post.php', static function () {
    $id = absint($_GET['post'] ?? 0);
    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'GET' && ($_GET['action'] ?? 'edit') === 'edit' && get_post_type($id) === 'pons_project') { wp_safe_redirect(pons_project_admin_url($id)); exit; }
});

function pons_admin_project_posts($trash = false) {
    $args = array('post_type' => 'pons_project', 'post_status' => $trash ? 'trash' : array('publish', 'draft', 'pending', 'private', 'future'), 'posts_per_page' => -1, 'orderby' => array('menu_order' => 'ASC', 'ID' => 'DESC'), 'suppress_filters' => false);
    if (!current_user_can('edit_others_posts')) { $args['author'] = get_current_user_id(); }
    return array_values(array_filter(get_posts($args), static function ($post) { return current_user_can('edit_post', $post->ID); }));
}
function pons_admin_save_project($id, $input) {
    if (!current_user_can('edit_posts') || !current_user_can('upload_files') || ($id && (get_post_type($id) !== 'pons_project' || !current_user_can('edit_post', $id)))) { return new WP_Error('permission', __('Non hai i permessi per modificare questo progetto.', 'ponsenergiasolare')); }
    $title = sanitize_text_field($input['title'] ?? '');
    if ($title === '') { return new WP_Error('title', __('Scrivi il nome del progetto.', 'ponsenergiasolare')); }
    $images = array_values(array_unique(array_filter(array_map('absint', explode(',', (string) ($input['photos'] ?? ''))), 'wp_attachment_is_image')));
    $cover = absint($input['cover'] ?? 0);
    if (!$cover || !wp_attachment_is_image($cover)) { $cover = $images[0] ?? 0; }
    $visible = !empty($input['visible']);
    if ($visible && !current_user_can('publish_posts')) { return new WP_Error('permission', __('Non hai i permessi per pubblicare progetti.', 'ponsenergiasolare')); }
    if ($visible && !$cover) { return new WP_Error('photos', __('Aggiungi almeno una foto prima di mostrare il progetto sul sito.', 'ponsenergiasolare')); }
    if ($id && !empty($input['modified']) && get_post_field('post_modified_gmt', $id) !== $input['modified']) { return new WP_Error('conflict', __('Questo progetto è stato aggiornato in un’altra finestra. Il tuo testo è ancora qui: copialo prima di ricaricare la pagina.', 'ponsenergiasolare')); }
    $post = array('post_type' => 'pons_project', 'post_title' => $title, 'post_content' => wp_kses_post($input['description'] ?? ''), 'post_status' => $visible ? 'publish' : 'draft');
    if ($id) { $post['ID'] = $id; }
    else {
        $last = get_posts(array('post_type' => 'pons_project', 'post_status' => 'any', 'posts_per_page' => 1, 'orderby' => 'menu_order', 'order' => 'DESC'));
        $post['menu_order'] = $last ? (int) $last[0]->menu_order + 1 : 0;
    }
    $saved = $id ? wp_update_post(wp_slash($post), true) : wp_insert_post(wp_slash($post), true);
    if (is_wp_error($saved)) { return $saved; }
    if (!pons_update_project_photos($saved, $images)) { return new WP_Error('gallery', __('Le foto non sono state salvate. Riprova a salvare il progetto.', 'ponsenergiasolare')); }
    if ($cover) { set_post_thumbnail($saved, $cover); } else { delete_post_thumbnail($saved); }
    return $saved;
}

add_action('load-toplevel_page_pons-projects', static function () {
    if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') { return; }
    check_admin_referer('pons_manage_projects', 'pons_admin_nonce');
    $id = absint($_POST['project_id'] ?? 0);
    $operation = sanitize_key($_POST['pons_operation'] ?? 'save');
    if (in_array($operation, array('trash', 'restore'), true)) {
        if (!$id || get_post_type($id) !== 'pons_project' || !current_user_can('delete_post', $id)) { wp_die(esc_html__('Non hai i permessi per questa operazione.', 'ponsenergiasolare')); }
        if ($operation === 'trash') { wp_trash_post($id); }
        else { wp_untrash_post($id); wp_update_post(array('ID' => $id, 'post_status' => 'draft')); }
        wp_safe_redirect(add_query_arg('notice', $operation, pons_project_admin_url())); exit;
    }
    $input = array(
        'title' => is_string($_POST['project_title'] ?? null) ? wp_unslash($_POST['project_title']) : '',
        'description' => is_string($_POST['project_description'] ?? null) ? wp_unslash($_POST['project_description']) : '',
        'photos' => is_string($_POST['pons_project_images'] ?? null) ? wp_unslash($_POST['pons_project_images']) : '',
        'cover' => absint($_POST['project_cover'] ?? 0), 'visible' => !empty($_POST['project_visible']),
        'modified' => sanitize_text_field(wp_unslash($_POST['project_modified'] ?? '')),
    );
    $result = pons_admin_save_project($id, $input);
    if (is_wp_error($result)) { $GLOBALS['pons_project_admin_error'] = $result; $GLOBALS['pons_project_admin_input'] = $input; return; }
    wp_safe_redirect(add_query_arg('notice', 'saved', pons_project_admin_url($result))); exit;
});

add_action('wp_ajax_pons_order_projects', static function () {
    check_ajax_referer('pons_order_projects', 'nonce');
    if (!current_user_can('edit_posts')) { wp_send_json_error(null, 403); }
    $ids = isset($_POST['ids']) && is_array($_POST['ids']) ? array_values(array_unique(array_map('absint', $_POST['ids']))) : array();
    $all = pons_admin_project_posts();
    $expected = array_map(static function ($p) { return $p->ID; }, $all);
    $sorted = $ids; sort($sorted); $check = $expected; sort($check);
    if (!$ids || $sorted !== $check) { wp_send_json_error(null, 409); }
    foreach ($ids as $id) { if (!current_user_can('edit_post', $id)) { wp_send_json_error(null, 403); } }
    foreach ($ids as $order => $id) { $result = wp_update_post(array('ID' => $id, 'menu_order' => $order), true); if (is_wp_error($result)) { wp_send_json_error(null, 500); } }
    wp_send_json_success();
});

add_action('admin_enqueue_scripts', static function ($hook) {
    if ($hook !== 'toplevel_page_pons-projects') { return; }
    $id = absint($_GET['project'] ?? 0);
    if ($id && (get_post_type($id) !== 'pons_project' || !current_user_can('edit_post', $id))) { return; }
    $version = wp_get_theme()->get('Version');
    if ($id || !empty($_GET['new'])) { wp_enqueue_media($id ? array('post' => $id) : array()); }
    wp_enqueue_style('pons-project-admin', get_stylesheet_directory_uri() . '/assets/css/project-admin.css', array(), $version);
    wp_enqueue_script('pons-project-admin', get_stylesheet_directory_uri() . '/assets/js/project-admin.js', ($id || !empty($_GET['new'])) ? array('jquery', 'jquery-ui-sortable', 'media-views') : array('jquery', 'jquery-ui-sortable'), $version, true);
    wp_localize_script('pons-project-admin', 'ponsAdmin', array(
        'photosTitle' => __('Foto del progetto', 'ponsenergiasolare'), 'usePhotos' => __('Usa queste foto', 'ponsenergiasolare'),
        'remove' => __('Rimuovi foto %d', 'ponsenergiasolare'), 'before' => __('Sposta prima', 'ponsenergiasolare'), 'after' => __('Sposta dopo', 'ponsenergiasolare'),
        'cover' => __('Copertina', 'ponsenergiasolare'), 'setCover' => __('Usa come copertina', 'ponsenergiasolare'), 'chooseCover' => __('Scegli copertina', 'ponsenergiasolare'),
        'dirty' => __('Modifiche da salvare', 'ponsenergiasolare'), 'ready' => __('Tutto salvato', 'ponsenergiasolare'),
        'visible' => __('Visibile sul sito', 'ponsenergiasolare'), 'hidden' => __('Non visibile sul sito', 'ponsenergiasolare'),
        'orderSaved' => __('Ordine salvato', 'ponsenergiasolare'), 'orderSaving' => __('Salvataggio ordine…', 'ponsenergiasolare'),
        'orderError' => __('Ordine non salvato. Ricarica la pagina e riprova.', 'ponsenergiasolare'),
        'orderNonce' => wp_create_nonce('pons_order_projects'), 'ajaxUrl' => admin_url('admin-ajax.php'),
    ));
});

function pons_projects_admin_page() {
    $id = absint($_GET['project'] ?? 0);
    $new = !empty($_GET['new']);
    if ($id && (get_post_type($id) !== 'pons_project' || !current_user_can('edit_post', $id) || get_post_status($id) === 'trash')) { wp_die(esc_html__('Progetto non disponibile.', 'ponsenergiasolare')); }
    echo '<div class="wrap pons-project-manager">';
    if ($id || $new) { pons_project_admin_form($id); } else { pons_project_admin_index(); }
    echo '</div>';
}
function pons_project_admin_notice() {
    $notice = sanitize_key($_GET['notice'] ?? '');
    $messages = array('saved' => __('Progetto salvato.', 'ponsenergiasolare'), 'trash' => __('Progetto spostato nel cestino.', 'ponsenergiasolare'), 'restore' => __('Progetto recuperato. È nascosto: aprilo e attiva la visibilità quando è pronto.', 'ponsenergiasolare'));
    if (isset($messages[$notice])) { echo '<div class="p-admin-notice" role="status">' . esc_html($messages[$notice]) . '</div>'; }
}
function pons_project_admin_index() {
    $trash = ($_GET['view'] ?? '') === 'trash';
    $posts = pons_admin_project_posts($trash);
    $trashed = pons_admin_project_posts(true);
    ?>
    <header class="p-admin-heading"><div><h1><?php esc_html_e('Progetti referenze', 'ponsenergiasolare'); ?></h1><p><?php esc_html_e('Le tue realizzazioni, pronte da mostrare sul sito.', 'ponsenergiasolare'); ?></p></div><a class="p-admin-button primary" href="<?php echo esc_url(add_query_arg('new', '1', pons_project_admin_url())); ?>"><span aria-hidden="true">＋</span><?php esc_html_e('Nuovo progetto', 'ponsenergiasolare'); ?></a></header>
    <?php pons_project_admin_notice(); ?>
    <div class="p-admin-toolbar"><nav aria-label="<?php esc_attr_e('Elenco progetti', 'ponsenergiasolare'); ?>"><a <?php if (!$trash) echo 'aria-current="page"'; ?> href="<?php echo esc_url(pons_project_admin_url()); ?>"><?php esc_html_e('Progetti', 'ponsenergiasolare'); ?></a><?php if ($trashed) : ?><a <?php if ($trash) echo 'aria-current="page"'; ?> href="<?php echo esc_url(add_query_arg('view', 'trash', pons_project_admin_url())); ?>"><?php echo esc_html(sprintf(__('Cestino (%d)', 'ponsenergiasolare'), count($trashed))); ?></a><?php endif; ?></nav><div class="p-admin-toolbar-actions"><?php if (pons_page_url('referenze')) : ?><a class="p-admin-link" href="<?php echo esc_url(pons_page_url('referenze')); ?>" target="_blank" rel="noopener"><?php esc_html_e('Vedi sul sito ↗', 'ponsenergiasolare'); ?></a><?php endif; ?></div></div>
    <?php if (!$trash && count($posts) > 1) : ?><p class="p-admin-order-hint" data-order-hint><?php esc_html_e('Trascina le schede o usa le frecce. L’ordine si salva automaticamente.', 'ponsenergiasolare'); ?></p><?php endif; ?><p role="status" class="p-admin-order-status" data-order-status></p>
    <?php if (!$posts) : ?><div class="p-admin-empty"><h2><?php echo esc_html($trash ? __('Il cestino è vuoto.', 'ponsenergiasolare') : __('Il tuo primo progetto parte da qui.', 'ponsenergiasolare')); ?></h2><p><?php esc_html_e('Bastano un nome e qualche fotografia. Puoi completare il testo anche più tardi.', 'ponsenergiasolare'); ?></p></div><?php endif; ?>
    <div class="p-admin-projects is-ordering" data-project-order-list>
    <?php foreach ($posts as $post) : $images = pons_project_image_ids($post->ID); $cover = $images[0] ?? 0; ?>
        <article class="p-admin-project" data-project-id="<?php echo esc_attr($post->ID); ?>">
            <a class="p-admin-project-open" href="<?php echo esc_url($trash ? '#' : pons_project_admin_url($post->ID)); ?>" <?php if ($trash) echo 'tabindex="-1" aria-disabled="true"'; ?>>
                <div class="p-admin-project-photo"><?php if ($cover) { echo wp_get_attachment_image($cover, 'medium_large', false, array('loading' => 'lazy')); } else { ?><span><?php esc_html_e('Aggiungi una foto', 'ponsenergiasolare'); ?></span><?php } ?></div>
                <div class="p-admin-project-copy"><span class="p-admin-status <?php echo $post->post_status === 'publish' ? 'online' : ''; ?>"><?php echo esc_html($post->post_status === 'publish' ? __('Visibile', 'ponsenergiasolare') : ($trash ? __('Nel cestino', 'ponsenergiasolare') : __('Non visibile', 'ponsenergiasolare'))); ?></span><h2><?php echo esc_html($post->post_title ?: __('Senza nome', 'ponsenergiasolare')); ?></h2><div class="p-admin-project-bottom"><span><?php echo esc_html(sprintf(__('%s foto', 'ponsenergiasolare'), number_format_i18n(count($images)))); ?></span><?php if (!$trash) : ?><strong><?php esc_html_e('Modifica progetto', 'ponsenergiasolare'); ?><span aria-hidden="true"> ↗</span></strong><?php endif; ?></div></div>
            </a>
            <?php if (!$trash) : ?><div class="p-admin-project-order"><button type="button" data-project-earlier aria-label="<?php esc_attr_e('Sposta prima', 'ponsenergiasolare'); ?>">←</button><span aria-hidden="true">⠿</span><button type="button" data-project-later aria-label="<?php esc_attr_e('Sposta dopo', 'ponsenergiasolare'); ?>">→</button></div><?php else : ?><form method="post"><?php wp_nonce_field('pons_manage_projects', 'pons_admin_nonce'); ?><input type="hidden" name="project_id" value="<?php echo esc_attr($post->ID); ?>"><button class="p-admin-button quiet" name="pons_operation" value="restore"><?php esc_html_e('Ripristina progetto', 'ponsenergiasolare'); ?></button></form><?php endif; ?>
        </article>
    <?php endforeach; ?>
    </div>
    <?php
}
function pons_project_admin_form($id) {
    $post = $id ? get_post($id) : null;
    $input = $GLOBALS['pons_project_admin_input'] ?? array('title' => $post ? $post->post_title : '', 'description' => $post ? $post->post_content : '', 'cover' => $id ? get_post_thumbnail_id($id) : 0, 'photos' => implode(',', $id ? pons_project_gallery_ids($id) : array()), 'visible' => $post && $post->post_status === 'publish', 'modified' => $post ? $post->post_modified_gmt : '');
    $autosave = $id ? wp_get_post_autosave($id) : false;
    $normalize = static function ($text) { return preg_replace('/\s+/u', ' ', trim(wp_strip_all_tags($text))); };
    $recoverable = $autosave && $post && strcmp($autosave->post_modified_gmt, $post->post_modified_gmt) > 0 && ($normalize($autosave->post_content) !== $normalize($post->post_content) || $autosave->post_title !== $post->post_title);
    if ($recoverable && !empty($_GET['recover']) && empty($GLOBALS['pons_project_admin_input'])) { $input['title'] = $autosave->post_title; $input['description'] = $autosave->post_content; }
    $images = array_values(array_filter(array_map('absint', explode(',', $input['photos'])), 'wp_attachment_is_image'));
    $cover = $input['cover'] ?: ($images[0] ?? 0);
    $error = $GLOBALS['pons_project_admin_error'] ?? null;
    $unsaved = (bool) $error || ($recoverable && !empty($_GET['recover']));
    ?>
    <form method="post" class="p-admin-editor" data-project-form data-initial-dirty="<?php echo $unsaved ? '1' : '0'; ?>">
        <?php wp_nonce_field('pons_manage_projects', 'pons_admin_nonce'); ?>
        <input type="hidden" name="project_id" value="<?php echo esc_attr($id); ?>"><input type="hidden" name="project_modified" value="<?php echo esc_attr($input['modified']); ?>"><input type="hidden" name="pons_operation" value="save">
        <header class="p-admin-heading editor-heading"><div><a class="p-admin-back" href="<?php echo esc_url(pons_project_admin_url()); ?>">← <?php esc_html_e('Tutti i progetti', 'ponsenergiasolare'); ?></a><h1><?php echo esc_html($id ? __('Modifica progetto', 'ponsenergiasolare') : __('Nuovo progetto', 'ponsenergiasolare')); ?></h1></div><div class="p-admin-save"><span data-save-status role="status"><?php echo esc_html($unsaved ? __('Modifiche da salvare', 'ponsenergiasolare') : ($id ? __('Tutto salvato', 'ponsenergiasolare') : __('Da completare', 'ponsenergiasolare'))); ?></span><button class="p-admin-button primary" type="submit"><?php esc_html_e('Salva progetto', 'ponsenergiasolare'); ?></button></div></header>
        <?php if ($recoverable) : ?><div class="p-admin-notice" role="status"><?php if (!empty($_GET['recover'])) { esc_html_e('Testo della bozza recuperato. Salva il progetto per confermare.', 'ponsenergiasolare'); } else { esc_html_e('Esiste un testo non salvato più recente.', 'ponsenergiasolare'); ?> <a href="<?php echo esc_url(add_query_arg('recover', '1', pons_project_admin_url($id))); ?>"><?php esc_html_e('Recupera il testo', 'ponsenergiasolare'); ?></a><?php } ?></div><?php endif; ?>
        <?php pons_project_admin_notice(); if ($error) : ?><div class="p-admin-notice error" role="alert"><?php echo esc_html($error->get_error_message()); ?></div><?php endif; ?>
        <div class="p-admin-editor-grid"><div class="p-admin-editor-main">
            <section class="p-admin-panel"><h2><?php esc_html_e('Il progetto', 'ponsenergiasolare'); ?></h2><label class="p-admin-field" for="project-title"><?php esc_html_e('Nome del progetto', 'ponsenergiasolare'); ?><input id="project-title" name="project_title" type="text" value="<?php echo esc_attr($input['title']); ?>" required maxlength="200" autocomplete="off"></label><label class="p-admin-field" for="project-description"><?php esc_html_e('Descrizione', 'ponsenergiasolare'); ?><span><?php esc_html_e('Racconta in poche righe il lavoro realizzato.', 'ponsenergiasolare'); ?></span></label>
            <?php wp_editor($input['description'], 'project-description', array('textarea_name' => 'project_description', 'media_buttons' => false, 'quicktags' => false, 'textarea_rows' => 7, 'teeny' => true, 'tinymce' => array('toolbar1' => 'bold,italic,bullist,numlist,link,unlink', 'toolbar2' => '', 'menubar' => false, 'statusbar' => false, 'branding' => false, 'content_style' => 'body{font-family:-apple-system,BlinkMacSystemFont,Segoe UI,sans-serif;font-size:15px;line-height:1.6;margin:16px;color:#263239;}'))); ?>
            </section>
            <section class="p-admin-panel" data-admin-photos><div class="p-admin-panel-heading"><div><h2><?php esc_html_e('Foto del progetto', 'ponsenergiasolare'); ?></h2><p><?php esc_html_e('Trascina per riordinare. Scegli la copertina tra le foto.', 'ponsenergiasolare'); ?></p></div><button type="button" class="p-admin-button quiet" data-admin-add-photos disabled>＋ <?php esc_html_e('Aggiungi foto', 'ponsenergiasolare'); ?></button></div><input type="hidden" name="pons_project_images" value="<?php echo esc_attr(implode(',', $images)); ?>" data-admin-photo-ids><input type="hidden" name="project_cover" value="<?php echo esc_attr($cover); ?>" data-admin-cover-id>
            <ul class="p-admin-photos" data-admin-photo-list><?php foreach ($images as $image) : ?><li data-photo-id="<?php echo esc_attr($image); ?>"><?php echo wp_get_attachment_image($image, 'medium'); ?></li><?php endforeach; ?></ul><div class="p-admin-photo-empty" data-admin-photo-empty <?php if ($images) echo 'hidden'; ?>><p><?php esc_html_e('Aggiungi le prime foto di questo progetto.', 'ponsenergiasolare'); ?></p></div></section>
        </div><aside class="p-admin-editor-aside"><section class="p-admin-panel"><h2><?php esc_html_e('Sul sito', 'ponsenergiasolare'); ?></h2><label class="p-admin-visibility"><input type="checkbox" name="project_visible" value="1" <?php checked($input['visible']); ?> data-admin-visible><span class="p-admin-switch" aria-hidden="true"></span><strong data-visible-label><?php echo esc_html($input['visible'] ? __('Visibile sul sito', 'ponsenergiasolare') : __('Non visibile sul sito', 'ponsenergiasolare')); ?></strong></label><p><?php esc_html_e('Attiva quando il progetto è pronto. Puoi nasconderlo in qualsiasi momento.', 'ponsenergiasolare'); ?></p></section>
            <section class="p-admin-panel p-admin-preview"><h2><?php esc_html_e('Copertina', 'ponsenergiasolare'); ?></h2><div class="p-admin-cover-preview" data-cover-preview><?php if ($cover) echo wp_get_attachment_image($cover, 'medium_large'); ?></div><strong data-cover-title><?php echo esc_html($input['title'] ?: __('Nome del progetto', 'ponsenergiasolare')); ?></strong><button type="button" class="p-admin-link" data-admin-choose-cover disabled><?php esc_html_e('Scegli copertina', 'ponsenergiasolare'); ?></button><p><?php esc_html_e('Se non scegli una copertina, useremo la prima foto.', 'ponsenergiasolare'); ?></p></section>
            <?php if ($id && current_user_can('delete_post', $id)) : ?><button type="button" class="p-admin-trash" data-trash-project disabled><?php esc_html_e('Sposta nel cestino', 'ponsenergiasolare'); ?></button><?php endif; ?>
        </aside></div>
        <?php if ($id) : ?><dialog class="p-admin-dialog" data-trash-dialog aria-labelledby="trash-dialog-title"><h2 id="trash-dialog-title"><?php esc_html_e('Spostare il progetto nel cestino?', 'ponsenergiasolare'); ?></h2><p><?php esc_html_e('Verrà nascosto dal sito. Potrai recuperarlo dal cestino; le foto resteranno nella Libreria Media.', 'ponsenergiasolare'); ?></p><div><button type="button" class="p-admin-button quiet" data-trash-cancel><?php esc_html_e('Annulla', 'ponsenergiasolare'); ?></button><button class="p-admin-button danger" type="submit" name="pons_operation" value="trash" formnovalidate><?php esc_html_e('Sposta nel cestino', 'ponsenergiasolare'); ?></button></div></dialog><?php endif; ?>
        <div class="p-admin-mobile-save"><span data-save-status role="status"><?php echo esc_html($unsaved ? __('Modifiche da salvare', 'ponsenergiasolare') : ($id ? __('Tutto salvato', 'ponsenergiasolare') : __('Da completare', 'ponsenergiasolare'))); ?></span><button class="p-admin-button primary" type="submit"><?php esc_html_e('Salva progetto', 'ponsenergiasolare'); ?></button></div>
    </form>
    <?php
}
