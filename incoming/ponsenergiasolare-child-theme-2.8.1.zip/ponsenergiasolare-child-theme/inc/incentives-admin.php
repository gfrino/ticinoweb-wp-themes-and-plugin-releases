<?php
/** Simple Incentivi editor backed by the existing WordPress page. */
if (!defined('ABSPATH')) { exit; }
function pons_incentives_admin_url() { return admin_url('admin.php?page=pons-incentives'); }
add_action('admin_menu', static function () { add_menu_page(__('Incentivi', 'ponsenergiasolare'), __('Incentivi', 'ponsenergiasolare'), 'edit_pages', 'pons-incentives', 'pons_incentives_admin_page', 'dashicons-lightbulb', 27); });
add_filter('get_edit_post_link', static function ($url, $id) { return get_post_meta($id, '_pons_page_role', true) === 'incentivi' && current_user_can('edit_post', $id) ? pons_incentives_admin_url() : $url; }, 20, 2);
add_action('load-post.php', static function () {
    $id = absint($_GET['post'] ?? 0);
    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'GET' && ($_GET['action'] ?? 'edit') === 'edit' && $id && $id === pons_page_id('incentivi')) { wp_safe_redirect(pons_incentives_admin_url()); exit; }
});
function pons_incentives_request_fields() {
    $raw = wp_unslash($_POST);
    $string = static function ($array, $key) { return is_string($array[$key] ?? null) ? $array[$key] : ''; };
    $out = array('title' => $string($raw, 'page_title'), 'excerpt' => $string($raw, 'page_excerpt'), 'cover' => absint($raw['page_cover'] ?? 0), 'fingerprint' => $string($raw, 'fingerprint'), 'programs' => array());
    foreach (array('intro', 'help', 'contact') as $key) {
        $row = is_array($raw[$key] ?? null) ? $raw[$key] : array();
        foreach (array('title', 'text', 'link_label', 'link_url', 'note', 'level') as $field) { $out[$key][$field] = $string($row, $field); }
    }
    foreach (array_slice(is_array($raw['programs'] ?? null) ? $raw['programs'] : array(), 0, 31) as $row) {
        if (!is_array($row)) { continue; }
        $item = array(); foreach (array('source', 'title', 'level', 'text', 'link_label', 'link_url') as $field) { $item[$field] = $string($row, $field); }
        $out['programs'][] = $item;
    }
    return $out;
}
add_action('load-toplevel_page_pons-incentives', static function () {
    if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') { return; }
    check_admin_referer('pons_save_incentives', 'pons_incentives_nonce');
    $input = pons_incentives_request_fields(); $saved = pons_incentives_save(pons_page_id('incentivi'), $input);
    if (is_wp_error($saved)) { $GLOBALS['pons_incentives_error'] = $saved; $GLOBALS['pons_incentives_input'] = $input; return; }
    wp_safe_redirect(add_query_arg('saved', '1', pons_incentives_admin_url())); exit;
});
add_action('admin_enqueue_scripts', static function ($hook) {
    if ($hook !== 'toplevel_page_pons-incentives') { return; }
    $id = pons_page_id('incentivi'); if (!$id || !current_user_can('edit_post', $id)) { return; }
    $v = wp_get_theme()->get('Version'); wp_enqueue_media(array('post' => $id));
    wp_enqueue_style('pons-project-admin', get_stylesheet_directory_uri() . '/assets/css/project-admin.css', array(), $v);
    wp_enqueue_style('pons-incentives-admin', get_stylesheet_directory_uri() . '/assets/css/incentives-admin.css', array('pons-project-admin'), $v);
    wp_enqueue_script('pons-incentives-admin', get_stylesheet_directory_uri() . '/assets/js/incentives-admin.js', array('media-views'), $v, true);
    wp_localize_script('pons-incentives-admin', 'ponsIncentives', array('imageTitle' => __('Immagine della pagina', 'ponsenergiasolare'), 'imageUse' => __('Usa questa immagine', 'ponsenergiasolare'), 'dirty' => __('Modifiche da salvare', 'ponsenergiasolare'), 'newTitle' => __('Nuovo incentivo', 'ponsenergiasolare')));
});
function pons_incentives_field($name, $label, $value, $type = 'text', $help = '') {
    $id = 'i-' . sanitize_html_class(str_replace(array('[', ']'), array('-', ''), $name));
    echo '<label class="p-admin-field i-admin-field" for="' . esc_attr($id) . '">' . esc_html($label);
    if ($help) { echo '<span>' . esc_html($help) . '</span>'; }
    if ($type === 'textarea') { echo '<textarea id="' . esc_attr($id) . '" name="' . esc_attr($name) . '" rows="4">' . esc_textarea($value) . '</textarea>'; }
    else { echo '<input id="' . esc_attr($id) . '" type="' . esc_attr($type) . '" name="' . esc_attr($name) . '" value="' . esc_attr($value) . '">'; }
    echo '</label>';
}
function pons_incentives_page_select($name, $url) {
    $id = 'i-' . sanitize_html_class(str_replace(array('[', ']'), array('-', ''), $name));
    $pages = get_pages(array('post_status' => 'publish', 'sort_column' => 'post_title')); $found = false;
    echo '<label class="p-admin-field i-admin-field" for="' . esc_attr($id) . '">' . esc_html__('Destinazione del pulsante', 'ponsenergiasolare') . '<select name="' . esc_attr($name) . '" id="' . esc_attr($id) . '">';
    foreach ($pages as $page) { $link = get_permalink($page); if (untrailingslashit($link) === untrailingslashit($url)) { $found = true; $link = $url; } echo '<option value="' . esc_attr($link) . '" ' . selected($url, $link, false) . '>' . esc_html($page->post_title) . '</option>'; }
    if (!$found) { echo '<option value="' . esc_attr($url) . '" selected>' . esc_html__('Collegamento attuale', 'ponsenergiasolare') . '</option>'; }
    echo '</select></label>';
}
function pons_incentives_program_editor($index, $program, $open = false) {
    $name = 'programs[' . $index . ']'; ?>
    <details class="i-admin-program" data-incentive-program <?php if ($open) echo 'open'; ?>>
        <summary><span><strong data-incentive-name><?php echo esc_html($program['title'] ?: __('Nuovo incentivo', 'ponsenergiasolare')); ?></strong><small><?php echo esc_html($program['level'] ?? ''); ?></small></span><span class="i-admin-edit-label"><?php esc_html_e('Modifica', 'ponsenergiasolare'); ?><span aria-hidden="true">⌄</span></span></summary>
        <div class="i-admin-program-fields"><input type="hidden" name="<?php echo esc_attr($name); ?>[source]" value="<?php echo esc_attr($program['source'] ?? 'new'); ?>">
            <div class="i-admin-two-fields"><?php pons_incentives_field($name . '[title]', __('Nome dell’incentivo', 'ponsenergiasolare'), $program['title']); pons_incentives_field($name . '[level]', __('Ambito o ente', 'ponsenergiasolare'), $program['level'] ?? ''); ?></div>
            <?php pons_incentives_field($name . '[text]', __('Descrizione', 'ponsenergiasolare'), $program['text'] ?? '', 'textarea'); ?>
            <div class="i-admin-two-fields"><?php pons_incentives_field($name . '[link_label]', __('Testo del link', 'ponsenergiasolare'), $program['link_label'] ?? ''); pons_incentives_field($name . '[link_url]', __('Collegamento ufficiale', 'ponsenergiasolare'), $program['link_url'] ?? '', 'url'); ?></div>
            <div class="i-admin-program-actions"><div><button type="button" class="p-admin-button quiet" data-incentive-up aria-label="<?php esc_attr_e('Sposta prima', 'ponsenergiasolare'); ?>">↑</button><button type="button" class="p-admin-button quiet" data-incentive-down aria-label="<?php esc_attr_e('Sposta dopo', 'ponsenergiasolare'); ?>">↓</button></div><button type="button" class="p-admin-trash" data-incentive-remove><?php esc_html_e('Rimuovi incentivo', 'ponsenergiasolare'); ?></button></div>
        </div>
    </details>
    <?php
}
function pons_incentives_text_section($key, $label, $data, $open = false) { ?>
    <details class="p-admin-panel i-admin-section" <?php if ($open) echo 'open'; ?>><summary><h2><?php echo esc_html($label); ?></h2><span aria-hidden="true">⌄</span></summary><div class="i-admin-section-content">
        <?php pons_incentives_field($key . '[title]', __('Titolo del blocco', 'ponsenergiasolare'), $data['title']); pons_incentives_field($key . '[text]', __('Testo', 'ponsenergiasolare'), $data['text'], 'textarea'); ?>
        <div class="i-admin-two-fields"><?php pons_incentives_field($key . '[link_label]', __('Testo del pulsante', 'ponsenergiasolare'), $data['link_label']); pons_incentives_page_select($key . '[link_url]', $data['link_url']); ?></div>
        <?php if ($key === 'contact') { pons_incentives_field('contact[note]', __('Nota informativa', 'ponsenergiasolare'), $data['note'], 'textarea', __('Qui puoi aggiornare le avvertenze e l’eventuale data di verifica delle informazioni.', 'ponsenergiasolare')); } ?>
    </div></details>
<?php }
function pons_incentives_admin_page() {
    $id = pons_page_id('incentivi'); if (!$id || !current_user_can('edit_post', $id)) { wp_die(esc_html__('Pagina Incentivi non disponibile.', 'ponsenergiasolare')); }
    $page = get_post($id); $data = $GLOBALS['pons_incentives_input'] ?? pons_incentives_fields($page); $error = $GLOBALS['pons_incentives_error'] ?? null;
    if (is_wp_error($data)) { echo '<div class="wrap"><h1>' . esc_html__('Incentivi', 'ponsenergiasolare') . '</h1><p>' . esc_html($data->get_error_message()) . '</p></div>'; return; }
    ?>
    <div class="wrap pons-project-manager pons-incentives-manager"><form method="post" class="p-admin-editor" data-incentives-form data-initial-dirty="<?php echo $error ? '1' : '0'; ?>">
        <?php wp_nonce_field('pons_save_incentives', 'pons_incentives_nonce'); ?><input type="hidden" name="fingerprint" value="<?php echo esc_attr($data['fingerprint']); ?>">
        <header class="p-admin-heading editor-heading"><div><h1><?php esc_html_e('Incentivi', 'ponsenergiasolare'); ?></h1><p><?php esc_html_e('Aggiorna testi e collegamenti della pagina, tutto da qui.', 'ponsenergiasolare'); ?></p></div><div class="p-admin-save"><span data-incentives-status role="status"><?php echo esc_html($error ? __('Modifiche da salvare', 'ponsenergiasolare') : __('Tutto salvato', 'ponsenergiasolare')); ?></span><button class="p-admin-button primary" type="submit"><?php esc_html_e('Salva incentivi', 'ponsenergiasolare'); ?></button></div></header>
        <?php if ($error) : ?><div class="p-admin-notice error" role="alert"><?php echo esc_html($error->get_error_message()); ?></div><?php elseif (!empty($_GET['saved'])) : ?><div class="p-admin-notice" role="status"><?php esc_html_e('Pagina Incentivi aggiornata.', 'ponsenergiasolare'); ?></div><?php endif; ?>
        <div class="p-admin-editor-grid"><div class="p-admin-editor-main">
            <section class="p-admin-panel"><h2><?php esc_html_e('Apertura della pagina', 'ponsenergiasolare'); ?></h2><?php pons_incentives_field('page_title', __('Titolo della pagina', 'ponsenergiasolare'), $data['title']); pons_incentives_field('page_excerpt', __('Testo sotto il titolo', 'ponsenergiasolare'), $data['excerpt'], 'textarea'); ?></section>
            <section class="p-admin-panel"><h2><?php esc_html_e('Introduzione', 'ponsenergiasolare'); ?></h2><?php pons_incentives_field('intro[title]', __('Titolo introduttivo', 'ponsenergiasolare'), $data['intro']['title']); pons_incentives_field('intro[text]', __('Testo introduttivo', 'ponsenergiasolare'), $data['intro']['text'], 'textarea'); ?></section>
            <section class="p-admin-panel"><div class="p-admin-panel-heading"><div><h2><?php esc_html_e('Incentivi disponibili', 'ponsenergiasolare'); ?></h2><p><?php esc_html_e('Apri una scheda per modificarne il contenuto.', 'ponsenergiasolare'); ?></p></div><button type="button" class="p-admin-button quiet" data-add-incentive disabled>＋ <?php esc_html_e('Aggiungi incentivo', 'ponsenergiasolare'); ?></button></div>
                <div data-incentives-list><?php foreach ($data['programs'] as $index => $program) { pons_incentives_program_editor($index, $program, (bool) $error); } ?></div>
            </section>
            <?php pons_incentives_text_section('help', __('Come seguiamo le pratiche', 'ponsenergiasolare'), $data['help'], (bool) $error); pons_incentives_text_section('contact', __('Invito al contatto e nota informativa', 'ponsenergiasolare'), $data['contact'], (bool) $error); ?>
        </div><aside class="p-admin-editor-aside"><section class="p-admin-panel"><h2><?php esc_html_e('Sul sito', 'ponsenergiasolare'); ?></h2><p><?php esc_html_e('Salvando, le modifiche saranno subito visibili nella pagina Incentivi.', 'ponsenergiasolare'); ?></p><a class="p-admin-link i-admin-preview-link" href="<?php echo esc_url(get_permalink($id)); ?>" target="_blank" rel="noopener"><?php esc_html_e('Apri la pagina ↗', 'ponsenergiasolare'); ?></a></section><section class="p-admin-panel"><h2><?php esc_html_e('Immagine di apertura', 'ponsenergiasolare'); ?></h2><input type="hidden" name="page_cover" value="<?php echo esc_attr($data['cover']); ?>" data-incentives-image-id><div class="p-admin-cover-preview" data-incentives-image><?php if ($data['cover']) echo wp_get_attachment_image($data['cover'], 'medium_large'); ?></div><div class="i-admin-image-actions"><button type="button" class="p-admin-button quiet" data-incentives-choose-image disabled><?php esc_html_e('Scegli immagine', 'ponsenergiasolare'); ?></button><button type="button" class="p-admin-trash" data-incentives-remove-image <?php if (!$data['cover']) echo 'hidden'; ?>><?php esc_html_e('Rimuovi immagine', 'ponsenergiasolare'); ?></button></div></section></aside></div>
        <template data-incentive-template><?php pons_incentives_program_editor('__INDEX__', array('source' => 'new', 'title' => '', 'level' => '', 'text' => '', 'link_label' => '', 'link_url' => ''), true); ?></template>
        <dialog class="p-admin-dialog" data-remove-incentive-dialog aria-labelledby="remove-incentive-title"><h2 id="remove-incentive-title"><?php esc_html_e('Rimuovere questo incentivo?', 'ponsenergiasolare'); ?></h2><p><?php esc_html_e('La scheda verrà rimossa dalla pagina quando salverai le modifiche.', 'ponsenergiasolare'); ?></p><div><button type="button" class="p-admin-button quiet" data-cancel-incentive-remove><?php esc_html_e('Annulla', 'ponsenergiasolare'); ?></button><button type="button" class="p-admin-button danger" data-confirm-incentive-remove><?php esc_html_e('Rimuovi incentivo', 'ponsenergiasolare'); ?></button></div></dialog>
        <div class="p-admin-mobile-save"><span data-incentives-status role="status"><?php echo esc_html($error ? __('Modifiche da salvare', 'ponsenergiasolare') : __('Tutto salvato', 'ponsenergiasolare')); ?></span><button type="submit" class="p-admin-button primary"><?php esc_html_e('Salva incentivi', 'ponsenergiasolare'); ?></button></div>
    </form></div>
    <?php
}
