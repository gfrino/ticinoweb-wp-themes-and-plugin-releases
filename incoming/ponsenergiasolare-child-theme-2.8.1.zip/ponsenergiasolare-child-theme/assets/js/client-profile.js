/* Keep native inputs, nonce, user-profile.js and security handlers untouched. */
(()=>{
 'use strict';
 const form=document.querySelector('body.pons-client-profile #your-profile'),labels=window.ponsProfile;if(!form||!labels)return;
 const title=document.querySelector('#wpbody-content .wrap>h1');if(title){title.textContent=labels.title;const intro=document.createElement('p');intro.className='p-profile-intro';intro.textContent=labels.intro;title.after(intro);}
 const section=(row,label)=>{
  const table=form.querySelector(row)?.closest('table');if(!table)return;
  const heading=table.previousElementSibling;if(heading?.tagName==='H2')heading.textContent=label;
  const panel=document.createElement('section');panel.className='p-profile-panel';table.before(panel);if(heading?.tagName==='H2')panel.append(heading);panel.append(table);
 };
 section('.user-user-login-wrap',labels.identity);section('.user-email-wrap',labels.contact);section('.user-pass1-wrap',labels.security);
 const applications=form.querySelector('#application-passwords-section');if(applications){const details=document.createElement('details');details.className='p-profile-advanced';const summary=document.createElement('summary');summary.textContent=labels.applications;details.append(summary);applications.before(details);details.append(applications);if(location.hash==='#application-passwords-section')details.open=true;}
 const passkeyHeading=form.querySelector('#tw-passkeys');if(passkeyHeading){
  const details=document.createElement('details');details.className='p-profile-advanced';const summary=document.createElement('summary');summary.textContent=labels.passkeys;details.append(summary);passkeyHeading.before(details);
  let node=passkeyHeading;
  while(node&&!(node!==passkeyHeading&&(node.tagName==='H2'||node.matches('.submit')))){const next=node.nextElementSibling;details.append(node);node=next;}
  if(location.hash==='#tw-passkeys')details.open=true;
 }
 const save=form.querySelector('#submit');if(save)save.value=labels.save;
})();
