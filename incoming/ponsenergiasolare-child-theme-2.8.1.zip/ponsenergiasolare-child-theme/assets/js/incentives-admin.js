(()=>{
 'use strict';
 const form=document.querySelector('[data-incentives-form]');if(!form)return;
 const labels=window.ponsIncentives,list=form.querySelector('[data-incentives-list]'),dialog=form.querySelector('[data-remove-incentive-dialog]');
 let dirty=form.dataset.initialDirty==='1',submitting=false,nextIndex=list.children.length,pending=null,frame;
 const mark=()=>{dirty=true;form.querySelectorAll('[data-incentives-status]').forEach(status=>status.textContent=labels.dirty);};
 form.addEventListener('input',event=>{mark();if(event.target.name?.endsWith('[title]')){const row=event.target.closest('[data-incentive-program]');if(row)row.querySelector('[data-incentive-name]').textContent=event.target.value||labels.newTitle;}if(event.target.name?.endsWith('[level]'))event.target.closest('[data-incentive-program]')?.querySelector('summary small').replaceChildren(document.createTextNode(event.target.value));});
 form.addEventListener('change',mark);form.addEventListener('submit',()=>{submitting=true;});
 addEventListener('beforeunload',event=>{if(dirty&&!submitting){event.preventDefault();event.returnValue='';}});
 const arrows=()=>{[...list.children].forEach((row,index)=>{row.querySelector('[data-incentive-up]').disabled=index===0;row.querySelector('[data-incentive-down]').disabled=index===list.children.length-1;});form.querySelector('[data-add-incentive]').disabled=list.children.length>=30;};
 form.querySelector('[data-add-incentive]').addEventListener('click',()=>{
  const fragment=form.querySelector('[data-incentive-template]').content.cloneNode(true);fragment.querySelectorAll('[name],[id],[for]').forEach(element=>{['name','id','for'].forEach(attribute=>{if(element.hasAttribute(attribute))element.setAttribute(attribute,element.getAttribute(attribute).replace('__INDEX__',String(nextIndex)));});});nextIndex++;list.append(fragment);arrows();mark();list.lastElementChild.querySelector('input[type=text]').focus();
 });
 list.addEventListener('click',event=>{
  const row=event.target.closest('[data-incentive-program]');if(!row)return;
  if(event.target.closest('[data-incentive-remove]')){pending=row;dialog.showModal();return;}
  if(event.target.closest('[data-incentive-up]')){if(row.previousElementSibling){list.insertBefore(row,row.previousElementSibling);arrows();mark();row.querySelector('[data-incentive-down]').focus();}}
  if(event.target.closest('[data-incentive-down]')){if(row.nextElementSibling){list.insertBefore(row.nextElementSibling,row);arrows();mark();row.querySelector('[data-incentive-up]').focus();}}
 });
 dialog.querySelector('[data-cancel-incentive-remove]').addEventListener('click',()=>{dialog.close();pending?.querySelector('[data-incentive-remove]').focus();pending=null;});
 dialog.querySelector('[data-confirm-incentive-remove]').addEventListener('click',()=>{pending?.remove();pending=null;dialog.close();arrows();mark();form.querySelector('[data-add-incentive]').focus();});
 const imageId=form.querySelector('[data-incentives-image-id]'),imageWrap=form.querySelector('[data-incentives-image]'),removeImage=form.querySelector('[data-incentives-remove-image]');
 form.querySelector('[data-incentives-choose-image]').addEventListener('click',()=>{
  if(!frame){frame=wp.media({title:labels.imageTitle,button:{text:labels.imageUse},library:{type:'image'},multiple:false});frame.on('select',()=>{const image=frame.state().get('selection').first().toJSON();const img=document.createElement('img');img.src=image.sizes?.medium_large?.url||image.url;img.alt=image.alt||'';imageWrap.replaceChildren(img);imageId.value=String(image.id);removeImage.hidden=false;mark();});}frame.open();
 });
 removeImage.addEventListener('click',()=>{imageWrap.replaceChildren();imageId.value='0';removeImage.hidden=true;mark();});
 form.querySelector('[data-incentives-choose-image]').disabled=false;arrows();
})();
