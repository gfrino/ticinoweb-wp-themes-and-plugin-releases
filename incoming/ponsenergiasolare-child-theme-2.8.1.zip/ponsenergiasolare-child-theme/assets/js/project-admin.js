/* Dedicated project workspace; WordPress owns the media picker and persisted data. */
(function($){
 'use strict';
 const app=document.querySelector('.pons-project-manager');if(!app)return;
 const labels=window.ponsAdmin,form=app.querySelector('[data-project-form]');
 if(form){
  let dirty=form.dataset.initialDirty==='1',submitting=false,photoFrame,coverFrame;
  const list=form.querySelector('[data-admin-photo-list]'),ids=form.querySelector('[data-admin-photo-ids]'),coverInput=form.querySelector('[data-admin-cover-id]'),preview=form.querySelector('[data-cover-preview]');
  let photos=[...list.children].map(li=>({id:Number(li.dataset.photoId),url:li.querySelector('img').src,alt:li.querySelector('img').alt}));
  const markDirty=()=>{dirty=true;form.querySelectorAll('[data-save-status]').forEach(status=>status.textContent=labels.dirty);};
  form.addEventListener('input',markDirty);form.addEventListener('change',markDirty);
  addEventListener('beforeunload',event=>{if(dirty&&!submitting){event.preventDefault();event.returnValue='';}});
  form.addEventListener('submit',()=>{submitting=true;window.tinymce?.triggerSave();});
  const setCover=photo=>{
   coverInput.value=photo?String(photo.id):'0';preview.replaceChildren();
   if(photo){const img=document.createElement('img');img.src=photo.url;img.alt=photo.alt||'';preview.append(img);}
  };
  const sync=()=>{ids.value=photos.map(photo=>photo.id).join(',');markDirty();};
  const render=()=>{
   list.replaceChildren();form.querySelector('[data-admin-photo-empty]').hidden=photos.length>0;
   photos.forEach((photo,index)=>{
    const li=document.createElement('li');li.dataset.photoId=String(photo.id);
    const image=document.createElement('img');image.src=photo.url;image.alt=photo.alt||'';image.draggable=false;li.append(image);
    const remove=document.createElement('button');remove.type='button';remove.className='p-admin-remove-photo';remove.textContent='×';remove.setAttribute('aria-label',labels.remove.replace('%d',String(index+1)));
    remove.addEventListener('click',()=>{photos.splice(index,1);if(Number(coverInput.value)===photo.id)setCover(photos[0]);render();sync();(list.children[Math.min(index,photos.length-1)]?.querySelector('button')||form.querySelector('[data-admin-add-photos]')).focus();});li.append(remove);
    const controls=document.createElement('div');controls.className='p-admin-photo-controls';
    const cover=document.createElement('button');cover.type='button';cover.className='p-admin-photo-cover';const active=Number(coverInput.value)===photo.id;cover.textContent=active?'✓ '+labels.cover:labels.setCover;cover.setAttribute('aria-pressed',String(active));cover.addEventListener('click',()=>{setCover(photo);render();sync();list.children[index].querySelector('.p-admin-photo-cover').focus();});controls.append(cover);
    const moves=document.createElement('div');moves.className='p-admin-photo-moves';
    [-1,1].forEach(delta=>{const button=document.createElement('button');button.type='button';button.textContent=delta<0?'←':'→';button.setAttribute('aria-label',delta<0?labels.before:labels.after);button.disabled=index+delta<0||index+delta>=photos.length;button.addEventListener('click',()=>{[photos[index],photos[index+delta]]=[photos[index+delta],photos[index]];render();sync();list.children[index+delta].querySelector('.p-admin-photo-cover').focus();});moves.append(button);});controls.append(moves);li.append(controls);list.append(li);
   });
   $(list).sortable('refresh');
  };
  $(list).sortable({items:'>li',handle:'img',placeholder:'p-admin-photo-placeholder',tolerance:'pointer',update:()=>{const order=[...list.children].map(li=>Number(li.dataset.photoId));photos=order.map(id=>photos.find(photo=>photo.id===id));render();sync();}});
  form.querySelector('[data-admin-add-photos]').addEventListener('click',()=>{
   if(!photoFrame){photoFrame=wp.media({title:labels.photosTitle,button:{text:labels.usePhotos},library:{type:'image'},multiple:'add'});
    photoFrame.on('open',()=>{const selection=photoFrame.state().get('selection');selection.reset();photos.forEach(photo=>{const model=wp.media.attachment(photo.id);model.fetch();selection.add(model);});});
    photoFrame.on('select',()=>{const previous=photos;photos=photoFrame.state().get('selection').toJSON().map(photo=>({id:photo.id,url:photo.sizes?.medium?.url||photo.url,alt:photo.alt||''})).filter(photo=>photo.url);const cover=Number(coverInput.value);if(!cover||(previous.some(photo=>photo.id===cover)&&!photos.some(photo=>photo.id===cover)))setCover(photos[0]);render();sync();});
   }photoFrame.open();
  });
  form.querySelector('[data-admin-choose-cover]').addEventListener('click',()=>{
   if(!coverFrame){coverFrame=wp.media({title:labels.chooseCover,button:{text:labels.setCover},library:{type:'image'},multiple:false});coverFrame.on('select',()=>{const photo=coverFrame.state().get('selection').first().toJSON();setCover({id:photo.id,url:photo.sizes?.medium_large?.url||photo.url,alt:photo.alt||''});render();sync();});}coverFrame.open();
  });
  const visible=form.querySelector('[data-admin-visible]');visible.addEventListener('change',()=>{form.querySelector('[data-visible-label]').textContent=visible.checked?labels.visible:labels.hidden;});
  form.querySelector('#project-title').addEventListener('input',event=>{form.querySelector('[data-cover-title]').textContent=event.target.value;});
  const dialog=form.querySelector('[data-trash-dialog]');if(dialog){form.querySelector('[data-trash-project]').addEventListener('click',()=>dialog.showModal());dialog.querySelector('[data-trash-cancel]').addEventListener('click',()=>dialog.close());}
  // Native TinyMCE initializes after this script on some WordPress versions.
  $(document).on('tinymce-editor-init',(_event,editor)=>{if(editor.id==='project-description')editor.on('input change undo redo',markDirty);});
  if(window.tinymce){Object.values(window.tinymce.editors||{}).forEach(editor=>{if(editor.id==='project-description')editor.on('input change undo redo',markDirty);});}
  render();form.querySelectorAll('[data-admin-add-photos],[data-admin-choose-cover],[data-trash-project]').forEach(button=>button.disabled=false);
 }
 const cards=app.querySelector('[data-project-order-list]');
 if(cards&&cards.querySelector('[data-project-earlier]')){
  let saving=false,lastSavedOrder=[...cards.children];
  const status=app.querySelector('[data-order-status]');
  const refreshArrows=()=>{[...cards.children].forEach((card,index)=>{card.querySelector('[data-project-earlier]').disabled=saving||index===0;card.querySelector('[data-project-later]').disabled=saving||index===cards.children.length-1;});};
  const saveOrder=async()=>{
   if(saving)return;saving=true;status.textContent=labels.orderSaving;
   cards.querySelectorAll('button').forEach(button=>button.disabled=true);$(cards).sortable('disable');
   const body=new URLSearchParams({action:'pons_order_projects',nonce:labels.orderNonce});[...cards.children].forEach(card=>body.append('ids[]',card.dataset.projectId));
   try{const response=await fetch(labels.ajaxUrl,{method:'POST',credentials:'same-origin',body});const result=await response.json();if(!response.ok||!result.success)throw new Error();lastSavedOrder=[...cards.children];status.textContent=labels.orderSaved;}
   catch{lastSavedOrder.forEach(card=>cards.append(card));$(cards).sortable('refresh');status.textContent=labels.orderError;}
   finally{saving=false;refreshArrows();$(cards).sortable('enable');}
  };
  $(cards).sortable({items:'>article',handle:'.p-admin-project-order>span',disabled:false,tolerance:'pointer',update:saveOrder});
  refreshArrows();
  cards.addEventListener('click',event=>{
   const button=event.target.closest('[data-project-earlier],[data-project-later]');if(!button||saving)return;
   const card=button.closest('article'),earlier=button.hasAttribute('data-project-earlier'),sibling=earlier?card.previousElementSibling:card.nextElementSibling;
   if(!sibling)return;if(earlier)cards.insertBefore(card,sibling);else cards.insertBefore(sibling,card);saveOrder();
  });
 }
})(jQuery);
