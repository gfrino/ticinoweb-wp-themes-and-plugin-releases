<?php
/**
 * Wistaria child theme bootstrap.
 *
 * @package WistariaChildTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once get_stylesheet_directory() . '/inc/cms.php';

add_action( 'admin_enqueue_scripts', static function ( $hook ) {
	if ( 'toplevel_page_ticinoweb-cms' === $hook ) {
		wp_enqueue_script( 'wistaria-cms-fonts', get_stylesheet_directory_uri() . '/assets/js/cms-tab.js', array(), wp_get_theme()->get( 'Version' ), true );
		wp_localize_script( 'wistaria-cms-fonts', 'wistariaCmsFonts', array( 'body' => get_option( 'ticinoweb_font_body', 'Heebo' ), 'headings' => get_option( 'ticinoweb_font_headings', 'Inter' ), 'subheadings' => get_option( 'ticinoweb_font_subheadings', 'Inter' ) ) );
	}
} );

/** The parent CMS favicon is authoritative on this subsite. */
add_action( 'wp', static function () {
	if ( get_option( 'ticinoweb_site_icon' ) ) {
		remove_action( 'wp_head', 'wp_site_icon', 99 );
	}
} );

/** The first CMS slider button supplies the shared quote CTA label. */
function wistaria_quote_label() {
	return (string) get_option( 'ticinoweb_slider_btn_text_1', __( 'Richiedi un preventivo', 'wistaria-child-theme' ) );
}

/** Apply the existing parent palette plus Wistaria-only layout tokens. */
function wistaria_cms_token_css() {
	$colors = array(
		'ink'         => sanitize_hex_color( get_option( 'ticinoweb_palette_suggested_1', '#00160e' ) ) ?: '#00160e',
		'green'       => sanitize_hex_color( get_option( 'ticinoweb_palette_primary', '#007a0a' ) ) ?: '#007a0a',
		'light-green' => sanitize_hex_color( get_option( 'ticinoweb_palette_suggested_3', '#6dac33' ) ) ?: '#6dac33',
		'yellow'      => sanitize_hex_color( get_option( 'ticinoweb_palette_suggested_2', '#ffd402' ) ) ?: '#ffd402',
		'surface'     => sanitize_hex_color( wistaria_cms_value( 'surface' ) ) ?: '#ffffff',
		'soft'        => sanitize_hex_color( wistaria_cms_value( 'soft' ) ) ?: '#f3f7ef',
		'border'      => sanitize_hex_color( wistaria_cms_value( 'border' ) ) ?: '#dbe6d7',
		'muted'       => sanitize_hex_color( wistaria_cms_value( 'muted' ) ) ?: '#41564a',
	);
	$declarations = array();
	foreach ( $colors as $name => $value ) {
		$declarations[] = '--wistaria-' . $name . ':' . $value;
	}
	$declarations[] = '--wistaria-container:' . min( 1440, max( 960, absint( wistaria_cms_value( 'container' ) ) ) ) . 'px';
	$headings = get_option( 'ticinoweb_font_headings', 'Inter' );
	$body = get_option( 'ticinoweb_font_body', 'Heebo' );
	$declarations[] = '--wistaria-heading-font:' . ( in_array( $headings, array( 'Inter', 'Heebo' ), true ) ? $headings : 'Inter' ) . ',Arial,sans-serif';
	$declarations[] = '--wistaria-body-font:' . ( in_array( $body, array( 'Inter', 'Heebo' ), true ) ? $body : 'Heebo' ) . ',Arial,sans-serif';
	return ':root{' . implode( ';', $declarations ) . '}';
}

/** Load the child assets only where needed. */
function wistaria_enqueue_assets() {
	wp_dequeue_style( 'ticinoweb-ai-style' );
	wp_deregister_style( 'ticinoweb-ai-style' );
	wp_dequeue_style( 'poppins-font' );
	wp_dequeue_script( 'ticinoweb-ai-main' );
	$version = wp_get_theme()->get( 'Version' );
	wp_enqueue_style( 'wistaria-style', get_stylesheet_uri(), array(), $version );
	wp_add_inline_style( 'wistaria-style', wistaria_cms_token_css() );
	wp_enqueue_script( 'wistaria-navigation', get_stylesheet_directory_uri() . '/assets/js/navigation.js', array(), $version, true );
	wp_enqueue_script( 'wistaria-consent', get_stylesheet_directory_uri() . '/assets/js/consent.js', array(), $version, true );
	wp_localize_script( 'wistaria-consent', 'wistariaConsent', array(
		'message' => __( 'Usiamo cookie e contenuti di terzi, tra cui Google Maps. Puoi scegliere quali autorizzare.', 'wistaria-child-theme' ),
		'category' => __( 'Contenuti esterni e marketing', 'wistaria-child-theme' ),
		'description' => __( 'Consente il caricamento di Google Maps e degli eventuali contenuti di marketing di terze parti.', 'wistaria-child-theme' ),
	) );
	if ( is_front_page() ) {
		wp_enqueue_script( 'wistaria-reload-position', get_stylesheet_directory_uri() . '/assets/js/reload-position.js', array(), $version, false );
		wp_enqueue_script( 'wistaria-carousel', get_stylesheet_directory_uri() . '/assets/js/carousel.js', array(), $version, true );
		wp_enqueue_script( 'wistaria-services', get_stylesheet_directory_uri() . '/assets/js/services.js', array(), $version, true );
		wp_enqueue_script( 'wistaria-services-motion', get_stylesheet_directory_uri() . '/assets/js/services-motion.js', array(), $version, true );
		wp_enqueue_script( 'wistaria-home-motion', get_stylesheet_directory_uri() . '/assets/js/home-motion.js', array( 'wistaria-carousel' ), $version, true );
		wp_enqueue_script( 'wistaria-about', get_stylesheet_directory_uri() . '/assets/js/about.js', array(), $version, true );
	}
	if ( is_front_page() ) {
		$site_key = (string) get_option( 'ticinoweb_recaptcha_site_key', '' );
		if ( $site_key ) {
			wp_enqueue_script( 'wistaria-recaptcha', 'https://www.google.com/recaptcha/api.js?render=' . rawurlencode( $site_key ), array(), null, true );
		}
		wp_enqueue_script( 'wistaria-form', get_stylesheet_directory_uri() . '/assets/js/form.js', $site_key ? array( 'wistaria-recaptcha' ) : array(), $version, true );
		wp_localize_script( 'wistaria-form', 'wistariaForm', array(
			'ajaxUrl'          => admin_url( 'admin-ajax.php' ),
			'recaptchaSiteKey' => $site_key,
			'fallbackError'    => __( 'Invio non riuscito. Riprova o contattaci via email.', 'wistaria-child-theme' ),
			'connectionError'  => __( 'Problema di connessione. Riprova tra poco.', 'wistaria-child-theme' ),
			'sending'          => __( 'Invio in corso…', 'wistaria-child-theme' ),
		) );
	}
}
add_action( 'wp_enqueue_scripts', 'wistaria_enqueue_assets', 30 );

/** Keep this site's choices separate from other sites sharing the same host. */
function wistaria_scoped_consent_output( $callback ) {
	ob_start();
	call_user_func( $callback );
	$output = ob_get_clean();
	// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Parent output is already escaped.
	echo str_replace( array( 'tw_cookie_consent', 'tw_cookie_preferences' ), array( 'wistaria_cookie_consent', 'wistaria_cookie_preferences' ), $output );
}
function wistaria_render_consent_banner() { wistaria_scoped_consent_output( 'tw_seo_cookie_banner_render' ); }
function wistaria_render_analytics() { wistaria_scoped_consent_output( 'tw_seo_google_analytics_render' ); }
add_action( 'wp', static function () {
	if ( function_exists( 'tw_seo_cookie_banner_render' ) ) {
		remove_action( 'wp_footer', 'tw_seo_cookie_banner_render', 100 );
		add_action( 'wp_footer', 'wistaria_render_consent_banner', 100 );
	}
	if ( function_exists( 'tw_seo_google_analytics_render' ) ) {
		remove_action( 'wp_head', 'tw_seo_google_analytics_render', 5 );
		add_action( 'wp_head', 'wistaria_render_analytics', 5 );
	}
} );

/** Home section anchors are not the current page until their anchor is open. */
function wistaria_menu_item_classes( $classes, $item ) {
	if ( is_front_page() && in_array( wp_parse_url( $item->url, PHP_URL_FRAGMENT ), array( 'servizi', 'lavori', 'chi-siamo', 'contatti' ), true ) ) {
		$classes = array_diff( $classes, array( 'current-menu-item', 'current_page_item' ) );
	}
	return $classes;
}
add_filter( 'nav_menu_css_class', 'wistaria_menu_item_classes', 10, 2 );

function wistaria_menu_link_attributes( $atts, $item ) {
	if ( is_front_page() && in_array( wp_parse_url( $item->url, PHP_URL_FRAGMENT ), array( 'servizi', 'lavori', 'chi-siamo', 'contatti' ), true ) ) {
		unset( $atts['aria-current'] );
	}
	return $atts;
}
add_filter( 'nav_menu_link_attributes', 'wistaria_menu_link_attributes', 10, 2 );

/** Keep old page addresses working after moving content into the one-page site. */
function wistaria_redirect_legacy_pages() {
	if ( is_page() && ! is_front_page() ) {
		$legacy_sections = array( 'servizi' => 'servizi', 'chi-siamo' => 'chi-siamo' );
		foreach ( $legacy_sections as $slug => $anchor ) {
			$page = get_page_by_path( $slug );
			if ( $page && is_page( $page->ID ) ) {
				wp_safe_redirect( home_url( '/#' . $anchor ), 301 );
				exit;
			}
		}
	}
	if ( ! is_404() ) {
		return;
	}
	$request_path = wp_parse_url( esc_url_raw( wp_unslash( $_SERVER['REQUEST_URI'] ?? '' ) ), PHP_URL_PATH );
	foreach ( array( 'negozio', 'carrello', 'checkout', 'mio-account' ) as $retired_page ) {
		$retired_path = wp_parse_url( home_url( '/' . $retired_page . '/' ), PHP_URL_PATH );
		if ( trailingslashit( $request_path ) === trailingslashit( $retired_path ) ) {
			wp_safe_redirect( home_url( '/' ), 301 );
			exit;
		}
	}
	$legacy_path = wp_parse_url( home_url( '/lavori/' ), PHP_URL_PATH );
	if ( trailingslashit( $request_path ) === trailingslashit( $legacy_path ) ) {
		wp_safe_redirect( home_url( '/#lavori' ), 301 );
		exit;
	}
	$contact_path = wp_parse_url( home_url( '/contatti/' ), PHP_URL_PATH );
	if ( trailingslashit( $request_path ) === trailingslashit( $contact_path ) ) {
		wp_safe_redirect( home_url( '/#contatti' ), 301 );
		exit;
	}
	$impressum_path = wp_parse_url( home_url( '/impressum/' ), PHP_URL_PATH );
	if ( trailingslashit( $request_path ) === trailingslashit( $impressum_path ) ) {
		$company_details_page = get_page_by_path( 'dati-aziendali' );
		if ( $company_details_page && 'publish' === $company_details_page->post_status ) {
			wp_safe_redirect( get_permalink( $company_details_page ), 301 );
			exit;
		}
	}
}
add_action( 'template_redirect', 'wistaria_redirect_legacy_pages', 1 );

/** Redirect-only pages should not appear as canonical sitemap entries. */
function wistaria_sitemap_exclude_redirects( $args, $post_type ) {
	if ( 'page' !== $post_type ) {
		return $args;
	}
	$mapping = (array) get_option( 'ticinoweb_page_mapping', array() );
	$ids = array_filter( array_map( 'absint', array( $mapping['page_servizi'] ?? 0, $mapping['page_chi_siamo'] ?? 0 ) ) );
	$args['post__not_in'] = array_values( array_unique( array_merge( (array) ( $args['post__not_in'] ?? array() ), $ids ) ) );
	return $args;
}
add_filter( 'wp_sitemaps_posts_query_args', 'wistaria_sitemap_exclude_redirects', 10, 2 );

/** Split the CMS address for the parent LocalBusiness schema when its format is complete. */
function wistaria_local_business_address( $schema ) {
	$address = trim( (string) get_option( 'ticinoweb_contact_address', '' ) );
	if ( isset( $schema['@type'] ) && 'LocalBusiness' === $schema['@type'] && preg_match( '/^(.+?),\s*(\d{4})\s+([^,]+)$/u', $address, $parts ) ) {
		$schema['address'] = array(
			'@type'           => 'PostalAddress',
			'streetAddress'   => trim( $parts[1] ),
			'postalCode'      => $parts[2],
			'addressLocality' => trim( $parts[3] ),
			'addressCountry'  => 'CH',
		);
	}
	return $schema;
}
add_filter( 'ticinoweb_seo_jsonld_org_schema', 'wistaria_local_business_address' );

/** Use the parent's services setting as the single content source. */
function wistaria_services() {
	return function_exists( 'ticinoweb_get_services' ) ? (array) ticinoweb_get_services() : array();
}

/** Read a parent media gallery in its saved order. */
function wistaria_gallery_images( $slug ) {
	$term = get_term_by( 'slug', $slug, 'ticinoweb_media_gallery' );
	if ( ! $term || is_wp_error( $term ) ) {
		return array();
	}
	$ids = get_posts( array(
		'post_type'      => 'attachment',
		'post_status'    => 'inherit',
		'posts_per_page' => 100,
		'fields'         => 'ids',
		'tax_query'      => array( array(
			'taxonomy' => 'ticinoweb_media_gallery',
			'field'    => 'term_id',
			'terms'    => (int) $term->term_id,
		) ),
	) );
	$order = (array) get_term_meta( $term->term_id, '_ticinoweb_gallery_order', true );
	$rank = array_flip( array_map( 'intval', $order ) );
	usort( $ids, static function ( $a, $b ) use ( $rank ) {
		return ( $rank[ $a ] ?? PHP_INT_MAX ) <=> ( $rank[ $b ] ?? PHP_INT_MAX );
	} );
	return $ids;
}

function wistaria_work_images() {
	return wistaria_gallery_images( 'lavori-wistaria' );
}

/** Resolve a configured site page without storing post IDs in code. */
function wistaria_page_url( $key, $slug ) {
	$id = function_exists( 'ticinoweb_get_mapped_page_id' ) ? (int) ticinoweb_get_mapped_page_id( $key ) : 0;
	if ( $id && 'publish' === get_post_status( $id ) ) {
		return get_permalink( $id );
	}
	$page = get_page_by_path( $slug );
	return $page && 'publish' === $page->post_status ? get_permalink( $page ) : home_url( '/' );
}

/** A short guide scoped to this subsite's llms.txt route. */
function wistaria_serve_llms_txt( $wp ) {
	if ( 'llms.txt' !== $wp->request ) {
		return;
	}
	$name = sanitize_text_field( get_bloginfo( 'name' ) );
	$address = sanitize_text_field( (string) get_option( 'ticinoweb_contact_address', '' ) );
	$phone = sanitize_text_field( (string) get_option( 'ticinoweb_contact_phone', '' ) );
	$email = sanitize_email( (string) get_option( 'ticinoweb_contact_email', '' ) );
	$lines = array(
		'# ' . $name, '',
		'> ' . __( 'Costruzione e manutenzione di giardini e parchi.', 'wistaria-child-theme' ), '',
		'## ' . __( 'Pagine', 'wistaria-child-theme' ), '',
		'- [' . __( 'Home', 'wistaria-child-theme' ) . '](' . home_url( '/' ) . ')',
		'- [' . __( 'Servizi', 'wistaria-child-theme' ) . '](' . home_url( '/#servizi' ) . ')',
		'- [' . __( 'Lavori', 'wistaria-child-theme' ) . '](' . home_url( '/#lavori' ) . ')',
		'- [' . __( 'Chi siamo', 'wistaria-child-theme' ) . '](' . wistaria_page_url( 'page_chi_siamo', 'chi-siamo' ) . ')',
		'- [' . __( 'Contatti', 'wistaria-child-theme' ) . '](' . home_url( '/#contatti' ) . ')',
	);
	$services = wistaria_services();
	if ( $services ) {
		$lines[] = '';
		$lines[] = '## ' . __( 'Servizi offerti', 'wistaria-child-theme' );
		$lines[] = '';
		foreach ( $services as $service ) {
			$title = sanitize_text_field( (string) ( $service['title'] ?? '' ) );
			if ( $title ) {
				$lines[] = '- ' . $title;
			}
		}
	}
	if ( $address || $phone || $email ) {
		$lines[] = '';
		$lines[] = '## ' . __( 'Recapiti', 'wistaria-child-theme' );
		$lines[] = '';
		if ( $address ) { $lines[] = '- ' . __( 'Indirizzo', 'wistaria-child-theme' ) . ': ' . $address; }
		if ( $phone ) { $lines[] = '- ' . __( 'Telefono', 'wistaria-child-theme' ) . ': ' . $phone; }
		if ( $email ) { $lines[] = '- ' . __( 'Email', 'wistaria-child-theme' ) . ': ' . $email; }
	}
	nocache_headers();
	status_header( 200 );
	header( 'Content-Type: text/plain; charset=' . get_bloginfo( 'charset' ) );
	echo implode( "\n", $lines ) . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Sanitized plain-text response.
	exit;
}
add_action( 'parse_request', 'wistaria_serve_llms_txt' );
