<?php
/**
 * Footer del design New Polo Design 360°: chiude il contenitore aperto in header.php.
 */
if (!defined('ABSPATH')) {
    exit;
}
$npd_name  = ticinoweb_frontend_text(get_bloginfo('name'), 'theme:branding:site_name');
$npd_email = npd_contact('email');
$npd_addr  = npd_contact('address');
$npd_tel   = npd_phone_display();
$npd_priv  = function_exists('get_privacy_policy_url') ? get_privacy_policy_url() : '';
?>
<footer class="relative bg-[#111111] text-white pt-16 pb-28 sm:pb-8 overflow-hidden">
    <div class="absolute -top-24 -right-24 w-80 h-80 rounded-full bg-primary/15 blur-3xl pointer-events-none"></div>
    <div class="absolute -bottom-32 -left-24 w-80 h-80 rounded-full bg-accent/10 blur-3xl pointer-events-none"></div>
    <div class="container mx-auto px-4 relative">
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10 mb-12 text-center md:text-left">
            <div>
                <img alt="<?php echo esc_attr($npd_name); ?>" class="h-12 object-contain mx-auto md:mx-0 mb-6" src="<?php echo esc_url(npd_logo_url(true)); ?>" loading="lazy" width="75" height="48">
                <?php if (npd_c('foot_tagline') !== '') : ?>
                    <p class="text-gray-400 text-sm max-w-xs mx-auto md:mx-0"><?php echo esc_html(npd_c('foot_tagline')); ?></p>
                <?php endif; ?>
            </div>
            <div>
                <h4 class="text-lg font-bold mb-4 text-accent"><?php esc_html_e('Contatti', 'new-polo-design-child-theme'); ?></h4>
                <ul class="space-y-2 text-gray-400 text-sm">
                    <?php if ($npd_email) : ?><li><a href="mailto:<?php echo esc_attr($npd_email); ?>" class="hover:text-white transition-colors break-all"><?php echo esc_html($npd_email); ?></a></li><?php endif; ?>
                    <?php if ($npd_tel) : ?><li><a href="tel:<?php echo esc_attr(npd_phone_href()); ?>" class="hover:text-white transition-colors"><?php esc_html_e('Tel', 'new-polo-design-child-theme'); ?>: <?php echo esc_html($npd_tel); ?></a></li><?php endif; ?>
                    <?php if ($npd_addr) : ?><li><?php esc_html_e('Sede', 'new-polo-design-child-theme'); ?>: <?php echo esc_html($npd_addr); ?></li><?php endif; ?>
                </ul>
            </div>
            <div>
                <h4 class="text-lg font-bold mb-4 text-accent"><?php esc_html_e('Link Rapidi', 'new-polo-design-child-theme'); ?></h4>
                <ul class="space-y-2 text-gray-400 text-sm">
                    <li><a href="<?php echo esc_url(npd_anchor('servizi')); ?>" class="hover:text-white transition-colors"><?php esc_html_e('Servizi', 'new-polo-design-child-theme'); ?></a></li>
                    <li><a href="<?php echo esc_url(npd_anchor('metodo')); ?>" class="hover:text-white transition-colors"><?php esc_html_e('Metodo', 'new-polo-design-child-theme'); ?></a></li>
                    <li><a href="#preventivo" data-npd-open="quote" class="hover:text-white transition-colors"><?php esc_html_e('Preventivo', 'new-polo-design-child-theme'); ?></a></li>
                    <?php if ($npd_priv) : ?><li><a href="<?php echo esc_url($npd_priv); ?>" class="hover:text-white transition-colors"><?php esc_html_e('Privacy Policy', 'new-polo-design-child-theme'); ?></a></li><?php endif; ?>
                </ul>
            </div>
            <div>
                <h4 class="text-lg font-bold mb-3 text-accent"><?php echo esc_html(npd_c('news_title')); ?></h4>
                <p class="text-gray-400 text-sm mb-4 max-w-xs mx-auto md:mx-0"><?php echo esc_html(npd_c('news_text')); ?></p>
                <form class="space-y-2" novalidate data-npd-newsletter>
                    <div class="flex gap-2">
                        <input type="email" name="email" placeholder="<?php esc_attr_e('La tua email', 'new-polo-design-child-theme'); ?>" aria-label="<?php esc_attr_e('La tua email', 'new-polo-design-child-theme'); ?>" autocomplete="email" class="flex-1 min-w-0 rounded-xl bg-white/10 border border-white/15 px-4 py-3 text-sm text-white placeholder:text-gray-500 focus:outline-none focus:ring-2 focus:ring-accent focus:border-transparent transition">
                        <input type="text" name="tw_hp" tabindex="-1" autocomplete="off" aria-hidden="true" class="npd-hp">
                        <button type="submit" aria-label="<?php esc_attr_e('Iscriviti', 'new-polo-design-child-theme'); ?>" class="shrink-0 inline-flex items-center justify-center gap-2 rounded-xl bg-accent hover:bg-accent/90 text-accent-foreground font-bold px-4 py-3 text-sm transition-colors disabled:opacity-70">
                            <?php echo npd_icon('send', 16); // phpcs:ignore WordPress.Security.EscapeOutput ?><span class="hidden sm:inline"><?php esc_html_e('Iscriviti', 'new-polo-design-child-theme'); ?></span>
                        </button>
                    </div>
                    <p class="text-[11px] text-gray-600 leading-snug"><?php echo esc_html(npd_c('news_note')); ?></p>
                    <p class="text-sm font-medium" data-npd-newsletter-msg role="status" aria-live="polite"></p>
                </form>
            </div>
        </div>
        <div class="border-t border-white/10 pt-8 text-center text-gray-500 text-sm">
            <?php
            /* translators: 1: anno, 2: nome del sito */
            echo esc_html(sprintf(__('© %1$s %2$s. Tutti i diritti riservati.', 'new-polo-design-child-theme'), wp_date('Y'), $npd_name));
            ?>
            <span class="text-gray-600"> · Design by <a href="https://ticinoweb.com" target="_blank" rel="noopener" class="hover:text-white transition-colors">ticinoWEB</a></span>
        </div>
    </div>
</footer>

<div class="sm:hidden h-[var(--mobile-nav-h)]" aria-hidden="true"></div>
<?php if (npd_whatsapp_number()) : ?>
<a href="<?php echo esc_url(npd_whatsapp_url(npd_c('wa_info'))); ?>" target="_blank" rel="noopener noreferrer" aria-label="<?php esc_attr_e('Scrivici su WhatsApp', 'new-polo-design-child-theme'); ?>" class="fixed z-50 right-4 sm:right-6 bottom-[calc(1rem+var(--bizmart-total-h)+var(--mobile-nav-h))] sm:bottom-[calc(1.5rem+var(--bizmart-total-h))] h-14 w-14 rounded-full bg-[#25D366] text-white shadow-xl flex items-center justify-center">
    <span class="absolute inset-0 rounded-full bg-[#25D366] animate-ping opacity-40"></span>
    <?php echo npd_icon('message-circle', 28); // phpcs:ignore WordPress.Security.EscapeOutput ?>
</a>
<?php endif; ?>
<nav class="sm:hidden fixed bottom-[var(--bizmart-total-h)] left-0 right-0 z-40 h-[var(--mobile-nav-h)] border-t border-border bg-white/95 backdrop-blur-md shadow-[0_-4px_20px_rgb(0,0,0,0.06)]" aria-label="<?php esc_attr_e('Navigazione rapida', 'new-polo-design-child-theme'); ?>">
    <div class="relative grid h-full grid-cols-5 items-center px-1">
        <a href="<?php echo esc_url(npd_anchor('servizi')); ?>" class="flex flex-col items-center justify-center gap-0.5 py-1 text-[10px] font-medium text-foreground/70 active:text-accent transition-colors"><?php echo npd_icon('layout-grid', 20); // phpcs:ignore WordPress.Security.EscapeOutput ?><?php esc_html_e('Servizi', 'new-polo-design-child-theme'); ?></a>
        <a href="<?php echo esc_url(npd_anchor('portfolio')); ?>" class="flex flex-col items-center justify-center gap-0.5 py-1 text-[10px] font-medium text-foreground/70 active:text-accent transition-colors"><?php echo npd_icon('images', 20); // phpcs:ignore WordPress.Security.EscapeOutput ?><?php esc_html_e('Portfolio', 'new-polo-design-child-theme'); ?></a>
        <div aria-hidden="true"></div>
        <a href="<?php echo esc_url(npd_anchor('recensioni')); ?>" class="flex flex-col items-center justify-center gap-0.5 py-1 text-[10px] font-medium text-foreground/70 active:text-accent transition-colors"><?php echo npd_icon('star', 20); // phpcs:ignore WordPress.Security.EscapeOutput ?><?php esc_html_e('Recensioni', 'new-polo-design-child-theme'); ?></a>
        <button type="button" data-npd-open="quote" class="flex flex-col items-center justify-center gap-0.5 py-1 text-[10px] font-medium text-foreground/70 active:text-accent transition-colors"><?php echo npd_icon('file-text', 20); // phpcs:ignore WordPress.Security.EscapeOutput ?><?php esc_html_e('Preventivo', 'new-polo-design-child-theme'); ?></button>
        <div class="absolute left-1/2 -translate-x-1/2 -top-7 w-16 h-16">
            <span class="absolute inset-0 rounded-full border-2 border-primary"></span>
            <a href="<?php echo esc_url(npd_anchor('top')); ?>" aria-label="<?php echo esc_attr($npd_name); ?>" class="relative w-full h-full rounded-full bg-white border-4 border-primary shadow-lg flex items-center justify-center overflow-hidden active:scale-95 transition-transform">
                <img alt="" class="w-11 h-11 object-contain" src="<?php echo esc_url(npd_logo_url()); ?>" loading="lazy" width="44" height="44">
            </a>
        </div>
    </div>
</nav>
</div>
<?php get_template_part('template-parts/modals', null, array('services' => npd_services())); ?>
<?php wp_footer(); ?>
</body>
</html>
