<?php
/**
 * Helper del design: contatti (letti dal parent), link WhatsApp, selettore lingua.
 */
if (!defined('ABSPATH')) {
    exit;
}

/** Valore di contatto dal pannello ticinoWEB CMS del parent (Input First). */
function npd_contact($key) {
    if (!function_exists('ticinoweb_get_contact_info')) {
        return '';
    }
    $info = ticinoweb_get_contact_info();
    return isset($info[$key]) && is_string($info[$key]) ? $info[$key] : '';
}

/** Numero telefonico per tel: (solo cifre e +). */
function npd_phone_href() {
    return preg_replace('/[^\d+]/', '', npd_contact('phone_mobile') ?: npd_contact('phone'));
}

/** Numero WhatsApp in formato internazionale senza + (es. 41782344358). */
function npd_whatsapp_number() {
    return preg_replace('/\D/', '', npd_contact('phone_mobile') ?: npd_contact('phone'));
}

function npd_phone_display() {
    return npd_contact('phone_mobile') ?: npd_contact('phone');
}

function npd_whatsapp_url($text = '') {
    $number = npd_whatsapp_number();
    if ($number === '') {
        return '';
    }
    return 'https://wa.me/' . $number . ($text !== '' ? '?text=' . rawurlencode($text) : '');
}

/** URL di un'ancora della home, valido anche dalle pagine interne. */
function npd_anchor($id) {
    return (is_front_page() ? '' : home_url('/')) . '#' . $id;
}

/** Logo del sito (pannello del parent) con ripiego sul file del tema. */
function npd_logo_url($light = false) {
    if ($light) {
        return NPD_URI . '/assets/img/logo-light.png';
    }
    $logo = function_exists('ticinoweb_get_site_logo') ? ticinoweb_get_site_logo() : '';
    return $logo ?: NPD_URI . '/assets/img/logo.png';
}

/** Orari raggruppati per giorni consecutivi con lo stesso testo (es. Lunedi - Sabato). */
function npd_opening_rows() {
    $hours = get_option('ticinoweb_contact_opening_hours', array());
    if (!is_array($hours) || !$hours) {
        return array();
    }
    $labels = array(
        'monday'    => __('Lunedì', 'new-polo-design-child-theme'),
        'tuesday'   => __('Martedì', 'new-polo-design-child-theme'),
        'wednesday' => __('Mercoledì', 'new-polo-design-child-theme'),
        'thursday'  => __('Giovedì', 'new-polo-design-child-theme'),
        'friday'    => __('Venerdì', 'new-polo-design-child-theme'),
        'saturday'  => __('Sabato', 'new-polo-design-child-theme'),
        'sunday'    => __('Domenica', 'new-polo-design-child-theme'),
    );
    $note = npd_contact('opening_hours_note');
    $rows = array();
    foreach ($labels as $key => $label) {
        if (!isset($hours[$key])) {
            continue;
        }
        $text = function_exists('ticinoweb_format_day_hours') ? ticinoweb_format_day_hours($hours[$key]) : '';
        if ($text === '') {
            $text = $note;
        }
        $last = count($rows) - 1;
        if ($last >= 0 && $rows[$last]['text'] === $text) {
            $rows[$last]['to'] = $label;
        } else {
            $rows[] = array('from' => $label, 'to' => '', 'text' => $text);
        }
    }
    $out = array();
    foreach ($rows as $r) {
        if ($r['text'] === '') {
            continue;
        }
        $out[] = array(
            'label' => $r['to'] !== '' ? $r['from'] . ' – ' . $r['to'] : $r['from'],
            'text'  => $r['text'],
        );
    }
    return $out;
}

/** Bandiera 60x30 per il selettore lingua. */
function npd_flag_svg($code) {
    $flags = array(
        'it' => '<rect width="20" height="30" x="0" fill="#009246"/><rect width="20" height="30" x="20" fill="#fff"/><rect width="20" height="30" x="40" fill="#CE2B37"/>',
        'de' => '<rect width="60" height="10" y="0" fill="#000"/><rect width="60" height="10" y="10" fill="#DD0000"/><rect width="60" height="10" y="20" fill="#FFCE00"/>',
        'fr' => '<rect width="20" height="30" x="0" fill="#0055A4"/><rect width="20" height="30" x="20" fill="#fff"/><rect width="20" height="30" x="40" fill="#EF4135"/>',
        'en' => '<rect width="60" height="30" fill="#012169"/><path d="M0 0l60 30M60 0L0 30" stroke="#fff" stroke-width="6"/><path d="M0 0l60 30M60 0L0 30" stroke="#C8102E" stroke-width="3"/><path d="M30 0v30M0 15h60" stroke="#fff" stroke-width="10"/><path d="M30 0v30M0 15h60" stroke="#C8102E" stroke-width="6"/>',
    );
    $code = isset($flags[$code]) ? $code : null;
    if (!$code) {
        return '';
    }
    return '<svg viewBox="0 0 60 30" class="w-full h-full" aria-hidden="true">' . $flags[$code] . '</svg>';
}

/**
 * Lingue attive di WPML (o del plugin di traduzione compatibile). Vuoto se il sito
 * e' monolingua: in quel caso il selettore non viene mostrato.
 */
function npd_languages() {
    if (!has_filter('wpml_active_languages')) {
        return array();
    }
    $langs = apply_filters('wpml_active_languages', null, array('skip_missing' => 0));
    return is_array($langs) && count($langs) > 1 ? $langs : array();
}

function npd_lang_switcher($variant = 'desktop') {
    $langs = npd_languages();
    if (!$langs) {
        return;
    }
    $current = null;
    foreach ($langs as $l) {
        if (!empty($l['active'])) {
            $current = $l;
        }
    }
    if (!$current) {
        $current = reset($langs);
    }
    $wrap = $variant === 'mobile' ? 'w-full justify-center' : '';
    ?>
    <div class="npd-lang relative">
        <button type="button" aria-label="<?php esc_attr_e('Seleziona lingua', 'new-polo-design-child-theme'); ?>" aria-haspopup="true" aria-expanded="false" data-npd-lang class="flex items-center gap-2 rounded-full border border-border bg-white px-3 py-2 text-sm font-semibold text-foreground/80 hover:border-primary hover:text-primary transition-all <?php echo esc_attr($wrap); ?>">
            <span class="w-6 h-4 overflow-hidden rounded-sm shadow-sm ring-1 ring-black/10 flex"><?php echo npd_flag_svg($current['language_code']); // phpcs:ignore WordPress.Security.EscapeOutput -- SVG statico ?></span>
            <span class="uppercase"><?php echo esc_html($current['language_code']); ?></span>
            <?php echo npd_icon('chevron-down', 16); // phpcs:ignore WordPress.Security.EscapeOutput ?>
        </button>
        <ul class="npd-lang-menu" hidden>
            <?php foreach ($langs as $l) : ?>
                <li>
                    <a href="<?php echo esc_url($l['url']); ?>" hreflang="<?php echo esc_attr($l['language_code']); ?>" class="flex items-center gap-3 px-3 py-2 text-sm font-medium hover:bg-muted rounded-md">
                        <span class="w-6 h-4 overflow-hidden rounded-sm shadow-sm ring-1 ring-black/10 flex"><?php echo npd_flag_svg($l['language_code']); // phpcs:ignore WordPress.Security.EscapeOutput ?></span>
                        <?php echo esc_html($l['native_name']); ?>
                    </a>
                </li>
            <?php endforeach; ?>
        </ul>
    </div>
    <?php
}
