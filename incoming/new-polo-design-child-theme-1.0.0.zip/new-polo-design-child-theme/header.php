<?php
/**
 * Header del design New Polo Design 360°.
 */
if (!defined('ABSPATH')) {
    exit;
}
$npd_name = ticinoweb_frontend_text(get_bloginfo('name'), 'theme:branding:site_name');
$npd_nav  = array(
    'servizi'    => __('Servizi', 'new-polo-design-child-theme'),
    'metodo'     => __('Come lavoriamo', 'new-polo-design-child-theme'),
    'portfolio'  => __('Portfolio', 'new-polo-design-child-theme'),
    'recensioni' => __('Recensioni', 'new-polo-design-child-theme'),
    'faq'        => __('FAQ', 'new-polo-design-child-theme'),
);
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<div id="top" class="min-h-[100dvh] w-full bg-background flex flex-col font-sans overflow-x-hidden">
<div class="fixed top-0 left-0 right-0 z-[60] h-1 origin-left bg-gradient-to-r from-primary via-[#2F65B8] to-accent npd-progress" data-npd-progress aria-hidden="true"></div>
<header class="sticky top-0 z-50 w-full backdrop-blur-md bg-white/90 border-b border-border shadow-sm transition-all duration-300 npd-header">
    <div class="container mx-auto px-4 h-20 flex items-center justify-between">
        <a href="<?php echo esc_url(home_url('/')); ?>" class="flex-shrink-0 z-50" rel="home">
            <img alt="<?php echo esc_attr($npd_name); ?>" class="h-10 object-contain" src="<?php echo esc_url(npd_logo_url()); ?>" width="156" height="40">
        </a>
        <nav class="hidden md:flex items-center gap-8" aria-label="<?php esc_attr_e('Menu principale', 'new-polo-design-child-theme'); ?>">
            <?php foreach ($npd_nav as $id => $label) : ?>
                <a href="<?php echo esc_url(npd_anchor($id)); ?>" class="text-sm font-semibold text-foreground/80 hover:text-accent transition-colors"><?php echo esc_html($label); ?></a>
            <?php endforeach; ?>
            <?php npd_lang_switcher('desktop'); ?>
            <button type="button" data-npd-open="quote" class="inline-flex items-center justify-center gap-2 whitespace-nowrap text-sm focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 hover-elevate active-elevate-2 border border-primary-border min-h-9 py-2 bg-accent hover:bg-accent/90 text-accent-foreground font-bold rounded-full px-6 shadow-md hover:shadow-lg transition-all hover:-translate-y-0.5"><?php esc_html_e('Preventivo', 'new-polo-design-child-theme'); ?></button>
        </nav>
        <div class="flex items-center gap-2 md:hidden z-50">
            <?php npd_lang_switcher('mobile'); ?>
            <button type="button" class="p-2 text-foreground" data-npd-menu aria-label="<?php esc_attr_e('Apri menu', 'new-polo-design-child-theme'); ?>" aria-expanded="false" aria-controls="mobile-nav">
                <span data-npd-menu-open><?php echo npd_icon('menu', 28); // phpcs:ignore WordPress.Security.EscapeOutput ?></span>
                <span data-npd-menu-close hidden><?php echo npd_icon('x', 28); // phpcs:ignore WordPress.Security.EscapeOutput ?></span>
            </button>
        </div>
    </div>
    <div id="mobile-nav" hidden class="absolute top-20 left-0 w-full bg-white border-b border-border shadow-xl md:hidden py-6 px-4 flex flex-col gap-4">
        <?php foreach ($npd_nav as $id => $label) : ?>
            <a href="<?php echo esc_url(npd_anchor($id)); ?>" data-npd-menu-link class="text-lg font-semibold py-2 border-b border-border/50"><?php echo esc_html($label); ?></a>
        <?php endforeach; ?>
        <button type="button" data-npd-open="quote" class="inline-flex items-center justify-center gap-2 whitespace-nowrap font-medium w-full bg-accent text-accent-foreground font-bold rounded-full mt-4 h-12 text-lg"><?php esc_html_e('Richiedi Preventivo', 'new-polo-design-child-theme'); ?></button>
    </div>
</header>
