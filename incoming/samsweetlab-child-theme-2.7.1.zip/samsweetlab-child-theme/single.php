<?php defined('ABSPATH') || exit; get_header(); ?>
<main id="main-content" class="detail-main wrap">
<?php while (have_posts()) : the_post(); $machine=get_post_type()==='macchina'; $category_url=sweet_page_url($machine?'machines':'ingredients'); ?>
  <?php if (function_exists('woocommerce_output_all_notices')) woocommerce_output_all_notices(); ?>
  <a class="back-link" href="<?php echo esc_url($category_url); ?>">← <?php esc_html_e('Torna al catalogo', 'samsweetlab-child-theme'); ?></a>
  <article class="detail-grid">
    <div class="detail-image"><?php the_post_thumbnail('large', array('loading'=>'eager','fetchpriority'=>'high')); ?></div>
    <div class="detail-copy">
      <p class="eyebrow"><?php echo esc_html($machine ? sweet_machine_family(get_the_ID()) : __('Ingredienti e accessori','samsweetlab-child-theme')); ?></p>
      <h1><?php the_title(); ?></h1>
      <div class="entry-content">
        <?php if (get_post_type()==='product') : ?>
          <?php // La consegna la dicono i vantaggi sotto il prezzo: qui si toglie la riga ripetuta.
          $excerpt=preg_replace('~<em>Tempi di consegna.*?</em>~iu','',get_the_excerpt()); echo wp_kses_post(wpautop($excerpt)); ?>
        <?php endif; ?>
        <?php the_content(); ?>
      </div>
      <?php $downloads=get_post_meta(get_the_ID(),'_downloadable_files',true); if (is_array($downloads)) : foreach($downloads as $download) : if(empty($download['file']))continue; ?>
        <a class="text-link download" href="<?php echo esc_url($download['file']); ?>" target="_blank" rel="noopener"><?php echo esc_html($download['name'] ?: __('Scarica il catalogo','samsweetlab-child-theme')); ?> <span aria-hidden="true">↓</span></a>
      <?php endforeach; endif; ?>
      <?php $brochure=(int)get_post_meta(get_the_ID(),'_sweet_brochure_id',true); if($brochure) : ?><a class="text-link download" href="<?php echo esc_url(wp_get_attachment_url($brochure)); ?>" target="_blank" rel="noopener"><?php esc_html_e('Scarica la brochure','samsweetlab-child-theme'); ?> ↓</a><?php endif; ?>
      <?php if (!$machine && function_exists('wc_get_product') && ($product = wc_get_product(get_the_ID()))) : ?>
        <div class="sweet-purchase"><?php sweet_purchase_box($product); ?></div>
        <a class="text-link sweet-ask" href="<?php echo esc_url(sweet_page_url('contacts')); ?>"><?php esc_html_e('Hai una domanda? Scrivici','samsweetlab-child-theme'); ?> <span aria-hidden="true">↗</span></a>
        <?php if (isset(WC()->structured_data)) WC()->structured_data->generate_product_data($product); ?>
      <?php else : ?>
        <a class="button" href="<?php echo esc_url(sweet_page_url('contacts')); ?>"><?php esc_html_e('Richiedi informazioni','samsweetlab-child-theme'); ?> <span aria-hidden="true">↗</span></a>
      <?php endif; ?>
    </div>
  </article>
<?php endwhile; ?>
</main>
<?php get_footer(); ?>
