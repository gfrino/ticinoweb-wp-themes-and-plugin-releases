<?php
/** WooCommerce catalog uses the editable introduction from its configured page. */
defined('ABSPATH') || exit;
get_header();
$pages=get_option('samsweetlab_pages',array());
// La pagina degli ingredienti esiste in italiano: titolo, introduzione e testo
// li traduce tW Translate Plus, purché la si renda la pagina in corso.
$sweet_page_id=!empty($pages['ingredients'])?(int)$pages['ingredients']:0;
$sweet_page=$sweet_page_id?get_post($sweet_page_id):null;
?>
<main id="main-content" class="page-main">
  <header class="page-heading wrap"><p class="eyebrow"><?php esc_html_e('Shop online', 'samsweetlab-child-theme'); ?></p><h1><?php echo esc_html($sweet_page?get_the_title($sweet_page):__('Ingredienti e accessori','samsweetlab-child-theme')); ?></h1><?php if($sweet_page && $sweet_page->post_excerpt) : ?><p class="page-intro"><?php echo esc_html(get_the_excerpt($sweet_page)); ?></p><?php endif; ?><?php if (function_exists('sweet_shop_perks')) echo sweet_shop_perks('sweet-perks--heading'); ?></header>
  <div class="page-content wrap"><?php
    if ($sweet_page) { $GLOBALS['post']=$sweet_page; setup_postdata($sweet_page); echo apply_filters('the_content',$sweet_page->post_content); wp_reset_postdata(); }
    else echo do_shortcode('[sweet_catalog]');
  ?></div>
</main>
<?php get_footer(); ?>
