<?php defined('ABSPATH') || exit; $contact=ticinoweb_get_contact_info(); ?>
<footer class="site-footer">
  <div class="footer-top wrap">
    <div class="footer-brand"><?php $footer_logo=sweet_logo_img((int) get_theme_mod('sweet_footer_logo'), array('loading'=>'lazy')); if ($footer_logo) : ?><a class="footer-logo" href="<?php echo esc_url(home_url('/')); ?>"><?php echo $footer_logo; /* escape fatto in sweet_logo_img() */ ?></a><?php else : ?><a href="<?php echo esc_url(home_url('/')); ?>"><?php echo esc_html(get_bloginfo('name')); ?></a><?php endif; ?><p><?php echo esc_html(sweet_text(get_bloginfo('description'),'description')); ?></p></div>
    <div><p class="eyebrow"><?php esc_html_e('Esplora', 'samsweetlab-child-theme'); ?></p><?php wp_nav_menu(array('theme_location'=>'primary','container'=>false,'menu_class'=>'footer-menu','fallback_cb'=>false)); ?></div>
    <div class="footer-contacts"><p class="eyebrow"><?php esc_html_e('Parliamone', 'samsweetlab-child-theme'); ?></p>
      <?php if($contact['email']) : ?><a href="<?php echo esc_url('mailto:'.$contact['email']); ?>"><?php echo esc_html($contact['email']); ?></a><?php endif; ?>
      <?php if($contact['phone']) : ?><a href="<?php echo esc_url('tel:'.preg_replace('/[^+0-9]/','',$contact['phone'])); ?>"><?php echo esc_html(get_option('ticinoweb_contact_phone_display')?:$contact['phone']); ?></a><?php endif; ?>
      <?php if($contact['instagram']) : ?><a href="<?php echo esc_url($contact['instagram']); ?>" target="_blank" rel="noopener">Instagram <?php echo esc_html(sweet_instagram_handle($contact['instagram'])); ?> <span aria-hidden="true">↗</span></a><?php endif; ?>
      <?php if($contact['address']) : ?><p><?php echo esc_html($contact['address']); ?></p><?php endif; ?>
    </div>
  </div>
  <div class="footer-bottom wrap"><span>© <?php echo esc_html(wp_date('Y').' '.get_bloginfo('name')); ?></span><?php if(get_privacy_policy_url()) : ?><a href="<?php echo esc_url(get_privacy_policy_url()); ?>"><?php esc_html_e('Privacy Policy', 'samsweetlab-child-theme'); ?></a><?php endif; ?><a href="<?php echo esc_url(rtrim((string) get_option('home'), '/') . '/tw-login/'); ?>" rel="nofollow"><?php esc_html_e('Area riservata', 'samsweetlab-child-theme'); ?></a><a href="https://ticinoweb.com" target="_blank" rel="noopener">ticinoWEB ↗</a></div>
</footer>
<?php wp_footer(); ?>
</body></html>
