<?php
/** Pagina dei risultati: le schede in griglia come nel catalogo, le pagine in elenco. */
defined('ABSPATH') || exit;
get_header();
global $wp_query;
$cercato = get_search_query();
$schede = array();
$pagine = array();
while (have_posts()) : the_post();
    if (get_post_type() === 'page') $pagine[] = get_post(); else $schede[] = get_post();
endwhile;
?>
<main id="main-content" class="page-main search-page">
  <header class="page-heading wrap">
    <p class="eyebrow"><?php echo esc_html(get_bloginfo('name')); ?></p>
    <h1><?php printf(esc_html__('Risultati per «%s»', 'samsweetlab-child-theme'), esc_html($cercato)); ?></h1>
    <?php if ($wp_query->found_posts) : ?>
      <p class="page-intro"><?php echo esc_html(sprintf(_n('%s risultato', '%s risultati', (int) $wp_query->found_posts, 'samsweetlab-child-theme'), number_format_i18n((int) $wp_query->found_posts))); ?></p>
    <?php endif; ?>
  </header>
  <div class="page-content wrap">
    <form class="catalog-filters search-again" role="search" method="get" action="<?php echo esc_url(home_url('/')); ?>">
      <label><span><?php esc_html_e('Cerca nel sito', 'samsweetlab-child-theme'); ?></span><input type="search" name="s" value="<?php echo esc_attr($cercato); ?>" placeholder="<?php esc_attr_e('Cosa stai cercando?', 'samsweetlab-child-theme'); ?>" enterkeyhint="search"></label>
      <button class="button" type="submit"><?php esc_html_e('Cerca', 'samsweetlab-child-theme'); ?> <span aria-hidden="true">↗</span></button>
    </form>

    <?php if (!$schede && !$pagine) : ?>
      <p class="empty-state"><?php printf(esc_html__('Nessun risultato per «%s».', 'samsweetlab-child-theme'), esc_html($cercato)); ?></p>
    <?php endif; ?>

    <?php if ($schede) : ?>
      <div class="catalog-grid">
        <?php foreach ($schede as $scheda) sweet_card($scheda); ?>
      </div>
    <?php endif; ?>

    <?php if ($pagine) : ?>
      <ul class="search-pages">
        <?php foreach ($pagine as $pagina) : ?>
          <li><a class="text-link" href="<?php echo esc_url(get_permalink($pagina)); ?>"><?php echo esc_html(get_the_title($pagina)); ?> <span aria-hidden="true">↗</span></a></li>
        <?php endforeach; ?>
      </ul>
    <?php endif; ?>

    <?php the_posts_pagination(array('mid_size' => 1, 'prev_text' => '←', 'next_text' => '→')); ?>
  </div>
</main>
<?php get_footer(); ?>
