Lenis 1.3.26 (npm, dist/lenis.min.js), licenza MIT: LICENSE-lenis.txt.
Lo carica site.js solo con mouse o trackpad e senza «riduci animazioni».
