Caratteri del tema, licenza SIL Open Font License 1.1 (OFL-*.txt):
- Sweet Bean (sweet-bean.woff2) - titoli dalla 2.5.0. È BUTTER BEAN di JFFF ritagliato al latino con
  gli accenti (it, en, de, fr, hu, ro, sk): BUTTER BEAN è un nome riservato dalla licenza, quindi la
  versione ritagliata ha un altro nome (OFL-butter-bean.txt).
- Alegreya Black, solo cirillico (alegreya-black-cyrillic.woff2, Huerta Tipográfica) - le lettere russe
  dei titoli, che Butter Bean non ha; il browser lo scarica solo sulle pagine in russo.
- Sofia Sans Extra Condensed (Lettersoup) - scritte strette (menu, pulsanti, adesivi)
- Sofia Sans + Italic (Lettersoup) - testo
Non più usati (restano per tornare indietro): Modak (2.4.0), Sweet Groove (2.3.x, da Shrikhand,
tools/font/build-sweet-groove.py), Big Shoulders Stencil (fino alla 2.2.x).
Sottoinsiemi in WOFF2; originali da Google Fonts (github.com/google/fonts) e da JFFF.
