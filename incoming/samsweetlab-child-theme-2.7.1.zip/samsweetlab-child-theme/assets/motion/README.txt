GSAP 3.15.0 e ScrollTrigger (GreenSock), copiati dal pacchetto npm "gsap" (dist/).
Licenza: Standard 'no charge' license, https://gsap.com/standard-license
(gratuita anche per siti commerciali). Il tema li carica da qui: nessun server esterno.
Per aggiornare: npm pack gsap, poi copiare dist/gsap.min.js e dist/ScrollTrigger.min.js
e alzare la versione in functions.php.
