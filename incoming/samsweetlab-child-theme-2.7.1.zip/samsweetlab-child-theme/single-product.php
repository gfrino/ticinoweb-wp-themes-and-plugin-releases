<?php defined('ABSPATH') || exit; require get_stylesheet_directory() . '/single.php';
