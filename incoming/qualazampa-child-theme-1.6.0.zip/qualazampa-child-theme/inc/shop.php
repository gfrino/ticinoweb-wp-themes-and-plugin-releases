<?php
defined('ABSPATH') || exit;
add_filter('woocommerce_product_query_tax_query',static function($tax){
    if(is_admin())return $tax;
    foreach(['qz_brand'=>'pa_marche','qz_kind'=>'pa_tipo-prodotto'] as $param=>$taxonomy){
        $id=isset($_GET[$param])?absint($_GET[$param]):0;
        if($id&&term_exists($id,$taxonomy))$tax[]=['taxonomy'=>$taxonomy,'field'=>'term_id','terms'=>[$id]];
    }
    return $tax;
});
function qz_shop_filters(){
    if(is_front_page())return;
    echo '<form class="qz-filters" method="get" action="'.esc_url(is_product_category()?get_term_link(get_queried_object()):wc_get_page_permalink('shop')).'">';
    foreach(['qz_brand'=>['pa_marche',__('Tutte le marche','qualazampa')],'qz_kind'=>['pa_tipo-prodotto',__('Tutti i tipi di prodotto','qualazampa')]] as $param=>$field){
        $selected=isset($_GET[$param])?absint($_GET[$param]):0;
        echo '<label><span class="screen-reader-text">'.esc_html($field[1]).'</span><select name="'.esc_attr($param).'">';echo '<option value="">'.esc_html($field[1]).'</option>';
        $terms=get_terms(['taxonomy'=>$field[0],'hide_empty'=>true]);if(!is_wp_error($terms))foreach($terms as $t)echo '<option value="'.esc_attr($t->term_id).'" '.selected($selected,$t->term_id,false).'>'.esc_html($t->name).'</option>';
        echo '</select></label>';
    }
    if(get_search_query())echo '<input type="hidden" name="s" value="'.esc_attr(get_search_query()).'"><input type="hidden" name="post_type" value="product">';
    echo '<button type="submit">'.esc_html__('Filtra prodotti','qualazampa').'</button><a href="'.esc_url(wc_get_page_permalink('shop')).'">'.esc_html__('Azzera filtri','qualazampa').'</a></form>';
}
add_action('woocommerce_before_shop_loop','qz_shop_filters',15);
add_action('woocommerce_no_products_found','qz_shop_filters',5);
add_filter('loop_shop_columns',static function(){return 4;});
add_filter('loop_shop_per_page',static function(){return 24;});
// Preserve the complete packshot; generated Woo thumbnails may already be cropped.
add_filter('single_product_archive_thumbnail_size',static function(){return 'large';});

// Give native WooCommerce cards a readable hierarchy without changing commerce data.
add_action('woocommerce_shop_loop_item_title',static function(){
    global $product;
    if(!$product)return;
    $brands=get_the_terms($product->get_id(),'pa_marche');
    if($brands&&!is_wp_error($brands))echo '<span class="qz-product-brand">'.esc_html($brands[0]->name).'</span>';
    else echo '<span class="qz-product-brand" aria-hidden="true">&nbsp;</span>';
},5);
add_action('after_setup_theme',static function(){
    remove_action('woocommerce_shop_loop_item_title','woocommerce_template_loop_product_title',10);
    add_action('woocommerce_shop_loop_item_title',static function(){
        global $product;
        if(!$product)return;
        echo '<h2 class="woocommerce-loop-product__title">'.esc_html(preg_replace('/\s*\[[^\]]*\]\s*$/','',$product->get_name())).'</h2>';
    },10);
},110);

// Catalogue pagination uses explicit labels instead of decorative arrows.
add_filter('woocommerce_pagination_args',static function($args){
    $args['prev_text']=esc_html__('Precedente','qualazampa');
    $args['next_text']=esc_html__('Successiva','qualazampa');
    return $args;
});
