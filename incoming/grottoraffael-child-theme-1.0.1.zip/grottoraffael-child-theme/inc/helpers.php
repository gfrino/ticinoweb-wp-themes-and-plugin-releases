<?php
/**
 * Funzioni comuni: testi tradotti dal livello del parent, icone SVG, selettore della lingua.
 */
defined('ABSPATH') || exit;

/**
 * Testi che non finiscono come testo visibile nella pagina (attributi, messaggi degli script):
 * passano dal livello di traduzione del parent, così tW Translate li traduce come gli altri.
 */
function grottoraffael_t($text, $key)
{
    return function_exists('ticinoweb_frontend_text') ? ticinoweb_frontend_text($text, 'grottoraffael:' . $key) : $text;
}

/** Icone in linea (niente font di icone, niente richieste esterne). */
function grottoraffael_icon($name, $size = 16)
{
    $paths = array(
        'gift'      => '<path d="M20 12v9H4v-9M2 7h20v5H2zM12 21V7M12 7H7.5a2.5 2.5 0 1 1 0-5C11 2 12 7 12 7zm0 0h4.5a2.5 2.5 0 1 0 0-5C13 2 12 7 12 7z" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/>',
        'check'     => '<path d="m4 12.5 5 5L20 6.5" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"/>',
        'wine'      => '<path d="M10 2h4v4.5c0 1 2 2 2 4.5v10a1 1 0 0 1-1 1H9a1 1 0 0 1-1-1V11c0-2.5 2-3.5 2-4.5z" fill="currentColor"/>',
        'book'      => '<path d="M2 5c3-1.3 6.5-1.3 9.2.6V20c-2.7-1.6-6.2-1.6-9.2-.4zM22 5c-3-1.3-6.5-1.3-9.2.6V20c2.7-1.6 6.2-1.6 9.2-.4z" fill="currentColor"/>',
        'facebook'  => '<path d="M20 2H4a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h8.6v-7.7H10V11.3h2.6V9.1c0-2.6 1.6-4 3.9-4 1.1 0 2 .1 2.3.1v2.7h-1.6c-1.3 0-1.5.6-1.5 1.5v1.9h3l-.4 3h-2.6V22H20a2 2 0 0 0 2-2V4a2 2 0 0 0-2-2z" fill="currentColor"/>',
        'instagram' => '<rect x="3" y="3" width="18" height="18" rx="5" fill="none" stroke="currentColor" stroke-width="2"/><circle cx="12" cy="12" r="4" fill="none" stroke="currentColor" stroke-width="2"/><circle cx="17.3" cy="6.7" r="1.2" fill="currentColor"/>',
        'phone'     => '<path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1 1 .4 1.9.7 2.8a2 2 0 0 1-.5 2.1L8.1 9.9a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.4c.9.3 1.8.6 2.8.7a2 2 0 0 1 1.7 2z" fill="currentColor"/>',
        'mobile'    => '<rect x="6" y="2" width="12" height="20" rx="2.5" fill="currentColor"/><rect x="8" y="4.5" width="8" height="13" fill="#fff"/><circle cx="12" cy="19.6" r="1" fill="#fff"/>',
        'dot'       => '<circle cx="12" cy="12" r="9" fill="none" stroke="currentColor" stroke-width="2.4"/><circle cx="12" cy="12" r="4" fill="currentColor"/>',
        'quote'     => '<path d="M10 6H5.5A2.5 2.5 0 0 0 3 8.5V13a2 2 0 0 0 2 2h3c0 2-1 3-3 3.5V21c4-.5 6-3.3 6-7.5V7a1 1 0 0 0-1-1zm11 0h-4.5A2.5 2.5 0 0 0 14 8.5V13a2 2 0 0 0 2 2h3c0 2-1 3-3 3.5V21c4-.5 6-3.3 6-7.5V7a1 1 0 0 0-1-1z" fill="currentColor"/>',
        'star'      => '<path d="m12 2.5 2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 17.4l-5.9 3.1 1.2-6.5-4.8-4.6 6.6-.9z" fill="currentColor"/>',
        'play'      => '<circle cx="12" cy="12" r="10.5" fill="none" stroke="currentColor" stroke-width="1.4"/><path d="M9.5 7.5v9l7-4.5z" fill="currentColor"/>',
        'chevron'   => '<path d="m6 9 6 6 6-6" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/>',
        'close'     => '<path d="M6 6l12 12M18 6 6 18" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"/>',
        'left'      => '<path d="m15 5-7 7 7 7" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/>',
        'right'     => '<path d="m9 5 7 7-7 7" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/>',
        'cart'      => '<path d="M3 4h2.5l2.2 10.2a1.5 1.5 0 0 0 1.5 1.2h8.4a1.5 1.5 0 0 0 1.5-1.1L21 8H6.3" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/><circle cx="9.5" cy="19.5" r="1.5" fill="currentColor"/><circle cx="17.5" cy="19.5" r="1.5" fill="currentColor"/>',
    );
    if (!isset($paths[$name])) {
        return '';
    }
    return '<svg class="gr-icon gr-icon--' . esc_attr($name) . '" viewBox="0 0 24 24" width="' . (int) $size . '" height="' . (int) $size . '" aria-hidden="true" focusable="false">' . $paths[$name] . '</svg>';
}

/**
 * Selettore della lingua di tW Translate Plus come sull'originale: bandiera della lingua corrente
 * con una freccia, le altre bandiere in una tendina. Vuoto con una sola lingua o senza il plugin.
 * $variant «flags» = solo le bandiere delle altre lingue in fila (fondo del footer).
 */
function grottoraffael_language_switcher($variant = 'dropdown')
{
    if (!function_exists('twtr_get_languages')) {
        return '<!-- grottoraffael: tW Translate Plus non attivo, nessun selettore lingua -->';
    }
    $languages = twtr_get_languages();
    if (count($languages) < 2) {
        return '';
    }
    $flag = function ($lang) {
        $url = class_exists('Twtr_Switcher') ? Twtr_Switcher::flag_url($lang['slug']) : '';
        return $url ? '<img class="gr-lang__flag" src="' . esc_url($url) . '" alt="' . esc_attr($lang['label']) . '" width="18" height="12">' : '<span class="gr-lang__code">' . esc_html(strtoupper($lang['slug'])) . '</span>';
    };
    $link = function ($lang) use ($flag) {
        return '<a href="' . esc_url($lang['url']) . '" hreflang="' . esc_attr(str_replace('_', '-', $lang['locale'])) . '" lang="' . esc_attr($lang['slug']) . '" title="' . esc_attr($lang['label']) . '">' . $flag($lang) . '</a>';
    };
    $current = null;
    $others = '';
    foreach ($languages as $lang) {
        if ($lang['is_current']) {
            $current = $lang;
            continue;
        }
        $others .= '<li>' . $link($lang) . '</li>';
    }
    $current = $current ?: reset($languages);
    if ($variant === 'flags') {
        return '<ul class="gr-lang-flags">' . $others . '</ul>';
    }
    return '<details class="gr-lang"><summary aria-label="' . esc_attr(grottoraffael_t(__('Lingua', 'grottoraffael-child-theme'), 'lang:label') . ': ' . $current['label']) . '">'
        . $flag($current) . grottoraffael_icon('chevron', 12) . '</summary><ul>' . $others . '</ul></details>';
}

/** Link «Buono Regalo» dell'header: la pagina con il template o lo slug «buono-regalo». */
function grottoraffael_voucher_url()
{
    $page = get_page_by_path('buono-regalo');
    return $page ? get_permalink($page) : '';
}

/** Numero di telefono per i link tel: (solo cifre e +). */
function grottoraffael_tel($number)
{
    return 'tel:' . preg_replace('/[^\d+]/', '', (string) $number);
}

/**
 * Fascia con foto, titolo e i due segni ai lati (Il Grotto, Contatto, Banchetti, Shop).
 * Le pagine la scrivono nel contenuto con lo stesso HTML.
 */
function grottoraffael_banner($title, $image_id = 0, $class = '')
{
    $img = $image_id ? wp_get_attachment_image($image_id, 'full', false, array('class' => 'gr-banner__image', 'alt' => '', 'fetchpriority' => 'high', 'loading' => 'eager', 'sizes' => '100vw')) : '';
    return '<section class="gr-banner ' . esc_attr($class) . '">' . $img
        . '<h1 class="gr-banner__title"><span class="gr-banner__mark" aria-hidden="true">x</span>' . esc_html($title) . '<span class="gr-banner__mark" aria-hidden="true">x</span></h1></section>';
}
