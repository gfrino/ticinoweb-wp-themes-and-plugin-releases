<!-- Footer Design (CONTATTI) -->
<footer class="bg-brand-deepblue text-white py-16 border-t-[10px] border-brand-red" id="contatti">
    <div class="container mx-auto px-6 md:px-12 max-w-6xl">
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-12">
            <!-- Left Info -->
            <div class="lg:col-span-1">
                <div class="mb-8">
                    <img src="<?php echo esc_url(get_stylesheet_directory_uri() . '/assets/media/logo-square-trasparent.png'); ?>" alt="Fondazione DEMIAP" class="w-32 md:w-40 h-auto object-contain" loading="lazy" />
                </div>
                <h4 class="font-serif text-xl font-bold tracking-widest uppercase mb-6 text-brand-red flex items-center gap-2">
                    <span class="material-symbols-outlined">contact_support</span> Modulo Contatti
                </h4>
                <div class="text-sm font-light text-white/80 leading-relaxed mb-6">
                    <p>Tramite questo modulo puoi scriverci direttamente per richieste, informazioni sulle donazioni o necessità spirituali.</p>
                </div>
            </div>
            
            <!-- Contact Form Area (Takes remaining columns) -->
            <div class="lg:col-span-2 bg-white/5 p-8 rounded-sm relative">
                
                <?php
                $demiap_privacy_url = function_exists('get_privacy_policy_url') && get_privacy_policy_url() ? get_privacy_policy_url() : site_url('/privacy-policy/');
                $demiap_mail        = get_option('ticinoweb_contact_email') ?: get_option('admin_email');
                ?>
                <!-- Modulo gestito dal parent (ticinoweb_submit_form): Invii Ricevuti, antispam e reCAPTCHA opzionale -->
                <div id="demiapFormSuccess" class="hidden bg-green-500/20 border border-green-500/50 text-green-200 p-8 rounded-sm text-center flex-col justify-center items-center" role="status" aria-live="polite" tabindex="-1">
                    <span class="material-symbols-outlined text-6xl mb-4 text-green-400" aria-hidden="true">check_circle</span>
                    <p class="font-serif text-2xl mb-2">Grazie!</p>
                    <p id="demiapFormSuccessText" class="text-sm font-light leading-relaxed max-w-md mx-auto"></p>
                </div>

                <form id="demiapContactForm" data-demiap-contact-form data-ajax-url="<?php echo esc_url(admin_url('admin-ajax.php')); ?>" data-fallback-mail="<?php echo esc_attr($demiap_mail); ?>" method="post" action="#contatti" novalidate class="space-y-6">
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <label for="demiap-cf-nome" class="block text-xs uppercase tracking-widest text-white/70 mb-2">Nome e Cognome *</label>
                            <input type="text" id="demiap-cf-nome" name="nome" required maxlength="120" autocomplete="name" class="w-full bg-white/10 border border-white/20 text-white rounded-sm px-4 py-3 focus:outline-none focus:border-brand-red focus:ring-0 transition-colors placeholder-white/40" placeholder="Il tuo nome" />
                            <div class="demiap-field-error" data-error-for="nome" role="alert"></div>
                        </div>
                        <div>
                            <label for="demiap-cf-email" class="block text-xs uppercase tracking-widest text-white/70 mb-2">Indirizzo Email *</label>
                            <input type="email" id="demiap-cf-email" name="email" required maxlength="190" autocomplete="email" class="w-full bg-white/10 border border-white/20 text-white rounded-sm px-4 py-3 focus:outline-none focus:border-brand-red focus:ring-0 transition-colors placeholder-white/40" placeholder="La tua email" />
                            <div class="demiap-field-error" data-error-for="email" role="alert"></div>
                        </div>
                    </div>
                    <div>
                        <label for="demiap-cf-messaggio" class="block text-xs uppercase tracking-widest text-white/70 mb-2">Il tuo messaggio *</label>
                        <textarea id="demiap-cf-messaggio" name="messaggio" required rows="5" maxlength="5000" class="w-full bg-white/10 border border-white/20 text-white rounded-sm px-4 py-3 focus:outline-none focus:border-brand-red focus:ring-0 transition-colors placeholder-white/40" placeholder="Come possiamo aiutarti?"></textarea>
                        <div class="demiap-field-error" data-error-for="messaggio" role="alert"></div>
                    </div>
                    <p class="demiap-hp" aria-hidden="true">
                        <label for="demiap-cf-hp">Lascia vuoto questo campo</label>
                        <input type="text" id="demiap-cf-hp" name="tw_hp" tabindex="-1" autocomplete="off" />
                    </p>
                    <div>
                        <label class="flex items-start gap-3 text-sm text-white/80 leading-relaxed cursor-pointer">
                            <input type="checkbox" name="privacy" value="1" required class="mt-1 rounded-sm" />
                            <span>Ho letto la <a href="<?php echo esc_url($demiap_privacy_url); ?>" target="_blank" rel="noopener" class="underline hover:text-white">Privacy Policy</a>: i dati inviati servono solo a rispondere alla mia richiesta.</span>
                        </label>
                        <div class="demiap-field-error" data-error-for="privacy" role="alert"></div>
                    </div>
                    <div class="pt-2">
                        <button type="submit" class="w-full bg-brand-red text-white font-bold uppercase tracking-widest py-4 hover:bg-white hover:text-brand-red transition-colors shadow-[0_0_15px_rgba(231,54,59,0.3)] hover:shadow-[0_0_25px_rgba(255,255,255,0.5)]">
                            Invia Messaggio
                        </button>
                        <div id="demiapFormStatus" class="demiap-form-status" role="status" aria-live="polite"></div>
                    </div>
                </form>

            </div>
        </div>

        <!-- Social & More info -->
        <div class="mt-16 border-t border-white/10 pt-10 flex flex-col items-center">
            <h4 class="text-sm uppercase tracking-widest text-white/50 text-center w-full mb-6">Seguici per rimanere aggiornato</h4>
            <div class="flex gap-4">
                <a href="https://www.facebook.com/demiap.ch/" target="_blank" rel="noopener noreferrer" class="w-12 h-12 rounded-full border border-white/20 flex items-center justify-center hover:bg-[#1877F2] hover:border-[#1877F2] transition-all group shadow-lg">
                    <svg class="w-5 h-5 fill-white group-hover:scale-110 transition-transform" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.469h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.469h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
                    </svg>
                </a>
                <a href="https://www.instagram.com/demiap_official/" target="_blank" rel="noopener noreferrer" class="w-12 h-12 rounded-full border border-white/20 flex items-center justify-center hover:bg-[#E1306C] hover:border-[#E1306C] transition-all group shadow-lg">
                    <svg class="w-5 h-5 fill-white group-hover:scale-110 transition-transform" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zM12 0C8.741 0 8.333.014 7.053.072 2.695.272.273 2.69.073 7.052.014 8.333 0 8.741 0 12c0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98C8.333 23.986 8.741 24 12 24c3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98C15.668.014 15.259 0 12 0zm0 5.838a6.162 6.162 0 100 12.324 6.162 6.162 0 000-12.324zM12 16a4 4 0 110-8 4 4 0 010 8zm6.406-11.845a1.44 1.44 0 100 2.881 1.44 1.44 0 000-2.881z"/>
                    </svg>
                </a>
            </div>
        </div>

        <!-- Footer Bottom -->
        <div class="w-full text-center mt-12 text-xs md:text-sm font-sans text-white/60 flex flex-col items-center">
            <div class="flex flex-col md:flex-row items-center gap-2 md:gap-0">
                <span>© <?php echo date('Y'); ?> Fondazione DEMIAP. Tutti i diritti riservati.</span>
                <span class="opacity-30 mx-2 hidden md:inline">|</span>
                <span>Design by <a href="https://ticinoweb.net" target="_blank" rel="noopener noreferrer" class="hover:text-white transition-colors">ticinoWEB</a></span>
            </div>
            <div class="mt-6 flex flex-wrap justify-center items-center gap-x-4 md:gap-x-6 gap-y-3">
                <a class="hover:text-brand-red transition-colors" href="<?php echo esc_url(site_url('/privacy-policy/')); ?>">Privacy Policy</a>
                <span class="opacity-30 hidden md:inline">|</span>
                <?php if (get_option('tw_cookie_banner_enable')) : ?>
                <button type="button" class="text-brand-red hover:text-brand-red transition-colors" data-demiap-cookie-preferences>Preferenze cookie</button>
                <span class="opacity-30 hidden md:inline">|</span>
                <?php endif; ?>
                <a class="hover:text-brand-red transition-colors" href="<?php echo esc_url(trailingslashit(get_option('home')) . 'tw-login/'); ?>" rel="nofollow">Area Riservata</a>
            </div>
        </div>
    </div>
</footer>

<!-- ScrollSpy Navigation -->
<style>
    html { scroll-behavior: smooth; }
    
    #scrollSpyDots a.active span {
        opacity: 1 !important;
        transform: translateX(0) !important;
        background-color: #CC2027 !important;
    }
    #scrollSpyDots a.active .scrollspy-dot {
        background-color: #CC2027 !important;
        border-color: #CC2027 !important;
        transform: scale(1.5) !important;
    }
</style>

<!-- Nascosto su mobile (hidden) ma visibile da tablet in su (md:flex) -->
<div class="hidden md:flex fixed right-3 md:right-6 top-1/2 -translate-y-1/2 z-[9999] flex-col gap-3 md:gap-4 items-end" id="scrollSpyDots">
    <?php
    $scroll_sections = [
        'home' => 'Home',
        'fondazione' => 'Fondazione',
        'chisiamo' => 'Chi Siamo',
        'attivita' => 'Le Nostre Attività',
        'agenda' => 'Agenda & Notizie',
        'donazioni' => 'Sostienici',
        'contatti' => 'Contatti'
    ];
    foreach($scroll_sections as $id => $label): ?>
        <a href="<?php echo is_front_page() ? '' : esc_url(home_url('/')); ?>#<?php echo $id; ?>" class="group flex items-center gap-3 relative h-6 w-6 justify-end cursor-pointer scrollspy-link" data-target="<?php echo $id; ?>">
            <span class="opacity-0 group-hover:opacity-100 transition-all duration-300 bg-brand-deepblue text-white text-[10px] py-1 px-2 rounded-sm font-bold uppercase tracking-widest whitespace-nowrap drop-shadow-md translate-x-2 group-hover:translate-x-0 absolute right-8 pointer-events-none hidden md:block"><?php echo $label; ?></span>
            <div class="w-3 h-3 md:w-2.5 md:h-2.5 rounded-full bg-gray-400 border border-white shadow-md shadow-black/30 group-hover:bg-brand-red group-hover:border-brand-red group-hover:scale-125 transition-all duration-300 scrollspy-dot"></div>
        </a>
    <?php endforeach; ?>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // === AOS Animations Setup ===
    
    // Intestazioni principali
    document.querySelectorAll('section h2, section h3, section h4').forEach(el => {
        el.setAttribute('data-aos', 'fade-up');
        el.setAttribute('data-aos-duration', '800');
    });

    // Elementi a griglia (animazione a cascata/staggered)
    document.querySelectorAll('section .grid > div, footer .grid > div').forEach((el, index) => {
        el.setAttribute('data-aos', 'fade-up');
        el.setAttribute('data-aos-duration', '800');
        el.setAttribute('data-aos-delay', (index % 3) * 150 + '');
    });

    // Fisarmonica (Accordion)
    document.querySelectorAll('details').forEach((el, index) => {
        el.setAttribute('data-aos', 'fade-left');
        el.setAttribute('data-aos-duration', '600');
        el.setAttribute('data-aos-delay', (index % 6) * 100 + '');
    });

    // Immagini principali
    document.querySelectorAll('section img.shadow-2xl, section img.rounded-full, section img.border-white\\/10').forEach(el => {
        el.setAttribute('data-aos', 'zoom-in');
        el.setAttribute('data-aos-duration', '1000');
    });

    // Pulsanti donazioni
    document.querySelectorAll('#donazioni a.group').forEach((el, index) => {
        el.setAttribute('data-aos', 'zoom-in-up');
        el.setAttribute('data-aos-delay', (index * 150) + '');
    });
    
    // Box coordinate bancarie
    const ibanBox = document.querySelector('#donazioni .bg-white');
    if(ibanBox) {
        ibanBox.setAttribute('data-aos', 'flip-up');
        ibanBox.setAttribute('data-aos-duration', '1000');
    }

    // Inizializza AOS
    if (typeof AOS !== 'undefined') {
        AOS.init({
            once: true,
            offset: 80,
            easing: 'ease-out-cubic'
        });
    }

    // === ScrollSpy Navigation ===
    const navLinksSpy = document.querySelectorAll('#scrollSpyDots a');
    const sectionsSpy = [];
    
    if (navLinksSpy.length > 0) {
        navLinksSpy.forEach(a => {
            const targetId = a.getAttribute('data-target');
            const el = document.getElementById(targetId);
            if (el) {
                sectionsSpy.push(el);
            } else {
                a.style.display = 'none';
            }
        });

        function highlightDot() {
            let current = '';
            const scrollY = window.pageYOffset || document.documentElement.scrollTop;

            sectionsSpy.forEach(section => {
                const rect = section.getBoundingClientRect();
                const sectionTop = rect.top + scrollY;
                if (scrollY >= (sectionTop - 300)) {
                    current = section.getAttribute('id');
                }
            });

            navLinksSpy.forEach(a => {
                a.classList.remove('active');
                if (current && a.getAttribute('data-target') === current) {
                    a.classList.add('active');
                }
            });
        }

        window.addEventListener('scroll', highlightDot, { passive: true });
        setTimeout(highlightDot, 100);
    }
});
</script>

<?php wp_footer(); ?>
</body>
</html>
