<?php
/**
 * Header template per Fondazione DEMIAP Child Theme
 */
?>
<!DOCTYPE html>
<html class="scroll-smooth" <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>"/>
    <meta content="width=device-width, initial-scale=1.0" name="viewport"/>
    <?php wp_head(); ?>
</head>
<body class="bg-white text-gray-900 antialiased overflow-x-hidden">
<?php wp_body_open(); ?>

<!-- Sfondo oscurante per il menu mobile -->
<div id="menuBackdrop" class="fixed inset-0 bg-brand-deepblue/80 backdrop-blur-sm z-40 hidden opacity-0 transition-opacity duration-300"></div>

<header class="bg-white w-full z-50 py-5 md:py-6 px-6 md:px-12 border-b border-gray-100 flex items-center justify-center sticky top-0 shadow-sm relative">
    <div class="absolute right-6 top-1/2 -translate-y-1/2 md:hidden z-50">
        <button id="mobileMenuBtn" class="text-brand-deepblue p-2">
            <span class="material-symbols-outlined text-3xl">menu</span>
        </button>
    </div>
    
    <!-- Menu Laterale (Side Drawer) su mobile, Menu orizzontale su desktop -->
    <nav id="mainNav" class="fixed top-0 right-0 h-screen w-64 bg-white shadow-2xl z-50 transform translate-x-full transition-transform duration-300 ease-in-out md:relative md:h-auto md:w-auto md:translate-x-0 md:bg-transparent md:shadow-none flex flex-col md:flex-row justify-start md:justify-center items-start md:items-center gap-y-6 md:gap-y-4 gap-x-4 pt-10 px-8 md:pt-0 md:px-0 text-sm md:text-xs font-semibold tracking-widest uppercase">
        <div class="w-full flex justify-end md:hidden mb-2 -mr-2">
            <button id="closeMenuBtn" class="text-brand-deepblue p-2 hover:bg-gray-100 rounded-full transition-colors">
                <span class="material-symbols-outlined text-3xl">close</span>
            </button>
        </div>
        <a class="text-brand-deepblue w-full md:w-auto hover:text-brand-red transition-colors" href="<?php echo esc_url(home_url('/')); ?>">HOME</a>
        <span class="text-gray-300 hidden md:inline">|</span>
        <a class="text-gray-600 hover:text-brand-deepblue transition-colors w-full md:w-auto" href="<?php echo esc_url(home_url('/#fondazione')); ?>">FONDAZIONE</a>
        <span class="text-gray-300 hidden md:inline">|</span>
        <a class="text-gray-600 hover:text-brand-deepblue transition-colors w-full md:w-auto" href="<?php echo esc_url(home_url('/chi-siamo/')); ?>">CHI SIAMO</a>
        <span class="text-gray-300 hidden md:inline">|</span>
        <a class="text-gray-600 hover:text-brand-deepblue transition-colors w-full md:w-auto" href="<?php echo esc_url(home_url('/attivita/')); ?>">ATTIVITÀ</a>
        <span class="text-gray-300 hidden md:inline">|</span>
        <a class="text-gray-600 hover:text-brand-deepblue transition-colors w-full md:w-auto" href="<?php echo esc_url(home_url('/agenda/')); ?>">AGENDA</a>
        <span class="text-gray-300 hidden md:inline">|</span>
        <a class="text-gray-600 hover:text-brand-deepblue transition-colors w-full md:w-auto" href="<?php echo esc_url(home_url('/sostienici/')); ?>">SOSTIENICI</a>
    </nav>
</header>
<script>
document.addEventListener('DOMContentLoaded', function() {
    const mobileMenuBtn = document.getElementById('mobileMenuBtn');
    const closeMenuBtn = document.getElementById('closeMenuBtn');
    const mainNav = document.getElementById('mainNav');
    const backdrop = document.getElementById('menuBackdrop');
    const navLinks = mainNav.querySelectorAll('a');

    function openMenu() {
        mainNav.classList.remove('translate-x-full');
        backdrop.classList.remove('hidden');
        // Piccolo delay per permettere al display:block di applicarsi prima dell'opacità
        setTimeout(() => backdrop.classList.remove('opacity-0'), 10);
        document.body.classList.add('overflow-hidden'); // Blocca lo scroll della pagina
    }

    function closeMenu() {
        mainNav.classList.add('translate-x-full');
        backdrop.classList.add('opacity-0');
        setTimeout(() => backdrop.classList.add('hidden'), 300); // Attendi la fine della transizione
        document.body.classList.remove('overflow-hidden'); // Sblocca lo scroll
    }

    mobileMenuBtn.addEventListener('click', openMenu);
    closeMenuBtn.addEventListener('click', closeMenu);
    backdrop.addEventListener('click', closeMenu);

    // Chiudi il menu quando si clicca su un link (su mobile)
    navLinks.forEach(link => {
        link.addEventListener('click', function() {
            if (window.innerWidth < 768) {
                closeMenu();
            }
        });
    });
});
</script>
