<?php
/**
 * Front Page - Fondazione DEMIAP Child Theme
 * Template personalizzato basato rigorosamente sulla struttura Tailwind fornita.
 */

get_header();
?>

    <!-- Hero Section SLIDER DINAMICO DAL CMS -->
    <?php
    // Utilizziamo un array fisso per la Hero, forzando il nuovo video
    $slides = [
        [
            'video' => fondazionedemiap_hero_video_url(),
            'poster' => fondazionedemiap_hero_poster_url(),
            'title' => 'Un altro modo di vivere<br>la comunità',
            'desc' => 'Fondazione DEMIAP<br>Un luogo di spiritualità, crescita e sostegno.'
        ]
    ];
    ?>

    <section class="relative w-full bg-white pt-6 md:pt-10 pb-6" id="home">
        <div class="container mx-auto px-6 md:px-8 max-w-[1600px]">
            <div
                class="relative w-full h-[45vh] md:h-[80vh] min-h-[320px] md:min-h-[600px] rounded-none overflow-hidden">
                <div id="demiapTailwindSlider" class="flex w-full h-full transition-transform duration-700 ease-in-out">
                    <?php foreach ($slides as $index => $slide):
                        ?>
                        <div class="relative w-full h-full flex-shrink-0 flex items-center justify-center">
                            <div class="absolute inset-0 z-0">
                                <?php if (!empty($slide['video'])): ?>
                                    <video class="w-full h-full object-cover" autoplay loop muted playsinline<?php if (!empty($slide['poster'])): ?> poster="<?php echo esc_url($slide['poster']); ?>"<?php endif; ?>>
                                        <source src="<?php echo esc_url($slide['video']); ?>" type="video/mp4">
                                    </video>
                                <?php elseif (!empty($slide['image'])): ?>
                                    <img alt="<?php echo esc_attr($slide['title']); ?>" class="w-full h-full object-cover"
                                        src="<?php echo esc_url($slide['image']); ?>" />
                                <?php else: ?>
                                    <div class="w-full h-full bg-brand-deepblue"></div>
                                <?php endif; ?>
                                <div class="absolute inset-0 bg-brand-deepblue/30"></div>
                            </div>
                            <!-- Content centrale -->
                            <div class="relative z-10 text-center px-6 max-w-6xl mx-auto flex flex-col items-center">
                                <img src="<?php echo esc_url(get_stylesheet_directory_uri() . '/assets/media/logo-square-trasparent.png'); ?>"
                                    alt="Logo Fondazione DEMIAP"
                                    class="w-16 h-16 md:w-24 md:h-24 object-contain mb-3 md:mb-8 drop-shadow-lg" />
                                <h1 class="font-serif text-3xl sm:text-4xl md:text-6xl lg:text-7xl font-bold text-white tracking-wide uppercase mb-2 md:mb-6 drop-shadow-lg magic-title"
                                    style="line-height: 1.28 !important;">
                                    <?php echo $slide['title']; ?>
                                </h1>
                                <p
                                    class="font-sans text-white/90 text-sm md:text-xl font-light tracking-wide drop-shadow-md <?php echo !empty($slide['btn1_text']) ? 'mb-4 md:mb-10' : ''; ?>">
                                    <?php echo $slide['desc']; ?>
                                </p>

                                <div class="flex justify-center mt-3 md:mt-4">
                                    <a href="<?php echo esc_url(home_url('/#fondazione')); ?>"
                                        class="inline-block border border-brand-red bg-brand-red text-white rounded-sm px-6 py-3 md:px-10 md:py-4 text-xs md:text-sm font-semibold tracking-widest hover:bg-white hover:text-brand-red transition-all transform hover:-translate-y-1 shadow-lg uppercase">
                                        La Fondazione
                                    </a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>

                <!-- Frecce ed Indicatori visibili solo se ci sono più slide -->
                <?php if (count($slides) > 1): ?>
                    <button id="sliderPrevBtn"
                        class="absolute left-4 top-1/2 -translate-y-1/2 w-12 h-12 rounded-full border-2 border-white/30 bg-black/20 backdrop-blur-sm text-white flex items-center justify-center hover:bg-brand-red hover:border-brand-red transition-all z-20">
                        <span class="material-symbols-outlined">arrow_back_ios_new</span>
                    </button>
                    <button id="sliderNextBtn"
                        class="absolute right-4 top-1/2 -translate-y-1/2 w-12 h-12 rounded-full border-2 border-white/30 bg-black/20 backdrop-blur-sm text-white flex items-center justify-center hover:bg-brand-red hover:border-brand-red transition-all z-20">
                        <span class="material-symbols-outlined">arrow_forward_ios</span>
                    </button>
                    <div id="sliderDots" class="absolute bottom-8 left-1/2 -translate-x-1/2 flex gap-4 z-20">
                        <!-- Pallini generati dinamicamente via JS -->
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </section>

    <!-- Script per l'animazione minimale dello slider in puro JS Tailwind -->
    <?php if (count($slides) > 1): ?>
        <script>
            document.addEventListener('DOMContentLoaded', () => {
                const track = document.getElementById('demiapTailwindSlider');
                if (!track) return;
                const slides = Array.from(track.children);
                if (slides.length <= 1) return;

                let currentIndex = 0;
                let slideInterval;
                const nextBtn = document.getElementById('sliderNextBtn');
                const prevBtn = document.getElementById('sliderPrevBtn');
                const dotsContainer = document.getElementById('sliderDots');

                slides.forEach((_, idx) => {
                    const dot = document.createElement('button');
                    dot.className = `w-4 h-4 rounded-full border-2 border-white/60 transition-all duration-300 ${idx === 0 ? 'bg-brand-red border-brand-red scale-110' : 'bg-transparent hover:bg-white/40'}`;
                    dot.addEventListener('click', () => {
                        goToSlide(idx);
                        resetInterval();
                    });
                    dotsContainer.appendChild(dot);
                });

                const updateDots = () => {
                    Array.from(dotsContainer.children).forEach((dot, idx) => {
                        dot.className = `w-4 h-4 rounded-full border-2 border-white/60 transition-all duration-300 ${idx === currentIndex ? 'bg-brand-red border-brand-red scale-110' : 'bg-transparent hover:bg-white/40'}`;
                    });
                };

                const goToSlide = (idx) => {
                    currentIndex = idx;
                    track.style.transform = `translateX(-${currentIndex * 100}%)`;
                    updateDots();
                };

                const nextSlide = () => {
                    currentIndex = (currentIndex === slides.length - 1) ? 0 : currentIndex + 1;
                    goToSlide(currentIndex);
                };

                nextBtn.addEventListener('click', () => { nextSlide(); resetInterval(); });
                prevBtn.addEventListener('click', () => {
                    currentIndex = (currentIndex === 0) ? slides.length - 1 : currentIndex - 1;
                    goToSlide(currentIndex);
                    resetInterval();
                });

                const startInterval = () => { slideInterval = setInterval(nextSlide, 6000); };
                const resetInterval = () => { clearInterval(slideInterval); startInterval(); };

                startInterval();
            });
        </script>
    <?php endif; ?>

    <!-- WRAPPER UNICO PER SFONDO BIANCO E PATTERN -->
    <div class="relative bg-white bg-[radial-gradient(#e5e7eb_1px,transparent_1px)] [background-size:20px_20px] hero-highlight group/hero">
        <!-- Hero Highlight Layer (Interactive) -->
        <div class="absolute inset-0 z-0 bg-[radial-gradient(#1877F2_1.5px,transparent_1.5px)] [background-size:20px_20px] pointer-events-none opacity-0 group-hover/hero:opacity-15 transition-opacity duration-500"
             style="mask-image: radial-gradient(300px circle at var(--mouse-x, 0px) var(--mouse-y, 0px), black 0%, transparent 100%); -webkit-mask-image: radial-gradient(300px circle at var(--mouse-x, 0px) var(--mouse-y, 0px), black 0%, transparent 100%);">
        </div>
        <!-- Decorazioni Sfondo Vettoriale Globali -->
        <!-- Text Intro: FONDAZIONE DEMIAP (Inizio) -->
        <section class="py-16 relative z-10" id="fondazione">
            <div class="container mx-auto px-6 md:px-12 max-w-4xl bg-white/70 backdrop-blur-sm p-8 md:p-12 rounded-2xl border border-white/50 shadow-sm relative z-10">
                <h2
                    class="font-serif text-3xl md:text-4xl font-bold text-brand-deepblue mb-6 md:mb-8 uppercase tracking-wide text-left magic-title">
                    Fondazione DEMIAP</h2>
                <p class="text-gray-700 text-base md:text-lg leading-relaxed mb-8 text-left">
                    La Fondazione DEMIAP è un ente senza fini di lucro, riconosciuto ufficialmente per la sua utilità
                    pubblica. Il nome DEMIAP racchiude i nostri valori fondamentali: Divulgazione dell’Evangelo, Momenti
                    d’Incontro e Aiuto a Persone. Questi principi costituiscono la bussola che orienta ogni nostra
                    iniziativa e progetto. Ogni attività che proponiamo e realizziamo riflette, in misura diversa, tali
                    scopi, con l’obiettivo di generare un impatto positivo e concreto nella vita delle persone e della
                    comunità.
                </p>
            </div>
        </section>

        <!-- La nostra Fondazione (Services): I TRE PILASTRI -->
        <section class="py-12 flex-1 relative z-10">
            <div class="container mx-auto px-6 md:px-12 text-center">
                <div class="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto relative z-10">

                <?php 
                $services = get_option('ticinoweb_services');
                if (!empty($services) && is_array($services)): 
                    foreach ($services as $service): 
                        // Usa l'immagine caricata dal CMS, o un fallback
                        $img_src = !empty($service['image']) ? $service['image'] : get_stylesheet_directory_uri() . '/assets/media/evangelo.jpg';
                ?>
                <div class="flex flex-col group shadow-lg border border-gray-100">
                    <div class="h-64 overflow-hidden">
                        <img alt="<?php echo esc_attr($service['title']); ?>"
                            class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                            src="<?php echo esc_url($img_src); ?>" loading="lazy" />
                    </div>
                    <div class="bg-gray-50 p-10 flex-1 flex flex-col items-start text-left border-t-4 border-brand-deepblue">
                        <h3 class="font-serif text-lg md:text-xl tracking-widest uppercase mb-3 md:mb-4 text-brand-deepblue">
                            <?php echo esc_html($service['title']); ?></h3>
                        <div class="w-8 h-px bg-brand-red mb-6"></div>
                        <div class="text-sm md:text-base leading-relaxed text-gray-700 mb-8 flex-1 space-y-4">
                            <?php echo wpautop(wp_kses_post($service['description'])); ?>
                        </div>
                    </div>
                </div>
                <?php 
                    endforeach; 
                else:
                ?>
                    <p class="col-span-1 md:col-span-3 text-center text-gray-500 py-8">Nessun servizio configurato. Aggiungili dal pannello "ticinoWEB CMS" -> "Servizi Principali".</p>
                <?php endif; ?>

            </div>

            <p class="text-gray-700 max-w-4xl mx-auto mt-12 text-xs sm:text-sm md:text-base leading-relaxed">
                Vi invitiamo a esplorare le pagine successive per scoprire come, attraverso le nostre azioni concrete,
                mettiamo in pratica questi ideali e offriamo opportunità di crescita e sostegno a chi ne ha bisogno.
                Troverete informazioni sull’agenda delle attività, sulle iniziative di incontro e sulle modalità con cui
                la Fondazione DEMIAP si impegna ogni giorno a essere una presenza positiva e costruttiva sul territorio.
            </p>
        </div>
        </section>
        
        <!-- La sfumatura verso il bianco è stata rimossa, lasciamo scendere i puntini normalmente -->
    </div>

    <!-- ========================================== -->
    <!-- SFUMATURA PURA (Clean Gradient Fade)       -->
    <!-- ========================================== -->
    <div class="relative w-full h-[300px] md:h-[400px] bg-gradient-to-b from-white to-brand-deepblue -mt-[1px] z-20 hero-highlight group/hero">
        <!-- Hero Highlight Layer (Interactive) per la sfumatura -->
        <div class="absolute inset-0 z-0 bg-[radial-gradient(#ffffff_1.5px,transparent_1.5px)] [background-size:20px_20px] pointer-events-none opacity-0 group-hover/hero:opacity-15 transition-opacity duration-500"
             style="mask-image: radial-gradient(300px circle at var(--mouse-x, 0px) var(--mouse-y, 0px), black 0%, transparent 100%); -webkit-mask-image: radial-gradient(300px circle at var(--mouse-x, 0px) var(--mouse-y, 0px), black 0%, transparent 100%);">
        </div>
        <!-- Overlay del pattern a puntini che sfuma dolcemente nel blu -->
        <div class="absolute top-0 left-0 w-full h-full pointer-events-none bg-[radial-gradient(#e5e7eb_1px,transparent_1px)] [background-size:20px_20px] [mask-image:linear-gradient(to_bottom,white_0%,transparent_90%)]"></div>
        
        <!-- Overlay del pattern a puntini BIANCHI che appare dal basso per fondersi con la sezione successiva -->
        <div class="absolute top-0 left-0 w-full h-full pointer-events-none bg-[radial-gradient(#ffffff15_1px,transparent_1px)] [background-size:20px_20px] [mask-image:linear-gradient(to_top,white_0%,transparent_50%)]"></div>
    </div>

    <!-- Ciao Section (Riadattata per video/Missione) -->
    <section class="relative w-full py-24 bg-brand-deepblue bg-[radial-gradient(#ffffff15_1px,transparent_1px)] [background-size:20px_20px] -mt-[1px] hero-highlight group/hero">
        <!-- Hero Highlight Layer (Interactive) -->
        <div class="absolute inset-0 z-0 bg-[radial-gradient(#ffffff_1.5px,transparent_1.5px)] [background-size:20px_20px] pointer-events-none opacity-0 group-hover/hero:opacity-20 transition-opacity duration-500"
             style="mask-image: radial-gradient(300px circle at var(--mouse-x, 0px) var(--mouse-y, 0px), black 0%, transparent 100%); -webkit-mask-image: radial-gradient(300px circle at var(--mouse-x, 0px) var(--mouse-y, 0px), black 0%, transparent 100%);">
        </div>
        <!-- Decorazioni Sfondo Vettoriale -->
        <div class="relative z-10 container mx-auto px-6 md:px-12 flex flex-col items-center">
            <!-- Glassmorphism Container per estrema leggibilità -->
            <div
                class="bg-brand-deepblue/40 backdrop-blur-lg border border-white/20 p-8 md:p-16 rounded-3xl shadow-2xl max-w-5xl flex flex-col items-center">

                <!-- Video Placeholder -->
                <div
                    class="w-full max-w-4xl aspect-video bg-black/60 border border-white/20 rounded-2xl mb-12 flex flex-col items-center justify-center relative shadow-2xl overflow-hidden group">
                    <div
                        class="w-20 h-20 bg-brand-red rounded-full flex items-center justify-center z-10 group-hover:scale-110 transition-transform cursor-pointer shadow-[0_0_20px_rgba(231,54,59,0.5)]">
                        <span class="material-symbols-outlined text-white text-4xl">play_arrow</span>
                    </div>
                    <span
                        class="text-white/70 text-sm mt-6 z-10 font-bold tracking-widest uppercase bg-black/50 px-4 py-1 rounded-full">[
                        Vano Placeholder per il Futuro Video ]</span>
                </div>
                <h2
                    class="font-serif text-2xl md:text-4xl lg:text-5xl font-bold mb-6 md:mb-8 uppercase tracking-wide text-white drop-shadow-md magic-title">
                    L'altro modo di essere Chiesa</h2>

                <div
                    class="text-xs sm:text-sm md:text-base leading-relaxed font-light space-y-4 md:space-y-6 text-white text-left mx-auto drop-shadow-sm">
                    <p class="text-white">La divulgazione dell’Evangelo è basata sulla vita e l’opera di Gesù Cristo che
                        desideriamo trasmettere attraverso la quotidianità e la genuinità. Nel 2000 abbiamo costituito
                        la Chiesa Ticino. Proprio per il fatto che ci si voleva differenziare dai classici modi di
                        vivere la chiesa, ci siamo dati il seguente motto: <strong>CHIESA TICINO, L’ALTRO MODO DI ESSERE
                            CHIESA.</strong></p>
                    <p class="text-white">Dopo anni di esperienza possiamo affermare che la Chiesa Ticino non è un luogo
                        dove andare, bensì un modo di essere.</p>
                    <p class="text-white">Per tutto ciò che invece è e che fa classicamente una chiesa, ci appoggiamo a
                        varie realtà presenti nel territorio.</p>
                    <p class="text-white">I momenti di incontro sono il fulcro della nostra attività, in quanto è
                        proprio in quei momenti che si può esprimere ciò che abita in noi. Il contatto diretto con le
                        persone, in vari modi e in varie occasioni, è un’opportunità per tutti di esporsi senza rete.
                        Crediamo che non siano le grandi teorie a cambiare il mondo, ma le sane e genuine relazioni.</p>
                    <p class="text-white">L’aiuto a persone è lo scopo ultimo di tutto ciò. È vero che abbiamo
                        organizzato dei programmi di aiuto a persone bisognose, ma crediamo che portare dei sani
                        principi all’interno di sane relazioni, possa giovare a tutti, dandoci reciprocamente
                        l’opportunità di renderci persone migliori.</p>
                </div>
            </div>
        </div>
        
        <!-- Sfumatura inferiore per far svanire i puntini prima della sezione successiva -->
        <div class="absolute bottom-0 left-0 w-full h-48 bg-gradient-to-b from-transparent to-brand-deepblue pointer-events-none z-20"></div>
    </section>


    <!-- Call to Action Section (DONAZIONI) -->
    <section class="relative py-32 flex items-center justify-center text-center bg-brand-deepblue" id="donazioni">
        <div class="absolute inset-0 z-0 pointer-events-none">
            <!-- Background Immagine che entra con un morbido fade-in -->
            <img alt="Grayscale portrait" class="w-full h-full object-cover grayscale [mask-image:linear-gradient(to_bottom,transparent_0%,black_40%,black_100%)]"
                src="<?php echo esc_url(get_stylesheet_directory_uri() . '/assets/media/sostienici-banner.png'); ?>" loading="lazy" />
            <div class="absolute inset-0 bg-brand-deepblue/95"></div>
        </div>
        <div class="relative z-10 px-6 max-w-4xl mx-auto flex flex-col items-center">
            <h2
                class="font-serif text-2xl md:text-5xl text-white font-bold mb-6 md:mb-8 uppercase tracking-wide drop-shadow-lg text-center magic-title">
                Sostieni la Fondazione
            </h2>

            <!-- Il testo donazioni con card ad alto contrasto -->
            <div class="sostienici-card bg-[#0b1d36]/85 backdrop-blur-md border border-white/20 p-8 md:p-12 rounded-2xl shadow-2xl text-white text-base md:text-lg leading-relaxed mb-10 font-normal max-w-4xl space-y-5 text-left md:text-center mx-auto"
                style="color: #ffffff !important; background-color: rgba(11, 29, 54, 0.88) !important;">
                <p class="text-white text-base md:text-lg leading-relaxed" style="color: #ffffff !important;">La fondazione DEMIAP svolge la sua attività grazie al sostegno di volontari e alle donazioni.
                    Trattandosi di una Fondazione riconosciuta per la pubblica utilità, ogni offerta può essere dedotta
                    dalle imposte.</p>
                <p class="text-white text-base md:text-lg leading-relaxed" style="color: #ffffff !important;">Le attività operative che agiscono direttamente sul territorio le abbiamo riunite nella <strong
                        class="text-white font-extrabold" style="color: #ffffff !important;">Missione Operativa Svizzera Italiana (MOSI)</strong>. Si tratta di attività
                    che contemplano sempre un aspetto di preghiera. Per questo nei vostri versamenti vi saremmo grati se
                    indicaste <span class="inline-block bg-brand-red text-white font-extrabold px-2.5 py-0.5 rounded shadow-sm tracking-wide" style="background-color: #E7363B !important; color: #ffffff !important;">SOSTEGNO MOSI</span> come motivo del
                    versamento.</p>
                <p class="text-white text-base md:text-lg leading-relaxed" style="color: #ffffff !important;">Si può donare il proprio tempo partecipando in modo concreto alle nostre attività. In questo caso <a
                        href="#contatti" class="inline-flex items-center text-white font-extrabold underline decoration-2 decoration-brand-red underline-offset-4 hover:bg-white/20 px-2 py-0.5 rounded transition-all" style="color: #ffffff !important;">contattaci &rarr;</a> attraverso i
                    nostri recapiti.</p>
                <p class="text-white text-base md:text-lg leading-relaxed" style="color: #ffffff !important;">Si può evidentemente sostenere la nostra Fondazione anche con contributi finanziari. Per questo si
                    può utilizzare l’IBAN o il codice QR che trovate sotto.</p>

                <!-- Link Video ad alto contrasto: pulsanti bianchi con testo scuro e icona rossa -->
                <div class="flex flex-col md:flex-row gap-4 justify-center py-6 border-y border-white/20 my-6">
                    <a href="#"
                        class="sostienici-btn group flex items-center justify-center gap-2.5 bg-white hover:bg-brand-red text-brand-deepblue hover:text-white border-2 border-white hover:border-brand-red px-6 py-3.5 rounded-lg transition-all text-sm md:text-base font-extrabold shadow-lg"
                        style="background-color: #ffffff !important; color: #193256 !important;">
                        <span
                            class="material-symbols-outlined text-brand-red group-hover:text-white transition-colors text-xl" style="color: #E7363B !important;">play_circle</span>
                        <span>Fr. 1.- al giorno (MOSI)</span>
                    </a>
                    <a href="#"
                        class="sostienici-btn group flex items-center justify-center gap-2.5 bg-white hover:bg-brand-red text-brand-deepblue hover:text-white border-2 border-white hover:border-brand-red px-6 py-3.5 rounded-lg transition-all text-sm md:text-base font-extrabold shadow-lg"
                        style="background-color: #ffffff !important; color: #193256 !important;">
                        <span
                            class="material-symbols-outlined text-brand-red group-hover:text-white transition-colors text-xl" style="color: #E7363B !important;">play_circle</span>
                        <span>Versare la tua decima</span>
                    </a>
                    <a href="#"
                        class="sostienici-btn group flex items-center justify-center gap-2.5 bg-white hover:bg-brand-red text-brand-deepblue hover:text-white border-2 border-white hover:border-brand-red px-6 py-3.5 rounded-lg transition-all text-sm md:text-base font-extrabold shadow-lg"
                        style="background-color: #ffffff !important; color: #193256 !important;">
                        <span
                            class="material-symbols-outlined text-brand-red group-hover:text-white transition-colors text-xl" style="color: #E7363B !important;">play_circle</span>
                        <span>Lasciti o eredità</span>
                    </a>
                </div>

                <p class="text-white text-base md:text-lg leading-relaxed" style="color: #ffffff !important;">Un altro modo per sostenere la Fondazione DEMIAP è l’offerta di servizi. Dovendo viaggiare spesso al
                    nord delle Alpi, ben vengano buoni vari come per: spostamenti in treno o auto, pasti, pernottamenti,
                    sconti vari, buoni Reka e altro ancora.</p>
                <p class="text-white text-base md:text-lg leading-relaxed" style="color: #ffffff !important;">Siamo certamente aperti anche a sponsorizzazioni che non siano lesive dell’etica cristiana.</p>
            </div>

            <!-- Box IBAN / QR -->
            <div
                class="bg-white text-brand-deepblue p-8 rounded-sm shadow-2xl w-full max-w-2xl mx-auto flex flex-col md:flex-row items-center justify-between gap-8 mt-4 border-b-4 border-brand-red transform hover:scale-[1.02] transition-transform">
                <div class="flex-1 text-left">
                    <h4 class="font-bold text-lg mb-2 uppercase tracking-widest text-brand-red">Coordinate Bancarie</h4>
                    <p class="text-sm font-bold mb-1">Fondazione DEMIAP</p>
                    <div
                        class="bg-gray-100 p-3 mt-4 rounded-sm text-sm font-mono tracking-wider border border-gray-200 break-all">
                        [ INSERIRE IBAN DELLA FONDAZIONE ]
                    </div>
                </div>
                <div
                    class="w-32 h-32 bg-gray-100 border border-gray-300 flex flex-col items-center justify-center text-xs text-gray-400 p-2 text-center rounded-sm">
                    <span class="material-symbols-outlined text-4xl mb-1">qr_code_2</span>
                    [ IMMAGINE QR ]
                </div>
            </div>
    </section>

<?php get_footer(); ?>