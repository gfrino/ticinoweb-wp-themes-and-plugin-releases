<?php
/** Editorial blocks stay in WordPress; legal notes close the page after the footer. */
if (!defined('ABSPATH')) { exit; }
get_header();
$privacy_content = '';
?>
<main id="main" class="site-main" tabindex="-1"><?php
while (have_posts()) :
    the_post();
    $main_blocks = array();
    foreach (parse_blocks(get_the_content()) as $block) {
        $classes = preg_split('/\s+/', trim($block['attrs']['className'] ?? ''));
        if ($block['blockName'] === 'core/group' && in_array('privacy-section', $classes, true)) {
            $privacy_content .= serialize_block($block);
        } else {
            $main_blocks[] = $block;
        }
    }
    echo apply_filters('the_content', serialize_blocks($main_blocks));
endwhile;
?></main>
<?php get_footer(null, array('privacy_content' => $privacy_content));
