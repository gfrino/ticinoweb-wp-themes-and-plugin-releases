<?php
/** Ephemeral decorative opening. It never changes content, navigation or consent. */
if (!defined('ABSPATH')) { exit; }
add_action('wp_head', static function () {
    if (!is_front_page()) { return; }
    $directory = get_stylesheet_directory();
    // Fixed child-owned assets only. Critical styles remain independent of the main bundle.
    $css = file_get_contents($directory . '/assets/css/intro.css');
    $js = file_get_contents($directory . '/assets/js/intro.js');
    if ($css === false || $js === false) { return; }
    echo '<style id="pons-intro-css">' . $css . '</style><script id="pons-intro-js">' . $js . '</script>';
}, 1);
add_action('wp_body_open', static function () {
    if (!is_front_page()) { return; }
    echo '<div class="solar-intro" aria-hidden="true"><div class="intro-veil"></div><div class="intro-sun"><svg data-intro-sun viewBox="0 0 200 200" fill="none" focusable="false">';
    for ($index = 0; $index < 24; $index++) {
        $a = deg2rad($index * 15 - 90);
        $b = $a + deg2rad(9);
        $points = array();
        foreach (array(array(100, $a), array(100, $b), array(42, $b), array(42, $a)) as $point) {
            $points[] = number_format(100 + cos($point[1]) * $point[0], 3, '.', '') . ',' . number_format(100 + sin($point[1]) * $point[0], 3, '.', '');
        }
        echo '<polygon class="intro-ray" style="--ray:' . esc_attr((string) $index) . '" points="' . esc_attr(implode(' ', $points)) . '"/>';
    }
    echo '<circle class="intro-core" cx="100" cy="100" r="31"/></svg></div>';
    $name = preg_split('/\s+/', trim(get_bloginfo('name')), 2);
    echo '<p class="intro-brand"><span class="intro-brand-main">' . esc_html($name[0] ?? '') . '</span>';
    if (!empty($name[1])) { echo '<span class="intro-brand-detail">' . esc_html($name[1]) . '</span>'; }
    echo '</p></div>';
});
