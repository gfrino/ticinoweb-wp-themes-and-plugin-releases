<?php
/** Native page associations and a gallery selector over the parent's CMS. */
if (!defined('ABSPATH')) { exit; }

function pons_editor_page_roles() {
    $roles = array(
        'servizi' => __('Servizi', 'ponsenergiasolare'),
        'chi-siamo' => __('Chi siamo', 'ponsenergiasolare'),
        'incentivi' => __('Incentivi', 'ponsenergiasolare'),
        'referenze' => __('Referenze', 'ponsenergiasolare'),
        'preventivo' => __('Preventivo', 'ponsenergiasolare'),
        'contatti' => __('Contatti', 'ponsenergiasolare'),
        'privacy' => __('Privacy', 'ponsenergiasolare'),
        'note-legali' => __('Note legali', 'ponsenergiasolare'),
    );
    // Retain existing service-specific roles without storing another list of services.
    $pages = get_posts(array('post_type' => 'page', 'post_status' => array('publish', 'draft', 'pending', 'private', 'future'), 'posts_per_page' => -1, 'meta_key' => '_pons_page_role', 'suppress_filters' => true));
    foreach ($pages as $page) {
        $role = (string) get_post_meta($page->ID, '_pons_page_role', true);
        if (strpos($role, 'service-') === 0 && sanitize_key($role) === $role) {
            $roles[$role] = sprintf(__('Pagina servizio: %s', 'ponsenergiasolare'), get_the_title($page));
        }
    }
    return $roles;
}

add_action('after_setup_theme', static function () {
    add_post_type_support('page', 'excerpt');
});

add_action('add_meta_boxes_page', static function () {
    add_meta_box('pons-page-settings', __('Contenuti della pagina Pons', 'ponsenergiasolare'), 'pons_editor_page_box', 'page', 'normal', 'high');
});

function pons_editor_page_box($post) {
    wp_nonce_field('pons_page_associations', 'pons_page_associations_nonce');
    $role = get_post_meta($post->ID, '_pons_page_role', true);
    $service_id = get_post_meta($post->ID, '_pons_service_id', true);
    $assigned = array('_pons_page_role' => array(), '_pons_service_id' => array());
    $other_pages = get_posts(array(
        'post_type' => 'page', 'post_status' => array('publish', 'draft', 'pending', 'private', 'future'),
        'posts_per_page' => -1, 'post__not_in' => array($post->ID), 'suppress_filters' => true,
        'meta_query' => array('relation' => 'OR', array('key' => '_pons_page_role', 'compare' => 'EXISTS'), array('key' => '_pons_service_id', 'compare' => 'EXISTS')),
    ));
    foreach ($other_pages as $page) {
        foreach (array_keys($assigned) as $key) {
            $value = (string) get_post_meta($page->ID, $key, true);
            if ($value !== '') { $assigned[$key][$value] = get_the_title($page) ?: __('Pagina senza titolo', 'ponsenergiasolare'); }
        }
    }
    ?>
    <p><label for="pons-page-role"><strong><?php esc_html_e('Funzione della pagina', 'ponsenergiasolare'); ?></strong></label></p>
    <select id="pons-page-role" name="pons_page_role">
        <option value=""><?php esc_html_e('Pagina libera', 'ponsenergiasolare'); ?></option>
        <?php foreach (pons_editor_page_roles() as $value => $label) : ?>
            <option value="<?php echo esc_attr($value); ?>" <?php selected($role, $value); ?> <?php disabled(isset($assigned['_pons_page_role'][$value]) && $role !== $value); ?>><?php echo esc_html(isset($assigned['_pons_page_role'][$value]) ? sprintf(__('%1$s — già collegato a %2$s', 'ponsenergiasolare'), $label, $assigned['_pons_page_role'][$value]) : $label); ?></option>
        <?php endforeach; ?>
    </select>
    <p class="description"><?php esc_html_e('Ogni funzione può appartenere a una sola pagina. Le associazioni Servizi, Chi siamo e Contatti del CMS hanno la precedenza: modificale nel CMS quando cambi pagina.', 'ponsenergiasolare'); ?></p>
    <p><label for="pons-service-id"><strong><?php esc_html_e('Servizio collegato', 'ponsenergiasolare'); ?></strong></label></p>
    <select id="pons-service-id" name="pons_service_id">
        <option value=""><?php esc_html_e('Nessun servizio', 'ponsenergiasolare'); ?></option>
        <?php foreach (ticinoweb_get_services() as $service) : ?>
            <?php if (empty($service['id'])) { continue; } ?>
            <option value="<?php echo esc_attr($service['id']); ?>" <?php selected($service_id, $service['id']); ?> <?php disabled(isset($assigned['_pons_service_id'][$service['id']]) && $service_id !== (string) $service['id']); ?>><?php $label = !empty($service['title']) ? $service['title'] : __('Servizio senza titolo', 'ponsenergiasolare'); echo esc_html(isset($assigned['_pons_service_id'][$service['id']]) ? sprintf(__('%1$s — già collegato a %2$s', 'ponsenergiasolare'), $label, $assigned['_pons_service_id'][$service['id']]) : $label); ?></option>
        <?php endforeach; ?>
    </select>
    <p class="description"><?php esc_html_e('Collega una pagina di dettaglio al servizio già presente nel CMS. Titolo, descrizione e immagine del servizio si modificano una sola volta nel CMS.', 'ponsenergiasolare'); ?></p>
    <p><a href="<?php echo esc_url(admin_url('admin.php?page=ticinoweb-cms#services')); ?>"><?php esc_html_e('Apri servizi e contenuti nel CMS', 'ponsenergiasolare'); ?></a> · <a href="<?php echo esc_url(admin_url('admin.php?page=ticinoweb-cms#mappatura')); ?>"><?php esc_html_e('Apri associazioni delle pagine', 'ponsenergiasolare'); ?></a></p>
    <p><?php esc_html_e('Scrivi i testi nell’editor della pagina. Usa il riassunto per l’introduzione. La copertina usa l’immagine in evidenza; nelle pagine servizio ha precedenza l’immagine del servizio nel CMS e quella in evidenza viene usata solo se manca. Trovi entrambi nelle impostazioni della pagina; se nascosti, attivali nelle preferenze dell’editor.', 'ponsenergiasolare'); ?></p>
    <p><?php esc_html_e('Per le realizzazioni inserisci il blocco “Referenze Pons” e scegli la galleria per nome. Foto, didascalie e ordine restano nella Libreria Media e in Gestisci Gallerie.', 'ponsenergiasolare'); ?></p>
    <?php
}

function pons_editor_association_error($code) {
    add_filter('redirect_post_location', static function ($location) use ($code) {
        return add_query_arg('pons_association_error', $code, $location);
    });
}

add_action('save_post_page', static function ($post_id, $post) {
    if (wp_is_post_revision($post_id) || wp_is_post_autosave($post_id) || (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE)) { return; }
    if (!current_user_can('edit_post', $post_id) || !isset($_POST['pons_page_associations_nonce']) || !is_string($_POST['pons_page_associations_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['pons_page_associations_nonce'])), 'pons_page_associations')) { return; }
    if (!isset($_POST['pons_page_role'], $_POST['pons_service_id']) || !is_string($_POST['pons_page_role']) || !is_string($_POST['pons_service_id'])) { return; }
    $role = sanitize_key(wp_unslash($_POST['pons_page_role']));
    $service_id = sanitize_text_field(wp_unslash($_POST['pons_service_id']));
    $service_ids = array_map('strval', wp_list_pluck(ticinoweb_get_services(), 'id'));
    if (($role !== '' && !isset(pons_editor_page_roles()[$role])) || ($service_id !== '' && !in_array($service_id, $service_ids, true))) {
        pons_editor_association_error('invalid');
        return;
    }
    $mapping_keys = array('servizi' => 'page_servizi', 'chi-siamo' => 'page_chi_siamo', 'contatti' => 'page_contatti');
    if ($role && isset($mapping_keys[$role]) && function_exists('ticinoweb_get_mapped_page_id')) {
        $mapped = (int) ticinoweb_get_mapped_page_id($mapping_keys[$role]);
        if ($mapped && $mapped !== (int) $post_id && get_post_status($mapped) !== 'trash') {
            pons_editor_association_error('mapping');
            return;
        }
    }
    foreach (array('_pons_page_role' => $role, '_pons_service_id' => $service_id) as $key => $value) {
        if ($value === '') { continue; }
        $duplicates = get_posts(array(
            'post_type' => 'page', 'post_status' => array('publish', 'draft', 'pending', 'private', 'future'),
            'posts_per_page' => 1, 'fields' => 'ids', 'post__not_in' => array($post_id),
            'meta_key' => $key, 'meta_value' => $value, 'suppress_filters' => true,
        ));
        if ($duplicates) {
            pons_editor_association_error('duplicate');
            return;
        }
    }
    foreach (array('_pons_page_role' => $role, '_pons_service_id' => $service_id) as $key => $value) {
        if ($value === '') { delete_post_meta($post_id, $key); }
        else { update_post_meta($post_id, $key, $value); }
    }
}, 10, 2);

add_action('admin_notices', static function () {
    $screen = get_current_screen();
    if (!$screen || $screen->base !== 'post' || $screen->post_type !== 'page' || !current_user_can('edit_pages')) { return; }
    $code = isset($_GET['pons_association_error']) && is_string($_GET['pons_association_error']) ? sanitize_key(wp_unslash($_GET['pons_association_error'])) : '';
    $messages = array(
        'invalid' => __('La scelta non è più disponibile. Le associazioni precedenti sono state conservate: aggiorna la pagina e scegli di nuovo.', 'ponsenergiasolare'),
        'mapping' => __('Questa funzione è già assegnata a un’altra pagina nel CMS. Correggi prima la mappatura delle pagine nel CMS; le associazioni precedenti sono state conservate.', 'ponsenergiasolare'),
        'duplicate' => __('Funzione o servizio già collegati a un’altra pagina, anche in bozza. Rimuovi prima quel collegamento; le associazioni precedenti sono state conservate.', 'ponsenergiasolare'),
    );
    if (isset($messages[$code])) { echo '<div class="notice notice-warning"><p>' . esc_html($messages[$code]) . '</p></div>'; }
});

add_action('init', static function () {
    register_block_type('pons/references', array(
        'api_version' => 2,
        'attributes' => array('galleryId' => array('type' => 'integer', 'default' => 0)),
        'render_callback' => static function ($attributes) {
            $id = absint($attributes['galleryId'] ?? 0);
            if (!$id || !shortcode_exists('pons_references') || !term_exists($id, 'ticinoweb_media_gallery')) { return ''; }
            return '<div class="reference-gallery-block">' . do_shortcode('[pons_references gallery="' . $id . '"]') . '</div>';
        },
    ));
});

add_action('enqueue_block_editor_assets', static function () {
    if (!current_user_can('edit_pages')) { return; }
    $screen = get_current_screen();
    if (!$screen || $screen->post_type !== 'page') { return; }
    $path = '/assets/js/editor.js';
    wp_enqueue_script('pons-editor', get_stylesheet_directory_uri() . $path, array('wp-blocks', 'wp-element', 'wp-components', 'wp-block-editor', 'wp-server-side-render', 'wp-i18n'), (string) filemtime(get_stylesheet_directory() . $path), true);
    $terms = get_terms(array('taxonomy' => 'ticinoweb_media_gallery', 'hide_empty' => false));
    $galleries = array();
    if (!is_wp_error($terms)) {
        foreach ($terms as $term) { $galleries[] = array('value' => (int) $term->term_id, 'label' => $term->name); }
    }
    wp_localize_script('pons-editor', 'ponsEditor', array(
        'galleries' => $galleries,
        'galleryUrl' => current_user_can('manage_options') ? admin_url('upload.php?page=ticinoweb-media-galleries-manager') : admin_url('upload.php'),
    ));
    wp_set_script_translations('pons-editor', 'ponsenergiasolare', get_stylesheet_directory() . '/languages');
});
