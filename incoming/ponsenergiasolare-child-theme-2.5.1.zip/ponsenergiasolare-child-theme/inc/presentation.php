<?php
if (!defined('ABSPATH')) { exit; }

function pons_text($text, $context) {
    return function_exists('ticinoweb_frontend_text') ? ticinoweb_frontend_text($text, 'pons:' . $context) : $text;
}

function pons_home() {
    return function_exists('ticinoweb_frontend_url') ? ticinoweb_frontend_url(home_url('/'), 'theme:url:home') : home_url('/');
}

function pons_contacts() {
    return array(
        'phone' => (string) (get_option('ticinoweb_contact_phone_landline') ?: get_option('ticinoweb_contact_phone', '')),
        'mobile' => (string) get_option('ticinoweb_contact_phone_mobile', ''),
        'email' => (string) get_option('ticinoweb_contact_email', ''),
        'address' => pons_text((string) get_option('ticinoweb_contact_address', ''), 'address'),
    );
}

function pons_phone_url($phone) { return 'tel:' . preg_replace('/[^0-9+]/', '', $phone); }

add_shortcode('pons_privacy_identity', static function () {
    $contact = pons_contacts();
    $parts = array('<strong>' . esc_html(get_bloginfo('name')) . '</strong>');
    if ($contact['address']) { $parts[] = nl2br(esc_html($contact['address'])); }
    if ($contact['email']) { $parts[] = '<a href="mailto:' . esc_attr(antispambot($contact['email'])) . '">' . esc_html(antispambot($contact['email'])) . '</a>'; }
    if ($contact['phone']) { $parts[] = '<a href="' . esc_url(pons_phone_url($contact['phone'])) . '">' . esc_html($contact['phone']) . '</a>'; }
    return '<p>' . implode('<br>', $parts) . '</p>';
});

function pons_logo() {
    $url = ticinoweb_get_site_logo();
    if ($url) {
        $image_id = attachment_url_to_postid($url);
        if ($image_id) {
            echo wp_get_attachment_image($image_id, 'medium', false, array('class' => 'site-logo', 'alt' => get_bloginfo('name'), 'sizes' => '205px', 'loading' => 'eager', 'fetchpriority' => 'low', 'decoding' => 'async'));
        } else {
            echo '<img src="' . esc_url($url) . '" alt="' . esc_attr(get_bloginfo('name')) . '" width="1286" height="409" class="site-logo" decoding="async">';
        }
    } else { echo '<span class="site-name">' . esc_html(get_bloginfo('name')) . '</span>'; }
}

function pons_image($url, $class = '', $sizes = '100vw') {
    if (!$url) { return ''; }
    $id = attachment_url_to_postid($url);
    if ($id) { return wp_get_attachment_image($id, 'large', false, array('class' => $class, 'loading' => 'lazy', 'decoding' => 'async', 'sizes' => $sizes)); }
    return '<img class="' . esc_attr($class) . '" src="' . esc_url($url) . '" alt="" loading="lazy" decoding="async">';
}

/** Plain CMS paragraphs: first line is a heading when followed by a single newline. */
function pons_about_paragraph($paragraph) {
    $lines = preg_split('/\\n+/', trim($paragraph), 2);
    return array('title' => count($lines) > 1 ? $lines[0] : '', 'text' => count($lines) > 1 ? $lines[1] : ($lines[0] ?? ''));
}

add_shortcode('pons_about', static function () {
    $title = pons_text((string) get_option('ticinoweb_chi_siamo_title', ''), 'about-title');
    $text = pons_text((string) get_option('ticinoweb_chi_siamo_text', ''), 'about-text');
    if (!$title && !trim($text)) { return ''; }
    $paragraphs = preg_split('/\\n[ \t]*\\n+/', str_replace(array("\r\n", "\r"), "\n", trim($text)), -1, PREG_SPLIT_NO_EMPTY);
    $identity = pons_about_paragraph(array_shift($paragraphs) ?? '');
    $image = (string) get_option('ticinoweb_chi_siamo_image', '');
    ob_start(); ?>
    <div class="about-layout about-editorial" data-about-editorial>
        <div class="about-identity<?php echo $image ? ' has-photo' : ''; ?>">
            <div class="about-signature">
                <?php if ($image) : ?><div class="about-photo" aria-hidden="true"><?php echo pons_image($image, 'about-context-image', '(max-width:420px) calc(100vw - 44px), (max-width:700px) calc(100vw - 50px), (max-width:1500px) 40vw, 525px'); ?></div><?php endif; ?>
                <span class="about-brand"><?php echo esc_html(get_bloginfo('name')); ?></span>
                <span class="about-sun" aria-hidden="true"><span class="solar-disc"></span></span>
                <div class="about-identity-copy">
                    <?php if ($identity['title']) : ?><p class="about-identity-heading"><?php echo esc_html($identity['title']); ?></p><?php endif; ?>
                    <?php if ($identity['text']) : ?><p><?php echo nl2br(esc_html($identity['text'])); ?></p><?php endif; ?>
                </div>
            </div>
        </div>
        <div class="about-copy">
            <?php if ($title) : ?><h2><?php echo esc_html($title); ?></h2><?php endif; ?>
            <?php if ($paragraphs) : ?><div class="about-principles">
                <?php foreach ($paragraphs as $paragraph) : $part = pons_about_paragraph($paragraph); ?>
                    <div class="about-principle">
                        <?php if ($part['title']) : ?><h3><?php echo esc_html($part['title']); ?></h3><?php endif; ?>
                        <p><?php echo nl2br(esc_html($part['text'])); ?></p>
                    </div>
                <?php endforeach; ?>
            </div><?php endif; ?>
        </div>
    </div>
    <?php return ob_get_clean();
});

add_shortcode('pons_contact', static function () {
    $contact = pons_contacts();
    if (!array_filter($contact)) { return ''; }
    $channels = $contact['phone'] || $contact['email'];
    $details = $contact['mobile'] || $contact['address'];
    $map = 'https://www.google.com/maps/search/?api=1&query=' . rawurlencode(preg_replace('/\\s+/u', ' ', wp_strip_all_tags($contact['address'])));
    ob_start(); ?>
    <div class="contact-directory<?php echo (!$channels || !$details) ? ' contact-directory-single' : ''; ?>">
        <?php if ($channels) : ?><div class="contact-channels">
            <?php if ($contact['phone']) : ?><a class="contact-channel" href="<?php echo esc_url(pons_phone_url($contact['phone'])); ?>">
                <span class="contact-label"><?php echo esc_html(pons_text(__('Telefono', 'ponsenergiasolare'), 'contact-phone-label')); ?></span>
                <span class="contact-value"><?php echo esc_html($contact['phone']); ?></span><span class="contact-arrow" aria-hidden="true">↗</span>
            </a><?php endif; ?>
            <?php if ($contact['email']) : ?><a class="contact-channel contact-channel-email" href="mailto:<?php echo esc_attr(antispambot($contact['email'])); ?>">
                <span class="contact-label"><?php echo esc_html(pons_text(__('Email', 'ponsenergiasolare'), 'contact-email-label')); ?></span>
                <span class="contact-value"><?php echo esc_html(antispambot($contact['email'])); ?></span><span class="contact-arrow" aria-hidden="true">↗</span>
            </a><?php endif; ?>
        </div><?php endif; ?>
        <?php if ($details) : ?><div class="contact-details">
            <?php if ($contact['mobile']) : ?><div class="contact-detail">
                <span class="contact-label"><?php echo esc_html(pons_text(__('Cellulare', 'ponsenergiasolare'), 'mobile')); ?></span>
                <a class="contact-mobile" href="<?php echo esc_url(pons_phone_url($contact['mobile'])); ?>"><?php echo esc_html($contact['mobile']); ?></a>
            </div><?php endif; ?>
            <?php if ($contact['address']) : ?><div class="contact-detail">
                <span class="contact-label"><?php echo esc_html(pons_text(__('Indirizzo', 'ponsenergiasolare'), 'contact-address-label')); ?></span>
                <address><?php echo nl2br(esc_html($contact['address'])); ?></address>
                <a class="contact-map" href="<?php echo esc_url($map); ?>"><?php echo esc_html(pons_text(__('Apri la mappa', 'ponsenergiasolare'), 'contact-map-label')); ?><span aria-hidden="true">↗</span></a>
            </div><?php endif; ?>
        </div><?php endif; ?>
    </div>
    <?php return ob_get_clean();
});
