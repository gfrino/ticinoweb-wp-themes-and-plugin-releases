<?php
/** Footer presentation: canonical CMS services and native WordPress navigation. */
if (!defined('ABSPATH')) { exit; }

add_action('after_setup_theme', static function () {
    register_nav_menus(array(
        'footer_services' => __('Servizi nel footer (automatici senza menu)', 'ponsenergiasolare'),
        'footer_legal' => __('Informazioni legali nel footer', 'ponsenergiasolare'),
    ));
});

function pons_footer_service_items() {
    $items = '';
    $current = get_post_meta(get_queried_object_id(), '_pons_service_id', true);
    foreach (ticinoweb_get_services() as $service) {
        $id = (string) ($service['id'] ?? '');
        $url = pons_service_page_url($id);
        if (!$url || empty($service['title'])) { continue; }
        $active = $id !== '' && $current === $id;
        $items .= '<li' . ($active ? ' class="current-menu-item"' : '') . '><a href="' . esc_url($url) . '"' . ($active ? ' aria-current="page"' : '') . '>' . esc_html($service['title']) . '</a></li>';
    }
    return $items;
}

/** wp_nav_menu fallback: keep service order/names in the existing parent CMS. */
function pons_footer_services_fallback($args) {
    $items = pons_footer_service_items();
    $html = $items ? '<ul class="footer-services-menu">' . $items . '</ul>' : '';
    if (!empty($args['echo'])) { echo $html; return; }
    return $html;
}

/** Legal links stay available if an administrator unassigns the custom legal menu. */
function pons_footer_legal_fallback($args) {
    $items = '';
    $privacy = get_privacy_policy_url() ?: get_option('tw_privacy_policy_url', '');
    if ($privacy) {
        $privacy = ticinoweb_frontend_url($privacy, 'theme:url:privacy');
        $label = pons_page_id('privacy') ? get_the_title(pons_page_id('privacy')) : __('Privacy', 'ponsenergiasolare');
        $items .= '<li><a href="' . esc_url($privacy) . '">' . esc_html($label) . '</a></li>';
    }
    if ($url = pons_page_url('note-legali')) {
        $items .= '<li><a href="' . esc_url($url) . '">' . esc_html(get_the_title(pons_page_id('note-legali'))) . '</a></li>';
    }
    $html = $items ? '<ul class="footer-legal-menu">' . $items . '</ul>' : '';
    if (!empty($args['echo'])) { echo $html; return; }
    return $html;
}
