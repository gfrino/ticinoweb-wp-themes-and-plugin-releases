<?php
/** Pons quote presentation; the parent owns validation nonce, rate limit, storage and mail. */
if (!defined('ABSPATH')) { exit; }

function pons_quote_label($text, $key) {
    return pons_text($text, 'quote-' . $key);
}

function pons_quote_choices() {
    return array(
        'property_type' => array('house' => pons_quote_label(__('Casa unifamiliare', 'ponsenergiasolare'), 'house'), 'apartment' => pons_quote_label(__('Condominio', 'ponsenergiasolare'), 'apartment'), 'business' => pons_quote_label(__('Edificio aziendale', 'ponsenergiasolare'), 'business'), 'other' => pons_quote_label(__('Altro / da valutare', 'ponsenergiasolare'), 'other')),
        'roof_type' => array('pitched' => pons_quote_label(__('Tetto a falde', 'ponsenergiasolare'), 'pitched'), 'flat' => pons_quote_label(__('Tetto piano', 'ponsenergiasolare'), 'flat'), 'unknown' => pons_quote_label(__('Non lo so ancora', 'ponsenergiasolare'), 'unknown')),
        'battery' => array('unsure' => pons_quote_label(__('Da valutare insieme', 'ponsenergiasolare'), 'unsure'), 'yes' => pons_quote_label(__('Sì', 'ponsenergiasolare'), 'yes'), 'no' => pons_quote_label(__('No', 'ponsenergiasolare'), 'no')),
        'ev' => array('unsure' => pons_quote_label(__('Da valutare insieme', 'ponsenergiasolare'), 'unsure'), 'yes' => pons_quote_label(__('Sì', 'ponsenergiasolare'), 'yes'), 'no' => pons_quote_label(__('No', 'ponsenergiasolare'), 'no')),
    );
}

function pons_quote_value($post, $key) {
    return isset($post[$key]) && is_scalar($post[$key]) ? sanitize_text_field(wp_unslash((string) $post[$key])) : '';
}

/** Protect the native scalar sanitizers before they receive malformed array values. */
function pons_quote_preflight() {
    if (pons_quote_value($_POST, 'pons_quote') !== '1') { return; }
    foreach (array('nome', 'email', 'telefono', 'messaggio', 'oggetto', 'token', 'recaptcha_token') as $key) {
        if (isset($_POST[$key]) && !is_string($_POST[$key])) {
            wp_send_json_error(array('message' => pons_quote_label(__('Controlla i campi indicati.', 'ponsenergiasolare'), 'check')), 422);
        }
    }
}
add_action('wp_ajax_ticinoweb_submit_form', 'pons_quote_preflight', 1);
add_action('wp_ajax_nopriv_ticinoweb_submit_form', 'pons_quote_preflight', 1);

function pons_quote_fields($fields, $post) {
    if (pons_quote_value($post, 'pons_quote') !== '1') { return $fields; }
    $choices = pons_quote_choices();
    $lines = array(pons_quote_label(__('Richiesta di valutazione fotovoltaica', 'ponsenergiasolare'), 'subject'));
    $labels = array('property_type' => pons_quote_label(__('Immobile', 'ponsenergiasolare'), 'property'), 'roof_type' => pons_quote_label(__('Tetto', 'ponsenergiasolare'), 'roof'), 'battery' => pons_quote_label(__('Accumulo', 'ponsenergiasolare'), 'battery'), 'ev' => pons_quote_label(__('Ricarica auto elettrica', 'ponsenergiasolare'), 'ev'));
    foreach ($choices as $key => $values) {
        $value = pons_quote_value($post, $key);
        $lines[] = $labels[$key] . ': ' . ($values[$value] ?? '');
    }
    $lines[] = pons_quote_label(__('Località / NPA', 'ponsenergiasolare'), 'locality') . ': ' . pons_quote_value($post, 'locality');
    $consumption = pons_quote_value($post, 'annual_consumption');
    $lines[] = pons_quote_label(__('Consumo annuo indicativo', 'ponsenergiasolare'), 'consumption') . ': ' . ($consumption !== '' ? $consumption . ' kWh' : pons_quote_label(__('Non noto', 'ponsenergiasolare'), 'consumption-unknown'));
    $lines[] = pons_quote_label(__('Informativa privacy letta', 'ponsenergiasolare'), 'privacy-record') . ': ' . (pons_quote_value($post, 'privacy') === '1' ? pons_quote_label(__('Sì', 'ponsenergiasolare'), 'yes') : pons_quote_label(__('No', 'ponsenergiasolare'), 'no'));
    $lines[] = '';
    // Keep free text separate from the generated summary; validate its original length below.
    $lines[] = isset($post['messaggio']) && is_string($post['messaggio']) ? sanitize_textarea_field(wp_unslash($post['messaggio'])) : '';
    $fields['messaggio'] = implode("\n", $lines);
    $fields['oggetto'] = pons_quote_label(__('Richiesta di valutazione fotovoltaica', 'ponsenergiasolare'), 'subject');
    return $fields;
}
add_filter('ticinoweb_form_fields', 'pons_quote_fields', 10, 2);

function pons_quote_errors($errors, $fields, $post) {
    if (pons_quote_value($post, 'pons_quote') !== '1') { return $errors; }
    $invalid = pons_quote_label(__('Scegli una delle opzioni disponibili.', 'ponsenergiasolare'), 'invalid-choice');
    foreach (pons_quote_choices() as $key => $values) {
        if (!array_key_exists(pons_quote_value($post, $key), $values)) { $errors[$key] = $invalid; }
    }
    $locality = pons_quote_value($post, 'locality');
    if (mb_strlen($locality) < 2 || mb_strlen($locality) > 150) { $errors['locality'] = pons_quote_label(__('Inserisci la località o il NPA (massimo 150 caratteri).', 'ponsenergiasolare'), 'invalid-locality'); }
    $consumption = pons_quote_value($post, 'annual_consumption');
    if ((isset($post['annual_consumption']) && !is_scalar($post['annual_consumption'])) || ($consumption !== '' && (!preg_match('/^[0-9]{1,7}$/D', $consumption) || (int) $consumption < 1 || (int) $consumption > 1000000))) {
        $errors['annual_consumption'] = pons_quote_label(__('Inserisci un consumo da 1 a 1 000 000 kWh, oppure lascia vuoto se non lo conosci.', 'ponsenergiasolare'), 'invalid-consumption');
    }
    if (pons_quote_value($post, 'privacy') !== '1') { $errors['privacy'] = pons_quote_label(__('Conferma di aver letto l’informativa privacy.', 'ponsenergiasolare'), 'invalid-privacy'); }
    if (!get_privacy_policy_url() && !get_option('tw_privacy_policy_url', '')) { $errors['privacy'] = pons_quote_label(__('Il modulo non è ancora disponibile. Contattaci tramite i recapiti del sito.', 'ponsenergiasolare'), 'unavailable'); }
    if (!isset($post['messaggio']) || !is_string($post['messaggio']) || mb_strlen(wp_unslash($post['messaggio'])) > 3000) { $errors['messaggio'] = pons_quote_label(__('Il messaggio può contenere al massimo 3000 caratteri.', 'ponsenergiasolare'), 'invalid-message'); }
    if (mb_strlen($fields['nome']) > 150) { $errors['nome'] = pons_quote_label(__('Il nome può contenere al massimo 150 caratteri.', 'ponsenergiasolare'), 'invalid-name'); }
    if (mb_strlen($fields['telefono']) > 50) { $errors['telefono'] = pons_quote_label(__('Il telefono può contenere al massimo 50 caratteri.', 'ponsenergiasolare'), 'invalid-phone'); }
    return $errors;
}
add_filter('ticinoweb_form_errors', 'pons_quote_errors', 10, 3);

// The parent can succeed through storage alone; do not promise that mail was sent.
add_filter('ticinoweb_form_success_message', static function ($message, $fields) {
    return pons_quote_value($_POST, 'pons_quote') === '1' ? pons_quote_label(__('Richiesta ricevuta.', 'ponsenergiasolare'), 'received') : $message;
}, 10, 2);

function pons_quote_shortcode() {
    $id = wp_unique_id('pons-quote-');
    $choices = pons_quote_choices();
    $privacy = get_privacy_policy_url() ?: (string) get_option('tw_privacy_policy_url', '');
    $config = array(
        'ajaxUrl' => admin_url('admin-ajax.php'),
        'siteKey' => (string) get_option('ticinoweb_recaptcha_site_key', ''),
        'sending' => pons_quote_label(__('Invio in corso…', 'ponsenergiasolare'), 'sending'),
        'error' => pons_quote_label(__('Invio non confermato. Riprova oppure usa i contatti del sito.', 'ponsenergiasolare'), 'error'),
        'saved' => pons_quote_label(__('Richiesta registrata. La notifica email non è stata inviata; puoi contattarci anche direttamente.', 'ponsenergiasolare'), 'saved'),
        'mailed' => pons_quote_label(__('Richiesta inviata via email. La registrazione nel sito non è riuscita.', 'ponsenergiasolare'), 'mailed'),
        'success' => pons_quote_label(__('Richiesta registrata e inviata. Grazie per averci contattato.', 'ponsenergiasolare'), 'success'),
        'check' => pons_quote_label(__('Controlla i campi indicati.', 'ponsenergiasolare'), 'check'),
    );
    $select = static function ($name, $label) use ($id, $choices) {
        echo '<label for="' . esc_attr($id . $name) . '">' . esc_html($label) . '</label><select id="' . esc_attr($id . $name) . '" name="' . esc_attr($name) . '" required>';
        if (in_array($name, array('property_type', 'roof_type'), true)) { echo '<option value="">' . esc_html(pons_quote_label(__('Seleziona un’opzione', 'ponsenergiasolare'), 'select')) . '</option>'; }
        foreach ($choices[$name] as $value => $text) { echo '<option value="' . esc_attr($value) . '">' . esc_html($text) . '</option>'; }
        echo '</select>';
    };
    ob_start(); ?>
    <form class="pons-quote" data-pons-quote data-config="<?php echo esc_attr(wp_json_encode($config)); ?>" method="post" action="<?php echo esc_url(admin_url('admin-ajax.php')); ?>">
        <input type="hidden" name="action" value="ticinoweb_submit_form"><input type="hidden" name="pons_quote" value="1">
        <input type="hidden" name="token" value="<?php echo esc_attr(wp_create_nonce('ticinoweb_submit_form')); ?>">
        <input type="hidden" name="recaptcha_token" value="">
        <div class="pons-quote-trap" aria-hidden="true"><label><?php echo esc_html(pons_quote_label(__('Lascia vuoto questo campo', 'ponsenergiasolare'), 'trap')); ?><input name="tw_hp" type="text" tabindex="-1" autocomplete="off"></label></div>
        <ol class="pons-quote-progress" hidden aria-label="<?php echo esc_attr(pons_quote_label(__('Fasi della richiesta', 'ponsenergiasolare'), 'stages')); ?>">
            <li><?php echo esc_html(pons_quote_label(__('Il tuo immobile', 'ponsenergiasolare'), 'step-property')); ?></li><li><?php echo esc_html(pons_quote_label(__('Le tue esigenze', 'ponsenergiasolare'), 'step-needs')); ?></li><li><?php echo esc_html(pons_quote_label(__('I tuoi contatti', 'ponsenergiasolare'), 'step-contact')); ?></li>
        </ol>
        <fieldset data-quote-step><legend tabindex="-1"><?php echo esc_html(pons_quote_label(__('Il tuo immobile', 'ponsenergiasolare'), 'step-property')); ?></legend>
            <div class="pons-quote-grid"><div><?php $select('property_type', pons_quote_label(__('Tipo di immobile *', 'ponsenergiasolare'), 'property-label')); ?></div><div><?php $select('roof_type', pons_quote_label(__('Tipo di tetto *', 'ponsenergiasolare'), 'roof-label')); ?></div></div>
            <label for="<?php echo esc_attr($id); ?>locality"><?php echo esc_html(pons_quote_label(__('Località / NPA *', 'ponsenergiasolare'), 'locality-label')); ?></label><input id="<?php echo esc_attr($id); ?>locality" name="locality" required minlength="2" maxlength="150" autocomplete="address-level2">
        </fieldset>
        <fieldset data-quote-step><legend tabindex="-1"><?php echo esc_html(pons_quote_label(__('Le tue esigenze', 'ponsenergiasolare'), 'step-needs')); ?></legend>
            <label for="<?php echo esc_attr($id); ?>consumption"><?php echo esc_html(pons_quote_label(__('Consumo elettrico annuo indicativo (kWh)', 'ponsenergiasolare'), 'consumption-label')); ?></label><input id="<?php echo esc_attr($id); ?>consumption" name="annual_consumption" type="number" min="1" max="1000000" step="1" inputmode="numeric" aria-describedby="<?php echo esc_attr($id); ?>consumption-help">
            <p class="pons-quote-hint" id="<?php echo esc_attr($id); ?>consumption-help"><?php echo esc_html(pons_quote_label(__('Lo trovi sulla bolletta. Se non lo conosci, lascia il campo vuoto.', 'ponsenergiasolare'), 'consumption-help')); ?></p>
            <div class="pons-quote-grid"><div><?php $select('battery', pons_quote_label(__('Ti interessa un accumulatore?', 'ponsenergiasolare'), 'battery-label')); ?></div><div><?php $select('ev', pons_quote_label(__('Ti interessa la ricarica auto?', 'ponsenergiasolare'), 'ev-label')); ?></div></div>
        </fieldset>
        <fieldset data-quote-step><legend tabindex="-1"><?php echo esc_html(pons_quote_label(__('I tuoi contatti', 'ponsenergiasolare'), 'step-contact')); ?></legend>
            <label for="<?php echo esc_attr($id); ?>name"><?php echo esc_html(pons_quote_label(__('Nome e cognome *', 'ponsenergiasolare'), 'name-label')); ?></label><input id="<?php echo esc_attr($id); ?>name" name="nome" required minlength="2" maxlength="150" autocomplete="name">
            <div class="pons-quote-grid"><div><label for="<?php echo esc_attr($id); ?>email"><?php echo esc_html(pons_quote_label(__('Email *', 'ponsenergiasolare'), 'email-label')); ?></label><input id="<?php echo esc_attr($id); ?>email" name="email" type="email" required maxlength="254" autocomplete="email"></div><div><label for="<?php echo esc_attr($id); ?>phone"><?php echo esc_html(pons_quote_label(__('Telefono (facoltativo)', 'ponsenergiasolare'), 'phone-label')); ?></label><input id="<?php echo esc_attr($id); ?>phone" name="telefono" type="tel" maxlength="50" autocomplete="tel"></div></div>
            <label for="<?php echo esc_attr($id); ?>message"><?php echo esc_html(pons_quote_label(__('Vuoi aggiungere qualcosa? (facoltativo)', 'ponsenergiasolare'), 'message-label')); ?></label><textarea id="<?php echo esc_attr($id); ?>message" name="messaggio" rows="4" maxlength="3000"></textarea>
            <p class="pons-quote-hint"><?php echo esc_html(pons_quote_label(__('I dati della richiesta vengono registrati nel sito e notificati via email al team per risponderti.', 'ponsenergiasolare'), 'data-notice')); ?></p>
            <?php if ($privacy) : ?><label class="pons-quote-privacy"><input name="privacy" type="checkbox" value="1" required><span><?php echo esc_html(pons_quote_label(__('Ho letto l’informativa sul trattamento dei dati personali.', 'ponsenergiasolare'), 'privacy')); ?> <a href="<?php echo esc_url(function_exists('ticinoweb_frontend_url') ? ticinoweb_frontend_url($privacy, 'theme:url:privacy') : $privacy); ?>"><?php echo esc_html(pons_quote_label(__('Leggi la privacy policy', 'ponsenergiasolare'), 'privacy-link')); ?></a></span></label>
            <?php else : ?><p role="alert"><?php echo esc_html(pons_quote_label(__('Il modulo non è ancora disponibile. Contattaci tramite i recapiti del sito.', 'ponsenergiasolare'), 'unavailable')); ?></p><?php endif; ?>
        </fieldset>
        <div class="pons-quote-actions"><button type="button" data-quote-back hidden><?php echo esc_html(pons_quote_label(__('Indietro', 'ponsenergiasolare'), 'back')); ?></button><button type="button" data-quote-next hidden><?php echo esc_html(pons_quote_label(__('Continua', 'ponsenergiasolare'), 'next')); ?><span aria-hidden="true">↗</span></button><button type="submit" data-quote-submit <?php disabled(!$privacy); ?>><?php echo esc_html(pons_quote_label(__('Invia la richiesta', 'ponsenergiasolare'), 'submit')); ?><span aria-hidden="true">↗</span></button></div>
        <p class="pons-quote-status" data-quote-status role="status" aria-live="polite" tabindex="-1"></p>
        <noscript><p><?php echo esc_html(pons_quote_label(__('Puoi compilare tutte le sezioni e inviare il modulo. Dopo l’invio sarà mostrata una conferma testuale. Se è attiva la verifica anti-spam, abilita JavaScript oppure usa i contatti del sito.', 'ponsenergiasolare'), 'noscript')); ?></p></noscript>
    </form>
    <?php return ob_get_clean();
}
add_shortcode('pons_quote', 'pons_quote_shortcode');
