<?php
/** Decorative process drawing; all editorial copy stays in native Home blocks. */
if (!defined('ABSPATH')) { exit; }
function pons_method_drawing() {
    return '<figure class="method-drawing" aria-hidden="true"><svg viewBox="0 0 560 270" fill="none" focusable="false">
    <defs><pattern id="method-grid-lines" width="28" height="28" patternUnits="userSpaceOnUse"><path d="M28 0H0V28" stroke="currentColor" opacity=".07"/></pattern></defs>
    <path fill="url(#method-grid-lines)" d="M0 0h560v270H0z"/>
    <g class="method-house"><path d="m95 150 190-105 185 105-190 108Z" fill="#f2f0e9"/><path d="M125 133v78l155 47v-94M280 164l158-51v95l-158 50" stroke="#b3bebc" stroke-width="1.6"/>
    <path d="m95 150 83-113 190-25 102 138-190 14Z" fill="#fbfaf6" stroke="#536966" stroke-width="1.8"/><path d="m178 37 102 127M178 37l190-25" stroke="#84948f"/>
    <path d="M158 169v39l37 11v-40Zm65 19v39l31 10v-40Zm88-3v39l43-13v-39Zm59-19v39l42-13v-39Z" stroke="#aebcb8"/>
    </g>
    <g class="method-survey" stroke="#b17d0a" stroke-width="1.4" stroke-dasharray="4 5"><path d="m85 128 90-122 205-23M95 171l181 17 206-18"/><path d="m91 120-12 11 14 4m80-132 2 12 11-5"/></g>
    <g class="method-plan" stroke="#ac810d" stroke-width="1.3"><path d="m204 48 146-18 85 109-146 10Z" stroke-dasharray="5 4"/><path d="m220 72 146-16m-128 40 146-14m-128 39 146-12M252 42l85 105M300 36l85 108" opacity=".45"/></g>
    <g class="method-panels" fill="#36565f" stroke="#e8efec" stroke-width="2"><path d="m210 52 42-5 30 38-42 4Zm49-6 42-5 30 38-42 5Zm49-6 40-5 30 38-40 5ZM246 96l42-4 30 39-42 3Zm49-5 42-4 30 38-42 4Zm49-5 41-4 29 38-40 4Z"/></g>
    <g class="method-powered"><circle cx="455" cy="45" r="16" fill="#ffb800"/><g stroke="#d29a10" stroke-width="1.6"><path d="M455 17V8m0 74v-9m28-28h9m-74 0h9m48-20 7-7m-53 53 7-7m39 0 7 7m-53-53 7 7"/></g><path class="method-current" d="m407 139 20 12v51l-67 23" stroke="#c99513" stroke-width="2.5"/><circle cx="360" cy="225" r="4" fill="#ffb800"/></g>
    <path d="M70 260h420" stroke="#d9dfdb"/>
    </svg></figure>';
}
add_filter('render_block_core/group', static function ($html, $block) {
    $classes = preg_split('/\s+/', trim($block['attrs']['className'] ?? ''));
    if (!in_array('method-section', $classes, true)) { return $html; }
    // Insert inside the existing introduction, leaving the native text and steps untouched.
    return preg_replace_callback('/<\/p>/', static function ($match) { return $match[0] . pons_method_drawing(); }, $html, 1);
}, 10, 2);
