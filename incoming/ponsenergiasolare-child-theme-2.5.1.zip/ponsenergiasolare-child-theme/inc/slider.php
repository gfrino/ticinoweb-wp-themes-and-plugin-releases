<?php
/** Bespoke presentation for the parent's Slider & Partner data. No new inputs. */
if (!defined('ABSPATH')) { exit; }

function pons_render_slider() {
    $slides = ticinoweb_get_slider_data();
    if (!$slides) { return ''; }
    $count = count($slides);
    $uid = wp_unique_id('solar-hero-');
    ob_start(); ?>
    <section class="solar-hero" data-solar-slider role="region" aria-roledescription="<?php esc_attr_e('carosello', 'ponsenergiasolare'); ?>" aria-label="<?php esc_attr_e('In evidenza', 'ponsenergiasolare'); ?>">
        <div class="solar-stage" id="<?php echo esc_attr($uid); ?>">
            <?php foreach ($slides as $index => $slide) :
                $heading = $index === 0 ? 'h1' : 'h2';
                $image_id = attachment_url_to_postid($slide['image']);
                $label = sprintf(pons_text(__('Slide %1$d di %2$d', 'ponsenergiasolare'), 'slider-position'), $index + 1, $count);
                $link = $slide['btn1_link'];
                if (strpos($link, '#') === 0) { $link = pons_home() . $link; }
                ?>
                <article class="solar-slide <?php echo $index === 0 ? 'is-active' : ''; ?>" data-solar-slide role="group" aria-roledescription="slide" aria-label="<?php echo esc_attr($label); ?>" aria-hidden="<?php echo $index === 0 ? 'false' : 'true'; ?>" <?php echo $index === 0 ? '' : 'inert'; ?>>
                    <figure class="solar-visual">
                        <?php if ($image_id) {
                            echo wp_get_attachment_image($image_id, 'full', false, array('class' => 'solar-image', 'loading' => $index === 0 ? 'eager' : 'lazy', 'fetchpriority' => $index === 0 ? 'high' : 'low', 'decoding' => 'async', 'sizes' => '100vw'));
                        } else { ?>
                            <img class="solar-image" src="<?php echo esc_url($slide['image']); ?>" alt="" width="1200" height="900" loading="<?php echo $index === 0 ? 'eager' : 'lazy'; ?>" decoding="async">
                        <?php } ?>
                    </figure>
                    <div class="solar-copy">
                        <div class="solar-heading">
                        <<?php echo $heading; ?> class="solar-title"><?php
                            // Keep CMS copy intact; emphasize only an introductory clause when present.
                            if (preg_match('/^([^,]+,)(.*)$/us', $slide['title'], $title_parts)) {
                                echo '<span class="solar-title-accent">' . esc_html($title_parts[1]) . '</span>' . esc_html($title_parts[2]);
                            } else {
                                echo esc_html($slide['title']);
                            }
                        ?></<?php echo $heading; ?>>
                        </div>
                        <div class="solar-details"><?php if ($slide['desc']) : ?><p class="solar-description"><?php echo nl2br(esc_html($slide['desc'])); ?></p><?php endif; ?>
                        <?php if ($slide['btn1_text'] && $link) : ?><a class="button solar-cta" href="<?php echo esc_url($link); ?>"><?php echo esc_html($slide['btn1_text']); ?><span aria-hidden="true">↗</span></a><?php endif; ?>
                        </div>
                    </div>
                </article>
            <?php endforeach; ?>
            <div class="solar-corner" aria-hidden="true"><span class="solar-disc"></span></div>
        </div>
        <?php if ($count > 1) : ?>
            <button type="button" class="solar-accessible-pause" data-slider-rotation aria-label="<?php esc_attr_e('Metti in pausa lo slider', 'ponsenergiasolare'); ?>" aria-pressed="false" hidden><span><?php esc_html_e('Metti in pausa lo slider', 'ponsenergiasolare'); ?></span></button>
            <button type="button" class="solar-accessible-pause solar-accessible-next" data-slider-accessible-next hidden><?php esc_html_e('Slide successiva', 'ponsenergiasolare'); ?></button>
        <?php endif; ?>
    </section>
    <?php return ob_get_clean();
}

add_action('init', static function () { add_shortcode('ticinoweb_slider', 'pons_render_slider'); }, 20);
