<?php
/** Presentation controls only. Editorial headings and explanations live in Home blocks. */
if (!defined('ABSPATH')) { exit; }
add_shortcode('pons_solar_lab', static function () {
    $uid = wp_unique_id('solar-lab-');
    ob_start(); ?>
    <div class="solar-lab" data-solar-lab>
        <div class="lab-phase-nav" aria-label="<?php esc_attr_e('Esplora le tre fasi', 'ponsenergiasolare'); ?>" hidden>
            <?php for ($i=0;$i<3;$i++) : ?><button type="button" data-lab-phase="<?php echo esc_attr($i); ?>" aria-pressed="<?php echo $i===0?'true':'false'; ?>"><span aria-hidden="true"><?php echo esc_html(sprintf('%02d',$i+1)); ?></span><span data-phase-label><?php echo esc_html(sprintf(__('Fase %d','ponsenergiasolare'),$i+1)); ?></span></button><?php endfor; ?>
        </div>
        <div class="lab-viewport" data-lab-viewport>
            <figure class="lab-fallback" aria-label="<?php esc_attr_e('Schema illustrativo di un edificio con impianto solare', 'ponsenergiasolare'); ?>">
                <svg viewBox="0 0 800 580" role="img" aria-labelledby="<?php echo esc_attr($uid); ?>"><title id="<?php echo esc_attr($uid); ?>"><?php esc_html_e('Dal tetto al sistema fotovoltaico', 'ponsenergiasolare'); ?></title>
                    <ellipse cx="408" cy="482" rx="255" ry="28" fill="#d5dbd7"/>
                    <path d="M120 387 430 299 704 406 390 509Z" fill="#d3d4cb"/>
                    <path d="M185 253 426 191 426 405 185 466Z" fill="#b9b7aa"/>
                    <path d="M426 191 638 277 638 464 426 405Z" fill="#e5e1d6"/>
                    <path d="M176 253 348 113 434 184 676 277 492 132 348 113Z" fill="#a96e54"/>
                    <path d="M176 253 348 113 492 132 434 184Z" fill="#946451"/>
                    <path d="M348 113 492 132 676 277 434 184Z" fill="#a87058"/>
                    <g fill="#1e3d4b" stroke="#b3c0c4" stroke-width="2"><path d="m385 139 42 6 47 37-43-12Z"/><path d="m435 146 42 6 50 43-45-13Z"/><path d="m442 182 44 13 48 39-46-17Z"/><path d="m493 196 45 13 49 43-47-18Z"/><path d="m488 153 43 6 54 49-47-13Z"/><path d="m548 212 47 13 53 48-50-19Z"/></g>
                    <g fill="#4b6266" stroke="#796654" stroke-width="7"><path d="m213 329 55-15v65l-55 16Z"/><path d="m327 299 48-13v69l-48 14Z"/><path d="m470 285 45 18v65l-45-18Z"/><path d="m555 320 44 18v65l-44-18Z"/></g>
                    <path d="m347 378 42-11v80l-42 10Z" fill="#776453"/><path d="m435 184 203 93" fill="none" stroke="#69564b" stroke-width="5"/>
                </svg>
            </figure>
            <div class="lab-canvas" data-lab-canvas aria-hidden="true" role="img" aria-label="<?php esc_attr_e('Modello tridimensionale illustrativo: tetto, moduli e percorso dell’energia', 'ponsenergiasolare'); ?>"></div>
            <div class="lab-labels" data-lab-3d-controls hidden>
                <?php $components = array('modules' => __('Moduli', 'ponsenergiasolare'), 'inverter' => __('Inverter', 'ponsenergiasolare'), 'building' => __('Edificio', 'ponsenergiasolare'), 'roof' => __('Tetto', 'ponsenergiasolare'));
                foreach ($components as $key => $name) : ?><button type="button" data-lab-component="<?php echo esc_attr($key); ?>" data-lab-label="<?php echo esc_attr(array_search($key, array_keys($components), true)); ?>" aria-expanded="false" aria-controls="<?php echo esc_attr($uid.'-inspector'); ?>" hidden><?php echo esc_html($name); ?><span aria-hidden="true"> +</span></button><?php endforeach; ?>
            </div>
            <div class="lab-scene-tools" data-lab-3d-controls hidden>
                <button type="button" data-lab-rotate="-1" aria-label="<?php esc_attr_e('Ruota il modello a sinistra', 'ponsenergiasolare'); ?>">↶</button>
                <button type="button" data-lab-reset aria-label="<?php esc_attr_e('Ripristina la vista iniziale', 'ponsenergiasolare'); ?>">↺</button>
                <button type="button" data-lab-rotate="1" aria-label="<?php esc_attr_e('Ruota il modello a destra', 'ponsenergiasolare'); ?>">↷</button>
            </div>
            <button type="button" class="lab-flow-control" data-lab-flow aria-pressed="false" hidden><?php esc_html_e('Pausa flusso', 'ponsenergiasolare'); ?></button>
            <button type="button" class="lab-mount-control" data-lab-explode aria-pressed="false" hidden><?php esc_html_e('Scopri il montaggio', 'ponsenergiasolare'); ?></button>
            <p class="lab-drag-hint" data-lab-3d-controls hidden><?php esc_html_e('Trascina per esplorare', 'ponsenergiasolare'); ?></p>
        </div>
        <div class="lab-inspector" id="<?php echo esc_attr($uid.'-inspector'); ?>" data-lab-inspector hidden>
            <div class="lab-inspector-copy" aria-live="polite">
                <?php $details = array(
                    'roof' => array(__('Prima, il tetto', 'ponsenergiasolare'), __('Orientamento, superficie disponibile e condizioni della copertura guidano la disposizione dei moduli. Nel modello puoi osservare le superfici e le ombre.', 'ponsenergiasolare')),
                    'modules' => array(__('La luce diventa elettricità', 'ponsenergiasolare'), __('Le celle fotovoltaiche trasformano la luce in corrente continua. Cornice, morsetti e guide fissano il modulo alla struttura: esplora il montaggio nella seconda fase.', 'ponsenergiasolare')),
                    'inverter' => array(__('Il passaggio che rende utile l’energia', 'ponsenergiasolare'), __('L’inverter converte la corrente continua dei moduli in corrente alternata utilizzabile nell’edificio. Il percorso cambia colore per rendere visibile questa trasformazione.', 'ponsenergiasolare')),
                    'building' => array(__('L’energia raggiunge l’edificio', 'ponsenergiasolare'), __('Dopo l’inverter, il percorso mostra la corrente alternata diretta all’edificio. Qui segui un principio di funzionamento: non il cablaggio esecutivo di un impianto.', 'ponsenergiasolare')),
                ); foreach ($details as $key => $detail) : ?><div data-lab-detail="<?php echo esc_attr($key); ?>" hidden><h4><?php echo esc_html($detail[0]); ?></h4><p><?php echo esc_html($detail[1]); ?></p></div><?php endforeach; ?>
            </div>
            <button type="button" data-lab-close aria-label="<?php esc_attr_e('Chiudi il dettaglio e torna alla vista generale', 'ponsenergiasolare'); ?>">×</button>
        </div>
        <p class="lab-energy-key" data-lab-energy-key hidden><span><?php esc_html_e('Corrente continua', 'ponsenergiasolare'); ?></span><span><?php esc_html_e('Corrente alternata', 'ponsenergiasolare'); ?></span></p>
        <div class="lab-controls" data-lab-3d-controls hidden>
            <fieldset class="lab-view-toggle"><legend><?php esc_html_e('Vista del modello', 'ponsenergiasolare'); ?></legend><button type="button" data-lab-view="material" aria-pressed="true"><?php esc_html_e('Materiali', 'ponsenergiasolare'); ?></button><button type="button" data-lab-view="blueprint" aria-pressed="false"><?php esc_html_e('Progetto', 'ponsenergiasolare'); ?></button></fieldset>
            <label class="lab-light" for="<?php echo esc_attr($uid.'-light'); ?>"><span><?php esc_html_e('Dal giorno alla sera', 'ponsenergiasolare'); ?><output data-lab-period><?php esc_html_e('Giorno', 'ponsenergiasolare'); ?></output></span><input id="<?php echo esc_attr($uid.'-light'); ?>" type="range" min="-65" max="65" value="-25" step="1" data-lab-light><small data-lab-night hidden><?php esc_html_e('Scena serale: il flusso solare è fermo.', 'ponsenergiasolare'); ?></small><small data-lab-light-help hidden><?php esc_html_e('La luce si esplora nella vista Materiali.', 'ponsenergiasolare'); ?></small></label>
        </div>
        <p class="lab-status" role="status" data-lab-status></p>
    </div>
    <?php return ob_get_clean();
});
