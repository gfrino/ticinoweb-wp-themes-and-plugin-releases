<?php
/** Native premium pages and parent-owned content, without a parallel CMS. */
if (!defined('ABSPATH')) { exit; }
function pons_page_id($role) {
    static $ids = array();
    if (isset($ids[$role])) { return $ids[$role]; }
    $mapping = array('servizi' => 'page_servizi', 'chi-siamo' => 'page_chi_siamo', 'contatti' => 'page_contatti');
    if (isset($mapping[$role])) {
        $mapped = ticinoweb_get_mapped_page_id($mapping[$role]);
        if ($mapped && get_post_status($mapped) === 'publish') { return $ids[$role] = $mapped; }
    }
    $posts = get_posts(array('post_type' => 'page', 'post_status' => 'publish', 'posts_per_page' => 1, 'fields' => 'ids', 'meta_key' => '_pons_page_role', 'meta_value' => $role));
    return $ids[$role] = (int) ($posts[0] ?? 0);
}
function pons_page_url($role) {
    $id = pons_page_id($role);
    return $id ? ticinoweb_frontend_url(get_permalink($id), 'post:' . $id . ':url') : '';
}
function pons_service_page_url($service_id) {
    static $pages;
    if ($pages === null) {
        $service_ids = array_filter(array_column(ticinoweb_get_services(), 'id'));
        $pages = $service_ids ? get_posts(array('post_type' => 'page', 'post_status' => 'publish', 'posts_per_page' => count($service_ids), 'meta_query' => array(array('key' => '_pons_service_id', 'value' => $service_ids, 'compare' => 'IN')))) : array();
    }
    foreach ($pages as $page) { if (get_post_meta($page->ID, '_pons_service_id', true) === (string) $service_id) { return ticinoweb_frontend_url(get_permalink($page), 'post:' . $page->ID . ':url'); } }
    return '';
}
/** Navigation wording follows the native quote page title. */
function pons_quote_cta_label() {
    $id = pons_page_id('preventivo');
    return $id ? get_the_title($id) : pons_text(__('Richiedi un preventivo', 'ponsenergiasolare'), 'quote-cta');
}

function pons_current_service() {
    $id = get_post_meta(get_queried_object_id(), '_pons_service_id', true);
    foreach (ticinoweb_get_services() as $service) { if ((string) ($service['id'] ?? '') === (string) $id && $id) { return $service; } }
    return array();
}
function pons_service_description($description) {
    $html = '';
    foreach (preg_split('/(?:\r?\n){2,}/u', trim($description)) as $chunk) {
        if (preg_match('/^\s*•/u', $chunk)) {
            $html .= '<ul>';
            foreach (preg_split('/\R(?=\s*•)/u', $chunk) as $bullet) { $html .= '<li>' . wp_kses_post(preg_replace('/^\s*•\s*/u', '', $bullet)) . '</li>'; }
            $html .= '</ul>';
        } else { $html .= wp_kses_post(wpautop($chunk)); }
    }
    return $html;
}
add_shortcode('pons_service_summary', static function () {
    $service = pons_current_service();
    return $service ? '<div class="service-detail">' . pons_service_description($service['description'] ?? '') . '</div>' : '';
});
add_shortcode('pons_service_catalog', static function () {
    $html = '<div class="premium-service-grid">';
    foreach (ticinoweb_get_services() as $index => $service) {
        $url = pons_service_page_url($service['id'] ?? '');
        if (!$url) { continue; }
        $description = preg_split('/(?:\r?\n){2,}/u', $service['description'] ?? '')[0];
        $image = $service['image'] ?? '';
        $html .= '<article class="premium-service-item"><a class="premium-service-link" href="' . esc_url($url) . '">';
        if ($image) {
            $html .= '<div class="premium-service-photo">' . pons_image($image, '', '(max-width:780px) 90vw, 46vw') . '</div>';
        } else { $html .= '<div class="premium-service-photo premium-service-art" aria-hidden="true"><span class="solar-disc"></span></div>'; }
        $html .= '<div class="premium-service-copy"><span class="premium-index">' . esc_html(sprintf('%02d', $index + 1)) . '</span><h3>' . esc_html($service['title']) . '</h3><p>' . esc_html(wp_strip_all_tags($description)) . '</p><span class="premium-service-arrow" aria-hidden="true">↗</span></div></a></article>';
    }
    return $html . '</div>';
});

/** Adjacent stages always follow the CMS service order and translated page URLs. */
add_shortcode('pons_service_next', static function () {
    $services = array_values(ticinoweb_get_services());
    $current = pons_current_service();
    if (!$current) { return ''; }
    $position = array_search($current['id'], array_column($services, 'id'), true);
    if ($position === false) { return ''; }
    $html = '<nav class="service-journey" aria-label="' . esc_attr(pons_text(__('Altri servizi', 'ponsenergiasolare'), 'other-services')) . '">';
    foreach (array(-1, 1) as $direction) {
        $service = $services[$position + $direction] ?? null;
        if (!$service || !($url = pons_service_page_url($service['id']))) { continue; }
        $label = $direction < 0 ? __('Servizio precedente', 'ponsenergiasolare') : __('Continua il percorso', 'ponsenergiasolare');
        $html .= '<a href="' . esc_url($url) . '"><span>' . esc_html(pons_text($label, $direction < 0 ? 'previous-service' : 'next-service')) . '</span><strong>' . esc_html($service['title']) . '</strong><i aria-hidden="true">' . ($direction < 0 ? '↖' : '↗') . '</i></a>';
    }
    return $html . '</nav>';
});

/** Table of contents derives labels from editable native headings, not duplicated copy. */
add_shortcode('pons_page_contents', static function () {
    $links = array();
    $walk = static function ($blocks) use (&$walk, &$links) {
        foreach ($blocks as $block) {
            if ($block['blockName'] === 'core/heading' && ($block['attrs']['level'] ?? 2) === 2 && !empty($block['attrs']['anchor'])) {
                $links[] = '<li><a href="#' . esc_attr($block['attrs']['anchor']) . '">' . esc_html(wp_strip_all_tags($block['innerHTML'])) . '</a></li>';
            }
            if (!empty($block['innerBlocks'])) { $walk($block['innerBlocks']); }
        }
    };
    $walk(parse_blocks(get_post_field('post_content', get_queried_object_id())));
    return $links ? '<nav class="page-contents" aria-label="' . esc_attr(pons_text(__('In questa pagina', 'ponsenergiasolare'), 'page-contents')) . '"><ol>' . implode('', $links) . '</ol></nav>' : '';
});
add_shortcode('pons_page_link', static function ($atts) {
    $atts = shortcode_atts(array('page' => '', 'label' => ''), $atts);
    $url = pons_page_url(sanitize_key($atts['page']));
    if (!$url) { return ''; }
    $label = $atts['label'] ?: get_the_title(pons_page_id($atts['page']));
    return '<a class="premium-link" href="' . esc_url($url) . '">' . esc_html(pons_text($label, 'page-link-' . sanitize_key($atts['page']))) . '<span aria-hidden="true">↗</span></a>';
});
add_shortcode('pons_references', static function ($atts) {
    $atts = shortcode_atts(array('gallery' => 0), $atts);
    $term = get_term(absint($atts['gallery']), 'ticinoweb_media_gallery');
    if (!$term || is_wp_error($term)) { return ''; }
    $images = get_posts(array('post_type' => 'attachment', 'post_status' => 'inherit', 'post_mime_type' => 'image', 'posts_per_page' => 60, 'tax_query' => array(array('taxonomy' => 'ticinoweb_media_gallery', 'field' => 'term_id', 'terms' => $term->term_id)), 'meta_query' => array(array('key' => '_pons_illustrative_generated', 'compare' => 'NOT EXISTS')), 'orderby' => 'menu_order ID', 'order' => 'ASC'));
    if (!$images) { return ''; }
    $order = get_term_meta($term->term_id, '_ticinoweb_gallery_order', true);
    if (is_array($order) && $order) {
        $positions = array_flip(array_map('absint', $order));
        usort($images, static function ($a, $b) use ($positions) { return ($positions[$a->ID] ?? PHP_INT_MAX) <=> ($positions[$b->ID] ?? PHP_INT_MAX); });
    }
    $html = '<div class="reference-grid">';
    foreach ($images as $image) { $html .= '<figure>' . wp_get_attachment_image($image->ID, 'large', false, array('loading' => 'lazy', 'sizes' => '(max-width:780px) 90vw, 45vw')) . ($image->post_excerpt ? '<figcaption>' . esc_html($image->post_excerpt) . '</figcaption>' : '') . '</figure>'; }
    return $html . '</div>';
});
add_shortcode('pons_map', static function () {
    $address = pons_contacts()['address'];
    if (!$address) { return ''; }
    $url = 'https://maps.google.com/maps?q=' . rawurlencode(preg_replace('/\s+/', ' ', $address)) . '&output=embed';
    return '<div class="premium-map" data-map-src="' . esc_url($url) . '"><span class="map-orbit solar-disc" aria-hidden="true"></span><div class="map-prompt"><h2>' . esc_html(pons_text(__('Ci trovi qui.', 'ponsenergiasolare'), 'map-title')) . '</h2><p>' . nl2br(esc_html($address)) . '</p><button type="button" class="button" data-load-map>' . esc_html(pons_text(__('Carica la mappa di Google', 'ponsenergiasolare'), 'map-load')) . '</button><p class="map-notice">' . esc_html(pons_text(__('La mappa viene caricata solo su tua richiesta. Google riceverà i dati tecnici della connessione.', 'ponsenergiasolare'), 'map-notice')) . '</p></div></div>';
});

// Keep the parent's breadcrumb renderer/schema, enriching only native page ancestry.
add_filter('ticinoweb_seo_breadcrumb_items', static function ($items) {
    if (!is_page() || is_front_page() || count($items) < 2) { return $items; }
    $service = pons_current_service();
    if ($service) { $items[count($items) - 1]['name'] = $service['title']; }
    $ancestors = array_reverse(get_post_ancestors(get_queried_object_id()));
    if (!$ancestors) { return $items; }
    $parents = array();
    foreach ($ancestors as $id) {
        $parents[] = array('name' => get_the_title($id), 'url' => ticinoweb_frontend_url(get_permalink($id), 'post:' . $id . ':url'));
    }
    array_splice($items, 1, 0, $parents);
    return $items;
});
