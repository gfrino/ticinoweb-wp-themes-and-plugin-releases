<?php
/** Visual journey using only the parent's canonical service fields. */
if (!defined('ABSPATH')) { exit; }
add_shortcode('pons_services', static function () {
    $services = array_values(array_filter(ticinoweb_get_services(), static function ($service) { return !empty($service['title']); }));
    if (!$services) { return ''; }
    $prefix = wp_unique_id('pons-services-');
    $count = count($services);
    ob_start(); ?>
    <div class="services-explorer" data-services-explorer style="--service-count:<?php echo esc_attr((string) $count); ?>">
        <?php if ($count > 1) : ?>
        <div class="services-navigation" aria-label="<?php echo esc_attr(pons_text(__('Le fasi del tuo impianto', 'ponsenergiasolare'), 'services-navigation')); ?>" hidden>
            <?php foreach ($services as $index => $service) : ?>
            <button type="button" id="<?php echo esc_attr($prefix . '-tab-' . $index); ?>" aria-controls="<?php echo esc_attr($prefix . '-panel-' . $index); ?>" data-service-select="<?php echo esc_attr($index); ?>">
                <span class="service-index" aria-hidden="true"><?php echo esc_html(sprintf('%02d', $index + 1)); ?></span>
                <span><?php echo esc_html($service['title']); ?></span><span class="service-nav-arrow" aria-hidden="true">↗</span>
            </button>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
        <div class="services-stage">
            <?php foreach ($services as $index => $service) : ?>
            <article class="service-panel<?php echo empty($service['image']) ? ' service-panel-text' : ''; ?>" id="<?php echo esc_attr($prefix . '-panel-' . $index); ?>" aria-labelledby="<?php echo esc_attr($prefix . '-title-' . $index); ?>">
                <?php if (!empty($service['image'])) : ?>
                <figure class="service-visual"><?php echo pons_image($service['image'], '', '(max-width:420px) calc(100vw - 44px), (max-width:700px) calc(100vw - 50px), (max-width:1500px) 48vw, 662px'); ?>
                </figure>
                <?php endif; ?>
                <div class="service-content">
                    <span class="service-chapter" aria-hidden="true"><?php echo esc_html(sprintf('%02d / %02d', $index + 1, $count)); ?></span>
                    <h3 id="<?php echo esc_attr($prefix . '-title-' . $index); ?>"><?php echo esc_html($service['title']); ?></h3>
                    <div class="service-description"><?php
                    // Preserve CMS HTML; convert plain bullet lines into a semantic list.
                    $description = (string) ($service['description'] ?? '');
                    $chunks = preg_split('/(?:\r?\n){2,}/u', trim($description));
                    foreach ($chunks as $chunk) {
                        if (preg_match('/^\s*•/u', $chunk)) {
                            echo '<ul>';
                            foreach (preg_split('/\R(?=\s*•)/u', $chunk) as $bullet) {
                                echo '<li>' . wp_kses_post(preg_replace('/^\s*•\s*/u', '', $bullet)) . '</li>';
                            }
                            echo '</ul>';
                        } else { echo wp_kses_post(wpautop($chunk)); }
                    }
                    ?></div>
                    <?php if ($detail = pons_service_page_url($service['id'] ?? '')) : ?><a class="service-contact" href="<?php echo esc_url($detail); ?>"><?php echo esc_html(pons_text(__('Scopri il servizio', 'ponsenergiasolare'), 'service-detail')); ?><span aria-hidden="true">↗</span></a><?php endif; ?>
                    <a class="service-contact" href="<?php echo esc_url(pons_page_url('preventivo') ?: pons_home() . '#contatti'); ?>"><?php echo esc_html(pons_text(__('Richiedi un preventivo', 'ponsenergiasolare'), 'services-contact')); ?><span aria-hidden="true">↗</span></a>
                </div>
            </article>
            <?php endforeach; ?>
        </div>
    </div>
    <?php return ob_get_clean();
});
