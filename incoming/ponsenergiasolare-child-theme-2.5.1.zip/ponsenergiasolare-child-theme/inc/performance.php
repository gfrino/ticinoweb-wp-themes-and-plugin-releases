<?php
/** Presentation assets only; source files remain the editable source of truth. */
if (!defined('ABSPATH')) { exit; }

function pons_style_bundle() {
    $base = array('site.css', 'footer.css', 'header.css', 'pages.css', 'base.entry.css');
    $home = array('method.css', 'solutions.css', 'about.css', 'contacts.css', 'lab.css', 'lab-entry.css', 'services.css', 'slider.css', 'handoff.css', 'home.entry.css');
    $name = is_front_page() ? 'home.min.css' : 'base.min.css';
    $directory = get_stylesheet_directory() . '/assets/css/';
    if (!is_readable($directory . $name)) { return false; }
    $built = filemtime($directory . $name);
    foreach (is_front_page() ? array_merge($base, $home) : $base as $file) {
        if (!is_readable($directory . $file) || filemtime($directory . $file) > $built) { return false; }
    }
    return $name;
}

function pons_enqueue_style($handle, $file, $dependencies, $version) {
    $bundle = pons_style_bundle();
    if ($bundle && $handle !== 'pons-site') {
        // Preserve the registered handles/dependencies without a duplicate request.
        wp_register_style($handle, false, $dependencies, $version);
        wp_enqueue_style($handle);
        return;
    }
    wp_enqueue_style($handle, get_stylesheet_directory_uri() . '/assets/css/' . ($bundle ?: $file), $dependencies, $version);
}

add_action('wp_head', static function () {
    foreach (array('archivo-latin.woff2', 'source-sans-3-latin.woff2') as $file) {
        echo '<link rel="preload" href="' . esc_url(get_stylesheet_directory_uri() . '/assets/fonts/' . $file) . '" as="font" type="font/woff2" crossorigin>' . "\n";
    }
}, 2);

add_filter('render_block_core/image', static function ($html, $block) {
    $classes = preg_split('/\s+/', trim($block['attrs']['className'] ?? ''));
    if (!in_array('solution-photo', $classes, true)) { return $html; }
    $processor = new WP_HTML_Tag_Processor($html);
    if ($processor->next_tag('IMG')) {
        $processor->set_attribute('sizes', '(max-width:420px) calc(100vw - 44px), (max-width:780px) calc(100vw - 50px), (max-width:1500px) calc(45vw - 18px), 652px');
        $processor->set_attribute('loading', 'lazy');
        $processor->set_attribute('decoding', 'async');
    }
    return $processor->get_updated_html();
}, 10, 2);
