<?php if (!defined('ABSPATH')) { exit; } get_header(); ?>
<main id="main" class="site-main premium-document" tabindex="-1">
<?php while (have_posts()) : the_post();
    $service = pons_current_service();
    $role = get_post_meta(get_the_ID(), '_pons_page_role', true);
    $photo = !empty($service['image']) ? $service['image'] : get_the_post_thumbnail_url(get_the_ID(), 'large');
    $image_id = !empty($service['image']) ? attachment_url_to_postid($photo) : get_post_thumbnail_id(get_the_ID());
    $compact = in_array($role, array('preventivo', 'privacy', 'contatti', 'note-legali'), true);
    $classes = 'page-hero premium-scene-' . sanitize_html_class($role ?: 'page') . ($photo ? ' page-hero-photo' : '') . ($compact ? ' page-hero-compact' : '') . ($service ? ' page-hero-service' : '');
?>
<header class="<?php echo esc_attr($classes); ?>" data-page-scene>
    <div class="premium-shell page-hero-grid">
        <div class="page-hero-copy">
            <div class="premium-breadcrumbs"><?php echo do_shortcode('[ticinoweb_breadcrumbs]'); ?></div>
            <h1><?php echo esc_html($service['title'] ?? get_the_title()); ?></h1>
            <?php if (has_excerpt()) : ?><p class="page-lead"><?php echo esc_html(get_the_excerpt()); ?></p><?php endif; ?>
            <?php if (!$compact && pons_page_url('preventivo')) : ?>
            <div class="page-hero-actions"><a class="premium-link" href="<?php echo esc_url(pons_page_url('preventivo')); ?>"><?php echo esc_html(pons_quote_cta_label()); ?><span aria-hidden="true">↗</span></a></div>
            <?php endif; ?>
        </div>
        <?php if ($photo) : ?>
        <figure class="page-hero-image"><div class="page-photo-frame">
            <?php echo $image_id ? wp_get_attachment_image($image_id, 'large', false, array('loading' => 'eager', 'fetchpriority' => 'high', 'sizes' => '(max-width:780px) 100vw, 52vw')) : pons_image($photo); ?>
            </div>
            <span class="page-photo-sun solar-disc" aria-hidden="true"></span>
        </figure>
        <?php else : ?><span class="page-orbit solar-disc" aria-hidden="true"></span><?php endif; ?>
    </div>
    <span class="page-hero-baseline" aria-hidden="true"></span>
</header>
<div class="premium-content premium-role-<?php echo esc_attr(sanitize_html_class($role)); ?><?php echo $service ? ' premium-service-page' : ''; ?>"><?php the_content(); ?></div>
<?php endwhile; ?>
</main>
<?php get_footer(); ?>
