<?php if (!defined('ABSPATH')) { exit; }
$contact = pons_contacts();
$locations = get_nav_menu_locations();
$page_menu = !empty($locations['footer']) ? wp_get_nav_menu_object($locations['footer']) : false;
$has_services = has_nav_menu('footer_services') || pons_footer_service_items() !== '';
?>
<footer class="site-footer">
    <span class="footer-orbit solar-disc" aria-hidden="true"></span>
    <div class="footer-shell">
        <div class="footer-grid<?php echo $has_services ? '' : ' footer-grid-without-services'; ?>">
            <div class="footer-identity">
                <a class="footer-brand" href="<?php echo esc_url(pons_home()); ?>" rel="home"><?php pons_logo(); ?></a>
                <?php if ($contact['address']) : ?><address class="footer-address"><?php echo nl2br(esc_html($contact['address'])); ?></address><?php endif; ?>
                <div class="footer-contacts">
                    <?php if ($contact['phone']) : ?><a href="<?php echo esc_url(pons_phone_url($contact['phone'])); ?>"><?php echo esc_html($contact['phone']); ?></a><?php endif; ?>
                    <?php if ($contact['email']) : ?><a href="mailto:<?php echo esc_attr(antispambot($contact['email'])); ?>"><?php echo esc_html(antispambot($contact['email'])); ?></a><?php endif; ?>
                </div>
            </div>
            <?php if ($has_services) : ?>
            <nav class="footer-services" aria-labelledby="footer-services-title">
                <h2 id="footer-services-title" class="footer-heading"><?php echo esc_html(pons_page_id('servizi') ? get_the_title(pons_page_id('servizi')) : __('Servizi', 'ponsenergiasolare')); ?></h2>
                <?php wp_nav_menu(array('theme_location' => 'footer_services', 'container' => false, 'menu_class' => 'footer-services-menu', 'fallback_cb' => 'pons_footer_services_fallback', 'depth' => 1)); ?>
            </nav>
            <?php endif; ?>
            <?php if ($page_menu) : ?>
            <nav class="footer-navigation" aria-labelledby="footer-pages-title">
                <h2 id="footer-pages-title" class="footer-heading"><?php echo esc_html(pons_text($page_menu->name, 'footer-menu-title')); ?></h2>
                <?php wp_nav_menu(array('theme_location' => 'footer', 'container' => false, 'menu_class' => 'footer-menu', 'fallback_cb' => false, 'depth' => 1)); ?>
            </nav>
            <?php endif; ?>
        </div>
        <div class="footer-utility">
            <span class="footer-copyright">© <?php echo esc_html(wp_date('Y')); ?> <?php echo esc_html(get_bloginfo('name')); ?></span>
            <div class="footer-legal">
                <nav aria-label="<?php esc_attr_e('Informazioni legali', 'ponsenergiasolare'); ?>">
                    <?php wp_nav_menu(array('theme_location' => 'footer_legal', 'container' => false, 'menu_class' => 'footer-legal-menu', 'fallback_cb' => 'pons_footer_legal_fallback', 'depth' => 1)); ?>
                </nav>
                <?php if (get_option('tw_cookie_banner_enable')) : ?><button type="button" class="cookie-preferences"><?php esc_html_e('Preferenze cookie', 'ponsenergiasolare'); ?></button><?php endif; ?>
            </div>
            <a class="footer-top" href="<?php echo esc_url((is_front_page() ? pons_home() : get_permalink()) . '#main'); ?>"><span><?php esc_html_e('Torna in alto', 'ponsenergiasolare'); ?></span><span class="footer-top-symbol" aria-hidden="true">↑</span></a>
        </div>
    </div>
</footer>
<?php if (!empty($args['privacy_content'])) : ?>
<div class="footer-privacy"><?php echo apply_filters('the_content', $args['privacy_content']); ?></div>
<?php endif; ?>
<?php if (pons_page_url('preventivo') && get_post_meta(get_queried_object_id(), '_pons_page_role', true) !== 'preventivo') : ?><a class="quick-quote" href="<?php echo esc_url(pons_page_url('preventivo')); ?>"><?php echo esc_html(pons_quote_cta_label()); ?><span aria-hidden="true">↗</span></a><?php endif; ?>
<?php wp_footer(); ?>
</body></html>
