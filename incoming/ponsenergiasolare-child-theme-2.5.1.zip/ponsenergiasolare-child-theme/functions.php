<?php
/** Pons presentation only. The parent owns CMS, submissions, SEO and consent. */
if (!defined('ABSPATH')) { exit; }
require_once __DIR__ . '/inc/presentation.php';
require_once __DIR__ . '/inc/performance.php';
require_once __DIR__ . '/inc/method.php';
require_once __DIR__ . '/inc/intro.php';
require_once __DIR__ . '/inc/pages.php';
require_once __DIR__ . '/inc/footer.php';
require_once __DIR__ . '/inc/editor.php';
require_once __DIR__ . '/inc/quote.php';
require_once __DIR__ . '/inc/slider.php';
require_once __DIR__ . '/inc/services.php';
require_once __DIR__ . '/inc/lab.php';

add_action('after_setup_theme', static function () {
    load_child_theme_textdomain('ponsenergiasolare', get_stylesheet_directory() . '/languages');
    register_nav_menus(array('primary' => __('Navigazione principale', 'ponsenergiasolare'), 'footer' => __('Collegamenti nel footer', 'ponsenergiasolare')));
    add_theme_support('editor-styles');
    add_editor_style('assets/css/editor.css');
    add_theme_support('responsive-embeds');
    remove_action('wp_enqueue_scripts', 'ticinoweb_ai_assets');
    remove_action('wp_enqueue_scripts', 'ticinoweb_form_localize_main', 20);
    remove_action('wp_head', 'ticinoweb_apply_page_background_image');
    // Remove only the parent's anonymous external-font preconnect; leave all other hooks.
    global $wp_filter;
    foreach (($wp_filter['wp_head']->callbacks[0] ?? array()) as $entry) {
        if ($entry['function'] instanceof Closure) {
            $reflection = new ReflectionFunction($entry['function']);
            if ($reflection->getFileName() === get_template_directory() . '/functions.php') {
                $lines = array_slice(file($reflection->getFileName()), $reflection->getStartLine() - 1, $reflection->getEndLine() - $reflection->getStartLine() + 1);
                if (strpos(implode('', $lines), 'fonts.googleapis.com') !== false) { remove_action('wp_head', $entry['function'], 0); }
            }
        }
    }
}, 30);

add_action('wp_enqueue_scripts', static function () {
    $version = wp_get_theme()->get('Version');
    pons_enqueue_style('pons-site', 'site.css', array(), $version);
    pons_enqueue_style('pons-footer', 'footer.css', array('pons-site'), $version);
    pons_enqueue_style('pons-header', 'header.css', array('pons-site'), $version);
    pons_enqueue_style('pons-pages', 'pages.css', array('pons-site'), $version);
    if (!is_front_page()) {
        wp_enqueue_script('pons-pages', get_stylesheet_directory_uri() . '/assets/js/pages.js', array(), $version, true);
        $content = get_post_field('post_content', get_queried_object_id());
        foreach (array('about' => 'pons_about', 'contacts' => 'pons_contact') as $file => $shortcode) {
            if (has_shortcode($content, $shortcode)) { wp_enqueue_style('pons-page-' . $file, get_stylesheet_directory_uri() . '/assets/css/' . $file . '.css', array('pons-site'), $version); }
        }
        if (has_shortcode($content, 'pons_quote')) {
            wp_enqueue_style('pons-quote', get_stylesheet_directory_uri() . '/assets/css/quote.css', array('pons-site'), $version);
            wp_enqueue_script('pons-quote', get_stylesheet_directory_uri() . '/assets/js/quote.js', array(), $version, true);
        }
    }
    if (is_front_page()) {
        // Run in the head, before native fragment/scroll restoration.
        wp_enqueue_script('pons-reload', get_stylesheet_directory_uri() . '/assets/js/reload.js', array(), $version, false);
        pons_enqueue_style('pons-solutions', 'solutions.css', array('pons-site'), $version);
        pons_enqueue_style('pons-method', 'method.css', array('pons-site'), $version);
        wp_enqueue_script('pons-method', get_stylesheet_directory_uri() . '/assets/js/method.js', array(), $version, true);
        pons_enqueue_style('pons-about', 'about.css', array('pons-site'), $version);
        wp_enqueue_script('pons-about', get_stylesheet_directory_uri() . '/assets/js/about.js', array(), $version, true);
    }
    wp_enqueue_script('pons-site', get_stylesheet_directory_uri() . '/assets/js/site.js', array(), $version, true);
    if (is_front_page()) {
        pons_enqueue_style('pons-contacts', 'contacts.css', array('pons-site'), $version);
        wp_enqueue_script('pons-contacts', get_stylesheet_directory_uri() . '/assets/js/contacts.js', array(), $version, true);
    }
    if (is_front_page() && has_shortcode(get_post_field('post_content', get_queried_object_id()), 'pons_solar_lab')) {
        pons_enqueue_style('pons-lab', 'lab.css', array('pons-site'), $version);
        pons_enqueue_style('pons-lab-entry', 'lab-entry.css', array('pons-lab'), $version);
        wp_register_script_module('pons-lab-entry-state', get_stylesheet_directory_uri() . '/assets/js/lab-entry-state.js', array(), $version);
        wp_enqueue_script_module('pons-lab-entry', get_stylesheet_directory_uri() . '/assets/js/lab-entry.js', array('pons-lab-entry-state'), $version);
        wp_enqueue_script('pons-lab', get_stylesheet_directory_uri() . '/assets/js/lab.js', array(), $version, true);
        wp_localize_script('pons-lab', 'ponsLabLabels', array(
            'sceneUrl' => get_stylesheet_directory_uri() . '/assets/js/lab-scene.bundle.js?ver=' . $version,
            'mount' => __('Scopri il montaggio', 'ponsenergiasolare'),
            'mountClose' => __('Ricomponi il modulo', 'ponsenergiasolare'),
            'morning' => __('Mattino', 'ponsenergiasolare'),
            'day' => __('Giorno', 'ponsenergiasolare'),
            'evening' => __('Sera', 'ponsenergiasolare'),
            'sunset' => __('Tramonto', 'ponsenergiasolare'),
            'pauseFlow' => pons_text(__('Pausa flusso', 'ponsenergiasolare'), 'lab-pause-flow'),
            'playFlow' => pons_text(__('Avvia flusso', 'ponsenergiasolare'), 'lab-play-flow'),
            'loading' => pons_text(__('Il modello prende forma…', 'ponsenergiasolare'), 'lab-loading'),
            'fallback' => pons_text(__('Vista illustrativa. Esplora le tre fasi per conoscere il sistema.', 'ponsenergiasolare'), 'lab-fallback'),
        ));
    }
    if (is_front_page()) {
        pons_enqueue_style('pons-services', 'services.css', array('pons-site'), $version);
        wp_enqueue_script('pons-services', get_stylesheet_directory_uri() . '/assets/js/services.js', array(), $version, true);
        pons_enqueue_style('pons-slider', 'slider.css', array('pons-site'), $version);
        wp_enqueue_script('pons-slider', get_stylesheet_directory_uri() . '/assets/js/slider.js', array(), $version, true);
        pons_enqueue_style('pons-handoff', 'handoff.css', array('pons-slider'), $version);
        wp_register_script_module('pons-handoff-state', get_stylesheet_directory_uri() . '/assets/js/handoff-state.js', array(), $version);
        wp_enqueue_script_module('pons-handoff', get_stylesheet_directory_uri() . '/assets/js/handoff.js', array('pons-handoff-state'), $version);
        wp_localize_script('pons-slider', 'ponsSliderLabels', array(
            'pause' => pons_text(__('Metti in pausa lo slider', 'ponsenergiasolare'), 'slider-pause'),
            'play' => pons_text(__('Avvia lo slider', 'ponsenergiasolare'), 'slider-play'),
        ));
    }
}, 30);


add_filter('nav_menu_link_attributes', static function ($atts) {
    if (!empty($atts['href']) && strpos($atts['href'], '#') === 0) { $atts['href'] = pons_home() . $atts['href']; }
    return $atts;
});

// Expand the parent's one organization entity with canonical CMS contacts/services.
add_filter('ticinoweb_seo_jsonld_org_schema', static function ($schema) {
    $contact = pons_contacts();
    foreach (array('phone' => 'telephone', 'email' => 'email') as $key => $property) {
        if ($contact[$key]) { $schema[$property] = $contact[$key]; } else { unset($schema[$property]); }
    }
    if ($contact['address']) { $schema['address'] = array('@type' => 'PostalAddress', 'streetAddress' => $contact['address']); } else { unset($schema['address']); }
    $offers = array();
    foreach (ticinoweb_get_services() as $service) {
        if (empty($service['title'])) { continue; }
        $offers[] = array('@type' => 'Offer', 'itemOffered' => array('@type' => 'Service', 'name' => $service['title'], 'description' => wp_strip_all_tags($service['description'] ?? '')));
    }
    if ($offers) { $schema['hasOfferCatalog'] = array('@type' => 'OfferCatalog', 'itemListElement' => $offers); }
    return $schema;
});

// Preserve the local development mail guard; the contact section uses direct links.
add_filter('pre_wp_mail', static function ($result) {
    $host = wp_parse_url(home_url('/'), PHP_URL_HOST);
    return in_array($host, array('localhost', '127.0.0.1', '::1'), true) ? false : $result;
});
