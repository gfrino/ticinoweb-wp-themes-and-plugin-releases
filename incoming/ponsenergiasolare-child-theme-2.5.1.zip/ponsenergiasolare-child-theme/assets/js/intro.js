(() => {
  'use strict';
  const root=document.documentElement,key='pons:solar-intro:'+location.pathname;
  const navigation=performance.getEntriesByType('navigation')[0]?.type;
  const reload=navigation==='reload';
  if((location.hash&&!reload)||navigation==='back_forward'||matchMedia('(prefers-reduced-motion: reduce)').matches)return;
  if(!reload){try{if(sessionStorage.getItem(key))return;sessionStorage.setItem(key,'1');}catch{return;}}
  const started=performance.now();let deadline,revealTimer,cleanupTimer,finished=false;
  const inputEvents=['keydown','pointerdown','wheel','touchstart'];
  function dismiss(){
    finished=true;clearTimeout(deadline);clearTimeout(revealTimer);clearTimeout(cleanupTimer);
    root.classList.remove('pons-intro');
    document.querySelector('.solar-intro')?.remove();
    inputEvents.forEach(name=>window.removeEventListener(name,dismiss));
  }
  function reveal(){
    if(finished)return;finished=true;
    clearTimeout(revealTimer);
    const cover=document.querySelector('.solar-intro'),sun=cover?.querySelector('.intro-sun');
    if(!cover||!sun){dismiss();return;}
    const target=document.querySelector('.solar-corner'),graphic=sun.querySelector('svg');
    cover.classList.add('is-leaving');
    if(!target||!graphic||!sun.animate){cleanupTimer=setTimeout(dismiss,400);return;}
    const from=sun.getBoundingClientRect(),to=target.getBoundingClientRect();
    const x=to.left+to.width/2-from.left-from.width/2,y=to.top+to.height/2-from.top-from.height/2;
    try{
      sun.animate([{transform:'translate3d(0,0,0) scale(1)'},{transform:`translate3d(${x}px,${y}px,0) scale(${to.width/Math.max(1,from.width)})`}],{duration:760,easing:'cubic-bezier(.22,.61,.36,1)',fill:'forwards'});
    }catch{dismiss();return;}
    cleanupTimer=setTimeout(()=>{
      if(target.isConnected){
        // Move this exact graphic into the hero. No second visible sun or opacity crossfade.
        graphic.classList.add('solar-disc','intro-shared-sun');
        target.replaceChildren(graphic);
      }
      dismiss();
    },760);
  }

  function ready(){
    if(finished)return;
    const image=document.querySelector('.solar-hero img');
    const schedule=duration=>{clearTimeout(revealTimer);revealTimer=setTimeout(reveal,Math.max(0,duration-(performance.now()-started)));};
    schedule(image&&!image.complete?1320:1050);
    if(image&&!image.complete){image.addEventListener('load',()=>{if(!finished)schedule(1050);},{once:true});image.addEventListener('error',reveal,{once:true});}
  }
  // All exits work without the footer scripts, stylesheet bundle, hero image or WebGL.
  deadline=setTimeout(dismiss,2300);
  inputEvents.forEach(name=>window.addEventListener(name,dismiss,{passive:true}));
  window.addEventListener('pageshow',event=>{if(event.persisted)dismiss();});
  window.addEventListener('resize',dismiss,{once:true,passive:true});
  document.addEventListener('visibilitychange',()=>{if(document.hidden)dismiss();});
  root.classList.add('pons-intro');
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',ready,{once:true});else ready();
})();
