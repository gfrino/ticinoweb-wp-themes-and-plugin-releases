(() => {
  'use strict';
  document.querySelectorAll('[data-services-explorer]').forEach(explorer => {
    const navigation = explorer.querySelector('.services-navigation');
    const panels = [...explorer.querySelectorAll('.service-panel')];
    const tabs = [...explorer.querySelectorAll('[data-service-select]')];
    if (!navigation || tabs.length < 2 || tabs.length !== panels.length) return;
    const section = explorer.closest('.services-section');
    const reduced = matchMedia('(prefers-reduced-motion: reduce)');
    let reflection = null;
    let active = -1;
    let light = null;
    if (section && typeof Element.prototype.animate === 'function') {
      light = document.createElement('span');
      light.className = 'services-reflection';
      light.setAttribute('aria-hidden', 'true');
      section.prepend(light);
    }
    const stopReflection = () => { reflection?.cancel(); reflection = null; };
    reduced.addEventListener('change', stopReflection);
    document.addEventListener('visibilitychange', () => { if (document.hidden) stopReflection(); });
    const reflect = () => {
      stopReflection();
      if (!light || reduced.matches || document.hidden) return;
      reflection = light.animate([
        { transform: 'translateX(-48px)', opacity: 0 },
        { opacity: .6, offset: .4 },
        { transform: 'translateX(64px)', opacity: 0 }
      ], { duration: 1550, easing: 'cubic-bezier(.2,.6,.3,1)' });
      reflection.addEventListener('finish', () => { reflection = null; }, { once: true });
    };
    navigation.setAttribute('role', 'tablist');
    const select = index => {
      if (active >= 0 && active !== index) reflect();
      active = index;
      tabs.forEach((tab, i) => {
        tab.setAttribute('role', 'tab');
        tab.setAttribute('aria-selected', String(i === index));
        tab.tabIndex = i === index ? 0 : -1;
        panels[i].hidden = i !== index;
        panels[i].setAttribute('role', 'tabpanel');
        panels[i].setAttribute('aria-labelledby', tab.id);
      });
    };
    tabs.forEach((tab, index) => {
      tab.addEventListener('click', () => select(index));
      tab.addEventListener('keydown', event => {
        let next;
        if (event.key === 'ArrowRight') next = (index + 1) % tabs.length;
        if (event.key === 'ArrowLeft') next = (index - 1 + tabs.length) % tabs.length;
        if (event.key === 'Home') next = 0;
        if (event.key === 'End') next = tabs.length - 1;
        if (next === undefined) return;
        event.preventDefault();
        select(next);
        tabs[next].focus({ preventScroll: true });
      });
    });
    select(0);
    navigation.hidden = false;
    explorer.classList.add('is-enhanced');
  });
})();
