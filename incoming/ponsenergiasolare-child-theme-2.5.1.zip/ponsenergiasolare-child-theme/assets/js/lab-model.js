/** Original illustrative architecture. Dimensions describe this model, not a client project. */
import * as T from '../vendor/three/three.module.min.js';
import {resolveLabState,solarLighting} from './lab-state.js';
export function buildSolarHouse() {
  const group=new T.Group(), structure=new T.Group(), roof=new T.Group(), panels=new T.Group(), energy=new T.Group(), outlines=new T.Group();
  group.add(structure,roof,panels,energy,outlines);
  const mat=(color,roughness=.8,metalness=0)=>new T.MeshStandardMaterial({color,roughness,metalness});
  const plaster=mat('#e8e4da'), tile=mat('#9f6550'), stone=mat('#c6c4ba'), timber=mat('#675345'), metal=mat('#535d62',.36,.65), glass=mat('#334e57',.22,.35), interior=mat('#e2d6bf');
  const roofBase=mat('#846657'), frontMat=plaster.clone(), sideMat=plaster.clone(), roofMat=roofBase.clone();
  const wire=new T.LineBasicMaterial({color:'#79909c',transparent:true,opacity:.65});
  function mesh(geo,material,parent=structure,pos=[0,0,0],rotation=[0,0,0],outline=true){
    const m=new T.Mesh(geo,material);m.position.set(...pos);m.rotation.set(...rotation);m.castShadow=true;m.receiveShadow=true;parent.add(m);
    if(outline){const e=new T.LineSegments(new T.EdgesGeometry(geo,25),wire);e.position.copy(m.position);e.rotation.copy(m.rotation);outlines.add(e);}
    return m;
  }
  const box=(size,material,parent,pos,rot,edge=true)=>mesh(new T.BoxGeometry(...size),material,parent,pos,rot,edge);
  // A shallow, bevelled architectural plinth makes ground contact readable.
  const footprint=new T.Shape();footprint.moveTo(-5.4,-4);footprint.lineTo(5.4,-4);footprint.lineTo(5.4,4);footprint.lineTo(-5.4,4);footprint.closePath();
  const base=mesh(new T.ExtrudeGeometry(footprint,{depth:.16,bevelEnabled:true,bevelThickness:.06,bevelSize:.08,bevelSegments:2,steps:1}),stone,structure,[0,.05,0],[-Math.PI/2,0,0],false);
  box([8,.12,5],interior,structure,[0,.2,0]);
  box([8,3.05,.18],plaster,structure,[0,1.8,-2.5]);
  // Front wall contains real apertures, rather than windows painted on a solid box.
  const wallShape=new T.Shape();wallShape.moveTo(-4,0);wallShape.lineTo(4,0);wallShape.lineTo(4,3.2);wallShape.lineTo(-4,3.2);wallShape.closePath();
  const apertures=[[-2.6,.95,1.7,1.5],[-.35,0,1.05,2.35],[2.2,.95,1.75,1.5]];
  for(const [x,y,w,h] of apertures){const hole=new T.Path();hole.moveTo(x-w/2,y);hole.lineTo(x-w/2,y+h);hole.lineTo(x+w/2,y+h);hole.lineTo(x+w/2,y);hole.closePath();wallShape.holes.push(hole);}
  const front=mesh(new T.ExtrudeGeometry(wallShape,{depth:.18,bevelEnabled:false}),frontMat,structure,[0,.26,2.42]);
  const facade=new T.Group();structure.add(facade);
  for(const [x,y,w,h] of apertures){
    const isDoor=y===0;
    box([w-.06,h-.06,.035],isDoor?timber:glass,facade,[x,.26+y+h/2,2.48]);
    for(const sign of [-1,1]) box([.065,h+.06,.15],timber,facade,[x+sign*w/2,.26+y+h/2,2.55]);
    box([w+.08,.065,.15],timber,facade,[x,.26+y+h,2.55]);
    if(!isDoor){box([w+.16,.08,.3],stone,facade,[x,.26+y,2.57]);box([.045,h,.07],timber,facade,[x,.26+y+h/2,2.58]);}
    else box([.025,.16,.035],metal,facade,[x+.32,1.35,2.52],undefined,false);
  }
  for(const sign of [-1,1]){
    const gable=new T.Shape();gable.moveTo(-2.5,0);gable.lineTo(2.5,0);gable.lineTo(2.5,3.2);gable.lineTo(0,5.0);gable.lineTo(-2.5,3.2);gable.closePath();
    mesh(new T.ExtrudeGeometry(gable,{depth:.16,bevelEnabled:false}),sign===1?sideMat:plaster,structure,[sign*4,.26,0],[0,Math.PI/2,0]);
    box([.25,.12,5.5],stone,structure,[sign*4, .27,0]);
  }
  const slope=Math.atan2(1.8,2.85), length=Math.hypot(1.8,2.85), roofPlanes=[];
  for(const sign of [-1,1]){
    const plane=new T.Group();plane.position.set(0,4.36,sign*1.425);plane.rotation.x=sign*slope;roof.add(plane);roofPlanes.push(plane);
    box([8.7,.12,length],roofMat,plane,[0,0,0],undefined,false);
    const rows=9,cols=25,geo=new T.BoxGeometry(8.7/cols-.009,.055,length/rows+.035);
    const tiles=new T.InstancedMesh(geo,tile,rows*cols);tiles.castShadow=true;tiles.receiveShadow=true;
    const d=new T.Object3D();let i=0;
    for(let row=0;row<rows;row++)for(let col=0;col<cols;col++){
      d.position.set(-4.35+(col+.5)*8.7/cols,.09+((row%2)*.002),-length/2+(row+.5)*length/rows);d.updateMatrix();tiles.setMatrixAt(i,d.matrix);
      const c=new T.Color('#a56b52');c.multiplyScalar(.9+((col*13+row*7)%17)/100);tiles.setColorAt(i++,c);
    }
    plane.add(tiles);plane.userData.tiles=tiles;
    const edge=new T.LineSegments(new T.EdgesGeometry(new T.BoxGeometry(8.7,.14,length)),wire);edge.position.copy(plane.position);edge.rotation.copy(plane.rotation);outlines.add(edge);
    // Thin eaves, gutter and downpipe anchor the roof in believable construction.
    const z=sign*2.85;
    box([8.75,.11,.12],timber,structure,[0,3.46,z]);
    const gutter=mesh(new T.CylinderGeometry(.065,.065,8.7,10),metal,structure,[0,3.4,z+.04*sign],[0,0,Math.PI/2],false);
  }
  mesh(new T.CylinderGeometry(.055,.055,3.15,10),metal,structure,[3.9,1.85,2.88],undefined,false);
  box([.52,.75,.6],stone,roof,[-2.8,5.05,-.65]);box([.66,.09,.72],metal,roof,[-2.8,5.47,-.65]);
  // The array follows the south roof plane exactly; every module has its own frame.
  const cell=new T.MeshPhysicalMaterial({color:'#163347',roughness:.25,metalness:.45,clearcoat:.55,clearcoatRoughness:.18});
  const mounting=new T.Group();mounting.position.copy(roofPlanes[1].position);mounting.rotation.copy(roofPlanes[1].rotation);group.add(mounting);
  for(const z of [-1.17,-.28,.28,1.17]){
    box([7.65,.055,.065],metal,mounting,[0,.145,z],undefined,false);
    for(const x of [-3.48,-1.62,.24,2.10,3.48]){
      box([.045,.13,.11],metal,mounting,[x,.12,z],undefined,false);
      box([.105,.035,.10],metal,mounting,[x,.22,z],undefined,false);
    }
  }
  const cellGrid=new T.LineBasicMaterial({color:'#768e9b',transparent:true,opacity:.37});
  for(let row=0;row<2;row++)for(let col=0;col<4;col++){
    const module=new T.Group();module.position.set(-2.8+col*1.86,4.36,1.425);module.rotation.x=slope;
    // Coordinates on the roof local plane, with clearance for tile and rails.
    const z=(row-.5)*1.43;module.position.add(new T.Vector3(0,.20,z).applyAxisAngle(new T.Vector3(1,0,0),slope));
    box([1.75,.075,1.32],metal,module,[0,0,0],undefined,false);
    box([1.68,.012,1.25],cell,module,[0,.044,0],undefined,false);
    const lines=[];
    for(let k=1;k<12;k++){const x=-.84+k*1.68/12;lines.push(x,.052,-.625,x,.052,.625);}
    for(let k=1;k<6;k++){const q=-.625+k*1.25/6;lines.push(-.84,.052,q,.84,.052,q);}
    const geometry=new T.BufferGeometry();geometry.setAttribute('position',new T.Float32BufferAttribute(lines,3));module.add(new T.LineSegments(geometry,cellGrid));
    panels.add(module);
  }
  const sample=panels.children[5],sampleRest=sample.position.clone();
  const sampleGuide=new T.Group();group.add(sampleGuide);
  for(const x of [-.7,.7]){
    const points=[new T.Vector3(x,-.08,0),new T.Vector3(x,-1.02,0)];
    const line=new T.Line(new T.BufferGeometry().setFromPoints(points),new T.LineDashedMaterial({color:'#8d7751',dashSize:.08,gapSize:.06}));line.computeLineDistances();sampleGuide.add(line);
  }
  sampleGuide.visible=false;
  // Inverter and schematic energy path become visible in the cutaway.
  const equipment=new T.Group();equipment.position.z=-.06;structure.add(equipment);
  box([.70,.94,.24],mat('#b5c2c4',.45),equipment,[2.2,1.75,-2.23]);
  box([.45,.17,.035],mat('#223338',.28),equipment,[2.2,1.94,-2.08]);
  for(let i=0;i<6;i++)box([.018,.38,.025],metal,equipment,[2.01+i*.075,1.60,-2.09],undefined,false);
  box([.22,.3,.14],mat('#d8dad4'),equipment,[2.82,1.65,-2.23]);
  box([.07,.1,.03],mat('#733f31'),equipment,[2.82,1.65,-2.14],undefined,false);
  for(const x of [2.02,2.36])mesh(new T.CylinderGeometry(.025,.025,.32,8),metal,equipment,[x,1.13,-2.2],undefined,false);
  box([.055,.055,.025],mat('#ffb800'),equipment,[2.39,1.56,-2.08],undefined,false);
  const amber=new T.MeshBasicMaterial({color:'#ffb800'});
  const paths=[[[2.8,4.36,1.5],[3.3,3.75,1.0],[3.3,2.65,-2.14],[2.2,2.65,-2.14],[2.2,1.75,-2.14]],[[2.2,1.3,-2.14],[2.2,.55,-2.14],[1.6,.55,-1.5],[.5,.55,.9],[-1,.55,.9]]];
  const curves=paths.map(points=>new T.CatmullRomCurve3(points.map(p=>new T.Vector3(...p)),false,'catmullrom',.15));
  const routes=curves.map((curve,i)=>mesh(new T.TubeGeometry(curve,40,.025,6,false),new T.MeshBasicMaterial({color:i===0?'#a97500':'#356a70',transparent:true,opacity:.9}),energy,undefined,undefined,false));
  const pulses=[];for(let k=0;k<6;k++){const dot=mesh(new T.SphereGeometry(.055,8,6),k%2===0?amber:new T.MeshBasicMaterial({color:'#457f86'}),energy,undefined,undefined,false);dot.castShadow=false;dot.receiveShadow=false;pulses.push(dot);}

  // A light roof footprint is the only annotation before modules are introduced.
  const guide=new T.LineSegments(new T.EdgesGeometry(new T.BoxGeometry(7.6,.02,2.9)),new T.LineBasicMaterial({color:'#c99a2d',transparent:true,opacity:.65}));guide.position.set(0,4.54,1.425);guide.rotation.x=slope;group.add(guide);
  const surfaces=[];structure.traverse(o=>{if(o.isMesh&&!o.isInstancedMesh)surfaces.push(o);});roof.traverse(o=>{if(o.isMesh&&!o.isInstancedMesh)surfaces.push(o);});panels.traverse(o=>{if(o.isMesh)surfaces.push(o);});
  const originals=new Map(surfaces.map(m=>[m,m.material]));
  const blueprint=new T.MeshBasicMaterial({color:'#e5edf0',transparent:true,opacity:.22,depthWrite:false});
  let currentState={};
  const anchors=[new T.Vector3(0,4.7,1.6),new T.Vector3(2.2,1.9,-2.14),new T.Vector3(-1,.6,.9),new T.Vector3(-1,4.8,1.1)];
  const pickables={roof:roof,modules:panels,inverter:equipment,building:structure};
  function apply(input){
    currentState=resolveLabState(input);
    const {phase,blueprint:plan,exploded,selected}=currentState;
    sample.position.copy(sampleRest);if(exploded){sample.position.add(new T.Vector3(-1.45,1.45,.9));}
    sampleGuide.children.forEach((line,i)=>{
      const x=i===0?-.7:.7;
      line.geometry.setFromPoints([sample.position.clone().add(new T.Vector3(x,-.08,0)),sampleRest.clone().add(new T.Vector3(x,-.08,0))]);line.computeLineDistances();
    });
    sampleGuide.visible=exploded;mounting.visible=phase>0&&!plan;
    anchors[0].copy(exploded?sample.position:new T.Vector3(0,4.7,1.6));
    cell.envMapIntensity=selected==='modules'?1.5:1;
    routes[0].visible=selected!=='building';routes[1].visible=selected!=='modules';
    panels.visible=phase>0;energy.visible=phase===2&&solarLighting(currentState.light).production>0;equipment.visible=phase===2;guide.visible=phase===0;outlines.visible=plan;
    for(const m of surfaces)m.material=plan?blueprint:originals.get(m);
    roofPlanes.forEach(p=>{p.userData.tiles.visible=!plan&&phase!==2;});
    frontMat.transparent=phase===2;frontMat.opacity=phase===2?.10:1;frontMat.depthWrite=phase!==2;
    roofMat.transparent=phase===2;roofMat.opacity=phase===2?.12:1;roofMat.depthWrite=phase!==2;
    facade.visible=phase!==2;front.visible=phase!==2;
    sideMat.transparent=phase===2;sideMat.opacity=phase===2?.10:1;sideMat.depthWrite=phase!==2;
    // In blueprint mode a section still removes the foreground roof for legibility.
    roof.visible=!plan||phase!==2;
  }
  function animate(time){pulses.forEach((dot,i)=>{const c=curves[i%curves.length];dot.visible=routes[i%2].visible;dot.position.copy(c.getPointAt(((time*.16+i/3)%1+1)%1));});}
  apply({phase:0,blueprint:false});
  return {group,panels,roof,front,energy,outlines,apply,animate,anchors,sample,mounting,routes,pickables};
}
