/** Reversible scroll geometry, independent of scroll direction or frame rate. */
const clamp=value=>Math.min(1,Math.max(0,Number.isFinite(value)?value:0));
const smooth=value=>value*value*(3-2*value);
export function handoffState({scroll=0,run=0,panelTop=0,viewport=0,header=0,mobile=false}={}) {
  const progress=run>0?clamp(scroll/run):0,settled=smooth(progress);
  const arrival=smooth(clamp((viewport-panelTop)/Math.max(1,viewport-header)*1.5));
  return {progress,scale:1-(mobile?.09:.22)*settled,radius:(mobile?16:28)*settled,
    inset:(mobile?8:28)*(1-arrival),panelRadius:(mobile?20:30)*(1-arrival),turn:-12+150*progress,pause:progress>.025};
}

/** Full overlap keeps the hero pinned until the incoming surface reaches the header. */
export function handoffLayout({heroHeight,viewport,header,mobile=false}) {
  const available=Math.max(1,viewport-header);
  return {run:heroHeight+available*(mobile?.06:.10),overlap:heroHeight};
}
