import {entryLayout,entryState} from 'pons-lab-entry-state';
const lab=document.querySelector('.solar-lab-section'),method=lab?.previousElementSibling;
if(lab&&method?.matches('.method-section')&&CSS.supports('overflow','clip')&&'ResizeObserver' in window){
  const wrapper=document.createElement('div'),track=document.createElement('div'),tail=document.createElement('div');
  wrapper.className='lab-entry';track.className='lab-entry-track';tail.className='lab-entry-tail';tail.setAttribute('aria-hidden','true');
  method.before(wrapper);wrapper.append(track,lab,tail);track.append(method);
  const reduced=matchMedia('(prefers-reduced-motion: reduce)');
  let frame=0,dirty=true,geometry,header=0,lastTop=null,preferenceFrame=0,currentReduced=reduced.matches;
  const schedule=()=>{if(!frame&&!document.hidden)frame=requestAnimationFrame(paint);};
  function measure(){
    header=document.querySelector('.site-header')?.getBoundingClientRect().bottom||0;
    const height=method.getBoundingClientRect().height;
    geometry=entryLayout({height,viewport:innerHeight,header,width:innerWidth});
    wrapper.style.setProperty('--entry-method-height',`${height}px`);
    wrapper.style.setProperty('--entry-top',`${header}px`);
    wrapper.style.setProperty('--entry-run',`${geometry.run}px`);
    wrapper.style.setProperty('--entry-pin',`${geometry.pin}px`);
    wrapper.style.setProperty('--entry-offset',`${geometry.offset}px`);
    dirty=false;
  }
  function paint(){
    frame=0;
    // Media styles may settle before their change event; retain the last reading position.
    if(reduced.matches!==currentReduced)return;
    if(dirty)measure();
    if(reduced.matches){lastTop=lab.getBoundingClientRect().top;return;}
    const state=entryState({scroll:geometry.pin-track.getBoundingClientRect().top,run:geometry.run,width:innerWidth});
    lastTop=lab.getBoundingClientRect().top;
    for(const key of ['x','feather'])wrapper.style.setProperty(`--entry-${key}`,`${state[key]}px`);
    wrapper.dataset.entryProgress=state.progress.toFixed(4);
    wrapper.classList.toggle('is-travelling',state.progress>0&&state.progress<1);
  }
  function preference(){
    const before=lastTop??lab.getBoundingClientRect().top;
    const keep=before<innerHeight&&before+lab.offsetHeight>header;
    currentReduced=reduced.matches;
    if(currentReduced)wrapper.classList.remove('is-travelling');
    wrapper.classList.toggle('is-enabled',!reduced.matches);dirty=true;paint();
    cancelAnimationFrame(preferenceFrame);
    preferenceFrame=requestAnimationFrame(()=>{preferenceFrame=requestAnimationFrame(()=>{preferenceFrame=requestAnimationFrame(()=>{
      if(keep)window.scrollBy({top:lab.getBoundingClientRect().top-before,behavior:'instant'});
      schedule();
    });});});
  }
  window.addEventListener('scroll',schedule,{passive:true});
  window.addEventListener('resize',()=>{dirty=true;schedule();},{passive:true});
  document.addEventListener('visibilitychange',()=>{if(document.hidden){cancelAnimationFrame(frame);frame=0;}else schedule();});
  reduced.addEventListener('change',preference);
  const observer=new ResizeObserver(()=>{dirty=true;schedule();});observer.observe(method);
  const masthead=document.querySelector('.site-header');if(masthead)observer.observe(masthead);
  lab.addEventListener('focusin',()=>{
    if(!reduced.matches&&Number(wrapper.dataset.entryProgress)<1){
      window.scrollTo({top:Math.ceil(scrollY+track.getBoundingClientRect().top-geometry.pin+geometry.run),behavior:'instant'});paint();
    }
  });
  // Reveal reverse-Tab destinations once, after native focus scrolling has settled.
  method.addEventListener('focusin',event=>{
    const target=event.target;
    requestAnimationFrame(()=>{
      if(reduced.matches||document.activeElement!==target)return;
      measure();
      if(Number(wrapper.dataset.entryProgress)>0){
        const reveal=Math.min(track.getBoundingClientRect().top-geometry.pin,target.getBoundingClientRect().top-header-24);
        window.scrollBy({top:Math.floor(reveal),behavior:'instant'});schedule();
      }
    });
  });
  preference();
  // Resolve the destination after both page transitions have settled their layout.
  function anchor(){
    if(reduced.matches||!location.hash)return;
    let target;try{target=document.getElementById(decodeURIComponent(location.hash.slice(1)));}catch{return;}
    if(target&&lab.contains(target)){
      measure();
      const inside=target.getBoundingClientRect().top-lab.getBoundingClientRect().top;
      window.scrollTo({top:Math.ceil(scrollY+track.getBoundingClientRect().top-geometry.pin+geometry.run+inside),behavior:'instant'});
      paint();
    }else if(target&&method.contains(target)){
      measure();
      const inside=target.getBoundingClientRect().top-method.getBoundingClientRect().top;
      window.scrollTo({top:Math.ceil(scrollY+track.getBoundingClientRect().top-header+inside),behavior:'instant'});
      paint();
    }
  }
  window.addEventListener('hashchange',()=>requestAnimationFrame(()=>anchor()));
  document.addEventListener('pons:anchor-ready',()=>anchor());
  // A repeated activation of the same fragment does not emit hashchange.
  document.addEventListener('click',event=>{
    if(reduced.matches||event.defaultPrevented||event.button!==0||event.metaKey||event.ctrlKey||event.shiftKey||event.altKey)return;
    const link=event.target.closest('a[href]');if(!link||link.target||link.hasAttribute('download'))return;
    const url=new URL(link.href,location.href);
    if(url.origin!==location.origin||url.pathname!==location.pathname||url.search!==location.search||!url.hash||url.hash!==location.hash)return;
    let target;try{target=document.getElementById(decodeURIComponent(url.hash.slice(1)));}catch{return;}
    if(target&&(lab.contains(target)||method.contains(target))){event.preventDefault();anchor();}
  });
}
