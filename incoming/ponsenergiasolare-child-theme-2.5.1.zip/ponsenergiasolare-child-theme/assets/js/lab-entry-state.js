export function entryLayout({height,viewport,header,width}){
  const available=Math.max(1,viewport-header);
  const pin=Math.min(header,viewport-height);
  const run=Math.max(320,available*(width<781?.7:.95));
  return {pin,run,offset:run+header-pin};
}
export function entryState({scroll,run,width}){
  const progress=Math.min(1,Math.max(0,scroll/Math.max(1,run)));
  const eased=progress*progress*(3-2*progress);
  const remaining=1-eased;
  const edge=Math.min(140,width*.12);
  return {progress,x:remaining*(width+edge),y:0,feather:edge*Math.min(1,remaining*5)};
}
