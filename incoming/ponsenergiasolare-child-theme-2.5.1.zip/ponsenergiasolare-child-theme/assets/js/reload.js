(() => {
  'use strict';
  // A refresh starts a new visit. Direct links and Back/Forward keep their destination.
  if (performance.getEntriesByType('navigation')[0]?.type !== 'reload') return;
  const previousRestoration = history.scrollRestoration;
  history.scrollRestoration = 'manual';
  if (location.hash) history.replaceState(history.state, '', location.pathname + location.search);
  window.scrollTo({top: 0, left: 0, behavior: 'instant'});
  let interacted = false;
  const input = () => { interacted = true; };
  const events = ['wheel', 'touchstart', 'pointerdown', 'keydown'];
  events.forEach(name => window.addEventListener(name, input, {passive: true}));
  window.addEventListener('load', async () => {
    try {
      await document.fonts?.ready;
      for (let i = 0; i < 4; i++) await new Promise(requestAnimationFrame);
      if (!interacted && !location.hash) window.scrollTo({top: 0, left: 0, behavior: 'instant'});
    } finally {
      events.forEach(name => window.removeEventListener(name, input));
      history.scrollRestoration = previousRestoration;
    }
  }, {once: true});
})();
