(() => {
  'use strict';
  document.querySelectorAll('[data-solar-slider]').forEach(root => {
    const header=document.querySelector('.site-header');
    const measureHeader=()=>{
      const admin=document.querySelector('#wpadminbar');
      root.style.setProperty('--pons-header-height',`${Math.ceil((header?.getBoundingClientRect().height||0)+(admin?.getBoundingClientRect().height||0))}px`);
    };
    measureHeader();
    if(header&&'ResizeObserver' in window)new ResizeObserver(measureHeader).observe(header);
    window.addEventListener('resize',measureHeader,{passive:true});
    const slides=[...root.querySelectorAll('[data-solar-slide]')];
    const rotation=root.querySelector('[data-slider-rotation]');
    if(slides.length<2||!rotation)return;
    const ray=document.createElement('span');
    ray.className='solar-slide-ray';ray.setAttribute('aria-hidden','true');root.append(ray);
    let transition=null,transitionTimer;
    const finishTransition=()=>{
      clearTimeout(transitionTimer);
      if(!transition)return;
      transition.outgoing.classList.remove('is-outgoing');
      transition.incoming.classList.remove('is-entering');
      root.classList.remove('is-switching');transition=null;
    };
    root.addEventListener('animationend',event=>{if(event.animationName==='solar-photo-reveal')finishTransition();});
    const nextButton=root.querySelector('[data-slider-accessible-next]');
    const reduced=matchMedia('(prefers-reduced-motion: reduce)');
    let current=0,userPaused=false,focusPaused=false,hovered=false,visible=true,handoffPaused=false,timer;
    const sync=()=>{
      if(reduced.matches&&document.activeElement===rotation){
        const target=slides[current].querySelector('a')||root;
        if(target===root)root.tabIndex=-1;
        target.focus({preventScroll:true});
      }
      rotation.hidden=reduced.matches;
      const paused=userPaused||focusPaused;
      rotation.setAttribute('aria-pressed',String(paused));
      const label=paused?ponsSliderLabels.play:ponsSliderLabels.pause;
      rotation.setAttribute('aria-label',label);rotation.querySelector('span').textContent=label;
    };
    const schedule=()=>{
      clearTimeout(timer);
      if(reduced.matches||handoffPaused||!visible||document.hidden||focusPaused)finishTransition();
      const rotating=!userPaused&&!focusPaused&&!hovered&&!handoffPaused&&visible&&!document.hidden&&!reduced.matches;
      root.classList.toggle('is-rotating',rotating);
      if(rotating){
        // Warm only the next CMS image at its existing low fetch priority.
        const image=slides[(current+1)%slides.length].querySelector('img');
        if(image)image.loading='eager';
        timer=setTimeout(()=>advance(),5200);
      }
      sync();
    };
    const advance=(manual=false)=>{
      if(transition)return;
      if(manual){userPaused=true;focusPaused=false;}
      const outgoing=slides[current];
      current=(current+1)%slides.length;
      const incoming=slides[current];
      if(!reduced.matches&&!document.hidden&&visible&&!handoffPaused){
        transition={outgoing,incoming};
        outgoing.classList.add('is-outgoing');incoming.classList.add('is-entering');
        root.style.setProperty('--solar-ray-distance',`${root.clientWidth}px`);
        root.classList.add('is-switching');
        // End events may be skipped by backgrounding or stylesheet interruption.
        transitionTimer=setTimeout(finishTransition,650);
      }
      slides.forEach((slide,i)=>{
        const active=i===current;
        slide.classList.toggle('is-active',active);slide.setAttribute('aria-hidden',String(!active));slide.inert=!active;
      });
      schedule();
    };
    nextButton.hidden=false;
    nextButton.addEventListener('click',()=>advance(true));
    rotation.hidden=false;
    rotation.addEventListener('click',()=>{finishTransition();userPaused=!(userPaused||focusPaused);focusPaused=false;schedule();});
    root.addEventListener('focusin',()=>{focusPaused=true;schedule();});
    root.addEventListener('focusout',()=>queueMicrotask(()=>{if(!root.contains(document.activeElement)){focusPaused=false;schedule();}}));
    root.querySelectorAll('.solar-cta').forEach(link=>{
      link.addEventListener('mouseenter',()=>{hovered=true;schedule();});
      link.addEventListener('mouseleave',()=>{hovered=false;schedule();});
    });
    root.addEventListener('pons:hero-handoff',event=>{handoffPaused=!!event.detail?.paused;schedule();});
    document.addEventListener('visibilitychange',schedule);reduced.addEventListener('change',schedule);
    if('IntersectionObserver' in window)new IntersectionObserver(entries=>{visible=entries[0].isIntersecting;schedule();},{threshold:.1}).observe(root);
    schedule();
  });
})();
