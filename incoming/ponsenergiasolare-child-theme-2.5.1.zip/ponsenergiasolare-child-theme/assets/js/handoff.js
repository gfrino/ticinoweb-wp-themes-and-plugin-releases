import {handoffState,handoffLayout} from 'pons-handoff-state';

const hero=document.querySelector('[data-solar-slider]'),panel=document.querySelector('#soluzioni');
if(hero&&panel&&hero.nextElementSibling===panel&&!hero.closest('.solar-handoff')){
  const wrapper=document.createElement('div'),track=document.createElement('div'),pin=document.createElement('div'),sun=document.createElement('span');
  wrapper.className='solar-handoff';track.className='solar-handoff-track';pin.className='solar-handoff-pin';sun.className='solar-disc solar-handoff-sun';sun.setAttribute('aria-hidden','true');
  hero.before(wrapper);wrapper.append(track,panel);track.append(pin);pin.append(sun,hero);
  const reduced=matchMedia('(prefers-reduced-motion: reduce)'),narrow=matchMedia('(max-width:780px)');
  let frame=0,measureNeeded=true,run=0,header=0,mobile=false,lastPause=false,enabled=false,lastPanelTop=null,preferenceFrame=0;
  const pause=value=>{if(value!==lastPause){lastPause=value;hero.dispatchEvent(new CustomEvent('pons:hero-handoff',{detail:{paused:value}}));}};
  function measure(){
    header=parseFloat(getComputedStyle(hero).getPropertyValue('--pons-header-height'))||95;
    const before=panel.getBoundingClientRect().top,wasEnabled=wrapper.classList.contains('is-enabled');
    const height=hero.offsetHeight,available=Math.max(1,innerHeight-header);mobile=narrow.matches;
    // A tall/zoomed hero must remain ordinary document flow so every CTA is reachable.
    enabled=!reduced.matches&&height<=available+2;
    wrapper.classList.toggle('is-enabled',enabled);wrapper.dataset.handoffMode=enabled?'scroll':'static';
    const geometry=handoffLayout({heroHeight:height,viewport:innerHeight,header,mobile});
    run=geometry.run;
    wrapper.style.setProperty('--handoff-top',`${header}px`);
    wrapper.style.setProperty('--handoff-size',`${height}px`);
    wrapper.style.setProperty('--handoff-run',`${run}px`);
    wrapper.style.setProperty('--handoff-overlap',`${geometry.overlap}px`);
    measureNeeded=false;
    if(wasEnabled!==enabled&&before<innerHeight&&scrollY>0)window.scrollBy({top:panel.getBoundingClientRect().top-before,behavior:'instant'});
  }
  function paint(){
    frame=0;if(document.hidden||reduced.matches)return;
    if(measureNeeded)measure();
    if(!enabled){wrapper.classList.remove('is-travelling');pause(false);return;}
    const scroll=header-track.getBoundingClientRect().top;
    lastPanelTop=panel.getBoundingClientRect().top;
    const next=handoffState({scroll,run,panelTop:lastPanelTop,viewport:innerHeight,header,mobile});
    const vars={'scale':next.scale,'radius':`${next.radius}px`,'inset':`${next.inset}px`,'panel-radius':`${next.panelRadius}px`,'turn':`${next.turn}deg`};
    for(const [key,value]of Object.entries(vars))wrapper.style.setProperty(`--handoff-${key}`,value);
    wrapper.classList.toggle('is-travelling',next.progress>0&&next.progress<1);pause(next.pause);
  }
  function request(){if(!frame&&!reduced.matches&&!document.hidden)frame=requestAnimationFrame(paint);}
  const resize=()=>{measureNeeded=true;request();};
  function preference(){
    const before=lastPanelTop??panel.getBoundingClientRect().top,keepPanel=before<innerHeight;
    wrapper.classList.toggle('is-enabled',!reduced.matches);
    if(reduced.matches){cancelAnimationFrame(frame);frame=0;wrapper.classList.remove('is-travelling');pause(false);}
    else{measure();paint();}
    cancelAnimationFrame(preferenceFrame);
    preferenceFrame=requestAnimationFrame(()=>{preferenceFrame=requestAnimationFrame(()=>{
      // Media/layout changes settle before preserving the visible content position.
      if(keepPanel)window.scrollBy({top:panel.getBoundingClientRect().top-before,behavior:'instant'});
      lastPanelTop=panel.getBoundingClientRect().top;request();
    });});
  }
  window.addEventListener('scroll',request,{passive:true});window.addEventListener('resize',resize,{passive:true});
  document.addEventListener('visibilitychange',()=>{if(document.hidden){cancelAnimationFrame(frame);frame=0;}else request();});
  reduced.addEventListener('change',preference);narrow.addEventListener('change',resize);
  const observer=new ResizeObserver(resize);observer.observe(hero);
  const headerElement=document.querySelector('.site-header');if(headerElement)observer.observe(headerElement);
  hero.addEventListener('focusin',event=>{
    if(!reduced.matches&&lastPause&&event.target.matches(':focus-visible'))window.scrollTo({top:Math.max(0,track.getBoundingClientRect().top+scrollY-header),behavior:'instant'});
  });
  preference();
}
