/* The process progresses on approach; it never changes the pinned laboratory geometry. */
function ponsMethodProgress(top, viewport, header) {
  if(viewport<=header)return top<=header?1:0;
  const distance=Math.max(1,(viewport*.77-header)*.75);
  return Math.min(1,Math.max(0,(viewport*.55-top)/distance));
}
function ponsMethodPhase(top, viewport, header) {
  return Math.min(3,Math.floor(ponsMethodProgress(top,viewport,header)*3+1e-8));
}
document.querySelectorAll('.method-section').forEach(section=>{
  const steps=[...section.querySelectorAll('.method-step')];
  if(steps.length!==4||!section.querySelector('.method-drawing'))return;
  const reduced=matchMedia('(prefers-reduced-motion: reduce)');
  let frame=0,active=-1,override=null,lastProgress=-1;
  const paint=()=>{
    frame=0;
    const anchor=section.closest('.lab-entry-track')||section;
    const header=document.querySelector('.site-header')?.getBoundingClientRect().bottom||0;
    const progress=override!==null?override/3:(reduced.matches?1:ponsMethodProgress(anchor.getBoundingClientRect().top,innerHeight,header));
    const phase=Math.min(3,Math.floor(progress*3+1e-8));
    section.classList.toggle('is-scroll-driven',override===null&&!reduced.matches);
    if(lastProgress!==progress){
      lastProgress=progress;
      const stage=progress*3,clamp=value=>Math.max(0,Math.min(1,value));
      section.style.setProperty('--method-progress',String(progress));
      section.style.setProperty('--method-survey',String(clamp(1-stage)));
      section.style.setProperty('--method-plan',String(clamp(1-Math.abs(stage-1))));
      section.style.setProperty('--method-panels',String(clamp(stage-1)));
      section.style.setProperty('--method-powered',String(clamp(stage-2)));
    }
    if(active===phase)return;active=phase;
    section.dataset.methodPhase=String(phase);
    steps.forEach((step,i)=>{
      step.classList.toggle('is-current',i===phase);step.classList.toggle('is-complete',i<=phase);
      step.querySelector('button')?.setAttribute('aria-pressed',String(i===phase));
    });
  };
  const schedule=()=>{if(!frame&&!document.hidden)frame=requestAnimationFrame(paint);};
  steps.forEach((step,i)=>{
    const title=step.querySelector('h3');if(!title)return;
    const button=document.createElement('button');button.type='button';button.className='method-select';
    while(title.firstChild)button.append(title.firstChild);title.append(button);
    button.setAttribute('aria-pressed','false');
    button.addEventListener('click',()=>{override=i;paint();});
    step.addEventListener('pointerenter',event=>{if(event.pointerType==='mouse'){override=i;paint();}});
    button.addEventListener('focus',()=>{override=i;paint();});
  });
  section.addEventListener('pointerleave',()=>{if(!section.contains(document.activeElement)){override=null;schedule();}});
  section.addEventListener('focusout',event=>{if(!section.contains(event.relatedTarget)){override=null;schedule();}});
  window.addEventListener('scroll',()=>{override=null;schedule();},{passive:true});
  window.addEventListener('resize',schedule,{passive:true});
  document.addEventListener('visibilitychange',()=>{if(document.hidden){cancelAnimationFrame(frame);frame=0;}else schedule();});
  reduced.addEventListener('change',schedule);paint();
});
