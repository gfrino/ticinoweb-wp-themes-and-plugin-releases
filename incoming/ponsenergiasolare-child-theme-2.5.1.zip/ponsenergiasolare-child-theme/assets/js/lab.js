(() => {
  'use strict';
  document.querySelectorAll('[data-solar-lab]').forEach(root=>{
    const layout=root.closest('.lab-layout');if(!layout)return;
    const copies=[...layout.querySelectorAll('.lab-phase-copy')];
    const phases=[...root.querySelectorAll('[data-lab-phase]')];
    if(copies.length!==3||phases.length!==3)return;
    const state={phase:0,blueprint:false,light:-25,motion:true,selected:null,exploded:false};let scene,started=false;
    const status=root.querySelector('[data-lab-status]');
    const update=()=>{
      copies.forEach((copy,i)=>{copy.hidden=i!==state.phase;});
      phases.forEach((button,i)=>button.setAttribute('aria-pressed',String(i===state.phase)));
      root.querySelectorAll('[data-lab-view]').forEach(button=>button.setAttribute('aria-pressed',String((button.dataset.labView==='blueprint')===state.blueprint)));
      root.dataset.phase=String(state.phase);
      root.querySelector('[data-lab-light]').disabled=state.blueprint;
      root.querySelector('[data-lab-light-help]').hidden=!state.blueprint;
      const flow=root.querySelector('[data-lab-flow]');
      flow.hidden=state.phase!==2||!root.classList.contains('has-webgl')||matchMedia('(prefers-reduced-motion: reduce)').matches;
      flow.setAttribute('aria-pressed',String(!state.motion));
      flow.textContent=state.motion?window.ponsLabLabels.pauseFlow:window.ponsLabLabels.playFlow;
      root.querySelector('.lab-drag-hint').classList.toggle('flow-visible',!flow.hidden);
      const ready=root.classList.contains('has-webgl');
      const allowed=state.phase===0?['roof']:state.phase===1?['modules']:['modules','inverter','building'];
      if(!allowed.includes(state.selected))state.selected=null;
      if(state.phase!==1||state.blueprint)state.exploded=false;
      root.querySelectorAll('[data-lab-component]').forEach(button=>{
        button.hidden=!ready||!allowed.includes(button.dataset.labComponent);
        button.setAttribute('aria-expanded',String(button.dataset.labComponent===state.selected));
      });
      root.querySelector('[data-lab-inspector]').hidden=!ready||!state.selected;
      root.querySelectorAll('[data-lab-detail]').forEach(detail=>{detail.hidden=detail.dataset.labDetail!==state.selected;});
      const mount=root.querySelector('[data-lab-explode]');
      mount.hidden=!ready||state.phase!==1||state.blueprint;
      mount.setAttribute('aria-pressed',String(state.exploded));mount.textContent=state.exploded?ponsLabLabels.mountClose:ponsLabLabels.mount;
      root.querySelector('[data-lab-energy-key]').hidden=!ready||state.phase!==2;
      const period=state.light>=60?'evening':state.light>30?'sunset':state.light< -35?'morning':'day';
      root.querySelector('[data-lab-period]').textContent=ponsLabLabels[period];
      root.querySelector('[data-lab-night]').hidden=state.light<60||state.blueprint;
      root.querySelector('[data-lab-light]').setAttribute('aria-valuetext',ponsLabLabels[period]);
      flow.hidden=flow.hidden||state.light>=60;
      root.querySelector('.lab-drag-hint').hidden=!ready||state.phase!==0;
      scene?.setState({...state});
    };
    copies.forEach((copy,i)=>{
      copy.id=copy.id||`${root.querySelector('svg title').id}-phase-${i}`;
      const title=copy.querySelector('h3');
      if(title)phases[i].querySelector('[data-phase-label]').textContent=title.textContent;
      phases[i].setAttribute('aria-controls',copy.id);
      phases[i].addEventListener('click',()=>{state.phase=i;state.selected=null;update();});
    });
    root.querySelector('.lab-phase-nav').hidden=false;layout.classList.add('lab-enhanced');update();
    root.querySelectorAll('[data-lab-view]').forEach(button=>button.addEventListener('click',()=>{state.blueprint=button.dataset.labView==='blueprint';update();}));
    root.querySelector('[data-lab-light]').addEventListener('input',event=>{state.light=Number(event.target.value);update();});
    root.querySelectorAll('[data-lab-rotate]').forEach(button=>button.addEventListener('click',()=>scene?.rotate(Number(button.dataset.labRotate))));
    root.querySelector('[data-lab-flow]').addEventListener('click',()=>{state.motion=!state.motion;update();});
    root.querySelector('[data-lab-reset]').addEventListener('click',()=>{state.phase=0;state.blueprint=false;state.light=-25;state.motion=true;state.selected=null;state.exploded=false;root.querySelector('[data-lab-light]').value='-25';update();scene?.reset();});
    const select=key=>{state.selected=state.selected===key?null:key;update();};
    root.querySelectorAll('[data-lab-component]').forEach(button=>button.addEventListener('click',()=>select(button.dataset.labComponent)));
    root.querySelector('[data-lab-explode]').addEventListener('click',()=>{state.exploded=!state.exploded;update();});
    root.querySelector('[data-lab-close]').addEventListener('click',()=>{const previous=state.selected;state.selected=null;update();root.querySelector(`[data-lab-component="${previous}"]`)?.focus({preventScroll:true});});
    root.addEventListener('keydown',event=>{if(event.key==='Escape'&&state.selected){root.querySelector('[data-lab-close]').click();}});
    const failure=()=>{
      if(document.activeElement?.closest('[data-lab-3d-controls]')||document.activeElement===root.querySelector('[data-lab-flow]')||document.activeElement?.closest('[data-lab-inspector]')||document.activeElement===root.querySelector('[data-lab-explode]'))phases[state.phase].focus({preventScroll:true});
      root.querySelectorAll('[data-lab-label]').forEach(el=>{el.hidden=true;});
      root.classList.remove('has-webgl');root.querySelector('[data-lab-canvas]').setAttribute('aria-hidden','true');root.querySelector('[data-lab-flow]').hidden=true;root.querySelectorAll('[data-lab-3d-controls]').forEach(el=>{el.hidden=true;});
      root.querySelector('[data-lab-inspector]').hidden=true;root.querySelector('[data-lab-explode]').hidden=true;root.querySelector('[data-lab-energy-key]').hidden=true;root.querySelector('[data-lab-canvas]').replaceChildren();status.textContent=window.ponsLabLabels?.fallback||'';scene=undefined;
    };
    const start=async()=>{
      if(started)return;started=true;status.textContent=window.ponsLabLabels?.loading||'';
      try{
        const module=await import(window.ponsLabLabels.sceneUrl);
        scene=module.createScene(root,{...state},failure,select);
        root.classList.add('has-webgl');root.querySelectorAll('[data-lab-3d-controls]').forEach(el=>{el.hidden=false;});root.querySelector('[data-lab-canvas]').setAttribute('aria-hidden','false');status.textContent='';update();
      }catch{failure();}
    };
    matchMedia('(prefers-reduced-motion: reduce)').addEventListener('change',()=>{if(document.activeElement===root.querySelector('[data-lab-flow]'))phases[state.phase].focus({preventScroll:true});update();});
    if('IntersectionObserver' in window){const observer=new IntersectionObserver(entries=>{if(entries.some(e=>e.isIntersecting)){observer.disconnect();start();}},{rootMargin:'300px'});observer.observe(root);
      // Compile the scene while the preceding process is being read, before it slides into view.
      const approach=document.querySelector('.method-section');if(approach)observer.observe(approach);
    }else start();
  });
})();
