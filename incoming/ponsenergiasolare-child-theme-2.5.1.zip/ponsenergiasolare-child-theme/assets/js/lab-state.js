/** State of an educational model; never a production or yield calculation. */
export function resolveLabState(input={}) {
  const phase=[0,1,2].includes(input.phase)?input.phase:0;
  const allowed=phase===0?['roof']:phase===1?['modules']:['modules','inverter','building'];
  return {...input,phase,blueprint:!!input.blueprint,light:Number.isFinite(input.light)?Math.max(-65,Math.min(65,input.light)):-25,
    selected:allowed.includes(input.selected)?input.selected:null,exploded:phase===1&&!input.blueprint&&!!input.exploded};
}
export function solarLighting(value=-25) {
  const light=Number.isFinite(value)?Math.max(-65,Math.min(65,value)):-25;
  const dusk=Math.max(0,(light-30)/35);
  return {period:light>=60?'evening':light>30?'sunset':light< -35?'morning':'day',dusk,production:light>=60?0:1-dusk,
    azimuth:light*Math.PI/180,elevation:Math.max(.06,Math.sin((light+80)/160*Math.PI))};
}

/** Includes horizontal entry/exit; the renderer separately allows one initial warm-up draw. */
export function labViewportVisible(rect,width,height) {
  return rect.width>0&&rect.height>0&&rect.bottom>0&&rect.top<height&&rect.right>0&&rect.left<width;
}
