import * as T from '../vendor/three/three.module.min.js';
import {resolveLabState,solarLighting,labViewportVisible} from './lab-state.js';
import {buildSolarHouse} from './lab-model.js';
export function createScene(root,initial,onFailure,onSelect) {
  const viewport=root.querySelector('[data-lab-canvas]');
  const renderer=new T.WebGLRenderer({antialias:true,alpha:false,powerPreference:'low-power'});
  renderer.setPixelRatio(Math.min(devicePixelRatio,1.65));
  renderer.shadowMap.enabled=true;renderer.shadowMap.type=T.PCFShadowMap;renderer.shadowMap.autoUpdate=false;
  renderer.toneMapping=T.ACESFilmicToneMapping;renderer.toneMappingExposure=1.02;
  renderer.outputColorSpace=T.SRGBColorSpace;
  renderer.domElement.setAttribute('aria-hidden','true');viewport.append(renderer.domElement);
  const scene=new T.Scene();scene.background=new T.Color('#e8edeb');
  const camera=new T.PerspectiveCamera(35,1,.1,80);
  const model=buildSolarHouse();scene.add(model.group);
  const floor=new T.Mesh(new T.PlaneGeometry(200,200),new T.ShadowMaterial({color:'#34453d',opacity:.16}));floor.rotation.x=-Math.PI/2;floor.position.y=-.18;floor.receiveShadow=true;scene.add(floor);
  const ambient=new T.HemisphereLight('#f6f9ff','#9b9486',1.8);scene.add(ambient);
  const sun=new T.DirectionalLight('#fff3db',2.6);sun.castShadow=true;sun.shadow.mapSize.set(innerWidth<600?512:1024,innerWidth<600?512:1024);sun.shadow.camera.left=-9;sun.shadow.camera.right=9;sun.shadow.camera.top=9;sun.shadow.camera.bottom=-9;sun.shadow.camera.near=.5;sun.shadow.camera.far=40;sun.shadow.bias=-.0004;sun.shadow.normalBias=.04;sun.shadow.radius=4;sun.target.position.set(0,1.5,0);scene.add(sun,sun.target);
  const fill=new T.DirectionalLight('#e4edff',.9);fill.position.set(-6,8,-8);scene.add(fill);
  // A studio reflection environment lends the modules a restrained glass response.
  const env=new T.Scene();env.background=new T.Color('#bacbd3');
  const softbox=new T.Mesh(new T.PlaneGeometry(12,8),new T.MeshBasicMaterial({color:'#ffffff'}));softbox.position.set(-4,8,2);softbox.lookAt(0,0,0);env.add(softbox);
  const pmrem=new T.PMREMGenerator(renderer), envMap=pmrem.fromScene(env,.08,.1,30);scene.environment=envMap.texture;pmrem.dispose();softbox.geometry.dispose();softbox.material.dispose();
  const grid=new T.GridHelper(18,18,'#7f99a5','#78929d');grid.position.y=-.12;grid.material.transparent=true;grid.material.opacity=.15;grid.visible=false;scene.add(grid);
  const reduced=matchMedia('(prefers-reduced-motion: reduce)');
  let state={...initial}, yaw=.8,pitch=.54,targetYaw=.8,targetPitch=.54,visible=false,frame=0,last=0,dead=false,hasRendered=false,lastPaint=0,flowTime=1;
  const normalBg=new T.Color('#e8edeb'),planBg=new T.Color('#172e3a');
  const eveningBg=new T.Color('#aab5c2'),warmSun=new T.Color('#edb87c'),daySun=new T.Color('#fff3db');
  const targetLook=new T.Vector3(0,2.1,0),currentLook=targetLook.clone();let targetDistance=17.8,currentDistance=17.8;
  let sampleTarget=model.sample.position.clone(),sampleCurrent=sampleTarget.clone();
  const setSun=()=>{
    const light=solarLighting(state.light);sun.position.set(Math.sin(light.azimuth)*12,1+light.elevation*9,Math.cos(light.azimuth)*10);
    sun.intensity=2.6*(1-light.dusk*.93);sun.color.copy(daySun).lerp(warmSun,light.dusk);
    ambient.intensity=1.8-light.dusk*.9;fill.intensity=.9-light.dusk*.45;
    scene.environmentIntensity=1-light.dusk*.6;
    scene.background.copy(state.blueprint?planBg:normalBg.clone().lerp(eveningBg,light.dusk));
  };
  function setState(next){
    const phaseChanged=state.phase!==next.phase,selectionChanged=state.selected!==next.selected;state=resolveLabState(next);
    const previousSample=model.sample.position.clone();model.apply(state);sampleTarget.copy(model.sample.position);sampleCurrent.copy(previousSample);model.sample.position.copy(sampleCurrent);setSun();renderer.shadowMap.needsUpdate=true;
    grid.visible=state.blueprint;
    model.outlines.traverse(o=>{if(o.material)o.material.color.set(state.blueprint?'#9dbac8':'#79909c');});
    if(phaseChanged){targetYaw=state.phase===2?.3:.8;targetPitch=state.phase===2?.20:.54;if(!reduced.matches)model.panels.position.y=.22;}
    const index={modules:0,inverter:1,building:2,roof:3}[state.selected];
    targetLook.set(0,2.1,0);targetDistance=17.8;
    if(index!==undefined){targetLook.lerp(model.anchors[index],.36);targetDistance=15.4;}
    if(selectionChanged&&state.selected==='inverter'){targetYaw=.22;targetPitch=.18;}
    if(state.exploded){targetLook.y=Math.max(targetLook.y,2.8);targetDistance=18.4;}
    request();
  }
  function draw(now){
    frame=0;if(dead||(!visible&&hasRendered)||document.hidden)return;
    const dt=Math.min((now-last)/1000,.05)||.016;last=now;
    const f=reduced.matches?1:1-Math.exp(-dt*10);
    yaw+=(targetYaw-yaw)*f;pitch+=(targetPitch-pitch)*f;model.panels.position.y*=1-f;currentLook.lerp(targetLook,f);currentDistance+=(targetDistance-currentDistance)*f;sampleCurrent.lerp(sampleTarget,f);model.sample.position.copy(sampleCurrent);if(state.exploded)model.anchors[0].copy(sampleCurrent);
    const width=viewport.clientWidth,height=viewport.clientHeight;
    const distance=currentDistance+(width/height<1.05?2:0);
    const target=currentLook;camera.position.set(Math.sin(yaw)*Math.cos(pitch)*distance,Math.sin(pitch)*distance,Math.cos(yaw)*Math.cos(pitch)*distance).add(target);camera.lookAt(target);
    const moving=Math.abs(targetYaw-yaw)+Math.abs(targetPitch-pitch)+model.panels.position.y+currentLook.distanceTo(targetLook)+Math.abs(currentDistance-targetDistance)+sampleCurrent.distanceTo(sampleTarget)>.001;
    const animating=state.phase===2&&model.energy.visible&&state.motion&&!reduced.matches;
    if(!moving&&animating&&now-lastPaint<30){frame=requestAnimationFrame(draw);return;}
    if(moving)renderer.shadowMap.needsUpdate=true;
    if(animating)flowTime+=dt*solarLighting(state.light).production;
    if(state.phase===2)model.animate(flowTime);
    renderer.render(scene,camera);hasRendered=true;lastPaint=now;
    root.querySelectorAll('[data-lab-label]').forEach((label,i)=>{
      label.hidden=state.phase===0?i!==3:state.phase===1?i!==0:i===3;
      const p=model.anchors[i].clone().project(camera);
      label.style.left=`${(p.x*.5+.5)*100}%`;label.style.top=`${(-p.y*.5+.5)*100}%`;
    });
    if(moving||(state.phase===2&&model.energy.visible&&state.motion&&!reduced.matches))frame=requestAnimationFrame(draw);
    root.dataset.labRendering=frame?'active':'idle';
  }
  const inView=()=>labViewportVisible(viewport.getBoundingClientRect(),innerWidth,innerHeight);
  function request(){visible=inView();if(!dead&&!frame&&(visible||!hasRendered)&&!document.hidden){last=performance.now();frame=requestAnimationFrame(draw);}}
  const resize=new ResizeObserver(()=>{const w=viewport.clientWidth,h=viewport.clientHeight;if(w&&h){renderer.setSize(w,h,false);camera.aspect=w/h;camera.updateProjectionMatrix();request();}});resize.observe(viewport);
  const checkVisibility=()=>{visible=inView();if(visible||!hasRendered)request();else{cancelAnimationFrame(frame);frame=0;root.dataset.labRendering='suspended';}};
  const intersection=new IntersectionObserver(checkVisibility,{threshold:0});intersection.observe(root.querySelector('[data-lab-viewport]'));
  // Native group wrappers use display:contents. Also measure after scroll so an
  // anchor jump during lazy initialization cannot leave a visible canvas asleep.
  let visibilityFrame=0;
  const scroll=()=>{if(!visibilityFrame)visibilityFrame=requestAnimationFrame(()=>{visibilityFrame=0;checkVisibility();});};
  window.addEventListener('scroll',scroll,{passive:true});
  const visibility=()=>{if(document.hidden){cancelAnimationFrame(frame);frame=0;}else request();};document.addEventListener('visibilitychange',visibility);reduced.addEventListener('change',request);
  // Horizontal drag only; a vertical gesture keeps normal page scrolling on touch.
  let pointer;
  const canvas=renderer.domElement;
  canvas.addEventListener('pointerdown',event=>{if(event.button!==0)return;pointer={id:event.pointerId,x:event.clientX,y:event.clientY,yaw:targetYaw,pitch:targetPitch,locked:false};});
  canvas.addEventListener('pointermove',event=>{
    if(!pointer||pointer.id!==event.pointerId)return;
    if(event.pointerType==='mouse'&&!(event.buttons&1)){pointer=undefined;return;}
    const dx=event.clientX-pointer.x,dy=event.clientY-pointer.y;
    if(!pointer.locked){if(Math.abs(dy)>Math.abs(dx)&&Math.abs(dy)>8){pointer=undefined;return;}if(Math.abs(dx)<7)return;pointer.locked=true;canvas.setPointerCapture(event.pointerId);}
    targetYaw=T.MathUtils.clamp(pointer.yaw-dx*.006,-.6,1.5);targetPitch=T.MathUtils.clamp(pointer.pitch+dy*.003,.18,.85);request();
  });
  const raycaster=new T.Raycaster();
  const release=event=>{
    if(pointer&&!pointer.locked&&event.type==='pointerup'&&Math.hypot(event.clientX-pointer.x,event.clientY-pointer.y)<7){
      const rect=canvas.getBoundingClientRect();raycaster.setFromCamera(new T.Vector2((event.clientX-rect.left)/rect.width*2-1,-(event.clientY-rect.top)/rect.height*2+1),camera);
      const keys=state.phase===0?['roof']:state.phase===1?['modules']:['modules','inverter','building'];
      const hits=raycaster.intersectObjects(keys.map(k=>model.pickables[k]),true);
      const hit=hits.find(h=>{let o=h.object;while(o){if(!o.visible)return false;o=o.parent;}return true;});
      if(hit){let node=hit.object,key;while(node&&!key){key=keys.find(k=>model.pickables[k]===node);node=node.parent;}if(key)onSelect(key);}
    }
    pointer=undefined;
  };canvas.addEventListener('pointerup',release);canvas.addEventListener('pointercancel',release);canvas.addEventListener('lostpointercapture',release);
  const lost=event=>{event.preventDefault();dead=true;cancelAnimationFrame(frame);resize.disconnect();intersection.disconnect();cancelAnimationFrame(visibilityFrame);window.removeEventListener('scroll',scroll);document.removeEventListener('visibilitychange',visibility);reduced.removeEventListener('change',request);onFailure();};canvas.addEventListener('webglcontextlost',lost);
  setState(initial);
  return {setState,rotate(direction){targetYaw=T.MathUtils.clamp(targetYaw+direction*.25,-.6,1.5);request();},reset(){targetYaw=.8;targetPitch=.54;request();}};
}
