(() => {
 'use strict';
 const scene=document.querySelector('[data-page-scene]');
 const motion=matchMedia('(prefers-reduced-motion: reduce)');
 if(scene){
  let queued=false,extent=scene.offsetHeight;
  const paint=()=>{queued=false;scene.style.setProperty('--scene-progress',motion.matches?'0':String(Math.max(0,Math.min(1,window.scrollY/Math.max(1,extent)))));};
  const queue=()=>{if(!queued){queued=true;requestAnimationFrame(paint);}};
  addEventListener('scroll',queue,{passive:true});
  new ResizeObserver(()=>{extent=scene.offsetHeight;queue();}).observe(scene);
  motion.addEventListener('change',queue);queue();
 }
 document.querySelectorAll('[data-load-map]').forEach(button=>button.addEventListener('click',()=>{
  const panel=button.closest('[data-map-src]'),url=new URL(panel.dataset.mapSrc);
  if(url.protocol!=='https:'||url.hostname!=='maps.google.com')return;
  const frame=document.createElement('iframe');frame.title=panel.querySelector('h2').textContent;frame.src=url.href;frame.loading='lazy';frame.referrerPolicy='no-referrer';frame.allowFullscreen=true;
  frame.addEventListener('load',()=>panel.classList.add('map-loaded'),{once:true});frame.tabIndex=0;panel.append(frame);button.hidden=true;frame.focus({preventScroll:true});
 }));
})();
