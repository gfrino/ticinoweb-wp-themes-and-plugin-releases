(() => {
  'use strict';
  document.body.classList.add('js-enabled');
  const toggle = document.querySelector('.menu-toggle');
  const nav = document.querySelector('#primary-navigation');
  const compactMenu = window.matchMedia('(max-width: 1020px)');
  const pageRegions = [...document.querySelectorAll('.site-main, .document-page, .site-footer, .footer-privacy')];
  const originalInert = new Map(pageRegions.map(region => [region, region.inert]));
  const header = document.querySelector('.site-header');
  const measureMenu = () => {
    if (header) header.style.setProperty('--menu-top', `${Math.max(0, header.getBoundingClientRect().bottom)}px`);
  };
  const setMenu = (open, focus = false) => {
    if (!toggle || !nav) return;
    open = open && compactMenu.matches;
    measureMenu();
    toggle.setAttribute('aria-expanded', String(open));
    nav.classList.toggle('is-open', open);
    nav.inert = compactMenu.matches && !open;
    document.body.classList.toggle('menu-open', open);
    pageRegions.forEach(region => { region.inert = open || originalInert.get(region); });
    if (focus) toggle.focus({preventScroll: true});
  };
  setMenu(false);
  toggle?.addEventListener('click', () => setMenu(toggle.getAttribute('aria-expanded') !== 'true'));
  nav?.addEventListener('click', event => { if (event.target.closest('a')) setMenu(false, true); });
  document.addEventListener('keydown', event => {
    if (toggle?.getAttribute('aria-expanded') !== 'true') return;
    if (event.key === 'Escape') { event.preventDefault(); setMenu(false, true); }
    if (event.key === 'Tab') {
      const links = [...header.querySelectorAll('a[href], button')].filter(element => element.getClientRects().length && !element.disabled);
      const first = links[0], last = links[links.length - 1];
      if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
      else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
    }
  });
  document.addEventListener('click', event => {
    if (toggle?.getAttribute('aria-expanded') === 'true' && !event.target.closest('.site-header')) setMenu(false);
  });
  document.addEventListener('focusin', event => {
    if (toggle?.getAttribute('aria-expanded') === 'true' && !event.target.closest('.site-header')) setMenu(false, true);
  });
  compactMenu.addEventListener('change', () => {
    const focusedToggle = document.activeElement === toggle;
    setMenu(false, compactMenu.matches && nav?.contains(document.activeElement));
    if (!compactMenu.matches && focusedToggle) header?.querySelector('.brand')?.focus({preventScroll: true});
  });
  window.addEventListener('resize', measureMenu, {passive: true});

  // Open native disclosures when an anchor targets one or an element inside one.
  const revealHash = () => {
    if (!window.location.hash) return;
    let target;
    try { target = document.getElementById(decodeURIComponent(window.location.hash.slice(1))); } catch { return; }
    const details = target?.closest('details');
    if (details) details.open = true;
  };
  window.addEventListener('hashchange', revealHash);
  document.addEventListener('click', event => {
    const anchor = event.target.closest('a[href*="#"]');
    if (!anchor) return;
    const url = new URL(anchor.href, window.location.href);
    if (url.origin !== location.origin || url.pathname !== location.pathname || !url.hash) return;
    let target;
    try { target = document.getElementById(decodeURIComponent(url.hash.slice(1))); } catch { return; }
    if (target?.closest('details')) target.closest('details').open = true;
  });
  revealHash();

  // Restore a deep link once, after fonts and both scroll layouts have settled.
  // Several independent initial scroll corrections previously competed here.
  const initialHash = location.hash;
  if (initialHash) {
    let interacted = false;
    const input = () => { interacted = true; };
    const events = ['wheel', 'touchstart', 'pointerdown', 'keydown'];
    events.forEach(name => window.addEventListener(name, input, { passive: true }));
    const restore = async () => {
      await document.fonts?.ready;
      for (let i = 0; i < 4; i++) await new Promise(requestAnimationFrame);
      events.forEach(name => window.removeEventListener(name, input));
      if (interacted || location.hash !== initialHash) return;
      let target;
      try { target = document.getElementById(decodeURIComponent(initialHash.slice(1))); } catch { return; }
      if (!target) return;
      revealHash();
      target.scrollIntoView({ block: 'start', behavior: 'instant' });
      document.dispatchEvent(new CustomEvent('pons:anchor-ready'));
    };
    if (document.readyState === 'complete') restore();
    else window.addEventListener('load', restore, { once: true });
  }

  document.querySelector('.cookie-preferences')?.addEventListener('click', () => {
    // The parent removes its consent interface after a choice; reload its own UI.
    for (const name of ['tw_cookie_consent', 'tw_cookie_preferences']) document.cookie = `${name}=; Max-Age=0; path=/; SameSite=Lax`;
    window.location.reload();
  });

})();
