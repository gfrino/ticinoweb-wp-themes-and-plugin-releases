/* Progressive enhancement only. The native parent endpoint owns all submissions. */
(() => {
    'use strict';
    // A styled select-only combobox over the native field: same values, labels and validation.
    const enhanceSelect = (select) => {
        const label = select.labels?.[0];
        if (!label || select.multiple || select.size > 1) return;
        label.id ||= `${select.id}-label`;
        const wrapper = document.createElement('div');
        wrapper.className = 'quote-select';
        const trigger = document.createElement('button');
        trigger.type = 'button';
        trigger.className = 'quote-select-trigger';
        trigger.setAttribute('role', 'combobox');
        trigger.setAttribute('aria-haspopup', 'listbox');
        trigger.setAttribute('aria-expanded', 'false');
        trigger.setAttribute('aria-controls', `${select.id}-options`);
        trigger.setAttribute('aria-labelledby', `${label.id} ${select.id}-value`);
        const value = document.createElement('span');
        value.id = `${select.id}-value`;
        value.className = 'quote-select-value';
        trigger.append(value);
        const list = document.createElement('div');
        list.id = `${select.id}-options`;
        list.className = 'quote-select-options';
        list.setAttribute('role', 'listbox');
        list.setAttribute('aria-labelledby', label.id);
        list.hidden = true;
        select.before(wrapper);
        wrapper.append(select, trigger, list);
        let open = false, active = select.selectedIndex, typed = '', typeTimer;
        const options = [];
        const available = () => options.map((_, i) => i).filter(i => !select.options[i].disabled);
        const activate = (index, scroll = false) => {
            active = index;
            options.forEach((option, i) => option.classList.toggle('is-active', i === index));
            if (open && options[index]) trigger.setAttribute('aria-activedescendant', options[index].id);
            if (scroll && options[index]) options[index].scrollIntoView({block: 'nearest'});
        };
        const close = () => {
            open = false; list.hidden = true;
            trigger.setAttribute('aria-expanded', 'false');
            trigger.removeAttribute('aria-activedescendant');
            wrapper.classList.remove('is-open');
            clearTimeout(typeTimer); typed = '';
        };
        const sync = () => {
            value.textContent = select.options[select.selectedIndex]?.textContent || '';
            trigger.disabled = select.disabled;
            if (select.disabled) close();
            trigger.setAttribute('aria-required', String(select.required));
            for (const attr of ['aria-invalid', 'aria-describedby']) {
                if (select.hasAttribute(attr)) trigger.setAttribute(attr, select.getAttribute(attr));
                else trigger.removeAttribute(attr);
            }
            wrapper.classList.toggle('is-placeholder', select.value === '');
            options.forEach((option, i) => option.setAttribute('aria-selected', String(i === select.selectedIndex)));
        };
        const show = () => {
            if (select.disabled) return;
            document.dispatchEvent(new CustomEvent('pons:select-open', {detail: trigger}));
            const rect = trigger.getBoundingClientRect();
            const below = window.innerHeight - rect.bottom - 16;
            const above = rect.top - (document.querySelector('.site-header')?.getBoundingClientRect().bottom || 0) - 16;
            const upwards = below < 190 && above > below;
            wrapper.classList.toggle('opens-up', upwards);
            list.style.maxHeight = `${Math.max(96, Math.min(280, upwards ? above : below))}px`;
            open = true; list.hidden = false;
            trigger.setAttribute('aria-expanded', 'true');
            wrapper.classList.add('is-open');
            activate(available().includes(select.selectedIndex) ? select.selectedIndex : available()[0], true);
        };
        const choose = (index) => {
            if (select.disabled || !select.options[index] || select.options[index].disabled) return;
            select.selectedIndex = index;
            select.removeAttribute('aria-invalid');
            sync(); close();
            select.dispatchEvent(new Event('input', {bubbles: true}));
            select.dispatchEvent(new Event('change', {bubbles: true}));
            trigger.focus({preventScroll: true});
        };
        [...select.options].forEach((item, index) => {
            const option = document.createElement('div');
            option.className = 'quote-select-option';
            option.id = `${select.id}-option-${index}`;
            option.setAttribute('role', 'option');
            option.textContent = item.textContent;
            if (item.disabled) option.setAttribute('aria-disabled', 'true');
            option.addEventListener('mousedown', event => event.preventDefault());
            option.addEventListener('pointermove', () => { if (!item.disabled) activate(index); });
            option.addEventListener('click', () => choose(index));
            options.push(option); list.append(option);
        });
        trigger.addEventListener('click', () => open ? close() : show());
        trigger.addEventListener('keydown', (event) => {
            const keys = ['ArrowDown', 'ArrowUp', 'Home', 'End', 'Enter', ' '];
            if (event.key === 'Escape') { if (open) { event.preventDefault(); close(); } return; }
            if (event.key === 'Tab') { close(); return; }
            if (keys.includes(event.key)) {
                event.preventDefault();
                if (!open) { show(); return; }
                if (event.key === 'Enter' || event.key === ' ') { choose(active); return; }
                const valid = available(); const position = valid.indexOf(active);
                const index = event.key === 'Home' ? valid[0] : event.key === 'End' ? valid.at(-1) : valid[Math.max(0, Math.min(valid.length - 1, position + (event.key === 'ArrowDown' ? 1 : -1)))];
                activate(index, true); return;
            }
            if (event.key.length === 1 && !event.ctrlKey && !event.metaKey && !event.altKey) {
                event.preventDefault(); if (!open) show();
                clearTimeout(typeTimer); typed += event.key.toLocaleLowerCase();
                const match = available().find(i => select.options[i].textContent.trim().toLocaleLowerCase().startsWith(typed));
                if (match !== undefined) activate(match, true);
                typeTimer = setTimeout(() => { typed = ''; }, 650);
            }
        });
        label.addEventListener('click', event => { event.preventDefault(); trigger.focus(); });
        select.addEventListener('focus', () => trigger.focus());
        select.addEventListener('change', sync);
        select.addEventListener('invalid', event => {
            event.preventDefault(); select.setAttribute('aria-invalid', 'true'); sync(); trigger.focus(); show();
        });
        document.addEventListener('pointerdown', event => { if (!wrapper.contains(event.target)) close(); });
        document.addEventListener('pons:select-open', event => { if (event.detail !== trigger) close(); });
        wrapper.addEventListener('focusout', () => queueMicrotask(() => { if (!wrapper.contains(document.activeElement)) close(); }));
        window.addEventListener('resize', close, {passive: true});
        select.form?.addEventListener('reset', () => setTimeout(() => { close(); sync(); }, 0));
        new MutationObserver(sync).observe(select, {attributes: true, attributeFilter: ['aria-invalid', 'aria-describedby', 'disabled', 'required']});
        // Only hide the native UI once the replacement is fully wired.
        select.classList.add('quote-select-native');
        select.setAttribute('aria-hidden', 'true'); select.tabIndex = -1;
        sync();
    };

    let recaptchaPromise;
    const recaptcha = (key) => {
        if (!key) return Promise.resolve('');
        if (!recaptchaPromise) {
            recaptchaPromise = new Promise((resolve, reject) => {
                if (window.grecaptcha?.execute) { resolve(window.grecaptcha); return; }
                const script = document.createElement('script');
                script.src = `https://www.google.com/recaptcha/api.js?render=${encodeURIComponent(key)}`;
                script.async = true;
                script.onload = () => window.grecaptcha ? resolve(window.grecaptcha) : reject(new Error('recaptcha'));
                script.onerror = () => { script.remove(); recaptchaPromise = undefined; reject(new Error('recaptcha')); };
                document.head.append(script);
            });
        }
        return recaptchaPromise.then((api) => new Promise((resolve, reject) => {
            api.ready(() => api.execute(key, {action: 'contact_form'}).then(resolve, reject));
        }));
    };

    document.querySelectorAll('[data-pons-quote]').forEach((form) => {
        let config;
        try { config = JSON.parse(form.dataset.config); } catch { return; }
        const steps = [...form.querySelectorAll('[data-quote-step]')];
        const progress = form.querySelector('.pons-quote-progress');
        const back = form.querySelector('[data-quote-back]');
        const next = form.querySelector('[data-quote-next]');
        const submit = form.querySelector('[data-quote-submit]');
        const status = form.querySelector('[data-quote-status]');
        form.querySelectorAll('select').forEach(enhanceSelect);
        let step = 0;
        let busy = false;
        let completed = false;
        const show = (index, focus = true) => {
            step = index;
            steps.forEach((fieldset, i) => { fieldset.hidden = i !== index; });
            [...progress.children].forEach((item, i) => {
                if (i === index) item.setAttribute('aria-current', 'step');
                else item.removeAttribute('aria-current');
            });
            back.hidden = index === 0;
            next.hidden = index === steps.length - 1;
            submit.hidden = index !== steps.length - 1;
            if (focus) steps[index].querySelector('legend').focus();
        };
        const invalidIn = (fieldset) => [...fieldset.querySelectorAll('input,select,textarea')].find((input) => !input.checkValidity());
        const advance = () => {
            const invalid = invalidIn(steps[step]);
            if (invalid) { invalid.reportValidity(); return; }
            show(Math.min(step + 1, steps.length - 1));
        };
        const clearErrors = () => {
            form.querySelectorAll('[data-quote-error]').forEach((error) => error.remove());
            form.querySelectorAll('[aria-invalid="true"]').forEach((input) => {
                input.removeAttribute('aria-invalid');
                const descriptions = (input.getAttribute('aria-describedby') || '').split(' ').filter((id) => !id.endsWith('-error'));
                if (descriptions.length) input.setAttribute('aria-describedby', descriptions.join(' '));
                else input.removeAttribute('aria-describedby');
            });
        };
        form.noValidate = true;
        progress.hidden = false;
        form.classList.add('is-enhanced');
        show(0, false);
        back.addEventListener('click', () => { if (!busy) show(Math.max(0, step - 1)); });
        next.addEventListener('click', advance);
        form.addEventListener('input', (event) => {
            const input = event.target;
            if (input.hasAttribute('aria-invalid')) input.removeAttribute('aria-invalid');
        });
        form.addEventListener('submit', async (event) => {
            event.preventDefault();
            if (busy || completed || submit.disabled) return;
            if (step < steps.length - 1) { advance(); return; }
            clearErrors();
            for (let i = 0; i < steps.length; i++) {
                const invalid = invalidIn(steps[i]);
                if (invalid) { show(i, false); invalid.reportValidity(); return; }
            }
            busy = true;
            status.textContent = config.sending;
            form.setAttribute('aria-busy', 'true');
            [submit, back, next].forEach((button) => { button.disabled = true; });
            try {
                const url = new URL(config.ajaxUrl, window.location.href);
                url.searchParams.set('action', 'ticinoweb_form_token');
                const tokenResponse = await fetch(url, {credentials: 'same-origin', cache: 'no-store'});
                const token = await tokenResponse.json();
                if (!tokenResponse.ok || !token.success || !token.data?.token) throw new Error('token');
                form.elements.token.value = token.data.token;
                form.elements.recaptcha_token.value = await recaptcha(config.siteKey);
                const response = await fetch(config.ajaxUrl, {method: 'POST', body: new FormData(form), credentials: 'same-origin', cache: 'no-store'});
                const result = await response.json();
                if (!response.ok || !result.success) {
                    let first;
                    Object.entries(result.data?.fields || {}).forEach(([name, message]) => {
                        const input = form.elements.namedItem(name);
                        if (!(input instanceof HTMLElement)) return;
                        const error = document.createElement('span');
                        error.className = 'pons-quote-error';
                        error.dataset.quoteError = '';
                        error.id = `${input.id || form.elements.nome.id + '-' + name}-error`;
                        error.textContent = String(message);
                        input.setAttribute('aria-invalid', 'true');
                        input.setAttribute('aria-describedby', [input.getAttribute('aria-describedby'), error.id].filter(Boolean).join(' '));
                        const control = input.closest('.quote-select') || input;
                        control.parentNode.insertBefore(error, control.nextSibling);
                        if (!first) first = input;
                    });
                    status.textContent = first ? config.check : (result.data?.message || config.error);
                    if (first) { show(steps.indexOf(first.closest('[data-quote-step]')), false); first.focus(); }
                    else status.focus();
                    return;
                }
                // Parent honeypot responses have neither an id nor a mailed flag: never claim delivery.
                const saved = Number(result.data?.id) > 0;
                const mailed = result.data?.mailed === true;
                if (!saved && !mailed) throw new Error('unconfirmed');
                completed = true;
                status.textContent = saved && mailed ? config.success : (saved ? config.saved : config.mailed);
                status.focus();
            } catch {
                status.textContent = config.error;
                status.focus();
            } finally {
                busy = false;
                form.removeAttribute('aria-busy');
                [submit, back, next].forEach((button) => { button.disabled = completed; });
            }
        });
    });
})();
