/* global wp, ponsEditor */
(function () {
    'use strict';
    var el = wp.element.createElement;
    var __ = wp.i18n.__;
    var config = window.ponsEditor || { galleries: [] };
    var options = [{ value: 0, label: __('Scegli una galleria', 'ponsenergiasolare') }].concat(config.galleries);
    var Preview = wp.serverSideRender.default || wp.serverSideRender;
    wp.blocks.registerBlockType('pons/references', {
        apiVersion: 2,
        title: __('Referenze Pons', 'ponsenergiasolare'),
        description: __('Mostra le foto di una galleria già gestita nella Libreria Media.', 'ponsenergiasolare'),
        icon: 'format-gallery',
        category: 'media',
        attributes: { galleryId: { type: 'integer', default: 0 } },
        supports: { html: false },
        edit: function (props) {
            var id = props.attributes.galleryId;
            var available = config.galleries.some(function (gallery) { return gallery.value === id; });
            return el('div', wp.blockEditor.useBlockProps(),
                el(wp.components.Placeholder, { icon: 'format-gallery', label: __('Referenze Pons', 'ponsenergiasolare') },
                    el(wp.components.SelectControl, {
                        label: __('Galleria delle realizzazioni', 'ponsenergiasolare'),
                        value: available ? id : 0,
                        options: options,
                        onChange: function (value) { props.setAttributes({ galleryId: parseInt(value, 10) || 0 }); },
                        help: __('Foto, didascalie e ordine si modificano nella galleria originale. Dopo averla modificata, riapri l’editor per aggiornare l’elenco.', 'ponsenergiasolare')
                    }),
                    config.galleryUrl ? el('a', { href: config.galleryUrl, target: '_blank', rel: 'noopener noreferrer' }, __('Apri le gallerie nella Libreria Media', 'ponsenergiasolare')) : null,
                    config.galleries.length === 0 ? el('p', null, __('Non ci sono gallerie. Creane una in Media → Gestisci Gallerie oppure chiedi all’amministratore.', 'ponsenergiasolare')) : null,
                    id && !available ? el('p', { role: 'alert' }, __('La galleria selezionata non è più disponibile. Scegline un’altra.', 'ponsenergiasolare')) : null
                ),
                id && available ? el(Preview, {
                    block: 'pons/references', attributes: props.attributes,
                    EmptyResponsePlaceholder: function () { return el('p', null, __('Questa galleria non contiene ancora foto di realizzazioni da mostrare.', 'ponsenergiasolare')); }
                }) : null
            );
        },
        save: function () { return null; }
    });
}());
