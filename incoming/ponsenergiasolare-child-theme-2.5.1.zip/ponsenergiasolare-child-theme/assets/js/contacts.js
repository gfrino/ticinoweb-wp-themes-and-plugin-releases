(() => {
  const section = document.querySelector('.contact-section');
  if (!section || !('IntersectionObserver' in window)) return;
  const reduced = matchMedia('(prefers-reduced-motion: reduce)');
  let visible = false;
  let frame = 0;
  const paint = () => {
    frame = 0;
    if (!visible || reduced.matches || document.hidden) return;
    const box = section.getBoundingClientRect();
    const progress = Math.min(1, Math.max(0, (innerHeight - box.top) / (innerHeight + box.height)));
    section.style.setProperty('--contact-shift', `${(progress - .5) * 36}px`);
  };
  const schedule = () => { if (visible && !reduced.matches && !document.hidden && !frame) frame = requestAnimationFrame(paint); };
  new IntersectionObserver(([entry]) => { visible = entry.isIntersecting; schedule(); }).observe(section);
  window.addEventListener('scroll', schedule, { passive: true });
  window.addEventListener('resize', schedule, { passive: true });
  document.addEventListener('visibilitychange', schedule);
  reduced.addEventListener('change', schedule);
})();
