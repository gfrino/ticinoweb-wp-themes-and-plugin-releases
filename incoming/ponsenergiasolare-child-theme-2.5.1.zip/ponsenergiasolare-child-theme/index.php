<?php if (!defined('ABSPATH')) { exit; } get_header(); ?>
<main id="main" class="document-page" tabindex="-1">
<?php if (have_posts()) : while (have_posts()) : the_post(); ?><article><h1><?php if (!is_singular()) : ?><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a><?php else : the_title(); endif; ?></h1><?php the_content(); ?></article><?php endwhile; the_posts_navigation(); else : ?><h1><?php esc_html_e('Contenuto non trovato', 'ponsenergiasolare'); ?></h1><p><a href="<?php echo esc_url(pons_home()); ?>"><?php esc_html_e('Torna alla home', 'ponsenergiasolare'); ?></a></p><?php endif; ?>
</main><?php get_footer();
