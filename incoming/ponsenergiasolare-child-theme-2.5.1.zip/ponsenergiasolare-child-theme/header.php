<?php if (!defined('ABSPATH')) { exit; } ?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head><meta charset="<?php bloginfo('charset'); ?>"><meta name="viewport" content="width=device-width, initial-scale=1"><?php wp_head(); ?></head>
<body <?php body_class('pons-site'); ?>>
<?php wp_body_open(); ?>
<a class="skip-link" href="#main"><?php esc_html_e('Vai al contenuto', 'ponsenergiasolare'); ?></a>
<?php $contact = pons_contacts(); ?>
<header class="site-header">
    <div class="header-inner">
        <a class="brand" href="<?php echo esc_url(pons_home()); ?>" rel="home"><?php pons_logo(); ?></a>
        <button type="button" class="menu-toggle" aria-expanded="false" aria-controls="primary-navigation"><span class="menu-label-open"><?php esc_html_e('Menu', 'ponsenergiasolare'); ?></span><span class="menu-label-close"><?php esc_html_e('Chiudi', 'ponsenergiasolare'); ?></span><span class="menu-icon" aria-hidden="true"></span></button>
        <nav id="primary-navigation" aria-label="<?php esc_attr_e('Navigazione principale', 'ponsenergiasolare'); ?>">
            <span class="menu-art" aria-hidden="true"><span class="menu-sun solar-disc"></span></span>
            <div class="menu-panel-inner">
                <p class="menu-intro"><?php esc_html_e('Esplora', 'ponsenergiasolare'); ?></p>
                <?php wp_nav_menu(array('theme_location' => 'primary', 'container' => false, 'menu_class' => 'primary-menu', 'fallback_cb' => false, 'depth' => 1)); ?>
                <?php if ($contact['phone'] || $contact['email']) : ?>
                <div class="menu-contacts">
                    <p><?php esc_html_e('Parliamone', 'ponsenergiasolare'); ?></p>
                    <?php if ($contact['phone']) : ?><a href="<?php echo esc_url(pons_phone_url($contact['phone'])); ?>"><?php echo esc_html($contact['phone']); ?><span aria-hidden="true">↗</span></a><?php endif; ?>
                    <?php if ($contact['email']) : ?><a class="menu-email" href="<?php echo esc_url('mailto:' . $contact['email']); ?>"><?php echo esc_html($contact['email']); ?></a><?php endif; ?>
                </div>
                <?php endif; ?>
            </div>
        </nav>
        <?php if ($quote_url = pons_page_url('preventivo')) : ?><a class="header-quote" href="<?php echo esc_url($quote_url); ?>"><?php echo esc_html(pons_quote_cta_label()); ?><span aria-hidden="true">↗</span></a><?php endif; ?>
    </div>
</header>
