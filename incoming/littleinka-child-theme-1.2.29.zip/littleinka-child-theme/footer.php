<?php
/**
 * Chiusura sulla fascia del marchio (titolo dall'offerta e dai metodi di consegna, orari di oggi,
 * «Ordina online», una foto) e footer a quattro colonne: contatti e orari della sede dal parent,
 * «Cambia sede» (menu littleinka_footer_links + portale), «Informazioni» (menu littleinka_footer_support),
 * app, partner, avviso alcol, social e la riga legale. Ogni blocco compare solo se il dato c'è.
 */
defined('ABSPATH') || exit;

$li_site_name = function_exists('ticinoweb_frontend_text') ? ticinoweb_frontend_text(get_bloginfo('name'), 'theme:branding:site_name') : get_bloginfo('name');
$li_vat       = function_exists('ticinoweb_get_contact_info') ? trim((string) (ticinoweb_get_contact_info()['vat'] ?? '')) : '';
$li_contact   = function_exists('ticinoweb_get_contact_info') ? ticinoweb_get_contact_info() : array();
$li_delivery  = littleinka_delivery();
$li_poke_only = littleinka_offer() === 'poke';
$li_menu_url  = littleinka_menu_url();
$li_rows      = littleinka_hours_rows();
$li_address   = littleinka_address_line();
$li_phone     = (string) (($li_contact['phone_landline'] ?? '') ?: ($li_contact['phone'] ?? ''));
$li_email     = (string) ($li_contact['email'] ?? '');
$li_apps      = littleinka_app_links();
$li_partners  = littleinka_partners();
$li_map_url   = (string) ($li_contact['map_url'] ?? '');

/* Immagini del piè di pagina scelte in Personalizza → Little Inka: badge delle app, pagamenti, bollino -18. */
$li_footer_img = function ($key, $size, $class) {
    $id = (int) littleinka_setting($key, 0);
    return $id && wp_attachment_is_image($id) ? wp_get_attachment_image($id, $size, false, array('class' => $class, 'loading' => 'lazy', 'decoding' => 'async')) : '';
};
$li_payments  = array();
foreach (littleinka_payment_methods() as $li_pay_key => $li_pay_label) {
    if (littleinka_setting('pay_' . $li_pay_key, true)) {
        $li_payments[$li_pay_key] = $li_pay_label;
    }
}
/* I metodi di pagamento, sotto gli orari (o nella prima colonna se la sede non ha orari). */
$li_pay_html = '';
if ($li_payments) {
    $li_pay_html = '<ul class="li-footer__payments" aria-label="' . esc_attr__('Metodi di pagamento accettati', 'littleinka-child-theme') . '">';
    foreach ($li_payments as $li_pay_key => $li_pay_label) {
        $li_pay_html .= '<li class="li-pay li-pay--' . esc_attr($li_pay_key) . '"><img src="' . esc_url(get_stylesheet_directory_uri() . '/assets/img/pay/' . $li_pay_key . '.svg') . '" alt="' . esc_attr($li_pay_label) . '" loading="lazy" decoding="async"></li>';
    }
    $li_pay_html .= '</ul>';
}
$li_badge_ios = $li_footer_img('badge_ios', 'medium', 'li-footer__badge-img');
$li_badge_and = $li_footer_img('badge_android', 'medium', 'li-footer__badge-img');
$li_alc_img   = $li_footer_img('alcohol_image', 'medium', 'li-footer__alcohol-img');
$li_badges    = '';
if (!empty($li_apps['android']) && $li_badge_and !== '') {
    $li_badges .= '<a class="li-footer__badge" href="' . esc_url($li_apps['android']) . '" target="_blank" rel="noopener">' . $li_badge_and . '</a>';
}
if (!empty($li_apps['ios']) && $li_badge_ios !== '') {
    $li_badges .= '<a class="li-footer__badge" href="' . esc_url($li_apps['ios']) . '" target="_blank" rel="noopener">' . $li_badge_ios . '</a>';
}
if ($li_map_url === '' && $li_address !== '') {
    $li_map_url = 'https://www.openstreetmap.org/search?query=' . rawurlencode($li_address);
}

/* Titolo in testa alla prima colonna del footer: sul portale «Scegli la tua sede»; nelle sedi con la consegna «{Offerta} a domicilio a {città}», altrimenti «Ordina … e ritira in sede». */
if (littleinka_is_portal()) {
    $li_close_title = littleinka_t(__('Scegli la sede Little Inka più vicina', 'littleinka-child-theme'), 'close:portale');
} elseif ($li_delivery['delivery']) {
    /* translators: 1: «Poké e sushi» o «Poké», 2: città della sede */
    $li_close_title = sprintf(littleinka_t(__('%1$s a domicilio a %2$s', 'littleinka-child-theme'), 'close:domicilio'), littleinka_offer_label(), littleinka_city());
} else {
    $li_close_title = $li_poke_only
        ? littleinka_t(__('Ordina la tua poké e ritirala in sede', 'littleinka-child-theme'), 'close:ritiro_poke')
        : littleinka_t(__('Ordina poké e sushi e ritirali in sede', 'littleinka-child-theme'), 'close:ritiro_sushi');
}

/* Il logo del CMS nei suoi colori, in un cerchio bianco, a sinistra delle colonne del footer. */
$li_close_logo     = function_exists('ticinoweb_get_site_logo') ? (string) ticinoweb_get_site_logo() : '';
$li_close_logo_att = $li_close_logo !== '' ? attachment_url_to_postid($li_close_logo) : 0;
?>
<footer class="li-footer">
    <div class="li-wrap li-footer__cols">
        <div class="li-footer__col">
            <?php if ($li_close_logo !== '') : ?>
                <a class="li-close__logo li-footer__brand" href="<?php echo esc_url($li_menu_url); ?>" tabindex="-1" aria-hidden="true">
                    <span class="li-close__badge">
                        <?php
                        echo $li_close_logo_att // phpcs:ignore WordPress.Security.EscapeOutput -- immagine di WordPress o tag escapato
                            ? wp_get_attachment_image($li_close_logo_att, 'medium', false, array('class' => 'li-close__badge-img', 'alt' => '', 'loading' => 'lazy', 'decoding' => 'async', 'sizes' => '96px'))
                            : '<img class="li-close__badge-img" src="' . esc_url($li_close_logo) . '" alt="" width="170" height="142" loading="lazy">';
                        ?>
                    </span>
                </a>
            <?php endif; ?>
            <h2 class="li-footer__headline"><?php echo esc_html($li_close_title); ?></h2>
            <?php if ($li_address === '' && $li_phone === '' && $li_email === '' && littleinka_is_portal()) : // Portale senza contatti propri: le sedi. ?>
                <ul class="li-footer__links">
                    <?php foreach (littleinka_portal_sedi() as $li_sede) : ?>
                        <?php if ($li_sede['url'] !== '') : ?><li><a href="<?php echo esc_url($li_sede['url']); ?>"><?php echo esc_html($li_sede['title']); ?></a></li><?php endif; ?>
                    <?php endforeach; ?>
                </ul>
            <?php endif; ?>
            <address class="li-footer__contact">
                <?php if ($li_address !== '') : ?>
                    <a href="<?php echo esc_url($li_map_url); ?>" target="_blank" rel="noopener"><?php echo esc_html($li_address); ?></a>
                <?php endif; ?>
                <?php if ($li_phone !== '') : ?>
                    <a href="<?php echo esc_url(littleinka_tel($li_phone)); ?>"><?php echo esc_html($li_phone); ?></a>
                <?php endif; ?>
                <?php if ($li_email !== '' && is_email($li_email)) : ?>
                    <a href="<?php echo esc_url('mailto:' . $li_email); ?>"><?php echo esc_html($li_email); ?></a>
                <?php endif; ?>
                <?php if ($li_vat !== '') : ?>
                    <span><?php echo esc_html(sprintf(littleinka_t(__('P.IVA %s', 'littleinka-child-theme'), 'footer:vat'), $li_vat)); ?></span>
                <?php endif; ?>
            </address>
            <?php if (!$li_rows) : // Senza orari i pagamenti restano qui. ?>
                <?php echo $li_pay_html; // phpcs:ignore WordPress.Security.EscapeOutput -- costruito sotto con esc_* ?>
            <?php endif; ?>
            <?php if ($li_badges) : ?>
                <p class="li-footer__badges"><?php echo $li_badges; // phpcs:ignore WordPress.Security.EscapeOutput -- link e immagini escapati sotto ?></p>
            <?php endif; ?>
        </div>

        <?php if ($li_rows) : ?>
            <div class="li-footer__col li-footer__col--hours">
                <h3 class="li-footer__title"><?php esc_html_e('Orari', 'littleinka-child-theme'); ?></h3>
                <dl class="li-hours">
                    <?php foreach ($li_rows as $li_row) : ?>
                        <dt<?php echo !empty($li_row['today']) ? ' class="is-today"' : ''; ?>><?php echo esc_html($li_row['days']); ?></dt>
                        <dd<?php echo !empty($li_row['today']) ? ' class="is-today"' : ''; ?>><?php echo esc_html($li_row['hours']); ?></dd>
                    <?php endforeach; ?>
                </dl>
                <?php echo $li_pay_html; // phpcs:ignore WordPress.Security.EscapeOutput -- costruito sotto con esc_* ?>
            </div>
        <?php endif; ?>

        <div class="li-footer__col">
            <h3 class="li-footer__title"><?php esc_html_e('Link veloci', 'littleinka-child-theme'); ?></h3>
            <?php if (has_nav_menu('littleinka_footer_links')) : ?>
                <?php wp_nav_menu(array('theme_location' => 'littleinka_footer_links', 'container' => false, 'menu_class' => 'li-footer__links', 'depth' => 1, 'fallback_cb' => false)); ?>
            <?php endif; ?>
            <?php if (littleinka_portal_url() !== '') : ?>
                <p class="li-footer__portal"><a href="<?php echo esc_url(littleinka_portal_url()); ?>"><?php esc_html_e('Tutte le sedi', 'littleinka-child-theme'); ?><?php echo littleinka_icon('arrow', 14); // phpcs:ignore WordPress.Security.EscapeOutput ?></a></p>
            <?php endif; ?>
        </div>

        <?php if (has_nav_menu('littleinka_footer_support') || ($li_apps && ($li_badge_ios === '' || $li_badge_and === '')) || littleinka_show_alcohol_notice()) : ?>
            <div class="li-footer__col">
                <?php if (has_nav_menu('littleinka_footer_support')) : ?>
                    <h3 class="li-footer__title"><?php esc_html_e('Informazioni', 'littleinka-child-theme'); ?></h3>
                    <?php wp_nav_menu(array('theme_location' => 'littleinka_footer_support', 'container' => false, 'menu_class' => 'li-footer__links', 'depth' => 1, 'fallback_cb' => false)); ?>
                <?php endif; ?>
                <?php if ($li_apps) : ?>
                    <p class="li-footer__apps">
                        <?php if (!empty($li_apps['ios']) && $li_badge_ios === '') : ?>
                            <a class="li-btn li-btn--outline" href="<?php echo esc_url($li_apps['ios']); ?>" target="_blank" rel="noopener"><?php echo littleinka_icon('mobile', 16); // phpcs:ignore WordPress.Security.EscapeOutput ?><?php esc_html_e('App per iPhone', 'littleinka-child-theme'); ?></a>
                        <?php endif; ?>
                        <?php if (!empty($li_apps['android']) && $li_badge_and === '') : ?>
                            <a class="li-btn li-btn--outline" href="<?php echo esc_url($li_apps['android']); ?>" target="_blank" rel="noopener"><?php echo littleinka_icon('mobile', 16); // phpcs:ignore WordPress.Security.EscapeOutput ?><?php esc_html_e('App per Android', 'littleinka-child-theme'); ?></a>
                        <?php endif; ?>
                    </p>
                <?php endif; ?>
                <?php if (littleinka_show_alcohol_notice() && $li_alc_img !== '') : ?>
                    <p class="li-footer__alcohol"><a href="https://www.bag.admin.ch" target="_blank" rel="noopener" aria-label="<?php esc_attr_e('Niente alcol e tabacco ai minori di 18 anni', 'littleinka-child-theme'); ?>"><?php echo $li_alc_img; // phpcs:ignore WordPress.Security.EscapeOutput -- immagine di WordPress ?></a></p>
                <?php elseif (littleinka_show_alcohol_notice()) : ?>
                    <p class="li-footer__notice"><?php echo littleinka_icon('warning', 16); // phpcs:ignore WordPress.Security.EscapeOutput ?><a href="https://www.bag.admin.ch" target="_blank" rel="noopener"><?php esc_html_e('Niente alcol e tabacco ai minori di 18 anni', 'littleinka-child-theme'); ?></a></p>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>

    <div class="li-wrap li-footer__legal">
        <p class="li-footer__copy">
            <?php
            printf(
                /* translators: 1: anno, 2: nome del sito */
                esc_html__('© %1$s %2$s', 'littleinka-child-theme'),
                esc_html(wp_date('Y')),
                esc_html($li_site_name)
            );
            ?>
            <a href="<?php echo esc_url(littleinka_login_url()); ?>"><?php esc_html_e('Area riservata', 'littleinka-child-theme'); ?></a>
            <span><?php esc_html_e('design by', 'littleinka-child-theme'); ?> <a href="https://ticinoweb.com" target="_blank" rel="noopener">ticinoWEB</a></span>
        </p>
        <?php if ($li_partners) : ?>
            <p class="li-footer__partner">
                <?php
                foreach ($li_partners as $li_p) {
                    // Un logo quasi quadrato (es. Codeborgo) sta più alto, così pesa come uno largo (es. Ficus).
                    $li_p_meta = wp_get_attachment_metadata($li_p['logo']);
                    $li_p_tall = !empty($li_p_meta['width']) && !empty($li_p_meta['height']) && $li_p_meta['height'] / $li_p_meta['width'] > 0.6;
                    $li_p_img  = wp_get_attachment_image($li_p['logo'], 'medium', false, array('class' => 'li-footer__partner-img' . ($li_p_tall ? ' is-tall' : ''), 'loading' => 'lazy', 'decoding' => 'async'));
                    echo $li_p['url'] !== '' // phpcs:ignore WordPress.Security.EscapeOutput -- immagine di WordPress
                        ? '<a href="' . esc_url($li_p['url']) . '" target="_blank" rel="noopener">' . $li_p_img . '</a>'
                        : '<span>' . $li_p_img . '</span>';
                }
                ?>
            </p>
        <?php endif; ?>
        <?php if (!empty($li_contact['facebook']) || !empty($li_contact['instagram']) || !empty($li_contact['tiktok'])) : ?>
            <p class="li-footer__social">
                <?php foreach (array('facebook' => 'Facebook', 'instagram' => 'Instagram', 'tiktok' => 'TikTok') as $li_net => $li_label) : ?>
                    <?php if (!empty($li_contact[$li_net])) : ?>
                        <a href="<?php echo esc_url($li_contact[$li_net]); ?>" target="_blank" rel="noopener" aria-label="<?php echo esc_attr($li_label . ' ' . $li_site_name); ?>"><?php echo littleinka_icon($li_net, 20); // phpcs:ignore WordPress.Security.EscapeOutput ?></a>
                    <?php endif; ?>
                <?php endforeach; ?>
            </p>
        <?php endif; ?>
    </div>
</footer>
<?php
// Il carrello in basso: sulle sedi, fuori da carrello e cassa (helpers.php).
if (!((function_exists('is_cart') && is_cart()) || (function_exists('is_checkout') && is_checkout()))) {
    echo littleinka_cart_bar(); // phpcs:ignore WordPress.Security.EscapeOutput -- escape nella funzione
}
?>
<?php wp_footer(); ?>
</body>
</html>
