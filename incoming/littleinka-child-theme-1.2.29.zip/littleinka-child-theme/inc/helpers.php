<?php
/**
 * Funzioni comuni del tema Little Inka. Tutto ciò che descrive la sede si LEGGE da qui:
 * contatti e orari dal parent (ticinoweb_contact_*), consegna e ritiro da WooCommerce e CodeRockz,
 * i pochi dati propri da Aspetto → Personalizza → Little Inka (theme_mod littleinka_*).
 * Nessun dato della sede è scritto nel codice.
 */
defined('ABSPATH') || exit;

/* -------------------------------------------------------------------------
 * Testi, icone, piccoli formati
 * ---------------------------------------------------------------------- */

/**
 * Testi che non passano da __() come testo visibile (attributi, messaggi degli script, titoli composti):
 * attraversano il livello di traduzione del parent, così tW Translate li traduce come gli altri.
 */
function littleinka_t($text, $key)
{
    return function_exists('ticinoweb_frontend_text') ? ticinoweb_frontend_text($text, 'littleinka:' . $key) : $text;
}

/** Icone in linea (niente font di icone, niente richieste esterne). */
function littleinka_icon($name, $size = 20)
{
    $paths = array(
        'cart'      => '<path d="M3 4h2.5l2.2 10.2a1.5 1.5 0 0 0 1.5 1.2h8.4a1.5 1.5 0 0 0 1.5-1.1L21 8H6.3" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round" stroke-linecap="round"/><circle cx="9.5" cy="19.5" r="1.4" fill="currentColor"/><circle cx="17.5" cy="19.5" r="1.4" fill="currentColor"/>',
        'arrow'     => '<path d="M5 12h14M13 6l6 6-6 6" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/>',
        'chevron'   => '<path d="m6 9 6 6 6-6" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/>',
        'close'     => '<path d="M6 6l12 12M18 6 6 18" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>',
        'menu'      => '<path d="M4 7h16M4 12h16M4 17h16" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>',
        'phone'     => '<path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1 1 .4 1.9.7 2.8a2 2 0 0 1-.5 2.1L8.1 9.9a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.4c.9.3 1.8.6 2.8.7a2 2 0 0 1 1.7 2z" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/>',
        'mail'      => '<rect x="3" y="5" width="18" height="14" rx="2" fill="none" stroke="currentColor" stroke-width="1.6"/><path d="m3.5 6.5 8.5 7 8.5-7" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/>',
        'pin'       => '<path d="M12 22s7-6.5 7-12.5A7 7 0 0 0 5 9.5C5 15.5 12 22 12 22z" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/><circle cx="12" cy="9.5" r="2.5" fill="none" stroke="currentColor" stroke-width="1.6"/>',
        'clock'     => '<circle cx="12" cy="12" r="9" fill="none" stroke="currentColor" stroke-width="1.6"/><path d="M12 7v5l3.5 2" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/>',
        'truck'     => '<path d="M3 6h11v9H3zM14 9h4l3 3v3h-7" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/><circle cx="7" cy="17" r="1.8" fill="none" stroke="currentColor" stroke-width="1.6"/><circle cx="17" cy="17" r="1.8" fill="none" stroke="currentColor" stroke-width="1.6"/>',
        'bag'       => '<path d="M5 8h14l-1 12H6z" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/><path d="M9 8V6a3 3 0 0 1 6 0v2" fill="none" stroke="currentColor" stroke-width="1.6"/>',
        'mobile'    => '<rect x="6" y="2" width="12" height="20" rx="2.5" fill="none" stroke="currentColor" stroke-width="1.6"/><circle cx="12" cy="18.5" r="1" fill="currentColor"/>',
        'check'     => '<path d="m4 12.5 5 5L20 6.5" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/>',
        'plus'      => '<path d="M12 5v14M5 12h14" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>',
        'minus'     => '<path d="M5 12h14" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>',
        'search'    => '<circle cx="11" cy="11" r="6.5" fill="none" stroke="currentColor" stroke-width="1.8"/><path d="m16 16 4.5 4.5" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>',
        'user'      => '<circle cx="12" cy="8.5" r="3.6" fill="none" stroke="currentColor" stroke-width="1.6"/><path d="M4.5 20c1.3-3.6 4.2-5.4 7.5-5.4s6.2 1.8 7.5 5.4" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/>',
        'facebook'  => '<path d="M20 2H4a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h8.6v-7.7H10V11.3h2.6V9.1c0-2.6 1.6-4 3.9-4 1.1 0 2 .1 2.3.1v2.7h-1.6c-1.3 0-1.5.6-1.5 1.5v1.9h3l-.4 3h-2.6V22H20a2 2 0 0 0 2-2V4a2 2 0 0 0-2-2z" fill="currentColor"/>',
        'instagram' => '<rect x="3" y="3" width="18" height="18" rx="5" fill="none" stroke="currentColor" stroke-width="1.8"/><circle cx="12" cy="12" r="4" fill="none" stroke="currentColor" stroke-width="1.8"/><circle cx="17.3" cy="6.7" r="1.2" fill="currentColor"/>',
        'tiktok'    => '<path d="M14 3v9.5a3.5 3.5 0 1 1-3-3.46" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/><path d="M14 3c.5 2.6 2.3 4.3 5 4.5" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>',
        'warning'   => '<path d="M12 3 2.5 20h19z" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/><path d="M12 9v5" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/><circle cx="12" cy="17" r="1" fill="currentColor"/>',
        'leaf'      => '<path d="M5 19c0-9 6-14 15-15-1 9-6 15-15 15z" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/><path d="M5 19 14 10" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/>',
        'external'  => '<path d="M14 4h6v6M20 4l-9 9M19 14v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V6a1 1 0 0 1 1-1h5" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/>',
    );
    if (!isset($paths[$name])) {
        return '';
    }
    return '<svg class="li-icon li-icon--' . esc_attr($name) . '" viewBox="0 0 24 24" width="' . (int) $size . '" height="' . (int) $size . '" aria-hidden="true" focusable="false">' . $paths[$name] . '</svg>';
}

/** Numero di telefono per i link tel: (solo cifre e +). */
function littleinka_tel($number)
{
    return 'tel:' . preg_replace('/[^\d+]/', '', (string) $number);
}

/** Prezzo di WooCommerce come testo (es. «CHF 16.90»), senza HTML. */
function littleinka_price($amount)
{
    return function_exists('wc_price') ? html_entity_decode(wp_strip_all_tags(wc_price((float) $amount)), ENT_QUOTES, 'UTF-8') : number_format((float) $amount, 2, '.', '\'');
}

/** Minuti dalla mezzanotte (come li salva CodeRockz) → «11:00». */
function littleinka_minutes_to_time($minutes)
{
    $minutes = (int) $minutes;
    return sprintf('%02d:%02d', intdiv($minutes, 60) % 24, $minutes % 60);
}

/* -------------------------------------------------------------------------
 * Impostazioni della sede (Aspetto → Personalizza → Little Inka, inc/settings.php)
 * ---------------------------------------------------------------------- */

/** Un'impostazione della sede (theme_mod «littleinka_<chiave>»), con il suo valore di default. */
function littleinka_setting($key, $default = '')
{
    return get_theme_mod('littleinka_' . $key, $default);
}

/** Nome breve della sede per i titoli («Via Murate», «Castione»): impostazione, altrimenti la città del negozio. */
function littleinka_short_name()
{
    $name = trim((string) littleinka_setting('nome_breve', ''));
    if ($name === '') {
        $name = littleinka_city();
    }
    return littleinka_t($name, 'sede:nome_breve');
}

/** La città della sede: dall'indirizzo del negozio WooCommerce, altrimenti dall'ultima parola dell'indirizzo del CMS. */
function littleinka_city()
{
    $city = trim((string) get_option('woocommerce_store_city', ''));
    if ($city === '' && function_exists('ticinoweb_get_contact_info')) {
        $address = wp_strip_all_tags((string) (ticinoweb_get_contact_info()['address'] ?? ''));
        if (preg_match('/\d{4}\s+([^\d,]+)\s*$/u', $address, $m)) {
            $city = trim($m[1]);
        }
    }
    return $city;
}

/** Indirizzo della sede in una riga («Via Murate 2, 6500 Bellinzona»): CMS del parent, altrimenti il negozio WooCommerce. */
function littleinka_address_line()
{
    $address = wp_strip_all_tags((string) (littleinka_contact_info()['address'] ?? ''));
    $address = trim(preg_replace('/\s*\n\s*/', ', ', $address));
    if ($address === '') {
        $parts = array_filter(array(
            trim((string) get_option('woocommerce_store_address', '')),
            trim(get_option('woocommerce_store_postcode', '') . ' ' . get_option('woocommerce_store_city', '')),
        ));
        $address = implode(', ', $parts);
    }
    return $address;
}

/* -------------------------------------------------------------------------
 * Offerta della sede: «sushi_poke» o «poke»
 * ---------------------------------------------------------------------- */

/** Le categorie prodotto che NON sono sushi: con solo queste la sede è «solo poké». */
function littleinka_poke_side_slugs()
{
    return apply_filters('littleinka_poke_side_slugs', array('poke-bowl', 'crea-la-tua-poke', 'bibite', 'dessert', 'desserts', 'accessori'));
}

/**
 * Offerta della sede: dall'impostazione («poke» | «sushi_poke»), oppure in automatico («auto», il default):
 * «sushi_poke» se esiste almeno un prodotto pubblicato e visibile nel catalogo in una categoria che non è del poké.
 * Risultato in transient, svuotato quando si salva un prodotto (vedi littleinka_flush_caches()).
 */
function littleinka_offer()
{
    $setting = (string) littleinka_setting('offerta', 'auto');
    if (in_array($setting, array('poke', 'sushi_poke'), true)) {
        return $setting;
    }
    $cached = get_transient('littleinka_offer');
    if ($cached === 'poke' || $cached === 'sushi_poke') {
        return $cached;
    }
    $offer = 'poke';
    if (function_exists('wc_get_products')) {
        $ids = wc_get_products(array(
            'status'     => 'publish',
            'limit'      => 1,
            'visibility' => 'catalog',
            'return'     => 'ids',
            'tax_query'  => array(array(
                'taxonomy' => 'product_cat',
                'field'    => 'slug',
                'terms'    => littleinka_poke_side_slugs(),
                'operator' => 'NOT IN',
            )),
        ));
        $offer = $ids ? 'sushi_poke' : 'poke';
    }
    set_transient('littleinka_offer', $offer, DAY_IN_SECONDS);
    return $offer;
}

/** Quello che la sede vende, per i titoli: «Poké e sushi» oppure «Poké». */
function littleinka_offer_label()
{
    return littleinka_offer() === 'sushi_poke'
        ? littleinka_t(__('Poké e sushi', 'littleinka-child-theme'), 'offerta:sushi_poke')
        : littleinka_t(__('Poké', 'littleinka-child-theme'), 'offerta:poke');
}

/* -------------------------------------------------------------------------
 * Consegna e ritiro: WooCommerce (zone di spedizione) e CodeRockz (ordine minimo, fasce orarie)
 * ---------------------------------------------------------------------- */

/**
 * Come si ordina in questa sede, letto dalle zone di spedizione di WooCommerce e da CodeRockz:
 *  - delivery   bool   almeno una tariffa flat_rate o free_shipping attiva (consegna a domicilio)
 *  - pickup     bool   almeno un local_pickup attivo (ritiro in sede)
 *  - fee_min / fee_max  float  costo di consegna più basso e più alto tra le zone (0 se nessuno)
 *  - free_from  float  soglia della consegna gratuita (0 se non c'è)
 *  - min_order  float  ordine minimo per la consegna (CodeRockz «minimum_amount_cart_restriction», 0 se non c'è)
 *  - zones      array  [ ['name' => 'Bellinzona', 'fee' => 3.0], … ] le zone con consegna
 */
function littleinka_delivery()
{
    static $info = null;
    if ($info !== null) {
        return $info;
    }
    $cached = get_transient('littleinka_delivery');
    if (is_array($cached)) {
        $info = $cached;
        return apply_filters('littleinka_delivery', $info);
    }
    $info = array('delivery' => false, 'pickup' => false, 'fee_min' => 0.0, 'fee_max' => 0.0, 'free_from' => 0.0, 'min_order' => 0.0, 'zones' => array());
    if (!class_exists('WC_Shipping_Zones')) {
        return $info;
    }
    $zones = WC_Shipping_Zones::get_zones();
    $zones[] = array('zone_name' => '', 'shipping_methods' => WC_Shipping_Zones::get_zone(0)->get_shipping_methods(true));
    foreach ($zones as $zone) {
        foreach ($zone['shipping_methods'] as $method) {
            if (!$method->is_enabled()) {
                continue;
            }
            if ($method->id === 'local_pickup') {
                $info['pickup'] = true;
            } elseif ($method->id === 'flat_rate') {
                $info['delivery'] = true;
                $fee = (float) preg_replace('/[^\d.]/', '', (string) $method->get_option('cost'));
                $info['fee_min'] = $info['fee_min'] > 0 ? min($info['fee_min'], $fee) : $fee;
                $info['fee_max'] = max($info['fee_max'], $fee);
                if ($zone['zone_name'] !== '') {
                    $info['zones'][] = array('name' => $zone['zone_name'], 'fee' => $fee);
                }
            } elseif ($method->id === 'free_shipping') {
                $info['delivery'] = true;
                $min = (float) $method->get_option('min_amount');
                if ($min > 0) {
                    $info['free_from'] = $info['free_from'] > 0 ? min($info['free_from'], $min) : $min;
                }
            }
        }
    }
    $coderockz = get_option('coderockz_woo_delivery_option_delivery_settings', array());
    if (is_array($coderockz) && !empty($coderockz['enable_delivery_restriction']) && !empty($coderockz['minimum_amount_cart_restriction'])) {
        $info['min_order'] = (float) $coderockz['minimum_amount_cart_restriction'];
    }
    set_transient('littleinka_delivery', $info, 12 * HOUR_IN_SECONDS);
    return apply_filters('littleinka_delivery', $info);
}

/**
 * Fasce orarie per ordinare, da CodeRockz Delivery Date Time: ['delivery' => [...], 'pickup' => [...]],
 * ogni fascia ['name' => 'Pranzo', 'from' => '11:00', 'to' => '14:00']. Solo le fasce attive e valide per
 * tutte le zone (quelle limitate a una zona restano alla cassa). Vuoto senza il plugin.
 */
function littleinka_slots()
{
    static $slots = null;
    if ($slots !== null) {
        return $slots;
    }
    $slots = array('delivery' => array(), 'pickup' => array());
    foreach (array('delivery' => 'coderockz_woo_delivery_time_slot_settings', 'pickup' => 'coderockz_woo_delivery_pickup_slot_settings') as $type => $option) {
        $settings = get_option($option, array());
        if (!is_array($settings) || empty($settings['time_slot']) || !is_array($settings['time_slot'])) {
            continue;
        }
        foreach ($settings['time_slot'] as $slot) {
            if (empty($slot['enable']) || !empty($slot['disable_zone']) || !empty($slot['disable_postcode']) || !isset($slot['start'], $slot['end'])) {
                continue;
            }
            $slots[$type][] = array(
                'name' => littleinka_t((string) ($slot['name'] ?? ''), 'fascia:' . sanitize_title((string) ($slot['name'] ?? $slot['start']))),
                'from' => littleinka_minutes_to_time($slot['start']),
                'to'   => littleinka_minutes_to_time($slot['end']),
            );
        }
        usort($slots[$type], function ($a, $b) {
            return strcmp($a['from'], $b['from']);
        });
    }
    return $slots;
}

/** Le fasce di un tipo in una riga: «11:00 – 14:00 e 18:00 – 22:00». */
function littleinka_slots_line($type)
{
    $parts = array();
    foreach (littleinka_slots()[$type] ?? array() as $slot) {
        $parts[] = $slot['from'] . ' – ' . $slot['to'];
    }
    return implode(' ' . littleinka_t(__('e', 'littleinka-child-theme'), 'fascia:e') . ' ', $parts);
}

/* -------------------------------------------------------------------------
 * Orari della sede (ticinoWEB CMS → Contatti) e «aperto adesso»
 * ---------------------------------------------------------------------- */

/** Gli orari della settimana del parent: array monday…sunday → {closed, open_24h, slots:[{open,close}]}. */
function littleinka_opening_hours()
{
    $hours = littleinka_contact_info()['opening_hours'] ?? array();
    return is_array($hours) ? $hours : array();
}

/**
 * La sede è aperta adesso? Ritorna ['open' => bool, 'until' => '22:00', 'next' => '10:00', 'next_day' => 'domani'|'lunedì'|'' ].
 * Tempo nel fuso del sito (wp_timezone()). Senza orari nel CMS: tutto vuoto e open = null.
 */
function littleinka_open_now()
{
    $hours = littleinka_opening_hours();
    if (!$hours) {
        return array('open' => null, 'until' => '', 'next' => '', 'next_day' => '');
    }
    $days = array('monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday');
    $now = new DateTimeImmutable('now', wp_timezone());
    $today = (int) $now->format('N') - 1;
    $hm = $now->format('H:i');
    $day = $hours[$days[$today]] ?? array();
    if (!empty($day['open_24h'])) {
        return array('open' => true, 'until' => '', 'next' => '', 'next_day' => '');
    }
    $result = array('open' => false, 'until' => '', 'next' => '', 'next_day' => '');
    foreach ((array) ($day['slots'] ?? array()) as $slot) {
        if (empty($day['closed']) && !empty($slot['open']) && !empty($slot['close']) && $slot['open'] <= $hm && $hm < $slot['close']) {
            return array('open' => true, 'until' => $slot['close'], 'next' => '', 'next_day' => '');
        }
        if (empty($day['closed']) && !empty($slot['open']) && $slot['open'] > $hm && $result['next'] === '') {
            $result['next'] = $slot['open'];
        }
    }
    if ($result['next'] !== '') {
        return $result;
    }
    for ($i = 1; $i <= 7; $i++) {
        $d = $hours[$days[($today + $i) % 7]] ?? array();
        $first = (array) (($d['slots'] ?? array(array()))[0] ?? array());
        if (empty($d['closed']) && (!empty($d['open_24h']) || !empty($first['open']))) {
            $result['next'] = !empty($d['open_24h']) ? '00:00' : $first['open'];
            $result['next_day'] = $i === 1
                ? littleinka_t(__('domani', 'littleinka-child-theme'), 'orari:domani')
                : wp_date('l', $now->modify('+' . $i . ' days')->getTimestamp(), wp_timezone());
            break;
        }
    }
    return $result;
}

/** La riga «Aperto adesso, fino alle 22:00» / «Chiuso, apre domani alle 10:00» (vuota senza orari). */
function littleinka_open_now_line()
{
    $state = littleinka_open_now();
    if ($state['open'] === null) {
        return '';
    }
    if ($state['open']) {
        return $state['until'] !== ''
            /* translators: %s: ora di chiusura, es. 22:00 */
            ? sprintf(littleinka_t(__('Aperto adesso, fino alle %s', 'littleinka-child-theme'), 'orari:aperto_fino'), $state['until'])
            : littleinka_t(__('Aperto adesso', 'littleinka-child-theme'), 'orari:aperto');
    }
    if ($state['next'] === '') {
        return littleinka_t(__('Chiuso', 'littleinka-child-theme'), 'orari:chiuso');
    }
    return $state['next_day'] === ''
        /* translators: %s: ora di apertura, es. 10:00 */
        ? sprintf(littleinka_t(__('Chiuso, apre oggi alle %s', 'littleinka-child-theme'), 'orari:apre_oggi'), $state['next'])
        /* translators: 1: giorno (domani, lunedì…), 2: ora di apertura */
        : sprintf(littleinka_t(__('Chiuso, apre %1$s alle %2$s', 'littleinka-child-theme'), 'orari:apre_giorno'), $state['next_day'], $state['next']);
}

/**
 * Orari raggruppati per righe uguali, per la tabella: [ ['days' => 'Lunedì – Domenica', 'hours' => '10:00 – 22:00', 'today' => bool], … ].
 * Giorni consecutivi con lo stesso orario stanno sulla stessa riga («Lunedì – Venerdì»).
 */
function littleinka_hours_rows()
{
    $hours = littleinka_opening_hours();
    if (!$hours || !function_exists('ticinoweb_format_day_hours')) {
        return array();
    }
    $days = array('monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday');
    $today = (int) (new DateTimeImmutable('now', wp_timezone()))->format('N') - 1;
    $labels = array(__('Lunedì', 'littleinka-child-theme'), __('Martedì', 'littleinka-child-theme'), __('Mercoledì', 'littleinka-child-theme'), __('Giovedì', 'littleinka-child-theme'), __('Venerdì', 'littleinka-child-theme'), __('Sabato', 'littleinka-child-theme'), __('Domenica', 'littleinka-child-theme'));
    $rows = array();
    foreach ($days as $i => $day) {
        $text = ticinoweb_format_day_hours($hours[$day] ?? array('closed' => true));
        $text = $text !== '' ? $text : __('Chiuso', 'littleinka-child-theme');
        $last = $rows ? count($rows) - 1 : -1;
        if ($last >= 0 && $rows[$last]['hours'] === $text && $rows[$last]['end'] === $i - 1) {
            $rows[$last]['end'] = $i;
            $rows[$last]['today'] = $rows[$last]['today'] || $i === $today;
            continue;
        }
        $rows[] = array('start' => $i, 'end' => $i, 'hours' => $text, 'today' => $i === $today);
    }
    foreach ($rows as &$row) {
        $row['days'] = $row['start'] === $row['end'] ? $labels[$row['start']] : $labels[$row['start']] . ' – ' . $labels[$row['end']];
        if ($row['start'] === 0 && $row['end'] === 6) {
            $row['days'] = __('Tutti i giorni', 'littleinka-child-theme');
        }
        unset($row['start'], $row['end']);
    }
    return $rows;
}

/* -------------------------------------------------------------------------
 * Pagine del sito: menu, Crea la tua poké, carrello, area riservata
 * ---------------------------------------------------------------------- */

/** ID della prima pagina pubblicata che contiene uno shortcode (cache in transient, svuotata al salvataggio di una pagina). */
function littleinka_page_with_shortcode($shortcode)
{
    $key = 'littleinka_page_' . sanitize_key($shortcode);
    $id = get_transient($key);
    if ($id !== false) {
        return (int) $id;
    }
    global $wpdb;
    $id = (int) $wpdb->get_var($wpdb->prepare(
        "SELECT ID FROM {$wpdb->posts} WHERE post_type = 'page' AND post_status = 'publish' AND post_content LIKE %s ORDER BY menu_order ASC, ID ASC LIMIT 1",
        '%[' . $wpdb->esc_like($shortcode) . '%'
    ));
    set_transient($key, $id, DAY_IN_SECONDS);
    return $id;
}

/** Indirizzo del menu: sulle sedi la home (che mostra la pagina con [littleinka_menu]). */
function littleinka_menu_url($anchor = '')
{
    $id = littleinka_page_with_shortcode('littleinka_menu');
    // Sulle sedi il menu è la home (front-page.php); sul portale resta la sua pagina.
    $url = $id && littleinka_is_portal() ? get_permalink($id) : home_url('/');
    $url = function_exists('ticinoweb_frontend_url') ? ticinoweb_frontend_url($url, 'littleinka:url:menu') : $url;
    return $anchor !== '' ? $url . '#' . ltrim($anchor, '#') : $url;
}

/** La pagina «Crea la tua poké» (quella con [make_your_own_poke]); vuota se non c'è. */
function littleinka_poke_url()
{
    $id = littleinka_page_with_shortcode('make_your_own_poke');
    if (!$id) {
        return '';
    }
    $url = get_permalink($id);
    return function_exists('ticinoweb_frontend_url') ? ticinoweb_frontend_url($url, 'littleinka:url:poke') : $url;
}

/** Il carrello: WooCommerce, altrimenti vuoto. */
function littleinka_cart_url()
{
    return function_exists('wc_get_cart_url') ? wc_get_cart_url() : '';
}

/** Articoli nel carrello (0 senza WooCommerce o senza sessione). */
function littleinka_cart_count()
{
    return (function_exists('WC') && WC()->cart) ? (int) WC()->cart->get_cart_contents_count() : 0;
}

/** Link «Area riservata»: il login sta su /tw-login/ (il parent risponde 404 su wp-admin a chi non è dentro). */
function littleinka_login_url()
{
    return rtrim((string) get_option('home'), '/') . '/tw-login/';
}

/** Il portale di tutte le sedi (impostazione della sede, di default littleinka.ch). */
function littleinka_portal_url()
{
    return (string) littleinka_setting('portale_url', LITTLEINKA_PORTAL_DEFAULT);
}

/* -------------------------------------------------------------------------
 * Cache del tema
 * ---------------------------------------------------------------------- */

/** Svuota i transient del tema quando cambiano prodotti, categorie o pagine. */
function littleinka_flush_caches()
{
    delete_transient('littleinka_offer');
    delete_transient('littleinka_delivery');
    delete_transient('littleinka_menu_data');
    delete_transient('littleinka_poke_sizes');
    delete_transient('littleinka_page_littleinka_menu');
    delete_transient('littleinka_page_make_your_own_poke');
    do_action('littleinka_flush_caches');
}
add_action('save_post_product', 'littleinka_flush_caches');
add_action('save_post_page', 'littleinka_flush_caches');
add_action('deleted_post', 'littleinka_flush_caches');
add_action('edited_product_cat', 'littleinka_flush_caches');
add_action('created_product_cat', 'littleinka_flush_caches');
add_action('delete_product_cat', 'littleinka_flush_caches');
add_action('woocommerce_product_set_stock_status', 'littleinka_flush_caches');
add_action('customize_save_after', 'littleinka_flush_caches');

/**
 * Il prodotto è una bevanda alcolica (da vendere solo a chi ha compiuto 18 anni)? Sì se ha il tag «alcol»
 * oppure se il nome riporta una gradazione («Birra Asahi 5.2%»): così il cliente non deve ricordarsi di etichettarla.
 */
function littleinka_is_alcohol($product)
{
    if (!($product instanceof WC_Product)) {
        return false;
    }
    if (has_term('alcol', 'product_tag', $product->get_id())) {
        return true;
    }
    return (bool) preg_match('/\d+(?:[.,]\d+)?\s*%/', (string) $product->get_name());
}

/* -------------------------------------------------------------------------
 * Pezzi di markup condivisi da header, footer e home
 * ---------------------------------------------------------------------- */

/**
 * Il carrello nell'header: icona, etichetta e numero di articoli. WooCommerce aggiorna «.li-cart__count»
 * con i frammenti (inc/shop.php). Vuoto senza WooCommerce.
 */
function littleinka_cart_link($class = '')
{
    $url = littleinka_cart_url();
    if ($url === '') {
        return '';
    }
    $count = littleinka_cart_count();
    /* translators: %s: numero di articoli nel carrello */
    $aria = sprintf(_n('Carrello, %s articolo', 'Carrello, %s articoli', $count, 'littleinka-child-theme'), number_format_i18n($count));
    return '<a class="li-cart ' . esc_attr($class) . '" href="' . esc_url($url) . '" aria-label="' . esc_attr(littleinka_t($aria, 'cart:aria')) . '">'
        . littleinka_icon('cart', 20)
        . '<span class="li-cart__label">' . esc_html__('Carrello', 'littleinka-child-theme') . '</span>'
        . '<span class="li-cart__count" data-cart-count>' . esc_html(number_format_i18n($count)) . '</span></a>';
}

/**
 * Il carrello in basso (sedi): pulsante fisso con numero di articoli e totale, visibile solo quando il carrello
 * non è vuoto e mai in carrello e cassa. WooCommerce lo sostituisce con i frammenti dopo ogni aggiunta
 * (inc/shop.php), così compare al primo piatto aggiunto senza ricaricare.
 */
function littleinka_cart_bar()
{
    $url = littleinka_cart_url();
    if ($url === '' || littleinka_is_portal()) {
        return '';
    }
    $count = littleinka_cart_count();
    $total = ($count && WC()->cart) ? wp_strip_all_tags(WC()->cart->get_cart_subtotal()) : '';
    /* translators: %s: numero di articoli nel carrello */
    $items = sprintf(_n('%s articolo', '%s articoli', $count, 'littleinka-child-theme'), number_format_i18n($count));
    return '<div class="li-cartbar"' . ($count ? '' : ' hidden') . ' data-li-cartbar>'
        . '<a class="li-cartbar__link" href="' . esc_url($url) . '">'
        . '<span class="li-cartbar__icon">' . littleinka_icon('cart', 20) . '<span class="li-cartbar__count">' . esc_html(number_format_i18n($count)) . '</span></span>'
        . '<span class="li-cartbar__label">' . esc_html__('Vai al carrello', 'littleinka-child-theme') . '<span class="li-cartbar__items"> · ' . esc_html($items) . '</span>'
        . (function_exists('littleinka_points_cartbar_text') && ($points = littleinka_points_cartbar_text()) !== '' ? '<span class="li-cartbar__points">' . esc_html($points) . '</span>' : '')
        . '</span>'
        . ($total !== '' ? '<span class="li-cartbar__total">' . esc_html(html_entity_decode($total, ENT_QUOTES, 'UTF-8')) . '</span>' : '')
        . '</a></div>';
}

/** Link alle app della sede: [ 'ios' => url, 'android' => url ], solo quelli impostati. */
function littleinka_app_links()
{
    return array_filter(array(
        'ios'     => esc_url_raw((string) littleinka_setting('app_ios_url', '')),
        'android' => esc_url_raw((string) littleinka_setting('app_android_url', '')),
    ));
}

/**
 * I partner della sede nel footer, nell'ordine delle impostazioni (fino a 3): [ [ 'logo' => ID allegato, 'url' => sito ], … ].
 * Il primo usa le chiavi storiche partner_logo / partner_url, gli altri partner_2_*, partner_3_*.
 */
function littleinka_partners()
{
    $list = array();
    foreach (array('', '_2', '_3') as $slot) {
        $logo = (int) littleinka_setting('partner' . $slot . '_logo', 0);
        if ($logo && wp_attachment_is_image($logo)) {
            $list[] = array('logo' => $logo, 'url' => esc_url_raw((string) littleinka_setting('partner' . $slot . '_url', '')));
        }
    }
    return $list;
}

/**
 * Metodi di pagamento da mostrare nel footer (loghi ufficiali nel tema, assets/img/pay/), nell'ordine scelto.
 * Ogni metodo si accende o si spegne in Personalizza → Little Inka.
 */
function littleinka_payment_methods()
{
    return array(
        'datatrans'  => 'Datatrans',
        'twint'      => 'TWINT',
        'apple-pay'  => 'Apple Pay',
        'google-pay' => 'Google Pay',
        'mastercard' => 'Mastercard',
        'visa'       => 'Visa',
    );
}

/** L'avviso «niente alcol e tabacco ai minori di 18 anni» va mostrato? (impostazione, di default sì). */
function littleinka_show_alcohol_notice()
{
    return (bool) littleinka_setting('banner_alcol', true);
}

/* -------------------------------------------------------------------------
 * [littleinka_contatti]: il pannello della sede (stato, indirizzo, telefono, email, orari, fasce)
 * per la pagina Contatti. Stesse classi del pannello della home (.li-visit), stessi dati del CMS.
 * ---------------------------------------------------------------------- */
function littleinka_visit_panel($with_email = true)
{
    $contact = function_exists('ticinoweb_get_contact_info') ? ticinoweb_get_contact_info() : array();
    $address = littleinka_address_line();
    $phone = trim((string) (($contact['phone_landline'] ?? '') ?: ($contact['phone'] ?? '')));
    $email = trim((string) ($contact['email'] ?? ''));
    $map = !empty($contact['map_url']) ? $contact['map_url'] : ($address !== '' ? 'https://www.openstreetmap.org/search?query=' . rawurlencode($address) : '');
    $open = littleinka_open_now_line();
    $rows = littleinka_hours_rows();
    $delivery = littleinka_slots_line('delivery');
    $pickup = littleinka_slots_line('pickup');
    $parts = array_map('trim', explode(',', $address, 2));

    ob_start(); ?>
    <div class="li-visit li-visit--page">
        <?php if ($open !== '') : ?>
            <p class="li-visit__open"><span class="li-visit__dot" aria-hidden="true"></span><?php echo esc_html($open); ?></p>
        <?php endif; ?>
        <div class="li-visit__cols">
            <div class="li-visit__col">
                <?php if ($address !== '') : ?>
                    <address class="li-visit__address"><a href="<?php echo esc_url($map); ?>" target="_blank" rel="noopener"><?php echo esc_html($parts[0]); ?><?php if (!empty($parts[1])) : ?><br><?php echo esc_html($parts[1]); ?><?php endif; ?></a></address>
                <?php endif; ?>
                <?php if ($phone !== '') : ?>
                    <p class="li-visit__phone"><a href="<?php echo esc_url(littleinka_tel($phone)); ?>"><?php echo esc_html($phone); ?></a></p>
                <?php endif; ?>
                <?php if ($with_email && $email !== '') : ?>
                    <p class="li-visit__email"><a href="<?php echo esc_url('mailto:' . $email); ?>"><?php echo esc_html($email); ?></a></p>
                <?php endif; ?>
                <?php if ($phone !== '') : ?>
                    <p class="li-visit__call"><a class="li-btn li-btn--secondary" href="<?php echo esc_url(littleinka_tel($phone)); ?>"><?php echo littleinka_icon('phone', 16); // phpcs:ignore WordPress.Security.EscapeOutput ?><?php esc_html_e('Chiama la sede', 'littleinka-child-theme'); ?></a></p>
                <?php endif; ?>
            </div>
            <?php if ($rows) : ?>
                <div class="li-visit__col">
                    <dl class="li-hours">
                        <?php foreach ($rows as $row) : ?>
                            <dt<?php echo !empty($row['today']) ? ' class="is-today"' : ''; ?>><?php echo esc_html($row['days']); ?></dt>
                            <dd<?php echo !empty($row['today']) ? ' class="is-today"' : ''; ?>><?php echo esc_html($row['hours']); ?></dd>
                        <?php endforeach; ?>
                    </dl>
                </div>
            <?php endif; ?>
        </div>
        <?php if ($delivery !== '' || $pickup !== '') : ?>
            <ul class="li-visit__rows">
                <?php if ($delivery !== '') : ?><li><span><?php esc_html_e('Consegna', 'littleinka-child-theme'); ?></span><span><?php echo esc_html($delivery); ?></span></li><?php endif; ?>
                <?php if ($pickup !== '') : ?><li><span><?php esc_html_e('Ritiro', 'littleinka-child-theme'); ?></span><span><?php echo esc_html($pickup); ?></span></li><?php endif; ?>
            </ul>
        <?php endif; ?>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('littleinka_contatti', function () {
    return littleinka_visit_panel(true);
});

// Zone di spedizione e impostazioni di consegna cambiate: si rileggono.
foreach (array('woocommerce_shipping_zone_method_added', 'woocommerce_shipping_zone_method_deleted', 'woocommerce_shipping_zone_method_status_toggled', 'woocommerce_update_shipping_method', 'update_option_coderockz_woo_delivery_option_delivery_settings') as $littleinka_hook) {
    add_action($littleinka_hook, function () {
        delete_transient('littleinka_delivery');
    });
}
unset($littleinka_hook);

/**
 * Le immagini di una galleria del parent (Media → Gallerie media), nell'ordine scelto nel gestore delle gallerie.
 * Usata per la striscia di foto in cima alla home: galleria con slug «striscia-home». Vuota se la galleria non c'è.
 *
 * @return int[] ID degli allegati
 */
function littleinka_gallery_images($slug, $max = 20)
{
    if (!taxonomy_exists('ticinoweb_media_gallery')) {
        return array();
    }
    $term = get_term_by('slug', sanitize_title($slug), 'ticinoweb_media_gallery');
    if (!($term instanceof WP_Term)) {
        return array();
    }
    $ids = get_posts(array(
        'post_type'      => 'attachment',
        'post_status'    => 'inherit',
        'post_mime_type' => 'image',
        'posts_per_page' => (int) $max,
        'fields'         => 'ids',
        'no_found_rows'  => true,
        'tax_query'      => array(array('taxonomy' => 'ticinoweb_media_gallery', 'field' => 'term_id', 'terms' => $term->term_id)),
    ));
    $order = get_term_meta($term->term_id, '_ticinoweb_gallery_order', true);
    if (is_array($order) && $order) {
        usort($ids, function ($a, $b) use ($order) {
            $pa = array_search($a, $order);
            $pb = array_search($b, $order);
            return ($pa === false ? 99999 : $pa) <=> ($pb === false ? 99999 : $pb);
        });
    }
    return array_map('intval', $ids);
}

/**
 * Il sito è il portale di tutte le sedi (littleinka.ch)? Sì se ha schede «Sede» pubblicate
 * (tipo di contenuto «sede», con il link al sito di ogni sede). Le sedi non ce l'hanno.
 */
function littleinka_is_portal()
{
    static $is = null;
    if ($is === null) {
        $is = post_type_exists('sede') && (int) (wp_count_posts('sede')->publish ?? 0) > 0;
    }
    return (bool) apply_filters('littleinka_is_portal', $is);
}

/**
 * Le sedi del portale: [ ['title', 'url', 'consegna' => [nomi], 'offerta' => [nomi], 'delivery' => bool, 'pickup' => bool], … ]
 * dalle schede «Sede» pubblicate (link nel campo «link_per_questa_sede», tipi di consegna e offerta nelle loro tassonomie).
 */
function littleinka_portal_sedi()
{
    $sedi = array();
    foreach (get_posts(array('post_type' => 'sede', 'post_status' => 'publish', 'numberposts' => 30, 'orderby' => array('menu_order' => 'ASC', 'title' => 'ASC'))) as $post) {
        $url = function_exists('get_field') ? (string) get_field('link_per_questa_sede', $post->ID) : '';
        $url = $url !== '' ? $url : (string) get_post_meta($post->ID, 'link_per_questa_sede', true);
        $consegna = wp_get_post_terms($post->ID, 'consegna', array('fields' => 'all'));
        $offerta  = wp_get_post_terms($post->ID, 'offerta', array('fields' => 'all'));
        $consegna = is_wp_error($consegna) ? array() : $consegna;
        $offerta  = is_wp_error($offerta) ? array() : $offerta;
        $slugs    = wp_list_pluck($consegna, 'slug');
        $sedi[] = array(
            'title'    => get_the_title($post),
            'url'      => $url,
            'consegna' => wp_list_pluck($consegna, 'name'),
            'offerta'  => wp_list_pluck($offerta, 'name'),
            'delivery' => in_array('consegna-a-domicilio', $slugs, true),
            'pickup'   => (bool) array_intersect(array('ritiro-in-sede', 'solo-ritiro-in-sede'), $slugs),
        );
    }
    return $sedi;
}

/**
 * Contatti del sito corrente (ticinoWEB CMS → Contatti). Come ticinoweb_get_contact_info(), che però tiene in memoria
 * il primo sito letto: dentro switch_to_blog() (schede delle sedi sul portale) si leggono le opzioni del sottosito.
 */
function littleinka_contact_info()
{
    if (!ms_is_switched()) {
        return function_exists('ticinoweb_get_contact_info') ? ticinoweb_get_contact_info() : array();
    }
    $phone = (string) get_option('ticinoweb_contact_phone', '');
    return array(
        'phone'          => $phone !== '' ? $phone : (string) get_option('ticinoweb_contact_phone_display', ''),
        'phone_landline' => (string) get_option('ticinoweb_contact_phone_landline', ''),
        'email'          => (string) get_option('ticinoweb_contact_email', ''),
        'map_url'        => (string) get_option('ticinoweb_contact_map_url', ''),
        'address'        => (string) get_option('ticinoweb_contact_address', ''),
        'opening_hours'  => get_option('ticinoweb_contact_opening_hours', array()),
    );
}

/** ID del sottosito della rete a cui porta il link di una sede (0 se il link è fuori dalla rete). */
function littleinka_sede_blog_id($url)
{
    if (!is_multisite() || $url === '') {
        return 0;
    }
    $host = (string) wp_parse_url($url, PHP_URL_HOST);
    $port = wp_parse_url($url, PHP_URL_PORT);
    $path = '/' . trim((string) wp_parse_url($url, PHP_URL_PATH), '/') . '/';
    $site = get_site_by_path($host . ($port ? ':' . $port : ''), str_replace('//', '/', $path));
    if (!$site && $port) {
        $site = get_site_by_path($host, str_replace('//', '/', $path));
    }
    return $site ? (int) $site->blog_id : 0;
}

/**
 * Le sedi con i loro contatti, letti dal sottosito di ogni sede (ticinoWEB CMS → Contatti e orari della sede):
 * nessun dato copiato sul portale. [ ['title', 'url', 'address', 'map', 'phone', 'email', 'open', 'hours' => [], 'delivery', 'pickup'], … ]
 */
function littleinka_portal_sedi_contacts()
{
    $out = array();
    foreach (littleinka_portal_sedi() as $sede) {
        $blog = littleinka_sede_blog_id($sede['url']);
        $sede += array('address' => '', 'map' => '', 'phone' => '', 'email' => '', 'open' => '', 'hours' => array());
        if ($blog && $blog !== get_current_blog_id()) {
            switch_to_blog($blog);
            $contact = littleinka_contact_info();
            $address = littleinka_address_line();
            $sede['address'] = $address;
            $sede['map']     = !empty($contact['map_url']) ? (string) $contact['map_url'] : ($address !== '' ? 'https://www.openstreetmap.org/search?query=' . rawurlencode($address) : '');
            $sede['phone']   = trim((string) (($contact['phone_landline'] ?? '') ?: ($contact['phone'] ?? '')));
            $sede['email']   = trim((string) ($contact['email'] ?? ''));
            $sede['open']    = littleinka_open_now_line();
            $sede['is_open'] = (bool) littleinka_open_now()['open'];
            $sede['hours']   = littleinka_hours_rows();
            restore_current_blog();
        }
        $out[] = $sede;
    }
    return $out;
}

/**
 * [littleinka_sedi] sul portale: una scheda per sede con indirizzo, telefono, e-mail, orari e «Ordina online».
 * [littleinka_sedi contatti="no"]: solo nome, indirizzo, consegna o ritiro e «Ordina online» (per Chi siamo).
 */
add_shortcode('littleinka_sedi', function ($atts) {
    $atts = shortcode_atts(array('contatti' => 'si'), $atts, 'littleinka_sedi');
    $full = $atts['contatti'] !== 'no';
    $sedi = littleinka_portal_sedi_contacts();
    if (!$sedi) {
        return '';
    }
    littleinka_enqueue_module_css('sedi');
    ob_start(); ?>
    <ul class="li-sedi<?php echo $full ? '' : ' li-sedi--compact'; ?>">
        <?php foreach ($sedi as $sede) :
            $parts = array_map('trim', explode(',', $sede['address'], 2));
            $modes = array_filter(array($sede['delivery'] ? __('Consegna a domicilio', 'littleinka-child-theme') : '', $sede['pickup'] ? __('Ritiro in sede', 'littleinka-child-theme') : '')); ?>
            <li class="li-sede">
                <h2 class="li-sede__title"><?php echo esc_html($sede['title']); ?></h2>
                <?php if ($full && $sede['open'] !== '') : ?>
                    <p class="li-sede__open<?php echo empty($sede['is_open']) ? ' is-closed' : ''; ?>"><span class="li-visit__dot" aria-hidden="true"></span><?php echo esc_html($sede['open']); ?></p>
                <?php endif; ?>
                <?php if ($sede['address'] !== '') : ?>
                    <address class="li-sede__address"><?php if ($full && $sede['map'] !== '') : ?><a href="<?php echo esc_url($sede['map']); ?>" target="_blank" rel="noopener"><?php endif; ?><?php echo esc_html($parts[0]); ?><?php if (!empty($parts[1])) : ?><br><?php echo esc_html($parts[1]); ?><?php endif; ?><?php if ($full && $sede['map'] !== '') : ?></a><?php endif; ?></address>
                <?php endif; ?>
                <?php if ($full && ($sede['phone'] !== '' || $sede['email'] !== '')) : ?>
                    <p class="li-sede__contact">
                        <?php if ($sede['phone'] !== '') : ?><a href="<?php echo esc_url(littleinka_tel($sede['phone'])); ?>"><?php echo esc_html($sede['phone']); ?></a><?php endif; ?>
                        <?php if ($sede['email'] !== '') : ?><a href="<?php echo esc_url('mailto:' . $sede['email']); ?>"><?php echo esc_html($sede['email']); ?></a><?php endif; ?>
                    </p>
                <?php endif; ?>
                <?php if ($full && $sede['hours']) : ?>
                    <dl class="li-hours li-sede__hours">
                        <?php foreach ($sede['hours'] as $row) : ?>
                            <dt<?php echo !empty($row['today']) ? ' class="is-today"' : ''; ?>><?php echo esc_html($row['days']); ?></dt>
                            <dd<?php echo !empty($row['today']) ? ' class="is-today"' : ''; ?>><?php echo esc_html($row['hours']); ?></dd>
                        <?php endforeach; ?>
                    </dl>
                <?php endif; ?>
                <?php if (!$full && $modes) : ?>
                    <p class="li-sede__modes"><?php echo esc_html(implode(' · ', $modes)); ?></p>
                <?php endif; ?>
                <?php if ($sede['url'] !== '' || ($full && $sede['phone'] !== '')) : ?>
                    <p class="li-sede__actions">
                        <?php if ($sede['url'] !== '') : ?><a class="li-btn li-btn--primary" href="<?php echo esc_url($sede['url']); ?>"><?php esc_html_e('Ordina online', 'littleinka-child-theme'); ?><?php echo littleinka_icon('arrow', 16); // phpcs:ignore WordPress.Security.EscapeOutput ?></a><?php endif; ?>
                        <?php if ($full && $sede['phone'] !== '') : ?><a class="li-btn li-btn--secondary" href="<?php echo esc_url(littleinka_tel($sede['phone'])); ?>"><?php echo littleinka_icon('phone', 16); // phpcs:ignore WordPress.Security.EscapeOutput ?><?php esc_html_e('Chiama', 'littleinka-child-theme'); ?></a><?php endif; ?>
                    </p>
                <?php endif; ?>
            </li>
        <?php endforeach; ?>
    </ul>
    <?php
    return ob_get_clean();
});

// Foglio delle schede delle sedi caricato nella <head> delle pagine che le mostrano (niente salto di stile).
add_action('wp_enqueue_scripts', function () {
    $post = get_queried_object();
    if (is_singular() && $post instanceof WP_Post && has_shortcode((string) $post->post_content, 'littleinka_sedi')) {
        littleinka_enqueue_module_css('sedi');
    }
}, 20);

/* -------------------------------------------------------------------------
 * Sedi: il menu è la home. La vecchia pagina /menu/ porta alla home (301) e le voci di menu che puntano lì
 * vanno alla home, segnate come pagina corrente.
 * ---------------------------------------------------------------------- */
add_action('template_redirect', function () {
    if (is_admin() || is_front_page() || littleinka_is_portal()) {
        return;
    }
    $id = littleinka_page_with_shortcode('littleinka_menu');
    if ($id && is_page($id)) {
        $query = isset($_SERVER['QUERY_STRING']) ? sanitize_text_field(wp_unslash($_SERVER['QUERY_STRING'])) : '';
        wp_safe_redirect(home_url('/') . ($query !== '' ? '?' . $query : ''), 301);
        exit;
    }
});
add_filter('nav_menu_link_attributes', function ($atts, $item) {
    $id = littleinka_page_with_shortcode('littleinka_menu');
    if ($id && (int) $item->object_id === $id && $item->object === 'page' && !littleinka_is_portal()) {
        $atts['href'] = home_url('/');
        if (is_front_page()) {
            $atts['aria-current'] = 'page';
        }
    }
    return $atts;
}, 10, 2);
add_filter('nav_menu_css_class', function ($classes, $item) {
    $id = littleinka_page_with_shortcode('littleinka_menu');
    if ($id && is_front_page() && (int) $item->object_id === $id && $item->object === 'page' && !littleinka_is_portal()) {
        $classes[] = 'current-menu-item';
    }
    return $classes;
}, 10, 2);

/**
 * È la categoria «Senza categoria» di WooCommerce (da non mostrare)? Si guarda lo slug, non l'opzione
 * «categoria predefinita»: sulle sedi Little Inka la predefinita è «Poke Bowl», che invece va nel menu.
 */
function littleinka_is_uncategorized_term($term)
{
    if (!$term instanceof WP_Term) {
        return false;
    }
    $slugs = (array) apply_filters('littleinka_uncategorized_slugs', array('uncategorized', 'senza-categoria', 'non-classe', 'unkategorisiert', 'sin-categoria'));
    return in_array($term->slug, $slugs, true);
}

/** Indirizzo del logo della sede (ticinoWEB CMS) in versione piccola, letto una volta per pagina; '' se manca. */
function littleinka_logo_mark_url()
{
    static $url = null;
    if ($url === null) {
        $url = function_exists('ticinoweb_get_site_logo') ? (string) ticinoweb_get_site_logo() : '';
        // La versione piccola dello stesso logo (l'originale può essere di migliaia di pixel).
        $att = $url !== '' ? attachment_url_to_postid($url) : 0;
        $small = $att ? wp_get_attachment_image_url($att, 'thumbnail') : '';
        if ($small) {
            $url = (string) $small;
        }
    }
    return $url;
}
