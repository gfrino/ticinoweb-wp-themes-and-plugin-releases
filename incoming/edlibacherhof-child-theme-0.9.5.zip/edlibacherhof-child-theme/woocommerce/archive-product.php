<?php
/**
 * Carta per ordinare (sostituisce la griglia del negozio): i piatti raggruppati per categoria, come una carta vera.
 * Pagina Shop = tutte le categorie con una barra per saltare tra loro; pagina di una categoria = solo quella.
 * Piatti con aggiunte (le pizze) → scheda del piatto; gli altri → nel carrello senza cambiare pagina.
 *
 * Basato su WooCommerce templates/archive-product.php 8.6.0 (stessi hook prima e dopo il contenuto).
 *
 * @package edlibacherhof-child-theme
 * @version 8.6.0
 */

defined('ABSPATH') || exit;

get_header('shop');
do_action('woocommerce_before_main_content');

$ed_is_cat = is_product_category();
if ($ed_is_cat) {
    $ed_terms = array(get_queried_object());
} else {
    $ed_terms = get_terms(array(
        'taxonomy'   => 'product_cat',
        'hide_empty' => true,
        'parent'     => 0,
        'orderby'    => 'menu_order',
        'exclude'    => edlibacherhof_hidden_cats(),
    ));
    $ed_terms = is_array($ed_terms) ? $ed_terms : array();
}
$ed_title = $ed_is_cat ? single_term_title('', false) : (edlibacherhof_text('shop_title') ?: __('Speisekarte', 'edlibacherhof-child-theme'));
$ed_intro = $ed_is_cat ? '' : edlibacherhof_text('shop_text');
?>
<header class="ed-carta-ordine__testa">
    <h1><?php echo esc_html($ed_title); ?></h1>
    <?php if ($ed_intro !== '') : ?><p class="ed-lead"><?php echo esc_html($ed_intro); ?></p><?php endif; ?>
</header>

<?php if (!$ed_is_cat && count($ed_terms) > 1) : ?>
    <nav class="ed-categorie" aria-label="<?php esc_attr_e('Kategorien', 'edlibacherhof-child-theme'); ?>">
        <ul role="list">
            <?php foreach ($ed_terms as $ed_term) : ?>
                <li><a href="#<?php echo esc_attr('kat-' . $ed_term->slug); ?>"><?php echo edlibacherhof_categoria_icona($ed_term); // phpcs:ignore WordPress.Security.EscapeOutput ?><?php echo esc_html(edlibacherhof_t($ed_term->name, 'cat:' . $ed_term->term_id)); ?></a></li>
            <?php endforeach; ?>
        </ul>
        <?php // Frecce ai bordi: compaiono solo quando la riga scorre e c'è altro da quella parte (site.js). ?>
        <button type="button" class="ed-categorie__freccia ed-categorie__freccia--indietro" data-ed-cat-scorri="-1" hidden><svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M15 6l-6 6 6 6"/></svg><span class="ed-categorie__testo"><?php esc_html_e('Vorherige Kategorien', 'edlibacherhof-child-theme'); ?></span></button>
        <button type="button" class="ed-categorie__freccia ed-categorie__freccia--avanti" data-ed-cat-scorri="1" hidden><svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M9 6l6 6-6 6"/></svg><span class="ed-categorie__testo"><?php esc_html_e('Weitere Kategorien', 'edlibacherhof-child-theme'); ?></span></button>
    </nav>
<?php endif; ?>

<?php woocommerce_output_all_notices(); ?>

<?php foreach ($ed_terms as $ed_term) : ?>
    <?php
    $ed_products = wc_get_products(array(
        'status'   => 'publish',
        'limit'    => -1,
        'category' => array($ed_term->slug),
        'orderby'  => array('menu_order' => 'ASC', 'title' => 'ASC'),
        'visibility' => 'catalog',
    ));
    if (!$ed_products) {
        continue;
    }
    ?>
    <section class="ed-gruppo" id="<?php echo esc_attr('kat-' . $ed_term->slug); ?>" aria-labelledby="<?php echo esc_attr('kat-t-' . $ed_term->slug); ?>">
        <?php if (!$ed_is_cat) : ?>
            <h2 id="<?php echo esc_attr('kat-t-' . $ed_term->slug); ?>"><?php echo esc_html(edlibacherhof_t($ed_term->name, 'cat:' . $ed_term->term_id)); ?></h2>
        <?php else : ?>
            <h2 class="ed-nascosto" id="<?php echo esc_attr('kat-t-' . $ed_term->slug); ?>"><?php echo esc_html($ed_term->name); ?></h2>
        <?php endif; ?>
        <?php if (trim((string) $ed_term->description) !== '') : ?>
            <p class="ed-gruppo__nota"><?php echo esc_html(edlibacherhof_t(wp_strip_all_tags($ed_term->description), 'cat:desc:' . $ed_term->term_id)); ?></p>
        <?php endif; ?>
        <?php
        // Se nel gruppo almeno un piatto ha la foto, tutti tengono la colonna della foto: chi non ce l'ha mostra un
        // riquadro con l'icona della categoria, così nomi e bottoni restano allineati.
        $ed_con_foto = false;
        foreach ($ed_products as $ed_product) {
            if ($ed_product->get_image_id()) {
                $ed_con_foto = true;
                break;
            }
        }
        ?>
        <ul class="ed-piatti" role="list">
            <?php foreach ($ed_products as $ed_product) : ?>
                <?php edlibacherhof_menu_row($ed_product, $ed_con_foto ? $ed_term : null); ?>
            <?php endforeach; ?>
        </ul>
    </section>
<?php endforeach; ?>

<?php
do_action('woocommerce_after_main_content');
get_footer('shop');
