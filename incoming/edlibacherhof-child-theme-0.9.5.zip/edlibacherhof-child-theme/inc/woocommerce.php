<?php
/**
 * Pagine del negozio dentro il sistema del tema: contenitore e ritmo della home, niente barra laterale.
 * Il disegno della pagina per ordinare (carta con aggiunte e orari di ritiro) è un passo successivo.
 *
 * @package edlibacherhof-child-theme
 */

defined('ABSPATH') || exit;

if (!class_exists('WooCommerce')) {
    return;
}

remove_action('woocommerce_before_main_content', 'woocommerce_output_content_wrapper', 10);
remove_action('woocommerce_after_main_content', 'woocommerce_output_content_wrapper_end', 10);
remove_action('woocommerce_sidebar', 'woocommerce_get_sidebar', 10);

/** Foto del piatto ferma: niente zoom al passaggio né lente per ingrandirla (il parent le accende per tutti i negozi). */
add_action('after_setup_theme', function () {
    remove_theme_support('wc-product-gallery-zoom');
    remove_theme_support('wc-product-gallery-lightbox');
}, 100); // dopo il parent (priorità 20), che si carica dopo il child
add_filter('woocommerce_single_product_zoom_enabled', '__return_false');
add_filter('woocommerce_single_product_photoswipe_enabled', '__return_false');

add_action('woocommerce_before_main_content', function () {
    echo '<main id="inhalt" class="ed-pagina ed-negozio"><div class="ed-contenitore">';
}, 10);
add_action('woocommerce_after_main_content', function () {
    echo '</div></main>';
}, 10);

/** Quattro prodotti per riga su computer (il CSS li riduce su tablet e telefono), 24 per pagina. */
add_filter('loop_shop_columns', function () {
    return 4;
});
add_filter('loop_shop_per_page', function () {
    return 24;
});

/** In Svizzera i prezzi si scrivono «Fr. 17.00»: simbolo e posizione per il franco. */
add_filter('woocommerce_currency_symbol', function ($symbol, $currency) {
    return $currency === 'CHF' ? 'Fr.' : $symbol;
}, 10, 2);
add_filter('pre_option_woocommerce_currency_pos', function () {
    return get_woocommerce_currency() === 'CHF' ? 'left_space' : false;
});

/**
 * Icona della categoria nella barra della carta (famiglia del tema, assets/icons). Le categorie del sito vecchio
 * hanno slug misti italiano/tedesco: la tabella li lega all'icona; una categoria nuova senza voce resta senza icona.
 * Filtro «edlibacherhof_icone_categorie» per aggiungerne.
 */
function edlibacherhof_categoria_icona($term)
{
    $mappa = apply_filters('edlibacherhof_icone_categorie', array(
        'le-pizze'         => 'pizza',
        'nudelgerichte'    => 'pasta',
        'secondi-piatti'   => 'carne',
        'salate'           => 'insalata',
        'suppen'           => 'zuppa',
        'dessert'          => 'dessert',
        'unsere-eisbecher' => 'gelato',
        'bibite'           => 'bevande',
        'unser-weinkeller' => 'vino',
    ));
    $nome = ($term instanceof WP_Term && isset($mappa[$term->slug])) ? $mappa[$term->slug] : '';
    return ($nome !== '' && function_exists('edlibacherhof_icona')) ? edlibacherhof_icona($nome, array('classe' => 'ed-categorie__icona')) : '';
}

/** Il piatto ha aggiunte da scegliere (proprie o globali di Product Add-ons)? */
function edlibacherhof_has_addons($product_id)
{
    if (class_exists('WC_Product_Addons_Helper') && method_exists('WC_Product_Addons_Helper', 'get_product_addons')) {
        return (bool) WC_Product_Addons_Helper::get_product_addons((int) $product_id);
    }
    return (bool) get_post_meta((int) $product_id, '_product_addons', true);
}

/**
 * Descrizione del piatto per la carta: il testo del prodotto (in tedesco), altrimenti il riassunto; senza HTML,
 * intera (l'utente la vuole completa: niente «…»).
 */
function edlibacherhof_dish_text(WC_Product $product)
{
    $text = trim(wp_strip_all_tags((string) $product->get_description()));
    if ($text === '') {
        $text = trim(wp_strip_all_tags((string) $product->get_short_description()));
    }
    $text = preg_replace('/\s+/u', ' ', $text);
    return $text === '' ? '' : edlibacherhof_t($text, 'dish:' . $product->get_id());
}

/**
 * Una riga della carta: foto piccola (se c'è), nome, descrizione, prezzo, bottone.
 * Le schede dei piatti non si aprono: niente link. I piatti con aggiunte si scelgono in un popup sulla carta.
 */
/**
 * Una riga della carta. Con $segnaposto (la categoria del gruppo) un piatto senza foto mostra al suo posto un
 * riquadro con l'icona della categoria, per restare allineato agli altri del gruppo.
 */
function edlibacherhof_menu_row(WC_Product $product, $segnaposto = null)
{
    $id       = $product->get_id();
    $choose   = edlibacherhof_has_addons($id) || !$product->is_type('simple');
    $can_buy  = $product->is_purchasable() && $product->is_in_stock();
    $name     = edlibacherhof_t($product->get_name(), 'dish:name:' . $id);
    // Le etichette dei bottoni si compongono con il nome originale: tW Translate traduce la frase intera
    // («Bismarck in den Warenkorb» → «Aggiungi «Bismarck» al carrello»), senza frasi miste.
    $raw_name = $product->get_name();
    $thumb_id = (int) $product->get_image_id();
    $vuota    = !$thumb_id && $segnaposto instanceof WP_Term;
    ?>
    <li class="ed-piatto<?php echo ($thumb_id || $vuota) ? ' ed-piatto--foto' : ''; ?>">
        <?php if ($thumb_id) : ?>
            <span class="ed-piatto__foto" aria-hidden="true"><?php echo wp_get_attachment_image($thumb_id, 'woocommerce_thumbnail', false, array('alt' => '', 'loading' => 'lazy', 'decoding' => 'async', 'sizes' => '72px')); // phpcs:ignore WordPress.Security.EscapeOutput ?></span>
        <?php elseif ($vuota) : ?>
            <span class="ed-piatto__foto ed-piatto__foto--vuota" aria-hidden="true"><?php echo edlibacherhof_categoria_icona($segnaposto); // phpcs:ignore WordPress.Security.EscapeOutput ?></span>
        <?php endif; ?>
        <div class="ed-piatto__testo">
            <h3 class="ed-piatto__nome"><?php echo esc_html($name); ?></h3>
            <?php if (($desc = edlibacherhof_dish_text($product)) !== '') : ?><p class="ed-piatto__desc"><?php echo esc_html($desc); ?></p><?php endif; ?>
        </div>
        <p class="ed-piatto__prezzo"><?php echo wp_kses_post($product->get_price_html()); ?></p>
        <div class="ed-piatto__azione">
            <?php if (!$can_buy) : ?>
                <span class="ed-piatto__esaurito"><?php esc_html_e('Nicht verfügbar', 'edlibacherhof-child-theme'); ?></span>
            <?php elseif ($choose) : ?>
                <button type="button" class="ed-bottone ed-bottone--linea" data-ed-scegli="<?php echo esc_attr((string) $id); ?>" aria-haspopup="dialog" aria-label="<?php echo esc_attr(sprintf(__('%s auswählen', 'edlibacherhof-child-theme'), $raw_name)); ?>"><?php esc_html_e('Auswählen', 'edlibacherhof-child-theme'); ?></button>
            <?php else : ?>
                <a class="ed-bottone ed-bottone--pieno add_to_cart_button ajax_add_to_cart" href="<?php echo esc_url($product->add_to_cart_url()); ?>" data-quantity="1" data-product_id="<?php echo esc_attr((string) $id); ?>" data-product_sku="<?php echo esc_attr($product->get_sku()); ?>" rel="nofollow" aria-label="<?php echo esc_attr(sprintf(__('%s in den Warenkorb', 'edlibacherhof-child-theme'), $raw_name)); ?>"><?php esc_html_e('Hinzufügen', 'edlibacherhof-child-theme'); ?></a>
            <?php endif; ?>
        </div>
    </li>
    <?php
}

/** Il carrello nella testata: numero dei piatti, aggiornato da WooCommerce dopo ogni aggiunta (frammenti). */
function edlibacherhof_cart_link()
{
    if (!function_exists('WC') || !WC()->cart) {
        return '';
    }
    $n = (int) WC()->cart->get_cart_contents_count();
    return '<a class="ed-testata__carrello' . ($n ? '' : ' ed-vuoto') . '" href="' . esc_url(wc_get_cart_url()) . '" aria-label="' . esc_attr(sprintf(_n('Warenkorb, %d Artikel', 'Warenkorb, %d Artikel', $n, 'edlibacherhof-child-theme'), $n)) . '">'
        . '<span class="ed-testata__parola">' . esc_html__('Warenkorb', 'edlibacherhof-child-theme') . '</span> <span class="ed-testata__n">' . $n . '</span></a>';
}
/**
 * Carrello fluttuante: pillola in basso a destra con borsa, numero dei piatti e totale, che porta al carrello.
 * Nascosto quando il carrello è vuoto e nelle pagine Carrello e Cassa (lì c'è già tutto). Aggiornato dai frammenti.
 */
function edlibacherhof_cart_float()
{
    if (!function_exists('WC') || !WC()->cart) {
        return '';
    }
    $n       = (int) WC()->cart->get_cart_contents_count();
    $nascosto = !$n || is_cart() || is_checkout();
    return '<a class="ed-carrello-flottante' . ($nascosto ? ' ed-vuoto' : '') . '" href="' . esc_url(wc_get_cart_url()) . '"' . ($nascosto ? ' hidden' : '') . '>'
        . '<span class="ed-carrello-flottante__borsa">' . edlibacherhof_icona('carrello') . '<span class="ed-carrello-flottante__n">' . $n . '</span></span>'
        . '<span class="ed-carrello-flottante__testo"><span class="ed-carrello-flottante__nome">' . esc_html__('Warenkorb', 'edlibacherhof-child-theme') . '</span>'
        . '<span class="ed-carrello-flottante__totale">' . wp_kses_post(WC()->cart->get_cart_subtotal()) . '</span></span>'
        . '<svg class="ed-carrello-flottante__freccia" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M5 12h14M13 6l6 6-6 6"/></svg>'
        . '</a>';
}
add_action('wp_footer', function () {
    echo edlibacherhof_cart_float(); // phpcs:ignore WordPress.Security.EscapeOutput -- costruito con esc_*
}, 5);

add_filter('woocommerce_add_to_cart_fragments', function ($fragments) {
    $fragments['a.ed-carrello-flottante'] = edlibacherhof_cart_float();
    $fragments['a.ed-testata__carrello'] = edlibacherhof_cart_link();
    return $fragments;
});

/** Sulla carta (pagina Shop) il percorso «Start / Speisekarte» non serve: c'è già il titolo. */
add_action('template_redirect', function () {
    if (function_exists('is_shop') && is_shop()) {
        remove_action('woocommerce_before_main_content', 'woocommerce_breadcrumb', 20);
    }
});

/**
 * Le schede dei piatti non esistono per il cliente: si ordina solo dalla carta. Chi arriva su una scheda
 * (vecchi link, motori di ricerca) torna alla carta, al gruppo del piatto. In amministrazione l'anteprima resta.
 */
add_action('template_redirect', function () {
    if (!is_product() || is_preview() || (current_user_can('edit_products') && isset($_GET['ed-anteprima']))) { // phpcs:ignore WordPress.Security.NonceVerification
        return;
    }
    $url   = wc_get_page_permalink('shop');
    $terms = get_the_terms(get_queried_object_id(), 'product_cat');
    if (is_array($terms) && $terms) {
        $url .= '#kat-' . $terms[0]->slug;
    }
    wp_safe_redirect($url, 301);
    exit;
});
/** Nemmeno la mappa del sito (sitemap di WordPress) le elenca. */
add_filter('wp_sitemaps_post_types', function ($types) {
    unset($types['product']);
    return $types;
});
/** Nel carrello, nella cassa e negli ordini il nome del piatto non è più un link alla scheda. */
add_filter('woocommerce_cart_item_permalink', '__return_false');
add_filter('woocommerce_order_item_permalink', '__return_false');

/**
 * Popup per scegliere le aggiunte (pagina Shop e pagine delle categorie). Il contenuto arriva al clic da
 * ?wc-ajax=ed_scelta&id=…: foto, nome, descrizione, il modulo di WooCommerce con le aggiunte di Product Add-ons.
 */
function edlibacherhof_is_carta()
{
    return function_exists('is_shop') && (is_shop() || is_product_taxonomy());
}

add_action('wp_enqueue_scripts', function () {
    if (!edlibacherhof_is_carta()) {
        return;
    }
    // Product Add-ons accoda gli stili solo su Shop e schede: servono anche nelle pagine delle categorie.
    if (defined('WC_PRODUCT_ADDONS_PLUGIN_URL') && defined('WC_PRODUCT_ADDONS_VERSION')) {
        wp_enqueue_style('woocommerce-addons-css', WC_PRODUCT_ADDONS_PLUGIN_URL . '/assets/css/frontend/frontend.css', array('dashicons'), WC_PRODUCT_ADDONS_VERSION);
    }
    wp_enqueue_script('jquery');
    wp_localize_script('edlibacherhof-site', 'edlibacherhofScelta', array(
        'scelta'   => WC_AJAX::get_endpoint('ed_scelta'),
        'aggiungi' => WC_AJAX::get_endpoint('ed_aggiungi'),
    ));
}, 30);

/** Il popup vuoto e le frasi che usa lo script (nell'HTML, così tW Translate le traduce con la pagina). */
add_action('wp_footer', function () {
    if (!edlibacherhof_is_carta()) {
        return;
    }
    ?>
    <dialog class="ed-scelta ed-negozio" aria-labelledby="ed-scelta-titolo" data-lenis-prevent>
        <button type="button" class="ed-scelta__chiudi" data-ed-chiudi aria-label="<?php esc_attr_e('Schliessen', 'edlibacherhof-child-theme'); ?>">
            <svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true" focusable="false" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg>
        </button>
        <div class="ed-scelta__corpo" aria-live="polite"></div>
        <div class="ed-nascosto" data-ed-frasi>
            <span data-f="carica"><?php esc_html_e('Wird geladen …', 'edlibacherhof-child-theme'); ?></span>
            <span data-f="errore"><?php esc_html_e('Das hat nicht geklappt. Bitte versuchen Sie es noch einmal.', 'edlibacherhof-child-theme'); ?></span>
            <span data-f="aggiunto"><?php esc_html_e('ist im Warenkorb.', 'edlibacherhof-child-theme'); ?></span>
            <span data-f="continua"><?php esc_html_e('Weiter bestellen', 'edlibacherhof-child-theme'); ?></span>
            <span data-f="carrello"><?php esc_html_e('Zum Warenkorb', 'edlibacherhof-child-theme'); ?></span>
        </div>
        <a class="ed-nascosto" data-ed-carrello href="<?php echo esc_url(wc_get_cart_url()); ?>"></a>
    </dialog>
    <?php
});

/** Contenuto del popup per un piatto. */
add_action('wc_ajax_ed_scelta', function () {
    $id      = isset($_GET['id']) ? absint($_GET['id']) : 0; // phpcs:ignore WordPress.Security.NonceVerification
    $product = $id ? wc_get_product($id) : null;
    if (!$product || $product->get_status() !== 'publish' || !$product->is_purchasable() || !$product->is_in_stock()) {
        status_header(404);
        exit;
    }
    nocache_headers();
    header('Content-Type: text/html; charset=utf-8');

    global $post;
    $post = get_post($id); // phpcs:ignore WordPress.WP.GlobalVariablesOverride
    setup_postdata($post);
    $GLOBALS['product'] = $product;

    $name  = edlibacherhof_t($product->get_name(), 'dish:name:' . $id);
    $desc  = trim(preg_replace('/\s+/u', ' ', wp_strip_all_tags((string) $product->get_description())));
    $desc  = $desc !== '' ? $desc : trim(wp_strip_all_tags((string) $product->get_short_description()));
    $thumb = (int) $product->get_image_id();
    ?>
    <article class="ed-scelta__piatto">
        <?php // Foto piccola a sinistra del titolo, come nelle righe della carta (niente foto grande in testa). ?>
        <header class="ed-scelta__testa<?php echo $thumb ? ' ed-scelta__testa--foto' : ''; ?>">
            <?php if ($thumb) : ?>
                <div class="ed-scelta__foto"><?php echo wp_get_attachment_image($thumb, 'woocommerce_thumbnail', false, array('alt' => '', 'decoding' => 'async', 'sizes' => '88px')); // phpcs:ignore WordPress.Security.EscapeOutput ?></div>
            <?php endif; ?>
            <div class="ed-scelta__nome">
                <h2 id="ed-scelta-titolo"><?php echo esc_html($name); ?></h2>
                <p class="ed-scelta__prezzo"><?php echo wp_kses_post($product->get_price_html()); ?></p>
            </div>
            <?php if ($desc !== '') : ?><p class="ed-scelta__desc"><?php echo esc_html(edlibacherhof_t($desc, 'dish:' . $id)); ?></p><?php endif; ?>
        </header>
        <?php woocommerce_template_single_add_to_cart(); ?>
    </article>
    <?php
    wp_reset_postdata();
    exit;
});

/**
 * Aggiunta al carrello dal popup: stessi controlli del modulo della scheda (Product Add-ons legge i campi
 * dalla richiesta). Risponde con i frammenti del carrello, oppure con gli errori da mostrare nel popup.
 */
add_action('wc_ajax_ed_aggiungi', function () {
    $id  = isset($_POST['product_id']) ? absint($_POST['product_id']) : 0; // phpcs:ignore WordPress.Security.NonceVerification
    $qty = isset($_POST['quantity']) ? wc_stock_amount(wp_unslash($_POST['quantity'])) : 1; // phpcs:ignore WordPress.Security.NonceVerification
    $qty = max(1, (int) $qty);
    $product = $id ? wc_get_product($id) : null;
    $ok = $product && $product->is_purchasable() && apply_filters('woocommerce_add_to_cart_validation', true, $id, $qty) // phpcs:ignore WooCommerce.Commenting.CommentHooks
        && WC()->cart->add_to_cart($id, $qty) !== false;
    if ($ok) {
        wc_clear_notices();
        do_action('woocommerce_ajax_added_to_cart', $id); // phpcs:ignore WooCommerce.Commenting.CommentHooks
        WC_AJAX::get_refreshed_fragments(); // risponde ed esce
    }
    $msgs = array_map(function ($n) {
        return wp_strip_all_tags(is_array($n) ? $n['notice'] : (string) $n);
    }, wc_get_notices('error'));
    wc_clear_notices();
    wp_send_json(array('error' => true, 'messages' => array_values($msgs)));
});

/** Product Add-ons non ha la traduzione tedesca: le poche parole che vede il cliente. */
add_filter('gettext_woocommerce-product-addons', function ($translation, $text) {
    static $de = array('Subtotal' => 'Zwischensumme', 'Options total' => 'Optionen gesamt', 'Grand total' => 'Gesamtsumme');
    return (strpos(determine_locale(), 'de_') === 0 && isset($de[$text])) ? $de[$text] : $translation;
}, 10, 2);

/**
 * tW Translate: dopo l'ordine la pagina di conferma perde il prefisso della lingua (/it/) e si apre in tedesco.
 * Si riporta nella lingua di chi ha ordinato (come su Sam Sweet Lab).
 */
add_filter('woocommerce_get_checkout_order_received_url', function ($url) {
    if (!function_exists('twtr_get_language_url') || !function_exists('twtr_get_current_language')) {
        return $url;
    }
    return twtr_get_language_url(twtr_get_current_language(), $url);
});

/**
 * WooDelivery (CodeRockz) prende etichette e avvisi dalle sue impostazioni e alcuni li inserisce con JavaScript,
 * dove tW Translate non arriva: nelle pagine in un'altra lingua i testi delle impostazioni passano dal livello
 * di traduzione (contesto «edlibacherhof:woodelivery:<chiave>»). Solo sul sito, mai in amministrazione.
 */
foreach (array('coderockz_woo_delivery_option_delivery_settings', 'coderockz_woo_delivery_localization_settings', 'coderockz_woo_delivery_pickup_date_settings', 'coderockz_woo_delivery_pickup_time_settings', 'coderockz_woo_delivery_date_settings', 'coderockz_woo_delivery_time_settings') as $edlibacherhof_opt) {
    add_filter('option_' . $edlibacherhof_opt, function ($value) use ($edlibacherhof_opt) {
        if ((is_admin() && !wp_doing_ajax()) || !is_array($value) || !function_exists('twtr_get_current_language') || !class_exists('Twtr_Settings')
            || twtr_get_current_language() === Twtr_Settings::default_lang()) {
            return $value;
        }
        // Calendario nella lingua della pagina (mesi e giorni), non quello delle impostazioni (de).
        if (isset($value['calendar_locale']) && $value['calendar_locale'] !== '') {
            $value['calendar_locale'] = twtr_get_current_language();
        }
        foreach ($value as $k => $v) {
            if (is_string($v) && preg_match('/\p{L}{3,}/u', $v) && !preg_match('/^[a-z0-9_\-]+$/', $v)) {
                $value[$k] = edlibacherhof_t($v, 'woodelivery:' . $k);
            }
        }
        return $value;
    });
}

/** Croce del carrello disegnata (non il carattere × del font, che non sta mai al centro del tondo). */
add_filter('woocommerce_cart_item_remove_link', function ($link) {
    $croce = '<svg viewBox="0 0 24 24" width="16" height="16" aria-hidden="true" focusable="false" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg>';
    return str_replace('&times;', $croce, (string) $link);
});

/**
 * Titolo «Extras» sopra i gruppi di aggiunte (Carne, Pesce, Formaggi…): senza, le tendine non si capiva che
 * fossero aggiunte a pagamento. Prima di Product Add-ons (priorità 10), solo se il piatto ha aggiunte.
 */
add_action('woocommerce_before_add_to_cart_button', function () {
    global $product;
    if (!($product instanceof WC_Product) || !edlibacherhof_has_addons($product->get_id())) {
        return;
    }
    echo '<div class="ed-extra-testa"><h3>' . esc_html__('Extras', 'edlibacherhof-child-theme') . '</h3>'
        . '<p>' . esc_html__('Nach Wunsch, gegen Aufpreis. Tippen Sie auf eine Gruppe, um sie zu öffnen.', 'edlibacherhof-child-theme') . '</p></div>';
}, 5);

/*
 * Quantità e «In den Warenkorb» in un solo blocco: nel popup resta attaccato al fondo mentre si scorrono gli extra.
 * (Ordine del modulo semplice: extra di Product Add-ons → quantità → bottone.)
 */
add_action('woocommerce_before_add_to_cart_quantity', function () {
    echo '<div class="ed-compra">';
}, 1);
add_action('woocommerce_after_add_to_cart_button', function () {
    echo '</div>';
}, 99);
