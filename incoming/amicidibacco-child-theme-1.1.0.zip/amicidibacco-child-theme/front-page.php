<?php
/* THESIS: An enoteca in motion, with the bottle and its own information travelling together.
 * OWN-WORLD: Real vineyards, ivory paper labels, wine ink and quiet calligraphy.
 * STORY: Choose a wine, enter its landscape, meet the people, and return to buying.
 * FIRST VIEWPORT: Separated bottles on a large left arc, selected wine at minimum x;
 * editorial copy and shop action on the right, the cursive name already in the scene.
 * FORM: One connected opening camera, then ordinary editorial flow and a complete producer index.
 */
defined('ABSPATH') || exit;
get_header();
$orbit_ids = (array) adb_home('hero_orbit_ids', []);
if (!$orbit_ids) { $orbit_ids = [absint(adb_home('hero_product_id'))]; }
$hero_products = adb_products(['ids' => $orbit_ids, 'limit' => 5]);
$producers = adb_wineries([], -1);
$selected = adb_products(['ids' => (array) adb_home('selection_ids', []), 'limit' => 4]);
$wineries = adb_wineries((array) adb_home('winery_ids', []), 6);
?>
<main id="main-content" class="adb-home">
    <section class="adb-opening" data-opening>
        <div class="adb-opening__stage" data-opening-stage>
            <div class="adb-opening__landscape" data-hero-landscape><?php adb_photo(adb_home('hero_image_id'), 'full', ['loading' => 'eager', 'fetchpriority' => 'high', 'decoding' => 'async', 'sizes' => '100vw']); ?></div>
            <div class="adb-opening__shade"></div>
            <section class="adb-hero" data-hero aria-label="<?php echo esc_attr(get_bloginfo('name')); ?>">
                <div class="adb-hero__copy">
                    <p class="adb-hero__eyebrow"><?php echo esc_html(adb_home('hero_eyebrow')); ?></p>
                    <?php adb_heading(adb_home('hero_title'), 'h1', 'adb-hero__title'); ?>
                    <p class="adb-hero__text"><?php echo esc_html(adb_home('hero_text')); ?></p>
                    <div class="adb-hero__links"><a class="adb-button adb-button--light" href="<?php echo esc_url(adb_catalog_url()); ?>"><?php echo esc_html(adb_home('hero_link_label') ?: __('Scopri i vini', 'amicidibacco')); ?> <?php echo adb_icon(); ?></a><a class="adb-text-link" href="#il-nostro-mondo"><?php esc_html_e('Il nostro mondo', 'amicidibacco'); ?> <?php echo adb_icon('down'); ?></a></div>
                    <p class="adb-hero__note"><?php echo esc_html(adb_home('hero_note')); ?></p>
                </div>
                <?php if ($hero_products) : ?>
                <div class="adb-orbit" data-orbit aria-label="<?php esc_attr_e('Vini da scoprire', 'amicidibacco'); ?>">
                    <div class="adb-orbit__field" data-orbit-field>
                        <?php foreach ($hero_products as $index => $wine) : $angle = M_PI + $index * 2 * M_PI / count($hero_products); $depth=(1-cos($angle))/2; ?>
                        <a class="adb-orbit__bottle<?php echo !$index ? ' is-active' : ''; ?>" data-orbit-bottle="<?php echo esc_attr($index); ?>" href="<?php echo esc_url($wine->get_permalink()); ?>" aria-label="<?php echo esc_attr($wine->get_name()); ?>" style="--bottle-x:<?php echo esc_attr(round(cos($angle),4)); ?>;--bottle-y:<?php echo esc_attr(round(sin($angle),4)); ?>;--bottle-scale:<?php echo esc_attr(round(.58+.64*$depth,4)); ?>;--bottle-opacity:<?php echo esc_attr(round(.45+.55*$depth,4)); ?>">
                            <?php echo $wine->get_image('full', ['loading' => 'eager', 'decoding' => 'async', 'alt' => '']); ?>
                            <span class="adb-orbit__caption<?php echo !$index ? ' is-active' : ''; ?>" data-orbit-caption="<?php echo esc_attr($index); ?>"<?php if ($index) { echo ' aria-hidden="true"'; } ?>>
                                <span class="adb-orbit__category"><?php echo esc_html(adb_product_category_label($wine)); ?></span>
                                <strong><?php echo esc_html($wine->get_name()); ?></strong>
                                <span class="adb-orbit__price"><span><?php echo wp_kses_post($wine->get_price_html()); ?></span> <?php echo adb_icon(); ?></span>
                            </span>
                        </a>
                        <?php endforeach; ?>
                    </div>
                    <?php if(count($hero_products)>1) : ?><div class="adb-orbit__controls"><button type="button" data-orbit-prev aria-label="<?php esc_attr_e('Vino precedente','amicidibacco'); ?>"><?php echo adb_icon('arrow'); ?></button><button type="button" data-orbit-pause aria-pressed="false" aria-label="<?php esc_attr_e('Ferma la rotazione','amicidibacco'); ?>" title="<?php esc_attr_e('Ferma la rotazione','amicidibacco'); ?>"><span data-orbit-pause-icon="pause"><?php echo adb_icon('pause'); ?></span><span data-orbit-pause-icon="play"><?php echo adb_icon('play'); ?></span></button><button type="button" data-orbit-next aria-label="<?php esc_attr_e('Vino successivo','amicidibacco'); ?>"><?php echo adb_icon('arrow'); ?></button></div><?php endif; ?>
                </div>
                <?php endif; ?>
                <p class="adb-hero__caption"><?php echo esc_html(adb_home('hero_image_caption')); ?></p>
            </section>
            <section id="il-nostro-mondo" class="adb-opening__intro" data-opening-intro aria-label="<?php echo esc_attr(adb_home('intro_title')); ?>">
                <div class="adb-opening__story"><p class="adb-kicker"><?php echo esc_html(adb_home('intro_eyebrow')); ?></p><?php adb_heading(adb_home('intro_title'),'h2','adb-intro__title'); ?><p><?php echo esc_html(adb_home('intro_text')); ?></p></div>
            </section>
            <div class="adb-entry" data-entry aria-hidden="true">
                <svg viewBox="0 0 1440 900" preserveAspectRatio="xMidYMid slice" xmlns="http://www.w3.org/2000/svg">
                    <defs><mask id="adb-letter-door" maskUnits="userSpaceOnUse" x="0" y="0" width="1440" height="900" style="mask-type:luminance"><rect width="1440" height="900" fill="white"/><g data-portal-cut><text class="adb-entry__type" fill="black" text-anchor="middle"><?php echo esc_html(get_bloginfo('name')); ?></text></g></mask></defs>
                    <rect data-entry-paper width="1440" height="900" fill="var(--adb-paper)" mask="url(#adb-letter-door)"/>
                    <g data-portal-ink><text class="adb-entry__type" fill="var(--adb-paper)" text-anchor="middle"><?php echo esc_html(get_bloginfo('name')); ?></text></g>
                </svg>
            </div>
        </div>
    </section>

    <nav class="adb-categories adb-wrap" aria-label="<?php esc_attr_e('Esplora per tipologia', 'amicidibacco'); ?>">
        <span><?php esc_html_e('Cosa ti va di scoprire?', 'amicidibacco'); ?></span>
        <?php foreach ((array) adb_home('category_ids', []) as $term_id) : $term = get_term(absint($term_id), 'product_cat'); if (!$term || is_wp_error($term)) { continue; } ?><a href="<?php echo esc_url(get_term_link($term)); ?>"><?php echo esc_html($term->name); ?> <span>↗</span></a><?php endforeach; ?>
    </nav>

    <?php if ($selected) : ?>
    <section class="adb-selection adb-wrap" aria-labelledby="adb-selection-title">
        <div class="adb-section-heading"><div><p class="adb-kicker"><?php echo esc_html(adb_home('selection_eyebrow')); ?></p><h2 id="adb-selection-title"><?php echo esc_html(adb_home('selection_title')); ?></h2></div><a class="adb-link" href="<?php echo esc_url(adb_catalog_url()); ?>"><?php esc_html_e('Tutti i vini', 'amicidibacco'); ?> <?php echo adb_icon(); ?></a></div>
        <p class="adb-selection__text"><?php echo esc_html(adb_home('selection_text')); ?></p>
        <div class="adb-product-grid"><?php foreach ($selected as $product) { adb_product_card($product); } ?></div>
    </section>
    <?php endif; ?>

    <section class="adb-journey" data-journey aria-labelledby="adb-journey-title">
        <div class="adb-journey__stage">
            <?php foreach (array_slice(adb_journey_images(), 0, 3) as $index => $image_id) : ?><div class="adb-journey__photo <?php echo $index ? 'adb-journey__photo--next' : ''; ?>" data-journey-photo="<?php echo esc_attr($index); ?>"><?php adb_photo($image_id, 'full', ['loading' => 'lazy', 'sizes' => '(max-width:900px) 1050px, 110vw']); ?></div><?php endforeach; ?>
            <div class="adb-journey__shade"></div>
            <div class="adb-journey__copy"><p class="adb-kicker"><?php echo esc_html(adb_home('journey_eyebrow')); ?></p><?php adb_heading(adb_home('journey_title'), 'h2', 'adb-journey__title'); ?><p><?php echo esc_html(adb_home('journey_text')); ?></p><a class="adb-button adb-button--light" href="<?php echo esc_url(adb_page_link('wineries_page_id', '/produttori/')); ?>"><?php esc_html_e('Incontra le cantine', 'amicidibacco'); ?> <?php echo adb_icon(); ?></a></div>
            <div class="adb-journey__words" aria-hidden="true"><span><?php echo esc_html(adb_home('journey_word_one')); ?></span><span><?php echo esc_html(adb_home('journey_word_two')); ?></span><span><?php echo esc_html(adb_home('journey_word_three')); ?></span></div>
            <div class="adb-journey__progress" aria-hidden="true"><span></span></div>
            <p class="adb-journey__caption"><?php echo esc_html(adb_home('journey_caption')); ?></p>
        </div>
    </section>

    <section class="adb-territories adb-wrap" aria-labelledby="adb-territory-title">
        <div class="adb-section-heading"><div><p class="adb-kicker"><?php echo esc_html(adb_home('territory_eyebrow')); ?></p><h2 id="adb-territory-title"><?php echo esc_html(adb_home('territory_title')); ?></h2></div><p><?php echo esc_html(adb_home('territory_text')); ?></p></div>
        <div class="adb-territories__grid">
            <?php foreach (['ticino', 'italia'] as $place) : $term_id = absint(adb_home($place . '_term_id')); $tax = $place === 'ticino' ? 'pa_regione' : 'pa_nazione'; $term = get_term($term_id, $tax); if (!$term || is_wp_error($term)) { continue; } ?>
            <a class="adb-territory adb-territory--<?php echo esc_attr($place); ?>" href="<?php echo esc_url(get_term_link($term)); ?>"><div class="adb-territory__photo"><?php adb_photo(adb_home($place . '_image_id'), 'large', ['loading' => 'lazy', 'sizes' => '(max-width: 760px) 800px, 60vw']); ?></div><div class="adb-territory__text"><span><?php echo esc_html(adb_home($place . '_subtitle')); ?></span><h3><?php echo esc_html($term->name); ?></h3><p><?php echo esc_html(adb_home($place . '_text')); ?></p><span class="adb-territory__action"><?php esc_html_e('Scopri i vini', 'amicidibacco'); ?> <?php echo adb_icon(); ?></span></div></a>
            <?php endforeach; ?>
        </div>
    </section>

    <?php if ($wineries) : ?>
    <section class="adb-wineries adb-wrap" aria-labelledby="adb-wineries-title">
        <div class="adb-section-heading"><div><p class="adb-kicker"><?php echo esc_html(adb_home('winery_eyebrow')); ?></p><h2 id="adb-wineries-title"><?php echo esc_html(adb_home('winery_title')); ?></h2></div><a class="adb-link" href="<?php echo esc_url(adb_page_link('wineries_page_id', '/produttori/')); ?>"><?php esc_html_e('Tutte le cantine', 'amicidibacco'); ?> <?php echo adb_icon(); ?></a></div>
        <p class="adb-selection__text"><?php echo esc_html(adb_home('winery_text')); ?></p>
        <div class="adb-winery-grid"><?php foreach ($wineries as $winery) : $image = absint(get_post_meta($winery->ID, 'immagine_di_sfondo_sulla_pagina_del_produttore', true)) ?: get_post_thumbnail_id($winery->ID); ?><a class="adb-winery" href="<?php echo esc_url(get_permalink($winery)); ?>"><div><?php adb_photo($image, 'large', ['loading' => 'lazy']); ?></div><h3><?php echo esc_html($winery->post_title); ?> <?php echo adb_icon(); ?></h3></a><?php endforeach; ?></div>
    </section>
    <?php endif; ?>

    <?php if ($producers) : ?>
    <section class="adb-producers adb-wrap" aria-labelledby="adb-producers-title">
        <div class="adb-section-heading"><h2 id="adb-producers-title"><?php echo esc_html(adb_home('producer_title')); ?></h2><p><?php echo esc_html(adb_home('producer_text')); ?></p></div>
        <div class="adb-producers__index">
            <?php foreach ($producers as $producer) : $logo_id = get_post_thumbnail_id($producer->ID); ?>
            <a class="adb-producers__mark" href="<?php echo esc_url(get_permalink($producer)); ?>" aria-label="<?php echo esc_attr($producer->post_title); ?>"><?php if ($logo_id) { echo wp_get_attachment_image($logo_id, 'medium', false, ['loading' => 'lazy', 'decoding' => 'async', 'alt' => '']); } ?><span><?php echo esc_html($producer->post_title); ?></span></a>
            <?php endforeach; ?>
        </div>
    </section>
    <?php endif; ?>

    <section class="adb-story adb-wrap" data-reveal><div class="adb-story__photo"><?php adb_photo(adb_home('story_image_id'), 'large', ['loading' => 'lazy']); ?></div><div class="adb-story__copy"><p class="adb-kicker"><?php echo esc_html(adb_home('story_eyebrow')); ?></p><?php adb_heading(adb_home('story_title')); ?><p><?php echo esc_html(adb_home('story_text')); ?></p><a class="adb-link" href="<?php echo esc_url(adb_page_link('story_page_id', '/storia/')); ?>"><?php esc_html_e('La nostra storia', 'amicidibacco'); ?> <?php echo adb_icon(); ?></a></div></section>

    <section class="adb-professional"><div class="adb-wrap adb-professional__inner"><div><p class="adb-kicker"><?php echo esc_html(adb_home('professional_eyebrow')); ?></p><?php adb_heading(adb_home('professional_title')); ?><p><?php echo esc_html(adb_home('professional_text')); ?></p></div><a class="adb-button adb-button--light" href="<?php echo esc_url(adb_page_link('contact_page_id', '/contatti/')); ?>"><?php esc_html_e('Parliamone insieme', 'amicidibacco'); ?> <?php echo adb_icon(); ?></a></div></section>

    <?php $faq_id = absint(adb_home('faq_id')); if ($faq_id && function_exists('ticinoweb_faq_render')) : ?><section class="adb-faq adb-wrap"><h2><?php echo esc_html(adb_home('faq_title') ?: __('Prima del prossimo brindisi', 'amicidibacco')); ?></h2><?php echo ticinoweb_faq_render($faq_id, ['show_title' => false, 'heading_level' => 3]); ?></section><?php endif; ?>
</main>
<?php get_footer(); ?>
