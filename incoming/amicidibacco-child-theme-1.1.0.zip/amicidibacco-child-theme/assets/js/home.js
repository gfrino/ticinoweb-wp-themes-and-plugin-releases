(() => {
    'use strict';
    const math=window.ADBMotion;
    if (!math) return;
    const {clamp,orbitPoint,activeBottle,passage,portal:portalState}=math;
    const reduced=matchMedia('(prefers-reduced-motion: reduce)');
    const desktop=matchMedia('(min-width: 901px) and (pointer: fine)');
    const saveData=!!navigator.connection?.saveData;
    const hero=document.querySelector('[data-hero]');
    const landscape=document.querySelector('[data-hero-landscape] img');
    const orbit=document.querySelector('[data-orbit]');
    const bottles=[...document.querySelectorAll('[data-orbit-bottle]')];
    const captions=[...document.querySelectorAll('[data-orbit-caption]')];
    const pause=document.querySelector('[data-orbit-pause]');
    const opening=document.querySelector('[data-opening]');
    const openingStage=document.querySelector('[data-opening-stage]');
    const openingIntro=document.querySelector('[data-opening-intro]');
    const portalCut=document.querySelector('[data-portal-cut]');
    const portalInk=document.querySelector('[data-portal-ink]');
    const entryPaper=document.querySelector('[data-entry-paper]');
    const journey=document.querySelector('[data-journey]');
    const journeyPhotos=[...document.querySelectorAll('[data-journey-photo]')];
    const journeyWords=document.querySelector('.adb-journey__words');
    const portraits=[...document.querySelectorAll('.adb-territory__photo img,.adb-story__photo img')];
    let lenis=null,raf=0,lastTime=0,dirty=true,bounds={},selected=-1;
    let phase=Math.PI,targetPhase=null,commerceVisible=true,heroVisible=true,hovered=false,focused=false,userPaused=false;
    const cinematic=()=>!reduced.matches&&!saveData;
    const autoRotate=()=>cinematic()&&bottles.length>1&&heroVisible&&commerceVisible&&!hovered&&!focused&&!userPaused&&!document.hidden;
    function select(index) {
        if (index===selected) return;
        selected=index;
        bottles.forEach((el,i)=>el.classList.toggle('is-active',i===index));
        captions.forEach((el,i)=>{
            el.classList.toggle('is-active',i===index);
            if(i===index){el.removeAttribute('aria-hidden');el.removeAttribute('tabindex');}
            else{el.setAttribute('aria-hidden','true');el.setAttribute('tabindex','-1');}
        });
    }
    function paintOrbit() {
        bottles.forEach((el,i)=>{
            const point=orbitPoint(i,bottles.length,phase),depth=(1-point.x)/2;
            el.style.setProperty('--bottle-x',point.x.toFixed(5));
            el.style.setProperty('--bottle-y',point.y.toFixed(5));
            el.style.setProperty('--bottle-scale',(.58+.64*depth).toFixed(5));
            el.style.setProperty('--bottle-opacity',(.45+.55*depth).toFixed(5));
            el.style.setProperty('--caption-scale',(1/(.58+.64*depth)).toFixed(5));
            el.style.zIndex=String(10+Math.round(depth*20));
        });
        select(activeBottle(bottles.length,phase));
    }
    function paintScroll() {
        const y=scrollY,h=innerHeight;
        if(opening&&y+h>bounds.opening.top&&y<bounds.opening.bottom){
            const progress=clamp((y-bounds.opening.start)/bounds.opening.travel);
            const state=portalState(progress),camera=clamp(progress/.52),blend=camera*camera*(3-2*camera);
            const geometry=bounds.entry;
            const tx=geometry.startX+(720-geometry.startX)*blend;
            const ty=geometry.startY+(geometry.height*.5-geometry.startY)*blend;
            const matrix=`translate(${tx} ${ty}) scale(${state.zoom}) translate(${-geometry.pivotX} ${-geometry.pivotY})`;
            portalCut?.setAttribute('transform',matrix);portalInk?.setAttribute('transform',matrix);
            if(portalInk){
                portalInk.style.opacity=String(state.ink);
                const tone=clamp(progress/.23),from=[255,253,248],to=[112,44,59];
                portalInk.querySelector('text')?.setAttribute('fill',`rgb(${from.map((v,i)=>Math.round(v+(to[i]-v)*tone)).join(',')})`);
            }
            if(entryPaper)entryPaper.style.opacity=String(state.veil);
            if(hero){hero.style.opacity=String(state.heroOpacity);hero.style.transform=`translate3d(0,${-progress*55}px,0)`;hero.inert=progress>.45;}
            if(orbit)orbit.style.transform=`translate3d(${-progress*150}px,0,0)`;
            if(openingIntro)openingIntro.style.opacity=String(clamp((progress-.34)/.22));
            if(landscape)landscape.style.transform=`scale(${1.05+progress*.13}) translate3d(0,${progress*-14}px,0)`;
            commerceVisible=progress<.42;
        }
        if (journey&&y+h>bounds.journey.top&&y<bounds.journey.bottom) {
            const progress=passage(bounds.journey.top,bounds.journey.height,y,h);
            journey.style.setProperty('--journey-progress',String(progress));
            journeyPhotos.forEach((photo,index)=>{
                const amount=index?clamp((progress-(index===1?.19:.54))/.3):1;
                photo.style.opacity=String(amount);
                const image=photo.querySelector('img');
                if(image)image.style.transform=`translate3d(0,${(progress-.5)*-90}px,0) scale(1.07)`;
            });
            if(journeyWords)journeyWords.style.transform=`translate3d(${-progress*18}vw,0,0)`;
        }
        portraits.forEach((image,i)=>{
            const b=bounds.portraits[i];
            if(y+h>b.top&&y<b.bottom)image.style.transform=`translate3d(0,${(passage(b.top,b.height,y,h)-.5)*-32}px,0) scale(1.07)`;
        });
    }
    function frame(time) {
        raf=0;
        if(document.hidden){lastTime=0;return;}
        const dt=lastTime?Math.min(50,time-lastTime):16;lastTime=time;
        lenis?.raf(time);
        let moving=false;
        if(targetPhase!==null){
            const difference=targetPhase-phase;
            phase=reduced.matches?targetPhase:phase+difference*(1-Math.exp(-dt/220));
            if(Math.abs(targetPhase-phase)<.0001){phase=targetPhase;targetPhase=null;}
            moving=true;
        }else if(autoRotate()){phase+=dt*Math.PI*2/46000;moving=true;}
        if(moving||dirty)paintOrbit();
        if(cinematic()&&(dirty||lenis?.isScrolling))paintScroll();
        dirty=false;
        if(lenis||autoRotate()||targetPhase!==null)requestFrame();
    }
    function requestFrame(){if(!raf&&!document.hidden)raf=requestAnimationFrame(frame);}
    function requestPaint(){dirty=true;requestFrame();}
    function box(el){if(!el)return{top:0,bottom:0,height:1};const top=el.getBoundingClientRect().top+scrollY,height=el.offsetHeight;return{top,height,bottom:top+height};}
    function measure() {
        document.body.classList.add('adb-motion-ready');
        document.body.classList.toggle('adb-cinematic',cinematic());
        const wantsSmooth=desktop.matches&&cinematic()&&typeof window.Lenis==='function';
        if(wantsSmooth&&!lenis)lenis=new window.Lenis({autoRaf:false,lerp:.12,smoothWheel:true,syncTouch:false,anchors:false,prevent:node=>!!node.closest?.('dialog,textarea,select,[data-lenis-prevent]')});
        if(!wantsSmooth&&lenis){lenis.destroy();lenis=null;}
        window.adbSmoothScroll=lenis;
        bounds={opening:box(opening),journey:box(journey),portraits:portraits.map(image=>box(image.parentElement))};
        if(openingStage){
            bounds.opening.start=bounds.opening.top-(parseFloat(getComputedStyle(openingStage).top)||0);
            bounds.opening.travel=Math.max(1,opening.offsetHeight-openingStage.offsetHeight);
            const canvasHeight=1440*openingStage.clientHeight/Math.max(1,openingStage.clientWidth);
            const svg=openingStage.querySelector('.adb-entry svg'),mask=svg?.querySelector('mask');
            svg?.setAttribute('viewBox',`0 0 1440 ${canvasHeight}`);mask?.setAttribute('height',String(canvasHeight));
            svg?.querySelectorAll('rect').forEach(rect=>rect.setAttribute('height',String(canvasHeight)));
            const text=portalInk?.querySelector('text'),bbox=text?.getBBox()||{x:-250,y:-90,width:500,height:100};
            let pivot={x:0,y:-30};
            if(text){try{const index=Math.max(0,text.textContent.lastIndexOf(' ')+1),letter=text.getExtentOfChar(index);pivot={x:letter.x+letter.width*.28,y:letter.y+letter.height*.6};}catch{pivot={x:bbox.x+bbox.width*.64,y:bbox.y+bbox.height*.6};}}
            bounds.entry={height:canvasHeight,pivotX:pivot.x,pivotY:pivot.y,startX:1440*(innerWidth<=760?.7:.67)+pivot.x-(bbox.x+bbox.width/2),startY:canvasHeight*.91+pivot.y-(bbox.y+bbox.height/2)};
        }
        const field=document.querySelector('[data-orbit-field]');
        if(field){field.style.setProperty('--orbit-rx',`${field.clientWidth*.43}px`);field.style.setProperty('--orbit-ry',`${field.clientHeight*.48}px`);}
        if(!cinematic()){
            [landscape,hero,orbit,journeyWords,...portraits,...journeyPhotos.map(p=>p.querySelector('img'))].filter(Boolean).forEach(el=>el.style.removeProperty('transform'));
            journeyPhotos.forEach(el=>el.style.removeProperty('opacity'));
            hero?.style.removeProperty('opacity');if(hero)hero.inert=false;openingIntro?.style.removeProperty('opacity');
            portalCut?.removeAttribute('transform');portalInk?.removeAttribute('transform');
            [entryPaper,portalInk].filter(Boolean).forEach(el=>el.style.removeProperty('opacity'));
            commerceVisible=true;
        }
        lenis?.resize();lastTime=0;requestPaint();
    }
    function turn(direction){
        const step=Math.PI*2/Math.max(1,bottles.length);
        targetPhase=Math.PI-((selected+direction+bottles.length)%bottles.length)*step;
        while(targetPhase-phase>Math.PI)targetPhase-=Math.PI*2;
        while(targetPhase-phase< -Math.PI)targetPhase+=Math.PI*2;
        requestPaint();
    }
    document.querySelector('[data-orbit-prev]')?.addEventListener('click',()=>turn(-1));
    document.querySelector('[data-orbit-next]')?.addEventListener('click',()=>turn(1));
    pause?.addEventListener('click',()=>{
        userPaused=!userPaused;pause.setAttribute('aria-pressed',String(userPaused));const label=userPaused?adbMotionLabels.play:adbMotionLabels.pause;pause.setAttribute('aria-label',label);pause.setAttribute('title',label);requestPaint();
    });
    orbit?.addEventListener('pointerenter',()=>{hovered=true;});
    orbit?.addEventListener('pointerleave',()=>{hovered=false;requestFrame();});
    orbit?.addEventListener('focusin',event=>{
        focused=true;
        const bottle=event.target.closest('[data-orbit-bottle]');
        if(bottle){const index=Number(bottle.dataset.orbitBottle);turn(index-selected);}
    });
    orbit?.addEventListener('focusout',event=>{focused=orbit.contains(event.relatedTarget);requestFrame();});
    // Observer gates every nonessential loop; no background orbit after the hero.
    if(hero)new IntersectionObserver(entries=>{heroVisible=entries[0].isIntersecting;lastTime=0;requestFrame();},{threshold:0}).observe(hero);
    document.querySelectorAll('a[href^="#"]').forEach(link=>link.addEventListener('click',event=>{
        const hash=link.getAttribute('href');if(!hash||hash.length<2)return;
        let id;try{id=decodeURIComponent(hash.slice(1));}catch{return;}
        const target=document.getElementById(id);if(!target)return;
        event.preventDefault();const top=id==='il-nostro-mondo'&&cinematic()?bounds.opening.start+bounds.opening.travel:target.getBoundingClientRect().top+scrollY-(document.querySelector('[data-header]')?.offsetHeight||80)-25;
        if(lenis)lenis.scrollTo(top,{duration:1.05,easing:t=>1-(1-t)**4});
        else window.scrollTo({top,behavior:reduced.matches?'instant':'smooth'});
        history.replaceState(null,'',hash);target.setAttribute('tabindex','-1');target.focus({preventScroll:true});
    }));
    addEventListener('scroll',requestPaint,{passive:true});addEventListener('resize',measure,{passive:true});addEventListener('pageshow',measure);
    reduced.addEventListener('change',measure);desktop.addEventListener('change',measure);
    document.addEventListener('visibilitychange',()=>{lastTime=0;if(document.hidden){if(raf)cancelAnimationFrame(raf);raf=0;}else requestPaint();});
    addEventListener('pagehide',()=>{if(raf)cancelAnimationFrame(raf);raf=0;lastTime=0;});
    document.fonts?.ready.then(measure);document.fonts?.load('120px "Bacco Calligraphy"').then(measure);addEventListener('load',measure,{once:true});measure();
})();
