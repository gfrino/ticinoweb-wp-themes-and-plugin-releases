/* Pure geometry shared by the homepage controller and its continuity tests. */
(function (root, factory) {
    if (typeof module === 'object' && module.exports) module.exports = factory();
    else root.ADBMotion = factory();
})(typeof window !== 'undefined' ? window : this, function () {
    'use strict';
    const clamp = value => Math.max(0, Math.min(1, value));
    const smooth = value => { const p=clamp(value); return p*p*(3-2*p); };
    return {
        orbitPoint(index, count, phase) {
            const angle=phase+index*Math.PI*2/Math.max(1,count);
            return {x:Math.cos(angle),y:Math.sin(angle)};
        },
        activeBottle(count, phase) {
            if (!count) return 0;
            return ((Math.round((Math.PI-phase)/(Math.PI*2/count))%count)+count)%count;
        },
        passage(top, height, y, viewport) { return clamp((y+viewport-top)/Math.max(1,height+viewport)); },
        portal(progress) {
            const p=clamp(progress);
            return {zoom:Math.exp(p*Math.log(80)),ink:1-smooth((p-.2)/.18),veil:smooth((p-.15)/.32)*(1-smooth((p-.72)/.25)),heroOpacity:1-smooth(p/.42)};
        },
        clamp,
    };
});
