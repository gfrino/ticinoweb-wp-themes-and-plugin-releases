<?php
/** Native editing of existing catalog records and page-specific editorial choices. */
defined( 'ABSPATH' ) || exit;

function adb_home_fields() {
    return array(
        'hero_eyebrow' => array( __( 'Apertura: sopratitolo', 'amicidibacco' ), 'text' ),
        'hero_title' => array( __( 'Apertura: titolo', 'amicidibacco' ), 'parent' ),
        'hero_text' => array( __( 'Apertura: testo', 'amicidibacco' ), 'parent' ),
        'hero_image_id' => array( __( 'Apertura: immagine', 'amicidibacco' ), 'parent' ),
        'hero_link_label' => array( __( 'Apertura: testo del pulsante catalogo', 'amicidibacco' ), 'parent' ),
        'hero_product_id' => array( __( 'Apertura: bottiglia di riserva (se l’orbita è vuota)', 'amicidibacco' ), 'product' ),
        'hero_orbit_ids' => array( __( 'Apertura: vini nell’orbita (fino a cinque)', 'amicidibacco' ), 'products' ),
        'intro_title' => array( __( 'Introduzione: titolo', 'amicidibacco' ), 'text' ),
        'intro_text' => array( __( 'Introduzione: testo', 'amicidibacco' ), 'textarea' ),
        'selection_title' => array( __( 'Selezione: titolo', 'amicidibacco' ), 'text' ),
        'selection_text' => array( __( 'Selezione: testo', 'amicidibacco' ), 'textarea' ),
        'selection_ids' => array( __( 'Selezione: vini da mostrare', 'amicidibacco' ), 'products' ),
        'journey_title' => array( __( 'Viaggio: titolo', 'amicidibacco' ), 'text' ),
        'journey_text' => array( __( 'Viaggio: testo', 'amicidibacco' ), 'textarea' ),
        'journey_gallery_id' => array( __( 'Viaggio: galleria fotografica', 'amicidibacco' ), 'term', 'ticinoweb_media_gallery' ),
        'journey_image_id' => array( __( 'Viaggio: fotografia', 'amicidibacco' ), 'image' ),
        'territory_title' => array( __( 'Territori: titolo', 'amicidibacco' ), 'text' ),
        'territory_text' => array( __( 'Territori: testo', 'amicidibacco' ), 'textarea' ),
        'ticino_image_id' => array( __( 'Territori: fotografia del Ticino', 'amicidibacco' ), 'image' ),
        'italia_image_id' => array( __( 'Territori: fotografia dell’Italia', 'amicidibacco' ), 'image' ),
        'winery_title' => array( __( 'Cantine: titolo', 'amicidibacco' ), 'text' ),
        'winery_text' => array( __( 'Cantine: testo', 'amicidibacco' ), 'textarea' ),
        'winery_ids' => array( __( 'Cantine da mostrare', 'amicidibacco' ), 'wineries' ),
        'producer_title' => array( __( 'Produttori: titolo', 'amicidibacco' ), 'text' ),
        'producer_text' => array( __( 'Produttori: testo', 'amicidibacco' ), 'textarea' ),
        'story_title' => array( __( 'Chi siamo: titolo', 'amicidibacco' ), 'parent' ),
        'story_text' => array( __( 'Chi siamo: testo', 'amicidibacco' ), 'parent' ),
        'story_image_id' => array( __( 'Chi siamo: fotografia', 'amicidibacco' ), 'parent' ),
        'professional_title' => array( __( 'Professionisti: titolo', 'amicidibacco' ), 'text' ),
        'professional_text' => array( __( 'Professionisti: testo', 'amicidibacco' ), 'textarea' ),
        'hero_note' => array( __( 'Apertura: nota', 'amicidibacco' ), 'text' ),
        'hero_scene_word' => array( __( 'Apertura: parola decorativa', 'amicidibacco' ), 'text' ),
        'hero_image_caption' => array( __( 'Apertura: didascalia fotografia', 'amicidibacco' ), 'text' ),
        'intro_eyebrow' => array( __( 'Introduzione: sopratitolo', 'amicidibacco' ), 'text' ),
        'selection_eyebrow' => array( __( 'Selezione: sopratitolo', 'amicidibacco' ), 'text' ),
        'journey_eyebrow' => array( __( 'Viaggio: sopratitolo', 'amicidibacco' ), 'text' ),
        'journey_word_one' => array( __( 'Viaggio: prima parola', 'amicidibacco' ), 'text' ),
        'journey_word_two' => array( __( 'Viaggio: seconda parola', 'amicidibacco' ), 'text' ),
        'journey_word_three' => array( __( 'Viaggio: terza parola', 'amicidibacco' ), 'text' ),
        'journey_caption' => array( __( 'Viaggio: didascalia fotografia', 'amicidibacco' ), 'text' ),
        'category_ids' => array( __( 'Categorie da mostrare', 'amicidibacco' ), 'terms', 'product_cat' ),
        'territory_eyebrow' => array( __( 'Territori: sopratitolo', 'amicidibacco' ), 'text' ),
        'winery_eyebrow' => array( __( 'Cantine: sopratitolo', 'amicidibacco' ), 'text' ),
        'story_eyebrow' => array( __( 'Chi siamo: sopratitolo', 'amicidibacco' ), 'text' ),
        'professional_eyebrow' => array( __( 'Professionisti: sopratitolo', 'amicidibacco' ), 'text' ),
        'faq_title' => array( __( 'Domande frequenti: titolo sezione', 'amicidibacco' ), 'text' ),
        'ticino_term_id' => array( __( 'Ticino: regione del catalogo', 'amicidibacco' ), 'term', 'pa_regione' ),
        'italia_term_id' => array( __( 'Italia: nazione del catalogo', 'amicidibacco' ), 'term', 'pa_nazione' ),
        'ticino_subtitle' => array( __( 'Ticino: sottotitolo', 'amicidibacco' ), 'text' ),
        'ticino_text' => array( __( 'Ticino: descrizione', 'amicidibacco' ), 'textarea' ),
        'italia_subtitle' => array( __( 'Italia: sottotitolo', 'amicidibacco' ), 'text' ),
        'italia_text' => array( __( 'Italia: descrizione', 'amicidibacco' ), 'textarea' ),
        'wineries_page_id' => array( __( 'Pagina delle cantine', 'amicidibacco' ), 'parent' ),
        'story_page_id' => array( __( 'Pagina Chi siamo', 'amicidibacco' ), 'parent' ),
        'contact_page_id' => array( __( 'Pagina Contatti', 'amicidibacco' ), 'parent' ),
        'faq_id' => array( __( 'Domande frequenti', 'amicidibacco' ), 'parent' ),
    );
}

/** One runtime API, with parent CMS data retaining priority and ownership. */
function adb_home( $key, $default = '' ) {
    if ( ! isset( adb_home_fields()[ $key ] ) ) { return $default; }
    $page_keys = array( 'wineries_page_id' => 'archive_produttore', 'story_page_id' => 'page_chi_siamo', 'contact_page_id' => 'page_contatti' );
    if ( isset( $page_keys[ $key ] ) ) {
        $mapping = get_option( 'ticinoweb_page_mapping', array() );
        if ( ! empty( $mapping[ $page_keys[ $key ] ] ) ) { return absint( $mapping[ $page_keys[ $key ] ] ); }
    }
    $parent = array( 'hero_link_label' => 'ticinoweb_slider_btn_text_1', 'hero_title' => 'ticinoweb_slider_title_1', 'hero_text' => 'ticinoweb_slider_desc_1', 'hero_image_id' => 'ticinoweb_slider_image_1', 'story_title' => 'ticinoweb_chi_siamo_title', 'story_text' => 'ticinoweb_chi_siamo_text', 'story_image_id' => 'ticinoweb_chi_siamo_image' );
    if ( isset( $parent[ $key ] ) ) {
        $value = get_option( $parent[ $key ], '' );
        if ( '' !== $value && false !== $value ) {
            if ( in_array( $key, array( 'hero_image_id', 'story_image_id' ), true ) ) { return is_numeric( $value ) ? absint( $value ) : attachment_url_to_postid( $value ); }
            return $value;
        }
    }
    $page = (int) get_option( 'page_on_front' );
    if ( ! $page ) { return $default; }
    if ( 'faq_id' === $key ) {
        $faq = get_post_meta( $page, defined( 'TICINOWEB_FAQ_META_PAGE' ) ? TICINOWEB_FAQ_META_PAGE : '_tw_faq_page_set', true );
        if ( $faq ) { return absint( $faq ); }
    }
    $value = get_post_meta( $page, '_adb_' . $key, true );
    return '' === $value ? $default : $value;
}

function adb_copy( $key, $default = '' ) { return adb_home( $key, $default ); }

/** The parent gets the first opportunity to register its configurable CPT. */
function adb_register_wineries() {
    if ( ! post_type_exists( 'produttore' ) ) {
        register_post_type( 'produttore', array(
            'labels' => array( 'name' => __( 'Cantine', 'amicidibacco' ), 'singular_name' => __( 'Cantina', 'amicidibacco' ), 'add_new_item' => __( 'Aggiungi cantina', 'amicidibacco' ), 'edit_item' => __( 'Modifica cantina', 'amicidibacco' ), 'all_items' => __( 'Tutte le cantine', 'amicidibacco' ), 'search_items' => __( 'Cerca cantine', 'amicidibacco' ) ),
            'public' => true, 'show_in_rest' => true, 'exclude_from_search' => true,
            'has_archive' => 'cantine', 'rewrite' => array( 'slug' => 'produttore', 'with_front' => true ),
            'supports' => array( 'title', 'editor', 'thumbnail', 'excerpt' ), 'menu_icon' => 'dashicons-palmtree',
            'taxonomies' => array( 'pa_cantina' ),
        ) );
    }
    if ( taxonomy_exists( 'pa_cantina' ) ) { register_taxonomy_for_object_type( 'pa_cantina', 'produttore' ); }
}
add_action( 'init', 'adb_register_wineries', 20 );

function adb_add_meta_boxes( $post_type, $post ) {
    if ( 'page' === $post_type && (int) get_option( 'page_on_front' ) === (int) $post->ID ) { add_meta_box( 'adb-home', __( 'Contenuti della homepage', 'amicidibacco' ), 'adb_home_metabox', 'page', 'normal', 'high' ); }
    if ( 'product' === $post_type ) { add_meta_box( 'adb-product', __( 'Etichetta e scheda tecnica', 'amicidibacco' ), 'adb_product_metabox', 'product', 'normal' ); }
    if ( 'produttore' === $post_type ) {
        add_meta_box( 'adb-winery', __( 'Immagini e collegamento al catalogo', 'amicidibacco' ), 'adb_winery_metabox', 'produttore', 'normal' );
        // The existing relation has one owner: our named selector writes both the old meta and taxonomy.
        remove_meta_box( 'pa_cantinadiv', 'produttore', 'side' );
        remove_meta_box( 'tagsdiv-pa_cantina', 'produttore', 'side' );
    }
}
add_action( 'add_meta_boxes', 'adb_add_meta_boxes', 20, 2 );

function adb_admin_media_field( $name, $id, $label ) {
    $field_id = 'adb-' . sanitize_html_class( $name );
    echo '<div class="adb-media-field"><label for="' . esc_attr( $field_id ) . '"><strong>' . esc_html( $label ) . '</strong></label><p class="adb-media-preview">';
    if ( $id ) { echo wp_get_attachment_image( $id, 'thumbnail' ); }
    echo '</p><input type="hidden" id="' . esc_attr( $field_id ) . '" name="' . esc_attr( $name ) . '" value="' . esc_attr( $id ) . '"><button type="button" class="button adb-choose-media">' . esc_html__( 'Scegli immagine', 'amicidibacco' ) . '</button> <button type="button" class="button-link adb-clear-media">' . esc_html__( 'Rimuovi immagine', 'amicidibacco' ) . '</button></div>';
}

/** All labels are records; editors never enter numeric IDs. */
function adb_admin_record_choices( $post_type ) {
    global $wpdb;
    $where = in_array( $post_type, array( 'product', 'produttore', 'page' ), true ) ? adb_language_predicate( 'p.ID', "CONCAT('post_', p.post_type)" ) : '';
    $ids = $wpdb->get_col( $wpdb->prepare( "SELECT p.ID FROM {$wpdb->posts} p WHERE p.post_type=%s AND p.post_status=%s $where ORDER BY p.post_title ASC LIMIT 500", $post_type, 'publish' ) );
    if ( ! $ids ) { return array(); }
    return get_posts( array( 'post_type' => $post_type, 'post_status' => 'publish', 'post__in' => array_map( 'intval', $ids ), 'posts_per_page' => count( $ids ), 'orderby' => 'post__in', 'update_post_meta_cache' => false, 'update_post_term_cache' => false ) );
}

function adb_admin_term_choices( $taxonomy ) {
    global $wpdb;
    if ( ! taxonomy_exists( $taxonomy ) ) { return array(); }
    $where = adb_language_predicate( 'tt.term_taxonomy_id', "CONCAT('tax_', tt.taxonomy)" );
    $ids = $wpdb->get_col( $wpdb->prepare( "SELECT tt.term_id FROM {$wpdb->term_taxonomy} tt WHERE tt.taxonomy=%s $where", $taxonomy ) );
    if ( ! $ids ) { return array(); }
    $terms = get_terms( array( 'taxonomy' => $taxonomy, 'hide_empty' => false, 'include' => array_map( 'intval', $ids ), 'orderby' => 'name' ) );
    return is_wp_error( $terms ) ? array() : $terms;
}

function adb_admin_record_select( $name, $selected_ids, $records, $multiple = false ) {
    $selected_ids = array_map( 'absint', (array) $selected_ids );
    if ( $multiple ) {
        $by_id = array(); foreach ( $records as $record ) { $by_id[ $record->ID ] = $record; }
        $ordered = array();
        foreach ( $selected_ids as $id ) { if ( isset( $by_id[ $id ] ) ) { $ordered[] = $by_id[ $id ]; unset( $by_id[ $id ] ); } }
        $records = array_merge( $ordered, array_values( $by_id ) );
    }
    echo '<select class="widefat" id="adb-' . esc_attr( sanitize_html_class( $name ) ) . '" name="' . esc_attr( $name ) . ( $multiple ? '[]' : '' ) . '"' . ( $multiple ? ' multiple size="8"' : '' ) . '>';
    if ( ! $multiple ) { echo '<option value="">' . esc_html__( 'Nessuna selezione', 'amicidibacco' ) . '</option>'; }
    foreach ( $records as $record ) { echo '<option value="' . esc_attr( $record->ID ) . '"' . selected( in_array( (int) $record->ID, $selected_ids, true ), true, false ) . '>' . esc_html( $record->post_title ) . '</option>'; }
    echo '</select>';
    if ( $multiple ) { echo '<span style="display:block;margin-top:8px"><button type="button" class="button adb-choice-up">' . esc_html__( 'Sposta su', 'amicidibacco' ) . '</button> <button type="button" class="button adb-choice-down">' . esc_html__( 'Sposta giù', 'amicidibacco' ) . '</button></span>'; }
}

function adb_home_metabox( $post ) {
    wp_nonce_field( 'adb_save_home', 'adb_home_nonce' );
    echo '<p>' . esc_html__( 'Titolo, testo e immagine iniziali si modificano nella Slide 1 del ticinoWEB CMS. La sezione Chi siamo usa i campi Chi siamo dello stesso CMS. Le FAQ si scelgono nel riquadro FAQ della pagina.', 'amicidibacco' ) . '</p><p><a href="' . esc_url( admin_url( 'admin.php?page=ticinoweb-cms' ) ) . '">' . esc_html__( 'Apri ticinoWEB CMS', 'amicidibacco' ) . '</a></p>';
    $products = adb_admin_record_choices( 'product' );
    $wineries = adb_admin_record_choices( 'produttore' );
    foreach ( adb_home_fields() as $key => $field ) {
        list( $label, $type ) = $field;
        if ( 'parent' === $type ) { continue; }
        $value = get_post_meta( $post->ID, '_adb_' . $key, true );
        $name = 'adb_home[' . $key . ']';
        echo '<div style="margin:18px 0">';
        if ( 'image' === $type ) { adb_admin_media_field( $name, absint( $value ), $label ); }
        else {
            echo '<label for="adb-' . esc_attr( sanitize_html_class( $name ) ) . '"><strong>' . esc_html( $label ) . '</strong></label><p>';
            if ( in_array( $type, array( 'product', 'products', 'wineries', 'page' ), true ) ) {
                $records = 'wineries' === $type ? $wineries : $products;
                adb_admin_record_select( $name, $value ?: array(), $records, in_array( $type, array( 'products', 'wineries' ), true ) );
            } elseif ( in_array( $type, array( 'term', 'terms' ), true ) ) {
                $terms = adb_admin_term_choices( $field[2] );
                $records = array_map( static function ( $term ) { return (object) array( 'ID' => $term->term_id, 'post_title' => $term->name ); }, $terms );
                adb_admin_record_select( $name, $value ?: array(), $records, 'terms' === $type );
            }
            elseif ( 'textarea' === $type ) { echo '<textarea class="widefat" rows="4" id="adb-' . esc_attr( sanitize_html_class( $name ) ) . '" name="' . esc_attr( $name ) . '">' . esc_textarea( $value ) . '</textarea>'; }
            else { echo '<input class="widefat" type="text" id="adb-' . esc_attr( sanitize_html_class( $name ) ) . '" name="' . esc_attr( $name ) . '" value="' . esc_attr( $value ) . '">'; }
            echo '</p>';
        }
        echo '</div>';
    }
    echo '<p>' . esc_html__( 'Per selezionare più voci usa Ctrl (Windows) o Cmd (Mac). Usa Sposta su e Sposta giù per scegliere l’ordine di presentazione.', 'amicidibacco' ) . '</p>';
}

function adb_product_metabox( $post ) {
    wp_nonce_field( 'adb_save_product', 'adb_product_nonce' );
    echo '<p>' . esc_html__( 'Questi campi usano i dati tecnici originali. Prezzi, formati, annate e disponibilità restano nei Dati prodotto WooCommerce.', 'amicidibacco' ) . '</p>';
    foreach ( adb_product_fields() as $key => $label ) {
        $value = get_post_meta( $post->ID, $key, true );
        echo '<p><label for="adb-product-' . esc_attr( sanitize_html_class( str_replace( ':', '-grappa', $key ) ) ) . '"><strong>' . esc_html( $label ) . '</strong></label><br>';
        if ( 'tipo_di_prodotto' === $key ) {
            echo '<select id="adb-product-' . esc_attr( sanitize_html_class( str_replace( ':', '-grappa', $key ) ) ) . '" name="adb_product[' . esc_attr( $key ) . ']">';
            foreach ( array( '', 'VINO SINGOLO', 'GRAPPA SINGOLA', 'LE SELEZIONI VINO', 'LE SELEZIONI GRAPPA', 'BIRRE' ) as $choice ) { echo '<option value="' . esc_attr( $choice ) . '"' . selected( $value, $choice, false ) . '>' . esc_html( $choice ?: __( 'Scegli il tipo', 'amicidibacco' ) ) . '</option>'; }
            echo '</select>';
        } else { echo '<textarea class="widefat" rows="2" id="adb-product-' . esc_attr( sanitize_html_class( str_replace( ':', '-grappa', $key ) ) ) . '" name="adb_product[' . esc_attr( $key ) . ']">' . esc_textarea( is_scalar( $value ) ? $value : '' ) . '</textarea>'; }
        echo '</p>';
    }
    adb_admin_media_field( 'adb_product[logo_cantina]', absint( get_post_meta( $post->ID, 'logo_cantina', true ) ), __( 'Logo della cantina', 'amicidibacco' ) );
}

function adb_winery_metabox( $post ) {
    wp_nonce_field( 'adb_save_winery', 'adb_winery_nonce' );
    echo '<p><label for="adb-winery-cantina"><strong>' . esc_html__( 'Cantina del catalogo collegata', 'amicidibacco' ) . '</strong></label><br><select class="widefat" name="adb_winery[cantina]" id="adb-winery-cantina"><option value="">' . esc_html__( 'Nessun collegamento', 'amicidibacco' ) . '</option>';
    $terms = adb_admin_term_choices( 'pa_cantina' );
    if ( ! is_wp_error( $terms ) ) { foreach ( $terms as $term ) { echo '<option value="' . esc_attr( $term->term_id ) . '"' . selected( absint( get_post_meta( $post->ID, 'cantina', true ) ), $term->term_id, false ) . '>' . esc_html( $term->name ) . '</option>'; } }
    echo '</select></p>';
    adb_admin_media_field( 'adb_winery[immagine_di_sfondo_sulla_pagina_del_produttore]', absint( get_post_meta( $post->ID, 'immagine_di_sfondo_sulla_pagina_del_produttore', true ) ), __( 'Fotografia di sfondo', 'amicidibacco' ) );
}

function adb_valid_image_id( $value ) {
    $id = is_scalar( $value ) ? absint( $value ) : 0;
    return $id && wp_attachment_is_image( $id ) ? $id : 0;
}

function adb_valid_record_ids( $value, $post_type ) {
    $ids = wp_parse_id_list( is_array( $value ) ? array_filter( $value, 'is_scalar' ) : ( is_scalar( $value ) ? $value : array() ) );
    if ( ! $ids ) { return array(); }
    $valid = get_posts( array( 'post_type' => $post_type, 'post_status' => 'publish', 'post__in' => $ids, 'posts_per_page' => min( count( $ids ), 500 ), 'fields' => 'ids', 'orderby' => 'post__in', 'update_post_term_cache' => false, 'update_post_meta_cache' => false ) );
    return array_map( 'intval', $valid );
}

/** Normalize an editorial value; null means this input must never be written. */
function adb_sanitize_home_value( $key, $raw ) {
    $fields = adb_home_fields();
    if ( ! isset( $fields[ $key ] ) || 'parent' === $fields[ $key ][1] ) { return null; }
    $field = $fields[ $key ];
    $type = $field[1];
    if ( 'image' === $type ) { return adb_valid_image_id( $raw ); }
    if ( in_array( $type, array( 'product', 'products', 'wineries', 'page' ), true ) ) {
        $post_type = 'wineries' === $type ? 'produttore' : ( 'page' === $type ? 'page' : 'product' );
        $value = adb_valid_record_ids( $raw, $post_type );
        return in_array( $type, array( 'product', 'page' ), true ) ? ( $value[0] ?? 0 ) : $value;
    }
    if ( in_array( $type, array( 'term', 'terms' ), true ) ) {
        $ids = wp_parse_id_list( is_array( $raw ) ? array_filter( $raw, 'is_scalar' ) : ( is_scalar( $raw ) ? $raw : array() ) );
        $terms = $ids ? get_terms( array( 'taxonomy' => $field[2], 'hide_empty' => false, 'include' => $ids, 'fields' => 'ids' ) ) : array();
        $valid = is_wp_error( $terms ) ? array() : array_map( 'intval', $terms );
        $value = array_values( array_intersect( $ids, $valid ) );
        return 'term' === $type ? ( $value[0] ?? 0 ) : $value;
    }
    if ( ! is_scalar( $raw ) ) { return null; }
    return 'textarea' === $type ? wp_kses_post( $raw ) : sanitize_text_field( $raw );
}

/** One save dispatcher: strict form ownership, nonce, capability, and known field types. */
function adb_save_editorial_meta( $post_id, $post ) {
    if ( ! $post || wp_is_post_revision( $post_id ) || wp_is_post_autosave( $post_id ) || ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) || ! current_user_can( 'edit_post', $post_id ) ) { return; }
    if ( 'page' === $post->post_type && (int) get_option( 'page_on_front' ) === (int) $post_id && isset( $_POST['adb_home_nonce'] ) && is_string( $_POST['adb_home_nonce'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['adb_home_nonce'] ) ), 'adb_save_home' ) && isset( $_POST['adb_home'] ) && is_array( $_POST['adb_home'] ) ) {
        $input = wp_unslash( $_POST['adb_home'] );
        foreach ( adb_home_fields() as $key => $field ) {
            $value = adb_sanitize_home_value( $key, $input[ $key ] ?? '' );
            if ( null !== $value ) { update_post_meta( $post_id, '_adb_' . $key, $value ); }
        }
    }
    if ( 'product' === $post->post_type && isset( $_POST['adb_product_nonce'] ) && is_string( $_POST['adb_product_nonce'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['adb_product_nonce'] ) ), 'adb_save_product' ) && isset( $_POST['adb_product'] ) && is_array( $_POST['adb_product'] ) ) {
        $input = wp_unslash( $_POST['adb_product'] );
        foreach ( adb_product_fields() as $key => $label ) {
            if ( ! isset( $input[ $key ] ) || ! is_scalar( $input[ $key ] ) ) { continue; }
            $value = sanitize_textarea_field( $input[ $key ] );
            if ( 'tipo_di_prodotto' === $key && ! in_array( $value, array( '', 'VINO SINGOLO', 'GRAPPA SINGOLA', 'LE SELEZIONI VINO', 'LE SELEZIONI GRAPPA', 'BIRRE' ), true ) ) { continue; }
            update_post_meta( $post_id, $key, $value );
        }
        if ( isset( $input['logo_cantina'] ) ) { update_post_meta( $post_id, 'logo_cantina', adb_valid_image_id( $input['logo_cantina'] ) ); }
    }
    if ( 'produttore' === $post->post_type && isset( $_POST['adb_winery_nonce'] ) && is_string( $_POST['adb_winery_nonce'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['adb_winery_nonce'] ) ), 'adb_save_winery' ) && isset( $_POST['adb_winery'] ) && is_array( $_POST['adb_winery'] ) ) {
        $input = wp_unslash( $_POST['adb_winery'] );
        if ( isset( $input['cantina'] ) && is_scalar( $input['cantina'] ) ) {
            $id = absint( $input['cantina'] );
            if ( ! $id || term_exists( $id, 'pa_cantina' ) ) { update_post_meta( $post_id, 'cantina', $id ); wp_set_object_terms( $post_id, $id ? array( $id ) : array(), 'pa_cantina', false ); }
        }
        $key = 'immagine_di_sfondo_sulla_pagina_del_produttore';
        if ( isset( $input[ $key ] ) ) { update_post_meta( $post_id, $key, adb_valid_image_id( $input[ $key ] ) ); }
    }
}
add_action( 'save_post', 'adb_save_editorial_meta', 20, 2 );

function adb_editor_media_assets( $hook ) {
    if ( ! in_array( $hook, array( 'post.php', 'post-new.php' ), true ) ) { return; }
    $screen = get_current_screen();
    if ( ! $screen || ! in_array( $screen->post_type, array( 'page', 'product', 'produttore' ), true ) ) { return; }
    wp_enqueue_media();
    wp_add_inline_script( 'media-editor', 'jQuery(function($){$(document).on("click",".adb-choose-media",function(){var box=$(this).closest(".adb-media-field");var frame=wp.media({title:' . wp_json_encode( __( 'Scegli immagine', 'amicidibacco' ) ) . ',library:{type:"image"},multiple:false});frame.on("select",function(){var a=frame.state().get("selection").first().toJSON();box.find("input[type=hidden]").val(a.id);var src=a.sizes&&a.sizes.thumbnail?a.sizes.thumbnail.url:a.url;box.find(".adb-media-preview").empty().append($("<img>").attr({src:src,alt:a.alt||""}).css({maxWidth:"150px",height:"auto"}));});frame.open();});$(document).on("click",".adb-choice-up,.adb-choice-down",function(){var select=$(this).closest("div").find("select").first(),up=$(this).hasClass("adb-choice-up"),options=select.find("option:selected").get();if(!up){options.reverse();}options.forEach(function(option){var item=$(option),near=up?item.prev():item.next();if(near.length&&!near.prop("selected")){up?item.insertBefore(near):item.insertAfter(near);}});select.trigger("change");});$(document).on("click",".adb-clear-media",function(){var box=$(this).closest(".adb-media-field");box.find("input[type=hidden]").val("");box.find(".adb-media-preview").empty();});});' );
}
add_action( 'admin_enqueue_scripts', 'adb_editor_media_assets' );
