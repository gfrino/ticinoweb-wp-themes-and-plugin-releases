<?php defined('ABSPATH') || exit; get_header(); ?>
<main id="main-content" class="adb-commerce adb-wrap">
<?php if (is_product()) : ?>
    <?php woocommerce_breadcrumb(); woocommerce_content(); ?>
<?php else : ?>
    <header class="adb-catalog-heading"><p class="adb-kicker"><?php echo esc_html(get_bloginfo('name')); ?></p><h1><?php woocommerce_page_title(); ?></h1><p><?php echo esc_html(get_post_field('post_excerpt', wc_get_page_id('shop'))); ?></p></header>
    <div class="adb-catalog-layout">
        <aside aria-label="<?php esc_attr_e( 'Filtri del catalogo', 'amicidibacco' ); ?>">
            <button type="button" class="adb-filters-toggle" aria-expanded="false" aria-controls="adb-shop-filters" hidden>
                <?php esc_html_e( 'Filtra i vini', 'amicidibacco' ); ?><span data-active-filters></span>
            </button>
            <?php adb_shop_filter_form(); ?>
        </aside>
        <div class="adb-catalog-results"><?php woocommerce_content(); ?></div>
    </div>
<?php endif; ?>
</main>
<?php get_footer(); ?>
