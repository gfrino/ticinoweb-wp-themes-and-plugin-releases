<?php defined('ABSPATH') || exit; ?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head><meta charset="<?php bloginfo('charset'); ?>"><meta name="viewport" content="width=device-width, initial-scale=1"><?php wp_head(); ?><?php if (is_front_page()) : ?><noscript><style>.adb-header--hero[data-header-over-hero]{position:relative;top:auto}</style></noscript><?php endif; ?></head>
<body <?php body_class(); ?>><?php wp_body_open(); ?>
<a class="adb-skip" href="#main-content"><?php esc_html_e('Vai al contenuto', 'amicidibacco'); ?></a>
<header class="adb-header<?php echo is_front_page() ? ' adb-header--hero' : ''; ?>" data-header<?php if ( is_front_page() ) : ?> data-header-over-hero<?php endif; ?>>
    <div class="adb-header__inner">
        <?php $logo = function_exists('ticinoweb_get_site_logo') ? ticinoweb_get_site_logo() : ''; ?>
        <a class="adb-brand" href="<?php echo esc_url(home_url('/')); ?>" aria-label="<?php echo esc_attr(get_bloginfo('name') . ' — ' . __('Home', 'amicidibacco')); ?>">
            <?php if ($logo) : ?>
            <span class="adb-brand__art" style="<?php echo esc_attr('--adb-brand-image:url(' . wp_json_encode(esc_url_raw($logo), JSON_HEX_APOS | JSON_HEX_QUOT) . ')'); ?>"><img src="<?php echo esc_url($logo); ?>" width="900" height="215" alt="<?php echo esc_attr(get_bloginfo('name')); ?>"></span>
            <?php else : ?><span><?php bloginfo('name'); ?></span><?php endif; ?>
        </a>
        <?php $menu_photo = wp_get_attachment_image_url( absint( adb_home( 'hero_image_id' ) ), 'medium_large' ); ?>
        <nav class="adb-nav" id="adb-main-nav"<?php if ( $menu_photo ) : ?> style="<?php echo esc_attr( '--adb-menu-vineyard:url(' . wp_json_encode( esc_url_raw( adb_light_image_url( $menu_photo ) ), JSON_HEX_APOS | JSON_HEX_QUOT ) . ')' ); ?>"<?php endif; ?> aria-label="<?php esc_attr_e('Menu principale', 'amicidibacco'); ?>"><?php wp_nav_menu(['theme_location' => 'primary', 'container' => false, 'fallback_cb' => false, 'depth' => 2]); ?>
            <?php adb_wine_menu_template(); ?>
            <a class="adb-nav__catalog-photo" href="<?php echo esc_url( adb_catalog_url() ); ?>"><span><?php esc_html_e( 'Entra in enoteca', 'amicidibacco' ); ?></span><?php echo adb_icon(); ?></a>
        </nav>
        <div class="adb-header__actions">
            <button class="adb-icon-button" data-search-open aria-label="<?php esc_attr_e('Cerca un vino', 'amicidibacco'); ?>"><?php echo adb_icon('search'); ?></button>
            <?php adb_cart_link(); ?>
            <a class="adb-header__shop" href="<?php echo esc_url(adb_catalog_url()); ?>"><?php esc_html_e('Entra in enoteca', 'amicidibacco'); ?> <?php echo adb_icon(); ?></a>
            <button class="adb-icon-button adb-menu-toggle" aria-expanded="false" aria-controls="adb-main-nav" data-menu-toggle data-close-label="<?php esc_attr_e('Chiudi il menu', 'amicidibacco'); ?>" aria-label="<?php esc_attr_e('Apri il menu', 'amicidibacco'); ?>"><?php echo adb_icon('menu'); ?></button>
        </div>
    </div>
</header>
<noscript><nav class="adb-nav-fallback" aria-label="<?php esc_attr_e('Menu principale', 'amicidibacco'); ?>"><?php wp_nav_menu(['theme_location' => 'primary', 'menu_id' => 'adb-menu-fallback', 'container' => false, 'fallback_cb' => false, 'depth' => 2]); ?></nav></noscript>
<dialog class="adb-search-dialog" data-search-dialog aria-labelledby="adb-search-title">
    <button class="adb-icon-button adb-search-dialog__close" data-search-close aria-label="<?php esc_attr_e('Chiudi ricerca', 'amicidibacco'); ?>"><?php echo adb_icon('close'); ?></button>
    <h2 id="adb-search-title"><?php esc_html_e('Il prossimo vino da scoprire.', 'amicidibacco'); ?></h2>
    <form role="search" method="get" action="<?php echo esc_url(home_url('/')); ?>"><label for="adb-search"><?php esc_html_e('Vino, cantina o vitigno', 'amicidibacco'); ?></label><div><input id="adb-search" name="s" type="search" placeholder="<?php esc_attr_e('Cerca nel catalogo…', 'amicidibacco'); ?>" maxlength="80" autocomplete="off" aria-describedby="adb-search-status" aria-controls="adb-search-results" required><input type="hidden" name="post_type" value="product"><button type="submit" class="adb-button"><?php esc_html_e('Cerca', 'amicidibacco'); ?> <?php echo adb_icon(); ?></button></div></form>
    <p id="adb-search-status" class="adb-search-status" role="status" aria-live="polite"><?php esc_html_e('Scrivi almeno due caratteri. Premi Invio per vedere tutti i risultati.', 'amicidibacco'); ?></p>
    <div id="adb-search-results" class="adb-search-results" data-search-results></div>
</dialog>
