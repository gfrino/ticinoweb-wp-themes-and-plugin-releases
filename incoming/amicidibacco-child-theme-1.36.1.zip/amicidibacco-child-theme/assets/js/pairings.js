(function () {
    'use strict';

    function init(section) {
        const config = JSON.parse(section.dataset.pairConfig);
        const form = section.querySelector('form');
        const fields = form.querySelector('fieldset');
        const submit = form.querySelector('[type="submit"]');
        const message = form.querySelector('[data-pair-message]');
        const cart = form.querySelector('[data-pair-cart]');
        const feedback = message.parentElement;
        const lines = Array.from(form.querySelectorAll('[data-pair-id]'), (card) => ({
            id: Number(card.dataset.pairId),
            rules: JSON.parse(card.dataset.pairRules),
            include: card.querySelector('[type="checkbox"]'),
            selects: Array.from(card.querySelectorAll('select')),
            price: card.querySelector('[data-pair-price]'),
            unit: card.querySelector('[data-pair-unit]'),
            card
        }));
        const current = lines[0];
        const badge = current.card.querySelector('.adb-pair-check span');
        const originalBadge = badge.textContent;
        let stateRequest = 0;
        let pending = false;
        let attempt = null;
        const factor = 10 ** config.decimals;

        function money(minorUnits) {
            const parts = (minorUnits / factor).toFixed(config.decimals).split('.');
            parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, () => config.thousand);
            return config.format.replace('%1$s', () => config.currency).replace('%2$s', () => parts.join(config.decimal));
        }

        function resolve(line) {
            let candidates = line.rules;
            line.attributes = {};
            for (const select of line.selects) {
                const key = select.dataset.attribute_name;
                let first = '';
                for (const option of select.options) {
                    const allowed = option.value !== '' && candidates.some((rule) =>
                        !rule.attributes[key] || rule.attributes[key] === option.value);
                    option.disabled = !allowed;
                    option.hidden = !allowed;
                    if (!first && allowed) first = option.value;
                }
                if (!select.selectedOptions[0] || select.selectedOptions[0].disabled) select.value = first;
                line.attributes[key] = select.value;
                candidates = candidates.filter((rule) => select.value && (!rule.attributes[key] || rule.attributes[key] === select.value));
                select.disabled = !line.include.checked || line.include.disabled;
            }
            line.selected = candidates[0];
            line.amount = line.selected ? Math.round(line.selected.price * factor) : 0;
            line.price.textContent = line.selected ? money(line.amount) : '—';
            const units = line.selected?.units || {};
            const size = line.attributes.attribute_pa_dimensione || '';
            line.unit.textContent = units[size] || units[''] || (Object.keys(units).length === 1 ? Object.values(units)[0] : '');
            line.unit.hidden = !line.unit.textContent;
            line.card.classList.toggle('is-excluded', !line.include.checked || line.include.disabled);
        }

        function render() {
            lines.forEach(resolve);
            const selected = lines.filter((line) => line.include.checked && !line.include.disabled);
            const count = selected.length;
            const total = selected.reduce((sum, line) => sum + line.amount, 0);
            form.querySelector('[data-pair-count]').textContent = count === 1 ? config.one : config.many.replace('%d', count);
            form.querySelector('[data-pair-total]').textContent = money(total);
            submit.disabled = !count || selected.some((line) => !line.selected);
        }

        function displayCartState(inCart) {
            current.include.disabled = inCart;
            current.card.classList.toggle('is-in-cart', inCart);
            badge.textContent = inCart ? config.already : originalBadge;
            render();
        }

        async function refreshCartState() {
            const request = ++stateRequest;
            try {
                const response = await fetch(config.stateEndpoint, { credentials: 'same-origin', cache: 'no-store' });
                if (!response.ok) return;
                const result = await response.json();
                if (request === stateRequest && result.success && typeof result.data.in_cart === 'boolean') {
                    displayCartState(result.data.in_cart);
                }
            } catch {
                // The add endpoint always checks the current WooCommerce cart again.
            }
        }

        function clearFeedback() {
            delete feedback.dataset.state;
            message.textContent = '';
            cart.hidden = true;
        }

        function showFeedback(state, text) {
            feedback.dataset.state = state;
            message.textContent = text;
            cart.hidden = false;
        }

        function editSelection() {
            clearFeedback();
            render();
        }

        // Follow a choice made in the main purchase form without changing that form.
        const main = document.querySelector('.adb-product-stage form.variations_form');
        if (main) {
            function fromMain() {
                if (pending) return;
                let changed = false;
                for (const field of lines[0].selects) {
                    const other = main.elements.namedItem(field.name);
                    if (other && other.value && field.value !== other.value) {
                        field.value = other.value;
                        changed = true;
                    }
                }
                if (changed) editSelection();
            }
            if (window.jQuery) window.jQuery(main).on('change.adbPairings found_variation.adbPairings', fromMain);
            else main.addEventListener('change', fromMain);
            fromMain();
        }

        if (window.jQuery) window.jQuery(form).on('change.adbPairings', editSelection);
        else form.addEventListener('change', editSelection);
        form.addEventListener('submit', async (event) => {
            event.preventDefault();
            if (pending || submit.disabled) return;
            const items = JSON.stringify(lines.filter((line) => line.include.checked && !line.include.disabled).map((line) => ({
                id: line.id, variation_id: line.selected.id, attributes: line.attributes
            })));
            // Reuse the same token if a response was lost after the server accepted the cart.
            if (!attempt || attempt.items !== items) {
                const bytes = crypto.getRandomValues(new Uint8Array(16));
                const id = Array.from(bytes, (value) => value.toString(16).padStart(2, '0')).join('');
                attempt = { items, id };
            }
            pending = true;
            fields.disabled = true;
            form.setAttribute('aria-busy', 'true');
            clearFeedback();
            try {
                const response = await fetch(config.endpoint, {
                    method: 'POST', credentials: 'same-origin',
                    body: new URLSearchParams({ product_id: lines[0].id, items, nonce: config.nonce, request_id: attempt.id })
                });
                const result = await response.json();
                if (result.success !== true || !response.ok) {
                    throw new Error(result.data?.message || config.failure);
                }
                attempt = null;
                const count = Number(result.data.count);
                if (Number.isInteger(count)) {
                    document.querySelectorAll('.adb-cart').forEach((link) => {
                        const badge = link.querySelector('.adb-cart__count');
                        if (badge) badge.textContent = String(count);
                        link.setAttribute('aria-label', config.cartLabel.replace('%d', count));
                    });
                }
                if (window.jQuery) window.jQuery(document.body).trigger('wc_fragment_refresh');
                if (result.data.cart_url) {
                    const url = new URL(result.data.cart_url, window.location.href);
                    if (url.origin === window.location.origin) cart.href = url.href;
                }
                ++stateRequest;
                displayCartState(result.data.in_cart);
                const added = result.data.added;
                const text = added === 0 ? config.nothingAdded : added === 1 ? config.addedOne : config.addedMany.replace('%d', added);
                showFeedback(added === 0 ? 'info' : 'success', text);
            } catch (error) {
                showFeedback('error', error instanceof TypeError || error instanceof SyntaxError ? config.failure : error.message);
            } finally {
                fields.disabled = false;
                pending = false;
                form.removeAttribute('aria-busy');
            }
        });
        render();
        refreshCartState().finally(() => { fields.disabled = false; });
        if (window.jQuery) {
            window.jQuery(document.body).on('added_to_cart.adbPairings removed_from_cart.adbPairings updated_wc_div.adbPairings wc_fragments_refreshed.adbPairings', refreshCartState);
        }
        window.addEventListener('pageshow', (event) => { if (event.persisted) refreshCartState(); });
        document.addEventListener('visibilitychange', () => { if (!document.hidden) refreshCartState(); });
    }

    document.querySelectorAll('[data-adb-pairings]').forEach(init);
}());
