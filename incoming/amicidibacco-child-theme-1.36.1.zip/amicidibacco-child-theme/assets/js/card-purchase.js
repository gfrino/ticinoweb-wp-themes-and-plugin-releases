(function ($) {
    'use strict';
    const dialog = document.getElementById('adb-quick-buy');
    if (!dialog || !dialog.showModal) return;
    const mount = dialog.querySelector('[data-form]');
    const status = dialog.querySelector('[data-feedback]');
    const cart = dialog.querySelector('[data-cart]');
    const detail = dialog.querySelector('[data-detail]');
    const title = dialog.querySelector('h2');
    const receipt = dialog.querySelector('[data-receipt]');
    const check = dialog.querySelector('[data-check]');
    const resume = dialog.querySelector('[data-continue]');
    let opener;
    let visit = 0;
    let saving = false;
    let tokens;

    document.addEventListener('click', async event => {
        const link = event.target.closest('[data-adb-buy]');
        if (!link || event.ctrlKey || event.metaKey || event.shiftKey || event.altKey) return;
        event.preventDefault();
        opener = link;
        const current = ++visit;
        receipt.hidden = check.hidden = resume.hidden = true;
        dialog.classList.remove('is-confirmed');
        mount.replaceChildren();
        tokens = null;
        detail.hidden = cart.hidden = true;
        detail.href = link.href;
        title.textContent = link.dataset.name;
        status.textContent = dialog.dataset.loading;
        dialog.showModal();
        dialog.querySelector('[data-dismiss]').focus();
        try {
            const url = new URL(dialog.dataset.options, location.href);
            url.searchParams.set('product_id', link.dataset.adbBuy);
            const response = await fetch(url, {cache: 'no-store'});
            if (!response.ok) throw Error();
            const result = await response.json();
            if (!result.success) throw Error();
            if (visit !== current || !dialog.open) return;
            tokens = result.data;
            mount.innerHTML = tokens.form;
            const form = mount.querySelector('.variations_form');
            if (!form) throw Error();
            // Avoid duplicate field IDs on a product page containing related wine cards.
            form.querySelectorAll('.variations select').forEach(select => {
                const label = select.closest('tr')?.querySelector('label');
                select.id = 'adb-quick-' + select.name;
                if (label) label.htmlFor = select.id;
                const options = [...select.options].filter(option => option.value && !option.disabled);
                if (options.length === 1) select.value = options[0].value;
            });
            $(form).wc_variation_form();
            $(form).trigger('adb_variation_controls');
            status.textContent = '';
        } catch {
            if (visit !== current || !dialog.open) return;
            mount.replaceChildren();
            detail.hidden = false;
            status.textContent = dialog.dataset.loadError;
        }
    });
    dialog.querySelector('[data-dismiss]').addEventListener('click', () => { if (!saving) dialog.close(); });
    resume.addEventListener('click', () => dialog.close());
    dialog.addEventListener('cancel', event => { if (saving) event.preventDefault(); });
    dialog.addEventListener('close', () => { ++visit; mount.replaceChildren(); });
    dialog.addEventListener('submit', async event => {
        const form = event.target;
        if (!form.matches('.variations_form')) return;
        event.preventDefault();
        const button = form.querySelector('[type="submit"]');
        const data = new FormData(form);
        const id = Number(data.get('variation_id'));
        if (saving || !id || !tokens || button.classList.contains('disabled')) return;
        saving = true;
        button.disabled = true;
        dialog.querySelector('[data-dismiss]').disabled = true;
        form.setAttribute('inert', '');
        status.textContent = '';
        const quantity = Number(data.get('quantity') || 1);
        const description = [...form.querySelectorAll('.variations select')].map(select => select.selectedOptions[0]?.textContent.trim()).filter(Boolean).join(' · ');
        const variation = [...data].filter(([key]) => key.startsWith('attribute_')).map(([attribute, value]) => ({attribute, value}));
        try {
            const response = await fetch(dialog.dataset.add, {method:'POST',
                headers:{'Content-Type':'application/json', 'Nonce':tokens.nonce, 'X-WP-Nonce':tokens.restNonce},
                body:JSON.stringify({id, quantity, variation})});
            const result = await response.json();
            if (!response.ok) {
                status.textContent = result.message ? new DOMParser().parseFromString(result.message, 'text/html').body.textContent : dialog.dataset.error;
                return;
            }
            if (!result.items?.some(item => Number(item.id) === id)) throw Error();
            mount.replaceChildren();
            title.textContent = dialog.dataset.added;
            receipt.querySelector('[data-wine]').textContent = opener.dataset.name;
            receipt.querySelector('[data-variant]').textContent = description;
            receipt.querySelector('[data-units]').textContent = quantity;
            const bottle = receipt.querySelector('[data-bottle]');
            const source = opener.closest('.adb-product')?.querySelector('.adb-product__photo img');
            bottle.replaceChildren();
            if (source) {
                const image = document.createElement('img');
                image.src = source.currentSrc || source.src;
                image.alt = '';
                bottle.append(image);
            }
            bottle.hidden = !source;
            dialog.classList.add('is-confirmed');
            receipt.hidden = check.hidden = cart.hidden = resume.hidden = false;
            title.focus({preventScroll: true});
            $(document.body).trigger('wc_fragment_refresh');
        } catch {
            status.textContent = dialog.dataset.error;
            cart.hidden = false;
        } finally {
            saving = false;
            button.disabled = false;
            form.removeAttribute('inert');
            dialog.querySelector('[data-dismiss]').disabled = false;
        }
    });
})(jQuery);
