/* Facets match one purchasable variation, never unrelated year/format/price combinations. */
(function (scope) {
    'use strict';
    function matches(row, selection, maps, except) {
        return Object.keys(selection).every(function (key) {
            var value = selection[key];
            if (key === except || value === '' || value === null || value === undefined) { return true; }
            if (key === 'adb_min_price') { return row.price !== null && row.price >= Number(value); }
            if (key === 'adb_max_price') { return row.price !== null && row.price <= Number(value); }
            return !maps[key] || (row.f[key] || []).indexOf(maps[key][value]) !== -1;
        });
    }
    function matchingIds(rows, selection, maps, except) {
        return Array.from(new Set(rows.filter(function (row) { return matches(row, selection, maps, except); }).map(function (row) { return row.id; })));
    }
    function facets(rows, selection, maps, key) {
        var counts = {};
        rows.forEach(function (row) {
            if (!matches(row, selection, maps, key)) { return; }
            (row.f[key] || []).forEach(function (id) { if (!counts[id]) { counts[id] = new Set(); } counts[id].add(row.id); });
        });
        return Object.fromEntries(Object.keys(counts).map(function (key) { return [key, counts[key].size]; }));
    }
    function pricePosition(price, min, max) { return Math.sqrt(Math.max(0, Math.min(1, (price - min) / Math.max(.01, max - min)))) * 1000; }
    function positionPrice(position, min, max) { return Math.round((min + Math.pow(Math.max(0, Math.min(1000, position)) / 1000, 2) * (max - min)) * 100) / 100; }
    function histogram(rows, selection, maps, min, max, buckets) {
        var prices = new Map(), unpriced = Object.assign({}, selection);
        delete unpriced.adb_min_price; delete unpriced.adb_max_price;
        rows.forEach(function (row) {
            if (row.price !== null && matches(row, unpriced, maps)) {
                prices.set(row.id, Math.min(prices.has(row.id) ? prices.get(row.id) : Infinity, row.price));
            }
        });
        var bins = Array(buckets).fill(0);
        prices.forEach(function (price) { bins[Math.min(buckets - 1, Math.floor(pricePosition(price, min, max) / 1000 * buckets))] += 1; });
        return bins;
    }
    if (typeof module === 'object' && module.exports) { module.exports = { matches: matches, matchingIds: matchingIds, facets: facets, histogram: histogram, pricePosition: pricePosition, positionPrice: positionPrice }; }
    if (!scope.document) { return; }

    var form = document.querySelector('[data-shop-filters]');
    if (!form) { return; }
    var data;
    try { data = JSON.parse(form.querySelector('[data-filter-index]').textContent); } catch (error) { return; }
    var maps = {}, selects = {}, controls = {}, selection = {}, active = null;
    var texts = data.strings;
    var number = new Intl.NumberFormat(data.locale || 'it-CH', { minimumFractionDigits: 0, maximumFractionDigits: 2 });
    data.filters.forEach(function (def) { maps[def.param] = Object.fromEntries(def.terms.map(function (term) { return [term.slug, term.id]; })); });
    var low = form.querySelector('[data-price-low]'), high = form.querySelector('[data-price-high]');
    var lowNumber = form.elements.adb_min_price, highNumber = form.elements.adb_max_price;
    var chips = form.querySelector('[data-filter-chips]');
    var bars = form.querySelector('[data-price-histogram]');
    var sliders = form.querySelector('[data-price-sliders]');

    const mobileToggle = document.querySelector('.adb-filters-toggle');
    const compact = window.matchMedia('(max-width: 899px)');
    function syncFilterLayout() {
        const expanded = mobileToggle.getAttribute('aria-expanded') === 'true';
        mobileToggle.hidden = !compact.matches;
        form.hidden = compact.matches && !expanded;
    }
    mobileToggle.addEventListener('click', function () {
        mobileToggle.setAttribute('aria-expanded', String(form.hidden));
        syncFilterLayout();
    });
    compact.addEventListener('change', syncFilterLayout);
    syncFilterLayout();

    function icon(kind) {
        var svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
        svg.setAttribute('viewBox', '0 0 20 20'); svg.setAttribute('fill', 'none'); svg.setAttribute('stroke', 'currentColor'); svg.setAttribute('stroke-width', '1.25'); svg.setAttribute('aria-hidden', 'true');
        var path = document.createElementNS(svg.namespaceURI, 'path');
        path.setAttribute('d', kind === 'close' ? 'M5 5l10 10M15 5L5 15' : 'M4 7l6 6 6-6'); svg.appendChild(path); return svg;
    }
    function element(tag, className, text) {
        var el = document.createElement(tag); if (className) { el.className = className; } if (text !== undefined) { el.textContent = text; } return el;
    }
    function close(restore) {
        if (!active) { return; }
        active.panel.hidden = true; active.trigger.setAttribute('aria-expanded', 'false');
        if (restore) { active.trigger.focus(); } active = null;
    }
    function enhance(select, label) {
        var trigger = element('button', 'adb-select-trigger'), value = element('span');
        const inline = select.hasAttribute('data-facet');
        trigger.type = 'button';
        if (inline) {
            trigger.appendChild(element('span', 'adb-facet-name', label));
            select.labels[0].hidden = true;
        }
        trigger.append(value, icon('chevron'));
        trigger.setAttribute('aria-haspopup', 'listbox'); trigger.setAttribute('aria-expanded', 'false');
        var panel = element('div', 'adb-select-popover'); panel.hidden = true;
        var list = element('div', 'adb-select-options'); list.setAttribute('role', 'listbox'); list.setAttribute('aria-label', label);
        var uid = 'adb-options-' + (select.name || 'sort'); list.id = uid; trigger.setAttribute('aria-controls', uid);
        var searchWrap = element('div', 'adb-select-search'), search = element('input');
        search.type = 'search'; search.placeholder = texts.search; search.setAttribute('aria-label', texts.search + ': ' + label); search.autocomplete = 'off'; searchWrap.appendChild(search);
        var empty = element('p', 'adb-select-empty', texts.none); empty.hidden = true;
        panel.append(searchWrap, list, empty);
        if (inline) { select.after(panel); } else { document.body.appendChild(panel); }
        select.before(trigger); select.hidden = true;
        var control = { trigger: trigger, panel: panel, list: list, inline: inline, counts: {}, refresh: refresh };
        function position() {
            var r = trigger.getBoundingClientRect();
            var width = Math.min(Math.max(r.width, 230), innerWidth - 32);
            panel.style.width = width + 'px'; panel.style.left = Math.max(16, Math.min(r.left, innerWidth - width - 16)) + 'px';
            var below = innerHeight - r.bottom - 20, above = r.top - 20;
            var room = below < 190 && above > below ? above : below;
            list.style.maxHeight = Math.max(80, Math.min(270, room - (searchWrap.hidden ? 20 : 74))) + 'px';
            panel.style.top = (below < 190 && above > below ? Math.max(12, r.top - panel.offsetHeight - 6) : r.bottom + 6) + 'px';
        }
        function visibleOptions() { return Array.from(list.children).filter(function (el) { return !el.hidden; }); }
        function refresh() {
            empty.hidden = true;
            var option = select.selectedOptions[0]; value.textContent = option ? option.textContent : texts.all;
            value.hidden = inline && !select.value;
            trigger.setAttribute('aria-label', label + ': ' + value.textContent); trigger.classList.toggle('has-value', !!select.value && select.name !== 'orderby');
            list.replaceChildren();
            Array.from(select.options).forEach(function (item) {
                var button = element('button', 'adb-select-option'), text = element('span', '', item.textContent);
                button.type = 'button'; button.tabIndex = -1; button.dataset.value = item.value; button.setAttribute('role', 'option'); button.setAttribute('aria-selected', item.value === select.value ? 'true' : 'false');
                button.appendChild(text);
                if (control.counts[item.value] !== undefined && item.value) { button.appendChild(element('small', '', String(control.counts[item.value]))); }
                button.addEventListener('click', function () { select.value = item.value; close(true); select.dispatchEvent(new Event('change', { bubbles: true })); refresh(); });
                list.appendChild(button);
            });
            searchWrap.hidden = select.options.length < 9;
        }
        function open() {
            if (active === control) { close(false); return; } close(false); refresh(); panel.hidden = false; active = control; trigger.setAttribute('aria-expanded', 'true'); search.value = ''; if (!inline) { position(); }
            if (!searchWrap.hidden && !(inline && compact.matches)) { search.focus(); } else { var option = list.querySelector('[aria-selected=true]') || list.firstElementChild; if (option) { option.focus(); } }
        }
        trigger.addEventListener('click', open);
        trigger.addEventListener('keydown', function (event) { if (event.key === 'ArrowDown' || event.key === 'ArrowUp') { event.preventDefault(); if (active !== control) { open(); } var options = visibleOptions(); if (options.length) { (event.key === 'ArrowUp' ? options[options.length - 1] : options[0]).focus(); } } });
        panel.addEventListener('keydown', function (event) {
            if (event.key === 'Escape') { event.preventDefault(); close(true); return; }
            if (event.key === 'Tab') { close(false); trigger.focus(); return; }
            var options = visibleOptions(), current = options.indexOf(document.activeElement), next;
            if (event.key === 'ArrowDown') { next = Math.min(options.length - 1, current + 1); }
            if (event.key === 'ArrowUp') { next = Math.max(0, current - 1); }
            if (document.activeElement !== search && event.key === 'Home') { next = 0; }
            if (document.activeElement !== search && event.key === 'End') { next = options.length - 1; }
            if (next !== undefined && options[next]) { event.preventDefault(); options[next].focus(); }
        });
        search.addEventListener('input', function () {
            var query = search.value.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLocaleLowerCase();
            Array.from(list.children).forEach(function (option) { var text = option.firstElementChild.textContent.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLocaleLowerCase(); option.hidden = !text.includes(query); });
            empty.hidden = visibleOptions().length > 0;
        });
        select.addEventListener('change', refresh);
        refresh(); return control;
    }
    document.addEventListener('pointerdown', function (event) { if (active && !active.panel.contains(event.target) && !active.trigger.contains(event.target)) { close(false); } });
    document.addEventListener('focusin', function (event) { if (active && !active.panel.contains(event.target) && event.target !== active.trigger) { close(false); } });
    window.addEventListener('resize', function () { if (active && !active.inline) { close(false); } });
    window.addEventListener('scroll', function (event) { if (active && !active.inline && !active.panel.contains(event.target)) { close(false); } }, true);
    data.filters.forEach(function (def) { var select = form.elements[def.param]; if (select) { selects[def.param] = select; controls[def.param] = enhance(select, def.label); } });
    var ordering = document.querySelector('.woocommerce-ordering select');
    if (ordering) { enhance(ordering, ordering.getAttribute('aria-label') || texts.order); }
    sliders.hidden = false; bars.hidden = false;
    function displayedLow() {
        if (lowNumber.value !== '') return Number(lowNumber.value);
        return highNumber.value === '' ? data.min : Math.min(data.min, Number(highNumber.value));
    }
    function displayedHigh() {
        return highNumber.value === '' ? Math.max(data.max, displayedLow()) : Number(highNumber.value);
    }
    // A manually entered budget outside the catalog domain still describes a valid empty search.
    if (lowNumber.value !== '' && highNumber.value !== '' && Number(highNumber.value) < Number(lowNumber.value)) {
        if (Number(highNumber.value) < data.min) { lowNumber.value = highNumber.value; }
        else { highNumber.value = lowNumber.value; }
    }
    function read() {
        selection = {};
        Object.keys(selects).forEach(function (key) { if (selects[key].value) { selection[key] = selects[key].value; } });
        if (Number(lowNumber.value) > data.min) { selection.adb_min_price = Number(lowNumber.value); }
        if (highNumber.value !== '' && Number(highNumber.value) < data.max) { selection.adb_max_price = Number(highNumber.value); }
    }
    function chip(text, remove) {
        var button = element('button', 'adb-filter-chip', text); button.type = 'button'; button.setAttribute('aria-label', texts.remove.replace('%s', text)); button.appendChild(icon('close')); button.addEventListener('click', remove); chips.appendChild(button);
    }
    function render() {
        read();
        data.filters.forEach(function (def) {
            var select = selects[def.param]; if (!select) { return; }
            var counts = facets(data.rows, selection, maps, def.param), selected = select.value;
            select.replaceChildren(new Option(texts.all, '')); controls[def.param].counts = {};
            def.terms.forEach(function (term) {
                if (counts[term.id] || term.slug === selected) { select.add(new Option(term.name, term.slug)); controls[def.param].counts[term.slug] = counts[term.id] || 0; }
            });
            if (selected && !def.terms.some(function (term) { return term.slug === selected; })) { select.add(new Option(texts.unavailable, selected)); controls[def.param].counts[selected] = 0; }
            select.value = selected; controls[def.param].refresh();
        });
        var count = matchingIds(data.rows, selection, maps).length;
        form.querySelector('[data-filter-count]').textContent = (count === 1 ? texts.one : texts.count).replace('%d', count);
        form.querySelector('[data-filter-apply]').textContent = (count === 1 ? texts.applyOne : texts.apply).replace('%d', count);
        var a = displayedLow(), b = displayedHigh();
        var budgetActive = selection.adb_min_price !== undefined || selection.adb_max_price !== undefined;
        sliders.closest('fieldset').classList.toggle('has-budget', budgetActive);
        low.value = pricePosition(a, data.min, data.max); high.value = pricePosition(b, data.min, data.max);
        [low, high].forEach(function (slider) { slider.setAttribute('aria-valuemin', data.min); slider.setAttribute('aria-valuemax', data.max); slider.setAttribute('aria-valuenow', slider === low ? a : b); });
        low.setAttribute('aria-valuetext', data.currency + ' ' + number.format(a)); high.setAttribute('aria-valuetext', data.currency + ' ' + number.format(b));
        sliders.style.setProperty('--price-left', (pricePosition(a, data.min, data.max) / 10) + '%'); sliders.style.setProperty('--price-right', (100 - pricePosition(b, data.min, data.max) / 10) + '%');
        var bins = histogram(data.rows, selection, maps, data.min, data.max, 28), tallest = Math.max.apply(null, bins.concat([1])); bars.replaceChildren();
        bins.forEach(function (n, i) { var bar = element('i'), price = positionPrice((i + .5) / bins.length * 1000, data.min, data.max); bar.style.setProperty('--bar-height', (n / tallest * 100) + '%'); bar.classList.toggle('is-in-budget', budgetActive && price >= a && price <= b); bars.appendChild(bar); });
        chips.replaceChildren();
        data.filters.forEach(function (def) { if (selection[def.param]) { var term = def.terms.find(function (term) { return term.slug === selection[def.param]; }); chip(def.label + ': ' + (term ? term.name : texts.unavailable), function () { selects[def.param].value = ''; render(); controls[def.param].trigger.focus(); }); } });
        if (selection.adb_min_price !== undefined || selection.adb_max_price !== undefined) { chip(texts.budget + ': ' + data.currency + ' ' + number.format(a) + ' – ' + number.format(b), function () { lowNumber.value = ''; highNumber.value = ''; render(); lowNumber.focus(); }); }
        const activeCount = chips.childElementCount;
        mobileToggle.querySelector('[data-active-filters]').textContent = activeCount ? '(' + activeCount + ')' : '';
        form.querySelector('[data-filter-reset]').setAttribute('aria-disabled', Object.keys(selection).length ? 'false' : 'true');
    }
    form.addEventListener('change', function (event) {
        if (!event.target.matches('[data-facet], [name=adb_min_price], [name=adb_max_price]')) { return; }
        if (event.target === lowNumber || event.target === highNumber) {
            if (lowNumber.value !== '' && highNumber.value !== '' && Number(lowNumber.value) > Number(highNumber.value)) {
                if (event.target === lowNumber) highNumber.value = lowNumber.value;
                else lowNumber.value = highNumber.value;
            }
        }
        render();
    });
    form.addEventListener('input', function (event) { if (event.target === lowNumber || event.target === highNumber) { render(); } });
    [low, high].forEach(function (slider) {
        slider.addEventListener('input', function () {
            if (Number(low.value) > Number(high.value)) { if (slider === low) { high.value = low.value; } else { low.value = high.value; } }
            var min = slider === low ? positionPrice(Number(low.value), data.min, data.max) : displayedLow();
            var max = slider === high ? positionPrice(Number(high.value), data.min, data.max) : displayedHigh();
            if (min > max) { if (slider === low) max = min; else min = max; }
            lowNumber.value = min; highNumber.value = max; render();
        });
        slider.addEventListener('keydown', function (event) {
            var step = event.shiftKey ? 5 : 1, value = slider === low ? displayedLow() : displayedHigh();
            if (event.key === 'ArrowLeft' || event.key === 'ArrowDown') { value -= step; }
            else if (event.key === 'ArrowRight' || event.key === 'ArrowUp') { value += step; }
            else if (event.key === 'PageDown') { value -= 10; }
            else if (event.key === 'PageUp') { value += 10; }
            else if (event.key === 'Home') { value = data.min; }
            else if (event.key === 'End') { value = data.max; }
            else { return; }
            event.preventDefault(); value = Math.max(data.min, Math.min(data.max, value));
            if (slider === low) { lowNumber.value = value; if (highNumber.value !== '' && value > Number(highNumber.value)) { highNumber.value = value; } }
            else { lowNumber.value = Math.min(displayedLow(), value); highNumber.value = value; }
            render();
        });
    });
    form.addEventListener('formdata', function (event) {
        Array.from(event.formData.entries()).forEach(function (pair) { if (pair[1] === '') { event.formData.delete(pair[0]); } });
        if (Number(lowNumber.value) <= data.min) { event.formData.delete('adb_min_price'); }
        if (Number(highNumber.value) >= data.max) { event.formData.delete('adb_max_price'); }
    });
    form.addEventListener('submit', function () {
        if (lowNumber.value !== '' && highNumber.value !== '' && Number(lowNumber.value) > Number(highNumber.value)) {
            var previous = lowNumber.value; lowNumber.value = highNumber.value; highNumber.value = previous; render();
        }
    });
    render();
}(typeof window === 'undefined' ? {} : window));
