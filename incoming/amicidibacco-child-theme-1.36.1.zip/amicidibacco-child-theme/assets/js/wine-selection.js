(function (root, factory) {
    'use strict';
    if (typeof module === 'object' && module.exports) { module.exports = factory(); }
    else { root.ADBWineSelection = factory(); }
}(typeof window !== 'undefined' ? window : globalThis, function () {
    'use strict';

    /**
     * Return original {id, group, image, ...} items, without mutating either input.
     * recent.ids/groups/images are newest-first; images is optional.
     * The caller owns history persistence.
     * A small pool may reuse history, but never duplicates a wine or image.
     */
    function choose(pool, recent, limit, random) {
        limit = limit === undefined ? 5 : Math.max(0, Math.floor(Number(limit) || 0));
        random = typeof random === 'function' ? random : Math.random;
        recent = recent || {};
        var recentIds = (Array.isArray(recent.ids) ? recent.ids : []).map(String);
        var recentGroups = (Array.isArray(recent.groups) ? recent.groups : []).map(String);
        var recentImages = (Array.isArray(recent.images) ? recent.images : []).map(String);
        var candidates = (Array.isArray(pool) ? pool : []).filter(function (item) {
            return item && Number(item.id) > 0 && typeof item.group === 'string' && item.group.trim() && Number(item.image) > 0;
        });
        // Fisher–Yates shuffles a new array, including on a cached page response.
        for (var index = candidates.length - 1; index > 0; index -= 1) {
            var sample = Number(random());
            var target = Math.floor(Math.min(0.9999999999999999, Math.max(0, sample || 0)) * (index + 1));
            var temporary = candidates[index];
            candidates[index] = candidates[target];
            candidates[target] = temporary;
        }
        // Prefer wines outside the immediately preceding display, even when every
        // candidate has appeared on an earlier visit. The shuffle breaks ties.
        function position(item, ids, groups, images) {
            var hits = [ids.indexOf(String(item.id)), groups.indexOf(item.group), images.indexOf(String(item.image))];
            var positions = hits.filter(function (index) { return index >= 0; });
            return positions.length ? Math.min.apply(Math, positions) : Infinity;
        }
        candidates.sort(function (a, b) {
            var first = position(a, recentIds, recentGroups, recentImages);
            var second = position(b, recentIds, recentGroups, recentImages);
            function priority(index) { return index < limit ? 0 : Number.isFinite(index) ? 1 : 2; }
            return priority(second) - priority(first);
        });
        var selected = [];
        var ids = new Set();
        var groups = new Set();
        var images = new Set();
        candidates.some(function (item) {
            if (selected.length >= limit) { return true; }
            var id = String(item.id);
            var image = String(item.image);
            if (!ids.has(id) && !groups.has(item.group) && !images.has(image)) {
                selected.push(item);
                ids.add(id);
                groups.add(item.group);
                images.add(image);
            }
            return false;
        });
        // A small collection may need to repeat a bottle. Move it to a
        // different slot whenever another distinct wine is available.
        function repeats(item, index) {
            return String(item.id) === recentIds[index] || item.group === recentGroups[index] || String(item.image) === recentImages[index];
        }
        selected.forEach(function (item, index) {
            if (!repeats(item, index)) { return; }
            var swap = selected.findIndex(function (other, slot) {
                return slot !== index && !repeats(other, index) && !repeats(item, slot);
            });
            if (swap >= 0) { selected[index] = selected[swap]; selected[swap] = item; }
        });
        return selected;
    }

    // Each section has its own history, so one territory cannot supply wines
    // to another. An unavailable storage area still leaves a random display.
    const wineHistory = new Map();
    function chooseForVisit(pool, section, limit) {
        if (!limit) return [];
        const key = 'adb-wine-history:' + section;
        let recent = wineHistory.get(key) || {};
        try { recent = JSON.parse(sessionStorage.getItem(key)) || recent; } catch {}
        const chosen = choose(pool, recent, limit);
        if (!chosen.length) return [];
        const history = {};
        for (const [field, values] of [['ids', 'id'], ['groups', 'group'], ['images', 'image']]) {
            const past = Array.isArray(recent[field]) ? recent[field] : [];
            history[field] = [...chosen.map(item => item[values]), ...past].slice(0, Math.max(15, limit * 3));
        }
        wineHistory.set(key, history);
        try { sessionStorage.setItem(key, JSON.stringify(history)); } catch {}
        return chosen;
    }

    return { choose, chooseForVisit };
}));
