/* Native WooCommerce interactions with measured, progressive editorial refinements. */
(function () {
    'use strict';
    const reduced = window.matchMedia('(prefers-reduced-motion: reduce)');
    const desktop = window.matchMedia('(min-width:1101px)');
    const title = document.querySelector('.adb-product-stage .product_title');
    const summary = document.querySelector('.adb-product-stage > .summary');
    const header = document.querySelector('[data-header]');

    // A tall purchase column may scroll up naturally before its lower edge follows the viewport.
    // Sticky remains bounded by the existing stage, immediately before the winery and native metadata.
    let fitFrame = 0;
    const fitSummary = () => {
        fitFrame = 0;
        if (!summary || !desktop.matches) { summary?.style.removeProperty('--purchase-top'); return; }
        const headerBottom = header ? header.offsetHeight + Math.max(0,parseFloat(getComputedStyle(header).top)||0) : 0;
        summary.style.setProperty('--purchase-top',`${Math.min(headerBottom + 24, innerHeight - summary.offsetHeight - 24)}px`);
    };
    const scheduleFit = () => { if (!fitFrame) fitFrame = requestAnimationFrame(fitSummary); };
    if (summary) {
        if ('ResizeObserver' in window) { const observer = new ResizeObserver(scheduleFit); observer.observe(summary); if (header) observer.observe(header); }
        addEventListener('resize',scheduleFit,{passive:true});desktop.addEventListener('change',scheduleFit);fitSummary();
    }

    // The base title remains readable. The optional sheen occupies only the original letterforms.
    if (title) {
        let inView = false;
        const play = () => title.classList.toggle('is-title-lit',inView && !document.hidden && !reduced.matches);
        if ('IntersectionObserver' in window) new IntersectionObserver(entries => { inView = entries[0].isIntersecting; play(); }).observe(title);
        document.addEventListener('visibilitychange',play);reduced.addEventListener('change',play);
    }

    // Remove only empty margins from the displayed viewport; original CMS files are untouched.
    // Full originals retain their resolution rather than enlarging a generated thumbnail.
    document.querySelectorAll('[data-winery-logo]').forEach(image => {
        const fitLogo = () => {
            try {
                const nw=image.naturalWidth,nh=image.naturalHeight;
                if (!nw || !nh) return;
                const scale=Math.min(1,700/Math.max(nw,nh)),w=Math.max(1,Math.round(nw*scale)),h=Math.max(1,Math.round(nh*scale));
                const canvas=document.createElement('canvas');canvas.width=w;canvas.height=h;
                const ctx=canvas.getContext('2d',{willReadFrequently:true});if (!ctx) return;
                ctx.drawImage(image,0,0,w,h);const pixels=ctx.getImageData(0,0,w,h).data;
                let left=w,top=h,right=-1,bottom=-1;
                for(let y=0;y<h;y++)for(let x=0;x<w;x++){const i=(y*w+x)*4;if(pixels[i+3]>32 && Math.min(pixels[i],pixels[i+1],pixels[i+2])<242){left=Math.min(left,x);right=Math.max(right,x);top=Math.min(top,y);bottom=Math.max(bottom,y);}}
                if(right<left || bottom<top) return;
                const pad=Math.max(3,Math.round(Math.max(w,h)*.012));left=Math.max(0,left-pad);top=Math.max(0,top-pad);right=Math.min(w,right+pad);bottom=Math.min(h,bottom+pad);
                const bw=right-left,bh=bottom-top;if(bw<5 || bh<5) return;
                const mark=image.parentElement;
                mark.style.setProperty('--logo-ratio',String(bw/bh));
                const vector=/\.svg(?:\?|$)/i.test(image.currentSrc||image.src);
                const density=vector ? Infinity : bw/scale/Math.max(2,Math.min(3,devicePixelRatio||1));
                mark.style.setProperty('--logo-width',`${Math.min(240,136*bw/bh,density)}px`);
                image.style.width=`${w/bw*100}%`;image.style.height=`${h/bh*100}%`;
                image.style.setProperty('--logo-image-height',`${h/bh*100}%`);
                image.style.left=`${-left/bw*100}%`;image.style.top=`${-top/bh*100}%`;
                mark.classList.add('has-logo-crop');
            } catch (_) { /* A remote or unreadable original retains its ordinary complete image. */ }
        };
        if(image.complete) fitLogo();else image.addEventListener('load',fitLogo,{once:true});
    });

    // Open the native PhotoSwipe viewer through its current image link; never paint a second bottle.
    const initGallery = () => {
        if (typeof window.PhotoSwipe !== 'function') return;
        document.querySelectorAll('.woocommerce-product-gallery').forEach(gallery => {
            if (gallery.querySelector('.adb-gallery-zoom')) return;
            const button=document.createElement('button');button.type='button';button.className='adb-gallery-zoom';
            const label=window.wc_single_product_params?.i18n_product_gallery_trigger_text;
            if (!label) return;
            button.setAttribute('aria-label',label);button.setAttribute('aria-haspopup','dialog');button.setAttribute('aria-controls','photoswipe-fullscreen-dialog');button.title=label;
            button.innerHTML='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" aria-hidden="true"><circle cx="10.5" cy="10.5" r="6.5"/><path d="m15.5 15.5 5 5"/></svg>';
            button.addEventListener('click',()=>{const link=gallery.querySelector('.flex-active-slide a')||gallery.querySelector('.woocommerce-product-gallery__image a');link?.click();});
            gallery.append(button);
        });
    };
    if (typeof window.jQuery === 'function') window.jQuery(initGallery);

    const sections = document.querySelectorAll('[data-product-reveal]');
    if (!sections.length || !('IntersectionObserver' in window) || reduced.matches) return;
    const observer = new IntersectionObserver(entries => {
        entries.forEach(entry => { if(entry.isIntersecting){entry.target.classList.add('is-product-visible');observer.unobserve(entry.target);} });
    },{threshold:.08,rootMargin:'0px 0px -30px 0px'});
    sections.forEach(section=>observer.observe(section));
}());
