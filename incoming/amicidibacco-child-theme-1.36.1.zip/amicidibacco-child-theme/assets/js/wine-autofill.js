(() => {
    'use strict';

    const box = document.getElementById('adb-wine-fill');
    if (!box) return;

    const form = box.closest('form');
    const start = box.querySelector('#adb-fill-start');
    const producer = box.querySelector('#adb-fill-producer');
    const vintage = box.querySelector('#adb-fill-vintage');
    const pdfButton = box.querySelector('#adb-fill-pdf');
    const clearPdf = box.querySelector('#adb-fill-pdf-clear');
    const pdfName = box.querySelector('#adb-fill-pdf-name');
    const status = box.querySelector('#adb-fill-status');
    const title = document.getElementById('title');
    const saveDraft = document.getElementById('save-post');
    const config = window.adbWineFill;
    const key = 'adb-wine:' + location.pathname.replace(/post(?:-new)?\.php$/, '') + ':' + box.dataset.id;
    let pdf = 0;
    let frame;

    function show(message, error = false) {
        status.textContent = message;
        status.className = error ? 'notice notice-error inline' : 'notice notice-info inline';
    }

    function selectPdf(id, name) {
        pdf = Number(id) || 0;
        pdfName.textContent = name || '';
        clearPdf.hidden = !pdf;
    }

    pdfButton.addEventListener('click', () => {
        if (!frame) {
            frame = wp.media({ title: config.choose, button: { text: config.usePdf }, library: { type: 'application/pdf' }, multiple: false });
            frame.on('select', () => {
                const attachment = frame.state().get('selection').first().toJSON();
                selectPdf(attachment.id, attachment.filename || attachment.title);
            });
        }
        frame.open();
    });
    clearPdf.addEventListener('click', () => selectPdf(0, ''));

    const usePrice = box.querySelector('#adb-fill-use-price');
    const priceField = document.getElementById('_regular_price');
    if (usePrice && priceField) {
        usePrice.addEventListener('click', () => {
            if (priceField.value.trim()) return;
            const decimal = window.woocommerce_admin?.mon_decimal_point || '.';
            priceField.value = usePrice.dataset.amount.replace('.', decimal);
            priceField.dispatchEvent(new Event('change', { bubbles: true }));
            usePrice.textContent = config.priceUsed;
            usePrice.disabled = true;
        });
    }

    start.addEventListener('click', () => {
        const name = title && title.value.trim();
        const kind = document.getElementById('adb-product-tipo_di_prodotto');
        if (!name || !producer.value) {
            show(config.identity, true);
            (name ? producer : title)?.focus();
            return;
        }
        if (!saveDraft || (kind && kind.value && kind.value !== 'VINO SINGOLO')) {
            show(config.draft, true);
            return;
        }
        if (vintage.value && !/^\d{4}$/.test(vintage.value)) {
            show(config.vintage, true);
            vintage.closest('details').open = true;
            vintage.focus();
            return;
        }
        // Use the native draft submission so WooCommerce saves any pending form edits first.
        const job = Array.from(crypto.getRandomValues(new Uint8Array(16)), byte => byte.toString(16).padStart(2, '0')).join('');
        const request = { job, name, producer: producer.value, vintage: vintage.value, pdf, filename: pdfName.textContent };
        try {
            sessionStorage.setItem(key + ':job', JSON.stringify(request));
        } catch (error) {
            show(config.storage, true);
            return;
        }
        const marker = document.createElement('input');
        marker.type = 'hidden';
        marker.name = 'adb_fill_job';
        marker.value = job;
        form.appendChild(marker);
        show(config.saving);
        saveDraft.click();
        // The native submit can be cancelled by validation or another editor extension.
        marker.remove();
    });

    async function generate(request) {
        producer.value = request.producer;
        vintage.value = request.vintage;
        selectPdf(request.pdf, request.filename);
        if (request.vintage || request.pdf) vintage.closest('details').open = true;
        show(config.working);
        box.scrollIntoView({ block: 'nearest' });
        // Prevent new edits from becoming stale while the server updates this saved draft.
        form.inert = true;
        box.setAttribute('aria-busy', 'true');
        try {
            const args = new URLSearchParams({
                action: 'adb_fill_wine_draft',
                nonce: box.dataset.nonce,
                id: box.dataset.id,
                version: box.dataset.version,
                name: request.name,
                producer: request.producer,
                vintage: request.vintage,
                pdf: request.pdf
            });
            const response = await fetch(config.ajax, { method: 'POST', credentials: 'same-origin', body: args });
            const result = await response.json();
            if (!result.success) {
                throw new Error(typeof result.data === 'string' ? result.data : config.failure);
            }
            sessionStorage.setItem(key + ':outcome', result.data.message);
            location.reload();
        } catch (error) {
            show(error instanceof SyntaxError || error instanceof TypeError ? config.failure : error.message, true);
            form.inert = false;
            box.removeAttribute('aria-busy');
            status.focus();
        }
    }

    try {
        const url = new URL(location.href);
        const job = url.searchParams.get('adb_fill_job');
        if (job) {
            url.searchParams.delete('adb_fill_job');
            history.replaceState(null, '', url);
            const request = JSON.parse(sessionStorage.getItem(key + ':job') || 'null');
            if (request && request.job === job) {
                sessionStorage.removeItem(key + ':job');
                generate(request);
            }
        }
        const outcome = sessionStorage.getItem(key + ':outcome');
        if (outcome) {
            sessionStorage.removeItem(key + ':outcome');
            show(outcome);
            status.className = 'notice notice-success inline';
            status.focus();
        }
    } catch (error) {
        show(config.storage, true);
    }
})();
