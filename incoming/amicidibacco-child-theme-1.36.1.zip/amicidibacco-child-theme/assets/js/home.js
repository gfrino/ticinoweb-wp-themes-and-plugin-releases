(() => {
    'use strict';
    const math=window.ADBMotion;
    if (!math) return;
    const {clamp,passage,coverZoom,portal:portalState}=math;
    const reduced=matchMedia('(prefers-reduced-motion: reduce)');
    const desktop=matchMedia('(min-width: 901px) and (pointer: fine)');
    const saveData=!!navigator.connection?.saveData;
    let gameVisible=false;
    const hero=document.querySelector('[data-hero]');
    const landscape=document.querySelector('[data-hero-landscape] img');
    const stack=document.querySelector('[data-wine-stack]');
    const chooseForVisit = (pool, section, limit) => window.ADBWineSelection.chooseForVisit(pool, location.pathname + ':' + section, limit);

    const wineItem = node => ({
        id: Number(node.dataset.wineId), group: node.dataset.wineGroup,
        image: Number(node.dataset.wineImage), node
    });
    function chooseWineSections() {
        for (const list of document.querySelectorAll('[data-home-wines]')) {
            const template = list.nextElementSibling;
            if (!template?.matches('template[data-home-wine-pool]')) continue;
            const slots = [...list.children];
            const pool = [...template.content.children].map(wineItem);
            const chosen = chooseForVisit(pool, list.dataset.homeWines, slots.length);
            if (!chosen.length) continue;
            const active = document.activeElement;
            const slot = slots.findIndex(node => node.contains(active));
            const link = slot < 0 ? -1 : [...slots[slot].querySelectorAll('a')].indexOf(active);
            const nodes = chosen.map(item => item.node.content.firstElementChild.cloneNode(true));
            if (list.hasAttribute('data-territory-wines')) {
                // The scroll controller retains the original list-item references.
                nodes.forEach((node, index) => slots[index].replaceChildren(...node.childNodes));
            } else {
                list.replaceChildren(...nodes);
            }
            if (link >= 0) list.children[slot]?.querySelectorAll('a')[link]?.focus({preventScroll: true});
        }
    }

    function chooseWineStack() {
        const template = document.querySelector('[data-wine-pool]');
        if (!stack || !template) return;
        const pool = [...template.content.querySelectorAll('[data-wine-slide]')].map(wineItem);
        const chosen = chooseForVisit(pool, 'hero', 5);
        if (!chosen.length) return;
        const nodes = chosen.map((item, index) => {
            const node = item.node.cloneNode(true);
            const first = index === 0;
            node.dataset.wineSlide = String(index);
            node.classList.toggle('is-active', first);
            node.inert = !first;
            const image = node.querySelector('img');
            if (first) {
                node.removeAttribute('aria-hidden');
                node.removeAttribute('tabindex');
                if (image) {
                    image.loading = 'eager';
                    image.fetchPriority = 'high';
                }
            } else {
                node.setAttribute('aria-hidden', 'true');
                node.setAttribute('tabindex', '-1');
                if (image) {
                    const placeholder = document.createElement('template');
                    image.replaceWith(placeholder);
                    placeholder.content.append(image);
                }
            }
            return node;
        });
        stack.replaceChildren(...nodes);
    }
    chooseWineStack();
    chooseWineSections();
    let slides=[...document.querySelectorAll('[data-wine-slide]')];
    const opening=document.querySelector('[data-opening]');
    const openingStage=document.querySelector('[data-opening-stage]');
    const openingIntro=document.querySelector('[data-opening-intro]');
    const portalInk=document.querySelector('[data-portal-ink]');
    const nextScene=document.querySelector('[data-next-scene]');
    const portraits=[...document.querySelectorAll('.adb-territory__photo img,.adb-story__photo img')];
    let lenis=null,raf=0,lastTime=0,dirty=true,bounds={},selected=-1;
    const flipAxes = ['0,1,0', '-1,0,0', '0.8,1,0', '0,-1,0', '1,0,0', '-0.8,1,0'];
    const flipDurationMs = 1200;
    let axisIndex = 0, flip = null, dwell = 0;
    let commerceVisible = true, heroVisible = true, focused = false, hovered = false;
    const signature = portalInk?.querySelector('[data-entry-outline]');
    const cinematic = () => !reduced.matches && !saveData && !!signature;
    const canRotate = () => !reduced.matches && !saveData && slides.length > 1;
    const autoAdvance = () => canRotate() && heroVisible && commerceVisible && !focused && !hovered && !document.hidden;

    function prepareWineImage(slide) {
        const holder = slide?.querySelector('template');
        if (!holder) return;
        const image = holder.content.querySelector('img');
        image.loading = 'eager';
        holder.replaceWith(image);
    }

    function showWine(index, moveFocus = false) {
        const previous = slides[selected];
        const next = slides[index];
        if (!next || selected === index) return;
        next.inert = false;
        next.removeAttribute('aria-hidden');
        next.removeAttribute('tabindex');
        next.classList.add('is-active');
        selected = index;
        if (moveFocus) next.focus({preventScroll:true});
        if (previous) {
            previous.inert = true;
            previous.setAttribute('aria-hidden', 'true');
            previous.setAttribute('tabindex', '-1');
            previous.classList.remove('is-active');
        }
    }

    function finishFlip() {
        if (flip) {
            showWine(flip.target, flip.keyboard);
            stack.style.removeProperty('transform');
            flip = null;
        }
        dwell = 0;
    }

    function stepWine(direction, keyboard = false) {
        if (slides.length < 2) return;
        finishFlip();
        const target = (selected + direction + slides.length) % slides.length;
        prepareWineImage(slides[target]);
        if (!canRotate()) {
            showWine(target, keyboard);
            return;
        }
        flip = {target, keyboard, direction, axis: flipAxes[axisIndex], elapsed: null};
        axisIndex = (axisIndex + 1) % flipAxes.length;
        requestFrame();
    }

    function paintStack(dt) {
        if (!flip) {
            if (!autoAdvance()) return;
            const readingTime = innerWidth > 760 ? 4000 : 5000;
            const preloadAt = readingTime / 2;
            if (dwell < preloadAt && dwell + dt >= preloadAt) {
                prepareWineImage(slides[(selected + 1) % slides.length]);
            }
            dwell += dt;
            if (dwell < readingTime) return;
            stepWine(1);
        }
        flip.elapsed = flip.elapsed === null ? 0 : flip.elapsed + dt;
        const t = clamp(flip.elapsed / flipDurationMs);
        const eased = (1 - Math.cos(Math.PI * t)) / 2;
        const back = eased >= 0.5;
        if (back) showWine(flip.target, flip.keyboard);
        // Both faces meet edge-on. The new label unfolds facing the reader.
        const angle = (eased - (back ? 1 : 0)) * 180 * flip.direction;
        stack.style.transform = `perspective(1250px) rotate3d(${flip.axis},${angle}deg)`;
        if (t === 1) finishFlip();
    }
    function paintScroll() {
        const y=scrollY,h=innerHeight;
        if(opening&&y+h>bounds.opening.top&&y<bounds.opening.bottom){
            const progress=clamp((y-bounds.opening.start)/bounds.opening.travel);
            const geometry=bounds.entry;
            const state=portalState(progress,geometry.zoomEnd);
            // Fixed horizontal anchor: zoom into the lettering without a sideways camera pan.
            const tx=geometry.startX;
            const ty=geometry.startY+(geometry.height*.5-geometry.startY)*state.rise;
            const matrix=`translate(${tx} ${ty}) scale(${state.zoom}) translate(${-geometry.pivotX} ${-geometry.pivotY})`;
            portalInk?.setAttribute('transform',matrix);
            if(portalInk)portalInk.style.opacity=String(state.ink);
            if(nextScene)nextScene.style.opacity=String(state.sceneBlend);
            if(hero){hero.style.opacity=String(state.heroOpacity);hero.style.transform=`translate3d(0,${-progress*55}px,0)`;hero.inert=progress>.45;}
            if(openingIntro)openingIntro.style.opacity=String(state.introOpacity);
            if(landscape)landscape.style.transform=`scale(${1.05+progress*.13}) translate3d(0,${progress*-14}px,0)`;
            commerceVisible=progress<.42;
        }
        portraits.forEach((image,i)=>{
            const b=bounds.portraits[i];
            if(y+h>b.top&&y<b.bottom)image.style.transform=`translate3d(0,${(passage(b.top,b.height,y,h)-.5)*-32}px,0) scale(1.07)`;
        });
    }
    function frame(time) {
        raf=0;
        if(document.hidden||gameVisible){lastTime=0;return;}
        const dt=lastTime?Math.min(250,time-lastTime):16;lastTime=time;
        lenis?.raf(time);
        if (flip || autoAdvance()) paintStack(dt);
        if(cinematic()&&(dirty||lenis?.isScrolling))paintScroll();
        dirty=false;
        if(lenis||flip||autoAdvance())requestFrame();
    }
    function requestFrame(){if(!raf&&!document.hidden&&!gameVisible)raf=requestAnimationFrame(frame);}
    function requestPaint(){dirty=true;requestFrame();}
    function box(el){if(!el)return{top:0,bottom:0,height:1};const top=el.getBoundingClientRect().top+scrollY,height=el.offsetHeight;return{top,height,bottom:top+height};}
    function measure() {
        if (selected < 0) showWine(0);
        if (!canRotate()) finishFlip();
        document.body.classList.add('adb-motion-ready');
        document.body.classList.toggle('adb-cinematic',cinematic());
        const wantsSmooth=desktop.matches&&cinematic()&&typeof window.Lenis==='function';
        if(wantsSmooth&&!lenis)lenis=new window.Lenis({autoRaf:false,lerp:.12,smoothWheel:true,syncTouch:false,anchors:false,prevent:node=>!!node.closest?.('dialog,textarea,select,[data-lenis-prevent]')});
        if(!wantsSmooth&&lenis){lenis.destroy();lenis=null;}
        window.adbSmoothScroll=lenis;
        bounds={opening:box(opening),portraits:portraits.map(image=>box(image.parentElement))};
        if(openingStage){
            bounds.opening.start=bounds.opening.top-(parseFloat(getComputedStyle(openingStage).top)||0);
            bounds.opening.travel=Math.max(1,opening.offsetHeight-openingStage.offsetHeight);
            const canvasHeight=1440*openingStage.clientHeight/Math.max(1,openingStage.clientWidth);
            const svg=openingStage.querySelector('.adb-entry svg');
            svg?.setAttribute('viewBox',`0 0 1440 ${canvasHeight}`);
            // Signature coordinates use the supplied 900 × 215 viewBox.
            // (607, 170) lies inside the lower counter of the B with 9 units of clearance.
            const nominalWidth = parseFloat(getComputedStyle(openingStage).getPropertyValue('--adb-signature-width'));
            const scale = Math.min(nominalWidth / 900, canvasHeight * .16 / 215);
            signature?.setAttribute('transform', `scale(${scale})`);
            const pivotX = 607 * scale;
            const pivotY = 170 * scale;
            const copyLeft = hero?.querySelector('.adb-hero__copy')?.getBoundingClientRect().left || 0;
            const startX = copyLeft * 1440 / openingStage.clientWidth + pivotX;
            bounds.entry = {
                height: canvasHeight,
                pivotX,
                pivotY,
                startX,
                startY: canvasHeight * .91 + pivotY - 107.5 * scale,
                zoomEnd: coverZoom({x: startX, y: canvasHeight * .5}, 9 * scale, 1440, canvasHeight)
            };
        }
        if(!cinematic()){
            [landscape,hero,...portraits].filter(Boolean).forEach(el=>el.style.removeProperty('transform'));
            hero?.style.removeProperty('opacity');if(hero)hero.inert=false;openingIntro?.style.removeProperty('opacity');
            portalInk?.removeAttribute('transform');nextScene?.style.removeProperty('opacity');
            [portalInk].filter(Boolean).forEach(el=>el.style.removeProperty('opacity'));
            commerceVisible=true;
        }
        lenis?.resize();lastTime=0;requestPaint();
    }
    stack?.addEventListener('keydown',event=>{
        if(event.key==='ArrowLeft'||event.key==='ArrowRight'){
            event.preventDefault();
            stepWine(event.key==='ArrowLeft'?-1:1,true);
        }
    });
    let touchOrigin=null, suppressTap=false;
    stack?.addEventListener('touchstart',event=>{
        const touch=event.touches[0];
        touchOrigin=event.touches.length===1?[touch.clientX,touch.clientY]:null;
        suppressTap=false;
    },{passive:true});
    stack?.addEventListener('touchend',event=>{
        if(!touchOrigin)return;
        const touch=event.changedTouches[0], dx=touch.clientX-touchOrigin[0], dy=touch.clientY-touchOrigin[1];
        touchOrigin=null;
        if(Math.abs(dx)>42&&Math.abs(dx)>Math.abs(dy)*1.5){
            suppressTap=true;
            stepWine(dx<0?1:-1);
        }
    },{passive:true});
    stack?.addEventListener('touchcancel',()=>{touchOrigin=null;});
    stack?.addEventListener('click',event=>{
        if(suppressTap){event.preventDefault();suppressTap=false;}
    });
    stack?.addEventListener('focusin',()=>{focused=true;dwell=0;requestPaint();});
    stack?.addEventListener('focusout',event=>{focused=stack.contains(event.relatedTarget);requestFrame();});
    stack?.addEventListener('pointerenter',event=>{if(event.pointerType==='mouse')hovered=true;});
    stack?.addEventListener('pointerleave',()=>{hovered=false;requestFrame();});
    // Observer gates every nonessential loop; no background wine cycle after the hero.
    if(hero)new IntersectionObserver(entries=>{heroVisible=entries[0].isIntersecting;lastTime=0;requestFrame();},{threshold:0}).observe(hero);
    document.querySelectorAll('a[href^="#"]').forEach(link=>link.addEventListener('click',event=>{
        const hash=link.getAttribute('href');if(!hash||hash.length<2)return;
        let id;try{id=decodeURIComponent(hash.slice(1));}catch{return;}
        const target=document.getElementById(id);if(!target)return;
        event.preventDefault();const top=id==='il-nostro-mondo'&&cinematic()?bounds.opening.start+bounds.opening.travel:target.getBoundingClientRect().top+scrollY-(document.querySelector('[data-header]')?.offsetHeight||80)-25;
        if(lenis)lenis.scrollTo(top,{duration:1.05,easing:t=>1-(1-t)**4});
        else window.scrollTo({top,behavior:reduced.matches?'instant':'smooth'});
        history.replaceState(null,'',hash);target.setAttribute('tabindex','-1');target.focus({preventScroll:true});
    }));
    addEventListener('scroll',requestPaint,{passive:true});addEventListener('resize',measure,{passive:true});addEventListener('pageshow',event=>{if(event.persisted){chooseWineStack();chooseWineSections();slides=[...document.querySelectorAll('[data-wine-slide]')];flip=null;dwell=0;stack?.style.removeProperty('transform');selected=-1;hovered=!!stack?.matches(':hover');focused=!!stack?.contains(document.activeElement);}measure();});
    reduced.addEventListener('change',measure);desktop.addEventListener('change',measure);
    document.addEventListener('adb:game-visibility',event=>{gameVisible=!!event.detail?.open;lastTime=0;if(gameVisible){if(raf)cancelAnimationFrame(raf);raf=0;}else requestPaint();});
    document.addEventListener('visibilitychange',()=>{lastTime=0;if(document.hidden){if(raf)cancelAnimationFrame(raf);raf=0;}else requestPaint();});
    addEventListener('pagehide',()=>{if(raf)cancelAnimationFrame(raf);raf=0;lastTime=0;});
    document.fonts?.ready.then(measure);addEventListener('load',measure,{once:true});measure();
})();
