(() => {
    const section = document.querySelector('#a-tavola');
    if (!section) return;
    const form = section.querySelector('form');
    const input = form.elements.piatto;
    const status = section.querySelector('[data-dish-status]');
    const results = section.querySelector('[data-dish-results]');
    const choices = [...section.querySelectorAll('[data-dish]')];
    let active;
    function mark(value) {
        choices.forEach(link => {
            if (link.dataset.dish.toLocaleLowerCase() === value.toLocaleLowerCase()) link.setAttribute('aria-current', 'true');
            else link.removeAttribute('aria-current');
        });
    }
    mark(input.value);
    async function search(value) {
        active?.abort();
        const controller = new AbortController();
        active = controller;
        mark(value);
        results.replaceChildren();
        status.textContent = status.dataset.loading;
        const url = new URL(form.dataset.endpoint, location.href);
        url.searchParams.set('piatto', value);
        try {
            const response = await fetch(url, { signal: controller.signal, credentials: 'same-origin' });
            if (!response.ok) throw Error();
            const payload = await response.json();
            if (!payload.success || typeof payload.data.html !== 'string') throw Error();
            if (controller !== active) return;
            results.innerHTML = payload.data.html;
            status.textContent = '';
            (results.querySelector('h3') || results).focus();
        } catch (error) {
            if (controller === active) status.textContent = status.dataset.error;
        }
    }
    form.addEventListener('submit', event => {
        event.preventDefault();
        if (input.value.trim()) search(input.value.trim());
    });
    choices.forEach(link => link.addEventListener('click', event => {
        if (event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
        event.preventDefault();
        input.value = link.dataset.dish;
        search(input.value);
    }));
})();
