(function () {
    'use strict';
    function read(name) {
        const entry = document.cookie.split('; ').find(item => item.startsWith(name + '='));
        return entry ? decodeURIComponent(entry.slice(name.length + 1)) : '';
    }
    function preferences() {
        const choice = read('tw_cookie_consent');
        if (choice === 'accepted') return { analytics: true, marketing: true };
        if (choice === 'custom') {
            try { return JSON.parse(read('tw_cookie_preferences')); } catch (_) { /* Invalid choices deny optional tracking. */ }
        }
        return { analytics: false, marketing: false };
    }
    function erase(name) {
        document.cookie = name + '=; Max-Age=0; path=/; SameSite=Lax';
        document.cookie = name + '=; Max-Age=0; path=/; domain=' + location.hostname + '; SameSite=Lax';
    }
    function sync(pref = preferences() || {}) {
        const stats = pref.analytics === true;
        const ads = pref.marketing === true;
        window.wp_consent_type = 'optin';
        if (typeof window.wp_set_consent === 'function') {
            window.wp_set_consent('statistics', stats ? 'allow' : 'deny');
            window.wp_set_consent('marketing', ads ? 'allow' : 'deny');
        }
        if (typeof window.gtag === 'function') {
            window.gtag('consent', 'update', {
                analytics_storage: stats ? 'granted' : 'denied',
                ad_storage: ads ? 'granted' : 'denied',
                ad_user_data: ads ? 'granted' : 'denied',
                ad_personalization: ads ? 'granted' : 'denied'
            });
        }
        const loaded = new Set();
        document.querySelectorAll('[data-adb-google-src]').forEach(tag => {
            const url = tag.dataset.adbGoogleSrc;
            const id = new URL(url, location.href).searchParams.get('id') || '';
            let allowed = stats && ads;
            if (/^AW-/.test(id)) allowed = ads;
            if (/^(G-|UA-)/.test(id)) allowed = stats;
            if (!allowed || loaded.has(url) || tag.dataset.activated) return;
            tag.dataset.activated = '1';
            loaded.add(url);
            const script = document.createElement('script');
            script.async = true;
            script.src = url;
            tag.after(script);
            document.querySelectorAll('[data-adb-google-src]').forEach(other => {
                if (other.dataset.adbGoogleSrc === url) other.dataset.activated = '1';
            });
        });
    }
    function setup() {
        ['analytics', 'marketing'].forEach(key => {
            const field = document.getElementById('tw-cookie-opt-' + key);
            if (field && !read('tw_cookie_consent')) field.checked = false;
        });
        sync();
        document.addEventListener('click', function (event) {
            const control = event.target.closest('[data-adb-cookie-settings], a[href$="#preferenze-cookie"], #tw-cookie-accept, #tw-cookie-decline, #tw-cookie-save-necessary, #tw-cookie-save-preferences');
            if (!control) return;
            if (control.matches('[data-adb-cookie-settings], a[href$="#preferenze-cookie"]')) {
                event.preventDefault();
                // Remove the old choice and identifiers before reopening the native banner.
                sync({ analytics: false, marketing: false });
                ['tw_cookie_consent','tw_cookie_preferences'].forEach(erase);
                document.cookie.split('; ').map(v => v.split('=')[0]).filter(k => /^(?:_ga(?:_|$)|_gid$|_gcl_|_gac_|sbjs_|wp_consent_(?:statistics|marketing))/.test(k)).forEach(erase);
                const dest = new URL(control.href || location.href, location.href);
                dest.hash = 'preferenze-cookie';
                if (dest.pathname !== location.pathname) location.assign(dest); else { history.replaceState(history.state, '', dest); location.reload(); }
                return;
            }
            // CMS click listeners persist the new choice before this delegated handler.
            sync();
        });
        if (location.hash === '#preferenze-cookie') {
            const open = document.getElementById('tw-cookie-customize');
            if (open) setTimeout(function () {
                open.click();
                document.getElementById('tw-cookie-opt-analytics')?.focus();
            }, 0);
        }
    }
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', setup);
    else setup();
})();
