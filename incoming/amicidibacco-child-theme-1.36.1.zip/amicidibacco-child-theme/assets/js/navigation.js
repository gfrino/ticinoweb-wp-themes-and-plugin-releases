(() => {
    'use strict';
    const menuButton = document.querySelector('[data-menu-toggle]');
    const menu = document.querySelector('#adb-main-nav');
    const header = document.querySelector('[data-header]');
    const mobile = window.matchMedia('(max-width: 1000px)');
    const inertState = new Map();
    const openLabel = menuButton?.getAttribute('aria-label') || '';
    const running = new WeakMap();
    const reducedMotion = matchMedia('(prefers-reduced-motion: reduce)');
    function revealPanel(panel, open) {
        const previous = running.get(panel);
        panel.inert = !open;
        if (previous) {
            if (!reducedMotion.matches) {
                previous.playbackRate = open ? 1 : -1;
                previous.play();
                return;
            }
            previous.cancel();
            running.delete(panel);
        }
        panel.hidden = false;
        if (reducedMotion.matches || !panel.animate) {
            panel.hidden = !open;
            return;
        }
        const frames = mobile.matches
            ? [{ height: '0px', opacity: 0 }, { height: panel.scrollHeight + 'px', opacity: 1 }]
            : [{ opacity: 0, transform: 'translateY(-9px)', clipPath: 'inset(0 0 12% 0)' },
               { opacity: 1, transform: 'translateY(0)', clipPath: 'inset(0 0 0% 0)' }];
        const animation = panel.animate(frames, { duration: 280, easing: 'cubic-bezier(.22,.7,.22,1)', fill: 'both' });
        if (!open) {
            animation.currentTime = 280;
            animation.reverse();
        }
        running.set(panel, animation);
        animation.onfinish = () => {
            if (running.get(panel) !== animation) return;
            panel.hidden = panel.inert;
            running.delete(panel);
            animation.cancel();
        };
    }
    const wineMenu = menu?.querySelector('template[data-wine-menu]');
    function decorateCategory(anchor) {
        // CMS links retain their names, order and destinations.
        const url = new URL(anchor.href);
        const category = url.searchParams.get('adb_category') || url.pathname.split('/').filter(Boolean).pop();
        const drawings = {
            'vini-rossi': '<path d="M10 5h12l1.5 8a7.6 7.6 0 0 1-15 0L10 5Zm6 15v7m-5 1h10"/><path class="adb-mega__wash" d="M9 12c4-2 8 2 14 0a7 7 0 0 1-14 2z"/>',
            'vini-rosati': '<path d="M6 9h20c-.3 6-4.6 10-10 10S6.3 15 6 9Zm10 10v8m-5 1h10"/><path class="adb-mega__wash" d="M7.7 12.7c5-2 10 1.8 16.6-.3-1.7 4-4.5 6-8.3 6-3.8 0-6.7-2-8.3-5.7Z"/>',
            'vini-bianchi': '<path d="M12 4h8l1.7 8.5c.8 4-1.6 7-5.7 7s-6.5-3-5.7-7L12 4Zm4 16v7m-4.5 1h9"/><path d="M11 12.5c2.4-1 4.1-1 6 .1 1.4.8 2.7.7 4 .2"/>',
            'bollicine': '<path d="M12 3.5h8l-.7 12c-.2 3-1.7 4.8-3.3 4.8s-3.1-1.8-3.3-4.8l-.7-12ZM16 21v6.5m-4.2.5h8.4"/><circle cx="15.3" cy="9" r=".55"/><circle cx="17.2" cy="13" r=".5"/>',
            'grappa': '<path d="M12.7 5h6.6c-1.8 4.6-.4 6.7 1.1 9 2.4 3.5.2 7.2-4.4 7.2s-6.8-3.7-4.4-7.2c1.5-2.3 2.9-4.4 1.1-9ZM16 21.5V27m-4 .8h8"/><path d="M13.3 17.1c0 1.1.7 1.7 1.6 1.9"/>'
        };
        const bottles = '<path d="M8 4h4v7c0 2 2.5 3.2 2.5 5.6V28h-9V16.6C5.5 14.2 8 13 8 11V4ZM19.5 7h4v6c0 1.8 2.5 3 2.5 5v10h-8V18c0-2 1.5-3.2 1.5-5V7Z"/><path d="M6 19h8m4.5 1.5h7M8 7h4"/>';
        const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
        svg.setAttribute('viewBox', '0 0 32 32');
        svg.setAttribute('aria-hidden', 'true');
        svg.classList.add('adb-mega__icon');
        svg.innerHTML = drawings[category] || bottles;
        anchor.prepend(svg);
    }
    function mountWineMenu(list) {
        const panel = wineMenu.content.firstElementChild.cloneNode(true);
        list.replaceWith(panel);
        list.classList.replace('sub-menu', 'adb-mega__categories');
        list.style.setProperty('--adb-category-rows', Math.ceil(list.children.length / 2));
        panel.querySelector('[data-menu-categories]').replaceWith(list);
        list.querySelectorAll('a').forEach(decorateCategory);
        return panel;
    }
    let discoveries;
    function loadWines(panel) {
        if (!panel.matches('.adb-mega') || discoveries) return;
        const picks = panel.querySelector('.adb-mega__picks');
        const shelf = picks.parentElement;
        discoveries = fetch(wineMenu.dataset.endpoint, { credentials: 'same-origin' })
            .then(response => {
                if (!response.ok) throw new Error();
                return response.json();
            })
            .then(payload => {
                if (!payload.success || typeof payload.data !== 'string') throw new Error();
                const markup = document.createElement('template');
                markup.innerHTML = payload.data;
                const cards = markup.content.querySelector('template[data-home-wine-pool]').content.children;
                const pool = Array.from(cards, node => ({
                    id: Number(node.dataset.wineId), group: node.dataset.wineGroup,
                    image: Number(node.dataset.wineImage), node
                }));
                const chosen = window.ADBWineSelection.chooseForVisit(pool, 'wine-menu', 2);
                picks.replaceChildren(...chosen.map(item => item.node.content.cloneNode(true)));
                shelf.hidden = !chosen.length;
            })
            .catch(() => { discoveries = null; shelf.hidden = true; })
            .finally(() => picks.removeAttribute('aria-busy'));
    }
    let expanded = null;
    const closeSubmenu = (focus = false) => {
        if (!expanded) return;
        const { button, panel } = expanded;
        expanded = null;
        revealPanel(panel, false);
        button.setAttribute('aria-expanded', 'false');
        if (focus) button.focus({ preventScroll: true });
    };
    menu?.querySelectorAll(':scope > ul > .menu-item-has-children').forEach((item, index) => {
        const link = item.querySelector(':scope > a');
        let panel = item.querySelector(':scope > .sub-menu');
        if (!link || !panel) return;
        if (wineMenu && [link, ...panel.querySelectorAll('a')].some(anchor => anchor.href === wineMenu.dataset.catalog)) {
            panel = mountWineMenu(panel);
        }
        const button = document.createElement('button');
        button.type = 'button';
        button.className = 'adb-nav__disclosure';
        button.textContent = link.textContent.trim();
        panel.id = 'adb-nav-categories-' + index;
        button.setAttribute('aria-controls', panel.id);
        button.setAttribute('aria-expanded', 'false');
        link.replaceWith(button);
        panel.hidden = true;
        const openSubmenu = () => {
            if (expanded?.button === button) return;
            closeSubmenu();
            expanded = { button, panel };
            loadWines(panel);
            button.setAttribute('aria-expanded', 'true');
            revealPanel(panel, true);
        };
        button.addEventListener('pointerenter', () => loadWines(panel));
        button.addEventListener('focus', () => loadWines(panel));
        button.addEventListener('click', () => {
            if (expanded?.button === button) closeSubmenu();
            else openSubmenu();
        });
        button.addEventListener('keydown', event => {
            if (event.key !== 'ArrowDown') return;
            event.preventDefault();
            openSubmenu();
            panel.querySelector('a')?.focus();
        });
        item.addEventListener('focusout', event => {
            if (expanded?.button === button && event.relatedTarget && !item.contains(event.relatedTarget)) closeSubmenu();
        });
    });
    document.addEventListener('pointerdown', event => {
        if (expanded && !expanded.button.parentElement.contains(event.target)) closeSubmenu();
    });
    document.addEventListener('keydown', event => {
        if (event.key === 'Escape' && expanded) {
            event.preventDefault();
            closeSubmenu(true);
        }
    });
    let isOpen = false;
    const closeMenu = (restoreFocus = false) => {
        closeSubmenu();
        const wasOpen = isOpen;
        isOpen = false;
        menu?.classList.remove('is-open');
        menuButton?.setAttribute('aria-expanded', 'false');
        menuButton?.setAttribute('aria-label', openLabel);
        document.documentElement.classList.remove('adb-menu-open');
        document.body.classList.remove('adb-menu-open');
        inertState.forEach((value, node) => { node.inert = value; });
        inertState.clear();
        if (menu) menu.inert = mobile.matches;
        if (wasOpen && !document.querySelector('dialog[open]')) window.adbSmoothScroll?.start();
        if (restoreFocus && wasOpen) menuButton?.focus({preventScroll: true});
    };
    const openMenu = () => {
        if (!mobile.matches || !menu || !menuButton) return;
        isOpen = true;
        menu.inert = false;
        menu.classList.add('is-open');
        menuButton.setAttribute('aria-expanded', 'true');
        menuButton.setAttribute('aria-label', menuButton.dataset.closeLabel || openLabel);
        document.documentElement.classList.add('adb-menu-open');
        document.body.classList.add('adb-menu-open');
        document.querySelectorAll('#main-content, .adb-footer, .adb-skip').forEach(node => { inertState.set(node, node.inert); node.inert = true; });
        window.adbSmoothScroll?.stop();
        menu.querySelector('a,button')?.focus({preventScroll: true});
    };
    menuButton?.addEventListener('click', () => { if (isOpen) closeMenu(true); else openMenu(); });
    header?.addEventListener('click', event => { if (event.target.closest('a')) closeMenu(); });
    document.addEventListener('keydown', event => {
        if (!isOpen || event.defaultPrevented) return;
        if (event.key === 'Escape') { event.preventDefault(); closeMenu(true); }
        if (event.key !== 'Tab') return;
        const controls = [...header.querySelectorAll('a[href],button:not([disabled])')].filter(node => node.getClientRects().length && !node.closest('[inert]'));
        if (event.shiftKey && document.activeElement === controls[0]) { event.preventDefault(); controls.at(-1)?.focus(); }
        else if (!event.shiftKey && document.activeElement === controls.at(-1)) { event.preventDefault(); controls[0]?.focus(); }
    });
    document.addEventListener('click', event => { if (isOpen && !event.target.closest('.adb-header')) closeMenu(); });
    mobile.addEventListener('change', () => closeMenu());
    // A visitor may already be browsing the menu while homepage photos finish loading.
    window.addEventListener('pageshow', event => { if (event.persisted) closeMenu(); });
    closeMenu();

    // The commercial opening and its calligraphic passage share one overlay header.
    // Keep the entire photographic passage transparent, including the letter aperture.
    const opening = document.querySelector('[data-opening]');
    const stage = document.querySelector('[data-opening-stage]');
    if (header?.classList.contains('adb-header--hero') && opening && stage) {
        let frame = 0, end = 0, maskStart = Infinity, maskEnd = Infinity;
        const update = () => {
            frame = 0;
            const y = window.scrollY;
            const overOpening = y < end;
            header.toggleAttribute('data-header-over-hero', overOpening);
            header.toggleAttribute('data-header-over-calligraphy', overOpening && y >= maskStart && y < maskEnd);
        };
        const measure = () => {
            const top = opening.getBoundingClientRect().top + window.scrollY;
            const stageTop = parseFloat(getComputedStyle(stage).top) || 0;
            const cinematic = document.body.classList.contains('adb-cinematic');
            const start = top - stageTop, travel = Math.max(1, opening.offsetHeight - stage.offsetHeight);
            end = top + opening.offsetHeight - Math.max(0, parseFloat(getComputedStyle(header).top) || 0);
            maskStart = cinematic ? start + travel * .26 : Infinity;
            maskEnd = cinematic ? start + travel * .84 : Infinity;
            update();
        };
        const schedule = () => { if (!frame) frame = requestAnimationFrame(update); };
        window.addEventListener('scroll', schedule, {passive:true});
        window.addEventListener('resize', measure, {passive:true});
        window.addEventListener('pageshow', measure);
        new MutationObserver(measure).observe(document.body, {attributes:true, attributeFilter:['class']});
        if ('ResizeObserver' in window) { const observer = new ResizeObserver(measure); observer.observe(opening); observer.observe(stage); }
        measure();
    }

    // WordPress's phone toolbar scrolls away; the tablet/desktop toolbar stays fixed.
    const toolbar = document.querySelector('#wpadminbar');
    if (toolbar && header) {
        let frame;
        const position = () => { frame = 0; header.style.setProperty('--adb-toolbar-offset', `${Math.max(0, toolbar.getBoundingClientRect().bottom)}px`); };
        const schedule = () => { if (!frame) frame = requestAnimationFrame(position); };
        window.addEventListener('scroll', schedule, {passive:true});
        window.addEventListener('resize', schedule, {passive:true});
        position();
    }
    const dialog = document.querySelector('[data-search-dialog]');
    const openSearch = document.querySelector('[data-search-open]');
    openSearch?.addEventListener('click', () => {
        closeMenu();
        if (dialog?.showModal) { dialog.showModal(); window.adbSmoothScroll?.stop(); dialog.querySelector('input[type="search"]')?.focus({ preventScroll: true }); }
    });
    dialog?.querySelector('[data-search-close]')?.addEventListener('click', () => dialog.close());
    dialog?.addEventListener('click', event => { if (event.target === dialog) dialog.close(); });
    dialog?.addEventListener('close', () => { if (document.querySelector('[data-vigna][open]')) return; window.adbSmoothScroll?.start(); openSearch?.focus(); });
})();
