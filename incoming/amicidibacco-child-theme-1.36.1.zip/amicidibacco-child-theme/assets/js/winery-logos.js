// Size the visible artwork, including logos supplied on a white or transparent canvas.
(() => {
    const logos = document.querySelectorAll('.adb-producers__logo img, .adb-wine-preview__mark img');
    if (!CSS.supports('width', '1cqw')) return;
    const canvas = document.createElement('canvas');
    const sample = 128;
    canvas.width = canvas.height = sample;
    const ctx = canvas.getContext('2d', { willReadFrequently: true });
    if (!ctx) return;

    function fitLogo(img) {
        if (!img.naturalWidth) return;
        let pixels;
        try {
            ctx.clearRect(0, 0, sample, sample);
            ctx.drawImage(img, 0, 0, sample, sample);
            pixels = ctx.getImageData(0, 0, sample, sample).data;
        } catch {
            // External images keep their proportional CSS fit.
            canvas.width = sample;
            return;
        }
        let lightArtwork = true;
        for (let i = 0; i < pixels.length; i += 4) {
            if (pixels[i + 3] > 16 && Math.min(pixels[i], pixels[i + 1], pixels[i + 2]) < 245) {
                lightArtwork = false;
                break;
            }
        }
        let left = sample, right = -1, top = sample, bottom = -1;
        for (let y = 0; y < sample; y++) {
            for (let x = 0; x < sample; x++) {
                const i = (y * sample + x) * 4;
                if (pixels[i + 3] <= 16) continue;
                if (!lightArtwork && Math.min(pixels[i], pixels[i + 1], pixels[i + 2]) >= 245) continue;
                left = Math.min(left, x);
                right = Math.max(right, x);
                top = Math.min(top, y);
                bottom = y;
            }
        }
        if (right < left) return;
        const width = (right - left + 1) / sample;
        const height = (bottom - top + 1) / sample;
        const aspect = img.naturalWidth / img.naturalHeight;
        const preferredWidth = Math.sqrt(4900 * aspect * width / height) / width;
        // Leave space for antialiased edges while limiting both wide and tall crests.
        const fit = (96 / width) + 'cqw, ' + (96 * aspect / height) + 'cqh';
        const size = img.closest('.adb-wine-preview__mark, .adb-mega__signature') ? fit : preferredWidth + 'px, ' + fit;
        img.style.setProperty('--logo-width', 'min(' + size + ')');
        img.style.setProperty('--logo-x', -(left + right + 1) * 50 / sample + '%');
        img.style.setProperty('--logo-y', -(top + bottom + 1) * 50 / sample + '%');
        img.toggleAttribute('data-light-artwork', lightArtwork);
        img.dataset.fitted = '';
    }

    // The discovery shelf inserts its two visible bottles after navigation opens.
    document.addEventListener('load', event => {
        if (event.target.matches?.('.adb-mega__logo')) fitLogo(event.target);
    }, true);
    document.addEventListener('error', event => {
        if (event.target.matches?.('.adb-mega__logo')) event.target.parentElement.hidden = true;
    }, true);

    for (const img of logos) {
        img.addEventListener('load', () => fitLogo(img));
        if (img.complete) fitLogo(img);
    }
})();
