<?php
defined( 'ABSPATH' ) || exit;
get_header();
?>
<main id="main-content" class="adb-page adb-wrap">
    <header class="adb-page__heading">
        <h1><?php esc_html_e( 'Pagina non trovata', 'amicidibacco' ); ?></h1>
        <p><?php esc_html_e( 'Puoi cercare un vino per nome o per cantina nel nostro catalogo.', 'amicidibacco' ); ?></p>
        <a class="adb-link" href="<?php echo esc_url( adb_catalog_url() ); ?>"><?php esc_html_e( 'Esplora il catalogo', 'amicidibacco' ); ?> <?php echo adb_icon(); ?></a>
    </header>
</main>
<?php get_footer(); ?>
