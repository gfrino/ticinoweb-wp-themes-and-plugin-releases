<?php
/** Purchase-based recommendations for the current shop. */
defined( 'ABSPATH' ) || exit;

/** The old multilingual catalogue also contains foreign copies sharing the Italian SKU. */
function adb_pair_is_wine( $id ) {
    global $wpdb;
    $id = absint( $id );
    if ( ! $id || ! function_exists( 'wc_get_product' ) || 'product' !== get_post_type( $id ) || 'publish' !== get_post_status( $id ) || post_password_required( $id ) ) {
        return false;
    }
    if ( 'VINO SINGOLO' !== get_post_meta( $id, 'tipo_di_prodotto', true ) || has_term( array( 'le-selezioni', 'le-selezioni-grappa', 'grappa', 'birra', 'birre', 'olio' ), 'product_cat', $id ) ) {
        return false;
    }
    $language = apply_filters( 'wpml_element_language_code', null, array( 'element_id' => $id, 'element_type' => 'post_product' ) );
    if ( $language && 'it' !== $language ) {
        return false;
    }
    $predicate = adb_language_predicate( 'p.ID', "'post_product'" );
    if ( $predicate && ! $wpdb->get_var( $wpdb->prepare( "SELECT p.ID FROM {$wpdb->posts} p WHERE p.ID = %d", $id ) . $predicate ) ) {
        return false;
    }
    $wine = wc_get_product( $id );
    if ( ! $wine || ! in_array( $wine->get_catalog_visibility(), array( 'visible', 'catalog' ), true ) || ! $wine->is_visible() || ! $wine->is_purchasable() || 'instock' !== $wine->get_stock_status() ) {
        return false;
    }
    if ( ! $wine->is_type( 'variable' ) ) {
        return $wine->is_type( 'simple' ) && $wine->has_enough_stock( 1 ) && ! $wine->is_on_backorder( 1 );
    }
    foreach ( $wine->get_visible_children() as $child_id ) {
        $format = wc_get_product( $child_id );
        if ( $format && $format->variation_is_visible() && $format->variation_is_active() && $format->is_purchasable() && 'instock' === $format->get_stock_status() && $format->has_enough_stock( 1 ) && ! $format->is_on_backorder( 1 ) ) {
            return true;
        }
    }
    return false;
}

/** Rank wines in the same catalogue type by distance from the current bottle's starting price. */
function adb_pair_type_candidates( $id ) {
    global $wpdb;
    $categories = get_the_terms( $id, 'product_cat' );
    if ( ! $categories || is_wp_error( $categories ) ) {
        return array();
    }
    $slugs = wp_list_pluck( $categories, 'slug' );
    $sparkling = array( 'spumanti', 'prosecco', 'franciacorta', 'metodo-classico', 'champagne' );
    $types = array_intersect( $slugs, array( 'vini-rossi', 'vini-bianchi', 'vini-rosati', 'vini-dolci' ) );
    if ( array_intersect( $slugs, $sparkling ) ) {
        $types = $sparkling;
    }
    if ( ! $types ) {
        return array();
    }
    $terms = get_terms( array( 'taxonomy' => 'product_cat', 'slug' => array_values( $types ), 'fields' => 'tt_ids', 'hide_empty' => false ) );
    if ( ! $terms || is_wp_error( $terms ) ) {
        return array();
    }
    $term_ids = implode( ',', wp_parse_id_list( $terms ) );
    $price = (float) wc_get_product( $id )->get_price();
    // The WC lookup already contains the parent minimum for variable bottles. Hydrate only ranked candidates until two qualify.
    $sql = "SELECT p.ID FROM {$wpdb->posts} p JOIN {$wpdb->wc_product_meta_lookup} l ON l.product_id=p.ID
            WHERE p.post_type='product' AND p.post_status='publish' AND p.post_password='' AND p.ID<>%d
            AND l.stock_status='instock' AND l.min_price IS NOT NULL
            AND p.ID IN (SELECT object_id FROM {$wpdb->term_relationships} WHERE term_taxonomy_id IN ($term_ids))
            ORDER BY ABS(l.min_price - %f), p.ID";
    return array_map( 'intval', $wpdb->get_col( $wpdb->prepare( $sql, $id, $price ) ) );
}

function adb_pair_recommendations( $product_id ) {
    $id = absint( $product_id );
    if ( ! adb_pair_is_wine( $id ) ) {
        return array();
    }
    $blocked = array_fill_keys( wp_parse_id_list( get_post_meta( $id, '_adb_pair_excludes', true ) ), true );
    $blocked[ $id ] = true;
    $result = array();
    $append = static function ( $candidates, $source, $counts = array() ) use ( &$result, &$blocked ) {
        foreach ( $candidates as $candidate ) {
            $candidate = absint( $candidate );
            if ( ! $candidate || isset( $blocked[ $candidate ] ) ) {
                continue;
            }
            $blocked[ $candidate ] = true;
            if ( adb_pair_is_wine( $candidate ) ) {
                $result[] = array( 'id' => $candidate, 'source' => $source, 'count' => (int) ( $counts[ $candidate ] ?? 0 ) );
                if ( 2 === count( $result ) ) {
                    return;
                }
            }
        }
    };
    $append( wp_parse_id_list( get_post_meta( $id, '_adb_pair_pins', true ) ), 'manual' );
    if ( count( $result ) < 2 ) {
        $native = get_option( 'adb_pair_order_counts', array() );
        $counts = $native[ $id ] ?? array();
        if ( home_url( '/' ) === get_option( 'adb_pair_legacy_scope' ) ) {
            $legacy = get_option( 'adb_pair_legacy_counts', array() );
            foreach ( $legacy[ $id ] ?? array() as $candidate => $count ) {
                $counts[ $candidate ] = ( $counts[ $candidate ] ?? 0 ) + (int) $count;
            }
        }
        $counts = array_filter( $counts, static function ( $count ) { return $count >= 3; } );
        $ranked = array_keys( $counts );
        usort( $ranked, static function ( $a, $b ) use ( $counts ) {
            return ( $counts[ $b ] <=> $counts[ $a ] ) ?: ( $a <=> $b );
        } );
        $append( $ranked, 'orders', $counts );
    }
    if ( count( $result ) < 2 ) {
        $append( adb_pair_type_candidates( $id ), 'type' );
    }
    return $result;
}

/** One vote per distinct pair per paid order, irrespective of quantities, formats or duplicate lines. */
function adb_pair_count_order( $order, &$counts ) {
    if ( ! $order instanceof WC_Order || ! $order->is_paid() ) {
        return;
    }
    $has_refunds = (bool) $order->get_refunds();
    $refunded = $has_refunds ? (float) $order->get_total_refunded() : 0.0;
    if ( $refunded > 0 && $refunded >= (float) $order->get_total() ) {
        return;
    }
    $ids = array();
    foreach ( $order->get_items( 'line_item' ) as $line_id => $item ) {
        $product_id = $item->get_product_id(); // WooCommerce stores the parent ID separately from the variation ID.
        $qty = (float) $item->get_quantity();
        if ( $has_refunds ) {
            $qty += $order->get_qty_refunded_for_item( $line_id ); // WooCommerce represents returned quantities as negative.
            $total = (float) $item->get_total();
            if ( $total > 0 && $order->get_total_refunded_for_item( $line_id ) >= $total ) {
                continue;
            }
        }
        if ( $product_id && $qty > 0 ) {
            $ids[ $product_id ] = true;
        }
    }
    $previous = array();
    foreach ( array_keys( $ids ) as $product_id ) {
        foreach ( $previous as $other ) {
            $votes = 1 + ( $counts[ $product_id ][ $other ] ?? 0 );
            $counts[ $product_id ][ $other ] = $votes;
            $counts[ $other ][ $product_id ] = $votes;
        }
        $previous[] = $product_id;
    }
}

/** Page by immutable ID so that simultaneous status changes cannot shift the next page. */
function adb_pair_paid_order_ids_after( $after, $limit ) {
    global $wpdb;
    $statuses = array_map( static function ( $status ) { return 'wc-' . $status; }, wc_get_is_paid_statuses() );
    if ( ! $statuses ) {
        return array();
    }
    $placeholders = implode( ',', array_fill( 0, count( $statuses ), '%s' ) );
    if ( class_exists( '\\Automattic\\WooCommerce\\Utilities\\OrderUtil' ) && \Automattic\WooCommerce\Utilities\OrderUtil::custom_orders_table_usage_is_enabled() ) {
        $table = \Automattic\WooCommerce\Internal\DataStores\Orders\OrdersTableDataStore::get_orders_table_name();
        $sql = "SELECT id FROM $table WHERE type='shop_order' AND status IN ($placeholders) AND id>%d ORDER BY id LIMIT %d";
    } else {
        $sql = "SELECT ID FROM {$wpdb->posts} WHERE post_type='shop_order' AND post_status IN ($placeholders) AND ID>%d ORDER BY ID LIMIT %d";
    }
    $ids = $wpdb->get_col( $wpdb->prepare( $sql, array_merge( $statuses, array( $after, $limit ) ) ) );
    return $wpdb->last_error ? null : array_map( 'intval', $ids );
}

/** A failed or interrupted batch never replaces the last complete result. */
function adb_pair_refresh() {
    global $wpdb;
    if ( ! function_exists( 'wc_get_order' ) ) {
        return;
    }
    $lock = 'adb_pair_' . md5( DB_NAME . '|' . $wpdb->prefix );
    if ( '1' !== (string) $wpdb->get_var( $wpdb->prepare( 'SELECT GET_LOCK(%s,0)', $lock ) ) ) {
        return;
    }
    try {
        $state = get_option( 'adb_pair_build_state', array( 'after' => 0, 'counts' => array() ) );
        $limit = 50;
        $ids = adb_pair_paid_order_ids_after( $state['after'], $limit );
        if ( null === $ids ) {
            adb_pair_schedule_refresh();
            return;
        }
        foreach ( $ids as $order_id ) {
            adb_pair_count_order( wc_get_order( $order_id ), $state['counts'] );
            $state['after'] = $order_id;
        }
        if ( count( $ids ) < $limit ) {
            update_option( 'adb_pair_order_counts', $state['counts'], false );
            delete_option( 'adb_pair_build_state' );
        } else {
            update_option( 'adb_pair_build_state', $state, false );
            if ( ! wp_next_scheduled( 'adb_pair_refresh_batch' ) ) {
                wp_schedule_single_event( time() + 5, 'adb_pair_refresh_batch' );
            }
        }
    } finally {
        $wpdb->get_var( $wpdb->prepare( 'SELECT RELEASE_LOCK(%s)', $lock ) );
    }
}

function adb_pair_schedule_refresh() {
    if ( ! wp_next_scheduled( 'adb_pair_refresh_requested' ) ) {
        wp_schedule_single_event( time() + 15 * MINUTE_IN_SECONDS, 'adb_pair_refresh_requested' );
    }
}

add_action( 'init', static function () {
    if ( function_exists( 'wc_get_order' ) && ! wp_next_scheduled( 'adb_pair_refresh_daily' ) ) {
        wp_schedule_event( time() + 5, 'daily', 'adb_pair_refresh_daily' );
    }
} );
add_action( 'adb_pair_refresh_batch', 'adb_pair_refresh' );
add_action( 'adb_pair_refresh_daily', 'adb_pair_refresh' );
add_action( 'adb_pair_refresh_requested', 'adb_pair_refresh' );
add_action( 'woocommerce_order_status_changed', 'adb_pair_schedule_refresh' );
add_action( 'woocommerce_order_refunded', 'adb_pair_schedule_refresh' );
add_action( 'woocommerce_saved_order_items', 'adb_pair_schedule_refresh' );
add_action( 'switch_theme', static function () {
    foreach ( array( 'adb_pair_refresh_batch', 'adb_pair_refresh_daily', 'adb_pair_refresh_requested' ) as $hook ) {
        wp_clear_scheduled_hook( $hook );
    }
    delete_option( 'adb_pair_build_state' );
} );

// A bottle may appear on several other product pages. Keep their full-page caches in step with inventory.
function adb_pair_invalidate_page_cache() {
    do_action( 'litespeed_purge', 'adb_pairings' );
}
add_action( 'template_redirect', static function () {
    if ( function_exists( 'is_product' ) && is_product() ) {
        do_action( 'litespeed_tag_add', 'adb_pairings' );
    }
} );
add_action( 'woocommerce_product_set_stock_status', 'adb_pair_invalidate_page_cache' );
add_action( 'woocommerce_variation_set_stock_status', 'adb_pair_invalidate_page_cache' );
add_action( 'woocommerce_update_product', 'adb_pair_invalidate_page_cache' );
add_action( 'woocommerce_update_product_variation', 'adb_pair_invalidate_page_cache' );
add_action( 'update_option_adb_pair_order_counts', 'adb_pair_invalidate_page_cache' );
add_action( 'add_option_adb_pair_order_counts', 'adb_pair_invalidate_page_cache' );
