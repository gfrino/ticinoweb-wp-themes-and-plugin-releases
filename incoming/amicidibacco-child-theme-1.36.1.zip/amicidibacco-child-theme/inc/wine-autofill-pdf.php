<?php
defined( 'ABSPATH' ) || exit;

/** Read a previously validated technical sheet without sending the PDF to another service. */
function adb_fill_pdf_text( $path ) {
    if ( ! is_string( $path ) || ! is_file( $path ) || ! is_readable( $path )
        || filesize( $path ) > 4 * MB_IN_BYTES || '%PDF-' !== file_get_contents( $path, false, null, 0, 5 ) ) {
        return '';
    }
    static $registered = false;
    if ( ! $registered ) {
        spl_autoload_register( static function ( $class ) {
            $prefix = 'Smalot\\PdfParser\\';
            if ( 0 !== strpos( $class, $prefix ) ) { return; }
            $relative = str_replace( '\\', '/', substr( $class, strlen( $prefix ) ) );
            $file = dirname( __DIR__ ) . '/lib/pdfparser/src/Smalot/PdfParser/' . $relative . '.php';
            if ( preg_match( '~^[A-Za-z0-9_/]+$~D', $relative ) && is_file( $file ) ) { require_once $file; }
        } );
        $registered = true;
    }
    try {
        $config = new \Smalot\PdfParser\Config();
        $config->setRetainImageContent( false );
        $config->setDecodeMemoryLimit( 12 * MB_IN_BYTES );
        $parser = new \Smalot\PdfParser\Parser( array(), $config );
        $document = $parser->parseFile( $path );
        $text = '';
        foreach ( array_slice( $document->getPages(), 0, 12 ) as $page ) {
            $page_text = $page->getText();
            // Some publishers draw headings first and values later, in separate PDF layers.
            if ( preg_match( '/(?:vitigni|vinificazione|degustazione|affinamento|temperatura di servizio)\s*\R\s*(?:vitigni|vinificazione|degustazione|affinamento|temperatura di servizio)\s*(?:\R|$)/iu', $page_text ) ) {
                $page_text = adb_fill_pdf_reading_order( $page );
            }
            $text .= $page_text . "\n";
            if ( mb_strlen( $text ) >= 80000 ) { break; }
        }
        return trim( mb_substr( $text, 0, 80000 ) );
    } catch ( \Throwable $error ) {
        return '';
    }
}


/** Restore lines from their printed baselines on a single-column technical sheet. */
function adb_fill_pdf_reading_order( $page ) {
    $rows = array();
    foreach ( $page->getDataTm() as $run ) {
        if ( ! isset( $run[0][4], $run[0][5], $run[1] ) || ! is_string( $run[1] ) ) { continue; }
        $y = (int) round( (float) $run[0][5] );
        $x = (float) $run[0][4];
        if ( ! isset( $rows[ $y ] ) ) { $rows[ $y ] = array( 'text' => '', 'x' => $x ); }
        // Preserve the publisher's fragment order on a baseline. Kerning often splits a word.
        // Separate new columns rather than folding their values into the end of the previous field.
        if ( $x + 15 < $rows[ $y ]['x'] && '' !== trim( $run[1] ) ) { return ''; }
        $rows[ $y ]['text'] .= $run[1];
        $rows[ $y ]['x'] = $x;
    }
    krsort( $rows, SORT_NUMERIC );
    return implode( "\n", array_column( $rows, 'text' ) );
}
