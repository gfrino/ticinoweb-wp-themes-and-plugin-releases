<?php
/** Use existing optimized media on storefront photographs and bottle images. */
defined( 'ABSPATH' ) || exit;

function adb_light_image_url( $url ) {
    static $memo = array();
    if ( isset( $memo[ $url ] ) ) { return $memo[ $url ]; }
    $uploads = wp_get_upload_dir();
    $prefix = trailingslashit( $uploads['baseurl'] );
    if ( ! str_starts_with( $url, $prefix ) || ! preg_match( '/\.(?:png|jpe?g)$/iD', $url ) ) { return $url; }
    $relative = rawurldecode( substr( $url, strlen( $prefix ) ) );
    if ( validate_file( $relative ) || str_contains( $relative, '\\' ) || str_contains( $relative, "\0" ) ) { return $url; }
    $file = trailingslashit( $uploads['basedir'] ) . $relative;
    $webp = $file . '.webp';
    $use_webp = is_file( $webp ) && is_file( $file ) && filemtime( $webp ) >= filemtime( $file )
        && filesize( $webp ) > 0 && filesize( $webp ) < filesize( $file );
    return $memo[ $url ] = $use_webp ? $url . '.webp' : $url;
}

function adb_light_image_attrs( $attrs ) {
    if ( empty( $attrs['src'] ) ) { return $attrs; }
    $attrs['src'] = adb_light_image_url( $attrs['src'] );
    if ( ! empty( $attrs['srcset'] ) ) {
        // Keep WordPress's candidate widths, ordering and crop selection.
        $attrs['srcset'] = preg_replace_callback( '~(https?://\S+)(?=\s+\d+w(?:,|$))~', static function ( $m ) {
            return adb_light_image_url( $m[1] );
        }, $attrs['srcset'] );
    }
    return $attrs;
}

add_filter( 'wp_get_attachment_image_attributes', static function ( $attrs ) {
    if ( ! isset( $attrs['data-adb-webp'] ) && ! isset( $attrs['data-adb-cover'] ) ) { return $attrs; }
    unset( $attrs['data-adb-webp'] );
    return adb_light_image_attrs( $attrs );
}, 50 );

add_filter( 'woocommerce_gallery_image_html_attachment_image_params', static function ( $attrs, $id, $size, $main ) {
    $attrs['data-adb-webp'] = true;
    if ( $main && is_product() ) {
        $attrs['fetchpriority'] = 'high';
        $attrs['loading'] = 'eager';
    }
    return $attrs;
}, 10, 4 );

// WooCommerce can select a default vintage as soon as the page opens.
add_filter( 'woocommerce_available_variation', static function ( $variation ) {
    if ( ! empty( $variation['image'] ) ) {
        $variation['image'] = adb_light_image_attrs( $variation['image'] );
    }
    return $variation;
} );
