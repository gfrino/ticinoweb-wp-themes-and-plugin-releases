<?php
/** Wine-specific editorial data. Original catalog fields remain the technical source. */
defined( 'ABSPATH' ) || exit;

function adb_tasting_axes() {
    return array(
        'body' => array( 'label' => __( 'Corpo', 'amicidibacco' ), 'low' => __( 'Leggero', 'amicidibacco' ), 'high' => __( 'Strutturato', 'amicidibacco' ) ),
        'freshness' => array( 'label' => __( 'Freschezza', 'amicidibacco' ), 'low' => __( 'Delicata', 'amicidibacco' ), 'high' => __( 'Vivace', 'amicidibacco' ) ),
        'sweetness' => array( 'label' => __( 'Dolcezza', 'amicidibacco' ), 'low' => __( 'Secco', 'amicidibacco' ), 'high' => __( 'Dolce', 'amicidibacco' ) ),
        'tannin' => array( 'label' => __( 'Tannino', 'amicidibacco' ), 'low' => __( 'Discreto', 'amicidibacco' ), 'high' => __( 'Deciso', 'amicidibacco' ) ),
        'persistence' => array( 'label' => __( 'Persistenza', 'amicidibacco' ), 'low' => __( 'Breve', 'amicidibacco' ), 'high' => __( 'Lunga', 'amicidibacco' ) ),
    );
}

/** Scores are explicit saved values: editorial estimates and documented official data. */
function adb_sanitize_tasting( $raw ) {
    $raw = is_array( $raw ) ? $raw : array();
    $raw['scores'] = is_array( $raw['scores'] ?? null ) ? $raw['scores'] : array();
    $raw['score_evidence'] = is_array( $raw['score_evidence'] ?? null ) ? $raw['score_evidence'] : array();
    $text = static function ( $value, $length = 1200 ) { return is_scalar( $value ) ? mb_substr( sanitize_textarea_field( (string) $value ), 0, $length ) : ''; };
    $method = in_array( $raw['score_method'] ?? '', array( 'editorial', 'official' ), true ) ? $raw['score_method'] : '';
    $out = array( 'aromas' => array(), 'finish' => $text( $raw['finish'] ?? '' ), 'scores' => array(), 'score_method' => $method, 'score_basis' => $text( $raw['score_basis'] ?? '', 3000 ), 'score_evidence' => array(), 'sources' => array(), 'verification' => 'needs_source', 'reference_vintage' => $text( $raw['reference_vintage'] ?? '', 100 ) );
    $aromas = is_array( $raw['aromas'] ?? null ) ? $raw['aromas'] : preg_split( '/[\r\n,;]+/u', $text( $raw['aromas'] ?? '' ) );
    foreach ( array_slice( $aromas, 0, 20 ) as $aroma ) {
        $aroma = trim( $text( $aroma, 60 ) );
        if ( '' !== $aroma && ! in_array( mb_strtolower( $aroma ), array_map( 'mb_strtolower', $out['aromas'] ), true ) ) { $out['aromas'][] = $aroma; }
        if ( count( $out['aromas'] ) >= 8 ) { break; }
    }
    foreach ( array_slice( is_array( $raw['sources'] ?? null ) ? $raw['sources'] : array(), 0, 12 ) as $source ) {
        if ( ! is_array( $source ) || ! is_string( $source['url'] ?? null ) || strlen( $source['url'] ) > 2048 ) { continue; }
        $url = esc_url_raw( $source['url'], array( 'https', 'http' ) );
        // These are escaped links, never fetched by the theme. Avoid DNS/network on page views.
        if ( ! $url || ! wp_parse_url( $url, PHP_URL_HOST ) || wp_parse_url( $url, PHP_URL_USER ) || wp_parse_url( $url, PHP_URL_PASS ) || ! filter_var( $url, FILTER_VALIDATE_URL ) ) { continue; }
        $title = trim( $text( $source['title'] ?? '', 200 ) ) ?: (string) wp_parse_url( $url, PHP_URL_HOST );
        $out['sources'][] = array( 'url' => $url, 'title' => $title, 'scope' => 'product' === ( $source['scope'] ?? '' ) ? 'product' : 'producer', 'vintage' => $text( $source['vintage'] ?? '', 100 ), 'fields' => array_values( array_filter( array_map( 'sanitize_key', array_slice( array_filter( (array) ( $source['fields'] ?? array() ), 'is_scalar' ), 0, 30 ) ) ) ) );
    }
    if ( in_array( $raw['verification'] ?? '', array( 'official_product', 'legacy_reviewed', 'needs_source' ), true ) ) { $out['verification'] = $raw['verification']; }
    if ( 'official_product' === $out['verification'] && ! array_filter( $out['sources'], static function ( $source ) { return 'product' === $source['scope']; } ) ) { $out['verification'] = 'legacy_reviewed'; }
    foreach ( adb_tasting_axes() as $key => $axis ) {
        $score = $raw['scores'][ $key ] ?? null;
        $evidence = $text( $raw['score_evidence'][ $key ] ?? '', 500 );
        $valid = ( is_int( $score ) || ( is_string( $score ) && preg_match( '/^[1-5]$/D', $score ) ) ) && (int) $score >= 1 && (int) $score <= 5;
        $relevant_sources = array_filter( $out['sources'], static function ( $source ) use ( $key ) {
            return 'product' === $source['scope'] && ( in_array( 'al_palato', $source['fields'], true ) || in_array( $key, $source['fields'], true ) );
        } );
        $editorial = 'editorial' === $method && ( '' !== $evidence || '' !== $out['score_basis'] );
        $official = 'editorial' !== $method && 'official_product' === $out['verification'] && $relevant_sources && '' !== $evidence;
        $out['scores'][ $key ] = $valid && ( $editorial || $official ) ? (int) $score : null;
        $out['score_evidence'][ $key ] = null !== $out['scores'][ $key ] ? $evidence : '';
    }
    return $out;
}

function adb_tasting_data( $product_id ) {
    $product_id = absint( $product_id );
    // Format variations inherit the product. No language or vintage cross-copying.
    if ( 'product_variation' === get_post_type( $product_id ) ) { $product_id = wp_get_post_parent_id( $product_id ); }
    $raw = $product_id ? get_post_meta( $product_id, '_adb_tasting', true ) : array();
    $data = adb_sanitize_tasting( $raw );
    $kind = get_post_meta( $product_id, 'tipo_di_prodotto', true );
    if ( 'VINO SINGOLO' !== $kind ) {
        $data['scores'] = array_fill_keys( array_keys( adb_tasting_axes() ), null );
    }
    if ( in_array( $kind, array( 'LE SELEZIONI VINO', 'LE SELEZIONI GRAPPA' ), true ) ) {
        $data['aromas'] = array();
        $data['finish'] = '';
    }
    return $data;
}

/** Preserve disputed original values in the CMS, but never publish them as verified facts. */
function adb_product_field_value( $product_id, $key ) {
    $review = get_post_meta( $product_id, '_adb_unverified_fields', true );
    if ( is_array( $review ) && in_array( $key, $review, true ) ) { return ''; }
    $value = get_post_meta( $product_id, $key, true );
    return is_scalar( $value ) ? trim( (string) $value ) : '';
}

/** Merge the small public editor without rewriting historical or private provenance. */
function adb_merge_tasting_editor_input( $stored, $input, $is_wine ) {
    $stored = is_array( $stored ) ? $stored : array();
    $input = is_array( $input ) ? $input : array();
    $next = $stored;
    $normal = adb_sanitize_tasting( $stored );
    foreach ( array( 'aromas', 'finish' ) as $key ) {
        if ( ! array_key_exists( $key, $input ) || ( ! is_scalar( $input[ $key ] ) && ! ( 'aromas' === $key && is_array( $input[ $key ] ) ) ) ) { continue; }
        $clean = adb_sanitize_tasting( array( $key => $input[ $key ] ) );
        $next[ $key ] = $clean[ $key ];
    }
    if ( ! $is_wine || ! is_array( $input['scores'] ?? null ) ) { return $next; }
    foreach ( adb_tasting_axes() as $key => $axis ) {
        if ( ! array_key_exists( $key, $input['scores'] ) ) { continue; }
        $raw = $input['scores'][ $key ];
        if ( '' === $raw ) { $score = null; }
        elseif ( ( is_int( $raw ) || ( is_string( $raw ) && preg_match( '/^[1-5]$/D', $raw ) ) ) && (int) $raw >= 1 && (int) $raw <= 5 ) { $score = (int) $raw; }
        else { continue; }
        if ( $score === $normal['scores'][ $key ] ) { continue; }
        if ( ! is_array( $next['scores'] ?? null ) ) { $next['scores'] = array(); }
        $next['scores'][ $key ] = $score;
        $next['score_method'] = 'editorial';
        if ( ! is_string( $next['score_basis'] ?? null ) || '' === trim( $next['score_basis'] ) ) { $next['score_basis'] = __( 'Valutazione editoriale', 'amicidibacco' ); }
        if ( null !== $score ) {
            if ( ! is_array( $next['score_evidence'] ?? null ) ) { $next['score_evidence'] = array(); }
            $next['score_evidence'][ $key ] = __( 'Valutazione editoriale', 'amicidibacco' );
        }
    }
    return $next;
}

/** The tasting controls live before the collapsed technical details. */
function adb_tasting_editor( $post, $groups ) {
    $data = adb_tasting_data( $post->ID );
    $kind = get_post_meta( $post->ID, 'tipo_di_prodotto', true );
    $fields = adb_product_fields();
    if ( ! in_array( $kind, array( 'VINO SINGOLO', 'GRAPPA SINGOLA', 'BIRRE', 'LE SELEZIONI VINO', 'LE SELEZIONI GRAPPA' ), true ) ) { return; }
    if ( $groups['composition'] ) {
        echo '<details class="adb-editor-group"><summary>' . esc_html__( 'Composizione', 'amicidibacco' ) . '</summary><div class="adb-editor-fields">';
        foreach ( $groups['composition'] as $key ) { adb_product_editor_field( $post, $key, $fields[ $key ], 3 ); }
        echo '</div></details>';
        return;
    }
    echo '<details class="adb-editor-group"><summary>' . esc_html__( 'Degustazione', 'amicidibacco' ) . '</summary>';
    echo '<input type="hidden" name="adb_tasting_present" value="1">';
    echo '<div class="adb-editor-fields">';
    foreach ( $groups['notes'] as $key ) { adb_product_editor_field( $post, $key, $fields[ $key ], 3 ); }
    echo '<p class="adb-editor-field"><label for="adb-aromas">' . esc_html__( 'Aromi principali', 'amicidibacco' ) . '</label><textarea class="widefat" id="adb-aromas" name="adb_tasting[aromas]" rows="2">' . esc_textarea( implode( "\n", $data['aromas'] ) ) . '</textarea><span class="description">' . esc_html__( 'Un aroma per riga, fino a otto.', 'amicidibacco' ) . '</span></p>';
    echo '<p class="adb-editor-field"><label for="adb-finish">' . esc_html__( 'Il finale', 'amicidibacco' ) . '</label><textarea class="widefat" id="adb-finish" name="adb_tasting[finish]" rows="2">' . esc_textarea( $data['finish'] ) . '</textarea></p></div></details>';
    if ( 'VINO SINGOLO' === $kind ) {
        echo '<details class="adb-editor-group"><summary>' . esc_html__( 'Profilo del vino · da 1 a 5', 'amicidibacco' ) . '</summary><p class="description">' . esc_html__( 'Valori orientativi dello stile, non voti di qualità. Puoi modificarli direttamente o lasciare una voce vuota.', 'amicidibacco' ) . '</p><div class="adb-editor-scores">';
        foreach ( adb_tasting_axes() as $key => $axis ) {
            echo '<p class="adb-editor-field"><label for="adb-score-' . esc_attr( $key ) . '">' . esc_html( $axis['label'] ) . '</label><select id="adb-score-' . esc_attr( $key ) . '" name="adb_tasting[scores][' . esc_attr( $key ) . ']"><option value="">' . esc_html__( 'Non indicato', 'amicidibacco' ) . '</option>';
            for ( $i = 1; $i <= 5; $i++ ) { echo '<option value="' . esc_attr( $i ) . '"' . selected( $data['scores'][ $key ], $i, false ) . '>' . esc_html( $i . '/5' ) . '</option>'; }
            echo '</select><span class="description">' . esc_html( $axis['low'] . ' → ' . $axis['high'] ) . '</span></p>';
        }
        echo '</div></details>';
    }
}

/** Historical material is optional, collapsed and cannot be submitted by the form. */
function adb_tasting_archive( $post ) {
    $original = get_post_meta( $post->ID, '_adb_original_editorial', true );
    $data = adb_tasting_data( $post->ID );
    if ( ! is_array( $original ) && ! $data['sources'] ) { return; }
    echo '<details class="adb-editor-archive"><summary>' . esc_html__( 'Archivio e riferimenti', 'amicidibacco' ) . '</summary>';
    if ( is_array( $original ) ) {
        echo '<p class="description">' . esc_html__( 'Contenuti originali conservati in sola lettura.', 'amicidibacco' ) . '</p>';
        foreach ( array( 'content' => __( 'Descrizione originale', 'amicidibacco' ), 'excerpt' => __( 'Introduzione originale', 'amicidibacco' ) ) as $key => $label ) {
            if ( ! is_string( $original[ $key ] ?? null ) || '' === $original[ $key ] ) { continue; }
            echo '<p><label for="adb-original-' . esc_attr( $key ) . '">' . esc_html( $label ) . '</label><textarea readonly class="widefat" rows="5" id="adb-original-' . esc_attr( $key ) . '">' . esc_textarea( $original[ $key ] ) . '</textarea></p>';
        }
        $labels = adb_product_fields();
        foreach ( (array) ( $original['technical'] ?? array() ) as $key => $value ) {
            if ( ! is_scalar( $value ) ) { continue; }
            echo '<p><strong>' . esc_html( $labels[ $key ] ?? $key ) . '</strong><br>' . esc_html( $value ) . '</p>';
        }
    }
    if ( $data['sources'] ) {
        echo '<h4>' . esc_html__( 'Riferimenti', 'amicidibacco' ) . '</h4><ul>';
        foreach ( $data['sources'] as $source ) { echo '<li><a href="' . esc_url( $source['url'] ) . '">' . esc_html( $source['title'] ) . '</a></li>'; }
        echo '</ul>';
    }
    echo '</details>';
}

function adb_save_tasting( $post_id, $post ) {
    if ( ! $post || 'product' !== $post->post_type || wp_is_post_revision( $post_id ) || wp_is_post_autosave( $post_id ) || ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) || ! current_user_can( 'edit_post', $post_id ) ) { return; }
    if ( empty( $_POST['adb_tasting_present'] ) || ! is_string( $_POST['adb_product_nonce'] ?? null ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['adb_product_nonce'] ) ), 'adb_save_product' ) || ! is_array( $_POST['adb_tasting'] ?? null ) ) { return; }
    $input = wp_unslash( $_POST['adb_tasting'] );
    $stored = get_post_meta( $post_id, '_adb_tasting', true );
    $next = adb_merge_tasting_editor_input( $stored, $input, 'VINO SINGOLO' === get_post_meta( $post_id, 'tipo_di_prodotto', true ) );
    update_post_meta( $post_id, '_adb_tasting', wp_slash( $next ) );
}
add_action( 'adb_product_editor_after_fields', 'adb_tasting_editor', 10, 2 );
add_action( 'adb_product_editor_archive', 'adb_tasting_archive' );
// The existing editorial dispatcher saves the product type on save_post at 20.
add_action( 'save_post', 'adb_save_tasting', 30, 2 );
