<?php
/** Connect the CMS consent banner to the store's front-end Google tags. */
defined( 'ABSPATH' ) || exit;

add_filter( 'wp_get_consent_type', static function () { return 'optin'; } );

add_shortcode( 'adb_cookie_preferences', static function () {
    return '<button type="button" class="adb-link" data-adb-cookie-settings>' . esc_html__( 'Modifica le preferenze cookie', 'amicidibacco' ) . '</button>';
} );

// The integrations print both enqueued and direct script tags in wp_head.
// Leave the initial HTML identical for every visitor, including cached pages.
add_action( 'wp_head', static function () { ob_start(); }, PHP_INT_MIN );
add_action( 'wp_head', static function () {
    $html = ob_get_clean();
    $tags = new WP_HTML_Tag_Processor( $html );
    while ( $tags->next_tag() ) {
        if ( 'SCRIPT' === $tags->get_tag() ) {
            $src = $tags->get_attribute( 'src' );
            if ( ! is_string( $src ) || ! in_array( wp_parse_url( $src, PHP_URL_HOST ), [ 'www.googletagmanager.com', 'www.google-analytics.com', 'pagead2.googlesyndication.com' ], true ) ) { continue; }
            $tags->set_attribute( 'type', 'text/plain' );
            $tags->set_attribute( 'data-adb-google-src', $src );
            $tags->remove_attribute( 'src' );
        } elseif ( 'LINK' === $tags->get_tag() && in_array( $tags->get_attribute( 'rel' ), [ 'preconnect', 'dns-prefetch', 'preload' ], true ) ) {
            $host = wp_parse_url( (string) $tags->get_attribute( 'href' ), PHP_URL_HOST );
            if ( in_array( $host, [ 'www.googletagmanager.com', 'www.google-analytics.com', 'pagead2.googlesyndication.com' ], true ) ) { $tags->remove_attribute( 'href' ); }
        }
    }
    echo $tags->get_updated_html(); // The original head markup from WordPress and its integrations.
}, PHP_INT_MAX );

add_action( 'wp_enqueue_scripts', static function () {
    wp_enqueue_script( 'adb-cookie-preferences', get_stylesheet_directory_uri() . '/assets/js/cookie-preferences.js', [], ADB_VERSION, true );
} );
