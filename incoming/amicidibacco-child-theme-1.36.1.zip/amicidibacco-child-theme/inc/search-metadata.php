<?php
/** Present the same public catalog facts in search, social previews and WooCommerce markup. */
defined( 'ABSPATH' ) || exit;

function adb_catalog_search_title() {
    if ( ! function_exists( 'is_product' ) || is_search() ) { return ''; }
    if ( is_product_taxonomy() ) {
        $term = get_queried_object();
        if ( get_term_meta( $term->term_id, '_tw_seo_title', true ) ) { return ''; }
        $titles = [
            'pa_anno'       => __( 'Vini dell’annata %s', 'amicidibacco' ),
            'pa_dimensione' => __( 'Bottiglie e confezioni da %s', 'amicidibacco' ),
            'pa_cantina'    => __( 'Le etichette di %s in catalogo', 'amicidibacco' ),
            'pa_regione'    => __( 'Etichette per territorio · %s', 'amicidibacco' ),
            'pa_nazione'    => __( 'Catalogo per paese · %s', 'amicidibacco' ),
            'pa_vitigno'    => __( 'Vini per vitigno · %s', 'amicidibacco' ),
        ];
        return isset( $titles[ $term->taxonomy ] ) ? sprintf( $titles[ $term->taxonomy ], $term->name ) : '';
    }
    if ( is_shop() ) {
        return (string) get_post_meta( wc_get_page_id( 'shop' ), '_tw_seo_title', true );
    }
    if ( ! is_product() ) { return ''; }
    $id = get_queried_object_id();
    if ( get_post_meta( $id, '_tw_seo_title', true ) ) { return ''; }
    $product = wc_get_product( $id );
    if ( ! $product ) { return ''; }
    $title = wp_strip_all_tags( $product->get_name() );
    $label = wp_strip_all_tags( adb_product_editorial_field( $id, 'etichetta' ) );
    $winery = wp_strip_all_tags( $product->get_attribute( 'pa_cantina' ) );
    // A selection sometimes repeats the producer as its subtitle.
    $label_key = preg_replace( '/\b(?:di|d)\b/u', '', str_replace( '-', ' ', sanitize_title( $label ) ) );
    $winery_key = preg_replace( '/\b(?:di|d)\b/u', '', str_replace( '-', ' ', sanitize_title( $winery ) ) );
    $label_key = str_replace( ' ', '', $label_key );
    if ( $label_key && false !== strpos( str_replace( ' ', '', $winery_key ), $label_key ) ) { $label = ''; }
    foreach ( [ $label, $winery ] as $detail ) {
        $detail = trim( $detail );
        if ( $detail && mb_strlen( $detail ) <= 85 && false === mb_stripos( $title, $detail ) ) {
            $title .= ' · ' . $detail;
        }
    }
    return $title;
}

add_filter( 'ticinoweb_seo_document_title_parts', static function ( $parts ) {
    $title = adb_catalog_search_title();
    if ( $title ) {
        $parts['title'] = $title;
        if ( is_shop() ) { unset( $parts['site'] ); }
    }
    if ( adb_is_offers_page() && adb_offers_requested_page() > 1 ) {
        $parts['page'] = sprintf( __( 'Pagina %d', 'amicidibacco' ), adb_offers_requested_page() );
    }
    return $parts;
} );

add_filter( 'ticinoweb_seo_og_title', static function ( $title ) {
    if ( function_exists( 'is_shop' ) && is_shop() && ! is_search() ) { return wp_get_document_title(); }
    return adb_catalog_search_title() ?: $title;
} );

/** Prefer the opening sentence; otherwise finish at a word boundary. */
function adb_search_summary( $text ) {
    $text = trim( preg_replace( '/\s+/u', ' ', html_entity_decode( wp_strip_all_tags( strip_shortcodes( $text ), true ), ENT_QUOTES | ENT_HTML5, 'UTF-8' ) ) );
    if ( mb_strlen( $text ) <= 160 ) { return $text; }
    $excerpt = mb_substr( $text, 0, 158 );
    if ( preg_match( '/^(.{55,}[.!?])\s/u', $excerpt, $match ) ) { return $match[1]; }
    return rtrim( preg_replace( '/\s+\S*$/u', '', $excerpt ), ' ,;:–-' ) . '…';
}

add_filter( 'ticinoweb_seo_meta_description', static function ( $description ) {
    if ( is_404() || is_search() || ( is_singular() && post_password_required( get_queried_object() ) ) ) { return ''; }
    if ( function_exists( 'is_shop' ) && is_shop() ) {
        $id = wc_get_page_id( 'shop' );
        $text = get_post_meta( $id, '_tw_seo_description', true ) ?: get_post_field( 'post_excerpt', $id );
    } elseif ( is_singular( [ 'product', 'produttore' ] ) ) {
        $post = get_queried_object();
        if ( get_post_meta( $post->ID, '_tw_seo_description', true ) || post_password_required( $post ) ) { return $description; }
        $text = $post->post_excerpt ?: $post->post_content;
        if ( ! $text && 'product' === $post->post_type ) { $text = adb_product_editorial_field( $post->ID, 'descrizione_etichetta' ); }
    } elseif ( function_exists( 'is_product_taxonomy' ) && is_product_taxonomy() ) {
        $term = get_queried_object();
        $text = get_term_meta( $term->term_id, '_tw_seo_description', true ) ?: $term->description;
        if ( ! $text ) {
            $summaries = [
                'pa_anno'       => __( 'Scopri i vini dell’annata %s in enoteca. Per ogni etichetta trovi la cantina, i formati disponibili e il prezzo in franchi svizzeri.', 'amicidibacco' ),
                'pa_dimensione' => __( 'Cerchi il formato %s? Sfoglia le etichette disponibili in questa misura e consulta prezzi e dettagli nelle schede dell’enoteca.', 'amicidibacco' ),
                'pa_cantina'    => __( 'Esplora le etichette di %s presenti nell’enoteca Amici di Bacco. Consulta le singole schede per conoscere formati, prezzi e disponibilità.', 'amicidibacco' ),
                'pa_regione'    => __( 'Territorio %s. Scopri i produttori rappresentati in enoteca e consulta le schede delle loro etichette con formati e prezzi in CHF.', 'amicidibacco' ),
                'pa_nazione'    => __( 'Esplora il catalogo per paese di origine. Nella selezione %s trovi le etichette dell’enoteca con produttori, formati e prezzi in CHF.', 'amicidibacco' ),
                'pa_vitigno'    => __( 'Scopri i vini da uve %s presenti in catalogo. Confronta le etichette e apri le schede per conoscere produttori, formati e prezzi.', 'amicidibacco' ),
            ];
            $format = $summaries[ $term->taxonomy ] ?? __( 'Scopri le etichette in catalogo per %s. Consulta le schede per conoscere i prodotti, i formati e le disponibilità.', 'amicidibacco' );
            $text = sprintf( $format, $term->name );
        }
    } else {
        return $description;
    }
    return adb_search_summary( (string) $text ) ?: $description;
} );

add_filter( 'woocommerce_structured_data_product', static function ( $data, $product ) {
    if ( empty( $data['brand'] ) && 'VINO SINGOLO' === $product->get_meta( 'tipo_di_prodotto' ) ) {
        $names = wc_get_product_terms( $product->get_id(), 'pa_cantina', [ 'fields' => 'names' ] );
        if ( is_array( $names ) && 1 === count( $names ) ) {
            $data['brand'] = [ '@type' => 'Brand', 'name' => reset( $names ) ];
            if ( is_product() && get_queried_object_id() === $product->get_id() ) {
                $details = adb_product_editorial_data( $product );
                $producer = $details['producer'];
                if ( $producer && ! post_password_required( $producer ) ) {
                    $data['brand']['url'] = get_permalink( $producer );
                    $data['manufacturer'] ??= [ '@id' => get_permalink( $producer ) . '#cantina' ];
                }
            }
        }
    }
    return $data;
}, 30, 2 );

add_filter( 'wp_robots', static function ( $robots ) {
    $filtered = function_exists( 'is_shop' ) && ( is_shop() || is_product_taxonomy() ) &&
        ( adb_shop_selection() || isset( $_GET['orderby'] ) );
    if ( $filtered || is_search() || is_404() || ( is_singular() && get_queried_object()->post_password !== '' ) ) {
        unset( $robots['index'] );
        $robots['noindex'] = true;
    }
    return $robots;
} );

// An empty offers page has no independent content. The last available page can change.
add_action( 'template_redirect', static function () {
    if ( ! adb_is_offers_page() || adb_offers_requested_page() < 2 ) { return; }
    $first = adb_offers_page( 1 );
    $last = max( 1, $first['pages'] );
    if ( adb_offers_requested_page() <= $last ) { return; }
    $url = get_permalink( get_queried_object_id() );
    if ( $last > 1 ) { $url = add_query_arg( 'product-page', $last, $url ); }
    if ( wp_safe_redirect( $url, 302, 'Amici di Bacco' ) ) { exit; }
}, 8 );

// Use the public contact record. Split the address into postal fields only when
// WooCommerce's structured address matches what visitors see on the contact page.
add_filter( 'ticinoweb_seo_jsonld_org_schema', static function ( $schema ) {
    if ( 'Store' !== ( $schema['@type'] ?? '' ) || ! function_exists( 'ticinoweb_get_contact_info' ) ) { return $schema; }
    $contact = ticinoweb_get_contact_info();
    $address = trim( wp_strip_all_tags( (string) ( $contact['address'] ?? '' ) ) );
    if ( $address && empty( $schema['address'] ) ) {
        $schema['address'] = $address;
        if ( function_exists( 'WC' ) && WC()->countries ) {
            $countries = WC()->countries;
            $street = trim( $countries->get_base_address() );
            $city = trim( $countries->get_base_city() );
            $zip = trim( $countries->get_base_postcode() );
            if ( $street && $city && $zip && false !== mb_stripos( $address, $street ) &&
                false !== mb_stripos( $address, $city ) && false !== mb_strpos( $address, $zip ) ) {
                $schema['address'] = array_filter( [
                    '@type' => 'PostalAddress', 'streetAddress' => $street, 'postalCode' => $zip,
                    'addressLocality' => $city, 'addressRegion' => $countries->get_base_state(),
                    'addressCountry' => $countries->get_base_country(),
                ] );
            }
        }
    }
    $phones = adb_contact_phones( $contact );
    if ( $phones && empty( $schema['telephone'] ) ) { $schema['telephone'] = (string) array_key_first( $phones ); }
    return $schema;
} );

add_filter( 'wp_sitemaps_posts_query_args', static function ( $args, $type ) {
    $args['has_password'] = false;
    if ( 'page' === $type && function_exists( 'wc_get_page_id' ) ) {
        $service_pages = array_filter( array_map( 'wc_get_page_id', [ 'cart', 'checkout', 'myaccount' ] ), static function ( $id ) { return $id > 0; } );
        $args['post__not_in'] = array_unique( array_merge( $args['post__not_in'] ?? [], $service_pages ) );
    }
    return $args;
}, 25, 2 );

// The media library uses this taxonomy to group attachments for editorial galleries.
add_filter( 'wp_sitemaps_taxonomies', static function ( $taxonomies ) {
    unset( $taxonomies['ticinoweb_media_gallery'] );
    return $taxonomies;
} );

function adb_empty_default_blog_category() {
    $id = (int) get_option( 'default_category' );
    $posts = get_posts( [
        'post_type' => 'post', 'post_status' => 'publish', 'cat' => $id,
        'numberposts' => 1, 'fields' => 'ids', 'suppress_filters' => false,
    ] );
    return $posts ? 0 : $id;
}

add_filter( 'wp_sitemaps_taxonomies_query_args', static function ( $args, $taxonomy ) {
    if ( 'category' === $taxonomy && ( $empty = adb_empty_default_blog_category() ) ) {
        $args['exclude'] = array_merge( wp_parse_id_list( $args['exclude'] ?? [] ), [ $empty ] );
    }
    return $args;
}, 25, 2 );

add_filter( 'wp_robots', static function ( $robots ) {
    if ( is_tax( 'ticinoweb_media_gallery' ) || ( is_category( (int) get_option( 'default_category' ) ) && adb_empty_default_blog_category() ) ) {
        unset( $robots['index'] );
        $robots['noindex'] = true;
    }
    return $robots;
} );

// Keep WooCommerce's own price, tax, stock and seller logic for every sellable variant.
add_filter( 'woocommerce_structured_data_type_for_page', static function ( $types ) {
    if ( is_product() ) { $types[] = 'productgroup'; }
    return $types;
} );

add_filter( 'woocommerce_structured_data_product', static function ( $data, $product ) {
    if ( ! $product instanceof WC_Product_Variable || ! is_product() || get_queried_object_id() !== $product->get_id() ) { return $data; }
    $ids = $product->get_visible_children();
    if ( count( $ids ) < 2 ) { return $data; }
    $options = $product->get_variation_attributes();
    $variants = [];
    $axes = [];
    $generator = clone WC()->structured_data;
    foreach ( $ids as $id ) {
        $variation = wc_get_product( $id );
        if ( ! $variation || ! $variation->variation_is_visible() ) { continue; }
        $args = [];
        $specs = [];
        foreach ( $options as $attribute => $choices ) {
            $param = wc_variation_attribute_name( $attribute );
            $slug = $variation->get_variation_attributes()[ $param ] ?? '';
            // A wildcard with one catalog choice has a concrete selectable URL.
            if ( '' === $slug && 1 === count( $choices ) ) { $slug = reset( $choices ); }
            if ( '' === $slug ) { return $data; }
            $args[ $param ] = $slug;
            $term = taxonomy_exists( $attribute ) ? get_term_by( 'slug', $slug, $attribute ) : null;
            $name = $term ? $term->name : $slug;
            $label = wc_attribute_label( $attribute, $product );
            $axis = 'pa_dimensione' === $attribute ? 'https://schema.org/size' : $label;
            $axes[ $axis ][ $slug ] = true;
            if ( 'pa_dimensione' === $attribute ) { $specs['size'] = $name; }
            else { $specs['additionalProperty'][] = [ '@type' => 'PropertyValue', 'name' => $label, 'value' => $name ]; }
        }
        $url = add_query_arg( $args, $product->get_permalink() );
        if ( isset( $variants[ $url ] ) ) { return $data; }
        $count = count( $generator->get_data() );
        $generator->generate_product_data( $variation );
        $nodes = $generator->get_data();
        if ( ! isset( $nodes[ $count ]['offers'][0] ) ) { return $data; }
        $item = $nodes[ $count ];
        $item['sku'] = (string) ( $variation->get_sku( 'edit' ) ?: $id );
        $item['url'] = $url;
        $item['@id'] = $url . '#product';
        $item['offers'][0]['url'] = $url;
        if ( empty( $item['description'] ) && ! empty( $data['description'] ) ) { $item['description'] = $data['description']; }
        $variants[ $url ] = $item + $specs;
    }
    if ( count( $variants ) < 2 ) { return $data; }
    unset( $data['offers'], $data['sku'], $data['gtin'], $data['inProductGroupWithID'] );
    $data['@type'] = 'ProductGroup';
    $data['productGroupID'] = (string) ( $product->get_sku() ?: $product->get_id() );
    $data['variesBy'] = array_keys( array_filter( $axes, static fn( $values ) => count( $values ) > 1 ) );
    $data['hasVariant'] = array_values( $variants );
    return $data;
}, 40, 2 );


// The winery taxonomy is shared by bottles and producer biographies. Only list
// a catalog archive in the sitemap when a published product actually uses it.
add_filter( 'wp_sitemaps_taxonomies_query_args', static function ( $args, $taxonomy ) {
    if ( 'pa_cantina' === $taxonomy ) { $args['adb_sitemap_products'] = true; }
    return $args;
}, 30, 2 );

add_filter( 'terms_clauses', static function ( $clauses, $taxonomies, $args ) {
    if ( empty( $args['adb_sitemap_products'] ) || [ 'pa_cantina' ] !== $taxonomies ) { return $clauses; }
    global $wpdb;
    $clauses['where'] .= " AND EXISTS (
        SELECT 1 FROM {$wpdb->term_relationships} adb_rel
        INNER JOIN {$wpdb->posts} adb_bottle ON adb_bottle.ID = adb_rel.object_id
        WHERE adb_rel.term_taxonomy_id = tt.term_taxonomy_id
        AND adb_bottle.post_type = 'product' AND adb_bottle.post_status = 'publish'
    )";
    return $clauses;
}, 25, 3 );

add_filter( 'wp_robots', static function ( $robots ) {
    global $wp_query;
    if ( is_tax( 'pa_cantina' ) && 0 === (int) $wp_query->post_count ) {
        unset( $robots['index'] );
        $robots['noindex'] = true;
    }
    return $robots;
} );


// WooCommerce HTML-escapes its JSON, but script contents are raw text. Use a
// JSON escape for ampersands so a second variation parameter keeps its name.
add_action( 'wp', static function () {
    if ( ! is_product() || ! WC()->structured_data ) { return; }
    $output = [ WC()->structured_data, 'output_structured_data' ];
    if ( ! remove_action( 'wp_footer', $output, 10 ) ) { return; }
    add_action( 'wp_footer', static function () use ( $output ) {
        ob_start();
        call_user_func( $output );
        $markup = ob_get_clean();
        echo str_replace( '&amp;', '\u0026', $markup ); // Already escaped by WooCommerce.
    }, 10 );
} );
