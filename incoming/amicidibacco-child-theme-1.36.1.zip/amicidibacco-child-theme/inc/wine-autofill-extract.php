<?php
/** Turn verified, product-scoped winery pages into editable Italian catalogue fields. */
defined( 'ABSPATH' ) || exit;

function adb_fill_fact_key( $text ) {
    return trim( preg_replace( '/[^a-z0-9]+/', ' ', strtolower( remove_accents( $text ) ) ) );
}

function adb_fill_fact_labels() {
    static $labels = null;
    if ( null !== $labels ) { return $labels; }
    $groups = array(
        'etichetta' => 'denominazione|denominazione di origine|appellation|denomination|classificazione',
        'vitigno' => 'uva|uve|vitigno|vitigni|uvaggio|composizione ampelografica|varietà delle uve|varietà di uva|varietà|grape varieties|grape varietals|grape variety|grapes|cépages|cépage|rebsorten',
        'vinificazione' => 'vinificazione|vinificazione e affinamento|tecnica di vinificazione|in cantina|vinification|winemaking|wine making process',
        'affinamento' => 'affinamento|maturazione|invecchiamento|affinamento e maturazione',
        'colore' => 'colore|aspetto|esame visivo|alla vista|color|colour|appearance|couleur',
        'abbinamenti_gastronomici' => 'abbinamenti|abbinamento|abbinamenti consigliati|abbinamenti gastronomici|accostamenti gastronomici|gastronomia|accordi gastronomici|food pairing|ideal food pairing|pairing|accords mets et vins',
        'gradazione_alcolica' => 'gradazione alcolica|grado alcolico|titolo alcolometrico|titolo alcolometrico volumico|tenore alcolico|alcol svolto|alcol|alcool|alcool svolto|alcohol|alcohol content|abv',
        'temperatura_di_servizio' => 'temperatura di servizio|temperatura consigliata|temperatura di degustazione|servizio|serving temperature|service temperature|température de service',
        'al_naso' => 'al naso|naso|all’olfatto|olfatto|profilo olfattivo|esame olfattivo|profumo|profumi|bouquet|nose|nez',
        'al_palato' => 'al palato|palato|in bocca|sapore|gusto|esame gustativo|profilo gustativo|palate|taste|bouche',
        'finish' => 'finale|il finale|finale di bocca|retrogusto|finish',
        'aromas' => 'aromi|aromi principali|profumi principali',
        'area' => 'zona di produzione e suolo|zona di produzione|zona di origine|area di produzione|production area|growing area',
        'pa_regione' => 'regione|regione di provenienza|regione di produzione|cantone|region|région',
        'pa_nazione' => 'nazione|paese|paese di origine|paese di produzione|country|pays',
        'categoria' => 'tipologia|tipo di vino|categoria|wine type|tipo',
        'body' => 'corpo|struttura|body',
        'freshness' => 'freschezza|freshness',
        'sweetness' => 'dolcezza|sweetness',
        'tannin' => 'tannino|tannini|tannin',
        'persistence' => 'persistenza|persistence',
        '_' => 'annata|vendemmia|vintage|anno|degustazione|note di degustazione|caratteristiche organolettiche|scheda tecnica|specifiche|dati tecnici|dati analitici|dati tecnici del vino|altre informazioni|in vigna|in vigneto|terreno|terroir|suolo|esposizione|altitudine|resa per ettaro|formato|formati|bottiglia|bottiglie|packaging|bottling|pH|acidità totale|zuccheri residui|estratto secco|technical data|tasting notes|vineyard management|soil|soil type|available format sizes|total acidity|residual sugar',
    );
    $labels = array();
    foreach ( $groups as $key => $names ) {
        foreach ( explode( '|', $names ) as $name ) { $labels[ adb_fill_fact_key( $name ) ] = $key; }
    }
    return $labels;
}

/** Keep the text of the published figure. Never confuse a fermentation temperature with service. */
function adb_fill_fact_measure( $key, $value ) {
    if ( 'gradazione_alcolica' === $key ) {
        if ( ! preg_match( '/^\s*(\d{1,2}(?:[.,]\d{1,2})?)\s*(?:%\s*(?:vol\.?)?|°(?:\s*vol\.?)?|vol\.?\s*%?)\s*[.]?$/iu', $value, $m ) ) { return ''; }
        return (float) str_replace( ',', '.', $m[1] ) <= 25 ? str_replace( '.', ',', $m[1] ) . '% vol.' : '';
    }
    $value = preg_replace( '/\.?\s*(?:scarica (?:la )?)?scheda tecnica(?: in pdf)?\s*$/iu', '', $value );
    if ( ! preg_match( '/^(?:(?:servire|servire a|serve at|circa)\s+)?(\d{1,2})(?:\s*[°º]?\s*(?:[-–—\/]|a)\s*(\d{1,2}))?\s*[°º]\s*(?:C(?:elsius)?)?\s*[.]?$/iu', $value, $m ) ) { return ''; }
    $high = isset( $m[2] ) && '' !== $m[2] ? (int) $m[2] : (int) $m[1];
    return (int) $m[1] <= $high && $high <= 25 ? $m[1] . ( $high !== (int) $m[1] ? '–' . $high : '' ) . ' °C' : '';
}

function adb_fill_fact_category( $value ) {
    $categories = array(
        'Champagne' => 'champagne', 'Franciacorta' => 'franciacorta', 'Prosecco' => 'prosecco',
        'Metodo classico' => 'metodo classico', 'Spumante' => 'spumante|sparkling wine',
        'Vini Dolci e Passiti' => 'vino (?:dolce|passito)|^passito$',
        'Vini Rosé' => '(?:vino |^)(?:rosato|rose)\b|rose wine',
        'Vini Bianchi' => '(?:vino |^)bianco\b|white wine',
        'Vini Rossi' => '(?:vino |^)rosso\b|red wine',
    );
    foreach ( $categories as $name => $pattern ) {
        if ( preg_match( '~\b(?:' . $pattern . ')\b~', adb_fill_fact_key( $value ) ) ) { return $name; }
    }
    return '';
}

function adb_fill_fact_sections( $text, $pdf = false ) {
    $labels = adb_fill_fact_labels();
    $sections = array();
    $lines = array();
    $pending = '';
    $continuation = '';
    // Keep original sentence boundaries. Producers often pair a heading with a separate paragraph.
    $text = str_replace( array( "\xc2\xa0", "\xe2\x80\xaf" ), ' ', $text );
    if ( $pdf ) {
        $paragraphs = array();
        foreach ( preg_split( '/\R/u', mb_substr( $text, 0, 60000 ) ) as $row ) {
            $row = trim( $row );
            if ( '' === $row ) { continue; }
            $last = count( $paragraphs ) - 1;
            if ( $last >= 0 && ! isset( $labels[ adb_fill_fact_key( $paragraphs[ $last ] ) ] )
                && ! isset( $labels[ adb_fill_fact_key( $row ) ] )
                && preg_match( '/^\p{Ll}/u', $row ) && ! preg_match( '/[.!?:]$/u', $paragraphs[ $last ] )
                && ! str_contains( $row, '@' ) && mb_strlen( $paragraphs[ $last ] ) + mb_strlen( $row ) < 1500 ) {
                $paragraphs[ $last ] .= ' ' . $row;
            } else {
                $paragraphs[] = $row;
            }
        }
        $text = implode( "\n", $paragraphs );
    }
    foreach ( preg_split( '/\R/u', mb_substr( $text, 0, 60000 ) ) as $line ) {
        $line = trim( preg_replace( '/\s+/u', ' ', wp_strip_all_tags( $line ) ) );
        if ( '' === $line ) { continue; }
        if ( preg_match( '/^(?:footer|prodotti correlati|prodotti consigliati|vini correlati|altri vini(?: della cantina)?|scopri (?:anche |gli altri vini)|potrebbe piacerti|ti potrebbe interessare|related (?:products|wines)|you may also like|restiamo in contatto|torna alla lista|iscriviti alla newsletter)\b/iu', $line ) ) { break; }
        $lines[] = $line;
        $parts = preg_split( '/\s*[:：]\s*/u', ltrim( $line, "- \t" ), 2 );
        $label = adb_fill_fact_key( $parts[0] );
        if ( isset( $labels[ $label ] ) ) {
            $continuation = '';
            $pending = $labels[ $label ];
            $line = $parts[1] ?? '';
            if ( '' === $line ) { continue; }
        } elseif ( count( $parts ) > 1 && mb_strlen( $parts[0] ) < 55 ) {
            $pending = '';
            $continuation = '';
        } elseif ( $pdf && ! $pending && 'vinificazione' === $continuation && mb_strlen( $sections[ $continuation ] ) + mb_strlen( $line ) < 1400
            && preg_match( '/^(?:dopo la (?:pressatura|fermentazione|raccolta)|segue (?:la|un periodo di)|la (?:fermentazione|macerazione|pressatura)|il (?:mosto|vino) (?:fermenta|sosta|riposa|affina))\b/iu', $line )
            && ! preg_match( '~https?://|@|www\.~iu', $line ) ) {
            // A new cellar sentence can follow a full stop on the next printed line of a PDF.
            $sections[ $continuation ] .= ' ' . $line;
            continue;
        } elseif ( ! $pending && $continuation && mb_strlen( $sections[ $continuation ] ) + mb_strlen( $line ) < 1700 &&
            ( preg_match( '/[,]$/u', $sections[ $continuation ] ) || ( $pdf && ! preg_match( '/[.!?:]$/u', $sections[ $continuation ] ) ) ) &&
            ( preg_match( '/^\p{Ll}/u', $line ) || ( 'vitigno' === $continuation && preg_match( '/^\d+(?:[.,]\d+)?\s*%/u', $line ) ) ) ) {
            $sections[ $continuation ] .= ( 'vitigno' === $continuation ? ', ' : ' ' ) . $line;
            continue;
        }
        $continuation = '';
        if ( $pending && '_' !== $pending && ! isset( $sections[ $pending ] ) && mb_strlen( $line ) <= 1800 && ( 'temperatura_di_servizio' === $pending || ! preg_match( '/https?:\/\/|[\w.+-]+@[\w.-]+|(?:scarica|acquista|download|aggiungi al carrello|cookie)\b/iu', $line ) ) ) {
            $sections[ $pending ] = $line;
            $continuation = $pending;
        }
        $pending = '';
    }
    return array( $sections, array_values( array_unique( $lines ) ) );
}

/** Pick individually identifiable sensory statements from unlabelled Italian tasting prose. */
function adb_fill_fact_sensory( $lines ) {
    $notes = array();
    // Prefer the dedicated tasting section over a marketing lead that repeats the same notes.
    foreach ( $lines as $index => $heading ) {
        if ( in_array( adb_fill_fact_key( $heading ), array( 'degustazione', 'note di degustazione', 'caratteristiche organolettiche' ), true ) ) {
            $lines = array_merge( array_slice( $lines, $index + 1 ), array_slice( $lines, 0, $index ) );
            break;
        }
    }
    foreach ( $lines as $line ) {
        foreach ( preg_split( '/(?<=[.!?;])\s+|\s*[:,]\s*(?=al naso|in bocca|al palato)/iu', $line ) as $sentence ) {
            $sentence = trim( $sentence );
            if ( mb_strlen( $sentence ) > 370 || mb_strlen( $sentence ) < 8 ) { continue; }
            $patterns = array(
                'colore' => '/^(?:(?:il )?colore\s+|alla vista\s+|(?:si presenta |si presenta di |è di )colore\s+)(.+)/iu',
                'al_naso' => '/^(?:(?:al naso|all[’\x27]olfatto)\s+|(?=profumi\s)|(?=il profumo\s))(.+)/iu',
                'al_palato' => '/^(?:(?:al palato|in bocca)\s+|(?=il sorso\s))(.+)/iu',
            );
            foreach ( $patterns as $key => $pattern ) {
                if ( ! isset( $notes[ $key ] ) && preg_match( $pattern, $sentence, $m ) ) { $notes[ $key ] = trim( $m[1], " :,." ); }
            }
        }
    }
    return $notes;
}

function adb_fill_fact_aromas( $value ) {
    $aromas = array();
    $vocabulary = array(
        'Erbe aromatiche' => 'erbe aromatiche', 'Frutti di bosco' => 'frutti di bosco|frutta di bosco', 'Agrumi' => 'agrum[ie]', 'Fiori' => 'floreal[ie]|fiorit[io]|fiori',
        'Ciliegia' => 'ciliegi[ae]', 'Amarena' => 'amaren[ae]', 'Frutti rossi' => 'frutt[ia] ross[ia]', 'Mora' => 'mor[ae]', 'Lampone' => 'lampon[ei]',
        'Ribes' => 'ribes', 'Mirtillo' => 'mirtill[oi]', 'Fragola' => 'fragol[ae]', 'Prugna' => 'prugn[ae]', 'Mela' => 'mel[ae]', 'Pera' => 'per[ae]',
        'Pesca' => 'pesch[ea]|pesca', 'Albicocca' => 'albicocc[ah]e?', 'Limone' => 'limon[ei]', 'Pompelmo' => 'pompelm[oi]', 'Mandarino' => 'mandarin[oi]',
        'Rosa' => 'ros[ae]', 'Viola' => 'viol[ae]|violett[ae]', 'Gelsomino' => 'gelsomino', 'Acacia' => 'acacia', 'Tiglio' => 'tiglio',
        'Mandorla' => 'mandorl[ae]', 'Nocciola' => 'nocciol[ae]', 'Vaniglia' => 'vaniglia', 'Pepe nero' => 'pepe nero', 'Spezie' => 'spezie|speziat[ioae]',
        'Cannella' => 'cannella', 'Tabacco' => 'tabacco', 'Cacao' => 'cacao', 'Caffè' => 'caff[eè]', 'Miele' => 'miele', 'Liquirizia' => 'liquirizia',
        'Crosta di pane' => 'crosta di pane', 'Pietra focaia' => 'pietra focaia',
    );
    foreach ( $vocabulary as $name => $pattern ) {
        if ( preg_match( '~\b(?:' . $pattern . ')\b~iu', $value, $match, PREG_OFFSET_CAPTURE ) ) { $aromas[ $name ] = $match[0][1]; }
    }
    asort( $aromas, SORT_NUMERIC );
    return array_slice( array_keys( $aromas ), 0, 8 );
}

/** Editorial reference profiles, used only for axes the product sheet does not describe. */
function adb_fill_style_reference( $fields, $evidence ) {
    // In catalogue axis order: body, freshness, sweetness, tannin, persistence.
    $profiles = array(
        'white' => array( 3, 4, 1, 1, 3 ), 'red' => array( 3, 3, 1, 3, 3 ),
        'rose' => array( 2, 4, 1, 2, 3 ), 'sparkling' => array( 2, 4, 2, 1, 3 ),
        'sweet' => array( 4, 3, 5, 2, 4 ), 'orange' => array( 3, 3, 1, 3, 3 ),
    );
    $types = array(
        'sweet' => 'vini dolci e passiti|vino dolce|passito|icewine|eiswein|sauternes',
        'sparkling' => 'spumante|champagne|franciacorta|prosecco|metodo classico|alta langa|sparkling',
        'orange' => 'orange wine|bianco macerato', 'rose' => 'vini rose|rosato|rose|chiaretto',
        'white' => 'vini bianchi|bianco|gavi', 'red' => 'vini rossi|rosso|barolo|barbaresco|chianti',
    );
    $colors = array( 'white' => 'giallo|paglierino|dorato', 'rose' => 'rosato|rosa|cerasuolo', 'red' => 'rosso|rubino|granato|porpora' );
    $grapes = array(
        'white' => 'cortese|chardonnay|riesling|pinot grigio|pinot bianco|sauvignon blanc|garganega|vermentino|verdicchio|arneis|chasselas|fiano',
        'red' => 'nebbiolo|cabernet sauvignon|cabernet franc|merlot|syrah|primitivo|barbera|sangiovese|montepulciano|corvina|gamay|pinot nero|pinot noir',
    );
    foreach ( array( 'categoria' => $types, 'etichetta' => $types, 'colore' => $colors, 'vitigno' => $grapes ) as $key => $patterns ) {
        $fact = adb_fill_fact_key( $fields[ $key ] ?? '' );
        $matches = array();
        foreach ( $patterns as $style => $pattern ) {
            if ( preg_match( '~\b(?:' . $pattern . ')\b~', $fact ) ) { $matches[] = $style; }
        }
        if ( 1 === count( $matches ) ) {
            return array( array_combine( array_keys( adb_tasting_axes() ), $profiles[ $matches[0] ] ), $evidence[ $key ]['quote'] ?? $fields[ $key ] );
        }
    }
    return array( array(), '' );
}

/** Assess only named characteristics. A characteristic on an aroma or a food is not a palate score. */
function adb_fill_fact_estimates( $palate, $finish, $sections = array(), $type = array() ) {
    $rules = array(
        'body' => array( 5 => 'molto strutturat[oa]|grande struttura|grande corpo', 4 => 'corpo pieno|di corpo|corpos[oa]|strutturat[oa]|pieno corpo|piena struttura', 3 => 'medio corpo|corpo medio|medi[oa] struttura', 1 => 'corpo leggero|di corpo leggero|di facile beva' ),
        'freshness' => array( 5 => 'grande freschezza|spiccata freschezza|freschezza spiccata|vibrante acidita', 4 => 'fresc[oa]|freschezza|acidita vivace', 2 => 'acidita delicata|freschezza delicata|freschezza bassa|acidita bassa|poco fresco|poca freschezza' ),
        'sweetness' => array( 1 => '(?<!semi)secc[oa]|asciutt[oa]|brut nature|extra brut|brut|dosaggio zero|pas dose', 2 => 'abboccat[oa]|extra dry', 3 => 'amabile|demi sec|semisecc[oa]|(?<!extra )dry', 5 => 'gusto dolce|sorso dolce|vino dolce|dolcezza elevata|^dolce$|doux' ),
        'tannin' => array( 5 => 'tannin[oi] (?:molto )?(?:potent[ei]|pronunciat[oi]|decis[oi])', 4 => 'tannin[oi] (?:ben )?(?:present[ei]|fermi|vigoros[oi])', 2 => 'tannin[oi] (?:delicat[oi]|morbid[oi]|setos[oi]|discret[oi])' ),
        'persistence' => array( 5 => 'finale (?:molto lungo|lunghissimo)|lunghissima persistenza', 4 => '(?:finale|retrogusto|chiusura) lungo|(?:a )?lung[oa] persistenza|persistent[ei]|buona persistenza|persistenza', 3 => 'media persistenza|persistenza media|finale di media lunghezza', 2 => 'poco persistente|persistenza limitata|persistenza modesta', 1 => 'finale breve|breve persistenza|scarsa persistenza|persistenza breve' ),
    );
    $result = array();
    $labels = array( 'body' => 'Corpo', 'freshness' => 'Freschezza', 'sweetness' => 'Dolcezza', 'tannin' => 'Tannini', 'persistence' => 'Persistenza' );
    foreach ( $rules as $axis => $scale ) {
        $fragments = preg_split( '/[.!?;]+/u', $palate );
        if ( 'persistence' === $axis && $finish ) { array_unshift( $fragments, $finish ); }
        if ( ! empty( $sections[ $axis ] ) ) { array_unshift( $fragments, $sections[ $axis ] ); }
        if ( 'sweetness' === $axis ) { $fragments = array_merge( $fragments, $type ); }
        foreach ( $fragments as $fragment ) {
            $prefix = '';
            if ( $fragment === ( $sections[ $axis ] ?? null ) ) { $prefix = $labels[ $axis ]; }
            elseif ( 'persistence' === $axis && $fragment === $finish ) { $prefix = 'Finale'; }
            $normalized = adb_fill_fact_key( $prefix . ' ' . $fragment );
            if ( preg_match( '/\b(?:non|privo|senza|assenza)\b/', $normalized ) ) { continue; }
            $match_score = null;
            $match_length = 0;
            foreach ( $scale as $value => $pattern ) {
                if ( preg_match( '~\b(?:' . $pattern . ')\b~', $normalized, $m ) && $m[0] !== strtolower( $prefix ) && strlen( $m[0] ) > $match_length ) {
                    $match_length = strlen( $m[0] );
                    $match_score = $value;
                }
            }
            if ( null !== $match_score ) { $result[ $axis ] = array( $match_score, trim( $fragment ) ); break; }
        }
    }
    return $result;
}

function adb_fill_fact_region( $value ) {
    $regions = array(
        'Italia' => array( 'Abruzzo','Basilicata','Calabria','Campania','Emilia Romagna','Friuli Venezia Giulia','Lazio','Liguria','Lombardia','Marche','Molise','Piemonte','Puglia','Sardegna','Sicilia','Toscana','Trentino','Alto Adige','Umbria','Valle d’Aosta','Veneto' ),
        'Svizzera' => array( 'Ticino','Vallese','Vaud','Ginevra','Grigioni' ),
        'Francia' => array( 'Borgogna','Bordeaux','Champagne','Alsazia','Provenza' ),
    );
    $haystack = ' ' . adb_fill_fact_key( $value ) . ' ';
    $matches = array();
    foreach ( $regions as $country => $names ) {
        foreach ( $names as $region ) {
            if ( false !== strpos( $haystack, ' ' . adb_fill_fact_key( $region ) . ' ' ) ) { $matches[] = array( $region, $country ); }
        }
    }
    return 1 === count( $matches ) ? $matches[0] : array();
}

function adb_fill_fact_country( $value ) {
    $names = array( 'Italia' => array( 'italia','italy','italie' ), 'Svizzera' => array( 'svizzera','switzerland','suisse','schweiz' ), 'Francia' => array( 'francia','france','frankreich' ), 'Spagna' => array( 'spagna','spain','espagne','espana' ), 'Portogallo' => array( 'portogallo','portugal' ), 'Germania' => array( 'germania','germany','deutschland' ), 'Austria' => array( 'austria','osterreich' ) );
    foreach ( $names as $country => $aliases ) {
        if ( in_array( adb_fill_fact_key( $value ), $aliases, true ) ) { return $country; }
    }
    return '';
}

function adb_fill_fact_sentence( $text ) {
    $text = trim( $text, " \t\r\n.;," );
    return '' === $text ? '' : mb_strtoupper( mb_substr( $text, 0, 1 ) ) . mb_substr( $text, 1 ) . '.';
}

function adb_fill_fact_list( $items ) {
    $items = array_values( array_filter( array_map( 'trim', $items ) ) );
    $last = array_pop( $items );
    if ( ! $last || ! $items ) { return (string) $last; }
    return implode( ', ', $items ) . ( preg_match( '/^e/iu', $last ) ? ' ed ' : ' e ' ) . $last;
}

/** Keep each duration, vessel and proportion attached to the operation the winery describes. */
function adb_fill_story_cellar( $vinification, $aging ) {
    $story = array();
    $process = mb_strtolower( remove_accents( $vinification ) );
    if ( preg_match( '/\b(?:raccolt[ae]|vendemmiat[ae]) (?:[a-z]+ ){0,2}(?:manual\w*|a mano)\b/', $process ) ) {
        $story[] = str_contains( $process, 'manualmente in cassetta' ) ? 'La raccolta avviene a mano, in cassetta.' : 'La vendemmia si svolge a mano.';
    }
    if ( preg_match( '/\bpressatura soffice\b/', $process ) ) { $story[] = 'In cantina le uve vengono pressate delicatamente.'; }
    if ( preg_match( '/\bsfecciatura statica (?:del mosto|dei mosti) per ((?:circa |almeno )?\d+ ore)\b/', $process, $m ) ) {
        $story[] = 'I mosti decantano per ' . $m[1] . '.';
    }
    if ( preg_match( '/\bfermentazione (?:alcolica |del mosto )?(?:(?:avviene|si svolge) )?(in (?:vasche di )?acciaio(?: a temperatura controllata)?|a bass[ae] temperatur[ae]|spontanea)(?: per ((?:circa |almeno )?\d+ giorni))?/u', $process, $m ) ) {
        $sentence = 'La fermentazione ' . ( 'spontanea' === $m[1] ? 'è spontanea' : 'si svolge ' . $m[1] );
        if ( ! empty( $m[2] ) ) { $sentence .= ' e dura ' . $m[2]; }
        if ( preg_match( '/\bper (\d+\/\d+) della sua durata,? (?:completamento della stessa|conclusione) in (barrique(?: francesi)?|acciaio|bottiglia)\b/', $process, $end ) ) {
            $fraction = strtr( $end[1], array( '2/3' => 'due terzi', '1/3' => 'un terzo', '1/2' => 'metà' ) );
            $sentence .= ' per ' . $fraction . ' della sua durata e si conclude in ' . $end[2];
        } elseif ( preg_match( '/\b(?:termina|si conclude|si completa) in (barrique(?: francesi)?|acciaio|bottiglia)\b/', $process, $end ) ) {
            $sentence .= ' e si conclude in ' . $end[1];
        }
        $story[] = $sentence . '.';
    }

    $maturation = mb_strtolower( remove_accents( $aging ?: 'Vinificazione: ' . $vinification ) );
    if ( preg_match( '/\b(?:sosta|riposa|rimane) (?:a contatto (?:con i |dei |con )?(?:propri )?|sui )lieviti(?: (?:per|di) ((?:circa |almeno )?\d+ mesi))?\b/', $maturation, $m ) ) {
        $story[] = 'Il vino riposa sui lieviti' . ( ! empty( $m[1] ) ? ' per ' . $m[1] : '' ) . '.';
    }
    if ( preg_match( '/\b((?:circa |almeno )?\d+ mesi)\s*\(\s*(\d+(?:[.,]\d+)?\s*%) in (barrique|acciaio|botti di rovere) e (\d+(?:[.,]\d+)?\s*%) in (barrique|acciaio|botti di rovere)\s*\)/', $maturation, $m ) && $aging ) {
        $story[] = 'Il vino affina per ' . $m[1] . ', suddiviso tra ' . $m[3] . ' (' . $m[2] . ') e ' . $m[5] . ' (' . $m[4] . ').';
    } elseif ( preg_match( '/(?:\b(?:affinamento|affina|matura|maturazione|riposa)\s+|^)(?:per ((?:circa |almeno )?\d+ mesi) )?in (acciaio|bottiglia|barrique(?: francesi)?|botti di rovere)(?: (?:per|di) ((?:circa |almeno )?\d+ mesi))?\b/', $maturation, $m ) ) {
        $duration = $m[1] ?: ( $m[3] ?? '' );
        $sentence = 'Il vino affina in ' . $m[2] . ( $duration ? ' per ' . $duration : '' );
        if ( preg_match( '/\bbatonnage sui lieviti\b/', $maturation ) ) { $sentence .= ' con rimescolamento dei lieviti'; }
        $story[] = $sentence . '.';
    }
    return $story;
}

function adb_fill_fact_lower_initial( $value ) {
    return mb_strtolower( mb_substr( $value, 0, 1 ) ) . mb_substr( $value, 1 );
}

/** A matching glass note or a practical pairing adds more than a repeated ingredient list. */
function adb_fill_story_palate( $value ) {
    $value = trim( $value, '. ' );
    if ( ! $value || mb_strlen( $value ) > 240 ) { return ''; }
    if ( preg_match( '/^buona l[’\x27]acidità\b/iu', $value ) ) {
        $phrase = 'Il sorso ha una buona acidità';
        if ( preg_match( '/\b(?:equilibrando|bilanciando) la morbidezza\b/iu', $value ) ) {
            $phrase .= ', che bilancia la morbidezza';
            if ( preg_match( '/\bmorbidezza naturale della leggera sur[ -]?maturazione delle uve\b/iu', $value ) ) { $phrase .= ' delle uve leggermente surmature'; }
        }
        return $phrase . '.';
    }
    if ( preg_match( '/^(?:il sorso|il gusto|al palato|in bocca)\b/iu', $value ) ) { return adb_fill_fact_sentence( $value ); }
    if ( preg_match( '/^(?:è\s|si\s|sorprende|presenta|mostra|rivela|spicca|emerge|emergono|prevale|prevalgono|esprime)/iu', $value ) ) {
        return 'Al palato ' . adb_fill_fact_lower_initial( $value ) . '.';
    }
    if ( preg_match( '/^(?:bilanciato|fresco|pieno|morbido|rotondo|fragrante|sapido|secco|intenso|fruttato|armonico|elegante|equilibrato|di corpo)\b/iu', $value ) ) {
        return 'Il sorso è ' . adb_fill_fact_lower_initial( $value ) . '.';
    }
    return '';
}

function adb_fill_story_pairing( $value ) {
    $value = trim( $value, '. ' );
    if ( ! $value || mb_strlen( $value ) > 210 ) { return ''; }
    if ( preg_match( '/^(?:(?:particolarmente )?(?:adatto|ideale|perfetto|ottimo) (?:per |ad? )?accompagnare|si abbina (?:bene )?(?:a|con)|da abbinare a) (.+)$/iu', $value, $m ) ) { $value = $m[1]; }
    if ( preg_match( '/^(?:(?:particolarmente )?(?:adatto|ideale|perfetto|ottimo) )?(come aperitivo\b.*)$/iu', $value, $m ) ) {
        return 'La cantina lo consiglia ' . lcfirst( $m[1] ) . '.';
    }
    if ( preg_match( '/^(?:carni|carne|piatti|salumi|formaggi|pesce|pesci|crostacei|molluschi|antipasti|primi|secondi|pasta|risott[oi]|selvaggina|arrosti|pollame|verdure|zuppe|dolci|dessert|frutti di mare)\b/iu', $value ) ) {
        return 'A tavola si abbina a ' . adb_fill_fact_lower_initial( $value ) . '.';
    }
    return '';
}

/** The catalogue pairs a short introduction with a separate account of how the wine is made and served. */
function adb_fill_fact_prose( $wine, $producer, $fields, $aromas, $sections = array() ) {
    $first = $producer ? $producer . ' produce ' . $wine : $wine;
    $grapes = trim( $fields['vitigno'] ?? '', '. ' );
    $label = trim( $fields['etichetta'] ?? '', '. ' );
    $distinct_label = $label && ! str_contains( adb_fill_fact_key( $wine ), adb_fill_fact_key( $label ) );
    if ( $distinct_label ) {
        $label = preg_replace_callback( '/\b(?:docg?|ig[tp]|dop|aoc)\b/iu', static function ( $m ) { return strtoupper( $m[0] ); }, $label );
        if ( $producer && $grapes ) { $first .= ', ' . $label; }
    }
    $single = $grapes && preg_match( '/^(?:100\s*%\s*([\pL][\pL\s’\x27-]*)|([\pL][\pL\s’\x27-]*)\s+100\s*%)$/iu', $grapes, $m );
    if ( $single ) {
        $first .= ( $producer ? ' da sole uve ' : ' nasce da sole uve ' ) . trim( $m[1] ?: $m[2] );
    } elseif ( $grapes && ! str_contains( $grapes, '%' ) && mb_strlen( $grapes ) < 100 ) {
        $first .= ( $producer ? ' da uve ' : ' nasce da uve ' ) . adb_fill_fact_list( preg_split( '/[,;]\s*/u', $grapes ) );
    }
    $excerpt = array( adb_fill_fact_sentence( $first ) );
    $blend = $grapes && ! $single && str_contains( $grapes, '%' );
    if ( $blend ) { $excerpt[] = 'L’uvaggio comprende ' . $grapes . '.'; }
    $color = trim( preg_replace( '/^(?:(?:di )?colore?\s+|si presenta (?:di colore )?)/iu', '', $fields['colore'] ?? '' ), '. ' );
    if ( $color && mb_strlen( $color ) < 105 && preg_match( '/^(?:rosso|rosa|rosato|giallo|rubino|granato|porpora|salmone|ambra|ambrato|violaceo|dorato|paglierino|ramato|aranciat[oa]|buccia di cipolla|oro|corallo|cerasuolo)\b/iu', $color ) ) {
        $excerpt[] = 'Nel calice si presenta ' . lcfirst( $color ) . '.';
    }
    // Prefer an identified flower over the generic tag when both describe the same aroma.
    if ( array_intersect( $aromas, array( 'Gelsomino', 'Acacia', 'Rosa', 'Viola', 'Tiglio' ) ) ) { $aromas = array_diff( $aromas, array( 'Fiori' ) ); }
    $nose = trim( $fields['al_naso'] ?? '', '. ' );
    if ( preg_match( '/^fiori di ([\pL\s’\x27-]{3,65}),? accompagnati da un (?:lieve|leggero) sentore di ([\pL\s,’\x27-]{3,100})$/iu', $nose, $m ) ) {
        $excerpt[] = 'Ai profumi di ' . lcfirst( trim( $m[1] ) ) . ' si affiancano cenni di ' . lcfirst( $m[2] ) . '.';
    } elseif ( preg_match( '/^(intenso|fine|delicato|ampio)( e persistente)? con note (floreali|agrumate|fruttate|speziate)$/iu', $nose, $m ) ) {
        $excerpt[] = 'Il profumo è ' . mb_strtolower( $m[1] . $m[2] ) . ', con richiami ' . strtr( mb_strtolower( $m[3] ), array( 'agrumate' => 'agrumati', 'fruttate' => 'fruttati', 'speziate' => 'speziati' ) ) . '.';
    } elseif ( $aromas ) {
        $excerpt[] = 'Al naso emergono note di ' . mb_strtolower( adb_fill_fact_list( array_slice( $aromas, 0, 5 ) ) ) . '.';
    }
    $story = adb_fill_story_cellar( $sections['vinificazione'] ?? ( $fields['vinificazione'] ?? '' ), $sections['affinamento'] ?? '' );
    $area = trim( $sections['area'] ?? '', '. ' );
    if ( $area && preg_match( '/^(versante|territorio|comune) ([\pL\s’\x27-]{3,70}?)\s+[-–]\s+([\pL\s’\x27-]+)$/iu', $area, $m )
        && adb_fill_fact_key( $m[3] ) === adb_fill_fact_key( $fields['pa_regione'] ?? '' ) ) {
        array_unshift( $story, 'Le uve provengono dal ' . mb_strtolower( $m[1] ) . ' ' . $m[2] . ', in ' . $m[3] . '.' );
    }
    $palate = adb_fill_story_palate( $fields['al_palato'] ?? '' );
    $pairing = adb_fill_story_pairing( $fields['abbinamenti_gastronomici'] ?? '' );
    if ( $distinct_label && ( ! $producer || ! $grapes ) ) { $excerpt[] = 'L’etichetta riporta la denominazione ' . $label . '.'; }
    if ( $palate ) { $story[] = $palate; }
    if ( $pairing ) { $story[] = $pairing; }
    if ( count( $story ) < 5 && ! empty( $fields['temperatura_di_servizio'] ) ) { $story[] = 'La cantina consiglia di servirlo a ' . $fields['temperatura_di_servizio'] . '.'; }
    if ( count( $story ) < 2 && ! empty( $fields['pa_regione'] ) ) { $story[] = 'La regione di provenienza è ' . $fields['pa_regione'] . '.'; }
    if ( count( $story ) < 2 && ! empty( $fields['gradazione_alcolica'] ) ) { $story[] = 'Il tenore alcolico è del ' . rtrim( $fields['gradazione_alcolica'], '. ' ) . '.'; }
    return array( 'excerpt' => implode( ' ', $excerpt ), 'description' => implode( ' ', $story ) );
}

/** Resolve facts within one document; undated or conflicting releases are never stitched together. */
function adb_fill_fact_document( $wine, $producer, $doc ) {
    list( $sections, $lines ) = adb_fill_fact_sections( $doc['text'], (bool) preg_match( '/\.pdf(?:$|[?#])/i', $doc['url'] ) );
    $language = strtolower( substr( (string) ( $doc['lang'] ?? '' ), 0, 2 ) );
    // Some Italian winery sites retain the CMS default en-GB. Distinct markers come from the actual card.
    preg_match_all( '/\b(?:vitign[oi]|vinificazione|uve|all.olfatto|abbinamenti|colore|profumo|palato|sapore|affinamento|denominazione)\b/iu', mb_strtolower( implode( "\n", $lines ) ), $markers );
    $italian = 'it' === $language || count( array_unique( $markers[0] ) ) >= 3 || ( '' === $language && ! empty( $markers[0] ) );
    if ( $italian ) { $sections += adb_fill_fact_sensory( $lines ); }
    $fields = array();
    $evidence = array();
    $record = static function ( $key, $value, $quote ) use ( &$evidence, $doc ) {
        if ( '' === trim( $value ) ) { return ''; }
        $evidence[ $key ] = array( 'url' => $doc['url'], 'title' => $doc['title'], 'vintage' => $doc['vintage'], 'quote' => mb_substr( $quote, 0, 500 ) );
        return sanitize_text_field( $value );
    };
    $keys = array( 'etichetta','vitigno','vinificazione','colore','abbinamenti_gastronomici','gradazione_alcolica','temperatura_di_servizio','al_naso','al_palato','pa_nazione','categoria' );
    foreach ( $keys as $key ) {
        $value = $sections[ $key ] ?? '';
        $quote = $value;
        if ( ! $value ) { continue; }
        if ( in_array( $key, array( 'gradazione_alcolica', 'temperatura_di_servizio' ), true ) ) {
            $value = adb_fill_fact_measure( $key, $value );
        } elseif ( 'categoria' === $key ) {
            $value = adb_fill_fact_category( $value );
        } elseif ( 'pa_nazione' === $key ) {
            $value = adb_fill_fact_country( $value );
        } elseif ( in_array( $key, array( 'vitigno','etichetta' ), true ) ) {
            if ( mb_strlen( $value ) > 220 ) { continue; }
            $value = rtrim( $value, '. ' );
        } elseif ( ! $italian ) {
            // Foreign pages still supply international names, numeric data and directly mappable types.
            continue;
        }
        if ( '' !== $value ) { $fields[ $key ] = $record( $key, $value, $quote ); }
    }
    if ( $italian && isset( $sections['affinamento'] ) ) {
        $aging = adb_fill_fact_sentence( $sections['affinamento'] );
        if ( preg_match( '/^(?:in|su|per|da)\s/iu', $aging ) ) { $aging = 'Affinamento ' . lcfirst( $aging ); }
        $process = trim( adb_fill_fact_sentence( $fields['vinificazione'] ?? '' ) . ' ' . $aging );
        $fields['vinificazione'] = $record( 'vinificazione', $process, $process );
    }
    $area = $sections['pa_regione'] ?? $sections['area'] ?? '';
    $region = adb_fill_fact_region( $area );
    if ( $region ) {
        $fields['pa_regione'] = $record( 'pa_regione', $region[0], $area );
        if ( empty( $fields['pa_nazione'] ) ) { $fields['pa_nazione'] = $record( 'pa_nazione', $region[1], $area ); }
    } elseif ( ! empty( $sections['pa_regione'] ) && mb_strlen( $area ) < 64 ) {
        $fields['pa_regione'] = $record( 'pa_regione', $area, $area );
    }
    if ( empty( $fields['etichetta'] ) ) {
        $identity = array_merge( array( $doc['title'] ), array_slice( $lines, 0, 12 ) );
        foreach ( $identity as $line ) {
            if ( mb_strlen( $line ) > 95 || ! preg_match( '/\b(?:DOCG?|IG[TP]|DOP|AOC|DOCa)\b/iu', $line ) || preg_match( '~https?://|[?!:]~iu', $line ) ) { continue; }
            $name = preg_replace( '/(?<![\pL\pN])' . preg_quote( $wine, '/' ) . '(?![\pL\pN])/iu', '', $line );
            if ( '' !== $producer ) { $name = preg_replace( '/(?<![\pL\pN])' . preg_quote( $producer, '/' ) . '(?![\pL\pN])/iu', '', $name ); }
            $name = trim( preg_replace( '/\b(?:19|20)\d\d\b/', '', $name ), " |·-–—,.“”\"'\t\n\r" );
            if ( $name && preg_match( '/\pL{4}/u', $name ) && preg_match( '/\b(?:DOCG?|IG[TP]|DOP|AOC|DOCa)\b/iu', $name ) ) {
                $fields['etichetta'] = $record( 'etichetta', $name, $line );
                break;
            }
        }
    }
    if ( ! isset( $fields['categoria'] ) ) {
        $type_lines = array( $fields['etichetta'] ?? '' );
        foreach ( $lines as $line ) {
            if ( mb_strlen( $line ) < 70 && preg_match( '/^(?:vino\s+(?:bianco|rosso|rosato|dolce|passito|spumante)|spumante\b|metodo classico\b|champagne\b|franciacorta\b|prosecco\b)/iu', $line ) ) { $type_lines[] = $line; }
        }
        foreach ( $type_lines as $line ) {
            $category = adb_fill_fact_category( $line );
            if ( $category ) { $fields['categoria'] = $record( 'categoria', $category, $line ); break; }
        }
    }
    $aroma_text = $italian ? ( $sections['aromas'] ?? $fields['al_naso'] ?? '' ) : '';
    $aromas = $aroma_text ? adb_fill_fact_aromas( $aroma_text ) : array();
    if ( $aromas ) { $record( 'aromas', implode( ', ', $aromas ), $aroma_text ); }
    $palate = $fields['al_palato'] ?? '';
    $finish = $italian ? ( $sections['finish'] ?? '' ) : '';
    if ( '' === $finish && preg_match( '/\b(?:finale|chiusura|retrogusto)\s+([^.;!]{3,140})/iu', $palate, $m ) ) {
        $finish = adb_fill_fact_sentence( $m[1] );
    }
    if ( '' === $finish && preg_match( '/\b(molto persistente|persistente|di lunga persistenza)\b/iu', $palate, $m ) && ! preg_match( '/\b(?:non|senza|privo)\b/iu', $palate ) ) {
        $finish = adb_fill_fact_sentence( $m[1] );
    }
    if ( $finish ) { $record( 'finish', $finish, $sections['finish'] ?? $palate ); }
    $scores = array();
    $score_evidence = array();
    $official = ! isset( $doc['official'] ) || true === $doc['official'];
    $type = array_filter( array( $sections['categoria'] ?? '', $fields['etichetta'] ?? '' ) );
    $descriptors = adb_fill_fact_estimates( $palate, $finish, $italian ? $sections : array(), $type );
    list( $reference, $style_quote ) = adb_fill_style_reference( $fields, $evidence );
    $method = '';
    $documented_axes = 0;
    foreach ( adb_tasting_axes() as $axis => $definition ) {
        if ( $official && isset( $sections[ $axis ] ) && preg_match( '/^([1-5])\s*(?:\/|su|of|sur)\s*5\s*\.?$/iu', $sections[ $axis ], $m ) ) {
            $score = (int) $m[1];
            $quote = $sections[ $axis ];
            $origin = 'official';
            $label = __( 'Punteggio della cantina', 'amicidibacco' );
        } elseif ( isset( $descriptors[ $axis ] ) ) {
            list( $score, $quote ) = $descriptors[ $axis ];
            $origin = 'descriptor';
            $label = __( 'Stima dalle note di degustazione', 'amicidibacco' );
        } elseif ( isset( $reference[ $axis ] ) ) {
            $score = $reference[ $axis ];
            $quote = $style_quote;
            $origin = 'style';
            $label = __( 'Stima dallo stile del vino', 'amicidibacco' );
        } else { continue; }
        $scores[ $axis ] = $score;
        $score_evidence[ $axis ] = $record( $axis, $label . ' · ' . $quote, $quote );
        $evidence[ $axis ]['score_origin'] = $origin;
        if ( 'style' !== $origin ) { ++$documented_axes; }
        if ( 'official' !== $origin ) { $method = 'editorial'; }
    }
    if ( $scores && ! $method ) { $method = 'official'; }
    if ( ! $fields && ! $scores && ! $aromas && ! $finish ) { return null; }
    $coverage = count( $fields ) + $documented_axes + ( $aromas ? 1 : 0 ) + ( $finish ? 1 : 0 );
    $fields['title'] = $record( 'title', $wine, $doc['title'] );
    if ( preg_match( '/^(?:19|20)\d{2}$/D', $doc['vintage'] ) ) { $fields['pa_anno'] = $record( 'pa_anno', $doc['vintage'], $doc['vintage'] ); }
    // Only Italian prose enters the narrative. Keep the two cellar operations separate to anchor their figures.
    $prose_sections = $italian ? $sections : array();
    foreach ( adb_fill_fact_prose( $wine, $producer, $fields, $aromas, $prose_sections ) as $key => $value ) {
        if ( $value ) {
            $quote_keys = 'excerpt' === $key ? array( 'vitigno', 'colore', 'al_naso', 'etichetta' ) : array( 'vinificazione', 'al_palato', 'abbinamenti_gastronomici', 'temperatura_di_servizio', 'etichetta', 'pa_regione', 'gradazione_alcolica' );
            $quotes = array_column( array_intersect_key( $evidence, array_flip( $quote_keys ) ), 'quote' );
            if ( 'description' === $key && ! empty( $prose_sections['area'] ) ) { $quotes[] = $prose_sections['area']; }
            $fields[ $key ] = $record( $key, $value, implode( ' · ', array_merge( array( $doc['title'] ), $quotes ) ) );
        }
    }
    $tasting = adb_sanitize_tasting( array(
        'aromas' => $aromas, 'finish' => $finish, 'scores' => $scores, 'score_method' => $method,
        'score_basis' => 'editorial' === $method ? __( 'Profilo indicativo basato sulle note della scheda e sullo stile del vino. I punteggi pubblicati dalla cantina sono identificati per singola voce.', 'amicidibacco' ) : '',
        'score_evidence' => $score_evidence, 'verification' => $official ? 'official_product' : 'legacy_reviewed', 'reference_vintage' => $doc['vintage'],
        'sources' => array( array( 'url' => $doc['url'], 'title' => $doc['title'], 'scope' => 'product', 'vintage' => $doc['vintage'], 'fields' => array_keys( $evidence ) ) ),
    ) );
    return array( 'fields' => $fields, 'tasting' => $tasting, 'evidence' => $evidence, 'coverage' => $coverage, 'italian' => $italian );
}

/** A second verified sheet of the same vintage may document facts absent from the principal one. */
function adb_fill_fact_supplement( &$primary, $secondary ) {
    $source = $secondary['tasting']['sources'][0] ?? null;
    if ( ! $source || in_array( $source['url'], array_column( $primary['tasting']['sources'], 'url' ), true ) ) { return; }
    $used = array();
    foreach ( $secondary['fields'] as $key => $value ) {
        if ( ! isset( $primary['fields'][ $key ] ) && isset( $secondary['evidence'][ $key ] ) ) {
            $primary['fields'][ $key ] = $value;
            $used[] = $key;
        }
    }
    foreach ( array( 'aromas', 'finish' ) as $key ) {
        if ( empty( $primary['tasting'][ $key ] ) && ! empty( $secondary['tasting'][ $key ] ) && isset( $secondary['evidence'][ $key ] ) ) {
            $primary['tasting'][ $key ] = $secondary['tasting'][ $key ];
            $used[] = $key;
        }
    }
    $profile = &$primary['tasting'];
    $other = $secondary['tasting'];
    // A documented score beats a sensory inference, which beats a reference by style.
    $priority = array( 'style' => 1, 'descriptor' => 2, 'official' => 3 );
    foreach ( $other['scores'] as $axis => $score ) {
        $origin = $secondary['evidence'][ $axis ]['score_origin'] ?? '';
        $previous = $primary['evidence'][ $axis ]['score_origin'] ?? '';
        if ( null === $score || ( $priority[ $origin ] ?? 0 ) <= ( $priority[ $previous ] ?? 0 ) ) { continue; }
        $profile['scores'][ $axis ] = $score;
        $profile['score_evidence'][ $axis ] = $other['score_evidence'][ $axis ];
        $used[] = $axis;
    }
    if ( $used ) {
        $source['fields'] = $used;
        $profile['sources'][] = $source;
        foreach ( $used as $key ) { $primary['evidence'][ $key ] = $secondary['evidence'][ $key ]; }
        $origins = array_column( $primary['evidence'], 'score_origin' );
        if ( $origins ) {
            $profile['score_method'] = array_diff( $origins, array( 'official' ) ) ? 'editorial' : 'official';
            $profile['score_basis'] = 'editorial' === $profile['score_method'] ? ( $profile['score_basis'] ?: $other['score_basis'] ) : '';
        }
    }
}

/** Accept only normalized documents that source discovery matched to the wine and producer. */
function adb_fill_extract( $wine, $producer_name, $vintage, $documents ) {
    $wine = sanitize_text_field( $wine );
    $producer_name = sanitize_text_field( $producer_name );
    $vintage = trim( (string) $vintage );
    $candidates = array();
    foreach ( array_slice( (array) $documents, 0, 16 ) as $doc ) {
        if ( ! is_array( $doc ) || true !== ( $doc['matched'] ?? false ) || empty( $doc['url'] ) || empty( $doc['text'] ) || empty( $doc['title'] ) ) { continue; }
        $doc['vintage'] = trim( (string) ( $doc['vintage'] ?? '' ) );
        if ( '' !== $vintage && $doc['vintage'] !== $vintage ) { continue; }
        $result = adb_fill_fact_document( $wine, $producer_name, $doc );
        if ( ! $result ) { continue; }
        $official = true === ( $doc['official'] ?? false );
        $result['rank'] = array( $official ? 1 : 0, (int) $doc['vintage'], $result['italian'] ? 1 : 0, $result['coverage'] );
        $result['producer_id'] = (int) ( $doc['producer_id'] ?? 0 );
        $result['official'] = $official;
        $candidates[] = $result;
    }
    if ( ! $candidates ) {
        return new WP_Error( 'adb_fill_no_facts', __( 'Nessuna scheda del vino contiene dati verificabili per la selezione richiesta. Puoi selezionare la scheda tecnica PDF della cantina.', 'amicidibacco' ) );
    }
    usort( $candidates, static function ( $left, $right ) { return $right['rank'] <=> $left['rank']; } );
    $best = array_shift( $candidates );
    $year = $best['tasting']['reference_vintage'];
    if ( $best['official'] && preg_match( '/^(?:19|20)\d{2}$/D', $year ) ) {
        foreach ( $candidates as $candidate ) {
            if ( $candidate['official'] && $candidate['producer_id'] === $best['producer_id'] && $candidate['tasting']['reference_vintage'] === $year &&
                count( $best['tasting']['sources'] ) < 12 ) {
                adb_fill_fact_supplement( $best, $candidate );
            }
        }
        $best['tasting'] = adb_sanitize_tasting( $best['tasting'] );
    }
    unset( $best['coverage'], $best['italian'], $best['rank'], $best['producer_id'], $best['official'] );
    return $best;
}
