<?php
/** WooCommerce administration for the pairings on an individual wine. */
defined( 'ABSPATH' ) || exit;

add_action( 'admin_menu', static function () {
    if ( ! function_exists( 'WC' ) ) { return; }
    $label = __( 'Abbinamenti', 'amicidibacco' );
    $screen = add_submenu_page( 'woocommerce', $label, $label, 'manage_woocommerce', 'adb-abbinamenti', 'adb_pair_admin_page' );
    add_action( 'admin_enqueue_scripts', static function ( $hook ) use ( $screen ) {
        if ( $hook !== $screen ) { return; }
        wp_enqueue_script( 'wc-enhanced-select' );
        wp_enqueue_style( 'woocommerce_admin_styles' );
    }, 30 );
}, 55 );

/** Use WooCommerce title/SKU search and apply the same wine scope used by the recommendations. */
add_action( 'wp_ajax_adb_pair_wine_search', static function () {
    check_ajax_referer( 'search-products', 'security' );
    if ( ! current_user_can( 'manage_woocommerce' ) ) { wp_send_json_error( null, 403 ); }
    $term = isset( $_GET['term'] ) && is_string( $_GET['term'] ) ? sanitize_text_field( wp_unslash( $_GET['term'] ) ) : '';
    if ( '' === trim( $term ) ) { wp_send_json( array() ); }
    $excluded = array_filter( (array) ( $_GET['exclude'] ?? array() ), 'is_scalar' );
    $ids = WC_Data_Store::load( 'product' )->search_products( substr( $term, 0, 200 ), '', false, false, 100, array(), wp_parse_id_list( $excluded ) );
    $result = array();
    foreach ( $ids as $id ) {
        if ( ! current_user_can( 'edit_post', $id ) || ! adb_pair_is_wine( $id ) ) { continue; }
        $product = wc_get_product( $id );
        if ( ! $product ) { continue; }
        $result[ $id ] = esc_html( wp_strip_all_tags( $product->get_formatted_name() ) );
        if ( count( $result ) >= 30 ) { break; }
    }
    wp_send_json( $result );
} );

function adb_pair_admin_select( $name, $label, $selected_ids, $exclude = 0, $multiple = false ) {
    ?>
    <p><label for="adb-<?php echo esc_attr( $name ); ?>"><strong><?php echo esc_html( $label ); ?></strong></label></p>
    <select id="adb-<?php echo esc_attr( $name ); ?>" name="<?php echo esc_attr( $name . ( $multiple ? '[]' : '' ) ); ?>"
        class="wc-product-search" style="width: min(100%, 34rem);" data-action="adb_pair_wine_search"
        data-minimum_input_length="2" data-allow_clear="true" data-exclude="<?php echo esc_attr( $exclude ); ?>"
        data-placeholder="<?php esc_attr_e( 'Cerca per nome o codice prodotto', 'amicidibacco' ); ?>" <?php echo $multiple ? 'multiple' : ''; ?>>
        <?php if ( ! $multiple ) { echo '<option value=""></option>'; } ?>
        <?php foreach ( array_filter( $selected_ids ) as $id ) :
            $product = wc_get_product( $id );
            if ( ! $product ) { continue; } ?>
            <option value="<?php echo esc_attr( $id ); ?>" selected><?php echo esc_html( wp_strip_all_tags( $product->get_formatted_name() ) ); ?></option>
        <?php endforeach; ?>
    </select>
    <?php
}

function adb_pair_admin_page() {
    if ( ! current_user_can( 'manage_woocommerce' ) ) { wp_die( esc_html__( 'Accesso negato.', 'amicidibacco' ), '', array( 'response' => 403 ) ); }
    $id = isset( $_GET['wine'] ) && is_string( $_GET['wine'] ) ? absint( $_GET['wine'] ) : 0;
    $wine = $id && current_user_can( 'edit_post', $id ) && adb_pair_is_wine( $id ) ? wc_get_product( $id ) : false;
    ?>
    <div class="wrap woocommerce">
        <h1><?php esc_html_e( 'Abbinamenti', 'amicidibacco' ); ?></h1>
        <form method="get" action="<?php echo esc_url( admin_url( 'admin.php' ) ); ?>">
            <input type="hidden" name="page" value="adb-abbinamenti">
            <?php adb_pair_admin_select( 'wine', __( 'Scheda del vino', 'amicidibacco' ), $wine ? array( $id ) : array() ); ?>
            <?php submit_button( __( 'Mostra abbinamenti', 'amicidibacco' ), 'secondary', '', false ); ?>
        </form>
        <?php if ( $id && ! $wine ) : ?>
            <p><?php esc_html_e( 'Scegli un vino disponibile nel catalogo.', 'amicidibacco' ); ?></p>
        <?php endif; ?>
        <?php if ( $wine ) :
            $recommendations = adb_pair_recommendations( $id );
            $pins = wp_parse_id_list( get_post_meta( $id, '_adb_pair_pins', true ) );
            $excludes = wp_parse_id_list( get_post_meta( $id, '_adb_pair_excludes', true ) );
            ?>
            <?php if ( isset( $_GET['saved'] ) ) : ?>
                <div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'Abbinamenti salvati.', 'amicidibacco' ); ?></p></div>
            <?php endif; ?>
            <h2><?php echo esc_html( $wine->get_name() ); ?></h2>
            <?php if ( $recommendations ) : ?>
                <table class="widefat striped"><thead><tr>
                    <th scope="col"><?php esc_html_e( 'Vino suggerito', 'amicidibacco' ); ?></th>
                    <th scope="col"><?php esc_html_e( 'Motivo', 'amicidibacco' ); ?></th>
                </tr></thead><tbody>
                <?php foreach ( $recommendations as $row ) :
                    $suggestion = wc_get_product( $row['id'] );
                    if ( ! $suggestion ) { continue; }
                    if ( 'manual' === $row['source'] ) {
                        $reason = __( 'Scelto manualmente', 'amicidibacco' );
                    } elseif ( 'orders' === $row['source'] ) {
                        $reason = sprintf( _n( 'Acquistati insieme in %s ordine', 'Acquistati insieme in %s ordini', $row['count'], 'amicidibacco' ), number_format_i18n( $row['count'] ) );
                    } else {
                        $reason = __( 'Affinità di tipologia', 'amicidibacco' );
                    } ?>
                    <tr><td><?php echo esc_html( $suggestion->get_name() ); ?></td><td><?php echo esc_html( $reason ); ?></td></tr>
                <?php endforeach; ?>
                </tbody></table>
            <?php else : ?>
                <p><?php esc_html_e( 'Al momento questo vino non ha suggerimenti disponibili.', 'amicidibacco' ); ?></p>
            <?php endif; ?>
            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                <input type="hidden" name="action" value="adb_pair_save">
                <input type="hidden" name="wine" value="<?php echo esc_attr( $id ); ?>">
                <?php wp_nonce_field( 'adb_pair_save_' . $id ); ?>
                <h2><?php esc_html_e( 'Scelte per questa scheda', 'amicidibacco' ); ?></h2>
                <p><?php esc_html_e( 'Puoi fissare fino a due vini. I posti lasciati liberi vengono assegnati automaticamente.', 'amicidibacco' ); ?></p>
                <?php
                adb_pair_admin_select( 'first', __( 'Primo vino fissato', 'amicidibacco' ), array_slice( $pins, 0, 1 ), $id );
                adb_pair_admin_select( 'second', __( 'Secondo vino fissato', 'amicidibacco' ), array_slice( $pins, 1, 1 ), $id );
                adb_pair_admin_select( 'excludes', __( 'Vini da escludere', 'amicidibacco' ), $excludes, $id, true );
                submit_button( __( 'Salva abbinamenti', 'amicidibacco' ) ); ?>
            </form>
        <?php endif; ?>
    </div>
    <?php
}

function adb_pair_admin_invalid( $message ) {
    wp_die( esc_html( $message ), '', array( 'response' => 400, 'back_link' => true ) );
}

add_action( 'admin_post_adb_pair_save', static function () {
    $id = isset( $_POST['wine'] ) && is_string( $_POST['wine'] ) ? absint( $_POST['wine'] ) : 0;
    if ( ! $id || ! current_user_can( 'manage_woocommerce' ) || ! current_user_can( 'edit_post', $id ) ) {
        wp_die( esc_html__( 'Accesso negato.', 'amicidibacco' ), '', array( 'response' => 403 ) );
    }
    check_admin_referer( 'adb_pair_save_' . $id );
    if ( ! adb_pair_is_wine( $id ) ) { adb_pair_admin_invalid( __( 'La scheda selezionata non è disponibile.', 'amicidibacco' ) ); }

    $selected = array( $_POST['first'] ?? '', $_POST['second'] ?? '' );
    $excluded = $_POST['excludes'] ?? array();
    if ( ! is_array( $excluded ) ) { adb_pair_admin_invalid( __( 'Selezione dei vini non valida.', 'amicidibacco' ) ); }
    $pins = $excludes = array();
    foreach ( array( 'pins' => $selected, 'excludes' => $excluded ) as $field => $values ) {
        $previous = wp_parse_id_list( get_post_meta( $id, '_adb_pair_' . $field, true ) );
        foreach ( $values as $value ) {
            if ( '' === $value ) { continue; }
            if ( ! is_string( $value ) || ! ctype_digit( $value ) || ! (int) $value || (int) $value === $id || ( ! in_array( (int) $value, $previous, true ) && ! adb_pair_is_wine( (int) $value ) ) ) {
                adb_pair_admin_invalid( __( 'Scegli altri vini validi del catalogo.', 'amicidibacco' ) );
            }
            if ( 'pins' === $field ) { $pins[] = (int) $value; } else { $excludes[] = (int) $value; }
        }
    }
    if ( count( $pins ) !== count( array_unique( $pins ) ) || array_intersect( $pins, $excludes ) ) {
        adb_pair_admin_invalid( __( 'Ogni vino può essere selezionato una sola volta, tra i fissati oppure tra gli esclusi.', 'amicidibacco' ) );
    }
    update_post_meta( $id, '_adb_pair_pins', $pins );
    update_post_meta( $id, '_adb_pair_excludes', array_values( array_unique( $excludes ) ) );
    do_action( 'litespeed_purge_url', get_permalink( $id ) );
    wp_safe_redirect( add_query_arg( array( 'page' => 'adb-abbinamenti', 'wine' => $id, 'saved' => 1 ), admin_url( 'admin.php' ) ) );
    exit;
} );
