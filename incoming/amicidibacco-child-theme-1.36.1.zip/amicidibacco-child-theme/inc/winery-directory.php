<?php
/** Complete winery directory from the existing producer records and linked catalog terms. */
defined( 'ABSPATH' ) || exit;

function adb_is_winery_directory() {
    if ( is_post_type_archive( 'produttore' ) ) { return true; }
    $page = get_queried_object();
    return is_page() && $page instanceof WP_Post && has_shortcode( $page->post_content, 'adb_wineries' );
}

function adb_winery_directory_data() {
    $wineries = adb_wineries( array(), -1 );
    $index = adb_shop_index();
    $names = array();
    foreach ( $index['filters'] as $def ) { $names[ $def['param'] ] = array_column( $def['terms'], 'name', 'id' ); }
    $origins = array();
    foreach ( $index['rows'] as $row ) {
        foreach ( $row['f']['adb_winery'] ?? array() as $winery_id ) {
            foreach ( array( 'adb_country', 'adb_region' ) as $key ) {
                foreach ( $row['f'][ $key ] ?? array() as $term_id ) { if ( isset( $names[ $key ][ $term_id ] ) ) { $origins[ $winery_id ][ $key ][ $term_id ] = $names[ $key ][ $term_id ]; } }
            }
        }
    }
    $cards = array(); $countries = array();
    foreach ( $wineries as $winery ) {
        $term_id = absint( get_post_meta( $winery->ID, 'cantina', true ) );
        $country = array_values( $origins[ $term_id ]['adb_country'] ?? array() );
        $regions = array_values( $origins[ $term_id ]['adb_region'] ?? array() );
        foreach ( $country as $name ) { $countries[ $name ] = $name; }
        $cards[] = array( 'post' => $winery, 'photo' => adb_valid_image_id( get_post_meta( $winery->ID, 'immagine_di_sfondo_sulla_pagina_del_produttore', true ) ), 'logo' => adb_valid_image_id( get_post_thumbnail_id( $winery->ID ) ), 'country' => $country, 'region' => $regions );
    }
    natcasesort( $countries );
    $cover = 0; $cover_name = ''; $cover_url = '';
    $pinned = array_map( 'absint', (array) adb_home( 'winery_ids', array() ) );
    $candidates = $cards;
    usort( $candidates, static function ( $a, $b ) use ( $pinned ) {
        $a_rank = array_search( $a['post']->ID, $pinned, true ); $b_rank = array_search( $b['post']->ID, $pinned, true );
        return ( false === $a_rank ? PHP_INT_MAX : $a_rank ) <=> ( false === $b_rank ? PHP_INT_MAX : $b_rank );
    } );
    foreach ( $candidates as $card ) {
        $meta = $card['photo'] ? wp_get_attachment_metadata( $card['photo'] ) : array();
        if ( ( $meta['width'] ?? 0 ) > ( $meta['height'] ?? 1 ) * 1.35 ) { $cover = $card['photo']; $cover_name = $card['post']->post_title; $cover_url = get_permalink( $card['post'] ); break; }
    }
    return array( 'cards' => $cards, 'countries' => $countries, 'cover' => $cover, 'cover_name' => $cover_name, 'cover_url' => $cover_url );
}

function adb_render_winery_directory() {
    $data = adb_winery_directory_data();
    $title = is_page() ? get_the_title( get_queried_object_id() ) : post_type_archive_title( '', false );
    $intro = is_page() ? get_the_excerpt( get_queried_object_id() ) : '';
    $intro = $intro ?: adb_home( 'winery_text' );
    $strings = array( 'count' => __( '%d cantine da scoprire', 'amicidibacco' ), 'one' => __( '1 cantina da scoprire', 'amicidibacco' ), 'empty' => __( 'Nessuna cantina corrisponde. Prova un altro nome o rimuovi la ricerca.', 'amicidibacco' ) );
    ob_start(); ?>
    <div class="adb-cellars" data-cellars>
        <header class="adb-cellars-hero<?php echo $data['cover'] ? '' : ' adb-cellars-hero--plain'; ?>">
            <?php if ( $data['cover'] ) { echo wp_get_attachment_image( $data['cover'], 'full', false, array( 'data-adb-webp' => true, 'class' => 'adb-cellars-hero__photo', 'loading' => 'eager', 'fetchpriority' => 'high', 'decoding' => 'async', 'sizes' => '100vw', 'alt' => '', 'aria-hidden' => 'true' ) ); } ?>
            <div class="adb-wrap adb-cellars-hero__body"><h1><?php echo esc_html( $title ); ?></h1><?php if ( $intro ) : ?><p><?php echo esc_html( $intro ); ?></p><?php endif; ?><a class="adb-link" href="#adb-cellars-directory"><?php esc_html_e( 'Esplora le cantine', 'amicidibacco' ); ?><?php echo adb_icon( 'down' ); ?></a></div>
            <?php if ( $data['cover_name'] ) : ?><div class="adb-wrap adb-cellars-hero__caption"><a href="<?php echo esc_url( $data['cover_url'] ); ?>"><?php echo esc_html( $data['cover_name'] ); ?><?php echo adb_icon(); ?></a></div><?php endif; ?>
        </header>
        <section id="adb-cellars-directory" class="adb-wrap adb-cellars-directory" aria-labelledby="adb-cellars-title">
            <div class="adb-cellars-directory__heading"><h2 id="adb-cellars-title"><?php echo esc_html( adb_home( 'winery_title' ) ?: __( 'Tutte le cantine', 'amicidibacco' ) ); ?></h2><div class="adb-cellars-search" data-cellars-search hidden><label class="screen-reader-text" for="adb-cellar-search"><?php esc_html_e( 'Cerca una cantina o un territorio', 'amicidibacco' ); ?></label><?php echo adb_icon( 'search' ); ?><input id="adb-cellar-search" type="search" placeholder="<?php esc_attr_e( 'Cerca una cantina o un territorio', 'amicidibacco' ); ?>" autocomplete="off"><button type="button" aria-label="<?php esc_attr_e( 'Cancella ricerca', 'amicidibacco' ); ?>" data-cellars-clear hidden><?php echo adb_icon( 'close' ); ?></button></div></div>
            <div class="adb-cellars-toolbar"><div class="adb-cellars-countries" role="group" aria-label="<?php esc_attr_e( 'Provenienza delle cantine', 'amicidibacco' ); ?>" data-cellars-countries hidden><button type="button" data-country="" aria-pressed="true"><?php esc_html_e( 'Tutte', 'amicidibacco' ); ?></button><?php foreach ( $data['countries'] as $country ) : ?><button type="button" data-country="<?php echo esc_attr( $country ); ?>" aria-pressed="false"><?php echo esc_html( $country ); ?></button><?php endforeach; ?></div><p role="status" aria-live="polite" data-cellars-count><?php echo esc_html( sprintf( 1 === count( $data['cards'] ) ? $strings['one'] : $strings['count'], count( $data['cards'] ) ) ); ?></p></div>
            <div class="adb-cellars-grid">
                <?php foreach ( $data['cards'] as $card ) : $winery = $card['post']; $geography = implode( ' · ', array_unique( array_merge( $card['region'], $card['country'] ) ) ); $frame = adb_cellar_framing( $card['photo'] ); $excerpt = $winery->post_excerpt ?: wp_trim_words( html_entity_decode( wp_strip_all_tags( strip_shortcodes( $winery->post_content ) ), ENT_QUOTES, 'UTF-8' ), 23 ); ?>
                <article class="adb-cellar<?php echo $frame['panorama'] ? ' adb-cellar--panorama' : ''; ?>" style="<?php echo esc_attr( adb_cellar_frame_style( $card['photo'] ) ); ?>" data-cellar data-country="<?php echo esc_attr( wp_json_encode( $card['country'] ) ); ?>" data-search="<?php echo esc_attr( $winery->post_title . ' ' . $geography ); ?>">
                    <a href="<?php echo esc_url( get_permalink( $winery ) ); ?>" aria-labelledby="adb-cellar-<?php echo esc_attr( $winery->ID ); ?>">
                        <figure class="adb-cellar__photo<?php echo $card['photo'] ? '' : ' adb-cellar__photo--logo'; ?>"><?php if ( $card['photo'] ) { echo wp_get_attachment_image( $card['photo'], 'large', false, array( 'data-adb-webp' => true, 'class' => 'adb-cellar__image', 'loading' => 'lazy', 'decoding' => 'async', 'sizes' => adb_cellar_photo_sizes( $card['photo'] ), 'alt' => '', 'aria-hidden' => 'true' ) ); } elseif ( $card['logo'] ) { echo wp_get_attachment_image( $card['logo'], 'medium', false, array( 'loading' => 'lazy', 'alt' => '', 'aria-hidden' => 'true' ) ); } ?></figure>
                        <div class="adb-cellar__identity"><div><?php if ( $geography ) : ?><p class="adb-cellar__origin"><?php echo esc_html( $geography ); ?></p><?php endif; ?><h3 id="adb-cellar-<?php echo esc_attr( $winery->ID ); ?>"><?php echo esc_html( $winery->post_title ); ?></h3></div><?php if ( $card['logo'] && $card['photo'] ) { echo wp_get_attachment_image( $card['logo'], 'medium', false, array( 'class' => 'adb-cellar__logo', 'loading' => 'lazy', 'sizes' => '(max-width:650px) 128px, 148px', 'alt' => '', 'aria-hidden' => 'true' ) ); } ?></div>
                        <?php if ( $excerpt ) : ?><p class="adb-cellar__excerpt"><?php echo esc_html( $excerpt ); ?></p><?php endif; ?><span class="adb-cellar__read"><?php esc_html_e( 'Il racconto', 'amicidibacco' ); ?><?php echo adb_icon(); ?></span>
                    </a>
                </article>
                <?php endforeach; ?>
            </div><p class="adb-cellars-empty" data-cellars-empty hidden><?php echo esc_html( $strings['empty'] ); ?></p>
        </section>
        <script type="application/json" data-cellars-strings><?php echo wp_json_encode( $strings, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT ); ?></script>
    </div>
    <?php return ob_get_clean();
}
