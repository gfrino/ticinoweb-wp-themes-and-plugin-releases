<?php
/** Shop navigation and the compact discovery shelf. */
defined( 'ABSPATH' ) || exit;

function adb_menu_wine_card( $wine ) {
    $winery   = adb_card_winery( $wine );
    $name     = $wine->get_attribute( 'pa_cantina' ) ?: ( $winery ? get_the_title( $winery ) : '' );
    $logo_id  = $winery ? get_post_thumbnail_id( $winery->ID ) : 0;
    $grapes   = wp_strip_all_tags( adb_product_editorial_field( $wine->get_id(), 'vitigno' ), true );
    ?>
    <a class="adb-mega__wine" href="<?php echo esc_url( $wine->get_permalink() ); ?>">
        <span class="adb-mega__portrait" aria-hidden="true">
            <span class="adb-mega__packshot"><?php echo wp_get_attachment_image( $wine->get_image_id(), 'medium', false, array( 'alt' => '', 'sizes' => '100px', 'decoding' => 'async', 'loading' => 'lazy', 'data-adb-webp' => true ) ); ?></span>
            <?php if ( $logo_id ) : ?>
                <span class="adb-mega__signature"><?php echo wp_get_attachment_image( $logo_id, 'medium', false, array( 'class' => 'adb-mega__logo', 'alt' => '', 'sizes' => '100px', 'decoding' => 'async', 'loading' => 'lazy' ) ); ?></span>
            <?php endif; ?>
        </span>
        <span class="adb-mega__details">
            <?php if ( $name ) : ?><span class="adb-mega__winery"><?php echo esc_html( $name ); ?></span><?php endif; ?>
            <span class="adb-mega__name"><?php echo esc_html( $wine->get_name() ); ?></span>
            <?php if ( $grapes ) : ?><span class="adb-mega__grapes"><span class="screen-reader-text"><?php esc_html_e( 'Vitigno', 'amicidibacco' ); ?> </span><?php echo esc_html( $grapes ); ?></span><?php endif; ?>
            <span class="adb-mega__foot"><span class="adb-mega__price"><?php echo wp_kses_post( $wine->get_price_html() . adb_price_details( $wine, false ) ); ?></span><?php echo adb_icon(); ?></span>
        </span>
    </a>
    <?php
}

// Cache only candidate IDs. Stock, price and visibility come from the current products.
function adb_menu_wines() {
    $key = 'adb_menu_pool_' . md5( determine_locale() );
    $ids = get_transient( $key );
    if ( false === $ids ) {
        $ids = array_map( static function ( $wine ) { return $wine->get_id(); }, adb_hero_wine_pool( (array) adb_home( 'selection_ids', array() ) ) );
        set_transient( $key, $ids, 20 * MINUTE_IN_SECONDS );
    }
    $eligible = array();
    foreach ( $ids ? adb_products( array( 'ids' => $ids, 'limit' => count( $ids ) ) ) : array() as $wine ) {
        if ( adb_hero_wine_eligible( $wine ) && $wine->is_purchasable() && ! post_password_required( $wine->get_id() ) ) {
            $eligible[] = $wine;
        }
    }
    adb_home_wine_template( $eligible, 'adb_menu_wine_card' );
}

add_action( 'wc_ajax_adb_menu_wines', function () {
    ob_start();
    adb_menu_wines();
    wp_send_json_success( ob_get_clean() );
} );

function adb_wine_menu_template() {
    if ( ! class_exists( 'WC_AJAX' ) ) { return; }
    ?>
    <template data-wine-menu data-catalog="<?php echo esc_url( adb_catalog_url() ); ?>" data-endpoint="<?php echo esc_url( WC_AJAX::get_endpoint( 'adb_menu_wines' ) ); ?>">
        <div class="adb-mega"><div class="adb-mega__inner">
            <div class="adb-mega__browse">
                <p class="adb-mega__heading"><?php esc_html_e( 'Esplora i vini', 'amicidibacco' ); ?></p>
                <div data-menu-categories></div>
            </div>
            <div class="adb-mega__discover">
                <p class="adb-mega__heading"><?php esc_html_e( 'Da scoprire', 'amicidibacco' ); ?></p>
                <div class="adb-mega__picks" aria-busy="true"></div>
            </div>
        </div></div>
    </template>
    <?php
}
