<?php
/** Look up wine documents on the selected winery's official site or in the local Media Library. */
defined( 'ABSPATH' ) || exit;

function adb_fill_official_host( $url ) {
    if ( ! is_string( $url ) || strlen( $url ) > 2000 || preg_match( '/[\x00-\x20\\\\]/', $url ) ) { return ''; }
    $parts = wp_parse_url( $url );
    if ( ! is_array( $parts ) || ! in_array( strtolower( $parts['scheme'] ?? '' ), array( 'https', 'http' ), true )
        || isset( $parts['user'] ) || isset( $parts['pass'] ) || isset( $parts['port'] ) ) { return ''; }
    $host = strtolower( $parts['host'] ?? '' );
    if ( ! preg_match( '/^(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z]{2,63}$/D', $host )
        || preg_match( '/\.(?:local|localhost|internal|invalid|test|onion)$/', $host ) ) { return ''; }
    return preg_replace( '/^www\./', '', $host );
}

add_action( 'add_meta_boxes_produttore', static function () {
    add_meta_box( 'adb-official-website', __( 'Sito ufficiale della cantina', 'amicidibacco' ), static function ( $post ) {
        wp_nonce_field( 'adb_fill_winery_site', 'adb_fill_winery_nonce' );
        echo '<label for="adb-official-url">' . esc_html__( 'Indirizzo del produttore', 'amicidibacco' ) . '</label>';
        echo '<input class="widefat" type="url" id="adb-official-url" name="adb_official_website" value="' . esc_attr( get_post_meta( $post->ID, '_adb_official_website', true ) ) . '" placeholder="https://">';
        echo '<p class="description">' . esc_html__( 'Usato per cercare le schede dei vini di questa cantina.', 'amicidibacco' ) . '</p>';
    }, 'produttore', 'side' );
} );

add_action( 'save_post_produttore', static function ( $id ) {
    if ( wp_is_post_revision( $id ) || wp_is_post_autosave( $id ) || ! current_user_can( 'edit_post', $id )
        || ! is_string( $_POST['adb_fill_winery_nonce'] ?? null ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['adb_fill_winery_nonce'] ) ), 'adb_fill_winery_site' )
        || ! is_string( $_POST['adb_official_website'] ?? null ) ) { return; }
    $url = trim( wp_unslash( $_POST['adb_official_website'] ) );
    if ( '' === $url ) { delete_post_meta( $id, '_adb_official_website' ); }
    elseif ( adb_fill_official_host( $url ) ) { update_post_meta( $id, '_adb_official_website', esc_url_raw( $url ) ); }
} );

function adb_fill_source_words( $text ) {
    $text = mb_strtolower( remove_accents( html_entity_decode( (string) $text, ENT_QUOTES | ENT_HTML5, 'UTF-8' ) ) );
    $text = preg_replace( '/\bd\W*o\W*c(?:\W*g)?\b|\bi\W*g\W*[tp]\b|\b(?:19|20)\d{2}\b/u', ' ', $text );
    return trim( preg_replace( '/[^\p{L}\p{N}]+/u', ' ', $text ) );
}

function adb_fill_source_tokens( $text ) {
    return array_values( array_diff( array_unique( explode( ' ', adb_fill_source_words( $text ) ) ), array( '', 'di', 'del', 'della', 'de', 'du', 'il', 'la', 'le', 'da', 'd', 'l', 'vino', 'wine' ) ) );
}

/** Match the complete identity against one document heading, keeping differentiating cuvée/style qualifiers. */
function adb_fill_source_identity( $name, $heading, $intro = '', $producer = '' ) {
    $wanted = adb_fill_source_tokens( $name );
    $found = adb_fill_source_tokens( $heading );
    if ( ! $wanted || ! $found ) { return false; }
    $styles = array( 'riserva', 'reserve', 'superiore', 'classico', 'classica', 'gran', 'grande', 'cru', 'bianco', 'rosso', 'rose', 'rosato', 'brut', 'extra', 'dry', 'pas', 'dose', 'dosaggio', 'zero', 'saten', 'passito', 'ripasso', 'appassimento', 'barricato', 'millesimato' );
    if ( array_diff( array_intersect( $found, $styles ), $wanted ) ) { return false; }
    if ( ! array_diff( $wanted, $found ) ) {
        $boilerplate = array_merge( adb_fill_source_tokens( $producer ), array( 'cantina', 'cantine', 'winery', 'scheda', 'tecnica', 'technical', 'sheet', 'fiche', 'technique', 'annata', 'vintage' ) );
        if ( ! array_diff( $found, $wanted, $boilerplate ) ) { return true; }
        // A winery may prefix the cuvée with its appellation (e.g. Monferrato DOC Chiaretto Tinetta).
        // Only strip a marked appellation. A different cuvée or style must still fail the match.
        if ( preg_match( '/^.{1,85}?\b(?:D\.?O\.?C(?:\.?G)?|I\.?G\.?[TP]|A\.?O\.?[CP])\.?\s+(.+)$/iu', $heading, $parts ) ) {
            $label = array_values( array_diff( adb_fill_source_tokens( $parts[1] ), $boilerplate, array( 'chiaretto' ) ) );
            if ( $label && ! array_diff( $label, $wanted ) && ! array_diff( $wanted, $label ) ) { return true; }
        }
        return false;
    }
    // Catalog names often include a DOC or grape in addition to a quoted cuvée.
    if ( preg_match( '/["“«]([^"”»]+)["”»]/u', $name, $match ) ) {
        $cuvee = adb_fill_source_tokens( $match[1] );
        return $cuvee && ! array_diff( $cuvee, $found ) && ! array_diff( $wanted, array_merge( $found, adb_fill_source_tokens( $intro ) ) );
    }
    return false;
}

function adb_fill_source_year( $heading, $text, $requested ) {
    preg_match_all( '/\b((?:19|20)\d{2})\b/u', $heading, $in_heading );
    preg_match_all( '/\b(?:annata|vintage|mill[eé]sime|jahrgang|a[ñn]ada|vendemmia)\s*[:\-]?\s*((?:19|20)\d{2})\b/iu', $text, $labelled );
    $years = array_unique( array_merge( $in_heading[1], $labelled[1] ) );
    if ( count( $years ) > 1 ) { return false; }
    $year = $years ? (string) reset( $years ) : '';
    return '' !== $requested && $year !== $requested ? false : $year;
}

/** Only catalog evidence already labelled by an editor as official and product-specific can seed a crawl. */
function adb_fill_source_seeds( $name, $producer_id, $vintage ) {
    $site = (string) get_post_meta( $producer_id, '_adb_official_website', true );
    $host = adb_fill_official_host( $site );
    $term = absint( get_post_meta( $producer_id, 'cantina', true ) );
    $ids = $term ? get_posts( array(
        'post_type' => 'product', 'post_status' => 'publish', 'posts_per_page' => 250, 'fields' => 'ids',
        'has_password' => false, 'meta_key' => '_adb_tasting',
        'tax_query' => array( array( 'taxonomy' => 'pa_cantina', 'field' => 'term_id', 'terms' => $term ) ),
    ) ) : array();
    $hosts = array();
    $direct = array();
    foreach ( $ids as $id ) {
        $raw = get_post_meta( $id, '_adb_tasting', true );
        if ( ! is_array( $raw ) || 'official_product' !== ( $raw['verification'] ?? '' ) ) { continue; }
        $winery = get_the_title( $producer_id );
        $catalog_match = adb_fill_source_identity( $name, get_the_title( $id ), '', $winery ) || adb_fill_source_identity( $name, get_post_meta( $id, 'etichetta', true ), '', $winery );
        foreach ( (array) ( $raw['sources'] ?? array() ) as $item ) {
            if ( ! is_array( $item ) || 'product' !== ( $item['scope'] ?? '' ) ) { continue; }
            $url = $item['url'] ?? '';
            $candidate = adb_fill_official_host( $url );
            if ( ! $candidate || adb_fill_official_host( home_url() ) === $candidate ) { continue; }
            $hosts[ $candidate ] = wp_parse_url( $url, PHP_URL_SCHEME ) . '://' . wp_parse_url( $url, PHP_URL_HOST ) . '/';
            if ( $catalog_match && ( ! $vintage || empty( $item['vintage'] ) || (string) $item['vintage'] === $vintage ) ) { $direct[] = $url; }
        }
    }
    if ( ! $host && $direct ) { $host = adb_fill_official_host( $direct[0] ); $site = $hosts[ $host ]; }
    if ( ! $host && count( $hosts ) === 1 ) { $host = key( $hosts ); $site = reset( $hosts ); }
    if ( ! $host ) { return new WP_Error( 'adb_missing_winery_site', __( 'Inserisci il sito ufficiale nella scheda della cantina oppure seleziona il PDF ufficiale dalla Libreria media.', 'amicidibacco' ) ); }
    return array( $host, $site, array_unique( $direct ) );
}

function adb_fill_source_link( $href, $base, $host ) {
    $href = trim( (string) $href );
    if ( '' === $href || '#' === $href[0] || strlen( $href ) > 2000 ) { return ''; }
    $url = explode( '#', WP_Http::make_absolute_url( $href, $base ), 2 )[0];
    if ( $host !== adb_fill_official_host( $url ) ) { return ''; }
    $parts = wp_parse_url( $url );
    $path = rawurldecode( $parts['path'] ?? '' );
    if ( preg_match( '~/(?:wp-admin|wp-login|wp-json|checkout|cart|carrello|account|logout|login|feed|wp-cron)(?:[./]|$)|\.(?:jpe?g|png|gif|webp|heic|avif|svg|ico|zip|mp[34]|webm|js|css|json)$~i', $path ) ) { return ''; }
    if ( isset( $parts['query'] ) ) {
        parse_str( $parts['query'], $params );
        if ( array_diff( array_keys( $params ), array( 's', 'q', 'p', 'page_id', 'lang', 'wineyear', 'vintage', 'annata', 'year' ) ) ) { return ''; }
    }
    return $url;
}

/** Never delegate redirects to the HTTP transport: validate each destination against the winery allowlist. */
function adb_fill_source_fetch( $url, $host, $deadline, &$remaining ) {
    for ( $redirect = 0; $redirect < 3 && $remaining > 0 && microtime( true ) < $deadline; $redirect++ ) {
        --$remaining;
        if ( $host !== adb_fill_official_host( $url ) ) { return null; }
        $response = wp_safe_remote_get( $url, array(
            'timeout' => min( 4, max( 0.5, $deadline - microtime( true ) ) ), 'redirection' => 0,
            'limit_response_size' => 4 * MB_IN_BYTES + 1, 'headers' => array( 'Accept' => 'text/html,application/pdf,application/xml,text/xml;q=0.9', 'Accept-Language' => 'it,en;q=0.6' ),
        ) );
        if ( is_wp_error( $response ) ) { return null; }
        $code = wp_remote_retrieve_response_code( $response );
        if ( in_array( $code, array( 301, 302, 303, 307, 308 ), true ) ) {
            $url = adb_fill_source_link( wp_remote_retrieve_header( $response, 'location' ), $url, $host );
            if ( ! $url ) { return null; }
            continue;
        }
        $body = wp_remote_retrieve_body( $response );
        if ( 200 !== $code || '' === $body || strlen( $body ) > 4 * MB_IN_BYTES ) { return null; }
        return array( $url, $body, strtolower( (string) wp_remote_retrieve_header( $response, 'content-type' ) ) );
    }
    return null;
}

function adb_fill_source_pdf( $path, $url, $name, $producer, $requested, $manual ) {
    $text = function_exists( 'adb_fill_pdf_text' ) ? adb_fill_pdf_text( $path ) : '';
    if ( ! is_string( $text ) || mb_strlen( trim( $text ) ) < 50 ) { return new WP_Error( 'adb_pdf_text', __( 'Il PDF non contiene testo leggibile. Seleziona una scheda tecnica con testo selezionabile.', 'amicidibacco' ) ); }
    $text = trim( mb_substr( $text, 0, 24000 ) );
    $lines = preg_split( '/\R+/u', $text, 0, PREG_SPLIT_NO_EMPTY );
    $intro = mb_substr( implode( ' ', array_slice( $lines, 0, 14 ) ), 0, 750 );
    $producer_words = array_diff( adb_fill_source_tokens( $producer->post_title ), array( 'azienda', 'agricola', 'tenuta', 'cantina', 'cantine', 'domaine', 'chateau', 'winery', 'sa', 'srl' ) );
    if ( $manual && ( ! $producer_words || array_diff( $producer_words, adb_fill_source_tokens( $text ) ) ) ) {
        return new WP_Error( 'adb_pdf_producer', __( 'Nel PDF non compare il nome della cantina selezionata.', 'amicidibacco' ) );
    }
    $heading = '';
    foreach ( array_slice( $lines, 0, 10 ) as $index => $line ) {
        $line = trim( $line );
        if ( mb_strlen( $line ) > 180 ) { continue; }
        if ( adb_fill_source_identity( $name, $line, $intro, $producer->post_title ) ) { $heading = $line; break; }
        $pair = $line . ' ' . trim( $lines[ $index + 1 ] ?? '' );
        if ( mb_strlen( $pair ) < 150 && adb_fill_source_identity( $name, $pair, $intro, $producer->post_title ) ) { $heading = $pair; break; }
    }
    $year = adb_fill_source_year( $heading, $text, $requested );
    if ( '' === $heading || false === $year ) { return new WP_Error( 'adb_pdf_identity', __( 'Nome del vino o annata non confermati nel PDF selezionato.', 'amicidibacco' ) ); }
    return array( 'url' => $url, 'title' => $heading, 'text' => $text, 'official' => ! $manual, 'matched' => true, 'producer_id' => $producer->ID, 'producer' => $producer->post_title, 'vintage' => $year, 'lang' => adb_fill_source_locale( $url, $text ) );
}

function adb_fill_source_media( $id, $name, $producer, $vintage, $draft_id = 0 ) {
    $post = get_post( $id );
    $parent = $post && $post->post_parent ? get_post( $post->post_parent ) : null;
    $own_draft = $parent && (int) $parent->ID === absint( $draft_id ) && 'product' === $parent->post_type
        && in_array( $parent->post_status, array( 'auto-draft', 'draft' ), true ) && '' === $parent->post_password
        && 'inherit' === $post->post_status && current_user_can( 'edit_post', $parent->ID );
    $public = $post && 'publish' === get_post_status( $post ) && ( ! $parent || ( '' === $parent->post_password && is_post_publicly_viewable( $parent ) ) );
    $file = $post ? realpath( (string) get_attached_file( $id ) ) : false;
    $uploads = wp_get_upload_dir();
    $dir = realpath( $uploads['basedir'] );
    $url = wp_get_attachment_url( $id );
    if ( ! $post || 'attachment' !== $post->post_type || 'application/pdf' !== $post->post_mime_type
        || ( ! $own_draft && ! $public ) || $post->post_password
        || ! current_user_can( 'read_post', $id ) || ! $file || ! $dir || 0 !== strpos( $file, trailingslashit( $dir ) ) || ! $url
        || ! is_file( $file ) || ! is_readable( $file ) || filesize( $file ) > 4 * MB_IN_BYTES || '%PDF-' !== file_get_contents( $file, false, null, 0, 5 ) ) {
        return new WP_Error( 'adb_pdf_unavailable', __( 'Seleziona un PDF pubblico o caricato in questa bozza, leggibile e di dimensione massima 4 MB.', 'amicidibacco' ) );
    }
    $doc = adb_fill_source_pdf( $file, $url, $name, $producer, $vintage, true );
    return is_wp_error( $doc ) ? $doc : array( $doc );
}

/** Parse navigation for discovery, then isolate the wine page before reading any tasting data. */
function adb_fill_source_html( $body, $name = '', $producer = '', $vintage = '' ) {
    if ( ! class_exists( 'DOMDocument' ) ) { return null; }
    $dom = new DOMDocument();
    if ( ! @$dom->loadHTML( '<?xml encoding="UTF-8">' . $body, LIBXML_NONET | LIBXML_NOERROR | LIBXML_NOWARNING ) ) { return null; }
    $xpath = new DOMXPath( $dom );
    $links = array();
    foreach ( $xpath->query( '//a[@href]' ) as $anchor ) {
        $href = $anchor->getAttribute( 'href' );
        if ( ! isset( $links[ $href ] ) || '' === $links[ $href ] ) {
            $links[ $href ] = trim( mb_substr( $anchor->textContent, 0, 160 ) );
        }
        if ( count( $links ) >= 600 ) { break; }
    }
    $lang = strtolower( (string) $xpath->evaluate( 'string(/html/@lang)' ) );
    $page_title = trim( (string) $xpath->evaluate( 'string(//title[1])' ) );
    $unwanted = '//script|//style|//noscript|//nav|//header[not(ancestor::article or ancestor::main) and not(.//h1)]|//footer|//aside|//form|//button|//template|//iframe|//select|//svg|//*[@hidden or @role="navigation" or @role="dialog"]';
    // Remove groups of recommendations/cross-sells, including grids of unrelated bottles.
    foreach ( array( 'related', 'upsell', 'cross-sell', 'recommendation', 'cookie', 'breadcrumb', 'site-header', 'site-footer', 'newsletter', 'product-grid', 'recently-viewed', 'social-share', 'elementor-menu', 'menu-item', 'vintage-selector', 'annate-disponibili' ) as $class ) {
        $unwanted .= '|//*[not(self::html or self::body or self::main or self::article) and contains(translate(@class,"ABCDEFGHIJKLMNOPQRSTUVWXYZ","abcdefghijklmnopqrstuvwxyz"),"' . $class . '")]';
    }
    foreach ( $xpath->query( $unwanted ) as $node ) {
        if ( $node->parentNode ) { $node->parentNode->removeChild( $node ); }
    }
    $scope = $xpath->query( '(//main|//*[@role="main"])[1]' )->item( 0 ) ?: $xpath->query( '//body' )->item( 0 );
    if ( ! $scope ) { return null; }
    $headings = array();
    foreach ( $xpath->query( './/h1', $scope ) as $node ) {
        $label = trim( preg_replace( '/\s+/u', ' ', $node->textContent ) );
        if ( $label ) { $headings[] = $label; }
    }
    // Some stores put the product H1 in a page banner just outside the content root.
    if ( ! $headings ) {
        $value = trim( (string) $xpath->evaluate( 'string(//h1[1])' ) );
        if ( $value ) { $headings[] = $value; }
    }
    $headings = array_unique( $headings );
    $archive = count( $headings ) > 1 || $xpath->query( '//*[contains(concat(" ", normalize-space(@class), " "), " products ")]//li[2]' )->length > 0;
    $title = trim( preg_split( '/\s+[|–—]\s+|\s+\|\s*/u', $page_title )[0] );
    if ( ! $headings && $title ) { $headings[] = $title; }
    $text = adb_fill_source_html_text( $dom->saveHTML( $scope ) );
    $sections = array();
    foreach ( $xpath->query( './/h2', $scope ) as $heading ) {
        $label = trim( preg_replace( '/\s+/u', ' ', $heading->textContent ) );
        if ( ! adb_fill_source_identity( $name, $label, '', $producer ) ) { continue; }
        // A collection may publish self-contained technical cards. Only read a subtree with
        // exactly one wine heading and explicit data. Adjacent sibling cards are never joined.
        $card = $heading->parentNode;
        for ( $level = 0; $level < 3 && $card instanceof DOMElement && $card !== $scope; $level++, $card = $card->parentNode ) {
            if ( 1 !== $xpath->query( './/h1|.//h2', $card )->length ) { break; }
            $excerpt = adb_fill_source_html_text( $dom->saveHTML( $card ) );
            if ( mb_strlen( $excerpt ) < 85 || ! preg_match( '/\b(?:uve|vitigno|uvaggio|vinificazione|affinamento|denominazione|grapes?|vinification|assemblage|rebsorte)\b/iu', $excerpt ) ) { continue; }
            $sections[] = array( 'title' => $label, 'text' => $excerpt, 'images' => adb_fill_bottle_candidates( $xpath, $card, $name, $label, $producer, $vintage ) );
            break;
        }
    }
    $heading = reset( $headings );
    $images = ! $archive && $heading && adb_fill_source_identity( $name, $heading, mb_substr( $text, 0, 1000 ), $producer )
        ? adb_fill_bottle_candidates( $xpath, $scope, $name, $heading, $producer, $vintage ) : array();
    return array( 'images' => $images, 'headings' => $headings, 'sections' => $sections, 'archive' => $archive, 'text' => mb_substr( $text, 0, 24000 ), 'links' => $links, 'lang' => sanitize_key( substr( $lang, 0, 12 ) ) );
}

function adb_fill_source_html_text( $markup ) {
    $markup = preg_replace( '~<(?:br\b[^>]*|/(?:p|div|section|article|h[1-6]|tr|td|th|dt|dd|li|ul|ol|strong|b|label|dl|blockquote))>~i', "\n", $markup );
    $text = html_entity_decode( wp_strip_all_tags( $markup ), ENT_QUOTES | ENT_HTML5, 'UTF-8' );
    $text = trim( preg_replace( '/ *\n(?:[ \t]*\n)* */u', "\n", preg_replace( '/[^\S\r\n]+/u', ' ', $text ) ) );
    // Some themes lack semantic containers for the recommended products.
    $text = preg_split( '/\n(?:prodotti correlati|vini correlati|potrebbe piacerti anche|related products|you may also like|produits similaires|ähnliche produkte)\s*(?:\n|$)/iu', $text, 2 )[0];
    return trim( mb_substr( $text, 0, 24000 ) );
}

function adb_fill_source_locale( $url, $text = '' ) {
    $path = (string) wp_parse_url( $url, PHP_URL_PATH );
    if ( preg_match( '~(?:^|[/_.-])(?:it|ita|italiano)(?:[/_.-]|$)~i', $path ) ) { return 'it'; }
    if ( preg_match( '~(?:^|[/_.-])(?:en|eng|english)(?:[/_.-]|$)~i', $path ) ) { return 'en'; }
    return preg_match( '/\b(?:vinificazione|abbinamenti|affinamento|denominazione|vitigno|uve)\b/iu', $text ) ? 'it' : '';
}

/** Rank likely wine links above site search and general catalog navigation. */
function adb_fill_source_priority( $url, $label, $name, $vintage, $is_wine_page ) {
    $path = rawurldecode( (string) wp_parse_url( $url, PHP_URL_PATH ) );
    $wanted = adb_fill_source_tokens( $name );
    $available = adb_fill_source_tokens( $path . ' ' . $label );
    $overlap = count( array_intersect( $wanted, $available ) );
    $pdf = (bool) preg_match( '/\.pdf$/i', $path );
    $year = preg_match( '/(?<!\d)((?:19|20)\d{2})(?!\d)/', $label . ' ' . basename( $path ) . ' ' . wp_parse_url( $url, PHP_URL_QUERY ), $years ) ? $years[1] : '';
    $preferred = $year && ( ! $vintage || $year === $vintage ) ? (int) $year / 100 : 0;
    if ( $is_wine_page && $pdf ) { return 180 + $preferred; }
    if ( $is_wine_page && $year && ( ! $vintage || $year === $vintage ) ) { return 140 + $preferred; }
    if ( $overlap ) {
        $all = $overlap === count( $wanted );
        return ( $all ? 110 : 42 ) + $preferred + $overlap + ( $all && $pdf ? 6 : 0 ) + ( $vintage && str_contains( $url . ' ' . $label, $vintage ) ? 8 : 0 );
    }
    if ( preg_match( '~(?:^|/)(?:i-nostri-vini|nostri-vini|vini|vins|wines?(?:-\d+)?|weine|products|prodotti|shop|catalogo|collections)(?:/|$)~i', $path ) ) {
        // Visit the index, not every unrelated product in a category.
        $last = basename( trim( $path, '/' ) );
        return preg_match( '/^(?:i-nostri-vini|nostri-vini|vini|vins|wines?(?:-\d+)?|weine|products|prodotti|shop|catalogo|collections)$/i', $last ) ? 38 : 0;
    }
    return 0;
}

/** Sitemap links are discovery hints only. Never use XML/search/catalog excerpts as wine documents. */
function adb_fill_source_sitemap( $xml, $base, $host, $name, $vintage, &$queue ) {
    if ( ! class_exists( 'DOMDocument' ) || stripos( $xml, '<!DOCTYPE' ) !== false ) { return; }
    $dom = new DOMDocument();
    if ( ! @$dom->loadXML( $xml, LIBXML_NONET | LIBXML_NOERROR | LIBXML_NOWARNING ) || ! $dom->documentElement ) { return; }
    $index = 'sitemapindex' === $dom->documentElement->localName;
    if ( ! $index && 'urlset' !== $dom->documentElement->localName ) { return; }
    $xpath = new DOMXPath( $dom );
    foreach ( $xpath->query( '/*/*/*[local-name()="loc"]' ) as $node ) {
        $url = adb_fill_source_link( $node->textContent, $base, $host );
        if ( ! $url ) { continue; }
        if ( $index ) {
            $priority = preg_match( '~(?:product|vino|vini|wine|page|pages|post-type-(?:page|post))~i', (string) wp_parse_url( $url, PHP_URL_PATH ) ) ? 76 : 29;
        } else {
            $priority = adb_fill_source_priority( $url, '', $name, $vintage, false );
        }
        if ( $priority ) { $queue[ $url ] = max( $queue[ $url ] ?? 0, $priority ); }
        if ( count( $queue ) >= 150 ) { break; }
    }
}

/** Fetch verifiable, product-specific evidence for the selected wine and producer. */
function adb_fill_sources( $wine_name, $producer_id, $vintage = '', $pdf_id = 0, $draft_id = 0 ) {
    $producer = get_post( absint( $producer_id ) );
    $name = trim( sanitize_text_field( (string) $wine_name ) );
    $vintage = trim( (string) $vintage );
    if ( ! $producer || 'produttore' !== $producer->post_type || 'publish' !== $producer->post_status || $producer->post_password || ! $name || mb_strlen( $name ) > 240 ) {
        return new WP_Error( 'adb_source_identity', __( 'Inserisci il nome del vino e seleziona una cantina pubblicata.', 'amicidibacco' ) );
    }
    if ( '' === $vintage && preg_match( '/\b((?:19|20)\d{2})\b/', $name, $embedded ) ) { $vintage = $embedded[1]; }
    if ( '' !== $vintage && ! preg_match( '/^(?:19|20)\d{2}$/D', $vintage ) ) { return new WP_Error( 'adb_source_vintage', __( 'Inserisci un’annata di quattro cifre.', 'amicidibacco' ) ); }
    if ( $pdf_id ) { return adb_fill_source_media( absint( $pdf_id ), $name, $producer, $vintage, $draft_id ); }
    $seeds = adb_fill_source_seeds( $name, $producer->ID, $vintage );
    if ( is_wp_error( $seeds ) ) { return $seeds; }
    list( $host, $site, $direct ) = $seeds;
    $root = wp_parse_url( $site, PHP_URL_SCHEME ) . '://' . wp_parse_url( $site, PHP_URL_HOST ) . '/';
    $queue = array( $site => 89, add_query_arg( 's', rawurlencode( $name ), $root ) => 81, $root . 'sitemap.xml' => 74, $root . 'wp-sitemap.xml' => 59, $root . 'sitemap_index.xml' => 54 );
    foreach ( $direct as $url ) { $queue[ $url ] = 'en' === adb_fill_source_locale( $url ) ? 147 : 158; }
    $visited = array();
    $docs = array();
    $remaining = 15;
    $deadline = microtime( true ) + 19;
    while ( $queue && $remaining > 0 && microtime( true ) < $deadline ) {
        arsort( $queue, SORT_NUMERIC );
        $url = key( $queue );
        array_shift( $queue );
        if ( isset( $visited[ $url ] ) ) { continue; }
        $visited[ $url ] = true;
        // Every queue entry comes from one validated seed or from same-host links on its pages.
        $source_host = adb_fill_official_host( $url );
        $response = adb_fill_source_fetch( $url, $source_host, $deadline, $remaining );
        if ( ! $response ) { continue; }
        list( $url, $body, $type ) = $response;
        $visited[ $url ] = true;
        if ( str_starts_with( $body, '%PDF-' ) ) {
            require_once ABSPATH . 'wp-admin/includes/file.php';
            $tmp = wp_tempnam( 'adb-wine-sheet.pdf' );
            if ( ! $tmp ) { continue; }
            try {
                if ( strlen( $body ) !== file_put_contents( $tmp, $body ) ) { continue; }
                $doc = adb_fill_source_pdf( $tmp, $url, $name, $producer, $vintage, false );
                if ( ! is_wp_error( $doc ) ) { $docs[] = $doc; }
            } finally {
                wp_delete_file( $tmp );
            }
            continue;
        }
        if ( ( str_contains( $type, 'xml' ) && ! str_contains( $type, 'html' ) ) || preg_match( '~<(?:sitemapindex|urlset)\b~i', substr( $body, 0, 500 ) ) ) {
            adb_fill_source_sitemap( $body, $url, $source_host, $name, $vintage, $queue );
            continue;
        }
        if ( ! str_contains( $type, 'html' ) && ! preg_match( '/^\s*(?:<!doctype\s+html|<html)/i', $body ) ) { continue; }
        $page = adb_fill_source_html( $body, $name, $producer->post_title, $vintage );
        if ( ! $page ) { continue; }
        $match = false;
        $path = (string) wp_parse_url( $url, PHP_URL_PATH );
        $query = (string) wp_parse_url( $url, PHP_URL_QUERY );
        if ( ! preg_match( '/(?:^|&)(?:s|q)=/i', $query ) && ! preg_match( '~/(?:search|category|product-category|tag)(?:/|$)~i', $path )
            && mb_strlen( $page['text'] ) >= 60 && ( trim( $path, '/' ) !== '' || $query ) ) {
            $excerpts = $page['sections'];
            if ( ! $excerpts && ! $page['archive'] ) {
                foreach ( $page['headings'] as $heading ) { $excerpts[] = array( 'title' => $heading, 'text' => $page['text'], 'images' => $page['images'] ); }
            }
            foreach ( $excerpts as $excerpt ) {
                $heading = $excerpt['title'];
                if ( adb_fill_source_identity( $name, $heading, mb_substr( $excerpt['text'], 0, 1000 ), $producer->post_title ) ) {
                    $year = adb_fill_source_year( $heading, $excerpt['text'], $vintage );
                    $match = true; // Even when the HTML shows another vintage its technical sheets may include the requested one.
                    if ( false !== $year ) {
                        $docs[] = array( 'url' => $url, 'title' => $heading, 'text' => $excerpt['text'], 'official' => true, 'matched' => true, 'producer_id' => $producer->ID, 'producer' => $producer->post_title, 'vintage' => $year, 'lang' => $page['lang'], 'images' => $host === $source_host ? $excerpt['images'] : array() );
                    }
                    break;
                }
            }
        }
        foreach ( $page['links'] as $href => $label ) {
            $candidate = adb_fill_source_link( $href, $url, $source_host );
            if ( ! $candidate || isset( $visited[ $candidate ] ) ) { continue; }
            $rank = adb_fill_source_priority( $candidate, $label, $name, $vintage, $match );
            if ( $rank ) {
                $locale = adb_fill_source_locale( $candidate );
                $rank += 'it' === $locale ? 9 : ( 'en' === $locale ? -8 : 0 );
                $queue[ $candidate ] = max( $queue[ $candidate ] ?? 0, $rank );
            }
        }
    }
    if ( $docs ) {
        $score = static function ( $doc ) {
            $lang = strtolower( substr( $doc['lang'] ?: adb_fill_source_locale( $doc['url'], $doc['text'] ), 0, 2 ) );
            $pdf = preg_match( '/\.pdf(?:$|[?#])/i', $doc['url'] );
            return (int) $doc['vintage'] * 100 + ( 'it' === $lang ? 8 : 0 ) + ( $pdf ? 2 : 0 );
        };
        usort( $docs, static function ( $a, $b ) use ( $score ) { return $score( $b ) <=> $score( $a ); } );
        $latest = $docs[0]['vintage'];
        return array_slice( array_values( array_filter( $docs, static function ( $doc ) use ( $latest ) { return $doc['vintage'] === $latest; } ) ), 0, 3 );
    }
    return new WP_Error( 'adb_source_not_found', __( 'Nessuna scheda ufficiale corrisponde al nome e all’annata indicati. Verifica il nome dell’etichetta oppure seleziona il PDF del produttore dalla Libreria media.', 'amicidibacco' ) );
}
