<?php
/** Sideload a verified producer's bottle photograph as a native WooCommerce product PNG. */
defined( 'ABSPATH' ) || exit;

function adb_fill_bottle_candidates( $xpath, $scope, $name, $heading, $producer, $vintage ) {
    $images = array();
    $match = static function ( $value ) use ( $name, $heading, $producer ) {
        return adb_fill_source_identity( $name, $value, '', $producer ) || adb_fill_source_identity( $heading, $value, '', $producer );
    };
    $expected_year = $vintage ?: adb_fill_source_year( $heading . ' ' . $name, '', '' );
    foreach ( $xpath->query( './/img', $scope ) as $img ) {
        $alt = trim( $img->getAttribute( 'alt' ) );
        $src = $img->getAttribute( 'data-large_image' ) ?: ( $img->getAttribute( 'data-src' ) ?: $img->getAttribute( 'src' ) );
        $file = rawurldecode( pathinfo( (string) wp_parse_url( $src, PHP_URL_PATH ), PATHINFO_FILENAME ) );
        if ( preg_match( '/(?:logo|favicon|banner|panoram|vigneto|vineyard|background|placeholder|award|premio|medaglia)/iu', $file . ' ' . $alt ) ) { continue; }
        $image_year = adb_fill_source_year( str_replace( '_', ' ', $file . ' ' . $alt ), '', '' );
        if ( false === $image_year || ( $expected_year && $image_year && $expected_year !== $image_year ) ) { continue; }
        $label = preg_replace( '/\b(?:bottiglia|bottle|packshot|bouteille|flasche)\b/iu', ' ', $alt );
        $file_label = preg_replace( '/\b(?:bottiglia|bottle|packshot|bouteille|flasche|png|scaled)\b|\d+x\d+/iu', ' ', str_replace( array( '-', '_' ), ' ', $file ) );
        $alt_match = $match( $label );
        $file_match = $match( $file_label );
        $primary = $xpath->evaluate( 'boolean(ancestor::*[contains(concat(" ", normalize-space(@class), " "), " woocommerce-product-gallery__image ") and not(preceding-sibling::*[contains(@class,"woocommerce-product-gallery__image")])])', $img );
        // A descriptive alt takes precedence over a similar filename. Opaque filenames are safe only in the primary product gallery.
        if ( trim( $label ) ? ! $alt_match : ( ! $file_match && ! $primary ) ) { continue; }
        if ( ! $src || strlen( $src ) > 2000 ) { continue; }
        $images[ $src ] = ( $primary ? 20 : 0 ) + ( $alt_match ? 10 : 0 ) + ( $file_match ? 5 : 0 );
    }
    arsort( $images, SORT_NUMERIC );
    return array_slice( array_keys( $images ), 0, 3 );
}

/** Validate every image URL and redirect against the matched official page origin. */
function adb_fill_bottle_url( $src, $page, $host ) {
    $src = trim( (string) $src );
    if ( '' === $src || strlen( $src ) > 2000 ) { return ''; }
    $url = explode( '#', WP_Http::make_absolute_url( $src, $page ), 2 )[0];
    if ( ! $host || $host !== adb_fill_official_host( $url ) ) { return ''; }
    $path = rawurldecode( (string) wp_parse_url( $url, PHP_URL_PATH ) );
    if ( ! preg_match( '~\.(?:jpe?g|png|webp)$~iD', $path ) || preg_match( '~(?:^|/)(?:\.\.?|wp-admin|wp-json|wp-login)(?:/|$)|[\x00-\x20\\\\]~i', $path ) ) { return ''; }
    if ( 'https' === wp_parse_url( $page, PHP_URL_SCHEME ) ) { $url = set_url_scheme( $url, 'https' ); }
    return $url;
}

/** Validate dimensions before decoding. Cut only edge-connected white background; keep transparent inputs and label whites. */
function adb_fill_bottle_png( $bytes, $out ) {
    if ( ! function_exists( 'imagecreatefromstring' ) || strlen( $bytes ) > 5 * MB_IN_BYTES ) { return false; }
    $size = @getimagesizefromstring( $bytes );
    if ( ! $size || ! in_array( $size['mime'], array( 'image/png', 'image/jpeg', 'image/webp' ), true ) ) { return false; }
    list( $width, $height ) = $size;
    if ( $width < 50 || $height < 220 || $width * $height > 6000000 || $width > $height * 1.3 ) { return false; }
    $original = @imagecreatefromstring( $bytes );
    if ( ! $original ) { return false; }
    $ratio = min( 1, 1200 / max( $width, $height ) );
    $w = (int) round( $width * $ratio );
    $h = (int) round( $height * $ratio );
    $photo = imagecreatetruecolor( $w, $h );
    imagealphablending( $photo, false );
    imagesavealpha( $photo, true );
    imagecopyresampled( $photo, $original, 0, 0, 0, 0, $w, $h, $width, $height );
    unset( $original );

    $transparent_corners = 0;
    foreach ( array( array( 0, 0 ), array( $w - 1, 0 ), array( 0, $h - 1 ), array( $w - 1, $h - 1 ) ) as $corner ) {
        if ( ( imagecolorat( $photo, $corner[0], $corner[1] ) >> 24 ) >= 115 ) { ++$transparent_corners; }
    }
    $has_cutout = $transparent_corners >= 3;
    // A one-pixel frame lets a single flood fill reach background along all four sides.
    $mask = imagecreate( $w + 2, $h + 2 );
    imagecolorallocate( $mask, 255, 255, 255 );
    $subject = imagecolorallocate( $mask, 0, 0, 0 );
    $outside = imagecolorallocate( $mask, 0, 127, 0 );
    for ( $y = 0; $y < $h; ++$y ) {
        for ( $x = 0; $x < $w; ++$x ) {
            $pixel = imagecolorat( $photo, $x, $y );
            $r = ( $pixel >> 16 ) & 255;
            $g = ( $pixel >> 8 ) & 255;
            $b = $pixel & 255;
            if ( ( $pixel >> 24 ) < 115 && ( $has_cutout || min( $r, $g, $b ) < 243 || max( $r, $g, $b ) - min( $r, $g, $b ) > 10 ) ) {
                imagesetpixel( $mask, $x + 1, $y + 1, $subject );
            }
        }
    }
    imagefill( $mask, 0, 0, $outside );
    $clear = imagecolorallocatealpha( $photo, 255, 255, 255, 127 );
    $min_x = $w; $min_y = $h; $max_x = -1; $max_y = -1; $background = 0;
    for ( $y = 0; $y < $h; ++$y ) {
        for ( $x = 0; $x < $w; ++$x ) {
            if ( imagecolorat( $mask, $x + 1, $y + 1 ) === $outside ) {
                if ( ! $has_cutout ) { imagesetpixel( $photo, $x, $y, $clear ); }
                ++$background;
            } else {
                $min_x = min( $min_x, $x ); $max_x = max( $max_x, $x );
                $min_y = min( $min_y, $y ); $max_y = max( $max_y, $y );
            }
        }
    }
    $subject_h = $max_y - $min_y + 1;
    $subject_w = $max_x - $min_x + 1;
    if ( $background < $w * $h * .12 || $subject_h < max( 150, $h * .48 ) || $subject_w < 30 || $subject_w > $subject_h * .70 ) { return false; }
    return imagepng( $photo, $out, 6 );
}

function adb_fill_fetch_bottle( $url, $host, $deadline, &$budget ) {
    while ( $budget > 0 && microtime( true ) < $deadline ) {
        --$budget;
        $response = wp_safe_remote_get( $url, array(
            'timeout' => min( 4, max( 0.5, $deadline - microtime( true ) ) ), 'redirection' => 0,
            'limit_response_size' => 5 * MB_IN_BYTES + 1, 'headers' => array( 'Accept' => 'image/jpeg,image/png,image/webp' ),
        ) );
        if ( is_wp_error( $response ) ) { break; }
        $code = wp_remote_retrieve_response_code( $response );
        if ( 200 === $code ) { return wp_remote_retrieve_body( $response ); }
        if ( ! in_array( $code, array( 301, 302, 303, 307, 308 ), true ) ) { break; }
        $url = adb_fill_bottle_url( wp_remote_retrieve_header( $response, 'location' ), $url, $host );
        if ( ! $url ) { break; }
    }
    return '';
}

function adb_fill_existing_bottle( $url, $draft_id ) {
    $ids = get_posts( array(
        'post_type' => 'attachment', 'post_status' => 'inherit', 'post_mime_type' => 'image/png', 'fields' => 'ids',
        'meta_key' => '_adb_bottle_source_url', 'meta_value' => $url, 'posts_per_page' => 8, 'has_password' => false,
    ) );
    foreach ( $ids as $id ) {
        $parent = wp_get_post_parent_id( $id );
        if ( ( $parent === $draft_id || ( $parent && is_post_publicly_viewable( $parent ) && ! get_post_field( 'post_password', $parent ) ) )
            && current_user_can( 'read_post', $id ) && is_readable( (string) get_attached_file( $id ) ) ) { return (int) $id; }
    }
    return 0;
}

/** Move the validated PNG into uploads and register its source on the attachment. Clean up partial imports. */
function adb_fill_store_bottle( $tmp, $id, $name, $url, $page ) {
    if ( filesize( $tmp ) > wp_max_upload_size() ) { return 0; }
    $file = array( 'name' => sanitize_file_name( $name . '.png' ), 'tmp_name' => $tmp, 'error' => 0, 'size' => filesize( $tmp ) );
    $upload = wp_handle_sideload( $file, array( 'test_form' => false ) );
    if ( ! empty( $upload['error'] ) ) { return 0; }
    $attachment = 0;
    $done = false;
    try {
        $attachment = wp_insert_attachment( array(
            'post_title' => wp_slash( $name ), 'post_mime_type' => 'image/png', 'post_status' => 'inherit',
            'guid' => $upload['url'],
        ), $upload['file'], $id, true );
        if ( ! $attachment || is_wp_error( $attachment ) ) { return 0; }
        $metadata = wp_generate_attachment_metadata( $attachment, $upload['file'] );
        if ( ! $metadata || empty( $metadata['width'] ) || empty( $metadata['height'] ) ) { return 0; }
        wp_update_attachment_metadata( $attachment, $metadata );
        update_post_meta( $attachment, '_wp_attachment_image_alt', wp_slash( $name ) );
        update_post_meta( $attachment, '_adb_bottle_source_page', wp_slash( $page ) );
        $done = (bool) update_post_meta( $attachment, '_adb_bottle_source_url', wp_slash( $url ) );
        return $done ? (int) $attachment : 0;
    } finally {
        if ( ! $done ) {
            if ( $attachment && ! is_wp_error( $attachment ) ) { wp_delete_attachment( $attachment, true ); }
            if ( is_file( $upload['file'] ) ) { wp_delete_file( $upload['file'] ); }
        }
    }
}

/** Prepare outside the product transaction. The caller assigns the ID only after rechecking the draft. */
function adb_fill_prepare_bottle_image( $docs, $id, $name ) {
    $id = absint( $id );
    if ( ! $docs || ! adb_fill_editable_draft( $id ) || get_post_thumbnail_id( $id ) || ! current_user_can( 'upload_files' ) ) { return null; }
    // A locally selected PDF may establish identity and vintage but cannot supply a remote image origin.
    if ( count( $docs ) === 1 && ! empty( $docs[0]['matched'] ) && empty( $docs[0]['official'] ) ) {
        $docs = adb_fill_sources( $name, $docs[0]['producer_id'], $docs[0]['vintage'] );
        if ( is_wp_error( $docs ) ) { return null; }
    }
    require_once ABSPATH . 'wp-admin/includes/file.php';
    require_once ABSPATH . 'wp-admin/includes/image.php';
    $budget = 4;
    $deadline = microtime( true ) + 9;
    $seen = array();
    foreach ( $docs as $doc ) {
        if ( empty( $doc['official'] ) || empty( $doc['matched'] ) || empty( $doc['images'] ) ) { continue; }
        $page = $doc['url'];
        $host = adb_fill_official_host( $page );
        foreach ( $doc['images'] as $candidate ) {
            $url = adb_fill_bottle_url( $candidate, $page, $host );
            if ( ! $url || isset( $seen[ $url ] ) ) { continue; }
            $seen[ $url ] = true;
            $image_id = adb_fill_existing_bottle( $url, $id );
            if ( $image_id ) { return array( 'id' => $image_id, 'created' => false, 'url' => $url, 'page' => $page ); }
            if ( $budget <= 0 || microtime( true ) >= $deadline ) { return null; }
            $bytes = adb_fill_fetch_bottle( $url, $host, $deadline, $budget );
            if ( ! $bytes ) { continue; }
            $tmp = wp_tempnam( 'adb-bottle.png' );
            if ( ! $tmp ) { return null; }
            try {
                if ( ! adb_fill_bottle_png( $bytes, $tmp ) ) { continue; }
                $image_id = adb_fill_store_bottle( $tmp, $id, $name, $url, $page );
                if ( $image_id ) { return array( 'id' => $image_id, 'created' => true, 'url' => $url, 'page' => $page ); }
            } finally {
                if ( is_file( $tmp ) ) { wp_delete_file( $tmp ); }
            }
        }
    }
    return null;
}

/** Discard only an attachment made by this attempt and still unused as a product image. */
function adb_fill_discard_bottle_image( $prepared ) {
    if ( empty( $prepared['created'] ) || empty( $prepared['id'] ) ) { return; }
    global $wpdb;
    $id = (int) $prepared['id'];
    if ( $prepared['url'] !== get_post_meta( $id, '_adb_bottle_source_url', true ) ) { return; }
    $uses = $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->postmeta} WHERE meta_key = '_thumbnail_id' AND meta_value = %s", (string) $id ) );
    if ( '0' === (string) $uses ) { wp_delete_attachment( $id, true ); }
}
