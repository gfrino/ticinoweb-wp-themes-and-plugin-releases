<?php
defined( 'ABSPATH' ) || exit;

/** Compact variation rules; an empty attribute value retains WooCommerce's "any" semantics. */
function adb_pair_purchase_rules( $product ) {
    if ( ! $product instanceof WC_Product || ! $product->is_purchasable() || 'instock' !== $product->get_stock_status() || ! $product->is_type( array( 'simple', 'variable' ) ) ) {
        return array();
    }
    $variable = $product->is_type( 'variable' );
    $choices = $variable ? $product->get_available_variations( 'objects' ) : array( $product );
    $rules = array();
    foreach ( $choices as $choice ) {
        if ( ! $choice->is_purchasable() || 'instock' !== $choice->get_stock_status() || $choice->is_on_backorder( 1 ) || ! $choice->has_enough_stock( 1 ) || ( $variable && ( ! $choice->variation_is_visible() || ! $choice->variation_is_active() ) ) ) {
            continue;
        }
        $price = (float) wc_get_price_to_display( $choice );
        $rules[] = array(
            'id'         => $variable ? $choice->get_id() : 0,
            'attributes' => $variable ? $choice->get_variation_attributes() : (object) array(),
            'price'      => $price,
            'units'      => (object) adb_unit_prices( $choice, $price ),
        );
    }
    return $rules;
}

function adb_pair_render_bottle( $wine, $rules, $is_current ) {
    $name = $wine->get_name();
    $winery = $wine->get_attribute( 'pa_cantina' );
    $attributes = $wine->is_type( 'variable' ) ? $wine->get_variation_attributes() : array();
    $details = array();
    foreach ( array( 'pa_dimensione', 'pa_anno' ) as $key ) {
        if ( ! isset( $attributes[ $key ] ) && $wine->get_attribute( $key ) ) {
            $details[] = $wine->get_attribute( $key );
        }
    }
    ?>
    <article class="adb-pair-bottle" data-pair-id="<?php echo esc_attr( $wine->get_id() ); ?>" data-pair-rules="<?php echo esc_attr( wp_json_encode( $rules ) ); ?>">
        <div class="adb-pair-bottle__art">
            <?php echo $wine->get_image( 'woocommerce_thumbnail', array( 'alt' => '', 'loading' => 'lazy', 'decoding' => 'async' ) ); ?>
            <label class="adb-pair-check">
                <input type="checkbox" checked aria-label="<?php echo esc_attr( sprintf( __( 'Includi %s nella selezione', 'amicidibacco' ), $name ) ); ?>">
                <span><?php echo esc_html( $is_current ? __( 'Questo vino', 'amicidibacco' ) : __( 'Includi', 'amicidibacco' ) ); ?></span>
            </label>
        </div>
        <div class="adb-pair-bottle__body">
            <?php if ( $winery ) : ?><p class="adb-pair-bottle__winery"><?php echo esc_html( $winery ); ?></p><?php endif; ?>
            <h3><?php if ( $is_current ) : echo esc_html( $name ); else : ?><a href="<?php echo esc_url( $wine->get_permalink() ); ?>"><?php echo esc_html( $name ); ?></a><?php endif; ?></h3>
            <?php if ( $details ) : ?><p class="adb-pair-bottle__details"><?php echo esc_html( implode( ' · ', $details ) ); ?></p><?php endif; ?>
            <?php if ( $attributes ) : ?>
                <div class="adb-pair-options">
                <?php foreach ( $attributes as $attribute => $options ) :
                    $input_id = wp_unique_id( 'adb-pair-option-' ); ?>
                    <div><label for="<?php echo esc_attr( $input_id ); ?>"><?php echo esc_html( wc_attribute_label( $attribute, $wine ) ); ?></label>
                    <?php wc_dropdown_variation_attribute_options( array(
                        'attribute' => $attribute, 'product' => $wine, 'options' => $options, 'id' => $input_id,
                        'selected' => $wine->get_variation_default_attribute( $attribute ),
                    ) ); ?></div>
                <?php endforeach; ?>
                </div>
            <?php endif; ?>
            <span class="adb-pair-bottle__price" data-pair-price><?php echo wp_kses_post( wc_price( $rules[0]['price'] ) ); ?></span>
            <span class="adb-price-unit" data-pair-unit><?php echo esc_html( implode( ' / ', (array) $rules[0]['units'] ) ); ?></span>
            <?php echo wp_kses_post( adb_shipping_price_link() ); ?>
        </div>
    </article>
    <?php
}

function adb_render_pairings( $product ) {
    if ( ! $product instanceof WC_Product ) { return; }
    $recommendations = adb_pair_recommendations( $product->get_id() );
    if ( ! $recommendations ) { return; }
    $current_rules = adb_pair_purchase_rules( $product );
    if ( ! $current_rules ) { return; }
    $bottles = array( array( $product, $current_rules ) );
    $all_orders = true;
    foreach ( $recommendations as $row ) {
        $wine = wc_get_product( $row['id'] );
        $rules = adb_pair_purchase_rules( $wine );
        if ( ! $rules ) { continue; }
        $bottles[] = array( $wine, $rules );
        $all_orders = $all_orders && 'orders' === $row['source'];
        if ( count( $bottles ) >= 3 ) { break; }
    }
    if ( count( $bottles ) < 2 ) { return; }
    $config = array(
        'endpoint' => WC_AJAX::get_endpoint( 'adb_add_pairing' ),
        'stateEndpoint' => add_query_arg( 'product_id', $product->get_id(), WC_AJAX::get_endpoint( 'adb_pair_cart_state' ) ),
        'already' => __( 'Già nel carrello', 'amicidibacco' ),
        'addedOne' => __( 'Una bottiglia aggiunta al carrello.', 'amicidibacco' ),
        'addedMany' => __( '%d bottiglie aggiunte al carrello.', 'amicidibacco' ),
        'nothingAdded' => __( 'Questo vino è già nel carrello.', 'amicidibacco' ),
        'nonce' => wp_create_nonce( 'adb_add_pairing' ),
        'currency' => html_entity_decode( get_woocommerce_currency_symbol(), ENT_QUOTES | ENT_HTML5, 'UTF-8' ),
        'format' => html_entity_decode( get_woocommerce_price_format(), ENT_QUOTES | ENT_HTML5, 'UTF-8' ),
        'decimals' => wc_get_price_decimals(), 'decimal' => wc_get_price_decimal_separator(), 'thousand' => wc_get_price_thousand_separator(),
        'one' => __( '1 bottiglia', 'amicidibacco' ), 'many' => __( '%d bottiglie', 'amicidibacco' ),
        'failure' => __( 'Impossibile verificare il carrello. Riprova.', 'amicidibacco' ),
        'cartLabel' => __( 'Carrello, %d articoli', 'amicidibacco' ),
    );
    $title_id = wp_unique_id( 'adb-pair-title-' );
    ?>
    <section class="adb-pairings" aria-labelledby="<?php echo esc_attr( $title_id ); ?>" data-adb-pairings data-pair-config="<?php echo esc_attr( wp_json_encode( $config ) ); ?>">
        <p class="adb-kicker"><?php esc_html_e( 'Acquistati spesso insieme', 'amicidibacco' ); ?></p>
        <h2 id="<?php echo esc_attr( $title_id ); ?>"><?php esc_html_e( 'La selezione dell’enoteca', 'amicidibacco' ); ?></h2>
        <p class="adb-pairings__intro"><?php echo esc_html( $all_orders ? __( 'Scegli le bottiglie da aggiungere al carrello.', 'amicidibacco' ) : __( 'Scegli quali abbinamenti suggeriti dall’enoteca aggiungere al carrello.', 'amicidibacco' ) ); ?></p>
        <form>
            <fieldset class="adb-pairings__fields" disabled aria-labelledby="<?php echo esc_attr( $title_id ); ?>">
                <div class="adb-pairings__bottles">
                    <?php foreach ( $bottles as $index => $bottle ) { adb_pair_render_bottle( $bottle[0], $bottle[1], 0 === $index ); } ?>
                </div>
                <div class="adb-pairings__checkout">
                    <div class="adb-pairings__sum" aria-live="polite" aria-atomic="true">
                        <div><?php esc_html_e( 'Totale', 'amicidibacco' ); ?> <span data-pair-count></span></div>
                        <strong data-pair-total></strong>
                    </div>
                    <button type="submit" class="adb-pairings__submit"><?php echo adb_icon( 'bag' ); ?> <?php esc_html_e( 'Aggiungi la selezione', 'amicidibacco' ); ?></button>
                </div>
            </fieldset>
            <div class="adb-pairings__feedback">
                <span class="adb-pairings__feedback-mark" aria-hidden="true"></span>
                <span data-pair-message role="status" aria-live="polite" aria-atomic="true"></span>
                <a href="<?php echo esc_url( wc_get_cart_url() ); ?>" data-pair-cart hidden><?php esc_html_e( 'Vai al carrello', 'amicidibacco' ); ?> <?php echo adb_icon( 'arrow' ); ?></a>
            </div>
            <noscript><?php esc_html_e( 'Attiva JavaScript per aggiungere più vini insieme.', 'amicidibacco' ); ?></noscript>
        </form>
    </section>
    <?php
}
