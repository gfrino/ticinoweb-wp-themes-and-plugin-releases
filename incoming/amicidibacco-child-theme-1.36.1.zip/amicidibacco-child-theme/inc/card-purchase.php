<?php
/** Native WooCommerce purchasing from catalog cards. */
defined( 'ABSPATH' ) || exit;

function adb_card_purchase( $product ) {
    $label = __( 'Aggiungi al carrello', 'amicidibacco' );
    if ( ! $product->is_in_stock() ) {
        echo '<span class="adb-card-stock">' . esc_html__( 'Esaurito', 'amicidibacco' ) . '</span>';
        return;
    }
    if ( $product->is_type( 'variable' ) && $product->is_purchasable() ) {
        wp_enqueue_script( 'adb-card-purchase', get_stylesheet_directory_uri() . '/assets/js/card-purchase.js', array( 'adb-variation-select', 'wc-cart-fragments' ), ADB_VERSION, true );
        printf( '<a class="adb-card-buy" data-adb-buy="%d" data-name="%s" href="%s" aria-haspopup="dialog" aria-label="%s">%s</a>',
            $product->get_id(), esc_attr( $product->get_name() ), esc_url( $product->get_permalink() ),
            esc_attr( $label . ' · ' . $product->get_name() ), esc_html( $label ) );
    } elseif ( $product->is_type( 'simple' ) && $product->is_purchasable() ) {
        wp_enqueue_script( 'wc-add-to-cart' );
        printf( '<a rel="nofollow" class="adb-card-buy add_to_cart_button ajax_add_to_cart" href="%s" data-product_id="%d" data-quantity="1" aria-label="%s">%s</a>',
            esc_url( $product->add_to_cart_url() ), $product->get_id(), esc_attr( $label . ' · ' . $product->get_name() ), esc_html( $label ) );
    } else {
        printf( '<a class="adb-card-buy" href="%s">%s</a>', esc_url( $product->get_permalink() ), esc_html__( 'Vedi prodotto', 'amicidibacco' ) );
    }
}

// Only load the chosen product's options. WooCommerce resolves combinations, stock and prices.
add_action( 'wc_ajax_adb_card_options', static function () {
    global $product;
    $id = absint( $_GET['product_id'] ?? 0 );
    $product = $id ? wc_get_product( $id ) : false;
    if ( ! $product || ! $product->is_type( 'variable' ) || 'publish' !== $product->get_status() || post_password_required( $id ) || ! $product->is_visible() || ! $product->is_purchasable() || ! $product->is_in_stock() ) {
        wp_send_json_error( null, 404 );
    }
    add_filter( 'woocommerce_show_variation_price', '__return_true' );
    add_filter( 'woocommerce_product_single_add_to_cart_text', 'adb_product_cart_label' );
    ob_start();
    woocommerce_variable_add_to_cart();
    wp_send_json_success( array( 'form' => ob_get_clean(), 'nonce' => wp_create_nonce( 'wc_store_api' ), 'restNonce' => wp_create_nonce( 'wp_rest' ) ) );
} );

add_action( 'wp_footer', static function () {
    if ( ! wp_script_is( 'adb-card-purchase', 'enqueued' ) ) { return; }
    ?>
    <dialog data-lenis-prevent class="adb-quick-buy" id="adb-quick-buy" aria-labelledby="adb-quick-buy-title"
        data-options="<?php echo esc_url( WC_AJAX::get_endpoint( 'adb_card_options' ) ); ?>"
        data-add="<?php echo esc_url( rest_url( 'wc/store/v1/cart/add-item' ) ); ?>"
        data-loading="<?php esc_attr_e( 'Caricamento delle opzioni…', 'amicidibacco' ); ?>"
        data-added="<?php esc_attr_e( 'Aggiunto al carrello', 'amicidibacco' ); ?>"
        data-error="<?php esc_attr_e( 'Operazione non riuscita. Verifica il carrello prima di riprovare.', 'amicidibacco' ); ?>"
        data-load-error="<?php esc_attr_e( 'Opzioni non disponibili. Puoi aprire la scheda del prodotto.', 'amicidibacco' ); ?>">
        <div class="adb-quick-buy__head">
            <span class="adb-buy-check" data-check hidden aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="m5 12 4.5 4.5L19 7"/></svg></span>
            <h2 id="adb-quick-buy-title" tabindex="-1"></h2>
            <button type="button" data-dismiss aria-label="<?php esc_attr_e( 'Chiudi', 'amicidibacco' ); ?>"><?php echo adb_icon( 'close' ); ?></button></div>
        <p data-feedback role="status" aria-live="polite"></p>
        <div data-form></div>
        <a class="adb-link" data-detail hidden><?php esc_html_e( 'Vedi prodotto', 'amicidibacco' ); ?></a>
        <div class="adb-buy-receipt" data-receipt hidden>
            <span data-bottle></span>
            <div><strong data-wine></strong><p data-variant></p><p><?php esc_html_e( 'Quantità', 'amicidibacco' ); ?> <span data-units></span></p></div>
        </div>
        <a class="adb-link" href="<?php echo esc_url( wc_get_cart_url() ); ?>" data-cart hidden><?php esc_html_e( 'Vai al carrello', 'amicidibacco' ); ?> <?php echo adb_icon(); ?></a>
        <button class="adb-buy-continue" type="button" data-continue hidden><?php esc_html_e( 'Continua gli acquisti', 'amicidibacco' ); ?></button>
    </dialog>
    <?php
}, 5 );
