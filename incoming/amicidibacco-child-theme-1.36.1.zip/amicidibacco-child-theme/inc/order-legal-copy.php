<?php
/** Preserve the public sales documents accepted at checkout in the first customer confirmation. */
defined( 'ABSPATH' ) || exit;

final class ADB_Order_Legal_Copy {
    private const SNAPSHOT = '_adb_order_legal_html';
    private const SENT = '_adb_order_legal_emailed';

    // A preview, a failed send, or the first part of a multipart message must not mark an order as sent.
    private static $rendered = array();

    private static function allowed_html() {
        return array(
            'h2' => array(), 'h3' => array(), 'h4' => array(), 'p' => array(), 'br' => array(),
            'strong' => array(), 'b' => array(), 'em' => array(), 'i' => array(),
            'ul' => array(), 'ol' => array(), 'li' => array(), 'a' => array( 'href' => true ),
            'blockquote' => array(), 'table' => array(), 'thead' => array(), 'tbody' => array(),
            'tr' => array(), 'td' => array(), 'th' => array(),
        );
    }

    public static function capture( $order ) {
        if ( ! $order instanceof WC_Order || $order->get_meta( self::SNAPSHOT ) ) {
            return;
        }

        $terms_id = wc_get_page_id( 'terms' );
        $pages = array(
            'terms' => $terms_id > 0 ? get_post( $terms_id ) : null,
            'resa-merce' => get_page_by_path( 'resa-merce' ),
            'spedizioni-e-pagamenti' => get_page_by_path( 'spedizioni-e-pagamenti' ),
            'impressum' => get_page_by_path( 'impressum' ),
        );
        $html = '';
        foreach ( $pages as $slug => $page ) {
            if ( $page ) {
                $page = get_post( apply_filters( 'wpml_object_id', $page->ID, 'page', true ) );
            }
            if ( ! $page || 'publish' !== $page->post_status || '' !== $page->post_password || '' === trim( $page->post_content ) ) {
                wc_get_logger()->warning( 'Documento di vendita non disponibile: ' . $slug, array( 'source' => 'adb-order-legal' ) );
                continue;
            }
            // Take only the editorial copy. Running shortcodes or the full content pipeline could inject forms or visitor data.
            $body = wp_kses( wpautop( strip_shortcodes( $page->post_content ) ), self::allowed_html() );
            $html .= '<h2>' . esc_html( $page->post_title ) . '</h2>' . links_add_base_url( $body, get_permalink( $page->ID ), array( 'href' ) );
        }
        if ( '' !== $html ) {
            $order->update_meta_data( self::SNAPSHOT, $html );
        }
    }

    public static function capture_block_checkout( $order ) {
        self::capture( $order );
        $order->save_meta_data();
    }

    public static function render( $order, $sent_to_admin, $plain_text, $email ) {
        if ( $sent_to_admin || ! $order instanceof WC_Order || ! is_object( $email ) ) {
            return;
        }
        $confirmations = array( 'customer_on_hold_order', 'customer_processing_order', 'customer_completed_order', 'customer_invoice' );
        if ( ! in_array( $email->id, $confirmations, true ) || $order->get_meta( self::SENT ) ) {
            return;
        }
        $snapshot = $order->get_meta( self::SNAPSHOT );
        if ( ! is_string( $snapshot ) || '' === $snapshot ) {
            return;
        }

        self::$rendered[ spl_object_id( $email ) ] = $order->get_id();
        $html = wp_kses( $snapshot, self::allowed_html() );
        if ( ! $plain_text ) {
            echo $html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- allowed elements and attributes above.
            return;
        }

        $with_links = preg_replace( '~<a\s+href=(["\'])(.*?)\1[^>]*>(.*?)</a>~is', '$3 ($2)', $html );
        $with_breaks = preg_replace( '~<br\s*/?>|</(?:p|h[2-4]|li|tr|blockquote)>~i', "\n\n", $with_links );
        $text = html_entity_decode( wp_strip_all_tags( $with_breaks ), ENT_QUOTES | ENT_HTML5, 'UTF-8' );
        echo "\n" . trim( $text ) . "\n\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- text/plain email.
    }

    public static function mark_sent( $success, $email_id, $email ) {
        $key = spl_object_id( $email );
        $rendered_order = self::$rendered[ $key ] ?? null;
        unset( self::$rendered[ $key ] );
        $order = $email->object;
        if ( $success && $order instanceof WC_Order && $rendered_order === $order->get_id() ) {
            $order->update_meta_data( self::SENT, 'yes' );
            $order->save_meta_data();
        }
    }
}

add_action( 'woocommerce_checkout_create_order', array( 'ADB_Order_Legal_Copy', 'capture' ) );
add_action( 'woocommerce_store_api_checkout_order_processed', array( 'ADB_Order_Legal_Copy', 'capture_block_checkout' ), 1 );
add_action( 'woocommerce_email_order_meta', array( 'ADB_Order_Legal_Copy', 'render' ), 20, 4 );
add_action( 'woocommerce_email_sent', array( 'ADB_Order_Legal_Copy', 'mark_sent' ), 10, 3 );
