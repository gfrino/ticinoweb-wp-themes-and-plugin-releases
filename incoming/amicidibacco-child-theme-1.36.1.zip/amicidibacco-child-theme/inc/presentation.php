<?php
defined('ABSPATH') || exit;

function adb_icon($name = 'arrow') {
    $paths = [
        'arrow' => '<path d="M4 12h15m-6-6 6 6-6 6"/>',
        'search' => '<circle cx="10.5" cy="10.5" r="6.5"/><path d="m16 16 5 5"/>',
        'bag' => '<path d="M5 7h14l1 14H4L5 7Z"/><path d="M8 8V6a4 4 0 0 1 8 0v2"/>',
        'close' => '<path d="m5 5 14 14M19 5 5 19"/>',
        'plus' => '<path d="M12 4v16M4 12h16"/>',
        'menu' => '<path d="M4 8h16"/><path d="M4 16h16"/>',
        'down' => '<path d="M12 3v18m-6-6 6 6 6-6"/>',
        'pause' => '<path d="M8 5v14M16 5v14"/>',
        'play' => '<path d="m8 5 11 7-11 7V5Z"/>',
        'account' => '<circle cx="12" cy="7" r="4"/><path d="M4 22v-3a8 8 0 0 1 16 0v3"/>',
    ];
    return '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4" aria-hidden="true" focusable="false">' . ($paths[$name] ?? $paths['arrow']) . '</svg>';
}

add_filter('walker_nav_menu_start_el', static function ($output, $item, $depth, $args) {
    if ('primary' !== ($args->theme_location ?? '') || $depth) { return $output; }
    return str_replace('</a>', '<span class="adb-nav__arrow" aria-hidden="true">' . adb_icon() . '</span></a>', $output);
}, 20, 4);

function adb_cart_link() {
    $count = function_exists('ticinoweb_get_cart_count') ? ticinoweb_get_cart_count() : 0;
    $url = function_exists('wc_get_cart_url') ? wc_get_cart_url() : home_url('/');
    ?><a class="adb-cart" href="<?php echo esc_url($url); ?>" aria-label="<?php echo esc_attr(sprintf(__('Carrello, %d articoli', 'amicidibacco'), $count)); ?>"><?php echo adb_icon('bag'); ?><span class="adb-cart__count"><?php echo esc_html($count); ?></span></a><?php
}

function adb_heading($text, $tag = 'h2', $class = '') {
    $tag = in_array($tag, ['h1', 'h2', 'h3'], true) ? $tag : 'h2';
    $lines = explode('|', (string) $text);
    echo '<' . $tag . ' class="' . esc_attr($class) . '">';
    foreach ($lines as $i => $line) {
        if ($i) { echo '<br>'; }
        echo $i === count($lines) - 1 && count($lines) > 1 ? '<em>' . esc_html($line) . '</em>' : esc_html($line);
    }
    echo '</' . $tag . '>';
}

function adb_photo($id, $size = 'large', $attrs = []) {
    if (!$id) { return; }
    // Cover crops need enough pixels for their height, including panoramic originals.
    $attrs = array_merge(['sizes' => '(max-width:600px) 850px, (max-width:1000px) 700px, 900px', 'data-adb-cover' => '1'], $attrs);
    echo wp_get_attachment_image(absint($id), $size, false, $attrs);
}

add_filter('wp_get_attachment_image_attributes', function ($attrs) {
    if (isset($attrs['data-adb-cover'])) {
        $attrs['sizes'] = preg_replace('/^auto,\s*/', '', $attrs['sizes'] ?? '100vw');
        unset($attrs['data-adb-cover']);
    }
    return $attrs;
}, 100);

/** Use the cantina term shared by the wine and its published producer record. */
function adb_card_winery($wine) {
    static $index = [];
    $terms = wc_get_product_terms($wine->get_id(), 'pa_cantina', ['fields' => 'ids']);
    if (is_wp_error($terms) || !$terms) { return null; }
    $site = get_current_blog_id() . ':' . determine_locale();
    if (!isset($index[$site])) {
        $index[$site] = [];
        foreach (adb_wineries([], -1) as $producer) {
            $term = (int) get_post_meta($producer->ID, 'cantina', true);
            $index[$site][$term] ??= $producer;
        }
    }
    foreach ($terms as $term) {
        if (isset($index[$site][$term])) { return $index[$site][$term]; }
    }
    return null;
}

function adb_card_wine_preview($wine, $preview_id) {
    $tasting = adb_tasting_data($wine->get_id());
    $scores = array_filter($tasting['scores']);
    $aromas = array_slice($tasting['aromas'], 0, 3);
    $winery = adb_card_winery($wine);
    $grape = adb_product_field_value($wine->get_id(), 'vitigno');
    if (!$scores && !$aromas && !$grape && !$winery) { return ''; }
    $axes = adb_tasting_axes();
    ob_start();
    ?>
    <div class="adb-wine-preview" id="<?php echo esc_attr($preview_id); ?>">
        <div class="adb-wine-preview__head">
            <span class="adb-wine-preview__title"><?php esc_html_e('Nel calice', 'amicidibacco'); ?></span>
            <?php if ($winery) :
                $logo = get_post_thumbnail_id($winery->ID);
                if ($logo) {
                    wp_enqueue_script('adb-winery-logos');
                    $attrs = ['class' => 'adb-wine-preview__logo', 'alt' => get_the_title($winery), 'loading' => 'lazy', 'decoding' => 'async', 'sizes' => '300px'];
                    $size = 'large';
                    if (image_get_intermediate_size($logo, 'adb-mark-png')) {
                        $size = 'adb-mark-png';
                        // Keep this lossless derivative when the original is a different format.
                        $attrs['srcset'] = wp_get_attachment_image_url($logo, $size);
                    }
                    echo '<span class="adb-wine-preview__mark">' . wp_get_attachment_image($logo, $size, false, $attrs) . '</span>';
                } else { ?><span class="adb-wine-preview__winery"><?php echo esc_html(get_the_title($winery)); ?></span><?php }
            endif; ?>
        </div>
        <?php if ($scores) : ?>
            <span class="adb-wine-preview__caption"><?php echo esc_html($tasting['score_method'] === 'editorial' ? __('Profilo indicativo', 'amicidibacco') : __('Profilo del vino', 'amicidibacco')); ?></span>
            <dl class="adb-wine-preview__axes">
                <?php foreach ($scores as $axis => $value) : ?>
                    <div><dt><?php echo esc_html($axes[$axis]['label']); ?></dt><dd>
                        <span class="adb-wine-preview__scale" aria-hidden="true"><?php for ($i = 1; $i <= 5; $i++) : ?><i<?php if ($i <= $value) { echo ' class="is-filled"'; } ?>></i><?php endfor; ?></span>
                        <span><?php echo esc_html($value . '/5'); ?></span>
                    </dd></div>
                <?php endforeach; ?>
            </dl>
        <?php elseif ($aromas || $grape) : ?>
            <span class="adb-wine-preview__caption"><?php echo esc_html($aromas ? __('Le note aromatiche', 'amicidibacco') : __('Vitigno', 'amicidibacco')); ?></span>
            <span class="adb-wine-preview__notes"><?php echo esc_html($aromas ? implode(' · ', $aromas) : wp_trim_words(wp_strip_all_tags($grape), 12)); ?></span>
        <?php elseif ($winery) : ?>
            <span class="adb-wine-preview__notes"><?php echo esc_html(get_the_title($winery)); ?></span>
        <?php endif; ?>
    </div>
    <?php
    return ob_get_clean();
}

// Product descriptions and variation notes are rendered through their native WooCommerce paths.
function adb_product_card($product, $class = '', $pairing_note = '') {
    if (!$product instanceof WC_Product || !$product->is_visible()) { return; }
    $id = $product->get_id();
    $region = wc_get_product_terms($id, 'pa_regione', ['fields' => 'names']);
    $label = $product->get_name();
    $winery_names = wc_get_product_terms($id, 'pa_cantina', ['fields' => 'names']);
    $is_selection = has_term(['le-selezioni', 'le-selezioni-grappa'], 'product_cat', $id);
    $is_wine = !$is_selection && get_post_meta($id, 'tipo_di_prodotto', true) === 'VINO SINGOLO';
    $preview_id = $is_wine ? wp_unique_id('adb-wine-preview-') : '';
    $preview = $is_wine ? adb_card_wine_preview($product, $preview_id) : '';
    ?>
    <article class="adb-product <?php echo esc_attr($class); ?>">
        <div class="adb-product__media">
        <a class="adb-product__photo" <?php if ($preview) : ?>aria-describedby="<?php echo esc_attr($preview_id); ?>"<?php endif; ?> href="<?php echo esc_url($product->get_permalink()); ?>" aria-label="<?php echo esc_attr($product->get_name()); ?>">
            <?php if ($product->is_on_sale()) : ?><span class="adb-product__badge"><?php esc_html_e('In offerta', 'amicidibacco'); ?></span><?php endif; ?>
            <?php echo $product->get_image('medium_large', ['data-adb-webp' => true, 'loading' => 'lazy', 'decoding' => 'async']); ?>
            <span class="adb-product__discover"><?php echo esc_html($is_selection ? __('Scopri la selezione', 'amicidibacco') : __('Scopri il vino', 'amicidibacco')); ?> <?php echo adb_icon(); ?></span>
        </a>
        <?php echo $preview; // Escaped by adb_card_wine_preview(). ?>
        </div>
        <div class="adb-product__info">
            <?php if ($region) : ?><span class="adb-product__origin"><?php echo esc_html(implode(' · ', $region)); ?></span><?php endif; ?>
            <h3 class="adb-product__title"><a href="<?php echo esc_url($product->get_permalink()); ?>"><?php echo esc_html($label ?: $product->get_name()); ?></a></h3>
            <?php if ($winery_names && !is_wp_error($winery_names)) : ?><p class="adb-product__winery"><?php echo esc_html(implode(' · ', $winery_names)); ?></p><?php endif; ?>
            <p class="adb-product__label"><?php echo esc_html(adb_product_field_value($id, 'etichetta')); ?></p>
            <?php if ($pairing_note !== '') : ?>
                <div class="adb-dishes__reason"><strong><?php esc_html_e('Perché si abbina', 'amicidibacco'); ?></strong><p><?php echo esc_html($pairing_note); ?></p></div>
            <?php endif; ?>
            <div class="adb-product__buy"><span class="adb-product__price"><?php echo wp_kses_post($product->get_price_html() . adb_price_details($product)); ?></span><?php adb_card_purchase($product); ?></div>
        </div>
    </article>
    <?php
}

function adb_page_link($key, $fallback = '') {
    $mapping = ['wineries_page_id' => 'archive_produttore', 'story_page_id' => 'page_chi_siamo', 'contact_page_id' => 'page_contatti'];
    if (isset($mapping[$key]) && function_exists('ticinoweb_get_mapped_page_url')) {
        $mapped = ticinoweb_get_mapped_page_url($mapping[$key]);
        if ($mapped) { return $mapped; }
    }
    $id = absint(get_post_meta((int) get_option('page_on_front'), '_adb_' . $key, true));
    return $id ? get_permalink($id) : ($fallback ? home_url($fallback) : home_url('/'));
}

function adb_winery_card($winery) {
    $image = absint(get_post_meta($winery->ID, 'immagine_di_sfondo_sulla_pagina_del_produttore', true)) ?: get_post_thumbnail_id($winery->ID);
    ?><a class="adb-winery" href="<?php echo esc_url(get_permalink($winery)); ?>"><div><?php adb_photo($image, 'large', ['loading' => 'lazy']); ?></div><h2><?php echo esc_html($winery->post_title); ?> <?php echo adb_icon(); ?></h2></a><?php
}

add_shortcode('adb_wineries', function () {
    return adb_render_winery_directory();
});

add_shortcode('adb_collection', function ($atts) {
    $atts = shortcode_atts(['kind' => 'selections'], $atts, 'adb_collection');
    if ('offers' === $atts['kind']) { return adb_render_offers(); }
    return 'selections' === $atts['kind'] ? adb_render_selections() : '';
});

/** The most specific category is the bottle's public category, never a decorative label. */
function adb_product_category_label($product) {
    $terms = get_the_terms($product->get_id(), 'product_cat');
    if (!$terms || is_wp_error($terms)) { return ''; }
    usort($terms, static function ($a, $b) { return count(get_ancestors($b->term_id, 'product_cat')) <=> count(get_ancestors($a->term_id, 'product_cat')); });
    return $terms[0]->name;
}

/** Shared server-rendered wine leaf; the inert pool never fetches unselected pictures. */
function adb_hero_wine_slide($wine, $index = 0) {
    if (!$wine instanceof WC_Product || !$wine->get_image_id()) { return; }
    $cantina = $wine->get_attribute('pa_cantina');
    ?>
    <a class="adb-wine-carousel__slide<?php echo !$index ? ' is-active' : ''; ?>" data-wine-slide="<?php echo esc_attr($index); ?>" data-wine-id="<?php echo esc_attr($wine->get_id()); ?>" data-wine-group="<?php echo esc_attr(adb_hero_wine_group($wine)); ?>" data-wine-image="<?php echo esc_attr($wine->get_image_id()); ?>" href="<?php echo esc_url($wine->get_permalink()); ?>" aria-label="<?php echo esc_attr(trim($wine->get_name() . ($cantina ? ' · ' . $cantina : ''))); ?>"<?php if ($index) { echo ' aria-hidden="true" tabindex="-1" inert'; } ?>>
        <?php echo $wine->get_image('full', ['data-adb-webp' => true, 'sizes' => '(max-width: 760px) min(43vw, 168px), 330px', 'class' => 'adb-wine-carousel__bottle', 'loading' => 'lazy', 'decoding' => 'async', 'alt' => '']); ?>
        <span class="adb-wine-carousel__meta">
            <span class="adb-wine-carousel__identity">
                <span class="adb-wine-carousel__category"><?php echo esc_html(adb_product_category_label($wine)); ?></span>
                <strong data-wine-title><?php echo esc_html($wine->get_name()); ?></strong>
                <?php if ($cantina) : ?><span class="adb-wine-carousel__winery"><?php echo esc_html($cantina); ?></span><?php endif; ?>
            </span>
            <span class="adb-wine-carousel__purchase">
                <span class="adb-wine-carousel__price"><?php echo wp_kses_post($wine->get_price_html() . adb_price_details($wine, false)); ?></span>
                <span class="adb-wine-carousel__link"><?php echo esc_html($wine->is_purchasable() && $wine->is_in_stock() ? __('Scegli e acquista', 'amicidibacco') : __('Scopri il vino', 'amicidibacco')); ?> <?php echo adb_icon(); ?></span>
            </span>
        </span>
    </a>
    <?php
}
