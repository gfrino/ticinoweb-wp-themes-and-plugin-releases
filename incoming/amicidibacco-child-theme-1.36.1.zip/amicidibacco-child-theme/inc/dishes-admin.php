<?php
defined( 'ABSPATH' ) || exit;

/** Install initial dishes once. Subsequent editorial changes, including deletions, are retained. */
function adb_dishes_seed() {
    if ( get_option( 'adb_dishes_seeded' ) || ! post_type_exists( 'adb_dish' ) ) { return; }
    if ( ! add_option( 'adb_dishes_installing', time(), '', false ) ) {
        if ( (int) get_option( 'adb_dishes_installing' ) < time() - 300 ) { delete_option( 'adb_dishes_installing' ); }
        return;
    }
    $defaults = array(
        'Risotto ai funghi' => 'risotto ai porcini, risotti ai funghi, funghi, porcini',
        'Pesce alla griglia' => 'pesce grigliato, pesce alla brace, pesce',
        'Pasta al ragù' => 'ragù, sughi di carne, salse di carne',
        'Tagliere di salumi' => 'salumi, affettati, prosciutto',
        'Frutti di mare' => 'vongole, cozze, molluschi',
        'Bistecca alla brace' => 'bistecca, costata, carne alla griglia, carni alla griglia',
        'Pollo arrosto' => 'pollo, pollame, carni bianche, carne bianca',
        'Formaggi stagionati' => 'formaggio stagionato, formaggi di lunga stagionatura',
        'Fritto di pesce' => 'frittura di pesce, fritto misto di mare, pesce fritto, fritture di pesce',
        'Gamberi alla griglia' => 'gamberi, scampi, crostacei',
        'Spezzatino di selvaggina' => 'selvaggina, cervo, cinghiale',
        'Tartare di manzo' => 'tartare di carne, carne cruda, carpaccio di manzo, tartare di manzo',
        'Verdure grigliate' => 'verdure alla griglia, verdure alla brace, verdure',
        'Formaggi freschi' => 'formaggio fresco, mozzarella, ricotta',
    );
    try {
        $order = 0;
        foreach ( $defaults as $name => $terms ) {
            ++$order;
            if ( get_page_by_path( sanitize_title( $name ), OBJECT, 'adb_dish' ) ) { continue; }
            $id = wp_insert_post( array( 'post_type' => 'adb_dish', 'post_status' => 'publish', 'post_title' => $name, 'menu_order' => $order, 'meta_input' => array( '_adb_dish_terms' => $terms ) ), true );
            if ( is_wp_error( $id ) ) { return; }
        }
        update_option( 'adb_dishes_seeded', 1, false );
    } finally {
        delete_option( 'adb_dishes_installing' );
    }
}
add_action( 'admin_init', static function () {
    if ( current_user_can( 'adb_manage_dishes' ) ) { adb_dishes_seed(); }
} );

add_action( 'add_meta_boxes_adb_dish', static function () {
    add_meta_box( 'adb-dish-wines', __( 'Vini per questo piatto', 'amicidibacco' ), 'adb_dish_editor', 'adb_dish', 'normal', 'high' );
} );

function adb_dish_editor( $post ) {
    global $wpdb;
    $slots = adb_dish_wine_slots( $post->ID );
    $wines = $wpdb->get_results( "SELECT DISTINCT p.ID, p.post_title FROM {$wpdb->posts} p
        JOIN {$wpdb->postmeta} m ON m.post_id=p.ID AND m.meta_key='tipo_di_prodotto' AND m.meta_value='VINO SINGOLO'
        WHERE p.post_type='product' AND p.post_status='publish' AND p.post_password=''"
        . adb_language_predicate( 'p.ID', "'post_product'" ) . ' ORDER BY p.post_title, p.ID' );
    wp_nonce_field( 'adb_edit_dish_' . $post->ID, 'adb_dish_nonce' );
    ?>
    <p><?php esc_html_e( 'Scegli i vini da proporre per questo piatto. Lascia «Automatico» nei posti che vuoi completare con gli abbinamenti delle schede vino.', 'amicidibacco' ); ?></p>
    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,14rem),1fr));gap:12px;margin-block:16px">
        <?php foreach ( $slots as $position => $selected ) : ?>
            <label><strong><?php echo esc_html( sprintf( __( 'Vino %d', 'amicidibacco' ), $position + 1 ) ); ?></strong>
                <select name="adb_dish_wines[]" style="display:block;width:100%;max-width:100%;margin-top:4px">
                    <option value="0"><?php esc_html_e( 'Automatico', 'amicidibacco' ); ?></option>
                    <?php foreach ( $wines as $wine ) : ?>
                        <option value="<?php echo absint( $wine->ID ); ?>" <?php selected( $selected, $wine->ID ); ?>><?php echo esc_html( $wine->post_title . ' · #' . $wine->ID ); ?></option>
                    <?php endforeach; ?>
                </select>
            </label>
        <?php endforeach; ?>
    </div>
    <p class="description"><?php esc_html_e( 'Se un vino è esaurito o selezionato due volte, il posto viene assegnato automaticamente a un altro vino disponibile.', 'amicidibacco' ); ?></p>
    <p><label for="adb-dish-terms"><strong><?php esc_html_e( 'Ingredienti e nomi alternativi (facoltativi)', 'amicidibacco' ); ?></strong></label></p>
    <input type="text" class="large-text" id="adb-dish-terms" name="adb_dish_terms" maxlength="500" value="<?php echo esc_attr( get_post_meta( $post->ID, '_adb_dish_terms', true ) ); ?>">
    <p class="description"><?php esc_html_e( 'Separa le voci con una virgola, ad esempio funghi, porcini. Il nome del piatto viene cercato sempre.', 'amicidibacco' ); ?></p>
    <?php
}

add_action( 'save_post_adb_dish', static function ( $id ) {
    $nonce = $_POST['adb_dish_nonce'] ?? '';
    if ( ! is_string( $nonce ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $nonce ) ), 'adb_edit_dish_' . $id ) || ! current_user_can( 'edit_post', $id ) || wp_is_post_autosave( $id ) ) { return; }
    $slots = adb_dish_wine_slots( $id );
    $input = $_POST['adb_dish_wines'] ?? null;
    // An editor tab opened before the update can still submit the original first field.
    if ( null === $input && isset( $_POST['adb_dish_wine'] ) ) {
        $input = array( $_POST['adb_dish_wine'], $slots[1], $slots[2] );
    }
    // Keep the fourth choice when saving from an older three-field form.
    if ( is_array( $input ) && count( $input ) === 3 ) { $input[] = $slots[3]; }
    if ( is_array( $input ) && count( $input ) === ADB_DISH_WINE_LIMIT ) {
        $seen = array();
        foreach ( array_values( $input ) as $position => $value ) {
            $wine = is_scalar( $value ) ? absint( $value ) : 0;
            if ( $wine && ( isset( $seen[ $wine ] ) || 'product' !== get_post_type( $wine ) || 'VINO SINGOLO' !== get_post_meta( $wine, 'tipo_di_prodotto', true ) ) ) {
                $wine = 0;
            }
            $slots[ $position ] = $wine;
            $seen[ $wine ] = true;
        }
        update_post_meta( $id, '_adb_dish_wine', $slots );
    }
    if ( isset( $_POST['adb_dish_terms'] ) && is_string( $_POST['adb_dish_terms'] ) ) {
        update_post_meta( $id, '_adb_dish_terms', mb_substr( sanitize_text_field( wp_unslash( $_POST['adb_dish_terms'] ) ), 0, 500 ) );
    }
} );

add_filter( 'manage_adb_dish_posts_columns', static function ( $columns ) {
    $columns['adb_wine'] = __( 'Vini scelti', 'amicidibacco' );
    return $columns;
} );
add_action( 'manage_adb_dish_posts_custom_column', static function ( $column, $id ) {
    if ( 'adb_wine' !== $column ) { return; }
    $names = array();
    foreach ( adb_dish_wine_slots( $id ) as $wine ) {
        if ( $wine && 'publish' === get_post_status( $wine ) ) { $names[] = get_the_title( $wine ); }
    }
    echo esc_html( $names ? implode( ', ', $names ) : __( 'Selezione automatica', 'amicidibacco' ) );
}, 10, 2 );
