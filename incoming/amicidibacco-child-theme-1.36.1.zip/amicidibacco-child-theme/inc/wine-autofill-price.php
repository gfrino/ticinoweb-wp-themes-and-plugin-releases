<?php
/** A draft price reference from comparable bottles in this shop's own catalogue. */
defined( 'ABSPATH' ) || exit;

function adb_fill_bottle_ml( $text ) {
    if ( ! preg_match( '/^(\d+(?:[.,]\d+)?)\s*(ml|cl|l)\.?$/i', trim( $text ), $size ) ) { return 0; }
    $units = array( 'ml' => 1, 'cl' => 10, 'l' => 1000 );
    return (int) round( (float) str_replace( ',', '.', $size[1] ) * $units[ strtolower( $size[2] ) ] );
}

function adb_fill_price_reference( $id, $producer_id, $result, $docs ) {
    $draft = wc_get_product( $id );
    $fields = $result['fields'];
    if ( 'CHF' !== get_woocommerce_currency() || ! $draft || ! $draft->is_type( 'simple' ) || '' !== $draft->get_regular_price( 'edit' ) || empty( $fields['categoria'] ) ) { return null; }
    $category = get_term_by( 'name', $fields['categoria'], 'product_cat' );
    $winery = adb_fill_producer_term( $producer_id );
    if ( ! $category || ! $winery ) { return null; }

    // Prefer an explicit shop format. Otherwise accept a single documented bottle size.
    $formats = wc_get_product_terms( $id, 'pa_dimensione', array( 'fields' => 'names' ) );
    if ( ! $formats ) {
        foreach ( $docs as $doc ) {
            if ( empty( $doc['matched'] ) ) { continue; }
            preg_match_all( '/(?:^|\n)\s*(?:bottiglia|formato|bottle size)\s*[:\n]\s*(\d+(?:[.,]\d+)?\s*(?:ml|cl|l))\.?\s*(?=\n|$)/iu', $doc['text'], $match );
            $formats = array_merge( $formats, $match[1] );
        }
    }
    $sizes = array_unique( array_map( 'adb_fill_bottle_ml', $formats ) );
    if ( 1 !== count( $sizes ) || ! reset( $sizes ) ) { return null; }
    $ml = reset( $sizes );
    $matches = get_posts( array(
        'post_type' => 'product', 'post_status' => 'publish', 'posts_per_page' => -1, 'fields' => 'ids',
        'tax_query' => array(
            array( 'taxonomy' => 'pa_cantina', 'terms' => array( $winery ) ),
            array( 'taxonomy' => 'product_cat', 'terms' => array( (int) $category->term_id ) ),
        ),
    ) );
    $prices = array();
    foreach ( $matches as $match_id ) {
        $wine = wc_get_product( $match_id );
        if ( ! $wine || ! $wine->is_visible() ) { continue; }
        $candidates = $wine->is_type( 'variable' ) ? $wine->get_children() : array( $match_id );
        $values = array();
        foreach ( $candidates as $candidate_id ) {
            $candidate = wc_get_product( $candidate_id );
            if ( ! $candidate || 'publish' !== $candidate->get_status() ) { continue; }
            $size = $candidate->get_attribute( 'pa_dimensione' );
            if ( adb_fill_bottle_ml( $size ) !== $ml ) { continue; }
            $regular = (float) $candidate->get_regular_price( 'edit' );
            if ( $regular > 0 ) { $values[] = $regular; }
        }
        if ( $values ) { $prices[ $match_id ] = adb_fill_price_median( $values ); }
    }
    if ( ! $prices ) { return null; }
    return array( 'amount' => wc_format_decimal( round( adb_fill_price_median( $prices ) * 20 ) / 20, 2 ), 'ml' => $ml, 'products' => array_keys( $prices ) );
}

function adb_fill_price_median( $prices ) {
    sort( $prices, SORT_NUMERIC );
    $middle = intdiv( count( $prices ), 2 );
    return count( $prices ) % 2 ? $prices[ $middle ] : ( $prices[ $middle - 1 ] + $prices[ $middle ] ) / 2;
}
