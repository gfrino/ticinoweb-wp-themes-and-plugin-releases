<?php
/** An editorial selection of one published winery from the current site's directory. */
defined( 'ABSPATH' ) || exit;

add_action( 'admin_menu', static function () {
    $label = __( 'Cantina del mese', 'amicidibacco' );
    add_submenu_page( 'edit.php?post_type=produttore', $label, $label, 'publish_pages', 'adb-monthly-winery', 'adb_monthly_winery_settings' );
} );

function adb_monthly_winery_record( $id ) {
    $post = $id ? get_post( $id ) : null;
    return $post && 'produttore' === $post->post_type && 'publish' === $post->post_status && '' === $post->post_password ? $post : null;
}

function adb_monthly_winery_settings() {
    $settings = get_option( 'adb_monthly_winery', array() );
    $wineries = array_filter( adb_admin_record_choices( 'produttore' ), static function ( $post ) { return '' === $post->post_password; } );
    ?>
    <div class="wrap">
        <h1><?php esc_html_e( 'Cantina del mese', 'amicidibacco' ); ?></h1>
        <?php if ( isset( $_GET['updated'] ) ) : ?>
            <div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'Cantina del mese aggiornata.', 'amicidibacco' ); ?></p></div>
        <?php endif; ?>
        <form action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" method="post">
            <input type="hidden" name="action" value="adb_save_monthly_winery">
            <?php wp_nonce_field( 'adb_save_monthly_winery' ); ?>
            <table class="form-table" role="presentation"><tbody>
                <tr><th scope="row"><label for="adb-monthly-winery-id"><?php esc_html_e( 'Cantina', 'amicidibacco' ); ?></label></th>
                    <td><select id="adb-monthly-winery-id" name="winery_id" aria-describedby="adb-monthly-choice-help">
                        <option value="0"><?php esc_html_e( 'Nessuna cantina in evidenza', 'amicidibacco' ); ?></option>
                        <?php foreach ( $wineries as $winery ) : ?>
                            <option value="<?php echo (int) $winery->ID; ?>" <?php selected( $settings['id'] ?? 0, $winery->ID ); ?>><?php echo esc_html( get_the_title( $winery ) ); ?></option>
                        <?php endforeach; ?>
                    </select><p id="adb-monthly-choice-help" class="description"><?php esc_html_e( 'Nome, fotografia e collegamento provengono dalla scheda della cantina.', 'amicidibacco' ); ?></p></td></tr>
                <tr><th scope="row"><label for="adb-monthly-note"><?php esc_html_e( 'Nota dell’enoteca', 'amicidibacco' ); ?></label></th>
                    <td><textarea id="adb-monthly-note" name="note" class="large-text" rows="4" aria-describedby="adb-monthly-note-help"><?php echo esc_textarea( $settings['note'] ?? '' ); ?></textarea>
                    <p id="adb-monthly-note-help" class="description"><?php esc_html_e( 'Racconta perché avete scelto questa cantina. Se lasci il campo vuoto, appare un estratto della sua storia.', 'amicidibacco' ); ?></p></td></tr>
            </tbody></table>
            <?php submit_button(); ?>
        </form>
    </div>
    <?php
}

add_action( 'admin_post_adb_save_monthly_winery', static function () {
    if ( ! current_user_can( 'publish_pages' ) ) { wp_die( esc_html__( 'Non hai i permessi per questa modifica.', 'amicidibacco' ), '', 403 ); }
    check_admin_referer( 'adb_save_monthly_winery' );
    $id = filter_var( wp_unslash( $_POST['winery_id'] ?? '' ), FILTER_VALIDATE_INT, array( 'options' => array( 'min_range' => 0 ) ) );
    if ( false === $id || ( $id && ! adb_monthly_winery_record( $id ) ) || ! is_string( $_POST['note'] ?? null ) ) {
        wp_die( esc_html__( 'Verifica la cantina selezionata e riprova.', 'amicidibacco' ), '', 400 );
    }
    update_option( 'adb_monthly_winery', array( 'id' => $id, 'note' => sanitize_textarea_field( wp_unslash( $_POST['note'] ) ) ), false );
    do_action( 'litespeed_purge_url', home_url( '/' ) );
    wp_safe_redirect( admin_url( 'edit.php?post_type=produttore&page=adb-monthly-winery&updated=1' ) );
    exit;
} );

function adb_monthly_winery_render() {
    $settings = get_option( 'adb_monthly_winery', array() );
    $winery = adb_monthly_winery_record( $settings['id'] ?? 0 );
    if ( ! $winery ) { return; }
    $photo = adb_valid_image_id( get_post_meta( $winery->ID, 'immagine_di_sfondo_sulla_pagina_del_produttore', true ) );
    $note = trim( $settings['note'] ?? '' );
    if ( '' === $note ) {
        $note = wp_trim_words( wp_strip_all_tags( strip_shortcodes( $winery->post_excerpt ?: $winery->post_content ), true ), 40, '…' );
    }
    ?>
    <section id="cantina-del-mese" class="adb-monthly" aria-labelledby="adb-monthly-title">
        <div class="adb-wrap adb-monthly__layout">
            <?php if ( $photo ) : ?>
                <figure class="adb-monthly__photo"><?php adb_photo( $photo, 'large', array( 'loading' => 'lazy', 'decoding' => 'async', 'sizes' => '(max-width: 760px) 94vw, (max-width: 1600px) 48vw, 760px' ) ); ?></figure>
            <?php endif; ?>
            <div class="adb-monthly__copy">
                <p class="adb-kicker"><?php esc_html_e( 'Cantina del mese', 'amicidibacco' ); ?></p>
                <h2 id="adb-monthly-title"><?php echo esc_html( get_the_title( $winery ) ); ?></h2>
                <?php if ( '' !== $note ) : ?><p class="adb-monthly__note"><?php echo esc_html( $note ); ?></p><?php endif; ?>
                <a class="adb-link" href="<?php echo esc_url( get_permalink( $winery ) ); ?>"><?php esc_html_e( 'Scopri la cantina', 'amicidibacco' ); ?> <?php echo adb_icon(); ?></a>
            </div>
        </div>
    </section>
    <?php
}
