<?php
/** Dish suggestions are editorial content. Wines and tasting notes stay in WooCommerce. */
defined( 'ABSPATH' ) || exit;

const ADB_DISH_WINE_LIMIT = 4;

add_filter( 'user_has_cap', static function ( $caps ) {
    $caps['adb_manage_dishes'] = ! empty( $caps['edit_others_posts'] ) || ! empty( $caps['manage_woocommerce'] );
    return $caps;
} );

add_action( 'init', static function () {
    if ( ! function_exists( 'WC' ) ) { return; }
    $labels = array(
        'name' => __( 'Piatti a tavola', 'amicidibacco' ), 'singular_name' => __( 'Piatto', 'amicidibacco' ),
        'add_new' => __( 'Aggiungi piatto', 'amicidibacco' ), 'add_new_item' => __( 'Aggiungi piatto', 'amicidibacco' ),
        'edit_item' => __( 'Modifica piatto', 'amicidibacco' ), 'all_items' => __( 'Piatti a tavola', 'amicidibacco' ),
        'search_items' => __( 'Cerca piatti', 'amicidibacco' ), 'not_found' => __( 'Nessun piatto trovato.', 'amicidibacco' ),
    );
    $capabilities = array_fill_keys( array( 'edit_posts', 'edit_others_posts', 'edit_published_posts', 'edit_private_posts', 'publish_posts', 'delete_posts', 'delete_others_posts', 'delete_published_posts', 'delete_private_posts', 'read_private_posts', 'create_posts' ), 'adb_manage_dishes' );
    register_post_type( 'adb_dish', array(
        'labels' => $labels, 'public' => false, 'show_ui' => true, 'show_in_admin_bar' => false,
        'show_in_menu' => current_user_can( 'manage_woocommerce' ) ? 'woocommerce' : true,
        'menu_icon' => 'dashicons-food', 'supports' => array( 'title' ), 'rewrite' => false,
        'capability_type' => array( 'adb_dish', 'adb_dishes' ), 'map_meta_cap' => true, 'capabilities' => $capabilities,
    ) );
} );

function adb_dishes_list() {
    return get_posts( array( 'post_type' => 'adb_dish', 'post_status' => 'publish', 'numberposts' => -1, 'orderby' => array( 'menu_order' => 'ASC', 'title' => 'ASC' ) ) );
}

function adb_dish_normalize( $text ) {
    $text = strtolower( remove_accents( wp_strip_all_tags( html_entity_decode( $text, ENT_QUOTES, 'UTF-8' ) ) ) );
    return trim( preg_replace( '/[^a-z0-9]+/', ' ', $text ) );
}

function adb_dish_terms( $dish ) {
    $aliases = explode( ',', (string) get_post_meta( $dish->ID, '_adb_dish_terms', true ) );
    return array_values( array_unique( array_filter( array_map( 'adb_dish_normalize', array_merge( array( $dish->post_title ), $aliases ) ) ) ) );
}

/** Require all significant words for an unordered match. Keep originals for the explanation. */
function adb_dish_score( $text, $term ) {
    if ( '' === $term ) { return 0; }
    $padded = ' ' . $text . ' ';
    $words = array_values( array_diff( explode( ' ', $term ), array( 'a','al','ai','alla','alle','agli','all','allo','con','di','da','del','della','e','i','il','la','le','in','un','una','per' ) ) );
    if ( ! $words ) { return 0; }
    if ( false !== strpos( $padded, ' ' . $term . ' ' ) ) { return 10 + count( $words ) * 4; }
    return count( $words ) > 1 && ! array_diff( $words, explode( ' ', $text ) ) ? count( $words ) * 3 : 0;
}

/** The original editor stored only the first wine as a scalar. Zero means automatic. */
function adb_dish_wine_slots( $dish_id ) {
    $saved = (array) get_post_meta( $dish_id, '_adb_dish_wine', true );
    return array_map( 'absint', array_pad( array_slice( array_values( $saved ), 0, ADB_DISH_WINE_LIMIT ), ADB_DISH_WINE_LIMIT, 0 ) );
}

/** Explain a documented match, using the wine's palate only when its descriptors support the comparison. */
function adb_dish_reason( $id, $terms, $query, $manual ) {
    $note = wp_strip_all_tags( adb_product_field_value( $id, 'abbinamenti_gastronomici' ) );
    $palate = wp_strip_all_tags( adb_product_field_value( $id, 'al_palato' ) );
    $best = '';
    $best_score = 0;
    foreach ( preg_split( '/(?<=[.!?])\s+|[;\r\n]+/u', $note, -1, PREG_SPLIT_NO_EMPTY ) as $sentence ) {
        $text = adb_dish_normalize( $sentence );
        foreach ( $terms as $index => $term ) {
            $score = adb_dish_score( $text, $term );
            if ( $score && 0 === $index ) { $score += 8; }
            if ( $score > $best_score ) { $best_score = $score; $best = trim( $sentence ); }
        }
    }
    if ( ! $best && $manual ) {
        $lead = sprintf( __( 'L’enoteca ha scelto questa bottiglia per «%s».', 'amicidibacco' ), $query );
        return trim( $lead . ' ' . wp_trim_words( $palate, 22, '…' ) );
    }
    $food = implode( ' ', $terms );
    $taste = adb_dish_normalize( $palate );
    if ( preg_match( '/\b(ragu|carne|carni|bistecca|selvaggina|cinghiale|brasato)\b/', $food ) ) {
        if ( preg_match( '/tannin\w* (?:\w+ ){0,2}(?:morbid|vellutat)/', $taste ) ) {
            return sprintf( __( 'I tannini morbidi accompagnano la parte succulenta della carne e lasciano spazio al sapore del piatto. È il tratto che lo rende adatto a «%s».', 'amicidibacco' ), $query );
        }
        if ( preg_match( '/\b(pien[oa]|strutturat[oa]|corpos[oa])\b/', $taste ) ) {
            return sprintf( __( 'Il sorso pieno tiene testa al sapore della carne. Con «%s» il vino mantiene la sua presenza anche dopo il boccone.', 'amicidibacco' ), $query );
        }
        if ( preg_match( '/\b(rotond[oa]|vellutat[oa]|morbid[oa])\b/', $taste ) ) {
            return sprintf( __( 'Con «%s» la morbidezza del sorso accompagna la consistenza della carne e ne arrotonda il finale.', 'amicidibacco' ), $query );
        }
    }
    if ( preg_match( '/\b(fritto|frittura|salumi|formaggi|formaggio)\b/', $food ) && preg_match( '/\b(fresc[oa]|freschezza|acidita vivace)\b/', $taste ) ) {
        return sprintf( __( 'La freschezza del vino ravviva il palato fra un boccone e l’altro di «%s».', 'amicidibacco' ), $query );
    }
    if ( preg_match( '/\b(pesce|crostacei|gamberi|molluschi|mare)\b/', $food ) && preg_match( '/\b(sapid[oa]|sapidita|salin[oa])\b/', $taste ) ) {
        return sprintf( __( 'La vena sapida dà risalto al gusto delicato del pesce. Con «%s» accompagna il boccone fino al finale.', 'amicidibacco' ), $query );
    }
    if ( preg_match( '/funghi|porcini/', $food ) && preg_match( '/persisten|finale lungo/', $taste ) ) {
        return sprintf( __( 'Il gusto dei funghi rimane a lungo sul palato. Il finale persistente del vino accompagna «%s» anche dopo il boccone.', 'amicidibacco' ), $query );
    }
    // Preserve the producer's relevant sentence when no more specific sensory connection is supported.
    return trim( wp_trim_words( $best ?: $note, 28, '…' ) . ' ' . wp_trim_words( $palate, 16, '…' ) );
}

function adb_dish_recommend( $query ) {
    global $wpdb;
    $term = adb_dish_normalize( $query );
    if ( strlen( $term ) < 2 ) { return array(); }
    $terms = array( $term );
    $slots = array_fill( 0, ADB_DISH_WINE_LIMIT, 0 );
    $matching_alias = null;
    $alias_count = 0;
    $dishes = adb_dishes_list();
    // A published dish name always wins over another dish's ingredient synonym.
    foreach ( $dishes as $dish ) {
        $dish_terms = adb_dish_terms( $dish );
        if ( adb_dish_normalize( $dish->post_title ) === $term ) {
            $terms = $dish_terms;
            $slots = adb_dish_wine_slots( $dish->ID );
            $alias_count = 0;
            break;
        }
        if ( in_array( $term, $dish_terms, true ) ) {
            $matching_alias = $dish;
            ++$alias_count;
        }
    }
    if ( 1 === $alias_count ) {
        $terms = array_values( array_unique( array_merge( array( $term ), adb_dish_terms( $matching_alias ) ) ) );
        $slots = adb_dish_wine_slots( $matching_alias->ID );
    }

    $chosen = array();
    foreach ( $slots as $position => $wine_id ) {
        if ( $wine_id && ! isset( $chosen[ $wine_id ] ) && adb_pair_is_wine( $wine_id ) ) {
            $chosen[ $wine_id ] = adb_dish_reason( $wine_id, $terms, $query, true );
        } else {
            $slots[ $position ] = 0;
        }
    }
    if ( count( $chosen ) === count( $slots ) ) { return $chosen; }

    $rows = $wpdb->get_results( "SELECT p.ID, m.meta_value AS note FROM {$wpdb->posts} p
        JOIN {$wpdb->postmeta} m ON m.post_id=p.ID AND m.meta_key='abbinamenti_gastronomici'
        JOIN {$wpdb->wc_product_meta_lookup} stock ON stock.product_id=p.ID AND stock.stock_status='instock'
        WHERE p.post_type='product' AND p.post_status='publish' AND p.post_password='' AND m.meta_value<>''
        AND EXISTS (SELECT 1 FROM {$wpdb->postmeta} w WHERE w.post_id=p.ID AND w.meta_key='tipo_di_prodotto' AND w.meta_value='VINO SINGOLO')"
        . adb_language_predicate( 'p.ID', "'post_product'" ) . ' ORDER BY p.ID' );
    $scores = array();
    foreach ( $rows as $row ) {
        $note = adb_dish_normalize( $row->note );
        $score = 0;
        foreach ( $terms as $index => $phrase ) {
            $match = adb_dish_score( $note, $phrase );
            if ( $match && 0 === $index ) { $match += 8; }
            $score = max( $score, $match );
        }
        if ( $score ) { $scores[ $row->ID ] = $score; }
    }
    arsort( $scores, SORT_NUMERIC );
    $automatic = array();
    foreach ( array_keys( $scores ) as $id ) {
        if ( isset( $chosen[ $id ] ) ) { continue; }
        $note = adb_product_field_value( $id, 'abbinamenti_gastronomici' );
        if ( ! $note || ! adb_pair_is_wine( $id ) ) { continue; }
        $automatic[] = $id;
        $chosen[ $id ] = adb_dish_reason( $id, $terms, $query, false );
        if ( count( $chosen ) === count( $slots ) ) { break; }
    }
    $result = array();
    foreach ( $slots as $id ) {
        $id = $id ?: array_shift( $automatic );
        if ( $id ) { $result[ $id ] = $chosen[ $id ]; }
    }
    return $result;
}

function adb_dish_results( $query ) {
    $wines = adb_dish_recommend( $query );
    if ( ! $wines ) {
        echo '<p>' . esc_html__( 'Nessun abbinamento disponibile per questo piatto. Prova un ingrediente o scegli un altro piatto.', 'amicidibacco' ) . '</p>';
        return;
    }
    echo '<h3 tabindex="-1">' . esc_html( sprintf( __( 'I vini per «%s»', 'amicidibacco' ), $query ) ) . '</h3><div class="adb-dishes__wines">';
    foreach ( $wines as $id => $note ) {
        adb_product_card( wc_get_product( $id ), 'adb-dish-wine', $note );
    }
    echo '</div>';
}

function adb_dish_query() {
    $raw = $_GET['piatto'] ?? '';
    return is_string( $raw ) ? mb_substr( sanitize_text_field( wp_unslash( $raw ) ), 0, 100 ) : '';
}

add_action( 'wc_ajax_adb_dish_wines', static function () {
    ob_start();
    adb_dish_results( adb_dish_query() );
    wp_send_json_success( array( 'html' => ob_get_clean() ) );
} );

function adb_dishes_home() {
    if ( ! function_exists( 'WC' ) ) { return; }
    $dishes = adb_dishes_list();
    if ( ! $dishes ) { return; }
    $uri = get_stylesheet_directory_uri();
    wp_enqueue_script( 'adb-dishes', $uri . '/assets/js/dishes.js', array(), ADB_VERSION, true );
    wp_enqueue_script( 'adb-card-purchase', $uri . '/assets/js/card-purchase.js', array( 'adb-variation-select', 'wc-cart-fragments' ), ADB_VERSION, true );
    wp_enqueue_script( 'wc-add-to-cart' );
    $query = adb_dish_query();
    ?>
    <section class="adb-dishes adb-wrap" id="a-tavola" aria-labelledby="adb-dishes-title">
        <h2 id="adb-dishes-title"><?php esc_html_e( 'Cosa porti a tavola?', 'amicidibacco' ); ?></h2>
        <form action="<?php echo esc_url( home_url( '/#a-tavola' ) ); ?>" method="get" data-endpoint="<?php echo esc_url( WC_AJAX::get_endpoint( 'adb_dish_wines' ) ); ?>">
            <label for="adb-dish-input"><?php esc_html_e( 'Scrivi il tuo piatto o scegline uno qui sotto.', 'amicidibacco' ); ?></label>
            <div class="adb-dishes__search"><input type="search" id="adb-dish-input" name="piatto" maxlength="100" value="<?php echo esc_attr( $query ); ?>" placeholder="<?php esc_attr_e( 'Es. risotto ai funghi', 'amicidibacco' ); ?>" required><button class="adb-button" type="submit"><?php esc_html_e( 'Trova il vino', 'amicidibacco' ); ?> <?php echo adb_icon(); ?></button></div>
        </form>
        <div class="adb-dishes__choices">
        <?php foreach ( $dishes as $dish ) : ?>
            <a href="<?php echo esc_url( add_query_arg( 'piatto', rawurlencode( $dish->post_title ), home_url( '/' ) ) . '#a-tavola' ); ?>" data-dish="<?php echo esc_attr( $dish->post_title ); ?>"><?php echo esc_html( $dish->post_title ); ?></a>
        <?php endforeach; ?>
        </div>
        <p data-dish-status role="status" data-loading="<?php esc_attr_e( 'Cerchiamo i vini…', 'amicidibacco' ); ?>" data-error="<?php esc_attr_e( 'Ricerca non riuscita. Riprova.', 'amicidibacco' ); ?>"></p>
        <div data-dish-results tabindex="-1"><?php if ( '' !== $query ) { adb_dish_results( $query ); } ?></div>
    </section>
    <?php
}
