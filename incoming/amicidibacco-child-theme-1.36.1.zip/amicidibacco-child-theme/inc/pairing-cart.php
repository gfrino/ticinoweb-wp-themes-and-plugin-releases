<?php
/** Add the shopper's selection as ordinary WooCommerce cart lines. */
defined( 'ABSPATH' ) || exit;

/**
 * WooCommerce reads the session before dispatching its AJAX endpoint. Serialize
 * competing pairing requests for an existing cart before either can read it.
 */
add_action( 'before_woocommerce_init', static function () {
    if ( 'adb_add_pairing' !== ( $_GET['wc-ajax'] ?? '' ) || 'POST' !== ( $_SERVER['REQUEST_METHOD'] ?? '' ) ) { return; }
    $cookie_name = apply_filters( 'woocommerce_cookie', 'wp_woocommerce_session_' . COOKIEHASH );
    $session_key = get_current_user_id() ?: ( $_COOKIE[ $cookie_name ] ?? '' );
    if ( ! is_scalar( $session_key ) || '' === $session_key ) { return; }
    global $wpdb;
    $lock = 'adb_pair_' . substr( hash( 'sha256', $wpdb->prefix . '|' . $session_key ), 0, 54 );
    if ( '1' !== (string) $wpdb->get_var( $wpdb->prepare( 'SELECT GET_LOCK(%s, 3)', $lock ) ) ) {
        wp_send_json_error( array( 'message' => __( 'Il carrello si sta aggiornando. Riprova tra un momento.', 'amicidibacco' ) ), 409 );
    }
    // Release after WooCommerce saves the session on shutdown.
    add_action( 'shutdown', static function () use ( $wpdb, $lock ) {
        $wpdb->get_var( $wpdb->prepare( 'SELECT RELEASE_LOCK(%s)', $lock ) );
    }, PHP_INT_MAX );
} );

function adb_pair_cart_error( $message, $status = 400 ) {
    wp_send_json_error( array( 'message' => $message ), $status );
}

// A bottle of the featured wine in any format or vintage already satisfies the selection.
function adb_pair_cart_has_wine( $cart, $owner ) {
    foreach ( $cart->get_cart() as $line ) {
        if ( (int) $line['product_id'] === $owner && $line['quantity'] > 0 ) { return true; }
    }
    return false;
}

// The product page may be cached. Read this shopper's cart separately.
add_action( 'wc_ajax_adb_pair_cart_state', static function () {
    $owner = absint( isset( $_GET['product_id'] ) && is_string( $_GET['product_id'] ) ? $_GET['product_id'] : 0 );
    nocache_headers();
    if ( ! $owner || ! WC()->cart ) { adb_pair_cart_error( __( 'Carrello non disponibile.', 'amicidibacco' ) ); }
    wp_send_json_success( array( 'in_cart' => adb_pair_cart_has_wine( WC()->cart, $owner ) ) );
} );

/** Validate the exact submitted native product and variation before modifying the cart. */
function adb_pair_cart_choice( $item, $allowed ) {
    $invalid = __( 'La selezione è cambiata. Ricarica la scheda e scegli di nuovo i vini.', 'amicidibacco' );
    if ( ! is_array( $item ) || ! isset( $item['id'] ) || ! is_int( $item['id'] ) || ! in_array( $item['id'], $allowed, true ) ) {
        adb_pair_cart_error( $invalid );
    }
    $id = $item['id'];
    $wine = wc_get_product( $id );
    $variation_id = $item['variation_id'] ?? 0;
    $attributes = $item['attributes'] ?? array();
    if ( ! is_int( $variation_id ) || $variation_id < 0 || ! is_array( $attributes ) || ! $wine || ! $wine->is_type( array( 'simple', 'variable' ) ) || 'publish' !== $wine->get_status() || ! $wine->is_purchasable() || ! $wine->is_in_stock() ) {
        adb_pair_cart_error( $invalid );
    }
    if ( $wine->is_type( 'simple' ) ) {
        if ( $variation_id || $attributes ) { adb_pair_cart_error( $invalid ); }
    } else {
        $variation = $variation_id ? wc_get_product( $variation_id ) : false;
        if ( ! $variation || ! $variation->is_type( 'variation' ) || (int) $variation->get_parent_id() !== $id || ! $variation->variation_is_active() || ! $variation->variation_is_visible() || ! $variation->is_purchasable() || 'instock' !== $variation->get_stock_status() || ! $variation->has_enough_stock( 1 ) || $variation->is_on_backorder( 1 ) ) {
            adb_pair_cart_error( __( 'Una variante selezionata non è disponibile. Scegli nuovamente le opzioni del vino.', 'amicidibacco' ) );
        }
        $expected = $variation->get_variation_attributes();
        if ( array_diff_key( $expected, $attributes ) || array_diff_key( $attributes, $expected ) ) {
            adb_pair_cart_error( __( 'Completa le opzioni di ogni vino selezionato.', 'amicidibacco' ) );
        }
        foreach ( $attributes as $key => $value ) {
            if ( ! is_string( $value ) || '' === $value || strlen( $value ) > 512 ) { adb_pair_cart_error( $invalid ); }
            // WooCommerce validates actual option values, including "any" variations, in add_to_cart().
            $attributes[ $key ] = 0 === strpos( $key, 'attribute_pa_' ) ? sanitize_title( $value ) : wc_clean( $value );
        }
    }
    return compact( 'id', 'variation_id', 'attributes' );
}

add_action( 'wc_ajax_adb_add_pairing', static function () {
    if ( 'POST' !== ( $_SERVER['REQUEST_METHOD'] ?? '' ) ) {
        adb_pair_cart_error( __( 'Richiesta non valida.', 'amicidibacco' ), 405 );
    }
    $nonce = $_POST['nonce'] ?? '';
    if ( ! is_string( $nonce ) || ! wp_verify_nonce( wp_unslash( $nonce ), 'adb_add_pairing' ) ) {
        adb_pair_cart_error( __( 'La sessione è scaduta. Ricarica la pagina per aggiornare il carrello.', 'amicidibacco' ), 403 );
    }
    $request_id = $_POST['request_id'] ?? '';
    $owner = isset( $_POST['product_id'] ) && is_string( $_POST['product_id'] ) && ctype_digit( $_POST['product_id'] ) ? (int) $_POST['product_id'] : 0;
    $json = isset( $_POST['items'] ) && is_string( $_POST['items'] ) ? wp_unslash( $_POST['items'] ) : '';
    $items = strlen( $json ) <= 12000 ? json_decode( $json, true, 12 ) : null;
    if ( ! is_string( $request_id ) || ! preg_match( '/\A[A-Za-z0-9_-]{8,100}\z/', $request_id ) || ! $owner || ! is_array( $items ) || ! $items || count( $items ) > 3 || array_keys( $items ) !== range( 0, count( $items ) - 1 ) ) {
        adb_pair_cart_error( __( 'Seleziona da una a tre bottiglie.', 'amicidibacco' ) );
    }

    $cart = WC()->cart;
    $session = WC()->session;
    if ( ! $session || ! $cart ) { adb_pair_cart_error( __( 'Carrello temporaneamente non disponibile.', 'amicidibacco' ), 503 ); }
    $receipts = (array) $session->get( 'adb_pair_receipts', array() );
    $signature = hash( 'sha256', $owner . '|' . $json );
    if ( isset( $receipts[ $request_id ] ) ) {
        $receipt = $receipts[ $request_id ];
        $previous_signature = is_array( $receipt ) ? $receipt['signature'] : $receipt;
        if ( $previous_signature !== $signature ) {
            adb_pair_cart_error( __( 'La selezione è cambiata. Riprova.', 'amicidibacco' ), 409 );
        }
        wp_send_json_success( array( 'count' => $cart->get_cart_contents_count(), 'added' => is_array( $receipt ) ? $receipt['added'] : count( $items ), 'in_cart' => adb_pair_cart_has_wine( $cart, $owner ), 'cart_url' => wc_get_cart_url() ) );
    }

    if ( ! adb_pair_is_wine( $owner ) ) { adb_pair_cart_error( __( 'Questo vino non è disponibile.', 'amicidibacco' ) ); }
    $suggestions = adb_pair_recommendations( $owner );
    if ( ! $suggestions ) { adb_pair_cart_error( __( 'Gli abbinamenti sono cambiati. Ricarica la scheda del vino.', 'amicidibacco' ) ); }
    $allowed = array_merge( array( $owner ), array_map( 'intval', array_column( $suggestions, 'id' ) ) );
    $choices = array();
    $seen = array();
    $in_cart = adb_pair_cart_has_wine( $cart, $owner );
    foreach ( $items as $item ) {
        $id = is_array( $item ) ? ( $item['id'] ?? null ) : null;
        if ( ! is_int( $id ) || isset( $seen[ $id ] ) ) { adb_pair_cart_error( __( 'Seleziona ogni vino una sola volta.', 'amicidibacco' ) ); }
        $seen[ $id ] = true;
        if ( $owner === $id && $in_cart ) { continue; }
        $choices[] = adb_pair_cart_choice( $item, $allowed );
    }

    $before = $cart->get_cart();
    $coupons = $cart->get_applied_coupons();
    $removed = $cart->get_removed_cart_contents();
    $notices = wc_get_notices();
    try {
        foreach ( $choices as $choice ) {
            $product = wc_get_product( $choice['variation_id'] ?: $choice['id'] );
            $in_cart = $cart->get_cart_item_quantities();
            if ( $product->is_on_backorder( 1 + ( $in_cart[ $product->get_stock_managed_by_id() ] ?? 0 ) ) ) {
                wc_add_notice( sprintf( __( 'La quantità disponibile di %s non basta per questa selezione.', 'amicidibacco' ), $product->get_name() ), 'error' );
                throw new RuntimeException( 'pairing_stock_changed' );
            }
            $valid = apply_filters( 'woocommerce_add_to_cart_validation', true, $choice['id'], 1, $choice['variation_id'], $choice['attributes'], array() );
            $key = $valid ? $cart->add_to_cart( $choice['id'], 1, $choice['variation_id'], $choice['attributes'] ) : false;
            if ( ! $key || (float) $cart->get_cart_item( $key )['quantity'] !== 1.0 + (float) ( $before[ $key ]['quantity'] ?? 0 ) ) {
                throw new RuntimeException( 'pairing_cart_rejected' );
            }
        }
        foreach ( $choices as $choice ) { do_action( 'woocommerce_ajax_added_to_cart', $choice['id'] ); }
        $cart->calculate_totals();
    } catch ( Throwable $error ) {
        $new_errors = array_slice( wc_get_notices( 'error' ), count( $notices['error'] ?? array() ) );
        $last_error = end( $new_errors );
        $message = $last_error ? wp_strip_all_tags( html_entity_decode( $last_error['notice'], ENT_QUOTES, get_bloginfo( 'charset' ) ) ) : __( 'Impossibile aggiungere la selezione. Controlla la disponibilità dei vini e riprova.', 'amicidibacco' );
        $cart->set_cart_contents( $before );
        $cart->set_applied_coupons( $coupons );
        $cart->set_removed_cart_contents( $removed );
        $cart->calculate_totals();
        // An earlier successful add may already have updated the signed-in customer's saved cart.
        ( new WC_Cart_Session( $cart ) )->persistent_cart_update();
        wc_set_notices( $notices );
        adb_pair_cart_error( $message, 409 );
    }

    $receipts[ $request_id ] = array( 'signature' => $signature, 'added' => count( $choices ) );
    $session->set( 'adb_pair_receipts', array_slice( $receipts, -32, null, true ) );
    wp_send_json_success( array( 'count' => $cart->get_cart_contents_count(), 'added' => count( $choices ), 'in_cart' => adb_pair_cart_has_wine( $cart, $owner ), 'cart_url' => wc_get_cart_url() ) );
} );
