<?php
/** Complete an existing WooCommerce wine draft with sourced editorial information. */
defined( 'ABSPATH' ) || exit;

function adb_fill_draft_error( $code = 'conflict' ) {
    $messages = array(
        'conflict' => __( 'La scheda è cambiata. Riapri la bozza aggiornata prima di riprovare.', 'amicidibacco' ),
        'draft' => __( 'La compilazione è disponibile solo nelle bozze di prodotti vino modificabili.', 'amicidibacco' ),
        'producer' => __( 'Scegli una cantina pubblicata e collegata al catalogo.', 'amicidibacco' ),
        'different_producer' => __( 'La cantina scelta è diversa da quella già associata al prodotto. Controlla gli attributi della bozza.', 'amicidibacco' ),
        'identity' => __( 'Inserisci il nome del vino e seleziona la cantina.', 'amicidibacco' ),
        'vintage_conflict' => __( 'Questa bozza contiene già dati di un’altra annata. Crea una nuova bozza per compilare la scheda di questa vendemmia.', 'amicidibacco' ),
        'empty' => __( 'Le fonti non hanno restituito dati verificabili per questa scheda.', 'amicidibacco' ),
        'save' => __( 'Salvataggio interrotto. Riapri la bozza e riprova.', 'amicidibacco' ),
        'busy' => __( 'È già in corso una compilazione per questa bozza.', 'amicidibacco' ),
        'pdf' => __( 'Scegli dalla Libreria media un PDF a cui hai accesso.', 'amicidibacco' ),
    );
    return new WP_Error( 'adb_fill_' . $code, $messages[ $code ] );
}

function adb_fill_editable_draft( $id ) {
    return function_exists( 'wc_get_product' ) && 'product' === get_post_type( $id )
        && in_array( get_post_status( $id ), array( 'auto-draft', 'draft' ), true )
        && current_user_can( 'edit_post', $id )
        && in_array( get_post_meta( $id, 'tipo_di_prodotto', true ), array( '', 'VINO SINGOLO' ), true );
}

function adb_fill_producer_term( $producer_id ) {
    if ( ! $producer_id || 'produttore' !== get_post_type( $producer_id ) || 'publish' !== get_post_status( $producer_id ) ) {
        return 0;
    }
    $term_id = absint( get_post_meta( $producer_id, 'cantina', true ) );
    return $term_id && term_exists( $term_id, 'pa_cantina' ) ? $term_id : 0;
}

/** Include editorial metadata and taxonomy changes made without a post timestamp update. */
function adb_fill_draft_version( $id ) {
    $post = get_post( $id );
    if ( ! $post ) { return ''; }
    $meta = get_post_meta( $id );
    unset( $meta['_edit_lock'], $meta['_edit_last'] );
    ksort( $meta );
    $terms = wp_get_object_terms( $id, get_object_taxonomies( 'product' ), array( 'fields' => 'tt_ids' ) );
    if ( is_wp_error( $terms ) ) { return ''; }
    sort( $terms, SORT_NUMERIC );
    return hash( 'sha256', serialize( array( $post->post_status, $post->post_title, $post->post_content, $post->post_excerpt, $post->post_modified_gmt, $meta, $terms ) ) );
}

function adb_fill_editor_box( $post ) {
    if ( 'product' !== $post->post_type || ! adb_fill_editable_draft( $post->ID ) ) { return; }
    $linked = wp_get_post_terms( $post->ID, 'pa_cantina', array( 'fields' => 'ids' ) );
    $linked = is_wp_error( $linked ) ? array() : array_map( 'intval', $linked );
    $wineries = adb_wineries( array(), -1 );
    ?>
    <div id="adb-wine-fill" class="postbox" data-id="<?php echo esc_attr( $post->ID ); ?>" data-version="<?php echo esc_attr( adb_fill_draft_version( $post->ID ) ); ?>" data-nonce="<?php echo esc_attr( wp_create_nonce( 'adb_fill_' . $post->ID ) ); ?>">
        <input type="hidden" name="adb_fill_editor_stamp" value="<?php echo esc_attr( get_post_meta( $post->ID, '_adb_fill_stamp', true ) ); ?>">
        <div class="adb-fill-layout">
            <header class="adb-fill-intro">
                <h2 id="adb-fill-heading"><?php esc_html_e( 'Compilazione automatica', 'amicidibacco' ); ?></h2>
                <p><?php esc_html_e( 'Inserisci il nome del vino nel titolo del prodotto e scegli la cantina. La scheda viene compilata dalle sue fonti ufficiali.', 'amicidibacco' ); ?></p>
            </header>
            <div class="adb-fill-controls">
                <label for="adb-fill-producer"><?php esc_html_e( 'Cantina', 'amicidibacco' ); ?></label>
                <select id="adb-fill-producer"><option value=""><?php esc_html_e( 'Seleziona la cantina', 'amicidibacco' ); ?></option>
                <?php foreach ( $wineries as $winery ) :
                    $term = absint( get_post_meta( $winery->ID, 'cantina', true ) );
                    if ( ! $term ) { continue; } ?>
                    <option value="<?php echo esc_attr( $winery->ID ); ?>" <?php selected( in_array( $term, $linked, true ) ); ?>><?php echo esc_html( $winery->post_title ); ?></option>
                <?php endforeach; ?>
                </select>
                <details class="adb-fill-options">
                    <summary><?php esc_html_e( 'Annata e scheda PDF', 'amicidibacco' ); ?><span class="adb-fill-optional"><?php esc_html_e( 'Facoltative', 'amicidibacco' ); ?></span></summary>
                    <div class="adb-fill-fields">
                        <div>
                            <label for="adb-fill-vintage"><?php esc_html_e( 'Annata di riferimento', 'amicidibacco' ); ?></label>
                            <input type="text" id="adb-fill-vintage" inputmode="numeric" maxlength="4" placeholder="<?php esc_attr_e( 'Es. 2024', 'amicidibacco' ); ?>">
                        </div>
                        <div>
                            <span class="adb-fill-label"><?php esc_html_e( 'Scheda tecnica', 'amicidibacco' ); ?></span>
                            <button type="button" id="adb-fill-pdf" class="button"><?php esc_html_e( 'Scegli un PDF', 'amicidibacco' ); ?></button>
                            <div class="adb-fill-file"><span id="adb-fill-pdf-name"></span>
                                <button type="button" id="adb-fill-pdf-clear" class="button-link" hidden><?php esc_html_e( 'Rimuovi PDF', 'amicidibacco' ); ?></button>
                            </div>
                        </div>
                    </div>
                </details>
                <button type="button" id="adb-fill-start" class="button button-primary"><?php esc_html_e( 'Compila e salva la bozza', 'amicidibacco' ); ?></button>
                <p class="adb-fill-note"><?php esc_html_e( 'I testi che hai scritto a mano vengono conservati.', 'amicidibacco' ); ?></p>
                <?php $reference = get_post_meta( $post->ID, '_adb_fill_price_reference', true );
                if ( ! empty( $reference['amount'] ) && '' === get_post_meta( $post->ID, '_regular_price', true ) ) : ?>
                    <p class="adb-fill-price"><?php echo esc_html( sprintf( __( 'Prezzo indicativo per %1$s cl: CHF %2$s. Il confronto usa il vostro catalogo, a parità di cantina, tipologia e formato.', 'amicidibacco' ), $reference['ml'] / 10, $reference['amount'] ) ); ?>
                        <button type="button" id="adb-fill-use-price" class="button-link" data-amount="<?php echo esc_attr( $reference['amount'] ); ?>"><?php esc_html_e( 'Usa questo prezzo', 'amicidibacco' ); ?></button>
                    </p>
                <?php endif; ?>
                <p id="adb-fill-status" role="status" aria-live="polite" tabindex="-1"></p>
            </div>
        </div>
    </div>
    <?php
}
add_action( 'edit_form_after_title', 'adb_fill_editor_box' );

function adb_fill_editor_assets( $hook ) {
    $screen = get_current_screen();
    if ( ! in_array( $hook, array( 'post-new.php', 'post.php' ), true ) || ! $screen || 'product' !== $screen->post_type ) { return; }
    wp_enqueue_media();
    $asset = '/assets/js/wine-autofill.js';
    wp_enqueue_script( 'adb-wine-fill', get_stylesheet_directory_uri() . $asset, array( 'media-editor' ), (string) filemtime( get_stylesheet_directory() . $asset ), true );
    wp_localize_script( 'adb-wine-fill', 'adbWineFill', array(
        'ajax' => admin_url( 'admin-ajax.php' ),
        'identity' => adb_fill_draft_error( 'identity' )->get_error_message(),
        'draft' => adb_fill_draft_error( 'draft' )->get_error_message(),
        'vintage' => __( 'Inserisci un’annata di quattro cifre.', 'amicidibacco' ),
        'saving' => __( 'Salvataggio delle modifiche alla bozza…', 'amicidibacco' ),
        'working' => __( 'Ricerca delle fonti e compilazione della bozza in corso…', 'amicidibacco' ),
        'failure' => __( 'La risposta non è arrivata. Riapri la bozza per verificare i dati salvati.', 'amicidibacco' ),
        'storage' => __( 'Il browser deve consentire l’archiviazione di sessione per completare la bozza.', 'amicidibacco' ),
        'choose' => __( 'Scegli la scheda tecnica PDF', 'amicidibacco' ),
        'priceUsed' => __( 'Prezzo inserito nella bozza', 'amicidibacco' ),
        'usePdf' => __( 'Usa questo PDF', 'amicidibacco' ),
    ) );
}
add_action( 'admin_enqueue_scripts', 'adb_fill_editor_assets' );

function adb_fill_native_job() {
    $job = $_POST['adb_fill_job'] ?? null;
    return is_string( $job ) && preg_match( '/^[a-f0-9]{32}$/D', $job ) ? $job : '';
}

/** The first native save handles all pending WooCommerce edits with the normal form. */
function adb_fill_guard_native_save() {
    if ( ! isset( $_POST['adb_fill_editor_stamp'] ) || 'editpost' !== ( $_POST['action'] ?? '' ) ) { return; }
    $id = absint( $_POST['post_ID'] ?? 0 );
    check_admin_referer( 'update-post_' . $id );
    // A second tab (or a lost network response) must not submit stale fields after a fill.
    if ( adb_fill_request_text( 'adb_fill_editor_stamp' ) !== get_post_meta( $id, '_adb_fill_stamp', true ) ) {
        wp_die( esc_html( adb_fill_draft_error()->get_error_message() ), '', array( 'response' => 409, 'back_link' => true ) );
    }
    if ( ! adb_fill_native_job() ) { return; }
    if ( ! adb_fill_editable_draft( $id ) || wp_check_post_lock( $id ) ) {
        wp_die( esc_html( adb_fill_draft_error()->get_error_message() ), '', array( 'response' => 409, 'back_link' => true ) );
    }
    $_POST['post_status'] = 'draft';
    $_POST['saveasdraft'] = '1';
    unset( $_POST['publish'], $_POST['saveasprivate'], $_POST['pending'] );
}
add_action( 'load-post.php', 'adb_fill_guard_native_save' );

function adb_fill_resume_location( $url, $id ) {
    $job = adb_fill_native_job();
    return $job && adb_fill_editable_draft( $id ) ? add_query_arg( 'adb_fill_job', $job, $url ) : $url;
}
add_filter( 'redirect_post_location', 'adb_fill_resume_location', 20, 2 );

/** Use only existing catalog terms, preserving custom attributes and variation settings. */
function adb_fill_add_attribute( $product, &$attributes, $taxonomy, $term_id, $replace = false ) {
    if ( ! $term_id || ! taxonomy_exists( $taxonomy ) || ! wc_attribute_taxonomy_id_by_name( $taxonomy ) ) { return false; }
    $assigned = wp_get_post_terms( $product->get_id(), $taxonomy, array( 'fields' => 'ids' ) );
    if ( is_wp_error( $assigned ) || ( ! $replace && $assigned && ! in_array( (int) $term_id, array_map( 'intval', $assigned ), true ) ) ) { return false; }
    if ( isset( $attributes[ $taxonomy ] ) ) {
        $attribute = clone $attributes[ $taxonomy ];
        if ( ( ! $replace && $attribute->get_options() ) || $attribute->get_variation() ) { return false; }
    } else {
        $attribute = new WC_Product_Attribute();
        $attribute->set_name( $taxonomy );
        $attribute->set_id( wc_attribute_taxonomy_id_by_name( $taxonomy ) );
        $attribute->set_position( count( $attributes ) );
        $attribute->set_visible( true );
        $attribute->set_variation( false );
    }
    $attribute->set_options( ! $replace && $assigned ? $assigned : array( (int) $term_id ) );
    $attributes[ $taxonomy ] = $attribute;
    return true;
}

function adb_fill_labels() {
    $groups = adb_product_editor_groups( 'VINO SINGOLO' );
    $technical = array_flip( array_merge( array( 'etichetta' ), $groups['technical'], $groups['notes'] ) );
    return array_merge( array(
        'description' => __( 'Descrizione', 'amicidibacco' ), 'excerpt' => __( 'Descrizione breve', 'amicidibacco' ),
        'pa_regione' => __( 'Regione', 'amicidibacco' ), 'pa_nazione' => __( 'Nazione', 'amicidibacco' ),
        'categoria' => __( 'Categoria', 'amicidibacco' ),
    ), array_intersect_key( adb_product_fields(), $technical ) );
}

function adb_fill_merge_tasting( $stored, $verified, &$added, &$owned, $evidence = array() ) {
    $stored = is_array( $stored ) ? $stored : array();
    $next = $stored;
    foreach ( array( 'aromas' => __( 'Aromi', 'amicidibacco' ), 'finish' => __( 'Finale', 'amicidibacco' ) ) as $key => $label ) {
        $previous = $stored[ $key ] ?? null;
        if ( ! empty( $verified[ $key ] ) && $previous !== $verified[ $key ] && ( isset( $owned[ $key ] ) ? $owned[ $key ] === $previous : empty( $previous ) ) ) {
            $owned[ $key ] = $verified[ $key ];
            $next[ $key ] = $verified[ $key ];
            $added[] = $label;
        }
    }
    // Ownership is per axis: one manual correction must not freeze the other four.
    $old_assessment = $owned['assessment'] ?? array();
    $assessment = $old_assessment;
    $edited = false;
    $has_editorial = false;
    $priority = array( 'style' => 1, 'editorial' => 1, 'descriptor' => 2, 'official' => 3 );
    foreach ( $verified['scores'] as $axis => $score ) {
        $current = $stored['scores'][ $axis ] ?? null;
        $note = $stored['score_evidence'][ $axis ] ?? '';
        $tracked = array_key_exists( $axis, $old_assessment['scores'] ?? array() );
        $changed_by_editor = $tracked
            ? ( $old_assessment['scores'][ $axis ] != $current || ( $old_assessment['score_evidence'][ $axis ] ?? '' ) !== $note )
            : ( null !== $current && '' !== $current );
        if ( $changed_by_editor ) {
            $owned['assessment_manual'][ $axis ] = true;
            unset( $assessment['scores'][ $axis ], $assessment['score_evidence'][ $axis ] );
        }
        $prior_origin = $owned['score_origins'][ $axis ] ?? ( $stored['score_method'] ?? '' );
        $origin = $evidence[ $axis ]['score_origin'] ?? $verified['score_method'];
        $manual = ! empty( $owned['assessment_manual'][ $axis ] );
        if ( $manual || null === $score || ( $current && ( $priority[ $prior_origin ] ?? 0 ) > ( $priority[ $origin ] ?? 0 ) ) ) {
            if ( $current && 'official' !== ( $manual ? ( $stored['score_method'] ?? '' ) : $prior_origin ) ) { $has_editorial = true; }
            continue;
        }
        $axis_note = $verified['score_evidence'][ $axis ];
        // An editorial profile may also contain individual scores published by the winery.
        if ( 'official' !== $origin ) { $has_editorial = true; }
        $owned['score_origins'][ $axis ] = $origin;
        $next['scores'][ $axis ] = $score;
        $next['score_evidence'][ $axis ] = $axis_note;
        $assessment['scores'][ $axis ] = $score;
        $assessment['score_evidence'][ $axis ] = $axis_note;
        $edited = $edited || $current != $score || $note !== $axis_note;
    }
    if ( ! empty( $assessment['scores'] ) ) {
        $method = $has_editorial ? 'editorial' : 'official';
        $basis = 'editorial' === $method ? ( $verified['score_basis'] ?: ( $stored['score_basis'] ?? '' ) ) : '';
        $next['score_method'] = $assessment['score_method'] = $method;
        $next['score_basis'] = $assessment['score_basis'] = $basis;
        $owned['assessment'] = $assessment;
    } elseif ( isset( $owned['assessment'] ) ) {
        unset( $owned['assessment'] );
    }
    if ( $edited ) { $added[] = __( 'Profilo del vino', 'amicidibacco' ); }
    if ( ! empty( $stored['reference_vintage'] ) && ! empty( $verified['reference_vintage'] ) && $stored['reference_vintage'] !== $verified['reference_vintage'] ) {
        return adb_fill_draft_error( 'vintage_conflict' );
    }
    if ( empty( $stored['reference_vintage'] ) && $verified['reference_vintage'] ) { $next['reference_vintage'] = $verified['reference_vintage']; }
    $urls = wp_list_pluck( (array) ( $stored['sources'] ?? array() ), 'url' );
    foreach ( $verified['sources'] as $source ) {
        $index = array_search( $source['url'], $urls, true );
        if ( false === $index ) {
            $next['sources'][] = $source;
            $urls[] = $source['url'];
        } elseif ( ( $next['sources'][ $index ]['vintage'] ?? '' ) === $source['vintage'] ) {
            $prior_fields = (array) ( $next['sources'][ $index ]['fields'] ?? array() );
            $next['sources'][ $index ]['fields'] = array_values( array_unique( array_merge( $prior_fields, $source['fields'] ) ) );
        }
    }
    if ( empty( $stored['verification'] ) || 'needs_source' === $stored['verification'] ) { $next['verification'] = $verified['verification']; }
    return $next;
}

/** Apply already validated extraction inside the short database transaction. */
function adb_fill_apply_result( $id, $wine_name, $producer_id, $result ) {
    $product = wc_get_product( $id );
    if ( ! $product || ! adb_fill_editable_draft( $id ) ) { return adb_fill_draft_error( 'draft' ); }
    $new = 'auto-draft' === get_post_status( $id );
    if ( ! $new && get_post_field( 'post_title', $id, 'raw' ) !== $wine_name ) { return adb_fill_draft_error(); }
    $producer_term = adb_fill_producer_term( $producer_id );
    if ( ! $producer_term ) { return adb_fill_draft_error( 'producer' ); }
    $linked = wp_get_post_terms( $id, 'pa_cantina', array( 'fields' => 'ids' ) );
    if ( is_wp_error( $linked ) || array_diff( $linked, array( $producer_term ) ) ) { return adb_fill_draft_error( 'different_producer' ); }

    $fields = array_intersect_key( (array) ( $result['fields'] ?? array() ), adb_fill_labels() );
    $evidence = (array) ( $result['evidence'] ?? array() );
    $tasting = adb_sanitize_tasting( $result['tasting'] ?? array() );
    if ( ! $tasting['sources'] ) { return adb_fill_draft_error( 'empty' ); }
    $attributes = $product->get_attributes( 'edit' );
    $dirty_attributes = adb_fill_add_attribute( $product, $attributes, 'pa_cantina', $producer_term );
    if ( ! $dirty_attributes && ( ! $linked || empty( $attributes['pa_cantina'] ) ) ) { return adb_fill_draft_error( 'different_producer' ); }
    $added = array();
    $missing = array();
    $meta = array();
    $new_evidence = array();
    $hidden = (array) get_post_meta( $id, '_adb_unverified_fields', true );
    $default_cat = (int) get_option( 'default_product_cat' );
    $previous_owned = get_post_meta( $id, '_adb_fill_written', true );
    $owned = is_array( $previous_owned ) ? $previous_owned : array();

    foreach ( adb_fill_labels() as $key => $label ) {
        if ( in_array( $key, $hidden, true ) ) { continue; }
        $value = is_string( $fields[ $key ] ?? null ) && ! empty( $evidence[ $key ] ) ? trim( sanitize_textarea_field( $fields[ $key ] ) ) : '';
        if ( 'description' === $key || 'excerpt' === $key ) {
            $is_long = 'description' === $key;
            $current = $is_long ? $product->get_description( 'edit' ) : $product->get_short_description( 'edit' );
            if ( isset( $owned[ $key ] ) && $owned[ $key ] !== $current ) { continue; }
            if ( '' !== trim( $current ) && ( ! isset( $owned[ $key ] ) || '' === $value || $value === $current ) ) { continue; }
            if ( '' !== $value ) {
                if ( $is_long ) { $product->set_description( $value ); } else { $product->set_short_description( $value ); }
            }
        } elseif ( in_array( $key, array( 'pa_regione', 'pa_nazione', 'categoria' ), true ) ) {
            $is_cat = 'categoria' === $key;
            $taxonomy = $is_cat ? 'product_cat' : $key;
            $existing = wp_get_post_terms( $id, $taxonomy, array( 'fields' => 'ids' ) );
            if ( is_wp_error( $existing ) ) { $missing[] = $label; continue; }
            $existing = array_map( 'intval', $existing );
            $replace = isset( $owned[ $key ] ) && array( $owned[ $key ] ) === $existing;
            if ( isset( $owned[ $key ] ) && ! $replace ) { continue; }
            if ( ( $is_cat ? array_diff( $existing, array( $default_cat ) ) : $existing ) && ( ! $replace || '' === $value ) ) { continue; }
            $term = '' !== $value ? get_term_by( 'name', $value, $taxonomy ) : false;
            if ( ! $term && '' !== $value ) { $term = get_term_by( 'slug', sanitize_title( $value ), $taxonomy ); }
            if ( ! $term ) { if ( ! $replace ) { $missing[] = $label; } continue; }
            if ( $existing === array( (int) $term->term_id ) ) { continue; }
            if ( $is_cat ) {
                $product->set_category_ids( array( $term->term_id ) );
            } else {
                if ( ! adb_fill_add_attribute( $product, $attributes, $taxonomy, $term->term_id, $replace ) ) { $missing[] = $label; continue; }
                $dirty_attributes = true;
            }
        } else {
            $current = get_post_meta( $id, $key, true );
            if ( isset( $owned[ $key ] ) && $owned[ $key ] !== $current ) { continue; }
            if ( '' !== $current && ( ! isset( $owned[ $key ] ) || '' === $value || $current === $value ) ) { continue; }
            if ( '' !== $value ) { $meta[ $key ] = $value; }
        }
        if ( '' === $value ) { $missing[] = $label; continue; }
        $added[] = $label;
        $new_evidence[ $key ] = $evidence[ $key ];
        $owned[ $key ] = in_array( $key, array( 'pa_regione', 'pa_nazione', 'categoria' ), true ) ? (int) $term->term_id : $value;
    }
    $stored = get_post_meta( $id, '_adb_tasting', true );
    $next = adb_fill_merge_tasting( $stored, $tasting, $added, $owned, $evidence );
    if ( is_wp_error( $next ) ) { return $next; }
    if ( empty( $next['aromas'] ) ) { $missing[] = __( 'Aromi', 'amicidibacco' ); }
    if ( empty( $next['finish'] ) ) { $missing[] = __( 'Finale', 'amicidibacco' ); }
    foreach ( adb_tasting_axes() as $axis => $definition ) {
        if ( empty( $next['scores'][ $axis ] ) ) { $missing[] = $definition['label']; }
    }
    $price_reference = $result['price_reference'] ?? null;
    if ( $price_reference && '' === $product->get_regular_price( 'edit' ) ) {
        if ( get_post_meta( $id, '_adb_fill_price_reference', true ) !== $price_reference ) {
            $meta['_adb_fill_price_reference'] = $price_reference;
        }
    }
    if ( '' === $product->get_regular_price( 'edit' ) ) { $missing[] = __( 'Prezzo di vendita', 'amicidibacco' ); }
    $image = $result['bottle_image'] ?? null;
    if ( ! $product->get_image_id( 'edit' ) ) {
        if ( $image && wp_attachment_is_image( $image['id'] ) && 'image/png' === get_post_mime_type( $image['id'] ) ) {
            $product->set_image_id( $image['id'] );
            $owned['image_id'] = $image['id'];
            $new_evidence['image_id'] = array( 'url' => $image['page'], 'image_url' => $image['url'] );
            $added[] = __( 'Foto della bottiglia', 'amicidibacco' );
        } else {
            $missing[] = __( 'Foto della bottiglia', 'amicidibacco' );
        }
    }
    if ( $new ) { $product->set_name( $wine_name ); $product->set_status( 'draft' ); }
    if ( $dirty_attributes ) { $product->set_attributes( $attributes ); }
    if ( $product->get_changes() && ! $product->save() ) { return adb_fill_draft_error( 'save' ); }
    if ( 'draft' !== get_post_status( $id ) || ! has_term( $producer_term, 'pa_cantina', $id ) ) { return adb_fill_draft_error( 'save' ); }

    if ( '' === get_post_meta( $id, 'tipo_di_prodotto', true ) ) { $meta['tipo_di_prodotto'] = 'VINO SINGOLO'; }
    if ( $next !== $stored ) { $meta['_adb_tasting'] = $next; }
    if ( $owned && $owned !== $previous_owned ) { $meta['_adb_fill_written'] = $owned; }
    foreach ( array( 'aromas', 'finish' ) as $key ) {
        if ( isset( $owned[ $key ], $evidence[ $key ] ) && ( $previous_owned[ $key ] ?? null ) !== $owned[ $key ] ) {
            $new_evidence[ $key ] = $evidence[ $key ];
        }
    }
    if ( isset( $owned['assessment'] ) && $owned['assessment'] != ( $previous_owned['assessment'] ?? null ) ) {
        foreach ( array_keys( array_filter( $owned['assessment']['scores'] ) ) as $axis ) {
            if ( isset( $evidence[ $axis ] ) && $owned['assessment']['scores'][ $axis ] === $tasting['scores'][ $axis ]
                && $owned['assessment']['score_evidence'][ $axis ] === $tasting['score_evidence'][ $axis ] ) {
                $new_evidence[ $axis ] = $evidence[ $axis ];
            }
        }
    }
    if ( $new_evidence ) {
        $previous = get_post_meta( $id, '_adb_fill_evidence', true );
        $meta['_adb_fill_evidence'] = array_merge( is_array( $previous ) ? $previous : array(), $new_evidence );
    }
    if ( $meta || $dirty_attributes || $new ) { $meta['_adb_fill_stamp'] = wp_generate_uuid4(); }
    foreach ( $new_evidence as $key => $source ) {
        if ( 'description' === $key || 'excerpt' === $key ) {
            $saved = get_post_field( 'description' === $key ? 'post_content' : 'post_excerpt', $id, 'raw' );
            if ( $owned[ $key ] !== $saved ) { return adb_fill_draft_error( 'save' ); }
        } elseif ( in_array( $key, array( 'categoria', 'pa_nazione', 'pa_regione' ), true ) ) {
            if ( ! has_term( $owned[ $key ], 'categoria' === $key ? 'product_cat' : $key, $id ) ) { return adb_fill_draft_error( 'save' ); }
        }
    }
    foreach ( $meta as $key => $value ) {
        update_post_meta( $id, $key, wp_slash( $value ) );
        if ( $value !== get_post_meta( $id, $key, true ) ) { return adb_fill_draft_error( 'save' ); }
    }
    return array( 'added' => $added, 'missing' => $missing, 'sources' => count( $tasting['sources'] ) );
}

function adb_fill_save_draft( $post_id, $wine_name, $producer_id, $result, $expected_version ) {
    global $wpdb;
    if ( ! adb_fill_editable_draft( $post_id ) ) { return adb_fill_draft_error( 'draft' ); }
    if ( ! is_string( $expected_version ) || ! $expected_version || ! is_array( $result ) ) { return adb_fill_draft_error(); }
    if ( false === $wpdb->query( 'START TRANSACTION' ) ) { return adb_fill_draft_error( 'save' ); }
    $committed = false;
    try {
        $locked = $wpdb->get_var( $wpdb->prepare( "SELECT ID FROM {$wpdb->posts} WHERE ID = %d FOR UPDATE", $post_id ) );
        clean_post_cache( $post_id );
        if ( ! $locked || ! hash_equals( $expected_version, adb_fill_draft_version( $post_id ) )
            || ( function_exists( 'wp_check_post_lock' ) && wp_check_post_lock( $post_id ) ) ) {
            return adb_fill_draft_error();
        }
        $outcome = adb_fill_apply_result( $post_id, $wine_name, $producer_id, $result );
        if ( is_wp_error( $outcome ) ) { return $outcome; }
        $committed = false !== $wpdb->query( 'COMMIT' );
        return $committed ? $outcome : adb_fill_draft_error( 'save' );
    } catch ( Throwable $exception ) {
        return adb_fill_draft_error( 'save' );
    } finally {
        if ( ! $committed ) {
            $wpdb->query( 'ROLLBACK' );
            clean_post_cache( $post_id );
            wc_delete_product_transients( $post_id );
        }
    }
}

function adb_fill_request_text( $key ) {
    return isset( $_POST[ $key ] ) && is_string( $_POST[ $key ] ) ? sanitize_text_field( wp_unslash( $_POST[ $key ] ) ) : '';
}

function adb_fill_editor_ajax() {
    global $wpdb;
    $id = absint( adb_fill_request_text( 'id' ) );
    check_ajax_referer( 'adb_fill_' . $id, 'nonce' );
    if ( ! adb_fill_editable_draft( $id ) ) { wp_send_json_error( adb_fill_draft_error( 'draft' )->get_error_message(), 403 ); }
    $producer = absint( adb_fill_request_text( 'producer' ) );
    $name = trim( get_post_field( 'post_title', $id, 'raw' ) );
    $vintage = adb_fill_request_text( 'vintage' );
    $pdf = absint( adb_fill_request_text( 'pdf' ) );
    $version = adb_fill_request_text( 'version' );
    if ( ! $name || $name !== adb_fill_request_text( 'name' ) || ! adb_fill_producer_term( $producer ) || ( $vintage && ! preg_match( '/^\d{4}$/D', $vintage ) ) ) {
        wp_send_json_error( adb_fill_draft_error( 'identity' )->get_error_message(), 400 );
    }
    if ( $pdf && ( 'attachment' !== get_post_type( $pdf ) || 'application/pdf' !== get_post_mime_type( $pdf ) || ! current_user_can( 'read_post', $pdf ) ) ) {
        wp_send_json_error( adb_fill_draft_error( 'pdf' )->get_error_message(), 400 );
    }
    if ( ! $version || ! hash_equals( adb_fill_draft_version( $id ), $version ) || wp_check_post_lock( $id ) ) {
        wp_send_json_error( adb_fill_draft_error()->get_error_message(), 409 );
    }
    $lock = 'adb_fill_' . md5( $wpdb->posts . ':' . DB_NAME . ':' . $id );
    if ( '1' !== (string) $wpdb->get_var( $wpdb->prepare( 'SELECT GET_LOCK(%s, 0)', $lock ) ) ) {
        wp_send_json_error( adb_fill_draft_error( 'busy' )->get_error_message(), 409 );
    }
    $image = null;
    try {
        $documents = adb_fill_sources( $name, $producer, $vintage, $pdf, $id );
        $result = is_wp_error( $documents ) ? $documents : adb_fill_extract( $name, get_post_field( 'post_title', $producer, 'raw' ), $vintage, $documents );
        if ( ! is_wp_error( $result ) ) {
            $result['price_reference'] = adb_fill_price_reference( $id, $producer, $result, $documents );
            $image = adb_fill_prepare_bottle_image( $documents, $id, $name );
            $result['bottle_image'] = $image;
            $result = adb_fill_save_draft( $id, $name, $producer, $result, $version );
        }
    } catch ( Throwable $exception ) {
        $result = adb_fill_draft_error( 'save' );
    } finally {
        if ( $image && ( is_wp_error( $result ) || (int) get_post_thumbnail_id( $id ) !== (int) $image['id'] ) ) {
            adb_fill_discard_bottle_image( $image );
        }
        $wpdb->get_var( $wpdb->prepare( 'SELECT RELEASE_LOCK(%s)', $lock ) );
    }
    if ( is_wp_error( $result ) ) { wp_send_json_error( $result->get_error_message(), 422 ); }
    $message = $result['added']
        ? sprintf( _n( 'Bozza salvata. Un campo compilato o aggiornato.', 'Bozza salvata. %d campi compilati o aggiornati.', count( $result['added'] ), 'amicidibacco' ), count( $result['added'] ) )
        : __( 'Bozza salvata. I dati disponibili sono già presenti.', 'amicidibacco' );
    if ( $result['missing'] ) {
        $message .= ' ' . sprintf( __( 'Campi da completare: %s.', 'amicidibacco' ), implode( ', ', array_unique( $result['missing'] ) ) );
    }
    wp_send_json_success( array( 'message' => $message ) );
}
add_action( 'wp_ajax_adb_fill_wine_draft', 'adb_fill_editor_ajax' );
