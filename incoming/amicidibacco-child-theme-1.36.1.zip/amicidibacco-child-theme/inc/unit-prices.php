<?php
/** Use the bottle or pack size recorded by the shop for the offer being shown. */
defined( 'ABSPATH' ) || exit;

function adb_format_litres( $format ) {
    if ( ! preg_match( '/^\s*(?:(\d+)\s*[x×]\s*)?(\d+(?:[.,]\d+)?)\s*(ml|cl|dl|l)\.?\s*$/iu', $format, $match ) ) {
        return 0;
    }
    $units = array( 'ml' => .001, 'cl' => .01, 'dl' => .1, 'l' => 1 );
    $count = '' === $match[1] ? 1 : (int) $match[1];
    return $count * (float) str_replace( ',', '.', $match[2] ) * $units[ strtolower( $match[3] ) ];
}

/** Keys are native size slugs, used when a variation accepts any of several formats. */
function adb_unit_prices( $product, $display_price = null ) {
    if ( ! $product || '' === $product->get_price() ) {
        return array();
    }
    if ( $product->is_type( 'variable' ) ) {
        // The theme shows the lowest displayed selling price. Use that exact offer's size.
        $prices = $product->get_variation_prices( true )['price'];
        if ( ! $prices ) { return array(); }
        $product = wc_get_product( key( $prices ) );
        $display_price = reset( $prices );
        if ( ! $product ) { return array(); }
    }

    // Some display stands carry a bottle capacity and an explicit "no spirits" shop label.
    $product_id = $product->is_type( 'variation' ) ? $product->get_parent_id() : $product->get_id();
    $label = trim( wp_strip_all_tags( (string) get_post_meta( $product_id, 'etichetta', true ) ) );
    if ( preg_match( '/^(?:senza (?:grappe|bottiglie)|pas de grappa|no grappa|kein grappa)$/iu', $label ) ) {
        return array();
    }
    $format = $product->get_attribute( 'pa_dimensione' );
    $formats = array( '' => $format );
    if ( '' === $format && $product->is_type( 'variation' ) ) {
        $terms = wc_get_product_terms( $product->get_parent_id(), 'pa_dimensione' );
        $formats = is_wp_error( $terms ) ? array() : wp_list_pluck( $terms, 'name', 'slug' );
    }
    $amount = null === $display_price ? wc_get_price_to_display( $product ) : $display_price;
    $labels = array();
    foreach ( $formats as $slug => $label ) {
        $litres = adb_format_litres( $label );
        if ( $litres > 0 ) {
            $price = html_entity_decode( wp_strip_all_tags( wc_price( $amount / $litres ) ), ENT_QUOTES | ENT_HTML5, 'UTF-8' );
            /* translators: 1: bottle or pack size, 2: formatted price per litre. */
            $labels[ $slug ] = sprintf( __( '%1$s · %2$s/l', 'amicidibacco' ), $label, $price );
        }
    }
    return $labels;
}

function adb_shipping_price_link() {
    return '<a class="adb-price-shipping" href="' . esc_url( home_url( '/spedizioni-e-pagamenti/' ) ) . '">' . esc_html__( 'Spese di spedizione', 'amicidibacco' ) . '</a>';
}

function adb_price_details( $product, $link_shipping = true, $display_price = null ) {
    $details = '';
    foreach ( adb_unit_prices( $product, $display_price ) as $slug => $text ) {
        $details .= '<span class="adb-price-unit" data-adb-unit-size="' . esc_attr( $slug ) . '">' . esc_html( $text ) . '</span>';
    }
    if ( $link_shipping && '' !== $product->get_price() ) {
        $details .= adb_shipping_price_link();
    }
    return $details;
}

add_action( 'woocommerce_single_product_summary', static function () {
    global $product;
    if ( $product instanceof WC_Product ) {
        echo '<div class="adb-summary-price-details">' . wp_kses_post( adb_price_details( $product ) ) . '</div>';
    }
}, 21 );

add_filter( 'woocommerce_available_variation', static function ( $data, $parent, $variation ) {
    if ( is_admin() && ! wp_doing_ajax() ) { return $data; }
    // WooCommerce normally suppresses the selected price if all variations have the same price.
    if ( '' !== $variation->get_price() ) {
        if ( '' === $data['price_html'] ) {
            $data['price_html'] = '<span class="price">' . $variation->get_price_html() . '</span>';
        }
        $data['price_html'] .= adb_price_details( $variation, true, $data['display_price'] );
    }
    return $data;
}, 10, 3 );

add_action( 'wp_enqueue_scripts', static function () {
    wp_enqueue_style( 'adb-unit-prices', get_stylesheet_directory_uri() . '/assets/css/unit-prices.css', array( 'adb-site' ), ADB_VERSION );
}, 30 );
