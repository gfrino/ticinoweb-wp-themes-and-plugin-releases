<?php
/** Italian winery stories: uncropped photography, native editorial content and catalog links. */
defined( 'ABSPATH' ) || exit;
get_header();
while ( have_posts() ) :
    the_post();
    $image = adb_valid_image_id( get_post_meta( get_the_ID(), 'immagine_di_sfondo_sulla_pagina_del_produttore', true ) );
    $logo = adb_valid_image_id( get_post_thumbnail_id() );
    $term_id = absint( get_post_meta( get_the_ID(), 'cantina', true ) );
    $term = $term_id ? get_term( $term_id, 'pa_cantina' ) : null;
    $catalog_url = $term && ! is_wp_error( $term ) ? get_term_link( $term ) : '';
    $catalog_url = is_wp_error( $catalog_url ) ? '' : $catalog_url;
    $wines = $catalog_url ? adb_products( array( 'filters' => array( 'adb_winery' => $term->slug ), 'limit' => 4 ) ) : array();
    $metadata = $image ? wp_get_attachment_metadata( $image ) : array();
    $portrait = is_array( $metadata ) && ( $metadata['height'] ?? 0 ) > ( $metadata['width'] ?? 0 );
    ?>
    <main id="main-content" class="adb-winery-page adb-estate">
        <div class="adb-wrap">
            <nav class="adb-estate__breadcrumb" aria-label="<?php esc_attr_e( 'Percorso di navigazione', 'amicidibacco' ); ?>">
                <a href="<?php echo esc_url( adb_page_link( 'wineries_page_id', '/produttori/' ) ); ?>"><?php esc_html_e( 'Tutte le cantine', 'amicidibacco' ); ?></a>
                <span aria-hidden="true">/</span><span aria-current="page"><?php the_title(); ?></span>
            </nav>
            <header class="adb-estate__opening<?php echo ! $image ? ' adb-estate__opening--text' : ''; ?><?php echo $portrait ? ' adb-estate__opening--portrait' : ''; ?>">
                <div class="adb-estate__identity">
                    <h1><?php the_title(); ?></h1>
                    <div class="adb-estate__links">
                        <a class="adb-link" href="#adb-estate-story"><?php esc_html_e( 'Il racconto', 'amicidibacco' ); ?> <?php echo adb_icon( 'down' ); ?></a>
                        <?php if ( $wines ) : ?><a class="adb-link" href="#adb-estate-wines"><?php esc_html_e( 'Le etichette', 'amicidibacco' ); ?> <?php echo adb_icon(); ?></a><?php endif; ?>
                    </div>
                </div>
                <?php if ( $image ) : ?>
                    <figure class="adb-estate__photograph">
                        <?php echo wp_get_attachment_image( $image, 'full', false, array( 'data-adb-webp' => true, 'loading' => 'eager', 'fetchpriority' => 'high', 'decoding' => 'async', 'sizes' => '(max-width:760px) calc(100vw - 48px), (max-width:1200px) 60vw, 900px', 'alt' => get_post_meta( $image, '_wp_attachment_image_alt', true ) ?: get_the_title() ) ); ?>
                    </figure>
                <?php endif; ?>
            </header>
            <section id="adb-estate-story" class="adb-estate__story" aria-labelledby="adb-estate-story-title">
                <div class="adb-estate__signature">
                    <?php if ( $logo ) { echo wp_get_attachment_image( $logo, 'medium', false, array( 'class' => 'adb-estate__logo', 'loading' => 'lazy', 'sizes' => '(max-width:760px) 140px, (max-width:1000px) 240px, 280px', 'alt' => get_the_title() ) ); } ?>
                    <h2 id="adb-estate-story-title"><?php esc_html_e( 'Il racconto', 'amicidibacco' ); ?></h2>
                </div>
                <div class="adb-estate__prose"><?php the_content(); ?></div>
            </section>
            <?php if ( $wines ) : ?>
                <section id="adb-estate-wines" class="adb-estate__wines" aria-labelledby="adb-estate-wines-title">
                    <div class="adb-section-heading">
                        <h2 id="adb-estate-wines-title"><?php esc_html_e( 'Le etichette', 'amicidibacco' ); ?></h2>
                        <a class="adb-link" href="<?php echo esc_url( $catalog_url ); ?>"><?php esc_html_e( 'Tutte le etichette', 'amicidibacco' ); ?> <?php echo adb_icon(); ?></a>
                    </div>
                    <div class="adb-product-grid"><?php foreach ( $wines as $wine ) { adb_product_card( $wine ); } ?></div>
                </section>
            <?php endif; ?>
            <nav class="adb-estate__return" aria-label="<?php esc_attr_e( 'Le nostre cantine', 'amicidibacco' ); ?>">
                <a class="adb-link" href="<?php echo esc_url( adb_page_link( 'wineries_page_id', '/produttori/' ) ); ?>"><?php esc_html_e( 'Tutte le cantine', 'amicidibacco' ); ?> <?php echo adb_icon(); ?></a>
            </nav>
        </div>
    </main>
    <?php
endwhile;
get_footer();
