<?php
/**
 * Public tutti.ch inventory synchronization for Luismacchine.
 *
 * The connector reads the public seller profile and listing pages without
 * signing in or calling private endpoints. This file owns the WordPress-side
 * workflow: scheduling, normalization, classification, catalog updates,
 * missing-listing handling and the CMS status tab.
 *
 * @package LuismacchineChildTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'LUISMACCHINE_TUTTI_CRON_HOOK', 'luismacchine_tutti_inventory_sync' );
define( 'LUISMACCHINE_TUTTI_SELLER_OPTION', 'luismacchine_tutti_seller_id' );
define( 'LUISMACCHINE_TUTTI_SETTINGS_OPTION', 'luismacchine_tutti_sync_settings' );
define( 'LUISMACCHINE_TUTTI_STATE_OPTION', 'luismacchine_tutti_sync_state' );
define( 'LUISMACCHINE_TUTTI_PENDING_OPTION', 'luismacchine_tutti_sync_pending' );
define( 'LUISMACCHINE_TUTTI_CATEGORY_OPTION', 'luismacchine_tutti_category_overrides' );
define( 'LUISMACCHINE_TUTTI_LOCK_KEY', 'luismacchine_tutti_sync_lock' );

/**
 * Return the saved synchronization settings with safe defaults.
 *
 * @return array
 */
function luismacchine_tutti_sync_settings() {
	$saved = get_option( LUISMACCHINE_TUTTI_SETTINGS_OPTION, array() );
	$saved = is_array( $saved ) ? $saved : array();
	$interval = ! empty( $saved['interval_configured'] )
		? luismacchine_tutti_sanitize_interval( $saved['interval'] ?? '' )
		: 'daily';

	$settings = wp_parse_args(
		$saved,
		array(
			'enabled'  => true,
			'interval' => 'daily',
		)
	);
	$settings['interval'] = $interval;

	return $settings;
}

/**
 * Return the supported synchronization intervals.
 *
 * @return array<string, string>
 */
function luismacchine_tutti_intervals() {
	return array(
		'luismacchine_four_hours'   => __( 'Ogni 4 ore', 'luismacchine-child-theme' ),
		'luismacchine_eight_hours'  => __( 'Ogni 8 ore', 'luismacchine-child-theme' ),
		'luismacchine_twelve_hours' => __( 'Ogni 12 ore', 'luismacchine-child-theme' ),
		'daily'                      => __( 'Ogni 24 ore', 'luismacchine-child-theme' ),
		'luismacchine_two_days'     => __( 'Ogni 48 ore', 'luismacchine-child-theme' ),
	);
}

/**
 * Sanitize a synchronization interval against the supported allowlist.
 *
 * @param string $interval Requested interval key.
 * @return string
 */
function luismacchine_tutti_sanitize_interval( $interval ) {
	$interval = sanitize_key( (string) $interval );
	return array_key_exists( $interval, luismacchine_tutti_intervals() ) ? $interval : 'daily';
}

/**
 * Return the duration in seconds of a supported synchronization interval.
 *
 * @param string $interval Supported interval key.
 * @return int
 */
function luismacchine_tutti_interval_seconds( $interval ) {
	$schedules = wp_get_schedules();
	return isset( $schedules[ $interval ]['interval'] ) ? max( MINUTE_IN_SECONDS, absint( $schedules[ $interval ]['interval'] ) ) : DAY_IN_SECONDS;
}

/**
 * Return whether an inventory connector is available.
 *
 * A connector must explicitly opt in through this filter. Keeping the default
 * false prevents accidental requests when the public connector is unavailable.
 *
 * @return bool
 */
function luismacchine_tutti_connector_available() {
	return (bool) apply_filters( 'luismacchine_tutti_connector_available', false );
}

/**
 * Return the seller identifier stored for the current site.
 *
 * The identifier is configuration data and deliberately stays outside the
 * repository. The public connector can provide a customer-specific fallback.
 *
 * @return string
 */
function luismacchine_tutti_seller_id() {
	$seller_id = sanitize_text_field( (string) get_option( LUISMACCHINE_TUTTI_SELLER_OPTION, '' ) );
	return (string) apply_filters( 'luismacchine_tutti_seller_id', $seller_id );
}

/**
 * Build the public seller profile URL from the configured identifier.
 *
 * @return string
 */
function luismacchine_tutti_seller_url() {
	$seller_id = luismacchine_tutti_seller_id();
	return $seller_id ? add_query_arg( 'id', rawurlencode( $seller_id ), 'https://www.tutti.ch/it/seller' ) : '';
}

/**
 * Add the custom schedules available for the inventory check.
 *
 * @param array $schedules Registered schedules.
 * @return array
 */
function luismacchine_tutti_cron_schedule( $schedules ) {
	$schedules['luismacchine_four_hours'] = array(
		'interval' => 4 * HOUR_IN_SECONDS,
		'display'  => __( 'Ogni 4 ore', 'luismacchine-child-theme' ),
	);
	$schedules['luismacchine_eight_hours'] = array(
		'interval' => 8 * HOUR_IN_SECONDS,
		'display'  => __( 'Ogni 8 ore', 'luismacchine-child-theme' ),
	);
	$schedules['luismacchine_twelve_hours'] = array(
		'interval' => 12 * HOUR_IN_SECONDS,
		'display'  => __( 'Ogni 12 ore', 'luismacchine-child-theme' ),
	);
	$schedules['luismacchine_two_days'] = array(
		'interval' => 2 * DAY_IN_SECONDS,
		'display'  => __( 'Ogni 48 ore', 'luismacchine-child-theme' ),
	);

	return $schedules;
}
add_filter( 'cron_schedules', 'luismacchine_tutti_cron_schedule' );

/**
 * Reconcile the cron event with the saved setting and connector state.
 *
 * @return void
 */
function luismacchine_tutti_reconcile_schedule() {
	$settings   = luismacchine_tutti_sync_settings();
	$scheduled  = wp_next_scheduled( LUISMACCHINE_TUTTI_CRON_HOOK );
	$recurrence = $scheduled ? wp_get_schedule( LUISMACCHINE_TUTTI_CRON_HOOK ) : false;
	$can_run    = ! empty( $settings['enabled'] ) && luismacchine_tutti_connector_available();

	if ( $can_run && $scheduled && $recurrence !== $settings['interval'] ) {
		wp_clear_scheduled_hook( LUISMACCHINE_TUTTI_CRON_HOOK );
		$scheduled = false;
	}

	if ( $can_run && ! $scheduled ) {
		wp_schedule_event( time() + luismacchine_tutti_interval_seconds( $settings['interval'] ), $settings['interval'], LUISMACCHINE_TUTTI_CRON_HOOK );
	} elseif ( ! $can_run && $scheduled ) {
		wp_clear_scheduled_hook( LUISMACCHINE_TUTTI_CRON_HOOK );
	}
}
add_action( 'init', 'luismacchine_tutti_reconcile_schedule', 60 );

/**
 * Clear this child theme's scheduled event when the theme is switched.
 *
 * @return void
 */
function luismacchine_tutti_clear_schedule() {
	wp_clear_scheduled_hook( LUISMACCHINE_TUTTI_CRON_HOOK );
}
add_action( 'switch_theme', 'luismacchine_tutti_clear_schedule' );

/**
 * Load the small admin stylesheet only on the main CMS screen.
 *
 * @param string $hook_suffix Current admin page hook.
 * @return void
 */
function luismacchine_tutti_admin_assets( $hook_suffix ) {
	if ( 'toplevel_page_ticinoweb-cms' !== $hook_suffix || ! current_user_can( 'manage_options' ) ) {
		return;
	}

	wp_enqueue_style(
		'luismacchine-tutti-admin',
		get_stylesheet_directory_uri() . '/assets/css/admin-tutti-sync.css',
		array(),
		LUISMACCHINE_THEME_VERSION
	);
}
add_action( 'admin_enqueue_scripts', 'luismacchine_tutti_admin_assets' );

/**
 * Return the last synchronization state.
 *
 * @return array
 */
function luismacchine_tutti_sync_state() {
	$state = get_option( LUISMACCHINE_TUTTI_STATE_OPTION, array() );
	$state = is_array( $state ) ? $state : array();

	return wp_parse_args(
		$state,
		array(
			'last_started'   => 0,
			'last_completed' => 0,
			'last_status'    => 'waiting',
			'last_message'   => '',
			'created'        => 0,
			'updated'        => 0,
			'unchanged'      => 0,
			'trashed'        => 0,
			'pending'        => 0,
			'failed'         => 0,
			'inventory_size' => 0,
		)
	);
}

/**
 * Save state without autoloading operational data on frontend requests.
 *
 * @param array $state New state.
 * @return void
 */
function luismacchine_tutti_update_state( $state ) {
	if ( false === get_option( LUISMACCHINE_TUTTI_STATE_OPTION, false ) ) {
		add_option( LUISMACCHINE_TUTTI_STATE_OPTION, $state, '', false );
		return;
	}

	update_option( LUISMACCHINE_TUTTI_STATE_OPTION, $state, false );
}

/**
 * Format a stored timestamp in the site's timezone.
 *
 * @param int $timestamp Unix timestamp.
 * @return string
 */
function luismacchine_tutti_format_time( $timestamp ) {
	return $timestamp ? wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $timestamp ) : __( 'Non ancora eseguito', 'luismacchine-child-theme' );
}

/**
 * Render the CMS status and controls as a tab in the parent CMS screen.
 *
 * The parent does not expose a PHP hook inside its tab wrapper. The panel is
 * therefore printed in the admin footer and moved next to the settings form.
 * Keeping it outside that form prevents invalid nested forms while preserving
 * the native tab behaviour provided by the parent.
 *
 * @return void
 */
function luismacchine_tutti_render_admin_page() {
	if ( ! current_user_can( 'manage_options' ) || 'ticinoweb-cms' !== ( isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : '' ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		return;
	}

	$settings            = luismacchine_tutti_sync_settings();
	$state               = luismacchine_tutti_sync_state();
	$connector_available = luismacchine_tutti_connector_available();
	$pending             = get_option( LUISMACCHINE_TUTTI_PENDING_OPTION, array() );
	$pending             = is_array( $pending ) ? $pending : array();
	$seller_url          = luismacchine_tutti_seller_url();
	$next_run            = wp_next_scheduled( LUISMACCHINE_TUTTI_CRON_HOOK );
	$status_class        = $connector_available ? 'is-ready' : 'is-waiting';
	$status_label        = $connector_available ? __( 'Lettura delle pagine pubbliche disponibile', 'luismacchine-child-theme' ) : __( 'Profilo venditore non configurato', 'luismacchine-child-theme' );
	?>
	<div id="tutti-sync" class="ticinoweb-tab-content lm-tutti-sync">
		<h2><?php esc_html_e( 'Sincronizzazione tutti.ch', 'luismacchine-child-theme' ); ?></h2>
		<p class="lm-tutti-sync__lead"><?php esc_html_e( 'Controlla automaticamente gli annunci di Luismacchine e mantiene aggiornati Veicoli e Ricambi senza creare duplicati.', 'luismacchine-child-theme' ); ?></p>

		<?php luismacchine_tutti_render_admin_notice(); ?>

		<section class="lm-tutti-sync__summary" aria-labelledby="lm-tutti-status-title">
			<div>
				<h2 id="lm-tutti-status-title"><?php esc_html_e( 'Stato del collegamento', 'luismacchine-child-theme' ); ?></h2>
				<p class="lm-tutti-sync__status <?php echo esc_attr( $status_class ); ?>"><span aria-hidden="true"></span><?php echo esc_html( $status_label ); ?></p>
			</div>
			<?php if ( $seller_url ) : ?>
				<a class="button" href="<?php echo esc_url( $seller_url ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Apri il profilo venditore', 'luismacchine-child-theme' ); ?></a>
			<?php endif; ?>
		</section>

		<div class="lm-tutti-sync__metrics" aria-label="<?php esc_attr_e( 'Riepilogo ultima sincronizzazione', 'luismacchine-child-theme' ); ?>">
			<dl><dt><?php esc_html_e( 'Ultimo controllo', 'luismacchine-child-theme' ); ?></dt><dd><?php echo esc_html( luismacchine_tutti_format_time( $state['last_completed'] ) ); ?></dd></dl>
			<dl><dt><?php esc_html_e( 'Prossimo controllo', 'luismacchine-child-theme' ); ?></dt><dd><?php echo esc_html( $next_run ? luismacchine_tutti_format_time( $next_run ) : __( 'Non pianificato', 'luismacchine-child-theme' ) ); ?></dd></dl>
			<dl><dt><?php esc_html_e( 'Annunci rilevati', 'luismacchine-child-theme' ); ?></dt><dd><?php echo esc_html( number_format_i18n( absint( $state['inventory_size'] ) ) ); ?></dd></dl>
			<dl><dt><?php esc_html_e( 'Da classificare', 'luismacchine-child-theme' ); ?></dt><dd><?php echo esc_html( number_format_i18n( count( $pending ) ) ); ?></dd></dl>
		</div>

		<section class="lm-tutti-sync__panel" aria-labelledby="lm-tutti-settings-title">
			<h2 id="lm-tutti-settings-title"><?php esc_html_e( 'Automazione', 'luismacchine-child-theme' ); ?></h2>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="luismacchine_save_tutti_sync">
				<?php wp_nonce_field( 'luismacchine_save_tutti_sync' ); ?>
				<label class="lm-tutti-sync__toggle">
					<input type="checkbox" name="enabled" value="1" <?php checked( ! empty( $settings['enabled'] ) ); ?> <?php disabled( ! $connector_available ); ?>>
					<span><strong><?php esc_html_e( 'Aggiornamento automatico', 'luismacchine-child-theme' ); ?></strong><small><?php esc_html_e( 'Legge esclusivamente il profilo venditore e gli annunci pubblici di tutti.ch.', 'luismacchine-child-theme' ); ?></small></span>
				</label>
				<p>
					<label for="lm-tutti-sync-interval"><strong><?php esc_html_e( 'Frequenza', 'luismacchine-child-theme' ); ?></strong></label><br>
					<select id="lm-tutti-sync-interval" name="interval" <?php disabled( ! $connector_available ); ?>>
						<?php foreach ( luismacchine_tutti_intervals() as $interval_key => $interval_label ) : ?>
							<option value="<?php echo esc_attr( $interval_key ); ?>" <?php selected( $settings['interval'], $interval_key ); ?>><?php echo esc_html( $interval_label ); ?></option>
						<?php endforeach; ?>
					</select>
				</p>
				<div class="lm-tutti-sync__actions">
					<?php submit_button( __( 'Salva impostazioni', 'luismacchine-child-theme' ), 'primary', 'submit', false, $connector_available ? array() : array( 'disabled' => 'disabled' ) ); ?>
					<?php if ( $connector_available ) : ?>
						<a class="button" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=luismacchine_run_tutti_sync' ), 'luismacchine_run_tutti_sync' ) ); ?>"><?php esc_html_e( 'Sincronizza ora', 'luismacchine-child-theme' ); ?></a>
					<?php else : ?>
						<span class="button disabled" aria-disabled="true"><?php esc_html_e( 'Sincronizza ora', 'luismacchine-child-theme' ); ?></span>
					<?php endif; ?>
				</div>
			</form>
			<?php if ( $state['last_message'] ) : ?>
				<p class="lm-tutti-sync__message"><strong><?php esc_html_e( 'Ultimo risultato:', 'luismacchine-child-theme' ); ?></strong> <?php echo esc_html( $state['last_message'] ); ?></p>
			<?php endif; ?>
		</section>

		<section class="lm-tutti-sync__panel" aria-labelledby="lm-tutti-rules-title">
			<h2 id="lm-tutti-rules-title"><?php esc_html_e( 'Regole di sicurezza', 'luismacchine-child-theme' ); ?></h2>
			<ul>
				<li><?php esc_html_e( 'Auto e veicoli commerciali vengono inseriti in Veicoli; accessori auto e ricambi vengono inseriti in Ricambi.', 'luismacchine-child-theme' ); ?></li>
				<li><?php esc_html_e( 'Una categoria sconosciuta non viene pubblicata e appare qui come “Da classificare”.', 'luismacchine-child-theme' ); ?></li>
				<li><?php esc_html_e( 'Un annuncio assente viene spostato nel Cestino soltanto dopo due inventari completi consecutivi.', 'luismacchine-child-theme' ); ?></li>
				<li><?php esc_html_e( 'Valori mancanti o anomali non cancellano informazioni attendibili già presenti nel CMS.', 'luismacchine-child-theme' ); ?></li>
			</ul>
		</section>

		<section class="lm-tutti-sync__panel" aria-labelledby="lm-tutti-pending-title">
			<h2 id="lm-tutti-pending-title"><?php esc_html_e( 'Da classificare', 'luismacchine-child-theme' ); ?></h2>
			<?php if ( empty( $pending ) ) : ?>
				<p class="lm-tutti-sync__empty"><?php esc_html_e( 'Nessun annuncio richiede un intervento.', 'luismacchine-child-theme' ); ?></p>
			<?php else : ?>
				<div class="lm-tutti-sync__pending-list">
					<?php foreach ( $pending as $external_id => $item ) : ?>
						<article class="lm-tutti-sync__pending-item">
							<div>
								<h3><?php echo esc_html( $item['title'] ); ?></h3>
								<p><?php printf( esc_html__( 'Categoria ricevuta: %s', 'luismacchine-child-theme' ), esc_html( $item['category_label'] ) ); ?></p>
							<a href="<?php echo esc_url( $item['source_url'] ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Visualizza annuncio', 'luismacchine-child-theme' ); ?></a>
							</div>
							<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
								<input type="hidden" name="action" value="luismacchine_classify_tutti_category">
								<input type="hidden" name="external_id" value="<?php echo esc_attr( $external_id ); ?>">
								<?php wp_nonce_field( 'luismacchine_classify_tutti_category_' . $external_id ); ?>
								<button class="button" name="classification" value="vehicle" type="submit"><?php esc_html_e( 'Tratta come Veicolo', 'luismacchine-child-theme' ); ?></button>
								<button class="button" name="classification" value="part" type="submit"><?php esc_html_e( 'Tratta come Ricambio', 'luismacchine-child-theme' ); ?></button>
								<button class="button-link-delete" name="classification" value="ignore" type="submit"><?php esc_html_e( 'Ignora', 'luismacchine-child-theme' ); ?></button>
							</form>
						</article>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>
		</section>
	</div>
	<script>
	(function () {
		'use strict';

		var panel = document.getElementById('tutti-sync');
		var tabs = document.querySelector('.ticinoweb-settings-tabs .nav-tab-wrapper');
		var settingsForm = document.querySelector('.wrap > form[action="options.php"]');
		var syncBodyState = function () {
			document.body.classList.toggle('lm-tutti-sync-active', window.location.hash === '#tutti-sync');
		};

		if (!panel || !tabs || !settingsForm || tabs.querySelector('[href="#tutti-sync"]')) {
			return;
		}

		var tab = document.createElement('a');
		tab.href = '#tutti-sync';
		tab.className = 'nav-tab';
		tab.textContent = <?php echo wp_json_encode( __( 'Sync tutti.ch', 'luismacchine-child-theme' ) ); ?>;
		tabs.appendChild(tab);
		settingsForm.insertAdjacentElement('afterend', panel);
		tabs.addEventListener('click', function () {
			window.setTimeout(syncBodyState, 0);
		});
		window.addEventListener('hashchange', syncBodyState);
		syncBodyState();
	}());
	</script>
	<?php
}
add_action( 'admin_footer-toplevel_page_ticinoweb-cms', 'luismacchine_tutti_render_admin_page' );

/**
 * Render only known admin notices.
 *
 * @return void
 */
function luismacchine_tutti_render_admin_notice() {
	$notice_code = isset( $_GET['lm-sync-notice'] ) ? sanitize_key( wp_unslash( $_GET['lm-sync-notice'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	$notices     = array(
		'settings-saved'       => array( 'success', __( 'Impostazioni salvate.', 'luismacchine-child-theme' ) ),
		'sync-complete'        => array( 'success', __( 'Sincronizzazione completata.', 'luismacchine-child-theme' ) ),
		'sync-error'           => array( 'error', __( 'La sincronizzazione non è riuscita. Controlla il risultato riportato nella pagina.', 'luismacchine-child-theme' ) ),
		'classification-saved' => array( 'success', __( 'Regola di classificazione salvata. Verrà applicata al prossimo controllo.', 'luismacchine-child-theme' ) ),
	);
	if ( ! isset( $notices[ $notice_code ] ) ) {
		return;
	}

	printf(
		'<div class="notice notice-%1$s is-dismissible"><p>%2$s</p></div>',
		esc_attr( $notices[ $notice_code ][0] ),
		esc_html( $notices[ $notice_code ][1] )
	);
}

/**
 * Add the manual synchronization command beside "Add new" in both catalogs.
 *
 * WordPress does not expose an action beside the page-title action. The link
 * is therefore generated server-side, including its nonce, and placed there
 * with a minimal progressive-enhancement script. The same command remains
 * available in the ticinoWEB CMS tab when JavaScript is unavailable.
 *
 * @return void
 */
function luismacchine_tutti_catalog_list_sync_button() {
	$screen = get_current_screen();
	$catalog_screens = array(
		LUISMACCHINE_VEHICLE_POST_TYPE => 'vehicles',
		LUISMACCHINE_PART_POST_TYPE    => 'parts',
	);
	if ( ! $screen || 'edit' !== $screen->base || ! isset( $catalog_screens[ $screen->post_type ] ) || ! current_user_can( 'manage_options' ) || ! luismacchine_tutti_connector_available() ) {
		return;
	}

	$sync_url = add_query_arg(
		array(
			'action'   => 'luismacchine_run_tutti_sync',
			'return'   => $catalog_screens[ $screen->post_type ],
			'_wpnonce' => wp_create_nonce( 'luismacchine_run_tutti_sync' ),
		),
		admin_url( 'admin-post.php' )
	);
	?>
	<script>
	document.addEventListener('DOMContentLoaded', function () {
		'use strict';

		var addNew = document.querySelector('.wrap .page-title-action');
		if (!addNew || document.getElementById('lm-tutti-catalog-sync')) {
			return;
		}

		var button = document.createElement('a');
		button.id = 'lm-tutti-catalog-sync';
		button.className = 'page-title-action';
		button.href = <?php echo wp_json_encode( $sync_url ); ?>;
		button.textContent = <?php echo wp_json_encode( __( 'Sincronizza con tutti.ch', 'luismacchine-child-theme' ) ); ?>;
		button.addEventListener('click', function () {
			button.setAttribute('aria-disabled', 'true');
			button.classList.add('disabled');
			button.textContent = <?php echo wp_json_encode( __( 'Sincronizzazione in corso…', 'luismacchine-child-theme' ) ); ?>;
		});
		addNew.insertAdjacentElement('afterend', button);
	});
	</script>
	<?php
}
add_action( 'admin_footer-edit.php', 'luismacchine_tutti_catalog_list_sync_button' );

/**
 * Show the result of a manual synchronization on either catalog list.
 *
 * @return void
 */
function luismacchine_tutti_catalog_list_notice() {
	$screen = get_current_screen();
	if ( ! $screen || 'edit' !== $screen->base || ! in_array( $screen->post_type, array( LUISMACCHINE_VEHICLE_POST_TYPE, LUISMACCHINE_PART_POST_TYPE ), true ) || ! current_user_can( 'manage_options' ) ) {
		return;
	}

	$notice_code = isset( $_GET['lm-sync-notice'] ) ? sanitize_key( wp_unslash( $_GET['lm-sync-notice'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	if ( ! in_array( $notice_code, array( 'sync-complete', 'sync-error' ), true ) ) {
		return;
	}

	$state   = luismacchine_tutti_sync_state();
	$type    = 'sync-complete' === $notice_code ? 'success' : 'error';
	$message = 'sync-complete' === $notice_code
		? __( 'Sincronizzazione con tutti.ch completata.', 'luismacchine-child-theme' )
		: __( 'La sincronizzazione con tutti.ch non è riuscita.', 'luismacchine-child-theme' );
	if ( ! empty( $state['last_message'] ) ) {
		$message .= ' ' . $state['last_message'];
	}

	printf(
		'<div class="notice notice-%1$s is-dismissible"><p>%2$s</p></div>',
		esc_attr( $type ),
		esc_html( $message )
	);
}
add_action( 'admin_notices', 'luismacchine_tutti_catalog_list_notice' );

/**
 * Save the activation setting.
 *
 * @return void
 */
function luismacchine_tutti_save_settings() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'Operazione non consentita.', 'luismacchine-child-theme' ) );
	}

	check_admin_referer( 'luismacchine_save_tutti_sync' );

	$enabled = isset( $_POST['enabled'] ) && luismacchine_tutti_connector_available();
	$interval = isset( $_POST['interval'] ) ? luismacchine_tutti_sanitize_interval( wp_unslash( $_POST['interval'] ) ) : 'daily';
	update_option(
		LUISMACCHINE_TUTTI_SETTINGS_OPTION,
		array(
			'enabled'             => $enabled,
			'interval'            => $interval,
			'interval_configured' => true,
		),
		false
	);
	luismacchine_tutti_reconcile_schedule();
	luismacchine_tutti_admin_redirect( 'settings-saved' );
}
add_action( 'admin_post_luismacchine_save_tutti_sync', 'luismacchine_tutti_save_settings' );

/**
 * Run a synchronization on demand.
 *
 * @return void
 */
function luismacchine_tutti_run_manual_sync() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'Operazione non consentita.', 'luismacchine-child-theme' ) );
	}

	check_admin_referer( 'luismacchine_run_tutti_sync' );
	$return_to = isset( $_GET['return'] ) ? sanitize_key( wp_unslash( $_GET['return'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	$result    = luismacchine_tutti_run_sync( 'manual' );
	luismacchine_tutti_admin_redirect( is_wp_error( $result ) ? 'sync-error' : 'sync-complete', $return_to );
}
add_action( 'admin_post_luismacchine_run_tutti_sync', 'luismacchine_tutti_run_manual_sync' );

/**
 * Save a category override selected by an administrator.
 *
 * @return void
 */
function luismacchine_tutti_classify_category() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'Operazione non consentita.', 'luismacchine-child-theme' ) );
	}

	$external_id   = isset( $_POST['external_id'] ) ? sanitize_text_field( wp_unslash( $_POST['external_id'] ) ) : '';
	$classification = isset( $_POST['classification'] ) ? sanitize_key( wp_unslash( $_POST['classification'] ) ) : '';

	check_admin_referer( 'luismacchine_classify_tutti_category_' . $external_id );

	if ( ! in_array( $classification, array( 'vehicle', 'part', 'ignore' ), true ) ) {
		wp_die( esc_html__( 'Classificazione non valida.', 'luismacchine-child-theme' ) );
	}

	$pending = get_option( LUISMACCHINE_TUTTI_PENDING_OPTION, array() );
	$pending = is_array( $pending ) ? $pending : array();
	if ( empty( $pending[ $external_id ]['category_key'] ) ) {
		wp_die( esc_html__( 'L’annuncio da classificare non è più disponibile.', 'luismacchine-child-theme' ) );
	}

	$category_key = sanitize_text_field( $pending[ $external_id ]['category_key'] );
	$overrides    = get_option( LUISMACCHINE_TUTTI_CATEGORY_OPTION, array() );
	$overrides    = is_array( $overrides ) ? $overrides : array();
	$overrides[ $category_key ] = $classification;
	update_option( LUISMACCHINE_TUTTI_CATEGORY_OPTION, $overrides, false );

	foreach ( $pending as $key => $item ) {
		if ( isset( $item['category_key'] ) && $category_key === $item['category_key'] ) {
			unset( $pending[ $key ] );
		}
	}
	update_option( LUISMACCHINE_TUTTI_PENDING_OPTION, $pending, false );

	luismacchine_tutti_admin_redirect( 'classification-saved' );
}
add_action( 'admin_post_luismacchine_classify_tutti_category', 'luismacchine_tutti_classify_category' );

/**
 * Redirect back to the CMS screen with a short notice.
 *
 * @param string $notice_code Known notice code.
 * @param string $return_to   Optional destination after the action.
 * @return void
 */
function luismacchine_tutti_admin_redirect( $notice_code, $return_to = '' ) {
	$catalog_screens = array(
		'vehicles' => LUISMACCHINE_VEHICLE_POST_TYPE,
		'parts'    => LUISMACCHINE_PART_POST_TYPE,
	);
	if ( isset( $catalog_screens[ $return_to ] ) ) {
		$redirect_url = add_query_arg(
			array(
				'post_type'      => $catalog_screens[ $return_to ],
				'lm-sync-notice' => sanitize_key( $notice_code ),
			),
			admin_url( 'edit.php' )
		);
		wp_safe_redirect( $redirect_url );
		exit;
	}

	$redirect_url = add_query_arg(
		array(
			'page'           => 'ticinoweb-cms',
			'lm-sync-notice' => sanitize_key( $notice_code ),
		),
		admin_url( 'admin.php' )
	);

	wp_safe_redirect( $redirect_url . '#tutti-sync' );
	exit;
}

/**
 * Let the configured connector provide one complete seller inventory.
 *
 * Expected result:
 * array(
 *   'complete' => true,
 *   'items'    => array(
 *     array(
 *       'external_id' => '123', 'source_url' => 'https://www.tutti.ch/...',
 *       'category_key' => 'veicoli/auto', 'category_label' => 'Auto',
 *       'title' => '...', 'content' => '...', 'price' => 1000,
 *       'images' => array( 'https://cdn.tutti.ch/...' ),
 *       'attributes' => array( 'year' => '2020', 'power_ps' => 100, ... ),
 *     ),
 *   ),
 * )
 *
 * @return array|WP_Error
 */
function luismacchine_tutti_fetch_inventory() {
	$unavailable = new WP_Error( 'connector_unavailable', __( 'Il profilo venditore tutti.ch non è configurato.', 'luismacchine-child-theme' ) );

	return apply_filters( 'luismacchine_tutti_inventory', $unavailable, luismacchine_tutti_seller_id() );
}

/**
 * Execute a full synchronization.
 *
 * @param string $context Invocation context.
 * @return array|WP_Error
 */
function luismacchine_tutti_run_sync( $context = 'cron' ) {
	if ( ! luismacchine_tutti_connector_available() ) {
		$error = new WP_Error( 'connector_unavailable', __( 'Il profilo venditore tutti.ch non è configurato.', 'luismacchine-child-theme' ) );
		$state = luismacchine_tutti_sync_state();
		$state['last_started']   = time();
		$state['last_completed'] = time();
		$state['last_status']    = 'error';
		$state['last_message']   = $error->get_error_message();
		$state['context']        = sanitize_key( $context );
		luismacchine_tutti_update_state( $state );
		return $error;
	}

	if ( get_transient( LUISMACCHINE_TUTTI_LOCK_KEY ) ) {
		return new WP_Error( 'sync_locked', __( 'Una sincronizzazione è già in corso.', 'luismacchine-child-theme' ) );
	}

	set_transient( LUISMACCHINE_TUTTI_LOCK_KEY, 1, 15 * MINUTE_IN_SECONDS );
	$started = time();
	$state   = array(
		'last_started'   => $started,
		'last_completed' => 0,
		'last_status'    => 'running',
		'last_message'   => __( 'Sincronizzazione in corso.', 'luismacchine-child-theme' ),
		'created'        => 0,
		'updated'        => 0,
		'unchanged'      => 0,
		'trashed'        => 0,
		'pending'        => 0,
		'failed'         => 0,
		'inventory_size' => 0,
		'context'        => sanitize_key( $context ),
	);
	luismacchine_tutti_update_state( $state );

	$inventory = luismacchine_tutti_fetch_inventory();
	if ( is_wp_error( $inventory ) ) {
		$state['last_completed'] = time();
		$state['last_status']    = 'error';
		$state['last_message']   = $inventory->get_error_message();
		luismacchine_tutti_update_state( $state );
		delete_transient( LUISMACCHINE_TUTTI_LOCK_KEY );
		return $inventory;
	}

	if ( ! is_array( $inventory ) || empty( $inventory['complete'] ) || ! isset( $inventory['items'] ) || ! is_array( $inventory['items'] ) ) {
		$error = new WP_Error( 'invalid_inventory', __( 'Il connettore non ha restituito un inventario completo e valido.', 'luismacchine-child-theme' ) );
		$state['last_completed'] = time();
		$state['last_status']    = 'error';
		$state['last_message']   = $error->get_error_message();
		luismacchine_tutti_update_state( $state );
		delete_transient( LUISMACCHINE_TUTTI_LOCK_KEY );
		return $error;
	}

	$items = array();
	foreach ( $inventory['items'] as $raw_item ) {
		$item = luismacchine_tutti_normalize_item( $raw_item );
		if ( is_wp_error( $item ) ) {
			++$state['failed'];
			continue;
		}
		$items[ $item['external_id'] ] = $item;
	}

	$state['inventory_size'] = count( $items );
	$seen_ids                = array();
	foreach ( $items as $item ) {
		$result = luismacchine_tutti_import_item( $item );
		if ( is_wp_error( $result ) ) {
			++$state['failed'];
			continue;
		}

		if ( 'pending' === $result['action'] ) {
			++$state['pending'];
			continue;
		}
		if ( 'ignored' === $result['action'] ) {
			continue;
		}

		$seen_ids[] = $item['external_id'];
		if ( isset( $state[ $result['action'] ] ) ) {
			++$state[ $result['action'] ];
		}
	}

	// An unexpectedly empty inventory is never allowed to remove products.
	if ( ! empty( $items ) ) {
		$state['trashed'] = luismacchine_tutti_process_missing( $seen_ids );
		luismacchine_tutti_prune_pending( array_keys( $items ) );
	}

	$state['last_completed'] = time();
	$state['last_status']    = $state['failed'] ? 'warning' : 'success';
	$state['last_message']   = sprintf(
		/* translators: 1: created, 2: updated, 3: trashed, 4: pending. */
		__( 'Creati: %1$d. Aggiornati: %2$d. Nel Cestino: %3$d. Da classificare: %4$d.', 'luismacchine-child-theme' ),
		$state['created'],
		$state['updated'],
		$state['trashed'],
		$state['pending']
	);
	luismacchine_tutti_update_state( $state );
	delete_transient( LUISMACCHINE_TUTTI_LOCK_KEY );

	return $state;
}
add_action( LUISMACCHINE_TUTTI_CRON_HOOK, 'luismacchine_tutti_run_sync' );

/**
 * Normalize and validate one item from the configured connector.
 *
 * @param mixed $raw_item Raw connector item.
 * @return array|WP_Error
 */
function luismacchine_tutti_normalize_item( $raw_item ) {
	if ( ! is_array( $raw_item ) ) {
		return new WP_Error( 'invalid_item', __( 'Formato annuncio non valido.', 'luismacchine-child-theme' ) );
	}

	$external_id  = isset( $raw_item['external_id'] ) ? sanitize_text_field( (string) $raw_item['external_id'] ) : '';
	$title        = isset( $raw_item['title'] ) ? sanitize_text_field( $raw_item['title'] ) : '';
	$source_url   = isset( $raw_item['source_url'] ) ? esc_url_raw( $raw_item['source_url'] ) : '';
	$category_key = isset( $raw_item['category_key'] ) ? luismacchine_tutti_normalize_category_key( $raw_item['category_key'] ) : '';

	if ( ! $external_id || ! $title || ! luismacchine_tutti_source_url_allowed( $source_url ) || ! $category_key ) {
		return new WP_Error( 'invalid_item', __( 'L’annuncio non contiene ID, titolo, URL o categoria validi.', 'luismacchine-child-theme' ) );
	}

	$images = array();
	foreach ( isset( $raw_item['images'] ) && is_array( $raw_item['images'] ) ? $raw_item['images'] : array() as $image_url ) {
		$image_url = esc_url_raw( $image_url );
		if ( luismacchine_tutti_image_url_allowed( $image_url ) ) {
			$images[] = $image_url;
		}
	}

	$attributes = isset( $raw_item['attributes'] ) && is_array( $raw_item['attributes'] ) ? $raw_item['attributes'] : array();

	return array(
		'external_id'   => substr( $external_id, 0, 191 ),
		'source_url'    => $source_url,
		'category_key'  => $category_key,
		'category_label'=> isset( $raw_item['category_label'] ) ? sanitize_text_field( $raw_item['category_label'] ) : $category_key,
		'title'         => $title,
		'content'       => isset( $raw_item['content'] ) ? wp_kses_post( $raw_item['content'] ) : '',
		'price'         => isset( $raw_item['price'] ) && is_numeric( $raw_item['price'] ) ? max( 0, (float) $raw_item['price'] ) : null,
		'images'        => array_values( array_unique( $images ) ),
		'attributes'    => luismacchine_tutti_normalize_attributes( $attributes ),
		'updated_at'    => isset( $raw_item['updated_at'] ) ? sanitize_text_field( $raw_item['updated_at'] ) : '',
	);
}

/**
 * Normalize the connector's structured attributes.
 *
 * @param array $attributes Raw attributes.
 * @return array
 */
function luismacchine_tutti_normalize_attributes( $attributes ) {
	$text_keys = array( 'year', 'fuel', 'transmission', 'traction', 'body_type', 'engine_type', 'license_category', 'vehicle_condition', 'warranty', 'condition', 'compatibility', 'brand', 'model', 'part_category', 'equipment' );
	$int_keys  = array( 'mileage', 'power_ps', 'power_kw', 'displacement_cc', 'cylinders', 'gears', 'doors', 'range' );
	$clean     = array();

	foreach ( $text_keys as $key ) {
		if ( isset( $attributes[ $key ] ) && '' !== trim( (string) $attributes[ $key ] ) ) {
			$clean[ $key ] = 'equipment' === $key ? sanitize_textarea_field( $attributes[ $key ] ) : sanitize_text_field( $attributes[ $key ] );
		}
	}

	foreach ( $int_keys as $key ) {
		if ( isset( $attributes[ $key ] ) && is_numeric( $attributes[ $key ] ) ) {
			$clean[ $key ] = absint( $attributes[ $key ] );
		}
	}

	if ( isset( $clean['power_ps'] ) && ! luismacchine_tutti_power_plausible( $clean['power_ps'] ) ) {
		unset( $clean['power_ps'] );
	}
	if ( isset( $clean['power_kw'] ) && ! luismacchine_tutti_power_plausible( $clean['power_kw'] ) ) {
		unset( $clean['power_kw'] );
	}
	if ( isset( $clean['power_ps'] ) && ! isset( $clean['power_kw'] ) ) {
		$clean['power_kw'] = (int) round( $clean['power_ps'] * 0.73549875 );
	} elseif ( isset( $clean['power_kw'] ) && ! isset( $clean['power_ps'] ) ) {
		$clean['power_ps'] = (int) round( $clean['power_kw'] / 0.73549875 );
	}

	return $clean;
}

/**
 * Reject clearly incomplete or corrupted power values.
 *
 * @param int $value Power value.
 * @return bool
 */
function luismacchine_tutti_power_plausible( $value ) {
	$value = absint( $value );
	return $value >= 5 && $value <= 2000;
}

/**
 * Normalize category keys from IDs or breadcrumb-like paths.
 *
 * @param mixed $category Raw category.
 * @return string
 */
function luismacchine_tutti_normalize_category_key( $category ) {
	$category = remove_accents( strtolower( trim( (string) $category ) ) );
	$category = preg_replace( '/[^a-z0-9]+/', '-', $category );
	return trim( $category, '-' );
}

/**
 * Allow only public listing URLs from tutti.ch.
 *
 * @param string $url URL to validate.
 * @return bool
 */
function luismacchine_tutti_source_url_allowed( $url ) {
	$host = wp_parse_url( $url, PHP_URL_HOST );
	$scheme = wp_parse_url( $url, PHP_URL_SCHEME );
	return 'https' === strtolower( (string) $scheme ) && is_string( $host ) && in_array( strtolower( $host ), array( 'tutti.ch', 'www.tutti.ch' ), true );
}

/**
 * Allow only known tutti.ch image hosts; actual downloads are copied into the
 * media library so images are never hotlinked.
 *
 * @param string $url URL to validate.
 * @return bool
 */
function luismacchine_tutti_image_url_allowed( $url ) {
	$host = wp_parse_url( $url, PHP_URL_HOST );
	$scheme = wp_parse_url( $url, PHP_URL_SCHEME );
	return 'https' === strtolower( (string) $scheme ) && is_string( $host ) && in_array( strtolower( $host ), array( 'cdn.tutti.ch', 'c.tutti.ch' ), true );
}

/**
 * Return the catalog destination for a category.
 *
 * @param string $category_key Normalized category.
 * @return string vehicle, part, ignore or pending.
 */
function luismacchine_tutti_classify( $category_key ) {
	$overrides = get_option( LUISMACCHINE_TUTTI_CATEGORY_OPTION, array() );
	$overrides = is_array( $overrides ) ? $overrides : array();
	if ( isset( $overrides[ $category_key ] ) && in_array( $overrides[ $category_key ], array( 'vehicle', 'part', 'ignore' ), true ) ) {
		return $overrides[ $category_key ];
	}

	$map = array(
		'auto'                  => 'vehicle',
		'veicoli-auto'          => 'vehicle',
		'veicoli-commerciali'   => 'vehicle',
		'veicoli-veicoli-commerciali' => 'vehicle',
		'accessori-auto'        => 'part',
		'veicoli-accessori-auto'=> 'part',
		'ricambi-auto'          => 'part',
	);
	$map = apply_filters( 'luismacchine_tutti_category_map', $map );

	return isset( $map[ $category_key ] ) ? $map[ $category_key ] : 'pending';
}

/**
 * Create or update one product using only normalized values.
 *
 * @param array $item Normalized item.
 * @return array|WP_Error
 */
function luismacchine_tutti_import_item( $item ) {
	$classification = luismacchine_tutti_classify( $item['category_key'] );
	if ( 'pending' === $classification ) {
		luismacchine_tutti_queue_pending( $item );
		return array( 'action' => 'pending' );
	}
	if ( 'ignore' === $classification ) {
		return array( 'action' => 'ignored' );
	}

	$post_type = 'vehicle' === $classification ? LUISMACCHINE_VEHICLE_POST_TYPE : LUISMACCHINE_PART_POST_TYPE;
	$post_id   = luismacchine_tutti_find_post( $item['external_id'] );
	if ( ! $post_id ) {
		$post_id = luismacchine_tutti_find_existing_product( $post_type, $item );
	}
	if ( $post_id && $post_type !== get_post_type( $post_id ) ) {
		return new WP_Error( 'classification_conflict', __( 'L’annuncio è già collegato a un tipo di prodotto diverso.', 'luismacchine-child-theme' ) );
	}

	$content_hash = hash( 'sha256', wp_json_encode( $item ) );
	$action       = $post_id ? 'updated' : 'created';
	if ( $post_id && hash_equals( (string) get_post_meta( $post_id, '_lm_tutti_hash', true ), $content_hash ) ) {
		update_post_meta( $post_id, '_lm_tutti_last_seen', time() );
		delete_post_meta( $post_id, '_lm_tutti_missing_count' );
		// Retry missing media even when the listing data itself has not changed.
		do_action( 'luismacchine_tutti_item_saved', $post_id, $item, 'unchanged' );
		return array( 'action' => 'unchanged', 'post_id' => $post_id );
	}

	$post_data = array(
		'post_type'    => $post_type,
		'post_status'  => 'publish',
		'post_title'   => $item['title'],
	);
	if ( $item['content'] || ! $post_id ) {
		$post_data['post_content'] = $item['content'];
	}
	if ( $post_id ) {
		$post_data['ID'] = $post_id;
		$post_id         = wp_update_post( wp_slash( $post_data ), true );
	} else {
		$post_id = wp_insert_post( wp_slash( $post_data ), true );
	}
	if ( is_wp_error( $post_id ) ) {
		return $post_id;
	}

	update_post_meta( $post_id, '_lm_tutti_id', $item['external_id'] );
	update_post_meta( $post_id, '_lm_tutti_url', $item['source_url'] );
	update_post_meta( $post_id, '_lm_tutti_category', $item['category_key'] );
	update_post_meta( $post_id, '_lm_tutti_hash', $content_hash );
	update_post_meta( $post_id, '_lm_tutti_last_seen', time() );
	update_post_meta( $post_id, '_lm_tutti_managed', '1' );
	delete_post_meta( $post_id, '_lm_tutti_missing_count' );
	update_post_meta( $post_id, '_lm_status', 'disponibile' );

	if ( null !== $item['price'] ) {
		update_post_meta( $post_id, '_lm_price', $item['price'] );
	}

	luismacchine_tutti_update_catalog_fields( $post_id, $post_type, $item['attributes'] );
	luismacchine_tutti_update_taxonomies( $post_id, $post_type, $item['attributes'] );

	/**
	 * Fires after a normalized item has been saved. The media synchronizer uses
	 * this hook to sideload validated images.
	 */
	do_action( 'luismacchine_tutti_item_saved', $post_id, $item, $action );

	return array( 'action' => $action, 'post_id' => $post_id );
}

/**
 * Update only known catalog fields and never clear a field with missing data.
 *
 * @param int    $post_id    Product ID.
 * @param string $post_type  Product post type.
 * @param array  $attributes Normalized attributes.
 * @return void
 */
function luismacchine_tutti_update_catalog_fields( $post_id, $post_type, $attributes ) {
	$vehicle_map = array(
		'year'              => '_lm_year',
		'mileage'           => '_lm_mileage',
		'fuel'              => '_lm_fuel',
		'transmission'      => '_lm_transmission',
		'power_ps'          => '_lm_power_ps',
		'power_kw'          => '_lm_power_kw',
		'traction'          => '_lm_traction',
		'body_type'         => '_lm_body_type',
		'displacement_cc'   => '_lm_displacement_cc',
		'cylinders'         => '_lm_cylinders',
		'engine_type'       => '_lm_engine_type',
		'gears'             => '_lm_gears',
		'license_category'  => '_lm_license_category',
		'vehicle_condition' => '_lm_vehicle_condition',
		'doors'             => '_lm_doors',
		'range'             => '_lm_range',
		'equipment'         => '_lm_equipment',
		'warranty'          => '_lm_warranty',
	);
	$part_map = array(
		'condition'     => '_lm_condition',
		'compatibility' => '_lm_compatibility',
	);
	$map = LUISMACCHINE_VEHICLE_POST_TYPE === $post_type ? $vehicle_map : $part_map;

	foreach ( $map as $source_key => $meta_key ) {
		if ( isset( $attributes[ $source_key ] ) && '' !== (string) $attributes[ $source_key ] ) {
			update_post_meta( $post_id, $meta_key, $attributes[ $source_key ] );
		}
	}
}

/**
 * Assign existing catalog taxonomies when the connector supplies them.
 *
 * @param int    $post_id    Product ID.
 * @param string $post_type  Product post type.
 * @param array  $attributes Normalized attributes.
 * @return void
 */
function luismacchine_tutti_update_taxonomies( $post_id, $post_type, $attributes ) {
	if ( LUISMACCHINE_VEHICLE_POST_TYPE === $post_type && ! empty( $attributes['brand'] ) ) {
		wp_set_object_terms( $post_id, $attributes['brand'], 'marca-veicolo', false );
	}
	if ( LUISMACCHINE_PART_POST_TYPE === $post_type && ! empty( $attributes['part_category'] ) ) {
		wp_set_object_terms( $post_id, $attributes['part_category'], 'categoria-ricambio', false );
	}
}

/**
 * Locate a product linked to one tutti.ch listing.
 *
 * @param string $external_id External listing ID.
 * @return int
 */
function luismacchine_tutti_find_post( $external_id ) {
	$posts = get_posts(
		array(
			'post_type'              => array( LUISMACCHINE_VEHICLE_POST_TYPE, LUISMACCHINE_PART_POST_TYPE ),
			'post_status'            => array( 'publish', 'draft', 'pending', 'private', 'trash' ),
			'posts_per_page'         => 1,
			'fields'                 => 'ids',
			'no_found_rows'          => true,
			'update_post_meta_cache' => false,
			'update_post_term_cache' => false,
			'meta_key'               => '_lm_tutti_id', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
			'meta_value'             => $external_id, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value
		)
	);

	return $posts ? absint( $posts[0] ) : 0;
}

/**
 * Reconcile an incoming listing with an existing manually created product.
 *
 * A match is accepted only when there is exactly one unlinked product with the
 * same price and a strongly matching normalized title. This avoids duplicating
 * the products already entered before the synchronization existed.
 *
 * @param string $post_type Catalog post type.
 * @param array  $item      Normalized listing.
 * @return int
 */
function luismacchine_tutti_find_existing_product( $post_type, $item ) {
	if ( null === $item['price'] ) {
		return 0;
	}

	$candidates = get_posts(
		array(
			'post_type'              => $post_type,
			'post_status'            => array( 'publish', 'draft', 'pending', 'private' ),
			'posts_per_page'         => 100,
			'no_found_rows'          => true,
			'update_post_meta_cache' => true,
			'update_post_term_cache' => false,
			'orderby'                => 'ID',
			'order'                  => 'ASC',
		)
	);
	$incoming_title = luismacchine_tutti_normalize_title( $item['title'] );
	$matches        = array();
	$brand_matches  = array();
	$incoming_brand = isset( $item['attributes']['brand'] ) ? luismacchine_tutti_normalize_brand( $item['attributes']['brand'] ) : '';

	foreach ( $candidates as $candidate ) {
		if ( get_post_meta( $candidate->ID, '_lm_tutti_id', true ) ) {
			continue;
		}
		$candidate_price = get_post_meta( $candidate->ID, '_lm_price', true );
		if ( ! is_numeric( $candidate_price ) || abs( (float) $candidate_price - (float) $item['price'] ) > 0.01 ) {
			continue;
		}

		$candidate_title = luismacchine_tutti_normalize_title( $candidate->post_title );
		$similarity      = 0.0;
		similar_text( $incoming_title, $candidate_title, $similarity );
		if ( $incoming_title === $candidate_title || $similarity >= 72.0 ) {
			$matches[] = $candidate->ID;
			continue;
		}

		if ( LUISMACCHINE_VEHICLE_POST_TYPE === $post_type && '' !== $incoming_brand ) {
			$candidate_brands = wp_get_post_terms( $candidate->ID, 'marca-veicolo', array( 'fields' => 'names' ) );
			if ( ! is_wp_error( $candidate_brands ) ) {
				foreach ( $candidate_brands as $candidate_brand ) {
					if ( $incoming_brand === luismacchine_tutti_normalize_brand( $candidate_brand ) ) {
						$brand_matches[] = $candidate->ID;
						break;
					}
				}
			}
		}
	}

	if ( 1 === count( $matches ) ) {
		return absint( $matches[0] );
	}

	return empty( $matches ) && 1 === count( $brand_matches ) ? absint( $brand_matches[0] ) : 0;
}

/**
 * Normalize known brand aliases for conservative first-sync reconciliation.
 *
 * @param string $brand Brand label.
 * @return string
 */
function luismacchine_tutti_normalize_brand( $brand ) {
	$brand = luismacchine_tutti_normalize_title( $brand );
	$map   = array(
		'vw'       => 'volkswagen',
		'mercedes' => 'mercedes benz',
	);

	return isset( $map[ $brand ] ) ? $map[ $brand ] : $brand;
}

/**
 * Normalize a product title for conservative first-sync reconciliation.
 *
 * @param string $title Product title.
 * @return string
 */
function luismacchine_tutti_normalize_title( $title ) {
	$title = remove_accents( strtolower( sanitize_text_field( $title ) ) );
	$title = preg_replace( '/[^a-z0-9]+/', ' ', $title );
	return trim( preg_replace( '/\s+/', ' ', $title ) );
}

/**
 * Store a compact record for an unknown category.
 *
 * @param array $item Normalized item.
 * @return void
 */
function luismacchine_tutti_queue_pending( $item ) {
	$pending = get_option( LUISMACCHINE_TUTTI_PENDING_OPTION, array() );
	$pending = is_array( $pending ) ? $pending : array();
	$pending[ $item['external_id'] ] = array(
		'title'          => $item['title'],
		'source_url'     => $item['source_url'],
		'category_key'   => $item['category_key'],
		'category_label' => $item['category_label'],
		'last_seen'      => time(),
	);
	update_option( LUISMACCHINE_TUTTI_PENDING_OPTION, $pending, false );
}

/**
 * Remove stale pending records that are no longer present in the complete inventory.
 *
 * @param array $current_ids External IDs in the current inventory.
 * @return void
 */
function luismacchine_tutti_prune_pending( $current_ids ) {
	$pending = get_option( LUISMACCHINE_TUTTI_PENDING_OPTION, array() );
	$pending = is_array( $pending ) ? $pending : array();

	foreach ( array_keys( $pending ) as $external_id ) {
		if ( ! in_array( (string) $external_id, $current_ids, true ) ) {
			unset( $pending[ $external_id ] );
		}
	}
	update_option( LUISMACCHINE_TUTTI_PENDING_OPTION, $pending, false );
}

/**
 * Increment the absence counter and trash only after two complete inventories.
 *
 * @param array $seen_ids External IDs present in the current inventory.
 * @return int Number of products moved to Trash.
 */
function luismacchine_tutti_process_missing( $seen_ids ) {
	$catalog_posts = get_posts(
		array(
			'post_type'              => array( LUISMACCHINE_VEHICLE_POST_TYPE, LUISMACCHINE_PART_POST_TYPE ),
			'post_status'            => array( 'publish', 'draft', 'pending', 'private' ),
			'posts_per_page'         => 500,
			'fields'                 => 'ids',
			'no_found_rows'          => true,
			'update_post_meta_cache' => true,
			'update_post_term_cache' => false,
		)
	);
	$trashed = 0;

	foreach ( $catalog_posts as $post_id ) {
		$external_id = (string) get_post_meta( $post_id, '_lm_tutti_id', true );
		if ( $external_id && in_array( $external_id, $seen_ids, true ) ) {
			delete_post_meta( $post_id, '_lm_tutti_missing_count' );
			continue;
		}

		// The public tutti.ch inventory is the source of truth for both catalogs.
		update_post_meta( $post_id, '_lm_tutti_managed', '1' );
		$missing_count = absint( get_post_meta( $post_id, '_lm_tutti_missing_count', true ) ) + 1;
		update_post_meta( $post_id, '_lm_tutti_missing_count', $missing_count );
		if ( $missing_count >= 2 && wp_trash_post( $post_id ) ) {
			++$trashed;
		}
	}

	return $trashed;
}
