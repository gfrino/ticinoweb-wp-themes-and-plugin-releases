<?php defined('ABSPATH') || exit; $contact = albatros_contact(); ?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php wp_head(); ?>
</head>
<body <?php body_class('albatros'); ?>>
<?php wp_body_open(); ?>
<a class="alb-skip" href="#contenuto"><?php esc_html_e('Vai al contenuto', 'albatrossagl-child-theme'); ?></a>
<header class="alb-header">
    <div class="alb-wrap alb-header-inner">
        <a class="alb-logo" href="<?php echo esc_url(albatros_url()); ?>" aria-label="<?php echo esc_attr(get_bloginfo('name')); ?>">
            <?php $logo = albatros_image(get_option('ticinoweb_site_logo'), 'medium', array('loading' => 'eager', 'alt' => get_bloginfo('name')));
            if ($logo) { echo $logo; } else { echo esc_html(get_bloginfo('name')); } ?>
        </a>
        <button class="alb-menu-toggle" type="button" aria-controls="alb-navigation" aria-expanded="false"><?php esc_html_e('Menu', 'albatrossagl-child-theme'); ?><span aria-hidden="true">☰</span></button>
        <nav id="alb-navigation" class="alb-nav" aria-label="<?php esc_attr_e('Navigazione principale', 'albatrossagl-child-theme'); ?>">
            <?php wp_nav_menu(array('theme_location' => 'albatros_primary', 'container' => false, 'menu_class' => 'alb-menu', 'fallback_cb' => false, 'depth' => 1)); ?>
        </nav>
        <a class="alb-button alb-header-cta" href="<?php echo esc_url(albatros_url('contatti')); ?>"><?php esc_html_e('Parliamo dei tuoi spazi', 'albatrossagl-child-theme'); ?><span aria-hidden="true">↗</span></a>
    </div>
</header>
<main id="contenuto">
