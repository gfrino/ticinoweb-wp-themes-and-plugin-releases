/* Albatros: progressive navigation and the parent's contact endpoint. */
(() => {
  'use strict';
  document.documentElement.classList.add('alb-js');
  const toggle = document.querySelector('.alb-menu-toggle');
  const navigation = document.querySelector('.alb-nav');
  const closeMenu = (restoreFocus = false) => {
    if (!toggle || !navigation) return;
    toggle.setAttribute('aria-expanded', 'false');
    navigation.classList.remove('is-open');
    if (restoreFocus) toggle.focus();
  };
  toggle?.addEventListener('click', () => {
    const open = toggle.getAttribute('aria-expanded') !== 'true';
    toggle.setAttribute('aria-expanded', String(open));
    navigation?.classList.toggle('is-open', open);
  });
  navigation?.addEventListener('click', (event) => {
    if (event.target.closest('a')) closeMenu();
  });
  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape' && toggle?.getAttribute('aria-expanded') === 'true') closeMenu(true);
  });
  document.querySelector('.alb-cookie-settings')?.addEventListener('click', () => {
    // The parent removes its consent UI after a choice. Reload it after clearing only its cookies.
    ['tw_cookie_consent', 'tw_cookie_preferences'].forEach((key) => {
      document.cookie = `${key}=; max-age=0; path=/; SameSite=Lax`;
    });
    window.location.reload();
  });
  const form = document.querySelector('.alb-form');
  if (!form || typeof albatrosConfig === 'undefined') return;
  document.querySelectorAll('[data-service]').forEach((link) => {
    link.addEventListener('click', () => {
      const select = form.elements.namedItem('oggetto');
      if (select) select.value = link.dataset.service;
    });
  });

  let recaptchaPromise;
  const recaptcha = () => {
    if (!albatrosConfig.recaptchaKey) return Promise.resolve('');
    if (!recaptchaPromise) {
      recaptchaPromise = new Promise((resolve, reject) => {
        if (window.grecaptcha?.execute) return resolve(window.grecaptcha);
        const script = document.createElement('script');
        script.src = `https://www.google.com/recaptcha/api.js?render=${encodeURIComponent(albatrosConfig.recaptchaKey)}`;
        script.async = true;
        script.onload = () => resolve(window.grecaptcha);
        script.onerror = () => { recaptchaPromise = undefined; script.remove(); reject(new Error(albatrosConfig.error)); };
        document.head.append(script);
      });
    }
    return recaptchaPromise.then((api) => new Promise((resolve, reject) => {
      api.ready(() => api.execute(albatrosConfig.recaptchaKey, {action:'contact'}).then(resolve, reject));
    }));
  };
  const request = async (data) => {
    const controller = new AbortController();
    const timeout = window.setTimeout(() => controller.abort(), 25000);
    try {
      const response = await fetch(albatrosConfig.ajaxUrl, {method:'POST', body:data, credentials:'same-origin', signal:controller.signal});
      return await response.json();
    } finally { window.clearTimeout(timeout); }
  };
  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    if (!form.reportValidity()) return;
    const button = form.querySelector('button[type="submit"]');
    const status = form.querySelector('.alb-form-status');
    const label = button.innerHTML;
    form.querySelectorAll('[aria-invalid]').forEach((field) => { field.removeAttribute('aria-invalid'); field.removeAttribute('aria-describedby'); });
    form.querySelectorAll('.alb-field-error').forEach((error) => error.remove());
    button.disabled = true;
    button.textContent = albatrosConfig.sending;
    form.setAttribute('aria-busy', 'true');
    status.textContent = albatrosConfig.sending;
    status.dataset.state = 'pending';
    try {
      const tokenData = new FormData();
      tokenData.append('action', 'ticinoweb_form_token');
      const token = await request(tokenData);
      if (!token.success || !token.data?.token) throw new Error(albatrosConfig.error);
      const data = new FormData(form);
      data.set('action', 'ticinoweb_submit_form');
      data.set('token', token.data.token);
      const rcToken = await Promise.race([recaptcha(), new Promise((_, reject) => window.setTimeout(() => reject(new Error(albatrosConfig.error)), 20000))]);
      if (rcToken) data.set('recaptcha_token', rcToken);
      const result = await request(data);
      if (!result.success) {
        Object.entries(result.data?.fields || {}).forEach(([name, message]) => {
          const field = form.elements.namedItem(name);
          if (!field) return;
          const error = document.createElement('span');
          error.className = 'alb-field-error';
          error.id = `alb-error-${name}`;
          error.textContent = message || albatrosConfig.fieldError;
          field.setAttribute('aria-invalid', 'true');
          field.setAttribute('aria-describedby', error.id);
          field.closest('label')?.append(error);
        });
        throw new Error(result.data?.message || albatrosConfig.error);
      }
      status.dataset.state = 'success';
      status.textContent = result.data?.message || '';
      form.reset();
      status.focus({preventScroll:true});
    } catch (error) {
      status.dataset.state = 'error';
      status.textContent = error.name === 'AbortError' ? albatrosConfig.error : error.message || albatrosConfig.error;
      const invalid = form.querySelector('[aria-invalid="true"]');
      (invalid || status).focus({preventScroll:!invalid});
    } finally {
      button.disabled = false;
      button.innerHTML = label;
      form.removeAttribute('aria-busy');
    }
  });
})();
