<?php defined('ABSPATH') || exit; $contact = albatros_contact(); $privacy = get_privacy_policy_url(); ?>
<div class="alb-contact-grid">
    <div class="alb-contact-info">
        <?php if (!empty($contact['phone'])) : ?><a class="alb-phone" href="<?php echo esc_url('tel:' . preg_replace('/[^+0-9]/', '', $contact['phone'])); ?>"><?php echo esc_html($contact['phone_display'] ?: $contact['phone']); ?></a><?php endif; ?>
        <?php if (!empty($contact['email'])) : ?><a href="<?php echo esc_url('mailto:' . sanitize_email($contact['email'])); ?>"><?php echo esc_html($contact['email']); ?></a><?php endif; ?>
        <?php if (!empty($contact['address'])) : ?><address><?php echo esc_html($contact['address']); ?></address><?php endif; ?>
        <?php if (!empty($contact['opening_hours_note'])) : ?><p class="alb-hours"><?php echo nl2br(esc_html($contact['opening_hours_note'])); ?></p><?php endif; ?>
        <?php if (!empty($contact['map_url'])) : ?><a class="alb-text-link" href="<?php echo esc_url($contact['map_url']); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e('Apri le indicazioni', 'albatrossagl-child-theme'); ?> ↗</a><?php endif; ?>
    </div>
    <form class="alb-form" method="post" action="<?php echo esc_url(admin_url('admin-ajax.php')); ?>" aria-label="<?php esc_attr_e('Richiesta di preventivo', 'albatrossagl-child-theme'); ?>">
        <input type="hidden" name="albatros_request" value="quote">
        <div class="alb-form-row"><label><?php esc_html_e('Nome e cognome', 'albatrossagl-child-theme'); ?><input name="nome" autocomplete="name" required minlength="2" maxlength="150"></label><label><?php esc_html_e('Email', 'albatrossagl-child-theme'); ?><input name="email" type="email" autocomplete="email" required maxlength="200"></label></div>
        <div class="alb-form-row"><label><?php esc_html_e('Telefono (facoltativo)', 'albatrossagl-child-theme'); ?><input name="telefono" type="tel" autocomplete="tel" maxlength="40"></label><label><?php esc_html_e('Località', 'albatrossagl-child-theme'); ?><input name="localita" autocomplete="address-level2" maxlength="160"></label></div>
        <div class="alb-form-row"><label><?php esc_html_e('La richiesta è per', 'albatrossagl-child-theme'); ?><select name="cliente"><option value=""><?php esc_html_e('Seleziona', 'albatrossagl-child-theme'); ?></option><option><?php esc_html_e('Un privato', 'albatrossagl-child-theme'); ?></option><option><?php esc_html_e('Un’azienda o uno stabile', 'albatrossagl-child-theme'); ?></option></select></label><label><?php esc_html_e('Servizio', 'albatrossagl-child-theme'); ?><select name="oggetto"><option value=""><?php esc_html_e('Seleziona un servizio', 'albatrossagl-child-theme'); ?></option><?php foreach ((function_exists('ticinoweb_get_services') ? ticinoweb_get_services() : array()) as $i => $service) : $title = function_exists('ticinoweb_frontend_text') ? ticinoweb_frontend_text($service['title'], 'theme:service:' . ($service['id'] ?? $i) . ':title') : $service['title']; ?><option><?php echo esc_html($title); ?></option><?php endforeach; ?></select></label></div>
        <label><?php esc_html_e('Di cosa hai bisogno?', 'albatrossagl-child-theme'); ?><textarea name="messaggio" rows="4" required minlength="5" maxlength="4500"></textarea></label>
        <div class="alb-honeypot" aria-hidden="true"><label><?php esc_html_e('Lascia vuoto questo campo', 'albatrossagl-child-theme'); ?><input name="tw_hp" tabindex="-1" autocomplete="off"></label></div>
        <label class="alb-consent"><input name="privacy" type="checkbox" value="1" required><span><?php esc_html_e('Ho letto l’informativa sul trattamento dei dati per la gestione della richiesta.', 'albatrossagl-child-theme'); ?> <?php if ($privacy) : ?><a href="<?php echo esc_url($privacy); ?>"><?php esc_html_e('Leggi la privacy', 'albatrossagl-child-theme'); ?></a><?php endif; ?></span></label>
        <button class="alb-button" type="submit"><?php esc_html_e('Invia la richiesta', 'albatrossagl-child-theme'); ?> <span aria-hidden="true">↗</span></button>
        <p class="alb-form-status" role="status" aria-live="polite" tabindex="-1"></p>
        <noscript><p><?php esc_html_e('Per inviare il modulo attiva JavaScript, oppure usa i contatti indicati accanto.', 'albatrossagl-child-theme'); ?></p></noscript>
    </form>
</div>
