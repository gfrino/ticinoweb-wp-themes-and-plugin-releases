<?php
/**
 * Contenuti di partenza del sito, scritti nel CMS del parent alla prima attivazione.
 *
 * Riempie solo ciò che è vuoto: non sovrascrive mai un dato già inserito. Tutto si
 * modifica poi da ticinoWEB CMS (orari, servizi, chi siamo) e da Bacheca → FAQ.
 *
 * @package BarMyWayChildTheme
 */

defined( 'ABSPATH' ) || exit;

const BARMYWAY_SEED_VERSION = 1;

function barmyway_seed() {
	if ( (int) get_option( 'barmyway_seed_version', 0 ) >= BARMYWAY_SEED_VERSION ) {
		return;
	}

	$tagline = (string) get_option( 'blogdescription', '' );
	if ( '' === $tagline || 'Just another WordPress site' === $tagline ) {
		update_option( 'blogdescription', 'Il tuo caffè lungo la strada, all’ArbedSmart Center di Arbedo' );
	}

	if ( '' === trim( (string) get_option( 'ticinoweb_contact_address', '' ) ) ) {
		update_option( 'ticinoweb_contact_address', "ArbedSmart Center\n6517 Arbedo" );
	}

	$hours = get_option( 'ticinoweb_contact_opening_hours', array() );
	if ( empty( $hours ) ) {
		$weekday = array(
			'closed'   => 0,
			'open_24h' => 0,
			'slots'    => array( array( 'open' => '06:30', 'close' => '18:30' ) ),
		);
		update_option(
			'ticinoweb_contact_opening_hours',
			array(
				'monday'    => $weekday,
				'tuesday'   => $weekday,
				'wednesday' => $weekday,
				'thursday'  => $weekday,
				'friday'    => $weekday,
				'saturday'  => array(
					'closed'   => 0,
					'open_24h' => 0,
					'slots'    => array( array( 'open' => '07:30', 'close' => '13:00' ) ),
				),
				'sunday'    => array(
					'closed'   => 1,
					'open_24h' => 0,
					'slots'    => array(),
				),
			)
		);
	}

	$services = get_option( 'ticinoweb_services', array() );
	if ( empty( $services ) ) {
		update_option(
			'ticinoweb_services',
			array(
				array(
					'id'          => 'srv_bmw_caffe',
					'title'       => 'Caffè e colazioni',
					'description' => 'Espresso, cappuccino e cornetti caldi fin dal mattino presto, anche da portare via.',
				),
				array(
					'id'          => 'srv_bmw_pranzo',
					'title'       => 'Pranzo veloce',
					'description' => 'Panini, insalate e piatto del giorno per la pausa pranzo, pronti in pochi minuti.',
				),
				array(
					'id'          => 'srv_bmw_aperitivo',
					'title'       => 'Aperitivo',
					'description' => 'Calici, stuzzichini e un tagliere da dividere a fine giornata o dopo una riunione.',
				),
				array(
					'id'          => 'srv_bmw_meeting',
					'title'       => 'Pause per le riunioni',
					'description' => 'Caffè, acqua e qualcosa da sgranocchiare per chi ha una sala prenotata nel centro: ordini e ti raggiungiamo.',
				),
			)
		);
	}

	if ( '' === trim( (string) get_option( 'ticinoweb_chi_siamo_title', '' ) ) ) {
		update_option( 'ticinoweb_chi_siamo_title', 'Una sosta che sa di casa' );
	}
	if ( '' === trim( (string) get_option( 'ticinoweb_chi_siamo_text', '' ) ) ) {
		update_option(
			'ticinoweb_chi_siamo_text',
			"Bar my Way è il bar dell’ArbedSmart Center di Arbedo: un posto dove fermarsi cinque minuti, senza fretta, che tu lavori qui, sia in viaggio o ti fermi per la notte.\n\nCaffè scelto con cura, prodotti freschi ogni giorno e un saluto vero al banco. Ognuno ha il suo modo di fare strada: il nostro è farti stare bene lungo la tua."
		);
	}

	if ( function_exists( 'ticinoweb_faq_upsert_set' ) && function_exists( 'ticinoweb_faq_find' ) && ! ticinoweb_faq_find( 'bar-my-way' ) ) {
		ticinoweb_faq_upsert_set(
			'bar-my-way',
			'Domande su Bar my Way',
			array(
				array(
					'q'       => 'Dove si trova Bar my Way?',
					'a'       => 'Bar my Way si trova all’interno dell’ArbedSmart Center di Arbedo, sulla strada tra Bellinzona e il Gottardo, ed è aperto anche a chi non alloggia o lavora nel centro.',
					'visible' => 1,
				),
				array(
					'q'       => 'Qual è l’orario di apertura?',
					'a'       => 'Siamo aperti dal lunedì al venerdì dalle 6.30 alle 18.30 e il sabato dalle 7.30 alle 13.00. La domenica siamo chiusi.',
					'visible' => 1,
				),
				array(
					'q'       => 'Posso ordinare caffè e snack per una riunione?',
					'a'       => 'Sì. Se hai una sala riunioni all’ArbedSmart Center scrivici o chiamaci prima: prepariamo caffè, acqua e qualcosa da mangiare e te li portiamo all’orario che indichi.',
					'visible' => 1,
				),
				array(
					'q'       => 'Servite la colazione?',
					'a'       => 'Sì, dalle 6.30 con caffè, cappuccino, cornetti e brioche appena sfornati. Puoi consumare al banco, al tavolo o portare via.',
					'visible' => 1,
				),
				array(
					'q'       => 'Bisogna prenotare un tavolo?',
					'a'       => 'Per un caffè o un pranzo veloce no, basta entrare. Per gruppi di più di otto persone ti consigliamo di avvisarci in anticipo, così ti riserviamo i posti.',
					'visible' => 1,
				),
			),
			array( 'intro' => 'Le risposte alle domande che ci fanno più spesso al banco.' )
		);
	}

	update_option( 'barmyway_seed_version', BARMYWAY_SEED_VERSION, false );
}
// Alla prima attivazione; admin_init copre il caso di un sito dove il tema è già attivo quando il codice arriva.
add_action( 'after_switch_theme', 'barmyway_seed' );
add_action( 'admin_init', 'barmyway_seed' );
