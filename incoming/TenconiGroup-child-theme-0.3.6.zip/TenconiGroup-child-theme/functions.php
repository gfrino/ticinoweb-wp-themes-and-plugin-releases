<?php
/**
 * Tenconi Group child theme - bootstrap.
 *
 * Tema figlio di ticinoweb-ai-theme. Il parent non si modifica mai: tutto passa
 * da hook, filtri e funzioni del parent (logo, contatti, SEO, cookie).
 *
 * @package tenconigroup
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'TG_VERSION', '0.3.6' );
define( 'TG_DIR', get_stylesheet_directory() );
define( 'TG_URI', get_stylesheet_directory_uri() );

require_once TG_DIR . '/inc/setup.php';
require_once TG_DIR . '/inc/content.php';
require_once TG_DIR . '/inc/icons.php';
require_once TG_DIR . '/inc/customizer.php';
require_once TG_DIR . '/inc/admin.php';
