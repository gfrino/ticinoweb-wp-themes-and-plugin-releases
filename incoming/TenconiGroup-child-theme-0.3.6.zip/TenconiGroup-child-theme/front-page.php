<?php
/**
 * Homepage: presentazione del gruppo, le due societa' con sito proprio e,
 * sotto, le altre societa' del gruppo.
 *
 * Corta per scelta: un'introduzione, due grandi riquadri cliccabili di pari
 * peso e due schede. Ogni testo viene dal Personalizza (inc/content.php).
 *
 * @package tenconigroup
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

$tg_label     = tg_text( 'tg_hero_label' );
$tg_title     = tg_text( 'tg_hero_title' );
$tg_intro     = tg_text( 'tg_hero_text' );
$tg_companies = tg_companies( 'home' );
$tg_cta       = tg_text( 'tg_home_cta' );
if ( '' === $tg_cta ) {
	$tg_cta = __( 'Visita il sito', 'tenconigroup' );
}
?>

<section class="tg-hero" aria-labelledby="tg-hero-title">
	<?php tg_the_mesh( 'hero' ); // Sfondo «mesh»: blu che sfuma nel bianco e si muove allo scorrimento. ?>
	<div class="tg-wrap tg-hero__in">
		<div class="tg-hero__id">
			<?php tg_the_symbol( 'tg-hero__symbol', 'medium' ); ?>
			<?php if ( '' !== $tg_label ) : ?>
				<p class="tg-hero__label"><?php echo esc_html( $tg_label ); ?></p>
			<?php endif; ?>
		</div>
		<h1 id="tg-hero-title" class="tg-hero__title"><?php echo esc_html( '' !== $tg_title ? $tg_title : get_bloginfo( 'name' ) ); ?></h1>
		<?php if ( '' !== $tg_intro ) : ?>
			<p class="tg-hero__text"><?php echo nl2br( esc_html( $tg_intro ) ); ?></p>
		<?php else : ?>
			<?php tg_admin_hint( __( 'Manca il testo di presentazione.', 'tenconigroup' ), 'tg_sec_intro' ); ?>
		<?php endif; ?>
	</div>
</section>

<section class="tg-band" aria-label="<?php esc_attr_e( 'Le società del gruppo con sito proprio', 'tenconigroup' ); ?>">
		<?php if ( empty( $tg_companies ) ) : ?>
			<div class="tg-wrap"><?php tg_admin_hint( __( 'Nessuna società in homepage.', 'tenconigroup' ), 'tg_sec_home' ); ?></div>
		<?php else : ?>
			<ul class="tg-panels tg-panels--<?php echo (int) count( $tg_companies ); ?>">
				<?php foreach ( $tg_companies as $tg_n => $tg_c ) : ?>
					<?php
					$tg_tag  = '' !== $tg_c['url'] ? 'a' : 'div';
					$tg_href = '' !== $tg_c['url'] ? ' href="' . esc_url( $tg_c['url'] ) . '"' : '';
					?>
					<li class="tg-panels__item">
						<<?php echo $tg_tag . $tg_href; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- tag fisso, href escapato sopra. ?> class="tg-panel">
							<span class="tg-panel__top">
								<span class="tg-panel__idx"><?php echo esc_html( sprintf( '%02d', $tg_n + 1 ) ); ?></span>
								<?php if ( '' !== $tg_c['url'] ) : ?>
									<span class="tg-panel__host"><?php echo esc_html( tg_url_label( $tg_c['url'] ) ); ?></span>
								<?php endif; ?>
							</span>
							<span class="tg-panel__mark"><?php tg_the_company_mark( $tg_c, 'medium' ); ?></span>
							<h2 class="tg-panel__name"><?php echo esc_html( $tg_c['name'] ); ?></h2>
							<?php if ( '' !== $tg_c['desc'] ) : ?>
								<span class="tg-panel__desc"><?php echo esc_html( $tg_c['desc'] ); ?></span>
							<?php endif; ?>
							<?php if ( '' !== $tg_c['url'] ) : ?>
								<span class="tg-panel__cta">
									<span class="tg-panel__cta-t"><?php echo esc_html( $tg_cta ); ?></span>
									<svg class="tg-panel__arrow" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M7 17 17 7M9 7h8v8" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="square"/></svg>
								</span>
							<?php endif; ?>
						</<?php echo $tg_tag; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- 'a' o 'div'. ?>>
					</li>
				<?php endforeach; ?>
			</ul>
		<?php endif; ?>
</section>

<?php
/*
 * LE ALTRE SOCIETA' DEL GRUPPO, sotto i due riquadri. Stessa grammatica (segno,
 * nome, descrizione, filetto) ma su campo chiaro e senza collegamento, perche'
 * queste societa' non hanno un sito: sono schede, non pulsanti.
 */
$tg_others       = tg_companies( 'soc' );
$tg_others_title = tg_text( 'tg_soc_title' );
$tg_others_intro = tg_text( 'tg_soc_intro' );
if ( ! empty( $tg_others ) ) :
	?>
	<section class="tg-others" aria-labelledby="tg-others-title">
		<div class="tg-wrap">
			<div class="tg-others__hd">
				<h2 id="tg-others-title" class="tg-others__title"><?php echo esc_html( '' !== $tg_others_title ? $tg_others_title : __( 'Le altre società del gruppo', 'tenconigroup' ) ); ?></h2>
				<?php if ( '' !== $tg_others_intro ) : ?>
					<p class="tg-others__text"><?php echo nl2br( esc_html( $tg_others_intro ) ); ?></p>
				<?php endif; ?>
			</div>
			<ul class="tg-sheets tg-sheets--<?php echo (int) min( 2, count( $tg_others ) ); ?>">
				<?php foreach ( $tg_others as $tg_c ) : ?>
					<li class="tg-sheet">
						<span class="tg-sheet__mark"><?php tg_the_company_mark( $tg_c, 'medium' ); ?></span>
						<h3 class="tg-sheet__name"><?php echo esc_html( $tg_c['name'] ); ?></h3>
						<?php if ( '' !== $tg_c['meta'] ) : ?>
							<p class="tg-sheet__meta"><?php echo esc_html( $tg_c['meta'] ); ?></p>
						<?php endif; ?>
						<?php if ( '' !== $tg_c['desc'] ) : ?>
							<p class="tg-sheet__desc"><?php echo nl2br( esc_html( $tg_c['desc'] ) ); ?></p>
						<?php endif; ?>
						<?php if ( '' !== $tg_c['url'] ) : ?>
							<p class="tg-sheet__link"><a href="<?php echo esc_url( $tg_c['url'] ); ?>"><?php echo esc_html( tg_url_label( $tg_c['url'] ) ); ?></a></p>
						<?php endif; ?>
					</li>
				<?php endforeach; ?>
			</ul>
		</div>
	</section>
<?php endif; ?>

<?php
get_footer();
