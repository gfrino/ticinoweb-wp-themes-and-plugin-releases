/*
 * Header che scende con la pagina, come su tenconi.ch: in cima resta com'e'
 * (trasparente sopra lo sfondo della homepage), appena si scorre diventa bianco
 * e compatto. Lo stato sta su <html data-tg-hd-solido>.
 *
 * IntersectionObserver e non un ascoltatore su scroll: basta sapere se un
 * sensore alto 24 px in cima alla pagina e' ancora in vista.
 */
( function () {
	var doc = document.documentElement;
	var sensore = document.querySelector( '[data-tg-sensore]' );
	if ( ! sensore ) {
		return;
	}
	if ( ! ( 'IntersectionObserver' in window ) ) {
		doc.setAttribute( 'data-tg-hd-solido', '' );
		return;
	}
	new IntersectionObserver( function ( voci ) {
		doc.toggleAttribute( 'data-tg-hd-solido', ! voci[ 0 ].isIntersecting );
	}, { threshold: 0 } ).observe( sensore );
}() );
