(function () {
	'use strict';

	var gate = document.querySelector('[data-oasi-age-gate]');
	if (!gate || !window.oasiAgeGateConfig || !oasiAgeGateConfig.sessionKey) {
		return;
	}

	try {
		if (window.sessionStorage.getItem(oasiAgeGateConfig.sessionKey)) {
			gate.remove();
			return;
		}
	} catch (error) {
		// Storage can be unavailable in private browsing; the gate still works.
	}

	var dialog = gate.querySelector('[role="dialog"]');
	var confirmButton = gate.querySelector('[data-oasi-age-confirm]');
	var declineButton = gate.querySelector('[data-oasi-age-decline]');
	var previousFocus = document.activeElement;

	function rememberConfirmation() {
		try {
			window.sessionStorage.setItem(oasiAgeGateConfig.sessionKey, '1');
		} catch (error) {
			// Confirmation must remain usable even when storage is unavailable.
		}
	}

	function closeGate() {
		rememberConfirmation();
		gate.remove();
		document.body.classList.remove('oasi-age-gate-open');
		if (previousFocus && document.contains(previousFocus)) {
			previousFocus.focus();
		}
	}

	function keepFocusInside(event) {
		if (event.key !== 'Tab' || !dialog) {
			return;
		}
		var focusable = Array.prototype.slice.call(dialog.querySelectorAll('button:not([disabled]), [tabindex]:not([tabindex="-1"])'));
		if (!focusable.length) {
			event.preventDefault();
			dialog.focus();
			return;
		}
		var first = focusable[0];
		var last = focusable[focusable.length - 1];
		if (event.shiftKey && document.activeElement === first) {
			event.preventDefault();
			last.focus();
		} else if (!event.shiftKey && document.activeElement === last) {
			event.preventDefault();
			first.focus();
		}
	}

	document.body.classList.add('oasi-age-gate-open');
	if (dialog) {
		dialog.focus();
	}

	if (confirmButton) {
		confirmButton.addEventListener('click', closeGate);
	}

	if (declineButton) {
		declineButton.addEventListener('click', function () {
			window.location.assign(oasiAgeGateConfig.exitUrl || '/');
		});
	}

	document.addEventListener('keydown', function (event) {
		keepFocusInside(event);
		if (event.key === 'Escape') {
			event.preventDefault();
			if (dialog) {
				dialog.focus();
			}
		}
	});
}());
