<?php
$tw_footer_contact = function_exists( 'ticinoweb_get_contact_info' ) ? ticinoweb_get_contact_info() : array();
$tw_footer_logo    = function_exists( 'ticinoweb_get_site_logo' ) ? (string) ticinoweb_get_site_logo() : '';
$tw_footer_logo_id = $tw_footer_logo ? attachment_url_to_postid( $tw_footer_logo ) : 0;
$tw_footer_locations = array(
	'footer-company'    => __( 'Azienda e sedi', 'ticinoweb-child-theme' ),
	'footer-services'   => __( 'Servizi', 'ticinoweb-child-theme' ),
	'footer-actions'    => __( 'Strumenti', 'ticinoweb-child-theme' ),
	'footer-commitment' => __( 'Il nostro impegno sociale', 'ticinoweb-child-theme' ),
);
?>
<footer class="tw-site-footer">
	<div class="tw-footer-atmosphere" aria-hidden="true">
		<span class="tw-footer-glow tw-footer-glow--blue"></span>
		<span class="tw-footer-glow tw-footer-glow--orange"></span>
	</div>

	<div class="tw-shell tw-footer-core">
		<div class="tw-footer-brand">
			<a class="tw-footer-brand__mark" href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home" aria-label="<?php esc_attr_e( 'ticinoWEB — Home', 'ticinoweb-child-theme' ); ?>">
				<?php if ( $tw_footer_logo_id ) : ?>
					<?php echo wp_get_attachment_image( $tw_footer_logo_id, 'full', false, array( 'class' => 'tw-footer-brand__logo', 'alt' => '', 'loading' => 'lazy', 'decoding' => 'async', 'sizes' => '(max-width: 600px) 132px, 160px' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				<?php elseif ( $tw_footer_logo ) : ?>
					<img class="tw-footer-brand__logo" src="<?php echo esc_url( $tw_footer_logo ); ?>" alt="" loading="lazy" decoding="async">
				<?php else : ?>
					<span>ticino<strong>WEB</strong></span>
				<?php endif; ?>
			</a>
			<p><?php esc_html_e( 'Web Design e soluzioni digitali progettate a Locarno per aziende che vogliono crescere.', 'ticinoweb-child-theme' ); ?></p>
			<?php if ( function_exists( 'tw_social_render' ) ) tw_social_render( 'tw-footer-socials' ); ?>
		</div>

		<nav class="tw-footer-navigation" aria-labelledby="tw-footer-navigation-title">
			<h2 id="tw-footer-navigation-title" class="tw-footer-heading"><?php esc_html_e( 'Navigazione', 'ticinoweb-child-theme' ); ?></h2>
			<?php if ( has_nav_menu( 'primary' ) ) : ?>
				<?php wp_nav_menu( array( 'theme_location' => 'primary', 'container' => false, 'menu_class' => 'tw-footer-menu tw-footer-menu--navigation', 'fallback_cb' => false, 'depth' => 1 ) ); ?>
			<?php elseif ( has_nav_menu( 'footer-company' ) ) : ?>
				<?php wp_nav_menu( array( 'theme_location' => 'footer-company', 'container' => false, 'menu_class' => 'tw-footer-menu tw-footer-menu--navigation', 'fallback_cb' => false, 'depth' => 1 ) ); ?>
			<?php endif; ?>
		</nav>

		<div class="tw-footer-contact">
			<h2 class="tw-footer-heading"><?php esc_html_e( 'Contatti', 'ticinoweb-child-theme' ); ?></h2>
			<address>
				<?php if ( ! empty( $tw_footer_contact['phone'] ) ) : ?><a href="tel:<?php echo esc_attr( preg_replace( '/[^+0-9]/', '', $tw_footer_contact['phone'] ) ); ?>"><?php echo esc_html( $tw_footer_contact['phone'] ); ?></a><?php endif; ?>
				<?php if ( ! empty( $tw_footer_contact['email'] ) ) : ?><a href="mailto:<?php echo esc_attr( antispambot( $tw_footer_contact['email'] ) ); ?>"><?php echo esc_html( antispambot( $tw_footer_contact['email'] ) ); ?></a><?php endif; ?>
				<?php if ( ! empty( $tw_footer_contact['address'] ) ) : ?><span><?php echo esc_html( $tw_footer_contact['address'] ); ?></span><?php endif; ?>
			</address>
		</div>
	</div>

	<div class="tw-shell tw-footer-directory">
		<?php $tw_stack_open = false; ?>
		<?php foreach ( $tw_footer_locations as $tw_location => $tw_heading ) : ?>
			<?php if ( has_nav_menu( $tw_location ) ) : ?>
				<?php
				// «Strumenti» e «Il nostro impegno sociale» condividono una colonna, una sopra l'altra.
				$tw_in_stack = in_array( $tw_location, array( 'footer-actions', 'footer-commitment' ), true );
				if ( $tw_in_stack && ! $tw_stack_open ) {
					echo '<div class="tw-footer-column tw-footer-column--stack">';
					$tw_stack_open = true;
				}
				?>
				<nav class="<?php echo $tw_in_stack ? 'tw-footer-block' : 'tw-footer-column'; ?> tw-footer-column--<?php echo esc_attr( sanitize_html_class( $tw_location ) ); ?>" aria-labelledby="tw-<?php echo esc_attr( sanitize_key( $tw_location ) ); ?>-title">
					<h2 id="tw-<?php echo esc_attr( sanitize_key( $tw_location ) ); ?>-title" class="tw-footer-heading"><?php echo esc_html( $tw_heading ); ?></h2>
					<?php wp_nav_menu( array( 'theme_location' => $tw_location, 'container' => false, 'menu_class' => 'tw-footer-menu tw-footer-menu--directory', 'fallback_cb' => false, 'depth' => 2 ) ); ?>
				</nav>
			<?php endif; ?>
		<?php endforeach; ?>
		<?php if ( $tw_stack_open ) { echo '</div>'; } ?>
	</div>

	<div class="tw-shell tw-footer-bottom">
		<div class="tw-footer-copyright"><span>© <?php echo esc_html( gmdate( 'Y' ) ); ?> ticinoWEB</span><span><?php esc_html_e( 'Locarno · Ticino · Switzerland', 'ticinoweb-child-theme' ); ?></span></div>
		<?php if ( has_nav_menu( 'footer-legal' ) ) : ?>
			<nav aria-label="<?php esc_attr_e( 'Informazioni legali', 'ticinoweb-child-theme' ); ?>"><?php wp_nav_menu( array( 'theme_location' => 'footer-legal', 'container' => false, 'menu_class' => 'tw-footer-menu tw-footer-menu--legal', 'fallback_cb' => false, 'depth' => 1 ) ); ?></nav>
		<?php elseif ( get_privacy_policy_url() ) : ?>
			<nav aria-label="<?php esc_attr_e( 'Informazioni legali', 'ticinoweb-child-theme' ); ?>"><ul class="tw-footer-menu tw-footer-menu--legal"><li><a href="<?php echo esc_url( get_privacy_policy_url() ); ?>"><?php esc_html_e( 'Privacy', 'ticinoweb-child-theme' ); ?></a></li></ul></nav>
		<?php endif; ?>
	</div>
</footer>
<?php wp_footer(); ?>
</body>
</html>
