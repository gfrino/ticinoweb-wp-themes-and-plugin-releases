<?php
/** Wine-specific editorial data. Original catalog fields remain the technical source. */
defined( 'ABSPATH' ) || exit;

function adb_tasting_axes() {
    return array(
        'body' => array( 'label' => __( 'Corpo', 'amicidibacco' ), 'low' => __( 'Leggero', 'amicidibacco' ), 'high' => __( 'Strutturato', 'amicidibacco' ) ),
        'freshness' => array( 'label' => __( 'Freschezza', 'amicidibacco' ), 'low' => __( 'Delicata', 'amicidibacco' ), 'high' => __( 'Vivace', 'amicidibacco' ) ),
        'sweetness' => array( 'label' => __( 'Dolcezza', 'amicidibacco' ), 'low' => __( 'Secco', 'amicidibacco' ), 'high' => __( 'Dolce', 'amicidibacco' ) ),
        'tannin' => array( 'label' => __( 'Tannino', 'amicidibacco' ), 'low' => __( 'Discreto', 'amicidibacco' ), 'high' => __( 'Deciso', 'amicidibacco' ) ),
        'persistence' => array( 'label' => __( 'Persistenza', 'amicidibacco' ), 'low' => __( 'Breve', 'amicidibacco' ), 'high' => __( 'Lunga', 'amicidibacco' ) ),
    );
}

/** No derived or default scores: a scale requires both evidence and a source. */
function adb_sanitize_tasting( $raw ) {
    $raw = is_array( $raw ) ? $raw : array();
    $raw['scores'] = is_array( $raw['scores'] ?? null ) ? $raw['scores'] : array();
    $raw['score_evidence'] = is_array( $raw['score_evidence'] ?? null ) ? $raw['score_evidence'] : array();
    $text = static function ( $value, $length = 1200 ) { return is_scalar( $value ) ? mb_substr( sanitize_textarea_field( (string) $value ), 0, $length ) : ''; };
    $out = array( 'aromas' => array(), 'finish' => $text( $raw['finish'] ?? '' ), 'scores' => array(), 'score_evidence' => array(), 'sources' => array(), 'verification' => 'needs_source', 'reference_vintage' => $text( $raw['reference_vintage'] ?? '', 100 ) );
    $aromas = is_array( $raw['aromas'] ?? null ) ? $raw['aromas'] : preg_split( '/[\r\n,;]+/u', $text( $raw['aromas'] ?? '' ) );
    foreach ( array_slice( $aromas, 0, 20 ) as $aroma ) {
        $aroma = trim( $text( $aroma, 60 ) );
        if ( '' !== $aroma && ! in_array( mb_strtolower( $aroma ), array_map( 'mb_strtolower', $out['aromas'] ), true ) ) { $out['aromas'][] = $aroma; }
        if ( count( $out['aromas'] ) >= 8 ) { break; }
    }
    foreach ( array_slice( is_array( $raw['sources'] ?? null ) ? $raw['sources'] : array(), 0, 12 ) as $source ) {
        if ( ! is_array( $source ) || ! is_string( $source['url'] ?? null ) || strlen( $source['url'] ) > 2048 ) { continue; }
        $url = esc_url_raw( $source['url'], array( 'https', 'http' ) );
        // These are escaped links, never fetched by the theme. Avoid DNS/network on page views.
        if ( ! $url || ! wp_parse_url( $url, PHP_URL_HOST ) || wp_parse_url( $url, PHP_URL_USER ) || wp_parse_url( $url, PHP_URL_PASS ) || ! filter_var( $url, FILTER_VALIDATE_URL ) ) { continue; }
        $title = trim( $text( $source['title'] ?? '', 200 ) ) ?: (string) wp_parse_url( $url, PHP_URL_HOST );
        $out['sources'][] = array( 'url' => $url, 'title' => $title, 'scope' => 'product' === ( $source['scope'] ?? '' ) ? 'product' : 'producer', 'vintage' => $text( $source['vintage'] ?? '', 100 ), 'fields' => array_values( array_filter( array_map( 'sanitize_key', array_slice( array_filter( (array) ( $source['fields'] ?? array() ), 'is_scalar' ), 0, 30 ) ) ) ) );
    }
    if ( in_array( $raw['verification'] ?? '', array( 'official_product', 'legacy_reviewed', 'needs_source' ), true ) ) { $out['verification'] = $raw['verification']; }
    if ( 'official_product' === $out['verification'] && ! array_filter( $out['sources'], static function ( $source ) { return 'product' === $source['scope']; } ) ) { $out['verification'] = 'legacy_reviewed'; }
    foreach ( adb_tasting_axes() as $key => $axis ) {
        $score = $raw['scores'][ $key ] ?? null;
        $evidence = $text( $raw['score_evidence'][ $key ] ?? '', 500 );
        $valid = ( is_int( $score ) || ( is_string( $score ) && preg_match( '/^[1-5]$/D', $score ) ) ) && (int) $score >= 1 && (int) $score <= 5;
        $relevant_sources = array_filter( $out['sources'], static function ( $source ) use ( $key ) {
            return 'product' === $source['scope'] && ( in_array( 'al_palato', $source['fields'], true ) || in_array( $key, $source['fields'], true ) );
        } );
        $out['scores'][ $key ] = $valid && 'official_product' === $out['verification'] && $relevant_sources && '' !== $evidence ? (int) $score : null;
        $out['score_evidence'][ $key ] = null !== $out['scores'][ $key ] ? $evidence : '';
    }
    return $out;
}

function adb_tasting_data( $product_id ) {
    $product_id = absint( $product_id );
    // Format variations inherit the product. No language or vintage cross-copying.
    if ( 'product_variation' === get_post_type( $product_id ) ) { $product_id = wp_get_post_parent_id( $product_id ); }
    $raw = $product_id ? get_post_meta( $product_id, '_adb_tasting', true ) : array();
    return adb_sanitize_tasting( $raw );
}

/** Preserve disputed original values in the CMS, but never publish them as verified facts. */
function adb_product_field_value( $product_id, $key ) {
    $review = get_post_meta( $product_id, '_adb_unverified_fields', true );
    if ( is_array( $review ) && in_array( $key, $review, true ) ) { return ''; }
    $value = get_post_meta( $product_id, $key, true );
    return is_scalar( $value ) ? trim( (string) $value ) : '';
}

/** Extends the one existing product metabox; no second technical data store. */
function adb_tasting_editor( $post ) {
    $data = adb_tasting_data( $post->ID );
    echo '<hr><h3>' . esc_html__( 'Nel calice · profilo di degustazione', 'amicidibacco' ) . '</h3><p>' . esc_html__( 'Usa soltanto caratteristiche documentate. I valori da 1 a 5 esprimono intensità, non qualità. Lascia non valutato quando manca un riscontro; i campi vuoti non compaiono sul sito.', 'amicidibacco' ) . '</p>';
    echo '<input type="hidden" name="adb_tasting_present" value="1">';
    echo '<p><label for="adb-aromas"><strong>' . esc_html__( 'Note aromatiche · una per riga, massimo otto', 'amicidibacco' ) . '</strong></label><textarea class="widefat" id="adb-aromas" name="adb_tasting[aromas]" rows="3">' . esc_textarea( implode( "\n", $data['aromas'] ) ) . '</textarea></p>';
    echo '<p><label for="adb-finish"><strong>' . esc_html__( 'Il finale', 'amicidibacco' ) . '</strong></label><textarea class="widefat" id="adb-finish" name="adb_tasting[finish]" rows="2">' . esc_textarea( $data['finish'] ) . '</textarea></p>';
    $kind = get_post_meta( $post->ID, 'tipo_di_prodotto', true );
    if ( 'VINO SINGOLO' === $kind ) {
        echo '<fieldset><legend><strong>' . esc_html__( 'Struttura del vino', 'amicidibacco' ) . '</strong></legend>';
        foreach ( adb_tasting_axes() as $key => $axis ) {
            echo '<p><label for="adb-score-' . esc_attr( $key ) . '">' . esc_html( $axis['label'] . ' · ' . $axis['low'] . ' → ' . $axis['high'] ) . '</label> <select id="adb-score-' . esc_attr( $key ) . '" name="adb_tasting[scores][' . esc_attr( $key ) . ']"><option value="">' . esc_html__( 'Non valutato', 'amicidibacco' ) . '</option>';
            for ( $i = 1; $i <= 5; $i++ ) { echo '<option value="' . esc_attr( $i ) . '"' . selected( $data['scores'][ $key ], $i, false ) . '>' . esc_html( $i . '/5' ) . '</option>'; }
            echo '</select><br><label for="adb-evidence-' . esc_attr( $key ) . '">' . esc_html__( 'Riscontro nella fonte', 'amicidibacco' ) . '</label><input class="widefat" id="adb-evidence-' . esc_attr( $key ) . '" name="adb_tasting[score_evidence][' . esc_attr( $key ) . ']" value="' . esc_attr( $data['score_evidence'][ $key ] ) . '"></p>';
        }
        echo '</fieldset>';
    }
    echo '<p><label for="adb-vintage">' . esc_html__( 'Annata di riferimento · vuoto se descrizione generale', 'amicidibacco' ) . '</label><input class="widefat" id="adb-vintage" name="adb_tasting[reference_vintage]" value="' . esc_attr( $data['reference_vintage'] ) . '"></p>';
    echo '<p><label for="adb-sources">' . esc_html__( 'Fonti ufficiali · un indirizzo completo per riga', 'amicidibacco' ) . '</label><textarea class="widefat" id="adb-sources" name="adb_tasting[source_urls]" rows="3">' . esc_textarea( implode( "\n", array_column( $data['sources'], 'url' ) ) ) . '</textarea><span class="description">' . esc_html__( 'Per le scale serve la scheda specifica del vino con le note al palato, verificata per l’annata: la homepage della cantina non basta.', 'amicidibacco' ) . '</span></p>';
    echo '<p><label for="adb-source-state">' . esc_html__( 'Verifica editoriale', 'amicidibacco' ) . '</label> <select id="adb-source-state" name="adb_tasting[verification]">';
    foreach ( array( 'needs_source' => __( 'Da verificare con la cantina', 'amicidibacco' ), 'legacy_reviewed' => __( 'Contenuti originali revisionati', 'amicidibacco' ), 'official_product' => __( 'Scheda ufficiale del prodotto verificata', 'amicidibacco' ) ) as $key => $label ) { echo '<option value="' . esc_attr( $key ) . '"' . selected( $data['verification'], $key, false ) . '>' . esc_html( $label ) . '</option>'; }
    echo '</select></p>';
    echo '<p><label for="adb-editorial-notes">' . esc_html__( 'Note interne della revisione · non visibili sul sito', 'amicidibacco' ) . '</label><textarea class="widefat" id="adb-editorial-notes" name="adb_tasting[editorial_notes]" rows="2">' . esc_textarea( get_post_meta( $post->ID, '_adb_editorial_notes', true ) ) . '</textarea></p>';
    $review = (array) get_post_meta( $post->ID, '_adb_unverified_fields', true );
    echo '<fieldset><legend><strong>' . esc_html__( 'Dati tecnici da verificare · nascosti sul sito', 'amicidibacco' ) . '</strong></legend>';
    foreach ( adb_product_fields() as $key => $label ) {
        if ( 'tipo_di_prodotto' === $key ) { continue; }
        if ( '' === (string) get_post_meta( $post->ID, $key, true ) && ! in_array( $key, $review, true ) ) { continue; }
        echo '<label style="display:inline-block;margin:4px 16px 4px 0"><input type="checkbox" name="adb_tasting[review_fields][]" value="' . esc_attr( $key ) . '"' . checked( in_array( $key, $review, true ), true, false ) . '>' . esc_html( $label ) . '</label>';
    }
    echo '</fieldset>';
    $original = get_post_meta( $post->ID, '_adb_original_editorial', true );
    if ( is_array( $original ) ) {
        echo '<details style="margin-top:20px"><summary><strong>' . esc_html__( 'Testi originali conservati · sola lettura', 'amicidibacco' ) . '</strong></summary><p>' . esc_html__( 'Archivio precedente alla revisione. I contenuti pubblicati si modificano nell’editor e nella descrizione breve di WooCommerce.', 'amicidibacco' ) . '</p>';
        foreach ( array( 'content' => __( 'Descrizione originale', 'amicidibacco' ), 'excerpt' => __( 'Introduzione originale', 'amicidibacco' ) ) as $key => $label ) {
            if ( ! is_string( $original[ $key ] ?? null ) || '' === $original[ $key ] ) { continue; }
            echo '<p><label for="adb-original-' . esc_attr( $key ) . '">' . esc_html( $label ) . '</label><textarea readonly class="widefat" rows="5" id="adb-original-' . esc_attr( $key ) . '">' . esc_textarea( $original[ $key ] ) . '</textarea></p>';
        }
        $labels = adb_product_fields();
        foreach ( (array) ( $original['technical'] ?? array() ) as $key => $value ) {
            if ( ! is_scalar( $value ) ) { continue; }
            echo '<p><strong>' . esc_html( $labels[ $key ] ?? $key ) . '</strong><br>' . esc_html( $value ) . '</p>';
        }
        echo '</details>';
    }
}

function adb_save_tasting( $post_id, $post ) {
    if ( 'product' !== $post->post_type || wp_is_post_revision( $post_id ) || wp_is_post_autosave( $post_id ) || ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) || ! current_user_can( 'edit_post', $post_id ) ) { return; }
    if ( empty( $_POST['adb_tasting_present'] ) || ! is_string( $_POST['adb_product_nonce'] ?? null ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['adb_product_nonce'] ) ), 'adb_save_product' ) || ! is_array( $_POST['adb_tasting'] ?? null ) ) { return; }
    $input = wp_unslash( $_POST['adb_tasting'] );
    $old = adb_tasting_data( $post_id );
    $input['sources'] = array();
    foreach ( array_slice( preg_split( '/[\r\n]+/', is_string( $input['source_urls'] ?? null ) ? $input['source_urls'] : '' ), 0, 12 ) as $url ) {
        $url = trim( $url );
        if ( ! $url ) { continue; }
        $found = array_values( array_filter( $old['sources'], static function ( $source ) use ( $url ) { return $source['url'] === $url; } ) );
        $input['sources'][] = $found ? $found[0] : array( 'url' => $url, 'scope' => 'official_product' === ( $input['verification'] ?? '' ) ? 'product' : 'producer', 'fields' => 'official_product' === ( $input['verification'] ?? '' ) ? array( 'al_palato' ) : array() );
    }
    if ( 'VINO SINGOLO' !== get_post_meta( $post_id, 'tipo_di_prodotto', true ) ) { $input['scores'] = array(); }
    update_post_meta( $post_id, '_adb_tasting', adb_sanitize_tasting( $input ) );
    $review = array_values( array_intersect( array_keys( adb_product_fields() ), array_filter( (array) ( $input['review_fields'] ?? array() ), 'is_string' ) ) );
    update_post_meta( $post_id, '_adb_unverified_fields', $review );
    if ( is_string( $input['editorial_notes'] ?? null ) ) { update_post_meta( $post_id, '_adb_editorial_notes', mb_substr( sanitize_textarea_field( $input['editorial_notes'] ), 0, 3000 ) ); }
}
add_action( 'adb_product_editor_after_fields', 'adb_tasting_editor' );
// The existing editorial dispatcher saves the product type on save_post at 20.
add_action( 'save_post', 'adb_save_tasting', 30, 2 );

add_filter( 'manage_edit-product_columns', static function ( $columns ) {
    $columns['adb_profile'] = __( 'Revisione scheda', 'amicidibacco' );
    return $columns;
} );
add_action( 'manage_product_posts_custom_column', static function ( $column, $post_id ) {
    if ( 'adb_profile' !== $column ) { return; }
    $raw = get_post_meta( $post_id, '_adb_tasting', true );
    $status = is_array( $raw ) ? ( $raw['verification'] ?? 'needs_source' ) : 'needs_source';
    $labels = array( 'needs_source' => __( 'Da verificare', 'amicidibacco' ), 'legacy_reviewed' => __( 'Originale revisionato', 'amicidibacco' ), 'official_product' => __( 'Fonte prodotto verificata', 'amicidibacco' ) );
    echo esc_html( $labels[ $status ] ?? $labels['needs_source'] );
    $review = get_post_meta( $post_id, '_adb_unverified_fields', true );
    if ( is_array( $review ) && $review ) { echo '<br><small>' . esc_html( sprintf( __( 'Dati sospesi: %d', 'amicidibacco' ), count( $review ) ) ) . '</small>'; }
}, 10, 2 );

add_action( 'restrict_manage_posts', static function ( $post_type ) {
    if ( 'product' !== $post_type ) { return; }
    $current = isset( $_GET['adb_editorial'] ) && is_string( $_GET['adb_editorial'] ) ? sanitize_key( wp_unslash( $_GET['adb_editorial'] ) ) : ''; // Read-only admin filter.
    echo '<label class="screen-reader-text" for="adb-editorial-filter">' . esc_html__( 'Revisione scheda', 'amicidibacco' ) . '</label><select name="adb_editorial" id="adb-editorial-filter"><option value="">' . esc_html__( 'Tutte le revisioni', 'amicidibacco' ) . '</option>';
    foreach ( array( 'reviewed' => __( 'Schede revisionate', 'amicidibacco' ), 'pending' => __( 'Schede non revisionate', 'amicidibacco' ), 'disputed' => __( 'Con dati da verificare', 'amicidibacco' ) ) as $key => $label ) { echo '<option value="' . esc_attr( $key ) . '"' . selected( $current, $key, false ) . '>' . esc_html( $label ) . '</option>'; }
    echo '</select>';
} );
add_action( 'pre_get_posts', static function ( $query ) {
    if ( ! is_admin() || ! $query->is_main_query() || 'product' !== $query->get( 'post_type' ) || ! is_string( $_GET['adb_editorial'] ?? null ) ) { return; }
    $choice = sanitize_key( wp_unslash( $_GET['adb_editorial'] ) );
    $clause = null;
    if ( 'reviewed' === $choice || 'pending' === $choice ) { $clause = array( 'key' => '_adb_editorial_revision', 'compare' => 'reviewed' === $choice ? 'EXISTS' : 'NOT EXISTS' ); }
    if ( 'disputed' === $choice ) { $clause = array( 'key' => '_adb_unverified_fields', 'value' => 'a:0:{}', 'compare' => '!=' ); }
    if ( $clause ) {
        $existing = $query->get( 'meta_query' );
        $query->set( 'meta_query', $existing ? array( 'relation' => 'AND', $existing, $clause ) : array( $clause ) );
    }
}, 30 );
