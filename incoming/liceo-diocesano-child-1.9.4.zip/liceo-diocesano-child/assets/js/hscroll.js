( function () {
    var wrap = document.querySelector( '.ld-hscroll' );
    var stick = wrap && wrap.querySelector( '.ld-hscroll__stick' );
    var track = wrap && wrap.querySelector( '.ld-hscroll__track' );
    if ( ! track ) { return; }

    var mqStill = window.matchMedia( '(prefers-reduced-motion: reduce)' );
    var mqSmall = window.matchMedia( '(max-width: 900px)' );
    var dist = 0;
    var pinTop = 0;
    var ticking = false;

    // Con movimento ridotto o su schermi piccoli la riga resta scorrevole a mano (swipe o trackpad).
    function enabled() { return ! mqStill.matches && ! mqSmall.matches; }

    function measure() {
        if ( ! enabled() ) {
            wrap.classList.remove( 'is-pinned' );
            wrap.style.height = '';
            stick.style.top = '';
            track.style.transform = '';
            return;
        }
        wrap.classList.add( 'is-pinned' );
        dist = Math.max( 0, track.scrollWidth - stick.clientWidth );
        // La riga resta ferma al centro dello schermo per la sola distanza da percorrere: nessuno spazio vuoto sopra o sotto.
        stick.style.top = '0px';
        wrap.style.height = '';
        var h = stick.offsetHeight;
        pinTop = Math.max( 0, ( window.innerHeight - h ) / 2 );
        stick.style.top = pinTop + 'px';
        wrap.style.height = ( h + dist ) + 'px';
        update();
    }

    // Lo scroll verticale della pagina fa scorrere la riga in orizzontale, finché l'ultima card è visibile.
    function update() {
        ticking = false;
        if ( ! wrap.classList.contains( 'is-pinned' ) ) { return; }
        var p = dist > 0 ? Math.min( 1, Math.max( 0, ( pinTop - wrap.getBoundingClientRect().top ) / dist ) ) : 0;
        track.style.transform = 'translate3d(' + ( -p * dist ) + 'px,0,0)';
    }

    function onScroll() {
        if ( ! ticking ) { ticking = true; window.requestAnimationFrame( update ); }
    }

    window.addEventListener( 'scroll', onScroll, { passive: true } );
    window.addEventListener( 'resize', measure );
    window.addEventListener( 'load', measure );
    if ( mqStill.addEventListener ) { mqStill.addEventListener( 'change', measure ); mqSmall.addEventListener( 'change', measure ); }
    measure();
} )();
