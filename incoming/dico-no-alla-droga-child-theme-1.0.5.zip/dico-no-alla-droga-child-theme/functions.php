<?php
/**
 * Dico NO alla Droga – child theme di ticinoweb-ai-theme.
 *
 * Il design vive qui; i dati (testi, contatti, opuscoli, forme) stanno nel database:
 * contatti e social in ticinoWEB CMS, gli opuscoli come contenuti «Opuscoli»,
 * il resto nelle pagine. Vedi README.md per l'inventario parent / child.
 *
 * @package dico-no-alla-droga-child-theme
 */

if (!defined('ABSPATH')) {
    exit;
}

define('DND_THEME_VERSION', '1.0.5');

require_once get_stylesheet_directory() . '/inc/opuscoli.php';
require_once get_stylesheet_directory() . '/inc/richiesta.php';
require_once get_stylesheet_directory() . '/inc/structured-data.php';

/**
 * Il sito è solo in italiano: nessun selettore di lingua, lang sempre it-CH/it.
 */
add_action('after_setup_theme', function () {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_image_size('dnd-cover', 480, 640, false);
});

/**
 * Stili e script. Il font (Manrope, variabile) è quello già self-hosted dal parent:
 * nessuna richiesta a Google Fonts oltre a quella che il parent stampa da sé.
 */
add_action('wp_enqueue_scripts', function () {
    // Il parent registra il proprio style.css contro get_stylesheet_uri(), cioè questo stesso file: una sola copia.
    wp_dequeue_style('ticinoweb-ai-style');
    wp_dequeue_style('poppins-font');

    $font = get_template_directory_uri() . '/assets/fonts/manrope/manrope-latin-wght-normal.woff2';
    $font_ext = get_template_directory_uri() . '/assets/fonts/manrope/manrope-latin-ext-wght-normal.woff2';
    $css = "@font-face{font-family:'Manrope';font-style:normal;font-weight:200 800;font-display:swap;src:url('{$font}') format('woff2');unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+2000-206F,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD}"
         . "@font-face{font-family:'Manrope';font-style:normal;font-weight:200 800;font-display:swap;src:url('{$font_ext}') format('woff2');unicode-range:U+0100-02BA,U+02BD-02C5,U+02C7-02CC,U+02CE-02D7,U+02DD-02FF,U+0304,U+0308,U+0329,U+1D00-1DBF,U+1E00-1E9F,U+1EF2-1EFF,U+2020,U+20A0-20AB,U+20AD-20C0,U+2113,U+2C60-2C7F,U+A720-A7FF}";

    $path = get_stylesheet_directory() . '/style.css';
    wp_enqueue_style('dnd-style', get_stylesheet_uri(), array(), file_exists($path) ? filemtime($path) : DND_THEME_VERSION);
    wp_add_inline_style('dnd-style', $css);

    $js = get_stylesheet_directory() . '/assets/js/site.js';
    wp_enqueue_script('dnd-site', get_stylesheet_directory_uri() . '/assets/js/site.js', array(), file_exists($js) ? filemtime($js) : DND_THEME_VERSION, true);
}, 30);

/**
 * Il carattere Manrope si precarica solo sulla home (LCP).
 */
add_action('wp_head', function () {
    if (is_front_page()) {
        printf(
            '<link rel="preload" href="%s" as="font" type="font/woff2" crossorigin>' . "\n",
            esc_url(get_template_directory_uri() . '/assets/fonts/manrope/manrope-latin-wght-normal.woff2')
        );
    }
}, 1);

/**
 * Classe sul body per il CSS: pagina con fascia scura in testa (tutte tranne la home).
 */
add_filter('body_class', function ($classes) {
    $classes[] = 'dnd';
    if (!is_front_page()) {
        $classes[] = 'dnd-inner';
    }
    return $classes;
});

/**
 * Il parent mostra i commenti sugli articoli: qui non servono (sito di pagine).
 */
add_filter('comments_open', '__return_false', 20);

/**
 * Pulsante «Richiedi materiale» dell'header e del footer: porta alla sezione #richiedi della home
 * del sito corrente (mai un dominio scritto a mano).
 */
function dnd_cta_url() {
    return home_url('/#richiedi');
}
