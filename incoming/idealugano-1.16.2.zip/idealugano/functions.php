<?php
/**
 * Idealugano child theme functions
 *
 * @package Idealugano
 * @version 1.13.2
 */

/* ─────────────────────────────────────────────
   1. THEME SETUP
   ───────────────────────────────────────────── */
add_action('after_setup_theme', 'idealugano_setup');
function idealugano_setup()
{
    add_theme_support('menus');
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('html5', array('search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script'));

    register_nav_menus(array(
        'primary' => __('Menu Principale', 'idealugano'),
        'footer'  => __('Menu Footer', 'idealugano'),
    ));
}


/* ─────────────────────────────────────────────
   2. ENQUEUE STYLES & SCRIPTS
   ───────────────────────────────────────────── */
add_action('wp_enqueue_scripts', 'idealugano_enqueue_styles', 20);
function idealugano_enqueue_styles()
{
    $ver = wp_get_theme()->get('Version');

    // Google Fonts — Cormorant + Manrope
    wp_enqueue_style(
        'idealugano-fonts',
        'https://fonts.googleapis.com/css2?family=Cormorant:ital,wght@0,300;0,400;0,500;0,600;0,700;1,400;1,500&family=Manrope:wght@300;400;500;600;700&display=swap',
        array(),
        null
    );

    // Main child theme stylesheet
    wp_enqueue_style(
        'idealugano-style',
        get_stylesheet_directory_uri() . '/assets/css/idealugano.css',
        array('ticinoweb-ai-style', 'idealugano-fonts'),
        $ver
    );

    // Responsive layer — loaded last to preserve the approved desktop design.
    wp_enqueue_style(
        'idealugano-responsive',
        get_stylesheet_directory_uri() . '/assets/css/responsive.css',
        array('idealugano-style'),
        $ver
    );
}

add_action('wp_enqueue_scripts', 'idealugano_enqueue_scripts', 20);
function idealugano_enqueue_scripts()
{
    $ver = wp_get_theme()->get('Version');

    wp_enqueue_script(
        'idealugano-gsap',
        get_stylesheet_directory_uri() . '/assets/vendor/gsap.min.js',
        array(),
        '3.15.0',
        true
    );
    wp_enqueue_script(
        'idealugano-scroll-trigger',
        get_stylesheet_directory_uri() . '/assets/vendor/ScrollTrigger.min.js',
        array('idealugano-gsap'),
        '3.15.0',
        true
    );
    wp_enqueue_script(
        'idealugano-scroll-smoother',
        get_stylesheet_directory_uri() . '/assets/vendor/ScrollSmoother.min.js',
        array('idealugano-scroll-trigger'),
        '3.15.0',
        true
    );
    // I moduli si registrano in window.IdeaMotion (config.js) e index.js li avvia:
    // quelli legati a sezioni presenti solo in alcune pagine vengono caricati
    // solo li'. Ogni modulo esce comunque da solo se il suo selettore manca.
    $is_home     = is_front_page();
    $is_prodotti = is_page_template('page-prodotti.php') || is_page('prodotti');
    $is_galleria = is_page_template('page-galleria.php') || is_page('galleria');
    $is_landing  = is_page_template('page-landing.php');
    $motion_modules = array(
        'config'              => true,
        'smoother'            => true,
        'hero'                => $is_home,
        'kinetic-text'        => $is_home,
        'image-reveal'        => true,
        'services'            => true,
        'curtains-horizontal' => $is_home || $is_prodotti,
        'products-loop'       => $is_home,
        'objects-collage'     => $is_home || $is_prodotti,
        'before-after-motion' => $is_home || $is_galleria || $is_landing,
        'footer'              => true,
        'interactions'        => true,
        'index'               => true,
    );
    $motion_dependency = 'idealugano-scroll-smoother';
    foreach ($motion_modules as $motion_module => $enabled) {
        if (!$enabled) {
            continue;
        }
        $handle = 'idealugano-motion-' . $motion_module;
        wp_enqueue_script(
            $handle,
            get_stylesheet_directory_uri() . '/assets/js/motion/' . $motion_module . '.js',
            array($motion_dependency),
            $ver,
            true
        );
        $motion_dependency = $handle;
    }
    wp_localize_script('idealugano-motion-config', 'idealuganoMotion', array(
        'curtainIntro' => true,
        'pageTransitions' => true,
        'customCursor' => false,
        'desktopBreakpoint' => 1025,
        'easeSoft' => 'power3.out',
        'easeCinematic' => 'power3.inOut',
        'scrubSoft' => 1.1,
        'parallax' => 8,
        'textTravel' => 22,
    ));

    // Image fade-in safety net (images are eager-loaded; late arrivals fade in)
    wp_enqueue_script(
        'idealugano-img-fade',
        get_stylesheet_directory_uri() . '/assets/js/img-fade.js',
        array(),
        $ver,
        true
    );

    // Header scroll effect
    wp_enqueue_script(
        'idealugano-header-scroll',
        get_stylesheet_directory_uri() . '/assets/js/header-scroll.js',
        array(),
        $ver,
        true
    );

    // Mobile menu
    wp_enqueue_script(
        'idealugano-mobile-menu',
        get_stylesheet_directory_uri() . '/assets/js/mobile-menu.js',
        array(),
        $ver,
        true
    );

    // Scroll reveal animations
    wp_enqueue_script(
        'idealugano-scroll-reveal',
        get_stylesheet_directory_uri() . '/assets/js/scroll-reveal.js',
        array(),
        $ver,
        true
    );

    wp_enqueue_script(
        'idealugano-responsive',
        get_stylesheet_directory_uri() . '/assets/js/responsive.js',
        array('idealugano-motion-index'),
        $ver,
        true
    );

    // Curtain intro (only on front page)
    if (is_front_page()) {
        wp_enqueue_script(
            'idealugano-curtain-intro',
            get_stylesheet_directory_uri() . '/assets/js/curtain-intro.js',
            array(),
            $ver,
            true
        );

    }

    // Gallery page scripts
    if (is_page_template('page-galleria.php') || is_page('galleria')) {
        wp_enqueue_script(
            'idealugano-gallery',
            get_stylesheet_directory_uri() . '/assets/js/gallery.js',
            array(),
            $ver,
            true
        );
    }

    // Before/After slider (front page + gallery + landing rifacimento)
    if (is_front_page() || is_page_template('page-galleria.php') || is_page('galleria') || is_page_template('page-landing.php')) {
        wp_enqueue_script(
            'idealugano-before-after',
            get_stylesheet_directory_uri() . '/assets/js/before-after.js',
            array(),
            $ver,
            true
        );
    }

    // Contact form validation (home, contatti e landing servizi)
    if (is_front_page() || is_page_template('page-contatti.php') || is_page('contatti') || is_page_template('page-landing.php')) {
        wp_enqueue_script(
            'idealugano-contact-form',
            get_stylesheet_directory_uri() . '/assets/js/contact-form.js',
            array(),
            $ver,
            true
        );
    }
}


/**
 * Tutti gli script del child (e GSAP) in `defer`: erano gia' nel footer, ma
 * senza defer bloccavano comunque il parsing a fine documento. L'ordine di
 * esecuzione tra script deferiti e' garantito, quindi la catena GSAP →
 * moduli motion → index resta valida.
 */
add_filter('script_loader_tag', 'idealugano_defer_theme_scripts', 10, 3);
function idealugano_defer_theme_scripts($tag, $handle, $src)
{
    if (is_admin() || strpos($handle, 'idealugano-') !== 0) {
        return $tag;
    }
    if (strpos($tag, ' defer') !== false || strpos($tag, ' async') !== false || strpos($tag, 'type="module"') !== false) {
        return $tag;
    }
    return str_replace(' src=', ' defer src=', $tag);
}

/**
 * Il parent carica Google Fonts "Poppins" come dipendenza del suo style.css,
 * ma il child non lo usa da nessuna parte: si svuota l'URL cosi' il tag non
 * viene stampato senza rompere la catena di dipendenze del parent.
 */
add_filter('style_loader_src', 'idealugano_drop_unused_parent_font', 10, 2);
function idealugano_drop_unused_parent_font($src, $handle)
{
    return $handle === 'poppins-font' ? '' : $src;
}

/**
 * 404 reali. Il parent reindirizza ogni 404 alla home con un 301 (soft 404
 * per Google, link rotti invisibili in Search Console): qui si rimuove quel
 * comportamento e si serve 404.php del child.
 */
add_action('after_setup_theme', 'idealugano_disable_parent_404_redirect');
function idealugano_disable_parent_404_redirect()
{
    remove_action('template_redirect', 'ticinoweb_redirect_404_to_home');
}

/**
 * Lingua coerente con og:locale (it_CH) e con il pubblico svizzero.
 */
add_filter('language_attributes', 'idealugano_language_attributes');
function idealugano_language_attributes($output)
{
    return preg_replace('/lang="it(-[A-Za-z]+)?"/', 'lang="it-CH"', $output);
}


/* ─────────────────────────────────────────────
   3. SEO & STRUCTURED DATA
   ───────────────────────────────────────────── */
require_once get_stylesheet_directory() . '/inc/landings.php';
require_once get_stylesheet_directory() . '/inc/faq.php';
require_once get_stylesheet_directory() . '/inc/form-photos.php';
require_once get_stylesheet_directory() . '/inc/navigation.php';
require_once get_stylesheet_directory() . '/inc/seo-schema.php';
require_once get_stylesheet_directory() . '/inc/content-seed.php';
require_once get_stylesheet_directory() . '/inc/suppliers.php';


/* ─────────────────────────────────────────────
   3b. ADMIN IMAGE MANAGER
   ───────────────────────────────────────────── */
require_once get_stylesheet_directory() . '/inc/admin-images.php';
require_once get_stylesheet_directory() . '/inc/admin-brands.php';
require_once get_stylesheet_directory() . '/inc/occasioni.php';
require_once get_stylesheet_directory() . '/inc/editor-role.php';

/* Lo strumento "Idea Sincro" (inc/migration-dashboard.php) è stato rimosso:
   esportava e importava database e media via zip, ma il pacchetto non stava nei
   limiti di upload del server e arrivava troncato, dichiarando comunque l'esito
   positivo. Al suo posto: il tema porta con sé le proprie immagini
   (inc/bundled-images.php) e in tools/ ci sono gli script di trasferimento e di
   riparazione degli URL. Il file è recuperabile dalla storia git se serve. */


/* ─────────────────────────────────────────────
   4. HELPER FUNCTIONS
   ───────────────────────────────────────────── */

/**
 * Returns the child theme image directory URI
 */
function idealugano_get_image_uri($filename)
{
    return get_stylesheet_directory_uri() . '/assets/images/' . $filename;
}

/**
 * Returns an image from media library by filename, with child-theme fallback
 */
function idealugano_get_image_by_filename($filename, $fallback_url = '')
{
    $filename = trim($filename);
    if (empty($filename)) {
        return $fallback_url;
    }

    // Una query per nome file e per richiesta (la stessa immagine viene chiesta
    // da piu' template/sezioni); l'ID trovato alimenta il registro srcset.
    static $cache = array();
    $title = pathinfo($filename, PATHINFO_FILENAME);
    if (!array_key_exists($title, $cache)) {
        global $wpdb;
        $cache[$title] = $wpdb->get_row($wpdb->prepare(
            "SELECT ID, guid FROM {$wpdb->posts} WHERE post_type = 'attachment' AND post_title = %s LIMIT 1",
            $title
        ));
    }
    $attachment = $cache[$title];

    if ($attachment && !empty($attachment->guid)) {
        if (function_exists('idealugano_remember_image_attachment')) {
            idealugano_remember_image_attachment($attachment->guid, (int) $attachment->ID);
        }
        return $attachment->guid;
    }

    // Try child theme assets
    $child_path = get_stylesheet_directory() . '/assets/images/' . $filename;
    if (file_exists($child_path) && !is_dir($child_path)) {
        return get_stylesheet_directory_uri() . '/assets/images/' . $filename;
    }

    return $fallback_url;
}

/**
 * Render a placeholder image box when no real image is available.
 * Pure CSS elegant placeholder with gradient + icon.
 */
function idealugano_placeholder_image($aspect = '4/3', $label = '', $class = '')
{
    $id = 'ph-' . wp_unique_id();
    ?>
    <div class="idea-placeholder <?php echo esc_attr($class); ?>" id="<?php echo esc_attr($id); ?>"
         style="aspect-ratio: <?php echo esc_attr($aspect); ?>;"
         role="img" aria-label="<?php echo esc_attr($label ?: 'Immagine in arrivo'); ?>">
        <div class="idea-placeholder__inner">
            <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1" stroke-linecap="round" stroke-linejoin="round">
                <rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="m21 15-5-5L5 21"/>
            </svg>
            <?php if ($label): ?>
                <span class="idea-placeholder__label"><?php echo esc_html($label); ?></span>
            <?php endif; ?>
        </div>
    </div>
    <?php
}


/* ─────────────────────────────────────────────
   5. CENTRALISED SITE DATA
   ───────────────────────────────────────────── */

/**
 * Automatically seeds default CMS options if empty, ensuring the backend fields
 * are pre-populated with actual content for editing.
 */
add_action('after_setup_theme', 'idealugano_seed_cms_defaults');
function idealugano_seed_cms_defaults()
{
    if (get_option('idealugano_cms_defaults_seeded') === '1') {
        return;
    }

    if (empty(get_option('ticinoweb_chi_siamo_title'))) {
        update_option('ticinoweb_chi_siamo_title', 'Artigianato su misura nel cuore del Ticino');
    }

    if (empty(get_option('ticinoweb_chi_siamo_text'))) {
        $text = "Da oltre vent'anni, Idea Lugano è il punto di riferimento per chi cerca soluzioni d'arredo su misura a Lugano. Tappezzeria, tende, cuscini, copriletti, divani e complementi prendono forma dall'ascolto delle esigenze del cliente e dalla passione per il dettaglio.\n\nLa nostra filosofia si fonda su tre principi: materiali di qualità, lavorazione artigianale e consulenza personalizzata. Ogni progetto nasce da un dialogo attento e diventa una soluzione unica, pensata per valorizzare lo stile della casa e la personalità di chi la vive.";
        update_option('ticinoweb_chi_siamo_text', $text);
    }

    if (empty(get_option('ticinoweb_contact_phone'))) {
        update_option('ticinoweb_contact_phone', '+41 78 803 92 01');
    }

    if (empty(get_option('ticinoweb_contact_phone_landline'))) {
        update_option('ticinoweb_contact_phone_landline', '+41 91 923 45 60');
    }

    if (empty(get_option('ticinoweb_contact_email'))) {
        update_option('ticinoweb_contact_email', 'info@idealugano.ch');
    }

    if (empty(get_option('ticinoweb_contact_address'))) {
        update_option('ticinoweb_contact_address', 'Via alla Gerra 9, Stabile Vallone, Piano Superiore, 6930 Bedano');
    }

    if (empty(get_option('ticinoweb_contact_opening_hours_note'))) {
        update_option('ticinoweb_contact_opening_hours_note', 'Su appuntamento');
    }

    if (empty(get_option('ticinoweb_contact_instagram'))) {
        update_option('ticinoweb_contact_instagram', 'https://www.instagram.com/idealugano/');
    }

    update_option('idealugano_cms_defaults_seeded', '1');
}

/**
 * Returns all site data for Idea Lugano.
 * Connects dynamically to ticinoWEB CMS options with dependable fallbacks.
 */
function idealugano_get_site_data()
{
    static $data = null;
    if ($data !== null) {
        return $data;
    }

    $cms_contact = function_exists('ticinoweb_get_contact_info') ? ticinoweb_get_contact_info() : array();

    $opt_phone    = get_option('ticinoweb_contact_phone');
    $phone        = !empty($opt_phone) ? $opt_phone : (!empty($cms_contact['phone']) ? $cms_contact['phone'] : '+41 78 803 92 01');

    $opt_landline = get_option('ticinoweb_contact_phone_landline');
    $phone_landline = ($opt_landline !== false && $opt_landline !== '') ? $opt_landline : (!empty($cms_contact['phone_landline']) ? $cms_contact['phone_landline'] : '+41 91 923 45 60');

    $opt_mobile   = get_option('ticinoweb_contact_phone_mobile');
    $phone_mobile = !empty($opt_mobile) ? $opt_mobile : (!empty($cms_contact['phone_mobile']) ? $cms_contact['phone_mobile'] : '');

    $opt_email    = get_option('ticinoweb_contact_email');
    $email        = !empty($opt_email) ? $opt_email : (!empty($cms_contact['email']) ? $cms_contact['email'] : 'info@idealugano.ch');

    $opt_address  = get_option('ticinoweb_contact_address');
    $address_raw  = !empty($opt_address) ? $opt_address : (!empty($cms_contact['address']) ? $cms_contact['address'] : 'Via alla Gerra 9, Stabile Vallone, Piano Superiore, 6930 Bedano');

    $opt_insta    = get_option('ticinoweb_contact_instagram');
    $instagram    = !empty($opt_insta) ? $opt_insta : (!empty($cms_contact['instagram']) ? $cms_contact['instagram'] : 'https://www.instagram.com/idealugano/');

    $opt_fb       = get_option('ticinoweb_contact_facebook');
    $facebook     = !empty($opt_fb) ? $opt_fb : (!empty($cms_contact['facebook']) ? $cms_contact['facebook'] : '');

    $opt_linkedin = get_option('ticinoweb_contact_linkedin');
    $linkedin     = !empty($opt_linkedin) ? $opt_linkedin : (!empty($cms_contact['linkedin']) ? $cms_contact['linkedin'] : '');

    $opt_hours    = get_option('ticinoweb_contact_opening_hours_note');
    $hours_note   = ($opt_hours !== false && $opt_hours !== '') ? $opt_hours : (!empty($cms_contact['opening_hours_note']) ? $cms_contact['opening_hours_note'] : 'Su appuntamento');

    // Chi siamo dynamic from ticinoWEB CMS
    $cms_about_title = get_option('ticinoweb_chi_siamo_title');
    $about_title     = !empty($cms_about_title) ? $cms_about_title : 'Artigianato su misura nel cuore del Ticino';

    $cms_about_text  = get_option('ticinoweb_chi_siamo_text');
    $default_text_1  = 'Da oltre vent\'anni, Idea Lugano è il punto di riferimento per chi cerca soluzioni d\'arredo su misura a Lugano. Tappezzeria, tende, cuscini, copriletti, divani e complementi prendono forma dall\'ascolto delle esigenze del cliente e dalla passione per il dettaglio.';
    $default_text_2  = 'La nostra filosofia si fonda su tre principi: materiali di qualità, lavorazione artigianale e consulenza personalizzata. Ogni progetto nasce da un dialogo attento e diventa una soluzione unica, pensata per valorizzare lo stile della casa e la personalità di chi la vive.';

    if (!empty($cms_about_text)) {
        $raw_paras = preg_split('/\r\n\r\n|\n\n/', trim($cms_about_text));
        $paragraphs = array_values(array_filter(array_map('trim', $raw_paras)));
        $text_1 = isset($paragraphs[0]) ? $paragraphs[0] : $cms_about_text;
        $text_2 = isset($paragraphs[1]) ? $paragraphs[1] : '';
    } else {
        $text_1 = $default_text_1;
        $text_2 = $default_text_2;
        $paragraphs = array($default_text_1, $default_text_2);
    }

    $about_image_cms = get_option('ticinoweb_chi_siamo_image');

    $city = '6930 Bedano';
    $country = 'Svizzera';
    if (preg_match('/(\d{4}\s+[A-Za-zÀ-ÿ\s]+)$/u', trim($address_raw), $matches)) {
        $city = trim($matches[1]);
    }

    $data = array(
        'brand' => 'IDeA Lugano',
        'tagline' => 'Tende su misura, divani, letti, tessuti d\'arredo e rifacimento imbottiti a Lugano',

        'contact' => array(
            'contact_person'    => 'Monica Spirig Papini',
            'address'           => $address_raw,
            'address_2'         => '',
            'city'              => $city,
            'country'           => $country,
            'formatted_address' => $address_raw,
            'phone'             => $phone,
            'phone_landline'    => $phone_landline,
            'phone_mobile'      => $phone_mobile,
            'email'             => $email,
            'instagram'         => $instagram,
            'facebook'          => $facebook,
            'linkedin'          => $linkedin,
            'maps_url'          => 'https://maps.app.goo.gl/X1EE7Ba3UHm9cBoU6',
        ),

        'hours'      => array(),
        'hours_note' => $hours_note,

        'hero' => array(
            'title'         => 'Diamo nuova vita ai tuoi arredi',
            'subtitle'      => 'Tende su misura, divani e letti, rifacimento di imbottiti e tessuti d\'arredo: tutto per la tua casa, con cura artigianale, a Lugano.',
            'cta_primary'   => 'Richiedi una consulenza',
            'cta_secondary' => 'Scopri i servizi',
        ),

        'about' => array(
            'title'        => $about_title,
            'text_1'       => $text_1,
            'text_2'       => $text_2,
            'paragraphs'   => $paragraphs,
            'preview_text' => $text_1,
            'image'        => $about_image_cms,
        ),

        // Servizi in ordine di priorita' commerciale (indicazioni del cliente,
        // set 2026). I primi cinque hanno una landing dedicata (inc/landings.php);
        // l'ultimo raccoglie i complementi e resta un'ancora nella pagina Servizi.
        'services' => array(
            array(
                'title' => 'Tende su Misura',
                'slug'  => 'tende-su-misura',
                'desc'  => 'Tendaggi confezionati in atelier con tessuti dei migliori editori, binari e motorizzazioni Silent Gliss, MHZ, Kadeco, Casa Valentina, Scaglioni e Interstil. Sopralluogo, progetto e posa in tutta la Svizzera e all\'estero.',
                'image' => 'services/tende-su-misura.jpg',
                'slot'  => 'srv_tende',
                'url'   => idealugano_landing_url('tende-su-misura'),
            ),
            array(
                'title' => 'Divani, Letti e Imbottiti su Misura',
                'slug'  => 'divani-letti-su-misura',
                'desc'  => 'Divani, poltrone, letti e testiere progettati per il tuo spazio e rivestiti con il tessuto che scegli tu. Rivenditori Tréca Paris per materassi e sistemi di riposo.',
                'image' => 'services/divani-letti.jpg',
                'slot'  => 'srv_divani',
                'url'   => idealugano_landing_url('divani-letti-su-misura'),
            ),
            array(
                'title' => 'Rifacimento Divani, Poltrone e Sedie',
                'slug'  => 'rifacimento-divani-poltrone',
                'desc'  => 'Rimettiamo a nuovo i tuoi mobili imbottiti: nuove imbottiture, molleggi e rivestimenti sartoriali, rispettando lo stile originale o creando una nuova identità.',
                'image' => 'services/rifacimento-mobili.jpg',
                'slot'  => 'srv_imbottiti',
                'url'   => idealugano_landing_url('rifacimento-divani-poltrone'),
            ),
            array(
                'title' => 'Tessuti per l\'Arredamento',
                'slug'  => 'tessuti-arredamento',
                'desc'  => 'Collezioni sempre aggiornate dei maggiori distributori tessili, tra cui Dedar e Decortex Firenze. Anche al metro, per chi confeziona altrove o da sé.',
                'image' => 'services/tessuti.jpg',
                'slot'  => 'srv_tessuti',
                'url'   => idealugano_landing_url('tessuti-arredamento'),
            ),
            array(
                'title' => 'Arredamento d\'Interni',
                'slug'  => 'arredamento-interni',
                'desc'  => 'Tutto ciò che serve ad arredare casa o appartamento con un solo interlocutore: tende, imbottiti, tappeti, moquette, carte da parati, illuminazione e complementi.',
                'image' => 'services/interior-design.jpg',
                'slot'  => 'srv_interior',
                'url'   => idealugano_landing_url('arredamento-interni'),
            ),
            array(
                'title' => 'Cuscini, Copriletti e Complementi',
                'slug'  => 'complementi',
                'desc'  => 'Cuscini decorativi e copriletti coordinati, paralumi rifatti o creati su misura e una selezione di oggettistica su richiesta, per completare ogni ambiente.',
                'image' => 'services/cuscini-personalizzati.jpg',
                'slot'  => 'srv_cuscini',
                'url'   => '',
            ),
        ),

        'curtain_types' => array(
            array('title' => 'Tende moderne',       'image' => 'images/tende-moderne.jpg',       'slot' => 'curtain_moderne'),
            array('title' => 'Tende tradizionali',   'image' => 'images/tende-tradizionali.jpg', 'slot' => 'curtain_classiche'),
            array('title' => 'Tende a rullo',         'image' => 'images/tende-rullo.jpg',       'slot' => 'curtain_rullo'),
            array('title' => 'Tende a lamelle',       'image' => 'images/tende-lamelle.jpg',     'slot' => 'curtain_lamelle'),
        ),

        'products' => array(
            array('title' => 'Tessuti d\'arredamento', 'image' => 'products/product-01.jpg', 'slot' => 'prod_tessuti',      'url' => idealugano_landing_url('tessuti-arredamento')),
            array('title' => 'Divani e letti',         'image' => 'products/product-03.jpg', 'slot' => 'prod_letti',        'url' => idealugano_landing_url('divani-letti-su-misura')),
            array('title' => 'Imbottiti rinnovati',    'image' => 'products/product-02.jpg', 'slot' => 'prod_imbottiti',    'url' => idealugano_landing_url('rifacimento-divani-poltrone')),
            array('title' => 'Cuscini e copriletti',   'image' => 'products/product-02.jpg', 'slot' => 'srv_cuscini',       'url' => home_url('/servizi/#servizio-complementi')),
            array('title' => 'Paralumi',               'image' => 'products/product-04.jpg', 'slot' => 'prod_paralumi',     'url' => home_url('/servizi/#servizio-complementi')),
            array('title' => 'Arredamento d\'interni', 'image' => 'products/product-06.jpg', 'slot' => 'prod_interior',     'url' => idealugano_landing_url('arredamento-interni')),
        ),

        'brands' => function_exists('idealugano_get_brands') ? idealugano_get_brands() : array(),

        'testimonials' => array(
            array(
                'text' => 'Il lavoro di restauro ha mantenuto lo stile originale aggiungendo comfort e modernità.',
                'author' => 'Cliente soddisfatto',
            ),
            array(
                'text' => 'Attenzione ai dettagli e materiali di qualità. Il risultato ha superato le aspettative.',
                'author' => 'Maria R.',
            ),
            array(
                'text' => 'Servizio professionale e consulenza preziosa nella scelta di tessuti e colori.',
                'author' => 'Paolo G.',
            ),
        ),

        'before_after' => idealugano_get_frontend_before_after_projects(),

        'method_steps' => array(
            array('num' => '01', 'title' => 'Ascolto',                   'desc' => 'Analizziamo le esigenze, lo stile e le aspettative del cliente.'),
            array('num' => '02', 'title' => 'Consulenza',                'desc' => 'Proponiamo soluzioni personalizzate e studiamo insieme il progetto.'),
            array('num' => '03', 'title' => 'Scelta materiali',          'desc' => 'Selezioniamo tessuti, finiture e accessori di qualità.'),
            array('num' => '04', 'title' => 'Lavorazione artigianale',   'desc' => 'Realizziamo il progetto con cura e precisione artigianale.'),
            array('num' => '05', 'title' => 'Installazione e consegna', 'desc' => 'Consegniamo e installiamo il risultato finito, pronto da vivere.'),
        ),

        'seo' => array(
            'home_title' => 'Idea Lugano | Tende su Misura, Divani e Tessuti d\'Arredo a Lugano',
            'home_desc'  => 'Atelier a Lugano: tende su misura, divani e letti su misura, rifacimento di divani e poltrone, tessuti d\'arredamento anche al metro e arredamento d\'interni completo. Sopralluogo gratuito, interventi in tutta la Svizzera e all\'estero.',
        ),
    );

    return $data;
}


/* ─────────────────────────────────────────────
   6. DEQUEUE PARENT SCRIPTS NOT NEEDED
   ───────────────────────────────────────────── */
add_action('wp_enqueue_scripts', 'idealugano_dequeue_parent_scripts', 100);
function idealugano_dequeue_parent_scripts()
{
    // Keep parent styles for CMS functionality, but override visuals
}


/* ─────────────────────────────────────────────
   7. PRECONNECT
   ───────────────────────────────────────────── */
add_action('wp_head', 'idealugano_preconnect', 1);
function idealugano_preconnect()
{
    echo '<link rel="preconnect" href="https://fonts.googleapis.com">' . "\n";
    echo '<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>' . "\n";
}


/* ─────────────────────────────────────────────
   8. AUTO-CREATE PAGES ON THEME ACTIVATION
   ───────────────────────────────────────────── */
add_action('after_switch_theme', 'idealugano_create_pages');
function idealugano_create_pages()
{
    // Pages to create: slug => [title, template file, menu order]
    $pages = array(
        'home' => array(
            'title'    => 'Home',
            'template' => '',  // Uses front-page.php automatically
            'order'    => 1,
        ),
        'chi-siamo' => array(
            'title'    => 'Chi Siamo',
            'template' => 'page-chi-siamo.php',
            'order'    => 2,
        ),
        'servizi' => array(
            'title'    => 'Servizi',
            'template' => 'page-servizi.php',
            'order'    => 3,
        ),
        'prodotti' => array(
            'title'    => 'Prodotti',
            'template' => 'page-prodotti.php',
            'order'    => 4,
        ),
        'galleria' => array(
            'title'    => 'Galleria',
            'template' => 'page-galleria.php',
            'order'    => 5,
        ),
        'contatti' => array(
            'title'    => 'Contatti',
            'template' => 'page-contatti.php',
            'order'    => 6,
        ),
    );

    $created_pages = array();

    foreach ($pages as $slug => $data) {
        // Check if page with this slug already exists
        $existing = get_page_by_path($slug);
        if ($existing) {
            // Update template if needed
            if (!empty($data['template'])) {
                update_post_meta($existing->ID, '_wp_page_template', $data['template']);
            }
            $created_pages[$slug] = $existing->ID;
            continue;
        }

        // Create the page
        $page_id = wp_insert_post(array(
            'post_title'   => $data['title'],
            'post_name'    => $slug,
            'post_status'  => 'publish',
            'post_type'    => 'page',
            'post_content' => '',
            'menu_order'   => $data['order'],
        ));

        if ($page_id && !is_wp_error($page_id)) {
            // Assign page template
            if (!empty($data['template'])) {
                update_post_meta($page_id, '_wp_page_template', $data['template']);
            }
            $created_pages[$slug] = $page_id;
        }
    }

    // Set static front page
    if (!empty($created_pages['home'])) {
        update_option('show_on_front', 'page');
        update_option('page_on_front', $created_pages['home']);
    }

    // Create the primary navigation menu
    idealugano_create_menu($created_pages);
}


/**
 * Creates the primary navigation menu with all pages.
 */
function idealugano_create_menu($page_ids)
{
    $menu_name = 'Menu Principale Idealugano';
    $menu_exists = wp_get_nav_menu_object($menu_name);

    if ($menu_exists) {
        // Menu already exists, just ensure it's assigned
        $locations = get_theme_mod('nav_menu_locations');
        $locations['primary'] = $menu_exists->term_id;
        set_theme_mod('nav_menu_locations', $locations);
        return;
    }

    // Create the menu
    $menu_id = wp_create_nav_menu($menu_name);
    if (is_wp_error($menu_id)) {
        return;
    }

    // Menu items in order
    $menu_items = array(
        'home'      => 'Home',
        'chi-siamo' => 'Chi Siamo',
        'servizi'   => 'Servizi',
        'prodotti'  => 'Prodotti',
        'galleria'  => 'Galleria',
        'contatti'  => 'Contatti',
    );

    $position = 1;
    foreach ($menu_items as $slug => $label) {
        if (!empty($page_ids[$slug])) {
            wp_update_nav_menu_item($menu_id, 0, array(
                'menu-item-title'     => $label,
                'menu-item-object'    => 'page',
                'menu-item-object-id' => $page_ids[$slug],
                'menu-item-type'      => 'post_type',
                'menu-item-status'    => 'publish',
                'menu-item-position'  => $position,
            ));
        }
        $position++;
    }

    // Assign menu to primary location
    $locations = get_theme_mod('nav_menu_locations');
    if (!is_array($locations)) {
        $locations = array();
    }
    $locations['primary'] = $menu_id;
    set_theme_mod('nav_menu_locations', $locations);
}

// Escludi cartelle pesanti dall'esportazione di All-in-One WP Migration
add_filter( 'ai1wm_exclude_content_from_export', function ( $exclude_filters ) {
    $excludes = array(
        'updraft',
        'upgrade-temp-backup',
        'logs',
        'litespeed',
        'star-cloudprnt',
        'wordpress-docker.log',
        'crawler.log'
    );
    foreach ( $excludes as $exclude ) {
        $exclude_filters[] = $exclude;
        $exclude_filters[] = WP_CONTENT_DIR . '/' . $exclude;
    }
    return $exclude_filters;
} );

add_filter( 'ai1wm_exclude_plugins_from_export', function ( $exclude_filters ) {
    // Escludi file di log del plugin stampante
    $exclude_filters[] = 'star-cloudprnt/raw_post_debug.log';
    $exclude_filters[] = WP_CONTENT_DIR . '/plugins/star-cloudprnt/raw_post_debug.log';
    
    // Trova ed escludi tutti i file ZIP presenti nella cartella plugins (ad es. backup)
    $plugins_dir = WP_CONTENT_DIR . '/plugins';
    if ( is_dir( $plugins_dir ) ) {
        $zip_files = glob( $plugins_dir . '/*.zip' );
        if ( is_array( $zip_files ) ) {
            foreach ( $zip_files as $zip_file ) {
                $exclude_filters[] = $zip_file;
                $exclude_filters[] = basename( $zip_file );
            }
        }
    }
    
    return $exclude_filters;
} );

