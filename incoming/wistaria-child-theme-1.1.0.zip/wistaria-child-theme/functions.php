<?php
/**
 * Wistaria child theme bootstrap.
 *
 * @package WistariaChildTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * The parent's legacy stylesheet hides Elementor content site-wide. Keep the
 * parent PHP features while the imported pages still depend on Elementor.
 */
function wistaria_enqueue_styles() {
	wp_dequeue_style( 'ticinoweb-ai-style' );
	wp_deregister_style( 'ticinoweb-ai-style' );

	$child = wp_get_theme();

	wp_enqueue_style(
		'wistaria-child-style',
		get_stylesheet_uri(),
		array(),
		$child->get( 'Version' )
	);
}
add_action( 'wp_enqueue_scripts', 'wistaria_enqueue_styles', 20 );

/**
 * Serve a short site guide at the current subsite's /llms.txt URL.
 */
function wistaria_serve_llms_txt( $wp ) {
	if ( 'llms.txt' !== $wp->request ) {
		return;
	}

	$name        = sanitize_text_field( get_bloginfo( 'name' ) );
	$description = sanitize_text_field( get_bloginfo( 'description' ) );
	$address     = sanitize_text_field( (string) get_option( 'ticinoweb_contact_address', '' ) );
	$phone       = sanitize_text_field( (string) get_option( 'ticinoweb_contact_phone', '' ) );
	$email       = sanitize_email( (string) get_option( 'ticinoweb_contact_email', '' ) );
	$home        = home_url( '/' );
	$lines       = array(
		'# ' . $name,
		'',
	);
	if ( $description ) {
		$lines[] = '> ' . rtrim( $description, '. ' ) . '.';
		$lines[] = '';
	}
	$lines[] = '## ' . __( 'Informazioni', 'wistaria-child-theme' );
	$lines[] = '';
	$lines[] = '- [' . __( 'Chi siamo', 'wistaria-child-theme' ) . '](' . $home . '#chisiamo)';
	$lines[] = '- [' . __( 'Servizi', 'wistaria-child-theme' ) . '](' . $home . '#servizi)';
	$lines[] = '- [' . __( 'Lavori', 'wistaria-child-theme' ) . '](' . $home . '#lavori)';
	$lines[] = '- [' . __( 'Contatto', 'wistaria-child-theme' ) . '](' . $home . '#contatto)';

	if ( $address || $phone || $email ) {
		$lines[] = '';
		$lines[] = '## ' . __( 'Recapiti', 'wistaria-child-theme' );
		$lines[] = '';
		if ( $address ) {
			$lines[] = '- ' . __( 'Indirizzo', 'wistaria-child-theme' ) . ': ' . $address;
		}
		if ( $phone ) {
			$lines[] = '- ' . __( 'Telefono', 'wistaria-child-theme' ) . ': ' . $phone;
		}
		if ( $email ) {
			$lines[] = '- ' . __( 'Email', 'wistaria-child-theme' ) . ': ' . $email;
		}
	}

	nocache_headers();
	status_header( 200 );
	header( 'Content-Type: text/plain; charset=' . get_bloginfo( 'charset' ) );
	echo implode( "\n", $lines ) . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Sanitized plain-text response.
	exit;
}
add_action( 'parse_request', 'wistaria_serve_llms_txt' );
