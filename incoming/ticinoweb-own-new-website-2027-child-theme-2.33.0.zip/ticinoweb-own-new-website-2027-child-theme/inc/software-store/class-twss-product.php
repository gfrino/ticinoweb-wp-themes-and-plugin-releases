<?php
if (!defined('ABSPATH')) {
    exit;
}

/** Crea e aggiorna il prodotto WooCommerce di un plugin. */
class Twss_Product {

    /** Prodotto già collegato allo slug: meta, poi SKU. */
    public static function find($slug) {
        $ids = get_posts(array('post_type' => 'product', 'post_status' => 'any', 'numberposts' => 1, 'fields' => 'ids',
            'meta_key' => '_twss_slug', 'meta_value' => $slug)); // phpcs:ignore WordPress.DB.SlowDBQuery
        if ($ids) {
            return (int) $ids[0];
        }
        $id = wc_get_product_id_by_sku($slug);
        return $id ? (int) $id : 0;
    }

    /** Collega a mano un prodotto esistente (testi e prezzo restano quelli scritti a mano). */
    public static function link($slug, $product_id) {
        $p = wc_get_product($product_id);
        if (!$p) {
            return false;
        }
        update_post_meta($product_id, '_twss_slug', $slug);
        update_post_meta($product_id, '_twss_manage_text', 'no');
        return true;
    }

    private static function category_id() {
        $slug = Twss_Settings::get('category');
        $term = get_term_by('slug', $slug, 'product_cat');
        if ($term) {
            return (int) $term->term_id;
        }
        $new = wp_insert_term(ucwords(str_replace('-', ' ', $slug)), 'product_cat', array('slug' => $slug));
        return is_wp_error($new) ? 0 : (int) $new['term_id'];
    }

    /** Cartella dei file venduti, fuori dalla portata del web (come woocommerce_uploads). */
    private static function store_dir($slug) {
        $up = wp_upload_dir();
        $base = trailingslashit($up['basedir']) . 'woocommerce_uploads/';
        $dir = $base . 'tw-software-store/' . $slug . '/';
        wp_mkdir_p($dir);
        foreach (array($base, $base . 'tw-software-store/') as $d) {
            if (!file_exists($d . 'index.html')) {
                @file_put_contents($d . 'index.html', ''); // phpcs:ignore WordPress.PHP.NoSilencedErrors
            }
        }
        if (!file_exists($base . '.htaccess')) {
            @file_put_contents($base . '.htaccess', "deny from all\n"); // phpcs:ignore WordPress.PHP.NoSilencedErrors
        }
        return array($dir, trailingslashit($up['baseurl']) . 'woocommerce_uploads/tw-software-store/' . $slug . '/');
    }

    private static function sideload($bytes, $filename, $post_id) {
        if (!function_exists('media_handle_sideload')) {
            require_once ABSPATH . 'wp-admin/includes/image.php';
            require_once ABSPATH . 'wp-admin/includes/file.php';
            require_once ABSPATH . 'wp-admin/includes/media.php';
        }
        $tmp = wp_tempnam($filename);
        file_put_contents($tmp, $bytes);
        $id = media_handle_sideload(array('name' => $filename, 'tmp_name' => $tmp), $post_id);
        if (is_wp_error($id)) {
            @unlink($tmp); // phpcs:ignore WordPress.PHP.NoSilencedErrors
            return 0;
        }
        return (int) $id;
    }

    /**
     * @param array $rel      release (Twss_Github::latest_by_slug)
     * @param array $pkg      Twss_Package::inspect
     * @param array $details  details.json decodificato (può essere vuoto)
     * @return array{action:string,id:int,notes:string[]}
     */
    public static function upsert($slug, array $rel, array $pkg, array $details, $zip_file, $dry) {
        $h = $pkg['headers'];
        $id = self::find($slug);
        $create = !$id;
        $notes = array();
        $product = $create ? new WC_Product_Simple() : wc_get_product($id);
        if (!$product) {
            return array('action' => 'error', 'id' => 0, 'notes' => array('prodotto non leggibile'));
        }
        $manage_text = $create || 'no' !== get_post_meta($id, '_twss_manage_text', true);
        $notes[] = $create ? 'nuovo prodotto' : 'aggiornamento';
        if ($dry) {
            return array('action' => $create ? 'create' : 'update', 'id' => (int) $id, 'notes' => $notes);
        }

        if ($create) {
            $product->set_status('publish' === Twss_Settings::get('new_status') ? 'publish' : 'draft');
            $product->set_sku($slug);
            $product->set_regular_price((string) Twss_Settings::get('price'));
            $product->set_sold_individually(true);
            $product->set_tax_status('taxable');
            $cat = self::category_id();
            if ($cat) {
                $product->set_category_ids(array($cat));
            }
        }
        // Licenza perpetua: nessuna scadenza e nessun limite di download.
        $product->set_virtual(true);
        $product->set_downloadable(true);
        $product->set_download_expiry(-1);
        $product->set_download_limit(-1);

        if ($manage_text) {
            $name = $h['name'];
            $short = $h['description'];
            $long = !empty($details['description']) ? Twss_Markdown::to_html($details['description']) : wpautop(esc_html($short));
            $product->set_name($name);
            $product->set_short_description(wp_kses_post($short));
            $product->set_description($long);
        }

        // File scaricabile: sempre l'ultima versione, la precedente viene tolta.
        list($dir, $url) = self::store_dir($slug);
        $file = $slug . '-' . $rel['version'] . '.zip';
        if (!copy($zip_file, $dir . $file)) {
            return array('action' => 'error', 'id' => (int) $id, 'notes' => array('impossibile salvare lo zip'));
        }
        foreach (glob($dir . '*.zip') ?: array() as $old) {
            if (basename($old) !== $file) {
                @unlink($old); // phpcs:ignore WordPress.PHP.NoSilencedErrors
            }
        }
        $dl = new WC_Product_Download();
        $dl->set_id(md5($slug));
        $dl->set_name($h['name'] . ' ' . $rel['version']);
        $dl->set_file($url . $file);
        $product->set_downloads(array($dl));

        $product->save();
        $id = $product->get_id();

        update_post_meta($id, '_twss_slug', $slug);
        if ($create) {
            update_post_meta($id, '_twss_manage_text', 'yes');
            update_post_meta($id, '_tw_seo_title', wp_strip_all_tags($h['name']) . ' | Plugin WordPress | ticinoWEB');
            update_post_meta($id, '_tw_seo_description', wp_strip_all_tags(mb_substr($h['description'], 0, 155)));
        }
        update_post_meta($id, '_twss_version', $rel['version']);
        update_post_meta($id, '_twss_released', $rel['published']);
        update_post_meta($id, '_twss_changelog', Twss_Markdown::to_html($rel['notes']));
        update_post_meta($id, '_twss_compat', array_filter(array(
            'WordPress' => $h['requires_wp'], 'PHP' => $h['requires_php'], 'WooCommerce' => $h['wc_requires'],
        )));

        // Immagini: solo se cambiate e mai sopra a quelle scelte a mano.
        if (!empty($pkg['icon'])) {
            $hash = md5($pkg['icon']);
            if (get_post_meta($id, '_twss_icon_hash', true) !== $hash) {
                $ours = (int) get_post_meta($id, '_twss_icon_id', true);
                if (!$product->get_image_id() || ($ours && (int) $product->get_image_id() === $ours)) {
                    $att = self::sideload($pkg['icon'], $slug . '-icon.png', $id);
                    if ($att) {
                        $product->set_image_id($att);
                        $product->save();
                        update_post_meta($id, '_twss_icon_id', $att);
                    }
                }
                update_post_meta($id, '_twss_icon_hash', $hash);
            }
        }
        $shots = (isset($details['screenshots']) && is_array($details['screenshots'])) ? $details['screenshots'] : array();
        $shots_hash = md5(wp_json_encode($shots));
        if ($shots && get_post_meta($id, '_twss_shots_hash', true) !== $shots_hash && !$product->get_gallery_image_ids()) {
            $ids = array();
            foreach (array_slice($shots, 0, 6) as $s) {
                $src = isset($s['src']) ? basename($s['src']) : '';
                $bytes = $src ? Twss_Github::raw('details/' . $slug . '/' . $src) : null;
                if ($bytes && ($att = self::sideload($bytes, $slug . '-' . $src, $id))) {
                    $ids[] = $att;
                }
            }
            if ($ids) {
                $product->set_gallery_image_ids($ids);
                $product->save();
            }
            update_post_meta($id, '_twss_shots_hash', $shots_hash);
        }

        self::refresh_extras($id, $slug, isset($rel['history']) ? $rel['history'] : array(), $details);

        return array('action' => $create ? 'create' : 'update', 'id' => (int) $id, 'notes' => $notes);
    }

    /**
     * Banner e storico delle versioni: non toccano testi, prezzo né immagini scelte a mano.
     * Lo storico si fonde con quello salvato (una lettura parziale delle release non lo accorcia).
     */
    public static function refresh_extras($id, $slug, array $history, array $details) {
        if ($history) {
            $saved = get_post_meta($id, '_twss_history', true);
            $by_ver = array();
            foreach (is_array($saved) ? $saved : array() as $row) {
                $by_ver[$row['version']] = $row;
            }
            foreach ($history as $row) {
                $by_ver[$row['version']] = array('version' => $row['version'], 'date' => $row['date'], 'html' => Twss_Markdown::to_html($row['notes']));
            }
            uksort($by_ver, function ($a, $b) { return version_compare($b, $a); });
            update_post_meta($id, '_twss_history', array_slice(array_values($by_ver), 0, 40));
        }
        $file = !empty($details['banner_2x']) ? $details['banner_2x'] : (!empty($details['banner']) ? $details['banner'] : '');
        if ($file) {
            $bytes = Twss_Github::raw('details/' . $slug . '/' . basename($file));
            if ($bytes && get_post_meta($id, '_twss_banner_hash', true) !== md5($bytes)) {
                $att = self::sideload($bytes, $slug . '-banner.png', $id);
                if ($att) {
                    $old = (int) get_post_meta($id, '_twss_banner_id', true);
                    update_post_meta($id, '_twss_banner_id', $att);
                    update_post_meta($id, '_twss_banner_hash', md5($bytes));
                    if ($old) {
                        wp_delete_attachment($old, true);
                    }
                }
            }
        }
    }
}
