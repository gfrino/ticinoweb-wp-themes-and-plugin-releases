<?php
/**
 * The core plugin class.
 *
 * @package WPNews
 */

/**
 * The core plugin class.
 *
 * This is used to define internationalization, admin-specific hooks, and
 * public-facing site hooks.
 */
class WPNews_Plugin
{

	/**
	 * The loader that's responsible for maintaining and registering all hooks.
	 *
	 * @var WPNews_Loader
	 */
	protected $loader;

	/**
	 * The unique identifier of this plugin.
	 *
	 * @var string
	 */
	protected $plugin_name;

	/**
	 * The current version of the plugin.
	 *
	 * @var string
	 */
	protected $version;

	/**
	 * Define the core functionality of the plugin.
	 */
	public function __construct()
	{
		$this->version = WPNEWS_VERSION;
		$this->plugin_name = 'wp-news';

		$this->load_dependencies();
		$this->set_locale();
		$this->define_admin_hooks();
		$this->define_public_hooks();
		$this->define_cron_hooks();
	}

	/**
	 * Load the required dependencies for this plugin.
	 */
	private function load_dependencies()
	{
		require_once WPNEWS_PLUGIN_DIR . 'includes/class-loader.php';
		require_once WPNEWS_PLUGIN_DIR . 'includes/class-i18n.php';
		require_once WPNEWS_PLUGIN_DIR . 'includes/class-security.php';
		require_once WPNEWS_PLUGIN_DIR . 'includes/class-tracker.php';
		require_once WPNEWS_PLUGIN_DIR . 'includes/class-sendgrid.php';
		require_once WPNEWS_PLUGIN_DIR . 'includes/class-ses.php';
		require_once WPNEWS_PLUGIN_DIR . 'includes/class-mailer.php';
		require_once WPNEWS_PLUGIN_DIR . 'includes/class-list-manager.php';
		require_once WPNEWS_PLUGIN_DIR . 'includes/class-blacklist-manager.php';
		require_once WPNEWS_PLUGIN_DIR . 'includes/class-campaign-manager.php';
		require_once WPNEWS_PLUGIN_DIR . 'includes/class-scheduler.php';
		require_once WPNEWS_PLUGIN_DIR . 'includes/class-woocommerce.php';
		require_once WPNEWS_PLUGIN_DIR . 'includes/class-antispam.php';
		require_once WPNEWS_PLUGIN_DIR . 'includes/api/class-rest-api.php'; // REST API
		require_once WPNEWS_PLUGIN_DIR . 'includes/class-sns-webhook.php'; // SNS Webhook
		require_once WPNEWS_PLUGIN_DIR . 'includes/class-sendgrid-webhook.php'; // SendGrid Webhook
		require_once WPNEWS_PLUGIN_DIR . 'admin/class-admin.php';
		require_once WPNEWS_PLUGIN_DIR . 'public/class-public.php';

		$this->loader = new WPNews_Loader();
	}

	/**
	 * Define the locale for this plugin for internationalization.
	 */
	private function set_locale()
	{
		$plugin_i18n = new WPNews_I18n();
		$this->loader->add_action('plugins_loaded', $plugin_i18n, 'load_plugin_textdomain');
	}

	public function register_rest_api()
	{
		$api = new WPNews_REST_API();
		$api->register_routes();
		WPNews_SNS_Webhook::register_routes();
		WPNews_SendGrid_Webhook::register_routes();
	}

	/**
	 * Disable LiteSpeed REST API cache for all wp-news endpoints.
	 *
	 * LiteSpeed caches REST responses for up to 7 days (cache-ttl_rest).
	 * This causes stale data to be returned after saves (e.g. campaign name
	 * not updating after a reload). We prevent caching on every wp-news request.
	 *
	 * @param mixed           $result  Response to replace the requested version.
	 * @param WP_REST_Server  $server  Server instance.
	 * @param WP_REST_Request $request Request used to generate the response.
	 * @return mixed Unchanged $result.
	 */
	public function disable_rest_cache_for_wpnews( $result, $server, $request ) {
		$route = $request->get_route();
		if ( strpos( $route, '/wp-news/' ) !== false ) {
			do_action( 'litespeed_control_set_nocache', 'wp-news REST endpoints must not be cached' );
			if ( ! headers_sent() ) {
				header( 'X-LiteSpeed-Cache-Control: no-cache' );
				header( 'Cache-Control: no-store, no-cache, must-revalidate, max-age=0, private' );
			}
		}
		return $result;
	}

	/**
	 * Register all of the hooks related to the admin area functionality.
	 */
	private function define_admin_hooks()
	{
		$plugin_admin = new WPNews_Admin($this->get_plugin_name(), $this->get_version());

		// Init REST API
		$this->loader->add_action('rest_api_init', $this, 'register_rest_api');

		// Disable LiteSpeed cache for wp-news REST endpoints (prevents stale data)
		$this->loader->add_filter('rest_pre_dispatch', $this, 'disable_rest_cache_for_wpnews', 10, 3);

		$this->loader->add_action('admin_enqueue_scripts', $plugin_admin, 'enqueue_styles');
		$this->loader->add_action('admin_enqueue_scripts', $plugin_admin, 'enqueue_scripts');
		$this->loader->add_action('admin_menu', $plugin_admin, 'add_plugin_admin_menu');
		$this->loader->add_action('admin_init', $plugin_admin, 'register_settings');
		$this->loader->add_action('admin_notices', $plugin_admin, 'activation_notice');
		$this->loader->add_action('admin_notices', $plugin_admin, 'timezone_notice');

		// Admin Post handlers for actions (avoids Headers Already Sent issues)
		$this->loader->add_action('admin_post_wpnews_duplicate_campaign', $plugin_admin, 'handle_duplicate_campaign');
		$this->loader->add_action('admin_post_wpnews_delete_campaign', $plugin_admin, 'handle_delete_campaign');
		$this->loader->add_action('admin_post_wpnews_bulk_delete_campaigns', $plugin_admin, 'handle_bulk_delete_campaigns');
		$this->loader->add_action('admin_post_wpnews_list_action', $plugin_admin, 'handle_list_action');

		// DB Version Check for Upgrades
		$this->loader->add_action('admin_init', $this, 'check_version');

		// AJAX handlers
	}

	/**
	 * Register all of the hooks related to the public-facing functionality.
	 */
	private function define_public_hooks()
	{
		$plugin_public = new WPNews_Public($this->get_plugin_name(), $this->get_version());

		$this->loader->add_action('wp_enqueue_scripts', $plugin_public, 'enqueue_styles');
		$this->loader->add_action('wp_enqueue_scripts', $plugin_public, 'enqueue_scripts');

		// Handle subscription forms
		$this->loader->add_action('wp_ajax_wpnews_subscribe', $plugin_public, 'handle_subscription');
		$this->loader->add_action('wp_ajax_nopriv_wpnews_subscribe', $plugin_public, 'handle_subscription');

		// Anti-spam proof-of-work challenge (uncached, works on cached pages)
		add_action('wp_ajax_wpnews_challenge', array('WPNews_Antispam', 'ajax_challenge'));
		add_action('wp_ajax_nopriv_wpnews_challenge', array('WPNews_Antispam', 'ajax_challenge'));

		// Handle standalone Unsubscribe Page
		$this->loader->add_action('init', $plugin_public, 'handle_unsubscribe_page');

		// Handle standalone subscription confirmation page
		$this->loader->add_action('init', $plugin_public, 'handle_confirm_page');

		// WooCommerce checkout newsletter opt-in (no-op without WooCommerce).
		add_action('plugins_loaded', array('WPNews_WooCommerce', 'init'), 20);

		// Register structural shortcodes for Email Builder
		add_shortcode('wpnews_latest_posts', array('WPNews_Campaign_Manager', 'render_latest_posts_shortcode'));

		// Register public signup form shortcode
		add_shortcode('wpnews_subscribe_form', array($plugin_public, 'render_subscribe_form_shortcode'));

		// Note: the `data:` protocol for inline images is allowed ONLY inside
		// WPNews_Campaign_Manager::sanitize_email_html(), not site-wide.
	}

	/**
	 * Register cron hooks for scheduled tasks.
	 */
	private function define_cron_hooks()
	{
		$scheduler = new WPNews_Scheduler();

		// Schedule campaign sending
		$this->loader->add_action('wpnews_send_scheduled_campaigns', $scheduler, 'process_scheduled_campaigns');

		// Async single campaign send (fired by REST/scheduler via wp_schedule_single_event)
		$this->loader->add_action('wpnews_send_campaign_async', $this, 'run_async_send', 10, 2);

		// Add custom cron intervals
		$this->loader->add_filter('cron_schedules', $this, 'add_cron_intervals');
		// Note: the 'wpnews_send_scheduled_campaigns' event is scheduled on plugin
		// activation (WPNews_Activator::activate_site) and cleared on deactivation.
	}

	/**
	 * Add custom cron intervals.
	 */
	public function add_cron_intervals($schedules)
	{
		$schedules['every_minute'] = array(
			'interval' => 60,
			'display' => __('Every Minute', 'wp-news'),
		);
		return $schedules;
	}

	/**
	 * Run the loader to execute all of the hooks with WordPress.
	 */
	public function run()
	{
		$this->loader->run();
	}

	/**
	 * The name of the plugin used to uniquely identify it.
	 *
	 * @return string
	 */
	public function get_plugin_name()
	{
		return $this->plugin_name;
	}

	/**
	 * The reference to the class that orchestrates the hooks.
	 *
	 * @return WPNews_Loader
	 */
	public function get_loader()
	{
		return $this->loader;
	}

	/**
	 * Retrieve the version number of the plugin.
	 *
	 * @return string
	 */
	public function get_version()
	{
		return $this->version;
	}

	/**
	 * Check if DB upgrade is needed to add new schema columns (per site).
	 */
	public function check_version()
	{
		if (get_option('wpnews_db_version') !== $this->version) {
			require_once WPNEWS_PLUGIN_DIR . 'includes/class-activator.php';
			WPNews_Activator::activate_site();
			update_option('wpnews_db_version', $this->version);
		}
	}

	/**
	 * Run async campaign send (triggered by wpnews_send_campaign_async cron event).
	 *
	 * @param int      $campaign_id Campaign ID to send.
	 * @param int|null $child_id    Legacy second argument (recurring snapshot ID); auto-detected when null.
	 */
	public function run_async_send($campaign_id, $child_id = null)
	{
		// Give the batch enough room; the engine itself stops after min(200s, max_execution_time - 30s)
		if (function_exists('set_time_limit')) {
			@set_time_limit(300);
		}

		WPNews_Campaign_Manager::send_campaign((int) $campaign_id, $child_id ? (int) $child_id : null);
	}
}
