<?php
/**
 * The public-facing functionality of the plugin.
 *
 * @package WPNews
 */

/**
 * The public-facing functionality of the plugin.
 */
class WPNews_Public {

	/**
	 * The ID of this plugin.
	 *
	 * @var string
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @var string
	 */
	private $version;

	/**
	 * Whether front-end assets have been registered in this request.
	 *
	 * @var bool
	 */
	private $assets_registered = false;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @param string $plugin_name The name of the plugin.
	 * @param string $version     The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {
		$this->plugin_name = $plugin_name;
		$this->version     = $version;
	}

	/* ------------------------------------------------------------------
	 * Assets: registered on wp_enqueue_scripts, ENQUEUED only when the
	 * [wpnews_subscribe_form] shortcode is actually rendered.
	 * ------------------------------------------------------------------ */

	/**
	 * Register (do not enqueue) the front-end script. The form ships without
	 * any stylesheet: it inherits the theme and is styled by the site's own
	 * CSS through its classes (see render_subscribe_form_shortcode()).
	 */
	private function register_assets() {
		if ( $this->assets_registered ) {
			return;
		}
		$this->assets_registered = true;

		wp_register_script(
			$this->plugin_name,
			WPNEWS_PLUGIN_URL . 'public/js/public.js',
			array(),
			$this->version,
			true
		);

		wp_localize_script(
			$this->plugin_name,
			'wpNewsPublic',
			array(
				'ajaxUrl' => admin_url( 'admin-ajax.php' ),
				'nonce'   => wp_create_nonce( 'wpnews_public_nonce' ),
				'pow'     => WPNews_Antispam::pow_enabled(),
				'strings' => array(
					'subscribing'    => __( 'Subscribing...', 'wp-news' ),
					'subscribeError' => __( 'Error subscribing. Please try again.', 'wp-news' ),
					'invalidEmail'   => __( 'Please enter a valid email address.', 'wp-news' ),
					'consentRequired' => __( 'Please accept the privacy conditions to subscribe.', 'wp-news' ),
					'verifying'       => __( 'Security check…', 'wp-news' ),
				),
			)
		);
	}

	/**
	 * Hooked to wp_enqueue_scripts (kept for the loader): registers assets.
	 */
	public function enqueue_styles() {
		$this->register_assets();
	}

	/**
	 * Hooked to wp_enqueue_scripts: only registers the script.
	 */
	public function enqueue_scripts() {
		$this->register_assets();
	}

	/**
	 * Shortcode callback to render the subscription form.
	 *
	 * Usage: [wpnews_subscribe_form list="3"]. By default it prints only the
	 * fields and the button (no heading, no box), so it can sit inside an
	 * Elementor/Gutenberg layout and be styled with CSS. The list id travels
	 * with an HMAC signature, so visitors cannot subscribe to another list.
	 *
	 * Attributes: list, title, description, button, first_name, last_name,
	 * consent, labels (true|false), layout (stacked|inline: only adds the class
	 * wpnews-layout-*), class (extra CSS classes).
	 *
	 * No stylesheet is loaded: the markup is unstyled and carries stable
	 * classes. The only inline styles are functional (hidden honeypot,
	 * screen-reader-only labels), so it also renders correctly in the
	 * Elementor editor where late-enqueued styles never print.
	 *
	 * @param array $atts Shortcode attributes.
	 * @return string HTML output.
	 */
	public function render_subscribe_form_shortcode( $atts ) {
		$atts = shortcode_atts(
			array(
				'list'        => '',
				'list_id'     => 0, // Legacy name, same as `list`.
				'title'       => '',
				'description' => '',
				'button'      => '',
				'first_name'  => 'true',
				'last_name'   => 'true',
				'consent'     => 'false',
				'labels'      => 'true',
				'layout'      => 'stacked',
				'class'       => '',
			),
			$atts,
			'wpnews_subscribe_form'
		);

		$list_id = absint( '' !== trim( (string) $atts['list'] ) ? $atts['list'] : $atts['list_id'] );
		if ( ! $list_id ) {
			$list_id = self::get_default_signup_list_id();
		}
		$list = $list_id ? WPNews_List_Manager::get_list( $list_id ) : null;

		if ( ! $list ) {
			// Visitors see nothing; administrators get a hint on what to fix.
			if ( ! current_user_can( 'manage_options' ) ) {
				return '';
			}
			return '<p class="wpnews-form-notice">' . esc_html__( 'WP-News signup form: no mailing list selected. Add list="ID" to the shortcode or choose a default signup list in Newsletter → Settings. (Only administrators see this message.)', 'wp-news' ) . '</p>';
		}

		// Assets only where the form is present.
		$this->register_assets();
		wp_enqueue_script( $this->plugin_name );

		$bool            = static function ( $v ) {
			return filter_var( $v, FILTER_VALIDATE_BOOLEAN );
		};
		$show_first_name = $bool( $atts['first_name'] );
		$show_last_name  = $bool( $atts['last_name'] );
		$show_consent    = $bool( $atts['consent'] );
		$show_labels     = $bool( $atts['labels'] );
		$layout          = 'inline' === strtolower( trim( (string) $atts['layout'] ) ) ? 'inline' : 'stacked';
		$title           = trim( sanitize_text_field( (string) $atts['title'] ) );
		$title           = 'none' === strtolower( $title ) ? '' : $title;
		$description     = sanitize_text_field( (string) $atts['description'] );
		$button          = '' !== trim( (string) $atts['button'] ) ? sanitize_text_field( $atts['button'] ) : __( 'Subscribe', 'wp-news' );
		$privacy_url     = get_privacy_policy_url();
		$uid             = 'wpnews-' . wp_unique_id();
		$label_class     = $show_labels ? ' class="wpnews-label"' : ' class="wpnews-label wpnews-sr-only" style="position:absolute;width:1px;height:1px;margin:-1px;padding:0;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border:0"';

		$classes = array( 'wpnews-subscribe-form', 'wpnews-layout-' . $layout );
		foreach ( preg_split( '/\s+/', (string) $atts['class'] ) as $extra ) {
			$extra = sanitize_html_class( $extra );
			if ( '' !== $extra ) {
				$classes[] = $extra;
			}
		}

		ob_start();
		?>
		<form class="<?php echo esc_attr( implode( ' ', $classes ) ); ?>" method="post" novalidate>
			<?php if ( '' !== $title ) : ?>
				<h3 class="wpnews-form-title"><?php echo esc_html( $title ); ?></h3>
			<?php endif; ?>
			<?php if ( '' !== $description ) : ?>
				<p class="wpnews-form-description"><?php echo esc_html( $description ); ?></p>
			<?php endif; ?>

			<input type="hidden" name="list_id" value="<?php echo esc_attr( $list_id ); ?>">
			<input type="hidden" name="list_sig" value="<?php echo esc_attr( $this->sign( 'signup_list:' . $list_id ) ); ?>">

			<div class="wpnews-form-fields">
				<?php if ( $show_first_name ) : ?>
					<div class="wpnews-form-group wpnews-field-first-name">
						<label for="<?php echo esc_attr( $uid ); ?>-first-name"<?php echo $label_class; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static string ?>><?php esc_html_e( 'First Name', 'wp-news' ); ?></label>
						<input type="text" class="wpnews-form-input" id="<?php echo esc_attr( $uid ); ?>-first-name" name="first_name" maxlength="100" autocomplete="given-name" placeholder="<?php esc_attr_e( 'Your first name', 'wp-news' ); ?>">
					</div>
				<?php endif; ?>
				<?php if ( $show_last_name ) : ?>
					<div class="wpnews-form-group wpnews-field-last-name">
						<label for="<?php echo esc_attr( $uid ); ?>-last-name"<?php echo $label_class; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static string ?>><?php esc_html_e( 'Last Name', 'wp-news' ); ?></label>
						<input type="text" class="wpnews-form-input" id="<?php echo esc_attr( $uid ); ?>-last-name" name="last_name" maxlength="100" autocomplete="family-name" placeholder="<?php esc_attr_e( 'Your last name', 'wp-news' ); ?>">
					</div>
				<?php endif; ?>
				<div class="wpnews-form-group wpnews-field-email">
					<label for="<?php echo esc_attr( $uid ); ?>-email"<?php echo $label_class; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static string ?>><?php esc_html_e( 'Email (required)', 'wp-news' ); ?></label>
					<input type="email" class="wpnews-form-input" id="<?php echo esc_attr( $uid ); ?>-email" name="email" required maxlength="255" autocomplete="email" placeholder="<?php esc_attr_e( 'Your email', 'wp-news' ); ?>">
				</div>
				<div class="wpnews-form-group wpnews-field-submit">
					<button type="submit" class="wpnews-submit-btn"><?php echo esc_html( $button ); ?></button>
				</div>
			</div>

			<?php if ( $show_consent ) : ?>
				<div class="wpnews-form-consent">
					<input type="hidden" name="wpnews_consent_required" value="1">
					<label class="wpnews-consent-label">
						<input type="checkbox" class="wpnews-consent-checkbox" name="wpnews_consent" value="1" required>
						<span class="wpnews-consent-text">
							<?php
							if ( $privacy_url ) {
								printf(
									/* translators: %s: link to the privacy policy page */
									esc_html__( 'I agree to receive the newsletter and accept the %s.', 'wp-news' ),
									'<a href="' . esc_url( $privacy_url ) . '" target="_blank" rel="noopener">' . esc_html__( 'privacy policy', 'wp-news' ) . '</a>'
								);
							} else {
								esc_html_e( 'I agree to receive the newsletter.', 'wp-news' );
							}
							?>
						</span>
					</label>
				</div>
			<?php endif; ?>

			<!-- Honeypot: must stay empty -->
			<div class="wpnews-hp" aria-hidden="true" style="position:absolute;left:-9999px;width:1px;height:1px;overflow:hidden">
				<label for="<?php echo esc_attr( $uid ); ?>-website"><?php esc_html_e( 'Leave this field empty', 'wp-news' ); ?></label>
				<input type="text" id="<?php echo esc_attr( $uid ); ?>-website" name="wpnews_website" tabindex="-1" autocomplete="off" value="">
			</div>

			<div class="wpnews-message-slot" aria-live="polite"></div>
		</form>
		<?php
		return ob_get_clean();
	}

	/**
	 * Default list used by [wpnews_subscribe_form] when no `list` is given.
	 *
	 * @return int List ID, 0 when not configured.
	 */
	public static function get_default_signup_list_id() {
		$options = get_option( 'wpnews_options', array() );
		return is_array( $options ) && ! empty( $options['signup_list_id'] ) ? absint( $options['signup_list_id'] ) : 0;
	}

	/* ------------------------------------------------------------------
	 * Helpers
	 * ------------------------------------------------------------------ */

	/**
	 * Sign data with the site HMAC secret (WPNews_Security when available).
	 *
	 * @param string $data Data to sign.
	 * @return string
	 */
	private function sign( $data ) {
		if ( method_exists( 'WPNews_Security', 'sign' ) ) {
			return WPNews_Security::sign( (string) $data );
		}
		$secret = get_option( 'wpnews_unsubscribe_secret', '' );
		if ( ! is_string( $secret ) || '' === $secret ) {
			$secret = bin2hex( random_bytes( 32 ) );
			add_option( 'wpnews_unsubscribe_secret', $secret, '', false );
		}
		return hash_hmac( 'sha256', (string) $data, $secret );
	}

	/**
	 * Constant-time token verification.
	 *
	 * @param string $data  Signed data.
	 * @param string $token Token from the request.
	 * @return bool
	 */
	private function verify_token( $data, $token ) {
		$token = (string) $token;
		if ( '' === $token ) {
			return false;
		}
		if ( method_exists( 'WPNews_Security', 'verify' ) && WPNews_Security::verify( (string) $data, $token ) ) {
			return true;
		}
		$secret = get_option( 'wpnews_unsubscribe_secret', '' );
		if ( ! is_string( $secret ) || '' === $secret ) {
			return false;
		}
		return hash_equals( hash_hmac( 'sha256', (string) $data, $secret ), $token );
	}

	/**
	 * Headers for the standalone confirm/unsubscribe pages: never cached,
	 * never indexed (also tells LiteSpeed Cache to bypass).
	 */
	private function send_private_page_headers() {
		nocache_headers();
		if ( ! headers_sent() ) {
			header( 'X-Robots-Tag: noindex, nofollow', true );
		}
		do_action( 'litespeed_control_set_nocache', 'wpnews' );
	}

	/**
	 * Best-effort client IP for rate limiting.
	 *
	 * @return string
	 */
	private function get_client_ip() {
		$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
		return '' !== $ip ? $ip : 'unknown';
	}

	/**
	 * Build the double opt-in confirmation email.
	 *
	 * @param string $confirm_url Confirmation URL.
	 * @return string HTML.
	 */
	private function build_confirmation_email( $confirm_url ) {
		$body_title = __( 'Confirm your subscription!', 'wp-news' );
		$body_text  = __( 'Thank you for signing up for our newsletter. Please click the button below to confirm your email address and complete your subscription.', 'wp-news' );
		$btn_text   = __( 'Confirm Subscription', 'wp-news' );
		$ignore     = __( 'If you did not request this subscription, you can safely ignore this email.', 'wp-news' );

		return '<!DOCTYPE html>
<html>
<body style="margin:0; padding:0; background-color:#f1f5f9; font-family:-apple-system,BlinkMacSystemFont,Arial,sans-serif;">
	<table width="100%" cellpadding="0" cellspacing="0" style="background-color:#f1f5f9; padding:40px 0;">
		<tr>
			<td align="center">
				<table width="500" cellpadding="0" cellspacing="0" style="background-color:#ffffff; border-radius:16px; overflow:hidden; box-shadow:0 10px 30px rgba(0,0,0,0.05); border:1px solid #e2e8f0;">
					<tr>
						<td style="background:linear-gradient(135deg,#667eea 0%,#764ba2 100%); padding:40px; text-align:center;">
							<h1 style="margin:0; color:#ffffff; font-size:24px; font-weight:600;">' . esc_html( $body_title ) . '</h1>
						</td>
					</tr>
					<tr>
						<td style="padding:40px; text-align:center;">
							<p style="color:#475569; font-size:16px; line-height:1.6; margin:0 0 32px;">' . esc_html( $body_text ) . '</p>
							<a href="' . esc_url( $confirm_url ) . '" style="display:inline-block; background-color:#3b82f6; color:#ffffff; padding:14px 28px; font-size:16px; font-weight:500; text-decoration:none; border-radius:8px; box-shadow:0 4px 14px rgba(59,130,246,0.3);">' . esc_html( $btn_text ) . '</a>
							<p style="color:#94a3b8; font-size:13px; margin:32px 0 0;">' . esc_html( $ignore ) . '</p>
						</td>
					</tr>
				</table>
			</td>
		</tr>
	</table>
</body>
</html>';
	}

	/* ------------------------------------------------------------------
	 * AJAX: subscribe
	 * ------------------------------------------------------------------ */

	/**
	 * Handle subscription via AJAX.
	 */
	public function handle_subscription() {
		// Visitors get the form from full-page cache (LiteSpeed), where the
		// nonce can be days old: for them the signed list id, the honeypot and
		// the rate limits below are the protection. Logged-in users always get
		// a fresh page, so their requests keep the CSRF check.
		if ( is_user_logged_in() ) {
			check_ajax_referer( 'wpnews_public_nonce', 'nonce' );
		}

		$success_message = __( 'Thank you for subscribing!', 'wp-news' );

		// Honeypot: bots fill it in; answer "success" without doing anything.
		$honeypot = isset( $_POST['wpnews_website'] ) ? trim( (string) wp_unslash( $_POST['wpnews_website'] ) ) : '';
		if ( '' !== $honeypot ) {
			WPNews_Antispam::count( 'honeypot' );
			wp_send_json_success( array( 'message' => $success_message ) );
		}

		// Rate limit per IP: max 5 attempts / 10 minutes.
		$ip_key   = 'wpnews_rl_ip_' . md5( $this->get_client_ip() );
		$ip_count = (int) get_transient( $ip_key );
		if ( $ip_count >= 5 ) {
			if ( 5 === $ip_count ) { // Count once per window, not on every blocked request.
				WPNews_Antispam::count( 'rate_ip' );
				set_transient( $ip_key, $ip_count + 1, 10 * MINUTE_IN_SECONDS );
			}
			wp_send_json_error( array( 'message' => __( 'Too many requests. Please try again in a few minutes.', 'wp-news' ) ), 429 );
		}
		set_transient( $ip_key, $ip_count + 1, 10 * MINUTE_IN_SECONDS );

		$email      = isset( $_POST['email'] ) ? WPNews_Security::sanitize_email( $_POST['email'] ) : '';
		$first_name = isset( $_POST['first_name'] ) ? WPNews_Security::sanitize_text( $_POST['first_name'] ) : '';
		$last_name  = isset( $_POST['last_name'] ) ? WPNews_Security::sanitize_text( $_POST['last_name'] ) : '';
		$list_id    = isset( $_POST['list_id'] ) ? absint( $_POST['list_id'] ) : 0;
		$list_sig   = isset( $_POST['list_sig'] ) ? sanitize_text_field( wp_unslash( $_POST['list_sig'] ) ) : '';

		if ( ! $list_id || ! $this->verify_token( 'signup_list:' . $list_id, $list_sig ) || ! WPNews_List_Manager::get_list( $list_id ) ) {
			wp_send_json_error( array( 'message' => __( 'This signup form is no longer valid. Please reload the page and try again.', 'wp-news' ) ) );
		}

		// Bots get the same "thank you" as humans, so they learn nothing.
		if ( WPNews_Antispam::looks_like_spam( $first_name, $last_name ) ) {
			WPNews_Antispam::count( 'content' );
			wp_send_json_success( array( 'message' => $success_message ) );
		}
		if ( WPNews_Antispam::pow_enabled() ) {
			$pow_fail = WPNews_Antispam::verify_pow(
				isset( $_POST['wpnews_c'] ) ? sanitize_text_field( wp_unslash( $_POST['wpnews_c'] ) ) : '',
				isset( $_POST['wpnews_s'] ) ? sanitize_text_field( wp_unslash( $_POST['wpnews_s'] ) ) : '',
				isset( $_POST['wpnews_n'] ) ? sanitize_text_field( wp_unslash( $_POST['wpnews_n'] ) ) : ''
			);
			if ( '' !== $pow_fail ) {
				WPNews_Antispam::count( $pow_fail );
				if ( 'expired' === $pow_fail ) {
					// A human who left the page open for hours: let them retry.
					wp_send_json_error( array( 'message' => __( 'This page has been open for a long time. Please reload it and try again.', 'wp-news' ) ) );
				}
				wp_send_json_success( array( 'message' => $success_message ) );
			}
		}

		if ( '' === $email || ! WPNews_Security::is_valid_email( $email ) ) {
			wp_send_json_error( array( 'message' => __( 'Invalid email address.', 'wp-news' ) ) );
		}

		$email_problem = WPNews_Antispam::email_problem( $email );
		if ( '' !== $email_problem ) {
			wp_send_json_error( array( 'message' => $email_problem ) );
		}

		if ( ! empty( $_POST['wpnews_consent_required'] ) && empty( $_POST['wpnews_consent'] ) ) {
			wp_send_json_error( array( 'message' => __( 'Please accept the privacy conditions to subscribe.', 'wp-news' ) ) );
		}

		// Rate limit per email: 1 request / 2 minutes.
		$email_key = 'wpnews_rl_em_' . md5( strtolower( $email ) );
		if ( get_transient( $email_key ) ) {
			wp_send_json_error( array( 'message' => __( 'A request for this email address was made recently. Please wait a couple of minutes and try again.', 'wp-news' ) ), 429 );
		}

		// Check blacklist
		if ( WPNews_Blacklist_Manager::is_blacklisted( $email ) ) {
			wp_send_json_error( array( 'message' => __( 'This email address cannot be subscribed.', 'wp-news' ) ) );
		}

		global $wpdb;
		$subscribers_table = $wpdb->prefix . 'wpnews_subscribers';

		$options      = get_option( 'wpnews_options', array() );
		$double_optin = is_array( $options ) && array_key_exists( 'double_optin', $options ) ? (bool) $options['double_optin'] : true;

		$subscriber = $wpdb->get_row(
			$wpdb->prepare( "SELECT id, status FROM $subscribers_table WHERE email = %s", $email )
		);

		$needs_confirmation = $double_optin;
		$subscriber_id      = 0;

		if ( $subscriber ) {
			$subscriber_id = (int) $subscriber->id;
			$status        = (string) $subscriber->status;

			if ( 'active' === $status ) {
				set_transient( $email_key, 1, 2 * MINUTE_IN_SECONDS );

				if ( WPNews_List_Manager::is_subscriber_in_list( $subscriber_id, $list_id ) ) {
					wp_send_json_success( array( 'message' => $success_message ) );
				}

				if ( ! $double_optin ) {
					WPNews_List_Manager::add_subscriber_to_list( $subscriber_id, $list_id );
					wp_send_json_success( array( 'message' => $success_message ) );
				}

				// Already subscribed elsewhere: joining this list needs the
				// owner's confirmation too, otherwise anyone could add a known
				// address to any list. The list is added when the link is clicked.
				$this->send_confirmation_or_fail( $email, $subscriber_id, $list_id );
			}

			// A previously unsubscribed address is NEVER re-activated silently:
			// it always has to confirm again via email.
			if ( 'unsubscribed' === $status ) {
				$needs_confirmation = true;
			}

			$wpdb->update(
				$subscribers_table,
				array(
					'first_name' => $first_name,
					'last_name'  => $last_name,
					'status'     => $needs_confirmation ? 'pending' : 'active',
				),
				array( 'id' => $subscriber_id ),
				array( '%s', '%s', '%s' ),
				array( '%d' )
			);
		} else {
			$wpdb->insert(
				$subscribers_table,
				array(
					'email'      => $email,
					'first_name' => $first_name,
					'last_name'  => $last_name,
					'status'     => $needs_confirmation ? 'pending' : 'active',
				),
				array( '%s', '%s', '%s', '%s' )
			);
			$subscriber_id = (int) $wpdb->insert_id;
		}

		if ( ! $subscriber_id ) {
			wp_send_json_error( array( 'message' => __( 'Error subscribing. Please try again.', 'wp-news' ) ) );
		}

		// Associate to list (counted / emailed only once status is 'active').
		WPNews_List_Manager::add_subscriber_to_list( $subscriber_id, $list_id );

		set_transient( $email_key, 1, 2 * MINUTE_IN_SECONDS );

		if ( $needs_confirmation ) {
			$this->send_confirmation_or_fail( $email, $subscriber_id );
		}

		wp_send_json_success( array( 'message' => $success_message ) );
	}

	/**
	 * Send the double opt-in email and end the AJAX request.
	 *
	 * @param string $email         Recipient.
	 * @param int    $subscriber_id Subscriber ID.
	 * @param int    $list_id       List to add on confirmation (0 = membership already stored).
	 */
	private function send_confirmation_or_fail( $email, $subscriber_id, $list_id = 0 ) {
		$args = array(
			'wpnews_confirm' => 1,
			's'              => $subscriber_id,
		);
		if ( $list_id ) {
			$args['l']     = $list_id;
			$args['token'] = $this->sign( 'confirm:' . $subscriber_id . ':' . $list_id );
		} else {
			$args['token'] = $this->sign( 'confirm:' . $subscriber_id );
		}
		$confirm_url = add_query_arg( $args, home_url( '/' ) );

		/* translators: %s: site name */
		$subject = sprintf( __( 'Please confirm your subscription - %s', 'wp-news' ), get_bloginfo( 'name' ) );
		$mailer  = new WPNews_Mailer();
		$result  = $mailer->send_email( $email, $subject, $this->build_confirmation_email( $confirm_url ) );

		if ( ! is_array( $result ) || empty( $result['success'] ) ) {
			wp_send_json_error( array( 'message' => __( 'We could not send the confirmation email. Please try again later.', 'wp-news' ) ) );
		}

		wp_send_json_success( array( 'message' => __( 'Please check your email to confirm your subscription.', 'wp-news' ) ) );
	}


	/* ------------------------------------------------------------------
	 * Standalone pages (init)
	 * ------------------------------------------------------------------ */

	/**
	 * Handle standalone Unsubscribe page intercept.
	 *
	 * - With `s`: the HMAC token is ALWAYS required (s:c).
	 * - Preview mode (`test=1`) only works WITHOUT `s` and never touches the DB.
	 */
	public function handle_unsubscribe_page() {
		if ( ! isset( $_GET['wpnews_unsubscribe'] ) ) {
			return;
		}

		$this->send_private_page_headers();

		global $wpdb;
		$subscribers_table = $wpdb->prefix . 'wpnews_subscribers';

		$has_sid       = isset( $_GET['s'] );
		$subscriber_id = $has_sid ? absint( $_GET['s'] ) : 0;
		$campaign_id   = isset( $_GET['c'] ) ? absint( $_GET['c'] ) : 0;
		$token         = isset( $_GET['token'] ) ? sanitize_text_field( wp_unslash( $_GET['token'] ) ) : '';
		$is_test       = ! $has_sid && isset( $_GET['test'] );

		$error      = '';
		$is_success = false;
		$email      = '';
		$subscriber = null;

		if ( $has_sid ) {
			if ( ! $subscriber_id || ! $this->verify_token( $subscriber_id . ':' . $campaign_id, $token ) ) {
				wp_die( esc_html__( 'Invalid unsubscribe link.', 'wp-news' ), '', array( 'response' => 403 ) );
			}
			$subscriber = $wpdb->get_row( $wpdb->prepare( "SELECT id, email FROM $subscribers_table WHERE id = %d", $subscriber_id ) );
			if ( $subscriber ) {
				$email = (string) $subscriber->email;
			} else {
				$error = __( 'Subscriber not found.', 'wp-news' );
			}
		} elseif ( $is_test ) {
			$email = 'name@example.com';
		} else {
			$error = __( 'Invalid link.', 'wp-news' );
		}

		$action = isset( $_POST['wpnews_action'] ) ? sanitize_key( wp_unslash( $_POST['wpnews_action'] ) ) : '';
		if ( 'unsubscribe' === $action && '' === $error ) {
			$nonce_action = 'wpnews_unsubscribe_' . ( $is_test ? 'test' : $subscriber_id );
			$nonce        = isset( $_POST['wpnews_unsub_nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['wpnews_unsub_nonce'] ) ) : '';

			if ( ! wp_verify_nonce( $nonce, $nonce_action ) ) {
				$error = __( 'Your session has expired. Please open the unsubscribe link from your email again.', 'wp-news' );
			} elseif ( $is_test ) {
				$is_success = true; // Preview only.
			} elseif ( $subscriber ) {
				$wpdb->update(
					$subscribers_table,
					array(
						'status'          => 'unsubscribed',
						'unsubscribed_at' => current_time( 'mysql' ),
					),
					array( 'id' => $subscriber_id ),
					array( '%s', '%s' ),
					array( '%d' )
				);

				if ( class_exists( 'WPNews_Blacklist_Manager' ) && '' !== $email ) {
					WPNews_Blacklist_Manager::add_to_blacklist( $email, 'Unsubscribed via footer link (Campaign ID: ' . $campaign_id . ')' );
				}

				$is_success = true;
			}
		}

		$site_name = get_bloginfo( 'name' );
		$home_url  = home_url( '/' );

		require plugin_dir_path( __FILE__ ) . 'partials/wpnews-unsubscribe-display.php';
		exit;
	}

	/**
	 * Handle standalone Confirm page intercept.
	 * GET activates the subscriber only when the signed token is valid
	 * (protects against link prefetchers hitting random ids).
	 */
	public function handle_confirm_page() {
		if ( ! isset( $_GET['wpnews_confirm'] ) ) {
			return;
		}

		$this->send_private_page_headers();

		$subscriber_id = isset( $_GET['s'] ) ? absint( $_GET['s'] ) : 0;
		$list_id       = isset( $_GET['l'] ) ? absint( $_GET['l'] ) : 0;
		$token         = isset( $_GET['token'] ) ? sanitize_text_field( wp_unslash( $_GET['token'] ) ) : '';
		$signed_data   = 'confirm:' . $subscriber_id . ( $list_id ? ':' . $list_id : '' );

		if ( ! $subscriber_id || ! $this->verify_token( $signed_data, $token ) ) {
			wp_die( esc_html__( 'Invalid or expired confirmation link.', 'wp-news' ), '', array( 'response' => 403 ) );
		}

		global $wpdb;
		$subscribers_table = $wpdb->prefix . 'wpnews_subscribers';

		$subscriber = $wpdb->get_row( $wpdb->prepare( "SELECT id, status FROM $subscribers_table WHERE id = %d", $subscriber_id ) );
		if ( ! $subscriber ) {
			wp_die( esc_html__( 'Invalid or expired confirmation link.', 'wp-news' ), '', array( 'response' => 403 ) );
		}

		if ( 'active' !== (string) $subscriber->status ) {
			$wpdb->update(
				$subscribers_table,
				array(
					'status'          => 'active',
					'unsubscribed_at' => null,
				),
				array( 'id' => $subscriber_id ),
				array( '%s', null ),
				array( '%d' )
			);
		}

		// Existing subscriber joining a further list from a signup form.
		if ( $list_id && WPNews_List_Manager::get_list( $list_id ) ) {
			WPNews_List_Manager::add_subscriber_to_list( $subscriber_id, $list_id );
		}

		$site_name = get_bloginfo( 'name' );
		$home_url  = home_url( '/' );

		require plugin_dir_path( __FILE__ ) . 'partials/wpnews-confirm-display.php';
		exit;
	}
}
