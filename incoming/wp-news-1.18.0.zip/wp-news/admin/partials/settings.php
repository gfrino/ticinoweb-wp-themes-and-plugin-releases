<?php
/**
 * Settings admin page.
 *
 * Options are saved exclusively through the Settings API (options.php →
 * WPNews_Admin::sanitize_options). Connection tests and the test email use a
 * separate form and never write options.
 *
 * @package WPNews
 */

if (!defined('ABSPATH')) {
	exit;
}

if (!current_user_can('manage_options')) {
	wp_die(esc_html__('You do not have permission to access this page.', 'wp-news'), '', array('response' => 403));
}

$options = get_option('wpnews_options', array());
if (!is_array($options)) {
	$options = array();
}

$opt = static function ($key, $default = '') use ($options) {
	return isset($options[$key]) ? $options[$key] : $default;
};

// Settings API redirects back here with settings-updated=true.
if (isset($_GET['settings-updated']) && 'true' === $_GET['settings-updated']) {
	add_settings_error('wpnews_messages', 'wpnews_saved', __('Settings saved successfully!', 'wp-news'), 'success');
}

// ------------------------------------------------------------------
// Diagnostics (connection tests + test email). Uses SAVED settings.
// ------------------------------------------------------------------
if (isset($_POST['wpnews_test_action']) && WPNews_Security::verify_nonce('wpnews_tests_nonce', 'wpnews_settings_tests')) {
	$test_action = sanitize_key(wp_unslash($_POST['wpnews_test_action']));

	if ('test_sendgrid' === $test_action) {
		$sendgrid    = new WPNews_SendGrid();
		$test_result = $sendgrid->test_connection();
		$ok          = !empty($test_result['success']);
		$msg         = isset($test_result['message']) ? (string) $test_result['message'] : '';
		add_settings_error('wpnews_messages', 'wpnews_test_sendgrid', $msg !== '' ? $msg : ($ok ? __('SendGrid connection successful.', 'wp-news') : __('SendGrid connection failed.', 'wp-news')), $ok ? 'success' : 'error');
	} elseif ('test_ses' === $test_action) {
		if (class_exists('WPNews_SES')) {
			$ses         = new WPNews_SES();
			$test_result = $ses->test_connection();
			$ok          = !empty($test_result['success']);
			$msg         = isset($test_result['message']) ? (string) $test_result['message'] : '';
			add_settings_error('wpnews_messages', 'wpnews_test_ses', $msg !== '' ? $msg : ($ok ? __('Amazon SES connection successful.', 'wp-news') : __('Amazon SES connection failed.', 'wp-news')), $ok ? 'success' : 'error');
		} else {
			add_settings_error('wpnews_messages', 'wpnews_test_ses', __('SES component not loaded. Please save the settings first.', 'wp-news'), 'error');
		}
	} elseif ('send_test_email' === $test_action) {
		$test_email_to = isset($_POST['test_email_to']) ? WPNews_Security::sanitize_email($_POST['test_email_to']) : '';
		if ($test_email_to !== '' && is_email($test_email_to)) {
			$mailer      = new WPNews_Mailer();
			$from_name   = $opt('from_name', get_option('blogname'));
			$from_email  = $opt('from_email', get_option('admin_email'));
			$mailer_type = strtoupper((string) $opt('mailer_type', 'sendgrid'));

			/* translators: %s: sender name */
			$test_subject = sprintf(__('[Test] Newsletter from %s', 'wp-news'), $from_name);
			$test_html    = '
				<!DOCTYPE html>
				<html>
				<body style="margin:0; padding:0; background:#f1f5f9; font-family:Arial,sans-serif;">
					<table width="100%" cellpadding="0" cellspacing="0" style="background:#f1f5f9; padding:40px 0;">
						<tr><td align="center">
							<table width="560" cellpadding="0" cellspacing="0" style="background:#ffffff; border-radius:12px; overflow:hidden; box-shadow:0 2px 8px rgba(0,0,0,0.06);">
								<tr><td style="background:linear-gradient(135deg,#3b82f6,#1d4ed8); padding:32px 40px; text-align:center;">
									<h1 style="margin:0; color:#ffffff; font-size:24px;">' . esc_html__('Test Email Successful!', 'wp-news') . '</h1>
								</td></tr>
								<tr><td style="padding:32px 40px;">
									<p style="color:#334155; font-size:16px; line-height:1.6; margin:0 0 16px;">
										' . esc_html__('This is a test email from your WP-News Newsletter plugin.', 'wp-news') . '
									</p>
									<table style="width:100%; border-collapse:collapse; margin:16px 0;">
										<tr style="border-bottom:1px solid #e2e8f0;">
											<td style="padding:10px 0; color:#64748b; font-size:13px; width:140px;">' . esc_html__('Mailer', 'wp-news') . '</td>
											<td style="padding:10px 0; color:#1e293b; font-size:13px; font-weight:600;">' . esc_html($mailer_type) . '</td>
										</tr>
										<tr style="border-bottom:1px solid #e2e8f0;">
											<td style="padding:10px 0; color:#64748b; font-size:13px;">' . esc_html__('From', 'wp-news') . '</td>
											<td style="padding:10px 0; color:#1e293b; font-size:13px;">' . esc_html($from_name) . ' &lt;' . esc_html($from_email) . '&gt;</td>
										</tr>
										<tr>
											<td style="padding:10px 0; color:#64748b; font-size:13px;">' . esc_html__('Sent at', 'wp-news') . '</td>
											<td style="padding:10px 0; color:#1e293b; font-size:13px;">' . esc_html(current_time('Y-m-d H:i:s')) . '</td>
										</tr>
									</table>
									<p style="color:#64748b; font-size:13px; margin:16px 0 0;">'
				. esc_html__('If you received this email, your email configuration is working correctly.', 'wp-news') .
				'</p>
								</td></tr>
							</table>
						</td></tr>
					</table>
				</body>
				</html>';

			$result = $mailer->send_email($test_email_to, $test_subject, $test_html);
			if (!empty($result['success'])) {
				/* translators: 1: recipient email, 2: mailer name */
				add_settings_error('wpnews_messages', 'wpnews_test_email', sprintf(__('Test email sent successfully to %1$s via %2$s.', 'wp-news'), $test_email_to, $mailer_type), 'success');
			} else {
				/* translators: %s: error message */
				add_settings_error('wpnews_messages', 'wpnews_test_email', sprintf(__('Failed to send test email: %s', 'wp-news'), isset($result['message']) ? (string) $result['message'] : __('Unknown error', 'wp-news')), 'error');
			}
		} else {
			add_settings_error('wpnews_messages', 'wpnews_test_email', __('Please enter a valid email address for the test.', 'wp-news'), 'error');
		}
	}
}

$lists          = WPNews_List_Manager::get_lists();
$webhook_secret = (string) $opt('webhook_secret', '');
$sendgrid_hook  = rest_url('wp-news/v1/sendgrid-webhook');
$sns_hook       = rest_url('wp-news/v1/sns-webhook');
$sendgrid_hook_full = $webhook_secret !== '' ? add_query_arg('key', $webhook_secret, $sendgrid_hook) : '';
$sns_hook_full      = $webhook_secret !== '' ? add_query_arg('key', $webhook_secret, $sns_hook) : '';
$ses_region     = (string) $opt('ses_region', 'eu-central-1');
$mailer_type    = in_array($opt('mailer_type', 'sendgrid'), array('sendgrid', 'ses'), true) ? $opt('mailer_type', 'sendgrid') : 'sendgrid';
$keep_placeholder = __('Leave empty to keep the current value', 'wp-news');

$regions = array(
	'us-east-1'      => 'US East (N. Virginia)',
	'us-east-2'      => 'US East (Ohio)',
	'us-west-1'      => 'US West (N. California)',
	'us-west-2'      => 'US West (Oregon)',
	'eu-west-1'      => 'Europe (Ireland)',
	'eu-central-1'   => 'Europe (Frankfurt)',
	'eu-central-2'   => 'Europe (Zurich)',
	'eu-west-2'      => 'Europe (London)',
	'eu-west-3'      => 'Europe (Paris)',
	'eu-south-1'     => 'Europe (Milan)',
	'ap-south-1'     => 'Asia Pacific (Mumbai)',
	'ap-northeast-1' => 'Asia Pacific (Tokyo)',
	'ap-southeast-1' => 'Asia Pacific (Singapore)',
	'ap-southeast-2' => 'Asia Pacific (Sydney)',
);
if (!isset($regions[$ses_region])) {
	$ses_region = 'eu-central-1';
}
?>

<div class="wpnews-admin-wrap">
	<div class="wpnews-header">
		<h1><?php esc_html_e('Newsletter Settings', 'wp-news'); ?></h1>
	</div>

	<?php settings_errors('wpnews_messages'); ?>

	<div class="wpnews-card">
		<form method="post" action="<?php echo esc_url(admin_url('options.php')); ?>">
			<?php settings_fields('wpnews_options_group'); ?>
			<input type="hidden" name="wpnews_options[settings_form]" value="1">

			<h2 class="nav-tab-wrapper wpnews-settings-tabs">
				<a href="#tab-general" class="nav-tab nav-tab-active" data-wpnews-tab="tab-general"><?php esc_html_e('General', 'wp-news'); ?></a>
				<a href="#tab-sending" class="nav-tab" data-wpnews-tab="tab-sending"><?php esc_html_e('Sending method', 'wp-news'); ?></a>
			</h2>

			<!-- TAB: GENERAL -->
			<div id="tab-general" class="wpnews-tab-content" data-wpnews-panel="tab-general">
				<h2><?php esc_html_e('Email Settings', 'wp-news'); ?></h2>

				<div class="wpnews-form-field">
					<label for="from_name"><?php esc_html_e('From Name', 'wp-news'); ?></label>
					<input type="text" id="from_name" name="wpnews_options[from_name]"
						value="<?php echo esc_attr($opt('from_name', get_option('blogname'))); ?>" class="regular-text">
				</div>

				<div class="wpnews-form-field">
					<label for="from_email"><?php esc_html_e('From Email', 'wp-news'); ?></label>
					<input type="email" id="from_email" name="wpnews_options[from_email]"
						value="<?php echo esc_attr($opt('from_email', get_option('admin_email'))); ?>" class="regular-text">
				</div>

				<hr>

				<h2><?php esc_html_e('Subscription Settings', 'wp-news'); ?></h2>

				<div class="wpnews-form-field">
					<label>
						<input type="checkbox" name="wpnews_options[double_optin]" value="1" <?php checked((bool) $opt('double_optin', true)); ?>>
						<?php esc_html_e('Enable double opt-in', 'wp-news'); ?>
					</label>
					<p class="description">
						<?php esc_html_e('Require subscribers to confirm their email address. Subscribers who previously unsubscribed always have to confirm again, regardless of this setting.', 'wp-news'); ?>
					</p>
				</div>

				<div class="wpnews-form-field wpnews-mt-20 wpnews-info-box wpnews-info-box--green">
					<label><strong><?php esc_html_e('Anti-spam protection', 'wp-news'); ?></strong></label>
					<p>
						<label>
							<input type="checkbox" name="wpnews_options[antispam_pow]" value="1" <?php checked(WPNews_Antispam::pow_enabled()); ?>>
							<?php esc_html_e('Invisible security check in the browser (recommended)', 'wp-news'); ?>
						</label>
					</p>
					<p class="description"><?php esc_html_e('No captcha and no external service. Always active: hidden trap field, time check, single-use tokens, rate limits, email domain check (MX) and blocking of temporary email addresses. Bots get a fake "thank you" and are not subscribed.', 'wp-news'); ?></p>
					<?php
					$wpnews_blocked = WPNews_Antispam::totals(30);
					$wpnews_total   = array_sum($wpnews_blocked);
					?>
					<p>
						<strong>
							<?php
							/* translators: %s: number of blocked attempts */
							printf(esc_html(_n('%s attempt blocked in the last 30 days', '%s attempts blocked in the last 30 days', $wpnews_total, 'wp-news')), esc_html(number_format_i18n($wpnews_total)));
							?>
						</strong>
					</p>
					<?php if ($wpnews_total) : ?>
						<ul class="wpnews-antispam-stats">
							<?php foreach ($wpnews_blocked as $wpnews_reason => $wpnews_n) : ?>
								<li><?php echo esc_html(WPNews_Antispam::reason_label($wpnews_reason)); ?>: <strong><?php echo esc_html(number_format_i18n($wpnews_n)); ?></strong></li>
							<?php endforeach; ?>
						</ul>
					<?php endif; ?>
				</div>

				<div class="wpnews-form-field wpnews-mt-20">
					<label for="signup_list_id"><?php esc_html_e('Default newsletter list', 'wp-news'); ?></label>
					<?php
					$signup_lists   = WPNews_List_Manager::get_lists();
					$signup_list_id = absint($opt('signup_list_id', 0));
					?>
					<select id="signup_list_id" name="wpnews_options[signup_list_id]">
						<option value="0"><?php esc_html_e('— None —', 'wp-news'); ?></option>
						<?php foreach ($signup_lists as $signup_list) : ?>
							<option value="<?php echo esc_attr((int) $signup_list['id']); ?>" <?php selected($signup_list_id, (int) $signup_list['id']); ?>>
								<?php echo esc_html((string) $signup_list['name']); ?>
							</option>
						<?php endforeach; ?>
					</select>
					<p class="description">
						<?php esc_html_e('Used by the WooCommerce checkout checkbox and by older forms whose code has no list. Forms made with the builder always name their own list.', 'wp-news'); ?>
					</p>
					<p>
						<a class="button button-primary" href="<?php echo esc_url(add_query_arg(array('page' => 'wp-news-lists'), admin_url('admin.php')) . '#wpnews-signup-builder'); ?>">
							<span class="dashicons dashicons-feedback wpnews-icon-inline"></span>
							<?php esc_html_e('Create a signup form for a list', 'wp-news'); ?>
						</a>
					</p>
				</div>

				<?php if (class_exists('WooCommerce')) : ?>
					<div class="wpnews-form-field wpnews-mt-20 wpnews-info-box wpnews-info-box--purple">
						<label><strong><?php esc_html_e('WooCommerce checkout', 'wp-news'); ?></strong></label>
						<p>
							<label>
								<input type="hidden" name="wpnews_options[woo_checkout_optin]" value="0">
								<input type="checkbox" name="wpnews_options[woo_checkout_optin]" value="1" <?php checked(!array_key_exists('woo_checkout_optin', $options) || (bool) $options['woo_checkout_optin']); ?>>
								<?php esc_html_e('Show a newsletter checkbox at checkout and add customers who tick it to the default newsletter list', 'wp-news'); ?>
							</label>
						</p>
						<p>
							<label>
								<input type="hidden" name="wpnews_options[woo_checkout_prechecked]" value="0">
								<input type="checkbox" name="wpnews_options[woo_checkout_prechecked]" value="1" <?php checked(!empty($options['woo_checkout_prechecked'])); ?>>
								<?php esc_html_e('Checkbox already ticked', 'wp-news'); ?>
							</label>
						</p>
						<p class="description"><?php esc_html_e('Leave it unticked if you sell to EU customers: GDPR requires an active choice. Customers who unsubscribed or are blacklisted are never added again.', 'wp-news'); ?></p>
						<p>
							<label for="woo_checkout_label"><?php esc_html_e('Checkbox text', 'wp-news'); ?></label><br>
							<input type="text" id="woo_checkout_label" name="wpnews_options[woo_checkout_label]" class="regular-text" value="<?php echo esc_attr((string) $opt('woo_checkout_label', '')); ?>" placeholder="<?php esc_attr_e('Subscribe to our newsletter', 'wp-news'); ?>">
						</p>
						<?php if (!absint($opt('signup_list_id', 0))) : ?>
							<p class="description wpnews-text-warning"><?php esc_html_e('Choose the default newsletter list above, otherwise the checkbox is not shown.', 'wp-news'); ?></p>
						<?php endif; ?>
					</div>
				<?php endif; ?>

				<div class="wpnews-form-field wpnews-mt-20">
					<label for="physical_address"><?php esc_html_e('Physical Sender Address', 'wp-news'); ?></label>
					<textarea id="physical_address" name="wpnews_options[physical_address]" class="large-text" rows="3"><?php echo esc_textarea((string) $opt('physical_address', '')); ?></textarea>
					<p class="description">
						<?php esc_html_e('This address will be automatically appended to the Footer widget to comply with anti-spam laws.', 'wp-news'); ?>
					</p>
				</div>

				<div class="wpnews-form-field wpnews-info-box wpnews-info-box--blue">
					<label><strong><?php esc_html_e('Unsubscribe Link Tag', 'wp-news'); ?></strong></label>
					<p class="description">
						<?php esc_html_e('To allow users to safely unsubscribe, paste the following tag as the URL (href) of any Email Builder button or text link:', 'wp-news'); ?>
					</p>
					<p>
						<a href="<?php echo esc_url(home_url('/?wpnews_unsubscribe=1&test=1')); ?>" target="_blank" rel="noopener" class="button button-small">
							<?php esc_html_e('Preview Unsubscribe Page', 'wp-news'); ?> <span class="dashicons dashicons-external wpnews-icon-inline"></span>
						</a>
					</p>
					<code class="wpnews-code-block"><?php echo esc_html('{{unsubscribe_url}}'); ?></code>
				</div>

				<hr>

				<h2><?php esc_html_e('Internal Notes', 'wp-news'); ?></h2>

				<div class="wpnews-form-field">
					<p class="description wpnews-mb-10">
						<?php esc_html_e('Use this field to store any internal notes or HTML snippets related to the newsletter configuration.', 'wp-news'); ?>
					</p>
					<?php
					wp_editor(
						(string) $opt('admin_note', ''),
						'admin_note',
						array(
							'textarea_name' => 'wpnews_options[admin_note]',
							'media_buttons' => true,
							'textarea_rows' => 10,
						)
					);
					?>
				</div>
			</div>

			<!-- TAB: SENDING METHOD -->
			<div id="tab-sending" class="wpnews-tab-content" data-wpnews-panel="tab-sending" style="display:none;">
				<h2><?php esc_html_e('Sending Method', 'wp-news'); ?></h2>

				<div class="wpnews-form-field">
					<label for="mailer_type"><?php esc_html_e('Select Service', 'wp-news'); ?></label>
					<select id="mailer_type" name="wpnews_options[mailer_type]" class="regular-text wpnews-mailer-select">
						<option value="sendgrid" <?php selected($mailer_type, 'sendgrid'); ?>>SendGrid</option>
						<option value="ses" <?php selected($mailer_type, 'ses'); ?>>Amazon SES</option>
					</select>
				</div>

				<div class="wpnews-form-field wpnews-mt-20">
					<label for="sending_frequency"><?php esc_html_e('Sending rate', 'wp-news'); ?></label>
					<input type="number" id="sending_frequency" name="wpnews_options[sending_frequency]" min="0" max="10000" step="1"
						value="<?php echo esc_attr((int) $opt('sending_frequency', 0)); ?>" class="small-text">
					<p class="description">
						<?php esc_html_e('Emails per minute (Amazon SES only). 0 = no throttling.', 'wp-news'); ?>
					</p>
				</div>

				<hr>

				<h2><?php esc_html_e('Webhook Security', 'wp-news'); ?></h2>

				<div class="wpnews-form-field">
					<label for="webhook_secret"><?php esc_html_e('Webhook secret', 'wp-news'); ?></label>
					<div class="wpnews-inline-field">
						<input type="text" id="webhook_secret" name="wpnews_options[webhook_secret]"
							value="<?php echo esc_attr($webhook_secret); ?>" class="regular-text code" autocomplete="off" spellcheck="false" pattern="[A-Za-z0-9]*">
						<button type="button" class="button" id="wpnews-generate-secret"><?php esc_html_e('Generate', 'wp-news'); ?></button>
					</div>
					<p class="description">
						<?php esc_html_e('Secret token required as the ?key= parameter on the SendGrid and Amazon SNS webhook URLs below. Requests without a valid key are rejected. If left empty, a secret is generated automatically on save. Changing it invalidates the URLs already configured in SendGrid / AWS SNS.', 'wp-news'); ?>
					</p>
				</div>

				<hr>

				<!-- SENDGRID SETTINGS -->
				<div class="mailer-settings-block" data-mailer="sendgrid">
					<h2><?php esc_html_e('SendGrid Configuration', 'wp-news'); ?></h2>
					<div class="wpnews-form-field">
						<label for="sendgrid_api_key"><?php esc_html_e('SendGrid API Key', 'wp-news'); ?></label>
						<input type="password" id="sendgrid_api_key" name="wpnews_options[sendgrid_api_key]" value=""
							class="regular-text" autocomplete="new-password" placeholder="<?php echo esc_attr($keep_placeholder); ?>">
						<p class="description">
							<?php if ($opt('sendgrid_api_key', '') !== '') : ?>
								<span class="wpnews-badge active"><?php esc_html_e('Configured', 'wp-news'); ?></span>
							<?php else : ?>
								<span class="wpnews-badge draft"><?php esc_html_e('Not configured', 'wp-news'); ?></span>
							<?php endif; ?>
							<?php esc_html_e('Enter your SendGrid API key. You can create one at SendGrid.com.', 'wp-news'); ?>
						</p>
					</div>

					<h3 class="wpnews-mb-10"><?php esc_html_e('SendGrid Event Webhook (Delivery Tracking)', 'wp-news'); ?></h3>

					<div class="wpnews-form-field wpnews-info-box wpnews-info-box--green">
						<label><strong><?php esc_html_e('Webhook URL', 'wp-news'); ?></strong></label>
						<p class="description">
							<?php esc_html_e('Copy this URL and set it as the Event Webhook in your SendGrid dashboard. The plugin will automatically receive delivery, bounce and spam report notifications.', 'wp-news'); ?>
						</p>
						<?php if ($sendgrid_hook_full !== '') : ?>
							<code class="wpnews-code-block wpnews-webhook-url" data-base="<?php echo esc_attr($sendgrid_hook); ?>"><?php echo esc_html($sendgrid_hook_full); ?></code>
						<?php else : ?>
							<p class="wpnews-text-warning"><?php esc_html_e('Save the settings once to generate the webhook secret: the full URL will appear here.', 'wp-news'); ?></p>
						<?php endif; ?>
					</div>

					<div class="wpnews-form-field wpnews-info-box wpnews-info-box--purple">
						<label><strong><?php esc_html_e('Automatic actions', 'wp-news'); ?></strong></label>
						<p class="description">
							<?php esc_html_e('Once the SendGrid Event Webhook is configured, the plugin automatically handles:', 'wp-news'); ?>
						</p>
						<ul class="wpnews-feature-list">
							<li><strong><?php esc_html_e('Delivery', 'wp-news'); ?></strong> — <?php esc_html_e('Marks each email as delivered with a timestamp (visible in the campaign statistics).', 'wp-news'); ?></li>
							<li><strong><?php esc_html_e('Bounce / Dropped', 'wp-news'); ?></strong> — <?php esc_html_e('Bounced or rejected addresses are automatically added to the blacklist.', 'wp-news'); ?></li>
							<li><strong><?php esc_html_e('Spam Report', 'wp-news'); ?></strong> — <?php esc_html_e('Recipients who report the email as spam are automatically added to the blacklist.', 'wp-news'); ?></li>
						</ul>

						<hr class="wpnews-hr-light">

						<label><strong><?php esc_html_e('How to configure (2 steps)', 'wp-news'); ?></strong></label>
						<ol class="wpnews-steps">
							<li>
								<strong><?php esc_html_e('Open the SendGrid dashboard', 'wp-news'); ?></strong> —
								<?php esc_html_e('Go to', 'wp-news'); ?>
								<a href="https://app.sendgrid.com/settings/mail_settings/webhook_settings" target="_blank" rel="noopener">SendGrid → Settings → Mail Settings → Event Webhooks</a>,
								<?php esc_html_e('then click "Create new webhook".', 'wp-news'); ?>
							</li>
							<li>
								<strong><?php esc_html_e('Configure the webhook', 'wp-news'); ?></strong> —
								<?php esc_html_e('Paste the webhook URL above (including the ?key= parameter) into the "Post URL" field. Select the events: Delivered, Bounced, Dropped, Spam Reports. Click "Save".', 'wp-news'); ?>
							</li>
						</ol>
					</div>

					<div class="wpnews-form-field wpnews-mt-15">
						<label for="sendgrid_webhook_key"><?php esc_html_e('Webhook Verification Key (Signed Event Webhook)', 'wp-news'); ?></label>
						<input type="password" id="sendgrid_webhook_key" name="wpnews_options[sendgrid_webhook_key]" value=""
							class="regular-text" autocomplete="new-password" placeholder="<?php echo esc_attr($keep_placeholder); ?>">
						<p class="description">
							<?php if ($opt('sendgrid_webhook_key', '') !== '') : ?>
								<span class="wpnews-badge active"><?php esc_html_e('Configured', 'wp-news'); ?></span>
							<?php else : ?>
								<span class="wpnews-badge draft"><?php esc_html_e('Not configured', 'wp-news'); ?></span>
							<?php endif; ?>
							<?php esc_html_e('If you enable the Signed Event Webhook in SendGrid, paste the public verification key here. Events are accepted only when the ?key= secret is valid and, when a verification key is set, the signature is valid too.', 'wp-news'); ?>
						</p>
					</div>
				</div>

				<!-- AMAZON SES SETTINGS -->
				<div class="mailer-settings-block" data-mailer="ses" style="display:none;">
					<h2><?php esc_html_e('Amazon SES Configuration', 'wp-news'); ?></h2>

					<div class="wpnews-form-field">
						<label for="ses_region"><?php esc_html_e('AWS Region', 'wp-news'); ?></label>
						<select id="ses_region" name="wpnews_options[ses_region]" class="regular-text">
							<?php foreach ($regions as $key => $label) : ?>
								<option value="<?php echo esc_attr($key); ?>" <?php selected($ses_region, $key); ?>><?php echo esc_html($label . ' (' . $key . ')'); ?></option>
							<?php endforeach; ?>
						</select>
					</div>

					<div class="wpnews-form-field">
						<label for="ses_access_key"><?php esc_html_e('AWS Access Key ID', 'wp-news'); ?></label>
						<input type="password" id="ses_access_key" name="wpnews_options[ses_access_key]" value=""
							class="regular-text" autocomplete="new-password" placeholder="<?php echo esc_attr($keep_placeholder); ?>">
						<p class="description">
							<?php if ($opt('ses_access_key', '') !== '') : ?>
								<span class="wpnews-badge active"><?php esc_html_e('Configured', 'wp-news'); ?></span>
							<?php else : ?>
								<span class="wpnews-badge draft"><?php esc_html_e('Not configured', 'wp-news'); ?></span>
							<?php endif; ?>
						</p>
					</div>

					<div class="wpnews-form-field">
						<label for="ses_secret_key"><?php esc_html_e('AWS Secret Access Key', 'wp-news'); ?></label>
						<input type="password" id="ses_secret_key" name="wpnews_options[ses_secret_key]" value=""
							class="regular-text" autocomplete="new-password" placeholder="<?php echo esc_attr($keep_placeholder); ?>">
						<p class="description">
							<?php if ($opt('ses_secret_key', '') !== '') : ?>
								<span class="wpnews-badge active"><?php esc_html_e('Configured', 'wp-news'); ?></span>
							<?php else : ?>
								<span class="wpnews-badge draft"><?php esc_html_e('Not configured', 'wp-news'); ?></span>
							<?php endif; ?>
						</p>
					</div>

					<div class="wpnews-form-field">
						<label for="sns_topic_arn"><?php esc_html_e('SNS Topic ARN', 'wp-news'); ?></label>
						<input type="text" id="sns_topic_arn" name="wpnews_options[sns_topic_arn]"
							value="<?php echo esc_attr((string) $opt('sns_topic_arn', '')); ?>" class="regular-text code"
							placeholder="arn:aws:sns:eu-central-1:123456789012:ses-notifications">
						<p class="description">
							<?php esc_html_e('ARN of the SNS topic that sends notifications to this site. Only notifications coming from this topic are accepted by the SNS webhook.', 'wp-news'); ?>
						</p>
					</div>

					<h3 class="wpnews-mb-10"><?php esc_html_e('SNS Webhook (Delivery Tracking)', 'wp-news'); ?></h3>

					<div class="wpnews-form-field wpnews-info-box wpnews-info-box--green">
						<label><strong><?php esc_html_e('Webhook URL', 'wp-news'); ?></strong></label>
						<p class="description">
							<?php esc_html_e('Copy this URL and set it as the HTTPS endpoint in the AWS SNS console. The plugin will confirm the subscription automatically.', 'wp-news'); ?>
						</p>
						<?php if ($sns_hook_full !== '') : ?>
							<code class="wpnews-code-block wpnews-webhook-url" data-base="<?php echo esc_attr($sns_hook); ?>"><?php echo esc_html($sns_hook_full); ?></code>
						<?php else : ?>
							<p class="wpnews-text-warning"><?php esc_html_e('Save the settings once to generate the webhook secret: the full URL will appear here.', 'wp-news'); ?></p>
						<?php endif; ?>
					</div>

					<div class="wpnews-form-field wpnews-info-box wpnews-info-box--purple">
						<label><strong><?php esc_html_e('Automatic actions', 'wp-news'); ?></strong></label>
						<p class="description">
							<?php esc_html_e('Once SNS is configured to notify this webhook, the plugin automatically handles:', 'wp-news'); ?>
						</p>
						<ul class="wpnews-feature-list">
							<li><strong><?php esc_html_e('Delivery', 'wp-news'); ?></strong> — <?php esc_html_e('Marks each email as delivered with a timestamp (visible in the campaign statistics).', 'wp-news'); ?></li>
							<li><strong><?php esc_html_e('Permanent bounces', 'wp-news'); ?></strong> — <?php esc_html_e('Permanently bounced addresses are automatically added to the blacklist.', 'wp-news'); ?></li>
							<li><strong><?php esc_html_e('Spam complaints', 'wp-news'); ?></strong> — <?php esc_html_e('Recipients who report the email as spam are automatically added to the blacklist.', 'wp-news'); ?></li>
						</ul>

						<hr class="wpnews-hr-light">

						<label><strong><?php esc_html_e('How to configure (3 steps)', 'wp-news'); ?></strong></label>
						<ol class="wpnews-steps">
							<li>
								<strong><?php esc_html_e('Create an SNS Topic', 'wp-news'); ?></strong> —
								<?php esc_html_e('Go to', 'wp-news'); ?>
								<a href="<?php echo esc_url('https://' . $ses_region . '.console.aws.amazon.com/sns/v3/home?region=' . $ses_region . '#/topics'); ?>" target="_blank" rel="noopener">AWS SNS → Topics</a>,
								<?php esc_html_e('click "Create topic", type Standard, and give it a name (e.g. "ses-notifications"). Paste its ARN in the "SNS Topic ARN" field above.', 'wp-news'); ?>
							</li>
							<li>
								<strong><?php esc_html_e('Add a Subscription', 'wp-news'); ?></strong> —
								<?php esc_html_e('Inside the topic, click "Create subscription". Protocol: HTTPS, Endpoint: the webhook URL above (including the ?key= parameter). Confirmation is automatic.', 'wp-news'); ?>
							</li>
							<li>
								<strong><?php esc_html_e('Connect it to SES', 'wp-news'); ?></strong> —
								<?php esc_html_e('Go to', 'wp-news'); ?>
								<a href="<?php echo esc_url('https://' . $ses_region . '.console.aws.amazon.com/ses/home?region=' . $ses_region . '#/identities'); ?>" target="_blank" rel="noopener">AWS SES → Identities</a>,
								<?php esc_html_e('select your identity, open the "Notifications" tab, click "Edit" and select the SNS topic for Delivery, Bounce and Complaint.', 'wp-news'); ?>
							</li>
						</ol>

						<div class="wpnews-mt-15">
							<button type="button" id="wpnews-check-sns" class="button button-secondary">
								<?php esc_html_e('Check SNS configuration', 'wp-news'); ?>
							</button>
							<span id="wpnews-sns-spinner" style="display:none;" class="wpnews-ml-8"><?php esc_html_e('Checking...', 'wp-news'); ?></span>
						</div>
						<div id="wpnews-sns-results" class="wpnews-sns-results" style="display:none;"></div>
					</div>
				</div>
			</div>

			<hr>

			<p class="wpnews-mt-20">
				<?php submit_button(__('Save Settings', 'wp-news'), 'primary button-large', 'submit', false); ?>
			</p>
		</form>
	</div>

	<!-- DIAGNOSTICS: connection tests + test email (does not save settings) -->
	<div class="wpnews-card wpnews-info-box wpnews-info-box--blue">
		<h3 class="wpnews-mb-4"><?php esc_html_e('Diagnostics', 'wp-news'); ?></h3>
		<p class="description wpnews-mb-16">
			<?php esc_html_e('These tests use the saved settings. Save your changes first, then run the tests.', 'wp-news'); ?>
		</p>
		<form method="post" action="">
			<?php wp_nonce_field('wpnews_settings_tests', 'wpnews_tests_nonce'); ?>
			<div class="wpnews-inline-field wpnews-mb-16">
				<button type="submit" name="wpnews_test_action" value="test_sendgrid" class="button button-secondary">
					<?php esc_html_e('Test SendGrid Connection', 'wp-news'); ?>
				</button>
				<button type="submit" name="wpnews_test_action" value="test_ses" class="button button-secondary">
					<?php esc_html_e('Test SES Connection', 'wp-news'); ?>
				</button>
			</div>
			<label for="test_email_to"><strong><?php esc_html_e('Send Test Email', 'wp-news'); ?></strong></label>
			<p class="description wpnews-mb-10">
				<?php esc_html_e('Send a real test email through the currently configured mailer to verify everything works end-to-end.', 'wp-news'); ?>
			</p>
			<div class="wpnews-inline-field">
				<input type="email" name="test_email_to" id="test_email_to"
					value="<?php echo esc_attr(get_option('admin_email')); ?>"
					placeholder="recipient@example.com" class="regular-text">
				<button type="submit" name="wpnews_test_action" value="send_test_email" class="button button-secondary">
					<?php esc_html_e('Send Test Email', 'wp-news'); ?>
				</button>
			</div>
		</form>
	</div>

	<!-- Plugin Version -->
	<div class="wpnews-version-bar">
		<strong>WP-News Newsletter</strong>
		<span class="wpnews-version-pill">v<?php echo esc_html(WPNEWS_VERSION); ?></span>
		<span class="wpnews-sep">|</span>
		<span>PHP <?php echo esc_html(PHP_MAJOR_VERSION . '.' . PHP_MINOR_VERSION); ?></span>
		<span class="wpnews-sep">|</span>
		<span>WordPress <?php echo esc_html(get_bloginfo('version')); ?></span>
	</div>
</div>
