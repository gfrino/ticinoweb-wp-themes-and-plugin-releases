<?php
/**
 * Plugin Name: WP-News Newsletter
 * Plugin URI: https://github.com/gfrino/wp-plugins
 * Description: Lightweight newsletter plugin with a drag-and-drop email builder, Amazon SES and SendGrid delivery, bounce/complaint webhooks, signed open/click tracking and advanced list management.
 * Version: 1.18.0
 * Requires at least: 6.2
 * Requires PHP: 8.0
 * Author: ticinoWEB
 * Author URI: https://ticinoweb.ch
 * License: GPL-2.0+
 * License URI: http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain: wp-news
 * Domain Path: /languages
 * Update URI: https://github.com/gfrino/ticinoweb-wp-themes-and-plugin-releases
 *
 * @package WPNews
 */

// If this file is called directly, abort.
if (!defined('WPINC')) {
	die;
}

/**
 * Current plugin version.
 */
define('WPNEWS_VERSION', '1.18.0');
define('WPNEWS_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('WPNEWS_PLUGIN_URL', plugin_dir_url(__FILE__));
define('WPNEWS_PLUGIN_FILE', __FILE__);
/*
 * Starter CSS for the signup form. The form itself ships unstyled; this is
 * shown (and used for the live preview) in Newsletter → Lists so it can be
 * copied into the site's Custom CSS and changed there.
 */
define('WPNEWS_STARTER_CSS', <<<'CSS'
.wpnews-subscribe-form .wpnews-form-fields {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 12px;
}
.wpnews-subscribe-form .wpnews-field-email,
.wpnews-subscribe-form .wpnews-field-submit {
  grid-column: 1 / -1;
}
.wpnews-subscribe-form .wpnews-label {
  display: block;
  margin-bottom: 6px;
  font-weight: 600;
}
.wpnews-subscribe-form .wpnews-form-input {
  width: 100%;
  height: 46px;
  padding: 0 14px;
  border: 1px solid #d1d5db;
  border-radius: 8px;
  background: #fff;
  font: inherit;
}
.wpnews-subscribe-form .wpnews-submit-btn {
  width: 100%;
  height: 46px;
  border: 0;
  border-radius: 8px;
  background: #4f46e5;
  color: #fff;
  font: inherit;
  font-weight: 600;
  cursor: pointer;
}
.wpnews-subscribe-form .wpnews-form-consent {
  margin-top: 12px;
  font-size: 0.9em;
}
.wpnews-subscribe-form .wpnews-message {
  margin-top: 12px;
  padding: 10px 14px;
}
.wpnews-subscribe-form .wpnews-message.success { background: #f0fdf4; color: #166534; }
.wpnews-subscribe-form .wpnews-message.error { background: #fef2f2; color: #991b1b; }
@media (max-width: 600px) {
  .wpnews-subscribe-form .wpnews-form-fields { grid-template-columns: 1fr; }
}
CSS
);

// Version of the bundled includes/tw-release-updater.php (keep in sync with its header).
define('WPNEWS_RELEASE_UPDATER_VERSION', '1.1.0');

/*
 * Updates from the ticinoWEB releases repo (see the Update URI header). The
 * bundled loader is generic and is also installed as a mu-plugin, so updates
 * work in Network Admin and the main site's cron too, where a per-site
 * activated plugin is not loaded. If the mu-plugin is already loaded this
 * include is a no-op.
 */
require_once WPNEWS_PLUGIN_DIR . 'includes/tw-release-updater.php';

/**
 * Install or upgrade the release updater mu-plugin from the bundled copy.
 *
 * Runs on activation and in admin when the mu-plugin is missing or older than
 * the bundled copy. A failure (mu-plugins not writable) is retried at most
 * every 12 hours; meanwhile the bundled copy still handles updates wherever
 * this plugin is loaded.
 */
function wpnews_install_release_updater()
{
	if (!class_exists('TW_Release_Updater') || TW_Release_Updater::mu_is_current(WPNEWS_RELEASE_UPDATER_VERSION)) {
		return;
	}
	if (get_site_transient('wpnews_release_updater_failed')) {
		return;
	}
	$result = TW_Release_Updater::install_mu(WPNEWS_PLUGIN_DIR . 'includes/tw-release-updater.php');
	if (is_wp_error($result)) {
		set_site_transient('wpnews_release_updater_failed', $result->get_error_message(), 12 * HOUR_IN_SECONDS);
	}
}

add_action('admin_init', function () {
	if (current_user_can(is_multisite() ? 'manage_network_plugins' : 'activate_plugins')) {
		wpnews_install_release_updater();
	}
}, 20);

/**
 * The code that runs during plugin activation.
 *
 * @param bool $network_wide True when activated network-wide on multisite.
 */
function activate_wpnews_plugin($network_wide = false)
{
	require_once WPNEWS_PLUGIN_DIR . 'includes/class-activator.php';
	WPNews_Activator::activate((bool) $network_wide);
	wpnews_install_release_updater();
}

/**
 * The code that runs during plugin deactivation.
 */
function deactivate_wpnews_plugin()
{
	require_once WPNEWS_PLUGIN_DIR . 'includes/class-deactivator.php';
	WPNews_Deactivator::deactivate();
}

register_activation_hook(__FILE__, 'activate_wpnews_plugin');
register_deactivation_hook(__FILE__, 'deactivate_wpnews_plugin');

/**
 * Multisite: set up tables/cron/secret on newly created sites when the
 * plugin is network-active.
 *
 * @param WP_Site $new_site The new site object.
 */
function wpnews_initialize_new_site($new_site)
{
	if (!is_multisite() || !($new_site instanceof WP_Site)) {
		return;
	}
	if (!function_exists('is_plugin_active_for_network')) {
		require_once ABSPATH . 'wp-admin/includes/plugin.php';
	}
	if (!is_plugin_active_for_network(plugin_basename(__FILE__))) {
		return;
	}

	require_once WPNEWS_PLUGIN_DIR . 'includes/class-activator.php';
	switch_to_blog((int) $new_site->blog_id);
	WPNews_Activator::activate_site();
	restore_current_blog();
}
add_action('wp_initialize_site', 'wpnews_initialize_new_site', 100);

/**
 * The core plugin class.
 */
require WPNEWS_PLUGIN_DIR . 'includes/class-plugin.php';

/**
 * Begins execution of the plugin.
 * DB version upgrade is handled by WPNews_Plugin::check_version(), hooked to admin_init.
 */
function run_wpnews_plugin()
{
	$plugin = new WPNews_Plugin();
	$plugin->run();
}

run_wpnews_plugin();
