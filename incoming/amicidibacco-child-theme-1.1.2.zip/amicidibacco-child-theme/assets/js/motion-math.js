/* Pure geometry shared by the homepage controller and its continuity tests. */
(function (root, factory) {
    if (typeof module === 'object' && module.exports) module.exports = factory();
    else root.ADBMotion = factory();
})(typeof window !== 'undefined' ? window : this, function () {
    'use strict';
    const clamp = value => Math.max(0, Math.min(1, value));
    const smooth = value => { const p=clamp(value); return p*p*(3-2*p); };
    return {
        orbitPoint(index, count, phase) {
            const angle=phase+index*Math.PI*2/Math.max(1,count);
            return {x:Math.cos(angle),y:Math.sin(angle)};
        },
        activeBottle(count, phase) {
            if (!count) return 0;
            return ((Math.round((Math.PI-phase)/(Math.PI*2/count))%count)+count)%count;
        },
        passage(top, height, y, viewport) { return clamp((y+viewport-top)/Math.max(1,height+viewport)); },
        // Conservative interior radius: an opaque text aperture must cover every viewport corner.
        inkAperture(rgba,width,height) {
            const distance=new Float32Array(width*height);
            for(let i=0;i<distance.length;i++)distance[i]=rgba[i*4+3]>=250?Math.max(width,height):0;
            for(let y=1;y<height-1;y++)for(let x=1;x<width-1;x++){
                const i=y*width+x;if(distance[i])distance[i]=Math.min(distance[i],1+Math.min(distance[i-1],distance[i-width],distance[i-width-1],distance[i-width+1]));
            }
            for(let y=height-2;y>0;y--)for(let x=width-2;x>0;x--){
                const i=y*width+x;if(distance[i])distance[i]=Math.min(distance[i],1+Math.min(distance[i+1],distance[i+width],distance[i+width-1],distance[i+width+1]));
            }
            let best={x:Math.floor(width/2),y:Math.floor(height/2),radius:0};
            for(let y=1;y<height-1;y++)for(let x=Math.floor(width*.25);x<width*.75;x++){
                const radius=Math.max(0,distance[y*width+x]-1)*.9;
                if(radius>best.radius)best={x,y,radius};
            }
            return best;
        },
        coverZoom(point,radius,width,height) {
            return Math.max(80,Math.hypot(Math.max(point.x,width-point.x),Math.max(point.y,height-point.y))/Math.max(.5,radius)*1.15);
        },
        portal(progress,maxZoom=80) {
            const p=clamp(progress);
            return {zoom:Math.exp(smooth(p/.84)*Math.log(maxZoom)),rise:smooth(p),introOpacity:smooth((p-.64)/.2),ink:1-smooth((p-.2)/.18),veil:smooth((p-.1)/.25),heroOpacity:1-smooth(p/.42)};
        },
        clamp,
    };
});
