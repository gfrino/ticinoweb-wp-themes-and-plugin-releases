<?php defined('ABSPATH') || exit; ?>
<footer class="gomes-footer"><div class="gomes-container">
    <div class="gomes-footer-grid">
        <div class="gomes-footer-brand">
            <a class="gomes-footer-logo" href="<?php echo esc_url(gomes_home()); ?>" aria-label="<?php echo esc_attr(get_bloginfo('name')); ?>">
                <?php $logo = function_exists('ticinoweb_get_site_logo') ? ticinoweb_get_site_logo() : ''; echo gomes_image($logo, 'medium', array('loading' => 'lazy', 'sizes' => '180px')) ?: esc_html(get_bloginfo('name')); ?>
            </a>

        </div>
        <nav class="gomes-footer-navigation" aria-label="<?php echo esc_attr(gomes_text(__('Esplora', 'gomes-gessatura'), 'footer-explore')); ?>">
            <h2><?php echo esc_html(gomes_text(__('Esplora', 'gomes-gessatura'), 'footer-explore')); ?></h2>
            <?php wp_nav_menu(array('theme_location' => 'primary', 'container' => false, 'fallback_cb' => false, 'depth' => 1, 'menu_id' => 'gomes-footer-navigation')); ?>
        </nav>
        <div class="gomes-footer-contact">
            <h2><?php echo esc_html(gomes_text(__('Contatti', 'gomes-gessatura'), 'footer-contact')); ?></h2>
            <a class="gomes-text-link" href="<?php echo esc_url(gomes_home() . '#contatti'); ?>"><?php echo esc_html(gomes_text(__('Contatti e orari', 'gomes-gessatura'), 'footer-contacts')); ?> <span aria-hidden="true">↗</span></a>
        </div>
    </div>
    <div class="gomes-footer-bottom"><p>© <?php echo esc_html(wp_date('Y') . ' ' . get_bloginfo('name')); ?></p>
        <?php wp_nav_menu(array('theme_location' => 'gomes_footer', 'container' => false, 'fallback_cb' => false, 'depth' => 1)); ?>
        <a class="gomes-footer-login" href="<?php echo esc_url(home_url('/tw-login/')); ?>"><?php echo esc_html(gomes_text(__('Zona riservata', 'gomes-gessatura'), 'footer-login')); ?><span aria-hidden="true"> ↗</span></a>
        <?php if (get_option('tw_cookie_banner_enable')) : ?><button type="button" data-cookie-preferences><?php echo esc_html(gomes_text(__('Preferenze cookie', 'gomes-gessatura'), 'cookies')); ?></button><?php endif; ?>
        <?php if (is_front_page()) : ?><button type="button" data-motion-toggle aria-pressed="false" hidden><?php echo esc_html(gomes_text(__('Riduci gli effetti', 'gomes-gessatura'), 'motion-reduce')); ?></button><?php endif; ?>
    </div>
<?php
$front_id = (int) get_option('page_on_front');
if ($front_id) {
    foreach (parse_blocks(get_post_field('post_content', $front_id)) as $block) {
        $anchor = $block['attrs']['anchor'] ?? '';
        if (!in_array($anchor, array('privacy', 'note-legali'), true)) { continue; }
        $label = $anchor === 'privacy' ? __('Informativa privacy', 'gomes-gessatura') : __('Note legali', 'gomes-gessatura');
        echo '<details class="gomes-legal" id="' . esc_attr($anchor) . '"><summary>' . esc_html(gomes_text($label, $anchor)) . '</summary>';
        // Anchor belongs to details, not also to its editable inner group.
        unset($block['attrs']['anchor']);
        $markup = serialize_block($block);
        $markup = str_replace(' id="' . $anchor . '"', '', $markup);
        echo apply_filters('the_content', $markup);
        echo '</details>';
    }
}
?>
</div></footer>
<?php if (!empty($contact['phone'])) : ?><a class="gomes-mobile-call" href="<?php echo esc_url(gomes_phone_href($contact['phone'])); ?>"><?php echo esc_html(gomes_text(__('Chiamaci per il tuo progetto', 'gomes-gessatura'), 'mobile-call')); ?><span aria-hidden="true"> ↗</span></a><?php endif; ?>
<?php wp_footer(); ?>
</body></html>
