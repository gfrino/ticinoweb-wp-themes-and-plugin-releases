<?php
/**
 * Studio Medico child theme — functions.
 *
 * Il parent (ticinoweb-ai-theme) fornisce CMS, SEO, sicurezza, email e il
 * gestore email. Qui vivono solo: asset, dati del sito letti dal CMS,
 * pannello "Studio medico", seeder dei contenuti e arricchimento SEO.
 *
 * @package Fratila_Blanc
 * @version 1.6.0
 */

if (!defined('ABSPATH')) {
    exit;
}

define('FRATILA_BLANC_VERSION', wp_get_theme()->get('Version'));

require_once get_stylesheet_directory() . '/inc/site-data.php';
require_once get_stylesheet_directory() . '/inc/admin-studio.php';
require_once get_stylesheet_directory() . '/inc/content-seed.php';
require_once get_stylesheet_directory() . '/inc/seo-schema.php';

/* ─────────────────────────────────────────────
   1. SETUP
   ───────────────────────────────────────────── */
add_action('after_setup_theme', 'fratila_blanc_setup');
function fratila_blanc_setup()
{
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('html5', array('search-form', 'comment-form', 'gallery', 'caption', 'style', 'script'));

    register_nav_menus(array(
        'primary' => __('Menu Principale', 'fratila-blanc'),
    ));
}

/* ─────────────────────────────────────────────
   2. ASSET
   ───────────────────────────────────────────── */
add_action('wp_enqueue_scripts', 'fratila_blanc_enqueue_assets', 20);
function fratila_blanc_enqueue_assets()
{
    $dir = get_stylesheet_directory();
    $uri = get_stylesheet_directory_uri();

    wp_enqueue_style(
        'fratila-blanc-fonts',
        'https://fonts.googleapis.com/css2?family=Figtree:wght@400;500;600;700&display=swap',
        array(),
        null
    );

    wp_enqueue_style(
        'fratila-blanc-style',
        $uri . '/assets/css/fratila-blanc.css',
        array('ticinoweb-ai-style', 'fratila-blanc-fonts'),
        (string) filemtime($dir . '/assets/css/fratila-blanc.css')
    );

    wp_enqueue_script(
        'fratila-blanc-main',
        $uri . '/assets/js/main.js',
        array(),
        (string) filemtime($dir . '/assets/js/main.js'),
        true
    );
}

/**
 * Tutti gli script del child in defer: sono in footer e non dipendono
 * dall'ordine di esecuzione con l'HTML.
 */
add_filter('script_loader_tag', 'fratila_blanc_defer_scripts', 10, 2);
function fratila_blanc_defer_scripts($tag, $handle)
{
    if (is_admin() || strpos($handle, 'fratila-blanc-') !== 0) {
        return $tag;
    }
    if (strpos($tag, ' defer') !== false || strpos($tag, ' async') !== false) {
        return $tag;
    }
    return str_replace(' src=', ' defer src=', $tag);
}

/**
 * Il parent carica Google Fonts "Poppins" come dipendenza del suo style.css;
 * il child non lo usa: si svuota l'URL senza rompere la catena di dipendenze.
 */
add_filter('style_loader_src', 'fratila_blanc_drop_unused_parent_font', 10, 2);
function fratila_blanc_drop_unused_parent_font($src, $handle)
{
    return $handle === 'poppins-font' ? '' : $src;
}

add_action('wp_head', 'fratila_blanc_preconnect', 1);
function fratila_blanc_preconnect()
{
    echo '<link rel="preconnect" href="https://fonts.googleapis.com">' . "\n";
    echo '<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>' . "\n";
    echo '<meta name="theme-color" content="#14607a">' . "\n";
}

/* ─────────────────────────────────────────────
   3. LINGUA / VARIE
   ───────────────────────────────────────────── */
add_filter('language_attributes', 'fratila_blanc_language_attributes');
function fratila_blanc_language_attributes($output)
{
    return preg_replace('/lang="it(-[A-Za-z]+)?"/', 'lang="it-CH"', $output);
}

add_filter('body_class', 'fratila_blanc_body_class');
function fratila_blanc_body_class($classes)
{
    $classes[] = 'fb-body';
    return $classes;
}

/**
 * Stampa la lista degli orari settimanali letti dal CMS del parent.
 * Raggruppa i giorni consecutivi con lo stesso orario (Lun–Ven 08:00 – 16:30).
 *
 * @return array<int, array{days:string, hours:string, slots:array, closed:bool, iso:array}>
 */
function fratila_blanc_grouped_hours()
{
    $hours = get_option('ticinoweb_contact_opening_hours', array());
    if (!is_array($hours) || empty($hours)) {
        return array();
    }
    $labels = array(
        'monday'    => __('Lun', 'fratila-blanc'),
        'tuesday'   => __('Mar', 'fratila-blanc'),
        'wednesday' => __('Mer', 'fratila-blanc'),
        'thursday'  => __('Gio', 'fratila-blanc'),
        'friday'    => __('Ven', 'fratila-blanc'),
        'saturday'  => __('Sab', 'fratila-blanc'),
        'sunday'    => __('Dom', 'fratila-blanc'),
    );
    $iso    = array('monday' => 1, 'tuesday' => 2, 'wednesday' => 3, 'thursday' => 4, 'friday' => 5, 'saturday' => 6, 'sunday' => 7);
    $groups = array();
    foreach ($labels as $key => $label) {
        if (!isset($hours[$key])) {
            continue;
        }
        $text = function_exists('ticinoweb_format_day_hours') ? ticinoweb_format_day_hours($hours[$key], "\n") : '';
        if ($text === '') {
            continue;
        }
        $last = count($groups) - 1;
        if ($last >= 0 && $groups[$last]['text'] === $text) {
            $groups[$last]['end'] = $label;
            $groups[$last]['iso'][] = $iso[$key];
        } else {
            $groups[] = array(
                'start'  => $label,
                'end'    => $label,
                'text'   => $text,
                'closed' => !empty($hours[$key]['closed']),
                'iso'    => array($iso[$key]),
            );
        }
    }
    $out = array();
    foreach ($groups as $g) {
        $slots = array_values(array_filter(array_map('trim', explode("\n", $g['text']))));
        $out[] = array(
            'days'   => $g['start'] === $g['end'] ? $g['start'] : $g['start'] . ' – ' . $g['end'],
            'hours'  => implode(', ', $slots),
            'slots'  => $slots,
            'closed' => $g['closed'],
            'iso'    => $g['iso'],
        );
    }
    return $out;
}

/**
 * Orari settimanali come tabella leggibile: una riga per gruppo di giorni
 * uguali, una fascia oraria per riga, giorni di chiusura attenuati.
 * Il giorno corrente viene evidenziato da main.js. Output già escapato.
 *
 * @param array<int, array{days:string, hours:string, slots:array, closed:bool, iso:array}> $rows
 */
function fratila_blanc_hours_html($rows)
{
    if (empty($rows)) {
        return '';
    }
    $html = '<ul class="fb-hours">';
    foreach ($rows as $row) {
        $html .= '<li class="fb-hours__row' . (!empty($row['closed']) ? ' is-closed' : '') . '" data-days="' . esc_attr(implode(',', $row['iso'])) . '">';
        $html .= '<span class="fb-hours__days">' . esc_html($row['days']) . '</span>';
        $html .= '<span class="fb-hours__times">';
        foreach ($row['slots'] as $slot) {
            $html .= '<span class="fb-hours__slot">' . esc_html($slot) . '</span>';
        }
        $html .= '</span></li>';
    }
    return $html . '</ul>';
}

/**
 * Iniziali per l'avatar di un medico ("Dott. Mario Rossi" → "MR").
 * Ignora i titoli (Dott., Dr., Dott.ssa, Prof.) e usa al massimo due lettere.
 */
function fratila_blanc_initials($name)
{
    $name  = preg_replace('/\b(dott\.?(ssa)?|dr\.?(ssa)?|prof\.?(ssa)?|med\.?)\s*/iu', '', (string) $name);
    $parts = preg_split('/[\s\-]+/u', trim($name), -1, PREG_SPLIT_NO_EMPTY);
    if (empty($parts)) {
        return '';
    }
    $first = mb_substr($parts[0], 0, 1);
    $last  = count($parts) > 1 ? mb_substr(end($parts), 0, 1) : '';
    return mb_strtoupper($first . $last);
}

/**
 * Titolo su più righe: nel pannello il carattere "|" indica l'a capo
 * ("Studio medico | Rossi"). Output già escapato.
 */
function fratila_blanc_title_html($title)
{
    $lines = array_filter(array_map('trim', explode('|', (string) $title)), 'strlen');
    return implode('<br>', array_map('esc_html', $lines));
}

/**
 * Indirizzo su due righe pulite: via, poi CAP e località. Output già escapato.
 * "Via Esempio 1, 6500 Bellinzona" → "Via Esempio 1<br>6500 Bellinzona".
 */
function fratila_blanc_address_html($address)
{
    $address = trim((string) $address);
    if (preg_match('/^(.*?),\s*(\d{4}\s+.+)$/u', $address, $m)) {
        return esc_html($m[1]) . '<br>' . esc_html($m[2]);
    }
    return esc_html($address);
}

/**
 * Attributo href per i link telefonici: solo cifre e "+".
 */
function fratila_blanc_tel_href($phone)
{
    return 'tel:' . preg_replace('/[^0-9+]/', '', (string) $phone);
}
