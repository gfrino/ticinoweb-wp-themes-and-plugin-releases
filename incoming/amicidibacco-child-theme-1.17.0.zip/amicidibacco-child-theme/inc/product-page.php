<?php
/**
 * Product editorial presentation; commerce remains entirely WooCommerce native.
 *
 * THESIS: A bottle to discover, with the purchase immediately beside it.
 * OWN-WORLD: Existing ivory paper, burgundy ink, Cormorant and Manrope; open
 * compositions, measured rules, an unboxed bottle and a dark tasting passage.
 * STORY: Identify the bottle, buy, then explore its story, character and origin.
 * FIRST VIEWPORT: Native gallery left, product identity and native cart right.
 * FORM: Approved editorial product composition extending the site's identity.
 */
defined( 'ABSPATH' ) || exit;

/** Install presentation hooks only after the main product query is available. */
function adb_product_page_setup() {
    if ( ! function_exists( 'is_product' ) || ! is_product() ) { return; }
    add_filter( 'body_class', 'adb_product_page_body_class' );
    add_action( 'woocommerce_before_single_product_summary', 'adb_product_stage_open', 1 );
    add_action( 'woocommerce_after_single_product_summary', 'adb_product_stage_close', 1 );
    add_action( 'woocommerce_single_product_summary', 'adb_product_identity', 4 );
    remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_excerpt', 20 );
    remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_price', 10 );
    add_action( 'woocommerce_single_product_summary', 'adb_product_introduction', 15 );
    add_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_price', 20 );
    add_action( 'woocommerce_single_product_summary', 'adb_product_quick_facts', 25 );
    remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_meta', 40 );
    add_action( 'woocommerce_after_single_product_summary', 'adb_product_editorial', 5 );
    add_filter( 'woocommerce_product_tabs', 'adb_product_editorial_tabs', 100 );
    add_filter( 'woocommerce_product_single_add_to_cart_text', 'adb_product_cart_label' );
}
add_action( 'wp', 'adb_product_page_setup', 30 );

function adb_product_cart_label( $label ) { return __( 'Aggiungi al carrello', 'amicidibacco' ); }

function adb_product_page_body_class( $classes ) {
    $classes[] = 'adb-product-page';
    if ( has_term( array( 'le-selezioni', 'le-selezioni-grappa' ), 'product_cat', get_queried_object_id() ) ) { $classes[] = 'adb-product-page--selection'; }
    return $classes;
}
function adb_product_stage_open() { echo '<div class="adb-product-stage">'; }
function adb_product_stage_close() { echo '</div>'; }

/** Read existing per-product content, never create or infer a factual value. */
function adb_product_editorial_field( $product_id, $keys ) {
    foreach ( (array) $keys as $key ) {
        $value = function_exists( 'adb_product_field_value' ) ? adb_product_field_value( $product_id, $key ) : get_post_meta( $product_id, $key, true );
        if ( is_scalar( $value ) && '' !== trim( wp_strip_all_tags( (string) $value ) ) ) { return (string) $value; }
    }
    return '';
}

/** A producer is linked by the recorded cantina taxonomy ID, never its name. */
function adb_product_linked_producer( $product ) {
    $ids = wc_get_product_terms( $product->get_id(), 'pa_cantina', array( 'fields' => 'ids' ) );
    if ( ! $ids || is_wp_error( $ids ) ) { return null; }
    $posts = get_posts( array(
        'post_type' => 'produttore', 'post_status' => 'publish', 'posts_per_page' => 1,
        'no_found_rows' => true, 'suppress_filters' => false, 'adb_language' => 'it',
        'orderby' => 'title', 'order' => 'ASC',
        'meta_query' => array( array( 'key' => 'cantina', 'value' => array_map( 'absint', $ids ), 'compare' => 'IN', 'type' => 'NUMERIC' ) ),
    ) );
    return $posts ? $posts[0] : null;
}

/** Collect once; navigation and sections always agree, including sparse products. */
function adb_product_editorial_data( $product ) {
    static $cache = array();
    $cache_key = get_current_blog_id() . ':' . $product->get_id();
    if ( isset( $cache[ $cache_key ] ) ) { return $cache[ $cache_key ]; }
    $id = $product->get_id();
    $field = static function ( $keys ) use ( $id ) { return adb_product_editorial_field( $id, $keys ); };
    $tasting = function_exists( 'adb_tasting_data' ) ? adb_tasting_data( $id ) : array();
    $tasting = is_array( $tasting ) ? $tasting : array();
    $selection = array();
    foreach ( array( '', '_grappa' ) as $suffix ) {
        for ( $number = 1; $number <= ( $suffix ? 2 : 3 ); $number++ ) {
            $value = $field( 'descrizione_' . $number . $suffix );
            if ( $value ) {
                $selection[] = array( 'title' => $field( 'etichetta_descrizione_' . $number . $suffix ), 'value' => $value );
            }
        }
    }
    // A collection has no single sensorial profile; never average its bottles.
    $kind = sanitize_title( $field( 'tipo_di_prodotto' ) );
    $is_selection = $selection || false !== strpos( $kind, 'selezion' ) || has_term( array( 'le-selezioni', 'le-selezioni-grappa' ), 'product_cat', $id );
    if ( $is_selection ) {
        $tasting['scores'] = array();
        $tasting['aromas'] = array();
        $tasting['finish'] = '';
    }
    $narrative = (string) $product->get_description();
    if ( '' === trim( $narrative ) ) { $narrative = (string) $product->get_short_description(); }
    $technical = array();
    $keys = array( 'vitigno', 'vinificazione', 'gradazione_alcolica', 'vitigni_disponibili:', 'provenienza_vinaccia:', 'sistema_di_distillazione:', 'periodo_di_distillazione:', 'tipologia_di_invecchiamento:', 'grado_alcolico:', 'stilebirra', 'ingredientibirra', 'gradazione_alcolicabirre' );
    $labels = adb_product_fields();
    foreach ( $keys as $key ) {
        $value = $field( $key );
        if ( $value ) { $technical[] = array( 'label' => $labels[ $key ], 'value' => $value ); }
    }
    $data = array(
        'story' => $narrative, 'selection' => $selection, 'tasting' => $tasting,
        'color' => $is_selection ? '' : $field( array( 'colore', 'colore:', 'colorebirre' ) ),
        'nose' => $is_selection ? '' : $field( array( 'al_naso', 'profumo:', 'al_nasobirre' ) ),
        'palate' => $is_selection ? '' : $field( array( 'al_palato', 'sapore:', 'al_palatobirre' ) ),
        'serving' => $field( array( 'temperatura_di_servizio', 'temperatura_di_serviziobirre' ) ),
        'pairing' => $field( 'abbinamenti_gastronomici' ),
        'technical' => $technical, 'producer' => adb_product_linked_producer( $product ),
    );
    $data['has_tasting'] = $data['color'] || $data['nose'] || $data['palate'] || ! empty( $tasting['aromas'] ) || ! empty( $tasting['finish'] ) || count( array_filter( $tasting['scores'] ?? array(), static function ( $score ) { return is_numeric( $score ) && $score >= 1 && $score <= 5; } ) );
    $cache[ $cache_key ] = $data;
    return $data;
}

function adb_product_identity() {
    global $product;
    if ( ! $product instanceof WC_Product ) { return; }
    $denomination = adb_product_editorial_field( $product->get_id(), 'etichetta' );
    $winery = $product->get_attribute( 'pa_cantina' );
    if ( ! $denomination && ! $winery ) { return; }
    echo '<div class="adb-product-identity">';
    if ( $winery ) { echo '<span>' . esc_html( $winery ) . '</span>'; }
    if ( $denomination ) { echo '<span>' . esc_html( $denomination ) . '</span>'; }
    echo '</div>';
}

function adb_product_introduction() {
    global $product;
    if ( ! $product instanceof WC_Product ) { return; }
    $intro = trim( (string) $product->get_short_description() );
    if ( '' === $intro ) { $intro = adb_product_editorial_field( $product->get_id(), 'descrizione_etichetta' ); }
    if ( '' === $intro ) { return; }
    // Legacy imports occasionally store the complete technical sheet as excerpt.
    if ( str_word_count( wp_strip_all_tags( $intro ) ) > 80 || preg_match( '/<(?:table|h[1-6]|dl)\b/i', $intro ) ) {
        $intro = wp_trim_words( wp_strip_all_tags( $intro ), 48 );
    }
    echo '<div class="adb-product-introduction">' . wp_kses_post( wpautop( $intro ) ) . '</div>';
}

function adb_product_quick_facts() {
    global $product;
    if ( ! $product instanceof WC_Product ) { return; }
    $years = array();
    if ( $product->is_type( 'variable' ) ) {
        foreach ( $product->get_variation_attributes()['pa_anno'] ?? array() as $slug ) {
            $term = get_term_by( 'slug', $slug, 'pa_anno' );
            if ( $term ) { $years[] = $term->name; }
        }
    } elseif ( $product->get_attribute( 'pa_anno' ) ) { $years[] = $product->get_attribute( 'pa_anno' ); }
    $years = array_values( array_unique( $years ) );
    $facts = array(
        _n( 'Annata', 'Annate', count( $years ), 'amicidibacco' ) => implode( ', ', $years ),
        __( 'Provenienza', 'amicidibacco' ) => implode( ', ', array_filter( array( $product->get_attribute( 'pa_regione' ), $product->get_attribute( 'pa_nazione' ) ) ) ),
    );
    $facts = array_filter( $facts );
    if ( ! $facts ) { return; }
    echo '<dl class="adb-product-quick-facts">';
    foreach ( $facts as $label => $value ) { echo '<div><dt>' . esc_html( $label ) . '</dt><dd>' . esc_html( $value ) . '</dd></div>'; }
    echo '</dl>';
}

/** Description and custom technical tab are replaced; native reviews/attributes remain. */
function adb_product_editorial_tabs( $tabs ) {
    unset( $tabs['description'], $tabs['adb_technical'] );
    return $tabs;
}

function adb_product_editorial() {
    global $product;
    if ( ! $product instanceof WC_Product ) { return; }
    $data = adb_product_editorial_data( $product );
    $sections = array();
    if ( trim( $data['story'] ) || $data['selection'] ) { $sections['adb-product-story'] = __( 'Il racconto', 'amicidibacco' ); }
    if ( $data['has_tasting'] ) { $sections['adb-product-tasting'] = __( 'Nel calice', 'amicidibacco' ); }
    if ( $data['serving'] || $data['pairing'] ) { $sections['adb-product-serving'] = __( 'A tavola', 'amicidibacco' ); }
    if ( $data['technical'] ) { $sections['adb-product-details'] = __( 'Scheda tecnica', 'amicidibacco' ); }
    if ( $data['producer'] ) { $sections['adb-product-producer'] = __( 'Il produttore', 'amicidibacco' ); }
    ?>
    <div class="adb-product-editorial">
        <?php if ( count( $sections ) > 1 ) : ?>
        <nav class="adb-product-index" aria-label="<?php esc_attr_e( 'Scopri il prodotto', 'amicidibacco' ); ?>">
            <?php foreach ( $sections as $anchor => $label ) : ?><a href="#<?php echo esc_attr( $anchor ); ?>"><?php echo esc_html( $label ); ?> <?php echo adb_icon( 'down' ); ?></a><?php endforeach; ?>
        </nav>
        <?php endif; ?>
        <?php if ( isset( $sections['adb-product-story'] ) ) : ?>
        <section id="adb-product-story" class="adb-product-story adb-product-section" aria-labelledby="adb-product-story-title">
            <h2 id="adb-product-story-title"><?php esc_html_e( 'Il racconto', 'amicidibacco' ); ?></h2>
            <div class="adb-product-story__body">
                <?php if ( trim( $data['story'] ) ) : ?><div class="adb-product-prose"><?php echo wp_kses_post( apply_filters( 'the_content', $data['story'] ) ); ?></div><?php endif; ?>
                <?php if ( $data['selection'] ) : ?>
                <div class="adb-product-selection">
                    <h3><?php esc_html_e( 'Nella selezione', 'amicidibacco' ); ?></h3>
                    <?php foreach ( $data['selection'] as $item ) : ?><div><?php if ( $item['title'] ) : ?><h4><?php echo esc_html( $item['title'] ); ?></h4><?php endif; ?><?php echo wp_kses_post( wpautop( $item['value'] ) ); ?></div><?php endforeach; ?>
                </div>
                <?php endif; ?>
            </div>
        </section>
        <?php endif; ?>
        <?php if ( $data['has_tasting'] ) { adb_product_tasting_section( $data ); } ?>
        <?php if ( isset( $sections['adb-product-serving'] ) ) : ?>
        <section id="adb-product-serving" class="adb-product-serving adb-product-section" aria-labelledby="adb-product-serving-title">
            <h2 id="adb-product-serving-title"><?php esc_html_e( 'A tavola', 'amicidibacco' ); ?></h2>
            <div class="adb-product-serving__body">
                <?php if ( $data['serving'] ) : ?><div class="adb-product-temperature"><h3><?php esc_html_e( 'Temperatura di servizio', 'amicidibacco' ); ?></h3><div><?php echo wp_kses_post( wpautop( $data['serving'] ) ); ?></div></div><?php endif; ?>
                <?php if ( $data['pairing'] ) : ?><div class="adb-product-pairing"><h3><?php esc_html_e( 'Gli abbinamenti', 'amicidibacco' ); ?></h3><?php echo wp_kses_post( wpautop( $data['pairing'] ) ); ?></div><?php endif; ?>
            </div>
        </section>
        <?php endif; ?>
        <?php if ( $data['technical'] ) : ?>
        <section id="adb-product-details" class="adb-product-details adb-product-section" aria-labelledby="adb-product-details-title">
            <h2 id="adb-product-details-title"><?php esc_html_e( 'Scheda tecnica', 'amicidibacco' ); ?></h2>
            <dl class="adb-product-specifications"><?php foreach ( $data['technical'] as $row ) : ?><div><dt><?php echo esc_html( $row['label'] ); ?></dt><dd><?php echo wp_kses_post( wpautop( $row['value'] ) ); ?></dd></div><?php endforeach; ?></dl>
        </section>
        <?php endif; ?>
        <?php if ( $data['producer'] ) { adb_product_producer_section( $data['producer'] ); } ?>
        <div class="adb-product-native-meta"><?php woocommerce_template_single_meta(); ?></div>
    </div>
    <?php
}

function adb_product_tasting_section( $data ) {
    $tasting = $data['tasting'];
    $aromas = array_filter( (array) ( $tasting['aromas'] ?? array() ), 'is_string' );
    $axes = function_exists( 'adb_tasting_axes' ) ? adb_tasting_axes() : array();
    $scores = array_filter( (array) ( $tasting['scores'] ?? array() ), static function ( $score ) { return is_numeric( $score ) && $score >= 1 && $score <= 5; } );
    ?>
    <section id="adb-product-tasting" class="adb-product-tasting" aria-labelledby="adb-product-tasting-title" data-product-reveal>
        <header class="adb-product-tasting__heading"><h2 id="adb-product-tasting-title"><?php esc_html_e( 'Nel calice', 'amicidibacco' ); ?></h2><?php if ( $data['color'] ) : ?><div class="adb-product-color"><h3><?php esc_html_e( 'Il colore', 'amicidibacco' ); ?></h3><?php echo wp_kses_post( wpautop( $data['color'] ) ); ?></div><?php endif; ?></header>
        <div class="adb-product-tasting__body">
            <?php if ( $aromas ) : ?><div class="adb-product-aromas"><h3><?php esc_html_e( 'Le note aromatiche', 'amicidibacco' ); ?></h3><ul><?php foreach ( $aromas as $aroma ) : ?><li><?php echo esc_html( $aroma ); ?></li><?php endforeach; ?></ul></div><?php endif; ?>
            <?php if ( $data['nose'] || $data['palate'] || ! empty( $tasting['finish'] ) ) : ?>
            <dl class="adb-product-senses">
                <?php if ( $data['nose'] ) : ?><div><dt><?php esc_html_e( 'Al naso', 'amicidibacco' ); ?></dt><dd><?php echo wp_kses_post( wpautop( $data['nose'] ) ); ?></dd></div><?php endif; ?>
                <?php if ( $data['palate'] ) : ?><div><dt><?php esc_html_e( 'Al palato', 'amicidibacco' ); ?></dt><dd><?php echo wp_kses_post( wpautop( $data['palate'] ) ); ?></dd></div><?php endif; ?>
                <?php if ( ! empty( $tasting['finish'] ) && is_string( $tasting['finish'] ) ) : ?><div><dt><?php esc_html_e( 'Il finale', 'amicidibacco' ); ?></dt><dd><?php echo wp_kses_post( wpautop( $tasting['finish'] ) ); ?></dd></div><?php endif; ?>
            </dl>
            <?php endif; ?>
            <?php if ( $scores && $axes ) : ?>
            <div class="adb-product-profile"><h3><?php esc_html_e( 'Il carattere', 'amicidibacco' ); ?></h3><p class="adb-product-profile__note"><?php if ( 'editorial' === ( $tasting['score_method'] ?? '' ) ) { esc_html_e( 'Profilo stilistico indicativo: stime editoriali da 1 a 5 basate sulle caratteristiche del vino. Descrive lo stile, non è un voto di qualità.', 'amicidibacco' ); } else { esc_html_e( 'Intensità da 1 a 5: descrive lo stile, non la qualità.', 'amicidibacco' ); } ?></p><dl>
                <?php foreach ( $axes as $key => $axis ) : if ( ! isset( $scores[ $key ] ) ) { continue; } $score = (int) $scores[ $key ]; ?>
                <div class="adb-product-axis"><dt><?php echo esc_html( $axis['label'] ); ?></dt><dd><span class="adb-product-axis__value"><?php echo esc_html( sprintf( __( '%d su 5', 'amicidibacco' ), $score ) ); ?></span><span class="adb-product-axis__segments" aria-hidden="true"><?php for ( $segment = 1; $segment <= 5; $segment++ ) : ?><i<?php echo $segment <= $score ? ' class="is-filled"' : ''; ?>></i><?php endfor; ?></span><span class="adb-product-axis__ends" aria-hidden="true"><span><?php echo esc_html( $axis['low'] ); ?></span><span><?php echo esc_html( $axis['high'] ); ?></span></span></dd></div>
                <?php endforeach; ?>
            </dl></div>
            <?php endif; ?>
            <?php adb_product_tasting_sources( $tasting ); ?>
        </div>
    </section>
    <?php
}

function adb_product_tasting_sources( $tasting ) {
    $sources = array_filter( (array) ( $tasting['sources'] ?? array() ), static function ( $source ) { return is_array( $source ) && ! empty( $source['url'] ) && ! empty( $source['title'] ) && esc_url( $source['url'] ); } );
    if ( ! $sources ) { return; }
    ?>
    <details class="adb-product-sources"><summary><?php esc_html_e( 'Fonti e annata di riferimento', 'amicidibacco' ); ?></summary>
        <?php if ( ! empty( $tasting['reference_vintage'] ) && is_scalar( $tasting['reference_vintage'] ) ) : ?><p><?php echo esc_html( sprintf( __( 'Annata di riferimento: %s', 'amicidibacco' ), $tasting['reference_vintage'] ) ); ?></p><?php endif; ?>
        <ul><?php foreach ( $sources as $source ) : ?><li><a href="<?php echo esc_url( $source['url'] ); ?>" rel="external nofollow"><?php echo esc_html( $source['title'] ); ?></a><?php if ( ! empty( $source['vintage'] ) && is_scalar( $source['vintage'] ) ) : ?><span> · <?php echo esc_html( sprintf( __( 'Annata %s', 'amicidibacco' ), $source['vintage'] ) ); ?></span><?php endif; ?></li><?php endforeach; ?></ul>
    </details>
    <?php
}

function adb_product_producer_section( $producer ) {
    $image = absint( get_post_meta( $producer->ID, 'immagine_di_sfondo_sulla_pagina_del_produttore', true ) ) ?: get_post_thumbnail_id( $producer->ID );
    $excerpt = $producer->post_excerpt ?: wp_trim_words( wp_strip_all_tags( strip_shortcodes( $producer->post_content ) ), 38 );
    ?>
    <section id="adb-product-producer" class="adb-product-producer<?php echo $image ? ' adb-product-producer--with-photo' : ''; ?>" aria-labelledby="adb-product-producer-title">
        <?php if ( $image ) : ?><a class="adb-product-producer__photo" href="<?php echo esc_url( get_permalink( $producer ) ); ?>" tabindex="-1" aria-hidden="true"><?php adb_photo( $image, 'large', array( 'loading' => 'lazy', 'alt' => '' ) ); ?></a><?php endif; ?>
        <div class="adb-product-producer__body"><p class="adb-kicker"><?php esc_html_e( 'Il produttore', 'amicidibacco' ); ?></p><h2 id="adb-product-producer-title"><?php echo esc_html( get_the_title( $producer ) ); ?></h2><?php if ( $excerpt ) : ?><p><?php echo esc_html( wp_strip_all_tags( $excerpt ) ); ?></p><?php endif; ?><a class="adb-link" href="<?php echo esc_url( get_permalink( $producer ) ); ?>"><?php esc_html_e( 'Scopri la cantina', 'amicidibacco' ); ?> <?php echo adb_icon(); ?></a></div>
    </section>
    <?php
}
