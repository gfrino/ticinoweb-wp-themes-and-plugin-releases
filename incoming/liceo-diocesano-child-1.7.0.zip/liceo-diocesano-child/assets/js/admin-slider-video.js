( function ( $ ) {
    var cfg = window.liceoHero || { i18n: {} };
    var t = cfg.i18n;

    $( function () {
        var $count = $( '#ticinoweb_slider_count' );
        if ( ! $count.length ) {
            return;
        }
        var $table = $count.closest( 'table' );
        var $box = $(
            '<tr class="ld-hero-mode-row"><th scope="row"><label></label></th><td>' +
            '<label style="margin-right:1.5rem"><input type="radio" name="ld_hero_mode" value="slider"> <span class="ld-m-slider"></span></label>' +
            '<label><input type="radio" name="ld_hero_mode" value="video"> <span class="ld-m-video"></span></label>' +
            '<div class="ld-video-panel" style="margin-top:12px">' +
            '<strong class="ld-m-file"></strong><br>' +
            '<input type="text" class="regular-text ld-video-url" name="ld_hero_video" readonly> ' +
            '<button type="button" class="button button-secondary ld-video-choose"></button> ' +
            '<button type="button" class="button-link-delete ld-video-remove"></button>' +
            '<p class="description ld-video-status"></p><p class="description ld-video-hint"></p>' +
            '<div class="ld-overlay-panel" style="margin-top:14px;padding:12px 14px;border:1px solid #dcdcde;border-radius:8px;max-width:720px">' +
            '<strong class="ld-ov-title"></strong>' +
            '<p style="margin:10px 0 0"><label class="ld-ov-color-l"></label> <input type="color" name="ld_hero_overlay_color" class="ld-ov-color"></p>' +
            '<p style="margin:10px 0 0"><label class="ld-ov-op-l"></label> <input type="range" min="0" max="90" step="5" name="ld_hero_overlay_opacity" class="ld-ov-op"> <output class="ld-ov-out"></output>%</p>' +
            '<p style="margin:10px 0 0"><label class="ld-ov-st-l"></label> <select name="ld_hero_overlay_style" class="ld-ov-style"><option value="gradient"></option><option value="flat"></option></select></p>' +
            '<div class="ld-ov-prev" style="margin-top:12px;height:120px;border-radius:12px;display:flex;align-items:flex-end;padding:14px;color:#fff;font-size:20px;font-weight:600;background:#8a7b6c url(\'\') center/cover"></div>' +
            '</div></div></td></tr>'
        );
        $box.find( 'th label' ).text( t.modeLabel );
        $box.find( '.ld-m-slider' ).text( t.slider );
        $box.find( '.ld-m-video' ).text( t.video );
        $box.find( '.ld-m-file' ).text( t.file );
        $box.find( '.ld-video-choose' ).text( t.choose );
        $box.find( '.ld-video-remove' ).text( t.remove );
        $box.find( '.ld-video-hint' ).text( t.hint );
        $box.find( '.ld-video-url' ).val( cfg.video || '' );
        var ov = cfg.overlay || {};
        $box.find( '.ld-ov-title' ).text( t.overlayTitle );
        $box.find( '.ld-ov-color-l' ).text( t.ovColor );
        $box.find( '.ld-ov-op-l' ).text( t.ovOpacity );
        $box.find( '.ld-ov-st-l' ).text( t.ovStyle );
        $box.find( '.ld-ov-style option[value="gradient"]' ).text( t.ovGradient );
        $box.find( '.ld-ov-style option[value="flat"]' ).text( t.ovFlat );
        $box.find( '.ld-ov-color' ).val( ov.color || '#281c14' );
        $box.find( '.ld-ov-op' ).val( ov.opacity );
        $box.find( '.ld-ov-style' ).val( ov.style || 'gradient' );
        $box.find( '.ld-ov-prev' ).text( t.ovPreview );
        function paint() {
            var hex = $box.find( '.ld-ov-color' ).val().replace( '#', '' );
            var rgb = [ 0, 2, 4 ].map( function ( i ) { return parseInt( hex.substr( i, 2 ), 16 ); } ).join( ',' );
            var a = parseInt( $box.find( '.ld-ov-op' ).val(), 10 ) / 100;
            $box.find( '.ld-ov-out' ).text( Math.round( a * 100 ) );
            var bg = $box.find( '.ld-ov-style' ).val() === 'flat'
                ? 'rgba(' + rgb + ',' + a + ')'
                : 'linear-gradient(180deg, rgba(' + rgb + ',' + ( a * 0.2 ) + ') 0%, rgba(' + rgb + ',' + a + ') 100%)';
            var $p = $box.find( '.ld-ov-prev' );
            var src = $( '#slider-items-container .slider-image-url' ).first().val();
            $p.css( 'background', bg + ( src ? ', url("' + src + '") center/cover' : ', #8a7b6c' ) );
        }
        $box.on( 'input change', '.ld-ov-color, .ld-ov-op, .ld-ov-style', paint );
        paint();
        $box.find( 'input[name="ld_hero_mode"][value="' + ( cfg.mode === 'video' ? 'video' : 'slider' ) + '"]' ).prop( 'checked', true );
        $table.find( 'tr' ).first().before( $box );

        function refresh() {
            var video = $box.find( 'input[name="ld_hero_mode"]:checked' ).val() === 'video';
            var v = $box.find( '.ld-video-url' ).val();
            $box.find( '.ld-video-panel' ).toggle( video );
            $box.find( '.ld-video-remove' ).toggle( !! v );
            $box.find( '.ld-video-status' ).text( v ? v.split( '/' ).pop() : t.none );
            // In modalità video conta solo la Slide 1: le altre e il numero di slide si nascondono.
            $count.closest( 'tr' ).toggle( ! video );
            $( '#slider-items-container .slider-item' ).each( function ( i ) {
                var $it = $( this );
                $it.toggle( ! video || i === 0 );
                if ( i === 0 ) {
                    // In modalità video non è una "slide": si chiama "Testi della testata" e non si sposta.
                    $it.find( '.slider-item-number' ).text( video ? t.textsTitle : 'Slide 1' );
                    $it.find( '.slider-move-up, .slider-move-down, .slider-drag-handle, .dashicons-move' ).toggle( ! video );
                }
            } );
            paint();
        }

        $box.on( 'change', 'input[name="ld_hero_mode"]', refresh );
        $box.on( 'click', '.ld-video-choose', function () {
            var frame = wp.media( { title: t.title, library: { type: 'video' }, multiple: false } );
            frame.on( 'select', function () {
                $box.find( '.ld-video-url' ).val( frame.state().get( 'selection' ).first().toJSON().url );
                refresh();
            } );
            frame.open();
        } );
        $box.on( 'click', '.ld-video-remove', function () {
            $box.find( '.ld-video-url' ).val( '' );
            refresh();
        } );
        refresh();
    } );
} )( jQuery );
