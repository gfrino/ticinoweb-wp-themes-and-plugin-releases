( function () {
    var root = document.getElementById( 'ld-programmi' );
    var cfg = window.ldProgrammi;
    if ( ! root || ! cfg || ! cfg.list || ! cfg.list.length ) {
        return;
    }

    var LIST = cfg.list;
    var ROMAN = [ '', 'I', 'II', 'III', 'IV' ];
    var GROUPS = {
        fond: { label: 'Materie fondamentali', text: 'Le discipline fondamentali del piano di studi.' },
        os: { label: 'Opzione specifica (OS)', text: 'È la scelta curricolare più importante: con l’opzione specifica ogni studente sceglie il proprio indirizzo formativo.' },
        oc: { label: 'Opzione complementare (OC)', text: 'Si affianca all’opzione specifica e al lavoro di maturità, per approfondire un’altra materia.' }
    };
    var state = { mode: 'class', year: 0, group: 'all', profile: '', subject: '', id: 0, q: '' };
    var cache = {};

    var byId = {};
    var bySubject = {};
    LIST.forEach( function ( e ) {
        byId[ e.id ] = e;
        ( bySubject[ e.s ] = bySubject[ e.s ] || [] ).push( e );
    } );
    Object.keys( bySubject ).forEach( function ( k ) {
        bySubject[ k ].sort( function ( a, b ) { return a.y - b.y; } );
    } );
    var subjects = Object.keys( bySubject ).sort( function ( a, b ) { return a.localeCompare( b, 'it' ); } );

    function el( tag, cls, text ) {
        var n = document.createElement( tag );
        if ( cls ) { n.className = cls; }
        if ( text !== undefined ) { n.textContent = text; }
        return n;
    }
    function btn( label, cls, onClick, pressed ) {
        var b = el( 'button', cls, label );
        b.type = 'button';
        if ( pressed !== undefined ) { b.setAttribute( 'aria-pressed', pressed ? 'true' : 'false' ); }
        b.addEventListener( 'click', onClick );
        return b;
    }
    function base( s ) { return s.replace( /\s+(OS|OC)$/, '' ); }
    function count( fn ) { return LIST.filter( fn ).length; }

    var tabs = el( 'div', 'ldp-tabs' );
    tabs.setAttribute( 'role', 'tablist' );
    var panel = el( 'div', 'ldp-panel' );
    var detail = el( 'section', 'ldp-detail' );
    detail.setAttribute( 'aria-live', 'polite' );
    detail.hidden = true;
    root.appendChild( tabs );
    root.appendChild( panel );
    root.appendChild( detail );

    function renderTabs() {
        tabs.textContent = '';
        [ [ 'class', 'Per classe' ], [ 'subject', 'Per materia' ], [ 'table', 'Tabella' ] ].forEach( function ( t ) {
            var b = btn( t[ 1 ], 'ldp-tab' + ( state.mode === t[ 0 ] ? ' is-on' : '' ), function () {
                state.mode = t[ 0 ];
                render();
            } );
            b.setAttribute( 'role', 'tab' );
            b.setAttribute( 'aria-selected', state.mode === t[ 0 ] ? 'true' : 'false' );
            tabs.appendChild( b );
        } );
    }

    function card( e, withYear ) {
        var b = btn( '', 'ldp-card' + ( state.id === e.id ? ' is-on' : '' ), function () { open( e.id, true ); } );
        b.appendChild( el( 'strong', '', base( e.s ) ) );
        if ( e.g !== 'fond' ) { b.appendChild( el( 'span', 'ldp-badge', e.g.toUpperCase() ) ); }
        if ( withYear ) { b.appendChild( el( 'span', 'ldp-year', e.y + 'a Liceo' ) ); }
        b.appendChild( el( 'span', 'ldp-go', '→' ) );
        return b;
    }

    function stepTitle( n, text ) {
        var h = el( 'h3', 'ldp-step' );
        h.appendChild( el( 'span', 'ldp-n', String( n ) ) );
        h.appendChild( document.createTextNode( ' ' + text ) );
        return h;
    }

    function renderClass() {
        panel.appendChild( stepTitle( 1, 'In che classe sei?' ) );
        var row = el( 'div', 'ldp-chips' );
        [ 1, 2, 3, 4 ].forEach( function ( y ) {
            var n = count( function ( e ) { return e.y === y; } );
            row.appendChild( btn( y + 'a Liceo · ' + n + ' programmi', 'ldp-chip' + ( state.year === y ? ' is-on' : '' ), function () {
                state.year = y;
                state.group = 'all';
                state.profile = '';
                render();
            }, state.year === y ) );
        } );
        panel.appendChild( row );
        if ( ! state.year ) { return; }

        panel.appendChild( stepTitle( 2, 'Cosa vuoi vedere?' ) );
        var yearList = LIST.filter( function ( e ) { return e.y === state.year; } );
        var g = el( 'div', 'ldp-chips' );
        [ [ 'all', 'Tutti' ], [ 'fond', GROUPS.fond.label ], [ 'os', GROUPS.os.label ], [ 'oc', GROUPS.oc.label ] ].forEach( function ( x ) {
            var n = x[ 0 ] === 'all' ? yearList.length : yearList.filter( function ( e ) { return e.g === x[ 0 ]; } ).length;
            if ( ! n ) { return; }
            g.appendChild( btn( x[ 1 ] + ' (' + n + ')', 'ldp-chip' + ( state.group === x[ 0 ] ? ' is-on' : '' ), function () {
                state.group = x[ 0 ];
                state.profile = '';
                render();
            }, state.group === x[ 0 ] ) );
        } );
        panel.appendChild( g );
        if ( GROUPS[ state.group ] ) { panel.appendChild( el( 'p', 'ldp-hint', GROUPS[ state.group ].text ) ); }

        var shown = yearList.filter( function ( e ) { return state.group === 'all' || e.g === state.group; } );
        if ( state.group === 'os' ) {
            var profiles = [];
            shown.forEach( function ( e ) { if ( e.p && profiles.indexOf( e.p ) < 0 ) { profiles.push( e.p ); } } );
            if ( profiles.length > 1 ) {
                var pr = el( 'div', 'ldp-chips ldp-chips--sub' );
                pr.appendChild( btn( 'Tutti gli indirizzi', 'ldp-chip' + ( ! state.profile ? ' is-on' : '' ), function () { state.profile = ''; render(); }, ! state.profile ) );
                profiles.forEach( function ( p ) {
                    pr.appendChild( btn( p, 'ldp-chip' + ( state.profile === p ? ' is-on' : '' ), function () { state.profile = p; render(); }, state.profile === p ) );
                } );
                panel.appendChild( pr );
                if ( state.profile ) { shown = shown.filter( function ( e ) { return e.p === state.profile; } ); }
            }
        }
        panel.appendChild( stepTitle( 3, 'Scegli un programma' ) );
        var grid = el( 'div', 'ldp-grid' );
        shown.forEach( function ( e ) { grid.appendChild( card( e, false ) ); } );
        panel.appendChild( grid );
    }

    function renderSubject() {
        panel.appendChild( stepTitle( 1, 'Scegli una materia' ) );
        var search = el( 'input', 'ldp-search' );
        search.type = 'search';
        search.placeholder = 'Cerca una materia…';
        search.setAttribute( 'aria-label', 'Cerca una materia' );
        search.value = state.q;
        panel.appendChild( search );
        var row = el( 'div', 'ldp-chips' );
        panel.appendChild( row );
        function fill() {
            row.textContent = '';
            var q = state.q.trim().toLowerCase();
            subjects.filter( function ( s ) { return ! q || s.toLowerCase().indexOf( q ) >= 0; } ).forEach( function ( s ) {
                var on = state.subject === s;
                row.appendChild( btn( s, 'ldp-chip' + ( on ? ' is-on' : '' ), function () {
                    state.subject = s;
                    open( bySubject[ s ][ 0 ].id, true );
                    render();
                }, on ) );
            } );
            if ( ! row.firstChild ) { row.appendChild( el( 'p', 'ldp-hint', 'Nessuna materia trovata.' ) ); }
        }
        search.addEventListener( 'input', function () { state.q = search.value; fill(); } );
        fill();
    }

    function renderTable() {
        panel.appendChild( el( 'p', 'ldp-hint', 'Scegli la cella della materia e della classe per aprire il programma.' ) );
        var wrap = el( 'div', 'ldp-table-wrap' );
        var t = el( 'table', 'ldp-table' );
        var head = el( 'tr' );
        [ 'Materia', '1a Liceo', '2a Liceo', '3a Liceo', '4a Liceo' ].forEach( function ( h ) {
            var th = el( 'th', '', h );
            th.scope = 'col';
            head.appendChild( th );
        } );
        var thead = el( 'thead' );
        thead.appendChild( head );
        t.appendChild( thead );
        var tb = el( 'tbody' );
        subjects.forEach( function ( s ) {
            var tr = el( 'tr' );
            var th = el( 'th', '', s );
            th.scope = 'row';
            tr.appendChild( th );
            [ 1, 2, 3, 4 ].forEach( function ( y ) {
                var td = el( 'td' );
                var e = bySubject[ s ].filter( function ( x ) { return x.y === y; } )[ 0 ];
                if ( e ) {
                    var b = btn( ROMAN[ y ], 'ldp-cell' + ( state.id === e.id ? ' is-on' : '' ), function () { open( e.id, true ); } );
                    b.setAttribute( 'aria-label', s + ', ' + y + 'a liceo' );
                    td.appendChild( b );
                }
                tr.appendChild( td );
            } );
            tb.appendChild( tr );
        } );
        t.appendChild( tb );
        wrap.appendChild( t );
        panel.appendChild( wrap );
    }

    function render() {
        renderTabs();
        panel.textContent = '';
        if ( state.mode === 'class' ) { renderClass(); }
        else if ( state.mode === 'subject' ) { renderSubject(); }
        else { renderTable(); }
    }

    // ---- Dettaglio di un programma ----
    function rich( text ) {
        var box = el( 'div', 'ldp-rich' );
        var parts = String( text || '' ).split( /\s*[·•]\s*/ ).map( function ( s ) { return s.trim(); } ).filter( Boolean );
        if ( parts.length > 1 ) {
            if ( text.trim().charAt( 0 ) !== '·' ) { box.appendChild( el( 'p', 'ldp-sub', parts.shift() ) ); }
            var ul = el( 'ul' );
            parts.forEach( function ( p ) { ul.appendChild( el( 'li', '', p ) ); } );
            box.appendChild( ul );
        } else {
            String( text || '' ).split( /\n+/ ).forEach( function ( p ) {
                if ( p.trim() ) { box.appendChild( el( 'p', '', p.trim() ) ); }
            } );
        }
        return box;
    }

    function section( title, text, open ) {
        if ( ! text || ! String( text ).trim() ) { return null; }
        var d = el( 'details', 'ldp-sec' );
        d.open = !! open;
        d.appendChild( el( 'summary', '', title ) );
        d.appendChild( rich( text ) );
        return d;
    }

    function paint( e, data ) {
        detail.textContent = '';
        var head = el( 'div', 'ldp-detail__head' );
        head.appendChild( el( 'h3', '', base( e.s ) + ( e.g !== 'fond' ? ' — ' + ( e.g === 'os' ? 'opzione specifica' : 'opzione complementare' ) : '' ) ) );
        var yrs = el( 'div', 'ldp-years' );
        bySubject[ e.s ].forEach( function ( x ) {
            yrs.appendChild( btn( x.y + 'a Liceo', 'ldp-year-tab' + ( x.id === e.id ? ' is-on' : '' ), function () { open( x.id, false ); }, x.id === e.id ) );
        } );
        head.appendChild( yrs );
        var close = btn( 'Chiudi', 'ldp-close', function () {
            detail.hidden = true;
            state.id = 0;
            history.replaceState( null, '', location.pathname + location.search );
            render();
        } );
        head.appendChild( close );
        detail.appendChild( head );
        if ( ! data ) {
            detail.appendChild( el( 'p', 'ldp-hint', 'Caricamento del programma…' ) );
            return;
        }
        [
            section( 'Osservazioni introduttive e finalità generali', data.intro, true ),
            section( 'Temi trattati · I semestre', data.sem1, true ),
            section( 'Temi trattati · II semestre', data.sem2, true ),
            section( 'Obiettivi cognitivi e metodologici', data.goals, false ),
            section( 'Modalità di lavoro e materiali utilizzati', data.method, false )
        ].forEach( function ( s ) { if ( s ) { detail.appendChild( s ); } } );
        if ( data.revision ) { detail.appendChild( el( 'p', 'ldp-rev', 'Ultima revisione: ' + data.revision ) ); }
    }

    function open( id, scroll ) {
        var e = byId[ id ];
        if ( ! e ) { return; }
        state.id = id;
        state.subject = e.s;
        detail.hidden = false;
        history.replaceState( null, '', '#programma-' + id );
        paint( e, cache[ id ] );
        if ( ! cache[ id ] ) {
            fetch( cfg.api + id, { credentials: 'omit' } )
                .then( function ( r ) { if ( ! r.ok ) { throw new Error( r.status ); } return r.json(); } )
                .then( function ( data ) {
                    cache[ id ] = data;
                    if ( state.id === id ) { paint( e, data ); }
                } )
                .catch( function () {
                    if ( state.id === id ) { detail.appendChild( el( 'p', 'ldp-hint', 'Non riesco a caricare il programma. Riprova tra poco.' ) ); }
                } );
        }
        render();
        if ( scroll ) { detail.scrollIntoView( { behavior: 'smooth', block: 'start' } ); }
    }

    var m = /^#programma-(\d+)$/.exec( location.hash );
    if ( m && byId[ m[ 1 ] ] ) {
        state.year = byId[ m[ 1 ] ].y;
        open( parseInt( m[ 1 ], 10 ), false );
    } else {
        render();
    }
} )();
