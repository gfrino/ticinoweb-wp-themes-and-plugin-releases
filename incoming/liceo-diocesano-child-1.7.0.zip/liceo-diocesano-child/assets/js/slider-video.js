( function () {
    var url = ( window.liceoHero || {} ).video;
    var slider = document.querySelector( '.hero-slider' );
    var img = slider && slider.querySelector( '.slide .slide-image' );
    if ( ! url || ! img ) {
        return;
    }

    // Se il video non può o non deve partire, la foto torna visibile.
    function fallback() {
        document.body.classList.add( 'ld-video-failed' );
    }

    // Foto con movimento ridotto, risparmio dati attivo o rete lenta.
    var conn = navigator.connection || {};
    var slow = conn.saveData || /(^|-)2g$|3g/.test( conn.effectiveType || '' );
    var still = window.matchMedia && window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches;
    if ( slow || still ) {
        fallback();
        return;
    }

    var FADE = 1.0; // secondi di dissolvenza incrociata tra la fine e l'inizio del video

    function make() {
        var v = document.createElement( 'video' );
        v.className = 'slide-image slide-video';
        v.muted = true;
        v.playsInline = true;
        v.setAttribute( 'playsinline', '' );
        v.setAttribute( 'muted', '' );
        v.setAttribute( 'aria-hidden', 'true' );
        v.disablePictureInPicture = true;
        v.preload = 'auto';
        v.src = url;
        v.style.opacity = '0';
        return v;
    }

    var a = make();
    var b = make();
    img.parentNode.insertBefore( a, img.nextSibling );
    img.parentNode.insertBefore( b, a.nextSibling );

    var cur = a;
    var nxt = b;
    var crossing = false;
    var visible = true;
    var started = false;

    function play( v ) {
        var p = v.play();
        if ( p && p.catch ) {
            p.catch( function () {
                if ( ! started ) { fallback(); } // il browser blocca l'avvio automatico
            } );
        }
    }

    // Il loop è una dissolvenza: poco prima della fine parte la seconda copia e la prima sfuma.
    function watch( v ) {
        v.addEventListener( 'timeupdate', function () {
            if ( v !== cur || crossing || ! v.duration || v.duration - v.currentTime > FADE ) {
                return;
            }
            crossing = true;
            nxt.currentTime = 0;
            play( nxt );
            nxt.style.opacity = '1';
            cur.style.opacity = '0';
            var old = cur;
            setTimeout( function () {
                old.pause();
                old.currentTime = 0;
                cur = nxt;
                nxt = old;
                crossing = false;
            }, FADE * 1000 + 50 );
        } );
    }
    watch( a );
    watch( b );

    // Appare in dissolvenza sul fondo scuro appena parte; non c'è nessuna foto di attesa.
    a.addEventListener( 'playing', function first() {
        a.removeEventListener( 'playing', first );
        started = true;
        a.style.opacity = '1';
    } );
    // Se dopo 6 secondi non è partito (rete lenta, errore), si mostra la foto.
    setTimeout( function () { if ( ! started ) { fallback(); } }, 6000 );
    a.addEventListener( 'error', fallback );

    // Fuori schermo o con la scheda in background si ferma: meno CPU e batteria.
    function sync() {
        if ( visible && ! document.hidden ) {
            play( cur );
            if ( crossing ) { play( nxt ); }
        } else {
            a.pause();
            b.pause();
        }
    }
    if ( 'IntersectionObserver' in window ) {
        new IntersectionObserver( function ( entries ) {
            visible = entries[ 0 ].isIntersecting;
            sync();
        }, { threshold: 0.1 } ).observe( slider );
    }
    document.addEventListener( 'visibilitychange', sync );
    sync();
} )();
