( function () {
    var btn = document.querySelector( '.ld-menu-toggle' );
    var nav = document.querySelector( '.main-navigation' );
    if ( ! btn || ! nav ) {
        return;
    }
    btn.addEventListener( 'click', function () {
        var open = nav.classList.toggle( 'is-open' );
        btn.setAttribute( 'aria-expanded', open ? 'true' : 'false' );
    } );
    // Su mobile i sottomenu si aprono toccando la voce principale.
    nav.querySelectorAll( '.menu-item-has-children > a' ).forEach( function ( a ) {
        a.addEventListener( 'click', function ( e ) {
            if ( window.matchMedia( '(max-width: 900px)' ).matches && ! a.parentNode.classList.contains( 'is-open' ) ) {
                e.preventDefault();
                a.parentNode.classList.add( 'is-open' );
            }
        } );
    } );
} )();
