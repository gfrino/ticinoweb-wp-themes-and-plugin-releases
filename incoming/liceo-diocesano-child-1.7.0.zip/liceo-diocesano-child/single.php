<?php
/**
 * Articolo singolo: fascia con titolo e data, contenuto su scheda bianca.
 *
 * @package liceo-diocesano-child
 */
get_header();
while ( have_posts() ) :
    the_post();
    liceo_diocesano_page_hero( get_the_title(), get_the_date() );
    ?>
    <main class="container ld-page">
        <article <?php post_class( 'default-article' ); ?>>
            <div class="entry-content"><?php the_content(); ?></div>
        </article>
    </main>
    <?php
endwhile;
get_footer();
