<?php
/**
 * Liceo Diocesano Child: funzioni del tema.
 *
 * @package liceo-diocesano-child
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

require_once get_stylesheet_directory() . '/inc/slider-video.php';
require_once get_stylesheet_directory() . '/inc/programmi.php';

function liceo_diocesano_enqueue_styles() {
    // Il parent accoda get_stylesheet_uri() (= questo style.css) come 'ticinoweb-ai-style' e Poppins da Google Fonts:
    // il child lo riaccoda con la propria versione e usa Source Sans 3 self-hosted, quindi si tolgono entrambi.
    wp_dequeue_style( 'ticinoweb-ai-style' );
    wp_dequeue_style( 'poppins-font' );

    $parent_version = wp_get_theme( get_template() )->get( 'Version' );
    wp_enqueue_style( 'parent-style', get_template_directory_uri() . '/style.css', array(), $parent_version );
    $version = filemtime( get_stylesheet_directory() . '/style.css' );
    wp_enqueue_style( 'child-style', get_stylesheet_uri(), array( 'parent-style' ), $version );
}
add_action( 'wp_enqueue_scripts', 'liceo_diocesano_enqueue_styles', 20 );

function liceo_diocesano_enqueue_menu_script() {
    $file = get_stylesheet_directory() . '/assets/js/menu.js';
    wp_enqueue_script( 'liceo-diocesano-menu', get_stylesheet_directory_uri() . '/assets/js/menu.js', array(), filemtime( $file ), true );
}
add_action( 'wp_enqueue_scripts', 'liceo_diocesano_enqueue_menu_script', 25 );

// Pulsante del menu su mobile (il parent non lo prevede); si vede solo sotto i 900px.
function liceo_diocesano_menu_toggle() {
    echo '<button type="button" class="ld-menu-toggle" aria-expanded="false" aria-label="' . esc_attr__( 'Apri il menu', 'liceo-diocesano-child' ) . '"><span></span><span></span><span></span></button>';
}
add_action( 'ticinoweb_after_primary_navigation', 'liceo_diocesano_menu_toggle' );

// Il font del corpo è caricato dal CSS: precarica la parte latina, usata da tutto il testo italiano.
function liceo_diocesano_preload_font() {
    printf(
        '<link rel="preload" href="%s" as="font" type="font/woff2" crossorigin>' . "\n",
        esc_url( get_stylesheet_directory_uri() . '/assets/fonts/source-sans-3-latin.woff2' )
    );
}
add_action( 'wp_head', 'liceo_diocesano_preload_font', 1 );

function liceo_diocesano_register_menus() {
    register_nav_menus( array(
        'primary' => __( 'Menu Principale', 'liceo-diocesano-child' ),
    ) );
}
add_action( 'after_setup_theme', 'liceo_diocesano_register_menus', 20 );

/**
 * Home: il parent stampa lo slider (ticinoWEB CMS → Slider) e poi questi tre punti di aggancio.
 * Il testo di presentazione si modifica nella pagina impostata come Home (Impostazioni → Lettura).
 */
function liceo_diocesano_upload_url( $path ) {
    $up = wp_upload_dir();
    return trailingslashit( $up['baseurl'] ) . ltrim( $path, '/' );
}

function liceo_diocesano_page_url( $slug ) {
    $page = get_page_by_path( $slug );
    return $page ? get_permalink( $page ) : '';
}

function liceo_diocesano_home_intro() {
    $home_id = (int) get_option( 'page_on_front' );
    $home    = $home_id ? get_post( $home_id ) : null;
    if ( $home && '' !== trim( $home->post_content ) ) {
        $more = liceo_diocesano_page_url( 'presentazione' );
        echo '<div class="ld-intro"><span class="ld-pill">' . esc_html__( 'Il Liceo', 'liceo-diocesano-child' ) . '</span><div class="entry-content">' . apply_filters( 'the_content', $home->post_content ) . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput
        if ( $more ) {
            echo '<a class="ld-btn" href="' . esc_url( $more ) . '">' . esc_html__( 'Scopri di più', 'liceo-diocesano-child' ) . '</a>';
        }
        echo '</div>';
    }

    $cards = array(
        array( 'Iscrizione alla scuola', 'Info e iscrizioni >', 'iscrizione', '2025/10/Schermata-2025-09-23-alle-17.22.24.png', '' ),
        array( 'Corsi tecnologici', 'Info e iscrizioni >', 'corsi-tecnologici', '2025/10/liceo-alberi.jpg', 'ld-card--alt' ),
        array( 'Indirizzi formativi', 'Scopri di più >', 'piano-degli-studi', '2025/10/Schermata-2025-09-23-alle-17.22.24.png', '' ),
        array( 'Indirizzo e contatti', 'Scopri di più >', 'indirizzo_contatti', '2025/10/contact-us-concept-2025-02-20-23-32-51-utc-scaled.jpg', 'ld-card--alt' ),
        array( 'Borse di studio', 'Scopri di più >', 'borse-di-studio', '2025/10/Schermata-2025-09-23-alle-17.29.58.png', '' ),
        array( 'Informativa sul trattamento dei dati personali della fondazione Liceo Diocesano', 'Scopri di più >', '', '2025/10/Schermata-2025-09-23-alle-17.30.43.png', 'ld-card--alt' ),
    );
    echo '<div class="ld-cards">';
    foreach ( $cards as $c ) {
        $url = $c[2] ? liceo_diocesano_page_url( $c[2] ) : liceo_diocesano_upload_url( '2023/12/Informativa-LDP-Lucino-WEB.pdf' );
        printf(
            '<a class="ld-card %1$s" href="%2$s" style="background-image:url(%3$s)"><span class="ld-card__go" aria-hidden="true">↗</span><span class="ld-card__body"><strong>%4$s</strong><span class="screen-reader-text">%5$s</span></span></a>',
            esc_attr( $c[4] ),
            esc_url( $url ),
            esc_url( liceo_diocesano_upload_url( $c[3] ) ),
            esc_html( $c[0] ),
            esc_html( $c[1] )
        );
    }
    echo '</div>';
}
add_action( 'ticinoweb_services_section', 'liceo_diocesano_home_intro' );

function liceo_diocesano_home_quicklinks() {
    $links = array(
        array( 'Calendario Scolastico', 'calendario-scolastico', '2025/10/calendar-editable_0.3s.svg' ),
        array( 'Orario Scolastico', 'la-griglia-oraria', '2025/10/clock-1-editable_0.3s.svg' ),
        array( 'Menu Settimanale mensa', 'menu-settimanale-mensa', '2025/10/Restaurant_Silverware_0.3s.svg' ),
    );
    echo '<section class="ld-quicklinks"><div class="container"><span class="ld-pill ld-pill--light">' . esc_html__( 'Ogni giorno a scuola', 'liceo-diocesano-child' ) . '</span><div class="ld-quicklinks__grid">';
    foreach ( $links as $l ) {
        printf(
            '<a href="%1$s"><img src="%2$s" alt="" width="64" height="64" loading="lazy"><span>%3$s</span></a>',
            esc_url( liceo_diocesano_page_url( $l[1] ) ),
            esc_url( liceo_diocesano_upload_url( $l[2] ) ),
            esc_html( $l[0] )
        );
    }
    echo '</div></div></section>';
}
add_action( 'ticinoweb_cta_section', 'liceo_diocesano_home_quicklinks' );

function liceo_diocesano_home_news() {
    $posts = get_posts( array( 'numberposts' => 6, 'post_status' => 'publish' ) );
    if ( ! $posts ) {
        return;
    }
    echo '<section class="ld-news"><div class="container"><span class="ld-pill">' . esc_html__( 'Notizie', 'liceo-diocesano-child' ) . '</span><h2>' . esc_html__( 'Ultimi articoli', 'liceo-diocesano-child' ) . '</h2><div class="ld-news__grid">';
    foreach ( $posts as $p ) {
        $thumb = get_the_post_thumbnail( $p, 'medium_large', array( 'loading' => 'lazy', 'alt' => '' ) );
        printf(
            '<article class="ld-news__item"><a class="ld-news__img" href="%1$s" tabindex="-1" aria-hidden="true">%2$s</a><time datetime="%3$s">%4$s</time><h3><a href="%1$s">%5$s</a></h3></article>',
            esc_url( get_permalink( $p ) ),
            $thumb, // phpcs:ignore WordPress.Security.EscapeOutput
            esc_attr( get_the_date( 'c', $p ) ),
            esc_html( get_the_date( '', $p ) ),
            esc_html( get_the_title( $p ) )
        );
    }
    echo '</div>';
    $archive = liceo_diocesano_page_url( 'articoli' );
    if ( $archive ) {
        echo '<p class="ld-news__all"><a class="button" href="' . esc_url( $archive ) . '">' . esc_html__( 'Vedi tutti gli articoli', 'liceo-diocesano-child' ) . '</a></p>';
    }
    echo '</div></section>';
}
add_action( 'ticinoweb_about_section', 'liceo_diocesano_home_news' );

// Footer: tutti gli indirizzi email del sito (il parent ne stampa uno solo) e link principali.
function liceo_diocesano_footer_emails() {
    $c      = ticinoweb_get_contact_info();
    $labels = array( 'email' => 'segreteria', 'email_2' => 'direzione', 'email_3' => 'amministrazione' );
    echo '<ul class="ld-footer-emails">';
    foreach ( $labels as $key => $label ) {
        if ( ! empty( $c[ $key ] ) ) {
            printf( '<li>%s: <a href="mailto:%s">%s</a></li>', esc_html( $label ), esc_attr( $c[ $key ] ), esc_html( $c[ $key ] ) );
        }
    }
    echo '</ul>';
}
add_action( 'ticinoweb_footer_brand_description', 'liceo_diocesano_footer_emails' );

function liceo_diocesano_footer_links() {
    $items = array( 'informazioni' => 'Informazioni', 'organizzazione' => 'Studi', 'il-liceo' => '2025-26', 'articoli' => 'Notizie', 'la-storia' => 'La Storia', 'area-riservata-2' => 'Area Riservata' );
    foreach ( $items as $slug => $label ) {
        $url = liceo_diocesano_page_url( $slug );
        if ( $url ) {
            printf( '<li><a href="%s">%s</a></li>', esc_url( $url ), esc_html( $label ) );
        }
    }
}
add_action( 'ticinoweb_footer_links', 'liceo_diocesano_footer_links' );

// Titolo della colonna link del footer del parent.
add_filter( 'gettext', function ( $text, $original, $domain ) {
    return ( 'Servizi' === $original && 'ticinoweb-ai-theme' === $domain ) ? 'Link utili' : $text;
}, 10, 3 );

// Home: la classe permette alla testata (video o foto) di salire sotto topbar e menu.
add_filter( 'body_class', function ( $classes ) {
    if ( is_front_page() ) {
        $classes[] = 'ld-home';
    }
    return $classes;
} );

/**
 * Riga superiore dell'header (il menu sta sulla riga sotto): contatti e social, letti dal CMS del parent.
 * Stampata a inizio body, subito prima dell'header del parent.
 */
function liceo_diocesano_topbar() {
    $c = ticinoweb_get_contact_info();
    $phone_svg = '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.13.96.36 1.9.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.91.34 1.85.57 2.81.7A2 2 0 0 1 22 16.92z"/></svg>';
    $mail_svg  = '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>';
    echo '<div class="ld-topbar"><div class="ld-topbar__in"><div class="ld-topbar__contacts">';
    if ( ! empty( $c['phone'] ) ) {
        printf( '<a href="tel:%s">%s<span>%s</span></a>', esc_attr( preg_replace( '/[^0-9+]/', '', $c['phone'] ) ), $phone_svg, esc_html( $c['phone'] ) ); // phpcs:ignore WordPress.Security.EscapeOutput
    }
    if ( ! empty( $c['email'] ) ) {
        printf( '<a href="mailto:%1$s">%2$s<span>%1$s</span></a>', esc_attr( $c['email'] ), $mail_svg ); // phpcs:ignore WordPress.Security.EscapeOutput
    }
    echo '</div><div class="ld-topbar__social">';
    $yt = get_option( 'ticinoweb_contact_youtube', '' );
    $networks = array(
        'Facebook'  => array( $c['facebook'], 'M24 12.07C24 5.44 18.63.07 12 .07S0 5.44 0 12.07c0 5.99 4.39 10.95 10.13 11.85v-8.38H7.08v-3.47h3.05V9.43c0-3.01 1.79-4.67 4.53-4.67 1.31 0 2.69.23 2.69.23v2.95h-1.51c-1.49 0-1.96.93-1.96 1.87v2.25h3.33l-.53 3.47h-2.8v8.38C19.61 23.03 24 18.06 24 12.07z' ),
        'Instagram' => array( $c['instagram'], 'M12 2.16c3.2 0 3.58.01 4.85.07 3.25.15 4.77 1.69 4.92 4.92.06 1.27.07 1.65.07 4.85s-.01 3.58-.07 4.85c-.15 3.23-1.66 4.77-4.92 4.92-1.27.06-1.64.07-4.85.07s-3.58-.01-4.85-.07c-3.26-.15-4.77-1.7-4.92-4.92C2.17 15.58 2.16 15.2 2.16 12s.01-3.58.07-4.85C2.38 3.92 3.9 2.38 7.15 2.23 8.42 2.17 8.8 2.16 12 2.16zM12 0C8.74 0 8.33.01 7.05.07 2.7.27.27 2.69.07 7.05.01 8.33 0 8.74 0 12s.01 3.67.07 4.95c.2 4.36 2.62 6.78 6.98 6.98C8.33 23.99 8.74 24 12 24s3.67-.01 4.95-.07c4.35-.2 6.78-2.62 6.98-6.98.06-1.28.07-1.69.07-4.95s-.01-3.67-.07-4.95c-.2-4.35-2.62-6.78-6.98-6.98C15.67.01 15.26 0 12 0zm0 5.84a6.16 6.16 0 100 12.32 6.16 6.16 0 000-12.32zM12 16a4 4 0 110-8 4 4 0 010 8zm6.41-11.85a1.44 1.44 0 100 2.88 1.44 1.44 0 000-2.88z' ),
        'YouTube'   => array( $yt, 'M23.5 6.2a3 3 0 00-2.1-2.1C19.5 3.6 12 3.6 12 3.6s-7.5 0-9.4.5A3 3 0 00.5 6.2C0 8.1 0 12 0 12s0 3.9.5 5.8a3 3 0 002.1 2.1c1.9.5 9.4.5 9.4.5s7.5 0 9.4-.5a3 3 0 002.1-2.1c.5-1.9.5-5.8.5-5.8s0-3.9-.5-5.8zM9.6 15.6V8.4l6.2 3.6-6.2 3.6z' ),
    );
    foreach ( $networks as $name => $n ) {
        if ( ! empty( $n[0] ) ) {
            printf( '<a href="%s" target="_blank" rel="noopener" aria-label="%s"><svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="%s"/></svg></a>', esc_url( $n[0] ), esc_attr( $name ), esc_attr( $n[1] ) );
        }
    }
    echo '</div></div></div>';
}
add_action( 'wp_body_open', 'liceo_diocesano_topbar', 5 );

add_filter( 'body_class', function ( $classes ) {
    $classes[] = 'ld-ovh'; // header e contatti sovrapposti alla testata, su tutte le pagine
    return $classes;
} );

/**
 * Testata delle pagine interne: stessa impostazione della home (header trasparente sopra una fascia
 * con il titolo), con l'immagine in evidenza se c'è, altrimenti il fondo grigio-bruno del liceo.
 */
function liceo_diocesano_page_hero( $title, $pill = '' ) {
    $img = is_singular() ? get_the_post_thumbnail_url( get_queried_object_id(), 'full' ) : '';
    if ( ! $img ) {
        // Senza immagine in evidenza si usano le foto d'epoca della testata, a rotazione per pagina.
        $n   = ( is_singular() ? get_queried_object_id() : 0 ) % 4 + 1;
        $img = liceo_diocesano_upload_url( array( 1 => '2025/10/1-modd.png', 2 => '2025/10/2-mod.png', 3 => '2025/10/3-mod.png', 4 => '2025/10/4-mod.png' )[ $n ] );
    }
    echo '<section class="ld-page-hero" style="background-image:url(' . esc_url( $img ) . ')"><div class="ld-page-hero__in">';
    if ( $pill ) {
        echo '<span class="ld-pill ld-pill--light">' . esc_html( $pill ) . '</span>';
    }
    echo '<h1>' . esc_html( $title ) . '</h1></div></section>';
}

/**
 * Navigazione della sezione: le pagine «sorelle» della pagina corrente nel menu principale
 * (o le sue sottopagine, se è una voce di primo livello). Si gestisce solo dal menu: nessun dato in più.
 */
function liceo_diocesano_section_nav( $page_id ) {
    $locations = get_nav_menu_locations();
    if ( empty( $locations['primary'] ) ) {
        return '';
    }
    $items = wp_get_nav_menu_items( $locations['primary'] );
    if ( ! $items ) {
        return '';
    }
    $current = null;
    foreach ( $items as $it ) {
        if ( 'page' === $it->object && (int) $it->object_id === (int) $page_id ) {
            $current = $it;
            break;
        }
    }
    if ( ! $current ) {
        return '';
    }
    $parent_id = (int) $current->menu_item_parent;
    if ( ! $parent_id ) {
        $parent_id = (int) $current->ID; // voce di primo livello: mostra le sue sottopagine
    }
    $title = '';
    $links = array();
    foreach ( $items as $it ) {
        if ( (int) $it->ID === $parent_id ) {
            $title = $it->title;
        }
        if ( (int) $it->menu_item_parent === $parent_id ) {
            $links[] = $it;
        }
    }
    if ( count( $links ) < 2 ) {
        return '';
    }
    $out = '<aside class="ld-aside"><h2>' . esc_html( $title ) . '</h2><ul>';
    foreach ( $links as $l ) {
        $on   = (int) $l->object_id === (int) $page_id && 'page' === $l->object;
        $out .= '<li><a href="' . esc_url( $l->url ) . '"' . ( $on ? ' class="is-on" aria-current="page"' : '' ) . '>' . esc_html( $l->title ) . '</a></li>';
    }
    return $out . '</ul></aside>';
}

function liceo_diocesano_posts_grid( $query ) {
    echo '<div class="ld-news__grid">';
    while ( $query->have_posts() ) {
        $query->the_post();
        printf(
            '<article class="ld-news__item"><a class="ld-news__img" href="%1$s" tabindex="-1" aria-hidden="true">%2$s</a><time datetime="%3$s">%4$s</time><h3><a href="%1$s">%5$s</a></h3></article>',
            esc_url( get_permalink() ),
            get_the_post_thumbnail( null, 'medium_large', array( 'loading' => 'lazy', 'alt' => '' ) ), // phpcs:ignore WordPress.Security.EscapeOutput
            esc_attr( get_the_date( 'c' ) ),
            esc_html( get_the_date() ),
            esc_html( get_the_title() )
        );
    }
    echo '</div>';
    wp_reset_postdata();
}
