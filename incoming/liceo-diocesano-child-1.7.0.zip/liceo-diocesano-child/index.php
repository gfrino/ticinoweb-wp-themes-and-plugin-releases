<?php
/**
 * Archivi, ricerca e pagina degli articoli.
 *
 * @package liceo-diocesano-child
 */
get_header();
liceo_diocesano_page_hero( is_search() ? sprintf( /* translators: %s: search terms */ __( 'Risultati per «%s»', 'liceo-diocesano-child' ), get_search_query() ) : ( is_archive() ? wp_strip_all_tags( get_the_archive_title() ) : __( 'Notizie', 'liceo-diocesano-child' ) ), get_bloginfo( 'name' ) );
?>
<main class="container ld-page">
    <?php if ( have_posts() ) : ?>
        <div class="ld-news ld-news--page">
            <?php liceo_diocesano_posts_grid( $GLOBALS['wp_query'] ); ?>
            <nav class="ld-pagination"><?php echo paginate_links(); // phpcs:ignore WordPress.Security.EscapeOutput ?></nav>
        </div>
    <?php else : ?>
        <article class="default-article"><p><?php esc_html_e( 'Nessun contenuto disponibile.', 'liceo-diocesano-child' ); ?></p></article>
    <?php endif; ?>
</main>
<?php get_footer(); ?>
