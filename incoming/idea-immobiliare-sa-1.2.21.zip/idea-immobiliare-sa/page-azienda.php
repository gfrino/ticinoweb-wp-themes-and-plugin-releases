<?php
/**
 * Pagina «Azienda» (si applica da sola alla pagina con indirizzo «azienda»).
 * Testo, immagine in evidenza e foto dentro il testo si gestiscono dalla pagina:
 * ogni titolo H2 diventa un riquadro, la foto in evidenza è l'immagine principale.
 *
 * @package Idea_Immobiliare_SA
 */
get_header();
while (have_posts()) : the_post();
	$html     = apply_filters('the_content', get_the_content());
	$parts    = preg_split('/(?=<h2[\s>])/i', $html, -1, PREG_SPLIT_NO_EMPTY);
	$intro    = '';
	if ($parts && stripos($parts[0], '<h2') !== 0) {
		$intro = array_shift($parts);
	}
	$has_thumb = has_post_thumbnail();
?>
<main id="main" class="az">
	<header class="az-hero<?php echo $has_thumb ? ' has-photo' : ''; ?>">
		<div class="idea-container az-hero__grid">
			<div class="az-hero__copy">
				<?php echo ticinoweb_get_breadcrumbs(); // phpcs:ignore WordPress.Security.EscapeOutput ?>
				<h1><?php the_title(); ?></h1>
				<?php if (has_excerpt()) : ?><p class="az-hero__lead"><?php echo esc_html(get_the_excerpt()); ?></p><?php endif; ?>
				<?php if ($intro) : ?><div class="az-hero__intro"><?php echo $intro; // phpcs:ignore WordPress.Security.EscapeOutput ?></div><?php endif; ?>
			</div>
			<?php if ($has_thumb) : ?>
				<figure class="az-hero__photo"><?php the_post_thumbnail('large', array('alt' => '', 'loading' => 'eager', 'decoding' => 'async')); ?></figure>
			<?php endif; ?>
		</div>
	</header>

	<?php if ($parts) : ?>
	<section class="idea-section az-body">
		<div class="idea-container">
			<?php foreach ($parts as $i => $part) : ?>
				<?php if ($i === 2) : ?><div class="az-rest"><?php endif; ?>
				<article class="az-card az-card--<?php echo (int) $i; ?>"><?php echo $part; // phpcs:ignore WordPress.Security.EscapeOutput ?></article>
			<?php endforeach; ?>
			<?php if (count($parts) > 2) : ?></div><?php endif; ?>
		</div>
	</section>
	<?php endif; ?>
</main>
<?php endwhile;
get_footer();
