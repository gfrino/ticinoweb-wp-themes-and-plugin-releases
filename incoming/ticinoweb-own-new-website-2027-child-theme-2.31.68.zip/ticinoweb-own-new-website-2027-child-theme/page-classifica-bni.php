<?php
/**
 * Template Name: ticinoWEB — Classifica BNI
 *
 * Classifica dei membri del capitolo BNI Verzasca per referenze passate:
 * settimana (mercoledì–martedì), mese e anno. Titolo e testo introduttivo (estratto)
 * dall'editor; i dati da Odoo (vedi inc/bni-ranking.php). Pensata per il telefono.
 */
if ( ! defined( 'ABSPATH' ) ) exit;
get_header();
$tw_bni = function_exists( 'tw_bni_ranking_data' ) ? tw_bni_ranking_data() : array( 'ok' => false, 'members' => array() );
while ( have_posts() ) :
	the_post();
	?>
<main id="main-content" class="tw-bni">
	<div class="tw-bni__wrap">
		<header class="tw-bni__head">
			<img class="tw-bni__logo" src="<?php echo esc_url( get_stylesheet_directory_uri() . '/assets/images/bni-logo.png' ); ?>" width="480" height="185" alt="BNI" decoding="async">
			<h1><?php the_title(); ?></h1>
			<?php if ( has_excerpt() ) : ?><p class="tw-bni__lead"><?php echo esc_html( get_the_excerpt() ); ?></p><?php endif; ?>
		</header>

		<?php if ( $tw_bni['ok'] && $tw_bni['members'] ) : ?>
			<dl class="tw-bni__kpi">
				<div><dt><?php echo esc_html( sprintf( __( 'Referenze scambiate nel %s', 'ticinoweb-child-theme' ), $tw_bni['year'] ) ); ?></dt><dd><?php echo esc_html( $tw_bni['total'] ); ?></dd></div>
				<div><dt><?php esc_html_e( 'Periodo', 'ticinoweb-child-theme' ); ?></dt><dd class="is-period"><?php echo esc_html( date_i18n( 'j M Y', strtotime( $tw_bni['year'] . '-01-01' ) ) . ' – ' . date_i18n( 'j M Y', strtotime( $tw_bni['today'] ) ) ); ?></dd></div>
			</dl>
			<p class="tw-bni__week"><?php echo esc_html( sprintf( __( 'Settimana: %1$s – %2$s', 'ticinoweb-child-theme' ), date_i18n( 'D j M', strtotime( $tw_bni['week_from'] ) ), date_i18n( 'D j M', strtotime( $tw_bni['week_to'] ) ) ) ); ?></p>
			<table class="tw-bni__table">
				<thead>
					<tr>
						<th scope="col" class="tw-bni__rank"><span class="screen-reader-text"><?php esc_html_e( 'Posizione', 'ticinoweb-child-theme' ); ?></span>#</th>
						<th scope="col" class="tw-bni__name"><?php esc_html_e( 'Membro', 'ticinoweb-child-theme' ); ?></th>
						<th scope="col" class="tw-bni__num"><abbr title="<?php esc_attr_e( 'Settimana', 'ticinoweb-child-theme' ); ?>"><?php esc_html_e( 'Sett.', 'ticinoweb-child-theme' ); ?></abbr></th>
						<th scope="col" class="tw-bni__num"><?php esc_html_e( 'Mese', 'ticinoweb-child-theme' ); ?></th>
						<th scope="col" class="tw-bni__num is-year"><?php esc_html_e( 'Anno', 'ticinoweb-child-theme' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ( $tw_bni['members'] as $i => $tw_member ) : ?>
						<tr class="<?php echo ( $tw_member['year'] > 0 && $tw_member['rank'] <= 3 ) ? 'is-top' : ''; ?>">
							<td class="tw-bni__rank"><span><?php echo ( $i > 0 && $tw_bni['members'][ $i - 1 ]['rank'] === $tw_member['rank'] ) ? '' : esc_html( $tw_member['rank'] ); ?></span></td>
							<th scope="row" class="tw-bni__name"><?php echo esc_html( $tw_member['name'] ); ?></th>
							<td class="tw-bni__num"><?php echo esc_html( $tw_member['week'] ); ?></td>
							<td class="tw-bni__num"><?php echo esc_html( $tw_member['month'] ); ?></td>
							<td class="tw-bni__num is-year"><?php echo esc_html( $tw_member['year'] ); ?></td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		<?php else : ?>
			<p class="tw-bni__empty"><?php esc_html_e( 'La classifica sarà pubblicata a breve.', 'ticinoweb-child-theme' ); ?></p>
		<?php endif; ?>
	</div>
</main>
	<?php
endwhile;
get_footer();
