<?php
/**
 * Structured data and helpers for the existing service pages.
 *
 * @package TelecomSecurityChild
 */

defined( 'ABSPATH' ) || exit;

const TELECOMSECURITY_SERVICE_META_KEY = '_ts_service_content';

/**
 * Return the CMS partner assigned to the intrusion-alarm service hero.
 *
 * The canonical page keeps the association stable across WPML translations,
 * while the partner logo and alt text stay owned by the existing CMS fields.
 *
 * @param int $page_id Service page ID.
 * @return array Partner data or an empty array.
 */
function telecomsecurity_get_service_hero_partner( int $page_id ): array {
	if ( $page_id <= 0 || ! function_exists( 'telecomsecurity_get_partner_by_key' ) ) {
		return array();
	}

	$canonical_id = function_exists( 'telecomsecurity_get_canonical_service_page_id' )
		? telecomsecurity_get_canonical_service_page_id( $page_id )
		: $page_id;
	$service_slug = sanitize_title( (string) get_post_field( 'post_name', $canonical_id ) );
	if ( 'allarmi-scasso-tradizionali-via-radio' !== $service_slug ) {
		return array();
	}

	return telecomsecurity_get_partner_by_key( 'abi' );
}

/**
 * Render a compact, accessible partner mark for the service hero image.
 *
 * @param array $partner Normalized CMS partner data.
 * @return string Safe partner badge markup or an empty string.
 */
function telecomsecurity_render_service_hero_partner( array $partner ): string {
	$logo_id  = absint( $partner['image_id'] ?? 0 );
	$logo_url = trim( (string) ( $partner['logo'] ?? '' ) );
	$alt      = trim( (string) ( $partner['alt'] ?? '' ) );
	if ( ( ! $logo_id && '' === $logo_url ) || '' === $alt ) {
		return '';
	}

	$attributes = array(
		'class'         => 'ts-service-hero__partner-logo',
		'alt'           => '',
		'loading'       => 'eager',
		'decoding'      => 'async',
		'fetchpriority' => 'low',
		'sizes'         => '128px',
	);
	$logo = $logo_id
		? wp_get_attachment_image( $logo_id, 'medium', false, $attributes )
		: sprintf(
			'<img class="%1$s" src="%2$s" alt="" loading="eager" decoding="async" fetchpriority="low">',
			esc_attr( $attributes['class'] ),
			esc_url( $logo_url )
		);
	if ( '' === trim( (string) $logo ) ) {
		return '';
	}

	$label = sprintf( __( 'Partner tecnologico: %s', 'telecomsecurity-child-theme' ), $alt );
	return '<div class="ts-service-hero__partner" role="img" aria-label="' . esc_attr( $label ) . '">' . $logo . '</div>';
}

/**
 * Return the service context derived from the existing CMS relationship.
 *
 * @param int $page_id Page ID. Defaults to the queried object.
 * @return array<string,mixed>
 */
function telecomsecurity_get_service_context( int $page_id = 0 ): array {
	$page_id = $page_id ?: get_queried_object_id();
	if ( ! $page_id ) {
		return array();
	}

	$services = function_exists( 'telecomsecurity_get_services_explorer_data' ) ? telecomsecurity_get_services_explorer_data() : array();
	foreach ( $services as $position => $service ) {
		if ( $page_id !== absint( $service['page_id'] ?? 0 ) ) {
			continue;
		}

		return array(
			'current'    => $service,
			'services'   => $services,
			'position'   => $position,
			'previous'   => $position > 0 ? $services[ $position - 1 ] : null,
			'next'       => isset( $services[ $position + 1 ] ) ? $services[ $position + 1 ] : null,
			'archive_id' => wp_get_post_parent_id( $page_id ),
		);
	}

	// Draft and pending child pages still need the structured editor. Build its
	// related-service choices from the hierarchy without exposing them publicly.
	if ( ! telecomsecurity_is_service_page( $page_id ) ) {
		return array();
	}
	$raw_services = function_exists( 'telecomsecurity_get_raw_services_option' ) ? telecomsecurity_get_raw_services_option() : array();
	$parent_id    = telecomsecurity_get_services_parent_page_id( is_array( $raw_services ) ? $raw_services : array() );
	$services     = telecomsecurity_get_service_editor_services( $page_id );

	return array(
		'current'    => array(
			'page_id' => $page_id,
			'title'   => sanitize_text_field( (string) get_the_title( $page_id ) ),
			'url'     => (string) get_permalink( $page_id ),
		),
		'services'   => $services,
		'position'   => -1,
		'previous'   => null,
		'next'       => null,
		'archive_id' => $parent_id,
	);

}

/** Determine service membership from the page hierarchy, regardless of status. */
function telecomsecurity_is_service_page( int $page_id = 0 ): bool {
	$page_id = $page_id ?: get_queried_object_id();
	$page    = $page_id ? get_post( $page_id ) : null;
	if ( ! $page || 'page' !== get_post_type( $page_id ) || ! function_exists( 'telecomsecurity_get_services_parent_page_id' ) ) {
		return false;
	}

	$raw_services        = function_exists( 'telecomsecurity_get_raw_services_option' ) ? telecomsecurity_get_raw_services_option() : array();
	$parent_id           = telecomsecurity_get_services_parent_page_id( is_array( $raw_services ) ? $raw_services : array() );
	$canonical_parent_id = function_exists( 'telecomsecurity_get_canonical_service_page_id' ) ? telecomsecurity_get_canonical_service_page_id( $parent_id ) : $parent_id;
	$page_parent_id      = absint( $page->post_parent ?? 0 );
	$canonical_page_parent_id = function_exists( 'telecomsecurity_get_canonical_service_page_id' ) ? telecomsecurity_get_canonical_service_page_id( $page_parent_id ) : $page_parent_id;
	return $canonical_parent_id > 0 && $canonical_parent_id === $canonical_page_parent_id;
}

/** Return every service-page status needed by related-service editor controls. */
function telecomsecurity_get_service_editor_services( int $page_id = 0 ): array {
	$services = function_exists( 'telecomsecurity_get_services_explorer_data' ) ? telecomsecurity_get_services_explorer_data() : array();
	if ( $page_id && ! telecomsecurity_is_service_page( $page_id ) ) {
		return $services;
	}

	$raw_services = function_exists( 'telecomsecurity_get_raw_services_option' ) ? telecomsecurity_get_raw_services_option() : array();
	$parent_id    = telecomsecurity_get_services_parent_page_id( is_array( $raw_services ) ? $raw_services : array() );
	if ( ! $parent_id ) {
		return $services;
	}

	$known_ids = array_fill_keys( array_map( 'absint', array_column( $services, 'page_id' ) ), true );
	$pages     = get_pages(
		array(
			'parent'      => $parent_id,
			'post_type'   => 'page',
			'post_status' => array( 'publish', 'draft', 'pending', 'private', 'future' ),
			'sort_column' => 'menu_order,post_title',
			'sort_order'  => 'ASC',
		)
	);
	foreach ( $pages as $service_page ) {
		$service_page_id = absint( $service_page->ID ?? 0 );
		if ( ! $service_page_id || isset( $known_ids[ $service_page_id ] ) ) {
			continue;
		}
		$services[] = array(
			'page_id' => $service_page_id,
			'title'   => sanitize_text_field( (string) get_the_title( $service_page_id ) ),
			'url'     => (string) get_permalink( $service_page_id ),
		);
	}
	return $services;
}

/** Empty shape used by the editor and renderer. */
function telecomsecurity_service_content_defaults(): array {
	return array(
		'overview_title' => '',
		'overview'       => '',
		'includes'       => array(),
		'applications'   => array(),
		'benefits'       => array(),
		'process'        => array(),
		'faqs'           => array(),
		'cta_title'      => '',
		'cta_text'       => '',
		'cta_url'        => '',
		'related_ids'    => array(),
	);
}

/** Sanitize title/description repeater rows and discard empty items. */
function telecomsecurity_sanitize_service_rows( $rows, int $limit = 8 ): array {
	$clean = array();
	foreach ( array_slice( is_array( $rows ) ? $rows : array(), 0, $limit ) as $row ) {
		if ( ! is_array( $row ) ) {
			continue;
		}
		$title       = sanitize_text_field( $row['title'] ?? '' );
		$description = sanitize_textarea_field( $row['description'] ?? '' );
		if ( '' === $title && '' === $description ) {
			continue;
		}
		$clean[] = array(
			'title'       => $title,
			'description' => $description,
		);
	}
	return $clean;
}

/** Sanitize FAQ rows and discard empty items. */
function telecomsecurity_sanitize_service_faqs( $rows ): array {
	$clean = array();
	foreach ( array_slice( is_array( $rows ) ? $rows : array(), 0, 8 ) as $row ) {
		if ( ! is_array( $row ) ) {
			continue;
		}
		$question = sanitize_text_field( $row['question'] ?? '' );
		$answer   = sanitize_textarea_field( $row['answer'] ?? '' );
		if ( '' === $question && '' === $answer ) {
			continue;
		}
		$clean[] = array(
			'question' => $question,
			'answer'   => $answer,
		);
	}
	return $clean;
}

/** Sanitize the single structured service payload. */
function telecomsecurity_sanitize_service_content( $value ): array {
	$value = is_array( $value ) ? $value : array();
	$clean = array(
		'overview_title' => sanitize_text_field( $value['overview_title'] ?? '' ),
		'overview'       => sanitize_textarea_field( $value['overview'] ?? '' ),
		'includes'       => telecomsecurity_sanitize_service_rows( $value['includes'] ?? array(), 6 ),
		'applications'   => telecomsecurity_sanitize_service_rows( $value['applications'] ?? array(), 6 ),
		'benefits'       => telecomsecurity_sanitize_service_rows( $value['benefits'] ?? array(), 6 ),
		'process'        => telecomsecurity_sanitize_service_rows( $value['process'] ?? array(), 6 ),
		'faqs'           => telecomsecurity_sanitize_service_faqs( $value['faqs'] ?? array() ),
		'cta_title'      => sanitize_text_field( $value['cta_title'] ?? '' ),
		'cta_text'       => sanitize_textarea_field( $value['cta_text'] ?? '' ),
		'cta_url'        => esc_url_raw( $value['cta_url'] ?? '' ),
		'related_ids'    => array_values( array_unique( array_filter( array_map( 'absint', (array) ( $value['related_ids'] ?? array() ) ) ) ) ),
	);

	return $clean;
}

/** Register service meta for revisions and the block-editor REST API. */
function telecomsecurity_register_service_content_meta(): void {
	add_post_type_support( 'page', 'excerpt' );

	$row_schema = array(
		'type'       => 'object',
		'properties' => array(
			'title'       => array( 'type' => 'string' ),
			'description' => array( 'type' => 'string' ),
		),
	);
	$faq_schema = array(
		'type'       => 'object',
		'properties' => array(
			'question' => array( 'type' => 'string' ),
			'answer'   => array( 'type' => 'string' ),
		),
	);

	register_post_meta(
		'page',
		TELECOMSECURITY_SERVICE_META_KEY,
		array(
			'type'              => 'object',
			'single'            => true,
			'default'           => telecomsecurity_service_content_defaults(),
			'sanitize_callback' => 'telecomsecurity_sanitize_service_content',
			'auth_callback'     => static function ( $allowed, $meta_key, $object_id ): bool {
				return current_user_can( 'edit_post', (int) $object_id );
			},
			'show_in_rest'      => array(
				'schema' => array(
					'type'       => 'object',
					'properties' => array(
						'overview_title' => array( 'type' => 'string' ),
						'overview'       => array( 'type' => 'string' ),
						'includes'       => array( 'type' => 'array', 'items' => $row_schema ),
						'applications'   => array( 'type' => 'array', 'items' => $row_schema ),
						'benefits'       => array( 'type' => 'array', 'items' => $row_schema ),
						'process'        => array( 'type' => 'array', 'items' => $row_schema ),
						'faqs'           => array( 'type' => 'array', 'items' => $faq_schema ),
						'cta_title'      => array( 'type' => 'string' ),
						'cta_text'       => array( 'type' => 'string' ),
						'cta_url'        => array( 'type' => 'string', 'format' => 'uri' ),
						'related_ids'    => array( 'type' => 'array', 'items' => array( 'type' => 'integer' ) ),
					),
				),
			),
			'revisions_enabled' => true,
		)
	);
}
add_action( 'init', 'telecomsecurity_register_service_content_meta', 20 );

/** Return normalized structured data for a service page. */
function telecomsecurity_get_service_content( int $page_id ): array {
	$saved = get_post_meta( $page_id, TELECOMSECURITY_SERVICE_META_KEY, true );
	return wp_parse_args( is_array( $saved ) ? $saved : array(), telecomsecurity_service_content_defaults() );
}

/** Return selected related services, or derive a small deterministic fallback. */
function telecomsecurity_get_related_services( int $page_id, array $context, int $limit = 3 ): array {
	$data      = telecomsecurity_get_service_content( $page_id );
	$services  = $context['services'] ?? array();
	$by_page   = array();
	$current   = $context['current'] ?? array();
	$preferred = array_values( array_unique( array_map( 'absint', $data['related_ids'] ?? array() ) ) );

	foreach ( $services as $service ) {
		$service_page_id = absint( $service['page_id'] ?? 0 );
		if ( $service_page_id && $service_page_id !== $page_id ) {
			$by_page[ $service_page_id ] = $service;
		}
	}

	if ( empty( $preferred ) ) {
		foreach ( $services as $service ) {
			if ( ( $service['area'] ?? '' ) === ( $current['area'] ?? '' ) ) {
				$preferred[] = absint( $service['page_id'] ?? 0 );
			}
		}
	}

	$related = array();
	foreach ( $preferred as $related_id ) {
		if ( isset( $by_page[ $related_id ] ) ) {
			$related[] = $by_page[ $related_id ];
		}
		if ( count( $related ) >= $limit ) {
			break;
		}
	}

	return $related;
}

/** Output editor-authored plain text as safe paragraphs. */
function telecomsecurity_service_text( string $text ): string {
	return wpautop( esc_html( trim( $text ) ) );
}

/** Count readable words for reports and automated verification. */
function telecomsecurity_service_word_count( int $page_id ): int {
	$data = telecomsecurity_get_service_content( $page_id );
	$text = array( get_post_field( 'post_excerpt', $page_id ), $data['overview'], $data['cta_title'], $data['cta_text'] );
	foreach ( array( 'includes', 'applications', 'benefits', 'process' ) as $group ) {
		foreach ( $data[ $group ] as $row ) {
			$text[] = $row['title'];
			$text[] = $row['description'];
		}
	}
	foreach ( $data['faqs'] as $faq ) {
		$text[] = $faq['question'];
		$text[] = $faq['answer'];
	}
	$plain = wp_strip_all_tags( implode( ' ', $text ) );
	return preg_match_all( "/[\p{L}\p{N}]+(?:[’'-][\p{L}\p{N}]+)*/u", $plain ) ?: 0;
}
