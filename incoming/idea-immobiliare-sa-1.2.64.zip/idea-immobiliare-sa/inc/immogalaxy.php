<?php
/**
 * Esportazione automatica degli immobili su ImmoGalaxy (tracciato XML «immogalaxy.xml»).
 *
 * - Un file al giorno, via FTP, nome «AAAAMMGG.<nome-gestionale>.xml».
 * - Invii incrementali (solo ciò che è cambiato da ieri, con UPDATE e DELETE); il sabato, se attivo, invio completo.
 * - Tutto si imposta da Immobili → Immogalaxy. Spento finché non lo si attiva.
 * - Nessun dato del cliente nel codice: codici, referente, accessi FTP e nome del gestionale stanno nelle opzioni.
 *
 * @package Idea_Immobiliare_SA
 */

if (!defined('ABSPATH')) {
    exit;
}

const IDEA_GX_OPTION = 'idea_immo_gx';
const IDEA_GX_LOG    = 'idea_immo_gx_log';
const IDEA_GX_CRON   = 'idea_immo_gx_daily';

/* ───────────────────────── Impostazioni ───────────────────────── */

function idea_gx_defaults()
{
    return array(
        'enabled'       => 0,
        'offerente'     => '',        // codice dell'agenzia presso ImmoGalaxy (<offerente><codice_univoco>)
        'contact_code'  => '',        // codice della persona di contatto
        'contact_first' => '',
        'contact_last'  => '',
        'contact_zip'   => '',
        'contact_city'  => '',
        'contact_addr'  => '',
        'contact_nr'    => '',
        'canton'        => 'Ticino',  // cantone di partenza per gli immobili senza cantone
        'name'          => '',        // nome-gestionale nel nome del file
        'ftp_host'      => '',
        'ftp_user'      => '',
        'ftp_pass'      => '',
        'ftp_dir'       => '',
        'ftp_ssl'       => 0,
        'full_saturday' => 1,
        'window'        => 1,         // invii automatici solo tra le 00:01 e le 01:29
        'notify'        => '',
        'next_id'       => 3000,      // contatore dei codici per i nuovi immobili
    );
}

function idea_gx_opts()
{
    $o = get_option(IDEA_GX_OPTION, array());
    return wp_parse_args(is_array($o) ? $o : array(), idea_gx_defaults());
}

function idea_gx_ready(&$missing = null)
{
    $o = idea_gx_opts();
    $missing = array();
    $need = array(
        'offerente'     => __('Codice agenzia ImmoGalaxy', 'idea-immobiliare-sa'),
        'contact_first' => __('Nome del referente', 'idea-immobiliare-sa'),
        'contact_last'  => __('Cognome del referente', 'idea-immobiliare-sa'),
        'name'          => __('Nome del gestionale (nel nome del file)', 'idea-immobiliare-sa'),
    );
    foreach ($need as $k => $label) {
        if (trim((string) $o[$k]) === '') {
            $missing[] = $label;
        }
    }
    return !$missing;
}

function idea_gx_ftp_ready()
{
    $o = idea_gx_opts();
    return $o['ftp_host'] !== '' && $o['ftp_user'] !== '' && $o['ftp_pass'] !== '';
}

/* ───────────────────────── Dati dell'immobile ───────────────────────── */

/** Codice stabile dell'immobile verso ImmoGalaxy (non deve mai cambiare). */
function idea_gx_export_id($post_id)
{
    $id = (string) get_post_meta($post_id, '_idea_export_id', true);
    if ($id !== '') {
        return $id;
    }
    $o = idea_gx_opts();
    $n = max(3000, (int) $o['next_id']);
    $o['next_id'] = $n + 1;
    update_option(IDEA_GX_OPTION, $o, false);
    update_post_meta($post_id, '_idea_export_id', (string) $n);
    return (string) $n;
}

/** Categoria ImmoGalaxy (1–11) dai termini «Categorie» dell'immobile; 0 se non riconosciuta. */
function idea_gx_category_code($post_id)
{
    $map = apply_filters('idea_gx_category_map', array(
        'rustici' => 1, 'case' => 2, 'appartamenti' => 3, 'locali-commerciali' => 4, 'uffici' => 4, 'progetti' => 5,
        'terreni' => 6, 'ville' => 7, 'stabili-di-reddito' => 8, 'garages' => 9, 'parcheggi' => 9,
        'bar-ristoranti-hotel' => 10, 'attici' => 11,
    ));
    $slugs = wp_get_object_terms($post_id, 'categoria_immobile', array('fields' => 'slugs'));
    if (is_wp_error($slugs)) {
        return 0;
    }
    foreach ($slugs as $s) {
        if (isset($map[$s])) {
            return (int) $map[$s];
        }
    }
    return idea_gx_category_from_title(get_the_title($post_id));
}

/** Senza un tipo tra le categorie (es. solo «Affitto»), lo deduce dal titolo: meglio un annuncio in più che uno bloccato. */
function idea_gx_category_from_title($title)
{
    $rules = array(
        '/\battic/i' => 11, '/\bville?\b|\bvilla\b/i' => 7, '/\bcasa\b|\bcase\b|\bvillett/i' => 2,
        '/\bappartament|\bmonolocal|\bstudio\b|\bduplex\b/i' => 3, '/\bterren/i' => 6, '/\brustic/i' => 1,
        '/\buffic|\bnegozi|\bmagazzin|\blocale commerciale/i' => 4, '/\bgarage|\bposteggi|\bparcheggi/i' => 9,
    );
    foreach ($rules as $re => $code) {
        if (preg_match($re, (string) $title)) {
            return $code;
        }
    }
    return 0;
}

function idea_gx_is_rent($post_id)
{
    if (idea_immo_offer($post_id) === 'affitto') {
        return true;
    }
    $slugs = wp_get_object_terms($post_id, 'categoria_immobile', array('fields' => 'slugs'));
    return !is_wp_error($slugs) && in_array('affitto', $slugs, true);
}

/** Estrae il numero (metri) da testi come «100 m» o «300». */
function idea_gx_meters($text)
{
    return preg_match('/\d+/', (string) $text, $m) ? (int) $m[0] : 0;
}

/** Valore dai «Dati aggiuntivi» (etichetta libera) cercando una parola. */
function idea_gx_extra($post_id, $pattern)
{
    $extra = get_post_meta($post_id, '_idea_extra', true);
    if (is_array($extra)) {
        foreach ($extra as $label => $value) {
            if (preg_match($pattern, (string) $label)) {
                return preg_match('/\d+/', (string) $value, $m) ? (int) $m[0] : 0;
            }
        }
    }
    return 0;
}

function idea_gx_availability($text)
{
    $t = strtolower(trim((string) $text));
    if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $t)) {
        return $t;
    }
    if (preg_match('/^(\d{1,2})[.\/](\d{1,2})[.\/](\d{4})$/', $t, $m)) {
        return sprintf('%04d-%02d-%02d', $m[3], $m[2], $m[1]);
    }
    return strpos($t, 'subito') !== false ? 'da subito' : 'da concordare';
}

/** Descrizione in testo semplice: ImmoGalaxy accetta solo <BR> e <UL><LI>. */
function idea_gx_description($post)
{
    $html = $post->post_content !== '' ? $post->post_content : ($post->post_excerpt !== '' ? $post->post_excerpt : $post->post_title);
    $html = strip_shortcodes($html);
    $html = preg_replace('#</(p|div|h[1-6])>#i', "\n", $html);
    $html = preg_replace('#<br\s*/?>#i', "\n", $html);
    $text = html_entity_decode(wp_strip_all_tags($html), ENT_QUOTES, 'UTF-8');
    $text = trim(preg_replace("/[ \t]+/", ' ', preg_replace("/\n{2,}/", "\n", $text)));
    return str_replace("\n", "<BR>\n", $text);
}

/** Foto da inviare: al massimo 12, la prima è la copertina. */
function idea_gx_photos($post_id)
{
    $ids = idea_immo_gallery_ids($post_id);
    $out = array();
    foreach (array_slice($ids, 0, 12) as $att) {
        $meta = wp_get_attachment_metadata($att);
        $url  = (is_array($meta) && isset($meta['sizes']['1536x1536'])) ? wp_get_attachment_image_url($att, '1536x1536') : wp_get_attachment_url($att);
        if ($url) {
            $out[] = array('url' => $url, 'caption' => wp_get_attachment_caption($att));
        }
    }
    return $out;
}

/** Elenco dei problemi che impediscono l'invio di un immobile (testi per l'utente). */
function idea_gx_problems($post)
{
    $id = $post->ID;
    $p  = array();
    if (!preg_match('/^\d{4}$/', trim((string) get_post_meta($id, '_idea_zip', true)))) {
        $p[] = __('manca il NAP (codice postale a 4 cifre)', 'idea-immobiliare-sa');
    }
    if (trim((string) get_post_meta($id, '_idea_location', true)) === '') {
        $p[] = __('manca la località', 'idea-immobiliare-sa');
    }
    if (!idea_gx_category_code($id)) {
        $p[] = __('categoria non riconosciuta da ImmoGalaxy', 'idea-immobiliare-sa');
    }
    if (!idea_gx_photos($id)) {
        $p[] = __('serve almeno una foto', 'idea-immobiliare-sa');
    }
    return $p;
}

/** L'immobile va su ImmoGalaxy? (pubblicato, non archivio, non escluso a mano) */
function idea_gx_wanted($post)
{
    return $post->post_status === 'publish'
        && !in_array(idea_immo_status($post->ID), array('archivio', 'venduto'), true)
        && (string) get_post_meta($post->ID, '_idea_gx', true) !== '0';
}

/* ───────────────────────── Costruzione dell'XML ───────────────────────── */

function idea_gx_tag(XMLWriter $w, $name, $value, $attrs = array())
{
    $w->startElement($name);
    foreach ($attrs as $k => $v) {
        $w->writeAttribute($k, $v);
    }
    $w->text((string) $value);
    $w->endElement();
}

function idea_gx_phone_parts($phone)
{
    // «+41 91 840 20 10» → prefisso «0041 91», numero «840 20 10»
    $phone = trim((string) $phone);
    if (preg_match('/^(?:\+|00)\s*41\s*\(?0?(\d{2})\)?\s*(.+)$/', $phone, $m)) {
        return array('0041 ' . $m[1], trim($m[2]));
    }
    if (preg_match('/^0(\d{2})\s*(.+)$/', $phone, $m)) {
        return array('0041 ' . $m[1], trim($m[2]));
    }
    return array('', trim((string) $phone));
}

/** Nodo <immobile> in XML (stringa) per un post e un'azione UPDATE/DELETE. */
function idea_gx_immobile_xml($post, $action)
{
    $id = $post->ID;
    $o  = idea_gx_opts();
    $c  = idea_immo_contact();
    $get = function ($k) use ($id) {
        return trim((string) get_post_meta($id, $k, true));
    };
    list($pre, $tel) = idea_gx_phone_parts($c['phone']);
    $rent  = idea_gx_is_rent($id);
    $price = (float) $get('_idea_price');
    $w = new XMLWriter();
    $w->openMemory();
    $w->setIndent(true);
    $w->setIndentString("\t");
    $w->startElement('immobile');

    $w->startElement('persona_contatto');
    idea_gx_tag($w, 'codice_univoco', $o['contact_code'] !== '' ? $o['contact_code'] : '1');
    idea_gx_tag($w, 'email', $c['email']);
    idea_gx_tag($w, 'telefono', $tel);
    idea_gx_tag($w, 'prefisso_telefono', $pre);
    idea_gx_tag($w, 'nome', $o['contact_first']);
    idea_gx_tag($w, 'cognome', $o['contact_last']);
    idea_gx_tag($w, 'nap', $o['contact_zip']);
    idea_gx_tag($w, 'localita', $o['contact_city']);
    idea_gx_tag($w, 'indirizzo1', $o['contact_addr']);
    idea_gx_tag($w, 'nr', $o['contact_nr']);
    idea_gx_tag($w, 'cantone', $o['canton']);
    idea_gx_tag($w, 'nazione_iso', 'CH');
    $w->endElement();

    $w->startElement('descrizione');
    $w->writeAttribute('lingua', 'italiano');
    $w->writeCData(idea_gx_description($post));
    $w->endElement();

    idea_gx_tag($w, 'categoria_oggetto', idea_gx_category_code($id));
    idea_gx_tag($w, 'nap', $get('_idea_zip'));
    idea_gx_tag($w, 'localita', $get('_idea_location'));
    idea_gx_tag($w, 'indirizzo1', $get('_idea_address'));
    idea_gx_tag($w, 'indirizzo2', '');
    idea_gx_tag($w, 'nr', '');
    idea_gx_tag($w, 'cantone', $get('_idea_canton') !== '' ? $get('_idea_canton') : $o['canton']);
    idea_gx_tag($w, 'nazione_iso', 'CH');

    $w->startElement('prezzo');
    idea_gx_tag($w, 'tipo', $rent ? 1 : 2);
    idea_gx_tag($w, 'modello', $rent ? 9 : 1);
    idea_gx_tag($w, 'prezzo_base', $price > 0 ? (int) round($price) : 0);
    idea_gx_tag($w, 'spese', 0);
    idea_gx_tag($w, 'valuta_iso', 'CHF');
    $w->endElement();

    $w->startElement('superfici');
    idea_gx_tag($w, 'abitabile_m2', (int) round((float) $get('_idea_surface')));
    idea_gx_tag($w, 'abitabile_m3', 0);
    idea_gx_tag($w, 'terrazze_m2', (int) round((float) $get('_idea_terrace')));
    idea_gx_tag($w, 'terreno_m2', (int) round((float) $get('_idea_land')));
    idea_gx_tag($w, 'giardino_m2', (int) round((float) $get('_idea_garden')));
    $w->endElement();

    idea_gx_tag($w, 'numero_piani', idea_gx_extra($id, '/numero\s+piani|^piani$/i'));
    idea_gx_tag($w, 'numero_locali', $get('_idea_rooms') !== '' ? idea_immo_trim_number($get('_idea_rooms')) : 0);
    idea_gx_tag($w, 'numero_appartamenti', idea_gx_extra($id, '/numero\s+appartamenti|^appartamenti$/i'));

    $w->startElement('distanze');
    idea_gx_tag($w, 'trasporti_m', idea_gx_meters($get('_idea_transport')));
    idea_gx_tag($w, 'negozi_m', idea_gx_meters($get('_idea_shops')));
    $w->endElement();

    idea_gx_tag($w, 'titolo_annuncio', html_entity_decode(get_the_title($post), ENT_QUOTES, 'UTF-8'));

    $w->startElement('allegati');
    foreach (idea_gx_photos($id) as $ph) {
        $w->startElement('allegato');
        $w->writeAttribute('tipo', 'jpg');
        idea_gx_tag($w, 'descrizione', $ph['caption']);
        idea_gx_tag($w, 'url', $ph['url']);
        $w->endElement();
    }
    $w->endElement();

    idea_gx_tag($w, 'disponibilita', idea_gx_availability($get('_idea_availability')));

    $w->startElement('automatismi');
    idea_gx_tag($w, 'codice_univoco_immobile', idea_gx_export_id($id));
    $w->startElement('azione');
    $w->writeAttribute('tipo', $action);
    $w->endElement();
    $w->endElement();

    $w->endElement();
    return $w->outputMemory();
}

/**
 * Prepara un invio: ['xml', 'type', 'items' => [post_id => ['action','hash']], 'skipped' => [titolo => problemi]]
 * $type: 'incr' (cambiati da ieri) oppure 'full' (tutti gli immobili attivi).
 */
function idea_gx_build($type = 'incr')
{
    $type = $type === 'full' ? 'full' : 'incr';
    $o    = idea_gx_opts();
    $posts = get_posts(array(
        'post_type'      => 'immobile',
        'post_status'    => array('publish', 'draft', 'pending', 'private', 'trash'),
        'posts_per_page' => -1,
        'orderby'        => 'ID',
        'order'          => 'ASC',
        'no_found_rows'  => true,
    ));
    $nodes = array();
    $items = array();
    $skipped = array();
    foreach ($posts as $post) {
        $sent = (string) get_post_meta($post->ID, '_idea_gx_hash', true);
        if (idea_gx_wanted($post)) {
            $problems = idea_gx_problems($post);
            if ($problems) {
                $skipped[$post->ID] = array('title' => get_the_title($post), 'problems' => $problems);
                continue;
            }
            $xml  = idea_gx_immobile_xml($post, 'UPDATE');
            $hash = md5(preg_replace('#<azione[^>]*/>#', '', $xml));
            if ($type === 'full' || $hash !== $sent) {
                $nodes[] = $xml;
                $items[$post->ID] = array('action' => 'UPDATE', 'hash' => $hash);
            }
        } elseif ($sent !== '' && $type === 'incr') {
            // era stato inviato ed ora non è più in vendita: sospensione su ImmoGalaxy
            $nodes[] = idea_gx_immobile_xml($post, 'DELETE');
            $items[$post->ID] = array('action' => 'DELETE', 'hash' => '');
        }
    }
    $xml  = '<?xml version="1.0" encoding="UTF-8"?>' . "\n<offerente>\n";
    $xml .= "\t" . '<trasmissione tipo="' . $type . '"/>' . "\n";
    $xml .= "\t<codice_univoco>" . esc_html($o['offerente']) . "</codice_univoco>\n";
    foreach ($nodes as $n) {
        $xml .= rtrim($n) . "\n";
    }
    $xml .= "</offerente>\n";
    return array('xml' => $xml, 'type' => $type, 'items' => $items, 'skipped' => $skipped, 'count' => count($nodes));
}

/** Dopo un invio riuscito: ricorda cosa è stato inviato (serve agli invii incrementali). */
function idea_gx_commit($items)
{
    foreach ($items as $post_id => $it) {
        if ($it['action'] === 'DELETE') {
            delete_post_meta($post_id, '_idea_gx_hash');
        } else {
            update_post_meta($post_id, '_idea_gx_hash', $it['hash']);
        }
    }
}

/* ───────────────────────── Invio FTP ───────────────────────── */

function idea_gx_filename()
{
    $o = idea_gx_opts();
    return wp_date('Ymd') . '.' . sanitize_file_name($o['name']) . '.xml';
}

/** Carica il file via FTP (cURL). Restituisce true oppure un testo d'errore. */
function idea_gx_upload($xml, $filename)
{
    $o = idea_gx_opts();
    if (!function_exists('curl_init')) {
        return __('cURL non disponibile sul server', 'idea-immobiliare-sa');
    }
    $dir = trim((string) $o['ftp_dir'], '/');
    $url = ($o['ftp_ssl'] ? 'ftps' : 'ftp') . '://' . $o['ftp_host'] . '/' . ($dir !== '' ? $dir . '/' : '') . rawurlencode($filename);
    if (!function_exists('wp_tempnam')) {
        require_once ABSPATH . 'wp-admin/includes/file.php';
    }
    $tmp = wp_tempnam($filename);
    file_put_contents($tmp, $xml);
    $fh = fopen($tmp, 'r');
    $ch = curl_init($url);
    curl_setopt_array($ch, array(
        CURLOPT_UPLOAD       => true,
        CURLOPT_INFILE       => $fh,
        CURLOPT_INFILESIZE   => filesize($tmp),
        CURLOPT_USERPWD      => $o['ftp_user'] . ':' . $o['ftp_pass'],
        CURLOPT_FTP_CREATE_MISSING_DIRS => 0,
        CURLOPT_TIMEOUT      => 60,
        CURLOPT_CONNECTTIMEOUT => 20,
        CURLOPT_RETURNTRANSFER => true,
    ));
    if ($o['ftp_ssl']) {
        curl_setopt($ch, CURLOPT_USE_SSL, CURLUSESSL_ALL);
    }
    $ok  = curl_exec($ch);
    $err = $ok === false ? curl_error($ch) : '';
    curl_close($ch);
    fclose($fh);
    @unlink($tmp);
    return $ok === false ? ($err !== '' ? $err : __('invio non riuscito', 'idea-immobiliare-sa')) : true;
}

/** Prova il collegamento FTP (accesso e cartella) senza inviare nulla. Restituisce true oppure un testo d'errore. */
function idea_gx_test()
{
    $o = idea_gx_opts();
    if (!idea_gx_ftp_ready()) {
        return __('Compila server, utente e password FTP e salva.', 'idea-immobiliare-sa');
    }
    if (!function_exists('curl_init')) {
        return __('cURL non disponibile sul server', 'idea-immobiliare-sa');
    }
    $dir = trim((string) $o['ftp_dir'], '/');
    $ch  = curl_init(($o['ftp_ssl'] ? 'ftps' : 'ftp') . '://' . $o['ftp_host'] . '/' . ($dir !== '' ? $dir . '/' : ''));
    curl_setopt_array($ch, array(
        CURLOPT_USERPWD        => $o['ftp_user'] . ':' . $o['ftp_pass'],
        CURLOPT_FTPLISTONLY    => true,
        CURLOPT_TIMEOUT        => 30,
        CURLOPT_CONNECTTIMEOUT => 15,
        CURLOPT_RETURNTRANSFER => true,
    ));
    if ($o['ftp_ssl']) {
        curl_setopt($ch, CURLOPT_USE_SSL, CURLUSESSL_ALL);
    }
    $ok  = curl_exec($ch);
    $err = $ok === false ? curl_error($ch) : '';
    curl_close($ch);
    return $ok === false ? ($err !== '' ? $err : __('collegamento non riuscito', 'idea-immobiliare-sa')) : true;
}

function idea_gx_log($status, $message, $extra = array())
{
    $log = get_option(IDEA_GX_LOG, array());
    $log = is_array($log) ? $log : array();
    array_unshift($log, array_merge(array('t' => time(), 'status' => $status, 'msg' => $message), $extra));
    update_option(IDEA_GX_LOG, array_slice($log, 0, 30), false);
}

/**
 * Esegue un invio. $manual: da pulsante (ignora la finestra oraria). Restituisce ['ok'=>bool,'msg'=>string].
 */
function idea_gx_run($manual = false, $force_type = '')
{
    $o = idea_gx_opts();
    if (!idea_gx_ready($missing)) {
        $r = array('ok' => false, 'msg' => sprintf(__('Mancano dei dati: %s.', 'idea-immobiliare-sa'), implode(', ', $missing)));
        idea_gx_log('error', $r['msg']);
        return $r;
    }
    if (!idea_gx_ftp_ready()) {
        $r = array('ok' => false, 'msg' => __('Mancano gli accessi FTP di ImmoGalaxy.', 'idea-immobiliare-sa'));
        idea_gx_log('error', $r['msg']);
        return $r;
    }
    if (!$manual && $o['window']) {
        $now = (int) wp_date('Hi');
        if ($now < 1 || $now > 129) {
            $r = array('ok' => false, 'msg' => sprintf(__('Fuori dalla finestra di invio (00:01–01:29): ora %s. Riprova domani.', 'idea-immobiliare-sa'), wp_date('H:i')));
            idea_gx_log('skipped', $r['msg']);
            idea_gx_notify($r['msg']);
            return $r;
        }
    }
    $type = $force_type ?: ($o['full_saturday'] && (int) wp_date('N') === 6 ? 'full' : 'incr');
    $b = idea_gx_build($type);
    if ($b['count'] === 0) {
        $r = array('ok' => true, 'msg' => __('Niente da inviare oggi: nessuna novità.', 'idea-immobiliare-sa'));
        idea_gx_log('ok', $r['msg'], array('type' => $type, 'count' => 0, 'skipped' => count($b['skipped'])));
        idea_gx_notify($r['msg'], $b);
        return $r;
    }
    $file = idea_gx_filename();
    $res  = idea_gx_upload($b['xml'], $file);
    if ($res !== true) {
        $r = array('ok' => false, 'msg' => sprintf(__('Invio non riuscito: %s', 'idea-immobiliare-sa'), $res));
        idea_gx_log('error', $r['msg'], array('type' => $type, 'file' => $file));
        idea_gx_notify($r['msg'], $b);
        return $r;
    }
    idea_gx_commit($b['items']);
    $r = array('ok' => true, 'msg' => sprintf(__('Inviato %1$s con %2$d immobili (%3$s).', 'idea-immobiliare-sa'), $file, $b['count'], $type === 'full' ? __('completo', 'idea-immobiliare-sa') : __('solo novità', 'idea-immobiliare-sa')));
    idea_gx_log('ok', $r['msg'], array('type' => $type, 'file' => $file, 'count' => $b['count'], 'skipped' => count($b['skipped'])));
    idea_gx_notify($r['msg'], $b);
    return $r;
}

function idea_gx_notify($message, $build = null)
{
    $o  = idea_gx_opts();
    $to = $o['notify'] !== '' ? $o['notify'] : get_option('admin_email');
    if (!is_email($to)) {
        return;
    }
    $body = $message . "\n";
    if (is_array($build) && !empty($build['skipped'])) {
        $body .= "\n" . __('Immobili non inviati (da completare):', 'idea-immobiliare-sa') . "\n";
        foreach ($build['skipped'] as $s) {
            $body .= '- ' . $s['title'] . ': ' . implode(', ', $s['problems']) . "\n";
        }
    }
    wp_mail($to, sprintf('[%s] ImmoGalaxy', get_bloginfo('name')), $body);
}

/* ───────────────────────── Pianificazione ───────────────────────── */

add_action('init', function () {
    $o = idea_gx_opts();
    $next = wp_next_scheduled(IDEA_GX_CRON);
    if ($o['enabled'] && !$next) {
        $ts = strtotime('tomorrow 00:20', current_time('timestamp'));
        wp_schedule_event($ts - (int) get_option('gmt_offset') * HOUR_IN_SECONDS, 'daily', IDEA_GX_CRON);
    } elseif (!$o['enabled'] && $next) {
        wp_clear_scheduled_hook(IDEA_GX_CRON);
    }
});
add_action(IDEA_GX_CRON, function () {
    idea_gx_run(false);
});

/* ───────────────────────── Schermata di gestione ───────────────────────── */

add_action('admin_menu', function () {
    add_submenu_page('edit.php?post_type=immobile', __('Immogalaxy', 'idea-immobiliare-sa'), __('Immogalaxy', 'idea-immobiliare-sa'), 'manage_options', 'idea-immogalaxy', 'idea_gx_page');
});

add_action('admin_post_idea_gx_download', function () {
    if (!current_user_can('manage_options') || !wp_verify_nonce(isset($_GET['_wpnonce']) ? sanitize_text_field(wp_unslash($_GET['_wpnonce'])) : '', 'idea_gx_download')) {
        wp_die(esc_html__('Non autorizzato.', 'idea-immobiliare-sa'));
    }
    $type = isset($_GET['type']) && $_GET['type'] === 'incr' ? 'incr' : 'full';
    $b    = idea_gx_build($type);
    nocache_headers();
    header('Content-Type: application/xml; charset=UTF-8');
    header('Content-Disposition: attachment; filename="' . idea_gx_filename() . '"');
    echo $b['xml']; // phpcs:ignore WordPress.Security.EscapeOutput
    exit;
});

add_action('admin_post_idea_gx_save', function () {
    if (!current_user_can('manage_options') || !wp_verify_nonce(isset($_POST['_wpnonce']) ? sanitize_text_field(wp_unslash($_POST['_wpnonce'])) : '', 'idea_gx_save')) {
        wp_die(esc_html__('Non autorizzato.', 'idea-immobiliare-sa'));
    }
    $o   = idea_gx_opts();
    $in  = isset($_POST['gx']) ? (array) wp_unslash($_POST['gx']) : array();
    foreach (array('offerente', 'contact_code', 'contact_first', 'contact_last', 'contact_zip', 'contact_city', 'contact_addr', 'contact_nr', 'canton', 'name', 'ftp_host', 'ftp_user', 'ftp_dir') as $k) {
        $o[$k] = isset($in[$k]) ? sanitize_text_field($in[$k]) : $o[$k];
    }
    $o['name']     = preg_replace('/[^A-Za-z0-9._-]/', '', $o['name']);
    $o['ftp_host'] = preg_replace('#^[a-z]+://#i', '', $o['ftp_host']);
    if (isset($in['ftp_pass']) && $in['ftp_pass'] !== '') {
        $o['ftp_pass'] = (string) $in['ftp_pass']; // vuoto = si tiene quella già salvata
    }
    $o['notify']        = isset($in['notify']) && is_email($in['notify']) ? sanitize_email($in['notify']) : '';
    foreach (array('enabled', 'ftp_ssl', 'full_saturday', 'window') as $k) {
        $o[$k] = !empty($in[$k]) ? 1 : 0;
    }
    update_option(IDEA_GX_OPTION, $o, false);
    wp_safe_redirect(add_query_arg(array('post_type' => 'immobile', 'page' => 'idea-immogalaxy', 'saved' => 1), admin_url('edit.php')));
    exit;
});

add_action('admin_post_idea_gx_test', function () {
    if (!current_user_can('manage_options') || !wp_verify_nonce(isset($_POST['_wpnonce']) ? sanitize_text_field(wp_unslash($_POST['_wpnonce'])) : '', 'idea_gx_test')) {
        wp_die(esc_html__('Non autorizzato.', 'idea-immobiliare-sa'));
    }
    $r  = idea_gx_test();
    $ok = $r === true;
    $msg = $ok ? __('Collegamento riuscito: utente e password sono corretti, ImmoGalaxy risponde. Non è stato inviato nulla.', 'idea-immobiliare-sa')
               : sprintf(__('Collegamento non riuscito: %s', 'idea-immobiliare-sa'), $r);
    wp_safe_redirect(add_query_arg(array('post_type' => 'immobile', 'page' => 'idea-immogalaxy', 'sent' => $ok ? 1 : 0, 'msg' => rawurlencode($msg)), admin_url('edit.php')));
    exit;
});

add_action('admin_post_idea_gx_send', function () {
    if (!current_user_can('manage_options') || !wp_verify_nonce(isset($_POST['_wpnonce']) ? sanitize_text_field(wp_unslash($_POST['_wpnonce'])) : '', 'idea_gx_send')) {
        wp_die(esc_html__('Non autorizzato.', 'idea-immobiliare-sa'));
    }
    $type = isset($_POST['type']) && $_POST['type'] === 'full' ? 'full' : 'incr';
    $r = idea_gx_run(true, $type);
    wp_safe_redirect(add_query_arg(array('post_type' => 'immobile', 'page' => 'idea-immogalaxy', 'sent' => $r['ok'] ? 1 : 0, 'msg' => rawurlencode($r['msg'])), admin_url('edit.php')));
    exit;
});

function idea_gx_page()
{
    if (!current_user_can('manage_options')) {
        return;
    }
    $o = idea_gx_opts();
    $ready = idea_gx_ready($missing);
    $b = idea_gx_build('incr');
    $f = idea_gx_build('full');
    $log = get_option(IDEA_GX_LOG, array());
    $next = wp_next_scheduled(IDEA_GX_CRON);
    $field = function ($key, $label, $help = '', $type = 'text', $ph = '') use ($o) {
        printf(
            '<p class="idea-gx__f"><label for="gx_%1$s">%2$s</label><input id="gx_%1$s" type="%3$s" name="gx[%1$s]" value="%4$s" placeholder="%5$s" autocomplete="off">%6$s</p>',
            esc_attr($key), esc_html($label), esc_attr($type), esc_attr($type === 'password' ? '' : $o[$key]), esc_attr($ph),
            $help !== '' ? '<small>' . esc_html($help) . '</small>' : ''
        );
    };
    ?>
    <div class="wrap idea-gx">
        <style>
            .idea-gx__card{background:#fff;border:1px solid #dcdcde;border-radius:10px;padding:20px 24px;margin:16px 0;max-width:880px}
            .idea-gx__card h2{margin-top:0}
            .idea-gx__f{display:grid;grid-template-columns:240px 1fr;gap:4px 16px;align-items:center;margin:10px 0}
            .idea-gx__f small{grid-column:2;color:#646970}
            .idea-gx__f input[type=text],.idea-gx__f input[type=password],.idea-gx__f input[type=email]{width:100%;max-width:380px}
            .idea-gx__state{display:flex;gap:14px;flex-wrap:wrap}
            .idea-gx__kpi{background:#f6f7f7;border-radius:8px;padding:10px 16px;min-width:140px}
            .idea-gx__kpi strong{display:block;font-size:22px}
            .idea-gx__ok{color:#00a32a}.idea-gx__ko{color:#d63638}
            .idea-gx table{border-collapse:collapse;width:100%}.idea-gx td,.idea-gx th{padding:6px 8px;text-align:left;border-bottom:1px solid #eee;vertical-align:top}
        </style>
        <h1><?php esc_html_e('Immogalaxy', 'idea-immobiliare-sa'); ?></h1>
        <p><?php esc_html_e('Gli immobili in vendita vengono inviati ogni notte a ImmoGalaxy: gli immobili nuovi o modificati vengono aggiornati, quelli archiviati o tolti dal sito vengono sospesi.', 'idea-immobiliare-sa'); ?></p>

        <?php if (isset($_GET['saved'])) : // phpcs:ignore WordPress.Security.NonceVerification ?><div class="notice notice-success is-dismissible"><p><?php esc_html_e('Impostazioni salvate.', 'idea-immobiliare-sa'); ?></p></div><?php endif; ?>
        <?php if (isset($_GET['msg'])) : // phpcs:ignore WordPress.Security.NonceVerification ?><div class="notice notice-<?php echo !empty($_GET['sent']) ? 'success' : 'error'; ?> is-dismissible"><p><?php echo esc_html(rawurldecode(sanitize_text_field(wp_unslash($_GET['msg'])))); // phpcs:ignore WordPress.Security.NonceVerification ?></p></div><?php endif; ?>

        <div class="idea-gx__card">
            <h2><?php esc_html_e('Situazione', 'idea-immobiliare-sa'); ?></h2>
            <div class="idea-gx__state">
                <div class="idea-gx__kpi"><strong class="<?php echo $o['enabled'] && $ready && idea_gx_ftp_ready() ? 'idea-gx__ok' : 'idea-gx__ko'; ?>"><?php echo $o['enabled'] ? esc_html__('Attivo', 'idea-immobiliare-sa') : esc_html__('Spento', 'idea-immobiliare-sa'); ?></strong><?php esc_html_e('invio automatico', 'idea-immobiliare-sa'); ?></div>
                <div class="idea-gx__kpi"><strong><?php echo (int) $f['count']; ?></strong><?php esc_html_e('immobili pronti', 'idea-immobiliare-sa'); ?></div>
                <div class="idea-gx__kpi"><strong><?php echo (int) $b['count']; ?></strong><?php esc_html_e('da inviare stanotte', 'idea-immobiliare-sa'); ?></div>
                <div class="idea-gx__kpi"><strong class="<?php echo $f['skipped'] ? 'idea-gx__ko' : 'idea-gx__ok'; ?>"><?php echo count($f['skipped']); ?></strong><?php esc_html_e('da completare', 'idea-immobiliare-sa'); ?></div>
            </div>
            <?php if ($o['enabled'] && $next) : ?><p><?php printf(esc_html__('Prossimo invio: %s', 'idea-immobiliare-sa'), esc_html(wp_date('d.m.Y H:i', $next))); ?></p><?php endif; ?>
            <?php if (!$ready) : ?><p class="idea-gx__ko"><?php echo esc_html(sprintf(__('Per attivare mancano: %s.', 'idea-immobiliare-sa'), implode(', ', $missing))); ?></p><?php endif; ?>
            <?php if ($f['skipped']) : ?>
                <h3><?php esc_html_e('Immobili che non partono finché non li completi', 'idea-immobiliare-sa'); ?></h3>
                <table><?php foreach ($f['skipped'] as $pid => $s) : ?><tr><td><a href="<?php echo esc_url(get_edit_post_link($pid)); ?>"><?php echo esc_html($s['title']); ?></a></td><td><?php echo esc_html(implode(', ', $s['problems'])); ?></td></tr><?php endforeach; ?></table>
            <?php endif; ?>
        </div>

        <form class="idea-gx__card" method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
            <h2><?php esc_html_e('Impostazioni', 'idea-immobiliare-sa'); ?></h2>
            <input type="hidden" name="action" value="idea_gx_save">
            <?php wp_nonce_field('idea_gx_save'); ?>
            <p class="idea-gx__f"><label for="gx_enabled"><?php esc_html_e('Invio automatico', 'idea-immobiliare-sa'); ?></label><span><input id="gx_enabled" type="checkbox" name="gx[enabled]" value="1" <?php checked($o['enabled']); ?>> <?php esc_html_e('Invia ogni notte gli immobili a ImmoGalaxy', 'idea-immobiliare-sa'); ?></span></p>
            <h3><?php esc_html_e('Agenzia', 'idea-immobiliare-sa'); ?></h3>
            <?php
            $field('offerente', __('Codice agenzia', 'idea-immobiliare-sa'), __('Il codice con cui ImmoGalaxy conosce l’agenzia (<codice_univoco>).', 'idea-immobiliare-sa'));
            $field('name', __('Nome del gestionale', 'idea-immobiliare-sa'), __('Compare nel nome del file: AAAAMMGG.nome.xml. Lo comunica ImmoGalaxy.', 'idea-immobiliare-sa'));
            $field('contact_code', __('Codice del referente', 'idea-immobiliare-sa'));
            $field('contact_first', __('Nome del referente', 'idea-immobiliare-sa'));
            $field('contact_last', __('Cognome del referente', 'idea-immobiliare-sa'));
            $field('contact_addr', __('Indirizzo del referente', 'idea-immobiliare-sa'));
            $field('contact_zip', __('NAP del referente', 'idea-immobiliare-sa'));
            $field('contact_city', __('Località del referente', 'idea-immobiliare-sa'));
            $field('canton', __('Cantone predefinito', 'idea-immobiliare-sa'), __('Per gli immobili senza cantone. Email e telefono sono quelli di ticinoWEB CMS → Contatti.', 'idea-immobiliare-sa'));
            ?>
            <h3><?php esc_html_e('Collegamento FTP', 'idea-immobiliare-sa'); ?></h3>
            <?php
            $field('ftp_host', __('Server FTP', 'idea-immobiliare-sa'), __('Lo indica ImmoGalaxy, es. www.immogalaxy.ch', 'idea-immobiliare-sa'));
            $field('ftp_user', __('Utente', 'idea-immobiliare-sa'));
            $field('ftp_pass', __('Password', 'idea-immobiliare-sa'), $o['ftp_pass'] !== '' ? __('Salvata. Lascia vuoto per non cambiarla.', 'idea-immobiliare-sa') : '', 'password', $o['ftp_pass'] !== '' ? '••••••••••' : '');
            $field('ftp_dir', __('Cartella sul server', 'idea-immobiliare-sa'), __('Di solito vuota.', 'idea-immobiliare-sa'));
            ?>
            <p class="idea-gx__f"><label for="gx_ftp_ssl"><?php esc_html_e('Connessione cifrata', 'idea-immobiliare-sa'); ?></label><span><input id="gx_ftp_ssl" type="checkbox" name="gx[ftp_ssl]" value="1" <?php checked($o['ftp_ssl']); ?>> <?php esc_html_e('Usa FTPS (solo se ImmoGalaxy lo supporta)', 'idea-immobiliare-sa'); ?></span></p>
            <h3><?php esc_html_e('Regole di invio', 'idea-immobiliare-sa'); ?></h3>
            <p class="idea-gx__f"><label><?php esc_html_e('Invio completo', 'idea-immobiliare-sa'); ?></label><span><input type="checkbox" name="gx[full_saturday]" value="1" <?php checked($o['full_saturday']); ?>> <?php esc_html_e('Il sabato invia tutti gli immobili (gli altri giorni solo le novità)', 'idea-immobiliare-sa'); ?></span></p>
            <p class="idea-gx__f"><label><?php esc_html_e('Orario', 'idea-immobiliare-sa'); ?></label><span><input type="checkbox" name="gx[window]" value="1" <?php checked($o['window']); ?>> <?php esc_html_e('Invia solo tra le 00:01 e le 01:29 (la finestra accettata da ImmoGalaxy)', 'idea-immobiliare-sa'); ?></span></p>
            <?php $field('notify', __('Email dei resoconti', 'idea-immobiliare-sa'), __('Riceve l’esito di ogni invio. Vuoto = email dell’amministratore.', 'idea-immobiliare-sa'), 'email'); ?>
            <p><button class="button button-primary"><?php esc_html_e('Salva le impostazioni', 'idea-immobiliare-sa'); ?></button></p>
        </form>
        <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" style="margin:-8px 0 18px">
            <input type="hidden" name="action" value="idea_gx_test"><?php wp_nonce_field('idea_gx_test'); ?>
            <button class="button" <?php disabled(!idea_gx_ftp_ready()); ?>><?php esc_html_e('Verifica il collegamento FTP', 'idea-immobiliare-sa'); ?></button>
            <span class="description"><?php esc_html_e('Prova utente e password salvati, senza inviare nulla.', 'idea-immobiliare-sa'); ?></span>
        </form>

        <div class="idea-gx__card">
            <h2><?php esc_html_e('Prova e invio manuale', 'idea-immobiliare-sa'); ?></h2>
            <p><?php esc_html_e('Scarica il file che verrebbe inviato (per controllarlo o mandarlo a ImmoGalaxy per la validazione), oppure invialo adesso.', 'idea-immobiliare-sa'); ?></p>
            <p>
                <a class="button" href="<?php echo esc_url(wp_nonce_url(admin_url('admin-post.php?action=idea_gx_download&type=full'), 'idea_gx_download')); ?>"><?php esc_html_e('Scarica XML completo', 'idea-immobiliare-sa'); ?></a>
                <a class="button" href="<?php echo esc_url(wp_nonce_url(admin_url('admin-post.php?action=idea_gx_download&type=incr'), 'idea_gx_download')); ?>"><?php esc_html_e('Scarica solo le novità', 'idea-immobiliare-sa'); ?></a>
            </p>
            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" onsubmit="return confirm('<?php echo esc_js(__('Inviare adesso il file a ImmoGalaxy?', 'idea-immobiliare-sa')); ?>');">
                <input type="hidden" name="action" value="idea_gx_send"><?php wp_nonce_field('idea_gx_send'); ?>
                <select name="type"><option value="incr"><?php esc_html_e('Solo le novità', 'idea-immobiliare-sa'); ?></option><option value="full"><?php esc_html_e('Tutti gli immobili', 'idea-immobiliare-sa'); ?></option></select>
                <button class="button" <?php disabled(!($ready && idea_gx_ftp_ready())); ?>><?php esc_html_e('Invia adesso', 'idea-immobiliare-sa'); ?></button>
            </form>
        </div>

        <div class="idea-gx__card">
            <h2><?php esc_html_e('Ultimi invii', 'idea-immobiliare-sa'); ?></h2>
            <?php if (!$log) : ?><p><?php esc_html_e('Ancora nessun invio.', 'idea-immobiliare-sa'); ?></p><?php else : ?>
            <table><?php foreach (array_slice($log, 0, 12) as $row) : ?><tr><td><?php echo esc_html(wp_date('d.m.Y H:i', $row['t'])); ?></td><td class="<?php echo $row['status'] === 'ok' ? 'idea-gx__ok' : 'idea-gx__ko'; ?>"><?php echo esc_html($row['status']); ?></td><td><?php echo esc_html($row['msg']); ?></td></tr><?php endforeach; ?></table>
            <?php endif; ?>
        </div>
    </div>
    <?php
}
