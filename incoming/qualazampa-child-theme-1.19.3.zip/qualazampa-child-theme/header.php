<?php defined('ABSPATH') || exit; ?><!doctype html>
<html <?php language_attributes(); ?>><head><meta charset="<?php bloginfo('charset'); ?>"><meta name="viewport" content="width=device-width,initial-scale=1"><?php wp_head(); ?></head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="qz-skip" href="#main-content"><?php esc_html_e('Vai al contenuto','qualazampa'); ?></a>
<header class="qz-header" data-header>
    <div class="qz-header__main qz-container">
        <a class="qz-logo" href="<?php echo esc_url(home_url('/')); ?>" aria-label="<?php echo esc_attr(get_bloginfo('name')); ?>">
            <?php $logo=ticinoweb_get_site_logo(); if($logo): ?><img src="<?php echo esc_url($logo); ?>" width="280" height="56" alt="<?php echo esc_attr(get_bloginfo('name')); ?>"><?php else: echo esc_html(get_bloginfo('name')); endif; ?>
        </a>
        <div class="qz-search-shell" data-header-search>
        <button class="qz-search-trigger" type="button" aria-expanded="false" aria-controls="qz-search-form" hidden><?php echo qz_icon('search'); ?><span><?php esc_html_e('Cerca','qualazampa'); ?></span></button>
        <form class="qz-search" id="qz-search-form" method="get" role="search" action="<?php echo esc_url(home_url('/')); ?>">
            <label class="screen-reader-text" for="qz-search"><?php esc_html_e('Cerca nel negozio','qualazampa'); ?></label>
            <input id="qz-search" type="search" name="s" value="<?php echo esc_attr(get_search_query()); ?>" placeholder="<?php esc_attr_e('Cosa serve al tuo piccolo amico?','qualazampa'); ?>"><input type="hidden" name="post_type" value="product">
            <button class="qz-search-submit" type="submit" aria-label="<?php esc_attr_e('Cerca prodotti','qualazampa'); ?>"><?php echo qz_icon('search'); ?></button>
            <button class="qz-search-close" type="button" aria-label="<?php esc_attr_e('Chiudi la ricerca','qualazampa'); ?>" hidden><?php echo qz_icon('close'); ?></button>
        </form>
        </div>
        <div class="qz-header__tools"><a class="qz-account" href="<?php echo esc_url(wc_get_page_permalink('myaccount')); ?>" aria-label="<?php esc_attr_e('Il mio account','qualazampa'); ?>"><?php echo qz_icon('user'); ?><span><?php esc_html_e('Account','qualazampa'); ?></span></a><?php qz_cart_link(); ?><button class="qz-menu-toggle" aria-controls="qz-navigation" aria-expanded="false" aria-label="<?php esc_attr_e('Apri il menu','qualazampa'); ?>"><?php echo qz_icon('menu'); ?></button></div>
    </div>
    <div class="qz-header__nav qz-container" id="qz-navigation">
        <nav aria-label="<?php esc_attr_e('Menu principale','qualazampa'); ?>"><?php wp_nav_menu(['theme_location'=>'primary','container'=>false,'menu_class'=>'qz-menu','fallback_cb'=>false,'walker'=>new QZ_Navigation_Walker()]); ?></nav>
        <?php $address=qz_option('ticinoweb_contact_address_label');if($address): ?><span class="qz-local-note"><?php echo qz_icon('pin'); ?><?php echo esc_html($address); ?></span><?php endif; ?>
    </div>
</header>

<div class="qz-menu-scrim" data-menu-scrim aria-hidden="true"></div>
