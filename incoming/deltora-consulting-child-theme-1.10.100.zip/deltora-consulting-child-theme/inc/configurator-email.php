<?php
/**
 * Server-side validation and delivery for the EBITDA configurator.
 *
 * @package DeltoraConsultingChildTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Format an integer amount using Swiss grouping.
 *
 * @param float|int $value Amount.
 * @return string
 */
function deltora_consulting_format_chf( $value ) {
	$rounded = (int) round( (float) $value );
	$sign    = $rounded < 0 ? '-' : '';
	return 'CHF ' . $sign . number_format( abs( $rounded ), 0, '.', "'" );
}

/**
 * Validate and independently recalculate a result-email payload.
 *
 * @param array<string,mixed> $payload Raw payload.
 * @return array<string,mixed>|WP_Error
 */
function deltora_consulting_validate_result_payload( $payload ) {
	if ( ! is_array( $payload ) || ! empty( $payload['honeypot'] ) ) {
		return new WP_Error( 'invalid_request', 'La richiesta non è valida.' );
	}

	$email = isset( $payload['email'] ) ? sanitize_email( $payload['email'] ) : '';
	if ( ! is_email( $email ) ) {
		return new WP_Error( 'invalid_email', 'Inserisci un indirizzo email valido.' );
	}
	if ( empty( $payload['privacy'] ) ) {
		return new WP_Error( 'privacy_required', 'È necessario accettare l’informativa per ricevere il risultato.' );
	}

	$mode        = isset( $payload['mode'] ) ? sanitize_key( $payload['mode'] ) : '';
	$exceptional = isset( $payload['exceptional'] ) ? sanitize_key( $payload['exceptional'] ) : '';
	$sector_id   = isset( $payload['sector_id'] ) ? sanitize_key( $payload['sector_id'] ) : '';
	$ebitdas     = isset( $payload['ebitdas'] ) && is_array( $payload['ebitdas'] ) ? array_values( $payload['ebitdas'] ) : array();
	$labels      = isset( $payload['year_labels'] ) && is_array( $payload['year_labels'] ) ? array_values( $payload['year_labels'] ) : array();

	if ( ! in_array( $mode, array( 'guided', 'direct' ), true ) || ! in_array( $exceptional, array( 'no', 'yes', 'unknown' ), true ) ) {
		return new WP_Error( 'invalid_context', 'I dati del percorso non sono completi.' );
	}
	if ( 3 !== count( $ebitdas ) || 3 !== count( $labels ) ) {
		return new WP_Error( 'invalid_years', 'Sono necessari tre esercizi completi.' );
	}

	$normalized_ebitdas = array();
	$normalized_labels  = array();
	foreach ( $ebitdas as $index => $value ) {
		if ( ! is_numeric( $value ) ) {
			return new WP_Error( 'invalid_ebitda', 'Uno dei valori EBITDA non è valido.' );
		}
		$numeric_value = (float) $value;
		if ( ! is_finite( $numeric_value ) || abs( $numeric_value ) > 1000000000000 ) {
			return new WP_Error( 'invalid_ebitda', 'Uno dei valori EBITDA non rientra nei limiti consentiti.' );
		}
		$label = sanitize_text_field( $labels[ $index ] );
		$label = mb_substr( $label, 0, 40 );
		if ( '' === $label ) {
			return new WP_Error( 'invalid_label', 'Ogni esercizio deve avere un’etichetta.' );
		}
		$normalized_ebitdas[] = $numeric_value;
		$normalized_labels[]  = $label;
	}
	if ( 3 !== count( array_unique( $normalized_labels ) ) ) {
		return new WP_Error( 'duplicate_years', 'Gli esercizi devono avere etichette diverse.' );
	}

	$config = deltora_consulting_get_configurator_config();
	$sector = null;
	foreach ( $config['sectors'] as $candidate ) {
		if ( $candidate['id'] === $sector_id ) {
			$sector = $candidate;
			break;
		}
	}
	if ( null === $sector ) {
		return new WP_Error( 'invalid_sector', 'L’attività selezionata non è valida.' );
	}

	$average   = array_sum( $normalized_ebitdas ) / 3;
	$estimable = $average > 0 && is_numeric( $sector['min'] ) && is_numeric( $sector['max'] );
	$minimum   = $estimable ? round( ( $average * (float) $sector['min'] ) / 1000 ) * 1000 : null;
	$maximum   = $estimable ? round( ( $average * (float) $sector['max'] ) / 1000 ) * 1000 : null;

	return array(
		'email'       => $email,
		'mode'        => $mode,
		'exceptional' => $exceptional,
		'sector'      => $sector,
		'ebitdas'     => $normalized_ebitdas,
		'year_labels' => $normalized_labels,
		'average'     => (float) $average,
		'minimum'     => null === $minimum ? null : (float) $minimum,
		'maximum'     => null === $maximum ? null : (float) $maximum,
		'estimable'   => $estimable,
	);
}

/**
 * Build the result email arguments.
 *
 * @param array<string,mixed> $data Validated data.
 * @return array{to:string,subject:string,message:string,headers:array<int,string>}
 */
function deltora_consulting_build_result_email( $data ) {
	ob_start();
	include dirname( __DIR__ ) . '/templates/email-configurator-result.php';
	$message = (string) ob_get_clean();

	return array(
		'to'      => $data['email'],
		'subject' => 'La tua stima indicativa — Deltora Consulting',
		'message' => $message,
		'headers' => array( 'Content-Type: text/html; charset=UTF-8' ),
	);
}

/**
 * Decode a JSON AJAX payload.
 *
 * @return array<string,mixed>
 */
function deltora_consulting_read_ajax_payload() {
	$raw = isset( $_POST['payload'] ) ? wp_unslash( $_POST['payload'] ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing
	if ( ! is_string( $raw ) || strlen( $raw ) > 20000 ) {
		return array();
	}
	$data = json_decode( $raw, true );
	return is_array( $data ) ? $data : array();
}

/**
 * Deliver the result email.
 *
 * @return void
 */
function deltora_consulting_ajax_send_result() {
	check_ajax_referer( 'deltora_configurator', 'nonce' );
	$data = deltora_consulting_validate_result_payload( deltora_consulting_read_ajax_payload() );
	if ( is_wp_error( $data ) ) {
		wp_send_json_error( array( 'message' => $data->get_error_message() ), 422 );
	}

	$rate_key = 'deltora_cfg_' . md5( sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ?? 'unknown' ) ) );
	if ( (int) get_transient( $rate_key ) >= 5 ) {
		wp_send_json_error( array( 'message' => 'Troppi tentativi ravvicinati. Riprova tra qualche minuto.' ), 429 );
	}
	set_transient( $rate_key, (int) get_transient( $rate_key ) + 1, 10 * MINUTE_IN_SECONDS );

	$mail = deltora_consulting_build_result_email( $data );
	if ( ! wp_mail( $mail['to'], $mail['subject'], $mail['message'], $mail['headers'] ) ) {
		wp_send_json_error( array( 'message' => 'Il risultato resta visibile, ma l’email non è stata consegnata. Controlla l’indirizzo e riprova.' ), 500 );
	}

	wp_send_json_success( array( 'message' => sprintf( 'Il riepilogo è stato inviato a %s. Controlla anche la cartella spam.', $data['email'] ) ) );
}
add_action( 'wp_ajax_deltora_send_configurator_result', 'deltora_consulting_ajax_send_result' );
add_action( 'wp_ajax_nopriv_deltora_send_configurator_result', 'deltora_consulting_ajax_send_result' );
