<?php
/**
 * Per-site administration for the optional Zefix integration.
 *
 * Server constants remain authoritative. Database options are an explicit
 * fallback for hosting environments where constants cannot be configured.
 *
 * @package DeltoraConsultingChildTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Return the Zefix administration URL. */
function deltora_consulting_get_zefix_admin_url( $args = array() ) {
	return add_query_arg( $args, admin_url( 'admin.php?page=ticinoweb-cms-zefix' ) );
}

/** Register the per-site Zefix page below ticinoWEB CMS. */
function deltora_consulting_add_zefix_admin_page() {
	add_submenu_page(
		'ticinoweb-cms',
		__( 'Integrazione Zefix', 'deltora-consulting-child-theme' ),
		__( 'Integrazione Zefix', 'deltora-consulting-child-theme' ),
		'manage_options',
		'ticinoweb-cms-zefix',
		'deltora_consulting_render_zefix_admin_page'
	);
}
add_action( 'admin_menu', 'deltora_consulting_add_zefix_admin_page', 31 );

/** Return whether an effective setting is controlled by a server constant. */
function deltora_consulting_zefix_setting_uses_constant( $setting ) {
	$constants = array(
		'enabled'  => 'DELTORA_COMPANY_LOOKUP_ENABLED',
		'username' => 'DELTORA_ZEFIX_USERNAME',
		'password' => 'DELTORA_ZEFIX_PASSWORD',
	);

	return isset( $constants[ $setting ] ) && defined( $constants[ $setting ] );
}

/** Store a site option without autoloading it on unrelated requests. */
function deltora_consulting_update_private_option( $name, $value ) {
	if ( false === get_option( $name, false ) ) {
		add_option( $name, $value, '', false );
		return;
	}

	update_option( $name, $value, false );
}

/** Sanitize a secret while preserving characters valid in an HTTP password. */
function deltora_consulting_sanitize_zefix_secret( $value ) {
	$value = (string) $value;
	$value = preg_replace( '/[\x00-\x1F\x7F]/', '', $value );

	return substr( (string) $value, 0, 512 );
}

/** Render one source label without revealing the configured value. */
function deltora_consulting_render_zefix_source( $uses_constant ) {
	if ( $uses_constant ) {
		return '<span class="dashicons dashicons-lock" aria-hidden="true"></span> ' . esc_html__( 'Gestito dal server', 'deltora-consulting-child-theme' );
	}

	return esc_html__( 'Gestito da questo sito', 'deltora-consulting-child-theme' );
}

/** Render notices produced by save and connection-test actions. */
function deltora_consulting_render_zefix_admin_notice( $status ) {
	$notices = array(
		'saved'         => array( 'success', __( 'Impostazioni Zefix salvate.', 'deltora-consulting-child-theme' ) ),
		'test-ok'       => array( 'success', __( 'Collegamento riuscito: Zefix ha risposto correttamente.', 'deltora-consulting-child-theme' ) ),
		'test-auth'     => array( 'error', __( 'Zefix ha rifiutato le credenziali. Controlla username e password.', 'deltora-consulting-child-theme' ) ),
		'test-disabled' => array( 'warning', __( 'Attiva l’integrazione e completa le credenziali prima di verificarla.', 'deltora-consulting-child-theme' ) ),
		'test-error'    => array( 'error', __( 'Zefix non ha risposto correttamente. Riprova più tardi e controlla che il server possa effettuare richieste HTTPS in uscita.', 'deltora-consulting-child-theme' ) ),
	);

	if ( ! isset( $notices[ $status ] ) ) {
		return;
	}

	list( $type, $message ) = $notices[ $status ];
	printf(
		'<div class="notice notice-%1$s is-dismissible"><p>%2$s</p></div>',
		esc_attr( $type ),
		esc_html( $message )
	);
}

/** Render the per-site setup and operating instructions. */
function deltora_consulting_render_zefix_admin_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'Permessi insufficienti.', 'deltora-consulting-child-theme' ) );
	}

	$settings          = deltora_consulting_get_company_lookup_settings();
	$capabilities      = deltora_consulting_get_company_lookup_capabilities();
	$status            = sanitize_key( wp_unslash( $_GET['deltora_status'] ?? '' ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only notice selector.
	$enabled_constant  = deltora_consulting_zefix_setting_uses_constant( 'enabled' );
	$username_constant = deltora_consulting_zefix_setting_uses_constant( 'username' );
	$password_constant = deltora_consulting_zefix_setting_uses_constant( 'password' );
	$stored_password   = ! $password_constant && '' !== (string) get_option( 'deltora_zefix_password', '' );
	?>
	<div class="wrap">
		<h1><?php esc_html_e( 'Integrazione Zefix', 'deltora-consulting-child-theme' ); ?></h1>
		<p><?php esc_html_e( 'Configura la ricerca delle aziende svizzere usata nel passaggio “Attività” del configuratore EBITDA.', 'deltora-consulting-child-theme' ); ?></p>
		<?php deltora_consulting_render_zefix_admin_notice( $status ); ?>

		<div class="notice <?php echo ! empty( $capabilities['enabled'] ) ? 'notice-success' : 'notice-warning'; ?> inline">
			<p><strong><?php esc_html_e( 'Stato:', 'deltora-consulting-child-theme' ); ?></strong>
			<?php echo ! empty( $capabilities['enabled'] ) ? esc_html__( 'operativa', 'deltora-consulting-child-theme' ) : esc_html__( 'non operativa', 'deltora-consulting-child-theme' ); ?></p>
			<?php if ( empty( $capabilities['enabled'] ) ) : ?>
				<p><?php esc_html_e( 'Sono necessari attivazione, username, password e provider Zefix disponibile. Il configuratore continua comunque a funzionare con la scelta manuale del settore.', 'deltora-consulting-child-theme' ); ?></p>
			<?php endif; ?>
		</div>

		<h2><?php esc_html_e( 'Impostazioni di questo sito', 'deltora-consulting-child-theme' ); ?></h2>
		<p><?php esc_html_e( 'Le costanti definite dal server hanno sempre la precedenza e bloccano il campo corrispondente. Questo evita che un amministratore possa sovrascrivere accidentalmente la configurazione di produzione.', 'deltora-consulting-child-theme' ); ?></p>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="deltora_save_zefix_settings">
			<?php wp_nonce_field( 'deltora_save_zefix_settings' ); ?>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><?php esc_html_e( 'Ricerca Zefix', 'deltora-consulting-child-theme' ); ?></th>
					<td>
						<label><input type="checkbox" name="enabled" value="1" <?php checked( ! empty( $settings['enabled'] ) ); ?> <?php disabled( $enabled_constant ); ?>> <?php esc_html_e( 'Abilita la ricerca automatica', 'deltora-consulting-child-theme' ); ?></label>
						<p class="description"><?php echo wp_kses_post( deltora_consulting_render_zefix_source( $enabled_constant ) ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="deltora-zefix-username"><?php esc_html_e( 'Username Zefix', 'deltora-consulting-child-theme' ); ?></label></th>
					<td>
						<input class="regular-text" id="deltora-zefix-username" name="username" type="text" value="<?php echo $username_constant ? '' : esc_attr( (string) get_option( 'deltora_zefix_username', '' ) ); ?>" autocomplete="off" maxlength="190" <?php disabled( $username_constant ); ?>>
						<p class="description"><?php echo wp_kses_post( deltora_consulting_render_zefix_source( $username_constant ) ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="deltora-zefix-password"><?php esc_html_e( 'Password Zefix', 'deltora-consulting-child-theme' ); ?></label></th>
					<td>
						<input class="regular-text" id="deltora-zefix-password" name="password" type="password" value="" autocomplete="new-password" maxlength="512" placeholder="<?php echo esc_attr( $stored_password ? __( 'Salvata — lascia vuoto per mantenerla', 'deltora-consulting-child-theme' ) : '' ); ?>" <?php disabled( $password_constant ); ?>>
						<p class="description"><?php echo wp_kses_post( deltora_consulting_render_zefix_source( $password_constant ) ); ?> <?php esc_html_e( 'La password non viene mai mostrata nuovamente.', 'deltora-consulting-child-theme' ); ?></p>
						<?php if ( $stored_password ) : ?><label><input type="checkbox" name="clear_password" value="1"> <?php esc_html_e( 'Rimuovi la password salvata', 'deltora-consulting-child-theme' ); ?></label><?php endif; ?>
					</td>
				</tr>
			</table>
			<?php submit_button( __( 'Salva impostazioni', 'deltora-consulting-child-theme' ) ); ?>
		</form>

		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="deltora_test_zefix_connection">
			<?php wp_nonce_field( 'deltora_test_zefix_connection' ); ?>
			<?php submit_button( __( 'Verifica collegamento', 'deltora-consulting-child-theme' ), 'secondary', 'submit', false, empty( $capabilities['enabled'] ) ? array( 'disabled' => 'disabled' ) : array() ); ?>
		</form>

		<hr>
		<h2><?php esc_html_e( 'Istruzioni per il sito online', 'deltora-consulting-child-theme' ); ?></h2>
		<ol>
			<li><?php esc_html_e( 'Richiedi o recupera le credenziali per Zefix PublicREST.', 'deltora-consulting-child-theme' ); ?></li>
			<li><?php esc_html_e( 'Metodo consigliato: definisci le tre costanti sotto nella configurazione protetta del server o in wp-config.php, senza inserirle nel repository.', 'deltora-consulting-child-theme' ); ?></li>
			<li><?php esc_html_e( 'Se l’hosting non consente di gestire costanti, inserisci le credenziali nei campi sopra: saranno salvate nel database come opzioni del solo sottosito e non caricate automaticamente.', 'deltora-consulting-child-theme' ); ?></li>
			<li><?php esc_html_e( 'Salva, premi “Verifica collegamento” e poi prova dal frontend una ragione sociale e un UID.', 'deltora-consulting-child-theme' ); ?></li>
		</ol>
		<pre><code>define( 'DELTORA_COMPANY_LOOKUP_ENABLED', true );
define( 'DELTORA_ZEFIX_USERNAME', 'USERNAME_FORNITO_DA_ZEFIX' );
define( 'DELTORA_ZEFIX_PASSWORD', 'PASSWORD_FORNITA_DA_ZEFIX' );</code></pre>
		<p><strong><?php esc_html_e( 'Nota di sicurezza:', 'deltora-consulting-child-theme' ); ?></strong> <?php esc_html_e( 'le credenziali restano lato server. Il browser riceve soltanto lo stato dell’integrazione e i dati pubblici necessari. Le ricerche non vengono archiviate dal tema; le risposte sono conservate temporaneamente nella cache del sottosito.', 'deltora-consulting-child-theme' ); ?></p>
	</div>
	<?php
}

/** Save per-site settings that are not locked by constants. */
function deltora_consulting_handle_save_zefix_settings() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'Permessi insufficienti.', 'deltora-consulting-child-theme' ) );
	}
	check_admin_referer( 'deltora_save_zefix_settings' );

	if ( ! deltora_consulting_zefix_setting_uses_constant( 'enabled' ) ) {
		deltora_consulting_update_private_option( 'deltora_company_lookup_enabled', isset( $_POST['enabled'] ) ? '1' : '0' );
	}
	if ( ! deltora_consulting_zefix_setting_uses_constant( 'username' ) ) {
		$username = isset( $_POST['username'] ) ? sanitize_text_field( wp_unslash( $_POST['username'] ) ) : '';
		deltora_consulting_update_private_option( 'deltora_zefix_username', substr( trim( $username ), 0, 190 ) );
	}
	if ( ! deltora_consulting_zefix_setting_uses_constant( 'password' ) ) {
		if ( isset( $_POST['clear_password'] ) ) {
			delete_option( 'deltora_zefix_password' );
		} elseif ( isset( $_POST['password'] ) && '' !== (string) $_POST['password'] ) {
			$password = deltora_consulting_sanitize_zefix_secret( wp_unslash( $_POST['password'] ) );
			deltora_consulting_update_private_option( 'deltora_zefix_password', $password );
		}
	}

	wp_safe_redirect( deltora_consulting_get_zefix_admin_url( array( 'deltora_status' => 'saved' ) ) );
	exit;
}
add_action( 'admin_post_deltora_save_zefix_settings', 'deltora_consulting_handle_save_zefix_settings' );

/** Test authentication and outbound HTTPS without exposing provider details. */
function deltora_consulting_handle_test_zefix_connection() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'Permessi insufficienti.', 'deltora-consulting-child-theme' ) );
	}
	check_admin_referer( 'deltora_test_zefix_connection' );

	$capabilities = deltora_consulting_get_company_lookup_capabilities();
	$status       = 'test-disabled';
	if ( ! empty( $capabilities['enabled'] ) ) {
		$result = deltora_consulting_zefix_search_company_name( 'Consulting' );
		if ( ! is_wp_error( $result ) ) {
			$status = 'test-ok';
		} elseif ( 'zefix_authentication' === $result->get_error_code() ) {
			$status = 'test-auth';
		} else {
			$status = 'test-error';
		}
	}

	wp_safe_redirect( deltora_consulting_get_zefix_admin_url( array( 'deltora_status' => $status ) ) );
	exit;
}
add_action( 'admin_post_deltora_test_zefix_connection', 'deltora_consulting_handle_test_zefix_connection' );
