<?php
/**
 * Admin Settings Page for ticinoWEB AI Theme
 * Gestione impostazioni: reCAPTCHA, SMTP, SendGrid
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * ============================================================
 * GLOBAL SAFEGUARD — ticinoweb_ option preservation
 * ============================================================
 * Root cause of the recurring "fields reset" bug:
 *   WordPress Settings API calls update_option() for EVERY
 *   registered option in the group when options.php is submitted.
 *   If a field is registered but missing from the current form
 *   (e.g. you save the CMS main page while an option only exists
 *   in the Settings page), WordPress writes an empty string to DB.
 *
 * Fix:
 *   Hook pre_update_option (runs before ANY DB write).
 *   If the incoming value is empty AND the option key was NOT
 *   present in the submitted POST body → restore the old DB value.
 *   An explicit {option_name}_clear=1 companion field still allows
 *   intentional clearing when the user wants to blank a field.
 *
 * This covers ALL ticinoweb_ options — present and future —
 * without requiring per-field patching.
 * ============================================================
 */
add_filter('pre_update_option', function ($new_value, $option_name, $old_value) {
    // Only protect ticinoweb-namespaced options
    if (strpos($option_name, 'ticinoweb_') !== 0) {
        return $new_value;
    }

    // Only intercept Settings API submissions (action=options.php)
    if (
        empty($_POST['option_page']) ||
        $_POST['option_page'] !== 'ticinoweb_settings_group'
    ) {
        return $new_value;
    }

    // If the field was NOT present in the submitted form at all
    if (!array_key_exists($option_name, $_POST)) {
        // Allow intentional clear via explicit companion field {option_name}_clear=1
        $clear_key = $option_name . '_clear';
        if (!empty($_POST[$clear_key]) && $_POST[$clear_key] === '1') {
            return $new_value; // user explicitly wants to clear
        }
        // Preserve the existing DB value — do NOT overwrite with empty
        return $old_value;
    }

    return $new_value;
}, 10, 3);


/**
 * Ultima versione pubblicata di un tema (parent o child), letta dall'updater
 * (inc/github-updater.php) sul repo pubblico delle release: nessun token nel codice.
 *
 * Fino alla 3.10.0 questa funzione leggeva style.css dal repo PRIVATO wp-themes
 * con un token GitHub offuscato nel tema: il token va revocato su GitHub.
 *
 * @param string $slug Slug del tema (cartella). Default: il parent.
 * @return string|null Versione (es. '3.10.1') o null se non esiste una release o GitHub non risponde.
 */
function ticinoweb_get_github_version($slug = 'ticinoweb-ai-theme') {
    if (!class_exists('TW_GitHub_Updater')) {
        return null;
    }
    static $cache = array();
    if (!array_key_exists($slug, $cache)) {
        $updater      = new TW_GitHub_Updater($slug);
        $release      = $updater->get_latest_release();
        $cache[$slug] = $release ? $release['version'] : null;
    }
    return $cache[$slug];
}

/**
 * Badge di versione accanto al titolo del pannello (parent) o alla riga
 * "Child Theme" (child).
 * Verde = aggiornato. Grigio = aggiornamento disponibile (con link a
 * Bacheca → Aggiornamenti). Grigio vuoto = GitHub non raggiungibile, oppure
 * (solo child) nessuna release pubblicata per quel tema.
 *
 * @param string $installed_version Versione installata.
 * @param string $slug              Slug del tema. Default: il parent.
 */
function ticinoweb_render_version_badge($installed_version, $slug = 'ticinoweb-ai-theme') {
    $is_parent      = ($slug === 'ticinoweb-ai-theme');
    $github_version = ticinoweb_get_github_version($slug);
    $dot  = 'width:8px;height:8px;border-radius:50%;display:inline-block;flex-shrink:0;';
    $wrap = 'display:inline-flex;align-items:center;gap:5px;margin-left:10px;font-size:12px;';

    if ($github_version === null) {
        // Per il child: se il parent ha una release leggibile, GitHub risponde e
        // semplicemente non esiste ancora un tag <child>-v<versione>.
        $no_release = !$is_parent && ticinoweb_get_github_version('ticinoweb-ai-theme') !== null;
        $label = $no_release
            ? __('Nessuna release pubblicata', 'ticinoweb-ai-theme')
            : __('GitHub non raggiungibile', 'ticinoweb-ai-theme');
        $title = $no_release
            ? __('Sul repo delle release non esiste ancora un tag per questo child theme.', 'ticinoweb-ai-theme')
            : __('Impossibile leggere le release da GitHub in questo momento.', 'ticinoweb-ai-theme');
        echo '<span style="' . esc_attr($wrap) . 'color:#9ca3af;" title="' . esc_attr($title) . '">';
        echo '<span style="' . esc_attr($dot) . 'background:transparent;border:2px solid #d1d5db;box-sizing:border-box;"></span>';
        echo esc_html($label);
        echo '</span>';
        return;
    }

    if (version_compare($installed_version, $github_version, '>=')) {
        echo '<span style="' . esc_attr($wrap) . 'color:#16a34a;">';
        echo '<span style="' . esc_attr($dot) . 'background:#22c55e;box-shadow:0 0 4px rgba(34,197,94,.6);"></span>';
        echo esc_html($is_parent ? __('Tema aggiornato', 'ticinoweb-ai-theme') : __('Aggiornato', 'ticinoweb-ai-theme'));
        echo '</span>';
        return;
    }

    $update_url = is_multisite() ? network_admin_url('update-core.php') : admin_url('update-core.php');
    echo '<span style="' . esc_attr($wrap) . 'color:#6b7280;">';
    echo '<span style="' . esc_attr($dot) . 'background:#9ca3af;"></span>';
    if (current_user_can('update_themes')) {
        echo '<a href="' . esc_url($update_url) . '" style="color:inherit;">';
        echo esc_html(sprintf(__('Aggiornamento disponibile (v%s)', 'ticinoweb-ai-theme'), $github_version));
        echo '</a>';
    } else {
        echo esc_html(sprintf(__('Aggiornamento disponibile (v%s)', 'ticinoweb-ai-theme'), $github_version));
    }
    echo '</span>';
}

/**
 * Riga "Child Theme: <nome> v<versione> [badge]" sotto la versione del parent
 * nell'intestazione del pannello. Stampa nulla se il tema attivo e' il parent
 * stesso o un tema che non deriva da ticinoweb-ai-theme.
 */
function ticinoweb_render_child_version_line() {
    $child_slug = get_stylesheet();
    if ($child_slug === 'ticinoweb-ai-theme') {
        return;
    }
    $child = wp_get_theme($child_slug);
    if (!$child->exists() || $child->get('Template') !== 'ticinoweb-ai-theme') {
        return;
    }
    $child_version = (string) $child->get('Version');
    echo '<p style="margin:2px 0 0; color:#666; font-size:13px; display:flex; align-items:center;">';
    echo esc_html__('Child Theme:', 'ticinoweb-ai-theme') . ' ' . esc_html($child->get('Name'));
    if ($child_version !== '') {
        echo ' v' . esc_html($child_version);
        ticinoweb_render_version_badge($child_version, $child_slug);
    }
    echo '</p>';
}

// Add admin menu
add_action('admin_menu', 'ticinoweb_add_admin_menu');
function ticinoweb_add_admin_menu() {
    add_menu_page(
        __('ticinoWEB CMS', 'ticinoweb-ai-theme'),
        __('ticinoWEB CMS', 'ticinoweb-ai-theme'),
        'edit_pages',
        'ticinoweb-cms',
        'ticinoweb_settings_page',
        'dashicons-admin-settings',
        30
    );

    add_menu_page(
        __('Settings', 'ticinoweb-ai-theme'),
        __('Settings', 'ticinoweb-ai-theme'),
        'manage_options',
        'ticinoweb-settings',
        'ticinoweb_render_standalone_settings_page',
        'dashicons-admin-generic',
        32
    );

}

// Allow Editors+ to save editor-visible settings in this group
add_filter('option_page_capability_ticinoweb_settings_group', 'ticinoweb_settings_group_capability');
function ticinoweb_settings_group_capability($capability) {
    return 'edit_pages';
}

// Handle URL replacement (current site only)
/**
 * Sostituisce un URL dentro un valore del database senza rompere i dati serializzati.
 *
 * Un REPLACE in SQL cambia il testo ma non la lunghezza dichiarata nelle stringhe serializzate
 * (s:112:"..."): se il nuovo URL ha una lunghezza diversa, unserialize() fallisce e l'opzione risulta
 * vuota. Qui i valori serializzati si leggono, si sostituisce nelle stringhe e si riscrivono.
 */
function ticinoweb_replace_url_in_value($value, $old, $new) {
    if (is_array($value)) {
        foreach ($value as $k => $v) {
            $value[$k] = ticinoweb_replace_url_in_value($v, $old, $new);
        }
        return $value;
    }
    if (is_object($value)) {
        foreach (get_object_vars($value) as $k => $v) {
            $value->$k = ticinoweb_replace_url_in_value($v, $old, $new);
        }
        return $value;
    }
    if (!is_string($value) || $value === '') {
        return $value;
    }
    if (is_serialized($value)) {
        $data = @unserialize($value, array('allowed_classes' => false));
        if ($data !== false || $value === 'b:0;') {
            return serialize(ticinoweb_replace_url_in_value($data, $old, $new));
        }
        // Già rotto da una sostituzione precedente: si ripara con il conteggio dei byte.
    }
    $value = str_replace($old, $new, $value);
    $value = str_replace(str_replace('/', '\\/', $old), str_replace('/', '\\/', $new), $value);
    if (is_serialized($value) && @unserialize($value) === false) {
        $fixed = preg_replace_callback('/s:\d+:"(.*?)";(?=(?:}|[aisdbNO]:|i:|s:))/s', function ($m) {
            return 's:' . strlen($m[1]) . ':"' . $m[1] . '";';
        }, $value);
        if ($fixed !== null && @unserialize($fixed) !== false) {
            return $fixed;
        }
    }
    return $value;
}

add_action('admin_post_ticinoweb_url_replacement', 'ticinoweb_handle_url_replacement');
function ticinoweb_handle_url_replacement() {
    if (!current_user_can('manage_options')) {
        wp_die(__('Permessi insufficienti.', 'ticinoweb-ai-theme'));
    }

    check_admin_referer('ticinoweb_url_replacement', 'ticinoweb_url_replacement_nonce');

    $old_url = isset($_POST['ticinoweb_old_url']) ? trim(wp_unslash($_POST['ticinoweb_old_url'])) : '';
    $new_url = isset($_POST['ticinoweb_new_url']) ? trim(wp_unslash($_POST['ticinoweb_new_url'])) : '';

    if ($old_url === '' || $new_url === '' || $old_url === $new_url) {
        $redirect = add_query_arg(
            array(
                'page' => 'ticinoweb-cms',
                'ticinoweb_url_replacement' => 'error'
            ),
            admin_url('admin.php')
        );
        wp_safe_redirect($redirect);
        exit;
    }

    global $wpdb;
    $blog_id = get_current_blog_id();
    $prefix = $wpdb->get_blog_prefix($blog_id);

    $targets = array(
        array('table' => $prefix . 'posts', 'id' => 'ID', 'columns' => array('post_content', 'post_excerpt', 'guid')),
        array('table' => $prefix . 'postmeta', 'id' => 'meta_id', 'columns' => array('meta_value')),
        array('table' => $prefix . 'options', 'id' => 'option_id', 'columns' => array('option_value')),
        array('table' => $prefix . 'termmeta', 'id' => 'meta_id', 'columns' => array('meta_value')),
        array('table' => $prefix . 'commentmeta', 'id' => 'meta_id', 'columns' => array('meta_value')),
        array('table' => $prefix . 'comments', 'id' => 'comment_ID', 'columns' => array('comment_content', 'comment_author_url')),
    );

    // Il JSON (Elementor, blocchi) scrive gli URL con "\/": si cerca anche in quella forma.
    $old_json = str_replace('/', '\\/', $old_url);
    $like = '%' . $wpdb->esc_like($old_url) . '%';
    $like_json = '%' . $wpdb->esc_like($old_json) . '%';
    $updated = 0;

    foreach ($targets as $target) {
        $table = $target['table'];
        $id_col = $target['id'];
        foreach ($target['columns'] as $column) {
            $last_id = 0;
            do {
                // A blocchi di 200 righe, per non caricare in memoria tabelle grandi.
                $rows = $wpdb->get_results($wpdb->prepare(
                    "SELECT {$id_col} AS id, {$column} AS value FROM {$table} WHERE {$id_col} > %d AND ({$column} LIKE %s OR {$column} LIKE %s) ORDER BY {$id_col} ASC LIMIT 200",
                    $last_id,
                    $like,
                    $like_json
                ));
                foreach ($rows as $row) {
                    $last_id = (int) $row->id;
                    $new_value = ticinoweb_replace_url_in_value($row->value, $old_url, $new_url);
                    if ($new_value !== $row->value) {
                        $wpdb->update($table, array($column => $new_value), array($id_col => $row->id));
                        $updated++;
                    }
                }
            } while (count($rows) === 200);
        }
    }

    // Opzioni e contenuti sono cambiati direttamente nel database: si svuotano le cache.
    wp_cache_flush();
    if (class_exists('\\Elementor\\Plugin') && isset(\Elementor\Plugin::$instance->files_manager)) {
        \Elementor\Plugin::$instance->files_manager->clear_cache();
    }

    $redirect = add_query_arg(
        array(
            'page' => 'ticinoweb-cms',
            'ticinoweb_url_replacement' => 'done',
            'ticinoweb_url_replacement_count' => $updated
        ),
        admin_url('admin.php')
    );
    wp_safe_redirect($redirect);
    exit;
}

// Admin notice for URL replacement
add_action('admin_notices', 'ticinoweb_url_replacement_notice');
function ticinoweb_url_replacement_notice() {
    if (!isset($_GET['page']) || $_GET['page'] !== 'ticinoweb-cms') {
        return;
    }

    if (!isset($_GET['ticinoweb_url_replacement'])) {
        return;
    }

    $status = sanitize_text_field(wp_unslash($_GET['ticinoweb_url_replacement']));
    if ($status === 'done') {
        $count = isset($_GET['ticinoweb_url_replacement_count']) ? (int) $_GET['ticinoweb_url_replacement_count'] : 0;
        echo '<div class="notice notice-success is-dismissible"><p>' . sprintf(esc_html__('Sostituzione URL completata. Righe aggiornate: %d', 'ticinoweb-ai-theme'), $count) . '</p></div>';
    } elseif ($status === 'error') {
        echo '<div class="notice notice-error is-dismissible"><p>' . esc_html__('Inserisci URL validi (vecchio e nuovo) e assicurati che siano diversi.', 'ticinoweb-ai-theme') . '</p></div>';
    }
}

// Enqueue color picker and media uploader
add_action('admin_enqueue_scripts', 'ticinoweb_enqueue_admin_assets');
function ticinoweb_enqueue_admin_assets($hook) {
    if ($hook !== 'toplevel_page_ticinoweb-cms' && $hook !== 'toplevel_page_ticinoweb-settings') {
        return;
    }
    
    wp_enqueue_style('wp-color-picker');
    wp_enqueue_script('wp-color-picker');
    wp_enqueue_media();
    wp_enqueue_script('jquery-ui-sortable');
    
    // Modern Admin UI Styles
    wp_enqueue_style('ticinoweb-admin-modern', get_template_directory_uri() . '/assets/css/admin-modern.css', array(), defined('TICINOWEB_THEME_VERSION') ? TICINOWEB_THEME_VERSION : '3.1.5');
    wp_enqueue_script('ticinoweb-admin-tabs', get_template_directory_uri() . '/assets/js/tw-admin-tabs.js', array(), defined('TICINOWEB_THEME_VERSION') ? TICINOWEB_THEME_VERSION : '3.1.5', true);
}


/**
 * Sanitize callback for URL/image options.
 * PRESERVES the existing DB value when the submitted value is empty,
 * UNLESS the user explicitly clicked "Rimuovi" (sends a _clear=1 hidden field).
 * Prevents theme updates from accidentally wiping logos, slider images, etc.
 *
 * @param  string $new_value  Submitted URL.
 * @param  string $option_key WP option name (e.g. 'ticinoweb_site_logo').
 * @return string             Sanitized URL or existing preserved value.
 */
function tw_preserve_url_option( $new_value, $option_key ) {
    $new_value = trim( (string) $new_value );
    if ( '' === $new_value ) {
        // Only clear if the user explicitly clicked "Rimuovi",
        // which sets a hidden companion field {option_key}_clear=1.
        $clear_key = $option_key . '_clear';
        if ( ! empty( $_POST[ $clear_key ] ) && $_POST[ $clear_key ] === '1' ) {
            return '';
        }
        // Otherwise preserve the existing DB value.
        return (string) get_option( $option_key, '' );
    }
    return esc_url_raw( $new_value );
}

/**
 * Preserve text-based option when the submitted value is null/empty
 * (e.g. the field wasn't present in the submitted form at all).
 * Prevents cross-page saves from wiping text fields.
 *
 * @param  mixed  $new_value  Submitted value (may be null if field absent).
 * @param  string $option_key WP option name.
 * @param  string $sanitizer  Sanitize callback name (default: 'sanitize_text_field').
 * @return string             Sanitized value or preserved existing value.
 */
function tw_preserve_text_option( $new_value, $option_key, $sanitizer = 'sanitize_text_field' ) {
    // If the value is null the field wasn't in the POST payload at all.
    if ( $new_value === null ) {
        return get_option( $option_key, '' );
    }
    return call_user_func( $sanitizer, $new_value );
}

/**
 * Sanitizer per valori segreti (password SMTP): il valore viene salvato così com'è.
 * sanitize_text_field() rimuove le sequenze "%xx" (es. "%2f") e tutto ciò che assomiglia
 * a un tag HTML ("<...>"), corrompendo silenziosamente le password che li contengono.
 * Qui vengono tolti solo i caratteri di controllo e le interruzioni di riga.
 */
function tw_sanitize_secret( $value ) {
    $value = (string) $value;
    $value = preg_replace( '/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/', '', $value );
    return trim( $value, "\r\n" );
}

/**
 * Preserva il valore di una checkbox se non è presente nel POST (salvataggio da altra pagina)
 */
function tw_preserve_checkbox_option( $new_value, $option_key, $default = 0 ) {
    // Se il valore è strettamente null (non false, non 0, non ''), significa che
    // l'input non era presente nel form POST (es. stiamo salvando da un'altra pagina tab)
    if ( null === $new_value ) {
        return get_option( $option_key, $default );
    }
    
    // Altrimenti sanitizziamo normalmente
    return $new_value ? 1 : 0;
}

/**
 * Preserve array-based option when the submitted value is null
 * (e.g. the array fields weren't rendered in the submitted form).
 * Prevents cross-page saves from wiping services, CPTs, page mapping, etc.
 *
 * @param  mixed  $input      Submitted value (may be null if fields absent).
 * @param  string $option_key WP option name.
 * @return mixed              Original input for further processing, or preserved DB value.
 */
function tw_preserve_array_option_or_passthrough( $input, $option_key ) {
    if ( $input === null ) {
        return get_option( $option_key, [] );
    }
    return $input; // Return for further sanitization
}

/**
 * Opzioni riservate agli amministratori (SMTP, SendGrid, reCAPTCHA, Google API).
 *
 * Il gruppo `ticinoweb_settings_group` e' salvabile con `edit_pages` perche' gli
 * editor gestiscono i contenuti del CMS; questi campi pero' sono nascosti nella
 * UI agli editor e fino alla 3.9.x erano protetti SOLO dalla UI: un POST diretto
 * a options.php poteva sovrascrivere il server SMTP o la chiave API. Da 3.10.0
 * chi non ha `manage_options` non puo' modificarli: il valore salvato resta
 * quello attuale. Nessun cambiamento per gli amministratori.
 *
 * @param mixed    $new_value Valore inviato (null se il campo non era nel POST).
 * @param string   $option    Nome opzione.
 * @param callable $sanitize  Sanitizer da applicare per gli amministratori.
 * @return mixed
 */
function tw_admin_only_option($new_value, $option, $sanitize) {
    if (!current_user_can('manage_options') && !current_user_can('manage_network')) {
        return get_option($option);
    }
    return call_user_func($sanitize, $new_value);
}

// Register settings
add_action('admin_init', 'ticinoweb_register_settings');
function ticinoweb_register_settings() {
    
    // reCAPTCHA Settings
    register_setting('ticinoweb_settings_group', 'ticinoweb_recaptcha_site_key', function($v) { return tw_admin_only_option($v, 'ticinoweb_recaptcha_site_key', 'sanitize_text_field'); });
    register_setting('ticinoweb_settings_group', 'ticinoweb_recaptcha_secret_key', function($v) { return tw_admin_only_option($v, 'ticinoweb_recaptcha_secret_key', 'sanitize_text_field'); });
    register_setting('ticinoweb_settings_group', 'ticinoweb_recaptcha_threshold', function($v) { return tw_admin_only_option($v, 'ticinoweb_recaptcha_threshold', function($value) {
        return max(0, min(1, floatval($value)));
    }); });
    
    // SMTP Settings
    register_setting('ticinoweb_settings_group', 'ticinoweb_email_method', function($v) { return tw_admin_only_option($v, 'ticinoweb_email_method', function($v) { return tw_preserve_text_option($v, 'ticinoweb_email_method'); }); });
    
    // SMTP Standard
    register_setting('ticinoweb_settings_group', 'ticinoweb_smtp_host', function($v) { return tw_admin_only_option($v, 'ticinoweb_smtp_host', function($v) { return tw_preserve_text_option($v, 'ticinoweb_smtp_host'); }); });
    register_setting('ticinoweb_settings_group', 'ticinoweb_smtp_port', function($v) { return tw_admin_only_option($v, 'ticinoweb_smtp_port', function($value) {
        if ($value === null) {
            return get_option('ticinoweb_smtp_port', 587);
        }
        $val = absint($value);
        // Keep 0 only if explicitly entered as 0; default to 587 when empty
        return ($val > 0) ? $val : (($value === '0' || $value === 0) ? 587 : 587);
    }); });
    register_setting('ticinoweb_settings_group', 'ticinoweb_smtp_username', function($v) { return tw_admin_only_option($v, 'ticinoweb_smtp_username', function($v) { return tw_preserve_text_option($v, 'ticinoweb_smtp_username'); }); });
    // Password: stored verbatim (see tw_sanitize_secret). sanitize_text_field would strip "%xx" sequences and "<...>".
    register_setting('ticinoweb_settings_group', 'ticinoweb_smtp_password', function($v) { return tw_admin_only_option($v, 'ticinoweb_smtp_password', function($v) { return tw_preserve_text_option($v, 'ticinoweb_smtp_password', 'tw_sanitize_secret'); }); });
    register_setting('ticinoweb_settings_group', 'ticinoweb_smtp_encryption', function($v) { return tw_admin_only_option($v, 'ticinoweb_smtp_encryption', function($v) { return tw_preserve_text_option($v, 'ticinoweb_smtp_encryption'); }); });
    register_setting('ticinoweb_settings_group', 'ticinoweb_smtp_from_email', function($v) { return tw_admin_only_option($v, 'ticinoweb_smtp_from_email', function($v) { return tw_preserve_text_option($v, 'ticinoweb_smtp_from_email', 'sanitize_email'); }); });
    register_setting('ticinoweb_settings_group', 'ticinoweb_smtp_from_name', function($v) { return tw_admin_only_option($v, 'ticinoweb_smtp_from_name', function($v) { return tw_preserve_text_option($v, 'ticinoweb_smtp_from_name'); }); });
    
    // SendGrid
    register_setting('ticinoweb_settings_group', 'ticinoweb_sendgrid_api_key', function($v) { return tw_admin_only_option($v, 'ticinoweb_sendgrid_api_key', function($value) {
        $value = is_string($value) ? trim($value) : '';
        // If left empty in the form, keep the currently stored key (prevents accidental exposure overwrite)
        if ($value === '') {
            return get_option('ticinoweb_sendgrid_api_key', '');
        }
        return sanitize_text_field($value);
    }); });
    register_setting('ticinoweb_settings_group', 'ticinoweb_sendgrid_from_email', function($v) { return tw_admin_only_option($v, 'ticinoweb_sendgrid_from_email', function($v) { return tw_preserve_text_option($v, 'ticinoweb_sendgrid_from_email', 'sanitize_email'); }); });
    register_setting('ticinoweb_settings_group', 'ticinoweb_sendgrid_from_name', function($v) { return tw_admin_only_option($v, 'ticinoweb_sendgrid_from_name', function($v) { return tw_preserve_text_option($v, 'ticinoweb_sendgrid_from_name'); }); });
    
    // Custom Post Type Labels (Default Posts)
    register_setting('ticinoweb_settings_group', 'ticinoweb_post_name_singular', 'sanitize_text_field');
    register_setting('ticinoweb_settings_group', 'ticinoweb_post_name_plural', 'sanitize_text_field');
    register_setting('ticinoweb_settings_group', 'ticinoweb_post_gender', 'sanitize_text_field');
    register_setting('ticinoweb_settings_group', 'ticinoweb_post_icon', 'sanitize_text_field');

    // Custom Post Types Creator
    register_setting('ticinoweb_settings_group', 'ticinoweb_custom_post_types', 'ticinoweb_sanitize_cpts');
    
    // Theme Images
    register_setting('ticinoweb_settings_group', 'ticinoweb_page_header_overlay_image', function($v) { return tw_preserve_url_option($v, 'ticinoweb_page_header_overlay_image'); });
    register_setting('ticinoweb_settings_group', 'ticinoweb_page_header_bg_color', 'sanitize_hex_color');
    register_setting('ticinoweb_settings_group', 'ticinoweb_page_header_bg_image', function($v) { return tw_preserve_url_option($v, 'ticinoweb_page_header_bg_image'); });
    register_setting('ticinoweb_settings_group', 'ticinoweb_page_header_bg_gradient_enabled', 'sanitize_text_field');
    register_setting('ticinoweb_settings_group', 'ticinoweb_page_header_bg_gradient_color_1', 'sanitize_hex_color');
    register_setting('ticinoweb_settings_group', 'ticinoweb_page_header_bg_gradient_color_2', 'sanitize_hex_color');
    register_setting('ticinoweb_settings_group', 'ticinoweb_page_bg_image', function($v) { return tw_preserve_url_option($v, 'ticinoweb_page_bg_image'); });
    register_setting('ticinoweb_settings_group', 'ticinoweb_page_bg_scope', 'sanitize_text_field');
    register_setting('ticinoweb_settings_group', 'ticinoweb_page_bg_page_id', 'absint');

    // Look & Feel (Fonts + Palette)
    register_setting('ticinoweb_settings_group', 'ticinoweb_font_headings', 'sanitize_text_field');
    register_setting('ticinoweb_settings_group', 'ticinoweb_font_subheadings', 'sanitize_text_field');
    register_setting('ticinoweb_settings_group', 'ticinoweb_font_body', 'sanitize_text_field');
    register_setting('ticinoweb_settings_group', 'ticinoweb_palette_primary', 'sanitize_hex_color');
    register_setting('ticinoweb_settings_group', 'ticinoweb_palette_suggested_1', 'sanitize_hex_color');
    register_setting('ticinoweb_settings_group', 'ticinoweb_palette_suggested_2', 'sanitize_hex_color');
    register_setting('ticinoweb_settings_group', 'ticinoweb_palette_suggested_3', 'sanitize_hex_color');
    register_setting('ticinoweb_settings_group', 'ticinoweb_site_logo', function($v) { return tw_preserve_url_option($v, 'ticinoweb_site_logo'); });
    register_setting('ticinoweb_settings_group', 'ticinoweb_site_icon', function($v) { return tw_preserve_url_option($v, 'ticinoweb_site_icon'); });
    
    // Services Management
    register_setting('ticinoweb_settings_group', 'ticinoweb_services', 'ticinoweb_sanitize_services');
    
    // Contact Form Settings
    register_setting('ticinoweb_settings_group', 'ticinoweb_contact_email', function($v) { return tw_preserve_text_option($v, 'ticinoweb_contact_email', 'sanitize_email'); });
    register_setting('ticinoweb_settings_group', 'ticinoweb_contact_email_2', function($v) { return tw_preserve_text_option($v, 'ticinoweb_contact_email_2', 'sanitize_email'); });
    register_setting('ticinoweb_settings_group', 'ticinoweb_contact_email_3', function($v) { return tw_preserve_text_option($v, 'ticinoweb_contact_email_3', 'sanitize_email'); });
    
    // Contact Info Settings (spostato da Customizer)
    register_setting('ticinoweb_settings_group', 'ticinoweb_contact_phone', function($v) { return tw_preserve_text_option($v, 'ticinoweb_contact_phone'); });
    register_setting('ticinoweb_settings_group', 'ticinoweb_contact_phone_display', function($v) { return tw_preserve_text_option($v, 'ticinoweb_contact_phone_display'); });
    register_setting('ticinoweb_settings_group', 'ticinoweb_contact_phone_landline', function($v) { return tw_preserve_text_option($v, 'ticinoweb_contact_phone_landline'); });
    register_setting('ticinoweb_settings_group', 'ticinoweb_contact_phone_mobile', function($v) { return tw_preserve_text_option($v, 'ticinoweb_contact_phone_mobile'); });
    register_setting('ticinoweb_settings_group', 'ticinoweb_contact_address', function($v) { return tw_preserve_text_option($v, 'ticinoweb_contact_address'); });
    register_setting('ticinoweb_settings_group', 'ticinoweb_contact_facebook', function($v) { return tw_preserve_url_option($v, 'ticinoweb_contact_facebook'); });
    register_setting('ticinoweb_settings_group', 'ticinoweb_contact_instagram', function($v) { return tw_preserve_url_option($v, 'ticinoweb_contact_instagram'); });
    register_setting('ticinoweb_settings_group', 'ticinoweb_contact_linkedin', function($v) { return tw_preserve_url_option($v, 'ticinoweb_contact_linkedin'); });
    register_setting('ticinoweb_settings_group', 'ticinoweb_contact_youtube', function($v) { return tw_preserve_url_option($v, 'ticinoweb_contact_youtube'); });
    register_setting('ticinoweb_settings_group', 'ticinoweb_contact_x', function($v) { return tw_preserve_url_option($v, 'ticinoweb_contact_x'); });
    register_setting('ticinoweb_settings_group', 'ticinoweb_contact_tiktok', function($v) { return tw_preserve_url_option($v, 'ticinoweb_contact_tiktok'); });
    register_setting('ticinoweb_settings_group', 'ticinoweb_contact_opening_hours', 'ticinoweb_sanitize_opening_hours');
    register_setting('ticinoweb_settings_group', 'ticinoweb_contact_opening_hours_note', function($v) { return tw_preserve_text_option($v, 'ticinoweb_contact_opening_hours_note'); });
    
    // Chi Siamo Settings
    register_setting('ticinoweb_settings_group', 'ticinoweb_chi_siamo_title', function($v) { return tw_preserve_text_option($v, 'ticinoweb_chi_siamo_title'); });
    register_setting('ticinoweb_settings_group', 'ticinoweb_chi_siamo_text', function($v) { return tw_preserve_text_option($v, 'ticinoweb_chi_siamo_text', 'sanitize_textarea_field'); });
    register_setting('ticinoweb_settings_group', 'ticinoweb_chi_siamo_image', function($v) { return tw_preserve_url_option($v, 'ticinoweb_chi_siamo_image'); });
    register_setting('ticinoweb_settings_group', 'ticinoweb_chi_siamo_link', function($v) { return tw_preserve_url_option($v, 'ticinoweb_chi_siamo_link'); });
    
    // Slider Settings (spostato da Customizer)
    register_setting('ticinoweb_settings_group', 'ticinoweb_slider_count', function($value) {
        if ($value === null) { return get_option('ticinoweb_slider_count', 3); }
        $value = (int) $value;
        return max(1, min(5, $value));
    });
    for ($i = 1; $i <= 5; $i++) {
        $opt_img = "ticinoweb_slider_image_{$i}";
        $opt_lnk = "ticinoweb_slider_btn_link_{$i}";
        $opt_title = "ticinoweb_slider_title_{$i}";
        $opt_desc = "ticinoweb_slider_desc_{$i}";
        $opt_btn = "ticinoweb_slider_btn_text_{$i}";
        register_setting('ticinoweb_settings_group', $opt_img, function($v) use ($opt_img) { return tw_preserve_url_option($v, $opt_img); });
        register_setting('ticinoweb_settings_group', $opt_title, function($v) use ($opt_title) { return tw_preserve_text_option($v, $opt_title); });
        register_setting('ticinoweb_settings_group', $opt_desc, function($v) use ($opt_desc) { return tw_preserve_text_option($v, $opt_desc, 'sanitize_textarea_field'); });
        register_setting('ticinoweb_settings_group', $opt_btn, function($v) use ($opt_btn) { return tw_preserve_text_option($v, $opt_btn); });
        register_setting('ticinoweb_settings_group', $opt_lnk, function($v) use ($opt_lnk) { return tw_preserve_url_option($v, $opt_lnk); });
    }

    // Partner Settings (min 3, max 24)
    register_setting('ticinoweb_settings_group', 'ticinoweb_partner_count', function($value) {
        if ($value === null) { return get_option('ticinoweb_partner_count', 3); }
        $value = (int) $value;
        return max(3, min(24, $value));
    });
    for ($i = 1; $i <= 24; $i++) {
        $opt_logo = "ticinoweb_partner_logo_{$i}";
        $opt_lnk2 = "ticinoweb_partner_link_{$i}";
        register_setting('ticinoweb_settings_group', $opt_logo, function($v) use ($opt_logo) { return tw_preserve_url_option($v, $opt_logo); });
        register_setting('ticinoweb_settings_group', $opt_lnk2,  function($v) use ($opt_lnk2)  { return tw_preserve_url_option($v, $opt_lnk2); });
    }
    
    // Page Mapping (struttura pagine e archivi)
    register_setting('ticinoweb_settings_group', 'ticinoweb_page_mapping', 'ticinoweb_sanitize_page_mapping');
    
    // AI Instructions (admin/super-admin only)
    register_setting('ticinoweb_settings_group', 'ticinoweb_ai_instructions', 'wp_kses_post');
    register_setting('ticinoweb_settings_group', 'ticinoweb_disable_comments', function($value) {
        return tw_preserve_checkbox_option($value, 'ticinoweb_disable_comments', 1);
    });
    
    // Maintenance Mode
    register_setting('ticinoweb_settings_group', 'ticinoweb_maintenance_mode', function($value) {
        return tw_preserve_checkbox_option($value, 'ticinoweb_maintenance_mode', 0);
    });
    register_setting('ticinoweb_settings_group', 'ticinoweb_maintenance_heading', function($value) {
        // PATTERN: se il campo NON è presente nel POST corrente (es. si sta salvando
        // da un altro form come il CMS principale), preserva il valore esistente nel DB.
        // Questo evita il bug sistematico dove il salvataggio del CMS azzera i campi
        // che esistono solo nella pagina Settings.
        if (!isset($_POST['ticinoweb_maintenance_heading'])) {
            return get_option('ticinoweb_maintenance_heading', '');
        }
        return sanitize_text_field($value);
    });
    register_setting('ticinoweb_settings_group', 'ticinoweb_maintenance_subtitle', function($value) {
        if (!isset($_POST['ticinoweb_maintenance_subtitle'])) {
            return get_option('ticinoweb_maintenance_subtitle', '');
        }
        return sanitize_textarea_field($value);
    });

    // CMS Features
    register_setting('ticinoweb_settings_group', 'ticinoweb_disable_svg_icons', function($value) {
        return tw_preserve_checkbox_option($value, 'ticinoweb_disable_svg_icons', 0);
    });
    register_setting('ticinoweb_settings_group', 'ticinoweb_disable_page_mapping', function($value) {
        return tw_preserve_checkbox_option($value, 'ticinoweb_disable_page_mapping', 0);
    });
    register_setting('ticinoweb_settings_group', 'ticinoweb_disable_cpts', function($value) {
        return tw_preserve_checkbox_option($value, 'ticinoweb_disable_cpts', 0);
    });
    register_setting('ticinoweb_settings_group', 'ticinoweb_disable_reviews', function($value) {
        return tw_preserve_checkbox_option($value, 'ticinoweb_disable_reviews', 0);
    });

    // Promozioni Settings
    register_setting('ticinoweb_settings_group', 'ticinoweb_promozioni_title', function($v) { return tw_preserve_text_option($v, 'ticinoweb_promozioni_title'); });
    register_setting('ticinoweb_settings_group', 'ticinoweb_promozioni_text', function($v) { return tw_preserve_text_option($v, 'ticinoweb_promozioni_text', 'sanitize_textarea_field'); });
    register_setting('ticinoweb_settings_group', 'ticinoweb_promozioni_image', function($v) { return tw_preserve_url_option($v, 'ticinoweb_promozioni_image'); });
    register_setting('ticinoweb_settings_group', 'ticinoweb_promozioni_link', function($v) { return tw_preserve_url_option($v, 'ticinoweb_promozioni_link'); });
    register_setting('ticinoweb_settings_group', 'ticinoweb_disable_promozioni', function($value) {
        return tw_preserve_checkbox_option($value, 'ticinoweb_disable_promozioni', 0);
    });

    // Google Reviews Settings
    register_setting('ticinoweb_settings_group', 'ticinoweb_google_api_key', function($v) { return tw_admin_only_option($v, 'ticinoweb_google_api_key', function($v) { return tw_preserve_text_option($v, 'ticinoweb_google_api_key'); }); });
    register_setting('ticinoweb_settings_group', 'ticinoweb_google_place_id', function($v) { return tw_admin_only_option($v, 'ticinoweb_google_place_id', function($v) { return tw_preserve_text_option($v, 'ticinoweb_google_place_id'); }); });
    // Empty string is a real value here: it means "follow the site locale". An
    // unrecognised code is coerced to empty rather than sent to Google, which would
    // reject the request outright.
    register_setting('ticinoweb_settings_group', 'ticinoweb_google_reviews_language', function($v) {
        if ($v === null) { return get_option('ticinoweb_google_reviews_language', ''); }
        $v = sanitize_text_field($v);
        return in_array($v, array('', 'it', 'en', 'de', 'fr', 'es'), true) ? $v : '';
    });
    register_setting('ticinoweb_settings_group', 'ticinoweb_google_business_link', function($v) { return tw_preserve_url_option($v, 'ticinoweb_google_business_link'); });
    register_setting('ticinoweb_settings_group', 'ticinoweb_google_reviews_min_rating', function($v) { if ($v === null) { return get_option('ticinoweb_google_reviews_min_rating', 0); } return absint($v); });
    register_setting('ticinoweb_settings_group', 'ticinoweb_google_reviews_data', function($v) { if ($v === null) { return get_option('ticinoweb_google_reviews_data', ''); } return $v; });
    register_setting('ticinoweb_settings_group', 'ticinoweb_google_reviews_last_sync', function($v) { return tw_preserve_text_option($v, 'ticinoweb_google_reviews_last_sync'); });
    register_setting('ticinoweb_settings_group', 'ticinoweb_google_reviews_rating', function($v) { if ($v === null) { return get_option('ticinoweb_google_reviews_rating', 0); } return floatval($v); });
    register_setting('ticinoweb_settings_group', 'ticinoweb_google_reviews_count', function($v) { if ($v === null) { return get_option('ticinoweb_google_reviews_count', 0); } return absint($v); });
    

    
    // Register settings sections (required for Settings API to work properly)
    add_settings_section(
        'ticinoweb_main_section',
        __('Impostazioni Generali', 'ticinoweb-ai-theme'),
        'ticinoweb_section_callback',
        'ticinoweb_settings_group'
    );
}

// Settings section callback (displays section description)
function ticinoweb_section_callback() {
    echo '<p>' . esc_html__('Configura tutte le impostazioni del tema ticinoWEB AI CMS qui.', 'ticinoweb-ai-theme') . '</p>';
}

// Sanitize page mapping
function ticinoweb_sanitize_page_mapping($input) {
    // Preserve existing data when field not present in POST (cross-page save)
    if ($input === null) {
        return get_option('ticinoweb_page_mapping', []);
    }
    if (!is_array($input)) {
        return [];
    }
    
    $sanitized = [];
    foreach ($input as $key => $value) {
        if (!empty($value)) {
            $sanitized[$key] = absint($value);
        }
    }
    return $sanitized;
}

// Sanitize services data
function ticinoweb_sanitize_services($input) {
    // Preserve existing data when field not present in POST (cross-page save)
    if ($input === null) {
        return get_option('ticinoweb_services', []);
    }
    if (!is_array($input)) {
        return [];
    }
    
    $sanitized = [];
    foreach ($input as $service) {
        if (isset($service['title']) && !empty(trim($service['title']))) {
            $id = (!empty($service['id']) && is_string($service['id'])) ? sanitize_key($service['id']) : ('srv_' . substr(md5(uniqid((string)mt_rand(), true)), 0, 8));
            $sanitized[] = [
                'id' => $id,
                'image' => isset($service['image']) ? esc_url_raw($service['image']) : '',
                'title' => sanitize_text_field($service['title']),
                'description' => isset($service['description']) ? wp_kses_post($service['description']) : '',
                'icon' => isset($service['icon']) ? sanitize_text_field($service['icon']) : '',
                'icon_type' => isset($service['icon_type']) ? sanitize_text_field($service['icon_type']) : 'dashicon',
                'icon_svg' => isset($service['icon_svg']) ? esc_url_raw($service['icon_svg']) : ''
            ];
        }
    }
    return $sanitized;
}

// Sanitize opening hours data
function ticinoweb_sanitize_opening_hours($input) {
    if ($input === null) {
        return get_option('ticinoweb_contact_opening_hours', array());
    }
    if (!is_array($input)) {
        return array();
    }
    
    $sanitized = array();
    foreach ($input as $day_key => $day_data) {
        $sanitized_day = array(
            'closed'   => isset($day_data['closed']) ? 1 : 0,
            'open_24h' => !empty($day_data['open_24h']) ? 1 : 0,
            'slots'    => array()
        );

        // "Chiuso" wins if both boxes somehow arrive ticked. Of the two, wrongly
        // telling a customer the business is shut is the safer error than wrongly
        // telling them it is open around the clock.
        if ($sanitized_day['closed']) {
            $sanitized_day['open_24h'] = 0;
        }

        // A 24-hour day has no meaningful time slots; keeping any would leave
        // contradictory data behind the flag.
        if (!$sanitized_day['open_24h'] && isset($day_data['slots']) && is_array($day_data['slots'])) {
            foreach ($day_data['slots'] as $slot) {
                $open = isset($slot['open']) ? sanitize_text_field($slot['open']) : '';
                $close = isset($slot['close']) ? sanitize_text_field($slot['close']) : '';
                if (!empty($open) || !empty($close)) {
                    $sanitized_day['slots'][] = array(
                        'open' => $open,
                        'close' => $close
                    );
                }
            }
        }
        $sanitized[$day_key] = $sanitized_day;
    }
    return $sanitized;
}

// Sanitize Custom Post Types
function ticinoweb_sanitize_cpts($input) {
    // Preserve existing data when field not present in POST (cross-page save)
    if ($input === null) {
        return get_option('ticinoweb_custom_post_types', []);
    }
    if (!is_array($input)) {
        return [];
    }
    
    $sanitized = [];
    foreach ($input as $cpt) {
        if (isset($cpt['slug']) && !empty(trim($cpt['slug']))) {
            $sanitized[] = [
                'slug' => sanitize_title($cpt['slug']),
                'singular' => sanitize_text_field($cpt['singular']),
                'plural' => sanitize_text_field($cpt['plural']),
                'icon' => sanitize_text_field($cpt['icon']),
                'icon_type' => isset($cpt['icon_type']) ? sanitize_text_field($cpt['icon_type']) : 'dashicon',
                'icon_svg' => isset($cpt['icon_svg']) ? esc_url_raw($cpt['icon_svg']) : '',
                'public' => isset($cpt['public']) ? 1 : 0,
                'has_archive' => isset($cpt['has_archive']) ? 1 : 0
            ];
        }
    }
    return $sanitized;
}

// Settings page HTML
function ticinoweb_settings_page() {
    if (!current_user_can('edit_pages')) {
        wp_die(__('Permessi insufficienti.', 'ticinoweb-ai-theme'));
    }

    // Genera un nonce per le richieste AJAX degli orari
    $ajax_nonce = wp_create_nonce('ticinoweb_admin_ajax_nonce');
    echo '<script>var ticinoweb_admin_vars = { ajax_nonce: ' . json_encode($ajax_nonce) . ' };</script>';

    $ticinoweb_is_admin = current_user_can('manage_network') || current_user_can('manage_options');

    // Get theme version from parent theme style.css
    $theme = wp_get_theme('ticinoweb-ai-theme');
    $version = $theme->get('Version');
    ?>
    <div class="wrap">
        <div style="margin-bottom: 15px; text-align: left;">
            <img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/logo-ticinoweb-2025.png" alt="ticinoWEB" style="max-width: 150px; height: auto; margin-bottom: -2px; margin-left: -6px; display: block;">
            <h1 style="margin: 0; margin-bottom: 3px;"><?php echo esc_html(get_admin_page_title()); ?></h1>
            <p style="margin: 0; color: #666; font-size: 13px; display:flex; align-items:center;">v<?php echo esc_html($version); ?><?php ticinoweb_render_version_badge($version); ?></p>
            <?php ticinoweb_render_child_version_line(); ?>
        </div>
        
        <?php settings_errors(); ?>
        
        <form method="post" action="options.php">
            <?php
            settings_fields('ticinoweb_settings_group');
            do_settings_sections('ticinoweb_settings_group');
            ?>
            
            <div class="ticinoweb-settings-tabs">
                <h2 class="nav-tab-wrapper">
                    <a href="#services" class="nav-tab nav-tab-active"><?php _e('Servizi Principali', 'ticinoweb-ai-theme'); ?></a>
                    <?php if (!get_option('ticinoweb_disable_svg_icons')): ?>
                    <a href="#svg-icons" class="nav-tab"><?php _e('Icone SVG', 'ticinoweb-ai-theme'); ?></a>
                    <?php endif; ?>
                    <a href="#theme-images" class="nav-tab"><?php _e('Look & Feel', 'ticinoweb-ai-theme'); ?></a>
                    <a href="#slider" class="nav-tab"><?php _e('Slider & Partner', 'ticinoweb-ai-theme'); ?></a>
                    <?php if (!get_option('ticinoweb_disable_promozioni')): ?>
                    <a href="#promozioni" class="nav-tab"><?php _e('Promozioni', 'ticinoweb-ai-theme'); ?></a>
                    <?php endif; ?>
                    <a href="#contatti" class="nav-tab"><?php _e('Contatti', 'ticinoweb-ai-theme'); ?></a>
                    <a href="#chi-siamo" class="nav-tab"><?php _e('Chi Siamo', 'ticinoweb-ai-theme'); ?></a>
                    <a href="#form-submissions" class="nav-tab"><?php _e('Invii Ricevuti', 'ticinoweb-ai-theme'); ?></a>
                    <?php if ($ticinoweb_is_admin): ?>
                    <?php if (!get_option('ticinoweb_disable_page_mapping')): ?>
                    <a href="#mappatura" class="nav-tab"><?php _e('Mappatura Pagine', 'ticinoweb-ai-theme'); ?></a>
                    <?php endif; ?>
                    <a href="#recaptcha" class="nav-tab"><?php _e('reCAPTCHA', 'ticinoweb-ai-theme'); ?></a>
                    <a href="#smtp" class="nav-tab"><?php _e('SMTP / Email', 'ticinoweb-ai-theme'); ?></a>
                    <?php if (!get_option('ticinoweb_disable_reviews')): ?>
                    <a href="#recensioni" class="nav-tab"><?php _e('Recensioni', 'ticinoweb-ai-theme'); ?></a>
                    <?php endif; ?>
                    <?php if (!get_option('ticinoweb_disable_cpts')): ?>
                    <a href="#custom-fields" class="nav-tab"><?php _e('Custom Post Types', 'ticinoweb-ai-theme'); ?></a>
                    <?php endif; ?>
                    <?php endif; ?>
                </h2>
                
                <!-- Promozioni Tab -->
                <?php if (!get_option('ticinoweb_disable_promozioni')): ?>
                <div id="promozioni" class="ticinoweb-tab-content">
                    <h2><?php _e('Configurazione Promozioni', 'ticinoweb-ai-theme'); ?></h2>
                    <p class="description"><?php _e('Gestisci i contenuti della sezione Promozioni.', 'ticinoweb-ai-theme'); ?></p>
                    
                    <table class="form-table">
                        <tr>
                            <th scope="row">
                                <label for="ticinoweb_promozioni_title"><?php _e('Titolo', 'ticinoweb-ai-theme'); ?></label>
                            </th>
                            <td>
                                <input type="text" id="ticinoweb_promozioni_title" name="ticinoweb_promozioni_title" 
                                       value="<?php echo esc_attr(get_option('ticinoweb_promozioni_title')); ?>" 
                                       class="large-text" placeholder="<?php _e('Titolo della promozione', 'ticinoweb-ai-theme'); ?>">
                                <p class="description"><?php _e('Titolo della sezione Promozioni.', 'ticinoweb-ai-theme'); ?></p>
                                <p class="description"><?php _e('Sezione pubblicata tramite shortcode: <code>[ticinoweb_promozioni]</code>.', 'ticinoweb-ai-theme'); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <label for="ticinoweb_promozioni_text"><?php _e('Testo', 'ticinoweb-ai-theme'); ?></label>
                            </th>
                            <td>
                                <textarea id="ticinoweb_promozioni_text" name="ticinoweb_promozioni_text" 
                                          class="large-text" rows="6" placeholder="Dettagli della promozione..."><?php echo esc_textarea(get_option('ticinoweb_promozioni_text')); ?></textarea>
                                <p class="description"><?php _e('Testo principale della promozione.', 'ticinoweb-ai-theme'); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <label for="ticinoweb_promozioni_image"><?php _e('Immagine', 'ticinoweb-ai-theme'); ?></label>
                            </th>
                            <td>
                                <input type="text" id="ticinoweb_promozioni_image" name="ticinoweb_promozioni_image" 
                                       value="<?php echo esc_attr(get_option('ticinoweb_promozioni_image')); ?>" 
                                       class="regular-text">
                                <button type="button" class="button button-secondary" id="upload-promozioni-image"><?php _e('Carica Immagine', 'ticinoweb-ai-theme'); ?></button>
                                <div id="promozioni-image-preview" style="margin-top: 10px;">
                                    <?php $promo_img = get_option('ticinoweb_promozioni_image'); if (!empty($promo_img)): ?>
                                        <img src="<?php echo esc_url($promo_img); ?>" style="max-width: 300px; height: auto; border: 1px solid #ddd; border-radius: 4px;">
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <label for="ticinoweb_promozioni_link"><?php _e('Link', 'ticinoweb-ai-theme'); ?></label>
                            </th>
                            <td>
                                <input type="text" id="ticinoweb_promozioni_link" name="ticinoweb_promozioni_link" 
                                       value="<?php echo esc_attr(get_option('ticinoweb_promozioni_link')); ?>" 
                                       class="regular-text" placeholder="https://...">
                                <p class="description"><?php _e('Link per il pulsante di azione della promozione.', 'ticinoweb-ai-theme'); ?></p>
                            </td>
                        </tr>
                    </table>
                    
                    <script type="text/javascript">
                    jQuery(function($) {
                        $('#upload-promozioni-image').on('click', function(e) {
                            e.preventDefault();
                            var image_frame = wp.media({
                                title: '<?php _e('Seleziona Immagine Promozione', 'ticinoweb-ai-theme'); ?>',
                                multiple: false,
                                library: { type: 'image' }
                            });
                            image_frame.on('select', function() {
                                var image_data = image_frame.state().get('selection').first().toJSON();
                                $('#ticinoweb_promozioni_image').val(image_data.url);
                                $('#promozioni-image-preview').html('<img src="' + image_data.url + '" style="max-width: 300px; height: auto; border: 1px solid #ddd; border-radius: 4px;">');
                            });
                            image_frame.open();
                        });
                    });
                    </script>
                </div>
                <?php endif; ?>
                
                <!-- Contatti Tab -->
                <div id="contatti" class="ticinoweb-tab-content">
                    <h2><?php _e('Configurazione Contatti', 'ticinoweb-ai-theme'); ?></h2>
                    <p class="description"><?php _e('Configura i dettagli di contatto visualizzati in tutto il sito e la destinazione del form contatti.', 'ticinoweb-ai-theme'); ?></p>
                    
                    <table class="form-table">
                        <tr>
                            <th scope="row">
                                <div style="display:flex; align-items:center;">
                                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#555" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="margin-right:8px;"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path><polyline points="22,6 12,13 2,6"></polyline></svg>
                                    <label for="ticinoweb_contact_email"><?php _e('Email di Ricezione Form', 'ticinoweb-ai-theme'); ?></label>
                                </div>
                            </th>
                            <td>
                                <input type="email" id="ticinoweb_contact_email" name="ticinoweb_contact_email" 
                                       value="<?php echo esc_attr(get_option('ticinoweb_contact_email')); ?>" 
                                       class="regular-text" placeholder="info@tuosito.com">
                                <p class="description"><?php _e('Email dove verranno inoltrati i messaggi dal form contatti.', 'ticinoweb-ai-theme'); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <div style="display:flex; align-items:center;">
                                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#555" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="margin-right:8px;"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path><polyline points="22,6 12,13 2,6"></polyline></svg>
                                    <label for="ticinoweb_contact_email_2"><?php _e('Email Contatto #2', 'ticinoweb-ai-theme'); ?></label>
                                </div>
                            </th>
                            <td>
                                <input type="email" id="ticinoweb_contact_email_2" name="ticinoweb_contact_email_2" 
                                       value="<?php echo esc_attr(get_option('ticinoweb_contact_email_2')); ?>" 
                                       class="regular-text" placeholder="info2@tuosito.com">
                                <p class="description"><?php _e('Seconda email di contatto per ricezione form o riferimenti.', 'ticinoweb-ai-theme'); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <div style="display:flex; align-items:center;">
                                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#555" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="margin-right:8px;"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path><polyline points="22,6 12,13 2,6"></polyline></svg>
                                    <label for="ticinoweb_contact_email_3"><?php _e('Email Contatto #3', 'ticinoweb-ai-theme'); ?></label>
                                </div>
                            </th>
                            <td>
                                <input type="email" id="ticinoweb_contact_email_3" name="ticinoweb_contact_email_3" 
                                       value="<?php echo esc_attr(get_option('ticinoweb_contact_email_3')); ?>" 
                                       class="regular-text" placeholder="info3@tuosito.com">
                                <p class="description"><?php _e('Terza email di contatto per ricezione form o riferimenti.', 'ticinoweb-ai-theme'); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <div style="display:flex; align-items:center;">
                                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#555" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="margin-right:8px;"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path></svg>
                                    <label for="ticinoweb_contact_phone"><?php _e('Telefono', 'ticinoweb-ai-theme'); ?></label>
                                </div>
                            </th>
                            <td>
                                <input type="text" id="ticinoweb_contact_phone" name="ticinoweb_contact_phone" 
                                       value="<?php echo esc_attr(get_option('ticinoweb_contact_phone')); ?>" 
                                       class="regular-text" placeholder="+41 79 123 45 67">
                                <p class="description"><?php _e('Numero di telefono principale per contatti.', 'ticinoweb-ai-theme'); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <div style="display:flex; align-items:center;">
                                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#555" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="margin-right:8px;"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path></svg>
                                    <label for="ticinoweb_contact_phone_landline"><?php _e('Telefono fisso', 'ticinoweb-ai-theme'); ?></label>
                                </div>
                            </th>
                            <td>
                                <input type="text" id="ticinoweb_contact_phone_landline" name="ticinoweb_contact_phone_landline" 
                                       value="<?php echo esc_attr(get_option('ticinoweb_contact_phone_landline')); ?>" 
                                       class="regular-text" placeholder="+41 91 123 45 67">
                                <p class="description"><?php _e('Numero di telefono fisso della sede.', 'ticinoweb-ai-theme'); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <div style="display:flex; align-items:center;">
                                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#555" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="margin-right:8px;"><rect x="5" y="2" width="14" height="20" rx="2" ry="2"></rect><line x1="12" y1="18" x2="12.01" y2="18"></line></svg>
                                    <label for="ticinoweb_contact_phone_mobile"><?php _e('Cellulare', 'ticinoweb-ai-theme'); ?></label>
                                </div>
                            </th>
                            <td>
                                <input type="text" id="ticinoweb_contact_phone_mobile" name="ticinoweb_contact_phone_mobile" 
                                       value="<?php echo esc_attr(get_option('ticinoweb_contact_phone_mobile')); ?>" 
                                       class="regular-text" placeholder="+41 79 123 45 67">
                                <p class="description"><?php _e('Numero di cellulare per contatti.', 'ticinoweb-ai-theme'); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <div style="display:flex; align-items:center;">
                                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#555" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="margin-right:8px;"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path><circle cx="12" cy="10" r="3"></circle></svg>
                                    <label for="ticinoweb_contact_address"><?php _e('Indirizzo', 'ticinoweb-ai-theme'); ?></label>
                                </div>
                            </th>
                            <td>
                                <input type="text" id="ticinoweb_contact_address" name="ticinoweb_contact_address" 
                                       value="<?php echo esc_attr(get_option('ticinoweb_contact_address')); ?>" 
                                       class="regular-text" placeholder="Via Example 123, 6900 Lugano">
                                <p class="description"><?php _e('Indirizzo completo della sede.', 'ticinoweb-ai-theme'); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <div style="display:flex; align-items:center;">
                                    <svg width="20" height="20" viewBox="0 0 24 24" style="margin-right:8px;"><path fill="#1877F2" d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>
                                    <label for="ticinoweb_contact_facebook"><?php _e('Facebook URL', 'ticinoweb-ai-theme'); ?></label>
                                </div>
                            </th>
                            <td>
                                <input type="url" id="ticinoweb_contact_facebook" name="ticinoweb_contact_facebook" 
                                       value="<?php echo esc_attr(get_option('ticinoweb_contact_facebook')); ?>" 
                                       class="regular-text" placeholder="https://facebook.com/tuopage">
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <div style="display:flex; align-items:center;">
                                    <svg width="20" height="20" viewBox="0 0 24 24" style="margin-right:8px;"><path fill="#E1306C" d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zM12 0C8.741 0 8.333.014 7.053.072 2.695.272.273 2.69.073 7.052.014 8.333 0 8.741 0 12c0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98C8.333 23.986 8.741 24 12 24c3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98C15.668.014 15.259 0 12 0zm0 5.838a6.162 6.162 0 100 12.324 6.162 6.162 0 000-12.324zM12 16a4 4 0 110-8 4 4 0 010 8zm6.406-11.845a1.44 1.44 0 100 2.881 1.44 1.44 0 000-2.881z"/></svg>
                                    <label for="ticinoweb_contact_instagram"><?php _e('Instagram URL', 'ticinoweb-ai-theme'); ?></label>
                                </div>
                            </th>
                            <td>
                                <input type="url" id="ticinoweb_contact_instagram" name="ticinoweb_contact_instagram" 
                                       value="<?php echo esc_attr(get_option('ticinoweb_contact_instagram')); ?>" 
                                       class="regular-text" placeholder="https://instagram.com/tuoprofilo">
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <div style="display:flex; align-items:center;">
                                    <svg width="20" height="20" viewBox="0 0 24 24" style="margin-right:8px;"><path fill="#0077b5" d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"/></svg>
                                    <label for="ticinoweb_contact_linkedin"><?php _e('LinkedIn URL', 'ticinoweb-ai-theme'); ?></label>
                                </div>
                            </th>
                            <td>
                                <input type="url" id="ticinoweb_contact_linkedin" name="ticinoweb_contact_linkedin" 
                                       value="<?php echo esc_attr(get_option('ticinoweb_contact_linkedin')); ?>" 
                                       class="regular-text" placeholder="https://linkedin.com/company/tuoazienda">
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <div style="display:flex; align-items:center;">
                                    <svg width="20" height="20" viewBox="0 0 24 24" style="margin-right:8px;"><path fill="#FF0000" d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/></svg>
                                    <label for="ticinoweb_contact_youtube"><?php _e('YouTube URL', 'ticinoweb-ai-theme'); ?></label>
                                </div>
                            </th>
                            <td>
                                <input type="url" id="ticinoweb_contact_youtube" name="ticinoweb_contact_youtube" 
                                       value="<?php echo esc_attr(get_option('ticinoweb_contact_youtube')); ?>" 
                                       class="regular-text" placeholder="https://youtube.com/channel/...">
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <div style="display:flex; align-items:center;">
                                    <svg width="20" height="20" viewBox="0 0 24 24" style="margin-right:8px;"><path fill="#000000" d="M18.901 1.153h3.68l-8.04 9.19L24 22.846h-7.406l-5.8-7.584-6.638 7.584H.474l8.6-9.83L0 1.154h7.594l5.243 6.932ZM17.61 20.644h2.039L6.486 3.24H4.298Z"/></svg>
                                    <label for="ticinoweb_contact_x"><?php _e('X (Twitter) URL', 'ticinoweb-ai-theme'); ?></label>
                                </div>
                            </th>
                            <td>
                                <input type="url" id="ticinoweb_contact_x" name="ticinoweb_contact_x" 
                                       value="<?php echo esc_attr(get_option('ticinoweb_contact_x')); ?>" 
                                       class="regular-text" placeholder="https://x.com/tuoprofilo">
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <div style="display:flex; align-items:center;">
                                    <svg width="20" height="20" viewBox="0 0 448 512" style="margin-right:8px;"><path fill="#000000" d="M448 209.91a210.06 210.06 0 0 1-122.77-39.25V349.38A162.55 162.55 0 1 1 185 188.31V278.2a90.25 90.25 0 1 0 43.7 73.07 14.22 14.22 0 0 0 1.6-1V1.5h90.58c3.54 84.7 65.57 151.72 150.37 155.07v53.33z"/></svg>
                                    <label for="ticinoweb_contact_tiktok"><?php _e('TikTok URL', 'ticinoweb-ai-theme'); ?></label>
                                </div>
                            </th>
                            <td>
                                <input type="url" id="ticinoweb_contact_tiktok" name="ticinoweb_contact_tiktok" 
                                       value="<?php echo esc_attr(get_option('ticinoweb_contact_tiktok')); ?>" 
                                       class="regular-text" placeholder="https://tiktok.com/@tuoprofilo">
                            </td>
                        </tr>
                        
                        <!-- Opening Hours Row -->
                        <tr id="ticinoweb-opening-hours-row">
                            <th scope="row">
                                <div style="display:flex; align-items:center;">
                                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#555" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="margin-right:8px;"><circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 16 14"></polyline></svg>
                                    <label><?php _e('Orari di Apertura', 'ticinoweb-ai-theme'); ?></label>
                                </div>
                            </th>
                            <td>
                                <div class="tw-opening-hours-wrapper">
                                    <div style="margin-bottom: 15px;">
                                        <button type="button" class="button button-secondary" id="tw-sync-google-hours" style="display:inline-flex; align-items:center; gap:6px;">
                                            <span class="dashicons dashicons-google" style="font-size:17px; width:17px; height:17px; margin-top:2px;"></span>
                                            <?php _e('Sincronizza con Google My Business', 'ticinoweb-ai-theme'); ?>
                                        </button>
                                        <span class="spinner" id="tw-sync-spinner" style="float:none; margin:0 10px; vertical-align:middle;"></span>
                                        <span id="tw-sync-message" style="margin-left: 10px; font-weight: 500;"></span>
                                    </div>
                                    
                                    <table class="tw-opening-hours-table" style="width:100%; max-width:600px; border-collapse:collapse;">
                                        <thead>
                                            <tr style="border-bottom:1px solid #ddd;">
                                                <th style="text-align:left; padding:8px 0; font-weight:600; width:120px;"><?php _e('Giorno', 'ticinoweb-ai-theme'); ?></th>
                                                <th style="text-align:left; padding:8px 0; font-weight:600; width:90px;"><?php _e('Stato', 'ticinoweb-ai-theme'); ?></th>
                                                <th style="text-align:left; padding:8px 0; font-weight:600;"><?php _e('Fasce Orarie', 'ticinoweb-ai-theme'); ?></th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            $days_labels = array(
                                                'monday'    => __('Lunedì', 'ticinoweb-ai-theme'),
                                                'tuesday'   => __('Martedì', 'ticinoweb-ai-theme'),
                                                'wednesday' => __('Mercoledì', 'ticinoweb-ai-theme'),
                                                'thursday'  => __('Giovedì', 'ticinoweb-ai-theme'),
                                                'friday'    => __('Venerdì', 'ticinoweb-ai-theme'),
                                                'saturday'  => __('Sabato', 'ticinoweb-ai-theme'),
                                                'sunday'    => __('Domenica', 'ticinoweb-ai-theme'),
                                            );
                                            
                                            $hours = get_option('ticinoweb_contact_opening_hours', array());
                                            
                                            // Se non ci sono dati, inizializza i giorni a vuoto
                                            foreach ($days_labels as $day_key => $day_label) {
                                                if (!isset($hours[$day_key])) {
                                                    $hours[$day_key] = array('closed' => 1, 'open_24h' => 0, 'slots' => array());
                                                }
                                            }
                                            
                                            foreach ($days_labels as $day_key => $day_label):
                                                $day_data = $hours[$day_key];
                                                $is_closed = !empty($day_data['closed']) ? 1 : 0;
                                                $is_24h = !empty($day_data['open_24h']) ? 1 : 0;
                                                $slots = isset($day_data['slots']) && is_array($day_data['slots']) ? $day_data['slots'] : array();
                                                
                                                // Se non è chiuso e non ci sono fasce, mostrane almeno una vuota per comodità
                                                if (!$is_closed && !$is_24h && empty($slots)) {
                                                    $slots[] = array('open' => '', 'close' => '');
                                                }

                                                // Le fasce non si mostrano né quando è chiuso né quando è aperto 24 ore
                                                $hide_slots = $is_closed || $is_24h;
                                            ?>
                                            <tr class="day-row" data-day="<?php echo esc_attr($day_key); ?>" style="border-bottom:1px solid #f0f0f0;">
                                                <td style="padding:10px 0; vertical-align:top; font-weight:500;">
                                                    <?php echo esc_html($day_label); ?>
                                                </td>
                                                <td style="padding:10px 0; vertical-align:top; white-space:nowrap;">
                                                    <label style="display:inline-flex; align-items:center; cursor:pointer;">
                                                        <input type="checkbox" name="ticinoweb_contact_opening_hours[<?php echo esc_attr($day_key); ?>][closed]" value="1" class="day-closed-toggle" <?php checked($is_closed, 1); ?>>
                                                        <span style="margin-left:4px;"><?php _e('Chiuso', 'ticinoweb-ai-theme'); ?></span>
                                                    </label>
                                                    <label style="display:inline-flex; align-items:center; cursor:pointer; margin-left:12px;">
                                                        <input type="checkbox" name="ticinoweb_contact_opening_hours[<?php echo esc_attr($day_key); ?>][open_24h]" value="1" class="day-24h-toggle" <?php checked($is_24h, 1); ?>>
                                                        <span style="margin-left:4px;"><?php _e('24 ore', 'ticinoweb-ai-theme'); ?></span>
                                                    </label>
                                                </td>
                                                <td style="padding:10px 0; vertical-align:top;">
                                                    <div class="slots-container" style="<?php echo $hide_slots ? 'display:none;' : ''; ?>">
                                                        <?php 
                                                        $slot_idx = 0;
                                                        foreach ($slots as $slot): 
                                                            $open = isset($slot['open']) ? $slot['open'] : '';
                                                            $close = isset($slot['close']) ? $slot['close'] : '';
                                                        ?>
                                                        <div class="slot-row" style="display:flex; align-items:center; gap:8px; margin-bottom:8px;">
                                                            <div class="time-input-group" style="position:relative; display:inline-block;">
                                                                <input type="time" name="ticinoweb_contact_opening_hours[<?php echo esc_attr($day_key); ?>][slots][<?php echo $slot_idx; ?>][open]" value="<?php echo esc_attr($open); ?>" style="padding:4px 8px; border:1px solid #ccc; border-radius:4px;">
                                                                <span style="font-size:11px; color:#888; display:block;"><?php _e('Apertura', 'ticinoweb-ai-theme'); ?></span>
                                                            </div>
                                                            <span style="color:#666;">&mdash;</span>
                                                            <div class="time-input-group" style="position:relative; display:inline-block;">
                                                                <input type="time" name="ticinoweb_contact_opening_hours[<?php echo esc_attr($day_key); ?>][slots][<?php echo $slot_idx; ?>][close]" value="<?php echo esc_attr($close); ?>" style="padding:4px 8px; border:1px solid #ccc; border-radius:4px;">
                                                                <span style="font-size:11px; color:#888; display:block;"><?php _e('Chiusura', 'ticinoweb-ai-theme'); ?></span>
                                                            </div>
                                                            <button type="button" class="button remove-slot-btn" style="min-width:auto; padding:0 8px; color:#dc2626; border-color:#fca5a5; background:#fef2f2; margin-bottom:14px;" title="<?php _e('Rimuovi fascia', 'ticinoweb-ai-theme'); ?>">&times;</button>
                                                        </div>
                                                        <?php 
                                                            $slot_idx++;
                                                        endforeach; 
                                                        ?>
                                                    </div>
                                                    <div class="add-slot-container" style="<?php echo $hide_slots ? 'display:none;' : ''; ?>">
                                                        <button type="button" class="button button-secondary add-slot-btn" style="padding:0 8px; height:26px; line-height:24px; font-size:18px; font-weight:bold;" title="<?php _e('Aggiungi fascia', 'ticinoweb-ai-theme'); ?>">+</button>
                                                        <?php if ($day_key !== 'sunday'): ?>
                                                        <button type="button" class="button copy-day-btn" style="padding:0 8px; height:26px; line-height:24px; margin-left:6px; display:inline-flex; align-items:center; gap:4px;" title="<?php esc_attr_e('Copia questi orari nel giorno successivo', 'ticinoweb-ai-theme'); ?>">
                                                            <span class="dashicons dashicons-arrow-down-alt" style="font-size:14px; width:14px; height:14px; margin-top:5px;"></span><?php _e('Copia sotto', 'ticinoweb-ai-theme'); ?>
                                                        </button>
                                                        <?php endif; ?>
                                                    </div>
                                                </td>
                                            </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                    
                                    <div style="margin-top:20px;">
                                        <label for="ticinoweb_contact_opening_hours_note" style="display:block; font-weight:600; margin-bottom:5px;"><?php _e('Note / Orari Speciali / Orario Estivo', 'ticinoweb-ai-theme'); ?></label>
                                        <input type="text" id="ticinoweb_contact_opening_hours_note" name="ticinoweb_contact_opening_hours_note" 
                                               value="<?php echo esc_attr(get_option('ticinoweb_contact_opening_hours_note')); ?>" 
                                               class="large-text" placeholder="<?php _e('Es: Sabato (Orario estivo) 08:30 - 15:00 continuato', 'ticinoweb-ai-theme'); ?>">
                                        <p class="description"><?php _e('Testo aggiuntivo visualizzato sotto l\'elenco degli orari (es. per festività o variazioni stagionali).', 'ticinoweb-ai-theme'); ?></p>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    </table>
                </div>
                
                <!-- Slider Tab -->
                <div id="slider" class="ticinoweb-tab-content">
                    <h2><?php _e('Configurazione Slider', 'ticinoweb-ai-theme'); ?></h2>
                    <p class="description"><?php _e('Gestisci le slide dello slider homepage. Aggiungi da 1 a 5 slide con immagine, titolo, descrizione e bottone.', 'ticinoweb-ai-theme'); ?></p>
                    
                    <table class="form-table">
                        <tr>
                            <th scope="row">
                                <label for="ticinoweb_slider_count"><?php _e('Numero di Slide', 'ticinoweb-ai-theme'); ?></label>
                            </th>
                            <td>
                                <input type="number" id="ticinoweb_slider_count" name="ticinoweb_slider_count" 
                                       value="<?php echo esc_attr(get_option('ticinoweb_slider_count', 3)); ?>" 
                                       min="1" max="5" class="small-text">
                                <p class="description"><?php _e('Inserisci da 1 a 5 slide.', 'ticinoweb-ai-theme'); ?></p>
                            </td>
                        </tr>
                    </table>
                    
                    <div id="slider-items-container">
                        <?php
                        $slider_count = (int) get_option('ticinoweb_slider_count', 3);
                        $defaults = array(
                            1 => array('title' => '', 'desc' => '', 'btn_text' => '', 'btn_link' => ''),
                            2 => array('title' => '', 'desc' => '', 'btn_text' => '', 'btn_link' => ''),
                            3 => array('title' => '', 'desc' => '', 'btn_text' => '', 'btn_link' => ''),
                            4 => array('title' => '', 'desc' => '', 'btn_text' => '', 'btn_link' => ''),
                            5 => array('title' => '', 'desc' => '', 'btn_text' => '', 'btn_link' => ''),
                        );
                        
                        for ($i = 1; $i <= 5; $i++):
                            $default = isset($defaults[$i]) ? $defaults[$i] : array('title' => '', 'desc' => '', 'btn_text' => '', 'btn_link' => '');
                            $is_visible = $i <= $slider_count ? 'block' : 'none';
                            $image = get_option("ticinoweb_slider_image_$i", '');
                            $title = get_option("ticinoweb_slider_title_$i", $default['title']);
                            $desc = get_option("ticinoweb_slider_desc_$i", $default['desc']);
                            $btn_text = get_option("ticinoweb_slider_btn_text_$i", $default['btn_text']);
                            $btn_link = get_option("ticinoweb_slider_btn_link_$i", $default['btn_link']);
                        ?>
                        <?php
                            $is_open = false;
                            $body_display = $is_open ? 'block' : 'none';
                            $aria_expanded = $is_open ? 'true' : 'false';
                        ?>
                        <div class="slider-item" data-slide="<?php echo $i; ?>" style="display: <?php echo $is_visible; ?>; background: #fff; border: 1px solid #ccd0d4; border-radius: 6px; padding: 0; margin-bottom: 16px; overflow: hidden; box-shadow: 0 1px 2px rgba(0,0,0,0.04);">
                            <div class="slider-item-header" style="display: flex; align-items: center; justify-content: space-between; padding: 12px 16px; cursor: pointer; background: #f8fafc; border-bottom: 1px solid #e2e8f0; user-select: none;">
                                <div style="display: flex; align-items: center; gap: 8px;">
                                    <span class="dashicons dashicons-move slider-drag-handle" style="cursor: grab; color: #94a3b8; padding: 4px;" title="<?php esc_attr_e('Trascina per riordinare', 'ticinoweb-ai-theme'); ?>"></span>
                                    <span class="dashicons dashicons-images-alt2" style="color: #64748b;" aria-hidden="true"></span>
                                    <strong class="slider-item-number" style="font-size: 13.5px;"><?php printf(__('Slide %d', 'ticinoweb-ai-theme'), $i); ?></strong>
                                    <span class="slider-title-preview" style="color:#64748b; font-size: 13px; margin-left: 6px;">
                                        <?php echo !empty($title) ? esc_html($title) : __('(nessun titolo)', 'ticinoweb-ai-theme'); ?>
                                    </span>
                                </div>
                                <div style="display: flex; align-items: center; gap: 6px;">
                                    <button type="button" class="button button-small slider-move-up" title="<?php esc_attr_e('Sposta su', 'ticinoweb-ai-theme'); ?>" style="padding: 0 4px; height: 26px; line-height: 24px;">
                                        <span class="dashicons dashicons-arrow-up-alt2" style="font-size: 15px; width: 15px; height: 15px; vertical-align: middle;"></span>
                                    </button>
                                    <button type="button" class="button button-small slider-move-down" title="<?php esc_attr_e('Sposta giù', 'ticinoweb-ai-theme'); ?>" style="padding: 0 4px; height: 26px; line-height: 24px;">
                                        <span class="dashicons dashicons-arrow-down-alt2" style="font-size: 15px; width: 15px; height: 15px; vertical-align: middle;"></span>
                                    </button>
                                    <button type="button" class="button-link slider-accordion-toggle" aria-expanded="<?php echo $aria_expanded; ?>" aria-controls="slider-item-body-<?php echo $i; ?>" style="color: #64748b; padding: 4px;">
                                        <span class="dashicons dashicons-arrow-down"></span>
                                    </button>
                                </div>
                            </div>
                            <div class="slider-item-body" id="slider-item-body-<?php echo $i; ?>" style="padding: 16px; display: <?php echo $body_display; ?>;">
                                <table class="form-table">
                                    <tr>
                                        <th scope="row">
                                            <label><?php _e('Immagine', 'ticinoweb-ai-theme'); ?></label>
                                        </th>
                                        <td>
                                            <input type="text" name="ticinoweb_slider_image_<?php echo $i; ?>" 
                                                   value="<?php echo esc_attr($image); ?>" 
                                                   class="regular-text slider-image-url">
                                            <button type="button" class="button button-secondary upload-slider-image"><?php _e('Carica Immagine', 'ticinoweb-ai-theme'); ?></button>
                                            <div class="slider-image-preview" style="margin-top: 10px;">
                                                <?php if (!empty($image)): ?>
                                                    <img src="<?php echo esc_url($image); ?>" style="max-width: 300px; height: auto; border: 1px solid #ddd; border-radius: 4px;">
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th scope="row">
                                            <label><?php _e('Titolo', 'ticinoweb-ai-theme'); ?></label>
                                        </th>
                                        <td>
                                              <input type="text" name="ticinoweb_slider_title_<?php echo $i; ?>" 
                                                  value="<?php echo esc_attr($title); ?>" 
                                                  class="regular-text slider-title-input" placeholder="Titolo della slide">
                                        </td>
                                    </tr>
                                    <tr>
                                        <th scope="row">
                                            <label><?php _e('Descrizione', 'ticinoweb-ai-theme'); ?></label>
                                        </th>
                                        <td>
                                            <textarea name="ticinoweb_slider_desc_<?php echo $i; ?>" 
                                                      class="large-text" rows="3" placeholder="Descrizione della slide"><?php echo esc_textarea($desc); ?></textarea>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th scope="row">
                                            <label><?php _e('Testo Bottone', 'ticinoweb-ai-theme'); ?></label>
                                        </th>
                                        <td>
                                            <input type="text" name="ticinoweb_slider_btn_text_<?php echo $i; ?>" 
                                                   value="<?php echo esc_attr($btn_text); ?>" 
                                                   class="regular-text" placeholder="Testo bottone">
                                        </td>
                                    </tr>
                                    <tr>
                                        <th scope="row">
                                            <label><?php _e('Link Bottone', 'ticinoweb-ai-theme'); ?></label>
                                        </th>
                                        <td>
                                            <input type="text" name="ticinoweb_slider_btn_link_<?php echo $i; ?>" 
                                                   value="<?php echo esc_attr($btn_link); ?>" 
                                                   class="regular-text" placeholder="https://... o #ancora">
                                        </td>
                                    </tr>
                                </table>
                            </div>
                        </div>
                        <?php endfor; ?>
                    </div>

                    <hr>
                    <h2><?php _e('Partner', 'ticinoweb-ai-theme'); ?></h2>
                    <p class="description"><?php _e('Aggiungi i loghi dei partner con link; supporta da 3 a 24 loghi.', 'ticinoweb-ai-theme'); ?></p>

                    <table class="form-table">
                        <tr>
                            <th scope="row">
                                <label for="ticinoweb_partner_count"><?php _e('Numero di Loghi', 'ticinoweb-ai-theme'); ?></label>
                            </th>
                            <td>
                                <input type="number" id="ticinoweb_partner_count" name="ticinoweb_partner_count" 
                                       value="<?php echo esc_attr(get_option('ticinoweb_partner_count', 6)); ?>" 
                                       min="3" max="24" class="small-text">
                                <p class="description"><?php _e('Inserisci da 3 a 24 loghi partner.', 'ticinoweb-ai-theme'); ?></p>
                            </td>
                        </tr>
                    </table>

                    <div id="partner-items-container">
                        <?php
                        $partner_count = (int) get_option('ticinoweb_partner_count', 6);
                        for ($i = 1; $i <= 24; $i++):
                            $is_visible_partner = $i <= $partner_count ? 'block' : 'none';
                            $logo = get_option("ticinoweb_partner_logo_$i", '');
                            $link = get_option("ticinoweb_partner_link_$i", '');
                            $is_open_partner = false;
                            $body_display_partner = $is_open_partner ? 'block' : 'none';
                            $aria_expanded_partner = $is_open_partner ? 'true' : 'false';
                        ?>
                        <div class="partner-item" data-partner="<?php echo $i; ?>" style="display: <?php echo $is_visible_partner; ?>; background: #fff; border: 1px solid #ccd0d4; border-radius: 4px; padding: 0; margin-bottom: 16px; overflow: hidden;">
                            <div class="partner-item-header" style="display: flex; align-items: center; justify-content: space-between; padding: 12px 14px; cursor: pointer; background: #f6f7f7; border-bottom: 1px solid #e2e4e7;">
                                <div style="display: flex; align-items: center; gap: 8px;">
                                    <span class="dashicons dashicons-admin-links" aria-hidden="true"></span>
                                    <strong><?php printf(__('Partner %d', 'ticinoweb-ai-theme'), $i); ?></strong>
                                </div>
                                <button type="button" class="button-link partner-accordion-toggle" aria-expanded="<?php echo $aria_expanded_partner; ?>" aria-controls="partner-item-body-<?php echo $i; ?>">
                                    <span class="dashicons dashicons-arrow-down"></span>
                                </button>
                            </div>
                            <div class="partner-item-body" id="partner-item-body-<?php echo $i; ?>" style="padding: 14px; display: <?php echo $body_display_partner; ?>;">
                                <table class="form-table">
                                    <tr>
                                        <th scope="row">
                                            <label><?php _e('Logo', 'ticinoweb-ai-theme'); ?></label>
                                        </th>
                                        <td>
                                            <input type="text" name="ticinoweb_partner_logo_<?php echo $i; ?>" 
                                                   value="<?php echo esc_attr($logo); ?>" 
                                                   class="regular-text partner-logo-url">
                                            <button type="button" class="button button-secondary upload-partner-logo"><?php _e('Carica Logo', 'ticinoweb-ai-theme'); ?></button>
                                            <div class="partner-logo-preview" style="margin-top: 8px;">
                                                <?php if (!empty($logo)): ?>
                                                    <img src="<?php echo esc_url($logo); ?>" style="max-width: 200px; height: auto; border: 1px solid #ddd; border-radius: 4px;">
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th scope="row">
                                            <label><?php _e('Link', 'ticinoweb-ai-theme'); ?></label>
                                        </th>
                                        <td>
                                            <input type="url" name="ticinoweb_partner_link_<?php echo $i; ?>" 
                                                   value="<?php echo esc_attr($link); ?>" 
                                                   class="regular-text" placeholder="https://...">
                                        </td>
                                    </tr>
                                </table>
                            </div>
                        </div>
                        <?php endfor; ?>
                    </div>
                </div>
                
                <!-- Chi Siamo Tab -->
                <div id="chi-siamo" class="ticinoweb-tab-content">
                    <h2><?php _e('Configurazione Chi Siamo', 'ticinoweb-ai-theme'); ?></h2>
                    <p class="description"><?php _e('Gestisci i contenuti della pagina Chi Siamo.', 'ticinoweb-ai-theme'); ?></p>
                    
                    <table class="form-table">
                        <tr>
                            <th scope="row">
                                <label for="ticinoweb_chi_siamo_title"><?php _e('Titolo', 'ticinoweb-ai-theme'); ?></label>
                            </th>
                            <td>
                                <input type="text" id="ticinoweb_chi_siamo_title" name="ticinoweb_chi_siamo_title" 
                                       value="<?php echo esc_attr(get_option('ticinoweb_chi_siamo_title')); ?>" 
                                       class="large-text" placeholder="<?php _e('Titolo principale della pagina Chi Siamo', 'ticinoweb-ai-theme'); ?>">
                                <p class="description"><?php _e('Titolo principale della pagina Chi Siamo.', 'ticinoweb-ai-theme'); ?></p>
                                <p class="description"><?php _e('Sezione pubblicata tramite shortcode: <code>[ticinoweb_chi_siamo]</code>.', 'ticinoweb-ai-theme'); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <label for="ticinoweb_chi_siamo_text"><?php _e('Testo', 'ticinoweb-ai-theme'); ?></label>
                            </th>
                            <td>
                                <textarea id="ticinoweb_chi_siamo_text" name="ticinoweb_chi_siamo_text" 
                                          class="large-text" rows="6" placeholder="Descrizione della tua azienda..."><?php echo esc_textarea(get_option('ticinoweb_chi_siamo_text')); ?></textarea>
                                <p class="description"><?php _e('Testo principale della pagina Chi Siamo.', 'ticinoweb-ai-theme'); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <label for="ticinoweb_chi_siamo_image"><?php _e('Immagine', 'ticinoweb-ai-theme'); ?></label>
                            </th>
                            <td>
                                <input type="text" id="ticinoweb_chi_siamo_image" name="ticinoweb_chi_siamo_image" 
                                       value="<?php echo esc_attr(get_option('ticinoweb_chi_siamo_image')); ?>" 
                                       class="regular-text">
                                <button type="button" class="button button-secondary" id="upload-chi-siamo-image"><?php _e('Carica Immagine', 'ticinoweb-ai-theme'); ?></button>
                                <div id="chi-siamo-image-preview" style="margin-top: 10px;">
                                    <?php $chi_siamo_img = get_option('ticinoweb_chi_siamo_image'); if (!empty($chi_siamo_img)): ?>
                                        <img src="<?php echo esc_url($chi_siamo_img); ?>" style="max-width: 300px; height: auto; border: 1px solid #ddd; border-radius: 4px;">
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <label for="ticinoweb_chi_siamo_link"><?php _e('Link', 'ticinoweb-ai-theme'); ?></label>
                            </th>
                            <td>
                                <input type="text" id="ticinoweb_chi_siamo_link" name="ticinoweb_chi_siamo_link" 
                                       value="<?php echo esc_attr(get_option('ticinoweb_chi_siamo_link')); ?>" 
                                       class="regular-text" placeholder="https://... o #ancora">
                                <p class="description"><?php _e('Link per il pulsante di azione (URL o anchor link).', 'ticinoweb-ai-theme'); ?></p>
                            </td>
                        </tr>
                    </table>
                    
                    <script type="text/javascript">
                    jQuery(function($) {
                        $('#upload-chi-siamo-image').on('click', function(e) {
                            e.preventDefault();
                            var image_frame = wp.media({
                                title: '<?php _e('Seleziona Immagine Chi Siamo', 'ticinoweb-ai-theme'); ?>',
                                multiple: false,
                                library: { type: 'image' }
                            });
                            image_frame.on('select', function() {
                                var image_data = image_frame.state().get('selection').first().toJSON();
                                $('#ticinoweb_chi_siamo_image').val(image_data.url);
                                $('#chi-siamo-image-preview').html('<img src="' + image_data.url + '" style="max-width: 300px; height: auto; border: 1px solid #ddd; border-radius: 4px;">');
                            });
                            image_frame.open();
                        });
                    });
                    </script>
                </div>
                
                <!-- Mappatura Tab (Admin only) -->
                <?php if ($ticinoweb_is_admin): ?>
                <!-- Recensioni Tab -->
                <?php if (!get_option('ticinoweb_disable_reviews')): ?>
                <div id="recensioni" class="ticinoweb-tab-content">
                    <h2><?php _e('Google Reviews Integration', 'ticinoweb-ai-theme'); ?></h2>
                    
                    <div class="notice notice-info inline" style="margin: 20px 0; padding: 15px; border-left-color: #4285F4;">
                        <h3 style="margin-top: 0; color: #4285F4;"><?php _e('Come ottenere le chiavi?', 'ticinoweb-ai-theme'); ?></h3>
                        <ol>
                            <li><strong>Google API Key:</strong> Vai su <a href="https://console.cloud.google.com/" target="_blank">Google Cloud Console</a>, crea un progetto e abilita la <strong>"Places API"</strong>. Crea quindi una chiave API nelle "Credenziali".</li>
                            <li><strong>Place ID:</strong> Usa il <a href="https://developers.google.com/maps/documentation/javascript/examples/places-placeid-finder" target="_blank">Place ID Finder di Google</a> per trovare l'ID della tua attività cercandola sulla mappa.</li>
                            <li><strong>GMB Link:</strong> Questo è il link diretto alla scheda della tua attività (es. <code>https://g.page/r/CODICE/review</code>) usato per il pulsante "Lascia una recensione".</li>
                        </ol>
                    </div>

                    <table class="form-table">
                        <tr>
                            <th scope="row"><label for="ticinoweb_google_api_key"><?php _e('Google Places API Key', 'ticinoweb-ai-theme'); ?></label></th>
                            <td>
                                <input type="password" id="ticinoweb_google_api_key" name="ticinoweb_google_api_key" 
                                       value="<?php echo esc_attr(get_option('ticinoweb_google_api_key')); ?>" class="regular-text">
                                <p class="description"><?php _e('Necessaria per estrarre le recensioni dal tuo profilo Google Business.', 'ticinoweb-ai-theme'); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="ticinoweb_google_place_id"><?php _e('Place ID', 'ticinoweb-ai-theme'); ?></label></th>
                            <td>
                                <input type="text" id="ticinoweb_google_place_id" name="ticinoweb_google_place_id" 
                                       value="<?php echo esc_attr(get_option('ticinoweb_google_place_id')); ?>" class="regular-text">
                                <p class="description"><?php _e('Inserisci il Place ID della tua attività.', 'ticinoweb-ai-theme'); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="ticinoweb_google_business_link"><?php _e('Link Google My Business', 'ticinoweb-ai-theme'); ?></label></th>
                            <td>
                                <input type="url" id="ticinoweb_google_business_link" name="ticinoweb_google_business_link" 
                                       value="<?php echo esc_attr(get_option('ticinoweb_google_business_link')); ?>" class="regular-text" placeholder="https://g.page/r/...">
                                <p class="description"><?php _e('Il link diretto alla tua scheda per permettere ai clienti di scriverti una recensione.', 'ticinoweb-ai-theme'); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="ticinoweb_google_reviews_language"><?php _e('Lingua Recensioni', 'ticinoweb-ai-theme'); ?></label></th>
                            <td>
                                <?php
                                $tw_rev_lang = (string) get_option('ticinoweb_google_reviews_language', '');
                                $tw_rev_langs = array(
                                    'it' => __('Italiano', 'ticinoweb-ai-theme'),
                                    'en' => __('Inglese', 'ticinoweb-ai-theme'),
                                    'de' => __('Tedesco', 'ticinoweb-ai-theme'),
                                    'fr' => __('Francese', 'ticinoweb-ai-theme'),
                                    'es' => __('Spagnolo', 'ticinoweb-ai-theme'),
                                );
                                ?>
                                <select id="ticinoweb_google_reviews_language" name="ticinoweb_google_reviews_language">
                                    <option value="" <?php selected($tw_rev_lang, ''); ?>>
                                        <?php printf(__('Automatico — lingua del sito (%s)', 'ticinoweb-ai-theme'), esc_html(ticinoweb_google_places_language())); ?>
                                    </option>
                                    <?php foreach ($tw_rev_langs as $tw_code => $tw_label) : ?>
                                        <option value="<?php echo esc_attr($tw_code); ?>" <?php selected($tw_rev_lang, $tw_code); ?>><?php echo esc_html($tw_label); ?></option>
                                    <?php endforeach; ?>
                                </select>
                                <p class="description"><?php _e('Lingua in cui Google restituisce il testo delle recensioni e gli orari di apertura. Le recensioni già salvate non cambiano: premi "Sincronizza Recensioni Ora" dopo aver modificato questa impostazione.', 'ticinoweb-ai-theme'); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="ticinoweb_google_reviews_min_rating"><?php _e('Filtro Valutazione Minima', 'ticinoweb-ai-theme'); ?></label></th>
                            <td>
                                <select id="ticinoweb_google_reviews_min_rating" name="ticinoweb_google_reviews_min_rating">
                                    <option value="0" <?php selected(get_option('ticinoweb_google_reviews_min_rating'), 0); ?>><?php _e('Mostra tutte', 'ticinoweb-ai-theme'); ?></option>
                                    <option value="4" <?php selected(get_option('ticinoweb_google_reviews_min_rating', 4), 4); ?>><?php _e('Solo 4 e 5 stelle', 'ticinoweb-ai-theme'); ?></option>
                                    <option value="5" <?php selected(get_option('ticinoweb_google_reviews_min_rating'), 5); ?>><?php _e('Solo 5 stelle', 'ticinoweb-ai-theme'); ?></option>
                                </select>
                                <p class="description"><?php _e('Filtra le recensioni mostrate sul sito in base al punteggio.', 'ticinoweb-ai-theme'); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><?php _e('Sincronizzazione Dati', 'ticinoweb-ai-theme'); ?></th>
                            <td>
                                <button type="button" id="ticinoweb_sync_reviews" class="button button-secondary">
                                    <span class="dashicons dashicons-update" style="margin-top: 4px;"></span> <?php _e('Sincronizza Recensioni Ora', 'ticinoweb-ai-theme'); ?>
                                </button>
                                <span id="sync-status-spinner" class="spinner" style="float: none; margin: 0 10px;"></span>
                                <p class="description">
                                    <?php _e('Ultima sincronizzazione:', 'ticinoweb-ai-theme'); ?> 
                                    <strong id="last-sync-date"><?php echo get_option('ticinoweb_google_reviews_last_sync') ?: __('Mai', 'ticinoweb-ai-theme'); ?></strong>
                                </p>
                                <div id="sync-message" style="margin-top: 10px; display: none;"></div>
                            </td>
                        </tr>
                    </table>

                    <input type="hidden" id="ticinoweb_reviews_nonce" value="<?php echo wp_create_nonce('ticinoweb_reviews_nonce'); ?>">
                    
                    <script type="text/javascript">
                    jQuery(document).ready(function($) {
                        $('#ticinoweb_sync_reviews').on('click', function(e) {
                            e.preventDefault();
                            var btn = $(this);
                            var spinner = $('#sync-status-spinner');
                            var msg = $('#sync-message');
                            
                            btn.prop('disabled', true);
                            spinner.addClass('is-active');
                            msg.hide().removeClass('notice notice-success notice-error');
                            
                            $.post(ajaxurl, {
                                action: 'ticinoweb_sync_google_reviews',
                                nonce: $('#ticinoweb_reviews_nonce').val()
                            }, function(response) {
                                btn.prop('disabled', false);
                                spinner.removeClass('is-active');
                                
                                if (response.success) {
                                    msg.addClass('notice notice-success inline').html('<p>' + response.data.message + '</p>').fadeIn();
                                    $('#last-sync-date').text(response.data.last_sync);
                                } else {
                                    msg.addClass('notice notice-error inline').html('<p>' + response.data.message + '</p>').fadeIn();
                                }
                            });
                        });
                    });
                    </script>

                    <div style="margin-top: 30px; padding: 20px; background: #fff; border: 1px solid #ccd0d4; border-radius: 4px; border-left: 4px solid #4a148c;">
                        <h3 style="margin-top: 0; color: #4a148c;"><span class="dashicons dashicons-code-standards" style="margin-top: 4px;"></span> <?php _e('Guida Integrazione AI', 'ticinoweb-ai-theme'); ?></h3>
                        <p><?php _e('Per integrare le recensioni nel tuo child theme tramite AI, puoi usare queste informazioni:', 'ticinoweb-ai-theme'); ?></p>
                        <table class="wp-list-table widefat fixed striped" style="margin-top: 10px;">
                            <thead>
                                <tr>
                                    <th><?php _e('Metodo', 'ticinoweb-ai-theme'); ?></th>
                                    <th><?php _e('Uso / Codice', 'ticinoweb-ai-theme'); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td><strong>Shortcode</strong></td>
                                    <td><code>[ticinoweb_google_reviews limit="5" min_rating="4" layout="grid"]</code></td>
                                </tr>
                                <tr>
                                    <td><strong>PHP Helper</strong></td>
                                    <td><code>ticinoweb_get_google_reviews($limit, $min_rating);</code></td>
                                </tr>
                                <tr>
                                    <td><strong>Rating Totale</strong></td>
                                    <td><code>get_option('ticinoweb_google_reviews_rating');</code></td>
                                </tr>
                            </tbody>
                        </table>
                        <p style="margin-top: 15px;">
                            <a href="#ai-instructions" class="button button-secondary" onclick="jQuery('a[href=\'#ai-instructions\']').click();">
                                <?php _e('Vai al Prompt Iniziale in "Settings"', 'ticinoweb-ai-theme'); ?>
                            </a>
                        </p>
                    </div>
                </div>
                <?php endif; ?>

                <?php if (!get_option('ticinoweb_disable_page_mapping')): ?>
                <div id="mappatura" class="ticinoweb-tab-content">
                    <h2><?php _e('Mappatura Pagine e Archivi', 'ticinoweb-ai-theme'); ?></h2>
                    <p class="description"><?php _e('Seleziona le pagine dove devono apparire determinati elementi. Queste impostazioni vengono utilizzate dai template per mostrare i contenuti corretti.', 'ticinoweb-ai-theme'); ?></p>
                    
                    <table class="form-table">
                        <tr>
                            <th scope="row">
                                <label for="ticinoweb_page_mapping[page_contatti]"><?php _e('Pagina Contatti', 'ticinoweb-ai-theme'); ?></label>
                            </th>
                            <td>
                                <select id="ticinoweb_page_mapping_contatti" name="ticinoweb_page_mapping[page_contatti]">
                                    <option value=""><?php _e('-- Nessuna --', 'ticinoweb-ai-theme'); ?></option>
                                    <?php
                                    $pages = get_pages(array('post_status' => 'publish'));
                                    $mapping = get_option('ticinoweb_page_mapping', []);
                                    $selected_page = $mapping['page_contatti'] ?? 0;
                                    foreach ($pages as $page):
                                        $selected = selected($selected_page, $page->ID, false);
                                    ?>
                                        <option value="<?php echo $page->ID; ?>" <?php echo $selected; ?>><?php echo esc_html($page->post_title); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <label for="ticinoweb_page_mapping[page_slider]"><?php _e('Pagina con Slider', 'ticinoweb-ai-theme'); ?></label>
                            </th>
                            <td>
                                <select id="ticinoweb_page_mapping_slider" name="ticinoweb_page_mapping[page_slider]">
                                    <option value=""><?php _e('-- Nessuna --', 'ticinoweb-ai-theme'); ?></option>
                                    <?php
                                    $selected_slider = $mapping['page_slider'] ?? 0;
                                    foreach ($pages as $page):
                                        $selected = selected($selected_slider, $page->ID, false);
                                    ?>
                                        <option value="<?php echo $page->ID; ?>" <?php echo $selected; ?>><?php echo esc_html($page->post_title); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <label for="ticinoweb_page_mapping[page_servizi]"><?php _e('Archivio Servizi', 'ticinoweb-ai-theme'); ?></label>
                            </th>
                            <td>
                                <select id="ticinoweb_page_mapping_servizi" name="ticinoweb_page_mapping[page_servizi]">
                                    <option value=""><?php _e('-- Nessuna --', 'ticinoweb-ai-theme'); ?></option>
                                    <?php
                                    $selected_servizi = $mapping['page_servizi'] ?? 0;
                                    foreach ($pages as $page):
                                        $selected = selected($selected_servizi, $page->ID, false);
                                    ?>
                                        <option value="<?php echo $page->ID; ?>" <?php echo $selected; ?>><?php echo esc_html($page->post_title); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <label for="ticinoweb_page_mapping[page_chi_siamo]"><?php _e('Pagina Chi Siamo', 'ticinoweb-ai-theme'); ?></label>
                            </th>
                            <td>
                                <select id="ticinoweb_page_mapping_chi_siamo" name="ticinoweb_page_mapping[page_chi_siamo]">
                                    <option value=""><?php _e('-- Nessuna --', 'ticinoweb-ai-theme'); ?></option>
                                    <?php
                                    $selected_chi_siamo = $mapping['page_chi_siamo'] ?? 0;
                                    foreach ($pages as $page):
                                        $selected = selected($selected_chi_siamo, $page->ID, false);
                                    ?>
                                        <option value="<?php echo $page->ID; ?>" <?php echo $selected; ?>><?php echo esc_html($page->post_title); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                        </tr>
                        
                        <?php
                        // Aggiungi mappatura per ogni Custom Post Type
                        $cpts = get_option('ticinoweb_custom_post_types', []);
                        if (!empty($cpts)):
                            foreach ($cpts as $cpt):
                                $cpt_slug = $cpt['slug'];
                                $cpt_plural = $cpt['plural'];
                                $mapping_key = "archive_" . $cpt_slug;
                                $selected_cpt = $mapping[$mapping_key] ?? 0;
                        ?>
                        <tr>
                            <th scope="row">
                                <label for="ticinoweb_page_mapping[<?php echo $mapping_key; ?>]"><?php printf(__('Archivio %s', 'ticinoweb-ai-theme'), esc_html($cpt_plural)); ?></label>
                            </th>
                            <td>
                                <select name="ticinoweb_page_mapping[<?php echo $mapping_key; ?>]">
                                    <option value=""><?php _e('-- Nessuna --', 'ticinoweb-ai-theme'); ?></option>
                                    <?php
                                    foreach ($pages as $page):
                                        $selected = selected($selected_cpt, $page->ID, false);
                                    ?>
                                        <option value="<?php echo $page->ID; ?>" <?php echo $selected; ?>><?php echo esc_html($page->post_title); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                        </tr>
                        <?php
                            endforeach;
                        endif;
                        ?>
                    </table>
                </div>
                <?php endif; ?>
                <?php endif; ?>
                
                <!-- reCAPTCHA Tab (Admin only) -->
                <?php if ($ticinoweb_is_admin): ?>
                <div id="recaptcha" class="ticinoweb-tab-content" style="position: relative;">
                    <div style="position: absolute; top: 0; right: 0;">
                        <img src="<?php echo get_template_directory_uri(); ?>/assets/images/google-recaptcha-logo.png.webp" alt="Google reCAPTCHA" style="height: 60px; width: auto; opacity: 0.9;">
                    </div>
                    <h2><?php _e('Configurazione Google reCAPTCHA v3', 'ticinoweb-ai-theme'); ?></h2>
                    <p class="description"><?php _e('Proteggi i form del sito da spam e bot. Ottieni le chiavi da:', 'ticinoweb-ai-theme'); ?> <a href="https://www.google.com/recaptcha/admin" target="_blank">Google reCAPTCHA Admin</a></p>
                    
                    <table class="form-table">
                        <tr>
                            <th scope="row">
                                <label for="ticinoweb_recaptcha_site_key"><?php _e('Site Key (Chiave Pubblica)', 'ticinoweb-ai-theme'); ?></label>
                            </th>
                            <td>
                                <input type="text" id="ticinoweb_recaptcha_site_key" name="ticinoweb_recaptcha_site_key" 
                                       value="<?php echo esc_attr(get_option('ticinoweb_recaptcha_site_key')); ?>" 
                                       class="regular-text" placeholder="6Lc...">
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <label for="ticinoweb_recaptcha_secret_key"><?php _e('Secret Key (Chiave Segreta)', 'ticinoweb-ai-theme'); ?></label>
                            </th>
                            <td>
                                <input type="text" id="ticinoweb_recaptcha_secret_key" name="ticinoweb_recaptcha_secret_key" 
                                       value="<?php echo esc_attr(get_option('ticinoweb_recaptcha_secret_key')); ?>" 
                                       class="regular-text" placeholder="6Lc...">
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <label for="ticinoweb_recaptcha_threshold"><?php _e('Soglia Score (0.0 - 1.0)', 'ticinoweb-ai-theme'); ?></label>
                            </th>
                            <td>
                                <input type="number" id="ticinoweb_recaptcha_threshold" name="ticinoweb_recaptcha_threshold" 
                                       value="<?php echo esc_attr(get_option('ticinoweb_recaptcha_threshold', '0.5')); ?>" 
                                       step="0.1" min="0" max="1" class="small-text">
                                <p class="description"><?php _e('Soglia minima per accettare il form (consigliato: 0.5). Punteggi più alti = più restrittivo.', 'ticinoweb-ai-theme'); ?></p>
                            </td>
                        </tr>
                    </table>
                </div>
                <?php endif; ?>
                
                <!-- SMTP Tab (Admin only) -->
                <?php if ($ticinoweb_is_admin): ?>
                <div id="smtp" class="ticinoweb-tab-content" style="position: relative;">
                    <h2><?php _e('Configurazione Email (SMTP / SendGrid)', 'ticinoweb-ai-theme'); ?></h2>
                    
                    <table class="form-table">
                        <tr>
                            <th scope="row">
                                <label for="ticinoweb_email_method"><?php _e('Metodo di Invio', 'ticinoweb-ai-theme'); ?></label>
                            </th>
                            <td>
                                <select id="ticinoweb_email_method" name="ticinoweb_email_method">
                                    <option value="default" <?php selected(get_option('ticinoweb_email_method'), 'default'); ?>><?php _e('WordPress Default (mail)', 'ticinoweb-ai-theme'); ?></option>
                                    <option value="smtp" <?php selected(get_option('ticinoweb_email_method'), 'smtp'); ?>><?php _e('SMTP Standard', 'ticinoweb-ai-theme'); ?></option>
                                    <option value="sendgrid" <?php selected(get_option('ticinoweb_email_method'), 'sendgrid'); ?>><?php _e('SendGrid API', 'ticinoweb-ai-theme'); ?></option>
                                </select>
                            </td>
                        </tr>
                    </table>
                    
                    <!-- SMTP Standard Settings -->
                    <div id="smtp-standard-settings" style="display: <?php echo get_option('ticinoweb_email_method') === 'smtp' ? 'block' : 'none'; ?>;">
                        <h3><?php _e('Configurazione SMTP Standard', 'ticinoweb-ai-theme'); ?></h3>
                        <table class="form-table">
                            <tr>
                                <th scope="row">
                                    <label for="ticinoweb_smtp_host"><?php _e('Host SMTP', 'ticinoweb-ai-theme'); ?></label>
                                </th>
                                <td>
                                    <input type="text" id="ticinoweb_smtp_host" name="ticinoweb_smtp_host" 
                                           value="<?php echo esc_attr(get_option('ticinoweb_smtp_host')); ?>" 
                                           class="regular-text" placeholder="smtp.gmail.com">
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">
                                    <label for="ticinoweb_smtp_port"><?php _e('Porta SMTP', 'ticinoweb-ai-theme'); ?></label>
                                </th>
                                <td>
                                    <input type="number" id="ticinoweb_smtp_port" name="ticinoweb_smtp_port" 
                                           value="<?php echo esc_attr(get_option('ticinoweb_smtp_port', '587')); ?>" 
                                           class="small-text">
                                    <p class="description"><?php _e('Comune: 587 (TLS), 465 (SSL), 25 (non sicuro)', 'ticinoweb-ai-theme'); ?></p>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">
                                    <label for="ticinoweb_smtp_encryption"><?php _e('Crittografia', 'ticinoweb-ai-theme'); ?></label>
                                </th>
                                <td>
                                    <select id="ticinoweb_smtp_encryption" name="ticinoweb_smtp_encryption">
                                        <option value="tls" <?php selected(get_option('ticinoweb_smtp_encryption', 'tls'), 'tls'); ?>>TLS (STARTTLS) — porta 587</option>
                                        <option value="ssl" <?php selected(get_option('ticinoweb_smtp_encryption'), 'ssl'); ?>>SSL — porta 465</option>
                                        <option value="" <?php selected(get_option('ticinoweb_smtp_encryption'), ''); ?>><?php _e('Nessuna — porta 25', 'ticinoweb-ai-theme'); ?></option>
                                    </select>
                                    <div id="smtp-port-mismatch-warn" style="display:none;margin-top:6px;padding:8px 12px;background:#fef9c3;border:1px solid #fbbf24;border-radius:5px;font-size:12px;color:#92400e;">
                                        ⚠️ <strong><?php _e('Porta/crittografia non coincidono:', 'ticinoweb-ai-theme'); ?></strong>
                                        <span id="smtp-port-mismatch-msg"></span>
                                        <button type="button" id="smtp-fix-port" class="button" style="margin-left:8px;padding:2px 10px;font-size:11px;height:auto;line-height:1.6;"><?php _e('Correggi automaticamente', 'ticinoweb-ai-theme'); ?></button>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">
                                    <label for="ticinoweb_smtp_username"><?php _e('Username SMTP', 'ticinoweb-ai-theme'); ?></label>
                                </th>
                                <td>
                                    <input type="text" id="ticinoweb_smtp_username" name="ticinoweb_smtp_username" 
                                           value="<?php echo esc_attr(get_option('ticinoweb_smtp_username')); ?>" 
                                           class="regular-text" autocomplete="off">
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">
                                    <label for="ticinoweb_smtp_password"><?php _e('Password SMTP', 'ticinoweb-ai-theme'); ?></label>
                                </th>
                                <td>
                                    <input type="password" id="ticinoweb_smtp_password" name="ticinoweb_smtp_password" 
                                           value="<?php echo esc_attr(get_option('ticinoweb_smtp_password')); ?>" 
                                           class="regular-text" autocomplete="new-password">
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">
                                    <label for="ticinoweb_smtp_from_email"><?php _e('Email Mittente', 'ticinoweb-ai-theme'); ?></label>
                                </th>
                                <td>
                                    <input type="email" id="ticinoweb_smtp_from_email" name="ticinoweb_smtp_from_email" 
                                           value="<?php echo esc_attr(get_option('ticinoweb_smtp_from_email')); ?>" 
                                           class="regular-text" placeholder="noreply@tuosito.com">
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">
                                    <label for="ticinoweb_smtp_from_name"><?php _e('Nome Mittente', 'ticinoweb-ai-theme'); ?></label>
                                </th>
                                <td>
                                    <input type="text" id="ticinoweb_smtp_from_name" name="ticinoweb_smtp_from_name" 
                                           value="<?php echo esc_attr(get_option('ticinoweb_smtp_from_name')); ?>" 
                                           class="regular-text" placeholder="<?php bloginfo('name'); ?>">
                                </td>
                            </tr>
                        </table>
                    </div>
                    
                    <!-- SendGrid Settings -->
                    <div id="sendgrid-settings" style="display: <?php echo get_option('ticinoweb_email_method') === 'sendgrid' ? 'block' : 'none'; ?>;">
                        <!-- SendGrid Logo -->
                        <div style="position: absolute; top: 0; right: 0;">
                            <img src="<?php echo get_template_directory_uri(); ?>/assets/images/SendGrid_2016_Logo.png" alt="SendGrid" style="height: 40px; width: auto; opacity: 0.9;">
                        </div>
                        <h3><?php _e('Configurazione SendGrid', 'ticinoweb-ai-theme'); ?></h3>
                        <p class="description"><?php _e('Ottieni la tua API Key da:', 'ticinoweb-ai-theme'); ?> <a href="https://app.sendgrid.com/settings/api_keys" target="_blank">SendGrid Dashboard</a></p>
                        
                        <table class="form-table">
                            <tr>
                                <th scope="row">
                                    <label for="ticinoweb_sendgrid_api_key"><?php _e('SendGrid API Key', 'ticinoweb-ai-theme'); ?></label>
                                </th>
                                <td>
                                    <input type="password" id="ticinoweb_sendgrid_api_key" name="ticinoweb_sendgrid_api_key" 
                                           value="" 
                                           class="regular-text" placeholder="SG.xxxxx" autocomplete="new-password">
                                    <?php if (get_option('ticinoweb_sendgrid_api_key')): ?>
                                        <p class="description" style="margin-top:6px; color:#2271b1;">
                                            <?php _e('Chiave già salvata. Lascia vuoto per mantenerla.', 'ticinoweb-ai-theme'); ?>
                                        </p>
                                    <?php else: ?>
                                        <p class="description" style="margin-top:6px;">
                                            <?php _e('Inserisci la chiave completa (non verrà mostrata dopo il salvataggio).', 'ticinoweb-ai-theme'); ?>
                                        </p>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">
                                    <label for="ticinoweb_sendgrid_from_email"><?php _e('Email Mittente', 'ticinoweb-ai-theme'); ?></label>
                                </th>
                                <td>
                                    <input type="email" id="ticinoweb_sendgrid_from_email" name="ticinoweb_sendgrid_from_email" 
                                           value="<?php echo esc_attr(get_option('ticinoweb_sendgrid_from_email')); ?>" 
                                           class="regular-text" placeholder="noreply@tuosito.com">
                                    <p class="description"><?php _e('Deve essere verificata in SendGrid (Sender Authentication)', 'ticinoweb-ai-theme'); ?></p>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">
                                    <label for="ticinoweb_sendgrid_from_name"><?php _e('Nome Mittente', 'ticinoweb-ai-theme'); ?></label>
                                </th>
                                <td>
                                    <input type="text" id="ticinoweb_sendgrid_from_name" name="ticinoweb_sendgrid_from_name" 
                                           value="<?php echo esc_attr(get_option('ticinoweb_sendgrid_from_name')); ?>" 
                                           class="regular-text" placeholder="<?php bloginfo('name'); ?>">
                                </td>
                            </tr>
                        </table>
                    </div>
                    
                    <!-- Test Email Section -->
                    <hr>
                    <h3><?php _e('Test Invio Email', 'ticinoweb-ai-theme'); ?></h3>
                    <table class="form-table">
                        <tr>
                            <th scope="row">
                                <label for="test_email_address"><?php _e('Invia Email di Test a:', 'ticinoweb-ai-theme'); ?></label>
                            </th>
                            <td>
                                <input type="email" id="test_email_address" class="regular-text" placeholder="test@example.com">
                                <button type="button" id="send-test-email" class="button button-secondary"><?php _e('Invia Test', 'ticinoweb-ai-theme'); ?></button>
                                <?php if ( get_option('ticinoweb_email_method') === 'sendgrid' ) : ?>
                                <button type="button" id="check-sendgrid-api" class="button button-secondary" style="margin-left:6px;"><?php _e('Verifica API SendGrid', 'ticinoweb-ai-theme'); ?></button>
                                <?php endif; ?>
                                <div id="test-email-result" style="margin-top: 10px;"></div>
                            </td>
                        </tr>
                    </table>
                </div>
                <?php endif; ?>
            </div>
            
            <!-- Custom Fields Tab (Admin only) -->
            <?php if ($ticinoweb_is_admin): ?>
            <?php if (!get_option('ticinoweb_disable_cpts')): ?>
            <div id="custom-fields" class="ticinoweb-tab-content">
                <h2><?php _e('Personalizzazione Post Type Default (Articoli)', 'ticinoweb-ai-theme'); ?></h2>
                <p class="description"><?php _e('Rinomina il menu "Articoli" di WordPress con etichette personalizzate (es. "Referenze", "Progetti", "Portfolio").', 'ticinoweb-ai-theme'); ?></p>
                
                <table class="form-table">
                    <tr>
                        <th scope="row">
                            <label for="ticinoweb_post_name_singular"><?php _e('Nome Singolare', 'ticinoweb-ai-theme'); ?></label>
                        </th>
                        <td>
                            <input type="text" id="ticinoweb_post_name_singular" name="ticinoweb_post_name_singular" 
                                   value="<?php echo esc_attr(get_option('ticinoweb_post_name_singular', 'Articolo')); ?>" 
                                   class="regular-text" placeholder="Referenza">
                            <p class="description"><?php _e('Esempio: "Referenza", "Progetto", "Portfolio"', 'ticinoweb-ai-theme'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="ticinoweb_post_name_plural"><?php _e('Nome Plurale', 'ticinoweb-ai-theme'); ?></label>
                        </th>
                        <td>
                            <input type="text" id="ticinoweb_post_name_plural" name="ticinoweb_post_name_plural" 
                                   value="<?php echo esc_attr(get_option('ticinoweb_post_name_plural', 'Articoli')); ?>" 
                                   class="regular-text" placeholder="Referenze">
                            <p class="description"><?php _e('Esempio: "Referenze", "Progetti", "Portfolio"', 'ticinoweb-ai-theme'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="ticinoweb_post_gender"><?php _e('Genere', 'ticinoweb-ai-theme'); ?></label>
                        </th>
                        <td>
                            <select id="ticinoweb_post_gender" name="ticinoweb_post_gender">
                                <option value="maschile" <?php selected(get_option('ticinoweb_post_gender', 'maschile'), 'maschile'); ?>><?php _e('Maschile (il, un, tutti)', 'ticinoweb-ai-theme'); ?></option>
                                <option value="femminile" <?php selected(get_option('ticinoweb_post_gender'), 'femminile'); ?>><?php _e('Femminile (la, una, tutte)', 'ticinoweb-ai-theme'); ?></option>
                            </select>
                            <p class="description"><?php _e('Determina articoli e pronomi usati nelle etichette (es. "Aggiungi un..." vs "Aggiungi una...")', 'ticinoweb-ai-theme'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="ticinoweb_post_icon"><?php _e('Icona Menu (Dashicon)', 'ticinoweb-ai-theme'); ?></label>
                        </th>
                        <td>
                            <input type="text" id="ticinoweb_post_icon" name="ticinoweb_post_icon" 
                                   value="<?php echo esc_attr(get_option('ticinoweb_post_icon', 'dashicons-admin-post')); ?>" 
                                   class="regular-text" placeholder="dashicons-portfolio">
                            <p class="description">
                                <?php _e('Classe Dashicon (es. "dashicons-portfolio", "dashicons-awards", "dashicons-images-alt2").', 'ticinoweb-ai-theme'); ?><br>
                                <a href="https://developer.wordpress.org/resource/dashicons/" target="_blank"><?php _e('Vedi tutte le icone disponibili', 'ticinoweb-ai-theme'); ?></a>
                            </p>
                            <div id="icon-preview" style="margin-top: 10px;">
                                <span class="dashicons <?php echo esc_attr(get_option('ticinoweb_post_icon', 'dashicons-admin-post')); ?>" style="font-size: 32px; width: 32px; height: 32px;"></span>
                                <span style="margin-left: 10px; vertical-align: super;"><?php _e('Anteprima icona', 'ticinoweb-ai-theme'); ?></span>
                            </div>
                        </td>
                    </tr>
                </table>

                <hr style="margin: 30px 0;">

                <h2><?php _e('Crea Custom Post Types (Beta)', 'ticinoweb-ai-theme'); ?></h2>
                <div id="cpt-container">
                    <?php
                    $cpts = get_option('ticinoweb_custom_post_types', []);
                    // Ensure at least empty array if not set
                    if (!is_array($cpts)) $cpts = [];
                    
                    foreach ($cpts as $index => $cpt):
                    ?>
                    <div class="cpt-item" data-index="<?php echo $index; ?>" style="background: #fff; border: 1px solid #ccd0d4; border-radius: 4px; padding: 20px; margin-bottom: 20px; position: relative;">
                        <button type="button" class="button button-link-delete remove-cpt" style="position: absolute; top: 10px; right: 10px; color: #b32d2e; text-decoration: none;">
                            <span class="dashicons dashicons-trash"></span> <?php _e('Rimuovi', 'ticinoweb-ai-theme'); ?>
                        </button>
                        
                        <h3 style="margin-top: 0;"><?php _e('Nuovo Post Type', 'ticinoweb-ai-theme'); ?> #<?php echo $index + 1; ?></h3>
                        
                        <table class="form-table">
                            <tr>
                                <th scope="row"><label><?php _e('Slug (Chiave Univoca)', 'ticinoweb-ai-theme'); ?></label></th>
                                <td>
                                    <input type="text" name="ticinoweb_custom_post_types[<?php echo $index; ?>][slug]" 
                                           value="<?php echo esc_attr($cpt['slug'] ?? ''); ?>" 
                                           class="regular-text" placeholder="es. servizi">
                                    <p class="description"><?php _e('Minuscolo, niente spazi (usa trattini). Esempio: "servizi", "membri-team"', 'ticinoweb-ai-theme'); ?></p>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row"><label><?php _e('Nome Singolare', 'ticinoweb-ai-theme'); ?></label></th>
                                <td>
                                    <input type="text" name="ticinoweb_custom_post_types[<?php echo $index; ?>][singular]" 
                                           value="<?php echo esc_attr($cpt['singular'] ?? ''); ?>" 
                                           class="regular-text" placeholder="Servizio">
                                </td>
                            </tr>
                            <tr>
                                <th scope="row"><label><?php _e('Nome Plurale', 'ticinoweb-ai-theme'); ?></label></th>
                                <td>
                                    <input type="text" name="ticinoweb_custom_post_types[<?php echo $index; ?>][plural]" 
                                           value="<?php echo esc_attr($cpt['plural'] ?? ''); ?>" 
                                           class="regular-text" placeholder="Servizi">
                                </td>
                            </tr>
                            <tr>
                                <th scope="row"><label><?php _e('Tipo Icona', 'ticinoweb-ai-theme'); ?></label></th>
                                <td>
                                    <?php $icon_type = $cpt['icon_type'] ?? 'dashicon'; ?>
                                    <label style="margin-right: 15px;">
                                        <input type="radio" name="ticinoweb_custom_post_types[<?php echo $index; ?>][icon_type]" value="dashicon" class="cpt-icon-type-selector" <?php checked($icon_type, 'dashicon'); ?>> 
                                        Dashicon
                                    </label>
                                    <label>
                                        <input type="radio" name="ticinoweb_custom_post_types[<?php echo $index; ?>][icon_type]" value="svg" class="cpt-icon-type-selector" <?php checked($icon_type, 'svg'); ?>> 
                                        SVG Custom
                                    </label>
                                </td>
                            </tr>
                            <tr class="cpt-dashicon-row" style="<?php echo $icon_type === 'dashicon' ? '' : 'display:none;'; ?>">
                                <th scope="row"><label><?php _e('Icona (Dashicon)', 'ticinoweb-ai-theme'); ?></label></th>
                                <td>
                                    <input type="text" name="ticinoweb_custom_post_types[<?php echo $index; ?>][icon]" 
                                           value="<?php echo esc_attr($cpt['icon'] ?? 'dashicons-admin-post'); ?>" 
                                           class="regular-text cpt-icon-input" placeholder="dashicons-admin-post">
                                    <span class="dashicons <?php echo esc_attr($cpt['icon'] ?? 'dashicons-admin-post'); ?> cpt-icon-preview" style="font-size: 20px; margin-left:10px; vertical-align:middle;"></span>
                                    <p class="description"><a href="https://developer.wordpress.org/resource/dashicons/" target="_blank">Lista Dashicons</a></p>
                                </td>
                            </tr>
                            <tr class="cpt-svg-row" style="<?php echo $icon_type === 'svg' ? '' : 'display:none;'; ?>">
                                <th scope="row"><label><?php _e('Icona SVG URL', 'ticinoweb-ai-theme'); ?></label></th>
                                <td>
                                    <input type="text" name="ticinoweb_custom_post_types[<?php echo $index; ?>][icon_svg]" 
                                           value="<?php echo esc_attr($cpt['icon_svg'] ?? ''); ?>" 
                                           class="regular-text cpt-svg-input" placeholder="https://...">
                                    <button type="button" class="button button-secondary upload-cpt-svg"><?php _e('Carica SVG', 'ticinoweb-ai-theme'); ?></button>
                                    <div class="cpt-svg-preview" style="margin-top: 10px; width: 32px; height: 32px; border: 1px dashed #ccc; display: flex; align-items: center; justify-content: center;">
                                        <?php if (!empty($cpt['icon_svg'])): ?>
                                            <img src="<?php echo esc_url($cpt['icon_svg']); ?>" style="max-width: 100%; max-height: 100%;">
                                        <?php endif; ?>
                                    </div>
                                    <p class="description"><?php _e('Puoi copiare un URL dalla tab "Libreria Icone SVG".', 'ticinoweb-ai-theme'); ?></p>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row"><label><?php _e('Opzioni', 'ticinoweb-ai-theme'); ?></label></th>
                                <td>
                                    <label style="margin-right: 15px;">
                                        <input type="checkbox" name="ticinoweb_custom_post_types[<?php echo $index; ?>][public]" value="1" <?php checked(isset($cpt['public']) ? $cpt['public'] : 0, 1); ?>> 
                                        <?php _e('Pubblico (visibile sul sito)', 'ticinoweb-ai-theme'); ?>
                                    </label>
                                    <label>
                                        <input type="checkbox" name="ticinoweb_custom_post_types[<?php echo $index; ?>][has_archive]" value="1" <?php checked(isset($cpt['has_archive']) ? $cpt['has_archive'] : 0, 1); ?>> 
                                        <?php _e('Abilita Archivio', 'ticinoweb-ai-theme'); ?>
                                    </label>
                                </td>
                            </tr>
                        </table>
                    </div>
                    <?php endforeach; ?>
                </div>
                
                <button type="button" class="button button-primary" id="add-cpt-btn" style="margin-bottom: 20px;"><?php _e('Aggiungi Custom Post Type', 'ticinoweb-ai-theme'); ?></button>
                
                <div class="notice notice-warning inline" style="margin: 20px 0;">
                    <p><strong><?php _e('Nota:', 'ticinoweb-ai-theme'); ?></strong> <?php _e('Dopo aver salvato, ricarica la pagina admin per vedere le modifiche applicate al menu.', 'ticinoweb-ai-theme'); ?></p>
                </div>
            </div>
            <?php endif; ?>
            <?php endif; ?>
            
            <!-- Look & Feel Tab -->
            <div id="theme-images" class="ticinoweb-tab-content">
                <h2><?php _e('Look & Feel', 'ticinoweb-ai-theme'); ?></h2>
                <p class="description"><?php _e('Personalizza font, palette colori e immagini del tema.', 'ticinoweb-ai-theme'); ?></p>

                <h3 style="margin-top: 20px;"><?php _e('Font del sito', 'ticinoweb-ai-theme'); ?></h3>
                <?php
                $ticinoweb_google_fonts = array(
                    'Poppins', 'Inter', 'Montserrat', 'Nunito', 'Roboto', 'Open Sans', 'Lato',
                    'Raleway', 'Merriweather', 'Playfair Display', 'Source Sans 3', 'Work Sans',
                    'DM Sans', 'Manrope', 'Rubik'
                );
                ?>
                <table class="form-table">
                    <tr>
                        <th scope="row"><label for="ticinoweb_font_headings"><?php _e('Titoli', 'ticinoweb-ai-theme'); ?></label></th>
                        <td>
                            <?php $font_headings = get_option('ticinoweb_font_headings', 'Poppins'); ?>
                            <select id="ticinoweb_font_headings" name="ticinoweb_font_headings">
                                <?php foreach ($ticinoweb_google_fonts as $font): ?>
                                    <option value="<?php echo esc_attr($font); ?>" <?php selected($font_headings, $font); ?>><?php echo esc_html($font); ?></option>
                                <?php endforeach; ?>
                            </select>
                            <p class="description"><?php _e('Font usato per i titoli principali (H1-H2).', 'ticinoweb-ai-theme'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="ticinoweb_font_subheadings"><?php _e('Sottotitoli', 'ticinoweb-ai-theme'); ?></label></th>
                        <td>
                            <?php $font_subheadings = get_option('ticinoweb_font_subheadings', 'Poppins'); ?>
                            <select id="ticinoweb_font_subheadings" name="ticinoweb_font_subheadings">
                                <?php foreach ($ticinoweb_google_fonts as $font): ?>
                                    <option value="<?php echo esc_attr($font); ?>" <?php selected($font_subheadings, $font); ?>><?php echo esc_html($font); ?></option>
                                <?php endforeach; ?>
                            </select>
                            <p class="description"><?php _e('Font usato per sottotitoli e elementi secondari.', 'ticinoweb-ai-theme'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="ticinoweb_font_body"><?php _e('Testi', 'ticinoweb-ai-theme'); ?></label></th>
                        <td>
                            <?php $font_body = get_option('ticinoweb_font_body', 'Poppins'); ?>
                            <select id="ticinoweb_font_body" name="ticinoweb_font_body">
                                <?php foreach ($ticinoweb_google_fonts as $font): ?>
                                    <option value="<?php echo esc_attr($font); ?>" <?php selected($font_body, $font); ?>><?php echo esc_html($font); ?></option>
                                <?php endforeach; ?>
                            </select>
                            <p class="description"><?php _e('Font usato per il corpo testo e paragrafi.', 'ticinoweb-ai-theme'); ?></p>
                        </td>
                    </tr>
                </table>

                <h3 style="margin-top: 20px;"><?php _e('Color palette', 'ticinoweb-ai-theme'); ?></h3>
                <table class="form-table">
                    <tr>
                        <th scope="row"><label for="ticinoweb_palette_primary"><?php _e('Colore principale', 'ticinoweb-ai-theme'); ?></label></th>
                        <td>
                            <input type="text" id="ticinoweb_palette_primary" name="ticinoweb_palette_primary" value="<?php echo esc_attr(get_option('ticinoweb_palette_primary', '#1a7c1a')); ?>" class="color-picker" data-default-color="#1a7c1a">
                            <button type="button" class="button button-secondary" id="generate-palette-btn" style="margin-left: 8px;"><?php _e('Suggerisci palette', 'ticinoweb-ai-theme'); ?></button>
                            <button type="button" class="button" id="apply-palette-btn" style="margin-left: 6px;"><?php _e('Applica questa palette', 'ticinoweb-ai-theme'); ?></button>
                            <p class="description"><?php _e('Scegli il colore principale e genera 2-3 colori armonici suggeriti.', 'ticinoweb-ai-theme'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php _e('Colori suggeriti', 'ticinoweb-ai-theme'); ?></th>
                        <td>
                            <div style="display: flex; gap: 12px; flex-wrap: wrap; align-items: center;">
                                <div>
                                    <input type="text" id="ticinoweb_palette_suggested_1" name="ticinoweb_palette_suggested_1" value="<?php echo esc_attr(get_option('ticinoweb_palette_suggested_1', '')); ?>" class="regular-text color-picker">
                                    <span id="palette-swatch-1" style="display:inline-block;width:20px;height:20px;border-radius:4px;border:1px solid #ccc;margin-left:6px;vertical-align:middle;"></span>
                                </div>
                                <div>
                                    <input type="text" id="ticinoweb_palette_suggested_2" name="ticinoweb_palette_suggested_2" value="<?php echo esc_attr(get_option('ticinoweb_palette_suggested_2', '')); ?>" class="regular-text color-picker">
                                    <span id="palette-swatch-2" style="display:inline-block;width:20px;height:20px;border-radius:4px;border:1px solid #ccc;margin-left:6px;vertical-align:middle;"></span>
                                </div>
                                <div>
                                    <input type="text" id="ticinoweb_palette_suggested_3" name="ticinoweb_palette_suggested_3" value="<?php echo esc_attr(get_option('ticinoweb_palette_suggested_3', '')); ?>" class="regular-text color-picker">
                                    <span id="palette-swatch-3" style="display:inline-block;width:20px;height:20px;border-radius:4px;border:1px solid #ccc;margin-left:6px;vertical-align:middle;"></span>
                                </div>
                            </div>
                            <p class="description"><?php _e('Questi colori vengono proposti a partire dal colore principale. Puoi modificarli, rigenerarli o applicarli.', 'ticinoweb-ai-theme'); ?></p>
                        </td>
                    </tr>
                </table>

                <hr style="margin: 30px 0;">

                <h3><?php _e('Logo e Icona del sito', 'ticinoweb-ai-theme'); ?></h3>
                <p class="description"><?php _e('Imposta logo e icona (favicon) direttamente dal CMS. Il logo sarà usato in header/footer; l’icona è usata come favicon.', 'ticinoweb-ai-theme'); ?></p>

                <table class="form-table">
                    <tr>
                        <th scope="row">
                            <label for="ticinoweb_site_logo"><?php _e('Logo', 'ticinoweb-ai-theme'); ?></label>
                        </th>
                        <td>
                            <input type="text" id="ticinoweb_site_logo" name="ticinoweb_site_logo" 
                                   value="<?php echo esc_attr(get_option('ticinoweb_site_logo')); ?>" 
                                   class="regular-text">
                            <button type="button" class="button button-secondary" id="upload_site_logo_btn"><?php _e('Carica Logo', 'ticinoweb-ai-theme'); ?></button>
                            <div id="site-logo-preview" style="margin-top: 10px;">
                                <?php $curr_logo = get_option('ticinoweb_site_logo'); if (!empty($curr_logo)): ?>
                                    <img src="<?php echo esc_url($curr_logo); ?>" style="max-width: 220px; height: auto; border: 1px solid #ddd; border-radius: 4px;">
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="ticinoweb_site_icon"><?php _e('Icona (favicon)', 'ticinoweb-ai-theme'); ?></label>
                        </th>
                        <td>
                            <input type="text" id="ticinoweb_site_icon" name="ticinoweb_site_icon" 
                                   value="<?php echo esc_attr(get_option('ticinoweb_site_icon')); ?>" 
                                   class="regular-text">
                            <button type="button" class="button button-secondary" id="upload_site_icon_btn"><?php _e('Carica Icona', 'ticinoweb-ai-theme'); ?></button>
                            <div id="site-icon-preview" style="margin-top: 10px;">
                                <?php $curr_icon = get_option('ticinoweb_site_icon'); if (!empty($curr_icon)): ?>
                                    <img src="<?php echo esc_url($curr_icon); ?>" style="max-width: 64px; height: auto; border: 1px solid #ddd; border-radius: 4px;">
                                <?php endif; ?>
                            </div>
                            <p class="description"><?php _e('Usa un quadrato (es. 512x512) per risultati ottimali.', 'ticinoweb-ai-theme'); ?></p>
                        </td>
                    </tr>
                </table>

                <hr style="margin: 30px 0;">

                <h3><?php _e('Immagini Tema', 'ticinoweb-ai-theme'); ?></h3>
                <p class="description"><?php _e('Configura le immagini utilizzate nel tema (header pagine, sfondi, overlay).', 'ticinoweb-ai-theme'); ?></p>
                
                <table class="form-table">
                    <tr>
                        <th scope="row">
                            <label for="ticinoweb_page_header_overlay_image"><?php _e('Immagine Barra Superiore (Overlay)', 'ticinoweb-ai-theme'); ?></label>
                        </th>
                        <td>
                            <input type="text" id="ticinoweb_page_header_overlay_image" name="ticinoweb_page_header_overlay_image" 
                                   value="<?php echo esc_attr(get_option('ticinoweb_page_header_overlay_image')); ?>" 
                                   class="regular-text" placeholder="https://example.com/image.jpg">
                            <button type="button" class="button button-secondary" id="upload_header_overlay_btn"><?php _e('Carica Immagine', 'ticinoweb-ai-theme'); ?></button>
                            <p class="description"><?php _e('Immagine usata come overlay traslucido nella barra superiore delle pagine interne (template tW Full Width).', 'ticinoweb-ai-theme'); ?></p>
                            <p class="description ticinoweb-field-doc"><?php _e('Questa immagine viene applicata come overlay in alto nelle pagine interne. Non usa shortcode, è richiamata direttamente dal template.', 'ticinoweb-ai-theme'); ?></p>
                            <div id="header-overlay-preview" style="margin-top: 10px;">
                                <?php 
                                $overlay_img = get_option('ticinoweb_page_header_overlay_image');
                                if (!empty($overlay_img)): 
                                ?>
                                    <img src="<?php echo esc_url($overlay_img); ?>" style="max-width: 300px; height: auto; border: 1px solid #ddd; border-radius: 4px;">
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="ticinoweb_page_header_bg_image"><?php _e('Immagine Sfondo Barra', 'ticinoweb-ai-theme'); ?></label>
                        </th>
                        <td>
                            <input type="text" id="ticinoweb_page_header_bg_image" name="ticinoweb_page_header_bg_image" 
                                   value="<?php echo esc_attr(get_option('ticinoweb_page_header_bg_image')); ?>" 
                                   class="regular-text" placeholder="https://example.com/background.jpg">
                            <button type="button" class="button button-secondary" id="upload_header_bg_btn"><?php _e('Carica Immagine', 'ticinoweb-ai-theme'); ?></button>
                            <p class="description"><?php _e('Immagine di sfondo della barra superiore. Se presente, viene usata dietro al colore/gradiente.', 'ticinoweb-ai-theme'); ?></p>
                            <p class="description ticinoweb-field-doc"><?php _e('Sfondo della barra superiore per pagine interne. Non usa shortcode.', 'ticinoweb-ai-theme'); ?></p>
                            <div id="header-bg-preview" style="margin-top: 10px;">
                                <?php 
                                $bg_img = get_option('ticinoweb_page_header_bg_image');
                                if (!empty($bg_img)): 
                                ?>
                                    <img src="<?php echo esc_url($bg_img); ?>" style="max-width: 300px; height: auto; border: 1px solid #ddd; border-radius: 4px;">
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="ticinoweb_page_header_bg_color"><?php _e('Colore Sfondo Barra', 'ticinoweb-ai-theme'); ?></label>
                        </th>
                        <td>
                            <input type="text" id="ticinoweb_page_header_bg_color" name="ticinoweb_page_header_bg_color" 
                                   value="<?php echo esc_attr(get_option('ticinoweb_page_header_bg_color', '#6b9b6b')); ?>" 
                                   class="color-picker" data-default-color="#6b9b6b">
                            <p class="description"><?php _e('Colore di sfondo della barra superiore pagine (default: verde #6b9b6b).', 'ticinoweb-ai-theme'); ?></p>
                            <p class="description ticinoweb-field-doc"><?php _e('Il colore viene usato come fallback quando non è presente un overlay. Non usa shortcode.', 'ticinoweb-ai-theme'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="ticinoweb_page_header_bg_gradient_enabled"><?php _e('Gradiente Sfondo Barra', 'ticinoweb-ai-theme'); ?></label>
                        </th>
                        <td>
                            <label>
                                <input type="hidden" name="ticinoweb_page_header_bg_gradient_enabled" value="0">
                                <input type="checkbox" id="ticinoweb_page_header_bg_gradient_enabled" name="ticinoweb_page_header_bg_gradient_enabled" value="1" <?php checked(get_option('ticinoweb_page_header_bg_gradient_enabled'), '1'); ?>>
                                <?php _e('Usa gradiente a due colori', 'ticinoweb-ai-theme'); ?>
                            </label>
                            <div style="margin-top: 10px; display: flex; gap: 10px; align-items: center;">
                                <div>
                                    <label for="ticinoweb_page_header_bg_gradient_color_1"><?php _e('Colore 1', 'ticinoweb-ai-theme'); ?></label><br>
                                    <input type="text" id="ticinoweb_page_header_bg_gradient_color_1" name="ticinoweb_page_header_bg_gradient_color_1" 
                                           value="<?php echo esc_attr(get_option('ticinoweb_page_header_bg_gradient_color_1', '#6b9b6b')); ?>" 
                                           class="color-picker" data-default-color="#6b9b6b">
                                </div>
                                <div>
                                    <label for="ticinoweb_page_header_bg_gradient_color_2"><?php _e('Colore 2', 'ticinoweb-ai-theme'); ?></label><br>
                                    <input type="text" id="ticinoweb_page_header_bg_gradient_color_2" name="ticinoweb_page_header_bg_gradient_color_2" 
                                           value="<?php echo esc_attr(get_option('ticinoweb_page_header_bg_gradient_color_2', '#4e7a4e')); ?>" 
                                           class="color-picker" data-default-color="#4e7a4e">
                                </div>
                            </div>
                            <p class="description"><?php _e('Se attivo, il gradiente sostituisce il colore unico. Puoi abbinarlo all’immagine di sfondo.', 'ticinoweb-ai-theme'); ?></p>
                            <p class="description ticinoweb-field-doc"><?php _e('Gradiente applicato alla barra superiore. Non usa shortcode.', 'ticinoweb-ai-theme'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="ticinoweb_page_bg_image"><?php _e('Immagine Sfondo Pagina', 'ticinoweb-ai-theme'); ?></label>
                        </th>
                        <td>
                            <input type="text" id="ticinoweb_page_bg_image" name="ticinoweb_page_bg_image" 
                                   value="<?php echo esc_attr(get_option('ticinoweb_page_bg_image')); ?>" 
                                   class="regular-text" placeholder="https://example.com/page-bg.jpg">
                            <button type="button" class="button button-secondary" id="upload_page_bg_btn"><?php _e('Carica Immagine', 'ticinoweb-ai-theme'); ?></button>
                            <p class="description"><?php _e('Immagine di sfondo per le pagine. Puoi applicarla a tutte le pagine o solo a una specifica.', 'ticinoweb-ai-theme'); ?></p>
                            <p class="description ticinoweb-field-doc"><?php _e('Sfondo pagina applicato dal tema. Non usa shortcode.', 'ticinoweb-ai-theme'); ?></p>
                            <div id="page-bg-preview" style="margin-top: 10px;">
                                <?php $page_bg_img = get_option('ticinoweb_page_bg_image'); if (!empty($page_bg_img)): ?>
                                    <img src="<?php echo esc_url($page_bg_img); ?>" style="max-width: 300px; height: auto; border: 1px solid #ddd; border-radius: 4px;">
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="ticinoweb_page_bg_scope"><?php _e('Applica Sfondo Pagina', 'ticinoweb-ai-theme'); ?></label>
                        </th>
                        <td>
                            <?php $bg_scope = get_option('ticinoweb_page_bg_scope', 'all'); ?>
                            <select id="ticinoweb_page_bg_scope" name="ticinoweb_page_bg_scope">
                                <option value="all" <?php selected($bg_scope, 'all'); ?>><?php _e('Tutte le pagine', 'ticinoweb-ai-theme'); ?></option>
                                <option value="specific" <?php selected($bg_scope, 'specific'); ?>><?php _e('Solo pagina specifica', 'ticinoweb-ai-theme'); ?></option>
                            </select>
                            <p class="description"><?php _e('Scegli se applicare lo sfondo a tutte le pagine o a una specifica.', 'ticinoweb-ai-theme'); ?></p>
                        </td>
                    </tr>
                    <tr id="page-bg-specific-row" style="display: <?php echo ($bg_scope === 'specific') ? 'table-row' : 'none'; ?>;">
                        <th scope="row">
                            <label for="ticinoweb_page_bg_page_id"><?php _e('Pagina Specifica', 'ticinoweb-ai-theme'); ?></label>
                        </th>
                        <td>
                            <?php
                            $pages_for_bg = get_pages(array('post_status' => 'publish'));
                            $selected_bg_page = (int) get_option('ticinoweb_page_bg_page_id', 0);
                            ?>
                            <select id="ticinoweb_page_bg_page_id" name="ticinoweb_page_bg_page_id">
                                <option value="0"><?php _e('-- Seleziona pagina --', 'ticinoweb-ai-theme'); ?></option>
                                <?php foreach ($pages_for_bg as $page): ?>
                                    <option value="<?php echo $page->ID; ?>" <?php selected($selected_bg_page, $page->ID); ?>><?php echo esc_html($page->post_title); ?></option>
                                <?php endforeach; ?>
                            </select>
                            <p class="description"><?php _e('Lo sfondo verrà applicato solo alla pagina selezionata.', 'ticinoweb-ai-theme'); ?></p>
                        </td>
                    </tr>
                </table>
            </div>
            
            <!-- Services Tab -->
            <div id="services" class="ticinoweb-tab-content active">
                <div style="display: flex; justify-content: space-between; align-items: center;">
                    <h2 style="margin: 0;"><?php _e('Gestione Servizi', 'ticinoweb-ai-theme'); ?></h2>
                    <?php submit_button(__('Salva Modifiche', 'ticinoweb-ai-theme'), 'primary', 'submit', false); ?>
                </div>
                <p class="description notification-message" style="margin-top: 10px;"><?php _e('Aggiungi i servizi che verranno mostrati nella pagina Servizi del tema child. Usa la funzione ticinoweb_get_services() nel template.', 'ticinoweb-ai-theme'); ?></p>
                
                <div id="services-container">
                    <?php
                    $services = get_option('ticinoweb_services', []);
                    if (empty($services)) {
                        $services = [['image' => '', 'title' => '', 'description' => '', 'icon' => 'dashicons-admin-tools']];
                    }
                    
                    foreach ($services as $index => $service):
                        $service_title_preview = !empty($service['title']) ? esc_html($service['title']) : __('(nessun titolo)', 'ticinoweb-ai-theme');
                        $service_id = !empty($service['id']) ? $service['id'] : ('srv_' . substr(md5(uniqid((string)mt_rand(), true)), 0, 8));
                    ?>
                    <div class="service-item" data-index="<?php echo $index; ?>" style="background: #fff; border: 1px solid #ccd0d4; border-radius: 4px; padding: 16px; margin-bottom: 16px; position: relative;">
                        <input type="hidden" name="ticinoweb_services[<?php echo $index; ?>][id]" value="<?php echo esc_attr($service_id); ?>">
                        <div class="service-header" style="display: flex; align-items: center; gap: 8px;">
                            <button type="button" class="button-link service-toggle" aria-expanded="false" style="display: inline-flex; align-items: center; gap: 6px; text-decoration: none; padding: 4px 0;">
                                <span class="dashicons dashicons-arrow-right-alt2 service-toggle-icon"></span>
                                <strong><?php _e('Servizio', 'ticinoweb-ai-theme'); ?> #<?php echo $index + 1; ?></strong>
                                <span class="service-title-preview" style="color: #555;"><?php echo $service_title_preview; ?></span>
                            </button>
                            <button type="button" class="button button-link-delete remove-service" style="margin-left: auto; color: #b32d2e; text-decoration: none;">
                                <span class="dashicons dashicons-trash"></span> <?php _e('Rimuovi', 'ticinoweb-ai-theme'); ?>
                            </button>
                        </div>
                        
                        <div class="service-fields" style="display: none; margin-top: 12px;">
                            <table class="form-table">
                                <tr>
                                    <th scope="row" style="width: 180px;">
                                        <label><?php _e('Tipo Icona', 'ticinoweb-ai-theme'); ?></label>
                                    </th>
                                    <td>
                                        <label style="display: inline-block; margin-right: 20px;">
                                            <input type="radio" name="ticinoweb_services[<?php echo $index; ?>][icon_type]" value="dashicon" 
                                                   class="service-icon-type-radio" 
                                                   <?php checked($service['icon_type'] ?? 'dashicon', 'dashicon'); ?>>
                                            <?php _e('Dashicon', 'ticinoweb-ai-theme'); ?>
                                        </label>
                                        <label style="display: inline-block;">
                                            <input type="radio" name="ticinoweb_services[<?php echo $index; ?>][icon_type]" value="svg" 
                                                   class="service-icon-type-radio" 
                                                   <?php checked($service['icon_type'] ?? 'dashicon', 'svg'); ?>>
                                            <?php _e('Icona SVG Personalizzata', 'ticinoweb-ai-theme'); ?>
                                        </label>
                                    </td>
                                </tr>
                                <tr class="icon-dashicon-row" style="<?php echo (isset($service['icon_type']) && $service['icon_type'] === 'svg') ? 'display: none;' : ''; ?>">
                                    <th scope="row">
                                        <label><?php _e('Icona Dashicon', 'ticinoweb-ai-theme'); ?></label>
                                    </th>
                                    <td>
                                        <input type="text" name="ticinoweb_services[<?php echo $index; ?>][icon]" 
                                               value="<?php echo esc_attr($service['icon'] ?? 'dashicons-admin-tools'); ?>" 
                                               class="regular-text service-icon-input" 
                                               placeholder="dashicons-admin-tools">
                                        <div class="service-icon-preview" style="display: inline-block; margin-left: 10px; width: 32px; height: 32px;">
                                            <span class="dashicons <?php echo esc_attr($service['icon'] ?? 'dashicons-admin-tools'); ?>" style="font-size: 32px; width: 32px; height: 32px;"></span>
                                        </div>
                                        <p class="description"><?php _e('Esempio: dashicons-admin-tools, dashicons-hammer, dashicons-shield. Vedi:', 'ticinoweb-ai-theme'); ?> <a href="https://developer.wordpress.org/resource/dashicons/" target="_blank">Dashicons</a></p>
                                    </td>
                                </tr>
                                <tr class="icon-svg-row" style="<?php echo (!isset($service['icon_type']) || $service['icon_type'] === 'dashicon') ? 'display: none;' : ''; ?>">
                                    <th scope="row">
                                        <label><?php _e('Icona SVG', 'ticinoweb-ai-theme'); ?></label>
                                    </th>
                                    <td>
                                        <input type="text" name="ticinoweb_services[<?php echo $index; ?>][icon_svg]" 
                                               value="<?php echo esc_attr($service['icon_svg'] ?? ''); ?>" 
                                               class="regular-text service-svg-url" placeholder="https://example.com/icon.svg">
                                        <button type="button" class="button button-secondary upload-service-svg"><?php _e('Carica SVG', 'ticinoweb-ai-theme'); ?></button>
                                        <div class="service-svg-preview" style="margin-top: 10px;">
                                            <?php if (!empty($service['icon_svg'])): ?>
                                                <img src="<?php echo esc_url($service['icon_svg']); ?>" style="max-width: 64px; height: auto; border: 1px solid #ddd; border-radius: 4px;">
                                            <?php endif; ?>
                                        </div>
                                        <p class="description"><?php _e('Carica un\'icona SVG personalizzata (preferibilmente 64x64px).', 'ticinoweb-ai-theme'); ?></p>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row">
                                        <label><?php _e('Immagine Servizio', 'ticinoweb-ai-theme'); ?></label>
                                    </th>
                                    <td>
                                        <input type="text" name="ticinoweb_services[<?php echo $index; ?>][image]" 
                                               value="<?php echo esc_attr($service['image'] ?? ''); ?>" 
                                               class="regular-text service-image-url" placeholder="https://example.com/servizio.jpg">
                                        <button type="button" class="button button-secondary upload-service-image"><?php _e('Carica Immagine', 'ticinoweb-ai-theme'); ?></button>
                                        <div class="service-image-preview" style="margin-top: 10px;">
                                            <?php if (!empty($service['image'])): ?>
                                                <img src="<?php echo esc_url($service['image']); ?>" style="max-width: 200px; height: auto; border: 1px solid #ddd; border-radius: 4px;">
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row">
                                        <label><?php _e('Titolo Servizio', 'ticinoweb-ai-theme'); ?></label>
                                    </th>
                                    <td>
                                        <input type="text" name="ticinoweb_services[<?php echo $index; ?>][title]" 
                                               value="<?php echo esc_attr($service['title'] ?? ''); ?>" 
                                               class="regular-text service-title-input" placeholder="<?php _e('Es: Potatura Alberi', 'ticinoweb-ai-theme'); ?>">
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row">
                                        <label><?php _e('Descrizione', 'ticinoweb-ai-theme'); ?></label>
                                    </th>
                                    <td>
                                        <textarea name="ticinoweb_services[<?php echo $index; ?>][description]" 
                                                  rows="4" class="large-text" placeholder="<?php _e('Descrizione breve del servizio...', 'ticinoweb-ai-theme'); ?>"><?php echo esc_textarea($service['description'] ?? ''); ?></textarea>
                                    </td>
                                </tr>
                            </table>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
                
                <button type="button" id="add-service" class="button button-primary">
                    <span class="dashicons dashicons-plus-alt" style="margin-top: 3px;"></span> <?php _e('Aggiungi Servizio', 'ticinoweb-ai-theme'); ?>
                </button>
                
                <div style="margin-top: 30px; padding: 15px; background: #f0f6fc; border-left: 4px solid #0073aa; border-radius: 4px;">
                    <h4 style="margin-top: 0;"><?php _e('Come utilizzare i servizi nel tema child', 'ticinoweb-ai-theme'); ?></h4>
                    <p><strong><?php _e('Funzione helper:', 'ticinoweb-ai-theme'); ?></strong></p>
                    <pre style="background: #23282d; color: #f0f0f0; padding: 15px; border-radius: 4px; overflow-x: auto;">$services = ticinoweb_get_services();
foreach ($services as $service) {
    echo '&lt;h3&gt;' . esc_html($service['title']) . '&lt;/h3&gt;';
    echo '&lt;img src="' . esc_url($service['image']) . '"&gt;';
    echo '&lt;p&gt;' . wp_kses_post($service['description']) . '&lt;/p&gt;';
    echo '&lt;span class="' . esc_attr($service['icon']) . '"&gt;&lt;/span&gt;';
}</pre>
                </div>
            </div>
            
            <?php if (!get_option('ticinoweb_disable_svg_icons')): ?>
            <!-- SVG Icons Tab -->
            <div id="svg-icons" class="ticinoweb-tab-content">
                <h2><?php _e('Libreria Icone SVG', 'ticinoweb-ai-theme'); ?></h2>
                <p class="description"><?php _e('Icone SVG disponibili dalla cartella /assets/icons/. Clicca su un\'icona per copiare il percorso completo.', 'ticinoweb-ai-theme'); ?></p>
                
                <div style="margin: 20px 0; padding: 15px; background: #fff; border: 1px solid #ccd0d4; border-radius: 4px;">
                    <input type="text" id="svg-search" placeholder="<?php _e('Cerca icone...', 'ticinoweb-ai-theme'); ?>" class="large-text" style="margin-bottom: 15px;">
                    
                    <?php
                    $icons_dir = get_template_directory() . '/assets/icons/';
                    $icons_url = get_template_directory_uri() . '/assets/icons/';

                    // Cache + validation for SVG icons (admin panel)
                    function ticinoweb_admin_get_svg_icons_cached($icons_dir, $icons_url) {
                        $cache_key = 'ticinoweb_admin_svg_icons_list';
                        $cache_time = 12 * HOUR_IN_SECONDS;

                        $cached = get_transient($cache_key);
                        if ($cached !== false && is_array($cached)) {
                            return $cached;
                        }

                        $icons_by_category = ticinoweb_admin_scan_svg_icons($icons_dir, $icons_url);
                        set_transient($cache_key, $icons_by_category, $cache_time);
                        return $icons_by_category;
                    }

                    function ticinoweb_admin_encode_svg_url($base_url, $relative_path) {
                        $relative_path = str_replace('\\', '/', $relative_path);
                        $parts = array_map('rawurlencode', explode('/', $relative_path));
                        return $base_url . implode('/', $parts);
                    }

                    function ticinoweb_admin_validate_svg($file_path) {
                        if (!is_readable($file_path)) {
                            return false;
                        }

                        $size = filesize($file_path);
                        if ($size < 100 || $size > 500000) {
                            return false;
                        }

                        $content = @file_get_contents($file_path);
                        if ($content === false || stripos($content, '<svg') === false) {
                            return false;
                        }

                        $previous_errors = libxml_use_internal_errors(true);
                        $dom = new DOMDocument();
                        $loaded = @$dom->loadXML($content);
                        libxml_use_internal_errors($previous_errors);

                        if (!$loaded || !$dom->documentElement || $dom->documentElement->tagName !== 'svg') {
                            return false;
                        }

                        return true;
                    }

                    function ticinoweb_admin_scan_svg_icons($dir, $base_url, $category = '') {
                        $icons_by_category = array();

                        if (!is_dir($dir)) {
                            return $icons_by_category;
                        }

                        $items = scandir($dir);

                        foreach ($items as $item) {
                            if ($item === '.' || $item === '..') {
                                continue;
                            }

                            $item_path = $dir . $item;

                            if (is_dir($item_path)) {
                                $sub_category = $category ? $category . '/' . $item : $item;
                                $sub_icons = ticinoweb_admin_scan_svg_icons($item_path . '/', $base_url, $sub_category);
                                foreach ($sub_icons as $cat => $icons) {
                                    if (!isset($icons_by_category[$cat])) {
                                        $icons_by_category[$cat] = array();
                                    }
                                    $icons_by_category[$cat] = array_merge($icons_by_category[$cat], $icons);
                                }
                            } elseif (pathinfo($item, PATHINFO_EXTENSION) === 'svg') {
                                $full_path = $dir . $item;
                                if (!ticinoweb_admin_validate_svg($full_path)) {
                                    continue;
                                }

                                $cat_name = $category ? $category : 'Senza categoria';
                                if (!isset($icons_by_category[$cat_name])) {
                                    $icons_by_category[$cat_name] = array();
                                }

                                $rel_path = $category ? $category . '/' . $item : $item;
                                $icons_by_category[$cat_name][] = array(
                                    'filename' => $item,
                                    'url' => ticinoweb_admin_encode_svg_url($base_url, $rel_path),
                                    'name' => pathinfo($item, PATHINFO_FILENAME),
                                    'path' => $rel_path,
                                    'category' => $cat_name
                                );
                            }
                        }

                        return $icons_by_category;
                    }

                    $icons_by_category = ticinoweb_admin_get_svg_icons_cached($icons_dir, $icons_url);
                    
                    if (!empty($icons_by_category)) :
                        // Create category filter tabs
                        $all_count = 0;
                        foreach ($icons_by_category as $icons) {
                            $all_count += count($icons);
                        }
                        ?>
                        
                        <div class="svg-category-tabs" style="margin-bottom: 15px; border-bottom: 1px solid #ddd;">
                            <button type="button" class="svg-cat-tab active" data-category="all" style="padding: 8px 16px; border: none; background: #0073aa; color: #fff; cursor: pointer; margin-right: 5px; border-radius: 4px 4px 0 0;">
                                <?php _e('Tutte', 'ticinoweb-ai-theme'); ?> (<?php echo $all_count; ?>)
                            </button>
                            <?php foreach ($icons_by_category as $cat_name => $icons) : ?>
                                <button type="button" class="svg-cat-tab" data-category="<?php echo esc_attr($cat_name); ?>" style="padding: 8px 16px; border: none; background: #f0f0f0; color: #333; cursor: pointer; margin-right: 5px; border-radius: 4px 4px 0 0;">
                                    <?php echo esc_html(ucfirst($cat_name)); ?> (<?php echo count($icons); ?>)
                                </button>
                            <?php endforeach; ?>
                        </div>
                        
                        <div id="svg-icons-grid" style="display: grid; grid-template-columns: repeat(auto-fill, minmax(120px, 1fr)); gap: 15px; max-height: 600px; overflow-y: auto; padding: 10px;"></div>

                        <div style="margin-top: 12px; text-align: center;">
                            <button type="button" id="svg-load-more" class="button button-secondary" style="display: none;">Carica altre icone</button>
                        </div>

                        <script>
                            window.ticinowebAdminSvgIcons = <?php echo wp_json_encode($icons_by_category); ?>;
                        </script>
                        
                    <?php else : ?>
                        <p style="color: #d63638;"><?php _e('Nessuna icona SVG trovata in /assets/icons/', 'ticinoweb-ai-theme'); ?></p>
                    <?php endif; ?>
                    
                    <div id="svg-copy-notice" style="display: none; margin-top: 15px; padding: 10px; background: #00a32a; color: #fff; border-radius: 4px; text-align: center;">
                        <?php _e('URL copiato negli appunti!', 'ticinoweb-ai-theme'); ?>
                    </div>
                </div>
                
                <div style="margin-top: 20px; padding: 15px; background: #f0f6fc; border-left: 4px solid #0073aa; border-radius: 4px;">
                    <h4 style="margin-top: 0;"><?php _e('Come usare le icone SVG nei servizi', 'ticinoweb-ai-theme'); ?></h4>
                    <ol>
                        <li><?php _e('Clicca su un\'icona qui sopra per copiare il nome del file', 'ticinoweb-ai-theme'); ?></li>
                        <li><?php _e('Vai al tab "Servizi" e modifica un servizio', 'ticinoweb-ai-theme'); ?></li>
                        <li><?php _e('Seleziona "SVG Custom" come tipo icona', 'ticinoweb-ai-theme'); ?></li>
                        <li><?php _e('Incolla il nome del file nel campo "SVG URL"', 'ticinoweb-ai-theme'); ?></li>
                    </ol>
                    <p><strong><?php _e('Percorso completo:', 'ticinoweb-ai-theme'); ?></strong> <code><?php echo esc_html($icons_url); ?>nome-icona.svg</code></p>
                </div>
            </div>
            <?php endif; ?>
            
            <!-- Form Submissions Tab -->
            <div id="form-submissions" class="ticinoweb-tab-content">
                <h2><?php _e('Invii Ricevuti', 'ticinoweb-ai-theme'); ?></h2>
                <p class="description"><?php _e('Cronologia dei messaggi ricevuti dal form contatti.', 'ticinoweb-ai-theme'); ?></p>
                
                <?php
                global $wpdb;
                $table_name = $wpdb->prefix . 'ticinoweb_form_submissions';
                
                // Get page size from query parameter or default to 10
                $per_page_options = array(10, 20, 50, 100);
                $per_page = isset($_GET['per_page']) ? intval($_GET['per_page']) : 10;
                if (!in_array($per_page, $per_page_options)) {
                    $per_page = 10;
                }
                
                // Get total submissions
                $total_items = intval($wpdb->get_var("SELECT COUNT(*) FROM $table_name"));
                $total_pages = ceil($total_items / $per_page);
                
                // Get current page
                $current_page = isset($_GET['sub_paged']) ? intval($_GET['sub_paged']) : 1;
                $current_page = max(1, min($total_pages ? $total_pages : 1, $current_page));
                
                // Calculate offset
                $offset = ($current_page - 1) * $per_page;
                
                // Get paginated submissions
                $submissions = $wpdb->get_results($wpdb->prepare(
                    "SELECT * FROM $table_name ORDER BY data_invio DESC LIMIT %d OFFSET %d",
                    $per_page,
                    $offset
                ));
                
                if ($submissions && count($submissions) > 0):
                ?>
                    <div class="submission-actions" style="margin: 10px 0 15px; display: flex; align-items: center; gap: 10px;">
                        <button type="button" id="delete-selected-submissions" class="button button-secondary" disabled><?php _e('Elimina selezionati', 'ticinoweb-ai-theme'); ?></button>
                        <span id="submission-delete-feedback" style="color: #2271b1;"></span>
                    </div>

                    <div style="margin-top: 20px; overflow-x: auto;">
                        <table class="widefat striped">
                            <thead>
                                <tr>
                                    <th style="width: 32px; text-align: center;"><input type="checkbox" id="select-all-submissions"></th>
                                    <th><?php _e('Data', 'ticinoweb-ai-theme'); ?></th>
                                    <th><?php _e('Nome', 'ticinoweb-ai-theme'); ?></th>
                                    <th><?php _e('Email', 'ticinoweb-ai-theme'); ?></th>
                                    <th><?php _e('Telefono', 'ticinoweb-ai-theme'); ?></th>
                                    <th><?php _e('Oggetto', 'ticinoweb-ai-theme'); ?></th>
                                    <th><?php _e('Messaggio', 'ticinoweb-ai-theme'); ?></th>
                                    <th><?php _e('Stato', 'ticinoweb-ai-theme'); ?></th>
                                    <th><?php _e('Azioni', 'ticinoweb-ai-theme'); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($submissions as $submission): ?>
                                    <tr class="submission-row"
                                        data-id="<?php echo esc_attr($submission->id); ?>"
                                        data-nome="<?php echo esc_attr($submission->nome); ?>"
                                        data-email="<?php echo esc_attr($submission->email); ?>"
                                        data-telefono="<?php echo esc_attr($submission->telefono); ?>"
                                        data-oggetto="<?php echo esc_attr($submission->oggetto); ?>"
                                        data-messaggio="<?php echo esc_attr($submission->messaggio); ?>"
                                        data-data="<?php echo esc_attr(date('d.m.Y H:i', strtotime($submission->data_invio))); ?>"
                                        data-letto="<?php echo $submission->letto ? '1' : '0'; ?>">
                                        <td style="text-align: center;"><input type="checkbox" class="submission-checkbox" value="<?php echo esc_attr($submission->id); ?>" /></td>
                                        <td><?php echo esc_html(date('d.m.Y H:i', strtotime($submission->data_invio))); ?></td>
                                        <td><?php echo esc_html($submission->nome); ?></td>
                                        <td><a href="mailto:<?php echo esc_attr($submission->email); ?>"><?php echo esc_html($submission->email); ?></a></td>
                                        <td><?php echo esc_html($submission->telefono ?: '-'); ?></td>
                                        <td><?php echo esc_html($submission->oggetto); ?></td>
                                        <td><?php echo esc_html(substr($submission->messaggio, 0, 50)) . (strlen($submission->messaggio) > 50 ? '...' : ''); ?></td>
                                        <td>
                                            <span class="submission-status" style="padding: 4px 8px; border-radius: 3px; background: <?php echo $submission->letto ? '#f0f0f0' : '#fff8e5'; ?>; font-size: 12px;">
                                                <?php echo $submission->letto ? __('Letto', 'ticinoweb-ai-theme') : __('Non Letto', 'ticinoweb-ai-theme'); ?>
                                            </span>
                                        </td>
                                        <td>
                                            <a href="#" class="view-submission" data-id="<?php echo $submission->id; ?>" title="<?php _e('Visualizza completo', 'ticinoweb-ai-theme'); ?>"><?php _e('Visualizza', 'ticinoweb-ai-theme'); ?></a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>

                    <!-- Pagination Bar -->
                    <div class="ticinoweb-submissions-nav">
                        <div class="nav-left">
                            <?php 
                            $from_item = $offset + 1;
                            $to_item = min($offset + $per_page, $total_items);
                            if ($total_items > 0) {
                                printf(
                                    __('Mostrando da %1$d a %2$d di %3$d elementi', 'ticinoweb-ai-theme'),
                                    $from_item,
                                    $to_item,
                                    $total_items
                                );
                            } else {
                                _e('Nessun elemento da mostrare', 'ticinoweb-ai-theme');
                            }
                            ?>
                        </div>
                        <div class="nav-right">
                            <!-- Page Size Selector -->
                            <div class="page-size-selector">
                                <label for="ticinoweb-page-size"><?php _e('Elementi per pagina:', 'ticinoweb-ai-theme'); ?></label>
                                <select id="ticinoweb-page-size" onchange="ticinowebChangePageSize(this);">
                                    <?php foreach ($per_page_options as $option): ?>
                                        <option value="<?php echo $option; ?>" <?php selected($per_page, $option); ?>><?php echo $option; ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            
                            <!-- Pagination links -->
                            <?php
                            $page_links = paginate_links(array(
                                'base' => add_query_arg('sub_paged', '%#%'),
                                'format' => '',
                                'prev_text' => '&laquo;',
                                'next_text' => '&raquo;',
                                'total' => $total_pages,
                                'current' => $current_page,
                                'type' => 'array'
                            ));
                            
                            if ($page_links) {
                                echo '<ul class="ticinoweb-pagination">';
                                foreach ($page_links as $link) {
                                    if (strpos($link, 'href=') !== false) {
                                        $link = str_replace("'", '"', $link);
                                        $link = preg_replace('/href="([^"]+)"/', 'href="$1#form-submissions"', $link);
                                    }
                                    echo '<li>' . $link . '</li>';
                                }
                                echo '</ul>';
                            }
                            ?>
                        </div>
                    </div>
                    
                    <script>
                    function ticinowebChangePageSize(select) {
                        var url = new URL(window.location.href);
                        url.searchParams.set('per_page', select.value);
                        url.searchParams.set('sub_paged', '1');
                        url.hash = 'form-submissions';
                        window.location.href = url.toString();
                    }
                    </script>
                    
                    <!-- Modal for full submission view -->
                    <div id="submission-modal" style="display: none; position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(0,0,0,0.5); z-index: 9999; align-items: center; justify-content: center;">
                        <div style="background: white; padding: 30px; border-radius: 8px; max-width: 600px; width: 90%; max-height: 80vh; overflow-y: auto; position: relative;">
                            <button type="button" class="close-modal" style="position: absolute; top: 10px; right: 15px; background: none; border: none; font-size: 28px; cursor: pointer; color: #999;">×</button>
                            
                            <div id="modal-content">
                                <!-- Content will be filled by JS -->
                            </div>
                        </div>
                    </div>
                    
                <?php else: ?>
                    <div class="notice notice-info inline" style="margin: 20px 0;">
                        <p><?php _e('Nessun messaggio ricevuto ancora.', 'ticinoweb-ai-theme'); ?></p>
                    </div>
                <?php endif; ?>
            </div>
            
            <?php submit_button(); ?>
        </form>

        <!-- Admin Footer -->
        <div class="ticinoweb-admin-footer" style="margin-top: 50px; border-top: 1px solid #ccc; padding-top: 20px; padding-bottom: 20px; text-align: center; color: #666; font-size: 11px;">
            <p>
                <strong>ticinoWEB AI CMS v<?php echo TICINOWEB_THEME_VERSION; ?></strong> | 
                &copy; <?php echo date('Y'); ?> ticinoWEB. <?php _e('Tutti i diritti riservati.', 'ticinoweb-ai-theme'); ?>
            </p>
            <p style="opacity: 0.8;">
                <?php _e('Questo tema è concesso in licenza d\'uso esclusiva per questo sito. È vietata la ridistribuzione, la rivendita o l\'uso non autorizzato del codice sorgente.', 'ticinoweb-ai-theme'); ?><br>
                <?php _e('Built with custom header-less architecture by', 'ticinoweb-ai-theme'); ?> <a href="https://ticinoweb.com" target="_blank" style="color: #666; text-decoration: none; border-bottom: 1px dotted #999;">ticinoWEB</a>.
            </p>
        </div>

        <form id="ticinoweb-url-replace-form" method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
            <?php wp_nonce_field('ticinoweb_url_replacement', 'ticinoweb_url_replacement_nonce'); ?>
            <input type="hidden" name="action" value="ticinoweb_url_replacement">
        </form>
    </div>
    
    <script>
    jQuery(document).ready(function($) {
        var deleteNonce = '<?php echo wp_create_nonce('ticinoweb_delete_submissions'); ?>';

        // WordPress Color Picker
        if ($.fn.wpColorPicker) {
            $('.color-picker').wpColorPicker();
        }

        function hexToHsl(hex) {
            hex = hex.replace('#', '');
            if (hex.length === 3) {
                hex = hex.split('').map(function(c){ return c + c; }).join('');
            }
            var r = parseInt(hex.substr(0,2),16) / 255;
            var g = parseInt(hex.substr(2,2),16) / 255;
            var b = parseInt(hex.substr(4,2),16) / 255;
            var max = Math.max(r,g,b), min = Math.min(r,g,b);
            var h, s, l = (max + min) / 2;

            if (max === min) {
                h = s = 0;
            } else {
                var d = max - min;
                s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
                switch (max) {
                    case r: h = (g - b) / d + (g < b ? 6 : 0); break;
                    case g: h = (b - r) / d + 2; break;
                    case b: h = (r - g) / d + 4; break;
                }
                h = h * 60;
            }
            return { h: h, s: s, l: l };
        }

        function hslToHex(h, s, l) {
            var c = (1 - Math.abs(2*l - 1)) * s;
            var x = c * (1 - Math.abs((h / 60) % 2 - 1));
            var m = l - c/2;
            var r=0, g=0, b=0;

            if (h >= 0 && h < 60) { r=c; g=x; b=0; }
            else if (h >= 60 && h < 120) { r=x; g=c; b=0; }
            else if (h >= 120 && h < 180) { r=0; g=c; b=x; }
            else if (h >= 180 && h < 240) { r=0; g=x; b=c; }
            else if (h >= 240 && h < 300) { r=x; g=0; b=c; }
            else { r=c; g=0; b=x; }

            var toHex = function(v) {
                var h = Math.round((v + m) * 255).toString(16);
                return h.length === 1 ? '0' + h : h;
            };
            return '#' + toHex(r) + toHex(g) + toHex(b);
        }

        function normalizeHex(hex) {
            if (!hex) return '';
            hex = hex.trim();
            if (hex.charAt(0) !== '#') hex = '#' + hex;
            return hex;
        }

        function setPalette(hex1, hex2, hex3) {
            $('#ticinoweb_palette_suggested_1').val(hex1);
            $('#ticinoweb_palette_suggested_2').val(hex2);
            $('#ticinoweb_palette_suggested_3').val(hex3);
            $('#palette-swatch-1').css('background', hex1 || 'transparent');
            $('#palette-swatch-2').css('background', hex2 || 'transparent');
            $('#palette-swatch-3').css('background', hex3 || 'transparent');
            if ($.fn.wpColorPicker) {
                $('#ticinoweb_palette_suggested_1').wpColorPicker('color', hex1 || '#ffffff');
                $('#ticinoweb_palette_suggested_2').wpColorPicker('color', hex2 || '#ffffff');
                $('#ticinoweb_palette_suggested_3').wpColorPicker('color', hex3 || '#ffffff');
            }
        }

        function generatePalette() {
            var primary = normalizeHex($('#ticinoweb_palette_primary').val());
            if (!primary || primary.length < 4) return;
            var hsl = hexToHsl(primary);
            // Randomized harmonic variants so each click proposes something new
            var rand = function(min, max) { return min + Math.random() * (max - min); };
            var hueShifts = [rand(20, 55), rand(290, 340), (180 + rand(-15, 15)) % 360];
            var satAdjust = [rand(-0.05, 0.15), rand(-0.08, 0.12), rand(-0.1, 0.1)];
            var lightAdjust = [rand(-0.08, 0.12), rand(-0.06, 0.1), rand(-0.1, 0.1)];

            var hex1 = hslToHex(
                (hsl.h + hueShifts[0]) % 360,
                Math.min(1, Math.max(0, hsl.s + satAdjust[0])),
                Math.min(0.9, Math.max(0.1, hsl.l + lightAdjust[0]))
            );
            var hex2 = hslToHex(
                (hsl.h + hueShifts[1]) % 360,
                Math.min(1, Math.max(0, hsl.s + satAdjust[1])),
                Math.min(0.9, Math.max(0.1, hsl.l + lightAdjust[1]))
            );
            var hex3 = hslToHex(
                hueShifts[2],
                Math.min(1, Math.max(0, hsl.s + satAdjust[2])),
                Math.min(0.9, Math.max(0.1, hsl.l + lightAdjust[2]))
            );
            setPalette(hex1, hex2, hex3);
        }

        $('#generate-palette-btn').on('click', function() {
            generatePalette();
        });

        $('#apply-palette-btn').on('click', function() {
            var p1 = normalizeHex($('#ticinoweb_palette_suggested_1').val());
            var p2 = normalizeHex($('#ticinoweb_palette_suggested_2').val());
            var p3 = normalizeHex($('#ticinoweb_palette_suggested_3').val());
            if (p1) {
                $('#ticinoweb_palette_primary').val(p1);
                if ($.fn.wpColorPicker) {
                    $('#ticinoweb_palette_primary').wpColorPicker('color', p1);
                }
            }
            setPalette(p1, p2, p3);
        });

        // Initialize swatches on load
        setPalette(
            normalizeHex($('#ticinoweb_palette_suggested_1').val()),
            normalizeHex($('#ticinoweb_palette_suggested_2').val()),
            normalizeHex($('#ticinoweb_palette_suggested_3').val())
        );
        
        // SVG Icons Tab - Category filtering + pagination
        var currentCategory = 'all';
        var itemsPerPage = 40;
        var currentOffset = 0;
        var iconsByCategory = window.ticinowebAdminSvgIcons || {};

        $('.svg-cat-tab').on('click', function() {
            var category = $(this).data('category');
            currentCategory = category;

            // Update tab styles
            $('.svg-cat-tab').css({ 'background': '#f0f0f0', 'color': '#333' }).removeClass('active');
            $(this).css({ 'background': '#0073aa', 'color': '#fff' }).addClass('active');

            // Render icons
            renderIcons(true);
        });

        // SVG Icons Tab - Search and Click-to-Copy
        $('#svg-search').on('input', function() {
            renderIcons(true);
        });

        $('#svg-load-more').on('click', function() {
            renderIcons(false);
        });

        function flattenIcons(category) {
            if (category === 'all') {
                var all = [];
                Object.keys(iconsByCategory).forEach(function(cat) {
                    all = all.concat(iconsByCategory[cat]);
                });
                return all;
            }
            return iconsByCategory[category] || [];
        }

        function applySearch(icons, search) {
            if (!search) {
                return icons;
            }
            return icons.filter(function(icon) {
                return (icon.name || '').toLowerCase().indexOf(search) > -1;
            });
        }

        function renderIcons(reset) {
            var $searchEl = $('#svg-search');
            if ($searchEl.length === 0) {
                return;
            }
            var search = $searchEl.val().toLowerCase();
            var icons = applySearch(flattenIcons(currentCategory), search);
            var $grid = $('#svg-icons-grid');

            if (reset) {
                currentOffset = 0;
                $grid.empty();
            }

            var batch = icons.slice(currentOffset, currentOffset + itemsPerPage);

            batch.forEach(function(icon) {
                var item = $('<div/>', {
                    class: 'svg-icon-item',
                    'data-filename': icon.filename,
                    'data-name': icon.name,
                    'data-category': icon.category,
                    'data-url': icon.url,
                    css: {
                        border: '2px solid #ddd',
                        borderRadius: '8px',
                        padding: '10px',
                        cursor: 'pointer',
                        textAlign: 'center',
                        transition: 'all 0.2s',
                        background: '#f9f9f9'
                    }
                });

                var img = $('<img/>', {
                    src: icon.url,
                    alt: icon.name,
                    css: {
                        width: '48px',
                        height: '48px',
                        objectFit: 'contain',
                        margin: '0 auto 8px'
                    }
                }).on('error', function() {
                    $(this).closest('.svg-icon-item').css({ opacity: 0.4 });
                });

                var name = $('<div/>', {
                    text: icon.name,
                    css: {
                        fontSize: '11px',
                        color: '#555',
                        wordBreak: 'break-word',
                        lineHeight: '1.3'
                    }
                });

                var cat = $('<div/>', {
                    text: icon.category,
                    css: {
                        fontSize: '9px',
                        color: '#999',
                        marginTop: '4px'
                    }
                });

                item.append(img, name, cat);
                $grid.append(item);
            });

            currentOffset += batch.length;

            if (currentOffset < icons.length) {
                $('#svg-load-more').show();
            } else {
                $('#svg-load-more').hide();
            }
        }

        // Initial render
        renderIcons(true);

        $(document).on('click', '.svg-icon-item', function() {
            var url = $(this).data('url');
            
            // Copy to clipboard
            var $temp = $('<input>');
            $('body').append($temp);
            $temp.val(url).select();
            document.execCommand('copy');
            $temp.remove();
            
            // Show notice
            $('#svg-copy-notice').fadeIn().delay(2000).fadeOut();
            
            // Highlight selected
            $('.svg-icon-item').css({ 'border-color': '#ddd', 'background': '#f9f9f9' });
            $(this).css({ 'border-color': '#0073aa', 'background': '#e6f2ff' });
        });
        
        $(document).on('mouseenter', '.svg-icon-item', function() {
            if ($(this).css('border-color') !== 'rgb(0, 115, 170)') {
                $(this).css({ 'border-color': '#0073aa', 'transform': 'scale(1.05)' });
            }
        });

        $(document).on('mouseleave', '.svg-icon-item', function() {
            if ($(this).css('background-color') !== 'rgb(230, 242, 255)') {
                $(this).css({ 'border-color': '#ddd', 'transform': 'scale(1)' });
            }
        });

        // Form submissions: open modal with full details
        $(document).on('click', '.view-submission', function(e) {
            e.preventDefault();

            var $row = $(this).closest('.submission-row');
            if (!$row.length) {
                return;
            }

            var data = $row.data();
            var telefono = data.telefono ? data.telefono : '-';
            var message = (data.messaggio || '').toString().replace(/\r\n/g, '\n').replace(/\r/g, '\n');
            var messageHtml = message
                ? message.replace(/\n/g, '<br>')
                : '<em><?php echo esc_js(__('Nessun messaggio', 'ticinoweb-ai-theme')); ?></em>';

            var modalHtml = ''
                + '<p><strong><?php echo esc_js(__('Data', 'ticinoweb-ai-theme')); ?>:</strong> ' + (data.data || '') + '</p>'
                + '<p><strong><?php echo esc_js(__('Nome', 'ticinoweb-ai-theme')); ?>:</strong> ' + (data.nome || '') + '</p>'
                + '<p><strong><?php echo esc_js(__('Email', 'ticinoweb-ai-theme')); ?>:</strong> <a href="mailto:' + (data.email || '') + '">' + (data.email || '') + '</a></p>'
                + '<p><strong><?php echo esc_js(__('Telefono', 'ticinoweb-ai-theme')); ?>:</strong> ' + telefono + '</p>'
                + '<p><strong><?php echo esc_js(__('Oggetto', 'ticinoweb-ai-theme')); ?>:</strong> ' + (data.oggetto || '') + '</p>'
                + '<div><strong><?php echo esc_js(__('Messaggio', 'ticinoweb-ai-theme')); ?>:</strong><br>' + messageHtml + '</div>';

            $('#modal-content').html(modalHtml);
            $('#submission-modal').css('display', 'flex');

            // Mark as read visually
            $row.data('letto', '1');
            $row.find('.submission-status')
                .text('<?php echo esc_js(__('Letto', 'ticinoweb-ai-theme')); ?>')
                .css('background', '#f0f0f0');
        });

        $(document).on('click', '.close-modal', function() {
            $('#submission-modal').hide();
        });

        $('#submission-modal').on('click', function(event) {
            if ($(event.target).is('#submission-modal')) {
                $('#submission-modal').hide();
            }
        });

        // Bulk delete submissions
        var $deleteBtn = $('#delete-selected-submissions');
        var $feedback = $('#submission-delete-feedback');
        var $selectAll = $('#select-all-submissions');

        function updateDeleteState() {
            var checkedCount = $('.submission-checkbox:checked').length;
            $deleteBtn.prop('disabled', checkedCount === 0);
        }

        $(document).on('change', '.submission-checkbox', function() {
            updateDeleteState();
        });

        $selectAll.on('change', function() {
            var isChecked = $(this).is(':checked');
            $('.submission-checkbox').prop('checked', isChecked);
            updateDeleteState();
        });

        $deleteBtn.on('click', function() {
            var ids = $('.submission-checkbox:checked').map(function() { return $(this).val(); }).get();
            if (ids.length === 0) {
                return;
            }

            if (!confirm('<?php echo esc_js(__('Sei sicuro di voler eliminare i messaggi selezionati?', 'ticinoweb-ai-theme')); ?>')) {
                return;
            }

            $deleteBtn.prop('disabled', true).text('<?php echo esc_js(__('Eliminazione...', 'ticinoweb-ai-theme')); ?>');
            $feedback.text('');

            $.post(ajaxurl, {
                action: 'ticinoweb_delete_submissions',
                nonce: deleteNonce,
                ids: ids
            }).done(function(response) {
                $deleteBtn.text('<?php echo esc_js(__('Elimina selezionati', 'ticinoweb-ai-theme')); ?>');

                if (response && response.success) {
                    ids.forEach(function(id) {
                        $('.submission-checkbox[value="' + id + '"]').closest('tr').remove();
                    });
                    $selectAll.prop('checked', false);
                    updateDeleteState();
                    $feedback.css('color', '#2271b1').text('<?php echo esc_js(__('Messaggi eliminati', 'ticinoweb-ai-theme')); ?>');

                    // If no more rows, reload to show the empty state
                    if ($('.submission-row').length === 0) {
                        location.reload();
                    }
                } else {
                    var msg = (response && response.data) ? response.data : '<?php echo esc_js(__('Errore durante l\'eliminazione.', 'ticinoweb-ai-theme')); ?>';
                    $feedback.css('color', '#d63638').text(msg);
                    updateDeleteState();
                }
            }).fail(function() {
                $deleteBtn.text('<?php echo esc_js(__('Elimina selezionati', 'ticinoweb-ai-theme')); ?>');
                $feedback.css('color', '#d63638').text('<?php echo esc_js(__('Errore di rete durante l\'eliminazione.', 'ticinoweb-ai-theme')); ?>');
                updateDeleteState();
            });
        });

        // Documentazione sotto ogni campo (con shortcode per tab)
        function addFieldDoc($field, text) {
            var $container = $field.closest('td');
            if ($container.length === 0) {
                return;
            }
            if ($container.find('.ticinoweb-field-doc').length === 0) {
                $container.append('<p class="description ticinoweb-field-doc">' + text + '</p>');
            }
        }

        var tabDocs = {
            'services': 'Pubblicazione servizi tramite shortcode: <strong>[ticinoweb_services]</strong>.',
            'contatti': 'Contatti usati in header/footer e pagina contatti. Shortcode previsto: <strong>[ticinoweb_contatti]</strong>.',
            'slider': 'Slider pubblicato nella pagina mappata. Shortcode previsto: <strong>[ticinoweb_slider]</strong>.',
            'chi-siamo': 'Sezione pubblicata tramite shortcode: <strong>[ticinoweb_chi_siamo]</strong>.',
            'mappatura': 'Quando selezioni una pagina, il sistema inserisce automaticamente: <strong>[ticinoweb_contatti]</strong>, <strong>[ticinoweb_slider]</strong>, <strong>[ticinoweb_servizi]</strong>, <strong>[ticinoweb_chi_siamo]</strong> e <strong>[ticinoweb_{slug}_archive]</strong>.',
            'recaptcha': 'Protezione form (nessuno shortcode).',
            'smtp': 'Invio email (nessuno shortcode).',
            'theme-images': 'Usate nei template del tema (nessuno shortcode).',
            'custom-fields': 'Archivi CPT pubblicati con: <strong>[ticinoweb_{slug}_archive]</strong>.',
            'svg-icons': 'Usa gli URL delle SVG in Servizi e CPT.'
        };

        Object.keys(tabDocs).forEach(function(tabId) {
            $('#' + tabId)
                .find('input[type="text"], input[type="url"], input[type="email"], input[type="number"], textarea, select')
                .each(function() {
                    addFieldDoc($(this), tabDocs[tabId]);
                });
        });

        var fieldDocs = [
            { selector: '#ticinoweb_contact_email', text: 'Email di ricezione del form contatti. Shortcode: <strong>[ticinoweb_contatti]</strong>.' },
            { selector: '#ticinoweb_contact_email_2', text: 'Seconda email di contatto per ricezione form o riferimenti.' },
            { selector: '#ticinoweb_contact_email_3', text: 'Terza email di contatto per ricezione form o riferimenti.' },
            { selector: '#ticinoweb_contact_phone', text: 'Numero utilizzato per link tel: in header/footer.' },
            { selector: '#ticinoweb_contact_phone_display', text: 'Formato visualizzato (es. +41 79 123 45 67).' },
            { selector: '#ticinoweb_contact_address', text: 'Indirizzo mostrato in footer e pagina contatti.' },
            { selector: '#ticinoweb_contact_facebook', text: 'Link social mostrato nei footer/icon social.' },
            { selector: '#ticinoweb_contact_instagram', text: 'Link social mostrato nei footer/icon social.' },
            { selector: '#ticinoweb_contact_linkedin', text: 'Link social mostrato nei footer/icon social.' },
            { selector: '#ticinoweb_contact_youtube', text: 'Link canale YouTube.' },
            { selector: '#ticinoweb_contact_x', text: 'Link profilo X (Twitter).' },
            { selector: '#ticinoweb_contact_tiktok', text: 'Link profilo TikTok.' },
            { selector: '#ticinoweb_chi_siamo_text', text: 'Testo principale della sezione Chi Siamo. Shortcode: <strong>[ticinoweb_chi_siamo]</strong>.' },
            { selector: '#ticinoweb_chi_siamo_image', text: 'Immagine della sezione Chi Siamo. Shortcode: <strong>[ticinoweb_chi_siamo]</strong>.' },
            { selector: '#ticinoweb_chi_siamo_link', text: 'Link CTA della sezione Chi Siamo.' },
            { selector: '#ticinoweb_slider_count', text: 'Numero di slide mostrate nello slider.' },
            { selector: 'input[name^="ticinoweb_slider_image_"]', text: 'Immagine della slide (consigliato 1920x900). Shortcode: <strong>[ticinoweb_slider]</strong>.' },
            { selector: 'input[name^="ticinoweb_slider_title_"]', text: 'Titolo della slide.' },
            { selector: 'textarea[name^="ticinoweb_slider_desc_"]', text: 'Testo descrittivo della slide.' },
            { selector: 'input[name^="ticinoweb_slider_btn_text_"]', text: 'Testo del bottone della slide.' },
            { selector: 'input[name^="ticinoweb_slider_btn_link_"]', text: 'Link del bottone (URL o ancora).' },
            { selector: '#ticinoweb_page_mapping_contatti', text: 'Inserisce automaticamente lo shortcode <strong>[ticinoweb_contatti]</strong> nella pagina selezionata.' },
            { selector: '#ticinoweb_page_mapping_slider', text: 'Inserisce automaticamente lo shortcode <strong>[ticinoweb_slider]</strong> nella pagina selezionata.' },
            { selector: '#ticinoweb_page_mapping_servizi', text: 'Inserisce automaticamente lo shortcode <strong>[ticinoweb_servizi]</strong> nella pagina selezionata.' },
            { selector: '#ticinoweb_page_mapping_chi_siamo', text: 'Inserisce automaticamente lo shortcode <strong>[ticinoweb_chi_siamo]</strong> nella pagina selezionata.' },
            { selector: '#ticinoweb_recaptcha_site_key', text: 'Chiave pubblica per reCAPTCHA v3 (visibile nel front-end).' },
            { selector: '#ticinoweb_recaptcha_secret_key', text: 'Chiave segreta per reCAPTCHA v3 (solo server).' },
            { selector: '#ticinoweb_recaptcha_threshold', text: 'Soglia di accettazione (0.0–1.0).' },
            { selector: '#ticinoweb_email_method', text: 'Metodo di invio email per i form.' },
            { selector: '#ticinoweb_page_header_overlay_image', text: 'Overlay grafico per header pagine interne.' },
            { selector: '#ticinoweb_page_header_bg_image', text: 'Immagine di sfondo barra superiore pagine interne.' },
            { selector: '#ticinoweb_page_header_bg_color', text: 'Colore di sfondo della barra superiore.' },
            { selector: '#ticinoweb_page_header_bg_gradient_enabled', text: 'Abilita gradiente a due colori per la barra superiore.' },
            { selector: '#ticinoweb_page_header_bg_gradient_color_1', text: 'Colore 1 del gradiente barra superiore.' },
            { selector: '#ticinoweb_page_header_bg_gradient_color_2', text: 'Colore 2 del gradiente barra superiore.' },
            { selector: '#ticinoweb_page_bg_image', text: 'Immagine sfondo pagina (tutte le pagine o una specifica).' },
            { selector: '#ticinoweb_page_bg_scope', text: 'Scegli se applicare lo sfondo a tutte le pagine o a una specifica.' },
            { selector: '#ticinoweb_page_bg_page_id', text: 'Pagina su cui applicare lo sfondo, se usi la modalità specifica.' }
        ];

        fieldDocs.forEach(function(item) {
            $(item.selector).each(function() {
                addFieldDoc($(this), item.text);
            });
        });
        
        // WordPress Media Uploader
        var headerOverlayFrame;
        var headerBgFrame;
        var pageBgFrame;
        var siteLogoFrame;
        var siteIconFrame;

        $('#upload_header_overlay_btn').on('click', function(e) {
            e.preventDefault();
            
            if (headerOverlayFrame) {
                headerOverlayFrame.open();
                return;
            }
            
            headerOverlayFrame = wp.media({
                title: '<?php _e('Seleziona Immagine Overlay', 'ticinoweb-ai-theme'); ?>',
                button: {
                    text: '<?php _e('Usa questa immagine', 'ticinoweb-ai-theme'); ?>'
                },
                multiple: false
            });
            
            headerOverlayFrame.on('select', function() {
                var attachment = headerOverlayFrame.state().get('selection').first().toJSON();
                $('#ticinoweb_page_header_overlay_image').val(attachment.url);
                $('#header-overlay-preview').html('<img src="' + attachment.url + '" style="max-width: 300px; height: auto; border: 1px solid #ddd; border-radius: 4px;">');
            });
            
            headerOverlayFrame.open();
        });

        $('#upload_site_logo_btn').on('click', function(e) {
            e.preventDefault();

            if (siteLogoFrame) {
                siteLogoFrame.open();
                return;
            }

            siteLogoFrame = wp.media({
                title: '<?php _e('Seleziona Logo', 'ticinoweb-ai-theme'); ?>',
                button: { text: '<?php _e('Usa questo logo', 'ticinoweb-ai-theme'); ?>' },
                multiple: false
            });

            siteLogoFrame.on('select', function() {
                var attachment = siteLogoFrame.state().get('selection').first().toJSON();
                $('#ticinoweb_site_logo').val(attachment.url);
                $('#site-logo-preview').html('<img src="' + attachment.url + '" style="max-width: 220px; height: auto; border: 1px solid #ddd; border-radius: 4px;">');
            });

            siteLogoFrame.open();
        });

        $('#upload_site_icon_btn').on('click', function(e) {
            e.preventDefault();

            if (siteIconFrame) {
                siteIconFrame.open();
                return;
            }

            siteIconFrame = wp.media({
                title: '<?php _e('Seleziona Icona', 'ticinoweb-ai-theme'); ?>',
                button: { text: '<?php _e('Usa questa icona', 'ticinoweb-ai-theme'); ?>' },
                multiple: false
            });

            siteIconFrame.on('select', function() {
                var attachment = siteIconFrame.state().get('selection').first().toJSON();
                $('#ticinoweb_site_icon').val(attachment.url);
                $('#site-icon-preview').html('<img src="' + attachment.url + '" style="max-width: 64px; height: auto; border: 1px solid #ddd; border-radius: 4px;">');
            });

            siteIconFrame.open();
        });

        $('#upload_header_bg_btn').on('click', function(e) {
            e.preventDefault();

            if (headerBgFrame) {
                headerBgFrame.open();
                return;
            }

            headerBgFrame = wp.media({
                title: '<?php _e('Seleziona Immagine Sfondo Barra', 'ticinoweb-ai-theme'); ?>',
                button: {
                    text: '<?php _e('Usa questa immagine', 'ticinoweb-ai-theme'); ?>'
                },
                multiple: false
            });

            headerBgFrame.on('select', function() {
                var attachment = headerBgFrame.state().get('selection').first().toJSON();
                $('#ticinoweb_page_header_bg_image').val(attachment.url);
                $('#header-bg-preview').html('<img src="' + attachment.url + '" style="max-width: 300px; height: auto; border: 1px solid #ddd; border-radius: 4px;">');
            });

            headerBgFrame.open();
        });

        $('#upload_page_bg_btn').on('click', function(e) {
            e.preventDefault();

            if (pageBgFrame) {
                pageBgFrame.open();
                return;
            }

            pageBgFrame = wp.media({
                title: '<?php _e('Seleziona Immagine Sfondo Pagina', 'ticinoweb-ai-theme'); ?>',
                button: {
                    text: '<?php _e('Usa questa immagine', 'ticinoweb-ai-theme'); ?>'
                },
                multiple: false
            });

            pageBgFrame.on('select', function() {
                var attachment = pageBgFrame.state().get('selection').first().toJSON();
                $('#ticinoweb_page_bg_image').val(attachment.url);
                $('#page-bg-preview').html('<img src="' + attachment.url + '" style="max-width: 300px; height: auto; border: 1px solid #ddd; border-radius: 4px;">');
            });

            pageBgFrame.open();
        });

        $('#ticinoweb_page_bg_scope').on('change', function() {
            if ($(this).val() === 'specific') {
                $('#page-bg-specific-row').show();
            } else {
                $('#page-bg-specific-row').hide();
            }
        });
    });
    </script>
    

    
    <script>
    jQuery(document).ready(function($) {
        // Tab switching (persistenza tab attivo)
        var tabStorageKey = 'ticinoweb_active_tab';

        function activateTab(target) {
            if (!target || $(target).length === 0) {
                return;
            }
            $('.nav-tab').removeClass('nav-tab-active');
            $('.nav-tab[href="' + target + '"]').addClass('nav-tab-active');

            $('.ticinoweb-tab-content').removeClass('active');
            $(target).addClass('active');

            // Re-init color picker for inputs inside the active tab
            if ($.fn.wpColorPicker) {
                $(target).find('.color-picker').each(function() {
                    if (!$(this).parent().hasClass('wp-picker-container')) {
                        $(this).wpColorPicker();
                    }
                });
            }

            try {
                localStorage.setItem(tabStorageKey, target);
            } catch (e) {}

            if (history.replaceState) {
                history.replaceState(null, null, target);
            } else {
                window.location.hash = target;
            }
        }

        $('.nav-tab').on('click', function(e) {
            e.preventDefault();
            var target = $(this).attr('href');
            activateTab(target);
        });

        // Ripristina tab attivo da hash o localStorage
        var initialTab = window.location.hash;
        if (!initialTab) {
            try {
                initialTab = localStorage.getItem(tabStorageKey);
            } catch (e) {}
        }
        if (!initialTab) {
            initialTab = $('.nav-tab').first().attr('href');
        }
        activateTab(initialTab);

        // Salva tab attivo al submit del form
        $('form').on('submit', function() {
            var activeTab = $('.nav-tab.nav-tab-active').attr('href');
            if (activeTab) {
                try {
                    localStorage.setItem(tabStorageKey, activeTab);
                } catch (e) {}
            }
        });
        
        // Show/hide SMTP settings based on method
        $('#ticinoweb_email_method').on('change', function() {
            var method = $(this).val();
            $('#smtp-standard-settings').hide();
            $('#sendgrid-settings').hide();
            
            if (method === 'smtp') {
                $('#smtp-standard-settings').show();
            } else if (method === 'sendgrid') {
                $('#sendgrid-settings').show();
            }
        });
        
        // Icon preview update
        $('#ticinoweb_post_icon').on('input', function() {
            var iconClass = $(this).val();
            $('#icon-preview .dashicons').attr('class', 'dashicons ' + iconClass);
        });
        
        // Test email
        $('#send-test-email').on('click', function() {
            var btn = $(this);
            var email = $('#test_email_address').val();
            var result = $('#test-email-result');

            if (!email) {
                result.html('<div class="notice notice-error"><p>Inserisci un indirizzo email valido.</p></div>');
                return;
            }

            btn.prop('disabled', true).text('Invio in corso...');
            result.html('<div class="notice notice-info"><p>Invio email di test in corso...</p></div>');

            $.post(ajaxurl, {
                action: 'ticinoweb_test_email',
                email: email,
                nonce: '<?php echo wp_create_nonce('ticinoweb_test_email'); ?>'
            }, function(response) {
                btn.prop('disabled', false).text('Invia Test');

                if (response.success) {
                    var d = response.data;
                    var html = '<div class="notice notice-success"><p><strong>✓ ' + d.message + '</strong></p></div>';

                    // Show sender/domain verification warnings if present
                    if (d.warnings && d.warnings.length) {
                        html += '<div class="notice notice-warning"><ul style="margin:4px 0 4px 16px;">';
                        $.each(d.warnings, function(i, w) { html += '<li>' + w + '</li>'; });
                        html += '</ul></div>';
                    }

                    // Show preflight details if present
                    if (d.preflight) {
                        var p = d.preflight;
                        var rows = [
                            ['API Key', p.api_key_valid ? '✅ Valida' : '❌ Non valida o senza permessi'],
                            ['Sender verificato', p.sender_verified ? '✅ Sì' : '⚠️ No (potrebbe causare mancate consegne)'],
                            ['Dominio autenticato', p.domain_authenticated ? '✅ Sì' : '⚠️ No — aggiungi i record DNS SendGrid']
                        ];
                        html += '<div style="margin-top:8px;font-size:12px;color:#555;"><strong>Stato SendGrid:</strong><br>';
                        $.each(rows, function(i, r) { html += r[0] + ': ' + r[1] + '<br>'; });
                        html += '</div>';
                    }

                    result.html(html);
                } else {
                    var errHtml = (response.data + '').replace(/\n/g, '<br>');
                    result.html('<div class="notice notice-error"><p><strong>✗ Errore:</strong><br>' + errHtml + '</p></div>');
                }
            }).fail(function(xhr) {
                btn.prop('disabled', false).text('Invia Test');
                result.html('<div class="notice notice-error"><p><strong>✗ Errore di rete:</strong> ' + xhr.statusText + '</p></div>');
            });
        });

        // Verify SendGrid API (no actual send)
        $('#check-sendgrid-api').on('click', function() {
            var btn = $(this);
            var result = $('#test-email-result');
            btn.prop('disabled', true).text('Verifica...');
            result.html('<div class="notice notice-info"><p>Contatto API SendGrid in corso...</p></div>');

            $.post(ajaxurl, {
                action: 'ticinoweb_check_sendgrid_api',
                nonce: '<?php echo wp_create_nonce('ticinoweb_check_sendgrid_api'); ?>'
            }, function(response) {
                btn.prop('disabled', false).text('Verifica API SendGrid');
                if (response.success) {
                    var p = response.data;
                    var html = '<div class="notice notice-' + (p.api_key_valid ? 'success' : 'error') + '"><p><strong>Stato API SendGrid</strong></p>';
                    html += '<ul style="margin:4px 0 4px 16px;">';
                    html += '<li>API Key: ' + (p.api_key_valid ? '✅ Valida' : '❌ Non valida o senza permessi') + '</li>';
                    html += '<li>Sender verificato (' + p.from_email + '): ' + (p.sender_verified ? '✅ Sì' : '⚠️ No') + '</li>';
                    html += '<li>Dominio autenticato (' + p.from_domain + '): ' + (p.domain_authenticated ? '✅ Sì' : '⚠️ No — aggiungi i record DNS SendGrid') + '</li>';
                    html += '</ul>';
                    if (!p.sender_verified && !p.domain_authenticated) {
                        html += '<p style="color:#b45309;">⚠️ Né il sender né il dominio sono verificati. Le email potrebbero essere accettate da SendGrid (HTTP 202) ma non consegnate. Configura il dominio su <a href="https://app.sendgrid.com/settings/sender_auth" target="_blank">SendGrid Sender Authentication</a>.</p>';
                    }
                    html += '</div>';
                    result.html(html);
                } else {
                    result.html('<div class="notice notice-error"><p><strong>✗ Errore:</strong> ' + response.data + '</p></div>');
                }
            }).fail(function(xhr) {
                btn.prop('disabled', false).text('Verifica API SendGrid');
                result.html('<div class="notice notice-error"><p><strong>✗ Errore di rete:</strong> ' + xhr.statusText + '</p></div>');
            });
        });

        // SMTP port/encryption mismatch detector
        var smtpPortMap = { 'tls': 587, 'ssl': 465, '': 25 };
        function smtpCheckMismatch() {
            var enc      = $('#ticinoweb_smtp_encryption').val();
            var port     = parseInt($('#ticinoweb_smtp_port').val()) || 0;
            var expected = smtpPortMap[enc];
            if (expected && port && port !== expected) {
                var encLabel = enc === 'ssl' ? 'SSL' : (enc === 'tls' ? 'TLS (STARTTLS)' : 'Nessuna');
                $('#smtp-port-mismatch-msg').text(encLabel + ' usa porta ' + expected + ', ma hai impostato ' + port + '.');
                $('#smtp-fix-port').data('fix-to', expected);
                $('#smtp-port-mismatch-warn').slideDown(200);
            } else {
                $('#smtp-port-mismatch-warn').slideUp(200);
            }
        }
        $('#ticinoweb_smtp_encryption, #ticinoweb_smtp_port').on('change input', smtpCheckMismatch);
        $('#smtp-fix-port').on('click', function() {
            $('#ticinoweb_smtp_port').val($(this).data('fix-to'));
            smtpCheckMismatch();
        });
        smtpCheckMismatch(); // check mismatch on page load

        // Slider Management - Dynamic reindexing, move up/down and drag & drop
        function reindexSlides() {
            var $items = $('#slider-items-container .slider-item');
            var count = parseInt($('#ticinoweb_slider_count').val()) || 3;
            count = Math.max(1, Math.min(5, count));

            $items.each(function(idx) {
                var num = idx + 1; // 1-based index
                var $item = $(this);
                $item.attr('data-slide', num);
                $item.find('.slider-item-number').text('Slide ' + num);

                // Update accordion aria-controls & body id
                $item.find('.slider-accordion-toggle').attr('aria-controls', 'slider-item-body-' + num);
                $item.find('.slider-item-body').attr('id', 'slider-item-body-' + num);

                // Update input & textarea names
                $item.find('.slider-image-url').attr('name', 'ticinoweb_slider_image_' + num);
                $item.find('.slider-title-input').attr('name', 'ticinoweb_slider_title_' + num);
                $item.find('textarea[name^="ticinoweb_slider_desc_"]').attr('name', 'ticinoweb_slider_desc_' + num);
                $item.find('input[name^="ticinoweb_slider_btn_text_"]').attr('name', 'ticinoweb_slider_btn_text_' + num);
                $item.find('input[name^="ticinoweb_slider_btn_link_"]').attr('name', 'ticinoweb_slider_btn_link_' + num);

                // Update move buttons disabled state
                $item.find('.slider-move-up').prop('disabled', idx === 0);
                $item.find('.slider-move-down').prop('disabled', idx === count - 1 || idx === $items.length - 1);

                // Show/hide based on count
                if (num <= count) {
                    $item.show();
                } else {
                    $item.hide();
                }
            });
        }

        $('#ticinoweb_slider_count').on('change keyup', function() {
            reindexSlides();
        });

        // Move slide up
        $(document).on('click', '.slider-move-up', function(e) {
            e.preventDefault();
            e.stopPropagation();
            var $item = $(this).closest('.slider-item');
            var $prev = $item.prev('.slider-item');
            if ($prev.length) {
                $item.insertBefore($prev);
                reindexSlides();
            }
        });

        // Move slide down
        $(document).on('click', '.slider-move-down', function(e) {
            e.preventDefault();
            e.stopPropagation();
            var $item = $(this).closest('.slider-item');
            var $next = $item.next('.slider-item');
            if ($next.length) {
                $item.insertAfter($next);
                reindexSlides();
            }
        });

        // Initialize Sortable on slider items container
        if ($('#slider-items-container').length && $.fn.sortable) {
            $('#slider-items-container').sortable({
                items: '> .slider-item',
                handle: '.slider-drag-handle',
                placeholder: 'slider-sortable-placeholder',
                forcePlaceholderSize: true,
                tolerance: 'pointer',
                cursor: 'grabbing',
                opacity: 0.85,
                start: function(e, ui) {
                    ui.placeholder.css({
                        height: ui.item.outerHeight(),
                        background: '#f8fafc',
                        border: '2px dashed #cbd5e1',
                        borderRadius: '6px',
                        marginBottom: '16px',
                        visibility: 'visible'
                    });
                },
                stop: function() {
                    reindexSlides();
                }
            });
        }

        // Initialize slide button states
        reindexSlides();

        // Slider accordion
        const setAccordionIcon = function($btn) {
            var expanded = $btn.attr('aria-expanded') === 'true';
            $btn.find('.dashicons').toggleClass('dashicons-arrow-down', !expanded);
            $btn.find('.dashicons').toggleClass('dashicons-arrow-up', expanded);
        };

        $('.slider-accordion-toggle').each(function() { setAccordionIcon($(this)); });

        const toggleSliderItem = function($item) {
            var $btn = $item.find('.slider-accordion-toggle');
            var expanded = $btn.attr('aria-expanded') === 'true';
            $item.find('.slider-item-body').slideToggle(150);
            $btn.attr('aria-expanded', expanded ? 'false' : 'true');
            setAccordionIcon($btn);
        };

        $(document).on('click', '.slider-accordion-toggle', function(e) {
            e.preventDefault();
            toggleSliderItem($(this).closest('.slider-item'));
        });

        $(document).on('click', '.slider-item-header', function(e) {
            if ($(e.target).closest('.slider-accordion-toggle, .slider-move-up, .slider-move-down, .slider-drag-handle').length) {
                return;
            }
            toggleSliderItem($(this).closest('.slider-item'));
        });

        // Keep slider title preview in sync
        $(document).on('input', '.slider-title-input', function() {
            var value = $(this).val().trim();
            var text = value !== '' ? value : '<?php echo esc_js(__('(nessun titolo)', 'ticinoweb-ai-theme')); ?>';
            $(this).closest('.slider-item').find('.slider-title-preview').text(text);
        });

        // Partner Management - Show/hide partners based on count
        $('#ticinoweb_partner_count').on('change keyup', function() {
            var count = parseInt($(this).val()) || 3;
            count = Math.max(3, Math.min(24, count)); // Clamp to 3-24
            $('.partner-item').each(function() {
                var partner = parseInt($(this).data('partner'));
                $(this).show();
                if (partner > count) {
                    $(this).hide();
                }
            });
        });

        const setPartnerIcon = function($btn) {
            var expanded = $btn.attr('aria-expanded') === 'true';
            $btn.find('.dashicons').toggleClass('dashicons-arrow-down', !expanded);
            $btn.find('.dashicons').toggleClass('dashicons-arrow-up', expanded);
        };

        $('.partner-accordion-toggle').each(function() { setPartnerIcon($(this)); });

        const togglePartnerItem = function($item) {
            var $btn = $item.find('.partner-accordion-toggle');
            var expanded = $btn.attr('aria-expanded') === 'true';
            $item.find('.partner-item-body').slideToggle(150);
            $btn.attr('aria-expanded', expanded ? 'false' : 'true');
            setPartnerIcon($btn);
        };

        $(document).on('click', '.partner-accordion-toggle', function(e) {
            e.preventDefault();
            togglePartnerItem($(this).closest('.partner-item'));
        });

        $(document).on('click', '.partner-item-header', function(e) {
            if ($(e.target).closest('.partner-accordion-toggle').length) {
                return;
            }
            togglePartnerItem($(this).closest('.partner-item'));
        });

        // Partner logo upload
        $(document).on('click', '.upload-partner-logo', function(e) {
            e.preventDefault();
            var button = $(this);
            var inputField = button.siblings('.partner-logo-url');
            var previewDiv = button.siblings('.partner-logo-preview');
            var frame = wp.media({
                title: '<?php _e('Seleziona Logo Partner', 'ticinoweb-ai-theme'); ?>',
                button: { text: '<?php _e('Usa questo logo', 'ticinoweb-ai-theme'); ?>' },
                multiple: false
            });
            frame.on('select', function() {
                var attachment = frame.state().get('selection').first().toJSON();
                inputField.val(attachment.url);
                previewDiv.html('<img src="' + attachment.url + '" style="max-width: 200px; height: auto; border: 1px solid #ddd; border-radius: 4px;">');
            });
            frame.open();
        });
        
        // Slider image upload
        $(document).on('click', '.upload-slider-image', function(e) {
            e.preventDefault();
            
            var button = $(this);
            var inputField = button.siblings('.slider-image-url');
            var previewDiv = button.siblings('.slider-image-preview');
            
            var frame = wp.media({
                title: '<?php _e('Seleziona Immagine Slide', 'ticinoweb-ai-theme'); ?>',
                button: {
                    text: '<?php _e('Usa questa immagine', 'ticinoweb-ai-theme'); ?>'
                },
                multiple: false
            });
            
            frame.on('select', function() {
                var attachment = frame.state().get('selection').first().toJSON();
                inputField.val(attachment.url);
                previewDiv.html('<img src="' + attachment.url + '" style="max-width: 300px; height: auto; border: 1px solid #ddd; border-radius: 4px;">');
            });
            
            frame.open();
        });
        
        // CPT Management
        var cptIndex = $('.cpt-item').length;
        
        $('#add-cpt-btn').on('click', function() {
            var newCpt = `
            <div class="cpt-item" data-index="${cptIndex}" style="background: #fff; border: 1px solid #ccd0d4; border-radius: 4px; padding: 20px; margin-bottom: 20px; position: relative;">
                <button type="button" class="button button-link-delete remove-cpt" style="position: absolute; top: 10px; right: 10px; color: #b32d2e; text-decoration: none;">
                    <span class="dashicons dashicons-trash"></span> <?php _e('Rimuovi', 'ticinoweb-ai-theme'); ?>
                </button>
                
                <h3 style="margin-top: 0;"><?php _e('Nuovo Post Type', 'ticinoweb-ai-theme'); ?> #${cptIndex + 1}</h3>
                
                <table class="form-table">
                    <tr>
                        <th scope="row"><label><?php _e('Slug (Chiave Univoca)', 'ticinoweb-ai-theme'); ?></label></th>
                        <td>
                            <input type="text" name="ticinoweb_custom_post_types[${cptIndex}][slug]" class="regular-text" placeholder="es. servizi">
                            <p class="description"><?php _e('Minuscolo, niente spazi (usa trattini). Esempio: "servizi", "membri-team"', 'ticinoweb-ai-theme'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label><?php _e('Nome Singolare', 'ticinoweb-ai-theme'); ?></label></th>
                        <td>
                            <input type="text" name="ticinoweb_custom_post_types[${cptIndex}][singular]" class="regular-text" placeholder="Servizio">
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label><?php _e('Nome Plurale', 'ticinoweb-ai-theme'); ?></label></th>
                        <td>
                            <input type="text" name="ticinoweb_custom_post_types[${cptIndex}][plural]" class="regular-text" placeholder="Servizi">
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label><?php _e('Tipo Icona', 'ticinoweb-ai-theme'); ?></label></th>
                        <td>
                            <label style="margin-right: 15px;">
                                <input type="radio" name="ticinoweb_custom_post_types[${cptIndex}][icon_type]" value="dashicon" class="cpt-icon-type-selector" checked> 
                                Dashicon
                            </label>
                            <label>
                                <input type="radio" name="ticinoweb_custom_post_types[${cptIndex}][icon_type]" value="svg" class="cpt-icon-type-selector"> 
                                SVG Custom
                            </label>
                        </td>
                    </tr>
                    <tr class="cpt-dashicon-row">
                        <th scope="row"><label><?php _e('Icona (Dashicon)', 'ticinoweb-ai-theme'); ?></label></th>
                        <td>
                            <input type="text" name="ticinoweb_custom_post_types[${cptIndex}][icon]" value="dashicons-admin-post" class="regular-text cpt-icon-input" placeholder="dashicons-admin-post">
                            <span class="dashicons dashicons-admin-post cpt-icon-preview" style="font-size: 20px; margin-left:10px; vertical-align:middle;"></span>
                            <p class="description"><a href="https://developer.wordpress.org/resource/dashicons/" target="_blank">Lista Dashicons</a></p>
                        </td>
                    </tr>
                    <tr class="cpt-svg-row" style="display:none;">
                        <th scope="row"><label><?php _e('Icona SVG URL', 'ticinoweb-ai-theme'); ?></label></th>
                        <td>
                            <input type="text" name="ticinoweb_custom_post_types[${cptIndex}][icon_svg]" value="" class="regular-text cpt-svg-input" placeholder="https://...">
                            <button type="button" class="button button-secondary upload-cpt-svg"><?php _e('Carica SVG', 'ticinoweb-ai-theme'); ?></button>
                            <div class="cpt-svg-preview" style="margin-top: 10px; width: 32px; height: 32px; border: 1px dashed #ccc; display: flex; align-items: center; justify-content: center;"></div>
                            <p class="description"><?php _e('Puoi copiare un URL dalla tab "Libreria Icone SVG".', 'ticinoweb-ai-theme'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label><?php _e('Opzioni', 'ticinoweb-ai-theme'); ?></label></th>
                        <td>
                            <label style="margin-right: 15px;">
                                <input type="checkbox" name="ticinoweb_custom_post_types[${cptIndex}][public]" value="1" checked> 
                                <?php _e('Pubblico (visibile sul sito)', 'ticinoweb-ai-theme'); ?>
                            </label>
                            <label>
                                <input type="checkbox" name="ticinoweb_custom_post_types[${cptIndex}][has_archive]" value="1" checked> 
                                <?php _e('Abilita Archivio', 'ticinoweb-ai-theme'); ?>
                            </label>
                        </td>
                    </tr>
                </table>
            </div>
            `;
            
            $('#cpt-container').append(newCpt);
            cptIndex++;
        });
        
        // Remove CPT
        $(document).on('click', '.remove-cpt', function() {
            if (confirm('<?php _e('Sei sicuro di voler rimuovere questo Post Type?', 'ticinoweb-ai-theme'); ?>')) {
                $(this).closest('.cpt-item').remove();
            }
        });

        // CPT icon preview
        $(document).on('input', '.cpt-icon-input', function() {
            var iconClass = $(this).val();
            var $preview = $(this).siblings('.cpt-icon-preview');
            $preview.attr('class', 'dashicons cpt-icon-preview ' + iconClass);
        });

        // CPT Icon Type Switcher
        $(document).on('change', '.cpt-icon-type-selector', function() {
            var $container = $(this).closest('td');
            var type = $(this).val();
            var $row = $(this).closest('tr');
            
            if (type === 'dashicon') {
                $row.siblings('.cpt-dashicon-row').show();
                $row.siblings('.cpt-svg-row').hide();
            } else {
                $row.siblings('.cpt-dashicon-row').hide();
                $row.siblings('.cpt-svg-row').show();
            }
        });

        // CPT SVG Preview
        $(document).on('input change', '.cpt-svg-input', function() {
            var url = $(this).val();
            var $preview = $(this).siblings('.cpt-svg-preview');
            if (url) {
                $preview.html('<img src="' + url + '" style="max-width: 100%; max-height: 100%;">');
            } else {
                $preview.empty();
            }
        });

        // CPT SVG Upload
        $(document).on('click', '.upload-cpt-svg', function(e) {
            e.preventDefault();
            var $button = $(this);
            var $input = $button.siblings('.cpt-svg-input');
            var $preview = $button.siblings('.cpt-svg-preview');
            
            var custom_uploader = wp.media({
                title: '<?php _e('Seleziona Icona SVG', 'ticinoweb-ai-theme'); ?>',
                button: {
                    text: '<?php _e('Usa questa icona', 'ticinoweb-ai-theme'); ?>'
                },
                multiple: false,
                library: {
                    type: 'image/svg+xml' // Filter for SVG
                }
            }).on('select', function() {
                var attachment = custom_uploader.state().get('selection').first().toJSON();
                var url = attachment.url;
                $input.val(url).trigger('change');
            }).open();
        });

        // Services Management
        var serviceIndex = $('.service-item').length;

        function setServiceAccordionState($item, expanded) {
            var $fields = $item.find('.service-fields');
            var $toggle = $item.find('.service-toggle');
            var $icon = $toggle.find('.service-toggle-icon');

            if (expanded) {
                $fields.slideDown(150);
                $toggle.attr('aria-expanded', 'true');
                $icon.removeClass('dashicons-arrow-right-alt2').addClass('dashicons-arrow-down-alt2');
            } else {
                $fields.slideUp(150);
                $toggle.attr('aria-expanded', 'false');
                $icon.removeClass('dashicons-arrow-down-alt2').addClass('dashicons-arrow-right-alt2');
            }
        }

        // Collapse all on load
        $('.service-item').each(function() {
            setServiceAccordionState($(this), false);
        });

        // Toggle accordion
        $(document).on('click', '.service-toggle', function(e) {
            e.preventDefault();
            var $item = $(this).closest('.service-item');
            var isExpanded = $(this).attr('aria-expanded') === 'true';
            setServiceAccordionState($item, !isExpanded);
        });

        // Keep title preview in sync
        $(document).on('input', '.service-title-input', function() {
            var value = $(this).val().trim();
            var text = value !== '' ? value : '<?php echo esc_js(__('(nessun titolo)', 'ticinoweb-ai-theme')); ?>';
            $(this).closest('.service-item').find('.service-title-preview').text(text);
        });

        // Add new service
        $('#add-service').on('click', function() {
            var newServiceId = 'srv_' + Math.random().toString(36).substring(2, 10);
            var newService = `
            <div class="service-item" data-index="${serviceIndex}" style="background: #fff; border: 1px solid #ccd0d4; border-radius: 4px; padding: 16px; margin-bottom: 16px; position: relative;">
                <input type="hidden" name="ticinoweb_services[${serviceIndex}][id]" value="${newServiceId}">
                <div class="service-header" style="display: flex; align-items: center; gap: 8px;">
                    <button type="button" class="button-link service-toggle" aria-expanded="false" style="display: inline-flex; align-items: center; gap: 6px; text-decoration: none; padding: 4px 0;">
                        <span class="dashicons dashicons-arrow-right-alt2 service-toggle-icon"></span>
                        <strong><?php _e('Servizio', 'ticinoweb-ai-theme'); ?> #${serviceIndex + 1}</strong>
                        <span class="service-title-preview" style="color: #555;"><?php _e('(nessun titolo)', 'ticinoweb-ai-theme'); ?></span>
                    </button>
                    <button type="button" class="button button-link-delete remove-service" style="margin-left: auto; color: #b32d2e; text-decoration: none;">
                        <span class="dashicons dashicons-trash"></span> <?php _e('Rimuovi', 'ticinoweb-ai-theme'); ?>
                    </button>
                </div>

                <div class="service-fields" style="display: none; margin-top: 12px;">
                    <table class="form-table">
                        <tr>
                            <th scope="row" style="width: 180px;">
                                <label><?php _e('Tipo Icona', 'ticinoweb-ai-theme'); ?></label>
                            </th>
                            <td>
                                <label style="display: inline-block; margin-right: 20px;">
                                    <input type="radio" name="ticinoweb_services[${serviceIndex}][icon_type]" value="dashicon" 
                                           class="service-icon-type-radio" checked>
                                    <?php _e('Dashicon', 'ticinoweb-ai-theme'); ?>
                                </label>
                                <label style="display: inline-block;">
                                    <input type="radio" name="ticinoweb_services[${serviceIndex}][icon_type]" value="svg" 
                                           class="service-icon-type-radio">
                                    <?php _e('Icona SVG Personalizzata', 'ticinoweb-ai-theme'); ?>
                                </label>
                            </td>
                        </tr>
                        <tr class="icon-dashicon-row">
                            <th scope="row">
                                <label><?php _e('Icona Dashicon', 'ticinoweb-ai-theme'); ?></label>
                            </th>
                            <td>
                                <input type="text" name="ticinoweb_services[${serviceIndex}][icon]" 
                                       value="dashicons-admin-tools" 
                                       class="regular-text service-icon-input" 
                                       placeholder="dashicons-admin-tools">
                                <div class="service-icon-preview" style="display: inline-block; margin-left: 10px; width: 32px; height: 32px;">
                                    <span class="dashicons dashicons-admin-tools" style="font-size: 32px; width: 32px; height: 32px;"></span>
                                </div>
                                <p class="description"><?php _e('Esempio: dashicons-admin-tools, dashicons-hammer, dashicons-shield.', 'ticinoweb-ai-theme'); ?></p>
                            </td>
                        </tr>
                        <tr class="icon-svg-row" style="display: none;">
                            <th scope="row">
                                <label><?php _e('Icona SVG', 'ticinoweb-ai-theme'); ?></label>
                            </th>
                            <td>
                                <input type="text" name="ticinoweb_services[${serviceIndex}][icon_svg]" 
                                       value="" 
                                       class="regular-text service-svg-url" placeholder="https://example.com/icon.svg">
                                <button type="button" class="button button-secondary upload-service-svg"><?php _e('Carica SVG', 'ticinoweb-ai-theme'); ?></button>
                                <div class="service-svg-preview" style="margin-top: 10px;"></div>
                                <p class="description"><?php _e('Carica un\'icona SVG personalizzata (preferibilmente 64x64px).', 'ticinoweb-ai-theme'); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <label><?php _e('Immagine Servizio', 'ticinoweb-ai-theme'); ?></label>
                            </th>
                            <td>
                                <input type="text" name="ticinoweb_services[${serviceIndex}][image]" 
                                       value="" 
                                       class="regular-text service-image-url" placeholder="https://example.com/servizio.jpg">
                                <button type="button" class="button button-secondary upload-service-image"><?php _e('Carica Immagine', 'ticinoweb-ai-theme'); ?></button>
                                <div class="service-image-preview" style="margin-top: 10px;"></div>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <label><?php _e('Titolo Servizio', 'ticinoweb-ai-theme'); ?></label>
                            </th>
                            <td>
                                <input type="text" name="ticinoweb_services[${serviceIndex}][title]" 
                                       value="" 
                                       class="regular-text service-title-input" placeholder="<?php _e('Es: Potatura Alberi', 'ticinoweb-ai-theme'); ?>">
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <label><?php _e('Descrizione', 'ticinoweb-ai-theme'); ?></label>
                            </th>
                            <td>
                                <textarea name="ticinoweb_services[${serviceIndex}][description]" 
                                          rows="4" class="large-text" placeholder="<?php _e('Descrizione breve del servizio...', 'ticinoweb-ai-theme'); ?>"></textarea>
                            </td>
                        </tr>
                    </table>
                </div>
            </div>
            `;
            
            $('#services-container').append(newService);
            var $newItem = $('#services-container .service-item').last();
            setServiceAccordionState($newItem, true);
            serviceIndex++;
        });
        
        // Remove service - Double-click confirmation to avoid browser blocking
        $(document).on('click', '.remove-service', function() {
            var $btn = $(this);
            var $item = $btn.closest('.service-item');
            
            // Check if already in confirmation state
            if ($btn.hasClass('confirm-delete')) {
                // Second click - actually remove
                $item.fadeOut(200, function() {
                    $(this).remove();
                });
            } else {
                // First click - ask for confirmation
                var originalHtml = $btn.html();
                $btn.addClass('confirm-delete')
                    .html('<span class="dashicons dashicons-warning"></span> <?php _e('Clicca ancora per confermare', 'ticinoweb-ai-theme'); ?>')
                    .css({
                        'background-color': '#dc3232',
                        'color': '#fff',
                        'padding': '4px 8px',
                        'border-radius': '3px'
                    });
                
                // Reset after 3 seconds if not clicked again
                setTimeout(function() {
                    if ($btn.hasClass('confirm-delete')) {
                        $btn.removeClass('confirm-delete')
                            .html(originalHtml)
                            .css({
                                'background-color': '',
                                'color': '#b32d2e',
                                'padding': '',
                                'border-radius': ''
                            });
                    }
                }, 3000);
            }
        });
        
        // Service icon preview
        $(document).on('input', '.service-icon-input', function() {
            var iconClass = $(this).val();
            $(this).closest('td').find('.service-icon-preview .dashicons').attr('class', 'dashicons ' + iconClass);
        });
        
        // Service image uploader
        $(document).on('click', '.upload-service-image', function(e) {
            e.preventDefault();
            
            var button = $(this);
            var inputField = button.prev('.service-image-url');
            var previewDiv = button.next('.service-image-preview');
            
            var frame = wp.media({
                title: '<?php _e('Seleziona Immagine Servizio', 'ticinoweb-ai-theme'); ?>',
                button: {
                    text: '<?php _e('Usa questa immagine', 'ticinoweb-ai-theme'); ?>'
                },
                multiple: false
            });
            
            frame.on('select', function() {
                var attachment = frame.state().get('selection').first().toJSON();
                inputField.val(attachment.url);
                previewDiv.html('<img src="' + attachment.url + '" style="max-width: 200px; height: auto; border: 1px solid #ddd; border-radius: 4px;">');
            });
            
            frame.open();
        });
        
        // Icon type toggle (dashicon vs SVG)
        $(document).on('change', '.service-icon-type-radio', function() {
            var container = $(this).closest('.service-item');
            var iconType = $(this).val();
            
            if (iconType === 'dashicon') {
                container.find('.icon-dashicon-row').show();
                container.find('.icon-svg-row').hide();
            } else {
                container.find('.icon-dashicon-row').hide();
                container.find('.icon-svg-row').show();
            }
        });
        
        // SVG uploader
        $(document).on('click', '.upload-service-svg', function(e) {
            e.preventDefault();
            
            var button = $(this);
            var inputField = button.prev('.service-svg-url');
            var previewDiv = button.next('.service-svg-preview');
            
            var frame = wp.media({
                title: '<?php _e('Seleziona Icona SVG', 'ticinoweb-ai-theme'); ?>',
                button: {
                    text: '<?php _e('Usa questa icona', 'ticinoweb-ai-theme'); ?>'
                },
                library: {
                    type: 'image/svg+xml'
                },
                multiple: false
            });
            
            frame.on('select', function() {
                var attachment = frame.state().get('selection').first().toJSON();
                inputField.val(attachment.url);
                previewDiv.html('<img src="' + attachment.url + '" style="max-width: 64px; height: auto; border: 1px solid #ddd; border-radius: 4px;">');
            });
            
            frame.open();
        });

        // ==========================================
        // GESTIONE TABELLA ORARI DI APERTURA & GOOGLE SYNC
        // ==========================================
        console.log("ticinoWEB CMS: Orari di Apertura JS inizializzato.");

        // Toggle "24 ore": mutually exclusive with "Chiuso", and hides the slot
        // rows because a 24-hour day has no opening/closing time to enter.
        $(document).on('change', '.day-24h-toggle', function() {
            var $row = $(this).closest('.day-row');
            var isChecked = $(this).is(':checked');

            if (isChecked) {
                $row.find('.day-closed-toggle').prop('checked', false);
                $row.find('.slots-container').slideUp(200).find('input[type="time"]').val('');
                $row.find('.add-slot-container').slideUp(200);
            } else {
                $row.find('.slots-container').slideDown(200);
                $row.find('.add-slot-container').slideDown(200);
            }
        });

        // Toggle checkbox "Chiuso"
        $(document).on('change', '.day-closed-toggle', function() {
            var $row = $(this).closest('.day-row');
            var isChecked = $(this).is(':checked');
            var $slotsContainer = $row.find('.slots-container');
            var $addContainer = $row.find('.add-slot-container');
            
            console.log("Toggle Chiuso cambiato per day:", $row.data('day'), "Stato chiuso:", isChecked);

            if (isChecked) {
                $row.find('.day-24h-toggle').prop('checked', false);
            }

            if (isChecked) {
                $slotsContainer.slideUp(200);
                $addContainer.slideUp(200);
                $slotsContainer.find('input[type="time"]').val('');
            } else {
                $slotsContainer.slideDown(200);
                $addContainer.slideDown(200);
                if ($slotsContainer.find('.slot-row').length === 0) {
                    addSlotRow($row);
                }
            }
        });
        
        // Aggiungi fascia oraria (+)
        $(document).on('click', '.add-slot-btn', function() {
            var $row = $(this).closest('.day-row');
            console.log("Aggiunta fascia oraria per day:", $row.data('day'));
            addSlotRow($row);
        });
        
        // Rimuovi fascia oraria (x)
        $(document).on('click', '.remove-slot-btn', function() {
            var $row = $(this).closest('.day-row');
            console.log("Rimozione fascia oraria per day:", $row.data('day'));
            $(this).closest('.slot-row').remove();
            reindexSlots($row);
        });
        
        function addSlotRow($row, openVal, closeVal) {
            openVal = openVal || '';
            closeVal = closeVal || '';
            var dayKey = $row.data('day');
            var $container = $row.find('.slots-container');
            var nextIndex = $container.find('.slot-row').length;
            
            var html = '<div class="slot-row" style="display:flex; align-items:center; gap:8px; margin-bottom:8px; opacity:0;">' +
                '<div class="time-input-group" style="position:relative; display:inline-block;">' +
                    '<input type="time" name="ticinoweb_contact_opening_hours[' + dayKey + '][slots][' + nextIndex + '][open]" value="' + openVal + '" style="padding:4px 8px; border:1px solid #ccc; border-radius:4px;">' +
                    '<span style="font-size:11px; color:#888; display:block;">Apertura</span>' +
                '</div>' +
                '<span style="color:#666;">&mdash;</span>' +
                '<div class="time-input-group" style="position:relative; display:inline-block;">' +
                    '<input type="time" name="ticinoweb_contact_opening_hours[' + dayKey + '][slots][' + nextIndex + '][close]" value="' + closeVal + '" style="padding:4px 8px; border:1px solid #ccc; border-radius:4px;">' +
                    '<span style="font-size:11px; color:#888; display:block;">Chiusura</span>' +
                '</div>' +
                '<button type="button" class="button remove-slot-btn" style="min-width:auto; padding:0 8px; color:#dc2626; border-color:#fca5a5; background:#fef2f2; margin-bottom:14px;" title="Rimuovi fascia">&times;</button>' +
            '</div>';
            
            var $newRow = $(html);
            $container.append($newRow);
            $newRow.animate({ opacity: 1 }, 200);
        }
        
        // Copia gli orari di un giorno nel giorno successivo
        $(document).on('click', '.copy-day-btn', function() {
            var $sourceRow = $(this).closest('.day-row');
            var $targetRow = $sourceRow.nextAll('.day-row').first();
            if (!$targetRow.length) {
                return;
            }
            console.log("Copia orari da:", $sourceRow.data('day'), "a:", $targetRow.data('day'));

            // Un giorno aperto 24 ore non ha fasce da raccogliere: si copia il flag.
            if ($sourceRow.find('.day-24h-toggle').is(':checked')) {
                $targetRow.find('.day-closed-toggle').prop('checked', false);
                $targetRow.find('.day-24h-toggle').prop('checked', true);
                $targetRow.find('.slots-container').empty().hide();
                $targetRow.find('.add-slot-container').hide();
                $targetRow.css('background-color', '#e8f5e9');
                setTimeout(function() { $targetRow.css('background-color', 'transparent'); }, 600);
                return;
            }

            // Raccoglie le fasce valorizzate del giorno sorgente.
            var slots = [];
            $sourceRow.find('.slots-container .slot-row').each(function() {
                var open = $(this).find('input[name*="[open]"]').val();
                var close = $(this).find('input[name*="[close]"]').val();
                if (open || close) {
                    slots.push({ open: open, close: close });
                }
            });
            if (!slots.length) {
                return;
            }

            // Il giorno di destinazione diventa aperto e riceve una copia esatta.
            $targetRow.find('.day-24h-toggle').prop('checked', false);
            $targetRow.find('.day-closed-toggle').prop('checked', false);
            $targetRow.find('.slots-container').empty().show();
            $targetRow.find('.add-slot-container').show();
            $.each(slots, function(i, slot) {
                addSlotRow($targetRow, slot.open, slot.close);
            });
            reindexSlots($targetRow);

            // Feedback visivo sulla riga di destinazione.
            $targetRow.css('background-color', '#e6f4ea');
            setTimeout(function() {
                $targetRow.css('background-color', '');
            }, 800);
        });

        function reindexSlots($row) {
            var dayKey = $row.data('day');
            var $container = $row.find('.slots-container');
            $container.find('.slot-row').each(function(idx, el) {
                $(el).find('input[name*="[open]"]').attr('name', 'ticinoweb_contact_opening_hours[' + dayKey + '][slots][' + idx + '][open]');
                $(el).find('input[name*="[close]"]').attr('name', 'ticinoweb_contact_opening_hours[' + dayKey + '][slots][' + idx + '][close]');
            });
        }
        
        // Sincronizzazione con Google Places API (tramite standard jQuery $.ajax)
        $('#tw-sync-google-hours').on('click', function(e) {
            e.preventDefault();
            console.log("Bottone Sincronizza cliccato.");
            var $btn = $(this);
            var $spinner = $('#tw-sync-spinner');
            var $message = $('#tw-sync-message');
            
            $btn.prop('disabled', true);
            $spinner.addClass('is-active');
            $message.text('Sincronizzazione in corso...').css('color', '#666');
            
            var nonceVal = (typeof ticinoweb_admin_vars !== 'undefined') ? ticinoweb_admin_vars.ajax_nonce : '';
            
            $.ajax({
                url: (typeof ajaxurl !== 'undefined') ? ajaxurl : '/wp-admin/admin-ajax.php',
                type: 'POST',
                dataType: 'json',
                data: {
                    action: 'ticinoweb_sync_google_hours',
                    nonce: nonceVal
                }
            }).done(function(response) {
                $btn.prop('disabled', false);
                $spinner.removeClass('is-active');
                
                console.log("Risposta AJAX ricevuta:", response);
                
                if (response && response.success) {
                    $message.text('Sincronizzato con successo! Ricorda di salvare la pagina.').css('color', '#16a34a');
                    
                    // Popoliamo la tabella con i nuovi orari
                    var data = response.data;
                    $.each(data, function(dayKey, dayData) {
                        var $row = $('.day-row[data-day="' + dayKey + '"]');
                        var $checkbox = $row.find('.day-closed-toggle');
                        var $slotsContainer = $row.find('.slots-container');
                        var $addContainer = $row.find('.add-slot-container');
                        
                        $slotsContainer.empty();
                        
                        var $toggle24h = $row.find('.day-24h-toggle');

                        if (dayData.closed) {
                            $checkbox.prop('checked', true);
                            $toggle24h.prop('checked', false);
                            $slotsContainer.hide();
                            $addContainer.hide();
                        } else if (dayData.open_24h) {
                            // Google reported the place as open around the clock.
                            $checkbox.prop('checked', false);
                            $toggle24h.prop('checked', true);
                            $slotsContainer.hide();
                            $addContainer.hide();
                        } else {
                            $checkbox.prop('checked', false);
                            $toggle24h.prop('checked', false);
                            $slotsContainer.show();
                            $addContainer.show();
                            
                            if (dayData.slots && dayData.slots.length > 0) {
                                $.each(dayData.slots, function(idx, slot) {
                                    addSlotRow($row, slot.open, slot.close);
                                });
                            } else {
                                addSlotRow($row);
                            }
                        }
                    });
                    
                    // Flash effect usando semplice CSS
                    $('.tw-opening-hours-table').css('transition', 'background-color 0.3s ease');
                    $('.tw-opening-hours-table').css('background-color', '#e8f5e9');
                    setTimeout(function() {
                        $('.tw-opening-hours-table').css('background-color', 'transparent');
                    }, 1000);
                } else {
                    var errorMsg = (response && response.data && response.data.message) ? response.data.message : 'Errore durante la decodifica dei dati.';
                    $message.text(errorMsg).css('color', '#dc2626');
                }
            }).fail(function(xhr, status, error) {
                $btn.prop('disabled', false);
                $spinner.removeClass('is-active');
                console.error("Errore AJAX:", status, error);
                $message.text('Errore durante la comunicazione con il server.').css('color', '#dc2626');
            });
        });
    });
    </script>
    <?php
}

// AJAX handler for test email
/**
 * SendGrid pre-flight: check API key validity, sender verification, and domain authentication.
 * Returns an array with keys: api_key_valid, sender_verified, domain_authenticated, from_email, from_domain.
 */
function ticinoweb_sendgrid_preflight( $api_key, $from_email ) {
    $result = array(
        'api_key_valid'      => false,
        'sender_verified'    => false,
        'domain_authenticated' => false,
        'from_email'         => $from_email,
        'from_domain'        => substr( $from_email, strrpos( $from_email, '@' ) + 1 ),
    );

    $auth_headers = array(
        'Authorization' => 'Bearer ' . $api_key,
        'Content-Type'  => 'application/json',
    );

    // 1. Check API key validity + single sender verification
    $sg_senders = wp_remote_get( 'https://api.sendgrid.com/v3/verified_senders', array(
        'headers' => $auth_headers,
        'timeout' => 15,
    ) );

    if ( ! is_wp_error( $sg_senders ) ) {
        $code = wp_remote_retrieve_response_code( $sg_senders );
        if ( $code === 200 ) {
            $result['api_key_valid'] = true;
            $body = json_decode( wp_remote_retrieve_body( $sg_senders ), true );
            if ( ! empty( $body['results'] ) ) {
                foreach ( $body['results'] as $sender ) {
                    if (
                        isset( $sender['from_email'], $sender['verified'] ) &&
                        strtolower( $sender['from_email'] ) === strtolower( $from_email ) &&
                        $sender['verified']
                    ) {
                        $result['sender_verified'] = true;
                        break;
                    }
                }
            }
        } elseif ( $code === 401 || $code === 403 ) {
            // API key invalid / no permission — return early
            return $result;
        }
    }

    // 2. Check domain authentication
    $sg_domains = wp_remote_get(
        'https://api.sendgrid.com/v3/whitelabel/domains?domain=' . rawurlencode( $result['from_domain'] ),
        array( 'headers' => $auth_headers, 'timeout' => 15 )
    );

    if ( ! is_wp_error( $sg_domains ) && wp_remote_retrieve_response_code( $sg_domains ) === 200 ) {
        $domains = json_decode( wp_remote_retrieve_body( $sg_domains ), true );
        if ( is_array( $domains ) ) {
            foreach ( $domains as $domain ) {
                if ( ! empty( $domain['valid'] ) ) {
                    $result['domain_authenticated'] = true;
                    break;
                }
            }
        }
    }

    return $result;
}

add_action('wp_ajax_ticinoweb_test_email', 'ticinoweb_test_email_ajax');
function ticinoweb_test_email_ajax() {
    check_ajax_referer('ticinoweb_test_email', 'nonce');

    if (!current_user_can('manage_options')) {
        wp_send_json_error('Permessi insufficienti');
    }

    $to = sanitize_email($_POST['email']);
    if (!is_email($to)) {
        wp_send_json_error('Email non valida');
    }

    $method     = get_option('ticinoweb_email_method', 'default');
    $preflight  = null;
    $warnings   = array();

    // --- SendGrid pre-flight check ---
    if ( $method === 'sendgrid' ) {
        $api_key    = get_option('ticinoweb_sendgrid_api_key');
        $from_email = get_option('ticinoweb_sendgrid_from_email');

        if ( empty( $api_key ) ) {
            wp_send_json_error( 'SendGrid API Key non configurata. Vai su Impostazioni → SMTP / Email e salva la chiave.' );
        }
        if ( empty( $from_email ) ) {
            wp_send_json_error( 'From Email non configurata per SendGrid. Vai su Impostazioni → SMTP / Email e salva l\'indirizzo mittente.' );
        }

        $preflight = ticinoweb_sendgrid_preflight( $api_key, $from_email );

        if ( ! $preflight['api_key_valid'] ) {
            wp_send_json_error( '❌ API Key SendGrid non valida o priva dei permessi necessari. Verifica la chiave su app.sendgrid.com.' );
        }
        if ( ! $preflight['sender_verified'] && ! $preflight['domain_authenticated'] ) {
            $warnings[] = '⚠️ Il mittente <strong>' . esc_html( $from_email ) . '</strong> non è verificato e il dominio <strong>' . esc_html( $preflight['from_domain'] ) . '</strong> non è autenticato in SendGrid. SendGrid può accettare l\'email (HTTP 202) ma non consegnarla. Configura il dominio su <a href="https://app.sendgrid.com/settings/sender_auth" target="_blank">SendGrid Sender Authentication</a>.';
        } elseif ( ! $preflight['domain_authenticated'] ) {
            $warnings[] = '⚠️ Il dominio <strong>' . esc_html( $preflight['from_domain'] ) . '</strong> non è autenticato (DNS). La deliverability potrebbe essere ridotta.';
        }
    }

    $subject = 'Test Email da ' . get_bloginfo('name');
    $message = "Questa è una email di test inviata dal sistema ticinoWEB Settings.\n\n";
    $message .= "Metodo attivo: " . $method . "\n";
    $message .= "Data/Ora: " . date('Y-m-d H:i:s') . "\n";
    $message .= "Sito: " . home_url() . "\n\n";
    $message .= "Se ricevi questa email, la configurazione funziona correttamente.";

    $headers = array('Content-Type: text/plain; charset=UTF-8');

    add_action('wp_mail_failed', 'ticinoweb_capture_mail_error');

    $sent = wp_mail($to, $subject, $message, $headers);

    if ($sent) {
        $msg = ( $method === 'sendgrid' )
            ? 'Email accettata da SendGrid e inviata a ' . $to . '. Controlla la casella (e spam).'
            : '✅ Email inviata correttamente a ' . $to . '. Controlla la tua casella di posta (e spam).';

        wp_send_json_success( array(
            'message'   => $msg,
            'warnings'  => $warnings,
            'preflight' => $preflight,
        ) );
    } else {
        $error  = get_transient('ticinoweb_last_mail_error');
        delete_transient('ticinoweb_last_mail_error');

        // Build helpful diagnosis
        $port       = (int) get_option('ticinoweb_smtp_port', 587);
        $encryption = trim((string) get_option('ticinoweb_smtp_encryption', 'tls'));
        $hints      = array();

        if ($encryption === 'ssl' && $port !== 465) {
            $hints[] = sprintf(__('Porta/crittografia non compatibili: SSL richiede porta 465 (hai %d). Cambia porta o usa TLS.', 'ticinoweb-ai-theme'), $port);
        } elseif ($encryption === 'tls' && $port !== 587) {
            $hints[] = sprintf(__('Porta/crittografia non compatibili: TLS/STARTTLS richiede porta 587 (hai %d). Cambia porta o usa SSL + 465.', 'ticinoweb-ai-theme'), $port);
        }

        if ($error && (strpos($error, 'Failed to connect') !== false || strpos($error, 'connect') !== false)) {
            $hints[] = __('"Failed to connect" indica: host SMTP errato, porta/crittografia sbagliata, o firewall server.', 'ticinoweb-ai-theme');
        }

        if ($error && (strpos($error, 'authenticate') !== false || strpos($error, 'auth') !== false || strpos($error, '535') !== false)) {
            $hints[] = __('Errore di autenticazione: verifica username e password SMTP. Per Gmail usa una "App Password", non la password principale.', 'ticinoweb-ai-theme');
        }

        $base_msg = $error ?: __('Impossibile inviare email. Verifica le impostazioni SMTP.', 'ticinoweb-ai-theme');
        if (!empty($hints)) {
            $base_msg .= "\n\n💡 " . implode("\n💡 ", $hints);
        }

        wp_send_json_error($base_msg);
    }
}

function ticinoweb_capture_mail_error($wp_error) {
    set_transient('ticinoweb_last_mail_error', $wp_error->get_error_message(), 60);
}

// AJAX handler: verify SendGrid API key / sender / domain (no email sent)
add_action('wp_ajax_ticinoweb_check_sendgrid_api', 'ticinoweb_check_sendgrid_api_ajax');
function ticinoweb_check_sendgrid_api_ajax() {
    check_ajax_referer('ticinoweb_check_sendgrid_api', 'nonce');

    if (!current_user_can('manage_options')) {
        wp_send_json_error('Permessi insufficienti');
    }

    $api_key    = get_option('ticinoweb_sendgrid_api_key');
    $from_email = get_option('ticinoweb_sendgrid_from_email');

    if ( empty( $api_key ) ) {
        wp_send_json_error( 'SendGrid API Key non configurata.' );
    }
    if ( empty( $from_email ) ) {
        wp_send_json_error( 'From Email non configurata per SendGrid.' );
    }

    $result = ticinoweb_sendgrid_preflight( $api_key, $from_email );
    wp_send_json_success( $result );
}

// AJAX handler: delete selected form submissions
add_action('wp_ajax_ticinoweb_delete_submissions', 'ticinoweb_delete_submissions');
function ticinoweb_delete_submissions() {
    check_ajax_referer('ticinoweb_delete_submissions', 'nonce');

    if (!current_user_can('manage_options')) {
        wp_send_json_error(__('Permessi insufficienti', 'ticinoweb-ai-theme'), 403);
    }

    $ids = isset($_POST['ids']) ? (array) $_POST['ids'] : array();
    $ids = array_filter(array_map('intval', $ids));

    if (empty($ids)) {
        wp_send_json_error(__('Nessun ID fornito', 'ticinoweb-ai-theme'), 400);
    }

    global $wpdb;
    $table = $wpdb->prefix . 'ticinoweb_form_submissions';

    $placeholders = implode(',', array_fill(0, count($ids), '%d'));
    $sql = $wpdb->prepare("DELETE FROM {$table} WHERE id IN ($placeholders)", $ids);
    $deleted = $wpdb->query($sql);

    if ($deleted === false) {
        wp_send_json_error(__('Errore durante l\'eliminazione', 'ticinoweb-ai-theme'), 500);
    }

    wp_send_json_success(array('deleted' => intval($deleted)));
}

/**
 * Helper function: Get all services
 * 
 * @return array Array of services with image, title, description, icon
 */
function ticinoweb_get_services() {
    $services = get_option('ticinoweb_services', []);
    
    if (empty($services) || !is_array($services)) {
        return [];
    }

    $modified = false;
    foreach ($services as $key => &$service) {
        if (empty($service['id'])) {
            $service['id'] = 'srv_' . substr(md5(uniqid((string)mt_rand(), true)), 0, 8);
            $modified = true;
        }
    }
    unset($service);

    if ($modified) {
        update_option('ticinoweb_services', $services);
    }

    // Frontend translation-compat layer (see inc/translation-compat.php):
    // applied on the returned copy only, after any persistence above. In
    // admin no translation filter is registered, so saved data stays intact.
    if (function_exists('ticinoweb_frontend_text')) {
        foreach ($services as &$service) {
            $sid = isset($service['id']) ? $service['id'] : '';
            if ($sid !== '' && !empty($service['title'])) {
                $service['title'] = ticinoweb_frontend_text($service['title'], "theme:service:{$sid}:title");
            }
            if ($sid !== '' && !empty($service['description'])) {
                $service['description'] = ticinoweb_frontend_text($service['description'], "theme:service:{$sid}:description");
            }
        }
        unset($service);
    }

    return $services;
}

/**
 * Standalone Settings Page Rendering Function
 */
function ticinoweb_render_standalone_settings_page() {
    if (!current_user_can('manage_options')) {
        wp_die(__('Permessi insufficienti.', 'ticinoweb-ai-theme'));
    }

    $theme = wp_get_theme('ticinoweb-ai-theme');
    $version = $theme->get('Version');
    ?>
    <div class="wrap">
        <div style="margin-bottom: 15px; text-align: left;">
            <img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/logo-ticinoweb-2025.png" alt="ticinoWEB" style="max-width: 150px; height: auto; margin-bottom: -2px; margin-left: -6px; display: block;">
            <h1 style="margin: 0; margin-bottom: 3px;"><?php _e('Settings', 'ticinoweb-ai-theme'); ?></h1>
            <p style="margin: 0; color: #666; font-size: 13px; display:flex; align-items:center;">v<?php echo esc_html($version); ?><?php ticinoweb_render_version_badge($version); ?></p>
            <?php ticinoweb_render_child_version_line(); ?>
        </div>

        <?php settings_errors(); ?>

        <form method="post" action="options.php">
            <?php
            settings_fields('ticinoweb_settings_group');
            ?>
            
            <p class="description"><?php _e('Impostazioni avanzate e strumenti amministrativi. Questa sezione è visibile solo agli amministratori e super admin.', 'ticinoweb-ai-theme'); ?></p>
            
            <style>
                .ticinoweb-tab-content { display: none; margin-top: 0; }
                .ticinoweb-tab-content.active { display: block; }
                .nav-tab { cursor: pointer; }
            </style>

            <div class="ticinoweb-settings-tabs">
                <h2 class="nav-tab-wrapper">
                    <a href="#general" class="nav-tab nav-tab-active"><?php _e('Generale', 'ticinoweb-ai-theme'); ?></a>
                    <a href="#tools" class="nav-tab"><?php _e('Strumenti', 'ticinoweb-ai-theme'); ?></a>
                    <a href="#functions" class="nav-tab"><?php _e('Functions', 'ticinoweb-ai-theme'); ?></a>
                </h2>
                
                <div id="general" class="ticinoweb-tab-content active">
                    <table class="form-table">
                <tr>
                    <th scope="row">
                        <label for="ticinoweb_maintenance_mode"><?php _e('Sito in Manutenzione', 'ticinoweb-ai-theme'); ?></label>
                    </th>
                    <td>
                        <label>
                            <input type="hidden" name="ticinoweb_maintenance_mode" value="0">
                            <input type="checkbox" id="ticinoweb_maintenance_mode" name="ticinoweb_maintenance_mode" value="1" 
                                   <?php checked(get_option('ticinoweb_maintenance_mode', 0)); ?>>
                            <?php _e('Attiva la modalità manutenzione', 'ticinoweb-ai-theme'); ?>
                        </label>
                        <p class="description"><?php _e('Mostra una pagina di manutenzione con design liquid glass ai visitatori non autenticati. Gli amministratori possono accedere normalmente. Include logo, contatti e form di login.', 'ticinoweb-ai-theme'); ?></p>

                        <div style="margin-top: 16px; padding: 14px 16px; background: #f8f9fa; border-left: 3px solid #c3c4c7; border-radius: 0 4px 4px 0;">
                            <p style="margin: 0 0 10px; font-weight: 600; font-size: 13px; color: #1d2327;"><?php _e('Testo della pagina di manutenzione', 'ticinoweb-ai-theme'); ?></p>

                            <label for="ticinoweb_maintenance_heading" style="display: block; margin-bottom: 4px; font-size: 13px;">
                                <?php _e('Titolo principale', 'ticinoweb-ai-theme'); ?>
                            </label>
                            <input type="text"
                                   id="ticinoweb_maintenance_heading"
                                   name="ticinoweb_maintenance_heading"
                                   value="<?php echo esc_attr(get_option('ticinoweb_maintenance_heading', '')); ?>"
                                   class="regular-text"
                                   placeholder="<?php echo esc_attr(_x('Es: Sito in Costruzione', 'placeholder', 'ticinoweb-ai-theme')); ?>">
                            <p class="description" style="margin-bottom: 12px;"><?php _e('Lascia vuoto per usare il testo predefinito in base alla lingua del sito.', 'ticinoweb-ai-theme'); ?></p>

                            <label for="ticinoweb_maintenance_subtitle" style="display: block; margin-bottom: 4px; font-size: 13px;">
                                <?php _e('Sottotitolo / messaggio', 'ticinoweb-ai-theme'); ?>
                            </label>
                            <textarea id="ticinoweb_maintenance_subtitle"
                                      name="ticinoweb_maintenance_subtitle"
                                      rows="3"
                                      class="large-text"
                                      placeholder="<?php echo esc_attr(_x('Es: Stiamo lavorando per offrirti un\'esperienza migliore. Torna presto!', 'placeholder', 'ticinoweb-ai-theme')); ?>"><?php echo esc_textarea(get_option('ticinoweb_maintenance_subtitle', '')); ?></textarea>
                            <p class="description"><?php _e('Lascia vuoto per usare il testo predefinito in base alla lingua del sito.', 'ticinoweb-ai-theme'); ?></p>
                        </div>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="ticinoweb_disable_comments"><?php _e('Disabilita Commenti', 'ticinoweb-ai-theme'); ?></label>
                    </th>
                    <td>
                        <label>
                            <input type="hidden" name="ticinoweb_disable_comments" value="0">
                            <input type="checkbox" id="ticinoweb_disable_comments" name="ticinoweb_disable_comments" value="1" 
                                   <?php checked(get_option('ticinoweb_disable_comments', 1)); ?>>
                            <?php _e('Blocca tutti i commenti su questo sito', 'ticinoweb-ai-theme'); ?>
                        </label>
                        <p class="description"><?php _e('Se abilitato, disabilita completamente la possibilità di postare commenti su pagine, post e tutti gli altri tipi di contenuto. I commenti esistenti rimarranno visibili ma non saranno possibili nuovi commenti.', 'ticinoweb-ai-theme'); ?></p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="ticinoweb_ai_instructions"><?php _e('Prompt Inziale', 'ticinoweb-ai-theme'); ?></label>
                    </th>
                    <td>
                        <?php 
                        $default_prompt = "Agisci come un Senior WordPress Developer. Devo creare un Child Theme basato sul parent theme \"ticinoweb-ai-theme\".

### CONTESTO TECNICO ###

Il parent theme funge da CMS headless/lightweight.
- La logica risiede nel parent.
- I dati (Servizi, Slider, Contatti, Social) sono salvati nel database (wp_options) e non nei post standard, eccetto che per le Pagine standard.
- Il child theme deve gestire solo l'output HTML/PHP e il CSS.

### TASK ###

Genera i file necessari per il Child Theme con codice pulito, HTML5 semantico e classi CSS pronte per essere stilizzate (es. BEM o standard).

### STRUTTURA DEI FILE RICHIESTI ###

-- CORE FILES --
style.css: 
Includi l'intestazione corretta dichiarando Template: ticinoweb-ai-theme.

functions.php: 
Enqueue corretto dello stile parent e child.

-- TEMPLATE PARTS --
header.php:
- Logo (da Customizer o opzioni tema).
- Menu (wp_nav_menu location: 'primary').
- Cerca di recuperare i dati di contatto/social dalle opzioni del tema (get_option('ticinoweb_...')) per la top-bar.

footer.php:
- Copyright dinamico.
- Recupera indirizzo e contatti dalle opzioni del tema.
- wp_footer() obbligatorio.

-- PAGINE PRINCIPALI --
front-page.php (Home Page):
- NON usare il loop standard.
- Recupera i dati dello Slider e dei Servizi dalle opzioni del tema (es. get_option('ticinoweb_services'), get_option('ticinoweb_slider')).
- Renderizza queste sezioni in HTML.

page.php (Standard Page Template):
- Usa il Loop standard di WordPress.
- Mostra: Immagine in evidenza (se presente), Titolo H1, Contenuto (the_content), Custom Fields (se presenti).

-- TEMPLATE CUSTOM --
page-templates/template-about.php (Chi Siamo):
- Template Page personalizzato.
- Recupera i dati specifici della sezione \"About\" dalle opzioni del tema o usa un misto di contenuto standard + dati CMS.

page-templates/template-services.php (Servizi):
- Template Page personalizzato.
- Itera l'array dei servizi salvato nelle opzioni del tema e genera una griglia di servizi.

### WOOCOMMERCE (OPZIONALE) ###

woocommerce.php:
- Wrapper generico per le pagine prodotto se WooCommerce è installato.

### GOOGLE REVIEWS ###

Il tema integra le recensioni di Google gestite centralmente nel CMS:
- Shortcode: [ticinoweb_google_reviews limit=\"5\" min_rating=\"4\" layout=\"grid\"] 
  - layout: 'grid' o 'list'.
  - min_rating: sovrascrive il filtro di default del CMS.
- Funzione Helper: ticinoweb_get_google_reviews(\$limit, \$min_rating) ritorna un array di recensioni salvate localmente.
- Link GMB: get_option('ticinoweb_google_business_link') per il pulsante \"Lascia una recensione\".
- Metadata: get_option('ticinoweb_google_reviews_rating') (media voti) e get_option('ticinoweb_google_reviews_count') (totale recensioni).

### NOTE FINALI ###

Usa sempre l'escaping (esc_html, esc_url) e preparalo per la traduzione (_e(), __() con text-domain 'ticinoweb-child').";
                        ?>
                        
                        <div style="margin-bottom: 10px;">
                            <button type="button" class="button button-secondary" onclick="copyInstructions()"><span class="dashicons dashicons-clipboard" style="margin-top: 3px;"></span> <?php _e('Copia Prompt', 'ticinoweb-ai-theme'); ?></button>
                            <button type="button" class="button button-secondary" onclick="resetInstructions()" style="margin-left: 5px;"><?php _e('Ripristina Default Prompt', 'ticinoweb-ai-theme'); ?></button>
                        </div>

                        <textarea id="ticinoweb_ai_instructions" name="ticinoweb_ai_instructions" 
                                  rows="25" class="large-text code" 
                                  style="font-family: Monaco, Consolas, 'Courier New', monospace; font-size: 13px; line-height: 1.6;"
                                  placeholder="Inserisci qui le istruzioni di alto livello per il sito..."><?php echo esc_textarea(get_option('ticinoweb_ai_instructions', $default_prompt)); ?></textarea>
                        
                        <script>
                            function copyInstructions() {
                                var copyText = document.getElementById("ticinoweb_ai_instructions");
                                copyText.select();
                                copyText.setSelectionRange(0, 99999);
                                navigator.clipboard.writeText(copyText.value).then(function() {
                                    alert("<?php _e('Testo copiato negli appunti!', 'ticinoweb-ai-theme'); ?>");
                                });
                            }
                            function resetInstructions() {
                                if(confirm("<?php _e('Sei sicuro? Questo sostituirà il testo attuale con il prompt di default.', 'ticinoweb-ai-theme'); ?>")) {
                                    document.getElementById("ticinoweb_ai_instructions").value = <?php echo json_encode($default_prompt); ?>;
                                }
                            }
                        </script>

                        <p class="description">
                            <?php _e('Utilizza questo spazio per documentare le linee guida architetturali, le best practices, e le convenzioni da seguire nella realizzazione del sito. Supporta Markdown per una migliore formattazione.', 'ticinoweb-ai-theme'); ?>
                        </p>
                    </td>

                </tr>
            </table>
            </div>

            <div id="tools" class="ticinoweb-tab-content">

            <h3><?php _e('URL Replacement', 'ticinoweb-ai-theme'); ?></h3>
            <p class="description">
                <?php _e('Sostituisce il vecchio URL con il nuovo URL in tutto il sito corrente (solo questo sito del multisite).', 'ticinoweb-ai-theme'); ?>
            </p>
            <table class="form-table">
                <tr>
                    <th scope="row">
                        <label for="ticinoweb_old_url"><?php _e('Old URL', 'ticinoweb-ai-theme'); ?></label>
                    </th>
                    <td>
                        <input type="url" id="ticinoweb_old_url" name="ticinoweb_old_url" form="ticinoweb-url-replace-form"
                               class="regular-text" placeholder="https://ticinoweb04.jcloud.ik-server.com/ambrosini/">
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="ticinoweb_new_url"><?php _e('New URL', 'ticinoweb-ai-theme'); ?></label>
                    </th>
                    <td>
                        <input type="url" id="ticinoweb_new_url" name="ticinoweb_new_url" form="ticinoweb-url-replace-form"
                               class="regular-text" placeholder="https://ambrosinimuralto.ch/">
                        <p class="description">
                            <?php _e('Esegui un backup prima di procedere. L’operazione è irreversibile.', 'ticinoweb-ai-theme'); ?>
                        </p>
                        <button type="submit" form="ticinoweb-url-replace-form" class="button button-secondary">
                            <?php _e('Replace URLs', 'ticinoweb-ai-theme'); ?>
                        </button>
                    </td>
                </tr>
                        </button>
                    </td>
                </tr>
            </table>

            <hr style="margin: 40px 0;">

            <h2><?php _e('Stato del Sistema (Server Health)', 'ticinoweb-ai-theme'); ?></h2>
            <p class="description"><?php _e('Questa sezione verifica se le impostazioni del server PHP sono adeguate per il buon funzionamento del tema e di WordPress.', 'ticinoweb-ai-theme'); ?></p>
            
            <table class="form-table">
                <tbody>
                    <?php 
                    $checks = [
                        [
                            'label' => 'max_input_vars',
                            'current' => ini_get('max_input_vars'),
                            'required' => 5000,
                            'desc' => 'Necessario per salvare decine di campi nel CMS senza che vengano troncati.',
                            'ok' => (int)ini_get('max_input_vars') >= 5000
                        ],
                        [
                            'label' => 'memory_limit',
                            'current' => ini_get('memory_limit'),
                            'required' => '256M',
                            'desc' => 'Consigliato almeno 256M per eseguire script complessi senza interruzioni.',
                            'ok' => wp_convert_hr_to_bytes(ini_get('memory_limit')) >= wp_convert_hr_to_bytes('256M')
                        ],
                        [
                            'label' => 'post_max_size',
                            'current' => ini_get('post_max_size'),
                            'required' => '64M',
                            'desc' => 'Dimensione massima dei dati inviati tramite form.',
                            'ok' => wp_convert_hr_to_bytes(ini_get('post_max_size')) >= wp_convert_hr_to_bytes('64M')
                        ],
                        [
                            'label' => 'upload_max_filesize',
                            'current' => ini_get('upload_max_filesize'),
                            'required' => '64M',
                            'desc' => 'Dimensione massima dei singoli file caricati (immagini, video).',
                            'ok' => wp_convert_hr_to_bytes(ini_get('upload_max_filesize')) >= wp_convert_hr_to_bytes('64M')
                        ],
                        [
                            'label' => 'PHP Version',
                            'current' => phpversion(),
                            'required' => '8.0',
                            'desc' => 'Versione minima raccomandata di PHP per sicurezza e velocità.',
                            'ok' => version_compare(phpversion(), '8.0.0', '>=')
                        ]
                    ];
                    
                    foreach ($checks as $check): 
                    ?>
                    <tr>
                        <th scope="row">
                            <label><?php echo esc_html($check['label']); ?></label>
                        </th>
                        <td>
                            <div style="display: flex; align-items: center; gap: 10px;">
                                <?php if ($check['ok']): ?>
                                    <span class="dashicons dashicons-yes-alt" style="color: #46b450; font-size: 24px; width: 24px; height: 24px;"></span>
                                    <strong style="color: #46b450;"><?php echo esc_html($check['current']); ?></strong>
                                <?php else: ?>
                                    <span class="dashicons dashicons-dismiss" style="color: #dc3232; font-size: 24px; width: 24px; height: 24px;"></span>
                                    <strong style="color: #dc3232;"><?php echo esc_html($check['current']); ?> (Richiesto: <?php echo esc_html($check['required']); ?>)</strong>
                                <?php endif; ?>
                            </div>
                            <p class="description"><?php echo esc_html($check['desc']); ?></p>
                            <?php if (!$check['ok']): ?>
                                <p style="color: #dc3232; font-size: 13px; margin-top: 8px; font-weight: bold;">
                                    <em><?php _e('Azione richiesta: Aggiungi "php_value ' . esc_attr($check['label']) . ' ' . esc_attr($check['required']) . '" nel file .htaccess o contatta l\'hosting.', 'ticinoweb-ai-theme'); ?></em>
                                </p>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            </div>

            <div id="functions" class="ticinoweb-tab-content">
                <h2><?php _e('Funzionalità CMS', 'ticinoweb-ai-theme'); ?></h2>
                <p class="description"><?php _e('Attiva o disattiva aree specifiche del CMS.', 'ticinoweb-ai-theme'); ?></p>
                <table class="form-table">
                    <tr>
                        <th scope="row">
                            <label for="ticinoweb_disable_svg_icons"><?php _e('Disabilita Icone SVG', 'ticinoweb-ai-theme'); ?></label>
                        </th>
                        <td>
                            <label>
                                <input type="hidden" name="ticinoweb_disable_svg_icons" value="0">
                                <input type="checkbox" id="ticinoweb_disable_svg_icons" name="ticinoweb_disable_svg_icons" value="1" 
                                       <?php checked(get_option('ticinoweb_disable_svg_icons', 0)); ?>>
                                <?php _e('Nascondi la tab Icone SVG dal CMS e disabilita la funzionalità', 'ticinoweb-ai-theme'); ?>
                            </label>
                            <p class="description"><?php _e('Se abilitato, la tab "Icone SVG" non sarà più visibile e il caricamento delle librerie SVG verrà interrotto.', 'ticinoweb-ai-theme'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="ticinoweb_disable_promozioni"><?php _e('Disabilita Promozioni', 'ticinoweb-ai-theme'); ?></label>
                        </th>
                        <td>
                            <label>
                                <input type="hidden" name="ticinoweb_disable_promozioni" value="0">
                                <input type="checkbox" id="ticinoweb_disable_promozioni" name="ticinoweb_disable_promozioni" value="1" 
                                       <?php checked(get_option('ticinoweb_disable_promozioni', 0)); ?>>
                                <?php _e('Nascondi la tab Promozioni dal CMS', 'ticinoweb-ai-theme'); ?>
                            </label>
                            <p class="description"><?php _e('Se abilitato, la tab "Promozioni" non sarà più visibile nel CMS principale.', 'ticinoweb-ai-theme'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="ticinoweb_disable_page_mapping"><?php _e('Disabilita Mappatura Pagine', 'ticinoweb-ai-theme'); ?></label>
                        </th>
                        <td>
                            <label>
                                <input type="hidden" name="ticinoweb_disable_page_mapping" value="0">
                                <input type="checkbox" id="ticinoweb_disable_page_mapping" name="ticinoweb_disable_page_mapping" value="1" 
                                       <?php checked(get_option('ticinoweb_disable_page_mapping', 0)); ?>>
                                <?php _e('Nascondi la tab Mappatura Pagine dal CMS', 'ticinoweb-ai-theme'); ?>
                            </label>
                            <p class="description"><?php _e('Se abilitato, la tab "Mappatura Pagine" non sarà più visibile nel CMS principale.', 'ticinoweb-ai-theme'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="ticinoweb_disable_cpts"><?php _e('Disabilita Custom Post Types', 'ticinoweb-ai-theme'); ?></label>
                        </th>
                        <td>
                            <label>
                                <input type="hidden" name="ticinoweb_disable_cpts" value="0">
                                <input type="checkbox" id="ticinoweb_disable_cpts" name="ticinoweb_disable_cpts" value="1" 
                                       <?php checked(get_option('ticinoweb_disable_cpts', 0)); ?>>
                                <?php _e('Nascondi la tab Custom Post Types dal CMS', 'ticinoweb-ai-theme'); ?>
                            </label>
                            <p class="description"><?php _e('Se abilitato, la funzionalità per creare i Custom Post Type non sarà più visibile.', 'ticinoweb-ai-theme'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="ticinoweb_disable_reviews"><?php _e('Disabilita Recensioni', 'ticinoweb-ai-theme'); ?></label>
                        </th>
                        <td>
                            <label>
                                <input type="hidden" name="ticinoweb_disable_reviews" value="0">
                                <input type="checkbox" id="ticinoweb_disable_reviews" name="ticinoweb_disable_reviews" value="1" 
                                       <?php checked(get_option('ticinoweb_disable_reviews', 0)); ?>>
                                <?php _e('Nascondi la tab Recensioni dal CMS', 'ticinoweb-ai-theme'); ?>
                            </label>
                            <p class="description"><?php _e('Se abilitato, la tab "Recensioni" non sarà più visibile nel CMS principale.', 'ticinoweb-ai-theme'); ?></p>
                        </td>
                    </tr>
                </table>
            </div>

            </div> <!-- end ticinoweb-settings-tabs -->

            <?php submit_button(); ?>
            <script>
            (function() {
                function initOrari() {
                    if (typeof jQuery === 'undefined') {
                        setTimeout(initOrari, 50);
                        return;
                    }
                    jQuery(document).ready(function($) {
                var tabStorageKey = 'ticinoweb_settings_active_tab';
                function activateTab(target) {
                    if (!target || $(target).length === 0) return;
                    $('.nav-tab').removeClass('nav-tab-active');
                    $('.nav-tab[href="' + target + '"]').addClass('nav-tab-active');
                    $('.ticinoweb-tab-content').removeClass('active');
                    $(target).addClass('active');
                    try { localStorage.setItem(tabStorageKey, target); } catch (e) {}
                    if (history.replaceState) { history.replaceState(null, null, target); } else { window.location.hash = target; }
                }
                $('.nav-tab').on('click', function(e) {
                    e.preventDefault();
                    activateTab($(this).attr('href'));
                });
                var initialTab = window.location.hash || (function(){ try { return localStorage.getItem(tabStorageKey); } catch(e){} })() || $('.nav-tab').first().attr('href');
                activateTab(initialTab);

            });
                }
                initOrari();
            })();
            </script>
        </form>

        <form id="ticinoweb-url-replace-form" method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
            <?php wp_nonce_field('ticinoweb_url_replacement', 'ticinoweb_url_replacement_nonce'); ?>
            <input type="hidden" name="action" value="ticinoweb_url_replacement">
        </form>
    </div>
    <?php
}
