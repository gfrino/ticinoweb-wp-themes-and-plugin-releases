<?php
/**
 * Widget Elementor "FAQ ticinoWEB": inserisce una scheda FAQ scelta per nome.
 * Caricato solo quando Elementor registra i widget (vedi inc/faq.php).
 *
 * @package ticinoweb-ai-theme
 * @since   3.13.0
 */

if (!defined('ABSPATH')) {
    exit;
}

class TicinoWEB_FAQ_Elementor_Widget extends \Elementor\Widget_Base {

    public function get_name() {
        return 'tw_faq';
    }

    public function get_title() {
        return __('FAQ ticinoWEB', 'ticinoweb-ai-theme');
    }

    public function get_icon() {
        return 'eicon-help-o';
    }

    public function get_categories() {
        return array('general');
    }

    public function get_keywords() {
        return array('faq', 'domande', 'questions', 'ticinoweb');
    }

    protected function register_controls() {
        $choices = array('' => __('— Scegli una scheda —', 'ticinoweb-ai-theme')) + ticinoweb_faq_choices();

        $this->start_controls_section('content', array(
            'label' => __('Scheda FAQ', 'ticinoweb-ai-theme'),
        ));

        $this->add_control('tw_faq_scheda', array(
            'label'       => __('Scheda', 'ticinoweb-ai-theme'),
            'type'        => \Elementor\Controls_Manager::SELECT,
            'options'     => $choices,
            'default'     => '',
            'description' => sprintf(
                /* translators: %s: link alla pagina delle schede FAQ */
                __('Le domande si modificano in %s.', 'ticinoweb-ai-theme'),
                '<a href="' . esc_url(admin_url('edit.php?post_type=tw_faq')) . '" target="_blank">' . esc_html__('Bacheca → FAQ', 'ticinoweb-ai-theme') . '</a>'
            ),
        ));

        $this->add_control('tw_faq_show_title', array(
            'label'        => __('Mostra il titolo della scheda', 'ticinoweb-ai-theme'),
            'type'         => \Elementor\Controls_Manager::SWITCHER,
            'return_value' => 'yes',
            'default'      => 'yes',
        ));

        $this->add_control('tw_faq_open_first', array(
            'label'        => __('Prima risposta già aperta', 'ticinoweb-ai-theme'),
            'type'         => \Elementor\Controls_Manager::SWITCHER,
            'return_value' => 'yes',
            'default'      => '',
        ));

        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        if (empty($settings['tw_faq_scheda'])) {
            if (\Elementor\Plugin::$instance->editor->is_edit_mode()) {
                echo '<p style="padding:16px;border:1px dashed #94a3b8;text-align:center;">' . esc_html__('Scegli una scheda FAQ nel pannello a sinistra.', 'ticinoweb-ai-theme') . '</p>';
            }
            return;
        }
        echo ticinoweb_faq_render($settings['tw_faq_scheda'], array( // phpcs:ignore WordPress.Security.EscapeOutput -- HTML escapato nel template
            'show_title' => $settings['tw_faq_show_title'] === 'yes',
            'open_first' => $settings['tw_faq_open_first'] === 'yes',
        ));
    }
}
