<?php
/**
 * FAQ: schede di domande e risposte riutilizzabili in tutto il sito.
 *
 * Una "scheda FAQ" (CPT `tw_faq`) ha un nome, un'introduzione facoltativa e un
 * elenco ordinato di domande e risposte. Ogni domanda puo' appartenere a una
 * sezione (con descrizione) ed essere nascosta senza cancellarla.
 *
 * Dove si mette una scheda (sempre scelta per nome, mai per ID):
 * - in fondo a una pagina/articolo: box "FAQ della pagina" nell'editor;
 * - shortcode `[tw_faq scheda="nome-scheda"]` (pulsante "Copia" nella scheda);
 * - blocco Gutenberg "FAQ ticinoWEB" e widget Elementor "FAQ ticinoWEB".
 *
 * Ricerche AI e SEO: le risposte sono HTML reale (<details>/<summary>, leggibile
 * senza JavaScript) e la pagina riceve un unico JSON-LD `FAQPage` con tutte le
 * domande mostrate, anche se le schede sono piu' d'una.
 *
 * Multilingua: tW Translate Plus traduce tramite `ticinoweb_frontend_text()`
 * (contesti `faq:{id}:...`, quindi anche il JSON-LD); con WPML la scheda e'
 * un contenuto traducibile (vedi wpml-config.xml) e si usa la sua traduzione.
 *
 * Estendibile dai child:
 * - `ticinoweb_faq_item_fields`: campi in piu' per ogni domanda (testo, url,
 *   checkbox), salvati in $item['extra'][chiave];
 * - `ticinoweb_faq_get_set()` / `ticinoweb_faq_schema_add()` per un design proprio;
 * - template sovrascrivibile `template-parts/tw-faq.php` nel child;
 * - `ticinoweb_faq_schema`: modifica o spegne (array vuoto) il JSON-LD.
 *
 * @package ticinoweb-ai-theme
 * @since   3.13.0
 */

if (!defined('ABSPATH')) {
    exit;
}

define('TICINOWEB_FAQ_META_ITEMS', '_tw_faq_items');
define('TICINOWEB_FAQ_META_INTRO', '_tw_faq_intro');
define('TICINOWEB_FAQ_META_SECTIONS', '_tw_faq_sections');
define('TICINOWEB_FAQ_META_PAGE', '_tw_faq_page_set');

/* -------------------------------------------------------------------------
 * Registrazione
 * ---------------------------------------------------------------------- */

add_action('init', 'ticinoweb_faq_register');
function ticinoweb_faq_register() {
    register_post_type('tw_faq', array(
        'labels' => array(
            'name'               => __('FAQ', 'ticinoweb-ai-theme'),
            'singular_name'      => __('Scheda FAQ', 'ticinoweb-ai-theme'),
            'menu_name'          => __('FAQ', 'ticinoweb-ai-theme'),
            'all_items'          => __('Tutte le schede FAQ', 'ticinoweb-ai-theme'),
            'add_new'            => __('Nuova scheda FAQ', 'ticinoweb-ai-theme'),
            'add_new_item'       => __('Nuova scheda FAQ', 'ticinoweb-ai-theme'),
            'edit_item'          => __('Modifica scheda FAQ', 'ticinoweb-ai-theme'),
            'search_items'       => __('Cerca schede FAQ', 'ticinoweb-ai-theme'),
            'not_found'          => __('Nessuna scheda FAQ. Creane una con "Nuova scheda FAQ".', 'ticinoweb-ai-theme'),
            'not_found_in_trash' => __('Nessuna scheda FAQ nel cestino.', 'ticinoweb-ai-theme'),
        ),
        'public'              => false,
        'publicly_queryable'  => false,
        'exclude_from_search' => true,
        'show_ui'             => true,
        'show_in_menu'        => true,
        'show_in_nav_menus'   => false,
        'show_in_admin_bar'   => false,
        'show_in_rest'        => false,
        'menu_position'       => 21, // subito dopo Pagine: e' un contenuto
        'menu_icon'           => 'dashicons-editor-help',
        'capability_type'     => 'page',
        'map_meta_cap'        => true,
        'hierarchical'        => false,
        'supports'            => array('title'),
        'rewrite'             => false,
        'query_var'           => false,
        'can_export'          => true,
    ));

    add_shortcode('tw_faq', 'ticinoweb_faq_shortcode');
    wp_register_style('ticinoweb-faq', get_template_directory_uri() . '/assets/css/tw-faq.css', array(), TICINOWEB_THEME_VERSION);

    if (function_exists('register_block_type')) {
        wp_register_script(
            'ticinoweb-faq-block',
            get_template_directory_uri() . '/assets/js/tw-faq-block.js',
            array('wp-blocks', 'wp-element', 'wp-components', 'wp-block-editor', 'wp-server-side-render', 'wp-i18n'),
            TICINOWEB_THEME_VERSION,
            true
        );
        register_block_type('ticinoweb/faq', array(
            'editor_script'   => 'ticinoweb-faq-block',
            'editor_style'    => 'ticinoweb-faq',
            'render_callback' => 'ticinoweb_faq_block_render',
            'attributes'      => array(
                'scheda'    => array('type' => 'string', 'default' => ''),
                'showTitle' => array('type' => 'boolean', 'default' => true),
            ),
        ));
    }
}

/* -------------------------------------------------------------------------
 * Lettura dati
 * ---------------------------------------------------------------------- */

/** Campi extra per ogni domanda, registrati dai child: chiave => [label, type, help]. */
function ticinoweb_faq_item_fields() {
    $fields = apply_filters('ticinoweb_faq_item_fields', array());
    $clean  = array();
    foreach ((array) $fields as $key => $field) {
        $key = sanitize_key($key);
        if ($key === '' || !is_array($field)) {
            continue;
        }
        $type = isset($field['type']) && in_array($field['type'], array('text', 'url', 'checkbox'), true) ? $field['type'] : 'text';
        $clean[$key] = array(
            'label' => isset($field['label']) ? (string) $field['label'] : $key,
            'type'  => $type,
            'help'  => isset($field['help']) ? (string) $field['help'] : '',
        );
    }
    return $clean;
}

/**
 * Trova una scheda per ID, slug o titolo; con WPML restituisce la traduzione
 * nella lingua corrente (ripiega sull'originale).
 *
 * @param int|string|WP_Post $ref
 * @return WP_Post|null
 */
function ticinoweb_faq_find($ref) {
    $post = null;
    if ($ref instanceof WP_Post) {
        $post = $ref;
    } elseif (is_numeric($ref)) {
        $post = get_post((int) $ref);
    } elseif (is_string($ref) && $ref !== '') {
        $found = get_posts(array(
            'post_type'        => 'tw_faq',
            'name'             => sanitize_title($ref),
            'post_status'      => 'publish',
            'numberposts'      => 1,
            'suppress_filters' => true, // tutte le lingue: la traduzione si sceglie sotto
        ));
        if (!$found) {
            $found = get_posts(array(
                'post_type'        => 'tw_faq',
                'title'            => $ref,
                'post_status'      => 'publish',
                'numberposts'      => 1,
                'suppress_filters' => true,
            ));
        }
        $post = $found ? $found[0] : null;
    }
    if (!$post || $post->post_type !== 'tw_faq') {
        return null;
    }

    $translated = apply_filters('wpml_object_id', $post->ID, 'tw_faq', true);
    if ($translated && (int) $translated !== (int) $post->ID) {
        $tr = get_post((int) $translated);
        if ($tr && $tr->post_status === 'publish') {
            $post = $tr;
        }
    }
    return $post->post_status === 'publish' || is_preview() || is_admin() ? $post : null;
}

/** Domande grezze salvate (anche quelle nascoste), per l'editor e le migrazioni. */
function ticinoweb_faq_raw_items($post_id) {
    $items = get_post_meta($post_id, TICINOWEB_FAQ_META_ITEMS, true);
    return is_array($items) ? array_values($items) : array();
}

/**
 * Scheda pronta per la visualizzazione: testi tradotti, solo domande visibili.
 *
 * @param int|string|WP_Post $ref ID, slug o titolo della scheda.
 * @return array|null [id, slug, title, intro, sections => [slug => [title, desc]], items => [...]]
 *                    Ogni item: id, question, answer (HTML), section, section_slug, anchor, extra.
 */
function ticinoweb_faq_get_set($ref) {
    $post = ticinoweb_faq_find($ref);
    if (!$post) {
        return null;
    }
    $id  = $post->ID;
    $ctx = 'faq:' . $id;

    $section_desc = get_post_meta($id, TICINOWEB_FAQ_META_SECTIONS, true);
    $section_desc = is_array($section_desc) ? $section_desc : array();

    $set = array(
        'id'       => $id,
        'slug'     => $post->post_name,
        'title'    => ticinoweb_frontend_text(get_the_title($post), $ctx . ':title'),
        'intro'    => ticinoweb_frontend_text((string) get_post_meta($id, TICINOWEB_FAQ_META_INTRO, true), $ctx . ':intro'),
        'sections' => array(),
        'items'    => array(),
    );

    foreach (ticinoweb_faq_raw_items($id) as $item) {
        if (empty($item['q']) || (isset($item['visible']) && !$item['visible'])) {
            continue;
        }
        $item_id = isset($item['id']) ? (string) $item['id'] : md5($item['q']);
        $section = isset($item['section']) ? trim((string) $item['section']) : '';
        $sslug   = $section !== '' ? sanitize_title($section) : '';

        if ($sslug !== '' && !isset($set['sections'][$sslug])) {
            $set['sections'][$sslug] = array(
                'title' => ticinoweb_frontend_text($section, $ctx . ':section:' . $sslug . ':title'),
                'desc'  => isset($section_desc[$section]) ? ticinoweb_frontend_text((string) $section_desc[$section], $ctx . ':section:' . $sslug . ':desc') : '',
            );
        }

        $question = ticinoweb_frontend_text((string) $item['q'], $ctx . ':' . $item_id . ':q');
        $set['items'][] = array(
            'id'           => $item_id,
            'question'     => $question,
            'answer'       => ticinoweb_frontend_text(isset($item['a']) ? (string) $item['a'] : '', $ctx . ':' . $item_id . ':a'),
            'section'      => $sslug !== '' ? $set['sections'][$sslug]['title'] : '',
            'section_slug' => $sslug,
            'anchor'       => 'faq-' . sanitize_title($question),
            'extra'        => isset($item['extra']) && is_array($item['extra']) ? $item['extra'] : array(),
        );
    }

    return apply_filters('ticinoweb_faq_set', $set, $post);
}

/** Tutte le schede pubblicate (id => titolo), per i selettori. */
function ticinoweb_faq_choices() {
    $posts = get_posts(array(
        'post_type'        => 'tw_faq',
        'post_status'      => 'publish',
        'numberposts'      => 200,
        'orderby'          => 'title',
        'order'            => 'ASC',
        'suppress_filters' => false,
    ));
    $choices = array();
    foreach ($posts as $p) {
        $choices[$p->post_name] = $p->post_title !== '' ? $p->post_title : $p->post_name;
    }
    return $choices;
}

/* -------------------------------------------------------------------------
 * Visualizzazione
 * ---------------------------------------------------------------------- */

/**
 * HTML di una scheda. Il child puo' sovrascrivere `template-parts/tw-faq.php`.
 *
 * @param int|string|WP_Post $ref
 * @param array $args show_title (bool), heading_level (2-4), open_first (bool), class (string)
 */
function ticinoweb_faq_render($ref, $args = array()) {
    $set = ticinoweb_faq_get_set($ref);
    if (!$set || !$set['items']) {
        return '';
    }
    $args = wp_parse_args($args, array(
        'show_title'    => true,
        'heading_level' => 2,
        'open_first'    => false,
        'class'         => '',
    ));
    $args['heading_level'] = max(2, min(4, (int) $args['heading_level']));

    ticinoweb_faq_schema_add($set['items']);
    wp_enqueue_style('ticinoweb-faq');

    // La stessa scheda mostrata due volte nella pagina: id HTML resi unici.
    static $instances = array();
    $instances[$set['id']] = isset($instances[$set['id']]) ? $instances[$set['id']] + 1 : 1;
    if ($instances[$set['id']] > 1) {
        $suffix = '-' . $instances[$set['id']];
        $set['slug'] .= $suffix;
        foreach ($set['items'] as &$it) {
            $it['anchor'] .= $suffix;
        }
        unset($it);
    }

    ob_start();
    $template = locate_template('template-parts/tw-faq.php');
    if ($template) {
        $faq = $set;
        $faq_args = $args;
        include $template;
    } else {
        ticinoweb_faq_default_template($set, $args);
    }
    return ob_get_clean();
}

function ticinoweb_faq_default_template($set, $args) {
    $h  = (int) $args['heading_level'];
    $hs = min(6, $h + 1);
    $title_id = 'tw-faq-title-' . $set['id'];
    $groups = array();
    foreach ($set['items'] as $item) {
        $groups[$item['section_slug']][] = $item;
    }
    $first = true;
    ?>
    <section class="tw-faq <?php echo esc_attr($args['class']); ?>" id="<?php echo esc_attr('faq-' . $set['slug']); ?>"<?php echo $args['show_title'] ? ' aria-labelledby="' . esc_attr($title_id) . '"' : ''; ?>>
        <?php if ($args['show_title'] && $set['title'] !== '') : ?>
            <h<?php echo $h; ?> class="tw-faq__title" id="<?php echo esc_attr($title_id); ?>"><?php echo esc_html($set['title']); ?></h<?php echo $h; ?>>
        <?php endif; ?>
        <?php if ($set['intro'] !== '') : ?>
            <div class="tw-faq__intro"><?php echo wp_kses_post(wpautop($set['intro'])); ?></div>
        <?php endif; ?>
        <?php foreach ($groups as $sslug => $items) : ?>
            <div class="tw-faq__group"<?php echo $sslug !== '' ? ' id="' . esc_attr('faq-' . $set['slug'] . '-' . $sslug) . '"' : ''; ?>>
                <?php if ($sslug !== '' && isset($set['sections'][$sslug])) : ?>
                    <h<?php echo $hs; ?> class="tw-faq__group-title"><?php echo esc_html($set['sections'][$sslug]['title']); ?></h<?php echo $hs; ?>>
                    <?php if ($set['sections'][$sslug]['desc'] !== '') : ?>
                        <p class="tw-faq__group-desc"><?php echo esc_html($set['sections'][$sslug]['desc']); ?></p>
                    <?php endif; ?>
                <?php endif; ?>
                <?php foreach ($items as $item) : ?>
                    <details class="tw-faq__item" id="<?php echo esc_attr($item['anchor']); ?>"<?php echo ($first && $args['open_first']) ? ' open' : ''; ?>>
                        <summary class="tw-faq__question"><?php echo esc_html($item['question']); ?></summary>
                        <div class="tw-faq__answer"><?php echo wp_kses_post(wpautop($item['answer'])); ?></div>
                    </details>
                    <?php $first = false; ?>
                <?php endforeach; ?>
            </div>
        <?php endforeach; ?>
    </section>
    <?php
}

function ticinoweb_faq_shortcode($atts) {
    $atts = shortcode_atts(array(
        'scheda' => '',
        'id'     => '',
        'titolo' => 'si',
        'aperta' => 'no',
        'livello' => '2',
    ), $atts, 'tw_faq');
    $ref = $atts['scheda'] !== '' ? $atts['scheda'] : $atts['id'];
    return ticinoweb_faq_render($ref, array(
        'show_title'    => !in_array(strtolower($atts['titolo']), array('no', '0', 'false'), true),
        'open_first'    => in_array(strtolower($atts['aperta']), array('si', 'sì', '1', 'true'), true),
        'heading_level' => (int) $atts['livello'],
    ));
}

function ticinoweb_faq_block_render($attributes) {
    if (empty($attributes['scheda'])) {
        return '';
    }
    return ticinoweb_faq_render($attributes['scheda'], array('show_title' => !empty($attributes['showTitle'])));
}

/** Scheda scelta nel box "FAQ della pagina": aggiunta in fondo al contenuto. */
add_filter('the_content', 'ticinoweb_faq_append_to_content', 20);
function ticinoweb_faq_append_to_content($content) {
    static $done = array();
    if (is_admin() || !is_singular() || !in_the_loop() || !is_main_query()) {
        return $content;
    }
    $post_id = get_the_ID();
    if (!$post_id || isset($done[$post_id])) {
        return $content;
    }
    $ref = get_post_meta($post_id, TICINOWEB_FAQ_META_PAGE, true);
    if (!$ref) {
        return $content;
    }
    $done[$post_id] = true;
    return $content . ticinoweb_faq_render($ref);
}

add_action('wp_enqueue_scripts', 'ticinoweb_faq_enqueue_style');
function ticinoweb_faq_enqueue_style() {
    // Caricata subito (nell'head) quando si sa gia' che la pagina ha FAQ;
    // altrimenti ticinoweb_faq_render() la accoda al momento.
    if (is_singular()) {
        $post = get_queried_object();
        if ($post instanceof WP_Post && (get_post_meta($post->ID, TICINOWEB_FAQ_META_PAGE, true)
            || has_shortcode($post->post_content, 'tw_faq')
            || (function_exists('has_block') && has_block('ticinoweb/faq', $post)))) {
            wp_enqueue_style('ticinoweb-faq');
        }
    }
}

/* -------------------------------------------------------------------------
 * JSON-LD FAQPage: uno solo per pagina con tutte le domande mostrate.
 * ---------------------------------------------------------------------- */

/**
 * Aggiunge domande al FAQPage della pagina. Usala anche nei template dei child
 * che mostrano le FAQ con un design proprio.
 *
 * @param array $items Item con chiavi question/answer (come da ticinoweb_faq_get_set()).
 */
function ticinoweb_faq_schema_add($items) {
    global $ticinoweb_faq_schema_items;
    if (!is_array($ticinoweb_faq_schema_items)) {
        $ticinoweb_faq_schema_items = array();
    }
    foreach ((array) $items as $item) {
        if (empty($item['question']) || empty($item['answer'])) {
            continue;
        }
        $key = md5(wp_strip_all_tags($item['question']));
        $ticinoweb_faq_schema_items[$key] = $item;
    }
}

/** Link relativi resi assoluti: nei dati strutturati il testo e' letto fuori dalla pagina. */
function ticinoweb_faq_absolute_links($html) {
    return preg_replace_callback('/href="(\/[^"\/][^"]*|\/)"/', function ($m) {
        return 'href="' . esc_url(home_url($m[1])) . '"';
    }, $html);
}

add_action('wp_footer', 'ticinoweb_faq_print_schema', 20);
function ticinoweb_faq_print_schema() {
    global $ticinoweb_faq_schema_items;
    if (empty($ticinoweb_faq_schema_items)) {
        return;
    }
    $allowed = array('a' => array('href' => true), 'p' => array(), 'br' => array(), 'ul' => array(), 'ol' => array(), 'li' => array(), 'b' => array(), 'strong' => array(), 'i' => array(), 'em' => array(), 'h3' => array(), 'h4' => array());
    $entities = array();
    foreach ($ticinoweb_faq_schema_items as $item) {
        $entities[] = array(
            '@type'          => 'Question',
            'name'           => wp_strip_all_tags($item['question']),
            'acceptedAnswer' => array(
                '@type' => 'Answer',
                'text'  => ticinoweb_faq_absolute_links(trim(wp_kses(wpautop($item['answer']), $allowed))),
            ),
        );
    }
    $schema = apply_filters('ticinoweb_faq_schema', array(
        '@context'   => 'https://schema.org',
        '@type'      => 'FAQPage',
        'mainEntity' => $entities,
    ));
    if (empty($schema) || empty($schema['mainEntity'])) {
        return;
    }
    echo '<script type="application/ld+json">' . wp_json_encode($schema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_HEX_TAG) . '</script>' . "\n";
}

/* -------------------------------------------------------------------------
 * Scrittura (editor e migrazioni)
 * ---------------------------------------------------------------------- */

/** Pulisce un elenco di domande arrivato dall'editor o da una migrazione. */
function ticinoweb_faq_sanitize_items($raw) {
    $fields = ticinoweb_faq_item_fields();
    $items  = array();
    foreach ((array) $raw as $row) {
        if (!is_array($row)) {
            continue;
        }
        $q = isset($row['q']) ? sanitize_text_field(wp_unslash($row['q'])) : '';
        $a = isset($row['a']) ? wp_kses_post(wp_unslash($row['a'])) : '';
        if ($q === '' && trim(wp_strip_all_tags($a)) === '') {
            continue;
        }
        $id = isset($row['id']) ? preg_replace('/[^a-z0-9]/', '', strtolower((string) $row['id'])) : '';
        $extra = array();
        foreach ($fields as $key => $field) {
            $value = isset($row['extra'][$key]) ? wp_unslash($row['extra'][$key]) : '';
            if ($field['type'] === 'checkbox') {
                $extra[$key] = !empty($value);
            } elseif ($field['type'] === 'url') {
                $extra[$key] = esc_url_raw(trim((string) $value));
            } else {
                $extra[$key] = sanitize_text_field((string) $value);
            }
        }
        $items[] = array(
            'id'      => $id !== '' ? substr($id, 0, 16) : substr(md5(uniqid('', true)), 0, 10),
            'q'       => $q,
            'a'       => $a,
            'section' => isset($row['section']) ? sanitize_text_field(wp_unslash($row['section'])) : '',
            'visible' => !isset($row['visible']) || !empty($row['visible']),
            'extra'   => $extra,
        );
    }
    return $items;
}

/**
 * Crea o aggiorna una scheda (per seed e migrazioni dei child). Idempotente per slug.
 * I valori arrivano gia' "non slashati": vengono slashati qui per la sanitizzazione.
 *
 * @param string $slug
 * @param string $title
 * @param array  $items    [ ['q','a','section','visible','extra'] ]
 * @param array  $args     intro (string), sections (nome => descrizione)
 * @return int|WP_Error ID della scheda
 */
function ticinoweb_faq_upsert_set($slug, $title, $items, $args = array()) {
    $slug = sanitize_title($slug);
    $existing = get_posts(array('post_type' => 'tw_faq', 'name' => $slug, 'post_status' => 'any', 'numberposts' => 1, 'suppress_filters' => true));
    $postarr = array(
        'post_type'   => 'tw_faq',
        'post_title'  => wp_strip_all_tags($title),
        'post_name'   => $slug,
        'post_status' => 'publish',
    );
    if ($existing) {
        $postarr['ID'] = $existing[0]->ID;
    }
    $post_id = $existing ? wp_update_post($postarr, true) : wp_insert_post($postarr, true);
    if (is_wp_error($post_id)) {
        return $post_id;
    }
    update_post_meta($post_id, TICINOWEB_FAQ_META_ITEMS, ticinoweb_faq_sanitize_items(wp_slash($items)));
    if (isset($args['intro'])) {
        update_post_meta($post_id, TICINOWEB_FAQ_META_INTRO, wp_kses_post($args['intro']));
    }
    if (isset($args['sections']) && is_array($args['sections'])) {
        $sections = array();
        foreach ($args['sections'] as $name => $desc) {
            $sections[sanitize_text_field($name)] = sanitize_textarea_field($desc);
        }
        update_post_meta($post_id, TICINOWEB_FAQ_META_SECTIONS, $sections);
    }
    return $post_id;
}

/* -------------------------------------------------------------------------
 * Admin: editor della scheda
 * ---------------------------------------------------------------------- */

add_action('add_meta_boxes_tw_faq', 'ticinoweb_faq_meta_boxes');
function ticinoweb_faq_meta_boxes() {
    add_meta_box('tw_faq_items', __('Domande e risposte', 'ticinoweb-ai-theme'), 'ticinoweb_faq_items_box', 'tw_faq', 'normal', 'high');
    add_meta_box('tw_faq_publish_help', __('Dove mostrarla', 'ticinoweb-ai-theme'), 'ticinoweb_faq_usage_box', 'tw_faq', 'side', 'default');
}

add_filter('post_updated_messages', function ($messages) {
    $msg = __('Scheda FAQ salvata.', 'ticinoweb-ai-theme');
    $messages['tw_faq'] = array(
        1  => $msg,
        4  => $msg,
        6  => __('Scheda FAQ pubblicata.', 'ticinoweb-ai-theme'),
        7  => $msg,
        8  => $msg,
        10 => __('Bozza della scheda FAQ salvata.', 'ticinoweb-ai-theme'),
    );
    return $messages;
});

add_filter('enter_title_here', function ($text, $post) {
    return $post && $post->post_type === 'tw_faq' ? __('Nome della scheda (es. "FAQ Home" o "FAQ Servizi")', 'ticinoweb-ai-theme') : $text;
}, 10, 2);

add_action('admin_enqueue_scripts', 'ticinoweb_faq_admin_assets');
function ticinoweb_faq_admin_assets($hook) {
    $screen = get_current_screen();
    if (!$screen) {
        return;
    }
    if ($screen->post_type === 'tw_faq') {
        wp_enqueue_style('ticinoweb-faq-admin', get_template_directory_uri() . '/assets/css/tw-faq-admin.css', array(), TICINOWEB_THEME_VERSION);
    }
    if ($screen->post_type === 'tw_faq' && in_array($hook, array('post.php', 'post-new.php'), true)) {
        wp_enqueue_editor();
        wp_enqueue_script('jquery-ui-sortable');
        wp_enqueue_script('ticinoweb-faq-admin', get_template_directory_uri() . '/assets/js/tw-faq-admin.js', array('jquery', 'jquery-ui-sortable', 'editor'), TICINOWEB_THEME_VERSION, true);
        wp_localize_script('ticinoweb-faq-admin', 'twFaqAdmin', array(
            'confirmDelete' => __('Eliminare questa domanda?', 'ticinoweb-ai-theme'),
            'newQuestion'   => __('Nuova domanda', 'ticinoweb-ai-theme'),
            'copied'        => __('Copiato!', 'ticinoweb-ai-theme'),
        ));
    }
    if ($screen->base === 'edit' && $screen->post_type === 'tw_faq') {
        wp_enqueue_script('ticinoweb-faq-admin-list', get_template_directory_uri() . '/assets/js/tw-faq-admin.js', array('jquery'), TICINOWEB_THEME_VERSION, true);
        wp_localize_script('ticinoweb-faq-admin-list', 'twFaqAdmin', array('copied' => __('Copiato!', 'ticinoweb-ai-theme')));
    }
}

function ticinoweb_faq_item_card($index, $item, $fields, $sections) {
    $q       = isset($item['q']) ? $item['q'] : '';
    $a       = isset($item['a']) ? $item['a'] : '';
    $section = isset($item['section']) ? $item['section'] : '';
    $visible = !isset($item['visible']) || $item['visible'];
    $id      = isset($item['id']) ? $item['id'] : '';
    $name    = 'tw_faq_items[' . $index . ']';
    $editor  = 'tw_faq_a_' . $index;
    ?>
    <div class="tw-faq-card<?php echo $visible ? '' : ' is-hidden'; ?>" data-index="<?php echo esc_attr($index); ?>">
        <div class="tw-faq-card__head">
            <span class="tw-faq-card__drag dashicons dashicons-move" title="<?php esc_attr_e('Trascina per riordinare', 'ticinoweb-ai-theme'); ?>"></span>
            <button type="button" class="tw-faq-card__toggle" aria-expanded="false">
                <span class="tw-faq-card__label"><?php echo $q !== '' ? esc_html($q) : esc_html__('Nuova domanda', 'ticinoweb-ai-theme'); ?></span>
                <span class="tw-faq-card__badge tw-faq-card__badge--section"<?php echo $section === '' ? ' hidden' : ''; ?>><?php echo esc_html($section); ?></span>
                <span class="tw-faq-card__badge tw-faq-card__badge--hidden"><?php esc_html_e('Nascosta', 'ticinoweb-ai-theme'); ?></span>
            </button>
            <button type="button" class="tw-faq-card__remove" aria-label="<?php esc_attr_e('Elimina domanda', 'ticinoweb-ai-theme'); ?>"><span class="dashicons dashicons-trash"></span></button>
        </div>
        <div class="tw-faq-card__body" hidden>
            <input type="hidden" name="<?php echo esc_attr($name); ?>[id]" value="<?php echo esc_attr($id); ?>">
            <p>
                <label class="tw-faq-field-label"><?php esc_html_e('Domanda', 'ticinoweb-ai-theme'); ?></label>
                <input type="text" class="widefat tw-faq-q" name="<?php echo esc_attr($name); ?>[q]" value="<?php echo esc_attr($q); ?>" placeholder="<?php esc_attr_e('Scrivila come la farebbe un cliente, es. "Quanto costa una consulenza?"', 'ticinoweb-ai-theme'); ?>">
            </p>
            <div class="tw-faq-answer">
                <label class="tw-faq-field-label" for="<?php echo esc_attr($editor); ?>"><?php esc_html_e('Risposta', 'ticinoweb-ai-theme'); ?></label>
                <textarea class="widefat tw-faq-a" id="<?php echo esc_attr($editor); ?>" name="<?php echo esc_attr($name); ?>[a]" rows="6"><?php echo esc_textarea($a); ?></textarea>
                <p class="description"><?php esc_html_e('Rispondi subito alla domanda nella prima frase: è quella che Google e gli assistenti AI riportano.', 'ticinoweb-ai-theme'); ?></p>
            </div>
            <div class="tw-faq-card__row">
                <p>
                    <label class="tw-faq-field-label"><?php esc_html_e('Sezione (facoltativa)', 'ticinoweb-ai-theme'); ?></label>
                    <input type="text" class="widefat tw-faq-section" list="tw-faq-sections" name="<?php echo esc_attr($name); ?>[section]" value="<?php echo esc_attr($section); ?>" placeholder="<?php esc_attr_e('es. Prezzi, Consegna, Assistenza', 'ticinoweb-ai-theme'); ?>">
                </p>
                <p class="tw-faq-visible">
                    <input type="hidden" name="<?php echo esc_attr($name); ?>[visible]" value="0">
                    <label><input type="checkbox" class="tw-faq-visible-input" name="<?php echo esc_attr($name); ?>[visible]" value="1" <?php checked($visible); ?>> <?php esc_html_e('Visibile sul sito', 'ticinoweb-ai-theme'); ?></label>
                </p>
            </div>
            <?php if ($fields) : ?>
                <div class="tw-faq-card__extra">
                    <?php foreach ($fields as $key => $field) :
                        $value = isset($item['extra'][$key]) ? $item['extra'][$key] : '';
                        $fname = $name . '[extra][' . $key . ']';
                        ?>
                        <p>
                            <?php if ($field['type'] === 'checkbox') : ?>
                                <label><input type="checkbox" name="<?php echo esc_attr($fname); ?>" value="1" <?php checked(!empty($value)); ?>> <?php echo esc_html($field['label']); ?></label>
                            <?php else : ?>
                                <label class="tw-faq-field-label"><?php echo esc_html($field['label']); ?></label>
                                <input type="text" class="widefat" name="<?php echo esc_attr($fname); ?>" value="<?php echo esc_attr($value); ?>">
                            <?php endif; ?>
                            <?php if ($field['help'] !== '') : ?>
                                <span class="description"><?php echo esc_html($field['help']); ?></span>
                            <?php endif; ?>
                        </p>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
    <?php
}

function ticinoweb_faq_items_box($post) {
    wp_nonce_field('tw_faq_save', 'tw_faq_nonce');
    $items    = ticinoweb_faq_raw_items($post->ID);
    $fields   = ticinoweb_faq_item_fields();
    $intro    = (string) get_post_meta($post->ID, TICINOWEB_FAQ_META_INTRO, true);
    $sections = get_post_meta($post->ID, TICINOWEB_FAQ_META_SECTIONS, true);
    $sections = is_array($sections) ? $sections : array();
    $names    = array_values(array_unique(array_filter(array_merge(array_column($items, 'section'), array_keys($sections)))));
    ?>
    <div class="tw-faq-editor">
        <p class="tw-faq-editor__intro-field">
            <label class="tw-faq-field-label" for="tw_faq_intro"><?php esc_html_e('Introduzione (facoltativa)', 'ticinoweb-ai-theme'); ?></label>
            <textarea id="tw_faq_intro" class="widefat" name="tw_faq_intro" rows="2" placeholder="<?php esc_attr_e('Una frase mostrata sotto il titolo, es. "Le risposte alle domande che ci fate più spesso."', 'ticinoweb-ai-theme'); ?>"><?php echo esc_textarea($intro); ?></textarea>
        </p>

        <div class="tw-faq-toolbar">
            <strong class="tw-faq-count" data-label="<?php esc_attr_e('%d domande', 'ticinoweb-ai-theme'); ?>"><?php echo esc_html(sprintf(__('%d domande', 'ticinoweb-ai-theme'), count($items))); ?></strong>
            <button type="button" class="button-link tw-faq-expand-all"><?php esc_html_e('Apri tutte', 'ticinoweb-ai-theme'); ?></button>
            <button type="button" class="button-link tw-faq-collapse-all"><?php esc_html_e('Chiudi tutte', 'ticinoweb-ai-theme'); ?></button>
        </div>

        <div class="tw-faq-cards">
            <?php foreach ($items as $i => $item) {
                ticinoweb_faq_item_card($i, $item, $fields, $names);
            } ?>
        </div>

        <div class="tw-faq-empty"<?php echo $items ? ' hidden' : ''; ?>>
            <span class="dashicons dashicons-editor-help"></span>
            <p><?php esc_html_e('Questa scheda non ha ancora domande. Aggiungi la prima: scrivila come la farebbe un cliente.', 'ticinoweb-ai-theme'); ?></p>
        </div>

        <p><button type="button" class="button button-primary button-large tw-faq-add"><span class="dashicons dashicons-plus-alt2"></span> <?php esc_html_e('Aggiungi domanda', 'ticinoweb-ai-theme'); ?></button></p>

        <datalist id="tw-faq-sections">
            <?php foreach ($names as $n) : ?>
                <option value="<?php echo esc_attr($n); ?>"></option>
            <?php endforeach; ?>
        </datalist>

        <div class="tw-faq-sections-box"<?php echo $names ? '' : ' hidden'; ?>>
            <h4><?php esc_html_e('Descrizione delle sezioni (facoltativa)', 'ticinoweb-ai-theme'); ?></h4>
            <p class="description"><?php esc_html_e('Le sezioni compaiono qui quando le scrivi nelle domande. La descrizione è mostrata sotto il titolo della sezione.', 'ticinoweb-ai-theme'); ?></p>
            <div class="tw-faq-sections-list" data-placeholder="<?php esc_attr_e('Una frase che presenta la sezione', 'ticinoweb-ai-theme'); ?>">
                <?php foreach ($names as $n) : ?>
                    <p class="tw-faq-section-row" data-section="<?php echo esc_attr($n); ?>">
                        <label class="tw-faq-field-label"><?php echo esc_html($n); ?></label>
                        <input type="text" class="widefat" name="tw_faq_sections[<?php echo esc_attr($n); ?>]" value="<?php echo esc_attr(isset($sections[$n]) ? $sections[$n] : ''); ?>" placeholder="<?php esc_attr_e('Una frase che presenta la sezione', 'ticinoweb-ai-theme'); ?>">
                    </p>
                <?php endforeach; ?>
            </div>
        </div>

        <script type="text/html" id="tmpl-tw-faq-card">
            <?php ticinoweb_faq_item_card('__INDEX__', array('visible' => true), $fields, $names); ?>
        </script>
    </div>
    <?php
}

/** Pagine in cui la scheda e' usata (box della pagina, shortcode o blocco). */
function ticinoweb_faq_usage($post) {
    global $wpdb;
    $ids = get_posts(array(
        'post_type'        => 'any',
        'post_status'      => array('publish', 'draft', 'private', 'future'),
        'meta_key'         => TICINOWEB_FAQ_META_PAGE,
        'meta_value'       => $post->post_name,
        'fields'           => 'ids',
        'numberposts'      => 50,
        'suppress_filters' => true,
    ));
    if ($post->post_name !== '') {
        $like_sc  = '%' . $wpdb->esc_like('[tw_faq') . '%' . $wpdb->esc_like($post->post_name) . '%';
        $like_blk = '%' . $wpdb->esc_like('wp:ticinoweb/faq') . '%' . $wpdb->esc_like('"' . $post->post_name . '"') . '%';
        $like_el  = '%' . $wpdb->esc_like('"tw_faq_scheda":"' . $post->post_name . '"') . '%';
        $more = $wpdb->get_col($wpdb->prepare(
            "SELECT ID FROM {$wpdb->posts} WHERE post_status IN ('publish','draft','private','future') AND post_type NOT IN ('revision','tw_faq') AND (post_content LIKE %s OR post_content LIKE %s) LIMIT 50",
            $like_sc,
            $like_blk
        ));
        $el = $wpdb->get_col($wpdb->prepare(
            "SELECT p.ID FROM {$wpdb->postmeta} m JOIN {$wpdb->posts} p ON p.ID = m.post_id WHERE m.meta_key = '_elementor_data' AND m.meta_value LIKE %s AND p.post_status IN ('publish','draft','private','future') AND p.post_type <> 'revision' LIMIT 50",
            $like_el
        ));
        $ids = array_merge($ids, array_map('intval', $more), array_map('intval', $el));
    }
    return array_values(array_unique(array_map('intval', $ids)));
}

function ticinoweb_faq_usage_box($post) {
    $slug = $post->post_name;
    ?>
    <div class="tw-faq-usage">
        <?php if ($post->post_status !== 'publish' || $slug === '') : ?>
            <p><?php esc_html_e('Pubblica la scheda per poterla inserire nelle pagine.', 'ticinoweb-ai-theme'); ?></p>
        <?php else : ?>
            <ol class="tw-faq-usage__steps">
                <li><?php esc_html_e('In fondo a una pagina: apri la pagina e scegli questa scheda nel box "FAQ della pagina".', 'ticinoweb-ai-theme'); ?></li>
                <li><?php esc_html_e('Con Elementor o con l\'editor a blocchi: aggiungi l\'elemento "FAQ ticinoWEB" e scegli la scheda.', 'ticinoweb-ai-theme'); ?></li>
                <li><?php esc_html_e('In un testo qualsiasi: incolla questo codice.', 'ticinoweb-ai-theme'); ?>
                    <span class="tw-faq-copy">
                        <code>[tw_faq scheda="<?php echo esc_html($slug); ?>"]</code>
                        <button type="button" class="button button-small tw-faq-copy__btn" data-copy="<?php echo esc_attr('[tw_faq scheda="' . $slug . '"]'); ?>"><?php esc_html_e('Copia', 'ticinoweb-ai-theme'); ?></button>
                    </span>
                </li>
            </ol>
            <?php $used = ticinoweb_faq_usage($post); ?>
            <h4><?php esc_html_e('Usata in', 'ticinoweb-ai-theme'); ?></h4>
            <?php if ($used) : ?>
                <ul class="tw-faq-usage__list">
                    <?php foreach ($used as $pid) : ?>
                        <li><a href="<?php echo esc_url(get_edit_post_link($pid)); ?>"><?php echo esc_html(get_the_title($pid) ?: __('(senza titolo)', 'ticinoweb-ai-theme')); ?></a></li>
                    <?php endforeach; ?>
                </ul>
            <?php else : ?>
                <p class="description"><?php esc_html_e('Non ancora inserita in nessuna pagina.', 'ticinoweb-ai-theme'); ?></p>
            <?php endif; ?>
        <?php endif; ?>
    </div>
    <?php
}

add_action('save_post_tw_faq', 'ticinoweb_faq_save', 10, 2);
function ticinoweb_faq_save($post_id, $post) {
    if (!isset($_POST['tw_faq_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['tw_faq_nonce'])), 'tw_faq_save')) {
        return;
    }
    if ((defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) || wp_is_post_revision($post_id) || !current_user_can('edit_post', $post_id)) {
        return;
    }

    $raw = isset($_POST['tw_faq_items']) && is_array($_POST['tw_faq_items']) ? $_POST['tw_faq_items'] : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- sanitizzato in ticinoweb_faq_sanitize_items()
    unset($raw['__INDEX__']);
    update_post_meta($post_id, TICINOWEB_FAQ_META_ITEMS, ticinoweb_faq_sanitize_items($raw));

    $intro = isset($_POST['tw_faq_intro']) ? sanitize_textarea_field(wp_unslash($_POST['tw_faq_intro'])) : '';
    update_post_meta($post_id, TICINOWEB_FAQ_META_INTRO, $intro);

    $sections = array();
    if (isset($_POST['tw_faq_sections']) && is_array($_POST['tw_faq_sections'])) {
        foreach (wp_unslash($_POST['tw_faq_sections']) as $name => $desc) { // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
            $name = sanitize_text_field($name);
            if ($name !== '') {
                $sections[$name] = sanitize_textarea_field($desc);
            }
        }
    }
    update_post_meta($post_id, TICINOWEB_FAQ_META_SECTIONS, $sections);
}

/* Elenco schede: numero di domande, codice da copiare, pagine in cui e' usata. */
add_filter('manage_tw_faq_posts_columns', function ($cols) {
    $new = array();
    foreach ($cols as $key => $label) {
        if ($key === 'date') {
            continue;
        }
        $new[$key] = $key === 'title' ? __('Scheda', 'ticinoweb-ai-theme') : $label;
        if ($key === 'title') {
            $new['tw_faq_count'] = __('Domande', 'ticinoweb-ai-theme');
            $new['tw_faq_code']  = __('Codice', 'ticinoweb-ai-theme');
            $new['tw_faq_used']  = __('Usata in', 'ticinoweb-ai-theme');
        }
    }
    return $new;
});

add_action('manage_tw_faq_posts_custom_column', function ($col, $post_id) {
    $post = get_post($post_id);
    if ($col === 'tw_faq_count') {
        $items = ticinoweb_faq_raw_items($post_id);
        $hidden = count(array_filter($items, function ($i) { return isset($i['visible']) && !$i['visible']; }));
        echo esc_html(count($items));
        if ($hidden) {
            echo ' <span class="description">' . esc_html(sprintf(__('(%d nascoste)', 'ticinoweb-ai-theme'), $hidden)) . '</span>';
        }
    } elseif ($col === 'tw_faq_code' && $post->post_name !== '') {
        $code = '[tw_faq scheda="' . $post->post_name . '"]';
        echo '<span class="tw-faq-copy"><code>' . esc_html($code) . '</code> <button type="button" class="button button-small tw-faq-copy__btn" data-copy="' . esc_attr($code) . '">' . esc_html__('Copia', 'ticinoweb-ai-theme') . '</button></span>';
    } elseif ($col === 'tw_faq_used') {
        $used = ticinoweb_faq_usage($post);
        if (!$used) {
            echo '<span class="description">' . esc_html__('Non ancora inserita', 'ticinoweb-ai-theme') . '</span>';
            return;
        }
        $links = array();
        foreach (array_slice($used, 0, 3) as $pid) {
            $links[] = '<a href="' . esc_url(get_edit_post_link($pid)) . '">' . esc_html(get_the_title($pid)) . '</a>';
        }
        echo implode(', ', $links); // phpcs:ignore WordPress.Security.EscapeOutput -- escapato sopra
        if (count($used) > 3) {
            echo ' ' . esc_html(sprintf(__('e altre %d', 'ticinoweb-ai-theme'), count($used) - 3));
        }
    }
}, 10, 2);

/* -------------------------------------------------------------------------
 * Box "FAQ della pagina" nell'editor di pagine e articoli
 * ---------------------------------------------------------------------- */

function ticinoweb_faq_page_post_types() {
    return apply_filters('ticinoweb_faq_page_post_types', array('page', 'post'));
}

add_action('add_meta_boxes', function () {
    foreach (ticinoweb_faq_page_post_types() as $type) {
        add_meta_box('tw_faq_page', __('FAQ della pagina', 'ticinoweb-ai-theme'), 'ticinoweb_faq_page_box', $type, 'side', 'default');
    }
});

function ticinoweb_faq_page_box($post) {
    wp_nonce_field('tw_faq_page_save', 'tw_faq_page_nonce');
    $current = (string) get_post_meta($post->ID, TICINOWEB_FAQ_META_PAGE, true);
    $choices = ticinoweb_faq_choices();
    if (!$choices) {
        echo '<p>' . esc_html__('Non ci sono ancora schede FAQ.', 'ticinoweb-ai-theme') . '</p>';
        echo '<p><a class="button" href="' . esc_url(admin_url('post-new.php?post_type=tw_faq')) . '">' . esc_html__('Crea una scheda FAQ', 'ticinoweb-ai-theme') . '</a></p>';
        return;
    }
    ?>
    <p>
        <label for="tw_faq_page_set" class="screen-reader-text"><?php esc_html_e('Scheda FAQ', 'ticinoweb-ai-theme'); ?></label>
        <select id="tw_faq_page_set" name="tw_faq_page_set" class="widefat">
            <option value=""><?php esc_html_e('— Nessuna —', 'ticinoweb-ai-theme'); ?></option>
            <?php foreach ($choices as $slug => $title) : ?>
                <option value="<?php echo esc_attr($slug); ?>" <?php selected($current, $slug); ?>><?php echo esc_html($title); ?></option>
            <?php endforeach; ?>
        </select>
    </p>
    <p class="description"><?php esc_html_e('La scheda scelta compare in fondo alla pagina, con i dati strutturati per Google e gli assistenti AI.', 'ticinoweb-ai-theme'); ?></p>
    <?php if ($current !== '') :
        $faq = ticinoweb_faq_find($current);
        if ($faq) : ?>
            <p><a href="<?php echo esc_url(get_edit_post_link($faq->ID)); ?>"><?php esc_html_e('Modifica le domande di questa scheda', 'ticinoweb-ai-theme'); ?></a></p>
        <?php endif;
    endif; ?>
    <?php
}

add_action('save_post', function ($post_id) {
    if (!isset($_POST['tw_faq_page_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['tw_faq_page_nonce'])), 'tw_faq_page_save')) {
        return;
    }
    if ((defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) || wp_is_post_revision($post_id) || !current_user_can('edit_post', $post_id)) {
        return;
    }
    $value = isset($_POST['tw_faq_page_set']) ? sanitize_title(wp_unslash($_POST['tw_faq_page_set'])) : '';
    if ($value === '') {
        delete_post_meta($post_id, TICINOWEB_FAQ_META_PAGE);
    } else {
        update_post_meta($post_id, TICINOWEB_FAQ_META_PAGE, $value);
    }
});

/* Dati per il blocco Gutenberg: elenco schede per il selettore. */
add_action('enqueue_block_editor_assets', function () {
    $options = array(array('value' => '', 'label' => __('— Scegli una scheda —', 'ticinoweb-ai-theme')));
    foreach (ticinoweb_faq_choices() as $slug => $title) {
        $options[] = array('value' => $slug, 'label' => $title);
    }
    wp_localize_script('ticinoweb-faq-block', 'twFaqBlock', array(
        'options' => $options,
        'newUrl'  => admin_url('post-new.php?post_type=tw_faq'),
    ));
});

/* Widget Elementor "FAQ ticinoWEB". */
add_action('elementor/widgets/register', function ($widgets_manager) {
    require_once get_template_directory() . '/inc/faq-elementor.php';
    $widgets_manager->register(new TicinoWEB_FAQ_Elementor_Widget());
});
