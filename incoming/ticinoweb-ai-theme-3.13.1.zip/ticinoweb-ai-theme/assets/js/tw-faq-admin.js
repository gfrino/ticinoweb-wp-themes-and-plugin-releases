/**
 * Editor delle schede FAQ: schede domanda richiudibili, aggiunta, eliminazione,
 * riordino a trascinamento, editor della risposta caricato alla prima apertura,
 * sezioni sincronizzate, pulsanti "Copia".
 */
(function ($) {
    var L = window.twFaqAdmin || {};

    // Pulsanti "Copia" (anche nell'elenco delle schede).
    $(document).on('click', '.tw-faq-copy__btn', function () {
        var btn = $(this), text = btn.data('copy'), label = btn.text();
        var done = function () {
            btn.text(L.copied || 'OK');
            setTimeout(function () { btn.text(label); }, 1500);
        };
        if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(text).then(done);
        } else {
            var t = $('<textarea>').val(text).appendTo('body').select();
            document.execCommand('copy');
            t.remove();
            done();
        }
    });

    var $editor = $('.tw-faq-editor');
    if (!$editor.length) {
        return;
    }
    var $cards = $editor.find('.tw-faq-cards');
    var next = $cards.children().length;

    function editorId($card) {
        return $card.find('textarea.tw-faq-a').attr('id');
    }

    function initEditor($card) {
        var id = editorId($card);
        if (!id || $card.data('editor') || !window.wp || !wp.editor) {
            return;
        }
        if (!window.tinymce) {
            // TinyMCE viene caricato dopo questo script: riprova appena c'e'.
            setTimeout(function () { initEditor($card); }, 200);
            return;
        }
        wp.editor.initialize(id, {
            tinymce: {
                toolbar1: 'bold,italic,link,unlink,bullist,numlist,undo,redo',
                toolbar2: '',
                height: 160,
                menubar: false,
                setup: function (ed) {
                    ed.on('change keyup', function () { ed.save(); });
                }
            },
            quicktags: { buttons: 'strong,em,link,ul,ol,li' },
            mediaButtons: false
        });
        $card.data('editor', true);
    }

    function removeEditor($card) {
        var id = editorId($card);
        if (!$card.data('editor') || !window.wp || !wp.editor) {
            return;
        }
        if (window.tinymce && tinymce.get(id)) {
            tinymce.get(id).save();
        }
        wp.editor.remove(id);
        $card.data('editor', false);
    }

    function setOpen($card, open) {
        $card.toggleClass('is-open', open);
        $card.find('.tw-faq-card__toggle').attr('aria-expanded', open ? 'true' : 'false');
        $card.find('.tw-faq-card__body').prop('hidden', !open);
        if (open) {
            initEditor($card);
        }
    }

    function refresh() {
        var n = $cards.children('.tw-faq-card').length;
        var $count = $editor.find('.tw-faq-count');
        $count.text(($count.data('label') || '%d').replace('%d', n));
        $editor.find('.tw-faq-empty').prop('hidden', n > 0);
        syncSections();
    }

    // Le sezioni scritte nelle domande compaiono nel box delle descrizioni.
    function syncSections() {
        var names = [];
        $cards.find('.tw-faq-section').each(function () {
            var v = $.trim($(this).val());
            if (v && names.indexOf(v) === -1) {
                names.push(v);
            }
        });
        var $list = $editor.find('.tw-faq-sections-list');
        var placeholder = $list.data('placeholder') || '';
        $list.children('.tw-faq-section-row').each(function () {
            var $row = $(this);
            if (names.indexOf($row.data('section')) === -1 && !$.trim($row.find('input').val())) {
                $row.remove();
            }
        });
        names.forEach(function (name) {
            var exists = false;
            $list.children('.tw-faq-section-row').each(function () {
                if ($(this).data('section') === name) { exists = true; }
            });
            if (!exists) {
                var $row = $('<p class="tw-faq-section-row">').attr('data-section', name).data('section', name);
                $row.append($('<label class="tw-faq-field-label">').text(name));
                $row.append($('<input type="text" class="widefat">').attr('name', 'tw_faq_sections[' + name + ']').attr('placeholder', placeholder));
                $list.append($row);
            }
        });
        $editor.find('.tw-faq-sections-box').prop('hidden', $list.children().length === 0);
        var $dl = $('#tw-faq-sections').empty();
        names.forEach(function (name) { $dl.append($('<option>').attr('value', name)); });
    }

    $editor.on('click', '.tw-faq-card__toggle', function () {
        var $card = $(this).closest('.tw-faq-card');
        setOpen($card, !$card.hasClass('is-open'));
    });

    $editor.on('click', '.tw-faq-expand-all', function () {
        $cards.children('.tw-faq-card').each(function () { setOpen($(this), true); });
    });
    $editor.on('click', '.tw-faq-collapse-all', function () {
        $cards.children('.tw-faq-card').each(function () { setOpen($(this), false); });
    });

    function addCard(focus) {
        var html = $('#tmpl-tw-faq-card').html().replace(/__INDEX__/g, 'n' + (next++));
        var $card = $(html);
        $cards.append($card);
        setOpen($card, true);
        refresh();
        if (focus) {
            $card.find('.tw-faq-q').trigger('focus');
            $('html, body').animate({ scrollTop: $card.offset().top - 80 }, 200);
        }
    }

    $editor.on('click', '.tw-faq-add', function () {
        addCard(true);
    });

    $editor.on('click', '.tw-faq-card__remove', function () {
        var $card = $(this).closest('.tw-faq-card');
        if (!window.confirm(L.confirmDelete || 'OK?')) {
            return;
        }
        removeEditor($card);
        $card.remove();
        refresh();
    });

    $editor.on('input', '.tw-faq-q', function () {
        var v = $.trim($(this).val());
        $(this).closest('.tw-faq-card').find('.tw-faq-card__label').text(v || L.newQuestion || '');
    });

    $editor.on('input change', '.tw-faq-section', function () {
        var v = $.trim($(this).val());
        $(this).closest('.tw-faq-card').find('.tw-faq-card__badge--section').text(v).prop('hidden', !v);
        syncSections();
    });

    $editor.on('change', '.tw-faq-visible-input', function () {
        $(this).closest('.tw-faq-card').toggleClass('is-hidden', !this.checked);
    });

    $cards.sortable({
        handle: '.tw-faq-card__drag',
        axis: 'y',
        placeholder: 'tw-faq-card tw-faq-card--placeholder',
        forcePlaceholderSize: true,
        start: function (e, ui) {
            ui.item.data('wasOpen', ui.item.hasClass('is-open'));
            removeEditor(ui.item);
        },
        stop: function (e, ui) {
            if (ui.item.data('wasOpen')) {
                initEditor(ui.item);
            }
        }
    });

    // Prima del salvataggio: il testo degli editor aperti torna nelle textarea.
    $('#post').on('submit', function () {
        if (window.tinymce) {
            tinymce.triggerSave();
        }
    });

    // Una scheda nuova parte con una domanda pronta da compilare.
    // (dopo il load: TinyMCE e' caricato dopo questo script).
    $(window).on('load', function () {
        if ($cards.children('.tw-faq-card').length === 0 && $('#auto_draft').val() === '1') {
            addCard(false);
        }
    });
})(jQuery);
