/**
 * Blocco "FAQ ticinoWEB": scelta della scheda per nome, anteprima reale nell'editor.
 */
(function (wp) {
    if (!wp || !wp.blocks) {
        return;
    }
    var el = wp.element.createElement;
    var __ = wp.i18n.__;
    var InspectorControls = wp.blockEditor.InspectorControls;
    var C = wp.components;
    var ServerSideRender = wp.serverSideRender;
    var data = window.twFaqBlock || { options: [], newUrl: '' };

    wp.blocks.registerBlockType('ticinoweb/faq', {
        apiVersion: 2,
        title: __('FAQ ticinoWEB', 'ticinoweb-ai-theme'),
        description: __('Mostra una scheda di domande frequenti, con i dati strutturati per Google e gli assistenti AI.', 'ticinoweb-ai-theme'),
        icon: 'editor-help',
        category: 'widgets',
        keywords: ['faq', 'domande', 'questions'],
        attributes: {
            scheda: { type: 'string', default: '' },
            showTitle: { type: 'boolean', default: true }
        },
        edit: function (props) {
            var a = props.attributes;
            var blockProps = wp.blockEditor.useBlockProps ? wp.blockEditor.useBlockProps() : {};
            var picker = el(C.SelectControl, {
                label: __('Scheda FAQ', 'ticinoweb-ai-theme'),
                value: a.scheda,
                options: data.options,
                onChange: function (v) { props.setAttributes({ scheda: v }); }
            });
            var noSets = data.options.length <= 1;

            return el('div', blockProps,
                el(InspectorControls, {},
                    el(C.PanelBody, { title: __('Scheda FAQ', 'ticinoweb-ai-theme') },
                        picker,
                        el(C.ToggleControl, {
                            label: __('Mostra il titolo della scheda', 'ticinoweb-ai-theme'),
                            checked: a.showTitle,
                            onChange: function (v) { props.setAttributes({ showTitle: v }); }
                        })
                    )
                ),
                a.scheda
                    ? el(ServerSideRender, { block: 'ticinoweb/faq', attributes: a })
                    : el(C.Placeholder, { icon: 'editor-help', label: __('FAQ ticinoWEB', 'ticinoweb-ai-theme') },
                        noSets
                            ? el('a', { href: data.newUrl, target: '_blank', className: 'components-button is-primary' }, __('Crea la prima scheda FAQ', 'ticinoweb-ai-theme'))
                            : picker
                    )
            );
        },
        save: function () {
            return null;
        }
    });
})(window.wp);
