/**
 * Barre dei tab del pannello ticinoWEB (CMS, Impostazioni, tW SEO): sempre su
 * una riga. Se i tab non entrano, la barra scorre in orizzontale (anche con la
 * rotellina), sfuma sul lato che continua e porta in vista il tab attivo.
 */
(function () {
    var bars = document.querySelectorAll('.ticinoweb-settings-tabs .nav-tab-wrapper, .tw-seo-tabs-nav');
    if (!bars.length) {
        return;
    }

    function update(bar) {
        var max = bar.scrollWidth - bar.clientWidth;
        bar.classList.toggle('tw-tabs-more-left', bar.scrollLeft > 2);
        bar.classList.toggle('tw-tabs-more-right', max - bar.scrollLeft > 2);
    }

    function reveal(bar) {
        var active = bar.querySelector('.nav-tab-active, .tw-seo-tab-btn.active');
        if (!active) {
            return;
        }
        var left = active.offsetLeft - bar.offsetLeft;
        var right = left + active.offsetWidth;
        if (left < bar.scrollLeft + 24) {
            bar.scrollLeft = Math.max(0, left - 24);
        } else if (right > bar.scrollLeft + bar.clientWidth - 24) {
            bar.scrollLeft = right - bar.clientWidth + 24;
        }
        update(bar);
    }

    Array.prototype.forEach.call(bars, function (bar) {
        bar.addEventListener('scroll', function () { update(bar); }, { passive: true });
        bar.addEventListener('wheel', function (e) {
            if (bar.scrollWidth <= bar.clientWidth || Math.abs(e.deltaX) > Math.abs(e.deltaY)) {
                return;
            }
            e.preventDefault();
            bar.scrollLeft += e.deltaY;
        }, { passive: false });
        bar.addEventListener('click', function () {
            setTimeout(function () { reveal(bar); }, 0);
        });
        window.addEventListener('resize', function () { update(bar); });
        window.addEventListener('hashchange', function () { setTimeout(function () { reveal(bar); }, 0); });
        setTimeout(function () { reveal(bar); }, 50);
        update(bar);
    });
})();
