document.addEventListener('DOMContentLoaded', () => {
  const video = document.querySelector('.mol-hero-video');
  const play = document.querySelector('.mol-video-play');
  if (!video || !play) return;

  video.controls = false;
  play.hidden = false;
  play.addEventListener('click', () => {
    video.controls = true;
    play.hidden = true;
    video.play().catch(() => {
      // Native controls stay available if autoplay after the click is denied.
    });
  });
});
