<?php
/** Contact page using shared CMS fields. */
get_header();
$phone   = trim( (string) get_option( 'ticinoweb_contact_phone' ) );
$email   = trim( (string) get_option( 'ticinoweb_contact_email' ) );
$address = trim( (string) get_option( 'ticinoweb_contact_address' ) );
$hours   = trim( (string) get_option( 'ticinoweb_contact_opening_hours' ) );
$map_url = trim( (string) get_option( 'ticinoweb_contact_map_url' ) );
?>
<main id="main" class="mol-content">
<?php while ( have_posts() ) : the_post(); ?>
<article <?php post_class(); ?>><h1><?php the_title(); ?></h1><div class="entry-content"><?php the_content(); ?></div>
<div class="mol-contact-grid"><section><h2><?php esc_html_e( 'Vieni a trovarci', 'molinarieco-child-theme' ); ?></h2>
<?php if ( $address ) : ?><p><?php echo esc_html( $address ); ?></p><?php endif; ?>
<?php if ( $map_url ) : ?><p><a href="<?php echo esc_url( $map_url ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Apri la mappa', 'molinarieco-child-theme' ); ?></a></p><?php endif; ?>
</section><section><h2><?php esc_html_e( 'Contattaci', 'molinarieco-child-theme' ); ?></h2>
<?php if ( $phone ) : ?><p><a href="<?php echo esc_url( 'tel:' . preg_replace( '/[^+0-9]/', '', $phone ) ); ?>"><?php echo esc_html( $phone ); ?></a></p><?php endif; ?>
<?php if ( $email ) : ?><p><a href="<?php echo esc_url( 'mailto:' . $email ); ?>"><?php echo esc_html( $email ); ?></a></p><?php endif; ?>
<?php if ( $hours ) : ?><p><?php echo esc_html( $hours ); ?></p><?php endif; ?>
</section></div></article>
<?php endwhile; ?>
</main>
<?php get_footer(); ?>
