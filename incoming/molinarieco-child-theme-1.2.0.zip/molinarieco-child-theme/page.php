<?php
/** Standard content page. */
get_header();
?>
<main id="main" class="mol-content<?php echo is_page( 'servizi' ) ? ' mol-content--services' : ''; ?>">
<?php while ( have_posts() ) : the_post(); ?>
<article <?php post_class(); ?>><h1><?php the_title(); ?></h1><div class="entry-content"><?php the_content(); ?></div></article>
<?php endwhile; ?>
</main>
<?php get_footer(); ?>
