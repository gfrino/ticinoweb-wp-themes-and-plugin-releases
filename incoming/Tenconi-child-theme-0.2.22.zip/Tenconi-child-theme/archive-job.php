<?php
/**
 * JOBS — "Lavora con noi", l'archivio del CPT job reso come la pagina legacy.
 *
 * URL: /jobs/
 *
 * Nel legacy era un elenco di posizioni aperte con il PDF del profilo, piu' un
 * invito alla candidatura spontanea: la stessa famiglia di Certificazioni e
 * Condizioni di vendita. Si delega quindi allo stesso renderer.
 *
 * @package tenconi-child-theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

set_query_var( 'tl_slug', 'jobs' );
get_template_part( 'template-parts/pagine/documenti' );

get_footer();
