<?php
/**
 * Le tre aree di attivita' che vivono su un termine "market".
 *
 * URL: /settori/<slug>/
 *
 * SOSTITUISCE il template della fase Legacy-Modernized, che rendeva questa vista
 * come un archivio con campo scuro e colonna di riferimenti tecnici. Nel legacy
 * non era niente di tutto questo: era una pagina con titolo e due gallerie.
 *
 * Il rendering e' delegato al renderer condiviso della famiglia, lo stesso che
 * serve le due aree ospitate su un contenuto "capability". Un layout, cinque
 * pagine, nessun markup duplicato.
 *
 * @package tenconi-child-theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

$tl_term = get_queried_object();
$tl_slug = ( $tl_term && ! is_wp_error( $tl_term ) ) ? tenconi_legacy_area_chiave( $tl_term->slug ) : '';

/*
 * La mappa legacy e' indicizzata sullo slug legacy, che per queste tre coincide
 * con lo slug del termine. Se un giorno divergesse, la corrispondenza va scritta
 * qui e non indovinata.
 */
/*
 * set_query_var e non il terzo argomento di get_template_part: load_template fa
 * extract() sulle query vars, quindi la variabile arriva nel template part come
 * $tl_slug. Passandola in $args arriverebbe come $args['tl_slug'], che il
 * renderer condiviso non legge.
 */
set_query_var( 'tl_slug', $tl_slug );
get_template_part( 'template-parts/aree/pagina' );

get_footer();
