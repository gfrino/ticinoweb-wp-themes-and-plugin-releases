<?php
/**
 * PARCO MACCHINE — l'archivio del CPT machine, reso come la pagina legacy.
 *
 * URL: /parco-macchine/
 *
 * SOSTITUISCE archive.php della fase Legacy-Modernized, che rendeva questa pagina
 * come un elenco di titoli su campo scuro con una fascia CTA finale. Nel legacy
 * era sei gruppi etichettati di fotografie, ognuno con la griglia a 3 colonne
 * della homepage e la didascalia col nome del macchinario.
 *
 * PERCHE' LEGGE LA MAPPA E NON I 34 RECORD. I 34 macchinari esistono in WordPress
 * ed e' giusto che ci siano, ma il legacy non li elencava per titolo: mostrava una
 * selezione redazionale di 33 fotografie divise in sei gruppi, con nomi di
 * macchinario come didascalia. Prendere i record e ordinarli darebbe una pagina
 * plausibile e diversa. La selezione e l'ordine sono quelli del legacy.
 *
 * @package tenconi-child-theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

$tl_gruppi = tenconi_legacy_parco_macchine();
?>
<main id="main" class="tl-main" tabindex="-1">
	<div class="tl-wrap">

		<h1 class="tl-titolo tl-titolo--pagina">Parco macchine</h1>

		<?php foreach ( $tl_gruppi as $tl_i => $tl_g ) : ?>
			<?php if ( empty( $tl_g['img'] ) ) { continue; } ?>
			<section class="tl-grp" aria-labelledby="tl-grp-<?php echo (int) $tl_i; ?>">

				<h2 class="tl-grp__t" id="tl-grp-<?php echo (int) $tl_i; ?>"><?php echo esc_html( $tl_g['etichetta'] ); ?></h2>

				<ul class="tl-griglia tl-grp__g">
					<?php
					foreach ( $tl_g['img'] as $tl_x ) :
						list( $tl_att, $tl_cap ) = $tl_x;
						if ( ! tenconi_home_img_ok( $tl_att ) ) {
							continue;
						}
						?>
						<li>
							<figure class="tl-grp__f">
								<?php
								echo wp_get_attachment_image(
									$tl_att,
									'large',
									false,
									array(
										/* La didascalia E' il nome del macchinario: come alt va bene,
										   perche' descrive davvero cosa si vede. */
										'alt'      => '' !== $tl_cap ? $tl_cap : $tl_g['etichetta'],
										'loading'  => 'lazy',
										'decoding' => 'async',
										'sizes'    => '(max-width: 560px) 100vw, (max-width: 900px) 50vw, 33vw',
									)
								);
								?>
								<?php if ( '' !== $tl_cap ) : ?>
									<figcaption class="tl-grp__c"><?php echo esc_html( $tl_cap ); ?></figcaption>
								<?php endif; ?>
							</figure>
						</li>
					<?php endforeach; ?>
				</ul>
			</section>
		<?php endforeach; ?>
	</div>
</main>
<?php
get_footer();
