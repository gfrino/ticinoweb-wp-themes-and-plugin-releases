<?php
/**
 * CERTIFICAZIONI — l'archivio del CPT certification reso come la pagina legacy.
 *
 * URL: /certificazioni/
 *
 * PERCHE' UN TEMPLATE D'ARCHIVIO E NON UNA PAGINA. Il CPT certification dichiara
 * has_archive => 'certificazioni', e nelle regole di riscrittura l'archivio BATTE
 * lo slug di pagina: la pagina creata con lo stesso slug resta irraggiungibile e
 * il filtro su is_page() non scatta mai. Invece di spostare lo slug o di
 * cancellare l'archivio si serve qui il renderer giusto, lasciando URL e
 * architettura come sono.
 *
 * L'archivio non ha record, ma non serve: nel legacy la pagina era un elenco di
 * certificati con i PDF in piu' lingue, e quello viene dalla mappa legacy.
 *
 * @package tenconi-child-theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

set_query_var( 'tl_slug', 'certificazioni' );
get_template_part( 'template-parts/pagine/documenti' );

get_footer();
