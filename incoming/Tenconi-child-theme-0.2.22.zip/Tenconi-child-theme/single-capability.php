<?php
/**
 * Le due aree di attivita' che vivono su un contenuto "capability".
 *
 * URL: /lavorazioni/<slug>/
 *
 * Nel legacy Metalmeccanica e Carpenteria metallica erano pagine identiche alle
 * tre ospitate su un termine "market": stesso titolo centrato, stesse due
 * gallerie etichettate. L'architettura WordPress le ha messe su un CPT diverso,
 * ma il LAYOUT LEGACY E' LO STESSO, quindi si delega allo stesso renderer.
 *
 * Le capability che NON sono una delle cinque aree non entrano qui: la mappa
 * legacy non le contiene e il renderer esce senza stampare niente, lasciando
 * spazio al template generico.
 *
 * @package tenconi-child-theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$tl_post = get_queried_object();
$tl_slug = ( $tl_post && isset( $tl_post->post_name ) ) ? tenconi_legacy_area_chiave( $tl_post->post_name ) : '';

if ( '' === $tl_slug ) {

	/*
	 * GESTIONE PROGETTI SPECIALI ha uno screenshot legacy e un layout proprio:
	 * due colonne e un pulsante. Non e' una delle cinque aree, quindi non passa
	 * dal renderer di famiglia, ma non deve nemmeno finire nel template generico
	 * della fase Legacy-Modernized, che la rendeva con campo scuro e colonna di
	 * riferimenti tecnici.
	 */
	if ( $tl_post && isset( $tl_post->post_name ) && 'gestione-progetti' === $tl_post->post_name ) {
		get_header();
		get_template_part( 'template-parts/pagine/gestione-progetti' );
		get_footer();
		return;
	}

	/*
	 * Le altre capability non hanno ancora uno screenshot legacy analizzato: si
	 * usa il template generico, senza inventare un layout.
	 */
	get_template_part( 'singular' );
	return;
}

get_header();

set_query_var( 'tl_slug', $tl_slug );
get_template_part( 'template-parts/aree/pagina' );

get_footer();
