<?php
/**
 * Tenconi Child Theme - bootstrap.
 *
 * Tema figlio di ticinoweb-ai-theme (ticinoWEB CMS).
 * Il parent theme non deve mai essere modificato.
 *
 * Nota tecnica: il parent accoda gia get_stylesheet_uri(), che con un tema
 * figlio attivo risolve allo style.css di questo tema. Il CSS del child viene
 * quindi caricato senza bisogno di un enqueue aggiuntivo: aggiungerlo
 * produrrebbe un doppio caricamento dello stesso file.
 *
 * @package tenconi-child-theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'TENCONI_VERSION', '0.2.22' );
define( 'TENCONI_DIR', get_stylesheet_directory() );
define( 'TENCONI_URI', get_stylesheet_directory_uri() );

require_once TENCONI_DIR . '/inc/parent-compat.php';
require_once TENCONI_DIR . '/inc/setup.php';
require_once TENCONI_DIR . '/inc/template-tags.php';
require_once TENCONI_DIR . '/inc/content.php';

// CF-5: canonical corretto. Modulo dedicato perche' la correzione non e' una sola
// neutralizzazione del parent: rimuove una riga dal suo output E aggiunge il
// canonical che il core non emette sugli archivi. Tenerla in parent-compat.php
// avrebbe mescolato due responsabilita' diverse.
require_once TENCONI_DIR . '/inc/canonical.php';

// Content Foundation: modello dei contenuti.
require_once TENCONI_DIR . '/inc/post-types.php';
require_once TENCONI_DIR . '/inc/taxonomies.php';
require_once TENCONI_DIR . '/inc/content-meta.php';
require_once TENCONI_DIR . '/inc/nav-resolve.php';

// CF-4: navigazione dai menu WordPress reali, e redirect legacy centralizzati.
require_once TENCONI_DIR . '/inc/nav-menus.php';
require_once TENCONI_DIR . '/inc/redirects.php';

/*
 * Legacy-Modernized. L'architettura di navigazione approvata dal committente e
 * il cancello che decide quali destinazioni sono pubblicabili oggi.
 *
 * Perche' non usa piu' i menu WordPress: quei menu contengono 34 sottovoci e 8
 * intestazioni mute, e nessuno dei due documenti del cliente li approva. La
 * struttura approvata e' un'altra, e vive in nav-config.php dove si legge, si
 * discute e si verifica. inc/nav-menus.php resta caricato perche' altri
 * template lo usano ancora.
 */
require_once TENCONI_DIR . '/inc/nav-config.php';
require_once TENCONI_DIR . '/inc/home-content.php';

/*
 * La mappa asset legacy -> slot della home. Va DOPO home-content.php perche' si
 * appoggia a tenconi_home_img_ok() per il filtro di qualita'.
 */
require_once TENCONI_DIR . '/inc/home-legacy-media.php';

/*
 * La mappa dei media delle cinque pagine "area di attivita'". Generata dal
 * sorgente legacy in cache e verificata sugli screenshot: 96 immagini, tutte
 * risolte su un attachment, nessuna mancante.
 */
require_once TENCONI_DIR . '/inc/legacy-aree-media.php';

/*
 * Le mappe delle altre pagine interne con screenshot legacy: parco macchine e
 * gestione progetti speciali.
 */
require_once TENCONI_DIR . '/inc/legacy-pagine-media.php';

/*
 * Il modulo contatti: gestore admin-post, validazione e invio. Va caricato
 * sempre, anche in admin, perche' admin-post.php ci passa.
 */
require_once TENCONI_DIR . '/inc/contact-form.php';

/*
 * Le pagine del menu ricostruite dal legacy, con la loro mappa di media.
 */
require_once TENCONI_DIR . '/inc/legacy-menu-media.php';
require_once TENCONI_DIR . '/inc/legacy-documenti.php';

/*
 * Dati del mega menu: fotografia e frase per ogni voce. Va dopo le mappe legacy e
 * dopo nav-config, perche' legge le une e l'altra.
 */
require_once TENCONI_DIR . '/inc/nav-mega.php';

/*
 * Ricerca dal vivo. Dopo nav-config, perche' usa lo stesso cancello di
 * pubblicabilita' del menu: un risultato che il menu tiene spento non deve
 * comparire qui.
 */
require_once TENCONI_DIR . '/inc/search.php';

/*
 * Spegne il `sizes="auto"` che WordPress antepone alle immagini lazy.
 *
 * Il core, insieme a quell'attributo, stampa in <head> la regola
 * `img:is([sizes=auto i],...){contain-intrinsic-size:3000px 1500px}`. Su una
 * immagine in contenimento di dimensione quel segnaposto diventa l'altezza
 * REALE: nelle griglie `--intere`, dove togliamo l'aspect-ratio per lasciare a
 * ogni scatto il suo rapporto, non resta nulla a contraddirlo e ogni fotografia
 * si pianta a 1500px con il resto della cella vuoto (misurato su chi-siamo,
 * direzione e team: 11 celle da 1500px l'una).
 *
 * Non perdiamo niente a spegnerlo: `sizes` glielo passiamo gia' esplicito e
 * corretto in template-parts/pagine/legacy-menu.php, che era proprio lo scopo
 * di `auto`. Lo stesso filtro impedisce al core di stampare quella regola
 * (wp-includes/media.php, wp_enqueue_img_auto_sizes_contain_css_fix).
 */
add_filter( 'wp_img_tag_add_auto_sizes', '__return_false' );

/**
 * Instrada le cinque pagine del menu al renderer condiviso.
 *
 * Un filtro invece di cinque file page-<slug>.php: il layout e' uno, e cinque
 * file che si richiamano a vicenda sarebbero markup duplicato per niente. Il
 * filtro tocca SOLO gli slug della mappa, quindi nessun'altra pagina cambia
 * comportamento.
 *
 * @param string $template Percorso scelto da WordPress.
 * @return string
 */
function tenconi_instrada_pagine_menu( $template ) {

	if ( ! is_page() ) {
		return $template;
	}
	$p = get_queried_object();
	if ( ! $p || ! isset( $p->post_name ) ) {
		return $template;
	}
	/*
	 * Oltre alle pagine ricostruite dal legacy, il guscio legacy serve anche le
	 * pagine del menu il cui testo e' gia' corretto nel CMS. Elenco esplicito:
	 * il filtro non deve dirottare pagine che non sono nel menu.
	 */
	/* Gli elenchi di documenti hanno un guscio proprio. */
	if ( array_key_exists( $p->post_name, tenconi_legacy_documenti() ) ) {
		$doc = TENCONI_DIR . '/page-legacy-documenti.php';
		if ( file_exists( $doc ) ) {
			return $doc;
		}
	}

	$dal_cms = array( 'chi-siamo', 'storia', 'sostenibilita' );
	if ( ! array_key_exists( $p->post_name, tenconi_legacy_menu_media() )
		&& ! in_array( $p->post_name, $dal_cms, true ) ) {
		return $template;
	}
	$mio = TENCONI_DIR . '/page-legacy-menu.php';
	return file_exists( $mio ) ? $mio : $template;
}
add_filter( 'template_include', 'tenconi_instrada_pagine_menu' );

/**
 * Marca il body della home: l'header galleggia sopra l'hero.
 *
 * Una classe e non un controllo nel CSS su is_front_page(): cosi' l'header resta
 * un componente unico e la variante vive tutta nel foglio di stile.
 *
 * @param string[] $c Classi del body.
 * @return string[]
 */
function tenconi_body_hero( $c ) {

	if ( is_front_page() ) {
		$c[] = 'tl-hero-attiva';
	}
	return $c;
}
add_filter( 'body_class', 'tenconi_body_hero' );

/**
 * SPEGNE IL RILEVATORE DI EMOJI DEL CORE.
 *
 * MISURATO PRIMA DI TOCCARE NULLA: il blocco di WordPress — impostazioni JSON
 * piu' script di rilevamento inline in <head>, piu' un frammento di stile — pesa
 * 14 KB per pagina, e sta PRIMA del contenuto, quindi il browser lo deve
 * analizzare prima ancora di iniziare a disegnare la pagina. Su un documento
 * HTML di 94 KB e' un settimo del peso totale, per una funzione che qui non
 * serve: nessun contenuto del sito usa emoji, e i browser correnti le
 * disegnano da soli senza bisogno di questo script di compatibilita', pensato
 * per browser che oggi non esistono piu'.
 *
 * NON TOCCA IL PARENT: sono le azioni standard del CORE di WordPress
 * (wp-includes), le stesse tre righe che qualunque tema pulito rimuove. Le
 * emoji digitate in un titolo o in un testo restano visibili come sempre —
 * cambia solo che il browser le disegna con il proprio set nativo invece che
 * scaricare le immagini di Twemoji.
 */
remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
remove_action( 'admin_print_scripts', 'print_emoji_detection_script' );
remove_action( 'wp_print_styles', 'print_emoji_styles' );
remove_action( 'admin_print_styles', 'print_emoji_styles' );
remove_filter( 'wp_mail', 'wp_staticize_emoji_for_email' );
remove_filter( 'the_content_feed', 'wp_staticize_emoji' );
remove_filter( 'comment_text_rss', 'wp_staticize_emoji' );
add_filter(
	'tiny_mce_plugins',
	function ( $plugins ) {
		return is_array( $plugins ) ? array_diff( $plugins, array( 'wpemoji' ) ) : array();
	}
);
