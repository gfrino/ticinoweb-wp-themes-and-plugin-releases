<?php
/**
 * Template Name: Comunicati Archivio
 * 
 * Questo template estrae automaticamente tutti gli articoli "Comunicato" e li impagina in una griglia
 */

get_header(); ?>

<style>
/* Indicatore "PDF" sulle card dei comunicati che hanno un documento allegato.
   Nella lista non stampiamo l'embed: appesantirebbe la pagina (un PDF per card).
   L'embed vero e proprio sta nella vista di dettaglio (single-comunicato.php). */
.comunicato-card-badges {
	display: flex;
	align-items: center;
	gap: 8px;
	flex-wrap: wrap;
}
.comunicato-card-pdf-flag {
	display: inline-flex;
	align-items: center;
	gap: 5px;
	background-color: var(--color-primary);
	color: #FFFFFF;
	padding: 2px 9px;
	border-radius: 999px;
	font-size: 0.72rem;
	font-weight: 700;
	letter-spacing: 0.5px;
	text-transform: uppercase;
	line-height: 1.6;
}
.comunicato-card-pdf-flag svg {
	flex: 0 0 auto;
}
/* Modalità scura: il badge resta blu pieno con testo bianco */
html[data-theme="dark"] .comunicato-card-pdf-flag {
	color: #FFFFFF;
}
</style>

<main id="primary" class="site-main page-content" style="padding-bottom: var(--space-xxl);">
	
		<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
			<?php 
			$has_thumbnail = has_post_thumbnail();
			$thumbnail_url = $has_thumbnail ? get_the_post_thumbnail_url(get_the_ID(), 'full') : '';
			$header_class = $has_thumbnail ? 'page-header-cinematic has-bg' : 'page-header-cinematic no-bg';
			?>
			<header class="<?php echo esc_attr($header_class); ?>" <?php if ($has_thumbnail) echo 'style="background-image: url(\'' . esc_url($thumbnail_url) . '\');"'; ?>>
				<div class="page-header-overlay"></div>
				<div class="container page-header-inner animate-on-scroll">
					<h1 class="page-title"><?php the_title(); ?></h1>
					<h2 style="color: var(--color-accent); font-size: 1.5rem; font-weight: 500; font-family: var(--font-heading); margin-top: var(--space-sm);">Resta aggiornato sulle ultime novità e comunicazioni del Patriziato di Frasco.</h2>
				</div>
			</header>
		<?php endwhile; endif; ?>

	<div class="container">

		<div class="comunicati-grid">
			<?php
			$args = array(
				'post_type'      => 'comunicato',
				'posts_per_page' => -1, // Mostra tutti
				'orderby'        => 'date',
				'order'          => 'DESC', // Più recenti prima
			);
			$comunicati_query = new WP_Query( $args );

			if ( $comunicati_query->have_posts() ) :
				while ( $comunicati_query->have_posts() ) : $comunicati_query->the_post();
					// Nella lista segnaliamo solo la presenza del PDF: l'embed sta nel dettaglio.
					$comunicato_pdf_id = get_post_meta( get_the_ID(), '_comunicato_pdf_id', true );
					$comunicato_ha_pdf = ( $comunicato_pdf_id && function_exists( 'ptf_has_pdf_attachment' ) ) ? ptf_has_pdf_attachment( $comunicato_pdf_id ) : false;
					?>
					<article id="post-<?php the_ID(); ?>" <?php post_class('comunicato-card'); ?>>
						<a href="<?php the_permalink(); ?>" class="comunicato-card-link">
							
							<div class="comunicato-card-image">
								<?php 
								if ( has_post_thumbnail() ) {
									the_post_thumbnail( 'large' );
								} else {
									echo '<div class="comunicato-no-image"><span class="dashicons dashicons-megaphone"></span></div>';
								}
								?>
							</div>

							<div class="comunicato-card-content">
								<div class="comunicato-card-date comunicato-card-badges">
									<span><?php echo get_the_date(); ?></span>
									<?php if ( $comunicato_ha_pdf ) : ?>
										<span class="comunicato-card-pdf-flag" title="Questo comunicato ha un documento PDF allegato">
											<svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 21h10a2 2 0 002-2V9.414a1 1 0 00-.293-.707l-5.414-5.414A1 1 0 0012.586 3H7a2 2 0 00-2 2v14a2 2 0 002 2z"></path></svg>
											PDF
										</span>
									<?php endif; ?>
								</div>
								<h2 class="comunicato-card-title"><?php the_title(); ?></h2>
								<div class="comunicato-card-excerpt">
									<?php echo wp_trim_words( get_the_excerpt(), 20, '...' ); ?>
								</div>
								<div class="comunicato-card-readmore">Leggi tutto &rarr;</div>
							</div>
						</a>
					</article>
					<?php
				endwhile;
				wp_reset_postdata();
			else :
				echo '<div class="no-comunicati"><p>Nessun comunicato pubblicato al momento.</p></div>';
			endif;
			?>
		</div>
	</div>
</main>

<?php get_footer();
