jQuery(function ($) {
 
		 
		 $("body").on("change", '#brtw-cart-widget input.qty', function(){
			 qty = parseFloat($('#brtw-cart-widget').find('input.qty').val());
			 if(qty < 1){
				  $('#brtw-cart-widget').find('input.qty').val(1);
			 } 
			updateBrTwCartPrice();
		 });
		 $("body").on("change", '.brtw-listings-product input', function(){
			 $('#brtw-product-form').submit();
		 });
		 
				
		$("body").on("change", '.brtw-addons-wrapper .addons-items ul li input', function(){
			var total = 0;
			var total_raw = 0;
			var $totals = $('#brtw-cart-widget');
			var $wrapper = $('.brtw-addons-wrapper');
			var product_price = $totals.data('price');
			var product_type = $totals.data('type');
			var qty = parseFloat($totals.find('input.qty').val());
			var addons = [];
			var $this=$(this);
			 
			var parentContainer = $this.parents('ul.brtw-pao-addon');
			var name = parentContainer.data('addon-name');
			var max_addon = parseInt(parentContainer.data('max-addon'));
			 
			var min_addon = parentContainer.data('min-addon');
			var select_addon=parentContainer.find("input:checkbox:checked").length;
			var price=$this.attr('data-price');
			console.log('max_addon='+max_addon);
			console.log('select_addon='+select_addon);
			if($this.is( ":checked" )){
				if(max_addon >= select_addon){
					$this.attr('data-raw-price', '0');
					
				}else{
					$this.attr('data-raw-price',price);
					console.log(price);
				}
			}else{
				var selectAddon=0;
				parentContainer.find('.brtw-pao-addon-field').each(function () {
					var $brtwAddon=$(this);
					if($brtwAddon.is( ":checked" )){
						selectAddon++;
						if(max_addon >= selectAddon){
							$brtwAddon.attr('data-raw-price', '0');
						}else{
							 $brtwAddon.attr('data-raw-price',price);
						}
					}else{
						$brtwAddon.attr('data-raw-price',price);
					}
				})
				 
			} 
			updateBrTwCartPrice();
		});
		
		function updateBrTwCartPrice(){
			var total = 0;
			var total_raw = 0;
			var $totals = $('#brtw-cart-widget');
			var $wrapper = $('.brtw-addons-wrapper');
			var product_price = $totals.data('price');
			var product_type = $totals.data('type');
			var qty = parseFloat($totals.find('input.qty').val());
			var addons = [];
			var $brtw_product=$('.brtw-listings-product').find("input:radio:checked");
			var $productContainer = $brtw_product.parents('div.brtw-grid');
			  
			var product_price = $brtw_product.attr('data-price');
			var currencySymbol = $productContainer.find('span.price span.woocommerce-Price-currencySymbol').text();
			  total = parseFloat(product_price) * qty;
			  total_raw = parseFloat(product_price) * qty;
			
			$("#brtw-cart-widget").hide();
			$wrapper.find('.brtw-pao-addon-field').each(function () {
				var $addon=$(this);
				if($addon.is(":checked" )){
					$("#brtw-cart-widget").show();
					var value_label = $addon.attr('data-data-label');
					var addon_cost = $addon.attr('data-price');
					var addon_cost_raw = $addon.attr('data-raw-price');
					var price_type = $addon.attr('data-price-type');
					var addon_data = {};
					switch (price_type) {
							case 'flat_fee':
								addon_data.cost = parseFloat(addon_cost);
								addon_data.cost_raw =parseFloat(addon_cost_raw);
								break;
							case 'quantity_based':
								addon_data.cost_pu = parseFloat(addon_cost);
								addon_data.cost_raw_pu=parseFloat(addon_cost_raw);
								addon_data.cost = addon_data.cost_pu * qty;
								addon_data.cost_raw = addon_data.cost_raw_pu * qty;
								break;
							case 'percentage_based':
								addon_data.cost_pct =parseFloat(addon_cost) / 100;
								addon_data.cost_raw_pct =parseFloat(addon_cost_raw) / 100;
								addon_data.cost =parseFloat(product_price) * addon_data.cost_pct * qty;
								addon_data.cost_raw =parseFloat(product_price) * addon_data.cost_raw_pct * qty;
								
								break;
						}
						total += addon_data.cost || 0;
						total_raw += addon_data.cost_raw || 0;
						addons.push(addon_data);
				}
			});
			 
			 console.log(addons);
			$totals.find('.totals-price').html('<span class="woocommerce-Price-currencySymbol">'+currencySymbol+' '+total_raw+'</span>');
				
				
		}	
		
		function checkCartValidation(){
			var valid=true;
			var $totals = $('#brtw-cart-widget');
			var $wrapper = $('.brtw-addons-wrapper');
			var qty = parseFloat($totals.find('input.qty').val());
			if(!qty){  
				$totals.find('input.qty').val(1);
				updateBrTwCartPrice();
			}
			
			$wrapper.find('ul.brtw-pao-addon').each(function () {
				var $this=$(this);
				var min_addon = parseInt($this.data('min-addon'));
				var name = $this.data('addon-name');
				var select_addon=$this.find("input:checkbox:checked").length;
				if(min_addon > 0){
					if(min_addon > select_addon){
						valid=false; 
					}
				}	
				
			});
			return valid ;
		}
	 $("body").on("click", '#brtw-cart-widget .brtw-cart-button', function(){
		 if(checkCartValidation()){
			  
			  var fromData=$("#brtw-product-cart-form").serialize()+'&action=wc_brtw_product_addons_cart';
			$.ajax({
					type: 'POST',
					url: woocommerce_addons_params.ajax_url,
					data: fromData,
					success: function (result) {
						window.location = result;

					},
					error: function () {
						
					},
			});
							
		 }else{
			 console.log('invalid');
		 }
	 });
});

 