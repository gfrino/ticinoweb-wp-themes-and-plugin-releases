<?php

/**
 * The plugin bootstrap file
 *
 * Plugin Name:       Make your own Pokè
 * Plugin URI:        https://ticinoweb.com/
 * Description:       Crea la pagina «Componi il tuo Pokè»: i clienti scelgono la base e aggiungono ingredienti e extra, il prezzo si aggiorna subito e il piatto personalizzato va nel carrello senza ricaricare la pagina. Per ristoranti con negozio WooCommerce e Elementor.
 * Update URI:        https://github.com/gfrino/ticinoweb-wp-themes-and-plugin-releases
 * Requires PHP:      7.4
 * Version:           1.1.1
 * Author:            Giovanni Frino
 * Author URI:        https://ticinoweb.com/
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       ticinoweb
 * Domain Path:       /languages
 */

if( ! defined( 'ABSPATH' ) ) {
    return;
}

/*
 * human readable dump
 *
 */
if( ! function_exists('brtw_print') ) {
    function brtw_print( $what = '' ) {
        print '<pre class="rz-dump">';
        print_r( $what );
        print '</pre>';
    }
}

/*
 * textdomain
 *
 */
if( ! function_exists('brtw_utilities_load_textdomain') ) {
    function brtw_utilities_load_textdomain() {
    	load_plugin_textdomain( 'ticinoweb', false, basename( dirname( __FILE__ ) ) . '/languages' );
    }
    add_action( 'init', 'brtw_utilities_load_textdomain' );
}

define( 'BRTW_PATH', wp_normalize_path( plugin_dir_path( __FILE__ ) . DIRECTORY_SEPARATOR ) );
define( 'BRTW_URI', plugin_dir_url( __FILE__ ) );
define( 'BRTW_VERSION', '1.1.1' );
define( 'BRTW_TEXT_DOMAIN', 'ticinoweb' );
// Version of the bundled includes/tw-release-updater.php (keep in sync with its header).
define( 'BRTW_RELEASE_UPDATER_VERSION', '1.2.0' );
require_once BRTW_PATH . 'includes/tw-release-updater.php';
if( ! function_exists('brtw_utilities_enqueue_scripts') ) {
    function brtw_utilities_enqueue_scripts() {
        wp_enqueue_style( 'brtw-utilities-base', BRTW_URI.'assets/css/base.css', array(), BRTW_VERSION );
		wp_enqueue_script('brtw-frontend', BRTW_URI.'assets/js/frontend.js',array(),time(),true); 
    }
    add_action( 'wp_enqueue_scripts', 'brtw_utilities_enqueue_scripts' );
}
 
/*   ini_set('display_errors', 1);
  ini_set('display_startup_errors', 1);
  error_reporting(E_ALL); */

include BRTW_PATH.'src/helper.php';
 

include BRTW_PATH.'src/class.brtw.elementor.php';

 
 
/**
 * Install or upgrade the release updater mu-plugin from the bundled copy.
 * Retried at most every 12 hours if mu-plugins is not writable.
 */
function brtw_install_release_updater() {
    if ( ! class_exists( 'TW_Release_Updater' ) || TW_Release_Updater::mu_is_current( BRTW_RELEASE_UPDATER_VERSION ) ) {
        return;
    }
    if ( get_site_transient( 'brtw_release_updater_failed' ) ) {
        return;
    }
    $result = TW_Release_Updater::install_mu( BRTW_PATH . 'includes/tw-release-updater.php' );
    if ( is_wp_error( $result ) ) {
        set_site_transient( 'brtw_release_updater_failed', $result->get_error_message(), 12 * HOUR_IN_SECONDS );
    }
}

add_action( 'admin_init', function () {
    if ( current_user_can( is_multisite() ? 'manage_network_plugins' : 'activate_plugins' ) ) {
        brtw_install_release_updater();
    }
}, 20 );
