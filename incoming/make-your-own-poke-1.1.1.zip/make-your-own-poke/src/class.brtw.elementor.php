<?php

class Brtw_Uts_Elementor {

    function __construct() {
        add_action( 'init', array($this, 'brtw_init_widgets'));
    }

    public function brtw_init_widgets() {
 
        add_action( 'elementor/editor/before_enqueue_scripts', array($this, 'brtw_preview_enqueue_scripts'));

        add_action( 'elementor/widgets/widgets_registered', array( $this, 'brtw_register_widgets'));

        add_action( 'elementor/elements/categories_registered', array($this, 'brtw_create_custom_categories') );

    }

    public function brtw_preview_enqueue_scripts() {
        wp_enqueue_style( 'brtw-uts-elementor', BRTW_URI.'assets/css/elementor.css', array(), BRTW_VERSION );
		
    }

    public function brtw_register_widgets() {

         if(file_exists(BRTW_PATH.'src/elementor/class.brtw.personalized.products.php')){
			require_once(BRTW_PATH.'src/elementor/class.brtw.personalized.products.php');
			\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Brtw_Personalized_Products());
		} 
    } 
    public function brtw_create_custom_categories( $elements_manager ) {

        $elements_manager->add_category(
            'brtw',
            [
                'title' => __( 'TicinoWeb', 'ticinoweb' ),
                'icon' => 'fas fa-location-arrow',
            ]
        );

        $category_prefix = 'brtw';

        $reorder_cats = function() use( $category_prefix ) {
            uksort( $this->categories, function( $keyOne, $keyTwo ) use( $category_prefix ) {
                if( substr( $keyOne, 0, 5 ) == $category_prefix ) {
                    return -1;
                }
                if( substr( $keyTwo, 0, 5 ) == $category_prefix ) {
                    return 1;
                }
                return 0;
            });

        };

        $reorder_cats->call($elements_manager);

        $elements_manager->add_category(
            'brtw',
            [
                'title' => __( 'TicinoWeb', 'ticinoweb' ),
                'icon' => 'fas fa-location-arrow',
            ]
        );

    }

}

new Brtw_Uts_Elementor();
