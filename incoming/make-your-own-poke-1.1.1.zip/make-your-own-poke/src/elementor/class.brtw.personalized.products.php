<?php
 
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Icons_Manager;

class Brtw_Personalized_Products extends \Elementor\Widget_Base {

	public function get_name() {
		return 'brtw-personalized';
	}

	public function get_title() {
		return __( 'Personalized Product', BRTW_TEXT_DOMAIN );
	}

	public function get_icon() {
		return 'brtw-icon-som';
	}

	public function get_categories() {
		return ['brtw'];
	}

	protected function _register_controls() {
		
		if( class_exists('\Woocommerce') ){
			$taxonomies=array();
			$custom_taxonomies = brtw_get_terms('product_cat',0);
			foreach( $custom_taxonomies as $custom_taxonomy ) {
				$taxonomies[$custom_taxonomy->slug] = $custom_taxonomy->name;
			}
		   $this->start_controls_section(
                'brtw_product_list_query_section',
                [
                    'label' => esc_html__('Query Settings', BRTW_TEXT_DOMAIN),
                ]
            );
			
			$this->add_control(
			'brtw_taxonomy',
			[
                'label' => __( 'Taxonomy', BRTW_TEXT_DOMAIN ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => $taxonomies,
			] );
            $this->add_control(
                'brtw_per_page', [
                    'label' => esc_html__('Per Page', BRTW_TEXT_DOMAIN),
                    'type' => \Elementor\Controls_Manager::NUMBER,
                    'placeholder' => esc_html__('Enter Number', BRTW_TEXT_DOMAIN),
                    'default' => 3,
					'min' => 1,
					'max' => 10,
                ]
            );
            $this->add_control(
                'brtw_order_by',
                [
                    'label' => __('Order By', BRTW_TEXT_DOMAIN),
                    'type' => \Elementor\Controls_Manager::SELECT,
                    'default' => 'date',
                    'options' => [
                        'modified' => __('Modified', BRTW_TEXT_DOMAIN),
                        'date' => __('Date', BRTW_TEXT_DOMAIN),
                        'rand' => __('Rand', BRTW_TEXT_DOMAIN),
                        'ID' => __('ID', BRTW_TEXT_DOMAIN),
                        'title' => __('Title', BRTW_TEXT_DOMAIN),
                        'author' => __('Author', BRTW_TEXT_DOMAIN),
                        'name' => __('Name', BRTW_TEXT_DOMAIN),
                        'parent' => __('Parent', BRTW_TEXT_DOMAIN),
                        'menu_order' => __('Menu Order', BRTW_TEXT_DOMAIN),
                    ],
                ]
            );
            $this->add_control(
                'brtw_order',
                [
                    'label' => __('Order', BRTW_TEXT_DOMAIN),
                    'type' => \Elementor\Controls_Manager::SELECT,
                    'default' => 'ase',
                    'options' => [
                        'ase' => __('Ascending Order', BRTW_TEXT_DOMAIN),
                        'desc' => __('Descending Order', BRTW_TEXT_DOMAIN),
                    ],
                ]
            ); 
            $this->end_controls_section(); 
			$this->start_controls_section(
				'section_content_style',
				[
					'label' => __('Style', BRTW_TEXT_DOMAIN),
				]
				);
			
			$this->add_control(
				'product_title_color',
				[
					'label'     => __('Product Title Color', BRTW_TEXT_DOMAIN),
					'type'      => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .brtw-head h2' => 'color: {{VALUE}};',
					],
					'separator' => 'before',
				]
			);

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name'     => 'product_title',
					'selector' => '{{WRAPPER}} .brtw-head h2',
				]
			);
			$this->add_control(
				'product_price_color',
				[
					'label'     => __('Product Price Color', BRTW_TEXT_DOMAIN),
					'type'      => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .brtw-price span' => 'color: {{VALUE}};',
						'{{WRAPPER}} .brtw-price .checkmark' => 'border-color: {{VALUE}}!important;',
					],
					'separator' => 'before',
				]
			);
			$this->add_control(
				'product_active_color',
				[
					'label'     => __('Selected Product Color', BRTW_TEXT_DOMAIN),
					'type'      => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .brtw-price input:checked ~ .checkmark' => 'background-color: {{VALUE}}!important;',
					],
					'separator' => 'before',
				]
			);
			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name'     => 'product_price',
					'selector' => '{{WRAPPER}} .brtw-price span',
				]
			);
		
			
			$this->end_controls_section();
			
			
			$this->start_controls_section(
				'section_addon_style',
				[
					'label' => __('Addon Style', BRTW_TEXT_DOMAIN),
				]);
				
			$this->add_control(
				'addon_title_color',
				[
					'label'     => __('Addon Title Color', BRTW_TEXT_DOMAIN),
					'type'      => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .addons-head h3' => 'color: {{VALUE}};',
					],
					'separator' => 'before',
				]
			);

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name'     => 'addon_title',
					'selector' => '{{WRAPPER}} .addons-head h3',
				]
			);
			$this->add_control(
				'addon_desc_color',
				[
					'label'     => __('Addon Description Color', BRTW_TEXT_DOMAIN),
					'type'      => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .addons-head p' => 'color: {{VALUE}};',
					],
					'separator' => 'before',
				]
			);
			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name'     => 'addon_desc_fonts',
					'selector' => '{{WRAPPER}} .addons-head p',
				]
			);
			$this->add_control(
				'addon_color',
				[
					'label'     => __('Addon Color', BRTW_TEXT_DOMAIN),
					'type'      => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .addons-items ul li label' => 'color: {{VALUE}}!important;',
						'{{WRAPPER}} .addons-items ul li label .checkmark' => 'border-color: {{VALUE}}!important;',
					],
				]
			);
			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name'     => 'addon_font',
					'selector' => '{{WRAPPER}} .addons-items ul li label',
				]
			);
			
			$this->add_control(
				'addons_active_color',
				[
					'label'     => __('Addons Active Color', BRTW_TEXT_DOMAIN),
					'type'      => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .addons-items ul li input:checked ~ .checkmark' => 'background-color: {{VALUE}}!important;',
					],
					'separator' => 'before',
				]
			);
			
			$this->add_control(
				'addon_price_color',
				[
					'label'     => __('Addon Price Color', BRTW_TEXT_DOMAIN),
					'type'      => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .addon-price' => 'color: {{VALUE}}!important;',
					],
				]
			);
			$this->add_control(
				'addon_price_bg',
				[
					'label'     => __('Addon Price Background', BRTW_TEXT_DOMAIN),
					'type'      => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .addon-price' => 'background: {{VALUE}}!important;',
					],
				]
			);
			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name'     => 'addon_price_font',
					'selector' => '{{WRAPPER}} .addon-price',
				]
			);
			
				
			$this->end_controls_section(); 
		}
		
	}
public function get_addon_html( $addon ) {
		 

		$method_name = 'get_' . $addon['type'] . '_html';

		if ( method_exists( $this, $method_name ) ) {
			$this->$method_name( $addon );
		}

		do_action( 'woocommerce_product_addons_get_' . $addon['type'] . '_html', $addon );

		 
	}
	protected function render() {
		  ob_start();
		$settings = $this->get_settings_for_display();
		extract( $settings );
		?>
		 <div class="brtw-section-product">
			
		<?php		
		if( class_exists('\Woocommerce') ){
				$args=array(
						'post_type'      => 'product',
						'post_status' => 'publish',
						'product_cat' =>$brtw_taxonomy,
						'posts_per_page' => $brtw_per_page,
						'order'          => $brtw_order,
						'ignore_sticky_posts' => true,
						'order_by'          =>$brtw_order_by,
					);
				 
				$product_query = new WP_Query($args);
				 $count=1;
				 $product_brtw=0;
				  $product_brtw_price=0;
			if ( $product_query->have_posts() ) {
				
				echo '<form   action="" method="post" enctype="multipart/form-data" id="brtw-product-form" name="brtw-product-form">';
				echo '<div class="brtw-listings-product">';
				$checked='';
				while($product_query->have_posts()) : 
					$product_query->the_post();
					global $product;
					$product_id=$product->get_id();
					if(isset($_POST['brtw_product'])){
						if($product_id == $_POST['brtw_product']){
							$product_brtw=$product->get_id();
							$checked='checked';
						}
					}else{
						if($count==1){
							$product_brtw=$product->get_id();
							$checked='checked';
						}
					}
					
					$count++;
					?>
					<div class="brtw-grid" >
						<div class="brtw-head">
							<div class="brtw-thumbnail">
								<?php  the_post_thumbnail( 'Full' ); ?>
							</div>
							<h2> <?php echo get_the_title();?></h2>
						</div>
						<div class="brtw-price brtw-checkbox">
						  <label for="brtw_product<?php echo $product_id;?>" >
						  <input type="radio" id="brtw_product<?php echo $product_id;?>" name="brtw_product" value="<?php echo $product_id;?>" <?php echo $checked; ?> data-price="<?php echo $product->get_price(); ?>">
						  <?php woocommerce_template_loop_price(); ?>
						  
						   <i class="checkmark"></i>
						   </label>
						</div> 
					</div>
				<?php
				$checked='';
				endwhile;
				
				echo '</form>';
				echo '</div>';
			}
			wp_reset_postdata();
			

		}else{ 
			echo esc_html__("Woocommerces Plugin not activated",BRTW_TEXT_DOMAIN);
		} 
		
       ?> 
			
       <form class="cart" action="" method="post" enctype="multipart/form-data" id="brtw-product-cart-form" name="brtw-product-cart-form">
		<div class="brtw-wrapper brtw-addons-wrapper">
			<?php
			if($product_brtw){
				if( class_exists('WC_Product_Addons_Helper') ){ 
					$product_addons = $this->brtw_get_product_addons( $product_brtw);
					   
					if (is_array( $product_addons ) && count( $product_addons ) > 0 ) {
						$this->brtw_product_addons_html($product_addons,$product_brtw);
					}else{
						 
					}
				} 
			} 
			?> 
			<input type="hidden" name="add-to-cart" id="brtw-add-to-cart" value="<?php echo $product_brtw ?>" >
			<div id="brtw-cart-widget">
				<div class="brtw-addon-totals">
					<div class="brtw-totals"><?php 	echo esc_html__("Totale parziale ",BRTW_TEXT_DOMAIN); ?></div>
					<div class="totals-price"></div>
				</div>
				<div class="brtw-addons-cart">
				<div class="quantity"  >
					<input type="number"   class="input-text qty text" step="1" min="1"  name="quantity" value="1" title="Qta" size="4" placeholder="Qta" inputmode="numeric" autocomplete="off">
					<a href="javascript:void(0);"  rel="<?php echo $product_brtw ?>" class="brtw-cart-button "><?php 	echo esc_html__("Acquista",BRTW_TEXT_DOMAIN); ?></a>
				</div>
				</div>
			</div>
		
		 </div>
		 </form>
		</div>
		<?php echo ob_get_clean();

	}
	
	function brtw_product_addons_html($product_addons,$product_id){
		foreach($product_addons as $key=>$addons){ 
			if (is_array( $addons['options'] ) && count($addons['options']) > 0 ) {
					$maxaddon=0;
					if(!empty($addons['description'])){
						$maxaddon= $this->getMaxFreeAddons($addons['description']);
					}
					
					$addon_required = WC_Product_Addons_Helper::is_addon_required( $addons );
					$min_addon=0;
					if($addon_required){
						$min_addon=$addon_required;
					}
				?>
				<div class="brtw-addons">
					<div class="addons-head">
						<h3><?php echo $addons['name'] ?></h3>
						<p><?php echo $addons['description'] ?></p>
					</div>
					<div class="addons-items">
						<ul class="brtw-pao-addon" data-addon-name="<?php echo $addons['name'] ?>" data-max-addon="<?php echo $maxaddon ?>" data-min-addon="<?php echo $min_addon ?>" >
						<?php 
						$price=0;
						 
						foreach($addons['options'] as $keys=>$options){ 
							$option_price      = ! empty( $options['price'] ) ? $options['price'] : '';
							$option_price_type = ! empty( $options['price_type'] ) ? $options['price_type'] : '';
							$price_prefix       = 0 < $option_price ? '+' : '';
							$price_type        = $option_price_type;
							$price_raw         = apply_filters( 'woocommerce_product_addons_option_price_raw', $option_price, $options );
							$field_name         = ! empty( $addons['field_name'] ) ? $addons['field_name'] : '';
							$option_label      = ( '0' === $options['label'] ) || ! empty( $options['label'] ) ? $options['label'] : '';
							$price_display     = WC_Product_Addons_Helper::get_product_addon_price_for_display( $price_raw );
							$required_html     = $addon_required ? 'required' : '';
							$price=esc_attr( $price_display );
							?>
							<li>
								<label>
									<input type="checkbox" <?php echo $required_html; ?> class="brtw-pao-addon-field" name="addon-<?php echo $product_id; ?>-<?php echo sanitize_title( $field_name ); ?>[]" data-raw-price="<?php echo esc_attr( $price_raw ); ?>" data-price="<?php echo esc_attr( $price_display ); ?>" data-price-type="<?php echo esc_attr( $price_type ); ?>" value="<?php echo sanitize_title( $option_label ); ?>" data-label="<?php echo esc_attr( wptexturize( $option_label ) ); ?>" > <?php echo wptexturize( $option_label  ); ?>
									 <i class="checkmark"></i>
								</label>
							</li>
							 
						<?php } ?>
						</ul>
						<?php if($price){ ?>
							<div class="addon-price"> + <?php echo $price; ?> <span><?php echo __('Extra', BRTW_TEXT_DOMAIN); ?></span></div>
						<?php } ?>
						
					</div>
				</div>
			<?php
			
			
			}
		}
		
	}
	
	function getMaxFreeAddons($description){
		$freeaddons=0;
		$string = array();
		preg_match_all('!\d+!', $description, $string);
		if(!empty($string)){
			
			if(isset($string[0][1])){
				$freeaddons=$string[0][1];
			}else if(isset($string[0][0])){
				$freeaddons=$string[0][0];
			}

			
		}
		 
		return $freeaddons;
	}


	
	public   function brtw_get_product_addons( $post_id ) {
		if ( ! $post_id ) {
			return array();
		}

		$addons     = array();
		$raw_addons = array();
		$parent_id  = wp_get_post_parent_id( $post_id );

		if ( defined( 'WC_VERSION' ) && version_compare( WC_VERSION, '3.0.0', '<' ) ) {
			$product_terms  = apply_filters( 'get_product_addons_product_terms', wp_get_post_terms( $post_id, 'product_cat', array( 'fields' => 'ids' ) ), $post_id );
			$exclude        = get_post_meta( $post_id, '_product_addons_exclude_global', true );
			$product_addons = array_filter( (array) get_post_meta( $post_id, '_product_addons', true ) );
		} else {
			$product        = wc_get_product( $post_id );
			
			$product_terms  = apply_filters( 'get_product_addons_product_terms', wp_get_post_terms( $product->get_id(), 'product_cat', array( 'fields' => 'ids' ) ), $product->get_id());
			$exclude        = $product->get_meta( '_product_addons_exclude_global' );
			$product_addons = array_filter( (array) $product->get_meta( '_product_addons' ) );
		}
 
		$raw_addons[10]['product'] = apply_filters( 'get_product_addons_fields', $product_addons, $post_id );

		if ( '1' !== $exclude   ) {
			$args = array(
				'posts_per_page'   => -1,
				'orderby'          => 'meta_value',
				'order'            => 'ASC',
				'meta_key'         => '_priority',
				'post_type'        => 'global_product_addon',
				'post_status'      => 'publish',
				'suppress_filters' => true,
				'meta_query' => array(
					array(
						'key'   => '_all_products',
						'value' => '1',
					),
				),
			);

			$global_addons = get_posts( $args );

			if ( $global_addons ) {
				foreach ( $global_addons as $global_addon ) {
					$priority                                     = get_post_meta( $global_addon->ID, '_priority', true );
					$raw_addons[ $priority ][ $global_addon->ID ] = apply_filters( 'get_product_addons_fields', array_filter( (array) get_post_meta( $global_addon->ID, '_product_addons', true ) ), $global_addon->ID );
				}
			}

			// Global level addons (categories).
			if ( $product_terms ) {
				$args = apply_filters( 'get_product_addons_global_query_args', array(
					'posts_per_page'   => -1,
					'orderby'          => 'meta_value',
					'order'            => 'ASC',
					'meta_key'         => '_priority',
					'post_type'        => 'global_product_addon',
					'post_status'      => 'publish',
					'suppress_filters' => true,
					'tax_query'        => array(
						array(
							'taxonomy'         => 'product_cat',
							'field'            => 'id',
							'terms'            => $product_terms,
							'include_children' => false,
						),
					),
				), $product_terms );

				$global_addons = get_posts( $args );

				if ( $global_addons ) {
					foreach ( $global_addons as $global_addon ) {
						$priority                                     = get_post_meta( $global_addon->ID, '_priority', true );
						$raw_addons[ $priority ][ $global_addon->ID ] = apply_filters( 'get_product_addons_fields', array_filter( (array) get_post_meta( $global_addon->ID, '_product_addons', true ) ), $global_addon->ID );
					}
				}
			}
		}

		ksort( $raw_addons );

		foreach ( $raw_addons as $addon_group ) {
			if ( $addon_group ) {
				foreach ( $addon_group as $addon ) {
					$addons = array_merge( $addons, $addon );
				}
			}
		} 
		$addon_field_counter = 0;
		foreach ( $addons as $addon_key => $addon ) {
			if ( empty( $addon['name'] ) ) {
				unset( $addons[ $addon_key ] );
				continue;
			}
			
			if (empty( $addons[ $addon_key ]['field-name'])) {
				$addon_name = $addon['name'];
				$addons[ $addon_key ]['field_name'] = sanitize_title($addon_name .'-'. $addon_field_counter );
				$addon_field_counter++;
			}
		}

		return apply_filters( 'get_product_addons', $addons );
	}
	


}
 