<?php

add_action( 'wp_ajax_wc_brtw_product_addons_cart','brtw_product_addons_cart_callback' );
add_action( 'wp_ajax_nopriv_wc_brtw_product_addons_cart', 'brtw_product_addons_cart_callback' );

 function brtw_product_addons_cart_callback(){
	echo wc_get_cart_url();die;
		 
}
		
function brtw_get_terms( $taxonomy,$parent_id=0 ) {
	
	 $categories = get_terms( array(
		'taxonomy' =>$taxonomy,
		'hide_empty' => false,
		'parent'  => $parent_id,
	));
	
	return $categories;

}
 


/* function action_woocommerce_cart_calculate_fees( $cart ) {
   
    
    $discount = 0;
      
    foreach ( $cart->get_cart() as $cart_item ) {
		
        $product_id = $cart_item['product_id'];
		 
		if ( has_term( $specific_categories, 'product_cat', $product_id ) ) {
			 $discount = get_free_addons_price($product_id);
        }
    }
    if($discount) {
		$cart->add_fee( __( 'Discount_applied', 'woocommerce' ), -$discount, false );    
	}        
      
     
}
 add_action( 'woocommerce_cart_calculate_fees', 'action_woocommerce_cart_calculate_fees', 10, 1 );
  */
 function get_free_addons_price($product_id,$paddons){
	$discount=0;
	 
	$product_addons = WC_Product_Addons_Helper::get_product_addons( $product_id);
				
	if (is_array( $product_addons ) && count( $product_addons ) > 0 ) {
		foreach($product_addons as $key=>$addons){ 
			if (is_array( $addons['options'] ) && count($addons['options']) > 0 ) {
				$maxaddon= get_max_free_addons($addons['description']);
				/* $field_name=$addons['field_name']; */
					$field_names=explode('-',$addons['field_name']);
					array_shift($field_names);
					$field_name=implode('-',$field_names);
				 if(isset($paddons[$field_name])){
					 $count=1;
					 if($maxaddon > $paddons[$field_name] ){
						 $maxaddon=$paddons[$field_name];
					 }
					  
					 foreach($addons['options'] as $keys=>$options){ 
						if($count <= $maxaddon){
							$option_price      = ! empty( $options['price'] ) ? $options['price'] : 0;
							$discount=$discount+$option_price;
						}else{
							break;
						}
						$count++;
					}
				 } 
			}
		}
	}
	return $discount;
 }
 function printbr($data){
	 echo '<pre>';
	 print_r($data);
	echo '</pre>';
 }
  function get_max_free_addons($description){
	 $freeaddons=0;
		$string = array();
		preg_match_all('!\d+!', $description, $string);
		if(!empty($string)){
			
			if(isset($string[0][1])){
				$freeaddons=$string[0][1];
			}else if(isset($string[0][0])){
				$freeaddons=$string[0][0];
			}

			
		}
		 
		return $freeaddons;
 }


add_action( 'woocommerce_before_calculate_totals', 'add_custom_price', 10, 1);
function add_custom_price( $cart_object ) {

	if ( did_action( 'woocommerce_before_calculate_totals' ) <= 1 ){
		$specific_categories = array( 'crea-la-tua-poke' );
		$specific_categories_fr = array( 'creez-votre-propre-poke' );
		$specific_categories_en = array( 'create-your-own-poke' );
		$specific_categories_ge = array( 'erstellen-sie-ihren-eigenen-stopsel' );
		foreach ( $cart_object->get_cart() as $cart_item ) {
				$discount=0;
				$product_id = $cart_item['product_id'];
				$product_cats_ids = get_the_terms( $product_id, 'product_cat' );
				
				if ( has_term( $specific_categories, 'product_cat', $product_id ) ||  has_term( $specific_categories_fr, 'product_cat', $product_id ) ||  has_term( $specific_categories_en, 'product_cat', $product_id ) ||  has_term( $specific_categories_ge, 'product_cat', $product_id )  ) {
					
					$addons=array();
					$paddons=array();
					foreach($cart_item['addons'] as $addon){
						$field_name=explode('-',$addon['field_name']);
						array_shift($field_name);
						$paddons[]=implode('-',$field_name);
					}
					 
					$addons = array_count_values($paddons);
					$discount = get_free_addons_price($product_id,$addons);
					
				} 
				 
				if($discount){
					$price=$cart_item['data']->price - $discount;
					if ( version_compare( WC_VERSION, '3.0', '<' ) ) {
						$cart_item['data']->price = $price; 
					} else {
						$cart_item['data']->set_price( $price );  
					}
				}  
		}
	} 
    
}

function check_poke_specific_categories( $product_id ) {

/* Array ( [0] => WP_Term Object ( [term_id] => 48 [name] => CREA LA TUA POKE [slug] => crea-la-tua-poke [term_group] => 0 [term_taxonomy_id] => 48 [taxonomy] => product_cat [description] => [parent] => 0 [count] => 4 [filter] => raw ) )
Array ( [0] => WP_Term Object ( [term_id] => 232 [name] => ERSTELLEN SIE IHREN EIGENEN STÖPSEL [slug] => erstellen-sie-ihren-eigenen-stopsel [term_group] => 0 [term_taxonomy_id] => 232 [taxonomy] => product_cat [description] => [parent] => 0 [count] => 3 [filter] => raw ) )

Array ( [0] => WP_Term Object ( [term_id] => 231 [name] => CREATE YOUR OWN POKE [slug] => create-your-own-poke [term_group] => 0 [term_taxonomy_id] => 231 [taxonomy] => product_cat [description] => [parent] => 0 [count] => 3 [filter] => raw ) )

Array ( [0] => WP_Term Object ( [term_id] => 230 [name] => CRÉEZ VOTRE PROPRE POKE [slug] => creez-votre-propre-poke [term_group] => 0 [term_taxonomy_id] => 230 [taxonomy] => product_cat [description] => [parent] => 0 [count] => 3 [filter] => raw ) ) */

	 	$specific_categories = array( 'crea-la-tua-poke,creez-votre-propre-poke,create-your-own-poke,create-your-poke,erstellen-sie-ihren-eigenen-stopsel' );
		$product_cats_ids = get_the_terms( $product_id, 'product_cat' );
		if(isset($_GET['print-dev'])){
			print_r($product_cats_ids);die;
		}
		$result=0;
		foreach($product_cats_ids as $category){
			if (in_array($category->slug, $specific_categories)){
				$result=1;
				break;
			}
		}
   return $result;
}



?>