<?php
/**
 * Testa della pagina e barra di navigazione scura (uguale su tutte le pagine): logo della sede,
 * menu «primary» del parent, carrello, bottone «Ordina online» e, sotto 1024px, il pulsante che apre
 * il foglio a tutto schermo con le stesse voci. Il <main> lo aprono i template (WooCommerce usa i suoi
 * wrapper in inc/shop.php). In home c'è anche la barra fissa del telefono (nav.li-actionbar).
 * Logo e menu vengono dal CMS, il logo bianco da Aspetto → Personalizza → Little Inka.
 */
defined('ABSPATH') || exit;

$li_site_name = function_exists('ticinoweb_frontend_text') ? ticinoweb_frontend_text(get_bloginfo('name'), 'theme:branding:site_name') : get_bloginfo('name');
$li_home      = function_exists('ticinoweb_frontend_url') ? ticinoweb_frontend_url(home_url('/'), 'theme:url:home') : home_url('/');
$li_menu_url  = littleinka_menu_url();
$li_logo_url  = function_exists('ticinoweb_get_site_logo') ? ticinoweb_get_site_logo() : '';
$li_body      = array('li-site');
if (is_front_page()) {
    $li_body[] = 'li-has-actionbar';
}
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
    <?php wp_head(); ?>
</head>
<body <?php body_class($li_body); ?>>
<?php wp_body_open(); ?>
<a class="li-skip" href="#li-main"><?php esc_html_e('Vai al contenuto', 'littleinka-child-theme'); ?></a>
<header class="li-header">
    <div class="li-wrap li-header__bar">
        <a class="li-header__logo" href="<?php echo esc_url($li_home); ?>" rel="home">
            <?php if ($li_logo_url) : ?>
                <?php
                // Il logo del CMS nei suoi colori; se è nella libreria media si usa la misura media (non l'originale da 6000 px).
                $li_logo_att = attachment_url_to_postid($li_logo_url);
                echo $li_logo_att
                    ? wp_get_attachment_image($li_logo_att, 'medium', false, array('class' => 'li-header__logo-img', 'alt' => $li_site_name, 'loading' => 'eager', 'decoding' => 'async', 'fetchpriority' => 'low', 'sizes' => '48px')) // phpcs:ignore WordPress.Security.EscapeOutput
                    : '<img class="li-header__logo-img" src="' . esc_url($li_logo_url) . '" alt="' . esc_attr($li_site_name) . '" width="48" height="40" decoding="async">';
                ?>
            <?php else : ?>
                <span class="li-header__name"><?php echo esc_html($li_site_name); ?></span>
            <?php endif; ?>
        </a>
        <?php echo littleinka_cart_link('li-header__cart li-header__cart--bar'); // phpcs:ignore WordPress.Security.EscapeOutput -- escape nella funzione ?>
        <button class="li-header__toggle" type="button" aria-expanded="false" aria-controls="li-sheet" aria-label="<?php echo esc_attr(littleinka_t(__('Apri il menu', 'littleinka-child-theme'), 'ui:menu_open')); ?>">
            <span class="li-header__toggle-open"><?php echo littleinka_icon('menu', 22); // phpcs:ignore WordPress.Security.EscapeOutput -- SVG del tema ?></span>
            <span class="li-header__toggle-close"><?php echo littleinka_icon('close', 22); // phpcs:ignore WordPress.Security.EscapeOutput ?></span>
        </button>
        <div id="li-sheet" class="li-header__sheet">
            <nav class="li-nav" aria-label="<?php echo esc_attr(littleinka_t(__('Principale', 'littleinka-child-theme'), 'ui:nav_label')); ?>">
                <?php
                wp_nav_menu(array(
                    'theme_location' => 'primary',
                    'menu_class'     => 'li-nav__list',
                    'container'      => false,
                    'fallback_cb'    => false,
                    'depth'          => 2,
                ));
                ?>
            </nav>
            <div class="li-header__actions">
                <?php echo littleinka_account_link(); // phpcs:ignore WordPress.Security.EscapeOutput -- escape nella funzione (inc/points.php) ?>
                <?php echo littleinka_cart_link('li-header__cart'); // phpcs:ignore WordPress.Security.EscapeOutput -- escape nella funzione ?>
                <a class="li-btn li-btn--primary li-header__cta" href="<?php echo esc_url($li_menu_url); ?>"><?php echo esc_html(littleinka_is_portal() ? littleinka_t(__('Scegli la sede', 'littleinka-child-theme'), 'header:scegli') : __('Ordina online', 'littleinka-child-theme')); ?><?php echo littleinka_icon('arrow', 14); // phpcs:ignore WordPress.Security.EscapeOutput ?></a>
            </div>
        </div>
    </div>
    <?php if (!littleinka_is_portal()) : // Etichetta della sede sotto «Ordina online»: si capisce subito dove si ordina. ?>
        <div class="li-wrap li-header__sede">
            <a class="li-sede-tag" href="<?php echo esc_url((string) littleinka_setting('portale_url', 'https://littleinka.ch')); ?>" title="<?php esc_attr_e('Cambia sede', 'littleinka-child-theme'); ?>">
                <?php echo littleinka_icon('pin', 15); // phpcs:ignore WordPress.Security.EscapeOutput -- SVG del tema ?>
                <span><?php echo esc_html(littleinka_sede_label()); ?></span>
            </a>
        </div>
    <?php endif; ?>
</header>
<?php if (is_front_page() && littleinka_is_portal()) : ?>
<nav class="li-actionbar" aria-label="<?php echo esc_attr(littleinka_t(__('Azioni rapide', 'littleinka-child-theme'), 'ui:actionbar')); ?>">
    <a class="li-btn li-btn--primary" href="<?php echo esc_url($li_menu_url); ?>"><?php echo esc_html(littleinka_is_portal() ? littleinka_t(__('Scegli la sede', 'littleinka-child-theme'), 'header:scegli') : __('Ordina online', 'littleinka-child-theme')); ?></a>
</nav>
<?php endif; ?>
