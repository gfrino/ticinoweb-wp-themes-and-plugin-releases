<?php
/**
 * Portale di tutte le sedi (littleinka.ch): come il vecchio sito, senza Elementor. Fiori sullo sfondo, al centro
 * il logo, il campo CAP (plugin dell'app: dice quali sedi consegnano nel CAP), le schede «Consegna a domicilio» /
 * «Ritiro in sede» con le card delle sedi, i link legali. Tutti i dati vengono dalle schede «Sede» e dai siti delle sedi.
 */
defined('ABSPATH') || exit;

$li_sedi     = littleinka_portal_sedi();
$li_delivery = array_values(array_filter($li_sedi, function ($s) { return $s['delivery']; }));
$li_pickup   = array_values(array_filter($li_sedi, function ($s) { return $s['pickup']; }));
$li_logo     = function_exists('ticinoweb_get_site_logo') ? (string) ticinoweb_get_site_logo() : '';
$li_logo_id  = $li_logo !== '' ? attachment_url_to_postid($li_logo) : 0;
$li_name     = get_bloginfo('name');
$li_tagline  = get_bloginfo('description');
$li_terms    = get_page_by_path('condizioni-di-vendita');
$li_privacy  = (int) get_option('wp_page_for_privacy_policy') ?: (get_page_by_path('privacy-policy') ? get_page_by_path('privacy-policy')->ID : 0);

$li_card = function (array $s) {
    $lines = '';
    if ($s['consegna']) {
        $lines .= '<span class="li-portal__line">' . littleinka_icon('bag', 16) . esc_html(implode(' + ', $s['consegna'])) . '</span>';
    }
    if ($s['offerta']) {
        $lines .= '<span class="li-portal__line">' . littleinka_icon('leaf', 16) . esc_html(implode(' + ', $s['offerta'])) . '</span>';
    }
    return '<li><a class="li-portal__card" href="' . esc_url($s['url']) . '">'
        . '<span class="li-portal__card-body"><span class="li-portal__card-title">' . esc_html($s['title']) . '</span>' . $lines . '</span>'
        . '<span class="li-portal__chev" aria-hidden="true">' . littleinka_icon('chevron', 28) . '</span></a></li>';
};
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php wp_head(); ?>
</head>
<body <?php body_class('li-portal-page'); ?>>
<?php wp_body_open(); ?>
<main id="li-main" class="li-portal">
    <div class="li-portal__panel">
        <header class="li-portal__brand">
            <?php if ($li_logo_id) : ?>
                <?php echo wp_get_attachment_image($li_logo_id, 'medium', false, array('class' => 'li-portal__logo', 'alt' => '', 'loading' => 'eager', 'fetchpriority' => 'high', 'sizes' => '72px')); ?>
            <?php elseif ($li_logo !== '') : ?>
                <img class="li-portal__logo" src="<?php echo esc_url($li_logo); ?>" alt="" width="72" height="60">
            <?php endif; ?>
            <div>
                <h1 class="li-portal__name"><?php echo esc_html($li_name); ?></h1>
                <?php if ($li_tagline !== '') : ?><p class="li-portal__tagline"><?php echo esc_html($li_tagline); ?></p><?php endif; ?>
            </div>
        </header>

        <?php if (shortcode_exists('wpadr_cap_selector')) : ?>
            <div class="li-portal__cap">
                <?php echo do_shortcode('[wpadr_cap_selector placeholder="' . esc_attr(littleinka_t(__('Inserisci il tuo CAP…', 'littleinka-child-theme'), 'portal:cap')) . '"]'); ?>
            </div>
        <?php endif; ?>

        <div class="li-portal__tabs" role="tablist" aria-label="<?php echo esc_attr(littleinka_t(__('Come vuoi ordinare', 'littleinka-child-theme'), 'portal:tabs')); ?>">
            <button class="li-portal__tab" type="button" role="tab" id="li-tab-consegna" aria-controls="li-panel-consegna" aria-selected="true"><?php esc_html_e('Consegna a domicilio', 'littleinka-child-theme'); ?></button>
            <button class="li-portal__tab" type="button" role="tab" id="li-tab-ritiro" aria-controls="li-panel-ritiro" aria-selected="false" tabindex="-1"><?php esc_html_e('Ritiro in sede', 'littleinka-child-theme'); ?></button>
        </div>
        <ul class="li-portal__list" role="tabpanel" id="li-panel-consegna" aria-labelledby="li-tab-consegna">
            <?php foreach ($li_delivery as $li_s) { echo $li_card($li_s); } // phpcs:ignore WordPress.Security.EscapeOutput -- escape nella funzione ?>
        </ul>
        <ul class="li-portal__list" role="tabpanel" id="li-panel-ritiro" aria-labelledby="li-tab-ritiro" hidden>
            <?php foreach ($li_pickup as $li_s) { echo $li_card($li_s); } // phpcs:ignore WordPress.Security.EscapeOutput ?>
        </ul>

        <nav class="li-portal__legal" aria-label="<?php echo esc_attr(littleinka_t(__('Informazioni legali', 'littleinka-child-theme'), 'portal:legal')); ?>">
            <?php if ($li_terms) : ?><a href="<?php echo esc_url(get_permalink($li_terms)); ?>"><?php echo esc_html(get_the_title($li_terms)); ?></a><?php endif; ?>
            <?php if ($li_privacy) : ?><a href="<?php echo esc_url(get_permalink($li_privacy)); ?>"><?php echo esc_html(get_the_title($li_privacy)); ?></a><?php endif; ?>
        </nav>
    </div>
</main>
<script>
(function () {
  var tabs = Array.prototype.slice.call(document.querySelectorAll('.li-portal__tab'));
  tabs.forEach(function (tab, i) {
    tab.addEventListener('click', function () { select(i); });
    tab.addEventListener('keydown', function (e) {
      if (e.key === 'ArrowRight' || e.key === 'ArrowLeft') { var j = (i + (e.key === 'ArrowRight' ? 1 : tabs.length - 1)) % tabs.length; select(j); tabs[j].focus(); }
    });
  });
  function select(n) {
    tabs.forEach(function (t, k) {
      t.setAttribute('aria-selected', k === n ? 'true' : 'false');
      t.tabIndex = k === n ? 0 : -1;
      document.getElementById(t.getAttribute('aria-controls')).hidden = k !== n;
    });
  }
})();
</script>
<?php wp_footer(); ?>
</body>
</html>
