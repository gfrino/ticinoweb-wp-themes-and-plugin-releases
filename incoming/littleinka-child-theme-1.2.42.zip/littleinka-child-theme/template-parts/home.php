<?php
/**
 * La vecchia home della sede (hero con le foto, orari, menu in breve, poké, consegna, app), usata solo se la sede
 * non ha una pagina con [littleinka_menu]: di norma la home della sede è il menu (front-page.php).
 * La descrizione completa dei blocchi è in front-page.php della 1.0.13.
 */
defined('ABSPATH') || exit;

get_header();
if (have_posts()) {
    the_post();
}

$li_offer     = littleinka_offer();
$li_poke_only = $li_offer === 'poke';
$li_label     = littleinka_offer_label();
$li_delivery  = littleinka_delivery();
$li_short     = littleinka_short_name();
$li_city      = littleinka_city();
$li_site_name = function_exists('ticinoweb_frontend_text') ? ticinoweb_frontend_text(get_bloginfo('name'), 'theme:branding:site_name') : get_bloginfo('name');
$li_contact   = function_exists('ticinoweb_get_contact_info') ? ticinoweb_get_contact_info() : array();
$li_menu_url  = littleinka_menu_url();
$li_poke_url  = littleinka_poke_url();
$li_rows      = littleinka_hours_rows();
$li_address   = littleinka_address_line();
$li_phone     = (string) (($li_contact['phone_landline'] ?? '') ?: ($li_contact['phone'] ?? ''));
$li_apps      = littleinka_app_links();
$li_closed    = __('Chiuso', 'littleinka-child-theme');
$li_map_url   = (string) ($li_contact['map_url'] ?? '');
if ($li_map_url === '' && $li_address !== '') {
    $li_map_url = 'https://www.openstreetmap.org/search?query=' . rawurlencode($li_address);
}

/* Dati degli altri moduli, con ripiego vuoto. */
$li_dishes    = function_exists('littleinka_featured_dishes') ? (array) littleinka_featured_dishes(8) : array();
$li_sizes     = ($li_poke_url !== '' && function_exists('littleinka_poke_sizes')) ? (array) littleinka_poke_sizes() : array();
$li_included  = ($li_sizes && function_exists('littleinka_poke_included')) ? (array) littleinka_poke_included() : array();
$li_menu_data = function_exists('littleinka_menu_data') ? (array) littleinka_menu_data() : array();
$li_tiles     = array_slice($li_dishes, 0, 4);

/* Piccoli aiuti del template. */
$li_img = function ($id, $size, $sizes, $class = '', $eager = false) {
    $id = (int) $id;
    if (!$id || !wp_attachment_is_image($id)) {
        return '';
    }
    $attrs = array('class' => $class, 'decoding' => 'async', 'sizes' => $sizes);
    if ($eager) {
        $attrs['loading'] = 'eager';
        $attrs['fetchpriority'] = 'high';
    } else {
        $attrs['loading'] = 'lazy';
    }
    return wp_get_attachment_image($id, $size, false, $attrs);
};
$li_join = function (array $parts) {
    $parts = array_values(array_filter($parts));
    if (count($parts) < 2) {
        return implode('', $parts);
    }
    $last = array_pop($parts);
    return implode(', ', $parts) . ' ' . littleinka_t(__('e', 'littleinka-child-theme'), 'fascia:e') . ' ' . $last;
};
$li_num_word = function ($n) {
    $words = array(1 => __('una', 'littleinka-child-theme'), __('due', 'littleinka-child-theme'), __('tre', 'littleinka-child-theme'), __('quattro', 'littleinka-child-theme'), __('cinque', 'littleinka-child-theme'), __('sei', 'littleinka-child-theme'));
    return isset($words[(int) $n]) ? littleinka_t($words[(int) $n], 'num:' . (int) $n) : number_format_i18n((int) $n);
};
$li_lower = function ($text) {
    return function_exists('mb_strtolower') ? mb_strtolower((string) $text, 'UTF-8') : strtolower((string) $text);
};
$li_ucfirst = function ($text) {
    $text = (string) $text;
    return function_exists('mb_substr') ? mb_strtoupper(mb_substr($text, 0, 1, 'UTF-8'), 'UTF-8') . mb_substr($text, 1, null, 'UTF-8') : ucfirst($text);
};

/* Foto: l'hero dall'impostazione, poi l'immagine in evidenza, poi il primo piatto; le altre dai piatti in evidenza. */
$li_hero_id = (int) littleinka_setting('hero_image', 0);
if (!$li_hero_id || !wp_attachment_is_image($li_hero_id)) {
    $li_hero_id = (int) get_post_thumbnail_id();
}
$li_pool = array();
foreach (array_merge(array_slice($li_dishes, 4), array_slice($li_dishes, 0, 4)) as $li_dish) {
    $li_dish_img = is_object($li_dish) && method_exists($li_dish, 'get_image_id') ? (int) $li_dish->get_image_id() : 0;
    if ($li_dish_img && $li_dish_img !== $li_hero_id && !in_array($li_dish_img, $li_pool, true)) {
        $li_pool[] = $li_dish_img;
    }
}
if (!$li_hero_id && $li_pool) {
    $li_hero_id = array_shift($li_pool);
}
$li_next_photo = function () use (&$li_pool) {
    return $li_pool ? array_shift($li_pool) : 0;
};

/* Hero: le foto dei piatti che scorrono in due file, con il logo al centro. Servono almeno 4 foto, altrimenti resta la foto singola. */
$li_reel = array();
// 1. Le foto scelte dalla sede: galleria «striscia-home» in Media → Gallerie media (del CMS).
foreach (littleinka_gallery_images('striscia-home', 16) as $li_gid) {
    $li_reel[] = array('id' => $li_gid, 'name' => '');
}
// 2. Altrimenti (o se sono poche) le foto dei piatti in evidenza e del menu.
if (count($li_reel) < 4 && function_exists('littleinka_featured_dishes')) {
    foreach (littleinka_featured_dishes(14) as $li_dish) {
        $li_dish_img = is_object($li_dish) && method_exists($li_dish, 'get_image_id') ? (int) $li_dish->get_image_id() : 0;
        if ($li_dish_img && !in_array($li_dish_img, $li_reel, true)) {
            $li_reel[] = array('id' => $li_dish_img, 'name' => wp_strip_all_tags($li_dish->get_name()));
        }
    }
}
// Poche foto tra i piatti in evidenza (sedi solo poké): si completano con le foto degli altri piatti del menu, senza bibite e accessori.
if (count($li_reel) < 10 && function_exists('littleinka_menu_data')) {
    $li_seen = wp_list_pluck($li_reel, 'id');
    foreach (littleinka_menu_data() as $li_group) {
        if (in_array($li_group['term']->slug, array('bibite', 'accessori', 'dessert', 'desserts'), true)) {
            continue;
        }
        foreach ($li_group['products'] as $li_product) {
            $li_pid = (int) $li_product->get_image_id();
            if ($li_pid && !in_array($li_pid, $li_seen, true)) {
                $li_seen[] = $li_pid;
                $li_reel[] = array('id' => $li_pid, 'name' => wp_strip_all_tags($li_product->get_name()));
            }
            if (count($li_reel) >= 14) {
                break 2;
            }
        }
    }
}
$li_reel_rows = array();
if (count($li_reel) >= 4) {
    $li_half = (int) ceil(count($li_reel) / 2);
    $li_reel_rows = count($li_reel) >= 8 ? array(array_slice($li_reel, 0, $li_half), array_slice($li_reel, $li_half)) : array($li_reel, array_reverse($li_reel));
}
$li_logo_url  = function_exists('ticinoweb_get_site_logo') ? (string) ticinoweb_get_site_logo() : '';
$li_logo_att  = $li_logo_url !== '' ? attachment_url_to_postid($li_logo_url) : 0;

/* h1: «Poké e sushi in Via Murate, Bellinzona» oppure «Poké da asporto a Castione, Arbedo». */
$li_place = $li_short !== '' ? $li_short : $li_city;
if ($li_place === '') {
    /* translators: 1: «Poké e sushi» o «Poké», 2: nome del sito */
    $li_h1 = sprintf(littleinka_t(__('%1$s da %2$s', 'littleinka-child-theme'), 'hero:h1_sito'), $li_label, $li_site_name);
} elseif ($li_poke_only) {
    $li_h1 = ($li_city !== '' && $li_city !== $li_place)
        /* translators: 1: nome breve della sede, 2: città */
        ? sprintf(littleinka_t(__('Poké da asporto a %1$s, %2$s', 'littleinka-child-theme'), 'hero:h1_poke_citta'), $li_place, $li_city)
        /* translators: %s: nome della sede o città */
        : sprintf(littleinka_t(__('Poké da asporto a %s', 'littleinka-child-theme'), 'hero:h1_poke'), $li_place);
} else {
    $li_h1 = ($li_city !== '' && $li_city !== $li_place)
        /* translators: 1: «Poké e sushi», 2: nome breve della sede (via o quartiere), 3: città */
        ? sprintf(littleinka_t(__('%1$s in %2$s, %3$s', 'littleinka-child-theme'), 'hero:h1_via'), $li_label, $li_place, $li_city)
        /* translators: 1: «Poké e sushi», 2: città */
        : sprintf(littleinka_t(__('%1$s a %2$s', 'littleinka-child-theme'), 'hero:h1_citta'), $li_label, $li_place);
}

/* Sottotitolo: «Aperto tutti i giorni 10:00 – 22:00. Consegna a domicilio e ritiro in sede.» */
$li_lead = array();
foreach ($li_rows as $li_row) {
    if ($li_row['hours'] !== $li_closed) {
        /* translators: 1: giorni («tutti i giorni», «lunedì – venerdì»), 2: orari */
        $li_lead[] = sprintf(littleinka_t(__('Aperto %1$s %2$s.', 'littleinka-child-theme'), 'hero:aperto'), $li_lower($li_row['days']), str_replace(', ', ' ' . littleinka_t(__('e', 'littleinka-child-theme'), 'fascia:e') . ' ', $li_row['hours']));
        break;
    }
}
if ($li_delivery['delivery'] && $li_delivery['pickup']) {
    $li_lead[] = littleinka_t(__('Consegna a domicilio e ritiro in sede.', 'littleinka-child-theme'), 'hero:metodi_entrambi');
} elseif ($li_delivery['delivery']) {
    $li_lead[] = littleinka_t(__('Consegna a domicilio.', 'littleinka-child-theme'), 'hero:metodi_consegna');
} elseif ($li_delivery['pickup']) {
    $li_lead[] = littleinka_t(__('Ordina online e ritira in sede.', 'littleinka-child-theme'), 'hero:metodi_ritiro');
} else {
    $li_lead[] = littleinka_t(__('Ordina online.', 'littleinka-child-theme'), 'hero:metodi_online');
}

/* Indirizzo: via e resto, e la via senza numero civico per il momento tipografico. */
$li_addr_parts = $li_address !== '' ? explode(', ', $li_address, 2) : array();
$li_street     = $li_addr_parts[0] ?? '';
$li_addr_rest  = $li_addr_parts[1] ?? '';
// Per il titolo grande si prende la riga con la via, saltando «c/o …» o «presso …» (es. «c/o Stazione FFS Biasca, Via Bellinzona 6»).
$li_street_line = $li_street;
foreach (array_map('trim', explode(',', $li_address)) as $li_part) {
    if ($li_part !== '' && !preg_match('/^(c\/o|presso|c\.o\.)\b/iu', $li_part)) {
        $li_street_line = $li_part;
        break;
    }
}
$li_street_bare = trim((string) preg_replace('/\s+\d+\s*[A-Za-z]?$/u', '', $li_street_line));
$li_moment = implode(', ', array_filter(array($li_street_bare !== '' ? $li_street_bare : $li_short, $li_city !== '' && $li_city !== $li_street_bare ? $li_city : '')));

/* Foto di Orari e indirizzo: immagine in evidenza della pagina Contatti, altrimenti un piatto. */
$li_visit_img = 0;
$li_contact_page = get_page_by_path('contatti');
if ($li_contact_page instanceof WP_Post && $li_contact_page->post_status === 'publish') {
    $li_visit_img = (int) get_post_thumbnail_id($li_contact_page);
}
if (!$li_visit_img) {
    $li_visit_img = $li_next_photo();
}
$li_slots_delivery = $li_delivery['delivery'] ? littleinka_slots_line('delivery') : '';
$li_slots_pickup   = $li_delivery['pickup'] ? littleinka_slots_line('pickup') : '';
$li_open_line      = littleinka_open_now_line();

/* Il menu: nomi delle prime categorie per il titolo, prezzo più basso, poké della casa e altre categorie. */
$li_cat_names = array();
$li_other_cats = array();
$li_house = array();
$li_min_price = 0.0;
foreach ($li_menu_data as $li_group) {
    $li_term = $li_group['term'] ?? null;
    if (!($li_term instanceof WP_Term)) {
        continue;
    }
    foreach ((array) ($li_group['products'] ?? array()) as $li_product) {
        if (in_array($li_term->slug, littleinka_poke_side_slugs(), true) && $li_term->slug !== 'poke-bowl') {
            break;
        }
        if (is_object($li_product) && method_exists($li_product, 'get_price')) {
            $li_p = (float) $li_product->get_price();
            if ($li_p > 0 && ($li_min_price === 0.0 || $li_p < $li_min_price)) {
                $li_min_price = $li_p;
            }
        }
    }
    if ($li_term->slug === 'crea-la-tua-poke') {
        continue;
    }
    if (count($li_cat_names) < 3) {
        $li_cat_names[] = $li_cat_names ? $li_lower(littleinka_menu_term_label($li_term)) : littleinka_menu_term_label($li_term);
    }
    // Le poké della casa: la categoria «poke-bowl»; le altre categorie della sede solo poké finiscono in «Anche …».
    if ($li_term->slug === 'poke-bowl') {
        $li_house = array_slice((array) ($li_group['products'] ?? array()), 0, 6);
        continue;
    }
    if ($li_poke_only) {
        $li_other_cats[] = $li_lower(littleinka_menu_term_label($li_term));
    }
}
if (!$li_house && $li_poke_only) {
    $li_house = array_slice($li_dishes, 0, 6);
}
?>
<main id="li-main" class="li-main li-home">

    <section class="li-hero" aria-labelledby="li-hero-title">
        <?php if ($li_reel_rows) : ?>
            <div class="li-hero__reel" data-li-reel>
                <?php foreach ($li_reel_rows as $li_row_i => $li_row_imgs) : ?>
                    <div class="li-hero__row li-hero__row--<?php echo $li_row_i ? 'right' : 'left'; ?>" aria-hidden="true">
                        <div class="li-hero__track">
                            <?php
                            // Ogni metà della fila è più larga di qualunque schermo (almeno ~2800 px, 256 px per foto),
                            // e la fila contiene due metà uguali: scorrendo di metà larghezza il giro si chiude senza buchi.
                            $li_half_rep = max(1, (int) ceil(11 / max(1, count($li_row_imgs))));
                            $li_half     = array();
                            for ($li_rep = 0; $li_rep < $li_half_rep; $li_rep++) {
                                $li_half = array_merge($li_half, $li_row_imgs);
                            }
                            foreach (array(0, 1) as $li_copy) {
                                foreach ($li_half as $li_k => $li_r) {
                                    $li_first = !$li_copy && !$li_row_i && $li_k < 3;
                                    echo '<figure class="li-hero__tile">' . wp_get_attachment_image($li_r['id'], 'woocommerce_thumbnail', false, array( // phpcs:ignore WordPress.Security.EscapeOutput -- immagine di WordPress
                                        'class'         => 'li-hero__tile-img',
                                        'alt'           => '',
                                        'sizes'         => '(max-width: 639px) 150px, 240px',
                                        // tutte subito: sono miniature e le copie ripetute riusano lo stesso file
                                        'loading'       => 'eager',
                                        'fetchpriority' => $li_first ? 'high' : 'low',
                                        'decoding'      => 'async',
                                    )) . '</figure>';
                                }
                            }
                            ?>
                        </div>
                    </div>
                <?php endforeach; ?>
                <?php if ($li_logo_url !== '') : ?>
                    <div class="li-hero__badge">
                        <?php
                        echo $li_logo_att // phpcs:ignore WordPress.Security.EscapeOutput -- immagine di WordPress o tag escapato
                            ? wp_get_attachment_image($li_logo_att, 'medium', false, array('class' => 'li-hero__badge-img', 'alt' => get_bloginfo('name'), 'loading' => 'eager', 'decoding' => 'async', 'sizes' => '140px'))
                            : '<img class="li-hero__badge-img" src="' . esc_url($li_logo_url) . '" alt="' . esc_attr(get_bloginfo('name')) . '" width="140" height="117">';
                        ?>
                    </div>
                <?php endif; ?>
                <button class="li-hero__pause" type="button" aria-pressed="false" data-label-pause="<?php echo esc_attr(littleinka_t(__('Ferma le foto', 'littleinka-child-theme'), 'hero:pausa')); ?>" data-label-play="<?php echo esc_attr(littleinka_t(__('Fai scorrere le foto', 'littleinka-child-theme'), 'hero:riprendi')); ?>" aria-label="<?php echo esc_attr(littleinka_t(__('Ferma le foto', 'littleinka-child-theme'), 'hero:pausa')); ?>">
                    <svg class="li-hero__pause-icon" viewBox="0 0 24 24" width="16" height="16" aria-hidden="true" focusable="false"><path d="M8 5v14M16 5v14" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"/></svg>
                    <svg class="li-hero__play-icon" viewBox="0 0 24 24" width="16" height="16" aria-hidden="true" focusable="false"><path d="M8 5l11 7-11 7z" fill="currentColor"/></svg>
                </button>
            </div>
        <?php elseif ($li_hero_id) : ?>
            <div class="li-hero__photo"><?php echo $li_img($li_hero_id, 'full', '100vw', 'li-hero__img', true); // phpcs:ignore WordPress.Security.EscapeOutput -- immagine di WordPress ?></div>
        <?php endif; ?>
        <div class="li-wrap li-hero__grid">
            <h1 id="li-hero-title" class="li-h1 li-hero__title"><?php echo esc_html($li_h1); ?></h1>
            <div class="li-hero__text">
                <p class="li-hero__lead"><?php echo esc_html(implode(' ', $li_lead)); ?></p>
                <p class="li-hero__cta"><a class="li-btn li-btn--primary" href="<?php echo esc_url($li_menu_url); ?>" data-li-hero-cta><?php esc_html_e('Ordina online', 'littleinka-child-theme'); ?><?php echo littleinka_icon('arrow', 14); // phpcs:ignore WordPress.Security.EscapeOutput -- SVG del tema ?></a></p>
            </div>
        </div>
    </section>

    <section class="li-section li-visit-section" id="orari" aria-labelledby="li-visit-title">
        <div class="li-wrap">
            <h2 id="li-visit-title" class="li-h2 li-section__title">
                <?php
                echo esc_html($li_city !== ''
                    /* translators: %s: città della sede */
                    ? sprintf(littleinka_t(__('Orari e indirizzo a %s', 'littleinka-child-theme'), 'visit:titolo_citta'), $li_city)
                    : littleinka_t(__('Orari e indirizzo', 'littleinka-child-theme'), 'visit:titolo'));
                ?>
            </h2>
            <?php if ($li_moment !== '') : ?>
                <p class="li-moment"><a class="li-moment__link" href="<?php echo esc_url($li_map_url); ?>" target="_blank" rel="noopener"><?php echo esc_html($li_moment); ?></a></p>
            <?php endif; ?>
            <div class="li-visit-grid">
                <div class="li-visit">
                    <?php if ($li_open_line !== '') : ?>
                        <p class="li-visit__open"><span class="li-visit__dot" aria-hidden="true"></span><?php echo esc_html($li_open_line); ?></p>
                    <?php endif; ?>
                    <div class="li-visit__cols">
                        <div class="li-visit__col">
                            <?php if ($li_address !== '') : ?>
                                <address class="li-visit__address"><a href="<?php echo esc_url($li_map_url); ?>" target="_blank" rel="noopener"><?php echo esc_html($li_street); ?><?php if ($li_addr_rest !== '') : ?><br><?php echo esc_html($li_addr_rest); ?><?php endif; ?></a></address>
                            <?php endif; ?>
                            <?php if ($li_phone !== '') : ?>
                                <p class="li-visit__phone"><a href="<?php echo esc_url(littleinka_tel($li_phone)); ?>"><?php echo esc_html($li_phone); ?></a></p>
                                <p class="li-visit__call"><a class="li-btn li-btn--secondary" href="<?php echo esc_url(littleinka_tel($li_phone)); ?>"><?php echo littleinka_icon('phone', 16); // phpcs:ignore WordPress.Security.EscapeOutput ?><?php esc_html_e('Chiama la sede', 'littleinka-child-theme'); ?></a></p>
                            <?php endif; ?>
                        </div>
                        <?php if ($li_rows) : ?>
                            <div class="li-visit__col">
                                <dl class="li-hours">
                                    <?php foreach ($li_rows as $li_row) : ?>
                                        <dt<?php echo !empty($li_row['today']) ? ' class="is-today"' : ''; ?>><?php echo esc_html($li_row['days']); ?></dt>
                                        <dd<?php echo !empty($li_row['today']) ? ' class="is-today"' : ''; ?>><?php echo esc_html($li_row['hours']); ?></dd>
                                    <?php endforeach; ?>
                                </dl>
                            </div>
                        <?php endif; ?>
                    </div>
                    <?php if ($li_slots_delivery !== '' || $li_slots_pickup !== '') : ?>
                        <ul class="li-visit__rows">
                            <?php if ($li_slots_delivery !== '') : ?>
                                <li><span><?php esc_html_e('Consegna', 'littleinka-child-theme'); ?></span><span><?php echo esc_html($li_slots_delivery); ?></span></li>
                            <?php endif; ?>
                            <?php if ($li_slots_pickup !== '') : ?>
                                <li><span><?php esc_html_e('Ritiro', 'littleinka-child-theme'); ?></span><span><?php echo esc_html($li_slots_pickup); ?></span></li>
                            <?php endif; ?>
                        </ul>
                    <?php endif; ?>
                </div>
                <?php $li_visit_html = $li_img($li_visit_img, 'large', '(max-width: 1023px) 100vw, 588px', 'li-photo__img'); ?>
                <?php if ($li_visit_html !== '') : ?>
                    <figure class="li-photo li-visit-photo"><?php echo $li_visit_html; // phpcs:ignore WordPress.Security.EscapeOutput ?></figure>
                <?php endif; ?>
            </div>
        </div>
    </section>

    <?php if (!$li_poke_only && ($li_tiles || $li_menu_data)) : ?>
        <section class="li-section li-section--surface li-menu-section" id="menu" aria-labelledby="li-menu-title">
            <div class="li-wrap">
                <div class="li-section__head li-section__head--split">
                    <div>
                        <h2 id="li-menu-title" class="li-h2 li-section__title"><?php echo esc_html(littleinka_t(__('Poké, sushi e piatti caldi', 'littleinka-child-theme'), 'menu:titolo')); ?></h2>
                        <p class="li-section__lead">
                            <?php
                            echo esc_html($li_min_price > 0
                                /* translators: %s: prezzo più basso del menu */
                                ? sprintf(littleinka_t(__('Il menu completo online, piatti da %s.', 'littleinka-child-theme'), 'menu:lead_prezzo'), littleinka_price($li_min_price))
                                : littleinka_t(__('Il menu completo online.', 'littleinka-child-theme'), 'menu:lead'));
                            ?>
                        </p>
                    </div>
                    <a class="li-link" href="<?php echo esc_url($li_menu_url); ?>"><?php esc_html_e('Tutte le categorie', 'littleinka-child-theme'); ?><?php echo littleinka_icon('arrow', 14); // phpcs:ignore WordPress.Security.EscapeOutput ?></a>
                </div>
                <?php if (function_exists('littleinka_menu_chips')) : ?>
                    <div class="li-menu-section__chips"><?php echo littleinka_menu_chips(); // phpcs:ignore WordPress.Security.EscapeOutput -- escape nel modulo menu ?></div>
                <?php endif; ?>
                <?php if ($li_tiles && function_exists('littleinka_product_tile')) : ?>
                    <div class="li-tiles">
                        <?php foreach ($li_tiles as $li_product) : ?>
                            <?php echo littleinka_product_tile($li_product); // phpcs:ignore WordPress.Security.EscapeOutput -- escape nel modulo menu ?>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </section>
    <?php endif; ?>

    <?php if (!$li_poke_only && $li_sizes) : ?>
        <?php
        $li_extras = array();
        $li_group_names = array();
        foreach ($li_included as $li_grp) {
            $li_group_names[] = $li_lower($li_grp['name'] ?? '');
            if (!empty($li_grp['extra'])) {
                $li_extras[] = $li_lower($li_grp['name'] ?? '') . ' ' . littleinka_price($li_grp['extra']);
            }
        }
        $li_poke_photos = array();
        foreach ($li_sizes as $li_size) {
            $li_sp = $li_size['product'] ?? null;
            $li_sp_img = is_object($li_sp) && method_exists($li_sp, 'get_image_id') ? (int) $li_sp->get_image_id() : 0;
            if ($li_sp_img && !in_array($li_sp_img, $li_poke_photos, true)) {
                $li_poke_photos[] = $li_sp_img;
            }
            if (count($li_poke_photos) >= 2) {
                break;
            }
        }
        while (count($li_poke_photos) < 2 && $li_pool) {
            $li_poke_photos[] = $li_next_photo();
        }
        ?>
        <section class="li-section li-section--surface li-poke-section" id="poke" aria-labelledby="li-poke-title">
            <div class="li-wrap">
                <div class="li-section__head li-section__head--split">
                    <div>
                        <h2 id="li-poke-title" class="li-h2 li-section__title">
                            <?php
                            echo esc_html(sprintf(
                                /* translators: %s: numero di misure in lettere (quattro) */
                                littleinka_t(_n('Crea la tua poké in una misura', 'Crea la tua poké in %s misure', count($li_sizes), 'littleinka-child-theme'), 'poke:titolo'),
                                $li_num_word(count($li_sizes))
                            ));
                            ?>
                        </h2>
                        <p class="li-section__lead">
                            <?php
                            echo esc_html($li_group_names
                                /* translators: %s: elenco dei gruppi (base, proteine, condimenti…) */
                                ? sprintf(littleinka_t(__('Scegli la misura, poi %s.', 'littleinka-child-theme'), 'poke:lead_gruppi'), $li_join($li_group_names))
                                : littleinka_t(__('Scegli la misura e componila come vuoi.', 'littleinka-child-theme'), 'poke:lead'));
                            ?>
                        </p>
                    </div>
                    <a class="li-link" href="<?php echo esc_url($li_poke_url); ?>"><?php esc_html_e('Componi la tua poké', 'littleinka-child-theme'); ?><?php echo littleinka_icon('arrow', 14); // phpcs:ignore WordPress.Security.EscapeOutput ?></a>
                </div>
                <div class="li-poke-grid">
                    <div class="li-poke-groups">
                        <div>
                            <p class="li-label"><?php esc_html_e('Misure', 'littleinka-child-theme'); ?></p>
                            <ul class="li-rows">
                                <?php foreach ($li_sizes as $li_size) : ?>
                                    <?php if (!is_object($li_size['product'] ?? null)) { continue; } ?>
                                    <li><span class="li-rows__name"><?php echo esc_html($li_size['product']->get_name()); ?></span><span class="li-rows__value"><?php echo esc_html(littleinka_price($li_size['price'] ?? 0)); ?></span></li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                        <?php if ($li_included) : ?>
                            <div>
                                <p class="li-label"><?php esc_html_e('Inclusi nel prezzo', 'littleinka-child-theme'); ?></p>
                                <ul class="li-rows">
                                    <?php foreach ($li_included as $li_grp) : ?>
                                        <?php
                                        $li_n = (int) ($li_grp['included'] ?? 0);
                                        if ($li_n > 0) {
                                            $li_value = number_format_i18n($li_n);
                                        } elseif (!empty($li_grp['extra'])) {
                                            /* translators: %s: prezzo di una porzione */
                                            $li_value = sprintf(littleinka_t(__('%s l\'uno', 'littleinka-child-theme'), 'poke:extra_cad'), littleinka_price($li_grp['extra']));
                                        } else {
                                            $li_value = littleinka_t(__('senza limite', 'littleinka-child-theme'), 'poke:senza_limite');
                                        }
                                        ?>
                                        <li><span class="li-rows__name"><?php echo esc_html($li_grp['name'] ?? ''); ?></span><span class="li-rows__value"><?php echo esc_html($li_value); ?></span></li>
                                    <?php endforeach; ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                    </div>
                    <?php if ($li_extras) : ?>
                        <?php /* translators: %s: elenco «proteine CHF 4.00, condimenti CHF 2.50» */ ?>
                        <p class="li-poke-note"><?php echo esc_html(sprintf(littleinka_t(__('Oltre le porzioni incluse: %s.', 'littleinka-child-theme'), 'poke:extra'), implode(', ', $li_extras))); ?></p>
                    <?php endif; ?>
                    <?php if ($li_poke_photos) : ?>
                        <div class="li-poke-pics">
                            <?php foreach ($li_poke_photos as $li_i => $li_pid) : ?>
                                <?php $li_html = $li_img($li_pid, 'large', '(max-width: 639px) 50vw, 282px', 'li-photo__img'); ?>
                                <?php if ($li_html !== '') : ?>
                                    <a class="li-photo li-zoom <?php echo $li_i === 0 ? 'li-photo--tall' : 'li-photo--square'; ?>" href="<?php echo esc_url($li_poke_url); ?>" tabindex="-1" aria-hidden="true"><?php echo $li_html; // phpcs:ignore WordPress.Security.EscapeOutput ?></a>
                                <?php endif; ?>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </section>
    <?php endif; ?>

    <?php if ($li_poke_only && ($li_house || $li_sizes)) : ?>
        <?php
        $li_merged_lead = array();
        if ($li_house) {
            /* translators: %s: numero di ricette in lettere (sei) */
            $li_merged_lead[] = sprintf(littleinka_t(_n('Una ricetta della casa', '%s ricette della casa', count($li_house), 'littleinka-child-theme'), 'poke:ricette'), $li_ucfirst($li_num_word(count($li_house))));
        }
        if ($li_sizes) {
            /* translators: %s: numero di misure in lettere (tre) */
            $li_merged_lead[] = sprintf(littleinka_t(_n('la tua in una misura', 'la tua in %s misure', count($li_sizes), 'littleinka-child-theme'), 'poke:misure_lead'), $li_num_word(count($li_sizes)));
        }
        $li_merged_text = $li_ucfirst(implode(' ' . littleinka_t(__('o', 'littleinka-child-theme'), 'poke:o') . ' ', $li_merged_lead)) . '.';
        if ($li_other_cats) {
            /* translators: %s: altre categorie («dessert e bibite») */
            $li_merged_text .= ' ' . sprintf(littleinka_t(__('Anche %s.', 'littleinka-child-theme'), 'poke:anche'), $li_join($li_other_cats));
        }
        $li_merged_photos = array_filter(array($li_next_photo(), $li_next_photo()));
        ?>
        <section class="li-section li-section--surface li-poke-section li-poke-section--merged" id="menu" aria-labelledby="li-poke-title">
            <div class="li-wrap">
                <div class="li-section__head li-section__head--split">
                    <div>
                        <h2 id="li-poke-title" class="li-h2 li-section__title"><?php echo esc_html($li_sizes ? littleinka_t(__('Poké della casa o su misura', 'littleinka-child-theme'), 'poke:titolo_fuso') : littleinka_t(__('Le poké della casa', 'littleinka-child-theme'), 'poke:titolo_casa')); ?></h2>
                        <p class="li-section__lead"><?php echo esc_html($li_merged_text); ?></p>
                    </div>
                    <a class="li-link" href="<?php echo esc_url($li_menu_url); ?>"><?php esc_html_e('Menu completo', 'littleinka-child-theme'); ?><?php echo littleinka_icon('arrow', 14); // phpcs:ignore WordPress.Security.EscapeOutput ?></a>
                </div>
                <div class="li-poke-grid">
                    <div class="li-poke-groups">
                        <?php if ($li_house) : ?>
                            <div>
                                <p class="li-label"><?php esc_html_e('Poké della casa', 'littleinka-child-theme'); ?></p>
                                <ul class="li-rows">
                                    <?php foreach ($li_house as $li_product) : ?>
                                        <?php if (!is_object($li_product) || !method_exists($li_product, 'get_name')) { continue; } ?>
                                        <li><span class="li-rows__name"><a href="<?php echo esc_url(get_permalink($li_product->get_id())); ?>"><?php echo esc_html($li_product->get_name()); ?></a></span><span class="li-rows__value"><?php echo esc_html(littleinka_price($li_product->get_price())); ?></span></li>
                                    <?php endforeach; ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                        <?php if ($li_sizes) : ?>
                            <div>
                                <p class="li-label"><a class="li-poke-groups__link" href="<?php echo esc_url($li_poke_url); ?>"><?php esc_html_e('Crea la tua poké', 'littleinka-child-theme'); ?></a></p>
                                <ul class="li-rows">
                                    <?php foreach ($li_sizes as $li_size) : ?>
                                        <?php if (!is_object($li_size['product'] ?? null)) { continue; } ?>
                                        <li><span class="li-rows__name"><?php echo esc_html($li_size['product']->get_name()); ?></span><span class="li-rows__value"><?php echo esc_html(littleinka_price($li_size['price'] ?? 0)); ?></span></li>
                                    <?php endforeach; ?>
                                    <?php foreach ($li_included as $li_grp) : ?>
                                        <?php if ((int) ($li_grp['included'] ?? 0) < 1) { continue; } ?>
                                        <?php /* translators: %s: numero di porzioni incluse */ ?>
                                        <li><span class="li-rows__name"><?php echo esc_html($li_grp['name'] ?? ''); ?></span><span class="li-rows__value"><?php echo esc_html(sprintf(littleinka_t(__('%s nel prezzo', 'littleinka-child-theme'), 'poke:nel_prezzo'), number_format_i18n((int) $li_grp['included']))); ?></span></li>
                                    <?php endforeach; ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                    </div>
                    <?php if ($li_merged_photos) : ?>
                        <div class="li-poke-pics">
                            <?php $li_i = 0; ?>
                            <?php foreach ($li_merged_photos as $li_pid) : ?>
                                <?php $li_html = $li_img($li_pid, 'large', '(max-width: 639px) 50vw, 282px', 'li-photo__img'); ?>
                                <?php if ($li_html !== '') : ?>
                                    <a class="li-photo li-zoom <?php echo $li_i === 0 ? 'li-photo--tall' : 'li-photo--square'; ?>" href="<?php echo esc_url($li_menu_url); ?>" tabindex="-1" aria-hidden="true"><?php echo $li_html; // phpcs:ignore WordPress.Security.EscapeOutput ?></a>
                                    <?php $li_i++; ?>
                                <?php endif; ?>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </section>
    <?php endif; ?>

    <?php if ($li_delivery['delivery'] || $li_delivery['pickup'] || $li_apps) : ?>
        <?php
        $li_order_parts = array();
        if ($li_delivery['delivery']) {
            $li_order_parts[] = littleinka_t(__('consegna a domicilio', 'littleinka-child-theme'), 'ordini:consegna');
        }
        if ($li_delivery['pickup']) {
            $li_order_parts[] = littleinka_t(__('ritiro in sede', 'littleinka-child-theme'), 'ordini:ritiro');
        }
        if ($li_apps) {
            $li_order_parts[] = littleinka_t(__('app', 'littleinka-child-theme'), 'ordini:app');
        }
        $li_order_title = $li_ucfirst($li_join($li_order_parts));
        $li_order_lead = '';
        if ($li_delivery['delivery'] && $li_delivery['min_order'] > 0) {
            /* translators: %s: importo dell'ordine minimo */
            $li_order_lead = sprintf(littleinka_t(__('Ordine minimo per la consegna %s.', 'littleinka-child-theme'), 'ordini:minimo'), littleinka_price($li_delivery['min_order']));
        } elseif (!$li_delivery['delivery']) {
            $li_order_lead = $li_apps
                ? littleinka_t(__('Ordina online o con l\'app, poi passa a prendere il tuo ordine.', 'littleinka-child-theme'), 'ordini:lead_ritiro_app')
                : littleinka_t(__('Ordina online, poi passa a prendere il tuo ordine.', 'littleinka-child-theme'), 'ordini:lead_ritiro');
        }
        /* Metodi di pagamento attivi in WooCommerce (titoli dei gateway), o niente. */
        $li_payments = array();
        if (function_exists('WC') && WC() && WC()->payment_gateways && WC()->cart) {
            foreach ((array) WC()->payment_gateways()->get_available_payment_gateways() as $li_gateway) {
                $li_gw_title = wp_strip_all_tags((string) $li_gateway->get_title());
                if ($li_gw_title !== '') {
                    $li_payments[] = $li_gw_title;
                }
            }
        }
        $li_cards = 0;
        ?>
        <section class="li-section li-orders" id="<?php echo $li_delivery['delivery'] ? 'consegna' : 'ritiro'; ?>" aria-labelledby="li-orders-title">
            <div class="li-wrap">
                <div class="li-section__head">
                    <h2 id="li-orders-title" class="li-h2 li-section__title"><?php echo esc_html($li_order_title); ?></h2>
                    <?php if ($li_order_lead !== '') : ?>
                        <p class="li-section__lead"><?php echo esc_html($li_order_lead); ?></p>
                    <?php endif; ?>
                </div>
                <div class="li-cards">
                    <?php if ($li_delivery['delivery']) : ?>
                        <?php
                        $li_cards++;
                        if ($li_delivery['free_from'] > 0) {
                            /* translators: %s: importo da cui la consegna è gratuita */
                            $li_card_title = sprintf(littleinka_t(__('Consegna gratis da %s', 'littleinka-child-theme'), 'ordini:gratis_da'), littleinka_price($li_delivery['free_from']));
                        } elseif ($li_delivery['fee_min'] > 0) {
                            /* translators: %s: costo di consegna più basso */
                            $li_card_title = sprintf(littleinka_t(__('Consegna da %s', 'littleinka-child-theme'), 'ordini:consegna_da'), littleinka_price($li_delivery['fee_min']));
                        } else {
                            $li_card_title = littleinka_t(__('Consegna a domicilio gratuita', 'littleinka-child-theme'), 'ordini:consegna_gratis');
                        }
                        $li_card_text = '';
                        if ($li_delivery['zones']) {
                            $li_zone_names = $li_join(array_map(static function ($zone) {
                                return (string) ($zone['name'] ?? '');
                            }, $li_delivery['zones']));
                            if ($li_delivery['fee_max'] > 0 && $li_delivery['fee_min'] !== $li_delivery['fee_max']) {
                                /* translators: 1: elenco delle zone, 2: costo minimo, 3: costo massimo */
                                $li_card_text = sprintf(littleinka_t(__('%1$s: da %2$s a %3$s.', 'littleinka-child-theme'), 'ordini:zone_range'), $li_zone_names, littleinka_price($li_delivery['fee_min']), littleinka_price($li_delivery['fee_max']));
                            } elseif ($li_delivery['fee_max'] > 0) {
                                /* translators: 1: elenco delle zone, 2: costo di consegna */
                                $li_card_text = sprintf(littleinka_t(__('%1$s: %2$s.', 'littleinka-child-theme'), 'ordini:zone_costo'), $li_zone_names, littleinka_price($li_delivery['fee_max']));
                            } else {
                                $li_card_text = $li_zone_names . '.';
                            }
                        }
                        ?>
                        <article class="li-card">
                            <?php $li_html = $li_img($li_next_photo(), 'large', '(max-width: 639px) 100vw, (max-width: 1023px) 50vw, 384px', 'li-card__img'); ?>
                            <?php if ($li_html !== '') : ?><a class="li-card__media li-zoom" href="<?php echo esc_url($li_menu_url); ?>" tabindex="-1" aria-hidden="true"><?php echo $li_html; // phpcs:ignore WordPress.Security.EscapeOutput ?></a><?php endif; ?>
                            <div class="li-card__body">
                                <p class="li-label"><?php esc_html_e('Consegna a domicilio', 'littleinka-child-theme'); ?></p>
                                <h3 class="li-h3 li-card__title"><?php echo esc_html($li_card_title); ?></h3>
                                <?php if ($li_card_text !== '') : ?><p><?php echo esc_html($li_card_text); ?></p><?php endif; ?>
                                <?php if ($li_slots_delivery !== '') : ?><p><?php echo esc_html(sprintf(/* translators: %s: fasce orarie */ littleinka_t(__('Consegniamo %s.', 'littleinka-child-theme'), 'ordini:fasce_consegna'), $li_slots_delivery)); ?></p><?php endif; ?>
                                <p class="li-card__links"><a class="li-link" href="<?php echo esc_url($li_menu_url); ?>"><?php esc_html_e('Ordina online', 'littleinka-child-theme'); ?><?php echo littleinka_icon('arrow', 14); // phpcs:ignore WordPress.Security.EscapeOutput ?></a></p>
                            </div>
                        </article>
                    <?php endif; ?>
                    <?php if ($li_delivery['pickup']) : ?>
                        <?php $li_cards++; ?>
                        <article class="li-card">
                            <?php $li_html = $li_img($li_next_photo(), 'large', '(max-width: 639px) 100vw, (max-width: 1023px) 50vw, 384px', 'li-card__img'); ?>
                            <?php if ($li_html !== '' && $li_map_url !== '') : ?><a class="li-card__media li-zoom" href="<?php echo esc_url($li_map_url); ?>" target="_blank" rel="noopener" tabindex="-1" aria-hidden="true"><?php echo $li_html; // phpcs:ignore WordPress.Security.EscapeOutput ?></a><?php elseif ($li_html !== '') : ?><div class="li-card__media"><?php echo $li_html; // phpcs:ignore WordPress.Security.EscapeOutput ?></div><?php endif; ?>
                            <div class="li-card__body">
                                <p class="li-label"><?php esc_html_e('Ritiro in sede', 'littleinka-child-theme'); ?></p>
                                <h3 class="li-h3 li-card__title">
                                    <?php
                                    echo esc_html($li_place !== ''
                                        /* translators: %s: nome breve della sede o città */
                                        ? sprintf(littleinka_t(__('Ritiro gratuito a %s', 'littleinka-child-theme'), 'ordini:ritiro_sede'), $li_place)
                                        : littleinka_t(__('Ritiro gratuito in sede', 'littleinka-child-theme'), 'ordini:ritiro_gratis'));
                                    ?>
                                </h3>
                                <p><?php esc_html_e('Quando ordini scegli il giorno e l\'orario di ritiro.', 'littleinka-child-theme'); ?></p>
                                <?php if ($li_slots_pickup !== '') : ?><p><?php echo esc_html(sprintf(/* translators: %s: fasce orarie */ littleinka_t(__('Ritiro %s.', 'littleinka-child-theme'), 'ordini:fasce_ritiro'), $li_slots_pickup)); ?></p><?php endif; ?>
                                <?php if ($li_map_url !== '') : ?><p class="li-card__links"><a class="li-link" href="<?php echo esc_url($li_map_url); ?>" target="_blank" rel="noopener"><?php esc_html_e('Indicazioni stradali', 'littleinka-child-theme'); ?><?php echo littleinka_icon('arrow', 14); // phpcs:ignore WordPress.Security.EscapeOutput ?></a></p><?php endif; ?>
                            </div>
                        </article>
                    <?php endif; ?>
                    <?php if ($li_apps) : ?>
                        <?php
                        $li_cards++;
                        $li_stores = array();
                        $li_devices = array();
                        if (!empty($li_apps['ios'])) {
                            $li_stores[] = 'App Store';
                            $li_devices[] = 'iPhone';
                        }
                        if (!empty($li_apps['android'])) {
                            $li_stores[] = 'Google Play';
                            $li_devices[] = 'Android';
                        }
                        $li_app_first = !empty($li_apps['ios']) ? $li_apps['ios'] : $li_apps['android'];
                        ?>
                        <article class="li-card" id="app">
                            <?php $li_html = $li_img($li_next_photo(), 'large', '(max-width: 639px) 100vw, (max-width: 1023px) 50vw, 384px', 'li-card__img'); ?>
                            <?php if ($li_html !== '') : ?><a class="li-card__media li-zoom" href="<?php echo esc_url($li_app_first); ?>" target="_blank" rel="noopener" tabindex="-1" aria-hidden="true"><?php echo $li_html; // phpcs:ignore WordPress.Security.EscapeOutput ?></a><?php endif; ?>
                            <div class="li-card__body">
                                <p class="li-label"><?php esc_html_e('App', 'littleinka-child-theme'); ?></p>
                                <?php /* translators: 1: nome del sito, 2: «iPhone e Android» */ ?>
                                <h3 class="li-h3 li-card__title"><?php echo esc_html(sprintf(littleinka_t(__('App %1$s per %2$s', 'littleinka-child-theme'), 'ordini:app_titolo'), $li_site_name, $li_join($li_devices))); ?></h3>
                                <?php /* translators: %s: «App Store e Google Play» */ ?>
                                <p><?php echo esc_html(sprintf(littleinka_t(__('Disponibile su %s.', 'littleinka-child-theme'), 'ordini:app_store'), $li_join($li_stores))); ?></p>
                                <p class="li-card__links">
                                    <?php if (!empty($li_apps['ios'])) : ?><a class="li-link" href="<?php echo esc_url($li_apps['ios']); ?>" target="_blank" rel="noopener"><?php esc_html_e('Scarica per iPhone', 'littleinka-child-theme'); ?><?php echo littleinka_icon('arrow', 14); // phpcs:ignore WordPress.Security.EscapeOutput ?></a><?php endif; ?>
                                    <?php if (!empty($li_apps['android'])) : ?><a class="li-link" href="<?php echo esc_url($li_apps['android']); ?>" target="_blank" rel="noopener"><?php esc_html_e('Scarica per Android', 'littleinka-child-theme'); ?><?php echo littleinka_icon('arrow', 14); // phpcs:ignore WordPress.Security.EscapeOutput ?></a><?php endif; ?>
                                </p>
                            </div>
                        </article>
                    <?php endif; ?>
                </div>
                <?php if ($li_payments) : ?>
                    <?php /* translators: %s: elenco dei metodi di pagamento */ ?>
                    <p class="li-orders__pay"><?php echo esc_html(sprintf(littleinka_t(__('Accettiamo %s.', 'littleinka-child-theme'), 'ordini:pagamenti'), $li_join($li_payments))); ?></p>
                <?php endif; ?>
            </div>
        </section>
    <?php endif; ?>

    <?php
    /* Il contenuto della pagina iniziale (testi SEO, FAQ del parent), se c'è: in colonna, oppure a tutta
       larghezza se è già fatto a sezioni (classi li-*) o contiene il menu o «Crea la tua poké». */
    $li_content = is_page() ? trim((string) get_the_content()) : '';
    if ($li_content !== '') :
        $li_raw = strpos($li_content, 'class="li-') !== false || has_shortcode($li_content, 'littleinka_menu') || has_shortcode($li_content, 'make_your_own_poke');
        ?>
        <?php if ($li_raw) : ?>
            <section class="li-section li-home__content"><?php the_content(); ?></section>
        <?php else : ?>
            <section class="li-section li-home__content"><div class="li-wrap li-prose"><?php the_content(); ?></div></section>
        <?php endif; ?>
    <?php endif; ?>
</main>
<?php
get_footer();
