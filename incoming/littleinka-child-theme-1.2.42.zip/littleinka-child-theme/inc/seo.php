<?php
/**
 * SEO della sede: lo schema Organization del parent diventa un «Restaurant» con indirizzo, telefono, orari,
 * cucina e link al menu (tutto letto dai dati del CMS, di WooCommerce e del tema), e una descrizione per Google
 * di riserva dove il parent non ne trova una (home, carrello, cassa, account, scheda prodotto).
 * Niente altro JSON-LD: quello dei prodotti lo stampa già WooCommerce.
 */
defined('ABSPATH') || exit;

/**
 * L'indirizzo spezzato per lo schema: ['street' => 'Via Murate 2', 'postcode' => '6500', 'city' => 'Bellinzona'].
 * Prima l'indirizzo del negozio WooCommerce (già a campi), poi la riga del CMS del parent.
 */
function littleinka_seo_address_parts()
{
    $street   = trim((string) get_option('woocommerce_store_address', ''));
    $postcode = trim((string) get_option('woocommerce_store_postcode', ''));
    $city     = trim((string) get_option('woocommerce_store_city', ''));
    if ($street === '' || $city === '') {
        $line = littleinka_address_line();
        if (preg_match('/^(.*?)[,\s]*\b(\d{4})\s+([^\d,]+?)\s*$/u', $line, $m)) {
            $street   = $street !== '' ? $street : trim($m[1], " ,\t");
            $postcode = $postcode !== '' ? $postcode : $m[2];
            $city     = $city !== '' ? $city : trim($m[3]);
        } elseif ($street === '' && $line !== '') {
            $street = $line;
        }
    }
    return array_filter(array('street' => $street, 'postcode' => $postcode, 'city' => $city), 'strlen');
}

/** Gli orari del CMS come OpeningHoursSpecification: una voce per ogni fascia, con i giorni che la condividono; i giorni chiusi non compaiono. */
function littleinka_seo_opening_hours()
{
    $days = array(
        'monday'    => 'Monday',
        'tuesday'   => 'Tuesday',
        'wednesday' => 'Wednesday',
        'thursday'  => 'Thursday',
        'friday'    => 'Friday',
        'saturday'  => 'Saturday',
        'sunday'    => 'Sunday',
    );
    $groups = array();
    foreach (littleinka_opening_hours() as $day => $data) {
        if (!isset($days[$day]) || !is_array($data) || !empty($data['closed'])) {
            continue;
        }
        $slots = !empty($data['open_24h']) ? array(array('open' => '00:00', 'close' => '23:59')) : (array) ($data['slots'] ?? array());
        foreach ($slots as $slot) {
            $open  = trim((string) ($slot['open'] ?? ''));
            $close = trim((string) ($slot['close'] ?? ''));
            if ($open === '' || $close === '') {
                continue;
            }
            $key = $open . '|' . $close;
            $groups[$key]['opens']  = $open;
            $groups[$key]['closes'] = $close;
            $groups[$key]['days'][] = $days[$day];
        }
    }
    $spec = array();
    foreach ($groups as $group) {
        $spec[] = array(
            '@type'     => 'OpeningHoursSpecification',
            'dayOfWeek' => array_values(array_unique($group['days'])),
            'opens'     => $group['opens'],
            'closes'    => $group['closes'],
        );
    }
    return $spec;
}

/** Il logo per lo schema: quello scelto nella SEO del parent, altrimenti il logo del sito. */
function littleinka_seo_logo_url()
{
    $logo = function_exists('tw_seo_get_org_logo') ? (string) tw_seo_get_org_logo() : '';
    if ($logo === '' && function_exists('ticinoweb_get_site_logo')) {
        $logo = (string) ticinoweb_get_site_logo();
    }
    return $logo;
}

/**
 * Lo schema della home: il parent costruisce Organization/LocalBusiness (nome, url, logo, social, e con
 * LocalBusiness telefono e indirizzo); qui diventa Restaurant e si completa con i dati della sede.
 * Quello che il parent ha già messo resta: si aggiunge, non si sostituisce.
 */
add_filter('ticinoweb_seo_jsonld_org_schema', function ($schema) {
    $schema = is_array($schema) ? $schema : array();
    $schema['@type'] = 'Restaurant';
    if (empty($schema['name'])) {
        $schema['name'] = littleinka_t(get_bloginfo('name'), 'seo:schema_name');
    }
    if (empty($schema['url'])) {
        $schema['url'] = function_exists('ticinoweb_frontend_url') ? ticinoweb_frontend_url(home_url('/'), 'theme:url:home') : home_url('/');
    }

    $address = littleinka_seo_address_parts();
    if ($address) {
        $postal = array('@type' => 'PostalAddress');
        if (isset($address['street'])) {
            $postal['streetAddress'] = $address['street'];
        }
        if (isset($address['postcode'])) {
            $postal['postalCode'] = $address['postcode'];
        }
        if (isset($address['city'])) {
            $postal['addressLocality'] = $address['city'];
        }
        $country = strtoupper(trim((string) strtok((string) get_option('woocommerce_default_country', ''), ':')));
        if (preg_match('/^[A-Z]{2}$/', $country)) {
            $postal['addressCountry'] = $country;
        }
        $schema['address'] = $postal;
    }

    if (empty($schema['telephone']) && function_exists('ticinoweb_get_contact_info')) {
        $contact = ticinoweb_get_contact_info();
        $phone = trim((string) ($contact['phone'] ?? ''));
        if ($phone === '') {
            $phone = trim((string) ($contact['phone_landline'] ?? ($contact['phone_mobile'] ?? '')));
        }
        if ($phone !== '') {
            $schema['telephone'] = $phone;
        }
    }

    $schema['servesCuisine'] = littleinka_offer() === 'sushi_poke' ? array('Poké', 'Sushi') : array('Poké');
    $hours = littleinka_seo_opening_hours();
    if ($hours) {
        $schema['openingHoursSpecification'] = $hours;
    }
    $schema['priceRange'] = 'CHF';
    $schema['hasMenu'] = littleinka_menu_url();
    $schema['acceptsReservations'] = false;

    $logo = littleinka_seo_logo_url();
    if ($logo !== '') {
        if (empty($schema['image'])) {
            $schema['image'] = $logo;
        }
        if (empty($schema['logo'])) {
            $schema['logo'] = $logo;
        }
    }
    return $schema;
});

/** Gli orari in una frase: «tutti i giorni 10:00 – 22:00» oppure «lunedì – venerdì 11:00 – 14:00, 18:00 – 22:00; sabato 11:00 – 22:00». */
function littleinka_seo_hours_sentence()
{
    $closed = array(__('Chiuso', 'littleinka-child-theme'), __('Chiuso', 'ticinoweb-ai-theme'));
    $parts = array();
    foreach (littleinka_hours_rows() as $row) {
        if (in_array($row['hours'], $closed, true) || $row['hours'] === '') {
            continue;
        }
        $parts[] = lcfirst($row['days']) . ' ' . $row['hours'];
    }
    return implode('; ', $parts);
}

/** La descrizione della home ricavata dai dati: «Poké e sushi in Via Murate, Bellinzona: consegna a domicilio e ritiro in sede. Aperto tutti i giorni 10:00 – 22:00.» */
function littleinka_seo_home_description()
{
    $name = littleinka_short_name();
    $city = littleinka_city();
    $place = $name;
    if ($city !== '' && mb_strtolower($city) !== mb_strtolower($name)) {
        $place .= ', ' . $city;
    }
    $delivery = littleinka_delivery();
    $how = '';
    if ($delivery['delivery'] && $delivery['pickup']) {
        $how = __('consegna a domicilio e ritiro in sede', 'littleinka-child-theme');
    } elseif ($delivery['delivery']) {
        $how = __('consegna a domicilio', 'littleinka-child-theme');
    } elseif ($delivery['pickup']) {
        $how = __('ritiro in sede', 'littleinka-child-theme');
    }
    /* translators: 1: offerta (Poké e sushi), 2: sede (Via Murate, Bellinzona) */
    $text = sprintf(__('%1$s in %2$s', 'littleinka-child-theme'), littleinka_offer_label(), $place);
    if ($how !== '') {
        $text .= ': ' . $how;
    }
    $text .= '.';
    $hours = littleinka_seo_hours_sentence();
    if ($hours !== '') {
        /* translators: %s: orari, es. «tutti i giorni 10:00 – 22:00» */
        $text .= ' ' . sprintf(__('Aperto %s.', 'littleinka-child-theme'), $hours);
    }
    return littleinka_t($text, 'seo:home_description');
}

/** Al massimo 160 caratteri, come fa il parent. */
function littleinka_seo_trim($text)
{
    $text = trim(preg_replace('/\s+/u', ' ', wp_strip_all_tags(strip_shortcodes((string) $text))));
    return mb_strlen($text) > 160 ? rtrim(mb_substr($text, 0, 157)) . '…' : $text;
}

/**
 * Descrizione per Google quando il parent non ne ha trovata una:
 *  - home: dai dati della sede;
 *  - carrello, cassa, account: quella della pagina Menu (campo SEO del parent), se c'è;
 *  - scheda prodotto: la descrizione breve del prodotto.
 */
add_filter('ticinoweb_seo_meta_description', function ($desc) {
    if (is_front_page()) {
        // La descrizione globale del parent è uguale per tutte le sedi (cita consegne e città che non valgono ovunque):
        // in home vale quella ricavata dai dati della sede, salvo che la pagina abbia un testo proprio.
        $own = trim((string) get_post_meta((int) get_queried_object_id(), '_tw_seo_description', true));
        return $own !== '' ? $desc : littleinka_seo_trim(littleinka_seo_home_description());
    }
    if (trim((string) $desc) !== '') {
        return $desc;
    }
    if (function_exists('is_cart') && (is_cart() || is_checkout() || is_account_page())) {
        $menu_id = littleinka_page_with_shortcode('littleinka_menu');
        $menu_desc = $menu_id ? trim((string) get_post_meta($menu_id, '_tw_seo_description', true)) : '';
        if ($menu_desc === '') {
            return $desc;
        }
        return littleinka_seo_trim(littleinka_t($menu_desc, 'theme:seo:meta_description'));
    }
    if (function_exists('is_product') && is_product()) {
        $product = function_exists('wc_get_product') ? wc_get_product(get_queried_object_id()) : null;
        $short = $product instanceof WC_Product ? trim((string) $product->get_short_description()) : '';
        if ($short === '') {
            return $desc;
        }
        $short = trim(preg_replace('/\s+/u', ' ', wp_strip_all_tags(strip_shortcodes($short))));
        if (mb_strlen($short) > 155) {
            $short = rtrim(mb_substr($short, 0, 152)) . '…';
        }
        return littleinka_t($short, 'theme:seo:meta_description');
    }
    return $desc;
});

/**
 * Vecchi indirizzi della sede (le pagine Menu e Poké si chiamavano «menu-2» e «poke-bowl-2» quando le copie WPML
 * si prendevano gli slug): il parent manda ogni 404 in home, qui si portano alla pagina giusta con un 301.
 */
add_action('template_redirect', function () {
    global $wp;
    if (is_admin() || empty($wp->request)) {
        return;
    }
    $legacy = apply_filters('littleinka_legacy_slugs', array(
        'menu-2'       => 'littleinka_menu_url',
        'poke-bowl-2'  => 'littleinka_poke_url',
    ));
    $last = basename((string) $wp->request);
    if (isset($legacy[$last]) && is_callable($legacy[$last])) {
        $target = (string) call_user_func($legacy[$last]);
        $here = trailingslashit(home_url('/' . $wp->request));
        if ($target !== '' && trailingslashit($target) !== $here) {
            wp_safe_redirect($target, 301);
            exit;
        }
    }
}, 1);

/** Sulla scheda prodotto il parent stamperebbe anche un «Article» con un autore: lo schema giusto è il Product di WooCommerce. */
add_action('wp', function () {
    if (function_exists('is_product') && is_product() && function_exists('tw_seo_inject_schema')) {
        remove_action('wp_footer', 'tw_seo_inject_schema');
    }
});
