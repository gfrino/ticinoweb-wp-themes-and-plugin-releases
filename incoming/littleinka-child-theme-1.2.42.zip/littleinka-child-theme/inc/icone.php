<?php
/**
 * Icone del tema: SVG su misura in assets/icons, stampati in linea.
 *
 * Generato da wp-themes/tools/icone (icone.mjs installa). Le icone si gestiscono
 * con quello strumento: stile e provenienza stanno in assets/icons/icone.json.
 * Nessuna libreria esterna: si carica solo l'SVG che la pagina usa davvero.
 *
 * Uso nei template:
 *   echo littleinka_icona( 'consulenza' );                                   // decorativa
 *   echo littleinka_icona( 'telefono', array( 'etichetta' => __( 'Telefono', 'td' ) ) );
 *   echo littleinka_icona( 'impianto', array( 'classe' => 'icona--disegna' ) );   // animata
 * Nei contenuti (editor, Elementor): [icona nome="consulenza"]
 *
 * @package child-theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Markup SVG di un'icona del tema.
 *
 * I file sono del tema, passati dal controllo di sicurezza di icone.mjs, e il
 * nome è ridotto a [a-z0-9-]: non si può uscire da assets/icons.
 *
 * @param string $nome Slug dell'icona (nome del file senza .svg).
 * @param array  $args {
 *     @type string $etichetta Testo per i lettori di schermo. Vuoto = icona decorativa.
 *     @type string $classe    Classi CSS in più.
 * }
 * @return string SVG pronto da stampare, oppure stringa vuota.
 */
function littleinka_icona( $nome, $args = array() ) {
	static $cache = array();

	$nome = preg_replace( '/[^a-z0-9-]/', '', strtolower( (string) $nome ) );
	if ( '' === $nome ) {
		return '';
	}
	if ( ! array_key_exists( $nome, $cache ) ) {
		$file           = get_stylesheet_directory() . '/assets/icons/' . $nome . '.svg';
		$cache[ $nome ] = is_readable( $file ) ? trim( (string) file_get_contents( $file ) ) : ''; // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
	}
	$svg = $cache[ $nome ];
	if ( '' === $svg ) {
		return '';
	}

	$args   = wp_parse_args( $args, array( 'etichetta' => '', 'classe' => '' ) );
	$classi = trim( 'icona icona--' . $nome . ' ' . $args['classe'] );
	$attr   = ' class="' . esc_attr( $classi ) . '" focusable="false"';
	$titolo = '';
	if ( '' !== $args['etichetta'] ) {
		$attr  .= ' role="img" aria-label="' . esc_attr( $args['etichetta'] ) . '"';
		$titolo = '<title>' . esc_html( $args['etichetta'] ) . '</title>';
	} else {
		$attr .= ' aria-hidden="true"';
	}

	// Inserimento per posizione, non con preg_replace: un "$1" nell'etichetta non deve diventare un riferimento.
	$fine = strpos( $svg, '>' );
	if ( 0 !== strpos( $svg, '<svg' ) || false === $fine ) {
		return '';
	}
	$svg = '<svg' . $attr . substr( $svg, 4, $fine - 4 ) . '>' . $titolo . substr( $svg, $fine + 1 );

	/** Permette di ritoccare un'icona senza toccare il file. */
	return (string) apply_filters( 'littleinka_icona', $svg, $nome, $args );
}

/**
 * Elenco degli slug disponibili (per select nel Personalizza o nei metabox).
 *
 * @return string[]
 */
function littleinka_icone_disponibili() {
	$file = glob( get_stylesheet_directory() . '/assets/icons/*.svg' );
	return array_map(
		static function ( $f ) {
			return basename( $f, '.svg' );
		},
		$file ? $file : array()
	);
}

/**
 * Foglio di stile delle icone: poche righe, versionato con il tema.
 */
function littleinka_icone_stile() {
	wp_enqueue_style(
		'littleinka-icone',
		get_stylesheet_directory_uri() . '/assets/css/icone.css',
		array(),
		wp_get_theme()->get( 'Version' )
	);
}
add_action( 'wp_enqueue_scripts', 'littleinka_icone_stile' );

/**
 * Shortcode [icona nome="…" etichetta="…" classe="…"] per i contenuti.
 *
 * @param array|string $atts Attributi dello shortcode.
 * @return string
 */
function littleinka_icona_shortcode( $atts ) {
	$atts = shortcode_atts( array( 'nome' => '', 'etichetta' => '', 'classe' => '' ), $atts, 'icona' );
	return littleinka_icona(
		$atts['nome'],
		array(
			'etichetta' => sanitize_text_field( $atts['etichetta'] ),
			'classe'    => sanitize_html_class( $atts['classe'] ),
		)
	);
}
add_action(
	'init',
	static function () {
		if ( ! shortcode_exists( 'icona' ) ) {
			add_shortcode( 'icona', 'littleinka_icona_shortcode' );
		}
	}
);
