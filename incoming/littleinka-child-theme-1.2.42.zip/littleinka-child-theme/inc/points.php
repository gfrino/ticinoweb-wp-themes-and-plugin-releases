<?php
/**
 * Inviti all'iscrizione con i punti fedeltà (plugin «Simple Point System for WooCommerce», punti-acquisto).
 * Il plugin assegna i punti solo a chi ha un account e mostra il riquadro alla cassa solo a chi ha fatto l'accesso:
 * qui il tema fa vedere a chi ordina come ospite quanti punti perderebbe e lo porta a iscriversi.
 *  - cassa: riquadro con i punti dell'ordine e la casella «Crea un account» in evidenza;
 *  - carrello e pulsante «Vai al carrello»: «+N punti con questo ordine»;
 *  - intestazione: «Accedi» per chi non è iscritto, il saldo per chi lo è;
 *  - sotto il banner del menu e nel modulo di registrazione: l'invito con il valore dei punti.
 * Nomi, valore e costo del punto si leggono dal plugin (impostazioni della sede principale): niente numeri nel tema.
 * Senza il plugin attivo non compare niente.
 */
defined('ABSPATH') || exit;

/** Il plugin dei punti è attivo su questa sede? */
function littleinka_points_active()
{
    return function_exists('PA_get_option') && function_exists('PA_get_user_points') && function_exists('WC') && !littleinka_is_portal();
}

/** Valore di un punto e spesa per guadagnarne uno, dalle impostazioni del plugin. */
function littleinka_points_rate()
{
    return array(
        'value' => max(0.0, (float) PA_get_option('pa_point_value', 1)),
        'cost'  => max(0.01, (float) PA_get_option('pa_point_cost', 10)),
    );
}

/** Nome del punto al singolare o al plurale («Health Dot» / «Health Dots»). */
function littleinka_points_label($amount)
{
    if (function_exists('PA_format_point_label')) {
        return (string) PA_format_point_label($amount);
    }
    return _n('punto', 'punti', (int) $amount, 'littleinka-child-theme');
}

/** Importo in valuta del negozio, testo semplice; senza decimali se è un intero (es. «CHF 10», «CHF 2.50»). */
function littleinka_points_money($amount)
{
    $args = abs($amount - round($amount)) < 0.005 ? array('decimals' => 0) : array();
    return html_entity_decode(wp_strip_all_tags(wc_price($amount, $args)), ENT_QUOTES, 'UTF-8');
}

/** Punti che si guadagnano con il carrello attuale (stesso calcolo del plugin: totale ÷ costo del punto, per difetto). */
function littleinka_points_for_cart()
{
    if (!littleinka_points_active() || !WC()->cart || WC()->cart->is_empty()) {
        return 0;
    }
    $total = (float) WC()->cart->get_total('edit');
    if ($total <= 0 && !did_action('woocommerce_before_calculate_totals')) {
        // Nelle risposte AJAX (frammenti dopo un'aggiunta) i totali possono non essere ancora calcolati.
        WC()->cart->calculate_totals();
        $total = (float) WC()->cart->get_total('edit');
    }
    $rate = littleinka_points_rate();
    return (int) floor(max(0, $total) / $rate['cost']);
}

/** Pagina «Il mio account» (accesso e registrazione di WooCommerce). */
function littleinka_account_url()
{
    return function_exists('wc_get_page_permalink') ? (string) wc_get_page_permalink('myaccount') : '';
}

/** «Ogni CHF 10 spesi ricevi CHF 1 di sconto»: la regola dei punti in parole, dai valori del plugin. */
function littleinka_points_rule_text()
{
    $rate = littleinka_points_rate();
    /* translators: 1: spesa per un punto (es. CHF 10.00), 2: valore di un punto (es. CHF 1.00) */
    return sprintf(__('ogni %1$s spesi ricevi %2$s di sconto sul prossimo ordine', 'littleinka-child-theme'), littleinka_points_money($rate['cost']), littleinka_points_money($rate['value']));
}

/* -------------------------------------------------------------------------
 * 1. Cassa: chi ordina come ospite vede quanti punti guadagnerebbe iscrivendosi
 * ---------------------------------------------------------------------- */

add_action('woocommerce_before_checkout_form', function () {
    if (is_user_logged_in() || !littleinka_points_active()) {
        return;
    }
    $points = littleinka_points_for_cart();
    $rate = littleinka_points_rate();
    $can_signup = 'yes' === get_option('woocommerce_enable_signup_and_login_from_checkout');
    ?>
    <aside class="li-points-invite li-points-invite--checkout" aria-label="<?php esc_attr_e('Punti fedeltà', 'littleinka-child-theme'); ?>">
        <span class="li-points-invite__badge" aria-hidden="true"><?php echo esc_html($points > 0 ? '+' . number_format_i18n($points) : '%'); ?></span>
        <div class="li-points-invite__text">
            <p class="li-points-invite__title">
                <?php
                if ($points > 0) {
                    /* translators: 1: numero di punti, 2: nome dei punti, 3: valore in valuta */
                    echo esc_html(sprintf(__('Con questo ordine guadagneresti %1$s %2$s, cioè %3$s di sconto sul prossimo.', 'littleinka-child-theme'), number_format_i18n($points), littleinka_points_label($points), littleinka_points_money($points * $rate['value'])));
                } else {
                    /* translators: %s: la regola dei punti */
                    echo esc_html(sprintf(__('Con un account, %s.', 'littleinka-child-theme'), littleinka_points_rule_text()));
                }
                ?>
            </p>
            <p class="li-points-invite__desc">
                <?php
                echo esc_html($can_signup
                    ? __('I punti vanno solo a chi ha un account: spunta «Crea un account» sotto i tuoi dati e scegli una password. Valgono in tutte le sedi e nell\'app.', 'littleinka-child-theme')
                    : __('I punti vanno solo a chi ha un account. Valgono in tutte le sedi e nell\'app.', 'littleinka-child-theme'));
                ?>
            </p>
        </div>
    </aside>
    <?php
});

/* -------------------------------------------------------------------------
 * 2. Carrello: i punti dell'ordine sopra «Procedi al pagamento»
 * ---------------------------------------------------------------------- */

add_action('woocommerce_proceed_to_checkout', function () {
    if (!littleinka_points_active()) {
        return;
    }
    $points = littleinka_points_for_cart();
    if ($points < 1) {
        return;
    }
    $line = sprintf(
        /* translators: 1: numero di punti, 2: nome dei punti */
        __('+%1$s %2$s con questo ordine', 'littleinka-child-theme'),
        number_format_i18n($points),
        littleinka_points_label($points)
    );
    echo '<p class="li-points-cart"><strong>' . esc_html($line) . '</strong>';
    if (!is_user_logged_in()) {
        echo ' <a href="' . esc_url(littleinka_account_url()) . '">' . esc_html__('Iscriviti per riceverli', 'littleinka-child-theme') . '</a>';
    }
    echo '</p>';
}, 5);

/** Testo breve per il pulsante «Vai al carrello»: «+3 Health Dots» (vuoto senza punti). */
function littleinka_points_cartbar_text()
{
    $points = littleinka_points_for_cart();
    return $points > 0 ? '+' . number_format_i18n($points) . ' ' . littleinka_points_label($points) : '';
}

/* -------------------------------------------------------------------------
 * 3. Intestazione: «Accedi» o il saldo
 * ---------------------------------------------------------------------- */

function littleinka_account_link()
{
    if (!littleinka_points_active() || littleinka_account_url() === '') {
        return '';
    }
    if (is_user_logged_in()) {
        $balance = (int) PA_get_user_points(get_current_user_id());
        $label = number_format_i18n($balance) . ' ' . littleinka_points_label($balance);
        /* translators: %s: saldo punti, es. «12 Health Dots» */
        $aria = sprintf(__('Il mio account, saldo %s', 'littleinka-child-theme'), $label);
    } else {
        $label = __('Accedi', 'littleinka-child-theme');
        $aria = __('Accedi o crea un account', 'littleinka-child-theme');
    }
    return '<a class="li-account' . (is_user_logged_in() ? ' is-member' : '') . '" href="' . esc_url(littleinka_account_url()) . '" aria-label="' . esc_attr($aria) . '">'
        . littleinka_icon('user', 20)
        . '<span class="li-account__label">' . esc_html($label) . '</span></a>';
}

/* -------------------------------------------------------------------------
 * 4. Invito sotto il banner del menu e nel modulo di registrazione
 * ---------------------------------------------------------------------- */

function littleinka_points_invite()
{
    if (is_user_logged_in() || !littleinka_points_active() || littleinka_account_url() === '') {
        return '';
    }
    $labels = function_exists('PA_get_point_labels') ? PA_get_point_labels() : array('plural' => __('punti', 'littleinka-child-theme'));
    return '<p class="li-points-strip">'
        . '<span class="li-points-strip__text"><strong>' . esc_html(sprintf(
            /* translators: %s: nome dei punti al plurale */
            __('Raccogli %s', 'littleinka-child-theme'),
            $labels['plural']
        )) . '</strong> ' . esc_html(sprintf(
            /* translators: %s: la regola dei punti */
            __('Con un account, %s, in tutte le sedi e nell\'app.', 'littleinka-child-theme'),
            littleinka_points_rule_text()
        )) . '</span>'
        . '<a class="li-points-strip__link" href="' . esc_url(littleinka_account_url()) . '">' . esc_html__('Iscriviti', 'littleinka-child-theme') . littleinka_icon('arrow', 14) . '</a>'
        . '</p>';
}

add_action('woocommerce_register_form_start', function () {
    if (!littleinka_points_active()) {
        return;
    }
    /* translators: %s: la regola dei punti */
    echo '<p class="li-points-register">' . esc_html(sprintf(__('Con un account, %s. I punti valgono in tutte le sedi e nell\'app.', 'littleinka-child-theme'), littleinka_points_rule_text())) . '</p>';
});
