<?php
/**
 * Il menu online di Little Inka: dati delle categorie e dei prodotti (una sola query, in transient),
 * schede per la home, righe per la pagina Menu, pulsante «Aggiungi al carrello» e shortcode [littleinka_menu].
 * I prodotti, le categorie e i prezzi sono quelli di WooCommerce: qui non c'è nessun testo di prodotto.
 */
defined('ABSPATH') || exit;

/* -------------------------------------------------------------------------
 * Dati
 * ---------------------------------------------------------------------- */

/**
 * Tutte le categorie prodotto, indicizzate per ID (una query per richiesta): serve per risalire
 * dalle sottocategorie («base-salmone») alla categoria madre («uramaki-8pz») e per l'ordine.
 *
 * @return WP_Term[] term_id => WP_Term
 */
function littleinka_menu_terms()
{
    static $terms = null;
    if ($terms !== null) {
        return $terms;
    }
    $terms = array();
    if (!taxonomy_exists('product_cat')) {
        return $terms;
    }
    $found = get_terms(array('taxonomy' => 'product_cat', 'hide_empty' => false));
    if (is_wp_error($found)) {
        return $terms;
    }
    foreach ($found as $term) {
        $terms[(int) $term->term_id] = $term;
    }
    return $terms;
}

/** La categoria madre (senza parent) di una categoria: lei stessa se è già di primo livello. */
function littleinka_menu_root_term($term_id)
{
    $terms = littleinka_menu_terms();
    $id = (int) $term_id;
    $guard = 0;
    while (isset($terms[$id]) && (int) $terms[$id]->parent > 0 && isset($terms[(int) $terms[$id]->parent]) && $guard++ < 20) {
        $id = (int) $terms[$id]->parent;
    }
    return isset($terms[$id]) ? $terms[$id] : null;
}

/** Gli slug delle categorie madri di un prodotto (es. ['uramaki-8pz']). */
function littleinka_menu_product_root_slugs($product)
{
    $slugs = array();
    $terms = get_the_terms($product->get_id(), 'product_cat');
    if (!$terms || is_wp_error($terms)) {
        return $slugs;
    }
    foreach ($terms as $term) {
        $root = littleinka_menu_root_term($term->term_id);
        if ($root) {
            $slugs[$root->slug] = $root->slug;
        }
    }
    return array_values($slugs);
}

/** L'ordine di una categoria come lo salva WooCommerce (Prodotti → Categorie, trascinamento). */
function littleinka_menu_term_order($term_id)
{
    // Il cliente numera le categorie nel nome («01. Sushi: Antipasti», «13. Poke Bowl»): quel numero è l'ordine
    // del menu. Senza numero vale l'ordinamento di WooCommerce (term meta «order»), dopo le categorie numerate.
    // A parità di numero («01. Sushi: Antipasti» e «01. Poke Bowl») decide l'ordinamento di WooCommerce.
    $order = get_term_meta($term_id, 'order', true);
    if ($order === '') {
        $order = get_term_meta($term_id, 'order_product_cat', true);
    }
    $tie  = min(9999, max(0, (int) $order)) / 10000;
    $term = get_term($term_id, 'product_cat');
    if ($term instanceof WP_Term && preg_match('/^\s*(\d+)\s*[.)]/', $term->name, $m)) {
        return (int) $m[1] + $tie;
    }
    return 1000 + (int) $order;
}

/**
 * Il nome di una categoria come si mostra: senza il numero d'ordine («01. ») e senza il prefisso «Sushi: »
 * che il cliente usa per ordinare le categorie nella bacheca. «01. Sushi: Antipasti» → «Antipasti».
 */
function littleinka_menu_term_label($term)
{
    $name = $term instanceof WP_Term ? $term->name : (string) $term;
    $name = preg_replace('/^\s*\d+\s*[.)]\s*/u', '', $name);
    $name = preg_replace('/^(sushi|pok[eéè])\s*:\s*/iu', '', $name);
    $name = trim($name);
    if ($name !== '' && mb_strtoupper($name, 'UTF-8') === $name) {
        // Nomi tutti maiuscoli («CREA LA TUA POKE») → solo l'iniziale maiuscola.
        $name = mb_convert_case(mb_strtolower($name, 'UTF-8'), MB_CASE_TITLE, 'UTF-8');
        $name = preg_replace_callback('/\b(La|Il|Lo|Le|Gli|Di|Da|E|Tua|Tuo|Per|Con)\b/u', function ($m) { return mb_strtolower($m[1], 'UTF-8'); }, $name);
        $name = mb_strtoupper(mb_substr($name, 0, 1, 'UTF-8'), 'UTF-8') . mb_substr($name, 1, null, 'UTF-8');
    }
    return littleinka_t($name, 'categoria:' . ($term instanceof WP_Term ? $term->slug : sanitize_title($name)));
}

/**
 * Il menu della sede: le categorie di primo livello con i loro prodotti pubblicati e visibili nel catalogo.
 * Una sola wc_get_products; i prodotti delle sottocategorie stanno sotto la categoria madre; le categorie
 * senza prodotti non compaiono; ordine delle categorie per menu_order poi nome, dei prodotti per menu_order
 * poi titolo. Risultato in transient «littleinka_menu_data» per 12 ore (solo ID: gli oggetti si ricostruiscono),
 * svuotato da littleinka_flush_caches(). Vuoto senza WooCommerce.
 *
 * @return array[] [ ['term' => WP_Term, 'products' => WC_Product[]], … ]
 */
function littleinka_menu_data()
{
    static $menu = null;
    if ($menu !== null) {
        return $menu;
    }
    $menu = array();
    if (!function_exists('wc_get_products') || !littleinka_menu_terms()) {
        return $menu;
    }

    $cached = get_transient('littleinka_menu_data');
    if (is_array($cached) && isset($cached['v'], $cached['cats']) && $cached['v'] === 3) {
        $menu = littleinka_menu_rebuild($cached['cats']);
        return $menu;
    }

    $products = wc_get_products(array(
        'status'     => 'publish',
        'visibility' => 'catalog',
        'limit'      => -1,
        'orderby'    => 'menu_order title',
        'order'      => 'ASC',
        'return'     => 'objects',
    ));
    if (!$products) {
        set_transient('littleinka_menu_data', array('v' => 3, 'cats' => array()), 12 * HOUR_IN_SECONDS);
        return $menu;
    }
    littleinka_menu_prime_terms($products);

    $exclude_slugs = (array) apply_filters('littleinka_menu_exclude_categories', array());
    $has_wpml      = has_filter('wpml_current_language');
    $current_lang  = $has_wpml ? apply_filters('wpml_current_language', null) : null;

    $groups = array(); // term_id => WC_Product[]
    $subgroups = array(); // root term_id => sottocategoria term_id => WC_Product[]
    foreach ($products as $product) {
        if (!$product instanceof WC_Product) {
            continue;
        }
        if ($current_lang) {
            // Resti di WPML: un prodotto in un'altra lingua non va nel menu.
            $lang = apply_filters('wpml_element_language_code', null, array('element_id' => $product->get_id(), 'element_type' => 'post_product'));
            if ($lang && $lang !== $current_lang) {
                continue;
            }
        }
        $terms = get_the_terms($product->get_id(), 'product_cat');
        if (!$terms || is_wp_error($terms)) {
            continue;
        }
        $roots = array();
        $subs_of = array(); // root term_id => [sottocategoria di primo livello, …] di questo prodotto
        foreach ($terms as $term) {
            $root = littleinka_menu_root_term($term->term_id);
            if ($root && !littleinka_is_uncategorized_term($root) && !in_array($root->slug, $exclude_slugs, true)) {
                $roots[(int) $root->term_id] = $root;
                // La sottocategoria di primo livello sotto la madre (es. «Base gambero» sotto «Uramaki»): il menu le mostra divise.
                $first = $term;
                while ($first && (int) $first->parent !== 0 && (int) $first->parent !== (int) $root->term_id) {
                    $first = get_term((int) $first->parent, 'product_cat');
                    if (!($first instanceof WP_Term)) {
                        $first = null;
                    }
                }
                if ($first && (int) $first->parent === (int) $root->term_id) {
                    $subs_of[(int) $root->term_id][(int) $first->term_id] = true;
                }
            }
        }
        foreach ($roots as $root_id => $root) {
            if ($current_lang) {
                $lang = apply_filters('wpml_element_language_code', null, array('element_id' => $root->term_taxonomy_id, 'element_type' => 'tax_product_cat'));
                if ($lang && $lang !== $current_lang) {
                    continue;
                }
            }
            $groups[$root_id][$product->get_id()] = $product;
            foreach (array_keys($subs_of[$root_id] ?? array()) as $sub_id) {
                $subgroups[$root_id][$sub_id][$product->get_id()] = $product;
            }
        }
    }

    $all_terms = littleinka_menu_terms();
    $ordered = array();
    foreach ($groups as $term_id => $items) {
        $term = $all_terms[$term_id];
        usort($items, function ($a, $b) {
            $cmp = $a->get_menu_order() <=> $b->get_menu_order();
            return $cmp !== 0 ? $cmp : strnatcasecmp($a->get_name(), $b->get_name());
        });
        $subs = array();
        foreach (($subgroups[$term_id] ?? array()) as $sub_id => $sub_items) {
            if (!isset($all_terms[$sub_id])) {
                continue;
            }
            usort($sub_items, function ($a, $b) {
                $cmp = $a->get_menu_order() <=> $b->get_menu_order();
                return $cmp !== 0 ? $cmp : strnatcasecmp($a->get_name(), $b->get_name());
            });
            $subs[] = array('term' => $all_terms[$sub_id], 'products' => array_values($sub_items), '_order' => littleinka_menu_term_order($sub_id));
        }
        usort($subs, function ($a, $b) {
            $cmp = $a['_order'] <=> $b['_order'];
            return $cmp !== 0 ? $cmp : strnatcasecmp($a['term']->name, $b['term']->name);
        });
        foreach ($subs as &$sub_row) {
            unset($sub_row['_order']);
        }
        unset($sub_row);
        $ordered[] = array('term' => $term, 'products' => array_values($items), 'subs' => $subs, '_order' => littleinka_menu_term_order($term_id));
    }
    usort($ordered, function ($a, $b) {
        $cmp = $a['_order'] <=> $b['_order'];
        return $cmp !== 0 ? $cmp : strnatcasecmp($a['term']->name, $b['term']->name);
    });

    $cache = array();
    foreach ($ordered as &$cat) {
        unset($cat['_order']);
        $cache[] = array(
            'term'     => (int) $cat['term']->term_id,
            'products' => array_map(function ($p) {
                return $p->get_id();
            }, $cat['products']),
            'subs'     => array_map(function ($s) {
                return array('term' => (int) $s['term']->term_id, 'products' => array_map(function ($p) {
                    return $p->get_id();
                }, $s['products']));
            }, $cat['subs']),
        );
    }
    unset($cat);
    set_transient('littleinka_menu_data', array('v' => 3, 'cats' => $cache), 12 * HOUR_IN_SECONDS);

    $menu = $ordered;
    return $menu;
}

/** Ricostruisce il menu dagli ID salvati nel transient, con una sola wc_get_products. */
function littleinka_menu_rebuild(array $cats)
{
    $ids = array();
    foreach ($cats as $cat) {
        foreach ((array) ($cat['products'] ?? array()) as $id) {
            $ids[(int) $id] = (int) $id;
        }
    }
    if (!$ids) {
        return array();
    }
    $found = wc_get_products(array(
        'include' => array_values($ids),
        'limit'   => -1,
        'status'  => 'publish',
        'orderby' => 'none',
        'return'  => 'objects',
    ));
    littleinka_menu_prime_terms($found);
    $by_id = array();
    foreach ($found as $product) {
        if ($product instanceof WC_Product) {
            $by_id[$product->get_id()] = $product;
        }
    }
    $terms = littleinka_menu_terms();
    $menu = array();
    foreach ($cats as $cat) {
        $term_id = (int) ($cat['term'] ?? 0);
        if (!isset($terms[$term_id])) {
            continue;
        }
        $products = array();
        foreach ((array) ($cat['products'] ?? array()) as $id) {
            if (isset($by_id[(int) $id])) {
                $products[] = $by_id[(int) $id];
            }
        }
        $subs = array();
        foreach ((array) ($cat['subs'] ?? array()) as $sub) {
            $sub_id = (int) ($sub['term'] ?? 0);
            if (!isset($terms[$sub_id])) {
                continue;
            }
            $sub_products = array();
            foreach ((array) ($sub['products'] ?? array()) as $id) {
                if (isset($by_id[(int) $id])) {
                    $sub_products[] = $by_id[(int) $id];
                }
            }
            if ($sub_products) {
                $subs[] = array('term' => $terms[$sub_id], 'products' => $sub_products);
            }
        }
        if ($products) {
            $menu[] = array('term' => $terms[$term_id], 'products' => $products, 'subs' => $subs);
        }
    }
    return $menu;
}

/** Carica in una volta categorie, tag e visibilità di tutti i prodotti (così get_the_terms non fa una query a prodotto). */
function littleinka_menu_prime_terms(array $products)
{
    $ids = array();
    foreach ($products as $product) {
        if ($product instanceof WC_Product) {
            $ids[] = $product->get_id();
        }
    }
    if ($ids) {
        update_object_term_cache($ids, 'product');
    }
}

/**
 * I piatti da mostrare in evidenza (home): i prodotti «in evidenza» con foto; se sono meno di $n, i primi
 * prodotti con foto fuori dalle categorie poké/bibite (littleinka_poke_side_slugs()), o dentro «poke-bowl»
 * per le sedi solo poké.
 *
 * @return WC_Product[]
 */
function littleinka_featured_dishes($n = 4)
{
    $n = max(0, (int) $n);
    $picked = array();
    $side = littleinka_poke_side_slugs();
    $poke_only = littleinka_offer() === 'poke';
    // Senza prodotti «in evidenza» si prende un piatto con foto da ogni categoria, in quest'ordine: le categorie
    // che fanno venire fame per prime (poké, uramaki, sashimi…), mai accessori, bibite o dessert.
    $preference = apply_filters('littleinka_featured_preference', array('poke-bowl', 'uramaki-8pz', 'sashimi-6pz', 'piatti-caldi', 'sushi-set', 'nigiri-2-pz', 'tartare', 'hot-rolls-6-pz', 'hand-roll', 'hosomaki-6-pz', 'tatakis-6-pz', 'gyoza-3pz', 'antipasti'));
    $skip = array_diff($side, array('poke-bowl'));
    $by_cat = array();
    foreach (littleinka_menu_data() as $cat) {
        $slug = $cat['term']->slug;
        foreach ($cat['products'] as $product) {
            if (!$product->get_image_id()) {
                continue;
            }
            if ($product->is_featured()) {
                $picked[$product->get_id()] = $product;
            } elseif (!in_array($slug, $skip, true) && (!$poke_only || $slug === 'poke-bowl')) {
                $by_cat[$slug][] = $product;
            }
        }
    }
    $order = array_merge(array_intersect($preference, array_keys($by_cat)), array_diff(array_keys($by_cat), $preference));
    // Un giro per categoria finché bastano: prima il primo piatto di ogni categoria, poi il secondo…
    for ($round = 0; count($picked) < $n && $round < 10; $round++) {
        $added = false;
        foreach ($order as $slug) {
            if (count($picked) >= $n) {
                break;
            }
            if (isset($by_cat[$slug][$round]) && !isset($picked[$by_cat[$slug][$round]->get_id()])) {
                $picked[$by_cat[$slug][$round]->get_id()] = $by_cat[$slug][$round];
                $added = true;
            }
        }
        if (!$added) {
            break;
        }
    }
    return array_slice(array_values($picked), 0, $n);
}

/* -------------------------------------------------------------------------
 * Add-on (WooCommerce Product Add-ons)
 * ---------------------------------------------------------------------- */

/**
 * I gruppi globali di Product Add-ons attivi: ['all' => bool (almeno un gruppo per tutti i prodotti),
 * 'terms' => [term_id, …] (categorie con un gruppo)]. Due query per richiesta, invece di due a prodotto.
 */
function littleinka_menu_global_addons()
{
    static $info = null;
    if ($info !== null) {
        return $info;
    }
    $info = array('all' => false, 'terms' => array());
    if (!post_type_exists('global_product_addon')) {
        return $info;
    }
    $groups = get_posts(array(
        'post_type'        => 'global_product_addon',
        'post_status'      => 'publish',
        'posts_per_page'   => -1,
        'fields'           => 'ids',
        'no_found_rows'    => true,
        'suppress_filters' => true,
    ));
    if (!$groups) {
        return $info;
    }
    foreach ($groups as $group_id) {
        if (get_post_meta($group_id, '_all_products', true) === '1') {
            $info['all'] = true;
        }
    }
    $terms = wp_get_object_terms($groups, 'product_cat', array('fields' => 'ids'));
    if (!is_wp_error($terms)) {
        $info['terms'] = array_map('intval', $terms);
    }
    return $info;
}

/**
 * Il prodotto ha degli add-on (propri o da un gruppo globale di Product Add-ons)? Con gli add-on non si può
 * aggiungere al carrello dalla lista: si passa dalla scheda prodotto. Senza il plugin: no.
 */
function littleinka_product_has_addons($product)
{
    static $cache = array();
    $id = $product->get_id();
    if (isset($cache[$id])) {
        return $cache[$id];
    }
    if (!class_exists('WC_Product_Addons_Helper')) {
        return $cache[$id] = false;
    }
    $own = array_filter((array) $product->get_meta('_product_addons'));
    if ($own) {
        return $cache[$id] = true;
    }
    if ($product->get_meta('_product_addons_exclude_global') === '1') {
        return $cache[$id] = false;
    }
    $global = littleinka_menu_global_addons();
    if ($global['all']) {
        return $cache[$id] = true;
    }
    if ($global['terms']) {
        // Il plugin assegna i gruppi alla categoria esatta del prodotto (senza figli): si confronta la stessa cosa.
        $terms = get_the_terms($id, 'product_cat');
        if ($terms && !is_wp_error($terms)) {
            foreach ($terms as $term) {
                if (in_array((int) $term->term_id, $global['terms'], true)) {
                    return $cache[$id] = true;
                }
            }
        }
    }
    return $cache[$id] = false;
}

/* -------------------------------------------------------------------------
 * Pulsante, scheda, riga
 * ---------------------------------------------------------------------- */

/**
 * Icona della pioggia «aggiunto al carrello» per un prodotto: quella della sua categoria (assets/icons).
 * La registra, così in fondo alla pagina si stampa una sola copia di ogni icona usata (littleinka_rain_templates).
 * Restituisce l'attributo data-li-icon, vuoto se la categoria non ha un'icona del tema.
 */
function littleinka_rain_icon_attr(WC_Product $product)
{
    static $by_product = array();
    $id = $product->get_id();
    if (!array_key_exists($id, $by_product)) {
        $slug = '';
        $terms = get_the_terms($id, 'product_cat');
        foreach (is_array($terms) ? $terms : array() as $term) {
            $root = littleinka_menu_root_term($term->term_id);
            $slug = $root ? littleinka_category_icon_slug($root) : '';
            if ($slug !== '') {
                break;
            }
        }
        $by_product[$id] = $slug;
        if ($slug !== '') {
            $GLOBALS['littleinka_rain_icons'][$slug] = true;
        }
    }
    return $by_product[$id] !== '' ? ' data-li-icon="' . esc_attr($by_product[$id]) . '"' : '';
}

/** In fondo alla pagina: le icone usate dai pulsanti «Aggiungi», una volta sola, per la pioggia di menu.js. */
add_action('wp_footer', function () {
    if (empty($GLOBALS['littleinka_rain_icons'])) {
        return;
    }
    echo '<div id="li-rain-icons" hidden>';
    foreach (array_keys($GLOBALS['littleinka_rain_icons']) as $slug) {
        echo '<template data-icon="' . esc_attr($slug) . '">' . littleinka_icona($slug, array('classe' => 'li-rain__svg')) . '</template>'; // phpcs:ignore WordPress.Security.EscapeOutput -- SVG del tema
    }
    echo '</div>';
}, 5);

/**
 * Il pulsante di un prodotto nella lista:
 *  - categoria «crea-la-tua-poke» (con la pagina poké): link «Componi» → littleinka_poke_url();
 *  - non acquistabile o esaurito: «Non disponibile»;
 *  - semplice, senza add-on: a.add_to_cart_button.ajax_add_to_cart di WooCommerce (AJAX standard);
 *  - con add-on o variabile: link «Scegli» alla scheda prodotto.
 */
function littleinka_add_to_cart_button(WC_Product $product, $label = '')
{
    $name = wp_strip_all_tags($product->get_name());
    $roots = littleinka_menu_product_root_slugs($product);

    if (in_array('crea-la-tua-poke', $roots, true) && littleinka_poke_url() !== '') {
        return sprintf(
            '<a class="li-btn li-btn--primary li-add li-add--link" href="%s" aria-label="%s">%s</a>',
            esc_url(littleinka_poke_url()),
            /* translators: %s: nome del prodotto (es. Poké M) */
            esc_attr(sprintf(littleinka_t(__('Componi %s', 'littleinka-child-theme'), 'menu:componi_aria'), $name)),
            esc_html($label !== '' ? $label : littleinka_t(__('Componi', 'littleinka-child-theme'), 'menu:componi'))
        );
    }

    if (!$product->is_purchasable() || !$product->is_in_stock()) {
        return '<span class="li-unavailable">' . esc_html__('Non disponibile', 'littleinka-child-theme') . '</span>';
    }

    $direct = $product->is_type('simple') && !littleinka_product_has_addons($product);
    if (!$direct) {
        // Extra o varianti: popup con il modulo della scheda (inc/quick-add.php); il link resta per chi non ha JavaScript.
        return sprintf(
            '<a class="li-btn li-btn--primary li-add li-add--link" href="%s"%s aria-label="%s">%s</a>',
            esc_url($product->get_permalink()),
            (littleinka_quick_add_needed($product) ? ' data-li-options="' . (int) $product->get_id() . '" aria-haspopup="dialog" data-product_name="' . esc_attr($name) . '"' : '') . littleinka_rain_icon_attr($product),
            /* translators: %s: nome del prodotto */
            esc_attr(sprintf(littleinka_t(__('Scegli le opzioni di %s', 'littleinka-child-theme'), 'menu:scegli_aria'), $name)),
            esc_html($label !== '' ? $label : littleinka_t(__('Scegli', 'littleinka-child-theme'), 'menu:scegli'))
        );
    }

    $classes = array('li-btn', 'li-btn--primary', 'li-add', 'add_to_cart_button');
    if (get_option('woocommerce_enable_ajax_add_to_cart') === 'yes' && get_option('woocommerce_cart_redirect_after_add') !== 'yes') {
        $classes[] = 'ajax_add_to_cart';
    }
    return sprintf(
        '<a class="%s" href="%s" data-product_id="%d" data-quantity="1" data-product_sku="%s" data-product_name="%s"%s aria-label="%s" rel="nofollow">%s</a>',
        esc_attr(implode(' ', $classes)),
        esc_url($product->add_to_cart_url()),
        $product->get_id(),
        esc_attr($product->get_sku()),
        esc_attr($name),
        littleinka_rain_icon_attr($product),
        /* translators: %s: nome del prodotto */
        esc_attr(sprintf(littleinka_t(__('Aggiungi %s al carrello', 'littleinka-child-theme'), 'menu:aggiungi_aria'), $name)),
        esc_html($label !== '' ? $label : littleinka_t(__('Aggiungi al carrello', 'littleinka-child-theme'), 'menu:aggiungi'))
    );
}

/**
 * La scheda di un piatto per la home: foto 1:1 linkata alla scheda prodotto, nome (h3), prezzo, pulsante.
 * Da mettere in una griglia .li-tiles (2 / 3 / 4 colonne).
 */
function littleinka_product_tile(WC_Product $product)
{
    $url = $product->get_permalink();
    $name = wp_strip_all_tags($product->get_name());
    $image_id = (int) $product->get_image_id();
    $options = littleinka_quick_add_needed($product) ? ' data-li-options="' . (int) $product->get_id() . '" data-product_name="' . esc_attr($name) . '"' : '';

    $media = '';
    if ($image_id) {
        $img = wp_get_attachment_image($image_id, 'woocommerce_thumbnail', false, array(
            'class'    => 'li-tile__img',
            'loading'  => 'lazy',
            'decoding' => 'async',
            'sizes'    => '(max-width: 639px) calc(50vw - 24px), (max-width: 1023px) calc(33vw - 16px), 282px',
            'alt'      => $name,
        ));
        if ($img) {
            $media = '<a class="li-tile__media" href="' . esc_url($url) . '"' . $options . ' tabindex="-1" aria-hidden="true">' . $img . '</a>';
        }
    }

    return '<article class="li-tile li-tile--product">'
        . $media
        . '<div class="li-tile__body">'
        . '<div class="li-tile__head">'
        . '<h3 class="li-tile__name"><a href="' . esc_url($url) . '"' . $options . '>' . esc_html($name) . '</a></h3>'
        . '<span class="li-tile__price">' . wp_kses_post($product->get_price_html()) . '</span>'
        . '</div>'
        . littleinka_add_to_cart_button($product, littleinka_t(__('Aggiungi', 'littleinka-child-theme'), 'menu:aggiungi_breve'))
        . '</div></article>';
}

/** La descrizione di un prodotto per la riga del menu: quella breve, altrimenti la lunga accorciata a 160 caratteri. */
function littleinka_menu_product_excerpt(WC_Product $product, $max = 160)
{
    $text = trim(wp_strip_all_tags(strip_shortcodes((string) $product->get_short_description())));
    if ($text === '') {
        $text = trim(wp_strip_all_tags(strip_shortcodes((string) $product->get_description())));
        $text = preg_replace('/\s+/u', ' ', $text);
        if (mb_strlen($text) > $max) {
            $cut = mb_substr($text, 0, $max);
            $space = mb_strrpos($cut, ' ');
            $text = rtrim(($space !== false && $space > $max * 0.6) ? mb_substr($cut, 0, $space) : $cut, " ,;:.-") . '…';
        }
    }
    return preg_replace('/\s+/u', ' ', $text);
}

/**
 * La riga di un prodotto nella pagina Menu: nome, descrizione, prezzo, pulsante; nota per chi ha il tag
 * prodotto «alcol»; id="p-<id>" per i link dalla home e dalle schede.
 */
function littleinka_product_row(WC_Product $product)
{
    $id = $product->get_id();
    $available = $product->is_purchasable() && $product->is_in_stock();
    $excerpt = littleinka_menu_product_excerpt($product);
    $alcohol = littleinka_is_alcohol($product);

    $image_id = (int) $product->get_image_id();
    $thumb = $image_id ? wp_get_attachment_image($image_id, 'thumbnail', false, array('class' => 'li-row__img', 'loading' => 'lazy', 'decoding' => 'async', 'alt' => '', 'sizes' => '64px')) : '';
    // Prodotto senza foto: il marchio Little Inka (logo del CMS) piccolo e tenue nel riquadro, non un quadrato vuoto.
    $empty = $thumb === '' && littleinka_logo_mark_url() !== '';
    if ($empty) {
        $thumb = '<img class="li-row__mark" src="' . esc_url(littleinka_logo_mark_url()) . '" alt="" width="32" height="32" loading="lazy" decoding="async">';
    }

    $html = '<li class="li-row' . ($available ? '' : ' li-row--off') . ($alcohol ? ' li-row--alcol' : '') . '" id="p-' . (int) $id . '">';
    $html .= '<span class="li-row__thumb' . ($empty ? ' is-empty' : '') . '" aria-hidden="true">' . $thumb . '</span>';
    $html .= '<h3 class="li-row__name">' . esc_html(wp_strip_all_tags($product->get_name())) . '</h3>';
    $html .= '<span class="li-row__price">' . wp_kses_post($product->get_price_html()) . '</span>';
    if ($excerpt !== '') {
        $html .= '<p class="li-row__desc">' . esc_html($excerpt) . '</p>';
    }
    if ($alcohol) {
        $html .= '<p class="li-row__note">' . esc_html__('Solo per chi ha compiuto 18 anni', 'littleinka-child-theme') . '</p>';
    }
    $html .= '<div class="li-row__action">' . littleinka_add_to_cart_button($product, littleinka_t(__('Aggiungi', 'littleinka-child-theme'), 'menu:aggiungi_breve')) . '</div>';
    return $html . '</li>';
}

/* -------------------------------------------------------------------------
 * Icone delle categorie: le stesse dell'app (Gestione App → Icone Categorie sul sito principale)
 * ---------------------------------------------------------------------- */

/** ID del sito principale del marchio, dove l'app tiene le icone (dal link «Tutte le sedi»). */
function littleinka_hub_blog_id()
{
    static $id = null;
    if ($id === null) {
        $id = (int) apply_filters('littleinka_hub_blog_id', littleinka_sede_blog_id(littleinka_portal_url()));
    }
    return $id;
}

/**
 * Le icone delle categorie di questa sede: [ term_id => ['type' => 'emoji'|'svg', 'value' => '🍣'|URL] ].
 * Lette dall'opzione «app_category_icons» del sito principale (per sede e per nome di categoria).
 */
function littleinka_category_icons()
{
    static $icons = null;
    if ($icons !== null) {
        return $icons;
    }
    $icons = array();
    $hub = littleinka_hub_blog_id();
    if (!$hub || $hub === get_current_blog_id()) {
        return $icons;
    }
    $all = get_blog_option($hub, 'app_category_icons', array());
    $mine = is_array($all) && isset($all[get_current_blog_id()]) && is_array($all[get_current_blog_id()]) ? $all[get_current_blog_id()] : array();
    foreach ($mine as $name => $icon) {
        if (!is_array($icon) || empty($icon['value']) || !in_array($icon['type'] ?? '', array('emoji', 'svg'), true)) {
            continue;
        }
        $term_id = (int) ($icon['term_id'] ?? 0);
        if (!$term_id) {
            $term = get_term_by('name', (string) $name, 'product_cat');
            $term_id = $term ? (int) $term->term_id : 0;
        }
        if ($term_id) {
            $icons[$term_id] = array('type' => $icon['type'], 'value' => (string) $icon['value']);
        }
    }
    return $icons;
}

/**
 * L'icona del tema per una categoria (assets/icons), riconosciuta dal nome o dallo slug.
 * Le sedi hanno nomi simili ma non identici («02. Sushi: Hot Roll's / 6pz», «hot-rolls-6-pz»):
 * si cercano parole chiave, in quest'ordine (la prima che corrisponde vince).
 * Filtro «littleinka_category_icon_slug» per forzare o togliere un'icona.
 *
 * @return string Slug dell'icona, '' se nessuna corrisponde.
 */
function littleinka_category_icon_slug(WP_Term $term)
{
    $text = strtolower(remove_accents($term->name . ' ' . str_replace('-', ' ', $term->slug)));
    $rules = array(
        'crea-poke'    => '\bcrea\b',
        'poke-bowl'    => '\bpoke\b',
        'hot-roll'     => '\bhot\s?rolls?\b|\brouleaux chauds\b|\bwarme rollen\b',
        'hand-roll'    => '\bhand\s?rolls?\b|\btemaki\b',
        'uramaki'      => '\buramaki\b',
        'hosomaki'     => '\bhosomaki\b|\bmaki\b',
        'nigiri'       => '\bnigiri\b',
        'gyoza'        => '\bgyoza\b|\bravioli\b',
        'tataki'       => '\btatakis?\b',
        'tartare'      => '\btartare\b',
        'sashimi'      => '\bsashimi\b',
        'antipasti'    => '\bantipast[oi]\b|\bstarters?\b',
        'piatti-caldi' => '\bcaldi\b|\bhot dishes\b|\bplats chauds\b|\bwarme gerichte\b|\bscharfe gerichte\b|\bramen\b|\bzupp[ae]\b|\bwok\b|\byaki\s?(soba|udon?)\b|\btakoyaki\b',
        'sushi-set'    => '\bset\b|\bbento\b|\bcombo\b|\bbarc[ah]\b',
        'dessert'      => '\bdesserts?\b|\bdolci\b|\bmochi\b',
        'bibite'       => '\bbibite\b|\bbevande\b|\bdrinks?\b',
        'accessori'    => '\baccessori\b|\bbacchette\b|\bsalse\b',
    );
    $found = '';
    foreach ($rules as $icon => $re) {
        if (preg_match('/' . $re . '/', $text)) {
            $found = $icon;
            break;
        }
    }
    return (string) apply_filters('littleinka_category_icon_slug', $found, $term);
}

/**
 * L'icona di una categoria: prima la famiglia di icone del tema, poi (per le categorie che il
 * tema non riconosce) quella scelta nell'app; vuota se non c'è nessuna delle due.
 */
function littleinka_category_icon_html(WP_Term $term, $class = 'li-chips__icon')
{
    $slug = littleinka_category_icon_slug($term);
    if ($slug !== '') {
        $svg = littleinka_icona($slug, array('classe' => $class));
        if ($svg !== '') {
            return $svg;
        }
    }
    $icon = littleinka_category_icons()[(int) $term->term_id] ?? null;
    if (!$icon) {
        return '';
    }
    if ($icon['type'] === 'svg') {
        return '<img class="' . esc_attr($class) . '" src="' . esc_url($icon['value']) . '" alt="" width="24" height="24" loading="lazy" decoding="async">';
    }
    return '<span class="' . esc_attr($class) . ' ' . esc_attr($class) . '--emoji" aria-hidden="true">' . esc_html($icon['value']) . '</span>';
}

/* -------------------------------------------------------------------------
 * Chip delle categorie e shortcode
 * ---------------------------------------------------------------------- */

/**
 * I link alle categorie del menu: <nav class="li-chips"> con un link per categoria a #cat-<slug>.
 * $base_url vuoto = ancore nella stessa pagina; dalla home si passa littleinka_menu_url().
 * $categories = sottoinsieme di littleinka_menu_data() (lo shortcode con «categorie»/«escludi»); null = tutte.
 */
function littleinka_menu_chips($base_url = '', $categories = null, $class = '', $with_subs = false)
{
    $categories = is_array($categories) ? $categories : littleinka_menu_data();
    if (!$categories) {
        return '';
    }
    $html = '<nav class="li-chips' . ($class !== '' ? ' ' . esc_attr($class) : '') . '" aria-label="' . esc_attr(littleinka_t(__('Categorie', 'littleinka-child-theme'), 'menu:categorie')) . '"><ul class="li-chips__list">';
    foreach ($categories as $cat) {
        $term = $cat['term'];
        $href = ($base_url !== '' ? $base_url : '') . '#cat-' . $term->slug;
        $html .= '<li class="li-chips__item"><a class="li-chips__link" href="' . esc_url($href) . '" data-cat="' . esc_attr($term->slug) . '">' . littleinka_category_icon_html($term) . '<span class="li-chips__label">' . esc_html(littleinka_menu_term_label($term)) . '</span></a>';
        if ($with_subs && !empty($cat['subs'])) {
            // Sottocategorie (es. le «Base» degli uramaki): solo nella colonna laterale, rientrate sotto la madre.
            $html .= '<ul class="li-chips__sub">';
            foreach ($cat['subs'] as $sub) {
                $html .= '<li class="li-chips__item li-chips__item--sub"><a class="li-chips__link li-chips__link--sub" href="' . esc_url(($base_url !== '' ? $base_url : '') . '#cat-' . $sub['term']->slug) . '" data-sub="' . esc_attr($sub['term']->slug) . '">' . esc_html(littleinka_menu_term_label($sub['term'])) . '</a></li>';
            }
            $html .= '</ul>';
        }
        $html .= '</li>';
    }
    return $html . '</ul></nav>';
}

/** Le categorie del menu filtrate dagli attributi dello shortcode (slug separati da virgola). */
function littleinka_menu_filter_categories($include = '', $exclude = '')
{
    $include = array_filter(array_map('sanitize_title', array_map('trim', explode(',', (string) $include))));
    $exclude = array_filter(array_map('sanitize_title', array_map('trim', explode(',', (string) $exclude))));
    $cats = array();
    foreach (littleinka_menu_data() as $cat) {
        $slug = $cat['term']->slug;
        if ($include && !in_array($slug, $include, true)) {
            continue;
        }
        if ($exclude && in_array($slug, $exclude, true)) {
            continue;
        }
        $cats[] = $cat;
    }
    return $cats;
}

/** I testi per menu.js (window.littleInkaMenu). */
function littleinka_menu_js_data()
{
    return array(
        'arrows'    => array(
            'prev' => littleinka_t(__('Categorie precedenti', 'littleinka-child-theme'), 'menu:freccia_prec'),
            'next' => littleinka_t(__('Altre categorie', 'littleinka-child-theme'), 'menu:freccia_succ'),
        ),
        'cartUrl'   => function_exists('ticinoweb_frontend_url') ? ticinoweb_frontend_url(littleinka_cart_url(), 'littleinka:url:cart') : littleinka_cart_url(),
        /* translators: %s: nome del prodotto */
        'added'     => littleinka_t(__('%s è nel carrello', 'littleinka-child-theme'), 'menu:js_aggiunto'),
        'viewCart'  => littleinka_t(__('Vai al carrello', 'littleinka-child-theme'), 'menu:js_vai_carrello'),
        'close'     => littleinka_t(__('Chiudi', 'littleinka-child-theme'), 'menu:js_chiudi'),
        'countOne'  => littleinka_t(__('1 piatto trovato', 'littleinka-child-theme'), 'menu:js_uno'),
        /* translators: %d: numero di piatti */
        'countMany' => littleinka_t(__('%d piatti trovati', 'littleinka-child-theme'), 'menu:js_molti'),
        /* translators: %s: testo cercato */
        'noResults' => littleinka_t(__('Nessun piatto corrisponde a «%s»', 'littleinka-child-theme'), 'menu:js_nessuno'),
    );
}

/** Accoda menu.css, menu.js e gli script di WooCommerce per l'aggiunta al carrello in AJAX. */
function littleinka_menu_enqueue_assets()
{
    littleinka_enqueue_module_css('menu');
    if (!function_exists('WC')) {
        return;
    }
    if (wp_script_is('wc-add-to-cart', 'registered')) {
        wp_enqueue_script('wc-add-to-cart');
    }
    if (wp_script_is('wc-cart-fragments', 'registered')) {
        wp_enqueue_script('wc-cart-fragments');
    }
    littleinka_enqueue_module_js('menu', array('jquery', 'wc-add-to-cart'), littleinka_menu_js_data());
    littleinka_quick_add_assets();
    littleinka_enqueue_module_js('quickadd', array('jquery'), array(
        'form'    => WC_AJAX::get_endpoint('li_product_form'),
        'add'     => WC_AJAX::get_endpoint('li_add_with_options'),
        'close'   => littleinka_t(__('Chiudi', 'littleinka-child-theme'), 'menu:js_chiudi'),
        'addText' => littleinka_t(__('Aggiungi al carrello', 'littleinka-child-theme'), 'menu:aggiungi'),
        'error'   => littleinka_t(__('Non è stato possibile aggiungerlo. Riprova.', 'littleinka-child-theme'), 'menu:js_errore'),
        'loading' => littleinka_t(__('Caricamento…', 'littleinka-child-theme'), 'menu:js_caricamento'),
    ));
}

/** Gli asset del menu vanno nell'head sulla home (schede dei piatti) e sulla pagina con [littleinka_menu]. */
add_action('wp_enqueue_scripts', function () {
    if (is_admin()) {
        return;
    }
    $post = is_singular() ? get_post() : null;
    if (is_front_page() || ($post && has_shortcode((string) $post->post_content, 'littleinka_menu'))) {
        littleinka_menu_enqueue_assets();
    }
}, 20);

/**
 * [littleinka_menu categorie="" escludi=""]: ricerca istantanea, chip delle categorie fissi sotto l'header,
 * una sezione per categoria (h2, descrizione, righe in due colonne da 1024 in su).
 */
add_shortcode('littleinka_menu', function ($atts) {
    $atts = shortcode_atts(array('categorie' => '', 'escludi' => ''), $atts, 'littleinka_menu');
    if (!function_exists('wc_get_products')) {
        return '';
    }
    $cats = littleinka_menu_filter_categories($atts['categorie'], $atts['escludi']);
    if (!$cats) {
        return '<p class="li-menu__empty">' . esc_html__('Il menu online non è ancora disponibile.', 'littleinka-child-theme') . '</p>';
    }
    littleinka_menu_enqueue_assets();

    // Ricerca e categorie nella stessa colonna: su computer a sinistra e ferme, sul telefono una sopra l'altra.
    $html = '<div class="li-menu" id="li-menu">';
    $html .= '<div class="li-menu__layout">';
    $html .= '<div class="li-menu__side">';
    $html .= '<div class="li-menu__head">';
    $html .= '<div class="li-menu__search" role="search">';
    $html .= '<label class="screen-reader-text" for="li-menu-search">' . esc_html__('Cerca nel menu', 'littleinka-child-theme') . '</label>';
    $html .= littleinka_icon('search', 20);
    $html .= '<input class="li-menu__input" id="li-menu-search" type="search" autocomplete="off" spellcheck="false" placeholder="' . esc_attr(littleinka_t(__('Cerca un piatto…', 'littleinka-child-theme'), 'menu:cerca_placeholder')) . '" aria-controls="li-menu-list">';
    $html .= '</div>';
    $html .= '<p class="li-menu__count" id="li-menu-count" role="status" aria-live="polite"></p>';
    $html .= '</div>';
    $html .= littleinka_menu_chips('', $cats, 'li-chips--sticky', true);
    $html .= '</div>';
    $html .= '<div class="li-menu__list" id="li-menu-list">';
    foreach ($cats as $cat) {
        $term = $cat['term'];
        $slug = esc_attr($term->slug);
        $html .= '<section class="li-menu__cat" id="cat-' . $slug . '" aria-labelledby="cat-' . $slug . '-h" data-cat="' . $slug . '">';
        $html .= '<h2 class="li-menu__title" id="cat-' . $slug . '-h">' . littleinka_category_icon_html($term, 'li-menu__icon') . esc_html(littleinka_menu_term_label($term)) . '</h2>';
        if (trim((string) $term->description) !== '') {
            $html .= '<div class="li-menu__desc">' . wp_kses_post(wpautop($term->description)) . '</div>';
        }
        $subs = (array) ($cat['subs'] ?? array());
        if ($subs) {
            // Sottocategorie (es. «Uramaki» diviso per base: gambero, tonno, salmone…): ognuna con il suo titolo.
            $in_sub = array();
            foreach ($subs as $sub) {
                foreach ($sub['products'] as $product) {
                    $in_sub[$product->get_id()] = true;
                }
            }
            $loose = array_filter($cat['products'], function ($p) use ($in_sub) {
                return !isset($in_sub[$p->get_id()]);
            });
            if ($loose) {
                $html .= '<ul class="li-rows">';
                foreach ($loose as $product) {
                    $html .= littleinka_product_row($product);
                }
                $html .= '</ul>';
            }
            foreach ($subs as $sub) {
                $sub_slug = esc_attr($sub['term']->slug);
                $html .= '<div class="li-menu__sub" id="cat-' . $sub_slug . '">';
                $html .= '<h3 class="li-menu__subtitle">' . esc_html(littleinka_menu_term_label($sub['term'])) . '</h3>';
                $html .= '<ul class="li-rows">';
                foreach ($sub['products'] as $product) {
                    $html .= littleinka_product_row($product);
                }
                $html .= '</ul></div>';
            }
            $html .= '</section>';
            continue;
        }
        $html .= '<ul class="li-rows">';
        foreach ($cat['products'] as $product) {
            $html .= littleinka_product_row($product);
        }
        $html .= '</ul></section>';
    }
    $html .= '</div></div>';
    $html .= '<p class="li-menu__none" hidden>' . esc_html__('Nessun piatto trovato. Prova con un\'altra parola.', 'littleinka-child-theme') . '</p>';
    return $html . '</div>';
});
