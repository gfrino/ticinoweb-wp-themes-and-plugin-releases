<?php
/**
 * Negozio (WooCommerce): il numero nel carrello dell'header, il «Negozio» che rimanda al menu,
 * la scheda prodotto pulita (foto, titolo, prezzo, modulo di acquisto con gli add-on), carrello,
 * cassa e account con il foglio shop.css, i testi della cassa in italiano e, con tW Translate,
 * nomi e etichette nella lingua di chi ordina.
 *
 * Carrello e cassa restano gli shortcode classici [woocommerce_cart] / [woocommerce_checkout]: i blocchi
 * leggono dall'API JSON di WooCommerce, che tW Translate non traduce. L'ordine minimo lo impone CodeRockz
 * alla cassa, le spedizioni stanno nelle zone di WooCommerce: qui non si toccano.
 */
defined('ABSPATH') || exit;

if (!class_exists('WooCommerce')) {
    return;
}

/* -------------------------------------------------------------------------
 * Fogli di stile: quelli di WooCommerce solo su carrello, cassa e account; shop.css anche sulla scheda prodotto
 * ---------------------------------------------------------------------- */

add_filter('woocommerce_enqueue_styles', function ($styles) {
    return (is_cart() || is_checkout() || is_account_page()) ? $styles : array();
});

add_action('wp_enqueue_scripts', function () {
    if (is_cart() || is_checkout() || is_account_page() || is_product()) {
        littleinka_enqueue_module_css('shop');
    }
}, 20);

/** Zoom, slider e lightbox della galleria prodotto: tre script in più per una foto sola. La foto resta, senza link al file. */
add_action('after_setup_theme', function () {
    remove_theme_support('wc-product-gallery-zoom');
    remove_theme_support('wc-product-gallery-slider');
    remove_theme_support('wc-product-gallery-lightbox');
}, 30);

add_filter('woocommerce_single_product_image_thumbnail_html', function ($html) {
    return preg_replace('~<a\b[^>]*>(.*?)</a>~s', '$1', (string) $html);
});

/* -------------------------------------------------------------------------
 * Carrello nell'header: dopo un'aggiunta senza ricaricare, WooCommerce sostituisce il numero
 * (stesso markup di littleinka_cart_link() in helpers.php)
 * ---------------------------------------------------------------------- */

add_filter('woocommerce_add_to_cart_fragments', function ($fragments) {
    $fragments['.li-cart__count'] = '<span class="li-cart__count" data-cart-count>' . esc_html(number_format_i18n(littleinka_cart_count())) . '</span>';
    $bar = littleinka_cart_bar();
    if ($bar !== '') {
        $fragments['div.li-cartbar'] = $bar;
    }
    return $fragments;
});

/* -------------------------------------------------------------------------
 * Contenitore delle pagine WooCommerce: niente sidebar, niente breadcrumb, un <main> del tema
 * ---------------------------------------------------------------------- */

remove_action('woocommerce_before_main_content', 'woocommerce_output_content_wrapper', 10);
remove_action('woocommerce_after_main_content', 'woocommerce_output_content_wrapper_end', 10);
remove_action('woocommerce_before_main_content', 'woocommerce_breadcrumb', 20);
remove_action('woocommerce_sidebar', 'woocommerce_get_sidebar', 10);

add_action('woocommerce_before_main_content', function () {
    echo '<main id="li-main" class="li-main li-shop"><div class="li-wrap">';
}, 10);

add_action('woocommerce_after_main_content', function () {
    echo '</div></main>';
}, 10);

/** Il titolo dell'elenco prodotti non serve (il «Negozio» rimanda al menu); sulla scheda prodotto l'h1 resta. */
add_filter('woocommerce_show_page_title', '__return_false');

/* -------------------------------------------------------------------------
 * Il menu è un'unica pagina: «Negozio» e archivi di categoria rimandano lì
 * ---------------------------------------------------------------------- */

add_action('template_redirect', function () {
    if (is_admin() || is_search()) {
        return;
    }
    $target = '';
    if (is_shop()) {
        // Se la pagina Menu fosse proprio la pagina «Negozio» si girerebbe in tondo: in quel caso niente redirect.
        $shop_id = (int) wc_get_page_id('shop');
        if ($shop_id > 0 && $shop_id === littleinka_page_with_shortcode('littleinka_menu')) {
            return;
        }
        $target = littleinka_menu_url();
    } elseif (is_product_category()) {
        $term = get_queried_object();
        // Le sottocategorie (es. le basi degli uramaki) stanno sotto la categoria madre nel menu.
        while ($term instanceof WP_Term && $term->parent) {
            $parent = get_term($term->parent, 'product_cat');
            if (!$parent instanceof WP_Term) {
                break;
            }
            $term = $parent;
        }
        $target = littleinka_menu_url($term instanceof WP_Term ? 'cat-' . $term->slug : '');
    }
    if ($target !== '') {
        wp_safe_redirect($target, 301);
        exit;
    }
});

add_filter('woocommerce_return_to_shop_redirect', function () {
    return littleinka_menu_url();
});
add_filter('woocommerce_return_to_shop_text', function () {
    return __('Torna al menu', 'littleinka-child-theme');
});
// Lo stesso verbo del menu e della poké: «Aggiungi al carrello» (WooCommerce di base dice «Acquista»).
add_filter('woocommerce_product_single_add_to_cart_text', function () {
    return __('Aggiungi al carrello', 'littleinka-child-theme');
});

/* -------------------------------------------------------------------------
 * Scheda prodotto: foto a sinistra; a destra titolo, prezzo, descrizione breve, modulo di acquisto
 * (Product Add-ons si aggancia da solo a woocommerce_before_add_to_cart_button); sotto, a tutta larghezza,
 * descrizione lunga, categoria con link al menu e «Torna al menu». Niente tab, correlati, upsell, voti.
 * ---------------------------------------------------------------------- */

remove_action('woocommerce_single_product_summary', 'woocommerce_template_single_rating', 10);
remove_action('woocommerce_single_product_summary', 'woocommerce_template_single_meta', 40);
remove_action('woocommerce_single_product_summary', 'woocommerce_template_single_sharing', 50);
remove_action('woocommerce_after_single_product_summary', 'woocommerce_output_product_data_tabs', 10);
remove_action('woocommerce_after_single_product_summary', 'woocommerce_upsell_display', 15);
remove_action('woocommerce_after_single_product_summary', 'woocommerce_output_related_products', 20);
remove_action('woocommerce_cart_collaterals', 'woocommerce_cross_sell_display');
add_filter('woocommerce_product_tabs', '__return_empty_array', 99);

/** La classe del tema sul contenitore del prodotto: la griglia a due colonne di shop.css parte da qui. */
add_filter('woocommerce_post_class', function ($classes, $product = null) {
    if (is_product() && $product instanceof WC_Product && is_main_query() && in_the_loop()) {
        $classes[] = 'li-product';
    }
    return $classes;
}, 10, 2);

/** Il prodotto ha il tag «alcol»? (se il tag non esiste, mai). */
function littleinka_product_is_alcohol($product)
{
    return littleinka_is_alcohol($product);
}

/** Nota «Solo per chi ha compiuto 18 anni» sotto la descrizione breve, prima del modulo di acquisto. */
add_action('woocommerce_single_product_summary', function () {
    global $product;
    if (!littleinka_product_is_alcohol($product)) {
        return;
    }
    echo '<p class="li-product__age">' . littleinka_icon('warning', 18) . '<span>' . esc_html__('Solo per chi ha compiuto 18 anni', 'littleinka-child-theme') . '</span></p>'; // phpcs:ignore WordPress.Security.EscapeOutput -- l'icona è SVG del tema
}, 25);

/** Le categorie di primo livello del prodotto, con il link alla loro sezione del menu (#cat-slug). */
function littleinka_product_menu_categories($product)
{
    $terms = $product instanceof WC_Product ? get_the_terms($product->get_id(), 'product_cat') : array();
    $roots = array();
    foreach (is_array($terms) ? $terms : array() as $term) {
        while ($term instanceof WP_Term && $term->parent) {
            $parent = get_term($term->parent, 'product_cat');
            if (!$parent instanceof WP_Term) {
                break;
            }
            $term = $parent;
        }
        if ($term instanceof WP_Term && !littleinka_is_uncategorized_term($term)) {
            $roots[$term->term_id] = $term;
        }
    }
    return array_values($roots);
}

/** Sotto le due colonne: descrizione lunga, categoria, «Torna al menu». */
add_action('woocommerce_after_single_product_summary', function () {
    global $product;
    if (!$product instanceof WC_Product) {
        return;
    }
    $description = (string) $product->get_description();
    $description = trim(wp_strip_all_tags($description)) !== '' ? apply_filters('the_content', $description) : '';
    $categories = littleinka_product_menu_categories($product);
    ?>
    <div class="li-product__more">
        <?php if ($description !== '') : ?>
            <section class="li-product__description">
                <h2 class="li-product__h2"><?php esc_html_e('Descrizione', 'littleinka-child-theme'); ?></h2>
                <?php echo wp_kses_post($description); ?>
            </section>
        <?php endif; ?>
        <div class="li-product__nav">
            <?php if ($categories) : ?>
                <p class="li-product__cats">
                    <span class="li-product__cats-label"><?php echo esc_html(_n('Categoria:', 'Categorie:', count($categories), 'littleinka-child-theme')); ?></span>
                    <?php foreach ($categories as $term) : ?>
                        <a class="li-chip li-product__cat" href="<?php echo esc_url(littleinka_menu_url('cat-' . $term->slug)); ?>"><?php echo esc_html(function_exists('littleinka_menu_term_label') ? littleinka_menu_term_label($term) : $term->name); ?></a>
                    <?php endforeach; ?>
                </p>
            <?php endif; ?>
            <p class="li-product__back">
                <a href="<?php echo esc_url(littleinka_menu_url()); ?>"><?php echo littleinka_icon('arrow', 18); // phpcs:ignore WordPress.Security.EscapeOutput -- SVG del tema ?><span><?php esc_html_e('Torna al menu', 'littleinka-child-theme'); ?></span></a>
            </p>
        </div>
    </div>
    <?php
}, 10);

/* -------------------------------------------------------------------------
 * Cassa: i testi di legge in italiano (il resto è degli shortcode e di shop.css)
 * ---------------------------------------------------------------------- */

add_filter('woocommerce_get_terms_and_conditions_checkbox_text', function () {
    /* translators: [terms] diventa il collegamento «termini e condizioni» di WooCommerce */
    return __('Ho letto e accetto i [terms]', 'littleinka-child-theme');
});

add_filter('woocommerce_get_privacy_policy_text', function ($text, $type = '') {
    if ($type === 'registration') {
        /* translators: [privacy_policy] diventa il collegamento all'informativa */
        return __('I tuoi dati servono per gestire il tuo account e sono trattati come descritto nella nostra [privacy_policy].', 'littleinka-child-theme');
    }
    /* translators: [privacy_policy] diventa il collegamento all'informativa */
    return __('I tuoi dati servono per preparare e consegnare l’ordine e sono trattati come descritto nella nostra [privacy_policy].', 'littleinka-child-theme');
}, 20, 2);

/* -------------------------------------------------------------------------
 * tW Translate: nomi dei prodotti, etichette di spedizione e pagamento, pagina di conferma nella lingua
 * di chi ordina. Solo con il plugin attivo; l'ordine resta registrato in italiano, come lo legge il negozio.
 * ---------------------------------------------------------------------- */

/** La lingua della pagina (vuota senza tW Translate). */
function littleinka_shop_lang()
{
    return function_exists('twtr_get_current_language') ? (string) twtr_get_current_language() : '';
}

/** La lingua predefinita del sito secondo tW Translate (vuota senza il plugin). */
function littleinka_shop_default_lang()
{
    static $default = null;
    if ($default !== null) {
        return $default;
    }
    $default = '';
    $languages = function_exists('twtr_get_languages') ? (array) twtr_get_languages() : array();
    foreach ($languages as $code => $info) {
        if (!empty($info['is_default'])) {
            $default = (string) $code;
            break;
        }
    }
    return $default;
}

/**
 * Il nome di un prodotto nella lingua della pagina. WooCommerce lo prende da get_name(), senza passare
 * dal filtro dei titoli che tW traduce: qui si cerca la traduzione del titolo (solo a video).
 */
function littleinka_shop_translated_name($html, $product_id, $name)
{
    $lang = littleinka_shop_lang();
    if ($name === '' || $lang === '' || $lang === littleinka_shop_default_lang()) {
        return $html;
    }
    $post = get_post((int) $product_id);
    if (!$post) {
        return $html;
    }
    $raw = get_post_field('post_title', $post, 'raw');
    $translated = null;
    if (class_exists('Twtr_Resolver') && is_callable(array('Twtr_Resolver', 'find'))) {
        $translated = Twtr_Resolver::find($raw, 'post:' . (int) $post->ID . ':title', $lang);
    } elseif (function_exists('twtr_translate')) {
        $translated = twtr_translate($raw, 'post:' . (int) $post->ID . ':title');
    }
    $translated = is_string($translated) ? html_entity_decode(wp_strip_all_tags($translated), ENT_QUOTES, 'UTF-8') : '';
    if ($translated === '' || $translated === $name) {
        return $html;
    }
    return str_replace(array(esc_html($name), $name), esc_html($translated), $html);
}

if (function_exists('twtr_get_language_url')) {
    // Nomi dei prodotti nel carrello, alla cassa e nel riepilogo dell'ordine.
    add_filter('woocommerce_cart_item_name', function ($html, $item) {
        $product = isset($item['data']) && $item['data'] instanceof WC_Product ? $item['data'] : null;
        return $product ? littleinka_shop_translated_name($html, $product->get_id(), $product->get_name()) : $html;
    }, 20, 2);
    add_filter('woocommerce_order_item_name', function ($html, $item) {
        return is_callable(array($item, 'get_product_id')) ? littleinka_shop_translated_name($html, $item->get_product_id(), $item->get_name()) : $html;
    }, 20, 2);

    // Etichette di consegna e ritiro (salvate in italiano nelle zone di WooCommerce): a video nella lingua della pagina.
    add_filter('woocommerce_cart_shipping_method_full_label', function ($label, $method) {
        $name = (string) $method->get_label();
        $translated = littleinka_t($name, 'spedizione:' . sanitize_key($method->get_method_id()));
        return ($name === '' || $translated === $name) ? $label : str_replace(esc_html($name), esc_html($translated), $label);
    }, 20, 2);
    add_filter('woocommerce_order_shipping_to_display', function ($html, $order) {
        $name = is_callable(array($order, 'get_shipping_method')) ? (string) $order->get_shipping_method() : '';
        $translated = $name !== '' ? littleinka_t($name, 'spedizione:ordine') : '';
        return ($name === '' || $translated === $name) ? $html : str_replace(esc_html($name), esc_html($translated), $html);
    }, 20, 2);

    // Nomi dei metodi di pagamento (li gestisce il negozio): solo tradotti, mai riscritti.
    add_filter('woocommerce_gateway_title', function ($title, $id = '') {
        return littleinka_t((string) $title, 'pagamento:' . sanitize_key((string) $id));
    }, 20, 2);

    // Dopo il pagamento la conferma resta nella lingua in cui si è ordinato (la richiesta AJAX perde il prefisso).
    add_filter('woocommerce_get_checkout_order_received_url', function ($url) {
        $lang = littleinka_shop_lang();
        return $lang !== '' ? twtr_get_language_url($lang, $url) : $url;
    }, 20);
}

/* -------------------------------------------------------------------------
 * Bacheca: le pagine Carrello e Pagamento devono avere gli shortcode classici
 * ---------------------------------------------------------------------- */

/** La pagina ha lo shortcode classico, scritto a mano o tramite il blocco «Classic Shortcode» di WooCommerce? */
function littleinka_page_has_classic_shortcode($content, $which)
{
    $content = (string) $content;
    if (has_shortcode($content, 'woocommerce_' . $which)) {
        return true;
    }
    if (strpos($content, 'wp:woocommerce/classic-shortcode') === false) {
        return false;
    }
    // Il blocco senza attributo vale «cart»; con "shortcode":"checkout" vale cassa.
    $is_checkout_block = strpos($content, '"shortcode":"checkout"') !== false;
    return $which === 'checkout' ? $is_checkout_block : !$is_checkout_block;
}

add_action('admin_notices', function () {
    if (!current_user_can('manage_woocommerce') || !function_exists('get_current_screen')) {
        return;
    }
    $screen = get_current_screen();
    if (!$screen) {
        return;
    }
    $id = (string) $screen->id;
    $is_woocommerce = $screen->parent_base === 'woocommerce'
        || strpos($id, 'woocommerce') !== false
        || strpos($id, 'wc-') !== false
        || in_array((string) $screen->post_type, array('product', 'shop_order', 'shop_coupon'), true);
    $is_appearance = $screen->parent_base === 'themes' || $screen->base === 'themes';
    if (!$is_woocommerce && !$is_appearance) {
        return;
    }
    $pages = array(
        'cart'     => array('shortcode' => 'woocommerce_cart', 'label' => __('Carrello', 'littleinka-child-theme')),
        'checkout' => array('shortcode' => 'woocommerce_checkout', 'label' => __('Pagamento', 'littleinka-child-theme')),
    );
    $todo = array();
    foreach ($pages as $key => $info) {
        $page_id = (int) wc_get_page_id($key);
        $post = $page_id > 0 ? get_post($page_id) : null;
        if (!$post) {
            $todo[] = sprintf(
                /* translators: 1: nome della pagina (Carrello, Pagamento), 2: shortcode */
                esc_html__('In WooCommerce → Impostazioni → Avanzate scegli la pagina «%1$s» e mettici lo shortcode %2$s.', 'littleinka-child-theme'),
                esc_html($info['label']),
                '<code>[' . esc_html($info['shortcode']) . ']</code>'
            );
            continue;
        }
        if (littleinka_page_has_classic_shortcode($post->post_content, $key)) {
            continue;
        }
        $todo[] = sprintf(
            /* translators: 1: titolo della pagina, 2: shortcode, 3: link «Modifica la pagina» */
            esc_html__('Nella pagina «%1$s» metti lo shortcode %2$s al posto del blocco o del contenuto di Elementor. %3$s', 'littleinka-child-theme'),
            esc_html(get_the_title($post)),
            '<code>[' . esc_html($info['shortcode']) . ']</code>',
            '<a href="' . esc_url(get_edit_post_link($post->ID, 'raw')) . '">' . esc_html__('Modifica la pagina', 'littleinka-child-theme') . '</a>'
        );
    }
    if (!$todo) {
        return;
    }
    echo '<div class="notice notice-warning"><p><strong>' . esc_html__('Tema Little Inka: carrello e cassa funzionano con gli shortcode classici, non con i blocchi.', 'littleinka-child-theme') . '</strong></p><ul style="list-style:disc;margin-left:1.5em">';
    foreach ($todo as $line) {
        echo '<li>' . wp_kses($line, array('code' => array(), 'a' => array('href' => array()))) . '</li>';
    }
    echo '</ul></div>';
});

/* Carrello, cassa e account non si tengono in memoria dal browser (no-store): con «Indietro» / «Avanti» Chrome
   ripresentava una copia vecchia del carrello, con meno piatti di quelli veri. WooCommerce toglie apposta no-store
   agli ospiti (per la cache avanti/indietro) e indica il filtro wp_headers per rimetterlo: qui, dopo WooCommerce. */
add_filter('wp_headers', function ($headers) {
    if (is_admin() || !function_exists('wc_get_page_id')) {
        return $headers;
    }
    $pages = array_filter(array(wc_get_page_id('cart'), wc_get_page_id('checkout'), wc_get_page_id('myaccount')), function ($id) { return $id > 0; });
    if ($pages && is_page($pages)) {
        $headers['Cache-Control'] = 'no-cache, no-store, must-revalidate, max-age=0, private';
    }
    return $headers;
}, 9999);
