<?php
/**
 * Scelta degli extra in un popup (menu e home): i prodotti con add-on (WooCommerce Product Add-ons) o variabili
 * non aprono più la scheda prodotto. Il pulsante «Scegli» apre un popup con il modulo vero della scheda (campi,
 * prezzi, obbligatori e totale del plugin) e aggiunge al carrello senza lasciare la pagina.
 *  - GET  ?wc-ajax=li_product_form&product=ID → foto, nome, descrizione e HTML del modulo;
 *  - POST ?wc-ajax=li_add_with_options        → aggiunta come dalla scheda (stessa validazione di WooCommerce
 *    e del plugin), poi i frammenti del carrello per aggiornare l'header.
 */
defined('ABSPATH') || exit;

/** Il prodotto si sceglie nel popup? (add-on o variabile, acquistabile e disponibile). */
function littleinka_quick_add_needed(WC_Product $product)
{
    return $product->is_purchasable() && $product->is_in_stock()
        && ($product->is_type('variable') || littleinka_product_has_addons($product));
}

/** Script e stili di Product Add-ons e della variazione, sulle pagine con il menu (il plugin li carica solo sulle schede). */
function littleinka_quick_add_assets()
{
    if (isset($GLOBALS['Product_Addon_Display']) && method_exists($GLOBALS['Product_Addon_Display'], 'addon_scripts')) {
        $GLOBALS['Product_Addon_Display']->addon_scripts();
        if (defined('WC_PRODUCT_ADDONS_PLUGIN_URL') && defined('WC_PRODUCT_ADDONS_VERSION')) {
            wp_enqueue_style('woocommerce-addons-css', WC_PRODUCT_ADDONS_PLUGIN_URL . '/assets/css/frontend/frontend.css', array('dashicons'), WC_PRODUCT_ADDONS_VERSION);
        }
    }
    // Le descrizioni degli extra usano tipTip: il plugin lo carica solo nelle sue pagine.
    if (function_exists('WC') && !wp_script_is('jquery-tiptip', 'registered')) {
        $suffix = defined('SCRIPT_DEBUG') && SCRIPT_DEBUG ? '' : '.min';
        wp_register_script('dompurify', WC()->plugin_url() . '/assets/js/dompurify/purify' . $suffix . '.js', array(), WC_VERSION, false);
        wp_register_script('jquery-tiptip', WC()->plugin_url() . '/assets/js/jquery-tiptip/jquery.tipTip.min.js', array('jquery', 'dompurify'), WC_VERSION, true);
    }
    wp_enqueue_script('jquery-tiptip');
    if (wp_script_is('wc-add-to-cart-variation', 'registered')) {
        wp_enqueue_script('wc-add-to-cart-variation');
    }
}

add_action('wc_ajax_li_product_form', function () {
    $product = wc_get_product(absint(wp_unslash($_GET['product'] ?? 0))); // phpcs:ignore WordPress.Security.NonceVerification -- sola lettura di un prodotto pubblico
    if (!$product || $product->get_status() !== 'publish' || !littleinka_quick_add_needed($product)) {
        wp_send_json_error(null, 404);
    }
    global $post;
    $post = get_post($product->get_id()); // phpcs:ignore WordPress.WP.GlobalVariablesOverride -- il modulo della scheda legge il prodotto globale
    setup_postdata($post);
    $GLOBALS['product'] = $product;

    ob_start();
    woocommerce_template_single_add_to_cart();
    $form = ob_get_clean();
    wp_reset_postdata();

    $image = (int) $product->get_image_id();
    wp_send_json_success(array(
        'id'    => $product->get_id(),
        'name'  => wp_strip_all_tags($product->get_name()),
        'price' => wp_kses_post($product->get_price_html()),
        'desc'  => littleinka_menu_product_excerpt($product, 240),
        'image' => $image ? (string) wp_get_attachment_image_url($image, 'woocommerce_single') : '',
        'form'  => $form,
    ));
});

add_action('wc_ajax_li_add_with_options', function () {
    // Il campo si chiama «li_product» e non «add-to-cart», altrimenti WooCommerce lo aggiungerebbe già al caricamento.
    $id = absint(wp_unslash($_POST['li_product'] ?? 0)); // phpcs:ignore WordPress.Security.NonceVerification -- come il modulo della scheda prodotto di WooCommerce
    $product = $id ? wc_get_product($id) : null;
    if (!$product || !littleinka_quick_add_needed($product)) {
        wp_send_json_error(array('messages' => array(__('Questo piatto non è disponibile.', 'littleinka-child-theme'))), 400);
    }
    $_REQUEST['add-to-cart'] = (string) $id;
    add_filter('woocommerce_add_to_cart_redirect', '__return_false', 99);
    add_filter('pre_option_woocommerce_cart_redirect_after_add', function () { return 'no'; });
    wc_clear_notices();
    WC_Form_Handler::add_to_cart_action(false);
    $errors = wc_get_notices('error');
    wc_clear_notices();
    if ($errors) {
        wp_send_json_error(array('messages' => array_map(function ($n) {
            return wp_strip_all_tags(is_array($n) ? (string) $n['notice'] : (string) $n);
        }, $errors)), 400);
    }
    WC_AJAX::get_refreshed_fragments(); // risponde con i frammenti e termina
});
