<?php
/**
 * Little Inka: «Porta sul sito» (Strumenti → Little Inka: Porta sul sito).
 *
 * Porta i contenuti di UNA sede dal sito locale al sito live senza toccare il database:
 * sul locale si scarica un file JSON leggero, sul live lo si carica, si legge l'anteprima
 * e si conferma. Gli elementi si riconoscono per slug o chiave: quelli già presenti vengono
 * aggiornati, mai duplicati. Le immagini viaggiano come token per NOME FILE («limedia:foto.jpg»):
 * sul sito di destinazione devono già stare nella Libreria media con lo stesso nome, così gli ID
 * (diversi da un sito all'altro) si riagganciano da soli. Il dominio diventa il segnaposto {{home}}.
 *
 * Porta: pagine (con meta SEO, immagine in evidenza, template, scheda FAQ collegata), opzioni del
 * CMS (contatti, logo, icona, colore, SEO, cookie, privacy, Google, pagina iniziale, nome del sito),
 * impostazioni «Little Inka» del Customizer, menu di navigazione, schede FAQ.
 * NON porta: prodotti, categorie, ordini, clienti, utenti, consegne (zone, CodeRockz), pagamenti,
 * chiavi, licenze, plugin, file delle immagini.
 */
defined('ABSPATH') || exit;

const LITTLEINKA_CT_TOKEN     = 'limedia:';
const LITTLEINKA_CT_FORMAT    = 'littleinka-content';
const LITTLEINKA_CT_VERSION   = 1;
const LITTLEINKA_CT_HOME      = '{{home}}';
const LITTLEINKA_CT_MAX_BYTES = 5242880; // 5 MB
const LITTLEINKA_CT_SLUG      = 'littleinka-transfer';

/* -------------------------------------------------------------------------
 * Liste bianche: cosa viaggia e con quale tipo di dato
 * ---------------------------------------------------------------------- */

/** Stati delle pagine e delle schede FAQ che viaggiano (il cestino no). */
function littleinka_ct_statuses()
{
    return array('publish', 'draft', 'private', 'pending');
}

/** Meta delle pagine che viaggiano, con il tipo di dato per la sanitizzazione in import. */
function littleinka_ct_page_meta_types()
{
    return array(
        '_thumbnail_id'       => 'image',
        '_tw_seo_title'       => 'text',
        '_tw_seo_description' => 'textarea',
        '_tw_seo_robots'      => 'text',
        '_wp_page_template'   => 'template',
        '_tw_faq_page_set'    => 'slug',
    );
}

/**
 * Tipo di dato di un'opzione ammessa, oppure '' se l'opzione NON va toccata.
 * Qui sta tutta la lista bianca: fuori da questa funzione nessuna opzione viene scritta.
 */
function littleinka_ct_option_type($name)
{
    $name = (string) $name;
    if ($name === '' || preg_match('/(key|secret|token|password|licen[sc]e|_transient_)/i', $name)) {
        return '';
    }
    $fixed = array(
        'ticinoweb_site_logo'      => 'url',
        'ticinoweb_site_icon'      => 'url',
        'ticinoweb_palette_primary' => 'color',
        'tw_cookie_banner_enable'  => 'text',
        'tw_privacy_policy_url'    => 'url',
        'tw_google_analytics_id'   => 'text',
        'tw_gtag_code'             => 'code',
        'tw_gtm_head_code'         => 'code',
        'tw_gtm_body_code'         => 'code',
        'show_on_front'            => 'enum_front',
        'page_on_front'            => 'page',
        'page_for_posts'           => 'page',
        'blogname'                 => 'text',
        'blogdescription'          => 'text',
    );
    if (isset($fixed[$name])) {
        return $fixed[$name];
    }
    if (strpos($name, 'ticinoweb_contact_') === 0) {
        $rest = substr($name, strlen('ticinoweb_contact_'));
        if (in_array($rest, array('map_url', 'facebook', 'instagram', 'tiktok', 'linkedin', 'youtube', 'x', 'github', 'behance'), true)) {
            return 'url';
        }
        if ($rest === 'opening_hours') {
            return 'array_text';
        }
        if (in_array($rest, array('address', 'address_2', 'opening_hours_note'), true)) {
            return 'textarea';
        }
        return 'text';
    }
    if (strpos($name, 'tw_seo_') === 0) {
        $rest = substr($name, strlen('tw_seo_'));
        if (in_array($rest, array('social_image', 'org_logo'), true)) {
            return 'url';
        }
        if (in_array($rest, array('org_social', 'description', 'business_address'), true)) {
            return 'textarea';
        }
        if (in_array($rest, array('exclude_sitemap', 'enable_metabox'), true)) {
            return 'array_key';
        }
        return 'text';
    }
    return '';
}

/** Nomi delle opzioni da esportare: quelle fisse più tutte le ticinoweb_contact_* e tw_seo_* presenti nel database. */
function littleinka_ct_option_names()
{
    global $wpdb;
    $names = array(
        'ticinoweb_site_logo', 'ticinoweb_site_icon', 'ticinoweb_palette_primary',
        'tw_cookie_banner_enable', 'tw_privacy_policy_url', 'tw_google_analytics_id',
        'tw_gtag_code', 'tw_gtm_head_code', 'tw_gtm_body_code',
        'show_on_front', 'page_on_front', 'page_for_posts', 'blogname', 'blogdescription',
    );
    $rows = $wpdb->get_col(
        "SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE 'ticinoweb\_contact\_%' OR option_name LIKE 'tw\_seo\_%' ORDER BY option_name ASC"
    );
    foreach ((array) $rows as $row) {
        $names[] = (string) $row;
    }
    $names = array_values(array_unique($names));
    return array_values(array_filter($names, function ($name) {
        return littleinka_ct_option_type($name) !== '';
    }));
}

/* -------------------------------------------------------------------------
 * Immagini: token per nome file
 * ---------------------------------------------------------------------- */

/** True se l'ID è un allegato di questo sito. */
function littleinka_ct_is_attachment($id)
{
    $id = absint($id);
    return $id > 0 && get_post_type($id) === 'attachment';
}

/** Nome file (basename) di un allegato, '' se assente. */
function littleinka_ct_attachment_basename($id)
{
    $file = get_post_meta(absint($id), '_wp_attached_file', true);
    return $file ? basename((string) $file) : '';
}

/**
 * Cerca un allegato per nome file. Prova il nome così com'è, poi senza il suffisso di
 * dimensione (-300x200), con e senza «-scaled». Ritorna ['id', 'url', 'file'] o null.
 */
function littleinka_ct_find_attachment($filename)
{
    global $wpdb;
    static $cache = array();

    $filename = sanitize_file_name(rawurldecode(basename((string) $filename)));
    if ($filename === '') {
        return null;
    }
    if (array_key_exists($filename, $cache)) {
        return $cache[$filename];
    }
    $ext   = pathinfo($filename, PATHINFO_EXTENSION);
    $stem  = pathinfo($filename, PATHINFO_FILENAME);
    $plain = preg_replace('/-scaled$/', '', preg_replace('/-\d+x\d+$/', '', $stem));
    $candidates = array_unique(array(
        $filename,
        $plain . '.' . $ext,
        $plain . '-scaled.' . $ext,
    ));
    $result = null;
    foreach ($candidates as $candidate) {
        $id = (int) $wpdb->get_var($wpdb->prepare(
            "SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = '_wp_attached_file' AND (meta_value = %s OR meta_value LIKE %s) ORDER BY post_id DESC LIMIT 1",
            $candidate,
            '%/' . $wpdb->esc_like($candidate)
        ));
        if ($id && littleinka_ct_is_attachment($id)) {
            $url = wp_get_attachment_url($id);
            if ($url) {
                $result = array('id' => $id, 'url' => $url, 'file' => littleinka_ct_attachment_basename($id));
                break;
            }
        }
    }
    $cache[$filename] = $result;
    return $result;
}

/**
 * URL di questo sito per un nome file richiesto (anche in una dimensione intermedia, es. foto-300x200.jpg).
 * '' se l'immagine non c'è.
 */
function littleinka_ct_token_url($filename)
{
    $found = littleinka_ct_find_attachment($filename);
    if (!$found) {
        return '';
    }
    $requested = sanitize_file_name(rawurldecode(basename((string) $filename)));
    if ($requested === $found['file']) {
        return $found['url'];
    }
    $dir = untrailingslashit(dirname($found['url']));
    $ext = pathinfo($requested, PATHINFO_EXTENSION);
    if (preg_match('/-(\d+x\d+)$/', pathinfo($requested, PATHINFO_FILENAME), $m)) {
        $plain = preg_replace('/-scaled$/', '', pathinfo($found['file'], PATHINFO_FILENAME));
        return $dir . '/' . $plain . '-' . $m[1] . '.' . $ext;
    }
    $attached = get_attached_file($found['id']);
    if ($attached && file_exists(dirname($attached) . '/' . $requested)) {
        return $dir . '/' . $requested;
    }
    return $found['url'];
}

/**
 * Testo in forma portabile: gli URL della cartella uploads diventano token per nome file,
 * il dominio del sito diventa {{home}}. Raccoglie in $files i nomi file incontrati.
 */
function littleinka_ct_encode_text($text, array &$files)
{
    if (!is_string($text) || $text === '') {
        return $text;
    }
    $text = preg_replace_callback(
        '~(?:https?:)?//[^\s"\'<>()]+?/wp-content/uploads/[^\s"\'<>(),?#]+(?:\?[^\s"\'<>()]*)?|(?<![\w:/])/(?:[\w.-]+/)?wp-content/uploads/[^\s"\'<>(),?#]+(?:\?[^\s"\'<>()]*)?~i',
        function ($m) use (&$files) {
            $path = (string) wp_parse_url(html_entity_decode($m[0], ENT_QUOTES, 'UTF-8'), PHP_URL_PATH);
            $name = sanitize_file_name(rawurldecode(basename($path)));
            if ($name === '' || !preg_match('/\.[a-z0-9]{2,5}$/i', $name)) {
                return $m[0];
            }
            $files[$name] = true;
            return LITTLEINKA_CT_TOKEN . $name;
        },
        $text
    );
    $home = untrailingslashit(home_url());
    $variants = array_unique(array($home, set_url_scheme($home, 'http'), set_url_scheme($home, 'https')));
    $text = str_replace($variants, LITTLEINKA_CT_HOME, $text);
    $path = trim((string) wp_parse_url($home, PHP_URL_PATH), '/');
    if ($path !== '') {
        // Link relativi alla radice in un multisito a sottocartelle: href="/sede/menu/" → {{home}}/menu/
        $text = preg_replace('~(["\'(=])/' . preg_quote($path, '~') . '(?=/|["\')])~', '$1' . LITTLEINKA_CT_HOME, $text);
    }
    return $text;
}

/** ID allegato → token per nome file (il valore resta com'è se non è un allegato). */
function littleinka_ct_encode_id($value, array &$files)
{
    if (is_numeric($value) && littleinka_ct_is_attachment($value)) {
        $name = littleinka_ct_attachment_basename($value);
        if ($name !== '') {
            $files[$name] = true;
            return LITTLEINKA_CT_TOKEN . $name;
        }
    }
    return $value;
}

/** Forma portabile di una struttura: ogni stringa passa da littleinka_ct_encode_text(). */
function littleinka_ct_encode_deep($value, array &$files)
{
    if (is_array($value)) {
        $out = array();
        foreach ($value as $k => $v) {
            $out[$k] = littleinka_ct_encode_deep($v, $files);
        }
        return $out;
    }
    return is_string($value) ? littleinka_ct_encode_text($value, $files) : $value;
}

/**
 * Da portabile a locale: i token diventano URL di questo sito (se l'immagine manca il token resta
 * e il nome finisce in $missing), {{home}} diventa home_url().
 */
function littleinka_ct_decode_text($text, array &$found, array &$missing)
{
    if (!is_string($text) || $text === '') {
        return $text;
    }
    $text = preg_replace_callback(
        '~' . preg_quote(LITTLEINKA_CT_TOKEN, '~') . '([A-Za-z0-9._%+@-]+)~',
        function ($m) use (&$found, &$missing) {
            $url = littleinka_ct_token_url($m[1]);
            if ($url === '') {
                $missing[$m[1]] = true;
                return $m[0];
            }
            $found[$m[1]] = true;
            return $url;
        },
        $text
    );
    return str_replace(LITTLEINKA_CT_HOME, untrailingslashit(home_url()), $text);
}

/**
 * Token → ID allegato di questo sito (0 se manca: il nome finisce in $missing).
 * Un ID numerico «nudo» vale 0: gli ID di un altro sito non si copiano mai così come sono.
 */
function littleinka_ct_decode_id($value, array &$found, array &$missing)
{
    if (is_string($value) && strpos($value, LITTLEINKA_CT_TOKEN) === 0) {
        $name = substr($value, strlen(LITTLEINKA_CT_TOKEN));
        $hit  = littleinka_ct_find_attachment($name);
        if ($hit) {
            $found[$name] = true;
            return (int) $hit['id'];
        }
        $missing[$name] = true;
    }
    return 0;
}

/** Struttura da portabile a locale: ogni stringa passa da littleinka_ct_decode_text(). */
function littleinka_ct_decode_deep($value, array &$found, array &$missing)
{
    if (is_array($value)) {
        $out = array();
        foreach ($value as $k => $v) {
            $out[$k] = littleinka_ct_decode_deep($v, $found, $missing);
        }
        return $out;
    }
    return is_string($value) ? littleinka_ct_decode_text($value, $found, $missing) : $value;
}

/* -------------------------------------------------------------------------
 * Sanitizzazione per tipo (niente valore arriva nel database così com'è)
 * ---------------------------------------------------------------------- */

/** Pulisce ricorsivamente una struttura: stringhe con $fn, numeri e booleani restano tali, il resto sparisce. */
function littleinka_ct_sanitize_deep($value, $fn)
{
    if (is_array($value)) {
        $out = array();
        foreach ($value as $k => $v) {
            $key = is_int($k) ? $k : sanitize_text_field((string) $k);
            $out[$key] = littleinka_ct_sanitize_deep($v, $fn);
        }
        return $out;
    }
    if (is_bool($value) || is_int($value) || is_float($value)) {
        return $value;
    }
    return is_string($value) ? call_user_func($fn, $value) : '';
}

/** Pulisce un valore secondo il tipo della lista bianca. */
function littleinka_ct_sanitize($value, $type)
{
    switch ($type) {
        case 'html':
            return wp_kses_post((string) (is_scalar($value) ? $value : ''));
        case 'textarea':
            return sanitize_textarea_field((string) (is_scalar($value) ? $value : ''));
        case 'url':
            return esc_url_raw(trim((string) (is_scalar($value) ? $value : '')));
        case 'color':
            $color = sanitize_hex_color(trim((string) (is_scalar($value) ? $value : '')));
            return $color ? $color : '';
        case 'template':
            // Un template di pagina esistente nel tema (anche in sottocartella), altrimenti «default».
            $template = preg_replace('~[^A-Za-z0-9_./-]~', '', (string) (is_scalar($value) ? $value : ''));
            if ($template === '' || $template === 'default' || strpos($template, '..') !== false) {
                return 'default';
            }
            $known = wp_get_theme()->get_page_templates(null, 'page');
            return isset($known[$template]) ? $template : 'default';
        case 'slug':
            return sanitize_title((string) (is_scalar($value) ? $value : ''));
        case 'int':
            return absint($value);
        case 'enum_front':
            return $value === 'posts' ? 'posts' : 'page';
        case 'code':
            // Snippet Google Tag / GTM: li pulisce lo stesso filtro della pagina SEO del parent.
            $code = (string) (is_scalar($value) ? $value : '');
            return function_exists('tw_seo_sanitize_tag_code') ? tw_seo_sanitize_tag_code($code) : $code;
        case 'array_text':
            return littleinka_ct_sanitize_deep(is_array($value) ? $value : array(), 'sanitize_text_field');
        case 'array_key':
            return array_values(array_filter(array_map('sanitize_key', array_filter((array) $value, 'is_scalar'))));
        case 'text':
        default:
            return sanitize_text_field((string) (is_scalar($value) ? $value : ''));
    }
}

/* -------------------------------------------------------------------------
 * Pagine e schede: ricerca per slug
 * ---------------------------------------------------------------------- */

/** Pagina per percorso (genitore/figlia) o per slug, in qualunque stato tranne il cestino. */
function littleinka_ct_find_post($path, $slug, $post_type = 'page')
{
    $post = $path !== '' ? get_page_by_path($path, OBJECT, $post_type) : null;
    if (!$post instanceof WP_Post && $slug !== '') {
        $found = get_posts(array(
            'post_type'        => $post_type,
            'name'             => $slug,
            'post_status'      => littleinka_ct_statuses(),
            'numberposts'      => 1,
            'suppress_filters' => true,
        ));
        $post = $found ? $found[0] : null;
    }
    return ($post instanceof WP_Post && $post->post_status !== 'trash') ? $post : null;
}

/** Elemento dell'indice immagini: nome del file originale e dimensioni (0 se l'immagine non è su questo sito). */
function littleinka_ct_media_entry($filename)
{
    $hit   = littleinka_ct_find_attachment($filename);
    $entry = array('file' => sanitize_file_name(rawurldecode(basename((string) $filename))), 'width' => 0, 'height' => 0, 'mime' => '');
    if (!$hit) {
        return $entry;
    }
    $meta = wp_get_attachment_metadata($hit['id']);
    $entry['file']   = !empty($meta['original_image']) ? basename((string) $meta['original_image']) : $hit['file'];
    $entry['width']  = isset($meta['width']) ? (int) $meta['width'] : 0;
    $entry['height'] = isset($meta['height']) ? (int) $meta['height'] : 0;
    $entry['mime']   = (string) get_post_mime_type($hit['id']);
    return $entry;
}

/* -------------------------------------------------------------------------
 * Esportazione
 * ---------------------------------------------------------------------- */

/** Costruisce il pacchetto dei contenuti di questa sede. */
function littleinka_ct_export_payload()
{
    $files = array();

    // 1) Pagine (mai i prodotti: solo post_type page).
    $pages = array();
    $posts = get_posts(array(
        'post_type'        => 'page',
        'post_status'      => littleinka_ct_statuses(),
        'numberposts'      => -1,
        'orderby'          => array('menu_order' => 'ASC', 'ID' => 'ASC'),
        'suppress_filters' => true,
    ));
    foreach ($posts as $post) {
        $meta = array();
        foreach (littleinka_ct_page_meta_types() as $key => $type) {
            $raw = get_post_meta($post->ID, $key, true);
            if ($raw === '' || $raw === false || $raw === null) {
                continue;
            }
            if ($type === 'image') {
                $token = littleinka_ct_encode_id($raw, $files);
                if ($token === $raw) {
                    continue; // ID che non è un allegato: non viaggia.
                }
                $meta[$key] = $token;
                continue;
            }
            $meta[$key] = littleinka_ct_encode_text((string) $raw, $files);
        }
        $pages[] = array(
            'slug'       => $post->post_name,
            'path'       => get_page_uri($post),
            'title'      => $post->post_title,
            'content'    => littleinka_ct_encode_text($post->post_content, $files),
            'excerpt'    => littleinka_ct_encode_text($post->post_excerpt, $files),
            'status'     => $post->post_status,
            'menu_order' => (int) $post->menu_order,
            'parent'     => $post->post_parent ? get_post_field('post_name', $post->post_parent) : '',
            'template'   => (string) get_post_meta($post->ID, '_wp_page_template', true),
            'meta'       => $meta,
        );
    }

    // 2) Opzioni del CMS (le pagine per slug, le immagini per nome file).
    $options = array();
    foreach (littleinka_ct_option_names() as $name) {
        $value = get_option($name, null);
        if ($value === null) {
            continue;
        }
        if (littleinka_ct_option_type($name) === 'page') {
            $value = absint($value) ? (string) get_page_uri(absint($value)) : '';
        }
        $options[$name] = littleinka_ct_encode_deep($value, $files);
    }

    // 3) Impostazioni del tema (Customizer → Little Inka) e posizioni dei menu (per nome).
    $theme_mods = array();
    $locations  = array();
    foreach ((array) get_theme_mods() as $key => $value) {
        if ($key === 'nav_menu_locations' && is_array($value)) {
            foreach ($value as $location => $menu_id) {
                $menu = $menu_id ? wp_get_nav_menu_object((int) $menu_id) : false;
                $locations[sanitize_key($location)] = $menu ? $menu->name : '';
            }
            continue;
        }
        if (strpos((string) $key, 'littleinka_') !== 0) {
            continue;
        }
        if (is_numeric($value) && preg_match('/(image|logo|icon|img|foto|photo)/', (string) $key) && littleinka_ct_is_attachment($value)) {
            $theme_mods[$key] = littleinka_ct_encode_id($value, $files);
        } else {
            $theme_mods[$key] = littleinka_ct_encode_deep($value, $files);
        }
    }

    // 4) Menu di navigazione.
    $menus = array();
    foreach ((array) wp_get_nav_menus() as $menu) {
        $items = wp_get_nav_menu_items($menu->term_id, array('update_post_term_cache' => false));
        $list  = array();
        foreach ((array) $items as $item) {
            $entry = array(
                'ref'         => (int) $item->ID,
                'parent'      => (int) $item->menu_item_parent,
                'order'       => (int) $item->menu_order,
                'type'        => (string) $item->type,
                'object'      => (string) $item->object,
                'slug'        => '',
                'url'         => '',
                'title'       => (string) $item->post_title,
                'target'      => (string) $item->target,
                'classes'     => implode(' ', array_filter((array) $item->classes)),
                'xfn'         => (string) $item->xfn,
                'attr_title'  => (string) $item->attr_title,
                'description' => (string) $item->post_content,
            );
            if ($item->type === 'post_type') {
                $entry['slug'] = $item->object === 'page' ? (string) get_page_uri((int) $item->object_id) : (string) get_post_field('post_name', (int) $item->object_id);
            } elseif ($item->type === 'taxonomy') {
                $term = get_term((int) $item->object_id, $item->object);
                $entry['slug'] = ($term instanceof WP_Term) ? $term->slug : '';
            } else {
                $entry['url'] = littleinka_ct_encode_text((string) $item->url, $files);
            }
            $list[] = $entry;
        }
        $menus[] = array('name' => $menu->name, 'slug' => $menu->slug, 'items' => $list);
    }

    // 5) Schede FAQ del parent (tw_faq): le domande stanno nei meta _tw_faq_*.
    $faqs = array();
    if (post_type_exists('tw_faq')) {
        $cards = get_posts(array(
            'post_type'        => 'tw_faq',
            'post_status'      => littleinka_ct_statuses(),
            'numberposts'      => -1,
            'orderby'          => array('menu_order' => 'ASC', 'ID' => 'ASC'),
            'suppress_filters' => true,
        ));
        foreach ($cards as $card) {
            $meta = array();
            foreach ((array) get_post_meta($card->ID) as $key => $values) {
                if (!littleinka_ct_faq_meta_allowed($key) || !isset($values[0])) {
                    continue;
                }
                $meta[$key] = littleinka_ct_encode_deep(maybe_unserialize($values[0]), $files);
            }
            $faqs[] = array(
                'slug'       => $card->post_name,
                'title'      => $card->post_title,
                'status'     => $card->post_status,
                'menu_order' => (int) $card->menu_order,
                'meta'       => $meta,
            );
        }
    }

    // 6) Indice delle immagini citate (nome file e dimensioni): serve al resoconto dei mancanti.
    $media = array();
    foreach (array_keys($files) as $name) {
        $entry = littleinka_ct_media_entry($name);
        $media[$entry['file']] = $entry;
    }
    ksort($media);

    return array(
        'format'      => LITTLEINKA_CT_FORMAT,
        'version'     => LITTLEINKA_CT_VERSION,
        'exported_at' => gmdate('c'),
        'source_url'  => home_url(),
        'site_name'   => get_bloginfo('name'),
        'theme'       => get_stylesheet(),
        'pages'       => $pages,
        'options'     => $options,
        'theme_mods'  => $theme_mods,
        'locations'   => $locations,
        'menus'       => $menus,
        'faqs'        => $faqs,
        'media'       => array_values($media),
    );
}

/** Meta di una scheda FAQ che viaggiano: _tw_faq*, _tw_seo* e quelli non protetti (mai _edit_lock e simili). */
function littleinka_ct_faq_meta_allowed($key)
{
    $key = (string) $key;
    if ($key === '') {
        return false;
    }
    if (strpos($key, '_tw_faq') === 0 || strpos($key, '_tw_seo') === 0) {
        return true;
    }
    return !is_protected_meta($key, 'post');
}

/** Slug della sede per il nome del file: il percorso del sottosito, altrimenti il dominio. */
function littleinka_ct_site_slug()
{
    $home = home_url();
    $slug = trim((string) wp_parse_url($home, PHP_URL_PATH), '/');
    if ($slug === '') {
        $slug = (string) wp_parse_url($home, PHP_URL_HOST);
    }
    $slug = sanitize_title(preg_replace('/^littleinka-/', '', sanitize_title($slug)));
    return $slug !== '' ? $slug : 'sede';
}

/** admin-post: scarica il file JSON. */
function littleinka_ct_handle_export()
{
    if (!current_user_can('manage_options')) {
        wp_die(esc_html__('Non hai i permessi per questa operazione.', 'littleinka-child-theme'));
    }
    check_admin_referer('littleinka_ct_export');

    $payload  = littleinka_ct_export_payload();
    $filename = 'littleinka-' . littleinka_ct_site_slug() . '-' . wp_date('Y-m-d') . '.json';
    nocache_headers();
    header('Content-Type: application/json; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    echo wp_json_encode($payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE); // phpcs:ignore WordPress.Security.EscapeOutput
    exit;
}
add_action('admin_post_littleinka_ct_export', 'littleinka_ct_handle_export');

/* -------------------------------------------------------------------------
 * Importazione: caricamento, anteprima, conferma
 * ---------------------------------------------------------------------- */

/** Nome dell'opzione (non autoload) che tiene il file in attesa di conferma per l'utente corrente. */
function littleinka_ct_pending_key()
{
    return 'littleinka_ct_pending_' . get_current_user_id();
}

/** Nome dell'opzione (non autoload) con l'ultimo resoconto dell'utente corrente. */
function littleinka_ct_report_key()
{
    return 'littleinka_ct_report_' . get_current_user_id();
}

/** Il pacchetto in attesa di conferma: ['data' => array, 'token' => string, 'name' => string] o null (scaduto dopo 2 ore). */
function littleinka_ct_pending()
{
    $pending = get_option(littleinka_ct_pending_key());
    if (!is_array($pending) || empty($pending['json']) || empty($pending['token']) || empty($pending['time'])) {
        return null;
    }
    if ((int) $pending['time'] < time() - 2 * HOUR_IN_SECONDS) {
        delete_option(littleinka_ct_pending_key());
        return null;
    }
    $data = littleinka_ct_parse_json((string) $pending['json']);
    if (is_wp_error($data)) {
        delete_option(littleinka_ct_pending_key());
        return null;
    }
    return array('data' => $data, 'token' => (string) $pending['token'], 'name' => (string) ($pending['name'] ?? ''));
}

/** Decodifica e controlla il JSON del pacchetto (niente unserialize: il JSON basta). */
function littleinka_ct_parse_json($json)
{
    $data = json_decode($json, true, 64);
    if (!is_array($data) || json_last_error() !== JSON_ERROR_NONE) {
        return new WP_Error('json', __('Il file non è un JSON leggibile.', 'littleinka-child-theme'));
    }
    if (($data['format'] ?? '') !== LITTLEINKA_CT_FORMAT) {
        return new WP_Error('format', __('Il file non è stato prodotto da «Little Inka: Porta sul sito».', 'littleinka-child-theme'));
    }
    if ((int) ($data['version'] ?? 0) > LITTLEINKA_CT_VERSION) {
        return new WP_Error('version', __('Il file viene da una versione più nuova del tema: aggiorna prima il tema su questo sito.', 'littleinka-child-theme'));
    }
    foreach (array('pages', 'options', 'theme_mods', 'locations', 'menus', 'faqs', 'media') as $key) {
        if (isset($data[$key]) && !is_array($data[$key])) {
            return new WP_Error('shape', __('Il file è danneggiato.', 'littleinka-child-theme'));
        }
    }
    return $data;
}

/** Legge il file caricato: ritorna il JSON come stringa o un WP_Error. */
function littleinka_ct_read_upload()
{
    $file = isset($_FILES['littleinka_ct_file']) && is_array($_FILES['littleinka_ct_file']) ? $_FILES['littleinka_ct_file'] : null; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
    if (!$file || (int) ($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK || empty($file['tmp_name'])) {
        return new WP_Error('upload', __('Nessun file ricevuto. Scegli il file .json scaricato dal sito di partenza.', 'littleinka-child-theme'));
    }
    if ((int) $file['size'] > LITTLEINKA_CT_MAX_BYTES || (int) $file['size'] <= 0) {
        return new WP_Error('size', sprintf(
            /* translators: %s: dimensione massima */
            __('Il file supera il limite di %s.', 'littleinka-child-theme'),
            size_format(LITTLEINKA_CT_MAX_BYTES)
        ));
    }
    $name = sanitize_file_name((string) ($file['name'] ?? ''));
    $type = wp_check_filetype($name, array('json' => 'application/json'));
    if (empty($type['ext']) || $type['ext'] !== 'json') {
        return new WP_Error('type', __('Il file deve essere un .json.', 'littleinka-child-theme'));
    }
    $tmp = (string) $file['tmp_name'];
    if (!is_uploaded_file($tmp)) {
        return new WP_Error('upload', __('Caricamento non valido.', 'littleinka-child-theme'));
    }
    $json = file_get_contents($tmp); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
    if (!is_string($json) || $json === '') {
        return new WP_Error('read', __('Il file è vuoto.', 'littleinka-child-theme'));
    }
    $data = littleinka_ct_parse_json($json);
    if (is_wp_error($data)) {
        return $data;
    }
    return array('json' => $json, 'name' => $name);
}

/** URL della pagina dello strumento, con eventuali parametri. */
function littleinka_ct_page_url(array $args = array())
{
    return add_query_arg($args, admin_url('tools.php?page=' . LITTLEINKA_CT_SLUG));
}

/** admin-post: riceve il file, lo controlla e lo mette in attesa di conferma (anteprima). */
function littleinka_ct_handle_upload()
{
    if (!current_user_can('manage_options')) {
        wp_die(esc_html__('Non hai i permessi per questa operazione.', 'littleinka-child-theme'));
    }
    check_admin_referer('littleinka_ct_upload');

    $read = littleinka_ct_read_upload();
    if (is_wp_error($read)) {
        set_transient('littleinka_ct_error_' . get_current_user_id(), $read->get_error_message(), MINUTE_IN_SECONDS * 5);
        wp_safe_redirect(littleinka_ct_page_url(array('step' => 'error')));
        exit;
    }
    update_option(littleinka_ct_pending_key(), array(
        'json'  => $read['json'],
        'name'  => $read['name'],
        'token' => wp_generate_password(24, false, false),
        'time'  => time(),
    ), 'no');
    wp_safe_redirect(littleinka_ct_page_url(array('step' => 'preview')));
    exit;
}
add_action('admin_post_littleinka_ct_upload', 'littleinka_ct_handle_upload');

/** admin-post: annulla il file in attesa. */
function littleinka_ct_handle_cancel()
{
    if (!current_user_can('manage_options')) {
        wp_die(esc_html__('Non hai i permessi per questa operazione.', 'littleinka-child-theme'));
    }
    check_admin_referer('littleinka_ct_cancel');
    delete_option(littleinka_ct_pending_key());
    wp_safe_redirect(littleinka_ct_page_url());
    exit;
}
add_action('admin_post_littleinka_ct_cancel', 'littleinka_ct_handle_cancel');

/** admin-post: conferma e importa davvero. */
function littleinka_ct_handle_import()
{
    if (!current_user_can('manage_options')) {
        wp_die(esc_html__('Non hai i permessi per questa operazione.', 'littleinka-child-theme'));
    }
    check_admin_referer('littleinka_ct_import');

    $pending = littleinka_ct_pending();
    $token   = isset($_POST['littleinka_ct_token']) ? sanitize_text_field(wp_unslash($_POST['littleinka_ct_token'])) : '';
    if (!$pending || $token === '' || !hash_equals($pending['token'], $token)) {
        set_transient('littleinka_ct_error_' . get_current_user_id(), __('Il file da importare non c\'è più o è scaduto: ricaricalo.', 'littleinka-child-theme'), MINUTE_IN_SECONDS * 5);
        wp_safe_redirect(littleinka_ct_page_url(array('step' => 'error')));
        exit;
    }
    $report = littleinka_ct_run_import($pending['data']);
    $report['file'] = $pending['name'];
    $report['time'] = time();
    update_option(littleinka_ct_report_key(), $report, 'no');
    delete_option(littleinka_ct_pending_key());
    wp_safe_redirect(littleinka_ct_page_url(array('step' => 'done')));
    exit;
}
add_action('admin_post_littleinka_ct_import', 'littleinka_ct_handle_import');

/* -------------------------------------------------------------------------
 * Anteprima: cosa cambierà (non scrive nulla)
 * ---------------------------------------------------------------------- */

function littleinka_ct_preview(array $data)
{
    $preview = array('pages' => array(), 'options' => array(), 'theme_mods' => 0, 'locations' => array(), 'menus' => array(), 'faqs' => array(), 'images_found' => array(), 'images_missing' => array(), 'warnings' => array());

    $source = untrailingslashit((string) ($data['source_url'] ?? ''));
    if ($source !== '' && $source === untrailingslashit(home_url())) {
        $preview['warnings'][] = __('Il file è stato esportato da questo stesso sito: l\'importazione riscriverà i contenuti con quelli del file.', 'littleinka-child-theme');
    }
    if (!empty($data['theme']) && $data['theme'] !== get_stylesheet()) {
        $preview['warnings'][] = sprintf(
            /* translators: %s: nome del tema */
            __('Il file viene da un sito con un altro tema (%s): le impostazioni del Customizer potrebbero non corrispondere.', 'littleinka-child-theme'),
            (string) $data['theme']
        );
    }

    foreach ((array) ($data['pages'] ?? array()) as $item) {
        $slug = sanitize_title((string) ($item['slug'] ?? ''));
        if ($slug === '') {
            continue;
        }
        $existing = littleinka_ct_find_post(sanitize_text_field((string) ($item['path'] ?? '')), $slug, 'page');
        $preview['pages'][] = array(
            'slug'   => $slug,
            'title'  => sanitize_text_field((string) ($item['title'] ?? $slug)),
            'status' => in_array($item['status'] ?? '', littleinka_ct_statuses(), true) ? $item['status'] : 'publish',
            'action' => $existing ? 'update' : 'create',
        );
    }
    foreach ((array) ($data['options'] ?? array()) as $name => $value) {
        if (littleinka_ct_option_type($name) !== '') {
            $preview['options'][] = (string) $name;
        }
    }
    foreach ((array) ($data['theme_mods'] ?? array()) as $key => $value) {
        if (strpos((string) $key, 'littleinka_') === 0) {
            $preview['theme_mods']++;
        }
    }
    foreach ((array) ($data['locations'] ?? array()) as $location => $menu_name) {
        $preview['locations'][sanitize_key($location)] = sanitize_text_field((string) $menu_name);
    }
    foreach ((array) ($data['menus'] ?? array()) as $menu) {
        $name = sanitize_text_field((string) ($menu['name'] ?? ''));
        if ($name === '') {
            continue;
        }
        $preview['menus'][] = array(
            'name'   => $name,
            'items'  => is_array($menu['items'] ?? null) ? count($menu['items']) : 0,
            'exists' => (bool) wp_get_nav_menu_object($name),
        );
    }
    if (!post_type_exists('tw_faq') && !empty($data['faqs'])) {
        $preview['warnings'][] = __('Le schede FAQ non si possono importare: il tema parent su questo sito non le prevede.', 'littleinka-child-theme');
    }
    foreach ((array) ($data['faqs'] ?? array()) as $item) {
        $slug = sanitize_title((string) ($item['slug'] ?? ''));
        if ($slug === '') {
            continue;
        }
        $preview['faqs'][] = array(
            'slug'   => $slug,
            'title'  => sanitize_text_field((string) ($item['title'] ?? $slug)),
            'action' => littleinka_ct_find_post('', $slug, 'tw_faq') ? 'update' : 'create',
        );
    }
    foreach ((array) ($data['media'] ?? array()) as $entry) {
        $file = sanitize_file_name((string) ($entry['file'] ?? ''));
        if ($file === '') {
            continue;
        }
        $row = array('file' => $file, 'width' => absint($entry['width'] ?? 0), 'height' => absint($entry['height'] ?? 0));
        if (littleinka_ct_find_attachment($file)) {
            $preview['images_found'][] = $row;
        } else {
            $preview['images_missing'][] = $row;
        }
    }
    return $preview;
}

/* -------------------------------------------------------------------------
 * Importazione vera e propria (idempotente per slug/chiave)
 * ---------------------------------------------------------------------- */

function littleinka_ct_run_import(array $data)
{
    $report = array(
        'pages_created' => array(), 'pages_updated' => array(), 'pages_skipped' => array(),
        'options' => array(), 'theme_mods' => array(), 'locations' => array(),
        'menus' => array(), 'faq_created' => array(), 'faq_updated' => array(),
        'images_found' => array(), 'images_missing' => array(), 'warnings' => array(),
    );
    $found   = array();
    $missing = array();
    $ids     = array(); // percorso/slug della pagina → ID su questo sito

    // 1) Pagine: prima i genitori, poi le figlie.
    $pages = array_filter((array) ($data['pages'] ?? array()), 'is_array');
    usort($pages, function ($a, $b) {
        return substr_count((string) ($a['path'] ?? ''), '/') <=> substr_count((string) ($b['path'] ?? ''), '/');
    });
    foreach ($pages as $item) {
        $slug = sanitize_title((string) ($item['slug'] ?? ''));
        if ($slug === '') {
            continue;
        }
        $path     = sanitize_text_field((string) ($item['path'] ?? $slug));
        $existing = littleinka_ct_find_post($path, $slug, 'page');
        $parent   = sanitize_title((string) ($item['parent'] ?? ''));
        $parent_id = 0;
        if ($parent !== '') {
            $parent_post = isset($ids[$parent]) ? get_post($ids[$parent]) : littleinka_ct_find_post('', $parent, 'page');
            $parent_id   = $parent_post instanceof WP_Post ? (int) $parent_post->ID : 0;
        }
        $status  = in_array($item['status'] ?? '', littleinka_ct_statuses(), true) ? $item['status'] : 'publish';
        $postarr = array(
            'post_type'    => 'page',
            'post_name'    => $slug,
            'post_title'   => littleinka_ct_sanitize($item['title'] ?? $slug, 'text'),
            'post_content' => littleinka_ct_sanitize(littleinka_ct_decode_text((string) ($item['content'] ?? ''), $found, $missing), 'html'),
            'post_excerpt' => littleinka_ct_sanitize(littleinka_ct_decode_text((string) ($item['excerpt'] ?? ''), $found, $missing), 'html'),
            'post_status'  => $status,
            'menu_order'   => (int) ($item['menu_order'] ?? 0),
            'post_parent'  => $parent_id,
        );
        if ($existing) {
            $postarr['ID'] = $existing->ID;
            $result = wp_update_post(wp_slash($postarr), true);
        } else {
            $result = wp_insert_post(wp_slash($postarr), true);
        }
        if (is_wp_error($result) || !$result) {
            $report['pages_skipped'][] = $slug;
            continue;
        }
        $page_id = (int) $result;
        $ids[$slug] = $page_id;
        $ids[$path] = $page_id;

        // Meta della pagina (solo quelli della lista bianca).
        $meta = is_array($item['meta'] ?? null) ? $item['meta'] : array();
        if (!isset($meta['_wp_page_template']) && isset($item['template'])) {
            $meta['_wp_page_template'] = $item['template'];
        }
        foreach (littleinka_ct_page_meta_types() as $key => $type) {
            if (!array_key_exists($key, $meta)) {
                continue;
            }
            if ($type === 'image') {
                $thumb = littleinka_ct_decode_id($meta[$key], $found, $missing);
                if ($thumb > 0) {
                    update_post_meta($page_id, $key, $thumb);
                }
                continue;
            }
            $value = littleinka_ct_sanitize(littleinka_ct_decode_text((string) (is_scalar($meta[$key]) ? $meta[$key] : ''), $found, $missing), $type);
            if ($value === '' || ($type === 'template' && $value === 'default')) {
                delete_post_meta($page_id, $key);
            } else {
                update_post_meta($page_id, $key, $value);
            }
        }
        $report[$existing ? 'pages_updated' : 'pages_created'][] = $slug;
    }

    // 2) Schede FAQ (parent): per slug, con i loro meta.
    if (post_type_exists('tw_faq')) {
        foreach ((array) ($data['faqs'] ?? array()) as $item) {
            $slug = sanitize_title((string) ($item['slug'] ?? ''));
            if (!is_array($item) || $slug === '') {
                continue;
            }
            $existing = littleinka_ct_find_post('', $slug, 'tw_faq');
            $postarr  = array(
                'post_type'   => 'tw_faq',
                'post_name'   => $slug,
                'post_title'  => littleinka_ct_sanitize($item['title'] ?? $slug, 'text'),
                'post_status' => in_array($item['status'] ?? '', littleinka_ct_statuses(), true) ? $item['status'] : 'publish',
                'menu_order'  => (int) ($item['menu_order'] ?? 0),
            );
            if ($existing) {
                $postarr['ID'] = $existing->ID;
                $result = wp_update_post(wp_slash($postarr), true);
            } else {
                $result = wp_insert_post(wp_slash($postarr), true);
            }
            if (is_wp_error($result) || !$result) {
                $report['warnings'][] = sprintf(
                    /* translators: %s: slug della scheda */
                    __('Scheda FAQ «%s» non salvata.', 'littleinka-child-theme'),
                    $slug
                );
                continue;
            }
            foreach ((array) ($item['meta'] ?? array()) as $key => $value) {
                $key = sanitize_key($key);
                if (!littleinka_ct_faq_meta_allowed($key)) {
                    continue;
                }
                $value = littleinka_ct_decode_deep($value, $found, $missing);
                if ($key === '_tw_faq_items') {
                    $value = function_exists('ticinoweb_faq_sanitize_items')
                        ? ticinoweb_faq_sanitize_items(wp_slash(is_array($value) ? $value : array()))
                        : littleinka_ct_sanitize_deep(is_array($value) ? $value : array(), 'wp_kses_post');
                } elseif ($key === '_tw_faq_sections') {
                    $value = littleinka_ct_sanitize_deep(is_array($value) ? $value : array(), 'sanitize_textarea_field');
                } elseif (is_array($value)) {
                    $value = littleinka_ct_sanitize_deep($value, 'wp_kses_post');
                } else {
                    $value = littleinka_ct_sanitize($value, 'html');
                }
                update_post_meta((int) $result, $key, $value);
            }
            $report[$existing ? 'faq_updated' : 'faq_created'][] = $slug;
        }
    } elseif (!empty($data['faqs'])) {
        $report['warnings'][] = __('Schede FAQ non importate: il tema parent su questo sito non le prevede.', 'littleinka-child-theme');
    }

    // 3) Opzioni del CMS: solo la lista bianca, ognuna pulita secondo il suo tipo.
    foreach ((array) ($data['options'] ?? array()) as $name => $value) {
        $name = (string) $name;
        $type = littleinka_ct_option_type($name);
        if ($type === '') {
            continue;
        }
        if ($type === 'page') {
            $path = sanitize_text_field((string) (is_scalar($value) ? $value : ''));
            if ($path === '') {
                update_option($name, 0);
                $report['options'][] = $name;
                continue;
            }
            $page = isset($ids[$path]) ? get_post($ids[$path]) : littleinka_ct_find_post($path, sanitize_title(basename($path)), 'page');
            if (!$page instanceof WP_Post) {
                $report['warnings'][] = sprintf(
                    /* translators: 1: nome dell'opzione, 2: slug della pagina */
                    __('Opzione %1$s non scritta: la pagina «%2$s» non esiste su questo sito.', 'littleinka-child-theme'),
                    $name,
                    $path
                );
                continue;
            }
            update_option($name, (int) $page->ID);
            $report['options'][] = $name;
            continue;
        }
        $value = littleinka_ct_decode_deep($value, $found, $missing);
        update_option($name, littleinka_ct_sanitize($value, $type));
        $report['options'][] = $name;
    }

    // 4) Impostazioni del tema (Customizer → Little Inka).
    foreach ((array) ($data['theme_mods'] ?? array()) as $key => $value) {
        $key = sanitize_key($key);
        if (strpos($key, 'littleinka_') !== 0) {
            continue;
        }
        if (is_string($value) && strpos($value, LITTLEINKA_CT_TOKEN) === 0) {
            $id = littleinka_ct_decode_id($value, $found, $missing);
            if ($id > 0) {
                set_theme_mod($key, $id);
                $report['theme_mods'][] = $key;
            }
            continue;
        }
        if (is_bool($value) || is_int($value) || is_float($value)) {
            set_theme_mod($key, $value);
        } elseif (is_array($value)) {
            set_theme_mod($key, littleinka_ct_sanitize_deep(littleinka_ct_decode_deep($value, $found, $missing), 'sanitize_text_field'));
        } else {
            $string = littleinka_ct_decode_text((string) $value, $found, $missing);
            set_theme_mod($key, preg_match('~^https?://~i', $string) ? esc_url_raw($string) : sanitize_text_field($string));
        }
        $report['theme_mods'][] = $key;
    }

    // 5) Menu di navigazione: per nome; le voci vengono ricreate tali e quali (idempotente).
    foreach ((array) ($data['menus'] ?? array()) as $menu) {
        if (!is_array($menu)) {
            continue;
        }
        $name = littleinka_ct_sanitize($menu['name'] ?? '', 'text');
        if ($name === '') {
            continue;
        }
        $object  = wp_get_nav_menu_object($name);
        $menu_id = $object ? (int) $object->term_id : wp_create_nav_menu($name);
        if (is_wp_error($menu_id) || !$menu_id) {
            $report['warnings'][] = sprintf(
                /* translators: %s: nome del menu */
                __('Menu «%s» non creato.', 'littleinka-child-theme'),
                $name
            );
            continue;
        }
        foreach ((array) wp_get_nav_menu_items($menu_id, array('post_status' => 'any', 'update_post_term_cache' => false)) as $old) {
            wp_delete_post((int) $old->ID, true);
        }
        $created = 0;
        $skipped = 0;
        $args_by_ref = array();
        $new_by_ref  = array();
        $items = array_filter((array) ($menu['items'] ?? array()), 'is_array');
        usort($items, function ($a, $b) {
            return (int) ($a['order'] ?? 0) <=> (int) ($b['order'] ?? 0);
        });
        foreach ($items as $position => $item) {
            $args = littleinka_ct_menu_item_args($item, $position + 1, $ids, $found, $missing);
            if (!$args) {
                $skipped++;
                continue;
            }
            $new_id = wp_update_nav_menu_item($menu_id, 0, $args);
            if (is_wp_error($new_id) || !$new_id) {
                $skipped++;
                continue;
            }
            $ref = (int) ($item['ref'] ?? 0);
            if ($ref) {
                $args_by_ref[$ref] = array('id' => (int) $new_id, 'args' => $args, 'parent' => (int) ($item['parent'] ?? 0));
                $new_by_ref[$ref]  = (int) $new_id;
            }
            $created++;
        }
        foreach ($args_by_ref as $ref => $row) {
            if ($row['parent'] && isset($new_by_ref[$row['parent']])) {
                $row['args']['menu-item-parent-id'] = $new_by_ref[$row['parent']];
                wp_update_nav_menu_item($menu_id, $row['id'], $row['args']);
            }
        }
        $report['menus'][] = array('name' => $name, 'items' => $created, 'skipped' => $skipped, 'created' => !$object);
    }

    // 6) Posizioni dei menu (per nome del menu): solo quelle presenti nel file.
    if (!empty($data['locations']) && is_array($data['locations'])) {
        $locations  = (array) get_theme_mod('nav_menu_locations', array());
        $registered = get_registered_nav_menus();
        foreach ($data['locations'] as $location => $menu_name) {
            $location = sanitize_key($location);
            if ($location === '' || !isset($registered[$location])) {
                continue;
            }
            $menu_name = littleinka_ct_sanitize($menu_name, 'text');
            $object    = $menu_name !== '' ? wp_get_nav_menu_object($menu_name) : false;
            $locations[$location] = $object ? (int) $object->term_id : 0;
            $report['locations'][] = $location . ' → ' . ($object ? $menu_name : '—');
        }
        set_theme_mod('nav_menu_locations', $locations);
    }

    // 7) Immagini: trovate e mancanti (con le dimensioni dall'indice del file).
    $dims = array();
    foreach ((array) ($data['media'] ?? array()) as $entry) {
        if (is_array($entry) && !empty($entry['file'])) {
            $dims[sanitize_file_name((string) $entry['file'])] = array('width' => absint($entry['width'] ?? 0), 'height' => absint($entry['height'] ?? 0));
        }
    }
    $report['images_found'] = array_values(array_unique(array_map('sanitize_file_name', array_keys($found))));
    foreach (array_keys($missing) as $file) {
        $file = sanitize_file_name($file);
        $plain = preg_replace('/-scaled(?=\.[a-z0-9]+$)/i', '', preg_replace('/-\d+x\d+(?=\.[a-z0-9]+$)/i', '', $file));
        $info = $dims[$file] ?? ($dims[$plain] ?? array('width' => 0, 'height' => 0));
        $report['images_missing'][$plain] = array('file' => $plain, 'width' => $info['width'], 'height' => $info['height']);
    }
    $report['images_missing'] = array_values($report['images_missing']);
    sort($report['images_found']);

    // 8) Cache del tema e di LiteSpeed.
    if (function_exists('littleinka_flush_caches')) {
        littleinka_flush_caches();
    }
    do_action('litespeed_purge_all');

    return $report;
}

/**
 * Argomenti per wp_update_nav_menu_item() da una voce esportata. Null se la voce non si può
 * ricreare su questo sito (pagina o categoria assente).
 */
function littleinka_ct_menu_item_args(array $item, $position, array $ids, array &$found, array &$missing)
{
    $type   = in_array($item['type'] ?? '', array('post_type', 'taxonomy', 'custom', 'post_type_archive'), true) ? $item['type'] : 'custom';
    $object = sanitize_key((string) ($item['object'] ?? ''));
    $args   = array(
        'menu-item-title'       => littleinka_ct_sanitize($item['title'] ?? '', 'text'),
        'menu-item-type'        => $type,
        'menu-item-object'      => $object,
        'menu-item-object-id'   => 0,
        'menu-item-url'         => '',
        'menu-item-target'      => ($item['target'] ?? '') === '_blank' ? '_blank' : '',
        'menu-item-classes'     => littleinka_ct_sanitize($item['classes'] ?? '', 'text'),
        'menu-item-xfn'         => littleinka_ct_sanitize($item['xfn'] ?? '', 'text'),
        'menu-item-attr-title'  => littleinka_ct_sanitize($item['attr_title'] ?? '', 'text'),
        'menu-item-description' => littleinka_ct_sanitize($item['description'] ?? '', 'textarea'),
        'menu-item-status'      => 'publish',
        'menu-item-position'    => (int) $position,
        'menu-item-parent-id'   => 0,
    );
    $slug = sanitize_text_field((string) ($item['slug'] ?? ''));
    if ($type === 'post_type') {
        if ($object === '' || !post_type_exists($object) || $slug === '') {
            return null;
        }
        if ($object === 'page' && isset($ids[$slug])) {
            $args['menu-item-object-id'] = (int) $ids[$slug];
        } else {
            $post = littleinka_ct_find_post($slug, sanitize_title(basename($slug)), $object);
            if (!$post) {
                return null;
            }
            $args['menu-item-object-id'] = (int) $post->ID;
        }
        return $args;
    }
    if ($type === 'taxonomy') {
        if ($object === '' || !taxonomy_exists($object) || $slug === '') {
            return null;
        }
        $term = get_term_by('slug', sanitize_title($slug), $object);
        if (!$term instanceof WP_Term) {
            return null;
        }
        $args['menu-item-object-id'] = (int) $term->term_id;
        return $args;
    }
    if ($type === 'post_type_archive') {
        return ($object !== '' && post_type_exists($object)) ? $args : null;
    }
    $url = littleinka_ct_decode_text((string) ($item['url'] ?? ''), $found, $missing);
    $url = ($url !== '' && $url[0] === '#') ? '#' . sanitize_text_field(substr($url, 1)) : esc_url_raw($url);
    $args['menu-item-url'] = $url !== '' ? $url : '#';
    return $args;
}

/** Controllo delle pagine carrello e cassa di WooCommerce: devono contenere gli shortcode classici. */
function littleinka_ct_wc_pages_check()
{
    if (!function_exists('wc_get_page_id')) {
        return array();
    }
    $checks = array(
        'cart'     => array('label' => __('Carrello', 'littleinka-child-theme'), 'needles' => array('[woocommerce_cart', 'wp:woocommerce/cart')),
        'checkout' => array('label' => __('Pagamento (cassa)', 'littleinka-child-theme'), 'needles' => array('[woocommerce_checkout', 'wp:woocommerce/checkout')),
    );
    $rows = array();
    foreach ($checks as $key => $check) {
        $id   = (int) wc_get_page_id($key);
        $post = $id > 0 ? get_post($id) : null;
        $ok   = false;
        if ($post instanceof WP_Post && $post->post_status === 'publish') {
            foreach ($check['needles'] as $needle) {
                if (strpos($post->post_content, $needle) !== false) {
                    $ok = true;
                    break;
                }
            }
        }
        $rows[] = array(
            'ok'   => $ok,
            'text' => $ok
                /* translators: 1: nome della pagina, 2: slug */
                ? sprintf(__('%1$s: la pagina «%2$s» è pubblicata e contiene il modulo di WooCommerce.', 'littleinka-child-theme'), $check['label'], $post->post_name)
                /* translators: %s: nome della pagina */
                : sprintf(__('%s: la pagina di WooCommerce manca, non è pubblicata o non contiene il suo shortcode. Controlla WooCommerce → Impostazioni → Avanzate.', 'littleinka-child-theme'), $check['label']),
        );
    }
    return $rows;
}

/* -------------------------------------------------------------------------
 * Pagina in bacheca: Strumenti → Little Inka: Porta sul sito
 * ---------------------------------------------------------------------- */

add_action('admin_menu', function () {
    add_management_page(
        __('Little Inka: Porta sul sito', 'littleinka-child-theme'),
        __('Little Inka: Porta sul sito', 'littleinka-child-theme'),
        'manage_options',
        LITTLEINKA_CT_SLUG,
        'littleinka_ct_render_page'
    );
});

function littleinka_ct_render_page()
{
    if (!current_user_can('manage_options')) {
        wp_die(esc_html__('Non hai i permessi per questa pagina.', 'littleinka-child-theme'));
    }
    $step    = isset($_GET['step']) ? sanitize_key(wp_unslash($_GET['step'])) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    $pending = littleinka_ct_pending();
    $error   = get_transient('littleinka_ct_error_' . get_current_user_id());
    if ($error) {
        delete_transient('littleinka_ct_error_' . get_current_user_id());
    }
    $report = $step === 'done' ? get_option(littleinka_ct_report_key()) : null;
    if ($report) {
        // Il resoconto si legge una volta sola: non resta nel database.
        delete_option(littleinka_ct_report_key());
    }
    ?>
    <div class="wrap">
        <h1><?php esc_html_e('Little Inka: Porta sul sito', 'littleinka-child-theme'); ?></h1>

        <?php if ($error) : ?>
            <div class="notice notice-error"><p><?php echo esc_html((string) $error); ?></p></div>
        <?php endif; ?>

        <p><?php esc_html_e('Copia i contenuti di questa sede dal sito di prova al sito pubblico. Si fa in due passi: sul sito di partenza scarichi un file, sul sito di destinazione lo carichi, leggi l\'anteprima e confermi. Quello che esiste già con lo stesso nome viene aggiornato, non duplicato: puoi ripetere l\'operazione quante volte vuoi.', 'littleinka-child-theme'); ?></p>
        <p>
            <strong><?php esc_html_e('Porta:', 'littleinka-child-theme'); ?></strong>
            <?php esc_html_e('le pagine (testi, immagine in evidenza, titolo e descrizione per Google, scheda FAQ collegata), i contatti e gli orari, il logo, l\'icona e il colore del sito, le impostazioni SEO, cookie e privacy, i codici di Google, la pagina iniziale e il nome del sito, le impostazioni «Little Inka» di Aspetto → Personalizza, i menu di navigazione e le schede FAQ.', 'littleinka-child-theme'); ?>
        </p>
        <p>
            <strong><?php esc_html_e('Non porta:', 'littleinka-child-theme'); ?></strong>
            <?php esc_html_e('prodotti e categorie, ordini, clienti e utenti, zone e fasce di consegna, pagamenti, chiavi e licenze, plugin. E nemmeno i file delle immagini: le foto devono essere già caricate nella Libreria media del sito di destinazione con lo stesso nome di file, così lo strumento le riaggancia da solo. Quelle che mancano te le elenca.', 'littleinka-child-theme'); ?>
        </p>

        <?php if ($report && is_array($report)) : ?>
            <?php littleinka_ct_render_report($report); ?>
        <?php endif; ?>

        <?php if ($pending && $step === 'preview') : ?>
            <?php littleinka_ct_render_preview($pending); ?>
        <?php elseif ($pending) : ?>
            <div class="notice notice-info"><p>
                <?php esc_html_e('C\'è un file caricato in attesa di conferma.', 'littleinka-child-theme'); ?>
                <a href="<?php echo esc_url(littleinka_ct_page_url(array('step' => 'preview'))); ?>"><?php esc_html_e('Vedi l\'anteprima', 'littleinka-child-theme'); ?></a>
            </p></div>
        <?php endif; ?>

        <div class="card" style="max-width:760px;padding:20px;margin-top:24px;">
            <h2><?php esc_html_e('1. Esporta (sul sito di partenza)', 'littleinka-child-theme'); ?></h2>
            <p><?php esc_html_e('Scarica il file con i contenuti di questa sede. È un file di testo leggero: le immagini non sono incluse, viaggiano per nome.', 'littleinka-child-theme'); ?></p>
            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                <input type="hidden" name="action" value="littleinka_ct_export">
                <?php wp_nonce_field('littleinka_ct_export'); ?>
                <?php submit_button(__('Scarica i contenuti', 'littleinka-child-theme'), 'primary', 'submit', false); ?>
            </form>
        </div>

        <div class="card" style="max-width:760px;padding:20px;margin-top:24px;">
            <h2><?php esc_html_e('2. Importa (sul sito di destinazione)', 'littleinka-child-theme'); ?></h2>
            <p><?php echo esc_html(sprintf(
                /* translators: %s: dimensione massima */
                __('Scegli il file .json scaricato al passo 1 (massimo %s). Prima di scrivere qualcosa vedrai un\'anteprima di ciò che cambierà e potrai confermare o annullare.', 'littleinka-child-theme'),
                size_format(LITTLEINKA_CT_MAX_BYTES)
            )); ?></p>
            <form method="post" enctype="multipart/form-data" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                <input type="hidden" name="action" value="littleinka_ct_upload">
                <input type="hidden" name="MAX_FILE_SIZE" value="<?php echo esc_attr((string) LITTLEINKA_CT_MAX_BYTES); ?>">
                <?php wp_nonce_field('littleinka_ct_upload'); ?>
                <p><input type="file" name="littleinka_ct_file" accept="application/json,.json" required></p>
                <?php submit_button(__('Carica e mostra l\'anteprima', 'littleinka-child-theme'), 'secondary', 'submit', false); ?>
            </form>
        </div>

        <?php $wc = littleinka_ct_wc_pages_check(); ?>
        <?php if ($wc) : ?>
            <div class="card" style="max-width:760px;padding:20px;margin-top:24px;">
                <h2><?php esc_html_e('Controllo carrello e cassa', 'littleinka-child-theme'); ?></h2>
                <ul>
                    <?php foreach ($wc as $row) : ?>
                        <li><?php echo $row['ok'] ? '✔' : '✖'; ?> <?php echo esc_html($row['text']); ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>
    </div>
    <?php
}

/** Anteprima del file in attesa, con i pulsanti Conferma e Annulla. */
function littleinka_ct_render_preview(array $pending)
{
    $preview = littleinka_ct_preview($pending['data']);
    $data    = $pending['data'];
    $create  = count(array_filter($preview['pages'], function ($p) { return $p['action'] === 'create'; }));
    $update  = count($preview['pages']) - $create;
    ?>
    <div class="card" style="max-width:760px;padding:20px;margin-top:24px;border-left:4px solid #2271b1;">
        <h2><?php esc_html_e('Anteprima: cosa cambierà su questo sito', 'littleinka-child-theme'); ?></h2>
        <p>
            <?php echo esc_html(sprintf(
                /* translators: 1: nome del file, 2: sito di partenza, 3: data */
                __('File «%1$s», esportato da %2$s il %3$s.', 'littleinka-child-theme'),
                $pending['name'],
                (string) ($data['site_name'] ?? $data['source_url'] ?? ''),
                !empty($data['exported_at']) ? wp_date(get_option('date_format') . ' ' . get_option('time_format'), strtotime((string) $data['exported_at'])) : ''
            )); ?>
        </p>
        <?php foreach ($preview['warnings'] as $warning) : ?>
            <div class="notice notice-warning inline"><p><?php echo esc_html($warning); ?></p></div>
        <?php endforeach; ?>

        <h3><?php echo esc_html(sprintf(
            /* translators: 1: pagine da creare, 2: pagine da aggiornare */
            __('Pagine: %1$d da creare, %2$d da aggiornare', 'littleinka-child-theme'),
            $create,
            $update
        )); ?></h3>
        <?php if ($preview['pages']) : ?>
            <table class="widefat striped" style="margin-bottom:16px;">
                <thead><tr><th><?php esc_html_e('Pagina', 'littleinka-child-theme'); ?></th><th><?php esc_html_e('Slug', 'littleinka-child-theme'); ?></th><th><?php esc_html_e('Stato', 'littleinka-child-theme'); ?></th><th><?php esc_html_e('Azione', 'littleinka-child-theme'); ?></th></tr></thead>
                <tbody>
                <?php foreach ($preview['pages'] as $page) : ?>
                    <tr>
                        <td><?php echo esc_html($page['title']); ?></td>
                        <td><code><?php echo esc_html($page['slug']); ?></code></td>
                        <td><?php echo esc_html(littleinka_ct_status_label($page['status'])); ?></td>
                        <td><?php echo $page['action'] === 'create' ? esc_html__('Crea', 'littleinka-child-theme') : esc_html__('Aggiorna', 'littleinka-child-theme'); ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>

        <h3><?php echo esc_html(sprintf(
            /* translators: %d: numero di opzioni */
            __('Impostazioni del sito: %d da scrivere', 'littleinka-child-theme'),
            count($preview['options'])
        )); ?></h3>
        <?php if ($preview['options']) : ?>
            <p class="description"><?php echo esc_html(implode(', ', $preview['options'])); ?></p>
        <?php endif; ?>

        <h3><?php echo esc_html(sprintf(
            /* translators: %d: numero di impostazioni */
            __('Impostazioni «Little Inka» (Aspetto → Personalizza): %d', 'littleinka-child-theme'),
            $preview['theme_mods']
        )); ?></h3>

        <h3><?php esc_html_e('Menu di navigazione', 'littleinka-child-theme'); ?></h3>
        <?php if ($preview['menus']) : ?>
            <ul>
                <?php foreach ($preview['menus'] as $menu) : ?>
                    <li><?php echo esc_html(sprintf(
                        /* translators: 1: nome del menu, 2: numero di voci, 3: nuovo/esistente */
                        __('«%1$s»: %2$d voci (%3$s)', 'littleinka-child-theme'),
                        $menu['name'],
                        $menu['items'],
                        $menu['exists'] ? __('le voci attuali vengono sostituite', 'littleinka-child-theme') : __('nuovo menu', 'littleinka-child-theme')
                    )); ?></li>
                <?php endforeach; ?>
                <?php foreach ($preview['locations'] as $location => $menu_name) : ?>
                    <li><?php echo esc_html(sprintf(
                        /* translators: 1: posizione, 2: nome del menu */
                        __('Posizione «%1$s» → menu «%2$s»', 'littleinka-child-theme'),
                        $location,
                        $menu_name !== '' ? $menu_name : '—'
                    )); ?></li>
                <?php endforeach; ?>
            </ul>
        <?php else : ?>
            <p class="description"><?php esc_html_e('Nessun menu nel file.', 'littleinka-child-theme'); ?></p>
        <?php endif; ?>

        <h3><?php echo esc_html(sprintf(
            /* translators: %d: numero di schede */
            __('Schede FAQ: %d', 'littleinka-child-theme'),
            count($preview['faqs'])
        )); ?></h3>
        <?php if ($preview['faqs']) : ?>
            <ul>
                <?php foreach ($preview['faqs'] as $faq) : ?>
                    <li><?php echo esc_html($faq['title']); ?> (<code><?php echo esc_html($faq['slug']); ?></code>): <?php echo $faq['action'] === 'create' ? esc_html__('crea', 'littleinka-child-theme') : esc_html__('aggiorna', 'littleinka-child-theme'); ?></li>
                <?php endforeach; ?>
            </ul>
        <?php endif; ?>

        <h3><?php echo esc_html(sprintf(
            /* translators: 1: immagini trovate, 2: immagini mancanti */
            __('Immagini: %1$d trovate nella Libreria media, %2$d mancanti', 'littleinka-child-theme'),
            count($preview['images_found']),
            count($preview['images_missing'])
        )); ?></h3>
        <?php littleinka_ct_render_missing($preview['images_missing'], __('Puoi caricarle ora nella Libreria media (stesso nome di file) e poi confermare, oppure confermare lo stesso e rifare l\'importazione in seguito.', 'littleinka-child-theme')); ?>

        <div style="display:flex;gap:12px;align-items:center;margin-top:16px;">
            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                <input type="hidden" name="action" value="littleinka_ct_import">
                <input type="hidden" name="littleinka_ct_token" value="<?php echo esc_attr($pending['token']); ?>">
                <?php wp_nonce_field('littleinka_ct_import'); ?>
                <?php submit_button(__('Conferma e importa', 'littleinka-child-theme'), 'primary', 'submit', false); ?>
            </form>
            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                <input type="hidden" name="action" value="littleinka_ct_cancel">
                <?php wp_nonce_field('littleinka_ct_cancel'); ?>
                <?php submit_button(__('Annulla', 'littleinka-child-theme'), 'secondary', 'submit', false); ?>
            </form>
        </div>
    </div>
    <?php
}

/** Resoconto dell'ultima importazione. */
function littleinka_ct_render_report(array $report)
{
    ?>
    <div class="card" style="max-width:760px;padding:20px;margin-top:24px;border-left:4px solid #00a32a;">
        <h2><?php esc_html_e('Importazione completata', 'littleinka-child-theme'); ?></h2>
        <?php if (!empty($report['file'])) : ?>
            <p class="description"><?php echo esc_html(sprintf(
                /* translators: 1: nome del file, 2: data e ora */
                __('File «%1$s», importato il %2$s.', 'littleinka-child-theme'),
                (string) $report['file'],
                wp_date(get_option('date_format') . ' ' . get_option('time_format'), (int) ($report['time'] ?? time()))
            )); ?></p>
        <?php endif; ?>
        <ul>
            <li><?php echo esc_html(sprintf(
                /* translators: 1: create, 2: aggiornate */
                __('Pagine: %1$d create, %2$d aggiornate.', 'littleinka-child-theme'),
                count($report['pages_created']),
                count($report['pages_updated'])
            )); ?>
                <?php if ($report['pages_created']) : ?><br><span class="description"><?php esc_html_e('Create:', 'littleinka-child-theme'); ?> <?php echo esc_html(implode(', ', $report['pages_created'])); ?></span><?php endif; ?>
                <?php if ($report['pages_updated']) : ?><br><span class="description"><?php esc_html_e('Aggiornate:', 'littleinka-child-theme'); ?> <?php echo esc_html(implode(', ', $report['pages_updated'])); ?></span><?php endif; ?>
                <?php if ($report['pages_skipped']) : ?><br><span class="description"><?php esc_html_e('Non salvate:', 'littleinka-child-theme'); ?> <?php echo esc_html(implode(', ', $report['pages_skipped'])); ?></span><?php endif; ?>
            </li>
            <li><?php echo esc_html(sprintf(
                /* translators: %d: numero di opzioni */
                __('Impostazioni del sito scritte: %d.', 'littleinka-child-theme'),
                count($report['options'])
            )); ?>
                <?php if ($report['options']) : ?><br><span class="description"><?php echo esc_html(implode(', ', $report['options'])); ?></span><?php endif; ?>
            </li>
            <li><?php echo esc_html(sprintf(
                /* translators: %d: numero */
                __('Impostazioni «Little Inka» scritte: %d.', 'littleinka-child-theme'),
                count($report['theme_mods'])
            )); ?></li>
            <li><?php esc_html_e('Menu:', 'littleinka-child-theme'); ?>
                <?php if ($report['menus']) : ?>
                    <?php foreach ($report['menus'] as $menu) : ?>
                        <br><span class="description"><?php echo esc_html(sprintf(
                            /* translators: 1: nome, 2: voci, 3: voci saltate */
                            __('«%1$s»: %2$d voci%3$s', 'littleinka-child-theme'),
                            $menu['name'],
                            $menu['items'],
                            $menu['skipped'] ? sprintf(
                                /* translators: %d: voci saltate */
                                __(', %d saltate perché la pagina o la categoria non esiste qui', 'littleinka-child-theme'),
                                $menu['skipped']
                            ) : ''
                        )); ?></span>
                    <?php endforeach; ?>
                    <?php foreach ($report['locations'] as $line) : ?>
                        <br><span class="description"><?php echo esc_html($line); ?></span>
                    <?php endforeach; ?>
                <?php else : ?>
                    <?php esc_html_e('nessuno.', 'littleinka-child-theme'); ?>
                <?php endif; ?>
            </li>
            <li><?php echo esc_html(sprintf(
                /* translators: 1: create, 2: aggiornate */
                __('Schede FAQ: %1$d create, %2$d aggiornate.', 'littleinka-child-theme'),
                count($report['faq_created']),
                count($report['faq_updated'])
            )); ?></li>
            <li><?php echo esc_html(sprintf(
                /* translators: 1: riagganciate, 2: mancanti */
                __('Immagini: %1$d riagganciate, %2$d mancanti.', 'littleinka-child-theme'),
                count($report['images_found']),
                count($report['images_missing'])
            )); ?></li>
        </ul>
        <?php foreach ((array) $report['warnings'] as $warning) : ?>
            <div class="notice notice-warning inline"><p><?php echo esc_html($warning); ?></p></div>
        <?php endforeach; ?>
        <?php littleinka_ct_render_missing((array) $report['images_missing'], __('Caricale nella Libreria media con lo stesso nome di file e rifai l\'importazione dello stesso file: le pagine si riaggancieranno da sole.', 'littleinka-child-theme')); ?>
    </div>
    <?php
}

/** Elenco delle immagini mancanti con le dimensioni, copiabile. */
function littleinka_ct_render_missing(array $missing, $hint)
{
    if (!$missing) {
        return;
    }
    $lines = array();
    foreach ($missing as $row) {
        $size    = (!empty($row['width']) && !empty($row['height'])) ? sprintf(' (%d×%d px)', (int) $row['width'], (int) $row['height']) : '';
        $lines[] = $row['file'] . $size;
    }
    ?>
    <div style="border-left:4px solid #d63638;padding:8px 12px;margin:8px 0;background:#fcf0f1;">
        <p><strong><?php esc_html_e('Immagini mancanti su questo sito', 'littleinka-child-theme'); ?></strong><br><?php echo esc_html($hint); ?></p>
        <textarea rows="<?php echo esc_attr((string) min(12, max(3, count($lines)))); ?>" style="width:100%;font-family:monospace;font-size:12px;" onclick="this.select();" readonly><?php echo esc_textarea(implode("\n", $lines)); ?></textarea>
    </div>
    <?php
}

/** Etichetta in italiano di uno stato. */
function littleinka_ct_status_label($status)
{
    $labels = array(
        'publish' => __('Pubblicata', 'littleinka-child-theme'),
        'draft'   => __('Bozza', 'littleinka-child-theme'),
        'private' => __('Privata', 'littleinka-child-theme'),
        'pending' => __('In attesa di revisione', 'littleinka-child-theme'),
    );
    return $labels[$status] ?? (string) $status;
}
