<?php
/**
 * Little Inka: «Crea la tua poké».
 *
 * I dati vengono da WooCommerce (le misure = prodotti della categoria crea-la-tua-poke) e da
 * WooCommerce Product Add-ons (gli ingredienti = gruppo globale della categoria); la pagina la fa lo
 * shortcode [make_your_own_poke] del plugin Make your own Pokè, che il tema veste con assets/css/poke.css.
 * Gli «inclusi nel prezzo» si leggono con la stessa regola del plugin (brtw_included_count: eccezioni
 * dalle sue impostazioni, altrimenti il secondo numero della descrizione del gruppo); il tema non
 * scrive numeri né nomi di gruppo.
 */
defined('ABSPATH') || exit;

/** Slug della categoria delle misure: la prima configurata nel plugin, altrimenti quella standard. */
function littleinka_poke_category()
{
    if (function_exists('brtw_configurator_categories')) {
        $slugs = brtw_configurator_categories();
        if ($slugs) {
            return (string) $slugs[0];
        }
    }
    return 'crea-la-tua-poke';
}

/**
 * Le misure della poké: `[['product' => WC_Product, 'price' => float], …]` in ordine di prezzo crescente.
 * Gli ID stanno nel transient littleinka_poke_sizes (svuotato da littleinka_flush_caches()); i prodotti si
 * ricaricano a ogni richiesta, così prezzo e disponibilità sono sempre quelli veri.
 */
function littleinka_poke_sizes()
{
    if (!function_exists('wc_get_products')) {
        return array();
    }
    $ids = get_transient('littleinka_poke_sizes');
    if (!is_array($ids)) {
        $ids = wc_get_products(array(
            'status'   => 'publish',
            'limit'    => 20,
            'category' => array(littleinka_poke_category()),
            'orderby'  => 'meta_value_num',
            'meta_key' => '_price', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
            'order'    => 'ASC',
            'return'   => 'ids',
        ));
        $ids = array_map('intval', (array) $ids);
        set_transient('littleinka_poke_sizes', $ids, 12 * HOUR_IN_SECONDS);
    }
    $sizes = array();
    foreach ($ids as $id) {
        $product = wc_get_product($id);
        if ($product instanceof WC_Product && $product->is_purchasable() && $product->get_status() === 'publish') {
            $sizes[] = array('product' => $product, 'price' => (float) $product->get_price());
        }
    }
    usort($sizes, function ($a, $b) {
        return $a['price'] <=> $b['price'];
    });
    return $sizes;
}

/**
 * Gruppi di ingredienti di una misura, con la regola del plugin:
 * `[['name' => 'Base', 'included' => 2, 'extra' => 0.5], …]`. Vuoto senza Product Add-ons.
 */
function littleinka_poke_groups_for($product_id)
{
    $product_id = (int) $product_id;
    if (!$product_id || !class_exists('WC_Product_Addons_Helper')) {
        return array();
    }
    $rows = array();
    if (function_exists('brtw_product_addon_groups')) {
        foreach (brtw_product_addon_groups($product_id) as $group) {
            $rows[] = array(
                'name'     => (string) $group['name'],
                'included' => (int) $group['brtw_included'],
                'extra'    => (float) $group['brtw_extra'],
            );
        }
        return $rows;
    }
    // Senza il plugin: stessa lettura, fatta qui.
    foreach ((array) WC_Product_Addons_Helper::get_product_addons($product_id) as $group) {
        if (!is_array($group) || empty($group['name']) || empty($group['options']) || !is_array($group['options'])) {
            continue;
        }
        if (!in_array($group['type'] ?? '', array('checkbox', 'multiple_choice'), true)) {
            continue;
        }
        $first = reset($group['options']);
        $rows[] = array(
            'name'     => (string) $group['name'],
            'included' => littleinka_poke_included_from_description($group['description'] ?? ''),
            'extra'    => isset($first['price']) && $first['price'] !== '' ? (float) $first['price'] : 0.0,
        );
    }
    return $rows;
}

/** Il secondo numero della descrizione («Minimo 1, dopo 2 si paga un extra» → 2); usato solo se il plugin manca. */
function littleinka_poke_included_from_description($description)
{
    if (!preg_match_all('/\d+/', wp_strip_all_tags((string) $description), $m) || empty($m[0])) {
        return 0;
    }
    return isset($m[0][1]) ? (int) $m[0][1] : (int) $m[0][0];
}

/**
 * Gli ingredienti inclusi nel prezzo: `[['name' => 'Base', 'included' => 2, 'extra' => 0.5], …]`.
 * Senza $product_id: la regola condivisa dalla maggior parte delle misure (M, L e XL hanno lo stesso gruppo;
 * la Kids ha il suo, che si legge con littleinka_poke_included($id) o si riassume in littleinka_poke_note()).
 */
function littleinka_poke_included($product_id = 0)
{
    if ($product_id) {
        return littleinka_poke_groups_for($product_id);
    }
    $sizes = littleinka_poke_sizes();
    if (!$sizes) {
        return array();
    }
    $signatures = array();
    foreach ($sizes as $size) {
        $rows = littleinka_poke_groups_for($size['product']->get_id());
        if (!$rows) {
            continue;
        }
        $key = md5(wp_json_encode($rows));
        if (!isset($signatures[$key])) {
            $signatures[$key] = array('rows' => $rows, 'count' => 0);
        }
        $signatures[$key]['count']++;
    }
    if (!$signatures) {
        return array();
    }
    uasort($signatures, function ($a, $b) {
        return $b['count'] <=> $a['count'];
    });
    $first = reset($signatures);
    return $first['rows'];
}

/** Minuscolo sicuro anche senza mbstring. */
function littleinka_poke_lower($text)
{
    $text = trim((string) $text);
    return function_exists('mb_strtolower') ? mb_strtolower($text, 'UTF-8') : strtolower($text);
}

/** «2 incluse» / «1 incluso»: la stessa etichetta del plugin, se c'è. */
function littleinka_poke_included_label($count, $group_name)
{
    if (function_exists('brtw_included_label')) {
        return brtw_included_label($count, $group_name);
    }
    $count = (int) $count;
    $last = function_exists('mb_substr') ? mb_substr(littleinka_poke_lower($group_name), -1, 1, 'UTF-8') : substr(littleinka_poke_lower($group_name), -1);
    $feminine = in_array($last, array('e', 'a'), true);
    if ($count === 1) {
        return $feminine ? __('1 inclusa', 'littleinka-child-theme') : __('1 incluso', 'littleinka-child-theme');
    }
    /* translators: %d: numero */
    return sprintf($feminine ? __('%d incluse', 'littleinka-child-theme') : __('%d inclusi', 'littleinka-child-theme'), $count);
}

/** Valore della colonna «Inclusi nel prezzo»: «2 incluse», «tutte» se gratis, «a pagamento» se nessuno è incluso. */
function littleinka_poke_included_value(array $row)
{
    if ($row['extra'] <= 0) {
        return littleinka_t(__('tutte', 'littleinka-child-theme'), 'poke:tutte');
    }
    if ($row['included'] <= 0) {
        return littleinka_t(__('a pagamento', 'littleinka-child-theme'), 'poke:a_pagamento');
    }
    return littleinka_poke_included_label($row['included'], $row['name']);
}

/**
 * La nota sotto le due colonne: «Oltre le porzioni incluse: proteina CHF 4.00, condimento CHF 2.50, topping CHF 0.50.
 * Nella Poké Kids sono inclusi 1 proteina e 3 condimenti.» Tutto dai dati; vuota se non c'è nulla da dire.
 */
function littleinka_poke_note()
{
    $main = littleinka_poke_included();
    if (!$main) {
        return '';
    }
    $parts = array();
    foreach ($main as $row) {
        if ($row['extra'] > 0 && $row['included'] > 0) {
            $parts[] = littleinka_t(littleinka_poke_lower($row['name']), 'poke:gruppo:' . sanitize_title($row['name'])) . ' ' . littleinka_price($row['extra']);
        }
    }
    $sentences = array();
    if ($parts) {
        /* translators: %s: elenco «proteine CHF 4.00, condimenti CHF 2.50» */
        $sentences[] = sprintf(littleinka_t(__('Oltre le porzioni incluse: %s.', 'littleinka-child-theme'), 'poke:nota_extra'), implode(', ', $parts));
    }
    // Misure con una regola diversa dalla principale (es. la Kids).
    $main_by_name = array();
    foreach ($main as $row) {
        $main_by_name[$row['name']] = $row['included'];
    }
    foreach (littleinka_poke_sizes() as $size) {
        $rows = littleinka_poke_groups_for($size['product']->get_id());
        $diff = array();
        foreach ($rows as $row) {
            if ($row['extra'] > 0 && isset($main_by_name[$row['name']]) && $main_by_name[$row['name']] !== $row['included']) {
                $diff[] = littleinka_t(littleinka_poke_lower($row['name']), 'poke:gruppo:' . sanitize_title($row['name'])) . ' ' . littleinka_poke_included_label($row['included'], $row['name']);
            }
        }
        if ($diff) {
            /* translators: 1: nome della misura, 2: elenco «proteine 1 inclusa, condimenti 3 inclusi» */
            $sentences[] = sprintf(littleinka_t(__('Nella %1$s: %2$s.', 'littleinka-child-theme'), 'poke:nota_misura'), $size['product']->get_name(), implode(', ', $diff));
        }
    }
    return implode(' ', $sentences);
}

/**
 * Le due colonne della home: «Misure» (nome, prezzo) e «Inclusi nel prezzo» (gruppo, n inclusi), più la nota.
 * Vuoto se non ci sono misure (la home allora non mostra la sezione).
 */
function littleinka_poke_summary_rows()
{
    $sizes = littleinka_poke_sizes();
    if (!$sizes) {
        return '';
    }
    $included = littleinka_poke_included();
    ob_start();
    ?>
    <div class="li-poke-groups">
        <div class="li-poke-groups__col">
            <p class="li-label"><?php echo esc_html(littleinka_t(__('Misure', 'littleinka-child-theme'), 'poke:misure')); ?></p>
            <ul class="li-rows li-rows--spec">
                <?php foreach ($sizes as $size) : ?>
                    <li>
                        <span class="li-rows__name"><?php echo esc_html($size['product']->get_name()); ?></span>
                        <span class="li-rows__value"><?php echo esc_html(littleinka_price($size['price'])); ?></span>
                    </li>
                <?php endforeach; ?>
            </ul>
        </div>
        <?php if ($included) : ?>
            <div class="li-poke-groups__col">
                <p class="li-label"><?php echo esc_html(littleinka_t(__('Inclusi nel prezzo', 'littleinka-child-theme'), 'poke:inclusi')); ?></p>
                <ul class="li-rows li-rows--spec">
                    <?php foreach ($included as $row) : ?>
                        <li>
                            <span class="li-rows__name"><?php echo esc_html(littleinka_t($row['name'], 'poke:gruppo:' . sanitize_title($row['name']))); ?></span>
                            <span class="li-rows__value"><?php echo esc_html(littleinka_poke_included_value($row)); ?></span>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>
    </div>
    <?php $note = littleinka_poke_note(); ?>
    <?php if ($note !== '') : ?>
        <p class="li-poke-note"><?php echo esc_html($note); ?></p>
    <?php endif; ?>
    <?php
    return (string) ob_get_clean();
}

/**
 * poke.css solo dove serve: la pagina con [make_your_own_poke] e la home (sezione «Crea la tua poké»).
 * Dopo gli stili del plugin, così li sovrascrive.
 */
add_action('wp_enqueue_scripts', function () {
    $needed = is_front_page();
    if (!$needed && is_singular()) {
        $post = get_post();
        $needed = $post instanceof WP_Post && has_shortcode((string) $post->post_content, 'make_your_own_poke');
    }
    if ($needed && function_exists('littleinka_enqueue_module_css')) {
        littleinka_enqueue_module_css('poke');
        if (isset(wp_styles()->registered['littleinka-poke']) && wp_style_is('brtw-utilities-base', 'enqueued')) {
            wp_styles()->registered['littleinka-poke']->deps[] = 'brtw-utilities-base';
        }
    }
}, 30);

/** Le impostazioni del plugin (categorie, inclusi) cambiano le misure: si svuota la cache del tema. */
add_action('update_option_brtw_settings', 'littleinka_flush_caches');

/** Il bottone del configuratore con le classi del tema (filtro del plugin). */
add_filter('brtw_submit_button_class', function () {
    return 'brtw-submit li-btn li-btn--primary';
});

/**
 * Icona accanto al titolo di ogni passaggio di «Crea la tua poké» (misura, base, proteine, condimenti, topping, salse).
 * Il plugin non ha un filtro sui titoli: si lavora sull'HTML dello shortcode. Il gruppo si riconosce dal nome,
 * anche tradotto; un gruppo che il tema non riconosce resta senza icona.
 */
function littleinka_poke_step_icon($name)
{
    $name = remove_accents(strtolower(wp_strip_all_tags((string) $name)));
    $map = array(
        'poke-base'       => '/\b(base|riso|rice|reis|riz)/',
        'poke-proteine'   => '/(protein|pesce|fish|fisch|poisson)/',
        'poke-condimenti' => '/(condiment|verdur|vegetab|gemuse|legume|garnitur)/',
        'poke-topping'    => '/(topping|croccant|crunch)/',
        'poke-salse'      => '/(sals|sauce|sosse)/',
        'poke-misura'     => '/(misura|size|grosse|taille)/',
    );
    foreach ($map as $icon => $re) {
        if (preg_match($re, $name)) {
            return $icon;
        }
    }
    return '';
}

add_filter('do_shortcode_tag', function ($output, $tag) {
    if ($tag !== 'make_your_own_poke' || !function_exists('littleinka_icona') || !is_string($output)) {
        return $output;
    }
    return preg_replace_callback(
        '#(<(h3|legend) class="(brtw-addons__title|brtw-sizes__title)"[^>]*>)(\s*)([^<]*)#',
        function ($m) {
            $icon = littleinka_poke_step_icon($m[5]);
            return $icon === '' ? $m[0] : $m[1] . $m[4] . littleinka_icona($icon, array('classe' => 'li-step-icon')) . $m[5];
        },
        $output
    );
}, 10, 2);

/**
 * La misura scelta all'apertura di «Crea la tua poké» è la M (la più ordinata), non la prima della lista.
 * Il plugin seleziona sempre la prima: dopo il suo avvio si sceglie la M come farebbe il cliente (evento change),
 * così foto, ingredienti e totale si aggiornano con la logica del plugin. Senza una misura «M» resta la prima.
 */
add_filter('do_shortcode_tag', function ($output, $tag) {
    if ($tag === 'make_your_own_poke' && wp_script_is('brtw-frontend', 'enqueued')) {
        static $done = false;
        if (!$done) {
            $done = true;
            wp_add_inline_script('brtw-frontend', <<<'JS'
document.addEventListener('DOMContentLoaded', function () {
  document.querySelectorAll('[data-brtw-configurator]').forEach(function (conf) {
    var labels = conf.querySelectorAll('.brtw-size');
    for (var i = 0; i < labels.length; i++) {
      var name = labels[i].querySelector('.brtw-size__name');
      var input = labels[i].querySelector('.brtw-size__input');
      if (name && input && /(^|\s)M$/i.test(name.textContent.trim())) {
        if (!input.checked) {
          input.checked = true;
          input.dispatchEvent(new Event('change', { bubbles: true }));
        }
        return;
      }
    }
  });
});
JS
            , 'after');
        }
    }
    return $output;
}, 20, 2);
