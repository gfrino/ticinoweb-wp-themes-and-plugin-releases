<?php
/**
 * Little Inka: «Controllo della sede» in bacheca.
 *
 * Quando una sede passa da Hello Elementor a questo tema restano dei pezzi da sistemare che il tema da solo non
 * vede: menu non assegnati (le assegnazioni valgono per tema), nessuna pagina con [littleinka_menu] (home vuota),
 * Elementor ancora attivo (copre la home e le pagine con i suoi modelli), pagine fatte con Elementor che senza
 * Elementor mostrano codice o shortcode grezzi, contatti del CMS vuoti. Un riquadro li elenca, ognuno con il
 * link per sistemarlo; due si sistemano con un clic (pagina Menu, modello delle pagine). Sparisce quando è tutto a posto.
 *
 * Solo per chi può cambiare tema, solo in Bacheca, Aspetto (temi, menu), elenco Pagine e ticinoWEB CMS.
 */
defined('ABSPATH') || exit;

const LITTLEINKA_SETUP_ACTION = 'littleinka_setup_fix';

/** Pagine pubblicate o in bozza fatte con Elementor (modello di Elementor o contenuto con il suo markup). */
function littleinka_setup_elementor_pages()
{
    global $wpdb;
    $rows = $wpdb->get_results(
        "SELECT p.ID, p.post_title, p.post_name, pm.meta_value AS tpl,
                (p.post_content LIKE '%[product\\_table%') AS product_table,
                (p.post_content LIKE '%/*! elementor%' OR p.post_content LIKE '%elementor-widget%' OR p.post_content LIKE '%elementor-element%') AS markup
         FROM {$wpdb->posts} p
         LEFT JOIN {$wpdb->postmeta} pm ON pm.post_id = p.ID AND pm.meta_key = '_wp_page_template'
         WHERE p.post_type = 'page' AND p.post_status IN ('publish', 'draft', 'private')
           AND (pm.meta_value LIKE 'elementor%'
                OR p.post_content LIKE '%[product\\_table%'
                OR p.post_content LIKE '%/*! elementor%'
                OR p.post_content LIKE '%elementor-widget%'
                OR p.post_content LIKE '%elementor-element%')
         ORDER BY p.menu_order ASC, p.post_title ASC
         LIMIT 30"
    );
    return is_array($rows) ? $rows : array();
}

/** Shortcode da mettere nelle pagine che il tema riconosce (pagine di WooCommerce e Crea la tua poké). */
function littleinka_setup_suggested_shortcode($page_id, $slug)
{
    if (function_exists('wc_get_page_id')) {
        foreach (array('cart' => '[woocommerce_cart]', 'checkout' => '[woocommerce_checkout]', 'myaccount' => '[woocommerce_my_account]') as $key => $code) {
            if ((int) wc_get_page_id($key) === (int) $page_id) {
                return $code;
            }
        }
    }
    if (strpos((string) $slug, 'poke') !== false && shortcode_exists('make_your_own_poke')) {
        return '[make_your_own_poke]';
    }
    if (strpos((string) $slug, 'contatt') === 0) {
        return '[littleinka_contatti]';
    }
    return '';
}

/** La pagina da trasformare in «Menu»: quella con slug o titolo «Menu», se c'è. */
function littleinka_setup_menu_candidate()
{
    foreach (array('menu', 'menu-2') as $slug) {
        $page = get_page_by_path($slug, OBJECT, 'page');
        if ($page && $page->post_status !== 'trash') {
            return $page;
        }
    }
    $found = get_posts(array(
        'post_type'      => 'page',
        'post_status'    => array('publish', 'draft', 'private'),
        'title'          => 'Menu',
        'posts_per_page' => 1,
        'no_found_rows'  => true,
    ));
    return $found ? $found[0] : null;
}

/**
 * I problemi della sede: [ 'id', 'text', 'url' => link per sistemarlo, 'label', 'fix' => azione con un clic, 'fix_label', 'items' => [html] ].
 */
function littleinka_setup_issues()
{
    $issues = array();
    $portal = littleinka_is_portal();

    if (defined('ELEMENTOR_VERSION') || defined('ELEMENTOR_PRO_VERSION')) {
        $issues[] = array(
            'id'    => 'elementor',
            'text'  => __('Elementor è ancora attivo. Il tema non lo usa: con Elementor attivo la home e le pagine fatte con Elementor mostrano i vecchi modelli al posto di quelli del tema.', 'littleinka-child-theme'),
            'url'   => admin_url('plugins.php?plugin_status=active&s=elementor'),
            'label' => __('Disattiva Elementor ed Elementor Pro', 'littleinka-child-theme'),
        );
    }

    if (!$portal && !littleinka_page_with_shortcode('littleinka_menu')) {
        $candidate = littleinka_setup_menu_candidate();
        $issues[] = array(
            'id'        => 'menu_page',
            'text'      => $candidate
                ? sprintf(
                    /* translators: %s: titolo della pagina */
                    __('Manca la pagina con il menu dei prodotti, per questo la home è vuota. Con un clic la pagina «%s» diventa il menu del tema (il contenuto di adesso resta nelle revisioni).', 'littleinka-child-theme'),
                    get_the_title($candidate)
                )
                : __('Manca la pagina con il menu dei prodotti, per questo la home è vuota. Con un clic si crea la pagina «Menu».', 'littleinka-child-theme'),
            'fix'       => 'menu_page',
            'fix_label' => $candidate ? __('Usa il menu del tema', 'littleinka-child-theme') : __('Crea la pagina Menu', 'littleinka-child-theme'),
        );
    }

    // Sulle sedi la home è front-page.php e il contenuto della pagina iniziale non si vede: non va riscritta.
    $front = $portal ? 0 : (int) get_option('page_on_front');
    $pages = array_values(array_filter(littleinka_setup_elementor_pages(), function ($row) use ($front) {
        return (int) $row->ID !== $front || strpos((string) $row->tpl, 'elementor') === 0;
    }));
    if ($pages) {
        $items = array();
        $with_template = false;
        foreach ($pages as $row) {
            $with_template = $with_template || strpos((string) $row->tpl, 'elementor') === 0;
            $code = littleinka_setup_suggested_shortcode($row->ID, $row->post_name);
            $title = $row->post_title !== '' ? $row->post_title : '#' . (int) $row->ID;
            $line = '<a href="' . esc_url(get_edit_post_link((int) $row->ID)) . '">' . esc_html($title) . '</a>';
            if ($code !== '') {
                /* translators: %s: shortcode */
                $line .= ' — ' . sprintf(esc_html__('contenuto da mettere: %s', 'littleinka-child-theme'), '<code>' . esc_html($code) . '</code>');
            } elseif ($row->product_table) {
                $line .= ' — ' . esc_html__('usa la tabella prodotti di Elementor: il menu ora è la home', 'littleinka-child-theme');
            }
            $items[] = $line;
        }
        $issue = array(
            'id'    => 'elementor_pages',
            'text'  => __('Queste pagine sono ancora fatte con Elementor: senza Elementor mostrano codice o testo grezzo. Riscrivile come testo normale o con lo shortcode indicato.', 'littleinka-child-theme'),
            'items' => $items,
        );
        if ($with_template) {
            $issue['text'] .= ' ' . __('Prima rimetti il modello standard, altrimenti WordPress non le lascia salvare.', 'littleinka-child-theme');
            $issue['fix'] = 'page_templates';
            $issue['fix_label'] = __('Rimetti il modello standard', 'littleinka-child-theme');
        }
        $issues[] = $issue;
    }

    $locations = get_nav_menu_locations();
    $missing = array();
    foreach (get_registered_nav_menus() as $location => $label) {
        if (empty($locations[$location]) || !wp_get_nav_menu_object((int) $locations[$location])) {
            $missing[] = $label;
        }
    }
    if ($missing) {
        $issues[] = array(
            'id'    => 'menus',
            'text'  => sprintf(
                /* translators: %s: elenco delle posizioni dei menu */
                __('Queste posizioni non hanno un menu, per questo l\'intestazione o il piè di pagina restano vuoti: %s. Le assegnazioni dei menu valgono per un solo tema: vanno rifatte dopo il cambio di tema.', 'littleinka-child-theme'),
                implode(', ', $missing)
            ),
            'url'   => admin_url('nav-menus.php?action=locations'),
            'label' => __('Assegna i menu', 'littleinka-child-theme'),
        );
    }

    $contacts = array(
        'ticinoweb_contact_address'       => __('indirizzo', 'littleinka-child-theme'),
        'ticinoweb_contact_phone'         => __('telefono', 'littleinka-child-theme'),
        'ticinoweb_contact_email'         => __('e-mail', 'littleinka-child-theme'),
        'ticinoweb_contact_opening_hours' => __('orari', 'littleinka-child-theme'),
    );
    $empty = array();
    foreach ($contacts as $option => $label) {
        $value = get_option($option, '');
        if ((is_array($value) && !$value) || (!is_array($value) && trim((string) $value) === '')) {
            $empty[] = $label;
        }
    }
    if ($empty) {
        $issues[] = array(
            'id'    => 'contacts',
            'text'  => sprintf(
                /* translators: %s: elenco dei dati mancanti */
                __('Mancano dei contatti della sede: %s. Senza, la pagina Contatti, il piè di pagina e «Aperto adesso» restano incompleti.', 'littleinka-child-theme'),
                implode(', ', $empty)
            ),
            'url'   => admin_url('admin.php?page=ticinoweb-cms#contatti'),
            'label' => __('Compila i contatti', 'littleinka-child-theme'),
        );
    }

    return $issues;
}

/** Schermate dove compare il riquadro. */
function littleinka_setup_screen_ok()
{
    $screen = function_exists('get_current_screen') ? get_current_screen() : null;
    if (!$screen) {
        return false;
    }
    return in_array($screen->base, array('dashboard', 'themes', 'nav-menus'), true)
        || ($screen->base === 'edit' && $screen->post_type === 'page')
        || strpos((string) $screen->id, 'ticinoweb-cms') !== false;
}

add_action('admin_notices', function () {
    if (!current_user_can('switch_themes') || !littleinka_setup_screen_ok()) {
        return;
    }
    $done = isset($_GET['littleinka_setup']) ? sanitize_key(wp_unslash($_GET['littleinka_setup'])) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- solo messaggio di conferma
    if ($done === 'ok') {
        echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__('Little Inka: sistemato.', 'littleinka-child-theme') . '</p></div>';
    }
    $issues = littleinka_setup_issues();
    if (!$issues) {
        return;
    }
    // «inline»: il pannello «Avvisi dei plugin» del parent non lo nasconde (è un avviso del tema, non di un plugin).
    echo '<div class="notice notice-warning inline littleinka-setup"><p><strong>' . esc_html__('Little Inka: da sistemare su questa sede', 'littleinka-child-theme') . '</strong></p><ol>';
    foreach ($issues as $issue) {
        echo '<li><p>' . esc_html($issue['text']) . '</p>';
        if (!empty($issue['items'])) {
            echo '<ul style="list-style:disc;margin-left:1.5em">';
            foreach ($issue['items'] as $item) {
                echo '<li>' . wp_kses($item, array('a' => array('href' => array()), 'code' => array())) . '</li>';
            }
            echo '</ul>';
        }
        echo '<p>';
        if (!empty($issue['fix'])) {
            echo '<a class="button button-primary" href="' . esc_url(wp_nonce_url(admin_url('admin-post.php?action=' . LITTLEINKA_SETUP_ACTION . '&fix=' . $issue['fix']), LITTLEINKA_SETUP_ACTION . '_' . $issue['fix'])) . '">' . esc_html($issue['fix_label']) . '</a> ';
        }
        if (!empty($issue['url'])) {
            echo '<a class="button" href="' . esc_url($issue['url']) . '">' . esc_html($issue['label']) . '</a>';
        }
        echo '</p></li>';
    }
    echo '</ol></div>';
});

/** Le due correzioni con un clic: pagina Menu e modello standard delle pagine fatte con Elementor. */
add_action('admin_post_' . LITTLEINKA_SETUP_ACTION, function () {
    $fix = isset($_GET['fix']) ? sanitize_key(wp_unslash($_GET['fix'])) : '';
    if (!current_user_can('switch_themes') || !current_user_can('edit_pages')) {
        wp_die(esc_html__('Non hai i permessi per farlo.', 'littleinka-child-theme'), '', array('response' => 403));
    }
    check_admin_referer(LITTLEINKA_SETUP_ACTION . '_' . $fix);

    if ($fix === 'menu_page' && !littleinka_page_with_shortcode('littleinka_menu')) {
        $page = littleinka_setup_menu_candidate();
        if ($page) {
            // Prima il modello: con un modello di Elementor non più valido wp_update_post rifiuta la pagina.
            update_post_meta($page->ID, '_wp_page_template', 'default');
            delete_post_meta($page->ID, '_elementor_edit_mode');
            wp_update_post(array(
                'ID'           => $page->ID,
                'post_content' => '[littleinka_menu]',
                'post_name'    => 'menu',
                'post_status'  => 'publish',
            ));
        } else {
            wp_insert_post(array(
                'post_type'    => 'page',
                'post_title'   => __('Menu', 'littleinka-child-theme'),
                'post_name'    => 'menu',
                'post_content' => '[littleinka_menu]',
                'post_status'  => 'publish',
            ));
        }
        delete_transient('littleinka_page_littleinka_menu');
    } elseif ($fix === 'page_templates') {
        foreach (littleinka_setup_elementor_pages() as $row) {
            if (strpos((string) $row->tpl, 'elementor') === 0 && current_user_can('edit_post', (int) $row->ID)) {
                update_post_meta((int) $row->ID, '_wp_page_template', 'default');
            }
        }
    }
    if (function_exists('littleinka_flush_caches')) {
        littleinka_flush_caches();
    }
    $back = wp_get_referer() ? wp_get_referer() : admin_url();
    wp_safe_redirect(add_query_arg('littleinka_setup', 'ok', remove_query_arg('littleinka_setup', $back)));
    exit;
});
