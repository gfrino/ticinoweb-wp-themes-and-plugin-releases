<?php
/**
 * Cassa: «Consegna o ritiro?» del plugin WooDelivery (CodeRockz) con tre scelte invece di due.
 *  - Consegna a domicilio  → il plugin come prima (data e orario di consegna);
 *  - Ritiro in sede        → data e orario di ritiro, senza il punto di ritiro;
 *  - Ritiro da Partner/Scuole/Ospedale → data e punto di ritiro (Ospedale, Liceo, CPC…), senza orario:
 *    l'orario è quello fisso del punto, scritto nel suo nome nelle impostazioni del plugin.
 * Per il plugin la terza scelta è un normale «ritiro» (valore pickup) con il punto di ritiro: il tema aggiunge
 * solo la scelta visibile (assets/js/delivery.js), toglie l'orario obbligatorio per quegli ordini e rende
 * obbligatorio il punto. Il plugin non si tocca; i punti si gestiscono nelle sue impostazioni («Pickup Location»).
 */
defined('ABSPATH') || exit;

/** Il plugin WooDelivery è attivo e ha i punti di ritiro (Partner/Scuole/Ospedale) accesi? */
function littleinka_delivery_partner_enabled()
{
    if (!function_exists('WC')) {
        return false;
    }
    $settings = (array) get_option('coderockz_woo_delivery_pickup_location_settings', array());
    if (empty($settings['enable_pickup_location']) || empty($settings['pickup_location'])) {
        return false;
    }
    foreach ((array) $settings['pickup_location'] as $location) {
        if (!empty($location['enable'])) {
            return true;
        }
    }
    return false;
}

/** Il nome del campo dei punti nelle impostazioni del plugin («Partner/Scuole/Ospedale»). */
function littleinka_delivery_partner_label()
{
    $settings = (array) get_option('coderockz_woo_delivery_pickup_location_settings', array());
    $label = trim(stripslashes((string) ($settings['field_label'] ?? '')));
    return $label !== '' ? $label : __('un punto di ritiro', 'littleinka-child-theme');
}

add_action('wp_enqueue_scripts', function () {
    if (!function_exists('is_checkout') || !is_checkout() || is_wc_endpoint_url() || !littleinka_delivery_partner_enabled()) {
        return;
    }
    littleinka_enqueue_module_js('delivery', array('jquery'), array(
        /* translators: %s: nome dei punti di ritiro, es. «Partner/Scuole/Ospedale» */
        'partner'  => sprintf(__('Ritiro da %s', 'littleinka-child-theme'), littleinka_delivery_partner_label()),
        'hint'     => __('Orario fisso del punto di ritiro', 'littleinka-child-theme'),
        'logos'    => (object) littleinka_pickup_logos(),
    ));
}, 30);

/** Il cliente ha scelto «Ritiro da Partner/Scuole/Ospedale»? (campo nascosto inviato da delivery.js) */
function littleinka_delivery_is_partner_post()
{
    // phpcs:disable WordPress.Security.NonceVerification.Missing -- dentro il checkout di WooCommerce, che verifica il suo nonce
    return isset($_POST['li_pickup_mode'], $_POST['coderockz_woo_delivery_delivery_selection_box'])
        && sanitize_key(wp_unslash($_POST['li_pickup_mode'])) === 'partner'
        && sanitize_key(wp_unslash($_POST['coderockz_woo_delivery_delivery_selection_box'])) === 'pickup';
    // phpcs:enable
}

/*
 * Prima dei controlli del plugin (priorità 10): per un ritiro dal partner l'orario non serve (il plugin lo vuole
 * obbligatorio) e il punto sì; per un ritiro in sede il punto si toglie.
 */
add_action('woocommerce_checkout_process', function () {
    if (!littleinka_delivery_partner_enabled()) {
        return;
    }
    // phpcs:disable WordPress.Security.NonceVerification.Missing -- checkout di WooCommerce
    if (littleinka_delivery_is_partner_post()) {
        $_POST['coderockz_woo_delivery_pickup_time_field'] = '';
        add_filter('option_coderockz_woo_delivery_pickup_time_settings', 'littleinka_delivery_time_not_required');
        if (empty($_POST['coderockz_woo_delivery_pickup_location_field'])) {
            /* translators: %s: nome dei punti di ritiro, es. «Partner/Scuole/Ospedale» */
            wc_add_notice(sprintf(__('Scegli dove ritirare: %s.', 'littleinka-child-theme'), littleinka_delivery_partner_label()), 'error');
        }
    } elseif (isset($_POST['li_pickup_mode']) && sanitize_key(wp_unslash($_POST['li_pickup_mode'])) === 'pickup') {
        $_POST['coderockz_woo_delivery_pickup_location_field'] = '';
    }
    // phpcs:enable
}, 5);

/** Le impostazioni degli orari di ritiro con l'orario non obbligatorio (solo per l'ordine dal partner in corso). */
function littleinka_delivery_time_not_required($settings)
{
    if (is_array($settings)) {
        $settings['pickup_time_mandatory'] = false;
    }
    return $settings;
}

/* -------------------------------------------------------------------------
 * Loghi dei punti di ritiro (Partner/Scuole/Ospedale) nella tendina della cassa
 * ---------------------------------------------------------------------- */

/** I punti di ritiro attivi del plugin, per nome (nell'ordine delle sue impostazioni). */
function littleinka_pickup_points()
{
    $settings = (array) get_option('coderockz_woo_delivery_pickup_location_settings', array());
    $names = array();
    foreach ((array) ($settings['pickup_location'] ?? array()) as $location) {
        $name = trim(stripslashes((string) ($location['location_name'] ?? '')));
        if ($name !== '' && !empty($location['enable'])) {
            $names[] = $name;
        }
    }
    return $names;
}

/** Chiave del logo di un punto in Personalizza (dal nome: lo stesso nome ha lo stesso logo). */
function littleinka_pickup_logo_key($name)
{
    return 'littleinka_pickup_logo_' . substr(md5(strtolower(trim($name))), 0, 12);
}

/** { nome del punto: indirizzo del logo } per i punti che hanno un logo. */
function littleinka_pickup_logos()
{
    $logos = array();
    foreach (littleinka_pickup_points() as $name) {
        $id = (int) get_theme_mod(littleinka_pickup_logo_key($name), 0);
        $url = $id ? wp_get_attachment_image_url($id, 'medium') : ''; // «medium» non ritaglia (thumbnail è quadrata)
        if ($url) {
            $logos[$name] = (string) $url;
        }
    }
    return $logos;
}

// Personalizza → Little Inka: un campo «Logo» per ogni punto di ritiro attivo del plugin.
add_action('customize_register', function ($wp_customize) {
    if (!littleinka_delivery_partner_enabled()) {
        return;
    }
    foreach (littleinka_pickup_points() as $name) {
        $key = littleinka_pickup_logo_key($name);
        $wp_customize->add_setting($key, array('default' => 0, 'sanitize_callback' => 'absint'));
        $wp_customize->add_control(new WP_Customize_Media_Control($wp_customize, $key, array(
            'section'     => 'littleinka',
            'mime_type'   => 'image',
            /* translators: %s: nome del punto di ritiro, es. «UBS Bellinzona» */
            'label'       => sprintf(__('Punto di ritiro «%s»: logo', 'littleinka-child-theme'), $name),
            'description' => __('Compare accanto al nome nella tendina della cassa. Meglio un PNG con fondo trasparente. Senza logo compare l\'iniziale.', 'littleinka-child-theme'),
        )));
    }
}, 20);

