<?php
/**
 * Aspetto → Personalizza → «Little Inka»: le poche cose che cambiano da una sede all'altra e che
 * non stanno già nel CMS del parent (contatti, orari, logo, SEO), in WooCommerce (prodotti, consegne,
 * indirizzo del negozio) o in CodeRockz (ordine minimo, fasce orarie).
 * I valori si leggono con littleinka_setting('<chiave>') di inc/helpers.php (theme_mod «littleinka_<chiave>»);
 * al salvataggio le cache del tema si svuotano (customize_save_after → littleinka_flush_caches, in helpers.php).
 */
defined('ABSPATH') || exit;

/** Il valore del menu a tendina «Cosa vende questa sede»: solo uno dei tre ammessi. */
function littleinka_sanitize_offerta($value)
{
    return in_array($value, array('auto', 'sushi_poke', 'poke'), true) ? $value : 'auto';
}

add_action('customize_register', function ($wp_customize) {
    $section = 'littleinka';
    $wp_customize->add_section($section, array(
        'title'       => __('Little Inka', 'littleinka-child-theme'),
        'priority'    => 30,
        'description' => __('Qui ci sono solo le cose proprie di questa sede. Indirizzo, telefono, orari e logo si cambiano in ticinoWEB CMS; piatti, prezzi, consegne e ritiro in WooCommerce.', 'littleinka-child-theme'),
    ));

    // Nome breve della sede.
    $wp_customize->add_setting('littleinka_nome_breve', array('default' => '', 'sanitize_callback' => 'sanitize_text_field'));
    $wp_customize->add_control('littleinka_nome_breve', array(
        'section'     => $section,
        'type'        => 'text',
        'label'       => __('Nome breve della sede', 'littleinka-child-theme'),
        'description' => __('Come chiamate questa sede nei titoli, per esempio «Via Murate» o «Castione». Se lo lasciate vuoto si usa la città del negozio.', 'littleinka-child-theme'),
    ));

    // Offerta: sushi e poké, oppure solo poké.
    $wp_customize->add_setting('littleinka_offerta', array('default' => 'auto', 'sanitize_callback' => 'littleinka_sanitize_offerta'));
    $wp_customize->add_control('littleinka_offerta', array(
        'section'     => $section,
        'type'        => 'select',
        'label'       => __('Cosa vende questa sede', 'littleinka-child-theme'),
        'description' => __('«In automatico» guarda i prodotti pubblicati: se ci sono piatti oltre al poké (sushi, uramaki…) la sede è «Poké e sushi», altrimenti «Solo poké». Scegliete una voce fissa solo se l’automatico sbaglia.', 'littleinka-child-theme'),
        'choices'     => array(
            'auto'       => __('In automatico (dai prodotti)', 'littleinka-child-theme'),
            'sushi_poke' => __('Poké e sushi', 'littleinka-child-theme'),
            'poke'       => __('Solo poké', 'littleinka-child-theme'),
        ),
    ));

    // Foto grande della pagina iniziale.
    $wp_customize->add_setting('littleinka_hero_image', array('default' => 0, 'sanitize_callback' => 'absint'));
    $wp_customize->add_control(new WP_Customize_Media_Control($wp_customize, 'littleinka_hero_image', array(
        'section'     => $section,
        'mime_type'   => 'image',
        'label'       => __('Foto grande in cima alla pagina iniziale', 'littleinka-child-theme'),
        'description' => __('Una foto orizzontale di un piatto o del locale, almeno 1600 pixel di larghezza. Senza, si usa l’immagine in evidenza della pagina iniziale, altrimenti la foto del primo piatto in evidenza.', 'littleinka-child-theme'),
    )));

    // Logo per la barra scura.

    // Partner nel footer (fino a tre loghi, nell'ordine).
    $partner_slots = array(
        ''   => __('Primo partner', 'littleinka-child-theme'),
        '_2' => __('Secondo partner', 'littleinka-child-theme'),
        '_3' => __('Terzo partner', 'littleinka-child-theme'),
    );
    foreach ($partner_slots as $slot => $name) {
        $wp_customize->add_setting('littleinka_partner' . $slot . '_logo', array('default' => 0, 'sanitize_callback' => 'absint'));
        $wp_customize->add_control(new WP_Customize_Media_Control($wp_customize, 'littleinka_partner' . $slot . '_logo', array(
            'section'     => $section,
            'mime_type'   => 'image',
            /* translators: %s: «Primo partner», «Secondo partner»… */
            'label'       => sprintf(__('%s: logo (in fondo alla pagina)', 'littleinka-child-theme'), $name),
            'description' => __('Il logo in bianco su sfondo trasparente (PNG), perché sta sulla fascia colorata del piè di pagina. Senza logo, questo partner non compare.', 'littleinka-child-theme'),
        )));
        $wp_customize->add_setting('littleinka_partner' . $slot . '_url', array('default' => '', 'sanitize_callback' => 'esc_url_raw'));
        $wp_customize->add_control('littleinka_partner' . $slot . '_url', array(
            'section'     => $section,
            'type'        => 'url',
            /* translators: %s: «Primo partner», «Secondo partner»… */
            'label'       => sprintf(__('%s: sito', 'littleinka-child-theme'), $name),
            'description' => __('L’indirizzo completo, con https://. Vuoto: il logo non è un link.', 'littleinka-child-theme'),
        ));
    }

    // App della sede.
    $wp_customize->add_setting('littleinka_app_ios_url', array('default' => '', 'sanitize_callback' => 'esc_url_raw'));
    $wp_customize->add_control('littleinka_app_ios_url', array(
        'section'     => $section,
        'type'        => 'url',
        'label'       => __('App per iPhone: indirizzo su App Store', 'littleinka-child-theme'),
        'description' => __('Il link della vostra app nell’App Store di Apple. Vuoto: il bottone non compare.', 'littleinka-child-theme'),
    ));
    $wp_customize->add_setting('littleinka_app_android_url', array('default' => '', 'sanitize_callback' => 'esc_url_raw'));
    $wp_customize->add_control('littleinka_app_android_url', array(
        'section'     => $section,
        'type'        => 'url',
        'label'       => __('App per Android: indirizzo su Google Play', 'littleinka-child-theme'),
        'description' => __('Il link della vostra app su Google Play. Vuoto: il bottone non compare.', 'littleinka-child-theme'),
    ));

    // Immagini del piè di pagina (badge delle app, metodi di pagamento, bollino -18).
    $footer_images = array(
        'badge_android'  => array(__('Badge «Disponibile su Google Play»', 'littleinka-child-theme'), __('L’immagine ufficiale del bottone Google Play. Porta all’indirizzo dell’app inserito sopra. Senza immagine compare un bottone di testo.', 'littleinka-child-theme')),
        'badge_ios'      => array(__('Badge «Scarica su App Store»', 'littleinka-child-theme'), __('L’immagine ufficiale del bottone App Store. Porta all’indirizzo dell’app inserito sopra. Senza immagine compare un bottone di testo.', 'littleinka-child-theme')),
        'alcohol_image'  => array(__('Bollino «-18, niente alcol e tabacco»', 'littleinka-child-theme'), __('Il bollino per i minori di 18 anni. Senza immagine compare quello del tema.', 'littleinka-child-theme')),
    );
    foreach ($footer_images as $key => $def) {
        $wp_customize->add_setting('littleinka_' . $key, array('default' => 0, 'sanitize_callback' => 'absint'));
        $wp_customize->add_control(new WP_Customize_Media_Control($wp_customize, 'littleinka_' . $key, array(
            'section'     => $section,
            'mime_type'   => 'image',
            'label'       => $def[0],
            'description' => $def[1],
        )));
    }

    // Metodi di pagamento accettati: i loghi ufficiali, uno per uno.
    foreach (littleinka_payment_methods() as $key => $label) {
        $wp_customize->add_setting('littleinka_pay_' . $key, array('default' => true, 'sanitize_callback' => 'wp_validate_boolean'));
        $wp_customize->add_control('littleinka_pay_' . $key, array(
            'section' => $section,
            'type'    => 'checkbox',
            /* translators: %s: nome del metodo di pagamento */
            'label'   => sprintf(__('Pagamenti: mostra il logo %s', 'littleinka-child-theme'), $label),
        ));
    }

    // Sfondo decorativo (il motivo con i fiori del vecchio sito), appena visibile dietro le parti bianche.
    $wp_customize->add_setting('littleinka_bg_pattern', array('default' => 0, 'sanitize_callback' => 'absint'));
    $wp_customize->add_control(new WP_Customize_Media_Control($wp_customize, 'littleinka_bg_pattern', array(
        'section'     => $section,
        'mime_type'   => 'image',
        'label'       => __('Sfondo decorativo (molto leggero)', 'littleinka-child-theme'),
        'description' => __('Un motivo che si ripete dietro le parti bianche delle pagine, per esempio i fiori tropicali. Si vede appena, non disturba la lettura. Vuoto: sfondo bianco.', 'littleinka-child-theme'),
    )));
    $wp_customize->add_setting('littleinka_bg_pattern_strength', array('default' => 4, 'sanitize_callback' => 'absint'));
    $wp_customize->add_control('littleinka_bg_pattern_strength', array(
        'section'     => $section,
        'type'        => 'range',
        'input_attrs' => array('min' => 2, 'max' => 20, 'step' => 1),
        'label'       => __('Quanto si vede lo sfondo decorativo', 'littleinka-child-theme'),
        'description' => __('Più a sinistra = più leggero. Consigliato: poco, perché i testi restino ben leggibili.', 'littleinka-child-theme'),
    ));

    // Portale di tutte le sedi.
    $wp_customize->add_setting('littleinka_portale_url', array('default' => LITTLEINKA_PORTAL_DEFAULT, 'sanitize_callback' => 'esc_url_raw'));
    $wp_customize->add_control('littleinka_portale_url', array(
        'section'     => $section,
        'type'        => 'url',
        'label'       => __('Sito con tutte le sedi («Cambia sede»)', 'littleinka-child-theme'),
        'description' => __('Dove porta il link «Cambia sede» nel piè di pagina: il sito principale con l’elenco di tutte le sedi.', 'littleinka-child-theme'),
    ));

    // Titolare del © nel piè di pagina.
    $wp_customize->add_setting('littleinka_copyright', array('default' => LITTLEINKA_COPYRIGHT_DEFAULT, 'sanitize_callback' => 'sanitize_text_field'));
    $wp_customize->add_control('littleinka_copyright', array(
        'section'     => $section,
        'type'        => 'text',
        'label'       => __('Titolare del copyright', 'littleinka-child-theme'),
        'description' => __('Il nome dopo «© anno» nel piè di pagina. È la società di tutte le sedi, non il nome della sede.', 'littleinka-child-theme'),
    ));

    // Avviso alcol e tabacco.
    $wp_customize->add_setting('littleinka_banner_alcol', array('default' => true, 'sanitize_callback' => 'rest_sanitize_boolean'));
    $wp_customize->add_control('littleinka_banner_alcol', array(
        'section'     => $section,
        'type'        => 'checkbox',
        'label'       => __('Mostra l’avviso «niente alcol e tabacco ai minori di 18 anni»', 'littleinka-child-theme'),
        'description' => __('L’avviso di legge compare nel piè di pagina. Toglietelo solo se questa sede non vende bevande alcoliche.', 'littleinka-child-theme'),
    ));
});
