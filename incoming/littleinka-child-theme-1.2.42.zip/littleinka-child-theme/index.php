<?php
/**
 * Ripiego per tutto il resto (articoli, archivi, ricerca, 404): titolo e testo in colonna,
 * oppure l'elenco dei contenuti trovati.
 */
defined('ABSPATH') || exit;

get_header();
?>
<main id="li-main" class="li-main li-page li-page--text">
    <div class="li-wrap li-page__head">
        <?php if (is_singular()) : ?>
            <h1 class="li-h1 li-page__title"><?php single_post_title(); ?></h1>
        <?php elseif (is_search()) : ?>
            <?php /* translators: %s: testo cercato */ ?>
            <h1 class="li-h1 li-page__title"><?php echo esc_html(sprintf(littleinka_t(__('Risultati per «%s»', 'littleinka-child-theme'), 'ui:ricerca'), get_search_query())); ?></h1>
        <?php elseif (is_404()) : ?>
            <h1 class="li-h1 li-page__title"><?php esc_html_e('Pagina non trovata', 'littleinka-child-theme'); ?></h1>
        <?php else : ?>
            <h1 class="li-h1 li-page__title"><?php echo esc_html(wp_strip_all_tags(get_the_archive_title() ?: get_bloginfo('name'))); ?></h1>
        <?php endif; ?>
    </div>
    <div class="li-wrap li-prose">
        <?php if (is_singular()) : ?>
            <?php while (have_posts()) : the_post(); ?>
                <?php if (has_post_thumbnail()) : ?><figure class="li-prose__figure"><?php the_post_thumbnail('large', array('loading' => 'eager', 'decoding' => 'async')); ?></figure><?php endif; ?>
                <?php the_content(); ?>
            <?php endwhile; ?>
        <?php elseif (have_posts()) : ?>
            <ul class="li-archive">
                <?php while (have_posts()) : the_post(); ?>
                    <li><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></li>
                <?php endwhile; ?>
            </ul>
            <?php the_posts_pagination(); ?>
        <?php else : ?>
            <p><?php esc_html_e('Nessun contenuto da mostrare.', 'littleinka-child-theme'); ?></p>
            <p><a class="li-btn li-btn--primary" href="<?php echo esc_url(littleinka_menu_url()); ?>"><?php esc_html_e('Vai al menu', 'littleinka-child-theme'); ?></a></p>
        <?php endif; ?>
    </div>
</main>
<?php
get_footer();
