/**
 * Cassa: «Consegna o ritiro?» a tre scelte (inc/delivery.php).
 * Al posto della tendina del plugin WooDelivery, tre riquadri: Consegna a domicilio, Ritiro in sede,
 * Ritiro da Partner/Scuole/Ospedale. La tendina vera resta nel modulo (nascosta) e viene aggiornata:
 * il plugin continua a mostrare data, orari e punti come sa fare. Il tema decide solo cosa nascondere:
 *  - Ritiro in sede: niente punto di ritiro;
 *  - Partner: niente orario (è quello fisso del punto), punto obbligatorio.
 */
(function ($) {
  'use strict';
  var cfg = window.littleInkaDelivery || {};
  var wrap = document.getElementById('coderockz_woo_delivery_setting_wrapper');
  var select = document.getElementById('coderockz_woo_delivery_delivery_selection_box');
  var pickupPoint = document.getElementById('coderockz_woo_delivery_pickup_location_field');
  if (!wrap || !select || !pickupPoint || !$) { return; }

  var field = document.getElementById('coderockz_woo_delivery_delivery_selection_box_field') || select.closest('.form-row');
  var timeSelect = document.getElementById('coderockz_woo_delivery_pickup_time_field');
  var form = select.closest('form');

  // Campo che dice al server quale delle tre scelte è stata fatta.
  var mode = document.createElement('input');
  mode.type = 'hidden';
  mode.name = 'li_pickup_mode';
  if (form) { form.appendChild(mode); }

  var choices = [];
  Array.prototype.forEach.call(select.options, function (o) {
    if (o.value === 'delivery' || o.value === 'pickup') { choices.push({ value: o.value, label: o.textContent.trim() }); }
  });
  if (choices.some(function (c) { return c.value === 'pickup'; })) {
    choices.push({ value: 'partner', label: cfg.partner || 'Partner', hint: cfg.hint || '' });
  }
  if (choices.length < 2) { return; }

  var group = document.createElement('div');
  group.className = 'li-dmode';
  group.setAttribute('role', 'radiogroup');
  var labelEl = field ? field.querySelector('label') : null;
  if (labelEl) {
    labelEl.id = labelEl.id || 'li-dmode-label';
    group.setAttribute('aria-labelledby', labelEl.id);
  }
  choices.forEach(function (c, i) {
    var lab = document.createElement('label');
    lab.className = 'li-dmode__opt';
    var input = document.createElement('input');
    input.type = 'radio';
    input.name = 'li_dmode';
    input.value = c.value;
    input.className = 'li-dmode__input';
    var text = document.createElement('span');
    text.className = 'li-dmode__text';
    text.textContent = c.label;
    lab.appendChild(input);
    lab.appendChild(text);
    if (c.hint) {
      var hint = document.createElement('span');
      hint.className = 'li-dmode__hint';
      hint.textContent = c.hint;
      lab.appendChild(hint);
    }
    input.addEventListener('change', function () { if (input.checked) { apply(c.value, true); } });
    group.appendChild(lab);
  });
  (field ? field.querySelector('.woocommerce-input-wrapper') || field : wrap).appendChild(group);
  wrap.classList.add('li-dmode-on');

  function setSelect(el, value) {
    if (!el || el.value === value) { return; }
    $(el).val(value).trigger('change');
  }

  function apply(value, fromUser) {
    wrap.setAttribute('data-li-mode', value);
    mode.value = value;
    Array.prototype.forEach.call(group.querySelectorAll('input'), function (r) { r.checked = r.value === value; });
    if (!fromUser) { return; }
    if (value === 'partner') {
      setSelect(select, 'pickup');
      setSelect(timeSelect, '');
    } else {
      if (value === 'pickup') { setSelect(pickupPoint, ''); }
      setSelect(select, value);
    }
  }

  // Stato iniziale: un ritiro con il punto già scelto è un ritiro dal partner.
  var start = select.value === 'pickup' && pickupPoint.value ? 'partner' : select.value;
  if (start) { apply(start, false); }

  // Se il plugin cambia la tendina da solo (es. dopo un aggiornamento della cassa), i riquadri lo seguono.
  $(select).on('change', function () {
    var current = wrap.getAttribute('data-li-mode');
    var next = select.value === 'pickup' && current === 'partner' ? 'partner' : select.value;
    if (next && next !== current) { apply(next, false); }
  });

  /*
   * Tendina dei punti di ritiro con il logo accanto al nome (solo nell'elenco: il campo scelto mostra il nome,
   * perché questa versione di select2 lo scrive come testo) (loghi da Personalizza → Little Inka;
   * senza logo, l'iniziale in un quadratino). La tendina è del plugin (select2): la si riapre con le stesse
   * opzioni più il disegno delle voci. Il plugin ascolta la <select>, non select2, quindi continua a funzionare.
   */
  var logos = cfg.logos || {};
  function esc(text) {
    return String(text == null ? '' : text).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }
  // HTML della voce: tutto il testo passa da esc(), quindi la tendina può usarlo senza riscaparlo (escapeMarkup sotto).
  function pointHtml(item) {
    if (!item.id) { return esc(item.text); }
    var url = logos[item.id] || logos[item.text];
    var mark = url
      ? '<span class="li-pp__logo"><img src="' + esc(url) + '" alt="" loading="lazy"></span>'
      : '<span class="li-pp__logo is-initial">' + esc(String(item.text || '').trim().charAt(0).toUpperCase()) + '</span>';
    return '<span class="li-pp">' + mark + '<span class="li-pp__name">' + esc(item.text) + '</span></span>';
  }
  function decoratePoints() {
    var $p = $(pickupPoint);
    var s2 = $p.data('select2');
    if (!s2 || !$.fn.select2 || s2.options.get('templateResult') === pointHtml) { return; }
    var opts = $.extend({}, s2.options.options, { templateResult: pointHtml, templateSelection: function (item) { return item.text; }, escapeMarkup: function (m) { return m; } });
    $p.select2('destroy').select2(opts);
  }
  $(function () { window.setTimeout(decoratePoints, 50); });
  $(window).on('load', decoratePoints);
  $(document.body).on('updated_checkout', function () { window.setTimeout(decoratePoints, 0); });
})(window.jQuery);
