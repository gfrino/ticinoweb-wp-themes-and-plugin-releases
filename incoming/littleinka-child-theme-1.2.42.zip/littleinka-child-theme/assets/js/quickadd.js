/**
 * Little Inka: extra e varianti in un popup (inc/quick-add.php).
 * Click su [data-li-options] → <dialog> con foto, nome e il modulo vero della scheda prodotto (Product Add-ons
 * lo inizializza con l'evento «quick-view-displayed»); l'invio aggiunge al carrello in AJAX e aggiorna l'header
 * con l'evento «added_to_cart» di WooCommerce (lo stesso avviso «è nel carrello» del menu).
 */
(function ($) {
  'use strict';

  var data = window.littleInkaQuickadd || {};
  if (!$ || !data.form || typeof HTMLDialogElement === 'undefined') {
    return;
  }

  var dialog = null;
  var opener = null;
  var busy = false;

  function build() {
    var d = document.createElement('dialog');
    d.className = 'li-qa';
    d.setAttribute('aria-labelledby', 'li-qa-title');
    d.innerHTML =
      '<div class="li-qa__box">' +
      '<button type="button" class="li-qa__close"><svg class="li-icon" viewBox="0 0 24 24" width="20" height="20" aria-hidden="true" focusable="false"><path d="M6 6l12 12M18 6 6 18" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg></button>' +
      '<div class="li-qa__body"></div>' +
      '</div>';
    d.querySelector('.li-qa__close').setAttribute('aria-label', data.close || 'Chiudi');
    d.querySelector('.li-qa__close').addEventListener('click', close);
    d.addEventListener('click', function (e) { if (e.target === d && !busy) { close(); } });
    d.addEventListener('cancel', function (e) { if (busy) { e.preventDefault(); } });
    d.addEventListener('close', function () {
      d.querySelector('.li-qa__body').innerHTML = '';
      document.documentElement.classList.remove('li-qa-open');
      if (opener) { opener.focus(); }
    });
    document.body.appendChild(d);
    return d;
  }

  function close() {
    if (dialog && dialog.open) { dialog.close(); }
  }

  function el(tag, cls, text) {
    var n = document.createElement(tag);
    if (cls) { n.className = cls; }
    if (text) { n.textContent = text; }
    return n;
  }

  function render(p) {
    var body = dialog.querySelector('.li-qa__body');
    body.innerHTML = '';
    var head = el('div', 'li-qa__head');
    if (p.image) {
      var img = el('img', 'li-qa__img');
      img.src = p.image; img.alt = ''; img.width = 600; img.height = 600;
      head.appendChild(img);
    }
    var text = el('div', 'li-qa__text');
    var h = el('h2', 'li-qa__title', p.name); h.id = 'li-qa-title';
    var price = el('p', 'li-qa__price'); price.innerHTML = p.price; // HTML del prezzo di WooCommerce, già filtrato sul server
    text.appendChild(h); text.appendChild(price);
    if (p.desc) { text.appendChild(el('p', 'li-qa__desc', p.desc)); }
    head.appendChild(text);
    body.appendChild(head);

    var wrap = el('div', 'li-qa__form');
    wrap.innerHTML = p.form; // modulo della scheda reso da WooCommerce sul server
    body.appendChild(wrap);
    var msg = el('div', 'li-qa__msg'); msg.setAttribute('role', 'alert');
    body.appendChild(msg);

    var form = wrap.querySelector('form.cart');
    if (!form) { return; }
    var button = form.querySelector('button[name="add-to-cart"], .single_add_to_cart_button');
    if (button) { button.classList.add('li-btn', 'li-btn--primary'); }
    // Quantità e «Aggiungi al carrello» in una barra fissa in fondo alla finestra: scorrono solo gli extra.
    // La barra resta dentro il modulo, così quantità e pulsante continuano a essere inviati con lui.
    var qty = form.querySelector(':scope > .quantity');
    if (button && button.parentNode === form) {
      var bar = el('div', 'li-qa__bar');
      if (qty) { bar.appendChild(qty); }
      bar.appendChild(button);
      form.appendChild(bar);
    }

    // Product Add-ons e le varianti si attivano sul modulo appena inserito.
    try {
      $(document.body).trigger('quick-view-displayed');
      if ($.fn.wc_variation_form && form.classList.contains('variations_form')) { $(form).wc_variation_form(); }
    } catch (err) {
      if (window.console) { window.console.error('[Little Inka] extra:', err); }
    }

    $(form).on('submit', function (e) {
      e.preventDefault();
      if (busy) { return; }
      var fd = new FormData(form);
      var id = (button && button.value) || fd.get('add-to-cart') || p.id;
      fd.delete('add-to-cart');
      fd.set('li_product', id);
      busy = true; dialog.classList.add('is-busy'); msg.textContent = '';
      if (button) { button.disabled = true; }
      fetch(data.add, { method: 'POST', credentials: 'same-origin', body: fd })
        .then(function (r) { return r.json(); })
        .then(function (res) {
          busy = false; dialog.classList.remove('is-busy');
          if (button) { button.disabled = false; }
          if (res && res.fragments) {
            var $fake = $('<a>').attr('data-product_name', p.name).attr('data-li-icon', (opener && opener.getAttribute && opener.getAttribute('data-li-icon')) || '');
            close();
            $(document.body).trigger('added_to_cart', [res.fragments, res.cart_hash, $fake]);
            return;
          }
          var list = res && res.data && res.data.messages ? res.data.messages : [data.error];
          msg.textContent = list.join(' ');
        })
        .catch(function () {
          busy = false; dialog.classList.remove('is-busy');
          if (button) { button.disabled = false; }
          msg.textContent = data.error || '';
        });
    });
  }

  function open(id, trigger) {
    opener = trigger;
    dialog = dialog || build();
    var body = dialog.querySelector('.li-qa__body');
    body.innerHTML = '';
    body.appendChild(el('p', 'li-qa__loading', data.loading || ''));
    document.documentElement.classList.add('li-qa-open');
    dialog.showModal();
    var url = data.form + (data.form.indexOf('?') === -1 ? '?' : '&') + 'product=' + encodeURIComponent(id);
    fetch(url, { credentials: 'same-origin' })
      .then(function (r) { return r.json(); })
      .then(function (res) {
        if (!res || !res.success) { throw new Error('form'); }
        render(res.data);
      })
      .catch(function (err) {
        // Senza modulo si va alla scheda prodotto, come prima.
        if (window.console) { window.console.error('[Little Inka] popup extra:', err); }
        close();
        if (trigger && trigger.href) { window.location.href = trigger.href; }
      });
  }

  document.addEventListener('click', function (e) {
    var t = e.target.closest ? e.target.closest('[data-li-options]') : null;
    if (!t || e.defaultPrevented || e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) {
      return;
    }
    e.preventDefault();
    open(t.getAttribute('data-li-options'), t);
  });
})(window.jQuery);
