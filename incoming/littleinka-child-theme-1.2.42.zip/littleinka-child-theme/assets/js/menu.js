/**
 * Little Inka: menu online.
 *  - avviso accessibile «{Nome} è nel carrello» all'evento «added_to_cart» di WooCommerce (AJAX standard);
 *  - chip delle categorie: aria-current sulla sezione visibile (IntersectionObserver, nessuno scroll animato);
 *  - ricerca istantanea tra le righe (nome e descrizione), categorie vuote nascoste, conteggio in aria-live.
 * Testi e URL in window.littleInkaMenu (inc/menu.php). Dipende da jQuery e wc-add-to-cart.
 */
(function () {
  'use strict';

  var data = window.littleInkaMenu || {};
  var $ = window.jQuery;

  function text(key, fallback) {
    return typeof data[key] === 'string' && data[key] !== '' ? data[key] : fallback;
  }

  function format(template, value) {
    return template.replace(/%[sd]/, value);
  }

  /* ---------- Avviso «è nel carrello» ---------- */
  var toast = null;
  var toastTimer = 0;

  function buildToast() {
    var el = document.createElement('div');
    el.className = 'li-toast';
    el.setAttribute('role', 'status');
    el.setAttribute('aria-live', 'polite');

    var p = document.createElement('p');
    p.className = 'li-toast__text';
    el.appendChild(p);

    var cartUrl = text('cartUrl', '');
    if (cartUrl) {
      var link = document.createElement('a');
      link.className = 'li-toast__link';
      link.href = cartUrl;
      link.textContent = text('viewCart', 'Vai al carrello');
      el.appendChild(link);
    }

    var close = document.createElement('button');
    close.type = 'button';
    close.className = 'li-toast__close';
    close.setAttribute('aria-label', text('close', 'Chiudi'));
    close.innerHTML = '<svg class="li-icon" viewBox="0 0 24 24" width="20" height="20" aria-hidden="true" focusable="false"><path d="M6 6l12 12M18 6 6 18" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>';
    close.addEventListener('click', hideToast);
    el.appendChild(close);

    document.body.appendChild(el);
    return el;
  }

  function showToast(productName) {
    if (!toast) {
      toast = buildToast();
    }
    var p = toast.querySelector('.li-toast__text');
    p.textContent = '';
    var template = text('added', '%s è nel carrello');
    var parts = template.split('%s');
    var strong = document.createElement('strong');
    strong.textContent = productName;
    p.appendChild(document.createTextNode(parts[0] || ''));
    p.appendChild(strong);
    p.appendChild(document.createTextNode(parts.slice(1).join('%s')));

    // Forza il riavvio dell'annuncio anche se il testo è uguale al precedente.
    toast.classList.remove('is-open');
    void toast.offsetWidth; // eslint-disable-line no-void
    toast.classList.add('is-open');

    window.clearTimeout(toastTimer);
    toastTimer = window.setTimeout(hideToast, 6000);
  }

  function hideToast() {
    if (toast) {
      toast.classList.remove('is-open');
    }
    window.clearTimeout(toastTimer);
  }

  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape' && toast && toast.classList.contains('is-open')) {
      hideToast();
    }
  });

  if ($) {
    $(document.body).on('added_to_cart', function (event, fragments, cartHash, $button) {
      var name = '';
      if ($button && $button.length) {
        name = $button.data('product_name') || $button.attr('data-product_name') || '';
        // Lo stato «aggiunto» del pulsante dura poco: si può aggiungere di nuovo senza ricaricare.
        window.setTimeout(function () {
          $button.removeClass('added');
        }, 2500);
      }
      showToast(String(name));
      if ($button && $button.length) { rain(String($button.attr('data-li-icon') || '')); }
    });
  }

  /*
   * Pioggia di icone quando un piatto entra nel carrello: l'icona della sua categoria (uramaki, poké, bibite…)
   * cade dall'alto in tante copie per poco più di due secondi. Solo decorativa (aria-hidden, non blocca i click);
   * nessuna animazione per chi ha chiesto meno movimento.
   */
  function rain(icon) {
    var tpl = icon ? document.querySelector('#li-rain-icons template[data-icon="' + icon + '"]') : null;
    if (!tpl || !document.body.animate || window.matchMedia('(prefers-reduced-motion: reduce)').matches) { return; }
    var old = document.querySelector('.li-rain');
    if (old) { old.remove(); }
    var layer = document.createElement('div');
    layer.className = 'li-rain';
    layer.setAttribute('aria-hidden', 'true');
    document.body.appendChild(layer);
    var h = window.innerHeight;
    var count = window.innerWidth < 640 ? 14 : 22;
    var longest = 0;
    for (var i = 0; i < count; i++) {
      var drop = document.createElement('span');
      drop.className = 'li-rain__drop' + (i % 3 === 0 ? ' is-light' : '');
      drop.appendChild(tpl.content.cloneNode(true));
      var size = 26 + Math.round(Math.random() * 26);
      drop.style.width = drop.style.height = size + 'px';
      drop.style.left = ((i + Math.random()) / count * 100) + '%';
      layer.appendChild(drop);
      var spin = (Math.random() < 0.5 ? -1 : 1) * (90 + Math.random() * 200);
      var drift = (Math.random() - 0.5) * 80;
      var duration = 1300 + Math.random() * 900;
      var delay = Math.random() * 500;
      longest = Math.max(longest, duration + delay);
      drop.animate([
        { transform: 'translate3d(0, -' + (size + 20) + 'px, 0) rotate(0deg)', opacity: 0 },
        { opacity: 1, offset: 0.12 },
        { opacity: 1, offset: 0.8 },
        { transform: 'translate3d(' + drift + 'px, ' + (h + size) + 'px, 0) rotate(' + spin + 'deg)', opacity: 0 }
      ], { duration: duration, delay: delay, easing: 'cubic-bezier(0.4, 0, 0.9, 0.6)', fill: 'both' });
    }
    window.setTimeout(function () { layer.remove(); }, longest + 100);
  }

  /* ---------- Pagina Menu ---------- */
  var menu = document.getElementById('li-menu');
  if (!menu) {
    return;
  }

  var chips = menu.querySelector('.li-chips');
  var chipLinks = chips ? Array.prototype.slice.call(chips.querySelectorAll('.li-chips__link')) : [];
  /* Frecce per scorrere le categorie quando non stanno tutte nella riga */
  var chipList = chips ? chips.querySelector('.li-chips__list') : null;
  if (chipList) {
    var arrowSvg = '<svg class="li-icon" viewBox="0 0 24 24" width="18" height="18" aria-hidden="true" focusable="false"><path d="M5 12h14M13 6l6 6-6 6" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>';
    var makeArrow = function (dir, label) {
      var b = document.createElement('button');
      b.type = 'button';
      b.className = 'li-chips__arrow li-chips__arrow--' + dir;
      b.setAttribute('aria-label', label);
      b.setAttribute('tabindex', '-1');
      b.innerHTML = arrowSvg;
      return b;
    };
    var cfg = (window.littleInkaMenu && window.littleInkaMenu.arrows) || {};
    var prevBtn = makeArrow('prev', cfg.prev || 'Categorie precedenti');
    var nextBtn = makeArrow('next', cfg.next || 'Altre categorie');
    chips.appendChild(prevBtn);
    chips.appendChild(nextBtn);
    var reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    var updateArrows = function () {
      // Se le categorie non stanno tutte nella riga si riservano due spazi ai lati per le frecce: il testo non ci passa sotto.
      chips.classList.remove('has-arrows');
      var overflow = chipList.scrollWidth > chipList.clientWidth + 1;
      chips.classList.toggle('has-arrows', overflow);
      var max = chipList.scrollWidth - chipList.clientWidth;
      chips.classList.toggle('has-prev', chipList.scrollLeft > 4);
      chips.classList.toggle('has-next', chipList.scrollLeft < max - 4);
    };
    var scrollByPage = function (dir) {
      chipList.scrollBy({ left: dir * Math.max(160, chipList.clientWidth * 0.7), behavior: reduce ? 'auto' : 'smooth' });
    };
    prevBtn.addEventListener('click', function () { scrollByPage(-1); });
    nextBtn.addEventListener('click', function () { scrollByPage(1); });
    chipList.addEventListener('scroll', updateArrows, { passive: true });
    window.addEventListener('resize', updateArrows);
    updateArrows();
    setTimeout(updateArrows, 400);
  }

  var sections = Array.prototype.slice.call(menu.querySelectorAll('.li-menu__cat'));
  var rows = Array.prototype.slice.call(menu.querySelectorAll('.li-row'));
  var input = menu.querySelector('.li-menu__input');
  var count = menu.querySelector('.li-menu__count');
  var none = menu.querySelector('.li-menu__none');

  function chipFor(slug) {
    for (var i = 0; i < chipLinks.length; i++) {
      if (chipLinks[i].getAttribute('data-cat') === slug) {
        return chipLinks[i];
      }
    }
    return null;
  }

  /* --- chip: la categoria visibile --- */
  var visible = {};

  function setCurrent(slug) {
    chipLinks.forEach(function (link) {
      var isCurrent = link.getAttribute('data-cat') === slug;
      if (isCurrent) {
        link.setAttribute('aria-current', 'true');
        // Porta il chip nel riquadro scorrevole, senza animazione e senza muovere la pagina.
        var list = link.parentNode && link.parentNode.parentNode;
        if (list && list.scrollWidth > list.clientWidth) {
          var left = link.offsetLeft;
          var right = left + link.offsetWidth;
          if (left < list.scrollLeft) {
            list.scrollLeft = left - 16;
          } else if (right > list.scrollLeft + list.clientWidth) {
            list.scrollLeft = right - list.clientWidth + 16;
          }
        }
      } else {
        link.removeAttribute('aria-current');
      }
    });
  }

  function updateCurrent() {
    for (var i = 0; i < sections.length; i++) {
      var slug = sections[i].getAttribute('data-cat');
      if (visible[slug] && !sections[i].hidden) {
        setCurrent(slug);
        return;
      }
    }
  }

  if (chips && sections.length && 'IntersectionObserver' in window) {
    var navH = parseInt(getComputedStyle(document.documentElement).getPropertyValue('--li-nav-h'), 10) || 64;
    // Riga orizzontale (telefono): conta la sua altezza; colonna laterale (computer): non occupa spazio sopra il contenuto.
    var chipsH = chips.offsetHeight > 200 ? 0 : (chips.offsetHeight || 48);
    var observer = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        visible[entry.target.getAttribute('data-cat')] = entry.isIntersecting;
      });
      updateCurrent();
    }, { rootMargin: '-' + (navH + chipsH + 8) + 'px 0px -45% 0px', threshold: 0 });
    sections.forEach(function (section) {
      observer.observe(section);
    });

    // Al clic su un chip la sezione è «corrente» subito: il salto è quello del browser (nessuno scroll animato).
    chipLinks.forEach(function (link) {
      link.addEventListener('click', function () {
        if (link.getAttribute('data-cat')) {
          setCurrent(link.getAttribute('data-cat'));
        }
      });
    });
  }

  /* --- ricerca istantanea --- */
  function normalize(str) {
    str = String(str || '').toLowerCase();
    if (str.normalize) {
      str = str.normalize('NFD').replace(/[̀-ͯ]/g, '');
    }
    return str.replace(/\s+/g, ' ').trim();
  }

  rows.forEach(function (row) {
    var name = row.querySelector('.li-row__name');
    var desc = row.querySelector('.li-row__desc');
    row.liText = normalize((name ? name.textContent : '') + ' ' + (desc ? desc.textContent : ''));
  });

  function filter(query) {
    var q = normalize(query);
    var words = q ? q.split(' ') : [];
    var shown = 0;

    rows.forEach(function (row) {
      var match = true;
      for (var i = 0; i < words.length; i++) {
        if (row.liText.indexOf(words[i]) === -1) {
          match = false;
          break;
        }
      }
      row.hidden = !match;
      if (match) {
        shown++;
      }
    });

    Array.prototype.forEach.call(menu.querySelectorAll('.li-menu__sub'), function (subSection) {
      subSection.hidden = subSection.querySelector('.li-row:not([hidden])') === null;
      var subLink = menu.querySelector('.li-chips__link--sub[data-sub="' + subSection.id.replace('cat-', '') + '"]');
      if (subLink && subLink.parentNode) {
        subLink.parentNode.hidden = subSection.hidden;
      }
    });

    sections.forEach(function (section) {
      var any = section.querySelector('.li-row:not([hidden])') !== null;
      section.hidden = !any;
      var chip = chipFor(section.getAttribute('data-cat'));
      if (chip && chip.parentNode) {
        chip.parentNode.hidden = !any;
      }
    });

    if (none) {
      none.hidden = !(q && shown === 0);
    }
    if (count) {
      if (!q) {
        count.textContent = '';
      } else if (shown === 0) {
        count.textContent = format(text('noResults', 'Nessun piatto corrisponde a «%s»'), query.trim());
      } else if (shown === 1) {
        count.textContent = text('countOne', '1 piatto trovato');
      } else {
        count.textContent = format(text('countMany', '%d piatti trovati'), String(shown));
      }
    }
    updateCurrent();
  }

  if (input) {
    var timer = 0;
    input.addEventListener('input', function () {
      window.clearTimeout(timer);
      timer = window.setTimeout(function () {
        filter(input.value);
      }, 120);
    });
    input.addEventListener('keydown', function (e) {
      if (e.key === 'Enter') {
        e.preventDefault();
      }
      if (e.key === 'Escape' && input.value) {
        input.value = '';
        filter('');
      }
    });
    // Il browser può ripristinare il testo digitato al ritorno sulla pagina.
    if (input.value) {
      filter(input.value);
    }
  }
})();
