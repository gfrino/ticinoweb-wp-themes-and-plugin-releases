<?php
/**
 * Pagina interna. Titolo h1 e contenuto in colonna (.li-prose) per le pagine di testo, il carrello,
 * la cassa e l'account (colonna più larga); a tutta larghezza, con l'h1 nel .li-wrap sopra, per le pagine
 * fatte a sezioni (classi li-*) e per quelle con [littleinka_menu] o [make_your_own_poke]. Menu e Crea la tua poké
 * hanno in cima il banner con le foglie e l'h1 solo per Google e i lettori di schermo (la voce del menu dice già dove sei).
 */
defined('ABSPATH') || exit;

get_header();
the_post();
$li_content = (string) get_the_content();
$li_wide    = strpos($li_content, 'class="li-') !== false;
$li_sedi    = has_shortcode($li_content, 'littleinka_sedi');
$li_banner  = has_shortcode($li_content, 'littleinka_menu') || has_shortcode($li_content, 'make_your_own_poke');
$li_app     = $li_sedi || $li_banner;
$li_shop    = (function_exists('is_cart') && is_cart()) || (function_exists('is_checkout') && is_checkout()) || (function_exists('is_account_page') && is_account_page());
$li_classes = 'li-main li-page ' . ($li_wide ? 'li-page--wide' : ($li_app ? 'li-page--app' : 'li-page--text')) . ($li_shop ? ' li-page--shop' : '') . ($li_sedi ? ' li-page--sedi' : '') . ($li_banner ? ' li-page--banner' : '');
?>
<main id="li-main" class="<?php echo esc_attr($li_classes); ?>">
    <div class="li-wrap li-page__head">
        <h1 class="li-h1 li-page__title"><?php the_title(); ?></h1>
        <?php if ($li_banner) { echo littleinka_points_invite(); } // phpcs:ignore WordPress.Security.EscapeOutput -- escape nella funzione (inc/points.php) ?>
    </div>
    <?php if ($li_wide) : ?>
        <?php the_content(); ?>
    <?php elseif ($li_app) : ?>
        <div class="li-wrap li-page__app"><?php the_content(); ?></div>
    <?php else : ?>
        <div class="li-wrap li-prose"><?php the_content(); ?></div>
    <?php endif; ?>
</main>
<?php
get_footer();
