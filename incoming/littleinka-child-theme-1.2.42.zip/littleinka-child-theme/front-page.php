<?php
/**
 * Home. Portale: «scegli la sede». Sede: il menu (la pagina con [littleinka_menu]), con orario e indirizzo sotto il
 * titolo; /menu/ porta qui (inc/helpers.php). Senza pagina Menu: la vecchia home in template-parts/home.php.

 */
defined('ABSPATH') || exit;

// Sul sito principale (portale delle sedi) la home è la pagina «scegli la sede», come il vecchio littleinka.ch.
if (littleinka_is_portal()) {
    littleinka_enqueue_module_css('portal');
    get_template_part('template-parts/portal');
    return;
}

// Sulle sedi la home è il menu: dal portale si arriva subito ai piatti. Senza pagina Menu, la vecchia home.
$li_menu_page = littleinka_page_with_shortcode('littleinka_menu');
if (!$li_menu_page) {
    get_template_part('template-parts/home');
    return;
}

get_header();
$li_open    = littleinka_open_now_line();
$li_address = littleinka_address_line();
$li_state   = littleinka_open_now();
?>
<main id="li-main" class="li-main li-page li-page--app li-page--menu-home li-page--banner">
    <div class="li-wrap li-page__head">
        <h1 class="li-h1 li-page__title"><?php echo esc_html(get_the_title($li_menu_page)); ?></h1>
        <?php if ($li_open !== '' || $li_address !== '') : ?>
            <p class="li-page__meta">
                <?php if ($li_open !== '') : ?><span class="li-page__open<?php echo $li_state['open'] ? '' : ' is-closed'; ?>"><span class="li-visit__dot" aria-hidden="true"></span><?php echo esc_html($li_open); ?></span><?php endif; ?>
                <?php if ($li_address !== '') : ?><span class="li-page__address"><?php echo esc_html($li_address); ?></span><?php endif; ?>
            </p>
        <?php endif; ?>
        <?php echo littleinka_points_invite(); // phpcs:ignore WordPress.Security.EscapeOutput -- escape nella funzione (inc/points.php) ?>
    </div>
    <div class="li-wrap li-page__app"><?php echo apply_filters('the_content', (string) get_post_field('post_content', $li_menu_page)); // phpcs:ignore WordPress.Security.EscapeOutput -- contenuto della pagina Menu ?></div>
</main>
<?php
get_footer();

