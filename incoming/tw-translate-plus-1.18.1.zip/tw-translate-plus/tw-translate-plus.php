<?php
/**
 * Plugin Name:       tW Translate Plus
 * Plugin URI:        https://ticinoweb.net
 * Description:       Traduzioni multilingua leggere con motore a scelta per sito (gpt-oss-20b, OpenAI o Google Cloud Translation v3, ciascun sito con la propria chiave): un solo oggetto WordPress, URL con prefisso lingua, glossario per sito e override manuali.
 * Version:           1.18.1
 * Requires at least: 6.2
 * Requires PHP:      7.4
 * Author:            ticinoWEB
 * License:           Proprietary — Licenza d'uso esclusiva ticinoWEB
 * Text Domain:       tw-translate-plus
 * Update URI:        https://github.com/gfrino/ticinoweb-wp-themes-and-plugin-releases
 *
 * @package tw-translate-plus
 */

if (!defined('ABSPATH')) {
    exit;
}

define('TWTR_VERSION', '1.18.1');
define('TWTR_DB_VERSION', '5');
define('TWTR_FILE', __FILE__);
define('TWTR_DIR', plugin_dir_path(__FILE__));
define('TWTR_URL', plugin_dir_url(__FILE__));
// Version of the bundled includes/tw-release-updater.php (keep in sync with its header).
define('TWTR_RELEASE_UPDATER_VERSION', '1.1.0');

/*
 * Updates from the ticinoWEB releases repo (see the Update URI header). The
 * bundled loader is generic and is also installed as a mu-plugin, so updates
 * work in Network Admin and the main site's cron too, where a per-site
 * activated plugin is not loaded. If the mu-plugin is already loaded this
 * include is a no-op.
 */
require_once TWTR_DIR . 'includes/tw-release-updater.php';

require_once TWTR_DIR . 'includes/class-twtr-settings.php';
require_once TWTR_DIR . 'includes/class-twtr-storage.php';
require_once TWTR_DIR . 'includes/class-twtr-resolver.php';
require_once TWTR_DIR . 'includes/class-twtr-slugs.php';
require_once TWTR_DIR . 'includes/class-twtr-router.php';
require_once TWTR_DIR . 'includes/functions.php';
require_once TWTR_DIR . 'includes/class-twtr-switcher.php';
require_once TWTR_DIR . 'includes/class-twtr-html.php';

/**
 * Lazy loaders: heavier components are included only when actually needed.
 */
function twtr_google() {
    require_once TWTR_DIR . 'includes/class-twtr-google.php';
    return Twtr_Google::instance();
}

function twtr_openai() {
    require_once TWTR_DIR . 'includes/class-twtr-openai.php';
    return Twtr_Openai::instance();
}

/**
 * The configured translation engine.
 *
 * Both clients expose the same three methods (translate_batch,
 * test_connection, last_error), so every caller that only translates goes
 * through here and never needs to know which engine is active. The engine
 * and its key are those of the current site (Twtr_Settings::engine()). Google-only
 * features (glossary resources, GCS) keep calling twtr_google() directly.
 *
 * @return Twtr_Google|Twtr_Openai
 */
function twtr_translator() {
    return Twtr_Settings::is_llm() ? twtr_openai() : twtr_google();
}

function twtr_queue() {
    require_once TWTR_DIR . 'includes/class-twtr-queue.php';
    return 'Twtr_Queue';
}

function twtr_glossary() {
    require_once TWTR_DIR . 'includes/class-twtr-glossary.php';
    return 'Twtr_Glossary';
}

/**
 * Bootstrap.
 *
 * The language router must run before WordPress resolves the request,
 * therefore it is initialized directly at plugins_loaded.
 */
function twtr_bootstrap() {
    Twtr_Router::init();
    Twtr_Switcher::init();
    if (!is_admin() && !Twtr_Router::wpml_active()) {
        Twtr_Slugs::init(); // 301 for old (e.g. WPML) URLs that have no page anymore
    }

    // Frontend adapters: only when a non-default language is being served.
    if (Twtr_Router::current_language() !== '' ) {
        require_once TWTR_DIR . 'includes/class-twtr-content.php';
        require_once TWTR_DIR . 'includes/class-twtr-theme.php';
        Twtr_Content::init();
        Twtr_Theme_Adapter::init();
        // Everything the filters cannot see (theme templates, page builders).
        Twtr_Html::init();
        if (class_exists('WooCommerce') || defined('WC_PLUGIN_FILE')) {
            require_once TWTR_DIR . 'includes/class-twtr-woocommerce.php';
            Twtr_Woo::init();
        }
    }

    // SEO (hreflang, og:locale, sitemap, noindex) runs on every frontend request
    // because the default-language pages must also expose hreflang alternates.
    if (!is_admin() && !wp_doing_cron() && !wp_doing_ajax()) {
        require_once TWTR_DIR . 'includes/class-twtr-seo.php';
        Twtr_Seo::init();
    }

    // Cache purge bridge + content change tracking. The extractor is loaded
    // unconditionally because Gutenberg saves via REST (not is_admin()).
    require_once TWTR_DIR . 'includes/class-twtr-cache.php';
    require_once TWTR_DIR . 'includes/class-twtr-extractor.php';
    Twtr_Cache::init();
    Twtr_Extractor::init();

    if (is_admin()) {
        require_once TWTR_DIR . 'admin/class-twtr-admin.php';
        require_once TWTR_DIR . 'admin/class-twtr-network-admin.php';
        require_once TWTR_DIR . 'admin/class-twtr-post-ui.php';
        Twtr_Admin::init();
        Twtr_Network_Admin::init();
        Twtr_Post_UI::init();
    }

    // Self-driven background worker (loopback chain + watchdog): translates
    // without any server configuration. WP-Cron, where it works, helps.
    require_once TWTR_DIR . 'includes/class-twtr-worker.php';
    Twtr_Worker::init();
    add_action('twtr_process_queue', 'twtr_run_queue_batch');

    if (defined('WP_CLI') && WP_CLI) {
        require_once TWTR_DIR . 'includes/class-twtr-cli.php';
        WP_CLI::add_command('twtr', 'Twtr_CLI');
    }
}
add_action('plugins_loaded', 'twtr_bootstrap', 5);

/**
 * Cron/CLI entry point for the queue.
 */
function twtr_run_queue_batch() {
    // Updates are installed by cron: migrate before translating, or the
    // queue would run against the old schema until someone opens the admin.
    Twtr_Worker::run_from_cron();
}

/**
 * Activation: create/upgrade the shared tables and grant the capability.
 *
 * @param bool $network_wide Whether the plugin is being network-activated.
 */
function twtr_activate($network_wide = false) {
    Twtr_Storage::install();
    twtr_grant_capability();
    twtr_install_release_updater();

    if ($network_wide && is_multisite()) {
        // Grant the capability on every existing site. Settings themselves are
        // lazy: each site gets defaults on first read, so no network iteration
        // is ever needed at request time.
        $site_ids = get_sites(array('fields' => 'ids', 'number' => 500));
        foreach ($site_ids as $sid) {
            switch_to_blog($sid);
            twtr_grant_capability();
            restore_current_blog();
        }
    }
}
register_activation_hook(__FILE__, 'twtr_activate');

/**
 * New sites created after a network-wide activation.
 *
 * @param WP_Site $new_site The new site object.
 */
function twtr_initialize_new_site($new_site) {
    if (!function_exists('is_plugin_active_for_network')) {
        require_once ABSPATH . 'wp-admin/includes/plugin.php';
    }
    if (!is_plugin_active_for_network(plugin_basename(__FILE__))) {
        return;
    }
    switch_to_blog((int) $new_site->blog_id);
    twtr_grant_capability();
    restore_current_blog();
}
add_action('wp_initialize_site', 'twtr_initialize_new_site', 20);

/**
 * Roles of a site that manage its translations, glossary and translation
 * API: administrators, WooCommerce shop managers and editors.
 *
 * @return string[]
 */
function twtr_manager_roles() {
    return (array) apply_filters('twtr_manager_roles', array('administrator', 'shop_manager', 'editor'));
}

/**
 * Grant the dedicated capability to the manager roles of the current site.
 * Cheap enough to run on every admin request (roles are already loaded),
 * which also covers sites upgraded from older versions and a shop_manager
 * role created later by WooCommerce.
 */
function twtr_grant_capability() {
    // Once per role set: an administrator who later removes the capability
    // from a role (with a role editor) is not overruled on the next request.
    $signature = implode(',', twtr_manager_roles()) . '|' . (get_role('shop_manager') ? 'woo' : '');
    if (get_option('twtr_caps_granted') === $signature) {
        return;
    }
    update_option('twtr_caps_granted', $signature, true);
    foreach (twtr_manager_roles() as $name) {
        $role = get_role($name);
        if ($role && !$role->has_cap('twtr_manage_translations')) {
            $role->add_cap('twtr_manage_translations');
        }
    }
}
add_action('admin_init', 'twtr_grant_capability', 1);

/**
 * Deactivation: clear scheduled events for this site. Data is kept.
 */
function twtr_deactivate() {
    wp_clear_scheduled_hook('twtr_process_queue');
    wp_clear_scheduled_hook('twtr_index_site');
    wp_clear_scheduled_hook('twtr_daily_maintenance');
}
register_deactivation_hook(__FILE__, 'twtr_deactivate');

/**
 * DB schema upgrade check (admin only, cheap version compare).
 */
function twtr_maybe_upgrade() {
    if (get_site_option('twtr_db_version') !== TWTR_DB_VERSION) {
        Twtr_Storage::install();
    }
}
add_action('admin_init', 'twtr_maybe_upgrade', 1);
add_action('admin_init', array('Twtr_Settings', 'upgrade_site'), 2);

/**
 * Install or upgrade the release updater mu-plugin from the bundled copy.
 *
 * Runs on activation (so installing the plugin on another server sets it up
 * there too) and in admin when the mu-plugin is missing or older than the
 * bundled copy — e.g. right after this plugin was updated. A failure (mu-plugins
 * not writable) is retried at most every 12 hours; meanwhile the bundled copy
 * still handles updates wherever this plugin is loaded.
 */
function twtr_install_release_updater() {
    if (!class_exists('TW_Release_Updater') || TW_Release_Updater::mu_is_current(TWTR_RELEASE_UPDATER_VERSION)) {
        return;
    }
    if (get_site_transient('twtr_release_updater_failed')) {
        return;
    }
    $result = TW_Release_Updater::install_mu(TWTR_DIR . 'includes/tw-release-updater.php');
    if (is_wp_error($result)) {
        set_site_transient('twtr_release_updater_failed', $result->get_error_message(), 12 * HOUR_IN_SECONDS);
    }
}

add_action('admin_init', function () {
    if (current_user_can(is_multisite() ? 'manage_network_plugins' : 'activate_plugins')) {
        twtr_install_release_updater();
    }
}, 20);

