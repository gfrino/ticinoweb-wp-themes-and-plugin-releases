<?php
/**
 * Configuratore dei programmi scolastici: shortcode [ld_programmi].
 *
 * Legge i programmi dal tipo di contenuto «programma-scolastico» (campi ACF già compilati dalla scuola):
 * nessun dato nuovo da inserire. L'elenco leggero (titolo, classe, gruppo) è nella pagina; il testo completo di
 * ogni programma si carica solo quando lo studente lo apre, da un endpoint di sola lettura.
 *
 * @package liceo-diocesano-child
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

const LICEO_PROGRAMMI_CPT = 'programma-scolastico';

/**
 * Elenco leggero. Il titolo ha sempre la forma «Fisica OC 4a liceo»: materia, eventuale sigla OS/OC, classe.
 * Il profilo dell'opzione specifica (es. «Biologia e chimica») sta nel campo «materia» come «OS biologia e chimica: chimica».
 */
function liceo_diocesano_programmi_list() {
    $cached = get_transient( 'ld_programmi_list' );
    if ( is_array( $cached ) ) {
        return $cached;
    }
    $ids  = get_posts( array( 'post_type' => LICEO_PROGRAMMI_CPT, 'post_status' => 'publish', 'numberposts' => -1, 'fields' => 'ids', 'orderby' => 'title', 'order' => 'ASC' ) );
    $list = array();
    foreach ( $ids as $id ) {
        $title = get_the_title( $id );
        if ( ! preg_match( '/^(.*?)\s+(\d)\s*a\s+liceo$/iu', trim( $title ), $m ) ) {
            continue;
        }
        $subject = trim( $m[1] );
        $group   = 'fond';
        $profile = '';
        if ( preg_match( '/\sOS$/u', $subject ) ) {
            $group = 'os';
            $raw   = (string) get_post_meta( $id, 'materia', true );
            if ( preg_match( '/^OS\s+(.+?):/iu', $raw, $p ) ) {
                $profile = ucfirst( trim( $p[1] ) );
            }
        } elseif ( preg_match( '/\sOC$/u', $subject ) ) {
            $group = 'oc';
        }
        $list[] = array(
            'id'      => (int) $id,
            's'       => $subject,
            'y'       => (int) $m[2],
            'g'       => $group,
            'p'       => $profile,
        );
    }
    set_transient( 'ld_programmi_list', $list, DAY_IN_SECONDS );
    return $list;
}
add_action( 'save_post_' . LICEO_PROGRAMMI_CPT, function () {
    delete_transient( 'ld_programmi_list' );
} );
add_action( 'deleted_post', function () {
    delete_transient( 'ld_programmi_list' );
} );

// Endpoint pubblico di sola lettura: il testo di un singolo programma.
add_action( 'rest_api_init', function () {
    register_rest_route( 'liceo/v1', '/programma/(?P<id>\d+)', array(
        'methods'             => 'GET',
        'permission_callback' => '__return_true',
        'args'                => array( 'id' => array( 'sanitize_callback' => 'absint' ) ),
        'callback'            => function ( WP_REST_Request $req ) {
            $post = get_post( (int) $req['id'] );
            if ( ! $post || LICEO_PROGRAMMI_CPT !== $post->post_type || 'publish' !== $post->post_status ) {
                return new WP_Error( 'not_found', 'Programma non trovato', array( 'status' => 404 ) );
            }
            $rev = (string) get_post_meta( $post->ID, 'ultima_revisione', true );
            if ( preg_match( '/^(\d{4})(\d{2})(\d{2})$/', $rev, $d ) ) {
                $rev = $d[3] . '/' . $d[2] . '/' . $d[1];
            }
            $res = new WP_REST_Response( array(
                'title'    => get_the_title( $post ),
                'revision' => sanitize_text_field( $rev ),
                'intro'    => (string) get_post_meta( $post->ID, 'osservazioni_introduttive_e_finalita_generali:', true ),
                'sem1'     => (string) get_post_meta( $post->ID, 'temi_trattati_i_semestre', true ),
                'sem2'     => (string) get_post_meta( $post->ID, 'temi_trattati_ii_semestre', true ),
                'goals'    => (string) get_post_meta( $post->ID, 'obiettivi_cognitivi_e_metodologici_dell’anno_eo_delle_unita_didattiche', true ),
                'method'   => (string) get_post_meta( $post->ID, 'modalita_di_lavoro_e_materiali_utilizzati', true ),
            ) );
            $res->header( 'Cache-Control', 'public, max-age=3600' );
            return $res;
        },
    ) );
} );

add_shortcode( 'ld_programmi', function () {
    $dir = get_stylesheet_directory();
    $uri = get_stylesheet_directory_uri();
    wp_enqueue_style( 'ld-programmi', $uri . '/assets/css/programmi.css', array( 'child-style' ), filemtime( $dir . '/assets/css/programmi.css' ) );
    wp_enqueue_script( 'ld-programmi', $uri . '/assets/js/programmi.js', array(), filemtime( $dir . '/assets/js/programmi.js' ), true );
    wp_localize_script( 'ld-programmi', 'ldProgrammi', array(
        'list'  => liceo_diocesano_programmi_list(),
        'plans' => liceo_diocesano_piani_di_studio(),
        'api'   => esc_url_raw( rest_url( 'liceo/v1/programma/' ) ),
    ) );
    return '<div class="ldp" id="ld-programmi"><noscript><p>' . esc_html__( 'Per consultare i programmi serve JavaScript.', 'liceo-diocesano-child' ) . '</p></noscript></div>';
} );

/**
 * Piani di studio per indirizzo (ore settimanali per classe): dati del file assets/data/piani-di-studio.json,
 * ricavati dal foglio «Indirizzi liceo diocesano» della scuola.
 */
function liceo_diocesano_piani_di_studio() {
    $file = get_stylesheet_directory() . '/assets/data/piani-di-studio.json';
    $json = is_readable( $file ) ? file_get_contents( $file ) : '';
    $data = $json ? json_decode( $json, true ) : null;
    return is_array( $data ) ? $data : array();
}
