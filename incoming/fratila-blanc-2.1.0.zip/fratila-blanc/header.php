<?php
/**
 * Header one-page: logo, ancore alle sezioni, telefono in evidenza.
 *
 * @package Fratila_Blanc
 */
$site    = fratila_blanc_get_site_data();
$contact = $site['contact'];
$prefix  = is_front_page() ? '' : home_url('/');
$anchors = array();
if ($site['about']['text'] !== '' || $site['about']['features'] || $site['about']['location_text']) {
    $anchors['chi-siamo'] = __('Chi siamo', 'fratila-blanc');
}
if ($site['staff']) {
    $anchors['medici'] = __('Medici', 'fratila-blanc');
}
if ($contact['address'] !== '') {
    $anchors['dove-siamo'] = __('Dove siamo', 'fratila-blanc');
}
if ($contact['email'] !== '' || $contact['email_hin'] !== '') {
    $anchors['contatti'] = __('Contatti', 'fratila-blanc');
}
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo('charset'); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="fb-skip-link" href="#main"><?php esc_html_e('Vai al contenuto', 'fratila-blanc'); ?></a>

<header class="fb-header" id="top">
	<div class="fb-container fb-header__inner">
		<a class="fb-logo" href="<?php echo esc_url(home_url('/')); ?>" rel="home">
			<?php if ($site['use_image_logo'] && $site['logo']) : ?>
				<img class="fb-logo__img" src="<?php echo esc_url($site['logo']); ?>" alt="<?php echo esc_attr($site['brand']); ?>" width="200" height="81">
			<?php else : ?>
				<span class="fb-logo__mark" aria-hidden="true"><svg width="22" height="22" viewBox="0 0 24 24" fill="currentColor"><path d="M9 3h6v6h6v6h-6v6H9v-6H3V9h6z"/></svg></span>
				<span class="fb-logo__text"><?php if ($site['logo_prefix'] !== '') : ?><span class="fb-logo__light"><?php echo esc_html($site['logo_prefix']); ?></span> <?php endif; ?><strong><?php echo esc_html($site['logo_name']); ?></strong></span>
			<?php endif; ?>
		</a>

		<nav class="fb-nav" id="fb-nav" aria-label="<?php esc_attr_e('Navigazione principale', 'fratila-blanc'); ?>">
			<?php if (has_nav_menu('primary')) : ?>
				<?php wp_nav_menu(array('theme_location' => 'primary', 'container' => false, 'menu_class' => 'fb-nav__list', 'depth' => 1)); ?>
			<?php else : ?>
				<ul class="fb-nav__list">
					<?php foreach ($anchors as $id => $label) : ?>
						<li><a class="fb-nav__link" href="<?php echo esc_url($prefix . '#' . $id); ?>" data-section="<?php echo esc_attr($id); ?>"><?php echo esc_html($label); ?></a></li>
					<?php endforeach; ?>
				</ul>
			<?php endif; ?>
			<?php if ($contact['phone_1'] !== '') : ?>
			<?php if ($contact['phone_1'] !== '') : ?>
			<a class="fb-btn fb-btn--primary fb-nav__cta" href="<?php echo esc_attr(fratila_blanc_tel_href($contact['phone_1'])); ?>">
				<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/></svg>
				<span><?php echo esc_html($contact['phone_1']); ?></span>
			</a>
			<?php endif; ?>
			<?php endif; ?>
		</nav>

		<button class="fb-burger" id="fb-burger" type="button" aria-controls="fb-nav" aria-expanded="false" aria-label="<?php esc_attr_e('Apri il menu', 'fratila-blanc'); ?>">
			<span></span><span></span><span></span>
		</button>
	</div>
</header>
