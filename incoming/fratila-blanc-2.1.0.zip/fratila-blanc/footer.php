<?php
/**
 * Footer: recapiti, orari, link legali.
 *
 * @package Fratila_Blanc
 */
$site    = fratila_blanc_get_site_data();
$contact = $site['contact'];
$about   = $site['about'];
$privacy = get_privacy_policy_url();
?>
<footer class="fb-footer" role="contentinfo">
	<div class="fb-container">
		<div class="fb-footer__grid">
			<div class="fb-footer__col fb-footer__brand">
				<?php if ($site['use_image_logo'] && $site['logo']) : ?>
					<img class="fb-footer__logo" src="<?php echo esc_url($site['logo']); ?>" alt="<?php echo esc_attr($site['brand']); ?>" width="180" height="73" loading="lazy">
				<?php else : ?>
					<p class="fb-footer__brand-name">
						<span class="fb-logo__mark fb-logo__mark--footer" aria-hidden="true"><svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M9 3h6v6h6v6h-6v6H9v-6H3V9h6z"/></svg></span>
							<?php if ($site['logo_prefix'] !== '') : ?><span class="fb-logo__light"><?php echo esc_html($site['logo_prefix']); ?></span> <?php endif; ?><strong><?php echo esc_html($site['logo_name']); ?></strong>
						</p>
				<?php endif; ?>
				<?php if ($site['tagline'] !== '') : ?><p class="fb-footer__tagline"><?php echo esc_html($site['tagline']); ?></p><?php endif; ?>
				<?php $aff = $site['affiliation']; ?>
					<?php if ($aff['logo'] || $aff['name'] || $aff['sub']) : ?>
						<?php echo $aff['url'] ? '<a class="fb-footer__fmh" href="' . esc_url($aff['url']) . '" target="_blank" rel="noopener noreferrer">' : '<span class="fb-footer__fmh">'; ?>
							<?php if ($aff['logo']) : ?>
								<span class="fb-footer__fmh-chip"><img src="<?php echo esc_url(get_stylesheet_directory_uri() . '/assets/img/fmh.png'); ?>" alt="<?php echo esc_attr($aff['badge'] ?: 'FMH'); ?>" width="134" height="64" loading="lazy" decoding="async"></span>
							<?php endif; ?>
							<?php if ($aff['name'] || $aff['sub']) : ?>
								<span class="fb-footer__fmh-text"><?php echo esc_html($aff['name']); ?><?php if ($aff['name'] && $aff['sub']) : ?><br><?php endif; ?><?php if ($aff['sub']) : ?><small><?php echo esc_html($aff['sub']); ?></small><?php endif; ?></span>
							<?php endif; ?>
						<?php echo $aff['url'] ? '</a>' : '</span>'; ?>
					<?php endif; ?>
			</div>

			<div class="fb-footer__col">
				<h2 class="fb-footer__title"><?php esc_html_e('Contatti', 'fratila-blanc'); ?></h2>
				<ul class="fb-footer__list">
					<?php if ($contact['address'] !== '') : ?>
					<li><?php echo fratila_blanc_address_html($contact['address']); ?></li>
					<?php endif; ?>
					<?php if ($contact['phone_1'] !== '') : ?>
					<li><a href="<?php echo esc_attr(fratila_blanc_tel_href($contact['phone_1'])); ?>"><?php echo esc_html($contact['phone_1']); ?></a></li>
					<?php endif; ?>
					<?php if ($contact['phone_2']) : ?>
						<li><a href="<?php echo esc_attr(fratila_blanc_tel_href($contact['phone_2'])); ?>"><?php echo esc_html($contact['phone_2']); ?></a></li>
					<?php endif; ?>
					<?php if ($contact['email'] !== '') : ?>
					<li><a href="mailto:<?php echo esc_attr($contact['email']); ?>"><?php echo esc_html($contact['email']); ?></a></li>
					<?php endif; ?>
					<?php if ($contact['email_hin']) : ?>
						<li><a href="mailto:<?php echo esc_attr($contact['email_hin']); ?>"><?php echo esc_html($contact['email_hin']); ?></a> <span class="fb-footer__muted">(HIN)</span></li>
					<?php endif; ?>
				</ul>
			</div>

			<?php if ($about['hours'] || $about['phone_hours'] || $about['hours_note']) : ?>
			<div class="fb-footer__col">
				<h2 class="fb-footer__title"><?php esc_html_e('Orari', 'fratila-blanc'); ?></h2>
				<ul class="fb-footer__list">
					<?php foreach ($about['hours'] as $row) : ?>
						<li><strong><?php echo esc_html($row['days']); ?></strong> <?php echo esc_html($row['hours']); ?></li>
					<?php endforeach; ?>
					<?php if ($about['phone_hours']) : ?>
						<li><span class="fb-footer__muted"><?php esc_html_e('Linee telefoniche:', 'fratila-blanc'); ?></span> <?php echo esc_html($about['phone_hours']); ?></li>
					<?php endif; ?>
					<?php if ($about['hours_note']) : ?>
						<li class="fb-footer__muted"><?php echo esc_html($about['hours_note']); ?></li>
					<?php endif; ?>
				</ul>
			</div>
			<?php endif; ?>
		</div>

		<div class="fb-footer__bottom">
			<p class="fb-footer__copy">&copy; <?php echo esc_html(date_i18n('Y')); ?> <?php echo esc_html($site['brand']); ?>. <?php esc_html_e('Tutti i diritti riservati.', 'fratila-blanc'); ?></p>
			<ul class="fb-footer__legal">
				<?php if ($privacy) : ?>
					<li><a href="<?php echo esc_url($privacy); ?>"><?php esc_html_e('Privacy Policy', 'fratila-blanc'); ?></a></li>
				<?php endif; ?>
				<li><a href="<?php echo esc_url(home_url('/tw-login/')); ?>"><?php esc_html_e('Area privata', 'fratila-blanc'); ?></a></li>
				<li><a href="https://ticinoweb.com/" target="_blank" rel="noopener noreferrer">Design by <strong>ticinoWEB</strong></a></li>
			</ul>
		</div>
	</div>
</footer>
<?php wp_footer(); ?>
</body>
</html>
