<?php
/**
 * Dati del sito: tutto viene letto dal ticinoWEB CMS (opzioni ticinoweb_*)
 * e dal pannello "Studio medico" del child (opzione fratila_blanc_studio).
 * Nessun dato del cliente è scritto nel tema: se un valore manca il blocco
 * che lo mostra non viene stampato.
 *
 * @package Fratila_Blanc
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Valori predefiniti del pannello "Studio medico".
 */
function fratila_blanc_studio_defaults()
{
    return array(
        'logo_prefix'    => '',
        'logo_name'      => '',
        'use_image_logo' => '0',
        'badge'          => '',
        'affiliation'    => '',
        'affiliation_sub' => '',
        'affiliation_url' => '',
        'show_fmh_logo'  => '0',
        'hero_eyebrow'   => '',
        'hero_title'     => '',
        'hero_text'      => '',
        'hero_image'     => 0,
        'about_image'    => 0,
        'about_image_caption' => '',
        'phone_hours'    => '',
        'location_text'  => '',
        'features'       => '',
        'email_hin'      => '',
        'maps_url'       => '',
        'show_map'       => '1',
        'contact_intro'  => 'Per appuntamenti e urgenze vi invitiamo a telefonare. Per informazioni generali potete scriverci via email: vi risponderemo al più presto.',
        'contact_note'   => 'Per motivi di riservatezza, non inviate referti o dati sanitari via email ordinaria.',
        'schema_specialty' => 'PrimaryCare',
        'geo_lat'        => '',
        'geo_lng'        => '',
        'areas_served'   => '',
        'staff'          => array(),
    );
}

/**
 * Specialità proposte per i dati strutturati (valori di schema.org MedicalSpecialty).
 */
function fratila_blanc_specialty_choices()
{
    return array(
        'PrimaryCare'    => __('Medicina generale / interna', 'fratila-blanc'),
        'Surgical'       => __('Chirurgia', 'fratila-blanc'),
        'Cardiovascular' => __('Cardiologia', 'fratila-blanc'),
        'Dermatology'    => __('Dermatologia', 'fratila-blanc'),
        'Gynecologic'    => __('Ginecologia', 'fratila-blanc'),
        'Pediatric'      => __('Pediatria', 'fratila-blanc'),
        'Psychiatric'    => __('Psichiatria', 'fratila-blanc'),
        'Dentistry'      => __('Odontoiatria', 'fratila-blanc'),
    );
}

/**
 * Opzione del pannello "Studio medico", con i default applicati.
 */
function fratila_blanc_get_studio_option()
{
    static $cache = null;
    if ($cache !== null) {
        return $cache;
    }
    $defaults = fratila_blanc_studio_defaults();
    $saved    = get_option('fratila_blanc_studio', array());
    if (!is_array($saved)) {
        $saved = array();
    }
    $cache = array_merge($defaults, $saved);

    // Staff: se salvato, si usa quello del cliente; le righe senza nome sono scartate.
    if (isset($saved['staff']) && is_array($saved['staff'])) {
        $staff = array();
        foreach ($saved['staff'] as $row) {
            if (!is_array($row) || trim((string) ($row['name'] ?? '')) === '') {
                continue;
            }
            $staff[] = array_merge(array('name' => '', 'role' => '', 'languages' => '', 'pdf' => '', 'photo' => 0), $row);
        }
        $cache['staff'] = $staff;
    }
    return $cache;
}

/**
 * Loghi della rete Medisyn: fanno parte del tema, uguali per tutti i medici
 * associati. Se Medisyn o Sonic Suisse cambiano logo o indirizzo si aggiorna
 * questo elenco (e i file in assets/img/) e il cambiamento arriva a tutti i
 * siti con il normale aggiornamento del tema.
 *
 * @return array<int, array{logo:string, url:string, name:string}>
 */
function fratila_blanc_network_logos()
{
    $img = get_stylesheet_directory_uri() . '/assets/img/';
    $logos = array(
        array('logo' => $img . 'network-sonic-suisse.png', 'url' => 'https://www.sonic-suisse.ch/it-it/', 'name' => 'Sonic Suisse'),
        array('logo' => $img . 'network-medisyn.png', 'url' => 'https://www.medisyn.ch/en/homepage', 'name' => 'Medisyn'),
    );
    return apply_filters('fratila_blanc_network_logos', $logos);
}

/**
 * Loghi della rete Medisyn (dal tema) seguiti dagli eventuali altri partner dal
 * ticinoWEB CMS (sezione Partner del parent): opzioni
 * ticinoweb_partner_count, ticinoweb_partner_logo_N (URL), ticinoweb_partner_link_N.
 *
 * @return array<int, array{logo:string, url:string, name:string}>
 */
function fratila_blanc_get_partners()
{
    $count    = max(0, min(24, (int) get_option('ticinoweb_partner_count', 0)));
    $partners = fratila_blanc_network_logos();
    $known    = array();
    foreach ($partners as $network) {
        $known[] = (string) wp_parse_url($network['url'], PHP_URL_HOST);
    }
    for ($i = 1; $i <= $count; $i++) {
        $logo = trim((string) get_option("ticinoweb_partner_logo_{$i}", ''));
        if ($logo === '') {
            continue;
        }
        $url  = trim((string) get_option("ticinoweb_partner_link_{$i}", ''));
        if ($url !== '' && in_array((string) wp_parse_url($url, PHP_URL_HOST), $known, true)) {
            continue;
        }
        $name = '';
        $attachment_id = attachment_url_to_postid($logo);
        if ($attachment_id) {
            $name = trim((string) get_post_meta($attachment_id, '_wp_attachment_image_alt', true)) ?: get_the_title($attachment_id);
        }
        if ($name === '' && $url !== '') {
            $name = (string) wp_parse_url($url, PHP_URL_HOST);
        }
        $partners[] = array('logo' => $logo, 'url' => $url, 'name' => $name);
    }
    return $partners;
}

/**
 * URL dell'attestato di un medico (PDF scelto nel pannello Studio medico).
 */
function fratila_blanc_staff_pdf_url(array $member)
{
    return !empty($member['pdf']) ? esc_url($member['pdf']) : '';
}

/**
 * Tutti i dati necessari ai template, con cache per richiesta.
 */
function fratila_blanc_get_site_data()
{
    static $data = null;
    if ($data !== null) {
        return $data;
    }

    $contact = function_exists('ticinoweb_get_contact_info') ? ticinoweb_get_contact_info() : array();
    $studio  = fratila_blanc_get_studio_option();

    $phone_1 = !empty($contact['phone']) ? $contact['phone'] : '';
    $phone_2 = !empty($contact['phone_landline']) ? $contact['phone_landline'] : '';
    if ($phone_2 === $phone_1) {
        $phone_2 = '';
    }

    $brand       = trim((string) get_bloginfo('name'));
    $logo_name   = trim((string) $studio['logo_name']);
    $logo_prefix = trim((string) $studio['logo_prefix']);
    if ($logo_name === '' && $logo_prefix === '') {
        $logo_name = $brand;
    }

    $data = array(
        'brand'   => $brand,
        'tagline' => (string) get_bloginfo('description'),
        'logo'    => function_exists('ticinoweb_get_site_logo') ? ticinoweb_get_site_logo() : false,
        'use_image_logo' => $studio['use_image_logo'] === '1',
        'logo_prefix' => $logo_prefix,
        'logo_name'   => $logo_name,
        'affiliation' => array(
            'badge' => trim((string) $studio['badge']),
            'name'  => trim((string) $studio['affiliation']),
            'sub'   => trim((string) $studio['affiliation_sub']),
            'url'   => trim((string) $studio['affiliation_url']),
            'logo'  => $studio['show_fmh_logo'] === '1',
        ),
        'hero'    => array(
            'eyebrow' => $studio['hero_eyebrow'],
            'title'   => $studio['hero_title'] !== '' ? $studio['hero_title'] : $brand,
            'text'    => $studio['hero_text'],
            'image'   => (int) $studio['hero_image'],
        ),
        'about'   => array(
            'title'         => (string) get_option('ticinoweb_chi_siamo_title'),
            'text'          => (string) get_option('ticinoweb_chi_siamo_text'),
            'hours'         => fratila_blanc_grouped_hours(),
            'hours_note'    => !empty($contact['opening_hours_note']) ? $contact['opening_hours_note'] : '',
            'phone_hours'   => $studio['phone_hours'],
            'location_text' => $studio['location_text'],
            'features'      => array_values(array_filter(array_map('trim', preg_split('/\r\n|\r|\n/', (string) $studio['features'])))),
            'partners'      => fratila_blanc_get_partners(),
            'image'         => (int) $studio['about_image'],
            'image_caption' => $studio['about_image_caption'],
        ),
        'staff'   => $studio['staff'],
        'contact' => array(
            'address'   => !empty($contact['address']) ? $contact['address'] : '',
            'phone_1'   => $phone_1,
            'phone_2'   => $phone_2,
            'email'     => !empty($contact['email']) ? $contact['email'] : '',
            'email_hin' => !empty($contact['email_2']) ? $contact['email_2'] : $studio['email_hin'],
            'maps_url'  => $studio['maps_url'],
            'show_map'  => $studio['show_map'] === '1',
            'intro'     => $studio['contact_intro'],
            'note'      => $studio['contact_note'],
            'facebook'  => $contact['facebook'] ?? '',
            'instagram' => $contact['instagram'] ?? '',
            'linkedin'  => $contact['linkedin'] ?? '',
        ),
        'schema'  => array(
            'specialty' => $studio['schema_specialty'],
            'lat'       => $studio['geo_lat'],
            'lng'       => $studio['geo_lng'],
            'areas'     => array_values(array_filter(array_map('trim', explode(',', (string) $studio['areas_served'])))),
        ),
    );
    return $data;
}
