<?php
/**
 * SEO: arricchimento del JSON-LD del parent (tW SEO) con i dati dello studio.
 * Meta description, Open Graph e Twitter Card restano al parent.
 *
 * @package Fratila_Blanc
 */

if (!defined('ABSPATH')) {
    exit;
}

add_filter('ticinoweb_seo_og_locale', function () {
    return 'it_CH';
});

add_filter('ticinoweb_seo_jsonld_org_schema', 'fratila_blanc_enrich_schema');
function fratila_blanc_enrich_schema($schema)
{
    $site    = fratila_blanc_get_site_data();
    $contact = $site['contact'];

    // Studio medico con sede fisica: sottotipo di LocalBusiness.
    $schema['@type'] = 'MedicalClinic';
    if (!empty($site['schema']['specialty'])) {
        $schema['medicalSpecialty'] = $site['schema']['specialty'];
    }

    if (empty($schema['description'])) {
        $desc = trim((string) get_option('tw_seo_description'));
        if ($desc !== '') {
            $schema['description'] = $desc;
        }
    }

    $phones = array_values(array_filter(array($contact['phone_1'], $contact['phone_2'])));
    if ($phones) {
        $schema['telephone'] = count($phones) === 1 ? $phones[0] : $phones;
    }
    if (!empty($contact['email'])) {
        $schema['email'] = $contact['email'];
    }

    // Indirizzo strutturato (il parent scrive solo streetAddress):
    // "Via Esempio 1, 6500 Località" → via, CAP, località.
    $address = trim((string) $contact['address']);
    if ($address !== '') {
        $postal = preg_match('/\b(\d{4})\b/', $address, $m) ? $m[1] : '';
        $street = trim(preg_replace('/,?\s*\d{4}.*$/', '', $address));
        $locality = preg_match('/\b\d{4}\s+(.+)$/u', $address, $m) ? trim($m[1]) : '';
        $postal_address = array(
            '@type'          => 'PostalAddress',
            'streetAddress'  => $street !== '' ? $street : $address,
            'addressRegion'  => 'Ticino',
            'addressCountry' => 'CH',
        );
        if ($locality !== '') {
            $postal_address['addressLocality'] = $locality;
        }
        if ($postal !== '') {
            $postal_address['postalCode'] = $postal;
        }
        $schema['address'] = $postal_address;
    }
    if ($site['schema']['lat'] !== '' && $site['schema']['lng'] !== '') {
        $schema['geo'] = array(
            '@type'     => 'GeoCoordinates',
            'latitude'  => (float) $site['schema']['lat'],
            'longitude' => (float) $site['schema']['lng'],
        );
    }
    if (!empty($contact['maps_url'])) {
        $schema['hasMap'] = $contact['maps_url'];
    }
    if ($site['schema']['areas']) {
        $schema['areaServed'] = array_map(function ($name) {
            return array('@type' => 'City', 'name' => $name);
        }, $site['schema']['areas']);
    }

    // Orari dal CMS del parent.
    $hours = get_option('ticinoweb_contact_opening_hours', array());
    $map   = array(
        'monday' => 'Monday', 'tuesday' => 'Tuesday', 'wednesday' => 'Wednesday',
        'thursday' => 'Thursday', 'friday' => 'Friday', 'saturday' => 'Saturday', 'sunday' => 'Sunday',
    );
    $spec = array();
    if (is_array($hours)) {
        foreach ($map as $key => $day) {
            if (empty($hours[$key]) || !empty($hours[$key]['closed']) || empty($hours[$key]['slots'])) {
                continue;
            }
            foreach ($hours[$key]['slots'] as $slot) {
                $open  = fratila_blanc_normalize_time($slot['open'] ?? '');
                $close = fratila_blanc_normalize_time($slot['close'] ?? '');
                if ($open && $close) {
                    $spec[] = array(
                        '@type'     => 'OpeningHoursSpecification',
                        'dayOfWeek' => 'https://schema.org/' . $day,
                        'opens'     => $open,
                        'closes'    => $close,
                    );
                }
            }
        }
    }
    if ($spec) {
        $schema['openingHoursSpecification'] = $spec;
    }

    // Medici.
    $employees = array();
    foreach ($site['staff'] as $member) {
        $person = array(
            '@type'   => 'Physician',
            'name'    => $member['name'],
            'jobTitle' => $member['role'],
        );
        $langs = array_filter(array_map('trim', explode(',', str_replace(array('–', '-', '/'), ',', (string) $member['languages']))));
        if ($langs) {
            $person['knowsLanguage'] = array_values($langs);
        }
        $employees[] = $person;
    }
    if ($employees) {
        $schema['employee'] = $employees;
    }

    $schema['isAcceptingNewPatients'] = true;
    $schema['currenciesAccepted']     = 'CHF';

    return $schema;
}

/**
 * "08.00" / "8:00" / "16.30" → "08:00" / "16:30".
 */
function fratila_blanc_normalize_time($value)
{
    $value = trim((string) $value);
    if (!preg_match('/^(\d{1,2})[.:h](\d{2})$/', $value, $m)) {
        return '';
    }
    return sprintf('%02d:%02d', (int) $m[1], (int) $m[2]);
}
