<?php
/**
 * Pannello "Studio medico" (sottomenu di ticinoWEB CMS): testi del sito e
 * scheda dei medici. Recapiti, orari, logo e "Chi siamo" restano nel pannello
 * del parent (ticinoWEB CMS), per non duplicare i dati.
 *
 * Opzione: fratila_blanc_studio (array), Settings API con sanitizzazione.
 *
 * @package Fratila_Blanc
 */

if (!defined('ABSPATH')) {
    exit;
}

add_action('admin_menu', 'fratila_blanc_register_studio_menu', 20);
function fratila_blanc_register_studio_menu()
{
    add_submenu_page(
        'ticinoweb-cms',
        __('Studio medico', 'fratila-blanc'),
        __('Studio medico', 'fratila-blanc'),
        'edit_pages',
        'fratila-blanc-studio',
        'fratila_blanc_render_studio_page'
    );
}

add_action('admin_init', 'fratila_blanc_register_studio_settings');
function fratila_blanc_register_studio_settings()
{
    register_setting('fratila_blanc_studio_group', 'fratila_blanc_studio', array(
        'type'              => 'array',
        'sanitize_callback' => 'fratila_blanc_sanitize_studio',
        'default'           => array(),
    ));
}

// Gli editor (edit_pages) possono salvare questo gruppo, come per il CMS del parent.
add_filter('option_page_capability_fratila_blanc_studio_group', function () {
    return 'edit_pages';
});

/**
 * Coordinata decimale entro il limite dato, oppure stringa vuota.
 */
function fratila_blanc_sanitize_coord($value, $limit)
{
    $value = str_replace(',', '.', trim((string) $value));
    if ($value === '' || !is_numeric($value) || abs((float) $value) > $limit) {
        return '';
    }
    return (string) (float) $value;
}

/**
 * Sanitizzazione completa dell'opzione.
 */
function fratila_blanc_sanitize_studio($input)
{
    if (!is_array($input)) {
        return array();
    }
    $specialties = fratila_blanc_specialty_choices();
    $specialty   = sanitize_text_field($input['schema_specialty'] ?? 'PrimaryCare');
    $out = array(
        'logo_prefix'   => sanitize_text_field($input['logo_prefix'] ?? ''),
        'logo_name'     => sanitize_text_field($input['logo_name'] ?? ''),
        'badge'         => sanitize_text_field($input['badge'] ?? ''),
        'affiliation'   => sanitize_text_field($input['affiliation'] ?? ''),
        'affiliation_sub' => sanitize_text_field($input['affiliation_sub'] ?? ''),
        'affiliation_url' => esc_url_raw($input['affiliation_url'] ?? ''),
        'show_fmh_logo' => !empty($input['show_fmh_logo']) ? '1' : '0',
        'contact_intro' => sanitize_textarea_field($input['contact_intro'] ?? ''),
        'contact_note'  => sanitize_textarea_field($input['contact_note'] ?? ''),
        'schema_specialty' => isset($specialties[$specialty]) ? $specialty : 'PrimaryCare',
        'geo_lat'       => fratila_blanc_sanitize_coord($input['geo_lat'] ?? '', 90),
        'geo_lng'       => fratila_blanc_sanitize_coord($input['geo_lng'] ?? '', 180),
        'areas_served'  => sanitize_text_field($input['areas_served'] ?? ''),
        'hero_eyebrow'  => sanitize_text_field($input['hero_eyebrow'] ?? ''),
        'hero_title'    => sanitize_text_field($input['hero_title'] ?? ''),
        'hero_text'     => sanitize_textarea_field($input['hero_text'] ?? ''),
        'hero_image'    => absint($input['hero_image'] ?? 0),
        'use_image_logo' => !empty($input['use_image_logo']) ? '1' : '0',
        'about_image'   => absint($input['about_image'] ?? 0),
        'about_image_caption' => sanitize_text_field($input['about_image_caption'] ?? ''),
        'phone_hours'   => sanitize_text_field($input['phone_hours'] ?? ''),
        'location_text' => sanitize_textarea_field($input['location_text'] ?? ''),
        'features'      => sanitize_textarea_field($input['features'] ?? ''),
        'email_hin'     => sanitize_email($input['email_hin'] ?? ''),
        'maps_url'      => esc_url_raw($input['maps_url'] ?? ''),
        'show_map'      => !empty($input['show_map']) ? '1' : '0',
        'staff'         => array(),
    );
    if ($out['hero_image'] && !wp_attachment_is_image($out['hero_image'])) {
        $out['hero_image'] = 0;
    }
    if ($out['about_image'] && !wp_attachment_is_image($out['about_image'])) {
        $out['about_image'] = 0;
    }
    if (isset($input['staff']) && is_array($input['staff'])) {
        foreach (array_slice($input['staff'], 0, 4) as $row) {
            if (!is_array($row)) {
                continue;
            }
            $name = sanitize_text_field($row['name'] ?? '');
            if ($name === '') {
                continue;
            }
            $photo = absint($row['photo'] ?? 0);
            if ($photo && !wp_attachment_is_image($photo)) {
                $photo = 0;
            }
            $pdf = esc_url_raw($row['pdf'] ?? '');
            if ($pdf !== '' && strtolower(pathinfo(wp_parse_url($pdf, PHP_URL_PATH) ?? '', PATHINFO_EXTENSION)) !== 'pdf') {
                $pdf = '';
            }
            $out['staff'][] = array(
                'name'      => $name,
                'role'      => sanitize_text_field($row['role'] ?? ''),
                'languages' => sanitize_text_field($row['languages'] ?? ''),
                'pdf'       => $pdf,
                'photo'     => $photo,
            );
        }
    }
    return $out;
}

add_action('admin_enqueue_scripts', 'fratila_blanc_studio_admin_assets');
function fratila_blanc_studio_admin_assets($hook)
{
    if ($hook !== 'ticinoweb-cms_page_fratila-blanc-studio') {
        return;
    }
    wp_enqueue_media();
    $dir = get_stylesheet_directory();
    wp_enqueue_script(
        'fratila-blanc-admin',
        get_stylesheet_directory_uri() . '/assets/js/admin-studio.js',
        array('jquery'),
        (string) filemtime($dir . '/assets/js/admin-studio.js'),
        true
    );
    wp_add_inline_style('wp-admin', '
        .fb-admin .form-table th{width:220px}
        .fb-admin textarea.large-text{min-height:110px}
        .fb-staff{border:1px solid #dcdcde;border-radius:8px;padding:16px 20px;margin:0 0 16px;background:#fff}
        .fb-staff h3{margin:0 0 12px;font-size:14px}
        .fb-staff .form-table{margin:0}
        .fb-staff .form-table th{width:160px;padding:8px 10px 8px 0}
        .fb-staff .form-table td{padding:8px 0}
        .fb-media-preview{display:block;max-width:120px;max-height:120px;border-radius:8px;margin-top:8px}
        .fb-admin .description{color:#646970}
    ');
}

/**
 * Pagina del pannello.
 */
function fratila_blanc_render_studio_page()
{
    if (!current_user_can('edit_pages')) {
        wp_die(esc_html__('Permessi insufficienti.', 'fratila-blanc'));
    }
    $o = fratila_blanc_get_studio_option();
    $staff = $o['staff'];
    while (count($staff) < 4) {
        $staff[] = array('name' => '', 'role' => '', 'languages' => '', 'pdf' => '', 'photo' => 0);
    }
    $cms_url = admin_url('admin.php?page=ticinoweb-cms');
    ?>
    <div class="wrap fb-admin">
        <h1><?php esc_html_e('Studio medico — contenuti del sito', 'fratila-blanc'); ?></h1>
        <p class="description">
            <?php
            printf(
                /* translators: %s: link al pannello ticinoWEB CMS */
                esc_html__('Recapiti, orari di apertura, logo e testo "Chi siamo" si modificano in %s. Qui trovi i testi specifici della one-page e la scheda dei medici.', 'fratila-blanc'),
                '<a href="' . esc_url($cms_url) . '">ticinoWEB CMS</a>'
            );
            ?>
        </p>
        <?php settings_errors(); ?>
        <form method="post" action="options.php">
            <?php settings_fields('fratila_blanc_studio_group'); ?>

            <h2><?php esc_html_e('Intestazione (hero)', 'fratila-blanc'); ?></h2>
            <table class="form-table" role="presentation">
                <tr>
                    <th scope="row"><?php esc_html_e('Logo', 'fratila-blanc'); ?></th>
                    <td>
                        <label><input type="checkbox" name="fratila_blanc_studio[use_image_logo]" value="1" <?php checked($o['use_image_logo'], '1'); ?>> <?php esc_html_e('Usa il logo immagine di ticinoWEB CMS nell\'intestazione e nel footer', 'fratila-blanc'); ?></label>
                        <p class="description"><?php esc_html_e('Spento: logo testuale con il nome dello studio nel font del sito (consigliato). Il logo immagine resta usato per login, SEO e anteprime social.', 'fratila-blanc'); ?></p>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="fb_logo_prefix"><?php esc_html_e('Logo testuale', 'fratila-blanc'); ?></label></th>
                    <td>
                        <input type="text" class="regular-text" id="fb_logo_prefix" name="fratila_blanc_studio[logo_prefix]" value="<?php echo esc_attr($o['logo_prefix']); ?>" placeholder="<?php esc_attr_e('Studio Medico', 'fratila-blanc'); ?>">
                        <input type="text" class="regular-text" id="fb_logo_name" name="fratila_blanc_studio[logo_name]" value="<?php echo esc_attr($o['logo_name']); ?>" placeholder="<?php esc_attr_e('Cognome / nome in grassetto', 'fratila-blanc'); ?>">
                        <p class="description"><?php esc_html_e('Prima parte in chiaro e seconda in grassetto. Vuoti = nome del sito (Impostazioni → Generali).', 'fratila-blanc'); ?></p>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="fb_badge"><?php esc_html_e('Marchio e appartenenza', 'fratila-blanc'); ?></label></th>
                    <td>
                        <input type="text" class="small-text" id="fb_badge" name="fratila_blanc_studio[badge]" value="<?php echo esc_attr($o['badge']); ?>" placeholder="FMH">
                        <input type="text" class="regular-text" name="fratila_blanc_studio[affiliation]" value="<?php echo esc_attr($o['affiliation']); ?>" placeholder="<?php esc_attr_e('Swiss Medical Association', 'fratila-blanc'); ?>">
                        <input type="text" class="regular-text" name="fratila_blanc_studio[affiliation_sub]" value="<?php echo esc_attr($o['affiliation_sub']); ?>" placeholder="<?php esc_attr_e('Medicina Interna Generale', 'fratila-blanc'); ?>">
                        <input type="url" class="regular-text" name="fratila_blanc_studio[affiliation_url]" value="<?php echo esc_attr($o['affiliation_url']); ?>" placeholder="https://www.fmh.ch/">
                        <p class="description"><?php esc_html_e('Sigla (es. FMH), nome dell\'associazione, specialità e sito. Lasciali vuoti se non servono: il blocco non viene mostrato.', 'fratila-blanc'); ?></p>
                        <label><input type="checkbox" name="fratila_blanc_studio[show_fmh_logo]" value="1" <?php checked($o['show_fmh_logo'], '1'); ?>> <?php esc_html_e('Mostra il logo ufficiale FMH nel footer (solo se lo studio è FMH)', 'fratila-blanc'); ?></label>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="fb_hero_eyebrow"><?php esc_html_e('Sopratitolo', 'fratila-blanc'); ?></label></th>
                    <td><input type="text" class="regular-text" id="fb_hero_eyebrow" name="fratila_blanc_studio[hero_eyebrow]" value="<?php echo esc_attr($o['hero_eyebrow']); ?>"></td>
                </tr>
                <tr>
                    <th scope="row"><label for="fb_hero_title"><?php esc_html_e('Titolo principale (H1)', 'fratila-blanc'); ?></label></th>
                    <td>
                        <input type="text" class="regular-text" id="fb_hero_title" name="fratila_blanc_studio[hero_title]" value="<?php echo esc_attr($o['hero_title']); ?>">
                        <p class="description"><?php esc_html_e('Il carattere | indica l\'a capo (es. "Studio medico | Rossi").', 'fratila-blanc'); ?></p>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="fb_hero_text"><?php esc_html_e('Testo introduttivo', 'fratila-blanc'); ?></label></th>
                    <td><textarea class="large-text" id="fb_hero_text" name="fratila_blanc_studio[hero_text]"><?php echo esc_textarea($o['hero_text']); ?></textarea></td>
                </tr>
                <tr>
                    <th scope="row"><?php esc_html_e('Immagine di sfondo', 'fratila-blanc'); ?></th>
                    <td>
                        <input type="hidden" class="fb-media-id" name="fratila_blanc_studio[hero_image]" value="<?php echo esc_attr($o['hero_image']); ?>">
                        <button type="button" class="button fb-media-pick" data-type="image"><?php esc_html_e('Scegli immagine', 'fratila-blanc'); ?></button>
                        <button type="button" class="button-link-delete fb-media-clear"><?php esc_html_e('Rimuovi', 'fratila-blanc'); ?></button>
                        <?php $hi = $o['hero_image'] ? wp_get_attachment_image_url($o['hero_image'], 'medium') : ''; ?>
                        <img class="fb-media-preview" src="<?php echo esc_url($hi); ?>" alt="" <?php echo $hi ? '' : 'style="display:none"'; ?>>
                        <p class="description"><?php esc_html_e('Foto a tutta larghezza dietro l\'intestazione. Consigliato 1920×1280 px, toni chiari. Vuota = immagine inclusa nel tema.', 'fratila-blanc'); ?></p>
                    </td>
                </tr>
            </table>

            <h2><?php esc_html_e('Chi siamo e come raggiungerci', 'fratila-blanc'); ?></h2>
            <table class="form-table" role="presentation">
                <tr>
                    <th scope="row"><?php esc_html_e('Foto del luogo', 'fratila-blanc'); ?></th>
                    <td>
                        <input type="hidden" class="fb-media-id" name="fratila_blanc_studio[about_image]" value="<?php echo esc_attr($o['about_image']); ?>">
                        <button type="button" class="button fb-media-pick" data-type="image"><?php esc_html_e('Scegli immagine', 'fratila-blanc'); ?></button>
                        <button type="button" class="button-link-delete fb-media-clear"><?php esc_html_e('Rimuovi', 'fratila-blanc'); ?></button>
                        <?php $ai = $o['about_image'] ? wp_get_attachment_image_url($o['about_image'], 'medium') : ''; ?>
                        <img class="fb-media-preview" src="<?php echo esc_url($ai); ?>" alt="" <?php echo $ai ? '' : 'style="display:none"'; ?>>
                        <p class="description"><?php esc_html_e('Mostrata nella sezione Chi siamo sopra "Dove ci troviamo". Formato 16:9, almeno 1200 px. Vuota = il riquadro foto non viene mostrato.', 'fratila-blanc'); ?></p>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="fb_about_image_caption"><?php esc_html_e('Didascalia foto', 'fratila-blanc'); ?></label></th>
                    <td><input type="text" class="regular-text" id="fb_about_image_caption" name="fratila_blanc_studio[about_image_caption]" value="<?php echo esc_attr($o['about_image_caption']); ?>"></td>
                </tr>
                <tr>
                    <th scope="row"><label for="fb_phone_hours"><?php esc_html_e('Orari linee telefoniche', 'fratila-blanc'); ?></label></th>
                    <td>
                        <input type="text" class="regular-text" id="fb_phone_hours" name="fratila_blanc_studio[phone_hours]" value="<?php echo esc_attr($o['phone_hours']); ?>">
                        <p class="description"><?php esc_html_e('Gli orari di apertura dello studio si impostano in ticinoWEB CMS → Contatti.', 'fratila-blanc'); ?></p>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="fb_location_text"><?php esc_html_e('Dove si trova lo studio', 'fratila-blanc'); ?></label></th>
                    <td><textarea class="large-text" id="fb_location_text" name="fratila_blanc_studio[location_text]"><?php echo esc_textarea($o['location_text']); ?></textarea></td>
                </tr>
                <tr>
                    <th scope="row"><label for="fb_features"><?php esc_html_e('Servizi e accessibilità', 'fratila-blanc'); ?></label></th>
                    <td>
                        <textarea class="large-text" id="fb_features" name="fratila_blanc_studio[features]"><?php echo esc_textarea($o['features']); ?></textarea>
                        <p class="description"><?php esc_html_e('Una voce per riga (trasporti, posteggi, accesso disabili…).', 'fratila-blanc'); ?></p>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="fb_email_hin"><?php esc_html_e('Email HIN', 'fratila-blanc'); ?></label></th>
                    <td>
                        <input type="email" class="regular-text" id="fb_email_hin" name="fratila_blanc_studio[email_hin]" value="<?php echo esc_attr($o['email_hin']); ?>">
                        <p class="description"><?php esc_html_e('Casella sicura HIN per medici e istituzioni. Se in ticinoWEB CMS è compilata la "Email 2", ha la precedenza.', 'fratila-blanc'); ?></p>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="fb_maps_url"><?php esc_html_e('Link Google Maps', 'fratila-blanc'); ?></label></th>
                    <td><input type="url" class="regular-text" id="fb_maps_url" name="fratila_blanc_studio[maps_url]" value="<?php echo esc_attr($o['maps_url']); ?>"></td>
                </tr>
                <tr>
                    <th scope="row"><?php esc_html_e('Mappa incorporata', 'fratila-blanc'); ?></th>
                    <td><label><input type="checkbox" name="fratila_blanc_studio[show_map]" value="1" <?php checked($o['show_map'], '1'); ?>> <?php esc_html_e('Mostra la mappa Google nella sezione "Come raggiungerci"', 'fratila-blanc'); ?></label></td>
                </tr>
            </table>

            <p class="description">
                <?php
                printf(
                    /* translators: %s: link al pannello ticinoWEB CMS */
                    esc_html__('I loghi dei partner con i relativi link si gestiscono in %s → sezione Partner.', 'fratila-blanc'),
                    '<a href="' . esc_url($cms_url) . '">ticinoWEB CMS</a>'
                );
                ?>
            </p>

            <h2><?php esc_html_e('Sezione Contatti', 'fratila-blanc'); ?></h2>
            <table class="form-table" role="presentation">
                <tr>
                    <th scope="row"><label for="fb_contact_intro"><?php esc_html_e('Testo introduttivo', 'fratila-blanc'); ?></label></th>
                    <td><textarea class="large-text" id="fb_contact_intro" name="fratila_blanc_studio[contact_intro]"><?php echo esc_textarea($o['contact_intro']); ?></textarea></td>
                </tr>
                <tr>
                    <th scope="row"><label for="fb_contact_note"><?php esc_html_e('Nota sulla riservatezza', 'fratila-blanc'); ?></label></th>
                    <td><textarea class="large-text" id="fb_contact_note" name="fratila_blanc_studio[contact_note]"><?php echo esc_textarea($o['contact_note']); ?></textarea></td>
                </tr>
            </table>

            <h2><?php esc_html_e('Ricerca online (Google e assistenti AI)', 'fratila-blanc'); ?></h2>
            <p class="description"><?php esc_html_e('Questi dati servono solo ai dati strutturati del sito (scheda "studio medico"). Nome, indirizzo, telefono e orari arrivano da ticinoWEB CMS.', 'fratila-blanc'); ?></p>
            <table class="form-table" role="presentation">
                <tr>
                    <th scope="row"><label for="fb_schema_specialty"><?php esc_html_e('Specialità', 'fratila-blanc'); ?></label></th>
                    <td>
                        <select id="fb_schema_specialty" name="fratila_blanc_studio[schema_specialty]">
                            <?php foreach (fratila_blanc_specialty_choices() as $value => $label) : ?>
                                <option value="<?php echo esc_attr($value); ?>" <?php selected($o['schema_specialty'], $value); ?>><?php echo esc_html($label); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="fb_areas_served"><?php esc_html_e('Zone servite', 'fratila-blanc'); ?></label></th>
                    <td>
                        <input type="text" class="large-text" id="fb_areas_served" name="fratila_blanc_studio[areas_served]" value="<?php echo esc_attr($o['areas_served']); ?>">
                        <p class="description"><?php esc_html_e('Località separate da virgola (es. "Bellinzona, Giubiasco, Sementina").', 'fratila-blanc'); ?></p>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="fb_geo_lat"><?php esc_html_e('Coordinate', 'fratila-blanc'); ?></label></th>
                    <td>
                        <input type="text" class="small-text" id="fb_geo_lat" name="fratila_blanc_studio[geo_lat]" value="<?php echo esc_attr($o['geo_lat']); ?>" placeholder="46.1950">
                        <input type="text" class="small-text" name="fratila_blanc_studio[geo_lng]" value="<?php echo esc_attr($o['geo_lng']); ?>" placeholder="9.0200">
                        <p class="description"><?php esc_html_e('Latitudine e longitudine (facoltative: su Google Maps, tasto destro sul punto, si copiano i due numeri).', 'fratila-blanc'); ?></p>
                    </td>
                </tr>
            </table>

            <h2><?php esc_html_e('Medici (staff)', 'fratila-blanc'); ?></h2>
            <p class="description"><?php esc_html_e('Le schede senza nome non vengono mostrate. Massimo 4 medici.', 'fratila-blanc'); ?></p>
            <?php foreach ($staff as $i => $m) : ?>
                <div class="fb-staff">
                    <h3><?php printf(esc_html__('Medico %d', 'fratila-blanc'), $i + 1); ?></h3>
                    <table class="form-table" role="presentation">
                        <tr>
                            <th scope="row"><label for="fb_staff_name_<?php echo (int) $i; ?>"><?php esc_html_e('Nome', 'fratila-blanc'); ?></label></th>
                            <td><input type="text" class="regular-text" id="fb_staff_name_<?php echo (int) $i; ?>" name="fratila_blanc_studio[staff][<?php echo (int) $i; ?>][name]" value="<?php echo esc_attr($m['name']); ?>"></td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="fb_staff_role_<?php echo (int) $i; ?>"><?php esc_html_e('Ruolo / specialità', 'fratila-blanc'); ?></label></th>
                            <td><input type="text" class="regular-text" id="fb_staff_role_<?php echo (int) $i; ?>" name="fratila_blanc_studio[staff][<?php echo (int) $i; ?>][role]" value="<?php echo esc_attr($m['role']); ?>"></td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="fb_staff_lang_<?php echo (int) $i; ?>"><?php esc_html_e('Lingue parlate', 'fratila-blanc'); ?></label></th>
                            <td><input type="text" class="regular-text" id="fb_staff_lang_<?php echo (int) $i; ?>" name="fratila_blanc_studio[staff][<?php echo (int) $i; ?>][languages]" value="<?php echo esc_attr($m['languages']); ?>" placeholder="Italiano, Francese, …"></td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="fb_staff_pdf_<?php echo (int) $i; ?>"><?php esc_html_e('Attestato (PDF)', 'fratila-blanc'); ?></label></th>
                            <td>
                                <input type="url" class="regular-text fb-media-url" id="fb_staff_pdf_<?php echo (int) $i; ?>" name="fratila_blanc_studio[staff][<?php echo (int) $i; ?>][pdf]" value="<?php echo esc_attr($m['pdf']); ?>">
                                <button type="button" class="button fb-media-pick" data-type="application/pdf"><?php esc_html_e('Scegli PDF', 'fratila-blanc'); ?></button>
                                <p class="description"><?php esc_html_e('Facoltativo: se vuoto il link non viene mostrato.', 'fratila-blanc'); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><?php esc_html_e('Foto', 'fratila-blanc'); ?></th>
                            <td>
                                <input type="hidden" class="fb-media-id" name="fratila_blanc_studio[staff][<?php echo (int) $i; ?>][photo]" value="<?php echo esc_attr($m['photo']); ?>">
                                <button type="button" class="button fb-media-pick" data-type="image"><?php esc_html_e('Scegli foto', 'fratila-blanc'); ?></button>
                                <button type="button" class="button-link-delete fb-media-clear"><?php esc_html_e('Rimuovi', 'fratila-blanc'); ?></button>
                                <?php $ph = $m['photo'] ? wp_get_attachment_image_url($m['photo'], 'thumbnail') : ''; ?>
                                <img class="fb-media-preview" src="<?php echo esc_url($ph); ?>" alt="" <?php echo $ph ? '' : 'style="display:none"'; ?>>
                                <p class="description"><?php esc_html_e('Consigliato: quadrata, almeno 400×400 px. Vuota = avatar con le iniziali del medico.', 'fratila-blanc'); ?></p>
                            </td>
                        </tr>
                    </table>
                </div>
            <?php endforeach; ?>

            <?php submit_button(__('Salva contenuti', 'fratila-blanc')); ?>
        </form>
    </div>
    <?php
}
