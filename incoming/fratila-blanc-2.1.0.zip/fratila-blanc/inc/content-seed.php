<?php
/**
 * Seeder: prepara la struttura del sito alla prima attivazione del tema.
 * Crea la pagina Home (front-page) e la Privacy Policy, imposta home statica,
 * pagina privacy, fuso orario e formati data svizzeri, e abilita il metabox
 * SEO sulle pagine. NON scrive nessun dato del cliente (nome, recapiti, orari,
 * testi, medici, SEO): quelli si inseriscono in ticinoWEB CMS, nel pannello
 * "Studio medico" e in tW SEO.
 *
 * Gira SOLO:
 *   - all'attivazione del tema (after_switch_theme);
 *   - in admin_init per un amministratore quando cambia FRATILA_BLANC_SEED_VERSION;
 *   - su richiesta: admin.php?fratila_blanc_reseed=1&_wpnonce=<nonce 'fratila_blanc_reseed'>;
 *   - da WP-CLI: wp eval 'fratila_blanc_seed_content(false);' --url=<sito>
 * Non sovrascrive mai pagine o valori già presenti.
 *
 * @package Fratila_Blanc
 */

if (!defined('ABSPATH')) {
    exit;
}

define('FRATILA_BLANC_SEED_VERSION', '2.0.0');

add_action('after_switch_theme', 'fratila_blanc_seed_on_activation');
function fratila_blanc_seed_on_activation()
{
    fratila_blanc_seed_content(false);
}

add_action('admin_init', 'fratila_blanc_maybe_seed', 15);
function fratila_blanc_maybe_seed()
{
    if (wp_doing_ajax() || (defined('REST_REQUEST') && REST_REQUEST)) {
        return;
    }
    if (!current_user_can('manage_options')) {
        return;
    }
    $requested = false;
    if (isset($_GET['fratila_blanc_reseed'])) {
        $nonce = isset($_GET['_wpnonce']) ? sanitize_text_field(wp_unslash($_GET['_wpnonce'])) : '';
        if (!wp_verify_nonce($nonce, 'fratila_blanc_reseed')) {
            wp_die(esc_html__('Richiesta non valida: nonce mancante o scaduto.', 'fratila-blanc'), 403);
        }
        $requested = true;
    }
    if (!$requested && get_option('fratila_blanc_seed_version') === FRATILA_BLANC_SEED_VERSION) {
        return;
    }
    fratila_blanc_seed_content($requested);
    if ($requested) {
        wp_safe_redirect(remove_query_arg(array('fratila_blanc_reseed', '_wpnonce')));
        exit;
    }
}

/**
 * Imposta un'opzione solo se è vuota.
 */
function fratila_blanc_seed_option($name, $value)
{
    $current = get_option($name, null);
    if ($current === null || $current === '' || $current === array() || $current === false) {
        update_option($name, $value);
    }
}

/**
 * Seed della struttura. Idempotente.
 */
function fratila_blanc_seed_content($force = false)
{
    $first_run = get_option('fratila_blanc_seed_version', '') === '';

    if ($first_run) {
        update_option('timezone_string', 'Europe/Zurich');
        update_option('date_format', 'j F Y');
        update_option('time_format', 'H:i');
        fratila_blanc_seed_option('ticinoweb_palette_primary', '#14607a');
    }

    $author_id = get_current_user_id();
    if (!$author_id) {
        $admins    = get_users(array('role' => 'administrator', 'number' => 1, 'fields' => 'ID', 'orderby' => 'ID'));
        $author_id = !empty($admins) ? (int) $admins[0] : 0;
    }

    $home_id = fratila_blanc_ensure_page('home', 'Home', '', $author_id);
    if ($home_id && (get_option('show_on_front') !== 'page' || (int) get_option('page_on_front') !== $home_id)) {
        update_option('show_on_front', 'page');
        update_option('page_on_front', $home_id);
    }

    $privacy_id = fratila_blanc_ensure_page('privacy-policy', 'Privacy Policy', fratila_blanc_privacy_content(), $author_id);
    if ($privacy_id) {
        if (!(int) get_option('wp_page_for_privacy_policy')) {
            update_option('wp_page_for_privacy_policy', $privacy_id);
        }
        fratila_blanc_seed_option('tw_privacy_policy_url', get_permalink($privacy_id));
    }

    fratila_blanc_seed_option('tw_seo_enable_metabox', array('page'));

    if ($home_id || $privacy_id) {
        flush_rewrite_rules(false);
    }
    update_option('fratila_blanc_seed_version', FRATILA_BLANC_SEED_VERSION);
}

/**
 * Crea la pagina se non esiste (anche in bozza/privata: non la duplica).
 *
 * @return int ID pagina, 0 se non creata.
 */
function fratila_blanc_ensure_page($slug, $title, $content, $author_id, $template = '')
{
    global $wpdb;
    $existing = get_page_by_path($slug, OBJECT, 'page');
    if (!$existing) {
        $post_id = $wpdb->get_var($wpdb->prepare(
            "SELECT ID FROM {$wpdb->posts} WHERE post_name = %s AND post_type = 'page' AND post_status != 'trash' LIMIT 1",
            $slug
        ));
        if ($post_id) {
            $existing = get_post($post_id);
        }
    }
    if ($existing) {
        return (int) $existing->ID;
    }
    $new_id = wp_insert_post(array(
        'post_type'    => 'page',
        'post_status'  => 'publish',
        'post_title'   => $title,
        'post_name'    => $slug,
        'post_content' => $content,
        'post_author'  => $author_id,
        'comment_status' => 'closed',
        'ping_status'    => 'closed',
    ), true);
    if (is_wp_error($new_id) || !$new_id) {
        return 0;
    }
    if ($template) {
        update_post_meta($new_id, '_wp_page_template', $template);
    }
    return (int) $new_id;
}

/**
 * Testo della Privacy Policy (LPD svizzera) costruito con i dati del sito
 * (nome, medici, indirizzo, telefono, email) al momento della creazione.
 * Da far verificare al cliente. Per rigenerarlo dopo aver cambiato i dati:
 * wp eval 'wp_update_post(array("ID" => <id pagina>, "post_content" => fratila_blanc_privacy_content()));'
 */
function fratila_blanc_privacy_content()
{
    $site    = fratila_blanc_get_site_data();
    $contact = $site['contact'];
    $names   = array();
    foreach ($site['staff'] as $member) {
        $names[] = $member['name'];
    }
    $brand = $site['brand'] !== '' ? $site['brand'] : get_bloginfo('name');

    $identity = '<p><strong>' . esc_html($brand) . '</strong>';
    if ($names) {
        $identity .= '<br>' . esc_html(wp_sprintf('%l', $names));
    }
    if ($contact['address'] !== '') {
        $identity .= '<br>' . esc_html($contact['address']) . ', Svizzera';
    }
    if ($contact['phone_1'] !== '') {
        $identity .= '<br>Tel. ' . esc_html($contact['phone_1']);
    }
    if ($contact['email'] !== '') {
        $identity .= '<br><a href="mailto:' . esc_attr($contact['email']) . '">' . esc_html($contact['email']) . '</a>';
    }
    $identity .= '</p>';

    $rights_mail = $contact['email'] !== ''
        ? ', scrivendo a <a href="mailto:' . esc_attr($contact['email']) . '">' . esc_html($contact['email']) . '</a>'
        : '';
    $hin = $contact['email_hin'] !== '' ? ' o, per medici e istituzioni, tramite la casella sicura HIN' : '';

    return '<div class="fb-legal">
<p class="fb-legal__updated">Ultimo aggiornamento: ' . esc_html(date_i18n('j F Y')) . '</p>
<p>La presente informativa descrive come ' . esc_html($brand) . ' tratta i dati personali raccolti tramite questo sito, nel rispetto della Legge federale svizzera sulla protezione dei dati (LPD) e, ove applicabile, del Regolamento generale europeo sulla protezione dei dati (GDPR). Il trattamento dei dati sanitari dei pazienti nell’ambito della cura è disciplinato dalla legislazione sanitaria e dal segreto medico e non avviene tramite questo sito.</p>
<h2>1. Titolare del trattamento</h2>' . $identity . '
<h2>2. Dati trattati</h2>
<p>Il sito non contiene moduli di raccolta dati. Se ci scrivi via email trattiamo i dati che ci fornisci volontariamente (nome, indirizzo email, contenuto del messaggio) al solo scopo di risponderti. Ti chiediamo di <strong>non inviare referti, diagnosi o altri dati sanitari via email ordinaria</strong>: per comunicazioni mediche contattaci telefonicamente' . $hin . '.</p>
<p>Durante la navigazione il server registra dati tecnici (indirizzo IP, data e ora, pagina richiesta, browser e dispositivo) necessari al funzionamento e alla sicurezza del sito.</p>
<h2>3. Finalità e base giuridica</h2>
<ul><li>rispondere alle richieste di informazioni e di appuntamento ricevute via email o telefono;</li><li>garantire il funzionamento, la sicurezza e la prevenzione degli abusi del sito;</li><li>adempiere a obblighi legali.</li></ul>
<h2>4. Servizi di terzi</h2>
<p>Il sito può incorporare una mappa di Google Maps (Google Ireland Ltd.): al caricamento della mappa Google può ricevere dati tecnici e impostare propri cookie secondo la sua informativa. I caratteri tipografici sono caricati da Google Fonts. Il sito non utilizza cookie di profilazione o di marketing.</p>
<h2>5. Comunicazione dei dati</h2>
<p>I dati possono essere trattati da fornitori tecnici strettamente necessari (hosting, posta elettronica, manutenzione del sito), vincolati alla riservatezza. Non vendiamo né cediamo dati personali a terzi per finalità commerciali.</p>
<h2>6. Conservazione</h2>
<p>I messaggi ricevuti via email sono conservati per il tempo necessario a gestire la richiesta e poi eliminati, salvo obblighi legali di conservazione.</p>
<h2>7. Diritti</h2>
<p>Nei limiti previsti dalla legge puoi chiedere l’accesso, la rettifica, la cancellazione o la limitazione del trattamento dei tuoi dati e opporti a determinati trattamenti' . $rights_mail . '. Puoi inoltre rivolgerti all’Incaricato federale della protezione dei dati e della trasparenza (IFPDT).</p>
<h2>8. Sicurezza e modifiche</h2>
<p>Adottiamo misure tecniche e organizzative adeguate al rischio. Questa informativa può essere aggiornata in caso di modifiche al sito, ai servizi o alla normativa.</p>
</div>';
}
