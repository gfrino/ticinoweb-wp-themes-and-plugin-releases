/**
 * Pannello "Studio medico": selettore media per foto, logo partner e PDF.
 */
(function ($) {
  'use strict';
  if (!window.wp || !wp.media) return;

  $(document).on('click', '.fb-media-pick', function (e) {
    e.preventDefault();
    var btn = $(this);
    var wrap = btn.closest('td');
    var type = btn.data('type') || 'image';
    var frame = wp.media({
      title: type === 'image' ? 'Scegli immagine' : 'Scegli PDF',
      library: { type: type },
      multiple: false,
      button: { text: 'Usa questo file' }
    });
    frame.on('select', function () {
      var att = frame.state().get('selection').first().toJSON();
      if (type === 'image') {
        wrap.find('.fb-media-id').val(att.id);
        var url = (att.sizes && (att.sizes.medium || att.sizes.thumbnail)) ? (att.sizes.medium || att.sizes.thumbnail).url : att.url;
        wrap.find('.fb-media-preview').attr('src', url).show();
      } else {
        wrap.find('.fb-media-url').val(att.url);
      }
    });
    frame.open();
  });

  $(document).on('click', '.fb-media-clear', function (e) {
    e.preventDefault();
    var wrap = $(this).closest('td');
    wrap.find('.fb-media-id').val('0');
    wrap.find('.fb-media-preview').attr('src', '').hide();
  });
})(jQuery);
