<?php
/**
 * Pagine standard (es. Privacy Policy).
 *
 * @package Fratila_Blanc
 */
get_header();
?>
<main id="main" class="fb-main fb-page">
	<div class="fb-container fb-page__inner">
		<?php while (have_posts()) : the_post(); ?>
			<article <?php post_class('fb-article'); ?>>
				<header class="fb-page__header">
					<p class="fb-eyebrow"><?php echo esc_html(get_bloginfo('name')); ?></p>
					<h1 class="fb-page__title"><?php the_title(); ?></h1>
				</header>
				<div class="fb-prose">
					<?php the_content(); ?>
				</div>
				<p class="fb-page__back"><a class="fb-btn fb-btn--ghost" href="<?php echo esc_url(home_url('/')); ?>">&larr; <?php esc_html_e('Torna alla home', 'fratila-blanc'); ?></a></p>
			</article>
		<?php endwhile; ?>
	</div>
</main>
<?php get_footer(); ?>
