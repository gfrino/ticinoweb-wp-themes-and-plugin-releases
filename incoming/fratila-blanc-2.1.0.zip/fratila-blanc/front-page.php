<?php
/**
 * One-page: hero, chi siamo, medici, dove siamo, contatti.
 *
 * @package Fratila_Blanc
 */
$site    = fratila_blanc_get_site_data();
$hero    = $site['hero'];
$about   = $site['about'];
$staff   = $site['staff'];
$contact = $site['contact'];
$aff     = $site['affiliation'];
$map_query   = rawurlencode(preg_replace('/\s+/', ' ', $contact['address'] . ', Svizzera'));

get_header();
?>
<main id="main" class="fb-main">

	<!-- ═══════ HERO ═══════ -->
	<section class="fb-hero" aria-labelledby="fb-hero-title">
		<div class="fb-hero__media" aria-hidden="true">
			<?php if ($hero['image']) : ?>
				<?php echo wp_get_attachment_image($hero['image'], 'full', false, array('class' => 'fb-hero__img', 'alt' => '', 'fetchpriority' => 'high', 'decoding' => 'async', 'sizes' => '100vw')); ?>
			<?php else : ?>
				<?php $img = get_stylesheet_directory_uri() . '/assets/img/hero-'; ?>
				<picture>
					<source type="image/webp" srcset="<?php echo esc_url($img . '800.webp'); ?> 800w, <?php echo esc_url($img . '1280.webp'); ?> 1280w, <?php echo esc_url($img . '1920.webp'); ?> 1920w" sizes="100vw">
					<img class="fb-hero__img" src="<?php echo esc_url($img . '1280.jpg'); ?>" srcset="<?php echo esc_url($img . '800.jpg'); ?> 800w, <?php echo esc_url($img . '1280.jpg'); ?> 1280w, <?php echo esc_url($img . '1920.jpg'); ?> 1920w" sizes="100vw" width="1920" height="1279" alt="" fetchpriority="high" decoding="async">
				</picture>
			<?php endif; ?>
			<div class="fb-hero__overlay"></div>
		</div>
		<div class="fb-container fb-hero__grid">
			<div class="fb-hero__content">
				<?php if ($hero['eyebrow'] || $aff['badge']) : ?>
					<p class="fb-eyebrow"><?php if ($aff['badge']) : ?><span class="fb-badge"><?php echo esc_html($aff['badge']); ?></span> <?php endif; ?><?php echo esc_html($hero['eyebrow']); ?></p>
				<?php endif; ?>
				<h1 class="fb-hero__title" id="fb-hero-title"><?php echo fratila_blanc_title_html($hero['title']); ?></h1>
				<?php if ($hero['text']) : ?>
					<p class="fb-hero__text"><?php echo esc_html($hero['text']); ?></p>
				<?php endif; ?>
				<div class="fb-hero__actions">
					<?php if ($contact['phone_1'] !== '') : ?>
						<a class="fb-btn fb-btn--primary fb-btn--lg" href="<?php echo esc_attr(fratila_blanc_tel_href($contact['phone_1'])); ?>"><?php esc_html_e('Chiama lo studio', 'fratila-blanc'); ?></a>
					<?php endif; ?>
					<?php if ($contact['address'] !== '') : ?>
						<a class="fb-btn fb-btn--ghost fb-btn--lg" href="#dove-siamo"><?php esc_html_e('Come raggiungerci', 'fratila-blanc'); ?></a>
					<?php endif; ?>
				</div>
				<?php if ($about['partners']) : ?>
				<ul class="fb-hero__partners" aria-label="<?php esc_attr_e('Partner', 'fratila-blanc'); ?>">
					<?php foreach ($about['partners'] as $partner) : ?>
						<?php $logo_html = '<img class="fb-hero__partner-logo" src="' . esc_url($partner['logo']) . '" alt="' . esc_attr($partner['name']) . '" loading="lazy" decoding="async">'; ?>
						<li>
							<?php if ($partner['url']) : ?>
								<a class="fb-hero__partner" href="<?php echo esc_url($partner['url']); ?>" target="_blank" rel="noopener noreferrer" title="<?php echo esc_attr($partner['name']); ?>"><?php echo $logo_html; ?></a>
							<?php else : ?>
								<span class="fb-hero__partner"><?php echo $logo_html; ?></span>
							<?php endif; ?>
						</li>
					<?php endforeach; ?>
				</ul>
				<?php endif; ?>
			</div>

			<?php if ($about['hours'] || $about['phone_hours'] || $contact['phone_1'] !== '' || $contact['address'] !== '') : ?>
			<aside class="fb-card fb-hero__card" aria-label="<?php esc_attr_e('Orari e recapiti', 'fratila-blanc'); ?>">
				<h2 class="fb-card__title"><?php esc_html_e('Orari e recapiti', 'fratila-blanc'); ?></h2>
				<dl class="fb-dl">
					<?php if ($about['hours']) : ?>
						<div>
							<dt><?php esc_html_e('Studio', 'fratila-blanc'); ?></dt>
							<dd>
								<?php foreach ($about['hours'] as $row) : ?>
									<span class="fb-dl__row"><strong><?php echo esc_html($row['days']); ?></strong> <?php echo esc_html($row['hours']); ?></span>
								<?php endforeach; ?>
							</dd>
						</div>
					<?php endif; ?>
					<?php if ($about['phone_hours']) : ?>
						<div>
							<dt><?php esc_html_e('Linee telefoniche', 'fratila-blanc'); ?></dt>
							<dd><?php echo esc_html($about['phone_hours']); ?></dd>
						</div>
					<?php endif; ?>
					<?php if ($contact['phone_1'] !== '') : ?>
					<div>
						<dt><?php esc_html_e('Telefono', 'fratila-blanc'); ?></dt>
						<dd>
							<a href="<?php echo esc_attr(fratila_blanc_tel_href($contact['phone_1'])); ?>"><?php echo esc_html($contact['phone_1']); ?></a>
							<?php if ($contact['phone_2']) : ?>
								<br><a href="<?php echo esc_attr(fratila_blanc_tel_href($contact['phone_2'])); ?>"><?php echo esc_html($contact['phone_2']); ?></a>
							<?php endif; ?>
						</dd>
					</div>
					<?php endif; ?>
					<?php if ($contact['address'] !== '') : ?>
					<div>
						<dt><?php esc_html_e('Indirizzo', 'fratila-blanc'); ?></dt>
						<dd><?php echo fratila_blanc_address_html($contact['address']); ?></dd>
					</div>
					<?php endif; ?>
				</dl>
				<?php if ($about['hours_note']) : ?>
					<p class="fb-card__note"><?php echo esc_html($about['hours_note']); ?></p>
				<?php endif; ?>
			</aside>
			<?php endif; ?>
		</div>
	</section>

	<!-- ═══════ CHI SIAMO ═══════ -->
	<?php if ($about['text'] !== '' || $about['features'] || $about['location_text'] || $about['image'] || $aff['badge'] || $aff['name'] || $aff['sub']) : ?>
	<section class="fb-section fb-about" id="chi-siamo" aria-labelledby="fb-about-title">
		<div class="fb-container">
			<div class="fb-about__grid">
				<div class="fb-about__text fb-reveal">
					<p class="fb-eyebrow"><?php esc_html_e('Lo studio', 'fratila-blanc'); ?></p>
					<h2 class="fb-section__title" id="fb-about-title"><?php echo esc_html($about['title'] !== '' ? $about['title'] : __('Chi siamo', 'fratila-blanc')); ?></h2>
					<?php if ($about['text'] !== '') : ?><div class="fb-prose"><?php echo wp_kses_post(wpautop(esc_html($about['text']))); ?></div><?php endif; ?>
					<?php if ($aff['badge'] || $aff['name'] || $aff['sub']) : ?>
					<div class="fb-about__logos">
						<span class="fb-fmh"<?php echo $aff['name'] ? ' title="' . esc_attr($aff['name']) . '"' : ''; ?>>
							<?php if ($aff['badge']) : ?><span class="fb-badge fb-badge--lg"><?php echo esc_html($aff['badge']); ?></span><?php endif; ?>
							<?php if ($aff['name'] || $aff['sub']) : ?><span><?php echo esc_html($aff['name']); ?><?php if ($aff['name'] && $aff['sub']) : ?><br><?php endif; ?><?php if ($aff['sub']) : ?><small><?php echo esc_html($aff['sub']); ?></small><?php endif; ?></span><?php endif; ?>
						</span>
					</div>
					<?php endif; ?>
					<?php if ($about['features']) : ?>
						<ul class="fb-features fb-features--grid fb-reveal">
							<?php foreach ($about['features'] as $feature) : ?>
								<li>
									<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 6 9 17l-5-5"/></svg>
									<span><?php echo esc_html($feature); ?></span>
								</li>
							<?php endforeach; ?>
						</ul>
					<?php endif; ?>
				</div>

				<div class="fb-about__side">
					<?php if ($about['image']) : ?>
					<figure class="fb-about__figure fb-reveal">
						<?php
						$about_alt = trim((string) get_post_meta($about['image'], '_wp_attachment_image_alt', true));
						echo wp_get_attachment_image($about['image'], 'large', false, array('class' => 'fb-about__photo', 'alt' => $about_alt !== '' ? $about_alt : $about['image_caption'], 'loading' => 'lazy', 'sizes' => '(max-width: 1024px) 100vw, 480px'));
						?>
						<?php if ($about['image_caption']) : ?>
							<figcaption class="fb-about__caption">
								<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>
								<?php echo esc_html($about['image_caption']); ?>
							</figcaption>
						<?php endif; ?>
					</figure>
					<?php endif; ?>
					<?php if ($about['location_text']) : ?>
						<div class="fb-card fb-reveal">
							<h3 class="fb-card__title"><?php esc_html_e('Dove ci troviamo', 'fratila-blanc'); ?></h3>
							<div class="fb-prose fb-prose--sm"><?php echo wp_kses_post(wpautop(esc_html($about['location_text']))); ?></div>
						</div>
					<?php endif; ?>
				</div>
			</div>
		</div>
	</section>
	<?php endif; ?>

	<!-- ═══════ MEDICI ═══════ -->
	<?php if ($staff) : ?>
	<section class="fb-section fb-section--alt fb-staff" id="medici" aria-labelledby="fb-staff-title">
		<div class="fb-container">
			<header class="fb-section__header fb-reveal">
				<p class="fb-eyebrow"><?php esc_html_e('Staff', 'fratila-blanc'); ?></p>
				<h2 class="fb-section__title" id="fb-staff-title"><?php esc_html_e('I nostri medici', 'fratila-blanc'); ?></h2>
			</header>
			<div class="fb-staff__grid">
				<?php foreach ($staff as $i => $member) : ?>
					<?php
					$pdf   = fratila_blanc_staff_pdf_url($member);
					$langs = array_filter(array_map('trim', preg_split('/[,–\/]+/u', (string) $member['languages'])));
					?>
					<article class="fb-card fb-doctor fb-reveal">
						<div class="fb-doctor__photo">
							<?php if (!empty($member['photo'])) : ?>
								<?php echo wp_get_attachment_image((int) $member['photo'], 'medium', false, array('alt' => $member['name'], 'loading' => 'lazy')); ?>
							<?php else : ?>
								<span class="fb-doctor__avatar" aria-hidden="true">
									<span class="fb-doctor__initials"><?php echo esc_html(fratila_blanc_initials($member['name'])); ?></span>
									<span class="fb-doctor__mark">
										<svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M9 3h6v6h6v6h-6v6H9v-6H3V9h6z"/></svg>
									</span>
								</span>
							<?php endif; ?>
						</div>
						<div class="fb-doctor__body">
							<h3 class="fb-doctor__name"><?php echo esc_html($member['name']); ?></h3>
							<?php if ($member['role']) : ?>
								<p class="fb-doctor__role"><?php echo esc_html($member['role']); ?></p>
							<?php endif; ?>
							<?php if ($langs) : ?>
								<p class="fb-doctor__label"><?php esc_html_e('Lingue parlate', 'fratila-blanc'); ?></p>
								<ul class="fb-chips">
									<?php foreach ($langs as $lang) : ?>
										<li><?php echo esc_html($lang); ?></li>
									<?php endforeach; ?>
								</ul>
							<?php endif; ?>
							<?php if ($pdf) : ?>
								<a class="fb-doctor__pdf" href="<?php echo esc_url($pdf); ?>" target="_blank" rel="noopener">
									<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6"/><path d="M9 15h6M9 11h2"/></svg>
									<?php esc_html_e('Attestato (PDF)', 'fratila-blanc'); ?>
								</a>
							<?php endif; ?>
						</div>
					</article>
				<?php endforeach; ?>
			</div>
		</div>
	</section>
	<?php endif; ?>

	<!-- ═══════ DOVE SIAMO ═══════ -->
	<?php if ($contact['address'] !== '') : ?>
	<section class="fb-section fb-where" id="dove-siamo" aria-labelledby="fb-where-title">
		<div class="fb-container">
			<header class="fb-section__header fb-reveal">
				<p class="fb-eyebrow"><?php esc_html_e('Dove siamo', 'fratila-blanc'); ?></p>
				<h2 class="fb-section__title" id="fb-where-title"><?php esc_html_e('Come raggiungerci', 'fratila-blanc'); ?></h2>
				<p class="fb-section__lead"><?php echo esc_html($contact['address']); ?></p>
			</header>
			<div class="fb-where__grid">
				<div class="fb-card fb-where__card fb-reveal">
					<ul class="fb-contact-list">
						<li>
							<span class="fb-contact-list__icon" aria-hidden="true"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg></span>
							<div><span class="fb-contact-list__label"><?php esc_html_e('Indirizzo', 'fratila-blanc'); ?></span><address><?php echo fratila_blanc_address_html($contact['address']); ?></address></div>
						</li>
						<?php if ($contact['phone_1'] !== '') : ?>
						<li>
							<span class="fb-contact-list__icon" aria-hidden="true"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/></svg></span>
							<div>
								<span class="fb-contact-list__label"><?php esc_html_e('Telefono', 'fratila-blanc'); ?></span>
								<a href="<?php echo esc_attr(fratila_blanc_tel_href($contact['phone_1'])); ?>"><?php echo esc_html($contact['phone_1']); ?></a>
								<?php if ($contact['phone_2']) : ?><br><a href="<?php echo esc_attr(fratila_blanc_tel_href($contact['phone_2'])); ?>"><?php echo esc_html($contact['phone_2']); ?></a><?php endif; ?>
								<?php if ($about['phone_hours']) : ?><br><small><?php echo esc_html($about['phone_hours']); ?></small><?php endif; ?>
							</div>
						</li>
						<?php endif; ?>
						<?php if ($contact['email'] !== '' || $contact['email_hin'] !== '') : ?>
						<li>
							<span class="fb-contact-list__icon" aria-hidden="true"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg></span>
							<div>
								<span class="fb-contact-list__label"><?php esc_html_e('Email', 'fratila-blanc'); ?></span>
								<?php if ($contact['email'] !== '') : ?><a href="mailto:<?php echo esc_attr($contact['email']); ?>"><?php echo esc_html($contact['email']); ?></a><?php endif; ?>
								<?php if ($contact['email_hin']) : ?><?php if ($contact['email'] !== '') : ?><br><?php endif; ?><a href="mailto:<?php echo esc_attr($contact['email_hin']); ?>"><?php echo esc_html($contact['email_hin']); ?></a> <small><?php esc_html_e('(HIN, per medici e istituzioni)', 'fratila-blanc'); ?></small><?php endif; ?>
							</div>
						</li>
						<?php endif; ?>
					</ul>
					<?php if ($contact['maps_url']) : ?>
						<a class="fb-btn fb-btn--primary" href="<?php echo esc_url($contact['maps_url']); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e('Apri in Google Maps', 'fratila-blanc'); ?></a>
					<?php endif; ?>
				</div>

				<?php if ($contact['show_map']) : ?>
					<div class="fb-map fb-reveal">
						<iframe
							title="<?php echo esc_attr(sprintf(__('Mappa: %s', 'fratila-blanc'), trim($site['brand'] . ', ' . preg_replace('/\s+/', ' ', $contact['address']), ' ,'))); ?>"
							src="https://www.google.com/maps?q=<?php echo $map_query; ?>&amp;output=embed&amp;hl=it"
							loading="lazy"
							referrerpolicy="no-referrer-when-downgrade"
							allowfullscreen></iframe>
					</div>
				<?php endif; ?>
			</div>
		</div>
	</section>
	<?php endif; ?>

	<!-- ═══════ CONTATTI ═══════ -->
	<?php if ($contact['email'] !== '' || $contact['email_hin'] !== '') : ?>
	<section class="fb-section fb-section--alt fb-contact" id="contatti" aria-labelledby="fb-contact-title">
		<div class="fb-container fb-contact__grid">
			<div class="fb-contact__intro fb-reveal">
				<p class="fb-eyebrow"><?php esc_html_e('Contattaci', 'fratila-blanc'); ?></p>
				<h2 class="fb-section__title" id="fb-contact-title"><?php esc_html_e('Scriveteci via email', 'fratila-blanc'); ?></h2>
				<?php if ($contact['intro'] !== '') : ?><p><?php echo esc_html($contact['intro']); ?></p><?php endif; ?>
				<?php if ($contact['note'] !== '') : ?><p class="fb-contact__privacy-note"><?php echo esc_html($contact['note']); ?></p><?php endif; ?>
			</div>

			<div class="fb-card fb-contact__card fb-reveal">
				<ul class="fb-contact-list">
					<?php if ($contact['email'] !== '') : ?>
					<li>
						<span class="fb-contact-list__icon" aria-hidden="true"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg></span>
						<div>
							<span class="fb-contact-list__label"><?php esc_html_e('Email', 'fratila-blanc'); ?></span>
							<a class="fb-contact__email" href="mailto:<?php echo esc_attr($contact['email']); ?>"><?php echo esc_html($contact['email']); ?></a>
							<small><?php esc_html_e('Informazioni generali e richieste amministrative', 'fratila-blanc'); ?></small>
						</div>
					</li>
					<?php endif; ?>
					<?php if ($contact['email_hin']) : ?>
					<li>
						<span class="fb-contact-list__icon" aria-hidden="true"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg></span>
						<div>
							<span class="fb-contact-list__label"><?php esc_html_e('Email HIN', 'fratila-blanc'); ?></span>
							<a class="fb-contact__email" href="mailto:<?php echo esc_attr($contact['email_hin']); ?>"><?php echo esc_html($contact['email_hin']); ?></a>
							<small><?php esc_html_e('Casella sicura per medici e istituzioni sanitarie', 'fratila-blanc'); ?></small>
						</div>
					</li>
					<?php endif; ?>
				</ul>
				<?php $mail_to = $contact['email'] !== '' ? $contact['email'] : $contact['email_hin']; ?>
				<a class="fb-btn fb-btn--primary fb-btn--lg" href="mailto:<?php echo esc_attr($mail_to); ?>"><?php esc_html_e('Scrivi a', 'fratila-blanc'); ?> <?php echo esc_html($mail_to); ?></a>
			</div>
		</div>
	</section>
	<?php endif; ?>

</main>
<?php get_footer(); ?>
