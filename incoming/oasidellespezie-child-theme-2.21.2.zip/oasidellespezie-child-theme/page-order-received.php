<?php
/**
 * WooCommerce order confirmation surface.
 *
 * WooCommerce remains the only source of order data. The shortcode detects the
 * order-received endpoint and renders its authenticated thank-you details.
 *
 * @package OasiDelleSpezieChild
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

$shop_url = function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'shop' ) : '';
?>

<main id="primary" class="oasi-checkout oasi-order-confirmation">
	<header class="oasi-order-confirmation__head">
		<div class="oasi-container oasi-order-confirmation__head-inner">
			<span class="oasi-checkout-kicker"><?php esc_html_e( 'Ordine completato', 'oasidellespezie-child-theme' ); ?></span>
			<h1><?php esc_html_e( 'Grazie, il tuo ordine è stato ricevuto', 'oasidellespezie-child-theme' ); ?></h1>
			<p><?php esc_html_e( 'Qui trovi il riepilogo dell’acquisto e tutte le informazioni utili.', 'oasidellespezie-child-theme' ); ?></p>
		</div>
	</header>

	<section class="oasi-checkout-body oasi-order-confirmation__body" aria-label="<?php esc_attr_e( 'Conferma e dettagli dell’ordine', 'oasidellespezie-child-theme' ); ?>">
		<div class="oasi-container">
			<div class="oasi-order-confirmation__surface">
				<?php echo do_shortcode( '[woocommerce_checkout]' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Trusted WooCommerce endpoint output. ?>

				<?php if ( '' !== $shop_url ) : ?>
					<div class="oasi-order-confirmation__actions">
						<a class="button" href="<?php echo esc_url( $shop_url ); ?>"><?php esc_html_e( 'Torna allo shop', 'oasidellespezie-child-theme' ); ?></a>
					</div>
				<?php endif; ?>
			</div>
		</div>
	</section>
</main>

<?php get_footer(); ?>
