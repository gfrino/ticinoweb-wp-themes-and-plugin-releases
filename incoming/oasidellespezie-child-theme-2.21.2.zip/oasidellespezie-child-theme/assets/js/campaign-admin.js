(function () {
	'use strict';

	function setEmpty(preview) {
		var label = document.createElement('span');
		label.textContent = preview.getAttribute('data-empty-label') || 'Nessuna immagine selezionata';
		preview.replaceChildren(label);
	}

	document.addEventListener('click', function (event) {
		var target = event.target;
		if (!(target instanceof Element)) {
			return;
		}

		var pick = target.closest('[data-oasi-campaign-media-pick]');
		var clear = target.closest('[data-oasi-campaign-media-clear]');
		if (!pick && !clear) {
			return;
		}

		var field = (pick || clear).closest('[data-oasi-campaign-media]');
		var input = field && field.querySelector('[data-oasi-campaign-media-input]');
		var preview = field && field.querySelector('[data-oasi-campaign-preview]');
		if (!field || !input || !preview) {
			return;
		}

		event.preventDefault();
		if (clear) {
			input.value = '';
			setEmpty(preview);
			return;
		}

		if (!window.wp || !window.wp.media) {
			return;
		}

		var storage = field.getAttribute('data-storage') || 'id';
		var frame = window.wp.media({
			title: 'Seleziona l’immagine',
			button: { text: 'Usa questa immagine' },
			library: { type: 'image' },
			multiple: false
		});

		frame.on('select', function () {
			var attachment = frame.state().get('selection').first().toJSON();
			var previewUrl = attachment.sizes && attachment.sizes.medium
				? attachment.sizes.medium.url
				: attachment.url;
			var image = document.createElement('img');
			image.src = previewUrl;
			image.alt = '';
			input.value = storage === 'id' ? attachment.id : attachment.url;
			preview.replaceChildren(image);
		});

		frame.open();
	});
}());
