/**
 * AJAX catalog interactions for Oasi delle Spezie.
 *
 * The server-rendered GET form remains the complete no-JavaScript fallback.
 */

(function() {
	'use strict';

	const shop = document.querySelector('[data-oasi-shop]');
	if (!shop) return;

	const form = shop.querySelector('[data-oasi-shop-form]');
	const results = shop.querySelector('[data-oasi-shop-results]');
	const drawer = shop.querySelector('[data-oasi-filter-drawer]');
	const overlay = shop.querySelector('.oasi-shop__drawer-overlay');
	const openButton = shop.querySelector('[data-oasi-filter-open]');
	const searchInput = shop.querySelector('[data-oasi-search]');
	const orderSelect = shop.querySelector('[data-oasi-orderby]');
	const filterCount = shop.querySelector('[data-oasi-filter-count]');
	const config = window.oasiShopConfig || {
		partialParam: 'oasi_shop_partial',
		loadingText: 'Aggiornamento prodotti…',
		errorText: 'Impossibile aggiornare il catalogo.',
	};

	if (!form || !results) return;

	let activeRequest = null;
	let searchTimer = 0;
	let lastFocusedElement = null;

	function getArchivePage(urlValue) {
		const url = new URL(urlValue, window.location.href);
		const queryPage = Number.parseInt(url.searchParams.get('paged') || url.searchParams.get('product-page') || '', 10);
		if (Number.isInteger(queryPage) && queryPage > 0) return queryPage;
		const pathPage = url.pathname.match(/\/page\/(\d+)\/?$/);
		return pathPage ? Number.parseInt(pathPage[1], 10) : 1;
	}

	let activePage = getArchivePage(window.location.href);
	if (history.replaceState) {
		history.replaceState(Object.assign({}, history.state, { oasiShopPage: activePage }), '', window.location.href);
	}

	function buildFilterUrl() {
		const url = new URL(form.action, window.location.href);
		const formData = new FormData(form);
		formData.forEach(function(value, key) {
			if (String(value).trim() !== '' && !(key === 'orderby' && value === 'menu_order')) {
				url.searchParams.append(key, value);
			}
		});
		return url;
	}

	function setLoading(isLoading) {
		results.setAttribute('aria-busy', isLoading ? 'true' : 'false');
		if (isLoading) {
			results.setAttribute('aria-label', config.loadingText);
		} else {
			results.removeAttribute('aria-label');
		}
	}

	function syncControlsFromUrl(urlValue) {
		const url = new URL(urlValue, window.location.href);
		const categories = [];
		url.searchParams.forEach(function(value, key) {
			if (key === 'oasi_cat[]' || key.indexOf('oasi_cat[') === 0) categories.push(value);
		});
		const search = url.searchParams.get('oasi_q') || '';
		const order = url.searchParams.get('orderby') || 'menu_order';

		if (searchInput) searchInput.value = search;
		if (orderSelect) orderSelect.value = order;

		form.querySelectorAll('input[name="oasi_cat[]"]').forEach(function(input) {
			input.checked = categories.includes(input.value);
		});
		['min_price', 'max_price'].forEach(function(name) {
			const input = form.querySelector('[name="' + name + '"]');
			if (input) input.value = url.searchParams.get(name) || '';
		});
		['oasi_in_stock', 'oasi_on_sale'].forEach(function(name) {
			const input = form.querySelector('[name="' + name + '"]');
			if (input) input.checked = url.searchParams.get(name) === '1';
		});

		if (filterCount) {
			let count = categories.length;
			['oasi_q', 'min_price', 'max_price', 'oasi_in_stock', 'oasi_on_sale'].forEach(function(name) {
				if (url.searchParams.get(name)) count += 1;
			});
			filterCount.textContent = String(count);
		}
	}

	function updateArchive(data) {
		if (!data || typeof data.results !== 'string') throw new Error('invalid-payload');
		results.innerHTML = data.results;
		if (data.documentTitle) document.title = data.documentTitle;
		syncControlsFromUrl(data.url || window.location.href);
		const firstHeading = results.querySelector('.woocommerce-loop-product__title, .woocommerce-info');
		if (firstHeading) firstHeading.setAttribute('tabindex', '-1');
	}

	function scrollToResultsStart() {
		const header = document.getElementById('oasi-site-header');
		const adminBar = document.getElementById('wpadminbar');
		const headerBottom = header ? Math.max(0, header.getBoundingClientRect().bottom) : 0;
		const adminBarBottom = adminBar ? Math.max(0, adminBar.getBoundingClientRect().bottom) : 0;
		const visibleBarsBottom = Math.max(headerBottom, adminBarBottom);
		const currentScroll = window.scrollY || window.pageYOffset || 0;
		const targetTop = results.getBoundingClientRect().top + currentScroll - visibleBarsBottom - 16;
		const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

		window.scrollTo({
			top: Math.max(0, targetTop),
			behavior: reducedMotion ? 'auto' : 'smooth',
		});
	}

	async function loadArchive(urlValue, pushState, scrollAfterLoad) {
		const shouldPush = pushState !== false;
		if (activeRequest) activeRequest.abort();
		activeRequest = new AbortController();
		setLoading(true);

		const requestUrl = new URL(urlValue, window.location.href);
		requestUrl.searchParams.set(config.partialParam, '1');

		try {
			const response = await fetch(requestUrl, {
				headers: { 'X-Requested-With': 'XMLHttpRequest' },
				signal: activeRequest.signal,
			});
			if (!response.ok) throw new Error(String(response.status));
			const payload = await response.json();
			if (!payload.success) throw new Error('invalid-payload');
			updateArchive(payload.data);
			const loadedPage = getArchivePage(payload.data.url || requestUrl.href);
			if (shouldPush) history.pushState({ oasiShopPage: loadedPage }, '', payload.data.url);
			activePage = loadedPage;
			if (scrollAfterLoad) window.requestAnimationFrame(scrollToResultsStart);
			shop.dispatchEvent(new CustomEvent('oasi:catalog-updated', { detail: payload.data }));
		} catch (error) {
			if (error.name !== 'AbortError') {
				window.location.assign(urlValue);
			}
		} finally {
			setLoading(false);
		}
	}

	function closeDrawer() {
		if (!drawer) return;
		drawer.classList.remove('is-open');
		drawer.removeAttribute('role');
		drawer.removeAttribute('aria-modal');
		if (overlay) overlay.classList.remove('is-open');
		document.body.classList.remove('oasi-filter-drawer-open');
		if (openButton) openButton.setAttribute('aria-expanded', 'false');
		if (lastFocusedElement) lastFocusedElement.focus();
	}

	function openDrawer() {
		if (!drawer) return;
		lastFocusedElement = document.activeElement;
		drawer.classList.add('is-open');
		drawer.setAttribute('role', 'dialog');
		drawer.setAttribute('aria-modal', 'true');
		if (overlay) overlay.classList.add('is-open');
		document.body.classList.add('oasi-filter-drawer-open');
		if (openButton) openButton.setAttribute('aria-expanded', 'true');
		const firstControl = drawer.querySelector('button, input, summary, a');
		if (firstControl) firstControl.focus();
	}

	function trapDrawerFocus(event) {
		if (event.key !== 'Tab' || !drawer || !drawer.classList.contains('is-open')) return;
		const focusable = Array.from(drawer.querySelectorAll('button:not([disabled]), input:not([disabled]), summary, a[href]'))
			.filter(function(element) { return element.offsetParent !== null; });
		if (!focusable.length) return;
		const first = focusable[0];
		const last = focusable[focusable.length - 1];
		if (event.shiftKey && document.activeElement === first) {
			event.preventDefault();
			last.focus();
		} else if (!event.shiftKey && document.activeElement === last) {
			event.preventDefault();
			first.focus();
		}
	}

	form.addEventListener('submit', function(event) {
		event.preventDefault();
		const url = buildFilterUrl();
		closeDrawer();
		loadArchive(url.href, true);
	});

	form.addEventListener('change', function(event) {
		if (window.matchMedia('(min-width: 961px)').matches && event.target.matches('input[type="checkbox"]')) {
			form.requestSubmit();
		}
	});

	if (searchInput) {
		searchInput.addEventListener('input', function() {
			window.clearTimeout(searchTimer);
			searchTimer = window.setTimeout(function() { form.requestSubmit(); }, 450);
		});
		searchInput.addEventListener('keydown', function(event) {
			if (event.key === 'Enter') {
				event.preventDefault();
				window.clearTimeout(searchTimer);
				form.requestSubmit();
			}
		});
	}

	if (orderSelect) {
		orderSelect.addEventListener('change', function() { form.requestSubmit(); });
	}

	if (openButton) openButton.addEventListener('click', openDrawer);
	shop.querySelectorAll('[data-oasi-filter-close]').forEach(function(button) {
		button.addEventListener('click', closeDrawer);
	});

	shop.addEventListener('click', function(event) {
		const paginationLink = event.target.closest('.woocommerce-pagination a');
		const link = paginationLink || event.target.closest('[data-oasi-filter-link]');
		if (!link || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
		event.preventDefault();
		closeDrawer();
		loadArchive(link.href, true, Boolean(paginationLink));
	});

	document.addEventListener('keydown', function(event) {
		if (event.key === 'Escape' && drawer && drawer.classList.contains('is-open')) closeDrawer();
		trapDrawerFocus(event);
	});

	window.addEventListener('popstate', function(event) {
		const statePage = event.state && Number.parseInt(event.state.oasiShopPage, 10);
		const requestedPage = Number.isInteger(statePage) && statePage > 0 ? statePage : getArchivePage(window.location.href);
		loadArchive(window.location.href, false, requestedPage !== activePage);
	});
})();
