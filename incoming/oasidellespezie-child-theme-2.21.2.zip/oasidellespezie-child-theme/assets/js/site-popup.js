(function () {
	'use strict';

	var popup = document.querySelector('[data-oasi-site-popup]');
	if (!popup || !window.oasiPopupConfig || !oasiPopupConfig.sessionKey) {
		return;
	}

	try {
		if (window.sessionStorage.getItem(oasiPopupConfig.sessionKey)) {
			popup.remove();
			return;
		}
	} catch (error) {
		// Private browsing may deny storage. The popup remains functional.
	}

	var dialog = popup.querySelector('[role="dialog"]');
	var previousFocus = null;

	function rememberSeen() {
		try {
			window.sessionStorage.setItem(oasiPopupConfig.sessionKey, '1');
		} catch (error) {
			// Closing the popup must not depend on storage availability.
		}
	}

	function closePopup() {
		popup.hidden = true;
		document.body.classList.remove('oasi-popup-open');
		rememberSeen();
		if (previousFocus && document.contains(previousFocus)) {
			previousFocus.focus();
		}
	}

	function openPopup() {
		previousFocus = document.activeElement;
		popup.hidden = false;
		document.body.classList.add('oasi-popup-open');
		rememberSeen();
		if (dialog) {
			dialog.focus();
		}
	}

	function keepFocusInside(event) {
		if (popup.hidden || event.key !== 'Tab' || !dialog) {
			return;
		}
		var focusable = Array.prototype.slice.call(dialog.querySelectorAll('a[href], button:not([disabled]), [tabindex]:not([tabindex="-1"])'));
		if (!focusable.length) {
			event.preventDefault();
			dialog.focus();
			return;
		}
		var first = focusable[0];
		var last = focusable[focusable.length - 1];
		if (event.shiftKey && document.activeElement === first) {
			event.preventDefault();
			last.focus();
		} else if (!event.shiftKey && document.activeElement === last) {
			event.preventDefault();
			first.focus();
		}
	}

	popup.addEventListener('click', function (event) {
		if (event.target.closest('[data-oasi-popup-close]')) {
			closePopup();
		}
	});

	document.addEventListener('keydown', function (event) {
		keepFocusInside(event);
		if (!popup.hidden && event.key === 'Escape') {
			event.preventDefault();
			closePopup();
		}
	});

	window.setTimeout(openPopup, Math.max(0, Number(oasiPopupConfig.delay) || 0));
}());
