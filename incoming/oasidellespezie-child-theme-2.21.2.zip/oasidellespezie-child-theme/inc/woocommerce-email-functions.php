<?php
/**
 * WooCommerce email branding sourced from the central ticinoWEB CMS logo.
 *
 * @package OasiDelleSpezieChild
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Prefer the current CMS logo while preserving WooCommerce's native fallback.
 *
 * The same resolver is used for the saved setting and for WooCommerce's email
 * preview transient so the preview always matches the emails that are sent.
 *
 * @param mixed $pre_value Value supplied by an earlier pre-option filter.
 * @return mixed CMS logo URL, or the untouched value when the CMS logo is empty.
 */
function oasi_email_logo_from_cms( mixed $pre_value ): mixed {
	$cms_logo = function_exists( 'ticinoweb_get_site_logo' ) ? ticinoweb_get_site_logo() : false;
	$logo_url = is_string( $cms_logo ) ? esc_url_raw( trim( $cms_logo ) ) : '';

	return '' !== $logo_url ? $logo_url : $pre_value;
}

/**
 * Enable the CMS logo only for the WooCommerce header rendering window.
 */
function oasi_email_logo_enable_cms_source(): void {
	add_filter( 'pre_option_woocommerce_email_header_image', 'oasi_email_logo_from_cms', 20 );
	add_filter( 'pre_transient_woocommerce_email_header_image', 'oasi_email_logo_from_cms', 20 );
}

/**
 * Restore native WooCommerce option handling immediately after the header.
 */
function oasi_email_logo_disable_cms_source(): void {
	remove_filter( 'pre_option_woocommerce_email_header_image', 'oasi_email_logo_from_cms', 20 );
	remove_filter( 'pre_transient_woocommerce_email_header_image', 'oasi_email_logo_from_cms', 20 );
}

add_action( 'woocommerce_email_header', 'oasi_email_logo_enable_cms_source', 5 );
add_action( 'woocommerce_email_header', 'oasi_email_logo_disable_cms_source', 15 );
