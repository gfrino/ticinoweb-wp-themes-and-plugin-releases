<?php
/**
 * Preserve variable products while they still contain active variations.
 *
 * @package OasiDelleSpezieChild
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Determine whether a product still owns at least one non-trashed variation.
 *
 * @param int $product_id Product ID.
 * @return bool
 */
function oasi_product_has_active_variations( int $product_id ): bool {
	$variation_ids = get_posts(
		array(
			'post_type'        => 'product_variation',
			'post_status'      => array( 'publish', 'private', 'draft', 'pending', 'future' ),
			'post_parent'      => $product_id,
			'posts_per_page'   => 1,
			'fields'           => 'ids',
			'no_found_rows'    => true,
			'suppress_filters' => true,
		)
	);

	return ! empty( $variation_ids );
}

/**
 * Restore the variable type when a background process or accidental save tries
 * to mark a product as simple while live variations still exist.
 *
 * @param int          $object_id  Object ID.
 * @param array|string $terms      Assigned terms.
 * @param array        $tt_ids     Assigned term-taxonomy IDs.
 * @param string       $taxonomy   Taxonomy name.
 * @param bool         $append     Whether terms were appended.
 * @param array        $old_tt_ids Previous term-taxonomy IDs.
 * @return void
 */
function oasi_preserve_variable_product_type( $object_id, $terms, $tt_ids, $taxonomy, $append, $old_tt_ids ): void {
	static $restoring = false;

	$product_id = absint( $object_id );
	if ( $restoring || 'product_type' !== $taxonomy || ! $product_id || 'product' !== get_post_type( $product_id ) ) {
		return;
	}

	$current_types = wp_get_object_terms( $product_id, 'product_type', array( 'fields' => 'slugs' ) );
	if ( is_wp_error( $current_types ) || ! in_array( 'simple', (array) $current_types, true ) ) {
		return;
	}

	if ( ! oasi_product_has_active_variations( $product_id ) ) {
		return;
	}

	$restoring = true;
	wp_set_object_terms( $product_id, 'variable', 'product_type' );
	$restoring = false;

	wc_delete_product_transients( $product_id );
	clean_post_cache( $product_id );

	$user_id = get_current_user_id();
	if ( $user_id ) {
		set_transient( 'oasi_product_type_guard_' . $user_id . '_' . $product_id, 1, MINUTE_IN_SECONDS );
	}
}
add_action( 'set_object_terms', 'oasi_preserve_variable_product_type', 20, 6 );

/**
 * Explain a prevented conversion to the product editor.
 *
 * @return void
 */
function oasi_product_type_guard_admin_notice(): void {
	$screen = get_current_screen();
	if ( ! $screen || 'product' !== $screen->post_type ) {
		return;
	}

	$product_id = isset( $_GET['post'] ) ? absint( wp_unslash( $_GET['post'] ) ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only notice lookup.
	$user_id    = get_current_user_id();
	if ( ! $product_id || ! $user_id ) {
		return;
	}

	$transient_key = 'oasi_product_type_guard_' . $user_id . '_' . $product_id;
	if ( ! get_transient( $transient_key ) ) {
		return;
	}

	delete_transient( $transient_key );
	?>
	<div class="notice notice-warning is-dismissible"><p><?php esc_html_e( 'Il prodotto è rimasto variabile perché contiene ancora delle variazioni. Per convertirlo intenzionalmente in prodotto semplice, elimina prima tutte le variazioni.', 'oasidellespezie-child-theme' ); ?></p></div>
	<?php
}
add_action( 'admin_notices', 'oasi_product_type_guard_admin_notice' );
