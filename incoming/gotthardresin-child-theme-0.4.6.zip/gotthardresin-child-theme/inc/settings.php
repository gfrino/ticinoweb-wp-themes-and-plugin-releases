<?php
/**
 * Aspetto → Personalizza → «Gotthard Resin»: i testi e le foto della pagina iniziale che non stanno già
 * nel CMS del parent. Contatti, logo, servizi, «Chi siamo», gallerie, FAQ e SEO restano in ticinoWEB CMS.
 * I valori si leggono con gotthardresin_setting('<chiave>') (theme_mod «gotthardresin_<chiave>»).
 *
 * @package gotthardresin-child-theme
 */

defined('ABSPATH') || exit;

/** Slug di una galleria del parent: solo una di quelle esistenti, altrimenti vuoto. */
function gotthardresin_sanitize_gallery($value)
{
    $value = sanitize_title((string) $value);
    if ($value === '' || !taxonomy_exists('ticinoweb_media_gallery')) {
        return $value;
    }
    return term_exists($value, 'ticinoweb_media_gallery') ? $value : '';
}

/** Le gallerie del parent per i menu a tendina: [slug => nome]. */
function gotthardresin_gallery_choices()
{
    $choices = array('' => __('— nessuna —', 'gotthardresin-child-theme'));
    if (!taxonomy_exists('ticinoweb_media_gallery')) {
        return $choices;
    }
    $terms = get_terms(array('taxonomy' => 'ticinoweb_media_gallery', 'hide_empty' => false));
    foreach (is_array($terms) ? $terms : array() as $term) {
        $choices[$term->slug] = $term->name;
    }
    return $choices;
}

add_action('customize_register', function ($wp_customize) {
    $wp_customize->add_panel('gotthardresin', array(
        'title'       => __('Gotthard Resin', 'gotthardresin-child-theme'),
        'priority'    => 30,
        'description' => __('I testi e le foto della pagina iniziale. Indirizzo, telefono, email, social, logo, servizi e «Chi siamo» si cambiano in ticinoWEB CMS; le foto dei lavori in Media → Gallerie.', 'gotthardresin-child-theme'),
    ));

    $text = function ($section, $key, $label, $description = '', $type = 'text') use ($wp_customize) {
        $wp_customize->add_setting('gotthardresin_' . $key, array(
            'default'           => '',
            'sanitize_callback' => $type === 'textarea' ? 'sanitize_textarea_field' : ($type === 'url' ? 'esc_url_raw' : 'sanitize_text_field'),
        ));
        $wp_customize->add_control('gotthardresin_' . $key, array(
            'section'     => 'gotthardresin_' . $section,
            'type'        => $type,
            'label'       => $label,
            'description' => $description,
        ));
    };
    $image = function ($section, $key, $label, $description) use ($wp_customize) {
        $wp_customize->add_setting('gotthardresin_' . $key, array('default' => 0, 'sanitize_callback' => 'absint'));
        $wp_customize->add_control(new WP_Customize_Media_Control($wp_customize, 'gotthardresin_' . $key, array(
            'section'     => 'gotthardresin_' . $section,
            'mime_type'   => 'image',
            'label'       => $label,
            'description' => $description,
        )));
    };
    $gallery = function ($section, $key, $label, $description) use ($wp_customize) {
        $wp_customize->add_setting('gotthardresin_' . $key, array('default' => '', 'sanitize_callback' => 'gotthardresin_sanitize_gallery'));
        $wp_customize->add_control('gotthardresin_' . $key, array(
            'section'     => 'gotthardresin_' . $section,
            'type'        => 'select',
            'choices'     => gotthardresin_gallery_choices(),
            'label'       => $label,
            'description' => $description,
        ));
    };
    $section = function ($id, $title, $description) use ($wp_customize) {
        $wp_customize->add_section('gotthardresin_' . $id, array('title' => $title, 'panel' => 'gotthardresin', 'description' => $description));
    };

    // 1. In cima alla pagina.
    $section('hero', __('In cima alla pagina', 'gotthardresin-child-theme'), __('Il titolo dice cosa fate e dove, in poche parole. Sotto, una o due frasi e una riga con un fatto vero.', 'gotthardresin-child-theme'));
    $text('hero', 'hero_title', __('Titolo', 'gotthardresin-child-theme'), __('Per esempio «Pavimenti in resina a Lugano». Vuoto: il nome del sito.', 'gotthardresin-child-theme'));
    $text('hero', 'hero_text', __('Testo sotto il titolo', 'gotthardresin-child-theme'), __('Una o due frasi, al massimo 30 parole.', 'gotthardresin-child-theme'), 'textarea');
    $image('hero', 'hero_image', __('Foto a tutto schermo', 'gotthardresin-child-theme'), __('Il lavoro che vi rappresenta di più. Occupa tutto lo schermo: serve l’originale ad alta risoluzione, almeno 2400 pixel sul lato lungo. Il titolo sta in basso a sinistra, sopra la foto.', 'gotthardresin-child-theme'));

    // 2. Lavori.
    $section('works', __('Lavori', 'gotthardresin-child-theme'), __('Con un profilo Instagram in ticinoWEB CMS → Contatti, qui compare il profilo incorporato (dopo il consenso ai cookie). Senza Instagram: le prime nove foto della galleria scelta.', 'gotthardresin-child-theme'));
    $text('works', 'works_title', __('Titolo della sezione', 'gotthardresin-child-theme'));
    $text('works', 'works_text', __('Frase sotto il titolo', 'gotthardresin-child-theme'));
    $gallery('works', 'works_gallery', __('Galleria dei lavori', 'gotthardresin-child-theme'), __('Serve solo se non c’è il profilo Instagram.', 'gotthardresin-child-theme'));

    // 3. Servizi.
    $section('services', __('Servizi', 'gotthardresin-child-theme'), __('L’elenco dei servizi (nome e descrizione) si cambia in ticinoWEB CMS → Servizi.', 'gotthardresin-child-theme'));
    $text('services', 'services_title', __('Titolo della sezione', 'gotthardresin-child-theme'));
    $text('services', 'services_text', __('Frase sotto il titolo', 'gotthardresin-child-theme'), '', 'textarea');

    // 4. Azienda.
    $section('about', __('Azienda', 'gotthardresin-child-theme'), __('Titolo e testo vengono da ticinoWEB CMS → Chi siamo. Qui i dati in elenco e le foto.', 'gotthardresin-child-theme'));
    $text('about', 'about_owner', __('Titolare', 'gotthardresin-child-theme'), __('Vuoto: la riga non compare.', 'gotthardresin-child-theme'));
    $text('about', 'about_partner', __('Partner ufficiale: nome', 'gotthardresin-child-theme'));
    $text('about', 'about_partner_url', __('Partner ufficiale: sito', 'gotthardresin-child-theme'), __('L’indirizzo completo, con https://.', 'gotthardresin-child-theme'), 'url');
    $text('about', 'about_area', __('Zona di lavoro', 'gotthardresin-child-theme'), __('Per esempio «Luganese, Mendrisiotto».', 'gotthardresin-child-theme'));
    $gallery('about', 'about_gallery', __('Galleria delle due foto', 'gotthardresin-child-theme'), __('Le prime due foto, quadrate: per esempio un cantiere. Sotto ogni foto compare la sua didascalia (Libreria media). Senza foto compaiono due riquadri «In arrivo».', 'gotthardresin-child-theme'));

    // 5. Richiesta di preventivo.
    $section('contact', __('Richiesta di preventivo', 'gotthardresin-child-theme'), __('Il modulo invia all’email di ticinoWEB CMS → Contatti e salva ogni richiesta in Invii Ricevuti. Telefono, email e indirizzo accanto al modulo vengono dal CMS.', 'gotthardresin-child-theme'));
    $text('contact', 'contact_title', __('Titolo', 'gotthardresin-child-theme'), __('Per esempio «Raccontaci il lavoro».', 'gotthardresin-child-theme'));
    $image('contact', 'contact_bg', __('Foto di sfondo', 'gotthardresin-child-theme'), __('Un vostro lavoro: si vede dietro il modulo, appena sfocato e scurito, e scorre piano. Vuoto: la foto in cima alla pagina.', 'gotthardresin-child-theme'));
    $text('contact', 'contact_text', __('Frase sotto il titolo', 'gotthardresin-child-theme'), __('Per esempio «Consulenza gratuita. Scrivi cosa vuoi rifare e dove: ti richiamiamo».', 'gotthardresin-child-theme'), 'textarea');
});
