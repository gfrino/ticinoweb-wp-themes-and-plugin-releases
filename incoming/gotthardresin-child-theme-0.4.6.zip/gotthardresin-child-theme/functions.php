<?php
/**
 * Gotthard Resin: child di ticinoWEB CMS (ticinoweb-ai-theme), senza Elementor.
 * La pagina iniziale a sezioni viene dal prototipo della skill design-con-carattere (direzione «Su misura», 16.11.2026). Contatti, logo, servizi,
 * «Chi siamo», gallerie, FAQ, SEO, cookie e modulo (Invii Ricevuti, reCAPTCHA, SMTP) restano nel parent;
 * i pochi testi della home stanno in Aspetto → Personalizza → Gotthard Resin (inc/settings.php).
 *
 * @package gotthardresin-child-theme
 */

defined('ABSPATH') || exit;

define('GOTTHARDRESIN_VERSION', wp_get_theme(get_stylesheet())->get('Version'));
define('GOTTHARDRESIN_DIR', get_stylesheet_directory());
define('GOTTHARDRESIN_URI', get_stylesheet_directory_uri());

require_once GOTTHARDRESIN_DIR . '/inc/helpers.php';
require_once GOTTHARDRESIN_DIR . '/inc/settings.php';
require_once GOTTHARDRESIN_DIR . '/inc/icone.php';
// La sincronizzazione delle foto da Instagram (0.3.0) è sostituita dal profilo incorporato: si toglie il suo controllo orario.
add_action('init', function () {
    if (wp_next_scheduled('gotthardresin_instagram_lavori')) {
        wp_clear_scheduled_hook('gotthardresin_instagram_lavori');
    }
});
if (is_admin()) {
    require_once GOTTHARDRESIN_DIR . '/inc/content-transfer.php';
}

add_action('after_setup_theme', function () {
    load_child_theme_textdomain('gotthardresin-child-theme', GOTTHARDRESIN_DIR . '/languages');
}, 20);

/**
 * Stili e script. Il parent accoda già lo style.css del child («ticinoweb-ai-style») con la versione del
 * parent: qui si aggiunge il suo style.css come dipendenza e si versiona tutto con la versione del child
 * (ogni rilascio svuota la cache del browser). I caratteri sono nel tema: Poppins di Google non si scarica.
 */
add_action('wp_enqueue_scripts', function () {
    wp_enqueue_style('gotthardresin-parent', get_template_directory_uri() . '/style.css', array(), wp_get_theme(get_template())->get('Version'));
    if (isset(wp_styles()->registered['ticinoweb-ai-style'])) {
        wp_styles()->registered['ticinoweb-ai-style']->deps[] = 'gotthardresin-parent';
        wp_styles()->registered['ticinoweb-ai-style']->ver    = GOTTHARDRESIN_VERSION;
    }
    // Handle vuoto al posto del carattere di Google: la dipendenza del parent resta valida, non si stampa nulla.
    wp_deregister_style('poppins-font');
    wp_register_style('poppins-font', false, array(), null);

    // Le pagine sono HTML del tema, non blocchi: gli stili dei blocchi pesano ~28 KB su ogni pagina.
    wp_dequeue_style('wp-block-library');
    wp_dequeue_style('classic-theme-styles');
    wp_dequeue_style('global-styles');

    // Movimento: Lenis (scorrimento morbido) ovunque; GSAP + ScrollTrigger solo sulla pagina iniziale. Tutto nel tema,
    // niente CDN. Con «riduci movimento» lo script non attiva nulla (assets/js/movimento.js).
    $gtr_lib = GOTTHARDRESIN_URI . '/assets/vendor/';
    wp_enqueue_script('gotthardresin-lenis', $gtr_lib . 'lenis.min.js', array(), '1.3.27', array('in_footer' => true, 'strategy' => 'defer'));
    $gtr_deps = array('gotthardresin-lenis');
    if (is_front_page()) {
        wp_enqueue_script('gotthardresin-gsap', $gtr_lib . 'gsap.min.js', array(), '3.15.1', array('in_footer' => true, 'strategy' => 'defer'));
        wp_enqueue_script('gotthardresin-scrolltrigger', $gtr_lib . 'ScrollTrigger.min.js', array('gotthardresin-gsap'), '3.15.1', array('in_footer' => true, 'strategy' => 'defer'));
        $gtr_deps[] = 'gotthardresin-scrolltrigger';
    }
    wp_enqueue_script('gotthardresin-movimento', GOTTHARDRESIN_URI . '/assets/js/movimento.js', $gtr_deps, GOTTHARDRESIN_VERSION . '.' . (int) @filemtime(GOTTHARDRESIN_DIR . '/assets/js/movimento.js'), array('in_footer' => true, 'strategy' => 'defer'));

    wp_enqueue_script('gotthardresin-site', GOTTHARDRESIN_URI . '/assets/js/site.js', array(), GOTTHARDRESIN_VERSION, array('in_footer' => true, 'strategy' => 'defer'));
    wp_localize_script('gotthardresin-site', 'gotthardResin', array(
        'ajaxUrl'      => admin_url('admin-ajax.php'),
        'recaptchaKey' => (string) get_option('ticinoweb_recaptcha_site_key', ''),
        'subject'      => gotthardresin_t(__('Richiesta di preventivo dal sito', 'gotthardresin-child-theme'), 'form:subject'),
        'sending'      => gotthardresin_t(__('Invio in corso…', 'gotthardresin-child-theme'), 'form:sending'),
        'sent'         => gotthardresin_t(__('Grazie, abbiamo ricevuto la richiesta. Ti rispondiamo presto.', 'gotthardresin-child-theme'), 'form:sent'),
        'failed'       => gotthardresin_t(__('La richiesta non è partita. Riprova tra poco oppure scrivici o chiamaci.', 'gotthardresin-child-theme'), 'form:failed'),
        'interesse'    => gotthardresin_t(__('Interessato a', 'gotthardresin-child-theme'), 'form:interest'),
        'offline'      => gotthardresin_t(__('Sembra che la connessione sia assente. Controlla la rete e riprova.', 'gotthardresin-child-theme'), 'form:offline'),
        'menuOpen'     => gotthardresin_t(__('Apri il menu', 'gotthardresin-child-theme'), 'ui:menu_open'),
        'menuClose'    => gotthardresin_t(__('Chiudi il menu', 'gotthardresin-child-theme'), 'ui:menu_close'),
    ));
}, 20);

/** I due caratteri (variabili) si precaricano: Syne per il titolo, Instrument Sans per menu e testo del primo schermo. */
add_action('wp_head', function () {
    foreach (array('syne.woff2', 'instrument-sans.woff2') as $gtr_font) {
        printf('<link rel="preload" href="%s" as="font" type="font/woff2" crossorigin>' . "\n", esc_url(GOTTHARDRESIN_URI . '/assets/fonts/' . $gtr_font));
    }
}, 1);

/**
 * Il parent apre due preconnect verso Google Fonts su ogni pagina (closure su wp_head 0): si tolgono,
 * perché nessun carattere arriva da Google e l'IP del visitatore non deve uscire prima del consenso.
 */
add_action('wp_head', function () {
    global $wp_filter;
    if (empty($wp_filter['wp_head']) || empty($wp_filter['wp_head']->callbacks[0])) {
        return;
    }
    $parent_functions = wp_normalize_path(get_template_directory() . '/functions.php');
    foreach ($wp_filter['wp_head']->callbacks[0] as $callback) {
        if (!($callback['function'] instanceof Closure)) {
            continue;
        }
        $ref = new ReflectionFunction($callback['function']);
        if (wp_normalize_path((string) $ref->getFileName()) !== $parent_functions) {
            continue;
        }
        $lines = file($parent_functions);
        $body  = implode('', array_slice((array) $lines, $ref->getStartLine() - 1, $ref->getEndLine() - $ref->getStartLine() + 1));
        if (strpos($body, 'fonts.googleapis.com') !== false) {
            remove_action('wp_head', $callback['function'], 0);
        }
    }
}, -100);

/** Emoji di WordPress: scaricherebbero immagini da s.w.org prima del consenso ai cookie. */
remove_action('wp_head', 'print_emoji_detection_script', 7);
remove_action('wp_print_styles', 'print_emoji_styles');
add_filter('emoji_svg_url', '__return_false');

/** WordPress mette sizes="auto" sulle immagini lazy e le pianta a 1500px finché il CSS non arriva: si spegne. */
add_filter('wp_img_tag_add_auto_sizes', '__return_false');

/** Classi del body del tema; sulla pagina iniziale la testata sta sopra la foto. */
add_filter('body_class', function ($classes) {
    $classes[] = 'gtr-site';
    if (is_front_page()) {
        $classes[] = 'gtr-home';
    }
    return $classes;
});

/**
 * Prima del primo disegno si decide il movimento: html.gtr-moto (scena della hero guidata dallo scorrimento) se il
 * visitatore non ha chiesto «riduci movimento»; html.gtr-con-intro (intro con il logo) sulla pagina iniziale, a ogni
 * apertura (scelta del cliente), solo senza ancora nell'indirizzo: con #lavori, #contatto… la pagina va dritta alla sezione. Se le librerie non partono entro 4 secondi l'intro si spegne da sola.
 */
add_action('wp_head', function () {
    if (!is_front_page()) {
        return;
    }
    ?>
<script>(function(){var d=document.documentElement;try{if(window.matchMedia('(prefers-reduced-motion: reduce)').matches)return;d.classList.add('gtr-moto');if(!location.hash){d.classList.add('gtr-con-intro');setTimeout(function(){if(!window.gtrIntroPartita)d.classList.remove('gtr-con-intro')},4000)}}catch(e){d.classList.remove('gtr-con-intro')}})();</script>
    <?php
}, 2);

/**
 * Il modulo della home usa il gestore del parent (Invii Ricevuti, reCAPTCHA, SMTP): se arriva senza
 * oggetto, gli si dà quello del preventivo, così negli Invii Ricevuti si riconosce a colpo d'occhio.
 */
add_filter('ticinoweb_form_fields', function ($fields, $post) {
    if (!empty($post['gtr_form']) && isset($fields['oggetto']) && $fields['oggetto'] === '') {
        $fields['oggetto'] = __('Richiesta di preventivo dal sito', 'gotthardresin-child-theme');
    }
    return $fields;
}, 10, 2);

/**
 * Un'impostazione che manca la dice la bacheca, invece di lasciare la pagina vuota senza spiegazioni:
 * email del modulo, SMTP, reCAPTCHA, pagina privacy.
 */
add_action('admin_notices', function () {
    if (!current_user_can('manage_options')) {
        return;
    }
    $screen = function_exists('get_current_screen') ? get_current_screen() : null;
    if ($screen && !in_array($screen->id, array('dashboard', 'themes', 'toplevel_page_ticinoweb-settings'), true)) {
        return;
    }
    $missing = array();
    if (!get_option('ticinoweb_contact_email')) {
        $missing[] = __('l’email di contatto (ticinoWEB CMS → Contatti): senza, le richieste di preventivo arrivano all’email dell’amministratore', 'gotthardresin-child-theme');
    }
    if (!get_option('ticinoweb_smtp_host') && !get_option('ticinoweb_sendgrid_api_key')) {
        $missing[] = __('l’invio email (ticinoWEB CMS → SMTP): dai nostri server la posta senza SMTP non arriva', 'gotthardresin-child-theme');
    }
    if (!get_option('ticinoweb_recaptcha_site_key')) {
        $missing[] = __('le chiavi reCAPTCHA (ticinoWEB CMS): senza, il modulo riceve molto spam', 'gotthardresin-child-theme');
    }
    if (gotthardresin_privacy_url() === '') {
        $missing[] = __('la pagina Privacy (tW SEO → Cookie e privacy)', 'gotthardresin-child-theme');
    }
    if (!$missing) {
        return;
    }
    echo '<div class="notice notice-warning"><p><strong>' . esc_html__('Tema Gotthard Resin: da completare', 'gotthardresin-child-theme') . '</strong></p><ul style="list-style:disc;padding-left:20px">';
    foreach ($missing as $item) {
        echo '<li>' . esc_html($item) . '</li>';
    }
    echo '</ul></div>';
});
