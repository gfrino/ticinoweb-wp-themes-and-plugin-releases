<?php
/**
 * Plugin Name:       Make your own Pokè
 * Plugin URI:        https://ticinoweb.com/
 * Description:       Crea la pagina «Crea la tua poké»: il cliente sceglie la misura, poi gli ingredienti del gruppo di Product Add-ons; i primi ingredienti sono inclusi nel prezzo, gli altri si pagano. Prezzo calcolato sul server, aggiunta al carrello senza ricaricare la pagina. Shortcode [make_your_own_poke] o widget Elementor.
 * Update URI:        https://github.com/gfrino/ticinoweb-wp-themes-and-plugin-releases
 * Requires PHP:      7.4
 * Requires at least: 6.5
 * Requires Plugins:  woocommerce, woocommerce-product-addons
 * Version:           1.3.0
 * Author:            Giovanni Frino
 * Author URI:        https://ticinoweb.com/
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       ticinoweb
 * Domain Path:       /languages
 */

if ( ! defined( 'ABSPATH' ) ) {
    return;
}

// Un'altra copia del configuratore (il vecchio «ticinoweb-utilities») è già caricata: questo plugin
// non si carica, perché i due definiscono le stesse funzioni. Lo si dice in bacheca invece di andare in errore.
if ( defined( 'BRTW_PATH' ) || function_exists( 'brtw_get_terms' ) ) {
    add_action( 'admin_notices', function () {
        if ( current_user_can( 'activate_plugins' ) ) {
            echo '<div class="notice notice-error"><p>' . esc_html__( 'Make your own Pokè: è attivo anche il vecchio plugin «TicinoWeb Utilities» con lo stesso configuratore. Disattivane uno dei due: questo resta spento finché sono attivi entrambi.', 'ticinoweb' ) . '</p></div>';
        }
    } );
    return;
}

define( 'BRTW_PATH', wp_normalize_path( plugin_dir_path( __FILE__ ) . DIRECTORY_SEPARATOR ) );
define( 'BRTW_URI', plugin_dir_url( __FILE__ ) );
define( 'BRTW_VERSION', '1.3.0' );
define( 'BRTW_TEXT_DOMAIN', 'ticinoweb' );
// Version of the bundled includes/tw-release-updater.php (keep in sync with its header).
define( 'BRTW_RELEASE_UPDATER_VERSION', '1.2.0' );

require_once BRTW_PATH . 'includes/tw-release-updater.php';
require_once BRTW_PATH . 'src/helper.php';
require_once BRTW_PATH . 'src/configurator.php';
if ( is_admin() ) {
    require_once BRTW_PATH . 'src/admin.php';
}

/*
 * Text domain.
 */
if ( ! function_exists( 'brtw_utilities_load_textdomain' ) ) {
    function brtw_utilities_load_textdomain() {
        load_plugin_textdomain( 'ticinoweb', false, basename( dirname( __FILE__ ) ) . '/languages' );
    }
    add_action( 'init', 'brtw_utilities_load_textdomain' );
}

/**
 * Register front-end assets. They are enqueued only where the configurator is printed
 * (shortcode, Elementor widget or brtw_render_configurator()), always with BRTW_VERSION.
 */
function brtw_register_assets() {
    wp_register_style( 'brtw-utilities-base', BRTW_URI . 'assets/css/base.css', array(), BRTW_VERSION );
    wp_register_script( 'brtw-frontend', BRTW_URI . 'assets/js/frontend.js', array(), BRTW_VERSION, true );
    wp_localize_script( 'brtw-frontend', 'brtwConfigurator', brtw_frontend_settings() );

    // Pages that contain the shortcode: enqueue in <head>, so the CSS arrives before the markup.
    if ( is_singular() ) {
        $post = get_post();
        if ( $post instanceof WP_Post && has_shortcode( (string) $post->post_content, 'make_your_own_poke' ) ) {
            brtw_enqueue_assets();
        }
    }
}
add_action( 'wp_enqueue_scripts', 'brtw_register_assets' );

/**
 * The Elementor widget is loaded only when Elementor is active (and it renders
 * through brtw_render_configurator(), like the shortcode).
 */
function brtw_maybe_load_elementor() {
    if ( did_action( 'elementor/loaded' ) ) {
        require_once BRTW_PATH . 'src/class.brtw.elementor.php';
    }
}
add_action( 'plugins_loaded', 'brtw_maybe_load_elementor', 20 );

/**
 * Admin notice when WooCommerce or Product Add-ons are missing: the configurator cannot work without them.
 */
function brtw_dependencies_notice() {
    if ( ! current_user_can( 'activate_plugins' ) ) {
        return;
    }
    $missing = array();
    if ( ! class_exists( 'WooCommerce' ) ) {
        $missing[] = 'WooCommerce';
    }
    if ( ! class_exists( 'WC_Product_Addons_Helper' ) ) {
        $missing[] = 'WooCommerce Product Add-ons';
    }
    if ( ! $missing ) {
        return;
    }
    echo '<div class="notice notice-error"><p>' . esc_html( sprintf(
        /* translators: %s: elenco di plugin */
        __( 'Make your own Pokè: per funzionare servono questi plugin, ora non attivi: %s.', 'ticinoweb' ),
        implode( ', ', $missing )
    ) ) . '</p></div>';
}
add_action( 'admin_notices', 'brtw_dependencies_notice' );

/**
 * Install or upgrade the release updater mu-plugin from the bundled copy.
 * Retried at most every 12 hours if mu-plugins is not writable.
 */
function brtw_install_release_updater() {
    if ( ! class_exists( 'TW_Release_Updater' ) || TW_Release_Updater::mu_is_current( BRTW_RELEASE_UPDATER_VERSION ) ) {
        return;
    }
    if ( get_site_transient( 'brtw_release_updater_failed' ) ) {
        return;
    }
    $result = TW_Release_Updater::install_mu( BRTW_PATH . 'includes/tw-release-updater.php' );
    if ( is_wp_error( $result ) ) {
        set_site_transient( 'brtw_release_updater_failed', $result->get_error_message(), 12 * HOUR_IN_SECONDS );
    }
}

add_action( 'admin_init', function () {
    if ( current_user_can( is_multisite() ? 'manage_network_plugins' : 'activate_plugins' ) ) {
        brtw_install_release_updater();
    }
}, 20 );
