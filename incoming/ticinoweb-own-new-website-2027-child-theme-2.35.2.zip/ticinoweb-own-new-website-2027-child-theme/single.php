<?php
/**
 * Single tBlog article.
 *
 * THESIS: a calm editorial page replaces the unstructured text block.
 * OWN-WORLD: warm paper, Ink typography, one blue action and fine rules.
 * STORY: identify the article, read comfortably, continue or make contact.
 * FIRST VIEWPORT: compact metadata, controlled headline and optional excerpt.
 * FORM: established Digital Proof Studio, tuned specifically for reading.
 *
 * @package ticinoWEB_Child_Theme
 */

get_header();

while ( have_posts() ) :
	the_post();
	$tw_post_id          = get_the_ID();
	$tw_category         = tw_single_get_primary_category( $tw_post_id );
	$tw_reading_time     = tw_single_reading_time( get_post_field( 'post_content', $tw_post_id ) );
	$tw_is_project       = '1' === (string) get_post_meta( $tw_post_id, 'tw_home_project_featured', true );
	$tw_related_post_ids = tw_single_get_related_post_ids( $tw_post_id, 4 );
	$tw_contact_url      = tw_home_mapped_url( 'page_contatti', 'chi-siamo-contatti' );
	?>
	<main class="tw-single-article">
		<article <?php post_class( 'tw-single-entry' ); ?>>
			<header class="tw-single-hero">
				<div class="tw-shell tw-single-hero__inner">
					<?php if ( $tw_category || $tw_is_project ) : ?>
						<p class="tw-single-kicker">
							<?php if ( $tw_is_project ) : ?><span><?php esc_html_e( 'Progetti', 'ticinoweb-child-theme' ); ?></span><?php endif; ?>
							<?php if ( $tw_is_project && $tw_category ) : ?><span aria-hidden="true">·</span><?php endif; ?>
							<?php if ( $tw_category ) : ?><span><?php echo esc_html( $tw_category->name ); ?></span><?php endif; ?>
						</p>
					<?php endif; ?>
					<h1><?php the_title(); ?></h1>
					<?php if ( has_excerpt() ) : ?>
						<p class="tw-single-deck"><?php echo esc_html( get_the_excerpt() ); ?></p>
					<?php endif; ?>
					<p class="tw-single-meta">
						<time datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>"><?php echo esc_html( get_the_date() ); ?></time>
						<span aria-hidden="true">·</span>
						<span><?php echo esc_html( sprintf( _n( '%d min di lettura', '%d min di lettura', $tw_reading_time, 'ticinoweb-child-theme' ), $tw_reading_time ) ); ?></span>
					</p>
				</div>
			</header>

			<div class="tw-shell tw-single-layout">
				<aside class="tw-single-aside" aria-label="<?php esc_attr_e( 'Informazioni sull’articolo', 'ticinoweb-child-theme' ); ?>">
					<?php if ( has_post_thumbnail() ) : ?>
						<figure class="tw-single-featured">
							<?php echo get_the_post_thumbnail( $tw_post_id, 'large', array( 'loading' => 'eager', 'fetchpriority' => 'high', 'decoding' => 'async', 'sizes' => '(max-width: 960px) calc(100vw - 44px), 340px' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
						</figure>
					<?php endif; ?>

					<div class="tw-single-share">
						<p class="tw-single-aside__label"><?php esc_html_e( 'Condividi', 'ticinoweb-child-theme' ); ?></p>
						<ul class="tw-single-share__list">
							<?php foreach ( tw_single_share_links( $tw_post_id ) as $tw_share ) : ?>
								<li>
									<?php if ( 'copy' === $tw_share['key'] ) : ?>
										<button type="button" class="tw-single-share__link" data-share-copy="<?php echo esc_url( $tw_share['url'] ); ?>" data-copied-label="<?php esc_attr_e( 'Link copiato', 'ticinoweb-child-theme' ); ?>" aria-label="<?php echo esc_attr( $tw_share['label'] ); ?>" title="<?php echo esc_attr( $tw_share['label'] ); ?>"><?php echo $tw_share['icon']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></button>
									<?php else : ?>
										<a class="tw-single-share__link" href="<?php echo esc_url( $tw_share['url'] ); ?>" target="_blank" rel="noopener noreferrer" aria-label="<?php echo esc_attr( $tw_share['label'] ); ?>" title="<?php echo esc_attr( $tw_share['label'] ); ?>"><?php echo $tw_share['icon']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></a>
									<?php endif; ?>
								</li>
							<?php endforeach; ?>
						</ul>
					</div>

					<?php $tw_tags = get_the_tags( $tw_post_id ); ?>
					<?php if ( $tw_tags && ! is_wp_error( $tw_tags ) ) : ?>
						<div class="tw-single-tags">
							<p class="tw-single-aside__label"><?php esc_html_e( 'Tag', 'ticinoweb-child-theme' ); ?></p>
							<ul class="tw-single-tags__list">
								<?php foreach ( $tw_tags as $tw_tag ) : ?>
									<li><a href="<?php echo esc_url( get_tag_link( $tw_tag ) ); ?>" rel="tag"><?php echo esc_html( $tw_tag->name ); ?></a></li>
								<?php endforeach; ?>
							</ul>
						</div>
					<?php endif; ?>

					<?php if ( $tw_related_post_ids ) : ?>
						<nav class="tw-single-related" aria-labelledby="tw-single-related-title">
							<p id="tw-single-related-title" class="tw-single-aside__label"><?php esc_html_e( 'Articoli correlati', 'ticinoweb-child-theme' ); ?></p>
							<?php foreach ( $tw_related_post_ids as $tw_related_id ) : ?>
								<?php $tw_related_category = tw_single_get_primary_category( $tw_related_id ); ?>
								<article class="tw-single-related-card">
									<?php if ( has_post_thumbnail( $tw_related_id ) ) : ?>
										<a class="tw-single-related-card__media" href="<?php echo esc_url( get_permalink( $tw_related_id ) ); ?>" tabindex="-1" aria-hidden="true">
											<?php echo get_the_post_thumbnail( $tw_related_id, 'thumbnail', array( 'alt' => '', 'loading' => 'lazy', 'decoding' => 'async' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
										</a>
									<?php endif; ?>
									<div>
										<?php if ( $tw_related_category ) : ?><p class="tw-single-related-card__meta"><?php echo esc_html( $tw_related_category->name ); ?></p><?php endif; ?>
										<h3><a href="<?php echo esc_url( get_permalink( $tw_related_id ) ); ?>"><?php echo esc_html( get_the_title( $tw_related_id ) ); ?></a></h3>
									</div>
								</article>
							<?php endforeach; ?>
						</nav>
					<?php endif; ?>
				</aside>

				<div class="tw-single-content entry-content">
					<?php the_content(); ?>
					<?php wp_link_pages(); ?>
				</div>
			</div>
		</article>

		<section class="tw-single-cta" aria-labelledby="tw-single-cta-title">
			<div class="tw-shell tw-single-cta__inner">
				<h2 id="tw-single-cta-title"><?php esc_html_e( 'Hai un progetto da raccontare?', 'ticinoweb-child-theme' ); ?></h2>
				<div>
					<p><?php esc_html_e( 'Progettiamo siti web e soluzioni digitali capaci di trasformare l’identità di un’azienda in un’esperienza riconoscibile.', 'ticinoweb-child-theme' ); ?></p>
					<a class="tw-text-link" href="<?php echo esc_url( $tw_contact_url ); ?>"><?php esc_html_e( 'Parliamo del tuo progetto', 'ticinoweb-child-theme' ); ?><span class="tw-arrow" aria-hidden="true"></span></a>
				</div>
			</div>
		</section>

	</main>
	<?php
endwhile;

get_footer();
