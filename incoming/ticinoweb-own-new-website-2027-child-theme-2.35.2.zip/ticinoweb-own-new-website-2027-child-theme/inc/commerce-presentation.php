<?php
/** Native WooCommerce presentation, without commerce or persistence overrides. */
if ( ! defined( 'ABSPATH' ) ) { exit; }

/** Include commerce endpoints and service pages embedding native purchase forms. */
function tw_commerce_is_context() {
	if ( ! function_exists( 'is_woocommerce' ) ) { return false; }
	if ( is_woocommerce() || is_cart() || is_checkout() || is_account_page() ) { return true; }
	if ( is_singular( 'page' ) && function_exists( 'tw_service_enabled' ) && tw_service_enabled() ) {
		$data = (array) get_post_meta( get_queried_object_id(), '_tw_service_content', true );
		return 'purchase' === ( $data['mode'] ?? 'info' ) && ! empty( $data['product_id'] );
	}
	return false;
}

/** The existing service renderer remains authoritative for enabled services. */
function tw_commerce_template( $template ) {
	if ( ! tw_commerce_is_context() ) { return $template; }
	if ( function_exists( 'tw_service_enabled' ) && tw_service_enabled() && ( is_singular( 'product' ) || is_singular( 'page' ) ) ) { return $template; }
	return get_stylesheet_directory() . '/woocommerce.php';
}
add_filter( 'template_include', 'tw_commerce_template', 110 );

function tw_commerce_body_class( $classes ) {
	if ( tw_commerce_is_context() ) { $classes[] = 'tw-commerce-context'; }
	return $classes;
}
add_filter( 'body_class', 'tw_commerce_body_class' );

/** Run before do_blocks/wpautop/do_shortcode; leave all native endpoint handling to WC. */
function tw_commerce_checkout_content( $content ) {
	if ( ! function_exists( 'wc_get_page_id' ) || is_admin() || ! is_checkout() || ! is_main_query() || ! in_the_loop() ) { return $content; }
	$page_id = (int) wc_get_page_id( 'checkout' );
	if ( $page_id < 1 || $page_id !== (int) get_queried_object_id() || $page_id !== (int) get_the_ID() ) { return $content; }
	if ( has_shortcode( $content, 'woocommerce_checkout' ) || has_block( 'woocommerce/checkout', $content ) ) { return $content; }
	return '[woocommerce_checkout]';
}
add_filter( 'the_content', 'tw_commerce_checkout_content', 8 );

function tw_commerce_enqueue() {
	if ( ! tw_commerce_is_context() ) { return; }
	wp_enqueue_style( 'tw-commerce-presentation', get_stylesheet_directory_uri() . '/assets/css/commerce.css', array( 'ticinoweb-child-site' ), wp_get_theme()->get( 'Version' ) );
}
add_action( 'wp_enqueue_scripts', 'tw_commerce_enqueue', 40 );


/** Shop: i prodotti (hosting, pacchetti) si acquistano singolarmente, senza campo quantità. */
add_filter( 'woocommerce_is_sold_individually', '__return_true' );

/** Carrello: link chiaro per tornare a guardare altri prodotti, accanto ad «Aggiorna carrello». */
function tw_commerce_cart_continue_link() {
	if ( ! function_exists( 'wc_get_page_permalink' ) ) { return; }
	printf( '<a class="tw-cart-continue" href="%s">%s</a>', esc_url( wc_get_page_permalink( 'shop' ) ), esc_html__( '← Continua gli acquisti', 'ticinoweb-child-theme' ) );
}
add_action( 'woocommerce_cart_actions', 'tw_commerce_cart_continue_link', 5 );

/** Badge con il numero di prodotti nel carrello, sopra la voce «Shop» del menu. */
function tw_cart_badge_html() {
	$count = ( function_exists( 'WC' ) && WC()->cart ) ? (int) WC()->cart->get_cart_contents_count() : 0;
	return sprintf(
		'<span class="tw-cart-badge" data-count="%1$d" role="status"%2$s>%1$d<span class="screen-reader-text"> %3$s</span></span>',
		$count,
		$count ? '' : ' hidden',
		esc_html__( 'prodotti nel carrello', 'ticinoweb-child-theme' )
	);
}

function tw_cart_badge_fragment( $fragments ) {
	$fragments['span.tw-cart-badge'] = tw_cart_badge_html();
	return $fragments;
}
add_filter( 'woocommerce_add_to_cart_fragments', 'tw_cart_badge_fragment' );

function tw_cart_badge_enqueue() {
	if ( ! class_exists( 'WooCommerce' ) ) { return; }
	wp_enqueue_script( 'tw-cart-badge', get_stylesheet_directory_uri() . '/assets/js/cart-badge.js', array(), wp_get_theme()->get( 'Version' ), true );
	wp_localize_script( 'tw-cart-badge', 'twCartBadge', array( 'url' => WC_AJAX::get_endpoint( 'get_refreshed_fragments' ) ) );
}
add_action( 'wp_enqueue_scripts', 'tw_cart_badge_enqueue', 40 );
