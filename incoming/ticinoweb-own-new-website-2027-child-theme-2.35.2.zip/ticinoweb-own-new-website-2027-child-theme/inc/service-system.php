<?php
/** Native, opt-in service presentation. Commerce remains owned by WooCommerce. */
if ( ! defined( 'ABSPATH' ) ) exit;

function tw_service_fields() {
	return array(
		'hero_eyebrow'=>'Sopratitolo', 'hero_title'=>'Titolo', 'hero_text'=>'Descrizione',
		'hero_cta_text'=>'CTA primaria', 'hero_cta_url'=>'Link CTA primaria', 'hero_secondary_text'=>'CTA secondaria', 'hero_secondary_url'=>'Link CTA secondaria',
		'intro_title'=>'Titolo introduzione', 'intro_text'=>'Introduzione', 'offer_title'=>'Titolo attività', 'includes_title'=>'Titolo funzionalità', 'process_title'=>'Titolo metodo',
		'commerce_title'=>'Titolo configuratore', 'final_title'=>'Titolo CTA finale', 'final_text'=>'Testo CTA finale', 'final_cta_text'=>'CTA finale', 'final_cta_url'=>'Link CTA finale', 'final_secondary_text'=>'CTA finale secondaria', 'final_secondary_url'=>'Link CTA finale secondaria',
	);
}
function tw_service_enabled( $id = 0 ) { return (bool) get_post_meta( $id ?: get_queried_object_id(), '_tw_service_enabled', true ); }
add_filter( 'template_include', function( $template ) {
	return is_singular( array('page','product') ) && tw_service_enabled() ? get_stylesheet_directory().'/page-service.php' : $template;
}, 110 );
add_action( 'wp_enqueue_scripts', function() {
	if ( ! is_singular() || ! tw_service_enabled() ) return;
	if ( function_exists('tw_odoo_suite_enabled') && tw_odoo_suite_enabled() ) return;
	wp_enqueue_style('tw-service-system',get_stylesheet_directory_uri().'/assets/css/service-system.css',array('ticinoweb-child-site'),wp_get_theme()->get('Version'));
	wp_enqueue_script('tw-service-media',get_stylesheet_directory_uri().'/assets/js/web-services.js',array(),wp_get_theme()->get('Version'),true);
}, 30 );
add_action( 'add_meta_boxes', function() {
	foreach(array('page','product') as $type) add_meta_box('tw-service-system',__('Contenuti pagina Servizio','ticinoweb-child-theme'),'tw_service_metabox',$type,'normal','high');
});
function tw_service_metabox( $post ) {
	$d=(array)get_post_meta($post->ID,'_tw_service_content',true);
	wp_nonce_field('tw_service_save','tw_service_nonce');
	wp_enqueue_media();
	?><p><label><input type="checkbox" name="tw_service_enabled" value="1" <?php checked(tw_service_enabled($post->ID)); ?>> <?php esc_html_e('Usa il template Servizio','ticinoweb-child-theme'); ?></label></p>
	<p><label>Modalità <select name="tw_service[mode]"><?php foreach(array('info'=>'Informativo','quote'=>'Richiesta preventivo','purchase'=>'Acquistabile online') as $k=>$v): ?><option value="<?php echo esc_attr($k); ?>" <?php selected($d['mode']??'info',$k); ?>><?php echo esc_html($v); ?></option><?php endforeach; ?></select></label></p>
	<p><label>Prodotto collegato (lascia vuoto per usare questo prodotto) <select name="tw_service[product_id]"><option value="0">Nessuno</option><?php foreach(get_posts(array('post_type'=>'product','numberposts'=>-1)) as $p): ?><option value="<?php echo esc_attr($p->ID); ?>" <?php selected($d['product_id']??0,$p->ID); ?>><?php echo esc_html($p->post_title); ?></option><?php endforeach; ?></select></label></p>
	<?php foreach(tw_service_fields() as $k=>$label): ?>
	<p><label style="display:block"><strong><?php echo esc_html($label); ?></strong><textarea style="width:100%" rows="<?php echo str_ends_with($k,'_text')?3:1; ?>" name="tw_service[<?php echo esc_attr($k); ?>]"><?php echo esc_textarea($d[$k]??''); ?></textarea></label></p>
	<?php endforeach;
	foreach(array('hero','intro','visual','final') as $section): ?>
	<p><label><?php echo esc_html(ucfirst($section)); ?> Media <input class="tw-service-media-id" type="hidden" name="tw_service[<?php echo esc_attr($section); ?>_media_id]" value="<?php echo esc_attr($d[$section.'_media_id']??0); ?>"><button type="button" class="button tw-service-pick">Seleziona dalla Libreria Media</button> <button type="button" class="button tw-service-clear">Rimuovi</button> <span class="tw-service-media-name"><?php echo esc_html(get_the_title($d[$section.'_media_id']??0)); ?></span></label></p>
	<?php endforeach;
	foreach(array('offer'=>'Cosa facciamo','includes'=>'Funzionalità','process'=>'Metodo') as $k=>$label): ?>
	<details class="tw-service-repeater" data-field="<?php echo esc_attr($k); ?>"><summary><?php echo esc_html($label); ?></summary><div class="tw-service-items"><?php foreach((array)($d[$k]??array()) as $i=>$r): ?><fieldset style="padding:16px;border:1px solid #ddd;margin-block:12px"><p><label>Titolo<input style="width:100%" name="tw_service[<?php echo esc_attr($k); ?>][<?php echo esc_attr($i); ?>][title]" value="<?php echo esc_attr($r['title']??''); ?>"></label></p><p><label>Descrizione<textarea style="width:100%" rows="4" name="tw_service[<?php echo esc_attr($k); ?>][<?php echo esc_attr($i); ?>][text]"><?php echo esc_textarea($r['text']??''); ?></textarea></label></p><p><label>Link opzionale<input type="url" style="width:100%" name="tw_service[<?php echo esc_attr($k); ?>][<?php echo esc_attr($i); ?>][url]" value="<?php echo esc_attr($r['url']??''); ?>"></label></p><button type="button" class="button tw-service-remove">Rimuovi voce</button></fieldset><?php endforeach; ?></div><button type="button" class="button tw-service-add">Aggiungi voce</button></details>
	<?php endforeach; ?>
	<p><label>Scheda FAQ <select name="tw_service[faq_set_id]"><option value="0">Nessuna</option><?php foreach(function_exists('ticinoweb_faq_choices')?ticinoweb_faq_choices():array() as $id=>$label): ?><option value="<?php echo esc_attr($id); ?>" <?php selected($d['faq_set_id']??0,$id); ?>><?php echo esc_html($label); ?></option><?php endforeach; ?></select></label></p>
	<p><label>Servizi correlati (massimo tre)<select multiple style="width:100%;height:100px" name="tw_service[related][]"><?php foreach(get_posts(array('post_type'=>array('page','product'),'numberposts'=>-1,'meta_key'=>'_tw_service_enabled','meta_value'=>'1')) as $p): if($p->ID===$post->ID)continue; ?><option value="<?php echo esc_attr($p->ID); ?>" <?php selected(in_array($p->ID,(array)($d['related']??array()),true)); ?>><?php echo esc_html($p->post_title); ?></option><?php endforeach; ?></select></label></p>
	<?php foreach(array('hero_media','intro','offer','visual','includes','process','commerce','faq','final','legacy') as $k): ?><p><label><input type="checkbox" name="tw_service[show_<?php echo esc_attr($k); ?>]" value="1" <?php checked($d['show_'.$k]??'1','1'); ?>> Mostra <?php echo esc_html($k); ?></label></p><?php endforeach; ?>
	<p>Il contenuto originale resta nell’editor, i prezzi e le varianti restano nella scheda prodotto. La sezione contenuto originale è opzionale.</p>
	<script>document.querySelectorAll('#tw-service-system .tw-service-pick').forEach(function(b){b.onclick=function(){const f=wp.media({title:'Media servizio',multiple:false});f.on('select',function(){const m=f.state().get('selection').first().toJSON();b.parentNode.querySelector('input').value=m.id;b.parentNode.querySelector('span').textContent=m.title;});f.open();};});document.querySelectorAll('#tw-service-system .tw-service-clear').forEach(function(b){b.onclick=function(){b.parentNode.querySelector('input').value=0;b.parentNode.querySelector('span').textContent='';};});</script>
	<script>document.querySelectorAll('.tw-service-repeater').forEach(function(s){s.addEventListener('click',function(e){if(e.target.classList.contains('tw-service-remove'))e.target.closest('fieldset').remove();if(e.target.classList.contains('tw-service-add')){const i=Date.now(),k=s.dataset.field,f=document.createElement('fieldset');f.style.cssText='padding:16px;border:1px solid #ddd;margin-block:12px';['title','text','url'].forEach(function(key){const l=document.createElement('label');l.textContent=key==='title'?'Titolo':key==='text'?'Descrizione':'Link opzionale';const c=document.createElement(key==='text'?'textarea':'input');c.name='tw_service['+k+']['+i+']['+key+']';c.style.cssText='width:100%;margin-bottom:16px';if(key==='url')c.type='url';l.append(c);f.append(l);});const b=document.createElement('button');b.type='button';b.className='button tw-service-remove';b.textContent='Rimuovi voce';f.append(b);s.querySelector('.tw-service-items').append(f);}});});</script>
	<?php
}
add_action('save_post',function($id){
	if(empty($_POST['tw_service_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['tw_service_nonce'])),'tw_service_save') || !current_user_can('edit_post',$id) || wp_is_post_revision($id) || (defined('DOING_AUTOSAVE')&&DOING_AUTOSAVE))return;
	$raw=wp_unslash($_POST['tw_service']??array());$d=array();
	foreach(tw_service_fields() as $k=>$label)$d[$k]=str_ends_with($k,'_url')?esc_url_raw($raw[$k]??''):sanitize_textarea_field($raw[$k]??'');
	$d['mode']=in_array($raw['mode']??'',array('info','quote','purchase'),true)?$raw['mode']:'info';
	foreach(array('hero_media_id','intro_media_id','visual_media_id','final_media_id','product_id','faq_set_id') as $k)$d[$k]=absint($raw[$k]??0);
	foreach(array('offer','includes','process') as $k){$d[$k]=array();foreach((array)($raw[$k]??array()) as $r){if(!is_array($r)||empty($r['title']))continue;$d[$k][]=array('title'=>sanitize_text_field($r['title']),'text'=>sanitize_textarea_field($r['text']??''),'url'=>esc_url_raw($r['url']??''));}}
	foreach(array('hero_media','intro','offer','visual','includes','process','commerce','faq','final','legacy') as $k)$d['show_'.$k]=empty($raw['show_'.$k])?'0':'1';
	$d['related']=array_slice(array_filter(array_map('absint',(array)($raw['related']??array()))),0,3);
	update_post_meta($id,'_tw_service_content',$d);update_post_meta($id,'_tw_service_enabled',empty($_POST['tw_service_enabled'])?'0':'1');
});
function tw_service_rows($rows){
	echo '<ol class="tw-service-rows'.(count($rows)>8?' tw-service-catalog':'').'">';foreach($rows as $i=>$r){echo '<li><span aria-hidden="true">'.esc_html(sprintf('%02d',$i+1)).'</span><div><h3>'.esc_html($r['title']).'</h3>'.wp_kses_post(do_shortcode(shortcode_unautop(wpautop($r['text']))));if(!empty($r['url']))echo '<a class="tw-text-link" href="'.esc_url($r['url']).'">'.esc_html($r['title']).' <span class="tw-arrow" aria-hidden="true"></span></a>';echo '</div></li>';}echo '</ol>';
}
/** Keep extensions and native commerce hooks; suppress only the redundant stock presentation. */
function tw_service_commerce() {
	$hidden=array('woocommerce_template_single_title'=>5,'woocommerce_template_single_rating'=>10,'woocommerce_template_single_excerpt'=>20,'woocommerce_template_single_meta'=>40,'woocommerce_template_single_sharing'=>50);
	$restore=array();foreach($hidden as $callback=>$priority){if(has_action('woocommerce_single_product_summary',$callback)!==false){remove_action('woocommerce_single_product_summary',$callback,$priority);$restore[$callback]=$priority;}}
	do_action('woocommerce_single_product_summary');
	foreach($restore as $callback=>$priority)add_action('woocommerce_single_product_summary',$callback,$priority);
}
function tw_service_original_content( $content ) {
	$content=preg_replace('#<(style|script)\b[^>]*>.*?</\1>#is','',$content);
	return preg_replace('#<(\/?)h1\b([^>]*)>#i','<$1h2$2>',$content);
}
