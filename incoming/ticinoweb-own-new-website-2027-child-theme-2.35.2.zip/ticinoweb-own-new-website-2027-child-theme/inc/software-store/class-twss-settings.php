<?php
if (!defined('ABSPATH')) {
    exit;
}

/** Impostazioni, stato e registro (opzioni non autoload). */
class Twss_Settings {
    const OPT = 'twss_settings';
    const STATE = 'twss_state';
    const LOG = 'twss_log';

    public static function defaults() {
        return array(
            'price'         => '199',
            'category'      => 'wordpress-plugins',
            'new_status'    => 'draft',
            'excluded'      => '',
            'ping_secret'   => '',
            'delete_on_uninstall' => 0,
        );
    }

    public static function all() {
        $saved = get_option(self::OPT, array());
        return array_merge(self::defaults(), is_array($saved) ? $saved : array());
    }

    public static function get($key) {
        $all = self::all();
        return isset($all[$key]) ? $all[$key] : null;
    }

    public static function save(array $in) {
        $cur = self::all();
        $price = isset($in['price']) ? str_replace(',', '.', trim((string) $in['price'])) : $cur['price'];
        $cur['price'] = (is_numeric($price) && $price >= 0) ? (string) (0 + $price) : $cur['price'];
        $cur['category'] = isset($in['category']) ? sanitize_title($in['category']) : $cur['category'];
        $cur['new_status'] = (isset($in['new_status']) && 'publish' === $in['new_status']) ? 'publish' : 'draft';
        $cur['excluded'] = isset($in['excluded']) ? sanitize_textarea_field($in['excluded']) : $cur['excluded'];
        $cur['delete_on_uninstall'] = empty($in['delete_on_uninstall']) ? 0 : 1;
        update_option(self::OPT, $cur, false);
    }

    /** Segreto per il "ping" immediato dal workflow GitHub: wp-config (TWSS_PING_SECRET) o generato. */
    public static function ping_secret() {
        if (defined('TWSS_PING_SECRET') && TWSS_PING_SECRET) {
            return (string) TWSS_PING_SECRET;
        }
        $all = self::all();
        if (empty($all['ping_secret'])) {
            $all['ping_secret'] = wp_generate_password(40, false);
            update_option(self::OPT, $all, false);
        }
        return $all['ping_secret'];
    }

    public static function excluded_slugs() {
        $list = preg_split('/[\s,]+/', (string) self::get('excluded'), -1, PREG_SPLIT_NO_EMPTY);
        return array_map('strtolower', $list ?: array());
    }

    public static function state() {
        $s = get_option(self::STATE, array());
        return is_array($s) ? $s : array();
    }

    public static function save_state(array $s) {
        update_option(self::STATE, $s, false);
    }

    public static function log($slug, $message, $level = 'info') {
        $log = get_option(self::LOG, array());
        $log = is_array($log) ? $log : array();
        array_unshift($log, array('t' => time(), 'slug' => (string) $slug, 'level' => $level, 'msg' => (string) $message));
        update_option(self::LOG, array_slice($log, 0, 200), false);
    }
}
