<?php
if (!defined('ABSPATH')) {
    exit;
}

/**
 * POST /wp-json/tw-software-store/v1/ping: lo chiama il workflow del repo release appena
 * pubblicata una versione, per avere il prodotto in pochi secondi invece che entro l'ora.
 * Firma HMAC-SHA256 del corpo nell'header X-TW-Signature ("sha256=<hex>").
 */
class Twss_Rest {
    public static function init() {
        add_action('rest_api_init', function () {
            register_rest_route('tw-software-store/v1', '/ping', array(
                'methods'             => 'POST',
                'callback'            => array(__CLASS__, 'ping'),
                'permission_callback' => array(__CLASS__, 'authorize'),
            ));
        });
    }

    public static function signature_ok($body, $header, $secret) {
        if (!$secret || !is_string($header)) {
            return false;
        }
        return hash_equals('sha256=' . hash_hmac('sha256', (string) $body, $secret), $header);
    }

    public static function authorize(WP_REST_Request $req) {
        return self::signature_ok($req->get_body(), $req->get_header('x-tw-signature'), Twss_Settings::ping_secret());
    }

    public static function ping() {
        if (!wp_next_scheduled('twss_sync_now')) {
            wp_schedule_single_event(time() + 5, 'twss_sync_now');
        }
        return rest_ensure_response(array('queued' => true));
    }
}
add_action('twss_sync_now', function () {
    delete_option(Twss_Github::ETAG); // GitHub potrebbe rispondere 304 con la cache di pochi secondi fa
    Twss_Sync::run();
});
