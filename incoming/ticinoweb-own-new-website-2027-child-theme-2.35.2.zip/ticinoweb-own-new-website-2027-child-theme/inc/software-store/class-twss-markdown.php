<?php
if (!defined('ABSPATH')) {
    exit;
}

/** Markdown minimo (titoli, elenchi, grassetto, corsivo, link, codice) → HTML sicuro. */
class Twss_Markdown {
    public static function to_html($md) {
        $md = str_replace(array("\r\n", "\r"), "\n", (string) $md);
        $out = array();
        $list = '';
        $para = array();
        $flush_para = function () use (&$para, &$out) {
            if ($para) {
                $out[] = '<p>' . self::inline(implode(' ', $para)) . '</p>';
                $para = array();
            }
        };
        $close_list = function () use (&$list, &$out) {
            if ($list) {
                $out[] = '</' . $list . '>';
                $list = '';
            }
        };
        foreach (explode("\n", $md) as $line) {
            $t = trim($line);
            if ('' === $t) {
                $flush_para();
                $close_list();
            } elseif (preg_match('/^(#{1,4})\s+(.+)$/', $t, $m)) {
                $flush_para();
                $close_list();
                $lvl = min(6, strlen($m[1]) + 2); // h3..h6: il titolo pagina resta l'unico h1/h2
                $out[] = "<h$lvl>" . self::inline($m[2]) . "</h$lvl>";
            } elseif (preg_match('/^([-*]|\d+\.)\s+(.+)$/', $t, $m)) {
                $flush_para();
                $want = ctype_digit($m[1][0]) ? 'ol' : 'ul';
                if ($list !== $want) {
                    $close_list();
                    $out[] = "<$want>";
                    $list = $want;
                }
                $out[] = '<li>' . self::inline($m[2]) . '</li>';
            } else {
                $close_list();
                $para[] = $t;
            }
        }
        $flush_para();
        $close_list();
        return wp_kses_post(implode("\n", $out));
    }

    private static function inline($text) {
        $text = esc_html($text);
        $text = preg_replace('/`([^`]+)`/', '<code>$1</code>', $text);
        $text = preg_replace('/\*\*(.+?)\*\*/', '<strong>$1</strong>', $text);
        $text = preg_replace('/(?<![\w*])\*(?!\s)(.+?)(?<!\s)\*(?![\w*])/', '<em>$1</em>', $text);
        $text = preg_replace_callback('/\[([^\]]+)\]\((https?:\/\/[^)\s]+)\)/', function ($m) {
            return '<a href="' . esc_url(html_entity_decode($m[2])) . '" rel="noopener">' . $m[1] . '</a>';
        }, $text);
        return $text;
    }
}
