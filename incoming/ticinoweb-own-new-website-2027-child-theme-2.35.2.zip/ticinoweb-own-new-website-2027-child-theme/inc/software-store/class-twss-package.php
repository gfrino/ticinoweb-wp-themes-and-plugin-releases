<?php
if (!defined('ABSPATH')) {
    exit;
}

/** Ispezione dello zip di una release: plugin o tema? quali header? icona? */
class Twss_Package {
    private static $keys = array(
        'name' => 'Plugin Name', 'description' => 'Description', 'version' => 'Version',
        'requires_wp' => 'Requires at least', 'tested_wp' => 'Tested up to', 'requires_php' => 'Requires PHP',
        'wc_requires' => 'WC requires at least', 'wc_tested' => 'WC tested up to',
    );

    /** Header di un file (come get_file_data, ma da stringa). */
    public static function headers_from($text, $map = null) {
        $map = $map ?: self::$keys;
        $text = substr((string) $text, 0, 8192);
        $out = array();
        foreach ($map as $k => $label) {
            $out[$k] = preg_match('/^[ \t\/*#@]*' . preg_quote($label, '/') . ':(.*)$/mi', $text, $m) ? trim(preg_replace('/\s*(?:\*\/|\?>).*/', '', $m[1])) : '';
        }
        return $out;
    }

    /**
     * @return array{type:string, headers?:array, icon?:string}  type: plugin | theme | unknown
     */
    public static function inspect($zip_file, $slug) {
        if (!class_exists('ZipArchive')) {
            return array('type' => 'unknown');
        }
        $zip = new ZipArchive();
        if (true !== $zip->open($zip_file)) {
            return array('type' => 'unknown');
        }
        $prefix = $slug . '/';
        $result = array('type' => 'unknown');
        $style = $zip->getFromName($prefix . 'style.css');
        if (false !== $style && preg_match('/^[ \t\/*#@]*Theme Name:/mi', substr($style, 0, 8192))) {
            $zip->close();
            return array('type' => 'theme');
        }
        for ($i = 0; $i < $zip->numFiles; $i++) {
            $name = $zip->getNameIndex($i);
            if (0 !== strpos($name, $prefix) || false !== strpos(substr($name, strlen($prefix)), '/') || '.php' !== substr($name, -4)) {
                continue;
            }
            $h = self::headers_from($zip->getFromIndex($i, 8192));
            if ('' !== $h['name']) {
                $result = array('type' => 'plugin', 'headers' => $h);
                $icon = $zip->getFromName($prefix . 'assets/icon-256x256.png');
                if (false !== $icon) {
                    $result['icon'] = $icon;
                }
                break;
            }
        }
        $zip->close();
        return $result;
    }
}
