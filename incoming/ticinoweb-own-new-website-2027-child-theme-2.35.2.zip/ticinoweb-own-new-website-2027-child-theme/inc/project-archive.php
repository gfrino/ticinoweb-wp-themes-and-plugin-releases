<?php
/**
 * Unified portfolio archive backed by the content model already available.
 *
 * Production currently stores projects as flagged blog posts. The adapter also
 * understands a future/remote project CPT without forcing a second data model.
 *
 * @package ticinoWEB_Child_Theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Return the verified project schema for the current site.
 */
function tw_projects_get_schema() {
	static $schema = null;
	if ( null !== $schema ) {
		return $schema;
	}

	$post_type = 'post';
	// A completed article migration remains authoritative after native Projects return.
	if ( post_type_exists( 'tw_project' ) && '1' !== (string) get_option( 'tw_home_project_article_migration_version', '' ) ) {
		$project_ids = get_posts(
			array(
				'post_type'      => 'tw_project',
				'post_status'    => 'publish',
				'posts_per_page' => 1,
				'fields'         => 'ids',
			)
		);
		if ( $project_ids ) {
			$post_type = 'tw_project';
		}
	}

	$type_taxonomy   = 'post' === $post_type ? 'category' : '';
	$sector_taxonomy = '';
	if ( 'tw_project' === $post_type ) {
		$taxonomies = (array) get_object_taxonomies( $post_type, 'names' );
		foreach ( array( 'tw_project_type', 'project_type', 'tipologia' ) as $candidate ) {
			if ( in_array( $candidate, $taxonomies, true ) && taxonomy_exists( $candidate ) ) {
				$type_taxonomy = $candidate;
				break;
			}
		}
		foreach ( array( 'tw_project_sector', 'project_sector', 'settore' ) as $candidate ) {
			if ( in_array( $candidate, $taxonomies, true ) && taxonomy_exists( $candidate ) ) {
				$sector_taxonomy = $candidate;
				break;
			}
		}
	}

	$schema = array(
		'post_type'       => $post_type,
		'type_taxonomy'   => $type_taxonomy,
		'sector_taxonomy' => $sector_taxonomy,
		'flag_meta_key'   => 'post' === $post_type ? 'tw_home_project_featured' : '',
	);

	return $schema;
}

/**
 * Project IDs used to calculate term counts without trusting global counts.
 */
function tw_projects_get_ids() {
	$schema = tw_projects_get_schema();
	$args   = array(
		'post_type'           => $schema['post_type'],
		'post_status'         => 'publish',
		'posts_per_page'      => -1,
		'fields'              => 'ids',
		'ignore_sticky_posts' => true,
		'no_found_rows'       => true,
	);
	if ( $schema['flag_meta_key'] ) {
		$args['meta_query'] = array(
			array(
				'key'     => $schema['flag_meta_key'],
				'value'   => '1',
				'compare' => '=',
			),
		);
	}
	return array_values( array_map( 'absint', get_posts( $args ) ) );
}

/**
 * Return only portfolio terms that are actually connected to projects.
 */
function tw_projects_get_terms( $taxonomy ) {
	if ( ! $taxonomy || ! taxonomy_exists( $taxonomy ) ) {
		return array();
	}
	$project_ids = tw_projects_get_ids();
	if ( ! $project_ids ) {
		return array();
	}

	$terms = get_terms(
		array(
			'taxonomy'   => $taxonomy,
			'hide_empty' => true,
			'object_ids' => $project_ids,
		)
	);
	if ( is_wp_error( $terms ) ) {
		return array();
	}

	$schema = tw_projects_get_schema();
	if ( 'post' === $schema['post_type'] && 'category' === $taxonomy ) {
		$allowed = array( 'web-design', 'ecommerce', 'gestionali', 'app', 'grafica-pubblicitaria-cat', 'hosting' );
		$terms   = array_values(
			array_filter(
				$terms,
				static fn( $term ) => in_array( $term->slug, $allowed, true )
			)
		);
	}

	usort(
		$terms,
		static function ( $first, $second ) {
			$priority = array( 'web-design', 'ecommerce', 'gestionali', 'app', 'grafica-pubblicitaria-cat', 'hosting' );
			$first_position  = array_search( $first->slug, $priority, true );
			$second_position = array_search( $second->slug, $priority, true );
			$first_position  = false === $first_position ? 999 : $first_position;
			$second_position = false === $second_position ? 999 : $second_position;
			return $first_position <=> $second_position ?: strcasecmp( $first->name, $second->name );
		}
	);

	return $terms;
}

/**
 * Legacy reference pages mapped to the matching real portfolio term.
 */
function tw_projects_legacy_routes() {
	return array(
		'one-page-referenze'                 => array( 'one-page' ),
		'aziendali-premium-referenze'        => array( 'aziendale-premium' ),
		'ecommerce-referenza'                => array( 'ecommerce' ),
		'applicazioni-ios-android-referenza' => array( 'app', 'applicazioni-ios-android' ),
	);
}

/**
 * Resolve a term by slug, constrained to the terms used by projects.
 */
function tw_projects_find_term( $taxonomy, $slug ) {
	$slug = sanitize_title( $slug );
	if ( ! $slug ) {
		return null;
	}
	foreach ( tw_projects_get_terms( $taxonomy ) as $term ) {
		if ( $slug === $term->slug ) {
			return $term;
		}
	}

	/* Legacy filtered routes can target a real project term that is intentionally
	 * omitted from the compact public filter bar (for example One-Page). */
	$term = get_term_by( 'slug', $slug, $taxonomy );
	if ( ! $term || is_wp_error( $term ) ) {
		return null;
	}
	$project_ids = tw_projects_get_ids();
	$matches     = get_objects_in_term( absint( $term->term_id ), $taxonomy );
	if ( is_wp_error( $matches ) || ! array_intersect( $project_ids, array_map( 'absint', $matches ) ) ) {
		return null;
	}
	return $term;
}

/**
 * Read a request value in WordPress and in the isolated contract test.
 */
function tw_projects_request_value( $key ) {
	global $tw_test_request;
	$value = isset( $_GET[ $key ] ) ? wp_unslash( $_GET[ $key ] ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	if ( '' === $value && isset( $tw_test_request[ $key ] ) ) {
		$value = $tw_test_request[ $key ];
	}
	return sanitize_text_field( $value );
}

/**
 * Build the active archive context for general, filtered and legacy URLs.
 */
function tw_projects_get_context() {
	$schema   = tw_projects_get_schema();
	$taxonomy = '';
	$term     = null;

	if ( is_tax() ) {
		$queried = get_queried_object();
		if ( $queried && in_array( $queried->taxonomy ?? '', array_filter( array( $schema['type_taxonomy'], $schema['sector_taxonomy'] ) ), true ) ) {
			$taxonomy = $queried->taxonomy;
			$term     = $queried;
		}
	}

	if ( ! $term ) {
		$type_slug   = tw_projects_request_value( 'tipologia' );
		$sector_slug = tw_projects_request_value( 'settore' );
		if ( $type_slug ) {
			$taxonomy = $schema['type_taxonomy'];
			$term     = tw_projects_find_term( $taxonomy, $type_slug );
		} elseif ( $sector_slug && $schema['sector_taxonomy'] ) {
			$taxonomy = $schema['sector_taxonomy'];
			$term     = tw_projects_find_term( $taxonomy, $sector_slug );
		}
	}

	if ( ! $term ) {
		foreach ( tw_projects_legacy_routes() as $page_slug => $term_slugs ) {
			if ( ! is_page( $page_slug ) ) {
				continue;
			}
			$taxonomy = $schema['type_taxonomy'];
			foreach ( $term_slugs as $term_slug ) {
				$term = tw_projects_find_term( $taxonomy, $term_slug );
				if ( $term ) {
					break;
				}
			}
			break;
		}
	}

	$general_title = __( 'Progetti e realizzazioni', 'ticinoweb-child-theme' );
	$title         = $term ? $term->name : $general_title;
	$intro         = $term && ! empty( $term->description )
		? $term->description
		: __( 'Una selezione di siti web, eCommerce, applicazioni e soluzioni digitali realizzate per aziende e organizzazioni.', 'ticinoweb-child-theme' );

	return array(
		'schema'       => $schema,
		'taxonomy'     => $term ? $taxonomy : '',
		'term_id'      => $term ? absint( $term->term_id ) : 0,
		'term_slug'    => $term ? $term->slug : '',
		'title'        => $title,
		'eyebrow'      => $term ? __( 'Realizzazioni / Tipologia', 'ticinoweb-child-theme' ) : __( 'Progetti / Realizzazioni', 'ticinoweb-child-theme' ),
		'intro'        => $intro,
		'type_terms'   => tw_projects_get_terms( $schema['type_taxonomy'] ),
		'sector_terms' => $schema['sector_taxonomy'] ? tw_projects_get_terms( $schema['sector_taxonomy'] ) : array(),
	);
}

/**
 * Normalize a project for the shared card component.
 */
function tw_projects_card_data( $project, $schema = null ) {
	$schema      = $schema ?: tw_projects_get_schema();
	$type_names  = $schema['type_taxonomy'] ? wp_get_post_terms( $project->ID, $schema['type_taxonomy'], array( 'fields' => 'names' ) ) : array();
	$sector_names = $schema['sector_taxonomy'] ? wp_get_post_terms( $project->ID, $schema['sector_taxonomy'], array( 'fields' => 'names' ) ) : array();

	return array(
		'id'       => (int) $project->ID,
		'title'    => get_the_title( $project ),
		'url'      => get_permalink( $project ),
		'image_id' => absint( get_post_thumbnail_id( $project ) ),
		'types'    => is_wp_error( $type_names ) ? array() : array_values( $type_names ),
		'sectors'  => is_wp_error( $sector_names ) ? array() : array_values( $sector_names ),
		'year'     => get_the_date( 'Y', $project ),
	);
}

/**
 * Query a bounded project batch for the active context.
 */
function tw_projects_query_batch( $context, $page = 1, $per_page = 12 ) {
	$schema     = $context['schema'] ?? tw_projects_get_schema();
	$batch_size = min( 12, max( 1, absint( $per_page ) ) );
	$args       = array(
		'post_type'           => $schema['post_type'],
		'post_status'         => 'publish',
		'posts_per_page'      => $batch_size,
		'paged'               => max( 1, absint( $page ) ),
		'orderby'             => 'date',
		'order'               => 'DESC',
		'ignore_sticky_posts' => true,
	);
	if ( $schema['flag_meta_key'] ) {
		$args['meta_query'] = array(
			array(
				'key'     => $schema['flag_meta_key'],
				'value'   => '1',
				'compare' => '=',
			),
		);
	}
	if ( ! empty( $context['taxonomy'] ) && ! empty( $context['term_id'] ) ) {
		$args['tax_query'] = array(
			array(
				'taxonomy' => $context['taxonomy'],
				'field'    => 'term_id',
				'terms'    => array( absint( $context['term_id'] ) ),
			),
		);
	}

	$query = new WP_Query( $args );
	$items = array_map(
		static fn( $project ) => tw_projects_card_data( $project, $schema ),
		$query->posts
	);
	$result = array(
		'items' => $items,
		'total' => (int) $query->found_posts,
		'pages' => (int) $query->max_num_pages,
	);
	wp_reset_postdata();
	return $result;
}

/**
 * Keep known indexed URLs while linking every filter through the same system.
 */
function tw_projects_term_url( $taxonomy, $term ) {
	$schema = tw_projects_get_schema();
	if ( $taxonomy === $schema['type_taxonomy'] ) {
		$legacy_by_term = array(
			'one-page'          => 'one-page-referenze',
			'aziendale-premium' => 'aziendali-premium-referenze',
			'ecommerce'         => 'ecommerce-referenza',
		);
		if ( isset( $legacy_by_term[ $term->slug ] ) ) {
			$page = get_page_by_path( $legacy_by_term[ $term->slug ] );
			if ( $page && 'publish' === get_post_status( $page ) ) {
				return get_permalink( $page );
			}
		}
	}
	$page = get_page_by_path( 'referenze' );
	$base = $page && 'publish' === get_post_status( $page ) ? get_permalink( $page ) : home_url( '/referenze/' );
	$key  = $taxonomy === $schema['sector_taxonomy'] ? 'settore' : 'tipologia';
	return add_query_arg( array( $key => $term->slug ), $base );
}

/**
 * Whether the current request belongs to the unified portfolio family.
 */
function tw_projects_is_archive() {
	if ( is_page( array_merge( array( 'referenze', 'showcase' ), array_keys( tw_projects_legacy_routes() ) ) ) ) {
		return true;
	}
	$schema = tw_projects_get_schema();
	return ( 'tw_project' === $schema['post_type'] && is_post_type_archive( 'tw_project' ) )
		|| ( $schema['type_taxonomy'] && is_tax( $schema['type_taxonomy'] ) )
		|| ( $schema['sector_taxonomy'] && is_tax( $schema['sector_taxonomy'] ) );
}

/**
 * Route legacy pages and real archives to one visual template.
 */
function tw_projects_template_include( $template ) {
	if ( ! tw_projects_is_archive() ) {
		return $template;
	}
	$archive_template = get_stylesheet_directory() . '/page-projects.php';
	return file_exists( $archive_template ) ? $archive_template : $template;
}
add_filter( 'template_include', 'tw_projects_template_include', 98 );

/**
 * Render one shared project card server-side.
 */
function tw_projects_render_card( $project ) {
	$meta = array_filter(
		array(
			implode( ' · ', array_slice( $project['types'] ?? array(), 0, 2 ) ),
			implode( ' · ', array_slice( $project['sectors'] ?? array(), 0, 1 ) ),
			$project['year'] ?? '',
		)
	);
	ob_start();
	?>
	<article class="tw-project-archive-card">
		<a href="<?php echo esc_url( $project['url'] ); ?>">
			<figure class="tw-project-archive-card__media">
				<?php
				if ( ! empty( $project['image_id'] ) ) {
					echo wp_get_attachment_image(
						$project['image_id'],
						'large',
						false,
						array(
							'alt'      => '',
							'loading'  => 'lazy',
							'decoding' => 'async',
							'sizes'    => '(max-width: 767px) calc(100vw - 32px), (max-width: 1599px) 46vw, 31vw',
						)
					); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				}
				?>
			</figure>
			<div class="tw-project-archive-card__body">
				<?php if ( $meta ) : ?><p><?php echo esc_html( implode( ' / ', $meta ) ); ?></p><?php endif; ?>
				<h2><?php echo esc_html( $project['title'] ); ?></h2>
				<span class="tw-arrow" aria-hidden="true"></span>
			</div>
		</a>
	</article>
	<?php
	return (string) ob_get_clean();
}

/**
 * Public REST endpoint returning the exact same server-rendered cards.
 */
function tw_projects_register_rest_route() {
	register_rest_route(
		'ticinoweb/v1',
		'/projects',
		array(
			'methods'             => 'GET',
			'permission_callback' => '__return_true',
			'callback'            => static function ( $request ) {
				if($request->get_param('context')==='home')return tw_home_projects_rest_request($request);
				$schema     = tw_projects_get_schema();
				$taxonomy   = sanitize_key( $request->get_param( 'taxonomy' ) );
				$term_slug  = sanitize_title( $request->get_param( 'term' ) );
				$allowed    = array_filter( array( $schema['type_taxonomy'], $schema['sector_taxonomy'] ) );
				$term       = in_array( $taxonomy, $allowed, true ) ? tw_projects_find_term( $taxonomy, $term_slug ) : null;
				$context    = array(
					'schema'   => $schema,
					'taxonomy' => $term ? $taxonomy : '',
					'term_id'  => $term ? absint( $term->term_id ) : 0,
				);
				$batch      = tw_projects_query_batch( $context, absint( $request->get_param( 'page' ) ), 12 );
				$batch['html'] = implode( '', array_map( 'tw_projects_render_card', $batch['items'] ) );
				unset( $batch['items'] );
				return rest_ensure_response( $batch );
			},
			'args'                => array(
				'context'  => array( 'type'=>'string', 'sanitize_callback'=>'sanitize_key', 'default'=>'archive', 'enum'=>array('archive','home') ),
				'term_id'  => array( 'type'=>'integer', 'sanitize_callback'=>'absint', 'minimum'=>0 ),
				'page'     => array( 'sanitize_callback' => 'absint', 'default' => 1 ),
				'taxonomy' => array( 'sanitize_callback' => 'sanitize_key' ),
				'term'     => array( 'sanitize_callback' => 'sanitize_title' ),
			),
		)
	);
}
add_action( 'rest_api_init', 'tw_projects_register_rest_route' );
