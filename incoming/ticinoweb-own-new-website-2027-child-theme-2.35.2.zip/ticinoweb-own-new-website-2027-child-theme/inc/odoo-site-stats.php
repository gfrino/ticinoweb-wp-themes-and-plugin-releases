<?php
/**
 * Statistiche delle visite del sito → Odoo (Social Publisher → Dashboard → Sito web).
 *
 * Il tema parent conta già visitatori, visite e tempo di lettura (senza cookie né dati personali) nella tabella
 * `tw_visit_stats`. Una volta al giorno mandiamo quei contatori a Odoo con la stessa connessione dei form
 * (Integrazione Odoo): il metodo `tw.social.site.push_stats` li salva così come li conta il sito. Un visitatore è
 * contato una volta per giorno, per settimana, per mese e per anno: i contatori di ogni periodo viaggiano separati,
 * perché la settimana non è la somma dei suoi sette giorni.
 *
 * Il primo invio manda tutto lo storico, i successivi solo gli ultimi periodi (Odoo sostituisce i contatori già
 * ricevuti). Se Odoo non risponde il tentativo si ripete dopo un'ora. L'utente Odoo dell'integrazione deve avere il
 * diritto «Utente» di Social Publisher.
 *
 * @package ticinoWEB_Child_Theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

const TW_ODOO_STATS_HOOK = 'tw_odoo_push_stats';
const TW_ODOO_STATS_LOG  = 'tw_odoo_stats_last';
const TW_ODOO_STATS_FLAG = 'tw_odoo_stats_sent_all';

/**
 * Contatori da mandare: [[chiave, visitatori, visite, secondi], …].
 *
 * @param bool $full Tutto lo storico (primo invio) o solo gli ultimi periodi.
 */
function tw_odoo_stats_rows( $full ) {
	if ( ! function_exists( 'ticinoweb_stats_all' ) || ! function_exists( 'ticinoweb_stats_periods' ) || ! function_exists( 'ticinoweb_stats_unique' ) ) {
		return array();
	}
	$data = ticinoweb_stats_all();
	$plan = $full
		? array( 'd' => 800, 'w' => 120, 'm' => 30, 'y' => 5 )
		: array( 'd' => 60, 'w' => 10, 'm' => 4, 'y' => 2 );
	$rows = array();
	foreach ( $plan as $type => $count ) {
		foreach ( ticinoweb_stats_periods( $type, $count ) as $period ) {
			$key      = $period['key'];
			$visitors = (int) ticinoweb_stats_unique( $period, $data );
			$visits   = (int) ( $data[ $key ]['s'] ?? 0 );
			$seconds  = (int) ( $data[ $key ]['t'] ?? 0 );
			if ( $visitors || $visits || $seconds ) {
				$rows[] = array( $key, $visitors, $visits, $seconds );
			}
		}
	}
	return $rows;
}

/** Manda i contatori a Odoo. Restituisce il risultato di Odoo o un WP_Error. */
function tw_odoo_push_site_stats() {
	$s = tw_odoo_settings();
	if ( empty( $s['enabled'] ) ) {
		return new WP_Error( 'tw_odoo_off', 'L’invio a Odoo non è attivo (Integrazione Odoo).' );
	}
	$full = ! get_option( TW_ODOO_STATS_FLAG );
	$rows = tw_odoo_stats_rows( $full );
	if ( ! $rows ) {
		return new WP_Error( 'tw_odoo_no_stats', 'Nessun contatore di visite da mandare.' );
	}
	$result = null;
	foreach ( array_chunk( $rows, 800 ) as $chunk ) {
		$result = tw_odoo_call( 'tw.social.site', 'push_stats', array( home_url( '/' ), $chunk ) );
		if ( is_wp_error( $result ) ) {
			return $result;
		}
	}
	if ( $full ) {
		update_option( TW_ODOO_STATS_FLAG, 1, false );
	}
	return is_array( $result ) ? array_merge( $result, array( 'sent' => count( $rows ) ) ) : array( 'sent' => count( $rows ) );
}

/** Esegue l'invio, lo registra e, se fallisce, riprova tra un'ora (al massimo 24 volte di fila). */
function tw_odoo_run_stats_push() {
	try {
		$result = tw_odoo_push_site_stats();
	} catch ( Throwable $e ) {
		$result = new WP_Error( 'tw_odoo_exception', $e->getMessage() );
	}
	if ( is_wp_error( $result ) ) {
		update_option( TW_ODOO_STATS_LOG, array( 'time' => time(), 'ok' => false, 'message' => $result->get_error_message() ), false );
		$tries = (int) get_transient( 'tw_odoo_stats_tries' ) + 1;
		set_transient( 'tw_odoo_stats_tries', $tries, DAY_IN_SECONDS );
		if ( $tries < 24 && 'tw_odoo_off' !== $result->get_error_code() && ! wp_next_scheduled( TW_ODOO_STATS_HOOK . '_retry' ) ) {
			wp_schedule_single_event( time() + HOUR_IN_SECONDS, TW_ODOO_STATS_HOOK . '_retry' );
		}
		return $result;
	}
	delete_transient( 'tw_odoo_stats_tries' );
	update_option( TW_ODOO_STATS_LOG, array(
		'time'    => time(),
		'ok'      => true,
		'message' => sprintf( 'Mandati %d contatori di visite a Odoo.', (int) ( $result['sent'] ?? 0 ) ),
	), false );
	return $result;
}

add_action( TW_ODOO_STATS_HOOK, 'tw_odoo_run_stats_push' );
add_action( TW_ODOO_STATS_HOOK . '_retry', 'tw_odoo_run_stats_push' );

// Ogni notte, poco dopo le 3:30 (ora del sito).
add_action( 'init', function () {
	if ( wp_doing_ajax() || ! function_exists( 'tw_odoo_settings' ) || wp_next_scheduled( TW_ODOO_STATS_HOOK ) ) {
		return;
	}
	if ( empty( tw_odoo_settings()['enabled'] ) ) {
		return;
	}
	$first = new DateTimeImmutable( 'tomorrow 03:40', wp_timezone() );
	wp_schedule_event( $first->getTimestamp(), 'daily', TW_ODOO_STATS_HOOK );
} );

add_action( 'admin_post_tw_odoo_push_stats', function () {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( 'Non autorizzato.' );
	}
	check_admin_referer( 'tw_odoo_push_stats' );
	tw_odoo_run_stats_push();
	wp_safe_redirect( add_query_arg( array( 'page' => 'tw-odoo', 'stats' => 1 ), admin_url( 'admin.php' ) ) );
	exit;
} );

/** Blocco «Statistiche delle visite» nella pagina Integrazione Odoo. */
function tw_odoo_render_stats_status() {
	$log = get_option( TW_ODOO_STATS_LOG, array() );
	?>
	<h2>Statistiche delle visite</h2>
	<p>Ogni notte i contatori delle visite (visitatori, visite, tempo di lettura) vanno a Odoo, nella dashboard di Social Publisher. L’utente Odoo qui sopra deve avere il diritto «Utente» di Social Publisher.</p>
	<?php if ( $log ) : ?>
		<p><strong><?php echo ! empty( $log['ok'] ) ? 'Ultimo invio riuscito' : 'Ultimo invio non riuscito'; ?></strong> (<?php echo esc_html( wp_date( 'd.m.Y H:i', (int) $log['time'] ) ); ?>): <?php echo esc_html( $log['message'] ); ?></p>
	<?php else : ?>
		<p>Nessun invio ancora.</p>
	<?php endif; ?>
	<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
		<input type="hidden" name="action" value="tw_odoo_push_stats">
		<?php wp_nonce_field( 'tw_odoo_push_stats' ); ?>
		<?php submit_button( 'Manda le statistiche ora', 'secondary', 'submit', false ); ?>
	</form>
	<?php
}
