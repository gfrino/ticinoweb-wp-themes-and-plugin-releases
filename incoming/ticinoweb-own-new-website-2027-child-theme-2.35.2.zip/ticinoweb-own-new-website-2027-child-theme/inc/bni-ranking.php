<?php
/**
 * Classifica referenze BNI Verzasca (pagina con template «ticinoWEB — Classifica BNI»).
 *
 * I dati si leggono da Odoo (ticinoweb.online, menu «BNI Verzasca») con la connessione
 * dei form (inc/odoo-integration.php): membri attivi `x_bni_member` e referenze `x_bni_referral`
 * del gioco (`x_game`): le referenze ricevute da ticinoWEB prima dell'inizio del gioco non contano.
 * Quando in Odoo si aggiunge una referenza, la pagina si aggiorna da sola entro 15 minuti.
 * Se Odoo non risponde si mostra l'ultima classifica letta.
 *
 * Le statistiche del gioco si aggiornano una volta a settimana, al meeting: la pagina mostra i dati fino alla
 * fine dell'ultima settimana chiusa (mercoledì alle 08:00). Settimana = da mercoledì 08:01 a mercoledì 08:00;
 * mese e anno sono quelli in cui cade la fine della settimana chiusa. Fuso del sito.
 * L'ora di una referenza è `x_datetime` (UTC in Odoo); se manca vale `x_date` alle 12:00.
 * La pagina va in noindex dal metabox SEO del parent (`_tw_seo_robots`).
 *
 * @package ticinoWEB_Child_Theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

const TW_BNI_CACHE = 'tw_bni_ranking_cache';
const TW_BNI_LAST  = 'tw_bni_ranking_last';
const TW_BNI_GAME_START = '2026-10-14 08:01'; // Inizio del gioco (mercoledì della prima settimana, ora locale).

/**
 * Membri attivi e date delle referenze da Odoo, con cache di 15 minuti.
 *
 * @return array{members:array<int,array{id:int,name:string}>,referrals:array<int,array{member:int,date:string}>,fetched:string}|null
 */
function tw_bni_ranking_fetch() {
	$cached = get_transient( TW_BNI_CACHE );
	if ( is_array( $cached ) ) {
		return $cached;
	}
	$data = null;
	if ( function_exists( 'tw_odoo_call' ) ) {
		$members = tw_odoo_call( 'x_bni_member', 'search_read', array( array( array( 'x_active', '=', true ) ) ), array( 'fields' => array( 'x_name' ) ) );
		$refs    = tw_odoo_call( 'x_bni_referral', 'search_read', array( array( array( 'x_game', '=', true ) ) ), array( 'fields' => array( 'x_date', 'x_datetime', 'x_member_id' ) ) );
		if ( is_array( $members ) && is_array( $refs ) && ! is_wp_error( $members ) && ! is_wp_error( $refs ) ) {
			$data = array( 'members' => array(), 'referrals' => array(), 'fetched' => current_datetime()->format( 'Y-m-d H:i' ) );
			foreach ( $members as $m ) {
				if ( ! empty( $m['id'] ) && ! empty( $m['x_name'] ) ) {
					$data['members'][] = array( 'id' => (int) $m['id'], 'name' => sanitize_text_field( (string) $m['x_name'] ) );
				}
			}
			foreach ( $refs as $r ) {
				if ( ! empty( $r['x_date'] ) && ! empty( $r['x_member_id'][0] ) ) {
					$stamp = substr( (string) $r['x_date'], 0, 10 ) . ' 12:00:00';
					if ( ! empty( $r['x_datetime'] ) ) {
						$utc = date_create_immutable( (string) $r['x_datetime'], new DateTimeZone( 'UTC' ) );
						if ( $utc ) {
							$stamp = $utc->setTimezone( wp_timezone() )->format( 'Y-m-d H:i:s' );
						}
					}
					$data['referrals'][] = array( 'member' => (int) $r['x_member_id'][0], 'date' => substr( $stamp, 0, 10 ), 'stamp' => $stamp );
				}
			}
			update_option( TW_BNI_LAST, $data, false );
		}
	}
	if ( null === $data ) {
		$last = get_option( TW_BNI_LAST );
		$data = is_array( $last ) ? $last : null;
	}
	if ( null !== $data ) {
		set_transient( TW_BNI_CACHE, $data, 15 * MINUTE_IN_SECONDS );
	}
	return $data;
}

/**
 * Ultima settimana del gioco già chiusa al momento dato: da mercoledì 08:01 a mercoledì 08:00.
 *
 * @param DateTimeImmutable $now Momento di riferimento (fuso del sito).
 * @return array{0:string,1:string} Inizio (incluso) e fine (inclusa), Y-m-d H:i.
 */
function tw_bni_week( DateTimeImmutable $now ) {
	$back = ( (int) $now->format( 'N' ) - 3 + 7 ) % 7; // N: 1 = lunedì … 7 = domenica; 3 = mercoledì.
	$end  = $now->setTime( 8, 0 )->modify( "-{$back} days" );
	if ( $end > $now ) {
		$end = $end->modify( '-7 days' );
	}
	return array( $end->modify( '-7 days +1 minute' )->format( 'Y-m-d H:i' ), $end->format( 'Y-m-d H:i' ) );
}

/**
 * Classifica: referenze di settimana, mese e anno per ogni membro attivo.
 * Ordine e posizione seguono l'anno (pari merito = stessa posizione), poi mese e settimana.
 *
 * @param DateTimeImmutable|null $today Oggi (per i test).
 * @param array|null             $data  Dati già letti (per i test).
 * @return array{ok:bool,today:string,week_from:string,week_to:string,year:string,total:int,start:string,members:array<int,array{name:string,week:int,month:int,year:int,rank:int}>}
 */
function tw_bni_ranking_data( $today = null, $data = null ) {
	$today = $today instanceof DateTimeImmutable ? $today : current_datetime();
	$data  = null === $data ? tw_bni_ranking_fetch() : $data;
	list( $week_from, $week_to ) = tw_bni_week( $today );
	$cut   = $week_to . ':59';
	$month = substr( $week_to, 0, 7 );
	$year  = substr( $week_to, 0, 4 );

	$rows = array();
	foreach ( (array) ( $data['members'] ?? array() ) as $m ) {
		$rows[ $m['id'] ] = array( 'name' => $m['name'], 'week' => 0, 'month' => 0, 'year' => 0 );
	}
	$total = 0;
	$start = '';
	foreach ( (array) ( $data['referrals'] ?? array() ) as $r ) {
		$stamp = $r['stamp'] ?? ( $r['date'] . ' 12:00:00' );
		if ( ! isset( $rows[ $r['member'] ] ) || $stamp > $cut ) {
			continue;
		}
		++$total;
		if ( '' === $start || $stamp < $start ) {
			$start = substr( $stamp, 0, 16 );
		}
		if ( substr( $r['date'], 0, 4 ) === $year ) {
			++$rows[ $r['member'] ]['year'];
		}
		if ( substr( $r['date'], 0, 7 ) === $month ) {
			++$rows[ $r['member'] ]['month'];
		}
		if ( $stamp >= $week_from . ':00' && $stamp <= $week_to . ':59' ) {
			++$rows[ $r['member'] ]['week'];
		}
	}
	$members = array_values( $rows );
	usort(
		$members,
		static function ( $a, $b ) {
			return ( $b['year'] <=> $a['year'] ) ?: ( $b['month'] <=> $a['month'] ) ?: ( $b['week'] <=> $a['week'] ) ?: strcasecmp( $a['name'], $b['name'] );
		}
	);
	foreach ( $members as $i => $m ) {
		$members[ $i ]['rank'] = ( $i > 0 && $members[ $i - 1 ]['year'] === $m['year'] ) ? $members[ $i - 1 ]['rank'] : $i + 1;
	}
	return array(
		'ok'        => null !== $data,
		'today'     => $today->format( 'Y-m-d' ),
		'until'     => $week_to,
		'week_from' => $week_from,
		'week_to'   => $week_to,
		'year'      => $year,
		'total'     => $total,
		'start'     => ( '' === $start || $start > TW_BNI_GAME_START ) ? TW_BNI_GAME_START : $start,
		'members'   => $members,
	);
}

/**
 * Una sezione della classifica: solo i membri con almeno una referenza nel periodo,
 * ordinati per quel periodo (pari merito = stessa posizione, poi in ordine alfabetico).
 *
 * @param array  $members Righe di tw_bni_ranking_data()['members'].
 * @param string $key     'week', 'month' o 'year'.
 * @return array<int,array{name:string,count:int,rank:int}>
 */
function tw_bni_ranking_section( array $members, $key ) {
	$rows = array();
	foreach ( $members as $m ) {
		if ( ! empty( $m[ $key ] ) ) {
			$rows[] = array( 'name' => $m['name'], 'count' => (int) $m[ $key ] );
		}
	}
	usort(
		$rows,
		static function ( $a, $b ) {
			return ( $b['count'] <=> $a['count'] ) ?: strcasecmp( $a['name'], $b['name'] );
		}
	);
	foreach ( $rows as $i => $r ) {
		$rows[ $i ]['rank'] = ( $i > 0 && $rows[ $i - 1 ]['count'] === $r['count'] ) ? $rows[ $i - 1 ]['rank'] : $i + 1;
	}
	return $rows;
}

/**
 * Carica il CSS solo sulla pagina della classifica.
 */
function tw_bni_ranking_enqueue() {
	if ( ! is_page_template( 'page-classifica-bni.php' ) ) {
		return;
	}
	wp_enqueue_style(
		'ticinoweb-child-bni-ranking',
		get_stylesheet_directory_uri() . '/assets/css/bni-ranking.css',
		array( 'ticinoweb-child-site' ),
		wp_get_theme()->get( 'Version' )
	);
}
add_action( 'wp_enqueue_scripts', 'tw_bni_ranking_enqueue', 30 );
