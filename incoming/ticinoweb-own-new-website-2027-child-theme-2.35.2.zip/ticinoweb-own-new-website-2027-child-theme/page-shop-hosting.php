<?php
/**
 * Template Name: ticinoWEB — Shop Hosting
 *
 * Catalogo dei pacchetti hosting (categoria WooCommerce «hosting»), stessa grafica del catalogo software.
 *
 * @package ticinoWEB_Child_Theme
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

$tw_products = tw_software_products( 'hosting', 'price' );
get_header();
?>
<main class="tw-software tw-hosting">
	<header class="tw-software-hero">
		<div class="tw-shell">
			<p class="tw-software-kicker"><?php esc_html_e( 'Shop', 'ticinoweb-child-theme' ); ?></p>
			<h1><?php echo esc_html( get_the_title() ); ?></h1>
			<div class="tw-software-intro">
				<?php
				$tw_intro = trim( wp_strip_all_tags( get_post_field( 'post_content', get_the_ID() ) ) );
				echo $tw_intro ? wp_kses_post( wpautop( get_post_field( 'post_content', get_the_ID() ) ) ) : '<p>' . esc_html__( 'Hosting WordPress su server svizzeri, gestito da ticinoWEB: tu pensi al tuo business, al resto pensiamo noi.', 'ticinoweb-child-theme' ) . '</p>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				?>
			</div>
			<ul class="tw-software-points">
				<li><?php esc_html_e( 'Server 100% svizzeri', 'ticinoweb-child-theme' ); ?></li>
				<li><?php esc_html_e( 'Dominio gestito da ticinoWEB', 'ticinoweb-child-theme' ); ?></li>
				<li><?php esc_html_e( 'Assistenza in Ticino', 'ticinoweb-child-theme' ); ?></li>
			</ul>
		</div>
	</header>
	<div class="tw-shell tw-software-results">
		<?php if ( $tw_products ) : ?>
			<div class="tw-software-grid">
				<?php foreach ( $tw_products as $tw_product ) : ?>
					<?php
					$tw_url   = get_permalink( $tw_product->get_id() );
					$tw_short = wp_trim_words( wp_strip_all_tags( $tw_product->get_short_description() ), 26 );
					?>
					<article class="tw-software-card">
						<a class="tw-software-card__media is-icon" href="<?php echo esc_url( $tw_url ); ?>" tabindex="-1" aria-hidden="true">
							<?php
							if ( $tw_product->get_image_id() ) {
								echo wp_get_attachment_image( $tw_product->get_image_id(), 'medium', false, array( 'alt' => '', 'loading' => 'lazy', 'decoding' => 'async' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
							}
							?>
						</a>
						<div class="tw-software-card__body">
							<h2><a href="<?php echo esc_url( $tw_url ); ?>"><?php echo esc_html( $tw_product->get_name() ); ?></a></h2>
							<?php if ( $tw_short ) : ?><p class="tw-software-card__text"><?php echo esc_html( $tw_short ); ?></p><?php endif; ?>
							<div class="tw-software-card__foot">
								<span class="tw-software-card__price"><?php echo wp_kses_post( $tw_product->get_price_html() ); ?></span>
								<a class="tw-software-btn" href="<?php echo esc_url( $tw_url ); ?>"><?php esc_html_e( 'Scopri di più', 'ticinoweb-child-theme' ); ?><span class="tw-arrow" aria-hidden="true"></span></a>
							</div>
						</div>
					</article>
				<?php endforeach; ?>
			</div>
		<?php else : ?>
			<div class="tw-software-empty">
				<h2><?php esc_html_e( 'Pacchetti hosting in arrivo', 'ticinoweb-child-theme' ); ?></h2>
				<a class="tw-software-btn is-solid" href="<?php echo esc_url( function_exists( 'tw_home_mapped_url' ) ? tw_home_mapped_url( 'page_contatti', 'contatti' ) : home_url( '/contatti/' ) ); ?>"><?php esc_html_e( 'Contattaci', 'ticinoweb-child-theme' ); ?></a>
			</div>
		<?php endif; ?>
	</div>
</main>
<?php get_footer(); ?>
