<?php
/**
 * Template Name: ticinoWEB — Wordpress Software
 *
 * Catalogo dei plugin in vendita: i prodotti nascono da soli dalle release (inc/software-store.php).
 *
 * @package ticinoWEB_Child_Theme
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

$tw_products = tw_software_products();
get_header();
?>
<main class="tw-software">
	<header class="tw-software-hero">
		<div class="tw-shell">
			<p class="tw-software-kicker"><?php esc_html_e( 'Shop', 'ticinoweb-child-theme' ); ?></p>
			<h1><?php echo esc_html( get_the_title() ); ?></h1>
			<div class="tw-software-intro">
				<?php
				$tw_intro = trim( wp_strip_all_tags( get_post_field( 'post_content', get_the_ID() ) ) );
				echo $tw_intro ? wp_kses_post( wpautop( get_post_field( 'post_content', get_the_ID() ) ) ) : '<p>' . esc_html__( 'Plugin WordPress sviluppati da ticinoWEB a Locarno: pronti all’uso, per siti che devono funzionare ogni giorno.', 'ticinoweb-child-theme' ) . '</p>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				?>
			</div>
			<ul class="tw-software-points">
				<li><?php esc_html_e( 'Licenza perpetua, nessun canone annuale', 'ticinoweb-child-theme' ); ?></li>
				<li><?php esc_html_e( 'Download subito dopo l’acquisto', 'ticinoweb-child-theme' ); ?></li>
				<li><?php esc_html_e( 'Sviluppati e seguiti in Ticino', 'ticinoweb-child-theme' ); ?></li>
			</ul>
		</div>
	</header>
	<div class="tw-shell tw-software-results">
		<?php if ( $tw_products ) : ?>
			<div class="tw-software-grid">
				<?php foreach ( $tw_products as $tw_product ) : ?>
					<?php
					$tw_pid    = $tw_product->get_id();
					$tw_url    = get_permalink( $tw_pid );
					$tw_ver    = get_post_meta( $tw_pid, '_twss_version', true );
					$tw_banner = (int) get_post_meta( $tw_pid, '_twss_banner_id', true );
					$tw_short  = wp_trim_words( wp_strip_all_tags( $tw_product->get_short_description() ), 26 );
					?>
					<article class="tw-software-card">
						<a class="tw-software-card__media<?php echo $tw_banner ? '' : ' is-icon'; ?>" href="<?php echo esc_url( $tw_url ); ?>" tabindex="-1" aria-hidden="true">
							<?php
							if ( $tw_banner ) {
								echo wp_get_attachment_image( $tw_banner, 'large', false, array( 'alt' => '', 'loading' => 'lazy', 'decoding' => 'async', 'sizes' => '(max-width: 700px) 100vw, (max-width: 1100px) 50vw, 33vw' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
							} elseif ( $tw_product->get_image_id() ) {
								echo wp_get_attachment_image( $tw_product->get_image_id(), 'medium', false, array( 'alt' => '', 'loading' => 'lazy', 'decoding' => 'async' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
							}
							?>
						</a>
						<div class="tw-software-card__body">
							<p class="tw-software-card__chips">
								<?php if ( $tw_ver ) : ?><span><?php echo esc_html( sprintf( /* translators: %s: plugin version */ __( 'Versione %s', 'ticinoweb-child-theme' ), $tw_ver ) ); ?></span><?php endif; ?>
								<span><?php esc_html_e( 'Licenza perpetua', 'ticinoweb-child-theme' ); ?></span>
							</p>
							<h2><a href="<?php echo esc_url( $tw_url ); ?>"><?php echo esc_html( $tw_product->get_name() ); ?></a></h2>
							<?php if ( $tw_short ) : ?><p class="tw-software-card__text"><?php echo esc_html( $tw_short ); ?></p><?php endif; ?>
							<div class="tw-software-card__foot">
								<span class="tw-software-card__price"><?php echo wp_kses_post( $tw_product->get_price_html() ); ?></span>
								<a class="tw-software-btn" href="<?php echo esc_url( $tw_url ); ?>"><?php esc_html_e( 'Scopri di più', 'ticinoweb-child-theme' ); ?><span class="tw-arrow" aria-hidden="true"></span></a>
							</div>
						</div>
					</article>
				<?php endforeach; ?>
			</div>
		<?php else : ?>
			<div class="tw-software-empty">
				<h2><?php esc_html_e( 'Nuovi plugin in arrivo', 'ticinoweb-child-theme' ); ?></h2>
				<p><?php esc_html_e( 'Stiamo preparando il catalogo. Hai bisogno di una funzione su misura per il tuo sito? Scrivici.', 'ticinoweb-child-theme' ); ?></p>
				<a class="tw-software-btn is-solid" href="<?php echo esc_url( function_exists( 'tw_home_mapped_url' ) ? tw_home_mapped_url( 'page_contatti', 'contatti' ) : home_url( '/contatti/' ) ); ?>"><?php esc_html_e( 'Contattaci', 'ticinoweb-child-theme' ); ?></a>
			</div>
		<?php endif; ?>
	</div>
</main>
<?php get_footer(); ?>
