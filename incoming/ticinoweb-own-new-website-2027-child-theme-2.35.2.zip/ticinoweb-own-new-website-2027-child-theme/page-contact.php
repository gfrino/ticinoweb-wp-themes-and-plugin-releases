<?php
/**
 * Template Name: ticinoWEB — Contatti / Parliamo del tuo progetto
 * Pagina di conversione: un solo obiettivo, il form compilato.
 */
if ( ! defined( 'ABSPATH' ) ) exit;
$contact = function_exists( 'ticinoweb_get_contact_info' ) ? ticinoweb_get_contact_info() : array();
$reviews = function_exists( 'tw_home_get_reviews' ) ? tw_home_get_reviews() : array();
$phone   = $contact['phone'] ?? '';
$mobile  = (string) get_option( 'ticinoweb_contact_phone_mobile', '' );
$wa      = $mobile ? 'https://wa.me/' . preg_replace( '/[^0-9]/', '', $mobile ) : '';
$maps    = ! empty( $contact['address'] ) ? 'https://www.google.com/maps/search/?api=1&query=' . rawurlencode( $contact['address'] ) : '';
$about   = tw_home_mapped_url( 'page_chi_siamo', 'chi-siamo' );
get_header();
?>
<main id="main-content" class="tw-about-page tw-contact-page">
	<section class="tw-about-contact tw-contact-hero" id="parliamo">
		<div class="tw-shell tw-contact-grid">
			<div class="tw-contact-intro">
				<p class="tw-kicker"><?php esc_html_e( 'Contatti', 'ticinoweb-child-theme' ); ?></p>
				<h1><?php esc_html_e( 'Parliamo del tuo progetto', 'ticinoweb-child-theme' ); ?></h1>
				<p class="tw-contact-lead"><?php esc_html_e( 'Raccontaci in poche righe cosa hai in mente: un sito, un e-commerce, un’app, un gestionale o una campagna. Ti rispondiamo personalmente e ti proponiamo una prima consulenza gratuita e senza impegno.', 'ticinoweb-child-theme' ); ?></p>

				<ol class="tw-contact-steps">
					<li><strong><?php esc_html_e( 'Ci scrivi', 'ticinoweb-child-theme' ); ?></strong><span><?php esc_html_e( 'Bastano due minuti: non serve avere già tutto chiaro.', 'ticinoweb-child-theme' ); ?></span></li>
					<li><strong><?php esc_html_e( 'Ti ricontattiamo', 'ticinoweb-child-theme' ); ?></strong><span><?php esc_html_e( 'Una persona del team legge la richiesta e ti risponde nel modo che preferisci.', 'ticinoweb-child-theme' ); ?></span></li>
					<li><strong><?php esc_html_e( 'Consulenza gratuita', 'ticinoweb-child-theme' ); ?></strong><span><?php esc_html_e( 'In sede a Locarno, al telefono o in video, poi una proposta chiara.', 'ticinoweb-child-theme' ); ?></span></li>
				</ol>

				<?php if ( ! empty( $reviews['rating'] ) ) : ?>
					<p class="tw-contact-proof"><strong><?php echo esc_html( $reviews['rating'] ); ?>/5</strong> <span aria-hidden="true">★★★★★</span> <?php echo esc_html( sprintf( __( 'su %d recensioni Google', 'ticinoweb-child-theme' ), absint( $reviews['count'] ?? 0 ) ) ); ?></p>
				<?php endif; ?>

				<div class="tw-contact-direct">
					<p class="tw-contact-direct__label"><?php esc_html_e( 'Preferisci parlarci subito?', 'ticinoweb-child-theme' ); ?></p>
					<?php if ( $phone ) : ?><a href="<?php echo esc_url( 'tel:' . preg_replace( '/[^+0-9]/', '', $phone ) ); ?>"><?php echo esc_html( $phone ); ?></a><?php endif; ?>
					<?php if ( $wa ) : ?><a href="<?php echo esc_url( $wa ); ?>" target="_blank" rel="noopener noreferrer">WhatsApp</a><?php endif; ?>
					<?php if ( ! empty( $contact['email'] ) ) : ?><a href="<?php echo esc_url( 'mailto:' . $contact['email'] ); ?>"><?php echo esc_html( $contact['email'] ); ?></a><?php endif; ?>
				</div>
			</div>

			<form class="tw-about-form tw-contact-form" data-tw-about-form method="post" action="<?php echo esc_url( admin_url( 'admin-ajax.php' ) ); ?>">
				<input type="hidden" name="action" value="ticinoweb_submit_form">
				<input type="hidden" name="tw_form_context" value="about">
				<input type="hidden" name="tw_contact_page" value="1">

				<fieldset class="tw-contact-chips">
					<legend><?php esc_html_e( 'Di cosa hai bisogno?', 'ticinoweb-child-theme' ); ?></legend>
					<div>
						<?php foreach ( tw_contact_project_types() as $key => $label ) : ?>
							<label><input type="checkbox" name="progetto[]" value="<?php echo esc_attr( $key ); ?>"><span><?php echo esc_html( $label ); ?></span></label>
						<?php endforeach; ?>
					</div>
				</fieldset>

				<label><?php esc_html_e( 'Raccontaci il progetto', 'ticinoweb-child-theme' ); ?> *<textarea name="messaggio" required minlength="5" maxlength="4500" rows="5" placeholder="<?php esc_attr_e( 'Obiettivi, idee, esempi che ti piacciono…', 'ticinoweb-child-theme' ); ?>"></textarea></label>

				<div class="tw-about-form-row">
					<label><?php esc_html_e( 'Nome e cognome', 'ticinoweb-child-theme' ); ?> *<input name="nome" autocomplete="name" required minlength="2" maxlength="150"></label>
					<label><?php esc_html_e( 'Email', 'ticinoweb-child-theme' ); ?> *<input type="email" name="email" autocomplete="email" required maxlength="254"></label>
				</div>
				<div class="tw-about-form-row">
					<label><?php esc_html_e( 'Nome azienda (facoltativo)', 'ticinoweb-child-theme' ); ?><input name="azienda" autocomplete="organization" maxlength="200"></label>
					<label><?php esc_html_e( 'Telefono (facoltativo)', 'ticinoweb-child-theme' ); ?><input type="tel" name="telefono" autocomplete="tel" maxlength="80"></label>
				</div>

				<div class="tw-about-hp" aria-hidden="true"><label>Website<input name="tw_hp" tabindex="-1" autocomplete="off"></label></div>
				<label class="tw-about-privacy"><input type="checkbox" name="privacy" value="1" required><span><?php esc_html_e( 'Ho letto e accetto l’informativa', 'ticinoweb-child-theme' ); ?> <a href="<?php echo esc_url( get_privacy_policy_url() ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'privacy', 'ticinoweb-child-theme' ); ?></a>. *</span></label>
				<button class="tw-button" type="submit"><?php esc_html_e( 'Invia la richiesta', 'ticinoweb-child-theme' ); ?> <span class="tw-arrow" aria-hidden="true"></span></button>
				<p class="tw-contact-reassure"><?php esc_html_e( 'Gratuito e senza impegno. I tuoi dati servono solo per risponderti.', 'ticinoweb-child-theme' ); ?></p>
				<p id="tw-about-form-status" class="tw-about-form-status" role="status" aria-live="polite" tabindex="-1"></p>
				<noscript><p><?php esc_html_e( 'Per usare il modulo abilita JavaScript, oppure contattaci via telefono o email.', 'ticinoweb-child-theme' ); ?></p></noscript>
			</form>
		</div>
	</section>

	<section class="tw-contact-visit">
		<div class="tw-shell tw-contact-visit__grid">
			<div>
				<p class="tw-kicker"><?php esc_html_e( 'Vieni a trovarci', 'ticinoweb-child-theme' ); ?></p>
				<h2><?php esc_html_e( 'Ci trovi a Locarno', 'ticinoweb-child-theme' ); ?></h2>
				<?php if ( ! empty( $contact['address'] ) ) : ?><p class="tw-about-address"><?php echo esc_html( $contact['address'] ); ?></p><?php endif; ?>
				<?php if ( $maps ) : ?><a class="tw-text-link" href="<?php echo esc_url( $maps ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Apri in Google Maps', 'ticinoweb-child-theme' ); ?> <span class="tw-arrow" aria-hidden="true"></span></a><?php endif; ?>
			</div>
			<div>
				<p class="tw-kicker"><?php esc_html_e( 'Su appuntamento', 'ticinoweb-child-theme' ); ?></p>
				<p class="tw-about-copy"><?php esc_html_e( 'Ti accogliamo in sede per la prima consulenza: fissiamo insieme l’appuntamento dopo la tua richiesta.', 'ticinoweb-child-theme' ); ?></p>
				<a class="tw-text-link" href="<?php echo esc_url( $about ); ?>"><?php esc_html_e( 'Conosci il team ticinoWEB', 'ticinoweb-child-theme' ); ?> <span class="tw-arrow" aria-hidden="true"></span></a>
			</div>
		</div>
	</section>
</main>
<?php get_footer();
