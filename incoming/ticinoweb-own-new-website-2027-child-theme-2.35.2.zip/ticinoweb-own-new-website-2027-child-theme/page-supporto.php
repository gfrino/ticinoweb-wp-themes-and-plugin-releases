<?php
/**
 * Simple Support page.
 *
 * THESIS: one clear path from problem to the right human support channel.
 * OWN-WORLD: warm paper, Ink type, fine rules and restrained blue details.
 * STORY: orient, request remote access, choose a service, understand the care.
 * FIRST VIEWPORT: compact promise followed immediately by the remote-access path.
 * FORM: calm service desk, not a campaign landing page.
 *
 * @package ticinoWEB_Child_Theme
 */

get_header();

while ( have_posts() ) :
	the_post();
	$tw_support_post_id          = get_the_ID();
	$tw_support_raw_content      = (string) get_post_field( 'post_content', $tw_support_post_id );
	$tw_support_rendered_content = (string) apply_filters( 'the_content', $tw_support_raw_content );
	$tw_support_contact          = function_exists( 'ticinoweb_get_contact_info' ) ? ticinoweb_get_contact_info() : array();
	$tw_support_email            = sanitize_email( (string) ( $tw_support_contact['email'] ?? get_option( 'admin_email', '' ) ) );
	$tw_support_phone            = trim( (string) ( $tw_support_contact['phone'] ?? '' ) );
	$tw_support_phone_label      = trim( (string) get_option( 'ticinoweb_contact_phone_display', '' ) ) ?: $tw_support_phone;
	$tw_support_phone_href       = preg_replace( '/[^0-9+]/', '', $tw_support_phone );
	$tw_support_paragraphs       = tw_support_extract_description_paragraphs( $tw_support_rendered_content );
	$tw_support_remote_href      = tw_support_build_mailto( $tw_support_email, __( 'Richiesta accesso remoto', 'ticinoweb-child-theme' ), __( 'Accesso remoto', 'ticinoweb-child-theme' ) );
	$tw_support_contact_href = tw_support_build_mailto( $tw_support_email, __( 'Richiesta assistenza', 'ticinoweb-child-theme' ), __( 'Assistenza generale', 'ticinoweb-child-theme' ) );
	$tw_zoho_logo = '';
	foreach ( array( 'svg', 'png', 'webp' ) as $tw_ext ) {
		if ( file_exists( get_stylesheet_directory() . '/assets/images/zoho-assist.' . $tw_ext ) ) {
			$tw_zoho_logo = get_stylesheet_directory_uri() . '/assets/images/zoho-assist.' . $tw_ext;
			break;
		}
	}
	$tw_support_services = array(
		'odoo' => array(
			'number'      => '01',
			'title'       => __( 'Odoo', 'ticinoweb-child-theme' ),
			'description' => __( 'Assistenza sul tuo gestionale Odoo.', 'ticinoweb-child-theme' ),
			'subject'     => __( 'Richiesta assistenza Odoo', 'ticinoweb-child-theme' ),
			'service'     => __( 'Odoo', 'ticinoweb-child-theme' ),
		),
		'app' => array(
			'number'      => '02',
			'title'       => __( 'App iOS / Android', 'ticinoweb-child-theme' ),
			'description' => __( 'Supporto per applicazioni e servizi mobile.', 'ticinoweb-child-theme' ),
			'subject'     => __( 'Richiesta assistenza App iOS/Android', 'ticinoweb-child-theme' ),
			'service'     => __( 'App iOS/Android', 'ticinoweb-child-theme' ),
		),
		'web' => array(
			'number'      => '03',
			'title'       => __( 'Siti Web', 'ticinoweb-child-theme' ),
			'description' => __( 'Problemi, modifiche o assistenza sul tuo sito web.', 'ticinoweb-child-theme' ),
			'subject'     => __( 'Richiesta assistenza Web', 'ticinoweb-child-theme' ),
			'service'     => __( 'Web', 'ticinoweb-child-theme' ),
		),
		'marketing' => array(
			'number'      => '04',
			'title'       => __( 'Marketing', 'ticinoweb-child-theme' ),
			'description' => __( 'Supporto per campagne e servizi di marketing digitale.', 'ticinoweb-child-theme' ),
			'subject'     => __( 'Richiesta assistenza Marketing', 'ticinoweb-child-theme' ),
			'service'     => __( 'Marketing', 'ticinoweb-child-theme' ),
		),
	);
	?>
	<main class="tw-support-page">
		<section class="tw-support-remote" aria-labelledby="tw-support-remote-title">
			<div class="tw-shell tw-support-remote__inner">
				<div>
					<p class="tw-kicker"><?php esc_html_e( 'Assistenza tecnica', 'ticinoweb-child-theme' ); ?></p>
					<h1 id="tw-support-remote-title"><?php esc_html_e( 'Accesso remoto', 'ticinoweb-child-theme' ); ?></h1>
				</div>
				<div>
					<p><?php esc_html_e( 'Hai già parlato con un nostro tecnico? Utilizza il codice ricevuto per consentire l’accesso remoto al tuo computer.', 'ticinoweb-child-theme' ); ?></p>
					<form class="tw-support-session" action="https://assist.zoho.eu/join" method="get" target="_blank" rel="noopener noreferrer" data-support-session>
						<label for="tw-support-session-id"><?php esc_html_e( 'ID sessione', 'ticinoweb-child-theme' ); ?></label>
						<div class="tw-support-session__controls">
							<input id="tw-support-session-id" name="key" type="text" inputmode="numeric" autocomplete="off" spellcheck="false" required maxlength="15" pattern="[0-9]{3}[ -]?[0-9]{3}[ -]?[0-9]{3}" aria-describedby="tw-support-session-help" data-invalid-message="<?php esc_attr_e( 'Inserisci le 9 cifre del codice ricevuto dal tecnico.', 'ticinoweb-child-theme' ); ?>">
							<button class="tw-button tw-button--primary" type="submit"><?php esc_html_e( 'Collega', 'ticinoweb-child-theme' ); ?><span class="tw-arrow" aria-hidden="true"></span></button>
						</div>
						<input type="hidden" name="join_source" value="CUSTOMER_WIDGET">
						<p id="tw-support-session-help" class="tw-support-session__help"><?php esc_html_e( 'Inserisci il codice di 9 cifre ricevuto dal tecnico. Il collegamento si apre in una nuova scheda su Zoho Assist.', 'ticinoweb-child-theme' ); ?></p>
						<p class="tw-support-session__provider">
							<?php if ( $tw_zoho_logo ) : ?>
								<img class="tw-support-session__logo" src="<?php echo esc_url( $tw_zoho_logo ); ?>" alt="Zoho Assist" width="124" height="48" loading="lazy" decoding="async">
							<?php else : ?>
								<?php esc_html_e( 'Con il supporto di Zoho Assist', 'ticinoweb-child-theme' ); ?>
							<?php endif; ?>
						</p>
					</form>
					<?php if ( $tw_support_remote_href ) : ?>
						<a class="tw-text-link" href="<?php echo esc_url( $tw_support_remote_href ); ?>"><?php esc_html_e( 'Non hai il codice? Richiedilo al nostro tecnico', 'ticinoweb-child-theme' ); ?><span class="tw-arrow" aria-hidden="true"></span></a>
					<?php endif; ?>
				</div>
			</div>
		</section>

		<section class="tw-support-request" id="richiedi-assistenza" aria-labelledby="tw-support-request-title">
			<div class="tw-shell tw-support-request__inner">
				<div class="tw-support-request__intro">
					<span class="tw-support-badge" aria-hidden="true"><?php echo tw_support_icon( 'headset' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
					<p class="tw-kicker"><?php esc_html_e( 'Assistenza ticinoWEB', 'ticinoweb-child-theme' ); ?></p>
					<h2 id="tw-support-request-title"><?php esc_html_e( 'Apri un ticket di assistenza', 'ticinoweb-child-theme' ); ?></h2>
					<p class="tw-support-request__lead"><?php esc_html_e( 'Scegli il servizio e raccontaci cosa non funziona: la richiesta arriva al tecnico giusto.', 'ticinoweb-child-theme' ); ?></p>
					<ul class="tw-support-points">
						<li><span aria-hidden="true"><?php echo tw_support_icon( 'ticket' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span><div><strong><?php esc_html_e( 'Un ticket tracciato', 'ticinoweb-child-theme' ); ?></strong><?php esc_html_e( 'Ogni richiesta viene registrata e assegnata a un tecnico.', 'ticinoweb-child-theme' ); ?></div></li>
						<li><span aria-hidden="true"><?php echo tw_support_icon( 'user' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span><div><strong><?php esc_html_e( 'Il tecnico giusto', 'ticinoweb-child-theme' ); ?></strong><?php esc_html_e( 'La risposta arriva dal responsabile del servizio che scegli.', 'ticinoweb-child-theme' ); ?></div></li>
						<li><span aria-hidden="true"><?php echo tw_support_icon( 'shield' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span><div><strong><?php esc_html_e( 'Accesso remoto sicuro', 'ticinoweb-child-theme' ); ?></strong><?php esc_html_e( 'Solo con il codice che ti comunica il tecnico.', 'ticinoweb-child-theme' ); ?></div></li>
					</ul>
				</div>
				<form class="tw-about-form tw-support-form" data-tw-about-form method="post" action="<?php echo esc_url( admin_url( 'admin-ajax.php' ) ); ?>">
					<input type="hidden" name="action" value="ticinoweb_submit_form">
					<input type="hidden" name="tw_form_context" value="support">
					<fieldset class="tw-service-pick">
						<legend><?php esc_html_e( 'Per quale servizio?', 'ticinoweb-child-theme' ); ?></legend>
						<div class="tw-service-tiles">
							<?php $tw_first = true; foreach ( $tw_support_services as $tw_service_key => $tw_service ) : ?>
								<label class="tw-service-tile">
									<input type="radio" name="servizio" value="<?php echo esc_attr( $tw_service_key ); ?>"<?php echo $tw_first ? ' checked' : ''; ?>>
									<span class="tw-service-tile__body">
										<span class="tw-service-tile__icon" aria-hidden="true"><?php echo tw_support_icon( $tw_service_key ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
										<span class="tw-service-tile__name"><?php echo esc_html( $tw_service['title'] ); ?></span>
									</span>
								</label>
							<?php $tw_first = false; endforeach; ?>
						</div>
					</fieldset>
					<label><?php esc_html_e( 'Descrivi il problema', 'ticinoweb-child-theme' ); ?> *<textarea name="messaggio" required minlength="5" maxlength="4500" rows="5"></textarea></label>
					<div class="tw-about-form-row">
						<label><?php esc_html_e( 'Nome e cognome', 'ticinoweb-child-theme' ); ?> *<input name="nome" autocomplete="name" required minlength="2" maxlength="150"></label>
						<label><?php esc_html_e( 'Email', 'ticinoweb-child-theme' ); ?> *<input type="email" name="email" autocomplete="email" required maxlength="254"></label>
					</div>
					<label><?php esc_html_e( 'Telefono (facoltativo)', 'ticinoweb-child-theme' ); ?><input type="tel" name="telefono" autocomplete="tel" maxlength="80"></label>
					<div class="tw-about-hp" aria-hidden="true"><label>Website<input name="tw_hp" tabindex="-1" autocomplete="off"></label></div>
					<label class="tw-about-privacy"><input type="checkbox" name="privacy" value="1" required><span><?php esc_html_e( 'Ho letto e accetto l’informativa', 'ticinoweb-child-theme' ); ?> <a href="<?php echo esc_url( get_privacy_policy_url() ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'privacy', 'ticinoweb-child-theme' ); ?></a>. *</span></label>
					<button class="tw-button" type="submit"><?php esc_html_e( 'Invia la richiesta', 'ticinoweb-child-theme' ); ?> <span class="tw-arrow" aria-hidden="true"></span></button>
					<p id="tw-about-form-status" class="tw-about-form-status" role="status" aria-live="polite" tabindex="-1"></p>
				</form>
			</div>
		</section>

		<section class="tw-support-story" aria-labelledby="tw-support-story-title">
			<div class="tw-shell tw-support-story__inner">
				<p class="tw-kicker"><?php esc_html_e( 'Il nostro supporto', 'ticinoweb-child-theme' ); ?></p>
				<h2 id="tw-support-story-title"><?php esc_html_e( 'Ci siamo anche dopo la consegna.', 'ticinoweb-child-theme' ); ?></h2>
				<div class="tw-support-story__copy">
					<?php foreach ( $tw_support_paragraphs as $tw_support_paragraph ) : ?>
						<p><?php echo esc_html( $tw_support_paragraph ); ?></p>
					<?php endforeach; ?>
				</div>
				<p class="tw-support-promise"><?php esc_html_e( 'Puoi contare su di noi, quando c’è bisogno noi ci siamo.', 'ticinoweb-child-theme' ); ?></p>
			</div>
		</section>

		<section class="tw-support-contact" aria-labelledby="tw-support-contact-title">
			<div class="tw-shell tw-support-contact__inner">
				<div>
					<p class="tw-kicker"><?php esc_html_e( 'Contatto diretto', 'ticinoweb-child-theme' ); ?></p>
					<h2 id="tw-support-contact-title"><?php esc_html_e( 'Non sai quale assistenza scegliere?', 'ticinoweb-child-theme' ); ?></h2>
				</div>
				<div class="tw-support-contact__details">
					<p><?php esc_html_e( 'Contattaci direttamente e ti indirizzeremo alla persona giusta.', 'ticinoweb-child-theme' ); ?></p>
					<?php if ( $tw_support_phone_href && $tw_support_phone_label ) : ?><a href="tel:<?php echo esc_attr( $tw_support_phone_href ); ?>"><?php echo esc_html( $tw_support_phone_label ); ?></a><?php endif; ?>
					<?php if ( $tw_support_email ) : ?><a href="mailto:<?php echo esc_attr( antispambot( $tw_support_email ) ); ?>"><?php echo esc_html( antispambot( $tw_support_email ) ); ?></a><?php endif; ?>
					<?php if ( $tw_support_contact_href ) : ?><a class="tw-text-link" href="<?php echo esc_url( $tw_support_contact_href ); ?>"><?php esc_html_e( 'Contattaci', 'ticinoweb-child-theme' ); ?><span class="tw-arrow" aria-hidden="true"></span></a><?php endif; ?>
				</div>
			</div>
		</section>
	</main>
	<?php
endwhile;

get_footer();
