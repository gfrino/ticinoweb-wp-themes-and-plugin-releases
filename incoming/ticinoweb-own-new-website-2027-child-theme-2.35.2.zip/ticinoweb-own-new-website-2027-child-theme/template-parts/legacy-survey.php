<?php
/** Existing field labels remain authoritative CMS data. */
if (!defined('ABSPATH')) exit;
$survey_id=isset($args['post_id'])?(int)$args['post_id']:get_the_ID();
$survey_fields=tw_sitewide_survey_fields($survey_id);
if (!$survey_fields) return;
?>
<form class="tw-about-form tw-legacy-survey" data-tw-about-form method="post" action="<?php echo esc_url(admin_url('admin-ajax.php')); ?>">
	<input type="hidden" name="action" value="ticinoweb_submit_form">
	<input type="hidden" name="tw_form_context" value="legacy_survey">
	<input type="hidden" name="tw_survey_page" value="<?php echo esc_attr($survey_id); ?>">
	<?php foreach ($survey_fields as $survey_field): $survey_role=tw_sitewide_survey_role($survey_field); $survey_name=$survey_role?:'tw_survey['.$survey_field['id'].']'; $survey_required=in_array($survey_role,['nome','email'],true); ?>
	<label for="tw-survey-<?php echo esc_attr($survey_field['id']); ?>"><?php echo esc_html($survey_field['label']); ?><?php if ($survey_required) echo ' *'; ?>
		<?php if ($survey_field['type']==='textarea'): ?>
		<textarea id="tw-survey-<?php echo esc_attr($survey_field['id']); ?>" name="<?php echo esc_attr($survey_name); ?>" rows="4" maxlength="5000" data-tw-survey-question data-tw-survey-label="<?php echo esc_attr($survey_field['label']); ?>" data-tw-survey-type="textarea"></textarea>
		<?php else: ?>
		<input id="tw-survey-<?php echo esc_attr($survey_field['id']); ?>" name="<?php echo esc_attr($survey_name); ?>" type="<?php echo esc_attr($survey_role==='telefono'?'tel':$survey_field['type']); ?>" <?php if ($survey_required) echo 'required'; ?> <?php if ($survey_role==='nome') echo 'minlength="2" autocomplete="name"'; ?> <?php if ($survey_role==='email') echo 'autocomplete="email"'; ?> maxlength="<?php echo $survey_role==='email'?'254':'5000'; ?>" <?php if (!$survey_role): ?>data-tw-survey-question data-tw-survey-label="<?php echo esc_attr($survey_field['label']); ?>" data-tw-survey-type="<?php echo esc_attr($survey_field['type']); ?>"<?php endif; ?>>
		<?php endif; ?>
	</label>
	<?php endforeach; ?>
	<div class="tw-about-hp" aria-hidden="true"><label>Website<input name="tw_hp" tabindex="-1" autocomplete="off"></label></div>
	<label class="tw-about-privacy"><input type="checkbox" name="privacy" value="1" required><span><?php esc_html_e('Ho letto e accetto l’informativa','ticinoweb-child-theme'); ?> <a href="<?php echo esc_url(get_privacy_policy_url()); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e('privacy','ticinoweb-child-theme'); ?></a>. *</span></label>
	<p class="tw-survey-budget" data-tw-survey-budget aria-live="polite"></p>
	<button class="tw-button" type="submit"><?php esc_html_e('Invia la richiesta','ticinoweb-child-theme'); ?> <span class="tw-arrow" aria-hidden="true"></span></button>
	<p id="tw-survey-form-status" class="tw-about-form-status" role="status" aria-live="polite" tabindex="-1"></p>
	<noscript><p><?php esc_html_e('Per usare il modulo abilita JavaScript, oppure contattaci via telefono o email.','ticinoweb-child-theme'); ?></p></noscript>
</form>
