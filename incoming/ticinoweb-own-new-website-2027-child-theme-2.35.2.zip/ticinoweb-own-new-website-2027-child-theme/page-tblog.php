<?php
/**
 * Native article archive for the tBlog page.
 *
 * Template Name: tBlog Archive
 *
 * @package ticinoWEB_Child_Theme
 */

get_header();

$tw_blog_page_id    = get_queried_object_id();
$tw_blog_page_title = $tw_blog_page_id ? get_the_title( $tw_blog_page_id ) : '';
$tw_blog_page_intro = $tw_blog_page_id ? trim( get_the_excerpt( $tw_blog_page_id ) ) : '';
if ( ! $tw_blog_page_title ) {
	$tw_blog_page_title = __( 'tBlog', 'ticinoweb-child-theme' );
}
if ( ! $tw_blog_page_intro ) {
	$tw_blog_page_intro = __( 'Approfondimenti, casi reali e novità dal mondo del web design, dell’eCommerce e del marketing digitale.', 'ticinoweb-child-theme' );
}

$tw_blog_search   = isset( $_GET['tw_blog_search'] ) ? sanitize_text_field( wp_unslash( $_GET['tw_blog_search'] ) ) : '';
$tw_blog_category = isset( $_GET['tw_blog_category'] ) ? absint( $_GET['tw_blog_category'] ) : 0;
$tw_blog_tag      = isset( $_GET['tw_blog_tag'] ) ? absint( $_GET['tw_blog_tag'] ) : 0;
$tw_blog_year     = isset( $_GET['tw_blog_year'] ) ? absint( $_GET['tw_blog_year'] ) : 0;
$tw_blog_order    = isset( $_GET['tw_blog_order'] ) && 'oldest' === sanitize_key( wp_unslash( $_GET['tw_blog_order'] ) ) ? 'oldest' : 'newest';
$tw_blog_paged    = max( 1, absint( get_query_var( 'paged' ) ), absint( get_query_var( 'page' ) ) );

$tw_blog_query_args = array(
	'post_type'           => 'post',
	'post_status'         => 'publish',
	'posts_per_page'      => 12,
	'paged'               => $tw_blog_paged,
	's'                   => $tw_blog_search,
	'cat'                 => $tw_blog_category,
	'tag_id'              => $tw_blog_tag,
	'orderby'             => 'date',
	'order'               => 'oldest' === $tw_blog_order ? 'ASC' : 'DESC',
	'ignore_sticky_posts' => true,
);
if ( $tw_blog_year ) {
	$tw_blog_query_args['year'] = $tw_blog_year;
}

$tw_blog_query      = new WP_Query( $tw_blog_query_args );
$tw_blog_categories = get_categories( array( 'hide_empty' => true, 'orderby' => 'name' ) );
$tw_blog_tags       = get_tags( array( 'hide_empty' => true, 'orderby' => 'name', 'number' => 80 ) );
$tw_oldest_posts    = get_posts(
	array(
		'post_type'      => 'post',
		'post_status'    => 'publish',
		'posts_per_page' => 1,
		'orderby'        => 'date',
		'order'          => 'ASC',
		'fields'         => 'ids',
		'no_found_rows'  => true,
	)
);
$tw_current_year = absint( wp_date( 'Y' ) );
$tw_oldest_year  = $tw_oldest_posts ? absint( get_the_date( 'Y', $tw_oldest_posts[0] ) ) : $tw_current_year;
$tw_filter_args  = array_filter(
	array(
		'tw_blog_search'   => $tw_blog_search,
		'tw_blog_category' => $tw_blog_category,
		'tw_blog_tag'      => $tw_blog_tag,
		'tw_blog_year'     => $tw_blog_year,
		'tw_blog_order'    => 'newest' !== $tw_blog_order ? $tw_blog_order : '',
	)
);
?>
<main class="tw-blog-archive">
	<header class="tw-blog-hero">
		<div class="tw-shell">
			<p class="tw-blog-kicker"><?php esc_html_e( 'Articoli e approfondimenti', 'ticinoweb-child-theme' ); ?></p>
			<h1><?php echo esc_html( $tw_blog_page_title ); ?></h1>
			<p><?php echo esc_html( $tw_blog_page_intro ); ?></p>
		</div>
	</header>

	<div class="tw-shell tw-blog-layout">
		<aside class="tw-blog-sidebar" aria-labelledby="tw-blog-filters-title">
			<form class="tw-blog-filters" method="get" action="<?php echo esc_url( get_permalink() ); ?>">
				<h2 id="tw-blog-filters-title"><?php esc_html_e( 'Filtra gli articoli', 'ticinoweb-child-theme' ); ?></h2>
				<div class="tw-blog-field tw-blog-field--search">
				<label for="tw-blog-search"><?php esc_html_e( 'Parola chiave', 'ticinoweb-child-theme' ); ?></label>
				<input type="search" id="tw-blog-search" name="tw_blog_search" value="<?php echo esc_attr( $tw_blog_search ); ?>" placeholder="<?php esc_attr_e( 'Cerca nel tBlog', 'ticinoweb-child-theme' ); ?>">
				</div>

				<div class="tw-blog-field">
				<label for="tw-blog-category"><?php esc_html_e( 'Categoria', 'ticinoweb-child-theme' ); ?></label>
				<select id="tw-blog-category" name="tw_blog_category">
					<option value="0"><?php esc_html_e( 'Tutte le categorie', 'ticinoweb-child-theme' ); ?></option>
					<?php foreach ( $tw_blog_categories as $tw_category ) : ?>
						<option value="<?php echo esc_attr( (string) $tw_category->term_id ); ?>" <?php selected( $tw_blog_category, $tw_category->term_id ); ?>><?php echo esc_html( sprintf( '%s (%d)', $tw_category->name, $tw_category->count ) ); ?></option>
					<?php endforeach; ?>
				</select>
				</div>

				<div class="tw-blog-field">
				<label for="tw-blog-tag"><?php esc_html_e( 'Argomento', 'ticinoweb-child-theme' ); ?></label>
				<select id="tw-blog-tag" name="tw_blog_tag">
					<option value="0"><?php esc_html_e( 'Tutti gli argomenti', 'ticinoweb-child-theme' ); ?></option>
					<?php foreach ( $tw_blog_tags as $tw_tag ) : ?>
						<option value="<?php echo esc_attr( (string) $tw_tag->term_id ); ?>" <?php selected( $tw_blog_tag, $tw_tag->term_id ); ?>><?php echo esc_html( sprintf( '%s (%d)', $tw_tag->name, $tw_tag->count ) ); ?></option>
					<?php endforeach; ?>
				</select>
				</div>

				<div class="tw-blog-field">
				<label for="tw-blog-year"><?php esc_html_e( 'Anno', 'ticinoweb-child-theme' ); ?></label>
				<select id="tw-blog-year" name="tw_blog_year">
					<option value="0"><?php esc_html_e( 'Tutti gli anni', 'ticinoweb-child-theme' ); ?></option>
					<?php for ( $tw_year = $tw_current_year; $tw_year >= $tw_oldest_year; $tw_year-- ) : ?>
						<option value="<?php echo esc_attr( (string) $tw_year ); ?>" <?php selected( $tw_blog_year, $tw_year ); ?>><?php echo esc_html( (string) $tw_year ); ?></option>
					<?php endfor; ?>
				</select>
				</div>

				<div class="tw-blog-field">
				<label for="tw-blog-order"><?php esc_html_e( 'Ordine', 'ticinoweb-child-theme' ); ?></label>
				<select id="tw-blog-order" name="tw_blog_order">
					<option value="newest" <?php selected( $tw_blog_order, 'newest' ); ?>><?php esc_html_e( 'Più recenti', 'ticinoweb-child-theme' ); ?></option>
					<option value="oldest" <?php selected( $tw_blog_order, 'oldest' ); ?>><?php esc_html_e( 'Meno recenti', 'ticinoweb-child-theme' ); ?></option>
				</select>
				</div>

				<div class="tw-blog-filter-actions">
				<button type="submit"><?php esc_html_e( 'Applica filtri', 'ticinoweb-child-theme' ); ?></button>
				<a href="<?php echo esc_url( get_permalink() ); ?>"><?php esc_html_e( 'Azzera filtri', 'ticinoweb-child-theme' ); ?></a>
				</div>
			</form>
		</aside>

		<section class="tw-blog-results" aria-labelledby="tw-blog-results-title">
			<div class="tw-blog-results__head">
				<h2 id="tw-blog-results-title"><?php esc_html_e( 'Tutti gli articoli', 'ticinoweb-child-theme' ); ?></h2>
				<p><?php echo esc_html( sprintf( _n( '%d articolo', '%d articoli', $tw_blog_query->found_posts, 'ticinoweb-child-theme' ), $tw_blog_query->found_posts ) ); ?></p>
			</div>

			<?php if ( $tw_blog_query->have_posts() ) : ?>
				<div class="tw-blog-grid">
					<?php foreach ( $tw_blog_query->posts as $tw_article ) : ?>
						<?php $tw_article_categories = get_the_category( $tw_article->ID ); ?>
						<article class="tw-blog-card">
							<a class="tw-blog-card__media" href="<?php echo esc_url( get_permalink( $tw_article ) ); ?>" tabindex="-1" aria-hidden="true">
								<?php if ( has_post_thumbnail( $tw_article ) ) : ?>
									<?php echo wp_get_attachment_image( get_post_thumbnail_id( $tw_article ), 'medium_large', false, array( 'alt' => '', 'loading' => 'lazy', 'decoding' => 'async', 'sizes' => '(max-width: 900px) 100vw, (max-width: 1300px) 50vw, 33vw' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
								<?php else : ?>
									<span>tBlog</span>
								<?php endif; ?>
							</a>
							<div class="tw-blog-card__body">
								<p class="tw-blog-card__meta"><?php echo esc_html( $tw_article_categories ? $tw_article_categories[0]->name : __( 'tBlog', 'ticinoweb-child-theme' ) ); ?> · <time datetime="<?php echo esc_attr( get_the_date( 'c', $tw_article ) ); ?>"><?php echo esc_html( get_the_date( '', $tw_article ) ); ?></time></p>
								<h3><a href="<?php echo esc_url( get_permalink( $tw_article ) ); ?>"><?php echo esc_html( get_the_title( $tw_article ) ); ?></a></h3>
								<p><?php echo esc_html( wp_trim_words( get_the_excerpt( $tw_article ), 24 ) ); ?></p>
								<a class="tw-blog-card__link" href="<?php echo esc_url( get_permalink( $tw_article ) ); ?>"><?php esc_html_e( 'Leggi l’articolo', 'ticinoweb-child-theme' ); ?><span class="tw-arrow" aria-hidden="true"></span></a>
							</div>
						</article>
					<?php endforeach; ?>
				</div>

				<?php
				$tw_pagination = paginate_links(
					array(
						'total'     => $tw_blog_query->max_num_pages,
						'current'   => $tw_blog_paged,
						'type'      => 'list',
						'prev_text' => __( 'Precedenti', 'ticinoweb-child-theme' ),
						'next_text' => __( 'Successivi', 'ticinoweb-child-theme' ),
						'add_args'  => $tw_filter_args,
					)
				);
				if ( $tw_pagination ) {
					echo '<nav class="tw-blog-pagination" aria-label="' . esc_attr__( 'Paginazione articoli', 'ticinoweb-child-theme' ) . '">' . wp_kses_post( $tw_pagination ) . '</nav>';
				}
				?>
			<?php else : ?>
				<div class="tw-blog-empty"><h3><?php esc_html_e( 'Nessun articolo trovato.', 'ticinoweb-child-theme' ); ?></h3><p><?php esc_html_e( 'Prova a modificare o azzerare i filtri.', 'ticinoweb-child-theme' ); ?></p></div>
			<?php endif; ?>
			<?php wp_reset_postdata(); ?>
		</section>
	</div>
</main>
<?php get_footer(); ?>
