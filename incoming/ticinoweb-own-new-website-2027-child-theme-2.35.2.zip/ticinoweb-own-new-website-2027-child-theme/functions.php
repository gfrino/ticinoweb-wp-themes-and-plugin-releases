<?php
/**
 * Bootstrap essenziale del ticinoWEB Child Theme.
 *
 * @package ticinoWEB_Child_Theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once get_stylesheet_directory() . '/inc/content.php';
require_once get_stylesheet_directory() . '/inc/project-sectors.php';
require_once get_stylesheet_directory() . '/inc/editorial-cursor.php';
require_once get_stylesheet_directory() . '/inc/project-archive.php';
require_once get_stylesheet_directory() . '/inc/web-services.php';
require_once get_stylesheet_directory() . '/inc/service-system.php';
require_once get_stylesheet_directory() . '/inc/about-contact.php';
require_once get_stylesheet_directory() . '/inc/contact-page.php';
require_once get_stylesheet_directory() . '/inc/recruiting.php';
require_once get_stylesheet_directory() . '/inc/agency-menu.php';
require_once get_stylesheet_directory() . '/inc/navigation.php';
require_once get_stylesheet_directory() . '/inc/editorial.php';
require_once get_stylesheet_directory() . '/inc/hero-dynamic-title.php';
require_once get_stylesheet_directory() . '/inc/site-metrics.php';
require_once get_stylesheet_directory() . '/inc/single-article.php';
require_once get_stylesheet_directory() . '/inc/support-page.php';
require_once get_stylesheet_directory() . '/inc/odoo-integration.php';
require_once get_stylesheet_directory() . '/inc/odoo-site-stats.php';
require_once get_stylesheet_directory() . '/inc/sustainability.php';
require_once get_stylesheet_directory() . '/inc/food-delivery.php';
require_once get_stylesheet_directory() . '/inc/service-extras.php';
require_once get_stylesheet_directory() . '/inc/social-links.php';
require_once get_stylesheet_directory() . '/inc/sitewide.php';
require_once get_stylesheet_directory() . '/inc/commerce-presentation.php';
require_once get_stylesheet_directory() . '/inc/public-archives.php';
require_once get_stylesheet_directory() . '/inc/legacy-survey.php';
require_once get_stylesheet_directory() . '/inc/odoo-icons.php';
require_once get_stylesheet_directory() . '/inc/odoo-suite.php';
require_once get_stylesheet_directory() . '/inc/odoo-suite-admin.php';
require_once get_stylesheet_directory() . '/inc/bni-ranking.php';
require_once get_stylesheet_directory() . '/inc/software-store.php';

/**
 * Ensures the mapped Support page uses the child-theme service-desk layout.
 */
function ticinoweb_child_support_template( $template ) {
	if ( ! tw_support_is_page() ) {
		return $template;
	}
	$support_template = get_stylesheet_directory() . '/page-supporto.php';
	return file_exists( $support_template ) ? $support_template : $template;
}
add_filter( 'template_include', 'ticinoweb_child_support_template', 99 );

/**
 * Configura le capacità native del child theme.
 */
function ticinoweb_child_setup() {
	load_child_theme_textdomain( 'ticinoweb-child-theme', get_stylesheet_directory() . '/languages' );
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'responsive-embeds' );
	register_nav_menus(
		array(
			'footer-company'    => __( 'Footer — Azienda e sedi', 'ticinoweb-child-theme' ),
			'footer-services'   => __( 'Footer — Servizi', 'ticinoweb-child-theme' ),
			'footer-commitment' => __( 'Footer — Impegno sociale', 'ticinoweb-child-theme' ),
			'footer-actions'    => __( 'Footer — Azioni', 'ticinoweb-child-theme' ),
			'footer-legal'      => __( 'Footer — Informazioni legali', 'ticinoweb-child-theme' ),
		)
	);
}
add_action( 'after_setup_theme', 'ticinoweb_child_setup', 20 );

/**
 * Carica una sola volta gli stili del parent e del child.
 *
 * Il parent usa get_stylesheet_uri(), che con un child attivo punta al CSS
 * del child. La registrazione viene quindi corretta esplicitamente qui.
 */
function ticinoweb_child_enqueue_styles() {
	$parent_theme = wp_get_theme( get_template() );
	$child_theme  = wp_get_theme();

	wp_dequeue_style( 'poppins-font' );
	wp_deregister_style( 'poppins-font' );
	wp_dequeue_style( 'ticinoweb-ai-style' );
	wp_deregister_style( 'ticinoweb-ai-style' );

	wp_enqueue_style(
		'ticinoweb-ai-style',
		get_template_directory_uri() . '/style.css',
		array(),
		$parent_theme->get( 'Version' )
	);

	wp_enqueue_style(
		'ticinoweb-child-style',
		get_stylesheet_uri(),
		array( 'ticinoweb-ai-style' ),
		$child_theme->get( 'Version' )
	);

	wp_enqueue_style(
		'ticinoweb-child-site',
		get_stylesheet_directory_uri() . '/assets/css/site.css',
		array( 'ticinoweb-child-style' ),
		$child_theme->get( 'Version' )
	);

	wp_enqueue_script(
		'ticinoweb-child-site',
		get_stylesheet_directory_uri() . '/assets/js/site.js',
		array(),
		$child_theme->get( 'Version' ),
		true
	);
	wp_script_add_data( 'ticinoweb-child-site', 'strategy', 'defer' );

	if ( is_front_page() ) {
		wp_enqueue_style(
			'ticinoweb-child-home',
			get_stylesheet_directory_uri() . '/assets/css/home.css',
			array( 'ticinoweb-child-site' ),
			$child_theme->get( 'Version' )
		);
		wp_enqueue_style(
			'ticinoweb-child-project-explorer',
			get_stylesheet_directory_uri() . '/assets/css/project-explorer.css',
			array( 'ticinoweb-child-home' ),
			$child_theme->get( 'Version' )
		);
		wp_enqueue_script(
			'ticinoweb-child-home',
			get_stylesheet_directory_uri() . '/assets/js/home.js',
			array(),
			$child_theme->get( 'Version' ),
			true
		);
		wp_script_add_data( 'ticinoweb-child-home', 'strategy', 'defer' );
		wp_enqueue_script(
			'ticinoweb-child-project-explorer',
			get_stylesheet_directory_uri() . '/assets/js/project-explorer.js',
			array(),
			$child_theme->get( 'Version' ),
			true
		);
		wp_script_add_data( 'ticinoweb-child-project-explorer', 'strategy', 'defer' );
	}

	if ( is_page_template( 'page-tblog.php' ) || is_page( 'tblog' ) ) {
		wp_enqueue_style(
			'ticinoweb-child-blog',
			get_stylesheet_directory_uri() . '/assets/css/blog.css',
			array( 'ticinoweb-child-site' ),
			$child_theme->get( 'Version' )
		);
	}

	if ( is_singular( 'post' ) ) {
		wp_enqueue_style(
			'ticinoweb-child-single',
			get_stylesheet_directory_uri() . '/assets/css/single.css',
			array( 'ticinoweb-child-site' ),
			$child_theme->get( 'Version' )
		);
		wp_enqueue_script( 'ticinoweb-child-single', get_stylesheet_directory_uri() . '/assets/js/single.js', array(), $child_theme->get( 'Version' ), true );
		wp_script_add_data( 'ticinoweb-child-single', 'strategy', 'defer' );
	}

	if ( is_page_template( 'page-sostenibilita.php' ) ) {
		wp_enqueue_style(
			'ticinoweb-child-sustainability',
			get_stylesheet_directory_uri() . '/assets/css/sustainability.css',
			array( 'ticinoweb-child-site' ),
			$child_theme->get( 'Version' )
		);
	}

	if ( tw_support_is_page() ) {
		wp_enqueue_script( 'ticinoweb-child-support', get_stylesheet_directory_uri() . '/assets/js/support.js', array(), $child_theme->get( 'Version' ), true );
		wp_script_add_data( 'ticinoweb-child-support', 'strategy', 'defer' );
		wp_enqueue_script( 'tw-about', get_stylesheet_directory_uri() . '/assets/js/about-contact.js', array(), $child_theme->get( 'Version' ), true );
		wp_localize_script( 'tw-about', 'twAboutForm', array(
			'ajax_url' => admin_url( 'admin-ajax.php' ), 'token_action' => 'ticinoweb_form_token', 'submit_action' => 'ticinoweb_submit_form',
			'recaptcha_site_key' => (string) get_option( 'ticinoweb_recaptcha_site_key', '' ),
			'busy'    => __( 'Invio in corso…', 'ticinoweb-child-theme' ),
			'failure' => __( 'Invio non riuscito. Riprova oppure contattaci via email.', 'ticinoweb-child-theme' ),
			'privacy' => __( 'Accetta l’informativa privacy per inviare la richiesta.', 'ticinoweb-child-theme' ),
			'saved'   => __( 'Richiesta registrata. Se non ricevi una risposta, contattaci direttamente.', 'ticinoweb-child-theme' ),
		) );
		wp_enqueue_style(
			'ticinoweb-child-support',
			get_stylesheet_directory_uri() . '/assets/css/support.css',
			array( 'ticinoweb-child-site' ),
			$child_theme->get( 'Version' )
		);
	}

	if ( tw_projects_is_archive() ) {
		wp_enqueue_style(
			'ticinoweb-child-project-archive',
			get_stylesheet_directory_uri() . '/assets/css/project-archive.css',
			array( 'ticinoweb-child-site' ),
			$child_theme->get( 'Version' )
		);
		wp_enqueue_script(
			'ticinoweb-child-project-archive',
			get_stylesheet_directory_uri() . '/assets/js/project-archive.js',
			array(),
			$child_theme->get( 'Version' ),
			true
		);
		wp_script_add_data( 'ticinoweb-child-project-archive', 'strategy', 'defer' );
	}

	if ( tw_web_services_is_page() ) {
		wp_enqueue_style(
			'ticinoweb-child-web-services',
			get_stylesheet_directory_uri() . '/assets/css/web-services.css',
			array( 'ticinoweb-child-site' ),
			$child_theme->get( 'Version' )
		);
		wp_enqueue_script(
			'ticinoweb-child-web-services',
			get_stylesheet_directory_uri() . '/assets/js/web-services.js',
			array(),
			$child_theme->get( 'Version' ),
			true
		);
		wp_script_add_data( 'ticinoweb-child-web-services', 'strategy', 'defer' );
	}
}
add_action( 'wp_enqueue_scripts', 'ticinoweb_child_enqueue_styles', 20 );

/**
 * Precarica il visual LCP configurato nella prima slide del CMS.
 */
function ticinoweb_child_preload_home_hero() {
	if ( ! is_front_page() ) {
		return;
	}
	$slides = tw_home_get_slides();
	$hero   = $slides[0] ?? array();
	if ( empty( $hero['image'] ) ) {
		return;
	}
	if ( 'video' === ( $hero['media_type'] ?? 'image' ) ) {
		printf(
			'<link rel="preload" as="video" href="%1$s"%2$s>' . "\n",
			esc_url( $hero['image'] ),
			! empty( $hero['mime_type'] ) ? ' type="' . esc_attr( $hero['mime_type'] ) . '"' : ''
		);
		return;
	}
	$srcset = ! empty( $hero['image_id'] ) ? wp_get_attachment_image_srcset( $hero['image_id'], 'full' ) : '';
	printf(
		'<link rel="preload" as="image" href="%1$s"%2$s imagesizes="100vw" fetchpriority="high">' . "\n",
		esc_url( $hero['image'] ),
		$srcset ? ' imagesrcset="' . esc_attr( $srcset ) . '"' : ''
	);
}
add_action( 'wp_head', 'ticinoweb_child_preload_home_hero', 2 );
