( function () {
	'use strict';
	var KEY = 'span.tw-cart-badge';

	function paint( html ) {
		var holder = document.createElement( 'div' );
		holder.innerHTML = html;
		var fresh = holder.firstElementChild;
		if ( ! fresh ) { return; }
		document.querySelectorAll( '.tw-cart-badge' ).forEach( function ( el ) { el.replaceWith( fresh.cloneNode( true ) ); } );
	}

	function refresh() {
		if ( ! window.twCartBadge || ! window.fetch ) { return; }
		fetch( window.twCartBadge.url, { credentials: 'same-origin' } )
			.then( function ( r ) { return r.json(); } )
			.then( function ( data ) { if ( data && data.fragments && data.fragments[ KEY ] ) { paint( data.fragments[ KEY ] ); } } )
			.catch( function () {} );
	}

	// Pagine in cache: se il cookie dice che il carrello non è vuoto, rileggo il numero vero.
	if ( /(?:^|; )woocommerce_items_in_cart=/.test( document.cookie ) || document.querySelector( '.tw-cart-badge:not([hidden])' ) ) { refresh(); }

	// Aggiunta al carrello senza ricaricare la pagina (pulsanti AJAX di WooCommerce).
	if ( window.jQuery ) {
		window.jQuery( document.body ).on( 'added_to_cart removed_from_cart updated_cart_totals', function ( e, fragments ) {
			if ( fragments && fragments[ KEY ] ) { paint( fragments[ KEY ] ); } else { refresh(); }
		} );
	}
}() );
