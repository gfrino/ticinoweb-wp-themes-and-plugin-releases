<?php
/**
 * Chez Halima: configuratore di pasticcini sopra il parent ticinoWEB CMS.
 * Contatti, SEO, cookie, form e FAQ restano nel parent (ticinoweb_contact_*, tW SEO, ...).
 */
defined('ABSPATH') || exit;

/**
 * Il parent stampa già lo style.css del child (get_stylesheet_uri). Qui si aggiunge lo
 * style.css del parent come dipendenza, così le regole comuni arrivano prima.
 */
add_action('wp_enqueue_scripts', function () {
    $version = wp_get_theme()->get('Version');
    wp_enqueue_style('chezhalima-parent', get_template_directory_uri() . '/style.css', array(), wp_get_theme(get_template())->get('Version'));
    if (isset(wp_styles()->registered['ticinoweb-ai-style'])) {
        wp_styles()->registered['ticinoweb-ai-style']->deps[] = 'chezhalima-parent';
        // Il parent versiona il CSS con la sua versione: il child usa la propria, così ogni rilascio svuota la cache del browser.
        wp_styles()->registered['ticinoweb-ai-style']->ver = $version;
    }
    // Il sito usa Lato, incluso nel tema (assets/fonts): il Poppins del parent non serve e non si scarica da Google.
    // La voce resta registrata senza file perché lo stile del parent ne dipende.
    if (isset(wp_styles()->registered['poppins-font'])) {
        wp_styles()->registered['poppins-font']->src = false;
    }
    wp_enqueue_script('chezhalima-menu', get_stylesheet_directory_uri() . '/assets/js/menu.js', array(), $version, array('in_footer' => true, 'strategy' => 'defer'));
    if (is_page_template('template-pastry-shop.php')) {
        wp_enqueue_script('chezhalima-configurator', get_stylesheet_directory_uri() . '/assets/js/configuratore.js', array('jquery'), $version, true);
        wp_localize_script('chezhalima-configurator', 'chezHalima', array(
            'ajaxUrl'  => admin_url('admin-ajax.php'),
            'cartUrl'  => function_exists('wc_get_cart_url') ? wc_get_cart_url() : home_url('/'),
            'messages' => array(
                'pick'    => __('Seleziona prodotto e dimensione', 'chez-halima-child-theme'),
                'added'   => __('Prodotto aggiunto al carrello!', 'chez-halima-child-theme'),
                'error'   => __('Errore durante l\'aggiunta al carrello', 'chez-halima-child-theme'),
                'network' => __('Errore di connessione', 'chez-halima-child-theme'),
            ),
        ));
    }
}, 20);

add_action('after_setup_theme', function () {
    load_child_theme_textdomain('chez-halima-child-theme', get_stylesheet_directory() . '/languages');
    // L'estratto della pagina è il testo sotto il titolo dell'hero.
    add_post_type_support('page', 'excerpt');
    // Link della barra in alto, ripetuti nella colonna «Regole» del footer (come su chezhalima.ch).
    register_nav_menus(array('chezhalima_topbar' => __('Barra in alto e footer «Regole»', 'chez-halima-child-theme')));
});

/** Testo a sinistra nella barra in alto: Aspetto → Personalizza → Chez Halima. */
add_action('customize_register', function ($wp_customize) {
    $wp_customize->add_section('chezhalima', array('title' => __('Chez Halima', 'chez-halima-child-theme'), 'priority' => 30));
    $wp_customize->add_setting('chezhalima_topbar_text', array('default' => '', 'sanitize_callback' => 'sanitize_text_field', 'transport' => 'refresh'));
    $wp_customize->add_control('chezhalima_topbar_text', array(
        'label'   => __('Testo della barra in alto', 'chez-halima-child-theme'),
        'section' => 'chezhalima',
        'type'    => 'text',
    ));
});

/** Barra verde sopra l'header: testo a sinistra, link del menu «Barra in alto» a destra. */
add_action('wp_body_open', function () {
    $text = trim((string) get_theme_mod('chezhalima_topbar_text', ''));
    $links = has_nav_menu('chezhalima_topbar') ? wp_nav_menu(array(
        'theme_location' => 'chezhalima_topbar',
        'container'      => false,
        'menu_class'     => 'ch-topbar__links',
        'depth'          => 1,
        'echo'           => false,
        'fallback_cb'    => false,
    )) : '';
    ob_start();
    do_action('chezhalima_topbar_after_links');
    $after = ob_get_clean();
    if ($text === '' && !$links && $after === '') {
        return;
    }
    echo '<div class="ch-topbar"><div class="ch-wrap ch-topbar__inner">';
    if ($text !== '') {
        echo '<p class="ch-topbar__text">' . esc_html($text) . '</p>';
    }
    echo '<nav class="ch-topbar__nav" aria-label="' . esc_attr__('Link utili', 'chez-halima-child-theme') . '">' . $links . $after . '</nav>';
    echo '</div></div>';
});

/**
 * Testi che non finiscono come testo visibile nella pagina (attributi data-*, messaggi degli script):
 * passano dal livello di traduzione del parent, così tW Translate li traduce come gli altri.
 */
function chezhalima_t($text, $key)
{
    return function_exists('ticinoweb_frontend_text') ? ticinoweb_frontend_text($text, 'chezhalima:' . $key) : $text;
}

/** Pulsante del menu da telefono e tablet: il parent non ne ha uno (comportamento in assets/js/menu.js). */
add_action('ticinoweb_after_primary_navigation', function () {
    printf(
        '<button class="ch-menu-toggle" type="button" aria-expanded="false" data-label-open="%1$s" data-label-close="%2$s"><span class="ch-menu-toggle__icon" aria-hidden="true"></span><span class="ch-menu-toggle__label">%1$s</span></button>',
        esc_attr(chezhalima_t(__('Apri il menu', 'chez-halima-child-theme'), 'menu:open')),
        esc_attr(chezhalima_t(__('Chiudi il menu', 'chez-halima-child-theme'), 'menu:close'))
    );
});

/**
 * Le pagine fatte a sezioni (classi ch-*) sono HTML già pronto: niente paragrafi automatici di
 * WordPress, che metterebbero <p> vuoti tra foto e testo e romperebbero le griglie.
 */
add_filter('the_content', function ($content) {
    if (is_singular('page') && strpos($content, 'class="ch-') !== false) {
        remove_filter('the_content', 'wpautop');
    }
    return $content;
}, 9);

/**
 * Mappa Google che si carica solo al clic: fino ad allora nessuna richiesta a Google e nessun cookie di terzi.
 * [chezhalima_map indirizzo="Corso Elvezia 5, 6900 Lugano" titolo="Ricigliano pasticceria SA"]
 * Senza indirizzo usa quello dei contatti del CMS. Con «sede="si"» sopra la mappa compare il riquadro della sede.
 */
add_shortcode('chezhalima_map', function ($atts) {
    $atts = shortcode_atts(array('indirizzo' => '', 'titolo' => '', 'sede' => ''), $atts, 'chezhalima_map');
    $c = ticinoweb_get_contact_info();
    $address = trim((string) $atts['indirizzo']) !== '' ? trim((string) $atts['indirizzo']) : trim((string) ($c['address'] ?? ''));
    if ($address === '') {
        return '';
    }
    $title = trim((string) $atts['titolo']) !== '' ? trim((string) $atts['titolo']) : get_bloginfo('name');
    $query = rawurlencode($title . ', ' . $address);
    $embed = 'https://maps.google.com/maps?q=' . $query . '&z=16&ie=UTF8&iwloc=&output=embed';
    $directions = !empty($c['map_url']) && $atts['indirizzo'] === '' ? $c['map_url'] : 'https://www.google.com/maps/search/?api=1&query=' . $query;

    wp_enqueue_script('chezhalima-map', get_stylesheet_directory_uri() . '/assets/js/map.js', array(), wp_get_theme()->get('Version'), array('in_footer' => true, 'strategy' => 'defer'));

    $html = '<div class="ch-map" data-src="' . esc_url($embed) . '" data-title="' . esc_attr(sprintf(chezhalima_t(__('Mappa: %s', 'chez-halima-child-theme'), 'map:title'), $title)) . '">'
        . '<div class="ch-map__consent"><p>' . esc_html__('La mappa è di Google Maps: si carica solo se la chiedi, e Google riceve allora il tuo indirizzo IP e può usare i suoi cookie.', 'chez-halima-child-theme') . '</p>'
        . '<button type="button" class="ch-btn ch-map__load">' . esc_html__('Mostra la mappa', 'chez-halima-child-theme') . '</button></div>';
    if (in_array(strtolower((string) $atts['sede']), array('si', 'sì', '1'), true)) {
        /* translators: %s: nome del sito */
        $html .= '<div class="ch-map__place"><h2>' . esc_html(sprintf(__('Sede %s', 'chez-halima-child-theme'), $title)) . '</h2><p>' . esc_html($address) . '</p>'
            . '<a class="ch-btn" href="' . esc_url($directions) . '" target="_blank" rel="noopener">' . esc_html__('Indicazioni', 'chez-halima-child-theme') . '</a></div>';
    }
    return $html . '</div>';
});

/** Riquadro con giorno e mese della news, come su chezhalima.ch. */
function chezhalima_date_badge($post = null)
{
    return sprintf(
        '<time class="ch-badge" datetime="%1$s"><span class="ch-badge__day">%2$s</span><span class="ch-badge__month">%3$s</span></time>',
        esc_attr(get_the_date('c', $post)),
        esc_html(get_the_date('d', $post)),
        esc_html(get_the_date('M', $post))
    );
}

/** Ultime news con il riquadro della data: colonna del footer e barra laterale delle news. */
function chezhalima_recent_posts($count = 3)
{
    $posts = get_posts(array('numberposts' => $count, 'post_status' => 'publish', 'suppress_filters' => false));
    if (!$posts) {
        return '';
    }
    $html = '<ul class="ch-recent">';
    foreach ($posts as $post) {
        $html .= '<li>' . chezhalima_date_badge($post) . '<a href="' . esc_url(get_permalink($post)) . '">' . esc_html(get_the_title($post)) . '</a></li>';
    }
    return $html . '</ul>';
}

/**
 * Riquadri «Parla con noi» e «Contattaci» della pagina Contatti, dai contatti del CMS.
 * Il riquadro del telefono compare solo se il numero è inserito.
 */
add_shortcode('chezhalima_contact_cards', function () {
    $c = ticinoweb_get_contact_info();
    $cards = array();
    if (!empty($c['phone'])) {
        $cards[] = array(
            'icon'  => '<path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.8 19.8 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.18 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.72c.13.96.36 1.9.7 2.81a2 2 0 0 1-.45 2.11L8.1 9.9a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.9.34 1.85.57 2.81.7A2 2 0 0 1 22 16.92z"/>',
            'title' => __('Parla con noi', 'chez-halima-child-theme'),
            'text'  => __('Scegli questa opzione se vuoi entrare in contatto telefonico.', 'chez-halima-child-theme'),
            'url'   => 'tel:' . preg_replace('/[^\d+]/', '', $c['phone']),
            'label' => __('Telefono', 'chez-halima-child-theme'),
        );
    }
    if (!empty($c['email'])) {
        $cards[] = array(
            'icon'  => '<path d="M21 11.5a8.4 8.4 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.4 8.4 0 0 1-3.8-.9L3 21l1.9-5.7a8.4 8.4 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.4 8.4 0 0 1 3.8-.9h.5a8.5 8.5 0 0 1 8 8v.5z"/>',
            'title' => __('Contattaci', 'chez-halima-child-theme'),
            'text'  => __('Entra in contatto via mail, cercheremo di risponderti nel più breve tempo possibile.', 'chez-halima-child-theme'),
            'url'   => 'mailto:' . $c['email'],
            'label' => __('Contatto email', 'chez-halima-child-theme'),
        );
    }
    if (!$cards) {
        return '';
    }
    $html = '<div class="ch-cards">';
    foreach ($cards as $card) {
        $html .= '<div class="ch-card"><svg class="ch-card__icon" viewBox="0 0 24 24" aria-hidden="true" fill="currentColor">' . $card['icon'] . '</svg>'
            . '<h2>' . esc_html($card['title']) . '</h2><p>' . esc_html($card['text']) . '</p>'
            . '<a class="ch-btn" href="' . esc_url($card['url']) . '">' . esc_html($card['label']) . '</a></div>';
    }
    return $html . '</div>';
});

/** Dati di contatto dal CMS del parent (ticinoweb_contact_*): un solo posto dove si modificano. */
add_shortcode('chezhalima_contact_details', function () {
    $c = ticinoweb_get_contact_info();
    $rows = array();
    if (!empty($c['phone'])) {
        $rows[] = array(__('Telefono', 'chez-halima-child-theme'), '<a href="tel:' . esc_attr(preg_replace('/[^\d+]/', '', $c['phone'])) . '">' . esc_html($c['phone']) . '</a>');
    }
    if (!empty($c['email'])) {
        $rows[] = array(__('Email', 'chez-halima-child-theme'), '<a href="mailto:' . esc_attr($c['email']) . '">' . esc_html($c['email']) . '</a>');
    }
    if (!empty($c['address'])) {
        $address = esc_html($c['address']);
        if (!empty($c['map_url'])) {
            $address .= ' <a href="' . esc_url($c['map_url']) . '" target="_blank" rel="noopener">' . esc_html__('Indicazioni', 'chez-halima-child-theme') . '</a>';
        }
        $rows[] = array(__('Sede', 'chez-halima-child-theme'), $address);
    }
    if (!$rows) {
        return '';
    }
    $html = '<dl class="ch-details">';
    foreach ($rows as $row) {
        $html .= '<dt>' . esc_html($row[0]) . '</dt><dd>' . wp_kses_post($row[1]) . '</dd>';
    }
    return $html . '</dl>';
});

/** Modulo di contatto: usa l'invio del parent (Invii Ricevuti, e-mail del CMS, reCAPTCHA se configurato). */
add_shortcode('chezhalima_contact_form', function () {
    $privacy = function_exists('get_privacy_policy_url') ? get_privacy_policy_url() : '';
    ob_start();
    ?>
    <form class="ch-form" method="post" novalidate>
        <p><label for="ch-nome"><?php esc_html_e('Il tuo nome', 'chez-halima-child-theme'); ?></label>
            <input id="ch-nome" name="nome" type="text" autocomplete="name" required></p>
        <p><label for="ch-email"><?php esc_html_e('La tua email', 'chez-halima-child-theme'); ?></label>
            <input id="ch-email" name="email" type="email" autocomplete="email" required></p>
        <p><label for="ch-messaggio"><?php esc_html_e('Il tuo messaggio', 'chez-halima-child-theme'); ?></label>
            <textarea id="ch-messaggio" name="messaggio" rows="5" required></textarea></p>
        <p class="ch-hp" aria-hidden="true"><label>Sito web <input name="tw_hp" type="text" tabindex="-1" autocomplete="off"></label></p>
        <p class="ch-form-note">
            <?php
            echo $privacy
                ? wp_kses_post(sprintf(
                    /* translators: %s: link alla privacy policy */
                    __('Inviando accetti la nostra %s.', 'chez-halima-child-theme'),
                    '<a href="' . esc_url($privacy) . '">' . esc_html__('privacy policy', 'chez-halima-child-theme') . '</a>'
                ))
                : esc_html__('Il messaggio arriva via email a Chez Halima.', 'chez-halima-child-theme');
            ?>
        </p>
        <p><button type="submit" class="ch-btn"><?php esc_html_e('Invia', 'chez-halima-child-theme'); ?></button></p>
        <p class="ch-form-status" role="status" aria-live="polite"></p>
    </form>
    <?php
    chezhalima_form_assets();
    return ob_get_clean();
});

/** Script dei moduli (contatti e newsletter): invio del parent, reCAPTCHA se configurato nel CMS. */
function chezhalima_form_assets()
{
    if (wp_script_is('chezhalima-form', 'enqueued')) {
        return;
    }
    wp_enqueue_script('chezhalima-form', get_stylesheet_directory_uri() . '/assets/js/contact-form.js', array(), wp_get_theme()->get('Version'), true);
    $key = (string) get_option('ticinoweb_recaptcha_site_key', '');
    wp_localize_script('chezhalima-form', 'chezHalimaForm', array(
        'ajaxUrl'      => admin_url('admin-ajax.php'),
        'tokenAction'  => 'ticinoweb_form_token',
        'submitAction' => 'ticinoweb_submit_form',
        'recaptchaKey' => $key,
        'ok'           => chezhalima_t(__('Grazie, messaggio ricevuto.', 'chez-halima-child-theme'), 'form:ok'),
        'error'        => chezhalima_t(__('Invio non riuscito, riprova o scrivici via email.', 'chez-halima-child-theme'), 'form:error'),
    ));
    if ($key) {
        wp_enqueue_script('google-recaptcha', 'https://www.google.com/recaptcha/api.js?render=' . rawurlencode($key), array(), null, true);
    }
}

require_once get_stylesheet_directory() . '/inc/header.php';

/**
 * Catalogo del configuratore: prodotti, dimensioni e prezzi.
 * Unica fonte: il template li mostra, il carrello li ricalcola da qui (il prezzo non arriva mai dal browser).
 * Si adatta con il filtro `chezhalima_catalog`.
 */
function chezhalima_catalog()
{
    $standard = array('piccola' => 27, 'media' => 41, 'grande' => 54, 'luxury' => 145);
    $catalog = array(
        'sizes' => array(
            'piccola' => array('name' => __('Piccola', 'chez-halima-child-theme'), 'quantity' => __('6 Pasticcini', 'chez-halima-child-theme'), 'icon' => '📦'),
            'media'   => array('name' => __('Media', 'chez-halima-child-theme'), 'quantity' => __('9 Pasticcini', 'chez-halima-child-theme'), 'icon' => '📦📦'),
            'grande'  => array('name' => __('Grande', 'chez-halima-child-theme'), 'quantity' => __('12 Pasticcini', 'chez-halima-child-theme'), 'icon' => '📦📦📦'),
            'luxury'  => array('name' => __('Luxury', 'chez-halima-child-theme'), 'quantity' => __('1 Kg', 'chez-halima-child-theme'), 'icon' => '⚖️', 'badge' => __('Premium', 'chez-halima-child-theme')),
        ),
        'products' => array(
            'scatola-mista' => array('name' => __('Scatola Mista', 'chez-halima-child-theme'), 'cart_name' => __('Scatola Mista (6 Gusti)', 'chez-halima-child-theme'), 'desc' => __('6 Gusti Assortiti', 'chez-halima-child-theme'), 'emoji' => '🎁', 'prices' => $standard),
            'nocciola'      => array('name' => __('Singola Nocciola', 'chez-halima-child-theme'), 'desc' => __('Gusto Classico', 'chez-halima-child-theme'), 'icon' => 'Hazelnut', 'prices' => $standard),
            'anacardo'      => array('name' => __('Singola Anacardo', 'chez-halima-child-theme'), 'desc' => __('Delicato e Raffinato', 'chez-halima-child-theme'), 'icon' => 'Cashew', 'prices' => $standard),
            'lotus'         => array('name' => __('Singola Lotus', 'chez-halima-child-theme'), 'desc' => __('Gusto Speziato', 'chez-halima-child-theme'), 'icon' => 'Poppy-seeds', 'prices' => $standard),
            'cocco'         => array('name' => __('Singola Cocco', 'chez-halima-child-theme'), 'desc' => __('Tropicale e Dolce', 'chez-halima-child-theme'), 'icon' => 'Coffee-bean', 'prices' => $standard),
            'mandorla'      => array('name' => __('Singola Mandorla', 'chez-halima-child-theme'), 'desc' => __('Tradizionale', 'chez-halima-child-theme'), 'icon' => 'Almonds', 'prices' => $standard),
            'pistacchio'    => array('name' => __('Singola Pistacchio', 'chez-halima-child-theme'), 'desc' => __('Premium Selection', 'chez-halima-child-theme'), 'icon' => 'Pistachio', 'prices' => array('piccola' => 29, 'media' => 44, 'grande' => 58, 'luxury' => 155)),
        ),
    );
    return apply_filters('chezhalima_catalog', $catalog);
}

/**
 * Aggiunta al carrello. Nessun nonce: l'azione è pubblica come l'add-to-cart di WooCommerce,
 * la pagina può stare in cache (LiteSpeed) e il prezzo è ricalcolato qui, non letto dal browser.
 */
add_action('wp_ajax_chezhalima_add_to_cart', 'chezhalima_add_to_cart');
add_action('wp_ajax_nopriv_chezhalima_add_to_cart', 'chezhalima_add_to_cart');
function chezhalima_add_to_cart()
{
    if (!class_exists('WooCommerce') || !function_exists('WC') || !WC()->cart) {
        wp_send_json_error(__('WooCommerce non è attivo', 'chez-halima-child-theme'));
    }

    $catalog  = chezhalima_catalog();
    $product  = isset($_POST['product']) ? sanitize_key(wp_unslash($_POST['product'])) : '';
    $size     = isset($_POST['size']) ? sanitize_key(wp_unslash($_POST['size'])) : '';
    $quantity = isset($_POST['quantity']) ? max(1, min(99, absint($_POST['quantity']))) : 1;

    if (!isset($catalog['products'][$product], $catalog['sizes'][$size], $catalog['products'][$product]['prices'][$size])) {
        wp_send_json_error(__('Prodotto non valido', 'chez-halima-child-theme'));
    }

    $item      = $catalog['products'][$product];
    $base_id   = chezhalima_base_product_id();
    if (!$base_id) {
        wp_send_json_error(__('Errore nella creazione del prodotto', 'chez-halima-child-theme'));
    }

    $key = WC()->cart->add_to_cart($base_id, $quantity, 0, array(), array(
        'pastry_type'         => $product,
        'pastry_name'         => isset($item['cart_name']) ? $item['cart_name'] : $item['name'],
        'pastry_size'         => $size,
        'pastry_size_name'    => $catalog['sizes'][$size]['name'],
        'pastry_custom_price' => (float) $item['prices'][$size],
        'unique_key'          => md5($product . $size . microtime()),
    ));

    if (!$key) {
        wp_send_json_error(__('Errore durante l\'aggiunta al carrello', 'chez-halima-child-theme'));
    }
    wp_send_json_success(array('cart_count' => WC()->cart->get_cart_contents_count()));
}

/** Prodotto base nascosto a cui si agganciano le righe del configuratore. */
function chezhalima_base_product_id()
{
    $found = get_posts(array(
        'post_type'              => 'product',
        'post_status'            => array('publish', 'private', 'draft'),
        'posts_per_page'         => 1,
        'fields'                 => 'ids',
        'meta_key'               => '_pastry_base_product',
        'meta_value'             => 'yes',
        'no_found_rows'          => true,
        'update_post_term_cache' => false,
    ));
    if ($found) {
        // WooCommerce non vende ai visitatori un prodotto privato: deve essere pubblicato (e nascosto dal catalogo).
        if (get_post_status($found[0]) !== 'publish') {
            wp_update_post(array('ID' => (int) $found[0], 'post_status' => 'publish'));
        }
        return (int) $found[0];
    }
    $product = new WC_Product_Simple();
    $product->set_name(__('Pasticcino Personalizzato', 'chez-halima-child-theme'));
    $product->set_status('publish');
    $product->set_catalog_visibility('hidden');
    $product->set_regular_price(0);
    $product->set_virtual(true);
    $id = $product->save();
    if ($id) {
        update_post_meta($id, '_pastry_base_product', 'yes');
    }
    return $id;
}

add_filter('woocommerce_cart_item_name', function ($name, $cart_item) {
    if (isset($cart_item['pastry_name'], $cart_item['pastry_size_name'])) {
        return sprintf(
            '<strong>%s</strong><br><small>%s: %s</small>',
            esc_html($cart_item['pastry_name']),
            esc_html__('Dimensione', 'chez-halima-child-theme'),
            esc_html($cart_item['pastry_size_name'])
        );
    }
    return $name;
}, 10, 2);

add_action('woocommerce_before_calculate_totals', function ($cart) {
    if (is_admin() && !wp_doing_ajax()) {
        return;
    }
    foreach ($cart->get_cart() as $cart_item) {
        if (isset($cart_item['pastry_custom_price'])) {
            $cart_item['data']->set_price($cart_item['pastry_custom_price']);
        }
    }
});

add_filter('woocommerce_get_item_data', function ($data, $cart_item) {
    if (isset($cart_item['pastry_name'])) {
        $data[] = array('name' => __('Prodotto', 'chez-halima-child-theme'), 'value' => $cart_item['pastry_name']);
    }
    if (isset($cart_item['pastry_size_name'])) {
        $data[] = array('name' => __('Dimensione', 'chez-halima-child-theme'), 'value' => $cart_item['pastry_size_name']);
    }
    return $data;
}, 10, 2);

add_action('woocommerce_checkout_create_order_line_item', function ($item, $cart_item_key, $values) {
    if (isset($values['pastry_name'])) {
        $item->add_meta_data(__('Prodotto', 'chez-halima-child-theme'), $values['pastry_name']);
    }
    if (isset($values['pastry_size_name'])) {
        $item->add_meta_data(__('Dimensione', 'chez-halima-child-theme'), $values['pastry_size_name']);
    }
}, 10, 3);

/** Immagine hero della pagina del configuratore (metabox nella barra laterale delle pagine). */
add_action('add_meta_boxes', function () {
    add_meta_box('pastry_hero_image', __('Immagine hero pasticceria', 'chez-halima-child-theme'), 'chezhalima_hero_metabox', 'page', 'side');
});

function chezhalima_hero_metabox($post)
{
    wp_nonce_field('pastry_hero_image_nonce', 'pastry_hero_image_nonce_field');
    $id  = (int) get_post_meta($post->ID, '_pastry_hero_image', true);
    $url = $id ? wp_get_attachment_image_url($id, 'medium') : '';
    ?>
    <div class="pastry-hero-image-wrapper">
        <input type="hidden" id="pastry_hero_image_id" name="pastry_hero_image_id" value="<?php echo esc_attr($id ?: ''); ?>">
        <div id="pastry_hero_image_preview">
            <?php if ($url) : ?>
                <img src="<?php echo esc_url($url); ?>" alt="" style="max-width:100%;height:auto;border-radius:4px;">
            <?php else : ?>
                <p><em><?php esc_html_e('Nessuna immagine selezionata', 'chez-halima-child-theme'); ?></em></p>
            <?php endif; ?>
        </div>
        <button type="button" class="button" id="pastry_hero_upload_button"><?php echo $url ? esc_html__('Cambia immagine', 'chez-halima-child-theme') : esc_html__('Carica immagine', 'chez-halima-child-theme'); ?></button>
        <button type="button" class="button-link-delete" id="pastry_hero_remove_button" <?php echo $url ? '' : 'hidden'; ?>><?php esc_html_e('Rimuovi', 'chez-halima-child-theme'); ?></button>
        <p class="description"><?php esc_html_e('Sfondo dell\'hero. Dimensioni consigliate: 1920×600 px.', 'chez-halima-child-theme'); ?></p>
    </div>
    <?php
}

add_action('admin_enqueue_scripts', function ($hook) {
    if (!in_array($hook, array('post.php', 'post-new.php'), true) || get_post_type() !== 'page') {
        return;
    }
    wp_enqueue_media();
    wp_enqueue_script('chezhalima-hero-admin', get_stylesheet_directory_uri() . '/assets/js/admin-hero.js', array('jquery'), wp_get_theme()->get('Version'), true);
    wp_localize_script('chezhalima-hero-admin', 'chezHalimaHero', array(
        'title'  => __('Seleziona immagine hero', 'chez-halima-child-theme'),
        'button' => __('Usa questa immagine', 'chez-halima-child-theme'),
        'change' => __('Cambia immagine', 'chez-halima-child-theme'),
        'upload' => __('Carica immagine', 'chez-halima-child-theme'),
        'none'   => __('Nessuna immagine selezionata', 'chez-halima-child-theme'),
    ));
});

add_action('save_post_page', function ($post_id) {
    if (
        !isset($_POST['pastry_hero_image_nonce_field']) ||
        !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['pastry_hero_image_nonce_field'])), 'pastry_hero_image_nonce') ||
        (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) ||
        !current_user_can('edit_post', $post_id)
    ) {
        return;
    }
    $image = isset($_POST['pastry_hero_image_id']) ? absint($_POST['pastry_hero_image_id']) : 0;
    if ($image && wp_attachment_is_image($image)) {
        update_post_meta($post_id, '_pastry_hero_image', $image);
    } else {
        delete_post_meta($post_id, '_pastry_hero_image');
    }
});
