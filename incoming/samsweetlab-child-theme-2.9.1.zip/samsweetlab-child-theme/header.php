<?php defined('ABSPATH') || exit; ?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head><meta charset="<?php bloginfo('charset'); ?>"><meta name="viewport" content="width=device-width, initial-scale=1"><?php wp_head(); ?></head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="skip-link" href="#main-content"><?php esc_html_e('Vai al contenuto', 'samsweetlab-child-theme'); ?></a>
<header class="site-header">
  <a class="site-brand" href="<?php echo esc_url(home_url('/')); ?>" rel="home">
    <?php $logo=sweet_logo_img((string) ticinoweb_get_site_logo()); if ($logo) : echo $logo; /* escape fatto in sweet_logo_img() */ else : ?><span><?php echo esc_html(sweet_text(get_bloginfo('name'),'site_name')); ?></span><?php endif; ?>
  </a>
  <button class="search-open search-open--bar" type="button" commandfor="sweet-search" command="show-modal" aria-label="<?php esc_attr_e('Cerca nel sito', 'samsweetlab-child-theme'); ?>"><svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true" focusable="false"><circle cx="10.5" cy="10.5" r="6.5" fill="none" stroke="currentColor" stroke-width="1.6"/><path d="M15.4 15.4 21 21" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg></button>
  <?php if (function_exists('sweet_cart_link') && sweet_sells()) : ?><div class="shop-links"><?php sweet_account_link(); sweet_cart_link(); ?></div><?php endif; ?>
  <button class="menu-toggle" type="button" aria-expanded="false" aria-controls="site-navigation"><?php esc_html_e('Menu', 'samsweetlab-child-theme'); ?><span aria-hidden="true">☰</span></button>
  <nav id="site-navigation" aria-label="<?php esc_attr_e('Navigazione principale', 'samsweetlab-child-theme'); ?>"><?php wp_nav_menu(array('theme_location'=>'primary','container'=>false,'menu_class'=>'primary-menu','fallback_cb'=>false)); ?><button class="search-open search-open--nav" type="button" commandfor="sweet-search" command="show-modal" aria-label="<?php esc_attr_e('Cerca nel sito', 'samsweetlab-child-theme'); ?>"><svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true" focusable="false"><circle cx="10.5" cy="10.5" r="6.5" fill="none" stroke="currentColor" stroke-width="1.6"/><path d="M15.4 15.4 21 21" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg></button><?php sweet_language_switcher(); ?></nav>
</header>

<dialog id="sweet-search" class="search-dialog" closedby="any" aria-labelledby="sweet-search-title">
  <form class="search-form" role="search" method="get" action="<?php echo esc_url(home_url('/')); ?>">
    <h2 id="sweet-search-title" class="screen-reader-text"><?php esc_html_e('Cerca nel sito', 'samsweetlab-child-theme'); ?></h2>
    <div class="search-field">
      <svg viewBox="0 0 24 24" width="22" height="22" aria-hidden="true" focusable="false"><circle cx="10.5" cy="10.5" r="6.5" fill="none" stroke="currentColor" stroke-width="1.6"/><path d="M15.4 15.4 21 21" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg>
      <input id="sweet-search-input" type="search" name="s" autocomplete="off" autofocus enterkeyhint="search" spellcheck="false"
        placeholder="<?php esc_attr_e('Cosa stai cercando?', 'samsweetlab-child-theme'); ?>"
        aria-label="<?php esc_attr_e('Cosa stai cercando?', 'samsweetlab-child-theme'); ?>"
        role="combobox" aria-expanded="false" aria-controls="sweet-search-list" aria-autocomplete="list">
      <button class="search-close" type="button" commandfor="sweet-search" command="close" aria-label="<?php esc_attr_e('Chiudi', 'samsweetlab-child-theme'); ?>"><svg viewBox="0 0 16 16" width="14" height="14" aria-hidden="true" focusable="false"><path d="M3 3 13 13M13 3 3 13" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg></button>
    </div>
    <ul id="sweet-search-list" class="search-suggestions" role="listbox" aria-label="<?php esc_attr_e('Cerca nel sito', 'samsweetlab-child-theme'); ?>" hidden></ul>
    <p class="search-status screen-reader-text" role="status" aria-live="polite"></p>
    <a class="search-all text-link" href="#" hidden><?php esc_html_e('Vedi tutti i risultati', 'samsweetlab-child-theme'); ?> <span aria-hidden="true">↗</span></a>
  </form>
</dialog>
