<?php
/**
 * Modalità del negozio: «vendita online» o «su richiesta».
 *
 * Si sceglie in WooCommerce → Impostazioni → Generale → Modalità del negozio.
 * - Vendita online (predefinita): prezzi, pulsanti «Aggiungi», carrello e cassa.
 * - Su richiesta: niente prezzi, niente carrello né cassa; al posto di «Aggiungi»
 *   c'è «Contattaci», che apre una finestra per scrivere una mail o chiamare.
 *   Email e telefono vengono dai recapiti del ticinoWEB CMS.
 */
defined('ABSPATH') || exit;

/** true se il negozio vende online, false se è in modalità «su richiesta». */
function sweet_sells() {
    return get_option('sweet_shop_mode', 'shop') !== 'contact';
}

// L'impostazione, in cima a WooCommerce → Impostazioni → Generale.
add_filter('woocommerce_general_settings', function ($settings) {
    return array_merge(array(
        array(
            'title' => __('Modalità del negozio', 'samsweetlab-child-theme'),
            'type'  => 'title',
            'desc'  => __('Scegli se i clienti possono ordinare online oppure se ti contattano per un’offerta.', 'samsweetlab-child-theme'),
            'id'    => 'sweet_shop_mode_options',
        ),
        array(
            'title'   => __('Prezzi e ordini', 'samsweetlab-child-theme'),
            'id'      => 'sweet_shop_mode',
            'type'    => 'radio',
            'default' => 'shop',
            'options' => array(
                'shop'    => __('Vendita online: prezzi visibili, carrello e ordini', 'samsweetlab-child-theme'),
                'contact' => __('Su richiesta: prezzi e carrello nascosti, pulsante «Contattaci» per scrivere o chiamare', 'samsweetlab-child-theme'),
            ),
            'desc_tip' => false,
        ),
        array('type' => 'sectionend', 'id' => 'sweet_shop_mode_options'),
    ), $settings);
});

// Cambiando modalità, le pagine salvate nella cache mostrerebbero ancora quella vecchia.
add_action('update_option_sweet_shop_mode', function () { do_action('litespeed_purge_all'); });
add_action('add_option_sweet_shop_mode', function () { do_action('litespeed_purge_all'); });

/* ---------------------------------------------------------------
 * Modalità «su richiesta»
 * --------------------------------------------------------------- */

// Nessun prodotto si può mettere nel carrello (vale anche per i link diretti ?add-to-cart=).
add_filter('woocommerce_is_purchasable', function ($purchasable) { return sweet_sells() ? $purchasable : false; }, 99);
add_filter('woocommerce_variation_is_purchasable', function ($purchasable) { return sweet_sells() ? $purchasable : false; }, 99);
// Nessun prezzo, nemmeno dove lo stampa WooCommerce da solo.
add_filter('woocommerce_get_price_html', function ($html) { return sweet_sells() ? $html : ''; }, 99);

// Carrello e cassa non esistono: chi ci arriva (vecchio link, preferiti) va al catalogo.
add_action('template_redirect', function () {
    if (sweet_sells() || !(is_cart() || is_checkout())) return;
    if (is_checkout() && is_wc_endpoint_url('order-received')) return; // conferma di un ordine già fatto
    if (WC()->cart) WC()->cart->empty_cart();
    wp_safe_redirect(sweet_page_url('ingredients'));
    exit;
});

/**
 * La finestra «Contattaci» serve in questa pagina? Sempre nel negozio «su richiesta»;
 * altrove la chiede chi la usa (lo shortcode [sweet_contatto]).
 */
function sweet_contact_dialog_needed($chiedila = false) {
    static $serve = null;
    if ($serve === null) $serve = !sweet_sells();
    if ($chiedila) $serve = true;
    return $serve;
}

/**
 * Pulsante «Contattaci». Senza JavaScript porta alla pagina Contatti; con JavaScript
 * apre la finestra con mail e telefono, con il nome del prodotto nell'oggetto della mail.
 *
 * @param WC_Product|null $product Il prodotto, se il pulsante è nella sua scheda.
 * @param string          $class   Classi in più per il pulsante.
 * @param string          $label   Scritta del pulsante, vuota per «Contattaci».
 */
function sweet_contact_button($product, $class = '', $label = '') {
    sweet_contact_dialog_needed(true);
    $title = $product ? wp_strip_all_tags(get_the_title($product->get_id())) : '';
    return sprintf(
        '<a href="%s" class="button sweet-contact-open %s" data-product="%s"%s>%s <span aria-hidden="true">↗</span></a>',
        esc_url(sweet_page_url('contacts')),
        esc_attr($class),
        esc_attr($title),
        /* translators: %s: nome del prodotto */
        $title !== '' ? ' aria-label="' . esc_attr(sprintf(__('Contattaci per «%s»', 'samsweetlab-child-theme'), $title)) . '"' : '',
        esc_html($label !== '' ? $label : __('Contattaci', 'samsweetlab-child-theme'))
    );
}

/**
 * [sweet_contatto] — il pulsante che apre la finestra con mail e telefono, da usare
 * in qualsiasi pagina. Attributi: testo="…" e classe="…".
 */
add_shortcode('sweet_contatto', function ($attributes) {
    $a = shortcode_atts(array('testo' => '', 'classe' => ''), $attributes);
    return sweet_contact_button(null, $a['classe'], (string) $a['testo']);
});

// La finestra, una sola per pagina, in fondo.
add_action('wp_footer', function () {
    if (!sweet_contact_dialog_needed()) return;
    $contact = ticinoweb_get_contact_info();
    $email = (string) $contact['email'];
    $phone = (string) $contact['phone'];
    $phone_display = (string) (get_option('ticinoweb_contact_phone_display') ?: $phone);
    ?>
<dialog id="sweet-contact" class="sweet-contact" closedby="any" aria-labelledby="sweet-contact-title"><div class="sweet-contact-box">
  <div class="sweet-contact-head">
    <div>
      <?php if (!sweet_sells()) : ?><p class="eyebrow"><?php esc_html_e('Prezzo e disponibilità su richiesta', 'samsweetlab-child-theme'); ?></p><?php endif; ?>
      <h2 id="sweet-contact-title"><?php esc_html_e('Contattaci', 'samsweetlab-child-theme'); ?></h2>
      <p class="sweet-contact-product" hidden></p>
    </div>
    <button class="search-close" type="button" commandfor="sweet-contact" command="close" aria-label="<?php esc_attr_e('Chiudi', 'samsweetlab-child-theme'); ?>"><svg viewBox="0 0 16 16" width="14" height="14" aria-hidden="true" focusable="false"><path d="M3 3 13 13M13 3 3 13" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg></button>
  </div>
  <p class="sweet-contact-intro"><?php echo esc_html(sweet_sells()
      ? __('Scrivici o chiamaci: ti rispondiamo con tutte le informazioni che ti servono.', 'samsweetlab-child-theme')
      : __('Scrivici o chiamaci: ti rispondiamo con prezzo, disponibilità e tempi di consegna.', 'samsweetlab-child-theme')); ?></p>
  <div class="sweet-contact-ways">
    <?php if ($email !== '') : ?>
    <a class="sweet-contact-way sweet-contact-mail" href="<?php echo esc_url('mailto:' . $email); ?>" data-email="<?php echo esc_attr($email); ?>">
      <svg viewBox="0 0 24 24" width="30" height="30" aria-hidden="true" focusable="false" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round" stroke-linecap="round"><rect x="3" y="5.5" width="18" height="13" rx="2"/><path d="m4 7 8 6 8-6"/></svg>
      <span class="eyebrow"><?php esc_html_e('Scrivici una mail', 'samsweetlab-child-theme'); ?></span>
      <strong><?php echo esc_html($email); ?></strong>
    </a>
    <?php endif; ?>
    <?php if ($phone !== '') : ?>
    <a class="sweet-contact-way" href="<?php echo esc_url('tel:' . preg_replace('/[^+0-9]/', '', $phone)); ?>">
      <svg viewBox="0 0 24 24" width="30" height="30" aria-hidden="true" focusable="false" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round" stroke-linecap="round"><path d="M6.6 3.5h2.8l1.4 4.2-2 1.4a12 12 0 0 0 6.1 6.1l1.4-2 4.2 1.4v2.8a2 2 0 0 1-2.2 2A16.5 16.5 0 0 1 4.6 5.7a2 2 0 0 1 2-2.2z"/></svg>
      <span class="eyebrow"><?php esc_html_e('Chiamaci', 'samsweetlab-child-theme'); ?></span>
      <strong><?php echo esc_html($phone_display); ?></strong>
    </a>
    <?php endif; ?>
    <?php if ($email === '' && $phone === '') : ?>
    <a class="button" href="<?php echo esc_url(sweet_page_url('contacts')); ?>"><?php esc_html_e('Vai alla pagina Contatti', 'samsweetlab-child-theme'); ?> <span aria-hidden="true">↗</span></a>
    <?php endif; ?>
  </div>
</div></dialog>
<?php
}, 5);

// I testi della mail precompilata, nella lingua della pagina.
add_action('wp_enqueue_scripts', function () {
    wp_add_inline_script('samsweetlab-site', 'window.sweetContact=' . wp_json_encode(array(
        /* translators: %s: nome del prodotto */
        'subject' => __('Richiesta per «%s»', 'samsweetlab-child-theme'),
        'subjectAll' => __('Richiesta di informazioni', 'samsweetlab-child-theme'),
        /* translators: %s: nome del prodotto */
        'body' => __('Buongiorno, vorrei ricevere prezzo e disponibilità di «%s».', 'samsweetlab-child-theme'),
    )) . ';', 'before');
}, 22);
