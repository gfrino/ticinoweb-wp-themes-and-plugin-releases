<?php
/**
 * Home: hero con ricerca, presentazione (testo della pagina), immobili
 * in evidenza, categorie, promozioni, blog e FAQ.
 *
 * @package Idea_Immobiliare_SA
 */
get_header();

$featured = idea_immo_featured_query(9);
$cats     = get_terms(array('taxonomy' => 'categoria_immobile', 'hide_empty' => true, 'orderby' => 'count', 'order' => 'DESC', 'number' => 6));
$promos   = new WP_Query(array('post_type' => 'promozione', 'posts_per_page' => 3, 'no_found_rows' => true));
$blog_q   = new WP_Query(array('post_type' => 'post', 'posts_per_page' => 3, 'no_found_rows' => true, 'ignore_sticky_posts' => true));
$archive  = get_post_type_archive_link('immobile');
?>
<main id="main">
<?php while (have_posts()) : the_post(); ?>
	<section class="idea-hero"<?php if (has_post_thumbnail()) : ?> style="background-image:url('<?php echo esc_url(get_the_post_thumbnail_url(get_the_ID(), 'idea-hero')); ?>')"<?php endif; ?>>
		<div class="idea-hero__shade"></div>
		<div class="idea-container idea-hero__inner">
			<h1 class="idea-hero__title"><?php bloginfo('name'); ?></h1>
			<?php if (get_bloginfo('description') !== '') : ?><p class="idea-hero__lead"><?php bloginfo('description'); ?></p><?php endif; ?>
		</div>
	</section>

	<section class="idea-searchbar">
		<div class="idea-container">
			<p class="idea-searchbar__title"><strong><?php esc_html_e('Trova', 'idea-immobiliare-sa'); ?></strong> <?php esc_html_e('la casa dei tuoi sogni', 'idea-immobiliare-sa'); ?></p>
			<?php echo idea_immo_search_form(); // phpcs:ignore WordPress.Security.EscapeOutput ?>
		</div>
	</section>

	<?php if (trim(get_the_content()) !== '') : ?>
	<section class="idea-section idea-intro">
		<div class="idea-container idea-prose idea-prose--wide">
			<?php the_content(); ?>
		</div>
	</section>
	<?php endif; ?>
<?php endwhile; ?>

	<?php if ($featured->have_posts()) : ?>
	<section class="idea-section idea-section--tint">
		<div class="idea-container">
			<h2 class="idea-section__title"><?php esc_html_e('I nostri immobili scelti e selezionati per voi', 'idea-immobiliare-sa'); ?></h2>
			<div class="idea-grid">
				<?php while ($featured->have_posts()) : $featured->the_post(); get_template_part('template-parts/property-card'); endwhile; wp_reset_postdata(); ?>
			</div>
			<p class="idea-section__more"><a class="idea-btn idea-btn--navy" href="<?php echo esc_url($archive); ?>"><?php esc_html_e('Vedi tutti gli immobili', 'idea-immobiliare-sa'); ?></a></p>
		</div>
	</section>
	<?php endif; ?>

	<?php if ($cats && !is_wp_error($cats)) : ?>
	<section class="idea-section">
		<div class="idea-container">
			<h2 class="idea-section__title"><?php esc_html_e('Le categorie dei nostri immobili', 'idea-immobiliare-sa'); ?></h2>
			<ul class="idea-cats">
				<?php foreach ($cats as $cat) : ?>
					<li>
						<a href="<?php echo esc_url(get_term_link($cat)); ?>">
							<?php echo idea_immo_category_icon($cat->slug); // phpcs:ignore WordPress.Security.EscapeOutput ?>
							<strong><?php echo esc_html($cat->name); ?></strong>
							<span><?php esc_html_e('Scopri gli immobili', 'idea-immobiliare-sa'); ?></span>
						</a>
					</li>
				<?php endforeach; ?>
			</ul>
		</div>
	</section>
	<?php endif; ?>

	<?php if ($promos->have_posts()) : ?>
	<section class="idea-section idea-section--tint">
		<div class="idea-container">
			<h2 class="idea-section__title"><?php esc_html_e('Le nostre promozioni immobiliari', 'idea-immobiliare-sa'); ?></h2>
			<div class="idea-grid idea-grid--3">
				<?php while ($promos->have_posts()) : $promos->the_post(); get_template_part('template-parts/post-card'); endwhile; wp_reset_postdata(); ?>
			</div>
			<p class="idea-section__more"><a class="idea-btn idea-btn--navy" href="<?php echo esc_url(get_post_type_archive_link('promozione')); ?>"><?php esc_html_e('Scopri le nostre selezioni', 'idea-immobiliare-sa'); ?></a></p>
		</div>
	</section>
	<?php endif; ?>

	<?php if ($blog_q->have_posts()) : ?>
	<section class="idea-section">
		<div class="idea-container">
			<h2 class="idea-section__title"><?php esc_html_e('Blog immobiliare', 'idea-immobiliare-sa'); ?></h2>
			<div class="idea-grid idea-grid--3">
				<?php while ($blog_q->have_posts()) : $blog_q->the_post(); get_template_part('template-parts/post-card'); endwhile; wp_reset_postdata(); ?>
			</div>
			<?php $blog = get_option('page_for_posts') ? get_permalink(get_option('page_for_posts')) : ''; if ($blog) : ?>
			<p class="idea-section__more"><a class="idea-btn idea-btn--navy" href="<?php echo esc_url($blog); ?>"><?php esc_html_e('Leggi il blog', 'idea-immobiliare-sa'); ?></a></p>
			<?php endif; ?>
		</div>
	</section>
	<?php endif; ?>

	<?php
	if (function_exists('ticinoweb_faq_render')) {
		$faq = ticinoweb_faq_render('domande-frequenti-idea-immobiliare', array('show_title' => false));
		if ($faq !== '') : ?>
		<section class="idea-section idea-section--tint">
			<div class="idea-container idea-prose">
				<h2 class="idea-section__title"><?php esc_html_e('Domande frequenti', 'idea-immobiliare-sa'); ?></h2>
				<?php echo $faq; // phpcs:ignore WordPress.Security.EscapeOutput ?>
			</div>
		</section>
		<?php endif;
	}
	?>
</main>
<?php get_footer(); ?>
