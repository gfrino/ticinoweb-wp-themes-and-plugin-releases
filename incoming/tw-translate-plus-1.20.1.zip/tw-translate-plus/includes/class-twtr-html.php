<?php
/**
 * Page-level translation: the finished HTML of every translated page is
 * scanned and each visible text (plus alt, title, placeholder, aria-label,
 * button values and SEO meta) is translated, like a browser translator
 * does — but stored, indexable and cached.
 *
 * Why: the WordPress filters (titles, content, terms, widgets…) only see
 * what goes through WordPress. Themes and page builders also print text of
 * their own — template labels, sections built by parsing the content,
 * Elementor widgets, plugin markup — that no filter ever sees. This layer
 * catches all of it, on any theme.
 *
 * Cost: runs only on translated pages and only when the page is generated
 * (LiteSpeed then caches the result). One indexed query by hash per page;
 * new texts are queued (context "html", shared by every page, so a label
 * repeated on 900 products is one row per language) and translated in
 * background.
 *
 * Not translated: script, style, code, pre, textarea, svg, template,
 * noscript, the admin bar, anything inside class="notranslate" or
 * translate="no", texts without letters, and translations already output
 * by the filters in this request.
 *
 * Script data: the JSON that themes and plugins hand to their scripts with
 * wp_localize_script() (<script id="…-js-extra">) is interface text the
 * visitor sees once the script renders it. Its string values are translated
 * too, but only under keys that name visible text (label, title, message,
 * strings, i18n…) and never under technical keys (id, url, nonce, keywords…),
 * so data the script compares or sends back keeps its original value. See
 * translate_script_data().
 *
 * @package tw-translate-plus
 */

if (!defined('ABSPATH')) {
    exit;
}

class Twtr_Html {

    const CONTEXT = 'html';
    const MAX_NEW_PER_PAGE = 300;

    /** Elements whose content is never translated. */
    private static $skip_tags = array('script', 'style', 'code', 'pre', 'textarea', 'svg', 'template', 'noscript', 'math', 'kbd', 'samp', 'var');

    /** @var string Current language slug. */
    private static $locale = '';

    /** @var array<string,string[]> Hashes discovered per post id (for «Traduci adesso»). */
    private static $post_hashes = array();

    public static function init() {
        if (wp_doing_cron() || (defined('WP_CLI') && WP_CLI)) {
            return;
        }
        // HTML fragments returned as JSON by front-end AJAX (JetEngine lazy
        // listings and "load more", JetSmartFilters, WooCommerce fragments):
        // they never reach the page buffer, so they are translated here.
        if (self::is_fragment_request()) {
            self::$locale = Twtr_Router::current_language();
            if (self::$locale !== '' && apply_filters('twtr_translate_html', true)) {
                ob_start(array(__CLASS__, 'filter_fragment'));
            }
            return;
        }
        if (is_admin() || wp_doing_ajax() || (defined('REST_REQUEST') && REST_REQUEST)) {
            return;
        }
        self::$locale = Twtr_Router::current_language();
        if (self::$locale === '' || !apply_filters('twtr_translate_html', true)) {
            return;
        }
        // Early: themes and plugins that print a page and exit inside
        // template_redirect (maintenance pages, landing pages) are covered
        // too. Page caches (LiteSpeed) buffer outside this one, so they store
        // the translated result.
        add_action('template_redirect', array(__CLASS__, 'start'), -10000);
    }

    public static function start() {
        if (is_feed() || is_robots() || is_trackback() || is_embed()) {
            return;
        }
        ob_start(array(__CLASS__, 'filter'));
    }

    /**
     * Output-buffer callback.
     *
     * @param string $html
     * @return string
     */
    public static function filter($html) {
        if (!is_string($html) || $html === '' || stripos($html, '<body') === false) {
            return $html; // not an HTML page (JSON, XML, partial output)
        }
        foreach (headers_list() as $header) {
            if (stripos($header, 'content-type:') === 0 && stripos($header, 'text/html') === false) {
                return $html;
            }
        }
        // Memory guard: tokenizing costs roughly 10x the page size. On a
        // process already close to its limit, serve the page untranslated
        // rather than risk an out-of-memory error.
        $limit = wp_convert_hr_to_bytes((string) ini_get('memory_limit'));
        if (strlen($html) > 4 * MB_IN_BYTES || ($limit > 0 && memory_get_usage(true) + strlen($html) * 12 > $limit * 0.85)) {
            return $html;
        }
        try {
            return self::translate_document($html);
        } catch (Throwable $e) {
            return $html; // never break a page
        }
    }

    /**
     * Front-end AJAX requests whose response carries visible HTML.
     *
     * @return bool
     */
    private static function is_fragment_request() {
        // phpcs:disable WordPress.Security.NonceVerification
        $action = isset($_REQUEST['action']) ? sanitize_key(wp_unslash($_REQUEST['action'])) : '';
        $wanted = !empty($_REQUEST['jet_engine_action'])
            || isset($_GET['wc-ajax'])
            // JetEngine posts action=jet_engine_ajax to the page URL itself and
            // only defines DOING_AJAX later, in parse_request.
            || in_array($action, array('jet_engine_ajax', 'jet_smart_filters'), true);
        // phpcs:enable
        return (bool) apply_filters('twtr_translate_ajax_fragment', $wanted, $action);
    }

    /**
     * Output-buffer callback for AJAX responses: JSON whose string values
     * contain HTML, or a bare HTML fragment.
     *
     * @param string $out
     * @return string
     */
    public static function filter_fragment($out) {
        if (!is_string($out) || strpos($out, '<') === false || strlen($out) > 4 * MB_IN_BYTES) {
            return $out;
        }
        try {
            $trim = ltrim($out);
            if ($trim !== '' && ($trim[0] === '{' || $trim[0] === '[')) {
                $data = json_decode($out, true);
                if (!is_array($data)) {
                    return $out;
                }
                $changed = false;
                array_walk_recursive($data, function (&$v) use (&$changed) {
                    if (is_string($v) && strpos($v, '<') !== false && strpos($v, '>') !== false) {
                        $t = self::translate_document($v, true);
                        if ($t !== $v) {
                            $v       = $t;
                            $changed = true;
                        }
                    }
                });
                if (!$changed) {
                    return $out;
                }
                $json = wp_json_encode($data);
                return is_string($json) ? $json : $out;
            }
            return self::translate_document($out, true);
        } catch (Throwable $e) {
            return $out; // never break a response
        }
    }

    /**
     * @param string $html     Full document, or a fragment (no <body>).
     * @param bool   $fragment Treat the whole input as visible content.
     * @return string
     */
    public static function translate_document($html, $fragment = false) {
        $locale = self::$locale !== '' ? self::$locale : Twtr_Router::current_language();
        if ($locale === '') {
            return $html;
        }
        if (!$fragment) {
            $html = self::translate_script_data($html, $locale);
        }
        $tokens = preg_split('/(<!--.*?-->|<[^>]*>)/s', $html, -1, PREG_SPLIT_DELIM_CAPTURE | PREG_SPLIT_NO_EMPTY);
        if (!$tokens) {
            return $html;
        }

        $segments = array(); // token index => array(kind, data)
        $wanted   = array(); // hash => source text
        $skip_tag = '';
        $depth    = 0;
        $in_body  = (bool) $fragment;
        $in_title = false;

        foreach ($tokens as $i => $tok) {
            if ($tok[0] === '<') {
                if (strpos($tok, '<!--') === 0 || strpos($tok, '<!') === 0 || strpos($tok, '<?') === 0) {
                    continue;
                }
                if (!preg_match('/^<\s*(\/?)\s*([a-zA-Z][a-zA-Z0-9:-]*)/', $tok, $m)) {
                    continue;
                }
                $closing = $m[1] === '/';
                $name    = strtolower($m[2]);
                $self    = substr($tok, -2) === '/>';

                if ($skip_tag !== '') {
                    if ($name === $skip_tag && !$self) {
                        $depth += $closing ? -1 : 1;
                        if ($depth <= 0) {
                            $skip_tag = '';
                            $depth    = 0;
                        }
                    }
                    continue;
                }
                if ($name === 'body' && !$closing) {
                    $in_body = true;
                }
                if ($name === 'title') {
                    $in_title = !$closing && !$in_body; // the document title, not an SVG <title>
                }
                if (!$closing && $name === 'a' && $in_body) {
                    // Internal links stored as default-language URLs (page
                    // builders, editors): point them to this language.
                    $tokens[$i] = $tok = self::localize_href($tok, $locale);
                }
                if (!$closing) {
                    // Translatable attributes of this tag.
                    $attrs = self::attribute_segments($name, $tok);
                    if ($attrs) {
                        $segments[$i] = array('attr', $attrs);
                        foreach ($attrs as $a) {
                            $wanted[md5($a['text'])] = $a['text'];
                        }
                    }
                    $opaque = in_array($name, self::$skip_tags, true)
                        || preg_match('/\sclass\s*=\s*["\'][^"\']*\bnotranslate\b/i', $tok)
                        || preg_match('/\stranslate\s*=\s*["\']?no\b/i', $tok)
                        || preg_match('/\sid\s*=\s*["\']wpadminbar["\']/i', $tok);
                    if ($opaque && !$self && !in_array($name, array('br', 'img', 'input', 'meta', 'link', 'hr', 'source', 'wbr'), true)) {
                        $skip_tag = $name;
                        $depth    = 1;
                    }
                }
                continue;
            }
            if ($skip_tag !== '' || (!$in_body && !$in_title)) {
                continue;
            }
            $text = trim($tok);
            if (!self::worth($text, $locale)) {
                continue;
            }
            $segments[$i] = array('text', $text);
            $wanted[md5($text)] = $text;
            // Same text with entities decoded (&#8217; / &rsquo; / ’ are one
            // character spelled three ways, depending on the locale that ran
            // wptexturize): a translation stored in any spelling is found.
            $alt = self::decoded($text);
            if ($alt !== $text) {
                $wanted[md5($alt)] = $alt;
            }
        }

        if (!$segments) {
            return $html;
        }

        $found = self::lookup($locale, array_keys($wanted));

        // Replace.
        $missing = array();
        foreach ($segments as $i => $seg) {
            if ($seg[0] === 'text') {
                $hash = md5($seg[1]);
                if (!isset($found[$hash])) {
                    $alt = md5(self::decoded($seg[1]));
                    if (isset($found[$alt])) {
                        $found[$hash] = $found[$alt];
                    }
                }
                if (isset($found[$hash])) {
                    $tok         = $tokens[$i];
                    $lead        = substr($tok, 0, strlen($tok) - strlen(ltrim($tok)));
                    $trail       = substr($tok, strlen(rtrim($tok)));
                    $tokens[$i]  = $lead . self::as_text($found[$hash]) . $trail;
                } else {
                    $missing[$hash] = $seg[1];
                }
                continue;
            }
            $tag = $tokens[$i];
            foreach ($seg[1] as $a) {
                $hash = md5($a['text']);
                if (isset($found[$hash])) {
                    $tag = str_replace($a['full'], $a['prefix'] . esc_attr(self::plain($found[$hash])) . $a['suffix'], $tag);
                } else {
                    $missing[$hash] = $a['text'];
                }
            }
            $tokens[$i] = $tag;
        }

        if ($missing) {
            self::queue($locale, $missing);
        }
        return implode('', $tokens);
    }

    /**
     * Translatable attributes of one opening tag.
     *
     * @return array<int,array{full:string,prefix:string,suffix:string,text:string}>
     */
    private static function attribute_segments($name, $tag) {
        $names = array('title', 'alt', 'placeholder', 'aria-label', 'aria-description', 'data-title', 'data-tooltip');
        if ($name === 'input' && preg_match('/\stype\s*=\s*["\']?(submit|button|reset)\b/i', $tag)) {
            $names[] = 'value';
        }
        if ($name === 'meta' && preg_match('/\s(?:name|property)\s*=\s*["\'](description|og:title|og:description|twitter:title|twitter:description|og:image:alt)["\']/i', $tag)) {
            $names = array('content');
        }
        $out = array();
        if (!preg_match_all('/(\s(' . implode('|', array_map('preg_quote', $names)) . ')\s*=\s*(["\']))(.*?)(\3)/is', $tag, $m, PREG_SET_ORDER)) {
            return $out;
        }
        foreach ($m as $hit) {
            $text = trim(html_entity_decode($hit[4], ENT_QUOTES | ENT_HTML5, 'UTF-8'));
            if (self::worth($text, self::$locale)) {
                $out[] = array('full' => $hit[0], 'prefix' => $hit[1], 'suffix' => $hit[5], 'text' => $text);
            }
        }
        return $out;
    }

    /**
     * Rewrite href of an <a> tag to the URL of the same page in $locale when
     * it points to this site (files, admin and anchors untouched).
     *
     * @param string $tag
     * @param string $locale
     * @return string
     */
    private static function localize_href($tag, $locale) {
        if (!preg_match('/\shref\s*=\s*(["\'])(.*?)\1/is', $tag, $m)) {
            return $tag;
        }
        // Language switchers (ours and other plugins') point to a chosen language.
        if (preg_match('/\shreflang\s*=|twtr-ls-link|wpml-ls-link/i', $tag)) {
            return $tag;
        }
        $href = html_entity_decode($m[2], ENT_QUOTES | ENT_HTML5, 'UTF-8');
        if ($href === '' || $href[0] === '#' || preg_match('#\.(jpe?g|png|gif|webp|svg|pdf|zip|docx?|xlsx?|mp4|mp3)(\?|$)#i', $href)) {
            return $tag;
        }
        // Already pointing to a language explicitly: leave it.
        $extra = Twtr_Settings::extra_languages();
        $home  = rtrim((string) parse_url(get_option('home'), PHP_URL_PATH), '/');
        if ($extra && preg_match('#^(?:https?://[^/]+)?' . preg_quote($home, '#') . '/(' . implode('|', array_map('preg_quote', $extra)) . ')(/|$|\?)#', $href)) {
            return $tag;
        }
        $new = Twtr_Router::language_url($locale, $href);
        if ($new === $href) {
            return $tag;
        }
        return str_replace($m[0], ' href=' . $m[1] . esc_url($new) . $m[1], $tag);
    }

    /**
     * Translate the visible texts of wp_localize_script() data blocks.
     *
     * WordPress prints them as <script id="{handle}-js-extra"> with one
     * "var name = {json};" statement per line. Each statement is decoded,
     * its translatable string values are looked up (same store, same
     * "html" context and hash as the page texts, so a text already
     * translated anywhere on the site is reused) and the statement is
     * re-encoded only when something changed. Missing texts are queued
     * like any other page text. Anything that does not decode cleanly is
     * left exactly as it was.
     *
     * Filters:
     * - twtr_translate_script_data (bool, $script_id): opt a block out
     *   (or in, for ids that do not end in -js-extra).
     * - twtr_script_data_text_keys / twtr_script_data_skip_keys (regex):
     *   which keys hold visible text / technical values.
     *
     * @param string $html
     * @param string $locale
     * @return string
     */
    public static function translate_script_data($html, $locale) {
        if (stripos($html, '<script') === false || !apply_filters('twtr_translate_script_data_enabled', true)) {
            return $html;
        }
        if (!preg_match_all('#<script\b([^>]*)>(.*?)</script>#is', $html, $blocks, PREG_SET_ORDER | PREG_OFFSET_CAPTURE)) {
            return $html;
        }

        // Pass 1: collect statements and the texts they carry.
        $jobs   = array(); // list of array(offset, length, attrs-id, lines)
        $wanted = array(); // hash => text
        foreach ($blocks as $block) {
            $attrs = $block[1][0];
            $id    = preg_match('/\sid\s*=\s*["\']([^"\']+)["\']/i', ' ' . $attrs, $m) ? $m[1] : '';
            if (preg_match('/\stype\s*=\s*["\']?(?!text\/javascript|module)[^"\'\s>]+/i', ' ' . $attrs)) {
                continue; // JSON-LD, templates, other script types
            }
            $default = $id !== '' && substr($id, -strlen('-js-extra')) === '-js-extra';
            if (!apply_filters('twtr_translate_script_data', $default, $id)) {
                continue;
            }
            $body  = $block[2][0];
            $lines = preg_split('/(\r\n|\n|\r)/', $body, -1, PREG_SPLIT_DELIM_CAPTURE);
            $found = false;
            foreach ($lines as $i => $line) {
                if (!preg_match('/^(\s*var\s+[A-Za-z_$][\w$]*\s*=\s*)([\[{].*[\]}])(\s*;?\s*)$/s', $line, $sm)) {
                    continue;
                }
                $data = json_decode($sm[2]);
                if (!is_object($data) && !is_array($data)) {
                    continue;
                }
                $texts = array();
                self::collect_script_texts($data, array(), $texts, $locale);
                if (!$texts) {
                    continue;
                }
                foreach ($texts as $text) {
                    $wanted[md5($text)] = $text;
                    $alt = self::decoded($text);
                    if ($alt !== $text) {
                        $wanted[md5($alt)] = $alt;
                    }
                }
                $lines[$i] = array('prefix' => $sm[1], 'data' => $data, 'suffix' => $sm[3], 'raw' => $line);
                $found     = true;
            }
            if ($found) {
                $jobs[] = array('offset' => $block[2][1], 'length' => strlen($body), 'lines' => $lines);
            }
        }
        if (!$wanted) {
            return $html;
        }

        // Pass 2: one lookup for the whole page, then rewrite.
        $found   = self::lookup($locale, array_keys($wanted));
        $missing = array();
        foreach (array_reverse($jobs) as $job) {
            $out     = '';
            $changed = false;
            foreach ($job['lines'] as $line) {
                if (!is_array($line)) {
                    $out .= $line;
                    continue;
                }
                $data = $line['data'];
                if (self::apply_script_translations($data, array(), $found, $missing, $locale)) {
                    $json = wp_json_encode($data, JSON_HEX_TAG | JSON_UNESCAPED_SLASHES);
                    if (is_string($json)) {
                        $out    .= $line['prefix'] . $json . $line['suffix'];
                        $changed = true;
                        continue;
                    }
                }
                $out .= $line['raw'];
            }
            if ($changed) {
                $html = substr_replace($html, $out, $job['offset'], $job['length']);
            }
        }
        if ($missing) {
            self::queue($locale, $missing);
        }
        return $html;
    }

    /** Regex of keys whose string values are visible text. */
    private static function script_text_keys() {
        return (string) apply_filters(
            'twtr_script_data_text_keys',
            '/(label|title|text|help|desc|message|msg|notice|error|warning|hint|placeholder|caption|heading|subtitle|button|btn|tooltip|strings?|i18n|l10n|translations?|summary|intro|confirm|cta|empty|loading|success|fail)/i'
        );
    }

    /** Regex of keys whose values are technical and never translated. */
    private static function script_skip_keys() {
        return (string) apply_filters(
            'twtr_script_data_skip_keys',
            '/^(id|ids|key|keys|keywords?|slug|slugs|nonce|token|hash|type|mode|format|currency|locale|lang|class|classes|icon|selector|action|method|endpoint|route|email|phone|value|values|name|code|status|sku|unit)$|(_id|Id|Ids|_ids|url|Url|URL|uri|Uri|href|src|Src|nonce|Nonce|path|Path|selector|Selector|class|Class|key|Key)$/'
        );
    }

    /**
     * Whether the value at $path is translatable.
     *
     * The nearest named key decides first: technical keys never are. Then
     * any named key on the path that names visible text makes it so (for
     * "strings": {"Continua": "Continua"} the nearest key is the source
     * text itself and its parent names it as text).
     *
     * @param string[] $path Keys from the root (numeric indexes included).
     * @return bool
     */
    private static function script_path_translatable($path) {
        $named = array_values(array_filter($path, function ($k) {
            return !is_int($k) && !ctype_digit((string) $k);
        }));
        if (!$named) {
            return false;
        }
        $nearest = (string) end($named);
        $ident   = function ($k) {
            return (bool) preg_match('/^[A-Za-z_$][\w$-]*$/', (string) $k);
        };
        if ($ident($nearest) && preg_match(self::script_skip_keys(), $nearest)) {
            return false;
        }
        $text_keys = self::script_text_keys();
        foreach ($named as $k) {
            if ($ident($k) && preg_match($text_keys, (string) $k)) {
                return true;
            }
        }
        return false;
    }

    /** Whether a script data string looks like text for people. */
    private static function script_value_worth($value, $locale) {
        if (!self::worth($value, $locale)) {
            return false;
        }
        // A single token is text only when it reads like a word for people
        // ("Continua", "Indietro"); lowercase tokens are usually values the
        // script compares (bold, left, primary, d.m.Y, #fff, file-name.svg).
        if (!preg_match('/\s/u', $value)) {
            return (bool) preg_match('/^\p{Lu}\p{Ll}+[.!?…:]?$/u', $value);
        }
        return true;
    }

    /**
     * @param mixed    $node
     * @param array    $path
     * @param string[] $texts
     * @param string   $locale
     */
    private static function collect_script_texts($node, $path, &$texts, $locale) {
        if (is_object($node) || is_array($node)) {
            foreach ($node as $k => $v) {
                $p   = $path;
                $p[] = $k;
                self::collect_script_texts($v, $p, $texts, $locale);
            }
            return;
        }
        if (is_string($node)) {
            $text = trim($node);
            if ($text !== '' && self::script_path_translatable($path) && self::script_value_worth($text, $locale)) {
                $texts[] = $text;
            }
        }
    }

    /**
     * Replace translatable values in place.
     *
     * @return bool Whether anything changed.
     */
    private static function apply_script_translations(&$node, $path, $found, &$missing, $locale) {
        $changed = false;
        if (is_object($node)) {
            foreach (get_object_vars($node) as $k => $v) {
                $p   = $path;
                $p[] = $k;
                if (self::apply_script_translations($v, $p, $found, $missing, $locale)) {
                    $node->$k = $v;
                    $changed  = true;
                }
            }
            return $changed;
        }
        if (is_array($node)) {
            foreach ($node as $k => $v) {
                $p   = $path;
                $p[] = $k;
                if (self::apply_script_translations($v, $p, $found, $missing, $locale)) {
                    $node[$k] = $v;
                    $changed  = true;
                }
            }
            return $changed;
        }
        if (!is_string($node)) {
            return false;
        }
        $text = trim($node);
        if ($text === '' || !self::script_path_translatable($path) || !self::script_value_worth($text, $locale)) {
            return false;
        }
        $hash = md5($text);
        if (!isset($found[$hash])) {
            $alt = md5(self::decoded($text));
            if (isset($found[$alt])) {
                $found[$hash] = $found[$alt];
            }
        }
        if (!isset($found[$hash])) {
            $missing[$hash] = $text;
            return false;
        }
        // Keep markup only when the source had markup (the engines preserve it).
        $translation = strpos($text, '<') !== false ? (string) $found[$hash] : self::plain($found[$hash]);
        $lead        = substr($node, 0, strlen($node) - strlen(ltrim($node)));
        $trail       = substr($node, strlen(rtrim($node)));
        $node        = $lead . $translation . $trail;
        return true;
    }

    /** Whether a piece of text should be translated. */
    private static function worth($text, $locale) {
        if ($text === '' || mb_strlen($text) > 5000) {
            return false;
        }
        $plain = html_entity_decode($text, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        // Fragment of an attribute whose value contained ">" (the tokenizer
        // split the tag there): never touch it.
        if (preg_match('/^["\'}\]]|=\s*["\']|["\']\s*\/?>?$/', $text)) {
            return false;
        }
        if (!preg_match('/\p{L}{2}/u', $plain)) {
            return false; // numbers, prices, symbols, single letters
        }
        if (preg_match('#^(https?:)?//\S+$#i', $plain) || preg_match('/^[\w.+-]+@[\w-]+\.[\w.]+$/', $plain)) {
            return false; // URLs, e-mail addresses
        }
        // Already a translation produced by the filters in this request.
        return !Twtr_Resolver::is_emitted($locale, $text) && !Twtr_Resolver::is_emitted($locale, $plain);
    }

    /**
     * Ready translations for these hashes, from ANY context of the site: a
     * text translated as part of a title or a menu is reused here for free.
     *
     * @param string   $locale
     * @param string[] $hashes
     * @return array<string,string> hash => translation
     */
    private static function lookup($locale, $hashes) {
        global $wpdb;
        $out = array();
        foreach (array_chunk($hashes, 400) as $chunk) {
            $ph   = implode(',', array_fill(0, count($chunk), '%s'));
            $rows = $wpdb->get_results($wpdb->prepare(
                'SELECT source_hash, translated_text, locked FROM ' . Twtr_Storage::entries_table() .
                " WHERE blog_id = %d AND target_locale = %s AND status = 'ready' AND source_hash IN ({$ph})" .
                ' AND translated_text IS NOT NULL ORDER BY locked ASC',
                array_merge(array(get_current_blog_id(), $locale), $chunk)
            ));
            foreach ((array) $rows as $row) {
                // Manual overrides (locked) come last and win.
                $out[$row->source_hash] = (string) $row->translated_text;
            }
        }
        return $out;
    }

    /**
     * Queue the texts of this page that have no translation yet.
     *
     * @param string               $locale
     * @param array<string,string> $missing hash => text
     */
    private static function queue($locale, $missing) {
        // Search results, feeds and 404s echo whatever a visitor or a bot
        // typed (spam queries): never queue them for paid translation.
        if (is_search() || is_feed() || is_404()) {
            return;
        }
        $items = array();
        foreach (array_slice($missing, 0, self::MAX_NEW_PER_PAGE, true) as $hash => $text) {
            $items[] = array('context' => self::CONTEXT, 'hash' => $hash, 'source' => $text, 'locale' => $locale);
        }
        if (!$items) {
            return;
        }
        if (is_singular()) {
            self::remember_for_post((int) get_queried_object_id(), $locale, array_keys($missing));
        }
        // Do not let the page cache keep this half-translated version: the
        // next visitor gets the texts as soon as they are translated.
        do_action('litespeed_control_set_nocache', 'tW Translate Plus: translation in progress');
        $new = Twtr_Storage::insert_pending($items);
        if ($new > 0) {
            twtr_queue();
            Twtr_Queue::schedule();
        }
    }

    /**
     * Hashes of a post's page-level texts, so «Traduci adesso» can translate
     * them first.
     */
    private static function remember_for_post($post_id, $locale, $hashes) {
        if ($post_id > 0) {
            set_transient('twtr_html_' . $post_id . '_' . $locale, array_slice($hashes, 0, 1000), DAY_IN_SECONDS);
        }
    }

    /**
     * @param int    $post_id
     * @param string $locale
     * @return string[] Page-level hashes discovered on the post's page.
     */
    public static function hashes_for_post($post_id, $locale) {
        $h = get_transient('twtr_html_' . (int) $post_id . '_' . $locale);
        return is_array($h) ? $h : array();
    }

    /** Text with HTML entities decoded (lookup key independent of their spelling). */
    public static function decoded($text) {
        return html_entity_decode((string) $text, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    }

    /** A stored translation as safe text for a text node. */
    private static function as_text($translation) {
        return esc_html(self::plain($translation));
    }

    private static function plain($translation) {
        return html_entity_decode(wp_strip_all_tags((string) $translation), ENT_QUOTES | ENT_HTML5, 'UTF-8');
    }
}
