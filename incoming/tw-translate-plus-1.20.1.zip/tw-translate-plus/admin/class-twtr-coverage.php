<?php
/**
 * Real coverage check: what visitors actually read.
 *
 * The progress bar of the Lingue tab counts the strings the plugin knows
 * about. Texts it never sees (printed by a script after the page loads,
 * hard-coded in a theme's JavaScript, inside an iframe…) are invisible to
 * that number, so a language can show 100% while the page still shows
 * Italian.
 *
 * This check measures the rendered pages instead. In the admin, the
 * browser opens every page twice in a hidden frame — default language and
 * translated language — lets its scripts run, reads every visible text
 * (plus placeholder, title, alt, aria-label, button values) and reports
 * the texts that are still identical to the default language. The work
 * happens in the administrator's browser: no headless browser on the
 * server, no external service, no cost.
 *
 * Stored: the last report (option twtr_coverage_report, not autoloaded)
 * and the texts marked as "same in every language" (twtr_coverage_ignore).
 *
 * @package tw-translate-plus
 */

if (!defined('ABSPATH')) {
    exit;
}

class Twtr_Coverage {

    const REPORT_OPTION = 'twtr_coverage_report';
    const IGNORE_OPTION = 'twtr_coverage_ignore';
    const MAX_PAGES     = 60;
    const MAX_TEXTS     = 60;   // untranslated texts stored per page
    const MAX_IGNORED   = 1000;

    public static function init() {
        add_action('wp_ajax_twtr_coverage_save', array(__CLASS__, 'ajax_save'));
        add_action('wp_ajax_twtr_coverage_ignore', array(__CLASS__, 'ajax_ignore'));
    }

    /**
     * Pages to check: home, published pages, latest posts and products.
     *
     * @return array<int,array{title:string,url:string,urls:array<string,string>}>
     */
    public static function pages() {
        $languages = Twtr_Settings::extra_languages();
        $items     = array();
        $seen      = array();
        $add       = function ($title, $url) use (&$items, &$seen, $languages) {
            $url = (string) $url;
            if ($url === '' || isset($seen[$url]) || count($items) >= self::MAX_PAGES) {
                return;
            }
            $seen[$url] = true;
            $urls       = array();
            foreach ($languages as $slug) {
                $urls[$slug] = Twtr_Router::language_url($slug, $url);
            }
            $items[] = array('title' => wp_strip_all_tags((string) $title), 'url' => $url, 'urls' => $urls);
        };

        $add(__('Pagina iniziale', 'tw-translate-plus'), home_url('/'));
        $groups = array(
            array('post_type' => 'page', 'posts_per_page' => 40, 'orderby' => 'menu_order title', 'order' => 'ASC'),
            array('post_type' => 'post', 'posts_per_page' => 10),
        );
        if (post_type_exists('product')) {
            $groups[] = array('post_type' => 'product', 'posts_per_page' => 10);
        }
        foreach ($groups as $args) {
            $posts = get_posts(array_merge(array(
                'post_status'      => 'publish',
                'has_password'     => false,
                'suppress_filters' => true,
                'no_found_rows'    => true,
            ), $args));
            foreach ($posts as $post) {
                $add(get_the_title($post), get_permalink($post));
            }
        }
        return (array) apply_filters('twtr_coverage_pages', $items);
    }

    /** @return array Last saved report (empty array if none). */
    public static function report() {
        $report = get_option(self::REPORT_OPTION, array());
        return is_array($report) ? $report : array();
    }

    /** @return string[] Texts marked as identical in every language. */
    public static function ignored() {
        $list = get_option(self::IGNORE_OPTION, array());
        return is_array($list) ? array_values($list) : array();
    }

    /**
     * Texts that are expected to stay the same: site name, texts the
     * engine translated to themselves, glossary terms kept untranslated,
     * language names of the switcher, ignored texts.
     *
     * @return string[]
     */
    public static function expected_same() {
        $same = array(get_bloginfo('name'));
        foreach (Twtr_Settings::catalog() as $info) {
            $same[] = $info['label'];
        }
        // Texts the engine itself left unchanged ("Home", "Menu", "Privacy",
        // "Email" read the same in Italian and English): not forgotten.
        global $wpdb;
        $identical = $wpdb->get_col($wpdb->prepare(
            'SELECT DISTINCT source_text FROM ' . Twtr_Storage::entries_table() .
            " WHERE blog_id = %d AND status = 'ready' AND translated_text = source_text AND CHAR_LENGTH(source_text) < 200 LIMIT 2000",
            get_current_blog_id()
        ));
        $same = array_merge($same, array_map('strval', (array) $identical));

        // Glossary terms kept as they are (brands, product names).
        require_once TWTR_DIR . 'includes/class-twtr-glossary.php';
        foreach (Twtr_Glossary::all() as $term) {
            $source       = (string) $term->source_text;
            $translations = json_decode((string) $term->translations, true);
            if (!is_array($translations) || !$translations || in_array(mb_strtolower($source), array_map('mb_strtolower', array_map('strval', $translations)), true)) {
                $same[] = $source;
            }
        }
        return array_values(array_unique(array_filter(array_merge($same, self::ignored()))));
    }

    /**
     * Summary of one language from the last report, for the Lingue tab.
     *
     * @param string $slug
     * @return array{percent:int,pages:int,untranslated:int,at:int}|null
     */
    public static function language_summary($slug) {
        $report = self::report();
        if (empty($report['languages'][$slug])) {
            return null;
        }
        $lang = $report['languages'][$slug];
        return array(
            'percent'      => (int) $lang['percent'],
            'pages'        => (int) $lang['pages'],
            'untranslated' => (int) $lang['untranslated'],
            'at'           => (int) $report['at'],
        );
    }

    /** Data for the browser scan (admin.js). */
    public static function script_data() {
        $languages = array();
        $catalog   = Twtr_Settings::catalog();
        foreach (Twtr_Settings::extra_languages() as $slug) {
            $languages[] = array('slug' => $slug, 'label' => isset($catalog[$slug]) ? $catalog[$slug]['label'] : $slug);
        }
        return array(
            'pages'     => self::pages(),
            'languages' => $languages,
            'same'      => self::expected_same(),
            'i18n'      => array(
                'progress'   => __('Pagina %1$d di %2$d: %3$s (%4$s)…', 'tw-translate-plus'),
                'done'       => __('Verifica completata.', 'tw-translate-plus'),
                'blocked'    => __('Pagina letta senza eseguire JavaScript: il sito non si lascia aprire in un riquadro.', 'tw-translate-plus'),
                'failed'     => __('Pagina non raggiungibile.', 'tw-translate-plus'),
                'ignore'     => __('Uguale in tutte le lingue', 'tw-translate-plus'),
                'ignored'    => __('Ignorato nelle prossime verifiche', 'tw-translate-plus'),
                'none'       => __('Nessun testo rimasto in lingua originale.', 'tw-translate-plus'),
                'open'       => __('Apri', 'tw-translate-plus'),
                'stop'       => __('Interrompi', 'tw-translate-plus'),
                'start'      => __('Verifica le pagine', 'tw-translate-plus'),
            ),
        );
    }

    /* ------------------------------------------------------------------ AJAX */

    private static function guard() {
        check_ajax_referer('twtr_admin');
        if (!current_user_can(Twtr_Admin::CAP)) {
            wp_send_json_error(array('message' => __('Permessi insufficienti.', 'tw-translate-plus')), 403);
        }
    }

    /**
     * Save the report built by the browser (sanitized and size-capped).
     */
    public static function ajax_save() {
        self::guard();
        $raw  = isset($_POST['report']) ? wp_unslash($_POST['report']) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
        $data = is_string($raw) && strlen($raw) < 2 * MB_IN_BYTES ? json_decode($raw, true) : null;
        if (!is_array($data) || empty($data['languages']) || !is_array($data['languages'])) {
            wp_send_json_error(array('message' => __('Rapporto non valido.', 'tw-translate-plus')), 400);
        }
        $allowed = array_flip(Twtr_Settings::extra_languages());
        $home    = (string) wp_parse_url(home_url(), PHP_URL_HOST);
        $report  = array('at' => time(), 'languages' => array());

        foreach ($data['languages'] as $slug => $lang) {
            $slug = sanitize_key($slug);
            if (!isset($allowed[$slug]) || !is_array($lang) || empty($lang['pages']) || !is_array($lang['pages'])) {
                continue;
            }
            $pages = array();
            $total = 0;
            $bad   = 0;
            foreach (array_slice($lang['pages'], 0, self::MAX_PAGES) as $page) {
                $url = isset($page['url']) ? esc_url_raw((string) $page['url']) : '';
                if ($url === '' || strcasecmp((string) wp_parse_url($url, PHP_URL_HOST), $home) !== 0) {
                    continue; // only this site's pages
                }
                $texts = array();
                foreach (array_slice((array) ($page['untranslated'] ?? array()), 0, self::MAX_TEXTS) as $text) {
                    $text = sanitize_text_field(mb_substr((string) $text, 0, 300));
                    if ($text !== '') {
                        $texts[] = $text;
                    }
                }
                $page_total = max(0, (int) ($page['total'] ?? 0));
                $page_bad   = max(count($texts), (int) ($page['count'] ?? 0));
                $total     += $page_total;
                $bad       += min($page_bad, $page_total);
                $pages[]    = array(
                    'title'        => sanitize_text_field(mb_substr((string) ($page['title'] ?? ''), 0, 200)),
                    'url'          => $url,
                    'total'        => $page_total,
                    'count'        => $page_bad,
                    'untranslated' => $texts,
                    'nojs'         => !empty($page['nojs']),
                    'error'        => !empty($page['error']),
                );
            }
            if (!$pages) {
                continue;
            }
            $report['languages'][$slug] = array(
                'percent'      => $total > 0 ? (int) floor(100 * ($total - $bad) / $total) : 100,
                'pages'        => count($pages),
                'untranslated' => $bad,
                'list'         => $pages,
            );
        }
        if (!$report['languages']) {
            wp_send_json_error(array('message' => __('Rapporto non valido.', 'tw-translate-plus')), 400);
        }
        update_option(self::REPORT_OPTION, $report, false);
        wp_send_json_success(array('report' => $report));
    }

    /**
     * Mark a text as identical in every language (brand, product code…).
     */
    public static function ajax_ignore() {
        self::guard();
        $text = isset($_POST['text']) ? sanitize_text_field(mb_substr(wp_unslash((string) $_POST['text']), 0, 300)) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
        if ($text === '') {
            wp_send_json_error(array('message' => __('Testo non valido.', 'tw-translate-plus')), 400);
        }
        $list = self::ignored();
        if (!in_array($text, $list, true)) {
            $list[] = $text;
            $list   = array_slice($list, -self::MAX_IGNORED);
            update_option(self::IGNORE_OPTION, $list, false);
        }
        // Drop it from the stored report as well.
        $report = self::report();
        if (!empty($report['languages'])) {
            foreach ($report['languages'] as $slug => $lang) {
                foreach ($lang['list'] as $i => $page) {
                    $before = count($page['untranslated']);
                    $page['untranslated'] = array_values(array_diff($page['untranslated'], array($text)));
                    $removed = $before - count($page['untranslated']);
                    $page['count'] = max(0, (int) $page['count'] - $removed);
                    $report['languages'][$slug]['list'][$i] = $page;
                    $report['languages'][$slug]['untranslated'] = max(0, (int) $report['languages'][$slug]['untranslated'] - $removed);
                }
                $total = 0;
                foreach ($report['languages'][$slug]['list'] as $page) {
                    $total += (int) $page['total'];
                }
                $bad = (int) $report['languages'][$slug]['untranslated'];
                $report['languages'][$slug]['percent'] = $total > 0 ? (int) floor(100 * ($total - $bad) / $total) : 100;
            }
            update_option(self::REPORT_OPTION, $report, false);
        }
        wp_send_json_success(array('message' => __('Ignorato nelle prossime verifiche', 'tw-translate-plus')));
    }
}
