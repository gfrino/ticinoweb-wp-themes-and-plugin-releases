/* global twtrAdmin, jQuery */
/**
 * tW Translate Plus — admin interactions.
 * Inline translation editing, queue actions, connection test, glossary table.
 */
(function ($) {
    'use strict';

    function post(action, data) {
        return $.post(twtrAdmin.ajaxUrl, $.extend({
            action: action,
            _ajax_nonce: twtrAdmin.nonce
        }, data));
    }

    function feedback($el, message, ok) {
        $el.text(message)
            .removeClass('twtr-feedback-ok twtr-feedback-error')
            .addClass(ok ? 'twtr-feedback-ok' : 'twtr-feedback-error');
    }

    /* ------------------------------------------------ Translations: inline edit */

    $(document).on('click keydown', '.twtr-entries .twtr-view', function (e) {
        if (e.type === 'keydown' && e.key !== 'Enter' && e.key !== ' ') {
            return;
        }
        e.preventDefault();
        var $cell = $(this).closest('.twtr-target');
        $cell.find('.twtr-view').prop('hidden', true);
        $cell.find('.twtr-editor').prop('hidden', false).find('textarea').trigger('focus');
    });

    $(document).on('click', '.twtr-cancel', function () {
        var $cell = $(this).closest('.twtr-target');
        $cell.find('.twtr-editor').prop('hidden', true);
        $cell.find('.twtr-view').prop('hidden', false);
    });

    $(document).on('click', '.twtr-save', function () {
        var $btn = $(this),
            $row = $btn.closest('tr'),
            $cell = $btn.closest('.twtr-target'),
            text = $cell.find('textarea').val();

        $btn.prop('disabled', true).text(twtrAdmin.i18n.working);
        post('twtr_save_entry', { entry_id: $row.data('entry'), text: text })
            .done(function (res) {
                if (res && res.success) {
                    window.location.reload();
                } else {
                    window.alert((res && res.data && res.data.message) || twtrAdmin.i18n.error);
                    $btn.prop('disabled', false).text(twtrAdmin.i18n.saved);
                }
            })
            .fail(function () {
                window.alert(twtrAdmin.i18n.error);
                $btn.prop('disabled', false);
            });
    });

    $(document).on('click', '.twtr-restore', function () {
        var $row = $(this).closest('tr');
        post('twtr_restore_google', { entry_id: $row.data('entry') }).done(function (res) {
            if (res && res.success) {
                window.location.reload();
            } else {
                window.alert((res && res.data && res.data.message) || twtrAdmin.i18n.error);
            }
        });
    });

    $(document).on('click', '.twtr-recover', function () {
        var $cell = $(this).closest('.twtr-target');
        post('twtr_recover_previous', { entry_id: $(this).closest('tr').data('entry') }).done(function (res) {
            if (res && res.success && res.data.text) {
                $cell.find('textarea').val(res.data.text).trigger('focus');
            } else {
                window.alert((res && res.data && res.data.message) || twtrAdmin.i18n.error);
            }
        });
    });

    /* ------------------------------------------------------------- Status tab */

    $('#twtr-process-now').on('click', function () {
        var $btn = $(this), $fb = $('#twtr-status-feedback');
        $btn.prop('disabled', true);
        feedback($fb, twtrAdmin.i18n.working, true);
        post('twtr_process_now', {})
            .done(function (res) {
                feedback($fb, res && res.data ? res.data.message : twtrAdmin.i18n.error, res && res.success);
            })
            .fail(function () { feedback($fb, twtrAdmin.i18n.error, false); })
            .always(function () { $btn.prop('disabled', false); });
    });

    $('#twtr-index-site').on('click', function () {
        var $btn = $(this), $fb = $('#twtr-index-feedback'), scanned = 0, queued = 0;
        $btn.prop('disabled', true);
        feedback($fb, twtrAdmin.i18n.working, true);
        function stop(message, ok) {
            feedback($fb, message, ok);
            $btn.prop('disabled', false);
        }
        function step(phase, offset) {
            post('twtr_index_site', { phase: phase, offset: offset })
                .done(function (res) {
                    if (!res || !res.success || !res.data) {
                        stop(res && res.data && res.data.message ? res.data.message : twtrAdmin.i18n.error, false);
                        return;
                    }
                    scanned += res.data.scanned || 0;
                    queued  += res.data.queued || 0;
                    if (res.data.done) {
                        stop(twtrAdmin.i18n.indexDone.replace('%1$d', scanned).replace('%2$d', queued), true);
                        return;
                    }
                    feedback($fb, twtrAdmin.i18n.indexProgress.replace('%1$d', scanned).replace('%2$d', res.data.total), true);
                    step(res.data.phase, res.data.offset);
                })
                .fail(function () { stop(twtrAdmin.i18n.error, false); });
        }
        step('posts', 0);
    });

    $('#twtr-retry-errors').on('click', function () {
        var $fb = $('#twtr-status-feedback');
        feedback($fb, twtrAdmin.i18n.working, true);
        post('twtr_retry_errors', {}).done(function (res) {
            feedback($fb, res && res.data ? res.data.message : twtrAdmin.i18n.error, res && res.success);
        });
    });

    /* --------------------------------------------- Lingue: copy shortcodes */

    $(document).on('click', '.twtr-copy', function () {
        var $btn = $(this), text = $btn.data('copy'), done = function () {
            var label = $btn.text();
            $btn.text('✓');
            setTimeout(function () { $btn.text(label); }, 1200);
        };
        if (navigator.clipboard && window.isSecureContext) {
            navigator.clipboard.writeText(text).then(done);
        } else {
            var $tmp = $('<textarea>').val(text).appendTo('body').select();
            document.execCommand('copy');
            $tmp.remove();
            done();
        }
    });

    /* ------------------------------------------------------- Network: Google */

    /* Show only the settings of the selected translation engine. The other
       engine's fields stay in the DOM (and are still submitted, so saved
       credentials survive a switch), they are only hidden. */
    $('#twtr_provider').on('change', function () {
        var provider = $(this).val();
        $('.twtr-provider-panel').each(function () {
            $(this).prop('hidden', $(this).data('provider') !== provider);
        });
    });

    /* Refill the model dropdown from the account behind the saved API key.
       The current selection is preserved when the refreshed list still
       contains it, so a refresh never silently switches engine model. */
    $('#twtr-fetch-models').on('click', function () {
        var $btn = $(this),
            $fb = $('#twtr-models-feedback'),
            $select = $('#twtr_openai_model');

        $btn.prop('disabled', true);
        feedback($fb, twtrAdmin.i18n.working, true);
        post('twtr_fetch_openai_models', {})
            .done(function (res) {
                if (!res || !res.success || !res.data || !res.data.models) {
                    feedback($fb, res && res.data ? res.data.message : twtrAdmin.i18n.error, false);
                    return;
                }
                var previous = $select.val();
                $select.empty();
                $.each(res.data.models, function (i, model) {
                    $select.append($('<option></option>').attr('value', model).text(model));
                });
                $select.val($.inArray(previous, res.data.models) !== -1 ? previous : res.data.selected);
                feedback($fb, res.data.message, true);
            })
            .fail(function () { feedback($fb, twtrAdmin.i18n.error, false); })
            .always(function () { $btn.prop('disabled', false); });
    });

    $('#twtr-test-connection').on('click', function () {
        var $btn = $(this), $fb = $('#twtr-test-feedback');
        $btn.prop('disabled', true);
        feedback($fb, twtrAdmin.i18n.working, true);
        post('twtr_test_connection', {})
            .done(function (res) {
                feedback($fb, res && res.data ? res.data.message : twtrAdmin.i18n.error, res && res.success);
            })
            .fail(function () { feedback($fb, twtrAdmin.i18n.error, false); })
            .always(function () { $btn.prop('disabled', false); });
    });

    /* ----------------------------------------------------- Network: glossary */

    $(document).on('click', '.twtr-glossary .twtr-g-save', function () {
        var $row = $(this).closest('tr'),
            $fb = $('#twtr-glossary-feedback'),
            translations = {};

        $row.find('.twtr-g-lang').each(function () {
            translations[$(this).data('lang')] = $(this).val();
        });
        feedback($fb, twtrAdmin.i18n.working, true);
        post('twtr_save_glossary_term', {
            source: $row.find('.twtr-g-source').val(),
            active: $row.find('.twtr-g-active').is(':checked') ? 1 : '',
            translations: translations
        }).done(function (res) {
            if (res && res.success) {
                window.location.reload();
            } else {
                feedback($fb, (res && res.data && res.data.message) || twtrAdmin.i18n.error, false);
            }
        });
    });

    $(document).on('click', '.twtr-glossary .twtr-g-delete', function () {
        if (!window.confirm('Eliminare definitivamente questo termine?')) {
            return;
        }
        var $row = $(this).closest('tr');
        post('twtr_delete_glossary_term', { term_id: $row.data('term') }).done(function () {
            $row.remove();
        });
    });

    $('#twtr-glossary-sync').on('click', function () {
        var $btn = $(this), $fb = $('#twtr-glossary-feedback');
        $btn.prop('disabled', true);
        feedback($fb, twtrAdmin.i18n.working, true);
        post('twtr_glossary_sync', {})
            .done(function (res) {
                feedback($fb, res && res.data ? res.data.message : twtrAdmin.i18n.error, res && res.success);
            })
            .always(function () { $btn.prop('disabled', false); });
    });
    /* ------------------------------------- Stato: real coverage of the pages */

    /*
     * Each page is opened twice in a hidden same-origin frame (default and
     * translated language). After its scripts settle, every text the visitor
     * reads is collected; texts of the translated page that are identical to
     * the default page are the ones nobody translated. Language-agnostic:
     * no language detection, no external service.
     */
    var Coverage = (function () {
        var SKIP = 'script,style,noscript,template,svg,code,pre,textarea,#wpadminbar,[translate="no"],.notranslate,[hreflang],[class*="twtr-ls"],[class*="wpml-ls"]';
        var ATTRS = ['placeholder', 'title', 'alt', 'aria-label'];

        function normalize(text) {
            return String(text || '').replace(/\s+/g, ' ').trim();
        }

        function meaningful(text) {
            if (text.length < 2 || text.length > 600) { return false; }
            if (!/\p{L}{2}/u.test(text)) { return false; }
            if (/^(https?:)?\/\/\S+$/i.test(text) || /^[\w.+-]+@[\w-]+\.[\w.]+$/.test(text)) { return false; }
            // Acronyms, codes and amounts only (EBITDA, CHF 1'000, CHE-123.456.789).
            if (!/\p{Ll}/u.test(text)) { return false; }
            return true;
        }

        function collect(doc) {
            var found = {};
            var body = doc && doc.body;
            if (!body) { return found; }
            var walker = doc.createTreeWalker(body, 4 /* NodeFilter.SHOW_TEXT */);
            var node;
            while ((node = walker.nextNode())) {
                var parent = node.parentElement;
                if (!parent || parent.closest(SKIP)) { continue; }
                var text = normalize(node.nodeValue);
                if (meaningful(text)) { found[text] = true; }
            }
            body.querySelectorAll('[placeholder],[title],[alt],[aria-label],input[type="submit"],input[type="button"]').forEach(function (el) {
                if (el.closest(SKIP)) { return; }
                ATTRS.forEach(function (name) {
                    var value = normalize(el.getAttribute(name));
                    if (value && meaningful(value)) { found[value] = true; }
                });
                if (el.matches('input[type="submit"],input[type="button"]')) {
                    var v = normalize(el.value);
                    if (meaningful(v)) { found[v] = true; }
                }
            });
            return found;
        }

        /** Wait until the page stops changing (scripts rendered), max ~6 s. */
        function settle(doc) {
            return new Promise(function (resolve) {
                var quiet, hard, observer;
                function finish() {
                    clearTimeout(quiet); clearTimeout(hard);
                    if (observer) { observer.disconnect(); }
                    resolve();
                }
                function arm() { clearTimeout(quiet); quiet = setTimeout(finish, 700); }
                try {
                    observer = new MutationObserver(arm);
                    observer.observe(doc.documentElement, { childList: true, subtree: true, characterData: true });
                } catch (e) { /* no observer: rely on timers */ }
                arm();
                hard = setTimeout(finish, 6000);
            });
        }

        function viaFetch(url) {
            return fetch(url, { credentials: 'same-origin' }).then(function (r) {
                if (!r.ok) { throw new Error('http ' + r.status); }
                return r.text();
            }).then(function (html) {
                return { texts: collect(new DOMParser().parseFromString(html, 'text/html')), nojs: true };
            });
        }

        function viaFrame(url, $holder) {
            return new Promise(function (resolve, reject) {
                var frame = document.createElement('iframe');
                var timer = setTimeout(function () { cleanup(); reject(new Error('timeout')); }, 25000);
                function cleanup() { clearTimeout(timer); frame.remove(); }
                // Scripts run and the frame stays readable (same origin), but
                // the page can neither navigate the admin nor open pop-ups.
                frame.setAttribute('sandbox', 'allow-scripts allow-same-origin');
                frame.setAttribute('tabindex', '-1');
                frame.addEventListener('load', function () {
                    var doc;
                    try { doc = frame.contentDocument; } catch (e) { doc = null; }
                    if (!doc || !doc.body || doc.location.href === 'about:blank') {
                        cleanup(); reject(new Error('blocked')); return;
                    }
                    settle(doc).then(function () {
                        var texts = collect(doc);
                        cleanup();
                        resolve({ texts: texts, nojs: false });
                    });
                });
                frame.src = url;
                $holder.append(frame);
            });
        }

        function read(url, $holder) {
            return viaFrame(url, $holder).catch(function () { return viaFetch(url); });
        }

        function run(data, $fb, $btn) {
            var same = {};
            (data.same || []).forEach(function (t) { same[normalize(t)] = true; });
            var $holder = $('#twtr-coverage-frame');
            var report = { languages: {} };
            var stopped = false;
            var total = data.pages.length * data.languages.length;
            var done = 0;
            $btn.text(data.i18n.stop).off('click.twtrrun').on('click.twtrstop', function () {
                stopped = true;
                $btn.prop('disabled', true);
            });
            data.languages.forEach(function (l) { report.languages[l.slug] = { pages: [] }; });

            var chain = Promise.resolve();
            data.pages.forEach(function (page) {
                chain = chain.then(function () {
                    if (stopped) { return; }
                    return read(page.url, $holder).then(function (base) {
                        var langChain = Promise.resolve();
                        data.languages.forEach(function (lang) {
                            langChain = langChain.then(function () {
                                if (stopped) { return; }
                                done++;
                                feedback($fb, data.i18n.progress.replace('%1$d', done).replace('%2$d', total).replace('%3$s', page.title).replace('%4$s', lang.label), true);
                                var url = page.urls[lang.slug];
                                return read(url, $holder).then(function (res) {
                                    var keys = Object.keys(res.texts);
                                    var left = keys.filter(function (t) { return base.texts[t] && !same[t]; });
                                    report.languages[lang.slug].pages.push({
                                        title: page.title, url: url, total: keys.length,
                                        count: left.length, untranslated: left.slice(0, 60),
                                        nojs: res.nojs || base.nojs
                                    });
                                }).catch(function () {
                                    report.languages[lang.slug].pages.push({ title: page.title, url: url, total: 0, count: 0, untranslated: [], error: true });
                                });
                            });
                        });
                        return langChain;
                    }).catch(function () {
                        done += data.languages.length;
                    });
                });
            });

            return chain.then(function () {
                $btn.off('click.twtrstop');
                return post('twtr_coverage_save', { report: JSON.stringify(report) });
            }).then(function (res) {
                if (res && res.success) {
                    feedback($fb, data.i18n.done, true);
                    window.location.hash = 'twtr-coverage';
                    window.location.reload();
                } else {
                    feedback($fb, (res && res.data && res.data.message) || twtrAdmin.i18n.error, false);
                    $btn.prop('disabled', false).text(data.i18n.start);
                }
            }, function () {
                feedback($fb, twtrAdmin.i18n.error, false);
                $btn.prop('disabled', false).text(data.i18n.start);
            });
        }

        return { run: run, collect: collect, meaningful: meaningful };
    }());

    function startCoverage() {
        var data = twtrAdmin.coverage, $btn = $(this);
        if (!data || !data.pages || !data.pages.length || !data.languages.length) { return; }
        Coverage.run(data, $('#twtr-coverage-feedback'), $btn).then(function () {
            // Still on the page (save failed): allow a new run.
            $btn.off('click.twtrstop click.twtrrun').on('click.twtrrun', startCoverage).prop('disabled', false);
        });
    }
    $('#twtr-coverage-run').on('click.twtrrun', startCoverage);

    $(document).on('click', '.twtr-coverage-ignore', function () {
        var $btn = $(this), $li = $btn.closest('li');
        $btn.prop('disabled', true);
        post('twtr_coverage_ignore', { text: String($btn.data('text')) }).done(function (res) {
            if (res && res.success) {
                $li.addClass('is-ignored');
                $btn.replaceWith($('<em/>').text(res.data.message));
            } else {
                $btn.prop('disabled', false);
            }
        });
    });

})(jQuery);

/* WPML migration: run the import step by step with a progress bar. */
(function ($) {
    'use strict';
    if (typeof twtrAdmin === 'undefined') {
        return;
    }
    var i18n = twtrAdmin.i18n || {};
    var steps = ['configure', 'posts', 'terms', 'media', 'strings', 'redirects'];

    function fmt(str) {
        var args = Array.prototype.slice.call(arguments, 1);
        return String(str).replace(/%(\d+)\$[sd]/g, function (m, n) { return args[n - 1]; });
    }

    function call(data) {
        return $.post(twtrAdmin.ajaxUrl, $.extend({ _ajax_nonce: twtrAdmin.nonce }, data));
    }

    $(document).on('click', '#twtr-wpml-start', function () {
        if (!window.confirm(i18n.wpmlConfirm)) {
            return;
        }
        var $btn = $(this).prop('disabled', true);
        var $box = $('#twtr-wpml-progress').prop('hidden', false);
        var $bar = $box.find('.twtr-bar span');
        var $status = $('#twtr-wpml-status');
        var s = 0;

        function run(offset) {
            var step = steps[s];
            call({ action: 'twtr_wpml_step', step: step, offset: offset }).done(function (res) {
                if (!res || !res.success) {
                    $status.text((res && res.data && res.data.message) || i18n.error);
                    $btn.prop('disabled', false);
                    return;
                }
                var d = res.data;
                var stepShare = 100 / steps.length;
                var inStep = d.total ? Math.min(1, d.next / d.total) : 1;
                $bar.css('width', Math.round(stepShare * (s + inStep)) + '%');
                $status.text(d.message || fmt(i18n.wpmlProgress, (i18n.wpmlSteps || {})[step] || step, Math.min(d.next, d.total), d.total));
                if (!d.done) {
                    run(d.next);
                    return;
                }
                if (d.report) {
                    $('#twtr-wpml-report').html(d.report);
                }
                if (d.imported) {
                    $('#twtr-wpml-imported').text(d.imported);
                }
                s++;
                if (s < steps.length) {
                    run(0);
                } else {
                    $bar.css('width', '100%');
                    $status.text(i18n.wpmlDone);
                    $btn.prop('disabled', false);
                }
            }).fail(function () {
                $status.text(i18n.error);
                $btn.prop('disabled', false);
            });
        }
        run(0);
    });

    $(document).on('click', '#twtr-wpml-undo', function () {
        if (!window.confirm(i18n.wpmlUndo)) {
            return;
        }
        var $btn = $(this).prop('disabled', true);
        call({ action: 'twtr_wpml_undo' }).done(function (res) {
            window.alert((res && res.data && res.data.message) || i18n.error);
            window.location.reload();
        }).fail(function () {
            window.alert(i18n.error);
            $btn.prop('disabled', false);
        });
    });

})(jQuery);
