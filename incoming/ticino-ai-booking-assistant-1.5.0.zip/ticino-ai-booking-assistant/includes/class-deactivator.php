<?php

/**
 * Fired during plugin deactivation
 */
class Ticino_AI_Booking_Deactivator {

	public static function deactivate() {
        // La pulizia dei dati (tabelle e opzioni) non avviene qui per non perdere 
        // dati involontariamente se il plugin viene solo disattivato temporaneamente.
        // Se si vuole pulire tutto alla disinstallazione, andrebbe fatto in un file uninstall.php
        wp_clear_scheduled_hook( 'ticino_ai_pdf_sync' );
	}

}
