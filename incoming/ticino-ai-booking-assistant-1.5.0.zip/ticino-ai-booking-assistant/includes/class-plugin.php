<?php
/**
 * Logica principale del plugin e orchestrazione delle classi.
 */

class Ticino_AI_Booking_Plugin {

	protected $plugin_name;
	protected $version;

	public function __construct() {
		$this->plugin_name = 'ticino-ai-booking';
		$this->version = TICINO_AI_BOOKING_VERSION;

		$this->load_dependencies();
		$this->set_locale();
		$this->define_admin_hooks();
		$this->define_public_hooks();
	}

	private function load_dependencies() {
		require_once TICINO_AI_BOOKING_PLUGIN_DIR . 'includes/class-admin.php';
		require_once TICINO_AI_BOOKING_PLUGIN_DIR . 'includes/class-knowledge-base.php';
		require_once TICINO_AI_BOOKING_PLUGIN_DIR . 'includes/class-pdf-knowledge.php';
		require_once TICINO_AI_BOOKING_PLUGIN_DIR . 'includes/class-chatbot.php';
		require_once TICINO_AI_BOOKING_PLUGIN_DIR . 'includes/class-appointments.php';
		require_once TICINO_AI_BOOKING_PLUGIN_DIR . 'includes/class-email.php';
		require_once TICINO_AI_BOOKING_PLUGIN_DIR . 'includes/class-caldav-client.php';
		require_once TICINO_AI_BOOKING_PLUGIN_DIR . 'includes/class-dynamic-site-knowledge.php';
		require_once TICINO_AI_BOOKING_PLUGIN_DIR . 'includes/class-openai-client.php';
		require_once TICINO_AI_BOOKING_PLUGIN_DIR . 'includes/class-gemini-client.php';
		require_once TICINO_AI_BOOKING_PLUGIN_DIR . 'includes/class-treatment-metabox.php';
	}

	private function set_locale() {
		add_action( 'plugins_loaded', array( $this, 'load_plugin_textdomain' ) );
	}
	
	public function load_plugin_textdomain() {
	    load_plugin_textdomain(
	        'ticino-ai-booking',
	        false,
	        dirname( dirname( plugin_basename( __FILE__ ) ) ) . '/languages/'
	    );
	}

	private function define_admin_hooks() {
		$plugin_admin = new Ticino_AI_Booking_Admin( $this->get_plugin_name(), $this->get_version() );
        $appointments = new Ticino_AI_Booking_Appointments();
        $knowledge_base = new Ticino_AI_Booking_Knowledge_Base();
        $treatment_metabox = new Ticino_AI_Booking_Treatment_Metabox( $this->get_plugin_name(), $this->get_version() );
        $treatment_metabox->init();

		add_action( 'admin_enqueue_scripts', array( $plugin_admin, 'enqueue_styles' ) );
		add_action( 'admin_enqueue_scripts', array( $plugin_admin, 'enqueue_scripts' ) );
		
		add_action( 'admin_menu', array( $plugin_admin, 'add_plugin_admin_menu' ) );
        add_action( 'admin_init', array( $plugin_admin, 'register_settings' ) );
        
        // Hooks per salvataggio e logica in background admin
        add_action( 'admin_post_ticino_ai_confirm_appointment', array( $appointments, 'handle_confirmation' ) );
        add_action( 'admin_post_ticino_ai_reject_appointment', array( $appointments, 'handle_rejection' ) );
        add_action( 'admin_post_ticino_ai_contact_appointment', array( $appointments, 'handle_mark_contacted' ) );
        add_action( 'admin_post_ticino_ai_delete_appointment', array( $appointments, 'handle_delete' ) );
        add_action( 'admin_init', array( $appointments, 'handle_get_delete' ) );
        
        // KB AJAX
        add_action( 'wp_ajax_ticino_ai_save_kb', array( $knowledge_base, 'ajax_save' ) );
        add_action( 'wp_ajax_ticino_ai_delete_kb', array( $knowledge_base, 'ajax_delete' ) );
        add_action( 'wp_ajax_ticino_ai_reindex_site', array( $knowledge_base, 'ajax_reindex_site' ) );

        // Documenti PDF nella Knowledge Base (1.4.0)
        $pdf_knowledge = new Ticino_AI_Booking_PDF_Knowledge();
        add_action( 'admin_init', array( 'Ticino_AI_Booking_PDF_Knowledge', 'maybe_upgrade' ) );
        add_action( 'wp_ajax_ticino_ai_pdf_add', array( $pdf_knowledge, 'ajax_add' ) );
        add_action( 'wp_ajax_ticino_ai_pdf_remove', array( $pdf_knowledge, 'ajax_remove' ) );
        add_action( 'wp_ajax_ticino_ai_pdf_search', array( $pdf_knowledge, 'ajax_search' ) );
        add_action( 'delete_attachment', array( 'Ticino_AI_Booking_PDF_Knowledge', 'on_delete_attachment' ) );
        add_action( 'wp_ajax_ticino_ai_pdf_sync', array( $pdf_knowledge, 'ajax_sync' ) );
        add_action( 'add_attachment', array( 'Ticino_AI_Booking_PDF_Knowledge', 'on_add_attachment' ) );
        add_action( 'admin_init', array( 'Ticino_AI_Booking_PDF_Knowledge', 'maybe_schedule_sync' ) );
        add_action( Ticino_AI_Booking_PDF_Knowledge::CRON_HOOK, array( 'Ticino_AI_Booking_PDF_Knowledge', 'cron_sync' ) );
	}

	private function define_public_hooks() {
		$plugin_public = new Ticino_AI_Booking_Chatbot( $this->get_plugin_name(), $this->get_version() );

		add_action( 'wp_enqueue_scripts', array( $plugin_public, 'enqueue_styles' ) );
		add_action( 'wp_enqueue_scripts', array( $plugin_public, 'enqueue_scripts' ) );
		
		add_action( 'wp_footer', array( $plugin_public, 'render_chatbot_html' ) );
		add_shortcode( 'ticino_ai_booking_chatbot', array( $plugin_public, 'shortcode_render_chatbot' ) );
		
		// REST API Hooks
		add_action( 'rest_api_init', array( $plugin_public, 'register_rest_routes' ) );
	}

	public function run() {
		// Eventuali inizializzazioni ritardate
	}

	public function get_plugin_name() {
		return $this->plugin_name;
	}

	public function get_version() {
		return $this->version;
	}

}
