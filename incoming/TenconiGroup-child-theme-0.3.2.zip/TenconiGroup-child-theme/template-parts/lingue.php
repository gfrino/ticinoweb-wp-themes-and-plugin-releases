<?php
/**
 * Selettore di lingua (tW Translate Plus), come sul sito Tenconi SA.
 *
 * La pastiglia con la sigla della lingua corrente apre l'elenco delle lingue.
 * E' un <details>: si apre e si chiude con il dito, il mouse e la tastiera
 * anche senza JavaScript; assets/js/lingue.js aggiunge solo la chiusura con un
 * clic fuori o con Esc. Le lingue e i loro indirizzi vengono dal plugin:
 * se il plugin non c'e' o c'e' una sola lingua, non si stampa nulla.
 *
 * @package tenconigroup
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$tg_langs = function_exists( 'twtr_get_languages' ) ? (array) twtr_get_languages() : array();
if ( count( $tg_langs ) < 2 ) {
	return;
}
$tg_cur = null;
foreach ( $tg_langs as $tg_l ) {
	if ( ! empty( $tg_l['is_current'] ) ) {
		$tg_cur = $tg_l;
		break;
	}
}
if ( ! $tg_cur ) {
	$tg_cur = reset( $tg_langs );
}
?>
<details class="tg-lingue" data-tg-lingue>
	<summary class="tg-lang" aria-label="<?php echo esc_attr( sprintf( /* translators: %s: lingua corrente. */ __( 'Lingua: %s. Scegli un’altra lingua', 'tenconigroup' ), $tg_cur['label'] ) ); ?>">
		<span aria-hidden="true"><?php echo esc_html( strtoupper( $tg_cur['slug'] ) ); ?></span>
		<i class="tg-lang__chev" aria-hidden="true"></i>
	</summary>
	<ul class="tg-lingue__lista">
		<?php foreach ( $tg_langs as $tg_l ) : ?>
			<?php $tg_is = ! empty( $tg_l['is_current'] ); ?>
			<li>
				<a class="tg-lingue__v<?php echo $tg_is ? ' is-current' : ''; ?>"
					href="<?php echo esc_url( $tg_l['url'] ); ?>"
					hreflang="<?php echo esc_attr( str_replace( '_', '-', (string) $tg_l['locale'] ) ); ?>"
					lang="<?php echo esc_attr( $tg_l['slug'] ); ?>"
					<?php echo $tg_is ? 'aria-current="true"' : ''; ?>>
					<span class="tg-lingue__et"><?php echo esc_html( $tg_l['label'] ); ?></span>
					<?php if ( $tg_is ) : ?>
						<svg class="tg-lingue__spunta" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="m5 12.5 4.5 4.5L19 7" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="square"/></svg>
					<?php endif; ?>
				</a>
			</li>
		<?php endforeach; ?>
	</ul>
</details>
