/*
 * Sfondi «mesh» della homepage (parte alta, sezione sotto i riquadri, piede):
 * per ognuno passa al CSS quanto la sua parte alta e' salita rispetto alla
 * finestra (--tg-s, in pixel) e il CSS sposta le quattro macchie a velocita'
 * diverse. Un solo aggiornamento per fotogramma, niente movimento con
 * «riduci movimento».
 */
( function () {
	var meshes = Array.prototype.slice.call( document.querySelectorAll( '[data-tg-mesh]' ) );
	if ( ! meshes.length || ( window.matchMedia && window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches ) ) {
		return;
	}
	var queued = false;
	function update() {
		queued = false;
		var h = window.innerHeight || 800;
		meshes.forEach( function ( m ) {
			var r = m.getBoundingClientRect();
			if ( r.bottom < -200 || r.top > h + 200 ) { return; }
			m.style.setProperty( '--tg-s', Math.round( Math.min( Math.max( -r.top, -900 ), 1400 ) ) );
		} );
	}
	function queue() {
		if ( ! queued ) {
			queued = true;
			window.requestAnimationFrame( update );
		}
	}
	window.addEventListener( 'scroll', queue, { passive: true } );
	window.addEventListener( 'resize', queue );
	update();
}() );
