/*
 * Selettore di lingua: chiude l'elenco con un clic fuori o con Esc.
 * Apertura e chiusura base le fa gia' <details>, anche senza questo file.
 */
( function () {
	var box = document.querySelector( '[data-tg-lingue]' );
	if ( ! box ) {
		return;
	}
	document.addEventListener( 'click', function ( e ) {
		if ( box.open && ! box.contains( e.target ) ) {
			box.open = false;
		}
	} );
	document.addEventListener( 'keydown', function ( e ) {
		if ( 'Escape' === e.key && box.open ) {
			box.open = false;
			box.querySelector( 'summary' ).focus();
		}
	} );
}() );
