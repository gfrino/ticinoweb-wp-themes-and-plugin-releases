<?php
/**
 * Pagina interna (es. «Storia»).
 *
 * In testa: nome del gruppo, titolo e, se la pagina ha un'immagine in evidenza,
 * la fotografia a destra, come le pagine interne del sito Tenconi SA. Sotto, il
 * contenuto scritto nell'editor di WordPress: i titoli (H2) aprono le sezioni a
 * tutta larghezza, i paragrafi stanno nella colonna di lettura, gallerie e
 * immagini larghe occupano tutta la colonna (vedi .tg-content in group.css).
 *
 * @package tenconigroup
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

$tg_label = tg_text( 'tg_hero_label' );

while ( have_posts() ) :
	the_post();
	$tg_has_img = has_post_thumbnail();
	?>
	<section class="tg-page-hd<?php echo $tg_has_img ? ' tg-page-hd--img' : ''; ?>" aria-labelledby="tg-page-title">
		<div class="tg-wrap tg-page-hd__in">
			<div class="tg-page-hd__txt">
				<?php if ( '' !== $tg_label ) : ?>
					<p class="tg-label"><?php echo esc_html( $tg_label ); ?></p>
				<?php endif; ?>
				<h1 id="tg-page-title" class="tg-page-hd__title"><?php the_title(); ?></h1>
				<?php if ( has_excerpt() ) : ?>
					<p class="tg-page-hd__text"><?php echo esc_html( get_the_excerpt() ); ?></p>
				<?php endif; ?>
			</div>
			<?php if ( $tg_has_img ) : ?>
				<figure class="tg-page-hd__fig">
					<?php
					the_post_thumbnail(
						'large',
						array(
							'class'         => 'tg-page-hd__img',
							'loading'       => 'eager',
							'fetchpriority' => 'high',
							'sizes'         => '(min-width: 1024px) 50vw, 100vw',
						)
					);
					?>
				</figure>
			<?php endif; ?>
		</div>
	</section>
	<div class="tg-wrap">
		<div class="tg-content"><?php the_content(); ?></div>
	</div>
	<?php
endwhile;

get_footer();
