<?php
/**
 * Footer: simbolo e nome a sinistra, sede al centro, collegamenti a destra.
 *
 * Come sul sito Tenconi SA: bianco, un solo filetto sopra, etichette in
 * maiuscoletto. L'indirizzo viene dai contatti del parent (ticinoWEB CMS →
 * Contatti), non da questo file.
 *
 * @package tenconigroup
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$tg_contact = function_exists( 'ticinoweb_get_contact_info' ) ? ticinoweb_get_contact_info() : array();
$tg_address = trim( (string) get_option( 'ticinoweb_contact_address', '' ) );
$tg_email   = isset( $tg_contact['email'] ) ? trim( (string) $tg_contact['email'] ) : '';
$tg_phone   = isset( $tg_contact['phone'] ) ? trim( (string) $tg_contact['phone'] ) : '';
$tg_privacy = function_exists( 'get_privacy_policy_url' ) ? get_privacy_policy_url() : '';
?>
</main>

<footer class="tg-fo">
	<?php
	if ( is_front_page() ) {
		tg_the_mesh( 'piede' ); // In homepage lo sfondo blu sfumato chiude anche il piede.
	}
	?>
	<div class="tg-wrap tg-fo__in">
		<div class="tg-fo__brand">
			<?php tg_the_symbol( 'tg-fo__symbol', 'thumbnail' ); ?>
			<p class="tg-fo__name"><?php bloginfo( 'name' ); ?></p>
		</div>

		<?php if ( '' !== $tg_address || '' !== $tg_email || '' !== $tg_phone ) : ?>
			<div class="tg-fo__col">
				<p class="tg-label"><?php esc_html_e( 'Sede', 'tenconigroup' ); ?></p>
				<?php if ( '' !== $tg_address ) : ?>
					<p class="tg-fo__text"><?php echo nl2br( esc_html( $tg_address ) ); ?></p>
				<?php endif; ?>
				<?php if ( '' !== $tg_phone ) : ?>
					<p class="tg-fo__text"><a href="<?php echo esc_url( 'tel:' . preg_replace( '/[^0-9+]/', '', $tg_phone ) ); ?>"><?php echo esc_html( $tg_phone ); ?></a></p>
				<?php endif; ?>
				<?php if ( '' !== $tg_email && is_email( $tg_email ) ) : ?>
					<p class="tg-fo__text"><a href="<?php echo esc_url( 'mailto:' . antispambot( $tg_email ) ); ?>"><?php echo esc_html( antispambot( $tg_email ) ); ?></a></p>
				<?php endif; ?>
			</div>
		<?php endif; ?>

		<div class="tg-fo__col tg-fo__col--nav">
			<?php if ( has_nav_menu( 'tg-principale' ) ) : ?>
				<nav aria-label="<?php esc_attr_e( 'Collegamenti nel piè di pagina', 'tenconigroup' ); ?>">
					<?php
					wp_nav_menu(
						array(
							'theme_location' => 'tg-principale',
							'container'      => false,
							'menu_class'     => 'tg-fo__nav',
							'depth'          => 1,
							'fallback_cb'    => false,
						)
					);
					?>
				</nav>
			<?php endif; ?>
			<?php if ( $tg_privacy ) : ?>
				<p class="tg-fo__text"><a href="<?php echo esc_url( $tg_privacy ); ?>"><?php esc_html_e( 'Protezione dei dati', 'tenconigroup' ); ?></a></p>
			<?php endif; ?>
			<p class="tg-fo__copy">&copy; <?php echo esc_html( wp_date( 'Y' ) ); ?> <?php bloginfo( 'name' ); ?></p>
		</div>
	</div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
