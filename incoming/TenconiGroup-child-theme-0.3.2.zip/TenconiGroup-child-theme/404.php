<?php
/**
 * Pagina non trovata: risponde 404 (il rinvio alla home del parent e' spento).
 *
 * @package tenconigroup
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
?>
<section class="tg-page-hd" aria-labelledby="tg-page-title">
	<div class="tg-wrap tg-page-hd__in">
		<p class="tg-label"><?php esc_html_e( 'Errore 404', 'tenconigroup' ); ?></p>
		<h1 id="tg-page-title" class="tg-page-hd__title"><?php esc_html_e( 'Pagina non trovata', 'tenconigroup' ); ?></h1>
		<p class="tg-page-hd__text"><?php esc_html_e( 'L’indirizzo non esiste o è stato spostato.', 'tenconigroup' ); ?></p>
	</div>
</section>
<div class="tg-wrap">
	<div class="tg-prose"><p><a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Torna alla pagina iniziale', 'tenconigroup' ); ?></a></p></div>
</div>
<?php
get_footer();
