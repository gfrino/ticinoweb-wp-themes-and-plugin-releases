<?php
/**
 * Header: logo a sinistra, una sola riga di navigazione a destra.
 *
 * Stesse misure del sito Tenconi SA (logo largo 249 px su desktop, voci in
 * maiuscolo 13/700 con tracking .12em, colonna di 1400 px). Con una sola voce
 * di menu non serve un menu a scomparsa: la voce resta visibile anche sul
 * telefono.
 *
 * @package tenconigroup
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="tg-skip" href="#contenuto"><?php esc_html_e( 'Vai al contenuto', 'tenconigroup' ); ?></a>

<header class="tg-hd">
	<div class="tg-wrap tg-hd__bar">
		<a class="tg-brand" href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
			<?php
			$tg_logo = function_exists( 'ticinoweb_get_site_logo' ) ? ticinoweb_get_site_logo() : false;
			if ( $tg_logo ) :
				$tg_dim = tg_logo_dimensions( $tg_logo );
				$tg_src = ( $tg_dim && '' !== $tg_dim[2] ) ? $tg_dim[2] : $tg_logo;
				?>
				<img class="tg-brand__logo" src="<?php echo esc_url( $tg_src ); ?>" alt="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>"<?php echo $tg_dim ? ' width="' . (int) $tg_dim[0] . '" height="' . (int) $tg_dim[1] . '"' : ''; ?> decoding="async" fetchpriority="high">
			<?php else : ?>
				<span class="tg-brand__name"><?php bloginfo( 'name' ); ?></span>
			<?php endif; ?>
		</a>

		<div class="tg-hd__right">
			<?php if ( has_nav_menu( 'tg-principale' ) ) : ?>
				<nav class="tg-nav" aria-label="<?php esc_attr_e( 'Navigazione principale', 'tenconigroup' ); ?>">
					<?php
					wp_nav_menu(
						array(
							'theme_location' => 'tg-principale',
							'container'      => false,
							'menu_class'     => 'tg-nav__list',
							'depth'          => 1,
							'fallback_cb'    => false,
						)
					);
					?>
				</nav>
			<?php endif; ?>
			<?php get_template_part( 'template-parts/lingue' ); ?>
		</div>
	</div>
</header>

<main id="contenuto" class="tg-main" tabindex="-1">
