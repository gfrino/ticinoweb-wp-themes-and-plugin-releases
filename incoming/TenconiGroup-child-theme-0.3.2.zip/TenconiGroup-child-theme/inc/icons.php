<?php
/**
 * Icone delle societa' e simbolo del gruppo.
 *
 * Le icone sono SVG del tema (pittogrammi generici, nessun dato del cliente),
 * disegnate sulle proporzioni del simbolo circolare FTA: anello spesso il 9,5%
 * del diametro e segni interni dello stesso spessore, spigoli vivi. Stampate in
 * linea con currentColor, prendono il colore del testo che le circonda.
 *
 * Il simbolo del gruppo invece e' un'immagine della Libreria media scelta nel
 * Personalizza: e' un marchio del cliente e non sta nel codice.
 *
 * @package tenconigroup
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * SVG di un'icona del tema, letto una volta per richiesta.
 *
 * @param string $key Chiave dell'icona (whitelist di tg_icon_choices()).
 * @return string Markup SVG, oppure stringa vuota.
 */
function tg_icon_svg( $key ) {
	static $cache = array();
	$allowed = array( 'idromeccanica', 'immobiliare', 'rail' );
	if ( ! in_array( $key, $allowed, true ) ) {
		return '';
	}
	if ( ! isset( $cache[ $key ] ) ) {
		$file          = TG_DIR . '/assets/icons/' . $key . '.svg';
		$cache[ $key ] = is_readable( $file ) ? trim( (string) file_get_contents( $file ) ) : ''; // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
	}
	return $cache[ $key ];
}

/**
 * Stampa il segno di una societa': immagine propria, simbolo o icona.
 *
 * Ordine: un'immagine caricata per quella societa' vince; poi il simbolo del
 * gruppo se scelto; poi l'icona SVG. Il segno e' decorativo (il nome della
 * societa' e' sempre scritto accanto), quindi alt vuoto.
 *
 * @param array<string,mixed> $company Societa' da tg_companies().
 * @param string              $size    Dimensione immagine WordPress.
 */
function tg_the_company_mark( $company, $size = 'medium' ) {
	if ( ! empty( $company['image'] ) ) {
		echo wp_get_attachment_image( (int) $company['image'], $size, false, array( 'class' => 'tg-mark tg-mark--img', 'alt' => '', 'loading' => 'lazy' ) );
		return;
	}
	if ( 'simbolo' === $company['icon'] ) {
		tg_the_symbol( 'tg-mark tg-mark--simbolo', $size );
		return;
	}
	$svg = tg_icon_svg( (string) $company['icon'] );
	if ( '' !== $svg ) {
		echo '<span class="tg-mark tg-mark--svg tg-mark--' . esc_attr( $company['icon'] ) . '">' . $svg . '</span>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- file SVG del tema, in whitelist.
	}
}

/**
 * Larghezza e altezza del logo del CMS, per riservargli lo spazio giusto.
 *
 * Il parent salva il logo come indirizzo: risalire all'allegato costa una query,
 * quindi il risultato resta in un transient per un giorno (la chiave cambia da
 * sola quando cambia il logo).
 *
 * Restituisce anche la versione 'medium_large' (768 px): il logo non supera mai
 * 249 px di larghezza, quindi basta anche per schermi 3x, e si evita di
 * scaricare l'originale intero su ogni pagina.
 *
 * @param string $url Indirizzo del logo.
 * @return array{0:int,1:int,2:string}|null [larghezza, altezza, src ridotto] oppure null.
 */
function tg_logo_dimensions( $url ) {
	$key = 'tg_logo_dim_' . md5( (string) $url );
	$dim = get_transient( $key );
	if ( false === $dim ) {
		$id    = attachment_url_to_postid( $url );
		$src   = $id ? wp_get_attachment_image_src( $id, 'full' ) : false;
		$small = $id ? wp_get_attachment_image_url( $id, 'medium_large' ) : '';
		$dim   = $src ? array( (int) $src[1], (int) $src[2], (string) $small ) : array();
		set_transient( $key, $dim, DAY_IN_SECONDS );
	}
	return ( is_array( $dim ) && 3 === count( $dim ) && $dim[0] > 0 ) ? $dim : null;
}

/**
 * Stampa il simbolo del gruppo dalla Libreria media, se impostato.
 *
 * @param string $class Classi CSS.
 * @param string $size  Dimensione immagine WordPress.
 * @return bool Vero se stampato.
 */
function tg_the_symbol( $class = 'tg-symbol', $size = 'medium' ) {
	$id = absint( get_theme_mod( 'tg_symbol', 0 ) );
	if ( ! $id || ! wp_attachment_is_image( $id ) ) {
		return false;
	}
	echo wp_get_attachment_image( $id, $size, false, array( 'class' => $class, 'alt' => '', 'loading' => 'lazy', 'decoding' => 'async' ) );
	return true;
}
