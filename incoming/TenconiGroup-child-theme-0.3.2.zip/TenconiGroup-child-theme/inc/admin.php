<?php
/**
 * Bacheca: una voce ovvia per arrivare ai testi del sito.
 *
 * Chi gestisce il sito non deve sapere che i testi stanno nel Personalizza:
 * la voce «Testi del sito» nel menu e un avviso sulle due pagine lo portano li'.
 *
 * @package tenconigroup
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Voce di menu «Testi del sito» che apre il pannello Tenconi Group.
 */
function tg_admin_menu() {
	add_menu_page(
		__( 'Testi del sito', 'tenconigroup' ),
		__( 'Testi del sito', 'tenconigroup' ),
		'edit_theme_options',
		'tg-testi',
		'__return_null',
		'dashicons-edit-page',
		21
	);
}
add_action( 'admin_menu', 'tg_admin_menu' );

/**
 * La voce di menu porta direttamente al Personalizza (nessuna pagina intermedia).
 */
function tg_admin_menu_redirect() {
	if ( isset( $_GET['page'] ) && 'tg-testi' === $_GET['page'] && current_user_can( 'edit_theme_options' ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- sola navigazione.
		wp_safe_redirect( add_query_arg( 'autofocus[panel]', 'tg_panel', admin_url( 'customize.php' ) ) );
		exit;
	}
}
add_action( 'admin_init', 'tg_admin_menu_redirect' );

/**
 * Avviso sulla modifica della homepage.
 *
 * La homepage prende i testi dal Personalizza: senza questo avviso chi apre
 * l'editor vedrebbe una pagina vuota e non saprebbe dove scrivere.
 */
function tg_page_notice() {
	$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
	if ( ! $screen || 'page' !== $screen->id || empty( $_GET['post'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		return;
	}
	$post_id  = absint( $_GET['post'] ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	if ( (int) get_option( 'page_on_front' ) !== $post_id ) {
		return;
	}
	$url = add_query_arg(
		array(
			'autofocus[panel]'   => 'tg_panel',
			'url'                => rawurlencode( (string) get_permalink( $post_id ) ),
		),
		admin_url( 'customize.php' )
	);
	printf(
		'<div class="notice notice-info"><p>%1$s <a href="%2$s">%3$s</a></p></div>',
		esc_html__( 'I testi di questa pagina non si scrivono qui: si modificano con l’anteprima in', 'tenconigroup' ),
		esc_url( $url ),
		esc_html__( 'Testi del sito (Personalizza → Tenconi Group)', 'tenconigroup' )
	);
}
add_action( 'admin_notices', 'tg_page_notice' );
