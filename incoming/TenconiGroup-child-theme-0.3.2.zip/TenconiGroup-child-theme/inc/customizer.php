<?php
/**
 * Aspetto → Personalizza → Tenconi Group.
 *
 * Il Personalizza mostra il sito accanto ai campi: chi modifica un testo lo vede
 * cambiare nell'anteprima prima di pubblicarlo. Un solo posto per tutti i testi
 * del sito; logo, indirizzo e SEO restano dove li gestisce il parent
 * (ticinoWEB CMS e tW SEO).
 *
 * @package tenconigroup
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Sanifica la scelta dell'icona.
 *
 * @param string $value Valore inviato.
 * @return string
 */
function tg_sanitize_icon( $value ) {
	return array_key_exists( $value, tg_icon_choices() ) ? $value : '';
}

/**
 * Aggiunge un campo al Personalizza.
 *
 * @param WP_Customize_Manager $wpc     Manager.
 * @param string               $id      theme_mod.
 * @param string               $section Sezione.
 * @param string               $type    text|textarea|url|icon|image.
 * @param string               $label   Etichetta.
 * @param string               $desc    Aiuto breve.
 */
function tg_customize_field( $wpc, $id, $section, $type, $label, $desc = '' ) {
	$sanitize = array(
		'text'     => 'sanitize_text_field',
		'textarea' => 'sanitize_textarea_field',
		'url'      => 'esc_url_raw',
		'icon'     => 'tg_sanitize_icon',
		'image'    => 'absint',
	);
	$wpc->add_setting(
		$id,
		array(
			'type'              => 'theme_mod',
			'default'           => 'image' === $type ? 0 : '',
			'sanitize_callback' => $sanitize[ $type ],
			'transport'         => 'refresh',
		)
	);
	if ( 'image' === $type ) {
		$wpc->add_control(
			new WP_Customize_Media_Control(
				$wpc,
				$id,
				array(
					'section'     => $section,
					'label'       => $label,
					'description' => $desc,
					'mime_type'   => 'image',
				)
			)
		);
		return;
	}
	$args = array(
		'section'     => $section,
		'label'       => $label,
		'description' => $desc,
		'type'        => 'icon' === $type ? 'select' : $type,
	);
	if ( 'icon' === $type ) {
		$args['choices'] = tg_icon_choices();
	}
	if ( 'url' === $type ) {
		$args['input_attrs'] = array( 'placeholder' => 'https://' );
	}
	$wpc->add_control( $id, $args );
}

/**
 * Registra pannello, sezioni e campi.
 *
 * @param WP_Customize_Manager $wpc Manager.
 */
function tg_customize_register( $wpc ) {
	$wpc->add_panel(
		'tg_panel',
		array(
			'title'       => __( 'Tenconi Group', 'tenconigroup' ),
			'description' => __( 'I testi della homepage. Modifica un campo: l’anteprima a destra si aggiorna. Premi «Pubblica» per salvare. Il logo in alto si cambia in ticinoWEB CMS → Logo; indirizzo e dati SEO in ticinoWEB CMS e tW SEO; la pagina «Storia» da Pagine; le traduzioni in tW Translate.', 'tenconigroup' ),
			'priority'    => 20,
		)
	);

	/* --- Homepage: introduzione --------------------------------------- */
	$wpc->add_section(
		'tg_sec_intro',
		array(
			'title'       => __( 'Homepage – introduzione', 'tenconigroup' ),
			'description' => __( 'La parte alta della homepage: simbolo, titolo e testo di presentazione del gruppo.', 'tenconigroup' ),
			'panel'       => 'tg_panel',
		)
	);
	tg_customize_field( $wpc, 'tg_symbol', 'tg_sec_intro', 'image', __( 'Simbolo del gruppo', 'tenconigroup' ), __( 'PNG con fondo trasparente. Compare accanto al nome del gruppo e nel piè di pagina.', 'tenconigroup' ) );
	tg_customize_field( $wpc, 'tg_hero_label', 'tg_sec_intro', 'text', __( 'Nome del gruppo', 'tenconigroup' ), __( 'La riga accanto al simbolo, sopra il titolo.', 'tenconigroup' ) );
	tg_customize_field( $wpc, 'tg_hero_title', 'tg_sec_intro', 'text', __( 'Titolo principale', 'tenconigroup' ), __( 'Breve: una frase. È il titolo principale della pagina per Google.', 'tenconigroup' ) );
	tg_customize_field( $wpc, 'tg_hero_text', 'tg_sec_intro', 'textarea', __( 'Testo di presentazione', 'tenconigroup' ), __( 'Due o tre frasi al massimo.', 'tenconigroup' ) );

	/* --- Homepage: le due societa' con sito -------------------------- */
	$wpc->add_section(
		'tg_sec_home',
		array(
			'title'       => __( 'Homepage – società', 'tenconigroup' ),
			'description' => __( 'I due grandi riquadri cliccabili della homepage. Ognuno porta al sito della società. Per togliere un riquadro, svuota il nome.', 'tenconigroup' ),
			'panel'       => 'tg_panel',
		)
	);
	tg_customize_field( $wpc, 'tg_home_cta', 'tg_sec_home', 'text', __( 'Testo del collegamento', 'tenconigroup' ), __( 'Uguale per tutti i riquadri, es. «Visita il sito».', 'tenconigroup' ) );
	for ( $i = 1; $i <= tg_company_groups()['home']; $i++ ) {
		/* translators: %d: numero del riquadro. */
		$n = sprintf( __( 'Riquadro %d', 'tenconigroup' ), $i );
		tg_customize_field( $wpc, "tg_home_{$i}_name", 'tg_sec_home', 'text', $n . ' – ' . __( 'nome della società', 'tenconigroup' ) );
		tg_customize_field( $wpc, "tg_home_{$i}_desc", 'tg_sec_home', 'textarea', $n . ' – ' . __( 'descrizione breve', 'tenconigroup' ) );
		tg_customize_field( $wpc, "tg_home_{$i}_url", 'tg_sec_home', 'url', $n . ' – ' . __( 'indirizzo del sito', 'tenconigroup' ) );
		tg_customize_field( $wpc, "tg_home_{$i}_icon", 'tg_sec_home', 'icon', $n . ' – ' . __( 'icona', 'tenconigroup' ) );
		tg_customize_field( $wpc, "tg_home_{$i}_image", 'tg_sec_home', 'image', $n . ' – ' . __( 'logo (facoltativo)', 'tenconigroup' ), __( 'Se carichi un logo, prende il posto dell’icona. Meglio un PNG trasparente.', 'tenconigroup' ) );
	}

	/* --- Homepage: le altre societa' (sotto i riquadri) ---------------- */
	$wpc->add_section(
		'tg_sec_soc',
		array(
			'title'       => __( 'Homepage – altre società', 'tenconigroup' ),
			'description' => __( 'Le società del gruppo presentate sotto i due riquadri, senza collegamento. Per togliere una società, svuota il nome.', 'tenconigroup' ),
			'panel'       => 'tg_panel',
		)
	);
	tg_customize_field( $wpc, 'tg_soc_title', 'tg_sec_soc', 'text', __( 'Titolo della sezione', 'tenconigroup' ), __( 'Es. «Le altre società del gruppo».', 'tenconigroup' ) );
	tg_customize_field( $wpc, 'tg_soc_intro', 'tg_sec_soc', 'textarea', __( 'Testo introduttivo', 'tenconigroup' ) );
	for ( $i = 1; $i <= tg_company_groups()['soc']; $i++ ) {
		/* translators: %d: numero della societa'. */
		$n = sprintf( __( 'Società %d', 'tenconigroup' ), $i );
		tg_customize_field( $wpc, "tg_soc_{$i}_name", 'tg_sec_soc', 'text', $n . ' – ' . __( 'nome ufficiale', 'tenconigroup' ) );
		tg_customize_field( $wpc, "tg_soc_{$i}_meta", 'tg_sec_soc', 'text', $n . ' – ' . __( 'forma giuridica e sede', 'tenconigroup' ), __( 'Es. «Società anonima · Lugano».', 'tenconigroup' ) );
		tg_customize_field( $wpc, "tg_soc_{$i}_desc", 'tg_sec_soc', 'textarea', $n . ' – ' . __( 'descrizione', 'tenconigroup' ) );
		tg_customize_field( $wpc, "tg_soc_{$i}_url", 'tg_sec_soc', 'url', $n . ' – ' . __( 'sito web (facoltativo)', 'tenconigroup' ) );
		tg_customize_field( $wpc, "tg_soc_{$i}_icon", 'tg_sec_soc', 'icon', $n . ' – ' . __( 'icona', 'tenconigroup' ) );
		tg_customize_field( $wpc, "tg_soc_{$i}_image", 'tg_sec_soc', 'image', $n . ' – ' . __( 'logo (facoltativo)', 'tenconigroup' ), __( 'Se carichi un logo, prende il posto dell’icona.', 'tenconigroup' ) );
	}
}
add_action( 'customize_register', 'tg_customize_register' );
