<?php
/**
 * The front page template for Monvél Cappelli (Streetwear / E-commerce Edition)
 */
get_header();

// Fetch Hero Data
$slider_data = function_exists('ticinoweb_get_slider_data') ? ticinoweb_get_slider_data() : [];
$hero_img = !empty($slider_data[0]['image']) ? $slider_data[0]['image'] : ''; // Fallback hat image here if empty
$hero_title = !empty($slider_data[0]['title']) ? $slider_data[0]['title'] : 'NEW ERA';
$hero_subtitle = !empty($slider_data[0]['desc']) ? $slider_data[0]['desc'] : 'Premium Headwear for the Urban Culture.';

// If WooCommerce is active, fetch some products, otherwise fallback to services
$products = [];
if ( class_exists( 'WooCommerce' ) ) {
    $args = array(
        'post_type' => 'product',
        'posts_per_page' => 4,
        'orderby' => 'date',
        'order' => 'DESC',
        'status' => 'publish',
    );
    $products = wc_get_products( $args );
} else {
    $products = function_exists('ticinoweb_get_services') ? ticinoweb_get_services() : [];
}

?>

<main id="primary" class="site-main">

    <!-- HERO IMMERSIVE -->
    <section class="mv-hero">

        <div class="swiper mv-hero-swiper">
            <div class="swiper-wrapper">
                <?php if ( class_exists('WooCommerce') && !empty($products) ) : ?>
                    <?php 
                    $slide_index = 0;
                    foreach ( $products as $product ) : 
                        if ($slide_index >= 4) break; // Max 4 slides

                        // Dati dinamici dal CMS TicinoWEB (con fallback al prodotto WooCommerce)
                        $bg_image     = !empty($slider_data[$slide_index]['image']) ? $slider_data[$slide_index]['image'] : 'http://localhost:8081/monvel/wp-content/uploads/sites/17/2026/06/ChatGPT-Image-5-giu-2026-10_18_37.png';
                        $cms_title    = !empty($slider_data[$slide_index]['title']) ? $slider_data[$slide_index]['title'] : $product->get_name();
                        $cms_desc     = !empty($slider_data[$slide_index]['desc']) ? $slider_data[$slide_index]['desc'] : strip_tags($product->get_short_description());
                        $cms_btn_text = !empty($slider_data[$slide_index]['btn1_text']) ? $slider_data[$slide_index]['btn1_text'] : 'Shop Now — ' . strip_tags($product->get_price_html());
                        $cms_btn_link = $product->get_permalink();
                        
                        $image_id  = $product->get_image_id();
                        $product_img = wp_get_attachment_image_url( $image_id, 'full' );
                        
                        // Attributi WooCommerce
                        $attributes = $product->get_attributes();
                    ?>
                        <div class="swiper-slide">
                            <!-- Sfondo dinamico della slide -->
                            <div class="mv-hero-bg" style="background-image: url('<?php echo esc_url($bg_image); ?>');"></div>
                            <div class="mv-hero-overlay"></div>

                            <div class="monvel-container">
                                <div class="mv-hero-grid">
                                    <div class="mv-hero-content">
                                        <<?php echo 0 === $slide_index ? 'h1' : 'h2'; ?> class="mv-hero-title"><?php echo esc_html($cms_title); ?></<?php echo 0 === $slide_index ? 'h1' : 'h2'; ?>>
                                        <p class="mv-hero-subtitle"><?php echo wp_kses_post($cms_desc); ?></p>
                                        <a href="<?php echo esc_url($cms_btn_link); ?>" class="mv-btn">
                                            <span><?php echo esc_html($cms_btn_text); ?></span>
                                        </a>
                                    </div>
                                    <div class="mv-hero-product">
                                        <div class="mv-product-wrapper">
                                            <?php if ( $product_img ) : ?>
                                                <img src="<?php echo esc_url($product_img); ?>" alt="<?php echo esc_attr($product->get_name()); ?>" class="hero-hat-img">
                                                
                                                <!-- Premium Pop-up Tooltip -->
                                                <div class="mv-product-tooltip">
                                                    <!-- Close Button -->
                                                    <div class="mv-tooltip-close">
                                                        <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                            <path d="M1 1L13 13M1 13L13 1" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>
                                                        </svg>
                                                    </div>

                                                    <?php 
                                                    // Determina il colore dinamico del cerchio (es. Rosa, Nero, ecc.)
                                                    // Di default mettiamo un colore neutro elegante
                                                    $bg_circle_color = '#e0e0e0';
                                                    $color_name = 'Custom';
                                                    $model_name = 'Monvél Curve';
                                                    
                                                    // Parse WooCommerce attributes to find Color
                                                    $parsed_attrs = [];
                                                    if ( !empty($attributes) ) {
                                                        foreach ( $attributes as $attribute ) {
                                                            $name = $attribute->is_taxonomy() ? wc_attribute_label( $attribute->get_name() ) : $attribute->get_name();
                                                            
                                                            // Custom sorting per Colore
                                                            if ($attribute->get_name() === 'pa_colore' && $product->is_type('variable')) {
                                                                $ordered_colors = array();
                                                                $variation_ids = $product->get_children();
                                                                foreach ($variation_ids as $vid) {
                                                                    $v = wc_get_product($vid);
                                                                    if ($v && $v->get_status() === 'publish') {
                                                                        $c = $v->get_attribute('pa_colore');
                                                                        if ($c && !in_array($c, $ordered_colors)) {
                                                                            $ordered_colors[] = $c;
                                                                        }
                                                                    }
                                                                }
                                                                $val_str = implode(', ', $ordered_colors);
                                                            } else {
                                                                $values = $attribute->is_taxonomy() ? wc_get_product_terms( $product->get_id(), $attribute->get_name(), array( 'fields' => 'names' ) ) : $attribute->get_options();
                                                                $val_str = implode(', ', $values);
                                                            }

                                                            $parsed_attrs[strtolower($name)] = [ 'label' => $name, 'value' => $val_str ];

                                                            // Simple color mapping
                                                            if ( strtolower($name) === 'colore' || strtolower($name) === 'color' ) {
                                                                $color_name = $val_str;
                                                                if (stripos($val_str, 'rosa') !== false) $bg_circle_color = '#f8d0d6';
                                                                elseif (stripos($val_str, 'nero') !== false) $bg_circle_color = '#2a2a2a';
                                                                elseif (stripos($val_str, 'verde') !== false) $bg_circle_color = '#6b705c';
                                                                elseif (stripos($val_str, 'grigio') !== false) $bg_circle_color = '#b0b0b0';
                                                                elseif (stripos($val_str, 'beige') !== false) $bg_circle_color = '#e3d5ca';
                                                            }
                                                            if ( strtolower($name) === 'modello' || strtolower($name) === 'model' ) {
                                                                $model_name = $val_str;
                                                            }
                                                        }
                                                    }
                                                    ?>

                                                    <!-- Decorative Background Circle -->
                                                    <div class="mv-tooltip-bg-circle" style="background-color: <?php echo esc_attr($bg_circle_color); ?>;"></div>

                                                    <!-- Compact Header -->
                                                    <div class="mv-tooltip-header">
                                                        <h3 class="mv-tooltip-title">DETAILS</h3>
                                                        <div class="mv-tooltip-badge"><?php echo esc_html(strtoupper($model_name)); ?></div>
                                                    </div>

                                                    <!-- Compact Info List -->
                                                    <div class="mv-tooltip-list">
                                                        <?php if (!empty($parsed_attrs)): ?>
                                                            <?php foreach ($parsed_attrs as $attr): ?>
                                                                <div class="mv-info-row">
                                                                    <span class="mv-info-label"><?php echo esc_html($attr['label']); ?></span>
                                                                    <span class="mv-info-value"><?php echo esc_html($attr['value']); ?></span>
                                                                </div>
                                                            <?php endforeach; ?>
                                                        <?php else: ?>
                                                            <!-- Fallback Demo List -->
                                                            <div class="mv-info-row">
                                                                <span class="mv-info-label">CHIUSURA</span>
                                                                <span class="mv-info-value">Cinturino regolabile</span>
                                                            </div>
                                                            <div class="mv-info-row">
                                                                <span class="mv-info-label">COLORE</span>
                                                                <span class="mv-info-value">Rosa</span>
                                                            </div>
                                                            <div class="mv-info-row">
                                                                <span class="mv-info-label">RICAMO</span>
                                                                <span class="mv-info-value">Logo frontale 3D</span>
                                                            </div>
                                                            <div class="mv-info-row">
                                                                <span class="mv-info-label">STILE</span>
                                                                <span class="mv-info-value">Casual / Streetwear</span>
                                                            </div>
                                                            <div class="mv-info-row">
                                                                <span class="mv-info-label">FIT</span>
                                                                <span class="mv-info-value">Taglia unica</span>
                                                            </div>
                                                            <div class="mv-info-row">
                                                                <span class="mv-info-label">VISIERA</span>
                                                                <span class="mv-info-value">Curva Premium</span>
                                                            </div>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                            <?php else : ?>
                                                <div style="width:100%; height:400px; background:rgba(0,0,0,0.1); display:flex; align-items:center; justify-content:center; font-family:var(--font-heading);">NO PRODUCT IMAGE</div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php 
                        $slide_index++;
                    endforeach; ?>
                <?php else : ?>
                    <div class="swiper-slide">
                        <div class="monvel-container">
                            <div class="mv-hero-grid">
                                <div class="mv-hero-content">
                                    <h2 class="mv-hero-title">NEW ERA</h2>
                                    <p class="mv-hero-subtitle">Premium Headwear for the Urban Culture.</p>
                                    <a href="#shop" class="mv-btn"><span>Shop the Drop</span></a>
                                </div>
                                <div class="mv-hero-product">
                                    <div class="mv-product-wrapper">
                                        <div style="width:100%; height:400px; background:rgba(0,0,0,0.1); display:flex; align-items:center; justify-content:center; font-family:var(--font-heading);">UPLOAD PRODUCT</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
            
            <div class="mv-swiper-controls">
                <div class="swiper-button-prev-custom">PREV</div>
                <div class="swiper-pagination"></div>
                <div class="swiper-button-next-custom">NEXT</div>
            </div>
        </div>
    </section>

    <!-- CAMPAIGN GRID (Editorial layout) -->
    <section class="mv-campaign-grid-section">
        <?php
        // Fetch images for Campaign Grid from ticinoWEB Media Gallery ID 27
        $campaign_gallery_id = 27;
        $campaign_images = array();
        
        $campaign_query = new WP_Query(array(
            'post_type'      => 'attachment',
            'post_status'    => 'inherit',
            'posts_per_page' => 4,
            'tax_query' => array(
                array(
                    'taxonomy' => 'ticinoweb_media_gallery',
                    'field' => 'term_id',
                    'terms' => $campaign_gallery_id,
                )
            )
        ));

        // Apply saved order if any
        $saved_order = get_term_meta($campaign_gallery_id, '_ticinoweb_gallery_order', true);
        if (!empty($saved_order) && is_array($saved_order) && $campaign_query->have_posts()) {
            usort($campaign_query->posts, function ($a, $b) use ($saved_order) {
                $posA = array_search($a->ID, $saved_order);
                $posB = array_search($b->ID, $saved_order);
                if ($posA === false) $posA = 999999;
                if ($posB === false) $posB = 999999;
                return $posA - $posB;
            });
        }

        if ($campaign_query->have_posts()) {
            foreach ($campaign_query->posts as $attachment) {
                $img_src = wp_get_attachment_image_src($attachment->ID, 'large');
                if ($img_src) {
                    $campaign_images[] = $img_src[0];
                }
            }
        }
        wp_reset_postdata();

        // Fallbacks if fewer than 4 images
        while (count($campaign_images) < 4) {
            $campaign_images[] = 'https://images.unsplash.com/photo-1556821840-3a63f95609a7?q=80&w=1200&auto=format&fit=crop';
        }

        $shop_url = function_exists('wc_get_page_permalink') ? wc_get_page_permalink('shop') : home_url('/shop/');
        
        $campaign_blocks = array(
            array('title' => 'ESSENZIALI MONVÉL', 'cta' => 'ACQUISTA ORA', 'link' => $shop_url),
            array('title' => 'STILE URBANO', 'cta' => 'SCOPRI ORA', 'link' => $shop_url),
            array('title' => 'NUOVE ICONE STREET', 'cta' => 'ESPLORA', 'link' => $shop_url),
            array('title' => 'DETTAGLI CHE CONTANO', 'cta' => 'VEDI I CAPPELLI', 'link' => $shop_url),
        );
        ?>
        <div class="monvel-container">
            <div class="mv-campaign-grid">
                <?php for ($i = 0; $i < 4; $i++): ?>
                    <a href="<?php echo esc_url($campaign_blocks[$i]['link']); ?>" class="mv-campaign-block">
                        <div class="mv-campaign-bg" style="background-image: url('<?php echo esc_url($campaign_images[$i]); ?>');"></div>
                        <div class="mv-campaign-overlay"></div>
                        <div class="mv-campaign-content">
                            <h3 class="mv-campaign-title"><?php echo esc_html($campaign_blocks[$i]['title']); ?></h3>
                            <span class="mv-campaign-cta"><?php echo esc_html($campaign_blocks[$i]['cta']); ?></span>
                        </div>
                    </a>
                <?php endfor; ?>
            </div>
        </div>
    </section>

    <!-- PROMOTIONAL VIDEO SECTION -->
    <section class="mv-front-video-section">
        <div class="monvel-container">
            <div class="mv-video-wrapper">
                <video id="mv-front-video" class="mv-front-video" autoplay loop muted playsinline src="https://monvelwear.com/wp-content/uploads/sites/108/2026/07/Crea_un_video_pubblicitario_ci-1.mp4"></video>
                <div class="mv-video-overlay"></div>
                <button id="mv-audio-toggle" class="mv-audio-toggle" aria-label="Toggle Audio">
                    <svg class="mv-icon-muted" viewBox="0 0 24 24" width="24" height="24" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"></polygon><line x1="23" y1="9" x2="17" y2="15"></line><line x1="17" y1="9" x2="23" y2="15"></line></svg>
                    <svg class="mv-icon-unmuted" viewBox="0 0 24 24" width="24" height="24" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round" style="display:none;"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"></polygon><path d="M19.07 4.93a10 10 0 0 1 0 14.14M15.54 8.46a5 5 0 0 1 0 7.07"></path></svg>
                </button>
            </div>
        </div>
    </section>

    <?php get_template_part( 'template-parts/home-color-cards' ); ?>

    <?php
    // ==========================================================================
    // 6. WEAR MONVÉL (Campaign Section - REPLACED SHOWCASE)
    // ==========================================================================
    $wear_gallery_id = 30;
    $wear_images = array();
    
    if (class_exists('WooCommerce')) {
        $wear_query = new WP_Query(array(
            'post_type'      => 'attachment',
            'post_status'    => 'inherit',
            'posts_per_page' => 3,
            'tax_query' => array(
                array(
                    'taxonomy' => 'ticinoweb_media_gallery',
                    'field' => 'term_id',
                    'terms' => $wear_gallery_id,
                )
            )
        ));

        $saved_order = get_term_meta($wear_gallery_id, '_ticinoweb_gallery_order', true);
        if (!empty($saved_order) && is_array($saved_order) && $wear_query->have_posts()) {
            usort($wear_query->posts, function ($a, $b) use ($saved_order) {
                $posA = array_search($a->ID, $saved_order);
                $posB = array_search($b->ID, $saved_order);
                if ($posA === false) $posA = 999999;
                if ($posB === false) $posB = 999999;
                return $posA - $posB;
            });
        }

        if ($wear_query->have_posts()) {
            foreach ($wear_query->posts as $attachment) {
                $img_src = wp_get_attachment_image_src($attachment->ID, 'large');
                if ($img_src) {
                    $wear_images[] = $img_src[0];
                }
            }
        }
        wp_reset_postdata();
    }
    
    $fallbacks = array(
        'https://images.unsplash.com/photo-1520975954732-57dd22299614?auto=format&fit=crop&w=800&q=80',
        'https://images.unsplash.com/photo-1622445275463-afa2ab738c34?auto=format&fit=crop&w=800&q=80',
        'https://images.unsplash.com/photo-1514316454349-750a7fd3da3a?auto=format&fit=crop&w=800&q=80'
    );
    while (count($wear_images) < 3) {
        $wear_images[] = array_shift($fallbacks);
    }
    
    $wear_blocks = array(
        array(
            'title' => 'Clean Street',
            'desc'  => 'Linee pulite. Attitudine urbana.',
            'img'   => $wear_images[0]
        ),
        array(
            'title' => 'Soft Minimal',
            'desc'  => 'Essenziale. Leggero. Definito.',
            'img'   => $wear_images[1]
        ),
        array(
            'title' => 'Urban Essential',
            'desc'  => 'Presenza quotidiana. Stile immediato.',
            'img'   => $wear_images[2]
        )
    );
    ?>

    <section id="shop" class="mv-wear-section">
        <div class="monvel-container">
            <div class="mv-wear-header">
                <h2 class="mv-wear-title">INDOSSA MONVÉL</h2>
            </div>
            
            <div class="mv-wear-grid">
                <?php foreach ($wear_blocks as $block) : ?>
                    <div class="mv-wear-card">
                        <div class="mv-wear-image-wrapper">
                            <img src="<?php echo esc_url($block['img']); ?>" alt="<?php echo esc_attr($block['title']); ?>" class="mv-wear-img">
                            <div class="mv-wear-overlay"></div>
                        </div>
                        <div class="mv-wear-content">
                            <h3 class="mv-wear-card-title"><?php echo esc_html($block['title']); ?></h3>
                            <p class="mv-wear-card-desc"><?php echo esc_html($block['desc']); ?></p>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- FINAL CTA SECTION -->
    <section class="mv-final-cta-section">
        <!-- Soft glowing background effect -->
        <div class="mv-final-glow"></div>
        
        <div class="monvel-container">
            <div class="mv-final-content">
                <span class="mv-final-eyebrow">IL PROSSIMO PASSO</span>
                <h2 class="mv-final-title">UNISCITI AL DROP</h2>
                <p class="mv-final-subtitle">Nuovi colori, nuovi modelli, stessa identità Monvél.</p>
                <div class="mv-final-actions">
                    <a href="<?php echo class_exists('WooCommerce') ? wc_get_page_permalink( 'shop' ) : '#shop'; ?>" class="mv-btn mv-btn-dark mv-final-btn">
                        <span>Scopri la collezione</span>
                    </a>
                </div>
            </div>
        </div>
    </section>

</main>

<?php
get_footer();
