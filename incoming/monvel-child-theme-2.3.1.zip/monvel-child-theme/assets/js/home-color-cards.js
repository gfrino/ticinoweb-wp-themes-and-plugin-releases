/** Each color keeps its own gallery; additional photos load only when requested. */
document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('.mv-card-gallery').forEach(gallery => {
        const photos = Array.from(gallery.querySelectorAll('template[data-photo]'));
        if (photos.length < 2) return;
        const frame = gallery.querySelector('.mv-card-photo');
        const controls = gallery.querySelector('.mv-card-gallery-controls');
        const dots = Array.from(gallery.querySelectorAll('[data-gallery-photo]'));
        const status = gallery.querySelector('.mv-gallery-status');
        let current = 0;
        const show = index => {
            current = (index + photos.length) % photos.length;
            frame.replaceChildren(photos[current].content.cloneNode(true));
            dots.forEach((dot, i) => dot.setAttribute('aria-pressed', String(i === current)));
            status.textContent = dots[current].getAttribute('aria-label');
        };
        controls.hidden = false;
        controls.addEventListener('click', event => {
            const button = event.target.closest('button');
            if (!button) return;
            if (button.hasAttribute('data-gallery-photo')) show(Number(button.dataset.galleryPhoto));
            if (button.hasAttribute('data-gallery-step')) show(current + Number(button.dataset.galleryStep));
        });
        controls.addEventListener('keydown', event => {
            if (!['ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(event.key)) return;
            event.preventDefault();
            const target = event.key === 'Home' ? 0 : event.key === 'End' ? photos.length - 1 : current + (event.key === 'ArrowRight' ? 1 : -1);
            show(target);
            dots[current].focus();
        });
        let touchStart;
        frame.addEventListener('touchstart', event => {
            touchStart = event.touches.length === 1 ? { x: event.touches[0].clientX, y: event.touches[0].clientY } : null;
        }, { passive: true });
        frame.addEventListener('touchend', event => {
            if (!touchStart || !event.changedTouches.length) return;
            const dx = event.changedTouches[0].clientX - touchStart.x;
            const dy = event.changedTouches[0].clientY - touchStart.y;
            if (Math.abs(dx) > 45 && Math.abs(dx) > Math.abs(dy) * 1.5) show(current + (dx < 0 ? 1 : -1));
            touchStart = null;
        }, { passive: true });
        frame.addEventListener('touchcancel', () => { touchStart = null; }, { passive: true });
    });
});
