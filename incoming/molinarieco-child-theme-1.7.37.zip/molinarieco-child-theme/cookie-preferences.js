document.addEventListener('click', function (event) {
  const trigger = event.target instanceof Element ? event.target.closest('.mol-cookie-preferences') : null;
  if (!trigger) return;

  event.preventDefault();
  document.cookie = 'tw_cookie_consent=; Max-Age=0; path=/; SameSite=Lax';
  document.cookie = 'tw_cookie_preferences=; Max-Age=0; path=/; SameSite=Lax';
  window.location.reload();
});
