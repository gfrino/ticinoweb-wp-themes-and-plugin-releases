<?php
/**
 * Garage Molinari child theme setup.
 *
 * @package Molinarieco
 */
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

require_once __DIR__ . '/admin-media.php';

/** Build the public hours label from the parent CMS's weekly schedule. */
function molinarieco_opening_hours_label() {
    $schedule = get_option( 'ticinoweb_contact_opening_hours', array() );
    if ( ! is_array( $schedule ) ) {
        return trim( (string) $schedule );
    }

    $days = array(
        'monday'    => __( 'lun', 'molinarieco-child-theme' ),
        'tuesday'   => __( 'mar', 'molinarieco-child-theme' ),
        'wednesday' => __( 'mer', 'molinarieco-child-theme' ),
        'thursday'  => __( 'gio', 'molinarieco-child-theme' ),
        'friday'    => __( 'ven', 'molinarieco-child-theme' ),
        'saturday'  => __( 'sab', 'molinarieco-child-theme' ),
        'sunday'    => __( 'dom', 'molinarieco-child-theme' ),
    );
    $groups = array();
    $active = null;

    foreach ( $days as $key => $label ) {
        $day = isset( $schedule[ $key ] ) && is_array( $schedule[ $key ] ) ? $schedule[ $key ] : array();
        $times = array();
        if ( empty( $day['closed'] ) ) {
            if ( ! empty( $day['open_24h'] ) ) {
                $times[] = __( '24 ore', 'molinarieco-child-theme' );
            } else {
                foreach ( isset( $day['slots'] ) && is_array( $day['slots'] ) ? $day['slots'] : array() as $slot ) {
                    if ( is_array( $slot ) && ! empty( $slot['open'] ) && ! empty( $slot['close'] ) ) {
                        $times[] = sanitize_text_field( $slot['open'] ) . '–' . sanitize_text_field( $slot['close'] );
                    }
                }
            }
        }
        $value = implode( ', ', $times );
        if ( '' === $value ) {
            $active = null;
            continue;
        }
        if ( null !== $active && $groups[ $active ]['value'] === $value ) {
            $groups[ $active ]['last'] = $label;
            continue;
        }
        $groups[] = array( 'first' => $label, 'last' => $label, 'value' => $value );
        $active = array_key_last( $groups );
    }

    $labels = array();
    foreach ( $groups as $group ) {
        $range = $group['first'] === $group['last'] ? $group['first'] : $group['first'] . '-' . $group['last'];
        $labels[] = $range . ' ' . $group['value'];
    }
    return implode( '; ', $labels );
}
add_action( 'wp_enqueue_scripts', function () {
    wp_enqueue_style( 'molinarieco-parent', get_template_directory_uri() . '/style.css', array(), wp_get_theme( get_template() )->get( 'Version' ) );
}, 9 );

// The parent registers Google Fonts; use the system font on this site to avoid a third-party request.
add_action( 'wp_enqueue_scripts', function () {
    wp_dequeue_style( 'ticinoweb-ai-style' );
    wp_deregister_style( 'ticinoweb-ai-style' );
    wp_dequeue_style( 'poppins-font' );
    wp_deregister_style( 'poppins-font' );
    wp_register_style( 'poppins-font', false );
    wp_enqueue_style( 'ticinoweb-ai-style', get_stylesheet_uri(), array( 'molinarieco-parent' ), wp_get_theme()->get( 'Version' ) );
    $palette_options = array(
        'ticinoweb_palette_primary'     => '--mol-red',
        'ticinoweb_palette_suggested_1' => '--mol-red-dark',
        'ticinoweb_palette_suggested_2' => '--mol-cream',
        'ticinoweb_palette_suggested_3' => '--mol-paper',
    );
    $palette_rules = array();
    foreach ( $palette_options as $option => $property ) {
        $color = sanitize_hex_color( (string) get_option( $option, '' ) );
        if ( $color ) {
            $palette_rules[] = $property . ':' . $color;
        }
    }
    if ( $palette_rules ) {
        wp_add_inline_style( 'ticinoweb-ai-style', ':root{' . implode( ';', $palette_rules ) . '}' );
    }
    $background_url = get_option( 'ticinoweb_page_bg_image', '' );
    if ( $background_url && 'all' === get_option( 'ticinoweb_page_bg_scope', 'all' ) ) {
        $css_url = wp_json_encode( esc_url( $background_url ), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT );
        wp_add_inline_style( 'ticinoweb-ai-style', 'body{background-image:linear-gradient(rgba(242,237,221,.75),rgba(242,237,221,.75)),url(' . $css_url . ');background-position:center top;background-size:cover;background-repeat:no-repeat;background-attachment:fixed}@media(max-width:800px){body{background-attachment:scroll}}' );
    }
    if ( is_front_page() ) {
        wp_enqueue_script( 'molinarieco-home', get_stylesheet_directory_uri() . '/home.js', array(), wp_get_theme()->get( 'Version' ), true );
    }
    if ( is_page_template( 'template-servizio.php' ) ) {
        wp_enqueue_script( 'molinarieco-service-carousel', get_stylesheet_directory_uri() . '/service-carousel.js', array(), wp_get_theme()->get( 'Version' ), true );
        wp_enqueue_script( 'molinarieco-service-mobile-gallery', get_stylesheet_directory_uri() . '/service-mobile-gallery.js', array(), wp_get_theme()->get( 'Version' ), true );
    }
    if ( is_page( 'contatti' ) ) {
        wp_enqueue_script( 'molinarieco-contact-map', get_stylesheet_directory_uri() . '/contact-map.js', array(), wp_get_theme()->get( 'Version' ), true );
    }
    if ( get_option( 'tw_cookie_banner_enable' ) ) {
        wp_enqueue_script( 'molinarieco-cookie-preferences', get_stylesheet_directory_uri() . '/cookie-preferences.js', array(), wp_get_theme()->get( 'Version' ), true );
    }
    if ( has_nav_menu( 'primary' ) ) {
        wp_enqueue_script( 'molinarieco-services-menu', get_stylesheet_directory_uri() . '/services-menu.js', array(), wp_get_theme()->get( 'Version' ), true );
    }
}, 11 );

// The shared banner describes optional categories; this site currently uses neither analytics nor advertising.
add_filter( 'gettext', function ( $translation, $text, $domain ) {
    if ( 'ticinoweb-ai-theme' !== $domain || is_admin() ) {
        return $translation;
    }
    static $cookie_copy = null;
    if ( null === $cookie_copy ) {
        $cookie_copy = array(
            'Utilizziamo i cookie per offrirti la migliore esperienza sul nostro sito web e per analizzare il traffico.' => __( 'Usiamo cookie necessari per il sito. Google Maps si carica solo quando scegli di mostrare la mappa; non usiamo cookie per analisi o pubblicità.', 'molinarieco-child-theme' ),
            'Ci consentono di misurare il traffico del sito in modo anonimo per migliorare le performance e l\'esperienza d\'uso.' => __( 'Al momento non usiamo cookie per analisi del traffico.', 'molinarieco-child-theme' ),
            'Utilizzati per mostrare annunci pertinenti o tracciare le conversioni pubblicitarie sui social media e motori di ricerca.' => __( 'Al momento non usiamo cookie pubblicitari o di profilazione.', 'molinarieco-child-theme' ),
        );
    }
    return $cookie_copy[ $text ] ?? $translation;
}, 10, 3 );

// The parent CMS lists web fonts only; add the locally used Arial choice on this site's screen.
add_action( 'admin_enqueue_scripts', function ( $hook ) {
    if ( 'toplevel_page_ticinoweb-cms' !== $hook ) {
        return;
    }
    wp_enqueue_script( 'molinarieco-cms-font', get_stylesheet_directory_uri() . '/admin-cms-font.js', array(), wp_get_theme()->get( 'Version' ), true );
    $saved = array();
    foreach ( array( 'headings', 'subheadings', 'body' ) as $role ) {
        $saved[ $role ] = (string) get_option( 'ticinoweb_font_' . $role, 'Arial' );
    }
    wp_add_inline_script( 'molinarieco-cms-font', 'window.molinariecoCmsFonts=' . wp_json_encode( $saved ) . ';', 'before' );
} );

// The parent renders this setting as a small corner ornament; this child uses it as the site background.
add_action( 'after_setup_theme', function () {
    remove_action( 'wp_head', 'ticinoweb_apply_page_background_image' );
}, 20 );

// The parent prints Google Fonts preconnects even when its font is disabled.
// Remove only that closure for this child so a public visit does not contact Google.
add_action( 'after_setup_theme', function () {
    global $wp_filter;

    if ( empty( $wp_filter['wp_head']->callbacks[0] ) ) {
        return;
    }

    foreach ( $wp_filter['wp_head']->callbacks[0] as $entry ) {
        $callback = $entry['function'];
        if ( ! $callback instanceof Closure ) {
            continue;
        }

        $reflection = new ReflectionFunction( $callback );
        if ( $reflection->getFileName() !== get_template_directory() . '/functions.php' ) {
            continue;
        }

        $source = file( $reflection->getFileName() );
        $body   = implode( '', array_slice( $source, $reflection->getStartLine() - 1, $reflection->getEndLine() - $reflection->getStartLine() + 1 ) );
        if ( str_contains( $body, 'fonts.googleapis.com' ) && str_contains( $body, 'fonts.gstatic.com' ) ) {
            remove_action( 'wp_head', $callback, 0 );
        }
    }
}, 20 );

add_action( 'after_setup_theme', function () {
    register_nav_menus( array( 'molinarieco-footer-services' => __( 'Servizi nel footer', 'molinarieco-child-theme' ) ) );
} );

// Keep the CMS menu as the source of service links, but make its parent a disclosure.
add_filter( 'walker_nav_menu_start_el', function ( $output, $item, $depth, $args ) {
    if ( 0 !== $depth || 'mol-header-menu' !== ( $args->menu_class ?? '' ) || 'page' !== $item->object ) {
        return $output;
    }
    $services = get_page_by_path( 'servizi' );
    if ( ! $services || (int) $item->object_id !== (int) $services->ID ) {
        return $output;
    }
    return '<button class="mol-services-trigger" type="button" aria-expanded="false">' . esc_html( $item->title ) . '</button>';
}, 10, 4 );

// The footer already has a separate list of service links, so omit the parent index there.
add_filter( 'wp_nav_menu_objects', function ( $items, $args ) {
    if ( 'mol-footer-site-menu' !== ( $args->menu_class ?? '' ) ) {
        return $items;
    }
    $services = get_page_by_path( 'servizi' );
    if ( ! $services ) {
        return $items;
    }
    return array_values( array_filter( $items, static function ( $item ) use ( $services ) {
        return 'page' !== $item->object || (int) $item->object_id !== (int) $services->ID;
    } ) );
}, 10, 2 );

add_action( 'ticinoweb_footer_links', function () {
    if ( has_nav_menu( 'molinarieco-footer-services' ) ) {
        wp_nav_menu( array(
            'theme_location' => 'molinarieco-footer-services',
            'container'      => false,
            'items_wrap'     => '%3$s',
            'depth'          => 1,
        ) );
        return;
    }
    $services = get_page_by_path( 'servizi' );
    if ( $services ) {
        foreach ( get_pages( array( 'parent' => $services->ID, 'sort_column' => 'menu_order' ) ) as $service ) {
            if ( 'publish' === $service->post_status ) {
                echo '<li><a href="' . esc_url( get_permalink( $service ) ) . '">' . esc_html( get_the_title( $service ) ) . '</a></li>';
            }
        }
    }
} );

add_filter( 'ticinoweb_seo_jsonld_org_schema', static function ( $schema ) {
    if ( 'LocalBusiness' !== ( $schema['@type'] ?? '' ) ) {
        return $schema;
    }
    $address = trim( (string) get_option( 'ticinoweb_contact_address' ) );
    if ( preg_match( '/^(.+),\s*(\d{4})\s+(.+)$/u', $address, $parts ) ) {
        $schema['address'] = array(
            '@type'           => 'PostalAddress',
            'streetAddress'   => trim( $parts[1] ),
            'postalCode'      => $parts[2],
            'addressLocality' => trim( $parts[3] ),
            'addressCountry'  => 'CH',
        );
    }
    return $schema;
} );

// The homepage video is page-specific content, selected from this site's Media Library.
add_action( 'add_meta_boxes_page', function ( $post ) {
    if ( (int) get_option( 'page_on_front' ) !== (int) $post->ID ) {
        return;
    }
    add_meta_box( 'mol-home-video', __( 'Video della home', 'molinarieco-child-theme' ), function ( $post ) {
        wp_nonce_field( 'mol_home_video_save', 'mol_home_video_nonce' );
        $selected = (int) get_post_meta( $post->ID, 'mol_hero_video_id', true );
        $videos = get_posts( array(
            'post_type'      => 'attachment',
            'post_status'    => 'inherit',
            'post_mime_type' => 'video',
            'posts_per_page' => 100,
        ) );
        echo '<p><label for="mol-hero-video-id">' . esc_html__( 'Scegli un video dalla Libreria media', 'molinarieco-child-theme' ) . '</label></p>';
        echo '<select id="mol-hero-video-id" name="mol_hero_video_id">';
        echo '<option value="0">' . esc_html__( 'Nessun video', 'molinarieco-child-theme' ) . '</option>';
        foreach ( $videos as $video ) {
            echo '<option value="' . esc_attr( $video->ID ) . '"' . selected( $selected, $video->ID, false ) . '>' . esc_html( get_the_title( $video ) ) . '</option>';
        }
        echo '</select>';
        echo '<p class="description">' . esc_html__( 'La copertina usa l’immagine in evidenza della pagina.', 'molinarieco-child-theme' ) . '</p>';
    }, 'page', 'side' );
} );

add_action( 'save_post_page', function ( $post_id ) {
    if ( (int) get_option( 'page_on_front' ) !== (int) $post_id || ! isset( $_POST['mol_home_video_nonce'] ) ) {
        return;
    }
    if ( ! is_string( $_POST['mol_home_video_nonce'] ) ) {
        return;
    }
    $nonce = sanitize_text_field( wp_unslash( $_POST['mol_home_video_nonce'] ) );
    if ( ! wp_verify_nonce( $nonce, 'mol_home_video_save' ) || ! current_user_can( 'edit_post', $post_id ) ) {
        return;
    }
    $video_id = isset( $_POST['mol_hero_video_id'] ) && is_scalar( $_POST['mol_hero_video_id'] ) ? absint( wp_unslash( $_POST['mol_hero_video_id'] ) ) : 0;
    if ( $video_id && wp_attachment_is( 'video', $video_id ) ) {
        update_post_meta( $post_id, 'mol_hero_video_id', $video_id );
    } else {
        delete_post_meta( $post_id, 'mol_hero_video_id' );
    }
} );

// The gallery taxonomy only groups Media Library images; its archive is not a public page.
add_filter( 'wp_sitemaps_taxonomies', function ( $taxonomies ) {
    unset( $taxonomies['ticinoweb_media_gallery'] );
    return $taxonomies;
} );

add_filter( 'wp_robots', function ( $robots ) {
    if ( is_tax( 'ticinoweb_media_gallery' ) ) {
        $robots['noindex'] = true;
        $robots['follow'] = true;
    }
    return $robots;
} );

// The parent owns gallery membership and photo order; the child only reads it.
function molinarieco_gallery_data( $slug ) {
    static $cache = array();
    $slug = sanitize_title( (string) $slug );
    if ( isset( $cache[ $slug ] ) ) {
        return $cache[ $slug ];
    }
    $term = $slug ? get_term_by( 'slug', $slug, 'ticinoweb_media_gallery' ) : false;
    if ( ! $term ) {
        $cache[ $slug ] = array( 'term' => false, 'ids' => array() );
        return $cache[ $slug ];
    }
    $ids = get_posts( array(
        'post_type'      => 'attachment',
        'post_status'    => 'inherit',
        'post_mime_type' => 'image',
        'posts_per_page' => 30,
        'fields'         => 'ids',
        'tax_query'      => array( array(
            'taxonomy' => 'ticinoweb_media_gallery',
            'field'    => 'term_id',
            'terms'    => (int) $term->term_id,
        ) ),
    ) );
    $order = array_map( 'intval', (array) get_term_meta( $term->term_id, '_ticinoweb_gallery_order', true ) );
    $positions = array_flip( $order );
    usort( $ids, static function ( $a, $b ) use ( $positions ) {
        return ( $positions[ $a ] ?? PHP_INT_MAX ) <=> ( $positions[ $b ] ?? PHP_INT_MAX ) ?: $a <=> $b;
    } );
    $cache[ $slug ] = array( 'term' => $term, 'ids' => $ids );
    return $cache[ $slug ];
}

add_shortcode( 'mol_gallery', function ( $attributes ) {
    $attributes = shortcode_atts( array( 'slug' => '', 'mode' => 'grid' ), $attributes, 'mol_gallery' );
    $gallery = molinarieco_gallery_data( $attributes['slug'] );
    $term = $gallery['term'];
    $ids = $gallery['ids'];
    if ( ! $term || ! $ids ) {
        return '';
    }
    $carousel = 'carousel' === $attributes['mode'];
    $output = $carousel
        ? '<div class="mol-carousel" role="region" aria-roledescription="carousel" aria-label="' . esc_attr( $term->name ) . '" data-keyboard-help="' . esc_attr__( 'Usa le frecce sinistra e destra per scorrere le foto. Premi Spazio per mettere in pausa o riprendere la galleria.', 'molinarieco-child-theme' ) . '" data-photo-label="' . esc_attr__( 'Foto', 'molinarieco-child-theme' ) . '" data-of-label="' . esc_attr__( 'di', 'molinarieco-child-theme' ) . '" data-paused-label="' . esc_attr__( 'Galleria in pausa', 'molinarieco-child-theme' ) . '" data-resumed-label="' . esc_attr__( 'Galleria ripresa', 'molinarieco-child-theme' ) . '"><div class="mol-carousel-viewport"><div class="mol-carousel-track" aria-live="off">'
        : '<div class="mol-gallery" aria-label="' . esc_attr( $term->name ) . '">';
    foreach ( $ids as $id ) {
        $alt = get_post_meta( $id, '_wp_attachment_image_alt', true ) ?: get_the_title( $id );
        $image = wp_get_attachment_image( $id, 'medium_large', false, array( 'loading' => 'lazy', 'alt' => $alt ) );
        if ( $image ) {
            $output .= '<a class="' . ( $carousel ? 'mol-carousel-slide' : '' ) . '" href="' . esc_url( wp_get_attachment_url( $id ) ) . '" aria-label="' . esc_attr( sprintf( __( 'Apri foto: %s', 'molinarieco-child-theme' ), $alt ) ) . '">' . $image . '</a>';
        }
    }
    if ( ! $carousel ) {
        return $output . '</div>';
    }
    return $output . '</div></div><span class="screen-reader-text mol-carousel-status" role="status" aria-live="polite"></span></div>';
} );

// A service page selects one of the parent theme's Media Galleries; the parent owns its images and order.
add_action( 'add_meta_boxes_page', function ( $post ) {
    $services = get_page_by_path( 'servizi' );
    if ( ! $services || (int) $post->post_parent !== (int) $services->ID ) {
        return;
    }
    add_meta_box( 'mol-service-gallery', __( 'Galleria del servizio', 'molinarieco-child-theme' ), function ( $post ) {
        wp_nonce_field( 'mol_service_gallery_save', 'mol_service_gallery_nonce' );
        $selected = sanitize_title( (string) get_post_meta( $post->ID, 'mol_service_gallery_slug', true ) );
        $terms = get_terms( array( 'taxonomy' => 'ticinoweb_media_gallery', 'hide_empty' => false ) );
        echo '<p><label for="mol-service-gallery-slug">' . esc_html__( 'Scegli una galleria della Libreria media', 'molinarieco-child-theme' ) . '</label></p>';
        echo '<select id="mol-service-gallery-slug" name="mol_service_gallery_slug"><option value="">' . esc_html__( 'Nessuna galleria', 'molinarieco-child-theme' ) . '</option>';
        if ( ! is_wp_error( $terms ) ) {
            foreach ( $terms as $term ) {
                echo '<option value="' . esc_attr( $term->slug ) . '"' . selected( $selected, $term->slug, false ) . '>' . esc_html( $term->name ) . '</option>';
            }
        }
        echo '</select>';
    }, 'page', 'side' );
} );

add_action( 'save_post_page', function ( $post_id ) {
    if ( ! isset( $_POST['mol_service_gallery_nonce'], $_POST['mol_service_gallery_slug'] ) || ! is_string( $_POST['mol_service_gallery_nonce'] ) || ! is_string( $_POST['mol_service_gallery_slug'] ) ) {
        return;
    }
    $nonce = sanitize_text_field( wp_unslash( $_POST['mol_service_gallery_nonce'] ) );
    if ( ! wp_verify_nonce( $nonce, 'mol_service_gallery_save' ) || ! current_user_can( 'edit_post', $post_id ) || wp_is_post_revision( $post_id ) ) {
        return;
    }
    $slug = sanitize_title( wp_unslash( $_POST['mol_service_gallery_slug'] ) );
    if ( $slug && ! get_term_by( 'slug', $slug, 'ticinoweb_media_gallery' ) ) {
        return;
    }
    if ( $slug ) {
        update_post_meta( $post_id, 'mol_service_gallery_slug', $slug );
    } else {
        delete_post_meta( $post_id, 'mol_service_gallery_slug' );
    }
} );
