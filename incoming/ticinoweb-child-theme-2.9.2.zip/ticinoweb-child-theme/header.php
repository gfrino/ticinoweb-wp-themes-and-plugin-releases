<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<script>document.documentElement.classList.add('tw-js');</script>
	<?php wp_head(); ?>
</head>
<body <?php body_class( 'tw-proof-site' ); ?>>
<?php wp_body_open(); ?>
<a class="tw-skip-link" href="#main-content"><?php esc_html_e( 'Vai al contenuto', 'ticinoweb-child-theme' ); ?></a>
<?php
$tw_logo          = function_exists( 'ticinoweb_get_site_logo' ) ? ticinoweb_get_site_logo() : '';
$tw_logo_id       = $tw_logo ? attachment_url_to_postid( $tw_logo ) : 0;
$tw_contact_url   = tw_home_mapped_url( 'page_contatti', 'contatti' );
$tw_support_url   = tw_home_mapped_url( 'page_supporto', 'supporto' );
$tw_support_url   = rtrim( $tw_support_url, '/' ) === rtrim( home_url( '/' ), '/' ) ? home_url( '/supporto/' ) : $tw_support_url;
$tw_status_url    = 'https://status.infomaniak.com/it/';
$tw_contact       = function_exists( 'ticinoweb_get_contact_info' ) ? ticinoweb_get_contact_info() : array();
$tw_phone         = trim( (string) ( $tw_contact['phone'] ?? '' ) );
$tw_phone_display = trim( (string) get_option( 'ticinoweb_contact_phone_display', '' ) );
$tw_phone_display = $tw_phone_display ?: $tw_phone;
$tw_phone_digits  = preg_replace( '/[^0-9]/', '', $tw_phone );
$tw_phone_href    = $tw_phone_digits ? ( 0 === strpos( $tw_phone, '+' ) ? '+' : '' ) . $tw_phone_digits : '';
$tw_languages     = function_exists( 'twtr_get_languages' ) ? twtr_get_languages() : array();
?>
<header class="tw-site-header" data-site-header>
	<div class="tw-utility-bar">
		<div class="tw-shell tw-utility-bar__inner">
			<?php if ( $tw_phone_href && $tw_phone_display ) : ?>
				<a class="tw-utility-phone" href="tel:<?php echo esc_attr( $tw_phone_href ); ?>">
					<svg aria-hidden="true" viewBox="0 0 24 24" width="16" height="16"><path d="M7.2 2.8 10 7.1 8.3 9.4c1.2 2.3 3 4.1 5.3 5.3l2.3-1.7 4.3 2.8-.6 3.8c-.2 1-1.1 1.7-2.1 1.7C9.3 20.8 3.2 14.7 2.7 6.5c0-1 .7-1.9 1.7-2.1l2.8-.6Z" fill="currentColor"/></svg>
					<span><?php echo esc_html( $tw_phone_display ); ?></span>
				</a>
			<?php endif; ?>

			<nav class="tw-utility-actions" aria-label="<?php esc_attr_e( 'Collegamenti di servizio', 'ticinoweb-child-theme' ); ?>">
				<a href="<?php echo esc_url( $tw_status_url ); ?>" target="_blank" rel="noopener">
					<svg aria-hidden="true" viewBox="0 0 24 24" width="16" height="16"><path d="M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20Zm4.7 7.7-5.4 5.4a1 1 0 0 1-1.4 0l-2.6-2.6 1.4-1.4 1.9 1.9 4.7-4.7 1.4 1.4Z" fill="currentColor"/></svg>
					<span><?php esc_html_e( 'Stato dei Servizi', 'ticinoweb-child-theme' ); ?></span>
				</a>
				<a href="<?php echo esc_url( $tw_support_url ); ?>">
					<svg aria-hidden="true" viewBox="0 0 24 24" width="16" height="16"><path d="M13 2v7h7v6h-7v7H7v-7H2V9h5V2h6Zm-2 2H9v7H4v2h5v7h2v-7h7v-2h-7V4Z" fill="currentColor"/></svg>
					<span><?php esc_html_e( 'Richiedi Supporto', 'ticinoweb-child-theme' ); ?></span>
				</a>
			</nav>

			<?php if ( $tw_languages ) : ?>
				<nav class="tw-language-switcher" aria-label="<?php esc_attr_e( 'Lingue', 'ticinoweb-child-theme' ); ?>">
					<?php foreach ( $tw_languages as $tw_language ) : ?>
						<?php
						$tw_language_label = (string) ( $tw_language['label'] ?? $tw_language['slug'] ?? '' );
						$tw_language_locale = str_replace( '_', '-', (string) ( $tw_language['locale'] ?? $tw_language['slug'] ?? '' ) );
						$tw_language_class = ! empty( $tw_language['is_current'] ) ? ' is-current' : '';
						?>
						<a class="tw-language-switcher__link<?php echo esc_attr( $tw_language_class ); ?>" href="<?php echo esc_url( $tw_language['url'] ?? home_url( '/' ) ); ?>" hreflang="<?php echo esc_attr( $tw_language_locale ); ?>" aria-label="<?php echo esc_attr( sprintf( __( 'Passa a %s', 'ticinoweb-child-theme' ), $tw_language_label ) ); ?>"<?php echo ! empty( $tw_language['is_current'] ) ? ' aria-current="page"' : ''; ?>>
							<span aria-hidden="true"><?php echo esc_html( $tw_language['flag'] ?? strtoupper( (string) ( $tw_language['slug'] ?? '' ) ) ); ?></span>
							<span class="screen-reader-text"><?php echo esc_html( $tw_language_label ); ?></span>
						</a>
					<?php endforeach; ?>
				</nav>
			<?php endif; ?>
		</div>
	</div>

	<div class="tw-shell tw-site-header__inner">
		<a class="tw-brand" href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home" aria-label="<?php esc_attr_e( 'ticinoWEB — Home', 'ticinoweb-child-theme' ); ?>">
			<?php if ( $tw_logo ) : ?>
				<?php if ( $tw_logo_id ) : ?>
					<?php echo wp_get_attachment_image( $tw_logo_id, 'full', false, array( 'class' => 'tw-brand__logo', 'alt' => '', 'fetchpriority' => 'high', 'decoding' => 'async', 'sizes' => '(max-width: 1180px) 170px, 190px' ) ); ?>
				<?php else : ?>
					<img class="tw-brand__logo" src="<?php echo esc_url( $tw_logo ); ?>" alt="" fetchpriority="high" decoding="async">
				<?php endif; ?>
			<?php else : ?>
				<span>ticino<strong>WEB</strong></span>
			<?php endif; ?>
		</a>

		<nav class="tw-primary-nav" id="tw-primary-navigation" aria-label="<?php esc_attr_e( 'Navigazione principale', 'ticinoweb-child-theme' ); ?>" data-primary-nav>
			<?php
			wp_nav_menu(
				array(
					'theme_location' => 'primary',
					'container'      => false,
					'menu_class'     => 'tw-primary-nav__list',
					'fallback_cb'    => false,
					'depth'          => 3,
					'walker'         => new TW_Premium_Nav_Walker(),
				)
			);
			?>
		</nav>

		<a class="tw-header-cta" href="<?php echo esc_url( $tw_contact_url ); ?>" data-header-cta><?php esc_html_e( 'Parliamo del tuo progetto', 'ticinoweb-child-theme' ); ?><span aria-hidden="true">↗</span></a>
		<button class="tw-menu-toggle" type="button" aria-controls="tw-primary-navigation" aria-expanded="false" aria-label="<?php esc_attr_e( 'Apri il menu', 'ticinoweb-child-theme' ); ?>" data-open-label="<?php esc_attr_e( 'Apri il menu', 'ticinoweb-child-theme' ); ?>" data-close-label="<?php esc_attr_e( 'Chiudi il menu', 'ticinoweb-child-theme' ); ?>" data-menu-toggle>
			<span class="screen-reader-text"><?php esc_html_e( 'Apri il menu', 'ticinoweb-child-theme' ); ?></span>
			<span aria-hidden="true"></span>
		</button>
	</div>
</header>
<span id="main-content" class="tw-skip-target" tabindex="-1"></span>
