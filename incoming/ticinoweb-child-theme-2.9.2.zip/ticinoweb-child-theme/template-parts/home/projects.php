<?php
/**
 * THESIS: il portfolio si esplora come un indice vivo, non come una sequenza di card promozionali.
 * OWN-WORLD: griglia svizzera, linee Ink, immagini reali e tipografia editoriale del Digital Proof Studio.
 * STORY: scegliere una lente → aprire una categoria → sfogliare lavori reali → approfondire il progetto.
 * FIRST VIEWPORT: titolo compatto, selettore Tipologie/Settori e prime righe dell'indice immediatamente visibili.
 * FORM: Project Explorer a fisarmonica, estensione locale della Home esistente.
 *
 * @package ticinoWEB_Child_Theme
 */

$tw_explorer     = $args['project_explorer'] ?? array();
$tw_groups       = $tw_explorer['groups'] ?? array();
$tw_default_tax  = $tw_explorer['default_taxonomy'] ?? 'tw_project_type';
$tw_default_term = $tw_explorer['default_term'] ?? null;
$tw_initial      = $tw_explorer['initial'] ?? array( 'items' => array(), 'pages' => 0 );
$tw_projects_url = $args['urls']['projects'] ?? home_url( '/' );
$tw_query_params = array(
	'tw_project_type'   => 'tipologia',
	'tw_project_sector' => 'settore',
);

$tw_render_project_card = static function ( $project ) {
	$meta = array_filter(
		array(
			implode( ', ', $project['types'] ?? array() ),
			implode( ', ', $project['sectors'] ?? array() ),
		)
	);
	?>
	<a class="tw-project-card" href="<?php echo esc_url( $project['url'] ); ?>">
		<span class="tw-project-card__media">
			<?php
			if ( ! empty( $project['image_id'] ) ) {
				echo wp_get_attachment_image(
					$project['image_id'],
					'large',
					false,
					array(
						'alt'      => '',
						'loading'  => 'lazy',
						'decoding' => 'async',
						'sizes'    => '(max-width: 767px) calc(100vw - 32px), (max-width: 1100px) 46vw, 31vw',
					)
				); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			}
			?>
			<span class="tw-project-card__overlay">
				<strong><?php echo esc_html( $project['title'] ); ?></strong>
				<?php if ( $meta ) : ?><small><?php echo esc_html( implode( ' · ', $meta ) ); ?></small><?php endif; ?>
				<i aria-hidden="true">↗</i>
			</span>
		</span>
		<span class="tw-project-card__mobile-copy">
			<strong><?php echo esc_html( $project['title'] ); ?></strong>
			<?php if ( $meta ) : ?><small><?php echo esc_html( implode( ' · ', $meta ) ); ?></small><?php endif; ?>
			<i aria-hidden="true">↗</i>
		</span>
	</a>
	<?php
};
?>
<section
	class="tw-section tw-projects tw-project-explorer"
	id="progetti"
	aria-labelledby="tw-projects-title"
	data-project-explorer
	data-rest-url="<?php echo esc_url( $tw_explorer['rest_url'] ?? '' ); ?>"
	data-per-page="<?php echo esc_attr( (string) ( $tw_explorer['per_page'] ?? 6 ) ); ?>"
	data-loading-label="<?php esc_attr_e( 'Caricamento progetti…', 'ticinoweb-child-theme' ); ?>"
	data-error-label="<?php esc_attr_e( 'Non è stato possibile caricare i progetti. Riprova.', 'ticinoweb-child-theme' ); ?>"
	data-empty-label="<?php esc_attr_e( 'Nessun progetto disponibile in questa categoria.', 'ticinoweb-child-theme' ); ?>"
	data-loaded-label="<?php esc_attr_e( 'Progetti caricati: %d.', 'ticinoweb-child-theme' ); ?>"
>
	<div class="tw-shell">
		<header class="tw-project-explorer__head">
			<p class="tw-kicker"><?php esc_html_e( 'Progetti / Realizzazioni', 'ticinoweb-child-theme' ); ?></p>
			<div>
				<h2 id="tw-projects-title"><?php esc_html_e( 'Una selezione del nostro lavoro.', 'ticinoweb-child-theme' ); ?></h2>
				<p><?php esc_html_e( 'Siti web, eCommerce, applicazioni e soluzioni digitali realizzate per aziende e organizzazioni in Ticino e in Svizzera.', 'ticinoweb-child-theme' ); ?></p>
			</div>
		</header>

		<div class="tw-project-explorer__modes" role="tablist" aria-label="<?php esc_attr_e( 'Esplora i progetti per', 'ticinoweb-child-theme' ); ?>">
			<?php foreach ( $tw_groups as $tw_taxonomy => $tw_group ) : ?>
				<?php $tw_mode_active = $tw_taxonomy === $tw_default_tax; ?>
				<button type="button" id="tw-project-tab-<?php echo esc_attr( $tw_taxonomy ); ?>" role="tab" aria-selected="<?php echo $tw_mode_active ? 'true' : 'false'; ?>" aria-controls="tw-project-group-<?php echo esc_attr( $tw_taxonomy ); ?>" tabindex="<?php echo $tw_mode_active ? '0' : '-1'; ?>" data-project-mode="<?php echo esc_attr( $tw_taxonomy ); ?>">
					<?php echo esc_html( $tw_group['label'] ); ?>
				</button>
			<?php endforeach; ?>
		</div>

		<div class="tw-project-explorer__groups">
			<?php foreach ( $tw_groups as $tw_taxonomy => $tw_group ) : ?>
				<?php $tw_group_active = $tw_taxonomy === $tw_default_tax; ?>
				<div class="tw-project-explorer__group<?php echo $tw_group_active ? ' is-active' : ''; ?>" id="tw-project-group-<?php echo esc_attr( $tw_taxonomy ); ?>" role="tabpanel" aria-labelledby="tw-project-tab-<?php echo esc_attr( $tw_taxonomy ); ?>" data-project-group="<?php echo esc_attr( $tw_taxonomy ); ?>" data-query-param="<?php echo esc_attr( $tw_query_params[ $tw_taxonomy ] ?? 'progetto' ); ?>"<?php echo $tw_group_active ? '' : ' hidden'; ?>>
					<div class="tw-project-accordion">
						<?php foreach ( $tw_group['terms'] as $tw_term ) : ?>
							<?php
							$tw_is_open = $tw_group_active && $tw_default_term && (int) $tw_default_term['id'] === (int) $tw_term['id'];
							$tw_panel_id = 'tw-project-panel-' . $tw_taxonomy . '-' . $tw_term['id'];
							$tw_button_id = 'tw-project-trigger-' . $tw_taxonomy . '-' . $tw_term['id'];
							$tw_count_label = sprintf(
								_n( '%s progetto', '%s progetti', $tw_term['count'], 'ticinoweb-child-theme' ),
								number_format_i18n( $tw_term['count'] )
							);
							?>
							<article class="tw-project-accordion__item<?php echo $tw_is_open ? ' is-open' : ''; ?>" data-project-item data-taxonomy="<?php echo esc_attr( $tw_taxonomy ); ?>" data-term-id="<?php echo esc_attr( (string) $tw_term['id'] ); ?>" data-term-slug="<?php echo esc_attr( $tw_term['slug'] ); ?>" data-loaded="<?php echo $tw_is_open ? 'true' : 'false'; ?>" data-page="1" data-pages="<?php echo $tw_is_open ? esc_attr( (string) ( $tw_initial['pages'] ?? 0 ) ) : '0'; ?>">
								<h3>
									<button type="button" id="<?php echo esc_attr( $tw_button_id ); ?>" aria-expanded="<?php echo $tw_is_open ? 'true' : 'false'; ?>" aria-controls="<?php echo esc_attr( $tw_panel_id ); ?>" data-project-trigger>
										<span><?php echo esc_html( $tw_term['name'] ); ?></span>
										<small><?php echo esc_html( $tw_count_label ); ?></small>
										<i aria-hidden="true"></i>
									</button>
								</h3>
								<div class="tw-project-accordion__panel" id="<?php echo esc_attr( $tw_panel_id ); ?>" role="region" aria-labelledby="<?php echo esc_attr( $tw_button_id ); ?>" data-project-panel<?php echo $tw_is_open ? '' : ' hidden'; ?>>
									<div class="tw-project-accordion__panel-inner">
										<div class="tw-project-grid" data-project-grid>
											<?php
											if ( $tw_is_open ) {
												foreach ( $tw_initial['items'] ?? array() as $tw_project ) {
													$tw_render_project_card( $tw_project );
												}
											}
											?>
										</div>
										<p class="tw-project-explorer__status" role="status" aria-live="polite" data-project-status></p>
										<button class="tw-project-explorer__more" type="button" data-project-load-more<?php echo $tw_is_open && ( $tw_initial['pages'] ?? 0 ) > 1 ? '' : ' hidden'; ?>><?php esc_html_e( 'Mostra altri progetti', 'ticinoweb-child-theme' ); ?> <span aria-hidden="true">+</span></button>
									</div>
								</div>
							</article>
						<?php endforeach; ?>
					</div>
				</div>
			<?php endforeach; ?>
		</div>

		<a class="tw-project-explorer__archive tw-text-link" href="<?php echo esc_url( $tw_projects_url ); ?>"><?php esc_html_e( 'Vedi tutti i progetti', 'ticinoweb-child-theme' ); ?> <span aria-hidden="true">↗</span></a>
	</div>
</section>
