<?php
$tw_reviews  = $args['reviews'] ?? array();
$tw_partners = array_slice( $args['partners'] ?? array(), 0, 4 );
$tw_published_projects = absint( $args['published_project_count'] ?? 0 );
?>
<section class="tw-trust" aria-label="<?php esc_attr_e( 'Fiducia e partner', 'ticinoweb-child-theme' ); ?>">
	<div class="tw-shell tw-trust__inner">
		<p class="tw-trust__statement"><?php esc_html_e( 'Scelti da aziende in Ticino e in Svizzera.', 'ticinoweb-child-theme' ); ?></p>
		<div class="tw-trust__facts">
			<?php if ( ! empty( $tw_reviews['rating'] ) ) : ?><p><strong><?php echo esc_html( $tw_reviews['rating'] ); ?>/5</strong><span><?php echo esc_html( sprintf( __( '%d recensioni', 'ticinoweb-child-theme' ), $tw_reviews['count'] ?? 0 ) ); ?></span></p><?php endif; ?>
			<?php if ( $tw_published_projects ) : ?><p><strong><?php echo esc_html( (string) $tw_published_projects ); ?>+</strong><span><?php esc_html_e( 'progetti', 'ticinoweb-child-theme' ); ?></span></p><?php endif; ?>
		</div>
		<div class="tw-trust__logos">
			<?php foreach ( $tw_partners as $tw_partner ) : ?>
				<?php if ( $tw_partner['url'] ) : ?><a href="<?php echo esc_url( $tw_partner['url'] ); ?>" target="_blank" rel="noopener noreferrer"><?php else : ?><span><?php endif; ?>
				<?php if ( $tw_partner['image_id'] ) : ?>
					<?php echo wp_get_attachment_image( $tw_partner['image_id'], 'medium', false, array( 'alt' => $tw_partner['label'] ?? '', 'loading' => 'lazy', 'decoding' => 'async', 'sizes' => '(max-width: 767px) 20vw, 110px' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				<?php else : ?>
					<img src="<?php echo esc_url( $tw_partner['logo'] ); ?>" alt="<?php echo esc_attr( $tw_partner['label'] ?? '' ); ?>" width="110" height="42" loading="lazy" decoding="async">
				<?php endif; ?>
				<?php if ( $tw_partner['url'] ) : ?></a><?php else : ?></span><?php endif; ?>
			<?php endforeach; ?>
		</div>
	</div>
</section>
