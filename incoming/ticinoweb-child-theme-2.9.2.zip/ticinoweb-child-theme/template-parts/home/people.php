<?php
$tw_people      = array_values( array_filter( array_merge( array( $args['founder'] ?? null ), $args['team'] ?? array() ) ) );
$tw_contact_url = $args['urls']['contact'] ?? home_url( '/' );
?>
<section class="tw-section tw-team" id="team" aria-labelledby="tw-team-title">
	<div class="tw-shell">
		<header class="tw-section-head">
			<div><p class="tw-kicker"><?php esc_html_e( 'Il Team', 'ticinoweb-child-theme' ); ?></p><h2 id="tw-team-title"><?php esc_html_e( 'Le persone dietro ogni progetto.', 'ticinoweb-child-theme' ); ?></h2></div>
			<div><p><?php esc_html_e( 'Competenze diverse, responsabilità chiare e un confronto diretto con chi segue il tuo progetto.', 'ticinoweb-child-theme' ); ?></p><a class="tw-text-link" href="<?php echo esc_url( $tw_contact_url ); ?>"><?php esc_html_e( 'Parla con noi', 'ticinoweb-child-theme' ); ?><span aria-hidden="true">↗</span></a></div>
		</header>
		<div class="tw-team__grid">
			<?php foreach ( $tw_people as $tw_index => $tw_person ) : ?>
				<article class="tw-person tw-person--<?php echo esc_attr( (string) ( ( $tw_index % 3 ) + 1 ) ); ?>" data-home-reveal>
					<div class="tw-person__media"><?php if ( $tw_person['image_id'] ) : ?><?php echo wp_get_attachment_image( $tw_person['image_id'], 'medium_large', false, array( 'alt' => $tw_person['name'], 'loading' => 'lazy', 'decoding' => 'async', 'sizes' => '(max-width: 480px) 92vw, (max-width: 767px) 45vw, 24vw' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?><?php endif; ?></div>
					<div class="tw-person__body">
						<h3><?php echo esc_html( $tw_person['name'] ); ?></h3>
						<?php if ( $tw_person['role'] ) : ?><p class="tw-person__role"><?php echo esc_html( $tw_person['role'] ); ?></p><?php endif; ?>
						<?php if ( $tw_person['specialization'] ) : ?><p class="tw-person__specialization"><strong><?php esc_html_e( 'Competenze', 'ticinoweb-child-theme' ); ?></strong><?php echo esc_html( $tw_person['specialization'] ); ?></p><?php endif; ?>
						<?php if ( $tw_person['languages'] ) : ?><p class="tw-person__languages"><strong><?php esc_html_e( 'Lingue', 'ticinoweb-child-theme' ); ?></strong><?php echo esc_html( $tw_person['languages'] ); ?></p><?php endif; ?>
					</div>
				</article>
			<?php endforeach; ?>
		</div>
	</div>
</section>
