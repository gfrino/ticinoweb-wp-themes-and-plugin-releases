<?php
$tw_reviews  = $args['reviews'] ?? array();
$tw_partners = $args['partners'] ?? array();
?>
<section class="tw-section tw-reviews" aria-labelledby="tw-reviews-title">
	<div class="tw-shell">
		<header class="tw-reviews__head">
			<div><p class="tw-kicker"><?php esc_html_e( 'Recensioni Google', 'ticinoweb-child-theme' ); ?></p><h2 id="tw-reviews-title"><?php esc_html_e( 'Cosa dicono di noi.', 'ticinoweb-child-theme' ); ?></h2></div>
			<div class="tw-google-summary" aria-label="<?php echo esc_attr( sprintf( __( 'Valutazione Google %s su 5', 'ticinoweb-child-theme' ), $tw_reviews['rating'] ?? '' ) ); ?>">
				<span class="tw-google-mark" aria-hidden="true">G</span>
				<?php if ( $tw_reviews['rating'] ?? '' ) : ?><p><strong><?php echo esc_html( $tw_reviews['rating'] ); ?>/5</strong><span class="tw-google-stars" aria-hidden="true">★★★★★</span><small><?php echo esc_html( sprintf( __( '%d recensioni verificate', 'ticinoweb-child-theme' ), $tw_reviews['count'] ?? 0 ) ); ?></small></p><?php endif; ?>
			</div>
		</header>
		<div class="tw-reviews__grid" role="list">
			<?php foreach ( $tw_reviews['items'] ?? array() as $tw_review ) : $tw_rating = min( 5, max( 0, absint( $tw_review['rating'] ?? 0 ) ) ); $tw_time = absint( $tw_review['time'] ?? 0 ); ?>
				<article class="tw-review" role="listitem" data-home-reveal>
					<header class="tw-review__author">
						<?php if ( ! empty( $tw_review['profile_photo_url'] ) ) : ?><img src="<?php echo esc_url( $tw_review['profile_photo_url'] ); ?>" alt="" width="48" height="48" loading="lazy" decoding="async" referrerpolicy="no-referrer"><?php else : ?><span class="tw-review__avatar" aria-hidden="true"><?php echo esc_html( mb_substr( $tw_review['author_name'], 0, 1 ) ); ?></span><?php endif; ?>
						<div><strong><?php echo esc_html( $tw_review['author_name'] ); ?></strong><?php if ( $tw_time ) : ?><time datetime="<?php echo esc_attr( gmdate( 'c', $tw_time ) ); ?>"><?php echo esc_html( wp_date( get_option( 'date_format' ), $tw_time ) ); ?></time><?php endif; ?></div>
						<span class="tw-google-mark" aria-hidden="true">G</span>
					</header>
					<p class="tw-review__stars" aria-label="<?php echo esc_attr( sprintf( __( '%d stelle su 5', 'ticinoweb-child-theme' ), $tw_rating ) ); ?>"><span aria-hidden="true"><?php echo esc_html( str_repeat( '★', $tw_rating ) . str_repeat( '☆', 5 - $tw_rating ) ); ?></span></p>
					<blockquote><?php echo esc_html( $tw_review['text'] ); ?></blockquote>
					<footer><?php esc_html_e( 'Pubblicata su Google', 'ticinoweb-child-theme' ); ?></footer>
				</article>
			<?php endforeach; ?>
		</div>
		<?php if ( ! empty( $tw_reviews['business_url'] ) ) : ?><p class="tw-reviews__all"><a class="tw-text-link" href="<?php echo esc_url( $tw_reviews['business_url'] ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Vedi tutte le recensioni su Google', 'ticinoweb-child-theme' ); ?><span aria-hidden="true">↗</span></a></p><?php endif; ?>
	</div>
</section>

<?php if ( $tw_partners ) : ?>
<section class="tw-partners" aria-labelledby="tw-partners-title">
	<div class="tw-shell">
		<h2 id="tw-partners-title"><?php esc_html_e( 'Partner, tecnologie e certificazioni.', 'ticinoweb-child-theme' ); ?></h2>
		<div class="tw-partners__wall">
			<?php foreach ( $tw_partners as $tw_partner ) : ?>
				<?php if ( $tw_partner['url'] ) : ?><a href="<?php echo esc_url( $tw_partner['url'] ); ?>" target="_blank" rel="noopener noreferrer"><?php else : ?><span><?php endif; ?>
				<?php if ( $tw_partner['image_id'] ) : ?><?php echo wp_get_attachment_image( $tw_partner['image_id'], 'medium', false, array( 'alt' => $tw_partner['label'] ?? '', 'loading' => 'lazy', 'decoding' => 'async', 'sizes' => '(max-width: 767px) 42vw, 120px' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?><?php else : ?><img src="<?php echo esc_url( $tw_partner['logo'] ); ?>" alt="<?php echo esc_attr( $tw_partner['label'] ?? '' ); ?>" width="120" height="42" loading="lazy" decoding="async"><?php endif; ?>
				<?php if ( $tw_partner['url'] ) : ?></a><?php else : ?></span><?php endif; ?>
			<?php endforeach; ?>
		</div>
	</div>
</section>
<?php endif; ?>
