<?php
$tw_services = $args['services'] ?? array();
$tw_core = array_values(
	array_filter(
		$tw_services,
		static fn( $service ) => in_array( $service['category'] ?? '', array( 'Web Design', 'eCommerce' ), true )
	)
);
$tw_ecosystem = array_values(
	array_filter(
		$tw_services,
		static fn( $service ) => ! in_array( $service['category'] ?? '', array( 'Web Design', 'eCommerce' ), true )
	)
);
?>
<section class="tw-section tw-core-services" aria-labelledby="tw-core-title">
	<div class="tw-shell">
		<header class="tw-core-services__head">
			<p class="tw-kicker"><?php esc_html_e( 'Il nostro core', 'ticinoweb-child-theme' ); ?></p>
			<h2 id="tw-core-title"><?php esc_html_e( 'Il web non deve solo esserci. Deve funzionare.', 'ticinoweb-child-theme' ); ?></h2>
			<p><?php esc_html_e( 'Progettiamo siti web capaci di unire identità, esperienza utente, performance e obiettivi commerciali. Ogni progetto viene costruito intorno all’azienda, non intorno a un template.', 'ticinoweb-child-theme' ); ?></p>
		</header>
		<div class="tw-core-services__list">
			<?php foreach ( $tw_core as $tw_index => $tw_service ) : $tw_service_url = $tw_service['url'] ?? ''; ?>
				<article class="tw-core-service" data-home-reveal>
					<div class="tw-core-service__media">
						<?php $tw_image_id = tw_home_attachment_id_from_url( $tw_service['image'] ?? '' ); ?>
						<?php if ( $tw_image_id ) : ?><?php echo wp_get_attachment_image( $tw_image_id, 'large', false, array( 'alt' => $tw_service['title'], 'loading' => 'lazy', 'decoding' => 'async', 'sizes' => '(max-width: 767px) 92vw, 46vw' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?><?php endif; ?>
					</div>
					<div class="tw-core-service__copy">
						<span><?php echo esc_html( str_pad( (string) ( $tw_index + 1 ), 2, '0', STR_PAD_LEFT ) ); ?></span>
						<h3><?php echo esc_html( $tw_service['title'] ); ?></h3>
						<p><?php echo esc_html( tw_home_excerpt( $tw_service['short_description'] ?? $tw_service['description'], 26 ) ); ?></p>
						<?php if ( $tw_service_url ) : ?><a class="tw-text-link" href="<?php echo esc_url( $tw_service_url ); ?>"><?php echo esc_html( $tw_service['cta_label'] ?? __( 'Scopri il servizio', 'ticinoweb-child-theme' ) ); ?><span aria-hidden="true">↗</span></a><?php endif; ?>
					</div>
				</article>
			<?php endforeach; ?>
		</div>
	</div>
</section>

<section class="tw-section tw-ecosystem" aria-labelledby="tw-ecosystem-title" data-service-index>
	<div class="tw-shell">
		<header class="tw-section-head tw-section-head--light">
			<div><p class="tw-kicker"><?php esc_html_e( 'Un sito è spesso solo l’inizio', 'ticinoweb-child-theme' ); ?></p><h2 id="tw-ecosystem-title"><?php esc_html_e( 'Un unico partner per il tuo ecosistema digitale.', 'ticinoweb-child-theme' ); ?></h2></div>
			<p><?php esc_html_e( 'Strategia, contenuti, tecnologia e supporto restano collegati in un solo percorso.', 'ticinoweb-child-theme' ); ?></p>
		</header>
		<div class="tw-service-index">
			<div class="tw-service-index__list">
				<?php foreach ( $tw_ecosystem as $tw_index => $tw_service ) : $tw_panel_id = 'tw-service-panel-' . absint( $tw_index ); $tw_service_url = $tw_service['url'] ?? ''; $tw_service_image_id = tw_home_attachment_id_from_url( $tw_service['image'] ?? '' ); ?>
					<div class="tw-service-index__item<?php echo 0 === $tw_index ? ' is-active' : ''; ?>">
						<button type="button" data-service-trigger="<?php echo esc_attr( (string) $tw_index ); ?>" aria-expanded="<?php echo 0 === $tw_index ? 'true' : 'false'; ?>" aria-controls="<?php echo esc_attr( $tw_panel_id ); ?>">
							<span><?php echo esc_html( str_pad( (string) ( $tw_index + 1 ), 2, '0', STR_PAD_LEFT ) ); ?></span><strong><?php echo esc_html( $tw_service['short_name'] ?? $tw_service['title'] ); ?></strong><i aria-hidden="true">+</i>
						</button>
						<div class="tw-service-index__mobile-panel" id="<?php echo esc_attr( $tw_panel_id ); ?>" data-mobile-service-panel>
							<?php if ( $tw_service_image_id ) : ?><div class="tw-service-index__mobile-media"><?php echo wp_get_attachment_image( $tw_service_image_id, 'medium_large', false, array( 'alt' => $tw_service['title'], 'loading' => 'lazy', 'decoding' => 'async', 'sizes' => 'calc(100vw - 74px)' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div><?php endif; ?>
							<p><?php echo esc_html( tw_home_excerpt( $tw_service['short_description'] ?? $tw_service['description'], 28 ) ); ?></p>
							<?php if ( $tw_service_url ) : ?><a class="tw-text-link" href="<?php echo esc_url( $tw_service_url ); ?>"><?php esc_html_e( 'Approfondisci', 'ticinoweb-child-theme' ); ?><span aria-hidden="true">↗</span></a><?php endif; ?>
						</div>
					</div>
				<?php endforeach; ?>
			</div>
			<div class="tw-service-index__stage" aria-live="polite">
				<?php foreach ( $tw_ecosystem as $tw_index => $tw_service ) : $tw_service_url = $tw_service['url'] ?? ''; $tw_service_image_id = tw_home_attachment_id_from_url( $tw_service['image'] ?? '' ); ?>
					<article class="tw-service-panel<?php echo 0 === $tw_index ? ' is-active' : ''; ?>" data-service-panel="<?php echo esc_attr( (string) $tw_index ); ?>" <?php echo 0 === $tw_index ? '' : 'hidden'; ?>>
						<?php if ( $tw_service_image_id ) : ?><div class="tw-service-panel__media"><?php echo wp_get_attachment_image( $tw_service_image_id, 'large', false, array( 'alt' => $tw_service['title'], 'loading' => 'lazy', 'decoding' => 'async', 'sizes' => '(max-width: 1180px) 92vw, 44vw' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div><?php endif; ?>
						<div class="tw-service-panel__copy">
							<p class="tw-kicker"><?php echo esc_html( $tw_service['category'] ?? __( 'Servizio digitale', 'ticinoweb-child-theme' ) ); ?></p>
							<h3><?php echo esc_html( $tw_service['title'] ); ?></h3>
							<p><?php echo esc_html( tw_home_excerpt( $tw_service['short_description'] ?? $tw_service['description'], 34 ) ); ?></p>
							<?php if ( $tw_service_url ) : ?><a class="tw-button tw-button--light" href="<?php echo esc_url( $tw_service_url ); ?>"><?php esc_html_e( 'Scopri il servizio', 'ticinoweb-child-theme' ); ?><span aria-hidden="true">↗</span></a><?php endif; ?>
						</div>
					</article>
				<?php endforeach; ?>
			</div>
		</div>
	</div>
</section>
