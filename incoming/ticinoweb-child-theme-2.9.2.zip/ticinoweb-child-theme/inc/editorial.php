<?php
/**
 * Editing contract for the existing Project and Team content models.
 *
 * Only fields consumed by the new Home are exposed here. Existing records and
 * meta keys remain unchanged; this is not a second content system.
 *
 * @package ticinoWEB_Child_Theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Sanitize a stored checkbox or REST boolean. */
function tw_home_sanitize_boolean( $value ) {
	return (bool) rest_sanitize_boolean( $value );
}

/** Sanitize a comma-separated or REST array of service keys. */
function tw_home_sanitize_key_list( $value ) {
	if ( is_string( $value ) ) {
		$value = preg_split( '/[\s,]+/', $value, -1, PREG_SPLIT_NO_EMPTY );
	}
	$keys = array_filter( array_map( 'sanitize_key', is_array( $value ) ? $value : array( $value ) ) );
	return array_values( array_unique( $keys ) );
}

/** Fields used by Project cards on the Home. */
function tw_home_project_fields() {
	return array(
		'tw_project_client'            => array( 'label' => __( 'Cliente', 'ticinoweb-child-theme' ), 'type' => 'text', 'sanitize' => 'sanitize_text_field', 'rest_type' => 'string' ),
		'tw_project_year'              => array( 'label' => __( 'Anno', 'ticinoweb-child-theme' ), 'type' => 'number', 'sanitize' => 'absint', 'rest_type' => 'integer' ),
		'tw_project_short_description' => array( 'label' => __( 'Descrizione breve', 'ticinoweb-child-theme' ), 'type' => 'textarea', 'sanitize' => 'sanitize_textarea_field', 'rest_type' => 'string' ),
		'tw_project_featured'          => array( 'label' => __( 'In evidenza nella Home', 'ticinoweb-child-theme' ), 'type' => 'checkbox', 'sanitize' => 'tw_home_sanitize_boolean', 'rest_type' => 'boolean' ),
		'tw_project_order'             => array( 'label' => __( 'Ordine nella Home', 'ticinoweb-child-theme' ), 'type' => 'number', 'sanitize' => 'absint', 'rest_type' => 'integer' ),
		'tw_project_service_keys'      => array( 'label' => __( 'Chiavi servizi', 'ticinoweb-child-theme' ), 'type' => 'text', 'sanitize' => 'tw_home_sanitize_key_list', 'rest_type' => 'array', 'description' => __( 'Slug separati da virgola, corrispondenti ai servizi del CMS.', 'ticinoweb-child-theme' ) ),
	);
}

/** Fields used by Founder and Team on the Home. */
function tw_home_team_fields() {
	return array(
		'tw_role'             => array( 'label' => __( 'Ruolo', 'ticinoweb-child-theme' ), 'type' => 'text', 'sanitize' => 'sanitize_text_field', 'rest_type' => 'string' ),
		'tw_full_bio'         => array( 'label' => __( 'Bio completa', 'ticinoweb-child-theme' ), 'type' => 'textarea', 'sanitize' => 'wp_kses_post', 'rest_type' => 'string' ),
		'tw_specializations'  => array( 'label' => __( 'Specializzazioni', 'ticinoweb-child-theme' ), 'type' => 'textarea', 'sanitize' => 'sanitize_textarea_field', 'rest_type' => 'string' ),
		'tw_languages'        => array( 'label' => __( 'Lingue parlate', 'ticinoweb-child-theme' ), 'type' => 'textarea', 'sanitize' => 'sanitize_textarea_field', 'rest_type' => 'string', 'description' => __( 'Indica le lingue parlate, separate da virgole.', 'ticinoweb-child-theme' ) ),
		'tw_experience_since' => array( 'label' => __( 'Attivo nel settore dal', 'ticinoweb-child-theme' ), 'type' => 'number', 'sanitize' => 'absint', 'rest_type' => 'integer' ),
		'tw_order'            => array( 'label' => __( 'Ordinamento', 'ticinoweb-child-theme' ), 'type' => 'number', 'sanitize' => 'absint', 'rest_type' => 'integer' ),
		'tw_active'           => array( 'label' => __( 'Attivo', 'ticinoweb-child-theme' ), 'type' => 'checkbox', 'sanitize' => 'tw_home_sanitize_boolean', 'rest_type' => 'boolean' ),
		'tw_founder'          => array( 'label' => __( 'Fondatore', 'ticinoweb-child-theme' ), 'type' => 'checkbox', 'sanitize' => 'tw_home_sanitize_boolean', 'rest_type' => 'boolean' ),
	);
}

/** Register Home-consumed meta keys without changing stored data. */
function tw_home_register_editorial_meta() {
	foreach ( array( 'tw_project' => tw_home_project_fields(), 'tw_team_member' => tw_home_team_fields() ) as $post_type => $fields ) {
		foreach ( $fields as $key => $field ) {
			$rest_type = $field['rest_type'];
			$show_in_rest = 'array' === $rest_type ? array( 'schema' => array( 'type' => 'array', 'items' => array( 'type' => 'string' ) ) ) : true;
			register_post_meta(
				$post_type,
				$key,
				array(
					'type'              => $rest_type,
					'single'            => true,
					'show_in_rest'      => $show_in_rest,
					'sanitize_callback' => $field['sanitize'],
					'auth_callback'     => static function () {
						return current_user_can( 'edit_posts' );
					},
				)
			);
		}
	}
}
add_action( 'init', 'tw_home_register_editorial_meta', 25 );

/** Render one secure group of existing meta fields. */
function tw_home_render_meta_box( $post, $fields, $nonce_action ) {
	wp_nonce_field( $nonce_action, '_tw_home_meta_nonce' );
	echo '<table class="form-table" role="presentation"><tbody>';
	foreach ( $fields as $key => $field ) {
		$value = get_post_meta( $post->ID, $key, true );
		echo '<tr><th scope="row"><label for="' . esc_attr( $key ) . '">' . esc_html( $field['label'] ) . '</label></th><td>';
		if ( 'textarea' === $field['type'] ) {
			echo '<textarea class="large-text" rows="5" id="' . esc_attr( $key ) . '" name="' . esc_attr( $key ) . '">' . esc_textarea( (string) $value ) . '</textarea>';
		} elseif ( 'checkbox' === $field['type'] ) {
			echo '<input type="checkbox" id="' . esc_attr( $key ) . '" name="' . esc_attr( $key ) . '" value="1" ' . checked( (bool) $value, true, false ) . '>';
		} else {
			$display = is_array( $value ) ? implode( ', ', $value ) : (string) $value;
			echo '<input class="regular-text" type="' . esc_attr( $field['type'] ) . '" id="' . esc_attr( $key ) . '" name="' . esc_attr( $key ) . '" value="' . esc_attr( $display ) . '">';
		}
		if ( ! empty( $field['description'] ) ) {
			echo '<p class="description">' . esc_html( $field['description'] ) . '</p>';
		}
		echo '</td></tr>';
	}
	echo '</tbody></table>';
}

/** Persist only whitelisted fields after nonce and capability checks. */
function tw_home_save_meta_box( $post_id, $fields, $nonce_action ) {
	$nonce = isset( $_POST['_tw_home_meta_nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['_tw_home_meta_nonce'] ) ) : '';
	if ( ! wp_verify_nonce( $nonce, $nonce_action ) || ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) || wp_is_post_revision( $post_id ) || ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}
	foreach ( $fields as $key => $field ) {
		if ( 'checkbox' === $field['type'] ) {
			update_post_meta( $post_id, $key, isset( $_POST[ $key ] ) ? '1' : '0' );
			continue;
		}
		if ( ! isset( $_POST[ $key ] ) ) {
			continue;
		}
		$value = call_user_func( $field['sanitize'], wp_unslash( $_POST[ $key ] ) );
		'' === $value ? delete_post_meta( $post_id, $key ) : update_post_meta( $post_id, $key, $value );
	}
}

/** Add and save the Project editing panel. */
function tw_home_add_project_meta_box() {
	add_meta_box( 'tw-home-project-details', __( 'Dati progetto ticinoWEB', 'ticinoweb-child-theme' ), static function ( $post ) {
		tw_home_render_meta_box( $post, tw_home_project_fields(), 'tw_home_save_project' );
	}, 'tw_project', 'normal', 'high' );
}
add_action( 'add_meta_boxes_tw_project', 'tw_home_add_project_meta_box' );
add_action( 'save_post_tw_project', static function ( $post_id ) {
	tw_home_save_meta_box( $post_id, tw_home_project_fields(), 'tw_home_save_project' );
} );

/** Add and save the Team editing panel. */
function tw_home_add_team_meta_box() {
	add_meta_box( 'tw-home-team-details', __( 'Dati collaboratore ticinoWEB', 'ticinoweb-child-theme' ), static function ( $post ) {
		tw_home_render_meta_box( $post, tw_home_team_fields(), 'tw_home_save_team' );
	}, 'tw_team_member', 'normal', 'high' );
}
add_action( 'add_meta_boxes_tw_team_member', 'tw_home_add_team_meta_box' );
add_action( 'save_post_tw_team_member', static function ( $post_id ) {
	tw_home_save_meta_box( $post_id, tw_home_team_fields(), 'tw_home_save_team' );
	if ( '1' !== (string) get_post_meta( $post_id, 'tw_founder', true ) ) {
		return;
	}
	$other_founders = get_posts(
		array(
			'post_type'      => 'tw_team_member',
			'post_status'    => 'any',
			'posts_per_page' => -1,
			'fields'         => 'ids',
			'post__not_in'   => array( $post_id ),
			'meta_key'       => 'tw_founder',
			'meta_value'     => '1',
		)
	);
	foreach ( $other_founders as $other_id ) {
		update_post_meta( $other_id, 'tw_founder', '0' );
	}
} );

/** Flush rewrites once per child version, after CPT/taxonomy registration. */
function tw_home_maybe_flush_rewrites() {
	$version = wp_get_theme()->get( 'Version' );
	if ( get_option( 'tw_home_rewrite_version' ) === $version ) {
		return;
	}
	flush_rewrite_rules( false );
	update_option( 'tw_home_rewrite_version', $version, false );
}
add_action( 'admin_init', 'tw_home_maybe_flush_rewrites' );
