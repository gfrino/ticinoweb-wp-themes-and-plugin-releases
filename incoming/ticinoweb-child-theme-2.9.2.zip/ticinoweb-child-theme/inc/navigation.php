<?php
/**
 * Navigazione premium e mega menu dinamici del child theme.
 *
 * @package ticinoWEB_Child_Theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Recupera un numero limitato di progetti reali per il pannello editoriale.
 */
function tw_nav_get_featured_projects( $limit = 3, $type_slug = '' ) {
	$limit     = min( 3, max( 1, absint( $limit ) ) );
	$type_slug = sanitize_title( $type_slug );
	$cache_key = $limit . ':' . $type_slug;
	static $cache = array();

	if ( isset( $cache[ $cache_key ] ) ) {
		return $cache[ $cache_key ];
	}

	$args = array(
		'post_type'      => 'tw_project',
		'post_status'    => 'publish',
		'posts_per_page' => min( 3, $limit ),
		'orderby'        => 'date',
		'order'          => 'DESC',
		'no_found_rows'  => true,
	);

	if ( $type_slug && term_exists( $type_slug, 'tw_project_type' ) ) {
		$args['tax_query'] = array(
			array(
				'taxonomy' => 'tw_project_type',
				'field'    => 'slug',
				'terms'    => array( $type_slug ),
			),
		);
	}

	$query = new WP_Query( $args );
	$cache[ $cache_key ] = array_map(
		static function ( $project ) {
			$types = wp_get_post_terms( $project->ID, 'tw_project_type', array( 'fields' => 'names' ) );
			return array(
				'id'       => (int) $project->ID,
				'title'    => get_the_title( $project ),
				'url'      => get_permalink( $project ),
				'image_id' => (int) get_post_thumbnail_id( $project ),
				'types'    => is_wp_error( $types ) ? array() : array_values( $types ),
			);
		},
		$query->posts
	);

	return $cache[ $cache_key ];
}

/**
 * Estrae una tipologia progetto valida dalle classi native del menu.
 */
function tw_nav_project_type_from_classes( $classes ) {
	foreach ( (array) $classes as $class ) {
		$class = sanitize_html_class( $class );
		if ( 0 !== strpos( $class, 'project-type-' ) ) {
			continue;
		}
		$slug = sanitize_title( substr( $class, strlen( 'project-type-' ) ) );
		if ( $slug && term_exists( $slug, 'tw_project_type' ) ) {
			return $slug;
		}
	}
	return '';
}

/**
 * Confronta la voce con la pagina Referenze configurata nel CMS.
 */
function tw_nav_is_references_item( $item ) {
	if ( ! function_exists( 'tw_home_mapped_url' ) ) {
		return false;
	}
	$references_url = tw_home_mapped_url( 'page_referenze', 'referenze' );
	return untrailingslashit( (string) $item->url ) === untrailingslashit( $references_url );
}

/**
 * Crea l'immagine differita di un progetto senza avviare richieste nascoste.
 */
function tw_nav_get_deferred_image_markup( $image_id ) {
	$image_id = absint( $image_id );
	$image    = $image_id ? wp_get_attachment_image_src( $image_id, 'medium_large' ) : false;
	if ( ! $image ) {
		return '';
	}

	$srcset = wp_get_attachment_image_srcset( $image_id, 'medium_large' );
	return sprintf(
		'<figure class="tw-mega-feature__media"><img data-deferred-image data-src="%1$s"%2$s alt="" width="%3$d" height="%4$d" decoding="async" sizes="(max-width: 1180px) 0px, 360px"></figure>',
		esc_url( $image[0] ),
		$srcset ? ' data-srcset="' . esc_attr( $srcset ) . '"' : '',
		(int) $image[1],
		(int) $image[2]
	);
}

/**
 * Renderizza un gruppo editoriale di progetti reali.
 */
function tw_nav_render_featured_projects( $projects, $key = 'default', $hidden = false ) {
	if ( empty( $projects ) ) {
		return;
	}
	?>
	<div class="tw-mega-feature__projects" data-featured-project="<?php echo esc_attr( $key ); ?>"<?php echo $hidden ? ' hidden' : ''; ?>>
		<?php foreach ( $projects as $project ) : ?>
			<article class="tw-mega-feature__project">
				<a href="<?php echo esc_url( $project['url'] ); ?>">
					<?php echo tw_nav_get_deferred_image_markup( $project['image_id'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
					<?php if ( ! empty( $project['types'] ) ) : ?><p><?php echo esc_html( implode( ' · ', $project['types'] ) ); ?></p><?php endif; ?>
					<p class="tw-mega-feature__title"><?php echo esc_html( $project['title'] ); ?></p>
					<span><?php esc_html_e( 'Scopri il progetto', 'ticinoweb-child-theme' ); ?> <span aria-hidden="true">↗</span></span>
				</a>
			</article>
		<?php endforeach; ?>
	</div>
	<?php
}

/**
 * Walker a tre livelli con supporto automatico per mega menu.
 */
class TW_Premium_Nav_Walker extends Walker_Nav_Menu {
	private $children_by_parent = array();
	private $descendant_counts = array();
	private $mega_roots = array();
	private $parent_by_id = array();
	private $items_by_id = array();
	private $parents_by_depth = array();
	private $project_type_by_item = array();
	private $project_types_by_root = array();

	/**
	 * Prepara l'albero prima che WordPress inizi il rendering ricorsivo.
	 */
	public function walk( $elements, $max_depth, ...$args ) {
		$this->children_by_parent   = array();
		$this->descendant_counts    = array();
		$this->mega_roots           = array();
		$this->parent_by_id         = array();
		$this->items_by_id          = array();
		$this->parents_by_depth     = array();
		$this->project_type_by_item = array();
		$this->project_types_by_root = array();

		foreach ( (array) $elements as $element ) {
			$id = (int) $element->ID;
			$parent = (int) $element->menu_item_parent;
			$this->items_by_id[ $id ] = $element;
			$this->parent_by_id[ $id ] = $parent;
			$this->children_by_parent[ $parent ][] = $id;
		}

		foreach ( $this->children_by_parent[0] ?? array() as $root_id ) {
			$count = $this->count_descendants( $root_id );
			$classes = (array) ( $this->items_by_id[ $root_id ]->classes ?? array() );
			if ( $count >= 4 || in_array( 'menu-mega', $classes, true ) ) {
				$this->mega_roots[ $root_id ] = true;
			}
		}

		foreach ( $this->items_by_id as $id => $item ) {
			$slug = tw_nav_project_type_from_classes( $item->classes ?? array() );
			if ( ! $slug ) {
				continue;
			}
			$this->project_type_by_item[ $id ] = $slug;
			$root_id = $this->find_root( $id );
			if ( isset( $this->mega_roots[ $root_id ] ) ) {
				$this->project_types_by_root[ $root_id ][ $slug ] = $slug;
			}
		}

		return parent::walk( $elements, $max_depth, ...$args );
	}

	private function count_descendants( $item_id ) {
		if ( isset( $this->descendant_counts[ $item_id ] ) ) {
			return $this->descendant_counts[ $item_id ];
		}
		$count = 0;
		foreach ( $this->children_by_parent[ $item_id ] ?? array() as $child_id ) {
			$count += 1 + $this->count_descendants( $child_id );
		}
		$this->descendant_counts[ $item_id ] = $count;
		return $count;
	}

	private function find_root( $item_id ) {
		$current = $item_id;
		while ( ! empty( $this->parent_by_id[ $current ] ) ) {
			$current = $this->parent_by_id[ $current ];
		}
		return $current;
	}

	private function is_mega_item( $item ) {
		return 0 === (int) $item->menu_item_parent && isset( $this->mega_roots[ (int) $item->ID ] );
	}

	/**
	 * Apre il pannello relativo alla voce padre corrente.
	 */
	public function start_lvl( &$output, $depth = 0, $args = null ) {
		$parent = $this->parents_by_depth[ $depth ] ?? null;
		if ( ! $parent ) {
			return;
		}
		$panel_id = 'tw-nav-panel-' . absint( $parent->ID );
		$trigger_id = 'tw-nav-trigger-' . absint( $parent->ID );
		if ( 0 === $depth && $this->is_mega_item( $parent ) ) {
			$output .= '<div id="' . esc_attr( $panel_id ) . '" class="tw-menu-panel tw-mega-menu" data-menu-panel data-mega-menu aria-labelledby="' . esc_attr( $trigger_id ) . '"><div class="tw-shell tw-mega-menu__inner"><ul class="sub-menu tw-mega-menu__navigation">';
			return;
		}
		$output .= '<ul id="' . esc_attr( $panel_id ) . '" class="sub-menu tw-menu-panel" data-menu-panel aria-labelledby="' . esc_attr( $trigger_id ) . '">';
	}

	/**
	 * Chiude il pannello e aggiunge l'area editoriale ai mega menu.
	 */
	public function end_lvl( &$output, $depth = 0, $args = null ) {
		$parent = $this->parents_by_depth[ $depth ] ?? null;
		if ( 0 === $depth && $parent && $this->is_mega_item( $parent ) ) {
			$output .= '</ul>';
			ob_start();
			$this->render_featured_area( $parent );
			$output .= ob_get_clean();
			$output .= '</div></div>';
			return;
		}
		$output .= '</ul>';
	}

	/**
	 * Renderizza una singola voce mantenendo filtri e attributi WordPress.
	 */
	public function start_el( &$output, $item, $depth = 0, $args = null, $current_object_id = 0 ) {
		$this->parents_by_depth[ $depth ] = $item;
		$item_id = absint( $item->ID );
		$has_children = ! empty( $this->children_by_parent[ $item_id ] );
		$classes = array_filter( array_map( 'sanitize_html_class', (array) $item->classes ) );
		$classes[] = 'menu-item';
		$classes[] = 'menu-item-' . $item_id;
		if ( $has_children ) {
			$classes[] = 'menu-item-has-children';
		}
		if ( $this->is_mega_item( $item ) ) {
			$classes[] = 'menu-item--mega';
		}
		$classes = array_unique( $classes );

		$output .= '<li class="' . esc_attr( implode( ' ', $classes ) ) . '"';
		if ( isset( $this->project_type_by_item[ $item_id ] ) ) {
			$output .= ' data-project-type="' . esc_attr( $this->project_type_by_item[ $item_id ] ) . '"';
		}
		$output .= '><span class="tw-nav-item__line">';

		$attributes = array(
			'title'        => $item->attr_title ?? '',
			'target'       => $item->target ?? '',
			'rel'          => $item->xfn ?? '',
			'href'         => $item->url ?? '',
			'aria-current' => $item->current ? 'page' : '',
		);
		if ( isset( $this->project_type_by_item[ $item_id ] ) ) {
			$attributes['data-feature-project'] = $this->project_type_by_item[ $item_id ];
		}
		$attributes = apply_filters( 'nav_menu_link_attributes', $attributes, $item, $args, $depth );
		$attribute_html = '';
		foreach ( $attributes as $attribute => $value ) {
			if ( '' === (string) $value ) {
				continue;
			}
			$value = 'href' === $attribute ? esc_url( $value ) : esc_attr( $value );
			$attribute_html .= ' ' . $attribute . '="' . $value . '"';
		}

		$title = apply_filters( 'the_title', $item->title, $item->ID );
		$title = apply_filters( 'nav_menu_item_title', $title, $item, $args, $depth );
		$item_output = ( $args->before ?? '' ) . '<a' . $attribute_html . '>' . ( $args->link_before ?? '' ) . esc_html( $title ) . ( $args->link_after ?? '' ) . '</a>' . ( $args->after ?? '' );
		$output .= apply_filters( 'walker_nav_menu_start_el', $item_output, $item, $depth, $args );

		if ( $has_children ) {
			$panel_id = 'tw-nav-panel-' . $item_id;
			$label = sprintf( __( 'Apri il sottomenu %s', 'ticinoweb-child-theme' ), wp_strip_all_tags( $title ) );
			$output .= '<button id="tw-nav-trigger-' . esc_attr( (string) $item_id ) . '" class="tw-submenu-toggle" type="button" aria-expanded="false" aria-controls="' . esc_attr( $panel_id ) . '" aria-label="' . esc_attr( $label ) . '" data-submenu-toggle';
			if ( 0 === $depth ) {
				$output .= ' data-menu-trigger';
			}
			$output .= '><span aria-hidden="true">+</span></button>';
		}
		$output .= '</span>';
	}

	public function end_el( &$output, $item, $depth = 0, $args = null ) {
		$output .= '</li>';
	}

	/**
	 * Colonna editoriale alimentata dai progetti del CMS.
	 */
	private function render_featured_area( $parent ) {
		$is_references = tw_nav_is_references_item( $parent );
		$projects = tw_nav_get_featured_projects( $is_references ? 3 : 1 );
		?>
		<aside class="tw-mega-feature" aria-label="<?php esc_attr_e( 'Progetti in evidenza', 'ticinoweb-child-theme' ); ?>" data-mega-feature>
			<p class="tw-mega-feature__eyebrow"><?php echo esc_html( $is_references ? __( 'Progetti selezionati', 'ticinoweb-child-theme' ) : __( 'Dal nostro studio', 'ticinoweb-child-theme' ) ); ?></p>
			<?php tw_nav_render_featured_projects( $projects ); ?>
			<?php foreach ( $this->project_types_by_root[ (int) $parent->ID ] ?? array() as $slug ) : ?>
				<?php tw_nav_render_featured_projects( tw_nav_get_featured_projects( 1, $slug ), $slug, true ); ?>
			<?php endforeach; ?>
		</aside>
		<?php
	}
}
