(() => {
	'use strict';

	const OPEN_DELAY = 120;
	const CLOSE_DELAY = 200;
	const PANEL_TRANSITION = 240;
	const FEATURE_TRANSITION = 170;
	const header = document.querySelector('[data-site-header]');
	const toggle = document.querySelector('[data-menu-toggle]');
	const nav = document.querySelector('[data-primary-nav]');
	const cta = document.querySelector('[data-header-cta]');
	const desktopMedia = window.matchMedia('(min-width: 1181px)');
	const focusableSelector = 'a[href], button:not([disabled]), [tabindex]:not([tabindex="-1"])';
	let activeDesktopItem = null;
	let openTimer = null;
	let closeTimer = null;
	let lastFocused = null;
	let suppressFocusOpen = false;
	const panelHideTimers = new WeakMap();
	const featureSwitchTimers = new WeakMap();

	if (!header || !toggle || !nav) return;

	const directPanel = (item) => item?.querySelector(':scope > [data-menu-panel]');
	const directTrigger = (item) => item?.querySelector(':scope > .tw-nav-item__line > [data-submenu-toggle]');
	const clearDesktopTimers = () => {
		window.clearTimeout(openTimer);
		window.clearTimeout(closeTimer);
		openTimer = null;
		closeTimer = null;
	};
	const clearPanelHideTimer = (panel) => {
		const timer = panel ? panelHideTimers.get(panel) : null;
		if (timer) window.clearTimeout(timer);
		if (panel) panelHideTimers.delete(panel);
	};

	const hydratePanelMedia = (panel) => {
		panel?.querySelectorAll('[data-src]').forEach((image) => {
			if (image.closest('[hidden]')) return;
			image.src = image.dataset.src;
			if (image.dataset.srcset) image.srcset = image.dataset.srcset;
			image.removeAttribute('data-src');
			image.removeAttribute('data-srcset');
		});
		panel?.classList.add('is-hydrated');
	};

	const closeDesktopPanel = (item, returnFocus = false) => {
		if (!item) return;
		const trigger = directTrigger(item);
		const panel = directPanel(item);
		item.classList.remove('is-open');
		trigger?.setAttribute('aria-expanded', 'false');
		if (panel) {
			clearPanelHideTimer(panel);
			const timer = window.setTimeout(() => {
				if (!item.classList.contains('is-open')) panel.hidden = true;
				panelHideTimers.delete(panel);
			}, PANEL_TRANSITION);
			panelHideTimers.set(panel, timer);
		}
		if (returnFocus && trigger) {
			clearDesktopTimers();
			suppressFocusOpen = true;
			trigger.focus();
			window.requestAnimationFrame(() => { suppressFocusOpen = false; });
		}
		if (activeDesktopItem === item) activeDesktopItem = null;
	};

	const openDesktopPanel = (item) => {
		const trigger = directTrigger(item);
		const panel = directPanel(item);
		if (!trigger || !panel || !desktopMedia.matches) return;
		clearDesktopTimers();
		if (activeDesktopItem && activeDesktopItem !== item) closeDesktopPanel(activeDesktopItem);
		clearPanelHideTimer(panel);
		panel.hidden = false;
		trigger.setAttribute('aria-expanded', 'true');
		window.requestAnimationFrame(() => item.classList.add('is-open'));
		hydratePanelMedia(panel);
		activeDesktopItem = item;
	};

	const scheduleDesktopOpen = (item) => {
		clearDesktopTimers();
		openTimer = window.setTimeout(() => openDesktopPanel(item), OPEN_DELAY);
	};
	const scheduleDesktopClose = (item) => {
		clearDesktopTimers();
		closeTimer = window.setTimeout(() => closeDesktopPanel(item), CLOSE_DELAY);
	};

	const closeMobileSubmenu = (item, returnFocus = false) => {
		const trigger = directTrigger(item);
		const panel = directPanel(item);
		item?.classList.remove('is-mobile-open');
		trigger?.setAttribute('aria-expanded', 'false');
		if (panel) panel.hidden = true;
		item?.querySelectorAll('.is-mobile-open').forEach((child) => closeMobileSubmenu(child));
		if (returnFocus) trigger?.focus();
	};

	const closeSiblingSubmenus = (item) => {
		const list = item.parentElement;
		list?.querySelectorAll(':scope > .menu-item.is-mobile-open').forEach((sibling) => {
			if (sibling !== item) closeMobileSubmenu(sibling);
		});
	};

	const openMobileSubmenu = (item) => {
		const trigger = directTrigger(item);
		const panel = directPanel(item);
		if (!trigger || !panel) return;
		closeSiblingSubmenus(item);
		panel.hidden = false;
		item.classList.add('is-mobile-open');
		trigger.setAttribute('aria-expanded', 'true');
	};

	const setMobileMenu = (open, returnFocus = true) => {
		if (open) closeDesktopPanel(activeDesktopItem);
		toggle.setAttribute('aria-expanded', String(open));
		toggle.setAttribute('aria-label', open ? toggle.dataset.closeLabel : toggle.dataset.openLabel);
		header.classList.toggle('is-menu-open', open);
		nav.classList.toggle('is-open', open);
		document.body.classList.toggle('tw-menu-open', open);
		if (open) {
			lastFocused = document.activeElement;
			const first = nav.querySelector(focusableSelector);
			if (first) window.requestAnimationFrame(() => first.focus());
		} else {
			nav.querySelectorAll('.is-mobile-open').forEach((item) => closeMobileSubmenu(item));
			if (returnFocus) (lastFocused instanceof HTMLElement ? lastFocused : toggle).focus();
		}
	};

	const showFeaturedProject = (link) => {
		const mega = link.closest('[data-mega-menu]');
		if (!mega) return;
		const groups = [...mega.querySelectorAll('[data-featured-project]')];
		const key = link.dataset.featureProject || 'default';
		const requested = groups.find((group) => group.dataset.featuredProject === key) || groups.find((group) => group.dataset.featuredProject === 'default');
		if (!requested) return;
		const previousTimer = featureSwitchTimers.get(mega);
		if (previousTimer) window.clearTimeout(previousTimer);
		groups.forEach((group) => group.classList.remove('is-featured-entering', 'is-featured-leaving'));
		const current = groups.find((group) => !group.hidden);
		if (!current || current === requested) {
			groups.forEach((group) => { group.hidden = group !== requested; });
			hydratePanelMedia(requested);
			return;
		}
		current.classList.add('is-featured-leaving');
		const timer = window.setTimeout(() => {
			groups.forEach((group) => {
				group.hidden = group !== requested;
				group.classList.remove('is-featured-leaving', 'is-featured-entering');
			});
			requested.classList.add('is-featured-entering');
			hydratePanelMedia(requested);
			window.requestAnimationFrame(() => requested.classList.remove('is-featured-entering'));
			featureSwitchTimers.delete(mega);
		}, FEATURE_TRANSITION);
		featureSwitchTimers.set(mega, timer);
	};

	const initializePanels = () => {
		clearDesktopTimers();
		closeDesktopPanel(activeDesktopItem);
		setMobileMenu(false, false);
		nav.querySelectorAll('[data-menu-panel]').forEach((panel) => {
			const item = panel.closest('.menu-item');
			const nestedInMega = Boolean(item?.parentElement?.closest('[data-mega-menu]'));
			const trigger = directTrigger(item);
			const keepOpen = desktopMedia.matches && nestedInMega;
			panel.hidden = !keepOpen;
			trigger?.setAttribute('aria-expanded', String(keepOpen));
			item?.classList.remove('is-open', 'is-mobile-open');
		});
	};

	const topLevelItems = [...nav.querySelectorAll(':scope > ul > .menu-item-has-children')];
	topLevelItems.forEach((item) => {
		item.addEventListener('pointerenter', () => { if (desktopMedia.matches) scheduleDesktopOpen(item); });
		item.addEventListener('pointerleave', () => { if (desktopMedia.matches) scheduleDesktopClose(item); });
		item.addEventListener('focusin', () => { if (desktopMedia.matches && !suppressFocusOpen) scheduleDesktopOpen(item); });
		item.addEventListener('focusout', (event) => {
			if (desktopMedia.matches && !item.contains(event.relatedTarget)) scheduleDesktopClose(item);
		});
	});

	nav.addEventListener('click', (event) => {
		const submenuToggle = event.target.closest('[data-submenu-toggle]');
		if (submenuToggle) {
			const item = submenuToggle.closest('.menu-item');
			if (desktopMedia.matches && submenuToggle.hasAttribute('data-menu-trigger')) {
				activeDesktopItem === item ? closeDesktopPanel(item, true) : openDesktopPanel(item);
			} else if (!desktopMedia.matches) {
				item.classList.contains('is-mobile-open') ? closeMobileSubmenu(item, true) : openMobileSubmenu(item);
			}
			return;
		}
		const link = event.target.closest('a');
		if (link?.closest('[data-mega-menu]')) showFeaturedProject(link);
		if (link && !desktopMedia.matches) setMobileMenu(false, false);
	});

	nav.addEventListener('pointerover', (event) => {
		const link = event.target.closest('a');
		if (desktopMedia.matches && link?.closest('[data-mega-menu]')) showFeaturedProject(link);
	});
	nav.addEventListener('focusin', (event) => {
		const link = event.target.closest('a');
		if (desktopMedia.matches && link?.closest('[data-mega-menu]')) showFeaturedProject(link);
	});

	toggle.addEventListener('click', () => setMobileMenu(toggle.getAttribute('aria-expanded') !== 'true'));
	document.addEventListener('click', (event) => {
		if (desktopMedia.matches && activeDesktopItem && !event.target.closest('[data-site-header]')) closeDesktopPanel(activeDesktopItem);
	});
	document.addEventListener('keydown', (event) => {
		if (event.key === 'Escape') {
			if (activeDesktopItem) {
				closeDesktopPanel(activeDesktopItem, true);
				return;
			}
			const openSubmenus = [...nav.querySelectorAll('.menu-item.is-mobile-open')];
			if (openSubmenus.length) {
				closeMobileSubmenu(openSubmenus[openSubmenus.length - 1], true);
				return;
			}
			if (toggle.getAttribute('aria-expanded') === 'true') setMobileMenu(false);
		}
		if (event.key !== 'Tab' || desktopMedia.matches || toggle.getAttribute('aria-expanded') !== 'true') return;
		const focusable = [...nav.querySelectorAll(focusableSelector), cta, toggle].filter((item) => item instanceof HTMLElement && item.offsetParent !== null);
		if (!focusable.length) return;
		const first = focusable[0];
		const last = focusable[focusable.length - 1];
		if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
		if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
	});

	const updateHeader = () => header.classList.toggle('is-scrolled', window.scrollY > 24);
	window.addEventListener('scroll', updateHeader, { passive: true });
	desktopMedia.addEventListener('change', initializePanels);
	updateHeader();
	initializePanels();
})();
