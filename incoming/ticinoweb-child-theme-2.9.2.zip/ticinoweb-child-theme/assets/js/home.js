(() => {
	'use strict';

	const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
	const HERO_VIDEO_FADE_MS = 520;
	const HERO_VIDEO_LOOP_LEAD = 0.75;
	if (!reduceMotion) {
		document.documentElement.classList.add('tw-home-enhanced');
		const revealItems = document.querySelectorAll('[data-home-reveal]');
		if ('IntersectionObserver' in window) {
			const revealObserver = new IntersectionObserver((entries, observer) => {
				entries.forEach((entry) => {
					if (!entry.isIntersecting) return;
					entry.target.classList.add('is-visible');
					observer.unobserve(entry.target);
				});
			}, { rootMargin: '0px 0px -8% 0px', threshold: 0.08 });
			revealItems.forEach((item) => revealObserver.observe(item));
		} else {
			revealItems.forEach((item) => item.classList.add('is-visible'));
		}
	}

	document.querySelectorAll('[data-service-index]').forEach((index) => {
		const triggers = [...index.querySelectorAll('[data-service-trigger]')];
		const panels = [...index.querySelectorAll('[data-service-panel]')];
		const activate = (value) => {
			triggers.forEach((trigger) => {
				const active = trigger.dataset.serviceTrigger === value;
				trigger.setAttribute('aria-expanded', String(active));
				trigger.closest('.tw-service-index__item')?.classList.toggle('is-active', active);
			});
			panels.forEach((panel) => {
				const active = panel.dataset.servicePanel === value;
				panel.hidden = !active;
				panel.classList.toggle('is-active', active);
			});
		};
		triggers.forEach((trigger) => {
			trigger.addEventListener('click', () => activate(trigger.dataset.serviceTrigger));
			trigger.addEventListener('mouseenter', () => {
				if (window.matchMedia('(min-width: 961px)').matches) activate(trigger.dataset.serviceTrigger);
			});
		});
	});

	const hero = document.querySelector('[data-hero-slider]');
	if (!hero) return;
	const slides = [...hero.querySelectorAll('[data-hero-slide]')];
	const heroVideos = [...hero.querySelectorAll('[data-hero-video]')];
	const videoLoopTimers = new WeakMap();

	const playHeroVideo = (video) => {
		const playRequest = video.play();
		if (playRequest?.catch) playRequest.catch(() => {});
	};
	const cancelHeroVideoLoop = (video) => {
		const timer = videoLoopTimers.get(video);
		if (timer) window.clearTimeout(timer);
		videoLoopTimers.delete(video);
		video.classList.remove('is-loop-fading');
		video.dataset.looping = 'false';
	};
	const startHeroVideoLoop = (video) => {
		if (reduceMotion || video.dataset.looping === 'true' || !video.closest('[data-hero-slide]')?.classList.contains('is-active')) return;
		video.dataset.looping = 'true';
		video.classList.add('is-loop-fading');
		const timer = window.setTimeout(() => {
			video.currentTime = 0;
			if (!document.hidden && video.closest('[data-hero-slide]')?.classList.contains('is-active')) playHeroVideo(video);
			window.requestAnimationFrame(() => window.requestAnimationFrame(() => {
				video.classList.remove('is-loop-fading');
				video.dataset.looping = 'false';
				videoLoopTimers.delete(video);
			}));
		}, HERO_VIDEO_FADE_MS);
		videoLoopTimers.set(video, timer);
	};
	const synchronizeHeroVideos = () => {
		heroVideos.forEach((video) => {
			video.muted = true;
			const active = video.closest('[data-hero-slide]')?.classList.contains('is-active');
			if (reduceMotion || document.hidden || !active) {
				cancelHeroVideoLoop(video);
				video.pause();
				if (reduceMotion && video.readyState >= 1) video.currentTime = 0;
				return;
			}
			playHeroVideo(video);
		});
	};
	heroVideos.forEach((video) => {
		video.addEventListener('timeupdate', () => {
			if (Number.isFinite(video.duration) && video.duration - video.currentTime <= HERO_VIDEO_LOOP_LEAD) startHeroVideoLoop(video);
		});
		video.addEventListener('ended', () => startHeroVideoLoop(video));
		if (reduceMotion) video.addEventListener('loadedmetadata', () => { video.pause(); video.currentTime = 0; }, { once: true });
	});
	window.requestAnimationFrame(() => {
		window.requestAnimationFrame(() => document.documentElement.classList.add('tw-hero-loaded'));
	});
	synchronizeHeroVideos();
	document.addEventListener('visibilitychange', synchronizeHeroVideos);

	document.querySelectorAll('[data-hero-rotator]').forEach((rotator) => {
		const terms = [...rotator.querySelectorAll('[data-hero-term]')];
		if (reduceMotion || terms.length < 2) return;
		const interval = Math.min(10000, Math.max(1800, Number.parseInt(rotator.dataset.interval || '3200', 10)));
		let current = 0;
		let changeTimer = null;
		let transitionTimer = null;
		let pending = null;

		const clearTimers = () => {
			if (changeTimer) window.clearTimeout(changeTimer);
			if (transitionTimer) window.clearTimeout(transitionTimer);
			changeTimer = null;
			transitionTimer = null;
		};
		const schedule = (delay = interval) => {
			if (document.hidden) return;
			if (changeTimer) window.clearTimeout(changeTimer);
			changeTimer = window.setTimeout(swap, delay);
		};
		const finishSwap = () => {
			if (!pending) return;
			const { outgoing, incoming, next } = pending;
			outgoing.classList.remove('is-current', 'is-leaving');
			incoming.classList.remove('is-entering');
			incoming.classList.add('is-current');
			current = next;
			pending = null;
			transitionTimer = null;
			schedule();
		};
		function swap() {
			changeTimer = null;
			const next = (current + 1) % terms.length;
			const outgoing = terms[current];
			const incoming = terms[next];
			pending = { outgoing, incoming, next };
			outgoing.classList.add('is-leaving');
			incoming.classList.add('is-entering');
			transitionTimer = window.setTimeout(finishSwap, 660);
		}

		document.addEventListener('visibilitychange', () => {
			if (document.hidden) {
				clearTimers();
				finishSwap();
			} else {
				schedule();
			}
		});
		// L'ingresso Hero dura circa 900 ms: il primo cambio arriva ~1,9 s dopo la sua conclusione.
		schedule(2800);
	});

	if (!reduceMotion && window.matchMedia('(min-width: 768px)').matches) {
		let parallaxFrame = null;
		const updateHeroShift = () => {
			parallaxFrame = null;
			const bounds = hero.getBoundingClientRect();
			if (bounds.bottom <= 0 || bounds.top >= window.innerHeight) return;
			const shift = Math.min(18, Math.max(0, window.scrollY * 0.045));
			hero.style.setProperty('--tw-hero-shift', `${shift}px`);
		};
		const requestHeroShift = () => {
			if (parallaxFrame === null) parallaxFrame = window.requestAnimationFrame(updateHeroShift);
		};
		window.addEventListener('scroll', requestHeroShift, { passive: true });
		updateHeroShift();
	}

	if (slides.length < 2) return;
	const previous = hero.querySelector('[data-hero-prev]');
	const next = hero.querySelector('[data-hero-next]');
	const autoplayToggle = hero.querySelector('[data-hero-toggle]');
	const currentLabel = hero.querySelector('[data-hero-current]');
	let current = 0;
	let timer = null;
	let pointerStart = null;
	let userPaused = reduceMotion;

	const show = (target) => {
		current = (target + slides.length) % slides.length;
		slides.forEach((slide, index) => {
			const active = index === current;
			slide.classList.toggle('is-active', active);
			slide.setAttribute('aria-hidden', String(!active));
		});
		if (currentLabel) currentLabel.textContent = String(current + 1).padStart(2, '0');
		synchronizeHeroVideos();
	};
	const stop = () => { if (timer) window.clearInterval(timer); timer = null; };
	const updateAutoplayControl = () => {
		if (!autoplayToggle) return;
		autoplayToggle.setAttribute('aria-pressed', String(userPaused));
		autoplayToggle.setAttribute('aria-label', userPaused ? autoplayToggle.dataset.playLabel : autoplayToggle.dataset.pauseLabel);
		autoplayToggle.textContent = userPaused ? '▶' : 'Ⅱ';
	};
	const start = () => {
		stop();
		if (!userPaused && !document.hidden) timer = window.setInterval(() => show(current + 1), 8000);
	};
	const pauseFromInteraction = () => { userPaused = true; stop(); updateAutoplayControl(); };
	previous?.addEventListener('click', () => { show(current - 1); pauseFromInteraction(); });
	next?.addEventListener('click', () => { show(current + 1); pauseFromInteraction(); });
	autoplayToggle?.addEventListener('click', () => {
		userPaused = !userPaused;
		updateAutoplayControl();
		userPaused ? stop() : start();
	});
	hero.addEventListener('mouseenter', stop);
	hero.addEventListener('mouseleave', start);
	hero.addEventListener('focusin', stop);
	hero.addEventListener('focusout', start);
	hero.addEventListener('pointerdown', (event) => { pointerStart = event.clientX; });
	hero.addEventListener('pointerup', (event) => {
		if (pointerStart === null) return;
		const distance = event.clientX - pointerStart;
		pointerStart = null;
		if (Math.abs(distance) > 55) { show(current + (distance < 0 ? 1 : -1)); pauseFromInteraction(); }
	});
	document.addEventListener('visibilitychange', () => {
		document.hidden ? stop() : start();
	});
	updateAutoplayControl();
	start();
})();
