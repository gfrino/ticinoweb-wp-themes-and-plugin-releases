<?php
$tw_footer_contact   = function_exists( 'ticinoweb_get_contact_info' ) ? ticinoweb_get_contact_info() : array();
$tw_footer_services  = tw_home_get_services();
$tw_footer_partners  = tw_home_get_partners();
$tw_footer_icon      = (string) get_option( 'ticinoweb_site_icon', '' );
$tw_footer_icon_id   = $tw_footer_icon ? attachment_url_to_postid( $tw_footer_icon ) : 0;
$tw_footer_locations = array(
	'footer-company'    => __( 'Azienda e sedi', 'ticinoweb-child-theme' ),
	'footer-services'   => __( 'Servizi', 'ticinoweb-child-theme' ),
	'footer-actions'    => __( 'Strumenti', 'ticinoweb-child-theme' ),
	'footer-commitment' => __( 'Il nostro impegno sociale', 'ticinoweb-child-theme' ),
);
?>
<footer class="tw-site-footer">
	<div class="tw-shell tw-footer-lead">
		<div class="tw-footer-brand">
			<?php if ( $tw_footer_icon_id ) : ?><?php echo wp_get_attachment_image( $tw_footer_icon_id, 'medium', false, array( 'class' => 'tw-footer-brand__logo', 'alt' => 'ticinoWEB', 'loading' => 'lazy', 'decoding' => 'async', 'sizes' => '112px' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?><?php elseif ( $tw_footer_icon ) : ?><img class="tw-footer-brand__logo" src="<?php echo esc_url( $tw_footer_icon ); ?>" alt="ticinoWEB" width="112" height="112" loading="lazy" decoding="async"><?php endif; ?>
			<div><p class="tw-footer-brand__eyebrow">ticinoWEB</p><p><?php esc_html_e( 'Web Design e soluzioni digitali progettate a Locarno per aziende che vogliono crescere.', 'ticinoweb-child-theme' ); ?></p></div>
		</div>
		<div class="tw-footer-contact">
			<h2><?php esc_html_e( 'Parliamone.', 'ticinoweb-child-theme' ); ?></h2>
			<address>
				<?php if ( ! empty( $tw_footer_contact['address'] ) ) : ?><span><?php echo esc_html( $tw_footer_contact['address'] ); ?></span><?php endif; ?>
				<?php if ( ! empty( $tw_footer_contact['phone'] ) ) : ?><a href="tel:<?php echo esc_attr( preg_replace( '/[^+0-9]/', '', $tw_footer_contact['phone'] ) ); ?>"><?php echo esc_html( $tw_footer_contact['phone'] ); ?></a><?php endif; ?>
				<?php if ( ! empty( $tw_footer_contact['email'] ) ) : ?><a href="mailto:<?php echo esc_attr( antispambot( $tw_footer_contact['email'] ) ); ?>"><?php echo esc_html( antispambot( $tw_footer_contact['email'] ) ); ?></a><?php endif; ?>
			</address>
			<div class="tw-footer-social"><?php foreach ( array( 'instagram' => 'Instagram', 'linkedin' => 'LinkedIn', 'facebook' => 'Facebook' ) as $tw_network => $tw_label ) : ?><?php if ( ! empty( $tw_footer_contact[ $tw_network ] ) ) : ?><a href="<?php echo esc_url( $tw_footer_contact[ $tw_network ] ); ?>" rel="noopener noreferrer"><?php echo esc_html( $tw_label ); ?></a><?php endif; ?><?php endforeach; ?></div>
		</div>
	</div>

	<div class="tw-shell tw-footer-grid">
		<?php foreach ( $tw_footer_locations as $tw_location => $tw_heading ) : ?>
			<details class="tw-footer-section" open><summary><?php echo esc_html( $tw_heading ); ?></summary>
				<?php if ( has_nav_menu( $tw_location ) ) : ?><?php wp_nav_menu( array( 'theme_location' => $tw_location, 'container' => false, 'menu_class' => 'tw-footer-menu', 'fallback_cb' => false, 'depth' => 2 ) ); ?>
				<?php elseif ( 'footer-services' === $tw_location ) : ?><ul class="tw-footer-menu"><?php foreach ( $tw_footer_services as $tw_service ) : ?><?php if ( ! empty( $tw_service['url'] ) ) : ?><li><a href="<?php echo esc_url( $tw_service['url'] ); ?>"><?php echo esc_html( $tw_service['short_name'] ?? $tw_service['title'] ); ?></a></li><?php endif; ?><?php endforeach; ?></ul>
				<?php endif; ?>
			</details>
		<?php endforeach; ?>
	</div>

	<?php if ( $tw_footer_partners ) : ?><div class="tw-shell tw-footer-partners" aria-label="<?php esc_attr_e( 'Partner e certificazioni', 'ticinoweb-child-theme' ); ?>"><?php foreach ( $tw_footer_partners as $tw_partner ) : ?><?php if ( $tw_partner['url'] ) : ?><a href="<?php echo esc_url( $tw_partner['url'] ); ?>" target="_blank" rel="noopener noreferrer"><?php else : ?><span><?php endif; ?><?php if ( $tw_partner['image_id'] ) : ?><?php echo wp_get_attachment_image( $tw_partner['image_id'], 'medium', false, array( 'alt' => $tw_partner['label'] ?? '', 'loading' => 'lazy', 'decoding' => 'async', 'sizes' => '140px' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?><?php else : ?><img src="<?php echo esc_url( $tw_partner['logo'] ); ?>" alt="<?php echo esc_attr( $tw_partner['label'] ?? '' ); ?>" width="140" height="52" loading="lazy" decoding="async"><?php endif; ?><?php if ( $tw_partner['url'] ) : ?></a><?php else : ?></span><?php endif; ?><?php endforeach; ?></div><?php endif; ?>

	<div class="tw-shell tw-footer-utility">
		<div class="tw-footer-search"><h2><?php esc_html_e( 'Cerca nel sito', 'ticinoweb-child-theme' ); ?></h2><?php get_search_form(); ?></div>
		<details class="tw-footer-section tw-footer-section--legal" open><summary><?php esc_html_e( 'Informazioni legali', 'ticinoweb-child-theme' ); ?></summary><?php if ( has_nav_menu( 'footer-legal' ) ) : ?><?php wp_nav_menu( array( 'theme_location' => 'footer-legal', 'container' => false, 'menu_class' => 'tw-footer-menu tw-footer-menu--inline', 'fallback_cb' => false, 'depth' => 1 ) ); ?><?php elseif ( get_privacy_policy_url() ) : ?><ul class="tw-footer-menu tw-footer-menu--inline"><li><a href="<?php echo esc_url( get_privacy_policy_url() ); ?>"><?php esc_html_e( 'Privacy', 'ticinoweb-child-theme' ); ?></a></li></ul><?php endif; ?></details>
	</div>
	<div class="tw-shell tw-footer-bottom"><span>© <?php echo esc_html( gmdate( 'Y' ) ); ?> ticinoWEB</span><span><?php esc_html_e( 'Locarno · Ticino · Switzerland', 'ticinoweb-child-theme' ); ?></span></div>
</footer>
<?php wp_footer(); ?>
</body>
</html>
