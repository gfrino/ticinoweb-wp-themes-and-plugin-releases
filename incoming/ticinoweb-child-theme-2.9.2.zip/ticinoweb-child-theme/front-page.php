<?php
/**
 * THESIS: ticinoWEB dimostra la propria competenza attraverso prove reali, non attraverso claim astratti.
 * OWN-WORLD: fogli di prova digitali, carta calda, Ink, griglia svizzera, blu ticinoWEB e segni arancio rari.
 * STORY: promessa → progetti → fiducia → servizi → metodo → persone → recensioni → insight → contatto.
 * FIRST VIEWPORT: header integrato e Hero fotografico CMS con l'inizio dei progetti già percepibile.
 * FORM: Digital Proof Studio, quinta direzione assegnata dal seed 4c0ee11d; composizione editoriale asimmetrica.
 *
 * @package ticinoWEB_Child_Theme
 */

get_header();
$tw_home = tw_home_get_view_model();
?>
<main class="tw-home">
	<?php
	foreach ( array( 'hero', 'reviews', 'projects', 'trust', 'services', 'method', 'people', 'insights', 'final-cta' ) as $tw_section ) {
		get_template_part( 'template-parts/home/' . $tw_section, null, $tw_home );
	}
	?>
</main>
<?php
get_footer();
