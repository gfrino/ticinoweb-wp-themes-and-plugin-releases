<?php
/**
 * Funzioni comuni: testi tradotti dal livello del parent, icone SVG, selettore della lingua.
 */
defined('ABSPATH') || exit;

/**
 * Testi che non finiscono come testo visibile nella pagina (attributi, messaggi degli script):
 * passano dal livello di traduzione del parent, così tW Translate li traduce come gli altri.
 */
function grottoraffael_t($text, $key)
{
    return function_exists('ticinoweb_frontend_text') ? ticinoweb_frontend_text($text, 'grottoraffael:' . $key) : $text;
}

/** Icone in linea (niente font di icone, niente richieste esterne). */
function grottoraffael_icon($name, $size = 16)
{
    $paths = array(
        'gift'      => '<path d="M20 12v9H4v-9M2 7h20v5H2zM12 21V7M12 7H7.5a2.5 2.5 0 1 1 0-5C11 2 12 7 12 7zm0 0h4.5a2.5 2.5 0 1 0 0-5C13 2 12 7 12 7z" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/>',
        'check'     => '<path d="m4 12.5 5 5L20 6.5" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"/>',
        'wine'      => '<path d="M10 2h4v4.5c0 1 2 2 2 4.5v10a1 1 0 0 1-1 1H9a1 1 0 0 1-1-1V11c0-2.5 2-3.5 2-4.5z" fill="currentColor"/>',
        'book'      => '<path d="M2 5c3-1.3 6.5-1.3 9.2.6V20c-2.7-1.6-6.2-1.6-9.2-.4zM22 5c-3-1.3-6.5-1.3-9.2.6V20c2.7-1.6 6.2-1.6 9.2-.4z" fill="currentColor"/>',
        'facebook'  => '<path d="M20 2H4a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h8.6v-7.7H10V11.3h2.6V9.1c0-2.6 1.6-4 3.9-4 1.1 0 2 .1 2.3.1v2.7h-1.6c-1.3 0-1.5.6-1.5 1.5v1.9h3l-.4 3h-2.6V22H20a2 2 0 0 0 2-2V4a2 2 0 0 0-2-2z" fill="currentColor"/>',
        'instagram' => '<rect x="3" y="3" width="18" height="18" rx="5" fill="none" stroke="currentColor" stroke-width="2"/><circle cx="12" cy="12" r="4" fill="none" stroke="currentColor" stroke-width="2"/><circle cx="17.3" cy="6.7" r="1.2" fill="currentColor"/>',
        'phone'     => '<path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1 1 .4 1.9.7 2.8a2 2 0 0 1-.5 2.1L8.1 9.9a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.4c.9.3 1.8.6 2.8.7a2 2 0 0 1 1.7 2z" fill="currentColor"/>',
        'mobile'    => '<rect x="6" y="2" width="12" height="20" rx="2.5" fill="currentColor"/><rect x="8" y="4.5" width="8" height="13" fill="#fff"/><circle cx="12" cy="19.6" r="1" fill="#fff"/>',
        'dot'       => '<circle cx="12" cy="12" r="9" fill="none" stroke="currentColor" stroke-width="2.4"/><circle cx="12" cy="12" r="4" fill="currentColor"/>',
        'quote'     => '<path d="M10 6H5.5A2.5 2.5 0 0 0 3 8.5V13a2 2 0 0 0 2 2h3c0 2-1 3-3 3.5V21c4-.5 6-3.3 6-7.5V7a1 1 0 0 0-1-1zm11 0h-4.5A2.5 2.5 0 0 0 14 8.5V13a2 2 0 0 0 2 2h3c0 2-1 3-3 3.5V21c4-.5 6-3.3 6-7.5V7a1 1 0 0 0-1-1z" fill="currentColor"/>',
        'star'      => '<path d="m12 2.5 2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 17.4l-5.9 3.1 1.2-6.5-4.8-4.6 6.6-.9z" fill="currentColor"/>',
        'play'      => '<circle cx="12" cy="12" r="10.5" fill="none" stroke="currentColor" stroke-width="1.4"/><path d="M9.5 7.5v9l7-4.5z" fill="currentColor"/>',
        'chevron'   => '<path d="m6 9 6 6 6-6" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/>',
        'close'     => '<path d="M6 6l12 12M18 6 6 18" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"/>',
        'left'      => '<path d="m15 5-7 7 7 7" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/>',
        'right'     => '<path d="m9 5 7 7-7 7" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/>',
        'users' => '<g fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="9" cy="8" r="3.2"/><path d="M3 20c0-3.3 2.7-6 6-6s6 2.7 6 6"/><circle cx="17" cy="9" r="2.6"/><path d="M15.6 14.2c3 .2 5.4 2.6 5.4 5.8"/></g>',
        'grotto' => '<g fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M3 11 12 4l9 7"/><path d="M5 10v10h14V10"/><path d="M10 20v-5a2 2 0 0 1 4 0v5"/></g>',
        'menu' => '<g fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M7 3v8a2 2 0 0 0 2 2v8"/><path d="M11 3v8a2 2 0 0 1-2 2"/><path d="M9 3v6"/><path d="M17 21V3c-2 1.5-3 4-3 7 0 2 1 3 3 3"/></g>',
        'camera' => '<g fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M4 8h3l2-3h6l2 3h3a1 1 0 0 1 1 1v10a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V9a1 1 0 0 1 1-1z"/><circle cx="12" cy="13.5" r="3.5"/></g>',
        'cheers' => '<g fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M6 3h5l-.6 5.5A2.6 2.6 0 0 1 7.8 11h-.6A2.6 2.6 0 0 1 4.6 8.5L4 3"/><path d="M7.5 11v7M5 21h5"/><path d="M14 5h5l-.6 5.5a2.6 2.6 0 0 1-2.6 2.5h-.6a2.6 2.6 0 0 1-2.6-2.5L12.4 5" transform="translate(1 0)"/><path d="M16.5 13v5M14 21h5"/></g>',
        'music' => '<g fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M9 18V5l11-2v13"/><circle cx="6.5" cy="18" r="2.5"/><circle cx="17.5" cy="16" r="2.5"/></g>',
        'mountain' => '<g fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M2 20 9 7l4 7 2-3 7 9z"/><path d="m7.5 10 1.5 1.5L10.5 10"/></g>',
        'mail' => '<g fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3.5 6.5 8.5 7 8.5-7"/></g>',
        'bag' => '<g fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M5 8h14l-1 12H6z"/><path d="M9 8V6a3 3 0 0 1 6 0v2"/></g>',
        'glass' => '<g fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M7 3h10l-.5 6a4.5 4.5 0 0 1-9 0z"/><path d="M12 13.5V20M8 21h8"/></g>',
        'flower' => '<g fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="9" r="2"/><path d="M12 7a2.5 2.5 0 1 1 2.4-3.2A2.5 2.5 0 1 1 15 8.5a2.5 2.5 0 1 1-1.7 4.1A2.5 2.5 0 1 1 9 11.4 2.5 2.5 0 1 1 9.6 6 2.5 2.5 0 0 1 12 7z"/><path d="M12 11v10M12 17c-2 0-4-1-5-3M12 19c2 0 4-1 5-3"/></g>',
        'sun' => '<g fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/></g>',
        'leaf' => '<g fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M5 19c0-9 6-14 15-15-1 9-6 15-15 15z"/><path d="M5 19 14 10"/></g>',
        'pages' => '<g fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M3 5.5c3-1.2 6-1 9 1V20c-3-2-6-2.2-9-1z"/><path d="M21 5.5c-3-1.2-6-1-9 1V20c3-2 6-2.2 9-1z"/></g>',
        'cart'      => '<path d="M3 4h2.5l2.2 10.2a1.5 1.5 0 0 0 1.5 1.2h8.4a1.5 1.5 0 0 0 1.5-1.1L21 8H6.3" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/><circle cx="9.5" cy="19.5" r="1.5" fill="currentColor"/><circle cx="17.5" cy="19.5" r="1.5" fill="currentColor"/>',
    );
    if (!isset($paths[$name])) {
        return '';
    }
    return '<svg class="gr-icon gr-icon--' . esc_attr($name) . '" viewBox="0 0 24 24" width="' . (int) $size . '" height="' . (int) $size . '" aria-hidden="true" focusable="false">' . $paths[$name] . '</svg>';
}

/**
 * Selettore della lingua di tW Translate Plus come sull'originale: bandiera della lingua corrente
 * con una freccia, le altre bandiere in una tendina. Vuoto con una sola lingua o senza il plugin.
 * $variant «flags» = solo le bandiere delle altre lingue in fila (fondo del footer);
 * «row» = tutte le bandiere in fila, quella attiva segnata (header).
 */
function grottoraffael_language_switcher($variant = 'dropdown')
{
    if (!function_exists('twtr_get_languages')) {
        return '<!-- grottoraffael: tW Translate Plus non attivo, nessun selettore lingua -->';
    }
    $languages = twtr_get_languages();
    if (count($languages) < 2) {
        return '';
    }
    $flag = function ($lang) {
        $url = class_exists('Twtr_Switcher') ? Twtr_Switcher::flag_url($lang['slug']) : '';
        return $url ? '<img class="gr-lang__flag" src="' . esc_url($url) . '" alt="' . esc_attr($lang['label']) . '" width="18" height="12">' : '<span class="gr-lang__code">' . esc_html(strtoupper($lang['slug'])) . '</span>';
    };
    $link = function ($lang) use ($flag) {
        return '<a href="' . esc_url($lang['url']) . '" hreflang="' . esc_attr(str_replace('_', '-', $lang['locale'])) . '" lang="' . esc_attr($lang['slug']) . '" title="' . esc_attr($lang['label']) . '">' . $flag($lang) . '</a>';
    };
    $current = null;
    $others = '';
    $all = '';
    foreach ($languages as $lang) {
        if ($lang['is_current']) {
            $current = $lang;
            // Fila dell'header: la lingua attiva resta in fila, segnata e non cliccabile.
            $all .= '<li class="is-current"><span aria-current="true" title="' . esc_attr($lang['label']) . '">' . $flag($lang) . '</span></li>';
            continue;
        }
        $others .= '<li>' . $link($lang) . '</li>';
        $all .= '<li>' . $link($lang) . '</li>';
    }
    $current = $current ?: reset($languages);
    if ($variant === 'flags') {
        return '<ul class="gr-lang-flags">' . $others . '</ul>';
    }
    if ($variant === 'row') {
        return '<ul class="gr-lang-row" aria-label="' . esc_attr(grottoraffael_t(__('Lingua', 'grottoraffael-child-theme'), 'lang:label')) . '">' . $all . '</ul>';
    }
    return '<details class="gr-lang"><summary aria-label="' . esc_attr(grottoraffael_t(__('Lingua', 'grottoraffael-child-theme'), 'lang:label') . ': ' . $current['label']) . '">'
        . $flag($current) . grottoraffael_icon('chevron', 12) . '</summary><ul>' . $others . '</ul></details>';
}

/** Link «Buono Regalo» dell'header: la pagina con il template o lo slug «buono-regalo». */
function grottoraffael_voucher_url()
{
    $page = get_page_by_path('buono-regalo');
    return $page ? get_permalink($page) : '';
}

/** Numero di telefono per i link tel: (solo cifre e +). */
function grottoraffael_tel($number)
{
    return 'tel:' . preg_replace('/[^\d+]/', '', (string) $number);
}

/**
 * Fascia con foto, titolo e i due segni ai lati (Il Grotto, Contatto, Banchetti, Shop).
 * Le pagine la scrivono nel contenuto con lo stesso HTML.
 */
function grottoraffael_banner($title, $image_id = 0, $class = '')
{
    $img = $image_id ? wp_get_attachment_image($image_id, 'full', false, array('class' => 'gr-banner__image', 'alt' => '', 'fetchpriority' => 'high', 'loading' => 'eager', 'sizes' => '100vw')) : '';
    return '<section class="gr-banner ' . esc_attr($class) . '">' . $img
        . '<h1 class="gr-banner__title">' . esc_html($title) . '</h1></section>';
}

/** Link al menù classico nella lingua della pagina (Aspetto → Personalizza → Grotto Raffael). */
function grottoraffael_localize_pdf($html)
{
    if (!function_exists('twtr_get_current_language')) {
        return $html;
    }
    $lang = twtr_get_current_language();
    $base = (int) get_theme_mod('grottoraffael_menu_pdf_base', 0);
    $local = (int) get_theme_mod('grottoraffael_menu_pdf_' . $lang, 0);
    if (!$base || !$local) {
        return $html;
    }
    $from = wp_get_attachment_url($base);
    $to = wp_get_attachment_url($local);
    return ($from && $to) ? str_replace($from, $to, $html) : $html;
}
add_filter('wp_nav_menu', 'grottoraffael_localize_pdf');
add_filter('the_content', 'grottoraffael_localize_pdf', 20);
