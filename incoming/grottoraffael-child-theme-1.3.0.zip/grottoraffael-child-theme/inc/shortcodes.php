<?php
/**
 * Shortcode delle pagine. Dati sempre dal database: gallerie del parent (Media → Gallerie media),
 * contatti del CMS (ticinoweb_contact_*), immagini della libreria.
 */
defined('ABSPATH') || exit;

/**
 * Galleria di foto con apertura a schermo intero.
 * [gr_galleria scheda="galleria" colonne="4"] — «scheda» è lo slug della galleria in Gallerie media;
 * l'ordine è quello scelto nel gestore delle gallerie del parent.
 */
add_shortcode('gr_galleria', function ($atts) {
    $atts = shortcode_atts(array('scheda' => '', 'colonne' => '4', 'stile' => ''), $atts, 'gr_galleria');
    $term = get_term_by('slug', sanitize_title($atts['scheda']), 'ticinoweb_media_gallery');
    if (!$term) {
        return current_user_can('edit_pages') ? '<p class="gr-notice">' . esc_html(sprintf(__('Galleria «%s» non trovata: creala in Media → Gallerie media.', 'grottoraffael-child-theme'), $atts['scheda'])) . '</p>' : '';
    }
    $ids = get_posts(array(
        'post_type'      => 'attachment',
        'post_status'    => 'inherit',
        'posts_per_page' => 200,
        'fields'         => 'ids',
        'orderby'        => 'menu_order ID',
        'order'          => 'ASC',
        'no_found_rows'  => true,
        'tax_query'      => array(array('taxonomy' => 'ticinoweb_media_gallery', 'field' => 'term_id', 'terms' => $term->term_id)),
    ));
    $order = get_term_meta($term->term_id, '_ticinoweb_gallery_order', true);
    if (is_array($order) && $order) {
        $pos = array_flip(array_map('intval', $order));
        usort($ids, function ($a, $b) use ($pos) {
            return ($pos[$a] ?? PHP_INT_MAX) <=> ($pos[$b] ?? PHP_INT_MAX);
        });
    }
    if (!$ids) {
        return '';
    }
    $cols = max(1, min(8, (int) $atts['colonne']));
    $class = 'gr-gallery' . ($atts['stile'] === 'striscia' ? ' gr-gallery--strip' : '');
    $html = '<div class="' . esc_attr($class) . '" style="--gr-cols:' . $cols . '" data-gr-lightbox>';
    foreach ($ids as $id) {
        $full = wp_get_attachment_image_url($id, 'full');
        $alt = trim((string) get_post_meta($id, '_wp_attachment_image_alt', true));
        $html .= '<a class="gr-gallery__item" href="' . esc_url($full) . '">'
            . wp_get_attachment_image($id, 'medium_large', false, array('loading' => 'lazy', 'sizes' => '(max-width: 767px) 50vw, ' . round(100 / $cols) . 'vw', 'alt' => $alt))
            . '</a>';
    }
    return $html . '</div>';
});

/**
 * Telefoni ed email del CMS in elenco con icone (pagina Contatto).
 * Una riga compare solo se il dato è compilato in ticinoWEB CMS.
 */
add_shortcode('gr_contatti', function () {
    $c = function_exists('ticinoweb_get_contact_info') ? ticinoweb_get_contact_info() : array();
    $rows = array();
    $landline = ($c['phone_landline'] ?? '') ?: ($c['phone'] ?? '');
    if ($landline) {
        $rows[] = array('phone', __('T:', 'grottoraffael-child-theme') . ' ' . $landline, grottoraffael_tel($landline));
    }
    if (!empty($c['phone_mobile'])) {
        $rows[] = array('mobile', __('M:', 'grottoraffael-child-theme') . ' ' . $c['phone_mobile'], grottoraffael_tel($c['phone_mobile']));
    }
    if (!empty($c['email'])) {
        // Niente antispambot(): mescola l'indirizzo in modo diverso a ogni visita, e tW Translate vede ogni volta
        // una pagina «nuova» da tradurre (e la toglie da Google finché non è tradotta).
        $rows[] = array('dot', __('Email:', 'grottoraffael-child-theme') . ' ' . $c['email'], 'mailto:' . $c['email']);
    }
    if (!$rows) {
        return '';
    }
    $html = '<ul class="gr-contact-list">';
    foreach ($rows as $row) {
        $html .= '<li><a href="' . esc_url($row[2]) . '">' . grottoraffael_icon($row[0], 14) . '<span>' . esc_html($row[1]) . '</span></a></li>';
    }
    return $html . '</ul>';
});

/**
 * Mappa Google che si carica solo al clic: fino ad allora nessuna richiesta a Google e nessun cookie.
 * [gr_mappa indirizzo="…" altezza="450"] — senza indirizzo usa quello del CMS.
 */
add_shortcode('gr_mappa', function ($atts) {
    $atts = shortcode_atts(array('indirizzo' => '', 'altezza' => '450', 'zoom' => '16'), $atts, 'gr_mappa');
    $c = function_exists('ticinoweb_get_contact_info') ? ticinoweb_get_contact_info() : array();
    $address = trim((string) $atts['indirizzo']) !== '' ? trim((string) $atts['indirizzo']) : trim(get_bloginfo('name') . ', ' . ($c['address'] ?? ''), ' ,');
    if ($address === '') {
        return '';
    }
    $embed = 'https://maps.google.com/maps?q=' . rawurlencode($address) . '&z=' . (int) $atts['zoom'] . '&ie=UTF8&iwloc=&output=embed';
    return '<div class="gr-map" style="--gr-map-h:' . max(200, (int) $atts['altezza']) . 'px" data-gr-embed="' . esc_url($embed) . '" data-gr-title="' . esc_attr(grottoraffael_t(__('Mappa', 'grottoraffael-child-theme'), 'map:title')) . '">'
        . '<div class="gr-map__consent"><p>' . esc_html__('La mappa è di Google Maps: si carica solo se la chiedi, e Google riceve allora il tuo indirizzo IP e può usare i suoi cookie.', 'grottoraffael-child-theme') . '</p>'
        . '<button type="button" class="gr-btn gr-map__load">' . esc_html__('Mostra la mappa', 'grottoraffael-child-theme') . '</button></div></div>';
});

/**
 * Video di YouTube con anteprima: il video (youtube-nocookie) si apre solo al clic.
 * [gr_video url="https://youtu.be/…" immagine="ID allegato"]
 */
add_shortcode('gr_video', function ($atts) {
    $atts = shortcode_atts(array('url' => '', 'immagine' => ''), $atts, 'gr_video');
    if (!preg_match('~(?:youtu\.be/|v=|embed/)([A-Za-z0-9_-]{6,})~', (string) $atts['url'], $m)) {
        return '';
    }
    $embed = 'https://www.youtube-nocookie.com/embed/' . $m[1] . '?autoplay=1&rel=0';
    $img = $atts['immagine'] ? wp_get_attachment_image((int) $atts['immagine'], 'large', false, array('loading' => 'lazy', 'alt' => '')) : '';
    return '<button type="button" class="gr-video" data-gr-video="' . esc_url($embed) . '" aria-label="' . esc_attr(grottoraffael_t(__('Guarda il video', 'grottoraffael-child-theme'), 'video:play')) . '">'
        . $img . '<span class="gr-video__play">' . grottoraffael_icon('play', 64) . '</span></button>';
});

/**
 * Icone delle voci di menu (menu principale, sua tendina e footer «Menù»): classe CSS della voce «gr-ico-<nome>»,
 * per esempio gr-ico-wine, gr-ico-camera (nomi in grottoraffael_icon()). Senza classe la voce resta solo testo.
 */
add_filter('nav_menu_item_title', function ($title, $item, $args) {
    $locations = array('grottoraffael_footer_menu' => 14, 'primary' => 17);
    if (empty($args->theme_location) || !isset($locations[$args->theme_location])) {
        return $title;
    }
    foreach ((array) $item->classes as $class) {
        if (strpos((string) $class, 'gr-ico-') === 0) {
            $icon = grottoraffael_icon(substr($class, 7), $locations[$args->theme_location]);
            return $icon !== '' ? $icon . '<span class="gr-menu-label">' . $title . '</span>' : $title;
        }
    }
    return $title;
}, 10, 3);

/** Stelle delle recensioni scritte nella pagina: [gr_stelle n="5"]. */
add_shortcode('gr_stelle', function ($atts) {
    $n = max(0, min(5, (int) shortcode_atts(array('n' => '5'), $atts)['n']));
    return '<span class="gr-stars" role="img" aria-label="' . esc_attr(sprintf(grottoraffael_t(__('%d stelle su 5', 'grottoraffael-child-theme'), 'stars'), $n)) . '">' . str_repeat(grottoraffael_icon('star', 14), $n) . '</span>';
});

/** Icona del tema dentro il testo di una pagina: [gr_icona nome="check"]. */
add_shortcode('gr_icona', function ($atts) {
    $atts = shortcode_atts(array('nome' => '', 'misura' => '14'), $atts, 'gr_icona');
    return grottoraffael_icon(sanitize_key($atts['nome']), (int) $atts['misura']);
});
