<?php
/**
 * Grotto Raffael: child di ticinoWEB CMS (ticinoweb-ai-theme), senza Elementor.
 * Contatti, SEO, cookie, FAQ, gallerie e form restano nel parent e nei plugin ticinoWEB
 * (tW Translate Plus per le lingue, tW Formulari per il buono regalo).
 */
defined('ABSPATH') || exit;

define('GROTTORAFFAEL_VERSION', wp_get_theme(get_stylesheet())->get('Version'));

require_once get_stylesheet_directory() . '/inc/helpers.php';
require_once get_stylesheet_directory() . '/inc/shortcodes.php';
require_once get_stylesheet_directory() . '/inc/popup.php';
require_once get_stylesheet_directory() . '/inc/shop.php';

add_action('after_setup_theme', function () {
    load_child_theme_textdomain('grottoraffael-child-theme', get_stylesheet_directory() . '/languages');
    add_post_type_support('page', 'excerpt');
    register_nav_menus(array(
        'grottoraffael_footer_menu'  => __('Footer: menù e carte (PDF)', 'grottoraffael-child-theme'),
        'grottoraffael_footer_links' => __('Footer: link', 'grottoraffael-child-theme'),
        'grottoraffael_legal'        => __('Footer: note legali', 'grottoraffael-child-theme'),
    ));
}, 20);

/**
 * Stili: il parent stampa già lo style.css del child; qui si mette il suo style.css come dipendenza
 * e si versiona tutto con la versione del child (ogni rilascio svuota la cache del browser).
 */
add_action('wp_enqueue_scripts', function () {
    wp_enqueue_style('grottoraffael-parent', get_template_directory_uri() . '/style.css', array(), wp_get_theme(get_template())->get('Version'));
    if (isset(wp_styles()->registered['ticinoweb-ai-style'])) {
        wp_styles()->registered['ticinoweb-ai-style']->deps[] = 'grottoraffael-parent';
        wp_styles()->registered['ticinoweb-ai-style']->ver = GROTTORAFFAEL_VERSION;
    }
    // Caratteri inclusi nel tema (assets/fonts): il Poppins del parent non si scarica da Google.
    if (isset(wp_styles()->registered['poppins-font'])) {
        wp_styles()->registered['poppins-font']->src = false;
    }
    wp_enqueue_script('grottoraffael-site', get_stylesheet_directory_uri() . '/assets/js/site.js', array(), GROTTORAFFAEL_VERSION, array('in_footer' => true, 'strategy' => 'defer'));
    // Movimento: GSAP e ScrollTrigger inclusi nel tema (nessuna richiesta a CDN esterni), caricati in fondo e differiti.
    $vendor = get_stylesheet_directory_uri() . '/assets/vendor/gsap/';
    wp_enqueue_script('gsap', $vendor . 'gsap.min.js', array(), '3.13.0', array('in_footer' => true, 'strategy' => 'defer'));
    wp_enqueue_script('gsap-scrolltrigger', $vendor . 'ScrollTrigger.min.js', array('gsap'), '3.13.0', array('in_footer' => true, 'strategy' => 'defer'));
    wp_enqueue_script('grottoraffael-motion', get_stylesheet_directory_uri() . '/assets/js/motion.js', array('gsap', 'gsap-scrolltrigger'), GROTTORAFFAEL_VERSION, array('in_footer' => true, 'strategy' => 'defer'));
    wp_localize_script('grottoraffael-site', 'grottoRaffael', array(
        'close' => grottoraffael_t(__('Chiudi', 'grottoraffael-child-theme'), 'ui:close'),
        'prev'  => grottoraffael_t(__('Foto precedente', 'grottoraffael-child-theme'), 'ui:prev'),
        'next'  => grottoraffael_t(__('Foto successiva', 'grottoraffael-child-theme'), 'ui:next'),
    ));
}, 20);

/** Caratteri precaricati: il titolo della home e il menu li usano subito. */
add_action('wp_head', function () {
    printf('<link rel="preload" href="%s" as="font" type="font/woff2" crossorigin>' . "\n", esc_url(get_stylesheet_directory_uri() . '/assets/fonts/josefin-sans.woff2'));
}, 1);

/** Le pagine fatte a sezioni (classi gr-*) sono HTML pronto: niente paragrafi automatici. */
add_filter('the_content', function ($content) {
    if (is_singular() && strpos($content, 'class="gr-') !== false) {
        remove_filter('the_content', 'wpautop');
    }
    return $content;
}, 9);

/** Emoji di WordPress: scaricherebbero immagini da s.w.org prima del consenso ai cookie. */
remove_action('wp_head', 'print_emoji_detection_script', 7);
remove_action('wp_print_styles', 'print_emoji_styles');
add_filter('emoji_svg_url', '__return_false');
