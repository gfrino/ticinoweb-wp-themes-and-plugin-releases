/**
 * Grotto Raffael: menu da telefono, tendine del menu, foto a schermo intero, video e mappe al clic, popup.
 */
(function () {
  'use strict';
  var i18n = window.grottoRaffael || { close: 'Chiudi', prev: '‹', next: '›' };

  /* Menu da telefono e tablet */
  var toggle = document.querySelector('.gr-menu-toggle');
  var nav = document.getElementById('gr-nav');
  if (toggle && nav) {
    toggle.addEventListener('click', function () {
      var open = toggle.getAttribute('aria-expanded') !== 'true';
      toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
      document.body.classList.toggle('gr-nav-open', open);
    });
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && document.body.classList.contains('gr-nav-open')) {
        toggle.click();
        toggle.focus();
      }
    });
  }

  /* Voci con sottomenu: su telefono e tastiera si aprono con un clic sulla voce senza link («Menù») */
  document.querySelectorAll('.gr-nav__menu .menu-item-has-children > a').forEach(function (a) {
    a.setAttribute('aria-haspopup', 'true');
    a.setAttribute('aria-expanded', 'false');
    var li = a.parentNode;
    a.addEventListener('click', function (e) {
      var href = a.getAttribute('href') || '';
      if (href === '#' || href === '' || window.matchMedia('(max-width: 1024px)').matches) {
        e.preventDefault();
        var open = !li.classList.contains('is-open');
        li.classList.toggle('is-open', open);
        a.setAttribute('aria-expanded', open ? 'true' : 'false');
      }
    });
    // Solo con il mouse: sui telefoni il tocco su un'altra voce «esce» dalla tendina, che si chiuderebbe
    // spostando le voci sotto il dito (il tocco su «Shop» finiva sulla foto della home).
    if (window.matchMedia('(hover: hover) and (pointer: fine)').matches) {
      li.addEventListener('mouseleave', function () {
        if (window.matchMedia('(max-width: 1024px)').matches) return;
        li.classList.remove('is-open');
        a.setAttribute('aria-expanded', 'false');
      });
    }
  });

  /* Finestra a schermo intero: foto delle gallerie e video */
  var dialog = null;
  var items = [];
  var index = 0;

  function button(cls, label, svg) {
    var b = document.createElement('button');
    b.type = 'button';
    b.className = cls;
    b.setAttribute('aria-label', label);
    b.innerHTML = '<svg viewBox="0 0 24 24" width="28" height="28" aria-hidden="true"><path d="' + svg + '" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/></svg>';
    return b;
  }

  function ensureDialog() {
    if (dialog) return dialog;
    dialog = document.createElement('dialog');
    dialog.className = 'gr-lightbox';
    dialog.innerHTML = '<div class="gr-lightbox__stage"></div>';
    var close = button('gr-lightbox__close', i18n.close, 'M6 6l12 12M18 6 6 18');
    var prev = button('gr-lightbox__prev', i18n.prev, 'm15 5-7 7 7 7');
    var next = button('gr-lightbox__next', i18n.next, 'm9 5 7 7-7 7');
    close.addEventListener('click', function () { dialog.close(); });
    prev.addEventListener('click', function () { show(index - 1); });
    next.addEventListener('click', function () { show(index + 1); });
    // I pulsanti prima del contenuto: all'apertura il cursore va sulla crocetta e non dentro il video,
    // così Esc chiude la finestra anche con YouTube aperto.
    dialog.prepend(close, prev, next);
    dialog.addEventListener('click', function (e) { if (e.target === dialog) dialog.close(); });
    dialog.addEventListener('close', function () { dialog.querySelector('.gr-lightbox__stage').innerHTML = ''; });
    dialog.addEventListener('keydown', function (e) {
      if (e.key === 'ArrowLeft') show(index - 1);
      if (e.key === 'ArrowRight') show(index + 1);
    });
    document.body.appendChild(dialog);
    return dialog;
  }

  function show(i) {
    if (!items.length) return;
    index = (i + items.length) % items.length;
    var a = items[index];
    var img = document.createElement('img');
    img.src = a.getAttribute('href');
    var thumb = a.querySelector('img');
    img.alt = thumb ? thumb.alt : '';
    var stage = dialog.querySelector('.gr-lightbox__stage');
    stage.innerHTML = '';
    stage.appendChild(img);
  }

  document.querySelectorAll('[data-gr-lightbox]').forEach(function (gallery) {
    var links = Array.prototype.slice.call(gallery.querySelectorAll('a'));
    links.forEach(function (a, i) {
      a.addEventListener('click', function (e) {
        e.preventDefault();
        ensureDialog();
        items = links;
        dialog.classList.remove('is-video');
        dialog.classList.toggle('is-single', links.length < 2);
        show(i);
        dialog.showModal();
      });
    });
  });

  /* Video: al clic suona dentro la pagina, al posto dell'anteprima (prima del clic nessuna richiesta a YouTube) */
  document.querySelectorAll('[data-gr-video]').forEach(function (btn) {
    btn.addEventListener('click', function () {
      var box = document.createElement('div');
      box.className = 'gr-video-frame';
      var frame = document.createElement('iframe');
      frame.src = btn.getAttribute('data-gr-video');
      frame.title = btn.getAttribute('aria-label') || '';
      frame.allow = 'autoplay; encrypted-media; picture-in-picture; fullscreen';
      frame.allowFullscreen = true;
      box.appendChild(frame);
      btn.replaceWith(box);
      frame.focus();
    });
  });

  /* Mappa di Google solo al clic */
  document.querySelectorAll('.gr-map').forEach(function (map) {
    var load = map.querySelector('.gr-map__load');
    if (!load) return;
    load.addEventListener('click', function () {
      var frame = document.createElement('iframe');
      frame.src = map.getAttribute('data-gr-embed');
      frame.title = map.getAttribute('data-gr-title') || '';
      frame.loading = 'lazy';
      frame.referrerPolicy = 'no-referrer-when-downgrade';
      map.innerHTML = '';
      map.appendChild(frame);
      map.classList.add('is-loaded');
    });
  });

  /* Popup della home: una volta per visita */
  var popup = document.querySelector('[data-gr-popup]');
  if (popup && typeof popup.showModal === 'function') {
    var key = 'gr-popup-' + popup.getAttribute('data-gr-popup');
    var seen = false;
    try { seen = sessionStorage.getItem(key) === '1'; } catch (e) { seen = false; }
    if (!seen) {
      setTimeout(function () { popup.showModal(); }, 2000);
    }
    popup.addEventListener('close', function () {
      try { sessionStorage.setItem(key, '1'); } catch (e) { /* senza memoria il popup ricompare: va bene */ }
    });
    popup.querySelectorAll('[data-gr-close]').forEach(function (b) {
      b.addEventListener('click', function () { popup.close(); });
    });
    popup.addEventListener('click', function (e) { if (e.target === popup) popup.close(); });
  }
})();
