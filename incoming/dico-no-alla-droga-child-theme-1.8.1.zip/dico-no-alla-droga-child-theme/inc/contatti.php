<?php
/**
 * Contatti: i nominativi raccolti dal «Modulo di raccolta dati» diventano schede in Bacheca → Contatti.
 *
 * Il modulo è di tW Formulari (opzione dnd_form_raccolta). A ogni invio il tema crea una scheda «Contatto» con i
 * dati della persona, l'iscrizione alla newsletter e di cosa si è parlato. Il testo originale resta anche in
 * «Compilazioni» di tW Formulari. La scheda si può correggere e arricchire con note interne.
 * I dati sono personali: la sezione è visibile solo agli amministratori.
 */

if (!defined('ABSPATH')) {
    exit;
}

const DND_CONTATTO_TYPE = 'dnd_contatto';

function dnd_contatto_td() {
    return 'dico-no-alla-droga-child-theme';
}

/** Campi della scheda: chiave => etichetta. */
function dnd_contatto_ruoli() {
    return array('Insegnante', 'Dirigente scolastico', 'Operatore giovanile o sociale', 'Genitore', 'Rappresentante di un’associazione o di un ente', 'Altro');
}

function dnd_contatto_meta($id, $k) {
    return get_post_meta($id, '_dndc_' . $k, true);
}

/** Solo gli amministratori vedono e gestiscono i contatti. */
add_filter('user_has_cap', function ($allcaps) {
    if (!empty($allcaps['manage_options'])) {
        foreach (array('edit_dnd_contatto', 'read_dnd_contatto', 'delete_dnd_contatto', 'edit_dnd_contatti', 'edit_others_dnd_contatti', 'publish_dnd_contatti', 'read_private_dnd_contatti', 'delete_dnd_contatti', 'delete_private_dnd_contatti', 'delete_published_dnd_contatti', 'delete_others_dnd_contatti', 'edit_private_dnd_contatti', 'edit_published_dnd_contatti') as $cap) {
            $allcaps[$cap] = true;
        }
    }
    return $allcaps;
});

add_action('init', function () {
    $td = dnd_contatto_td();
    register_post_type(DND_CONTATTO_TYPE, array(
        'labels' => array(
            'name'               => __('Contatti', $td),
            'singular_name'      => __('Contatto', $td),
            'menu_name'          => __('Contatti', $td),
            'all_items'          => __('Tutti i contatti', $td),
            'add_new'            => __('Aggiungi contatto', $td),
            'add_new_item'       => __('Nuovo contatto', $td),
            'edit_item'          => __('Scheda contatto', $td),
            'search_items'       => __('Cerca contatti', $td),
            'not_found'          => __('Nessun contatto ancora. Compaiono qui da soli quando si compila il «Modulo di raccolta dati».', $td),
            'not_found_in_trash' => __('Nessun contatto nel cestino.', $td),
        ),
        'public'              => false,
        'show_ui'             => true,
        'show_in_menu'        => true,
        'show_in_rest'        => false,
        'menu_position'       => 24,
        'menu_icon'           => 'dashicons-id-alt',
        'capability_type'     => array('dnd_contatto', 'dnd_contatti'),
        'map_meta_cap'        => true,
        'supports'            => array('title'),
        'exclude_from_search' => true,
        'rewrite'             => false,
    ));
});

/** Dal modulo pubblico alla scheda. */
add_action('twf_submission_completed', function ($form_id, $entry_id, $values) {
    $fid = (int) get_option('dnd_form_raccolta');
    if (!$fid || (int) $form_id !== $fid) {
        return;
    }
    $txt = function ($k) use ($values) {
        $v = isset($values[$k]) ? $values[$k] : '';
        if (is_array($v)) {
            if (isset($v['first']) || isset($v['last'])) {
                return trim((isset($v['first']) ? $v['first'] : '') . ' ' . (isset($v['last']) ? $v['last'] : ''));
            }
            return implode(', ', array_map('strval', $v));
        }
        return trim((string) $v);
    };
    $nome = $txt('nome');
    $id = wp_insert_post(array(
        'post_type'   => DND_CONTATTO_TYPE,
        'post_status' => 'publish',
        'post_title'  => $nome !== '' ? sanitize_text_field($nome) : __('Contatto senza nome', dnd_contatto_td()),
    ), true);
    if (is_wp_error($id) || !$id) {
        return;
    }
    $map = array('ruolo' => 'ruolo', 'ente' => 'ente', 'email' => 'email', 'telefono' => 'telefono', 'data' => 'data', 'luogo' => 'luogo', 'discorso' => 'discorso', 'raccolto_da' => 'raccolto_da');
    foreach ($map as $field => $key) {
        $val = $txt($field);
        update_post_meta($id, '_dndc_' . $key, $key === 'discorso' ? sanitize_textarea_field($val) : sanitize_text_field($key === 'email' ? sanitize_email($val) : $val));
    }
    $int = isset($values['interessi']) ? (array) $values['interessi'] : array();
    update_post_meta($id, '_dndc_interessi', array_values(array_map('sanitize_text_field', array_map('strval', $int))));
    $nl = mb_strtolower($txt('newsletter'));
    update_post_meta($id, '_dndc_newsletter', ($nl === 'sì' || $nl === 'si' || $nl === 'yes') ? 'si' : 'no');
    update_post_meta($id, '_dndc_invio', (int) $entry_id);
    dnd_contatto_reindex($id);
}, 10, 3);

/** Testo unico per la ricerca. */
function dnd_contatto_reindex($id) {
    $parts = array(get_the_title($id));
    foreach (array('ruolo', 'ente', 'email', 'telefono', 'luogo', 'discorso', 'raccolto_da', 'note_int') as $k) {
        $parts[] = (string) dnd_contatto_meta($id, $k);
    }
    update_post_meta($id, '_dndc_search', mb_strtolower(implode(' ', $parts)));
}

// ---------------------------------------------------------------------
// Scheda contatto
// ---------------------------------------------------------------------

add_action('add_meta_boxes_' . DND_CONTATTO_TYPE, function () {
    $td = dnd_contatto_td();
    remove_meta_box('submitdiv', DND_CONTATTO_TYPE, 'side');
    add_meta_box('dndc-scheda', __('Scheda contatto', $td), 'dnd_contatto_box_scheda', DND_CONTATTO_TYPE, 'normal', 'high');
    add_meta_box('dndc-lato', __('Salva e note', $td), 'dnd_contatto_box_lato', DND_CONTATTO_TYPE, 'side', 'high');
});

function dnd_contatto_iniziali($nome) {
    $words = preg_split('/\s+/', trim((string) $nome));
    $out = '';
    foreach (array_slice(array_filter($words), 0, 2) as $w) {
        $out .= mb_strtoupper(mb_substr($w, 0, 1));
    }
    return $out !== '' ? $out : '?';
}

function dnd_contatto_box_scheda($post) {
    $td = dnd_contatto_td();
    $m = function ($k) use ($post) {
        return dnd_contatto_meta($post->ID, $k);
    };
    wp_nonce_field('dnd_contatto', 'dnd_contatto_nonce');
    $nome = $post->post_title;
    $email = (string) $m('email');
    $tel = (string) $m('telefono');
    $nl = $m('newsletter') === 'si';
    $interessi = array_filter((array) $m('interessi'));
    ?>
    <div class="dndc">
        <div class="dndc-head">
            <span class="dndc-avatar" aria-hidden="true"><?php echo esc_html(dnd_contatto_iniziali($nome)); ?></span>
            <div class="dndc-who">
                <input type="text" name="dndc_nome" class="dndc-name" value="<?php echo esc_attr($nome); ?>" placeholder="<?php esc_attr_e('Nome e cognome', $td); ?>" required>
                <div class="dndc-sub">
                    <?php if ($m('ruolo')) : ?><span class="dndc-pill"><?php echo esc_html($m('ruolo')); ?></span><?php endif; ?>
                    <?php if ($m('ente')) : ?><span><?php echo esc_html($m('ente')); ?></span><?php endif; ?>
                    <span class="dndc-pill <?php echo $nl ? 'dndc-pill--yes' : 'dndc-pill--no'; ?>"><?php echo $nl ? esc_html__('Newsletter: sì', $td) : esc_html__('Newsletter: no', $td); ?></span>
                </div>
            </div>
            <div class="dndc-actions">
                <?php if ($email) : ?><a class="button" href="mailto:<?php echo esc_attr($email); ?>"><span class="dashicons dashicons-email"></span> <?php esc_html_e('Scrivi', $td); ?></a><?php endif; ?>
                <?php if ($tel) : ?><a class="button" href="tel:<?php echo esc_attr(preg_replace('/[^0-9+]/', '', $tel)); ?>"><span class="dashicons dashicons-phone"></span> <?php esc_html_e('Chiama', $td); ?></a><?php endif; ?>
            </div>
        </div>

        <div class="dndc-grid">
            <section class="dndc-card">
                <h3><?php esc_html_e('Chi è', $td); ?></h3>
                <label><?php esc_html_e('Ruolo', $td); ?>
                    <select name="dndc_ruolo">
                        <option value=""><?php esc_html_e('—', $td); ?></option>
                        <?php foreach (dnd_contatto_ruoli() as $r) : ?>
                            <option value="<?php echo esc_attr($r); ?>" <?php selected($m('ruolo'), $r); ?>><?php echo esc_html($r); ?></option>
                        <?php endforeach; ?>
                        <?php if ($m('ruolo') && !in_array($m('ruolo'), dnd_contatto_ruoli(), true)) : ?>
                            <option value="<?php echo esc_attr($m('ruolo')); ?>" selected><?php echo esc_html($m('ruolo')); ?></option>
                        <?php endif; ?>
                    </select>
                </label>
                <label><?php esc_html_e('Scuola, ente o associazione', $td); ?>
                    <input type="text" name="dndc_ente" value="<?php echo esc_attr($m('ente')); ?>">
                </label>
                <label><?php esc_html_e('E-mail', $td); ?>
                    <input type="email" name="dndc_email" value="<?php echo esc_attr($email); ?>">
                </label>
                <label><?php esc_html_e('Telefono', $td); ?>
                    <input type="text" name="dndc_telefono" value="<?php echo esc_attr($tel); ?>">
                </label>
                <label class="dndc-switch">
                    <input type="checkbox" name="dndc_newsletter" value="si" <?php checked($nl); ?>>
                    <span><?php esc_html_e('Iscritta/o alla newsletter', $td); ?></span>
                </label>
            </section>

            <section class="dndc-card">
                <h3><?php esc_html_e('L’incontro', $td); ?></h3>
                <label><?php esc_html_e('Data', $td); ?>
                    <input type="date" name="dndc_data" value="<?php echo esc_attr($m('data')); ?>">
                </label>
                <label><?php esc_html_e('Luogo o occasione', $td); ?>
                    <input type="text" name="dndc_luogo" value="<?php echo esc_attr($m('luogo')); ?>">
                </label>
                <label><?php esc_html_e('Raccolto da', $td); ?>
                    <input type="text" name="dndc_raccolto_da" value="<?php echo esc_attr($m('raccolto_da')); ?>">
                </label>
                <?php if ($interessi) : ?>
                    <div class="dndc-int">
                        <strong><?php esc_html_e('Interessata/o a', $td); ?></strong>
                        <ul><?php foreach ($interessi as $i) : ?><li><?php echo esc_html($i); ?></li><?php endforeach; ?></ul>
                    </div>
                <?php endif; ?>
            </section>
        </div>

        <section class="dndc-card dndc-card--wide">
            <h3><?php esc_html_e('Di cosa si è parlato…', $td); ?></h3>
            <textarea name="dndc_discorso" rows="6"><?php echo esc_textarea((string) $m('discorso')); ?></textarea>
        </section>
    </div>
    <?php
}

function dnd_contatto_box_lato($post) {
    $td = dnd_contatto_td();
    $invio = (int) dnd_contatto_meta($post->ID, 'invio');
    ?>
    <p class="dndc-meta"><?php echo esc_html(sprintf(__('Registrato il %s', $td), get_the_date('d.m.Y H:i', $post))); ?></p>
    <p>
        <label for="dndc_note_int"><strong><?php esc_html_e('Note interne', $td); ?></strong></label>
        <textarea name="dndc_note_int" id="dndc_note_int" rows="6" style="width:100%"><?php echo esc_textarea((string) dnd_contatto_meta($post->ID, 'note_int')); ?></textarea>
    </p>
    <p class="description"><?php esc_html_e('Per esempio: richiamato il…, opuscoli spediti, conferenza fissata. Le note non le vede nessuno fuori da qui.', $td); ?></p>
    <p><button type="submit" class="button button-primary button-large" style="width:100%"><?php esc_html_e('Salva scheda', $td); ?></button></p>
    <?php if ($post->post_status !== 'auto-draft') : ?>
        <p><a class="submitdelete" style="color:#b3261e" href="<?php echo esc_url(get_delete_post_link($post->ID)); ?>"><?php esc_html_e('Sposta nel cestino', $td); ?></a></p>
    <?php endif; ?>
    <?php if ($invio && class_exists('\TicinoWeb\TWFormulari\Builder\EntriesAdmin')) : ?>
        <p><a href="<?php echo esc_url(\TicinoWeb\TWFormulari\Builder\EntriesAdmin::list_url(array('entry' => $invio))); ?>"><?php esc_html_e('Vedi la compilazione originale', $td); ?></a></p>
    <?php endif;
}

add_action('save_post_' . DND_CONTATTO_TYPE, function ($post_id, $post) {
    if (!isset($_POST['dnd_contatto_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['dnd_contatto_nonce'])), 'dnd_contatto')) {
        return;
    }
    if ((defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) || !current_user_can('edit_post', $post_id)) {
        return;
    }
    $in = function ($k) {
        return isset($_POST['dndc_' . $k]) ? sanitize_text_field(wp_unslash($_POST['dndc_' . $k])) : '';
    };
    foreach (array('ruolo', 'ente', 'telefono', 'data', 'luogo', 'raccolto_da') as $k) {
        update_post_meta($post_id, '_dndc_' . $k, $in($k));
    }
    update_post_meta($post_id, '_dndc_email', sanitize_email($in('email')));
    update_post_meta($post_id, '_dndc_newsletter', isset($_POST['dndc_newsletter']) ? 'si' : 'no');
    update_post_meta($post_id, '_dndc_discorso', isset($_POST['dndc_discorso']) ? sanitize_textarea_field(wp_unslash($_POST['dndc_discorso'])) : '');
    update_post_meta($post_id, '_dndc_note_int', isset($_POST['dndc_note_int']) ? sanitize_textarea_field(wp_unslash($_POST['dndc_note_int'])) : '');
    $nome = $in('nome');
    if ($nome !== '' && $nome !== $post->post_title) {
        global $wpdb;
        $wpdb->update($wpdb->posts, array('post_title' => $nome), array('ID' => $post_id)); // evita il ciclo di save_post
        clean_post_cache($post_id);
    }
    dnd_contatto_reindex($post_id);
}, 10, 2);

// ---------------------------------------------------------------------
// Elenco
// ---------------------------------------------------------------------

add_filter('manage_' . DND_CONTATTO_TYPE . '_posts_columns', function () {
    $td = dnd_contatto_td();
    return array(
        'cb'         => '<input type="checkbox">',
        'title'      => __('Contatto', $td),
        'dndc_ruolo' => __('Ruolo e ente', $td),
        'dndc_rec'   => __('Recapiti', $td),
        'dndc_nl'    => __('Newsletter', $td),
        'dndc_inc'   => __('Incontro', $td),
        'date'       => __('Registrato', $td),
    );
});

add_action('manage_' . DND_CONTATTO_TYPE . '_posts_custom_column', function ($col, $id) {
    $td = dnd_contatto_td();
    if ($col === 'dndc_ruolo') {
        echo '<strong>' . esc_html((string) dnd_contatto_meta($id, 'ruolo')) . '</strong>';
        $ente = (string) dnd_contatto_meta($id, 'ente');
        if ($ente !== '') {
            echo '<br><span class="description">' . esc_html($ente) . '</span>';
        }
    } elseif ($col === 'dndc_rec') {
        $e = (string) dnd_contatto_meta($id, 'email');
        $t = (string) dnd_contatto_meta($id, 'telefono');
        if ($e) {
            echo '<a href="mailto:' . esc_attr($e) . '">' . esc_html($e) . '</a>';
        }
        if ($t) {
            echo ($e ? '<br>' : '') . '<a href="tel:' . esc_attr(preg_replace('/[^0-9+]/', '', $t)) . '">' . esc_html($t) . '</a>';
        }
    } elseif ($col === 'dndc_nl') {
        echo dnd_contatto_meta($id, 'newsletter') === 'si'
            ? '<span class="dndc-pill dndc-pill--yes">' . esc_html__('Sì', $td) . '</span>'
            : '<span class="dndc-pill dndc-pill--no">' . esc_html__('No', $td) . '</span>';
    } elseif ($col === 'dndc_inc') {
        $d = (string) dnd_contatto_meta($id, 'data');
        $l = (string) dnd_contatto_meta($id, 'luogo');
        echo esc_html(trim(($d ? mysql2date('d.m.Y', $d) : '') . ($d && $l ? ' · ' : '') . $l));
    }
}, 10, 2);

add_filter('manage_edit-' . DND_CONTATTO_TYPE . '_sortable_columns', function ($c) {
    return $c;
});

add_action('restrict_manage_posts', function ($type) {
    if ($type !== DND_CONTATTO_TYPE) {
        return;
    }
    $td = dnd_contatto_td();
    $nl = isset($_GET['dndc_nl']) ? sanitize_key(wp_unslash($_GET['dndc_nl'])) : '';
    $ru = isset($_GET['dndc_ruolo']) ? sanitize_text_field(wp_unslash($_GET['dndc_ruolo'])) : '';
    echo '<select name="dndc_ruolo"><option value="">' . esc_html__('Tutti i ruoli', $td) . '</option>';
    foreach (dnd_contatto_ruoli() as $r) {
        echo '<option value="' . esc_attr($r) . '"' . selected($ru, $r, false) . '>' . esc_html($r) . '</option>';
    }
    echo '</select>';
    echo '<select name="dndc_nl"><option value="">' . esc_html__('Newsletter: tutti', $td) . '</option><option value="si"' . selected($nl, 'si', false) . '>' . esc_html__('Iscritti', $td) . '</option><option value="no"' . selected($nl, 'no', false) . '>' . esc_html__('Non iscritti', $td) . '</option></select>';
    $url = wp_nonce_url(admin_url('admin-post.php?action=dnd_contatti_csv' . ($nl ? '&dndc_nl=' . $nl : '')), 'dnd_contatti_csv');
    echo ' <a class="button" href="' . esc_url($url) . '"><span class="dashicons dashicons-download" style="vertical-align:middle"></span> ' . esc_html__('Esporta CSV', $td) . '</a>';
});

add_action('pre_get_posts', function ($q) {
    if (!is_admin() || !$q->is_main_query() || $q->get('post_type') !== DND_CONTATTO_TYPE) {
        return;
    }
    $mq = array();
    if (!empty($_GET['dndc_nl'])) {
        $mq[] = array('key' => '_dndc_newsletter', 'value' => sanitize_key(wp_unslash($_GET['dndc_nl'])) === 'si' ? 'si' : 'no');
    }
    if (!empty($_GET['dndc_ruolo'])) {
        $mq[] = array('key' => '_dndc_ruolo', 'value' => sanitize_text_field(wp_unslash($_GET['dndc_ruolo'])));
    }
    if ($q->get('s')) {
        $mq[] = array('key' => '_dndc_search', 'value' => mb_strtolower(sanitize_text_field($q->get('s'))), 'compare' => 'LIKE');
        $q->set('s', '');
    }
    if ($mq) {
        $q->set('meta_query', $mq);
    }
});

// Il titolo nell'elenco: la ricerca è svuotata sopra, ma il campo di ricerca deve continuare a mostrare il testo.
add_filter('get_search_query', function ($s) {
    return $s === '' && isset($_GET['post_type'], $_GET['s']) && $_GET['post_type'] === DND_CONTATTO_TYPE ? sanitize_text_field(wp_unslash($_GET['s'])) : $s;
});

/** Esporta in CSV (Excel), per la newsletter o altro. */
add_action('admin_post_dnd_contatti_csv', function () {
    if (!current_user_can('manage_options') || !check_admin_referer('dnd_contatti_csv')) {
        wp_die(esc_html__('Non autorizzato.', dnd_contatto_td()), 403);
    }
    $args = array('post_type' => DND_CONTATTO_TYPE, 'post_status' => 'publish', 'posts_per_page' => -1, 'fields' => 'ids', 'orderby' => 'date', 'order' => 'DESC');
    if (!empty($_GET['dndc_nl'])) {
        $args['meta_query'] = array(array('key' => '_dndc_newsletter', 'value' => sanitize_key(wp_unslash($_GET['dndc_nl'])) === 'si' ? 'si' : 'no'));
    }
    $ids = get_posts($args);
    nocache_headers();
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="contatti-' . gmdate('Y-m-d') . '.csv"');
    $out = fopen('php://output', 'w');
    fwrite($out, "\xEF\xBB\xBF");
    fputcsv($out, array('Nome', 'Ruolo', 'Ente', 'E-mail', 'Telefono', 'Newsletter', 'Data incontro', 'Luogo', 'Interessi', 'Di cosa si è parlato', 'Raccolto da', 'Registrato il'), ';');
    foreach ($ids as $id) {
        $row = array(get_the_title($id), dnd_contatto_meta($id, 'ruolo'), dnd_contatto_meta($id, 'ente'), dnd_contatto_meta($id, 'email'), dnd_contatto_meta($id, 'telefono'),
            dnd_contatto_meta($id, 'newsletter') === 'si' ? 'Sì' : 'No', dnd_contatto_meta($id, 'data'), dnd_contatto_meta($id, 'luogo'),
            implode(', ', (array) dnd_contatto_meta($id, 'interessi')), dnd_contatto_meta($id, 'discorso'), dnd_contatto_meta($id, 'raccolto_da'), get_the_date('Y-m-d H:i', $id));
        // Niente formule in Excel: le celle che iniziano con = + - @ vengono neutralizzate.
        $row = array_map(function ($v) {
            $v = (string) $v;
            return $v !== '' && strpos('=+-@', $v[0]) !== false ? "'" . $v : $v;
        }, $row);
        fputcsv($out, $row, ';');
    }
    fclose($out);
    exit;
});

/** Segnalino con i contatti nuovi (ultimi 7 giorni) nel menu. */
add_action('admin_menu', function () {
    global $menu;
    $n = (int) (new WP_Query(array('post_type' => DND_CONTATTO_TYPE, 'post_status' => 'publish', 'fields' => 'ids', 'posts_per_page' => 50, 'no_found_rows' => true, 'date_query' => array(array('after' => '7 days ago')))))->post_count;
    if (!$n || !is_array($menu)) {
        return;
    }
    foreach ($menu as $k => $item) {
        if (isset($item[2]) && $item[2] === 'edit.php?post_type=' . DND_CONTATTO_TYPE) {
            $menu[$k][0] .= ' <span class="awaiting-mod">' . $n . '</span>'; // phpcs:ignore WordPress.WP.GlobalVariablesOverride
        }
    }
}, 99);

// ---------------------------------------------------------------------
// Aspetto in Bacheca
// ---------------------------------------------------------------------

add_action('admin_head', function () {
    $s = function_exists('get_current_screen') ? get_current_screen() : null;
    if (!$s || $s->post_type !== DND_CONTATTO_TYPE) {
        return;
    }
    ?>
    <style>
    .dndc-pill{display:inline-block;padding:2px 10px;border-radius:999px;background:#e6f4f7;color:#00596a;font-size:12px;font-weight:600;line-height:1.6}
    .dndc-pill--yes{background:#dff3e8;color:#0f6a41}
    .dndc-pill--no{background:#eef0f1;color:#50636b}
    .post-type-dnd_contatto .column-dndc_nl{width:110px}
    .post-type-dnd_contatto #titlediv,.post-type-dnd_contatto #post-body-content{display:none}
    .post-type-dnd_contatto #dndc-scheda{border:0;background:transparent;box-shadow:none}
    .post-type-dnd_contatto #dndc-scheda .postbox-header,.post-type-dnd_contatto #dndc-scheda .hndle{display:none}
    .post-type-dnd_contatto #dndc-scheda .inside{padding:0;margin:0}
    .dndc-head{display:flex;align-items:center;gap:18px;flex-wrap:wrap;background:#fff;border:1px solid #dcdcde;border-radius:14px;padding:20px 22px;margin-bottom:16px}
    .dndc-avatar{width:64px;height:64px;border-radius:50%;background:#00788c;color:#fff;display:flex;align-items:center;justify-content:center;font-size:22px;font-weight:700;flex:none}
    .dndc-who{flex:1;min-width:240px}
    .dndc-name{width:100%;font-size:24px;font-weight:700;border:0!important;border-bottom:1px dashed #c3c4c7!important;border-radius:0!important;padding:2px 0!important;background:transparent!important;box-shadow:none!important}
    .dndc-sub{display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin-top:8px;color:#50636b}
    .dndc-actions{display:flex;gap:8px}
    .dndc-actions .dashicons{vertical-align:middle;margin-top:-2px}
    .dndc-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px;margin-bottom:16px}
    @media(max-width:900px){.dndc-grid{grid-template-columns:1fr}}
    .dndc-card{background:#fff;border:1px solid #dcdcde;border-radius:14px;padding:18px 22px}
    .dndc-card h3{margin:0 0 12px;font-size:15px}
    .dndc-card label{display:block;margin:0 0 12px;font-weight:600;font-size:13px}
    .dndc-card label input[type=text],.dndc-card label input[type=email],.dndc-card label input[type=date],.dndc-card label select,.dndc-card textarea{display:block;width:100%;max-width:100%;margin-top:4px;font-weight:400}
    .dndc-card textarea{margin:0}
    .dndc-switch{display:flex!important;align-items:center;gap:8px;padding:10px 12px;background:#f3f9fa;border-radius:10px}
    .dndc-int ul{margin:6px 0 0;padding-left:18px;list-style:disc}
    .dndc-meta{color:#50636b;margin-top:0}
    </style>
    <?php
});
