(() => {
  'use strict';
  const form = document.querySelector('[data-gl-booking-form]');
  if (!form) return;

  const panels = Array.from(form.querySelectorAll('[data-gl-form-step]'));
  const progressButtons = Array.from(form.querySelectorAll('[data-gl-step-target]'));
  const progressStatus = form.querySelector('[data-gl-form-status]');
  const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  if (panels.length && progressButtons.length === panels.length) {
    let activeStep = 0;
    let furthestStep = 0;

    form.classList.add('is-wizard');

    const panelIsValid = (panel) => {
      const invalid = panel.querySelector(':invalid');
      if (!invalid) return true;
      invalid.reportValidity();
      invalid.focus({ preventScroll: true });
      return false;
    };

    const showStep = (index, shouldFocus = true) => {
      activeStep = Math.max(0, Math.min(index, panels.length - 1));
      furthestStep = Math.max(furthestStep, activeStep);
      form.style.setProperty('--gl-booking-progress', `${((activeStep + 1) / panels.length) * 100}%`);

      panels.forEach((panel, panelIndex) => {
        panel.hidden = panelIndex !== activeStep;
        panel.setAttribute('aria-hidden', panelIndex === activeStep ? 'false' : 'true');
      });

      progressButtons.forEach((button, buttonIndex) => {
        button.disabled = buttonIndex > furthestStep;
        button.removeAttribute('aria-current');
        if (buttonIndex === activeStep) button.setAttribute('aria-current', 'step');
      });

      const currentButton = progressButtons[activeStep];
      if (progressStatus) progressStatus.textContent = currentButton.dataset.stepAnnouncement || '';

      const activePanel = panels[activeStep];
      if (!reduceMotion) {
        activePanel.classList.remove('is-entering');
        window.requestAnimationFrame(() => activePanel.classList.add('is-entering'));
      }
      if (shouldFocus) activePanel.querySelector('h3')?.focus({ preventScroll: true });
      activePanel.scrollIntoView({ behavior: reduceMotion ? 'auto' : 'smooth', block: 'start' });
    };

    form.querySelectorAll('[data-gl-form-next]').forEach((button) => {
      button.addEventListener('click', () => {
        if (panelIsValid(panels[activeStep])) showStep(activeStep + 1);
      });
    });

    form.querySelectorAll('[data-gl-form-back]').forEach((button) => {
      button.addEventListener('click', () => showStep(activeStep - 1));
    });

    progressButtons.forEach((button, index) => {
      button.addEventListener('click', () => {
        if (index <= furthestStep && (index < activeStep || panelIsValid(panels[activeStep]))) showStep(index);
      });
    });

    form.addEventListener('submit', (event) => {
      if (activeStep >= panels.length - 1) return;
      event.preventDefault();
      if (panelIsValid(panels[activeStep])) showStep(activeStep + 1);
    });

    showStep(0, false);
  }

  if (!window.glutelabBooking) return;

  const date = form.querySelector('[data-gl-booking-date]');
  const time = form.querySelector('[data-gl-booking-time]');
  const status = form.querySelector('[data-gl-booking-status]');
  if (!date || !time || !time.dataset.package) return;

  let controller;
  const setStatus = (message) => { if (status) status.textContent = message || ''; };
  const resetTime = (message, statusMessage = '') => {
    time.replaceChildren(new Option(message, ''));
    time.disabled = true;
    setStatus(statusMessage);
  };

  date.addEventListener('change', async () => {
    if (!date.value) {
      if (controller) controller.abort();
      controller = undefined;
      resetTime(glutelabBooking.chooseDate);
      return;
    }

    if (controller) controller.abort();
    const requestController = new AbortController();
    controller = requestController;
    resetTime(glutelabBooking.loading, glutelabBooking.loading);

    try {
      const url = new URL(glutelabBooking.slotsUrl);
      url.searchParams.set('package', time.dataset.package);
      url.searchParams.set('date', date.value);
      const response = await fetch(url, {
        headers: { 'X-WP-Nonce': glutelabBooking.nonce },
        signal: requestController.signal,
      });
      if (!response.ok) throw new Error('slots');

      const data = await response.json();
      if (!data.slots || !data.slots.length) {
        resetTime(glutelabBooking.empty, glutelabBooking.empty);
        return;
      }

      time.replaceChildren(new Option(glutelabBooking.chooseTime, ''));
      data.slots.forEach((slot) => {
        time.append(new Option(`${slot.label} · ${slot.duration_label}`, slot.value));
      });
      time.disabled = false;
      setStatus('');
    } catch (error) {
      if (error.name !== 'AbortError') resetTime(glutelabBooking.error, glutelabBooking.error);
    }
    finally { if (controller === requestController) controller = undefined; }
  });
})();
