(function (root, factory) {
  'use strict';
  var api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  if (root && root.document) {
    if (root.document.readyState === 'loading') root.document.addEventListener('DOMContentLoaded', api.init, { once: true });
    else api.init();
  }
})(typeof window !== 'undefined' ? window : globalThis, function () {
  'use strict';

  function menuLabel(open, openLabel, closeLabel) {
    return open ? closeLabel : openLabel;
  }

  function shouldCloseOnResize(width, breakpoint) {
    return Number(width) > Number(breakpoint);
  }

  function initHeader() {
    document.body.classList.remove('no-js');
    var header = document.querySelector('[data-gl-header]');
    var toggle = document.querySelector('[data-gl-menu-toggle]');
    var menu = document.querySelector('[data-gl-menu]');
    var headerFrame = false;

    function updateHeader() {
      headerFrame = false;
      if (header) header.classList.toggle('is-scrolled', window.scrollY > 18);
    }

    function setMenu(open, returnFocus) {
      if (!toggle || !menu) return;
      var openLabel = toggle.getAttribute('data-open-label') || 'Apri il menu';
      var closeLabel = toggle.getAttribute('data-close-label') || 'Chiudi il menu';
      var label = toggle.querySelector('[data-gl-menu-label]');
      toggle.setAttribute('aria-expanded', String(open));
      menu.classList.toggle('is-open', open);
      document.body.classList.toggle('gl-menu-open', open);
      if (label) label.textContent = menuLabel(open, openLabel, closeLabel);
      if (open) {
        window.requestAnimationFrame(function () {
          var firstLink = menu.querySelector('a');
          if (firstLink) firstLink.focus({ preventScroll: true });
        });
      } else if (returnFocus) {
        toggle.focus({ preventScroll: true });
      }
    }

    window.addEventListener('scroll', function () {
      if (!headerFrame) {
        headerFrame = true;
        window.requestAnimationFrame(updateHeader);
      }
    }, { passive: true });
    updateHeader();

    if (!toggle || !menu) return;
    toggle.addEventListener('click', function () {
      setMenu(toggle.getAttribute('aria-expanded') !== 'true', false);
    });
    menu.addEventListener('click', function (event) {
      if (event.target.closest('a')) setMenu(false, false);
    });
    document.addEventListener('pointerdown', function (event) {
      if (toggle.getAttribute('aria-expanded') !== 'true') return;
      if (header && !header.contains(event.target)) setMenu(false, false);
    });
    document.addEventListener('keydown', function (event) {
      if (event.key === 'Escape' && toggle.getAttribute('aria-expanded') === 'true') setMenu(false, true);
    });
    window.addEventListener('resize', function () {
      if (shouldCloseOnResize(window.innerWidth, 960)) setMenu(false, false);
    }, { passive: true });
  }

  function initPageHero() {
    var pageHero = document.querySelector('.gl-page-hero');
    if (!pageHero) return;
    var pageHeroVisible = true;
    var reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
    var updatePageHeroMotion = function () {
      pageHero.classList.toggle('is-motion-active', pageHeroVisible && !document.hidden && !reducedMotion.matches);
    };
    if ('IntersectionObserver' in window) {
      new IntersectionObserver(function (entries) {
        pageHeroVisible = entries[0] ? entries[0].isIntersecting : false;
        updatePageHeroMotion();
      }, { threshold: 0.02 }).observe(pageHero);
    }
    if (reducedMotion.addEventListener) reducedMotion.addEventListener('change', updatePageHeroMotion);
    document.addEventListener('visibilitychange', updatePageHeroMotion);
    updatePageHeroMotion();
  }

  function initForms() {
    document.querySelectorAll('[data-gl-contact-form]').forEach(function (form) {
      form.addEventListener('submit', async function (event) {
        event.preventDefault();
        var status = form.querySelector('[data-gl-form-status]');
        if (!form.reportValidity()) return;
        form.classList.add('is-sending');
        if (status) status.textContent = 'Invio in corso…';
        try {
          var tokenResponse = await fetch(glutelabSite.ajaxUrl + '?action=' + encodeURIComponent(glutelabSite.tokenAction), { credentials: 'same-origin' });
          var tokenJson = await tokenResponse.json();
          if (!tokenJson.success || !tokenJson.data.token) throw new Error('token');
          var data = new FormData(form);
          data.append('action', glutelabSite.submitAction);
          data.append('token', tokenJson.data.token);
          var response = await fetch(glutelabSite.ajaxUrl, { method: 'POST', body: data, credentials: 'same-origin' });
          var json = await response.json();
          if (!json.success) throw new Error(json.data && json.data.message ? json.data.message : glutelabSite.genericError);
          if (status) status.textContent = json.data.message;
          form.reset();
        } catch (error) {
          if (status) status.textContent = error.message && error.message !== 'token' ? error.message : glutelabSite.genericError;
        } finally {
          form.classList.remove('is-sending');
        }
      });
    });
  }

  function init() {
    initHeader();
    initPageHero();
    initForms();
  }

  return { menuLabel: menuLabel, shouldCloseOnResize: shouldCloseOnResize, init: init };
});
