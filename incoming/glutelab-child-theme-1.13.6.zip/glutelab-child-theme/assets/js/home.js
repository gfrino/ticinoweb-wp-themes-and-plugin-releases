(function (root, factory) {
  'use strict';
  var api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  if (root && root.document) {
    root.glutelabHome = Object.assign(root.glutelabHome || {}, api);
    if (root.document.readyState === 'loading') {
      root.document.addEventListener('DOMContentLoaded', api.init, { once: true });
    } else {
      api.init();
    }
  }
})(typeof window !== 'undefined' ? window : globalThis, function () {
  'use strict';

  function wrapIndex(index, count) {
    if (count < 1) return 0;
    return ((Number(index) || 0) % count + count) % count;
  }

  function nextIndex(current, direction, count) {
    return wrapIndex((Number(current) || 0) + (Number(direction) || 0), count);
  }

  function swipeDirection(startX, endX, threshold) {
    var distance = Number(startX) - Number(endX);
    var minimum = Math.max(1, Number(threshold) || 1);
    if (Math.abs(distance) < minimum) return 0;
    return distance > 0 ? 1 : -1;
  }

  function shouldAnimateAtmosphere(heroVisible, documentVisible, reducedMotion) {
    return Boolean(heroVisible && documentVisible && !reducedMotion);
  }

  function shouldAutoplaySlider(slideCount, heroVisible, documentVisible, reducedMotion, userPaused, interactionPaused) {
    return Number(slideCount) > 1 && Boolean(heroVisible && documentVisible && !reducedMotion && !userPaused && !interactionPaused);
  }

  function shouldPauseForFocus(focusVisible) {
    return Boolean(focusVisible);
  }

  function autoplayControlState(userPaused, reducedMotion) {
    var stopped = Boolean(userPaused || reducedMotion);
    return {
      hidden: Boolean(reducedMotion),
      pressed: Boolean(userPaused),
      running: !stopped,
      icon: stopped ? '▶' : '↻'
    };
  }

  function formatSlidePosition(index, count) {
    var current = String(wrapIndex(index, count) + 1).padStart(2, '0');
    var total = String(Math.max(0, Number(count) || 0)).padStart(2, '0');
    return current + ' / ' + total;
  }

  function initHeroAtmosphere(hero) {
    var atmosphere = hero.querySelector('[data-gl-hero-atmosphere]');
    if (!atmosphere) return;
    var heroVisible = true;
    var reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');

    function updateAtmosphere() {
      hero.classList.toggle('is-atmosphere-active', shouldAnimateAtmosphere(heroVisible, !document.hidden, reducedMotion.matches));
    }

    if ('IntersectionObserver' in window) {
      new IntersectionObserver(function (entries) {
        heroVisible = entries[0] ? entries[0].isIntersecting : false;
        updateAtmosphere();
      }, { threshold: 0.02 }).observe(hero);
    }
    if (reducedMotion.addEventListener) reducedMotion.addEventListener('change', updateAtmosphere);
    document.addEventListener('visibilitychange', updateAtmosphere);
    updateAtmosphere();
  }

  function initHero(hero) {
    var slides = Array.from(hero.querySelectorAll('[data-gl-hero-slide]'));
    var autoplay = hero.querySelector('[data-gl-hero-autoplay]');
    var controls = hero.querySelector('[data-gl-hero-controls]');
    var loopIndex = hero.querySelector('[data-gl-hero-loop-index]');
    var status = hero.querySelector('[data-gl-hero-status]');
    var activeIndex = 0;
    var pointerStart = null;
    var autoplayTimer = null;
    var heroVisible = true;
    var userPaused = false;
    var interactionPaused = false;
    var reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
    var autoplayDelay = Math.max(3000, Number(hero.getAttribute('data-gl-hero-autoplay-delay')) || 3200);

    if (!slides.length) return;
    hero.style.setProperty('--gl-loop-duration', autoplayDelay + 'ms');
    initHeroAtmosphere(hero);

    function announce(index) {
      if (!status) return;
      var slide = slides[index];
      var title = slide.getAttribute('data-title') || '';
      var template = window.glutelabHome && window.glutelabHome.slideStatus ? window.glutelabHome.slideStatus : 'Slide %1$d di %2$d: %3$s';
      status.textContent = template.replace('%1$d', index + 1).replace('%2$d', slides.length).replace('%3$s', title);
    }

    function setActive(index, shouldAnnounce) {
      var selected = wrapIndex(index, slides.length);
      slides.forEach(function (slide, slideIndex) {
        var current = selected === slideIndex;
        slide.classList.toggle('is-active', current);
        slide.setAttribute('aria-hidden', current ? 'false' : 'true');
        slide.toggleAttribute('inert', !current);
      });
      activeIndex = selected;
      if (loopIndex) loopIndex.textContent = formatSlidePosition(selected, slides.length);
      if (shouldAnnounce) announce(selected);
    }

    function updateAutoplayControl() {
      if (!autoplay) return;
      var state = autoplayControlState(userPaused, reducedMotion.matches);
      var pauseLabel = autoplay.getAttribute('data-pause-label') || 'Metti in pausa lo slider';
      var playLabel = autoplay.getAttribute('data-play-label') || 'Riprendi lo slider';
      var runningLabel = autoplay.getAttribute('data-running-label') || 'Auto';
      var pausedLabel = autoplay.getAttribute('data-paused-label') || 'In pausa';
      autoplay.hidden = state.hidden;
      if (controls) controls.hidden = state.hidden;
      autoplay.setAttribute('aria-pressed', state.pressed ? 'true' : 'false');
      autoplay.setAttribute('aria-label', state.pressed ? playLabel : pauseLabel);
      var icon = autoplay.querySelector('[data-gl-hero-autoplay-icon]');
      var label = autoplay.querySelector('[data-gl-hero-loop-label]');
      if (icon) icon.textContent = state.icon;
      if (label) label.textContent = state.pressed ? pausedLabel : runningLabel;
    }

    function scheduleAutoplay() {
      if (autoplayTimer) window.clearTimeout(autoplayTimer);
      autoplayTimer = null;
      hero.classList.remove('is-loop-running');
      updateAutoplayControl();
      if (!shouldAutoplaySlider(slides.length, heroVisible, !document.hidden, reducedMotion.matches, userPaused, interactionPaused)) return;
      if (autoplay) void autoplay.offsetWidth;
      hero.classList.add('is-loop-running');
      autoplayTimer = window.setTimeout(function () {
        setActive(nextIndex(activeIndex, 1, slides.length), false);
        scheduleAutoplay();
      }, autoplayDelay);
    }

    function setActiveFromControl(index) {
      setActive(index, true);
      scheduleAutoplay();
    }

    if (autoplay) autoplay.addEventListener('click', function () {
      userPaused = !userPaused;
      scheduleAutoplay();
    });

    hero.addEventListener('keydown', function (event) {
      var target = event.target;
      if (target && /^(INPUT|TEXTAREA|SELECT)$/.test(target.tagName)) return;
      if (event.key === 'ArrowRight') setActiveFromControl(nextIndex(activeIndex, 1, slides.length));
      else if (event.key === 'ArrowLeft') setActiveFromControl(nextIndex(activeIndex, -1, slides.length));
      else if (event.key === 'Home') setActiveFromControl(0);
      else if (event.key === 'End') setActiveFromControl(slides.length - 1);
      else return;
      event.preventDefault();
    });

    hero.addEventListener('pointerdown', function (event) {
      if ('mouse' === event.pointerType) return;
      pointerStart = event.clientX;
    }, { passive: true });
    hero.addEventListener('pointerup', function (event) {
      if (null === pointerStart) return;
      var direction = swipeDirection(pointerStart, event.clientX, 42);
      pointerStart = null;
      if (direction) setActiveFromControl(nextIndex(activeIndex, direction, slides.length));
    }, { passive: true });
    hero.addEventListener('pointercancel', function () { pointerStart = null; }, { passive: true });
    hero.addEventListener('mouseenter', function () { interactionPaused = true; scheduleAutoplay(); });
    hero.addEventListener('mouseleave', function () { interactionPaused = false; scheduleAutoplay(); });
    hero.addEventListener('focusin', function (event) {
      var target = event.target;
      interactionPaused = shouldPauseForFocus(Boolean(target && target.matches && target.matches(':focus-visible')));
      scheduleAutoplay();
    });
    hero.addEventListener('focusout', function (event) {
      if (event.relatedTarget && hero.contains(event.relatedTarget)) return;
      interactionPaused = false;
      scheduleAutoplay();
    });

    if ('IntersectionObserver' in window) {
      new IntersectionObserver(function (entries) {
        heroVisible = entries[0] ? entries[0].isIntersecting : false;
        scheduleAutoplay();
      }, { threshold: 0.1 }).observe(hero);
    }
    if (reducedMotion.addEventListener) reducedMotion.addEventListener('change', scheduleAutoplay);
    document.addEventListener('visibilitychange', scheduleAutoplay);

    hero.classList.add('is-ready');
    setActive(0, false);
    scheduleAutoplay();
  }

  function initReveals() {
    var elements = Array.from(document.querySelectorAll('[data-gl-home-reveal]'));
    var reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (!elements.length || reduced || !('IntersectionObserver' in window)) return;
    document.documentElement.classList.add('gl-home-reveal-ready');
    var observer = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (!entry.isIntersecting) return;
        entry.target.classList.add('is-visible');
        observer.unobserve(entry.target);
      });
    }, { threshold: 0.12, rootMargin: '0px 0px -6% 0px' });
    elements.forEach(function (element) {
      if (element.getBoundingClientRect().top < window.innerHeight * 0.95) element.classList.add('is-visible');
      observer.observe(element);
    });
  }

  function init() {
    document.querySelectorAll('[data-gl-hero]').forEach(initHero);
    initReveals();
  }

  return { wrapIndex: wrapIndex, nextIndex: nextIndex, swipeDirection: swipeDirection, shouldAnimateAtmosphere: shouldAnimateAtmosphere, shouldAutoplaySlider: shouldAutoplaySlider, shouldPauseForFocus: shouldPauseForFocus, autoplayControlState: autoplayControlState, formatSlidePosition: formatSlidePosition, init: init };
});
