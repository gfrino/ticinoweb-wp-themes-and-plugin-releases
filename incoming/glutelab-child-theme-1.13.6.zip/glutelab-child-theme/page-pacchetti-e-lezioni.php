<?php
/** Packages page. @package GluteLabChildTheme */
$catalog = glutelab_get_catalog(); $groups = glutelab_get_package_groups();
get_header(); ?>
<main id="primary" class="gl-main gl-page gl-catalogue">
	<header class="gl-page-hero"><div class="gl-shell gl-narrow"><p class="gl-kicker">GLUTE LAB — <?php esc_html_e( 'PERCORSI', 'glutelab-child-theme' ); ?></p><h1><?php echo esc_html( $catalog['general']['title'] ); ?></h1><?php while ( have_posts() ) : the_post(); ?><div class="gl-prose"><?php the_content(); ?></div><?php endwhile; ?></div></header>
	<nav class="gl-catalogue-nav gl-shell" aria-label="<?php esc_attr_e( 'Vai al percorso', 'glutelab-child-theme' ); ?>"><?php foreach ( $groups as $group ) : ?><a href="#<?php echo esc_attr( $group['id'] ); ?>"><span><?php echo esc_html( $group['order_label'] ); ?></span><?php echo esc_html( $group['title'] ); ?></a><?php endforeach; ?></nav>
	<?php foreach ( $groups as $group ) : $packages = glutelab_get_packages_by_group( $group['id'] ); if ( ! $packages ) continue; ?>
	<section class="gl-catalogue-group gl-section" id="<?php echo esc_attr( $group['id'] ); ?>"><div class="gl-shell"><header class="gl-catalogue-group__head"><p><?php echo esc_html( $group['order_label'] . ' · ' . glutelab_mode_label( $group['mode'] ) ); ?></p><h2><?php echo esc_html( $group['title'] ); ?></h2><p><?php echo esc_html( $group['description'] ); ?></p></header><div class="gl-packages"><?php foreach ( $packages as $package ) echo glutelab_package_card_html( $package, $group ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div></div></section>
	<?php endforeach; ?>
	<section class="gl-catalogue-closing gl-section"><div class="gl-shell gl-catalogue-closing__inner"><h2><?php echo esc_html( $catalog['general']['closing_text'] ); ?></h2><div class="gl-catalogue-closing__actions"><a class="gl-button gl-button--light" href="<?php echo esc_url( $catalog['general']['cta_url'] ); ?>"><span><?php echo esc_html( $catalog['general']['cta_label'] ); ?></span><span aria-hidden="true">→</span></a><p><?php esc_html_e( 'Richiesta informativa: acquisto online e prenotazione non sono ancora attivi.', 'glutelab-child-theme' ); ?></p></div></div></section>
</main><?php get_footer(); ?>
