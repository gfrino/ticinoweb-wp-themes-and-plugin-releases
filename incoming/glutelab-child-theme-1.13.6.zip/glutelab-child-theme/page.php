<?php
/** Generic page template. @package GluteLabChildTheme */
get_header();
?>
<main id="primary" class="gl-main gl-page"><?php while ( have_posts() ) : the_post(); ?><header class="gl-page-hero"><div class="gl-shell gl-narrow"><p class="gl-kicker">GLUTE LAB</p><h1><?php the_title(); ?></h1></div></header><div class="gl-shell gl-narrow"><article class="gl-prose gl-page__content"><?php the_content(); ?></article></div><?php endwhile; ?></main>
<?php get_footer(); ?>
