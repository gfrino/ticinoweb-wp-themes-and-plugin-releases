<?php
/**
 * Front page.
 *
 * @package GluteLabChildTheme
 */

get_header();

$package_page = get_page_by_path( 'pacchetti-e-lezioni' );
$method_page  = get_page_by_path( 'il-metodo' );
$contact_page = get_page_by_path( 'contatti' );
$home_content = '';
$home_excerpt = '';

if ( have_posts() ) {
	while ( have_posts() ) {
		the_post();
		$home_content = get_the_content();
		$home_excerpt = get_the_excerpt();
	}
}

$home_args = array(
	'slides'         => glutelab_get_home_slides(),
	'services'       => glutelab_get_services(),
	'gallery'        => glutelab_get_gallery_images(),
	'package_groups' => glutelab_get_package_groups(),
	'process_steps'  => glutelab_get_home_process_steps(),
	'package_page'   => $package_page,
	'method_page'    => $method_page,
	'contact_page'   => $contact_page,
	'package_url'    => $package_page ? get_permalink( $package_page ) : glutelab_page_url( 'pacchetti-e-lezioni' ),
	'contact_url'    => $contact_page ? get_permalink( $contact_page ) : glutelab_page_url( 'contatti' ),
	'home_content'   => $home_content,
	'home_excerpt'   => $home_excerpt,
	'about_title'    => glutelab_frontend_text( (string) get_option( 'ticinoweb_chi_siamo_title', '' ), 'glutelab:about:title' ),
	'about_text'     => glutelab_frontend_text( (string) get_option( 'ticinoweb_chi_siamo_text', '' ), 'glutelab:about:text' ),
	'about_image'    => glutelab_frontend_url( (string) get_option( 'ticinoweb_chi_siamo_image', '' ), 'glutelab:about:image' ),
);
?>
<main id="primary" class="gl-home">
	<?php
	get_template_part( 'template-parts/home/hero-flow', null, $home_args );
	get_template_part( 'template-parts/home/manifesto', null, $home_args );
	get_template_part( 'template-parts/home/services', null, $home_args );
	get_template_part( 'template-parts/home/packages', null, $home_args );
	get_template_part( 'template-parts/home/process', null, $home_args );
	get_template_part( 'template-parts/home/trust', null, $home_args );
	get_template_part( 'template-parts/home/faq', null, $home_args );
	get_template_part( 'template-parts/home/final-cta', null, $home_args );
	?>
</main>
<?php get_footer();
