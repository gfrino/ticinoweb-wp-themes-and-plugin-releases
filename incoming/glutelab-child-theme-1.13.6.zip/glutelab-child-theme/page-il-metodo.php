<?php
/**
 * Method page.
 *
 * @package GluteLabChildTheme
 */

get_header();

$contact        = glutelab_get_contact_data();
$services       = array_slice( array_values( array_filter( glutelab_get_services() ) ), 0, 4 );
$services_by_id = array();
foreach ( $services as $service ) {
	if ( ! empty( $service['id'] ) ) {
		$services_by_id[ $service['id'] ] = $service;
	}
}
$gallery        = array_values( glutelab_get_gallery_images() );
$image_id       = isset( $gallery[0] ) ? absint( $gallery[0] ) : 0;
$image_url      = get_theme_file_uri( 'assets/images/stock/method-training.webp' );
$packages_url   = glutelab_page_url( 'pacchetti-e-lezioni' );
$contact_url    = glutelab_page_url( 'contatti' );
?>
<main id="primary" class="gl-main gl-page gl-method-page">
	<?php while ( have_posts() ) : ?>
		<?php the_post(); ?>
		<?php
		$method_content  = apply_filters( 'the_content', get_the_content() );
		$method_sections = glutelab_split_method_content( $method_content );
		$intro_section   = $method_sections[0] ?? array();
		$editorial       = $method_sections[1] ?? array();
		$audience        = $method_sections[2] ?? array();
		$intro_content   = $intro_section['content'] ?? '';
		if ( '' === $intro_content && has_excerpt() ) {
			$intro_content = '<p>' . esc_html( get_the_excerpt() ) . '</p>';
		}

		$method_steps = array(
			array(
				'title'       => __( 'Partenza personale', 'glutelab-child-theme' ),
				'description' => $services_by_id['srv_gl_personale']['description'] ?? __( 'Obiettivo e lavoro vengono adattati al livello iniziale della persona.', 'glutelab-child-theme' ),
			),
			array(
				'title'       => __( 'Seduta mirata', 'glutelab-child-theme' ),
				'description' => $services_by_id['srv_gl_macchinari']['description'] ?? __( 'Movimenti controllati e macchinari specializzati concentrano il lavoro sui glutei.', 'glutelab-child-theme' ),
			),
			array(
				'title'       => __( 'Progressione concordata', 'glutelab-child-theme' ),
				'description' => $services_by_id['srv_gl_mirato']['description'] ?? __( 'Il percorso viene inserito con continuità nel programma di allenamento.', 'glutelab-child-theme' ),
			),
		);
		$method_steps = (array) apply_filters( 'glutelab_method_steps', $method_steps, $services );

		$audience_plain = wp_strip_all_tags( $audience['content'] ?? '' );
		$duration       = '';
		if ( preg_match( '/\b(\d+\s*(?:minuto|minuti))\b/ui', $audience_plain, $duration_match ) ) {
			$duration = $duration_match[1];
		}
		?>

		<section class="gl-method-hero" aria-labelledby="gl-method-title">
			<div class="gl-shell gl-method-hero__layout">
				<div class="gl-method-hero__content">
					<p class="gl-kicker"><?php esc_html_e( 'Metodo Glute Lab', 'glutelab-child-theme' ); ?></p>
					<h1 id="gl-method-title"><?php the_title(); ?></h1>
					<?php if ( $intro_content ) : ?><div class="gl-method-hero__lead gl-prose"><?php echo wp_kses_post( $intro_content ); ?></div><?php endif; ?>
					<div class="gl-method-hero__actions">
						<a class="gl-button gl-button--primary" href="<?php echo esc_url( $packages_url ); ?>"><?php esc_html_e( 'Scopri lezioni e pacchetti', 'glutelab-child-theme' ); ?></a>
						<a class="gl-text-link" href="#come-funziona"><?php esc_html_e( 'Come funziona', 'glutelab-child-theme' ); ?></a>
					</div>
				</div>

				<figure class="gl-method-hero__media">
					<?php if ( $image_id ) : ?>
						<?php echo wp_get_attachment_image( $image_id, 'large', false, array( 'loading' => 'eager', 'fetchpriority' => 'high', 'decoding' => 'async', 'class' => 'gl-method-hero__image' ) ); ?>
					<?php else : ?>
						<?php glutelab_image( $image_url, __( 'Allenamento seguito Glute Lab', 'glutelab-child-theme' ), true, 'gl-method-hero__image' ); ?>
					<?php endif; ?>
				</figure>
			</div>
		</section>

		<section class="gl-method-facts" aria-label="<?php esc_attr_e( 'Il metodo in sintesi', 'glutelab-child-theme' ); ?>">
			<div class="gl-shell">
				<dl>
					<div><dt><?php esc_html_e( 'Percorsi', 'glutelab-child-theme' ); ?></dt><dd><?php esc_html_e( 'Individuale, gruppo, integrato e digitale', 'glutelab-child-theme' ); ?></dd></div>
					<div><dt><?php esc_html_e( 'Approccio', 'glutelab-child-theme' ); ?></dt><dd><?php esc_html_e( 'Mirato e progressivo', 'glutelab-child-theme' ); ?></dd></div>
					<?php if ( ! empty( $contact['address'] ) ) : ?><div><dt><?php esc_html_e( 'Luogo', 'glutelab-child-theme' ); ?></dt><dd><?php echo esc_html( $contact['address'] ); ?></dd></div><?php endif; ?>
				</dl>
			</div>
		</section>

		<?php if ( $editorial ) : ?>
			<section class="gl-method-editorial gl-section" aria-labelledby="gl-method-editorial-title">
				<div class="gl-shell gl-method-editorial__layout">
					<h2 id="gl-method-editorial-title"><?php echo esc_html( $editorial['title'] ); ?></h2>
					<div class="gl-method-editorial__content gl-prose"><?php echo wp_kses_post( $editorial['content'] ); ?></div>
				</div>
			</section>
		<?php endif; ?>

		<section class="gl-method-steps gl-section" id="come-funziona" aria-labelledby="gl-method-steps-title">
			<div class="gl-shell">
				<header class="gl-method-steps__head">
					<p class="gl-kicker"><?php esc_html_e( 'Come funziona', 'glutelab-child-theme' ); ?></p>
					<h2 id="gl-method-steps-title"><?php esc_html_e( 'Dal punto di partenza alla continuità', 'glutelab-child-theme' ); ?></h2>
				</header>
				<ol class="gl-method-steps__list">
					<?php foreach ( $method_steps as $index => $step ) : ?>
						<li class="gl-method-step">
							<span><?php echo esc_html( sprintf( '%02d', $index + 1 ) ); ?></span>
							<h3><?php echo esc_html( $step['title'] ?? '' ); ?></h3>
							<?php if ( ! empty( $step['description'] ) ) : ?><p><?php echo esc_html( $step['description'] ); ?></p><?php endif; ?>
						</li>
					<?php endforeach; ?>
				</ol>
			</div>
		</section>

		<?php if ( $services ) : ?>
			<section class="gl-method-principles gl-section" aria-labelledby="gl-method-principles-title">
				<div class="gl-shell">
					<header class="gl-method-principles__head">
						<div>
							<p class="gl-kicker"><?php esc_html_e( 'Il lavoro', 'glutelab-child-theme' ); ?></p>
							<h2 id="gl-method-principles-title"><?php esc_html_e( 'Quattro elementi, una sola progressione', 'glutelab-child-theme' ); ?></h2>
						</div>
						<p><?php esc_html_e( 'Ogni seduta unisce precisione, attrezzature dedicate e accompagnamento personale per inserirsi nel tuo programma.', 'glutelab-child-theme' ); ?></p>
					</header>

					<div class="gl-method-principles__grid">
						<?php foreach ( $services as $index => $service ) : ?>
							<article class="gl-method-principle">
								<span><?php echo esc_html( sprintf( '%02d', $index + 1 ) ); ?></span>
								<div>
									<?php if ( ! empty( $service['title'] ) ) : ?><h3><?php echo esc_html( $service['title'] ); ?></h3><?php endif; ?>
									<?php if ( ! empty( $service['description'] ) ) : ?><p><?php echo esc_html( $service['description'] ); ?></p><?php endif; ?>
								</div>
							</article>
						<?php endforeach; ?>
					</div>
				</div>
			</section>
		<?php endif; ?>

		<?php if ( $audience ) : ?>
			<section class="gl-method-audience gl-section" aria-labelledby="gl-method-audience-title">
				<div class="gl-shell gl-method-audience__layout">
					<div class="gl-method-audience__copy">
						<h2 id="gl-method-audience-title"><?php echo esc_html( $audience['title'] ); ?></h2>
						<div class="gl-prose"><?php echo wp_kses_post( $audience['content'] ); ?></div>
						<a class="gl-button gl-button--primary" href="<?php echo esc_url( $packages_url ); ?>"><?php esc_html_e( 'Scopri lezioni e pacchetti', 'glutelab-child-theme' ); ?></a>
					</div>
					<dl class="gl-method-audience__facts">
						<div><dt><?php esc_html_e( 'Livello di esperienza', 'glutelab-child-theme' ); ?></dt><dd><?php esc_html_e( 'Dal livello di partenza', 'glutelab-child-theme' ); ?></dd></div>
						<?php if ( $duration ) : ?><div><dt><?php esc_html_e( 'Durata indicativa', 'glutelab-child-theme' ); ?></dt><dd><?php echo esc_html( $duration ); ?></dd></div><?php endif; ?>
					</dl>
				</div>
			</section>
		<?php endif; ?>

		<section class="gl-method-action gl-section">
			<div class="gl-shell gl-method-action__inner">
				<div>
					<p class="gl-kicker"><?php esc_html_e( 'Il prossimo passo', 'glutelab-child-theme' ); ?></p>
					<h2><?php esc_html_e( 'Scegli il percorso che completa il tuo allenamento', 'glutelab-child-theme' ); ?></h2>
				</div>
				<div class="gl-method-action__buttons">
					<a class="gl-button gl-button--light" href="<?php echo esc_url( $packages_url ); ?>"><?php esc_html_e( 'Vedi lezioni e pacchetti', 'glutelab-child-theme' ); ?></a>
					<a class="gl-button gl-button--outline-light" href="<?php echo esc_url( $contact_url ); ?>"><?php esc_html_e( 'Richiedi informazioni', 'glutelab-child-theme' ); ?></a>
				</div>
			</div>
		</section>
	<?php endwhile; ?>
</main>
<?php get_footer(); ?>
