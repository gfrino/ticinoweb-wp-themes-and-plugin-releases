<?php
/** Public Glute Lab request, booking and checkout page. @package GluteLabChildTheme */
if ( ! defined( 'ABSPATH' ) ) exit;
$selected_id = isset( $_GET['package'] ) ? sanitize_key( wp_unslash( $_GET['package'] ) ) : '';
get_header(); ?>
<main id="primary" class="gl-main gl-page gl-booking-page">
	<?php glutelab_app_render_purchase_page( $selected_id ); ?>
</main>
<?php get_footer(); ?>
