<?php
/**
 * Site footer.
 *
 * @package GluteLabChildTheme
 */

$contact     = glutelab_get_contact_data();
$hours       = glutelab_get_opening_hours_rows();
$contact_url = glutelab_page_url( 'contatti' );
$logo        = function_exists( 'ticinoweb_get_site_logo' ) ? ticinoweb_get_site_logo() : get_option( 'ticinoweb_site_logo', '' );
?>
<footer class="gl-footer">
	<div class="gl-shell gl-footer__inner">
		<div class="gl-footer__lead">
			<a class="gl-footer__brand" href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home" aria-label="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>">
				<?php if ( $logo ) : ?>
					<img src="<?php echo esc_url( $logo ); ?>" alt="" width="300" height="137">
				<?php else : ?>
					<span aria-hidden="true">GL</span>
				<?php endif; ?>
			</a>
			<div class="gl-footer__identity">
				<div class="gl-footer__message">
					<p class="gl-footer__eyebrow"><?php bloginfo( 'name' ); ?></p>
					<p class="gl-footer__statement"><?php esc_html_e( 'Allenamento mirato, macchinari dedicati e un percorso seguito presso ASCO Fit.', 'glutelab-child-theme' ); ?></p>
				</div>
				<a class="gl-footer__cta" href="<?php echo esc_url( $contact_url ); ?>">
					<span><?php esc_html_e( 'Richiedi una lezione', 'glutelab-child-theme' ); ?></span>
					<span aria-hidden="true">&#8599;</span>
				</a>
			</div>
		</div>

		<div class="gl-footer__grid">
			<section class="gl-footer__details" aria-labelledby="gl-footer-location">
				<p class="gl-footer__index" aria-hidden="true">01</p>
				<div>
					<h2 id="gl-footer-location"><?php esc_html_e( 'Dove siamo', 'glutelab-child-theme' ); ?></h2>
					<?php if ( ! empty( $contact['address'] ) ) : ?>
						<p><?php echo esc_html( $contact['address'] ); ?></p>
					<?php endif; ?>
					<?php if ( ! empty( $contact['opening_hours_note'] ) ) : ?>
						<p class="gl-footer__meta"><?php echo esc_html( $contact['opening_hours_note'] ); ?></p>
					<?php elseif ( $hours ) : ?>
						<p class="gl-footer__meta"><?php echo esc_html( $hours[0]['label'] . ' · ' . $hours[0]['value'] ); ?></p>
					<?php endif; ?>
				</div>
			</section>

			<section class="gl-footer__details" aria-labelledby="gl-footer-contact">
				<p class="gl-footer__index" aria-hidden="true">02</p>
				<div>
					<h2 id="gl-footer-contact"><?php esc_html_e( 'Contatti', 'glutelab-child-theme' ); ?></h2>
					<?php if ( ! empty( $contact['phone'] ) ) : ?>
						<p><a href="tel:<?php echo esc_attr( preg_replace( '/[^0-9+]/', '', $contact['phone'] ) ); ?>"><?php echo esc_html( $contact['phone'] ); ?></a></p>
					<?php endif; ?>
					<?php if ( ! empty( $contact['email'] ) ) : ?>
						<p class="gl-footer__meta"><a href="mailto:<?php echo esc_attr( antispambot( $contact['email'] ) ); ?>"><?php echo esc_html( antispambot( $contact['email'] ) ); ?></a></p>
					<?php endif; ?>
				</div>
			</section>

			<nav class="gl-footer__nav" aria-labelledby="gl-footer-navigation">
				<h2 id="gl-footer-navigation"><?php esc_html_e( 'Esplora', 'glutelab-child-theme' ); ?></h2>
				<?php
				wp_nav_menu(
					array(
						'theme_location' => 'primary',
						'container'      => false,
						'menu_class'     => 'gl-footer__menu',
						'fallback_cb'    => false,
						'depth'          => 1,
					)
				);
				?>
			</nav>
		</div>

		<div class="gl-footer__bottom">
			<p>&copy; <?php echo esc_html( wp_date( 'Y' ) ); ?> <?php bloginfo( 'name' ); ?></p>
			<p><?php esc_html_e( 'Glute Lab by ASCO Fit', 'glutelab-child-theme' ); ?></p>
			<?php if ( get_privacy_policy_url() ) : ?>
				<a href="<?php echo esc_url( get_privacy_policy_url() ); ?>"><?php esc_html_e( 'Privacy', 'glutelab-child-theme' ); ?></a>
			<?php endif; ?>
		</div>
	</div>
</footer>
<?php wp_footer(); ?>
</body>
</html>
