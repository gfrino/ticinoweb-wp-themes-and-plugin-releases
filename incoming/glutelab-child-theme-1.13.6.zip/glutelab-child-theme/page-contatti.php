<?php
/** Contact page. @package GluteLabChildTheme */
get_header();
?>
<main id="primary" class="gl-main gl-page"><header class="gl-page-hero"><div class="gl-shell gl-narrow"><p class="gl-kicker">GLUTE LAB — <?php esc_html_e( 'CONTATTI', 'glutelab-child-theme' ); ?></p><h1><?php the_title(); ?></h1><?php while ( have_posts() ) : the_post(); ?><div class="gl-prose"><?php the_content(); ?></div><?php endwhile; ?></div></header><section class="gl-contact gl-section"><div class="gl-shell gl-contact__grid"><div><?php get_template_part( 'template-parts/contact-details' ); ?></div><div><?php get_template_part( 'template-parts/contact-form' ); ?></div></div></section></main>
<?php get_footer(); ?>

