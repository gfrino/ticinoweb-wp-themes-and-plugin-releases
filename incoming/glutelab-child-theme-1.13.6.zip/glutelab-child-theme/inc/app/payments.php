<?php
/** Payment and credit workflows. @package GluteLabChildTheme */
if ( ! defined( 'ABSPATH' ) ) exit;

function glutelab_app_finalize_paid_order( $order_id, $provider_reference = '' ) {
	global $wpdb; $order = glutelab_app_get_order( $order_id );
	if ( ! $order ) return new WP_Error( 'order_not_found', __( 'Ordine non trovato.', 'glutelab-child-theme' ) );
	if ( ! empty( $order['credits_granted'] ) ) return $order;
	$package = glutelab_get_package( $order['package_id'] ); if ( ! $package ) return new WP_Error( 'package_not_found', __( 'Offerta non trovata.', 'glutelab-child-theme' ) );
	$wpdb->query( 'START TRANSACTION' );
	$credits = glutelab_app_package_credits( $package );
	if ( $credits ) {
		$entry = glutelab_app_add_credit_entry( array( 'customer_id' => $order['customer_id'], 'order_id' => $order['id'], 'delta' => $credits, 'reason' => 'purchase', 'idempotency_key' => 'order-paid-' . $order['id'], 'note' => $provider_reference ) );
		if ( is_wp_error( $entry ) ) { $wpdb->query( 'ROLLBACK' ); return $entry; }
	}
	$updated = $wpdb->update( glutelab_app_table( 'orders' ), array( 'status' => 'paid', 'credits_granted' => 1, 'paid_at' => glutelab_app_now_utc(), 'updated_at' => glutelab_app_now_utc(), 'stripe_payment_intent_id' => sanitize_text_field( $provider_reference ) ), array( 'id' => (int) $order_id, 'credits_granted' => 0 ) );
	if ( false === $updated ) { $wpdb->query( 'ROLLBACK' ); return new WP_Error( 'order_update_failed', __( 'Non è stato possibile confermare il pagamento.', 'glutelab-child-theme' ) ); }
	if ( ! empty( $order['booking_id'] ) ) $wpdb->update( glutelab_app_table( 'bookings' ), array( 'status' => 'confirmed', 'expires_at' => null, 'updated_at' => glutelab_app_now_utc() ), array( 'id' => (int) $order['booking_id'] ) );
	$wpdb->query( 'COMMIT' ); return glutelab_app_get_order( $order_id );
}

function glutelab_app_create_request( array $input ) {
	$package = glutelab_get_package( sanitize_key( $input['package_id'] ?? '' ) );
	if ( ! $package || 'active' !== $package['status'] ) return new WP_Error( 'invalid_package', __( 'L’offerta selezionata non è disponibile.', 'glutelab-child-theme' ) );
	$customer_id = glutelab_app_upsert_customer( $input ); if ( is_wp_error( $customer_id ) ) return $customer_id;
	$method = sanitize_key( $input['payment_method'] ?? 'inquiry' ); if ( ! in_array( $method, array( 'inquiry', 'in_person', 'stripe' ), true ) ) $method = 'inquiry';
	$order = glutelab_app_create_order( array( 'customer_id' => $customer_id, 'package_id' => $package['id'], 'amount_cents' => (int) round( $package['price'] * 100 ), 'payment_method' => $method, 'status' => 'stripe' === $method ? 'awaiting_payment' : 'pending' ) );
	if ( is_wp_error( $order ) ) return $order;
	$booking = null;
	if ( ! empty( $input['start_at_utc'] ) || ! empty( $input['preferred_date'] ) ) {
		$booking = glutelab_app_create_booking( array( 'customer_id' => $customer_id, 'order_id' => $order['id'], 'preferred_date' => sanitize_text_field( $input['preferred_date'] ?? '' ), 'start_at_utc' => sanitize_text_field( $input['start_at_utc'] ?? '' ), 'end_at_utc' => sanitize_text_field( $input['end_at_utc'] ?? '' ), 'seats' => 1, 'status' => 'stripe' === $method ? 'pending' : 'requested', 'notes' => $input['notes'] ?? '', 'expires_at' => 'stripe' === $method ? gmdate( 'Y-m-d H:i:s', time() + 1800 ) : null ), $package );
		global $wpdb;
		if ( is_wp_error( $booking ) ) {
			$wpdb->delete( glutelab_app_table( 'orders' ), array( 'id' => (int) $order['id'] ), array( '%d' ) );
			return $booking;
		}
		$wpdb->update( glutelab_app_table( 'orders' ), array( 'booking_id' => $booking['id'] ), array( 'id' => $order['id'] ) );
	}
	return array( 'customer_id' => $customer_id, 'order' => $order, 'booking' => $booking, 'package' => $package );
}

function glutelab_app_use_booking_credit( $booking_id ) {
	global $wpdb; $booking = glutelab_app_get_booking( $booking_id );
	if ( ! $booking ) return new WP_Error( 'booking_not_found', __( 'Prenotazione non trovata.', 'glutelab-child-theme' ) );
	if ( ! empty( $booking['credits_used'] ) ) return true;
	if ( glutelab_app_credit_balance( $booking['customer_id'] ) < 1 ) return new WP_Error( 'insufficient_credits', __( 'Il cliente non ha crediti disponibili.', 'glutelab-child-theme' ) );
	$entry = glutelab_app_add_credit_entry( array( 'customer_id' => $booking['customer_id'], 'booking_id' => $booking['id'], 'order_id' => $booking['order_id'], 'delta' => -1, 'reason' => 'booking', 'idempotency_key' => 'booking-use-' . $booking['id'], 'note' => $booking['reference'] ) );
	if ( is_wp_error( $entry ) ) return $entry;
	$wpdb->update( glutelab_app_table( 'bookings' ), array( 'credits_used' => 1, 'updated_at' => glutelab_app_now_utc() ), array( 'id' => (int) $booking_id ) ); return true;
}

function glutelab_app_restore_booking_credit( $booking_id ) {
	global $wpdb; $booking = glutelab_app_get_booking( $booking_id );
	if ( ! $booking || empty( $booking['credits_used'] ) ) return true;
	$entry = glutelab_app_add_credit_entry( array( 'customer_id' => $booking['customer_id'], 'booking_id' => $booking['id'], 'order_id' => $booking['order_id'], 'delta' => 1, 'reason' => 'cancellation', 'idempotency_key' => 'booking-restore-' . $booking['id'], 'note' => $booking['reference'] ) );
	if ( is_wp_error( $entry ) ) return $entry;
	$wpdb->update( glutelab_app_table( 'bookings' ), array( 'credits_used' => 0, 'updated_at' => glutelab_app_now_utc() ), array( 'id' => (int) $booking_id ) ); return true;
}

function glutelab_app_booking_status_transition_allowed( $current, $next ) {
	$current = sanitize_key( $current );
	$next    = sanitize_key( $next );
	if ( $current === $next ) return true;
	if ( in_array( $current, array( 'completed', 'cancelled', 'no_show' ), true ) ) return false;
	return in_array( $next, array( 'confirmed', 'cancelled', 'completed', 'no_show' ), true );
}
