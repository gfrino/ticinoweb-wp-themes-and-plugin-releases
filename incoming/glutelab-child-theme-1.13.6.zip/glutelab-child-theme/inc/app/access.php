<?php
/**
 * Dedicated access for Glute Lab managers.
 *
 * THESIS: keep WordPress authentication familiar while removing every task
 * unrelated to Glute Lab. OWN-WORLD: warm white, lilac and one decisive
 * violet action, using the official logo and native controls. STORY: sign in,
 * arrive directly in operations, work without CMS noise. FIRST VIEWPORT: logo,
 * a concise access message and the native form in one compact panel. FORM:
 * focused Operate surface extending the established Glute Lab admin system.
 *
 * @package GluteLabChildTheme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'GLUTELAB_ACCESS_VERSION', '1.0.0' );
define( 'GLUTELAB_MANAGER_ROLE', 'glutelab_manager' );

/** Return the capability shared by the operational UI and all its mutations. */
function glutelab_app_management_capability() {
	return 'manage_glutelab';
}

/** Resolve a request path relative to the current Multisite subdirectory. */
function glutelab_access_relative_request_path( $request_uri = null, $current_site_url = null ) {
	$request_uri      = null === $request_uri ? (string) ( $_SERVER['REQUEST_URI'] ?? '' ) : (string) $request_uri;
	$current_site_url = null === $current_site_url ? site_url() : (string) $current_site_url;
	$request_path     = (string) parse_url( $request_uri, PHP_URL_PATH );
	$site_path        = (string) parse_url( $current_site_url, PHP_URL_PATH );
	$site_path        = '/' . trim( $site_path, '/' );

	if ( '/' !== $site_path && ( $request_path === $site_path || 0 === strpos( $request_path, $site_path . '/' ) ) ) {
		$request_path = substr( $request_path, strlen( $site_path ) );
	}

	return trim( $request_path, '/' );
}

/** True only for the exact dedicated login endpoint of the current site. */
function glutelab_access_is_login_request( $request_uri = null, $current_site_url = null ) {
	return 'glutelab-login' === glutelab_access_relative_request_path( $request_uri, $current_site_url );
}

/** True only for the standard ticinoWEB login endpoint of the current site. */
function glutelab_access_is_classic_login_request( $request_uri = null, $current_site_url = null ) {
	return 'tw-login' === glutelab_access_relative_request_path( $request_uri, $current_site_url );
}

/** Return the per-site cookie used to remember which backend was requested. */
function glutelab_access_mode_cookie_name() {
	return 'glutelab_access_mode_' . md5( (string) get_option( 'siteurl' ) );
}

/** Scope the access-mode cookie to this Multisite subsite. */
function glutelab_access_mode_cookie_path() {
	$path = (string) parse_url( site_url(), PHP_URL_PATH );
	return '/' === $path ? '/' : trailingslashit( '/' . trim( $path, '/' ) );
}

/** Persist or clear the selected Glute Lab backend mode. */
function glutelab_access_set_mode_cookie( $enabled ) {
	$name    = glutelab_access_mode_cookie_name();
	$value   = $enabled ? '1' : '';
	$expires = $enabled ? time() + ( 30 * 86400 ) : time() - 3600;

	setcookie(
		$name,
		$value,
		array(
			'expires'  => $expires,
			'path'     => glutelab_access_mode_cookie_path(),
			'secure'   => 'https' === parse_url( site_url(), PHP_URL_SCHEME ),
			'httponly' => true,
			'samesite' => 'Lax',
		)
	);

	if ( $enabled ) {
		$_COOKIE[ $name ] = '1';
	} else {
		unset( $_COOKIE[ $name ] );
	}
}

/** Read the backend mode selected through the dedicated login endpoint. */
function glutelab_access_is_dedicated_mode() {
	$name = glutelab_access_mode_cookie_name();
	return isset( $_COOKIE[ $name ] ) && '1' === (string) $_COOKIE[ $name ];
}

/** Remember glutelab-login and explicitly reset the mode on tw-login. */
function glutelab_access_sync_entry_mode() {
	if ( 'cli' === PHP_SAPI || ( defined( 'WP_CLI' ) && WP_CLI ) ) {
		return;
	}
	if ( glutelab_access_is_login_request() ) {
		glutelab_access_set_mode_cookie( true );
	} elseif ( glutelab_access_is_classic_login_request() ) {
		glutelab_access_set_mode_cookie( false );
	}
}
add_action( 'init', 'glutelab_access_sync_entry_mode', 0 );

/** Build the dedicated login URL on the current site. */
function glutelab_access_login_url( $args = array() ) {
	$url = trailingslashit( site_url( 'glutelab-login' ) );
	return $args ? add_query_arg( $args, $url ) : $url;
}

/** Build the single administration destination exposed to a Glute Lab manager. */
function glutelab_access_admin_url() {
	return add_query_arg( array( 'page' => 'glutelab-operations' ), admin_url( 'admin.php' ) );
}

/** Install or update the per-site role without touching existing user accounts. */
function glutelab_access_install_roles() {
	$capabilities = array(
		'read'             => true,
		'upload_files'     => true,
		'manage_glutelab' => true,
	);
	$role = get_role( GLUTELAB_MANAGER_ROLE );
	if ( ! $role ) {
		$role = add_role( GLUTELAB_MANAGER_ROLE, __( 'Gestore Glute Lab', 'glutelab-child-theme' ), $capabilities );
	}
	if ( $role ) {
		foreach ( $capabilities as $capability => $grant ) {
			$role->add_cap( $capability, $grant );
		}
	}

	$administrator = get_role( 'administrator' );
	if ( $administrator ) {
		$administrator->add_cap( glutelab_app_management_capability() );
	}

	update_option( 'glutelab_access_version', GLUTELAB_ACCESS_VERSION, false );
}

/** Upgrade roles once per access-module version. */
function glutelab_access_maybe_install_roles() {
	if ( GLUTELAB_ACCESS_VERSION !== get_option( 'glutelab_access_version' ) ) {
		glutelab_access_install_roles();
	}
}
add_action( 'init', 'glutelab_access_maybe_install_roles', 0 );
add_action( 'after_switch_theme', 'glutelab_access_install_roles' );

/** Identify the intentionally restricted role, never an administrator. */
function glutelab_access_is_restricted_manager( $user = null ) {
	$user = $user ?: wp_get_current_user();
	if ( ! $user || empty( $user->ID ) || user_can( $user, 'manage_options' ) ) {
		return false;
	}
	return in_array( GLUTELAB_MANAGER_ROLE, (array) $user->roles, true );
}

/** Decide whether a user should see only the Glute Lab workspace. */
function glutelab_access_should_restrict_user( $user, $dedicated_mode ) {
	if ( glutelab_access_is_restricted_manager( $user ) ) {
		return true;
	}
	return $dedicated_mode && is_object( $user ) && ! empty( $user->ID ) && user_can( $user, glutelab_app_management_capability() );
}

/** Resolve the active access mode for the current request and user. */
function glutelab_access_is_restricted_context( $user = null ) {
	$user           = $user ?: wp_get_current_user();
	$dedicated_mode = glutelab_access_is_dedicated_mode() || ( defined( 'GLUTELAB_LOGIN_CONTEXT' ) && GLUTELAB_LOGIN_CONTEXT );
	return glutelab_access_should_restrict_user( $user, $dedicated_mode );
}

/** Serve WordPress core login through the additional Glute Lab endpoint. */
function glutelab_access_serve_login() {
	if ( 'cli' === PHP_SAPI || ( defined( 'WP_CLI' ) && WP_CLI ) || ! glutelab_access_is_login_request() ) {
		return;
	}

	if ( ! defined( 'GLUTELAB_LOGIN_CONTEXT' ) ) {
		define( 'GLUTELAB_LOGIN_CONTEXT', true );
	}

	$action = sanitize_key( wp_unslash( $_REQUEST['action'] ?? 'login' ) );
	if ( is_user_logged_in() && ! in_array( $action, array( 'logout', 'postpass' ), true ) ) {
		$destination = glutelab_access_is_restricted_context() ? glutelab_access_admin_url() : admin_url();
		wp_safe_redirect( $destination );
		exit;
	}

	global $error, $interim_login, $action, $user_login;
	require ABSPATH . 'wp-login.php';
	exit;
}
add_action( 'init', 'glutelab_access_serve_login', 2 );

/** Keep all WordPress-generated login actions inside the dedicated endpoint. */
function glutelab_access_filter_login_url( $url ) {
	$dedicated_context = ( defined( 'GLUTELAB_LOGIN_CONTEXT' ) && GLUTELAB_LOGIN_CONTEXT ) || glutelab_access_is_dedicated_mode();
	if ( $dedicated_context ) {
		$path = (string) parse_url( $url, PHP_URL_PATH );
		if ( ! in_array( basename( rtrim( $path, '/' ) ), array( 'wp-login.php', 'tw-login', 'glutelab-login' ), true ) ) {
			return $url;
		}
		$query    = (string) parse_url( $url, PHP_URL_QUERY );
		$fragment = (string) parse_url( $url, PHP_URL_FRAGMENT );
		$url      = trailingslashit( home_url( 'glutelab-login' ) );
		if ( '' !== $query ) {
			$url .= '?' . $query;
		}
		if ( '' !== $fragment ) {
			$url .= '#' . $fragment;
		}
	}
	return $url;
}
add_filter( 'site_url', 'glutelab_access_filter_login_url', 30 );
add_filter( 'network_site_url', 'glutelab_access_filter_login_url', 30 );
add_filter( 'wp_redirect', 'glutelab_access_filter_login_url', 30 );

/** Send the dedicated role directly to its only workspace after authentication. */
function glutelab_access_login_redirect( $redirect_to, $requested_redirect_to, $user ) {
	if ( is_object( $user ) && ! empty( $user->ID ) && glutelab_access_is_restricted_context( $user ) ) {
		return glutelab_access_admin_url();
	}
	return $redirect_to;
}
add_filter( 'login_redirect', 'glutelab_access_login_redirect', 10, 3 );

/** Return Glute Lab managers to their dedicated login after logout. */
function glutelab_access_logout_redirect( $redirect_to, $requested_redirect_to, $user ) {
	if ( is_object( $user ) && ! empty( $user->ID ) && glutelab_access_is_restricted_context( $user ) ) {
		return glutelab_access_login_url( array( 'loggedout' => 'true' ) );
	}
	return $redirect_to;
}
add_filter( 'logout_redirect', 'glutelab_access_logout_redirect', 10, 3 );

/** Declare the small set of technical administration endpoints the role needs. */
function glutelab_access_is_allowed_admin_request( $pagenow, $page, $is_ajax ) {
	if ( $is_ajax ) {
		return true;
	}
	if ( 'admin.php' === $pagenow ) {
		return 'glutelab-operations' === $page;
	}
	return in_array( $pagenow, array( 'admin-post.php', 'options.php', 'async-upload.php', 'load-scripts.php', 'load-styles.php' ), true );
}

/** Prevent direct access to every unrelated wp-admin screen. */
function glutelab_access_guard_admin() {
	if ( ! glutelab_access_is_restricted_context() ) {
		return;
	}
	global $pagenow;
	$page    = sanitize_key( wp_unslash( $_GET['page'] ?? '' ) );
	$is_ajax = function_exists( 'wp_doing_ajax' ) && wp_doing_ajax();
	if ( glutelab_access_is_allowed_admin_request( (string) $pagenow, $page, $is_ajax ) ) {
		return;
	}
	wp_safe_redirect( glutelab_access_admin_url() );
	exit;
}
add_action( 'admin_init', 'glutelab_access_guard_admin', 1 );

/** Keep a single, explicit menu item for the restricted role. */
function glutelab_access_prune_admin_menu() {
	if ( ! glutelab_access_is_restricted_context() ) {
		return;
	}
	global $menu, $submenu;
	$menu = array_values( array_filter( (array) $menu, static function ( $item ) {
		return isset( $item[2] ) && 'glutelab-operations' === $item[2];
	} ) );
	$submenu = array();
}
add_action( 'admin_menu', 'glutelab_access_prune_admin_menu', 999 );

/** Remove unrelated shortcuts while retaining the native account/logout menu. */
function glutelab_access_prune_admin_bar( $admin_bar ) {
	if ( ! glutelab_access_is_restricted_context() ) {
		return;
	}
	foreach ( array( 'wp-logo', 'site-name', 'updates', 'comments', 'new-content', 'search' ) as $node ) {
		$admin_bar->remove_node( $node );
	}
}
add_action( 'admin_bar_menu', 'glutelab_access_prune_admin_bar', 999 );

/** Add a body class for small restricted-workspace refinements. */
function glutelab_access_admin_body_class( $classes ) {
	return glutelab_access_is_restricted_context() ? $classes . ' glutelab-manager-admin' : $classes;
}
add_filter( 'admin_body_class', 'glutelab_access_admin_body_class' );

/** Hide WordPress help and screen settings from the focused workspace. */
function glutelab_access_show_screen_controls( $show ) {
	return glutelab_access_is_restricted_context() ? false : $show;
}
add_filter( 'screen_options_show_screen', 'glutelab_access_show_screen_controls' );

/** Remove help tabs with the supported screen API, without deprecated hooks. */
function glutelab_access_remove_help_tabs() {
	if ( ! glutelab_access_is_restricted_context() ) {
		return;
	}
	$screen = get_current_screen();
	if ( $screen ) {
		$screen->remove_help_tabs();
	}
}
add_action( 'current_screen', 'glutelab_access_remove_help_tabs', 30 );

/** Keep the dedicated workspace free from the generic core-update prompt. */
function glutelab_access_remove_update_notice() {
	if ( ! glutelab_access_is_restricted_context() ) {
		return;
	}
	remove_action( 'admin_notices', 'update_nag', 3 );
	remove_action( 'network_admin_notices', 'update_nag', 3 );
}
add_action( 'admin_init', 'glutelab_access_remove_update_notice', 20 );

/** Load the dedicated visual treatment only on glutelab-login. */
function glutelab_access_login_assets() {
	if ( ! defined( 'GLUTELAB_LOGIN_CONTEXT' ) || ! GLUTELAB_LOGIN_CONTEXT ) {
		return;
	}
	$path = get_stylesheet_directory() . '/assets/css/login.css';
	wp_enqueue_style( 'glutelab-login', get_stylesheet_directory_uri() . '/assets/css/login.css', array(), is_file( $path ) ? filemtime( $path ) : GLUTELAB_THEME_VERSION );
}
add_action( 'login_enqueue_scripts', 'glutelab_access_login_assets', 30 );

/** Add a route-specific class without altering the normal tw-login screen. */
function glutelab_access_login_body_class( $classes ) {
	if ( defined( 'GLUTELAB_LOGIN_CONTEXT' ) && GLUTELAB_LOGIN_CONTEXT ) {
		$classes[] = 'glutelab-login';
	}
	return $classes;
}
add_filter( 'login_body_class', 'glutelab_access_login_body_class' );

/** Explain the purpose of the dedicated access before the native form. */
function glutelab_access_login_message( $message ) {
	if ( ! defined( 'GLUTELAB_LOGIN_CONTEXT' ) || ! GLUTELAB_LOGIN_CONTEXT ) {
		return $message;
	}
	$intro  = '<div class="glutelab-login__intro">';
	$intro .= '<strong>' . esc_html__( 'Accesso Gestione Glute Lab', 'glutelab-child-theme' ) . '</strong>';
	$intro .= '<span>' . esc_html__( 'Inserisci le tue credenziali per gestire richieste, clienti, orari, pacchetti e pagamenti.', 'glutelab-child-theme' ) . '</span>';
	$intro .= '</div>';
	return $intro . $message;
}
add_filter( 'login_message', 'glutelab_access_login_message' );

/** Use Glute Lab identity for the dedicated login header only. */
function glutelab_access_login_header_url( $url ) {
	return defined( 'GLUTELAB_LOGIN_CONTEXT' ) && GLUTELAB_LOGIN_CONTEXT ? home_url( '/' ) : $url;
}
add_filter( 'login_headerurl', 'glutelab_access_login_header_url', 30 );

function glutelab_access_login_header_text( $text ) {
	return defined( 'GLUTELAB_LOGIN_CONTEXT' ) && GLUTELAB_LOGIN_CONTEXT ? __( 'Glute Lab', 'glutelab-child-theme' ) : $text;
}
add_filter( 'login_headertext', 'glutelab_access_login_header_text', 30 );

function glutelab_access_login_language_dropdown( $display ) {
	return defined( 'GLUTELAB_LOGIN_CONTEXT' ) && GLUTELAB_LOGIN_CONTEXT ? false : $display;
}
add_filter( 'login_display_language_dropdown', 'glutelab_access_login_language_dropdown' );

