<?php
/** Per-site database schema. @package GluteLabChildTheme */
if ( ! defined( 'ABSPATH' ) ) exit;

define( 'GLUTELAB_APP_DB_VERSION', '1.2.0' );
function glutelab_app_table( $name ) { global $wpdb; return $wpdb->prefix . 'glutelab_' . sanitize_key( $name ); }

function glutelab_app_install_schema() {
	global $wpdb;
	require_once ABSPATH . 'wp-admin/includes/upgrade.php';
	$charset = $wpdb->get_charset_collate();
	$sql = array(
		"CREATE TABLE " . glutelab_app_table( 'customers' ) . " (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			email varchar(190) NOT NULL,
			first_name varchar(100) NOT NULL DEFAULT '',
			last_name varchar(100) NOT NULL DEFAULT '',
			phone varchar(50) NOT NULL DEFAULT '',
			locale varchar(20) NOT NULL DEFAULT '',
			created_at datetime NOT NULL,
			updated_at datetime NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY email (email)
		) {$charset};",
		"CREATE TABLE " . glutelab_app_table( 'orders' ) . " (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			reference varchar(40) NOT NULL,
			customer_id bigint(20) unsigned NOT NULL,
			package_id varchar(100) NOT NULL,
			amount_cents int unsigned NOT NULL DEFAULT 0,
			currency varchar(3) NOT NULL DEFAULT 'CHF',
			payment_method varchar(20) NOT NULL,
			status varchar(30) NOT NULL,
			credits_granted tinyint(1) NOT NULL DEFAULT 0,
			stripe_session_id varchar(190) DEFAULT NULL,
			stripe_payment_intent_id varchar(190) DEFAULT NULL,
			booking_id bigint(20) unsigned DEFAULT NULL,
			created_at datetime NOT NULL,
			paid_at datetime DEFAULT NULL,
			updated_at datetime NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY reference (reference),
			KEY customer_id (customer_id),
			KEY stripe_session_id (stripe_session_id)
		) {$charset};",
		"CREATE TABLE " . glutelab_app_table( 'bookings' ) . " (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			reference varchar(40) NOT NULL,
			customer_id bigint(20) unsigned NOT NULL,
			package_id varchar(100) NOT NULL,
			service_key varchar(100) NOT NULL,
			order_id bigint(20) unsigned DEFAULT NULL,
			preferred_date date DEFAULT NULL,
			start_at_utc datetime DEFAULT NULL,
			end_at_utc datetime DEFAULT NULL,
			seats smallint unsigned NOT NULL DEFAULT 1,
			status varchar(30) NOT NULL,
			credits_used smallint unsigned NOT NULL DEFAULT 0,
			notes text NOT NULL,
			expires_at datetime DEFAULT NULL,
			reminder_sent_at datetime DEFAULT NULL,
			created_at datetime NOT NULL,
			updated_at datetime NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY reference (reference),
			KEY customer_id (customer_id),
			KEY slot (service_key,start_at_utc,status),
			KEY preferred_date (preferred_date,status)
		) {$charset};",
		"CREATE TABLE " . glutelab_app_table( 'credit_ledger' ) . " (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			customer_id bigint(20) unsigned NOT NULL,
			order_id bigint(20) unsigned DEFAULT NULL,
			booking_id bigint(20) unsigned DEFAULT NULL,
			delta int NOT NULL,
			balance_after int NOT NULL,
			reason varchar(30) NOT NULL,
			idempotency_key varchar(190) NOT NULL,
			note varchar(255) NOT NULL DEFAULT '',
			created_at datetime NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY idempotency_key (idempotency_key),
			KEY customer_id (customer_id)
		) {$charset};",
		"CREATE TABLE " . glutelab_app_table( 'webhook_events' ) . " (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			provider_event_id varchar(190) NOT NULL,
			event_type varchar(100) NOT NULL,
			status varchar(30) NOT NULL,
			payload_hash char(64) NOT NULL,
			processed_at datetime DEFAULT NULL,
			created_at datetime NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY provider_event_id (provider_event_id)
		) {$charset};",
	);
	foreach ( $sql as $statement ) dbDelta( $statement );
	$bookings_table = glutelab_app_table( 'bookings' );
	$has_preferred_date = $wpdb->get_var( $wpdb->prepare( "SHOW COLUMNS FROM {$bookings_table} LIKE %s", 'preferred_date' ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	if ( ! $has_preferred_date ) {
		$wpdb->query( "ALTER TABLE {$bookings_table} ADD preferred_date date DEFAULT NULL AFTER order_id, ADD KEY preferred_date (preferred_date,status)" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$has_preferred_date = $wpdb->get_var( $wpdb->prepare( "SHOW COLUMNS FROM {$bookings_table} LIKE %s", 'preferred_date' ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	}
	if ( ! $has_preferred_date ) return false;
	update_option( 'glutelab_app_db_version', GLUTELAB_APP_DB_VERSION, false );
	return true;
}

function glutelab_app_maybe_upgrade_schema() {
	if ( version_compare( (string) get_option( 'glutelab_app_db_version', '0' ), GLUTELAB_APP_DB_VERSION, '<' ) ) glutelab_app_install_schema();
}
